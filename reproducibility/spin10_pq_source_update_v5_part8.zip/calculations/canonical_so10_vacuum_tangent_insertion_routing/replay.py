"""HPR1 exterior integral and abstract charge-conjugation transpose algebra."""
from data import *
from collections import defaultdict
t=begin('replay')
def add(A,B):
 out=dict(A)
 for k,v in B.items():out[k]=s.expand(out.get(k,0)+v)
 return {k:v for k,v in out.items() if v}
def mul(A,B):
 out=defaultdict(lambda:s.S.Zero)
 for a,x in A.items():
  for b,y in B.items():
   if a&b:continue
   inv=sum((b&((1<<i)-1)).bit_count() for i in range(7) if a&(1<<i));out[a|b]+=(-1)**inv*x*y
 return {k:s.expand(v) for k,v in out.items() if s.expand(v)!=0}
def word(w,c):
 out={0:c}
 for i in w:out=mul(out,{1<<i:1})
 return out
f,q,y,th,x=s.symbols('f q y th x',nonzero=True);action={}
for w,c in [([5,6],-f),([3,4],-q),([6,2],y*x),([0,4],th*x)]:action=add(action,word(w,c))
Z=term={0:s.S.One}
for j in range(1,6):term={k:-v/s.Integer(j) for k,v in mul(term,action).items()};Z=add(Z,term)
internal=sum(1<<j for j in [3,4,5,6]);base=Z[internal];out=mul(word([3,5,1],1),Z);wick=s.simplify(out[127]*f*q/(base*y*th*x*x));assert wick==1
# Abstract E^T=-C Atilde h, G=-i h C^-1 gives +i C Atilde Tau.
# Antisymmetrizing the external quadratic form gives the holo minus and
# anti plus. Check this with free noncommuting color words, not a Ward target.
TT,Tt,MM,NN=s.symbols('T Ttranspose M N',commutative=False)
# Transpose of C times a mass word reverses the color word and contributes
# C^T=-C. Atilde is -T^T in PL and +T in PR.
ordered_h=s.I*(-Tt)*MM;transposed_h=-s.I*MM*(-TT)
ordered_a=s.I*TT*NN;transposed_a=-s.I*NN*Tt
kh=s.expand(wick*(ordered_h-transposed_h));ka=s.expand(wick*(ordered_a-transposed_a))
hc=kh.coeff(Tt*MM);ac=ka.coeff(TT*NN)
assert s.expand(kh-hc*(Tt*MM+MM*TT))==0 and s.expand(ka-ac*(TT*NN+NN*Tt))==0
eps,dh,mu=s.symbols('epsilon dhat m2',positive=True);reg=dh*s.gamma(1+eps)*mu**(-eps)/(2*s.gamma(3));moment=s.simplify(s.diff(reg.subs(dh,-2*eps),eps).subs(eps,0))
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');gy=packed(CAL/'canonical_so10_gauge_yukawa_vertex_poles/replay_v2_tables.json.gz');CI,CH=map(dec,gy['scalar_Casimir_I_H']);K=tidy(CI-CH)
unit=s.simplify(hc*moment*s.I);aunit=s.simplify(ac*moment*(-s.I));models=[]
for r in ['10','126']:
 B=dec(Y['B'+r]);models.append({'carrier':r,'total':enc(tidy(unit*B*K)),'antiholomorphic':enc(tidy(aunit*s.conjugate(B)*K))})
finish('replay',{'method':'exterior_Gaussian_abstract_Ctranspose_Schwinger_variance','holo_kernel_unit':str(hc),'anti_kernel_unit':str(ac),'finite_moment':str(moment),'color_BK_unit':str(unit),'anti_color_BK_unit':str(aunit),'models':models,'quadratic_kernel_positions':1024,'proper_topologies':1,'ordered_endpoints':2,'all_tangent_directions':328,'color_covariance_and_Casimir_inherited':True},t)
