# HPR1: literal Gaussian kernel before physical mass projection

Use the compact insertion C_ghost S^T E P and Yukawa x P^T Y P/2.
At external fermion hats0 the insertion derivative on P vanishes. Write r
for its S field momentum. All incoming momenta give q_ghost=-r, hence the
actual iE coefficient -qhat A becomes +rhat A. In Majorana coordinates

    E = Cspin rhat A,
    G_SP(r) = -i rhat Cspin^-1,
    Y = Cspin Tau.

The ordered word C,S,P1,h,a,p,P2 has even permutation parity relative to
h,P1,P2,C,a,S,p. The two action insertions contribute two minus signs.
The direct Gaussian contraction therefore gives the coefficient E^T G_SP Y
of h P1 P2. To express it as a quadratic form1/2 P^T K P, the external
kernel is K=E^T G_SP Y-(E^T G_SP Y)^T. This transpose is essential.
It is not the same operation as reading the two ordinary open chains with
their momenta given the same direction. The Yukawa1/2 cancels its two
external/internal polarizations; no additional open-line half remains.

Using Cspin^T=-Cspin, (Cspin gammahat)^T=Cspin gammahat,
and A=PL T-PR T^T, one obtains, before integration,

    K_holo = -i Cspin PL (T^T Tau+Tau T) rhat^2,
    K_anti = +i Cspin PR (T Taubar+Taubar T^T) rhat^2.

Primary checks these formulas with the full SMA Clifford/charge-conjugation
witness and a generic Hermitian2x2 generator and symmetric2x2 scalar maps.
Replay uses exterior Gaussian integration and the abstract transpose rules.
The analytic hat dimension is still continued, never replaced by the finite
witness rank. Gamma integration or an independent Schwinger variance gives
int hat k^2/(k^2+mIR^2)^3 = -1/2 in16pi^2 units. A positive common auxiliary
IR completion is only a local-coefficient device, not a physical mass input.

For the actual tangent interaction and raw ghost/dual pairing, the color sum
of T^T Tau+Tau T is i B K_scalar h by qualified full45 YCT covariance and
the heavy scalar Casimir K_scalar. The anti expression uses its conjugate.
These inherited identities determine the complete h tensor after the new
kernel unit has been extracted; neither is fitted to the MFC remainder.

The selected dimensional insertion, the heat regulator response, and the
variation of relative local parents are three distinct quantities. A late
algebraic comparison can specify what an eventual extended comparison identity
would require, but it does not calculate that heat response or prove the
identity's analytic/source prerequisites. Those remain the next task.
