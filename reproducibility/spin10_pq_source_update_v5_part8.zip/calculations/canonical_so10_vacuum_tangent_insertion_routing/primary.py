"""HPR1 literal charge-conjugation kernel and independent Gamma moment."""
from data import *
t=begin('primary');pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g4=[s.kronecker_product(pa[1],z) for z in pa]+[s.kronecker_product(pa[0],s.eye(2))]
g8=[s.kronecker_product(g,pa[2]) for g in g4]+[s.kronecker_product(s.eye(4),z) for z in pa[:2]]
C8=g8[0]*g8[2]*g8[5];C=s.kronecker_product(C8,pa[1]);gam=[s.kronecker_product(a,s.eye(2)) for a in g8];chi=s.kronecker_product(s.diag(1,1,-1,-1),s.eye(4));PL=(s.eye(16)+chi)/2;PR=s.eye(16)-PL
zero(C.T+C)
for g in gam:zero((C*g).T-C*g)
h=gam[4];zero(h*h-s.eye(16));zero(h*chi-chi*h)
u=s.symbols('t0:4',real=True);T=s.Matrix([[u[0],u[1]+s.I*u[2]],[u[1]-s.I*u[2],u[3]]]);m=s.symbols('m0:3');n=s.symbols('n0:3');M=s.Matrix([[m[0],m[1]],[m[1],m[2]]]);N=s.Matrix([[n[0],n[1]],[n[1],n[2]]])
CC=s.kronecker_product(C,s.eye(2));H=s.kronecker_product(h,s.eye(2));A=s.kronecker_product(PL,T)-s.kronecker_product(PR,T.T);Tau=s.kronecker_product(PL,M)+s.kronecker_product(PR,N)
# r is the momentum of the S field in the contraction <S(r)P(-r)>.
# qghost=-r at the compact insertion, so its -qhat A coefficient is +rhat A.
E=CC*H*A;G=-s.I*H*CC.inv();Y=CC*Tau;ordered=E.T*G*Y;kernel=ordered-ordered.T
hol=CC*s.kronecker_product(PL,T.T*M+M*T);anti=CC*s.kronecker_product(PR,T*N+N*T.T)
den=s.trace(hol.H*hol);hc=s.simplify(s.trace(hol.H*kernel)/den)
ac=s.simplify(s.trace(anti.H*kernel)/s.trace(anti.H*anti));zero(kernel-hc*hol-ac*anti)
eps,dh,mu=s.symbols('epsilon dhat m2',positive=True);D=4-2*eps
reg=dh/D*mu**(-eps)*s.gamma(1+D/2)*s.gamma(1+eps)/(s.gamma(D/2)*s.gamma(3));moment=s.simplify(s.diff(reg.subs(dh,-2*eps),eps).subs(eps,0))
Yc=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');K=dec(packed(CAL/'canonical_so10_vacuum_tangent_source_kernel/primary_tables.json.gz')['kernel_unit'])
unit=s.simplify(hc*moment*s.I);aunit=s.simplify(ac*moment*(-s.I));models=[]
for r in ['10','126']:
 B=dec(Yc['B'+r]);models.append({'carrier':r,'total':enc(tidy(unit*B*K)),'antiholomorphic':enc(tidy(aunit*s.conjugate(B)*K))})
finish('primary',{'method':'literal_C16_Fourier_routing_alternating_kernel_Gamma_moment','holo_kernel_unit':str(hc),'anti_kernel_unit':str(ac),'finite_moment':str(moment),'color_BK_unit':str(unit),'anti_color_BK_unit':str(aunit),'models':models,'quadratic_kernel_positions':1024,'proper_topologies':1,'ordered_endpoints':2,'all_tangent_directions':328,'color_covariance_and_Casimir_inherited':True},t)
