from data import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');assert P['method']!=R['method']
for k in P:
 if k not in ['method','elapsed_after_imports']:assert P[k]==R[k],k
assert P['holo_kernel_unit']=='-I' and P['anti_kernel_unit']=='I' and P['finite_moment']=='-1/2' and P['color_BK_unit']=='-1/2'
PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';v=dec(read(PK/'frozen_a10_physical_reconciliation/full_primary.json')['vacuum']['VEV'])
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');gy=packed(CAL/'canonical_so10_gauge_yukawa_vertex_poles/replay_v2_tables.json.gz');CI,CH=map(dec,gy['scalar_Casimir_I_H']);K=CI-CH
xi=s.Symbol('xi',real=True);old=packed(CAL/'canonical_so10_fermion_mass_finite_comparison/local_mass_comparison_member.json.gz');positions=0;nz=0;controls={};proj=[]
for j,row in enumerate(P['models']):
 B=dec(Y['B'+row['carrier']]);mat=dec(row['total']);anti=dec(row['antiholomorphic']);zero(mat+B*K/2);zero(anti-s.conjugate(mat))
 for n in ['total','antiholomorphic']:
  mm=dec(row[n]);zero(mm-dec(R['models'][j][n]));positions+=256*328
  dd=mm.todok()
  for (flat,col),co in dd.items():a,b=divmod(flat,16);assert s.simplify(co-dd.get((b*16+a,col),0))==0
 atv=s.Matrix(16,16,list(xi*mat*v));M=s.Matrix(16,16,list(B*v));zero(atv+s.Rational(25,4)*xi*M)
 defect=dec(old['projected_comparisons'][j]['raw_projected_comparison_defect']);target=tidy(atv-defect)
 zero(target-s.Rational(25,2)*xi*s.log(s.Rational(3,2))*M)
 proj.append({'carrier':row['carrier'],'dimensional_iE_at_v':enc(atv),'MFC_raw_diagnostic':enc(defect),'difference_only_NOT_measured_heat_response':enc(target)})
 nz+=len(mat.todok())
 for n,m in {'wrong_same_direction_open_chain':2*mat,'early_internal_hats0':mat,'missing_quadratic_antisymmetrization':mat/2,'extra_open_half':mat/2,'extra_family3':2*mat,'wrong_radial_moment':mat/3,'full45_for_heavy':B*CH/2}.items():controls[n]=controls.get(n,0)+len(tidy(m).todok())
 zero(B*CH*v)
assert all(v>0 for v in controls.values())
recipe={'schema':'HPR1_ROUTING_RECONCILED_SELECTED_DIMENSIONAL_hPP','overall_factor':'g10^2*xi*Y_R/(16*pi^2)','local_tensor':'-(1/2)*B_R*K_scalar','models':P['models'],'projections':proj,'color_inputs_inherited_not_new_45_generator_replay':True,'heat_response_measured':False,'extended_Slavnov_QAP_or_E5A5_qualified':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(recipe,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'routing_reconciled_dimensional_insertion.json.gz').open('xb') as f:f.write(blob)
result={'status':'QUALIFIED_ROUTING_RECONCILED_SELECTED_DIMENSIONAL_hPP_INSERTION','new_quadratic_kernel_witness_positions':1024,'inherited_color_tensor_positions_compared':positions,'total_holomorphic_nonzero_positions':nz,'all_tangent_directions':328,'carriers':2,'proper_topologies':1,'ordered_endpoints':2,'local_dimensional_iE_tensor':'-(1/2)*B_R*K_scalar','dimensional_iE_at_v_126':'-(25/4)*xi*M126','controls_changed_positions':controls,'full45_control_at_v_INSENSITIVE':True,'earlier_HPI_open_chain_sign_accepted':False,'heat_regulator_response_calculated':False,'extended_source_Hessian_QAP_or_E5A5_qualified':False,'authority':'34/39','physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED','artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest(),'elapsed_after_imports':time.perf_counter()-t}
print('RESULT '+json.dumps(result,sort_keys=True),flush=True)
