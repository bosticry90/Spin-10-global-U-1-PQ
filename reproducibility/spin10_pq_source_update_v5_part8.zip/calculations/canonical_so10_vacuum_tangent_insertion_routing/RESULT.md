# A nonzero dimensional tangent insertion, with its routing sign reconciled

The selected local one-loop dimensional iE insertion in the provisional VTS
vacuum-tangent extension is, suppressing g10^2 xi Y_R/(16pi^2),

    R_dim,hPP = -(1/2) B_R K_scalar,
    K_scalar = Cs,I-Cs,H.

Both Yukawa carriers and all328 tangent directions are retained. There are
4352 nonzero holomorphic entries:320 for10 and4032 for126. General symmetric
complex three-family matrices remain factorized. These are coefficients,
not particles, experiments or a completion percentage.

The actual reference-vector projection is, suppressing g10^2/(16pi^2),

    R_dim,126(v) = -(25/4) xi M126,
    R_dim,10(v) = 0.

Receipt SHA256:
649a468157290c71f7c602aadccac2ca25e0ae5135db975b05ab7cd6bd3e8b34.
Status QUALIFIED_ROUTING_RECONCILED_SELECTED_DIMENSIONAL_hPP_INSERTION.
Scientific/director acceptance NOT_PERFORMED; authority34/39 remains unchanged.

## Why the first trial's sign is not accepted

HPI1 completed its three native checks and produced an internal receipt with
the opposite sign. Its sources, outputs, receipt and full captures are all
preserved in canonical_so10_vacuum_tangent_matter_insertion. Its RESULT
explicitly withholds scientific interpretation. Both trial routes shared an
untested conversion from open chains to the external alternating quadratic
kernel. Their agreement could not validate that shared assumption.

The literal compact insertion has ghost momentum q=-r, where r is the S
field momentum in its mixed propagator. After the ordered Gaussian contraction,
the quadratic kernel is E^T G Y-(E^T G Y)^T. Keeping charge conjugation and
this transpose gives a holomorphic unit -i, rather than the trial's +i.
The formal dimensional moment is -1/2, with the analytic hat dimension
continued only after integration. The color covariance reduction then gives
the displayed negative coefficient. No finite parameter was adjusted.

Primary uses explicit SMA charge-conjugation/Clifford matrices and a generic
noncommuting color witness. Replay uses an exterior Gaussian integral,
abstract charge-conjugation transpose rules and an independent Schwinger
variance integral. The new quadratic-kernel witness compares1024 positions.
Both routes subsequently assemble complete tensors from authenticated YCT
covariance and paired VTS Casimir data. The335872 tensor positions compared,
including their zero complement and conjugate chirality, are assembled from
those inherited color inputs; this is not a fresh independent45-generator
color calculation. That distinction avoids repeating the expensive trial.

Controls detect using the same momentum direction, early internal hats0,
omitting the external antisymmetrization, spurious open half/family3, wrong
radial moment and replacing the heavy projector by the full45 Casimir. The
last control changes4320 full tensor entries while remaining invisible at v;
that projected insensitivity is recorded, not hidden.

## What the mass comparison now says

MFC1 independently obtained the raw parent diagnostic

    D126 = -(25/2) xi [log(3/2)+1/2] M126.

Subtracting this from the new dimensional insertion leaves the algebraic
difference +(25/2) xi log(3/2) M126. This is only an algebraic comparison.
It has NOT measured the heat-regulator response or proved the extended
source-Hessian identity in its required domain. In particular, it must not
be relabeled as a calculated heat insertion merely because it resembles a
heat-length logarithm. The raw MFC result remains nonzero and independent
of the finite baseline; it was never an anomaly or obstruction theorem.

The next competent test is the actual ordered G_t R_t M insertion in the
same provisional extension, retaining correlated sources and all relevant
constant tangents. The two-interaction rooted matter tangent and possible
three-interaction constant gauge/auxiliary tangents require explicit support
and sign analysis. The radial integrals alone cannot establish their tensor
weights. First establish the extended source/Hessian and first-variation
domain, or identify the precise missing premise. Do not infer a cancellation
or fit a counterterm from the displayed algebraic target.

For context, cutoff-modified Slavnov identities retain explicit source and
regulator trace contributions in [BRST in the Exact RG](https://arxiv.org/html/1904.08231v3),
sections3.1 and3.5. That framework motivates checking these terms; its
regulator and coefficients are not imported as ToE-Next results.

## Execution and scientific limits

P/R/V completed native0 in114.534170/112.964939/213.080798 seconds after imports.
Their59/58/107 memory samples have private maxima64413696/67555328/71254016B;
these are sampled observations, not measured peaks. Frozen600s,8GiB private,
350MiB launch-floor and16MiB packet caps held. Eight source copies and93/101
preparation/validation bindings are retained. Pre-report packet187240B.
No HPR scientific-worker/controller failure occurred. MFC E4 is authenticated
reuse with root0, steps0/0/0/0/0/2 and historical custodysevenNOTPASS.

Artifact packed SHA256:
94396def456f928f71c109f4e4490f077a42fde9fbef022719365954a756198a.
Artifact raw SHA256:
66553665ac8663f3e6ccab44cbea281430454d53b493bb7aa66abdbff427a53b.

The bare insertion has one proper topology and two fermion orientations in
the declared local nonexceptional Euclidean scope. This does not construct
the heat-side quantum response, full renormalized mass/VEV relation, arbitrary
sources/backgrounds/hats, multiple products/QAP, measure/global phase,
physical vacuum/causal limits, C1, E5/A5 or physical Grand Unification.
The z/h construction remains provisional; no physical scheme, baseline or
new benchmark is adopted. project_state.json, prior adverse physical results,
quartetFAIL, paused flavor, HB1/C5 and historical custody remain unchanged.

The supplied assessments' distinction between mathematical coherence and
physical support remains applicable. Here the AI-capability evidence includes
an explicit limitation: two methods shared a sign interpretation that their
internal checks did not detect. A separate literal-kernel derivation corrected
it. All methods still share action, inherited tensors, software and AI
authorship; this is computational corroboration, not external confirmation.
