# HPR1: reconcile the literal insertion, momentum routing and quadratic kernel

The ongoing HPI1 trial uses open endpoint chains without an explicit
charge-conjugation reconstruction of their external quadratic kernel. A
separate routing check is necessary before interpreting its output. Preserve
that entire trial; its native execution status is distinct from acceptance.

This bounded continuation computes the local dimensional hPP insertion from
the literal compact SMA insertion with all incoming Fourier momenta. With
the S field momentum r, the ghost momentum is q=-r. Extract the alternating
external kernel from the actual Grassmann contraction, rather than assigning
an ordinary open-line sign. Compare an explicit charge-conjugation Clifford
matrix derivation against exterior Gaussian integration and abstract transpose
algebra. Both must derive their answer before reading MFC or HPI results.

Retain the HPI1 field/types/domain and one proper triangle support proof,
including both endpoints. General h spans328 columns; both symmetric complex
family Yukawa carriers remain symbolic. Use the already qualified YCT full45
covariance and VTS paired scalar Casimir kernels to assemble the full images.
Do not repeat HPI1's expensive new45-generator contraction. The shared old
color inputs are explicitly inherited, not independent new color replay.

Freeze8 sources/copies and immutable inputs before P/R/V. Run only after the
HPI1 controller reaches a terminal state, with no overlapping scientific
workers. Each role has600s after imports/8GiB sampledprivate/350MiB available
commit launchfloor/16MiB storedpacket. Preserve any incomplete or incorrect
HPI1 execution separately. New local seals preserve33397 old blobs and include
both new evidence folders. Reuse MFC E4 root0 steps0/0/0/0/0/2; custodysevenNOTPASS.

Ceiling: selected dimensional insertion and explicit routing reconciliation.
No heat response or extended source-Hessian/Slavnov/QAP theorem follows just
by subtracting this insertion from MFC's raw comparison. No baseline or
physical scheme selected; authority34/39 and all protected boundaries remain.
Shared action, old color tensors, software and AI authorship limit assurance.
