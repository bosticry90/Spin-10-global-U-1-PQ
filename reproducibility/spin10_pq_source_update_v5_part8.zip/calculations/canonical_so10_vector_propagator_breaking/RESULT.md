# VPR1 qualified: all 34 remaining propagator-response profiles measured

Receipt SHA256
2afc7a0a9707a192542f7a71e96e71d20af56d3f29c26f4bd22cbe112071761f.
Disposition ALL34_REMAINING_ORDERED_RESPONSES_MEASURED. This is measured
input coverage,not a whole-vector cancellation or full restoration claim.
State113/scientific authority34of39 unchanged.

| Complete family | Profiles g4/g3 | Nonzero g4 entries | Nonzero g3 entries |
| --- | --- | --- | --- |
| Ghost edge | 8/4 | 21312 | 19968 |
| Physical cubic-vector edge | 8/4 | 20832 | 19008 |
| Mixed vector/auxiliary edge | 8/2 | 21696 | 7360 |

Counts are per chirality,not independent experiments. All6220800 output
positions and8294400 basis positions,including zeros,agree between the
ordered-generator and scalar-Lie routes. Both use the qualified action,
regulator,charts and software. Actual right generators give right=-left.T;
all totals are anti-Hermitian;all12 H tensor remainders vanish for each
family and each coupling order. No physical width or flavor value selected.

The primary full-D inverse-block proof and replay projector/Berezin proof
precede model contractions. The ghost insertion retains A=UA-UC. The
physical cubic vertex is the action-derived-i g f V;the mixed vertex is
-i g Phi. Raw LambdaBB coefficients are complex in their canonical frame;
UL/Qi transport produces1472 real plane entries. Both mixed placements
are retained with opposite free BL/LB signs and GLL=0. No proper-vertex
UV pole was substituted for a finite insertion unit.

In the notation of DERIVATION,with C=WV,

    Lghost4=J C A [T,T], Lghost3=-xi J H A [T,T],
    Lphy4=-(I0-J) f C [T,T], Lphy3=xi(I0-J) f H [T,T],
    Lmixed4=-(I0-J)M1I-J M1W+J M2W,
    Lmixed3=-xi J M2H.

I0=-1/2,J=-1/12;control moments IB=-1/3,JB=-1/16. Main moments are reused
only after pointwise sewing proves their applicability. Metadata
new_radial_integrations0 means no new main-kernel integration;the control
moments are analytically evaluated by both Gaussian/Schwinger routes.

Sensitive controls:omit UC changes20192 ordinary and7360 auxiliary ghost
entries;omit first/second mixed placement changes19136/20192 ordinary
entries. Auxiliary first mixed placement is structurally absent(GLL=0),
so that omission control is correctly insensitive. Early-bar controls
change21312 ghost-g4,21984 physical-g4,19008 physical-g3 and21696 mixed-g4
entries. Ghost/mixed auxiliary early-bar controls are insensitive. Omitting
either E endpoint,extra half,wrong right sign or reversed cubic/mixed
Wick sign changes the nonzero tested kernels. Controls do not validate
shared physical premises.

Original primary FAILED(native1) before any model table at its auxiliary
early-bar control. It compared Vbar*kbar with the formula for Vfull*kbar.
CORRECTION_V2 distinguishes them. Original source/copies/preparation/full
capture/controller failure remain immutable;replay/gate were not launched
for that original run. V2 changes the diagnostic only,not the physical
kernel,targets,acceptance requirements or resource limits.

Commands:python -B calculations/canonical_so10_vector_propagator_breaking/
run.py(original failed);run_v2.py(completed sequential P/R/gate). Successful
elapsed afterimports471.4215139/16.9338277/71.5281017s;native0 each. Each
600s cap,8GiB sampled private cap,350MiB launch floor,16MiB packet cap.
Samples238/11/37,max542744576/310165504/390496256B;sampled maxima are not
continuous memory peaks. Original failure10 samples,max58126336B.
Fourteen frozen source copies;343/361/369 input bindings across original,
V2 and validation preparations. Full captures also reside in the external
vector-propagator-breaking-v1-2026-10-23 control directory.

Primary packed SHA1d1a1ea27bdb4207e38e5eabea598f19a628b5f9e5df6414616872522c1491c4,
raw348daf628fb032522762498fc751e433efd6ae05c7fb76a18cbab8e22e13160a.
Replay packedcc6c84035a2d9241d776d4187e54cfcd913f7d1da5ed689502ce7081a734cb62,
raw02a50fd339593094b96bae7c264237c1241f4a5ce92dbcaa0745a1cb52b0b6d4.

Fresh E4 native0,declared step exits0,0,0,0,0,2. Historical custody remains
exit2/seven NOTPASS,not global PASS. V2 authenticates this same-goal-turn
readiness and adds a fresh byte preflight. No old evidence/state edited.

Scientific significance:the complete42 internal-ghost vector inventory now
has all five measured response families(contact2,fermion6,ghost12,physical
12,mixed10). MDS1's20 paired external-ghost local zeros remain separate.
The cheapest justified next test is exact-once full42 assembly and a
comparison with the fixed CFC/source images. Quantum workers did not read
those structured targets. A remainder must be preserved;bosonic-source
matter Euler companions and other coupled obligations remain distinct.

No whole finite Slavnov/QAP/products/measure/phase,physical chiral scheme,
massive C1,E5/A5,physical unification or gravity result follows. The two
adverse scalar configurations,quartetFAIL,flavorpause,HB1/C5blocks and
custody limitations remain. No invariant finite constant is fixed or
identified with another. Shared action,data,software and AI authorship are
computational corroboration,not independent scientific confirmation.
