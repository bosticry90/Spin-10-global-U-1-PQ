"""VPR1 Berezin ghost inverse,projector response,Schwinger,scalar Lie sewing."""
from data import *
start=begin('replay');P=packed(HERE/'qualified_action_inputs.json.gz');G=P['GR'];assert not P['full_proper_vertex_quantum_outputs_included']
# Four Grassmann coordinates,a0 C0 a1 C1. Integrate exp(-a K C)
# without introducing a closed ghost-loop sign in this open inverse edge.
def wedge(a,b):
 out=defaultdict(lambda:sy.S.Zero)
 for ka,x in a.items():
  for kb,y in b.items():
   if not ka&kb:out[ka|kb]+=(-1)**sum((kb&((1<<i)-1)).bit_count() for i in range(4) if ka&(1<<i))*x*y
 return {k:sy.expand(v) for k,v in out.items() if sy.expand(v)}
def word(seq):
 z={0:sy.S.One}
 for i in seq:z=wedge(z,{1<<i:1})
 return z
f0,f1,lam,m00,m01,m10,m11=sy.symbols('f0 f1 lambda m00 m01 m10 m11');KM=sy.diag(f0,f1)+lam*sy.Matrix([[m00,m01],[m10,m11]]);action={}
for i in range(2):
 for j in range(2):
  for q,z in word([2*i,2*j+1]).items():action[q]=action.get(q,0)+KM[i,j]*z
term={0:sy.S.One};exp=dict(term)
for n in range(1,3):
 term={k:-v/n for k,v in wedge(term,action).items()}
 for k,v in term.items():exp[k]=sy.expand(exp.get(k,0)+v)
for i in range(2):
 for j in range(2):
  num=wedge(word([2*i+1,2*j]),exp).get(15,0);value=sy.cancel(num/exp[15]);assert sy.cancel(value-KM.inv()[i,j])==0
  assert sy.simplify(sy.diff(value,lam).subs(lam,0)+sy.Matrix([[m00,m01],[m10,m11]])[i,j]/([f0,f1][i]*[f0,f1][j]))==0
# Independent projector algebra. In e,k coordinates, k.e=z and k.k=r.
# Matrix acts on vector x e+y k; both offdiagonal placements remain ordered.
r,z,u,w,aa,bb,xi,sg=sy.symbols('r z u w a b xi sigma',nonzero=True)
def B(width,x,y):return x/r,(y+(width-1)*(x*z+y*r)/r)/r
def VB(x,y):return -x*z-y*r,2*x*z+y*r-x*z
# Explicitly V(x e+y k)=(2z x-y r)e+(-x z+2z y-y z)k
# for V=2z I-k e.T-e k.T and e.e=1.
def VV(x,y):return 2*z*x-x*z-y*r,-x+z*y
vx,vy=VV(0,1);assert vx==-r and vy==z
bx,by=B(u,vx,vy);assert sy.simplify(bx+1)==sy.simplify(by-z/r)==0
# Ordinary mixed response: first placement -GBB Gamma_BL GLB,
# second -GBL Gamma_LB GBB,applied before angular projection.
x1,y1=B(u,-aa,0);x2,y2=0,bb*w*z/r**2
assert sy.simplify(x1+aa/r)==0 and sy.simplify(y1+y2-(-aa*(u-1)+bb*w)*z/r**2)==0
# Auxiliary first placement is absent because GLL=0.
assert sy.simplify((-xi*bb*z/r**2)-(-xi*bb*z/r**2))==0
eps,h=sy.symbols('epsilon h');D=4-2*eps
mom={'I0':sy.limit((h*sy.gamma(2-D/2)/(2*sy.factorial(2))).subs(h,-2*eps),eps,0),'J':sy.limit((h*sy.gamma(2-D/2)/(4*sy.factorial(3))).subs(h,-2*eps),eps,0),'IB':sy.limit((h*4*sy.gamma(2-D/2)/(4*sy.factorial(3))).subs(h,-2*eps),eps,0),'JB':sy.limit((h*(4+2)*sy.gamma(2-D/2)/(8*sy.factorial(4))).subs(h,-2*eps),eps,0)}
I0,J,IB,JB=[mom[n] for n in ['I0','J','IB','JB']];assert str(I0)==P['I0'] and str(J)==P['J'] and str(IB)==P['IB']
jets={n:tensorrows(rows) for n,rows in G['plane_jets'].items()};V=cleanq({k:sub(jets['a'].get(k,Z),jets['B'].get(k,Z)) for k in set(jets['a'])|set(jets['B'])});A=cleanq({k:sub(jets['a'].get(k,Z),jets['c'].get(k,Z)) for k in set(jets['a'])|set(jets['c'])});H=tensorrows(G['plane_H']);UL=dec(G['raw_aux_map']);Qi=mul(dec(G['raw_Gca']),trans(inv(UL)));zero(minus(mul(dec(G['C3_chart']),Qi),ident(45)));zero(minus(UL,dec(P['auxiliary_UL_replay'])))
Y=P['YR'];T=list(map(dec,Y['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];HF=dec(Y['H_new']);PH=mul(HF,trans(HF));W=plus(scale(ident(45),Q('xi')),scale(PH,Q('eta_H-xi')));Phi=tensorrows(P['plane_U_B_replay']);assert all(conj(x)==x for x in Phi.values())
C={}
for (r,a,c),v in V.items():
 for b in range(45):
  if (b,r) in W.d:putq(C,(b,a,c),prod(W.d[b,r],v))
C=cleanq(C);fs=defaultdict(list)
for b,a,e,v in P['plane_f']:fs[b,a].append((e,Q(v)))
adj={n:{} for n in ['G4','G3','P4','P3','M1I','M1W','M2W','M2H']}
byanti={};byvector={}
for tag,co in [('C',C),('H',H),('V',V)]:
 x=defaultdict(list);y=defaultdict(list)
 for (r,a,c),v in co.items():x[a].append((r,c,v));y[r].append((a,c,v))
 byanti[tag]=x;byvector[tag]=y
for (d,t,a),v in A.items():
 for n,tag in [('G4','C'),('G3','H')]:
  for b,c,co in byanti[tag][a]:
   for e,f in fs[b,t]:putq(adj[n],(c,d,e),prod(II,prod(v,prod(co,f))))
for s,t,d,v in P['plane_f']:
 for n,tag in [('P4','C'),('P3','H')]:
  for a,c,co in byvector[tag][t]:
   for e,f in fs[s,a]:putq(adj[n],(c,d,e),prod(II,prod(Q(v),prod(co,f))))
for (r,b,d),v in Phi.items():
 for a,c,co in byvector['V'][r]:
  for e,f in fs[b,a]:putq(adj['M1I'],(c,d,e),prod(II,prod(v,prod(co,f))))
  for bb in range(45):
   if (bb,b) in W.d:
    for e,f in fs[bb,a]:putq(adj['M1W'],(c,d,e),prod(II,prod(v,prod(co,prod(W.d[bb,b],f)))))
 for n,tag in [('M2W','C'),('M2H','H')]:
  for a,c,co in byvector[tag][b]:
   for e,f in fs[r,a]:putq(adj[n],(c,d,e),prod(II,prod(v,prod(co,f))))
adj={n:cleanq(v) for n,v in adj.items()}
def sew(co,ts):
 out={}
 for (c,d,e),v in co.items():putm(out,(c,d),ts[e],v)
 return out
basis={s:{n:sew(co,ts) for n,co in adj.items()} for s,ts in [('left',T),('right',U)]};answers={}
for side,B in basis.items():
 answers[side]={'ghost':{'4':tabcomb([(B['G4'],Q(J))]),'3':tabcomb([(B['G3'],Q(-WM*J))])},'physical':{'4':tabcomb([(B['P4'],Q(-(I0-J)))]),'3':tabcomb([(B['P3'],Q(WM*(I0-J)))])},'mixed':{'4':tabcomb([(B['M1I'],Q(-I0+J)),(B['M1W'],Q(-J)),(B['M2W'],Q(J))]),'3':tabcomb([(B['M2H'],Q(-WM*J))])}}
# Actual witness classifier independent of VCT's stored partition labels.
remaining=defaultdict(list)
for st in packed(CAL/'canonical_so10_matter_degreezero_support/support_tables.json.gz')['partitions']['cBPP']['remaining_internal_ghost_candidates']:
 q=json.loads(st);vv=[json.loads(n) for n in q[0]];v=vv[next(p[0] for p in q[1] if p[1]=='B')];roles=Counter(k for k,j in v[1])
 if v[0]=='PHY':assert roles=={'B':3};name='physical_vector_edge'
 elif roles=={'B':2,'L':1}:name='GF_mixed_edge'
 elif roles=={'B':1,'a':1,'c':1}:name='ghost_edge'
 else:continue
 remaining[name].append(st)
remaining={n:sorted(v) for n,v in remaining.items()};assert sum(map(len,remaining.values()))==34
print('STAGE REPLAY_LIE_RESPONSES_COMPLETE',flush=True)
finish('replay',{'method':'Berezin_inverse_projectors_Schwinger_scalar_Lie','moments':{n:str(v) for n,v in mom.items()},'response_remainders':'0','ghost_inverse_response_sign':'-','Phi':[[*k,textq(v)] for k,v in sorted(Phi.items())],'Qi':enc(Qi),'UL':enc(UL),'W':enc(W),'A':[[*k,textq(v)] for k,v in sorted(A.items())],'V':[[*k,textq(v)] for k,v in sorted(V.items())],'weighted_C':[[*k,textq(v)] for k,v in sorted(C.items())],'basis':{s:{n:table(v) for n,v in d.items()} for s,d in basis.items()},'left':{f:{o:table(v) for o,v in orders.items()} for f,orders in answers['left'].items()},'right':{f:{o:table(v) for o,v in orders.items()} for f,orders in answers['right'].items()},'Lie_coefficients':{n:[[*k,textq(v)] for k,v in sorted(co.items())] for n,co in adj.items()},'supported_witnesses':remaining,'newly_measured_profiles':34,'remaining_vector_profiles_unmeasured':0,'new_radial_integrations':0,'control_moments_analytically_evaluated':True},start)
