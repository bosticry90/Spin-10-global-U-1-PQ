# VPR1 diagnostic correction before any model output

Original primary native1 failed its auxiliary early-bar diagnostic at
line39. It used Vbar*kbar while the frozen expected polynomial concerns
Vfull*kbar. These are different controls. The former is transverse to
full k and gives the width-independent (IB-J)xi=-xi/4;the latter retains
the hatted mismatch and gives-xi(11+u)/48. The ordinary early-endpoint
check,physical full-D response and all preceding assertions passed.

No primary table/result was produced;replay and verifier were not launched.
Preserve original sources,copies,preparation,full primary/controller failure
captures and E4 readiness. No scientific coefficient or acceptance is
inferred from this failure. V2 replaces only that diagnostic's cubic
matrix with the full matrix. It retains the same physical response,
moments,target34,all coefficient/H/reality tests and resource caps.
Replay/gate are copied under new filenames for complete output custody.
No original source or input is modified. Original readiness is fresh this
goal turn and reused,not rerun/relabelled. Freeze V2 before execution.
