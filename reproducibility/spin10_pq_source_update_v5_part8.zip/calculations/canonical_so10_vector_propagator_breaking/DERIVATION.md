# VPR1: ordered inverse responses before finite extraction

All formulas below are frozen hypotheses until the two workers and gate
complete. GTT gives E_C/current/mixed-fermion numerator
+hatk2 gamma_bar_nu Tb Tt and E_S gives its negative reversed product.
Its three-vertex cumulants are both+1. The insertion is an inverse
variation,not a new closed ghost loop or an extra half. Write K2=k.k,
sigma=+1/-1 for the E orientations. Bosonic momentum p=-sigma k:

    GBB(u)=[I+(u-1)kk.T/K2]/K2,
    GBL=+sigma k/K2, GLB=-sigma k.T/K2, GLL=0.

The other endpoint ordinary vertex is -i sigma g V k,V=UA-UB;
auxiliary vertex is+i xi g H. At an external B insertion into the ghost
inverse,the differentiated ghost is internal:deltaK=-i sigma g A k_mu,
A=UA-UC. Its inverse response is+i sigma A k_mu/K2². This fixes its color
order A[d,t,a] through <C_t a_i>,not a transposed ghost tensor. No new
closed-loop ghost minus sign. Independent Berezin integration checks it.

Let C_ba,c=sum_r W_br V_ra,c,W=eta_H PH+xi PM. Moments in16pi2 units:
I0=FP int hatk2/(K2+m2)^3=-1/2,
J delta_mu,nu=FP int hatk2 kbar_mu kbar_nu/(K2+m2)^4=-delta/12.
Full-D sewing precedes barred external projection. Every new numerator
reduces to I0 and J without a closed D trace. Auxiliary m is local UV
rearrangement only. Denominator differences containing m² are convergent
with an explicit hat dimension and vanish in the inherited analytic domain.

Ghost response ordinary EC is+w k_mu k_nu/K2³,auxiliary is-xi
k_mu k_nu/K2³;ES reverses sign. Hence

    Lghost4=J sum C_ba,c A_d,t,a [Tb,Tt],
    Lghost3=-xi J sum H_ba,c A_d,t,a [Tb,Tt].

Actual FCV action/Wick vertex is -i sigma g f_std times
V_mu,alpha,beta=2k_mu delta_alpha,beta-k_alpha delta_beta,mu
-k_beta delta_mu,alpha. V k=-K2 P_T e_mu;current-side width drops.
The ordinary EC is-w P_T e_mu/K2,auxiliary EC is+xi P_T e_mu/K2:

    Lphy4=-(I0-J) sum f_std C_ta,c [Ts,Ta],
    Lphy3=+xi(I0-J) sum f_std H_ta,c [Ts,Ta].

Phi_r,b,d is the real plane FAV U[B],already B differentiated. It is
obtained by UL on raw Lambda and Qi=Q^-1 on BOTH vectors;raw coordinates
can be complex. Actual Euclidean mixed vertex is-i g Phi with opposite
free BL/LB signs retained. In the Lorentz block proof use independent a,b:
deltaK=[[0,-ia e_mu],[-ib e_mu.T,0]]. Then sigma[-G(u)deltaK G(w)]
times ordinary column[-i sigma k;0] has B block

 sigma/K2[-a e_mu+(-a(u-1)+bw)k k_mu/K2];

times auxiliary column[0;i xi] gives -sigma xi b k k_mu/K2².
The two mixed placements must not be merged before this calculation.
Define M1I=sum Phi_r,b,d V_ra,c[Tb,Ta],
M1W=sum Phi_r,s,d W_bs V_ra,c[Tb,Ta],
M2W=sum Phi_b,t,d C_ta,c[Tb,Ta],
M2H=sum Phi_b,r,d H_ra,c[Tb,Ta]. Then

    LGF4=-(I0-J)M1I-J M1W+J M2W,
    LGF3=-xi J M2H.

Each commutator comes from two ordered E products;replay substitutes
[Tb,Ta]=i f_ba^e Te only after separately deriving its orientation unit.
Actual right generators U=-T.T yield right=-left.T. No antisymmetry of C
or of Phi in its auxiliary index is imposed.

Control moments IB=-1/3 and JB=-1/16 are obtained independently from
Gaussian/Schwinger hatk2*bark2 and hatk2*bark2*kbar_mu*kbar_nu tensors.
An early-barred internal GF momentum changes ghost Jw to J+JB(w-1).
Physical cubic ordinary EC changes to
-w IB+(2-u)J+(u+w-2)JB=(13w+u-2)/48;full result5w/12.
Auxiliary EC changes to-xi(11+u)/48 instead of-5xi/12.
Mixed first placement changes -(I0-J)I-JW to-(IB-JB)I-JB W;
second changes JW to(J-JB)I+JB W. Its auxiliary control is insensitive.
The exact response probes test these full-D versus early-bar formulas.
Controls are diagnostic alternatives,not new physical prescriptions.
