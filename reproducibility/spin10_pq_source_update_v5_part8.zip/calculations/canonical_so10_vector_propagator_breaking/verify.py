"""VPR1 complete coefficient/zero complement,orientation,covariance gate."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');A=packed(HERE/'qualified_action_inputs.json.gz')
for k in ['moments','response_remainders','ghost_inverse_response_sign','Phi','Qi','UL','W','A','V','weighted_C','basis','left','right','supported_witnesses','newly_measured_profiles','remaining_vector_profiles_unmeasured','new_radial_integrations','control_moments_analytically_evaluated']:assert P[k]==R[k],k
assert P['moments']=={'I0':'-1/2','J':'-1/12','IB':'-1/3','JB':'-1/16'} and P['response_remainders']=='0' and P['ghost_inverse_response_sign']=='-'
assert not P['quantum_coefficients_assigned_from_counterterm'] and not R['quantum_coefficients_assigned_from_counterterm']
T=list(map(dec,A['YR']['Tminus']));HF=dec(A['YR']['H_new']);f=defaultdict(list)
for a,b,e,z in A['plane_f']:f[a,b].append((e,Q(z)))
counts={};compared=0;hc={}
for family in ['ghost','physical','mixed']:
 counts[family]={};hc[family]={}
 for power in ['4','3']:
  L=fromtable(P['left'][family][power]);RR=fromtable(P['right'][family][power]);counts[family][power]={'left':tabnz(L),'right':tabnz(RR)}
  for c in range(45):
   for d in range(45):
    l=L.get((c,d),Mat(16,16));r=RR.get((c,d),Mat(16,16));zero(plus(r,trans(l)));zero(plus(l,trans(star(l))));compared+=512
    for v in l.d.values():assert all(k[0]>=0 and k[1]>=0 for k,z in v)
  hc[family][power]=[]
  for u in range(12):
   th=Mat(16,16);fh=defaultdict(lambda:Z)
   for a in range(45):
    z=HF.d.get((a,u),Z)
    if z:
     th=plus(th,scale(T[a],z))
     for b in range(45):
      for e,v in f[a,b]:fh[b,e]=add(fh[b,e],prod(z,v))
   inverse=defaultdict(list)
   for (a,b),z in fh.items():
    if z:inverse[b].append((a,z))
   var={}
   for (c,d),m in L.items():
    if not m.d:continue
    putm(var,(c,d),minus(mul(th,m),mul(m,th)),neg(II))
    for a,v in inverse[c]:putm(var,(a,d),m,neg(v))
    for a,v in inverse[d]:putm(var,(c,a),m,neg(v))
   n=tabnz(var);assert n==0,(family,power,u,n);hc[family][power].append(n)
print('STAGE ALL_COEFFICIENTS_AND_H_TESTS',counts,flush=True)
profiles={};whole=[]
for name,expected in [('ghost_edge',{'4':8,'3':4}),('physical_vector_edge',{'4':8,'3':4}),('GF_mixed_edge',{'4':8,'3':2})]:
 rows=P['supported_witnesses'][name];assert rows==sorted(A['partition'][name]);orders=Counter(str(json.loads(w)[5]) for w in rows);assert orders==expected;whole+=rows;profiles[name]={'total':len(rows),'orders':dict(orders)}
assert len(whole)==len(set(whole))==34 and not set(whole)&set(A['partition']['contact']+A['partition']['fermion_edge'])
# Model-sensitive early-bar diagnostics;their scalar units were derived
# from full-dimensional probes before the gate reads any model results.
B={n:fromtable(v) for n,v in P['basis']['left'].items()};W=dec(P['W']);wr=rowmaps(trans(W));V=tensorrows(P['V']);H=tensorrows(A['G']['plane_H']);byf=defaultdict(list)
for s,t,d,z in A['plane_f']:byf[t].append((s,d,Q(z)))
@lru_cache(maxsize=2025)
def comm(b,a):return minus(mul(T[b],T[a]),mul(T[a],T[b]))
current={}
for tag,co in [('4',V),('3',H)]:
 dd={}
 for (t,a,c),z in co.items():
  for s,d,v in byf[t]:
   for b,w in wr[s]:putm(dd,(c,d),comm(b,a),prod(z,prod(v,w)))
 current[tag]=dd
one=lambda tab:{k:at_one(v) for k,v in tab.items()}
J=Q('-1/12');JB=Q('-1/16');IB=Q('-1/3');early={}
early['ghost4']=tabcomb([(one(B['G4']),sub(J,JB)),(B['G4'],JB)])
early['physical4']=tabcomb([(B['P4'],Q('13/48')),(current['4'],Q('1/48')),(one(B['P4']),Q('-1/24'))])
early['physical3']=tabcomb([(B['P3'],Q('-11*xi/48')),(current['3'],Q('-xi/48'))])
early['mixed4']=tabcomb([(B['M1I'],neg(sub(IB,JB))),(B['M1W'],neg(JB)),(one(B['M2W']),sub(J,JB)),(B['M2W'],JB)])
controls=P['controls']
for family,power in [('ghost','4'),('physical','4'),('physical','3'),('mixed','4')]:
 controls[family+power]['premature_barred_internal_contraction']=tabnz(tabminus(fromtable(P['left'][family][power]),early[family+power]));assert controls[family+power]['premature_barred_internal_contraction']>0
controls['ghost3']['premature_barred_internal_contraction']=0;controls['mixed3']['premature_barred_internal_contraction']=0
for k,v in controls.items():
 assert v['extra_half']==counts[k[:-1]][k[-1]]['left']
 for name,n in v.items():assert isinstance(n,int) and n>=0
assert all(controls['ghost'+o]['omit_UC']>0 for o in ['4','3'])
assert controls['mixed4']['omit_first_mixed_placement']>0 and controls['mixed4']['omit_second_mixed_placement']>0
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_VECTOR_PROPAGATOR_MATTER_BREAKING_FAMILIES','disposition':'ALL34_REMAINING_ORDERED_RESPONSES_MEASURED','elapsed_after_imports':time.perf_counter()-start,'profiles_measured':34,'families':profiles,'remaining_vector_profiles_unmeasured':0,'coefficient_positions_compared':compared,'basis_matrix_positions_compared':8*2*45*45*256,'nonzero_counts':counts,'all12_H_tensor_remainders':hc,'right_plus_left_transpose_and_antiHermitian_remainders':0,'moments':P['moments'],'mixed_plane_coefficients':len(P['Phi']),'oriented_counts':P['oriented_counts'],'controls':controls,'new_radial_integrations':0,'control_moments_analytically_evaluated':True,'quantum_coefficients_assigned_from_counterterm':False,'whole_vector_or_full_restoration_QAP_measure_phase_massiveC1_E5A5_unification_qualified':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
