"""VPR1 authenticated action-only restriction,fresh readiness,immutable freeze."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PRED=CAL/'canonical_so10_vector_fermion_edge_breaking'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/vector-propagator-breaking-v1-2026-10-23')
BASE='a147a8f4b25e25e5c4e9b7db98b87066b5dbe235';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'validation_preparation.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==31815
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
for n in ['validation_receipt.json','verify_capture.json','RESULT.md','validation_preparation.json']:add(PRED/n)
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V532.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
for folder,names in [('canonical_so10_fermion_auxiliary_gauge_vertex',['primary_v2_tables.json.gz','replay_tables.json.gz','validation_receipt.json','DERIVATION.md']),('canonical_so10_fermion_cubic_vector_vertex',['primary_v3_tables.json.gz','validation_receipt.json','DERIVATION.md'])]:
 for n in names:add(CAL/folder/n)
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
# Restrict qualified old packets before workers. No new quantum coefficient
# is computed here. Both original files remain authenticated and immutable.
G=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/primary_tables.json.gz');GR=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/replay_tables.json.gz');F=packed(CAL/'canonical_so10_fermion_auxiliary_gauge_vertex/primary_v2_tables.json.gz');FR=packed(CAL/'canonical_so10_fermion_auxiliary_gauge_vertex/replay_tables.json.gz');C=packed(CAL/'canonical_so10_fermion_cubic_vector_vertex/primary_v3_tables.json.gz');Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');YR=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');V=packed(CAL/'canonical_so10_vector_contact_breaking/primary_tables.json.gz');VF=packed(PRED/'primary_tables.json.gz')
packet={'schema':'VPR1_QUALIFIED_ACTION_RESTRICTION','G':{k:G[k] for k in ['plane_V','plane_A','plane_H','C3_chart','raw_Gca','raw_aux_map','cumulant_units']},'GR':{k:GR[k] for k in ['plane_jets','plane_H','C3_chart','raw_Gca','raw_aux_map','cumulant_units']},'Y':{k:Y[k] for k in ['Tminus','H_new']},'YR':{k:YR[k] for k in ['Tminus','H_new']},'raw_U_B':F['raw_U']['B'],'plane_U_B_replay':FR['plane_U']['B'],'auxiliary_UL':F['auxiliary_UL'],'auxiliary_UL_replay':FR['auxiliary_UL'],'mixed_Wick_phase':F['Lorentz_Wick_phase'],'cubic_Wick_phase':C['cubic_Wick_phase'],'plane_f':packed(CAL/'canonical_so10_ghost_triangle_field_insertion/qualified_reference_inputs.json.gz')['reference_fields']['plane_f'],'partition':V['partition'],'I0':V['I0'],'J':V['J'],'IB':VF['IB_reused'],'full_proper_vertex_quantum_outputs_included':False}
with (HERE/'qualified_action_inputs.json.gz').open('xb') as f:f.write(gzip.compress((json.dumps(packet,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
add(HERE/'qualified_action_inputs.json.gz')
with (CONTROL/'readiness.jsonl').open('xb') as out,(CONTROL/'readiness_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_check.py'),'e4'],cwd=ROOT,stdout=out,stderr=err)
assert r.returncode==0
dump(CONTROL/'readiness_result.json',{'command':['python','-B','tools/research_check.py','e4'],'native_exit':r.returncode,'fresh_command':True,'scientific_replay_requested':False,'custody_expected_exit':2,'custody_expected_unresolved':7,'scientific_acceptance':'NOT_PERFORMED'})
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:add(CONTROL/n)
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and d['state_sha256']==STATE and d['files_written']==0 and not d['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'VPR1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('VPR1_FROZEN',len(bind),'bindings',flush=True)
