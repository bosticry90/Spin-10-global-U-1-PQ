# VPR1: remaining 34 ordered vector-propagator profiles

Base a147a8f4b25e25e5c4e9b7db98b87066b5dbe235/main,31815 tracked
blobs. Live AGENTS standing delegation. State113/34of39 unchanged.
Whole Spin(10)xPQ ACTIVE/incomplete; previous bounded VCT1/VFE1 qualified.

Question: determine the complete ghost-edge12(8g4+4g3), physical-vector
edge12(8g4+4g3), GF-mixed-edge10(8g4+2g3) zero-jet cBPP coefficients.
These are the remaining34 of MDS1's42 internal-ghost vector profiles.
Together with the contact2 and fermion-edge6, they permit a later whole
vector comparison. The separate20 paired external-ghost local zeros are
already qualified,not newly measured here. No partial sum is restoration.

Use actual unintegrated GTT1 inverse variations -G deltaK G, the physical
FCV1 cubic action vertex and FAV1 differentiated LambdaBB density. No
proper-vertex pole units are imported. Restricted action packet contains
jets,charts,vertices,structure constants and normalization moments only;
it excludes earlier quantum proper-vertex coefficients. Authenticate full
source packets before restricting;deny them and CFC/MSP targets in workers.
Primary recomputes the mixed tensor from complex raw coordinates;replay
uses the independently qualified real plane tensor. Do not assert raw
coordinate reality. Raw U is already differentiated in both B slots.

Same frozen Euclidean one-loop mass-independent nonexceptional analytic
Feynman domain as GTT/VCT/VFE,external physical hats0,background0. All45
ghosts and external B directions,16x16 color matrices,both chiralities,
family I3,no extra3 or Nambu half. eta_H and xi remain independent real
symbols,nonnegative polynomial powers. Positive-dimensional/massive,
background,phase,measure,QAP and physical IR/vacuum limits are separate.

Primary: exact full-D mixed block inverse response and physical cubic
contraction before Gaussian moments;direct ordered generator products.
Replay: Grassmann Gaussian ghost inverse,projector block algebra and
Schwinger moments;scalar Lie-tensor contractions before generators.
Reuse qualified GTT mixed-fermion/E chain since these insertions change
only bosonic/ghost edges. Do not Taylor-differentiate a renormalized or
already integrated functional. A=UA-UC retains internal ghost derivative.

Expected: all34 witnesses partitioned exactly once;phases and moments;
both g orders and every zero position independently equal;actual right
generators give right=-left.T;anti-Hermitian totals;all12 H tensor tests.
Controls omit each E or GF mixed placement,UC,physical cubic Wick sign,
mixed Wick phase,extra half,wrong right transpose and early-barred
contraction. Report insensitive controls honestly. Unitwidth is a
counterfactual check,not an adopted gauge. No unknown loop fitted.

Freeze eight sources/copies,input hashes,record and derivation before
scientific workers. Sequential P/R/gate,each600s after imports,8GiB sampled
private cap,350MiB available commit launch floor,16MiB packet cap. Current
fresh E4 command and byte preflight fully captured;custody2/seven NOTPASS
is expected and is not PASS. Preserve first failure and unfinished output;
new versioned corrections only,never mutate frozen evidence. No silent
resource expansion,truncation or missing-family zero assignment.

Ceiling: three measured propagator-response families,not complete coupled
Slavnov/QAP/products/measure/phase,physical chiral prescription,massive C1,
E5/A5 or unification. No action/counterterm physically adopted. Free
zpsi,z10,z126,b0,kappa,zeta,u10,u126 stay distinct. Scalar warnings,quartet
FAIL,flavorpause,HB1/C5blocks,custody remain. Shared physics,charts,data,
software and AI author;not independent scientists. No agents,branch,
worktree,publication,outreach,push or state change. If qualified,continue
the smallest exact-once full42+20zero comparison with fixed CFC images;
preserve any remainder and possible bosonic-source Euler companions.
