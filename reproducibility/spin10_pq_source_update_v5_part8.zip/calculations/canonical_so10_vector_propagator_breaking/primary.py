"""VPR1 full-dimensional inverse responses,raw action transport,ordered colors."""
from data import *
start=begin('primary');P=packed(HERE/'qualified_action_inputs.json.gz');assert not P['full_proper_vertex_quantum_outputs_included']
G=P['G'];T=list(map(dec,P['Y']['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];HF=dec(P['Y']['H_new']);W=plus(scale(ident(45),Q('xi')),scale(mul(HF,trans(HF)),Q('eta_H-xi')));wr=rowmaps(trans(W))
V=tensorrows(G['plane_V']);A=tensorrows(G['plane_A']);H=tensorrows(G['plane_H']);C=defaultdict(lambda:Z)
for (r,a,c),z in V.items():
 for b,w in wr[r]:putq(C,(b,a,c),prod(z,w))
C=cleanq(C);UL=dec(G['raw_aux_map']);zero(minus(UL,dec(P['auxiliary_UL'])));Qi=inv(dec(G['C3_chart']));qr=rowmaps(Qi);ur=rowmaps(UL);Phi={}
for r,b,d,z in P['raw_U_B']:
 for rr,x in ur[r]:
  for bb,y in qr[b]:
   for dd,v in qr[d]:putq(Phi,(rr,bb,dd),prod(Q(z),prod(x,prod(y,v))))
Phi=cleanq(Phi)
assert Phi and all(conj(z)==z for z in Phi.values())
for (r,b,d),z in Phi.items():assert z==Phi.get((r,d,b),Z)
assert P['mixed_Wick_phase']==['-I']*4 and P['cubic_Wick_phase']=='-I' and G['cumulant_units']==['1','1']
# Current-side physical spin chain is the qualified GTT arbitrary-hat
# identity. These responses act only on its bosonic/ghost factors.
k=sy.Matrix(sy.symbols('k0:6'));K2=(k.T*k)[0];kb=sy.Matrix(list(k[:4])+[0,0]);B2=(kb.T*kb)[0];u,w,a,b=sy.symbols('u w a b');xi=sy.Symbol('xi');eye=sy.eye(6);PT=eye-k*k.T/K2
def simp(m):return m.applyfunc(lambda z:sy.cancel(sy.expand(z)))
def bb(width):return (eye+(width-1)*k*k.T/K2)/K2
def block(width,sigma):return bb(width).row_join(sigma*k/K2).col_join((-sigma*k.T/K2).row_join(sy.zeros(1)))
for sigma in [1,-1]:
 for mu in range(4):
  e=eye[:,mu];vc=2*k[mu]*eye-k*e.T-e*k.T
  assert not simp(vc*k+K2*PT*e).todok()
  physical=-bb(u)*(-sy.I*sigma*vc)*bb(w)
  po=sigma*physical*(-sy.I*sigma*k);pa=sigma*(-bb(u)*(-sy.I*sigma*vc))*(sigma*k/K2)*sy.I*xi
  assert not simp(po+sigma*w*PT*e/K2).todok()
  assert not simp(pa-sigma*xi*PT*e/K2).todok()
  # Early barred endpoints and cubic tensor:retain the actual D-dimensional
  # propagator so the omitted hat terms remain diagnostically visible.
  pe=sigma*physical*(-sy.I*sigma*kb)
  target=sigma*(-w*B2*e/K2**2+(2-u)*kb*k[mu]/K2**2+(u+w-2)*k*k[mu]*B2/K2**3)
  assert not simp((pe-target)[:4,:]).todok()
  vcbar=2*k[mu]*sy.diag(1,1,1,1,0,0)-kb*e.T-e*kb.T
  pae=sigma*(-bb(u)*(-sy.I*sigma*vcbar))*(sigma*kb/K2)*sy.I*xi
  t=-xi*( -B2*e/K2**2+(2-u)*kb*k[mu]/K2**2+(u-1)*k*k[mu]*B2/K2**3)*sigma
  assert not simp((pae-t)[:4,:]).todok()
  delta=sy.zeros(7);delta[:6,6]=-sy.I*a*e;delta[6,:6]=-sy.I*b*e.T
  dg=-block(u,sigma)*delta*block(w,sigma)
  mo=(sigma*dg*((-sy.I*sigma*k).col_join(sy.zeros(1))))[:6,:]
  ma=(sigma*dg*(sy.zeros(6,1).col_join(sy.Matrix([sy.I*xi]))))[:6,:]
  assert not simp(mo-sigma*(-a*e/K2+(-a*(u-1)+b*w)*k*k[mu]/K2**2)).todok()
  assert not simp(ma+sigma*xi*b*k*k[mu]/K2**2).todok()
  ge=sigma*(bb(w)*(-sy.I*sigma*k))*(sy.I*sigma*k[mu]/K2**2)
  ga=sigma*(sigma*k/K2*sy.I*xi)*(sy.I*sigma*k[mu]/K2**2)
  assert not simp(ge-sigma*w*k*k[mu]/K2**3).todok()
  assert not simp(ga+sigma*xi*k*k[mu]/K2**3).todok()
print('STAGE FULL_D_ORDERED_RESPONSES_PROVED',flush=True)
eps,h=sy.symbols('epsilon h');I0=sy.limit((h*sy.gamma(eps)/4).subs(h,-2*eps),eps,0);J=sy.limit((h*sy.gamma(eps)/24).subs(h,-2*eps),eps,0);IB=sy.limit((h*4*sy.gamma(eps)/(4*sy.gamma(4))).subs(h,-2*eps),eps,0);JB=sy.limit((h*6*sy.gamma(eps)/(8*sy.gamma(5))).subs(h,-2*eps),eps,0)
assert str(I0)==P['I0'] and str(J)==P['J'] and str(IB)==P['IB']
assert sy.expand(-w*IB+(2-u)*J+(u+w-2)*JB-(13*w+u-2)/48)==0
assert sy.expand(-xi*(-IB+(2-u)*J+(u-1)*JB)+xi*(11+u)/48)==0
# Scalar tensor contractions retain ordered (current,E) color labels.
f=tensorrows(P['plane_f']);byghost=defaultdict(list);byf=defaultdict(list);byphi=defaultdict(list);byphifirst=defaultdict(list)
for (d,t,a),z in A.items():byghost[a].append((d,t,z))
for (s,t,d),z in f.items():byf[t].append((s,d,z))
for (r,b,d),z in Phi.items():byphi[r].append((b,d,z));byphifirst[b].append((r,d,z))
raw={n:{} for n in ['G4','G3','P4','P3','M1I','M1W','M2W','M2H']}
for n,co in [('G4',C),('G3',H)]:
 for (b,a,c),z in co.items():
  for d,t,v in byghost[a]:putq(raw[n],(c,d,b,t),prod(z,v))
for n,co in [('P4',C),('P3',H)]:
 for (t,a,c),z in co.items():
  for s,d,v in byf[t]:putq(raw[n],(c,d,s,a),prod(z,v))
for (r,a,c),z in V.items():
 for b,d,v in byphi[r]:
  putq(raw['M1I'],(c,d,b,a),prod(z,v))
  for bb,ww in wr[b]:putq(raw['M1W'],(c,d,bb,a),prod(z,prod(v,ww)))
for n,co in [('M2W',C),('M2H',H)]:
 for (t,a,c),z in co.items():
  for b,d,v in byphifirst[t]:putq(raw[n],(c,d,b,a),prod(z,v))
raw={n:cleanq(t) for n,t in raw.items()}
spec={'ghost':{'4':[('G4',J)],'3':[('G3',-WM*J)]},'physical':{'4':[('P4',-(I0-J))],'3':[('P3',WM*(I0-J))]},'mixed':{'4':[('M1I',-(I0-J)),('M1W',-J),('M2W',J)],'3':[('M2H',-WM*J)]}}
answers={};basis={};oriented={};controls={}
for side,ts in [('left',T),('right',U)]:
 @lru_cache(maxsize=2025)
 def pair(b,a):return mul(ts[b],ts[a])
 pos={};rev={};basis[side]={}
 for n,co in raw.items():
  pp={};rr={}
  for (c,d,b,a),z in co.items():putm(pp,(c,d),pair(b,a),z);putm(rr,(c,d),pair(a,b),z)
  pos[n]=pp;rev[n]=rr;basis[side][n]=tabminus(pp,rr)
  print('STAGE ORDERED_COLOR',side,n,len(co),flush=True)
 answers[side]={};oriented[side]={}
 for family,orders in spec.items():
  answers[side][family]={};oriented[side][family]={}
  for power,terms in orders.items():
   ec=tabcomb([(pos[n],Q(z)) for n,z in terms]);es=tabcomb([(rev[n],neg(Q(z))) for n,z in terms]);ans=tablinear(ec,es,ONE,ONE);answers[side][family][power]=ans;oriented[side][family][power]={'E_C':tabnz(ec),'E_S':tabnz(es)}
   if side=='left':controls[family+power]={'omit_E_C':tabnz(ec),'omit_E_S':tabnz(es),'extra_half':tabnz(ans),'wrong_right_sign':tabnz(ans)}
L=basis['left']
# Omit the internal differentiated-ghost jet UC before any color reduction.
UA=tensorrows(P['GR']['plane_jets']['a']);badraw={}
byua=defaultdict(list)
for (d,t,a),z in UA.items():byua[a].append((d,t,z))
for n,co in [('4',C),('3',H)]:
 dd={}
 for (b,a,c),z in co.items():
  for d,t,v in byua[a]:putm(dd,(c,d),minus(mul(T[b],T[t]),mul(T[t],T[b])),prod(z,v))
 controls['ghost'+n]['omit_UC']=tabnz(tabminus(answers['left']['ghost'][n],tabcomb([(dd,Q(J if n=='4' else -WM*J))])))
for power in ['4','3']:controls['physical'+power]['reverse_cubic_Wick']=tabnz(answers['left']['physical'][power]);controls['mixed'+power]['reverse_mixed_Wick']=tabnz(answers['left']['mixed'][power])
controls['mixed4']['omit_first_mixed_placement']=tabnz(tabcomb([(L['M1I'],Q(-(I0-J))),(L['M1W'],Q(-J))]));controls['mixed4']['omit_second_mixed_placement']=tabnz(tabcomb([(L['M2W'],Q(J))]));controls['mixed3']['omit_second_mixed_placement']=tabnz(answers['left']['mixed']['3']);controls['mixed3']['omit_first_mixed_placement']=0
remaining={k:sorted(P['partition'][k]) for k in ['ghost_edge','physical_vector_edge','GF_mixed_edge']};assert sum(map(len,remaining.values()))==34
finish('primary',{'method':'full_D_mixed_inverse_literal_raw_transport_ordered_products','moments':{'I0':str(I0),'J':str(J),'IB':str(IB),'JB':str(JB)},'response_remainders':'0','ghost_inverse_response_sign':'-','Phi':[[*k,textq(z)] for k,z in sorted(Phi.items())],'Qi':enc(Qi),'UL':enc(UL),'W':enc(W),'A':[[*k,textq(z)] for k,z in sorted(A.items())],'V':[[*k,textq(z)] for k,z in sorted(V.items())],'weighted_C':[[*k,textq(z)] for k,z in sorted(C.items())],'basis':{s:{n:table(v) for n,v in d.items()} for s,d in basis.items()},'left':{f:{o:table(v) for o,v in orders.items()} for f,orders in answers['left'].items()},'right':{f:{o:table(v) for o,v in orders.items()} for f,orders in answers['right'].items()},'oriented_counts':oriented,'controls':controls,'supported_witnesses':remaining,'newly_measured_profiles':34,'remaining_vector_profiles_unmeasured':0,'new_radial_integrations':0,'control_moments_analytically_evaluated':True},start)
