from pathlib import Path
from hashlib import sha256
import json,gzip,time
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter()
for p,h in read(O/'color_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('color_'+r+'_tables.json.gz'))for r in ['primary','replay']]
for z in [a,b]:z.pop('role');z.pop('input_coefficient_roundtrips_checked')
assert a==b and a['full_positions']==4841280
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'direct_scalar_paths_vs_Lie_plus_full_symmetric_products_pass':True,'all_4841280_positions_and_zero_complement_compared':True,'anti_sym_total_positions':[sum(len(z[k])for z in a['by_ghost'])for k in ['antisymmetric_operator','symmetric_operator','total_operator']],'nonzero_symmetric_current_not_discarded':True,'no_QAP_E5_A5_or_physical_promotion':True},sort_keys=True),flush=True)
