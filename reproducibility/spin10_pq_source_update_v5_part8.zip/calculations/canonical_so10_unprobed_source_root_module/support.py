from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from itertools import combinations,permutations
import json,gzip,sys,time,threading,os
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'support_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
d=load(O/('support_'+role+'_inputs.json.gz'));aux={('b'if i<12 else'L')+str(i)for i in range(45)};ants={('bar'if i<12 else'ub')+str(i)for i in range(45)}
def kind(n):
 if n in aux:return'L'
 if n in ants:return'a'
 if n.startswith('B'):return'B'
 if n.startswith('C'):return'C'
 if n.startswith('x_'):return'x'
 return None
dims={'B':1,'L':2,'C':1,'a':1,'x':1};catalog=defaultdict(list);excluded=Counter();source_one_port=[];source_rows=0
def add(origin,n,Jx,ports,external,ref):
 if n!=0:excluded['other_intrinsic_grade']+=1;return
 if any(k not in ['C','x']or jets for k,jets in external):excluded['other_external_mean_or_jet']+=1;return
 c=sum(k=='C'for k,j in external);x=sum(k=='x'for k,j in external)
 if c>1 or x>1:excluded['excess_external_target_grade']+=1;return
 if not Jx and not c and not x:excluded['resummed_free_reference_edge']+=1;return
 key=(origin,Jx,c,x,ports[0][0],ports[1][0],ports[0][1],ports[1][1]);catalog[key].append(ref)
def ports(word,origin,n,Jx,ref):
 pairs=((i,j)for i in range(len(word))for j in range(len(word))if i!=j)if role=='primary'else(pair for ij in combinations(range(len(word)),2)for pair in[ij,ij[::-1]])
 for i,j in pairs:add(origin,n,Jx,[word[i],word[j]],[v for k,v in enumerate(word)if k not in[i,j]],[*ref,i,j])
assert set(d['source_Qx'])<=set(d['xs'])and len(d['xs'])==328
for out in d['xs']:
 for idx,row in enumerate(d['source_Qx'].get(out,[])):
  ww=[]
  for v in row['word']:
   n,sep,jets=v.partition('__');k=kind(n);assert k in dims;ww.append((k,len(jets)))
  assert sorted(k for k,j in ww)==['C','x']and all(not j for k,j in ww);source_rows+=1;ports(ww,'Jx_Qx',4-2-sum(dims[k]+j for k,j in ww),1,[out,idx]);source_one_port.append({'source':out,'row':idx,'external_C_leaves_only_one_quantum_scalar':True})
for idx,row in enumerate(d['GF']):
 ww=[]
 for v in row['word']:
  n,sep,jets=v.partition('__');k=kind(n)
  if k is None:excluded['GF_background_at_A0']+=1;break
  ww.append((k,len(jets)))
 else:ports(ww,'GF',4-sum(dims[k]+j for k,j in ww),0,[idx])
for term in d['physical_graphs']:
 for idx,(parameters,nodes,coefficient)in enumerate(term['index_jet_graph_coefficients']):
  internal={};external=[]
  for node,n,indices,jets in nodes:
   if node!='Field':continue
   if n.startswith('h_'):internal['h']=(kind(n[2:]),len(jets))
   elif n.startswith('k_'):internal['k']=(kind(n[2:]),len(jets))
   else:external.append((kind(n),len(jets)))
  assert set(internal)=={'h','k'}and all(k in dims for k,j in list(internal.values())+external);add(term['term_id'],0,0,[internal['h'],internal['k']],external,[idx])
letters=[]
for key,refs in sorted(catalog.items()):
 origin,j,c,x,L,R,j1,j2=key;letters.append({'id':len(letters),'origin':origin,'grade':[j,c,x],'H_ports':[L,R],'internal_jet_orders':[j1,j2],'member_references':sorted(refs,key=str)})
G={('B','B'),('B','L'),('L','B'),('C','a'),('a','C'),('x','x')};ks=sorted(dims);target=(1,1,1);sub=lambda a,b:tuple(x-y for x,y in zip(a,b));sat=lambda a:all(x>=0 for x in a);active=[z['id']for z in letters if sat(sub(target,z['grade']))];opts={i:[(r,letters[i]['H_ports'][1])for r in ks if(r,letters[i]['H_ports'][0])in G]for i in active};found=set()
if role=='primary':
 edges=defaultdict(list)
 for i in active:
  for r,c in opts[i]:edges[r].append((i,c))
 def walk(start,at,left,w,path):
  if not any(left):
   if at==start:found.add((tuple(w),tuple(path)))
   return
  for i,to in edges[at]:
   rem=sub(left,letters[i]['grade'])
   if sat(rem):walk(start,to,rem,w+[i],path+[to])
 for k in ks:walk(k,k,target,[],[k])
else:
 multis=[]
 def choose(lo,left,w):
  if not any(left):multis.append(tuple(w));return
  for at in range(lo,len(active)):
   i=active[at];rem=sub(left,letters[i]['grade'])
   if sat(rem):choose(at,rem,w+[i])
 choose(0,target,[])
 for ms in multis:
  for w in set(permutations(ms)):
   def attach(at,path):
    if at==len(w):
     if path[-1]==path[0]:found.add((w,tuple(path)))
     return
    for r,c in opts[w[at]]:
     if not path or path[-1]==r:attach(at+1,(path or[r])+[c])
   attach(0,[])
words=[];families=Counter()
for w,path in sorted(found):
 assert len(w)<=3
 for j in range(len(w)):assert(w[j:]+w[:j],path[j:-1]+path[:j]+(path[j],))in found
 words.append({'letters':list(w),'Green_path':list(path),'STr_sign':(-1)**int(path[0]in ['a','C']),'ordered_log_weight':[(-1)**(len(w)+1),2*len(w)]});families[len(w),tuple(sorted(letters[i]['origin']for i in w))]+=1
out={'schema':'USR1_COMPLETE_MARGINAL_Jx_C_x_PROPER_SUPPORT','role':role,'letters':letters,'ordered_words':words,'families':[{'length':n,'origins':list(f),'words':v}for(n,f),v in sorted(families.items())],'excluded':dict(excluded),'source_rows':source_rows,'one_port_source_projection':source_one_port,'potential_quartic_requires_two_scalar_means_cubic_quadratic_intrinsic_degree_excluded':True,'fermion_cycle_cannot_consume_mandatory_source_scalar_ghost_ports_at_zero_fermion_mean':True,'typed_support_not_quantum_amplitude':True};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('support_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'letters':len(letters),'ordered_words':len(words),'families':out['families'],'source_rows':source_rows},sort_keys=True),flush=True);timer.cancel()
