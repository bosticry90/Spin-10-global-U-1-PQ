# USR2: complete marginal scalar-source three-edge kernel

Prospective after USR1:14 letters,54 ordered cycles across three charged
scalar kinetic sectors;all are3-edge. Qx source is homogeneous C*x;
source+external-C leaves only one quantum scalar and is excluded as one-port.
The potential and fermion exclusions are in the complete support record.

Source phase Sigma_E=-Sigma_M,Jx_M=-Jx_E gives the Euclidean source vertex
Jx_i C_c R_c[i,j] x_j with PLUS coefficient. Ordinary ghost current is the
left antighost Euler current,density a C_h J0_h b. The physical scalar
ending is HX_(B_a_mu,x_j)=-i q_mu R_a[j,k] x_k and its reverse +i q_mu.
These kinetic/source R tensors must match under the actual metric/chart.

Boson elimination gives the effective ghost potential Jx*C_h J0_h G W_i.
Varying its inverse boson matrix by HX changes it by -J0_h G HX G W_i.
The -Trlog ghost determinant therefore predicts
 C3_(i,h,k)=Tr(J0_h G HX_k G W_i).
This sign and no-extra-half are proposals until paired Gaussian agrees.
At q²=1 and b=(B_long,Lambda,x),G_BB=w,G_BL=-q,G_LB=q,G_LL=0,G_xx=I.
Thus C3=-i sum_(c,a,j) (J0_B,h w+J0_L,h)_(c,a) R_c[i,j] R_a[j,k].

Use literal paired-mode graded Hessian/quarter-STrlog vs full Schur trace
and closed indices for D3/4/5 and first/last axes,q±. Preserve both HX
endpoints. Test omitted vector/auxiliary current,source and one literal
HX endpoint with nonzero generic data. One-port/source-only controls should
be insensitive. The source scalar endpoint and momentum HX/current force
longitudinal paths,no closed spectator:fixed Djet0. Check this support
argument rather than inferring Djet0 from interpolation.

Relative coefficient is (chi4+log(3/2))*C3 with no physical normalization
choice. Positive heat3 means length6 vs baseline4;verify Frullani separately.
No desired H coefficient or model quantum root enters this kernel check.
Natives300s/reviewer180s,8GiB sampled,350MiB launch floor,32MiB whole packet.
