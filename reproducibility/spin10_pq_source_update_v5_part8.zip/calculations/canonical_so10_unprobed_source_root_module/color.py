from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'color_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('color_'+('replay'if role=='primary'else'primary')):raise PermissionError('USR4_PEER_DENIED')
  if p.parent.name in ['canonical_so10_intrinsic_full_source_descent','canonical_so10_intrinsic_correlated_source_contacts']and p.name.startswith(('variation','partial_H','lowering')):raise PermissionError('USR4_DESIRED_SOURCE_IMAGE_DENIED')
sys.addaudithook(guard)
cp=Path(read(O/'color_inputs.json')['coefficient_ring_source']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient,verify_basis_products,expression,I as CI
assert verify_basis_products()==1024
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def val(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
def dec(z):return {(i,j):val(v)for i,j,v in z['entries']}
def tidy(z):return{k:v for k,v in z.items()if v!=0}
def plus(terms):
 out=defaultdict(lambda:0)
 for z,f in terms:
  for k,v in z.items():out[k]+=f*v
 return tidy(out)
d=load(O/('operands_'+role+'_tables.json.gz'));inp=load(O/('operands_'+role+'_inputs.json.gz'));R=list(map(dec,d['R']));K=list(map(dec,d['K']));A=list(map(dec,d['K_antisymmetric']));S=list(map(dec,d['K_symmetric']));qc={tuple(v[:-1]):val(v[-1])for v in d['qC']};rby=[defaultdict(list)for i in range(45)]
for c,M in enumerate(R):
 for(i,j),v in M.items():rby[c][i].append((j,v))
@lru_cache(None)
def product(c,a):
 out=defaultdict(lambda:0)
 for(i,j),v in R[c].items():
  for k,w in rby[a][j]:out[i,k]+=v*w
 return tidy(out)
def apply(M):
 out=defaultdict(lambda:0)
 for(c,a),v in M.items():
  for ij,w in product(c,a).items():out[ij]+=v*w
 return{k:-CI*v for k,v in tidy(out).items()}
byqc=defaultdict(list)
for(b,c,a),v in qc.items():assert c<a;byqc[c,a].append((b,v))
results=[];controls=[];wrongJ=[];auxJ=[]
for z in inp['J0']:
 MM=s.SparseMatrix(*z['shape'],{(i,j):s.sympify(v,locals=loc)for i,j,v in z['entries']});wrongJ.append({(int(i),int(j)):coefficient(s.expand(v))for(i,j),v in (MM[:,:45]*xi+MM[:,45:]).applyfunc(s.expand).todok().items()});auxJ.append({(int(i),int(j)):coefficient(s.expand(v))for(i,j),v in MM[:,45:].todok().items()})
for h in range(45):
 if role=='primary':anti=apply(A[h]);sym=apply(S[h]);total=apply(K[h]);assert total==plus([(anti,1),(sym,1)])
 else:
  weights=defaultdict(lambda:0)
  for(c,a),v in A[h].items():
   if c<a:
    for b,f in byqc[c,a]:weights[b]+=v*f
  anti=defaultdict(lambda:0)
  for b,v in tidy(weights).items():
   for ij,w in R[b].items():anti[ij]+=-CI*v*w
  anti=tidy(anti);sym=defaultdict(lambda:0)
  for(c,a),v in S[h].items():
   if c>a:continue
   terms=[product(c,a)]if c==a else[product(c,a),product(a,c)]
   for term in terms:
    for ij,w in term.items():sym[ij]+=-CI*v*w
  sym=tidy(sym);total=plus([(anti,1),(sym,1)])
 wrong=apply(wrongJ[h]);aux=apply(auxJ[h]);controls.append({'h':h,'omit_symmetric_operator_changes_positions':len(sym),'omit_auxiliary_current_changes_positions':len(aux),'replace_all_widths_by_xi_changes_positions':len(plus([(total,1),(wrong,-1)])),'reverse_R_order_changes_positions':len(anti)})
 results.append({'h':h,'antisymmetric_operator':[[i,j,str(v)]for(i,j),v in sorted(anti.items())],'symmetric_operator':[[i,j,str(v)]for(i,j),v in sorted(sym.items())],'total_operator':[[i,j,str(v)]for(i,j),v in sorted(total.items())]});print('STAGE USR4',role,h,'anti_sym_total',len(anti),len(sym),len(total),flush=True)
out={'schema':'USR4_COMPLETE_UNPROBED_SCALAR_SOURCE_QUANTUM_ROOT','role':role,'by_ghost':results,'controls':controls,'full_positions':45*328*328,'common_normalization':'hbar/(16pi^2)','relative':'(chi4+log(3/2))*Z_h;fixed Djet0','ring_basis_products_verified':1024,'input_coefficient_roundtrips_checked':val.cache_info().currsize,'full_quantum_identity_QAP_E5_A5':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('color_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'anti_sym_total_positions':[sum(len(z[k])for z in results)for k in ['antisymmetric_operator','symmetric_operator','total_operator']],'controls_changed_positions':{k:sum(z[k]for z in controls)for k in controls[0]if k!='h'},'cached_direct_representation_products':product.cache_info().currsize},sort_keys=True),flush=True);timer.cancel()
