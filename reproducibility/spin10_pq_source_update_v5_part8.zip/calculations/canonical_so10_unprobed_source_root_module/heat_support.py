from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from itertools import combinations,permutations
import json,gzip,sys,time,threading,os
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'heat_support_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
d=load(O/('heat_support_'+role+'_inputs.json.gz'));aux={('b'if i<12 else'L')+str(i)for i in range(45)};ants={('bar'if i<12 else'ub')+str(i)for i in range(45)}
def kind(n):
 if n in aux:return'L'
 if n in ants:return'a'
 if n.startswith('B'):return'B'
 if n.startswith('C'):return'C'
 if n.startswith('x_'):return'x'
 return None
dims={'B':1,'L':2,'C':1,'a':1,'x':1,'P':1.5};catalog=defaultdict(list);excluded=Counter();resummed=[];lowports=[]
def add(origin,n,J,ports,external,ref):
 if n not in [0,1]:excluded['outside_intrinsic_zero_or_one']+=1;return
 if any(k not in ['a','C','x']or jets for k,jets in external):excluded['other_mean_field_or_external_jet']+=1;return
 a=sum(k=='a'for k,j in external);c=sum(k=='C'for k,j in external);x=sum(k=='x'for k,j in external)
 if a>1 or c>1 or x>1:excluded['excess_external_target_grade']+=1;return
 grade=(n,J,a,c,x)
 if not any(grade):resummed.append({'origin':origin,'ports':ports,'reference':ref});return
 key=(origin,*grade,ports[0][0],ports[1][0],ports[0][1],ports[1][1]);catalog[key].append(ref)
def ports(word,origin,n,J,ref):
 if len(word)<2:lowports.append({'origin':origin,'reference':ref,'fields':word});return
 pairs=((i,j)for i in range(len(word))for j in range(len(word))if i!=j)if role=='primary'else(pair for ij in combinations(range(len(word)),2)for pair in[ij,ij[::-1]])
 for i,j in pairs:add(origin,n,J,[word[i],word[j]],[v for k,v in enumerate(word)if k not in[i,j]],[*ref,i,j])
for out,rows in d['qLambda'].items():
 assert out in aux
 for idx,row in enumerate(rows):
  ww=[]
  for v in row['word']:
   n,sep,jets=v.partition('__');k=kind(n);assert k in dims;ww.append((k,len(jets)))
  ports(ww,'JL_qLambda',3-sum(dims[k]+j for k,j in ww),1,[out,idx])
for idx,row in enumerate(d['GF']):
 ww=[]
 for v in row['word']:
  n,sep,jets=v.partition('__');k=kind(n)
  if k is None:excluded['GF_background_at_A0']+=1;break
  ww.append((k,len(jets)))
 else:ports(ww,'GF',4-sum(dims[k]+j for k,j in ww),0,[idx])
for term in d['physical_graphs']:
 for idx,(parameters,nodes,coefficient)in enumerate(term['index_jet_graph_coefficients']):
  internal={};external=[]
  for node,n,indices,jets in nodes:
   if node!='Field':continue
   if n.startswith('h_'):internal['h']=(kind(n[2:]),len(jets))
   elif n.startswith('k_'):internal['k']=(kind(n[2:]),len(jets))
   else:external.append((kind(n),len(jets)))
  assert set(internal)=={'h','k'}and all(k in dims for k,j in list(internal.values())+external);add(term['term_id'],0,0,[internal['h'],internal['k']],external,[idx])
# These algebraic supersets permit every relevant potential and isolated
# zero-fermion-mean Yukawa/mass block,without importing a guessed coefficient.
add('ABSTRACT_potential_cubic',1,0,[('x',0),('x',0)],[('x',0)],['arbitrary_cubic_tensor'])
add('ABSTRACT_potential_quartic',0,0,[('x',0),('x',0)],[('x',0),('x',0)],['arbitrary_quartic_tensor'])
add('ABSTRACT_potential_mass',2,0,[('x',0),('x',0)],[],['arbitrary_scalar_mass'])
add('ABSTRACT_fermion_Yukawa',0,0,[('P',0),('P',0)],[('x',0)],['arbitrary_Yukawa_tensor'])
add('ABSTRACT_fermion_mass',1,0,[('P',0),('P',0)],[],['arbitrary_fermion_mass'])
letters=[]
for key,refs in sorted(catalog.items()):
 origin,n,J,a,c,x,left,right,j1,j2=key;grade=[n,J,a,c,x];assert sum(grade)>0;letters.append({'id':len(letters),'origin':origin,'grade':grade,'H_ports':[left,right],'internal_jet_orders':[j1,j2],'member_references':sorted(refs,key=str)})
G={('B','B'),('B','L'),('L','B'),('C','a'),('a','C'),('x','x'),('P','P')};ks=sorted(dims);sub=lambda a,b:tuple(x-y for x,y in zip(a,b));sat=lambda a:all(x>=0 for x in a);results=[]
for name,target in [('JL_Cx',(1,1,0,1,1)),('a_Cx',(1,0,1,1,1))]:
 active=[z['id']for z in letters if sat(sub(target,z['grade']))];opts={i:[(r,letters[i]['H_ports'][1])for r in ks if(r,letters[i]['H_ports'][0])in G]for i in active};found=set()
 if role=='primary':
  edges=defaultdict(list)
  for i in active:
   for r,c in opts[i]:edges[r].append((i,c))
  def walk(start,at,left,w,path):
   if not any(left):
    if at==start:found.add((tuple(w),tuple(path)))
    return
   for i,to in edges[at]:
    rem=sub(left,letters[i]['grade'])
    if sat(rem):walk(start,to,rem,w+[i],path+[to])
  for k in ks:walk(k,k,target,[],[k])
 else:
  multis=[]
  def choose(lo,left,w):
   if not any(left):multis.append(tuple(w));return
   for at in range(lo,len(active)):
    i=active[at];rem=sub(left,letters[i]['grade'])
    if sat(rem):choose(at,rem,w+[i])
  choose(0,target,[])
  for ms in multis:
   for w in set(permutations(ms)):
    def attach(at,path):
     if at==len(w):
      if path[-1]==path[0]:found.add((w,tuple(path)))
      return
     for r,c in opts[w[at]]:
      if not path or path[-1]==r:attach(at+1,(path or[r])+[c])
    attach(0,[])
 words=[];heat=Counter();abstract=Counter()
 for w,path in sorted(found):
  assert len(w)<=sum(target)==4
  for j in range(len(w)):assert(w[j:]+w[:j],path[j:-1]+path[:j]+(path[j],))in found
  words.append({'letters':list(w),'Green_path':list(path),'STr_sign':(-1)**int(path[0]in ['a','C','P']),'ordered_log_weight':[(-1)**(len(w)+1),2*len(w)]});heat[len(w)]+=1
  for i in w:
   if letters[i]['origin'].startswith('ABSTRACT'):abstract[letters[i]['origin']]+=1
 results.append({'target':name,'ordered_words':words,'word_counts_by_heat':dict(heat),'abstract_superfamily_word_occurrences':dict(abstract),'max_heat_edges':max(heat,default=0),'positive_grade_bound':sum(target)});print('STAGE USR6_SUPPORT',role,name,len(words),dict(heat),'abstract',dict(abstract),flush=True)
out={'schema':'USR6_COMPLETE_REMAINING_NATIVE_ROOT_HEAT_SUPPORT','role':role,'letters':letters,'results':results,'excluded':dict(excluded),'resummed_reference_candidates':resummed,'low_port_rows':lowports,'native_local_relative_constants_formal_span':['chi4','log2','log3','algebraic_fixed'],'formal_log5_projection_of_these_unprobed_native_loops':'zero','absolute_normalization_regulator_insertion_or_full_QAP_not_inferred':True};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('heat_support_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'letters':len(letters),'targets':[[q['target'],q['word_counts_by_heat'],q['max_heat_edges']]for q in results],'formal_log5_exclusion_only_not_anomaly':True},sort_keys=True),flush=True);timer.cancel()
