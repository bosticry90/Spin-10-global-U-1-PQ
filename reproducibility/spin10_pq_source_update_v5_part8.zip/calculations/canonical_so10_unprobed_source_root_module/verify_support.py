from pathlib import Path
from hashlib import sha256
import json,gzip,time
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter()
for p,h in read(O/'support_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('support_'+r+'_tables.json.gz'))for r in ['primary','replay']]
for z in [a,b]:z.pop('role')
assert a==b
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'complete_directed_cycles_vs_multisets_permutations_pass':True,'letters':len(a['letters']),'ordered_words':len(a['ordered_words']),'families':a['families'],'source_one_port_and_other_target_exclusions_retained':True,'typed_support_not_QAP_or_quantum_coefficient':True},sort_keys=True),flush=True)
