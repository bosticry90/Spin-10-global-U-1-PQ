# A measured scalar-source root and a protected finite heat-length remainder

October25,2026. Base1988c60c21fea8fe46c2ed764c3c9537d084f3b1,V629.
PROGRESS; director scientific acceptance NOT_PERFORMED. State113,
authority34/39,E5/A5 OPEN,custodyexit2/seven NOTPASS unchanged. This packet
does not install a counterterm,adopt a scheme or change physical inputs.

The complete unprobed scalar-source Jx Cx kernel is now measured. Its
ordinary auxiliary current has a nonzero symmetric component,so a proposed
commutator-only shortcut fails. Keeping that component gives a covariant
quantum root and its actual contribution to the selected source relation.

A more consequential restriction follows. The two remaining native kernels
cannot affect the relation's formal log5 coefficient. That coefficient
comes from three authenticated five-edge groups in the previously measured
u JL Cx root. Native-loop cancellation alone cannot make this retained-basis
group zero. The required additional finite regulator/source or normalization
contribution remains to be independently constructed. This is not an anomaly
or proof that an admissible full renormalized prescription cannot exist.

## Domain and reference intake

Same original unshifted SMA/CSW/EDS,A0,constant first probes,externaljets0,
all45 ghost/gauge/nonminimal directions and328 real scalars,symbolicg10/
xi/eta_H. New Jx Cx is unprobed C0,intrinsicdegree0. Its later B_rho
operation uses BOTH existing probes. Same inherited common nonexceptional
Euclidean LOCAL RELATIVE DIM-minus-strict-heat construction. This is not a
physical scaleless-p0 amplitude,massive-vacuum/causal limit,absolute product
normalization or adopted physical scheme. chi4 remains unselected and
distinct from b0,kappa and infrared contact freedom.

The two supplied October25 assessments were reviewed as reference and
interpretation,not quantum input or acceptance authority. They emphasize
complete interaction support,ordinary/source correlation,independently
measured corrections,shared-error limits and the failure of a sole constant
scalar shift. The present work follows those priorities. Their earlier
checkpoint and pause descriptions do not supersede live Git,process state,
the current handoff or the subsequent human resumption. Original attachment
paths and hashes are bound in the final-review inputs. Their external
literature claims were not needed or newly validated for this calculation.

## USR1-2: actual support and universal kernel

Complete source Qx has29754 raw rows. Two distinct enumerations retain
14 interaction letters and54 ordered three-edge cycles:18 each for
Phi,Sigma,phi. Source-only and one-port exclusions are preserved. Actual
full gauge-fixing and physical kinetic programs enter the inventory.
Potential vertices cannot satisfy the remaining target means;zero-fermion-
mean fermion cycles cannot reach the compulsory ghost/scalar source ports.
Singlet scalar directions are included,with measured zero coefficients.

Paired-mode literal graded Gaussian quarter-supertrace-log,boson/ghost
Schur elimination and closed-index contractions give

    Z_h[i,k]=-i sum_(c,a,j) K_h[c,a] R_c[i,j] R_a[j,k],
    K_h=J0_B,h G0_BB+J0_L,h.

Equivalently C3=Tr(J0_h G HX_k G W_i). The source sign is PLUS Jx C R x
in the actual Euclidean source action. HX_Bx has -i q R and the reverse
endpoint +i q R. Both vector and auxiliary currents are required. All
54 actual words are covered. Six generic Cartesian fixtures(D3/4/5,
first/last axes,q+/-) agree,with a nonzero example56+21i. Sensitive controls
include missing current,source or one literal HX endpoint. One-port and
source-only omissions are insensitive in this proper-loop projection.
Longitudinal endpoint support proves fixed dimensional jet0;this is not a
numerical interpolation in dimension. The local relative coefficient is

    (chi4+log(3/2)) Z_h, common normalization hbar/(16pi^2).

## USR3-4: the commutator-only shortcut fails,but the full root is measured

Primary uses actual kinetic R;replay reconstructs it from the full raw Qx
source action and physical charts. All45x328x328 coefficients,including
zeros,agree. Actual scalar and ghost metrics are checked,not replaced by
assumed identities. R has12560 nonzeros and SHA256
d6af5e8d4e0e3304504310767b32b98a82e3965d18f93daa6a8802a245bea1d8.

K/antisymmetricK/symmetricK have1340/1340/668 positions. In particular K is
not generally antisymmetric. The symmetric component is zero in the
unbroken directions but nonzero in broken directions. It must remain.

Primary contracts full ordered scalar paths. Replay reduces antiK using
the actual R/qC Lie relation and contracts symmetricK through anticommutators
and diagonal products. Both routes use the full symmetric part. They agree
on all4841280 positions,including the zero complement. Operator counts:

| Operator component | Nonzero coefficient positions |
| --- | ---: |
| Antisymmetric-current contribution |16184|
| Symmetric-current contribution |27344|
| Sum Z_h |35824|

These are algebraic positions,not independent interactions,tests or ranks.
Omitting symmetricK changes27344 positions;omitting J0_L changes11722;
replacing actual widths by xi changes33750;reversing R order changes16184.
No inverse coupling or fitted quantum coefficient is introduced. The
qualified exact Fraction/polynomial/multiquadratic ring checks1024 basis
products;it is reused as software,not a proof of shared physical premises.

## USR5: covariance and the actual source operation

All12 residual-H generator actions vanish on the full nonzero Z tensor,
with the actual ghost and scalar parameter charts. Source and scalar
singlet rows/columns vanish exactly. This is a bounded background covariance
check,not full quantum QAP or physical source-reality equivalence.

The action-derived qJx_i|rhoJL=rho JL_r D_ir is reconstructed from the
actual G density BEFORE restriction. Sigma_E=+i rho JL x c gives D=+i c.
It agrees with the earlier fixed operation matrix(296 nonzeros for probe1,
zero for probe0). Independent contraction associations give

    Bscalar[r,h,j]=sum_i D_ir Z_h[i,j].

The new contribution has12792 positions for each of chi4,log2,log3,
with signs+,-,+ respectively;its log5 coefficient is zero. The current
known H counts after adding it exactly once are:

| Probe1 formal carrier | New contribution | Known partial H |
| --- | ---: | ---: |
| chi4 |12792|10488|
| log2 |12792|13080|
| log3 |12792|10296|
| log5 |0|12432|

Probe0 is zero throughout this selected known group. Two native quantum
roots remain unmeasured:intrinsic JL Cx and intrinsic aCx. Counts cannot
establish their values or imply cancellation of any other carrier.

## USR6-7: those two native roots cannot cancel the formal log5 component

Complete actual qLambda/fullGF/physical-kinetic inventories,with abstract
potential and isolated fermion supersets,are enumerated independently by
directed paths versus multisets/permutations. Both targets have total
positive grade4. All gradezero free two-port terms are resummed in G0;
every non-reference interaction consumes positive grade. Thus at most4
positive-heat edges occur. An intrinsic N0 insertion is a vertex between
two such edges,not an unregulated free cancellation.

| Target | Two edges | Three edges | Four edges | Total |
| --- | ---: | ---: | ---: | ---: |
| intrinsic JL Cx |4|30|48|82|
| intrinsic aCx |4|174|288|466|

The catalog has37 letters. Abstract potential and fermion supersets enter
zero complete target cycles;absence of an input coefficient table is not
treated as a quantum zero. Under the qualified local radial rule,m edges
give chi4 plus log(m/2),with algebraic dimensional jets. These native roots
therefore lie in formal span{chi4,log2,log3,algebraic fixed}. Their90 actual
B_rho operation coefficients are polynomial/algebraic in g10,xi,eta_H and
introduce no logarithm. This proves the stated log5 exclusion in the
retained formal basis while chi4 remains unselected.

USR7 authenticates and combines the old heat-resolved quantum groups:

    N5=i(P2+Nh-K3).

Both earlier derivations agree. Probe1 group counts9632/9632/12128 combine
to12432 nonzeros,including the unchanged full zero complement. Each group
is sensitive to omission. All other log5 source carriers in the earlier
assembly vanish. Since du=rho,the rho JL Cx coefficient inherits +N5.
The source assembly,ISD replay H and current known H agree exactly with
N5 at all664200 positions/probe. This reuses authenticated earlier loop
tables;it is not a new independent replay of that quantum contraction.

A nonzero canonical witness(source r,ghost h,scalar i)=(13,0,137) is

    coefficient of log5 = -i sqrt(6) eta_H g10^4 xi/16.

This statement is formal and symbolic,not a chosen physical benchmark.
It does not prove transcendental independence after selecting chi4,a
fundamental anomaly,no admissible counterterm or failure of Spin(10).
It proves that completing these two NATIVE kernels alone cannot make this
formal native conversion group zero. It also does not authorize choosing
a favorable chi4,declaring the negative remainder a measured regulator
root,or identifying chi4 with b0/kappa/IR freedom.

An elementary regulator mechanism is checked separately:for Gt=E G0,
H0 Gt=E rather than I. A free-equation contraction may leave a heat factor.
With the declared momentum measure,the difference of four/five-edge radial
terms integrates to log(5/4)/(16pi^2). Two parameterizations agree beyond
68 decimals,and a sign reversal fails. This is only a candidate mechanism;
the complete model-specific graded regulator/source Ward insertion and
its coefficient have NOT been derived here. Nonlinear source,Hessian,
connected-product and measure terms must come from the actual regulated
construction,not from the value needed to cancel N5.

## Evidence,failures and research capability

All17 pre-final-review native captures completed with exit0. Prospective
records,source copies,actual inputs,outputs,resource samples and verifiers
are preserved. One apply_patch was rejected before any source/preparation
or native launch because a patch line lacked its leading+. Its exact
failure classification is retained externally;the corrected source was
then frozen normally. No failed native calculation is relabeled PASS.

Native primary/replay times(seconds after imports):support1.5604/1.4462;
kernel.3671/.3227;operands2.6167/8.6884;color32.6363/24.1452;
heat support1.0264/1.0877. Integration70.5202,provenance3.6704.
Verifiers also passed. Largest pre-review sampled private allocation
400973824bytes;sampling is not continuous peak measurement. Packet before
report/review3787439bytes. Bounds300s/native,180s/review,8GiB sampled,
350MiB launch floor and32MiB packet were retained.

The delegated E4 command completed,native0,step exits[0,0,0,0,0,2]. It
authenticates the sealed bounded evidence and runs declared audits;it is
not a fresh whole scientific replay or global PASS. Custody remains exit2
with seven unresolved references. State SHA256 remains
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8.

Demonstrated AI capability:complete interaction-domain reductions,a
generic graded Hessian derivation,actual Lie/Jordan contraction and
covariance,followed by a structural exclusion that redirects effort away
from an incapable cancellation route. The non-antisymmetric current is a
rejected shortcut,not a failed model. The heat-length restriction is a
scientific limitation on this proposed cancellation,not an engineering bug.
Shared action,charts,qualified helpers,tables,SymPy/runtime and AI author
remain shared-error limits. Multiple methods are not independent scientists,
experimental evidence or validation of the physical premises.

This RESULT is frozen before the separate final interpretation/replay
review. Its receipt is a distinct artifact;review failure must preserve
this source rather than rewrite a claim retrospectively.

## Next smallest scientific action

Derive the selected finite regulator/source operation on the measured
u JL Cx five-edge family from the ORIGINAL regulated identity,including
actual free-edge contractions,nonlinear Hessian/source terms and reference
response. Begin a complete port/operation inventory for the rho JL Cx
projection. A four-to-five-edge heat defect is a hypothesis to test,not a
coefficient to assign. Compare independently derived operators with N5
only after their construction. If the existing prescription omits a
necessary finite definition,record that premise precisely. Keep the two
unmeasured native roots for completion of other formal carriers when needed.

Remaining u quadratic-source contacts,T/F,complete general ordinary BBx,
renormalized products,full chiral QAP/measure/global phase,physical source
reality and massive/causal physical-domain obligations remain open. No
HB1/C5 or flavor activation,protected promotion or remote action. Goal
ACTIVE/INCOMPLETE;physical Grand Unification remains unproved.
