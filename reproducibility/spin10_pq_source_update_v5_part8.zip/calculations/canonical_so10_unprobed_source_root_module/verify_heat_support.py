from pathlib import Path
from hashlib import sha256
import json,gzip,time,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter()
for p,h in read(O/'heat_support_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('heat_support_'+r+'_tables.json.gz'))for r in ['primary','replay']]
for z in [a,b]:z.pop('role')
assert a==b and all(q['max_heat_edges']<=4 and not q['abstract_superfamily_word_occurrences']for q in a['results'])
ip=read(O/'heat_support_late_inputs.json');old=load(Path(ip['old_H_log5']));now=load(O/'integration_tables.json.gz');counts=[]
for probe in range(2):
 q=old['results'][probe]['formal_basis'][0]['nonminimal']['H'];previous={(r,ww[0],i):s.expand(s.sympify(v))for r,ww,i,v in q};assert all(len(ww)==1 for r,ww,i,v in q);current=next(z for z in now['results'][probe]['formal_basis']if z['basis']=='log5');present={tuple(z[:-1]):s.expand(s.sympify(z[-1]))for z in current['known_partial_H_with_scalar_source']};assert previous==present and not current['measured_scalar_source_BrhoC0'];counts.append(len(previous))
ops=load(Path(ip['operation_matrices']))['results'];polynomials=0
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
for probe in range(2):
 for k in ['C_JL_x','C_a_x']:
  for *ix,v in ops[probe]['pending_operation_matrices'][k]:
   z=s.sympify(v,locals=loc);assert not z.has(s.log)and z.free_symbols<=set([g,xi,eta]);s.Poly(z,g,xi,eta);polynomials+=1
assert counts==[0,12432]
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'directed_cycles_vs_multisets_complete_heat_support_pass':True,'remaining_root_word_counts':[[q['target'],q['word_counts_by_heat']]for q in a['results']],'each_remaining_unprobed_native_root_maximum_heat':4,'polynomial_operation_entries_checked':polynomials,'formal_log5_H_positions_unaffected_by_missing_native_roots':counts,'native_conversion_group_cannot_be_formally_zero_without_additional_log5_contribution':True,'not_transcendence_anomaly_or_no_counterterm_theorem':True,'full_QAP_E5_A5_promotion':False},sort_keys=True),flush=True)
