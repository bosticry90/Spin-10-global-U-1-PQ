from pathlib import Path
from hashlib import sha256
import json,gzip,time
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter()
for p,h in read(O/'kernel_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('kernel_'+r+'_tables.json.gz'))for r in ['primary','replay']]
for z in [a,b]:z.pop('role')
assert a==b and all(a['controls'].values());su=load(O/'support_primary_tables.json.gz');assert len(su['ordered_words'])==54 and all(len(w['letters'])==3 for w in su['ordered_words'])
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'paired_Gaussian_vs_Schur_vs_closed_indices_pass':True,'all_six_Cartesian_fixtures_and_controls_pass':True,'generic_heat_coefficients':a['generic_heat_coefficients'],'complete_actual_54_words_covered_by_three_edge_kernel':True,'model_quantum_coefficient_QAP_or_E5_A5_not_inferred':True},sort_keys=True),flush=True)
