from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'operands_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.expand(s.sympify(z,locals=loc))
cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v)for i,j,v in z['entries']});enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(v)]for(i,j),v in sorted(cl(M).todok().items())]}
d=load(O/('operands_'+role+'_inputs.json.gz'));frame=d['frame'];xs=d['xs'];aux=[('b'if i<12 else'L')+str(i)for i in range(45)];cs=['C'+str(i)for i in range(45)];ants=[('bar'if i<12 else'ub')+str(i)for i in range(45)];phys=[f'B{i}_{mu}'for i in range(45)for mu in range(4)]+xs+aux+cs+ants;ri={n:i for i,n in enumerate(frame['field_order'])};pi={n:i for i,n in enumerate(phys)};TI=dec(frame['physical_to_raw_inverse']);TF=dec(frame['physical_to_raw_kernel'])
def block(ns):
 T=TI.extract([ri[n]for n in ns],[pi[n]for n in ns]);F=TF.extract([pi[n]for n in ns],[ri[n]for n in ns]);assert not cl(T*F-s.eye(len(ns))).todok()and not cl(F*T-s.eye(len(ns))).todok();return T,F
Tx,Fx=block(xs);TC,FC=block(cs);TA,FA=block(ants);assert not cl(Fx*Fx.T-s.eye(328)).todok()and not cl(FC*dec(frame['raw_ghost_Green'])*FA.T-s.eye(45)).todok()
if role=='primary':R=list(map(dec,d['R']))
else:
 raw=[s.SparseMatrix(328,328,{})for c in range(45)];xid={n:i for i,n in enumerate(xs)}
 for out,rows in d['source_Qx'].items():
  for row in rows:
   w=row['word'];assert len(w)==2 and all('__'not in n for n in w);c=int(next(n[1:]for n in w if n.startswith('C')));j=xid[next(n for n in w if n in xid)];raw[c][xid[out],j]+=parse(row['coefficient'])
 R=[cl(Fx*sum((TC[k,c]*raw[k]for k in range(45)if TC[k,c]),s.zeros(328))*Tx)for c in range(45)]
assert all(not cl(M+M.T).todok()for M in R);G=dec(d['G0']);assert not G[45:,45:].todok()and not cl(G[:45,45:]+s.eye(45)).todok()and not cl(G[45:,:45]-s.eye(45)).todok();width=G[:45,:45];assert all(a==b for a,b in width.todok());JJ=list(map(dec,d['J0']));K=[];anti=[];sym=[];controls=[]
for h,J in enumerate(JJ):
 M=cl(J[:,:45]*width+J[:,45:]);A=cl((M-M.T)/2);S=cl((M+M.T)/2);assert not cl(A+S-M).todok();K.append(M);anti.append(A);sym.append(S);wrong=cl(J[:,:45]*xi+J[:,45:]);controls.append({'h':h,'replace_widths_by_xi_changes_K_positions':len(cl(M-wrong).todok()),'omit_auxiliary_current_changes_K_positions':len(J[:,45:].todok())})
RR=list(map(enc,R));rh=sha256((json.dumps(RR,sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest();out={'schema':'USR3_ACTUAL_ALIGNED_SCALAR_SOURCE_OPERANDS','role':role,'R':RR,'R_sha256':rh,'K':[enc(M)for M in K],'K_antisymmetric':[enc(M)for M in anti],'K_symmetric':[enc(M)for M in sym],'controls':controls,'all_scalar_and_ghost_inverse_metrics_identity_verified':True,'qC':d['qC'],'K_not_assumed_antisymmetric':True,'new_quantum_coefficients_measured':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('operands_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'R_sha256':rh,'R_nonzero':sum(len(M.todok())for M in R),'K_anti_sym_positions':[sum(len(M.todok())for M in seq)for seq in [K,anti,sym]],'K_symmetric_counts_by_h':[len(M.todok())for M in sym],'new_quantum_coefficient_measured':False},sort_keys=True),flush=True);timer.cancel()
