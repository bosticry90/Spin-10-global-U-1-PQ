from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,gzip,sys,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'provenance_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
sys.path.insert(0,str(Path(read(O/'color_inputs.json')['coefficient_ring_source']).parent));from coefficient_ring import coefficient,I as CI
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def val(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
def tab(z):return {tuple(q[:-1]):val(q[-1])for q in z}
def plus(terms):
 out=defaultdict(lambda:0)
 for z,f in terms:
  for k,v in z.items():out[k]+=f*v
 return {k:v for k,v in out.items()if v!=0}
ip=read(O/'provenance_inputs.json');old={r:load(Path(ip['IAG_'+r]))for r in ['primary','replay']};assembly=load(Path(ip['ISD_replay_inputs']))['assembly'];isd=load(Path(ip['ISD_log5_replay']));current=load(O/'integration_tables.json.gz');results=[]
for probe in range(2):
 rr=[]
 for role in ['primary','replay']:
  z=old[role]['results'][probe];gg={k:tab(z['groups_unphased'][k])for k in ['m5_P2','m5_Nh','m5_K3']};N5=plus([(gg['m5_P2'],CI),(gg['m5_Nh'],CI),(gg['m5_K3'],-CI)]);assert N5==tab(z['F_m']['5'])==tab(z['DIM_minus_heat_basis']['log5_over2']);rr.append(N5)
 assert rr[0]==rr[1];N5=rr[0];zz=assembly['outputs'][probe]['formal_basis']['log5'];assert all(not zz[k]for k in ['rho_JLambda_x','rho_Jx','u_Ja_x','u_Jx_C']);assert N5==tab(zz['u_JLambda_C_x'])
 oldH={(r,ww[0],i):val(v)for r,ww,i,v in isd['results'][probe]['formal_basis'][0]['nonminimal']['H']};assert all(len(ww)==1 for r,ww,i,v in isd['results'][probe]['formal_basis'][0]['nonminimal']['H']);newH=tab(next(q for q in current['results'][probe]['formal_basis']if q['basis']=='log5')['known_partial_H_with_scalar_source']);assert N5==oldH==newH
 changes={k:len(v)for k,v in gg.items()};assert probe==0 or all(changes.values());witness=next(iter(sorted(N5.items())),None);results.append({'probe':probe,'five_edge_positions':len(N5),'full_tensor_positions_including_zeros':45*45*328,'omission_changed_positions':changes,'witness':None if witness is None else [*witness[0],str(witness[1])],'old_quantum_tables_reused_not_freshly_replayed':True,'N5_assembly_ISD_current_exact_equality':True})
 print('STAGE USR7_PROVENANCE',json.dumps(results[-1],sort_keys=True),flush=True)
# Independent literal odd Leibniz sign: q acts on even u before JL/C.
par={'u':0,'rho':1,'JL':1,'C':1,'x':0};w=['u','JL','C','x'];flow={'u':['rho']};out=[]
for at,n in enumerate(w):
 if n in flow:out.append(((-1)**sum(par[nn]for nn in w[:at]),w[:at]+flow[n]+w[at+1:]))
assert out==[(1,['rho','JL','C','x'])]
# The reference is scalar in internal slots at the selected zero-transfer
# shell,so this finite matrix check concerns contraction order,not a full
# nonlinear source or BRST Hessian identity.
K=s.Matrix([[2,1],[1,3]]);E=s.Rational(2,5);Gt=E*K.inv();assert K*Gt==E*s.eye(2)and K*Gt!=s.eye(2)
mp.mp.dps=75
def f(u):return (mp.exp(-8*u)-mp.exp(-10*u))/u if u else mp.mpf(2)
radial=mp.quad(f,[0,mp.mpf('.01'),1,mp.inf]);schwinger=mp.quad(lambda a:1/a,[8,10]);expected=mp.log(mp.mpf(5)/4);assert abs(radial-expected)<mp.mpf('1e-68')and abs(schwinger-expected)<mp.mpf('1e-68');assert abs(-radial-expected)>mp.mpf('.4')
# d4q/(2pi)^4 gives dq q^3/(8pi^2);u=tq^2 gives
# (16pi^2)^-1 du/u,so the normalized radial coefficient is log(5/4).
out={'schema':'USR7_PROTECTED_LOG5_PROVENANCE','results':results,'q_u_source_sign':1,'free_heat_edge_contracts_to_E_not_identity':True,'normalized_four_minus_five_edge_radial':str(radial),'radial_parameterization_max_error':str(max(abs(radial-expected),abs(schwinger-expected))),'radial_identity_is_only_candidate_mechanism_not_model_regulator_coefficient':True,'missing_regulator_or_finite_source_operation_not_inferred_by_subtraction':True,'authority_change_anomaly_no_counterterm_theorem':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode()
with(O/'provenance_tables.json').open('xb')as f:f.write(raw)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'tables_sha256':sha256(raw).hexdigest(),'log5_positions_by_probe':[q['five_edge_positions']for q in results],'three_measured_five_edge_groups_and_source_operation_checked':True,'fresh_independent_quantum_regulator_evaluation':False,'finite_regulator_source_contact_dependency_remains_open':True},sort_keys=True),flush=True);timer.cancel()
