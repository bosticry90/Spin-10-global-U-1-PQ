# USR5: background covariance and actual scalar-source operation in H

Prospective after USR4 qualification. Complete Jx Cx coefficient has35824
positions;its antisymmetric/symmetric-current operators16184/27344. All
4841280 positions inclzeros agree in both methods. Symmetric operator,
auxiliary current,widths and R order have sensitive actual controls.

Check all12 residual-H actions on the full source/ghost/scalar tensor,using
actual canonical qC,R and raw unbroken parameter chart. For deltaJx=-Jx RH,
delta x=RH x and deltaC=CH C require -RH Z_h+Z_h RH+sum_k CH[k,h]Z_k=0.
No favorable sign selection;fail/rederive on a nonzero remainder.

Reconstruct D_(i,r) in qJx_i|rho JL=rho JL_r D_ir directly from actual G
monomials (Sigma_E=+i rho JL x*Gcoef gives D=+iGcoef) and compare with the
already qualified ICR matrix. Do not derive D or Z from a Ward remainder.
Contract B_scalar[r,h,j]=sum_i D_ir Z_h[i,j] by independent scalar paths
and matrix association,all664200 positions/probe. chi4/log3 coefficients
are +B,log2=-B,log5=0. Only after contraction add the previous known H sum.

The new unprobed root retires ONE of the three pending H kernels. Intrinsic
JL Cx and aCx remain unmeasured. Preserve a nonzero partial sum and the
unchanged log5 component;do not force restoration or choose chi4. Quantum
source reality,QAP/measure/phase and massive physical limits stay separate.
Review180s afterimports,8GiB sampled,350MiB floor,32MiB packet. Sources,
copies,actual inputs and late-comparison boundary frozen before computation.
