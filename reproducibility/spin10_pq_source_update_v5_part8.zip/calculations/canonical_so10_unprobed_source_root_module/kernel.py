from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import ast,json,gzip,sys,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'kernel_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
src=Path(read(O/'kernel_inputs.json')['exact_helper_source']).read_text();tree=ast.parse(src);fn=['gc','add','scale','mul','mm','ma','ms','const','tr','rat','fracadd','encode'];aa=['ca','cm','cs','cz'];nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in fn or isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id in aa for t in n.targets)];assert len(nodes)==len(fn)+len(aa);ns={'s':s,'F':F,'defaultdict':defaultdict};exec(compile('\n\n'.join(ast.get_source_segment(src,n)for n in nodes),'<USR2_exact_helper_definitions_only>','exec'),ns);gc,add,mm,const,tr,rat,fracadd,encode=[ns[k]for k in ['gc','add','mm','const','tr','rat','fracadd','encode']]
def data(D,axis,q,omitB=False,omitL=False):
 nb=2*D+4;K=s.zeros(nb);J=s.zeros(2,nb);W=s.zeros(nb,2);X=s.zeros(nb);jb=s.I*s.Matrix([[1,2],[-1,3]]);jl=s.Matrix([[2,1],[4,-1]]);xx=s.Matrix([[1,-2],[3,1]]);ww=s.Matrix([[2,-1],[1,3]])
 for a,w in enumerate([2,3]):
  for mu in range(D):K[a*D+mu,a*D+mu]=0 if mu==axis else 1
  K[a*D+axis,2*D+a]=q;K[2*D+a,a*D+axis]=-q;K[2*D+a,2*D+a]=w
  for c in range(2):J[c,a*D+axis]=0 if omitB else q*jb[c,a];J[c,2*D+a]=0 if omitL else jl[c,a]
  for j in range(2):X[a*D+axis,2*D+2+j]=-s.I*q*xx[a,j];X[2*D+2+j,a*D+axis]=s.I*q*xx[a,j]
 for j in range(2):
  K[2*D+2+j,2*D+2+j]=1
  for c in range(2):W[2*D+2+j,c]=ww[j,c]
 return K,J,X,W,xx,ww
def born(D,axis,omitB=False,omitL=False,omitW=False,omit_endpoint=False,omit_classical=False):
 nb=2*D+4;per=nb+4;dim=2*per;ej=dim;ec=dim+1;par=([0]*nb+[1]*4)*2;qfield=lambda mode,i:mode*per+i
 def hess(terms):
  out={}
  def deriv(word,i):
   for at,v in enumerate(word):
    if v==i:yield word[:at]+word[at+1:],(-1)**(par[i]*sum(par[w]if w<dim else 1 for w in word[:at]))
  for mask,co,w in terms:
   for i in set(v for v in w if v<dim):
    for ww,sg in deriv(w,i):
     for j in set(v for v in ww if v<dim):
      for zz,tg in deriv(ww,j):
       assert all(v>=dim for v in zz)
       if len(set(zz))!=len(zz):continue
       sign=sg*tg*(-1)**(par[j]*(par[i]+1)+sum(a>b for k,a in enumerate(zz)for b in zz[k+1:]));mask2=mask|sum(1<<(v-dim)for v in zz);out[i,j]=add(out.get((i,j),{}),{(mask2,0):ns['cs'](co,sign)})
  return out
 K,J,X,W,*_=data(D,axis,1,omitB,omitL);free=[(0,gc(z),(qfield(1,i),qfield(0,j)))for(i,j),z in s.SparseMatrix(K).todok().items()];pert=[]
 for mode in [0,1]:
  other=1-mode;q=1 if mode==0 else-1;K,J,X,W,*_=data(D,axis,q,omitB,omitL)
  for a in range(2):free.append((0,(1,0),(qfield(other,nb+2+a),qfield(mode,nb+a))))
  for(a,j),z in s.SparseMatrix(J).todok().items():pert.append((0,gc(z),(qfield(other,nb+2+a),ec,qfield(mode,j))))
  if not omitW:
   for(j,c),z in s.SparseMatrix(W).todok().items():pert.append((0,gc(z),(ej,qfield(mode,nb+c),qfield(other,j))))
  if mode==0:
   for(i,j),z in s.SparseMatrix(X).todok().items():
    if omit_endpoint and i>=2*D+2:continue
    pert.append((4,gc(z),(qfield(1,i),qfield(0,j))))
 if not omit_classical:pert.extend([(4,(3,0),(ej,ec)),(0,(5,0),(ej,ec,qfield(0,2*D+2)))])
 H0=hess(free);V=hess(pert);K=s.SparseMatrix(dim,dim,{(i,j):s.Integer(v[0])+s.I*v[1]for(i,j),dd in H0.items()for(mask,e),v in dd.items()});M=mm(const(K.inv(),1),V);power=const(s.eye(dim));out={m:(F(0),F(0))for m in [1,2,3]}
 for n in range(1,4):power=mm(power,M);tt=tr(power,par);out[n]=rat(ns['cs'](tt.get((7,n),(0,0)),(-1)**(n+1)),4*n)
 return out
def schur(D,axis,closed=False,omitB=False,omitL=False):
 out=(F(0),F(0))
 for q in [1,-1]:
  K,J,X,W,xx,ww=data(D,axis,q,omitB,omitL);G=K.inv()
  if closed:z=-s.I*s.trace((J[:,:2*D].extract(range(2),[a*D+axis for a in range(2)])*q*s.diag(2,3)+J[:,2*D:2*D+2])*xx*ww)
  else:z=s.trace(J*G*X*G*W)
  out=fracadd(out,rat(gc(s.expand(z)),2))
 return out
fixtures=[];first=None
for D in [3,4,5]:
 for axis in [0,D-1]:
  x=born(D,axis);y=schur(D,axis);z=schur(D,axis,closed=True);assert x[1]==x[2]==(0,0)and x[3]==y==z,(D,axis,x,y,z)
  if first is None:first=x
  else:assert first==x
  fixtures.append({'D':D,'axis':axis,'heat_coefficients':encode(x)})
assert first[3]!=(0,0);controls={'omit_vector_current_changes':born(3,0,omitB=True)!=first,'omit_auxiliary_current_changes':born(3,0,omitL=True)!=first,'omit_source_changes':born(3,0,omitW=True)!=first,'omit_one_literal_Hx_density_endpoint_changes':born(3,0,omit_endpoint=True)!=first,'one_port_source_only_omission_insensitive':born(3,0,omit_classical=True)==first,'collapse_three_edge_heat_loses_log3_over2':first[3]!=(0,0)};assert all(controls.values());mp.mp.dps=70;err=abs(mp.quad(lambda x:(mp.exp(-4*x)-mp.exp(-6*x))/x,[0,1,mp.inf])-mp.log(mp.mpf(3)/2));assert err<mp.mpf('1e-65')
out={'schema':'USR2_SCALAR_SOURCE_ACTUAL_TOPOLOGY_GENERIC_KERNEL','role':role,'fixtures':fixtures,'generic_heat_coefficients':encode(first),'controls':controls,'Frullani_error':str(err),'fixed_Djet0_by_longitudinal_endpoints':True,'relative':'(chi4+log(3/2))*C3','source_density':'Jx_i C_h x_k Z_ihk;no extra half','model_quantum_inputs_used':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('kernel_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'fixtures':len(fixtures),'generic_heat_coefficients':encode(first),'controls':controls},sort_keys=True),flush=True);timer.cancel()
