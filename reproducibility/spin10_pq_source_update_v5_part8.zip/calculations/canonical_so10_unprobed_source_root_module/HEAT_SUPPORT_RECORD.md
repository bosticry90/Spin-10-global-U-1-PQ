# USR6: can the two remaining native kernels affect the formal log5 term?

Prospective after USR5. Complete scalar-source root is measured,covariant,
and integrated. Remaining native H kernels are intrinsic JL Cx and aCx.
Known log5 coefficient still has12432 positions in probe1,zero in probe0.
Do NOT assume the missing roots can cancel every formal constant.

Inventory BOTH remaining unprobed proper-loop domains from the actual full
GF density,original source qLambda and physical kinetic programs. Retain
external antighost in the ordinary target. Include abstract potential cubic/
quartic/mass and fermion mass/Yukawa Hessian SUPERSETS so absence of an
input table is not treated as an amplitude zero. Their grades/ports either
exclude them or prove they cannot join the compulsory target cycle at zero
fermion mean. All grade-zero free two-port kernels are resummed in actual G0.

Targets have total positive grade4: intrinsic1 plus JL/antighost1,ghost1,
scalar1. Each non-reference interaction must consume a positive target grade.
Enumerate directed cycles vs multisets/permutations; prove maximum heat
edges from this grading,not by stopping at an imposed loop length. Each
actual G0 positive-heat edge has length2 in the inherited fixed reference;
an intrinsic N0 insertion is a vertex between TWO such edges. No probe or
reference variation is inserted into these UNPROBED C0 coefficients.

Under the qualified local relative radial rule,an m-edge coefficient lies
in chi4 plus log(m/2),and dimensional jets give algebraic fixed terms. If
all permitted m<=4,these native roots lie in formal span{chi4,log2,log3,1}.
The actual classical B_rho matrices are polynomial/algebraic in g10/xi/eta_H;
they introduce no new formal logarithm. Test this premise explicitly.

Only AFTER support is established compare the old ISD REPLAY log5 H and
the current known log5 H coefficient. If nonzero and invariant under the
missing native inputs,report that necessary missing finite contribution.
This is a FORMAL retained-basis projection with chi4 unselected,not a
transcendence theorem,anomaly,proof no finite counterterm can restore the
theory,or an absolute subtraction prescription. Regulator/source transport,
measure/insertion terms and admissible finite normalization are outside
this native-loop cancellation test and may supply additional terms.

No favorable normalization or new physical scheme is selected. No unknown
kernel coefficient is fitted. Natives300s/review180s,8GiB sampled,350MiB
floor,32MiB packet;all actual inputs/sources/copies bound before computation.
Unexpected heat/source support leaves the proposed exclusion unqualified.
