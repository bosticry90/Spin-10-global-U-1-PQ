# USR1+: the missing common unprobed source-root module

Prospective October25,2026 at1988c60c21fea8fe46c2ed764c3c9537d084f3b1,
V629. Previous goal turn PROGRESS. Fresh preflight clean main,no matching
workers,goal ACTIVE. State113,authority34of39,E5/A5 OPEN,custodyexit2/seven
NOTPASS. Live AGENTS,charter,solo-review and epistemic boundaries apply.
No agent,branch/worktree,remote action,publication,outreach,foundation/scheme/
benchmark adoption,flavor/HB1C5 activation,protected promotion or state edit.

Question: measure the three actual C0 kernels still required by the selected
rho JL Cx conversion identity,rather than solving them from its partial
remainder. Begin marginal Jx Cx,then the intrinsic JL Cx/aCx module if
competent within the frozen continuation. The current known partial H is
nonzero; it cannot decide anomaly/restoration while these inputs are unknown.

Original unshifted SMA/CSW/EDS,A0,zero external jets,unprobed baseline C0,
all45 ghost/gauge/nonminimal and328 real scalar directions,symbolicg10/
xi/eta_H. Jx Cx has intrinsic degree0,the two other kernels degree1. Same
inherited common nonexceptional Euclidean LOCAL RELATIVE DIM-minus-strict-
heat construction,not a physical scalelessp0,massive-vacuum/causal limit,
absolute contact normalization or adopted physical scheme. chi4 stays free
and distinct from b0,kappa and infrared contact freedom. Integration into
B_rho later uses both previously fixed probes,not new parameter choices.

Before model contractions inventory the complete proper loops from actual
Qx source,GaugeFixing density and physical Hessian programs. Preserve one-
port/external derivative terms before target exclusions and resummed free
edges. Prove any fermion-cycle exclusion from the compulsory source ports;
do not turn an absent bosonic table row into a full quantum zero. No desired
ISD H/T/F coefficient or fitted quantum input is a native operand.

For Jx Cx test the proposed three-edge Tr(J0 G Hx G W_scalar) by paired
graded Gaussian vs boson elimination/ghost determinant,retaining the ordinary
auxiliary current,scalar/ghost metric,physical-source Wick/cotangent phases,
full noncommuting order and actual heat length. Prove fixed D-jet by endpoint
support,not finite-D interpolation. If additional actual words occur,extend
the qualified kernel or report incomplete;never omit them to match a proposal.

Test whether the actual K_h=J0_B w+J0_L is antisymmetric before a Lie reduction.
Use the verified R/qC representation only after matching actual charts and
coefficients. A symmetric component,invalid source-phase assumption or
unqualified operator is evidence against that shortcut,not permission to
discard a term. Derive actual quantum coefficients by distinct contraction
routes and sensitive controls before any comparison with the source identity.

Possible outcomes: complete measured kernels and a qualified selected
identity;nonzero independently measured remainder;precise underdefinition;
bounded inconclusiveness. None alone implies full QAP/E5/A5 or physical
unification. Preserve all original failures and shared-assumption limitations.

Sequential native300s/reviewer180s afterimports,8GiB sampled private,
350MiB available-pagefile launch floor,32MiB whole packet. Freeze sources,
copies,inputs and failure conditions before each bounded computation. Full
captures/resources,never truncated evidence or silent resource expansion.
After each bounded result verify and pursue the most informative authorized
dependency. No mechanical coefficient-count target or independent benchmark
platform. Shared action/charts/data/libraries/AI author remain limitations.

Ceiling: common unprobed local relative kernels and selected consequences
whose dependencies are actually complete. Remaining u quadratic-source
contacts,full general BBx,renormalized products,chiral QAP/measure/global
phase,physical source reality and massive/causal physical-domain obligations
remain separate. Goal ACTIVE/INCOMPLETE; machine scientific authority unchanged.
