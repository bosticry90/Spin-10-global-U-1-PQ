# USR8: frozen-result interpretation and independent integration review

Prospective after USR1-7,RESULT and delegated E4 capture. Authenticate all
preparation hashes,executed source copies,exact captures and bounded resource
observations. No failed native is to be hidden. External rejected patch is
pre-source-write evidence,not an executed calculation. Bind supplied
assessments as user reference only. Preserve all original bytes.

Use REPLAY Z and the earlier independently enumerated actual source
operation routes to reconstruct D,then B_rho Z and every known partial H
coefficient. Do not reuse integrate.py or its D reconstruction as a helper.
Only afterward compare the new integration tables,including zero domains.
Recheck the protected five-edge carrier from authenticated old REPLAY groups,
separately test remaining heat support and polynomial operation premises.
Old quantum tables are reused evidence,not a fresh independent loop replay.

Explicitly assess final claim ceilings:nonzero symmetric current retained,
native-log5 exclusion formal only,no fitted regulator coefficient,chi4/b0/
kappa/IR freedoms not identified,no counterterm/anomaly/QAP/E5 promotion.
Existing covariance is authenticated;this is not another fresh full tensor
covariance calculation. Report omitted broader checks/shared premises.
180s afterimports,8GiB sampled private,350MiB floor,32MiB packet. A failure
preserves RESULT,captures and preparations;no silent favorable correction.
