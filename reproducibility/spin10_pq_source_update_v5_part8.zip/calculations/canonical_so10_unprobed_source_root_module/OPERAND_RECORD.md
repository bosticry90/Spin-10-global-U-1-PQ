# USR3: actual scalar-source operands and reduction test

Prospective after generic USR2 kernel qualification. Source/kinetic R charts
must agree,not be identified by name. Primary reuses the authenticated actual
kinetic matrices;replay reconstructs the full raw Qx field/source transport.
Verify scalar/ghost metrics and inverses before using identity contractions.
Keep328 directions including singlets and every zero entry.

Compute all actual K_h=J0_B,h G0_BB+J0_L,h,using complete EDS current and
inverse blocks. Verify the baseline mixed signs/G_LL0 and diagonal width
structure. Split K into antisymmetric and symmetric parts with exact onehalf.
Report both. No assertion that the symmetric part vanishes; a nonzero part
rejects the Lie-commutator-only shortcut and must be retained in the quantum
operator. No unknown Ward value is used to infer K or a coefficient.

This is a classical operand/reduction test,not a measured quantum tensor.
Its result chooses the cheapest complete contraction method without changing
the kernel,action,source conventions,limits or authority. Both routes compare
full R/K matrices and zero complements. Natives300s/review180s,8GiB sampled,
350MiB floor,32MiB packet. Actual input hashes/sources/copies frozen first.
