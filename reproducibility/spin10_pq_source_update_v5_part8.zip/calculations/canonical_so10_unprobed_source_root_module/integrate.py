from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'integration_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
sys.path.insert(0,str(Path(read(O/'color_inputs.json')['coefficient_ring_source']).parent));from coefficient_ring import coefficient,expression,I as CI
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def val(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
def dec(z):return {(i,j):val(v)for i,j,v in z['entries']}
def tidy(z):return{k:v for k,v in z.items()if v!=0}
def plus(terms):
 out=defaultdict(lambda:0)
 for z,f in terms:
  for k,v in z.items():out[k]+=f*v
 return tidy(out)
def mm(A,B):
 by=defaultdict(list);out=defaultdict(lambda:0)
 for(i,j),v in B.items():by[i].append((j,v))
 for(i,k),v in A.items():
  for j,w in by[k]:out[i,j]+=v*w
 return tidy(out)
def enc(z):return [[*k,str(v)]for k,v in sorted(z.items())]
ip=read(O/'integration_inputs.json');o=load(O/'operands_primary_tables.json.gz');inp=load(O/'operands_primary_inputs.json.gz');R=list(map(dec,o['R']));Z=[{(i,j):val(v)for i,j,v in q['total_operator']}for q in load(O/'color_primary_tables.json.gz')['by_ghost']];qc={tuple(z[:-1]):val(z[-1])for z in o['qC']};frame=inp['frame'];xs=inp['xs'];aux=[('b'if i<12 else'L')+str(i)for i in range(45)];cs=['C'+str(i)for i in range(45)];ants=[('bar'if i<12 else'ub')+str(i)for i in range(45)];phys=[f'B{i}_{mu}'for i in range(45)for mu in range(4)]+xs+aux+cs+ants;ri={n:i for i,n in enumerate(frame['field_order'])};pi={n:i for i,n in enumerate(phys)};ff=frame['physical_to_raw_kernel'];FC={(i,j):val(v)for i,j,v in ff['entries']if i in[pi[n]for n in cs]and j in[ri[n]for n in cs]};fc={(c,h):FC.get((pi[cs[c]],ri[cs[h]]),0)for c in range(45)for h in range(12)};cov=[]
for h in range(12):
 RH=defaultdict(lambda:0);CH=defaultdict(lambda:0)
 for c,M in enumerate(R):
  if fc[c,h]:
   for ij,v in M.items():RH[ij]+=fc[c,h]*v
 for(k,a,b),v in qc.items():CH[k,b]+=fc[a,h]*v;CH[k,a]-=fc[b,h]*v
 RH=tidy(RH);CH=tidy(CH);by=defaultdict(list)
 for(k,c),v in CH.items():by[c].append((k,v))
 counts=[]
 for c,M in enumerate(Z):
  zz=plus([(mm(RH,M),-1),(mm(M,RH),1)])
  for k,v in by[c]:zz=plus([(zz,1),({ij:v*z for ij,z in Z[k].items()},1)])
  counts.append(len(zz))
 assert not any(counts),('scalar_source_H_covariance_failed',h,counts);cov.append(counts);print('STAGE USR5_H_COV',h,flush=True)
assert all(not any(i>=326 or j>=326 for i,j in M)for M in Z)
# Direct reconstruction of the source-scalar operation,not its quantum target.
dd=load(Path(ip['G_audit']))['audit'];names=dd['names'];geo=dd['geometry'];base=geo['names'];src={names.index(base[J]):base[f]for f,J,h,k in geo['field_source_h_k']};ai={n:i for i,n in enumerate(aux)};xid={n:i for i,n in enumerate(xs)}
def co(p,ci,gp):
 z=0
 for xp,ep,mask,num,den in p['coefficients'][ci]:
  v=s.Rational(num,den)*xi**xp*eta**ep
  for j,q in enumerate([2,3,5,7]):
   if mask&(1<<j):v*=s.sqrt(q)
  if mask&16:v*=s.I
  z+=v
 return coefficient(s.expand(z*g**gp))
old=load(Path(ip['late_partial_H']));results=[]
for probe,p in enumerate(dd['physical_G']):
 D=defaultdict(lambda:0)
 for gp,w,ci in p['monomials']:
  if len(w)!=2 or any(I for n,I in w):continue
  js=[(at,n)for at,(n,I)in enumerate(w)if n in src]
  if len(js)!=1:continue
  at,n=js[0]
  if src[n]not in ai:continue
  other=w[1-at][0]
  if names[other]not in xid:continue
  D[xid[names[other]],ai[src[n]]]+=CI*co(p,ci,gp)
 D=tidy(D);expected={tuple(q[:-1]):val(q[-1])for q in old['results'][probe]['pending_operation_matrices']['C_Jx_x']};assert D==expected;DT={(r,i):v for(i,r),v in D.items()};B={}
 for h,M in enumerate(Z):
  z=mm(DT,M)
  # Different association: accumulate each quantum root row into its
  # associated source-flow columns before comparing the full tensor.
  byD=defaultdict(list)
  for(i,r),v in D.items():byD[i].append((r,v))
  replay=defaultdict(lambda:0)
  for(i,j),v in M.items():
   for r,z0 in byD[i]:replay[r,j]+=z0*v
  assert z==tidy(replay)
  for(r,j),v in z.items():B[r,h,j]=v
 per=[]
 for basis,f in [('chi4',1),('log2',-1),('log3',1),('log5',0)]:
  contribution={k:f*v for k,v in B.items()}if f else{};prior=next(q for q in old['results'][probe]['formal_basis']if q['basis']==basis);known={tuple(q[:-1]):val(q[-1])for q in prior['known_partial_H']};remaining=plus([(known,1),(contribution,1)]);per.append({'basis':basis,'measured_scalar_source_BrhoC0':enc(contribution),'known_partial_H_with_scalar_source':enc(remaining),'two_intrinsic_root_kernels_still_unmeasured':True})
 results.append({'probe':probe,'source_operation_D':enc(D),'formal_basis':per});print('STAGE USR5_PARTIAL',probe,[(q['basis'],len(q['measured_scalar_source_BrhoC0']),len(q['known_partial_H_with_scalar_source']))for q in per],flush=True)
out={'schema':'USR5_SCALAR_SOURCE_ROOT_COVARIANCE_AND_H_INTEGRATION','results':results,'all12_H_covariance_remainders':cov,'all_source_scalar_positions_per_probe_basis':45*45*328,'remaining_H_quantum_roots':['intrinsic JL Cx','intrinsic aCx'],'source_operation_reconstructed_not_fitted':True,'singlet_source_and_scalar_rows_exact_zero':True,'full_H_identity_QAP_E5_A5_or_anomaly':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'integration_tables.json.gz').open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'all12_H_covariance_and_independent_operation_contractions_pass':True,'probe_basis_new_B_partial_positions':[[[q['basis'],len(q['measured_scalar_source_BrhoC0']),len(q['known_partial_H_with_scalar_source'])]for q in p['formal_basis']]for p in results],'remaining_quantum_root_families':2,'no_full_restoration_or_anomaly_inferred':True},sort_keys=True),flush=True);timer.cancel()
