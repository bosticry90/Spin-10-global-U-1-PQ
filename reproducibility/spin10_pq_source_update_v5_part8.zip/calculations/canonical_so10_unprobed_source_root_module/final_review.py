from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'final_review_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
copies=bindings=captures=0;peak=0
for p in O.glob('*.source.txt'):assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes();copies+=1
for p in O.glob('*preparation*.json'):
 for f,h in read(p).get('input_sha256',{}).items():assert H(Path(f))==h,(p,f);bindings+=1
for p in O.glob('*capture.json'):
 z=read(p);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2;peak=max(peak,max(v['private_bytes']for v in z['all_resource_samples']));captures+=1
assert captures==17 and peak<=8*1024**3 and sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2
ip=read(O/'final_review_inputs.json');patch=read(Path(ip['pre_source_patch_failure']));assert 'FAILED_PRE_SOURCE_WRITE'in str(patch)
sys.path.insert(0,str(Path(read(O/'color_inputs.json')['coefficient_ring_source']).parent));from coefficient_ring import coefficient,I as CI
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def val(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
def tab(z):return {tuple(q[:-1]):val(q[-1])for q in z}
def plus(terms):
 out=defaultdict(lambda:0)
 for z,f in terms:
  for k,v in z.items():out[k]+=f*v
 return {k:v for k,v in out.items()if v!=0}
Z=load(O/'color_replay_tables.json.gz')['by_ghost'];ops=load(Path(ip['root_routes']))['results'][0]['probes'];prior=load(Path(ip['prior_partial_H']));now=load(O/'integration_tables.json.gz');xs=[f'x_{sec}_{i}'for sec,n in [('Phi',54),('Sigma',252),('phi',20),('S',2)]for i in range(n)];xid={n:i for i,n in enumerate(xs)};counts=[];checked=0
for probe in range(2):
 D=defaultdict(lambda:0)
 for row in ops[probe]['routes']:
  if row['root']==['C','Jx','x']:
   assert row['flow_output'].startswith('Jx_')and len(row['flow_remaining_word'])==1;name,jets=row['flow_remaining_word'][0];assert name.startswith('JL')and not jets;D[xid[row['flow_output'][1:]],int(name[2:])]+=val(row['operation_coefficient'])
 D={k:v for k,v in D.items()if v!=0};assert D==tab(now['results'][probe]['source_operation_D']);by=defaultdict(list)
 for(i,r),v in D.items():by[i].append((r,v))
 B=defaultdict(lambda:0)
 for z in Z:
  h=z['h']
  for i,j,v in z['total_operator']:
   for r,t in by[i]:B[r,h,j]+=t*val(v)
 B={k:v for k,v in B.items()if v!=0};per=[]
 for basis,f in [('chi4',1),('log2',-1),('log3',1),('log5',0)]:
  new={k:f*v for k,v in B.items()}if f else{};old=tab(next(q for q in prior['results'][probe]['formal_basis']if q['basis']==basis)['known_partial_H']);full=plus([(old,1),(new,1)]);q=next(q for q in now['results'][probe]['formal_basis']if q['basis']==basis);assert new==tab(q['measured_scalar_source_BrhoC0'])and full==tab(q['known_partial_H_with_scalar_source']);checked+=2*45*45*328;per.append([basis,len(new),len(full)])
 counts.append(per)
for role in ['primary','replay']:
 heat=load(O/('heat_support_'+role+'_tables.json.gz'));assert all(q['max_heat_edges']==4 and not q['abstract_superfamily_word_occurrences']for q in heat['results']);assert[(q['target'],len(q['ordered_words']))for q in heat['results']]==[('JL_Cx',82),('a_Cx',466)]
assert not any(now['all12_H_covariance_remainders'][h][c]for h in range(12)for c in range(45))
old=load(Path(read(O/'provenance_inputs.json')['IAG_replay']));proof=read(O/'provenance_tables.json');five=[]
for probe in range(2):
 groups=old['results'][probe]['groups_unphased'];N=plus([(tab(groups['m5_P2']),CI),(tab(groups['m5_Nh']),CI),(tab(groups['m5_K3']),-CI)]);q=next(q for q in now['results'][probe]['formal_basis']if q['basis']=='log5');assert N==tab(q['known_partial_H_with_scalar_source']);five.append(len(N))
assert five==[0,12432]and proof['q_u_source_sign']==1 and proof['radial_identity_is_only_candidate_mechanism_not_model_regulator_coefficient'];assert N[13,0,137]==val('-sqrt(6)*I*eta_H*g10**4*xi/16')
for q in prior['results']:
 for k in ['C_JL_x','C_a_x']:
  for *ix,v in q['pending_operation_matrices'][k]:z=s.sympify(v,locals=loc);assert not z.has(s.log)and z.free_symbols<={g,xi,eta};s.Poly(z,g,xi,eta)
assert now['remaining_H_quantum_roots']==['intrinsic JL Cx','intrinsic aCx']and not now['full_H_identity_QAP_E5_A5_or_anomaly']
e=read(Path(ip['E4']));events=[json.loads(q)for q in e['stdout_and_stderr'].splitlines()];assert e['native_exit']==0 and[q['exit_code']for q in events if q['event']=='step_finished']==[0,0,0,0,0,2]and events[-1]['execution_state']=='COMPLETED';assert H(O.parents[1]/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
report=(O/'RESULT.md').read_text();assert all(z in report for z in ['not an anomaly','not a new independent replay','candidate mechanism','native kernels','chi4 remains unselected','symmetr','ACTIVE/INCOMPLETE'])
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'all_preparation_bindings_checked':bindings,'frozen_source_copies_equal':copies,'pre_final_review_captures_completed':captures,'largest_pre_review_private_sample':peak,'actual_source_routes_vs_direct_G_D_and_replay_quantum_integration_pass':True,'full_positions_compared_by_sparse_zero_completion':checked,'probe_basis_B_and_partial_H_positions':counts,'protected_five_edge_counts_and_exact_witness_checked':five,'remaining_native_heat_support_excludes_formal_log5_only':True,'old_covariance_receipt_authenticated_not_fresh_full_replay':True,'two_native_roots_unmeasured_and_regulator_source_term_not_fitted':True,'E4_declared_exits_and_unchanged_state_pass':True,'full_QAP_E5_A5_anomaly_or_physical_promotion':False},sort_keys=True),flush=True);timer.cancel()
