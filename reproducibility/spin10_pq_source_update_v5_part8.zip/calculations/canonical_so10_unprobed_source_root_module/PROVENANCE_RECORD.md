# USR7: provenance of the protected formal log5 component

Prospective after qualified USR6. Reuse authenticated IAG heat-resolved
quantum tables rather than rerunning an expensive qualified contraction.
This is an exact provenance/operation audit,not an independent fresh loop
measurement. USR6 has excluded log5 from the two missing native C0 roots.

Reconstruct the actual five-edge coefficient from the three separately
measured IAG groups,with the qualified phases:

    N5=i(P2+Nh-K3).

Compare both original methods,all coefficients and implicit zeros. Test
each omitted group. Only after reconstruction compare the log5 source
assembly and old ISD H,then the current known H. The operation du=rho
must retain the plus sign with rho before the odd JL/C factors. All other
measured log5 source carriers must be checked,not presumed absent.

Retain an exact nonzero witness with its ghost/source/scalar indices and
unselected symbolic parameters. Do not call its negative an independently
calculated regulator insertion or infer an anomaly/counterterm obstruction.

For the NEXT calculation only,verify the elementary free-edge identity
H0 Gt=E (not I),Gt=E G0,E=exp(-2t q^2). A Ward contraction can therefore
leave an extra heat factor. The difference of four/five-edge radial terms
has local finite value log(5/4)/(16pi^2). Check the Frullani value using
two radial parameterizations at high precision,including a sign-reversal
control. This demonstrates a POSSIBLE heat-length mechanism,not that this
defect with any chosen coefficient is the actual complete model Ward term.
No missing quantum coefficient is fitted or derived from cancellation.

Acceptance: exact IAG->source assembly->ISD->current tensor equality,
all three groups sensitively tested when nonzero,plus literal source sign
and radial identity. Report underdefinition on any mismatch. Same original
local relative Euclidean domain,chi4 free,b0/kappa/IR freedoms distinct.
No physical scheme,foundation,action or authority change. Native/review180s
afterimports,8GiB sampled private,350MiB launch floor,32MiB packet. Freeze
sources,copies,input hashes before computation. Full QAP/E5/A5 open.
