from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-source-root-module-v1-2026-10-25');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'provenance_preparation.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 D=O.parent/'canonical_so10_intrinsic_correlated_source_contacts';ip={'root_routes':str(D/'roots_v2_replay_tables.json.gz'),'prior_partial_H':str(D/'partial_H_tables.json.gz'),'E4':str(C/'e4_full_capture.json'),'pre_source_patch_failure':str(C/'color_source_patch_failure.json'),'supplied_assessments':['C:/Users/psboy/.codex/attachments/02f1e4bb-55d7-43ab-addd-e39a66fab3af/Pasted text.txt','C:/Users/psboy/.codex/attachments/4aca9a79-16bb-4217-984d-46de2d6dc0dd/Pasted text.txt']};dump(O/'final_review_inputs.json',ip)
 for p in [Path(ip[k])for k in ['root_routes','prior_partial_H','E4','pre_source_patch_failure']]+[Path(v)for v in ip['supplied_assessments']]:b[str(p)]=H(p)
 for n in ['RESULT.md','FINAL_REVIEW_RECORD.md','final_review.py','run_final_review.py']:
  p=O/n;cp=O/(n+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
 for p in O.iterdir():
  if p.is_file():b[str(p)]=H(p)
 for p in [R/'AGENTS.md',R/'project_state.json']:b[str(p)]=H(p)
 dump(O/'final_review_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
 z=capture([sys.executable,'-B',str(O/'final_review.py')]);dump(O/'final_review_capture.json',z);dump(C/'final_review_full_capture.json',z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
 rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<180;dump(O/'final_review_validation_receipt.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2;print(json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'final_review_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
