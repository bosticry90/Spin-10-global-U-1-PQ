from pathlib import Path
from hashlib import sha256
import json,gzip,time
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter()
for p,h in read(O/'operands_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('operands_'+r+'_tables.json.gz'))for r in ['primary','replay']]
for z in [a,b]:z.pop('role')
assert a==b
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'kinetic_R_vs_full_raw_source_transport_all_coefficients_and_zeros_agree':True,'all_K_antisymmetric_symmetric_parts_and_actual_metrics_agree':True,'R_sha256':a['R_sha256'],'K_anti_sym_positions':[sum(len(M['entries'])for M in a[k])for k in ['K','K_antisymmetric','K_symmetric']],'new_quantum_coefficient_QAP_E5_A5_not_inferred':True},sort_keys=True),flush=True)
