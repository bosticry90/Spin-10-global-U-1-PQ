# USR4: complete quantum Jx Cx tensor,retaining the symmetric current

Prospective after USR3. Actual kinetic/source R agree across all328x328x45
positions;R has12560 nonzero coefficients. Actual K/A/S totals1340/1340/
668. Thus K is NOT antisymmetric. No commutator-only shortcut is justified
until the symmetric operator itself is calculated,and it must be retained
if nonzero. Do not change K,source phases or the regulator to remove it.

Compute the COMPLETE measured coefficient
 Z_h=-i sum_ca K_h[c,a] R_c R_a.
Native primary performs explicit directed scalar-index products with full K.
Replay splits K=A+S: sum_(c<a) A_ca [R_c,R_a] is reduced with the actual
qC representation,while S_ca{R_c,R_a} plus diagonal terms are evaluated in
the full scalar representation. Include source singlets and every implicit
zero. No division by g10 or physical input is allowed. Compare complete
anti/sym/total operators and all4841280 positions,not a selected source flow.

Use the previously qualified unbounded Fraction/multiquadratic polynomial
ring to avoid expensive repeated SymPy expansion. Bind its source,verify
all1024 basis products and roundtrip EVERY actual operand before arithmetic.
No fixed-width integer,tolerance,numeric parameter specialization or hidden
truncation. Sparse caches and coefficient dictionaries do not change coverage.

Retain model controls for omitting the symmetric part,auxiliary current,
width distinctions and reversing R order. Record insensitive controls honestly.
Actual output is (chi4+log(3/2))*Z_h,not a fitted finite normalization.
Natives300s/review180s,8GiB sampled,350MiB floor,32MiB whole packet. Freeze
sources/copies/bindings first. No desired ISD H or partial remainder operand.
