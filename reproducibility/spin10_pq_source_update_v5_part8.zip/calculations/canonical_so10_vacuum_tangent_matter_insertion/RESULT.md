# HPI1: completed trial with scientific interpretation withheld

All three native roles completed with exit0. Primary/replay/verifier took
341.771950/211.581279/244.627018 seconds after imports, within the frozen caps.
Their internal comparison records +B_R K_scalar/2 over671744 tensor positions,
including4352 nonzero holomorphic entries. Full captures, source copies,
tables, manifests and the generated receipt are preserved unchanged.

That receipt's QUALIFIED label describes the implemented internal checks.
It is not accepted here as a qualification of the actual action insertion.
Both routes share an untested identification between open-line chains and
the alternating external quadratic kernel. Agreement cannot validate that
shared interpretation. The literal compact insertion has ghost momentum
opposite to the S field momentum in its mixed propagator. Its Gaussian
contraction must be reconstructed with charge conjugation and external
antisymmetrization before assigning the physical kernel sign.

The separate HPR1 continuation in canonical_so10_vacuum_tangent_insertion_routing
freezes this explicit reconciliation. Its new operator witnesses must decide
the sign before comparison with any MFC target. HPI1's costly45-generator
transport need not be repeated: qualified YCT covariance and paired VTS
scalar kernels already determine the color reduction once the unit is fixed.

Execution COMPLETED is distinct from scientific validity. This is preserved
trial evidence with an identified shared-assumption limitation, not a new
Slavnov restoration, anomaly or E5/A5 result. Authority34/39 remains unchanged.
