"""HPI1 exterior Gaussian, Clifford algebra, Schwinger variance and scalar K."""
from data import *
from collections import defaultdict
start=begin('replay')
def add(A,B):
 out=dict(A)
 for k,v in B.items():out[k]=s.expand(out.get(k,0)+v)
 return {k:v for k,v in out.items() if v}
def mul(A,B):
 out=defaultdict(lambda:s.S.Zero)
 for a,x in A.items():
  for b,y in B.items():
   if a&b:continue
   inv=sum((b&((1<<i)-1)).bit_count() for i in range(7) if a&(1<<i));out[a|b]+=(-1)**inv*x*y
 return {k:s.expand(v) for k,v in out.items() if s.expand(v)!=0}
def word(w,c):
 out={0:c}
 for i in w:out=mul(out,{1<<i:1})
 return out
f,q,y,th,x=s.symbols('f q y th x',nonzero=True)
action={}
for w,c in [([5,6],-f),([3,4],-q),([6,2],y*x),([0,4],th*x)]:action=add(action,word(w,c))
Z=term={0:s.S.One}
for j in range(1,6):term={k:-v/s.Integer(j) for k,v in mul(term,action).items()};Z=add(Z,term)
internal=sum(1<<j for j in [3,4,5,6]);base=Z[internal];inserted=mul(word([3,5,1],1),Z)
wick=s.simplify(inserted[(1<<7)-1]*f*q/(base*y*th*x*x))
# h commutes with physical chirality; h*h=H. The endpoint signs arise from
# the two actual iE vertices and the one mixed propagator, independently of
# any source target. The conjugate projectors exchange their charge symbols.
raw=[(-s.I)*(-1),(+1)*(-s.I)];anti=list(raw)
eps,dh,mu=s.symbols('epsilon dhat mIR2',positive=True)
# Independent bar/hat Gaussian integration and Schwinger parameter u:
# hat variance dh/(2u), total gaussian u^(-D/2), denominator1/Gamma(3).
reg=dh*s.gamma(1+eps)*mu**(-eps)/(2*s.gamma(3))
moment=s.simplify(s.diff(reg.subs(dh,-2*eps),eps).subs(eps,0));units=[s.simplify(wick*u*moment) for u in raw]
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');K=dec(packed(CAL/'canonical_so10_vacuum_tangent_source_kernel/replay_tables.json.gz')['kernel_unit'])
H=dec(Y['H_new']);pm=tidy(s.eye(45)-H*H.T)
# Independent scalar covariance reduction: left+right color=i B K.
# Since U=-T^T, the two raw units contribute equal halves on symmetric B.
models=[]
for carrier in ['10','126']:
 B=dec(Y['B'+carrier]);total=tidy(s.I*units[0]*B*K)
 # Do not assert equality of the individual endpoints from the total. Their
 # difference is the commutator [Casimir,M], reconstructed by index action.
 T=list(map(dec,Y['Tminus']));C=s.zeros(16)
 for a in range(45):
  for b in range(45):
   if pm[a,b]:C+=pm[a,b]*T[a]*T[b]
 C=tidy(C);diff=s.SparseMatrix(256,328,{})
 for (flat,j),co in B.todok().items():
  u,v=divmod(flat,16)
  for r in range(16):
   if C[u,r]:diff[r*16+v,j]+=co*C[u,r]
   if C[v,r]:diff[u*16+r,j]-=co*C[v,r]
 # raw right-left endpoints give (M C-C^T M)/2 with their actual unit.
 ec=tidy((total+(-s.I*units[0])*diff)/2);es=tidy(total-ec)
 models.append({'carrier':carrier,'right_endpoint':enc(ec),'left_endpoint':enc(es),'total':enc(total),'antiholomorphic':enc(tidy(s.conjugate(total)))})
print('STAGE INDEPENDENT_EXTERIOR_SCHWINGER_SCALAR_CASIMIR',flush=True)
finish('replay',{'method':'exterior_Gaussian_abstract_Clifford_Schwinger_variance_scalar_Casimir','raw_units':list(map(str,raw)),'conjugate_raw_units':list(map(str,anti)),'wick_unit':str(wick),'finite_moment':str(moment),'units':list(map(str,units)),'heavy_projector':enc(pm),'models':models,'proper_topologies':1,'ordered_endpoints':2,'external_h_columns':328,'mass_orbit_insertions_allowed_at_critical_degree':0},start)
