# HPI1: graph support, signs and admissible interpretation

Use compact SMA iE with external physical fermions at hats0. Its derivative
on an external P is zero. The derivative on its internal ghost need not be
zero: sewing its S leg to a Yukawa P leg supplies a second internal hat.
The actual Euclidean open vertices are -g hat_slash A_a on the right and
+g Atilde_a hat_slash on the left. The mixed free propagator is
-i hat_slash/Q. The tangent vertex is +g xi h_A a_s T_s,jA x_j and the
ordered ghost propagator is <C a>=+1/Q in the bound raw maps.

The two open spin chains are

    Tau (-i hat_slash) (-hat_slash A),
    (Atilde hat_slash) (-i hat_slash) Tau.

Do not insert another closed-fermion sign or Pfaffian half. The action's
Yukawa1/2 cancels its two external/internal polarizations; expressing the
result as a quadratic form1/2 P^T K P retains both ordered endpoints.
For the compact odd insertion and the two even action vertices, the word
C,S,P1,h,a,p,P2 has the same parity as h,P1,P2,C,a,S,p. The expansion of
exp(-V) contributes two action minus signs. Both facts are checked by a
separate exterior-Gaussian integral in the replay.

In units16pi^2 the common integral is

    I0 = int d^D k hat k^2/(k^2+m_IR^2)^3.

Keep the formal hat dimension d_hat=-2epsilon until after integration.
Its Gaussian factor is d_hat/D; Gamma integration yields a finite term
through d_hat/epsilon. The second method obtains the moment by differentiating
the independent hat Schwinger variance. A common positive auxiliary IR mass
is used only to extract the local coefficient. Convergent completion changes
vanish with explicit d_hat. No physical p=0 massive trace limit is taken.

Let P_M be the actual heavy plane projector from the raw ghost/dual maps.
For a tangent h, put tau_a(h)=B rho_a h, with the authenticated covariance
B rho_a h=i(Ta^T B(h)+B(h)Ta). The two physical-color endpoints contain
tau_a(h) Tb and Tb^T tau_a(h), contracted with P_M,ab. Keep their order.
Their sum can independently be reduced using

    K_scalar = -sum_ab P_M,ab rho_a rho_b.

The primary contracts fermion endpoints; the replay uses the independently
qualified scalar Casimir K_scalar. This reuses the full45 covariance theorem
and VTS tensors rather than rerunning thousands of old action contractions.
All general h columns, both Yukawa carriers, both endpoints, and the
conjugate chirality are part of the new comparison.

One-loop proper support follows directly from valence. Ihat has one ghost,
one S and one P. The external h occurs only in the cubic h-a-x vertex.
Connecting C to a and S to a P-only Yukawa vertex leaves one scalar and
two external physical fermions, closing one three-edge loop. The alternative
with both external fermions on the Yukawa vertex has a scalar bridge and
is reducible. An additional mass/orbit insertion lowers UV degree and cannot
contribute to this local zero-jet dimension-five coefficient without forbidden
inverse dimensional parameters. The derivative-on-external-P class vanishes
before integration. There is no independent h derivative of Ihat itself.

The coefficient of this dimensional iE insertion is not the regulated
heat-side response. In a heat calculation the full ordered G_t R_t M and
the extended source/parameter terms must still be evaluated or connected by
a proved identity in a common domain. The MFC diagnostic is also not such
an identity. Do not infer a heat correction by naming their difference a
measured regulator insertion. This packet deliberately leaves that bridge
as the next scientific obligation.
