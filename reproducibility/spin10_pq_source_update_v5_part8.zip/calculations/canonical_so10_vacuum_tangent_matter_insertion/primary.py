"""HPI1 explicit spin, ordered Wick parity, Gamma moment and fermion colors."""
from data import *
from functools import lru_cache
start=begin('primary')
@lru_cache(None)
def simp(x):return s.simplify(x)
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g4=[s.kronecker_product(pa[1],v) for v in pa]+[s.kronecker_product(pa[0],s.eye(2))]
gam=[s.kronecker_product(v,pa[2]) for v in g4]+[s.kronecker_product(s.eye(4),v) for v in pa[:2]]
chi=s.prod(gam[:4]);PL=(s.eye(8)+chi)/2;PR=s.eye(8)-PL
k,l=s.symbols('khat lhat',real=True);hh=k*gam[4]+l*gam[5];HH=k*k+l*l;zero(hh*hh-HH*s.eye(8));zero(hh*chi-chi*hh)
a,b,n,nd=s.symbols('a b n nd');Aa=a*PL+b*PR;At=b*PL+a*PR;Tau=n*PL+nd*PR
chains=[Tau*(-s.I*hh)*(-hh*Aa),(At*hh)*(-s.I*hh)*Tau]
raw=[];anti=[]
for m,cl,cr in zip(chains,[n*a,b*n],[nd*b,a*nd]):
 u=simp(s.trace(PL*m)/(s.trace(PL)*HH*cl));v=simp(s.trace(PR*m)/(s.trace(PR)*HH*cr));zero(m*PL-u*HH*cl*PL);zero(m*PR-v*HH*cr*PR);raw.append(u);anti.append(v)
# Canonical exterior order h,P1,P2,C,a,S,p, with <C a> and <S p> positive.
word=[3,5,1,0,4,6,2];parity=(-1)**sum(word[i]>word[j] for i in range(7) for j in range(i+1,7));wick=parity*(-1)**2
eps,h,mu=s.symbols('epsilon dhat mIR2',positive=True);D=4-2*eps
regular=h/D*mu**(-eps)*s.gamma(1+D/2)*s.gamma(1+eps)/(s.gamma(D/2)*s.gamma(3))
moment=simp(s.diff(regular.subs(h,-2*eps),eps).subs(eps,0));units=[simp(wick*u*moment) for u in raw]
print('STAGE ORDERED_SPIN_AND_DIMENSIONAL_MOMENT',flush=True)
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));I=s.eye(16)
vts=packed(CAL/'canonical_so10_vacuum_tangent_source_kernel/primary_tables.json.gz');CG=dec(vts['raw_ghost_Green_unit'])
phys=read(PK/'frozen_a10_physical_reconciliation/full_primary.json');Q=dec(phys['C3_plane_to_parent'])
e1=read(PK/'frozen_a10_e1_fermion/primary.json');FM=dec(e1['charts']['blocks']['heavy_dual']['field_embedding'])
pm=tidy(Q*CG[:,12:]*FM.T);zero(pm-pm.T);zero(pm*pm-pm)
Ts=[tidy(sum((pm[a,b]*T[b] for b in range(45) if pm[a,b]),s.zeros(16))) for a in range(45)]
left=s.SparseMatrix(256,256,{});right=s.SparseMatrix(256,256,{})
for a in range(45):
 # B rho_a=i(Ta^T B+B Ta), followed by the actual two ordered endpoints.
 La=s.SparseMatrix(s.kronecker_product(T[a].T,I)+s.kronecker_product(I,T[a].T))
 right+=s.I*s.kronecker_product(I,Ts[a].T)*La
 left+=s.I*s.kronecker_product(Ts[a].T,I)*La
models=[]
for carrier in ['10','126']:
 B=dec(Y['B'+carrier]);ec=tidy(units[0]*right*B);es=tidy(-units[1]*left*B)
 # The conjugate spin projector has U=-T^T at the right endpoint and T at
 # the left. Derive those signs before comparing with complex conjugation.
 ac=tidy(-wick*anti[0]*moment*s.conjugate(right*B));al=tidy(wick*anti[1]*moment*s.conjugate(left*B))
 models.append({'carrier':carrier,'right_endpoint':enc(ec),'left_endpoint':enc(es),'total':enc(tidy(ec+es)),'antiholomorphic':enc(tidy(ac+al))})
print('STAGE COMPLETE_FERMION_ENDPOINT_TRANSPORT',flush=True)
finish('primary',{'method':'explicit_gamma8_ordered_Wick_Gamma_integral_raw_projector_fermion_endpoints','raw_units':list(map(str,raw)),'conjugate_raw_units':list(map(str,anti)),'wick_unit':str(wick),'finite_moment':str(moment),'units':list(map(str,units)),'heavy_projector':enc(pm),'models':models,'proper_topologies':1,'ordered_endpoints':2,'external_h_columns':328,'mass_orbit_insertions_allowed_at_critical_degree':0},start)
