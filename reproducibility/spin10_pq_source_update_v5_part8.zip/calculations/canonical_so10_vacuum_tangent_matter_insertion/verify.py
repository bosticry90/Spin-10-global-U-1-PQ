"""HPI1 late comparison, complete zero complements and sensitive controls."""
from data import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');assert P['method']!=R['method']
for k in P:
 if k not in ['method','elapsed_after_imports']:assert P[k]==R[k],k
assert P['proper_topologies']==1 and P['ordered_endpoints']==2 and P['external_h_columns']==328
assert P['wick_unit']=='1' and P['finite_moment']=='-1/2' and P['raw_units']==['I','-I']
K=dec(packed(CAL/'canonical_so10_vacuum_tangent_source_kernel/replay_tables.json.gz')['kernel_unit'])
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');v=dec(read(PK/'frozen_a10_physical_reconciliation/full_primary.json')['vacuum']['VEV'])
xi=s.Symbol('xi',real=True);logr=s.log(s.Rational(3,2));full=0;totalnz=0;controls={};projected=[]
old=packed(CAL/'canonical_so10_fermion_mass_finite_comparison/local_mass_comparison_member.json.gz')
for j,model in enumerate(P['models']):
 B=dec(Y['B'+model['carrier']]);ec,es,mat,anti=[dec(model[n]) for n in ['right_endpoint','left_endpoint','total','antiholomorphic']]
 zero(mat-ec-es);zero(anti-s.conjugate(mat));zero(mat-B*K/2)
 for n in ['right_endpoint','left_endpoint','total','antiholomorphic']:
  mm=dec(model[n]);zero(mm-dec(R['models'][j][n]));full+=mm.rows*mm.cols
 # Transpose of each physical mass bilinear, for every tangent column.
 for n in ['total','antiholomorphic']:
  mm=dec(model[n]);dd=mm.todok()
  for (flat,col),co in dd.items():a,b=divmod(flat,16);assert s.simplify(co-dd.get((b*16+a,col),0))==0
 mass=s.Matrix(16,16,list(B*v));atv=tidy(xi*mat*v);zero(s.Matrix(16,16,list(atv))-s.Rational(25,4)*xi*mass)
 # This is only an algebraic comparison. No heat-side identity is assumed.
 defect=dec(old['projected_comparisons'][j]['raw_projected_comparison_defect']);difference=tidy(s.Matrix(16,16,list(atv))-defect)
 projected.append({'carrier':model['carrier'],'dimensional_iE_at_v':enc(s.Matrix(16,16,list(atv))),'MFC_raw_parent_diagnostic':enc(defect),'algebraic_difference_only_not_measured_heat_insertion':enc(difference)})
 totalnz+=len(mat.todok())
 bad={
  'early_internal_hats0':mat,'wrong_tangent_or_ghost_sign':2*mat,
  'missing_right_endpoint':ec,'missing_left_endpoint':es,'extra_open_half':mat/2,
  'extra_family3':2*mat,'wrong_dimensional_radial_moment':mat/3,
 }
 gy=packed(CAL/'canonical_so10_gauge_yukawa_vertex_poles/replay_v2_tables.json.gz');CI,CH=map(dec,gy['scalar_Casimir_I_H'])
 bad['replace_heavy_projector_by_full45']=B*CH/2
 for n,a in bad.items():controls.setdefault(n,0);controls[n]+=len(tidy(a).todok())
 zero(B*CH*v)
 assert not any(s.Symbol(z) in mat.free_symbols for z in ['chi4','b0','kappa'])
assert all(z>0 for z in controls.values())
# A formal general symmetric complex family factor preserves the physical
# mass symmetry, without extra family3 or specializing a Yukawa matrix.
family=s.Matrix(3,3,lambda i,j:s.Symbol('y'+str(min(i,j))+str(max(i,j))))
zero(family-family.T)
recipe={'schema':'HPI1_SELECTED_DIMENSIONAL_VACUUM_TANGENT_MATTER_INSERTION','overall_factor':'g10^2*xi*Y_R/(16*pi^2)','local_dimensional_iE_tensor':'(1/2)*B_R*K_scalar','models':P['models'],'projected_comparisons':projected,'heat_response_measured':False,'full_extended_identity_qualified':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(recipe,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_dimensional_tangent_insertion.json.gz').open('xb') as f:f.write(blob)
result={'status':'QUALIFIED_COMPLETE_SELECTED_DIMENSIONAL_hPP_INSERTION','individual_tensor_positions_compared':full,'total_holomorphic_nonzero_positions':totalnz,'proper_topologies':1,'ordered_endpoints':2,'all_tangent_directions':328,'carriers':2,'finite_moment':'-1/2','coefficient_of_BK':'1/2','dimensional_iE_at_v_126':'(25/4)*xi*M126','general_family_matrices_symbolic':True,'controls_changed_positions':controls,'full45_control_at_v_INSENSITIVE':True,'heat_regulator_response_calculated':False,'full_extended_Slavnov_QAP_or_E5A5_qualified':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest(),'elapsed_after_imports':time.perf_counter()-t}
print('RESULT '+json.dumps(result,sort_keys=True),flush=True)
