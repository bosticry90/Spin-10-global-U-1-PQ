# HPI1: actual dimensional hPP insertion in the provisional vacuum extension

Question: calculate the complete local one-loop physical hPP coefficient of
the SMA iE insertion with the actual VTS tangent interaction. The nonzero MFC
parent diagnostic is motivation, not an input to the quantum calculation.
Use the current action; no fitted counterterm, physical scheme or baseline.

Freeze the existing massless Cartesian SMA/old643 reference, flat residual
background, physical external fermions/hats0, zero external jets for the local
coefficient, full328 tangent directions, general symmetric complex Y10/Y126,
fixed heavy projector/dual maps, and the VTS provisional qz=h,qh0/tree -Jh.
h is external odd, ghost number1, dimension2. The insertion has dimension5.
No inverse physical parameter or numerical Yukawa point is allowed.

At one loop, the only proper topology uses Ihat(C,S,P), tangent(h,a,x), and
Yukawa(x,P,P). Retain both fermion endpoints and the compact-insertion
boundary-current equivalence at external hats0. The scalar-current and
auxiliary graphs of the older cxPP calculation are different graphs; do not
transfer their total normalization. A tadpole attached by a scalar bridge
is not a proper graph. Extra interactions or mass insertions cannot change
this local dimension-five coefficient under polynomial power counting.

Primary: explicit gamma8 spin numerators, ordered Grassmann Wick sign,
Gamma integral and actual raw ghost/dual projector; contract fermion endpoint
operators using the authenticated full45 scalar/Yukawa covariance theorem.
Replay: independent exterior-Gaussian calculation, abstract Clifford words,
Schwinger moment and scalar Casimir contraction with the qualified VTS map.
Neither scientific worker may read MFC outputs or its peer. The gate alone
compares complete tensors, zero complements, symmetry, conjugation, the
actual reference projection and the earlier diagnostic. The comparison is
descriptive, not a declaration of the full extended quantum identity.

Controls: early hats0, wrong ghost/tangent sign, missing either endpoint,
extra open half/family3, full45 versus heavy projector, wrong radial moment.
Report actual sensitivities, including a control that may vanish at v but
changes the full tensor. No positive result is required in advance.

Freeze8 sources/copies and immutable dependencies before sequential P/R/V.
Caps600 seconds after imports each, sampled private8GiB, available-commit
launch floor350MiB, total stored packet16MiB. Stop on first failed requirement
and preserve complete captures; no silent retries or resource expansion.
Reuse authenticated E4 readiness from the completed MFC increment, with root0
and steps0/0/0/0/0/2, custodysevenNOTPASS. New before/index/after local seals
must preserve33397 prior blobs. No expensive old qualified replay.

Ceiling: selected complete dimensional iE hPP local coefficient in this
explicit provisional extension. It does not alone qualify the heat-regulator
insertion, extended source-Hessian/QAP domain, finite restoration, all source
products/measure/global phase, physical vacuum/causal limit, C1 or E5/A5.
Do not identify it with MFC's raw parent comparison. Keep chi4,b0,kappa
distinct and symbolic. Authority34/39,state113 unchanged; prior scalar
failures, quartetFAIL, flavorpause and HB1/C5 boundaries preserved. No agents,
branch/worktree/push/outreach/publication. Shared action, covariance inputs,
software, regulator assumptions and AI authorship limit independence.
