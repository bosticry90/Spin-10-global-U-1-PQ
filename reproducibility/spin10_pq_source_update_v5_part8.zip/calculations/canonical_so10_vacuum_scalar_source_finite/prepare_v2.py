from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/vacuum-scalar-source-finite-v1-2026-10-23')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='8677971d6d498c8ed7c7002965757fed999a67c7'
assert read(HERE/'validation_receipt.json')['status']=='QUALIFIED_SELECTED_EXTRA_GF_VACUUM_SCALAR_SOURCE_RELATIVE_MEMBER'
bind=dict(read(HERE/'validation_preparation.json')['input_sha256'])
for p in HERE.iterdir():
 if p.is_file():bind[str(p)]=digest(p)
for fo,n in [('canonical_so10_complete_heat_scalar_response','validation_receipt_v2.json'),('canonical_so10_complete_heat_scalar_response','DERIVATION.md'),('canonical_so10_vacuum_tangent_source_finite','selected_vacuum_source_relative_member.json.gz'),('canonical_so10_vacuum_ghost_matter_companion','extra_GF_vacuum_companion_v3.json.gz')]:
 p=CAL/fo/n;bind[str(p)]=digest(p)
assert digest(CAL/'canonical_so10_complete_heat_scalar_response/validation_receipt_v2.json')=='36b4cc573c79aa9cf200cdb39dc85de43c8f694cb41fe353dc54a4e1e4487f5f'
for n in ['EULER_PROJECTION_V2.md','project_v2.py','prepare_v2.py','run_v2.py']:
 p=HERE/n;b=p.read_bytes();assert b'\r' not in b
 if p.suffix=='.py':compile(b,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 bind[str(HERE/(n+'.source.txt'))]=digest(HERE/(n+'.source.txt'))
with (HERE/'preparation_v2.json').open('xb') as f:f.write((json.dumps({'schema':'VSC1_V2_PREPARATION','input_sha256':dict(sorted(bind.items())),'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('VSC1_V2_FROZEN',len(bind),'bindings',flush=True)
