# VSC1 V2: late source Euler and measured insertion comparison

Native P/R/gate completed under the original frozen contract. They agree at
73800 positions. Each component scalar/orbit/total has424 nonzero entries;
finite directions are chi4*total and log(3/2)*orbit. No N or B-jet omission
sensitivity survives this contracted source column at the frozen v; those
vertices remain in its derivation and GVC's operator-level N control.

NEXT bounded test, frozen before its numerical/algebraic execution: apply
the actual physical scalar Euler map to the measured column. HSC's generic
source-left derivation gives +B_R L_c in holomorphic mass-kernel units, and
+B_Rstar L_c for the conjugate kernel. It applies unchanged when the source
coefficient contains v instead of x: the scalar Euler column is linear and
no derivative acts on that coefficient. Differentiate J before setting J0.
The Nambu1/2 is present on both sides; no extra half in the kernel equation.
Use the inherited actual HSC source sign, not a sign chosen from GVC.

An independently measured GVC component is (i/2)sum_a L_Ta(B F_ca).
Full45 YCT covariance B rho_a=iL_Ta B and the present source sewing
L_c=-sum_a rho_a F_ca therefore predict, for each scalar/orbit/total piece,

    B_R L_piece,c = -2 R_GVC,piece,c.

This is a comparison of two quantum coefficients connected by a qualified
representation identity, not a multiple-insertion/QAP or restoration theorem.
Check both chiralities/both Yukawa carriers/all45 ghosts and all matrix zeros.
The tree covariance and source/Euler phase are inherited from the actual
HSC action/source proof, whose receipt is authenticated, not re-executed.

Only after coefficients are fixed, inspect whether each measured source
matrix is proportional to rho_c K v across ALL14760 source/ghost positions.
If not proportional, retain the complete remainder rather than forcing a
compact form. This diagnostic does not set a counterterm normalization.
Record actual source-Euler finite chi4 and log(3/2) maps. No conclusion about
complete cv/h cancellation before all remaining field/source terms are summed.

Use same600s/8GiB sampled/350MiB launch/16MiB packet and poleblind Python-B.
New manifest authenticates completed immutable inputs BEFORE computation;
new sources/copies only, no edits to previous frozen workers or results.
Any failure remains exact evidence. Authority34/39, custody2sevenNOTPASS;
no scheme/benchmark/flavor/HB1C5/E5A5 adoption/promotion. No agents.
