"""VSC1 primitive/representation contraction and independent exterior sign."""
from data import *
t=begin('replay')
def add(A,B):
 out=dict(A)
 for k,v in B.items():out[k]=s.expand(out.get(k,0)+v)
 return {k:v for k,v in out.items() if v}
def mul(A,B):
 out={}
 for a,x in A.items():
  for b,y in B.items():
   if a&b:continue
   inv=sum(1 for i in range(4) for j in range(4) if (a>>i)&1 and (b>>j)&1 and i>j);out[a|b]=s.expand(out.get(a|b,0)+(-1)**inv*x*y)
 return {k:v for k,v in out.items() if v}
def scale(A,c):return {k:s.expand(c*v) for k,v in A.items() if c*v!=0}
q,z,a,b,S=s.symbols('q z a b S',nonzero=True);action={12:-q,5:a*z,10:b*z};term={0:s.S.One};exp=dict(term)
for n in range(1,5):term=scale(mul(term,action),-s.Rational(1,n));exp=add(exp,term)
integ={k^12:v for k,v in exp.items() if k&12==12};assert integ[0]==q
unit=simp(-integ[3]/q*q/(a*b*z*z));assert unit==1
G=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/replay_tables.json.gz');V={(r,a,c):s.sympify(v) for r,a,c,v in G['plane_V']};U=dec(G['raw_aux_map']);Ui=U.inv();Q=dec(G['C3_chart']);Qi=Q.inv()
maps=packed(CAL/'canonical_so10_cutoff_source_ward_operator/primary_inputs.json.gz')['field_maps'];anti=[f'bar{a}' if a<12 else f'ub{a}' for a in range(45)];ai={n:i for i,n in enumerate(anti)};g=s.Symbol('g10');N=defaultdict(lambda:s.S.Zero);nrows=0
for out,n in enumerate(anti):
 for row in maps[n]:
  w=row['word']
  if len(w)==1:continue
  assert len(w)==2;cr=next(i for i,z in enumerate(w) if z.startswith('C'));ar=1-cr;ci=int(w[cr][1:]);ia=ai[w[ar]];co=simp((-1 if cr>ar else 1)*s.sympify(row['coefficient'])/g);nrows+=1
  for r in range(45):
   if not Ui[r,out]:continue
   for a in range(45):
    if not U[ia,a]:continue
    for c in range(45):
     if Qi[ci,c]:N[r,a,c]+=co*Ui[r,out]*U[ia,a]*Qi[ci,c]
N={k:simp(z) for k,z in N.items() if simp(z)!=0}
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');HF=dec(Y['H_new']);PM=tidy(s.eye(45)-HF*HF.T)
phys=read(PK/'frozen_a10_physical_reconciliation/full_replay.json');v=dec(phys['vacuum']['VEV']);scparts=[];obparts=[];nonlinparts=[];wrongparts=[];off=0
for sec,n in SECTORS:
 rho=list(map(dec,phys['representation_matrices'][sec]));vv=v[off:off+n,0];off+=n;rv=[tidy(r*vv) for r in rho];O=[tidy(sum((PM[a,b]*rv[b] for b in range(45) if PM[a,b]),s.zeros(n,1))) for a in range(45)]
 for a,b in zip(O,rv):zero(a-b)
 sc=[s.zeros(n,1) for c in range(45)];ob=[s.zeros(n,1) for c in range(45)];nl=[s.zeros(n,1) for c in range(45)];wrong=[s.zeros(n,1) for c in range(45)]
 for c in range(45):
  for a in range(45):
   if O[a].todok():sc[c]-=rho[a]*(rho[c]*O[a])
   if O[c].todok():wrong[c]-=rho[a]*(rho[a]*O[c])
 for (r,a,c),co in N.items():
  if O[r].todok():nl[c]-=co*rho[a]*O[r]
 for (r,a,c),co in V.items():
  if O[r].todok():ob[c]-=co*rho[a]*O[r]
 scparts.append(s.SparseMatrix.hstack(*[tidy(x+y) for x,y in zip(sc,nl)]));obparts.append(s.SparseMatrix.hstack(*map(tidy,ob)));nonlinparts.append(s.SparseMatrix.hstack(*map(tidy,nl)));wrongparts.append(s.SparseMatrix.hstack(*[tidy(x+y) for x,y in zip(wrong,nl)]))
 print('STAGE INDEPENDENT_SCALAR_SOURCE',sec,flush=True)
sc=s.SparseMatrix.vstack(*scparts);ob=s.SparseMatrix.vstack(*obparts);nl=s.SparseMatrix.vstack(*nonlinparts);wrong=s.SparseMatrix.vstack(*wrongparts)
u=s.Symbol('u',positive=True);aa,bb=s.symbols('aa bb',positive=True);frullani=-s.integrate(1/bb,(bb,4,6));assert simp(frullani+s.log(s.Rational(3,2)))==0
# Differentiation of integral(e^-aa*u-e^-bb*u)/u with respect to bb is1/bb;
# the coincident-boundary value is0. This fixes the finite shift independently.
chi=1+s.log(16*s.pi)-s.Symbol('n_log',positive=True)
finish('replay',{'method':'primitive_odd_variation_nonlinear_antighost_plane_representation_and_exterior_minus_log','scalar':enc(sc),'orbit':enc(ob),'total':enc(sc+ob),'nonlinear_scalar_component':enc(nl),'wrong_rho_order_scalar':enc(wrong),'nonlinear_antighost_rows':nrows,'second_cumulant_unit':str(unit),'finite_relative_constants':[str(s.expand_log(chi,force=True)),str(s.expand_log(chi+s.log(s.Rational(3,2)),force=True))],'Frullani_heatlength_shift':str(-frullani),'source_ghost_positions_each':328*45,'heatlengths':[4,6],'full_D_contraction':'q.q=Q','bosonic_Stokes_word_lengths':[2,3]},t)
