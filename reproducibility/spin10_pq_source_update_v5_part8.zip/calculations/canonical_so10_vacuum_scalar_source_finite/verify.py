from data import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');assert P['method']!=R['method']
assert P['scalar_source_rows']==29754 and P['GF_scalar_rows']==6688 and R['nonlinear_antighost_rows']==180
assert P['second_cumulant_unit']==R['second_cumulant_unit']=='1' and P['ordered_permutation_signs']==[-1,-1]
assert P['heatlengths']==R['heatlengths']==[4,6] and P['bosonic_Stokes_word_lengths']==R['bosonic_Stokes_word_lengths']==[2,3]
positions=0;counts={};M={}
for part in ['scalar','orbit','total']:
 a,b=dec(P[part]),dec(R[part]);assert a.shape==b.shape==(328,45);zero(a-b);zero(a-s.conjugate(a));positions+=328*45;counts[part]=len(a.todok());M[part]=a
zero(M['total']-M['scalar']-M['orbit'])
for a,b in zip(P['finite_relative_constants'],R['finite_relative_constants']):assert simp(s.sympify(a)-s.sympify(b))==0
assert simp(s.sympify(P['finite_relative_constants'][1])-s.sympify(P['finite_relative_constants'][0])-s.log(s.Rational(3,2)))==0
assert all(x['angular_first_D_jet']==0 and x['radial_pole']==1 for x in P['radial_checks'])
controls={'omit_scalar':len(M['scalar'].todok()),'omit_orbit':len(M['orbit'].todok()),'wrong_Schur_sign':len(tidy(2*M['orbit']).todok()),'wrong_source_sign':len(tidy(2*M['total']).todok()),'collapse_heatlengths':len(M['orbit'].todok()),'wrong_rho_order':len(tidy(M['scalar']-dec(R['wrong_rho_order_scalar'])).todok()),'omit_nonlinear_antighost':len(dec(R['nonlinear_scalar_component']).todok()),'omit_B_jet':len(tidy(M['orbit']-dec(P['omit_B_jet_orbit'])).todok())}
assert controls['omit_scalar'] and controls['omit_orbit'] and controls['collapse_heatlengths'] and controls['wrong_rho_order']
for part,mat in [('finite_chi4',M['total']),('finite_log_three_halves',M['orbit'])]:
 zero(mat-dec(R['total'] if part=='finite_chi4' else R['orbit']));positions+=328*45;counts[part]=len(mat.todok())
# Ownership is a scoped structural claim, not a rerun of the complete old
# Stokes construction. Verify the actual defining words and its stated domain.
st=(CAL/'canonical_so10_dimensional_stokes_primitive/DERIVATION.md').read_text(encoding='utf-8');jm=(CAL/'canonical_so10_joint_marginal_fermion_normalization/RECORD.md').read_text(encoding='utf-8')
assert all(z in st for z in ['V=H-K','All sources','Every additional scalar mass or scalar--auxiliary','constant vertex has positive dimension'])
assert all(z in jm for z in ['C_bStokes+(HSC-C_shared)+K_closed','dimension','Keep the full bosonic operator formula by reference.'])
ownership={'proper_cycle_words':[['JxCx','GF_Cax_v'],['JxCx','GF_CaB','GF_Lambda_x_v']],'loop_edge_counts':[2,3],'included_in_old643_complete_H':True,'new_fermion_loop':False,'already_in_C_bStokes':True,'inside_JMF_dimension0_shared_overlap':False,'add_second_copy_to_C_joint':False,'scope':'OPERATOR_FORMULA_COLUMN_EXTRACTION_NOT_GLOBAL_RUNTIME_DEPENDENCY_AUDIT'}
recipe={'schema':'VSC1_EXTRA_GF_VACUUM_SCALAR_SOURCE_RELATIVE_MEMBER','overall_factor':'g10^3*xi/(16*pi^2)','source_order':'Jx_left_C_real_plane_right','scalar_pole':P['scalar'],'orbit_pole':P['orbit'],'total_pole':P['total'],'finite_chi4':P['total'],'finite_log_three_halves':P['orbit'],'heatlengths':[4,6],'ownership':ownership,'complete_source_Euler_matter_restoration_qualified':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(recipe,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_vacuum_scalar_source_member.json.gz').open('xb') as f:f.write(blob)
out={'status':'QUALIFIED_SELECTED_EXTRA_GF_VACUUM_SCALAR_SOURCE_RELATIVE_MEMBER','full_coefficient_positions_compared':positions,'nonzero_coefficient_positions':counts,'scalar_source_directions':328,'external_ghost_directions':45,'controls_changed_positions':controls,'heatlengths':[4,6],'angular_first_D_jet':0,'ownership':ownership,'complete_source_Euler_matter_restoration_qualified':False,'full_renormalized_cvh_QAP_or_E5A5_qualified':False,'physical_scheme_adopted':False,'authority':'34/39','scientific_acceptance':'NOT_PERFORMED','artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest(),'elapsed_after_imports':time.perf_counter()-t}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
