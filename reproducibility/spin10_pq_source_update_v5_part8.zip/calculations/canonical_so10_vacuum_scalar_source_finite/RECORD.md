# VSC1: the proper positive-v scalar-source column

Frozen before calculation under current AGENTS standing delegation. Base
8677971d6d498c8ed7c7002965757fed999a67c7/main, state113/34of39 unchanged.
Question: what is the complete extra GF-v proper local Jx C coefficient and
its dimensional-minus-heat finite comparison in the fixed reference, and is
it already owned by the inherited bosonic Stokes operator formula?

Domain: one loop, Euclidean nonexceptional/local UV comparison with the
existing common auxiliary IR completion; physical zero external jets,
all328 scalar evaluation-dual source directions, all45 real-plane ghosts,
coefficient dimension1 from the frozen v. Jx odd/gh-1/dim2, C odd/gh1/dim1,
v even/dim1. The overall factor is g10^3 xi/(16pi^2). No new mass resummation,
benchmark, regulator scheme, physical constant-vacuum limit or source rule.

Actual source -g J R C x joins (1) actual GF C a x(v), or (2) ordinary GF
C a B plus GF Lambda-x(v). Scalar kinetic/mass dependence is ordinary x
evaluation, not this extra GF-v class. Dimension2 insertions cannot enter
this dimension1 coefficient with polynomial nonnegative parameter powers.
Other source endpoints are excluded by the actual quadratic source rule and
one-loop proper cycle incidence. Reducible tadpoles are not proper vertices.

Primary parses literal GF and scalar field maps, raw Green/ghost chart and
two oriented Schur paths. Replay uses scalar representation matrices,
primitive odd variation including nonlinear qa and independently transported
plane GF vector vertex. Both calculate coefficients before comparison.
Ordered Wick signs and exterior Berezin -log independently fix the source
unit. Direct Gamma/E_n finite parts vs inherited VTF plus Frullani heat
boundary fix heatlength4/6 separately. Full-D q.q=Q; no closed numeric D
trace. Do not equate the two heatlengths from their equal pole.

Gate: exact complete coefficient/zero complement agreement, reality, same
residue and finite differences, source/GF signs, structural ownership in
C_bStokes. Omission/sign/heatlength controls measured; report any insensitive
control honestly. No expectation that a new coefficient restores a desired
matter identity. Do not identify b0,kappa,chi4 or invariant matter freedoms.

Bind current policy/receipts/raw data/source copies and previous postcommit
seal before native workers. Sequential P/R/gate; no agents. Each600s after
imports,8GiB sampled private,350MiB launch commit floor,16MiB stored packet;
resource exhaustion=incomplete. Preserve any failed source/run/capture. Use
poleblind Python-B, exclusive writes and native exits, then external before,
index,after seals. Reuse authenticated fresh HWB E4; custody2sevenNOTPASS.

Ceiling: selected extra GF-v source pole and relative finite local member,
plus exact-once operator ownership only. Not full normalized cv/h restoration,
chiral phase/measure/multiple products/QAP/physical C1/E5A5/GUT. Shared action,
regulator, data, Python/SymPy and AI author limit independence; no external
scientific confirmation or theorem-prover formalization. TrackB tests whether
raw loop sewing and representation/primitive reduction agree efficiently.
TrackC explanations voluntary/nonblocking. Possible results qualified member,
refutation, underdefinition or resource-bounded inconclusiveness. Next action
is the actual source-Euler matter image, not an assumed cancellation.
