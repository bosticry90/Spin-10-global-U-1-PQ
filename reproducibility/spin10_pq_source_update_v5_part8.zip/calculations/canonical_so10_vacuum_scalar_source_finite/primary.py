"""VSC1 literal source/GF density, raw Green and ordered Wick sewing."""
from data import *
t=begin('primary');g,xi=s.symbols('g10 xi')
def perm(w):return (-1)**sum(w[i]>w[j] for i in range(len(w)) for j in range(i+1,len(w)))
signs=[perm(w) for w in [[0,2,1,3],[1,3,0,2]]];unit=-s.Rational(1,2)*sum(signs);assert unit==1
d=packed(CAL/'canonical_so10_cutoff_source_ward_operator/primary_inputs.json.gz');names=[f'x_{sec}_{i}' for sec,n in SECTORS for i in range(n)];si={n:i for i,n in enumerate(names)}
RR=[defaultdict(lambda:s.S.Zero) for _ in range(45)];rows=0
for j,n in enumerate(names):
 for row in d['field_maps'][n]:
  w=row['word'];assert len(w)==2 and '__' not in ''.join(w);c=int(next(n for n in w if n.startswith('C'))[1:]);k=si[next(n for n in w if n in si)];z=simp(-s.sympify(row['coefficient'])/g);assert not z.free_symbols;RR[c][j,k]+=z;rows+=1
R=[s.SparseMatrix(328,328,x) for x in RR];F=defaultdict(lambda:s.S.Zero);densityrows=0
for row in d['GF']:
 w=row['word'];cc=[i for i,n in enumerate(w) if n.startswith('C')];aa=[i for i,n in enumerate(w) if n.startswith(('bar','ub'))]
 if len(w)!=3 or len(cc)!=1 or len(aa)!=1 or not any(n in si for n in w):continue
 c=int(w[cc[0]][1:]);an=w[aa[0]];a=int(an[3:] if an.startswith('bar') else an[2:]);j=si[next(n for n in w if n in si)];z=simp(-(-1 if cc[0]>aa[0] else 1)*s.sympify(row['coefficient'])/(g*g*xi));assert not z.free_symbols;F[c,a,j]+=z;densityrows+=1
G=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/primary_tables.json.gz');CG=dec(G['raw_Gca']);Q=dec(G['C3_chart']);Qi=Q.inv()
ua={(r,a,c):s.sympify(z) for r,a,c,z in G['raw_jets']['a']};ub={(r,a,c):s.sympify(z) for r,a,c,z in G['raw_jets']['B']};V={k:simp(ua.get(k,0)-ub.get(k,0)) for k in set(ua)|set(ub)}
O=s.SparseMatrix(45,328,{});O[12:,:]=dec(packed(CAL/'canonical_so10_vacuum_tangent_source_kernel/primary_tables.json.gz')['primitive_orbit_at_v']);GO=tidy(CG*O)
RG=[tidy(sum((CG[c,a]*R[c] for c in range(45) if CG[c,a]),s.SparseMatrix(328,328,{}))) for a in range(45)]
rc=[]
for m in RG:
 z=defaultdict(list)
 for (j,k),v in m.todok().items():z[k].append((j,v))
 rc.append(z)
sc=defaultdict(lambda:s.S.Zero);ob=defaultdict(lambda:s.S.Zero);bad=defaultdict(lambda:s.S.Zero)
for (c,a,k),v in F.items():
 for j,z in rc[a][k]:sc[j,c]-=unit*z*v
go=defaultdict(list)
for (r,k),z in GO.todok().items():go[r].append((k,z))
for (r,a,c),v in V.items():
 for k,z in go[r]:
  for j,w in rc[a][k]:ob[j,c]-=unit*v*z*w
for (r,a,c),v in ua.items():
 for k,z in go[r]:
  for j,w in rc[a][k]:bad[j,c]-=unit*v*z*w
sc=tidy(s.SparseMatrix(328,45,sc)*Qi);ob=tidy(s.SparseMatrix(328,45,ob)*Qi);bad=tidy(s.SparseMatrix(328,45,bad)*Qi)
eps,m2,nlog=s.symbols('eps m2 n_log',positive=True);finite=[];checks=[]
for n in [2,3]:
 heat=s.expand(-s.EulerGamma-s.log(2*n)-s.log(m2)+sum((-1)**j*s.binomial(n-1,j)/j for j in range(1,n)))+nlog
 rat=s.prod([k-eps for k in range(2,n)])/s.factorial(n-1);assert rat.subs(eps,0)==1
 dim=s.log(4*s.pi)-s.EulerGamma-s.log(m2)+s.diff(rat,eps).subs(eps,0)
 finite.append(str(s.expand_log(s.simplify(dim-heat),force=True)));checks.append({'edges':n,'radial_pole':1,'heat_constant':str(heat),'dimensional_constant':str(dim),'angular_first_D_jet':0})
finish('primary',{'method':'literal_source_and_GF_density_raw_ghost_Green_two_oriented_Schur_paths','scalar':enc(sc),'orbit':enc(ob),'total':enc(sc+ob),'omit_B_jet_orbit':enc(bad),'scalar_source_rows':rows,'GF_scalar_rows':densityrows,'second_cumulant_unit':str(unit),'ordered_permutation_signs':signs,'finite_relative_constants':finite,'radial_checks':checks,'source_ghost_positions_each':328*45,'heatlengths':[4,6],'full_D_contraction':'q.q=Q','bosonic_Stokes_word_lengths':[2,3]},t)
