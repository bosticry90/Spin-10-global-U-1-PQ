from data import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');G=packed(CAL/'canonical_so10_vacuum_ghost_matter_companion/extra_GF_vacuum_companion_v3.json.gz')
parts=['scalar','orbit','total'];models=[];checks=0;controls={};source_maps={};finite_maps={}
for yidx,carrier in enumerate(['10','126']):
 B=dec(Y['B'+carrier]);rec={'carrier':carrier,'Euler':{},'anti_Euler':{}};controls[carrier]={}
 for part in parts:
  col=dec(P[part]);col2=dec(R[part]);zero(col-col2);e=tidy(B*col);ae=tidy(s.conjugate(B)*col2)
  for c in range(45):
   gm=dec(G['models'][yidx][part][c]);ag=dec(G['models'][yidx]['anti_'+part][c]);em=s.Matrix(16,16,list(e[:,c]));am=s.Matrix(16,16,list(ae[:,c]));zero(em+2*gm);zero(am+2*ag);zero(am-s.conjugate(em));zero(em-em.T);checks+=2*256
  rec['Euler'][part]=enc(e);rec['anti_Euler'][part]=enc(ae);controls[carrier][part]={'wrong_Euler_sign_changed':len(tidy(2*e).todok()),'extra_Nambu_half_changed':len(tidy(e/2).todok()),'actual_Euler_nonzero':len(e.todok())}
 models.append(rec)
phys=read(PK/'frozen_a10_physical_reconciliation/full_primary.json');K=dec(packed(CAL/'canonical_so10_vacuum_tangent_source_finite/selected_vacuum_source_relative_member.json.gz')['kernel_chi4']);v=dec(phys['vacuum']['VEV']);kv=K*v;off=0;refparts=[]
for sec,n in SECTORS:
 rho=list(map(dec,phys['representation_matrices'][sec]));vv=kv[off:off+n,0];off+=n;refparts.append(s.SparseMatrix.hstack(*[tidy(x*vv) for x in rho]))
ref=tidy(s.SparseMatrix.vstack(*refparts));assert ref.todok();i,j=next(iter(ref.todok()));diag={}
for part in parts:
 mat=dec(P[part]);ratio=simp(mat[i,j]/ref[i,j]);rem=tidy(mat-ratio*ref);diag[part]={'ratio_to_rho_c_Kv':str(ratio),'complete_positions_checked':328*45,'nonproportional_remainder':enc(rem),'remainder_nonzero':len(rem.todok())}
artifact={'schema':'VSC1_LATE_SOURCE_EULER_AND_GVC_COMPARISON','Euler_models':models,'compact_source_diagnostic':diag,'finite_Euler_direction_assignment':{'chi4':'total','log(3/2)':'orbit'},'measured_insertion_relation':'B_R L_piece=-2 R_GVC_piece','source_Euler_sign':1,'extra_Nambu_half':False,'complete_cvh_restoration_qualified':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(artifact,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'source_Euler_comparison_v2.json.gz').open('xb') as f:f.write(blob)
out={'status':'QUALIFIED_SELECTED_SOURCE_EULER_AND_GHOST_INSERTION_COEFFICIENT_BRIDGE','full_coefficient_positions_compared':checks,'compact_diagnostic':{p:{k:v for k,v in row.items() if k!='nonproportional_remainder'} for p,row in diag.items()},'controls':controls,'finite_Euler_direction_assignment':artifact['finite_Euler_direction_assignment'],'source_Euler_sign':1,'complete_cvh_restoration_qualified':False,'full_QAP_E5A5_qualified':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest(),'elapsed_after_imports':time.perf_counter()-t}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
