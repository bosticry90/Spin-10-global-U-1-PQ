# VSC1: source sewing, edge heat factors and existing ownership

Keep the VTS evaluation-dual source and Euclidean conventions. Its literal
vertex is -g J_i (R_c)ij C_c x_j. Canonical odd order J,Cexternal,Cinternal,a
gives -1 for each of the two even vertex orders; the -1/2 second cumulant
therefore has unit+1. Independent exact exterior integration and -log gives
the same unit. The source coefficient itself is negative, so with F the
positive Euclidean GF coefficient stripped of g²xi, the raw color column is

    Ls[d] = -sum_(c,a) Gca[c,a] R_c F[d,a],
    Lo[d] = -sum_(c,a,r) Gca[c,a] R_c V[r,a,d] (Gca O)[r].

F is parsed from the actual GF density, including nonlinear qa rotations.
O embeds the actual33 dual orbit rows into45. The plus orbit sign follows
the two oriented -H_aB G_BL H_Lx Schur terms, with the independently
qualified GVC paired-mode phase review; it is not selected from a target.
Scalar sources remain in the real scalar chart. External C_raw=Qinv Cplane.

In the real plane let O_a=sum_b PM[a,b]rho_b v. The independent primitive
variation gives Fplane[d,a]=rho_d O_a+sum_r N[r,a,d]O_r, with the actual
nonlinear antighost tensor N. Thus replay sews -sum_a rho_a Fplane[d,a]
and -sum_(r,a) Vplane[r,a,d]rho_a O_r. No adjoint-only replacement of V or
premature omission of N is justified. At the frozen v, PM rho v=rho v;
this does not eliminate the heavy projector at arbitrary h.

There are two internal heat edges in the direct bubble, three in the orbit
word, each e^-2tQ. The derivative contraction in the latter is full-D Q.
Their UV residues are both1, with no angular first-D jet. For a common
positive auxiliary m², n=2,3 critical radial completions are

    heat_n = exp(z) sum_(j=0)^(n-1) (-1)^j binom(n-1,j) E_(j+1)(z),
    z=2ntm²,
    dim_n = (4pi)^eps (m²)^-eps Gamma(eps)
            Gamma(n-eps)/(Gamma(2-eps)Gamma(n)).

Heat finite part is -gamma-log(2n)-log(m²)-H_(n-1); dimensional finite
part is log(4pi)-gamma-log(m²)+1-H_(n-1). Include inherited n_log once.
Hence chi4=1+log(16pi)-n_log and chi6=chi4+log(3/2).
Replay instead imports qualified VTF bubble normalization and derives the
extra log from integral_0^infinity (e^-4u-e^-6u)/u du=log(3/2).
The pole and relative finite source member are respectively

    P[J,C]=g³xi/(16pi²) J^T (Ls+Lo) C,
    Crel[J,C]=g³xi/(16pi²) J^T [chi4(Ls+Lo)+log(3/2)Lo] C.

The auxiliary completion is not a physical ghost/scalar mass selection.
Different lower-order completions differ by UV-integrable terms whose
dimensional-minus-heat difference vanishes in the inherited common domain.
Do not erase IR distribution contacts or claim an unproved vacuum limit.

Ownership follows the actual bosonic Stokes all-n logarithm and complete
source Hessian: the n2 word has source+GFscalar; n3 has source+GFvector+
GFaux. Both are old643 bosonic/ghost words in its full H, with v in V.
The Stokes formula retains all positive-dimension vertices and all sources.
These words are therefore already included in C_bStokes, not new fermionic
loop terms. JMF C_shared is explicitly dimension0 and cannot be interpreted
as subtracting this v column. Extracting this column does not authorize
adding a second copy to C_joint. The new external h/z extension is distinct;
its Jh term is owned by VTF and is not imported into the old bosonic proof.

Before interpreting the GVC one-direction conflict, evaluate the actual
Euler image of this measured source column with existing HSC/JMF/VTF terms.
This result alone neither removes nor proves that conflict for the complete
renormalized functional. No finite coefficient is fitted to a Ward target.
