# The positive-v source comparison and its matter Euler image are measured

Two action-derived calculations agree on the complete selected extra GF-v
proper Jx C column. Its finite comparison is nonzero, and it is already
included in the inherited complete bosonic Stokes operator formula. It must
not be added a second time to the joint normalization.

Writing Ls for the direct ghost-scalar bubble and Lo for the vector/auxiliary
orbit word, with the overall g10³xi/(16pi²) suppressed, the measured result is

    pole:                 J^T (Ls+Lo) C,
    dimensional - heat:  J^T [chi4(Ls+Lo)+log(3/2)Lo] C.

Each source matrix has328 rows and45 real-plane ghost columns. Ls,Lo and
their sum each have424 nonzero positions. The gate compares73800 positions,
including all zeros and both independent finite directions. Direct raw
source/GF density and Green sewing agrees with the independently transported
scalar representation/primitive calculation. Both retain the actual
nonlinear antighost terms and both derivative placements before contraction.

The two bubble edges carry heatlength4, the three orbit edges heatlength6.
Direct Gamma/E_n finite parts and an independent VTF/Frullani calculation
give the same chi4 and chi4+log(3/2). No angular first-D-jet contribution occurs
for this full-D q.q=Q source loop. No physical normalization is selected.
An auxiliary IR completion is used only for the existing relative local
comparison; no physical zero-mass or constant-vacuum limit is inferred.

Scalar/orbit omission, wrong source/Schur sign, wrong rho order and collapsing
heatlengths each change424 positions. Omitting nonlinear qa or the B jet is
INSENSITIVE in this final column at the frozen v. Those terms were retained;
GVC's earlier operator-level nonlinear control remains nonzero. A final
projection insensitive to a term cannot validate its absence at vertex level.

## Actual source Euler image and its limit

The V2 bounded continuation applies HSC's already qualified physical scalar
Euler rule +B_R L to the independently computed source column. The actual
source-left phase and Nambu normalization are inherited from the action-based
generic HSC derivation, not chosen from the GVC target. For each component,
both carriers/chiralities and all45 ghosts, the comparison gives

    B_R L_piece,c = -2 R_GVC,piece,c.

All138240 matrix coefficient positions agree. This follows independently
from full45 Yukawa covariance and the distinct insertion/source loop units,
and is checked against the already measured GVC tensor. Carrier126 has85
nonzero Euler positions per component/chirality; carrier10 has zero at this
v, without discarding its interactions in general. Wrong Euler sign or extra
Nambu half changes85 positions per nonzero component. The finite source Euler
directions are chi4*B_R(Ls+Lo) and log(3/2)*B_R Lo, with conjugate partners.

The complete source column is more complicated than its matter projection.
A late diagnostic attempts L_piece,c=a rho_c K v, with a fixed from one
nonzero reference position and ALL14760 positions checked. The resulting
ratios scalar3/5,orbit-2/5,total1/5 each leave400 nonzero remainder positions.
These are FAILED whole-source proportionality diagnostics, not accepted
compact identities or fitted counterterms. Their full exact remainders are
retained in source_Euler_comparison_v2.json.gz. Do not transfer the simple
GVC matter reduction to the unprojected source space.

This comparison does not assert that a selected cv/h breaking has been
restored, or that the earlier single-Cv conflict was a complete renormalized
obstruction. It supplies the missing proper source input and its measured
Euler contribution for that next coupled calculation. It is not a new QAP,
multiple-insertion, measure, determinant-phase or physical equivalence proof.

## Ownership and evidence

The proper n2 source/GF-scalar and n3 source/GF-vector/GF-aux words occur in
the old643 complete bosonic H and its all-n logarithm. The qualified Stokes
formula explicitly retains positive-dimension vertices and all sources.
JMF retains that complete operator by reference, while its demonstrated
C_shared overlap is dimension0. This establishes scoped operator ownership,
not a fresh global runtime dependency audit. VTF's new external Jh extension
is separate; it is not retrospectively inserted into the old bosonic proof.

Qualified receipt hashes:

- validation_receipt.json:
  190e043eaa287538dae303565f0d73c8ee61b584bc4b775617957477ec31cc78.
- projection_receipt_v2.json:
  e566caa6378112e589f94f38b3b873a2e0ed0503ba55ceb84a62c6864482ad14.

First artifact packed/raw SHA256:
be443e51001511edc6cb139182c31e9ed8435b347f87a2ec392fc1fb82c7d066 /
008ed99b1d7f3868377f98ac2258096a10280453e03492f6012a5ff6b464dbf0.
Euler artifact packed/raw:
80f69830f13742cd695a148432b1e6df97a48c874db2031deb9b32f0668f1028 /
a2193f28df35709824286f81bed4132217abb8597151270232175b95656e1bbe.

Native P/R/gate/project exits0/0/0/0; times45.645263/24.565292/3.172840/
15.450144s. Sample counts24/15/3/9, max sampled private117321728/84070400/
51904512/61120512B; sampled values are not process peaks. Same600s/8GiB/
350MiB/16MiB bounds held. Twelve exact source copies;96/104/120 input bindings;
pre-report packet171688B. No new failed native worker/verifier. Negative
compact diagnostics remain negative; earlier GVC/HPI failures unchanged.

The E4 preservation check is separately captured; successful execution is
not historical custody PASS. Custody remains exit2 with seven unresolved
references. External before/index/after gates bind new bytes and preserve
all33572 previously tracked blobs; inspect final external seal for commit
completion. No state, old evidence, scheme or physical benchmark changed.

## Significance and next step

TrackA: a previously unextracted source coefficient now has an action-derived
relative finite member and a checked relation to the measured insertion.
TrackB: distinct raw and representation methods agree, while a simpler
whole-source interpretation is rejected. Shared physics inputs, software and
AI authorship remain common-error limits; there is no external scientific
validation or proof-assistant formalization. TrackC explanations nonblocking.

Next assemble the actual positive-v/h selected finite Slavnov comparison:
MFC/HPR/HWB mass/tangent terms, HSC/JMF at x=v, VTF Jh and this proper JxCv
column, with their field/source Euler images and exact-once ownership. Keep
full source remainders; do not infer closure from the85-position matter
projection or fit a new coefficient to force cancellation. Full chiral/phase,
background, multiple products, QAP, Lorentzian/causal/physical vacuum, massive
C1, E5/A5 and physical GUT remain unqualified. Scientific authority34/39;
whole Spin10xPQ investigation ACTIVE and incomplete.
