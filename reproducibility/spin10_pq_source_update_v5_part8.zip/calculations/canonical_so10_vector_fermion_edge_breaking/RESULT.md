# VFE1: ordinary fermion-edge breaking measured; auxiliary placements cancel

Receipt SHA256
`5b99fc5df3ddcb82b05105ceb988109ac840cd5b950beac823a58cba20001f53`:
QUALIFIED_VECTOR_FERMION_EDGE_MATTER_BREAKING_FAMILY,
ORDINARY_FAMILY_MEASURED_AUXILIARY_ENDPOINT_PAIR_ZERO. Scientific acceptance
NOT_PERFORMED. State113/authority34of39 unchanged.

All six MDS1/VCT1 fermion-edge profiles are calculated:four ordinary g4
and two auxiliary g3,with both endpoint placements retained. Together
with VCT1's two contact profiles,eight of42 internal-ghost vector profiles
are accounted for. The remaining34 are ghost-edge12,physical-vector12
and mixed gauge-fixing vector/auxiliary10. No full vector restoration
claim is made from these partial inputs.

## The actual mixed gauge response fixes the units

The calculation differentiates the real prescribed P/S block operator,
not an assumed physical massive propagator. With b=gamma_bar.kbar,
h=gamma_hat.khat,S0=-i[[b,h],[h,b]]/K2 and
deltaD_PP=-ig gamma_mu A_d,the exact resolvent gives

 deltaS_PS=-ig b gamma_mu A_d h/K2²,
 deltaS_SP=-ig h gamma_mu A_d b/K2².

The primary verifies both blocks and every physical Lorentz component
using explicit split Clifford matrices and noncommuting color witnesses.
The actual contracted spin numerators are proportional to hatk²*bark²,
with ordered colors Tb Td Ta and Ta Td Tb. Full-D k.GBB=Wk is established
before the barred fermion current is contracted;no closed vector trace
or prematurely four-dimensional angular factor is introduced.

The raw ordinary phases are-i,-i and the auxiliary phases+i,+i,derived
before integration. Replay obtains them from an exact ten-coordinate
Berezin Gaussian,four-even-vertex units-1,-1,and an independent chirality
walk. Combining the independently qualified ASB1 main moment IB=-1/3
gives ordinary units+i/3,+i/3 and auxiliary units-i xi/3,-i xi/3.
There is no extra open-line half or family trace3.

For V=UA-UB,C_ba,c=sum_r W_br V_ra,c and W=eta_H PH+xi PM,

 L_cd^[4]=(i/3)sum_ba C_ba,c(Tb Td Ta+Ta Td Tb),
 L_cd^[3]=-(i xi/3)sum_ra H_ra,c(Tr Td Ta+Ta Td Tr).

The common1/(16pi²),g4 or g3 and barred gamma_mu are stripped. Actual
U=-T.T gives right=-left.T. C is NOT antisymmetric and its ordinary
contribution has25104 nonzero positions in each chirality. The actual
H is antisymmetric,so the two auxiliary placements sum to0. Each
individual auxiliary raw orientation has28700 nonzero entries in each
chirality. Their zero is a complete paired quantum result,not an absent
polynomial entry or a value assigned from the source target.

## Full coefficient checks and sensitive limits

Primary uses direct ordered triple matrices. Replay independently uses

 XZY+YZX=({X,Y}Z+Z{X,Y}-[X,[Y,Z]]-[Y,[X,Z]])/2,

with actual structure constants and the ENTIRE anticommutator matrix.
No adjoint-only projection is imposed. Both methods agree across all
2,073,600 g-order/chirality/color positions,including zeros. The gate
checks right=-left.T,anti-Hermitian totals,nonnegative polynomial widths,
the unit-width counterfactual and all12 residual-H tensor equations at
each coupling order. This does not establish a full background QAP.

Omitting either ordinary E orientation changes30906 positions. Reversing
its GF insertion,adding a Nambu half,using the wrong right-transpose sign,
transferring auxiliary antisymmetry,or prematurely barring its GF end
changes25104 each. Same-support rescalings are not independent physical
confirmations.

Omitting either auxiliary E orientation changes28700 positions. Rescaling
or reversing the COMPLETE auxiliary zero is correctly insensitive,and
the early-barred diagnostic is also0 there because its relevant fermion
endpoint already projects that mixed momentum. These controls do not
validate a universal convention outside their tested scope.

The ordinary early-barred error replaces IB W by
IB I+IBB(W-I),where IBB=FP integral hatk²*(bark²)²/(K2+m2)^5=-1/4.
The new-for-this-control Gamma/Schwinger evaluation is explicit in both
sources. `new_radial_integrations=0` records reuse of the MAIN kernel
moment rather than a new costly main integration;it does not claim the
control moment was never analytically evaluated. At W=I both expressions
coincide. That specialization is diagnostic,not an adopted gauge choice.

Neither worker reads structured CFC1/MSP1 targets after byte authentication.
The coefficients above come from the actual insertion,propagators,action
vertices and moments. Partial results are not tested against a full
counterterm image to manufacture a cancellation or an anomaly verdict.
All family factors remain I3;no flavor parameters are selected.

## Execution,significance and continuation

All three native workers completed0 without failed or unfinished runs.
Primary259.3560893s,replay8.0961145s,verifier16.6774614s;131/5/10 samples,
private maxima249409536/79704064/174510080 bytes,not continuous peaks.
600s/8GiB sampled/350MiB launch floor/16MiB packet bounds held. Eight
source copies;300 preparation and308 validation bindings.

Primary packed/raw SHA256:
`014dbaa5aa87824d5b4ffd2ec1d822d11f90246ecd8fff094065b38610bc3ce5` /
`43be9b6704203d74e69a672e54f63777adc35cd36dc6f5688b3e02d58cf4b9b5`.
Replay packed/raw SHA256:
`d5b00bf59bb040a0e6ae2ea61ae2129c31b28ae99806f22fb205d96a586992f4` /
`5bb5f5abb303d938900634bfda5a6c95431ef2357c0544b2a2fff44ffac2f4df`.

The fresh VCT1 E4 command earlier this goal turn is authenticated reuse,
not a second command or old scientific replay. Fresh byte preflight and
native resources observed. Historical custodyexit2/seven remains NOTPASS.
All VCT1 failed sources and its raw-coordinate diagnostic remain unchanged.

The scientific gain is a complete measured family with a nonzero ordinary
input and a separately established auxiliary zero. Track B demonstrates
the same full coefficient result through a much cheaper Lie reduction
than direct triple multiplication. Shared action,data,Clifford conventions,
exact-ring utilities,software and AI authorship remain common-error limits.
This is not independent scientific or experimental confirmation.

Next derive the remaining34 profiles through the ordered ghost and mixed
boson inverse responses,keeping the12/12/10 families separate. Ghost
response requires A=UA-UC with internal differentiated ghosts. Physical
vector response must use the action-derived cubic Wick sign and full-D
longitudinal contraction. Mixed response must use the correctly normalized
LambdaBB tensor and both BL/LB placements. Qualified FAV1/FCV1 action
tensors may be reused,but their proper-vertex UV pole units cannot replace
these finite E_hat insertion kernels. Only after all42 are measured should
the full quantum tensor and fixed CFC1 higher images be compared exactly
once,including required coupled source/Euler contributions.

Full cBPP/finite Slavnov,QAP/products/measure/phase,physical chiral scheme,
massiveC1,E5/A5 and physical unification remain unqualified. SMP1 scalar
correction and all free finite ambiguities unchanged. Both adverse scalar
benchmarks,quartetFAIL,flavor pause,HB1/C5 blocks and custody2/seven persist.
Preserve main,state and historical evidence. No agents,branch/worktree,
foundation/scheme/benchmark adoption,outreach,publication or push. Whole
Spin(10)xPQ investigation active/incomplete.
