"""VFE1 full two-order kernel,oriented-zero and tensor covariance gate."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
for key in ['ordinary_raw_phases','auxiliary_raw_phases','IB_reused','IBB_new_control_moment','units','resolvent_and_spin_remainders','full_D_BB_sewing_remainder','left','right','unweighted_left','weighted_left','weighted_C','supported_witnesses','newly_measured_profiles','remaining_vector_profiles_unmeasured','adjoint_only_projection_used','new_radial_integrations']:assert P[key]==R[key],key
assert P['IB_reused']=='-1/3' and P['IBB_new_control_moment']=='-1/4' and R['four_vertex_Berezin_units']==['-1','-1'] and P['resolvent_and_spin_remainders']==P['full_D_BB_sewing_remainder']=='0'
assert not P['adjoint_only_projection_used'] and not P['quantum_coefficients_assigned_from_counterterm'] and not R['quantum_coefficients_assigned_from_counterterm']
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));HF=dec(Y['H_new']);f=defaultdict(list)
for a,b,e,z in packed(CAL/'canonical_so10_ghost_triangle_field_insertion/qualified_reference_inputs.json.gz')['reference_fields']['plane_f']:f[a,b].append((e,Q(z)))
plain=fromtable(P['unweighted_left']);counts={};compared=0;hc={};oriented_aux={}
for power in ['4','3']:
 L=fromtable(P['left'][power]);RR=fromtable(P['right'][power]);counts[power]={'left':tabnz(L),'right':tabnz(RR)}
 for c in range(45):
  for d in range(45):
   l=L.get((c,d),Mat(16,16));r=RR.get((c,d),Mat(16,16));zero(plus(r,trans(l)));zero(plus(l,trans(star(l))));compared+=512
   if power=='4':zero(minus(at_one(l),scale(plain.get((c,d),Mat(16,16)),Q(P['units']['4'][0]))))
   for v in l.d.values():assert all(k[0]>=0 and k[1]>=0 for k,z in v)
 hc[power]=[]
 for u in range(12):
  th=Mat(16,16);fh=defaultdict(lambda:Z)
  for a in range(45):
   z=HF.d.get((a,u),Z)
   if z:
    th=plus(th,scale(T[a],z))
    for b in range(45):
     for e,v in f[a,b]:fh[b,e]=add(fh[b,e],prod(z,v))
  inverse=defaultdict(list)
  for (a,b),z in fh.items():
   if z:inverse[b].append((a,z))
  var={}
  for (c,d),m in L.items():
   if not m.d:continue
   putm(var,(c,d),minus(mul(th,m),mul(m,th)),neg(II))
   for a,v in inverse[c]:putm(var,(a,d),m,neg(v))
   for a,v in inverse[d]:putm(var,(c,a),m,neg(v))
  n=tabnz(var);assert n==0;hc[power].append(n)
for side in ['left','right']:
 a=fromtable(P['basis'][side]['H']['E_C']);b=fromtable(P['basis'][side]['H']['E_S']);rawsum=tablinear(a,b,ONE,ONE)
 assert tabnz(rawsum)==0;oriented_aux[side]={'E_C':tabnz(a),'E_S':tabnz(b)};assert tabnz(a)>0 and tabnz(b)>0
 assert counts['3'][side]==0
assert P['controls']['3']['premature_barred_GF_end']==0
vs=packed(CAL/'canonical_so10_vector_contact_breaking/replay_tables.json.gz')['partition']['fermion_edge'];assert sorted(vs)==P['supported_witnesses'] and len(vs)==6
orders=Counter(str(json.loads(w)[5]) for w in vs);assert orders=={'4':4,'3':2}
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_VECTOR_FERMION_EDGE_MATTER_BREAKING_FAMILY','disposition':'ORDINARY_FAMILY_MEASURED_AUXILIARY_ENDPOINT_PAIR_ZERO','elapsed_after_imports':time.perf_counter()-start,'profiles_measured':6,'profile_orders':dict(orders),'remaining_vector_profiles_unmeasured':34,'coefficient_positions_compared':compared,'nonzero_counts':counts,'oriented_auxiliary_raw_counts':oriented_aux,'all12_H_tensor_remainders':hc,'right_plus_left_transpose_and_antiHermitian_remainders':0,'IB_reused':P['IB_reused'],'IBB_new_control_moment':P['IBB_new_control_moment'],'ordinary_raw_phases':P['ordinary_raw_phases'],'auxiliary_raw_phases':P['auxiliary_raw_phases'],'units':P['units'],'controls':P['controls'],'adjoint_only_projection_used':False,'new_radial_integrations':0,'quantum_coefficients_assigned_from_counterterm':False,'whole_vector_or_full_restoration_QAP_measure_phase_massiveC1_E5A5_unification_qualified':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
