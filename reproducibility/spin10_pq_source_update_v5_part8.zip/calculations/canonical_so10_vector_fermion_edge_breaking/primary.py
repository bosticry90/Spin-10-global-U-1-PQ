"""VFE1 actual gauge resolvent/Clifford chains and ordered triple products."""
from data import *
start=begin('primary')
G=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/primary_tables.json.gz');Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];HF=dec(Y['H_new']);W=plus(scale(ident(45),Q('xi')),scale(mul(HF,trans(HF)),Q('eta_H-xi')))
V={(r,a,c):Q(z) for r,a,c,z in G['plane_V']};H={(r,a,c):Q(z) for r,a,c,z in G['plane_H']};wr=rowmaps(trans(W));C=defaultdict(lambda:Z)
for (r,a,c),co in V.items():
 for b,w in wr[r]:C[b,a,c]=add(C[b,a,c],prod(co,w))
C={k:v for k,v in C.items() if v}
for (r,a,c),v in H.items():assert add(v,H.get((a,r,c),Z))==Z
pa=[sy.Matrix([[0,1],[1,0]]),sy.Matrix([[0,-sy.I],[sy.I,0]]),sy.diag(1,-1)];g4=[sy.kronecker_product(pa[1],v) for v in pa]+[sy.kronecker_product(pa[0],sy.eye(2))];gg=[sy.kronecker_product(v,pa[2]) for v in g4]+[sy.kronecker_product(sy.eye(4),v) for v in pa[:2]]
chi=sy.prod(gg[:4]);PL=(sy.eye(8)+chi)/2;PR=sy.eye(8)-PL;bv=sy.symbols('b0:4');hv=sy.symbols('h0:2');bs=sum((v*x for v,x in zip(bv,gg[:4])),sy.zeros(8));hs=sum((v*x for v,x in zip(hv,gg[4:])),sy.zeros(8));b=sy.kronecker_product(bs,sy.eye(2));h=sy.kronecker_product(hs,sy.eye(2));O=sy.zeros(16);N=b.row_join(h).col_join(h.row_join(b));bh=sum(v*v for v in bv)*sum(v*v for v in hv)
tr,ta,td=pa[0],pa[2],sy.eye(2)+pa[0]
def AA(t):return sy.kronecker_product(PL,t)+sy.kronecker_product(PR,-t.T)
Ar,Aa,Ad=AA(tr),AA(ta),AA(td);At=sy.kronecker_product(PR,ta)+sy.kronecker_product(PL,-ta.T)
for mu in range(4):
 gm=sy.kronecker_product(gg[mu],sy.eye(2));delta=(-sy.I*gm*Ad).row_join(O).col_join(O.row_join(O));dS=-(-sy.I*N)*delta*(-sy.I*N)
 pS=-sy.I*b*gm*Ad*h;sP=-sy.I*h*gm*Ad*b
 assert not (dS[:16,16:]-pS).applyfunc(sy.expand).todok() and not (dS[16:,:16]-sP).applyfunc(sy.expand).todok()
 ec=(-sy.I*b*Ar)*pS*(-h*Aa);es=(At*h)*sP*(-sy.I*b*Ar)
 assert not (ec-bh*gm*Ar*Ad*Aa).applyfunc(sy.expand).todok() and not (es+bh*gm*Aa*Ad*Ar).applyfunc(sy.expand).todok()
# Full-D derivative sewing;the barred current only acts AFTER this identity.
km=sy.symbols('k0:6');K2=sum(v*v for v in km);w=sy.Symbol('w')
for mu in range(6):assert sy.simplify(sum((int(mu==nu)+(w-1)*km[mu]*km[nu]/K2)*km[nu] for nu in range(6))-w*km[mu])==0
three=list(map(sy.sympify,G['cumulant_units']));ordinary=[sy.simplify(three[0]*(+1)*(-sy.I)),sy.simplify(three[1]*(-1)*(+sy.I))];aux=[sy.simplify(three[0]*(+1)*sy.I*(+1)),sy.simplify(three[1]*(-1)*sy.I*(-1))]
AS=packed(CAL/'canonical_so10_auxiliary_scalar_matter_breaking/primary_tables.json.gz');IB=sy.sympify(AS['finite_moments']['IB']);eps,hd=sy.symbols('epsilon h');IBB=sy.limit((hd*4*6*sy.gamma(eps)/(8*sy.gamma(5))).subs(hd,-2*eps),eps,0);assert IB==sy.limit((hd*4*sy.gamma(eps)/(4*sy.gamma(4))).subs(hd,-2*eps),eps,0)
units={'4':[str(x*IB) for x in ordinary],'3':[str(x*IB*WM) for x in aux]};basis={};answers={};controls={}
for side,ts in [('left',T),('right',U)]:
 @lru_cache(maxsize=2025)
 def pair(a,b):return mul(ts[a],ts[b])
 basis[side]={}
 for tag,coefs in [('I',V),('W',C),('H',H)]:
  ec={};es={}
  for (b0,a,c),co in coefs.items():
   for d in range(45):
    putm(ec,(c,d),mul(pair(b0,d),ts[a]),co);putm(es,(c,d),mul(pair(a,d),ts[b0]),co)
  basis[side][tag]={'E_C':table(ec),'E_S':table(es)};print('STAGE FERMION_EDGE_TRIPLES',side,tag,flush=True)
 answers[side]={}
 for power,tag in [('4','W'),('3','H')]:
  ec=fromtable(basis[side][tag]['E_C']);es=fromtable(basis[side][tag]['E_S']);answers[side][power]=tablinear(ec,es,Q(units[power][0]),Q(units[power][1]))
  if side=='left':controls[power]={'omit_E_C':tabnz(tablinear(ec,{},Q(units[power][0]),Z)),'omit_E_S':tabnz(tablinear(es,{},Q(units[power][1]),Z)),'extra_Nambu_half':tabnz(answers[side][power]),'reverse_GF_insertion':tabnz(answers[side][power]),'wrong_right_transpose_sign':tabnz(answers[side][power])}
weighted=tablinear(fromtable(basis['left']['W']['E_C']),fromtable(basis['left']['W']['E_S']),ONE,ONE);plain=tablinear(fromtable(basis['left']['I']['E_C']),fromtable(basis['left']['I']['E_S']),ONE,ONE)
bad=tablinear(plain,weighted,Q(str(ordinary[0]*(IB-IBB))),Q(str(ordinary[0]*IBB)));controls['4']['premature_barred_GF_end']=tabnz(tabminus(answers['left']['4'],bad));controls['4']['wrong_auxiliary_antisymmetry']=tabnz(answers['left']['4']);controls['3']['premature_barred_GF_end']=0
family=packed(CAL/'canonical_so10_vector_contact_breaking/primary_tables.json.gz')['partition']['fermion_edge'];assert len(family)==6
finish('primary',{'method':'gauge_resolvent_explicit_noncommuting_Clifford_direct_triples','ordinary_raw_phases':list(map(str,ordinary)),'auxiliary_raw_phases':list(map(str,aux)),'IB_reused':str(IB),'IBB_new_control_moment':str(IBB),'units':units,'resolvent_and_spin_remainders':'0','full_D_BB_sewing_remainder':'0','basis':basis,'left':{p:table(v) for p,v in answers['left'].items()},'right':{p:table(v) for p,v in answers['right'].items()},'unweighted_left':table(plain),'weighted_left':table(weighted),'controls':controls,'weighted_C':[[*k,textq(v)] for k,v in sorted(C.items())],'supported_witnesses':sorted(family),'newly_measured_profiles':6,'remaining_vector_profiles_unmeasured':34,'adjoint_only_projection_used':False,'new_radial_integrations':0},start)
