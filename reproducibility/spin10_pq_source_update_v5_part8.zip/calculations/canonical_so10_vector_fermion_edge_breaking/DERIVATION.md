# VFE1: gauge derivative of the actual mixed fermion line

Let b=bar_gamma.kbar,h=hat_gamma.khat. With physical gauge insertion
deltaD_PP=-ig gamma_mu A_d,the actual mixed block resolvent gives

 deltaS_PS=-ig b gamma_mu A_d h/K2^2,
 deltaS_SP=-ig h gamma_mu A_d b/K2^2.

Insert these blocks into GTT1's two open graphs. Before the GF factor,
E_C gives +g^3 hatk2*bark2 gamma_mu A_b A_d A_a;
E_S gives -g^3 hatk2*bark2 gamma_mu A_a A_d A_b.
The ordinary GF Fourier factors are -igV and+igV,respectively,so both
raw ordinary phases are-i. Auxiliary+i xiH and opposite BL/LB signs
give+i xi in BOTH placements. An independent fourth-order Berezin
calculation must reproduce these phases rather than copying a mass kernel.

The common integral is IB=FP integral hatk2*bark2/(K2+m2)^4=-1/3.
Consequently the expected programs after actual phase/moment derivation
are ordinary(+i/3)sumC(Tb Td Ta+Ta Td Tb),and auxiliary
(-i xi/3)sumH(Tr Td Ta+Ta Td Tr). These are action-derived templates,not
coefficients assigned from CFC1. Replay derives the units independently.
H_ra,c=-H_ar,c can annul the auxiliary sum only after both placements.

For X,Y,Z matrices,
XZY+YZX=({X,Y}Z+Z{X,Y}-[X,[Y,Z]]-[Y,[X,Z]])/2.
Replay uses this identity with actual full45 f,including its nonadjoint
anticommutator part. Direct ordered triple multiplication is the separate
primary route. U=-T.T gives right=-left.T after the two placements exchange.

A premature bar projection of the internal GF momentum changes k.GBB=Wk
to kbar plus (W-I)kbar*bark2/K2. It replaces IB W by
IB I+IBB(W-I),with IBB=FP integral hatk2*(bark2)^2/(K2+m2)^5=-1/4.
The Schwinger numerators are h*4/(4Gamma4) and h*4*6/(8Gamma5),times
Gamma(epsilon). No physical momenta or widths are specialized. At W=I
the two expressions coincide,as a control should acknowledge. No extra
full-D vector trace is generated in this fermion-edge contraction.
