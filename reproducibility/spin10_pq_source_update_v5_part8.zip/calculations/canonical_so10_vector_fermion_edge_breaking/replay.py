"""VFE1 Berezin/abstract-Clifford units and double-Lie triple reduction."""
from data import *
start=begin('replay')
def eclean(d):return {k:sy.expand(v) for k,v in d.items() if sy.expand(v)!=0}
def eadd(a,b):
 d=dict(a)
 for k,v in b.items():d[k]=d.get(k,0)+v
 return eclean(d)
def escale(z,a):return eclean({k:z*v for k,v in a.items()})
def ewedge(a,b):
 d=defaultdict(lambda:sy.S.Zero)
 for ka,x in a.items():
  for kb,y in b.items():
   if not ka&kb:d[ka|kb]+=(-1)**sum((kb&((1<<i)-1)).bit_count() for i in range(10) if ka&(1<<i))*x*y
 return eclean(d)
def eword(seq,co):
 d={0:co}
 for i in seq:d=ewedge(d,{1<<i:1})
 return d
fd1,fd2,gd,al,be,ce,de=sy.symbols('fd1 fd2 gd alpha beta gamma delta',nonzero=True);four=[]
for ew,vw in [([0,8,7,2],[3,4]),([0,8,3,4],[7,2])]:
 action={}
 for word,co in [([4,5],-fd1),([6,7],-fd2),([8,9],-gd),(ew,al),(vw,be),([5,6],ce),([9,1],de)]:action=eadd(action,eword(word,co))
 term={0:sy.S.One};zz=dict(term)
 for n in range(1,6):term=escale(-sy.Rational(1,n),ewedge(term,action));zz=eadd(zz,term)
 mask=sum(1<<i for i in range(4,10));four.append(sy.simplify(zz[(1<<10)-1]*fd1*fd2*gd/(zz[mask]*al*be*ce*de)))
ordinary=[sy.simplify(four[0]*(-1)*(-sy.I)**2*(-sy.I)**2*(-sy.I)),sy.simplify(four[1]*(+1)*(-sy.I)**2*(-sy.I)**2*(+sy.I))]
aux=[sy.simplify(four[0]*(-1)*(-sy.I)**2*(-sy.I)**2*sy.I*(+1)),sy.simplify(four[1]*(+1)*(-sy.I)**2*(-sy.I)**2*sy.I*(-1))]
# Independent chirality walk: b and the external gamma each flip;h does not.
ar,al0,rr,rl,dr,dl=sy.symbols('aR aL rR rL dR dL')
for seq,target in [(['b','Ar','b','mu','Ad','h','h','Aa'],rl*dl*al0),(['Ata','h','h','mu','Ad','b','b','Ar'],al0*dl*rl)]:
 chir=0;co=sy.S.One
 for token in reversed(seq):
  if token in ['b','mu']:chir=1-chir
  elif token in ['Aa','Ata','Ar','Ad']:co*=({'Aa':[al0,ar],'Ata':[ar,al0],'Ar':[rl,rr],'Ad':[dl,dr]}[token][chir])
 assert chir==1 and sy.expand(co-target)==0
eps,h=sy.symbols('epsilon h');IB=sy.sympify(packed(CAL/'canonical_so10_auxiliary_scalar_matter_breaking/replay_tables.json.gz')['finite_moments']['IB']);IBB=sy.limit((h*4*(4+2)*sy.gamma(eps)/(8*sy.factorial(4))).subs(h,-2*eps),eps,0);assert IB==sy.limit((h*4*sy.gamma(eps)/(4*sy.factorial(3))).subs(h,-2*eps),eps,0)
units={'4':[str(v*IB) for v in ordinary],'3':[str(v*IB*WM) for v in aux]}
G=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/replay_tables.json.gz');u={j:{(r,a,c):Q(z) for r,a,c,z in rows} for j,rows in G['plane_jets'].items()};V={k:sub(u['a'].get(k,Z),u['B'].get(k,Z)) for k in set(u['a'])|set(u['B'])};V={k:v for k,v in V.items() if v};H={(r,a,c):Q(z) for r,a,c,z in G['plane_H']}
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];HF=dec(Y['H_new']);PH=mul(HF,trans(HF));W=plus(scale(ident(45),Q('xi')),scale(PH,Q('eta_H-xi')))
C=defaultdict(lambda:Z)
for (r,a,c),v in V.items():
 for b in range(45):
  w=W.d.get((b,r),Z)
  if w:C[b,a,c]=add(C[b,a,c],prod(w,v))
C={k:v for k,v in C.items() if v}
for (r,a,c),v in H.items():assert add(v,H.get((a,r,c),Z))==Z
f=defaultdict(list)
for a,b,e,z in packed(CAL/'canonical_so10_ghost_triangle_field_insertion/qualified_reference_inputs.json.gz')['reference_fields']['plane_f']:f[a,b].append((e,Q(z)))
sums={};ff={}
for tag,tab in [('I',V),('W',C),('H',H)]:
 dd=defaultdict(lambda:Z)
 for (b,a,c),co in tab.items():
  for d in range(45):
   for e,z in f[a,d]:
    for v,y in f[b,e]:dd[c,d,v]=add(dd[c,d,v],prod(co,prod(z,y)))
   for e,z in f[b,d]:
    for v,y in f[a,e]:dd[c,d,v]=add(dd[c,d,v],prod(co,prod(z,y)))
 ff[tag]={k:v for k,v in dd.items() if v}
 print('STAGE DOUBLE_LIE_COEFFICIENTS',tag,flush=True)
answers={};raws={}
for side,ts in [('left',T),('right',U)]:
 raws[side]={}
 for tag,tab in [('I',V),('W',C),('H',H)]:
  ps=[Mat(16,16) for _ in range(45)]
  for (b,a,c),co in tab.items():ps[c]=plus(ps[c],scale(plus(mul(ts[b],ts[a]),mul(ts[a],ts[b])),co))
  dd={}
  for (c,d,e),co in ff[tag].items():putm(dd,(c,d),ts[e],co)
  out={}
  for c in range(45):
   for d in range(45):out[c,d]=scale(plus(plus(mul(ps[c],ts[d]),mul(ts[d],ps[c])),dd.get((c,d),Mat(16,16))),Q('1/2'))
  raws[side][tag]=out
 answers[side]={'4':tablinear(raws[side]['W'],{},Q(units['4'][0]),Z),'3':tablinear(raws[side]['H'],{},Q(units['3'][0]),Z)}
 # Equal endpoint units follow from the independently derived Berezin spin.
 assert units['4'][0]==units['4'][1] and units['3'][0]==units['3'][1]
ib=packed(CAL/'canonical_so10_matter_degreezero_support/replay_tables.json.gz');family=[]
for st in ib['targets']['cBPP']['candidate']:
 w=json.loads(st);v=[json.loads(n) for n in w[0]];bext=next(p[0] for p in w[1] if p[1]=='B');ei=next(i for i,x in enumerate(v) if x[0].startswith('E_'))
 if v[bext][0]=='PPB' and any(p[0]==ei and p[1]=='P' for p in w[1]):family.append(st)
assert len(family)==6
finish('replay',{'method':'exact_Berezin_abstract_chirality_Schwinger_double_Lie','four_vertex_Berezin_units':list(map(str,four)),'ordinary_raw_phases':list(map(str,ordinary)),'auxiliary_raw_phases':list(map(str,aux)),'IB_reused':str(IB),'IBB_new_control_moment':str(IBB),'units':units,'resolvent_and_spin_remainders':'0','full_D_BB_sewing_remainder':'0','left':{p:table(v) for p,v in answers['left'].items()},'right':{p:table(v) for p,v in answers['right'].items()},'unweighted_left':table(raws['left']['I']),'weighted_left':table(raws['left']['W']),'weighted_C':[[*k,textq(v)] for k,v in sorted(C.items())],'supported_witnesses':sorted(family),'newly_measured_profiles':6,'remaining_vector_profiles_unmeasured':34,'adjoint_only_projection_used':False,'new_radial_integrations':0},start)
