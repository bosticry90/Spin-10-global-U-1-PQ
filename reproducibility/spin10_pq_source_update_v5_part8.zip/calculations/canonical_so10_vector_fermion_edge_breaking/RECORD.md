# VFE1: complete six-profile fermion-edge vector breaking

Base94d3080fc352c10d4c5b7df802a63bc3f242e38e/main31786 tracked blobs.
Current goal turn PROGRESS:VCT1. Whole Spin(10)xPQ ACTIVE/incomplete.
State113/authority34of39 unchanged. Current AGENTS delegation applies.

Question: what are the complete ordinary g4 and auxiliary g3 fermion-edge
cBPP coefficients among the remaining40 vector profiles? VCT1 qualified
the full42 partition and measured its two contact profiles. Its fermion
edge is a complete six-profile family:four ordinary,two auxiliary. Other
families remain required;this target does not replace the whole objective.

Use the actual SMA1 Dphys gauge derivative deltaD_PP=-ig gamma_bar_mu A_d,
S0=-i[[b,h],[h,b]]/K2 and deltaS=-S0 deltaD S0. Derive BOTH mixed blocks,
endpoint Clifford chains,phases and g grades BEFORE any source comparison.
At zero external ordinary momenta,the ordinary GF endpoints are -igVk
and+igVk,V=UA-UB; k.GBB=Wk,with full-dimensional k and
W=eta_H PH+xi PM. Auxiliary H uses the qualified opposite BL/LB signs.
Retain C_ba,c=sumW_br V_ra,c;it is not antisymmetric. Do not impose an
auxiliary cancellation on the ordinary class. A collective auxiliary zero
is an allowed result only after complete independent orientation pairing.

Same frozen mass-independent,one-loop Euclidean nonexceptional analytic
Feynman domain as MDS/GTT/ASB/VCT,physical external hats0,Abackground0,
all45 ghosts/vectors,16x16 color entries,both source chiralities,I3 family
identity with no closed-loop3 or extra half. No flavor/mass/width/scale or
physical scheme chosen. Positive-dimension/background/massive/measure/
phase,QAP and physical infrared limits stay separate.

Primary proves the gauge resolvent and contracted Clifford numerators with
explicit noncommuting color witnesses,then uses direct ordered triple
generator products. Replay derives the four-even-vertex Berezin unit and
abstract Clifford contraction,uses independent component width sums and
an anticommutator/double-Lie-commutator reduction. Preserve nonadjoint End16
components;do not project to adjoint-only because earlier source cochains
occupied that submodule. Workers deny CFC/MSP structured targets after
authentication. Counterterm coefficients do not assign loop values.

The pointwise sewn numerator is proportional to hatk2*bark2,so ASB1's
IB=-1/3 may be reused after this proof. Cheap Gamma/Schwinger controls
check the normalization,not a new costly integration. The early-barred
ordinary-boson diagnostic instead involves IBB=FP integral
hatk2*(bark2)^2/(k2+m2)^5. Derive it,do not insert an unweighted4D ratio.
Auxiliary fermion-end contractions are already barred and this particular
early-barred control may be insensitive;report that honestly.

Expected evidence:exact six-witness coverage;both raw phases and finite
moments;full ordinary/auxiliary coefficient and zero-complement agreement;
both oriented auxiliary maps retained before any zero claim;right=-left.T,
anti-Hermitian totals;all12 H tensor tests;general family identity;full
nonnegative polynomial widths with g3/g4 separate. Compare no partial sum
to the full CFC target as a restoration test. No unknown remainder fit.

Controls:omit each E placement,reverse GF insertion,extra Nambu half,
unjustified C antisymmetry,early barred internal ordinary GF contraction,
unit-width counterfactual and wrong right transpose. Same-support controls
are not independent scientific confirmations. Retain invisible limits.

Freeze eight source files/copies,qualified input bytes and caps before
sequential primary/replay/gate. Each600s afterimports,8GiB sampled private
cap,350MiB available-commit floor,16MiB total packet. Stop first failure;
preserve sources/full captures,version corrections. This goal turn's fresh
VCT1 E4 command is authenticated reuse,not another command or historical
scientific replay. Fresh byte preflight/resources. Custodyexit2/seven
NOTPASS. No resource expansion or coefficient truncation.

Authority ceiling:complete measured fermion-edge family,not whole cBPP
restoration,full coupled finiteSlavnov/QAP/products/measure/phase,physical
chiral scheme,massive C1,E5/A5 or unification. SMP scalar correction and
free invariant constants unchanged. Both adverse scalar points,quartetFAIL,
flavor pause,HB1/C5 blocks persist. Preserve main,state,old evidence. No
agents,branch/worktree,foundation/scheme/benchmark adoption,outreach,
publication or push. After qualification continue indispensable remaining
ghost and vector responses under the same delegation.
