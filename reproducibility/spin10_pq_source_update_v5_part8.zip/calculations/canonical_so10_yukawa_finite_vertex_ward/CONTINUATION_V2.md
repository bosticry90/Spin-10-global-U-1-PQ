# YVF1 V2: preserve immutable-matrix control failure

Original primary failed native1 at line55 while constructing the PS/SP
omission control: the preceding symbolic expressions made E immutable,
so E.copy() could not accept block assignment. No primary coefficient table
or completed worker RESULT was produced; replay/verifier never launched.
The original source/copy/preparation, complete primary capture and controller
failure remain unchanged. This is an implementation failure, not a failed
Ward identity or scientific PASS. No scientific requirement is relaxed.

V2 changes that control's temporary to s.MutableDenseMatrix(E), retaining
the same omitted block, exact comparison and nonzero-remainder requirement.
It adds an explicit continuation-byte authentication before begin(). No
integral, physical input, phase, target, resource cap or old hash is changed.
New preparation_v2 binds all original evidence and the four new sources/
copies. Run primary_v2 under the same600s/8GiBsampled/350MiBfloor/16MiB
limits, followed by the previously unexecuted original replay and verifier.
All captures use fresh names; no failure is overwritten. Reuse the existing
current-turn OFK1 readiness. The whole investigation remains active and
authority34/39 unchanged. A further mismatch stops and remains evidence.
