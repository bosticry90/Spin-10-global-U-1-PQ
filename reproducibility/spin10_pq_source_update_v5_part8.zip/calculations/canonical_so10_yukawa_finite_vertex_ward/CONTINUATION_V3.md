# YVF1 V3: preserve replay compilation failure, reuse completed primary

V2 primary completed native0 and wrote authenticated complete tables.
The original replay then failed at compilation, before scientific work:
its dictionary-comprehension assignment expression attempted to rebind
the iteration variable v. ast.parse accepted this tree, but compilation
correctly rejected it. Original replay/source/preparation, complete native1
replay capture and V2 controller failure remain unchanged. No verifier ran.

The bounded correction renames the temporary expanded coefficient to z;
no coefficient formula, integral or requirement changes. New replay_v2.py
and controller/preparer are frozen separately. New source prelaunch checks
use compile(), not ast.parse alone. Keep the existing completed primary_v2
tables and native0 capture after byte authentication; do not rerun it.
Run replay_v2 under the unchanged600s/8GiBsampled/350MiBfloor/16MiB limits,
then the original, previously unexecuted verifier. Bind all failures and all
new bytes in preparation_v3. Authority34/39 and all scientific boundaries
remain unchanged; failures are not relabelled PASS. If a scientific mismatch
appears, preserve it and reassess rather than adjusting the target.
