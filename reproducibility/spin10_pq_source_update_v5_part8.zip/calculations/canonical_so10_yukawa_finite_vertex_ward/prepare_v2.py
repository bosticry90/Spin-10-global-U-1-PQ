"""YVF1 bounded continuation freeze; original evidence never rebound."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='c1c7db8bca4f91922735a771904956a8e1055740'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
bind=dict(read(HERE/'preparation.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
assert read(HERE/'primary_capture.json')['exit_code']==1 and read(HERE/'controller_failure.json')['last_role']=='primary'
assert not (HERE/'primary_tables.json.gz').exists() and not (HERE/'replay_capture.json').exists()
old=(HERE/'primary.py').read_text();new=(HERE/'primary_v2.py').read_text()
expected=old.replace("start=begin('primary')","for pn,ph in read(HERE/'preparation_v2.json')['input_sha256'].items():assert digest(Path(pn))==ph,pn\nstart=begin('primary')").replace('bad=E.copy();','bad=s.MutableDenseMatrix(E);')
assert new==expected
for n in ['CONTINUATION_V2.md','primary_v2.py','prepare_v2.py','run_v2.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw)
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
for p in HERE.iterdir():
 if p.is_file():bind[str(p)]=digest(p)
with (HERE/'preparation_v2.json').open('xb') as f:f.write((json.dumps({'schema':'YVF1_CONTINUATION_V2_PREPARATION','input_sha256':dict(sorted(bind.items())),'original_primary_native_exit':1,'original_failure_relabelled_PASS':False,'scientific_requirements_or_resource_limits_changed':False,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('YVF1_V2_FROZEN',len(bind),flush=True)
