# YVF1: finite Yukawa gauge vertex and direct open-line Ward insertion

Scientific question: does OFK1's zero Yukawa kinetic difference extend to
the proper gauge vertex, and does an actual regulated matter-current
breaking insertion account for the result? This is the smallest next
nontrivial open-line identity, without an internal gauge propagator or an
undefined interacting full-gauge comparison. Base
c1c7db8bca4f91922735a771904956a8e1055740/main,31178 tracked blobs.

Claim under test: calculate both complete mass-independent gY^2 finite
proper current-vertex comparison families, then independently sew the
actual SMA1 charged-sterile free Ward defect into the Yukawa loop. Test
the selected linear matter-current Ward relation with its scalar-current
companion and inverse-propagator endpoints. The12 unbroken H projections
are the selected identity scope. All45 ordinary B coefficient tensors are
retained. This is not the nonlinear full Slavnov identity or a complete
independent-background/source/QAP/measure restoration theorem.

Freeze current AGENTS/CHARTER/state113/V515/local/solo conventions, SMA1
action, SMP1 exact free inverse, GEP1 defect derivation, YGV1 complete
two-family support/sign/covariance and both X/S/carrier/family tensor
tables, YCT1 actual45 generators/H frame, FGS1 support proof and receipts,
OFK1 physical embedding and its later kinetic comparator. Reuse the
qualified internal contractions rather than rerunning the entire group
calculation. Derived X/S tensors are explicit shared scientific inputs,
not independently confirmed premises. Workers do not read OFK1 answers.

Domain: mass-independent local finite part of one-loop proper P-P-B vertex
and its linear current identity, Euclidean physical external hats0 and
nonexceptional off-shell momenta. Dimensional family d=4-2eps,h=-2eps,
original two widths and all physical masses retained in the theory. This
particular class has no internal gauge line. Positive-dimensional insertions
lower the UV degree; their finite amplitudes are not set to0. Only a UV-
convergent evanescent difference may vanish at eps0 after the nonexceptional
domain argument. No physical constant-vacuum/IR/massive transfer.

Use actual barred current and pp numerator, full PS inverse for defect
sewing, physical external rank4 embedding. Reference chi anticommutes with
all Gamma; both fermion numerator and scalar-current routing are specified.
No parity averaging, Pfaffian half, witness8/2 or closed-family3 on open
chains. General complex symmetric family matrices remain, no numerical fit.

Primary: projected gamma8 spin chains at auxiliary ranks0,1,2 determine
fermion and scalar-current differences. Integrate the finite evanescent
Taylor kernel with an auxiliary positive IR mass; prove the subtracted
remainder vanishes in the stated off-shell domain. Separately differentiate
the actual PS inverse with physical field/source charge diag(A,0), derive
its full Ward defect and sew all blocks before extracting the physical
insertion. Integrate its hatted-pair contribution with Gaussian moments.
Replay: formal Clifford and ordered free-inverse identities, direct
nonexceptional Schwinger simplex construction of the insertion, plus an
independent dimension-counting derivation of the vertex difference. Reuse
the separately qualified YGV1 replay internal tensors and family factors.
Neither route may infer the insertion coefficient from a desired cancellation.

Retain the scalar-current companion: its actual Ward contraction cancels
endpoint terms by the actual B rho=i(T^T B+B T) identity. It may have zero
finite relative difference without having zero amplitude. The selected
linear relation is W_Y=q_mu Lambda_Y^mu+g Sigma_Y(k)A-g Atilde Sigma_Y(r),
with q=k-r. A full nonlinear/source-corrected Slavnov operator is not
identified with this linear current operator. Momentum translation is the
explicit off-shell dimensional prescription, not heat-trace cyclicity.

Gate: compare all finite vertex tensors and zero complements for both
carriers/chiralities/all45 directions, and12 H insertion/contracted vertex
tensors. Check general family polynomials, right minus-transpose for an
ordinary gauge vertex, source orientation unchanged, exact free Ward
endpoints, and scalar-current covariance. Later compare OFK1's zero Yukawa
two-point difference. Controls omit either mixed defect block, use charged
sterile sources, omit the scalar-current endpoint companion, use wrong h
sign, transpose the internal charge, or insert half/family3. A failed
identity retains its exact remainder; it is not fitted or called anomaly.

Possible outcomes: qualified finite comparison and measured selected
insertion relation; preserved mismatch; or resource/domain incompleteness.
The negative measured local vertex is only a selected current-counterterm
direction, not automatically a complete admissible finite action/source
completion. Preserve b0,kappa,zeta ambiguity and all physical-control failures.

Resources frozen before workers: eight sources/copies, sequential peer-
denied primary/replay/verifier,600s after imports each,8GiB sampled private
cap,350MiB launch commit floor,16MiB package. Authenticate reuse of OFK1's
fresh E4 command in this same logical goal turn, not a second execution or
fresh historical science. No agents or old evidence edits. Stop at first
failure, preserve full sources/captures; version any continuation.

Established comparator: arXiv2004.14398v2 Sec6 discusses finite breaking
insertions separately from singular poles; its counterterm prescription
is not imposed on this relative comparison. Shared action, old X/S data,
dimensional integration, software and AI author limit independence.
Native evidence and interpretation will be recorded in RESULT/receipt;
no authority change or physical scheme adoption. Flavor stays paused,
HB1/C5 blocked,E5/A5 unqualified,custody exit2/seven NOTPASS; no branch,
worktree,push,outreach/publication or fitted benchmark rescue.
