# YVF1 fixed current, defect and finite-integral conventions

The qualified YGV1 open inverse-response sign is+V_i S V_B S V_i,
V_B=-ig barGamma A, S=-i numerator/k^2. Thus the fermion-current phase is+i.
The scalar inverse-response sign and the actual two real derivative branches
give phase+2 multiplying rho_ij k_mu. These are action-derived inputs, not
signs chosen from the Ward target. For left chirality define
X_a=sum_i b_i^dag T_a^T b_i, S_a=sum_ij rho_a,ij b_i^dag b_j,
N=sum_i b_i^dag b_i. Actual covariance gives S_a=-i(T_a N+X_a).
The right ordinary-gauge coefficient is minus the full transpose.

Primary must calculate, rather than assume, projected spin chains
P_outer slash(k) Gamma_mu P_charge slash(k) P_inner. Actual slash and
Lorentz sum are barred, reference slash is full with chiAC. Its physical
external embedding is OFK1's rank4 map; no open-line trace divisor exists.
Scalar-current numerator has one slash and one barred loop component.
A single projected hat may vanish; this does not eliminate two-hat chains.
Integer h witnesses determine a polynomial, then analytically h=-2epsilon.

The reference and actual integrands have the same strict4D limit. Subtract
their degree0 UV Taylor term using a positive auxiliary mass m_IR. At
nonexceptional Euclidean external momenta the difference of remainder
kernels is UV/IR integrable and proportional to h after symmetric hat
contraction. Hence its eps0 limit vanishes. The finite local comparison is
obtained from the Taylor term, not from assigning a scaleless integral0.
Normalize integral k^2/(k^2+m_IR^2)^3=(d/4)Gamma(eps)m_IR^(-2eps).

Actual free PS inverse and propagator, with physical chi commuting hats:
D(p)=i[[bar p,hat p],[hat p,bar p]],
S(p)=-i[[bar p,hat p],[hat p,bar p]]/p^2.
Let G=diag(A,0),Gt=diag(Atilde,0), A=PL T+PR R,R=-T^T,
Atilde=PR T+PL R, q=k-r, qhat=0. Derive from these matrices
E=D(k)G-GtD(r)-i diag(bar q A,0).
Then check the exact sewn identity, retaining both endpoints:
i S(k)diag(bar q A,0)S(r)=G S(r)-S(k)Gt-S(k)E S(r).
Project the PP block only after sewing both off-diagonal E blocks. Attach
both scalar vertices and the scalar propagator to obtain the actual loop
insertion. Its color order and sign must be derived before comparing the
finite vertex. An independent Schwinger simplex with three denominators
has the hatted second moment; its eps0 limit is governed by the simplex
volume, while the nonexceptional remainder is finite. No integrated
coefficient is copied from the finite vertex calculation.

For the complete two-family current relation, the fermionic contraction
produces inverse-propagator endpoints and this E insertion. The scalar
current obeys q.(2l+q)=(l+q)^2-l^2. Its endpoint terms combine using
sum_j V_j rho_ji=i(V_i A-Atilde V_i), inherited from the actual real
scalar covariance and mass conjugation. Before integration the routing
relations are retained; after the specified momentum translations, the
scalar terms cancel the commutator endpoints. This proves applicability
of the selected linear current identity without assuming a full QAP.

Report physical H projections using the fixed45x12 H frame, full45 vertex
tensors and general YdagY/YYdag matrices. Interpret a negative finite vertex
as a selected linear-identity subtraction only. Higher-field/source terms,
nonlinear Slavnov compatibility, finite pure-gauge/auxiliary families,
Yukawa proper coupling vertex, measure/phase and massive matching remain.
