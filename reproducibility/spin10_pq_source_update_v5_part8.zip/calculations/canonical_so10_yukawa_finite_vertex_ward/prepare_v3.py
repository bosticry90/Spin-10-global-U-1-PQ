"""YVF1 V3 freeze with compilation and authenticated primary reuse."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='c1c7db8bca4f91922735a771904956a8e1055740'
bind=dict(read(HERE/'preparation_v2.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
assert read(HERE/'replay_capture.json')['exit_code']==1 and read(HERE/'controller_failure_v2.json')['last_role']=='replay'
pr=read(HERE/'primary_v2_result.json');cap=read(HERE/'primary_v2_capture.json');assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
b=(HERE/'primary_tables.json.gz').read_bytes();assert sha256(b).hexdigest()==pr['packed_sha256'] and sha256(gzip.decompress(b)).hexdigest()==pr['tables_sha256']
assert not (HERE/'replay_tables.json.gz').exists() and not (HERE/'validation_preparation.json').exists()
src=(HERE/'replay.py').read_text();new=(HERE/'replay_v2.py').read_text();assert new==src.replace("{k:v for k,v in A.items() if (v:=s.expand(v))!=0}","{k:z for k,v in A.items() if (z:=s.expand(v))!=0}")
for n in ['CONTINUATION_V3.md','replay_v2.py','prepare_v3.py','run_v3.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
compile((HERE/'verify.py').read_bytes(),str(HERE/'verify.py'),'exec')
for p in HERE.iterdir():
 if p.is_file():bind[str(p)]=digest(p)
with (HERE/'preparation_v3.json').open('xb') as f:f.write((json.dumps({'schema':'YVF1_CONTINUATION_V3_PREPARATION','input_sha256':dict(sorted(bind.items())),'completed_primary_reused':True,'failed_replay_native_exit':1,'original_failures_relabelled_PASS':False,'scientific_requirements_or_resource_limits_changed':False,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('YVF1_V3_FROZEN',len(bind),flush=True)
