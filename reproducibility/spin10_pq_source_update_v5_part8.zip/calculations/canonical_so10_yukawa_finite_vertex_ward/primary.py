"""YVF1 projected vertex chains and literal actual PS Ward-defect sewing."""
from data import *
from itertools import product
start=begin('primary')
def zero(M):assert not s.SparseMatrix(M).applyfunc(s.expand).todok()
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g4=[s.kronecker_product(pa[1],a) for a in pa]+[s.kronecker_product(pa[0],s.eye(2))]
gs=[s.kronecker_product(g,pa[2]) for g in g4]+[s.kronecker_product(s.eye(4),a) for a in pa[:2]]
ch4=s.prod(g4);cb=s.prod(gs[:4]);ca=s.I*s.prod(gs);U=s.kronecker_product(ch4,s.Matrix([0,1]));P4=[(s.eye(4)+ch4)/2,(s.eye(4)-ch4)/2]
Ps=[[(s.eye(8)+ch)/2,(s.eye(8)-ch)/2] for ch in [cb,ca]]
spin={};left_samples=[];scalar_zero=0
for nh in range(3):
 for mu in range(4):
  for outer,charge,inner in product(range(2),repeat=3):
   vals=[]
   for kind in range(2):
    P=Ps[kind];N=sum((P[outer]*gs[j]*gs[mu]*P[charge]*gs[j]*P[inner] for j in range(4 if kind==0 else 4+nh)),s.zeros(8));N=(U.H*N*U).applyfunc(s.expand)
    c=s.simplify(s.trace(g4[mu]*N)/2);zero(N-c*g4[mu]*P4[inner]);vals.append(c)
   spin[f'{nh}_{mu}_{outer}{charge}{inner}']=list(map(str,vals))
   if mu==0 and (outer,charge,inner)==(1,1,0):left_samples.append(-vals[1])
  for outer,inner in product(range(2),repeat=2):
   for j in range(6):
    # Angular k_bar_mu*k_j selects only j=mu. Prove hat projection0 first.
    a=U.H*Ps[0][outer]*(gs[j] if j<4 else s.zeros(8))*Ps[0][inner]*U
    b=U.H*Ps[1][outer]*gs[j]*Ps[1][inner]*U
    zero(a-b);scalar_zero+=16
h,eps,m=s.symbols('h epsilon m_IR',positive=True);dim=4-2*eps
refnum=s.interpolate(list(enumerate(left_samples)),h);actnum=s.sympify(spin['0_0_110'][0])*(-1)
radial_regular=s.gamma(1+eps)*m**(-2*eps)*dim/4
vertex_regular=(actnum-refnum.subs(h,-2*eps))*radial_regular/dim
vertex_finite=s.simplify(s.diff(vertex_regular,eps).subs(eps,0))
# Independent actual PS defect, before any insertion coefficient comparison.
rv=s.symbols('r0:4');qv=s.symbols('q0:4');hh=s.symbols('u0:2');tL,tR=s.symbols('tL tR')
slash=lambda vv,gg:sum((v*g for v,g in zip(vv,gg)),s.zeros(8))
br=slash(rv,gs[:4]);bq=slash(qv,gs[:4]);bk=br+bq;hat=slash(hh,gs[4:]);H2=sum(v*v for v in hh)
P=Ps[0];A=P[0]*tL+P[1]*tR;At=P[1]*tL+P[0]*tR;O=s.zeros(8)
Nk=bk.row_join(hat).col_join(hat.row_join(bk));Nr=br.row_join(hat).col_join(hat.row_join(br))
G=A.row_join(O).col_join(O.row_join(O));Gt=At.row_join(O).col_join(O.row_join(O));B=(bq*A).row_join(O).col_join(O.row_join(O))
E=(s.I*Nk*G-s.I*Gt*Nr-s.I*B).applyfunc(s.expand)
expected=O.row_join(-s.I*At*hat).col_join((s.I*hat*A).row_join(O));zero(E-expected)
sewn=(-Nk*E*Nr).applyfunc(s.expand);zero(sewn[:8,:8]-s.I*H2*A*bq)
K2=sum((rv[i]+qv[i])**2 for i in range(4))+H2;R2=sum(v*v for v in rv)+H2
endpoint=(-s.I*K2*G*Nr+s.I*R2*Nk*Gt+Nk*E*Nr).applyfunc(s.expand)
zero(-s.I*Nk*B*Nr-endpoint)
# A full-AC reference has no such free defect for physical q.
Ar=Ps[1][0]*tL+Ps[1][1]*tR;Atr=Ps[1][1]*tL+Ps[1][0]*tR
zero((bk+hat)*Ar-Atr*(br+hat)-bq*Ar)
q4=sum((v*g for v,g in zip(qv,g4)),s.zeros(4));zero(U.H*P[1]*A*bq*P[0]*U-tR*q4*P4[0])
# Attaching V_i on each side gives m_i^dag R m_i=-X on the left.
# The +i sewn phase and that minus are retained before the Gaussian integral.
insert_regular=(-2*eps)/4*s.gamma(1+eps)*m**(-2*eps)
insert_integral=s.simplify(s.diff(insert_regular,eps).subs(eps,0));insert_left=s.simplify(-s.I*insert_integral)
omission={}
for role,sl in [('PS',(slice(0,8),slice(8,16))),('SP',(slice(8,16),slice(0,8)))]:
 bad=E.copy();bad[sl[0],sl[1]]=s.zeros(8);rest=(-Nk*bad*Nr-sewn)[:8,:8].applyfunc(s.expand)
 omission[role]=len(s.SparseMatrix(rest).todok());assert omission[role]>0
# Actual scalar vertex has all incoming q=-pi-pj, hence its ordered
# contraction is pj^2-pi^2, fixing the endpoint sign independently.
pi=s.symbols('a0:4');pj=s.symbols('b0:4');assert s.expand(sum((-a-b)*(a-b) for a,b in zip(pi,pj))-sum(b*b-a*a for a,b in zip(pi,pj)))==0
V,AA,AT,Sk,Sr=s.symbols('V A At Sk Sr',commutative=False);C=AT*V-V*AA;RhoV=-s.I*C
ferm_ends=-V*AA*Sr*V+V*Sk*AT*V;self_ends=-V*Sk*V*AA+AT*V*Sr*V
scalar_ends=-s.I*(RhoV*Sr*V+V*Sk*RhoV);ward_end=s.expand(ferm_ends+self_ends+scalar_ends);assert ward_end==0
endpoint_without_scalar=s.expand(ferm_ends+self_ends);assert endpoint_without_scalar!=0
Y=packed(CAL/'canonical_so10_yukawa_dependent_gauge_vertices/primary_tables.json.gz');X=[[dec(v) for v in row] for row in Y['X_internal']];Sc=[[dec(v) for v in row] for row in Y['S_internal']]
T=list(map(dec,packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz')['Tminus']));H=dec(packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz')['H_new'])
vertices=[[enc(s.I*vertex_finite*v) for v in row] for row in X]
selectedX=[[sum((H[a,j]*row[a] for a in range(45)),s.zeros(16)).applyfunc(s.simplify) for j in range(12)] for row in X]
insertions=[[enc(insert_left*v) for v in row] for row in selectedX]
cov_remainders=[]
for rr in range(2):
 N=dec(Y['normal_internal'][rr]);cov_remainders.append([enc((Sc[rr][a]+s.I*(T[a]*N+X[rr][a])).applyfunc(s.simplify)) for a in range(45)])
finish('primary',{'method':'projected_vertex_gamma8_and_actual_full_PS_defect_with_Gaussian_insertion','spin_role_coefficients':spin,'reference_color_numerator_polynomial':str(refnum),'actual_color_numerator':str(actnum),
 'vertex_difference_unit_left':str(s.I*vertex_finite),'insertion_integral_finite':str(insert_integral),'insertion_unit_left':str(insert_left),
 'fermion_vertex_left':vertices,'fermion_vertex_right':[[enc(-dec(v).T) for v in row] for row in vertices],
 'scalar_vertex_difference':[[enc(s.zeros(16)) for a in range(45)] for rr in range(2)],'selected_H_insertion_left':insertions,'selected_H_insertion_right':[[enc(-dec(v).T) for v in row] for row in insertions],
 'family_left':Y['family_left'],'family_right':Y['family_right'],'classical_covariance_remainders':cov_remainders,
 'free_defect_remainder':'0','sewn_Ward_endpoint_remainder':'0','reference_free_defect_remainder':'0','scalar_endpoint_remainder':str(ward_end),'endpoint_without_scalar':str(endpoint_without_scalar),
 'mixed_defect_block_omission_nonzero_positions':omission,'scalar_spin_difference_positions_checked':scalar_zero,
 'insertion_from_actual_PS_blocks':True,'finite_vertex_inferred_from_Ward_target':False,'open_line_half_or_family_three':False,'physical_scheme_adopted':False,'new_two_loop_integrals':0},start)
