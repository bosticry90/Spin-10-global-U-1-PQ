# YVF1 result: measured finite Yukawa current breaking and selected subtraction

Qualified within the frozen one-loop mass-independent Euclidean domain.
Receipt19c30c658e3662845a57026fbeaa0ce9e4a82d779c42eb274b298bcdeb5c20cb.
State113/authority34of39 unchanged; scientific acceptance NOT_PERFORMED.
The full Spin(10) x PQ investigation remains active and incomplete.

The zero Yukawa kinetic comparison from OFK1 does not extend to the proper
gauge vertex. In common g10/(16pi^2) units the finite actual-reference
left coefficients are

 delta Lambda_a = i gamma_mu PL * sum_R (Y_R^dag Y_R) tensor (X_R,a/2),
 X_10,a=-3/8 T_a, X_126,a=7/8 T_a.

Thus the two coefficients after i are-3/16 and7/16. The ordinary right
coefficient is minus the full transpose, with YYdagger family factors.
The scalar-current family's relative finite difference is0. Its actual
amplitude is not0, and it remains essential to the endpoint Ward identity.
All45 ordinary B directions and general complex symmetric family matrices
are retained. This is not a selected numerical flavor point or a physical
renormalization prescription.

The reference uses the specified full-Clifford fermion numerator; there is
no internal gauge propagator in these two families. The projected vertex
spin chains and their degree0 UV Taylor differences were calculated before
comparison with the Ward insertion. A positive auxiliary IR mass separates
the log residue. The evanescent subtracted remainder vanishes in the stated
nonexceptional Euclidean domain; no scaleless full amplitude was discarded.

The actual SMA1 source/field charge remains G=diag(A,0). Differentiating its
free PS inverse gives the nonzero off-diagonal Ward defect E. Both blocks
are sewn with the full PS propagator, and both inverse-propagator endpoints
are retained. For q=k-r,qhat=0 the PP numerator is

 [S(k) E S(r)]_PP = i*hatk^2*A*barslash(q)/(k^2 r^2).

Attaching the two actual Yukawa vertices puts the ordered color matrix
mdagger R m=-X on the left. The scalar propagator completes a genuine
three-denominator quantum insertion. Its hatted integral is independently
derived as-1/2 in16pi^2 units, using h=-2epsilon. The resulting local
insertion is+i X/2, exactly matching the contracted finite vertex.
This insertion coefficient was not assigned from the desired Ward result.

Primary uses explicit projected gamma8 chains and the literal16x16 PS
blocks, followed by Gaussian integration. Replay uses ordered exterior
Clifford blocks and a nonexceptional Schwinger simplex; its area1/2 fixes
the finite hatted integral. All free sewing identities agree exactly.
The scalar-current contraction uses the actual all-incoming momentum sign
q.(pi-pj)=pj^2-pi^2 and actual scalar covariance. Its endpoint terms cancel
the remaining commutator endpoints; omitting it leaves a nonzero expression.
Neither a heat-trace rearrangement nor a full QAP was assumed.

The tested linear current identity is
 W_Y=q_mu Lambda_Y^mu+g Sigma_Y(k)A-g Atilde Sigma_Y(r).
The12 fixed unbroken H projections of its finite relative image equal the
independently derived actual insertion. OFK1 supplies a separately measured
zero Yukawa two-point difference. Subtracting the negative measured local
vertex cancels this selected breaking with exact0 remainder. This is a
measured selected current subtraction, stronger than an algebraic variation
of an untested counterterm. It is not the full nonlinear Slavnov operation,
independent-background/source completion or simultaneous quantum restoration.

Verification compares46080 full fermion-vertex tensor positions,23040
scalar-current difference positions,12288 selected H insertion positions
and36 general family-polynomial positions, including all zero complements.
Each carrier's left vertex has720 nonzero internal entries. The48-dimensional
family lift is factorized and exact by bilinearity, not a giant expanded
polynomial replay. Previously qualified YGV1 X/S contractions and covariance
are authenticated shared inputs, not a fresh independent group-theory proof.

Controls reject omission of either PS/SP defect block, scalar-current
endpoints, wrong analytic h sign, internal charge transpose, wrong ordinary
right transpose, open half/family3 and an inference of zero vertex from
zero kinetic difference. No free finite normalization was chosen to pass.

Two implementation failures remain explicit. Original primary exited1
when an immutable SymPy matrix was modified for an omission control. V2
used a mutable temporary and completed; original replay then failed at
compilation because a comprehension assignment rebound its iteration
variable. ast.parse had missed that compile-time restriction. V3 renamed
only the temporary, added compile() checks, reused the completed primary
without rerunning it and executed the corrected replay plus original gate.
Original sources/copies, both complete native1 captures and both controller
failures are retained and bound. Neither failed execution is relabelled PASS.
No mathematical requirement, physical input or resource limit was weakened.

Completed primary_v2/replay_v2/verifier native0; elapsed after imports
4.388919799996074/3.4537564999991446/4.473162799993588s.
3/3/3 samples; sampled private maxima58081280/58880000/54669312 bytes,
not continuous peaks. Original failed primary2samples/max49016832;
failed replay1startup sample401408, not a peak. Frozen600s/8GiBsampled/
350MiBfloor/16MiB limits respected. Manifest counts45initial,56V2,70V3,
76validation;16source copies. Current-turn OFK1 fresh E4 command is
authenticated reuse here; no second readiness execution or old scientific
replay. Historical custody remains exit2/seven NOTPASS.
Coefficient table packed/raw SHA256:
4bd0830766c10436888ba7158eaf3fe3786f41f846cce64953361d21cee99bf8 /
8fb0954b00934773d7f3bd6f5ef8f33533ad0a5988a0a82c60b37551c57f596e.

This demonstrates an actual finite open-line breaking calculation and a
matching selected subtraction. The source-generation/compilation errors
also document a continuing engineering limitation. Shared action/data/
algebra/software/AI authorship remain; this is internal computational
corroboration, not independent expert or experimental validation.

Next: complete finite proper Yukawa-coupling inputs, starting with the
existing action-derived gauge-Yukawa three-family support and the exact
pure-Yukawa carrier zero, before a simultaneous finite matter/source
assembly. This subset needs a specified full internal scalar/gauge reference,
including hatted scalar-current vertices; do not use numerator-only changes.
The three pure-gauge ordinary current families and finite source sector also
remain. No full chiral measure/phase, massive fermion C1,E5/A5 or physical
unification is earned. b0,kappa,zeta remain distinct, no scheme adopted.
All eta=.3/eta=.0001 adverse results, flavor pause, HB1/C5 blocks, quartet
failure and historical custody persist. No old evidence or authority changed.
