"""VTF1 nonexceptional Feynman/Beta and ordered two-edge heat calculation."""
from data import *
tick=begin('replay');eps=s.Symbol('epsilon',positive=True);p2=s.Symbol('p2',positive=True);x=s.Symbol('x',real=True);nlog=s.Symbol('n_log',real=True)
dim=(4*s.pi/p2)**eps*s.gamma(eps)*s.gamma(1-eps)**2/s.gamma(2-2*eps)
dimfp=s.expand(s.series(dim,eps,0,1).removeO()-1/eps)
# The exact ordered Schwinger region a,b>=2t gives E1 with this x-dependent lower limit.
heatfp=s.expand(2*s.integrate(-s.EulerGamma-s.log(2*p2*(1-x)),(x,0,s.Rational(1,2)))+nlog)
relative=s.simplify(s.expand_log(dimfp-heatfp,force=True));chi=1+s.log(16*s.pi)-nlog
assert s.simplify(s.expand_log(relative-chi,force=True))==0
mp.mp.dps=70;errors=[]
for pp,tt in [('0.2','0.125'),('2','0.2'),('5','0.03125')]:
 p=mp.mpf(pp);t=mp.mpf(tt);a=t*p
 proper=2*mp.quad(lambda xx:mp.e1(2*a*(1-xx)),[0,mp.mpf('.5')])
 closed=2*mp.e1(2*a)-mp.e1(a)+(mp.exp(-a)-mp.exp(-2*a))/a
 assert abs(proper-closed)<mp.mpf('1e-60');errors.append(mp.nstr(abs(proper-closed),8))
R=packed(VTS/'replay_tables.json.gz');K=dec(R['kernel_unit'])
assert R['bubble_residue']==R['second_cumulant_unit']==R['tangent_E_vertex_phase_relative_positive_gxi']=='1'
assert R['source_J_Wick_phase']==R['primitive_Wick_phase']=='-1'
assert K.shape==(328,328) and len(K.todok())==1342
finish('replay',{'method':'nonexceptional_Feynman_Beta_and_ordered_Schwinger_lower_bound_integral',
 'relative_scalar_unit':str(s.expand_log(relative,force=True).expand()),
 'finite_kernel_chi4':enc(K),'finite_kernel_fixed':enc(s.SparseMatrix(328,328,{})),
 'relative_log_heat6_minus_heat4':str(s.log(s.Rational(3,2))),
 'proper_time_edges':2,'heat_length':4,'numerator_dimension_jet':'0',
 'relative_action_addition_sign':'1','relative_half_background_normalization_sign':'-1',
 'nonexceptional_finite_cutoff_errors':errors,'numerator_has_no_Lorentz_or_spin_trace':True,
 'full_kernel_reused_from_independent_Casimir_route':True,'new_model_color_contractions':0},tick)
