"""VTF1 positive auxiliary-mass Gamma/radial calculation, before model kernel."""
from data import *
tick=begin('primary');eps,z=s.symbols('epsilon z',positive=True);m2=s.Symbol('m2',positive=True);nlog=s.Symbol('n_log',real=True)
dim=(4*s.pi/m2)**eps*s.gamma(eps)
dimfp=s.expand(s.series(dim,eps,0,1).removeO()-1/eps)
heat=(1+z)*s.exp(z)*s.expint(1,z)-1
heatfp=s.expand(s.limit(heat+s.log(z),z,0)-s.log(4*m2)+nlog)
relative=s.simplify(s.expand_log(dimfp-heatfp,force=True))
chi=1+s.log(16*s.pi)-nlog
assert s.simplify(s.expand_log(relative-chi,force=True))==0
# Independent direct radial integration at finite positive cutoff, before FP.
mp.mp.dps=70;errors=[]
for mm,tt in [('0.3333333333333333333333333333333333333333','0.125'),('2','0.2'),('3.5','0.03125')]:
 m=mp.mpf(mm);t=mp.mpf(tt)
 radial=mp.quad(lambda u:u*mp.exp(-4*t*u)/(u+m)**2,[0,1,mp.inf])
 zz=4*t*m;closed=(1+zz)*mp.exp(zz)*mp.e1(zz)-1
 assert abs(radial-closed)<mp.mpf('1e-60');errors.append(mp.nstr(abs(radial-closed),8))
P=packed(VTS/'primary_tables.json.gz');K=dec(P['kernel_unit'])
assert P['bubble_residue']==P['second_cumulant_unit']==P['tangent_E_vertex_phase_relative_positive_gxi']=='1'
assert P['source_J_Wick_phase']==P['primitive_Wick_phase']=='-1'
assert K.shape==(328,328) and len(K.todok())==1342
finish('primary',{'method':'positive_mass_dimensional_Gamma_and_direct_positive_heat_radial_integral',
 'relative_scalar_unit':str(s.expand_log(relative,force=True).expand()),
 'finite_kernel_chi4':enc(K),'finite_kernel_fixed':enc(s.SparseMatrix(328,328,{})),
 'relative_log_heat6_minus_heat4':str(s.log(s.Rational(3,2))),
 'proper_time_edges':2,'heat_length':4,'numerator_dimension_jet':'0',
 'relative_action_addition_sign':'1','relative_half_background_normalization_sign':'-1',
 'radial_finite_cutoff_errors':errors,'numerator_has_no_Lorentz_or_spin_trace':True,
 'full_kernel_reused_from_actual_raw_source_vertex_route':True,'new_model_color_contractions':0},tick)
