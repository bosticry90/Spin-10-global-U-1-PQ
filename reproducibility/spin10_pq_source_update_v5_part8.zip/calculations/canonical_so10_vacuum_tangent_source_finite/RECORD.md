# VTF1: finite vacuum-tangent source comparison in the existing extension

Question: what is the complete local dimensional-minus-positive-heat Jx-h
coefficient in the already explicit provisional VTS z/h source extension?
JMF's marginal construction deliberately excludes this vacuum-source input.
This small full328-coordinate parent calculation is more informative than
repeating the large qualified matter projections or fitting physical masses.
Base0eaf3d94922184d7ea528100386b0bc1795409df/main33329oldblobs; state113/34of39.

Reuse VTS's actual ordered vertices/Wick source signs and paired independently
derived K=CsI-CsH kernel, not a Casimir inferred from a desired mass identity.
The source-left action contains tree-Jh, qz=h,qh0; z,h are external, not
integrated fields. Keep the inherited heavy projector/Gram maps and fixed
reference. At zero external background the same positive heat on each internal
free edge is exp(-2tq²). An h vertex is an interaction/source insertion; no
new h-dependent heat/reference is silently substituted. This is a comparison
of those fixed-reference quantum constructions, not a full extended QAP.

The complete selected VTS proper parent has a scalar and ghost edge and no
derivative/Lorentz numerator. Its critical symbol is K/q^4; the natural D lift
has no closed numeric vector/spin trace and zero numerator dimension jet.
Derive its finite radial map BEFORE inserting K. Positive auxiliary reference
mass or nonexceptional p_E² controls IR; prove the difference independent of
these completions by the convergent order-minus-six remainder. This does not
prove a physical constant-vacuum, massless causal or massive-fermion IR limit.

Primary: dimensional Gamma bubble and direct positive-mass radial heat integral.
Replay: nonexceptional dimensional Feynman/Beta bubble and independent ordered
two-edge proper-time integral. Both retain the common sphere/finite normalization
chi4=1+log(16pi)-n_log, heatlength4, Euler/radial constants and all zero slots.
No regulator coefficient may be supplied by a Ward cancellation or old VTS
mass target. Source phases/second cumulant are reused from VTS, not recomputed
or replaced by an extra half/family3. General Y10/Y126 remain untouched.

Compare every328² coefficient, both inherited kernel routes, symmetry/reality
and the actual scalar-to-Yukawa vacuum projection only after finite extraction.
Controls wrong Wick phase, extra half/family3 and heat6 instead of4 must change
the actual nonzero kernel directions. The full-Casimir replacement is already
known to be invisible on the frozen VEV; preserve that insensitivity and do not
advertise the selected mass projection as a full-kernel test.

Freeze8sources/copies and immutable inputs before sequential P/R/V600s after
imports each,8GiB sampledprivate/350MiBlaunchfloor/16MiBpacket. Authenticate the
fresh JMF E4 command, exits0/0/0/0/0/2,custody2sevenNOTPASS; no repeated old
scientific workers. Native failures stop dependents and remain versioned.
Before/index/after gates preserve33329 oldtracked blobs before local commit.

Meaningful success: a complete selected finite J-h relative kernel with its
source normalization sign, still within a provisional extension. Nonzero or
underdefined remainder is preserved, not assigned a favorable finite baseline.
Failure of convergence/domain leaves a candidate only. No new physical scheme,
absolute finite VEV normalization, tadpole condition, mass fit or quantum
vacuum-restoration theorem. Full chiral source/products/QAP/measure/phase,
background/hats/massiveC1, E5/A5 and physical GUT remain unqualified.
Both adverse scalar points, quartetFAIL, flavorpause,HB1/C5blocks,state/custody
and all free normalizations persist. No agents,branch/worktree,push,outreach
or publication. Shared action, old coefficients, domain, software and AI
authorship limit the new result to bounded internal analytic corroboration.
