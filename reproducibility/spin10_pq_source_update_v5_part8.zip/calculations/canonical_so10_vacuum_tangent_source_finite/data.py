"""VTF1 immutable IO and exact scalar-kernel representation."""
from pathlib import Path
from hashlib import sha256
import json,gzip,os,sys,time,threading
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
VTS=CAL/'canonical_so10_vacuum_tangent_source_kernel'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dec(m):return s.SparseMatrix(*m['shape'],{(i,j):s.sympify(z) for i,j,z in m['entries']})
def enc(m):return {'shape':list(m.shape),'entries':[[int(i),int(j),str(s.simplify(z))] for (i,j),z in sorted(m.todok().items()) if z]}
def begin(role):
 tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
 assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and p.name.startswith(peer):raise PermissionError('VTF1_PEER_DENIED')
 sys.addaudithook(audit);return tick
def finish(role,out,tick):
 out.update({'elapsed_after_imports':time.perf_counter()-tick,'physical_scheme_adopted':False,
 'external_source_extension':'PROVISIONAL_EXPLICIT_NOT_ADOPTED','finite_baseline_selected':False,
 'scientific_acceptance':'NOT_PERFORMED','authority':'34/39',
 'full_vacuum_massive_Slavnov_QAP_measure_phase_or_E5A5_qualified':False})
 raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
