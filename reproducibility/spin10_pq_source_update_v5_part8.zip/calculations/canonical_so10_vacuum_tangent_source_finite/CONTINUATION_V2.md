# VTF1 prelaunch receipt-name correction

Original preparation failed native1 before source freezing or any scientific
worker launch: it requested gauge_yukawa_vertex_poles/validation_receipt.json,
but the qualified inherited result has validation_receipt_v2.json. Its exact
original source, preparation capture and controller failure are preserved.
No scientific output or validation receipt was produced by that attempt.

V2 binds the actual V2 receipt, including its existing orientation supplement.
It reuses the already written old-Git-tree control and preserves the failed
preparation instead of overwriting it. All eight original source bytes and the
three continuation sources are copied and bound before computation. The new
preparation.json is explicitly V2; the original never reached that writer.
No calculation source, scientific coefficient, method, sign, domain,
acceptance requirement or resource bound changes. The new controller records
its preparation separately and stops dependent work on any scientific failure.
