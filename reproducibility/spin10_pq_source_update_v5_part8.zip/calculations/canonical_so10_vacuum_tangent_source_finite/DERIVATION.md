# VTF1: actual two-edge finite map and the source normalization sign

VTS derives the scalar-source vertex -g J R C x and the Euclidean tangent
vertex +g xi h a T x. Ordered Wick permutations and the second cumulant give
the complete residue +g²xi J^T K h, K=CsI-CsH. Both internal edges receive the
same flat positive heat exp(-2tq²). No fermion or numerical Lorentz trace
occurs in this loop. Hence its critical numerator has zero first D jet; the
D-dependent integration measure must nevertheless be retained.

For a positive auxiliary m², normalize the radial integral in16pi² units:

    I_h(t,m²)=integral_0^infinity ds s exp(-4ts)/(s+m²)^2
             =(1+z) exp(z) E1(z)-1, z=4tm².

The finite coefficient after adding the inherited n_log is
-gamma_E-log4-log(m²)-1+n_log. The dimensional bubble is
(4pi)^epsilon Gamma(epsilon)(m²)^(-epsilon); its finite part is
-gamma_E+log(4pi)-log(m²). Their difference is therefore

    chi4 = 1+log(16pi)-n_log.

This auxiliary positive mass is not a selected physical scalar/ghost mass.
Replacing it by the actual reference lower-order masses changes the critical
integrand by order-minus-six terms. At fixed admissible IR completion that
remainder is absolutely integrable; the difference of heat factors tends to
zero and is bounded. Dominated convergence removes it from the RELATIVE local
coefficient. It does not authorize removing an IR delta or taking an unproved
physical zero-mass/constant-vacuum limit.

Independently at p²>0, dimensional Feynman parameters give finite
2-gamma_E+log(4pi)-log(p²). The actual two-edge heat proper times obey
a,b>=2t. With u=a+b and x=a/u, the lower u bound is2t/min(x,1-x), so

    I_h=2 integral_0^(1/2) dx E1(2tp²(1-x)).

Its finite part is1-gamma_E-log4-log(p²)+n_log. Thus the same difference
chi4 follows from the nonexceptional bubble, before substituting any color
kernel. The divergent radial factors and finite constants differ between
these two IR completions, while their relative local coefficient agrees.
No odd shifted numerator, power prefactor or dimension-dependent tensor has
been dropped: this particular parent simply has none.

Therefore the selected comparison is

    C_rel[J,h] = g²xi/(16pi²) * chi4 * J^T K h.

It is not zero merely because its additional fixed tensor direction is zero.
No value of chi4,mu,kappa,b0 or a physical finite normalization is selected.
Heatlength6 would incorrectly add log(3/2)K. This is a sensitive finite check
that the old ultraviolet residue cannot distinguish.

For matching the heat functional to the dimensional comparator, ADD C_rel.
Since the shifted tree density is -J*h, writing this relative addition as
-J*(deltaZhat_match/2)*h gives

    deltaZhat_match/2 = -g²xi*chi4*K/(16pi²).

This sign is opposite to the separately quoted positive POLE deltaZhat/2
because the pole counterterm subtracts +K/epsilon, whereas this matching map
adds Gamma_dim,FP-Gamma_heat,FP. Do not confuse the two conventions.

Actual authenticated YCT maps and VEV give B10*K*v=0 and
B126*K*v=(25/2)vec(M126). Thus the selected mass image of C_rel has positive
(25/2)chi4 and the relative half-background normalization has its negative.
The full K is not the full Spin10 Casimir; that wrong substitution is invisible
only on this particular VEV because the H Casimir annihilates it. Neither this
projection nor the source kernel alone proves the complete massive fermion
identity, finite stationarity or the full z/h-dependent regulated construction.

Primary reference context: Sperling,Stockinger,Voigt,
https://arxiv.org/abs/1305.1548v3 explains the separate background/VEV source
factor. Its beta functions do not supply this model's finite coefficient.
The actual VTS vertices, heat family and frozen common finite part do that.
