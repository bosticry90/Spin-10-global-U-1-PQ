"""VTF1 separate unit/kernel/source-sign and late actual mass-image checks."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
def zero(m):assert not s.SparseMatrix(m).applyfunc(s.simplify).todok()
for k in ['relative_scalar_unit','finite_kernel_chi4','finite_kernel_fixed','relative_log_heat6_minus_heat4','proper_time_edges','heat_length','numerator_dimension_jet','relative_action_addition_sign','relative_half_background_normalization_sign']:assert P[k]==R[k],k
assert P['method']!=R['method']
K=dec(P['finite_kernel_chi4']);zero(K-K.T);zero(K-K.conjugate());zero(dec(P['finite_kernel_fixed']))
assert digest(VTS/'validation_receipt.json')=='06e4061964a1c004607368e890dad39958f5bd19d3bdb3a1b7138b78fb39712c'
old=read(VTS/'validation_receipt.json');assert old['kernel_nonzero_positions']==1342 and old['kernel_rank']==326
bsf=packed(CAL/'canonical_so10_bosonic_source_onejet_finite/primary_v2_tables.json.gz')
zero(s.Matrix([[s.expand(s.sympify(P['relative_scalar_unit'])-s.sympify(bsf['chi_definition']))]]))
# The distinct full/H Casimir and actual vacuum are inherited action inputs.
gy=packed(CAL/'canonical_so10_gauge_yukawa_vertex_poles/primary_tables.json.gz');CI,CH=map(dec,gy['scalar_Casimir_I_H']);zero(K-CI+CH)
PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
v=dec(read(PK/'frozen_a10_physical_reconciliation/full_primary.json')['vacuum']['VEV'])
yc=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');images=[]
for key,mkey in [('B10','mass10'),('B126','mass126')]:
 image=dec(yc[key])*K*v;unit=s.Rational(25,2) if key=='B126' else 0
 zero(image-unit*s.Matrix(256,1,list(dec(yc[mkey]))))
 images.append({'carrier':key,'Crel_chi4_unit':str(unit),'half_background_matching_chi4_unit':str(-unit),'nonzero_positions':len(s.SparseMatrix(image).applyfunc(s.simplify).todok())})
zero(CH*v);wrong_full=s.SparseMatrix(K-CI).applyfunc(s.simplify)
assert wrong_full.todok()
J,h,a=s.symbols('J h a');assert s.diff(-J*(1+a)*h,a)==-J*h
controls={name:len(s.SparseMatrix(M).applyfunc(s.simplify).todok()) for name,M in {'wrong_Wick_sign':-2*K,'extra_half':-K/2,'extra_family3':2*K,'wrong_heat6':s.log(s.Rational(3,2))*K,'full_Casimir':K-CI}.items()}
assert all(n>0 for n in controls.values())
recipe={'schema':'VTF1_FULL_VACUUM_TANGENT_RELATIVE_FINITE_KERNEL','definition':'Gamma_dim_FP-Gamma_heat_FP',
 'source_order':'J_left_h_right','overall_factor':'g10^2*xi/(16*pi^2)',
 'chi4':'1+log(16*pi)-n_log','kernel_chi4':enc(K),'kernel_fixed':enc(s.SparseMatrix(328,328,{})),
 'relative_action_addition_sign':1,'relative_half_background_normalization_sign':-1,
 'actual_mass_images':images,'external_source_extension':'PROVISIONAL_EXPLICIT_NOT_ADOPTED',
 'physical_scheme_adopted':False,'finite_baseline_selected':False,
 'full_vacuum_massive_Slavnov_QAP_measure_phase_or_E5A5_qualified':False,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(recipe,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_vacuum_source_relative_member.json.gz').open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'status':'QUALIFIED_FULL_SELECTED_VACUUM_TANGENT_SOURCE_FINITE_COMPARISON',
 'full_kernel_positions_compared':328**2,'kernel_nonzero_chi4_positions':len(K.todok()),'kernel_fixed_nonzero_positions':0,
 'common_chi4_matches_existing_bosonic_finite_part':True,'finite_heatlength_control':P['relative_log_heat6_minus_heat4'],
 'actual_mass_images':images,'controls_changed_kernel_positions':controls,
 'wrong_full_Casimir_invisible_on_frozen_VEV':True,
 'relative_action_addition_sign':1,'relative_half_background_normalization_sign':-1,
 'artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest(),
 'external_source_extension':'PROVISIONAL_EXPLICIT_NOT_ADOPTED','physical_scheme_adopted':False,'finite_baseline_selected':False,
 'full_vacuum_massive_Slavnov_QAP_measure_phase_or_E5A5_qualified':False,
 'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','elapsed_after_imports':time.perf_counter()-tick},sort_keys=True),flush=True)
