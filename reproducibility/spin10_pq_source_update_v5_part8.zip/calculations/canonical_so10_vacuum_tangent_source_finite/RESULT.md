# The finite vacuum-source comparison is determined in the provisional extension

The complete selected local Jx-h comparison is

    Gamma_dim,FP - Gamma_heat,FP
      = g10²*xi/(16*pi²) * chi4 * J^T K h,
    K=Cs,I-Cs,H,  chi4=1+log(16*pi)-n_log.

The coefficient uses the actual previously qualified VTS scalar/ghost source
kernel and the same finite-part convention as the other bosonic source
calculations. It is a relative comparison, not an adopted finite physical VEV
normalization. The z/h source extension remains explicitly provisional.

Receipt [validation_receipt.json](validation_receipt.json), SHA256
`e43efef77d9dc790d798da94a28a0ea9acfff6bad669e372a2ee9721d268a8ac`, records
QUALIFIED_FULL_SELECTED_VACUUM_TANGENT_SOURCE_FINITE_COMPARISON.
Scientific/director acceptance NOT_PERFORMED; state113/authority34of39 unchanged.

The full328²=107,584 kernel positions agree, including zeros. The chi4 direction
has1,342 nonzero entries; the additional fixed tensor is zero. That does not
make the finite comparison zero or select chi4=0. Kernel rank326 and the full
H-covariance result are authenticated VTS reuse, not newly repeated calculations.
The structured member is
[selected_vacuum_source_relative_member.json.gz](selected_vacuum_source_relative_member.json.gz),
packed SHA256
`aa4846623625bbcee76ac667db50584ab1005897e2d3f5e5f3aa727924207720`, raw SHA256
`ada6ed69768ba456a3a04af8ca089ddff761d99d983a80975664681d20bc17d5`.

## Actual finite integrals and normalization

The primary obtains the dimensionally continued Gamma integral and the direct
positive-mass heat radial integral. Replay obtains the nonexceptional Feynman/
Beta integral and an ordered two-edge Schwinger integral. They use different
infrared completions and obtain the same relative local coefficient before
reading the model kernel. Three finite-cutoff integrations per route check
their closed integral formulas to an absolute tolerance of1e-60 at70-digit
working precision. This is an integral-formula control, not a claimed physical
prediction at that precision. The result itself is exact symbolic algebra.

The two scalar/ghost propagators have heatlength4. Their critical numerator
has no numeric vector or spin trace; its first dimension jet is zero. The
dimension-dependent measure and finite radial constants remain essential.
Changing the heatlength to6 introduces the erroneous local term log(3/2)K
while preserving the ultraviolet pole. Wrong source/Wick sign, an extra half,
family3, wrong heatlength and the full-Casimir substitution each change1,342
actual kernel positions. No new color contraction or old141-second VTS primary
was repeated; its independently derived paired coefficients were reused.

In the fixed-reference source construction, the relative action addition has
positive sign. Writing it with the shifted tree convention -J*h as
-J*(deltaZhat_match/2)*h gives the NEGATIVE matching coefficient

    deltaZhat_match/2 = -g10²*xi*chi4*K/(16*pi²).

This does not reverse the older ultraviolet result. The ultraviolet
counterterm subtracts the positive pole, whereas this matching addition is
Gamma_dim,FP-Gamma_heat,FP. These are different operations.

The actual algebraic reference-vector projection gives

    B10*K*v=0,  B126*K*v=(25/2)*vec(M126).

Thus C_rel has +(25/2)chi4 in the126 mass image, and the relative half-background
matching parameter has its negative. General Y126 remains symbolic; no family3,
extra Nambu half or neutrino spectrum is selected. This is a coefficient
projection using the existing reference vector, not a physical constant-h or
constant-vacuum infrared limit. The wrong full Spin10 Casimir gives the same
selected projection because the H Casimir annihilates v; that deliberate
insensitivity remains explicit. Only the full kernel distinguishes them.

## Execution and what remains

Initial preparation failed native1 before scientific freezing/launch because
one inherited receipt is named validation_receipt_v2.json rather than
validation_receipt.json. The exact source, full capture and controller failure
are preserved. V2 binds the actual receipt and its orientation supplement;
it changes no calculation source or acceptance requirement. All eleven
original/continuation source copies precede the scientific workers. The
original never wrote preparation.json; the successful manifest is explicitly
V2. See [CONTINUATION_V2.md](CONTINUATION_V2.md).

Primary/replay/gate native0 in1.161986/1.157343/9.660605s after imports. Their
2/2/6 samples have maximum private bytes54,079,488 /54,550,528 /63,541,248;
these are sparse sampled observations, not peaks. Same600s/8GiBsampled/
350MiBlaunch/16MiBpacket bounds held.78/86 preparation/validation bindings,
11 source copies, pre-report124,907B. JMF's fresh delegated E4 is authenticated
reuse: actual0/0/0/0/0/2 exits, historical custody2/seven NOTPASS.

This supplies one missing finite source input beyond the marginal family.
It does not show that every massive/vacuum identity cancels. The next useful
question is the actual dimension-one fermion mass comparison, including both
kinetic Bx and auxiliary Lambda-x reference insertions, together with this
source correction. Recover the exact reference/heat placement first: treating
a reference mass as an extra heat-damped interaction can alter a finite term
while preserving its pole. Keep Gamma_ref and any reference/heat variations;
do not assume the old pole cancellation proves a finite cancellation.

Finite tadpoles/stationarity, absolute VEV normalization, the complete z/h
source/product construction, full chiral QAP/measure/phase, backgrounds/hats,
physical massiveC1, E5/A5 and physical unification remain unqualified. Both
adverse scalar configurations, quartetFAIL, flavorpause,HB1/C5blocks, all
normalization freedoms and authority/custody are unchanged. No canonical
physical action or project_state was mutated; nothing was pushed or published.

Track B demonstrates two independent finite-integral routes and faithful reuse
of a qualified full model kernel. The prelaunch filename assumption is a real
orchestration error. Shared action, old kernel, regulator/domain assumptions,
software and AI authorship remain common-error limits, not external scientific
confirmation. The established background/VEV distinction is discussed by
[Sperling, Stockinger and Voigt](https://arxiv.org/abs/1305.1548v3); their work
does not supply or independently validate this project's finite coefficient.
