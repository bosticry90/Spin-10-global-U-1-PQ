from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from fractions import Fraction
import gzip,json,os,sys,threading,time
from cubic_core import *
R=O.parents[1];role=sys.argv[1];assert role in ['primary','replay']
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes())
for pp,h in read(O/'whole_preparation.json')['input_sha256'].items():assert sha256(Path(pp).read_bytes()).hexdigest()==h,pp
peer='replay' if role=='primary' else 'primary'
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        pp=Path(os.fsdecode(args[0]))
        if pp.parent.resolve()==O and (pp.name.startswith('kernel_'+peer) or pp.name.startswith('kernel_review')):raise PermissionError('UMC_QUANTUM_PEER_DENIED')
        if pp.parent.name in ['canonical_so10_u_lower_cutoff_contraction','canonical_so10_u_pair_contact_model'] or pp.parent.name=='canonical_so10_unprobed_log3_support' and pp.name in ['partial_after_known.json.gz','transport_review_result.json']:raise PermissionError('UMC_OLD_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard);denials=0
for pp in [O/('kernel_'+peer+'_tables.json.gz'),R/'calculations/canonical_so10_unprobed_log3_support/partial_after_known.json.gz',R/'calculations/canonical_so10_u_lower_cutoff_contraction/late_remainders.json.gz']:
    try:pp.read_bytes()
    except PermissionError:denials+=1
assert denials==3
method=read(O/'method_result.json');assert method['raw_classical_tables_equal'] and method['every_colored_path_within_qualified_ULS_support']
z,T=get(role);del z
families=['CC','aC_boson','aC_ghost','aC_scalar','JLC','JLa']
groups={case:{fam:{} for fam in families} for case in ['JLaCC','JLJLCC']};work=Counter();pair_count=0
if role=='primary':
    for case,fam,i,j,k,w,a,b,word,sg,v,x,y in paths(T):
        sig=[(-1)**int(i>=NB)*sg,(-1)**int(j>=NB)*merge((a,b)+w)[1],(-1)**int(k>=NB)*merge((b,)+w+(a,))[1]]
        assert len(set(sig))==1
        name,key,owner=owning_key(word);assert name==case
        put(groups[case][fam],key,(v*x*y)*constant(Fraction(owner*sum(sig),6)))
        work[case,fam]+=1
    expected=next(v for v in method['actual_path_cost'] if v['role']==role)
    assert [[list(k),v] for k,v in sorted(work.items())]==expected['by_case_family']
else:
    V1,V2,from1,edges=components(T);needed={(j,i) for i,j,w in V2};row1=defaultdict(list);Q={}
    for (i,j,w),v in V1.items():row1[i].append((j,w[0],v))
    for (j,k,w),x in V1.items():
        a=w[0]
        for i,b,y in row1[k]:
            if (j,i) not in needed:continue
            pair,sg=merge((a,b))
            if not sg or not complementary_types(pair):continue
            put(Q,(j,i,pair),(x*y)*sg);pair_count+=1
    Q=clean(Q);qby=defaultdict(list)
    for (j,i,pair),v in Q.items():qby[j,i].append((pair,v))
    for (i,j,w),v in V2.items():
        fam=family(i,j,w)
        for pair,x in qby[j,i]:
            word,sg=merge(w+pair)
            if not sg:continue
            case=target(word)
            if case is None:continue
            name,key,owner=owning_key(word);assert name==case
            put(groups[case][fam],key,(v*x)*constant(Fraction(owner*sg*((-1)**int(i>=NB)),2)))
        
groups={case:{fam:clean(M) for fam,M in rows.items()} for case,rows in groups.items()};results=[]
for case in ['JLaCC','JLJLCC']:
    total={}
    for M in groups[case].values():
        for key,v in M.items():put(total,key,v)
    total=clean(total);domain=45*45*990 if case=='JLaCC' else 990*990
    for r,s,h,k in total:
        assert 0<=r<45 and 0<=s<45 and 0<=h<k<45
        if case=='JLJLCC':assert r<s
    results.append({'case':case,'domain_positions':domain,'groups':{fam:encode(M) for fam,M in groups[case].items()},
       'group_nonzero_counts':{fam:len(M) for fam,M in groups[case].items()},'total':encode(total),
       'total_nonzero':len(total),'zero_complement':domain-len(total)})
out={'schema':'UMC3_COMPLETE_UNPROBED_MARGINAL_C3_KERNELS','role':role,'results':results,
 'primary_closed_path_counts':[[list(k),v] for k,v in sorted(work.items())],
 'replay_precontracted_path_products':pair_count,'guard_denials':denials,
 'density_orders':['JL_r a_s C_h C_k; h<k','JL_r JL_s C_h C_k; r<s,h<k'],
 'common_normalization':'hbar/(16pi^2); no extra half','full_Ward_QAP_or_physical_claim':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/('kernel_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),
 'counts':[{k:v for k,v in row.items() if k not in ['groups','total']} for row in results],
 'guard_denials':denials,'full_restoration_claim':False},sort_keys=True),flush=True);timer.cancel()
