from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-marginal-c3-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
    with p.open('xb') as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    C.mkdir(exist_ok=False)
    head=subprocess.run(['git','rev-parse','HEAD'],stdout=subprocess.PIPE,check=True).stdout.decode().strip();assert head=='12dcad42cf5d6846485be60434fcbb74003ffdcc'
    with (C/'old_git_tree.txt').open('xb') as f:f.write(subprocess.run(['git','ls-tree','-r','--full-tree','HEAD'],stdout=subprocess.PIPE,check=True).stdout)
    rels=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V654.md',
      'calculations/canonical_so10_unprobed_log3_support/final_review_validation_receipt.json',
      'calculations/canonical_so10_u_F_fourth_support/operators.py','calculations/canonical_so10_u_T_cutoff_tensor/actual.py',
      'calculations/canonical_so10_u_T_cutoff_tensor/algebra.py','calculations/canonical_so10_full_jet_source_master_bridge/jets.py',
      'calculations/canonical_so10_intrinsic_full_source_descent/coefficient_ring.py',
      'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']
    for role in ['primary','replay']:
        rels+=['calculations/canonical_so10_u_maximal_heat_cutoff/'+role+'_inputs.json.gz',
               'calculations/canonical_so10_unprobed_log3_support/support_v2_'+role+'_tables.json.gz']
    for name in ['.gitattributes','RECORD.md','blocks.py','operators.py','run_operators.py']:
        pp=O/name
        if pp.suffix=='.py':ast.parse(pp.read_bytes())
        with (O/(name+'.source.txt')).open('xb') as f:f.write(pp.read_bytes())
    files=[R/v for v in rels]+list(O.iterdir());bindings={str(p):H(p) for p in files if p.is_file()}
    prep={'schema':'UMC1_PREPARATION','base_HEAD':head,'input_sha256':bindings,'previous_goal_turn':'PROGRESS; complete Ja-a-C kernel and declared T log3 relation',
      'native_seconds_after_imports':300,'review_seconds_after_imports':180,'private_sample_bytes':8*1024**3,'launch_available_pagefile_floor':350*1024**2,
      'packet_byte_limit':32*1024**2,'scientific_acceptance':'NOT_PERFORMED'}
    dump(O/'preparation.json',prep);dump(C/'start.json',prep)
    for role in ['primary','replay']:
        z=capture([sys.executable,'-B',str(O/'operators.py'),role]);dump(O/(role+'_capture.json'),z);dump(C/(role+'_full_capture.json'),z)
        assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified']
        lines=[v for v in z['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(lines)==1
        data,elapsed=lines[0][7:].rsplit(' ELAPSED ',1);result=json.loads(data);result['elapsed_after_imports']=float(elapsed);assert result['elapsed_after_imports']<300
        dump(O/(role+'_result.json'),result);print('COMPLETED UMC1 '+role+' '+str(result['reduced_entries']),flush=True)
except BaseException:
    dump(O/'operators_controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
