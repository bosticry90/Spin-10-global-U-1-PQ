from pathlib import Path
from hashlib import sha256
import ast,gzip,json,os,subprocess,threading,time
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-marginal-c3-v1-2026-10-26')
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
bindings={};preps=[]
for prep in sorted(O.glob('*preparation*.json')):
    preps.append(prep.name)
    for pp,h in read(prep)['input_sha256'].items():
        assert H(Path(pp))==h,(prep.name,pp)
        if pp in bindings:assert bindings[pp]==h
        bindings[pp]=h
copies=list(O.glob('*.source.txt'))
for pp in copies:assert pp.read_bytes()==pp.with_name(pp.name[:-11]).read_bytes(),pp
for pp in O.glob('*.py'):ast.parse(pp.read_bytes())
complete=[];largest=0
for pp in sorted(O.glob('*_capture.json')):
    z=read(pp)
    assert z['execution_state']=='COMPLETED' and z['exit_code']==0 and z['calculation_completed'] and z['post_run_observations_qualified'],pp
    assert not z['failed_or_incomplete_counted_as_PASS'] and z['launch']['creation_after_observation']
    assert z['launch']['memory']['available_pagefile']>=350*1024**2
    assert z['all_resource_samples'] and all(0<v['private_bytes']<=8*1024**3 and 'query_error' not in v for v in z['all_resource_samples'])
    largest=max(largest,max(v['private_bytes'] for v in z['all_resource_samples']));complete.append(pp.name)
assert not list(O.glob('*controller_failure*.json'))
for name in ['primary_result','replay_result','kernel_primary_result','kernel_replay_result','transport_primary_result','transport_replay_result']:
    assert read(O/(name+'.json'))['elapsed_after_imports']<300
for name in ['method_result','kernel_review_result','transport_review_result']:
    assert read(O/(name+'.json'))['elapsed_after_imports']<180
whole=read(O/'whole_execution_result.json');assert whole['aggregate_after_imports_seconds']<=whole['aggregate_budget_seconds']==600
m=read(O/'method_result.json');k=read(O/'kernel_review_result.json');t=read(O/'transport_review_result.json')
assert m['raw_classical_tables_equal'] and m['every_colored_path_within_qualified_ULS_support'] and all(m['sensitive_controls'].values())
assert k['full_tensor_groups_and_zero_complements_equal'] and len(k['fresh_uncut_checks'])==20
assert t['complete_images_and_zero_complements_equal'] and t['all_five_UOR_F_log3_input_types_accounted_for']
assert all(z['complete_declared_sum_zero'] and z['complete_declared_sum_nonzero']==0 for z in t['late_complete_declared_F_log3_comparisons'])
assert next(z for z in t['late_complete_declared_F_log3_comparisons'] if z['probe']==1)['wrong_odd_source_prefix_sum_nonzero']>0
assert not t['full_Ward_QAP_or_scientific_promotion']
P=R/'calculations/canonical_so10_unprobed_log3_support';old=read(P/'final_review_validation_receipt.json')
oldT=P/'T_log3_complete_comparison_v2.json.gz';rel=str(oldT.relative_to(R)).replace('\\','/')
assert H(oldT)==old['new_files_sha256'][rel]
tc=json.loads(gzip.decompress(oldT.read_bytes()));assert all(z['complete_declared_T_log3_sum_zero'] for z in tc['results']) and all(not z['sum'] for z in tc['tensors'])
events=read(O/'e4_events.json');steps=[z for z in events if z['event']=='step_finished']
assert [z['exit_code'] for z in steps]==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested']
assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout'] and read(O/'e4_capture.json')['elapsed_seconds']<300
git=lambda *args:subprocess.run(['git',*args],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()=='12dcad42cf5d6846485be60434fcbb74003ffdcc'
assert git('branch','--show-current').decode().strip()=='main'
assert git('ls-tree','-r','--full-tree','HEAD')==(C/'old_git_tree.txt').read_bytes()
git('diff','--quiet','HEAD','--')
state=H(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
size=sum(p.stat().st_size for p in O.rglob('*') if p.is_file());assert size<32*1024**2
out={'schema':'UMC5_FINAL_BOUNDED_EVIDENCE_REVIEW','preparation_bindings_authenticated':len(bindings),'preparations':preps,'source_copies_equal':len(copies),
 'completed_captures_authenticated':complete,'largest_successful_sampled_private_bytes':largest,'packet_bytes_before_final_capture_and_seal':size,
 'bounded_evidence_validation':'PASS_WITHIN_FROZEN_SCOPE','complete_declared_F_log3':'ZERO_BOTH_PROBES','prior_complete_T_log3':'AUTHENTICATED_ZERO_BOTH_PROBES',
 'full_Ward_QAP_or_E5_claim':False,'E4_step_exits':[z['exit_code'] for z in steps],'custody':'EXIT2_SEVEN_UNRESOLVED_NOTPASS',
 'old_tracked_tree_and_state_unchanged':True,'state_sha256':state,'scientific_acceptance':'NOT_PERFORMED','elapsed_after_imports':time.perf_counter()-tick}
with (O/'final_review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
