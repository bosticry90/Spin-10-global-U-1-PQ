# UMC2: complete graded trace reduction and actual cost/support, prospective

Both UMC1 action-operator routes have completed. Compare all full raw
Lorentz/momentum tables, shapes and zero complements before using the
opposite-axis reduced blocks. Verify the complete ULS support premise
and keep scalar blocks until a closed-path exclusion applies.

Prove1/6 STr(A2 A1 A1+A1 A2 A1+A1 A1 A2)=1/2 STr(A2 A1 A1)
for the homogeneous target by literal exterior-matrix multiplication.
All JL/a/C external variables are odd; quantum block parity must match
external degree. Three fixed noncommuting finite graded fixtures include
both quantum ghost orientations and all odd-pair sectors. Track ordinary-
trace,commuting-exterior and pair-sector omission controls with their
actual sensitivity. Gaussian half-STrlog normalization is inherited,
not supplied by this cyclic test or by the desired model remainder.

Before freezing whole tensor jobs,count actual closed color paths for
both native input routes. Retain full target types and all V2 families:
CC (GF two-antighost Hessian),aC ghost,aC boson metric,JLC,and JLa
(source two-ghost Hessian). Every retained colored triple must map to
the already complete ULS126-word TYPE support. Count equality is not
coefficient equality; do not calculate a quantum value from support.
No scalar/fermion/potential complete cycle is allowed unless retained
and investigated. This is method qualification and cost evidence only.

Review180s,8GiB sampled,350MiB launchfloor,32MiB packet; freeze sources
and input bytes first. Whole coefficient resources are a later freeze.
No old remainder is read. State/authority/domain boundaries unchanged.
