from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import defaultdict
import ast,gzip,json,os,sys,threading,time
from blocks import *
O=Path(__file__).resolve().parent;R=O.parents[1]
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()))
for pp,h in read(O/'kernel_review_preparation.json')['input_sha256'].items():assert sha256(Path(pp).read_bytes()).hexdigest()==h,pp
def unpack(rows):
    out={tuple(z[:-1]):coeff(z[-1]) for z in rows};assert len(out)==len(rows) and all(out.values());return out
ab=[]
for role in ['primary','replay']:
    pp=O/('kernel_'+role+'_tables.json.gz');assert sha256(pp.read_bytes()).hexdigest()==read(O/('kernel_'+role+'_result.json'))['packed_sha256'];ab.append(loadz(pp))
assert ab[0]['results']==ab[1]['results'];kernels={};counts=[]
for z in ab[0]['results']:
    M=unpack(z['total']);total={}
    for fam,rows in z['groups'].items():
        F=unpack(rows);assert len(F)==z['group_nonzero_counts'][fam]
        for k,v in F.items():put(total,k,v)
    assert clean(total)==M and len(M)==z['total_nonzero'] and len(M)+z['zero_complement']==z['domain_positions']
    kernels[z['case']]=M;counts.append({k:v for k,v in z.items() if k not in ['groups','total']})
assert not kernels['JLJLCC']
assert all(z['guard_denials']==3 for z in ab)
assert read(O/'whole_execution_result.json')['aggregate_after_imports_seconds']<=600

d=load('primary');gradient={i:decode(v) for i,v in d['GF_gradient']};density=gf_primitive(gradient)
base=ast.parse((R/'calculations/canonical_so10_u_F_fourth_support/operators.py').read_bytes())
nodes=[n for n in base.body if isinstance(n,ast.FunctionDef) and n.name in ['hessian','source_density']]
keys=sorted(kernels['JLaCC'])
contexts=[('JLaCC',keys[min(len(keys)-1,j*len(keys)//4)]) for j in range(4)] if keys else [('JLaCC',(13,13,12,14)),('JLaCC',(20,24,5,13))]
contexts += [('JLaCC',(0,0,0,1)),('JLaCC',(12,12,12,13)),('JLJLCC',(0,1,12,13)),('JLJLCC',(12,13,0,1)),('JLJLCC',(13,14,13,14)),('JLJLCC',(20,44,21,43))]

def literal(raw,axis,q,selected,omit=None):
    V={}
    for (i,j,w,nd,p),v in raw.items():
        if any(n for mu,n in enumerate(p) if mu!=axis):continue
        typ=[external_type(k) for k in w]
        if omit=='source_CC' and sorted(typ)==['JL','a'] and 553<=i<598 and 553<=j<598:continue
        if omit=='GF_aa' and typ==['C','C'] and i>=598 and j>=598:continue
        if omit=='GF_BB' and sorted(typ)==['C','a'] and i<180 and j<180:continue
        bits=[selected[k] for k in w];mask=sum(bits);sg=(-1)**sum(a>b for at,a in enumerate(bits) for b in bits[at+1:]);v=v*(sg*q**sum(p))
        if i<180:
            color,mu=divmod(i,4);fold=[(i,co('eta_H' if color<12 else 'xi') if mu==axis else constant(1))]
            if mu==axis:fold.append((508+color,constant(q)))
        elif i<508:fold=[(i,constant(1))]
        elif i<553:fold=[(4*(i-508)+axis,constant(-q))]
        elif i<598:fold=[(i+45,constant(-1))]
        else:fold=[(i-45,constant(1))]
        for r,f in fold:put(V,(r,j,mask),v*f)
    V=clean(V);by=defaultdict(list)
    for (i,j,m),v in V.items():by[i].append((j,m,v))
    power={(i,i,0):constant(1) for i in range(643)}
    for n in range(3):
        out={}
        for (i,k,m),v in power.items():
            for j,m2,w in by[k]:
                if m&m2:continue
                sg=(-1)**sum(((m>>a)&1)*(m2&((1<<a)-1)).bit_count() for a in range(4))
                put(out,(i,j,m|m2),(v*w)*sg)
        power=clean(out)
    value=ZERO
    for (i,j,m),v in power.items():
        if i==j and m==15:value=value+v*((-1)**int(i>=553))
    return value*constant(Fraction(1,6))

fresh=[];controls=[]
for at,(case,key) in enumerate(contexts):
    r,s,h,k=key
    selected=({1151+r:1,598+s:2,553+h:4,553+k:8} if case=='JLaCC' else {1151+r:1,1151+s:2,553+h:4,553+k:8})
    assert len(selected)==4
    def allow(word,nd,low,high):
        if nd!=0 or not low<=len(word)<=high or any(js or i not in selected for i,js in word):return None
        ids=tuple(i for i,js in word)
        return ids if len(ids)==len(set(ids)) else None
    ns=dict(vars(OP));ns['allowed']=allow
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'UMC4_ORIGINAL_FULL_DENSITY_SELECTED_HESSIAN','exec'),ns)
    raw=ns['hessian'](density,'primary',1,2)
    for kk,v in ns['hessian'](ns['source_density'](d),'primary',1,2).items():put(raw,kk,v)
    raw=clean(raw)
    for axis,q in [(3,1),(2,-1)]:
        value=literal(raw,axis,q,selected);expected=kernels[case].get(key,ZERO);assert value==expected,(case,key,axis,q,str(value),str(expected))
        fresh.append({'case':case,'indices':list(key),'axis':axis,'q':q,'coefficient':str(value),'literal_full_power_equal':True})
        if at<2 and case=='JLaCC':
            controls.append({'case':case,'indices':list(key),'axis':axis,'q':q,'omission_sensitive':{name:literal(raw,axis,q,selected,name)!=value for name in ['source_CC','GF_aa','GF_BB']}})
        print('STAGE UMC4 fresh uncut '+json.dumps(fresh[-1],sort_keys=True),flush=True)
out={'schema':'UMC4_COMPLETE_KERNEL_REVIEW_AND_FRESH_UNCUT_ACTION','full_tensor_groups_and_zero_complements_equal':True,'counts':counts,
 'fresh_uncut_checks':fresh,'controls':controls,'full_GF_density_all90_columns_verified':True,'old_remainder_or_QAP_claim':False,
 'elapsed_after_imports':time.perf_counter()-tick}
with (O/'kernel_review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({k:v for k,v in out.items() if k not in ['fresh_uncut_checks','controls']},sort_keys=True),flush=True);timer.cancel()
