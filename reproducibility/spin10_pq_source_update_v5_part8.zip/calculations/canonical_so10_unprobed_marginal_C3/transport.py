from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
import gzip,json,os,sys,threading,time
from cubic_core import *
from blocks import co
R=O.parents[1];role=sys.argv[1];assert role in ['primary','replay']
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()))
for pp,h in read(O/'transport_preparation.json')['input_sha256'].items():assert sha256(Path(pp).read_bytes()).hexdigest()==h,pp
peer='replay' if role=='primary' else 'primary'
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        pp=Path(os.fsdecode(args[0]))
        if pp.parent.resolve()==O and (pp.name.startswith('transport_'+peer) or pp.name.startswith('transport_review')):raise PermissionError('UMC_TRANSPORT_PEER_DENIED')
        if pp.parent.name in ['canonical_so10_unprobed_log3_support','canonical_so10_u_lower_cutoff_contraction','canonical_so10_u_pair_contact_model']:raise PermissionError('UMC_TRANSPORT_OLD_TARGET_DENIED')
sys.addaudithook(guard);denials=0
for pp in [O/('transport_'+peer+'_tables.json.gz'),R/'calculations/canonical_so10_unprobed_log3_support/partial_after_known.json.gz',R/'calculations/canonical_so10_u_lower_cutoff_contraction/late_remainders.json.gz']:
    try:pp.read_bytes()
    except PermissionError:denials+=1
assert denials==3
assert read(O/'kernel_review_result.json')['full_tensor_groups_and_zero_complements_equal']
z=loadz(O/('kernel_'+role+'_tables.json.gz'));kernels={v['case']:{tuple(row[:-1]):coeff(row[-1]) for row in v['total']} for v in z['results']}
u=loadz(R/('calculations/canonical_so10_u_operation_root_inventory/root_'+role+'_tables.json.gz'))
d=loadz(R/('calculations/canonical_so10_u_maximal_heat_cutoff/'+role+'_inputs.json.gz'));names=d['field_order']
ids={n:i for i,n in enumerate(names)};ids.update({'J'+n:643+i for i,n in enumerate(names)})
parity=lambda i:int(553<=i<643) if i<643 else 1-int(553<=i-643<643)
def canonical(word):
    odd=[i for i in word if parity(i)]
    if len(odd)!=len(set(odd)):return (),0
    return tuple(sorted(word)),(-1)**sum(a>b for at,a in enumerate(odd) for b in odd[at+1:])
def density(case,key):
    r,s,h,k=key
    return (1151+r,598+s,553+h,553+k) if case=='JLaCC' else (1151+r,1151+s,553+h,553+k)
def key_of(word):
    xs=[i-180 for i in word if 180<=i<508];cc=[i-553 for i in word if 553<=i<598];jl=[i-1151 for i in word if 1151<=i<1196]
    assert len(xs)==len(jl)==1 and len(cc)==2 and len(word)==4 and cc[0]<cc[1]
    return (jl[0],*cc,xs[0])

# Nonzero fixtures distinguish the odd-source prefix sign and both source
# derivatives independently of the actual zero JJ model tensor.
fixtures=[((1151,598,553,554),598,(180,),-1),((1151,1152,553,554),1151,(180,),1),((1151,1152,553,554),1152,(180,),-1)]
for original,out,rem,expected in fixtures:
    at=original.index(out);target0,s0=canonical(original[:at]+rem+original[at+1:]);left=(-1)**sum(parity(i) for i in original[:at])*s0
    w,sg=canonical(original);at=w.index(out);target1,s1=canonical(w[:at]+rem+w[at+1:]);right=sg*((-1)**sum(parity(i) for i in w[:at]))*s1
    assert target0==target1 and left==right==expected

patterns={'JLaCC':('C','C','JL','a'),'JLJLCC':('C','C','JL','JL')};results=[]
for probe,record in enumerate(u['results']):
    groups={};flow_counts={};source_degrees={}
    for case,pattern in patterns.items():
        flows=defaultdict(list)
        for pat,nu,out,rem,value in record['targets']['F']['aggregate_flows']:
            if tuple(pat)!=pattern or nu!=0:continue
            assert out in ids and all(n in ids for n in rem)
            flows[ids[out]].append((tuple(ids[n] for n in rem),co(value)))
        flow_counts[case]=sum(map(len,flows.values()));source_degrees[case]=dict(Counter(row['QG_source_degree'] for row in record['targets']['F']['routes'] if tuple(row['C0_root_type'])==pattern and row['C0_intrinsic_degree']==0))
        image={}
        for key,v in (kernels[case].items() if role=='primary' else reversed(list(kernels[case].items()))):
            original=density(case,key)
            if role=='primary':
                for at,out in enumerate(original):
                    prefix=(-1)**sum(parity(i) for i in original[:at])
                    for rem,f in flows[out]:
                        word,sg=canonical(original[:at]+rem+original[at+1:])
                        if sg:put(image,key_of(word),(v*f)*(prefix*sg))
            else:
                word,sg0=canonical(original)
                for at,out in enumerate(word):
                    prefix=(-1)**sum(parity(i) for i in word[:at])
                    for rem,f in flows[out]:
                        new,sg=canonical(word[:at]+rem+word[at+1:])
                        if sg:put(image,key_of(new),(v*f)*(sg0*prefix*sg))
        groups[case]=clean(image)
    total={}
    for M in groups.values():
        for key,v in M.items():put(total,key,v)
    total=clean(total)
    results.append({'probe':probe,'target':'F','domain_positions':14612400,'groups':{k:encode(v) for k,v in groups.items()},
       'group_nonzero_counts':{k:len(v) for k,v in groups.items()},'total':encode(total),'total_nonzero':len(total),
       'zero_complement':14612400-len(total),'actual_aggregate_flow_counts':flow_counts,'original_QG_source_degree_route_counts':source_degrees})
out={'schema':'UMC4_ACTUAL_U_IMAGE_OF_COMPLETE_MARGINAL_C3_KERNELS','role':role,'results':results,'nonzero_graded_sign_fixtures':len(fixtures),
 'guard_denials':denials,'full_Ward_QAP_or_E5_claim':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/('transport_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),
 'counts':[{k:v for k,v in row.items() if k not in ['groups','total']} for row in results],'guard_denials':denials},sort_keys=True),flush=True);timer.cancel()
