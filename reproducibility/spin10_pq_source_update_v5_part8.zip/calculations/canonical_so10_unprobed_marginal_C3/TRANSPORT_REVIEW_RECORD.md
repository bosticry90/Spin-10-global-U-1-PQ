# UMC4c: complete image validation and late F log3 test, prospective

Both operation routes completed. Authenticate complete groups/sums,
source-degree provenance and all14612400 positions/probe including
zeros before reading the old comparison. Check the full UOR F log3
inventory: current JLJLCC,JLaCC;qualified zero JaJLC/intrinsicJax;
previously measured/transported intrinsicLambda x. No unlisted input
may be assumed zero. The native heat<=4 proof isolates log3 to C3.

Authenticate ULS partial_after_known.json.gz through its final receipt.
It already owns the known Lambda-x image ONCE. Add current new images
ONCE with the original plus sign. Preserve every coefficient regardless
of cancellation outcome. Record the wrong odd-source-prefix control
with its actual sensitivity. A passing scoped coefficient equality
does not prove the full finite Ward/QAP or change scientific authority.

Review180s,private8GiB sampled,350MiB launchfloor,total packet32MiB.
Freeze sources and hashes before run. No target fitting,source-sign
selection,changed physical inputs or finite-baseline normalization.
