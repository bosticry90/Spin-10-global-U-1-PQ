# UMC3: complete two-kernel contraction, prospective

UMC2 completed with exact raw-operator agreement and graded cyclic proof.
Three noncommuting fixtures give equal full/reduced coefficients22,
-509/2,11; ordinary trace,commuting exterior and both odd-pair omission
controls are sensitive in all3. This is finite algebra,not a new QAP.

Complete actual colored path enumeration agrees in both orientations:
807932 paths,all in JL a CC: JLC258656,JLa260976,aC_boson288300.
The other families and JL JL CC have no closed actual color path at
three edges,BEFORE loop coefficient multiplication. Preserve explicit
whole-domain zero tables; this is stronger than merely not printing a
tensor. Generic ULS support had12 JLJLCC candidates; candidate support
is not a model-specific nonzero amplitude. No scalar/fermion path enters.

Freeze TWO sequential complete native jobs,primary/replay300s each after
imports,aggregate600s,private8GiB sampled,launch350MiB,total packet32MiB.
The actual complete807932-path study took15.33/14.56s; the sparse exact
coefficient multiplication and full zero complement are a competent bounded
next step. No partial-tensor success or silent truncation on exhaustion.

Primary computes every closed path with all THREE cyclic placements,
their original starting supertrace and exterior signs,weight1/6.
Replay precontracts all needed tagged A1^2 entries,then contracts A2
against them with weight1/2. Both use their independently differentiated,
opposite-axis/q action tables. Store all V2 families and complete sums.

Canonical densities: JL_r a_s C_h C_k,h<k; JL_r JL_s C_h C_k,r<s,h<k.
Physical sorted words C,C,a,JL differ by a MINUS from the first density;
C,C,JL,JL differ by PLUS from the second. All fields here are odd. No
extra antisymmetric-source or ghost half. Domains2004750 and980100.
Equal odd labels vanish before summation. Confirm actual path counts
match UMC2 but do not use any desired coefficient in native execution.

Native guards deny old/current remainders and peer tensors. After native
agreement verify fresh full-action uncut coefficients,then actual UOR u
source/field operation. Only then compare F log3. No source sign,parameter,
chi4,b0,kappa,IR choice or subtraction scheme fitted. Other carriers and
the complete defect-inclusive quantum applicability remain open.
