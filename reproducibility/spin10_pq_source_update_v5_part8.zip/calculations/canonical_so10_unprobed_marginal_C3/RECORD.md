# UMC1-4: complete remaining unprobed marginal C3 kernels, prospective

Base12dcad42cf5d6846485be60434fcbb74003ffdcc. Fresh preflight clean
main/no matching workers,current AGENTS/highestV654 and actual ULS/UOR
receipts read. Previous goal turn PROGRESS: complete Ja-a-C kernel and
declared T log3 relation. Goal ACTIVE/incomplete;state113/34of39,E5/A5
OPEN,custodyexit2/seven unresolved unchanged. project_state sole authority.

Question: measure the two remaining unprobed C0 three-edge kernels
JL_r a_s C_h C_k (h<k) and JL_r JL_s C_h C_k (r<s,h<k),then transport
their actual QG/u images and test the declared F log3 relation. The old
F partial remainder is not a native operand or value to fit. No parameter,
source sign,finite normalization or scheme may be selected to force zero.

Original unshifted SMA/CSW/EDS,A0,zero intrinsic degree for native C0,
constant probes only in later u operation,intrinsic1 final F,external
jets0 AFTER differentiation,symbolic g10/xi/eta_H,common hbar/(16pi^2),
nonexceptional Euclidean LOCAL RELATIVE DIM-minus-strict-heat UV symbol.
UOR heat bound<=4 and chi4+log(m/2) isolate log3 to m3. Other finite
carriers and full quantum applicability remain separate obligations.

UMC1: recover complete target-compatible original-action Hessians from
the FULL GF density (verify its90 supplied Euler columns),not the
Euler-column-only shortcut that failed with an external antighost.
Include the original full source density before source restriction.
Primary left graded derivatives versus replay literal polarization.
Keep full four-component/internal-jet kernels and implicit zeros.
In particular retain GF H_aa|CC,GF H_BB|aC,and source H_CC|JL*a,
as well as the ordinary current/source ports. No scalar/fermion/potential
term may be omitted without its qualified complete ULS support exclusion.

Verify every raw Lorentz monomial,engineering degree and parity before
longitudinal reduction. Every V1 vector endpoint is a momentum pin or
a mixed B/L propagator;V2_BB is a nondifferential metric connected to
such endpoints. No unpinned vector spectator or free D trace may be
discarded. Keep any additional structure if this proof fails.

UMC2: define V1/V2 by external degree1/2 and A=G0 V. The exact target
coefficient is1/6 STr(A2 A1 A1+A1 A2 A1+A1 A1 A2),equivalently
1/2 STr(A2 A1 A1) for EVEN total graded matrices. Derive cyclic signs
with all external JL/a/C variables odd. Noncommuting exterior-matrix
fixtures compare full tagged powers to the reduced trace and test
ordinary-trace/commuting-exterior and pair-sector omission controls.
The finite half-STrlog Gaussian normalization is inherited explicitly;
no two-source antisymmetric density half is invented. Native density
words use physical sorted fields;convert to stated JL-first orders with
their actual exterior signs. Equal odd labels vanish before summation.

UMC3: freeze the complete contraction plan and resources after actual
path/cost inspection. Primary sums all three cyclic orderings with their
original starting supertrace signs;replay first forms tagged A1^2 and
uses the reduced trace. Opposite underlying action-derivative routes,
all45 source/antighost/ghost labels,complete tensors/zero complements.
Retain each V2 family separately. No native old-target or peer access.
Native construction is NOT a full physical theory or continuum theorem.

UMC4: compare complete coefficients before fresh full-action uncut
checks and actual UOR source0/1/2 transport. Source Euler derivatives
precede restriction. Keep JL odd and derivative-before-source-zero.
Only after agreement may the two independently derived images be added
ONCE to ULS's authenticated partial F log3 tensor. Preserve zero/nonzero
remainders without fitting. Full defect-inclusive Ward/master,common
finite-part/product,measure and renormalization applicability remain
required beyond a scoped coefficient identity.

Initial operator/method workers300s/role,review180s,private8GiB sampled,
launch available-pagefile350MiB,total packet32MiB. Whole-tensor budgets
must be frozen separately BEFORE launch after method verification;
these initial limits do not authorize unlimited component expansion.
Two sequential native roles,no agents/parallel organization. Immutable
inputs/source copies,exclusive outputs,owned PID/creation,complete stdout
and resource samples. Preserve failures/incompleteness;no silent retries
or resource expansion. E4 once without --fresh before eventual local
commit;historical custodyexit2 is NOTPASS. No old evidence/state edit,
promotion,protected activation,foundation/benchmark/scheme adoption,
branch/worktree,remote push,publication or outreach.

Focused result-to-claim assessment in existing RESULT. Shared action,
reference,charts,curated data,Gaussian premises,helpers/software and AI
author limit independence;no external scientist,proof assistant or
empirical validation. chi4,b0,kappa,IR freedoms distinct/unfixed.
