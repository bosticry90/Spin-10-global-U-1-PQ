from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-marginal-c3-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
    with p.open('xb') as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings=dict(read(O/'kernel_review_preparation.json')['input_sha256'])
    for pp,h in bindings.items():assert H(Path(pp))==h,pp
    assert read(O/'kernel_review_result.json')['full_tensor_groups_and_zero_complements_equal']
    P=R/'calculations/canonical_so10_u_operation_root_inventory'
    for role in ['primary','replay']:
        for name in ['root_'+role+'_tables.json.gz','root_'+role+'_result.json']:
            pp=P/name;bindings[str(pp)]=H(pp)
    pp=P/'validation_receipt.json';bindings[str(pp)]=H(pp)
    for name in ['TRANSPORT_RECORD.md','transport.py','run_transport.py']:
        pp=O/name
        if pp.suffix=='.py':ast.parse(pp.read_bytes())
        with (O/(name+'.source.txt')).open('xb') as f:f.write(pp.read_bytes())
    for pp in O.iterdir():
        if pp.is_file():bindings[str(pp)]=H(pp)
    dump(O/'transport_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    for role in ['primary','replay']:
        z=capture([sys.executable,'-B',str(O/'transport.py'),role]);dump(O/('transport_'+role+'_capture.json'),z);dump(C/('transport_'+role+'_full_capture.json'),z)
        assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified']
        result=[json.loads(v[7:]) for v in z['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(result)==1 and result[0]['elapsed_after_imports']<300
        dump(O/('transport_'+role+'_result.json'),result[0]);print('COMPLETED UMC4 transport '+role,flush=True)
except BaseException:
    dump(O/'transport_controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
