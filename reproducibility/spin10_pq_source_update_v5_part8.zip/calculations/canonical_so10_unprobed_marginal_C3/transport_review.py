from pathlib import Path
from hashlib import sha256
import gzip,json,os,threading,time
from cubic_core import *
R=O.parents[1];tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest()
for pp,h in read(O/'transport_review_preparation.json')['input_sha256'].items():assert H(Path(pp))==h,pp
def unpack(rows):
    out={tuple(z[:-1]):coeff(z[-1]) for z in rows};assert len(out)==len(rows) and all(out.values());return out
ab=[]
for role in ['primary','replay']:
    pp=O/('transport_'+role+'_tables.json.gz');assert H(pp)==read(O/('transport_'+role+'_result.json'))['packed_sha256'];ab.append(loadz(pp))
assert ab[0]['results']==ab[1]['results'] and all(z['guard_denials']==3 and z['nonzero_graded_sign_fixtures']==3 for z in ab)
images={};coverage=[]
for z in ab[0]['results']:
    total={}
    for name,rows in z['groups'].items():
        M=unpack(rows);assert len(M)==z['group_nonzero_counts'][name]
        for key,v in M.items():put(total,key,v)
    total=clean(total);assert total==unpack(z['total']) and len(total)==z['total_nonzero']
    assert z['domain_positions']==14612400 and len(total)+z['zero_complement']==14612400
    assert all(0<=r<45 and 0<=h<k<45 and 0<=i<328 for r,h,k,i in total)
    assert not z['groups']['JLJLCC'];images[z['probe']]=total
    coverage.append({k:v for k,v in z.items() if k not in ['groups','total']})
u=loadz(R/'calculations/canonical_so10_u_operation_root_inventory/root_primary_tables.json.gz')
expected={(('C','C','JL','JL'),0),(('C','C','JL','a'),0),(('C','JL','Ja'),0),(('Ja','x'),1),(('L','x'),1)}
assert {(tuple(p),nu) for p,nu,count in u['results'][1]['targets']['F']['nonzero_flows_by_root']}==expected
assert not u['results'][0]['targets']['F']['aggregate_flows']
P=R/'calculations/canonical_so10_unprobed_log3_support';receipt=read(P/'final_review_validation_receipt.json')
rel=str((P/'partial_after_known.json.gz').relative_to(R)).replace('\\','/')
assert H(P/'partial_after_known.json.gz')==receipt['new_files_sha256'][rel]
old=loadz(P/'partial_after_known.json.gz');reuse=read(P/'review_result.json')
assert reuse['old_actual_qualified_tensors_authenticated_and_compared']
assert next(z for z in reuse['six_roots_reused_or_support_zero'] if z['target']=='JaJLC')['nonzero']==0
assert next(z for z in reuse['six_roots_reused_or_support_zero'] if z['target']=='nJax')['nonzero']==0
late=[];saved=[]
for probe in range(2):
    prev=unpack(next(z for z in old['partial_tensors'] if z['probe']==probe and z['target']=='F')['partial_after_known_Bu_C0'])
    combined=dict(prev);wrong=dict(prev)
    for key,v in images[probe].items():put(combined,key,v);put(wrong,key,-v)
    combined=clean(combined);wrong=clean(wrong)
    late.append({'probe':probe,'target':'F','basis':'log3','previous_partial_nonzero':len(prev),
      'new_actual_image_nonzero':len(images[probe]),'complete_declared_sum_nonzero':len(combined),'complete_declared_sum_zero':not combined,
      'wrong_odd_source_prefix_sum_nonzero':len(wrong),'known_Lambda_x_image_already_owned_once':True,
      'full_Ward_QAP_or_physical_claim':False})
    saved.append({'probe':probe,'target':'F','basis':'log3','sum':encode(combined)})
payload={'schema':'UMC4_COMPLETE_DECLARED_F_LOG3_COMPARISON','results':late,'tensors':saved,'full_Ward_claim':False}
blob=gzip.compress((json.dumps(payload,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/'F_log3_complete_comparison.json.gz').open('xb') as f:f.write(blob)
out={'schema':'UMC4_COMPLETE_ACTUAL_IMAGE_AND_F_LOG3_REVIEW','complete_images_and_zero_complements_equal':True,'coverage':coverage,
 'all_five_UOR_F_log3_input_types_accounted_for':True,'late_complete_declared_F_log3_comparisons':late,
 'packed_comparison_sha256':sha256(blob).hexdigest(),'full_Ward_QAP_or_scientific_promotion':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'transport_review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
