from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
import gzip,json,os,sys,threading,time
from blocks import *
O=Path(__file__).resolve().parent;role=sys.argv[1];assert role in ['primary','replay']
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes())
for pp,h in read(O/'preparation.json')['input_sha256'].items():assert sha256(Path(pp).read_bytes()).hexdigest()==h,pp
peer='replay' if role=='primary' else 'primary'
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        pp=Path(os.fsdecode(args[0]))
        if pp.parent.resolve()==O and (pp.name.startswith(peer+'_') or pp.name.startswith('review_')):raise PermissionError('UMC_PEER_DENIED')
        if pp.parent.name in ['canonical_so10_u_lower_cutoff_contraction','canonical_so10_u_pair_contact_model'] or pp.parent.name=='canonical_so10_unprobed_log3_support' and pp.name in ['partial_after_known.json.gz','transport_review_result.json']:raise PermissionError('UMC_OLD_TARGET_DENIED')
sys.addaudithook(guard);denials=0
for pp in [O/(peer+'_blocks.json.gz'),R/'calculations/canonical_so10_unprobed_log3_support/partial_after_known.json.gz',R/'calculations/canonical_so10_u_lower_cutoff_contraction/late_remainders.json.gz']:
    try:pp.read_bytes()
    except PermissionError:denials+=1
assert denials==3
d=load(role);gradient={i:decode(z) for i,z in d['GF_gradient']};density=gf_primitive(gradient)
tables={};summary={};rawall={}
for name,poly in [('GF',density),('source',source_density(d))]:
    T=hessian(poly,role,1,2);raw={(i,j,w,p):v for (i,j,w,nd,p),v in T.items()}
    assert len(raw)==len(T)
    for (i,j,w,p),v in raw.items():
        assert len(w)+sum(p)==4-OP.dimension(i)-OP.dimension(j)
        assert len(w)%2==(OP.parity(i)+OP.parity(j))%2
        put(rawall,(i,j,w,p),v)
    tables[name]=raw;summary[name]={'entries':len(raw),'external_grade_counts':dict(Counter(len(w) for i,j,w,p in raw))}
rawall=clean(rawall)

# Every four-component/momentum monomial is reconstructed before axis use.
zero=(0,0,0,0);groups=defaultdict(dict)
for (i,j,w,p),v in rawall.items():
    ri,ci=(i//4,i%4) if i<180 else (i,None);rj,cj=(j//4,j%4) if j<180 else (j,None)
    groups[ri,rj,w][ci,cj,p]=v
shapes=Counter()
for (i,j,w),M in groups.items():
    vv=i<45 and j<45;vr=i<45;vc=j<45;E={}
    if vv:
        a0=M.get((0,0,zero),ZERO);a2=M.get((0,0,(0,2,0,0)),ZERO);b2=M.get((0,1,(1,1,0,0)),ZERO)
        assert len(w)==2 and not a2 and not b2,'ONLY_NONDERIVATIVE_METRIC_V2_BB_ALLOWED'
        for mu in range(4):put(E,(mu,mu,zero),a0)
        kind='V2_BB_metric'
    elif vr or vc:
        c=M.get((0,None,(1,0,0,0)) if vr else (None,0,(1,0,0,0)),ZERO)
        for mu in range(4):p=tuple(int(k==mu) for k in range(4));put(E,(mu,None,p) if vr else (None,mu,p),c)
        kind='pinned_vector_connector'
    else:
        a0=M.get((None,None,zero),ZERO);a2=M.get((None,None,(2,0,0,0)),ZERO)
        put(E,(None,None,zero),a0)
        for mu in range(4):p=tuple(2*int(k==mu) for k in range(4));put(E,(None,None,p),a2)
        kind='nonvector'
    assert clean(E)==M,('FULL_LORENTZ_SHAPE',i,j,w)
    shapes[kind]+=1
axis,q=(3,1) if role=='primary' else (2,-1);reduced=reduce(rawall,axis,q)
for (i,j,w),v in reduced.items():assert (int(i>=NB)+int(j>=NB))%2==len(w)%2
support=json.loads(gzip.decompress((R/'calculations/canonical_so10_unprobed_log3_support'/('support_v2_'+role+'_tables.json.gz')).read_bytes()))
counts={}
for z in support['results']:
    if z['target'] not in ['JLaCC','JLJLCC']:continue
    for ww in z['ordered_three_edge_words']:
        assert all(p in ['B','L','C','a'] for p in ww['Green_path'])
        assert not all(p=='B' for p in ww['Green_path'][:-1])
    counts[z['target']]=z['candidate_words']
assert counts=={'JLJLCC':12,'JLaCC':114}
out={'schema':'UMC1_COMPLETE_MARGINAL_ACTION_OPERATORS','role':role,'axis':axis,'q':q,'raw_tables':{k:encode(v) for k,v in tables.items()},
 'reduced':enc_reduced(reduced),'raw_summaries':summary,'raw_sum_entries':len(rawall),'reduced_entries':len(reduced),
 'all90_GF_Euler_columns_reproduced':True,'GF_density_terms':len(density),'all_four_component_Lorentz_monomials_verified':True,
 'Lorentz_shapes':dict(shapes),'no_free_D_trace_by_pinned_connectors_and_metric_V2':True,'qualified_full_support_counts':counts,
 'source_H_CC_JLa_and_GF_H_aa_CC_not_dropped':True,'guard_denials':denials,'quantum_C3_tensor_measured':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/(role+'_blocks.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({k:v for k,v in out.items() if k not in ['raw_tables','reduced']},sort_keys=True)+' ELAPSED '+str(time.perf_counter()-tick),flush=True)
timer.cancel()
