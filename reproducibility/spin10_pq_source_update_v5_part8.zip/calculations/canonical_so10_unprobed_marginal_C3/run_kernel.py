from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-marginal-c3-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
    with p.open('xb') as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings=dict(read(O/'method_preparation.json')['input_sha256'])
    for pp,h in bindings.items():assert H(Path(pp))==h,pp
    m=read(O/'method_result.json');assert m['actual_path_cost'][0]['closed_colored_paths']==807932
    for name in ['WHOLE_RECORD.md','kernel.py','run_kernel.py']:
        pp=O/name
        if pp.suffix=='.py':ast.parse(pp.read_bytes())
        with (O/(name+'.source.txt')).open('xb') as f:f.write(pp.read_bytes())
    for pp in O.iterdir():
        if pp.is_file():bindings[str(pp)]=H(pp)
    dump(O/'whole_preparation.json',{'input_sha256':bindings,'aggregate_after_imports_budget_seconds':600,'scientific_acceptance':'NOT_PERFORMED'})
    used=0
    for role in ['primary','replay']:
        z=capture([sys.executable,'-B',str(O/'kernel.py'),role]);dump(O/('kernel_'+role+'_capture.json'),z);dump(C/('kernel_'+role+'_full_capture.json'),z)
        assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified']
        result=[json.loads(v[7:]) for v in z['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(result)==1 and result[0]['elapsed_after_imports']<300
        used+=result[0]['elapsed_after_imports'];assert used<=600
        dump(O/('kernel_'+role+'_result.json'),result[0]);print('COMPLETED UMC3 '+role+' '+str(used),flush=True)
    dump(O/'whole_execution_result.json',{'schema':'UMC3_COMPLETE_NATIVE_EXECUTION','aggregate_after_imports_seconds':used,'aggregate_budget_seconds':600,'scientific_acceptance':'NOT_PERFORMED'})
except BaseException:
    dump(O/'kernel_controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
