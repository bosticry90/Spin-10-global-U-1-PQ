# UMC4a: full coefficient agreement and fresh uncut action checks

After both complete tensor jobs finish,authenticate every group/sum and
full zero complement. JLaCC domain2004750,JLJLCC domain980100.
Check actual canonical density orders and absence of an extra half.
The JLJLCC zero must agree with the complete actual closed-color-path
exclusion,not merely an empty printout. Retain all six V2 families,
including model-zero ones. No old remainder is read in this review.

Freshly reconstruct the complete original GF density and source Hessian
at selected labels,not an Euler-column-only shortcut or the reduced
cyclic model formula. Four deterministic nonzero JLaCC coefficients,
two fixed JLaCC zeros and four fixed JJ zero contexts are checked by
literal FULL four-component tagged1/6 STr(GV)^3,axis3/q+ andaxis2/q-.
If no nonzero JLaCC coefficient exists,use deterministic fixed contexts
and retain that limitation. Every quantum/internal-jet port stays until
external restriction. All four source/field variables are odd and the
tag basis follows the stated JL-first density order.

At the first two JLaCC contexts quantify actual omission controls for
source H_CC|JL*a,GF H_aa|CC,and GF H_BB|aC. A zero model control remains
insensitive; the generic exterior fixtures supply separate sensitivity.
These selected checks supplement complete tensor/zero-complement
agreement and the full126-word support,not replace them. Do not weaken
requirements or change a source sign if a check fails. Preserve failures.

Review180s,8GiB sampled,350MiB launchfloor,32MiB packet. No full
continuum/Ward/QAP or scientific promotion. Only after qualification may
the actual UOR operation and later old F comparison be executed.
