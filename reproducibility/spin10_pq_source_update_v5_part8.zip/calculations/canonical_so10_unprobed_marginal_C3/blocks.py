from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction
import ast,sys
R=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(R/'calculations/canonical_so10_u_F_fourth_support'))
import operators as OP
from operators import Coeff,ZERO,I,constant,decode,dec,load,co
NB=418;DIM=508
def put(T,k,v):
    if v:T[k]=T.get(k,ZERO)+v
def clean(T):return {k:v for k,v in T.items() if v}
def external_type(i):return 'C' if 553<=i<598 else 'a' if 598<=i<643 else 'JL' if 1151<=i<1196 else None
def allowed(word,nd,low,high):
    if nd!=0 or not low<=len(word)<=high:return None
    c=Counter();ids=[]
    for i,js in word:
        k=external_type(i)
        if k is None or js:return None
        c[k]+=1;ids.append(i)
    if len(ids)!=len(set(ids)) or c['C']>2 or c['JL']>2 or c['a']>1:return None
    if not any(not(c-Counter(p)) for p in [('JL','a','C','C'),('JL','JL','C','C')]):return None
    return tuple(ids)
tree=ast.parse((R/'calculations/canonical_so10_u_F_fourth_support/operators.py').read_bytes())
names={'hessian','gf_primitive','source_density'}
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
ns=dict(vars(OP));ns['allowed']=allowed
exec(compile(ast.Module(body=nodes,type_ignores=[]),'UMC_FULL_DENSITY_NEW_EXTERNAL_DOMAIN','exec'),ns)
for name in names:globals()[name]=ns[name]
def coeff(terms):return Coeff([(tuple(k),Fraction(n,d)) for k,n,d in terms])
def encode(T):return [[i,j,list(w),list(p),[[list(k),v.numerator,v.denominator] for k,v in c.terms]] for (i,j,w,p),c in sorted(T.items())]
def quantum(i,axis):
    if i<180:return i//4 if i%4==axis else None
    if i<508:return 90+i-180
    if i<553:return 45+i-508
    if i<598:return 418+i-553
    return 463+i-598
def reduce(T,axis,q):
    out={}
    for (i,j,w,p),v in T.items():
        a,b=quantum(i,axis),quantum(j,axis)
        if a is None or b is None or any(n for mu,n in enumerate(p) if mu!=axis):continue
        v=v*(q**sum(p))
        if a<45:fold=[(a,co('eta_H' if a<12 else 'xi')),(45+a,constant(q))]
        elif a<90:fold=[(a-45,constant(-q))]
        elif a<418:fold=[(a,constant(1))]
        elif a<463:fold=[(a+45,constant(-1))]
        else:fold=[(a-45,constant(1))]
        for row,factor in fold:put(out,(row,b,w),v*factor)
    return clean(out)
def enc_reduced(T):return [[i,j,list(w),[[list(k),v.numerator,v.denominator] for k,v in c.terms]] for (i,j,w),c in sorted(T.items())]
