# Final delegated audits, prospective

After UMC1-4 qualification run exactly once
`python -B tools/research_check.py e4`,without --fresh,before local commit.
Freeze command/tool/live policy/state/result bytes;retain full capture.
Expected native0,steps[0,0,0,0,0,2],terminalCOMPLETED,custodysevenNOTPASS.
This authenticates existing sealed evidence/current bounded audits,
not fresh global scientific replay or scientific promotion. Same300s
effort ceiling,8GiB sampled,350MiB launchfloor,32MiBpacket. Preserve
failure/incompleteness separately;no silent automatic retry.
