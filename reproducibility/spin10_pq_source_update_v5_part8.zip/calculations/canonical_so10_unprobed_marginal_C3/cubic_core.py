from pathlib import Path
from fractions import Fraction
from collections import Counter,defaultdict
import gzip,json
from blocks import Coeff,ZERO,constant,coeff,external_type,NB
O=Path(__file__).resolve().parent
def get(role):
    z=json.loads(gzip.decompress((O/(role+'_blocks.json.gz')).read_bytes()))
    T={(i,j,tuple(w)):coeff(c) for i,j,w,c in z['reduced']};assert len(T)==len(z['reduced'])
    return z,T
def merge(word):
    if len(word)!=len(set(word)):return (),0
    return tuple(sorted(word)),(-1)**sum(a>b for at,a in enumerate(word) for b in word[at+1:])
def target(word):
    c=Counter(external_type(i) for i in word)
    if c==Counter({'JL':1,'a':1,'C':2}):return 'JLaCC'
    if c==Counter({'JL':2,'C':2}):return 'JLJLCC'
    return None
def owning_key(word):
    cc=[i-553 for i in word if 553<=i<598];aa=[i-598 for i in word if 598<=i<643];jj=[i-1151 for i in word if 1151<=i<1196]
    if aa:return 'JLaCC',(jj[0],aa[0],*cc),-1
    return 'JLJLCC',(*jj,*cc),1
def sector(i):return 'B' if i<45 else 'L' if i<90 else 'x' if i<418 else 'C' if i<463 else 'a'
def family(i,j,w):
    tags=tuple(sorted(external_type(k) for k in w))
    if tags==('C','C'):return 'CC'
    if tags==('C','a'):return 'aC_boson' if i<90 or j<90 else 'aC_scalar' if i<418 or j<418 else 'aC_ghost'
    if tags==('C','JL'):return 'JLC'
    if tags==('JL','a'):return 'JLa'
    return ':'.join(tags)
def components(T):
    V1={k:v for k,v in T.items() if len(k[2])==1};V2={k:v for k,v in T.items() if len(k[2])==2}
    assert len(V1)+len(V2)==len(T)
    outgoing=defaultdict(list);edge=defaultdict(list)
    for (i,j,w),v in V1.items():
        tag=external_type(w[0]);outgoing[i,tag].append((j,w[0],v));edge[i,j,tag].append((w[0],v))
    return V1,V2,outgoing,edge
def complementary_types(w):
    c=Counter(external_type(i) for i in w);out=set()
    for total in [Counter({'JL':1,'a':1,'C':2}),Counter({'JL':2,'C':2})]:
        if c-total:continue
        rem=list((total-c).elements());assert len(rem)==2
        out.add(tuple(rem));out.add(tuple(rem[::-1]))
    return sorted(out)
def paths(T):
    V1,V2,outgoing,edge=components(T)
    for (i,j,w),v in V2.items():
        fam=family(i,j,w)
        for ta,tb in complementary_types(w):
            for k,a,x in outgoing[j,ta]:
                for b,y in edge[k,i,tb]:
                    word,sg=merge(w+(a,b))
                    if not sg:continue
                    case=target(word);assert case is not None
                    yield case,fam,i,j,k,w,a,b,word,sg,v,x,y
def encode(M):return [[*key,[[list(k),v.numerator,v.denominator] for k,v in c.terms]] for key,c in sorted(M.items()) if c]
def put(M,key,v):
    if v:M[key]=M.get(key,ZERO)+v
def clean(M):return {k:v for k,v in M.items() if v}
