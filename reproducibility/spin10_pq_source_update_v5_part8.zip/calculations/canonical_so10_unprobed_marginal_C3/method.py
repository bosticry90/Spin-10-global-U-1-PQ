from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import Counter,defaultdict
import gzip,json,os,threading,time
from cubic_core import *
R=O.parents[1];tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
for pp,h in read(O/'method_preparation.json')['input_sha256'].items():assert sha256(Path(pp).read_bytes()).hexdigest()==h,pp
data=[get(role) for role in ['primary','replay']]
assert data[0][0]['raw_tables']==data[1][0]['raw_tables']
assert all(z['all90_GF_Euler_columns_reproduced'] and z['all_four_component_Lorentz_monomials_verified'] for z,T in data)

# Literal finite exterior algebra, independently enumerating odd inversions.
def mul(A,B,commuting=False):
    out=defaultdict(Fraction)
    for (i,j,w),v in A.items():
        for (k,l,u),x in B.items():
            if j!=k or set(w)&set(u):continue
            z=w+u;sg=1 if commuting else (-1)**sum(a>b for a in w for b in u)
            out[i,l,tuple(sorted(z))]+=v*x*sg
    return {k:v for k,v in out.items() if v}
def add(*args):
    out=defaultdict(Fraction)
    for A in args:
        for key,v in A.items():out[key]+=v
    return {k:v for k,v in out.items() if v}
def trace(A,ordinary=False):
    return sum((v*(1 if ordinary else (-1)**int(i>=2)) for (i,j,w),v in A.items() if i==j and w==(0,1,2,3)),Fraction())
fixtures=[];controls=Counter()
for seed in [1,2,3]:
    V1={};V2={}
    for i in range(4):
        for j in range(4):
            if (i>=2)!=(j>=2):
                for a in range(4):V1[i,j,(a,)]=Fraction((seed+2*i+3*j+5*a)%11-5)
            else:
                for a in range(4):
                    for b in range(a+1,4):V2[i,j,(a,b)]=Fraction((3*seed+5*i+2*j+7*a+11*b)%13-6)
    full=Fraction(1,6)*trace(mul(mul(add(V1,V2),add(V1,V2)),add(V1,V2)))
    terms=[trace(mul(mul(V2,V1),V1)),trace(mul(mul(V1,V2),V1)),trace(mul(mul(V1,V1),V2))]
    reduced=Fraction(1,2)*terms[0];assert full==reduced and len(set(terms))==1
    wrong=Fraction(1,2)*trace(mul(mul(V2,V1),V1),ordinary=True);controls['ordinary_trace']+=wrong!=full
    wrong=Fraction(1,2)*trace(mul(mul(V2,V1,True),V1,True));controls['commuting_exterior']+=wrong!=full
    for pair in [(0,1),(2,3)]:
        B={k:v for k,v in V2.items() if k[2]!=pair};wrong=Fraction(1,2)*trace(mul(mul(B,V1),V1));controls['omit_pair_'+str(pair)]+=wrong!=full
    fixtures.append({'seed':seed,'full_coefficient':str(full),'three_cyclic_traces':[str(v) for v in terms],'reduced_coefficient':str(reduced)})
assert all(controls.values()),controls

support=load(R/'calculations/canonical_so10_unprobed_log3_support/support_v2_primary_tables.json.gz');expected=defaultdict(set)
for z in support['results']:
    if z['target'] not in ['JLaCC','JLJLCC']:continue
    for word in z['ordered_three_edge_words']:
        seq=[]
        for at,i in enumerate(word['letters']):
            e=support['letters'][i];seq.append((tuple(sorted(e['external_types'])),word['Green_path'][at],word['Green_path'][at+1]))
        for j in range(3):expected[z['target']].add(tuple(seq[j:]+seq[:j]))
cost=[]
for role,(z,T) in zip(['primary','replay'],data):
    counts=Counter();observed=defaultdict(set);start=time.perf_counter()
    for case,fam,i,j,k,w,a,b,word,sg,v,x,y in paths(T):
        seq=((tuple(sorted(external_type(c) for c in w)),sector(i),sector(j)),((external_type(a),),sector(j),sector(k)),((external_type(b),),sector(k),sector(i)))
        assert seq in expected[case],('UNQUALIFIED_TYPE_PATH',case,seq)
        assert 'x' not in [sector(i),sector(j),sector(k)]
        observed[case].add(seq);counts[case,fam]+=1
        # Total graded cyclicity includes original starting supertrace signs.
        s1=(-1)**int(i>=NB)*sg;s2=(-1)**int(j>=NB)*merge((a,b)+w)[1];s3=(-1)**int(k>=NB)*merge((b,)+w+(a,))[1]
        assert s1==s2==s3
    cost.append({'role':role,'closed_colored_paths':sum(counts.values()),'by_case_family':[[list(key),value] for key,value in sorted(counts.items())],
      'observed_coarse_type_paths':{k:len(v) for k,v in observed.items()},'count_seconds':time.perf_counter()-start})
assert cost[0]['by_case_family']==cost[1]['by_case_family']
out={'schema':'UMC2_GRADED_CUBIC_METHOD_AND_COMPLETE_PATH_COST','raw_classical_tables_equal':True,'fixtures':fixtures,'sensitive_controls':dict(controls),
 'finite_Gaussian_normalization_inherited_not_proved_by_cycle_test':True,'actual_path_cost':cost,'every_colored_path_within_qualified_ULS_support':True,
 'no_scalar_or_fermion_complete_path':True,'quantum_tensor_or_old_remainder_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'method_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
