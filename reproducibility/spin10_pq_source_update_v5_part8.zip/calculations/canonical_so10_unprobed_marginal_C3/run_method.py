from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-marginal-c3-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
    with p.open('xb') as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings=dict(read(O/'preparation.json')['input_sha256'])
    for pp,h in bindings.items():assert H(Path(pp))==h,pp
    for name in ['METHOD_RECORD.md','cubic_core.py','method.py','run_method.py']:
        pp=O/name
        if pp.suffix=='.py':ast.parse(pp.read_bytes())
        with (O/(name+'.source.txt')).open('xb') as f:f.write(pp.read_bytes())
    for pp in O.iterdir():
        if pp.is_file():bindings[str(pp)]=H(pp)
    dump(O/'method_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    z=capture([sys.executable,'-B',str(O/'method.py')]);dump(O/'method_capture.json',z);dump(C/'method_full_capture.json',z)
    assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified']
    result=read(O/'method_result.json');assert result['elapsed_after_imports']<180
    print('COMPLETED UMC2 '+json.dumps(result['actual_path_cost'],sort_keys=True),flush=True)
except BaseException:
    dump(O/'method_controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
