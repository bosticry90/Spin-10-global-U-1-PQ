# UMC4b: complete actual u-operation on the new kernels, prospective

UMC4a qualifies both complete kernels and20 fresh full-action checks.
Apply every UOR aggregate flow reaching F from C0 types JL a CC and
JL JL CC,retaining original QG source degrees and derivative-before-
restriction. No rho/G operation or source-free shortcut is substituted.

Primary differentiates the owning densities JL_r a_s C_h C_k and
JL_r JL_s C_h C_k by explicit odd-position Leibniz signs. Replay first
converts the whole quantum density to physical canonical order,then
uses literal graded derivation and exterior normalization. Source JL,
antighost a and ordinary C are ALL odd. In particular the a variation
in the first density has a minus sign from the preceding JL. Keep the
two possible source derivatives of the second density without an extra
half,even though its actual loop tensor is zero. Generic nonzero graded
fixtures test those signs;zero models cannot do so.

Both routes must agree on each whole image,sum and all implicit zeros
over14612400 positions/probe. Native old-remainder and peer guards.
No value,phase or finite normalization is fitted to desired cancellation.
Only after agreement may later review add these images ONCE to ULS's
authenticated F log3 partial_after_known tensor. The known Lambda-x
source2 image is already included there and must not be added again.

Native300s/role,review180s,private8GiB sampled,350MiB launchfloor,
32MiB total packet. Exact sources/captures preserved. Original formal
domain/authority ceiling unchanged;full finite Ward/contact/QAP/measure
applicability and other prime-log/absolute normalization obligations
remain beyond a scoped coefficient comparison.
