"""YBH1 covariant momentum differentiation and Gaussian-Schwinger power moments."""
from data_v2 import *
tick=begin('replay');d=packed(HERE/'replay_inputs.json.gz');Z=s.zeros(2);I=s.eye(2);sigma=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];g=[block(Z,-s.I*z,s.I*z,Z) for z in sigma]+[block(Z,I,I,Z)];L=s.diag(1,1,0,0);R=s.eye(4)-L;T=s.diag(1,2);A=s.kronecker_product(L,T)-s.kronecker_product(R,T.T);B=s.kronecker_product(R,T)-s.kronecker_product(L,T.T);outer=s.kronecker_product(R,I);inner=s.kronecker_product(L,I);rho=s.Matrix([[0,1],[-1,0]])
k=s.symbols('k0:4');Q=sum(z*z for z in k);slash=sum((z*v for z,v in zip(g,k)),s.zeros(4));G=-s.I*s.kronecker_product(slash,I)/Q;t=s.Symbol('t',positive=True);E=s.exp(-2*t*Q)
v=s.Symbol('v',positive=True);J=s.integrate(v/(v+4)**3,(v,0,s.oo))/2
# J/t is the exact rank-two Schwinger moment of e^-4tQ/Q2.
def gaussian(z):
 out=0
 for powers,val in s.Poly(s.expand(z),*k).terms():
  if not val:continue
  assert sum(powers)==2
  if sorted(powers)==[0,0,0,2]:out+=val*J
 return simp(out)
def coefficient(M,target):
 ij=next(ij for ij,z in target.todok().items() if z);v=simp(M[ij]/target[ij]);zero(M-v*target);return v
units=[];controls=[];positions=0
for mu in range(4):
 # Constant connection variation is -d_k(EG) B; isolate its dE term.
 heat_f=-s.diff(E,k[mu])*G*B;raw=tidy(-outer*heat_f*inner*Q/(t*E));got=raw.applyfunc(gaussian);target=s.kronecker_product(g[mu]*L,T.T)
 # Scalar momentum is p_s=-k. -d_{p_s} E times i*rho has opposite routing.
 ps=s.Symbol('p_s');Es=s.exp(-2*t*(ps**2+sum(k[j]**2 for j in range(4) if j!=mu)));scalar_dE=(s.I*rho*s.diff(Es,ps)).subs(ps,-k[mu]);zero(scalar_dE-4*s.I*t*k[mu]*E*rho)
 # The scalar inverse response uses -i*rho*d_{p_s}; keep that orientation.
 scalar_heat=-scalar_dE;rawS=tidy(-s.kronecker_product(R*(-s.I*slash)*L,scalar_heat)*1/(t*E));gotS=rawS.applyfunc(gaussian);targetS=s.kronecker_product(g[mu]*L,rho)
 wrong=tidy(-outer*(-s.diff(E,k[mu])*G*A)*inner*Q/(t*E)).applyfunc(gaussian);controls.append(nz(wrong-got));assert controls[-1]>0
 units.append((coefficient(got,target),coefficient(gotS,targetS)));positions+=2*8**2
assert len(set(units))==1;uf,us=units[0]
a,b=s.symbols('a b',positive=True);frullani=s.integrate(-1/a,(a,6,4));assert simp(frullani-s.log(s.Rational(3,2)))==0
hf=simp(uf/(s.I/2));hs=simp(us/(s.Rational(1,2)))
out=assemble(d,hf,hs);out.update({'method':'covariant_momentum_heat_derivative_Gaussian_Schwinger_rank_two_and_Frullani_boundary','heat_fermion_absolute_unit':str(uf),'heat_scalar_absolute_unit':str(us),'heat_fermion_pole_ratio':str(hf),'heat_scalar_pole_ratio':str(hs),'inverse_placement_log':str(frullani),'spin_Lorentz_positions':positions,'wrong_right_carrier_fixture_changes':controls,'one_endpoint_omission_is_half':True,'scalar_routing':'scalar_momentum_minus_k_from_actual_YGV_Euler','scalar_heat_definition':'DECLARED_MINIMAL_CONNECTION_LAPLACIAN_OF_ACTUAL_H_SCALAR_ACTION','physical_action_changed':False});finish('replay',out,tick)
