"""YBH1 freeze candidate heat definition, inherited quantum inputs and separate targets."""
from pathlib import Path
from hashlib import sha256
import json,gzip,sys,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PRED=CAL/'canonical_so10_auxiliary_background_yukawa_finite'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/yukawa-background-heat-completion-v1-2026-10-23');OLD=CONTROL.with_name('auxiliary-background-yukawa-finite-v1-2026-10-23')
BASE='bedd8185e43daf6cf2ff68218fdf115c113e7596';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'validation_preparation.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
def gz(p,d):
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
def source(folder,name):p=CAL/folder/name;add(p);return packed(p)
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==32923
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
assert digest(PRED/'validation_receipt.json')=='f2bbc9037a59fd9d8ce20aaa57efd62c327d221b13c99cdd6ec3c5dee605190d'
for n in ['validation_receipt.json','verify_capture.json','RESULT.md','validation_preparation.json']:add(PRED/n)
for n in ['before_commit_seal.json','successful_index_gate.json','postcommit_seal.json','seal.py','after_seal_full_capture.json']:add(OLD/n)
assert read(OLD/'postcommit_seal.json')['clean'] and read(OLD/'after_seal_full_capture.json')['native_exit']==0
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V560.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
for folder,names in [('canonical_so10_fermionic_background_reference',['DERIVATION.md','RESULT.md','validation_receipt_v2.json','candidate_background_reference.json.gz']),('canonical_so10_yukawa_dependent_gauge_vertices',['RECORD.md','RESULT.md','primary.py','replay.py','validation_receipt.json']),('canonical_so10_matter_gauge_vertex_finite_units',['DERIVATION.md','RESULT.md','validation_receipt.json']),('canonical_so10_matter_gauge_vertex_finite_color',['DERIVATION.md','RESULT.md','validation_receipt.json']),('canonical_so10_open_fermion_heat_kinetic',['DERIVATION.md','RESULT.md','validation_receipt.json'])]:
 for n in names:add(CAL/folder/n)
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;b=p.read_bytes();assert b'\r' not in b
 if p.suffix=='.py':compile(b,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 add(p);add(HERE/(n+'.source.txt'))
for role in ['primary','replay']:
 y=source('canonical_so10_yukawa_carrier_transport',role+'_tables.json.gz');v=source('canonical_so10_yukawa_dependent_gauge_vertices',role+'_tables.json.gz');a=source(PRED.name,role+'_tables.json.gz')
 d={'H_new':y['H_new'],'pole_currents':v['outputs'],'aux_current':{k:a[k] for k in ['left','right']},'family_left':v['family_left'],'family_right':v['family_right'],'fermion_phase':v['fermion_phase'],'scalar_phase':v['scalar_phase'],'scalar_vertex_phase':v['scalar_vertex_phase'],'selfenergy_unit':v['selfenergy_unit']}
 gz(HERE/(role+'_inputs.json.gz'),d);add(HERE/(role+'_inputs.json.gz'))
v=source('canonical_so10_matter_gauge_vertex_finite_color','primary_tables.json.gz');k=source('canonical_so10_open_fermion_heat_kinetic','primary_tables.json.gz');y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');f=packed(CAL/'canonical_so10_yukawa_dependent_gauge_vertices/primary_tables.json.gz')
gz(HERE/'validation_control_inputs.json.gz',{'old_current':{part:{tag:z for tag,z in row.items() if tag!='gauge'} for part,row in v['diagonal_H'].items()},'kinetic':{part:{tag:z for tag,z in row.items() if tag!='gauge'} for part,row in k['kinetic_coefficients'].items()},'Tminus':y['Tminus'],'family_left':f['family_left'],'family_right':f['family_right']});add(HERE/'validation_control_inputs.json.gz')
with (CONTROL/'readiness.jsonl').open('xb') as out,(CONTROL/'readiness_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_check.py'),'e4'],stdout=out,stderr=err,cwd=ROOT)
events=[json.loads(v) for v in (CONTROL/'readiness.jsonl').read_text().splitlines()];steps=[v for v in events if v['event']=='step_finished'];assert r.returncode==0 and [v['exit_code'] for v in steps]==[0,0,0,0,0,2] and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
dump(CONTROL/'readiness_result.json',{'native_exit':r.returncode,'step_exits':[v['exit_code'] for v in steps],'fresh_command_here':True,'historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED'})
for n in ['readiness.jsonl','readiness_stderr.txt','readiness_result.json']:add(CONTROL/n)
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],stdout=out,stderr=err,cwd=ROOT)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and not d['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'YBH1_PREPARATION','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('YBH1_FROZEN',len(bind),'bindings',flush=True)
