# YBH1: ordered inverse and both heat derivatives

Let Q=k2 and F=exp(-tQ), E=F2=exp(-2tQ). The two-edge Yukawa self energy
has weight E_fermion E_scalar=exp(-4tQ) at its critical zero-jet symbol.
The old proper-action triangles instead have three independently filtered
edges and weight exp(-6tQ). A background derivative of a reference edge is

 delta(F G Fdual)=deltaF G Fdual - F G deltaK G Fdual + F G deltaFdual.

The inverse term keeps one endpoint F on each side of the whole inverse
response, not a new filtered propagator on each side of an action vertex.
Thus both fermion- and scalar-inverse background insertions have total heat
length4, not6. Their finite heat difference is derived from

 16pi2 integral (exp(-4tQ)-exp(-6tQ))/Q2 = log(6/4).

The difference is infrared integrable and independent of positive t. It is
not a scaleless integral or a chosen subtraction constant.

For FBR1 X=A=PL T-PR T.T and Xswap=B=PR T-PL T.T on the physical block,
deltaP_X=-2g k_mu X at zero background momentum. Duhamel gives

deltaF=2tg k_mu X F, deltaFdual=2tg k_mu Xswap F.

Keep their order around G=-i bar_slash(k)/Q. The inherited open-line
self-energy sign is -1. Its two YdagY endpoints select PR outside and PL
inside; A and B act at different ends. Calculate the angular numerator of
-2 k_mu PR [A(-i slash)+(-i slash)B] PL before any color contraction.
The opposite chirality has its corresponding conjugate orientation.

For the scalar edge retain momentum -k. Its actual quadratic Euler gives
deltaP_scalar=+2ig rho_H k_mu in the established YGV convention. The two
heat derivatives are -2t deltaP_scalar E/Q. Multiply by the physical fermion
numerator and the same self-energy sign. The scalar and fermion heat signs
need not agree; derive them independently. The shared finite radial identity
is16pi2 integral exp(-4tQ)/Q=1/(4t), with <k_mu k_nu>/Q=delta_mu_nu/4.

Replay derives the same finite power integrals directly using

 16pi2 integral exp(-4tQ) k_mu k_nu/Q2
   = delta_mu_nu/2 integral_0^infinity s/(s+4t)^3 ds,

and momentum differentiation of the covariant inverse. This avoids inferring
either finite constant from the Ward target or using cyclicity of a singular
trace. The first pure-gauge ordered identity is inherited from FBR1, not
claimed as a new infinite-dimensional trace or distributional theorem.

Define the measured action pole currents F_h and S_h for the fermion and
scalar insertion, with both family factors retained. Derive heat ratios hF,
hS and placement log l. The new heat-minus-old heat is

 l(F_h+S_h) + hF F_h + hS S_h.

The independent dimensional-reference change is the measured ABY1 finite
current A_h. Therefore the new dimensional-minus-background-heat current is

 old_action_relative_h + A_h
   - l(F_h+S_h) - hF F_h - hS S_h.

Every term is action/reference derived before the late comparison with FHK.
No full g3 gauge background or absolute finite normalization is inferred.
The candidate scalar heat is explicit; general curvature-dependent or
positive-mass extensions, full background determinant and analytic product
construction remain separate. A matched local coefficient is a selected
compatibility result, not the full quantum consistency theorem.
