"""YBH1 V2 exact-assertion continuation, frozen before the workers."""
from pathlib import Path
from hashlib import sha256
import json,gzip,sys,traceback
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/yukawa-background-heat-completion-v1-2026-10-23')
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode())
label='freeze_v2'
try:
 old=json.loads((HERE/'preparation.json').read_bytes());bind=dict(old['input_sha256'])
 for p,h in bind.items():assert digest(Path(p))==h,p
 assert json.loads((HERE/'primary_capture.json').read_bytes())['exit_code']==1
 assert json.loads((HERE/'controller_failure.json').read_bytes())['last_role']=='primary'
 assert not any((HERE/n).exists() for n in ['replay_capture.json','verify_capture.json','primary_tables.json.gz'])
 for n in ['CONTINUATION_V2.md','data_v2.py','primary_v2.py','replay_v2.py','verify_v2.py','continue_v2.py']:
  p=HERE/n;b=p.read_bytes();assert b'\r' not in b
  if n.endswith('.py'):compile(b,str(p),'exec')
  with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 for p in HERE.iterdir():
  if p.is_file():bind[str(p.resolve())]=digest(p)
 for n in ['primary_full_capture.json','preparation_full_capture.json']:p=CONTROL/n;bind[str(p)]=digest(p)
 dump(HERE/'preparation_v2.json',{**old,'schema':'YBH1_PREPARATION_V2','input_sha256':dict(sorted(bind.items())),'original_primary':'FAILED_ZERO_POLYNOMIAL_DEGREE_HELPER','original_replay_and_gate':'NOT_LAUNCHED','original_sources_and_complete_failure_preserved':True})
 print('YBH1_V2_FROZEN',len(bind),'bindings',flush=True)
 for label in ['primary','replay','verify']:
  if label=='verify':
   vb=dict(bind)
   for p in HERE.iterdir():
    if p.is_file():vb[str(p.resolve())]=digest(p)
   dump(HERE/'validation_preparation_v2.json',{'schema':'YBH1_VALIDATION_PREPARATION_V2','input_sha256':dict(sorted(vb.items())),'scientific_acceptance':'NOT_PERFORMED'})
  c=capture([sys.executable,'-B',str(HERE/(label+'_v2.py'))]);dump(HERE/(label+'_v2_capture.json'),c);dump(CONTROL/(label+'_v2_full_capture.json'),c);print(c['stdout_and_stderr'],flush=True)
  assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
  assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
  rows=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rows)==1;r=rows[0];assert r['elapsed_after_imports']<600
  if label=='verify':assert r['status'] in ['QUALIFIED_SELECTED_YUKAWA_BACKGROUND_HEAT_COMPLETION_AND_KINETIC_COMPATIBILITY','QUALIFIED_SELECTED_YUKAWA_BACKGROUND_HEAT_COMPLETION_WITH_NONZERO_KINETIC_REMAINDER']
  else:
   raw=(HERE/(label+'_tables_v2.json.gz')).read_bytes();assert sha256(raw).hexdigest()==r['packed_sha256'] and sha256(gzip.decompress(raw)).hexdigest()==r['tables_sha256']
  dump(HERE/('validation_receipt_v2.json' if label=='verify' else label+'_v2_result.json'),r);assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
  print(label,'V2_COMPLETED',r['elapsed_after_imports'],flush=True)
except BaseException:
 dump(HERE/'controller_failure_v2.json',{'execution_state':'FAILED','last_role':label,'traceback':traceback.format_exc(),'failure_relabelled_PASS':False,'scientific_acceptance':'NOT_PERFORMED'});raise
