# YBH1 V2: preserve the exact-zero polynomial in angular averaging

Original primary FAILED before any finite result: SymPy applyfunc first calls
the angular helper on zero. Poly(0).terms() returns a zero coefficient of
degree0, rejected by the nonzero degree2 assertion. The full source,2031-bound
manifest, native capture and controller failure are preserved. Original replay
and gate were NOT LAUNCHED; no scientific result is relabelled PASS.

V2 skips exact zero coefficients before checking degree2 in primary angular
and replay Gaussian helpers. No nonzero numerator, angular rule, integration,
input, target or requirement changes. Both independent workers and the same
late gate use new versioned files/outputs. All original bindings and failure
captures, plus six new sources/copies, are frozen before launch. Reuse this
turn's completed fresh E4 audit. Same sequential600s/8GiB/350MiB/16MiB limits,
fail-stop behavior and34/39 ceiling. No physical scheme or scientific adoption.
