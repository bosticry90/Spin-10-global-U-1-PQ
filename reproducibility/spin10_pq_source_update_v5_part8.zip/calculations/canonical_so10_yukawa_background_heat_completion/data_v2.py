"""YBH1 immutable IO and exact matrix serialization; derivations are separate."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json,gzip,os,sys,time,threading
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
@lru_cache(maxsize=262144)
def simp(z):return s.simplify(z)
def tidy(m):return s.SparseMatrix(m).applyfunc(simp)
def zero(m):assert not tidy(m).todok()
def nz(m):return len(tidy(m).todok())
def dec(m):return s.SparseMatrix(*m['shape'],{(i,j):s.sympify(z) for i,j,z in m['entries']})
def enc(m):return {'shape':list(m.shape),'entries':[[int(i),int(j),str(s.expand(z))] for (i,j),z in sorted(tidy(m).todok().items())]}
def block(a,b,c,d):return s.SparseMatrix(s.BlockMatrix([[a,b],[c,d]]).as_explicit())
def begin(role):
 tick=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and (p.name.startswith(peer) or p.name=='validation_control_inputs.json.gz'):raise PermissionError('YBH1_PEER_OR_LATE_TARGET_DENIED')
 sys.addaudithook(audit);return tick
def finish(role,out,tick):
 out.update({'elapsed_after_imports':time.perf_counter()-tick,'construction':'SELECTED_YUKAWA_BACKGROUND_MINIMAL_CONNECTION_HEAT_MEMBER_NOT_ADOPTED','heat_member':'FBR_FERMION_DUAL_HEAT_AND_DECLARED_MINIMAL_SCALAR_CONNECTION_HEAT','finite_complete_background_vertex':False,'physical_scheme_adopted':False,'full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'})
 raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables_v2.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)

def assemble(d,hf,hs):
 H=dec(d['H_new']);proj={};heat={'fermion':{},'scalar':{}};placement={};transport={part:{} for part in ['chi4','log3over2','fixed']}
 for side in ['left','right']:
  proj[side]={};placement[side]=[]
  for fam in ['fermion','scalar']:
   proj[side][fam]=[];heat[fam][side]=[]
   for rows in d['pole_currents'][fam][side]:
    mats=list(map(dec,rows));arr=[tidy(sum((H[a,h]*mats[a] for a in range(45) if H[a,h]),s.zeros(16))) for h in range(12)];proj[side][fam].append(arr);heat[fam][side].append([enc((hf if fam=='fermion' else hs)*m) for m in arr])
  for part in transport:transport[part][side]=[]
  for j in range(2):
   pol=[a+b for a,b in zip(proj[side]['fermion'][j],proj[side]['scalar'][j])];placement[side].append(list(map(enc,pol)))
   transport['chi4'][side].append([enc(s.zeros(16)) for _ in range(12)]);transport['log3over2'][side].append([enc(-m) for m in pol])
   transport['fixed'][side].append([enc(dec(aux)-hf*f-hs*z) for aux,f,z in zip(d['aux_current'][side][j],proj[side]['fermion'][j],proj[side]['scalar'][j])])
 return {'heat_fixed':heat,'placement_log_coefficient':placement,'relative_transport':transport,'family_left':d['family_left'],'family_right':d['family_right']}
