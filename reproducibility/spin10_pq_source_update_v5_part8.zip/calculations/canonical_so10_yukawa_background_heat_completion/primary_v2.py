"""YBH1 literal two-endpoint heat variation and critical sphere/radial integral."""
from data_v2 import *
tick=begin('primary');d=packed(HERE/'primary_inputs.json.gz');sigma=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];g=[s.kronecker_product(sigma[1],z) for z in sigma]+[s.kronecker_product(sigma[0],s.eye(2))];L=s.diag(1,1,0,0);R=s.eye(4)-L;I2=s.eye(2);T=s.diag(1,2);A=s.kronecker_product(L,T)-s.kronecker_product(R,T.T);B=s.kronecker_product(R,T)-s.kronecker_product(L,T.T);outer=s.kronecker_product(R,I2);inner=s.kronecker_product(L,I2);rho=s.Matrix([[0,1],[-1,0]])
k=s.symbols('k0:4');Q=sum(z*z for z in k);slash=sum((z*v for z,v in zip(g,k)),s.zeros(4));sl=s.kronecker_product(slash,I2);q,t,alpha=s.symbols('q t alpha',positive=True)
def avg(z):
 out=0
 for powers,v in s.Poly(s.expand(z),*k).terms():
  if not v:continue
  assert sum(powers)==2
  if sorted(powers)==[0,0,0,2]:out+=v/4
 return s.simplify(out)
def coefficient(M,target):
 ij=next(ij for ij,z in target.todok().items() if z);v=s.simplify(M[ij]/target[ij]);zero(M-v*target);return v
units=[];controls=[];positions=0
for mu in range(4):
 # Direct differentiation of each connection Laplacian at constant A_mu.
 nx=s.I*k[mu]*s.eye(8)-s.I*alpha*A;dpx=tidy(s.diff(-nx*nx,alpha).subs(alpha,0));zero(dpx+2*k[mu]*A)
 nd=s.I*k[mu]*s.eye(8)-s.I*alpha*B;dpd=tidy(s.diff(-nd*nd,alpha).subs(alpha,0));zero(dpd+2*k[mu]*B)
 ns=-s.I*k[mu]*I2+alpha*rho;dps=tidy(s.diff(-ns*ns,alpha).subs(alpha,0));zero(dps-2*s.I*k[mu]*rho)
 target=s.kronecker_product(g[mu]*L,T.T);fleft=-outer*(-dpx)*(-s.I*sl)*inner;fright=-outer*(-s.I*sl)*(-dpd)*inner;full=(fleft+fright).applyfunc(avg)
 wrong=(-outer*((-dpx)*(-s.I*sl)+(-s.I*sl)*(-dpx))*inner).applyfunc(avg);controls.append(nz(wrong-full));assert controls[-1]>0
 scalar=(-s.kronecker_product(R*(-s.I*slash)*L,-2*dps)).applyfunc(avg);targetS=s.kronecker_product(g[mu]*L,rho)
 cf=coefficient(full,target);cs=coefficient(scalar,targetS);zero(fleft.applyfunc(avg)-full/2);zero(fright.applyfunc(avg)-full/2)
 # Radial moment is calculated from the actual normalized D4 measure.
 rad=s.integrate(s.exp(-4*t*q),(q,0,s.oo));assert simp(t*rad-s.Rational(1,4))==0
 units.append((simp(cf*t*rad),simp(cs*t*rad)));positions+=2*8**2
assert len(set(units))==1;uf,us=units[0]
# Frullani heat difference from positive exponent integration, not a scaleless rule.
a=s.Symbol('a',positive=True);logratio=s.integrate(1/a,(a,4,6));zero(s.Matrix([[logratio-s.log(s.Rational(3,2))]]))
assert s.sympify(d['fermion_phase'])==s.I and s.sympify(d['scalar_phase'])==2 and d['selfenergy_unit']=='-1'
hf=simp(uf/(s.sympify(d['fermion_phase'])*s.Rational(1,2)));hs=simp(us/(s.sympify(d['scalar_phase'])*s.Rational(1,4)))
out=assemble(d,hf,hs);out.update({'method':'explicit_connection_Laplacian_two_endpoint_derivatives_sphere_and_positive_radial_integral','heat_fermion_absolute_unit':str(uf),'heat_scalar_absolute_unit':str(us),'heat_fermion_pole_ratio':str(hf),'heat_scalar_pole_ratio':str(hs),'inverse_placement_log':str(logratio),'spin_Lorentz_positions':positions,'wrong_right_carrier_fixture_changes':controls,'one_endpoint_omission_is_half':True,'scalar_routing':'scalar_momentum_minus_k_from_actual_YGV_Euler','scalar_heat_definition':'DECLARED_MINIMAL_CONNECTION_LAPLACIAN_OF_ACTUAL_H_SCALAR_ACTION','physical_action_changed':False});finish('primary',out,tick)
