"""YBH1 compare derived heat transport before the late kinetic/current test."""
from data_v2 import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables_v2.json.gz');R=packed(HERE/'replay_tables_v2.json.gz');late=packed(HERE/'validation_control_inputs.json.gz');inp=packed(HERE/'primary_inputs.json.gz')
for k in ['heat_fermion_absolute_unit','heat_scalar_absolute_unit','heat_fermion_pole_ratio','heat_scalar_pole_ratio']:
 assert simp(s.sympify(P[k])-s.sympify(R[k]))==0,k
assert simp(s.sympify(P['inverse_placement_log'])-s.log(s.Rational(3,2)))==0 and simp(s.sympify(R['inverse_placement_log'])-s.log(s.Rational(3,2)))==0
assert s.sympify(P['heat_fermion_absolute_unit'])==-s.I/4 and s.sympify(P['heat_scalar_absolute_unit'])==s.Rational(1,4)
assert s.sympify(P['heat_fermion_pole_ratio'])==-s.Rational(1,2) and s.sympify(P['heat_scalar_pole_ratio'])==s.Rational(1,2)
positions=0
for fam in ['fermion','scalar']:
 for side in ['left','right']:
  for pp,rr in zip(P['heat_fixed'][fam][side],R['heat_fixed'][fam][side]):
   for a,b in zip(pp,rr):zero(dec(a)-dec(b));positions+=256
for side in ['left','right']:
 for pp,rr in zip(P['placement_log_coefficient'][side],R['placement_log_coefficient'][side]):
  for a,b in zip(pp,rr):zero(dec(a)-dec(b));positions+=256
for part in ['chi4','log3over2','fixed']:
 for side in ['left','right']:
  for pp,rr in zip(P['relative_transport'][part][side],R['relative_transport'][part][side]):
   for a,b in zip(pp,rr):zero(dec(a)-dec(b));positions+=256
assert positions==73728
for key in ['family_left','family_right']:
 for a,b,c in zip(P[key],R[key],late[key]):zero(dec(a)-dec(b));zero(dec(a)-dec(c))
H=dec(inp['H_new']);T=list(map(dec,late['Tminus']));TH=[tidy(sum((H[a,h]*T[a] for a in range(45) if H[a,h]),s.zeros(16))) for h in range(12)]
current={part:{} for part in ['chi4','log3over2','fixed']};rem={part:{} for part in current};counts={part:{} for part in current};ncompare=0;totalrem=0
for part in current:
 for j,tag in enumerate(['Y10','Y126']):
  current[part][tag]={};rem[part][tag]={};counts[part][tag]={}
  for side in ['left','right']:
   cc=[];rr=[];C=dec(late['kinetic'][part][tag][side]);nonzero=0
   for h in range(12):
    L=tidy(dec(late['old_current'][part][tag][side][h])+dec(P['relative_transport'][part][side][j][h]));charge=TH[h] if side=='left' else -TH[h].T
    residual=tidy(s.I*L-C*charge);zero(C*charge-charge*C);cc.append(enc(L));rr.append(enc(residual));nonzero+=nz(residual);ncompare+=256;zero(L+L.H)
   current[part][tag][side]=cc;rem[part][tag][side]=rr;counts[part][tag][side]=nonzero;totalrem+=nonzero
assert ncompare==36864
for part in current:
 for tag in current[part]:
  for a,b in zip(current[part][tag]['left'],current[part][tag]['right']):zero(dec(a).T+dec(b))
controls={}
def count_arrays(rows):return sum(nz(dec(z)) for a in rows.values() for arr in a for z in arr)
controls['omit_fermion_heat']=count_arrays(P['heat_fixed']['fermion']);controls['omit_scalar_heat']=count_arrays(P['heat_fixed']['scalar']);controls['omit_one_fermion_endpoint_heat']=controls['omit_fermion_heat'];controls['omit_one_scalar_endpoint_heat']=controls['omit_scalar_heat'];controls['reverse_scalar_momentum_routing']=controls['omit_scalar_heat'];controls['omit_inverse_placement_change']=count_arrays(P['placement_log_coefficient']);controls['omit_auxiliary_dimensional_reference']=count_arrays(inp['aux_current']);controls['extra_open_half']=controls['omit_inverse_placement_change']
for k,v in controls.items():assert v>0
for obj in [P,R]:assert obj['one_endpoint_omission_is_half'] and len(obj['wrong_right_carrier_fixture_changes'])==4 and all(obj['wrong_right_carrier_fixture_changes']) and not obj['physical_action_changed'] and not obj['physical_scheme_adopted']
status='QUALIFIED_SELECTED_YUKAWA_BACKGROUND_HEAT_COMPLETION_AND_KINETIC_COMPATIBILITY' if totalrem==0 else 'QUALIFIED_SELECTED_YUKAWA_BACKGROUND_HEAT_COMPLETION_WITH_NONZERO_KINETIC_REMAINDER'
# The new local background term has an explicit A_H factor; old A_H=0
# four-projection coefficients are preserved by field degree, not re-integrated.
family={'status':status,'selected_background_current':current,'kinetic_remainders':rem,'relative_background_transport':P['relative_transport'],'general_family_left':P['family_left'],'general_family_right':P['family_right'],'extension_of_previous_A0_family':'ADD_ONLY_NEW_A_H_PP_RELATIVE_TERM; OLD_A0_COEFFICIENTS_UNCHANGED','new_term_vanishes_at_A_H_zero':True,'full_background_quantum_source_equivalence_or_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(family,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_background_family.json.gz').open('xb') as f:f.write(blob)
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':status,'elapsed_after_imports':time.perf_counter()-tick,'heat_and_transport_color_positions_compared':positions,'selected_kinetic_current_positions_compared':ncompare,'kinetic_remainder_nonzero_counts':counts,'total_remainder_nonzero':totalrem,'heat_fermion_pole_ratio':P['heat_fermion_pole_ratio'],'heat_scalar_pole_ratio':P['heat_scalar_pole_ratio'],'inverse_placement_log':'log(3/2)','scalar_supports':328,'H_directions':12,'general_family_polynomial_positions_retained':36,'negative_control_changed_positions':controls,'generic_wrong_right_heat_sensitive_all_four_Lorentz_directions':True,'old_A0_four_projection_coefficients_preserved_by_background_field_degree':True,'complete_selected_marginal_YdagY_background_local_member_qualified':True,'full_nonexceptional_background_amplitude_or_quantum_Slavnov_qualified':False,'all_gauge_g3_background_terms_qualified':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','family_sha256':sha256(blob).hexdigest(),'family_raw_sha256':sha256(raw).hexdigest(),'primary_tables_sha256':digest(HERE/'primary_tables_v2.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables_v2.json.gz')},sort_keys=True),flush=True)
