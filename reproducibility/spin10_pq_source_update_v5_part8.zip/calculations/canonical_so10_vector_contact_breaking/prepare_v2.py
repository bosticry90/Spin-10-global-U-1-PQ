"""VCT1 immutable inputs,sources,readiness and current byte preflight."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PRED=CAL/'canonical_so10_scalar_matter_primitive'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/vector-contact-breaking-v1-2026-10-23')
BASE='935b56492a31fc694917c527e8223fe9c5c727fc';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(HERE/'preparation.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert read(CONTROL/'readiness_result.json')['readiness_command_executed_this_goal_turn'] and read(CONTROL/'readiness_result.json')['native_exit']==0
events=[json.loads(v) for v in (CONTROL/'readiness.jsonl').read_text(encoding='utf-8').splitlines()];assert [v['exit_code'] for v in events if v['event']=='step_finished']==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested']
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==31739 and old==(CONTROL/'old_git_tree.txt').read_bytes()
failed=read(HERE/'primary_capture.json');assert failed==read(CONTROL/'primary_full_capture.json') and failed['execution_state']=='FAILED' and failed['exit_code']==1 and not failed['calculation_completed'] and failed['post_run_observations_qualified']
assert not (HERE/'primary_tables.json.gz').exists() and not (HERE/'replay_capture.json').exists() and not (HERE/'verify_capture.json').exists() and not (HERE/'validation_receipt.json').exists()
for n in ['preparation.json','preparation_capture.json','primary_capture.json','controller_failure.json']:add(HERE/n)
for n in ['primary_full_capture.json','preparation_full_capture.json','raw_contact_diagnostic.py','raw_contact_diagnostic_capture.json','raw_contact_diagnostic_output.json']:add(CONTROL/n)
diag=read(CONTROL/'raw_contact_diagnostic_output.json');assert diag['all_metric_equal'] and diag['raw_nonreal_count']==956 and diag['canonical_positions_per_mu']==[3530]*4
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V530.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:add(ROOT/n)
for folder,names in [
 ('canonical_so10_ghost_triangle_field_insertion',['primary_tables.json.gz','replay_tables.json.gz','qualified_reference_inputs.json.gz','validation_receipt.json','DERIVATION.md']),
 ('canonical_so10_yukawa_carrier_transport',['primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json']),
 ('canonical_so10_matter_degreezero_support',['primary_tables.json.gz','replay_tables.json.gz','support_tables.json.gz','validation_receipt.json','DERIVATION.md']),
 ('canonical_so10_sterile_matter_action',['ACTION_V1.md','validation_receipt.json'])]:
 for n in names:add(CAL/folder/n)
add(ROOT/'tools/portable_dh_v1/inputs.json.gz')
for n in ['CONTINUATION_V2.md','data_v2.py','primary_v2.py','replay_v2.py','verify_v2.py','prepare_v2.py','run_v2.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
with (CONTROL/'v2_prelaunch_preflight.json').open('xb') as out,(CONTROL/'v2_prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
d=read(CONTROL/'v2_prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and d['state_sha256']==STATE and d['files_written']==0 and not d['active_A10_M08_python_processes']
for n in ['v2_prelaunch_preflight.json','v2_prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation_v2.json',{'schema':'VCT1_PREPARATION_V2','input_sha256':dict(sorted(bind.items())),'base_commit':BASE,'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('VCT1_V2_FROZEN',len(bind),'bindings',flush=True)
