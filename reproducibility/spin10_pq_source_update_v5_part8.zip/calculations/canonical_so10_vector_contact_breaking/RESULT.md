# VCT1: the complete vector contact family is measured and nonzero

Receipt SHA256
`0f87424162c1861203cd866280fe3e44ccf383e8ca2bf8f7b6ffc58324c3e358`:
QUALIFIED_VECTOR_CONTACT_MATTER_BREAKING_FAMILY,
ACTION_DERIVED_CONTACT_COEFFICIENT_MEASURED. Scientific acceptance
NOT_PERFORMED. State113/authority34of39 unchanged.

## Complete support reduction and the measured family

Both routes independently partition all42 remaining MDS1 internal-ghost
cBPP witnesses by the actual external-vector insertion:

| Ordered response family | g4 profiles | g3 profiles | Total |
| --- | ---: | ---: | ---: |
| Fermion edge | 4 | 2 | 6 |
| Ghost edge | 8 | 4 | 12 |
| Physical vector edge | 8 | 4 | 12 |
| Gauge-fixing mixed vector/auxiliary edge | 8 | 2 | 10 |
| Quartic aCBB contact | 2 | 0 | 2 |
| Total | 30 | 12 | 42 |

The disjoint union reproduces the entire qualified witness set exactly.
The inverse-Hessian response supplies a common calculation organization,
with operator order preserved;it does not supply the other families'
integrated coefficients. Ghost-edge insertions retain INTERNAL ghost
derivatives and the UC jet. Vector-edge insertions retain full BB/BL/LB
responses. Neither may inherit the scalar kernel by analogy.

Both contact orientations are now calculated from the actual gauge-fixing
action. Forty vector profiles remain unmeasured. No CFC1 counterterm or
MSP1 target table is read to set the quantum coefficient;those structured
targets are denied after input-byte authentication. The contact's result
is a necessary input for future full vector assembly,not a standalone
restoration test or an inferred cancellation.

## Action-derived coefficient and normalization

Canonicalizing the antighost before the ghost gives3530 contact density
coefficients in each Lorentz component,14120 literal positions in total.
All four metric-normalized tables agree exactly. The two commuting vector
derivatives retain both assignments,including the factor2 at repeated
indices. In the declared raw complex field coordinates,956 coefficients
are not individually real;their correct transport is essential.

With raw q_ij,rs a_i C_j B_r.B_s,g10² stripped,let Q_chart be GTT1's
fixed gauge/ghost chart,R=Q_chart^-1 and UL its dual antighost/auxiliary
map. The actual ghost-Green identity is Q_chart Gca UL^-T=I. Primary
inverts Q_chart;replay obtains R from Gca UL^-T. Both agree completely.

The independently derived finite moments in16pi² units are

 I0=FP integral hatk²/(k²+m²)^3=-1/2,
 J delta_mu,nu=FP integral hatk² kbar_mu kbar_nu/(k²+m²)^4
              =-delta_mu,nu/12.

They follow from h Gamma(epsilon)/4 and h Gamma(epsilon)/24 before
h=-2epsilon. The weighted hatted angular moment is essential;an
unweighted four-dimensional average would give the wrong finite term.
The temporary mass only rearranges the local UV calculation,not a
physical mass or an adopted infrared prescription. Both contact vector
endpoints are barred;no closed full-D vector trace is introduced.

Set W=eta_H PH+xi PM,F=I0 I+J(W-I)=-(5I+W)/12,and

 G_r=sum_bt R_rb F_tb T_t, A_i=sum_a UL_ia T_a.

The complete left contact current,with common g10^4/(16pi²) and barred
gamma_mu stripped,is

 L_cd=sum_ijrs q_ij,rs R_jc
       (R_sd [G_r,A_i]+R_rd [G_s,A_i]).

The commutator is DERIVED by adding both actual E placements:their raw
spinor phases are+1 and-1. No antisymmetry of q is assumed. Primary keeps
the ordered products and checks explicit barred/hat Clifford chains with
noncommuting color witnesses. Replay derives the odd-vertex cumulants and
Schwinger moments,polarizes commuting vector monomials,then contracts the
actual i f_ba^e T_e. The inherited relative Wick conversion is the same
for the two Lorentz slots of aC(partial B) and aCBB;the Fourier derivative
factor in the former is absent in the latter. The literal contact
coefficient is retained. This is distinct from the LambdaBB contour
factor needed by the still-unmeasured mixed family.

The total has19648 nonzero entries in EACH chirality. The gate compares
all1,036,800 c/vector/color positions,including zeros. Actual U=-T.T
gives right=-left.T;left is anti-Hermitian. The3120 nonzero adjoint Lie
coefficients reconstruct the entire matrix answer. All990 actual
generator commutators match the bound structure constants,and all12
residual-H coefficient covariance tests vanish. These are bounded tensor
tests,not a full local-background QAP theorem. The family extension is I3
with no extra3 or Nambu half. No physical parameter was evaluated.

## Controls and preserved input-assumption failure

Deleting either endpoint orientation changes27919 left positions.
Deleting the second vector-derivative assignment changes16576. An extra
Nambu half,ghost-order reversal,wrong right-transpose sign,unweighted
angular average or longitudinal omission changes19648 each. These tests
share the same result and are not independent experiments. At unit widths,
the complete expression agrees with I0 times its unweighted color
contraction;that specialization is a counterfactual check,not a gauge
choice. The angular/longitudinal controls correctly coincide there.

Original primary failed native1 before a table or RESULT. Its extra
assertion required raw coordinate coefficients to be individually real.
The separately preserved full diagnostic proves all four metric tables
agree,but identifies956 complex raw coefficients. The failed condition
was a misplaced representation assumption,not a physical reality failure.
Replay and verifier had not launched. V2 removes only that assertion and
versions authentication imports. Final transported Hermiticity,chirality,
covariance,complete coefficient agreement and every control remain intact.
No coefficient,action,physical input,phase or radial requirement changes.
The original source/copy/captures/controller failure and the full diagnostic
are preserved;no failed worker is relabeled PASS.

Completed P_v2/R_v2/V_v2 native0 at66.7683765/18.0806308/4.9621838s;
35/10/4 samples,private maxima232108032/99721216/181374976 bytes.
Failed primary4 samples,max73932800 bytes;diagnostic native0,4 samples,
max73334784 bytes. These are sampled maxima,not continuous peaks.
600s/8GiB sampled/350MiB launch floor/16MiB packet bounds held. Fifteen
frozen source copies;239 initial,264 V2 and272 validation bindings.

Primary packed/raw SHA256:
`a790ecae8a5d183fbe465ca03fb5a79910121100c9aae6402b0f54d356a3de7d` /
`08cd5b251ae91e734988ae0930803e0fbc0e9df7041e20d34518e95b7f1ca26a`.
Replay packed/raw SHA256:
`dfd6d80fd215c00e3e8e6c799dba6519b12ae001647b22c41f64a3723b0720d8` /
`641a289a9ef6c73a5d85ac74d8a96f08531c86e6a4dca3cda5609e97597ff7fe`.

Fresh E4 readiness command EXECUTED THIS goal turn,without--fresh
historical scientific replay:steps0,0,0,0,0,2. V2 authenticates reuse
of that command. New byte preflights/native resources observed. Custody
exit2/seven remains NOTPASS. No original tracked evidence or state changed.

## Significance and next action

The vector calculation now has a complete five-family organization and
one fully measured nonzero family. Next calculate the six fermion-edge
profiles through the ACTUAL gauge derivative of the mixed P/S resolvent.
Derive both endpoint phases and full-dimensional contractions before
reusing ASB1's moments;do not copy its scalar color programs. Preserve the
ordinary g4 and auxiliary g3 components separately,including any collective
auxiliary zero only after complete pairing. The other34 profiles then
require ghost and physical/mixed vector responses with their proper
derivative placements and Wick factors. Compare to fixed CFC1 images only
after complete relevant quantum assembly.

Track B demonstrates actual-action polarization,chart-aware reality,
separate Gamma/Schwinger and matrix/Lie derivations. The failed raw-real
assumption remains a meaningful methodological error. Action,data,charts,
exact-ring arithmetic,software and AI authorship are shared;there is no
independent scientist,proof-kernel or empirical validation.

Whole vector restoration,full coupled source/Euler prescription,QAP,
products,measure/phase,physical chiral scheme,massiveC1,E5/A5 and physical
unification remain unqualified. SMP1's scalar finite family is unchanged;
all free finite constants remain distinct and unfixed. Both adverse scalar
benchmarks,quartetFAIL,flavor pause,HB1/C5 blocks and custody2/seven persist.
No foundation,scheme,benchmark or authority adopted. No agents,new branch/
worktree,publication,outreach or push. Whole investigation active/incomplete.
