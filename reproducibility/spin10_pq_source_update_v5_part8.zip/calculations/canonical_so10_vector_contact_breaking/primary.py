"""VCT1 literal contact Hessian, explicit Clifford and ordered color sewing."""
from data import *
from itertools import permutations
start=begin('primary');g=sy.Symbol('g10');raw=[defaultdict(lambda:Z) for _ in range(4)];nraw=Counter()
for row in packed(ROOT/'tools/portable_dh_v1/inputs.json.gz')['gauge_fixing_density']:
 w=row['word'];bb=[n for n in w if n.startswith('B')];aa=[n for n in w if n.startswith(('bar','ub'))];cc=[n for n in w if n.startswith('C')]
 if len(w)!=4 or len(bb)!=2 or len(aa)!=1 or len(cc)!=1:continue
 assert not any('__' in n for n in w)
 r,mu=map(int,bb[0][1:].split('_'));t,nu=map(int,bb[1][1:].split('_'));assert mu==nu
 a=int(aa[0][3:] if aa[0].startswith('bar') else aa[0][2:]);c=int(cc[0][1:]);sign=-1 if w.index(cc[0])<w.index(aa[0]) else 1
 z=sy.expand(sign*[1,-1,-1,-1][mu]*sy.sympify(row['coefficient'],locals={'g10':g,'eta_H':WH,'xi':WM})/g**2);assert not z.has(g)
 co=Q(str(z));key=(a,c,min(r,t),max(r,t));raw[mu][key]=add(raw[mu][key],co);nraw[mu]+=1
raw=[{k:v for k,v in d.items() if v} for d in raw]
assert all(d==raw[0] for d in raw[1:]);assert all(v==conj(v) for v in raw[0].values())
qrows=raw[0]
G=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/primary_tables.json.gz');chart=dec(G['C3_chart']);Qi=inv(chart);UL=dec(G['raw_aux_map']);CG=dec(G['raw_Gca']);zero(minus(mul(mul(chart,CG),trans(inv(UL))),ident(45)))
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];HF=dec(Y['H_new']);PH=mul(HF,trans(HF));W=plus(scale(ident(45),Q('xi')),scale(PH,Q('eta_H-xi')))
# Each color slot is separately retained; both hatted and vector-bar ends
# are checked before integration. Noncommuting Pauli colors test ordering.
pa=[sy.Matrix([[0,1],[1,0]]),sy.Matrix([[0,-sy.I],[sy.I,0]]),sy.diag(1,-1)]
g4=[sy.kronecker_product(pa[1],v) for v in pa]+[sy.kronecker_product(pa[0],sy.eye(2))];gg=[sy.kronecker_product(v,pa[2]) for v in g4]+[sy.kronecker_product(sy.eye(4),v) for v in pa[:2]]
ch=sy.prod(gg[:4]);PL=(sy.eye(8)+ch)/2;PR=sy.eye(8)-PL;h0,h1=sy.symbols('h0 h1');hh=sy.kronecker_product(h0*gg[4]+h1*gg[5],sy.eye(2));hsq=h0*h0+h1*h1
tr,ta=pa[0],pa[2];Ar=sy.kronecker_product(PL,tr)+sy.kronecker_product(PR,-tr.T);Aa=sy.kronecker_product(PL,ta)+sy.kronecker_product(PR,-ta.T);At=sy.kronecker_product(PR,ta)+sy.kronecker_product(PL,-ta.T)
for mu in range(4):
 gm=sy.kronecker_product(gg[mu],sy.eye(2));ec=(-sy.I*gm*Ar)*(-sy.I*hh)*(-hh*Aa);es=(At*hh)*(-sy.I*hh)*(-sy.I*gm*Ar)
 assert not (ec-hsq*gm*Ar*Aa).applyfunc(sy.expand).todok() and not (es+hsq*gm*Aa*Ar).applyfunc(sy.expand).todok()
eps,h=sy.symbols('epsilon h');I0=sy.limit((h*sy.gamma(1+eps)/(4*eps)).subs(h,-2*eps),eps,0);J=sy.limit((h*sy.gamma(1+eps)/(24*eps)).subs(h,-2*eps),eps,0)
units=[sy.sympify(v) for v in G['cumulant_units']];phases=[sy.simplify(units[0]*(-1)*(-sy.I)*(-sy.I)),sy.simplify(units[1]*(1)*(-sy.I)*(-sy.I))];assert phases==[1,-1]
qr=rowmaps(Qi);basis={};first={}
for side,ts in [('left',T),('right',U)]:
 basis[side]={};first[side]={};anti=gens(UL,ts)
 for tag,weight in [('I',ident(45)),('W',W)]:
  vc=mul(Qi,trans(weight));vg=gens(vc,ts)
  @lru_cache(maxsize=2025)
  def pair(r,a):return mul(vg[r],anti[a]),mul(anti[a],vg[r])
  ec={};es={};one={}
  for (a,c,r,t),co in qrows.items():
   for which,(inside,outside) in enumerate([(r,t),(t,r)]):
    ma,mb=pair(inside,a)
    for ce,x in qr[c]:
     for de,y in qr[outside]:
      z=prod(co,prod(x,y));putm(ec,(ce,de),ma,prod(z,Q(str(phases[0]))));putm(es,(ce,de),mb,prod(z,Q(str(phases[1]))))
      if which==0:putm(one,(ce,de),minus(ma,mb),z)
  basis[side][tag]={'E_C':table(ec),'E_S':table(es)};first[side][tag]=table(one)
  print('STAGE CONTACT_DIRECT',side,tag,flush=True)
def total(side,tag):return tablinear(fromtable(basis[side][tag]['E_C']),fromtable(basis[side][tag]['E_S']),ONE,ONE)
ii={s:total(s,'I') for s in basis};ww={s:total(s,'W') for s in basis};answer={s:tablinear(ii[s],ww[s],Q(str(I0-J)),Q(str(J))) for s in basis}
ec=tablinear(fromtable(basis['left']['I']['E_C']),fromtable(basis['left']['W']['E_C']),Q(str(I0-J)),Q(str(J)));es=tablinear(fromtable(basis['left']['I']['E_S']),fromtable(basis['left']['W']['E_S']),Q(str(I0-J)),Q(str(J)))
one=tablinear(fromtable(first['left']['I']),fromtable(first['left']['W']),Q(str(I0-J)),Q(str(J)))
bad=tablinear(ii['left'],ww['left'],Q(str(I0-I0/4)),Q(str(I0/4)));nol=tablinear(ii['left'],{},Q(str(I0)),Z)
controls={'omit_E_C':tabnz(ec),'omit_E_S':tabnz(es),'omit_second_B_assignment':tabnz(tabminus(answer['left'],one)),'extra_Nambu_half':tabnz(answer['left']),'reverse_ghost_order':tabnz(answer['left']),'wrong_right_transpose_sign':tabnz(answer['right']),'unweighted_angular_average':tabnz(tabminus(answer['left'],bad)),'drop_longitudinal':tabnz(tabminus(answer['left'],nol))}
# A partition is a reduction of the existing complete support,not a new loop.
support=packed(CAL/'canonical_so10_matter_degreezero_support/support_tables.json.gz')['partitions']['cBPP']['remaining_internal_ghost_candidates'];groups=defaultdict(list)
for st in support:
 w=json.loads(st);v=[json.loads(n) for n in w[0]];orig=[x[0] for x in v]
 if len(v)==3:key='contact'
 elif orig.count('PPB')==2:key='fermion_edge'
 elif 'PHY' in orig:key='physical_vector_edge'
 elif any(x[0]=='GF' and sorted(k for k,j in x[1])==['B','B','L'] for x in v):key='GF_mixed_edge'
 else:key='ghost_edge'
 groups[key].append(st)
assert len(support)==42 and len(groups['contact'])==2
finish('primary',{'method':'literal_contact_Hessian_full_Clifford_Gamma_ordered_generators','raw_density':[[*k,textq(v)] for k,v in sorted(qrows.items())],'literal_rows_per_mu':dict(nraw),'all4_metric_components_equal':True,'Qi':enc(Qi),'UL':enc(UL),'W':enc(W),'I0':str(I0),'J':str(J),'endpoint_phases':list(map(str,phases)),'spin_chain_remainders':'0','basis_orientations':basis,'first_assignment':first,'left':table(answer['left']),'right':table(answer['right']),'unweighted_left':table(ii['left']),'weighted_left':table(ww['left']),'controls':controls,'partition':dict(groups),'supported_witnesses':groups['contact'],'coupling_order':4,'newly_measured_profiles':2,'remaining_vector_profiles_unmeasured':40,'unit_width_control_is_counterfactual_not_adopted':True},start)
