"""VCT1 complete coefficient,model symmetry and support-family gate."""
from data_v2 import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
for key in ['raw_density','literal_rows_per_mu','all4_metric_components_equal','Qi','UL','W','I0','J','endpoint_phases','spin_chain_remainders','left','right','unweighted_left','weighted_left','partition','supported_witnesses','coupling_order','newly_measured_profiles','remaining_vector_profiles_unmeasured']:assert P[key]==R[key],key
assert P['I0']=='-1/2' and P['J']=='-1/12' and P['endpoint_phases']==['1','-1'] and P['all4_metric_components_equal'] and P['spin_chain_remainders']=='0'
assert not P['quantum_coefficients_assigned_from_counterterm'] and not R['quantum_coefficients_assigned_from_counterterm'] and not P['extra_family_or_Nambu_half'] and not R['extra_family_or_Nambu_half']
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));HF=dec(Y['H_new']);G=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/replay_tables.json.gz');Qi=dec(P['Qi']);UL=dec(P['UL'])
zero(minus(mul(dec(G['C3_chart']),Qi),ident(45)));zero(minus(mul(mul(dec(G['C3_chart']),dec(G['raw_Gca'])),trans(inv(UL))),ident(45)))
L=fromtable(P['left']);RR=fromtable(P['right']);ii=fromtable(P['unweighted_left']);ww=fromtable(P['weighted_left']);compared=0
for c in range(45):
 for d in range(45):
  l=L.get((c,d),Mat(16,16));r=RR.get((c,d),Mat(16,16));zero(plus(r,trans(l)));zero(plus(l,trans(star(l))));zero(minus(at_one(l),scale(ii.get((c,d),Mat(16,16)),Q('-1/2'))));compared+=2*256
  for v in l.d.values():assert all(k[0]>=0 and k[1]>=0 for k,z in v)
f=defaultdict(list)
for a,b,e,z in packed(CAL/'canonical_so10_ghost_triangle_field_insertion/qualified_reference_inputs.json.gz')['reference_fields']['plane_f']:f[a,b].append((e,Q(z)))
for a in range(45):
 for b in range(a+1,45):
  m=minus(mul(T[a],T[b]),mul(T[b],T[a]));rhs=Mat(16,16)
  for e,z in f[a,b]:rhs=plus(rhs,scale(T[e],prod(II,z)))
  zero(minus(m,rhs))
co={(c,d,e):Q(z) for c,d,e,z in R['Lie_coefficients']};rebuilt={}
for (c,d,e),z in co.items():putm(rebuilt,(c,d),T[e],z)
for key in set(L)|set(rebuilt):zero(minus(L.get(key,Mat(16,16)),rebuilt.get(key,Mat(16,16))))
hc=[]
for h in range(12):
 fh=defaultdict(lambda:Z)
 for a in range(45):
  v=HF.d.get((a,h),Z)
  if v:
   for b in range(45):
    for e,z in f[a,b]:fh[b,e]=add(fh[b,e],prod(v,z))
 direct=defaultdict(list);inverse=defaultdict(list)
 for (a,b),z in fh.items():
  if z:direct[a].append((b,z));inverse[b].append((a,z))
 var=defaultdict(lambda:Z)
 for (c,d,e),z in co.items():
  for u,v in direct[e]:var[c,d,u]=add(var[c,d,u],prod(z,v))
  for a,v in inverse[c]:var[a,d,e]=sub(var[a,d,e],prod(z,v))
  for a,v in inverse[d]:var[c,a,e]=sub(var[c,a,e],prod(z,v))
 hc.append(sum(bool(v) for v in var.values()))
assert not any(hc)
M=packed(CAL/'canonical_so10_matter_degreezero_support/support_tables.json.gz')['partitions']['cBPP']['remaining_internal_ghost_candidates'];flat=[v for group in P['partition'].values() for v in group];assert len(flat)==len(set(flat))==42 and set(flat)==set(M) and len(P['supported_witnesses'])==2
groups={k:{'profiles':len(v),'g_orders':dict(Counter(str(json.loads(w)[5]) for w in v))} for k,v in P['partition'].items()}
assert set(groups)=={'fermion_edge','ghost_edge','physical_vector_edge','GF_mixed_edge','contact'}
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_VECTOR_CONTACT_MATTER_BREAKING_FAMILY','disposition':'ACTION_DERIVED_CONTACT_COEFFICIENT_MEASURED','elapsed_after_imports':time.perf_counter()-start,'profiles_measured':2,'remaining_vector_profiles_unmeasured':40,'complete_vector_partition':groups,'coefficient_positions_compared':compared,'left_nonzero_positions':tabnz(L),'right_nonzero_positions':tabnz(RR),'I0':P['I0'],'J':P['J'],'endpoint_phases':P['endpoint_phases'],'raw_contact_positions_per_mu':P['literal_rows_per_mu'],'canonical_raw_contact_coefficients':len(P['raw_density']),'all4_metric_components_equal':True,'all12_H_coefficient_remainders':hc,'right_plus_left_transpose_remainder':0,'antiHermitian_left_remainder':0,'unit_width_diagnostic_remainder':0,'controls':P['controls'],'Lie_coefficients_nonzero':len(co),'coupling_order':4,'extra_family_or_Nambu_half':False,'quantum_coefficients_assigned_from_counterterm':False,'whole_vector_family_or_full_restoration_QAP_measure_phase_massiveC1_E5A5_unification_qualified':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
