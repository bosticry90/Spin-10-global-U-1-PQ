"""VCT1 polarized density, Berezin/Schwinger units and scalar Lie sewing."""
from data_v2 import *
from itertools import permutations
start=begin('replay');g=sy.Symbol('g10');raw=[defaultdict(lambda:Z) for _ in range(4)];nraw=Counter()
for row in packed(ROOT/'tools/portable_dh_v1/inputs.json.gz')['gauge_fixing_density']:
 w=row['word'];kinds=['B' if z.startswith('B') else 'a' if z.startswith(('bar','ub')) else 'c' if z.startswith('C') else '?' for z in w]
 if Counter(kinds)!=Counter(['B','B','a','c']):continue
 assert not any('__' in z for z in w)
 a=w[kinds.index('a')];c=w[kinds.index('c')];ai=int(a[3:] if a.startswith('bar') else a[2:]);ci=int(c[1:]);bs=[w[i] for i,k in enumerate(kinds) if k=='B'];r,mu=map(int,bs[0][1:].split('_'));t,nu=map(int,bs[1][1:].split('_'));assert mu==nu
 odd=[0 if k=='a' else 1 for k in kinds if k in ['a','c']];sign=(-1)**sum(odd[i]>odd[j] for i in range(2) for j in range(i+1,2))
 coeff=sy.sympify(row['coefficient'],locals={'g10':g,'eta_H':WH,'xi':WM});q2=sy.diff(coeff,g,2).subs(g,0)/2;assert sy.expand(coeff-g**2*q2)==0
 value=Q(str(sy.expand(sign*(1 if mu==0 else -1)*q2)));key=ai,ci,min(r,t),max(r,t);raw[mu][key]=add(raw[mu][key],value);nraw[mu]+=1
raw=[{k:v for k,v in d.items() if v} for d in raw];assert all(d==raw[0] for d in raw[1:]);qrows=raw[0]
# Differentiate each commuting polynomial monomial. A repeated B yields
# exponent2 once,rather than two separately enumerated primary assignments.
directions=[]
for (a,c,r,t),co in sorted(qrows.items()):
 multi=Counter([r,t])
 for external,power in multi.items():
  residual=list((multi-Counter([external])).elements());assert len(residual)==1
  directions.append((a,c,residual[0],external,prod(Q(power),co)))
G=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/replay_tables.json.gz');UL=dec(G['raw_aux_map']);CG=dec(G['raw_Gca']);Qi=mul(CG,trans(inv(UL)));zero(minus(mul(dec(G['C3_chart']),Qi),ident(45)))
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];HF=dec(Y['H_new']);W=plus(scale(ident(45),Q('xi')),scale(mul(HF,trans(HF)),Q('eta_H-xi')))
words=[[[0,6,5,2],[3,4],[7,1]],[[0,6,3,4],[5,2],[7,1]]];units=[]
for ww in words:
 vals=[]
 for order in permutations(range(3)):
  word=sum((ww[i] for i in order),[]);vals.append((-1)**sum(word[i]>word[j] for i in range(8) for j in range(i+1,8)))
 units.append(-sy.Rational(sum(vals),6))
phases=[sy.simplify(units[0]*(-1)*(-sy.I)**2),sy.simplify(units[1]*(+1)*(-sy.I)**2)];assert phases==[1,-1]
eps,h=sy.symbols('epsilon h');D=4-2*eps
schwinger_I=h*sy.gamma(2-D/2)/(2*sy.gamma(3));schwinger_J=h*sy.gamma(2-D/2)/(4*sy.gamma(4))
I0=sy.limit(schwinger_I.subs(h,-2*eps),eps,0);J=sy.limit(schwinger_J.subs(h,-2*eps),eps,0)
f=defaultdict(list)
for b,a,e,z in packed(CAL/'canonical_so10_ghost_triangle_field_insertion/qualified_reference_inputs.json.gz')['reference_fields']['plane_f']:f[b,a].append((e,Q(z)))
ar=rowmaps(UL);qr=rowmaps(Qi);coeff={}
for tag,weight in [('I',ident(45)),('W',W)]:
 gr=rowmaps(mul(Qi,trans(weight)))
 @lru_cache(maxsize=2025)
 def adj(r,i):
  out=defaultdict(lambda:Z)
  for b,x in gr[r]:
   for a,y in ar[i]:
    for e,z in f[b,a]:out[e]=add(out[e],prod(II,prod(x,prod(y,z))))
  return {k:v for k,v in out.items() if v}
 out=defaultdict(lambda:Z)
 for a,c,inside,outside,co in directions:
  for ce,x in qr[c]:
   for de,y in qr[outside]:
    xy=prod(co,prod(x,y))
    for e,z in adj(inside,a).items():out[ce,de,e]=add(out[ce,de,e],prod(xy,z))
 coeff[tag]={k:v for k,v in out.items() if v};print('STAGE CONTACT_LIE',tag,flush=True)
full={k:add(prod(Q(str(I0-J)),coeff['I'].get(k,Z)),prod(Q(str(J)),coeff['W'].get(k,Z))) for k in set(coeff['I'])|set(coeff['W'])};full={k:v for k,v in full.items() if v}
def sew(tab,ts):
 out={}
 for (c,d,e),co in tab.items():putm(out,(c,d),ts[e],co)
 return out
left=sew(full,T);right=sew(full,U);ii=sew(coeff['I'],T);ww=sew(coeff['W'],T)
support=packed(CAL/'canonical_so10_matter_degreezero_support/support_tables.json.gz')['partitions']['cBPP']['remaining_internal_ghost_candidates'];groups=defaultdict(list)
for st in support:
 w=json.loads(st);vv=[json.loads(n) for n in w[0]];bext=next(p[0] for p in w[1] if p[1]=='B');v=vv[bext];types=sorted(k for k,j in v[1])
 if v[0]=='PPB':key='fermion_edge'
 elif v[0]=='PHY':assert types==['B','B','B'];key='physical_vector_edge'
 elif types==['B','B','a','c']:key='contact'
 elif types==['B','B','L']:key='GF_mixed_edge'
 else:assert types==['B','a','c'];key='ghost_edge'
 groups[key].append(st)
assert len(support)==42 and len(groups['contact'])==2
finish('replay',{'method':'polarized_commuting_B_monomials_exterior_order_Schwinger_and_Lie','raw_density':[[*k,textq(v)] for k,v in sorted(qrows.items())],'literal_rows_per_mu':dict(nraw),'all4_metric_components_equal':True,'Qi':enc(Qi),'UL':enc(UL),'W':enc(W),'I0':str(I0),'J':str(J),'endpoint_phases':list(map(str,phases)),'spin_chain_remainders':'0','left':table(left),'right':table(right),'unweighted_left':table(ii),'weighted_left':table(ww),'Lie_coefficients':[[*k,textq(v)] for k,v in sorted(full.items())],'partition':dict(groups),'supported_witnesses':groups['contact'],'coupling_order':4,'newly_measured_profiles':2,'remaining_vector_profiles_unmeasured':40,'unit_width_control_is_counterfactual_not_adopted':True},start)
