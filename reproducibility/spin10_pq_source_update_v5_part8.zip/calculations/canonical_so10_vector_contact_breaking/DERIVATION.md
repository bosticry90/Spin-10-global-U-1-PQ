# VCT1: ordered response and contact sewing before comparison

At zero background,the actual E_hat matter insertion contains P,S,c and
hatted derivatives only;its quantum-B derivative is0. The PPB current is
linear in B. Differentiate the unintegrated internal-ghost GTT triangle
with respect to quantum B,retaining operator order. The inverse identity
delta G=-G(delta K)G in inverse-Hessian units gives changes on the
fermion,ghost and mixed bosonic edges. Split deltaK_bos into physical BBB
and GF LambdaBB terms. The remaining derivative is the GF aCBB contact.
These are five ordered response families. This operation is before local
UV extraction;it is not differentiation of a proved renormalized product
or a variation of the external background/heat generator. No already
integrated one-jet coefficient is asserted to determine the new kernels.

The ghost-edge response has an INTERNAL differentiated ghost. It requires
the full UA/UB/UC jets,unlike the external-C-zero limit at the other
contact endpoint. The vector responses retain the full mixed BB/BL/LB
system. MDS1's separate20 paired external-ghost local zeros are reused;
the42 internal-ghost witnesses must be covered exactly once by the five
responses. No scalar coefficients are copied to the unmeasured responses.

Write the raw,metric-normalized contact density as
g2 q_ij,rs a_i C_j B_r.B_s with unordered r,s,canonical a before C.
Raw ghost reversal changes sign. Differentiating the two commuting B
slots gives both assignments,including2 when r=s. The same density is
verified in all four Lorentz components before covariant metric lifting.
Let Q be the qualified C3 chart,UL the raw auxiliary/antighost map and
R=Q^-1. The qualified ghost identity is Q Gca UL^-T=I. Thus an independent
construction of R is Gca UL^-T;using UL.T instead would be incorrect.

For the spinor current,F=I0 I+J(W-I),define action-derived generators
G_r=sum_bt R_rb F_tb T_t,A_i=sum_a UL_ia T_a. The full contact result is

 L_cd=sum_ijrs q_ij,rs R_jc
       (R_sd [G_r,A_i]+R_rd [G_s,A_i]).

There is no assumed antisymmetry of the contact density. The commutator
comes from adding both actual E orientations. Directly their numerators
are (-i gamma_bar A_b)(-i hatgamma.k)(-hatgamma.k A_a)
=+hatk2 gamma_bar A_b A_a and
(Atilde_a hatgamma.k)(-i hatgamma.k)(-i gamma_bar A_b)
=-hatk2 gamma_bar A_a A_b. Odd-left cumulants and the inherited Nambu
polarization preserve these signs without an extra half. The GF contact
has no Fourier derivative factor;its literal coefficient is retained.
Actual U=-T.T yields right=-left.T after the orientation exchange.

Gaussian moments before h=-2epsilon give
I0=h Gamma(epsilon)/4 ->-1/2,
J=h Gamma(epsilon)/24 ->-1/12
in16pi2 units. Primary Gamma and replay Schwinger derivations retain the
common analytic prefactor,which cannot change this evanescent finite term.
Both physical vector endpoints are barred;the longitudinal term therefore
contains kbar_mu kbar_nu,not a new closed D trace. F=-(5I+W)/12.
The auxiliary mass is only a local UV rearrangement,not a new propagator
mass or physical IR prescription. The bounded off-shell construction and
convergent-remainder argument are authenticated from GTT1.

Primary keeps the two ordered generator products and the two B assignments.
Replay contracts the same polarized vertex with i f_ba^e T_e,using actual
full45 structure constants and independently transported coefficients.
Their total matrices are compared on every c,d,color entry and zero.
This is a quantum coefficient derivation from the fixed action,not a
counterterm exactness solve or an assumption of vector restoration.
