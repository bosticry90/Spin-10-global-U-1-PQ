# VCT1 V2: correct a misplaced raw-coordinate reality assertion

Original primary failed native1 at its raw-real assertion before a
quantum table or RESULT. Replay and verifier never launched. Preserve
all original sources/copies,preparation,complete primary/controller captures
and failure metadata. It is not a physical coefficient FAIL or a PASS.

The separately preserved raw_contact_diagnostic.py/capture/output confirms
3530 coefficients per Lorentz component,all four metric-normalized tables
identical,and956 complex raw-coordinate coefficients. These raw ghost and
field charts are prescribed complex coordinates;raw scalar conjugation
is not their physical real structure. Primary's extra raw-real assertion
was an unjustified representation assumption,not a frozen physical gate.

V2 removes ONLY that assertion. No input value,phase,moment,color rule,
Bose derivative,or Lorentz comparison changes. Final complete right=-left.T,
anti-Hermitian left,all12H coefficient covariance,input-reconstruction and
independent-matrix/Lie agreement remain mandatory. If those fail,preserve
and investigate;do not tune phases or weaken them to obtain cancellation.

Version data/P/R/V/prepare/controller solely to authenticate the expanded
V2 input manifest consistently. Original data helpers/sources unchanged.
No completed quantum worker is repeated. Bind the failed primary and full
raw diagnostic before new computation. Copies of seven V2 sources are
frozen. Fresh read-only byte preflight;the E4 command earlier THIS goal
turn is authenticated reuse,not rerun historical science. Custodyexit2/
seven NOTPASS. Same600s afterimports,8GiB sampled private cap,350MiB launch
floor,16MiB whole packet. Stop first failure,preserve complete evidence.
State113/34of39 unchanged,no agents,branch/worktree,physical scheme or
benchmark adoption,paused-stage activation,publication,outreach or push.
