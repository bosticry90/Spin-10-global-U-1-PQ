from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/vacuum-ghost-matter-companion-v1-2026-10-23')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='691d2884621035d2a8405b34ba73e99ff84b51c2'
assert read(HERE/'validation_receipt_v3.json')['status']=='QUALIFIED_COMPLETE_EXTRA_GF_VACUUM_DIMENSIONAL_cPP_CLASS'
bind=dict(read(HERE/'preparation_v3.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
for p in HERE.iterdir():
 if p.is_file():bind[str(p)]=digest(p)
for n in ['INTERPRETATION_V4.md','interpret_v4.py','prepare_v4.py','run_v4.py']:
 p=HERE/n;b=p.read_bytes();assert b'\r' not in b
 if p.suffix=='.py':compile(b,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 bind[str(HERE/(n+'.source.txt'))]=digest(HERE/(n+'.source.txt'))
with (CONTROL/'prelaunch_v4_preflight.json').open('xb') as out,(CONTROL/'prelaunch_v4_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],stdout=out,stderr=err,cwd=ROOT)
d=read(CONTROL/'prelaunch_v4_preflight.json');assert r.returncode==0 and not d['active_A10_M08_python_processes']
for n in ['prelaunch_v4_preflight.json','prelaunch_v4_preflight_stderr.txt']:bind[str(CONTROL/n)]=digest(CONTROL/n)
with (HERE/'preparation_v4.json').open('xb') as f:f.write((json.dumps({'schema':'GVC1_V4_COMPACT_INTERPRETATION_PREPARATION','input_sha256':dict(sorted(bind.items())),'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'old_quantum_calculations_rerun':False,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('GVC1_V4_FROZEN',len(bind),flush=True)
