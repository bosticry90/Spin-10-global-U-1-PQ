# The extra GF-vacuum class is measured; one mass direction is insufficient

GVC1 qualifies the complete extra gauge-fixing vacuum class of the local
dimension-one cPP dimensional insertion at the existing fixed reference.
It retains the actual ghost-scalar vertex, the ordinary ghost-vector graph
with a GF Lambda-x orbit insertion, both fermion endpoints, derivative
placements and the external-ghost paired-zero family.

Two independent calculations agree on138240 coefficient positions, including
zeros, across all45 external ghost directions, both Yukawa carriers and
both chiralities. The126 scalar, orbit and total parts each have85 nonzero
holomorphic positions. The10 parts are zero at this reference; general Y10
interactions are retained elsewhere. Counts describe coefficient positions,
not independent experiments or a percentage of quantum restoration.

The primary contracts the literal6688-row GF scalar density in raw C3
coordinates, the actual ghost/BL Green blocks and heavy orbit. Replay derives
the vertex from the actual primitive and scalar/nonlinear-antighost field
laws, then uses plane covariance. The full-D Schur contraction retains
I0=IB+IH; a barred-only contraction changes85 positions. The independently
qualified HPR insertion kernel is reused with a justified external-odd-source
replacement; no new radial integral, Nambu half or family3 is assigned.

V3 receipt SHA256:
e2f441006ef9709570e863f7801301cb3adb3cfc17b408f3ddbb2c494251f57f.
Status QUALIFIED_COMPLETE_EXTRA_GF_VACUUM_DIMENSIONAL_cPP_CLASS.
Scientific/director acceptance NOT_PERFORMED; authority34/39 unchanged.

## A useful negative result for a specific completion

Put D=B_R K v, with K=Cs,I-Cs,H. The complete measured extra-GF tensor is

    R_extra,c = -(9/50) i (T_c^T D+D T_c),

with g10^3 xi Y_R/(16pi^2) suppressed. V4 checks this exact compact form at
all23040 holomorphic positions, including zeros; its conjugate is retained.
No unknown coefficient was fitted. This is a representation of measured
data, not a choice of quantum input.

For the single candidate mass direction with kernel

    C_v(a) = [g10^2 xi Y_R/(16pi^2)] a B_R K v,

the independently measured hPP insertion requires a=1/2. This selected
ordinary-ghost component instead requires a=9/50. Their difference is8/25.
Using the hPP value leaves85 nonzero coefficient positions in the ordinary
ghost comparison. Consequently this one direction cannot cancel both
isolated components by itself.

V4 interpretation receipt SHA256:
66933d1432e4779086909b42ead069c6872f62e8433ea6544300e8a89bdff6cb.
Status QUALIFIED_ONE_DIRECTION_RESTORATION_DIAGNOSTIC.

This does not exclude the full admissible counterterm space or establish an
anomaly. The new bare component must still be combined with the existing
joint normalization and its complete positive-dimension source extension.
The earlier HSC/JMF qualifications expressly excluded that extension. No
baseline, coupling, flavor point or physical scheme was changed to resolve
the mismatch, and neither of the two values above is adopted physically.

## Controls and preserved failures

The original verifier failed because it expected omission of nonlinear
antighost terms to change the final cPP tensor. They contribute180 source
rows and2272 nonzero operator positions, but their final loop contraction
vanishes at this reference. V3 validates the actual full GF scalar vertex
against its scalar and nonlinear-antighost primitive variations over664200
positions. Omitting the nonlinear term changes104 Yukawa-vertex positions
before contraction. This provides a sensitive test at the correct level,
while preserving the final-tensor insensitivity. Omitting the B-derivative
jet is also insensitive in this projection; the complete qualified GTT
derivative input remains retained. Neither is advertised as a sensitive
final-tensor control. Scalar/orbit omissions, rho-order reversal and wrong
Schur sign each change85 positions; the spurious-half component control
changes170.

The failed original verifier and controller remain FAILED with their exact
sources/captures. V2's control then failed before mathematics because its
peer guard blocked authentication of already completed primary files. V3
authenticates bytes before installing the guard, preserving blindness during
the actual control calculation. It changes no quantum coefficient or physics
requirement. Primary/replay were never repeated. Two earlier source-construction
tool errors are recorded in CONTINUATION_V2 and the transcript.

Because the two quantum routes share the action-to-operator identification,
V5 additionally checks the orbit sign using a complete paired +/- momentum
Gaussian and independent completion of the square. It confirms the positive
Schur sign for both orientations; a wrong momentum sign is detected. The
worker cannot read the GVC quantum outputs during that calculation. It does
not repair the candidate conflict. V5 receipt SHA256:
7ccf6e8c7f5534c138440a57881aea627bea441bc87b38cb553873583b9912d6.
This finite algebra phase review is distinct from the unqualified global
Pfaffian/measure phase problem.

## Execution and next decision

Successful P/R/control3/verifier3/interpret4/phase5 took28.289274/20.121273/
27.464366/5.608061/4.236531/0.245746 seconds after imports. Their sampled
private maxima were111509504/83320832/104828928/52506624/51003392/491520B;
the last is a startup-only sparse observation, not a measured peak. All
600s/8GiB sampled/350MiB launch-floor/16MiB packet caps held. Twenty-six
exact source copies and versioned bindings/captures remain. Pre-report
packet367926B. HWB E4 is authenticated reuse with root0, steps0/0/0/0/0/2;
historical custody stays exit2/sevenNOTPASS. Original/V2 failures are distinct
from the subsequent successful evidence qualification.

Artifact extra_GF_vacuum_companion_v3.json.gz packed SHA256:
b5533678938f80d3dbcf8e7f5fffa8f4d3f2451dd6af8a6a3aad40457f008b33,
raw4e4344312888571ee0db414b045815ba98a17129e52cc2ce846a5fae9987c1d0.

Next reconstruct the complete selected c/v/h remainder after the actual
joint source normalization, rather than fit a larger polynomial to this
isolated remainder. A particularly small missing input is the proper Jx C v
kernel: the same GF scalar and orbit vertices join the scalar-source vertex
in a ghost/scalar loop. Their different heat lengths must remain separate
before finite extraction. Determine its existing bosonic ownership and
transport through the source Euler column exactly once, alongside VTF's
Jx-h kernel. This can decide whether the apparent single-direction conflict
is modified by source terms or requires an additional admissible completion.

No complete renormalized c/v/h family, multiple products/QAP, measure/phase,
arbitrary backgrounds/hats, physical vacuum/causal limit, massive C1, E5/A5
or physical unification is qualified. State113, earlier adverse physical
results, quartetFAIL, paused flavor, HB1/C5 and historical evidence remain
unchanged. Shared action, old covariance/kernel inputs, software and AI
authorship limit these checks to internal computational corroboration.
