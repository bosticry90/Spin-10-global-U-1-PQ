from data import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'preparation_v5.json')['input_sha256'].items():assert digest(Path(p))==h,p
def audit(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==HERE and p.suffix=='.gz':raise PermissionError('GVC1_PHASE_QUANTUM_TARGET_DENIED')
sys.addaudithook(audit)
q,w,g,xi,V,O,zp,zm,xp,xm=s.symbols('q w g xi V O Ca_plus Ca_minus x_plus x_minus',nonzero=True);Q=q*q
G=s.Matrix([[0,w/Q,0,-q/Q],[w/Q,0,q/Q,0],[0,q/Q,0,0],[-q/Q,0,0,0]])
assert G==G.T
J=s.Matrix([-s.I*g*V*q*zm,s.I*g*V*q*zp,s.I*g*xi*O*xm,s.I*g*xi*O*xp])
effective=s.expand(-(J.T*G*J)[0]/2);K=G.inv();mean=-G*J
square=s.expand((mean.T*K*mean)[0]/2+(J.T*mean)[0]);assert s.expand(effective-square)==0
c1=s.simplify(effective.coeff(zm).coeff(xp)/(g*g*xi*V*O));c2=s.simplify(effective.coeff(zp).coeff(xm)/(g*g*xi*V*O))
wrong=J.copy();wrong[0]=-wrong[0];bad=s.expand(-(wrong.T*G*wrong)[0]/2)
changed=int(s.simplify(bad.coeff(zm).coeff(xp)/(g*g*xi*V*O)-c1)!=0)
assert changed>0
# Independent explicit Wick factors for both derivative/vector directions.
spatial=(-1)*(-1);temporal=(-1)*s.I*s.I;orbit=(-1)*(-s.I)
assert spatial==temporal==1 and orbit==s.I
result={'status':'QUALIFIED_PAIRED_MODE_ORBIT_PHASE_REVIEW','effective_Ca_minus_x_plus_unit':str(c1),'effective_Ca_plus_x_minus_unit':str(c2),
 'previous_positive_Schur_sign_corroborated':c1==c2==1,'paired_gaussian_equals_complete_square':True,'wrong_momentum_sign_changed_coefficients':changed,
 'GVC_quantum_outputs_read_for_phase':False,'quantum_coefficients_changed':False,'full_counterterm_obstruction_claimed':False,
 'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','physical_scheme_adopted':False,'elapsed_after_imports':time.perf_counter()-t}
print('RESULT '+json.dumps(result,sort_keys=True),flush=True)
