# GVC1: proper support and the two oriented effective vertices

The extra reference-v dependence occurs in the GF ghost-scalar cubic and
the GF Lambda-x bilinear. M(v) and the scalar kinetic orbit are the v
evaluation of ordinary x insertions; their qualified cxPP inputs remain
separate. No dimension-two mass insertion can affect this critical local
coefficient without forbidden inverse parameters. At one loop the proper
internal-ghost insertion has one external physical P, an internal C and an
internal S. Its other fermion endpoint is a Yukawa vertex. Either a ghost-
scalar GF vertex closes the triangle or an ordinary ghost-vector GF vertex
closes it through the GF Lambda-x mixing. Both derivative placements UA/UB
remain in coverage; at zero external-ghost momentum they combine as V=UA-UB.

For an external ghost at Ihat itself, both its fermion legs are internal.
The relevant massless free block satisfies P G0 iE G0 P=0 at zero external
ghost jets: the two orientations reduce to hatk^2(bar_slash Atilde-A bar_slash)
=0. The extra GF insertion is on the bosonic edge, so it does not disturb
this identity. This is a pointwise zero before integration, not a claim about
all external-ghost graphs with mass insertions on fermion edges. Those other
graphs belong to the already qualified ordinary scalar class. An attachment
with both external ghosts exchanged into the same new ghost-scalar vertex
is either reducible or needs another loop. Hence the replacement of h by
an external c in the proper triangle has no extra factor2 or Pfaffian half.

The literal GF density here is Minkowski data. For its C a x term all fields
are unchanged by the common Wick contour and the action has overall sign-1.
Thus the Euclidean coefficient F is minus the literal coefficient divided
by g10^2 xi. Ghosts are ordered C first and a second before differentiating.
The raw heavy primitive is Psi_M=-g xi a O(v)^T x. Its field variation uses
qx=-g rho(C)x and the ACTUAL qa=-Lambda+g N(C)a. Besides rho_c O_a(v),
there is sum_s N[s,a,c] O_s(v). The nonlinear antighost term must not be
replaced by a doublet rule. The replay derives both signs with the odd product rule, then
uses full45 YCT covariance before projecting onto either Yukawa map.

At external ghost momentum0, the GTT ordinary vertex is
i g[UA(-q)+UB q]=-i g V q, where a has momentum-q and B has q. In the
quadratic operator a(-q) H_aB(q) B(q), moving the external ghost left gives
H_aB=+i g c V q. Operator transpose gives the same coefficient in H_Ba,
with its opposite incoming momentum retained. FMU supplies
H_Lambda,x=H_x,Lambda=+i g xi O, G_B,Lambda=-q/Q and G_Lambda,B=+q/Q.
The two Schur terms are

    delta H_ax=-H_aB G_B,Lambda H_Lambda,x,
    delta H_xa=-H_x,Lambda G_Lambda,B H_Ba.

They have the same effective C a x orientation as the direct vertex, with
effective coefficient V G_Ca O in raw coordinates. The free Ward relation
between BL and Ca carries the raw Gram factors; it cannot be replaced by an
identity metric before transport. The full-D contraction q.q=Q is essential.
With a positive auxiliary IR completion, keeping the numerator Q until the
end has I0=IB+IH=-1/2. A barred-only contraction gives IB=-1/3 and changes
the finite insertion. UV-convergent completion differences vanish with the
explicit analytic hat dimension. No physical mass or IR limit is chosen.

Let Z_a=sum_(b,u) Q_bu G_Ca,ua T_b and O_raw embed the actual33 heavy
orbit rows into45 antighost slots. Define the two scalar-mass vertices

    tau_scalar[c,a]=B F[a,c],
    tau_orbit[c,a]=sum_r V_raw[r,a,c] B(G_Ca O_raw)[r].

The actual HPR literal quadratic kernel and I0 give

    R_c = (i/2) sum_a [Z_a^T tau[c,a]+tau[c,a] Z_a].

The conjugate chirality is computed with B* and the same raw coefficients,
NOT their complex conjugates: raw ghost charts can be complex. Transform
external ghosts to the real plane chart before checking physical reality.
The two contributions stay separate until this ordered contraction completes.

In the independent plane calculation put M=Bv and tau_r=i(T_r^T M+M T_r).
The primitive/Green geometry gives the heavy projector P_M. The scalar GF
vertex is i L_c sum_a P_M,ra tau_a plus sum_s N[s,r,c] tau_s, with
L_c(X)=T_c^T X+X T_c. N is independently transported from the actual
nonlinear antighost field maps. The orbit
contribution uses the actual GTT V[r,a,c] and tau_r; no adjoint-only V=f
replacement is assumed. This is crucial because changing rho_c rho_a v to
rho_a rho_c v loses their commutator. The gate compares the independently
derived raw and plane tensors without forcing a desired counterterm image.

This calculation supplies the complete EXTRA GF-v proper class at order
g10^3 xi. It does not itself sum every old ordinary cxPP input at v, nor
establish simultaneous finite restoration. Source and auxiliary Euler
partners must accompany any eventual finite normalization. The one-variation
HWB result cannot be silently promoted to a multiple-insertion or doublet
cohomology theorem.

For a late diagnostic only, the already measured hPP coefficient fixes the
candidate finite mass kernel C_v=+(g^2 xi/(32pi^2)) B K v. Its ordinary
ghost variation has +i g(T_c^T C_v+C_v T_c). Thus the new bare GF class
would be canceled in the selected physical c/h projections if its computed
coefficient equals -i(T_c^T B K v+B K v T_c)/2, with g^3 xi/(16pi^2)
suppressed. The gate records the entire remainder whether zero or not.
Neither worker reads this candidate to determine a quantum coefficient.
Even a matching physical projection does not by itself qualify the complete
renormalized source/product prescription or adopt a physical scheme.
