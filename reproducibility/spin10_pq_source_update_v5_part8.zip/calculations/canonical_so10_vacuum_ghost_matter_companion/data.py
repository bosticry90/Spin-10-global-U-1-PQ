from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,gzip,os,sys,time,threading
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
@lru_cache(maxsize=131072)
def simp(x):return s.simplify(x)
def dec(m):return s.SparseMatrix(*m['shape'],{(i,j):s.sympify(z) for i,j,z in m['entries']})
def tidy(m):return s.SparseMatrix(m).applyfunc(simp)
def zero(m):assert not tidy(m).todok()
def enc(m):return {'shape':list(m.shape),'entries':[[int(i),int(j),str(simp(z))] for (i,j),z in sorted(s.SparseMatrix(m).todok().items()) if z]}
def begin(role):
 t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
 assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and p.name.startswith(peer):raise PermissionError('GVC1_PEER_DENIED')
 sys.addaudithook(audit);return t
def finish(role,d,t):
 d.update({'elapsed_after_imports':time.perf_counter()-t,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','physical_scheme_adopted':False,'full_renormalized_cvh_QAP_or_E5A5_qualified':False})
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'elapsed_after_imports':d['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True)
def paired_zero():
 pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
 g4=[s.kronecker_product(pa[1],z) for z in pa]+[s.kronecker_product(pa[0],s.eye(2))]
 gg=[s.kronecker_product(g,pa[2]) for g in g4]+[s.kronecker_product(s.eye(4),z) for z in pa[:2]]
 chi=s.prod(gg[:4]);PL=(s.eye(8)+chi)/2;PR=s.eye(8)-PL;a,b=s.symbols('a b');A=a*PL+b*PR;At=b*PL+a*PR
 bar=gg[0]+2*gg[1];hat=gg[4]+3*gg[5]
 z=(-s.I*bar)*(At*hat)*(-s.I*hat)+(-s.I*hat)*(-hat*A)*(-s.I*bar);zero(z)
 return 64
