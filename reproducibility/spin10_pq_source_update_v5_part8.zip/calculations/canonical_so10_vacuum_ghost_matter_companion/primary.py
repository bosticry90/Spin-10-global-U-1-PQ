"""GVC1 raw GF density and ghost/BL/dual sewing, without a Ward target."""
from data import *
t=begin('primary');paired=paired_zero();q,Vv,oo=s.symbols('q V orbit',nonzero=True)
left=simp(-(s.I*Vv*q)*(-1/q)*(s.I*oo));right=simp(-(s.I*oo)*(1/q)*(s.I*Vv*q));assert simp(left+Vv*oo)==simp(right-Vv*oo)==0
d=packed(CAL/'canonical_so10_cutoff_source_ward_operator/primary_inputs.json.gz');g,xi=s.symbols('g10 xi');F={};rows=0
names={f'x_{sec}_{i}':off+i for sec,n,off in [('Phi',54,0),('Sigma',252,54),('phi',20,306),('S',2,326)] for i in range(n)}
for row in d['GF']:
 w=row['word']
 if len(w)!=3 or not any(n in names for n in w):continue
 cc=[i for i,n in enumerate(w) if n.startswith('C')];aa=[i for i,n in enumerate(w) if n.startswith(('bar','ub'))]
 if len(cc)!=1 or len(aa)!=1:continue
 assert not any('__' in n for n in w);cn=int(w[cc[0]][1:]);an=int(w[aa[0]][3:] if w[aa[0]].startswith('bar') else w[aa[0]][2:]);j=names[next(n for n in w if n in names)]
 odd=-1 if cc[0]>aa[0] else 1;co=simp(-odd*s.sympify(row['coefficient'])/(g*g*xi));assert not co.free_symbols
 F[cn,an,j]=s.expand(F.get((cn,an,j),0)+co);rows+=1
assert rows==6688
G=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/primary_tables.json.gz');CG=dec(G['raw_Gca']);Q=dec(G['C3_chart']);Qi=Q.inv()
ua={(r,a,c):s.sympify(z) for r,a,c,z in G['raw_jets']['a']};ub={(r,a,c):s.sympify(z) for r,a,c,z in G['raw_jets']['B']};VV={k:simp(ua.get(k,0)-ub.get(k,0)) for k in set(ua)|set(ub)};VV={k:z for k,z in VV.items() if z}
O=s.SparseMatrix(45,328,{});O[12:,:]=dec(packed(CAL/'canonical_so10_vacuum_tangent_source_kernel/primary_tables.json.gz')['primitive_orbit_at_v']);GO=tidy(CG*O)
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));Z=Q*CG;ZT=[tidy(sum((Z[b,a]*T[b] for b in range(45) if Z[b,a]),s.zeros(16))) for a in range(45)]
hr=packed(CAL/'canonical_so10_vacuum_tangent_insertion_routing/primary_tables.json.gz');hu=simp(s.sympify(hr['holo_kernel_unit'])*s.sympify(hr['finite_moment']));au=simp(s.sympify(hr['anti_kernel_unit'])*s.sympify(hr['finite_moment']))
models=[]
for carrier in ['10','126']:
 B=dec(Y['B'+carrier]);bc=defaultdict(list)
 for (flat,j),co in B.todok().items():i,k=divmod(flat,16);bc[j].append((i,k,co))
 scalar=defaultdict(dict);ascalar=defaultdict(dict)
 for (c,a,j),co in F.items():
  for i,k,v in bc[j]:scalar[c,a][i,k]=s.expand(scalar[c,a].get((i,k),0)+co*v);ascalar[c,a][i,k]=s.expand(ascalar[c,a].get((i,k),0)+co*s.conjugate(v))
 scalar={key:s.SparseMatrix(16,16,val) for key,val in scalar.items()};ascalar={key:s.SparseMatrix(16,16,val) for key,val in ascalar.items()}
 bo=B*GO.T;abo=s.conjugate(B)*GO.T;orbit=defaultdict(lambda:s.zeros(16));aorbit=defaultdict(lambda:s.zeros(16));bad=defaultdict(lambda:s.zeros(16))
 bm=[s.Matrix(16,16,list(bo[:,r])) for r in range(45)];abm=[s.Matrix(16,16,list(abo[:,r])) for r in range(45)]
 for (r,a,c),co in VV.items():orbit[c,a]+=co*bm[r];aorbit[c,a]+=co*abm[r]
 for (r,a,c),co in ua.items():bad[c,a]+=co*bm[r]
 def contract(tab,anti=False):
  out=[s.zeros(16) for _ in range(45)]
  for (c,a),m in tab.items():out[c]+= (au*(ZT[a]*m+m*ZT[a].T) if anti else hu*(ZT[a].T*m+m*ZT[a]))
  return out
 def plane(raw):return [enc(tidy(sum((Qi[c,p]*raw[c] for c in range(45) if Qi[c,p]),s.zeros(16)))) for p in range(45)]
 sc,orb,asc,aorb=contract(scalar),contract(orbit),contract(ascalar,True),contract(aorbit,True)
 models.append({'carrier':carrier,'scalar':plane(sc),'orbit':plane(orb),'total':plane([a+b for a,b in zip(sc,orb)]),'anti_scalar':plane(asc),'anti_orbit':plane(aorb),'anti_total':plane([a+b for a,b in zip(asc,aorb)]),'omit_B_jet_orbit':plane(contract(bad))})
 print('STAGE COMPLETE_RAW_GHOST_GF_CLASS',carrier,flush=True)
finish('primary',{'method':'literal_raw_GF_scalar_density_two_Schur_orientations_and_raw_Green_color_contraction','GF_scalar_rows':rows,'external_ghost_directions':45,'proper_extra_GF_families':2,'external_ghost_paired_zero_positions':paired,'holo_loop_unit':str(hu),'anti_loop_unit':str(au),'Schur_effective_vertex_relative_sign':1,'models':models,'coupling_order':'g10^3*xi*Y_R/(16*pi^2)','extra_identical_ghost_factor':False},t)
