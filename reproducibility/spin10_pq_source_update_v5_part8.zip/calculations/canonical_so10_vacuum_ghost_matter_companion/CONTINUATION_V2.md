# V2: restore control coverage at the level where the contribution is visible

Original primary/replay completed native0 and agree on every coefficient
component. Original verifier failed at its expectation that omitting the
nonlinear antighost contribution changes the final cPP tensor. All original
sources/copies, manifests, completed tables and native captures/controller
failure remain unchanged. There is no original validation receipt and no
original artifact. A completed calculation is distinct from qualification.

Inspection of the complete tables shows that this particular omission is
insensitive after contraction at the frozen reference, for both carriers.
V2 does not change any quantum coefficient, physical input, component/zero
comparison, reality condition or candidate diagnostic. It introduces a new
actual-action/source control BEFORE the insensitive contraction: reconstruct
the full6688-row GF scalar vertex as the sum of scalar-field and nonlinear-
antighost variations of the actual primitive, including zero complements.
Require the nonlinear term to be nonzero at this operator level, and verify
its complete contracted cPP contribution is exactly zero. Its omission is
then tested where it changes the action, rather than advertised as a sensitive
final-tensor control. Preserve that final-tensor insensitivity explicitly.

The new control uses actual raw source field maps and the primitive orbit,
against the actual GF density. It is independent of the completed loop
transport. Its Yukawa-projected vertex and final loop are also checked.
If the operator-level test is zero or fails, no qualification follows.
Other omission/sign/order/jet/moment controls remain unchanged. This is a
versioned control-harness correction, not relaxation of any physical result
or replacement of an unknown quantum input by a desired cancellation.

Before execution freeze these5 new sources/copies (including this record),
all original successful/failed evidence and immutable inputs. Sequential
control_v2 then verify_v2, each600s after imports/8GiB sampledprivate/
350MiB available-commit launchfloor; total packet remains16MiB. No primary/
replay rerun. Failed original verifier/controller stay FAILED. The new
receipt/artifact/preparation/captures have explicitV2 names. Authority34/39,
all source/renormalization limits and scientific acceptance remain unchanged.

Before V2 freezing, a shell-quoted script-construction command failed to parse
and a following patch used a missing anchor. Neither changed calculation
inputs or launched a worker; both tool failures remain in the transcript.
The new verifier is supplied explicitly before its immutable source copy.
