# V3: authenticate bytes before installing the peer-read guard

V2 preparation completed. Its control worker failed before any action or
tensor calculation because begin installed the original peer-read audit
before the new manifest's authentication. That manifest legitimately binds
the completed primary files, so the guard rejected a hash read. The exact
V2 sources/copies, manifests, native failed capture and controller failure
remain unchanged. No V2 control result or qualification exists.

V3 moves the new manifest's byte authentication before installation of the
peer guard, as the original begin already does. An earliest600s timer covers
the whole operation. The guard remains active during all control mathematics;
the control still needs no peer quantum outputs. All equations, operator-
level sensitivity requirements, final-tensor comparisons and input bytes
are identical to V2. No primary/replay rerun, resource enlargement or new
scientific assumption. Freeze5new sources/copies before sequential control_v3
and verify_v3. Same600s/8GiB/350MiB/16MiB. V3 manifests, captures, artifact
and final receipt are explicitly named. Original/V2 failed states remain
FAILED; a successful V3 cannot relabel them. Authority34/39 unchanged.
