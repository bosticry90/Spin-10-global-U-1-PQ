from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/vacuum-ghost-matter-companion-v1-2026-10-23')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='691d2884621035d2a8405b34ba73e99ff84b51c2'
assert read(HERE/'controller_failure.json')['last_role']=='verify' and read(HERE/'verify_capture.json')['exit_code']==1 and not (HERE/'validation_receipt.json').exists()
bind=dict(read(HERE/'preparation.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
for p in HERE.iterdir():
 if p.is_file():bind[str(p)]=digest(p)
for n in ['CONTINUATION_V2.md','control_v2.py','verify_v2.py','prepare_v2.py','run_v2.py']:
 p=HERE/n;b=p.read_bytes();assert b'\r' not in b
 if p.suffix=='.py':compile(b,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 bind[str(HERE/(n+'.source.txt'))]=digest(HERE/(n+'.source.txt'))
with (CONTROL/'prelaunch_v2_preflight.json').open('xb') as out,(CONTROL/'prelaunch_v2_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],stdout=out,stderr=err,cwd=ROOT)
d=read(CONTROL/'prelaunch_v2_preflight.json');assert r.returncode==0 and not d['active_A10_M08_python_processes']
for n in ['prelaunch_v2_preflight.json','prelaunch_v2_preflight_stderr.txt']:bind[str(CONTROL/n)]=digest(CONTROL/n)
with (HERE/'preparation_v2.json').open('xb') as f:f.write((json.dumps({'schema':'GVC1_V2_CONTROL_CONTINUATION_PREPARATION','input_sha256':dict(sorted(bind.items())),'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'old_quantum_calculations_rerun':False,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('GVC1_V2_FROZEN',len(bind),flush=True)
