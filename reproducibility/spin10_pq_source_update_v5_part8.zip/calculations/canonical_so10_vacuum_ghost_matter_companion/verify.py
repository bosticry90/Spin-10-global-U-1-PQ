from data import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');assert P['method']!=R['method']
assert P['GF_scalar_rows']==6688 and P['proper_extra_GF_families']==R['proper_extra_GF_families']==2 and R['nonlinear_antighost_rows']>0
assert P['external_ghost_paired_zero_positions']==R['external_ghost_paired_zero_positions']==64
assert P['holo_loop_unit']=='I/2' and P['anti_loop_unit']=='-I/2' and P['Schur_effective_vertex_relative_sign']==R['Schur_effective_vertex_relative_sign']==1
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));K=dec(packed(CAL/'canonical_so10_vacuum_tangent_source_finite/selected_vacuum_source_relative_member.json.gz')['kernel_chi4']);v=dec(read(PK/'frozen_a10_physical_reconciliation/full_primary.json')['vacuum']['VEV'])
positions=0;counts={};controls=defaultdict(int);diagnostics=[];compatible=True
common=['scalar','orbit','total','anti_scalar','anti_orbit','anti_total']
for j,(p,r) in enumerate(zip(P['models'],R['models'])):
 assert p['carrier']==r['carrier'];label=p['carrier'];counts[label]={}
 for part in common:
  count=0
  for c,(a,b) in enumerate(zip(p[part],r[part])):
   aa,bb=dec(a),dec(b);dd=tidy(aa-bb);assert not dd.todok(),(label,part,c,enc(dd));zero(aa-aa.T);positions+=256;count+=len(aa.todok())
  counts[label][part]=count
 B=dec(Y['B'+label]);D=s.Matrix(16,16,list(B*K*v));rem=[]
 for c in range(45):
  sc,orb,tot,asc,aorb,atot=[dec(p[n][c]) for n in common]
  zero(tot-sc-orb);zero(atot-asc-aorb);zero(asc-s.conjugate(sc));zero(aorb-s.conjugate(orb));zero(atot-s.conjugate(tot))
  pred=-s.I*(T[c].T*D+D*T[c])/2;rr=tidy(tot-pred);compatible=compatible and not bool(rr.todok());rem.append(enc(rr))
  controls['omit_scalar']+=len(tidy(sc).todok());controls['omit_orbit']+=len(tidy(orb).todok());controls['wrong_Schur_sign']+=len(tidy(2*orb).todok())
  controls['wrong_rho_order']+=len(tidy(sc-dec(r['wrong_rho_order_scalar'][c])).todok())
  controls['omit_nonlinear_antighost']+=len(tidy(sc-dec(r['omit_nonlinear_antighost_scalar'][c])).todok())
  controls['omit_B_GF_jet']+=len(tidy(orb-dec(p['omit_B_jet_orbit'][c])).todok())
  controls['barred_only_bosonic_moment']+=len(tidy(orb/3).todok())
  controls['extra_open_half_on_components']+=len(tidy(sc/2).todok())+len(tidy(orb/2).todok())
 diagnostics.append({'carrier':label,'candidate_Cv_remainder':rem,'remainder_nonzero_positions':sum(len(m['entries']) for m in rem)})
# The frozen physical10 mass is zero; this does not discard general Y10.
assert counts['10']['total']==0
assert controls['omit_scalar']>0 and controls['omit_orbit']>0 and controls['omit_nonlinear_antighost']>0
recipe={'schema':'GVC1_COMPLETE_EXTRA_GF_VACUUM_BARE_DIMENSIONAL_cPP','overall_factor':'g10^3*xi*Y_R/(16*pi^2)',
 'external_ghost_basis':'REAL_PLANE_ALL45','models':P['models'],'late_candidate_diagnostic':diagnostics,
 'selected_Cv_c_h_projection_compatible':compatible,'counterterm_kernel_candidate':'+(g10^2*xi/(32*pi^2))*B_R*K*v',
 'complete_renormalized_cvh_source_family_qualified':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(recipe,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'extra_GF_vacuum_companion.json.gz').open('xb') as f:f.write(blob)
result={'status':'QUALIFIED_COMPLETE_EXTRA_GF_VACUUM_DIMENSIONAL_cPP_CLASS','full_coefficient_positions_compared':positions,'nonzero_component_positions':counts,
 'external_ghost_directions':45,'carriers':2,'proper_extra_GF_families':2,'external_ghost_paired_zero_positions':64,'literal_GF_scalar_rows':6688,
 'nonlinear_antighost_rows_retained':R['nonlinear_antighost_rows'],'controls_changed_positions':dict(controls),'selected_Cv_c_h_projection_compatible':compatible,
 'candidate_remainder_nonzero_positions':sum(v['remainder_nonzero_positions'] for v in diagnostics),'full_renormalized_cvh_QAP_or_E5A5_qualified':False,
 'physical_scheme_adopted':False,'authority':'34/39','scientific_acceptance':'NOT_PERFORMED','artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest(),'elapsed_after_imports':time.perf_counter()-t}
print('RESULT '+json.dumps(result,sort_keys=True),flush=True)
