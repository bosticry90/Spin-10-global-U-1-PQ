# V4: compact one-direction diagnostic from the completed quantum tensor

V3 has qualified the full extra GF-v cPP class. Its coefficient tables are
inputs, not fitting variables. The candidate dictated by the independently
measured hPP insertion leaves85 nonzero coefficient positions. Determine
whether the whole computed ordinary-ghost tensor is proportional to the
classical image of the single mass direction D=B K v, or contains additional
independent structure. Extract a coefficient from the first nonzero measured
entry and test it against EVERY coefficient/zero and both carriers/chiralities;
do not choose unknown quantum values to satisfy a desired identity.

For C_v(a) with kernel g^2 xi*a*D/(16pi^2), its ordinary-ghost image is
i*a*(T_c^T D+D T_c), with g^3 xi/(16pi^2) suppressed. Its hPP image is
a B K h. HPR fixes a_h=1/2 to cancel its measured -BKh/2. If the computed
cPP tensor is r*i*(T^T D+D T), that selected projection instead needs
a_c=-r. Test the simultaneous single-direction condition exactly. A mismatch
excludes ONLY this direction as a simultaneous completion of these selected
components. It is not a complete-counterterm obstruction or anomaly claim.
The old ordinary cxPP inputs, source normalizations and their extension still
need full reconciliation before a complete renormalized c/v/h claim.

Freeze4 new sources/copies and completed V3 evidence before this dependent
interpretation. One600s-after-imports worker,8GiB sampledprivate/350MiB launch
floor/16MiB packet unchanged; old quantum workers are not rerun. Preserve
all earlier failures. New preparation/capture/receipt have explicitV4 names.
Authority34/39 and all physical inputs/boundaries remain unchanged.
