from data import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'preparation_v4.json')['input_sha256'].items():assert digest(Path(p))==h,p
receipt=read(HERE/'validation_receipt_v3.json');assert receipt['status']=='QUALIFIED_COMPLETE_EXTRA_GF_VACUUM_DIMENSIONAL_cPP_CLASS'
A=packed(HERE/'extra_GF_vacuum_companion_v3.json.gz');Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));K=dec(packed(CAL/'canonical_so10_vacuum_tangent_source_finite/selected_vacuum_source_relative_member.json.gz')['kernel_chi4']);v=dec(read(PK/'frozen_a10_physical_reconciliation/full_primary.json')['vacuum']['VEV'])
ratio=None;tested=0;nonproportional=0;rows=[]
for model in A['models']:
 B=dec(Y['B'+model['carrier']]);D=s.Matrix(16,16,list(B*K*v));out=[]
 for c in range(45):
  target=s.I*(T[c].T*D+D*T[c]);measured=dec(model['total'][c]);anti=dec(model['anti_total'][c]);zero(anti-s.conjugate(measured))
  if ratio is None:
   for i,j in sorted(target.todok()):
    if target[i,j]:ratio=simp(measured[i,j]/target[i,j]);break
  if ratio is not None:
   rem=tidy(measured-ratio*target);nonproportional+=len(rem.todok());out.append(enc(rem))
  else:zero(measured);out.append(enc(measured))
  tested+=256
 rows.append({'carrier':model['carrier'],'proportionality_remainders':out})
assert ratio is not None
ah=s.Rational(1,2);ac=simp(-ratio);compatible=nonproportional==0 and simp(ah-ac)==0
# These are exact candidate-image diagnostics, never updates of the quantum
# coefficient or a restriction of the full admissible counterterm domain.
result={'status':'QUALIFIED_ONE_DIRECTION_RESTORATION_DIAGNOSTIC','quantum_tensor_unit_relative_to_i_Lc_BKv':str(ratio),
 'entire_cPP_tensor_proportional':nonproportional==0,'nonproportional_positions':nonproportional,'full_holomorphic_positions_tested':tested,
 'a_required_by_hPP':str(ah),'a_required_by_selected_extra_cPP':str(ac),'single_direction_simultaneously_compatible':compatible,
 'coefficient_conflict':str(simp(ah-ac)),'full_admissible_counterterm_space_excluded':False,'quantum_inputs_modified':False,
 'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','physical_scheme_adopted':False,'elapsed_after_imports':time.perf_counter()-t}
print('RESULT '+json.dumps(result,sort_keys=True),flush=True)
