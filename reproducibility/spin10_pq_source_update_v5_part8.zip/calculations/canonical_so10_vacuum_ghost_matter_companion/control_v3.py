"""GVC1 actual operator-level N sensitivity and exact projected zero."""
from data import *
t=time.perf_counter(); timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(HERE/'preparation_v3.json')['input_sha256'].items():assert digest(Path(p))==h,p
begin('control_v3')
d=packed(CAL/'canonical_so10_cutoff_source_ward_operator/primary_inputs.json.gz');g,xi=s.symbols('g10 xi');anti=[f'bar{a}' if a<12 else f'ub{a}' for a in range(45)];ai={n:i for i,n in enumerate(anti)}
names=[f'x_{sec}_{i}' for sec,n in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(n)];si={n:i for i,n in enumerate(names)}
O=s.SparseMatrix(45,328,{});O[12:,:]=dec(packed(CAL/'canonical_so10_vacuum_tangent_source_kernel/primary_tables.json.gz')['primitive_orbit_at_v']);orow=defaultdict(list);ocol=defaultdict(list)
for (a,j),z in O.todok().items():orow[a].append((j,z));ocol[j].append((a,z))
FN=defaultdict(lambda:s.S.Zero);nonlinear=0
for out,n in enumerate(anti):
 for row in d['field_maps'][n]:
  w=row['word']
  if len(w)==1:continue
  cr=next(i for i,z in enumerate(w) if z.startswith('C'));ar=1-cr;c=int(w[cr][1:]);a=ai[w[ar]];co=simp((-1 if cr>ar else 1)*s.sympify(row['coefficient'])/g);nonlinear+=1
  for j,z in orow[out]:FN[c,a,j]+=co*z
FQ=defaultdict(lambda:s.S.Zero);scalarrows=0
for j,n in enumerate(names):
 for row in d['field_maps'][n]:
  w=row['word'];assert len(w)==2 and not any('__' in z for z in w);c=int(next(z for z in w if z.startswith('C'))[1:]);l=si[next(z for z in w if z in si)];co=simp(-s.sympify(row['coefficient'])/g);scalarrows+=1
  for a,z in ocol[l]:FQ[c,a,j]+=co*z
actual=defaultdict(lambda:s.S.Zero);densityrows=0
for row in d['GF']:
 w=row['word']
 if len(w)!=3 or not any(n in si for n in w):continue
 cc=[i for i,n in enumerate(w) if n.startswith('C')];aa=[i for i,n in enumerate(w) if n in ai]
 if len(cc)!=1 or len(aa)!=1:continue
 c=int(w[cc[0]][1:]);a=ai[w[aa[0]]];j=si[next(n for n in w if n in si)];co=simp(-(-1 if cc[0]>aa[0] else 1)*s.sympify(row['coefficient'])/(g*g*xi));actual[c,a,j]+=co;densityrows+=1
FN={k:simp(z) for k,z in FN.items() if simp(z)!=0};FQ={k:simp(z) for k,z in FQ.items() if simp(z)!=0};actual={k:simp(z) for k,z in actual.items() if simp(z)!=0}
for k in set(FN)|set(FQ)|set(actual):assert simp(actual.get(k,0)-FN.get(k,0)-FQ.get(k,0))==0,k
assert FN and densityrows==6688
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,Y['Tminus']));GG=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/primary_tables.json.gz');Z=dec(GG['C3_chart'])*dec(GG['raw_Gca']);ZT=[tidy(sum((Z[b,a]*T[b] for b in range(45) if Z[b,a]),s.zeros(16))) for a in range(45)]
mass_vertex_nz=0;loop_nz=0
for carrier in ['10','126']:
 B=dec(Y['B'+carrier]);cols=defaultdict(list)
 for (flat,j),co in B.todok().items():i,k=divmod(flat,16);cols[j].append((i,k,co))
 mass=defaultdict(dict)
 for (c,a,j),co in FN.items():
  for i,k,z in cols[j]:mass[c,a][i,k]=s.expand(mass[c,a].get((i,k),0)+co*z)
 total=[s.zeros(16) for _ in range(45)]
 for (c,a),m in mass.items():
  mat=tidy(s.SparseMatrix(16,16,m));mass_vertex_nz+=len(mat.todok());total[c]+=s.I*(ZT[a].T*mat+mat*ZT[a])/2
 for mat in total:zero(mat);loop_nz+=len(tidy(mat).todok())
assert mass_vertex_nz>0 and loop_nz==0
finish('control_v3',{'method':'literal_raw_GF_density_vs_actual_scalar_and_nonlinear_antighost_primitive_variations','GF_density_rows':densityrows,'scalar_source_rows':scalarrows,'nonlinear_antighost_rows':nonlinear,'full_vertex_positions_checked':45*45*328,'nonlinear_operator_nonzero_positions':len(FN),'nonlinear_Yukawa_vertex_nonzero_positions':mass_vertex_nz,'nonlinear_final_loop_nonzero_positions':loop_nz,'nonlinear_final_loop_control_insensitive':True,'operator_omission_control_sensitive':True,'quantum_inputs_changed':False},t)
