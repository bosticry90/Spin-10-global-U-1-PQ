# V5: adversarial paired-mode Gaussian check of the orbit sign

V4 finds an exact one-direction coefficient conflict. The raw and plane
quantum methods share the action-to-operator identification used for the
mixed graph. Before interpreting the conflict, independently check its sign
from the literal Fourier density and a COMPLETE paired +/- momentum Gaussian.
This check is justified by the earlier HPI shared-sign error, not by a demand
that the candidate pass. Do not alter a quantum coefficient to fit it.

For a scalar component of a full-D nonzero momentum q, the ordinary GF
vertex is i g(UA p_a+UB p_B) C a B. At p_C0,p_a=-p_B it is -ig V q C a,
V=UA-UB. This follows for spatial components from the literal Minkowski
metric-1 and action Wick-1, and for time from derivative/B rotations i*i
and action-1. The orbit source is +i g xi O Lambda x. Both use the actual
FMU/GTT conventions, not the candidate counterterm.

Pair the B+,B-,Lambda+,Lambda- modes. The symmetric full Green block has
G_B+Lambda-=-q/Q and G_B-Lambda+=+q/Q; transpose entries agree across
the paired modes. The sources are J_B+=-igVq(Ca-), J_B-=+igVq(Ca+),
J_Lambda+=igxiO x-,J_Lambda-=igxiO x+. Ca+ and Ca- are EVEN exterior
bilinears, hence commute; terms quadratic in them are irrelevant to this
linear-Ca check. Evaluate -J^T G J/2 and independently complete the square.
Extract the Ca- x+ and Ca+ x- coefficients. Wrong momentum/source sign is
the negative control. A single Fourier block must not replace this paired
Gaussian or be called a symmetric quadratic form.

Freeze4 new sources/copies before one exact worker,600s after imports,
8GiB sampledprivate/350MiB launchfloor/16MiB totalpacket. No old loop rerun.
The worker cannot read GVC quantum outputs after input authentication. The
result decides whether the previous orbit sign is corroborated; disagreement
requires preserving the mismatch, not forcing either answer. This is a
finite local algebra check, not a measure/global-phase or physical CPT test.
No scientific authority/physical input/scheme change. Full source restoration
and admissible counterterm completeness remain open whatever the outcome.
