# GVC1: the extra gauge-fixing vacuum class in the local cPP insertion

Base691d2884621035d2a8405b34ba73e99ff84b51c2/main33486blobs. Prior turn
PROGRESS: HWB before/index/after seals native0/clean,33456olderblobs preserved.
Fresh preflight clean/no matching workers, state113/authority34of39 unchanged.

Question: measure the complete EXTRA GF-vacuum class of the dimension-one,
zero-jet ordinary cPP dimensional insertion, needed to assess the ordinary
ghost partners of the HPR/HWB hPP result. Do not infer it from a chosen
counterterm. Already qualified cxPP graphs evaluated at the reference v
cover mass and kinetic-orbit dependence; the new class is explicit GF-v
dependence. Keep gauge powers distinct: this extra class is g10^3 xi Y_R v.

Freeze existing Cartesian massless SMA/old643 reference; no resummation or
reference transport. v is the existing fixed algebraic reference vector, with
dual/projector maps held fixed. Nonexceptional Euclidean physical external
c,P,P/hats0; critical local zero-jet coefficient; full-D bosonic momenta and
internal hats; all45 external ghost directions, both Yukawa carriers and
general symmetric complex family matrices. No numeric flavor/mass/baseline,
inverse parameter, scheme or physical benchmark adoption. Sources are not
part of this bare coefficient; a later restoring interpretation needs their
full correlated contributions. VTS external extension remains provisional.

Complete new proper support: (A) internal-ghost Ihat, the actual positive-
dimension GF a C x vertex, and Yukawa vertex; (B) internal-ghost Ihat, ordinary
GF a C B vertex, the GF Lambda-x vacuum insertion and Yukawa vertex, retaining
both UA/UB jets and both fermion orientations; (C) external-ghost Ihat with
the GF bosonic orbit and two external-matter vertices. C is tested with the
paired free identity, not discarded because absent from A/B. Constant ghost
or vector masses have dimension2 and are subleading; source/background and
reducible tadpole graphs are outside this declared proper target.

Primary derives the two oriented Schur/sewing signs from the actual free
BL blocks and GF Lambda-x vertex, then contracts the literal raw GF scalar
density, raw derivative jets, ghost Green, reference orbit and YCT maps.
Replay reconstructs the scalar vertex from the actual primitive, scalar
field law AND nonlinear q-antighost ghost terms, and contracts in the independent plane chart via YCT covariance
and qualified GTT jets. The HPR literal Gaussian kernel and its I0 moment
apply by linear replacement of the external odd h by the external ghost;
prove no extra identical-ghost attachment or symmetry factor is introduced.
No old large scalar/operator run or new45-generator identity is repeated.

Compare each component and their total, all45 matrices/both carriers and
conjugate chirality including zeros. Sensitive controls replace rho_c rho_a
by rho_a rho_c, omit either GF contribution, alter the Schur sign, omit a
GF derivative jet, use barred-only bosonic contraction, or add half/family3.
Record genuine insensitivities, including a zero10 reference mass. The
quantum total may be zero or nonzero; neither is required in advance. Omitting
the nonlinear antighost term is a separate necessary negative control.

Freeze8 sources/copies and immutable inputs before sequential P/R/V. Each
600s after imports,8GiB sampled private,350MiB available-commit launchfloor,
16MiB packet. Stop and preserve first failure; no silently expanded resources.
Reuse authenticated HWB E4 root0 steps0/0/0/0/0/2 custodysevenNOTPASS.
Before/index/after local seals preserve33486priorblobs. No agents or parallel
scientific mutation, branch/worktree, push, outreach or publication.

Ceiling: actual extra GF-v class bare DIM insertion at this fixed reference,
not the complete renormalized c/v/h source system, QAP/measure/phase,
restoring theorem, physical massive C1/E5A5/GUT. All protected adverse results,
flavorpause/HB1C5/state/custody remain. Shared action, covariance/old kernel,
software and AI author remain common-error limits. A counterterm comparison,
if useful, is a late diagnostic and cannot fit the computed quantum tensor.
