"""GVC1 primitive field variation, Gaussian elimination and plane covariance."""
from data import *
t=begin('replay');paired=paired_zero()
# Independently eliminate B,L from their sourced free equations at q=1.
Bv,Lv,xv,av,c,aa,ov=s.symbols('B L x a c vertex orbit');H=s.Matrix([[0,1],[-1,3]])
src=s.Matrix([s.I*c*aa*av,s.I*ov*xv]);sol=-H.inv()*src
ind=s.expand((src.T*sol)[0]/2);cross=s.expand(ind).coeff(c).coeff(av).coeff(xv)
# Ordinary commuting stand-ins erase the exterior sign. Extract the two
# directed equations separately, then place c to the left of the odd a.
left=simp(-s.I*aa*H.inv()[0,1]*s.I*ov);right=simp(-s.I*ov*H.inv()[1,0]*s.I*aa);assert left==-aa*ov and right==aa*ov
# Odd product rule: primitive-1, differentiated-x sign-1, qx-1,
# C past a-1, antisymmetric rho transpose-1, common Wick action-1.
ghost_primitive_unit=s.prod([-1]*6);assert ghost_primitive_unit==1
Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,Y['Tminus']));HF=dec(Y['H_new']);PM=tidy(s.eye(45)-HF*HF.T)
TP=[tidy(sum((PM[a,b]*T[b] for b in range(45) if PM[a,b]),s.zeros(16))) for a in range(45)]
G=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/replay_tables.json.gz');VV={(r,a,c):s.sympify(z) for r,a,c,z in G['plane_V']};assert all(s.conjugate(z)==z for z in VV.values())
UL=dec(G['raw_aux_map']);UI=UL.inv();Q=dec(G['C3_chart']);Qi=Q.inv();maps=packed(CAL/'canonical_so10_cutoff_source_ward_operator/primary_inputs.json.gz')['field_maps'];g=s.Symbol('g10');NN=defaultdict(lambda:s.S.Zero);rawN=0
anti=[f'bar{a}' if a<12 else f'ub{a}' for a in range(45)];anum={n:i for i,n in enumerate(anti)}
for out,n in enumerate(anti):
 for row in maps[n]:
  w=row['word']
  if len(w)==1:continue
  assert len(w)==2 and any(z.startswith('C') for z in w) and any(z in anum for z in w)
  cr=next(i for i,z in enumerate(w) if z.startswith('C'));ar=1-cr;ci=int(w[cr][1:]);ai=anum[w[ar]];co=simp((-1 if cr>ar else 1)*s.sympify(row['coefficient'])/g);assert not co.free_symbols;rawN+=1
  for a in range(45):
   if not UI[a,out]:continue
   for b in range(45):
    if not UL[ai,b]:continue
    for c in range(45):
     if Qi[ci,c]:NN[a,b,c]+=co*UI[a,out]*UL[ai,b]*Qi[ci,c]
NN={k:simp(v) for k,v in NN.items() if simp(v)!=0};assert rawN>0
models=[]
for carrier in ['10','126']:
 M=dec(Y['mass'+carrier]);N=s.conjugate(M)
 tau=[tidy(s.I*(a.T*M+M*a)) for a in T];tp=[tidy(s.I*(a.T*M+M*a)) for a in TP]
 at=[tidy(-s.I*(a*N+N*a.T)) for a in T];ap=[tidy(-s.I*(a*N+N*a.T)) for a in TP]
 for a,b in zip(tau,tp):zero(a-b)
 sc=[s.zeros(16) for _ in range(45)];asc=[s.zeros(16) for _ in range(45)];wrong=[s.zeros(16) for _ in range(45)];orb=[s.zeros(16) for _ in range(45)];aorb=[s.zeros(16) for _ in range(45)];ns=[s.zeros(16) for _ in range(45)];ans=[s.zeros(16) for _ in range(45)]
 for c in range(45):
  for a in range(45):
   if tp[a].todok():
    F=s.I*(T[c].T*tp[a]+tp[a]*T[c]);sc[c]+=s.I*(T[a].T*F+F*T[a])/2
    AF=-s.I*(T[c]*ap[a]+ap[a]*T[c].T);asc[c]+=-s.I*(T[a]*AF+AF*T[a].T)/2
   if tau[c].todok():
    Fw=s.I*(TP[a].T*tau[c]+tau[c]*TP[a]);wrong[c]+=s.I*(T[a].T*Fw+Fw*T[a])/2
 for (r,a,c),co in VV.items():
  if tau[r].todok():orb[c]+=s.I*co*(T[a].T*tau[r]+tau[r]*T[a])/2;aorb[c]+=-s.I*co*(T[a]*at[r]+at[r]*T[a].T)/2
 for (r,a,c),co in NN.items():
  if tau[r].todok():ns[c]+=s.I*co*(T[a].T*tau[r]+tau[r]*T[a])/2;ans[c]+=-s.I*co*(T[a]*at[r]+at[r]*T[a].T)/2
 tab=lambda ms:[enc(tidy(m)) for m in ms]
 models.append({'carrier':carrier,'scalar':tab([a+b for a,b in zip(sc,ns)]),'orbit':tab(orb),'total':tab([a+b+c for a,b,c in zip(sc,ns,orb)]),'anti_scalar':tab([a+b for a,b in zip(asc,ans)]),'anti_orbit':tab(aorb),'anti_total':tab([a+b+c for a,b,c in zip(asc,ans,aorb)]),'wrong_rho_order_scalar':tab([a+b for a,b in zip(wrong,ns)]),'omit_nonlinear_antighost_scalar':tab(sc)})
 print('STAGE COMPLETE_INDEPENDENT_PLANE_GF_CLASS',carrier,flush=True)
finish('replay',{'method':'primitive_odd_variation_independent_Gaussian_elimination_and_plane_mass_covariance','nonlinear_antighost_rows':rawN,'external_ghost_directions':45,'proper_extra_GF_families':2,'external_ghost_paired_zero_positions':paired,'Schur_effective_vertex_relative_sign':1,'models':models,'coupling_order':'g10^3*xi*Y_R/(16*pi^2)','extra_identical_ghost_factor':False},t)
