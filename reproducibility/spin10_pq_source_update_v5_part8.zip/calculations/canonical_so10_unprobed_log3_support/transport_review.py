from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import Counter
import gzip,json,os,sys,threading,time
O=Path(__file__).resolve().parent;R=O.parents[1]
sys.path.insert(0,str(R/'calculations/canonical_so10_u_T_cutoff_tensor'))
from actual import co
from algebra import Coeff,ZERO,constant
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest()
for pp,h in read(O/'transport_review_preparation.json')['input_sha256'].items():assert H(Path(pp))==h,pp
def decode(rows):
    out={tuple(row[:-1]):Coeff([(tuple(k),Fraction(n,d)) for k,n,d in row[-1]]) for row in rows}
    assert len(out)==len(rows) and all(out.values());return out
def plus(*parts):
    out={}
    for part in parts:
        for key,c in part.items():out[key]=out.get(key,ZERO)+c
    return {k:v for k,v in out.items() if v}
def enc(M):return [[*key,[[list(k),v.numerator,v.denominator] for k,v in c.terms]] for key,c in sorted(M.items())]
ab=[]
for role in ['primary','replay']:
    assert H(O/('transport_'+role+'_tables.json.gz'))==read(O/('transport_'+role+'_result.json'))['packed_sha256']
    ab.append(load(O/('transport_'+role+'_tables.json.gz')))
assert {k:v for k,v in ab[0].items() if k!='role'}=={k:v for k,v in ab[1].items() if k!='role'}
assert all(z['guard_denials']==3 and z['graded_density_fixtures']==3 for z in ab)
actual={};coverage=[]
for z in ab[0]['results']:
    target=z['target'];domain=(45*45 if target=='T' else 45*990)*328
    groups={k:decode(v) for k,v in z['groups'].items()};total=decode(z['total']);assert plus(*groups.values())==total
    assert len(total)==z['total_nonzero'] and domain-len(total)==z['zero_complement'] and domain==z['domain_positions']
    for key,v in total.items():
        assert len(key)==(3 if target=='T' else 4) and 0<=key[0]<45 and 0<=key[1]<45 and 0<=key[-1]<328
        if target=='F':assert key[1]<key[2]<45
    assert {k:len(M) for k,M in groups.items()}==z['group_nonzero_counts']
    actual[z['probe'],target]=total;coverage.append({k:v for k,v in z.items() if k not in ['groups','total']})

# The old target is first read mathematically after complete new equality.
P=R/'calculations/canonical_so10_u_lower_cutoff_contraction';receipt=read(P/'final_review_validation_receipt.json')
rel=str((P/'late_remainders.json.gz').relative_to(R)).replace('\\','/')
assert H(P/'late_remainders.json.gz')==receipt['new_files_sha256'][rel]
old=load(P/'late_remainders.json.gz');comparisons=[];saved=[]
for (probe,target),new in sorted(actual.items()):
    row=next(z for z in old if z['probe']==probe and z['case']==target and z['basis']=='log3')
    previous=decode(row['remainders']);combined=plus(previous,new)
    comparisons.append({'probe':probe,'target':target,'basis':'log3','previous_partial_nonzero':len(previous),
       'known_Bu_C0_nonzero':len(new),'new_partial_nonzero':len(combined),'new_partial_zero':not combined,
       'three_marginal_kernels_and_full_applicability_still_required':True})
    saved.append({'probe':probe,'target':target,'basis':'log3','partial_after_known_Bu_C0':enc(combined)})

support=load(O/'support_v2_primary_tables.json.gz');L=support['letters'];reductions=[]
for z in support['results']:
    if z['target'] not in ['JaaC','JLaCC','JLJLCC']:continue
    families={}
    for index,word in enumerate(z['ordered_three_edge_words']):
        sequence=[]
        for at,i in enumerate(word['letters']):
            e=L[i];sequence.append((e['origin'],e['intrinsic_degree'],tuple(e['external_types']),tuple(e['H_ports']),tuple(e['internal_jet_orders']),word['Green_path'][at]))
        signature=min(tuple(sequence[j:]+sequence[:j]) for j in range(3))
        families.setdefault(signature,[]).append(index)
    assert sum(map(len,families.values()))==z['candidate_words']
    reductions.append({'target':z['target'],'ordered_words':z['candidate_words'],'cyclic_type_signatures':len(families),
       'families':[{'signature':sig,'word_indices':ix} for sig,ix in sorted(families.items())],
       'amplitude_equivalence_or_Grassmann_cyclic_sign_not_inferred':True})
payload={'schema':'ULS4_LATE_PARTIAL_LOG3_AFTER_KNOWN_BU_C0','comparisons':comparisons,'partial_tensors':saved,'unmeasured_kernel_work_reduction':reductions,'full_Ward_claim':False}
raw=(json.dumps(payload,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/'partial_after_known.json.gz').open('xb') as f:f.write(blob)
out={'schema':'ULS4_COMPLETE_TRANSPORT_VALIDATION_AND_PARTIAL_COMPARISON','complete_native_images_and_zero_complements_equal':True,
 'coverage':coverage,'late_partial_comparisons':comparisons,'missing_marginal_type_family_counts':[{k:v for k,v in z.items() if k!='families'} for z in reductions],
 'packed_partial_sha256':sha256(blob).hexdigest(),'scientific_acceptance':'NOT_PERFORMED','full_Ward_restoration_or_anomaly':False,
 'elapsed_after_imports':time.perf_counter()-tick}
with (O/'transport_review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
