from pathlib import Path
from hashlib import sha256
from collections import Counter
import gzip,json,os,sys,threading,time
O=Path(__file__).resolve().parent;R=O.parents[1]
sys.path.insert(0,str(R/'calculations/canonical_so10_u_T_cutoff_tensor'))
from actual import co
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
H=lambda p:sha256(p.read_bytes()).hexdigest()
for pp,h in read(O/'review_preparation.json')['input_sha256'].items():assert H(Path(pp))==h,pp
a,b=[load(O/('support_v2_'+r+'_tables.json.gz')) for r in ['primary','replay']]
assert {k:v for k,v in a.items() if k!='role'}=={k:v for k,v in b.items() if k!='role'}
for role in ['primary','replay']:
    z=read(O/('support_v2_'+role+'_result.json'));assert H(O/('support_v2_'+role+'_tables.json.gz'))==z['packed_sha256']
    assert z['guard_denials']==3
assert len(a['results'])==9 and not any(z['abstract_superfamily_occurrences'] for z in a['results'])
for z in a['results']:
    for w in z['ordered_three_edge_words']:
        assert len(w['letters'])==3 and len(w['Green_path'])==4
        grade=tuple(sum(a['letters'][i]['grade'][j] for i in w['letters']) for j in range(len(a['letters'][0]['grade'])))
        assert sum(grade)==z['intrinsic_degree']+len(z['external_types'])
        assert w['STr_sign']==(-1)**int(w['Green_path'][0] in ['a','C','P'])
        assert w['ordered_log_weight']==[1,6]

def old_pair(folder,stem):
    P=R/'calculations'/folder;out=[]
    for role in ['primary','replay']:
        path=P/(stem+'_'+role+'_tables.json.gz');result=read(P/(stem+'_'+role+'_result.json'))
        assert H(path)==result['packed_sha256'];out.append(load(path))
    return out
def table(rows):
    out={tuple(v[:-1]):co(v[-1]) for v in rows};assert len(out)==len(rows) and all(out.values());return out

usr=old_pair('canonical_so10_unprobed_source_root_module','color')
assert read(R/'calculations/canonical_so10_unprobed_source_root_module/color_validation_receipt.json')['all_4841280_positions_and_zero_complement_compared']
Z=[]
for role in range(2):
    z={(row['h'],*key):v for row in usr[role]['by_ghost'] for key,v in table(row['total_operator']).items()};Z.append(z)
assert Z[0]==Z[1] and len(Z[0])==35824
assert all(0<=h<45 and 0<=i<328 and 0<=j<328 for h,i,j in Z[0])

aak=old_pair('canonical_so10_unprobed_antighost_kernel','color')
assert read(R/'calculations/canonical_so10_unprobed_antighost_kernel/color_validation_receipt_v2.json')['complete_group_heat_pole_prime_and_implicit_zero_agreement']
F=[table(z['F_m']['3']) for z in aak];assert F[0]==F[1] and len(F[0])==10632
assert all(0<=r<45 and 0<=h<45 and 0<=i<328 for r,h,i in F[0])

uak=old_pair('canonical_so10_unprobed_auxiliary_source_kernel','color')
ur=read(R/'calculations/canonical_so10_unprobed_auxiliary_source_kernel/color_validation_receipt.json')
assert ur['F3_mass_and_scalar_current_each_exact_zero'] and ur['full_heat_coefficients_and_implicit_zeros_agree']
assert all(not z['F_m']['3'] and all(not g for g in z['F3_groups'].values()) for z in uak)

iqc=old_pair('canonical_so10_intrinsic_quadratic_source_contacts','auxiliary')
assert read(R/'calculations/canonical_so10_intrinsic_quadratic_source_contacts/auxiliary_validation_receipt.json')['component_vs_density_Hessian_and_matrix_contractions_all_coefficients_and_zeros_agree']
L=[table(z['Lambda_x']['F3_vector']['entries']) for z in iqc]
assert L[0]==L[1] and len(L[0])==304
assert all(0<=r<45 and 0<=i<328 for r,i in L[0])
assert all(table(z['Lambda_x']['log3_over2']['entries'])==L[role] for role,z in enumerate(iqc))

icr=old_pair('canonical_so10_intrinsic_correlated_source_contacts','auxiliary_roots')
assert read(R/'calculations/canonical_so10_intrinsic_correlated_source_contacts/auxiliary_roots_validation_receipt.json')['all_91125_positions_per_root_heat_and_zeros_agree']
for z in icr:
    rr=next(v for v in z['results'] if v['root']=='Ja_JL_C');assert not rr['heat_and_group_tensors']['C3']

by_name={z['target']:z for z in a['results']};assert by_name['nJax']['candidate_words']==0
reused=[{'target':'JxCx','owner':'USR color C3=Z','domain':45*328*328,'nonzero':len(Z[0])},
 {'target':'naCx','owner':'AAK color F_m[3]','domain':45*45*328,'nonzero':len(F[0])},
 {'target':'nLx','owner':'IQC auxiliary Lambda_x.F3_vector','domain':45*328,'nonzero':len(L[0])},
 {'target':'nJLCx','owner':'UAK color both F3 groups individually zero','domain':45*45*328,'nonzero':0},
 {'target':'JaJLC','owner':'ICR auxiliary_roots Ja_JL_C.C3','domain':45**3,'nonzero':0},
 {'target':'nJax','owner':'ULS complete three-edge support zero; IQC all-edge block premise retained','domain':45*328,'nonzero':0}]
for z in reused:z['zero_complement']=z['domain']-z['nonzero']
missing=[{'target':name,'candidate_words':by_name[name]['candidate_words'],'quantum_tensor_measured':False} for name in ['JaaC','JLaCC','JLJLCC']]
out={'schema':'ULS2_COMPLETE_SUPPORT_AND_EXACT_C3_REUSE','complete_native_support_equal':True,'letters':len(a['letters']),
 'three_edge_words_by_target':{z['target']:z['candidate_words'] for z in a['results']},'total_ordered_candidate_words':sum(z['candidate_words'] for z in a['results']),
 'abstract_potential_or_fermion_complete_cycles':0,'six_roots_reused_or_support_zero':reused,'three_remaining_unmeasured_roots':missing,
 'old_quantum_calculations_freshly_replayed':False,'old_actual_qualified_tensors_authenticated_and_compared':True,
 'new_full_Ward_QAP_or_E5_claim':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
