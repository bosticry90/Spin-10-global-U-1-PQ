# ULS4: complete transported coefficients and late partial comparison

Both ULS3 native routes completed. First authenticate and compare every
group, sum, coefficient and implicit zero at45x45x328 T or45x990x328 F,
both probes. Check proper target indices, unique keys, source-degree
provenance and all native captures/effort/resource limits. Do not compare
only counts. These are new operation contractions of reused qualified
quantum coefficients, not new loop integrals.

Only then authenticate UCT late_remainders.json.gz with its final receipt,
and add the known ULS3 B_u C0 log3 images with the original plus sign.
Keep every coefficient of each resulting PARTIAL sum, irrespective of
zero/nonzero outcome. Three marginal root kernels remain unmeasured;
no full Ward/obstruction theorem is licensed. No fit, sign adjustment,
inverse coupling or finite contact chosen from the target.

Classify cyclic ORIGIN/type signatures for the three unmeasured kernels
only as a work reduction. Retain every original ordered path and starting
supertrace/Grassmann sign; cyclic grouping does not assert identical
amplitudes or cancellation. Actual derivative roles remain in the words.
Review180s,8GiB sampled,350MiB launchfloor,32MiB packet. Authority unchanged.
