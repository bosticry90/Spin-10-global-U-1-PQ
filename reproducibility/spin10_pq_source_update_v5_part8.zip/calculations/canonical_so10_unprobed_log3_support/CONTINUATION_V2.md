# ULS1 V2: explicit physical-graph B type alias, prospective

Original support.py primary exited1 at the full kinetic-graph type check,
before producing any support table or result. Its sources/copies,
preparation,complete capture and controller failure remain unchanged;
the original replay was not launched. This is an input parser failure,
not a failed physical hypothesis or a qualified partial result.

The physical kinetic graph program uses abstract Field names B,h_B,k_B,
whereas GF uses component names B0_0 etc. V1 recognized only components.
V2 adds exactly the explicit abstract B alias to the same vector type.
No input row,port,acceptance condition or scientific requirement is
removed. New V2 sources and preparation/output names preserve V1.
The native peer guard covers both old and V2 peer output names.

Run both complete routes under the original300s/role,review180s,
private8GiB sampled,350MiB launchfloor,32MiB packet. This authorizes a
new bounded corrected execution,not retroactive acceptance of V1.
All domain,claim,authority and no-fitting limits in RECORD still apply.
