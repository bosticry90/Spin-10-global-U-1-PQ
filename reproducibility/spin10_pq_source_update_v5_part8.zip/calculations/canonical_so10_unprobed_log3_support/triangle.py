from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import gzip,json,os,sys,threading,time
O=Path(__file__).resolve().parent;R=O.parents[1];role=sys.argv[1];assert role in ['primary','replay']
sys.path.insert(0,str(R/'calculations/canonical_so10_u_T_cutoff_tensor'))
from actual import co,dec
from algebra import ZERO,constant,multiply
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest()
for pp,h in read(O/'triangle_preparation.json')['input_sha256'].items():assert H(Path(pp))==h,pp
peer='replay' if role=='primary' else 'primary'
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        pp=Path(os.fsdecode(args[0]))
        if pp.parent.resolve()==O and (pp.name.startswith('triangle_'+peer) or pp.name.startswith('triangle_review') or pp.name in ['partial_after_known.json.gz','transport_review_result.json']):raise PermissionError('ULS_TRIANGLE_PEER_OR_TARGET_DENIED')
        if pp.parent.name in ['canonical_so10_u_lower_cutoff_contraction','canonical_so10_u_pair_contact_model']:raise PermissionError('ULS_TRIANGLE_OLD_TARGET_DENIED')
sys.addaudithook(guard);denials=0
for pp in [O/('triangle_'+peer+'_tables.json.gz'),O/'partial_after_known.json.gz',R/'calculations/canonical_so10_u_lower_cutoff_contraction/late_remainders.json.gz']:
    try:pp.read_bytes()
    except PermissionError:denials+=1
assert denials==3
def table(rows):return {tuple(z[:-1]):co(z[-1]) for z in rows}
def put(M,key,v):
    if v:M[key]=M.get(key,ZERO)+v
def clean(M):return {k:v for k,v in M.items() if v}
def enc(M):return [[*key,[[list(k),v.numerator,v.denominator] for k,v in c.terms]] for key,c in sorted(clean(M).items())]
d=load(R/('calculations/canonical_so10_unprobed_antighost_kernel/color_'+role+'_inputs.json.gz'))
q=load(R/('calculations/canonical_so10_intrinsic_quadratic_source_contacts/color_'+role+'_tables.json.gz'))
aligned=load(R/('calculations/canonical_so10_intrinsic_correlated_source_contacts/auxiliary_roots_'+role+'_inputs.json.gz'))
A=list(map(dec,q['A_original_Ja_aC']));G=dec(d['G0']);J=[{} for _ in range(45)];W=[{} for _ in range(45)]
for (h,a,b),v in table(d['J']).items():J[h][a,b]=v
for (r,c,b),v in table(d['W']).items():W[r][b,c]=v
assert A==list(map(dec,aligned['A'])) and G==dec(aligned['G0']) and J==list(map(dec,aligned['J0']))
support=load(O/('support_v2_'+role+'_tables.json.gz'));target=next(z for z in support['results'] if z['target']=='JaaC')
assert len(target['ordered_three_edge_words'])==48
for word in target['ordered_three_edge_words']:
    ll=[support['letters'][i] for i in word['letters']]
    assert sorted((z['origin'],tuple(z['external_types']),z['intrinsic_degree']) for z in ll)==[('GF',('C',),0),('GF',('a',),0),('original_source',('Ja',),0)]
    assert all(z['H_ports'][0] in ['a','C','B','L'] and z['H_ports'][1] in ['a','C','B','L'] for z in ll)
UG=[multiply(M,G) for M in J];GW=[multiply(G,M) for M in W];kernel={}
if role=='primary':
    byU=defaultdict(list);byW=defaultdict(list)
    for h,M in enumerate(UG):
        for (i,b),v in M.items():byU[i].append((h,b,v))
    for r,M in enumerate(W):
        for (b,j),v in M.items():byW[b,j].append((r,v))
    for s,M in enumerate(A):
        for (j,i),v in M.items():
            for h,b,w in byU[i]:
                for r,z in byW[b,j]:put(kernel,(s,r,h),v*w*z)
else:
    byV=defaultdict(list)
    for r,M in enumerate(GW):
        for (b,j),v in M.items():byV[b,j].append((r,v))
    for s,M in enumerate(A):
        for h,N in enumerate(J):
            for (j,b),v in multiply(M,N).items():
                for r,w in byV[b,j]:put(kernel,(s,r,h),v*w)
kernel=clean(kernel);assert all(0<=s<45 and 0<=r<45 and 0<=h<45 for s,r,h in kernel)

# The loop tensor above is formed before source transport and any comparison.
u=load(R/('calculations/canonical_so10_u_operation_root_inventory/root_'+role+'_tables.json.gz'))
names=load(R/('calculations/canonical_so10_u_maximal_heat_cutoff/'+role+'_inputs.json.gz'))['field_order']
ids={n:i for i,n in enumerate(names)};ids.update({'J'+n:643+i for i,n in enumerate(names)})
parity=lambda i:int(553<=i<643) if i<643 else 1-int(553<=i-643<643)
def canonical(word):
    odds=[i for i in word if parity(i)]
    if len(odds)!=len(set(odds)):return (),0
    return tuple(sorted(word)),(-1)**sum(a>b for at,a in enumerate(odds) for b in odds[at+1:])
images=[]
for probe,z in enumerate(u['results']):
    flows=defaultdict(list);ops=z['targets']['T']
    for pattern,nu,out,rem,value in ops['aggregate_flows']:
        if pattern!=['C','Ja','a'] or nu!=0:continue
        assert 598<=ids[out]<643 and len(rem)==1 and 180<=ids[rem[0]]<508
        flows[ids[out]-598].append((ids[rem[0]]-180,co(value)))
    image={}
    for (s,r,h),v in (kernel.items() if role=='primary' else reversed(list(kernel.items()))):
        for i,f in flows[r]:
            sign=1
            if role=='replay':
                original,sg=canonical((1241+s,598+r,553+h));at=original.index(598+r)
                prefix=(-1)**sum(parity(k) for k in original[:at]);target_word,sg2=canonical(original[:at]+(180+i,)+original[at+1:])
                assert target_word==tuple(sorted((1241+s,553+h,180+i)))
                sign=sg*prefix*sg2
            put(image,(s,h,i),(v*f)*sign)
    image=clean(image)
    images.append({'probe':probe,'target':'T','aggregate_flows':sum(map(len,flows.values())),'image':enc(image),
      'image_nonzero':len(image),'domain_positions':664200,'zero_complement':664200-len(image)})
out={'schema':'ULS5_COMPLETE_JA_A_C_THREE_EDGE_KERNEL_AND_ACTUAL_U_IMAGE','role':role,
 'density_order':'Ja_s a_r C_h; source Ja even; no extra half','kernel':enc(kernel),'kernel_nonzero':len(kernel),
 'kernel_domain':45**3,'kernel_zero_complement':45**3-len(kernel),'images':images,
 'entire48_word_specialization_checked':True,'A_J_G_inputs_equal_separately_bound_ICR':True,'guard_denials':denials,
 'normalization_inherits_qualified_AAK_S_M_G_W_Gaussian_specialization':True,'new_full_Ward_or_QAP_claim':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/('triangle_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),
 'kernel_nonzero':len(kernel),'images':[{k:v for k,v in z.items() if k!='image'} for z in images],'guard_denials':denials},sort_keys=True),flush=True);timer.cancel()
