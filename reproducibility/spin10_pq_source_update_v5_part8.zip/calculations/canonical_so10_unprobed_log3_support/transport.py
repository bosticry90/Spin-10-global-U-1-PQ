from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from fractions import Fraction
import gzip,json,os,sys,threading,time
O=Path(__file__).resolve().parent;R=O.parents[1];role=sys.argv[1];assert role in ['primary','replay']
sys.path.insert(0,str(R/'calculations/canonical_so10_u_T_cutoff_tensor'))
from actual import co
from algebra import ZERO,constant
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
for pp,h in read(O/'transport_preparation.json')['input_sha256'].items():assert sha256(Path(pp).read_bytes()).hexdigest()==h,pp
peer='replay' if role=='primary' else 'primary'
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        pp=Path(os.fsdecode(args[0]))
        if pp.parent.resolve()==O and (pp.name.startswith('transport_'+peer) or pp.name.startswith('transport_review')):raise PermissionError('ULS_TRANSPORT_PEER_DENIED')
        if pp.parent.name in ['canonical_so10_u_lower_cutoff_contraction','canonical_so10_u_pair_contact_model']:raise PermissionError('ULS_REMAINDER_DENIED')
sys.addaudithook(guard);denials=0
for pp in [O/('transport_'+peer+'_tables.json.gz'),R/'calculations/canonical_so10_u_lower_cutoff_contraction/late_remainders.json.gz',R/'calculations/canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz']:
    try:pp.read_bytes()
    except PermissionError:denials+=1
assert denials==3
assert read(O/'review_result.json')['complete_native_support_equal']
u=load(R/('calculations/canonical_so10_u_operation_root_inventory/root_'+role+'_tables.json.gz'))
data=load(R/('calculations/canonical_so10_u_maximal_heat_cutoff/'+role+'_inputs.json.gz'))
fields=data['field_order'];assert len(fields)==643 and len(set(fields))==643
ids={n:i for i,n in enumerate(fields)};ids.update({'J'+n:643+i for i,n in enumerate(fields)})
parity=lambda i:int(553<=i<643) if i<643 else 1-int(553<=i-643<643)
def canonical(word):
    odds=[i for i in word if parity(i)]
    if len(odds)!=len(set(odds)):return (),0
    return tuple(sorted(word)),(-1)**sum(a>b for k,a in enumerate(odds) for b in odds[k+1:])
def put(M,k,v):
    if v:M[k]=M.get(k,ZERO)+v
def clean(M):return {k:v for k,v in M.items() if v}
def table(rows):return {tuple(z[:-1]):co(z[-1]) for z in rows}
def encode(M):return [[*key,[[list(k),v.numerator,v.denominator] for k,v in c.terms]] for key,c in sorted(clean(M).items())]
patterns={'JxCx':(('C','Jx','x'),0),'naCx':(('C','a','x'),1),'nLx':(('L','x'),1)}

# Nonzero symbolic density fixtures derive signs without model operands.
# IDs choose actual parities/order: x180,C553,a598,JL1151,Jx823,Ja1241.
fixtures=[((823,553,180),823,(1241,),1),((598,553,180),598,(1241,),1),((508,180),508,(553,554,1151),1)]
for word,out,rem,expected in fixtures:
    w,s0=canonical(word);at=w.index(out);sg=(-1)**sum(parity(i) for i in w[:at]);nw,s1=canonical(w[:at]+rem+w[at+1:])
    target,ts=canonical(rem+tuple(i for i in word if i!=out))
    assert s0*sg*s1==expected*ts and nw==target

usr=load(R/('calculations/canonical_so10_unprobed_source_root_module/color_'+role+'_tables.json.gz'))
aak=load(R/('calculations/canonical_so10_unprobed_antighost_kernel/color_'+role+'_tables.json.gz'))
iqc=load(R/('calculations/canonical_so10_intrinsic_quadratic_source_contacts/auxiliary_'+role+'_tables.json.gz'))
native={'JxCx':{(row['h'],*key):v for row in usr['by_ghost'] for key,v in table(row['total_operator']).items()},
        'naCx':table(aak['F_m']['3']),'nLx':table(iqc['Lambda_x']['F3_vector']['entries'])}

def density(name,key):
    if name=='JxCx':h,i,j=key;return (823+i,553+h,180+j)
    if name=='naCx':a,h,j=key;return (598+a,553+h,180+j)
    a,j=key;return (508+a,180+j)
def result_key(word,target):
    xs=[i-180 for i in word if 180<=i<508];cs=[i-553 for i in word if 553<=i<598]
    src=[i-(1241 if target=='T' else 1151) for i in word if (1241<=i<1286 if target=='T' else 1151<=i<1196)]
    assert len(xs)==len(src)==1 and len(cs)==(1 if target=='T' else 2) and len(word)==(3 if target=='T' else 4)
    assert all(0<=v<45 for v in src+cs) and 0<=xs[0]<328
    return (src[0],*cs,xs[0])

results=[]
for probe,row in enumerate(u['results']):
    for target,ops in row['targets'].items():
        groups={};flow_counts={};origins=Counter()
        for name,(pattern,nu) in patterns.items():
            flows=defaultdict(list)
            for pat,degree,out,rem,value in ops['aggregate_flows']:
                if tuple(pat)!=pattern or degree!=nu:continue
                assert out in ids and all(n in ids for n in rem)
                flows[ids[out]].append((tuple(ids[n] for n in rem),co(value)))
            flow_counts[name]=sum(map(len,flows.values()))
            for v in ops['routes']:
                if tuple(v['C0_root_type'])==pattern and v['C0_intrinsic_degree']==nu:origins[str(v['QG_source_degree'])]+=1
            M={}
            if role=='primary':
                # Owning orders all place the only substituted coordinate
                # first. The field/source flow itself has already-qualified
                # UOR orientation; no extra density half is introduced.
                for key,c in native[name].items():
                    original=density(name,key);out=original[0]
                    for rem,f in flows.get(out,[]):
                        word,sg=canonical(rem+original[1:])
                        if sg:put(M,result_key(word,target),(c*f)*sg)
            else:
                # Literal odd derivation of the canonical full density.
                for key,c in reversed(list(native[name].items())):
                    word,s0=canonical(density(name,key));assert s0
                    for at,out in enumerate(word):
                        pref=(-1)**sum(parity(i) for i in word[:at])
                        for rem,f in flows.get(out,[]):
                            result,sg=canonical(word[:at]+rem+word[at+1:])
                            if sg:put(M,result_key(result,target),(c*f)*(s0*pref*sg))
            groups[name]=clean(M)
        total={}
        for M in groups.values():
            for key,c in M.items():put(total,key,c)
        total=clean(total);domain=(45*45 if target=='T' else 45*990)*328
        z={'probe':probe,'target':target,'domain_positions':domain,'groups':{name:encode(M) for name,M in groups.items()},
           'group_nonzero_counts':{name:len(M) for name,M in groups.items()},'total':encode(total),'total_nonzero':len(total),
           'zero_complement':domain-len(total),'actual_aggregate_flow_counts':flow_counts,'contributing_QG_source_degree_route_counts':dict(origins)}
        results.append(z);print('STAGE ULS3 known transport '+json.dumps({k:v for k,v in z.items() if k not in ['groups','total']},sort_keys=True),flush=True)
out={'schema':'ULS3_KNOWN_UNPROBED_LOG3_ACTUAL_U_TRANSPORT','role':role,'results':results,'graded_density_fixtures':len(fixtures),'guard_denials':denials,
     'known_qualified_loop_coefficients_reused_not_fresh_integrals':True,'three_marginal_loop_kernels_remain_unmeasured':True,'full_Bu_C0_or_Ward_claim':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/('transport_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),
 'known_counts':[[z['probe'],z['target'],z['group_nonzero_counts'],z['total_nonzero']] for z in results],'guard_denials':denials,'full_restoration_claim':False},sort_keys=True),flush=True);timer.cancel()
