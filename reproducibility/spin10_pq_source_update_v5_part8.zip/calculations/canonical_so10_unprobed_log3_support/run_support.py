from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-log3-support-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
    with p.open('xb') as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    C.mkdir(exist_ok=False)
    head=subprocess.run(['git','rev-parse','HEAD'],cwd=R,stdout=subprocess.PIPE,check=True).stdout.decode().strip()
    assert head=='a08bfe91fb66177e439f2b513a95baa371f0dbc5'
    with (C/'old_git_tree.txt').open('xb') as f:f.write(subprocess.run(['git','ls-tree','-r','--full-tree','HEAD'],cwd=R,stdout=subprocess.PIPE,check=True).stdout)
    rels=['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V653.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md',
      'calculations/canonical_so10_u_lower_cutoff_contraction/final_review_validation_receipt.json',
      'calculations/canonical_so10_u_operation_root_inventory/heat_bound_validation_receipt.json',
      'calculations/canonical_so10_u_operation_root_inventory/heat_bound_tables.json.gz',
      'calculations/canonical_so10_unprobed_source_root_module/heat_support_validation_receipt.json',
      'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']
    for role in ['primary','replay']:
        rels.extend(['calculations/canonical_so10_unprobed_source_root_module/heat_support_'+role+'_inputs.json.gz',
          'calculations/canonical_so10_intrinsic_full_source_descent/map_'+role+'_tables.json.gz',
          'calculations/canonical_so10_u_maximal_heat_cutoff/'+role+'_inputs.json.gz'])
    for name in ['.gitattributes','RECORD.md','support.py','run_support.py']:
        pp=O/name
        if pp.suffix=='.py':ast.parse(pp.read_bytes())
        with (O/(name+'.source.txt')).open('xb') as f:f.write(pp.read_bytes())
    files=[R/v for v in rels]+list(O.iterdir());bindings={str(p):H(p) for p in files if p.is_file()}
    prep={'schema':'ULS1_PREPARATION','base_HEAD':head,'previous_goal_turn':'PROGRESS; UCT complete lower-edge coefficients, partial comparison and claim dependency review',
      'input_sha256':bindings,'native_seconds_after_imports':300,'review_seconds_after_imports':180,'sampled_private_limit':8*1024**3,
      'launch_available_pagefile_floor':350*1024**2,'packet_byte_limit':32*1024**2,'scientific_acceptance':'NOT_PERFORMED'}
    dump(O/'preparation.json',prep);dump(C/'start.json',prep)
    for role in ['primary','replay']:
        z=capture([sys.executable,'-B',str(O/'support.py'),role]);dump(O/('support_'+role+'_capture.json'),z);dump(C/('support_'+role+'_full_capture.json'),z)
        assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified']
        result=[json.loads(v[7:]) for v in z['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(result)==1 and result[0]['elapsed_after_imports']<300
        dump(O/('support_'+role+'_result.json'),result[0]);print('COMPLETED ULS1 '+role,flush=True)
except BaseException:
    dump(O/'support_controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
