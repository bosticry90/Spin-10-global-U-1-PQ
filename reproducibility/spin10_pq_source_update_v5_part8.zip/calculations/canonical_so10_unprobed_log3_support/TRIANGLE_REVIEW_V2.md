# ULS6 V2: complete GF density, including external-antighost vertices

Original ULS6 failed its second deterministic context (Ja20,a24,C5):
the fresh checker returned0 against the native sqrt6 eta_H g10^3/12.
Both axis checks at the first context had passed. Exact source/copies,
preparation,complete capture and controller failure remain; no V1 receipt
or late-comparison output exists. The two model tensors are unchanged.

The checker used gf_hessian on only the supplied90 E_a/E_Lambda columns.
That shortcut cannot reconstruct H_(C,B)|a: differentiating E_a has
already removed the required external a. Its reverse completion only
fills transposes of computed entries;it cannot supply that missing port.
The old target domains without an external antighost do not automatically
license that shortcut here. The complete ACV W_B used by both natives
already retains the vertex. This is a verification-domain omission,
not evidence that a physical coefficient vanishes or that the native
formula must be fitted to the target.

V2 uses the qualified homotopy GF density reconstructed from all supplied
Euler columns, verifies that it reproduces ALL90 columns, then takes its
FULL two-field Hessian before the target restriction. Both source and
GF density derivatives keep all quantum ports/internal jets. The failed
context remains in the unchanged deterministic set and supplies a
preserved missing-vertex negative control. All full coefficient/domain,
axis/q,weight and late-comparison requirements remain. Same180s/8GiB
sampled/350MiB launchfloor/32MiB limits;no physical input or sign changes.
