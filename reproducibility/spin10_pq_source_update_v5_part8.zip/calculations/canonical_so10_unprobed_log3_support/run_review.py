from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-log3-support-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
    with p.open('xb') as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings=dict(read(O/'preparation_v2.json')['input_sha256'])
    for pp,h in bindings.items():assert H(Path(pp))==h,pp
    old=[('canonical_so10_unprobed_source_root_module','color','color_validation_receipt.json'),
         ('canonical_so10_unprobed_antighost_kernel','color','color_validation_receipt_v2.json'),
         ('canonical_so10_unprobed_auxiliary_source_kernel','color','color_validation_receipt.json'),
         ('canonical_so10_intrinsic_quadratic_source_contacts','auxiliary','auxiliary_validation_receipt.json'),
         ('canonical_so10_intrinsic_correlated_source_contacts','auxiliary_roots','auxiliary_roots_validation_receipt.json')]
    for folder,stem,receipt in old:
        P=R/'calculations'/folder;bindings[str(P/receipt)]=H(P/receipt)
        for role in ['primary','replay']:
            for kind in ['result.json','tables.json.gz']:
                pp=P/(stem+'_'+role+'_'+kind);bindings[str(pp)]=H(pp)
    for name in ['REVIEW_RECORD.md','review.py','run_review.py']:
        pp=O/name
        if pp.suffix=='.py':ast.parse(pp.read_bytes())
        with (O/(name+'.source.txt')).open('xb') as f:f.write(pp.read_bytes())
    for pp in O.iterdir():
        if pp.is_file():bindings[str(pp)]=H(pp)
    dump(O/'review_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    z=capture([sys.executable,'-B',str(O/'review.py')]);dump(O/'review_capture.json',z);dump(C/'review_full_capture.json',z)
    assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified']
    assert read(O/'review_result.json')['elapsed_after_imports']<180
    print('COMPLETED ULS2 support and actual C3 reuse',flush=True)
except BaseException:
    dump(O/'review_controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
