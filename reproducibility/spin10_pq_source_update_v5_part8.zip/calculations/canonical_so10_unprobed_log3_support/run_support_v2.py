from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-log3-support-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
    with p.open('xb') as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    prep=read(O/'preparation.json');bindings=dict(prep['input_sha256'])
    for pp,h in bindings.items():assert H(Path(pp))==h,pp
    failed=read(O/'support_primary_capture.json');assert failed['execution_state']=='FAILED' and failed['exit_code']==1
    assert not (O/'support_primary_tables.json.gz').exists() and not (O/'support_replay_capture.json').exists()
    for name in ['CONTINUATION_V2.md','support_v2.py','run_support_v2.py']:
        pp=O/name
        if pp.suffix=='.py':ast.parse(pp.read_bytes())
        with (O/(name+'.source.txt')).open('xb') as f:f.write(pp.read_bytes())
    for pp in O.iterdir():
        if pp.is_file():bindings[str(pp)]=H(pp)
    dump(O/'preparation_v2.json',{**prep,'input_sha256':bindings,'preserved_original_disposition':'FAILED_PARSER_NO_TABLE; REPLAY_NOT_LAUNCHED'})
    for role in ['primary','replay']:
        z=capture([sys.executable,'-B',str(O/'support_v2.py'),role]);dump(O/('support_v2_'+role+'_capture.json'),z);dump(C/('support_v2_'+role+'_full_capture.json'),z)
        assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified']
        result=[json.loads(v[7:]) for v in z['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(result)==1 and result[0]['elapsed_after_imports']<300
        dump(O/('support_v2_'+role+'_result.json'),result[0]);print('COMPLETED ULS1 V2 '+role,flush=True)
except BaseException:
    dump(O/'support_v2_controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
