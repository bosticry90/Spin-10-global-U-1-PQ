# ULS3: actual known B_u C0 log3 contributions, prospective

ULS2 passed support and exact old-C3 reuse. Freeze before applying the
actual qualified UOR operation to the reused kernels. Only three reused
C3 kernels are nonzero: Jx Cx (USR), intrinsic aCx (AAK), intrinsic
Lambda x (IQC). Ja JL C, intrinsic JL Cx and intrinsic Ja x have their
complete zero qualifications. Three NEW marginal types remain unmeasured.

For each probe/target retain every UOR aggregate flow, its actual
source/cotangent orientation and original QG source-degree provenance.
Scalar-source and antighost densities have the owning order Jx Cx and
a Cx; Lambda x is even. The full q operation is odd. Primary applies
component source/field substitutions to these owning density orders.
Replay first canonicalizes the complete actual quantum monomials, then
uses the literal odd graded Leibniz rule and canonical exterior algebra.
No rho operation is substituted for the even-u QG operation. Sources
were differentiated before restriction in the qualified UOR inputs.

Primary/replay must agree on each complete contribution, sum and implicit
zero complement, not selected values. Preserve the ordinary a scaling/
source pieces and all source2 terms that actually reach this projection.
Check nonzero graded sign fixtures before model use. Keep old remainder
and peer-output access guards. No new loop integral is performed.

Only after full native agreement may later review add these known images
to UCT's authenticated PARTIAL log3 remainders. Preserve all resulting
coefficients. The three unmeasured marginal kernels, defect-inclusive
identity and common-product applicability remain required regardless of
whether a partial sum vanishes. No anomaly or restoration verdict from
an incomplete sum. No fitted coefficient, source sign or baseline.

Same300s/native,180s/review,private8GiB sampled,350MiB launchfloor,
32MiB total packet and authority ceiling. All original failure evidence
retained. Freeze inputs/source copies before launch,exclusive outputs.
