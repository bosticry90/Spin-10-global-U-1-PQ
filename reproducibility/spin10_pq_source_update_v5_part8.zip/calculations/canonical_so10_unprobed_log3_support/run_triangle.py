from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-log3-support-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
    with p.open('xb') as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings=dict(read(O/'transport_review_preparation.json')['input_sha256'])
    for pp,h in bindings.items():assert H(Path(pp))==h,pp
    assert read(O/'transport_review_result.json')['complete_native_images_and_zero_complements_equal']
    for role in ['primary','replay']:
        for folder,name in [('canonical_so10_unprobed_antighost_kernel','color_'+role+'_inputs.json.gz'),
          ('canonical_so10_intrinsic_quadratic_source_contacts','color_'+role+'_tables.json.gz'),
          ('canonical_so10_intrinsic_correlated_source_contacts','auxiliary_roots_'+role+'_inputs.json.gz')]:
            pp=R/'calculations'/folder/name;bindings[str(pp)]=H(pp)
    for rel in ['calculations/canonical_so10_unprobed_antighost_kernel/universal_validation_receipt.json',
                'calculations/canonical_so10_unprobed_antighost_kernel/PROOF.md',
                'calculations/canonical_so10_unprobed_antighost_vertices/RESULT.md']:
        pp=R/rel;bindings[str(pp)]=H(pp)
    for name in ['TRIANGLE_RECORD.md','triangle.py','run_triangle.py']:
        pp=O/name
        if pp.suffix=='.py':ast.parse(pp.read_bytes())
        with (O/(name+'.source.txt')).open('xb') as f:f.write(pp.read_bytes())
    for pp in O.iterdir():
        if pp.is_file():bindings[str(pp)]=H(pp)
    dump(O/'triangle_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    for role in ['primary','replay']:
        z=capture([sys.executable,'-B',str(O/'triangle.py'),role]);dump(O/('triangle_'+role+'_capture.json'),z);dump(C/('triangle_'+role+'_full_capture.json'),z)
        assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified']
        result=[json.loads(v[7:]) for v in z['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(result)==1 and result[0]['elapsed_after_imports']<300
        dump(O/('triangle_'+role+'_result.json'),result[0]);print('COMPLETED ULS5 '+role,flush=True)
except BaseException:
    dump(O/'triangle_controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
