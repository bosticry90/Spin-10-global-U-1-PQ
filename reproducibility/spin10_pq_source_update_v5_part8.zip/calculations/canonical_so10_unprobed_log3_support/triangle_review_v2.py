from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import defaultdict
import ast,gzip,json,os,sys,threading,time
O=Path(__file__).resolve().parent;R=O.parents[1]
sys.path.insert(0,str(R/'calculations/canonical_so10_u_F_fourth_support'))
import operators as OP
from operators import decode,co,dec,Coeff,ZERO,constant
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest()
for pp,h in read(O/'triangle_review_preparation_v2.json')['input_sha256'].items():assert H(Path(pp))==h,pp
def unpack(rows):
    out={tuple(z[:-1]):Coeff([(tuple(k),Fraction(n,d)) for k,n,d in z[-1]]) for z in rows}
    assert len(out)==len(rows) and all(out.values());return out
def put(M,k,v):
    if v:M[k]=M.get(k,ZERO)+v
def clean(M):return {k:v for k,v in M.items() if v}
def enc(M):return [[*key,[[list(k),v.numerator,v.denominator] for k,v in c.terms]] for key,c in sorted(M.items())]
ab=[]
for role in ['primary','replay']:
    assert H(O/('triangle_'+role+'_tables.json.gz'))==read(O/('triangle_'+role+'_result.json'))['packed_sha256']
    ab.append(load(O/('triangle_'+role+'_tables.json.gz')))
assert {k:v for k,v in ab[0].items() if k!='role'}=={k:v for k,v in ab[1].items() if k!='role'}
kernel=unpack(ab[0]['kernel']);assert len(kernel)==ab[0]['kernel_nonzero'] and len(kernel)+ab[0]['kernel_zero_complement']==45**3
images={z['probe']:unpack(z['image']) for z in ab[0]['images']}
for z in ab[0]['images']:assert len(images[z['probe']])==z['image_nonzero'] and len(images[z['probe']])+z['zero_complement']==664200
assert all(z['guard_denials']==3 and z['entire48_word_specialization_checked'] for z in ab)

# Fresh uncut full-Lorentz original-action calculation, no A/J/G/W formula.
d=load(R/'calculations/canonical_so10_u_maximal_heat_cutoff/primary_inputs.json.gz')
gradient={i:decode(z) for i,z in d['GF_gradient']}
tree=ast.parse((R/'calculations/canonical_so10_u_F_fourth_support/operators.py').read_bytes())
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['gf_hessian','gf_primitive','hessian','source_density']]
keys=sorted(kernel);contexts=[keys[min(len(keys)-1,j*len(keys)//4)] for j in range(4)]+[(0,0,0),(12,12,12)]
fresh=[]
for s,r,h in contexts:
    selected={1241+s:1,598+r:2,553+h:4}
    def allowed(word,nd,low,high):
        if nd!=0 or not low<=len(word)<=high or any(js or i not in selected for i,js in word):return None
        ids=tuple(i for i,js in word)
        if len(ids)!=len(set(ids)):return None
        return ids
    ns=dict(vars(OP));ns['allowed']=allowed
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'ULS6_ORIGINAL_RAW_HESSIANS','exec'),ns)
    density=ns['gf_primitive'](gradient)
    raw=ns['hessian'](density,'primary',1,3)
    source=ns['hessian'](ns['source_density'](d),'primary',1,3)
    for k,v in source.items():put(raw,k,v)
    raw=clean(raw)
    for axis,q in [(3,1),(2,-1)]:
        V={}
        for (i,j,word,nd,power),v in raw.items():
            if any(p for mu,p in enumerate(power) if mu!=axis):continue
            mask=sum(selected[k] for k in word);odds=[selected[k] for k in word if selected[k] in [2,4]]
            sg=(-1)**sum(a>b for at,a in enumerate(odds) for b in odds[at+1:]);v=v*(sg*q**sum(power))
            folded=[]
            if i<180:
                color,mu=divmod(i,4);folded=[(i,co('eta_H' if color<12 else 'xi') if mu==axis else constant(1))]
                if mu==axis:folded.append((508+color,constant(q)))
            elif i<508:folded=[(i,constant(1))]
            elif i<553:folded=[(4*(i-508)+axis,constant(-q))]
            elif i<598:folded=[(i+45,constant(-1))]
            else:folded=[(i-45,constant(1))]
            for a,f in folded:put(V,(a,j,mask),v*f)
        V=clean(V);by=defaultdict(list)
        for (i,j,m),v in V.items():by[i].append((j,m,v))
        power={(i,i,0):constant(1) for i in range(643)}
        for n in range(3):
            out={}
            for (i,k,m),v in power.items():
                for j,m2,w in by[k]:
                    if m&m2:continue
                    sg=-1 if m&4 and m2&2 else 1
                    put(out,(i,j,m|m2),(v*w)*sg)
            power=clean(out)
        value=ZERO
        for (i,j,m),v in power.items():
            if i==j and m==7:value=value+v*((-1)**int(i>=553))
        value=value*constant(Fraction(1,6));assert value==kernel.get((s,r,h),ZERO),(s,r,h,axis,q,str(value),str(kernel.get((s,r,h),ZERO)))
        fresh.append({'source_Ja':s,'ordinary_a':r,'ghost':h,'axis':axis,'q':q,'coefficient':str(value),'full_uncut_power_equal':True})
        print('STAGE ULS6 fresh uncut '+json.dumps(fresh[-1],sort_keys=True),flush=True)

# Late partial comparison only after fresh action and full tensor agreement.
assert H(O/'partial_after_known.json.gz')==read(O/'transport_review_result.json')['packed_partial_sha256']
old=load(O/'partial_after_known.json.gz');late=[];saved=[]
for probe in range(2):
    previous=unpack(next(z for z in old['partial_tensors'] if z['probe']==probe and z['target']=='T')['partial_after_known_Bu_C0'])
    combined=dict(previous)
    for key,v in images[probe].items():put(combined,key,v)
    combined=clean(combined)
    late.append({'probe':probe,'target':'T','basis':'log3','previous_partial_nonzero':len(previous),'last_measured_image_nonzero':len(images[probe]),
       'complete_declared_T_log3_sum_nonzero':len(combined),'complete_declared_T_log3_sum_zero':not combined,
       'full_finite_Ward_or_QAP_not_inferred':True})
    saved.append({'probe':probe,'target':'T','basis':'log3','sum':enc(combined)})
payload={'schema':'ULS6_COMPLETE_DECLARED_T_LOG3_COMPARISON','results':late,'tensors':saved,'full_Ward_claim':False}
blob=gzip.compress((json.dumps(payload,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with (O/'T_log3_complete_comparison_v2.json.gz').open('xb') as f:f.write(blob)
out={'schema':'ULS6_COMPLETE_TRIANGLE_AND_T_LOG3_REVIEW','complete_kernel_images_and_zero_complements_equal':True,
 'kernel_domain':45**3,'kernel_nonzero':len(kernel),'kernel_zero_complement':45**3-len(kernel),
 'fresh_uncut_checks':fresh,'late_complete_declared_T_log3_comparisons':late,
 'F_missing_marginal_C3_types':['JLaCC','JLJLCC'],'packed_comparison_sha256':sha256(blob).hexdigest(),
 'full_Ward_QAP_or_scientific_promotion':False,'preserved_V1_failed_context_rechecked':any(z['source_Ja']==20 and z['ordinary_a']==24 and z['ghost']==5 and co(z['coefficient']) for z in fresh),'elapsed_after_imports':time.perf_counter()-tick}
with (O/'triangle_review_result_v2.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({k:v for k,v in out.items() if k!='fresh_uncut_checks'},sort_keys=True),flush=True);timer.cancel()
