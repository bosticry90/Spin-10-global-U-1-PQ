from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-log3-support-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
    with p.open('xb') as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings=dict(read(O/'triangle_review_preparation.json')['input_sha256'])
    for pp,h in bindings.items():assert H(Path(pp))==h,pp
    assert read(O/'triangle_review_capture.json')['execution_state']=='FAILED'
    assert not (O/'triangle_review_result.json').exists() and not (O/'T_log3_complete_comparison.json.gz').exists()
    for name in ['TRIANGLE_REVIEW_V2.md','triangle_review_v2.py','run_triangle_review_v2.py']:
        pp=O/name
        if pp.suffix=='.py':ast.parse(pp.read_bytes())
        with (O/(name+'.source.txt')).open('xb') as f:f.write(pp.read_bytes())
    for pp in O.iterdir():
        if pp.is_file():bindings[str(pp)]=H(pp)
    dump(O/'triangle_review_preparation_v2.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED','old_failed_review_preserved':True})
    z=capture([sys.executable,'-B',str(O/'triangle_review_v2.py')]);dump(O/'triangle_review_v2_capture.json',z);dump(C/'triangle_review_v2_full_capture.json',z)
    assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified']
    result=read(O/'triangle_review_result_v2.json');assert result['elapsed_after_imports']<180 and result['preserved_V1_failed_context_rechecked']
    print('COMPLETED ULS6 V2 '+json.dumps(result['late_complete_declared_T_log3_comparisons'],sort_keys=True),flush=True)
except BaseException:
    dump(O/'triangle_review_v2_controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
