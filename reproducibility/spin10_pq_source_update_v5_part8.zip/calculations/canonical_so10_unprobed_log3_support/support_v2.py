from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from itertools import combinations,permutations
import gzip,json,os,re,sys,threading,time

O=Path(__file__).resolve().parent;R=O.parents[1];role=sys.argv[1];assert role in ['primary','replay']
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
for pp,h in read(O/'preparation_v2.json')['input_sha256'].items():assert sha256(Path(pp).read_bytes()).hexdigest()==h,pp

peer='replay' if role=='primary' else 'primary'
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        pp=Path(os.fsdecode(args[0]))
        if pp.parent.resolve()==O and ((pp.name.startswith('support_'+peer) or pp.name.startswith('support_v2_'+peer)) or pp.name.startswith('review_')):raise PermissionError('ULS_PEER_DENIED')
        if pp.parent.name in ['canonical_so10_u_lower_cutoff_contraction','canonical_so10_u_pair_contact_model']:raise PermissionError('ULS_OLD_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard);denials=0
for pp in [O/('support_'+peer+'_tables.json.gz'),R/'calculations/canonical_so10_u_lower_cutoff_contraction/late_remainders.json.gz',R/'calculations/canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz']:
    try:pp.read_bytes()
    except PermissionError:denials+=1
assert denials==3

d=load(R/('calculations/canonical_so10_unprobed_source_root_module/heat_support_'+role+'_inputs.json.gz'))
source=load(R/('calculations/canonical_so10_intrinsic_full_source_descent/map_'+role+'_tables.json.gz'))
actual=load(R/('calculations/canonical_so10_u_maximal_heat_cutoff/'+role+'_inputs.json.gz'))
targets=[('JLJLCC',0,('C','C','JL','JL')),('JLaCC',0,('C','C','JL','a')),
 ('JaJLC',0,('C','JL','Ja')),('nJLCx',1,('C','JL','x')),
 ('JaaC',0,('C','Ja','a')),('JxCx',0,('C','Jx','x')),
 ('naCx',1,('C','a','x')),('nJax',1,('Ja','x')),('nLx',1,('L','x'))]
dim2={'B':2,'L':4,'C':2,'a':2,'x':2,'P':3,'JL':2,'Ja':4,'JC':4,'Jx':4}
fields={'B','L','C','a','x','P'};kinds=sorted(dim2)
target_vectors={name:(nu,*[pat.count(k) for k in kinds]) for name,nu,pat in targets}
sub=lambda a,b:tuple(x-y for x,y in zip(a,b));sat=lambda a:all(x>=0 for x in a)
aux={('b' if i<12 else 'L')+str(i) for i in range(45)}
ants={('bar' if i<12 else 'ub')+str(i) for i in range(45)}
def kind(n):
    if n in aux:return 'L'
    if n in ants:return 'a'
    if n=='B' or re.fullmatch(r'B\d+_[0-3]',n):return 'B'
    if re.fullmatch(r'C\d+',n):return 'C'
    if n.startswith('x_'):return 'x'
    return None

catalog=defaultdict(list);excluded=Counter();free=[];oneport=[];backgrounds=set();origins=Counter()
def add(origin,nu,ports,ext,ref):
    if nu not in [0,1]:excluded['outside_intrinsic0_1']+=1;return
    if any(jets for k,jets in ext):excluded['external_jet']+=1;return
    counts=Counter(k for k,j in ext);grade=(nu,*[counts[k] for k in kinds])
    eligible=[name for name,t in target_vectors.items() if sat(sub(t,grade))]
    if not eligible:excluded['outside_all_target_complements']+=1;return
    if not any(grade):
        assert all(k in fields for k,j in ports)
        assert tuple(sorted(k for k,j in ports)) in [('B','B'),('B','L'),('C','a'),('L','L'),('x','x')]
        free.append([origin,ref,[list(v) for v in ports]]);return
    key=(origin,nu,tuple(sorted(k for k,j in ext)),ports[0][0],ports[1][0],ports[0][1],ports[1][1])
    catalog[key].append(ref)

def density_ports(word,origin,nu,ref):
    pp=[i for i,(k,jets) in enumerate(word) if k in fields]
    origins[origin]+=1
    if len(pp)<2:
        oneport.append([origin,ref,[list(v) for v in word]]);return
    if role=='primary':choices=((a,b) for a in pp for b in pp if a!=b)
    else:
        choices=[]
        for ext in combinations(range(len(word)),len(word)-2):
            qp=[i for i in range(len(word)) if i not in ext]
            if all(i in pp for i in qp):choices.extend([tuple(qp),tuple(qp[::-1])])
    for a,b in choices:add(origin,nu,[word[a],word[b]],[v for i,v in enumerate(word) if i not in [a,b]],[*ref,a,b])

for i,row in enumerate(d['GF']):
    word=[]
    for token in row['word']:
        n,sep,jets=token.partition('__');k=kind(n)
        if k is None:
            assert re.fullmatch(r'A\d+_[0-3]',n),n
            backgrounds.add(n);excluded['GF_background_at_A0']+=1;break
        word.append((k,len(jets)))
    else:density_ports(word,'GF',(8-sum(dim2[k]+2*j for k,j in word))//2,[i])

for i,(word,value) in enumerate(source['Sigma_source_nonminimal_C']):
    tokens=[]
    for k in word:
        assert 0<=k<270
        tag='JL' if k<45 else 'Ja' if k<90 else 'JC' if k<135 else 'C' if k<180 else 'a' if k<225 else 'L'
        tokens.append((tag,0))
    assert 8==sum(dim2[k]+2*j for k,j in tokens)
    density_ports(tokens,'original_source',0,[i])

# Actual nonzero source-current rows, retaining every scalar component.
for a,mat in enumerate(actual['R']):
    for i,j,value in mat['entries']:
        density_ports([('Jx',0),('C',0),('x',0)],'scalar_source',0,[a,i,j])

for term in d['physical_graphs']:
    for idx,(parameters,nodes,value) in enumerate(term['index_jet_graph_coefficients']):
        internal={};external=[]
        for node,n,indices,jets in nodes:
            if node!='Field':continue
            if n.startswith('h_'):internal['h']=(kind(n[2:]),len(jets))
            elif n.startswith('k_'):internal['k']=(kind(n[2:]),len(jets))
            else:external.append((kind(n),len(jets)))
        assert set(internal)=={'h','k'} and all(k in fields for k,j in list(internal.values())+external)
        add(term['term_id'],0,[internal['h'],internal['k']],external,[idx])

add('ABSTRACT_potential_cubic',1,[('x',0),('x',0)],[('x',0)],['arbitrary_tensor'])
add('ABSTRACT_potential_quartic',0,[('x',0),('x',0)],[('x',0),('x',0)],['arbitrary_tensor'])
add('ABSTRACT_potential_mass',2,[('x',0),('x',0)],[],['arbitrary_tensor'])
add('ABSTRACT_fermion_Yukawa',0,[('P',0),('P',0)],[('x',0)],['arbitrary_tensor'])
add('ABSTRACT_fermion_mass',1,[('P',0),('P',0)],[],['arbitrary_tensor'])

letters=[]
for key,refs in sorted(catalog.items()):
    origin,nu,ext,left,right,j1,j2=key
    letters.append({'id':len(letters),'origin':origin,'intrinsic_degree':nu,'external_types':list(ext),
      'grade':[nu,*[ext.count(k) for k in kinds]],'H_ports':[left,right],
      'internal_jet_orders':[j1,j2],'member_references':sorted(refs,key=str)})
G={('B','B'),('B','L'),('L','B'),('C','a'),('a','C'),('x','x'),('P','P')};sectors=sorted(fields);results=[]
for name,nu,pat in targets:
    target=target_vectors[name];active=[z['id'] for z in letters if sat(sub(target,z['grade']))]
    opts={i:[(s,letters[i]['H_ports'][1]) for s in sectors if (s,letters[i]['H_ports'][0]) in G] for i in active}
    found=set()
    if role=='primary':
        edges=defaultdict(list)
        for i in active:
            for start,to in opts[i]:edges[start].append((i,to))
        def walk(start,at,left,w,path):
            if len(w)==3:
                if not any(left) and start==at:found.add((tuple(w),tuple(path)))
                return
            for i,to in edges[at]:
                rem=sub(left,letters[i]['grade'])
                if sat(rem):walk(start,to,rem,w+[i],path+[to])
        for start in sectors:walk(start,start,target,[],[start])
    else:
        multis=[]
        def choose(lo,left,w):
            if len(w)==3:
                if not any(left):multis.append(tuple(w))
                return
            for at in range(lo,len(active)):
                i=active[at];rem=sub(left,letters[i]['grade'])
                if sat(rem):choose(at,rem,w+[i])
        choose(0,target,[])
        for ms in multis:
            for w in set(permutations(ms)):
                def attach(at,path):
                    if at==3:
                        if path[-1]==path[0]:found.add((w,tuple(path)))
                        return
                    for start,to in opts[w[at]]:
                        if not path or start==path[-1]:attach(at+1,(path or [start])+[to])
                attach(0,[])
    words=[];abstract=Counter();signatures=Counter()
    for w,path in sorted(found):
        assert len(w)==3 and len(path)==4
        for j in range(3):assert (w[j:]+w[:j],path[j:-1]+path[:j]+(path[j],)) in found
        for i in w:
            if letters[i]['origin'].startswith('ABSTRACT'):abstract[letters[i]['origin']]+=1
        signatures[tuple(sorted(letters[i]['origin'] for i in w))]+=1
        words.append({'letters':list(w),'Green_path':list(path),'STr_sign':(-1)**int(path[0] in ['a','C','P']),
          'ordered_log_weight':[1,6]})
    z={'target':name,'intrinsic_degree':nu,'external_types':list(pat),'ordered_three_edge_words':words,
       'candidate_words':len(words),'abstract_superfamily_occurrences':dict(abstract),
       'origin_family_counts':[[list(k),v] for k,v in sorted(signatures.items())]}
    results.append(z);print('STAGE ULS1 support '+json.dumps({k:v for k,v in z.items() if k!='ordered_three_edge_words'},sort_keys=True),flush=True)

out={'schema':'ULS1_UNPROBED_THREE_EDGE_COMPLETE_SUPPORT','role':role,'letters':letters,'results':results,'source_density_origin_rows':dict(origins),
     'background_exclusions_verified':sorted(backgrounds),'resummed_reference_candidates':free,'one_port_or_source_only_exclusions':oneport,
     'excluded':dict(excluded),'guard_denials':denials,'new_quantum_coefficients_or_full_Ward_claim':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/('support_v2_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),
 'letters':len(letters),'targets':[[z['target'],z['candidate_words'],z['abstract_superfamily_occurrences']] for z in results],
 'guard_denials':denials,'quantum_tensor_measured':False},sort_keys=True),flush=True);timer.cancel()
