# ULS2 support qualification and exact coefficient reuse, prospective

Both V2 support routes have completed. Authenticate complete compressed
tables, not printed counts. Compare every letter/member reference,
exclusion, derivative assignment and ordered three-edge path. Check
positive-grade closure, cyclic support, source-only/one-port exclusions,
and absence/presence of the abstract potential/fermion supersets in the
completed cycles. A surviving abstract word must remain a missing input.

Only AFTER native support agreement authenticate the old unprobed quantum
tables against their native packed hashes and read their qualified
review receipts. Compare both old routes on the specific C3/log3 tensor
and every zero complement, with actual field/source types:
USR Jx Cx;AAK intrinsic aCx;UAK intrinsic JL Cx;IQC intrinsic Lambda x;
ICR Ja JL C. Intrinsic Ja x is three-edge support-zero here and has the
separately qualified IQC block-zero premise. Do not infer any changed
input, operation, inverse coupling or finite normalization from counts.

Record ownership, exact nonzero/zero domains, common hbar/(16pi^2),
original reference and the no-extra-half convention. New missing
marginal Ja aC,JL aCC,JL JL CC coefficients remain unmeasured; their
catalogue is not a tensor result. This review is authenticated reuse of
old physics, not fresh replay of their calculations. No old Ward
remainder is a native or review operand. Review180s,private8GiB sampled,
350MiB launchfloor,32MiB packet; original authority ceiling unchanged.
