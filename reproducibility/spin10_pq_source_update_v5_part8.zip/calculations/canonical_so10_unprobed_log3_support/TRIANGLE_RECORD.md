# ULS5: complete unprobed Ja-a-C three-edge kernel, prospective

ULS4 qualifies complete known B_u C0 contributions; the partial T log3
sum remains nonzero. UOR permits only one still-unmeasured C0 type in T
at log3: Ja a C. Ja JL C and intrinsic JL Cx are qualified C3 zero;
intrinsic Ja x is support zero; JaJa has native heat bound2. The other
two missing marginal C0 types reach F, not T. This makes the complete
Ja a C THREE-edge class the next discriminating calculation.

The48 ordered ULS words all contain one Ja source Hessian A, one
ordinary external-C ghost current J and one ordinary external-a current W.
There is no positive-grade room for a fourth or a gradezero proper
vertex. The source Ja is even. In the owning density order Ja_s a_r C_h,
the three-edge coefficient is

    K[s,r,h]=Tr(A_s J_h G0 W_r).

This follows by linear specialization of AAK's independently qualified
S_M_G_W Gaussian kernel: replace the even nx*S insertion by even Ja*A,
and remove N,X,Mn,Wn,Y,Z from that particular coefficient. No rho source,
antisymmetric-source half or additional diagram symmetry factor is
imported. AAK's literal paired-Gaussian/Schur proof fixes its PLUS sign
and common hbar/(16pi^2); that proof is inherited, not freshly replayed.
The new48-word support must match this entire specialized class before
qualification. The old actual ACV Lorentz theorem applies to the same
J/W endpoints; A has no vector/derivative port, so no new free D trace
or dimensional correction is introduced. This is log3 only, not the full
two-edge/absolute Ja a C counterterm or full Ward theorem.

Actual A comes from IQC's A_original_Ja_aC; J/W/G0 come from AAK's bound
ACV inputs. Verify aligned inputs against ICR's independently bound A/J/G.
Retain both B and Lambda currents and reference widths. Primary explicit
indexed sums using JG versus replay reassociated A*J against G*W must
agree over all45^3 positions and their zero complement. Store the actual
kernel before comparing any Ward remainder. No coefficient is fitted.

Then derive its T image from every UOR Ja a C aggregate flow. Primary
component substitution versus replay literal odd Leibniz in the complete
Ja a C density, with actual even-Ja/odd-a/C parities. Full original
source-degree provenance retained. No rho transformation substitution.
Native access guards deny old remainders, current partial sums and peers.
Only later review may add the resulting image ONCE to ULS4's partial T.
Preserve nonzero or zero outcomes without changing signs or parameters.

Native300s/role,review180s,private8GiB sampled,350MiB launchfloor,
32MiB total packet. Freeze sources/input hashes before launch. Existing
ULS failure evidence remains unchanged. This is original unshifted A0,
intrinsic0 kernel transported into intrinsic1,external jets0 after
differentiation,Euclidean LOCAL RELATIVE formal UV symbol. No new
normalization/scheme,continuum QAP/contact/measure or authority promotion.
chi4,b0,kappa,IR freedoms distinct/unfixed; state113/34of39/E5/A5 OPEN.
