# Final bounded checkpoint audits, prospective

After ULS1-6 V2 qualification, run exactly once
`python -B tools/research_check.py e4`, without --fresh, before local
commit. Freeze command/tool/live policy/state and completed result bytes.
Retain full stdout/stderr and owned-process resource capture. Expected
native0,step exits[0,0,0,0,0,2],terminalCOMPLETED,custodysevenNOTPASS.
This authenticates existing sealed evidence/current bounded audits,
not fresh whole physics replay,full quantum acceptance or promotion.
Same300s effort ceiling,8GiB sampled private,350MiB launchfloor,32MiB
packet. Preserve failure/incompleteness separately;no automatic retry.
