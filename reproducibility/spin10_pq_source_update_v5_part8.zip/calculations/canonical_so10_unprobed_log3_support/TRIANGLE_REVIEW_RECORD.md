# ULS6: triangle qualification, fresh uncut check and late T test

Both ULS5 routes completed. First authenticate every kernel/image
coefficient and full zero complement. Then freshly reconstruct selected
full four-component original-action Hessians from GF Euler columns and
the original source density, with no triangle block formula as oracle.
Use literal tagged third powers of the full G0 V matrix, actual graded
exterior order and1/6 STr weight. Four deterministic nonzero tensor
contexts plus two fixed zeros,each at axis3/q+ and axis2/q-, supplement
the complete48-word proof and tensor comparison. They do not replace
whole-domain comparison. No old Ward remainder chooses their values.

The free four-component reference has transverse BB=I,longitudinal
BB=width,BL=-q,LB=q,LL=0,scalarI,Ca=I,aC=-I at unit momentum.
All raw differentiated coefficients/internal jets stay until this
Fourier evaluation. Target external means are Ja_s,a_r,C_h,linear in
each; zero intrinsic degree. Source Ja is even,a/C odd in that order.
No unresummed gradezero vertex is admitted. Physical potential/fermion
sectors have the owning complete support exclusions.

Only after full new agreement and these uncut checks may review add
the actual triangle image ONCE to ULS4 partial_after_known. Preserve
all results,zero or nonzero. This completes the declared T log3 input
inventory,not full Ward/QAP or all finite bases. F retains two missing
marginal C3 kernels; b0,kappa,chi4 and IR freedoms stay unfixed. No
target-fitted sign/normalization. Review180s,private8GiB sampled,
350MiB launchfloor,32MiB packet. Preserve every failed/incomplete check.
