# ULS1-3: actual unprobed three-edge support and reuse, prospective

Basea08bfe91fb66177e439f2b513a95baa371f0dbc5. Fresh preflight clean
main/no matching workers,current AGENTS/highestV653 and actual UCT/UOR
receipts read. Previous goal turn PROGRESS: complete C2/C3 plus preserved
nonzero PARTIAL comparisons and identification of missing B_u C0.
Goal ACTIVE/incomplete; project_state sole scientific authority,
state113/34of39,E5/A5 OPEN,custodyexit2/seven unresolved unchanged.

Question: which actual unprobed C0 THREE-edge kernels are needed for
the missing B_u C0 log3 contribution, and which can be reused? The
qualified UOR native heat bound<=4 and carrier chi4+log(m/2) isolate
log3 to m3. Its JaJa root has bound2, leaving nine candidate types.
This is a selection of the missing input, not a change of final goal.
No old late remainder is an input or value to fit.

Same original unshifted SMA/CSW/EDS,A0,constant u,intrinsic0/1 as
required by each unprobed root,external jets0 AFTER differentiation,
symbolic g10/xi/eta_H,nonexceptional Euclidean LOCAL RELATIVE formal
DIM-minus-strict-heat symbol. Keep ordinary a/Lambda, ghost C and all
source types, derivative placements and the original quantum ports.
Sources are external only; original source-only and one-port terms
must be classified before proper-Hessian exclusion.

ULS1: use full actual GF rows, original nonminimal/ghost source density,
physical kinetic graphs and the actual scalar source Jx C R x density.
Classify all external/quantum port assignments for the nine C0 targets.
Retain generic potential and isolated-fermion supersets; absence of
their coefficients is not a zero-amplitude assumption. Zero-grade
reference terms stay resummed; no unresummed gradezero vertex is allowed
in a proper word. Check all source/field types and background exclusions.

Primary quantum-port-first versus replay external-complement-first
enumerations must agree on every letter/reference and exclusion. Then
directed THREE-edge closed paths versus graded-saturated multisets and
permutations must agree on all ordered typed words, paths, derivative
roles and supertrace starting signs. The catalogue is overinclusive:
allowed words are not nonzero coefficients or independent integrals.
No component coefficient tensor is claimed measured here.

ULS2/3: authenticate completed old kernel/zero/heat receipts. Identify
the actual three-edge coefficients and their exact ownership, including
complete zero complements, before adopting a reuse decision. Do not
infer equality from counts or transfer rho transformations to u.
Read old quantum kernels only in later review after native support
agreement. Differentiate original QG at all source degrees and with
its actual cotangent phases before a later B_u C0 integration. If a
required kernel remains missing, reduce it rather than define it from
the negative remainder. A full Ward verdict still requires its complete
defect-inclusive identity and common finite-part applicability.

Native300s/role after imports,review180s,private8GiB sampled,launch
available-pagefile350MiB,total packet32MiB. Two sequential native roles;
no agents or parallel organization. Freeze input hashes/source copies
before computation,exclusive outputs,owned PID/creation,complete stdout
and resource samples. Preserve all failures/incomplete work; no hidden
budget expansion. Distinct enumeration routes share action,reference,
charts,types,software and AI authorship; no external physical validation.

Focused result-to-claim assessment in existing RESULT. No continuum
product/contact/QAP/measure,source-reality,global phase,causal/massive/
physical or E5/A5 claim. chi4,b0,kappa,IR freedoms stay distinct/unfixed.
No protected activation,foundation/benchmark/scheme adoption,promotion,
branch/worktree,remote push,publication or outreach. Before local commit,
E4 once without --fresh,complete evidence validation and raw staged-byte
preservation; custodyexit2 is NOTPASS.
