# The missing unprobed input closes the complete declared T log3 relation

The complete unprobed Ja-a-C three-edge kernel is now calculated and
checked. Its actual u-operation image cancels all7,424 remaining T log3
coefficient positions after the other qualified unprobed inputs are
included. Both probes have zero complete declared T log3 sums. No source
sign, physical parameter, unknown loop coefficient or finite baseline was
fitted to obtain that equality.

The F log3 comparison remains partial and nonzero, with two marginal
unprobed C3 kernels still unmeasured. This result is a fixed-reference
formal coefficient identity, not full finite Ward restoration, QAP,
E5/A5 or physical validation. Goal ACTIVE/incomplete. project_state
remains sole authority: state113,34/39,E5/A5 OPEN,custodyexit2/seven
unresolved NOTPASS. Director scientific acceptance NOT_PERFORMED.

## Actual support and reuse

[Support/reuse review](review_result.json), [transport review](transport_review_result.json),
[complete triangle review](triangle_review_result_v2.json),
[exact T log3 comparison](T_log3_complete_comparison_v2.json.gz).
All complete ordered supports, native tensors, source images and partial
remainders are retained, rather than only their nonzero counts.

Same original unshifted SMA/CSW/EDS,A0,constant u,external jets0 AFTER
differentiation,symbolic g10/xi/eta_H,common hbar/(16pi^2),nonexceptional
Euclidean LOCAL RELATIVE DIM-minus-strict-heat UV symbol. Unprobed root
intrinsic degrees0/1 follow the actual UOR inventory; the final target
has intrinsic degree1. No changed reference or physical scheme.

UOR's native heat bound<=4 and carrier chi4+log(m/2) isolate log3 to
three-edge terms. JaJa has ceiling2. The remaining nine candidate root
types have the following COMPLETE ordered three-edge supports:

| C0 type | Ordered candidate words | Actual C3 disposition |
| --- | ---: | --- |
| JL JL CC |12|Unmeasured|
| JL a CC |114|Unmeasured|
| Ja JL C |12|Qualified zero, ICR reuse|
| intrinsic JL Cx |30|Both constituent C3 groups qualified zero, UAK reuse|
| Ja a C |48|New complete kernel,1,058 nonzero positions|
| Jx Cx |54|USR reuse,35,824 nonzero positions|
| intrinsic a Cx |174|AAK reuse,10,632 nonzero positions|
| intrinsic Ja x |0|Complete three-edge support zero; IQC block premise retained|
| intrinsic Lambda x |18|IQC reuse,304 nonzero positions|

The462 words are ordered support candidates, not particles, independent
integrals, counterterms or an E5 completion measure. Quantum-port-first
versus external-complement-first enumeration agrees on every letter,
reference, derivative role and exclusion. Directed paths versus saturated
multisets/permutations agree on all words and starting supertrace signs.
Sources remain external; one-port/source-only terms are retained before
their proper-Hessian exclusion. Zero-grade reference entries remain
resummed. Generic potential and isolated-fermion supersets have no complete
cycles in this exact domain; no missing coefficient was silently assigned0.

Old native packed hashes, both old coefficient tables and their actual
qualification receipts are authenticated. Every reused C3 coefficient
and zero complement agrees across the old methods. Those quantum loops
were reused, not freshly replayed. Current support and operation
contractions are new execution. Shared premises remain explicit.

## Known B_u C0, then the last T kernel

Primary component substitutions and replay's literal odd Leibniz rule
apply every relevant qualified UOR aggregate flow to the owning density
orders Jx Cx,a Cx,Lambda x. Sources are differentiated before restriction;
the u/QG operation is not replaced by the rho/G operation. Three nonzero
reused C3 inputs give the following new images:

| Probe1 target/image | Nonzero coefficient positions |
| --- | ---: |
| T from Jx Cx |12,792|
| T from intrinsic a Cx |10,632|
| Sum of these T images |13,112|
| F from intrinsic Lambda x |25,792|

All probe0 images are zero. T uses296 source-degree1 aggregate flows
from Jx Cx and33 source-degree2 flows from aCx; its raw source2 route
count66 retains both original derivative occurrences. F uses3,344
source2 aggregate flows from Lambda x. Known images and every implicit
zero agree before any old remainder is mathematically read.

Their late addition leaves7,424 partial T and121,408 partial F log3
positions. This identifies an indispensable missing T input without
choosing its value. The only still-unmeasured UOR type reaching T at
log3 is Ja a C. All48 of its ordered words specialize the qualified
AAK Gaussian S_M_G_W coefficient: replace the even nx*S insertion by
even Ja*A. In density order Ja_s a_r C_h,

    K[s,r,h] = Tr(A_s J_h G0 W_r).

AAK's independently qualified literal paired-Gaussian/Schur proof fixes
the plus sign and normalization by linearity. It is explicitly inherited,
not freshly rerun or replaced by agreement of two model implementations.
The actual Ja source Hessian A has no Lorentz port; the same qualified
ACV J/W pin theorem applies. Both B and Lambda currents and actual
reference widths remain. No extra half is inserted for the even source.

Primary indexed JG paths versus replay reassociated AJ against GW agree
over all91,125 source/antighost/ghost positions. The kernel has1,058
nonzero and90,067 zero positions. Independently bound ICR A/J/G inputs
agree before use. Exact examples in the common normalization are

    K[13,12,14] = 8 sqrt10 g10^2 xi/25,
    K[20,24,5]  = sqrt6 eta_H g10^3/12.

Fresh full four-component original-action Hessians and tagged third
powers corroborate four deterministic nonzero contexts plus two zeros,
at axis3/q+ and axis2/q-:12 complete uncut checks. The full GF density
is differentiated before restriction. These samples supplement the
complete48-word reduction and tensor/zero-complement comparison.

The kernel's actual u image uses296 UOR aggregate flows and has7,424
probe1 positions; probe0 is zero. Component source substitution and
literal graded density differentiation agree. Only after all checks is
that image added ONCE to the partial T sum:

| Probe | Previous partial T log3 | New measured image | Complete declared sum nonzero |
| --- | ---: | ---: | ---: |
|0|0|0|0|
|1|7,424|7,424|0|

This is coefficientwise equality across664,200 positions per probe,
not equality of counts. It completes the UOR T log3 input inventory
within the declared formal comparison. It does not calculate chi4,
log2, the full finite Ward identity or the two missing F kernels.

## Focused result-to-claim assessment

**Evidence to claim.** Actual complete support, authenticated qualified
coefficients, new u-operation contractions, a new complete triangle and
fresh uncut action checks now close the complete declared T log3
conversion-plus-cutoff comparison. The previous nonzero partial sum was
missing actual B_u C0 inputs. Their independently calculated values,
including the new triangle, supply the missing contribution without fit.

**Remaining bridge and alternatives.** F still needs JL a CC and JL JL CC
three-edge kernels. Its current121,408-position partial remainder is
preserved in partial_after_known.json.gz; it is not an anomaly verdict.
Their114/12 ordered words group into38/4 cyclic TYPE signatures solely
for organizing work. That grouping does not assert amplitude equality
or remove Grassmann/starting-supertrace signs. The Ja a C result cannot
be copied to odd-JL densities. Full defect-inclusive master/Ward,
regulator/reference/measure terms and a common continuum finite-part/
product domain remain under their owning applicability requirements.
Selected coefficient closure cannot provide those missing premises.

**Significance and AI limits.** The result makes the dependency assessment
concrete: a large nonzero partial sum became a zero complete scoped sum
through an actual missing calculation. Structural selection and exact
reuse avoided repeating large qualified tensors. A verifier's missing
vertex was detected and corrected with its failure preserved. Methods
share action, charts, curated inputs, Gaussian premise, coefficient ring,
software and AI author. No external scientist, proof assistant or
experiment validates the physical premises. Internal computational
corroboration is distinct from empirical truth or director acceptance.

**Next discriminating action.** Derive the common marginal C3 operator
for the two remaining F roots from the actual original source and GF
densities. Retain source JL parity, the second-ghost derivative of
JL CC a, GF aCBB seagulls and both ordinary current endpoints. Verify
the complete114/12 ordered words and generic graded Gaussian signs,
then measure complete coefficient tensors by distinct contractions.
Apply the actual UOR u operation and compare only after agreement.
Do not infer either tensor from the desired negative F remainder.

## Preserved failures, resources and omitted checks

1. Original ULS1 primary failed its kinetic-graph type assertion: abstract
   B,h_B,k_B labels were not recognized alongside component B0_0 labels.
   No table/result existed and replay was not launched. V2 added the
   explicit B alias, preserving every condition and input.
2. Original ULS6 fresh checker omitted H_(C,B)|a by using only90 supplied
   E_a/E_Lambda columns. It passed the first context but returned0 at
   K[20,24,5]. Full GF homotopy reconstruction recovers all90 original
   Euler columns and supplies the complete two-field Hessian. V2 passes
   the unchanged failed context and all others. Native model tensors
   were not changed. This preserved omission is a sensitive control.

Both failures retain exact sources/copies, preparations, full captures
and controller failures, with no original qualification receipt. Neither
failed attempt is relabeled PASS. Read-only path lookups were corrected
without changing scientific data. No physical parameter or sign changed.

After-import seconds: support V2 8.0861/8.3446, support/reuse review2.4036,
known transport7.1608/8.1310, transport review6.7719, triangle2.3567/2.4153,
corrected full review21.0147. Native300s/review180s,8GiB sampled private,
350MiB launch available-pagefile and32MiB packet remain. Maximum successful
private SAMPLE before finalseal512,958,464B, not a continuous peak. Complete
PID/creation/stdout/resource captures and immutable source copies retained.

Final E4/seal receipt records the one delegated E4 execution without
--fresh. Expected native0,[0,0,0,0,0,2],COMPLETED authenticates existing
evidence/current bounded audits, not global replay or custodyPASS.
Deliberately omitted: fresh old-loop replay, F missing kernels, other
finite carriers, continuum nonlinear products/QAP/measure/global phase,
source reality, causal/massive/physical limits and physical unification.
chi4,b0,kappa and IR freedoms stay distinct/unfixed. No state/promotion,
foundation/benchmark/scheme adoption,flavor/HB1/C5 activation,branch/
worktree,remote push,publication or outreach. Investigation remains active.
