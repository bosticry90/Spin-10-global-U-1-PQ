from pathlib import Path
from hashlib import sha256
import ast,json,os,subprocess,threading,time
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-log3-support-v1-2026-10-26')
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
bindings={};preps=[]
for prep in sorted(O.glob('*preparation*.json')):
    preps.append(prep.name)
    for pp,h in read(prep)['input_sha256'].items():
        assert H(Path(pp))==h,(prep.name,pp)
        if pp in bindings:assert bindings[pp]==h
        bindings[pp]=h
copies=list(O.glob('*.source.txt'))
for pp in copies:assert pp.read_bytes()==pp.with_name(pp.name[:-11]).read_bytes(),pp
for pp in O.glob('*.py'):ast.parse(pp.read_bytes())
expected_failed={'support_primary_capture.json','triangle_review_capture.json'};failed=set();complete=[];largest=0
for pp in sorted(O.glob('*_capture.json')):
    z=read(pp)
    assert z['launch']['creation_after_observation'] and z['launch']['memory']['available_pagefile']>=350*1024**2
    assert z['all_resource_samples'] and all(0<v['private_bytes']<=8*1024**3 and 'query_error' not in v for v in z['all_resource_samples'])
    assert z['post_run_observations_qualified'] and not z['failed_or_incomplete_counted_as_PASS']
    if pp.name in expected_failed:
        assert z['execution_state']=='FAILED' and z['exit_code']==1 and not z['calculation_completed'];failed.add(pp.name)
    else:
        assert z['execution_state']=='COMPLETED' and z['exit_code']==0 and z['calculation_completed'],pp
        complete.append(pp.name);largest=max(largest,max(v['private_bytes'] for v in z['all_resource_samples']))
assert failed==expected_failed
assert not (O/'support_primary_tables.json.gz').exists() and not (O/'support_replay_capture.json').exists()
assert not (O/'triangle_review_result.json').exists() and not (O/'T_log3_complete_comparison.json.gz').exists()
assert {p.name for p in O.glob('*controller_failure*.json')}=={'support_controller_failure.json','triangle_review_controller_failure.json'}
for name in ['support_v2_primary_result','support_v2_replay_result','transport_primary_result','transport_replay_result','triangle_primary_result','triangle_replay_result']:
    assert read(O/(name+'.json'))['elapsed_after_imports']<300
for name in ['review_result','transport_review_result','triangle_review_result_v2']:
    assert read(O/(name+'.json'))['elapsed_after_imports']<180
s=read(O/'review_result.json');t=read(O/'transport_review_result.json');k=read(O/'triangle_review_result_v2.json')
assert s['complete_native_support_equal'] and s['old_actual_qualified_tensors_authenticated_and_compared'] and s['total_ordered_candidate_words']==462
assert t['complete_native_images_and_zero_complements_equal']
assert k['complete_kernel_images_and_zero_complements_equal'] and k['preserved_V1_failed_context_rechecked'] and len(k['fresh_uncut_checks'])==12
assert all(z['complete_declared_T_log3_sum_zero'] and z['complete_declared_T_log3_sum_nonzero']==0 for z in k['late_complete_declared_T_log3_comparisons'])
assert k['F_missing_marginal_C3_types']==['JLaCC','JLJLCC'] and not k['full_Ward_QAP_or_scientific_promotion']
events=read(O/'e4_events.json');steps=[z for z in events if z['event']=='step_finished']
assert [z['exit_code'] for z in steps]==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested']
assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout'] and read(O/'e4_capture.json')['elapsed_seconds']<300
git=lambda *args:subprocess.run(['git',*args],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()=='a08bfe91fb66177e439f2b513a95baa371f0dbc5'
assert git('branch','--show-current').decode().strip()=='main'
assert git('ls-tree','-r','--full-tree','HEAD')==(C/'old_git_tree.txt').read_bytes()
git('diff','--quiet','HEAD','--')
state=H(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
size=sum(p.stat().st_size for p in O.rglob('*') if p.is_file());assert size<32*1024**2
out={'schema':'ULS7_FINAL_EVIDENCE_REVIEW','preparation_bindings_authenticated':len(bindings),'preparations':preps,'source_copies_equal':len(copies),
 'completed_captures_authenticated':complete,'preserved_failed_captures':sorted(failed),'failed_originals_not_relabelled_PASS':True,
 'largest_successful_sampled_private_bytes':largest,'packet_bytes_before_final_capture_and_seal':size,
 'bounded_evidence_validation':'PASS_WITHIN_FROZEN_SCOPE','complete_declared_T_log3_comparison':'ZERO_BOTH_PROBES',
 'F_log3_comparison':'PARTIAL_TWO_UNMEASURED_MARGINAL_KERNELS','full_Ward_QAP_or_E5_claim':False,
 'E4_step_exits':[z['exit_code'] for z in steps],'custody':'EXIT2_SEVEN_UNRESOLVED_NOTPASS',
 'old_tracked_tree_and_state_unchanged':True,'state_sha256':state,'scientific_acceptance':'NOT_PERFORMED',
 'elapsed_after_imports':time.perf_counter()-tick}
with (O/'final_review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
