"""SCO1 independent literal graded exterior-matrix inverse and ownership check."""
from pathlib import Path
from hashlib import sha256
import gzip,json,os,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()))
started=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation_v2.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
A=packed(HERE/'primary_tables.json.gz');B=packed(HERE/'replay_tables.json.gz')
names=['first_width_base','first_width_two_background','second_width_two_background','source_zero_two_background']
for name in names:assert A[name]==B[name],name
assert len(A['first_width_base'])==3 and len(A['source_zero_two_background'])==len(A['second_width_two_background'])==6
for d in [A,B]:
    assert d['allowed_soft_K_jets']==[1,2,3,8,9,10,12] and d['hard_X_jets']==list(range(16))
    assert d['all_word_products_noncommuting'] is True
    assert d['actual_hard_source_CT_family_qualified'] is d['full_two_loop_width_identity_qualified'] is False
rnc=read(CAL/'canonical_so10_regulator_nielsen_contact/validation_receipt.json')
assert rnc['status']=='QUALIFIED_REGULATOR_NIELSEN_CONTACT_AND_COMMON_LIGHT_GAUSSIAN_F2_RESPONSE'
rn=packed(CAL/'canonical_so10_regulator_nielsen_contact/primary_tables.json.gz')
dec=lambda d:s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z) for i,j,z in d['entries']})
assert dec(rn['contact_ghost_kernel'])==dec(rn['parent_projector'])/2
x1,r=s.symbols('x1 r',positive=True)
assert s.sympify(rn['auxiliary_contact_coefficient'],locals={'x1':x1})==1/(2*x1)
assert s.simplify(s.sympify(rn['u_linear_after_IBP'],locals={'x1':x1,'r':r}).subs(x1,1))==0
assert rn['second_width_mixed_contact']=='0'
# An independent matrix realization of the graded tensor product. h,k are
# commuting squarefree shifts, u,chi exterior shifts. An odd field operator
# crosses the exterior input state through its parity matrix.
odd=lambda m:(bool(m&4)+bool(m&8))%2
parity=s.diag(*[(-1)**odd(mask) for mask in range(16)])
def external(mask,graded=True):
    E=s.zeros(16)
    for base in range(16):
        if base&mask:continue
        E[base|mask,base]=(-1)**int(bool(mask&8) and bool(base&4))
    return E*parity if graded and odd(mask) else E
def typed(seed,p):
    return s.Matrix(4,4,lambda i,j:s.Rational((i+1)*(j+2)+seed*(i-j+3),seed%5+1)
        if (int(int(i)>=2)^int(int(j)>=2))==p else 0)
S=s.diag(1,1,-1,-1)
def eval_words(rows,G,K,X):
    result=s.zeros(4)
    for row in rows:
        M=s.eye(4)
        for token in row['word']:
            M=M*(G if token=='G' else K[int(token[1:])] if token[0]=='K' else X[int(token[1:])])
        result+=s.Rational(row['twice_coefficient'],2)*M
    return result
def literal(K0,K,X,mask,graded=True):
    M=s.kronecker_product(s.eye(16),K0)
    for n,T in K.items():M+=s.kronecker_product(external(n,graded),T)
    XX=s.zeros(64)
    for n,T in X.items():XX+=s.kronecker_product(external(n,graded),T)
    answer=M.inv(method='DM')*XX
    return answer[4*mask:4*(mask+1),:4]/2
wrong_tensor=0;missing_contact=0;missing_Xu=0
for seed in [2,5]:
    K0=s.diag(2,3,5,7);G=K0.inv()
    K={m:typed(seed+3*m,odd(m)) for m in A['allowed_soft_K_jets']}
    K[12]=s.diag(0,0,s.Rational(1,2),s.Rational(1,2))
    X={m:typed(7*seed+2*m,odd(m)) for m in range(16)}
    expected=literal(K0,K,X,15)
    actual=eval_words(A['first_width_two_background'],G,K,X)
    assert expected==actual
    assert s.trace(S*(expected-actual))==0
    assert literal(K0,K,X,3)==eval_words(A['source_zero_two_background'],G,K,X)
    Ksecond={m:K[m] for m in [1,2,3]}
    assert literal(K0,Ksecond,X,15)==eval_words(A['second_width_two_background'],G,Ksecond,X)
    bad=literal(K0,K,X,15,graded=False)
    wrong_tensor+=int(bad!=actual)
    cutR=[row for row in A['first_width_two_background'] if 'K12' not in row['word']]
    missing_contact+=int(eval_words(cutR,G,K,X)!=actual)
    cutXu=[row for row in A['first_width_two_background'] if not(int(row['word'][-1][1:])&4 and not int(row['word'][-1][1:])&8)]
    missing_Xu+=int(eval_words(cutXu,G,K,X)!=actual)
    # Kernel matching is linear BEFORE trace or limits; all source components
    # have independent nonzero rational values in this typed check.
    HF={m:typed(seed+11*m+1,odd(m)) for m in range(16)}
    CE={m:typed(seed+13*m+4,odd(m)) for m in range(16)}
    match={m:HF[m]+X[m]-CE[m] for m in range(16)}
    rows=A['first_width_two_background']
    assert eval_words(rows,G,K,HF)+eval_words(rows,G,K,X)-eval_words(rows,G,K,match)-eval_words(rows,G,K,CE)==s.zeros(4)
assert wrong_tensor==missing_contact==missing_Xu==2
out={'schema':'SCO1_VALIDATION_RECEIPT','status':'QUALIFIED_ORDERED_SOURCE_ONE_SOFT_OPERATION_AND_COMMON_KERNEL_TRANSPORT',
    'execution_state':'COMPLETED','first_width_base_words':3,
    'first_width_background_source_words':len(A['first_width_two_background']),
    'second_width_background_source_words':6,'source_zero_background_words':6,
    'literal_graded_matrix_dimension':64,'literal_typed_cases':2,'all_coefficients_exact':True,
    'controls':{'wrong_tensor_sign_detected_cases':wrong_tensor,'missing_RNC_contact_detected_cases':missing_contact,
    'missing_hard_Xu_detected_cases':missing_Xu},'common_transport_before_limits':True,
    'actual_hard_source_CT_family_qualified':False,'full_nonlocal_light_source_qualified':False,
    'full_two_loop_width_identity_qualified':False,'finite_C1_calculated':False,
    'scientific_acceptance':'NOT_PERFORMED','scientific_authority':'34/39_UNCHANGED',
    'elapsed_after_imports':time.perf_counter()-started}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
