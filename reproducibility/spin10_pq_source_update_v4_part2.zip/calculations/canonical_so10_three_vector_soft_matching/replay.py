"""V3M1 literal massive vertices/density Hessian and independent soft heat region."""
from data import *
def bubble(n):
    u,p=s.symbols('u p');ls=s.symbols('l0:'+str(n));mom=s.Matrix([p]+[0]*(n-1));k=s.Matrix(ls)-u*mom
    def V(mu,a,b):return int(mu==a)*(mom-k)[b]+int(a==b)*(2*k+mom)[mu]+int(b==mu)*(-k-2*mom)[a]
    coeff=[];masses=[]
    for mu in [1,0]:
        num=s.expand(sum(V(mu,a,b)**2 for a in range(n) for b in range(n)))
        rad=sum(num.coeff(l,2) for l in ls)/4 # -1/2 Gaussian and -D/2 massive tadpole moment.
        assert not rad.free_symbols
        const=num.subs(dict.fromkeys(ls,0)).expand().coeff(p,2)
        kinetic=s.integrate(rad*u*(1-u)-const/2,(u,0,1));coeff.append(clean(kinetic));masses.append(clean(rad))
    assert masses[0]==masses[1]
    return coeff[0],clean(coeff[0]-coeff[1]),masses[0]
def density(C):
    nn=len(C);nc=C[0].rows;Z=s.zeros(nc)
    def L(mu,nu,a):return C[mu]*int(nu==a)-C[nu]*int(mu==a)
    return s.Matrix.vstack(*[s.Matrix.hstack(*[sum((L(mu,nu,a).T*L(mu,nu,b)/2 for mu in range(nn) for nu in range(nn)),Z)-C[a]*C[b]+C[b]*C[a] for b in range(nn)]) for a in range(nn)])
def curvature(n,a,b,swapped):
    U=s.Matrix([[0,1,0],[-1,0,0],[0,0,0]]);V=s.Matrix([[0,0,0],[0,0,1],[0,-1,0]]);Z=s.zeros(3)
    A=[U,V]+[Z]*(n-2);Q=([V,U] if swapped else [U,V])+[Z]*(n-2)
    Kaa=density(A)+s.Matrix.vstack(*[s.Matrix.hstack(*[-A[i]*A[j] for j in range(n)]) for i in range(n)])
    Kaq=density([h+q for h,q in zip(A,Q)])-density(A)-density(Q)
    XA=[s.kronecker_product(s.eye(n),q) for q in A]
    XQ=[s.Matrix.vstack(*[s.Matrix.hstack(*[Q[l]*int(i==j)-(Q[i]*int(j==l)+Q[j]*int(i==l))/2 for j in range(n)]) for i in range(n)]) for l in range(n)]
    ZZ=s.zeros(3*n);Eaa=Kaa+sum((q*q for q in XA),ZZ);Eaq=Kaq+sum((a*q+q*a for a,q in zip(XA,XQ)),ZZ);Eqq=sum((q*q for q in XQ),ZZ)
    value=s.trace(Eaa*Eqq+Eaq*Eaq/2)
    for i in range(n):
        for j in range(n):
            aa=XA[i]*XA[j]-XA[j]*XA[i];qq=XQ[i]*XQ[j]-XQ[j]*XQ[i]
            aq=XA[i]*XQ[j]-XQ[j]*XA[i]+XQ[i]*XA[j]-XA[j]*XQ[i]
            value+=s.trace(aa*qq)/6+s.trace(aq*aq)/12
    value=-value/2;X=[[A[i]*Q[j]-Q[j]*A[i] for j in range(n)] for i in range(n)]
    Ac=sum(s.trace(q*q) for row in X for q in row);div=sum((X[i][i] for i in range(n)),Z);Cc=s.trace(div*div)
    Jc=sum(s.trace((A[i]*A[j]-A[j]*A[i])*(Q[i]*Q[j]-Q[j]*Q[i])) for i in range(n) for j in range(n));assert Jc
    return clean(2*(value+a*Ac/2-b*Cc/2)/Jc)
def shifted_gamma(k):
    return s.prod(t+eps for t in range(1,k)) if k>=1 else 1/s.prod(t+eps for t in range(k,1))
def main():
    start=begin();rows={}
    for n in [3,4,5,6]:
        a,b,nm=bubble(n);cc=[curvature(n,a,b,q) for q in [False,True]];assert cc[0]==cc[1]
        rows[str(n)]={'a':str(a),'b':str(b),'c':str(cc[0]),'n':str(nm)};print('STAGE literal_bubble_and_density_N'+str(n),flush=True)
    soft={};terms={};beta=4-eps
    for i,P in enumerate(heat_axes()):
        total=0;kept=[]
        for (ii,jj,kk),co in s.Poly(clean(P*U**2),*times).terms():
            assert ii+jj+kk==5
            for n in range(max(0,ii-2)):
                aa=ii-3-n;assert aa>=0
                term=co.subs(D,4-2*eps)*(-1)**n*s.rf(beta,n)/s.factorial(n)*shifted_gamma(aa)*shifted_gamma(-aa)
                term*=s.factorial(jj+n)*s.factorial(kk+n)/s.factorial(jj+kk+2*n+1)*d**(-aa)
                total+=term;kept.append({'powers':[ii,jj,kk],'n':n,'d_power':-aa,'coefficient_gamma2_ratio':str(clean(term))})
        soft[str(i)]=str(clean(total));terms[str(i)]=kept;print('STAGE independent_large_light_time_axis'+str(i),flush=True)
    save('replay',{'schema':'V3M1_INDEPENDENT_REPLAY','integer_N_checks':rows,'soft_bare_gamma2_ratios':soft,'retained_terms':terms,
      'primary_output_fields_read':False,'positive_minus_hard_used_to_determine_input':False,
      'next_unretained_power_at_least':1,'maximum_epsilon_pole_order_in_regions':2},start)
if __name__=='__main__':main()
