"""V3L2 complete hard forest gamma factor; no change to measured hard bare."""
from data import *
def main():
    start=begin('correction_preparation.json');mp.mp.dps=110
    old=packed(CAL/'canonical_so10_three_vector_one_light_kernel/primary_tables.json.gz')
    uv=packed(CAL/'canonical_so10_three_vector_uv_forests/primary_tables.json.gz');axes={};exact=[];pref=[]
    for i in range(3):
        pp=[s.S.Zero]*3 if i==0 else [clean(read(v).subs({x:0,y:1,z:1})) for v in uv['axes'][str(i)]['prefactor']]
        ct=gamma_jet(sum(pp[k]*eps**(k-2) for k in range(3)),0,1)
        if i>0:
            positive=list(map(read,uv['axes'][str(i)]['forest_Laurent_Q1']))
            assert all(clean(v.subs({x:0,y:1,z:1})-w)==0 for v,w in zip(positive,ct))
        bb=list(map(read,old['axes'][str(i)]['hard_bare_Q1']));rr=[clean(a+b) for a,b in zip(bb,ct)]
        scaled=[rr[0],clean(rr[1]+j*(2*bb[0]+ct[0])),clean(rr[2]+j*(2*bb[1]+ct[1])+j*j*(2*bb[0]+ct[0]/2))]
        axes[str(i)]={'hard_bare_Q1':list(map(str,bb)),'hard_forest_Q1':list(map(str,ct)),'hard_Rprime_Q1':list(map(str,rr)),
          'hard_Rprime_scale':list(map(str,scaled)),'correction_to_historical_forest':list(map(str,[clean(v-read(w)) for v,w in zip(ct,old['axes'][str(i)]['hard_forest_Q1'])]))}
        exact.append(ct);pref.append([mp.mpf(str(v)) if v.is_Integer else mp.mpf(int(s.numer(v)))/int(s.denom(v)) for v in pp])
    history=[];previous=None;error=mp.mpf(0);leak=mp.mpf(0)
    for nodes,den in [(32,32),(48,32),(48,64)]:
        radius=mp.mpf(1)/den;totals=[[mp.mpc(0) for k in range(3)] for i in range(3)]
        for n in range(nodes):
            phase=mp.exp(2j*mp.pi*n/nodes);e=radius*phase;G=mp.exp(mp.euler*e)*mp.gamma(1+e)
            for i,pp in enumerate(pref):
                value=G*(pp[0]+e*pp[1]+e*e*pp[2])
                for k in range(3):totals[i][k]+=value/phase**k
        vals=[[v/(nodes*radius**k) for k,v in enumerate(row)] for row in totals]
        if previous is not None:assert max(abs(a-b)/(1+abs(b)) for row,other in zip(vals,previous) for a,b in zip(row,other))<mp.mpf('1e-35')
        for row,xx in zip(vals,exact):
            for value,target in zip(row,xx):error=max(error,abs(value-mp.mpf(str(s.N(target,110))))/(1+abs(value)));leak=max(leak,abs(mp.im(value))/(1+abs(value)))
        previous=vals;history.append({'nodes':nodes,'radius_denominator':den})
    assert error<mp.mpf('1e-35') and leak<mp.mpf('1e-90')
    assert any(read(v)!=0 for row in axes.values() for v in row['correction_to_historical_forest'])
    out={'schema':'V3L2_GAMMA_COMPLETE_HARD_FOREST','status':'QUALIFIED_CORRECTED_GAMMA_COMPLETE_ONE_LIGHT_THREE_VECTOR_HARD_FOREST',
      'execution_state':'COMPLETED','axes':axes,'Cauchy_error':mp.nstr(error,45),'imaginary_leak':mp.nstr(leak,45),'refinements':history,
      'bare_integral_unchanged':True,'supersedes':'V3L1 finite hard forest and hard Rprime arrays only; all historical bytes retained',
      'full_C1_or_E5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED','elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
if __name__=='__main__':main()
