"""V3M1 exact soft identities followed by absolute positive-mass matching."""
from data import *
def main():
    start=begin('diagnostic_preparation.json');A,B=[packed(HERE/f'{r}_tables.json.gz') for r in ['primary','replay']]
    assert not A['positive_minus_hard_used_to_determine_input'] and not B['positive_minus_hard_used_to_determine_input'] and not B['primary_output_fields_read']
    for n in ['3','4','5','6']:
        for k,v in B['integer_N_checks'][n].items():assert clean(read(v)-read(A['integer_N_checks'][n][k]))==0
    opened=read(A['soft_bare_gamma2_ratio']);ct=read(A['soft_CT_gamma1_ratio'])
    region={i:read(v) for i,v in B['soft_bare_gamma2_ratios'].items()}
    assert clean(opened-region['0'])==0
    for i in ['1','2']:
        assert region[i]==0 and any(read(t['coefficient_gamma2_ratio'])!=0 for t in B['retained_terms'][i])
    # Every omitted next power is positive, for the actual finite numerator.
    for P in heat_axes():
        for powers,co in s.Poly(clean(P*U**2),*times).terms():assert 3+max(0,powers[0]-2)-powers[0]>=1
    old=packed(CAL/'canonical_so10_three_vector_uv_forests/primary_tables.json.gz')
    oldct=sum(read(v).subs({x:d,y:1,z:1})*eps**(i-2) for i,v in enumerate(old['axes']['0']['prefactor']))
    assert clean(ct-oldct)==0
    soft=list(map(read,A['soft_renormalized_Laurent']));controls={}
    for name in ['early_D4_change','omitted_finite_curvature_change']:
        vv=list(map(read,A[name]));assert any(v!=0 for v in vv);controls[name]=list(map(str,vv))
    ctjet=list(map(read,A['soft_CT_Laurent']));assert any(v!=0 for v in ctjet);controls['doubled_light_CT_change']=list(map(str,ctjet))
    gamma_lost=clean(-ratio_jet(opened)[0]*s.zeta(2)-ratio_jet(ct)[0]*s.zeta(2)/2);assert gamma_lost!=0;controls['omitted_positive_gamma_jets_finite_change']=str(gamma_lost)
    bare=packed(CAL/'canonical_so10_three_vector_bare_kernel/primary_v3_tables.json.gz')
    hard=packed(CAL/'canonical_so10_three_vector_one_light_kernel/primary_tables.json.gz');functions=[];tokens_all=set();pole_checks={};scale_limits={}
    for i in range(3):
        bb=list(map(read,bare['axes'][str(i)]['bare_Laurent_Q1']));ff=list(map(read,old['axes'][str(i)]['forest_Laurent_Q1']))
        full=[clean(bb[0]+ff[0]),clean(bb[1]+ff[1]+j*(2*bb[0]+ff[0])),clean(bb[2]+ff[2]+j*(2*bb[1]+ff[1])+j*j*(2*bb[0]+ff[0]/2))]
        match=[clean(v.subs({x:d,y:1,z:1})-(soft[k].subs(ld,s.log(d)) if i==0 else 0)) for k,v in enumerate(full)]
        hh=[s.sympify(v,locals={'j':j}) for v in hard['axes'][str(i)]['hard_Rprime_scale']]
        residual=[clean(match[k]-hh[k]) for k in [0,1]];assert all(q==0 for q in residual);pole_checks[str(i)]=list(map(str,residual))
        # Finite scale coefficients need no scalar-master evaluation.
        coeff_res={}
        for power in [1,2]:
            rv=s.expand(match[2]-hh[2]).coeff(j,power);lim=s.limit(rv,d,0,dir='+');assert lim==0
            coeff_res[str(power)]=str(clean(rv))
        scale_limits[str(i)]=coeff_res
        vv=full[2];tokens=sorted(vv.free_symbols-{x,y,z,j},key=str);assert all(str(v).startswith('I') for v in tokens)
        tokens_all.update(tokens);functions.append((s.lambdify([x,y,z,j,*tokens],vv,modules='mpmath',cse=True),tokens))
    print('STAGE exact_opened_heat_region_and_pole_matching',flush=True)
    mp.mp.dps=120;master=absolute_master();sample=[];previous=None;leak=mp.mpf(0);diagnostic_checks=[];softfun=s.lambdify([d,j,ld],soft[2],modules='mpmath',cse=True)
    hardfun=[s.lambdify([j],s.sympify(hard['axes'][str(i)]['hard_Rprime_scale'][2],locals={'j':j}),modules='mpmath') for i in range(3)]
    for exponent in [4,8,12]:
        dv=mp.mpf(10)**(-exponent);point=(mp.nstr(dv,130),'1','1');values={};rows=[];largest=mp.mpf(0)
        for token in tokens_all:
            value=master.imaster_derivative(point,tuple(map(int,str(token)[1:])));leak=max(leak,abs(mp.im(value))/(1+abs(value)));values[token]=mp.re(value)
        for jv in [mp.mpf(0),mp.mpf(1)/3]:
            for i,(fun,tokens) in enumerate(functions):
                full=fun(dv,mp.mpf(1),mp.mpf(1),jv,*[values[t] for t in tokens]);ss=softfun(dv,jv,mp.log(dv)) if i==0 else mp.mpf(0)
                target=hardfun[i](jv);matched=full-ss;err=abs(matched-target);largest=max(largest,err);leak=max(leak,abs(mp.im(full))/(1+abs(full)))
                rows.append({'j':mp.nstr(jv,50),'axis':i,'matched':mp.nstr(mp.re(matched),70),'hard':mp.nstr(target,70),'absolute_error':mp.nstr(err,45)})
        assert leak<mp.mpf('1e-70')
        if previous is not None:diagnostic_checks.append({'d':point[0],'required_refinement_pass':bool(largest<previous/100)})
        print('DIAGNOSTIC_MATCH '+json.dumps({'d':point[0],'rows':rows,'largest_error':mp.nstr(largest,50)},sort_keys=True),flush=True)
        previous=largest;sample.append({'d':point[0],'largest_absolute_error':mp.nstr(largest,45),'rows':rows})
        print('STAGE absolute_matching_d_1e-'+str(exponent),flush=True)
    diagnostic_checks.append({'required_final_tolerance_pass':bool(previous<mp.mpf('1e-5'))})
    native=[]
    for role in ['primary','replay']:
        c=json.loads((HERE/f'{role}_capture.json').read_bytes());r=json.loads((HERE/f'{role}_result.json').read_bytes());blob=(HERE/f'{role}_tables.json.gz').read_bytes()
        assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
        assert sha256(blob).hexdigest()==r['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['tables_sha256']
        peak=max(v['private_bytes'] for v in c['all_resource_samples']);assert peak<=8*1024**3 and c['launch']['memory']['available_pagefile']>=350*1024**2 and r['elapsed_after_imports']<600
        native.append({'role':role,'seconds':r['elapsed_after_imports'],'sampled_private_max':peak})
    assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<6*1024**2
    out={'schema':'V3M1_VALIDATION','status':'DIAGNOSTIC_ONLY_NO_SCIENTIFIC_QUALIFICATION','unchanged_required_gate_observations':diagnostic_checks,'execution_state':'COMPLETED',
      'general_N_coefficients':A['general_N'],'soft_bare_region_ratios':B['soft_bare_gamma2_ratios'],'soft_renormalized_Laurent':A['soft_renormalized_Laurent'],
      'exact_pole_residuals':pole_checks,'finite_scale_limit_residuals':scale_limits,'matching_diagnostics':sample,'imaginary_leak':mp.nstr(leak,45),
      'negative_controls':controls,'native_runs':native,'one_light_matching_qualified':False,'VVV_model_amplitude_calculated':False,'primitive_amplitude_inventory':6,
      'full_C1_or_E5_qualified':False,'authority':'34/39_UNCHANGED','scientific_acceptance':'NOT_PERFORMED',
      'shared_limits':['actual cubic action','heat/reference and dimensional-region domain','V3U operator closure','V3B/V3L numerator and absolute master','symbolic/special-function software','AI authorship'],
      'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
if __name__=='__main__':main()
