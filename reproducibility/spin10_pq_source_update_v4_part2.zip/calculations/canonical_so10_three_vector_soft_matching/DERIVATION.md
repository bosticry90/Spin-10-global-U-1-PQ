# V3M1 prospective opened-loop and region derivations

Use the actual cubic Hessian, original Kqq=0. Its Laplace connection is
W_lambda,ab=Q_lambda delta_ab-(Q_a delta_b,lambda+Q_b delta_a,lambda)/2.
For a first derivative X_mu,nu=D_mu Q_nu the linear endomorphism is
E1=-3(X-X.T)/2. Derive alpha,beta,gamma from the full ordered Lorentz heat
polynomial -1/2[Tr(E1²)/2+sum Tr(Omega1²)/12], and independent delta from
Tr(E0 Eqq)+Tr(Omega0 Omegaqq)/6 with Eqq=sum W². Canonical Hessian
a=-2alpha,b=2(beta+gamma),c=2(delta-beta). A mass moment uses Tr_L sum W².
Only two Lorentz directions are active in each coefficient; all others are
identical spectators, each entering a single closed Lorentz trace. This
proves degree<=1 in N; testing additional integer dimensions is a check,
not the justification for analytic continuation. No quartic Kqq is added.

Equal heavy mass M commutes with the unbroken background and the light
generator's carrier. Factoring exp(-M t) out of its minimal heat trace,
the dimension2 and dimension4 quadratic terms use a2 and a4 respectively.
Thus derivative/curvature coefficients multiply
Bm=exp(gammaEeps)Gamma(eps)(Q2/M)^eps, while the mass coefficient has the
additional M/(1-eps). Keep these whole functions before subtracting poles.
Replay derives flat low-momentum terms by shifting the literal two-vector
bubble and integrating its Feynman parameter; separately check c(N) from
the noncommuting density Hessian. It is not obtained from flat covariance.

Let resulting a(N),b(N),c(N),n(N) be measured, N=4-2eps, and their pole
values a0,b0,c0,n0. The full real triangle's ratio is the qualified2/3.
With Hdelta=exp(gammaEeps)Gamma(1+eps)(Q2/delta)^eps, the opened soft loop is

 Sbare=(2/3) Bm Hdelta [(10+eps)a(N)+b(N)/2
       -12(c(N)+2a(N))/eps-(10+eps)n(N)/(d(1-eps))].

The light-closing proper CT is

 Sct=(2/3)Hdelta/eps[-(10+eps)a0-b0/2
       +12(c0+2a0)/eps+(10+eps)n0/d].

This uses kinetic, longitudinal, independent curvature and mass heat traces
with their full eps-positive remaining-loop factors. Finite mass terms
cannot be dropped: they close into1/d. Finite curvature terms can close into
an additional pole. Sbare carries two gamma/scale factors whereas Sct has
one; their zeta2 contributions therefore differ.

For an independent region calculation write each actual P2 U² monomial
c(D)s^i t^j u^k, i+j+k=5, with s the light time. Expand
U^(-beta)=[s(t+u)]^(-beta) sum_n (-1)^n(beta)_n/n!
 *(tu/[s(t+u)])^n, beta=4-eps.
Retain n=0,...,i-3. Set a=i-3-n>=0. Integration gives each soft term

 c(D)(-1)^n(beta)_n/n! exp(2gammaEeps)
 *Gamma(a+eps)Gamma(-a+eps)
 *Beta(j+n+1,k+n+1) d^(-a-eps).

Reduce both shifted gammas relative to Gamma(1+eps), retaining every
potential1/d² term and every charge axis until the complete sum. Compare
the full rational meromorphic result to the opened-loop expression before
expanding or reading V3B-minus-V3L. This is the sensitive nonfitted test.

Remainder control is in the inherited C1 dimensional-region construction:
both heavy times are exponentially damped; a smooth separation of large s
allows a binomial remainder. Terms beyond the retained list have p>=1,
and their gamma coefficients at most double poles, yielding finite
O(d log²d). At the short-time boundaries proper subtractions use the same
original UV operators. No additional soft-heavy region is present. A
higher local opened-vector operator of order2n,n>=2, closes with F2
coefficient scaling delta^(n-1)/M^(n-1) times logarithms. Commuting derivatives
through the covariantly constant F reorganizes spin terms at the same
dimension; polynomial identity contacts use the existing dimensional C1
background-derivative convention. Nonconstant D.F, arbitrary backgrounds
and finite-cutoff physical limits remain outside this construction.

Finally compare finite [Rpositive(d,1,1)-Sbare-Sct] to V3L's hard Rprime,
with its actual hard forests. Light CT appears once on each side and
cancels in this subtraction; heavy CTs approach V3L hard forests. The
all-light H EFT primitive and complete model sum are later obligations.
