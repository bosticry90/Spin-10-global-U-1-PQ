# V3M1: independently derived soft response and one-light matching

Qualified within the frozen reference by validation_receipt_v2.json,
SHA7c89a4f23ccb688564621ae72a1084da5f4d68e9a19360aeed5ddb7741d35bde.
Mandatory correction receipt hard_forest_correction_receipt.json,
SHA019db039094fadc591f6841c715beb9816f32a0f225ce2356eff0c8d064bb509.
Director acceptance NOT_PERFORMED; state113/authority34of39 unchanged.

For the ORIGINAL cubic Hessian at general Lorentz dimension N, the native
calculation gives per-index a=(3N-31)/12,b=(N-15)/6,c=(30-7N)/12,
n=3(N-1)/2. Mass multiplies M/(1-eps), the others Bm. The raw curvature
delta=-(5N+1)/24 is independently retained; flat covariance was not used
to supply c. Spectator counting proves degree<=1; complete selected
invariants were evaluated at N3/4 and checked separately at5/6. Literal
momentum bubbles and two noncommuting density-Hessian configurations in
each dimension agree, including the eps-positive terms at N=4-2eps.

The actual light-vector closure and independent large-light-time expansion
of every V3K monomial agree EXACTLY as rational meromorphic functions, before
finite extraction. Potential higher inverse-d powers and both heavy charge
axes cancel collectively. Only the light charge has an unsuppressed soft
response. With d=delta/M,j=log(Q2/M),ld=logd, its renormalized Laurent terms
are double0,simple24j-4/3,finite

    -(30j+10)/d +36j²-24j*ld-83j/6+4ld/3-31/9+2pi².

This nonzero finite/power-sensitive term is not an adopted gauge-boson mass.
It must be subtracted with its original light CT in full/EFT matching.
Vector higher-derivative power counting and the actual finite time expansion
leave O(d log^k d),k<=2 in the inherited dimensional-region construction.
No broader physical or nonconstant-background limit is promoted.

IMPORTANT FAILURE/CORRECTION: original validation FAILED its finite numerical
convergence gate. The diagnostic-only run preserved the same false gates and
identified a2pi² discrepancy on each heavy charge axis; the light axis already
converged. Historical V3L hard_forest_Q1 stored its prefactor without the
quadratic term of H_eps(1). New correction derives this factor from the
original V3U forest and independently checks unexpanded gamma Cauchy
coefficients; maxerror1.0058803e-48. No hard bare integral, soft coefficient,
UV pole, physical scale or scheme was changed. Original V3L bytes remain.
The corrected finite hard Rprime per heavy axis is-187/36, not2pi²-187/36.
Light remains-2pi²-53/4. Scale coefficients are otherwise unchanged.

ValidationV2 retains ALL original pole/refinement/final-error/control gates.
Using actual absolute positive-mass master derivatives at120digits, the
largest finite matched-to-hard error is .0104889437 at d1e-4,
1.87786126e-6 at d1e-8,and2.70679190e-10 at d1e-12. All3axes and j0,1/3
were checked; imaginary leak0 printed. Pole matching is exact, including
the light hard simple pole23/2-24j. Finite scale coefficients match in the
limit. Neither the soft input nor the hard correction was inferred by fitting.

Primary1.5939582s,replay16.683215s,validationV2 15.2871978s; native sampled
private maxima48,095,232/49,119,232 bytes. Correction1.2328632s. Original
failed validation, complete diagnostic, original sources and their hashes
remain exact. Initial3714 bindings; new phases freeze additional evidence.
All runs retain600s/8GiB sampled/350MiB launch/6MiB package; no timeout,
manual cancellation or native-output truncation. ValidationV1 FAILED is
not relabelled; completed diagnostic is not a scientific qualification.

The error demonstrates a verification blind spot: V3L's very precise bare
hard integral comparison did not test its finite gamma factor in the forest.
Independent matching detected it. Shared action, heat/locality/domain
premises, master functions, symbolic software and AI authorship still limit
independence. This is internally corroborated mathematics, not independent
physical validation. VVV model amplitude is still a separate next calculation;
do not yet raise inventory6/9. Preserve Cfull even where its soft part cancels
in the hard representation; parent-minus-family and overall CTs remain.
