"""V3M1 actual heat a2/a4 at general Lorentz dimension; light closure."""
from data import *
def heat_dimension(n):
    v=s.symbols('X00 X11 X01 X10');X=s.zeros(n);X[0,0],X[1,1],X[0,1],X[1,0]=v
    dw=s.Matrix(n,n,lambda a,b:s.trace(X)*int(a==b)-(X[b,a]+X[a,b])/2)
    L=s.Matrix(n,n,lambda a,b:-s.trace(X)*int(a==b)+X[a,b]-2*(X[a,b]-X[b,a]));E=L+dw
    assert E==-R(3,2)*(X-X.T)
    val=s.trace(E*E)/2
    for mu in range(n):
        for nu in range(n):
            O=s.Matrix(n,n,lambda a,b:(X[mu,nu]-X[nu,mu])*int(a==b)
              -(X[mu,a]*int(b==nu)+X[mu,b]*int(a==nu)-X[nu,a]*int(b==mu)-X[nu,b]*int(a==mu))/2)
            val+=s.trace(O*O)/12
    poly=s.expand(-val/2);alpha=poly.coeff(v[2],2);beta=poly.coeff(v[2]).coeff(v[3])/2;gamma=poly.coeff(v[0]).coeff(v[1])/2
    AA=sum(t*t for t in X);BB=sum(X[a,b]*X[b,a] for a in range(n) for b in range(n));CC=s.trace(X)**2
    assert clean(poly-alpha*AA-beta*BB-gamma*CC)==0
    q0,q1=s.symbols('q0 q1',commutative=False);Q=[q0,q1]+[0]*(n-2)
    W=[s.Matrix(n,n,lambda a,b:Q[l]*int(a==b)-(Q[a]*int(b==l)+Q[b]*int(a==l))/2) for l in range(n)]
    EQ=sum((q*q for q in W),s.zeros(n));ee=s.expand(-2*EQ[1,0]+2*EQ[0,1]);oo=s.expand(s.trace(W[0]*W[1]-W[1]*W[0]))
    comm=q0*q1-q1*q0
    assert s.expand(ee-ee.coeff(q0*q1)*comm)==s.expand(oo-oo.coeff(q0*q1)*comm)==0
    delta=clean(-(ee.coeff(q0*q1)+oo.coeff(q0*q1)/3)/4)
    mass=clean(s.trace(EQ).subs(q1,0).expand().coeff(q0,2))
    return {'a':clean(-2*alpha),'b':clean(2*(beta+gamma)),'c':clean(2*(delta-beta)),'n':mass,
      'alpha':alpha,'beta':beta,'gamma':gamma,'delta':delta}
def main():
    start=begin();rows={}
    for n in [3,4,5,6]:rows[n]=heat_dimension(n);print('STAGE ordered_heat_N'+str(n),flush=True)
    general={k:clean(rows[3][k]+(N-3)*(rows[4][k]-rows[3][k])) for k in rows[3]}
    for n in [5,6]:assert all(clean(value.subs(N,n)-rows[n][k])==0 for k,value in general.items())
    co={k:clean(general[k].subs(N,4-2*eps)) for k in ['a','b','c','n']};pole={k:clean(v.subs(eps,0)) for k,v in co.items()}
    old=packed(CAL/'canonical_so10_three_vector_uv_forests/primary_tables.json.gz');ratio=s.sympify(old['triangle']['ratio'])
    for k in ['a','b','c','n']:assert pole[k]==s.sympify(old['per_index'][k if k!='n' else 'mass'])
    def opened(vals):
        a,b,c,n=[vals[k] for k in ['a','b','c','n']]
        return clean(ratio*((10+eps)*a+b/2-12*(c+2*a)/eps-(10+eps)*n/(d*(1-eps)))/eps)
    a,b,c,n=[pole[k] for k in ['a','b','c','n']]
    ct=clean(ratio*(-(10+eps)*a-b/2+12*(c+2*a)/eps+(10+eps)*n/d)/eps)
    bare=opened(co);bj=gamma_jet(bare,2*j-ld,2);cj=gamma_jet(ct,j-ld,1);ren=[clean(u+v) for u,v in zip(bj,cj)]
    early=gamma_jet(opened(pole),2*j-ld,2);noc=dict(co);noc['c']=pole['c'];no_curv=gamma_jet(opened(noc),2*j-ld,2)
    save('primary',{'schema':'V3M1_OPENED_HEAVY_LOOP','general_N':{k:str(v) for k,v in general.items()},
      'integer_N_checks':{str(n):{k:str(v) for k,v in row.items()} for n,row in rows.items()},
      'coefficient_BM':{k:str(v) for k,v in co.items()},'mass_additional_factor':'1/(1-eps)',
      'soft_bare_gamma2_ratio':str(bare),'soft_CT_gamma1_ratio':str(ct),'soft_bare_Laurent':list(map(str,bj)),
      'soft_CT_Laurent':list(map(str,cj)),'soft_renormalized_Laurent':list(map(str,ren)),
      'early_D4_change':list(map(str,[clean(u-v) for u,v in zip(early,bj)])),
      'omitted_finite_curvature_change':list(map(str,[clean(u-v) for u,v in zip(no_curv,bj)])),
      'positive_minus_hard_used_to_determine_input':False,'mass_and_scale_selected_as_physical_point':False},start)
if __name__=='__main__':main()
