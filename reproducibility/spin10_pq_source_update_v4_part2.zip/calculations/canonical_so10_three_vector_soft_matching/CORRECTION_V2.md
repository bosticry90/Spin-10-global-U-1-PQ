# V3M1 diagnostic and V3L hard-forest correction

Original V3M primary/replay completed and agree exactly on general-N
operators and full meromorphic soft heat region. Original validation FAILED
its unchanged finite convergence criterion; preserve its capture/source and
failure classification. No matching receipt was issued. Diagnostic-only run
then completed all points and recorded the same criteria false; it was not
a weakened validation or scientific qualification.

At d->0 the light charge remainder converges to V3L. Both heavy charge
remainders instead approach the stored hard value minus2pi². The cause is
identifiable in the historical V3L primary.py: hard_forest_Q1 was assigned
the UV prefactor coefficients, before multiplying its H_eps(1). The bare
hard integral itself includes its complete two-loop gamma factors and agrees
with the positive-mass bare limit. No soft term is being fitted or changed.

The remaining-loop H_eps(1)=exp(gamma eps)Gamma(1+eps) has nonzero quadratic
coefficient zeta2/2. Multiplication by a double pole changes the finite hard
forest. This follows independently from the original V3U meromorphic forest,
not from assigning the observed numerical discrepancy a desired value.

New bounded correction first computes the entire hard forest through finite
order with this factor, then compares it to a Cauchy extraction of the
unexpanded gamma expression and the positive V3U forest limit. Freeze
600s,8GiB sampled,350MiB launch,6MiB package; 110digits and32/48nodes with
radius1/32 and1/64, errors<1e-35, imaginary<1e-90. Bare hard coefficients,
UV coefficients, action, scales, regulator and finite physical scheme remain
unchanged. No desired hard finite number is an input.

The new correction receipt must be a mandatory dependency wherever the
V3L hard finite forest or hard Rprime is used. It supersedes those finite
arrays only; old V3L source/tables/receipts/commit remain exact historical
evidence. Then verify_v2 reuses completed V3M native results and applies the
SAME original pole, convergence, final-error, dimensional and control gates
against corrected hard arrays. Do not rerun completed native algebra merely
to generate a new receipt. A second mismatch still blocks matching.

This is a consequential finite-assembly implementation error, exposed by
the independent matching calculation. Earlier V3L numerical agreement tested
its bare hard integral, not this missing gamma term in the forest assembly.
Record that verification blind spot in the AI-capability assessment. No
project_state, authority34/39, E5/A5 or physical-model promotion follows.
