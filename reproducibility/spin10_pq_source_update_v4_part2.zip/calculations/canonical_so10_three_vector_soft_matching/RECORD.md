# V3M1 — actual opened heavy-vector loop and complete one-light matching

Question V3M1: does the independently derived soft response of the actual
cubic-vector loop agree with the ordered heat-region expansion and complete
the V3L one-light hard matching? This is the missing prerequisite for the
three mixed-light VVV orbits, not an optional finite adjustment.

Freeze before computation: V3S actual cubic interaction; V3K general-D F2
heat numerator; V3U original UV operators/cut normalization/forests; V3B
positive absolute kernel; V3L meromorphic hard region. Same xi1 C1 Euclidean
parity-even covariantly constant F2 reference, positive equal heavy squared
mass M, regulated light squared mass delta>0, d=delta/M, j=log(Q2/M).
No heavy internal auxiliary-delta shift in this fixed domain. No new finite
field/parameter scheme or physical point is adopted. Keep D=4-2eps until
finite extraction, both source-derivative boundary conventions and original
real Gaussian weight. No full-vector/quartic/ghost pole substitutes for cubic.

Primary derives general-N first-jet, ordered curvature and mass heat
coefficients of the linear-in-Q Hessian, then its a2/a4 massive low-momentum
operator. Lorentz coefficients have degree<=1 in N by explicit spectator
counting; check N=3,4 and separately5,6. Close the actual light-vector
propagator with the complete meromorphic heavy coefficients and original UV
CT. No desired positive-minus-hard remainder is an input to this derivation.

Replay evaluates the literal massive flat bubble, retains D-dependent
numerators, and checks the independent constant-density curvature Hessian.
It also derives every unsuppressed large-light-time term from the actual
V3K numerator, preserving gamma functions and all charge axes. It reads no
primary calculation output. Validation compares opened-loop/heat-region
meromorphic coefficients exactly, including zero complementary axes, then
compares the independently fixed soft subtraction with actual positive-mass
master values and V3L hard coefficients.

Asymptotics: two equal positive heavy masses exclude another unsuppressed
soft region. For each degree5 monomial retain every large-light-time power
d^p with p<=0; the next power is at least1 with at most double epsilon
poles, so omitted finite terms have order d log^k d,k<=2 in the inherited
meromorphic region prescription. No new absolute/causal regulator-limit
theorem is claimed. Explain identity-contact conventions and vector higher-
derivative power counting; do not transfer a scalar proof without adaptation.

Numerical checks at d=10^-4,10^-8,10^-12,120digits, j=0 and1/3. Final
absolute matched-to-hard difference<1e-5 on all axes, refinement ratio<1/100
between these points; imaginary leak<1e-70. These are diagnostics, not a
uniform error bound or substituted matching definition. A failed comparison
must preserve the remainder, not fit the soft coefficients.

Controls: early-D4 heavy loop, missing finite curvature, doubled light CT,
omitted soft term, lost gamma positive jets, and a heavy-charge soft term
that must cancel only after the full sum. Record insensitive projections.
Sequential primary/replay/validation each600s,8GiB sampled private,
350MiB available commit at launch,6MiB package. Preserve failures/captures;
incomplete calculations have no receipt. Reuse existing tools, no subagents.

Possible results: qualified scoped matching; exact nonzero mismatch;
underdefined domain; resource inconclusive. Director acceptance NOT_PERFORMED,
state113/authority34of39 unchanged. VVV model sum and amplitude inventory
promotion require a separate complete model calculation. Shared action,
heat/locality premises, master functions, software and AI authorship limit
independence; no outside or physical confirmation is implied.
