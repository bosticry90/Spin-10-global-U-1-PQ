"""V3M1 frozen IO, exact jets and qualified absolute master."""
from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
R=s.Rational
x,y,z,eps=s.symbols('x y z eps',positive=True);masses=[x,y,z];J=s.Symbol('J',real=True)
def clean(v):return s.cancel(s.expand(v))
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def expr(v):return s.sympify(v,locals={str(t):t for t in [*masses,eps,J]})
def mat(v):return s.SparseMatrix(*v['shape'],{(i,j):s.sympify(a) for i,j,a in v['entries']})
def tidy(M):return s.SparseMatrix(M).applyfunc(clean)
def enc(M):return {'shape':list(map(int,M.shape)),'entries':[[int(i),int(j),str(v)] for (i,j),v in sorted(tidy(M).todok().items())]}
def zero(M):assert not tidy(M).todok(),'NONZERO_MATRIX'
def tr(A,B):return clean(sum((v*B[j,i] for (i,j),v in A.todok().items()),s.Integer(0)))
def begin(prep='preparation.json'):
    start=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for p,h in json.loads((HERE/prep).read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
    return start
def save(role,v,start):
    raw=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/f'{role}_tables.json.gz').open('xb') as f:f.write(blob)
    print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':time.perf_counter()-start,'tables_sha256':sha256(raw).hexdigest(),
      'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)

st,tt,ut,D=s.symbols('s t u D',positive=True);times=[st,tt,ut];U=st*tt+st*ut+tt*ut
j=s.Symbol('j',real=True)
def heat_axes():
    tab=packed(CAL/'canonical_so10_three_vector_heat_kernel/primary_tables.json.gz')
    return [s.sympify(v,locals={str(t):t for t in [*times,D]}) for v in tab['charge_axes']]

import importlib.util,sys
import mpmath as mp
d=s.Symbol('d',positive=True);N=s.Symbol('N',integer=True,positive=True);ld=s.Symbol('ld',real=True)
def ratio_jet(rr):
    vv=s.series(rr,eps,0,1).removeO().expand()
    assert s.limit(eps**2*rr,eps,0).is_finite
    return [clean(vv.coeff(eps,k)) for k in [-2,-1,0]]
def gamma_jet(rr,L,gammas):
    a,b,c=ratio_jet(rr)
    return [a,clean(b+a*L),clean(c+b*L+a*(L*L/2+gammas*s.zeta(2)/2))]
def load(n,p):
    spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def absolute_master():
    return load('v3m_cck_data',CAL/'canonical_so10_charged_current_kernel/data.py').finite_master_coefficients()
def read(v):
    return s.sympify(v,locals={str(t):t for t in [*masses,eps,j,d,N,ld]})
