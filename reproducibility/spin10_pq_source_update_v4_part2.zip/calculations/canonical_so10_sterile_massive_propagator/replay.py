"""SMP1 direct inversions in faithful complementary small representations."""
from data import *
start=begin('replay');b,h=s.symbols('b h',real=True);m,mb=s.symbols('m mbar');B=b*b;H=h*h;P=B+H;z=m*mb
gb=s.Matrix([[0,1],[1,0]]);chi=s.diag(1,-1);PL=(s.eye(2)+chi)/2;PR=s.eye(2)-PL;M=PL*m+PR*mb;Mt=PL*mb+PR*m
def tidy(X):return X.applyfunc(lambda q:s.factor(s.cancel(q)))
def block(a,b,c,d):return s.BlockMatrix([[a,b],[c,d]]).as_explicit()
def algebra(gh):return [s.eye(2),chi,gb,gh,chi*gb,chi*gh,gb*gh,chi*gb*gh]
allinv={0:[],1:[]};det={0:[],1:[]};bas=[]
for sign in [1,-1]:
 gh=sign*chi;bas.append(algebra(gh));D0=block(s.I*b*gb+M,s.I*h*gh,s.I*h*gh,s.I*b*gb)
 D1=block(s.I*b*gb+M,s.I*h*gh,s.I*h*gh,s.I*b*gb+Mt)
 for k,D in [(0,D0),(1,D1)]:
  S=tidy(D.inv());assert tidy(D*S-s.eye(4))==s.zeros(4) and tidy(S*D-s.eye(4))==s.zeros(4)
  allinv[k].append(S);det[k].append(str(s.factor(D.det())))
mapmat=s.Matrix.hstack(*[s.Matrix(list(bas[0][j])+list(bas[1][j])) for j in range(8)]);assert mapmat.det()!=0
mi=mapmat.inv();den=[P**2+z*B,P+z];co={}
for k in [0,1]:
 rows=[]
 for br,bc in [(0,0),(0,1),(1,0),(1,1)]:
  vec=[]
  for S in allinv[k]:vec+=list(tidy(S[2*br:2*br+2,2*bc:2*bc+2]*den[k]))
  rows.append([str(s.factor(q)) for q in mi*s.Matrix(vec)])
 co[k]=rows
# A nontrivial complex unitary phase/rotation witness, not a physicalYukawa point.
U=s.Matrix([[s.Rational(3,5),s.Rational(4,5)*s.I],[s.Rational(4,5)*s.I,s.Rational(3,5)]]);assert U.H*U==s.eye(2)
Qp=s.kronecker_product(PL,U)+s.kronecker_product(PR,s.conjugate(U));Qs=s.kronecker_product(PL,s.conjugate(U))+s.kronecker_product(PR,U)
Qbp=s.kronecker_product(PL,U.T)+s.kronecker_product(PR,U.H);Qbs=s.kronecker_product(PL,U.H)+s.kronecker_product(PR,U.T)
ggb=s.kronecker_product(gb,s.eye(2));ggh=s.kronecker_product(chi,s.eye(2))
assert Qbp*ggb*Qp==ggb and Qbs*ggb*Qs==ggb
assert Qbp*ggh*Qs==ggh and Qbs*ggh*Qp==ggh and Qbp*ggh*Qp!=ggh
aa,bb,cc=s.symbols('a beta c');Y=s.Matrix([[aa,bb],[bb,cc]]);Yc=s.conjugate(Y).T
MM=s.kronecker_product(PL,Y)+s.kronecker_product(PR,Yc)
expected=s.kronecker_product(PL,U.T*Y*U)+s.kronecker_product(PR,U.H*Yc*s.conjugate(U))
assert tidy(Qbp*MM*Qp-expected)==s.zeros(4)
finish('replay',{'method':'independent_direct_inverse_of_two_complementary_Clifford_representations','denominator_case0':str(s.expand(den[0])),'denominator_case1':str(den[1]),
 'case0_block_numerator_coefficients':co[0],'case1_block_numerator_coefficients':co[1],'determinants_small_witness':det,
 'faithful_coefficient_map_rank':mapmat.rank(),'paired_family_transport_checks':5,'untransported_auxiliary_rotation_rejected':True,
 'symbolic_mass_congruence_checked':True,'test_unitary_is_not_a_flavor_point':True,'new_loop_integrals':0,'provisional_only':True},start)
