"""SMP1 complete coefficient comparison, symbol limits and misuse controls."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,hv in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==hv,p
P0=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');b,h=s.symbols('b h',real=True);m,mb=s.symbols('m mbar');local={'b':b,'h':h,'m':m,'mbar':mb}
parse=lambda z:s.sympify(z,locals=local)
def zero(M):assert not M.applyfunc(lambda z:s.factor(s.cancel(z))).todok()
count=0
for name in ['case0_block_numerator_coefficients','case1_block_numerator_coefficients']:
 assert len(P0[name])==len(R[name])==4
 for a,c in zip(P0[name],R[name]):
  assert len(a)==len(c)==8
  for x,y in zip(a,c):assert s.factor(parse(x)-parse(y))==0;count+=1
assert count==64
B=b*b;H=h*h;P=B+H;z=m*mb;den0=P**2+z*B;den1=P+z
assert s.expand(parse(P0['denominator_case0'])-den0)==s.expand(parse(R['denominator_case0'])-den0)==0
assert s.expand(parse(P0['denominator_case1'])-den1)==s.expand(parse(R['denominator_case1'])-den1)==0
for x in R['determinants_small_witness']['0']:assert s.expand(parse(x)-den0)==0
for x in R['determinants_small_witness']['1']:assert s.expand(parse(x)-den1**2)==0
gb=s.Matrix([[0,1],[1,0]]);chi=s.diag(1,-1);PL=(s.eye(2)+chi)/2;PR=s.eye(2)-PL;M=PL*m+PR*mb;Mt=PL*mb+PR*m
limit_positions=0
for sign in [1,-1]:
 gh=sign*chi;basis=[s.eye(2),chi,gb,gh,chi*gb,chi*gh,gb*gh,chi*gb*gh]
 mats=[]
 for name,den in [('case0_block_numerator_coefficients',den0),('case1_block_numerator_coefficients',den1)]:
  mats.append([sum((parse(c)*q for c,q in zip(row,basis)),s.zeros(2))/den for row in P0[name]])
 a,c=mats
 expected=-H*(s.I*b*gb*z+Mt*P)/(den0*den1);zero(a[0]-c[0]-expected)
 assert any(s.factor(v)!=0 for v in expected)
 zero((a[0]-(-s.I*b*gb+Mt)/(B+z)).subs(h,0));zero((c[0]-(-s.I*b*gb+Mt)/(B+z)).subs(h,0))
 zero(a[0].subs(b,0));zero((a[1]+s.I*gh/h).subs(b,0));zero((a[2]+s.I*gh/h).subs(b,0));zero((a[3]-M/H).subs(b,0))
 for x,y in zip(a,c):zero((x-y).subs({m:0,mb:0}));limit_positions+=4
assert s.expand(den0-P*(P+z))==-z*H
assert P0['polynomial_left_right_inverse_positions']==4096 and P0['bar_zero_extension_checked'] and P0['strict4D_and_massless_limits_checked']
assert R['faithful_coefficient_map_rank']==8 and R['paired_family_transport_checks']==5 and R['untransported_auxiliary_rotation_rejected'] and R['symbolic_mass_congruence_checked']
yr=read(CAL/'canonical_so10_yukawa_carrier_transport/validation_receipt.json');scale=s.sympify(yr['reference_sigma_squared'])*s.sympify(yr['abs_c_N_squared']);assert scale==s.Rational(3,10)
assert read(CAL/'canonical_so10_sterile_matter_action/validation_receipt.json')['strict4D_physical_Weyl_action_recovered']
for d in [P0,R]:assert d['new_loop_integrals']==0 and d['provisional_only']
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_FINITE_HAT_MASSIVE_REFERENCE_INVERSES_AND_AUXILIARY_COMPARISON','elapsed_after_imports':time.perf_counter()-start,
 'block_algebra_coefficients_compared':count,'polynomial_inverse_positions':4096,'faithful_small_representation_algebra_rank':8,
 'case0_denominator':'(barp^2+hatp^2)^2+|m|^2*barp^2','case1_denominator':'barp^2+hatp^2+|m|^2',
 'case0_standard_massive_substitution_valid_at_finite_hats':False,'case0_spurious_bar_zero_singularity_removed':True,'strict4D_and_massless_limits_match':True,
 'physical_propagator_difference':'-hatp^2*(i*bar_slash*|m|^2+Mt*p^2)/(D0*(p^2+|m|^2))',
 'paired_family_and_auxiliary_basis_transport_checked':True,'rotating_physical_basis_only_rejected':True,'neutral_mass_squared_per_Y126_singular_value_squared':'3/10',
 'auxiliary_mass_is_constant_field_independent_reference_only':True,'auxiliary_normalization_parameter_dependence_requires_future_treatment':True,
 'new_loop_integrals':0,'new_numerical_flavor_or_mass_point':False,'quantum_scheme_conversion_measure_phase_QAP_qualified':False,'case1_adopted_as_physical_scheme':False,
 'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
