"""SMP1 full split-Clifford Schur inverse and polynomial continuation."""
from data import *
start=begin('primary');b,h=s.symbols('b h',real=True);m,mb=s.symbols('m mbar');B=b*b;H=h*h;P=B+H;z=m*mb
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g4=[s.kronecker_product(pa[1],q) for q in pa]+[s.kronecker_product(pa[0],s.eye(2))]
g8=[s.kronecker_product(g,pa[2]) for g in g4]+[s.kronecker_product(s.eye(4),q) for q in pa[:2]]
gb=s.kronecker_product(g8[0],s.eye(2));gh=s.kronecker_product(g8[4],s.eye(2));chi=s.kronecker_product(s.diag(1,1,-1,-1),s.eye(4));PL=(s.eye(16)+chi)/2;PR=s.eye(16)-PL;I=s.eye(16)
M=PL*m+PR*mb;Mt=PL*mb+PR*m;bs=b*gb;hs=h*gh
def tidy(X):return s.SparseMatrix(X).applyfunc(lambda q:s.factor(s.cancel(q)))
def zero(X):assert not tidy(X).todok()
def block(a,b,c,d):return s.SparseMatrix(s.BlockMatrix([[a,b],[c,d]]).as_explicit())
zero(bs*hs+hs*bs);zero(bs*M-Mt*bs);zero(hs*M-M*hs);zero(M*Mt-z*I)
D0=block(s.I*bs+M,s.I*hs,s.I*hs,s.I*bs);den0=s.expand(P**2+z*B)
dsinv=-s.I*bs/B;Q=s.I*bs+M-s.I*hs*dsinv*s.I*hs
qinv=(-s.I*bs*P/B+Mt)/(P**2/B+z);zero(Q*qinv-I);zero(qinv*Q-I)
S0=[qinv,-qinv*s.I*hs*dsinv,-dsinv*s.I*hs*qinv,dsinv+dsinv*s.I*hs*qinv*s.I*hs*dsinv]
nums0=[tidy(q*den0) for q in S0];zero(D0*block(*nums0)-den0*s.eye(32));zero(block(*nums0)*D0-den0*s.eye(32))
D1=block(s.I*bs+M,s.I*hs,s.I*hs,s.I*bs+Mt);den1=P+z
nums1=[-s.I*bs+Mt,-s.I*hs,-s.I*hs,-s.I*bs+M]
zero(D1*block(*nums1)-den1*s.eye(32));zero(block(*nums1)*D1-den1*s.eye(32))
basis=[I,chi,gb,gh,chi*gb,chi*gh,gb*gh,chi*gb*gh]
assert s.Matrix(8,8,lambda i,j:s.trace(basis[i].H*basis[j])/16)==s.eye(8)
def coefficients(nums):
 rows=[]
 for mat in nums:
  co=[s.factor(s.trace(q.H*mat)/16) for q in basis];zero(mat-sum((c*q for c,q in zip(co,basis)),s.zeros(16)));rows.append(list(map(str,co)))
 return rows
diff=tidy(nums0[0]/den0-nums1[0]/den1)
expected=-H*(s.I*bs*z+Mt*P)/(den0*den1);zero(diff-expected)
zero((nums0[0]-nums1[0]*den0/den1).subs(h,0))
zero((D0*block(*nums0)-den0*s.eye(32)).subs(b,0))
zero((nums0[0]/den0-(-s.I*bs+Mt)/(B+z)).subs(h,0))
for a,c in zip(nums0,nums1):zero((a/den0-c/den1).subs({m:0,mb:0}))
finish('primary',{'method':'full_split_Clifford_Schur_then_cleared_polynomial_identity','denominator_case0':str(den0),'denominator_case1':str(den1),
 'case0_block_numerator_coefficients':coefficients(nums0),'case1_block_numerator_coefficients':coefficients(nums1),
 'physical_difference_formula':'-h^2*(i*bar_slash*m*mbar+Mt*(b^2+h^2))/((P^2+m*mbar*b^2)*(P+m*mbar))',
 'polynomial_left_right_inverse_positions':4096,'bar_zero_extension_checked':True,'strict4D_and_massless_limits_checked':True,
 'auxiliary_mass_reference_alternative_only':True,'new_loop_integrals':0,'provisional_only':True},start)
