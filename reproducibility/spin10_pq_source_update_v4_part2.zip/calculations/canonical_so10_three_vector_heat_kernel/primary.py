"""V3K1 nine ordered Lorentz traces in the exact magnetic I/J algebra."""
from data import *
def add(A,B):return [(a+c,b+d) for (a,b),(c,d) in zip(A,B)]
def scale(A,c):return [(c*a,c*b) for a,b in A]
def mul(A,B):
    out=[(0,0)]*3
    for n in range(3):
        out[n]=(sum(A[k][0]*B[n-k][0]-A[k][1]*B[n-k][1] for k in range(n+1)),sum(A[k][0]*B[n-k][1]+A[k][1]*B[n-k][0] for k in range(n+1)))
    return out
def trans(A):return [(a,-b) for a,b in A]
def trace(A,spectator):return [2*a+((D-2)*spectator if n==0 else 0) for n,(a,b) in enumerate(A)]
def scalar_mul(A,B):return [sum(A[k]*B[n-k] for k in range(n+1)) for n in range(3)]
def build(spin=True,connection=True,off=True):
    aa=[1/v for v in times];h=sum(aa);dh=sum(q*q*t for q,t in zip(charges,times))/3
    L=[[(a,0),(0,s.I*q if connection else 0),(q*q*t/3,0)] for a,q,t in zip(aa,charges,times)]
    Hinv=[(1/h,0),(0,0),(-dh/h**2,0)];C={};C0={}
    for i in range(3):
        for j in range(3):
            C[i,j]=add(scale(L[i],s.Rational(1,2) if i==j else 0),scale(mul(mul(L[i],Hinv),L[j]),-s.Rational(1,2)))
            C0[i,j]=((aa[i] if i==j else 0)-aa[i]*aa[j]/h)/2
    E=[[(1,0),(0,2*s.I*q*t if spin else 0),(2*q*q*t*t if spin else 0,0)] for q,t in zip(charges,times)]
    currents={};c0={}
    for m in range(3):
        for n in range(3):
            left=[((m+1)%3,1),((m+2)%3,-1)];right=[((n+1)%3,1),((n+2)%3,-1)];out=[(0,0)]*3;zero=0
            for i,ci in left:
                for j,cj in right:out=add(out,scale(C[i,j],ci*cj));zero+=ci*cj*C0[i,j]
            currents[m,n]=out;c0[m,n]=zero
    diag=[0]*3;interference=[0]*3
    for m in range(3):
        others=[i for i in range(3) if i!=m];a,b=others
        term=scalar_mul(trace(mul(trans(E[m]),currents[m,m]),c0[m,m]),trace(mul(E[a],trans(E[b])),1))
        diag=[v+w for v,w in zip(diag,term)]
        if off:
            for n in range(3):
                if m==n:continue
                k=3-m-n;M=mul(mul(E[m],trans(E[k])),E[n]);term=trace(mul(trans(M),currents[m,n]),c0[m,n]);interference=[v+w for v,w in zip(interference,term)]
    total=[clean(v+w) for v,w in zip(diag,interference)];orb=-sum(q*q*t*t for q,t in zip(charges,times))/6-dh/h
    P2=clean(total[2]+total[0]*orb)
    anchor=trace(mul(trans(E[2]),currents[2,2]),c0[2,2]);anchor2=clean(anchor[2]+anchor[0]*orb)
    return total[0],P2,{'diagonal_B2':clean(diag[2]),'interference_B2':clean(interference[2]),'orbital_B2':clean(total[0]*orb)},anchor2,total[1]
def main():
    start=begin();K,P,pieces,anchor,odd=build();U=st*tt+st*ut+tt*ut
    assert clean(K-3*D*(D-1)*(st+tt+ut)/U)==0 and odd==0
    old=expr(packed(CAL/'canonical_so10_scalar_current_sunset/primary_kernel_tables.json.gz')['P2']);assert clean(anchor-old)==0
    A=axes(P);controls={}
    for name,args in [('delete_spin',{'spin':False}),('delete_endpoint_connection',{'connection':False}),('omit_off_diagonal_traces',{'off':False})]:
        kk,pp,ignored,anch,o=build(**args);delta=clean(pp-P);assert delta!=0;controls[name]=str(delta)
    save('primary',{'schema':'V3K1_PRIMARY','K0':str(K),'P2':str(P),'charge_axes':list(map(str,A)),
      'pieces':{k:str(v) for k,v in pieces.items()},'SCP_current_anchor_residual':'0','odd_B_coefficient':'0','controls':controls,
      'D_degree_bound':2,'Lambda_prefactor':'g10^2/2','VVV_Wick_weight':'-1/12','proper_forests_or_amplitude_qualified':False},start)
if __name__=='__main__':main()
