# V3K1: full ordered bare three-vector local F2 heat kernel

Base0de34cedb9d517880da378b6266c4a285942b932/main, clean/no live workers.
Previous goal turn PROGRESS:GVA complete ghostV, V3S actual VVV input domain.
Whole Spin(10)xPQ objective ACTIVE;state113/authority34of39 unchanged.

Question: what is the actual general-D ordered VVV F2 numerator, with all
three spin-one heat factors and both derivative vertices retained? This is
a necessary missing amplitude input. Cheapest competent test: exact local
endpoint/Lorentz contraction, compare two different tensor organizations,
and independently extract B2 from unexpanded finite-B heat functions. Reuse
V3S/BFT actual cubic recipe and SCP's already-qualified endpoint heat kernel;
do not repeat45-color contractions or fit a UV remainder.

Types: C1 xi1 Euclidean local parity-even F2 Taylor projection at positive
auxiliary IR mass, D=4-2eps. Three positive proper times s,t,u; signed real
charges q1+q2+q3=0. Mass projectors commute with the unbroken H background.
A single covariantly constant magnetic plane extracts this declared local
kinetic coefficient; this is not an arbitrary varying-background functional.
Positive squared masses remain outside the universal numerator. Keep their
IR regulator and dimensional continuation when later integrating. Finite-B
samples are analytic controls at fixed proper times, not a new stable finite-
field physical background. No new scheme, action, point or source law.

Primary contracts the cubic vertex as nine matrix traces, in its2-plane
I/J algebra with D-2 spectator directions. It keeps the endpoint contact,
right-end cotangent connection, three ordered spin factors and the orbital
Gaussian determinant. Replay enumerates36 labelled vertex pairs with full
integer-dimensional Lorentz indices, reconstructs the degree<=2 polynomial
in D from dimensions2/3/4, and tests dimensions5/6 independently. The trace
network has at most two closed spectator sums, providing that degree bound.
This interpolation is not an unreported cutoff on a tensor expansion.

The complete mixed-endpoint covariance and scalar heat function are shared
qualified SCP premises; the trace-network and literal-index contractions are
different algorithms, not independent physical assumptions. Require exact
K0 and P2 equality, all six mass/charge-leg permutations, homogeneity,
simultaneous charge reversal, and conservation-compatible three-charge axes.
K0 must reproduce3D(D-1)(s+t+u)/(st+su+tu). The diagonal current block must
recover the authenticated SCP P2 exactly at generalD, without selectingq3=0.

Replay also uses the UNEXPANDED sinh/coth/spin matrices and scalar determinant
with its literal36-pair dictionary. At100digits use CauchyN24/32,radius1/1024
andN32,radius1/2048, for frozen times/charges/D:
(1,2,3)/(1,2,-3)/D3; (2,3,5)/(1,-1,0)/D4;
(3/2,7/3,5/4)/(2,-3,1)/D6. CompareB0/B2 to exact primary within1e-40
scaled, refinements1e-40, imaginary leakage1e-70. Include charge0 by its
continuous heat limit. No small-B result determines an unknown coefficient.

Controls: delete vector spin, delete the endpoint connection, omit six
off-diagonal trace terms, and setD4 early. Each must change the actual
general-D expression; report insensitive special samples. Preserve the real
VVV Wick weight-1/12 and Fphys^2=2B^2, hence Lambda/g^2=(1/2)sum W_i U_i
in the existing normalization. Do not import the ghost prefactor.

Freeze all sources/input hashes before execution. Sequential primary/replay,
then separately frozen verifier.600s each,8GiB sampled private,350MiB launch
floor,6MiB package, exclusive full captures. Preserve failed and incomplete
runs. Legitimate outcomes: qualified bare heat polynomial, counterexample,
underdefinition or inconclusive. No finite amplitude, actual UV cut/forest,
soft/EFT theorem or primitive7 qualification from this result. In particular
do not assume its bare double poles vanish; isolated spin counterterms may
generate double poles requiring other class/parent partners. Full C1/E5/A5,
HB1/C5 blocks and matter pause remain. Acceptance NOT_PERFORMED; no state
edit, physical promotion, publication/push/outreach. Preserve26956 old blobs.
