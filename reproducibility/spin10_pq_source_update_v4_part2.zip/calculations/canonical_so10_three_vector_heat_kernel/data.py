"""V3K1 frozen symbolic domain, input authentication and exclusive IO."""
from pathlib import Path
from hashlib import sha256
from itertools import product,permutations
import json,gzip,sys,time,threading,os,importlib.util
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
st,tt,ut,D=s.symbols('s t u D',positive=True);times=[st,tt,ut];q1,q2,q3=s.symbols('q1 q2 q3',real=True);charges=[q1,q2,q3]
LOC={str(v):v for v in times+[D,*charges]};LOC['qv']=q3
def clean(v):return s.cancel(s.expand(v))
def expr(v):return s.sympify(v,locals=LOC)
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def load(n,p):
    spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def begin(prep='preparation.json'):
    start=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for p,h in json.loads((HERE/prep).read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
    return start
def save(role,v,start):
    raw=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/f'{role}_tables.json.gz').open('xb') as f:f.write(blob)
    print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':time.perf_counter()-start,'tables_sha256':sha256(raw).hexdigest(),
      'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)
def axes(P):
    z=s.Poly(clean(P.subs(q3,-q1-q2)),q1,q2);A=z.coeff_monomial(q1*q1);B=z.coeff_monomial(q2*q2);C=z.coeff_monomial(q1*q2)
    out=list(map(clean,[A-C/2,B-C/2,C/2]));assert clean((P-sum(v*q*q for v,q in zip(out,charges))).subs(q3,-q1-q2))==0
    return out
def parity(pi):return (-1)**sum(pi[i]>pi[j] for i in range(3) for j in range(i+1,3))
