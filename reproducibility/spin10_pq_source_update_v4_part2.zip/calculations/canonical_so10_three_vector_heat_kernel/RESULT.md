# V3K1: complete ordered bare VVV F2 heat numerator

Qualified by validation_receipt.json, SHA256
b2f9c8b63350f586702d3b6e680ab9246f5fc2ca766661c490971c4d289a79a9,
within the frozen C1 xi1 Euclidean local magnetic-plane F2 reference.
Scientific acceptance NOT_PERFORMED;state113/authority34of39 unchanged.

The actual V3S cubic vertex has now been contracted with all three vector
spin factors, endpoint derivatives and the scalar orbital heat determinant.
The result is an explicit general-D proper-time numerator with three charge
axes. It retains all29 labelled background insertions through the complete
covariant heat/vertex construction, rather than using only the flat vertex.

Primary uses nine ordered Lorentz traces with D-2 spectators. Replay instead
contracts all36 labelled cubic-vertex pairs with literal Lorentz indices in
dimensions2/3/4, reconstructs the degree-at-most2 polynomial in D, and checks
dimensions5/6 independently. The exact trace-network bound is two closed
spectator sums. Both calculations agree exactly, including the odd-B zero,
all six simultaneous edge/charge permutations, positive-time homogeneity and
simultaneous charge reversal. Charge conservation gives

    P2=P1(s,t,u,D)q1^2+P2_axis(s,t,u,D)q2^2+P3(s,t,u,D)q3^2.

The full functions are in both authenticated native tables. Each is a compact
rational polynomial over2(st+su+tu)^2, with D^2 terms retained. This is a
computed kernel, not a list of possible profiles or a fitted Ward remainder.

The B0 result reproduces the independently derived flat normalization
3D(D-1)(s+t+u)/(st+su+tu). A diagonal current block agrees exactly with the
qualified SCP scalar-current P2 at generalD and general conserving charges.
That anchors the Fourier, right-cotangent and derivative-contact conventions.
The full VVV kernel also includes the other spin traces and six interference
terms; no scalar kernel was merely multiplied by a vector multiplicity.

Replay independently used UNEXPANDED coth/sinh heat functions, full spin
matrices and the orbital determinant at fixed positive proper times. Cauchy
extraction at100digits,N24/32,radius1/1024 andN32,radius1/2048 compared B0
andB2 in dimensions3,4,6 with three conserving charge assignments, including
a zero-charge edge. The maximum scaled error and refinement are
2.71093908111e-59, passing1e-40; maximum imaginary leakage5.39329116061e-94
passes1e-70. These are finite-proper-time analytic controls, not a finite-field
stability theorem or a physical IR limit.

Deleting vector spin, deleting the endpoint connection or omitting the
off-diagonal trace terms changes the actual P2. The earlyD4 control retains
both lost epsilon and epsilon-squared Lorentz jets. Those terms can multiply
UV poles in the later integral; no conclusion about its finite or divergent
coefficient is inferred from the heat numerator alone.

The real VVV Wick factor remains-1/12. With Fphys^2=2B^2, the existing Lambda
normalization gives Lambda_VVV/g10^2=(1/2)sum_i W_i U_i with positive actual
color/charge weights. The ghost prefactor is not imported. The local parity-
even F2 coefficient is extracted on one magnetic plane, with authenticated H
covariance supplying the ideal charge contractions. No arbitrary varying-
background, multiple-insertion, QAP or quantum-equivalence claim is made.

| Worker | Seconds after imports | Max sampled private bytes |
| --- | ---: | ---: |
| Nine-trace primary | 125.1272913 | 70,897,664 |
| Literal/finite-heat replay | 62.7421619 | 61,923,328 |
| Separate verifier | 2.8604452 | Recorded in full capture |

Sources and3,565 initial bindings were frozen. Commands prepare.py;run.py.
All native worker/controller/verifier executions completed. No failed native
run, timeout, cancellation or native truncation in V3K1. One initial read-only
file-inventory lookup referenced a nonexistent conventional quartic folder;
the actual inventory was recovered. Bounds600s,8GiB sampled private,350MiB
launch floor,6MiB package. Sampling does not establish a continuous memory peak.

TrackB demonstrates a full ordered Lorentz/heat construction in two tensor
representations and an unexpanded-function check, using existing normalization
evidence. Both methods share the action, scalar heat/endpoint premises,
magnetic-plane reference, software and AI authorship. Agreement cannot validate
those premises. There is no proof-assistant, outside-expert or empirical
confirmation. The construction is auditable within its declared formal scope.

The positive-mass bare Laurent integral is the next dependent V3B step. Do not
assume its double poles vanish; isolated spin/curvature classes can need
quartic or parent partners. Original proper forests, single-light matching,
complete VVV model amplitude and full parent assembly remain outstanding.
Primitive amplitude inventory remains6/9. Full C1/E5/A5 unqualified; authority,
physical benchmark, protected blocks, matter pause and historical limitations
are unchanged. No state edit, scheme adoption, publication or push.
