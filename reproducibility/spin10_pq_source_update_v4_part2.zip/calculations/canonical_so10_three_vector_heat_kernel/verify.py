"""V3K1 independent source-bound exact and finite-heat comparison."""
from data import *
def main():
    start=begin('validation_preparation.json');mp.mp.dps=100
    A,B=[packed(HERE/f'{r}_tables.json.gz') for r in ['primary','replay']];K,P=expr(A['K0']),expr(A['P2'])
    assert clean(K-expr(B['K0']))==clean(P-expr(B['P2']))==0
    assert all(clean(expr(a)-expr(b))==0 for a,b in zip(A['charge_axes'],B['charge_axes']))
    assert not P.has(s.I,s.Float) and s.Poly(P,D).degree()<=2 and s.Poly(K,D).degree()==2
    assert A['D_degree_bound']==B['D_degree_bound']==2 and B['D5_D6_independent_exact_checks'] and not B['primary_tables_read']
    U=st*tt+st*ut+tt*ut;assert clean(K-3*D*(D-1)*(st+tt+ut)/U)==0
    assert A['SCP_current_anchor_residual']==A['odd_B_coefficient']=='0'
    for pi in permutations(range(3)):
        mapping={**{times[i]:times[pi[i]] for i in range(3)},**{charges[i]:charges[pi[i]] for i in range(3)}}
        assert clean(P.xreplace(mapping)-P)==0
    assert clean(P.xreplace({q:-q for q in charges})-P)==0
    assert clean(P.xreplace({t:2*t for t in times})-2*P)==0 and clean(K.xreplace({t:2*t for t in times})-K/2)==0
    assert clean((P-sum(expr(v)*q*q for v,q in zip(A['charge_axes'],charges))).subs(q3,-q1-q2))==0
    old=expr(packed(CAL/'canonical_so10_scalar_current_sunset/primary_kernel_tables.json.gz')['P2']);assert old!=0
    # Unexpanded finite-heat checks use literal36-pair contractions only.
    fk=s.lambdify([*times,D,*charges],K,modules='mpmath',cse=True);fp=s.lambdify([*times,D,*charges],P,modules='mpmath',cse=True)
    worst=mp.mpf(0);refine=mp.mpf(0);leak=mp.mpf(0);samples=[]
    for row in B['finite_heat_samples']:
        ts=list(map(mp.mpf,row['times']));qs=list(map(mp.mpf,row['charges']));assert sum(qs)==0
        target=[fk(*ts,row['dimension'],*qs),fp(*ts,row['dimension'],*qs)];history=row['histories']
        assert [(h['nodes'],h['denominator']) for h in history]==[(24,1024),(32,1024),(32,2048)]
        for h in history:
            vals=[mp.mpf(h['B0']),mp.mpf(h['B2'])];e=max(abs(v-t)/(1+abs(t)) for v,t in zip(vals,target));worst=max(worst,e);assert e<mp.mpf('1e-40')
            leak=max(leak,mp.mpf(h['imaginary_leak']));assert mp.mpf(h['imaginary_leak'])<mp.mpf('1e-70')
        final=[mp.mpf(history[-1][k]) for k in ['B0','B2']]
        for h in history[:-1]:refine=max(refine,max(abs(mp.mpf(h[k])-v)/(1+abs(v)) for k,v in zip(['B0','B2'],final)))
        samples.append({'dimension':row['dimension'],'times':row['times'],'charges':row['charges'],'B2':mp.nstr(target[1],70)})
    assert refine<mp.mpf('1e-40')
    # Materialized wrong operators, using conserving generic charges.
    stimulus={st:s.S.One,tt:s.Integer(2),ut:s.Integer(3),D:s.Integer(4),q1:s.S.One,q2:s.Integer(2),q3:s.Integer(-3)}
    controls={}
    for n,v in A['controls'].items():
        vv=expr(v);assert vv!=0;value=clean(vv.subs(stimulus));assert value!=0;controls[n]={'actual_P2_change_at_generic_stimulus':str(value)}
    linear=clean(-2*s.diff(P,D).subs(D,4));quadratic=clean(2*s.diff(P,D,2).subs(D,4));assert linear!=0 or quadratic!=0
    controls['early_D4']={'lost_epsilon_linear':str(linear),'lost_epsilon_quadratic':str(quadratic)}
    assert A['VVV_Wick_weight']=='-1/12' and A['Lambda_prefactor']=='g10^2/2' and -12*(-s.Rational(1,12))/2==s.Rational(1,2)
    native=[]
    for role in ['primary','replay']:
        c=json.loads((HERE/f'{role}_capture.json').read_bytes());r=json.loads((HERE/f'{role}_result.json').read_bytes());blob=(HERE/f'{role}_tables.json.gz').read_bytes()
        assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
        assert sha256(blob).hexdigest()==r['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['tables_sha256']
        peak=max(v['private_bytes'] for v in c['all_resource_samples']);assert peak<=8*1024**3 and c['launch']['memory']['available_pagefile']>=350*1024**2 and r['elapsed_after_imports']<600
        native.append({'role':role,'seconds':r['elapsed_after_imports'],'sampled_private_max':peak})
    assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<6*1024**2
    out={'schema':'V3K1_VALIDATION','status':'QUALIFIED_FULL_ORDERED_THREE_VECTOR_GENERAL_D_BARE_F2_HEAT_KERNEL','execution_state':'COMPLETED',
      'Lorentz_routes':['NINE_ORDERED_TRACES_WITH_D_MINUS2_SPECTATORS','LITERAL36_LABELLED_VERTEX_PAIRS_D2_D3_D4_PLUS_D5_D6_CHECKS'],
      'degree_D':2,'charge_axes':A['charge_axes'],'SCP_general_D_current_anchor':'EXACT','six_permutations':'EXACT','positive_time_homogeneity':'EXACT',
      'finite_heat_samples':samples,'max_scaled_Cauchy_error':mp.nstr(worst,40),'max_scaled_Cauchy_refinement':mp.nstr(refine,40),
      'max_Cauchy_imaginary_leak':mp.nstr(leak,40),'controls':controls,'native_runs':native,'Lambda_prefactor':'g10^2/2',
      'bare_positive_mass_Laurent_integrated':False,'proper_forests_qualified':False,'VVV_amplitude_calculated':False,'primitive_amplitude_inventory':6,
      'full_C1_or_E5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED',
      'shared_limits':['action','qualified scalar heat and endpoint covariance','local magnetic-plane reference','software','AI authorship'],
      'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
if __name__=='__main__':main()
