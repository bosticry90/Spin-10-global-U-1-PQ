"""V3K1 literal36-pair contraction and unexpanded finite-heat Cauchy checks."""
from data import *
def mul(A,B):return [sum(A[k]*B[n-k] for k in range(n+1)) for n in range(3)]
def census(dim):
    result={};pis=list(permutations(range(3)))
    for xx in product(range(dim),repeat=3):
        opts=[range(2) if v<2 else [v] for v in xx]
        vx=[(pi[0],xx[pi[1]],parity(pi)) for pi in pis if xx[pi[0]]==xx[pi[2]]]
        if not vx:continue
        for yy in product(*opts):
            vy=[(pi[0],yy[pi[1]],parity(pi)) for pi in pis if yy[pi[0]]==yy[pi[2]]]
            codes=tuple(2*a+b if a<2 else 4 for a,b in zip(xx,yy))
            for i,mu,sgn in vx:
                for j,nu,sgn2 in vy:
                    if mu<2 and nu<2:c=2*mu+nu
                    elif mu==nu:c=4
                    else:continue
                    key=(*codes,i,j,c);result[key]=result.get(key,0)+sgn*sgn2
    return {k:v for k,v in result.items() if v}
def exact_at(dim,terms):
    aa=[1/t for t in times];h=sum(aa);dh=sum(q*q*t for q,t in zip(charges,times))/3
    spin=[]
    for q,t in zip(charges,times):spin.append([[1,0,2*q*q*t*t],[0,2*s.I*q*t,0],[0,-2*s.I*q*t,0],[1,0,2*q*q*t*t],[1,0,0]])
    cov={}
    for i in range(3):
        for j in range(3):
            c0=((aa[i] if i==j else 0)-aa[i]*aa[j]/h)/2
            c1=s.I*((charges[i] if i==j else 0)-(aa[i]*charges[j]+charges[i]*aa[j])/h)/2
            bi,bj=charges[i]**2*times[i]/3,charges[j]**2*times[j]/3
            c2=(bi if i==j else 0)/2-(bi*aa[j]+aa[i]*bj+charges[i]*charges[j])/(2*h)+aa[i]*aa[j]*dh/(2*h*h)
            cov[i,j]=[[c0,0,c2],[0,c1,0],[0,-c1,0],[c0,0,c2],[c0,0,0]]
    total=[0]*3
    for (a,b,c,i,j,k),weight in terms.items():
        value=mul(mul(mul(spin[0][a],spin[1][b]),spin[2][c]),cov[i,j][k]);total=[v+weight*w for v,w in zip(total,value)]
    assert clean(total[1])==0
    orb=-sum(q*q*t*t for q,t in zip(charges,times))/6-dh/h
    return clean(total[0]),clean(total[2]+total[0]*orb)
def finite(B,ts,qs,terms):
    a=[q*B*mp.coth(q*B*t) if q else 1/t for q,t in zip(qs,ts)];hh=sum(1/t for t in ts);H=sum(a);spin=[]
    R=hh/H
    for q,t in zip(qs,ts):
        b=q*B*t;R*=b/mp.sinh(b) if q else 1
        spin.append([mp.cosh(2*b),1j*mp.sinh(2*b),-1j*mp.sinh(2*b),mp.cosh(2*b),mp.mpf(1)])
    cov={}
    for i in range(3):
        for j in range(3):
            c0=((a[i] if i==j else 0)-(a[i]*a[j]+qs[i]*qs[j]*B*B)/H)/2
            c1=1j*B*((qs[i] if i==j else 0)-(a[i]*qs[j]+qs[i]*a[j])/H)/2
            per=((1/ts[i] if i==j else 0)-1/(ts[i]*ts[j]*hh))/2
            cov[i,j]=[c0,c1,-c1,c0,per]
    return R*sum(weight*spin[0][a]*spin[1][b]*spin[2][c]*cov[i,j][k] for (a,b,c,i,j,k),weight in terms.items())
def main():
    start=begin();censuses={n:census(n) for n in range(2,7)};values={n:exact_at(n,censuses[n]) for n in range(2,7)}
    K=s.interpolate([(n,v[0]) for n,v in values.items() if n<=4],D);P=s.interpolate([(n,v[1]) for n,v in values.items() if n<=4],D)
    K,P=clean(K),clean(P);assert s.Poly(K,D).degree()<=2 and s.Poly(P,D).degree()<=2
    for n in [5,6]:assert clean(K.subs(D,n)-values[n][0])==clean(P.subs(D,n)-values[n][1])==0
    mp.mp.dps=100;numeric=[]
    samples=[(['1','2','3'],[1,2,-3],3),(['2','3','5'],[1,-1,0],4),(['3/2','7/3','5/4'],[2,-3,1],6)]
    for ts,qs,dim in samples:
        ts=[mp.mpf(v.split('/')[0])/mp.mpf(v.split('/')[1]) if '/' in v else mp.mpf(v) for v in ts];qs=list(map(mp.mpf,qs));history=[]
        for N,den in [(24,1024),(32,1024),(32,2048)]:
            out=[mp.mpc(0),mp.mpc(0)];rad=mp.mpf(1)/den
            for n in range(N):
                B=rad*mp.exp(2j*mp.pi*n/N);val=finite(B,ts,qs,censuses[dim]);out[0]+=val/N;out[1]+=val/(B*B*N)
            history.append({'nodes':N,'denominator':den,'B0':mp.nstr(out[0].real,85),'B2':mp.nstr(out[1].real,85),
              'imaginary_leak':mp.nstr(max(abs(v.imag) for v in out),50)})
        numeric.append({'times':list(map(lambda v:mp.nstr(v,90),ts)),'charges':list(map(str,qs)),'dimension':dim,'histories':history})
        print('STAGE finite_heat_dimension_'+str(dim),flush=True)
    save('replay',{'schema':'V3K1_REPLAY','K0':str(K),'P2':str(P),'charge_axes':list(map(str,axes(P))),
      'literal_census_term_counts':{str(n):len(v) for n,v in censuses.items()},'D_degree_bound':2,
      'D5_D6_independent_exact_checks':True,'finite_heat_samples':numeric,'primary_tables_read':False},start)
if __name__=='__main__':main()
