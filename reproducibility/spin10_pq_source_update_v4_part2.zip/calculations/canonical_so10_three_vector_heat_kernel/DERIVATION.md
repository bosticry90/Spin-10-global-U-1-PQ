# V3K1: ordered endpoint and Lorentz contraction

Use the actual V3S1 cubic tensor -i g f_abc L, with three equal species but
distinct labelled edge masses, charges and proper times. Write a_i=1/s_i,
h=sum a_i, U=st+su+tu, J=[[0,1],[-1,0]], and dH=sum(q_i^2 s_i)/3.
The inherited scalar heat endpoint derivatives give, after Gaussian relative-
coordinate integration,

    C_ij=delta_ij L_i/2-L_i Hinv R_j^T/2,
    L_i=(a_i+B^2 q_i^2 s_i/3)I+i q_i B J,
    R_i=(a_i+B^2 q_i^2 s_i/3)I-i q_i B J,
    Hinv=(1/h-B^2 dH/h^2)I.

R_j^T=L_j on this magnetic plane; retain the transpose before evaluating it.
Spectator directions have C0_ij=(delta_ij a_i-a_i a_j/h)/2 and no B jets.
The vector spin matrix on edgei is

    E_i=I+2i q_i s_i B J+2q_i^2 s_i^2 B^2 I

in the plane and identity in D-2 spectators. The common scalar determinant/
Gaussian factor is1+B^2 Z2, where

    Z2=-sum(q_i^2 s_i^2)/6-dH/h.

This keeps the actual endpoint contact and right-cotangent signs, not only
derivatives of the translation-invariant exponential. The Schwinger phases
cancel in the product by q1+q2+q3=0. The original29 labelled variations are
therefore included:15 edge,12 edge/vertex,2 vertex/vertex. They have not been
replaced by a flat constant-connection effective potential.

Organize the three Lorentz terms in L by the free field index m. The two
other indices coincide; its derivative current is D_(m+1)-D_(m+2), cyclically.
Let v_m be that signed three-edge vector and
Ccurrent_mn=sum_ij v_mi v_nj C_ij. The full Lorentz contraction is nine terms:

 m=n: Tr(E_m^T Ccurrent_mm) Tr(E_a E_b^T), a,b the other edges;
 m!=n: Tr[(E_m E_k^T E_n)^T Ccurrent_mn], k the third edge.

All traces include their D-2 spectator part. Two closed sums are the maximum,
so the result is polynomial of degree at most2 in D. The literal replay uses
the six derivatives of the cubic density at each end, 36 pairs, with their
Kronecker constraints and all three propagator Lorentz indices. It does not
use the nine-trace identity or its computed coefficients.

The B0 term must be K0=3D(D-1)(s+t+u)/U, matching the actual flat Lorentz
norm after the momentum Gaussian. The full B2 numerator is

    P2=[nine-trace contraction]_B2+K0 Z2.

As a normalization anchor, Tr(E_3^T Ccurrent_33) with its own orbital term
is exactly the previously qualified SCP scalar-current numerator, at general
D and general conserving charges. The full VVV result also needs the other
spin traces and six interference terms; multiplying a scalar kernel by a
vector multiplicity would lose them.

For unexpanded independent controls put
A_i=q_i B coth(q_i B s_i), L_i=A_i I+i q_i B J,
Hinv=(sum A_i)^-1 I, E_i=cosh(2q_i B s_i)I+i sinh(2q_i B s_i)J,
and multiply the literal-index contraction by

    R(B)=product[q_i B s_i/sinh(q_i B s_i)] * h/(sum A_i).

Zero-charge factors are their exact continuous limits. Cauchy extraction at
fixed proper times checks both the spin/connection jets and Gaussian factor
without reading a primary target table. No finite-field stability theorem or
regulator-limit exchange is asserted.

The positive color contraction uses the actual V3S mass/charge tensors. Since
Gamma_VVV=-g^2/12 times that contraction, and Fphys^2=2B^2,
the existing Lambda normalization gives Lambda_VVV/g^2=(1/2)sum W_i U_i.
The kernel must first be decomposed into q1^2,q2^2,q3^2 using charge
conservation. All ordering, dimensional and contact terms stay in the result.
Its eventual Laurent double/single poles and finite master are outputs of
the integral, not values constrained here by a desired restoration theorem.
