"""V3K1 freeze exact action/projector ancestry and all source bytes."""
from pathlib import Path
from hashlib import sha256
import json,ast,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
BASE='0de34cedb9d517880da378b6266c4a285942b932'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/three-vector-heat-kernel-v1-2026-10-21')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='main'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT).strip()
def dump(p,b):
    with p.open('xb') as f:f.write(b)
deps={};cache={};qualified={}
for folder,receipt,want,wantsha in [('canonical_so10_three_vector_support', 'validation_receipt.json', 'QUALIFIED_ACTUAL_THREE_VECTOR_VERTEX_AND_COMPLETE_MASS_CHARGE_SUPPORT', 'd39535044d58a01dcccac5002698b9be13f5e846e25bcb75b261c3338a9915c7'), ('canonical_so10_scalar_current_sunset', 'validation_receipt.json', 'QUALIFIED_ORDERED_VSS_F2_KERNEL_AND_ACTUAL_HEAVY_NORMALIZATION_DERIVATIVE', 'c851b233d9c80ac49991a79f1e0aee6b7c4eca83070ffa94c4f973f4f871f123'), ('canonical_so10_scalar_current_sunset', 'dimensional_receipt.json', 'QUALIFIED_SEPARATE_ORBITAL_EVANESCENT_AND_RADIAL_CONTROLS', '123dbef8f28dfe0f1062d9529ef5a5336cfc9a64847cf4e3808afcaab9626615'), ('canonical_so10_charged_current_kernel', 'validation_receipt_v2.json', 'QUALIFIED_THREE_CHARGE_POSITIVE_MASS_CURRENT_KERNEL_AND_ACTUAL_FORESTS', '19ef4e88094128111c0557455efe880a12479fd4ec253bccf67eb1ef88b29be5')]:
    parent=ROOT/'calculations'/folder
    for prep in sorted(parent.glob('*preparation*.json')):
        for n,h in json.loads(prep.read_bytes())['input_sha256'].items():
            if n not in cache:cache[n]=sha256(Path(n).read_bytes()).hexdigest()
            assert cache[n]==h,n
            if n in deps:assert deps[n]==h,n
            deps[n]=h
    for p in sorted(parent.iterdir()):
        if p.is_file():deps[str(p)]=sha256(p.read_bytes()).hexdigest()
    p=parent/receipt;v=json.loads(p.read_bytes())
    if want:assert v['status']==want
    if wantsha:assert sha256(p.read_bytes()).hexdigest()==wantsha
    qualified[folder+'/'+receipt]=sha256(p.read_bytes()).hexdigest()
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V426.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md']:
    p=ROOT/n;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
    p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw,n
    if p.suffix=='.py':ast.parse(raw,filename=str(p))
    cp=HERE/(n+'.source.txt');dump(cp,raw);deps[str(p)]=deps[str(cp)]=sha256(raw).hexdigest()
state='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
old=subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT);assert len(old.splitlines())==26956
CONTROL.mkdir(parents=True,exist_ok=False);dump(CONTROL/'old_git_tree.txt',old)
v={'schema':'V3K1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(deps.items())),
 'qualified_receipts':qualified,'old_blobs':26956,'seconds_each':600,'sampled_private_cap':8*1024**3,
 'launch_floor':350*1024**2,'whole_package_bytes':6*1024**2,'state_sha256':state,'scientific_acceptance':'NOT_PERFORMED'}
dump(HERE/'preparation.json',(json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
print('FROZEN',len(deps),'bindings;26956oldblobs;no science executed',flush=True)
