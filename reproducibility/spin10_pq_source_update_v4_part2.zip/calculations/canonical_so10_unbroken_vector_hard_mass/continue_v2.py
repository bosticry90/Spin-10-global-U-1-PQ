"""Freeze and validate the one-soft consequence; no native loop rerun."""
from pathlib import Path
from hashlib import sha256
import json,ast,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unbroken-vector-hard-mass-v1-2026-10-21')
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
deps=dict(json.loads((HERE/'validation_preparation.json').read_bytes())['input_sha256'])
for p,h in deps.items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
for name in ['ONE_SOFT_MASS_CLOSURE_V2.md','verify_v2.py','continue_v2.py']:
    p=HERE/name;raw=p.read_bytes();assert b'\r' not in raw
    if p.suffix=='.py':ast.parse(raw,filename=str(p))
    with (HERE/(name+'.source.txt')).open('xb') as f:f.write(raw)
for p in HERE.iterdir():
    if p.is_file():deps[str(p)]=sha256(p.read_bytes()).hexdigest()
dump(HERE/'validation_preparation_v2.json',{'schema':'UHF1_ONE_SOFT_VALIDATION_PREPARATION','input_sha256':deps,'seconds':600,'scientific_acceptance':'NOT_PERFORMED'})
c=capture([sys.executable,'-B',str(HERE/'verify_v2.py')]);dump(HERE/'validation_v2_capture.json',c);dump(CONTROL/'validation_v2_full_capture.json',c)
if c['exit_code']!=0:print(c['stdout_and_stderr'],flush=True)
assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
assert c['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
out=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(out)==1 and out[0]['elapsed_after_imports']<600
assert out[0]['status']=='QUALIFIED_HARD_LIGHT_GAUGE_GHOST_MASS_AND_COMPLETE_ONE_SOFT_MASS_INSERTION_ZERO';dump(HERE/'validation_receipt_v2.json',out[0])
assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<24*1024**2
print('validation_v2 COMPLETED',out[0]['elapsed_after_imports'],flush=True)
