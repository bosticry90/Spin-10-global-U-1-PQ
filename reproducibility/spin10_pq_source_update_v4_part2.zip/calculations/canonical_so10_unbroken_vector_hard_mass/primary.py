from data import *
start=begin();save('primary',calculate('primary'),start)
