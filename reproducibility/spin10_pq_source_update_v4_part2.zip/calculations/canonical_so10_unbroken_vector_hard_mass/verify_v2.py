"""UHF1 actual counterterms and nonzero-dimensional-response closure test."""
from data import *
start=begin('validation_preparation_v2.json')
first=json.loads((HERE/'validation_receipt.json').read_bytes());assert sha256((HERE/'validation_receipt.json').read_bytes()).hexdigest()=='85e684c00bac73abccff0471500bfb85885d3147a90ac5a51b9dce1674137a59'
assert first['gauge_and_scalar_sums_zero_meromorphically'] and first['status']=='QUALIFIED_COMPLETE_POSITIVE_HARD_UNBROKEN_VECTOR_MASS_ZERO_THROUGH_FINITE_ORDER'
V=dec(packed(CAL/'canonical_so10_vector_quartic_ir_matching/primary_tables.json.gz')['light_embedding'])
for role in ['primary','replay']:
    src=packed(CAL/'canonical_so10_quantum_vector_mass_uv'/f'{role}_tables.json.gz')
    for key in ['combined_mass_counterterm','loop_mass_matrix','existing_parameter_mass_jet','reference_Gram_jet','field_normalization_mass_jet']:
        zero(V.T*dec(src[key])*V)
    fci=packed(CAL/'canonical_so10_finite_counterterm_insertion'/f'{role}_v3_tables.json.gz');zero(V.T*dec(fci['vector_delta_mass_matrix'])*V)
    table=packed(HERE/f'{role}_tables.json.gz');D=s.Symbol('D',positive=True);co=[s.sympify(z,locals={'D':D}) for z in table['units']['coefficient_on_A'].values()];assert s.factor(sum(co))==0

# Regenerate all marked background CT words, preserving the complete linear
# operation; an identically zero MASS operator has zero derivatives too.
spec=importlib.util.spec_from_file_location('uhf_osf',CAL/'canonical_so10_one_soft_factorization/factor.py');F=importlib.util.module_from_spec(spec);spec.loader.exec_module(F)
cat=packed(CAL/'canonical_so10_one_soft_factorization/primary_tables.json.gz')['weighted_catalog'];six=F.enc(F.direct_background((('G0S',''),('CT','')),{'K0S':2,'CT':2}));assert six==cat['soft_CT'] and len(six)==6
assert sha256(json.dumps(cat,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='9f38d69eff08521cceca570733a02b6590913d03705aeaccf1a88e3126a5a4bd'

# Nonzero probe tests the response, not the trivial operation on zero.
e,jd,delta,g2=s.symbols('eps jd delta g2',real=True);DD=4-2*e
spin=s.expand((DD-24)/2);assert spin==-(10+e)
rows=[]
for tau,ca in [(0,0),(2,2),(3,3)]:
    response=s.expand(spin*tau*(-delta*g2*ca/e)*(1+e*jd)/delta)
    rows.append({'pole':str(s.expand(response/g2).coeff(e,-1)),'finite_constant':str(s.expand(response/g2).coeff(e,0).subs(jd,0)),'log':str(s.expand(response/g2).coeff(e,0).coeff(jd))})
old=json.loads((CAL/'canonical_so10_light_regulator_spurion/validation_receipt.json').read_bytes());assert rows==old['light_vector_closure_full_and_EFT']
assert [row['finite_constant'] for row in rows]==['0','4','9']
wrongprobe=[s.simplify(t*ca*s.Rational(1,2)) for t,ca in [(0,0),(2,2),(3,3)]];assert any(z!=0 for z in wrongprobe)

table=packed(HERE/'primary_tables.json.gz');weighted=sum((s.sympify(row['lambda'])*dec(row['charge_matrix']) for row in table['color_sectors']),s.zeros(12))
# Half of the actual ordered-ghost loop is omitted: Sigma change=-A/4,
# hence its mass-pole change=+M/4. Light spin-one response detects it in
# both nonabelian ideals. This is never inserted into the real result.
mutant=s.diag(*[red(weighted[i,i]/4) for i in range(12)]);assert mutant.todok()
F2_control=[0,red(-10*2*mutant[1,1]),red(-10*3*mutant[4,4])];assert F2_control[1]!=0 and F2_control[2]!=0
sr=json.loads((CAL/'canonical_so10_soft_region_support_closure/validation_receipt.json').read_bytes());assert sr['hard_linear_delta_light_vector_and_ghost_mass_zero']
controls={'half_ghost_ordinary_mass_pole_on_U1_SU2_SU3':[str(mutant[i,i]) for i in [0,1,4]],
 'half_ghost_vector_closing_pole_per_g4_over_delta':list(map(str,F2_control)),
 'wrong_extra_half_heat_factor_nonzero_probe':list(map(str,wrongprobe)),
 'early_D4_loses_actual_vector_probe_finite':['0','4','9'],'U1_adjoint_F2_closing':'INSENSITIVE_tau0;whole_mass_matrix_tested_separately'}
receipt={'schema':'UHF1_ONE_SOFT_MASS_VALIDATION','status':'QUALIFIED_HARD_LIGHT_GAUGE_GHOST_MASS_AND_COMPLETE_ONE_SOFT_MASS_INSERTION_ZERO',
 'execution_state':'COMPLETED','scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED',
 'first_receipt_sha256':sha256((HERE/'validation_receipt.json').read_bytes()).hexdigest(),'first_receipt_disposition':'RETAINED_AND_EXTENDED_WITH_ONE_SOFT_MASS_OPERATION',
 'native_calculations_rerun':False,'original_mass_counterterm_and_reference_field_parts_light12x12_zero':True,
 'six_OSF_words_regenerated':6,'vector_mass_response':'-(10+epsilon)*tau_ad*H_e(delta)*m/delta',
 'vector_probe_pole_log':['0','40','90'],'vector_probe_evanescent_finite':['0','4','9'],
 'ordinary_one_soft_gauge_ghost_mass_insertion':'ZERO_BEFORE_EPSILON_AND_IR_LIMITS',
 'tadpole_leaf_for_two_light_vectors':'ZERO_FROM_O_H0;NO_FINITE_TADPOLE_CONDITION_ASSIGNED',
 'negative_controls':controls,'kinetic_curvature_full_common_boundary_C1_E5_A5_or_physical_pole_mass_qualified':False,
 'shared_error_limits':first['shared_error_limits'],'elapsed_after_imports':time.perf_counter()-start}
print('RESULT '+json.dumps(receipt,sort_keys=True),flush=True)
