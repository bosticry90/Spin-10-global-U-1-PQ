"""UHF1 immutable exact domains, completed ancestry and source freeze."""
from pathlib import Path
from hashlib import sha256
import json,ast,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
BASE='d27d642c9704e45941472bdf3db1e4b04d0c1c65'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unbroken-vector-hard-mass-v1-2026-10-21')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='main'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT).strip()
def dump(p,b):
    with p.open('xb') as f:f.write(b)
deps={};cache={};qualified={}
parents=[
 ('canonical_so10_soft_region_support_closure','validation_receipt.json','QUALIFIED_COMPLETE_LIGHT_HARD_DELTA_SUPPORT_AND_TWO_SOFT_FAMILY_CENSUS','9aad60eadad67bf8c7fe807f7f8d38eb082c3aa1efc3df302e0ed55bab1eaccb'),
 ('canonical_so10_unbroken_vector_mass_uv','validation_receipt.json','QUALIFIED_COMPLETE_FIXED_REFERENCE_UNBROKEN_VECTOR_LOG_MASS_POLE_ZERO','e571242000c0aecb465be4639d6939f0bfdbac7fb5b21961cb2a3da1607c2f95'),
 ('canonical_so10_quantum_vector_mass_uv','validation_receipt.json','QUALIFIED_FULL_VECTOR_MASS_UV_POLE_AND_EXACT_FIELD_NORMALIZATION_RECONCILIATION','fedbac91e74fbe319bc6960add48a3cc0f2349670abba45746e3c0cee758a15a')]
for folder,receipt,want,wantsha in parents:
    P=ROOT/'calculations'/folder;assert {p.name for p in P.glob('*preparation*.json')}=={'preparation.json','validation_preparation.json'}
    for name in ['preparation.json','validation_preparation.json']:
        record=json.loads((P/name).read_bytes());bindings=record.get('input_sha256',record.get('byte_sha256'));assert isinstance(bindings,dict) and bindings
        for n,h in bindings.items():
            n=str((ROOT/Path(n)).resolve())
            if n not in cache:cache[n]=sha256(Path(n).read_bytes()).hexdigest()
            assert cache[n]==h,n
            if n in deps:assert deps[n]==h,n
            deps[n]=h
    for p in P.iterdir():
        if p.is_file():deps[str(p)]=sha256(p.read_bytes()).hexdigest()
    p=P/receipt;v=json.loads(p.read_bytes());assert v['status']==want and sha256(p.read_bytes()).hexdigest()==wantsha
    qualified[folder+'/'+receipt]=wantsha
for name in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V439.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md']:
    p=ROOT/name;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for name in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
    p=HERE/name;raw=p.read_bytes();assert b'\r' not in raw
    if p.suffix=='.py':ast.parse(raw,filename=str(p))
    cp=HERE/(name+'.source.txt');dump(cp,raw);deps[str(p)]=deps[str(cp)]=sha256(raw).hexdigest()
state='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
old=subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT);assert len(old.splitlines())==28021
CONTROL.mkdir(parents=True,exist_ok=False);dump(CONTROL/'old_git_tree.txt',old)
v={'schema':'UHF1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(deps.items())),'qualified_receipts':qualified,'old_blobs':28021,'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'whole_package_bytes':24*1024**2,'state_sha256':state,'scientific_acceptance':'NOT_PERFORMED'}
dump(HERE/'preparation.json',(json.dumps(v,sort_keys=True,indent=2)+'\n').encode());print('FROZEN',len(deps),'bindings;28021 oldblobs;no science executed',flush=True)
