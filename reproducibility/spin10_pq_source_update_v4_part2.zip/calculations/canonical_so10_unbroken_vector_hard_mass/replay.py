from data import *
start=begin();save('replay',calculate('replay'),start)
