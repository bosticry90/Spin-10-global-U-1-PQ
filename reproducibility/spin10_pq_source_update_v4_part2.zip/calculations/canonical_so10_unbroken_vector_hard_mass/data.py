"""UHF1 finite dimensional units and full positive-sector charge matrices."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,gzip,sys,time,os,threading,importlib.util
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_finite_counterterm_insertion'))
from geometry_v2 import red,tidy,zero,dec,enc,w
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def begin(prep='preparation.json'):
    start=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for p,h in json.loads((HERE/prep).read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
    return start
def save(role,v,start):
    raw=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/f'{role}_tables.json.gz').open('xb') as f:f.write(blob)
    print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':time.perf_counter()-start,'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)
def q(v):
    a,sep,b=str(v).partition('/');return mp.mpf(a)/mp.mpf(b) if sep else mp.mpf(a)
def fmt(v):return mp.nstr(mp.re(v),70)

def colors(role):
    src=packed(CAL/'canonical_so10_background_threshold_inputs'/f'{role}_tables.json.gz');G=s.SparseMatrix(45,45,{(i,j):s.sympify(z) for i,j,z in src['Gram']});O=s.SparseMatrix(328,45,{(i,j):s.sympify(z) for i,j,z in src['orbit']})
    V=dec(packed(CAL/'canonical_so10_vector_quartic_ir_matching'/f'{role}_tables.json.gz')['light_embedding']);Ps=list(map(dec,packed(CAL/'canonical_so10_width_hard_projection'/f'{role}_tables.json.gz')['projectors']))
    zero(O.T*O-G);zero(O*V);zero(V.T*V-s.eye(12));zero(Ps[0]-V*V.T)
    lam=[0,s.Rational(3,10),s.Rational(3,2),25,s.Rational(253,10)]
    if role=='primary':
        f={(a,b,c):s.sympify(z) for a,b,c,z in src['f']};adj=[s.SparseMatrix(45,45,{(c,b):z for (a,b,c),z in f.items() if a==i}) for i in range(45)]
        T=[tidy(sum((V[a,h]*adj[a] for a in range(45)),s.zeros(45))) for h in range(12)]
    else:
        pairs=list(combinations(range(10),2));planes=[s.SparseMatrix(10,10,{(i,j):1/s.sqrt(2),(j,i):-1/s.sqrt(2)}) for i,j in pairs];T=[]
        for h in range(12):
            gen=tidy(sum((V[a,h]*planes[a] for a in range(45)),s.zeros(10)));columns=[]
            for B in planes:
                comm=tidy(gen*B-B*gen);columns.append(s.Matrix([s.sqrt(2)*comm[i,j] for i,j in pairs]))
            T.append(tidy(s.SparseMatrix.hstack(*columns)))
    for A in T:zero(A+A.T);zero(A*G-G*A)
    out=[]
    for r,P in enumerate(Ps):
        zero(G*P-lam[r]*P);zero(P*P-P)
        for A in T:zero(A*P-P*A)
        if r==0:continue
        if role=='primary':C=s.Matrix(12,12,lambda h,k:red(-s.trace(P*T[h]*T[k])))
        else:
            projected=[tidy(P*A).todok() for A in T];C=s.Matrix(12,12,lambda h,k:red(sum(z*projected[k].get(ij,0) for ij,z in projected[h].items())))
        zero(C-C.T);zero(C-s.diag(C[0,0],*([C[1,1]]*3),*([C[4,4]]*8)))
        # Same Goldstone charge matrix, using the independently inherited
        # actual rho_H O=O ad_H intertwiner and the explicit orbit Gram.
        gold=s.Matrix(12,12,lambda h,k:red(-s.trace(P*T[h]*G*T[k])/lam[r]));zero(gold-C)
        out.append({'r':r,'lambda':str(lam[r]),'rank':int(s.trace(P)),'charge_matrix':enc(C),'Goldstone_charge_matrix':enc(gold),'probe_charges':[str(C[i,i]) for i in [0,1,4]]})
    old=packed(CAL/'canonical_so10_unbroken_vector_mass_uv'/f'{role}_tables.json.gz')['geometry'];assert old['H_Goldstone_kernel_and_all12_intertwiners_checked']
    W=sum((s.sympify(row['lambda'])*dec(row['charge_matrix'])/60 for row in out),s.zeros(12));zero(W-dec(old['W_matrix']))
    return out

def units(role):
    D=s.Symbol('D',positive=True);A,B,J,M=s.symbols('A B J M',positive=True);e,j=s.symbols('eps j',real=True)
    if role=='primary':
        p,a,b,m=s.symbols('p a b m',real=True);pp=s.Matrix([p,0]);kk=s.Matrix([p+a,b]);kap=kk-pp;t=(kk.T*kk)[0]+m*m;c=(pp.T*kk)[0]+m*m
        left=s.symbols('ubar0 ubar1 etabar');right=s.symbols('u0 u1 eta');ub=s.Matrix(left[:2]);u=s.Matrix(right[:2]);eb=left[2];eta=right[2]
        density=sum((kk[h]*ub[k]-kk[k]*ub[h])*(kk[h]*u[k]-kk[k]*u[h]) for h in range(2) for k in range(2))/2
        density+=sum((-s.I*kk[h]*eb+m*ub[h])*(s.I*kk[h]*eta+m*u[h]) for h in range(2))
        density+=(-s.I*(pp.T*ub)[0]+m*eb)*(s.I*(pp.T*u)[0]+m*eta)
        K=s.Matrix(3,3,lambda h,k:s.diff(density,left[h],right[k]));assert s.factor(K.det()-t*c*c)==0
        K1=2*(pp.T*kap)[0]*s.eye(2)-pp*kap.T-kap*pp.T;K2=(kap.T*kap)[0]*s.eye(2)-kap*kap.T
        tr1=s.expand(s.trace(K1*K1)+(D-2)*4*(pp.T*kap)[0]**2);tr2=s.expand(s.trace(K2)+(D-2)*(kap.T*kap)[0])
        assert s.expand(tr1-((4*D-6)*p*p*a*a+2*p*p*(a*a+b*b)))==0
        assert s.expand(tr2-(D-1)*(a*a+b*b))==0
        angular=s.simplify(tr1.subs({a*a:s.Symbol('q2')/D,b*b:(D-1)*s.Symbol('q2')/D})/(p*p*s.Symbol('q2')))
        cubic=-angular*J/2
    else:
        P2,Q2,PQ=s.symbols('p2 q2 pq');dot=lambda u,v:P2 if u==v=='p' else Q2 if u==v=='q' else PQ
        terms=[(2*PQ,None),(-1,('p','q')),(-1,('q','p'))];num=0
        for c,u in terms:
            for d,v in terms:
                tr=D if u is None and v is None else dot(*v) if u is None else dot(*u) if v is None else dot(u[1],v[0])*dot(v[1],u[0])
                num+=c*d*tr
        angular=s.factor(s.expand(num).subs(PQ**2,P2*Q2/D)/(P2*Q2));assert s.simplify(angular-6*(1-1/D))==0
        cubic=-angular*J/2
    raw={'vector_quartic':(D-1)*A,'vector_cubic':cubic,'ghost':J/D,'mixed_VS':-M*B,'scalar_seagull':A,'scalar_bubble':-2*J/D}
    reduced={name:s.factor(z.subs({J:D*A/2,B:(1-D/2)*A/M})/A) for name,z in raw.items()}
    assert s.factor(sum(reduced.values()))==0
    assert s.factor(sum(z for n,z in reduced.items() if not n.startswith('scalar')))==0
    # MSbar normalized A_gamma. Finite extraction keeps the D factors.
    At=-M*(1/e+1+j);jets={}
    for name,co in reduced.items():
        z=s.series(co.subs(D,4-2*e)*At,e,0,1).removeO().expand();jets[name]={'pole_over_M':str(s.factor(z.coeff(e,-1)/M)),'finite_over_M':str(s.factor(z.coeff(e,0)/M))}
    return {'raw_Sigma':{n:str(s.factor(z)) for n,z in raw.items()},'coefficient_on_A':{n:str(z) for n,z in reduced.items()},'jets':jets,
      'gauge_total_meromorphic':'0','scalar_total_meromorphic':'0','Gamma_density_factor_Sigma':2}

def calculate(role):
    c=colors(role);print('STAGE '+role+'_all576_positive_sector_charge_positions',flush=True);u=units(role)
    return {'schema':'UHF1_POSITIVE_HARD_UNBROKEN_MASS','color_sectors':c,'units':u,
      'local_hard_mass_12x12_zero':True,'positive_gap_Taylor_then_meromorphic_continuation':True,
      'light_internal_modes':'RETAINED_SOFT; NO_FICTITIOUS_LIGHT_GOLDSTONE','finite_kinetic_C1_or_E5_qualified':False}
