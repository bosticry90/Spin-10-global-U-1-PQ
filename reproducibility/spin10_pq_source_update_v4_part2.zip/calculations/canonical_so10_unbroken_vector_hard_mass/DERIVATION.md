# UHF1 positive-gap hard Taylor domain and finite terms

UVM's actual geometry supplies O V=0, rho_H v=0, rho_H O=O ad_H,
[ad_H,G]=0,[rho_H,H]=0,HO=0 and G=O^T O. Thus scalar reference
X=H+g²OO^T commutes with H charges, and every positive vector mass
sector is intertwined with a Goldstone sector of the SAME squared mass.
No such commuting assumption is made for broken external generators.

SRC excludes all mixed-heavy/light bubbles for external H quantum vectors.
Light-only tadpoles and bubbles remain soft. The hard Taylor coefficient
therefore has only positive-heavy propagators. In0<ReD<2, its mass terms
and a finite neighbourhood of external momentum0 are bounded by convergent
radial integrands with the positive minimum heavy mass. Differentiation
under the integral is legitimate in that strip, and the computed coefficient
defines its dimensional meromorphic continuation. This does not shift an
undefined infinite TraceLog or infer a physical on-shell mass from p_ext0.

On one real charged gauge eigenmode let M=m²>0 and momentum shift
k=p+kappa. The actual bilinear densities give
 Kv=(k²+M)I-kk^T+pp^T, Ks=k²+M,
 Kvs=i m(k-p), Ksv=-i m(k-p)^T, Kc=p.k+M.
The coupled two-plane3x3 determinant is (k²+M)(p.k+M)². Spectator
directions supply (k²+M)^(D-2). Ordered ghosts remove the two FP factors.
This algebra fixes the mixed term sign independently of its cancellation.

For A=int1/(p²+M), B=int1/(p²+M)², J=int p²/(p²+M)²,
radial integration in the common strip gives J=D A/2, M B=(1-D/2)A.
In stripped MSbar units, A=exp(gamma_E e)(Q²)^e M^(1-e)Gamma(e-1),
B=exp(gamma_E e)(Q²/M)^e Gamma(e). With Sigma=2*Gamma_q², the raw terms are

| Diagram | Sigma/(g² charge²) |
| --- | --- |
| vector quartic | (D-1)A |
| vector cubic | -3(1-1/D)J |
| ordered ghost | J/D |
| mixed vector/Goldstone | -M B |
| minimal scalar seagull | A |
| minimal scalar bubble | -2J/D |

The cubic numerator is fixed by the actual derivative vertex:
Tr K1²=(4D-6)(p.kappa)²+2p²kappa². Its angular moment is1/D.
Scalar terms cancel for EACH positive eigenvalue by actual H-commutation.
The gauge four-term sum also vanishes identically after radial IBP.
The determinant route and the direct Wick route do not set an unknown
counterterm to the necessary value; the loop sum vanishes before subtraction.

Write j=log(Q²/M). Pole and finite Sigma/M coefficients are

| Diagram | pole | finite |
| --- | ---: | --- |
| vector quartic | -3 | -1-3j |
| vector cubic | 9/2 | 3/2+9j/2 |
| ghost | -1/2 | -(1+j)/2 |
| mixed | -1 | -j |
| scalar seagull | -1 | -1-j |
| scalar bubble | 1 | 1+j |

These coefficients retain the dimensional finite terms from D=4-2e.
Freezing Lorentz D4 BEFORE radial integration instead leaves e*A in the
gauge sum and e*A/2 in a minimal scalar sum, finite errors -M and-M/2.
By contrast freezing every coefficient only AFTER reducing to A can leave
the total zero accidentally: component finite terms remain wrong. Both
controls and this insensitivity must be recorded.

The model sector matrices are C_r,hk=-Tr[Pr ad_h ad_k], h,k=1..12.
Construct all576 entries for the four positive sectors; actual H covariance
allows diag(CY,C2 I3,C3 I8), which is checked, not assumed from traces.
Projected Frobenius Gram and fundamental10 commutators supply the second
route. The Goldstone charge matrix is the same C_r by O^T O=G and
rho_H O=O ad_H. Neutralr2 is retained with its zero adjoint charge matrix.
Polarization then gives the entire light12x12 zero mass block, including
off-diagonal complements, for arbitrary g²>0 and Q²>0 within this reference.

No general finite cancellation follows from a scalar UV zero. For two
unequal scalar squared masses x,y and a noncommuting charge, the Gamma_q²
finite coefficient is (x+y)/4-xy log(x/y)/(2(x-y)), nonzero for(1,4).
Actual H commutators are the premise permitting the stronger conclusion.

An external light antighost has an explicit momentum derivative in FPvector;
FPscalar has zero light-antighost row. The positive-hard kernels are analytic
at p_ext0, so no inverse external momentum can undo that zero. This removes
a hard ghost MASS contribution, not its kinetic/field matching.
The resulting zero mass insertion eliminates no ordinary finite p²/curvature
operator and authorizes no standalone field counterterm in C1.
