"""UHF1 finite master extraction, convergent strip and full charged matrices."""
from data import *
start=begin('validation_preparation.json');mp.mp.dps=100
a=packed(HERE/'primary_tables.json.gz');b=packed(HERE/'replay_tables.json.gz')
D=s.Symbol('D',positive=True);A,B,J,M=s.symbols('A B J M',positive=True);eps,j=s.symbols('eps j',real=True);loc={'D':D,'A':A,'B':B,'J':J,'M':M,'eps':eps,'j':j}
parse=lambda v:s.sympify(v,locals=loc)
for key in ['raw_Sigma','coefficient_on_A']:
    for name,z in a['units'][key].items():assert s.factor(parse(z)-parse(b['units'][key][name]))==0,(key,name)
assert a['units']['jets']==b['units']['jets']
for x,y in zip(a['color_sectors'],b['color_sectors']):
    assert x['r']==y['r'] and x['lambda']==y['lambda'] and x['rank']==y['rank']
    for key in ['charge_matrix','Goldstone_charge_matrix']:zero(dec(x[key])-dec(y[key]))
assert [v['rank'] for v in a['color_sectors']]==[8,1,12,12]
assert a['color_sectors'][1]['probe_charges']==['0','0','0']
uvm=packed(CAL/'canonical_so10_unbroken_vector_mass_uv/primary_tables.json.gz')['geometry']
for h in range(3):assert [row['probe_charges'][h] for row in a['color_sectors']]==uvm['charge_squared_by_mass'][h][1:]
for row in a['color_sectors']:assert row['charge_matrix']['shape']==[12,12] and row['Goldstone_charge_matrix']['shape']==[12,12]
for name,co in a['units']['coefficient_on_A'].items():
    old=packed(CAL/'canonical_so10_unbroken_vector_mass_uv/primary_tables.json.gz')['kernels']['mass_pole_coefficients'][name]
    assert s.simplify(parse(a['units']['jets'][name]['pole_over_M'])-s.sympify(old))==0

# Direct Gamma values on complex circles independently measure every
# individual pole and finite coefficient, at nonzero heavy squared masses.
contourerr=mp.mpf(0);refine=mp.mpf(0);history=[]
def cauchy(fun,n,r):
    vals=[]
    for k in range(n):
        z=r*mp.exp(2j*mp.pi*k/n);vals.append((z,fun(z)))
    return [mp.fsum(z*v for z,v in vals)/n,mp.fsum(v for z,v in vals)/n]
for MM in [q('3/10'),q('3/2'),q('25'),q('253/10')]:
    for jj in [mp.mpf(0),q('2/7')]:
        for name,co in a['units']['coefficient_on_A'].items():
            fun=s.lambdify(eps,parse(co).subs(D,4-2*eps),modules='mpmath')
            gamma=lambda ep:MM*mp.exp(mp.euler*ep+ep*jj)*mp.gamma(ep-1)
            lo=cauchy(lambda ep:fun(ep)*gamma(ep),64,q('1/32'));hi=cauchy(lambda ep:fun(ep)*gamma(ep),96,q('1/64'))
            want=[MM*q(a['units']['jets'][name]['pole_over_M']),MM*mp.mpf(str(s.N(parse(a['units']['jets'][name]['finite_over_M']).subs(j,s.Float(str(jj),100)),100)))]
            ee=max(abs(x-y)/(1+abs(y)) for x,y in zip(hi,want));rr=max(abs(x-y)/(1+abs(y)) for x,y in zip(lo,hi));contourerr=max(contourerr,ee);refine=max(refine,rr)
            history.append({'M':fmt(MM),'j':fmt(jj),'family':name,'pole':fmt(hi[0]),'finite':fmt(hi[1]),'max_scaled_error':fmt(ee)})
assert contourerr<mp.mpf('1e-45') and refine<mp.mpf('1e-45'),(fmt(contourerr),fmt(refine))

# Positive-mass Euclidean integrals in a common genuine convergence strip.
radialerr=mp.mpf(0);radial=[]
for dd in [q('3/4'),q('5/4')]:
    for MM in [q('3/10'),q('253/10')]:
        aa=mp.quad(lambda p:p**(dd-1)/(p*p+MM),[0,1,mp.inf]);bb=mp.quad(lambda p:p**(dd-1)/(p*p+MM)**2,[0,1,mp.inf]);jj=mp.quad(lambda p:p**(dd+1)/(p*p+MM)**2,[0,1,mp.inf])
        total=(dd-1)*aa-3*(1-1/dd)*jj+jj/dd-MM*bb+aa-2*jj/dd
        ee=max(abs(jj-dd*aa/2),abs(MM*bb-(1-dd/2)*aa),abs(total))/(1+abs(aa));radialerr=max(radialerr,ee)
        radial.append({'D':fmt(dd),'M':fmt(MM),'max_scaled_residual':fmt(ee)})
assert radialerr<mp.mpf('1e-40'),fmt(radialerr)

# Early-D4 at the LORENTZ stage is distinct from a coincidentally harmless
# total-zero shortcut after every radial identity has been applied.
raw={n:parse(z) for n,z in a['units']['raw_Sigma'].items()};gauge=sum(z for n,z in raw.items() if not n.startswith('scalar'));scalar=raw['scalar_seagull']+raw['scalar_bubble']
early=s.factor(gauge.subs(D,4).subs({J:D*A/2,B:(1-D/2)*A/M}));assert s.factor(early-(2-D/2)*A)==0
earlyscalar=s.factor(scalar.subs(D,4).subs(J,D*A/2));assert s.factor(earlyscalar-(1-D/4)*A)==0
assert s.limit(early.subs({D:4-2*eps,A:-M/eps}),eps,0)==-M
assert s.limit(earlyscalar.subs({D:4-2*eps,A:-M/eps}),eps,0)==-M/2
co={n:parse(z) for n,z in a['units']['coefficient_on_A'].items()};assert sum(co.values())==0 and sum(z.subs(D,4) for z in co.values())==0
assert co['mixed_VS']!=0 and s.factor(-2*co['mixed_VS'])!=0 and co['ghost']!=0

# Actual warning diagnostic: unequal commuting masses are not permitted
# by the stronger H-invariant claim. This noncommuting control is nonzero.
xx,yy=s.symbols('x y',positive=True);Ae=lambda x:-x*(1/eps+1-s.log(x))
Ixy=(xx*Ae(xx)-yy*Ae(yy))/(xx-yy);probe=Ae(xx)/2+Ae(yy)/2-2*Ixy/(4-2*eps)
finite=s.simplify(s.series(probe,eps,0,1).removeO());want=(xx+yy)/4-xx*yy*s.log(xx/yy)/(2*(xx-yy));assert s.simplify(s.expand_log(finite-want,force=True))==0
diagnostic=mp.mpf(str(s.N(want.subs({xx:1,yy:4}),95)));assert diagnostic>mp.mpf('.3')
def diag_gamma(ep):
    ax=mp.exp(mp.euler*ep)*mp.gamma(ep-1);ay=4**(1-ep)*mp.exp(mp.euler*ep)*mp.gamma(ep-1);ii=(ax-4*ay)/(1-4)
    return ax/2+ay/2-2*ii/(4-2*ep)
dg=cauchy(diag_gamma,96,q('1/64'));assert abs(dg[0])<mp.mpf('1e-45') and abs(dg[1]-diagnostic)<mp.mpf('1e-45')
src=json.loads((CAL/'canonical_so10_soft_region_support_closure/validation_receipt.json').read_bytes());assert src['hard_linear_delta_light_vector_and_ghost_mass_zero']
controls={'early_D4_gauge_finite_per_charged_mode':'-M','early_D4_scalar_finite_per_charged_mode':'-M/2',
 'one_wrong_mixed_phase_changes_coefficient_on_A':str(s.factor(-2*co['mixed_VS'])),'half_ghost_changes_coefficient_on_A':str(-co['ghost']/2),
 'broken_noncommuting_scalar_zero_pole_nonzero_finite':fmt(diagnostic),
 'simultaneous_mixed_phase_flip':'INSENSITIVE_BASIS_CHANGE','early_D4_after_ALL_IBP_total':'INSENSITIVE_TOTAL_COMPONENT_FINITES_WRONG'}
receipt={'schema':'UHF1_VALIDATION','status':'QUALIFIED_COMPLETE_POSITIVE_HARD_UNBROKEN_VECTOR_MASS_ZERO_THROUGH_FINITE_ORDER',
 'execution_state':'COMPLETED','scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED',
 'complete_light_mass_matrix_shape':[12,12],'positive_vector_mass_sectors':4,'sector_coefficient_positions':576,
 'sector_probe_charge_squared':[{k:row[k] for k in ['r','lambda','rank','probe_charges']} for row in a['color_sectors']],
 'unit_poles_and_finite':a['units']['jets'],'gauge_and_scalar_sums_zero_meromorphically':True,
 'positive_gap_hard_Taylor_domain':'0<ReD<2_then_dimensional_meromorphic_continuation',
 'gamma_Cauchy_max_scaled_error':fmt(contourerr),'gamma_Cauchy_refinement_max_scaled':fmt(refine),'finite_unit_samples':history,
 'positive_radial_max_scaled_error':fmt(radialerr),'positive_radial_checks':radial,
 'hard_light_ghost_mass':'ZERO_AT_EXTERNAL_ANTIGHOST_MOMENTUM0_WITH_HARD_ANALYTICITY',
 'light_internal_modes':'RETAINED_SOFT_NOT_DISCARDED','negative_controls':controls,
 'ordinary_hard_kinetic_curvature_or_C1_E5_A5_or_physical_pole_mass_qualified':False,
 'shared_error_limits':['action/point/source/reference/commuting_H_positive_spectrum/UV/region premises','symbolic_numeric_software','AI authorship'],
 'elapsed_after_imports':time.perf_counter()-start}
print('RESULT '+json.dumps(receipt,sort_keys=True),flush=True)
