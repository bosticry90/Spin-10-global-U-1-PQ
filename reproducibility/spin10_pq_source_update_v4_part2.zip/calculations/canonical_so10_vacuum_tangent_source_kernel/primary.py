"""VTS1 actual raw source/ghost/primitive contraction and ordered cumulant."""
from data import *
from functools import lru_cache
start=begin('primary')
@lru_cache(None)
def coeff(z):return s.sympify(z)
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
def perm(word):return (-1)**sum(word[i]>word[j] for i in range(len(word)) for j in range(i+1,len(word)))
# Canonical odd order J,h,C,a. The second cumulant is -1/2 of two even
# vertex orderings; both signs are computed, not assigned from restoration.
signs=[perm(w) for w in [[0,2,1,3],[1,3,0,2]]];gaussian=-s.Rational(1,2)*sum(signs)
JM,JE,h,a,z,R=s.symbols('JM JE h a z R');source=s.expand((-JM*R).subs(JM,-JE));tangent=s.expand(-h*(-g*xi*a*z));assert source==JE*R
assert s.diff(tangent,h,a,z)==g*xi
e1=read(PK/'frozen_a10_e1_fermion/primary.json');FM=dec(e1['charts']['blocks']['heavy_dual']['field_embedding']);phys=read(PK/'frozen_a10_physical_reconciliation/full_primary.json');Q=dec(phys['C3_plane_to_parent']);v=dec(phys['vacuum']['VEV'])
ref=read(PK/'frozen_a10_e5_full_hessian/primary.json')['retained_reference'];fi={n:i for i,n in enumerate(ref['field_order'])};green=dec(ref['reference_Green_raw_C3']);pm=s.symbols('p0_ref0:4');P=pm[0]**2-sum(x*x for x in pm[1:]);anti=[f'bar{a}' if a<12 else f'ub{a}' for a in range(45)]
CG=s.SparseMatrix(45,45,{(c,a):s.simplify(P*green[fi[f'C{c}'],fi[anti[a]]]) for c in range(45) for a in range(45) if green[fi[f'C{c}'],fi[anti[a]]]!=0});assert not any(z.free_symbols for z in CG.todok().values())
portable=packed(ROOT/'tools/portable_dh_v1/inputs.json.gz');maps=portable['master_field_maps'];blocks=[];badblocks=[];primitive=[];position_count=0;off=0
for sec,n in SECTORS:
 rho=list(map(dec,phys['representation_matrices'][sec]));raw=[s.SparseMatrix(n,n,{}) for _ in range(45)]
 for i in range(n):
  for row in maps[f'x_{sec}_{i}']:
   assert len(row['word'])==2 and '__' not in ''.join(row['word']);cn=next(w for w in row['word'] if w.startswith('C'));xn=next(w for w in row['word'] if w.startswith('x_'));assert xn.startswith(f'x_{sec}_')
   c=int(cn[1:]);j=int(xn[len(f'x_{sec}_'):]);co=s.expand(coeff(row['coefficient']));unit=co.coeff(g);assert s.expand(co-g*unit)==0
   raw[c][i,j]-=unit;position_count+=1
 for c in range(45):zero(raw[c]-sum((Q[b,c]*rho[b] for b in range(45) if Q[b,c]),s.SparseMatrix(n,n,{})))
 T=[tidy(sum((FM[b,a]*rho[b] for b in range(45) if FM[b,a]),s.SparseMatrix(n,n,{}))) for a in range(33)]
 wrong=[tidy(sum((Q[b,12+a]*rho[b] for b in range(45) if Q[b,12+a]),s.SparseMatrix(n,n,{}))) for a in range(33)]
 for t in T:zero(t+t.T)
 K=s.SparseMatrix(n,n,{});bad=s.SparseMatrix(n,n,{})
 for (c,a),co in CG.todok().items():
  if a<12:continue
  K-=gaussian*co*raw[c]*T[a-12];bad-=gaussian*co*raw[c]*wrong[a-12]
 blocks.append(tidy(K));badblocks.append(tidy(bad));primitive.append(s.SparseMatrix.vstack(*[(t*v[off:off+n,0]).T for t in T]));off+=n
# Authenticate the tangent extension's base point against every old orbit
# coefficient, including its zero complement. The extension is still new.
atv=s.SparseMatrix.hstack(*primitive);actual=s.SparseMatrix(33,328,{});names={f'x_{sec}_{i}':k for k,(sec,i) in enumerate((sec,i) for sec,n in SECTORS for i in range(n))}
for row in e1['polynomial_parts']['heavy_orbit']:
 an=next(n for n in row['word'] if n.startswith('ub'));sn=next(n for n in row['word'] if n.startswith('x_'));co=coeff(row['coefficient']);assert s.expand(co+g*xi*(-co/(g*xi)))==0
 actual[int(an[2:])-12,names[sn]]+=s.simplify(-co/(g*xi))
zero(atv-actual)
x=s.Symbol('feynman_x');res=s.integrate(1,(x,0,1));assert res==1
finish('primary',{'method':'actual_raw_scalar_source_Green_dual_primitive_and_ordered_second_cumulant','kernel_unit':enc(s.diag(*blocks)),'wrong_primal_primitive_kernel':enc(s.diag(*badblocks)),'raw_ghost_Green_unit':enc(CG),'primitive_orbit_at_v':enc(atv),'ordered_Wick_permutation_signs':signs,'second_cumulant_unit':str(gaussian),'bubble_residue':str(res),'source_J_Wick_phase':'-1','primitive_Wick_phase':'-1','tangent_E_vertex_phase_relative_positive_gxi':'1','scalar_source_coefficients_checked':position_count,'primitive_original_orbit_rows':len(e1['polynomial_parts']['heavy_orbit']),'new_one_loop_source_pole_families':1,'new_two_loop_integrals':0,'external_source_extension':'PROVISIONAL_EXPLICIT_NOT_ADOPTED'},start)
