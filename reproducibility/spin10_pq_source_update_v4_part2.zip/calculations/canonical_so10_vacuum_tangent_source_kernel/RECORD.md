# VTS1: provisional vacuum-tangent source extension and full scalar kernel

Base2b8c6500a8bc76540b5f60aa64c5b25f281bb14b/main,30501 tracked blobs.
Question: does a precisely defined tangent extension of the actual GF
primitive generate the extra VEV image required by FMU1? Compute its full
328-coordinate source kernel before projecting onto the mass direction.
This is an explicitly provisional external-source construction, not recovery
or adoption of a uniquely prescribed historical quantum scheme.

Freeze live AGENTS/charter/state113/34of39,V493/local/solo conventions;
actual E1 gauge fermion and charts/receipts, E2 scalar/source columns and
receipt, original BV scalar source polynomial, portable master maps, full
643 reference Green/chart, primary/replay physical rho/vacuum, GYV scalar
Casimirs, YCT matched maps, ASM interface and FMU mass result. Preserve all
old policy, failed sources/runs, physical inputs/exclusions and authority.

New formal domain: external even z_A of dimension1/ghost0 and odd h_A of
dimension2/ghost1, A=1..328, with qz=h,qh=0. These are not integrated fields
or physical particles. Define v(z)=v0+z, O_a(z)=rho_a(v0+z), eta=x-v0-z,
holding the actual heavy/light projectors, Gram maps, widths and all physical
parameters fixed. Extend ONLY the existing orbit term by that stated rule.
The antisymmetry of rho implies O(z)^T(v0+z)=0, so the primitive is linear
in z at fixed unshifted x. At z=h=0 it is exactly the original primitive.
Do not replace this declared extension by an assertion of historical uniqueness.

Let Pi_A=dPsi/dz_A at fixed x. It is source free, odd, ghost-1,dimension2.
The parametric canonical-family connection is h_A Pi_A, with h on the left.
Its source-free generators have zero antibrackets and zero curvature. The
extended classical master-family argument is conditional on the inherited
classical master premise; no HB1/C5 or full QAP theorem is activated. In
shifted coordinates qeta=qx-h, hence a tree term -J_eta*h appears. This
fixes the counterterm orientation for comparison, not a chosen cancellation.

Apply FMU's common Wick action sign and contour to the source terms as well.
For scalars/ghosts unchanged, qx unchanged, J_M=-J_E and h_M=h_E. Thus
Psi_E=-Psi_M and the tangent vertex uses the opposite primitive sign from
the Lorentzian orbit density. Derive these facts, and the internal ghost
inverse, rather than copying a positive background factor from the literature.

The actual scalar-source vertex is J_x qx. At one loop the proper J-h
kernel has precisely one ghost and one real scalar propagator joining the
two source vertices. Constant-background source vertices have a sole
quantum port, so yield1PR contributions; exclude them from this proper
kernel, not from the full action. Other ordinary cubic/quartic vertices
violate one-loop two-external-source valence counting. Positive-dimension
insertions cannot change its dimension-zero local pole. Use nonexceptional
Euclidean momentum/positive scalar reference mass to separate IR and UV.

Primary: reconstruct all raw scalar qx matrices from actual portable maps;
check them against plane rho and the actual C3 map. Differentiate the
declared extension, authenticate all432 old orbit coefficients, use the
actual raw C-antighost Green coefficient, and contract complete raw matrices.
Derive the external/Grassmann signs by ordered Wick permutations and the
second cumulant; no guessed half or family factor.
Replay: exact finite Berezin integration followed by scalar Gaussian moments
and -log independently fixes the loop sign. Use normalized plane ghost
pairing and independent GYV scalar-Casimir tables for the complete group
tensor. Derive the same bubble residue by Feynman parameters/Gamma functions.
Only IO/types are shared; no peer outputs or numerical flavor input.

Gate: all107584 scalar kernel positions, all2025 raw ghost entries, actual
source orientation and unchanged E2 scalar columns, original primitive,
reality/symmetry, all12 local-H commutators, exact kernel rank and complete
H-invariant scalar tangent space. Derive dimensions/ranks, do not assign
them from expectation. Compare the full matrix before testing B126*K*v
against the independent FMU required image. Distinguish full-matrix and
mass-projection coverage. No quantum coefficient is solved to force agreement.

Controls: wrong external/source Wick phase, missing Grassmann permutation,
extra loophalf/family3, replacing the heavy dual Gram map by the primal map,
dropping the tangent orbit term, and replacing the heavy Casimir by the
full Spin(10) Casimir. The last can be invisible on the frozen VEV; retain
that insensitivity explicitly rather than claiming a sensitive mass test.

Comparator arXiv1305.1548v3 Eq17c,18,20a,23: the source two-point method and
extra background factor guide this provisional construction. The complete
nonlinear GF/sterile-hat quantum domain is still not inherited from that
paper. A matched loop would qualify this explicit source extension's UV
kernel and its mass projection, not a physical finite normalization, vacuum
stationarity, all328 independent VEV choices or full quantum equivalence.

Freeze eight sources/copies before sequential primary/replay/gate;600s each
after imports,8GiB sampled private cap,350MiB launch floor,16MiB package cap;
no agents. Preserve failures/unfinished runs before versioned correction.
No retries that weaken domains, resources, equality or scientific acceptance.
Possible outcomes: constructed matched provisional kernel; exact mismatch;
underdefined extension/domain; resource incomplete. Shared action/maps,
canonical premise, Python/SymPy and AI authorship limit independence.

Ceiling34/39/scientific-director acceptance NOT_PERFORMED. No source/physical
scheme adoption, foundation/state change, flavor resume, HB1/C5 activation,
E5/A5 promotion, publication/push/branch/worktree or protected evidence change.
Original hierarchy exclusions, separate140% singlet warning, quartetFAIL and
custodyexit2/seven NOTPASS remain. Record resources, limitations, AI capability
and the smallest next quantum input in RESULT.md after actual validation.
