"""VTS1 full kernel/source/primitive comparison and independent mass image."""
from data import *
from functools import lru_cache
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for n,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(n))==h,n
@lru_cache(None)
def coeff(v):return s.sympify(v)
def tidy(M):return s.SparseMatrix(M).applyfunc(s.simplify)
def zero(M):assert not tidy(M).todok()
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');K=dec(P['kernel_unit']);zero(K-dec(R['kernel_unit']));zero(dec(P['raw_ghost_Green_unit'])-dec(R['raw_ghost_Green_unit']));zero(K-K.T);zero(K-K.conjugate())
for d in [P,R]:
 assert d['second_cumulant_unit']==d['bubble_residue']==d['tangent_E_vertex_phase_relative_positive_gxi']=='1'
 assert d['source_J_Wick_phase']==d['primitive_Wick_phase']=='-1' and d['external_source_extension']=='PROVISIONAL_EXPLICIT_NOT_ADOPTED'
 assert d['new_one_loop_source_pole_families']==1 and d['new_two_loop_integrals']==0
assert P['ordered_Wick_permutation_signs']==[-1,-1] and P['primitive_original_orbit_rows']==432
assert tidy(K-dec(P['wrong_primal_primitive_kernel'])).todok() and tidy(K-K/2).todok() and tidy(K-3*K).todok() and tidy(2*K).todok()
gy=packed(CAL/'canonical_so10_gauge_yukawa_vertex_poles/primary_tables.json.gz');CI,CH=map(dec,gy['scalar_Casimir_I_H']);zero(K-CI+CH);assert tidy(K-CI).todok()
yc=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');H=dec(yc['H_new']);phys=read(PK/'frozen_a10_physical_reconciliation/full_primary.json');v=dec(phys['vacuum']['VEV']);zero(CH*v);zero((K-CI)*v)
counts={};ranks={};singlet_columns=[];off=0
for sec,n in SECTORS:
 reps=list(map(dec,phys['representation_matrices'][sec]));block=K[off:off+n,off:off+n];hb=CH[off:off+n,off:off+n];basis=hb.nullspace();N=s.SparseMatrix.hstack(*basis) if basis else s.SparseMatrix(n,0,{})
 for h in range(12):
  rh=tidy(sum((H[a,h]*reps[a] for a in range(45) if H[a,h]),s.SparseMatrix(n,n,{})));zero(rh*block-block*rh);zero(rh*N)
 counts[sec]=len(basis);ranks[sec]=int(block.rank());cols=s.SparseMatrix(328,len(basis),{})
 for i in range(n):
  for j in range(len(basis)):cols[off+i,j]=N[i,j]
 singlet_columns.append(cols);off+=n
N=s.SparseMatrix.hstack(*singlet_columns);proj=N*(N.T*N).inv()*N.T;zero(proj*proj-proj);zero(CH*proj);zero(proj*K-K*proj)
# Actual source orientation is checked against the scalar part of the
# full source polynomial, retaining the odd reordering to J on the left.
portable=packed(ROOT/'tools/portable_dh_v1/inputs.json.gz');maps=portable['master_field_maps'];base=read(PK/'frozen_a10_bv_master/primary.json')['source_polynomial'];observed={};source_count=0
for row in base:
 js=[n for n in row['word'] if n.startswith('Jx_')]
 if not js:continue
 assert len(js)==1 and len(row['word'])==3;j=js[0];out=j[1:];rest=tuple(n for n in row['word'] if n!=j);assert rest[0].startswith('C') and rest[1].startswith('x_')
 sign=(-1)**sum(n.startswith('C') for n in row['word'][:row['word'].index(j)]);observed[out,rest]=observed.get((out,rest),0)+sign*coeff(row['coefficient']);source_count+=1
expected={(out,tuple(row['word'])):coeff(row['coefficient']) for out,rows in maps.items() if out.startswith('x_') for row in rows}
assert set(expected)==set(observed) and all(s.simplify(observed[k]-x)==0 for k,x in expected.items())
e2=read(PK/'frozen_a10_e2_transport/primary.json')['complete_columns']
for out in maps:
 if out.startswith('x_'):
  assert e2[out]['physical_program'] is None
  rows=e2[out]['source_polynomial'];assert not any(n.startswith('J') for row in rows for n in row['word'])
  ep={tuple(row['word']):coeff(row['coefficient']) for row in rows};ex={tuple(row['word']):coeff(row['coefficient']) for row in maps[out]};assert ep==ex
assert source_count==P['scalar_source_coefficients_checked']
massimages=[]
for key,mkey in [('B10','mass10'),('B126','mass126')]:
 image=tidy(dec(yc[key])*K*v);mass=dec(yc[mkey]);unit=s.Rational(25,2) if key=='B126' else 0;zero(image-unit*s.Matrix(256,1,list(mass)));massimages.append({'carrier':key,'coefficient':str(unit),'nonzero_positions':len(image.todok())})
fmu=read(CAL/'canonical_so10_fermion_mass_uv/validation_receipt.json');assert fmu['additional_over_scalar_half_field_stripped']=='(25/2)*xi*g10^2*M'
# Tree -J*h under the shifted-coordinate connection; a pole +g²xi*K
# therefore requires -J*(deltaZhat/2)*h with deltaZhat/2=g²xi*K.
t,z=s.symbols('t z');assert s.diff(-(1+t*z)*s.Symbol('J_h'),t).subs(t,0)==-z*s.Symbol('J_h')
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_FULL_VACUUM_TANGENT_SOURCE_UV_KERNEL_IN_EXPLICIT_PROVISIONAL_EXTENSION','elapsed_after_imports':time.perf_counter()-start,'full_scalar_positions_compared':328**2,'raw_ghost_positions_compared':45**2,'scalar_source_coefficients_checked':source_count,'original_primitive_orbit_positions':432,'kernel_nonzero_positions':len(K.todok()),'kernel_rank':sum(ranks.values()),'kernel_sector_ranks':ranks,'H_invariant_scalar_dimensions':counts,'H_invariant_scalar_total':N.cols,'H_covariance_matrix_positions_checked':12*sum(n*n for _,n in SECTORS),'loop_Jh_pole':'g10^2*xi*(Cs_I-Cs_H)/(16*pi^2*epsilon)','extra_half_background_counterterm':'g10^2*xi*(Cs_I-Cs_H)/(16*pi^2*epsilon)','mass_images':massimages,'full_Spin_Casimir_replacement_changes_kernel':True,'frozen_VEV_projection_sensitive_to_full_vs_heavy_Casimir':False,'source_and_Grassmann_phase_controls_sensitive':True,'new_one_loop_source_pole_families':1,'new_two_loop_integrals':0,'external_source_extension':'PROVISIONAL_EXPLICIT_NOT_ADOPTED','classical_canonical_connection_lemma':'CONDITIONAL_ON_INHERITED_MASTER_PREMISE_SOURCE_FREE_ZERO_CURVATURE','finite_VEV_tadpole_or_physical_scheme_adopted':False,'full_nonlinear_QAP_or_quantum_equivalence_qualified':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
