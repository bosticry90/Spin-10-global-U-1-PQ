"""VTS1 exact Berezin/Gaussian integration and independent plane Casimir."""
from data import *
start=begin('replay')
# Four independent odd generators J,h,C,a represented by exterior masks.
# This is a separate algebra from the primary ordered Wick permutations.
def plus(A,B):
 out=dict(A)
 for k,v in B.items():out[k]=s.expand(out.get(k,0)+v)
 return {k:v for k,v in out.items() if v}
def scale(A,c):return {k:s.expand(c*v) for k,v in A.items() if c*v!=0}
def mul(A,B):
 out={}
 for a,x in A.items():
  for b,y in B.items():
   if a&b:continue
   inv=sum(1 for i in range(4) for j in range(4) if (a>>i)&1 and (b>>j)&1 and i>j);k=a|b;out[k]=out.get(k,0)+(-1)**inv*x*y
 return {k:s.expand(v) for k,v in out.items() if s.expand(v)!=0}
Q,S,z,aa,bb=s.symbols('Q S z a b',nonzero=True)
action={12:-Q,5:aa*z,10:bb*z};term={0:s.S.One};exponential=dict(term)
for n in range(1,5):term=scale(mul(term,action),-s.Rational(1,n));exponential=plus(exponential,term)
integrated={k^12:v for k,v in exponential.items() if k&12==12};base=integrated[0];assert base==Q
# Scalar Wick moment <z²>=S, followed by -log of the source-nilpotent ratio.
ratio=plus(scale(integrated,1/base),{0:-1});assert set(ratio)=={3};logco=s.expand(-ratio[3]).subs(z*z,S);unit=s.simplify(logco*Q/(aa*bb*S));assert unit==1
# The actual Euclidean scalar source and tangent primitive have opposite
# coefficient signs. Thus the scalar-generator product has an overall minus.
gy=packed(CAL/'canonical_so10_gauge_yukawa_vertex_poles/replay_v2_tables.json.gz');CI,CH=map(dec,gy['scalar_Casimir_I_H']);K=(unit*(CI-CH)).applyfunc(s.simplify)
phys=read(PK/'frozen_a10_physical_reconciliation/full_replay.json');e1=read(PK/'frozen_a10_e1_fermion/replay.json');q=dec(phys['C3_plane_to_parent']);fm=dec(e1['charts']['blocks']['heavy_dual']['field_embedding']);pm=q[:,12:]*fm.T
assert not (pm*pm-pm).applyfunc(s.simplify).todok()
# A normalized plane C-a pairing is identity; its contraction with the
# actual heavy tangent projection is pm, rather than the full45 identity.
ref=read(PK/'frozen_a10_e5_full_hessian/replay.json')['retained_reference'];fi={n:i for i,n in enumerate(ref['field_order'])};green=dec(ref['reference_Green_raw_C3']);p=s.symbols('p0_ref0:4');P=p[0]**2-sum(x*x for x in p[1:]);anti=[f'bar{a}' if a<12 else f'ub{a}' for a in range(45)]
CG=s.SparseMatrix(45,45,{(i,j):s.simplify(P*green[fi[f'C{i}'],fi[anti[j]]]) for i in range(45) for j in range(45) if green[fi[f'C{i}'],fi[anti[j]]]!=0})
ph=s.SparseMatrix.hstack(q[:,:12],fm);assert not (q*CG*ph.T-s.eye(45)).applyfunc(s.simplify).todok()
eps,D=s.symbols('epsilon D',positive=True);parameter=s.Symbol('u',nonnegative=True);m2,p2=s.symbols('m2 p2',positive=True);delta=(1-parameter)*m2+parameter*(1-parameter)*p2
analytic=s.gamma(1+eps)*delta**(-eps);radial=analytic.subs(eps,0);residue=s.integrate(radial,(parameter,0,1));assert residue==1
finish('replay',{'method':'exact_exterior_Berezin_scalar_Gaussian_minus_log_and_independent_scalar_Casimir','kernel_unit':enc(K),'raw_ghost_Green_unit':enc(CG),'second_cumulant_unit':str(unit),'bubble_residue':str(residue),'source_J_Wick_phase':'-1','primitive_Wick_phase':'-1','tangent_E_vertex_phase_relative_positive_gxi':'1','heavy_projection':enc(pm),'new_one_loop_source_pole_families':1,'new_two_loop_integrals':0,'external_source_extension':'PROVISIONAL_EXPLICIT_NOT_ADOPTED'},start)
