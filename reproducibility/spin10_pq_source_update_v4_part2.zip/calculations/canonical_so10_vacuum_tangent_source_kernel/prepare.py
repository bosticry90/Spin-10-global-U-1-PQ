"""VTS1 immutable provisional-extension source and actual-input freeze."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
BASE='2b8c6500a8bc76540b5f60aa64c5b25f281bb14b';CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/vacuum-tangent-source-kernel-v1-2026-10-22')
git=lambda *v:subprocess.check_output(['git',*v],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
b={}
def add(p,h=None):
 p=p.resolve();v=sha256(p.read_bytes()).hexdigest()
 if h is not None:assert v==h,str(p)
 b[str(p)]=v
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V493.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md']:add(ROOT/n)
add(ROOT/'tools/portable_dh_v1/inputs.json.gz','7cb864dcef9d47e664c2a7cec3a5d457f2e9872eae7af4f015a0e0bd3fc0edcb')
for n in ['export_a10_e5_antighost_vector.py','frozen_a10_e5_full_hessian/primary.json','frozen_a10_e5_full_hessian/replay.json','frozen_a10_physical_reconciliation/full_primary.json','frozen_a10_physical_reconciliation/full_replay.json','frozen_a10_e1_fermion/primary.json','frozen_a10_e1_fermion/replay.json','frozen_a10_e1_fermion/M08_PHYSICAL_FRAME_GAUGE_FERMION_V1.json','frozen_a10_e1_fermion/validation_receipt.json','frozen_a10_e2_transport/primary.json','frozen_a10_e2_transport/validation_receipt.json','frozen_a10_bv_master/primary.json','frozen_a10_bv_master/validation_receipt.json']:add(PK/n)
for folder,names in {
 'canonical_so10_yukawa_carrier_transport':['primary_tables.json.gz','validation_receipt.json'],
 'canonical_so10_gauge_yukawa_vertex_poles':['primary_tables.json.gz','replay_v2_tables.json.gz','validation_receipt_v2.json'],
 'canonical_so10_auxiliary_scalar_mass_interface':['RESULT.md','validation_receipt.json'],
 'canonical_so10_fermion_mass_uv':['RESULT.md','DERIVATION.md','validation_receipt.json']}.items():
 for n in names:add(ROOT/'calculations'/folder/n)
for n,h in {'project_state.json':'d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8','calculations/canonical_so10_fermion_mass_uv/validation_receipt.json':'b494bbb94f65e86b54e3ba574bc4a1498160793deebe5e028cb83dc87c149b2f'}.items():add(ROOT/n,h)
for n,h in {'frozen_a10_e1_fermion/validation_receipt.json':'a9dab74d6a9f2eac7cf377d858eb29f9dcaf00bf9fbfde0fce0cafcc2cbbe677','frozen_a10_e2_transport/validation_receipt.json':'ac0e29bf834e7bc24dac3e8e8328e940bd45a4e3ca518f170ef737411f278d11','frozen_a10_bv_master/validation_receipt.json':'e18a7e33562236a84ec3dd75948c98a9db76f21c5c76cd419518fe55022f7776'}.items():add(PK/n,h)
for name in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/name;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw)
 with (HERE/(name+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(name+'.source.txt'))
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==30501
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
with (HERE/'preparation.json').open('xb') as f:f.write((json.dumps({'schema':'VTS1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(b.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('VTS1_FROZEN',len(b),'bindings',flush=True)
