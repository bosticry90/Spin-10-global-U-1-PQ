# VTS1: a full vacuum-tangent source UV kernel in an explicit extension

The independently calculated proper source kernel is

    Gamma_(J,h),pole = [g10²*xi/(16*pi²*epsilon)] J^T K h,
    K=Cs,I-Cs,H=-sum_ab PM_ab rho_a rho_b.

It supplies the additional half-background factor

    deltaZhat/2 = g10²*xi*K/(16*pi²*epsilon)

in the declared shifted-coordinate convention with tree source term -J*h.
Its projection onto the actual126 mass direction is exactly the extra
(25/2)*xi*g10²*M/(16*pi²*epsilon) required independently by FMU1.

Receipt `validation_receipt.json`, SHA-256
`06e4061964a1c004607368e890dad39958f5bd19d3bdb3a1b7138b78fb39712c`,
QUALIFIED_FULL_VACUUM_TANGENT_SOURCE_UV_KERNEL_IN_EXPLICIT_PROVISIONAL_EXTENSION.
Scientific/director acceptance NOT_PERFORMED; state113/authority34of39 unchanged.

## The source extension is explicit and provisional

The existing E1 primitive treats its orbit as frozen data. This increment
does not pretend that it already contained a uniquely prescribed vacuum-
source extension. It defines v=v0+z, O_a=rho_a(v0+z), eta=x-v0-z, with
external qz=h,qh=0 and fixed heavy/light projectors, Gram maps and physical
parameters. The new variables are not integrated or physical particles.

At z=h=0 the original primitive is recovered, including all432 orbit
coefficients. Antisymmetry gives O(v)^T*v=0 identically; the new tangent
primitive is source free and linear, with zero second derivative and zero
antibracket curvature. The canonical-connection argument in DERIVATION is
conditional on the inherited classical master premise. It neither removes
SMA's evanescent matter breaking nor establishes a new quantum master/QAP
theorem. No blocked stage or physical prescription was activated/adopted.

The same Wick action sign used in FMU also acts on the sources. Keeping
the scalar source vertex J*qx fixes J_M=-J_E; the tangent convention fixes
h_M=h_E. Consequently Psi_E=-Psi_M. This makes the Euclidean tangent
vertex +g*xi*h*antighost*T*x, while the scalar-source vertex is -g*J*R*C*x.
Copying the Lorentzian primitive sign would reverse the inferred result.

## Actual action coefficients, not a fitted Casimir

The primary reconstructs the29754 actual scalar-source coefficients from
portable master maps, checks their complete C3-to-plane representation and
uses the actual raw ghost Green matrix. Its heavy tangent vertex retains
the dual embedding FM=QM*(QM^T QM)^-1. It contracts these source, primitive
and Green tensors directly, with the sign derived from ordered Wick
permutations and the second cumulant. No mass-restoration target assigns
the loop coefficient.

The replay performs exact Berezin integration in an exterior algebra,
scalar Gaussian averaging and -log, then uses the independent scalar
Casimir tables in normalized plane coordinates. Both routes derive the
bubble residue1 with nonexceptional momentum/positive scalar reference
mass. There is no extra Gaussian half or fermion-family multiplicity.

The gate compares all107584 scalar matrix positions and2025 raw ghost
positions, including zeros. It separately authenticates the source-left
Grassmann orientation against the original full BV source polynomial and
checks that E2's scalar columns remain the same source-free qx maps.
Full source matrices were compared before any selected mass projection.

The resulting real symmetric K has1342 nonzero entries and rank326:

| Scalar sector | Kernel rank | Complete H-invariant tangent dimension |
| --- | ---: | ---: |
| Phi54 | 54 | 1 |
| Sigma252 | 252 | 2 |
| phi20 | 20 | 0 |
| S2 | 0 | 2 |

All12H commutators are checked sectorwise across801888 positions, with
cross-sector zeros fixed by the actual vertices and scalar reference.
The five-dimensional H-invariant tangent space is derived from the kernel
of the actual H Casimir and checked against all12 generators. It is not
an assumed or freely scanned physical vacuum domain.

B10*K*v=0 and B126*K*v=(25/2)*vec(M126), including their complete zero
complements. The latter gives the independent FMU mass image after tensoring
with the still symbolic Y126. This establishes a concrete source-loop
origin in this extension for the extra projected VEV factor; it does not
determine finite stationarity, tadpoles or arbitrary physical VEV choices.

## Sensitive controls and a deliberate insensitivity

Changing the external-source/primitive Wick phase or the Grassmann
permutation reverses the loop sign. Extra half/family3 and omission of
the tangent orbit term change the nonzero answer. Substituting the heavy
primal map for its actual dual Gram map also changes the full matrix.

The full Spin(10) Casimir is NOT this full kernel: their difference is
the nonzero H Casimir. That substitution would nevertheless be invisible
on the frozen vacuum because Cs,H*v=0. The selected fermion mass test
cannot validate the full328-coordinate kernel by itself. This insensitivity
is retained explicitly rather than advertised as a negative control.

The result has the expected source/background-renormalization structure
discussed in Sperling,Stockinger,Voigt, arXiv1305.1548v3 Eq17c,18,23,
https://arxiv.org/abs/1305.1548 . The actual heavy projector and nonminimal
charts distinguish this construction from simply importing that paper's
full-gauge formula. Its complete nonlinear source/QAP domain is not borrowed.

## Execution, capability and limits

Primary/replay/gate COMPLETED exit0 in141.9971840/2.1417845/14.4602156s
after imports. They have72/2/9 private-memory samples, with maxima
188,329,984/94,973,952/338,554,880 bytes; these are sampled maxima, not
continuous peaks. Frozen600s/8GiBsampled/350MiBfloor/16MiB limits were
unexhausted.46/53 bindings, eight exact source copies and full captures
remain. No frozen scientific worker/verifier failed or was corrected.

A prelaunch read-only schema probe attempted to slice a dictionary and
failed before scientific execution. The corrected intake inspected its
actual keys. Its visible source/output transcript is retained externally;
native raw bytes were not captured at that point, which is stated rather
than manufactured retrospectively. This operational error changed no input.
Fresh current-turn E4 completed expected0,0,0,0,0,2; historical custody
remains exit2/seven NOTPASS.

The AI-capability result is a fully stated provisional construction, a
corrected source/Wick-sign analysis before execution, an actual model
kernel, distinct Grassmann derivations and a successful independent mass
projection. Shared action, canonical premise, supplied maps, software and
AI authorship remain error correlations. This is internal corroboration,
not external scientific or empirical validation of Spin(10).

Only the pole and its required source counterterm matrix are constructed.
The correlated renormalization of the full extended action, finite contact
normalization, nonlinear source products, matter measure/phase/evanescent
restoration, complete QAP/forest, finite matterC1, E5/A5 and physical
unification remain unqualified. No b0/kappa relation, finite scheme, flavor
point or physical benchmark was selected. All historical exclusions, the
separate140% singlet warning, flavor pause, HB1/C5 blocks and quartetFAIL
are preserved; no authority or foundational status changed.

Next: assess the remaining actual fermionic source-vertex UV inputs before
claiming a complete matter counterterm action. In particular, classify the
proper K_P-C-P one-loop support using both ordinary ghost-vector and
nonlinear auxiliary-ghost vertices, rather than assuming a linear gauge.
The source extension above stays provisional throughout that investigation.
