"""VVS1 full comparison, independent f.O norm and actual IR domain."""
from data import *
def parse(v):return s.sympify(v,locals={'w':w})
def main():
    start=begin('validation_preparation.json')
    for p,h in json.loads((HERE/'preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
    A,B=[packed(HERE/f'{r}_tables.json.gz') for r in ['primary','replay']]
    assert A==B # Full tensor plus every implicit zero, norm and placement.
    assert A['tensor_positions']==664200 and A['tensor_shape']==[45,45,328]
    assert A['vector_ranks']==[12,8,1,12,12] and A['scalar_counts']==[290,5,8,1,12,12]
    assert A['actual_H_tensor_intertwiners']==12 and A['float_atoms']==0
    native=[]
    for role in ['primary','replay']:
        c=json.loads((HERE/f'{role}_capture.json').read_bytes());r=json.loads((HERE/f'{role}_result.json').read_bytes())
        assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
        blob=(HERE/f'{role}_tables.json.gz').read_bytes();assert sha256(blob).hexdigest()==r['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['tables_sha256']
        peak=max(v['private_bytes'] for v in c['all_resource_samples']);assert peak<=8*1024**3 and c['launch']['memory']['available_pagefile']>=350*1024**2
        assert r['elapsed_after_imports']<600
        native.append({'role':role,'seconds':r['elapsed_after_imports'],'sampled_private_max':peak})
    values,fci,Phi=inputs('primary');action,rho,V,ad,Ps,frame,Q,Qi,E=values
    O=dec(action['vacuum']['orbit']);T=ordered_table();Gram=tidy(O.T*O)
    old=packed(CAL/'canonical_so10_background_threshold_inputs/replay_tables.json.gz')
    anti={}
    for a,b,c,z in old['f']:
        for i in range(328):
            if O[i,c]:anti[a*45+b,i]=anti.get((a*45+b,i),s.S.Zero)+s.sympify(z)*O[i,c]
    anti=tidy(s.SparseMatrix(2025,328,anti));zero(anti-(T-transpose_tensor(T)))
    # Lie-algebra closure and full parent Casimir provide another invariant.
    H=s.SparseMatrix(45,45,{})
    for a,b,c,z in old['f']:
        for aa,bb,d,zz in old['f']:
            if aa==a and bb==b:H[c,d]+=s.sympify(z)*s.sympify(zz)
    zero(H-8*s.eye(45));anti_norm=red(s.trace(Gram*H));assert anti_norm==frob(anti)
    total=red(4*frob(T)-anti_norm);assert red(total-parse(A['total_norm_squared']))==0
    assert total!=parse(A['ordered_T_total_norm_squared']) and total!=parse(A['half_S_total_norm_squared'])
    nn={(v['first_vector'],v['second_vector'],v['scalar_type']):parse(v['norm_squared']) for v in A['norms']}
    assert len(nn)==150 and set(nn)=={(r,t,k) for r in range(5) for t in range(5) for k in range(6)}
    support=[];excluded=[]
    for r in range(5):
        for t in range(5):
            for k in range(6):
                assert red(nn[r,t,k]-nn[t,r,k])==0
                (support if nn[r,t,k]!=0 else excluded).append([r,t,k])
    two_light=[v for v in support if v[0]==v[1]==0]
    one_light=[v for v in support if (v[0]==0)!=(v[1]==0)]
    scalar_soft=[v for v in support if v[2]==1]
    multiply_soft=[v for v in support if (v[0]==0)+(v[1]==0)+(v[2]==1)>=2]
    # Physical/soft orbit orthogonality gives an exact structural light zero;
    # it is not silently extended to Goldstone scalar modes.
    for k in [0,1]:
        zero(O.T*Phi[k])
        for R in rho:zero(Ps[0]*O.T*R*Phi[k])
        for t in range(5):assert nn[0,t,k]==0
    lightnorm=red(sum(v for (r,t,k),v in nn.items() if r==0))
    # Independent unbroken-adjoint Casimir formula inherited for ordered T's
    # transpose. The full VVS light row has no factor1/4.
    H0=tidy(-sum((M*M for M in ad),s.SparseMatrix(45,45,{})))
    assert red(lightnorm-s.trace(Gram*H0))==0
    assert lightnorm!=0 and one_light
    gss=packed(CAL/'canonical_so10_ghost_scalar_support/primary_support_tables.json.gz')
    gn={(v['antighost'],v['ghost'],v['scalar_type']):parse(v['norm_squared']) for v in gss['norms']}
    differences=sum(red(nn[key]-gn[key])!=0 for key in nn)
    assert differences>0
    assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<6*1024**2
    out={'schema':'VVS1_VALIDATION','execution_state':'COMPLETED','status':'QUALIFIED_COMPLETE_VVS_ACTION_AND_MASS_SUPPORT',
      'tensor_positions':664200,'tensor_nonzero':A['tensor_nonzero'],'tensor_zero':664200-A['tensor_nonzero'],
      'full_exact_tensor_and_zero_complement_agree':True,'profile_positions':150,'supported_profiles':support,
      'supported_profile_count':len(support),'excluded_profile_count':len(excluded),'excluded_profiles':excluded,
      'one_light_vector_profiles':one_light,'two_light_vector_profiles':two_light,'scalar_soft_profiles':scalar_soft,
      'multiply_soft_profiles':multiply_soft,'first_vector_light_total_norm_squared':str(lightnorm),
      'total_vertex_norm_squared':str(total),'antisymmetric_ghost_tensor_norm_squared':str(anti_norm),
      'ordered_ghost_replacement_change_profiles':differences,'half_vertex_control_sensitive':True,
      'light_omission_control_sensitive':True,'VEV_S_contraction_is_2Gram':True,
      'H_intertwiners':12,'background_ordered_words':15,'Wick_weight':'-1/4','native_runs':native,
      'inherited_BFT_action_and_Gaussian_proof':'AUTHENTICATED_NOT_RERUN',
      'full_VVS_amplitude_calculated':False,'full_C1_or_E5_qualified':False,'scientific_acceptance':'NOT_PERFORMED',
      'authority':'34/39_UNCHANGED','shared_limits':['action','reference point','scalar projectors','exact ring/software','AI authorship'],
      'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
if __name__=='__main__':main()
