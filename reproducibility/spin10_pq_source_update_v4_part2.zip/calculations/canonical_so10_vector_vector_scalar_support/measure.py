"""VVS1 full action vertex, independent exact projected support routes."""
from data import *
def main():
    role=sys.argv[1];assert role in ['primary','replay'];start=begin('preparation.json')
    values,fci,Phi=inputs(role);action,rho,V,ad,Ps,frame,Q,Qi,E=values
    O=dec(action['vacuum']['orbit']);T=ordered_table()
    S=tidy(T+transpose_tensor(T)) if role=='primary' else gram_derivative(O,rho)
    zero(S-transpose_tensor(S));zero(S-S.conjugate())
    Gram=dec(action['vacuum']['orbit_Gram']);vev=dec(action['vacuum']['VEV'])
    zero(S*vev-2*s.Matrix(2025,1,lambda ab,j:Gram[ab//45,ab%45]))
    for h in range(12):
        Rh=tidy(sum((V[a,h]*rho[a] for a in range(45) if V[a,h]),s.SparseMatrix(328,328,{})))
        zero(Rh*O-O*ad[h])
        L=s.kronecker_product(ad[h],s.eye(45))+s.kronecker_product(s.eye(45),ad[h])
        zero(L*S-S*Rh)
        for P in Ps:zero(P*ad[h]-ad[h]*P)
    G=load('vvs_basis',CAL/'canonical_so10_ghost_scalar_support/data.py')
    U=[G.orthogonal_basis(P) for P in Ps] if role=='primary' else None
    norms=[];whole=s.S.Zero
    for r in range(5):
        for t in range(5):
            B=tidy(s.kronecker_product(U[r].T,U[t].T)*S) if role=='primary' else tidy(s.kronecker_product(Ps[r],Ps[t])*S)
            local=[]
            for typ,P in enumerate(Phi):
                val=frob(tidy(B*P));local.append(val)
                norms.append({'first_vector':r,'second_vector':t,'scalar_type':typ,'norm_squared':str(val),'vertex_zero':val==0})
            assert red(sum(local)-frob(B))==0;whole+=sum(local)
        print('STAGE '+role+'_vector_pairs_first_'+str(r),flush=True)
    assert red(whole-frob(S))==0
    # This polarized Gram derivative is exactly the canonical kinetic VVphi
    # vertex; the inherited linear gauge fixing has quantum degree<=2 here.
    inv=load('vvs_inventory',CAL/'canonical_so10_background_threshold_inputs/inventory.py')
    summary,words=inv.build(role)
    assert [v for v in summary['families'] if v[0]=='VVS']==[['VVS','-1/4',15]]
    weight=-s.Rational(1,2)*s.Rational(1,2)**2*2;assert weight==-s.Rational(1,4)
    rows=[[ab//45,ab%45,i,str(v)] for (ab,i),v in sorted(S.todok().items())]
    floats=sum(len(v.atoms(s.Float)) for v in S.todok().values());assert floats==0
    out={'schema':'VVS1','tensor_shape':[45,45,328],'tensor_positions':664200,'tensor_nonzero':len(rows),'S':rows,
      'norms':norms,'total_norm_squared':str(frob(S)),'ordered_T_total_norm_squared':str(frob(T)),
      'half_S_total_norm_squared':str(frob(S)/4),'vector_ranks':[int(s.trace(P)) for P in Ps],
      'scalar_counts':[int(red(s.trace(P))) for P in Phi],'actual_H_tensor_intertwiners':12,
      'Wick_weight':str(weight),'background_words':words['VVS'],'float_atoms':floats,
      'full_VVS_amplitude_calculated':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED'}
    save(role,out,start)
if __name__=='__main__':main()
