"""VVS1 exact shared inputs; all old helpers remain immutable."""
from pathlib import Path
from hashlib import sha256
import json,gzip,sys,time,threading,os,importlib.util
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_finite_counterterm_insertion'))
from geometry_v2 import red,tidy,zero,enc,dec,inflate,w,QUAD
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def load(n,p):
    spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def begin(prep):
    start=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for p,h in json.loads((HERE/prep).read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
    return start
def save(role,v,start):
    raw=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/f'{role}_tables.json.gz').open('xb') as f:f.write(blob)
    print('RESULT '+json.dumps({'schema':'VVS1_NATIVE','role':role,'elapsed_after_imports':time.perf_counter()-start,
      'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)
def inputs(role):
    G=load('vvs_gss',CAL/'canonical_so10_ghost_scalar_support/data.py');return G.inputs(role)
def frob(M):return red(sum((s.conjugate(v)*v for v in M.todok().values()),s.S.Zero))
def transpose_tensor(T):
    return s.SparseMatrix(2025,328,{(b*45+a,i):v for (ab,i),v in T.todok().items() for a,b in [divmod(ab,45)]})
def ordered_table():
    old=packed(CAL/'canonical_so10_background_threshold_inputs/primary_tables.json.gz')
    return s.SparseMatrix(2025,328,{(a*45+b,i):s.sympify(v) for a,b,i,v in old['T']})
def gram_derivative(O,rho):
    U=[R*O for R in rho];out={}
    for a in range(45):
        for b in range(45):
            vec=tidy(-U[a][:,b]-U[b][:,a])
            for (i,j),v in vec.todok().items():out[a*45+b,i]=v
    return s.SparseMatrix(2025,328,out)
