# VVS1: action-derived vector-vector-scalar support and infrared inventory

Base7562f42c14ef1ab5a946fbfc4534509f3378c76b/main, recovered clean with no
live research workers. Previous turn PROGRESS: complete ghostS primitive.
Whole Spin(10)xPQ goal ACTIVE/incomplete. State113/authority34of39 unchanged.

Question: what is the complete VVS vertex and which of25 ordered vector-mass
pairs times6 full scalar projectors can occur before a VVS loop is integrated?
This is an indispensable support/IR prerequisite to one of the five remaining
C1_GS primitive families. Cheapest competent test is exact tensor projection,
not a guessed kernel or another large effective-action expansion.

Domain: conventional C1 linear background Rxi reference, tree xi1, same actual
stationary scalar point and328 real fields, five vector sectors of ranks
12/8/1/12/12 with mass-squared coefficients0,3/10,3/2,25,253/10. Scalars:
physical290, soft5, Goldstone8/1/12/12. No physical point, gauge scheme,
counterterm normalization or foundational assumption is adopted or changed.
This is not the E1 nonlinear gauge-fixing auxiliary/quartic-ghost action.

From the actual canonical kinetic density (D(v+phi))^T D(v+phi)/2, define
O_a=rho_a v, T_abI=O_a^T rho_b e_I and
S_abI=T_abI+T_baI=-(rho_a O_b+rho_b O_a)_I.
The cubic density is g^2 S_abI V_a.V_b phi_I/2; the species-normalized
Hessian vertex is g^2 S_abI delta_mu_nu, NOT g^2 S_abI/2. The C1 linear
gauge-fixing function has no additional quantum VVphi term. Background
covariance comes from the qualified actual H action and Dbar, not constant
backgrounds substituted for the F^2 momentum projection.

Primary route: inherited qualified BFT ordered T table, sum its transpose,
orthonormal vector-sector bases and full scalar projections. Replay: polarized
derivative of Gram(v)=O(v)^T O(v) from actual rho and O, full45 vector
projectors and scalar projections. Compare all664200 tensor positions,
including implicit zeros, all150 exact squared norms and their zero complement.
Check all12 actual H intertwiners, all projectors, symmetry/reality, S.v=2Gram,
and independent whole norm 4||T||^2-||f.O||^2. Reuse authenticated BFT action,
Gaussian auxiliary prescription and its Wick/15-placement theorem; do not
pretend it is a fresh independent action derivation. Recheck the small VVS
Wick combinatorics (-1/2)(1/2)^2*2=-1/4 and independent15 ordered placements.

Do not transfer ghost P0T=0 to S. Test all light/heavy and scalar-soft
assignments without omission or thresholding. A vertex nonzero is candidate
support, NOT a measured nonzero F^2 amplitude. Heat/background insertions
preserve vector mass subspaces because [Pr,ad_H]=0; report two-light,
one-light, scalar-soft and multiply-soft domains from actual projections.
Negative controls: ordered T in place of S, half-normalized S, omitted light
profiles. Report insensitive projections explicitly; never demand arbitrary
diagnostics distinguish every error.

Freeze this record, all sources, exact qualified transitive inputs, current
policy and state before computation. Run two workers sequentially under
pole-blind sitecustomize, then a separate verifier only after both complete.
Each atomic worker/verifier <=600s, sampled private <=8GiB, launch commit
headroom>=350MiB, package<=6MiB. Exclusive outputs, full native captures,
resource samples and post-run observations. No silent truncation/cache resume.
Failed sources/captures remain immutable; resource exhaustion INCOMPLETE,
not a theorem. Symbolic exact ring with w reduced by inherited QUAD; no floats.

Qualification requires full tensor/norm agreement, action/Wick/covariance
checks, negative controls and explicit IR inventory. Outcomes: qualified
support, refuted proposed vertex, underdefinition or bounded inconclusive.
Authority ceiling: no VVS heat/Fourier kernel or amplitude, no subtraction,
no finite C1, no physical gauge unification, no E5/A5/authority promotion.
Scientific acceptance NOT_PERFORMED. Shared action, point, scalar frame,
software and AI authorship limit independence. Preserve historical quartet,
scalar quantum-control, matching and custody failures. No push/publication.
