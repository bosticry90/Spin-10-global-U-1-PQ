"""G2B1 exact whole-domain agreement and normalization-sensitive controls."""
from data import *
start=begin('validation_preparation.json');a=packed(HERE/'primary_tables.json.gz');b=packed(HERE/'replay_tables.json.gz');assert a==b
gcu=packed(CAL/'canonical_so10_gauge_coupling_uv/primary_tables.json.gz');assert a['parent_b_one']==gcu['b_GS'];assert s.Rational(a['parent_b_one'])/2==s.Rational(gcu['delta_g_over_g_coefficient'])
assert a['light_b_one']==gcu['light_GS_beta']
assert sum(v['dimension'] for v in a['parent_representations'].values())==328
CA=s.Rational(a['parent_CA']);reps=a['parent_representations'];actual=s.Rational(a['parent_c_two']);mutants={}
for name,sec,weight in [('half_complex126','Sigma',s.Rational(1,2)),('omit_one_real10','phi',s.Rational(1,2))]:
    S=sum(s.Rational(v['index'])*(weight if k==sec else 1) for k,v in reps.items());CS=sum(s.Rational(v['index'])*s.Rational(v['Casimir'])*(weight if k==sec else 1) for k,v in reps.items());bb,cc=beta(CA,S,CS)
    assert cc!=actual;mutants[name]={'b_one':str(bb),'c_two':str(cc),'difference':str(cc-actual)}
S=s.Rational(a['parent_real_scalar_index']);CS=s.Rational(a['parent_Casimir_weighted_index']);wrong=sum(s.Rational(v['Casimir']) for v in reps.values())*S/len(reps)
assert wrong!=CS;mutants['average_Casimir_before_index_trace']={'weighted_index_difference':str(wrong-CS)}
matrix=s.Matrix(a['light_c_two_matrix']);diag=s.diag(*[matrix[i,i] for i in range(3)]);change=(matrix-diag)*s.ones(3,1)
assert change[0]!=0 and change[1]!=0 and change[2]==0;mutants['omit_light_cross_group_terms']={'c_two_row_sum_difference':list(map(str,change)),'color_insensitive':True}
g,e,t,x,y=s.symbols('g epsilon ell b c');Z=1+t*x*g**2/(2*e)+t**2*g**4*(3*x**2/(8*e**2)+y/(2*e));bare=g*Z
bad=s.expand(e*bare+(-e*g+t*x*g**3+t**2*y*g**5)*s.diff(bare,g)).coeff(t,2);assert bad!=0
mutants['wrong_two_loop_Zg_factor']={'RG_residual':str(bad)}
h=s.Symbol('h');bad_h=h-t*x/e+t**2*(-y/(2*h*e)+x**2/(h*e**2));bad=s.expand(-2*e*bad_h+(2*e*h-2*t*x-2*t**2*y/h)*s.diff(bad_h,h)).coeff(t,2);assert bad!=0
mutants['spurious_background_double_pole']={'RG_residual':str(bad)}
receipt={'schema':'G2B1_VALIDATION','status':'QUALIFIED_INDEPENDENT_TWO_LOOP_GAUGE_SCALAR_PARENT_AND_LIGHT_RG_COMPARATOR','execution_state':'COMPLETED',
 'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED','parent_scalar_fields':328,'light_scalar_fields':5,
 'parent_b_one':a['parent_b_one'],'parent_c_two':a['parent_c_two'],'parent_real_scalar_index':a['parent_real_scalar_index'],
 'parent_Casimir_weighted_index':a['parent_Casimir_weighted_index'],'light_c_two_matrix':a['light_c_two_matrix'],
 'light_c_two_equal_g_row_sum':a['light_c_two_equal_g_row_sum'],'parent_Lambda_simple_pole':a['parent_Lambda_simple_pole'],
 'light_Lambda_simple_pole':a['light_Lambda_simple_pole'],'parent_minus_light_Lambda_simple_pole':a['parent_minus_light_Lambda_simple_pole'],
 'bare_RG':a['bare_RG'],'negative_controls':mutants,'exact_all_entries_equal':True,'primitive_pole_answers_consumed':False,
 'reference_premise':'Luo-Wang-Xiao hep-ph/0211440v3 Eq30 and semisimple replacement rules; real scalars, MS GS subset',
 'finite_C1_E5_or_physical_matching_qualified':False,'shared_error_limits':['representation/projector/reference premises','published perturbative beta formula','symbolic software','AI authorship'],
 'elapsed_after_imports':time.perf_counter()-start}
print('RESULT '+json.dumps(receipt,sort_keys=True),flush=True)
