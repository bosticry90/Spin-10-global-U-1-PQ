# G2B1: independent two-loop gauge/scalar RG comparator

Qualified by validation_receipt.json SHA256 658ccb86ed02611bd09816471fa4dd942f9099322416762db47a934c8c879d06.
State113/authority34of39 and9/9 primitive-input scope unchanged. Scientific/
director acceptance NOT_PERFORMED. No primitive two-loop pole answer was
consumed by these native derivations.

Qualified actual generator traces and independent Cartan tensor censuses
agree on real scalar index84, Casimir-weighted index1004 and adjointCA8.
The GS beta coefficients in beta(g)=ell*b*g³+ell²*c*g5 are
 b=-46/3, c=4520/3.
All328 real scalar directions are counted, including the complex126 as
252 real directions and complex10 as20. Fermions/Yukawas remain outside
this declared loop subset and human-paused research is not resumed.

The actual soft5 projector/class traces and independent real Higgs-doublet
matrices give the light GS two-loop coefficient matrix
 [[9/50,9/10,0],[3/10,-259/6,0],[0,0,-102]].
At symbolic tree-equal gauge couplings its row sums are
 (27/25,-643/15,-102). Mixed U1/SU2 terms are necessary. No physical gauge
coupling or finite normalization was selected.

Independent bare-g and bare-inverse-g² RG derivations give
 Zg=1+ell*g²*b/(2eps)+ell²*g4[3b²/(8eps²)+c/(4eps)],
 ZA=1-ell*g²*b/eps-ell²*g4*c/(2eps).
The two-loop background double pole cancels by the derived coefficients,
not a hand-set condition. Lambda=-12Gamma_F2/(ell²*g²) therefore predicts
parent loop simple pole-2260 and light(-81/50,643/10,153), in unitsg²/eps.
The independent parent-minus-light target is
 (-112919/50,-23243/10,-2413).
This supplies a comparator, not a measured nine-family pole result or an
adopted physical overall subtraction.

Primary2.7413856s/replay.9554878s/verifier.8020028s after imports;2545 initial
bindings. All3 workers COMPLETED within600s/8GiB sampled/350MiB launch/
12MiB package; no science failure or incomplete run. Exact full entry/RG
agreement and sensitive representation/mixed-group/factor2 controls pass.
Shared representation/projector premises, published perturbative MS formula,
SymPy and AI authorship remain limits; this is not external confirmation.

The reference premise is Luo-Wang-Xiao hep-ph/0211440v3 Eq30 and Eq106-110,
with its real-scalar convention. It does not certify applicability of the
entire finite heat/regulator/physical matching construction. Next compare
the COMPLETE original-forest nine-family Laurent sum with this independent
target, retaining light-internal quartic poles and all EFT contributions.
Full finite C1,E5/A5,scalar quantum control and physical unification remain
unqualified; all historical, protected and paused boundaries stay unchanged.
