# G2B1 independent gauge/scalar two-loop UV comparator

Question: derive the parent and actual light-EFT gauge/scalar beta coefficients
needed to test the complete nine-family Laurent assembly. This calculation
does NOT read or fit the nine-family two-loop pole sum. Reuse qualified GCU1
group-index/Casimir matrices, S4P class Casimirs and FCI soft projectors.
Previous turn PROGRESS: complete S3M/U/A, all9 primitive inputs. Current
preflight clean main d6a2d238e24b37a8715938728e06d23a8b8a66b8, no matching
live workers. Existing QUS1 already measures the quartic UV pole insertion;
do not repeat it or silently call that isolated diagnostic a physical CT.

Domain: actual normalized Spin(10) adjoint45 and scalar real dimensions
54+252+20+2, with the existing complex126 and complex10 realification.
No fermion/Yukawa loops; this is the active GS subset, not a claim that
the physical model lacks fermions. Actual light content is the qualified
soft rank5 (complex Higgs doublet plus neutral PQ scalar) and the actual
normalized H12 gauge embedding. Do not substitute full-SM fermionic beta
coefficients or change charges/finite physical conditions.

Use Luo-Wang-Xiao hep-ph/0211440v3 Eq30, real-scalar convention, and its
semisimple extension: in beta_i=g_i^3*b_i/(16pi²)+
g_i^3*sum_j c_ij*g_j²/(16pi²)²,
 b=-11*CA/3+S/6,
 c_parent=-34*CA²/3+CA*S/3+2*sum_R C_R*T_R,
 c_ij=2*Tr_light[-rho_i²*C_j]+delta_ij*(CA_i*S_i/3-34*CA_i²/3).
Here i is a normalized single probe, C_j is the full ideal Casimir, not
its single-probe average. This makes offdiagonal gauge-group terms explicit.
The tree matching comparison uses symbolic equal g_i=g10, not a selected
physical value. Literature applicability is a stated perturbative MS
premise; it does not certify this model's finite heat/matching prescription.

Primary uses qualified actual full-generator index matrices and Casimirs,
plus all35 exact soft-projector/class traces and actual restricted fH.
Replay counts normalized Cartan weights of Sym²0(10),Lambda5(10),two10s,
two neutral real singlets and Lambda²(10) adjoint. Its light coefficients
come from explicit complex Higgs-doublet/Pauli matrices realified to4
directions plus the neutral fifth, and SU(N) adjoint root weights.
Compare every parent invariant and full3x3 light beta matrix exactly.
All previously qualified mass/point data stay fixed; no primitive answer
is imported as a normalization target.

Independently derive two-loop bare coupling/field pole relations. Primary
solves mu*d(gB)/dmu=0 with formal b,c and Zg through two loops, then applies
the already qualified background relation ZA=Zg^-2. Replay solves the
inverse-coupling bare relation directly. Check all double/simple-pole
coefficients; do not force a background double pole to zero. Convert the
loop pole to Lambda=-12Gamma_F2/(ell²*g10²) from these equations.
This gives an independent parent-minus-light UV target, not an adopted
overall counterterm or an inference that finite C1 has been constructed.

Sensitive controls: half complex126, omitted second real10, scalar Casimir
averaging before trace, omitted offdiagonal light gauge terms, wrong
coupling factor2 and spurious background double pole. Any exact invariant,
matrix, realification, factor/sign or bare-RG disagreement bars qualification.
Possible outcomes: qualified comparator, discrepancy or underdefinition.
No physical input or loop coefficient may be chosen to make a pole cancel.

Freeze sources/qualified inputs before sequential600s workers/8GiB sampled
private/350MiB launch/12MiB package. Preserve complete failures/captures;
resource exhaustion is incomplete, sampled memory not a continuous peak.
Compare completed native outputs before separate validation or dependent
assembly. State113/authority34of39, inventory9/9 INPUTS unchanged; full
C1/E5/A5/physical matching unqualified. No protected activation, flavor
resumption, scheme/point/foundation adoption, publication or remote action.
Shared action/representations/reference, published beta premise, symbolic
software and AI authorship limit independent assurance. TrackB tests a
blind representation/RG comparator, not another benchmark platform;
director education remains voluntary/nonblocking.
