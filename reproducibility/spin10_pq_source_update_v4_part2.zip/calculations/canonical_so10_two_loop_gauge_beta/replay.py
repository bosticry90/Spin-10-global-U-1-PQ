"""G2B1 independent Cartan census, real Higgs matrices and inverse-coupling RG."""
from data import *
start=begin();save('replay',calculate('replay'),start)
