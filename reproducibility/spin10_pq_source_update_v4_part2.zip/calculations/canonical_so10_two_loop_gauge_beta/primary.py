"""G2B1 qualified actual representation matrices and exact soft-class traces."""
from data import *
start=begin();save('primary',calculate('primary'),start)
