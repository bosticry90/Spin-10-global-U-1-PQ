"""G2B1 exact group traces, light scalar domain and independent RG algebra."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations,combinations_with_replacement
import json,gzip,sys,time,threading,os
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_finite_counterterm_insertion'))
from geometry_v2 import red,zero,dec,tidy
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def begin(prep='preparation.json'):
    start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for p,h in json.loads((HERE/prep).read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
    return start
def save(role,v,start):
    raw=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/f'{role}_tables.json.gz').open('xb') as f:f.write(blob)
    print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':time.perf_counter()-start,'tables_sha256':sha256(raw).hexdigest(),
      'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)
def enc(M):return [[str(z) for z in row] for row in M.tolist()]
def beta(CA,S,CS):return s.expand(-11*CA/3+S/6),s.expand(-s.Rational(34,3)*CA**2+CA*S/3+2*CS)
def beta_matrix(CA,S,K):
    return s.Matrix(3,3,lambda i,j:2*K[i,j]+(CA[i]*S[i]/3-s.Rational(34,3)*CA[i]**2 if i==j else 0))

def parent_primary():
    d=packed(CAL/'canonical_so10_gauge_coupling_uv/primary_tables.json.gz');out={}
    for name,size in d['real_scalar_dimensions'].items():
        T=s.Rational(d['indices'][name]);C=s.Rational(d['Casimirs'][name]);zero(dec(d['index_matrices'][name])-T*s.eye(45));assert 45*T==size*C
        out[name]={'dimension':size,'index':str(T),'Casimir':str(C)}
    CA=s.Rational(d['Casimirs']['adjoint']);zero(dec(d['index_matrices']['adjoint'])-CA*s.eye(45))
    return out,CA
def parent_replay():
    weights=[1/s.sqrt(2),-1/s.sqrt(2)]+[s.S.Zero]*8
    sym=[weights[i]+weights[j] for i,j in combinations_with_replacement(range(10),2)];sym.remove(s.S.Zero)
    ext=[sum(weights[i] for i in ids) for ids in combinations(range(10),5)]
    reps={'Phi':sym,'Sigma':ext,'phi':weights*2,'S':[s.S.Zero]*2};out={}
    for name,qs in reps.items():
        T=s.simplify(sum(q*q for q in qs));C=s.Rational(45,len(qs))*T;out[name]={'dimension':len(qs),'index':str(T),'Casimir':str(C)}
    CA=s.simplify(sum((weights[i]+weights[j])**2 for i,j in combinations(range(10),2)))
    return out,CA

def light_primary():
    frame=packed(CAL/'canonical_so10_scalar_sm_frame/primary_tables.json.gz');fci=packed(CAL/'canonical_so10_finite_counterterm_insertion/primary_v3_tables.json.gz')
    bars=packed(CAL/'canonical_so10_scalar_quartic_charge_projection/primary_tables.json.gz')['class_values'];dims=[1,3,8];S=[s.S.Zero]*3;K=s.zeros(3);rank=0
    for ib,b in enumerate(frame['blocks']):
        P=dec(fci['blocks'][ib]['soft']);zero(P*P-P);zero(P-P.H);n=red(b['dimension']*s.trace(P));rank+=n
        cs=[s.Rational(v[ib]) for v in bars]
        for i in range(3):
            S[i]+=n*cs[i]
            for j in range(3):K[i,j]+=n*cs[i]*dims[j]*cs[j]
    assert rank==5;S=list(map(red,S));K=tidy(K)
    qir=packed(CAL/'canonical_so10_vector_quartic_ir_matching/primary_tables.json.gz');f=qir['restricted_f'];CA=[]
    for h in [0,1,4]:
        A=s.SparseMatrix(12,12,{(c,b):s.sympify(v) for a,b,c,v in f if a==h});CA.append(red(-s.trace(A*A)))
    return S,K,CA
def light_replay():
    I=s.I;pauli=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-I],[I,0]]),s.diag(1,-1)]
    def realify(H):
        A=I*H;R=A.applyfunc(s.re);J=A.applyfunc(s.im);return R.row_join(-J).col_join(J.row_join(R))
    groups=[[realify(s.sqrt(s.Rational(3,5))*s.eye(2)/2)],[realify(A/2) for A in pauli],[]]
    Cas=[-sum((A*A for A in row),s.zeros(4)) for row in groups];probes=[groups[0][0],groups[1][0],s.zeros(4)]
    S=[s.simplify(-s.trace(A*A)) for A in probes];K=s.Matrix(3,3,lambda i,j:s.simplify(-s.trace(probes[i]*probes[i]*Cas[j])))
    CA=[s.S.Zero]
    for N in [2,3]:
        q=[s.Rational(1,2),-s.Rational(1,2)]+[s.S.Zero]*(N-2);CA.append(sum((a-b)**2 for i,a in enumerate(q) for j,b in enumerate(q) if i!=j))
    return S,K,CA

def coupling_primary():
    g,e,t,b,c,A,B,C=s.symbols('g epsilon ell b c A B C');Z=1+t*A*g**2/e+t**2*g**4*(B/e**2+C/e);bare=g*Z
    residual=s.expand(e*bare+(-e*g+t*b*g**3+t**2*c*g**5)*s.diff(bare,g))
    Avalue=s.solve(residual.coeff(t,1),A)[0];r=s.expand(residual.coeff(t,2).subs(A,Avalue));sol=s.solve([r.coeff(e,-1),r.coeff(e,0)],[B,C],dict=True)[0]
    field=s.series(Z.subs({A:Avalue,**sol})**-2,t,0,3).removeO().expand()
    # Gamma_CT=ZA_two*F²/4, Lambda_CT=-12Gamma_CT/g²;
    # the cancelling loop coefficient is its opposite.
    loop_ratio=s.simplify(3*e*field.coeff(t,2)/(g**4*c))
    assert s.simplify(field.coeff(t,2)+g**4*c/(2*e))==0
    return {'Zg_one':str(Avalue),'Zg_double':str(sol[B]),'Zg_simple':str(sol[C]),'ZA_one':str(s.expand(field.coeff(t,1)/g**2)),
      'ZA_two':str(s.expand(field.coeff(t,2)/g**4)),'loop_Lambda_pole_over_c':str(loop_ratio),'background_double_pole':'0'}
def coupling_replay():
    h,e,t,b,c,K,L,M=s.symbols('h epsilon ell b c K L M');bare=h+t*K/e+t**2*(L/e**2+M/e)/h
    residual=s.expand(-2*e*bare+(2*e*h-2*t*b-2*t**2*c/h)*s.diff(bare,h));kv=s.solve(residual.coeff(t,1),K)[0]
    r=s.expand(residual.coeff(t,2).subs(K,kv));sol=s.solve([r.coeff(e,-1),r.coeff(e,0)],[L,M],dict=True)[0]
    # hB=(ZA/g²)mu^-2epsilon with h=1/g². Recover Zg=ZA^-1/2 separately.
    ZA=1+t*kv/(h*e)+t**2*(sol[L]/e**2+sol[M]/e)/h**2;Zg=s.series(ZA**(-s.Rational(1,2)),t,0,3).removeO().expand()
    return {'Zg_one':str(s.simplify(Zg.coeff(t,1)*h*e)),'Zg_double':str(s.expand(Zg.coeff(t,2)*h**2).coeff(e,-2)),
      'Zg_simple':str(s.expand(Zg.coeff(t,2)*h**2).coeff(e,-1)),'ZA_one':str(s.expand(ZA.coeff(t,1)*h)),
      'ZA_two':str(s.expand(ZA.coeff(t,2)*h**2)),'loop_Lambda_pole_over_c':str(s.simplify(3*sol[M]/c)),'background_double_pole':str(sol[L])}

def calculate(role):
    reps,CA=(parent_primary if role=='primary' else parent_replay)();S=sum(s.Rational(v['index']) for v in reps.values());CS=sum(s.Rational(v['index'])*s.Rational(v['Casimir']) for v in reps.values());b,c=beta(CA,S,CS)
    ls,K,la=(light_primary if role=='primary' else light_replay)();matrix=beta_matrix(la,ls,K);light=matrix*s.ones(3,1);lb=[-s.Rational(11,3)*a+v/6 for a,v in zip(la,ls)]
    targets=-s.Rational(3,2)*(c*s.ones(3,1)-light);rg=(coupling_primary if role=='primary' else coupling_replay)()
    return {'schema':'G2B1_GROUP_RG_COMPARATOR','parent_representations':reps,'parent_CA':str(CA),'parent_real_scalar_index':str(S),'parent_Casimir_weighted_index':str(CS),
      'parent_b_one':str(b),'parent_c_two':str(c),'light_CA':list(map(str,la)),'light_real_scalar_index':list(map(str,ls)),
      'light_Casimir_cross_trace':enc(K),'light_b_one':list(map(str,lb)),'light_c_two_matrix':enc(matrix),'light_c_two_equal_g_row_sum':list(map(str,light)),
      'parent_minus_light_Lambda_simple_pole':list(map(str,targets)),'parent_Lambda_simple_pole':str(-s.Rational(3,2)*c),
      'light_Lambda_simple_pole':list(map(str,-s.Rational(3,2)*light)),'bare_RG':rg,
      'primitive_two_loop_pole_answers_consumed':False,'finite_counterterm_or_C1_qualified':False}
