# Primary-source comparator

M. Luo, H. Wang and Y. Xiao, *Two-loop Renormalization Group Equations in
General Gauge Field Theories*, Phys.Rev.D67,065019(2003),
[arXiv hep-ph/0211440v3](https://arxiv.org/pdf/hep-ph/0211440v3), Eq30
and sectionVI (semisimple groups). Retrieved2026-10-21.

The paper defines real scalar generators and their index/Casimir traces,
then gives perturbative dimensional-regularization/MS gauge beta functions.
For the present GS subset retain gauge and real-scalar terms, without
fermion or Yukawa contributions. For product groups the scalar Casimir
term resolves into a sum over gauge factors, including mixed terms.
The calculation separately derives our field counts, normalization and
background-pole conversion. Applying this published perturbative formula
is a declared reference premise, not proof of finite regulator equivalence
or acceptance of the unfinished Spin(10) physical model.
