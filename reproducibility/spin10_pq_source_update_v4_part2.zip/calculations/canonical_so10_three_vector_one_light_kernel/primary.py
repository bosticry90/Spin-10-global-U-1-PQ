"""V3L1 integrate light time first and reduce exact shifted gamma ratios."""
from data import *
def gamma_ratio(value):
    bases={-1:s.Symbol('Gminus'),1:s.Symbol('Gplus'),2:s.Symbol('Gdouble')};replacements={}
    for atom in value.atoms(s.gamma):
        arg=s.expand(atom.args[0]);nn=arg.subs(eps,0);cc=s.diff(arg,eps)
        assert nn.is_Integer and cc in bases
        factor=s.prod(k+cc*eps for k in range(1,int(nn))) if nn>=1 else 1/s.prod(k+cc*eps for k in range(int(nn),1))
        replacements[atom]=bases[cc]*factor
    value=clean(value.xreplace(replacements)/bases[1]**2);assert not value.has(*bases.values(),s.gamma)
    return value
def integrate(P,early=False):
    poly=s.Poly(clean(P*U**2),*times);rows=[];ratio=0;beta=4-eps
    for (ii,jj,kk),co in poly.terms():
        assert ii+jj+kk==5
        cf=co.subs(D,4 if early else 4-2*eps);A=ii+jj+2-beta;B=ii+kk+2-beta
        term=cf*s.gamma(ii+1)*s.gamma(beta-ii-1)/s.gamma(beta)*s.gamma(2*eps)*s.gamma(A)*s.gamma(B)/s.gamma(A+B)
        ratio+=gamma_ratio(term);rows.append({'powers':[ii,jj,kk],'coefficient_D':str(co)})
    ratio=clean(ratio);val=s.series(ratio,eps,0,1).removeO().expand();jets=[clean(val.coeff(eps,k)) for k in [-2,-1,0]]
    # exp(2gamma eps)Gamma(1+eps)^2=1+zeta(2)eps²+O(eps³).
    jets[2]=clean(jets[2]+s.zeta(2)*jets[0]);assert s.limit(eps**2*ratio,eps,0).is_finite
    return rows,ratio,jets
def main():
    start=begin();out={};forests=packed(CAL/'canonical_so10_three_vector_uv_forests/primary_tables.json.gz')['axes']
    for i,P in enumerate(heat_axes()):
        rows,ratio,bb=integrate(P);unused,wrong_ratio,wrong=integrate(P,True)
        ff=[s.S.Zero]*3 if i==0 else [clean(expr(v).subs({x:0,y:1,z:1})) for v in forests[str(i)]['prefactor']]
        rr=list(map(clean,[a+b for a,b in zip(bb,ff)]));scaled=[rr[0],clean(rr[1]+j*(2*bb[0]+ff[0])),clean(rr[2]+j*(2*bb[1]+ff[1])+j*j*(2*bb[0]+ff[0]/2))]
        out[str(i)]={'terms':rows,'rational_Gamma_ratio':str(ratio),'hard_bare_Q1':list(map(str,bb)),
          'hard_forest_Q1':list(map(str,ff)),'hard_Rprime_Q1':list(map(str,rr)),'hard_Rprime_scale':list(map(str,scaled)),
          'early_D4_change':list(map(str,[clean(a-b) for a,b in zip(wrong,bb)]))}
        print('STAGE exact_hard_region_axis_'+str(i),flush=True)
    save('primary',{'schema':'V3L1_PRIMARY','light_edge':0,'heavy_masses':[1,1],'axes':out,
      'soft_matching_qualified':False,'light_closing_CT_retained_for_soft_matching':True},start)
if __name__=='__main__':main()
