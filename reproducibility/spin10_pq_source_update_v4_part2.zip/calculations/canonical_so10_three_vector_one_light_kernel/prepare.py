"""V3L1 freeze exact action/projector ancestry and all source bytes."""
from pathlib import Path
from hashlib import sha256
import json,ast,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
BASE='101526af31d43ad5d851fd9174f7585395cb9b51'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/three-vector-one-light-kernel-v1-2026-10-21')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='main'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT).strip()
def dump(p,b):
    with p.open('xb') as f:f.write(b)
deps={};cache={};qualified={}
for folder,receipt,want,wantsha in [('canonical_so10_three_vector_uv_forests', 'validation_receipt.json', 'QUALIFIED_ORIGINAL_CUBIC_VECTOR_UV_OPERATORS_AND_POSITIVE_MASS_PROPER_FOREST', '640e8e187c8acfea99762651e163c82cefba34e8db42daf78cdbcc1d5a8d9bb8'), ('canonical_so10_three_vector_heat_kernel', 'validation_receipt.json', 'QUALIFIED_FULL_ORDERED_THREE_VECTOR_GENERAL_D_BARE_F2_HEAT_KERNEL', 'b2f9c8b63350f586702d3b6e680ab9246f5fc2ca766661c490971c4d289a79a9'), ('canonical_so10_mixed_scalar_soft_matching', 'validation_receipt_v2.json', 'QUALIFIED_MIXED_SINGLE_SOFT_MATCHING_AND_ONE_MASSLESS_CURRENT_KERNEL', 'e70dbe69b3fdc710109b04203625f81badecd98f001842641e575951ef8ab6c9'), ('canonical_so10_charged_light_vector_matching', 'validation_receipt.json', 'QUALIFIED_CHARGED_LIGHT_VECTOR_MATCHING_KERNEL', 'c0b9d1f59ff1199f7909474dbeae4896ce17a17ca3af6121bfdf1a49c5e9ae57')]:
    parent=ROOT/'calculations'/folder
    for prep in sorted(parent.glob('*preparation*.json')):
        for n,h in json.loads(prep.read_bytes())['input_sha256'].items():
            if n not in cache:cache[n]=sha256(Path(n).read_bytes()).hexdigest()
            assert cache[n]==h,n
            if n in deps:assert deps[n]==h,n
            deps[n]=h
    for p in sorted(parent.iterdir()):
        if p.is_file():deps[str(p)]=sha256(p.read_bytes()).hexdigest()
    p=parent/receipt;v=json.loads(p.read_bytes())
    if want:assert v['status']==want
    if wantsha:assert sha256(p.read_bytes()).hexdigest()==wantsha
    qualified[folder+'/'+receipt]=sha256(p.read_bytes()).hexdigest()
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V427.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md']:
    p=ROOT/n;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
    p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw,n
    if p.suffix=='.py':ast.parse(raw,filename=str(p))
    cp=HERE/(n+'.source.txt');dump(cp,raw);deps[str(p)]=deps[str(cp)]=sha256(raw).hexdigest()
state='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
old=subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT);assert len(old.splitlines())==27042
CONTROL.mkdir(parents=True,exist_ok=False);dump(CONTROL/'old_git_tree.txt',old)
v={'schema':'V3L1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(deps.items())),
 'qualified_receipts':qualified,'old_blobs':27042,'seconds_each':600,'sampled_private_cap':8*1024**3,
 'launch_floor':350*1024**2,'whole_package_bytes':6*1024**2,'state_sha256':state,'scientific_acceptance':'NOT_PERFORMED'}
dump(HERE/'preparation.json',(json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
print('FROZEN',len(deps),'bindings;27042oldblobs;no science executed',flush=True)
