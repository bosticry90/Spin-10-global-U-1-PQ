# V3L1 prospective beta and projective derivations

For each monomial c(D)s^i t^j u^k in P2 U2, i+j+k=5,
U=st+su+tu, beta=D/2+2=4-eps. Set light mass on s to0 and heavy squared
masses to1. Integrate s first using the beta function, then t=T v,
u=T(1-v). The result for this monomial is

 c(4-2eps) exp(2gammaEeps) Gamma(i+1)Gamma(beta-i-1)/Gamma(beta)
 *Gamma(2eps)Gamma(i+j+2-beta)Gamma(i+k+2-beta)
 /Gamma(2i+j+k+4-2beta).

This equality first holds in the convergence domain for analytically
continued exponents and extends meromorphically. It is not a convergent
massless proper-time integral at every physical eps. Integer shifts reduce
the complete gamma quotient to Gamma(1+eps)2 times a rational function.
Evaluate Laurent terms through eps0 after including the full c(D).

For a separate derivation set total time T=s+t+u, heavy fraction v=(t+u)/T,
and w=t/(t+u). Then(s,t,u)=T(1-v,vw,v(1-w)),Jac=T2 v and
U=T2 v[1-v(1-w+w2)]. The radial integral gives Gamma(2eps)v^(-2eps).
The v beta integral has A=3-i-eps and A+i+1=beta, so its hypergeometric
factor reduces to[w(1-w)]^(-A). The remaining w integral gives
Gamma(j-A+1)Gamma(k-A+1)/Gamma(j+k-2A+2). This independently reconstructs
the same gamma expression. Replay uses it without rationalizing/expanding
the gamma factors, and extracts eps2*kernel by Cauchy integration.

The heavy forest follows from the already derived V3U original proper CTs:
on a heavy-closing edge v=1 the other masses are0,1. The light-closing
edge has no hard scale in its remaining loop and is entirely soft under
the same inherited dimensional-region operation. Preserve its actual
regulated trace for the subsequent full/EFT subtraction; do not set it0
in the original positive-mass formula. The hard forest retains all its
eps-positive factors and exp(eps*j); bare hard kernel scales exp(2eps*j).
No conclusion about the fully matched finite amplitude follows until the
actual soft terms and positive-mass asymptotic agreement are established.
