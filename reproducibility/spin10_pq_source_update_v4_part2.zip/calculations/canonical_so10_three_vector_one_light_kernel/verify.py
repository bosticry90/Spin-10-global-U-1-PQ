"""V3L1 full ordered hard-region evidence; no complete soft claim."""
from data import *
import mpmath as mp
def main():
    start=begin('validation_preparation.json');mp.mp.dps=100
    A,B=[packed(HERE/f'{r}_tables.json.gz') for r in ['primary','replay']];error=mp.mpf(0);controls={}
    assert not B['primary_Laurent_fields_read']
    axes=heat_axes()
    from itertools import permutations
    for p in permutations(range(3)):
        substitution={times[i]:times[p[i]] for i in range(3)}
        for i in range(3):assert clean(axes[i].xreplace(substitution)-axes[p[i]])==0
    for i in range(3):
        row=A['axes'][str(i)]
        for exact,measured in zip(row['hard_bare_Q1'],B['jets'][i]):
            value=mp.mpf(str(s.N(expr(exact),105)));error=max(error,abs(value-mp.mpf(measured))/(1+abs(value)))
        # Early Lorentz-dimension specialization must be visibly nontrivial.
        change=list(map(expr,row['early_D4_change']));assert any(q!=0 for q in change)
        bb,ff,rr=[list(map(expr,row[k])) for k in ['hard_bare_Q1','hard_forest_Q1','hard_Rprime_Q1']]
        assert all(clean(a+b-c)==0 for a,b,c in zip(bb,ff,rr))
        if i>0:assert any(q!=0 for q in ff)
        else:assert all(q==0 for q in ff)
        jj=s.Symbol('j',real=True);vals=[s.sympify(q,locals={'j':jj}) for q in row['hard_Rprime_scale']]
        expected=[rr[0],rr[1]+jj*(2*bb[0]+ff[0]),rr[2]+jj*(2*bb[1]+ff[1])+jj*jj*(2*bb[0]+ff[0]/2)]
        assert all(clean(a-b)==0 for a,b in zip(vals,expected))
        controls[str(i)]={'early_D4':list(map(str,change)),'missing_hard_forest':list(map(str,[-q for q in ff])),
          'hard_forest_omission_insensitive':i==0,'missing_quadratic_scale':str(clean(-jj*jj*(2*bb[0]+ff[0]/2)))}
    assert error<mp.mpf('1e-35')
    native=[]
    for role in ['primary','replay']:
        c=json.loads((HERE/f'{role}_capture.json').read_bytes());r=json.loads((HERE/f'{role}_result.json').read_bytes());blob=(HERE/f'{role}_tables.json.gz').read_bytes()
        assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
        assert sha256(blob).hexdigest()==r['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['tables_sha256']
        peak=max(v['private_bytes'] for v in c['all_resource_samples']);assert peak<8*1024**3 and c['launch']['memory']['available_pagefile']>=350*1024**2 and r['elapsed_after_imports']<600
        native.append({'role':role,'seconds':r['elapsed_after_imports'],'sampled_private_max':peak})
    assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<6*1024**2
    out={'schema':'V3L1_VALIDATION','status':'QUALIFIED_EQUAL_HEAVY_ONE_LIGHT_THREE_VECTOR_HARD_REGION','execution_state':'COMPLETED',
      'exact_axes':A['axes'],'projective_Cauchy_error':mp.nstr(error,45),'Cauchy_refinement':B['maximum_scaled_refinement'],
      'imaginary_leak':B['imaginary_leak'],'controls':controls,'all_six_placements_by_exact_kernel_symmetry':True,
      'hard_proper_forests_qualified':True,'complete_soft_matching_qualified':False,'VVV_model_amplitude_calculated':False,
      'primitive_amplitude_inventory':6,'full_C1_or_E5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED',
      'shared_limits':['V3K ordered heat numerator','meromorphic dimensional-region prescription','V3U proper forests','special-function software','AI authorship'],
      'native_runs':native,'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
if __name__=='__main__':main()
