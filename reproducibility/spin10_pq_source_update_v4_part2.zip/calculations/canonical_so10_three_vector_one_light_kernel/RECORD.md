# V3L1 — equal-heavy one-light hard region

Question: what is the complete meromorphic hard-region kernel for the actual
V3K numerator at squared masses(0,1,1), and its original hard proper forest?
V3S shows that all supported mixed-light orbits are equal-heavy. This supplies
a necessary matching input. It does not alone establish the soft subtraction.

Freeze actual three charge axes, ordered general-D numerator, xi1 C1 F2
convention and real-vector normalization. Positive heavy scale M>0 is factored
out; j=log(Q2/M) is symbolic. No physical scale/coupling is selected. The
massless line is a meromorphically continued HARD REGION, not deletion of
the regulated light propagator from the full amplitude. Common-delta full/EFT
matching and opened-heavy-loop soft terms remain unqualified.

Primary integrates the light Schwinger time first, then radial and beta
integrals; reduces integer-shift gamma ratios exactly before expansion.
Replay starts from total radial time and the heavy fraction; its v integral
has 2F1(beta,A;beta;c)=(1-c)^(-A), followed by another beta integral.
Replay numerically extracts the full unexpanded gamma expression by complex
Cauchy coefficients, not primary Laurent arrays. Both share the actual heat
numerator and established meromorphic region prescription; this is not a
second physics derivation or a proof of complete infrared matching.

Retain D=4-2eps before all integrals. Show term degrees and transformed
Jacobian identities. Keep double poles, finite constants and quadratic scale
logs. Hard proper CTs are the V3U heavy-closing edges at x0=0; the light-
closing forest belongs entirely to the soft region in this dimensional
hard expansion. Its actual common-delta trace is NOT declared zero. No
parent forest, finite parameter jets or background overall CT is supplied.

Validation compares every Laurent coefficient against110-digit Cauchy
results, node/radius refinements, all three placements by exact time/axis
permutation, early-D4 sensitivity and forest omission. Pole values are output,
not a target for fitting. Failure/inconclusive outcomes preserved exactly.
Sequential600s/worker,8GiB sampled private,350MiB launch,6MiB package.
Qualification only for the specified hard-region calculation; director
acceptance NOT_PERFORMED,authority34/39 unchanged,6/9 amplitude inventory.
Next independently derive the regulated opened-heavy-loop soft response and
compare with the positive-mass limit, then perform complete model VVV sum.
