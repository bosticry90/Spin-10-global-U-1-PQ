# V3L1: complete equal-heavy one-light hard-region input

Qualified by validation_receipt.json, SHA256
d6659ecb0f91e0d3a20506d47a4bbb3d0a2f46a9288a0b7ac212b29182cfe10e.
Scientific acceptance NOT_PERFORMED; state113/authority34of39 unchanged.
This is a meromorphic hard region and original hard proper forest, NOT
complete common-delta matching or a finished VVV model amplitude.

At squared masses(0,1,1), the bare double/simple/finite arrays are

| Charge axis | Bare array | Hard proper forest |
| --- | --- | --- |
| Light | (-12,23/2,-2pi2-53/4) | (0,0,0) |
| Each heavy | (12,-16,2pi2-31/4) | (-24,157/6,23/9) |

Here pi2 means pi squared. The resulting hard Rprime arrays are
light(-12,23/2,-2pi2-53/4), heavy(-12,61/6,2pi2-187/36).
They are not final matched threshold coefficients. Light-closing CT0 in
this hard-region operation does not set the actual regulated light trace0.
That trace belongs to the independently required soft/EFT subtraction.

With j=log(Q2/M), finite hard Rprime is
light:-24j2+23j-2pi2-53/4,
heavy:12j2-35j/6+2pi2-187/36.
The light-axis simple pole also changes by-24j. These are meromorphic
hard-region scale effects, not evidence of a physical anomaly. Do not
replace them by the positive-mass pole or a guessed scale-independent value.

The primary integrates light time first and reduces shifted gamma functions
to rational ratios. Replay changes to total time/heavy fraction/relative
heavy time, proves the Jacobian and hypergeometric reduction, and evaluates
the unexpanded gamma expression by Cauchy coefficient extraction. It never
reads primary Laurent fields. All three coefficients agree on every axis;
scaled error5.963292e-73, node/radius refinement3.0963183e-39, imaginary
leak1.9793272e-108 at110 working digits. Six time/charge permutations give
every light placement. Heavy interchange is exact. Early-D4 changes simple
poles by-35/4(light),+35/4(heavy), and changes finite constants; the actual
general-D numerator was retained before integration.

Primary5.7166778s/replay8.5995413s/validation1.1197233s after imports;
sampled native private maxima53,645,312/49,827,840 bytes. All under frozen
600s/8GiB sampled/350MiB launch/6MiB package. No failed native run, timeout,
cancellation or output truncation.3686 initial bindings and all sources
were frozen before execution. Sources used prepare.py then run.py.

Both routes share V3K's ordered numerator and the dimensional meromorphic
region assumptions; they are two integral representations of that input,
not independent scientific validation of the action. V3U original forests,
special-function software and AI authorship are also shared. No physical
scale/coupling, new subtraction scheme or finite physical jets were adopted.
The two supplied heavy masses1 are dimensionless normalization by a symbolic
positive squared mass M, not a new benchmark. Amplitude inventory remains6/9.

Next derive the heavy-loop soft local mass, kinetic, longitudinal and FQQ
finite coefficients before reading a needed positive-minus-hard remainder.
Close the actual regulated light vector with those coefficients and its
original CT. Test the complete common-delta asymptotic equality against the
qualified positive-mass kernel. The nonzero light-axis pole/scale terms make
this a sensitive check. Only then qualify the matched kernel, account for
the all-light H EFT primitive, and sum the actual three all-heavy and three
mixed-light supported model orbits once.
