"""V3L1 radial-projective gamma integrals, unexpanded Cauchy coefficients."""
from data import *
import mpmath as mp
def main():
    start=begin();mp.mp.dps=110;axes=heat_axes();terms=[]
    v,w,T,beta=s.symbols('v w T beta',positive=True)
    trans={st:T*(1-v),tt:T*v*w,ut:T*v*(1-w)}
    jac=s.det(s.Matrix([[s.diff(trans[t],vv) for vv in [T,v,w]] for t in times]))
    assert clean(jac+T*T*v)==0 # Reversed orientation; positive measure is -Jac.
    assert clean(U.subs(trans)-T*T*v*(1-v*(1-w+w*w)))==0
    for P in axes:
        terms.append([(powers,s.Poly(co,D)) for powers,co in s.Poly(clean(P*U**2),*times).terms()])
    def evaluate(e):
        beta=4-e;values=[];gammas={}
        for rows in terms:
            total=mp.mpc(0)
            for (ii,jj,kk),co in rows:
                assert ii+jj+kk==5
                aa=3-ii-e
                assert abs(aa+ii+1-beta)<mp.mpf('1e-100')
                key=(ii,jj,kk)
                if key not in gammas:
                    # Independent total-radial T, heavy fraction v, then w.
                    gammas[key]=mp.gamma(2*e)*mp.gamma(aa)*mp.factorial(ii)/mp.gamma(beta)*mp.gamma(jj-aa+1)*mp.gamma(kk-aa+1)/mp.gamma(jj+kk-2*aa+2)
                cv=sum(mp.mpf(int(s.numer(cc)))/int(s.denom(cc))*(4-2*e)**power[0] for power,cc in co.terms())
                total+=cv*gammas[key]
            values.append(mp.exp(2*mp.euler*e)*e*e*total)
        return values
    history=[];previous=None;last=None;refinement=mp.mpf(0);leak=mp.mpf(0)
    for nodes,den in [(32,32),(48,32),(48,64)]:
        radius=mp.mpf(1)/den;totals=[[mp.mpc(0) for k in range(3)] for i in range(3)]
        for n in range(nodes):
            angle=2*mp.pi*n/nodes;phase=mp.exp(1j*angle);values=evaluate(radius*phase)
            for i,value in enumerate(values):
                for k in range(3):totals[i][k]+=value/phase**k
        vals=[[q/(nodes*radius**k) for k,q in enumerate(row)] for row in totals]
        if previous is not None:
            err=max(abs(a-b)/(1+abs(b)) for row,old in zip(vals,previous) for a,b in zip(row,old));refinement=max(refinement,err);assert err<mp.mpf('1e-35')
        leak=max(leak,max(abs(mp.im(vv))/(1+abs(vv)) for row in vals for vv in row));assert leak<mp.mpf('1e-90')
        history.append({'nodes':nodes,'radius_denominator':den,'hard_bare_jets':[[mp.nstr(mp.re(q),80) for q in row] for row in vals]})
        previous=vals;last=vals;print('STAGE independent_projective_Cauchy_'+str(nodes)+'_'+str(den),flush=True)
    save('replay',{'schema':'V3L1_REPLAY','projective_Jacobian':'T**2*v','history':history,
      'maximum_scaled_refinement':mp.nstr(refinement,45),'imaginary_leak':mp.nstr(leak,45),'digits':110,
      'jets':[[mp.nstr(mp.re(q),80) for q in row] for row in last],'primary_Laurent_fields_read':False},start)
if __name__=='__main__':main()
