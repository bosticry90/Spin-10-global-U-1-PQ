"""TSR1 class-Gram hard kernels, physical charge indices and parameter moments."""
from data import *
start=begin();mp.mp.dps=110;save('replay',calculate('replay'),start)
