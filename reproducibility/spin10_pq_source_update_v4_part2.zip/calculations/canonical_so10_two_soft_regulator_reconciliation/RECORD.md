# TSR1 actual SSS/VSS two-soft reconciliation

Question: do the stored proper-subtracted two-soft SSS and VSS kernels use
the independently measured HDM regulator-mass coefficient, with their kinetic,
overlap and ORIGINAL full-class forest terms counted once? This is a required
finite assembly seam, not a new two-loop integral or final C1 calculation.
Base5b04eb18c18f91f8e235723c5e66771d8b907358/main;27966 old tracked blobs.
Whole goal ACTIVE. State113/authority34of39 unchanged; acceptance NOT_PERFORMED.

Domain: unchanged scalar point/frame/projectors, xi1/fixed-v H-background,
common positive auxiliary delta and D=4-2epsilon, g10²>0, heavy squared
masses M>0. ALL23 two-soft/one-physical-heavy scalar source rows, all3
background gauge components, both light charge axes and all4 heavy vector
projectors. Include neutral massive vectors and zero-F²-charge rows; do not
cut off small numeric weights. Reuse qualified exact Gold/all-light cubic
zeros and LGF tree/gauge correspondence. No matter/flavor or HB1/C5 work.

Primary: actual S3M row weights/class charges/axis order and S3A original
forest blueprint; actual SCM VSS left/right/vector charge projections and
stored TSM/NCM/CCK/S3T Laurent/finite prescriptions. Keep source unit signs,
Wick factors, common scale and original forests. Compute the full weighted
two-soft mass, regulator, kinetic and overlap coefficients. No fitting from
the cancellation target or reading the historical physical matching target.

Replay: quadratic hard-kernel matching and light heat response. Use HDM's
completed distinct class-Gram/matrix-function outputs for inverse-mass/log
moments and gauge soft currents. Compute new leading scalar mass/log moments
from full S3G Gram with physical P and P log(H), NOT S3M weights. Derive
the VSS opened mass/kinetic coefficients from elementary parameter moments,
and scalar kinetic from the actual massive/massless bubble parameter integral.
Keep Gamma(1+epsilon) in the light mass response; HDM's original extra-pole
interpretation remains superseded by its immutable V2 correction.

Compare scalar weighted moments and all finite coefficients at1e-45 scaled,
90/110 working digits and60 serialized; exact point-field vector identities
and meromorphic scalar relations at zero tolerance. Stored S3M65digits/
geometry90digits limit numerical assurance; no new interval or exact
transcendental theorem. Validate all native output tables after completion.

Acceptance includes: SSS mixed internal-delta pole opposite double-soft pole;
nonzero overlap log and kinetic term; match actual delta hard mass closure
with HDM; TSM per-axis versus NCM two-axis finite/pole/scale identity; VSS
regulator+kinetic split reconstructs actual scalar forests; neutral-vector
term retained; charged vector forest epsilon finite piece and19/18 retained;
S3A original full forest coefficients agree on every selected class/mode/axis
and both stored g² cases. The original heavy-closing scalar forest is kept,
even where a light hard-region forest is scaleless. Cparent-Cfull uses that
original forest, not an IR-matched residue. Test a labelled independent
parent polynomial to catch missing/doubled subtractions. This ownership
test does not determine the numerical full parent finite normalization.

Controls omit HDM b_delta, scalar overlap or scalar kinetic, the neutral
vector, scalar charge axes, original forests or vector evanescence; report
insensitive components rather than pretending every control tests every
error. Preserve exact signs, finite constants and old failures. No large
loop/tensor replay is justified; cached qualified units are authenticated,
not newly independently integrated. Distinct implementations share physical
premises, software and AI authorship; no external scientist/experiment/Lean.

Freeze input/source bytes first. Sequential600s each native/validation,
8GiB sampled private,350MiB launch floor,24MiB new package. Exhaustion or
failed scientific gate remains incomplete/failure with full captures. No
truncation, scope weakening, refit, physical scheme/point adoption, historical
evidence editing, branch/worktree/reset/amend/push/outreach/publication.

Ceiling: the complete specified SSS/VSS TWO-SOFT coefficient and original
forest reconciliation. Other one-soft kernels, full all-soft gauge/ghost,
hard HTB/finite physical jets, overall-MS and nonlinear C1 conversion still
need their actual common assembly; original RG/gauge/basis/degenerate and
one-loop acceptance gates apply. E5/A5/C1 and physical unification remain
unqualified. Scalar quantum-control/missingYukawa/gauge/quartet/custody
limitations unchanged. Custodyexit2/seven is NOTPASS. TrackB tests actual
cross-representation finite assembly rather than another zero example;
director education voluntary and nonblocking.
