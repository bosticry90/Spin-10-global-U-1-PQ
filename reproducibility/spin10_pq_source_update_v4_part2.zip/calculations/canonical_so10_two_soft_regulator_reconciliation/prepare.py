"""TSR1 exact parent manifest inventories and immutable source freeze."""
from pathlib import Path
from hashlib import sha256
import json,ast,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
BASE='5b04eb18c18f91f8e235723c5e66771d8b907358'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/two-soft-regulator-reconciliation-v1-2026-10-21')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='main'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT).strip()
def dump(p,b):
    with p.open('xb') as f:f.write(b)
parents=[
 ('canonical_so10_hard_delta_matching','validation_receipt_v2.json','QUALIFIED_LINEAR_DELTA_HARD_MASS_MATCH_AND_FINITE_F2_RESPONSE','ea83003375edff8fa212b71047c8c1f2ba915802e5e7201095a5c3585b78bd11',['preparation.json','validation_preparation.json','validation_preparation_v2.json']),
 ('canonical_so10_scalar_cubic_amplitude','validation_receipt.json','QUALIFIED_COMPLETE_SCALAR_CUBIC_MATCHED_PRIMITIVE','298979190845132e09dfcba4a2ac87c8896176a01e965e15310e64958aa5c463',['preparation.json','validation_preparation.json']),
 ('canonical_so10_scalar_two_soft_kernel','validation_receipt_v2.json','QUALIFIED_ONE_HEAVY_TWO_LIGHT_SPINZERO_MATCHED_KERNEL','b59bb2e54291977ee3edb2d1a861233b2b8520c61540e3b36b99913bf1b8ead1',['preparation.json','preparation_v2.json','validation_preparation.json','validation_preparation_v2.json']),
 ('canonical_so10_charged_two_soft_matching','validation_receipt_v2.json','QUALIFIED_CHARGED_TWO_SOFT_CURRENT_MATCHING_KERNEL','6de3332d84485861027265f633395cb6fc9fbf5b9d453d4e6018cb5b3bb559ab',['preparation.json','numeric_preparation.json','validation_preparation.json','validation_preparation_v2.json']),
 ('canonical_so10_neutral_current_matching','validation_receipt_v2.json','QUALIFIED_NEUTRAL_MASSIVE_VECTOR_FULL_SPECTRAL_FUNCTION_AND_ONE_SOFT_MATCHING','508cb3fca421192e2bc022f7757f18aba6eb58a889eef3e88b38f71f6aac572b',['preparation.json','amplitude_preparation.json','validation_preparation.json','validation_preparation_v2.json'])]
deps={};cache={};qualified={}
for folder,receipt,want,wantsha,names in parents:
    P=ROOT/'calculations'/folder;assert {p.name for p in P.glob('*preparation*.json')}==set(names)
    for name in names:
        v=json.loads((P/name).read_bytes());bindings=v.get('input_sha256',v.get('byte_sha256'));assert isinstance(bindings,dict) and bindings
        for n,h in bindings.items():
            n=str((ROOT/Path(n)).resolve())
            if n not in cache:cache[n]=sha256(Path(n).read_bytes()).hexdigest()
            assert cache[n]==h,n
            if n in deps:assert deps[n]==h,n
            deps[n]=h
    for p in P.iterdir():
        if p.is_file():deps[str(p)]=sha256(p.read_bytes()).hexdigest()
    p=P/receipt;v=json.loads(p.read_bytes());assert v['status']==want and sha256(p.read_bytes()).hexdigest()==wantsha
    qualified[folder+'/'+receipt]=wantsha
for name in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V438.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md']:
    p=ROOT/name;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for name in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
    p=HERE/name;raw=p.read_bytes();assert b'\r' not in raw
    if p.suffix=='.py':ast.parse(raw,filename=str(p))
    cp=HERE/(name+'.source.txt');dump(cp,raw);deps[str(p)]=deps[str(cp)]=sha256(raw).hexdigest()
state='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
old=subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT);assert len(old.splitlines())==27966
CONTROL.mkdir(parents=True,exist_ok=False);dump(CONTROL/'old_git_tree.txt',old)
v={'schema':'TSR1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(deps.items())),'qualified_receipts':qualified,'old_blobs':27966,'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'whole_package_bytes':24*1024**2,'state_sha256':state,'scientific_acceptance':'NOT_PERFORMED'}
dump(HERE/'preparation.json',(json.dumps(v,sort_keys=True,indent=2)+'\n').encode());print('FROZEN',len(deps),'bindings;27966 oldblobs;no science executed',flush=True)
