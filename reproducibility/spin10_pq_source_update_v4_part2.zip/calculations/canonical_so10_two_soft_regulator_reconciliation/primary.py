"""TSR1 actual stored charge-axis units and original forest coefficients."""
from data import *
start=begin();mp.mp.dps=90;save('primary',calculate('primary'),start)
