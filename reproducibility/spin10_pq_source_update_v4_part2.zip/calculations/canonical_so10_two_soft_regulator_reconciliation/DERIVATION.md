# TSR1 two-soft terms and forest ownership before limits

Use HDM V2's actual light response tau H_e(delta)/(2delta). For an SSS
spectral row of ordered-axis weight mu*W/2, each light charge axis c_h has
b_h=mu*W*c_h/12. All axes and class orbit factors refer to the ACTUAL
S3M/S3A ordering. Define vector moments W0=sum b_h, Wlog=sum b_h log(M),
W1=sum b_h/M, W1log=sum b_h log(M)/M. Terms below are vectors over the
three gauge components; no gauge coupling is fitted or selected.

For each b,M, S3T's stored light-axis regions are

 leading bare=-b H_M H_d/[delta e(1-e)],
 original light forest=+b H_d/[delta e],
 internal delta=-b H_M H_d/[M e(1-e)],
 double-soft=+b H_d²/[M e(1-e)],
 kinetic finite=-b/(2M).

Leading renormalized term is -b(1+jM)/delta. Internal delta plus double
soft is b log(M/delta)/M: its poles cancel but its logarithm does not.
The scalar bubble's hard derivative -A(M)/M² combined with the loop sign
gives the SAME internal-delta term. HDM and actual row charges must satisfy
W1=(tau_H/2)*a_H, W1log=(tau_H/2)*a_H_logM. The scalar derivative at external
p² gives +H_M/[M(1-e)(2-e)] in the inverse propagator; its finite light
kinetic closure is -W1/2. No early-D4 approximation of the hard two-loop
unit is used; its1/(4M) light-axis value remains inherited from S3T.

The original scalar forest has +mu*W*c_h*H_m/(12m e) on ALL3 axes,
including the heavy closing. S3A's blueprint must reproduce it without
replacing m by a matched light hard-region mass or counting the field-axis
permutations a second time. Neutral F² rows have zero charged projection
but remain in the scalar carrier and HDM PQ mass calculation.

For each heavy-vector sector r let Q1_h,Q2_h,Qv_h be the ACTUAL soft/soft
SCM charge projections. The graph prefactor is3g²/2, the single cut1/6.
Hence w_rh=(Q1_h+Q2_h)/4=(tau_H/2)*x_rH. The exact matrix maps determine
x_rH; r1 and neutral r2 are nonzero, r3/r4 zero in this projection only.

Elementary one-loop parameter moments yield m0/(zBz)=b_delta/Bz=1/(1-e)
and a_p²/Bz=-1/(1-e)-2/(2-e), Bz=H_z/e. The scalar charge soft term is
w_r H_z H_d/e *[z/(delta(1-e))+1/(1-e)+1/(1-e)+2/(2-e)]. Its three groups
are leading mass, internal delta, and minus kinetic. Their original forest
is -w_r H_d/e*[z/delta+3]. After subtraction the finite result is

 w_r * [(z/delta)(1+jz) + (1+jz) + (3/2+2jz)].

This equals the stored TSM two-axis result, and NCM when Q1=Q2 and Qv=0.
The internal-delta term alone agrees with HDM's measured +g² x_rH hard
mass response and finite constant1. Its forest contributes -w_r/e; the
kinetic part contributes -2w_r/e. Testing only their sum would miss an
incorrect redistribution between mass and kinetic insertions.

The remaining charged vector forest has pole-7/6 and finite evanescent
term-1/9 per vector-charge unit at Q²=z. It is retained in the matched
vector unit, whose finite coefficient19/18 and scale1/2 cannot be erased
because scalar soft terms cancel. Other background derivative contributions
obey the qualified TSM/OSF scaling assumptions, not a universal trace rule.

If Cfull denotes ORIGINAL graph forests and Csoft their soft part, the
matched Rprime is Bfull+Cfull-(Sbare+Csoft). Then

 Bfull+Cparent-(Sbare+Csoft)
   = Rprime_matched+(Cparent-Cfull).

The numerical colour/axis coefficients entering Cfull are independently
checked before this bookkeeping identity is used. Matched kernels that
already contain Cfull cannot receive it a second time. A symbolic identity
alone does not determine the full parent counterterm or physical finite jets.
The new result addresses only the named two-soft SSS/VSS families; original
all-family requirements remain. Do not promote a common finite C1 theorem.
