"""TSR1 actual charge-axis versus hard-kernel/heat-response reconciliation."""
from pathlib import Path
from hashlib import sha256
import json,gzip,sys,time,os,threading,importlib.util
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_finite_counterterm_insertion'))
from geometry_v2 import red,tidy,zero,dec,enc,w,point_root,number,numeric,real
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def begin(prep='preparation.json'):
    start=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for p,h in json.loads((HERE/prep).read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
    return start
def q(v):
    a,sep,b=str(v).partition('/');return mp.mpf(a)/mp.mpf(b) if sep else mp.mpf(a)
def fmt(v):return mp.nstr(real(v),60)
def save(role,v,start):
    raw=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/f'{role}_tables.json.gz').open('xb') as f:f.write(blob)
    print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':time.perf_counter()-start,'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)

def scalar_primary():
    src=packed(CAL/'canonical_so10_scalar_cubic_spectral_measure/primary_tables.json.gz');charges=packed(CAL/'canonical_so10_scalar_quartic_charge_projection/primary_tables.json.gz')['class_values']
    masses={m['key']:q(m['reference_mass_squared']) for b in src['blocks'] for m in b['modes'] if m['type']==0};mom=[[mp.mpf(0)]*3 for _ in range(4)];forests=[];rows=[]
    for index,row in enumerate(src['rows']):
        if row['types'].count(1)!=2 or row['types'].count(0)!=1:continue
        ha=row['types'].index(0);M=masses[row['mass_keys'][ha]];pref=q(row['class_orbit'])*q(row['weight'])/12
        rowweights=[]
        for axis,c in enumerate(row['classes']):
            ww=[pref*q(charges[h][c]) for h in range(3)]
            forests.append({'classes':row['classes'],'mode_ids':row['mode_ids'],'axis':axis,'mass_key':row['mass_keys'][axis],'soft':row['types'][axis]==1,'coefficient':list(map(fmt,ww)),'classification':row['classification']})
            if row['types'][axis]!=1:continue
            for h,v in enumerate(ww):
                for k,factor in enumerate([1,mp.log(M),1/M,mp.log(M)/M]):mom[k][h]+=v*factor
            rowweights.append(list(map(fmt,ww)))
        rows.append({'index':index,'M':fmt(M),'light_charge_weights':rowweights,'classification':row['classification']})
    assert len(rows)==23 and len(forests)==69
    return mom,{'rows':rows,'original_forest':forests}

def scalar_replay():
    ASE=module('tsr_ase',CAL/'canonical_so10_all_soft_scalar_tree/data.py');M=module('tsr_gram',CAL/'canonical_so10_scalar_cubic_spectral_measure/data.py')
    frame,fci,PH,PA=ASE.inputs('replay');root=point_root();op=[[],[]]
    for src in fci['blocks']:
        H=numeric(dec(src['H']),root);P=numeric(dec(src['physical']),root);K=H+mp.eye(H.rows)-P;vals,U=mp.eighe(K);assert min(vals)>0
        logH=U*mp.diag([mp.log(z) for z in vals])*U.H;op[0].append(P);op[1].append(P*logH)
    grams=packed(CAL/'canonical_so10_scalar_cubic_class_gram/replay_tables.json.gz');ps=[[numeric(P,root) for P in PH],[numeric(P,root) for P in PA]];ps.append([a+b for a,b in zip(*ps)])
    moments=[];counts=[]
    for ops in op:
        values=[]
        for pp in ps:
            total=mp.mpf(0);count=0
            for g in grams['groups']:
                cls=g['classes'];entries=M.gram_entries(g)
                for axis in range(3):
                    if not dec(fci['blocks'][cls[axis]]['physical']).todok():continue
                    if any(not any(pp[cls[k]]) for k in range(3) if k!=axis):continue
                    args=[pp[c] for c in cls];args[axis]=ops[cls[axis]]
                    total+=mp.mpf(M.orbit(cls))*M.gtrace(entries,args)/3;count+=1
            values.append(real(total));counts.append(count)
        poly=[values[0],values[2]-values[0]-values[1],values[1]];moments.append((poly[0]+poly[1]/2)/4)
    hdm=packed(CAL/'canonical_so10_hard_delta_matching/replay_tables.json.gz')
    for name in ['crossed_A','crossed_A_logM']:
        poly=list(map(q,hdm[name]));moments.append((poly[0]+poly[1]/2)/4)
    return [[z*q(c) for c in ['3/10','1/2','0']] for z in moments],{'class_axis_counts':counts,'S3M_weights_used':False}

def vectors(role):
    if role=='primary':
        src=packed(CAL/'canonical_so10_scalar_current_sm_kernel/primary_tables.json.gz');profiles=[p for p in src['physical_probes']['profiles'] if p['left']==p['right']=='soft' and p['r']>0];assert len(profiles)==4
        out=[]
        for p in sorted(profiles,key=lambda x:x['r']):
            left,right,vec=[[s.sympify(z,locals={'w':w}) for z in p[k]] for k in ['q1_squared','q2_squared','qv_squared']]
            out.append({'r':p['r'],'regulator_weight':[str(red((x+y)/4)) for x,y in zip(left,right)],'left':list(map(str,left)),'right':list(map(str,right)),'vector':list(map(str,vec))})
        return out
    hdm=packed(CAL/'canonical_so10_hard_delta_matching/replay_tables.json.gz');out=[]
    for r,xy in enumerate(hdm['vector_sectors_r0_to_r4'][1:],1):
        x=s.sympify(xy[0],locals={'w':w});out.append({'r':r,'regulator_weight':[str(red(x*c)) for c in [s.Rational(3,10),s.Rational(1,2),0]]})
    return out

def units(role):
    eps,d,j,ld=s.symbols('eps d j ld',real=True);Hz=1+eps*j;Hd=1+eps*(j-ld)
    if role=='primary':
        tsm=packed(CAL/'canonical_so10_charged_two_soft_matching/primary_kernel_tables.json.gz');src=tsm['soft_matching'];loc={'eps':eps,'d':d,'jz':j}
        m,b,a=[s.sympify(src[n],locals=loc) for n in ['m0_over_zB','mass_linear_over_B','kinetic_over_B']]
        full=s.sympify(src['Sren_finite_per_scalar_axis'],locals=loc)*6
        source={n:s.sympify(src[n],locals=loc)*6 for n in ['Sbare_pole','Sbare_finite','Sct_pole','Sct_finite']}
        source={n:s.expand_log(z,force=True).subs(s.log(d),ld) for n,z in source.items()}
        forest={k:{n:v for n,v in z.items() if n.startswith('remaining_forest') or n in ['matched_Laurent','scale_jz']} for k,z in tsm['families'].items()}
    else:
        moment=lambda n:1/(n+1-eps)
        m=(2-eps)*moment(1)/(1-eps);b=(2-eps)*(moment(0)-moment(1));a=-moment(0)-eps*moment(1)-(3-eps)*moment(2)
        full=(1+j)/d+s.Rational(5,2)+3*j;source={};forest={}
    groups={'leading_mass':m/d,'internal_delta':b,'minus_kinetic':-a}
    raw={k:s.series(z*Hz*Hd/eps,eps,0,1).removeO().expand() for k,z in groups.items()}
    ct={k:-s.simplify(z.subs(eps,0))*Hd/eps for k,z in groups.items()}
    ren={k:s.simplify(s.series(raw[k]+ct[k],eps,0,1).removeO()) for k in groups}
    assert s.simplify(sum(ren.values())-full)==0
    return {'ratios':list(map(lambda z:str(s.factor(z)),[m,b,a])),'renormalized':{k:str(z) for k,z in ren.items()},'raw':{k:str(z) for k,z in raw.items()},'CT':{k:str(s.expand(z)) for k,z in ct.items()},'full_renormalized':str(s.factor(full)),'source_pole_finite_times6':{k:str(z) for k,z in source.items()},'remaining_forest':forest}

def calculate(role):
    mom,detail=scalar_primary() if role=='primary' else scalar_replay();vector=vectors(role);unit=units(role)
    print('STAGE '+role+'_actual_two_soft_weights_and_original_forest',flush=True)
    return {'schema':'TSR1_TWO_SOFT_RECONCILIATION','scalar_moments_W0_Wlog_W1_W1log':[list(map(fmt,row)) for row in mom],
      'scalar_kinetic_finite':list(map(lambda z:fmt(-z/2),mom[2])),
      'scalar_HDM_delta_finite_Q1':[fmt(-x+y) for x,y in zip(mom[2],mom[3])],
      'scalar_overlap_log_delta_coefficient':list(map(lambda z:fmt(-z),mom[2])),
      'scalar_overlap_constant':list(map(fmt,mom[3])),'scalar_detail':detail,'vector_weights':vector,'VSS_units':unit,
      'complete_finite_C1_or_all_family_soft_ownership_qualified':False}
