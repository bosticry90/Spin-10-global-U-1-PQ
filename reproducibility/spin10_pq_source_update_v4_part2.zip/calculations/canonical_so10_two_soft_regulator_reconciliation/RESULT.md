# Actual SSS/VSS two-soft terms match the hard regulator kernel

TSR1 qualifies the complete specified two-soft SSS/VSS coefficient and
original-forest reconciliation. The actual stored charge-axis kernels agree
with the independently calculated hard mass/kinetic kernels, including the
regulator and overlap terms. This reduces a finite assembly dependency;
it is not a full all-family finite boundary, C1_GS or E5/A5 theorem.

Final [receipt](validation_receipt.json) SHA256
`045224bc43edabcc38071248388f3a184bc965e67cecc894bbb092881f02a8c2`.
Scientific/director acceptance NOT_PERFORMED; authority34/39 unchanged.

Primary retained all23 two-soft/physical-heavy SSS source rows and69 original
forest axes. Replay calculated leading mass/log moments from the complete
class Gram and physical P,P log(H), with inverse moments supplied by HDM's
independently completed matrix-function calculation. The four three-component
moments (U1,SU2,SU3), in unchanged reference mass units, are approximately

| Moment | U1 | SU2 | SU3 |
| --- | ---: | ---: | ---: |
| W0 | .148371497974795151 | .247285829957991918 | 0 |
| Wlog | .0304888622390709620 | .0508147703984516034 | 0 |
| W1 | .145210103756925720 | .242016839594876200 | 0 |
| W1log | -.0138392039178682017 | -.0230653398631136695 | 0 |

The complete SSS light-charge soft part is

    -[(1+L)W0-Wlog]/delta - W1/2 + W1log-W1*log(delta).

The final two terms retain the nonzero scalar overlap. The finite kinetic
term -W1/2=(-.0726050518784628599,-.121008419797438100,0) is also nonzero.
The internal-delta hard mass closure at Q²=1 equals -W1+W1log, independently
reproducing HDM's(-.159049307674793921,-.265082179457989869,0). No physical
coupling or subtraction scale is chosen by displaying polynomial coefficients.

The mixed internal-delta and double-soft poles cancel but leave the overlap
log. Original light and heavy mass forests remain in Cfull. We compared252
recorded coefficient positions against S3A's ORIGINAL blueprint across both
stored coupling cases. Another54 axis entries across those two cases were
correctly absent because their F² weights are zero; they remain in the full
source inventory. No zero-charge scalar direction is discarded from HDM.

VSS regulator weights w=(Q1+Q2)/4 reproduce the actual projected currents:
r1=(.148547548037476492,.247579246729127487,0), neutralr2=(.03,.05,0),
r3/r4=0 in this projection. Their sum is not a vector-charge average.
The three per-weight finite soft terms are

    leading mass: (1+jz)/d,
    internal delta: 1+jz,
    minus kinetic: 3/2+2*jz,

where d=delta/z. Their sum matches TSM's actual two-axis table and NCM's
neutral reduction. The ORIGINAL per-axis scalar forest is -(1/d+3)/6:
the regulator term supplies one unit of its constant pole and kinetic
supplies two. Keeping only the summed coefficient would hide that distinction.
The charged vector's remaining forest finite term-1/9 and matched finite
19/18 are retained. Dropping the former shifts the weighted U1 contribution
by approximately.198063397383301990*g10² despite leaving a pole-only test
insensitive to that finite error.

The exact algebraic forest accounting uses ORIGINAL Cfull in
Rprime_matched+(Cparent-Cfull). It is not the sum of a matched primitive and
the unchanged complete parent forest. The generic labelled identity is
checked only after the actual colour/axis coefficients have been matched.
It does not calculate Cparent's unresolved full finite normalizations.

Native maximum scaled difference9.74e-62; original-forest difference4.80e-62;
HDM finite-response difference7.59e-61, within1e-45 gates. VSS identities,
SSS Laurent region relations and neutral recovery exact. These are numerical
source comparisons at the declared point, not rigorous interval results.
No old expensive integration was repeated. HDM's initial extra-pole closing
interpretation remains superseded by its V2 correction.

4775bindings; primary1.7707481s/replay9.8069339s/validation1.5252050s after
imports; sampled private maxima49,082,368/65,855,488/50,286,592bytes, not
continuous peaks. All3 workers COMPLETED within600s/8GiB; no failure,
timeout, cancellation or truncation. Sources/old failures unchanged.

Next: complete the action-based support check for every mixed two-soft
assignment, including light vector/ghost hard delta insertions. Then combine
that result with OSF, ASE, LGF and actual remaining one-soft prescriptions
before asserting a common all-family finite boundary. Keep the mandatory
V3L correction, hard HTB/finite physical jets, overall-MS and nonlinear C1
obligations separate. No partial physical target comparison or fitting.

Shared action/point/source/frame/UV/region/gauge/software/AI assumptions and
qualified older kernel integrations limit independence. This is internal
computational corroboration, not external scientific/experimental confirmation.
Historical custodyexit2/seven NOTPASS, scalar/gauge/matter/quartet warnings,
protected stages and human-paused sectors remain unchanged. Goal ACTIVE.
