"""TSR1 separate comparison of stored units, actual weights and forest ownership."""
from data import *
start=begin('validation_preparation.json');mp.mp.dps=110
a=packed(HERE/'primary_tables.json.gz');b=packed(HERE/'replay_tables.json.gz');err=mp.mpf(0)
for key in ['scalar_moments_W0_Wlog_W1_W1log','scalar_kinetic_finite','scalar_HDM_delta_finite_Q1','scalar_overlap_log_delta_coefficient','scalar_overlap_constant']:
    aa=a[key] if key!='scalar_moments_W0_Wlog_W1_W1log' else sum(a[key],[]);bb=b[key] if key!='scalar_moments_W0_Wlog_W1_W1log' else sum(b[key],[])
    for x,y in zip(aa,bb):
        x,y=q(x),q(y);v=abs(x-y)/(1+abs(x)+abs(y));err=max(err,v);assert v<mp.mpf('1e-45'),(key,fmt(v))
for x,y in zip(a['vector_weights'],b['vector_weights']):
    assert x['r']==y['r']
    zero(s.Matrix([s.sympify(z,locals={'w':w})-s.sympify(t,locals={'w':w}) for z,t in zip(x['regulator_weight'],y['regulator_weight'])]))

eps,d,j,ld=s.symbols('eps d j ld',real=True);loc={'eps':eps,'d':d,'j':j,'ld':ld}
parse=lambda x:s.sympify(x,locals=loc)
for x,y in zip(a['VSS_units']['ratios'],b['VSS_units']['ratios']):assert s.cancel(parse(x)-parse(y))==0
for key in ['raw','CT','renormalized']:
    for name,x in a['VSS_units'][key].items():assert s.cancel(parse(x)-parse(b['VSS_units'][key][name]))==0
raw=sum(map(parse,a['VSS_units']['raw'].values()));ct=sum(map(parse,a['VSS_units']['CT'].values()));source=a['VSS_units']['source_pole_finite_times6']
for given,expr in [('Sbare_pole',raw.coeff(eps,-1)),('Sbare_finite',raw.coeff(eps,0)),('Sct_pole',ct.coeff(eps,-1)),('Sct_finite',ct.coeff(eps,0))]:assert s.cancel(parse(source[given])-expr)==0,given
assert s.cancel(parse(a['VSS_units']['full_renormalized'])-parse(b['VSS_units']['full_renormalized']))==0

# Compare the stored neutral two-axis result, not only a generic kernel.
ncm=packed(CAL/'canonical_so10_neutral_current_matching/primary_kernel_tables.json.gz');nf=s.sympify(ncm['soft_matching']['Sren_finite'],locals={'eps':eps,'jz':j,'delta':d})
assert s.simplify(nf-parse(a['VSS_units']['full_renormalized'])/3)==0
tsm=packed(CAL/'canonical_so10_charged_two_soft_matching/primary_kernel_tables.json.gz');fams=tsm['families']
for fam in ['left','right']:assert fams[fam]['matched_Laurent']==['0','-1','-5/4'] and fams[fam]['scale_jz']=='-2'
assert fams['vector']['matched_Laurent']==['0','-1/3','19/18'] and fams['vector']['scale_jz']=='1/2'
assert fams['vector']['remaining_forest_pole']=='-7/6' and fams['vector']['remaining_forest_evanescent']=='-1/9'

# Original current forests are read before the light limit from CCK's x,y,z
# unit, then reconstructed from the measured mass and kinetic poles.
X,Y,Z=s.symbols('x y z',positive=True);cck=packed(CAL/'canonical_so10_charged_current_kernel/primary_kernel_tables.json.gz');original_current={}
for fam in ['left','right']:
    p=s.sympify(cck['kernels'][fam]['forest']['pole'],locals={'x':X,'y':Y,'z':Z});light=s.cancel(p.subs({X:d,Y:d,Z:1}))
    assert s.cancel(light+(1/d+3)/6)==0
    original_current[fam]=str(light)

# Original SSS forest blueprint in BOTH stored coupling cases. No sorted
# mass-axis shortcut; classes/mode_ids/axis are kept independently labelled.
amp=packed(CAL/'canonical_so10_scalar_cubic_amplitude/primary_tables.json.gz');positions=0;missing_zero=0;ferr=mp.mpf(0)
for case in ['1','1/2']:
    lookup={(tuple(z['classes']),tuple(z['mode_ids']),z['axis']):z for z in amp['cases'][case]['full_original_forest_blueprint']}
    for row in a['scalar_detail']['original_forest']:
        key=(tuple(row['classes']),tuple(row['mode_ids']),row['axis']);ww=list(map(q,row['coefficient']))
        if key not in lookup:
            assert all(z==0 for z in ww);missing_zero+=1;continue
        old=lookup[key];assert old['closing_mass_key']==row['mass_key'] and old['original_common_delta_closing']==row['soft']
        for x,y in zip(ww,old['coefficient_of_Hm_over_m_epsilon']):
            y=q(y);v=abs(x-y)/(1+abs(x)+abs(y));ferr=max(ferr,v);assert v<mp.mpf('1e-45');positions+=1

# Actual S3T region jets from the qualified positive-mass/full-EFT proof.
s3t=packed(CAL/'canonical_so10_scalar_two_soft_kernel/primary_v2_tables.json.gz')['exact_regions'];MM,dd=s.symbols('M delta',positive=True);jj=s.Symbol('j',real=True)
regions={'mixed_mass_bare':[-1/d,-(1+2*j-ld)/d], 'mixed_mass_forest':[1/d,(j-ld)/d],
 'mixed_internal_light_mass':[-1,-(1+2*j-ld)],'double_soft':[1,1+2*j-2*ld]}
for name,pair in regions.items():
    for raw,want in zip(s3t['Laurent_region_groups'][name],pair):
        z=s.sympify(raw,locals={'eps':eps,'M':MM,'delta':dd,'j':jj}).subs({MM:1,dd:d,jj:j})*6
        z=s.expand_log(z,force=True).subs(s.log(d),ld);assert s.simplify(z-want)==0,(name,z,want)
assert s3t['soft_kinetic']=='-1/(12*M)'

# HDM's corrected finite mass closure must be the SAME weighted term.
hdm=json.loads((CAL/'canonical_so10_hard_delta_matching/validation_receipt_v2.json').read_bytes())
deltaerr=mp.mpf(0)
for x,y in zip(a['scalar_HDM_delta_finite_Q1'],hdm['potential_finite_mass_closing_Q2_one_U1_SU2_SU3']):
    x,y=q(x),q(y);deltaerr=max(deltaerr,abs(x-y)/(1+abs(x)+abs(y)))
assert deltaerr<mp.mpf('1e-45')
W0,Wlog,W1,W1log=[list(map(q,z)) for z in a['scalar_moments_W0_Wlog_W1_W1log']]
assert any(abs(z)>mp.mpf('1e-40') for z in W1)
root=point_root();vw=[[real(number(s.sympify(v,locals={'w':w}),root)) for v in row['regulator_weight']] for row in a['vector_weights']]
vector_evan=[real(number(s.sympify(z,locals={'w':w}),root))/6 for z in a['vector_weights'][0]['vector']]
assert any(abs(z)>mp.mpf('1e-40') for z in vector_evan) and any(abs(z)>mp.mpf('1e-40') for z in vw[1])

# Dimension-independent scalar identities and the ordinary original-forest
# bookkeeping, with all channels independently labelled before summation.
B,Cp,Cfull,Sb,Csoft=s.symbols('B Cparent Cfull Sbare Csoft')
matched=B+Cfull-Sb-Csoft
assert s.expand(B+Cp-Sb-Csoft-matched-(Cp-Cfull))==0
assert s.expand(B+Cp-Sb-Csoft-matched-Cp)!=0
assert s.expand(B+Cp-Sb-Csoft-matched-(Cp-2*Cfull))!=0
controls={'omit_SSS_overlap_log_delta_coefficient':list(map(fmt,W1)),
 'omit_SSS_kinetic_finite':list(map(lambda z:fmt(-z/2),W1)),
 'omit_HDM_internal_delta_finite_Q1':a['scalar_HDM_delta_finite_Q1'],
 'omit_neutral_vector_regulator_weight':list(map(fmt,vw[1])),
 'omit_charged_vector_evanescent_shift':list(map(fmt,vector_evan)),
 'omit_VSS_bdelta_original_forest_pole_per_weight':'1',
 'omit_VSS_kinetic_original_forest_pole_per_weight':'2',
 'missing_or_double_Cfull_nonzero':True}
receipt={'schema':'TSR1_VALIDATION','status':'QUALIFIED_SSS_VSS_TWO_SOFT_REGULATOR_KINETIC_OVERLAP_AND_ORIGINAL_FOREST_RECONCILIATION',
 'execution_state':'COMPLETED','scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED',
 'native_max_scaled_error':fmt(err),'original_SSS_forest_comparisons':positions,'source_zero_forest_axes_not_in_amplitude_blueprint':missing_zero,
 'original_SSS_forest_max_scaled_error':fmt(ferr),'HDM_scalar_delta_closing_max_scaled_error':fmt(deltaerr),
 'all_two_soft_scalar_rows':23,'original_scalar_forest_axes':69,'scalar_moments_W0_Wlog_W1_W1log':a['scalar_moments_W0_Wlog_W1_W1log'],
 'scalar_kinetic_finite':a['scalar_kinetic_finite'],'scalar_HDM_delta_finite_Q1':a['scalar_HDM_delta_finite_Q1'],
 'vector_regulator_weights_numeric':[[row['r'],list(map(fmt,v))] for row,v in zip(a['vector_weights'],vw)],
 'VSS_original_scalar_forest_units':original_current,'VSS_full_soft_finite_per_regulator_weight':'(1+jz)/d+5/2+3*jz',
 'VSS_matched_charged_vector_finite':'19/18','VSS_retained_vector_forest_finite':'-1/9',
 'SSS_overlap_log_retained':True,'kinetic_terms_retained':True,'original_Cfull_not_replaced_by_matched_forest':True,
 'qualified_old_loops_integrated_again':False,'negative_controls':controls,
 'all_family_common_finite_boundary_or_C1_E5_A5_qualified':False,
 'shared_error_limits':['action/point/reference/frame/source/spectrum/gauge/UV/region assumptions','qualified old kernel integrations','software','AI authorship'],
 'elapsed_after_imports':time.perf_counter()-start}
print('RESULT '+json.dumps(receipt,sort_keys=True),flush=True)
