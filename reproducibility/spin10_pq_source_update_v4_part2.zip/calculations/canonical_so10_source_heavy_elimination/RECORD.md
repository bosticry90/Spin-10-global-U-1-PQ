# SHE1: source-dependent heavy stationary reduction

Prospective at210e7d50c0a3ed01dd0467a8dc06a72ad660dfc3/main,2026-10-21.
Read-only recovery clean;no matching workers. Review intake: the director's
two attached nine-family/fixed-reference assessments. Preserve their ceiling:
all9 bosonic primitive inputs and fixed-xi assembly do not establish physical
C1 or gauge independence. Previous bounded increment NTS is progress.

Question: does eliminating the actual heavy fields BEFORE source restriction
preserve the nonlinear order-two Slavnov relation,and does its leading
dimension-four tree functional equal the existing light gauge/source action?
This is a necessary concrete part of common full/EFT source matching,not that
whole theorem. Cheapest competent test: exact full-carrier projection identities,
a complete action-based low-energy valuation proof,graded auxiliary elimination,
and independent stationary-envelope/loop-two bridge derivations. No new loop
integral or large coefficient expansion is required.

Use EPC/NTS's actual BFT S_ext,constant u,chi,widths near1,delta>0,Euclidean
formal local low-energy expansion at the same stationary v. Heavy antifields
are restricted to zero only AFTER the full functional is defined. Light
antifields,u,chi remain through heavy EOM and derivatives. Full598 fields after
the auxiliary Gaussian split into77 light and521 heavy;before it643=89+554.
Positive-heavy inverse is a Wilson expansion,not a new polynomial UV CT.
No physical normalization,gauge fixing,fermionic input or authority is changed.

Freeze RECORD,DERIVATION and six Python sources/copies before science. Native
primary contracts BFT ordered tensors with full projectors;replay builds Lie
brackets with10-dimensional planes and ghost/scalar projections directly from
physical representation matrices. Both retain the complete broken-generator
action on the5-light-scalar carrier,including any nonzero entries. They use
different graded-product and heavy-quadratic elimination routes. The separate
verifier imports neither native calculation;it compares full tensors,derives
another source-dependent Gaussian and tests Berezin/source-contact signs.
Shared inputs/action/coordinate and software/AI authorship remain limitations.

Acceptance: exact H closure,soft/heavy invariance,zero affine soft orbit and
zero O^T rho_H X;full source-generator family census;all graded light auxiliary
contacts;no omitted dimension<=4 heavy-induced source term;source-dependent
stationary pullback and negative two-loop bridge with nonzero omission controls.
Retain ASE's measured quartic as inherited evidence,not a fresh computation.
Failure of any projection/sign/valuation/control is not a qualified theorem.
Underdefinition or a demonstrated higher-dimension/source remainder is valid.
No unknown finite quantum coefficient is inferred from a desired cancellation.

Authority ceiling: source-dependent tree correspondence and full-theory
stationary-reduction rule within the stated formal domain. No complete hard
one-loop matching functional,one-/two-soft source ownership theorem,numerical
C1,E5/A5,physical gauge independence or unification. Higher-dimension terms
are retained as an explicit remainder;do not discard them inside un-subtracted
IR regions. Keep matter/flavor paused and HB1/C5 blocked.

Sequential600s after-import workers,8GiB sampled private memory,350MiB launch
floor,24MiB package;observed complete captures,separate validation,e4 readiness
and raw/index/HEAD seal before local commit. Preserve exact failures/unfinished
runs. No agents,reset,amend,push,outreach or publication. State113/34of39 and
custodyexit2/seven NOTPASS unchanged. All scalar/gauge/quartet warnings remain.
Root has previously seen the old physical comparison target;no blind claim.
