# Next: actual hard one-loop functional and complete source-region ownership

SHE supplies the source-dependent stationary operation,h0 and its graded
Schur derivatives,the leading light action and the higher-dimension remainder.
EPC supplies the actual full/EFT pole recipe;NTS supplies the nonlinear
order-two full-theory subtraction identity. They must now be connected to
the ACTUAL full/EFT source regions,not another symbolic matrix cancellation.

Define X_h1 from the hard part of the actual one-loop full trace evaluated
on SHE's source-dependent h0,including its heavy-EOM leaves,minus the common
light contribution and with the EPC full/EFT pole functionals in the same
chart. Derivatives of h0 and H_hh^-1 are Schur/source vertices and must remain.
No finite hard source coefficient may be inferred from the desired FAN width
cancellation. Reuse HRS/RNC/RLS/NVF/NAP measured projections as controls.

At order2 prove that the source-dependent light Gaussian with X_h1 and the
tree-induced scalar quartic reproduces all one-/two-soft contributions and
their original counterterm ownership. Differentiate all source/field/width
jets before restriction. Reconcile CBR's288 labels and the SSS/VSS two-soft
forests;retain the negative mixed/both-hard heavy bridges once. The exact
SHE envelope theorem alone does not prove this loop-region equality.

Show when higher-dimension tree source terms can be excluded from the LOCAL
F² Nielsen projection after COMPLETE common subtraction. A dimension count
on an individual IR-enhanced graph is insufficient. Relevant hard mass,
kinetic and regulator residues and the nonlocal light NVF form factor stay
until the common full/EFT cancellation is actually shown. Keep positive-eps
data through pole products and the original MSbar/FJ-like tadpole convention.

Success is a complete source-level region/forest theorem that licenses the
actual NTS identity for the matched coefficient. A concrete unowned source
graph or an underdefined subtraction is a valid outcome. Do not set an unknown
two-loop width derivative from a required cancellation. Do not extend C1's
acceptance contract to all-order/full-physical E5 as an additional prerequisite.

Then finish original C1 item7 gauge,basis,finite-degeneracy,RG and1L regressions,
arbitrary-g evaluation and item8 physical comparison/perturbative-control
assessment. Fermions/physical input dependencies remain distinct and matter/
flavor stays paused. Authority34/39,custodyexit2/seven NOTPASS,HB1/C5 block
and all scalar/gauge/quartet warnings remain. No new scheme,fit or publication.
