"""SHE1 full projector tensors,exterior products and stationary substitution."""
from data import *
started=begin('primary')
sys.path.insert(0,str(CAL/'canonical_so10_finite_counterterm_insertion'))
from geometry_v2 import tidy,zero,red,dec,enc
from itertools import product
b=packed(CAL/'canonical_so10_background_threshold_inputs/primary_tables.json.gz')
O=s.SparseMatrix(328,45,{(i,j):s.sympify(z) for i,j,z in b['orbit']})
f={(a,b,c):s.sympify(z) for a,b,c,z in b['f']}
T={(a,b,i):s.sympify(z) for a,b,i,z in b['T']}
d=read(PACKET/'full_primary.json')
rho=[s.SparseMatrix(s.diag(*[dec(d['representation_matrices'][k][a]) for k in ['Phi','Sigma','phi','S']])) for a in range(45)]
V=dec(packed(CAL/'canonical_so10_vector_quartic_ir_matching/primary_tables.json.gz')['light_embedding'])
X=dec(packed(CAL/'canonical_so10_scalar_cubic_light/primary_tables.json.gz')['light_basis_canonical'])
B=tidy(X.T*X)
aug=s.MutableSparseMatrix(B.row_join(s.eye(5)))
for j in range(5):
    pivot=next(k for k in range(j,5) if red(aug[k,j])!=0)
    if pivot!=j:aug.row_swap(j,pivot)
    z0=red(aug[j,j])
    for k in range(10):aug[j,k]=red(aug[j,k]/z0)
    for i in range(5):
        if i==j:continue
        z0=red(aug[i,j])
        if z0:
            for k in range(10):aug[i,k]=red(aug[i,k]-z0*aug[j,k])
Bi=tidy(aug[:,5:]);zero(B*Bi-s.eye(5))
left=tidy(Bi*X.T);Ps=tidy(X*left);P=tidy(V*V.T)
zero(V.T*V-s.eye(12));zero(Ps*Ps-Ps);zero(Ps-Ps.H);zero(Ps-Ps.T)
zero(O*V);zero(Ps*O)
ads=[s.SparseMatrix(45,45,{(c,b):z for (a,b,c),z in f.items() if a==j}) for j in range(45)]
rh=[];br=[]
for h in range(12):
    A=tidy(sum((V[a,h]*ads[a] for a in range(45)),s.zeros(45)))
    R=tidy(sum((V[a,h]*rho[a] for a in range(45)),s.SparseMatrix(328,328,{})))
    small=tidy(left*R*X);zero(R*X-X*small);rh.append(small)
    zero(A*P-P*A);br.append(tidy(A*V))
br=s.SparseMatrix.hstack(*br);zero((s.eye(45)-P)*br)
flat=s.SparseMatrix(45,45*328,{(a,328*b+i):z for (a,b,i),z in T.items()})
zero(V.T*flat)
# Contract the recorded ORDERED T,not an exchanged ghost index.
tc=[]
for h in range(12):
    Z=tidy(flat*s.kronecker_product(V[:,h],X));zero(Z);tc.append(Z)
U=s.SparseMatrix.hstack(*[tidy(left*R*X) for R in rho])
Uh=s.SparseMatrix.hstack(*[tidy(sum((P[a,b]*U[:,5*b:5*b+5] for b in range(45)),s.zeros(5))) for a in range(45)])
Um=tidy(U-Uh);assert Um.todok()
cas=tidy(-sum((R*R for R in rh),s.zeros(5)))
print('STAGE primary_actual_complete_source_projection',flush=True)

def clean(F):return {m:s.expand(z) for m,z in F.items() if s.expand(z)!=0}
def add(*Fs):
    out={}
    for F in Fs:
        for m,z in F.items():out[m]=out.get(m,0)+z
    return clean(out)
def scale(F,a):return clean({m:a*z for m,z in F.items()})
def mul(F,G):
    out={}
    for a,z in F.items():
        for b,w in G.items():
            if a&b:continue
            sign=(-1)**sum(i>j for i in range(4) if a&(1<<i) for j in range(4) if b&(1<<j))
            out[a|b]=out.get(a|b,0)+sign*z*w
    return clean(out)
r,K,x1=s.symbols('r K x1',real=True)
J={0:r+K,6:-s.Rational(1,2),9:-1} # u,chi,barc,c ordered bits
aux=scale(mul(J,J),1/(2*x1));total=add(aux,{9:r})
# A/B odd heavy currents:direct EOM substitution before taking sources zero.
m=s.symbols('m',nonzero=True);A={1:s.S.One};C={2:s.S.One}
bar=scale(A,-1/m);ghost=scale(C,-1/m)
oddred=add(scale(mul(bar,ghost),m),mul(bar,C),mul(A,ghost))
assert oddred=={3:-1/m}

x,z,hb=s.symbols('x z hb');M=s.Matrix([[3,1],[1,4]]);N=s.Matrix([[1,2],[2,0]])
J0=s.Matrix([x*x+z,2*x*x-z]);v=s.Matrix([x+2*z,3*x-z]);w=s.Matrix([1+z,-2+z])
h0=-M.inv()*J0;j1=v+N*h0;h1=-M.inv()*j1;h2=-M.inv()*(N*h1+w)
h=h0+hb*h1+hb**2*h2
action=(h.T*M*h)[0]/2+(J0.T*h)[0]+hb*((v.T*h)[0]+(h.T*N*h)[0]/2)+hb**2*(w.T*h)[0]
red2=s.expand(action).coeff(hb,2)
bridge=s.expand(-(j1.T*M.inv()*j1)[0]/2)
expected=(w.T*h0)[0]+bridge;assert s.expand(red2-expected)==0
direct_dx=(J0.diff(x).T*h)[0]+hb*(v.diff(x).T*h)[0]
assert s.expand(s.diff(action,x)-direct_dx).coeff(hb,2)==0
direct_dz=(J0.diff(z).T*h)[0]+hb*(v.diff(z).T*h)[0]+hb**2*(w.diff(z).T*h)[0]
assert s.expand(s.diff(action,z)-direct_dz).coeff(hb,2)==0
zero_source_first=s.expand(red2.subs(z,0));assert s.diff(zero_source_first,z)==0 and s.expand(red2).coeff(z,1)!=0
weights={'scalar':2,'vector':3,'ghost':3,'antighost':3}
source_terms={'K_s_phi_cM':2+1+weights['ghost'],'K_s_etaM_cM':2+weights['scalar']+weights['ghost'],
 'K_Q_QM_cM':2+weights['vector']+weights['ghost'],'K_c_cM_cM':2+2*weights['ghost'],
 'chi2_barM_etaM':1+weights['antighost']+weights['scalar'],'chi1_barM_D_QM':1+weights['antighost']+1+weights['vector'],
 'u_QH_QM_cM':1+1+weights['vector']+weights['ghost'],'u_phi_etaM_cM':1+1+weights['scalar']+weights['ghost'],
 'u_barH_cM_cM':1+1+2*weights['ghost'],'chi1_chi2_barM_barM':2+2*weights['antighost']}
assert min(source_terms.values())==6
finish('primary',{'scalar_metric':enc(B),'light_scalar_actions':list(map(enc,rh)),'light_Casimir':enc(cas),
 'light_f':enc(tidy(V.T*br)),'all45_soft_scalar_action':enc(U),'broken_soft_scalar_action':enc(Um),
 'broken_soft_scalar_nonzero':len(Um.todok()),'zero_positions':{'affine_soft_orbit':5*45,'T_MHsoft_with_zeroHrows':45*12*5,'T_H_all':12*45*328,'Lie_heavy_complement':45*12*12,'scalar_H_invariance':328*5*12},
 'auxiliary_square':[[mask,str(s.factor(v))] for mask,v in sorted(aux.items())],
 'auxiliary_with_u_IBP':[[mask,str(s.factor(v))] for mask,v in sorted(total.items())],
 'odd_heavy_reduced':[[mask,str(v)] for mask,v in sorted(oddred.items())],
 'bridge_z0':str(s.factor(bridge.subs(z,0))),'bridge_z1':str(s.factor(s.expand(bridge).coeff(z,1))),
 'red2_z0':str(s.factor(red2.subs(z,0))),'red2_z1':str(s.factor(s.expand(red2).coeff(z,1))),
 'heavy_valuations':weights,'source_term_min_weights':source_terms,
 'counts':{'full_before_b':643,'full_after_b':598,'light_before_b':89,'light_after_b':77,'heavy_before_b':554,'heavy_after_b':521},
 'lambda_E_reused':packed(CAL/'canonical_so10_all_soft_scalar_tree/primary_tables.json.gz')['lambda_from_all_light_source'],
 'full_EFT_source_regions_qualified':False,'finite_C1_evaluated':False},started)
