"""SHE1 faithful plane brackets,direct representation currents,exterior matrices."""
from data import *
from itertools import combinations
started=begin('replay')
sys.path.insert(0,str(CAL/'canonical_so10_finite_counterterm_insertion'))
from geometry_v2 import tidy,zero,red,dec,enc
d=read(PACKET/'full_replay.json');O=dec(d['vacuum']['orbit'])
V=dec(packed(CAL/'canonical_so10_vector_quartic_ir_matching/replay_tables.json.gz')['light_embedding'])
X=dec(packed(CAL/'canonical_so10_scalar_cubic_light/replay_tables.json.gz')['light_basis_canonical'])
metric=tidy(X.T*X);hermitian=tidy(X.H*X)
zero(hermitian-s.diag(*[hermitian[i,i] for i in range(5)]))
left=tidy(s.diag(*[red(1/hermitian[i,i]) for i in range(5)])*X.H)
zero(left*X-s.eye(5));P=tidy(V*V.T)
zero(V.T*V-s.eye(12));zero(left*O)
rho=[]
for a in range(45):
    blocks=[dec(d['representation_matrices'][k][a]) for k in ['Phi','Sigma','phi','S']]
    rho.append(s.SparseMatrix(s.diag(*blocks)))
indices=list(combinations(range(10),2));planes=[s.SparseMatrix(10,10,{(i,j):1/s.sqrt(2),(j,i):-1/s.sqrt(2)}) for i,j in indices]
gens=[tidy(sum((V[a,h]*planes[a] for a in range(45)),s.zeros(10))) for h in range(12)]
cols=[]
for A in gens:
    for C in gens:
        R=tidy(A*C-C*A);cols.append(s.Matrix([s.sqrt(2)*R[i,j] for i,j in indices]))
br=tidy(s.SparseMatrix.hstack(*cols));zero(br-V*(V.T*br))
rh=[]
for h in range(12):
    R=tidy(sum((V[a,h]*rho[a] for a in range(45)),s.SparseMatrix(328,328,{})))
    Y=tidy(R*X);small=tidy(left*Y);zero(Y-X*small);zero(O.T*Y)
    zero((O*V[:,h]));rh.append(small)
# Ordered row is O_a^T rho_b. Test light-antighost rows without reading BFT T.
for R in rho:zero(V.T*(O.T*R))
U=s.SparseMatrix.hstack(*[tidy(left*(R*X)) for R in rho])
broken=[]
for a in range(45):
    RM=tidy(rho[a]-sum((P[a,b]*rho[b] for b in range(45)),s.SparseMatrix(328,328,{})))
    broken.append(tidy(left*RM*X))
Um=s.SparseMatrix.hstack(*broken);assert Um.todok()
print('STAGE replay_direct_representation_tree_source_domain',flush=True)

def creation(bit):
    out=s.zeros(16)
    for mask in range(16):
        if not mask&(1<<bit):out[mask|(1<<bit),mask]=(-1)**((mask&((1<<bit)-1)).bit_count())
    return out
E=[creation(i) for i in range(4)];I=s.eye(16);r,K,x1=s.symbols('r K x1',real=True)
J=(r+K)*I-E[1]*E[2]/2-E[0]*E[3]
aux=J*J/(2*x1);total=aux+r*E[0]*E[3]
def terms(A):return [[mask,str(s.factor(A[mask,0]))] for mask in range(16) if s.simplify(A[mask,0])!=0]
m=s.symbols('m',nonzero=True);a,c=E[0],E[1]
bar=-a/m;g=-c/m;odd=m*bar*g+bar*c+a*g
assert odd[3,0]==-1/m

# Exact completion of a source-dependent heavy square,then its loop Taylor jet.
x,z,hb=s.symbols('x z hb');M=s.Matrix([[3,1],[1,4]]);N=s.Matrix([[1,2],[2,0]])
J0=s.Matrix([x*x+z,2*x*x-z]);v=s.Matrix([x+2*z,3*x-z]);w=s.Matrix([1+z,-2+z])
H=M+hb*N;j=J0+hb*v+hb**2*w;hstar=-H.inv()*j
exact=-(j.T*H.inv()*j)[0]/2
red2=s.expand(s.diff(exact,hb,2).subs(hb,0)/2)
h0=-M.inv()*J0;current=v+N*h0;bridge=s.expand(-(current.T*M.inv()*current)[0]/2)
assert s.simplify(red2-(w.T*h0)[0]-bridge)==0
for a in [x,z]:
    envelope=(j.diff(a).T*hstar)[0]
    assert s.simplify(s.diff(exact,a)-envelope)==0
assert red2.coeff(z,1)!=0
weights=dict(zip(['scalar','vector','ghost','antighost'],[2,3,3,3]))
terms_weight={}
families=[('K_s_phi_cM',[2,1,3]),('K_s_etaM_cM',[2,2,3]),('K_Q_QM_cM',[2,3,3]),('K_c_cM_cM',[2,3,3]),
 ('chi2_barM_etaM',[1,3,2]),('chi1_barM_D_QM',[1,3,1,3]),('u_QH_QM_cM',[1,1,3,3]),
 ('u_phi_etaM_cM',[1,1,2,3]),('u_barH_cM_cM',[1,1,3,3]),('chi1_chi2_barM_barM',[1,1,3,3])]
for name,dims in families:terms_weight[name]=sum(dims)
assert min(terms_weight.values())==6
finish('replay',{'scalar_metric':enc(metric),'light_scalar_actions':list(map(enc,rh)),
 'light_Casimir':enc(tidy(-sum((R*R for R in rh),s.zeros(5)))),'light_f':enc(tidy(V.T*br)),
 'all45_soft_scalar_action':enc(U),'broken_soft_scalar_action':enc(Um),'broken_soft_scalar_nonzero':len(Um.todok()),
 'zero_positions':{'affine_soft_orbit':5*45,'T_MHsoft_with_zeroHrows':45*12*5,'T_H_all':12*45*328,'Lie_heavy_complement':45*12*12,'scalar_H_invariance':328*5*12},
 'auxiliary_square':terms(aux),'auxiliary_with_u_IBP':terms(total),'odd_heavy_reduced':terms(odd),
 'bridge_z0':str(s.factor(bridge.subs(z,0))),'bridge_z1':str(s.factor(bridge.coeff(z,1))),
 'red2_z0':str(s.factor(red2.subs(z,0))),'red2_z1':str(s.factor(red2.coeff(z,1))),
 'heavy_valuations':weights,'source_term_min_weights':terms_weight,
 'counts':{'full_before_b':643,'full_after_b':598,'light_before_b':89,'light_after_b':77,'heavy_before_b':554,'heavy_after_b':521},
 'lambda_E_reused':packed(CAL/'canonical_so10_all_soft_scalar_tree/replay_tables.json.gz')['lambda_from_all_light_source'],
 'full_EFT_source_regions_qualified':False,'finite_C1_evaluated':False},started)
