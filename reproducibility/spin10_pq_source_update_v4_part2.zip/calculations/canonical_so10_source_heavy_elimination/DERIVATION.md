# SHE1: actual source-preserving reduction and its precise limit

## Domain and complete stationary operation

Use S_ext exactly as EPC eq(1)'s action definition: physical BFT action plus
s_ext Psi+s_ext(u O_delta)+K R. This is the ordinary fixed-reference gauge,
not the separate formal E5 action or the comparator's partially fixed gauge.
Split L=(Q_H,eta_s,c_H,barc_H,b_H) and h=all other integrated fields. Dimensions
of Q,eta,c,barc are1,b2,K_Q/K_eta/K_c/K_barc2,chi/u1,delta2,D1. K_b is absent
because R_b=0. Heavy field antifields K_h are set to zero as external arguments;
their full derivatives still exist. They must not be removed from the original
Slavnov functional before its heavy EOM factor is identified.

At fixed regulator solve Gamma_h=0 on the perturbative branch about the heavy
positive reference and define G(L,K_L,u,chi)=Gamma(L,h_*,K_L,K_h=0,u,chi).
For ANY retained field/source/width derivative a,the graded envelope rule gives
G_a=Gamma_a+Gamma_h*(h_*)_a=Gamma_a on this surface. The heavy term in the full
Slavnov equation is Gamma_h Gamma_Kh=0. Its restriction is therefore exactly
the light extended Slavnov equation,including chi.partial_xi+delta.partial_u.
This is stationary evaluation,not a change of integration variables;there is
no new Berezinian to append. It does not identify a path integral EFT or prove
that a hard-region extraction commutes with this operation.

Write Gamma=S+ell G1+ell² G2,with already consistent EPC/NTS subtraction.
Let S_h(h0)=0,H=S_hh(h0). With actual graded Hessian order,
 h1=-H^-1 G1,h(h0),
 Gred0=S(h0), Gred1=G1(h0),
 Gred2=G2(h0)-1/2 <G1,h,H^-1 G1,h>_graded.                 (1)
This follows by expanding S at h0 and combining its h1²/2 term with
G1,h*h1;terms involving h2 multiply S_h=0. No solution at all source orders
needs to be printed to define this formal implicit functional. Heavy inverses
are expanded in low-energy jets;they are local Wilson series with inverse
positive-heavy masses. Do not transfer this permission to the polynomial
UV-counterterm ring. The same graded order gives,for a heavy ghost pair,
 S=barz M z+barz B+A z -> Sred=-A M^-1 B,
which tests the odd part of(1). All A/B odd products retain their order.

NTS's nonlinear Slavnov identity then pulls back by the envelope rule through
order2. This proves a full-theory reduced identity,not common source matching.
At sourcezero and zero light fields,h0=0 for any retained H background. The
heavy one-loop tadpole source has only the previously qualified3 physical
singlet directions in this F² projection. In(1),the cross of t and R F² is
-R M^-1 t,with the original bilinear radial metric. It is FAN/HTB's bridge
ONCE,not NTS's distinct Legendre cancellation of connected1PR vacuum graphs.
No new numerical tadpole evaluation or width derivative is supplied here.

## Actual projection tests and full tree source domain

Let V be the actual real45x12 unbroken frame,P=VV^T. Let X be the actual
328x5 complexified real light carrier,B=X^T X,Ps=X B^-1 X^T. The bilinear
metric is essential;use no charge average. Test
 O V=0, Ps O=0, [H,H] subset H,
 rho_H X=X r_H, O^T rho_H X=0.                           (2)
The last identity is the actual potentially dangerous ghost current
T_M,H,s=O_M^T rho_H X,not merely the light-antighost row zero O_H=0.
Orthogonality and antisymmetric real representations prove invariance of
both complements. Independently retain Xleft rho_b X for ALL45 b and its
broken projection. It must not be asserted zero from H invariance:the soft
carrier need not be invariant under all of Spin10.

These tests cover the full source list,not just one ub12-like projection:
 K_QH P(Dbar c+g[Q,c]),
 -g K_s Xleft rho(c)(v+eta), -g K_cH P[c,c]/2, K_barcH b_H,
 the two width variations of Psi,and -u s O_delta.
For the scalar source,the affine heavy ghost term is zero by Ps O=0 and
the K_s eta_h c_H term by H complement invariance. Its ONE-heavy term
-g K_s(Xleft rho_M X)eta_s c_M is retained and can be nonzero.
K_QH has no single-heavy affine/linear term by P ad_H(1-P)=0;
K_cH has no c_H c_M term by the same closure;their remaining heavy terms
contain two heavy legs. K_barcH is only a light b source. The heavy width
vertices are chi1*barc_M*Dbar.Q_M and chi2*barc_M*O^T eta_h,plus their
ordered Gaussian descendants. No term has a light affine orbit. In -u sO,
the Q and scalar projectors are P and Ps. Q_H[Q_H,c_M]=0 by adjoint metric
invariance;eta_s^T rho_M eta_s=0 by antisymmetry,not by rho_M X=0.
The remaining heavy u terms contain Q_M c_M,eta_h c_M or c_M c_M.
The light u ghost cubic survives;it is not a whole scaleless integral zero.

To prove no additional leading source term rather than sample it,assign a
formal low-energy weight to every light jet equal to its displayed dimension
while holding positive-heavy parameters fixed. The implicit tree equations
give valuations eta_h>=2,Q_M>=3,c_M>=3,barc_M>=3. The only eta_h weight2
current is the actual potential T_hss eta_s²/2;its orbit component is zero
by the inherited stationary Ward/S3L/ASE proof. Gauge currents sourcing Q_M
start at eta_s D eta_s (weight3);affine mixing has one derivative and hence
cannot lower that bound. The ordinary one-heavy ghost currents vanish by(2)
and H closure. Induced eta_h c_H and chi2 eta_h currents start atweight3;
the K_s eta_s source of barc_M also starts at3. Remaining nonlinear vertices
increase these weights,so recursive solution preserves all4 bounds.

Substitution of the EXHAUSTIVE source families above then gives minimum
heavy-induced source weights:K_s eta_s c_M6;K_s eta_h c_M7;
K_QH Q_M c_M8;K_cH c_M²8;chi2 barc_M eta_h6;
chi1 barc_M DQ_M8;u Q_H Q_M c_M8;u eta_s eta_h c_M7;
u barc_H c_M²8;Gaussian chi1 chi2 barc_M²8.
This counts all source powers,not a truncation to one source:repeated heavy
EOM substitutions only increase weights. The source-independent eta_h²
term has weight4 and MUST be retained as ASE's induced quartic. Vector and
ghost elimination start atweight6. Thus every extra heavy-induced SOURCE
term has local dimension>=6 in this low-energy expansion. No claim that its
coefficient is zero is made. The full implicit functional(1) retains it.

## Leading light action and exact auxiliary contacts

Before light auxiliary elimination,the complete dimension<=4 result is
 S_H,YM+1/2(D_H eta_s)^2+lambda_E(H^T H)^2/4
 +s_ext[barc_H(Dbar.Q_H-x1 b_H/2)]
 +s_ext[u(Q_H²/2+eta_s²/2+barc_H c_H)]+K_L R_L.          (3)
R_L are the H-restricted maps in(2),with no scalar affine term. The qualified
neutral PQ action is zero;the Higgs carrier has Casimir9/10. Lambda_E is ASE's
measured0.104858242929586895...;its scalar exchange is inherited,not re-fit.
There is no leading chi2 vertex because O_H=0. Widths are in the same analytic
near1 family as EPC/NTS. The fixed-v gauge is not updated with eta_s.

For r=Dbar.Q_H and K=K_barcH,the exact light b Gaussian has bracket
 r+K-chi1*barc_H/2-u c_H
and gives its ordered square/(2x1). With external odd order u,chi1,barc,c,
this includes r²/(2x1)+Kr/x1+K²/(2x1)-chi1*barc*r/(2x1)
-chi1*K*barc/(2x1)-u*r*c/x1-u*K*c/x1+u*chi1*barc*c/(2x1).
The original -u Q_H Dbar c_H adds +u r c after IBP for constantu,leaving
u(1-1/x1)r c. Also retain -g*u*barc_H[c_H,c_H]/2. These K/chi/u contacts
must not be removed with the field-independent Gaussian normalization.
No K_b dependence is generated. The unbroken b split and its contour are
the inherited BFT ones,not a new positive real b integration.

## What is and is not closed

Equations(1)--(3) close the source-dependent heavy reduction prerequisite.
They do NOT prove that all relevant source soft loops match. The exact
higher-dimension remainder is retained for that next step. The inherited
LGF all-soft homogeneity argument excludes its ordinary local F² terms only
AFTER a complete common regulated subtraction;it is not applied here to
unsubtracted source graphs. One-loop hard relevant mass/kinetic/source
matching,positive-epsilon pole products,the nonlocal NVF light form factor,
and the one-/two-soft original-forest ownership remain actual dependencies.

Primary literature comparison:Fuentes-Martin et al2412.12270v2 section4.2.1,
eqs4.4--4.7 (https://arxiv.org/html/2412.12270v2#S4.SS2.SSS1),gives the heavy
quantum EOM and tree Schur construction including graded fields. Thomsen
2404.11640v2 section4.3 (https://arxiv.org/html/2404.11640v2#S4.SS3) warns
that ordinary broken-BF ghost/light Schur matching need not follow generally.
We check the specific tree source domain;we do not import its different
partially fixed gauge or infer the missing loop-region theorem from these
papers. Shared action/DR/Ward/forest/metric premises and AI authorship remain.
