# SHE1: source-preserving heavy reduction qualified within scope

The source-dependent heavy stationary reduction and its complete leading
dimension-four light tree action are qualified in the frozen formal BFT
domain. This closes a prerequisite of the actual full/EFT source comparison;
it does not close that entire comparison or establish physical C1.

Two native calculations and a separate verifier completed on their first
scientific executions. Receipt validation_receipt.json SHA256
2eaeca6270e57451936f11eadd8e3db0dab95a0b759397e527d39ce4445c62bf,
status QUALIFIED_SOURCE_DEPENDENT_HEAVY_REDUCTION_AND_LEADING_LIGHT_TREE.
Scientific/director acceptance NOT_PERFORMED;state113/34of39 unchanged.

## Actual-model result

All sources are retained through the heavy equations and derivatives. The
598 integrated fields after the auxiliary Gaussian split into77 light and
521 heavy directions (643=89+554 before it). Exact calculations using the
actual representation matrices,ordered ghost tensor and both native frames
establish H closure,soft/heavy invariance and the following full projections:

| Projection | Positions checked | Result |
| --- | ---: | --- |
| Soft affine orbit | 225 | Zero |
| Ordered O^T rho_H X | 2,700 | Zero,including the already-zero H rows |
| Light-antighost scalar vertex | 177,120 | Zero |
| Heavy part of unbroken bracket | 6,480 | Zero in the full45-row representation |
| Invariance of the light scalar carrier | 19,680 | Zero residual |

These are algebraic positions,not independent amplitudes or experimental
tests. The12 restricted scalar generators and all144 Lie relations also
agree with LGF. Its Higgs Casimir9/10 and neutral PQ action are preserved.

Crucially,the broken-generator action WITHIN the soft scalar carrier is
not zero:the complete projected tensor has36 nonzero positions. Setting it
to zero would erase an actual K_s eta_s c_M coupling. The proof retains
that term. Using the actual action's complete source families,the tree heavy
equations give eta_h>=weight2,Q_M/c_M/barc_M>=weight3. Consequently the extra
heavy-induced source terms start at local low-energy dimension6. This is
an action-based valuation proof for the entire formal tree solution,not a
finite sampling of source coefficients. The physical scalar exchange at
dimension4 remains and gives the inherited ASE lambda_E=0.104858242929586895...
with its bilinear metric. That quartic was authenticated,not recomputed here.

The leading source action therefore is the actual H gauge/scalar action,
its fixed-v linear FP gauge fermion,the same regulator doublet and the
H-restricted antifield transformations. It has no leading chi2 coupling.
Its exact light auxiliary Gaussian retains the K_barc square,K_barc*r,
K_barc*chi1*barc,K_barc*u*c and u*chi1*barc*c contacts. At constantu,the
ordinary u Q Dbar c term combines with the Gaussian to give
u(1-1/x1)r c. The light ghost cubic remains. Neither a Gaussian normalization
nor source restriction deletes these terms.

## Stationary pullback and two-loop bridge

For the actual full functional,restrict K_h=0 and solve Gamma_h=0 while
keeping K_L,u,chi. The graded envelope rule makes every retained derivative
equal to the corresponding full derivative on this surface. The heavy
Slavnov term vanishes by its EOM factor;the full NTS identity therefore pulls
back to the reduced light functional. This is stationary evaluation and
introduces no change-of-variables Jacobian.

Through loop order2,the complete reduced coefficient is

 Gred2=G2(h0)-1/2 <G1,h,H_hh^-1 G1,h>_graded.

Both the source-dependence of h0 and the derivatives of the inverse Hessian
are retained. Its source-zero F² cross gives the original -R M^-1 t bridge
once. This is distinct from the NTS Legendre removal of connected1PR graphs.
No new tadpole tensor or unknown two-loop width derivative was fitted here.

Native substitution and an independent exact heavy-square construction
agree. A separate Gaussian with different matrices/fields tests the envelope
rule and detects omitted bridge/source derivatives. The odd heavy pair gives
-A M^-1 B,also reproduced by an explicit finite Berezin expansion. These are
functional-calculus controls,not measured Spin10 loop amplitudes. Other
controls detect deleting the36-position broken action or the nonzero auxiliary
Kchi/Ku derivatives. The immutable DERIVATION supplies the analytic proof;
numerical checks alone would not establish its completeness.

## Execution,evidence and limitations

Primary/replay/verifier took71.5683527/45.3622236/3.0083629 seconds after
imports. Observed private-memory maxima were92,405,760/78,307,328/47,296,512
bytes with37/24/2 samples;these are sampled maxima,not continuous peaks.
All launches met350MiB available-commit floor;600s/8GiB/24MiB limits unchanged.
There were no scientific-worker,verifier or timeout failures in this increment.
Read-only attachment display initially hit Windows output encoding and was
reread as UTF8;it changed no inputs or calculation. No external agent was used.

Preparation binds5,701 inputs including NTS/LGF/ASE ancestry,current policy,
the director's two attachments and all prospective source copies. Validation
additionally authenticates completed outputs/captures. External complete
observations and raw/index/HEAD seals are in source-heavy-elimination-v1-2026-10-21
under the established research-control-records/ToE-Next location.

The delegated e4 readiness run completed its6 expected exits0,0,0,0,0,2.
Historical custody remains unresolved exit2 with seven references,NOTPASS.
All prior tracked bytes,failed records and authority are preserved;the seals
authenticate those bytes and this increment,not a fresh replay of all history.

This uses established stationary/Schur methods. The model-specific gain is
the complete source projection/valuation check and its light-contact domain.
Primary literature sections recorded in DERIVATION were consulted directly;
their general hard-matching statements are not imported as a certificate for
this ordinary broken-BF gauge. Shared action/representation/Ward/DR/ASE/LGF
premises,software and AI authorship remain. Root previously saw the historical
physical target;there is no blind-independence claim and no target fitting.

The higher-dimension source remainder is kept by the exact implicit reduction.
It has NOT been discarded within un-subtracted soft loops. Complete hard
one-loop source matching,positive-epsilon counterterm products and complete
one-/two-soft source-forest ownership remain open. NVF's nonlocal light source
kernel remains common before limits. No numerical C1,general gauge-width
independence,fermionic completion,E5/A5 or physical unification is established.

All9 bosonic amplitude inputs and the fixed-reference finite assembly remain
qualified in their existing scopes. The scalar140%local/1.94%Euclidean/
20.27%timelike warning,tree|a0|~0.76809>1/2,gauge residual0.745476/missing
Yukawas,quartetFAIL3960/648,paused matter/flavor and HB1/C5 block are unchanged.
The full Spin10xU1PQ investigation remains active and incomplete.
