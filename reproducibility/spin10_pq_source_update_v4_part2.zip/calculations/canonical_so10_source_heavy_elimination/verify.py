"""SHE1 separate full tensor audit,source derivatives and Berezin coefficients."""
from pathlib import Path
from hashlib import sha256
import gzip,json,os,sys,threading,time
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()))
started=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
sys.path.insert(0,str(CAL/'canonical_so10_finite_counterterm_insertion'))
from geometry_v2 import dec,red,tidy,zero,w
A=packed(HERE/'primary_tables.json.gz');B=packed(HERE/'replay_tables.json.gz')
for key in A:
    if key=='lambda_E_reused':continue
    assert A[key]==B[key],key
mp.mp.dps=65
assert abs(mp.mpf(A['lambda_E_reused'])-mp.mpf(B['lambda_E_reused']))<mp.mpf('1e-50')
assert mp.mpf('0.10485824292958')<mp.mpf(A['lambda_E_reused'])<mp.mpf('0.10485824292960')
metric=dec(A['scalar_metric']);actions=list(map(dec,A['light_scalar_actions']));F=dec(A['light_f'])
old=packed(CAL/'canonical_so10_light_gauge_tree_correspondence/primary_tables.json.gz')
zero(F-dec(old['light_f']));zero(metric-dec(old['scalar_bilinear_metric']))
for R,oldR in zip(actions,old['scalar_actions']):zero(R-dec(oldR))
for i,R in enumerate(actions):
    zero(R.T*metric+metric*R)
    for j,T in enumerate(actions):zero(R*T-T*R-sum((F[k,12*i+j]*actions[k] for k in range(12)),s.zeros(5)))
U=dec(A['all45_soft_scalar_action']);Um=dec(A['broken_soft_scalar_action'])
assert A['broken_soft_scalar_nonzero']==len(Um.todok())>0
for a in range(45):zero(U[:,5*a:5*a+5].T*metric+metric*U[:,5*a:5*a+5])
zero(dec(A['light_Casimir'])-dec(old['scalar_Casimir']))
assert A['zero_positions']=={'affine_soft_orbit':225,'T_MHsoft_with_zeroHrows':2700,'T_H_all':177120,'Lie_heavy_complement':6480,'scalar_H_invariance':19680}
counts=A['counts'];assert counts['full_before_b']==counts['light_before_b']+counts['heavy_before_b']==643
assert counts['full_after_b']==counts['light_after_b']+counts['heavy_after_b']==598

# Independent Grassmann multiplication by inversion count,including Berezin top degree.
def gp(a,b):
    if set(a)&set(b):return None,0
    return tuple(sorted(a+b)),(-1)**sum(i>j for i in a for j in b)
def multiply(F,G):
    out={}
    for a,x in F.items():
        for b,y in G.items():
            key,sign=gp(a,b)
            if sign:out[key]=s.expand(out.get(key,0)+sign*x*y)
    return {k:v for k,v in out.items() if v!=0}
def plus(*Fs):
    out={}
    for D in Fs:
        for k,v in D.items():out[k]=s.expand(out.get(k,0)+v)
    return {k:v for k,v in out.items() if v!=0}
def scale(F,c):return {k:s.expand(c*v) for k,v in F.items() if s.expand(c*v)!=0}
r,K,x1,m=s.symbols('r K x1 m');J={():r+K,(1,2):-s.Rational(1,2),(0,3):-1}
square=scale(multiply(J,J),1/(2*x1));expected={sum(1<<bit for bit in k):s.factor(v) for k,v in square.items()}
actual={mask:s.sympify(v,locals={'r':r,'K':K,'x1':x1}) for mask,v in A['auxiliary_square']}
assert set(actual)==set(expected)
for k in actual:assert s.simplify(actual[k]-expected[k])==0
assert actual[6].diff(K)==-1/(2*x1) and actual[9].diff(K)==-1/x1 and actual[15]==1/(2*x1)
total={mask:s.sympify(v,locals={'r':r,'K':K,'x1':x1}) for mask,v in A['auxiliary_with_u_IBP']}
assert s.simplify(total[9]-(-K/x1+r*(1-1/x1)))==0
assert s.simplify(total[6]-actual[6])==0

# Integral over ordered heavy z,barz. Sources A=e0,B=e1 stay external.
# exp[-(barz*m*z+barz*B+A*z)] terminates;ratio to source-free integral.
S={(2,3):-m,(1,3):-1,(0,2):1} # barz*z,barz*B,A*z in increasing order
exp={():1};power={():1}
for n in range(1,5):
    power=multiply(power,S);exp=plus(exp,scale(power,(-1)**n/s.factorial(n)))
det=exp[(2,3)];ratio_contact=s.simplify(exp[(0,1,2,3)]/det)
effective=-ratio_contact
assert effective==-1/m
assert s.simplify(s.sympify(A['odd_heavy_reduced'][0][1],locals={'m':m})-effective)==0

# Distinct2-heavy nonlinear-source example:raw stationary Taylor vs Schur result.
x,z,hb=s.symbols('x z hb');h,j=s.symbols('h j')
H=s.Matrix([[5,2],[2,7]]);N=s.Matrix([[2,-1],[-1,3]])
J0=s.Matrix([x*x+2*z,3*x-z]);v=s.Matrix([2*x-z,1+x*z]);q=s.Matrix([z-1,2+z])
h0=-H.inv()*J0;h1=-H.inv()*(v+N*h0);h2=-H.inv()*(N*h1+q)
fields=s.Matrix([h,j]);S=(fields.T*H*fields)[0]/2+(J0.T*fields)[0]
one=(v.T*fields)[0]+(fields.T*N*fields)[0]/2;two=(q.T*fields)[0]
sub=dict(zip(fields,h0+hb*h1+hb**2*h2))
direct=s.expand((S+hb*one+hb**2*two).subs(sub,simultaneous=True)).coeff(hb,2)
J1=v+N*h0;bridge=-(J1.T*H.inv()*J1)[0]/2
assert s.expand(direct-two.subs(dict(zip(fields,h0)),simultaneous=True)-bridge)==0
for a in [x,z]:
    lhs=s.expand(s.diff((S+hb*one+hb**2*two).subs(sub,simultaneous=True),a)).coeff(hb,2)
    rhs=s.expand(s.diff(S+hb*one+hb**2*two,a).subs(sub,simultaneous=True)).coeff(hb,2)
    assert s.expand(lhs-rhs)==0
missing_bridge=s.expand(bridge).coeff(z,1);assert missing_bridge!=0
source_first=s.expand(direct).coeff(z,1);assert source_first!=0
# Heavy EOM envelope is essential:an arbitrary nonstationary section leaves this.
nonstationary=s.diff(S,h).subs({h:x,j:0});assert s.expand(nonstationary)!=0
assert A['heavy_valuations']=={'scalar':2,'vector':3,'ghost':3,'antighost':3}
assert min(A['source_term_min_weights'].values())==6 and len(A['source_term_min_weights'])==10
receipt={'schema':'SHE1_VALIDATION','status':'QUALIFIED_SOURCE_DEPENDENT_HEAVY_REDUCTION_AND_LEADING_LIGHT_TREE',
 'execution_state':'COMPLETED','scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED',
 'full_carrier_exact_projections':A['zero_positions'],'broken_soft_scalar_nonzero_positions':A['broken_soft_scalar_nonzero'],
 'all12_light_scalar_Lie_actions_and144_relations':True,'full_source_family_census':True,
 'heavy_field_counts':counts,'all10_minimal_heavy_source_weights':A['source_term_min_weights'],
 'light_auxiliary_K_chi_u_contacts_retained':True,'source_stationary_envelope_and_loop2_bridge':True,
 'graded_ghost_stationary_and_Berezin_sign':str(effective),'lambda_E_inherited_not_new_measurement':A['lambda_E_reused'],
 'negative_controls':{'discard_broken_soft_action_positions':A['broken_soft_scalar_nonzero'],
 'omit_Kchi_auxiliary_derivative':'-1/(2*x1)','omit_Ku_auxiliary_derivative':'-1/x1',
 'omit_two_loop_bridge_source_coefficient':str(s.factor(missing_bridge)),
 'sources_zero_before_derivative_loses':str(s.factor(source_first)),
 'nonstationary_section_EOM_remainder':str(s.expand(nonstationary)),
 'commuting_odd_source_order_changes_sign':True},
 'higher_dimension_source_remainder_kept_in_implicit_functional':True,
 'full_hard_one_loop_matching_and_one_two_soft_source_ownership_qualified':False,
 'finite_numerical_C1_gauge_independence_E5_A5_physical_unification_qualified':False,
 'shared_error_limits':['BFT action/reference/representations','EPC/NTS DR and Ward premises','ASE/LGF scalar matching and local chart','SymPy/reducer/software','AI authorship'],
 'elapsed_after_imports':time.perf_counter()-started}
print('RESULT '+json.dumps(receipt,sort_keys=True),flush=True)
