"""V3S1 exact vertex, background, full orbit/charge and marked-cut validation."""
from data import *
def main():
    start=begin('validation_preparation.json');A,B=[packed(HERE/f'{r}_tables.json.gz') for r in ['primary','replay']]
    assert A['color_triples']==B['color_triples'] and A['rows']==B['rows']
    assert A['Bose_component_checks']==384 and A['general_D_norm']=='3*(D-1)*(p2+q2+r2)'
    for name in ['flat_samples_over_i_g','background_samples_over_g2_nonzero']:
        assert set(A[name])==set(B[name]) and all(clean(s.sympify(v)-s.sympify(B[name][k]))==0 for k,v in A[name].items()),name
    assert len(A['flat_samples_over_i_g'])==256 and A['background_sample_positions']==B['background_sample_positions']==12288
    bgcount=len(A['background_samples_over_g2_nonzero']);assert bgcount>0
    # Two coincident color labels have zero flat f but a nonzero covariant vertex.
    assert all(s.sympify(v)==0 for k,v in A['flat_samples_over_i_g'].items() if k.startswith('1|'))
    assert any(k.startswith('1|') for k in A['background_samples_over_g2_nonzero'])
    rows={tuple(v['roles']):v for v in A['rows']};assert len(rows)==125
    orbits={}
    for key,row in rows.items():
        for pi in permutations(range(3)):
            other=rows[tuple(key[i] for i in pi)];assert s.sympify(row['norm'])==s.sympify(other['norm'])
            assert all(s.sympify(other['charges'][3*j+k])==s.sympify(row['charges'][3*j+pi[k]]) for j in range(3) for k in range(3))
        if s.sympify(row['norm']):orbits.setdefault(tuple(sorted(key)),[]).append(key)
    assert len({tuple(sorted(key)) for key in rows})==35
    assert [(v['roles'],v['size']) for v in B['orbits']]==[(list(k),len(v)) for k,v in sorted(orbits.items())]
    assert {k:len(v) for k,v in orbits.items()}=={(0,0,0):1,(0,1,1):3,(0,3,3):3,(0,4,4):3,(1,1,2):3,(1,3,4):6,(2,4,4):3}
    assert sum(len(v) for v in orbits.values())==22 and sum(s.sympify(v['norm']) for v in rows.values())==360
    assert all(sum(s.sympify(v['charges'][3*i+k]) for v in rows.values())==64 for i in range(3) for k in range(3))
    assert A['background_words']==B['background_words'] and len(A['background_words'])==29
    assert A['Wick_weight']==B['Wick_weight']=='-1/12'
    # Independent Gaussian/marked-cut algebra, not a measured UV subgraph.
    G,t=s.symbols('G t');Gamma=-t*t*G**3/12;Sigma=-t*t*G*G/2;closure=-G*Sigma/2
    assert clean(-G*s.diff(Gamma,G)-closure)==0 and clean(3*(closure/3)-closure)==0
    triple_change=clean(3*closure-closure);assert triple_change!=0
    factor=s.Rational(6,2*s.factorial(3)**2);assert factor==s.Rational(1,12)
    src=source('primary');changed=[0,0,0]
    for key,row in rows.items():
        norm=s.sympify(row['norm'])
        for i in range(3):
            for leg,slot in enumerate(key):changed[i]+=s.sympify(row['charges'][3*i+leg])!=norm*s.sympify(src['sector_averaged_Cv'][slot][i])
    assert all(v>0 for v in changed)
    # Deleting an actual Lorentz vertex term changes the flat norm diagnostic.
    pp,qq,rr=PTEST;original=mutated=0
    for aa,bb,cc in product(range(4),repeat=3):
        term=(pp[cc]-qq[cc] if aa==bb else 0);value=term+(qq[aa]-rr[aa] if bb==cc else 0)+(rr[bb]-pp[bb] if cc==aa else 0)
        original+=value*value;mutated+=(value-term)**2
    assert original!=mutated
    ee,pm=s.symbols('eps pm');earlyD=clean(3*((4-2*ee)-1)*pm-9*pm);assert earlyD==-6*ee*pm
    controls={'symmetrize_color_without_momentum_labels':'KILLS720_NONZERO_INPUT_F_ENTRIES','omit_one_Lorentz_term_norm_change':str(mutated-original),
      'delete_background_vertex_nonzero_samples_lost':bgcount,'ghost_instead_of_real_Wick_factor_change':str(s.Rational(1,2)+factor),
      'duplicate_full_opened_vector_cut_on_three_labels':str(triple_change),'early_D4_lost_term':str(earlyD),
      'average_mass_sector_charge_changed_positions_by_ideal':changed,'omit_light_support_profiles':10}
    native=[]
    for role in ['primary','replay']:
        c=json.loads((HERE/f'{role}_capture.json').read_bytes());r=json.loads((HERE/f'{role}_result.json').read_bytes());blob=(HERE/f'{role}_tables.json.gz').read_bytes()
        assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
        assert sha256(blob).hexdigest()==r['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['tables_sha256']
        peak=max(v['private_bytes'] for v in c['all_resource_samples']);assert peak<=8*1024**3 and c['launch']['memory']['available_pagefile']>=350*1024**2 and r['elapsed_after_imports']<600
        native.append({'role':role,'seconds':r['elapsed_after_imports'],'sampled_private_max':peak})
    assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<6*1024**2
    out={'schema':'V3S1_VALIDATION','status':'QUALIFIED_ACTUAL_THREE_VECTOR_VERTEX_AND_COMPLETE_MASS_CHARGE_SUPPORT','execution_state':'COMPLETED',
      'flat_components_compared':256,'background_sample_positions':12288,'background_sample_nonzero':bgcount,'background_sample_zero':12288-bgcount,
      'background_scope':'EXACT_FULL_TENSOR_RECIPE_PLUS_FOUR_COLOR_TRIPLE_DIAGNOSTICS; NOT_FULL_COMPONENT_EXPANSION','Bose_component_checks':384,
      'norm_dimension_diagnostics':B['norm_dimension_diagnostics'],'sector_triples':125,'supported_ordered_profiles':22,'zero_profiles':103,
      'total_unordered_orbits':35,'supported_unordered_orbits':7,'heavy_kernel_mass_orbits':3,'one_light_kernel_mass_orbits':3,'all_light_orbits':1,
      'orbits':B['orbits'],'Wick_weight':'-1/12','labelled_background_words':29,'controls':controls,'native_runs':native,
      'new_finite_kernel_or_UV_cut_measured':False,'VVV_amplitude_calculated':False,'qualified_primitive_amplitude_inventory':6,
      'full_C1_or_E5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED',
      'shared_limits':['YM action','authenticated full color/mass/charge data','reference','software','AI authorship'],'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
if __name__=='__main__':main()
