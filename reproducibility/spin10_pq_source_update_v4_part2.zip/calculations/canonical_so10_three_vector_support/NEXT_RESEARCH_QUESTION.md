# Next: complete ordered VVV kernel and original proper subtractions

GVA1 closes ghostV at its declared graph-local matched stage; amplitude
inventory6/9. V3S1 now fixes actual VVV density, Fourier sign, Bose symmetry,
three heavy mass orbits, single-light equal-heavy domain and full29 ordered
background words. Reuse BFT/GVS inputs and V3S1; do not repeat full color
contractions or launch a component expansion of all125 profiles.

Derive the actual general-D F2 heat/proper-time polynomial for THREE spin-one
propagators and two covariant derivative cubic vertices. Retain both vertex
background derivatives, all matrix orders, propagator seagulls, noncommuting
spin factors and positive auxiliary delta. The flat norm3(D-1)sum p^2 is a
normalization control, not the full F2 kernel. In particular, a flat color
component can be0 while its first covariant background derivative is nonzero.

Use a sensitive small nonzero background component or exact polynomial to
compare two distinct construction routes before evaluating actual mass keys.
Exploit three-vector permutation symmetry only after its charge/momentum
roles are retained. Do not import ghostV's finite kernel or Wick normalization.

Derive/isolate original cubic-vector UV self-energy cuts from actual vertices.
Qualified QDV and QMV VECTOR rows include quartic seagulls: use their declared
class decomposition and the qualified isolated quartic class to separate
the cubic part where justified. A flat two-point pole does not determine a
missing curvature coefficient. Verify completeness of that isolation instead
of fitting a remainder. The full real-vector cut counts three labelled
closures; do not apply it three times.

Then establish proper forest/positive-mass kernel, single-light full/EFT
matching and all-light H cancellation in the same reference. Keep Cfull
before any soft cancellation and the eventual Cparent-Cfamily complement.
No new finite physical scheme, paused matter, authority promotion or protected
HB1/C5 activation is required or authorized. Full C1/E5/A5 remain unqualified.
