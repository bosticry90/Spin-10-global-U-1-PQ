# V3S1: actual cubic recipe and required kernel domain

With normalized antihermitian10-plane generators, -Tr(Ta Tb)=delta_ab and
[Ta,Tb]=f_ab^c Tc. BFT1's Yang--Mills action is -Tr(F_mn F_mn)/4, with
F=Fbar+Dbar Q-Dbar Q+g[Q,Q]. Its cubic density is

    S3=g f_bc^a(Dbar_mu Q_nu)^a Q_mu^b Q_nu^c.

For three labelled colors(a,b,c), Lorentz indices(alpha,beta,gamma) and
incoming momenta(p,q,r), six derivatives of this literal density give

    C3=-i g f_abc L_alpha,beta,gamma,
    L=delta_ab(p-q)_gamma+delta_bc(q-r)_alpha+delta_ca(r-p)_beta.

Here the deltas have Lorentz indices only. The color tensor f and L are
each antisymmetric under leg transposition; their product is Bose symmetric.
Symmetrizing f without its momentum/Lorentz labels would incorrectly kill
the vertex. The tensor recipe covers all45 colors through the authenticated
full f table. Its explicit first background derivative follows by replacing
the derivative on legl with g ad(H) acting on that color, BEFORE summing
all six leg assignments. No flat Ward completion is used to define it.

The independent matrix-curvature calculation uses the curl/[Q,Q] cross term.
For legl and its other two labelled legsu,v, it contracts
-Tr(T_l[T_u,T_v])/2 with the linear curl and antisymmetrized two-polarization
tensor. Replacing T_l by [H,T_l] and momentum by the background Lorentz delta
gives the actual background vertex. This tests the density differentiation
and Fourier sign, while sharing the frozen YM action and color convention.

Let A=p-q,B=q-r,C=r-p, so A+B+C=0. The complete Lorentz contraction is

    sum L^2=D(A^2+B^2+C^2)+2(A.B+B.C+C.A)
           =3(D-1)(p^2+q^2+r^2),  p+q+r=0.

Keep D=4-2eps. The -6eps times momentum-squared term can affect finite
Laurent coefficients. This flat contraction alone is NOT the F2 heat kernel:
three vector spin factors, noncommuting ordering, derivative vertices,
background vertices and seagulls still have to be included in all29 words.

The actual color/mass tensor is the same f with three vector slots, so GVS1's
signed negative ghost trace is converted to its positive real norm. Its full
three edge charges permute with all three identical vector legs. The 22
nonzero ordered profiles form seven supported unordered triples:

    (0,0,0), (0,1,1), (0,3,3), (0,4,4),
    (1,1,2), (1,3,4), (2,4,4).

Their orbit sizes are1,3,3,3,3,6,3. Thus the future positive-mass universal
kernel needs only three actual unordered mass keys and one equal-heavy
single-light kernel with permuted charge axes. Each mass-sector charge matrix
remains the actual one; the reduction does not replace it with an average.
All-light restriction is the actual H YM/linear gauge-fixing tree reference,
not an arbitrary massless theory. Its finite subtraction still requires the
appropriate original family forest; this increment does not calculate it.

The real cubic1PI vacuum term is -T^2 G0 G1 G2/12. Six cross-edge Wick
pairings give6/[2(3!)^2]=1/12; nine1PR bridge pairings are removed by the
Legendre source, not declared zero. The full opened real-vector self-energy
counts all three identical edge embeddings. If labelled edge closures are
listed, each gets one third of the full insertion. Closing the full insertion
once with the real1/2 trace agrees with summing all three labelled forests;
closing the full result separately on every label would triple it. This is
a combinatorial statement, not a calculated UV coefficient.

Next derive the full ordered general-D F2 kernel and original cubic-vector
UV subgraphs. Existing QDV/QMV TOTAL vector contributions include quartic
seagulls; the VVV class needs their correctly isolated cubic part. Do not
reuse a total vector pole or the ghost cut count without this separation.
Then compare a small nonzero background coefficient before model assembly.
