"""V3S1 exact actual color inputs and exclusive bounded IO."""
from pathlib import Path
from hashlib import sha256
from itertools import permutations,product
import json,gzip,sys,time,threading,os,importlib.util
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
def clean(v):return s.cancel(s.expand(v))
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def load(n,p):
    spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def begin(prep='preparation.json'):
    start=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for p,h in json.loads((HERE/prep).read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
    return start
def save(role,v,start):
    raw=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/f'{role}_tables.json.gz').open('xb') as f:f.write(blob)
    print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':time.perf_counter()-start,'tables_sha256':sha256(raw).hexdigest(),
      'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)
def sign(pi):return (-1)**sum(pi[i]>pi[j] for i in range(3) for j in range(i+1,3))
def source(role):return packed(CAL/'canonical_so10_ghost_vector_support'/f'{role}_tables.json.gz')
def support(role):
    src=source(role);out={}
    for row in src['rows']:
        key=(row['vector'],row['antighost_edge'],row['ghost_edge'])
        out[key]={'norm':-s.sympify(row['signed_raw']),'charges':[-s.sympify(v) for v in row['signed_charges_ideal_then_leg']]}
    return src,out
def actual(role):
    old=load('v3s_gvs_'+role,CAL/'canonical_so10_ghost_vector_support/data.py')
    f=old.f_table(role);src=source(role);F=[s.SparseMatrix(45,45,{(a,b):s.sympify(v) for dd,a,b,v in src['F'] if dd==d}) for d in range(45)]
    V=old.dec(packed(CAL/'canonical_so10_vector_quartic_ir_matching'/f'{role}_tables.json.gz')['light_embedding'])
    ad=[sum((V[a,h]*F[a] for a in range(45) if V[a,h]),s.zeros(45)) for h in range(12)]
    c,b=next((c,b) for (c,b),v in ad[0].todok().items() if v)
    a=next(a for a in range(45) if V[a,0]*f.get((a,b,c),0)!=0)
    triples=[(a,b,c),(b,b,a),(a,b,b),(b,b,b)]
    return f,V,ad,triples
PTEST=[[1,2,3,5],[-2,4,1,-3],[1,-6,-4,-2]]
