"""V3S1 six derivatives of the actual cubic density and permutation proof."""
from data import *
def density(indices,mom):
    total=0
    for pi in permutations(range(3)):
        l,m,n=pi
        if indices[l]==indices[n]:total+=sign(pi)*mom[l][indices[m]]
    return clean(total)
def standard(indices,mom):
    a,b,c=indices;p,q,r=mom
    return (p[c]-q[c] if a==b else 0)+(q[a]-r[a] if b==c else 0)+(r[b]-p[b] if c==a else 0)
def main():
    start=begin();mom=[s.symbols(f'p0:4'),s.symbols(f'q0:4'),s.symbols(f'r0:4')];tensor={};bose=0
    for indices in product(range(4),repeat=3):
        v=density(indices,mom);assert clean(v+standard(indices,mom))==0;tensor[str(indices)]=str(v)
        for pi in permutations(range(3)):
            vv=density([indices[i] for i in pi],[mom[i] for i in pi]);assert clean(sign(pi)*vv-v)==0;bose+=1
    # General-D Kronecker trace, with the independent p,q Gram variables.
    D,u,v,w=s.symbols('D u v w');squares=6*(u+v+w);cross=-squares/2;norm=clean(D*squares+2*cross)
    assert clean(norm-6*(D-1)*(u+v+w))==0
    src,rows=support('primary');permuted=0
    for key,row in rows.items():
        for pi in permutations(range(3)):
            other=rows[tuple(key[i] for i in pi)];assert row['norm']==other['norm']
            assert all(other['charges'][3*j+k]==row['charges'][3*j+pi[k]] for j in range(3) for k in range(3));permuted+=1
    f,V,ad,triples=actual('primary');flat={};bg={}
    for no,cols in enumerate(triples):
        for indices in product(range(4),repeat=3):
            flat[f'{no}|'+','.join(map(str,indices))]=str(clean(f.get(cols,0)*density(indices,PTEST)))
            for h in range(12):
                for kappa in range(4):
                    val=0
                    for pi in permutations(range(3)):
                        l,m,n=pi
                        if indices[m]==kappa and indices[l]==indices[n]:
                            val+=sum(ad[h][t,cols[l]]*f.get((cols[m],cols[n],t),0) for t in range(45))
                    val=clean(val)
                    if val:bg[f'{no}|{h}|{kappa}|'+','.join(map(str,indices))]=str(val)
    inv=load('v3s_inventory',CAL/'canonical_so10_background_threshold_inputs/inventory.py');summary,words=inv.build('primary')
    assert ['VVV','-1/12',29] in summary['families']
    save('primary',{'schema':'V3S1_PRIMARY','tensor_over_minus_i_g_f':{k:str(-s.sympify(v)) for k,v in tensor.items()},'Bose_component_checks':bose,
      'general_D_norm':'3*(D-1)*(p2+q2+r2)','flat_samples_over_i_g':flat,'background_samples_over_g2_nonzero':bg,
      'background_sample_positions':4*12*4*64,'color_triples':list(map(list,triples)),
      'rows':[{ 'roles':list(key),'norm':str(row['norm']),'charges':list(map(str,row['charges']))} for key,row in sorted(rows.items())],
      'background_words':words['VVV'],'Wick_weight':'-1/12','kernel_or_amplitude_calculated':False},start)
if __name__=='__main__':main()
