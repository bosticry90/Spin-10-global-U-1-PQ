"""V3S1 matrix-curvature curl/bracket coefficients and explicit Lorentz sums."""
from data import *
def curl_contract(pol,mom,kappa=None):
    total=0
    for mu in range(4):
        for nu in range(4):
            c=(mom[mu]*(nu==pol[0])-mom[nu]*(mu==pol[0])) if kappa is None else ((mu==kappa)*(nu==pol[0])-(nu==kappa)*(mu==pol[0]))
            b=(mu==pol[1])*(nu==pol[2])-(mu==pol[2])*(nu==pol[1]);total+=c*b
    return total
def main():
    start=begin();src,rows=support('replay');f,V,ad,triples=actual('replay');planes=[]
    for a in range(10):
        for b in range(a+1,10):
            T=s.zeros(10);T[a,b]=1/s.sqrt(2);T[b,a]=-1/s.sqrt(2);planes.append(T)
    H=[sum((V[a,h]*planes[a] for a in range(45) if V[a,h]),s.zeros(10)) for h in range(12)]
    flat={};bg={};norms=[]
    for no,cols in enumerate(triples):
        Ts=[planes[a] for a in cols];colors={};bcolors={}
        for l in range(3):
            u,v=[k for k in range(3) if k!=l];comm=Ts[u]*Ts[v]-Ts[v]*Ts[u]
            colors[l]=clean(-s.trace(Ts[l]*comm)/2)
            for h in range(12):bcolors[h,l]=clean(-s.trace((H[h]*Ts[l]-Ts[l]*H[h])*comm)/2)
        for indices in product(range(4),repeat=3):
            vv=0
            for l in range(3):
                u,v=[k for k in range(3) if k!=l];vv+=colors[l]*curl_contract([indices[l],indices[u],indices[v]],PTEST[l])
            flat[f'{no}|'+','.join(map(str,indices))]=str(clean(vv))
            for h in range(12):
                for kappa in range(4):
                    vv=0
                    for l in range(3):
                        u,v=[k for k in range(3) if k!=l];vv+=bcolors[h,l]*curl_contract([indices[l],indices[u],indices[v]],PTEST[l],kappa)
                    vv=clean(vv)
                    if vv:bg[f'{no}|{h}|{kappa}|'+','.join(map(str,indices))]=str(vv)
    for dim in range(2,7):
        pp=list(range(1,dim+1));qq=[(-1)**k*(2*k+3) for k in range(dim)];rr=[-a-b for a,b in zip(pp,qq)];value=0
        for a,b,c in product(range(dim),repeat=3):
            tensor=(pp[c]-qq[c] if a==b else 0)+(qq[a]-rr[a] if b==c else 0)+(rr[b]-pp[b] if c==a else 0);value+=tensor*tensor
        target=3*(dim-1)*sum(v*v for p in [pp,qq,rr] for v in p);assert value==target;norms.append([dim,value])
    # Independent orbit census, not the primary permutation comparison.
    orbits={}
    for key,row in rows.items():
        if row['norm']:
            orbit=tuple(sorted(key));orbits.setdefault(orbit,[]).append(key)
    inv=load('v3s_inventory_replay',CAL/'canonical_so10_background_threshold_inputs/inventory.py');summary,words=inv.build('replay');assert ['VVV','-1/12',29] in summary['families']
    save('replay',{'schema':'V3S1_REPLAY','flat_samples_over_i_g':flat,'background_samples_over_g2_nonzero':bg,'background_sample_positions':4*12*4*64,
      'color_triples':list(map(list,triples)),'norm_dimension_diagnostics':norms,
      'rows':[{ 'roles':list(key),'norm':str(row['norm']),'charges':list(map(str,row['charges']))} for key,row in sorted(rows.items())],
      'orbits':[{ 'roles':list(k),'size':len(v)} for k,v in sorted(orbits.items())],'background_words':words['VVV'],'Wick_weight':'-1/12'},start)
if __name__=='__main__':main()
