# V3S1: actual three-vector vertex and complete mass/charge support

Base d7e1911f/main; previous goal turn PROGRESS. GVA1 has now completed the
ghost-vector amplitude within scope; six of nine primitive inputs exist.
The next missing gauge family is VVV. Question: what are its actual symmetric
three-vector vertex, mass-role support and background-insertion domain, before
attempting a finite integral or importing a ghost counterterm normalization?
Cheapest competent test: differentiate the literal BFT1 YM cubic density,
rederive it from the matrix curvature action, reuse qualified GVS color/mass
contractions, and prove the complete three-leg permutation/orbit reduction.

Fixed BFT1 xi1 C1 reference; no nonlinear E1 quartic ghosts. S_YM=F^2/4,
Dbar=partial+g ad(Abar), all45 real vectors and twelve unbroken H backgrounds.
The linear gauge-fixing density is quadratic in vectors, so contributes no
QQQ vertex. Actual cubic density is g f_bc^a(Dbar_mu Q_nu)^a Q_mu^b Q_nu^c.
External momenta remain distinct until momentum conservation is explicitly
used; never substitute a constant gauge potential for the local F2 target.

Freeze sources and authenticated BFT1/GVS1 input hashes before computation.
Primary differentiates six labelled cubic monomials, proves the full Bose
symmetry, symbolic Lorentz norm and general-D trace. Replay starts with
-Tr(F_mn F_mn)/4 in actual normalized10-plane matrices and its curl/bracket
cross term. It tests all64 Lorentz components at four actual color triples,
and the background derivative at all12 H directions, four background Lorentz
directions and64 quantum components for those triples. This is a diagnostic
component sample plus an exact general tensor derivation, not a fresh expansion
of every model/background component. Imported full45 f/charge proofs are
authenticated/reused, not independently recomputed here.

Compare exact coefficient dictionaries and zero complements. Reuse the full
125 actual mass triples with positive f-norm charge weights; prove all six
permutations,35 total unordered mass orbits, seven supported orbits, and the
resulting three all-heavy and three one-light orbits plus one H EFT orbit.
Retain three distinct edge charge weights, including within degenerate mass
sets. Derive the full real-vector sunset -1/12 and three marked-cut counting
from the Gaussian/Legendre topology; it is not the complex ghost+1/2 rule.
The two-loop background census must retain all29 labelled ordered words.

Controls: symmetrize color alone, omit one Lorentz term, delete the covariant
background vertex, replace the real-vector Wick factor with the ghost factor,
duplicate the full self-energy on all three labelled closures, average charges
in a vector mass sector, drop light support or set D=4 before epsilon jets.
No finite kernel, actual UV cut pole or Ward cancellation is inferred.

Sequential primary/replay then separately frozen verifier,600s each,
8GiB sampled private,350MiB launch floor,6MiB package, exclusive complete
captures. Preserve failures and unfinished evidence. Outcomes: qualified
actual vertex/support reduction, counterexample, underdefinition or inconclusive.
This is preparation for VVV, not completed primitive7. No physical scheme,
foundation or point change, protected activation, paused matter, state edit,
publication/push/outreach. State113/34of39 unchanged;acceptance NOT_PERFORMED.
Shared action/color inputs, reference, software and AI authorship limit
independence; no independent scientist or experimental confirmation.
