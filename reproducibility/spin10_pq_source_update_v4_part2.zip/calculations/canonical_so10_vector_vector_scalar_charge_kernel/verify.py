"""VVK1 full-domain validation and independent support/matrix-trace probes."""
from data import *
def parse(v):return s.sympify(v,locals={'w':w})
def main():
    start=begin('validation_preparation.json')
    for p,h in json.loads((HERE/'preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
    A,B=[packed(HERE/f'{r}_tables.json.gz') for r in ['primary','replay']]
    for k in ['schema','basis','operator_names','scalar_Casimir_averages','vector_Casimir_operators','mass_sector_averaged_Casimir','actual_Rh_O_intertwiners_checked','domain_positions','scalar_dimension','classes']:
        assert A[k]==B[k],k
    assert A['domain_positions']==30975 and len(A['basis'])==177 and A['scalar_dimension']==328 and A['classes']==35
    native=[]
    for role in ['primary','replay']:
        c=json.loads((HERE/f'{role}_capture.json').read_bytes());r=json.loads((HERE/f'{role}_result.json').read_bytes())
        assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
        blob=(HERE/f'{role}_tables.json.gz').read_bytes();assert sha256(blob).hexdigest()==r['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['tables_sha256']
        peak=max(v['private_bytes'] for v in c['all_resource_samples']);assert peak<=8*1024**3 and c['launch']['memory']['available_pagefile']>=350*1024**2 and r['elapsed_after_imports']<600
        native.append({'role':role,'seconds':r['elapsed_after_imports'],'sampled_private_max':peak})
    ops={};nonzero=0
    assert set(A['operators'])==set(B['operators'])=={f'{r},{t}' for r in range(5) for t in range(5)}
    for k in A['operators']:
        aa=[[parse(v) for v in row] for row in A['operators'][k]];bb=[[parse(v) for v in row] for row in B['operators'][k]]
        assert len(aa)==len(bb)==7 and all(len(row)==177 for row in aa+bb)
        for row,row2 in zip(aa,bb):
            for v,z in zip(row,row2):assert red(v-z)==0 and not v.atoms(s.Float);nonzero+=v!=0
        ops[k]=aa
    values,fci,scm=inputs('primary');action,rho,V,ad,Ps,frame,Q,Qi,E=values;units=basis(frame)
    assert units==[tuple(v) for v in A['basis']];address={u:i for i,u in enumerate(units)}
    cs=[[parse(v) for v in row] for row in A['scalar_Casimir_averages']];av=[[parse(v) for v in row] for row in A['mass_sector_averaged_Casimir']]
    C=list(map(dec,A['vector_Casimir_operators']))
    for r,P in enumerate(Ps):
        for k,M in enumerate(C):assert red(s.trace(P*M)-s.trace(P)*av[r][k])==0
    small={};offdiag=0;rolechange=0;averagechanges=[0,0,0]
    for r in range(5):
        for t in range(5):
            key=f'{r},{t}';vv=ops[key];small[key]=[]
            for row in vv:
                mats=[]
                for alpha,b in enumerate(frame['blocks']):
                    m=b['multiplicity'];M=s.SparseMatrix(m,m,{(i,j):row[address[alpha,i,j]] for i in range(m) for j in range(m)})
                    zero(M-M.H);mats.append(M);offdiag+=sum(i!=j and v!=0 for (i,j),v in M.todok().items())
                small[key].append(mats)
            for j in range(177):
                assert red(vv[0][j]-ops[f'{t},{r}'][0][j])==0
                for k in range(3):
                    assert red(vv[1+k][j]-ops[f'{t},{r}'][4+k][j])==0
                    averagechanges[k]+=red(vv[1+k][j]-av[r][k]*vv[0][j])!=0
                    rolechange+=red(vv[1+k][j]-vv[4+k][j])!=0
    assert offdiag>0 and rolechange>0 and sum(averagechanges)>0
    dualchanges=sum(red(parse(z)-v)!=0 for key,row in B['wrong_dual_raw'].items() for v,z in zip(ops[key][0],row))
    # Some projections can legitimately be insensitive; retain exact counts.
    types=small_types(fci);counts=[red(sum(b['dimension']*s.trace(P) for b,P in zip(frame['blocks'],row))) for row in types]
    assert counts==[290,5,8,1,12,12]
    support=packed(CAL/'canonical_so10_vector_vector_scalar_support/primary_tables.json.gz')
    norms={(p['first_vector'],p['second_vector'],p['scalar_type']):parse(p['norm_squared']) for p in support['norms']}
    pps=[{(p['first_vector'],p['second_vector'],p['scalar_type']):p for p in tab['probes']} for tab in [A,B]]
    assert all(len(v)==150 for v in pps)
    rawprofiles=[];charged=[];excluded=[];Hdiag=0
    for r in range(5):
        for t in range(5):
            mats=small[f'{r},{t}']
            for typ,Prow in enumerate(types):
                direct=[red(sum((b['dimension']*s.trace(M*P) for b,M,P in zip(frame['blocks'],row,Prow)),s.S.Zero)) for row in mats]
                scalar=[red(sum((b['dimension']*cs[a][k]*s.trace(M*P) for a,(b,M,P) in enumerate(zip(frame['blocks'],mats[0],Prow))),s.S.Zero)) for k in range(3)]
                for probes0 in pps:
                    p=probes0[r,t,typ];want=list(map(parse,[p['raw'],*p['q1_squared'],*p['q2_squared']]))
                    assert all(red(a-b)==0 for a,b in zip(direct,want))
                    assert all(red(a-parse(b))==0 for a,b in zip(scalar,p['qscalar_squared']))
                assert red(direct[0]-norms[r,t,typ])==0
                if direct[0]!=0:rawprofiles.append([r,t,typ])
                else:assert all(v==0 for v in direct+scalar);excluded.append([r,t,typ])
                if any(v!=0 for v in direct[1:]+scalar):charged.append([r,t,typ])
            Hs=[dec(b['H']) for b in fci['blocks']]
            for row in mats:
                value=red(sum((b['dimension']*s.trace(M*(H-s.diag(*H.diagonal()))) for b,M,H in zip(frame['blocks'],row,Hs)),s.S.Zero));Hdiag+=value!=0
    assert len(rawprofiles)==len(json.loads((CAL/'canonical_so10_vector_vector_scalar_support/validation_receipt.json').read_bytes())['supported_profiles'])
    # Independent Goldstone Ward reconstruction from f and mass differences.
    O=dec(action['vacuum']['orbit']);Gram=tidy(O.T*O)
    lam=[s.S.Zero,s.Rational(3,10),s.Rational(3,2),s.Integer(25),s.Rational(253,10)]
    zero(Gram-sum((v*P for v,P in zip(lam,Ps)),s.SparseMatrix(45,45,{})))
    ft=packed(CAL/'canonical_so10_background_threshold_inputs/replay_tables.json.gz')['f']
    F=s.SparseMatrix(2025,45,{(a*45+b,c):s.sympify(v) for a,b,c,v in ft})
    I=s.SparseMatrix(s.eye(45));massdiff=s.kronecker_product(Gram,I)-s.kronecker_product(I,Gram)
    zero(tensor('primary',action,rho)*O-massdiff*F)
    for ell in range(1,5):
        Pfull=tidy(Q*inflate(frame['blocks'],types[ell+1])*Qi)
        zero(Pfull-O*Ps[ell]*O.T/lam[ell])
    norm0=lambda M:red(sum((s.conjugate(v)*v for v in M.todok().values()),s.S.Zero))
    for r in range(5):
        for t in range(5):
            projected=tidy(s.kronecker_product(Ps[r],Ps[t])*F) if r!=t else None
            for ell in range(1,5):
                predicted=s.S.Zero if r==t else red((lam[r]-lam[t])**2*norm0(tidy(projected*Ps[ell]))/lam[ell])
                assert red(predicted-norms[r,t,ell+1])==0,(r,t,ell)
    lightcharged=[v for v in charged if v[0]==0 or v[1]==0]
    softcharged=[v for v in charged if v[2]==1]
    assert lightcharged # Actual required light-vector F2 input, not ghost inference.
    ghost=packed(CAL/'canonical_so10_ghost_scalar_charge_kernel/primary_tables.json.gz')
    ghostchanges=sum(red(v-parse(z))!=0 for key,rows in ops.items() for row,grow in zip(rows,ghost['operators'][key]) for v,z in zip(row,grow))
    assert ghostchanges>0
    assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<6*1024**2
    out={'schema':'VVK1_VALIDATION','execution_state':'COMPLETED','status':'QUALIFIED_COMPLETE_ORDERED_VVS_CHARGE_OPERATORS',
      'scalar_dimension':328,'classes':35,'commutant_units':177,'vector_pairs':25,'operators_per_pair':7,
      'complete_operator_positions':30975,'nonzero_operator_positions':nonzero,'zero_operator_positions':30975-nonzero,
      'exact_native_operator_equality':True,'Hermitian_and_edge_exchange_checked':True,'actual_intertwiners':12,
      'closed_type_probe_positions':150,'raw_nonzero_profiles':rawprofiles,'F2_nonzero_profiles':charged,
      'Goldstone_mass_difference_norm_identities':100,'full_polarized_Gram_Ward_bridge':True,
      'raw_profile_count':len(rawprofiles),'F2_profile_count':len(charged),'structurally_excluded_profiles':excluded,
      'F2_one_light_vector_profiles':lightcharged,'F2_scalar_soft_profiles':softcharged,
      'vector_Casimir_averaging_changes_by_ideal':averagechanges,'wrong_scalar_dual_change_positions':dualchanges,
      'mass_role_exchange_change_positions':rolechange,'off_diagonal_operator_positions':offdiag,
      'ordered_ghost_operator_replacement_change_positions':ghostchanges,'diagonal_H_trace_change_operator_count':Hdiag,
      'exact_arithmetic_no_float_atoms':True,'SCM_actual_commutator_and_frame_certificate':'REUSED_AUTHENTICATED_NOT_RERUN',
      'native_runs':native,'full_model_VVS_amplitude_calculated':False,'full_C1_or_E5_qualified':False,
      'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED',
      'shared_limits':['action','reference','scalar frame','exact ring/software','AI authorship'],
      'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
if __name__=='__main__':main()
