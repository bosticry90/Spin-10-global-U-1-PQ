# VVK1 physical/soft spectral transport supplement

Execute only after VVK1 complete operator qualification. This is an exact
dependent comparison of qualified operators, not a third independent action
or a VVS amplitude. It tests whether costly, already-qualified ghostS physical
spectral resolution can be reused with factor4 in VVS without re-diagonalizing
the same scalar operator. All authority ceilings and failures remain.

On the physical and soft scalar carriers, O.T P=0 implies projected ordered T
is symmetric, hence projected S=2T. For BOTH scalar arguments on that carrier,
the VVS raw/first-charge/second-charge operators must therefore equal4 times
the corresponding ghostS operators. Verify P(Mvvs-4Mghost)P=0 for each of25
ordered vector pairs,7 operators,35 multiplicity classes and both carriers,
including all implicit zeros. The actual factor4 is from two vertices, not a
change in Gaussian Wick weight. Compare all100 Goldstone marginal probes
separately and report failures of a GLOBAL factor4 replacement as a sensitive
negative control; do not transport Goldstone data by this argument.

Authenticate the completed GSA1 spectral-measure receipt and its original
inputs. Check all35 H matrices, labels, dimensions, physical/soft/Gold
projectors and vector mass coefficients against the actual current FCI/frame.
If these differ, no spectral transport claim. If all gates pass, existing
physical/soft masses and weights may be reused with factor4 and their recorded
precision (85 mass digits,75 weight digits,110 working), not fresh exact
spectral data. Goldstone weights, spin kernels, prefactors, forest/soft matching
and finite amplitudes still require their own construction. The statement is
valid for any function of H restricted to the physical carrier; two numerical
couplings are not used to infer it.

Freeze this contract, supplement sources, completed VVK1 packet, GSA1 ancestry
and state before the exact comparison. One600s native verifier,8GiB sampled
private,350MiB launch headroom,6MiB combined VVK1 package; full capture and
exclusive outputs. Dependent table identity validation uses qualified distinct
tensor routes rather than an unnecessary third large coefficient extraction.
No fitted input, new scheme, authority promotion or protected activation.
Acceptance NOT_PERFORMED; state113/34of39 unchanged. Shared premises/software/
AI authorship explicitly limit independence. Failure/incomplete kept intact.
