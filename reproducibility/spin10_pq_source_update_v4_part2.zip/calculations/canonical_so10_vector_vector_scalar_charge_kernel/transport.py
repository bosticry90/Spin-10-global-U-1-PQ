"""Exact P(Mvvs-4Mghost)P comparison and authenticated spectral coordinates."""
from data import *
def parse(v):return s.sympify(v,locals={'w':w})
def main():
    start=begin('transport_preparation.json')
    vv=packed(HERE/'primary_tables.json.gz');gg=packed(CAL/'canonical_so10_ghost_scalar_charge_kernel/primary_tables.json.gz')
    values,fci,scm=inputs('primary');action,rho,V,ad,Ps,frame,Q,Qi,E=values
    units=basis(frame);assert units==list(map(tuple,vv['basis']))==list(map(tuple,gg['basis']));address={v:i for i,v in enumerate(units)}
    types=small_types(fci);checks=0;positions=0
    for r in range(5):
        for t in range(5):
            key=f'{r},{t}'
            for row,grow in zip(vv['operators'][key],gg['operators'][key]):
                delta=[red(parse(v)-4*parse(z)) for v,z in zip(row,grow)]
                for a,b in enumerate(frame['blocks']):
                    m=b['multiplicity'];M=s.SparseMatrix(m,m,{(i,j):delta[address[a,i,j]] for i in range(m) for j in range(m)})
                    for which in [0,1]:
                        P=types[which][a];zero(P*M*P);checks+=1;positions+=m*m
    goldchanges=0;ggp={(p['first_ghost'],p['second_ghost'],p['scalar_type']):p for p in gg['probes']}
    for p in vv['probes']:
        if p['scalar_type']<2:continue
        g=ggp[p['first_vector'],p['second_vector'],p['scalar_type']]
        va=[p['raw'],*p['q1_squared'],*p['q2_squared'],*p['qscalar_squared']]
        ga=[g['raw'],*g['q1_squared'],*g['q2_squared'],*g['qscalar_squared']]
        goldchanges+=sum(red(parse(v)-4*parse(z))!=0 for v,z in zip(va,ga))
    assert goldchanges>0
    tab=packed(CAL/'canonical_so10_ghost_scalar_sunset/primary_measure_tables.json.gz')
    assert len(tab['blocks'])==35 and tab['mass_output_digits']==85 and tab['weight_output_digits']==75 and tab['working_digits']==110
    assert list(map(parse,tab['ghost_mass_coefficients']))==[s.Rational(3,10),s.Rational(3,2),s.Integer(25),s.Rational(253,10)]
    for a,(b,old) in enumerate(zip(frame['blocks'],tab['blocks'])):
        assert b['label']==old['label'] and b['dimension']==old['dimension'] and b['multiplicity']==old['multiplicity']
        zero(dec(fci['blocks'][a]['H'])-dec(old['H']))
        assert len(old['projectors'])==6
        for which in range(6):zero(types[which][a]-dec(old['projectors'][which]))
    assert checks==25*7*35*2 and positions==25*7*177*2
    out={'schema':'VVK1_SPECTRAL_TRANSPORT','execution_state':'COMPLETED','status':'QUALIFIED_VVS_PHYSICAL_SOFT_SPECTRAL_TRANSPORT',
      'exact_projected_matrix_comparisons':checks,'projected_coefficient_positions':positions,'operator_weight_factor':4,
      'Goldstone_global_factor4_changed_probe_coefficients':goldchanges,'authenticated_H_blocks':35,'authenticated_projector_blocks':210,
      'source_mass_digits':85,'source_weight_digits':75,'source_working_digits':110,'new_spectral_calculation_performed':False,
      'Goldstone_transport_qualified':False,'VVS_kernel_or_amplitude_calculated':False,'full_C1_or_E5_qualified':False,
      'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED','elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
if __name__=='__main__':main()
