"""Append-only phase freeze; existing sources/evidence remain unchanged."""
from pathlib import Path
from hashlib import sha256
import json,ast
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
deps={};cache={}
v=json.loads((HERE/'validation_receipt.json').read_bytes());assert v['status']=='QUALIFIED_COMPLETE_ORDERED_VVS_CHARGE_OPERATORS'
parent=ROOT/'calculations/canonical_so10_ghost_scalar_sunset'
p=parent/'measure_receipt.json';assert sha256(p.read_bytes()).hexdigest()=='261d97642d3ee08b45b1fee2fc8aa1899f8fe731bb965055191d4b6202d2f39b'
assert json.loads(p.read_bytes())['status']=='QUALIFIED_COMPLETE_GHOST_SCALAR_SPECTRAL_MEASURE'
for folder in [HERE,parent]:
    for prep in sorted(folder.glob('*preparation*.json')):
        for n,h in json.loads(prep.read_bytes())['input_sha256'].items():
            if n not in cache:cache[n]=sha256(Path(n).read_bytes()).hexdigest()
            assert cache[n]==h,n
            if n in deps:assert deps[n]==h,n
            deps[n]=h
    for p in folder.iterdir():
        if p.is_file():deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for n in ['SPECTRAL_TRANSPORT_CONTRACT_V1.md','transport.py','prepare_transport.py','run_transport.py']:
    p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
    if p.suffix=='.py':ast.parse(raw,filename=str(p))
    cp=HERE/(n+'.source.txt')
    with cp.open('xb') as f:f.write(raw)
    deps[str(p)]=deps[str(cp)]=sha256(raw).hexdigest()
with (HERE/'transport_preparation.json').open('xb') as f:f.write((json.dumps({'schema':'VVK1_TRANSPORT_PREPARATION','input_sha256':dict(sorted(deps.items())),
 'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'whole_package_cap':6*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('FROZEN_TRANSPORT',len(deps),'bindings;no new comparison executed',flush=True)
