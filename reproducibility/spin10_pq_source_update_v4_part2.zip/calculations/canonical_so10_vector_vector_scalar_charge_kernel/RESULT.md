# VVK1: full VVS charge operators and a qualified spectral reuse reduction

Complete operator receipt SHA256
2c96ebb44ae8f58b82677dc34c464914517c8830d266a8380c1ce739f4174baf,
status QUALIFIED_COMPLETE_ORDERED_VVS_CHARGE_OPERATORS.
Physical/soft transport supplement SHA256
aef361b21ec20264e966dfb955188825ef3633e8562d7a5d34dfd975c02a395d,
status QUALIFIED_VVS_PHYSICAL_SOFT_SPECTRAL_TRANSPORT.
Scientific acceptance NOT_PERFORMED;state113/authority34of39 unchanged.

All25 ordered vector pairs,7 raw/charge operators and177 scalar commutant
units agree between qualified-table/orthonormal/highest-state and actual-
action/full45-index/all328-state methods:30975 coefficient positions,746
nonzero and30229 zero. The complete35-class multiplicity matrices retain
mixing and the nonunitary-frame inverse metric. Scalar squared-charge weights
are the actual class Casimirs times raw; vector charges remain matrices inside
their mass projectors. This is color/charge extraction, not a loop integral.

Every150 scalar-type probe matches the independently qualified VVS1 raw norms.
There are30 nonzero raw profiles and29 with nonzero F2 charge weight. The
exception(r2,r2,physical) has exactly zero charge on all legs, despite a nonzero
vertex. All6 one-light-vector and both scalar-soft profiles remain charged.
No numerical support cutoff or missing-entry-zero assumption is used.

The full polarized-Gram Ward bridge S.O=(Gram tensor I-I tensor Gram)f
holds. Actual FCI Goldstone projectors equal O Pl O.T/lambda_l. Independently,
all100 Goldstone norms equal (lambda_r-lambda_t)^2/lambda_l times the projected
structure-constant norm. In particular equal-vector-mass Goldstone vertices
vanish for structural reasons. This is a third group-theory check of the
raw typed support, not a third independent action or a finite amplitude.

## Why the actual operators must be kept

Averaging vector charges within degenerate mass sectors changes30 U1,
14 SU2 and44 SU3 operator positions. Unlike the earlier ghost calculation,
SU2 averaging is now sensitive because light vector sectors also contribute.
Wrong scalar dual changes14 positions; edge-role exchange changes236;
210 nonzero off-diagonal multiplicity positions are retained. Replacing S
operators by ordered ghost T changes746 positions. Removing off-diagonal
H entries changes45 operator traces. These controls test specific mistakes;
they are not a claim every error is detectable by one projection or UV pole.

The exact physical/soft supplement checks12250 projected matrices,61950
coefficient positions, with P(Mvvs-4Mghost)P=0. It authenticates all35 old GSA1
H blocks,210 projector blocks, scalar labels/kinetic coordinates and heavy
vector mass coefficients. Existing physical/soft spectral resolution may thus
be reused with factor4 in the OPERATOR WEIGHTS. Its85-digit masses/75-digit
weights at110 working digits retain their old precision and qualification.
No new eigensystem or amplitude was calculated. The identity holds for any
physical restricted H function, rather than extrapolating two sampled couplings.

The global factor4 shortcut fails at138 Goldstone probe coefficients. Those
weights must use VVK1 directly. Neither the Gaussian Wick weight, spin kernel,
finite amplitude nor the ghost no-light proof is transported. In particular
one must not multiply the completed ghostS threshold by4 to obtain VVS.

## Compact primitive/subtraction inventory

This is an evidence map, not a second scientific-authority ledger. Read the
linked results and exact scopes before assembly. Four of nine have qualified
amplitude inputs; their renormalization stages are different.

| Family | Amplitude input | Proper-subgraph status | IR/EFT status | Remaining assembly |
| --- | --- | --- | --- | --- |
| VVVV | Regulated primitive qualified | Class-local UV insertion diagnostic; not a complete parent forest | Actual primitive light matching qualified | Parent coordination and overall/finite subtraction open |
| VVSS | Qualified finite graph-local result | Graph-local forest qualified; pole0 | Mixed/all-soft matching qualified | Parent-minus-family and full finite normalization open |
| VSS | Complete five-sector primitive | Matched Rprime forest qualified; nonzero overall poles retained | Positive/one-soft/two-soft/light sectors qualified | Parent-minus-family and overall subtraction open |
| ghostS | Complete primitive | Graph-local forest qualified; remaining pole0 | Positive/scalar-soft matching qualified | Parent-minus-family and full finite normalization open |
| VVS | Support and complete charge operators only | Kernel/forest not yet calculated | Actual one-light and scalar-soft domains identified | Entire amplitude and matching pending |
| VVV | Not complete | Pending | Pending | Pending |
| SSSS | Not complete | Pending | Tree heavy-exchange check required | Pending |
| SSS | Not complete | Pending | Pending | Pending |
| ghostV | Not complete | Pending | Pending | Pending |

Sources: ../canonical_so10_vector_quartic_ir_matching/RESULT.md,
../canonical_so10_vector_quartic_uv_subgraphs/RESULT.md,
../canonical_so10_vector_scalar_quartic/RESULT.md,
../canonical_so10_scalar_current_vss_assembly/RESULT.md,
../canonical_so10_ghost_scalar_sunset/RESULT.md. Preserve
Bfull+Cparent-Sbare-Csoft=Rprime_matched+(Cparent-Cfamily), with the FULL
Cfamily before soft cancellation. No old subtotal or partial functional was
edited. No extra contained pilot or family subtraction is inserted twice.

## Execution, capability evidence and limits

3317 initial bindings, qualified VVS1 first; then primary40.5287s,replay58.1700s,
separate verifier153.6543s. Sampled native private maxima66973696/72503296
bytes. Transport3387 bindings,43.0577s. All sequential,exclusive and terminal
before dependent work. Caps600s each,8GiB sampled private,350MiB launch floor,
6MiB package. Full captures/raw and packed hashes retained. No scientific,
controller or verifier failure, timeout,cancellation or native truncation.

Read-only path/wildcard lookups and two unapplied patch-context attempts were
corrected before freezing; no failed scientific calculation or edited frozen
source is concealed by those engineering corrections. Some broad tool displays
were truncated; native evidence captures are complete. Old scientific and
premature-commit/custody failures remain preserved under their original records.

TrackB evidence is complete structural support, distinct tensor contractions,
sensitive charge/metric controls and a precise reuse theorem that avoids an
unnecessary repeat of a qualified spectral calculation. Methods share action,
reference point, frame, symbolic software and AI authorship. Agreement does
not validate shared physical premises; no external scientist or empirical
confirmation is claimed.

Full C1,physical gauge unification,E5/A5 and physical quantum control remain
unqualified. Historical custody exit2/seven is not PASS. All protected/paused
stages and authority remain unchanged. The director's supplied foundational
and helium references are reviewed in ../canonical_so10_vector_vector_scalar_support/RESULT.md;
they do not change this action or reactivate cosmology/flavor.

NEXT_RESEARCH_QUESTION.md identifies the smallest complete kernel domain and
explicitly labels its preliminary formulas as UNQUALIFIED candidate targets.
The next calculation must include real spin1 transport,D=4-2eps,all proper
forests and both actual soft limits before counting VVS as family5of9.
