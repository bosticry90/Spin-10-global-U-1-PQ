"""VVK1 highest-state/orthobasis vs all-state/full-index coefficient tables."""
from data import *
def main():
    role=sys.argv[1];assert role in ['primary','replay'];start=begin('preparation.json')
    values,fci,scm=inputs(role);action,rho,V,ad,Ps,frame,Q,Qi,E=values;B=basis(frame);assert len(B)==177
    O=dec(action['vacuum']['orbit'])
    Cv=[tidy(-sum((ad[h]*ad[h] for h in hs),s.SparseMatrix(45,45,{}))/len(hs)) for hs in [range(1),range(1,4),range(4,12)]]
    for C in Cv:
        zero(C-C.T)
        for P in Ps:zero(C*P-P*C)
        for A in ad:zero(C*A-A*C)
    for h in range(12):
        Rh=sum((V[a,h]*rho[a] for a in range(45) if V[a,h]),s.SparseMatrix(328,328,{}));zero(Rh*O-O*ad[h])
    S=tidy(tensor(role,action,rho))
    if role=='primary':
        G=load('vvk_basis',CAL/'canonical_so10_ghost_scalar_support/data.py');Us=[G.orthogonal_basis(P) for P in Ps]
        C=[[tidy(U.T*M*U) for M in Cv] for U in Us];X=Xcolumns(tidy(S*E))
        cs=[[s.sympify(v) for v in row] for row in scm['scalar_Casimir_averages']]
    else:
        Us=Ps;C=[Cv for _ in range(5)];X=Xcolumns(tidy(S*Q))
        cs=[[red(6*z/b['dimension']) for z in weights(b['label'])] for b in frame['blocks']]
    blocks={}
    for r in range(5):
        for t in range(5):blocks[r,t]=[tidy((Us[r].T*M*Us[t]) if role=='primary' else (Ps[r]*M*Ps[t])) for M in X]
    print('STAGE '+role+'_projected_VVS_charge_operators',flush=True)
    ops={};wrong={}
    for r in range(5):
        for t in range(r,5):
            direct=[[] for _ in range(7)];bad=[]
            for alpha,b in enumerate(frame['blocks']):
                m=b['multiplicity'];dim=b['dimension'];offset=b['seed_offset'] if role=='primary' else b['offset']
                for i in range(m):
                    for jj in range(m):
                        sums=[s.S.Zero]*7;bad0=s.S.Zero
                        for n in range(1 if role=='primary' else dim):
                            a=offset+(0 if role=='primary' else n*m)+i;c=offset+(0 if role=='primary' else n*m)+jj
                            forms=shapes((C[r],C[t]),blocks[r,t][a].conjugate(),blocks[t,r][a].conjugate())
                            v=coefficient(forms,blocks[t,r][c],blocks[r,t][c])
                            factor=s.S.One if role=='primary' else 1/(s.Integer(dim)*s.sympify(b['state_norms'][n]))
                            sums=[u+factor*z for u,z in zip(sums,v)]
                            if role=='replay':bad0+=v[0]/s.Integer(dim)
                        for k,z in enumerate(sums):direct[k].append(red(z))
                        if role=='replay':bad.append(red(bad0))
            key=f'{r},{t}';ops[key]=direct
            if role=='replay':wrong[key]=bad
            if r!=t:ops[f'{t},{r}']=[direct[0],*direct[4:7],*direct[1:4]]
            print('STAGE '+role+'_ordered_vector_pair_'+key,flush=True)
    av=[[str(red(s.trace(P*C)/s.trace(P))) for C in Cv] for P in Ps]
    out={'schema':'VVK1','basis':[list(v) for v in B],'operators':{k:[[str(z) for z in row] for row in vv] for k,vv in ops.items()},
      'operator_names':['raw','vector_first_U1','vector_first_SU2','vector_first_SU3','vector_second_U1','vector_second_SU2','vector_second_SU3'],
      'scalar_Casimir_averages':[[str(z) for z in row] for row in cs],'vector_Casimir_operators':list(map(enc,Cv)),
      'mass_sector_averaged_Casimir':av,'probes':probes(ops,frame,B,cs,fci),'actual_Rh_O_intertwiners_checked':12,
      'domain_positions':30975,'scalar_dimension':328,'classes':35,'full_model_amplitude_calculated':False,
      'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED'}
    if role=='replay':out['wrong_dual_raw']={k:[str(z) for z in row] for k,row in wrong.items()}
    save(role,out,start)
if __name__=='__main__':main()
