# VVK1: complete VVS ordered color/charge operators

Prospective next increment, executed only after VVS1 support comparison and
qualification. Same base7562f42c/main, action, point, xi1 reference and authority
ceiling as VVS1. This does not integrate a loop or assume its universal kernel.

Question: can all actual S_abI vector-vector-scalar contractions, including
light-vector and scalar-soft assignments, be represented completely on the
qualified35-class/177-unit scalar commutant without averaging distinct charges
in degenerate vector mass sectors? This is the least expensive next step
toward a complete VVS primitive after support is known. Outcomes: complete
operator tables, refuted proposed contraction, underdefinition or inconclusive.

Freeze all25 ordered vector pairs, raw weight and two independent vector-charge
weights for each of3 unbroken ideals:25*7*177=30975 exact coefficient positions.
Scalar squared-charge weight is the actual class Casimir times raw. Charge
conservation reconstructs a q1*q2 weight as (qscalar^2-q1^2-q2^2)/2; this is
an operator identity, not commuting arbitrary color matrices. Keep edge roles.
With S symmetric in its vector indices, K_IJ=Tr(Pr S_I Ps S_J), first-charge
insertion Pr Cv and second-charge insertion Ps Cv. Hermitian scalar bilinear
uses conjugate first argument and symmetric scalar-field product. Cv is
-sum ad_h^2/dim(ideal), ideal dimensions1/3/8. It is an actual matrix within
each vector sector, not its average eigenvalue. This is not ordered ghost T.

Primary: qualified VVS1 S table, orthonormal vector-sector bases, normalized65
highest scalar states. Replay: derivative Gram from actual action rho/O,
full45-index projectors and all328 scalar states with inverse kinetic metric.
Use actual Q,D,Qi=D^-1 Q.H; Q is not unitary. Reuse authenticated SCM full
representation/frame/Schur certificate rather than repeat its expensive proof.
Retain all328 scalar directions, physical/soft/Gold projectors and mixing.

Require all30975 entries/implicit zeros to agree exactly; Hermiticity, edge
exchange, scalar/Cv charges, all150 projected scalar-type norms and marginal
raw norms must match independently qualified VVS1 support. Check charge
centrality and all12 actual O intertwiners. Negative controls: averaged vector
charges per mass, omitted off-diagonal multiplicity operators, wrong inverse
metric, edge-role exchange, and ordered ghost T. Report sensitivity by ideal
or projection; insensitive controls are not passed error detectors.

Freeze immutable transitive input hashes and source copies before execution.
Sequential primary/replay, then independent validation; no dependent read of
unfinished outputs. 600s each, sampled private<=8GiB, available commit at
launch>=350MiB, whole package<=6MiB. Exact algebraic ring, no floats, exclusive
outputs, full captures/resource observations, no silently truncated evidence.
Preserve failed sources and captures; no silent retry or result fitting.

Claim ceiling: complete action-derived VVS charge operators and typed support,
NOT a heat/Fourier kernel, subtraction, amplitude, C1_GS, gauge unification or
E5/A5. State113/authority34of39 unchanged; scientific acceptance NOT_PERFORMED.
Shared action, point, scalar frame, exact software and AI authorship disclosed.
Existing historical/physical failures and all protected boundaries remain.

Additional pre-freeze structural check: S.O=(Gram tensor I-I tensor Gram)f,
with f_ab^c in the actual plane basis. The Goldstone projector is
O Pl O.T/lambda_l. Therefore every projected Goldstone raw norm is
(lambda_r-lambda_t)^2/lambda_l times ||(Pr tensor Pt)f Pl||^2. Verify all100
such norms and the projector identities from actual action/FCI inputs. This
route explains equal-mass Goldstone zeros and tests the light-vector cases
without using the measured S coefficients to assign their norm values.
