# Next: complete two-vector/one-scalar kernel for the actual VVS domain

Whole goal ACTIVE/incomplete. VVS1 and VVK1 provide the action vertex and
complete charge maps; they do not supply a VVS amplitude. Keep xi1, the same
mass/reference/scalar point, ordered color factors and BFT Wick-1/4. Do not
transfer ghost no-light or scalar-spin kernels. Preserve full parent-minus-
family accounting and unqualified overall/finite normalization obligations.

Only two IR limits are required by actual support: a light vector with the
other vector and Goldstone scalar of equal mass; or a soft scalar with the
two vector masses proportional to3/10 and253/10. Reverse vector-edge roles
are retained. No supported two-light, multiply-soft or all-light VVS graph.
No arbitrary scaleless discard or extrapolation of SCK's scalar-soft proof.

Freeze a kernel contract before new science. Derive all15 labelled background
placements from the two-spin1/one-spin0 propagator product, including ordered
spin transport, orbital curvature, source/auxiliary conventions and D=4-2eps.
Calculate every proper subgraph before its remaining closure; keep D in the
remaining loop but project a CLOSED vector-loop UV pole at D4. This distinction
already mattered in VVSS and SCK. An early-D4 finite control must be sensitive.

Provisional derivation for scrutiny, NOT QUALIFIED: with time variables(s,t,u),
U=st+su+tu and SCK orbital E_i=-t_i^2/6-t_i^2*t_j*t_k/(3U), the contracted
two-vector spin trace suggests

    D*sum_i q_i^2 E_i +4(q1*s-q2*t)^2,   q1+q2+q3=0.

This must follow from actual K1 K2^transpose and physical charge orientation,
not guessed commuting color products. Its charge-axis heat coefficients would
be D E1+4s^2+4st, D E2+4t^2+4st, D E3-4st. Independent Fourier mass-derivative
operators would then be

    ((4-D)/2+4) I_xx +4 I_xy +(2x/3) I_xxx,
    ((4-D)/2+4) I_yy +4 I_xy +(2y/3) I_yyy,
    (4-D) I_zz/2 -4 I_xy +(2z/3) I_zzz.

Do not accept these until Lorentz/charge conservation, all-dimensional heat/
Fourier comparison and proper-forest derivation agree. Using the authenticated
bare master including Ae and MSbar factors suggests positive-mass Rprime units

    R1=(2x/3)Ifin_xxx+4(Ifin_xx+Ifin_xy),
    R2=(2y/3)Ifin_yyy+4(Ifin_yy+Ifin_xy),
    R3=(2z/3)Ifin_zzz-4Ifin_xy+1/(3z),

with scale slopes(-10/(3x),-10/(3y),2/(3z)) and zero overall poles. These are
PROPOSED TARGETS, not inherited results. The scalar-axis1/(3z) is suggested
by the CLOSED vector bubble's D/eps finite remnant; verify it independently
instead of fitting a constant to a master derivative. The SCK initial failed
finite target is an explicit warning against trusting a plausible formula.

Then derive both complete actual soft subtractions, including mass, kinetic,
spin/field-strength and any background-dependent opened-bubble structures,
at common positive auxiliary delta and eps before limits. Compare a hard heat
integral with independent positive-mass master limits and actual opened-loop
matching. Retain power-sensitive terms and finite dimensional remnants.
The existing scalar-soft subtraction is not enough for a soft vector.

After kernel qualification, use VVK1 operators for Goldstone/light weights.
If transport_receipt qualifies, reuse the authenticated GSA1 physical/soft
spectral resolution with factor4 on those operator weights ONLY, at its
recorded85/75-digit precision. Do not multiply the ghostS amplitude by4,
copy its spin kernel, reuse its Gaussian weight, or transport Goldstone weights.
Common-scale conversion and full/EFT forest ownership are still required.
Only after the entire VVS domain closes should it count as family5of9.
