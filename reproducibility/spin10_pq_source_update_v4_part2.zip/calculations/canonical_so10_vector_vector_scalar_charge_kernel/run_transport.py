"""One exclusive exact-identity validation after the completed operator packet."""
from pathlib import Path
from hashlib import sha256
import json,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/vvs-charge-kernel-v1-2026-10-20')
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
for p,h in json.loads((HERE/'transport_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
c=capture([sys.executable,'-B',str(HERE/'transport.py')]);dump(HERE/'transport_capture.json',c);dump(CONTROL/'transport_full_capture.json',c)
if c['exit_code']!=0:print(c['stdout_and_stderr'],flush=True)
assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
assert c['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
r=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(r)==1
assert r[0]['status']=='QUALIFIED_VVS_PHYSICAL_SOFT_SPECTRAL_TRANSPORT' and r[0]['elapsed_after_imports']<600
dump(HERE/'transport_receipt.json',r[0]);assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<6*1024**2
print('COMPLETED_VVS_PHYSICAL_SOFT_TRANSPORT',r[0]['elapsed_after_imports'],flush=True)
