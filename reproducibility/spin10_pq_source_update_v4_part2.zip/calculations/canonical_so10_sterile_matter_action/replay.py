"""SMA1 component exterior-density construction and paired-mode Pfaffians."""
from data import *
from functools import lru_cache
start=begin('replay');eps=s.Matrix([[0,1],[-1,0]]);C=s.diag(eps,-eps);Ci=C.inv();PL=s.diag(1,1,0,0);PR=s.eye(4)-PL;Z=s.zeros(2)
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
gam=[s.BlockMatrix([[Z,s.eye(2)],[s.eye(2),Z]]).as_explicit()]+[s.BlockMatrix([[Z,s.I*p],[-s.I*p,Z]]).as_explicit() for p in pa]
def block(a,b,c,d):return s.BlockMatrix([[a,b],[c,d]]).as_explicit()
def zero(M):assert not s.SparseMatrix(M).applyfunc(s.simplify).todok()
for h in gam:zero(Ci*h*C+h.T);zero((C*h).T-C*h)
def component_substitute(K,U):
 # Expand each original quadratic Grassmann monomial under the field map.
 # Sorting the resulting odd variables supplies its sign; no U^T K U call.
 terms={}
 for i in range(K.rows):
  for j in range(i+1,K.cols):
   if K[i,j]==0:continue
   for a in range(U.cols):
    if U[i,a]==0:continue
    for b in range(U.cols):
     if U[j,b]==0 or a==b:continue
     key=(min(a,b),max(a,b));terms[key]=terms.get(key,0)+(1 if a<b else -1)*K[i,j]*U[i,a]*U[j,b]
 out=s.zeros(U.cols)
 for (a,b),v in terms.items():out[a,b]=s.simplify(v);out[b,a]=-out[a,b]
 return out
def original_kernel(D,mL,mR,n=1):
 cc=s.kronecker_product(C,s.eye(n));ll=s.kronecker_product(PL,s.eye(n));rr=s.kronecker_product(PR,s.eye(n));zz=s.zeros(4*n)
 return block(cc*ll*mL,-D.T,D,-rr*mR*cc.inv())
def Umap(n=1):
 return s.kronecker_product(block(PL,PR,-C*PR,-C*PL),s.eye(n))
def scalar_coefficient(M,target):
 v=s.simplify(s.trace(target.H*M)/s.trace(target.H*target));zero(M-v*target);return str(v)
coeff={};positions=0
p=s.Symbol('p',nonzero=True);J=s.Matrix([[0,p],[-p,0]]);I2=s.eye(2)
# Independent explicit two-mode kinetic construction, with correct derivative
# transpose. Auxiliary n=2 here means mode coordinates, not matter families.
for j,h in enumerate(gam):
 D=s.kronecker_product(h,J);K=original_kernel(D,s.zeros(8),s.zeros(8),2);U=Umap(2)
 got=component_substitute(K,U);target=s.diag(s.kronecker_product(C*h,J),s.kronecker_product(C*h,J))
 coeff['kin_bar_'+str(j)]=scalar_coefficient(got,target);positions+=256
# A separate jet matrix needs only the C/projector transpose rules. It is
# not a four-by-four full split-Clifford representation.
h=s.diag(pa[0],pa[0]);zero(Ci*h*C+h.T);zero(h*PL-PL*h)
K=original_kernel(s.kronecker_product(h,J),s.zeros(8),s.zeros(8),2);got=component_substitute(K,Umap(2));target=block(s.zeros(8),s.kronecker_product(C*h,J),s.kronecker_product(C*h,J),s.zeros(8))
mix=scalar_coefficient(got,target);coeff['mix_hat_4']=coeff['mix_hat_5']=mix;positions+=256
for tag,ml,mr,target in [
 ('mass_holo',s.eye(4),s.zeros(4),block(C*PL,s.zeros(4),s.zeros(4),s.zeros(4))),
 ('mass_anti',s.zeros(4),s.eye(4),block(C*PR,s.zeros(4),s.zeros(4),s.zeros(4)))]:
 got=component_substitute(original_kernel(s.zeros(4),ml,mr),Umap());coeff[tag]=scalar_coefficient(got,target);positions+=64
# Generic complex Hermitian internal generator: its transpose is kept distinct.
a,b,c,d=s.symbols('a b c d',real=True);T=s.Matrix([[a,b+s.I*c],[b-s.I*c,d]]);cc=s.kronecker_product(C,I2);ll=s.kronecker_product(PL,I2);rr=s.kronecker_product(PR,I2)
for j,h in enumerate(gam):
 D=-s.I*s.kronecker_product(h*PL,T);K=original_kernel(D,s.zeros(8),s.zeros(8),2);got=component_substitute(K,Umap(2))
 target=block(-s.I*s.kronecker_product(C*h*PL,T)+s.I*s.kronecker_product(C*h*PR,T.T),s.zeros(8),s.zeros(8),s.zeros(8))
 value=scalar_coefficient(got,target);coeff['current_T_'+str(j)]=coeff['current_Ttranspose_'+str(j)]=value;positions+=256

# Massive Gaussian in a sine/cosine derivative pair: transpose includes both
# Fourier partners, so this really is an alternating finite kernel.
m,mb=s.symbols('m mbar');D=s.kronecker_product(gam[0],J);K=original_kernel(D,m*s.eye(8),mb*s.eye(8),2);Kps=component_substitute(K,Umap(2));zero(Kps+Kps.T)
phys=s.kronecker_product(C*gam[0],J)+s.kronecker_product(C*PL*m+C*PR*mb,I2);aux=s.kronecker_product(C*gam[0],J)
zero(Kps-s.diag(phys,aux));zero(Kps[:8,8:]);zero(Kps[8:,:8])
def pfaff(M):
 @lru_cache(None)
 def rec(indices):
  if not indices:return s.S.One
  i=indices[0];answer=0
  for k,j in enumerate(indices[1:],1):
   if M[i,j]:answer+=(-1)**(k+1)*M[i,j]*rec(indices[1:k]+indices[k+1:])
  return s.expand(answer)
 return rec(tuple(range(M.rows)))
fullpf=pfaff(Kps);baseline=fullpf.subs({m:0,mb:0});ratio=s.factor(fullpf/baseline);expected=(1+m*mb/p**2)**2;assert s.factor(ratio-expected)==0
assert s.factor(pfaff(phys)*pfaff(aux)-fullpf)==0
detphys=s.factor((s.kronecker_product(gam[0],J)+s.kronecker_product(PL*m+PR*mb,I2)).det());assert detphys==(p**2+m*mb)**4
wrong=Kps.copy();wrong[:8,:8]=s.kronecker_product(C*gam[0],J)+s.kronecker_product(C*PL*m-C*PR*mb,I2)
wrongratio=s.factor(pfaff(wrong)/baseline);assert s.factor(wrongratio-(1-m*mb/p**2)**2)==0 and wrongratio!=ratio
u,v=s.symbols('u v',real=True);assert s.expand((m*mb).subs({m:u+s.I*v,mb:u-s.I*v}))==u*u+v*v
finish('replay',{'method':'component_exterior_density_and_sparse_paired_mode_Pfaffian','coefficients':coeff,'component_identity_positions':positions,
 'barred_pair_hc_sign':'-1','massive_normalized_Pfaffian_ratio':str(ratio),'expected_massive_ratio':str(expected),'wrong_hc_ratio':str(wrongratio),
 'physical_determinant':str(detphys),'positive_mass_pole_polynomial':'p**2 + m*mbar','strict4D_auxiliary_factor_independent_of_mass_and_fields':True,
 'paired_mode_derivative_transpose':True,'hat_jet_test_not_full_Clifford_witness':True,'physical_antifield_copies':1,
 'new_loop_integrals':0,'provisional_only':True},start)
