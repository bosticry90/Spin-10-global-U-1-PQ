# Provisional charged/sterile matter action V1

This is the explicitly tested **classical matter extension**, conditional on
the stated split-Clifford/charge-conjugation algebra. It is not adoption of a
physical renormalization scheme, a quantum measure or a completed QAP. Read
RECORD, RESULT and the actual validation receipt for scope and provenance.

## Physical inputs and types

The physical matter remains three left Weyl families in the historically
declared Spin(10) spinor. Set N=48. The328 real scalar coordinates x and their
gauge/source transformations are inherited. With YCT1's complete isometric
maps, including the physical scalar complement,

```
M(x) = Y10 tensor unvec(B10 x) + Y126 tensor unvec(B126 x),
M^T=M,    Y10^T=Y10,    Y126^T=Y126.
```

The two family matrices are symbolic; their off-diagonal entry coordinates
are not rescaled. There is no direct Phi54 or S Yukawa. At the inherited
reference geometry, `M_N=(sigma/sqrt(2))Y126`; no numerical spectrum or
flavor point is selected. Full scalar covariance gives

```
qM = -ig c^a(T_a^T M + M T_a),
qMdagger = ig c^a(T_a Mdagger + Mdagger T_a^T).
```

Here T includes the family identity. This is a linear/tensor consequence of
the bound all45 YCT1 covariance theorem, not a new replay of that theorem.
The inherited physical PQ assignment gives charge-2 for M and+1 for the
left Weyl field. Quantum PQ anomaly and regulator effects are separate.

## Dirac variables and the alternating Gaussian

Introduce complex Grassmann Dirac variables psi,barpsi with charged PL
components and auxiliary sterile PR components. They are regulator variables,
not additional physical neutrinos. Use

```
D = gamma.partial - ig bar_gamma PL T_a G^a,
S_matter = integral [barpsi D psi
            + psi^T C PL M psi/2
            - barpsi PR Mdagger C^-1 barpsi^T/2].
```

The barred-pair minus follows from the fixed Lorentzian h.c. identity before
using this Euclidean complex-Grassmann notation. The positive massive pole
is checked independently. No real Euclidean Majorana condition is assumed.

Let `chi_c=C^-1 barpsi^T`, `Xi=(psi,chi_c)`. With operator transpose including
integration by parts, the quadratic form is `S=Xi^T K_Xi Xi/2`, where

```
K_Xi = diag(C,C) [[PL M, -D_c],[-D, PR Mdagger]],
D_c = gamma.partial + ig bar_gamma PR T_a^T G^a.
```

Its nondifferential coefficients are alternating. Its derivative coefficients
have the opposite plain-transpose symmetry, as required by integration by
parts. A single momentum block must not be treated as an alternating finite
matrix without including its opposite-momentum partner.

## Physical and auxiliary variables

Define

```
P = PL psi - PR chi_c,    S = PR psi - PL chi_c,
Xi = R(P,S),    R = [[PL,PR],[-PR,-PL]],
R^-1 = [[PL,-PR],[PR,-PL]].
```

The tested congruence gives `K_PS=diag(C,C) D_PS`, with

```
D_PS = [[D_phys, hat_gamma.partial_hat],
        [hat_gamma.partial_hat, bar_gamma.partial_bar]],
D_phys = bar_gamma.partial_bar - ig bar_gamma A_a G^a
         + PL M + PR Mdagger,
A_a = PL T_a - PR T_a^T,
Atilde_a = PR T_a - PL T_a^T.
```

Every gauge and Yukawa vertex acts on P. At hats=0 this is the original
physical Weyl/Majorana action plus a free, field-independent auxiliary
Gaussian. Its latter factor is normalized out. At nonzero hats the mixing
is present and cannot be dropped in an internal line.

The full Gaussian is a Pfaffian, with local logarithmic variation
`-Trlog(K)/2`. At M=0 it reduces to CSC1's ordinary Dirac determinant without
an extra half. At hats=0 it factors into the massive physical Pfaffian and
free auxiliary Pfaffian. This factorization does not construct an absolute
infinite-dimensional Pfaffian phase, global sign or analytic trace domain.

## BRST breaking and sources

Use the inherited qG,qc, an odd left derivation and ghosts to the left:

```
qP = ig c^a A_a P,    qS=0,
qbarP = -ig c^a barP Atilde_a,    qbarS=0.
```

The full barred gauge and Yukawa part is invariant using the actual mass
law. The remaining matter variation is precisely the hatted mixing variation:

```
qS_hat = (ig/2) integral [
  (dhat c^a) barS hat_gamma A_a P
 +c^a barS hat_gamma A_a dhat P
 -c^a barP Atilde_a hat_gamma dhat S ].
```

It equals, modulo the explicitly checked boundary current,

```
ig integral [(dhat c^a)barS hat_gamma A_a P
             +c^a barS hat_gamma A_a dhat P].
```

The raw-minus-compact density is
`-(ig/2) dhat[c^a barS hat_gamma A_a P]`. The insertion has gh1 and dimension5
under the project's ghost dimension1 convention. It is an evanescent
classical breaking, not a calculated quantum anomaly or a zero quantum term.
The physical PQ rotation also varies the hatted mixing, even for constant
parameter; no regulator-PQ invariance is asserted from Yukawa neutrality.

One even physical Nambu antifield K_P, gh-1 and dimension3/2, couples as
`S_src=integral K_P qP` once. Set qK_P=0. Source closure follows from the
inherited full45 Lie/nilpotence premise. Its pullback is

```
(K_psi,K_chi) = (K_P,0)R^-1 = (K_P PL,-K_P PR),
K_barpsi = -K_P PR C^-1
```

in component pairing with `qbarpsi^T`. This is the charged psi/barpsi
cotangent pair, not two copies of the physical Nambu source. The auxiliary
field has zero BRST variation and no nonzero source vertex. There are192
formal physical-source components and384 formal Grassmann regulator
coordinates for the three families; neither is a particle count. Auxiliary
Clifford witness sizes do not change these numbers.

## Remaining quantum prerequisites

The construction does not supply a finite-hat massive propagator by simply
replacing the four-dimensional denominator with p^2+|m|^2. That must be derived
from the full block operator. It also does not establish the quantum source/
measure domain, Lorentzian reality or causal limits, restoration counterterms,
multiple insertions or a full scheme conversion. All physical model exclusions,
input uncertainties, protected stages and authority boundaries remain intact.
