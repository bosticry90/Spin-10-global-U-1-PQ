"""SMA1 comparison, actual Yukawa inheritance and independent odd algebra."""
from data import *
from itertools import combinations
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
assert P['coefficients']==R['coefficients'] and len(P['coefficients'])==16 and set(P['coefficients'].values())=={'1'}
assert P['barred_pair_hc_sign']==R['barred_pair_hc_sign']=='-1' and P['physical_antifield_copies']==R['physical_antifield_copies']==1
assert P['Clifford_relations']==21 and P['physical_hat_propagator_block_zero'] and R['strict4D_auxiliary_factor_independent_of_mass_and_fields']
assert R['massive_normalized_Pfaffian_ratio']!=R['wrong_hc_ratio'] and R['paired_mode_derivative_transpose']
yp=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');yr=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz')
yreceipt=read(CAL/'canonical_so10_yukawa_carrier_transport/validation_receipt.json');assert yreceipt['full_gauge_covariance_equations']==90 and yreceipt['full_physical_scalar_complement_nonzero']
upstream_positions=0
for name in ['B10','B126']:
 B=dec(yp[name]);assert B==dec(yr[name]) and B.shape==(256,328);upstream_positions+=256*328
 for j in range(328):
  M=s.Matrix(16,16,list(B[:,j]));assert M==M.T
assert upstream_positions==167936
assert yreceipt['c_N_fixed_Clifford_phase']=='sqrt(2)/2' and s.simplify(s.sympify(yp['c_N'])-s.sympify(yr['c_N']))==0

# A compact exterior algebra keeps ghosts and odd fields ordered explicitly.
def clean(p):return {m:s.simplify(c) for m,c in p.items() if s.simplify(c)!=0}
def plus(*polys):
 out={}
 for p in polys:
  for m,c in p.items():out[m]=out.get(m,0)+c
 return clean(out)
def scale(p,c):return clean({m:v*c for m,v in p.items()})
def mul(a,b):
 out={}
 for x,c in a.items():
  for y,d in b.items():
   if x&y:continue
   parity=sum((y&((1<<i)-1)).bit_count() for i in range(x.bit_length()) if (x>>i)&1)%2
   out[x|y]=out.get(x|y,0)+(-1 if parity else 1)*c*d
 return clean(out)
def var(i):return {1<<i:s.S.One}
def deriv(p,rules):
 out={}
 for mask,c in p.items():
  ids=[i for i in range(mask.bit_length()) if (mask>>i)&1]
  for k,i in enumerate(ids):
   term={0:c*(-1)**k}
   for j in ids[:k]:term=mul(term,var(j))
   term=mul(term,rules.get(i,{}))
   for j in ids[k+1:]:term=mul(term,var(j))
   out=plus(out,term)
 return clean(out)
def bil(left,M,right):
 out={}
 for i in range(M.rows):
  for j in range(M.cols):
   if M[i,j]:out=plus(out,scale(mul(var(left[i]),var(right[j])),M[i,j]))
 return out

aa,bb,cc,dd=s.symbols('a b c d');A=s.Matrix([[aa,bb],[cc,dd]]);C=s.Matrix([[0,1],[-1,0]]);h=s.Matrix([[0,1],[1,0]]);At=-C.inv()*A.T*C
phys=[0,1];aux=[2,3];dp=[4,5];ds=[6,7];ghost=var(8);dghost=var(9)
rules={}
for i in range(2):
 rules[phys[i]]=scale(mul(ghost,plus(*(scale(var(phys[j]),A[i,j]) for j in range(2)))),s.I)
 rules[dp[i]]=scale(plus(mul(dghost,plus(*(scale(var(phys[j]),A[i,j]) for j in range(2)))),mul(ghost,plus(*(scale(var(dp[j]),A[i,j]) for j in range(2))))),s.I)
Shat=scale(plus(bil(phys,C*h,ds),bil(aux,C*h,dp)),s.Rational(1,2));direct=deriv(Shat,rules)
raw=scale(plus(mul(dghost,bil(aux,C*h*A,phys)),mul(ghost,bil(aux,C*h*A,dp)),scale(mul(ghost,bil(phys,C*At*h,ds)),-1)),s.I/2)
compact=scale(plus(mul(dghost,bil(aux,C*h*A,phys)),mul(ghost,bil(aux,C*h*A,dp))),s.I)
boundary=scale(plus(mul(dghost,bil(aux,C*h*A,phys)),mul(ghost,bil(ds,C*h*A,phys)),mul(ghost,bil(aux,C*h*A,dp))),-s.I/2)
assert not plus(direct,scale(raw,-1)) and not plus(raw,scale(compact,-1),scale(boundary,-1))
wrongraw=plus(raw,scale(mul(ghost,bil(phys,C*At*h,ds)),s.I));assert plus(direct,scale(wrongraw,-1))

# Complete mass covariance is generic in M and T, then applies to every
# actual bound YCT coefficient by the tensor/linear lift (not a new rho replay).
t0,t1,t2,t3=s.symbols('t0 t1 t2 t3',real=True);T=s.Matrix([[t0,t1+s.I*t2],[t1-s.I*t2,t3]])
ma,mb,mc=s.symbols('ma mb mc');M=s.Matrix([[ma,mb],[mb,mc]]);K=s.kronecker_product(C,M);gen=s.kronecker_product(s.eye(2),T);fields=list(range(4));g=var(4)
mass=scale(bil(fields,K,fields),s.Rational(1,2));mrules={i:scale(mul(g,plus(*(scale(var(j),gen[i,j]) for j in fields))),s.I) for i in fields}
dM=-s.I*(T.T*M+M*T);dK=s.kronecker_product(C,dM);massvar=scale(mul(g,bil(fields,dK,fields)),s.Rational(1,2));fieldvar=deriv(mass,mrules)
assert not plus(fieldvar,massvar) and plus(fieldvar,scale(massvar,-1))
na,nb,nc=s.symbols('na nb nc');Mb=s.Matrix([[na,nb],[nb,nc]]);Kb=-s.kronecker_product(C,Mb);gb=-s.kronecker_product(s.eye(2),T.T)
bar_mass=scale(bil(fields,Kb,fields),s.Rational(1,2));bar_rules={i:scale(mul(g,plus(*(scale(var(j),gb[i,j]) for j in fields))),s.I) for i in fields}
dMb=s.I*(T*Mb+Mb*T.T);dKb=-s.kronecker_product(C,dMb)
bar_massvar=scale(mul(g,bil(fields,dKb,fields)),s.Rational(1,2));bar_fieldvar=deriv(bar_mass,bar_rules)
assert not plus(bar_fieldvar,bar_massvar) and plus(bar_fieldvar,scale(bar_massvar,-1))
assert P['global_PQ_hat_mixing_nonzero']
# Preserve original symmetric-family entry coordinates, including offdiagonal
# weight2 rather than silently redefining an isometric family parameter.
family=[]
for i in range(3):
 F=s.zeros(3);F[i,i]=1;family.append(F)
for i,j in combinations(range(3),2):
 F=s.zeros(3);F[i,j]=F[j,i]=1;family.append(F)
assert [s.trace(F.T*F) for F in family]==[1,1,1,2,2,2]
for F in family:
 assert s.kronecker_product(s.eye(3),T.T)*s.kronecker_product(F,M)+s.kronecker_product(F,M)*s.kronecker_product(s.eye(3),T)==s.kronecker_product(F,T.T*M+M*T)

# Odd source closure: a noncommuting SU2 subalgebra is a sensitive finite
# negative control; the full45 proof is inherited from the actual Lie premise.
pa=[s.Matrix([[0,1],[1,0]])/2,s.Matrix([[0,-s.I],[s.I,0]])/2,s.diag(1,-1)/2];psi=[3,4];qr={0:scale(mul(var(1),var(2)),-1),1:mul(var(0),var(2)),2:scale(mul(var(0),var(1)),-1)}
for i in range(2):qr[3+i]=scale(plus(*(mul(var(a),scale(var(3+j),pa[a][i,j])) for a in range(3) for j in range(2))),s.I)
for i in psi:assert not deriv(qr[i],qr)
bad=dict(qr)
for i in range(3):bad[i]=scale(qr[i],-1)
assert any(deriv(bad[i],bad) for i in psi)
source=dec(P['source_pullback']);RR=dec(P['R']);assert source*RR==s.SparseMatrix.hstack(s.eye(16),s.zeros(16)) and 2*source!=source
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_PROVISIONAL_FULL_CHARGED_STERILE_YUKAWA_ACTION_AND_SOURCE_DOMAIN','elapsed_after_imports':time.perf_counter()-start,
 'operator_coefficients_compared':16,'primary_operator_positions':P['operator_identity_positions'],'replay_component_positions':R['component_identity_positions'],
 'upstream_Yukawa_positions_compared':upstream_positions,'full45_Yukawa_covariance':'INHERITED_BOUND_YCT_THEOREM_NOT_RERUN','scalar_real_directions':328,
 'symbolic_symmetric_family_matrices':2,'symmetric_family_entries_each':6,'family_coordinate_metric':[1,1,1,2,2,2],
 'barred_pair_hc_sign':'-1','massive_pole':'p^2+|m|^2','normalized_massive_Pfaffian_ratio':R['massive_normalized_Pfaffian_ratio'],
 'strict4D_physical_Weyl_action_recovered':True,'free_auxiliary_factor_normalized_out':True,'hat_kinetic_mixing_retained':True,
 'complete_classical_breaking':'q_of_hat_cross_kinetic_only','raw_compact_IBP_current_checked':True,'generic_full_mass_variation_cancels':True,
 'physical_antifield_copies':1,'physical_source_formal_components_three_families':192,'total_formal_regulator_Grassmann_components':384,
 'source_cotangent_pullback_checked':True,'source_nilpotence_inherited_full45_and_sensitive_toy_checked':True,'source_nilpotence_insensitive_to_overall_source_factor':True,
 'PQ_Yukawa_neutrality_inherited':'REGULATOR_PQ_MIXING_STILL_BREAKS','new_loop_integrals':0,'new_physical_sterile_fields_or_flavor_fit':False,
 'quantum_measure_phase_QAP_or_full_restoration_qualified':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
