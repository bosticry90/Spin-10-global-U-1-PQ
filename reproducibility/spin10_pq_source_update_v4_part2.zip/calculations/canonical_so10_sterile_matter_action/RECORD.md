# SMA1: full provisional charged/sterile matter action and source domain

Basec03df9606b48c2cbf1024009ac53eea9f8ba4d79/main,30152trackedblobs.
Actual preflight clean/no matching workers. Previous goal turn PROGRESS:
CPC1 finite contact/insertion and CSC1 selected continuation conversion.
Question: can that continuation contain the ACTUAL full symmetric Yukawa
maps and sources, reduce to the original Weyl action in4D, and retain a
correct massive Gaussian plus an explicit evanescent breaking? This is
necessary before applying mass-dependent fermion loops or restoration results.

Freeze liveAGENTS/CHARTER/state113/34of39,V482/local/solo policies; original
Yukawa convention; YCT1 complete primary/replayB10/B126/generators/receipt;
CSC1/FSN1/CPC1/MEB1/MEC1 records/results/receipts and the native capture helper.
Reuse YCT1's full45 covariance proof, not just its vacuum tangent. Its two
maps include all328 real scalars and their physical complement. No old
scientific replay or new numerical flavor/mass/vacuum selection. Family
matrices Y10,Y126 remain general complex symmetric3x3 matrices.

Domain: conditional local classical regularized action, complex Grassmann
coordinates, BMHV bar/hat gamma and C^T=-C, C^-1 gamma C=-gamma^T,
C^-1 chi C=chi^T. No real Euclidean Majorana condition, trace-domain/QAP,
measure, global phase or physical scheme adoption. Exact finite witnesses
test algebra; auxiliary matrix sizes are not extra particles or physical traces.

Let N=3*16=48 and M(x)=sum_R Y_R tensor unvec(B_R x). Use existing
mass/spurion convention qM=-ig c(T^T M+M T), qMdagger=ig c(T Mdagger+
Mdagger T^T). Scalar qx=-g rho(c)x and YCT covariance imply this for all
328 directions. PQ:M hascharge-2, physicalleftfermion+1. Phi/S have no
direct Yukawa but the full physical scalar complement is retained.

Unconstrained Dirac variables psi,barpsi have charged PL and auxiliary
sterile PR components. D=gamma.partial-ig bar_gamma PL T_a G^a.
The Euclidean complex-Grassmann density is

 barpsi D psi + 1/2 psi^T C PL M psi
                    - 1/2 barpsi PR Mdagger C^-1 barpsi^T.

Derive, rather than guess, the minus of the barred pairing from a fixed
four-dimensional Lorentzian C/gamma0 Hermitian-conjugation identity. Check
its Euclidean massive pole with an explicitly antisymmetric two-mode
derivative. A single Fourier p block alone is not an alternating Gaussian:
functional transpose includes integration by parts/p->-p.

Define chi_c=C^-1 barpsi^T and Xi=(psi,chi_c). The alternating operator is

 K_Xi = diag(C,C) * [[PL M, -D_c],[-D, PR Mdagger]],
 D_c=gamma.partial+ig bar_gamma PR T^T G.

Its kinetic coefficient is symmetric with derivative transpose; its mass/
current density is alternating. qXi=ig c diag(PL T,-PR T^T)Xi.
Change to physical P=PL psi-PR chi_c and auxiliary S=PR psi-PL chi_c.
With Xi=R(P,S), R=[[PL,PR],[-PR,-PL]], prove by congruence that

 K_PS=diag(C,C) * [[D_phys, hat_gamma.partial_hat],
                  [hat_gamma.partial_hat, bar_gamma.partial_bar]],
 D_phys=bar_gamma.partial_bar-ig bar_gamma A G+PL M+PR Mdagger,
 A=PL T-PR T^T, Atilde=PR T-PL T^T.

All gauge/Yukawa vertices act only on P. S is inert and free in the4D limit;
its field-independent factor is normalized out. At nonzero hats it mixes
kinetically with P, so do not discard it inside a loop. The full Gaussian
is Pf(K), -TrlogK/2. At M=0 it gives CSC's ordinary Dirac determinant;
at hats=0 it factors into the original massive Weyl/Majorana Pfaffian and
the free auxiliary Pfaffian. No massive ordinary-Dirac determinant shortcut.

BRST: qP=ig c A P,qS=0,qbarP=-ig c barP Atilde (ghostLEFT), same inherited
qc/qG and qM law. The complete new classical breaking is the variation of
the hatted cross kinetic term. Raw ghost-left form:

 qS_hat=(ig/2)[(dhat c) barS hat_gamma A P
             +c barS hat_gamma A dhat P-c barP Atilde hat_gamma dhat S].

Using the actual alternating transpose/IBP rules, derive the equivalent
ig[(dhat c)barS hat_gamma A P+c barS hat_gamma A dhat P], keeping the boundary
current. No hatted gauge vertex or scalar-mass remainder is assumed absent:
show the former's support and the latter's cancellation from full qM.
GlobalPQ also breaks through this regulator mixing; classical Yukawa PQ
neutrality is not a quantumPQ identity or removal of the intended PQ anomaly.

One even physical Nambu antifield K_P, gh-1,dimension3/2, with Ssrc=K_P qP
once and qK_P=0. Derive its cotangent pullback to charged psi/barpsi sources;
do not double it or reuse a single unconstrained-Dirac source naively.
Auxiliary source term is zero because qS=0. Prove source nilpotence using
inherited full45 Lie/BRST premises and a sensitive finite exterior-algebra
test. Under ghostdimension1, q raisesdimension1 and the breaking density
hasdimension5,gh1. Keep physicalsource192/formalGrassmann384 coordinate
counts distinct from particles and from finite Clifford witness size.

Primary: fullsplitC16 algebra, Xi-to-PS congruence, operator coefficient
projection, principal symbol and source pullback. Replay: explicit two-
component Dirac/paired density expanded in an exterior algebra with a
two-mode antisymmetric derivative, plus direct sparse Pfaffians and the
massive spectral polynomial. Its hat jet test needs only C/projector
transpose rules, not an impossible four-by-four full BMHV algebra; primary
supplies the joint split-Clifford check. Separate gate: actual328input
coefficient comparison/authentication, family-coordinate symmetry, generic
mass covariance, odd-Leibniz/IBP/source checks and negative controls.

Do not rerun YCT's7.5million covariance positions. Transfer via an explicit
generic matrix/linear tensor proof, with old covariance as a bound premise.
Report inherited versus newly checked positions honestly. Wrong h.c. sign,
missing conjugate Yukawa, omitted physical complement, source doubling,
untransformed transpose/ghost sign, omittedhatmix and a massiveDiracfactor
must be detectable. Phase and analytic quantum-domain questions stay open.

Anchor: Belusca-Maito et al.2004.14398v2,Eqs2.13-2.18,3.26-3.29 andSecs3/9,
https://arxiv.org/pdf/2004.14398 . Charged/singlet continuation and
evanescent action breaking are inherited QFT, not AI discoveries. No paper
counterterms are imported. Shared action/data/physical premises/software/AI
authorship limit corroboration, not independent scientific confirmation.

Freeze7sources/copies before sequential primary/replay/separate gate.600s
each afterimports,8GiB sampledprivate,350MiB launchfloor,16MiB package.
Preserve every failed/unfinished execution and version any correction. No
agents, oldevidence edits, statechange, externalactions or foundational
adoption. Authority34/39,E5/A5unqualified,flavorpaused,HB1/C5blocked,custody
exit2/seven NOTPASS. Both scalar points' negative evidence remains intact.
