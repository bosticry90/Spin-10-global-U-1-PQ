# SMA1 result: full provisional Yukawa action, Gaussian and sources constructed

The charged/sterile continuation now has a complete typed classical matter
action containing the actual symbolic10/126 Yukawa couplings and their
conjugates. It reduces to the original physical Weyl action plus a normalized
free auxiliary factor in four dimensions. Its remaining classical variation
is explicitly confined to the hatted kinetic mixing. This is a provisional
classical construction, not a complete regulated quantum prescription.

Actual separate receipt status:
`QUALIFIED_PROVISIONAL_FULL_CHARGED_STERILE_YUKAWA_ACTION_AND_SOURCE_DOMAIN`,
SHA-256
`21d4816d5ea079b28b41783e8d65aa3bd52d779349c90106d4dec5e99e10bd41`.
Scientific/director acceptance NOT_PERFORMED; authority remains34/39.
The concrete action and conventions are in [ACTION_V1.md](ACTION_V1.md).

## What is established

- All328 real scalar directions enter through the complete bound YCT1 maps.
  The two symmetric family matrices retain their six original complex entry
  coordinates each. No numerical Yukawa, mass, flavor fit or new vacuum was
  chosen. The full physical scalar complement remains present.
- A direct charge-conjugation h.c. identity fixes the barred-pair minus sign.
  Independent component Grassmann expansion reproduces the physical/auxiliary
  block action, including both Yukawa chiralities and gauge-current transposes.
- The massive Gaussian uses a Pfaffian. For a finite antisymmetric derivative
  pair the normalized ratio is `(p^2+m*mbar)^2/p^4`, while the wrong h.c. sign
  gives `(p^2-m*mbar)^2/p^4`. This checks the positive **strict4D** massive pole;
  it is not a finite-hat propagator result. A single Fourier block lacking its
  transpose/opposite-momentum partner would not test an alternating Gaussian.
- The full split principal Clifford symbol and free physical propagator support
  agree with CSC1's massless counting: hats mix physical and auxiliary blocks,
  while physical vertices have no direct auxiliary support. At nonzero hats
  the auxiliary variables must stay inside internal propagators.
- The full Yukawa mass variation cancels by a generic matrix proof and the
  inherited all45 covariance theorem. New raw/compact evanescent variations
  agree modulo an explicit boundary current under a separate exterior algebra.
- One physical Nambu source and its Dirac cotangent pullback preserve source
  normalization. A sensitive noncommuting ghost test checks odd source closure.
  Nilpotence by itself is insensitive to an overall source factor; the separate
  cotangent-pairing test detects doubling.

The global PQ Yukawa assignment remains the original one. The regulator's
hatted kinetic mixing has nonzero PQ variation. This is not removal of the
already qualified physical PQ anomaly or a quantumPQ restoration result.

## Evidence and scope

Primary checks16 complete operator identities across16,384 spin/block positions
with a full split-C witness. Replay expands an independent component quadratic
Grassmann density across2,432 positions, with direct sparse paired-mode
Pfaffians. Its separate hat-jet test uses only the needed projector/transpose
identities; it is explicitly not a four-by-four full BMHV representation.
The separate gate compares all167,936 actual scalar-map positions and tests
generic holomorphic/conjugate mass covariance, family coordinates, the odd
Leibniz rule, IBP current and source pullback. The old7,557,120-position-per-route
YCT covariance calculation is authenticated and used as a theorem, not rerun.

The charge-conjugation, fictitious complementary chirality and evanescent
kinetic split are established methods; see
[Belusca-Maito et al., Secs2-3 and9](https://arxiv.org/pdf/2004.14398).
The specific model tensors, block construction and controls are project
calculations. They share action conventions, historical qualifications,
Python/SymPy and AI authorship. This is computational corroboration, not
independent physical validation or a new general quantization theorem.

Primary/replay/gate completed exit0 in2.4574078/1.1243348/11.8642171 seconds
after imports. Their2/2/7 samples have private maxima48,386,048/51,986,432/
55,472,128 bytes, not peak measurements. Launch available commit exceeded
11.13GB. Preparation42/validation49 bindings and seven source copies precede
the workers. Frozen600s/8GiB sampled/350MiB launchfloor/16MiB package limits
were unexhausted. No failed or unfinished scientific worker occurred. Complete
captures are preserved; zero new loop integrals were performed.

## What changes next

The missing classical matter/Yukawa/source definition is now explicit for
this provisional continuation. A new massive loop must still use its actual
finite-hat block inverse. The standard p^2+|m|^2 denominator is qualified only
for the strict4D spectral test above. Deriving that block inverse, its limits
and any legitimate auxiliary-mass comparison is the next economical test.

Quantum measure/phase, analytic domain, QAP, full non-Abelian finite restoration,
massive threshold and physical viability remain unqualified. No physical scheme
or foundational field content was adopted. Scalar hierarchy failures, the finite
witness's approximately140% singlet correction, paused flavor work, HB1/C5
blocks and historical custodyexit2/seven NOTPASS remain unchanged.
