"""SMA1 operator congruence, full split algebra and cotangent source map."""
from data import *
start=begin('primary');pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
g4=[s.kronecker_product(pa[1],z) for z in pa]+[s.kronecker_product(pa[0],s.eye(2))]
g8=[s.kronecker_product(g,pa[2]) for g in g4]+[s.kronecker_product(s.eye(4),z) for z in pa[:2]]
C8=g8[0]*g8[2]*g8[5];C=s.kronecker_product(C8,pa[1]);Ci=C.inv();g=[s.kronecker_product(a,s.eye(2)) for a in g8]
chi=s.kronecker_product(s.diag(1,1,-1,-1),s.eye(4));PL=(s.eye(16)+chi)/2;PR=s.eye(16)-PL;Z=s.zeros(16)
def block(a,b,c,d):return s.SparseMatrix(s.BlockMatrix([[a,b],[c,d]]).as_explicit())
def zero(M):assert not s.SparseMatrix(M).applyfunc(s.simplify).todok()
zero(C.T+C);zero(Ci*chi*C-chi.T)
for j,h in enumerate(g):
 zero(Ci*h*C+h.T);zero((C*h).T-C*h)
 zero(h*chi+chi*h if j<4 else h*chi-chi*h)
R=block(PL,PR,-PR,-PL);Ri=block(PL,-PR,PR,-PL);zero(Ri*R-s.eye(32));zero(R.T-Ri)
coeff={};positions=0
def check(name,old,target):
 global positions
 got=s.SparseMatrix(R.T*old*R);zero(got-target)
 den=s.trace(target.H*target);a=s.simplify(s.trace(target.H*got)/den);zero(got-a*target);coeff[name]=str(a);positions+=1024
for j,h in enumerate(g):
 old=block(Z,-C*h,-C*h,Z)
 target=block(C*h,Z,Z,C*h) if j<4 else block(Z,C*h,C*h,Z)
 check(('kin_bar_' if j<4 else 'mix_hat_')+str(j),old,target)
check('mass_holo',block(C*PL,Z,Z,Z),block(C*PL,Z,Z,Z))
check('mass_anti',block(Z,Z,Z,C*PR),block(C*PR,Z,Z,Z))
for j,h in enumerate(g[:4]):
 check('current_T_'+str(j),block(Z,Z,s.I*C*h*PL,Z),block(-s.I*C*h*PL,Z,Z,Z))
 check('current_Ttranspose_'+str(j),block(Z,-s.I*C*h*PR,Z,Z),block(s.I*C*h*PR,Z,Z,Z))
genT=Ri*block(PL,Z,Z,Z)*R;gent=Ri*block(Z,Z,Z,-PR)*R
zero(genT-block(PL,Z,Z,Z));zero(gent-block(-PR,Z,Z,Z))
# The source row is pulled back with the inverse field map, not a half.
source= s.SparseMatrix.hstack(s.eye(16),Z)*Ri
zero(source-s.SparseMatrix.hstack(PL,-PR));zero(source*R-s.SparseMatrix.hstack(s.eye(16),Z))
greg=[block(h,Z,Z,h) for h in g[:4]]+[block(Z,h,h,Z) for h in g[4:]];clifford=0
for i in range(6):
 for j in range(i,6):zero(greg[i]*greg[j]+greg[j]*greg[i]-2*int(i==j)*s.eye(32));clifford+=1
P=block(s.eye(16),Z,Z,Z)
for h in greg[4:]:zero(P*h*P)
PQ=block(chi,Z,Z,Z);PQtilde=block(-chi,Z,Z,Z)
assert s.SparseMatrix(greg[4]*PQ-PQtilde*greg[4]).todok()
# A fixed Lorentzian four-component h.c. identity determines the barred-pair sign.
eps=s.Matrix([[0,1],[-1,0]]);C4=s.diag(eps,-eps);gamma0=s.BlockMatrix([[s.zeros(2),s.eye(2)],[s.eye(2),s.zeros(2)]]).as_explicit();L4=s.diag(1,1,0,0);R4=s.eye(4)-L4
zero(gamma0*(C4*L4).H*gamma0.T+R4*C4.inv())
finish('primary',{'method':'full_split_C_congruence_and_source_cotangent_map','coefficients':coeff,'operator_identity_positions':positions,'R':enc(R),'R_inverse':enc(Ri),
 'source_pullback':enc(source),'generator_T':enc(genT),'generator_Ttranspose':enc(gent),'Clifford_relations':clifford,'physical_hat_propagator_block_zero':True,
 'barred_pair_hc_sign':'-1','kinetic_requires_IBP_transpose':True,'physical_antifield_copies':1,'auxiliary_BRST_transform':'0',
 'strict4D_physical_factor':'massive_Weyl_Majorana_Pfaffian','strict4D_auxiliary_factor':'free_field_independent_Pfaffian_normalized_out',
 'witness_spin_dimension':16,'physical_spin_dimension':4,'global_PQ_hat_mixing_nonzero':True,'new_loop_integrals':0,'provisional_only':True},start)
