# V3U1 prospective derivation

The V3S action is g f_bc^a (Dbar_mu Q_nu)^a Q_mu^b Q_nu^c. Its Hessian
linear in external Q has first derivative coefficient
A_lambda,ab=-2Q_lambda delta_ab+Q_a delta_b,lambda+Q_b delta_a,lambda.
Use W=-A/2. Original cubic Kqq=0, so completing the square gives Eqq=sum W2.
Keep E0=-2Fbar, connection curvature, color order and graded/real Gaussian
weight. The primary free-word calculation extracts the F01[Q0,Q1] invariant
from Tr(E0 Eqq)+Tr(Omega0 Omegaqq)/6. Convert raw first-jet beta and raw
curvature delta to the canonical Hessian c=2(delta-beta), in exactly QDV's
ordering. The quartic Kqq=-Q2 delta+Q_a Q_b-2[Q_a,Q_b] is a SEPARATE term.
Replay extracts the cubic coefficient directly from the constant full
density Hessian with Kqq removed; its kinetic/longitudinal invariants are
subtracted using independently measured flat a,b. It does not infer c from
a Ward identity or from a desired pole remainder.

For mass, Tr_L sum W2 determines the original cubic pole against a general
internal Gram. Both ordered mass placements are retained:
V_ab=-Tr[Gram(Fa Fb+Fb Fa)]/2. Replay obtains the same coefficient from the
literal cubic vertex at external p=0, expanding each internal denominator.
The qualified full-vector mass is the sum of cubic and quartic, not the
cubic operator by itself. QUS stores mass in ell60g4 units and curvature
with an explicit factor2 in its operator definition. These are different
type conversions, tested separately.

For the universal real color triangle, J=[[0,-1],[1,0]],
T0=t[[0,I],[-I,0]], T1=t[[0,J],[J,0]], h=diag(rJ,sJ),
Ty=(r-s)J. Verify [h,Ta]=sum_b Ty_ba Tb without full Lie closure. Extend
f_(a,j+2,i+2)=Ta_ij antisymmetrically on six real directions. Three real
planes carry masses(z,x,y) and charges(r-s,r,s), with charge squares
(qx+qy)^2,qx^2,qy^2 when r=-qx,s=qy. Verify all f entries and zero
complement, covariance, ordered mass roles and the real cut normalization.
The full original graph has Lambda/g2=(1/2) sum_ijk f_ijk^2 U; no new
ghost sign or extra1/3 is applied to a full real trace. A single labelled
cut may instead carry1/3, but must not be combined with full trace again.

Let measured loop coefficients be a,b,c times tau, and mass n V. CTs
A=-a, B=-b, C=-c and mass=-nV. Write CT as A KYM+(B-A)DD+(C+2A)F-nV.
Qualified remaining-loop traces at squared mass v are:
KYM:(21/2+eps)H(v), DD:H(v)/2, F:-12 H(v)/eps,
negative mass:-nV gives +(10+eps)nV H(v)/v.
H(v)=exp(gammaE eps)Gamma(1+eps)(Q2/v)^eps.
All carry the original subgraph1/eps. Native scripts derive the color
normalization ratio from the full six-direction f trace and close every
edge, not only one convenient vector. Replay instead uses separate kinetic
identity (10+eps)H-24H/eps, DD H/2, F -12H/eps and mass identity.

Only after both native forests are complete does validation read the
authenticated V3B bare arrays. At Q2=1, expand H=1-eps logv+
eps2(logv2+zeta2)/2 through the finite coefficient, and add to each bare
axis. Under J=logQ2 the bare graph scales exp(2epsJ), forest exp(epsJ).
Keep double poles and the resulting quadratic scale logarithms. Any
remaining overall poles belong to subsequent parent assembly; no automatic
vanishing, anomaly interpretation or finite physical normalization is imposed.
