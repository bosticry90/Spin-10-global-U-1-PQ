"""V3U1 free ordered words; original full-real cubic cut."""
from data import *
from itertools import permutations

def words():
    q0,q1=s.symbols('q0 q1',commutative=False);Q=[q0,q1,0,0];N=4
    W=[s.Matrix(N,N,lambda a,b:Q[lam]*int(a==b)-(Q[a]*int(b==lam)+Q[b]*int(a==lam))/2) for lam in range(N)]
    E=sum((v*v for v in W),s.zeros(N));e=s.expand(-2*E[1,0]+2*E[0,1])
    omega=s.expand(s.trace(W[0]*W[1]-W[1]*W[0]));comm=q0*q1-q1*q0
    for v in [e,omega]:assert s.expand(v-v.coeff(q0*q1)*comm)==0
    delta=clean(-R(1,2)*(e.coeff(q0*q1)+omega.coeff(q0*q1)/3)/2)
    n=clean(s.trace(E).subs(q1,0).expand().coeff(q0,2))
    K=s.Matrix(N,N,lambda a,b:-sum(q*q for q in Q)*int(a==b)+Q[a]*Q[b]-2*(Q[a]*Q[b]-Q[b]*Q[a]))
    eq=s.expand(-2*K[1,0]+2*K[0,1]);quartic_delta=clean(-R(1,2)*eq.coeff(q0*q1)/2)
    quartic_n=clean(s.trace(K).subs(q1,0).expand().coeff(q0,2))
    qdv=packed(CAL/'canonical_so10_quantum_vector_derivative_uv/primary_tables.json.gz')['per_index_coefficients']['vector']
    raw=json.loads((CAL/'canonical_so10_quantum_vector_derivative_uv/primary_result.json').read_bytes())['diagnostics']['raw_color_trace_basis']['vector']
    a,b=map(s.sympify,[qdv['a'],qdv['b']]);beta=s.sympify(raw[1]);c=clean(2*(delta-beta));qc=2*quartic_delta
    return a,b,c,n,qc,quartic_n,{'E0E2_commutator':str(e.coeff(q0*q1)),'Omega0Omega2_half_orientations':str(omega.coeff(q0*q1)),
      'raw_delta_cubic':str(delta),'raw_beta_inherited':str(beta),'mass_Lorentz_trace':str(n),'raw_delta_quartic':str(quartic_delta)}

def triangle():
    r,ss=s.symbols('r s',real=True);JJ=s.Matrix([[0,-1],[1,0]]);I=s.eye(2);Z=s.zeros(2)
    Ts=[s.Matrix.vstack(s.Matrix.hstack(Z,I),s.Matrix.hstack(-I,Z)),s.Matrix.vstack(s.Matrix.hstack(Z,JJ),s.Matrix.hstack(JJ,Z))]
    h=s.diag(r*JJ,ss*JJ);Ty=(r-ss)*JJ
    for a,T in enumerate(Ts):zero(h*T-T*h-sum((Ty[b,a]*Ts[b] for b in range(2)),s.zeros(4)))
    f={}
    for a,T in enumerate(Ts):
        for i in range(4):
            for j in range(i+1,4):
                if not T[i,j]:continue
                base=(a,i+2,j+2)
                for p in permutations(range(3)):
                    sign=(-1)**sum(p[i]>p[j] for i in range(3) for j in range(i+1,3))
                    f[tuple(base[k] for k in p)]=-sign*T[i,j]
    F=[s.SparseMatrix(6,6,{(k,j):v for (a,j,k),v in f.items() if a==i}) for i in range(6)]
    hh=s.diag(Ty,r*JJ,ss*JJ);mass=s.diag(z,z,x,x,y,y)
    for a in range(6):zero(hh*F[a]-F[a]*hh-sum((hh[b,a]*F[b] for b in range(6)),s.zeros(6)))
    tau=s.Matrix(6,6,lambda a,b:-s.trace(F[a]*F[b]));zero(tau-4*s.eye(6))
    V=s.Matrix(6,6,lambda a,b:clean(-s.trace(mass*(F[a]*F[b]+F[b]*F[a]))/2))
    total=sum(v*v for v in f.values());unit=total/2;ratios=[];rows=[]
    for k,v in enumerate([z,x,y]):
        q=[r-ss,r,ss][k];ids=range(2*k,2*k+2)
        weighted_tau=sum(q*q*tau[a,a] for a in ids);weighted_mass=sum(q*q*V[a,a] for a in ids)
        ratio=clean(weighted_tau/(unit*q*q));ratios.append(ratio)
        others=sum([z,x,y])-v
        assert clean(weighted_mass/(unit*q*q)-ratio*others/2)==0
        rows.append({'mass':str(v),'charge':str(q),'weighted_tau':str(weighted_tau),'weighted_mass':str(weighted_mass)})
    assert len(set(ratios))==1
    return ratios[0],{'f_nonzero':len(f),'f_norm':str(total),'unit_from_real_Wick_and_full_cut':str(unit),'tau':enc(tau),'V':enc(V),'rows':rows,'ratio':str(ratios[0])}

def main():
    start=begin();a,b,c,n,qc,qn,diag=words();ratio,col=triangle();print('STAGE original_linear_Hessian_and_full_real_triangle',flush=True)
    A,B,C=-a,-b,-c;axes={}
    for i,v in enumerate(masses):
        others=sum(masses)-v
        pre=clean(ratio*((R(21,2)+eps)*A+(B-A)/2-12*(C+2*A)/eps+(10+eps)*n*others/(2*v))/eps)
        p2,p1,p0=[clean(s.expand(pre).coeff(eps,k)) for k in [-2,-1,0]]
        lv=s.log(v);jet=[p2,p1-p2*lv,p0-p1*lv+p2*(lv**2+s.zeta(2))/2]
        axes[str(i)]={'prefactor':list(map(str,[p2,p1,p0])),'forest_Laurent_Q1':list(map(str,jet))}
    print('STAGE original_UV_closure_before_bare_fields',flush=True)
    full=full_table('primary',a,b,c,n,qc,qn)
    save('primary',{'schema':'V3U1_NATIVE','per_index':{k:str(v) for k,v in zip(['a','b','c','mass','quartic_c','quartic_mass'],[a,b,c,n,qc,qn])},
      'word_diagnostics':diag,'triangle':col,'axes':axes,'full45':full,'V3B_Laurent_fields_read':False,'UV_coefficients_fitted_to_bare_poles':False},start)
if __name__=='__main__':main()
