"""V3U1 inherited IO, actual full45 inputs; no new UV contraction here."""
from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
R=s.Rational
x,y,z,eps=s.symbols('x y z eps',positive=True);masses=[x,y,z];J=s.Symbol('J',real=True)
def clean(v):return s.cancel(s.expand(v))
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def expr(v):return s.sympify(v,locals={str(t):t for t in [*masses,eps,J]})
def mat(v):return s.SparseMatrix(*v['shape'],{(i,j):s.sympify(a) for i,j,a in v['entries']})
def tidy(M):return s.SparseMatrix(M).applyfunc(clean)
def enc(M):return {'shape':list(map(int,M.shape)),'entries':[[int(i),int(j),str(v)] for (i,j),v in sorted(tidy(M).todok().items())]}
def zero(M):assert not tidy(M).todok(),'NONZERO_MATRIX'
def tr(A,B):return clean(sum((v*B[j,i] for (i,j),v in A.todok().items()),s.Integer(0)))
def begin(prep='preparation.json'):
    start=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for p,h in json.loads((HERE/prep).read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
    return start
def save(role,v,start):
    raw=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/f'{role}_tables.json.gz').open('xb') as f:f.write(blob)
    print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':time.perf_counter()-start,'tables_sha256':sha256(raw).hexdigest(),
      'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)
def full_inputs(role):
    d=packed(CAL/'canonical_so10_background_threshold_inputs'/f'{role}_tables.json.gz')
    f={(a,b,c):s.sympify(v) for a,b,c,v in d['f']}
    F=[s.SparseMatrix(45,45,{(c,b):v for (a,b,c),v in f.items() if a==h}) for h in range(45)]
    G=s.SparseMatrix(45,45,{(i,j):s.sympify(v) for i,j,v in d['Gram']})
    emb=mat(packed(CAL/'canonical_so10_vector_quartic_ir_matching'/f'{role}_tables.json.gz')['light_embedding'])
    H=[tidy(sum((emb[a,j]*F[a] for a in range(45) if emb[a,j]),s.zeros(45))) for j in range(12)]
    return F,G,H
def full_table(role,a,b,c,n,quartic_c,quartic_n):
    F,G,H=full_inputs(role)
    tau=s.SparseMatrix(45,45,{(a,b):-tr(F[a],F[b]) for a in range(45) for b in range(45) if tr(F[a],F[b])})
    V=s.SparseMatrix(45,45,{(a,b):clean(-tr(G,F[a]*F[b]+F[b]*F[a])/2) for a in range(45) for b in range(45)})
    zero(tau-8*s.eye(45))
    qdv=packed(CAL/'canonical_so10_quantum_vector_derivative_uv'/f'{role}_tables.json.gz')
    qmv=packed(CAL/'canonical_so10_quantum_vector_mass_uv'/f'{role}_tables.json.gz')
    qus=packed(CAL/'canonical_so10_vector_quartic_uv_subgraphs'/f'{role}_tables.json.gz')
    old=qdv['per_index_coefficients']['vector']
    assert clean(a-s.sympify(old['a']))==clean(b-s.sympify(old['b']))==0
    assert clean(c+quartic_c-s.sympify(old['c']))==0
    zero(V-mat(qmv['V']));zero((n+quartic_n)*V-mat(qmv['groups']['vector']))
    zero(quartic_n*V-60*mat(qus['Sigma_mass_heavy_residue']))
    curv=[tidy(c*tau*T) for T in H];quartic=[tidy(quartic_c*tau*T) for T in H]
    for i,col in enumerate([0,1,4]):zero(quartic[col]-2*mat(qus['Sigma_curvature_full_residues'][i]))
    return {'tau':enc(tau),'V':enc(V),'a':enc(a*tau),'b':enc(b*tau),'curvature':list(map(enc,curv)),
      'mass':enc(n*V),'quartic_curvature':list(map(enc,quartic)),'quartic_mass':enc(quartic_n*V),
      'mass_QUS_type_factor':60,'curvature_QUS_type_factor':2,'all12_H_and_full45_zero_complements_checked':True}
