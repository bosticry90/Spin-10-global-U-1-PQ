# V3U1 result: original cubic UV poles and positive proper forest

Qualified within the frozen C1 reference by validation_receipt.json,
SHA256640e8e187c8acfea99762651e163c82cefba34e8db42daf78cdbcc1d5a8d9bb8.
Director acceptance NOT_PERFORMED. State113/authority34of39 unchanged.

The action-based cubic pole coefficients per color index are
(a,b,c,mass)=(-19/12,-11/6,1/6,9/2). The separate quartic contributes
c=3,mass=-3. Adding these reproduces the previously qualified vector-only
derivative/curvature and mass classes. Full45 matrices, all12 H curvature
operators and their zero complements agree; ghost/scalar inputs were not
substituted. QUS curvature converts by2; its mass converts by60. These are
typed conversions, not an overall factor on the old closure.

The primary free-word Hessian gives raw cubic delta=-7/8 from the independent
E0E2 commutator coefficient3 and connection-curvature coefficient3/2.
Combined with raw beta=-23/24 this gives c=1/6. A literal momentum bubble
and two noncommuting density-Hessian configurations reproduce it without
reading V3B Laurent fields. The mass coefficient follows both Lorentz W2
and the actual p=0 vertex with both denominator mass placements.

The real six-direction H-covariant triangle derives the original cut
ratio2/3. Restricted carriers need no full Spin10 Lie closure. For axisx,
with Hx=exp(gamma eps)Gamma(1+eps)(Q2/x)^eps, the original proper forest is

    Hx[-24/eps2+(67/6+15(y+z)/x)/eps+19/18+3(y+z)/(2x)].

Other axes permute masses. The positive-mass Rprime is the authenticated
V3B bare kernel plus this forest, read only after native UV derivation.
Every axis has remaining poles -12/eps2+61/(6eps), independent of masses.
These are not subtracted here. Mass dependence cancellation was observed,
not used to fit a coefficient. Explicit finite functions and full scale
arrays are in the receipt. Scale transport gives quadratic logQ2 coefficient12;
the linear coefficient on axisx is55/6-24logx-15(y+z)/x. A linear scale ansatz
would lose a real term. Forest eps-positive factors are retained.

Controls detect wrong full-vector curvature, omitted longitudinal/cubic
curvature, early-D4 remaining loop, half/double forest, one mass placement,
and wrong QUS type conversion. The mass-placement control is generically
nonzero but is insensitive at equal internal masses, as its expression shows.
No soft/full-EFT matching, complete VVV amplitude, parent-minus-family
counterterm or finite physical scheme has been supplied. Inventory remains6/9.

Primary3.6119627s/replay4.93684s/validation1.7675419s after imports; sampled
native private maxima52,002,816/52,527,104 bytes. All under frozen600s/8GiB
sampled/350MiB launch/6MiB package. No failed native run, timeout, cancellation
or output truncation. Sources and3656 initial bindings frozen before execution.
Commands prepare.py then run.py, with complete sequential captures.

Shared action, reference, heat a4, inherited QDV/QMV/SCU/CCK premises, symbolic
software, full45 IO helper and AI authorship limit independence. This is
internally checked mathematical research, not external physical confirmation.
Read-only source discovery included incorrect guesses for historical filenames;
those lookup errors did not execute science or change frozen inputs.

Next: derive equal-heavy one-light hard region from the actual general-D
numerator, then independently construct its opened-heavy-loop soft term and
common-delta subtraction before promoting a matched kernel. Keep all-light
H EFT and the three heavy unordered orbits for the eventual actual sum.
