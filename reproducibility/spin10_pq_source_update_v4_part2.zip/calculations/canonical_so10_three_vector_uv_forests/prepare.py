"""V3U1 freeze exact action/projector ancestry and all source bytes."""
from pathlib import Path
from hashlib import sha256
import json,ast,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
BASE='101526af31d43ad5d851fd9174f7585395cb9b51'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/three-vector-uv-forests-v1-2026-10-21')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='main'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT).strip()
def dump(p,b):
    with p.open('xb') as f:f.write(b)
deps={};cache={};qualified={}
for folder,receipt,want,wantsha in [('canonical_so10_three_vector_support', 'validation_receipt.json', 'QUALIFIED_ACTUAL_THREE_VECTOR_VERTEX_AND_COMPLETE_MASS_CHARGE_SUPPORT', 'd39535044d58a01dcccac5002698b9be13f5e846e25bcb75b261c3338a9915c7'), ('canonical_so10_three_vector_heat_kernel', 'validation_receipt.json', 'QUALIFIED_FULL_ORDERED_THREE_VECTOR_GENERAL_D_BARE_F2_HEAT_KERNEL', 'b2f9c8b63350f586702d3b6e680ab9246f5fc2ca766661c490971c4d289a79a9'), ('canonical_so10_three_vector_bare_kernel', 'validation_receipt.json', 'QUALIFIED_COMPLETE_POSITIVE_MASS_THREE_VECTOR_BARE_LAURENT_KERNEL', 'd35634cd4e5fa0d1f6c2af5b0ea9dbbc8dd75ab2993072ba07b96ae6e55500dd'), ('canonical_so10_quantum_vector_derivative_uv', 'validation_receipt.json', 'QUALIFIED_FIXED_REFERENCE_QUANTUM_VECTOR_DERIVATIVE_AND_CURVATURE_UV_POLES', '49dac2034b108e37abfaaf6f5f5f470d18e77a8dbaa7b583502fe293d543637f'), ('canonical_so10_quantum_vector_derivative_uv', 'validation_receipt_v2.json', 'QUALIFIED_FIXED_REFERENCE_QUANTUM_VECTOR_DERIVATIVE_AND_CURVATURE_UV_POLES', '58a4e975eefd7a8926c5d50b4d580bc361c071c8334f25350d9aa906f344c47d'), ('canonical_so10_quantum_vector_mass_uv', 'validation_receipt.json', 'QUALIFIED_FULL_VECTOR_MASS_UV_POLE_AND_EXACT_FIELD_NORMALIZATION_RECONCILIATION', 'fedbac91e74fbe319bc6960add48a3cc0f2349670abba45746e3c0cee758a15a'), ('canonical_so10_vector_quartic_uv_subgraphs', 'validation_receipt_v2.json', 'QUALIFIED_FULL_INTERNAL_POLE_SPLIT_HEAVY_INSERTIONS_AND_KNOWN_PARENT_JET_LIMIT', 'c9b545e1c00c9750a587c6543315431ee0620f7e19fd2168db5fcf1533290fa4'), ('canonical_so10_scalar_current_forests', 'validation_receipt_v2.json', 'QUALIFIED_CURRENT_SUNSET_UV_FOREST_AND_MASS_INDEPENDENT_RPRIME_POLE', None)]:
    parent=ROOT/'calculations'/folder
    for prep in sorted(parent.glob('*preparation*.json')):
        for n,h in json.loads(prep.read_bytes())['input_sha256'].items():
            if n not in cache:cache[n]=sha256(Path(n).read_bytes()).hexdigest()
            assert cache[n]==h,n
            if n in deps:assert deps[n]==h,n
            deps[n]=h
    for p in sorted(parent.iterdir()):
        if p.is_file():deps[str(p)]=sha256(p.read_bytes()).hexdigest()
    p=parent/receipt;v=json.loads(p.read_bytes())
    if want:assert v['status']==want
    if wantsha:assert sha256(p.read_bytes()).hexdigest()==wantsha
    qualified[folder+'/'+receipt]=sha256(p.read_bytes()).hexdigest()
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V427.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md']:
    p=ROOT/n;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
    p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw,n
    if p.suffix=='.py':ast.parse(raw,filename=str(p))
    cp=HERE/(n+'.source.txt');dump(cp,raw);deps[str(p)]=deps[str(cp)]=sha256(raw).hexdigest()
state='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
old=subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT);assert len(old.splitlines())==27042
CONTROL.mkdir(parents=True,exist_ok=False);dump(CONTROL/'old_git_tree.txt',old)
v={'schema':'V3U1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(deps.items())),
 'qualified_receipts':qualified,'old_blobs':27042,'seconds_each':600,'sampled_private_cap':8*1024**3,
 'launch_floor':350*1024**2,'whole_package_bytes':6*1024**2,'state_sha256':state,'scientific_acceptance':'NOT_PERFORMED'}
dump(HERE/'preparation.json',(json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
print('FROZEN',len(deps),'bindings;27042oldblobs;no science executed',flush=True)
