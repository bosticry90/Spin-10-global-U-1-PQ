"""V3U1 literal momentum and constant-density Hessian; direct operator closure."""
from data import *

def bubble():
    u,p,ir=s.symbols('u p ir',positive=True);l=s.symbols('l0:4');mom=s.Matrix([p,0,0,0]);k=s.Matrix(l)-u*mom
    delta=ir+u*(1-u)*p*p
    def residue(poly):
        ans=0
        for powers,c in s.Poly(s.expand(poly),*l).terms():
            if sum(powers)==0:ans+=c
            elif sum(powers)==2 and 2 in powers:ans-=delta*c/2
            else:assert sum(powers)<=2
        return clean(s.integrate(s.expand(ans),(u,0,1)))
    def vertex(mu,a,b):return int(mu==a)*(mom-k)[b]+int(a==b)*(2*k+mom)[mu]+int(b==mu)*(-k-2*mom)[a]
    vals=[]
    for mu in [1,0]:vals.append(s.expand(-residue(sum(vertex(mu,a,b)**2 for a in range(4) for b in range(4)))/2).coeff(p,2))
    # Literal p=0 vertex, with each of the two denominators expanded once.
    kk=s.symbols('k0:4');mu=0
    vv=sum((-int(mu==a)*kk[b]+2*int(a==b)*kk[mu]-int(b==mu)*kk[a])**2 for a in range(4) for b in range(4))
    angular=clean(sum(s.expand(vv).coeff(v,2) for v in kk)/4)
    return vals[0],clean(vals[0]-vals[1]),angular

def density(C):
    N=len(C);n=C[0].rows;Z=s.zeros(n)
    def L(mu,nu,a):return C[mu]*int(nu==a)-C[nu]*int(mu==a)
    return s.Matrix.vstack(*[s.Matrix.hstack(*[sum((L(mu,nu,a).T*L(mu,nu,b)/2 for mu in range(N) for nu in range(N)),Z)-C[a]*C[b]+C[b]*C[a] for b in range(N)]) for a in range(N)])

def curvature(a,b,swapped):
    N=4;n=3;U=s.Matrix([[0,1,0],[-1,0,0],[0,0,0]]);V=s.Matrix([[0,0,0],[0,0,1],[0,-1,0]]);Z=s.zeros(n)
    A=[U,V,Z,Z];Q=[V,U,Z,Z] if swapped else [U,V,Z,Z]
    Kaa=density(A)+s.Matrix.vstack(*[s.Matrix.hstack(*[-A[i]*A[j] for j in range(N)]) for i in range(N)])
    Kaq=density([h+q for h,q in zip(A,Q)])-density(A)-density(Q)
    XA=[s.kronecker_product(s.eye(N),v) for v in A]
    XQ=[s.Matrix.vstack(*[s.Matrix.hstack(*[Q[lam]*int(i==j)-(Q[i]*int(j==lam)+Q[j]*int(i==lam))/2 for j in range(N)]) for i in range(N)]) for lam in range(N)]
    ZZ=s.zeros(N*n);Eaa=Kaa+sum((v*v for v in XA),ZZ);Eaq=Kaq+sum((h*q+q*h for h,q in zip(XA,XQ)),ZZ)
    Eqq=sum((q*q for q in XQ),ZZ) # ORIGINAL CUBIC: Kqq=0, before square completion.
    value=s.trace(Eaa*Eqq+Eaq*Eaq/2)
    for i in range(N):
        for j in range(N):
            aa=XA[i]*XA[j]-XA[j]*XA[i];qq=XQ[i]*XQ[j]-XQ[j]*XQ[i]
            aq=XA[i]*XQ[j]-XQ[j]*XA[i]+XQ[i]*XA[j]-XA[j]*XQ[i]
            value+=s.trace(aa*qq)/6+s.trace(aq*aq)/12
    value=-value/2
    X=[[A[i]*Q[j]-Q[j]*A[i] for j in range(N)] for i in range(N)]
    Ac=sum(s.trace(v*v) for row in X for v in row);div=sum((X[i][i] for i in range(N)),Z);Cc=s.trace(div*div)
    Jc=sum(s.trace((A[i]*A[j]-A[j]*A[i])*(Q[i]*Q[j]-Q[j]*Q[i])) for i in range(N) for j in range(N));assert Jc
    return clean(2*(value+a*Ac/2-b*Cc/2)/Jc)

def main():
    start=begin();a,b,n=bubble();cs=[curvature(a,b,v) for v in [False,True]];assert cs[0]==cs[1];c=cs[0]
    # Quartic is the direct zeroth-order density Hessian, not the cubic's W2.
    q0,q1=s.symbols('q0 q1',commutative=False);Q=[q0,q1,0,0];K=s.Matrix(4,4,lambda i,j:-sum(q*q for q in Q)*int(i==j)-Q[i]*Q[j]+2*Q[j]*Q[i])
    qc=clean(-s.expand(-2*K[1,0]+2*K[0,1]).coeff(q0*q1)/2);qn=clean(s.trace(K).subs(q1,0).expand().coeff(q0,2))
    # Six nonzero unordered triples of magnitude1? Derive actual support directly.
    # Four triples (0,2,4),(0,3,5),(1,2,5),(1,3,4), each six permutations.
    triples={(0,2,4):1,(0,3,5):1,(1,2,5):1,(1,3,4):-1}
    total=6*sum(v*v for v in triples.values());realunit=R(1,2)*total
    norm_by_edge=[2*sum(v*v for t,v in triples.items() if a in t) for a in range(6)];assert norm_by_edge==[4]*6
    ratio=clean(sum(norm_by_edge[:2])/realunit)
    print('STAGE literal_bubble_and_noncommuting_density_Hessian',flush=True);axes={}
    for i,v in enumerate(masses):
        # Independent decomposition: a(-D2)delta+b DD+c F, not KYM.
        CTa,CTb,CTc=-a,-b,-c;mass_ct=-n*(sum(masses)-v)/2
        pre=s.expand(ratio*(CTa*(10+eps-24/eps)+CTb/2-12*CTc/eps-(10+eps)*mass_ct/v)/eps)
        pp=[clean(pre.coeff(eps,k)) for k in [-2,-1,0]];h=[1,-s.log(v),(s.log(v)**2+s.zeta(2))/2]
        jet=[sum(pp[j]*h[k-j] for j in range(k+1)) for k in range(3)]
        axes[str(i)]={'prefactor':list(map(str,pp)),'forest_Laurent_Q1':list(map(str,map(clean,jet)))}
    full=full_table('replay',a,b,c,n,qc,qn)
    save('replay',{'schema':'V3U1_NATIVE','per_index':{k:str(v) for k,v in zip(['a','b','c','mass','quartic_c','quartic_mass'],[a,b,c,n,qc,qn])},
      'two_density_configurations':list(map(str,cs)),'literal_angular_mass_coefficient':str(n),'direct_real_cut_ratio':str(ratio),
      'axes':axes,'full45':full,'V3B_Laurent_fields_read':False,'UV_coefficients_fitted_to_bare_poles':False},start)
if __name__=='__main__':main()
