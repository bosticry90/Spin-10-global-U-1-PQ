# V3U1 — original cubic-vector UV operators and positive-mass proper forest

Question V3U1: does the actual V3S1 cubic Hessian supply a complete independent
kinetic, longitudinal, curvature and mass pole, and what does its original
proper-subgraph forest produce when added to V3B1? This is needed before VVV
matching and the model amplitude. It is not the full parent counterterm.

Freeze before calculation. Domain: same C1 parity-even covariantly constant
magnetic F2 coefficient, Euclidean xi=1 reference, real vector Gaussian,
positive squared masses x,y,z, polynomial H-intertwining cubic color carriers.
No full Lie closure of restricted carriers is assumed. No finite UV jets,
mass scheme, coupling or scale is adopted. Continue D=4-2eps on the remaining
loop; only the UV pole residue is evaluated in D0=4. Total-derivative density
terms remain inherited QDV boundary currents. This is not an off-shell QAP.

Primary: ordered free-word Laplace completion of the actual linear-in-Q
cubic Hessian, qualified QDV flat coefficients, Lorentz W2 mass trace;
complete real six-direction color triangle; KYM/DD/F/mass insertion closure.
Replay: literal flat momentum bubble, noncommuting constant density Hessian
with its Q2 term removed before heat completion, angular p=0 mass expansion,
separate kinetic/spin/longitudinal/mass closure. Compare every full45 matrix
and all12 H curvature operators against the qualified vector-only inputs.
Mass QUS conversion is60; curvature conversion is2. Never substitute total
vector+ghost+scalar coefficients for the vector class.

Compute native UV operators and forests before reading V3B Laurent fields.
Hashing authenticated files is not scientific reading of their coefficients
or file blinding. Validation then adds actual V3B arrays, records remaining
double/simple poles, tests locality and scale transport, retaining all finite
and eps-positive forest terms. No desired Rprime pole is an input or fitting
condition. A nonlocal remainder is a finding, not permission to change CTs.

Controls: use full vector curvature for cubic only; omit longitudinal term;
omit cubic curvature; early-D4 remaining-loop factors; half/double forest;
omit one mass placement; wrong QUS curvature conversion. Each must change
the relevant actual output; insensitive projections must be labelled.

Inputs frozen recursively with required receipts by prepare.py. Sequential
primary/replay/validation each600s, sampled private8GiB, launch350MiB,
package6MiB. Capture complete stdout/stderr, process samples and terminal
status. Incomplete/failed calculations have no qualification receipt.
Distinct routes share action, reference, heat a4 framework, QDV/QMV/SCU
premises, symbolic software and AI authorship. Agreement is computational
corroboration, not independent physics confirmation. No outside reviewer.

Possible outcomes: qualified bounded UV/forest construction; contradictory
action/normalization result; explicit underdefinition; resource inconclusive.
First mismatch stops the controller and preserves full evidence. Qualification
requires all native checks, negative controls, immutable inputs and full bytes;
director scientific acceptance NOT_PERFORMED. Authority remains34/39,
state113 unchanged; C1/E5/A5 unqualified. VVV not a completed amplitude yet.
Next: equal-heavy one-light matching, then actual supported mass/charge sum.
