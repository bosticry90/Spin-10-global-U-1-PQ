"""V3U1 exact native comparison, independently fixed forests plus V3B input."""
from data import *
def main():
    start=begin('validation_preparation.json');A,B=[packed(HERE/f'{r}_tables.json.gz') for r in ['primary','replay']]
    assert A['per_index']==B['per_index'] and A['full45']==B['full45']
    assert all(not v['V3B_Laurent_fields_read'] and not v['UV_coefficients_fitted_to_bare_poles'] for v in [A,B])
    for i in range(3):
        for field in ['prefactor','forest_Laurent_Q1']:
            assert all(clean(expr(a)-expr(b))==0 for a,b in zip(A['axes'][str(i)][field],B['axes'][str(i)][field]))
    coeff={k:s.sympify(v) for k,v in A['per_index'].items()};ratio=s.sympify(A['triangle']['ratio']);assert ratio==s.sympify(B['direct_real_cut_ratio'])
    # Only here are native forest and authenticated V3B Laurent fields combined.
    bare=packed(CAL/'canonical_so10_three_vector_bare_kernel/primary_v3_tables.json.gz')
    rows={};controls={};a,b,c,n=[coeff[k] for k in ['a','b','c','mass']]
    for i,v in enumerate(masses):
        bb=list(map(expr,bare['axes'][str(i)]['bare_Laurent_Q1']));ff=list(map(expr,A['axes'][str(i)]['forest_Laurent_Q1']))
        rr=list(map(clean,[u+w for u,w in zip(bb,ff)]));scale=[rr[0],clean(rr[1]+J*(2*bb[0]+ff[0])),clean(rr[2]+J*(2*bb[1]+ff[1])+J*J*(2*bb[0]+ff[0]/2))]
        formal=s.expand((1+2*eps*J+2*eps**2*J**2)*sum(bb[k]*eps**(k-2) for k in range(3))+(1+eps*J+eps**2*J**2/2)*sum(ff[k]*eps**(k-2) for k in range(3)))
        assert all(clean(formal.coeff(eps,k-2)-scale[k])==0 for k in range(3))
        poles_local=all(not (q.free_symbols & set(masses)) for q in rr[:2])
        rows[str(i)]={'bare_Q1':list(map(str,bb)),'forest_Q1':list(map(str,ff)),'Rprime_Q1':list(map(str,rr)),
          'Rprime_logQ2_arrays':list(map(str,scale)),'remaining_overall_poles_mass_independent':poles_local}
        # Sensitivity from independent CT operator changes, before multiplication by H.
        others=sum(masses)-v
        changes={'total_vector_curvature_substituted_for_cubic':ratio*12*coeff['quartic_c']/eps**2,
          'omitted_longitudinal_difference':-ratio*((-b)-(-a))/(2*eps),
          'omitted_cubic_curvature':-ratio*12*c/eps**2,
          'early_D4_remaining_loop':-expr(A['axes'][str(i)]['prefactor'][2]),
          'half_forest':-sum(expr(q)*eps**(j-2) for j,q in enumerate(A['axes'][str(i)]['prefactor']))/2,
          'doubled_forest':sum(expr(q)*eps**(j-2) for j,q in enumerate(A['axes'][str(i)]['prefactor'])),
          'only_one_mass_placement':ratio*(10+eps)*n*(masses[(i+1)%3]-others/2)/(v*eps)}
        assert all(clean(q)!=0 for q in changes.values())
        controls[str(i)]={k:str(clean(q)) for k,q in changes.items()}
    # Curvature has factor2, whereas the stored mass has factor60, not2.
    q=packed(CAL/'canonical_so10_vector_quartic_uv_subgraphs/primary_tables.json.gz')
    wrongcurv=mat(A['full45']['quartic_curvature'][1])-mat(q['Sigma_curvature_full_residues'][1]);assert wrongcurv.todok()
    wrongmass=mat(A['full45']['quartic_mass'])-2*mat(q['Sigma_mass_heavy_residue']);assert wrongmass.todok()
    native=[]
    for role in ['primary','replay']:
        cap=json.loads((HERE/f'{role}_capture.json').read_bytes());r=json.loads((HERE/f'{role}_result.json').read_bytes());blob=(HERE/f'{role}_tables.json.gz').read_bytes()
        assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
        assert sha256(blob).hexdigest()==r['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['tables_sha256']
        assert r['elapsed_after_imports']<600 and cap['launch']['memory']['available_pagefile']>=350*1024**2
        peak=max(v['private_bytes'] for v in cap['all_resource_samples']);assert peak<=8*1024**3
        native.append({'role':role,'seconds':r['elapsed_after_imports'],'sampled_private_max':peak})
    assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<6*1024**2
    out={'schema':'V3U1_VALIDATION','status':'QUALIFIED_ORIGINAL_CUBIC_VECTOR_UV_OPERATORS_AND_POSITIVE_MASS_PROPER_FOREST','execution_state':'COMPLETED',
      'per_index':A['per_index'],'raw_word_diagnostics':A['word_diagnostics'],'cut_ratio':str(ratio),
      'complete_positive_Rprime':rows,'negative_controls':controls,'mass_QUS_factor':60,'curvature_QUS_factor':2,
      'full45_and12_H_checked':True,'proper_forests_qualified':True,'soft_EFT_matching_qualified':False,'VVV_model_amplitude_calculated':False,
      'primitive_amplitude_inventory':6,'full_C1_or_E5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED',
      'shared_limits':['action and reference','QDV and QMV applicability','remaining-loop SCU/CCK heat identities','V3B absolute bare master','symbolic software','AI authorship'],
      'native_runs':native,'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
if __name__=='__main__':main()
