# V3B1: complete positive-mass bare VVV kernel

Qualified by validation_receipt.json, SHA256
d35634cd4e5fa0d1f6c2af5b0ea9dbbc8dd75ab2993072ba07b96ae6e55500dd.
Scientific acceptance NOT_PERFORMED;state113/authority34of39 unchanged.
The result supplies the absolute bare double-pole,single-pole and finite
functions for all three VVV charge axes and all strictly positive squared
masses, including coincidence. It does not supply the proper counterterms,
massless matching or complete model amplitude.

## Actual Laurent coefficients

With x,y,z the three ordered vector squared masses, at Q^2=1 the unit
coefficient on the x-charge axis is

    Ux_bare=12/eps^2+[-24log x-1-15(y+z)/x]/eps+Fx(x,y,z).

The other axes are its correctly permuted functions. Fx,Fy,Fz are explicit
finite combinations of the inherited absolute sunset derivatives and massive
tadpole terms, supplied in both native tables. They are not fitted unknowns
or values selected to make a Ward remainder vanish. The actual VVV assembly
normalization remains Lambda/g10^2=(1/2)sum_i W_i Ui.

All three DOUBLE poles are nonzero12. At the generic diagnostic masses
(x,y,z)=(1,2,3), the rounded arrays(double pole,single pole,finite) are:

| Charge axis | Double | Single | Finite |
| --- | ---: | ---: | ---: |
| x | 12 | -76 | 24.1525543613 |
| y | 12 | -47.6355323334 | 56.6335491971 |
| z | 12 | -42.3666949280 | 68.6941061363 |

At coincident masses(2,2,2), all three arrays agree and their finite value is
53.5269280470. These are normalization diagnostics, not selected physical
parameters. The formulas contain no inverse eigenvalue differences or mass-
discriminant denominators. Finite master derivatives mean derivatives of one
function; they are not treated as independent symbols for mass-permutation
comparisons between different representations.

## Exact reduction and checks

Each actual V3K heat coefficient was compiled using the qualified Gaussian
moment tool into an exact general-D momentum certificate. The55 candidate
basis has rank18 on18 target monomials. The three certificates retain14,14,12
terms respectively. D4 selects columns only; every new identity holds at
generalD before D=4-2eps is inserted. Absent edges yield actual TWO-tadpole
products; no scalar contact or logarithmic integral is declared zero.

Replay loads the JSON container holding the certificate and primary arrays;
the arrays were therefore physically available and decoded. Its arithmetic
uses only the certificate/P2 fields, not the primary Laurent fields. The
receipt's not-read flag describes that program-field dependency, not a
file-level information barrier. It reconstructs each heat coefficient from
the independent Gaussian generating
determinant, then reduces every resolvent jet separately. Primary instead
uses the inherited full-expression absolute-master differentiation/series
algorithm. All three complete Laurent arrays agree exactly, as do the early-
D4 and omitted-O(eps)-tadpole controls. This is a dependent mathematical
certificate checker and a different reduction algorithm, not a blind second
quantum derivation. Both routes share the V3K heat polynomial and absolute
scalar master convention.

The verifier also evaluates actual master derivatives at120digits on
(1,2,3),(2,1,3),(3,2,1),(2,2,2). The maximum scaled permutation/coincidence
error8.62199298395e-121 passes1e-55; imaginary leakage is0 at retained
precision. Exact certificate identities remain the main evidence; these
finite tests do not constitute rigorous uniform numerical error intervals.

The early-D4 mutation leaves the double pole unchanged but shifts each
single-pole coefficient by35/4. Omitting O(eps) factorized tadpoles changes
the finite functions; the complete actual changes are retained in the receipt.
Thus neither correct double poles nor a convenient equal-mass check can
justify discarding the dimensional or factorized finite terms.

For J=log(Q^2) the bare expression carries exp(2eps J). If its array is
(c2,c1,c0), its finite part is

    c0+2J*c1+2J^2*c2 = c0+2J*c1+24J^2.

The remaining-loop counterterms have a different scale factor. They have
not been calculated here, and a linear-log ansatz cannot be imposed on this
bare class. A nonzero class-local double pole is not an anomaly verdict.

## Preserved failed and inconclusive executions

The original frozen primary FAILED in the reused compiler while reducing
the early-D4 diagnostic: an expanded D-dependent denominator obscured its
proper-variable powers. No full table was saved; original replay/verifier
were UNEXECUTED. Its complete native capture and sources remain intact.

V2 added an algebraically valid whole-expression common-denominator adapter.
That method destroyed the sparse summand organization and reached the frozen
600-second limit, exit124, without a complete table. Its execution state is
FAILED and its scientific disposition is INCONCLUSIVE_RESOURCE_BOUNDARY,
not a mathematical failure or qualified result. The live process was followed
to its confirmed terminal state; it was not restarted on an observation
timeout. RESOURCE_INCONCLUSIVE_V2.json and its complete native capture are
preserved. No memory cap, runtime ceiling or physical assumption was increased.

V3 normalizes individual rational summands, proves each equality and uses
linearity. This preserves sparse structure and the ENTIRE original scientific
target. It does not truncate a polynomial, drop a charge axis, weaken a
control or shrink the accepted mass domain. The old compiler was never
edited. V3 completed all three axes under the same bounds.

| Completed worker | Seconds after imports | Max sampled private bytes |
| --- | ---: | ---: |
| Primary V3 | 27.9639623 | 58,564,608 |
| Resolvent replay V3 | 8.6273374 | 53,424,128 |
| Verifier V3 | 74.8733374 | Recorded in full capture |

Initial3,591,V2-phase3,607,V3-phase3,621 bindings were frozen. Commands:
prepare.py;run.py(failed);prepare_phase.py v2...;run_v2.py(resource-inconclusive);
prepare_phase.py v3...;run_v3.py. Bounds600s each,8GiB sampled private,
350MiB launch floor,6MiB package. No manual cancellation or native output
truncation. Sampling is not a continuous memory peak. Do not rerun any of
these exclusive completed/failed evidence paths.

TrackB records both an avoidable representation failure and an inefficient
global normalization, followed by a structural repair that reduces engineering
work while preserving all scientific obligations. These failures remain part
of the capability evidence. Shared action, heat numerator, compiler
certificate, absolute master, software and AI authorship limit independence.
No proof assistant, outside expert or experiment has confirmed the result.

The next calculation must construct the ORIGINAL cubic-vector UV kernels and
proper forest, preserving independent curvature and dimensional terms. No
counterterm is inferred from these new pole coefficients. Then single-light
full/EFT matching and the actual three heavy mass-orbit contraction remain.
The primitive amplitude inventory is still6/9, with VVV,SSSS,SSS incomplete.
Full C1/E5/A5 unqualified; authority34/39 and all physical/protected limitations
unchanged. No state edit, scheme/point/foundation adoption, publication or push.
