# V3B1: complete positive-mass BARE VVV Laurent kernel

Base0de34ced/main. V3K1 receiptb2f9c8b63350f586702d3b6e680ab9246f5fc2ca766661c490971c4d289a79a9
qualifies the actual ordered general-D heat numerator. Question: what are its
absolute double-pole,single-pole and finite positive-mass coefficients?
This is necessary before deriving the original VVV subtractions. Cheapest
competent method: reuse the qualified general-D CCK Gaussian compiler and
absolute master, then independently check its certificate with a Gaussian
generating determinant and independently reduce every resolvent power.

Types: same C1 xi1 local Euclidean F2 reference; strictly positive squared
masses x,y,z, including coincident masses; D=4-2eps. No massless limit or
counterterm is chosen. Keep all three charge axes. Charges obeyq1+q2+q3=0.
Use VVV prefactor Lambda/g10^2=(1/2)sum W_i U_i. Preserve all Laurent orders
eps^-2,eps^-1,eps^0, O(eps) factorized tadpoles and the epsilon-dependent
Lorentz weights. Do not constrain an unknown pole by desired cancellation.

Primary compiles each new P_i into Gaussian momentum moments. The CCK basis
is a qualified tool, not a substitute target polynomial. D4 may select basis
columns only; its resulting identity must hold at GENERAL D. Expand momentum
numerators into the absolute massive sunset plus actual tadpole products,
then continue at D=4-2eps. All stored coefficients and absent-edge contacts
are retained. Failure of the known basis to span this target is a scientific
or algorithmic result, not permission to drop monomials.

Replay may read the PRIMARY CERTIFICATE, but not its Laurent coefficients.
It reconstructs its heat numerator using derivatives of the independent
Gaussian generating determinant, then assembles the Laurent result term by
term from resolvent mass differentiation. This is a dependent proof-checker
and a distinct reduction algorithm; it is not advertised as a blind second
quantum derivation. Both routes share the authenticated scalar master and
the V3K physics. Compare exact certificates, all three Laurent arrays and
their dimensional/tadpole controls before qualifying the integral.

Separate verifier checks the general-D Gaussian identity, complete charge
permutation at heat level and bare scale jets. Finite master derivatives are
not treated as algebraically independent for comparing different permuted
mass representations. Instead evaluate absolute derivative functions at
120digits for (1,2,3),(2,1,3),(3,2,1),(2,2,2), checking actual finite/pole
permutation to1e-55 scaled, imaginary leakage1e-80. These are diagnostic
positive masses, not new physical benchmark choices. Record earlyD4 and
omitted O(eps) tadpole changes, including any insensitive projections.

The bare scale law uses exp(2eps*J): finite contribution c0+2J*c1+2J^2*c2.
Do not prematurely replace it by a linear log if a double pole survives.
Remaining-loop counterterms have their different scale factor and must be
derived separately. No forest is inferred from the bare result.

Freeze sources,input hashes,assumptions,limits before computation. Sequential
primary/replay, then separately frozen verifier;600s each,8GiB sampled private,
350MiB launch floor,6MiB package; exclusive full captures. Preserve failures/
incomplete runs. Qualified absolute positive BARE kernel,counterexample,
underdefinition or inconclusive are possible. No original proper forests,
IR/EFT matching, complete VVV amplitude, primitive7 or E5/A5 promotion.
Full goalACTIVE, authority34/39 unchanged, acceptance NOT_PERFORMED. No state
edit,scheme/point/foundation adoption,paused-matter/protected activation,
publication/push/outreach. Preserve26956 old Git blobs. Shared physics,
absolute master, software and AI authorship limit independence.
