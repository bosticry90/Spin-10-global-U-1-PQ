"""V3B1 exact absolute jets and actual master permutation checks."""
from data import *
def main():
    start=begin('validation_v3_preparation.json');A,B=[packed(HERE/f'{r}_tables.json.gz') for r in ['primary_v3','replay_v3']]
    assert B['primary_certificate_read'] and not B['primary_Laurent_coefficients_read']
    assert set(A['axes'])==set(B['axes'])=={'0','1','2'}
    for i in A['axes']:
        for field in ['bare_Laurent_Q1','early_D4_change','omit_Oeps_factorized_tadpoles_change']:
            assert all(clean(expr(a)-expr(b))==0 for a,b in zip(A['axes'][i][field],B['axes'][i][field])),(i,field)
        assert B['axes'][i]['Gaussian_certificate_residual']=='0'
        assert A['axes'][i]['basis']['general_D_identity'] and A['axes'][i]['basis']['rank_at_D4']==A['axes'][i]['basis']['monomial_count']
        # No inverse eigenvalue differences or mass-discriminant factors.
        for v in A['axes'][i]['bare_Laurent_Q1']:
            num,den=s.fraction(expr(v));poly=s.Poly(den,x,y,z);assert len(poly.terms())==1
    old,cck=compiler();master=cck.finite_master_coefficients();mp.mp.dps=120;funcs=[];alltokens=set()
    for i in range(3):
        jet=list(map(expr,A['axes'][str(i)]['bare_Laurent_Q1']));tok=sorted(set().union(*(f.free_symbols for f in jet))-set(masses),key=str)
        assert all(str(v).startswith('I') for v in tok);alltokens.update(tok);funcs.append((s.lambdify([*masses,*tok],jet,modules='mpmath',cse=True),tok))
    samples={};leak=mp.mpf(0)
    for point in [('1','2','3'),('2','1','3'),('3','2','1'),('2','2','2')]:
        args=list(map(mp.mpf,point));vals={}
        for token in alltokens:
            value=master.imaster_derivative(point,tuple(map(int,str(token)[1:])));leak=max(leak,abs(mp.im(value))/(1+abs(value)));vals[token]=mp.re(value)
        rows=[]
        for f,tokens0 in funcs:
            vv=f(*args,*[vals[t] for t in tokens0]);rows.append([mp.re(v) for v in vv]);leak=max(leak,max(abs(mp.im(v))/(1+abs(v)) for v in vv))
        samples['|'.join(point)]=rows
        print('STAGE actual_bare_master_'+','.join(point),flush=True)
    err=mp.mpf(0);base=samples['1|2|3']
    for name,order in [('2|1|3',[1,0,2]),('3|2|1',[2,1,0])]:
        for i,other in enumerate(order):
            for a,b in zip(base[i],samples[name][other]):err=max(err,abs(a-b)/(1+abs(b)))
    for i in [1,2]:
        for a,b in zip(samples['2|2|2'][0],samples['2|2|2'][i]):err=max(err,abs(a-b)/(1+abs(b)))
    assert err<mp.mpf('1e-55') and leak<mp.mpf('1e-80')
    controls={};scaled={};J=s.Symbol('J',real=True)
    for i in range(3):
        row=A['axes'][str(i)];c2,c1,c0=map(expr,row['bare_Laurent_Q1']);orig=c2/eps**2+c1/eps+c0
        jet=s.series((1+2*eps*J+2*eps**2*J**2)*orig,eps,0,1).removeO().expand()
        expected=[c2,c1+2*J*c2,c0+2*J*c1+2*J*J*c2]
        assert all(clean(jet.coeff(eps,k)-v)==0 for k,v in zip([-2,-1,0],expected));scaled[str(i)]=list(map(str,expected))
        controls[str(i)]={'early_D4_change':row['early_D4_change'],'omit_Oeps_factorized_tadpoles_change':row['omit_Oeps_factorized_tadpoles_change'],
          'missing_quadratic_scale_log':str(-2*J*J*c2),'tadpole_mutation_insensitive':all(expr(v)==0 for v in row['omit_Oeps_factorized_tadpoles_change'])}
    assert any(any(expr(v)!=0 for v in row['early_D4_change']) for row in A['axes'].values())
    native=[]
    for role in ['primary_v3','replay_v3']:
        c=json.loads((HERE/f'{role}_capture.json').read_bytes());r=json.loads((HERE/f'{role}_result.json').read_bytes());blob=(HERE/f'{role}_tables.json.gz').read_bytes()
        assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
        assert sha256(blob).hexdigest()==r['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['tables_sha256']
        peak=max(v['private_bytes'] for v in c['all_resource_samples']);assert peak<=8*1024**3 and c['launch']['memory']['available_pagefile']>=350*1024**2 and r['elapsed_after_imports']<600
        native.append({'role':role,'seconds':r['elapsed_after_imports'],'sampled_private_max':peak})
    assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<6*1024**2
    out={'schema':'V3B1_VALIDATION','status':'QUALIFIED_COMPLETE_POSITIVE_MASS_THREE_VECTOR_BARE_LAURENT_KERNEL','execution_state':'COMPLETED',
      'general_D_Gaussian_certificate_checks':3,'independent_resolvent_jet_checks':3,
      'basis_metadata':{i:row['basis'] for i,row in A['axes'].items()},'bare_double_poles':[A['axes'][str(i)]['bare_Laurent_Q1'][0] for i in range(3)],
      'bare_single_poles':[A['axes'][str(i)]['bare_Laurent_Q1'][1] for i in range(3)],'bare_scale_arrays':scaled,
      'absolute_master_permutation_error':mp.nstr(err,40),'absolute_master_imaginary_leak':mp.nstr(leak,40),
      'diagnostic_samples':{k:[[mp.nstr(v,80) for v in row] for row in values] for k,values in samples.items()},'controls':controls,'native_runs':native,
      'proper_forests_qualified':False,'soft_EFT_matching_qualified':False,'VVV_model_amplitude_calculated':False,'primitive_amplitude_inventory':6,
      'full_C1_or_E5_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED',
      'shared_limits':['action','V3K heat kernel','Gaussian compiler certificate','absolute scalar master','software','AI authorship'],
      'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
if __name__=='__main__':main()
