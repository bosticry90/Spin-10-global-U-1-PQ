# V3B1: exact Gaussian certificate and absolute master continuation

For the three squared-charge heat coefficients from V3K1, express
P_i(s,t,u,D) as a finite sum of proper-time monomials times Gaussian momentum
moments. With U=st+su+tu, the covariance variables are
A=(t+u)/U,B=(s+u)/U,C=-u/U. For p,k and q=p+k, the independent generating
determinant is

 Z(alpha,beta,gamma)=[1-A alpha-B beta-(A+B+2C)gamma
       +(AB-C^2)(alpha beta+alpha gamma+beta gamma)]^(-D/2).

Its derivatives generate the actual Gaussian expectations of polynomials
in p^2,k^2,q^2. The compiler's chosen moment basis must reproduce the complete
new P_i at generalD, not only D4. The certificate records every numerator,
proper power and dimensional coefficient. A factor s^a t^b u^c maps to
a!b!c! times the corresponding inverse-propagator powers.

Only after that exact identity put Pp=Pa-x,Kk=Pb-y,Qq=Pv-z. This is algebraic
numerator cancellation, not a deletion of an integral. An absent edge gives
the product of the other TWO massive tadpoles. No scaleless integral is set0.
The primitive scalar master in the inherited normalization is

 I_bare=-(x+y+z)/(2eps^2)
       +[sum_m m(log m-1)-(x+y+z)/2]/eps
       +I_fin(x,y,z)+sum_m m[-1-zeta2/2+log m-(log m)^2/2].

Mass derivatives give all positive resolvent powers. For a factorized edge
A_bare(m)=-m/eps+m(log m-1)
          +eps*m[-1-zeta2/2+log m-(log m)^2/2]+O(eps^2).
The last term can multiply another tadpole pole and change the finite part.
Dimensional coefficients are expanded through eps^2 before multiplying double
poles. The two algorithms differ in whether the full expression is expanded
after differentiation or individual Laurent/resolvent jets are convolved.

Both calculations use the SAME authenticated absolute master convention;
their agreement does not validate a different physical subtraction scheme.
The exact Gaussian identity and master differentiation justify the complete
bare functions, including their finite constants, by composition with those
qualified inputs. No finite constants are recovered from a desired Ward zero.

For a scale change J=log(Q^2), multiply the complete bare array by
exp(2eps J). If its coefficients are(c2,c1,c0), the new array is
(c2,c1+2J c2,c0+2J c1+2J^2 c2). Actual proper-counterterm traces carry only
the remaining-loop scale factor; they have not been calculated here. A
nonzero c2 is legitimate class-local evidence, not an anomaly verdict.

The formulas are valid for all strictly positive masses and retain coincident
limits. Master derivative tokens must be interpreted as derivatives of one
function; different representations are compared numerically or at the
Gaussian/certificate level, not by falsely declaring all tokens independent.
Full all-positive mass-role functions are a prerequisite, not the completed
model amplitude or an infrared subtraction theorem.
