# V3B1 proper-monomial adapter

The original frozen primary failed in the reused compiler while reducing the
early-D4 diagnostic. A D-dependent denominator had been expanded with proper
variables inside it, so as_powers_dict could not identify the propagator powers.
The complete native capture and original sources are preserved. No full table
was saved; the old replay/verifier were not launched. V2 adds an exact rational
proper-Laurent normal form, proving equality before passing it to the unchanged
old reducer. All physics, inputs, controls, precision and resource limits remain.
Distinct V2 sources/captures are required; no historical helper is edited.
