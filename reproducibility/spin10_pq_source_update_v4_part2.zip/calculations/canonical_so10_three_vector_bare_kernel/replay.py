"""V3B1 generating-determinant certificate and termwise resolvent jet proof."""
from data import *
def main():
    start=begin();tab=packed(HERE/'primary_tables.json.gz');U=st*tt+st*ut+tt*ut
    A,B,C=(tt+ut)/U,(st+ut)/U,-ut/U;aa,bb,cc=s.symbols('aa bb cc')
    determinant=1-A*aa-B*bb-(A+B+2*C)*cc+(A*B-C*C)*(aa*bb+aa*cc+bb*cc);MGF=determinant**(-D/2)
    def gaussian(N):
        value=0
        for powers,coef in s.Poly(N,Pp,Kk,Qq).terms():
            f=MGF
            for v,n in zip([aa,bb,cc],powers):f=s.diff(f,v,n)
            value+=coef*f.subs({aa:0,bb:0,cc:0})
        return clean(value)
    If=s.Function('I')(x,y,z);A0=lambda m:m*(s.log(m)-1);Ae=lambda m:m*(-1-s.zeta(2)/2+s.log(m)-s.log(m)**2/2)
    primitive=[-(x+y+z)/2,sum(A0(m) for m in masses)-(x+y+z)/2,If+sum(Ae(m) for m in masses)]
    def resolvent(ns):
        if 0 in ns:
            ts=[]
            for m,n in zip(masses,ns):
                if n:
                    fs=[-m,A0(m),Ae(m)];ts.append([(-1)**(n-1)*s.diff(f,m,n-1)/s.factorial(n-1) for f in fs])
            assert len(ts)==2
            return [ts[0][0]*ts[1][0],ts[0][0]*ts[1][1]+ts[0][1]*ts[1][0],ts[0][0]*ts[1][2]+ts[0][1]*ts[1][1]+ts[0][2]*ts[1][0]]
        orders=[n-1 for n in ns];result=[]
        for f in primitive:
            for m,n in zip(masses,orders):f=s.diff(f,m,n)
            result.append((-1)**sum(orders)*f/s.prod(s.factorial(n) for n in orders))
        return result
    out={}
    for axis,row in tab['axes'].items():
        reconstructed=0;target=expr(row['P2']);jet=[0,0,0];early=[0,0,0];noae=[0,0,0]
        for part in row['certificate']:
            ns=[int(v)+1 for v in part['proper_powers']];N=expr(part['momentum_numerator']);w=expr(part['weight'])
            reconstructed+=w*s.prod(v**n for v,n in zip(times,part['proper_powers']))*gaussian(N)
            fct=s.prod(s.factorial(n-1) for n in ns)
            num=s.Poly(s.expand(N.subs({Pp:Pa-x,Kk:Pb-y,Qq:Pv-z})),proper)
            for powers,coef in num.terms():
                rs=[n-p for n,p in zip(ns,powers)];assert min(rs)>=0 and rs.count(0)<=1
                values=resolvent(rs);weighted=coef*w*fct;coeff=[s.diff(weighted.subs(D,4-2*eps),eps,n).subs(eps,0)/s.factorial(n) for n in range(3)]
                for i in range(3):jet[i]+=sum(coeff[k]*values[i-k] for k in range(i+1))
                # Explicit mutations on the SAME certificate and resolvent jets.
                if 0 in rs:
                    indices=[(m,n) for m,n in zip(masses,rs) if n]
                    delta=0
                    for chosen in range(2):
                        m,n=indices[chosen];m2,n2=indices[1-chosen]
                        delta+=(-1)**(n+n2-2)*s.diff(Ae(m),m,n-1)*s.diff(-m2,m2,n2-1)/(s.factorial(n-1)*s.factorial(n2-1))
                    noae[2]-=coeff[0]*delta
        assert clean(reconstructed-target)==0
        # The mutation freezes the HEAT numerator at D4; its Gaussian basis
        # still has the proper general-D dimensional integral.
        wrong_heat=0
        for part in row['early_D4_certificate']:
            ns=[int(v)+1 for v in part['proper_powers']];N=expr(part['momentum_numerator']);w=expr(part['weight'])
            fct=s.prod(s.factorial(n-1) for n in ns)
            wrong_heat+=w*s.prod(v**n for v,n in zip(times,part['proper_powers']))*gaussian(N)
            for powers,coef in s.Poly(s.expand(N.subs({Pp:Pa-x,Kk:Pb-y,Qq:Pv-z})),proper).terms():
                rs=[n-p for n,p in zip(ns,powers)];values=resolvent(rs);weighted=coef*w*fct
                coeff=[s.diff(weighted.subs(D,4-2*eps),eps,n).subs(eps,0)/s.factorial(n) for n in range(3)]
                for i in range(3):early[i]+=sum(coeff[k]*values[i-k] for k in range(i+1))
        assert clean(wrong_heat-target.subs(D,4))==0
        jet=list(map(lambda v:clean(tokens(v)),jet));early=[clean(tokens(v)-base) for v,base in zip(early,jet)];noae=list(map(clean,noae))
        out[axis]={'Gaussian_certificate_residual':'0','bare_Laurent_Q1':list(map(str,jet)),
          'early_D4_change':list(map(str,early)),'omit_Oeps_factorized_tadpoles_change':list(map(str,noae))}
        print('STAGE independent_resolvent_axis_'+axis,flush=True)
    save('replay',{'schema':'V3B1_REPLAY','axes':out,'primary_Laurent_coefficients_read':False,'primary_certificate_read':True},start)
if __name__=='__main__':main()
