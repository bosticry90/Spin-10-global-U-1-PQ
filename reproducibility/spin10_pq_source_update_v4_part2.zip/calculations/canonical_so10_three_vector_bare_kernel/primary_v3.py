"""V3B1 complete new target compiled at general D then absolutely reduced."""
from data import *
def proper_laurent_normal_form(value):
    pieces=[]
    for original in s.Add.make_args(value):
        numerator,denominator=s.fraction(original)
        den=s.Poly(denominator,Pa,Pb,Pv);assert len(den.terms())==1
        denpowers,dencoef=den.terms()[0];terms=[]
        for powers,coef in s.Poly(numerator,Pa,Pb,Pv).terms():
            terms.append((coef/dencoef)*s.prod(P**(n-k) for P,n,k in zip(proper,powers,denpowers)))
        normalized=s.Add(*terms);assert clean(normalized-original)==0
        pieces.extend(terms)
    # Sum of separately proved identities; no whole-expression common denominator.
    return s.Add(*pieces)
def main():
    start=begin('v3_preparation.json');old,helper=compiler();input=packed(CAL/'canonical_so10_three_vector_heat_kernel/primary_tables.json.gz')['charge_axes'];out={}
    for axis,P in enumerate(map(expr,input)):
        integrand,certificate,basis=old.conversion(P);jet=old.reduce_master(proper_laurent_normal_form(integrand))
        early,unused,b0=old.conversion(P.subs(D,4));wrong=old.reduce_master(proper_laurent_normal_form(early));noae=old.reduce_master(proper_laurent_normal_form(integrand),True)
        out[str(axis)]={'P2':str(P),'certificate':certificate,'early_D4_certificate':unused,'basis':basis,'bare_Laurent_Q1':list(map(str,jet)),
          'early_D4_change':list(map(str,[clean(a-b) for a,b in zip(wrong,jet)])),
          'omit_Oeps_factorized_tadpoles_change':list(map(str,[clean(a-b) for a,b in zip(noae,jet)]))}
        print('STAGE absolute_bare_axis_'+str(axis),flush=True)
    save('primary_v3',{'schema':'V3B1_PRIMARY','axes':out,'positive_masses_only':True,'proper_forests_calculated':False},start)
if __name__=='__main__':main()
