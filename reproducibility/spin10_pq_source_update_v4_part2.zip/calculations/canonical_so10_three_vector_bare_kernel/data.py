"""V3B1 absolute master types, frozen dependencies and evidence IO."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json,gzip,sys,time,threading,os,importlib.util
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
st,tt,ut,D=s.symbols('s t u D',positive=True);times=[st,tt,ut];x,y,z,eps=s.symbols('x y z eps',positive=True);masses=[x,y,z]
Pp,Kk,Qq=s.symbols('Pp Kk Qq');Pa,Pb,Pv=s.symbols('Pa Pb Pv',positive=True);proper=[Pa,Pb,Pv]
LOC={str(v):v for v in times+[D,*masses,eps,Pp,Kk,Qq,*proper]}
def clean(v):return s.cancel(s.expand(v))
def expr(v):return s.sympify(v,locals=LOC)
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def load(n,p):
    spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def begin(prep='preparation.json'):
    start=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for p,h in json.loads((HERE/prep).read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
    return start
def save(role,v,start):
    raw=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/f'{role}_tables.json.gz').open('xb') as f:f.write(blob)
    print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':time.perf_counter()-start,'tables_sha256':sha256(raw).hexdigest(),
      'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)
def compiler():
    old=load('v3b_cck_data',CAL/'canonical_so10_charged_current_kernel/data.py');saved=sys.modules.get('data')
    try:
        sys.modules['data']=old;mod=load('v3b_cck_compiler',CAL/'canonical_so10_charged_current_kernel/primary.py')
    finally:
        if saved is None:sys.modules.pop('data',None)
        else:sys.modules['data']=saved
    return mod,old
def tokens(V):
    If=s.Function('I')(x,y,z);mapping={If:s.Symbol('I000')}
    for atom in V.atoms(s.Derivative):
        order=dict(atom.variable_count);mapping[atom]=s.Symbol('I'+''.join(str(order.get(v,0)) for v in masses))
    return V.xreplace(mapping)
