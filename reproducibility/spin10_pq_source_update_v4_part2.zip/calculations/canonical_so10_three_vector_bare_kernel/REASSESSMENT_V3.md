# V3B1 termwise normal-form continuation design

The V2 adapter combines the entire rational integrand before separating
proper-variable powers. This is algebraically valid but destroys the sparse
summand organization and creates large intermediate mass/proper polynomials.
The V3 design normalizes individual summands and proves each local equality,
then uses linearity. It changes neither the expression nor its scientific
acceptance domain. No runtime/memory ceiling is increased. V3 must remain
UNEXECUTED until the confirmed live V2 process reaches a terminal state and
its completed or resource-inconclusive evidence has been preserved.
