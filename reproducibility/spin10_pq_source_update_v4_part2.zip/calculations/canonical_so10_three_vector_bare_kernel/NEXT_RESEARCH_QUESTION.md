# Next: original cubic-vector UV kernel and proper forest

V3S1 supplies the actual cubic vertex/support; V3K1 now supplies the full
ordered general-D heat numerator, and V3B1 its complete positive-mass BARE
Laurent functions. Reuse them. Do not repeat the36-pair/finite-heat check,
the full color inventory, or the failed global rational normalization.

The immediate missing input is the class-specific cubic-vector self-energy
and its original two-loop forest. Compute it from the actual VVV Hessian,
using the fixed BFT gauge fixing and the real-vector Gaussian normalization.
Keep independent kinetic, longitudinal, curvature and mass operators. The
isolated cubic class need not already have a Yang--Mills-shaped combination;
an independent FQQ operator can produce double poles when closed.

Qualified QDV/QMV vector rows and QUS quartic residues can be reused, but
their types must be matched explicitly. QDV's data maps TWO TIMES QUS's
stored curvature residue into its canonical FQQ Hessian convention. This is
a declared curvature mapping, not permission to double every stored mass or
kernel coefficient. Match the full action/Hessian and Lorentz antisymmetry
before subtracting the quartic class. Do not subtract arrays merely because
their informal labels look the same. QMV's separate mass decomposition and
the original QUS closure carry their own normalizations.

Derive the missing curvature coefficient independently from the actual
linear-in-Q operator or a suitable action-based heat calculation, not from
flat Ward completion or the cancellation desired for V3B's poles. Reuse the
qualified flat derivative poles where their class is proved. Include all
internal mass roles and light paths. Compare the independently constructed
cubic plus quartic operators with the qualified total only after derivation.

Close the ORIGINAL proper forest, retaining its epsilon-positive factors,
double/single poles and finite pieces. A full real-vector self-energy counts
three identical edge embeddings: use it once in its real1/2 trace, or one
third on each listed label. Prove the universal mass/charge projection or
actual full-model operator closure instead of importing a ghost/current
forest. No product of overlapping sunset subgraphs is present.

Then compare bare+forest; a failure must be investigated, not fitted away.
Do not demand that an isolated class has zero double poles. Appropriate
quartic/parent partners may be required. Keep exp(2eps J) on bare graphs and
the remaining-loop scale factor on counterterms. Full Cfamily remains in
Cparent-Cfamily after eventual soft cancellation.

Only after this step establish the equal-heavy single-light kernel, actual
H all-light EFT subtraction and complete three-heavy-orbit model sum. Full
C1/E5/A5 remain unqualified. No new finite scheme, parameter choice, paused
matter or protected HB1/C5 activation is needed or authorized. Goal ACTIVE.
