# Next: a fixed-order source prescription and its two-loop matching transport

NVF supplies the actual complete one-loop K_Q*chi1*Abar class,its nonzero
massless form factor and the regulated quadratic-background first-width
identity. RLS/HRS supply actual regulator and antifield-source kernels.
Do not recalculate them or replace their nonlocal light pieces by a local
heavy expansion. Their common full/EFT light functions agree before limits.

The next useful question is whether the actual source-extended BFT action
admits the required complete one-loop pole subtraction and correlated
two-loop first variation under the ORIGINAL MSbar/forest prescription.
This is the bounded prerequisite for C1,not a demand for all-order E5.

Start before auxiliary elimination. Use the actual classical extended
Slavnov action with width and regulator doublets. Check the model-specific
premises of a fixed-loop dimensional Gaussian/Wick Ward construction:
nilpotence,invariant action,field measure,positive regulated reference,
common UV convergence domain and translational/covariant integration by
parts. Do not transfer the separate formal E5 action's authority here.

Derive the one-loop source pole functional from the ACTUAL extended Hessian,
or a mathematically complete equivalent operation,with sources and odd order
retained. Determine whether pole extraction commutes with the required
linearized source operation and preserves the prescribed D-dimensional
lifts. A symbolic operator definition may avoid an enormous expansion,
but its domain/locality and compatibility must be proved. Bare invariance
alone does not certify arbitrary finite normalization or an incomplete
source CT family. Compare to the measured NAP/HRS/RLS/NVF source classes
and the complete ordinary GCT/QDV/LRS kernels;do not fit missing residues.

Then differentiate the common full/EFT forest and heavy-EOM reduction with
all source,contact and propagator jets. SCO covers a specific one-soft
operation;the actual two-soft source ownership still needs justification.
Seek a complete bounded first-variation theorem or the exact missing class,
not more unrelated selected cancellations. Do not set the unknown two-loop
1PI derivative equal to the desired conditional FAN formula.

Keep all original C1 item7 checks and item8 refit,arbitrary-g evaluator,
MSbar/tadpole inputs and physical perturbativity tests. No target fitting,
physical promotion,paused flavor/HB1/C5 activation or publication. Authority
34/39 and custodyexit2/seven NOTPASS unchanged;goal active and incomplete.
