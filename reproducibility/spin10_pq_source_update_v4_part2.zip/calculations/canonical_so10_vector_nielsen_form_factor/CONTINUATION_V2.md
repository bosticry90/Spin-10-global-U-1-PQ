# NVF1 V2 typed symbolic parsing correction

The frozen primary stopped at its first parameter-reflection assertion.
Densities were serialized to strings and parsed without a locals binding.
The native parameter x has real=True,while sympify created a distinct
assumption-free x. Reflection of the native symbol did not act on the
parsed polynomial. Preserve original primary.py,its frozen source,full
capture and controller failure unchanged. No scientific table was written.

V2 supplies the original x explicitly when parsing the polynomial. This
changes symbol identity in the harness,not a vertex,coefficient,source sign,
physical parameter or required identity. Freeze new source/controller and
all failure evidence before execution. Same600s/8GiB sampled/350MiB launch/
24MiB package;no resource expansion. The original replay and verifier were
frozen but not launched;run them unchanged after the corrected primary.
Authentication precedes native read-guard installation;no physical target
or peer result is parsed for scientific calculation. All scientific scope
and acceptance obligations in RECORD and DERIVATION remain unchanged.
