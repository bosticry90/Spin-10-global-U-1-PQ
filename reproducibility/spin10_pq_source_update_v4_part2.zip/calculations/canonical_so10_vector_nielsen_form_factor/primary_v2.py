"""NVF1 actual f forms,source permutation and three ordered background terms."""
from data import *
# Authenticate V2 immutable bytes before installing the calculation guard.
for p,h in read(HERE/'preparation_v2.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
started=begin('primary')
clean=lambda z:s.expand(s.radsimp(s.expand(z)))
tidy=lambda X:X.applyfunc(clean)
bf=packed(CAL/'canonical_so10_background_threshold_inputs/primary_tables.json.gz')
V=dec(packed(CAL/'canonical_so10_vector_quartic_ir_matching/primary_tables.json.gz')['light_embedding'])
wh=packed(CAL/'canonical_so10_width_hard_projection/primary_tables.json.gz');projectors=list(map(dec,wh['projectors']))
ad=[s.SparseMatrix(45,45,{}) for _ in range(12)]
for a,b,c,z in bf['f']:
    for h in range(12):
        if V[a,h]:ad[h][c,b]+=V[a,h]*s.sympify(z)
ad=list(map(tidy,ad));charges=[]
for P in projectors:
    for T in ad:assert tidy(P*T-T*P)==s.zeros(45)
    charges.append(tidy(s.SparseMatrix(12,12,{(a,b):-s.trace(P*ad[a]*ad[b]) for a in range(12) for b in range(12)})))
# Original word K,c,chi,barc -> K,chi,c,barc. Distinct-vertex cumulant -1.
word=[0,2,1,3];sortsign=(-1)**sum(word[i]>word[j] for i in range(4) for j in range(i+1,4))
cross=(-1)*(-s.Rational(1,2))*sortsign
operator_prefactor=-cross # endpoint derivative integration by parts
color_operator_prefactor=-operator_prefactor # f_bc*(ad_h)^bc=-B_ah
x=s.symbols('x',real=True);P2,M=s.symbols('s M',positive=True);P=s.symbols('P',real=True)
k=s.symbols('k0:3',real=True);l=s.symbols('l0:3',real=True);mom=[P,0,0]
densities={}
for polarization in [0,1]:
    avec=[int(i==polarization) for i in range(3)];mu=polarization
    orbital=sum((2*k[i]+mom[i])*avec[i] for i in range(3))
    vector=sum((orbital*int(mu==nu)+2*(mom[mu]*avec[nu]-mom[nu]*avec[mu]))*k[nu] for nu in range(3))
    # Reflection maps ghost insertion into the same a*b^2 denominator.
    ghost=k[mu]*orbital
    pieces={}
    for name,num in [('vector',-vector),('ghost',-ghost)]:
        shifted=s.expand(num.subs({k[i]:l[i]-x*mom[i] for i in range(3)}))
        squares=sum(shifted.coeff(z,2) for z in l)
        constant=shifted.subs(dict.fromkeys(l,0))
        remainder=s.expand(shifted-sum(shifted.coeff(z,2)*z**2 for z in l)-constant)
        assert s.Poly(remainder,*l).total_degree()<=2
        assert all(any(power%2 for power in monomial) for monomial,coef in s.Poly(remainder,*l).terms() if coef!=0)
        pieces[name]={'J2':str(s.factor(2*(1-x)*squares/4)),
                      'sJ3':str(s.factor(2*(1-x)*constant/P**2))}
    pieces['contact']={'J2':'1','sJ3':'0'}
    densities['parallel' if polarization==0 else 'transverse']=pieces
def total(pol,key):return s.expand(sum(s.sympify(z[key],locals={'x':x}) for z in densities[pol].values()))
sym=lambda z:s.factor((z+z.subs(x,1-x))/2)
residue=s.integrate(total('transverse','J2'),(x,0,1))
assert sym(total('parallel','J2'))==sym(total('parallel','sJ3'))==sym(total('transverse','J2'))==0
trans=sym(total('transverse','sJ3'));factor=s.cancel(color_operator_prefactor*trans/(x*(1-x)))
assert not factor.has(x)
eps=s.symbols('eps',positive=True)
finiteJ3=s.limit(s.exp(s.EulerGamma*eps)*s.gamma(1+eps)/2,eps,0)
finite_prefactor=s.simplify(factor*finiteJ3)
# Free noncommuting differential-operator identity,not fitted to the source.
d=s.symbols('d0:3',commutative=False);mass=s.symbols('mass',commutative=True)
comm=lambda a,b:a*b-b*a;minusD2=-sum(z*z for z in d)
F=[[comm(a,b) for b in d] for a in d]
J=[sum(comm(d[n],F[n][m]) for n in range(3)) for m in range(3)]
ward=[]
for m in range(3):
    raw=sum(((minusD2+mass if m==n else 0)-2*F[m][n])*d[n] for n in range(3))-d[m]*(minusD2+mass)+J[m]
    ward.append(s.expand(raw));assert ward[-1]==0
fclosed=(1-4*M/s.sqrt(P2*(4*M+P2))*s.atanh(s.sqrt(P2/(4*M+P2))))/P2
finish('primary',{'method':'actual_f_source_permutation_three_background_vertices_free_operator_identity',
    'charges':list(map(enc,charges)),'mass_eigenvalues':['0','3/10','3/2','25','253/10'],
    'source_cross_prefactor':str(cross),'color_operator_prefactor':str(color_operator_prefactor),
    'background_densities':densities,'f_D_J3_coefficient':str(factor),'finite_prefactor':str(finite_prefactor),
    'UV_pole':str(residue),'finite_form_factor':str(fclosed),'M_times_f_at_zero':str(finite_prefactor*s.integrate(x*(1-x),(x,0,1))),
    'massless_s_times_f':'1','operator_Ward_zero_components':len(ward),
    'finite_charge_tensors':list(map(lambda B:enc(finite_prefactor*B),charges)),
    'complete_KQ_chi1_Abar_class':True,'one_loop_background_first_width_identity':True,
    'two_loop_width_identity_qualified':False,'finite_C1_calculated':False},started)
