# NVF1: source diagrams before the identity test

## Actual source action and completeness

The BFT/RNC auxiliary Gaussian,performed after width/source differentiation,
gives at x1=x2=1

 S_K=g K_mu^a f_bc^a Q_mu^b c^c,
 S_chi=-chi1*barc^d Dbar_nu Q_nu^d/2.

Order external odd sources K,chi and use LEFT derivatives. Gamma's cross
coefficient is -<S_K S_chi>. Moving chi past the internal c gives a minus;
with the explicit -1/2 vertex the coefficient is -1/2 times the ordered
vector/ghost contraction. Integrating the endpoint derivative by parts
gives the operator expression

 C_mu^a=Gamma_[K_mu^a chi1]
       =g f_bc^a (Gv_munu Dbar_nu Gc)^{bc}(x,x)/2.       (1)

This sign convention agrees with C=partial_chi(delta_left Gamma/delta K),
not an unlabelled switch between chi*K and K*chi coefficients. There is
no extra closed-ghost-loop sign in this open source contraction.

Linear K.Dbar c shifts the ordinary Legendre source and has no 1PI loop
correction by itself. Other source attachments with one quantum edge are
1PR. K_Q has no scalar vertex. Extra quantum cubic/quartic vertices with
these two source vertices raise the loop order. At widths1 the Q/eta/ghost
Hessian is block diagonal for arbitrary H-valued background (Dbar v=0);
no scalar/vector propagator is silently neglected. The first background
variation of(1) therefore has exactly THREE terms:chi's Dbar contact,
ghost inverse insertion and vector inverse insertion. The latter includes
its spin term. This is complete for K_Q*chi1*Abar,not other source classes.

H mass projectors commute with every actual H adjoint,so both source edges
and every background insertion preserve the mass sector. Use all five
sectors r0..r4 and B_r,ab=-Tr(P_r ad_a ad_b),not a charge average.
M_0=delta;M_r=g^2 lambda_r for the four positive sectors.

## Direct background vertices and ordered integrals

In one sector,write Kc=-Dbar^2+M and
Kv_munu=Kc delta_munu-2 Omega_munu,Omega=g ad(Fbar).
For a Fourier background A_nu(p),strip g ad(A)'s color and use

 Vc(k+p,k)=-i(2k+p).A,
 Vv_munu=-i[(2k+p).A delta_munu+2(p_mu A_nu-p_nu A_mu)].

Let a=[(k+p)^2+M]^-1,b=[k^2+M]^-1. Direct differentiation of the ordered
product Gv Dbar Gc gives

 a*b*A_mu
 -a*b^2*[k_mu(2k+p).A+2p_mu(k.A)-2(k.p)A_mu]
 -a^2*b*(k+p)_mu(2k+p).A.                              (2)

The last term is the ghost insertion. Reflection k->-k-p maps its orbital
numerator to the vector orbital term,without interchanging matrix order.
Thus the full tensor in(2) is

 delta_munu*int a*b
 -int a*b^2*[4k_mu k_nu+2k_mu p_nu+2p_mu k_nu
                                      -2(k.p)delta_munu]. (3)

Feynman parameterization a*b^2=2 int_0^1(1-x)/(l^2+A)^3 dx,
l=k+xp,A=M+x(1-x)s,s=p^2. Exact dimensional integration gives
int l_mu l_nu/(l^2+A)^3=delta_munu J2(A)/4,not an early-D4 approximation.
All J2 terms are int(2x-1)J2(A)dx=0. Symmetrization x<->1-x of the
remaining coefficients yields

 F_munu=4 int_0^1 x(1-x)J3(A)dx*(p_mu p_nu-s delta_munu).

In(1),f_bc^a(ad_h)^{bc}=-B_r,ah. The prospective measured source is

 C_mu^a(p)=ell*g^2 sum_r B_r,ah*f_D(s,M_r)
                   *(s delta_munu-p_mu p_nu)*A_nu^h(p),
 f_D(s,M)=2 int_0^1 x(1-x)J3(M+x(1-x)s)dx.             (4)

The contact and orbital poles must cancel before testing this form. Spin
is essential;dropping it can leave a superficially covariant but zero wrong
answer. Keeping only one background placement is not the source kernel.
No identity requiring cancellation was used to set the coefficients in(2).

Independent resolvent route: Gv=Gc I+2 Gc Omega Gc+O(A^2). At first order
the orbital Gc Dbar Gc contribution is a loop-momentum total derivative;
its contact and both inverse insertions cancel. The remaining spin term
uses int k_mu*a*b^2=-2p_mu int x(1-x)J3(A)dx,again giving(4). This is an
ordinary dimensional integration identity,not discarding a singular whole
massless integral. Positive masses ensure the common convergence domain.

## Finite form factor,UV normalization and infrared limit

Jn(M)=exp(gammaE eps)Gamma(n-D/2)(Q^2)^eps M^(D/2-n)/Gamma(n),
D=4-2eps. The form factor is UV finite,and

 f_D(s,M)=-partial_s B0_D(s,M),
 f(s,M)=int_0^1 x(1-x)/[M+x(1-x)s]dx,
 f(s,M)=1/s*[1-4M/sqrt(s(4M+s))
                         *atanh(sqrt(s/(4M+s)))], s>0,
 f(0,M)=1/(6M).

B0_D is the actual RLS equal-mass bubble;the derivative removes its UV
pole,not an arbitrary finite normalization. All formulae are first defined
for M>0 in dimensional convergence domains and continued meromorphically.

At fixed s>0,dominated convergence gives lim_(M->0) f(s,M)=1/s. Thus the
light response tends to ell*g^2*B_0*(delta_munu-p_mu p_nu/s)A_nu. It is
finite,nonzero and nonlocal. A local expansion f~1/(6delta) is not uniform
as delta->0. Positive-heavy terms start with a covariant dimension-six
EOM structure in the local expansion;the massless source cannot be
discarded by that heavy-sector dimension argument. Full and EFT light
actions,vertices and B_0 agree by LGF/RLS,so their identical nonzero kernel
is common BEFORE source extraction or infrared removal. This is not an
extra hard threshold term to add to FAN's fixed-width coefficient.

There is no UV counterterm for THIS affine-background-forbidden K_Q*chi*A
projection. This does not make all K_Q*chi*Q or other source CTs zero.

## Independently test the one-loop first-width background identity

Keep b until the source equations are defined. At widths1 the actual
first-width determinant variations are
 vector: +(1/2)Tr[Gv Dbar_mu Dbar_nu],
 heavy ghost mass: -(M/2)Tr Gc,
 scalar: zero (x2 held fixed);off-diagonal Q/eta derivative: zero first trace.
For the light block the ghost regulator is width independent;instead
RNC supplies the ACTUAL mixed regulator contact delta*Gamma_[u chi]
=-(delta/2)Tr Gc. Thus the mass partner is independently present in every
sector:heavy FP derivative or light regulator contact. It is not chosen
to make an equation hold. The full nonlocal contact is retained here,
not only RNC's earlier local F^2 value.

Let Dcol have blocks D_mu,Drow blocks D_mu,F_munu=[D_mu,D_nu],
J_mu=sum_nu[D_nu,F_numu],Jcol/Jrow analogous. Actual operators satisfy

 Kv Dcol=Dcol Kc-Jcol.

This is proved by expanding the noncommuting derivatives and spin term.
It implies the direct width-plus-partner trace

 T_W=(1/2)Tr(Gv Dcol Drow)-(M/2)Tr Gc
    =-(1/2)Tr I+(1/2)Tr(Drow Gv Jcol Gc).

The actual source in(1),contracted with the tree YM field equation,is
 T_C=-(1/2)Tr(Jrow Gv Dcol Gc).
Transpose symmetry of Gv,Gc and antisymmetry of D_mu,J_mu show the last
traces equal. Therefore T_W+T_C=-Tr I/2. The identity contact has no
background derivative in the declared prescription. This proves the
quadratic-background first-width Nielsen identity in this one-loop domain,
with the actual light regulator source included. Test with independent
noncommuting finite matrix operators and spin/mass/source-sign controls.
Cyclicity is used only in the positive-mass dimensional convergence domain
of background-subtracted traces,then continued;not postulated for arbitrary
undefined regulated products. No all-order measure or QAP theorem follows.

At the background-quadratic level,this source contributes
ell*g^2 sum B_r*s^2*f(s,M_r)*A_transverse^2. Its opposite is the finite
width-plus-partner variation. At fixed delta the local F^2 part of the
source vanishes;after the fixed-s light limit a nonzero term remains.
This explains why the earlier local RNC cancellation could not settle the
complete massless nonlocal source problem. Two-loop matching still needs
the common hard/source/two-soft transport and appropriate finite source CTs.

Primary comparators: Lewandowski,1307.4055v1,sections2--4,
https://arxiv.org/pdf/1307.4055v1;Breckenridge--Lavelle--Steele,hep-th/9407028,
sections2--3,https://arxiv.org/pdf/hep-th/9407028. Their extended-source
methods guide the calculation;their Lorentz gauges/results do not provide
our BFT background kernel or certify two-loop matching. Shared-error limits
and all authority ceilings in RECORD remain;no numerical C1 is evaluated.
