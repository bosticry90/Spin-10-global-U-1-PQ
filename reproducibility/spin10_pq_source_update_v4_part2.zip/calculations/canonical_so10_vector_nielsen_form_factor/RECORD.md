# NVF1: actual vector Nielsen form factor and regulated one-loop identity

Prospective at f1c9cffd056db33e80e81945d5c0f1dd0ce3f911/main,2026-10-21.
Previous goal turn PROGRESS via RLS1. Clean main,no matching workers.
Question: what is the actual one-loop K_Q*chi1 response to a varying H
background,and does its complete quadratic-background first-width identity
include compatible ghost-mass/regulator partners before the infrared limit?
This is needed by C1's finite width/matching gate. Do not infer the source
form factor or a two-loop variation from a desired Nielsen cancellation.

Freeze this record,DERIVATION and six sources before scientific execution.
Actual BFT action,RNC doublet and MSbar/DR prescription unchanged. Widths1,
constant chi1 and u,external sources differentiated LEFT before source zero.
External K_Q and one background Abar have all12 normalized real H colors.
Keep all45 internal colors/five mass sectors,proving the neutral zero.
Positive masses M_r=g^2 lambda_r,light mass delta>0;M denotes mass squared.
Euclidean p^2>=0,Schwartz backgrounds,ell=1/(16pi^2),D=4-2eps.

Primary: actual structure constants/projectors;ordered source permutation;
literal vector/ghost background vertices and chi contact;Feynman shift and
general-D angular moments;free noncommuting operator proof. Replay: WHP
Hermitian charge transport;independent Berezin Gaussian;scalar-resolvent
plus spin-insertion calculation;mass/bubble derivative and finite covariant
matrix identity. Separate verifier imports neither native calculation,
uses literal16-dimensional exterior matrices,different noncommuting matrices,
convergent/meromorphic Gamma integrals and exact tensor/zero checks.

Acceptance: complete three-term source class,actual signs/finite function,
all720 sector charge positions and their coefficient tensors,UV complement,
transversality and covariant type. Test the one-loop first-width identity
with the ACTUAL positive-heavy ghost mass derivative and light u*chi contact,
not an unknown partner chosen for cancellation. Retain finite local and
nonlocal limits;prove the common full/EFT light response before limits.
Controls: missing chi contact,ghost insertion,vector spin,source-order sign,
mass partner/regulator contact,and premature light local expansion. Preserve
the U1/neutral-sector insensitivity. No finite source normalization is fitted.

Resources: sequential600s workers after imports,8GiB sampled private memory,
350MiB launch floor,24MiB package. Explicit ancestry/source byte freeze;
complete observed captures before checks;separate verifier;readiness e4 and
raw/index/HEAD seal before local commit. Preserve every failed/unfinished run.
Reuse qualified data without expensive primitive replay. No agents,branch,
reset,push,outreach,publication,paused flavor or HB1/C5 activation.

Ceiling: this actual source form factor and the one-loop first-width
quadratic-background identity in the declared domain,not arbitrary widths,
all mixed source counterterms,two-loop width independence or numerical C1.
State113/34of39,custodyexit2/seven NOTPASS and all physical warnings remain.
Root saw the historical comparison target previously;no blind-author claim,
worker target use or fitting. Shared action,group/projectors,DR/regions,
Python/SymPy and AI author limit independence. No external confirmation.
