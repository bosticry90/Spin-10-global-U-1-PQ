"""NVF1 V2 observed corrected primary,unchanged replay and unchanged verifier."""
from pathlib import Path
from hashlib import sha256
import gzip,json,sys,traceback
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/vector-nielsen-form-factor-v1-2026-10-21')
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
def dump(p,z):
    with p.open('xb') as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
prep=json.loads((HERE/'preparation_v2.json').read_bytes())
for p,h in prep['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
roles=[('primary','primary_v2.py','primary_capture_v2.json','primary_full_capture_v2.json'),
       ('replay','replay.py','replay_capture.json','replay_full_capture.json'),
       ('validation','verify.py','validation_capture.json','validation_full_capture.json')]
for n in ['primary_tables.json.gz','primary_result.json','replay_tables.json.gz','replay_result.json',
          'validation_preparation.json','validation_receipt.json','controller_failure_v2.json']+[r[2] for r in roles]:assert not (HERE/n).exists(),n
role=None
try:
    for role,worker,local,external in roles:
        if role=='validation':
            deps=dict(prep['input_sha256'])
            for p in HERE.iterdir():
                if p.is_file():deps[str(p)]=sha256(p.read_bytes()).hexdigest()
            dump(HERE/'validation_preparation.json',{'schema':'NVF1_VALIDATION_PREPARATION','input_sha256':deps,'seconds':600,'scientific_acceptance':'NOT_PERFORMED'})
        cap=capture([sys.executable,'-B',str(HERE/worker)])
        dump(HERE/local,cap);dump(CONTROL/external,cap)
        if cap['exit_code']!=0:print(cap['stdout_and_stderr'],flush=True)
        assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
        assert cap['launch']['memory']['available_pagefile']>=350*1024**2
        assert cap['all_resource_samples'] and all(x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples'])
        results=[json.loads(x[7:]) for x in cap['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')]
        assert len(results)==1;out=results[0];assert out['elapsed_after_imports']<600
        if role=='validation':
            assert out['status']=='QUALIFIED_VECTOR_NIELSEN_FORM_FACTOR_AND_REGULATED_ONE_LOOP_BACKGROUND_IDENTITY'
            dump(HERE/'validation_receipt.json',out)
        else:
            blob=(HERE/(role+'_tables.json.gz')).read_bytes()
            assert sha256(blob).hexdigest()==out['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==out['tables_sha256']
            dump(HERE/(role+'_result.json'),out)
        assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<24*1024**2
        print(role,'COMPLETED',out['elapsed_after_imports'],flush=True)
except BaseException:
    dump(HERE/'controller_failure_v2.json',{'execution_state':'FAILED','last_role':role,'traceback':traceback.format_exc(),
        'scientific_acceptance':'NOT_PERFORMED','failure_relabelled_PASS':False});raise
