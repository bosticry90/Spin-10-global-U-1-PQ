"""NVF1 independent Berezin,resolvent-spin,bubble derivative and covariant matrices."""
from data import *
started=begin('replay')
clean=lambda z:s.expand(s.radsimp(s.expand(z)))
tidy=lambda X:X.applyfunc(clean)
phy=read(PACKET/'full_replay.json');old=dec(phy['C3_plane_to_parent'])[:,:12]
V=dec(packed(CAL/'canonical_so10_vector_quartic_ir_matching/replay_tables.json.gz')['light_embedding'])
Z=tidy((old.H*old).inv()*old.H*V);assert tidy(old*Z-V)==s.zeros(45,12)
wh=packed(CAL/'canonical_so10_width_hard_projection/replay_tables.json.gz')
charges=[tidy(Z.H*dec(Q)*Z) for Q in wh['H_charge_pairings']]
def add(A,B):
    out=dict(A)
    for key,z in B.items():out[key]=s.expand(out.get(key,0)+z)
    return {k:v for k,v in out.items() if v!=0}
def scale(A,z):return {k:s.expand(z*v) for k,v in A.items() if z*v!=0}
def mul(A,B):
    out={}
    for a,y in A.items():
        for b,z in B.items():
            if a&b:continue
            sign=(-1)**sum(i>j for i in range(4) if a&(1<<i) for j in range(4) if b&(1<<j))
            out[a|b]=s.expand(out.get(a|b,0)+sign*y*z)
    return {k:v for k,v in out.items() if v!=0}
K,chi,c,bc=[{1<<j:s.S.One} for j in range(4)];q=s.symbols('q',real=True)
body=add({0:1},scale(mul(bc,c),-1));normal=body[12]
S=add(scale(mul(K,c),q),scale(mul(chi,bc),-q/2))
term=dict(body);value=dict(body)
for n in range(1,3):term=scale(mul(S,term),-s.Rational(1,n));value=add(value,term)
integral={mask&3:s.expand(z/normal).subs(q**2,1).subs(q,0) for mask,z in value.items() if mask&12==12}
assert integral[0]==1 and not integral.get(1,0) and not integral.get(2,0)
cross=-integral.get(3,0);color_operator_prefactor=cross # IBP and color each -1
# Orbital cancellation is the total derivative d_(k_mu)[k_mu*a*b].
# Only 2Gc Omega Gc D Gc remains. Parameter first moment is
# int k_mu*a*b^2=-2p_mu int x(1-x)J3;spin supplies -2.
x=s.symbols('x',real=True);M,P2=s.symbols('M s',positive=True)
spin_insertion=2;first_moment=-2*x*(1-x)
transverse_density=s.factor(spin_insertion*first_moment)
factor=s.cancel(color_operator_prefactor*transverse_density/(x*(1-x)))
eps=s.symbols('eps',positive=True)
# -partial_s B0_D:eps*Gamma(eps)=Gamma(1+eps);J3 has Gamma/2.
ratio=s.simplify(eps*s.gamma(eps)/(s.gamma(1+eps)/2));assert ratio==factor
finite_prefactor=s.limit(factor*s.gamma(1+eps)/2,eps,0)
b=-2+2*s.sqrt((4*M+P2)/P2)*s.atanh(s.sqrt(P2/(4*M+P2)))
fclosed=s.simplify(s.diff(b,P2))
# Independent finite covariant operators,nonzero curvature and Yang-Mills EOM.
T1=s.Matrix([[0,1,0],[-1,0,0],[0,0,0]]);T2=s.Matrix([[0,0,0],[0,0,1],[0,-1,0]])
d=[T1,2*T2,T1+T2/3];N=3;mass=s.Rational(20)
comm=lambda a,b:a*b-b*a
Kc=-sum((a*a for a in d),s.zeros(N))+mass*s.eye(N)
F=[[comm(a,b) for b in d] for a in d]
J=[sum((comm(d[n],F[n][m]) for n in range(3)),s.zeros(N)) for m in range(3)]
Kv=s.BlockMatrix([[(Kc if m==n else s.zeros(N))-2*F[m][n] for n in range(3)] for m in range(3)]).as_explicit()
Dc=s.Matrix.vstack(*d);Dr=s.Matrix.hstack(*d);Jc=s.Matrix.vstack(*J);Jr=s.Matrix.hstack(*J)
assert Kv*Dc-Dc*Kc+Jc==s.zeros(9,3) and Kv==Kv.T and Kc==Kc.T
Gv=Kv.inv();Gc=Kc.inv()
TW=s.trace(Gv*Dc*Dr)/2-mass*s.trace(Gc)/2
TC=-s.trace(Jr*Gv*Dc*Gc)/2
assert s.simplify(TW+TC+N/2)==0 and TC!=0
finish('replay',{'method':'Hermitian_charge_transport_Berezin_resolvent_spin_bubble_derivative_covariant_matrices',
    'charges':list(map(enc,charges)),'mass_eigenvalues':['0','3/10','3/2','25','253/10'],
    'source_cross_prefactor':str(cross),'color_operator_prefactor':str(color_operator_prefactor),
    'f_D_J3_coefficient':str(factor),'finite_prefactor':str(finite_prefactor),'UV_pole':'0',
    'finite_form_factor':str(fclosed),'M_times_f_at_zero':str(finite_prefactor*s.integrate(x*(1-x),(x,0,1))),
    'massless_s_times_f':'1','finite_charge_tensors':list(map(lambda B:enc(finite_prefactor*B),charges)),
    'covariant_matrix':{'color_size':N,'Lorentz_size':3,'mass_squared':str(mass),'width_plus_mass_partner':str(TW),
                       'tree_EOM_source':str(TC),'identity_contact':str(s.Rational(N,2)),'residual':'0'},
    'complete_KQ_chi1_Abar_class':True,'one_loop_background_first_width_identity':True,
    'two_loop_width_identity_qualified':False,'finite_C1_calculated':False},started)
