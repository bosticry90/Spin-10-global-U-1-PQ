"""NVF1 V2 freeze preserves the exact failed primary and unchanged future workers."""
from pathlib import Path
from hashlib import sha256
import ast,json
HERE=Path(__file__).resolve().parent
prep=json.loads((HERE/'preparation.json').read_bytes());deps=dict(prep['input_sha256'])
for p,h in deps.items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
for n in ['CONTINUATION_V2.md','primary_v2.py','prepare_v2.py','run_v2.py']:
    p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
    if p.suffix=='.py':ast.parse(raw)
    with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
for p in HERE.iterdir():
    if p.is_file():deps[str(p)]=sha256(p.read_bytes()).hexdigest()
cap=json.loads((HERE/'primary_capture.json').read_bytes());assert cap['exit_code']!=0
assert 'AssertionError' in cap['stdout_and_stderr'] and not (HERE/'primary_tables.json.gz').exists()
with (HERE/'preparation_v2.json').open('xb') as f:f.write((json.dumps({'schema':'NVF1_PREPARATION_V2',
    'input_sha256':deps,'scientific_acceptance':'NOT_PERFORMED','failed_primary_preserved':True,
    'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,
    'whole_package_bytes':24*1024**2},sort_keys=True,indent=2)+'\n').encode())
print('NVF1_V2_FROZEN',len(deps),'bindings; unchanged mathematical contract',flush=True)
