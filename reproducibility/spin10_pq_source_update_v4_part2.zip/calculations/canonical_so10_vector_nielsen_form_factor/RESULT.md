# NVF1: the light-vector Nielsen response is finite,nonzero and nonlocal

The complete one-loop K_Q*chi1*Abar source class has been calculated in
the actual BFT/RNC construction. Its finite form factor and the associated
regulated quadratic-background first-width identity are qualified within
the frozen Euclidean,widths1 domain. This is a one-loop result,not the
required two-loop matched width theorem or a physical C1 prediction.

For all12 normalized real H colors,the result is

    C_mu^a(p)=ell*g10^2*sum_r B_r,ah*f(p^2,M_r)
                    *(p^2 delta_munu-p_mu p_nu)*Abar_nu^h(p),
    f(s,M)=int_0^1 x(1-x)/[M+x(1-x)s]dx.

Here M denotes mass squared,M_0=delta and the other four masses are
g10^2*(3/10,3/2,25,253/10). The five independently reconstructed charge
forms have supports11,9,0,12,12 within their full12x12 domains. In particular
the neutral heavy sector has zero H charge;its zero is proved,not guessed.
The light form is diag(0,2,2,2,3,3,3,3,3,3,3,3),and the five forms sum to8I.

## What had to be retained

There are exactly three background placements:the chi-vertex covariant
derivative contact,the ghost inverse insertion,and the vector inverse
insertion with its spin coupling. Their separate affine-background pole
weights are1,-1/2,-1/2. Their sum has no UV pole.

The contact and orbital pieces cancel after the ordered momentum routing
and exact dimensional angular integration. The remaining vector-spin
contribution is nonzero. Dropping spin would preserve the pole cancellation
while incorrectly removing the entire finite source in this class.

The coefficient was obtained from source vertices and propagator variations
before testing a Nielsen identity. It was not assigned the value needed
to cancel a width derivative. LEFT derivatives and external order K,chi
fix the source sign;the opposite order changes the polynomial coefficient.
The source cumulant prefactor is-1/2 before the endpoint integration by parts.

## The infrared question now has an explicit answer

For s>0 the finite function is

    f(s,M)=[1-4M*atanh(sqrt(s/(4M+s)))/sqrt(s(4M+s))]/s.

Its limits differ in precisely the way the earlier local argument could
not resolve:

    f(0,M)=1/(6M),
    lim_(M->0 at fixed s>0) f(s,M)=1/s.

Thus the regulated light source tends to

    ell*g10^2*B_0*(delta_munu-p_mu p_nu/p^2)*Abar_nu.

This is finite,nonzero and nonlocal. Positive-heavy sources instead begin
with a local covariant dimension-six EOM structure. Applying that heavy
dimension argument to the massless source would be incorrect.

LGF/RLS establish the same light action,propagators,vertices,projector and
charges on the full/EFT sides. Their identical light source function is
therefore common before any local expansion or regulator removal. It
cancels as a common kernel;each side is not declared zero. It is not an
additional hard contribution to add to FAN's two-loop finite assembly.

The dimensional result is f_D=2 int x(1-x)J3 and independently
f_D=-partial_s B0_D. The derivative removes the bubble pole;no finite
normalization constant was selected. This projection requires no UV source
counterterm. Other K_Q*chi*Q and mixed source counterterms remain separate.

## The actual one-loop background identity

At fixed x2,the first-width vector determinant varies by
Tr(Gv Dcol Drow)/2. In a positive-heavy sector,the actual FP mass variation
supplies-M Tr Gc/2. In the light sector the ghost regulator is width
independent;RNC's actual mixed u*chi contact supplies-delta Tr Gc/2 instead.
Scalar first traces and off-diagonal vector/scalar first traces vanish in
this width slice for their established action-based reasons.

The source contraction with the classical Yang-Mills field equation is
-Tr(Jrow Gv Dcol Gc)/2. Expanding noncommuting derivatives proves

    Kv Dcol=Dcol Kc-Jcol.

Consequently the direct width-plus-partner variation and source contraction
sum to-Tr I/2. That identity contact has no background variation in the
declared prescription. The quadratic-background Nielsen identity follows
before the infrared limit,with its actual regulator/source partner present.
This uses dimensional cyclicity in the common positive-mass convergence
domain and meromorphic continuation,not an unrestricted singular trace rule.

The result also explains the earlier RNC local check. At fixed delta,the
source starts at p^4/delta in its contraction with the tree EOM;its local
F^2 part vanishes and the vector/regulator local contacts cancel. At fixed
nonzero momentum followed by delta removal,the source has a nonzero
quadratic F^2-order contribution. The two orders of limits cannot be
substituted for each other. In the matched one-loop light difference the
common kernel is identical before either operation.

## Verification,failures and resources

Receipt validation_receipt.json,SHA256
c7de1a41dd18a59e5b1d589fa10518e24dd590a0e8299ee4308f210f42333f23,
status QUALIFIED_VECTOR_NIELSEN_FORM_FACTOR_AND_REGULATED_ONE_LOOP_BACKGROUND_IDENTITY.
Scientific/director acceptance NOT_PERFORMED;authority34/39 unchanged.

Primary used actual structure constants/projectors,source ordering,the
literal three background placements and a free noncommuting-operator
identity. Replay independently transported WHP charge forms with the
Hermitian basis map,used a normalized Berezin Gaussian,and obtained the
source from scalar-resolvent cancellation plus spin and a bubble derivative.
It also tested the coupled identity with noncommuting9x9 vector operators.

The separate verifier imported neither native calculation. It checked
all720 sector charge and720 finite source-tensor positions,including their
zero complements,a literal16-dimensional exterior representation,different
12x12 noncommuting covariant operators,and missing-contact/spin/source-sign/
mass-partner controls. The free operator proof supplies the general identity;
finite matrices are sensitive diagnostics,not a substitute for that proof.

Six Gamma-function comparisons,three longitudinal-zero checks and five
finite-function comparisons used85 digits and tolerance1e-65. Maximum
errors were1.60861174671e-86,0,and1.56972355773e-82 respectively. Exact source,
tensor and operator identities supply evidence beyond numerical agreement.
The U1 light and neutral-heavy zero sectors are insensitive to some controls;
the nonzero SU2/SU3 blocks and full complement are retained.

The initial primary failed at its parameter-reflection assertion because
serialized expressions were parsed with a different assumption-free x than
the native real x. Original sources,capture and controller failure remain
unchanged. V2 binds the correct symbol explicitly;no diagram,coefficient,
parameter,source sign or acceptance tolerance changed. The original replay
and verifier were run unchanged and completed on their first executions.

Preparation bound5601 inputs,V2 bound5612,and verification bound5619.
Completed after-import times were3.32952279999,2.12148640002 and4.86032050004s.
Private-memory sampled maxima were51216384,46424064 and53006336 bytes,with
3,2,3 samples. These are observed samples,not continuous peaks. All runs
stayed within600s/8GiB sampled/350MiB launch/24MiB package. No expensive
qualified primitive amplitudes were replayed. Readiness and raw/index/HEAD
seals are in the external vector-nielsen-form-factor-v1-2026-10-21 directory.
Historical custody remains exit2/seven unresolved references,never PASS.

## Scientific significance and remaining requirements

This completes the specific nonlocal one-loop vector source that the RLS
handoff identified as missing. It gives an actual common light kernel and
a bounded regulated first-width identity,so future work need not assume
that source zero or discard it by local heavy-mass counting.

The next required step is the complete fixed-order extended-source pole
normalization and its common two-loop first-variation transport. One must
establish the applicability of minimal subtraction to that actual source
action,including mixed partners and dimensional lifts,and reconcile the
one-soft and two-soft owners. The two-loop 1PI derivative is still neither
measured nor assigned from the desired FAN conditional cancellation.

Primary comparators are [Lewandowski,1307.4055v1](https://arxiv.org/pdf/1307.4055v1)
and [Breckenridge--Lavelle--Steele,hep-th/9407028](https://arxiv.org/pdf/hep-th/9407028).
They supply established extended-source methods,not this BFT kernel or a
certificate for its two-loop matching. Shared action,group/projectors,DR/
region assumptions,software and AI author remain shared-error limits.
There is no external scientific endorsement or experimental confirmation.
Root previously saw the historical comparison target;no blind-author claim.
Workers did not use it to fit coefficients or calculate a physical comparison.

FAN/SRG/MTA/BMC and all historical bytes remain. Numerical C1,two-loop width
independence,E5/A5,physical unification and complete fermionic coverage stay
unqualified. Preserve the scalar140%local/1.94%Euclidean/20.27%timelike,
tree|a0|~.76809>1/2,gauge residual.745476/missingYukawas and quartet warnings;
paused matter/flavor and HB1/C5 block remain. Whole investigation incomplete.
