"""NVF1 separate exact tensors,exterior matrices,finite functions and Ward traces."""
from pathlib import Path
from hashlib import sha256
import gzip,json,os,sys,threading,time,importlib.util
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()))
started=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
spec=importlib.util.spec_from_file_location('nvf_exact',CAL/'canonical_so10_nielsen_affine_poles/exact_v2.py')
exact=importlib.util.module_from_spec(spec);spec.loader.exec_module(exact)
dec=lambda d:s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z) for i,j,z in d['entries']})
A=packed(HERE/'primary_tables.json.gz');B=packed(HERE/'replay_tables.json.gz')
for key in ['charges','finite_charge_tensors']:
    assert len(A[key])==len(B[key])==5
    for aa,bb in zip(A[key],B[key]):
        assert aa['shape']==bb['shape']==[12,12] and exact.decode(aa)==exact.decode(bb)
assert A['mass_eigenvalues']==B['mass_eigenvalues']==['0','3/10','3/2','25','253/10']
for key in ['source_cross_prefactor','color_operator_prefactor','f_D_J3_coefficient','finite_prefactor','UV_pole','M_times_f_at_zero','massless_s_times_f']:
    assert s.sympify(A[key])==s.sympify(B[key]),key
assert A['source_cross_prefactor']==A['color_operator_prefactor']=='-1/2'
assert A['f_D_J3_coefficient']=='2' and A['finite_prefactor']=='1' and A['UV_pole']=='0'
assert A['M_times_f_at_zero']=='1/6' and A['massless_s_times_f']=='1'
charges=list(map(dec,A['charges']));C=charges[0];H=sum(charges[1:],s.zeros(12))
assert C==s.diag(0,*([2]*3),*([3]*8)) and C+H==8*s.eye(12) and charges[2]==s.zeros(12)
rls=packed(CAL/'canonical_so10_regulated_light_slavnov/primary_tables.json.gz')
for current,prior in zip(A['charges'],rls['charges']):assert exact.decode(current)==exact.decode(prior)
for charge,finite in zip(A['charges'],A['finite_charge_tensors']):assert exact.decode(charge)==exact.decode(finite)
x=s.symbols('x',real=True);M,P2=s.symbols('M s',positive=True)
locals_={'M':M,'s':P2,'x':x}
fA=s.sympify(A['finite_form_factor'],locals=locals_);fB=s.sympify(B['finite_form_factor'],locals=locals_)
assert s.simplify(fA-fB)==0
dens=A['background_densities']
def density(pol,name,key):return s.sympify(dens[pol][name][key],locals=locals_)
def total(pol,key):return s.expand(sum(density(pol,n,key) for n in ['contact','vector','ghost']))
sym=lambda z:s.factor((z+z.subs(x,1-x))/2)
assert sym(total('transverse','J2'))==0 and sym(total('parallel','J2'))==0
assert sym(total('parallel','sJ3'))==0 and s.simplify(sym(total('transverse','sJ3'))+4*x*(1-x))==0
residues={n:s.integrate(density('transverse',n,'J2'),(x,0,1)) for n in ['contact','vector','ghost']}
assert list(residues.values())==[1,-s.Rational(1,2),-s.Rational(1,2)]
assert sum(residues.values())==0
# Literal16-dimensional creation matrices,not a native source-sign helper.
def create(bit):
    return s.SparseMatrix(16,16,{(mask|(1<<bit),mask):(-1)**((mask&((1<<bit)-1)).bit_count()) for mask in range(16) if not mask&(1<<bit)})
K,chi,c,bc=[create(j) for j in range(4)];I=s.SparseMatrix.eye(16)
vac=s.SparseMatrix(16,1,{(0,0):1});body=(I-bc*c)*vac;normal=body[12,0]
q=s.symbols('q',real=True);action=q*K*c-q*chi*bc/2
value=body;term=body
for n in range(1,3):term=-action*term/n;value=value+term
cross=-s.expand(value[15,0]/normal).subs(q**2,1)
assert cross==-s.Rational(1,2) and s.expand(value[12,0]/normal)==1
# Independent different noncommuting covariant matrices and mass.
N=4
def skew(a,b):
    out=s.zeros(N);out[a,b]=1;out[b,a]=-1;return out
d=[skew(0,1),skew(1,2),skew(2,3)+skew(0,3)/2];mass=s.Rational(100)
comm=lambda a,b:a*b-b*a
Kc=-sum((a*a for a in d),s.zeros(N))+mass*s.eye(N)
F=[[comm(a,b) for b in d] for a in d]
J=[sum((comm(d[n],F[n][m]) for n in range(3)),s.zeros(N)) for m in range(3)]
Dc=s.Matrix.vstack(*d);Dr=s.Matrix.hstack(*d);Jc=s.Matrix.vstack(*J);Jr=s.Matrix.hstack(*J)
Kv=s.BlockMatrix([[(Kc if m==n else s.zeros(N))-2*F[m][n] for n in range(3)] for m in range(3)]).as_explicit()
assert Kv==Kv.T and Kv*Dc-Dc*Kc+Jc==s.zeros(12,4)
Gv=Kv.inv();Gc=Kc.inv()
width=s.trace(Gv*Dc*Dr)/2;partner=-mass*s.trace(Gc)/2
source=-s.trace(Jr*Gv*Dc*Gc)/2
assert source!=0 and width+partner+source+N/2==0
assert width+partner-source+N/2!=0 and width+source+N/2!=0
spinless=s.diag(Kc,Kc,Kc).inv()
spinless_residue=s.trace(spinless*Dc*Dr)/2+partner-s.trace(Jr*spinless*Dc*Gc)/2+N/2
assert spinless_residue!=0
assert s.Rational(B['covariant_matrix']['width_plus_mass_partner'])+s.Rational(B['covariant_matrix']['tree_EOM_source'])+s.Rational(B['covariant_matrix']['identity_contact'])==0
assert A['operator_Ward_zero_components']==3
# RNC's actual auxiliary contact and source width;LGF actual common action.
rnc=packed(CAL/'canonical_so10_regulator_nielsen_contact/primary_tables.json.gz');x1=s.symbols('x1')
assert s.sympify(rnc['auxiliary_contact_coefficient']).subs(s.Symbol('x1'),1)==s.Rational(1,2)
lgf=read(CAL/'canonical_so10_light_gauge_tree_correspondence/validation_receipt.json')
assert lgf['same_dimension_four_tree_gauge_FP_density'] and lgf['actual_regulator_transport_retained']
mp.mp.dps=85;gamma_errors=[];long_errors=[]
funcs={(pol,n,key):s.lambdify(x,density(pol,n,key),'mpmath') for pol in ['parallel','transverse'] for n in ['contact','vector','ghost'] for key in ['J2','sJ3']}
for ds,ms,ps in [('2.4','0.7','0.2'),('3.4','2.3','8.1'),('3.9','1.1','3.7')]:
    dim,momass,mom=map(mp.mpf,[ds,ms,ps]);ep=2-dim/2
    j2=lambda y:mp.gamma(ep)*y**(-ep)
    j3=lambda y:mp.gamma(1+ep)*y**(-1-ep)/2
    a=lambda t:momass+t*(1-t)*mom
    direct={}
    for pol in ['parallel','transverse']:
        value=0
        for n in ['contact','vector','ghost']:
            value+=mp.quad(lambda t:funcs[pol,n,'J2'](t)*j2(a(t))+mom*funcs[pol,n,'sJ3'](t)*j3(a(t)),[0,mp.mpf('.5'),1])
        direct[pol]=-value/2
    param=2*mp.quad(lambda t:t*(1-t)*j3(a(t)),[0,mp.mpf('.5'),1])
    derivative=mp.gamma(1+ep)/(6*momass**(1+ep))*mp.hyp2f1(1+ep,2,mp.mpf('2.5'),-mom/(4*momass))
    gamma_errors.extend([abs(direct['transverse']/mom-param),abs(param-derivative)])
    long_errors.append(abs(direct['parallel']))
    assert max(gamma_errors+long_errors)<mp.mpf('1e-65')
finite_errors=[]
for ttext in ['0.00001','0.1','1','10','1000']:
    t=mp.mpf(ttext);quad=mp.quad(lambda y:y*(1-y)/(1+t*y*(1-y)),[0,mp.mpf('.5'),1])
    closed=(1-4/mp.sqrt(t*(4+t))*mp.atanh(mp.sqrt(t/(4+t))))/t
    finite_errors.append(abs(quad-closed));assert abs(quad-closed)<mp.mpf('1e-65')
assert s.integrate(x*(1-x),(x,0,1))==s.Rational(1,6)
assert s.cancel((x*(1-x)/(M+x*(1-x)*P2)).subs(M,0))==1/P2
# Dropping contact/ghost leaves an uncancelled UV residue;dropping spin
# preserves pole cancellation but loses this nonzero finite source entirely.
controls={'omitted_chi_contact':sum(residues.values())-residues['contact']!=0,
    'omitted_ghost_insertion':sum(residues.values())-residues['ghost']!=0,
    'omitted_vector_spin_finite':A['f_D_J3_coefficient']!='0',
    'wrong_source_order':source!=0,'omitted_heavy_ghost_mass_partner':partner!=0,
    'omitted_light_regulator_contact':partner!=0,'spinless_operator_identity':spinless_residue!=0,
    'premature_local_light_limit':s.Rational(1,6)!=1}
assert all(controls.values())
for z in [A,B]:
    assert z['complete_KQ_chi1_Abar_class'] and z['one_loop_background_first_width_identity']
    assert not z['two_loop_width_identity_qualified'] and not z['finite_C1_calculated']
out={'schema':'NVF1_VALIDATION_RECEIPT','status':'QUALIFIED_VECTOR_NIELSEN_FORM_FACTOR_AND_REGULATED_ONE_LOOP_BACKGROUND_IDENTITY',
    'execution_state':'COMPLETED','scientific_acceptance':'NOT_PERFORMED','scientific_authority':'34/39_UNCHANGED',
    'sector_charge_positions':720,'finite_source_tensor_positions':720,'ordered_background_groups':3,
    'source_cross_prefactor':'-1/2','dimensional_J3_prefactor':'2','UV_pole':'0','M_times_f_at_zero':'1/6',
    'massless_s_times_f':'1','light_Casimirs':['0','2','3'],'literal_exterior_dimension':16,
    'native_covariant_matrix_size':9,'verifier_covariant_matrix_size':12,'free_Ward_components':3,
    'Gamma_comparisons':len(gamma_errors),'longitudinal_zero_checks':len(long_errors),'finite_function_comparisons':len(finite_errors),
    'precision_digits':85,'absolute_tolerance':'1e-65','maximum_Gamma_error':mp.nstr(max(gamma_errors),12),
    'maximum_longitudinal_error':mp.nstr(max(long_errors),12),'maximum_finite_error':mp.nstr(max(finite_errors),12),
    'complete_KQ_chi1_Abar_class':True,'one_loop_background_first_width_identity':True,
    'full_EFT_light_nonlocal_kernel_common_before_limits':True,'controls':controls,'neutral_light_U1_insensitive':True,
    'two_loop_width_identity_qualified':False,'complete_extended_source_CT_family':False,'finite_C1_calculated':False,
    'new_physical_normalization_chosen':False,'elapsed_after_imports':time.perf_counter()-started}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
