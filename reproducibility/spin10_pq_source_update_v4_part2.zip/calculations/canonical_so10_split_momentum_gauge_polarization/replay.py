"""GEP1 actual P/S Ward insertion, sigma transverse projection and Schwinger moments."""
from data import *
from itertools import product
start=begin('replay')
assert 'qS=0' in (CAL/'canonical_so10_sterile_matter_action/ACTION_V1.md').read_text(encoding='utf-8')
def tidy(mat):return s.SparseMatrix(mat).applyfunc(s.expand)
def zero(mat):assert not tidy(mat).todok()
def block(a,b,c,d):return s.SparseMatrix(s.BlockMatrix([[a,b],[c,d]]).as_explicit())
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];g4=[s.kronecker_product(pa[0],s.eye(2)),s.kronecker_product(pa[1],s.eye(2)),s.kronecker_product(pa[2],pa[0]),s.kronecker_product(pa[2],pa[1])];gam=[s.kronecker_product(mat,pa[2]) for mat in g4]+[s.kronecker_product(s.eye(4),mat) for mat in pa[:2]];chi=s.kronecker_product(g4[0]*g4[1]*g4[2]*g4[3],s.eye(2));PL=(s.eye(8)+chi)/2;PR=s.eye(8)-PL;Ps=[PL,PR]
for i,j in product(range(6),repeat=2):zero(gam[i]*gam[j]+gam[j]*gam[i]-2*int(i==j)*s.eye(8))
for i,mat in enumerate(gam):zero(mat*chi+chi*mat if i<4 else mat*chi-chi*mat)
p=s.symbols('pbar0:4');k=s.symbols('kbar0:4');hp=s.symbols('phat0:2');hk=s.symbols('khat0:2');BP=sum((q*mat for q,mat in zip(p,gam)),s.zeros(8));BK=sum((q*mat for q,mat in zip(k,gam)),s.zeros(8));HP=sum((q*mat for q,mat in zip(hp,gam[4:])),s.zeros(8));HK=sum((q*mat for q,mat in zip(hk,gam[4:])),s.zeros(8));P2=sum(q*q for q in p+hp);K2=sum(q*q for q in k+hk);HP2=sum(q*q for q in hp);HK2=sum(q*q for q in hk);NP=block(BP,HP,HP,BP);NK=block(BK,HK,HK,BK);DP=s.I*NP;DK=s.I*NK
zero(DP*(-s.I*NP)-P2*s.eye(16));zero((-s.I*NP)*DP-P2*s.eye(16));zero(DK*(-s.I*NK)-K2*s.eye(16));zero((-s.I*NK)*DK-K2*s.eye(16))
aL,aR=s.symbols('a_left a_right');A=PL*aL+PR*aR;At=PR*aL+PL*aR;Z=s.zeros(8);GG=block(A,Z,Z,Z);GT=block(At,Z,Z,Z);Vq=block((BK-BP)*A,Z,Z,Z);E=DK*GG-GT*DP-s.I*Vq;expected=block(Z,-s.I*At*HP,s.I*HK*A,Z);zero(E-expected)
sewn=(NK*E*NP)[:8,:8];fold=s.I*(HK2*A*BP-BK*At*HP2);zero(sewn-fold)
endclear=GG*NP*K2-NK*GT*P2;assert any(s.expand(value)!=0 for value in endclear)
# Physical trace4 = witness trace8/2; the separate Nambu Gaussian is1/2.
# -i times the sewn E trace converts its i numerator to a positive unit.
ward_phase=s.simplify(-s.I*s.I);assert ward_phase==1
kp={};pp={}
for nu,rho in product(range(4),repeat=2):
 kp[nu,rho]=[[s.simplify(s.trace(gam[rho]*Ps[1-i]*gam[nu]*Ps[j])/4) for j in range(2)] for i in range(2)]
 pp[nu,rho]=[[-s.simplify(s.trace(Ps[i]*gam[rho]*gam[nu]*Ps[j])/4) for j in range(2)] for i in range(2)]
yct=packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz');T=list(map(dec,yct['Tminus']));H=dec(yct['H_new'])
def trprod(left,right):return s.simplify(sum(value*right[j,i] for (i,j),value in s.SparseMatrix(left).todok().items()))
G=s.Matrix(45,45,lambda a,b:trprod(T[a],T[b]));Kcolor={};Pcolor={}
for nu,rho in product(range(4),repeat=2):
 km=s.zeros(45);pm=s.zeros(45)
 for a,b in product(range(45),repeat=2):
  aa=[T[a],-T[a].T];bb=[T[b],-T[b].T]
  for i,j in product(range(2),repeat=2):
   if kp[nu,rho][i][j]:km[a,b]+=ward_phase*kp[nu,rho][i][j]*trprod(aa[i],bb[j])
   if pp[nu,rho][i][j]:pm[a,b]+=ward_phase*pp[nu,rho][i][j]*trprod(aa[i],bb[j])
 Kcolor[nu,rho]=km;Pcolor[nu,rho]=pm
# Independently fix the transverse coefficient with two-component sigma traces.
sig=[s.eye(2),s.Matrix([[0,s.I],[s.I,0]]),s.Matrix([[0,1],[-1,0]]),s.diag(s.I,-s.I)];bsig=[sig[0]]+[-mat for mat in sig[1:]];traces={}
for mu,al,nu,be in product(range(4),repeat=4):traces[mu,al,nu,be]=s.simplify(s.trace(sig[mu]*bsig[al]*sig[nu]*bsig[be]+sig[mu]*bsig[be]*sig[nu]*bsig[al])/2)
eps,L,x=s.symbols('epsilon L x');u=x*(1-x);qb=s.symbols('qbar0:4');offdiag=s.expand(sum(traces[0,al,1,be]*(-u*qb[al]*qb[be]) for al,be in product(range(4),repeat=2)));cweight=s.factor(-offdiag/(u*qb[0]*qb[1]))
assert sum(traces[0,al,1,al] for al in range(4))==0
# Sewn numerator shifts p=l-xq,k=l+(1-x)q. Cross bar/hat moments vanish.
# Compute the coefficient of qbar_nu*hatqÂ² directly from that shifted numerator.
hatq2,lh2,j2,ib=s.symbols('hatq2 lhat2 J2 I2');avg_k=(1-x)*(lh2+x*x*hatq2);avg_p=-x*(lh2+(1-x)**2*hatq2);shifted=s.expand(avg_k-avg_p);assert s.factor(shifted-lh2-u*hatq2)==0
# I_hat/QÂ²=(h/2)*Gamma(eps-1)*Beta(2-eps,2-eps)*exp(...).
# The factor2 below comes from the measured K/P color trace, not a Ward fit.
h=-2*eps;beta=s.gamma(2-eps)**2/s.gamma(4-2*eps);regular_master=s.exp((s.EulerGamma+L)*eps)*s.gamma(1+eps)*beta;frat=s.factor(h/(eps-1));hrat=s.factor(frat+2)
C=cweight*regular_master/eps;F=s.cancel(frat/eps)*regular_master;HH=hrat*regular_master/eps
logmaster=(s.EulerGamma+L)*eps+s.loggamma(1+eps)+2*s.loggamma(2-eps)-s.loggamma(4-2*eps);log1=s.simplify(s.diff(logmaster,eps).subs(eps,0));log2=s.simplify(s.diff(logmaster,eps,2).subs(eps,0));c0=s.simplify(cweight*s.gamma(1)*s.gamma(2)**2/s.gamma(4));Cjet=[c0,s.simplify(c0*log1),s.simplify(c0*(log1**2+log2)/2)]
rf=s.cancel(frat/(eps*cweight));rh=s.cancel(hrat/cweight);fco=[s.simplify(s.diff(rf,eps,i).subs(eps,0)/s.factorial(i)) for i in range(2)];hco=[s.simplify(s.diff(rh,eps,i).subs(eps,0)/s.factorial(i)) for i in range(3)];Fjet=[s.simplify(sum(Cjet[j]*fco[i-j] for j in range(i+1))) for i in range(2)];Hjet=[s.simplify(sum(Cjet[j]*hco[i-j] for j in range(i+1))) for i in range(3)]
single=s.gammasimp((s.gamma(3-eps)*s.gamma(2-eps)/s.gamma(5-2*eps))/beta);assert s.simplify(single-s.Rational(1,2))==0
# Both endpoint momenta are retained. Gaussian oddness proves each vanishes
# with a positive auxiliary IR reference before meromorphic continuation.
Jp,Jk,sch=s.symbols('Jp Jk sch',positive=True);odd_p=s.diff(s.exp(Jp**2/(4*sch)),Jp).subs(Jp,0);odd_k=s.diff(s.exp(Jk**2/(4*sch)),Jk).subs(Jk,0);assert odd_p==odd_k==0
finish('replay',{'method':'actual_PS_defect_sewing_sigma_transverse_projection_and_Schwinger_hat_moment','bar_trace_coefficients':[str(traces[key]) for key in product(range(4),repeat=4)],'G':enc(G),'SM_G':enc(H.T*G*H),'K_color_matrices':{f'{nu}_{rho}':enc(mat) for (nu,rho),mat in Kcolor.items()},'P_color_matrices':{f'{nu}_{rho}':enc(mat) for (nu,rho),mat in Pcolor.items()},'form_factors_C_F_H':list(map(str,[C,F,HH])),'C_pole_finite_epsilon':list(map(str,Cjet)),'F_finite_epsilon':list(map(str,Fjet)),'H_pole_finite_epsilon':list(map(str,Hjet)),'UV_tensor_coefficients':[str(Cjet[0]),str(-Cjet[0]),str(Hjet[0])],'Ward_UV_barq2_hatq2':['0',str(Hjet[0])],'Ward_physical_finite':str(Fjet[0]),'three_family_bar_transverse_pole':enc(3*Cjet[0]*G),'three_family_hat_kinetic_pole':enc(3*Hjet[0]*G),'single_mixed_block_ratio':str(single),'endpoint_kernels_nonzero_before_integration':True,'endpoint_integrals_retained_and_proved_odd':2,'free_inverse_positions_checked':4*16**2,'PS_Ward_defect_positions_checked':16**2,'sewn_PP_positions_checked':8**2,'physical_spin_trace':4,'witness_spin_trace':8,'witness_to_physical_divisor':2,'gaussian_factor':'1/2','closed_family_count':3,'external_hat_vertex_components':'ZERO_BY_SMA_ACTION','hat_rank_used':'d-4=-2epsilon','new_one_loop_two_point_families':1,'new_two_loop_integrals':0,'mass_dependent_polarization_computed':False,'physical_scheme_adopted':False},start)
