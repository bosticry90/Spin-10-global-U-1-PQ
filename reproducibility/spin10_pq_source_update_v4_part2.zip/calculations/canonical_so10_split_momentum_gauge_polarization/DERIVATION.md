# GEP1 kinetic bubble and actual SMA1 hatted insertion

At the mass-independent leading symbol D_PS(p)=i[[barSlash,hatSlash],
[hatSlash,barSlash]], S_PS=-i[[barSlash,hatSlash],[hatSlash,barSlash]]/p².
Vertices are PP only: V_a=-ig barGamma(PL Ta-PR Ta^T). All external hatted
vector vertices vanish. The Nambu effective action -Trlog(D)/2 gives the
quadratic kernel +Tr(S Va S Vb)/2, with no second half or extra sterile state.
Closed gauge-only family trace is3, unlike the earlier open-line diagrams.

For q=k-p define G=diag(A,0),Gtilde=diag(Atilde,0),
A=PL Ta-PR Ta^T,Atilde=PR Ta-PL Ta^T. The exact defect is

 E=D(k)G-Gtilde D(p)-i qbar.Gamma
   =[[0,-i Atilde hatSlash(p)],[i hatSlash(k)A,0]].

The sewn identity is
 i S(k)(qbar.Gamma)S(p)=G S(p)-S(k)Gtilde-S(k)E S(p).

Both endpoint terms remain before translation-invariant integration. Sewing
the actual off-diagonal insertion blocks yields a PP numerator with hatp²
and hatk², not an assumed finite contact. For physical trace4 and the Nambu
half, its traced Ward integrand should reduce to

 2 Tr(Ta Tb)[kbar_nu hatp²-pbar_nu hatk²]/[p² k²].

This normalization/sign is a hypothesis until the explicit block/trace route
checks it. After p=l-xq, angular averaging gives qbar_nu times
(h/d)l²+x(1-x)hatq². The h=d-4 piece can be finite after multiplying a pole;
the external hatq² piece can retain a pole. Neither may be dropped early.

The direct barred numerator is derived separately from actual Nambu traces.
With u=x(1-x),Delta=uQ²,I2=integral(l²+Delta)^-2 and
J2=integral l²(l²+Delta)^-2, it has candidate angular form

 G[-4/d J2 delta+2u barq² I2 delta-4u qbar_mu qbar_nu I2].

Derive J2=-d Delta I2/(d-2) from Gamma/Schwinger integrals. Work in three
independent momentum carriers, and compare the contraction with the sewn
insertion. The transverse scalar C is separately fixed by two-component
off-diagonal sigma traces; it must not be inferred by demanding a Ward zero.
Gamma/Beta functions keep every finite/epsilon jet available. Their physical
hatq=0 limit is a later comparison to CSC1, not a worker input value.

The negative measured pole defines a real local quadratic singular term.
Comparison with full-d transverse (Q²g-qq) requires all projector components
of the evanescent difference, since the actual loop has only barred external
vertices. This does not establish a nonlinear covariant completion or an
adopted physical renormalization. Endpoint oddness here uses the explicit
dimensional translation prescription, not cyclicity of the project's heat
operator products. All claims remain within this off-shell one-loop domain.
