"""GEP1 immutable-input and source freeze before any model calculation."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/split-momentum-gauge-polarization-v1-2026-10-22');BASE='b41208cefb462c14fcd347ac6617463c4cbdd0aa'
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind={}
def add(path,expected=None):
 path=path.resolve();hsh=sha256(path.read_bytes()).hexdigest()
 if expected is not None:assert hsh==expected,str(path)
 bind[str(path)]=hsh
for name in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V507.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md']:add(ROOT/name)
add(PK/'export_a10_e5_antighost_vector.py')
for folder,names in {'canonical_so10_sterile_matter_action':['ACTION_V1.md','RESULT.md','validation_receipt.json','primary_tables.json.gz','replay_tables.json.gz'],'canonical_so10_sterile_massive_propagator':['RESULT.md','validation_receipt.json','primary_tables.json.gz','replay_tables.json.gz'],'canonical_so10_yukawa_carrier_transport':['primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json'],'canonical_so10_chiral_sterile_comparison':['RECORD.md','RESULT.md','review.py','validation_receipt.json'],'canonical_so10_chiral_polarization_contact':['RECORD.md','RESULT.md','primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json'],'canonical_so10_fermion_statistical_normalization':['RESULT.md','validation_receipt.json'],'canonical_so10_matter_gauge_vertex_normalization':['RESULT.md','validation_receipt.json'],'canonical_so10_fermion_kinetic_mass_poles':['RESULT.md','validation_receipt_v2.json']}.items():
 for name in names:add(ROOT/'calculations'/folder/name)
add(ROOT/'project_state.json','d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8');add(ROOT/'calculations/canonical_so10_sterile_matter_action/validation_receipt.json','21d4816d5ea079b28b41783e8d65aa3bd52d779349c90106d4dec5e99e10bd41');add(ROOT/'calculations/canonical_so10_sterile_massive_propagator/validation_receipt.json','53a99e56ee95c247efd4e07d3ff7a4fb8817d284dd4f7a0cbfc63f449495c25c')
for name in ['prepare.py.failed-source.txt','run.py.failed-source.txt','failure.json']:add(Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/split-momentum-gauge-prefreeze-failure-2026-10-22')/name)
for name in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 path=HERE/name;raw=path.read_bytes();assert b'\r' not in raw
 if path.suffix=='.py':ast.parse(raw)
 with (HERE/(name+'.source.txt')).open('xb') as handle:handle.write(raw)
 add(path);add(HERE/(name+'.source.txt'))
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==30938
with (CONTROL/'old_git_tree.txt').open('xb') as handle:handle.write(tree)
with (HERE/'preparation.json').open('xb') as handle:handle.write((json.dumps({'schema':'GEP1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(bind.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'package_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('GEP1_FROZEN',len(bind),'bindings',flush=True)
