# GEP1 result: general-split gauge polarization and linear insertion

Qualified within the frozen mass-independent one-loop dimensional family.
Receipt SHA256 cad8a797c495ccdde738fd8f815f3d4e6f7dadf220852123dc035382ea0de1ab.
Scientific acceptance NOT_PERFORMED; project_state.json113 and authority34/39
unchanged. Whole Spin(10) x PQ investigation remains incomplete.

For each Weyl16, write G_ab=Tr(Ta Tb)=2delta_ab, Q²=barq²+hatq²>0,
L=log(mu_R²/Q²), d=4-2eps. The actual SMA1/SMP1case0 charged/sterile
Nambu action gives, with common g²/(16pi²),

 Pi_ab,mn=G_ab[C(barq²delta_mn-barq_m barq_n)
                 +F barq²delta_mn+H hatq²delta_mn],
 C=4 exp[(gamma_E+L)eps]Gamma(eps)B(2-eps,2-eps),
 F=2 exp[(gamma_E+L)eps]Gamma(1+eps)B(2-eps,2-eps)/(1-eps),
 H=C/2+F=C/[2(1-eps)].

C pole=2/3, finite=2L/3+10/9; F finite=1/3;
H pole=1/3, finite=L/3+8/9, eps coefficient
L²/6+8L/9-pi²/36+52/27. Exact Gamma/Beta kernels and jets are in tables.
Every hatted external vector vertex is absent in the actual action; cross
and hatted external tensor components are structural zeros.

Thus the pole per family is G_ab/eps times
[2/3(barq²delta-barq barq)+1/3 hatq²delta]. The three-family closed trace
produces 4I45 transverse barred pole and 2I45 hatted kinetic pole. Unlike
an open fermion line, this closed loop requires the family factor3.
The full physical spin trace4, conjugate chiral blocks and determinant half
are all retained. No extra sterile state, half or family multiplicity.

The negative measured quadratic pole defines a real local singular
subtraction; its full tensor remainder is exactly0. Replacing the barred
transverse tensor by a full-d transverse tensor requires the entire
projector-valued evanescent difference. In particular its bar/hat cross
components must not disappear from the comparison. The subtraction table
packed/raw SHA256 values are
29a535d13f54018327b9f8347495d3095fe3728bbeed8e43e0cfe83e6c041b9a /
77615a2856f366f5bfd105fc81e6ec0ffc8674d6053066aa1651000ce3e6bce2.

The independent insertion derives D(k)G-Gtilde D(p)-iVq, with both mixed
P/S blocks, before sewing. It checks1024 inverse positions,256 defect
positions and64 sewnPP positions. After physical trace/Nambuhalf the
Ward integrand is 2G_ab[kbar_n hatp²-pbar_n hatk²]/(p²k²).
Both endpoint terms are nonzero before integration. Their vanishing uses
odd Gaussian integrals in the declared translation-invariant analytic
prescription, not cyclicity of a heat trace. Their retained contraction
agrees exactly with the direct result: insertion remainder0.

Primary uses explicit barred Nambu traces and Feynman/Gamma integration.
Replay uses the full split-Clifford P/S defect, Schwinger hat moments and
an independent two-component transverse trace. A finite spin witness is
divided by2 to recover trace4; analytic hat rank remains d-4=-2eps, never2.
Direct color comparison covers6219 positions; insertion comparison64800;
256bar trace slots and512 cross-chiral zeros agree. Factorized quadratic
momentum coverage356400 positions means2025colors x16Lorentz x11carriers,
not that many independent experiments or giant expanded calculations.

Physical hatq0 reproduces CSC1, not the older conjugate-Nambu G+M contact.
The finite physical contact is distinct from the hatted UV pole, although
the full-family numerical coefficients both equal2 in different gradings.
All recorded negative controls detect their intended errors. Reversing
analytic hat sign changes the physical finite term but not the leading
UV pole; pole agreement alone would miss that error.

Observed primary/replay/verifier native exits0:8.489117699999042 /
8.653767399999197 /1.663494599997648 seconds after imports. Resource samples
5/5/2, maximum sampled private bytes51187712/51392512/51691520, not continuous
peaks. Frozen600s/8GiBsampled/350MiBlaunch/16MiB bounds respected.53initial
and60validation bindings,8source copies. Fresh current-logical-turn E4
native0 with expected steps0,0,0,0,0,2; historical custody remains exit2/
seven NOTPASS. No expensive historical scientific replay or acceptance.

Prefreeze preparation failed on a guessed unversioned FKP1 receipt name.
Original preparer/controller sources and failure metadata are preserved at
external split-momentum-gauge-prefreeze-failure-2026-10-22, bound by the
successful preparation. Correct inventory uses validation_receipt_v2.json.
This stopped before source freeze or scientific workers. No frozen worker
or verifier failed. No failure was erased or relabeled PASS.

This supplies one new two-point family and its linear insertion,0two-loop
integrals. It does not prove cubic/quartic non-Abelian completion, finite
restoration/QAP, massive polarization, heat-regulated quantum equivalence,
phase/measure/source equivalence, finite matterC1,E5/A5 or physical matching.
zeta,b0,kappa remain separate/free. Shared action, assumptions, group data,
software and AI author limit independence; no external scientific validation.
All benchmark exclusions, singlet140% warning, flavorpause/HB1C5blocks,
quartetFAIL and custody limitations persist.

Next smallest justified question: calculate the actual parity-even cubic
and quartic pure-gauge fermion UV poles, independently of the two-point
Ward requirement, and compare their complete noncommuting trace words with
a separately normalized curvature calculation. This tests the remaining
marginal pure-gauge interaction class without a45^4 component expansion.
Finite evanescent/restoration amplitudes remain a separate obligation.
