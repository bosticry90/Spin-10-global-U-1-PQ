"""GEP1 actual Nambu pp trace and general-split-momentum tensor integral."""
from data import *
from itertools import product
start=begin('primary')
actual_action=(CAL/'canonical_so10_sterile_matter_action/ACTION_V1.md').read_text(encoding='utf-8')
assert 'D_phys = bar_gamma.partial_bar - ig bar_gamma A_a G^a' in actual_action and 'Every gauge and Yukawa vertex acts on P.' in actual_action
smp=read(CAL/'canonical_so10_sterile_massive_propagator/validation_receipt.json');assert smp['strict4D_and_massless_limits_match'] and not smp['case0_standard_massive_substitution_valid_at_finite_hats'] and not smp['case1_adopted_as_physical_scheme']
def tidy(mat):return s.SparseMatrix(mat).applyfunc(s.simplify)
def zero(mat):assert not tidy(mat).todok()
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];gamma=[s.kronecker_product(pa[1],mat) for mat in pa]+[s.kronecker_product(pa[0],s.eye(2))];PL=s.diag(1,1,0,0);PR=s.eye(4)-PL;projectors=[PL,PR]
# -Trlog(D)/2: the second variation is +Tr(S V S V)/2.
# V=-ig gamma A and S_pp=-i bar_slash/Q give phase(-i)^4=+1.
gaussian=s.Rational(1,2);phase=(-s.I)**4;assert phase==1
bartrace={};chiral_trace=[];cross_zero=0
for mu,al,nu,be in product(range(4),repeat=4):
 pair=[]
 for i,j in product(range(2),repeat=2):
  val=s.simplify(gaussian*phase*s.trace(gamma[mu]*projectors[i]*gamma[al]*gamma[nu]*projectors[j]*gamma[be]));pair.append(str(val))
  if i!=j:assert val==0;cross_zero+=1
 actual=s.simplify(s.sympify(pair[0])+s.sympify(pair[3]));target=2*(int(mu==al)*int(nu==be)+int(mu==be)*int(al==nu)-int(mu==nu)*int(al==be));assert actual==target;bartrace[mu,al,nu,be]=actual;chiral_trace.append(pair)
yct=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');T=list(map(dec,yct['Tminus']));H=dec(yct['H_new']);G=s.Matrix(45,45,lambda a,b:s.simplify(s.trace(T[a]*T[b])));GR=s.Matrix(45,45,lambda a,b:s.simplify(s.trace(T[a].T*T[b].T)));zero(G-GR);zero(G-G.T)
# The pp inverse and every physical vertex have only barred numerators.
# Thus mixed/hatted external gauge indices are exact bare-action zeros.
eps,L,x=s.symbols('epsilon L x');dim,Delta=s.symbols('d Delta',positive=True);u=x*(1-x);qb=s.symbols('qbar0:4');qh2=s.Symbol('hatq2');qbar2=sum(q*q for q in qb);Q2=qbar2+qh2;I2=s.Symbol('I2')
Jratio=s.gammasimp((dim/2)*s.gamma(1-dim/2)*Delta**(dim/2-1)/(s.gamma(2-dim/2)*Delta**(dim/2-2)));assert s.simplify(Jratio+dim*Delta/(dim-2))==0
J2=Jratio.subs(Delta,u*Q2)*I2
angular=s.Matrix(4,4,lambda mu,nu:s.expand(sum(bartrace[mu,al,nu,be]*(int(al==be)*J2/dim-u*qb[al]*qb[be]*I2) for al,be in product(range(4),repeat=2))))
rqq=s.factor(angular[0,1]/(qb[0]*qb[1]));rhat=s.factor(s.diff(angular[0,0],qh2));rbar=s.factor(s.expand(angular[0,0]).coeff(qb[1],2))
for mu,nu in product(range(4),repeat=2):assert s.simplify(angular[mu,nu]-(int(mu==nu)*(rbar*qbar2+rhat*qh2)+rqq*qb[mu]*qb[nu]))==0
rational=[s.factor((coef/(u*I2)).subs(dim,4-2*eps)) for coef in [rbar,rqq,rhat]]
# Exact MSbar-normalized meromorphic bubble, with QÂ²>0 as the off-shell scale.
regular_master=s.exp((s.EulerGamma+L)*eps)*s.gamma(1+eps)*s.gamma(2-eps)**2/s.gamma(4-2*eps);transverse=s.simplify(-rational[1]);finite=s.factor(rational[0]-transverse);hat=rational[2]
C=transverse*regular_master/eps;F=s.cancel(finite/eps)*regular_master;HH=hat*regular_master/eps
Cregular=transverse*regular_master;Hregular=hat*regular_master
Cjet=[s.simplify(s.diff(Cregular,eps,order).subs(eps,0)/s.factorial(order)) for order in range(3)];Fjet=[s.simplify(s.diff(F,eps,order).subs(eps,0)/s.factorial(order)) for order in range(2)];Hjet=[s.simplify(s.diff(Hregular,eps,order).subs(eps,0)/s.factorial(order)) for order in range(3)]
# Direct contraction of the measured tensor, before using any insertion.
ward=s.Matrix([s.factor(sum(qb[mu]*angular[mu,nu] for mu in range(4))) for nu in range(4)])
for nu in range(4):assert s.simplify(ward[nu]-qb[nu]*((rbar+rqq)*qbar2+rhat*qh2))==0
finish('primary',{'method':'actual_physical_Nambu_pp_trace_and_full_split_tensor_Feynman_integral','bar_trace_coefficients':[str(bartrace[key]) for key in product(range(4),repeat=4)],'chiral_bar_trace_coefficients':chiral_trace,'cross_chiral_trace_zeros':cross_zero,'G':enc(G),'SM_G':enc(H.T*G*H),'tensor_rational_coefficients':list(map(str,rational)),'form_factors_C_F_H':list(map(str,[C,F,HH])),'C_pole_finite_epsilon':list(map(str,Cjet)),'F_finite_epsilon':list(map(str,Fjet)),'H_pole_finite_epsilon':list(map(str,Hjet)),'UV_tensor_coefficients':[str(Cjet[0]),str(-Cjet[0]),str(Hjet[0])],'Ward_UV_barq2_hatq2':['0',str(Hjet[0])],'Ward_physical_finite':str(Fjet[0]),'three_family_bar_transverse_pole':enc(3*Cjet[0]*G),'three_family_hat_kinetic_pole':enc(3*Hjet[0]*G),'physical_spin_trace':4,'gaussian_factor':'1/2','closed_family_count':3,'external_hat_vertex_components':'ZERO_BY_SMA_ACTION','hat_rank_used':'d-4=-2epsilon','new_one_loop_two_point_families':1,'new_two_loop_integrals':0,'mass_dependent_polarization_computed':False,'physical_scheme_adopted':False},start)
