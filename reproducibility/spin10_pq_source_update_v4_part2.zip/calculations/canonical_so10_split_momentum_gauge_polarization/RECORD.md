# GEP1: actual general-split-momentum gauge polarization and Ward insertion

Previousgoalturn PROGRESS: MGN1 completed the five-family marginal fermion/
gauge UV vertex and fixed-normalization projection. Whole Spin10 x PQ goal
active/incomplete. Baseb41208cefb462c14fcd347ac6617463c4cbdd0aa/main30938blobs,
clean/no live matching workers. State113/authority34of39 unchanged.

Question: what is the missing mass-independent gauge kinetic pole at general
external q=(barq,hatq) in the actual provisional SMA1 charged/sterile action,
and does its contraction match the actual evanescent insertion? Physical
hatq=0 tests cannot determine a hatq² pole. This supplies a needed singular
subtraction input before dimensional/finite restoration is claimed.

Freeze SMA1 action/current/source and Nambu Gaussian conventions, SMP1 case0
inverse, YCT1 full45 odd-carrier generators/H frame, FSN1 normalization,
CSC1 selected charged/sterile contact and CPC1 historical comparison. MGN1
ordinary marginal result, FKP1 separate scalar hats, current AGENTS/charter/
local/solo policies are bound. Do not import the older conjugate-Nambu G+M
contact as the charged/sterile answer. No mass, Yukawa/flavor value, physical
benchmark, gauge width, regulator scheme or finite baseline is selected.

Domain: parity-even mass-independent leading kinetic family, external barred
vector indices, formal barq and hatq with Q²=barq²+hatq²>0, d=4-2eps. Hatted
rank is analytically d-4, never a positive finite witness dimension. This is
a specified translation-invariant dimensional/Feynman-parameter integral,
meromorphic near eps0; it is not an ordered heat trace or general QAP.
Positive Q² separates the massless bubble's IR endpoints. Physical massive
and mass-pole amplitudes remain separate; the model is not set massless.

Primary derives the physical Nambu pp trace with its half and both charged
chiralities, using barred numerator/full momentum denominator. It keeps
barq² delta,barq_mu barq_nu,hatq² delta separately and integrates the measured
numerator. All hatted external gauge vertices are absent in this action;
the other tensor components are structural zeros. Retain the exact scalar
Gamma/Beta form factors and relevant Laurent jets, not just physical poles.

Replay derives the actual full P/S free Ward defect from D(k)G-Gtilde D(p),
sews its two off-diagonal hatted insertion blocks with the full P/S inverse,
and contracts before angular integration. It retains both endpoint terms
and proves their odd Gaussian integrals vanish under this declared
translation-invariant prescription. Two-component sigma traces independently
fix the transverse form factor; no Ward target sets a missing amplitude.
The primary and replay cannot read peers or earlier two-point answers.

A separate verifier compares both results, actual color matrices/all zero
complements, all barred Lorentz coefficients, hatted tensor types and the
full linear Ward contraction. It compares physical limits with CSC1/FSN1
only after the new outputs exist, and constructs the negative measured
quadratic UV pole as a local singular subtraction. Distinguish bar-only
transverse and full-d transverse tensors; retain the complete evanescent
difference if using the latter, including cross/hat components. No finite
non-Abelian counterterm, contact baseline or source/measure theorem follows.

Controls: premature hat removal, wrong analytic h sign, missing one hatted
insertion block, endpoint omission before the line identity, witness-trace
inflation, missing Nambu half/extra half, wrong closed-family count, and the
old conjugate continuation. Report insensitive controls precisely. Keep
zeta,b0,kappa distinct/free. A disagreement fails; independently agreed
nonzero insertion remainder is retained, not fitted or called an anomaly.

Freeze eight sources/copies/inputs before primary/replay/verifier, sequential
native observed workers600s after imports each,8GiB sampled private cap,
350MiB launch floor,16MiB package. Fresh E4 readiness this logical goal turn,
expected custody exit2/seven NOTPASS; no fresh expensive historical science.
Preserve failed/unfinished evidence; corrections must be versioned.

Ceiling: this complete parity-even mass-independent two-point family and
linear insertion/singular-subtraction projection in the explicit provisional
dimensional domain. Not full massive polarization, finite physical scheme,
non-Abelian cubic/quartic restoration, quantum equivalence, QAP/measure/phase,
finite matter C1,E5/A5 or physical unification. Preserve all old evidence,
scalar exclusions/140% warning, flavor pause/HB1C5blocks/quartetFAIL/main/state.
No agents,branch/worktree,outreach/publication/push or foundational adoption.
Shared action,analytic premises,software,group data and AI author limit
independence. Demonstrated capability is the missing general-hat input and
an independently normalized insertion, not new generic BMHV physics.

Primary literature comparator: Belusca-Maito et al.,arXiv2004.14398v2,
https://arxiv.org/abs/2004.14398v2 Eq5.12 andSecs5.3/6. It motivates retaining
evanescent singular terms but supplies no model coefficient to the workers.

Prefreeze preparation stopped on the guessed unversioned FKP1 receipt path.
Actual inventory identifies validation_receipt_v2.json. Original preparer/
controller bytes and failure metadata are preserved externally and bound.
No source freeze or scientific worker had occurred. The corrected preparation
binds that actual qualified version; no input evidence or test is changed.
