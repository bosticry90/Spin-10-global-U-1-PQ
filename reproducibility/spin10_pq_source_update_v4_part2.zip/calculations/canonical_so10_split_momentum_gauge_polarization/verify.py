"""GEP1 exact split-tensor/insertion gate and measured quadratic subtraction."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for name,hsh in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(name))==hsh,name
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
def tidy(mat):return s.SparseMatrix(mat).applyfunc(s.simplify)
def zero(mat):assert not tidy(mat).todok()
def eq(a,b):assert s.simplify(s.gammasimp(s.sympify(a)-s.sympify(b)))==0
assert P['bar_trace_coefficients']==R['bar_trace_coefficients'] and len(P['bar_trace_coefficients'])==256 and P['cross_chiral_trace_zeros']==512
for key in ['G','SM_G','three_family_bar_transverse_pole','three_family_hat_kinetic_pole']:zero(dec(P[key])-dec(R[key]))
for key in ['form_factors_C_F_H','C_pole_finite_epsilon','F_finite_epsilon','H_pole_finite_epsilon','UV_tensor_coefficients','Ward_UV_barq2_hatq2']:
 assert len(P[key])==len(R[key])
 for a,b in zip(P[key],R[key]):eq(a,b)
eq(P['Ward_physical_finite'],R['Ward_physical_finite'])
G=dec(P['G']);zero(G-2*s.eye(45));Cjet=list(map(s.sympify,P['C_pole_finite_epsilon']));Fjet=list(map(s.sympify,P['F_finite_epsilon']));Hjet=list(map(s.sympify,P['H_pole_finite_epsilon']));eps,L=s.symbols('epsilon L');C,F,HH=map(s.sympify,P['form_factors_C_F_H']);eq(HH,C/2+F)
for nu in range(4):
 for rho in range(4):
  zero(dec(R['K_color_matrices'][f'{nu}_{rho}'])-2*int(nu==rho)*G);zero(dec(R['P_color_matrices'][f'{nu}_{rho}'])+2*int(nu==rho)*G)
assert R['free_inverse_positions_checked']==1024 and R['PS_Ward_defect_positions_checked']==256 and R['sewn_PP_positions_checked']==64 and R['endpoint_kernels_nonzero_before_integration'] and R['endpoint_integrals_retained_and_proved_odd']==2 and R['single_mixed_block_ratio']=='1/2'
# Construct the exact symbolic momentum tensor independently of a gauge choice.
q=s.Matrix(s.symbols('q0:6'));bar=s.diag(1,1,1,1,0,0);hat=s.eye(6)-bar;qb=bar*q;qh=hat*q;B2=(qb.T*qb)[0];H2=(qh.T*qh)[0];Q2=B2+H2;Tbar=B2*bar-qb*qb.T;Tfull=Q2*s.eye(6)-q*q.T
uv=s.sympify(P['UV_tensor_coefficients'][0])*Tbar+s.sympify(P['UV_tensor_coefficients'][2])*H2*bar;ct=-uv;ev=tidy(uv-Cjet[0]*Tfull);zero(uv+ct);zero(q.T*uv-Hjet[0]*H2*qb.T);zero(q.T*ct+Hjet[0]*H2*qb.T)
assert bool(ev.todok())
zero((bar*ev*bar).subs({q[4]:0,q[5]:0}));zero(hat*uv);zero(uv*hat)
# Three tensor carriers exhaust the parity-even rank2 barred two-point domain.
# Direct tensor contraction and the independently sewn insertion must agree.
polar=(C+F)*B2*bar-C*qb*qb.T+HH*H2*bar;ward=tidy(q.T*polar-(F*B2+HH*H2)*qb.T);zero(ward)
# Later physical-limit comparators: neither worker could read these answers.
cp=packed(CAL/'canonical_so10_chiral_polarization_contact/primary_tables.json.gz');cr=packed(CAL/'canonical_so10_chiral_polarization_contact/replay_tables.json.gz');csc=read(CAL/'canonical_so10_chiral_sterile_comparison/validation_receipt.json');fsn=read(CAL/'canonical_so10_fermion_statistical_normalization/validation_receipt.json')
assert csc['status']=='QUALIFIED_SELECTED_CHARGED_STERILE_TWO_POINT_FINITE_CONVERSION' and fsn['status']=='QUALIFIED_PARITY_EVEN_WEYL_GAUSSIAN_AND_MASSLESS_GAUGE_POLE_NORMALIZATION'
for a,b in zip(P['C_pole_finite_epsilon'],cp['transverse_coefficients_pole_finite_epsilon']):eq(a,b)
for a,b,c in zip(P['F_finite_epsilon'],cp['contact_coefficients_F0_F1'],cr['contact_coefficients_F0_F1']):eq(a,b);eq(a,c)
zero(3*Cjet[0]*G-s.sympify(fsn['beta_three_16_families'])*s.eye(45));M=dec(cp['M']);assert M.todok()
controls={'drop_external_hats_before_extraction':Hjet[0]!=0,'wrong_analytic_hat_sign_changes_physical_finite':Fjet[0]!=-Fjet[0],'omit_one_mixed_insertion_block':Fjet[0]!=Fjet[0]/2 and Hjet[0]!=Hjet[0]/2,'omit_endpoint_side_before_identity':R['endpoint_kernels_nonzero_before_integration'],'inflate_witness_trace':Cjet[0]!=2*Cjet[0],'omit_Nambu_half':Cjet[0]!=2*Cjet[0],'extra_half_after_Nambu':Cjet[0]!=Cjet[0]/2,'wrong_closed_family_count':bool((3*Cjet[0]*G-6*Cjet[0]*G).todok()),'old_conjugate_contact_member':bool((Fjet[0]*M).todok()),'full_d_transverse_without_evanescent_difference':bool(ev.todok())}
assert all(controls.values())
for obj in [P,R]:assert obj['physical_spin_trace']==4 and obj['gaussian_factor']=='1/2' and obj['closed_family_count']==3 and obj['external_hat_vertex_components']=='ZERO_BY_SMA_ACTION' and obj['hat_rank_used']=='d-4=-2epsilon' and obj['new_one_loop_two_point_families']==1 and obj['new_two_loop_integrals']==0 and not obj['mass_dependent_polarization_computed'] and not obj['physical_scheme_adopted']
assert R['witness_spin_trace']==8 and R['witness_to_physical_divisor']==2
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
# Store coefficient tensors, not a fictitious noninteger-dimensional matrix.
subtraction={'three_family_UV_bar_transverse':enc(3*Cjet[0]*G),'three_family_UV_hatq2_bar_metric':enc(3*Hjet[0]*G),'three_family_CT_bar_transverse':enc(-3*Cjet[0]*G),'three_family_CT_hatq2_bar_metric':enc(-3*Hjet[0]*G),'three_family_physical_finite_contact':enc(3*Fjet[0]*G),'relative_full_d_transverse_evanescent_coefficients':{'barbar_hatq2_metric':str(Hjet[0]-Cjet[0]),'barhat_qbar_qhat':str(Cjet[0]),'hatbar_qhat_qbar':str(Cjet[0]),'hathat_Q2_metric':str(-Cjet[0]),'hathat_qhat_qhat':str(Cjet[0])},'formal_hat_components_zero_by_actual_vertices':True,'six_dimensional_tensor_only_an_algebra_witness':True,'finite_transverse_baseline':'zeta_symbolic_unfixed','b0_kappa_zeta_not_identified':True}
raw=(json.dumps(subtraction,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'subtraction_tables.json.gz').open('xb') as handle:handle.write(blob)
print('RESULT '+json.dumps({'status':'QUALIFIED_GENERAL_SPLIT_MOMENTUM_GAUGE_KINETIC_POLARIZATION_AND_LINEAR_INSERTION','elapsed_after_imports':time.perf_counter()-start,'direct_color_positions_compared':2025+144+2*2025,'insertion_color_positions_checked':2*16*2025,'bar_trace_slots_compared':256,'cross_chiral_trace_zeros':512,'factorized_bar_momentum_coefficient_positions_covered':2025*16*11,'free_inverse_positions_checked':1024,'PS_Ward_defect_positions_checked':256,'sewn_PP_positions_checked':64,'physical_spin_trace':4,'witness_to_physical_divisor':2,'closed_family_count':3,'UV_coefficients_barq2_delta_barqq_hatq2_delta':P['UV_tensor_coefficients'],'three_family_physical_transverse_pole':'4*I45','three_family_hatted_kinetic_pole':'2*I45','linear_Ward_insertion_remainder':'0','quadratic_UV_subtraction_remainder':'0','H_pole_finite_epsilon':P['H_pole_finite_epsilon'],'physical_hat_zero_contact_matches_CSC1':True,'endpoints_retained_and_proved_odd':2,'controls':controls,'wrong_h_sign_control_is_leading_UV_pole_insensitive':True,'subtraction_packed_sha256':sha256(blob).hexdigest(),'subtraction_raw_sha256':sha256(raw).hexdigest(),'new_one_loop_two_point_families':1,'new_two_loop_integrals':0,'nonAbelian_finite_restoration_or_QAP_qualified':False,'mass_dependent_polarization_or_physical_matching_qualified':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
