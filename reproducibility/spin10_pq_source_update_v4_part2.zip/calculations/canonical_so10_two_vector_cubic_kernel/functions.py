"""VCK1 convergent finite-bubble spin derivatives and analytic-index limits."""
from data import *
def sck():
    old=load('vck_sck_data',CAL/'canonical_so10_spinzero_cubic_kernel/data.py');saved=sys.modules.get('data')
    try:
        sys.modules['data']=old;f=load('vck_sck_functions',CAL/'canonical_so10_spinzero_cubic_kernel/functions.py')
    finally:
        if saved is None:sys.modules.pop('data',None)
        else:sys.modules['data']=saved
    return old,f
def g1(r):
    t=r-1
    if r==0:return -mp.mpf(3)/4
    if abs(t)<mp.mpf('.1'):
        total=mp.mpf(0);n=1
        while True:
            total+=(-1)**(n+1)*t**n/(n*(n+2))
            if abs(t)**(n+1)/((n+1)*(1-abs(t)))<mp.power(10,-mp.mp.dps-8):return total
            n+=1
            if n>10000:raise ArithmeticError('G1_SERIES_CAP')
    return ((r*r/2-r)*mp.log(r)-r*r/4+r-mp.mpf(3)/4)/(t*t)
def xx_unit(v,left,right,md):
    def at(a):
        if a==0 or a==1:return mp.mpf(0)
        if left==0:logA=mp.log(right)+mp.log1p(-a);ratio=a*v/right
        elif right==0:logA=mp.log(left)+mp.log(a);ratio=(1-a)*v/left
        else:
            A=a*left+(1-a)*right;logA=mp.log(A);ratio=a*(1-a)*v/A
        return -2*(logA/2+g1(ratio)+mp.mpf(3)/4)/v
    return mp.quad(at,[0,mp.mpf('.5'),1],method='tanh-sinh',maxdegree=md,error=True)
def xy_unit(v,left,right,md):
    if right==0:
        return ((mp.log(v)-mp.log(left))/(v-left) if v!=left else 1/v),mp.mpf(0)
    def at(a):
        if a==0 or a==1:return mp.mpf(0)
        A=a*left+(1-a)*right;r=a*(1-a)*v/A;t=r-1
        if abs(t)<mp.mpf('.1'):
            value=mp.mpf(0);n=0
            while True:
                value+=(-t)**n/(n+2)
                if abs(t)**(n+1)/(1-abs(t))<mp.power(10,-mp.mp.dps-8):break
                n+=1
                if n>10000:raise ArithmeticError('XY_SERIES_CAP')
        else:value=(t-mp.log(r))/(t*t)
        return a*value/A
    return mp.quad(at,[0,mp.mpf('.5'),1],method='tanh-sinh',maxdegree=md,error=True)
def finite_units(m,md,fun):
    rs=[fun.bubble_unit(m[k],m[(k+1)%3],m[(k+2)%3],md) for k in range(3)]
    xx=xx_unit(m[0],m[1],m[2],md);yy=xx_unit(m[1],m[0],m[2],md);xy=xy_unit(*m,md)
    vals=[4*rs[0][0]+4*(xx[0]+xy[0]),4*rs[1][0]+4*(yy[0]+xy[0]),4*rs[2][0]-4*xy[0]+1/(3*m[2])]
    return vals,max(v[1] for v in rs+[xx,yy,xy])
def raw_vector_hard(e,jj):
    be=2-e;g3=mp.gamma(be-3)/mp.gamma(be);g2=mp.gamma(be-2)/mp.gamma(be);g1=mp.gamma(be-1)/mp.gamma(be)
    B22=mp.beta(4-be,4-be);B21=mp.beta(4-be,3-be);B20=mp.beta(4-be,2-be)
    H=mp.exp(mp.euler*e)*mp.gamma(1+e)*mp.exp(e*jj)
    pref=mp.exp(2*mp.euler*e)*mp.gamma(1+2*e)*mp.exp(2*e*jj)
    values=[2*(4-be/3)*g3*B22-mp.mpf(4)/3*g2*B22+4*g2*B21,
      (4-be/3)*g1*B20-mp.mpf(2)/3*g1*B21+4*g2*B21,
      -be*g1*B20/3-mp.mpf(2)/3*g1*B21-4*g2*B21]
    return [pref*values[0],pref*values[1]+((4-2*e)/6-4)*H/e,pref*values[2]+2*H/(3*e)]
def raw_scalar_hard(r,e):
    pref=mp.exp(2*mp.euler*e)*mp.gamma(1+2*e)
    orbital=pref*mp.beta(2+e,2+e)*mp.hyp2f1(1+2*e,2+e,4+2*e,1-r)/((2-e)*(1-e)*(1+e))
    cross=pref*mp.beta(1+e,1+e)*mp.hyp2f1(1+2*e,1+e,2+2*e,1-r)/(1-e)
    return [(4-2*e)*orbital-4*cross]
def contour(fun,N,den):
    radius=mp.mpf(1)/den;out=None
    for n in range(N):
        e=radius*mp.exp(2j*mp.pi*(n+mp.mpf('.5'))/N);values=fun(e)
        if out is None:out=[[mp.mpc(0)]*3 for _ in values]
        for a,v in enumerate(values):
            for k,power in enumerate([-2,-1,0]):out[a][k]+=v/e**power/N
    leak=max(abs(mp.im(v)) for row in out for v in row)
    return {'nodes':N,'denominator':den,'Laurent':[[mp.nstr(v.real,100) for v in row] for row in out],'imaginary_leak':mp.nstr(leak,20)}
