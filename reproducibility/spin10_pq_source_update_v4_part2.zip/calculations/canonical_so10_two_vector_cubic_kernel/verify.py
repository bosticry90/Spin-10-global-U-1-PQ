"""VCK1 separate complete-domain numerical, Laurent and source validation."""
from data import *
def main():
    start=begin('validation_preparation.json');mp.mp.dps=240
    def m(v):return mp.mpf(v)
    def error(a,b):return abs(a-b)/(1+abs(a)+abs(b))
    maxima={'positive':m(0),'soft':m(0),'soft_refinement':m(0),'Gamma':m(0),'quadrature':m(0),'native_reconstruction':m(0)}
    def check(a,b,key,tol):
        e=error(a,b);maxima[key]=max(maxima[key],e);assert e<m(tol),(key,mp.nstr(e,30),mp.nstr(a,30),mp.nstr(b,30))
    exact=packed(HERE/'primary_exact_tables.json.gz');A=packed(HERE/'primary_numeric_tables.json.gz');B=packed(HERE/'replay_positive_numeric_tables.json.gz')
    If=s.Function('Ifin')(x,y,z)
    target=[2*x*s.diff(If,x,3)/3+4*(s.diff(If,x,2)+s.diff(If,x,y)),2*y*s.diff(If,y,3)/3+4*(s.diff(If,y,2)+s.diff(If,x,y)),
      2*z*s.diff(If,z,3)/3-4*s.diff(If,x,y)+1/(3*z)]
    for k,v in enumerate([x,y,z]):
        row=exact['positive'][str(k)];value=s.sympify(row['Rprime_finite_Q1'],locals={'x':x,'y':y,'z':z,'Ifin':s.Function('Ifin')})
        assert clean(value-target[k])==0
        expected=s.Rational(10,3)/v if k<2 else -s.Rational(2,3)/v
        assert clean(s.sympify(row['scale_j'],locals={'x':x,'y':y,'z':z})-expected)==0 and row['remaining_overall_pole']=='0'
    assert exact['soft_vector']['Rprime_pole']==['-2/3','-2','2']
    assert exact['soft_vector']['soft_pole']==['2/3','2','-2']
    native=[]
    labels=[('primary','exact'),*[(v,'numeric') for v in ['primary','replay_positive','replay_scalar0','replay_scalar1','replay_vector']]]
    for label,phase in labels:
        c=json.loads((HERE/f'{label}_{phase}_capture.json').read_bytes());r=json.loads((HERE/f'{label}_{phase}_result.json').read_bytes())
        assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
        blob=(HERE/f'{r["role"]}_{r["kind"]}_tables.json.gz').read_bytes()
        assert sha256(blob).hexdigest()==r['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['tables_sha256']
        peak=max(v['private_bytes'] for v in c['all_resource_samples']);assert peak<=8*1024**3 and c['launch']['memory']['available_pagefile']>=350*1024**2 and r['elapsed_after_imports']<600
        native.append({'label':label,'phase':phase,'seconds':r['elapsed_after_imports'],'sampled_private_max':peak})
    assert A['dps']==110 and B['dps']==240
    for ci in range(3):
        aa=A['positive'][str(ci)];bb=B['positive'][str(ci)];assert aa['masses']==bb['masses'];assert m(bb['imaginary_leak'])<m('1e-80')
        h0,h1=aa['history'];assert [h0['maxdegree'],h1['maxdegree']]==[8,10]
        for h in [h0,h1]:assert m(h['error_estimate'])<m('1e-50')
        for v,w,z0 in zip(h0['finite'],h1['finite'],bb['finite']):
            check(m(v),m(w),'quadrature','1e-45');check(m(w),m(z0),'positive','1e-40')
    base=list(map(m,A['positive']['0']['history'][-1]['finite']));masses=[m('.5'),m(1),m(2)];factor=m(7)/5
    slope=[10/(3*masses[0]),10/(3*masses[1]),-2/(3*masses[2])]
    for v,w,c in zip(A['scaled_first'],base,slope):check(m(v),(w-c*mp.log(factor))/factor,'positive','1e-40')
    for v,w in zip(A['permuted_first'],[base[1],base[0],base[2]]):check(m(v),w,'positive','1e-40')
    assert m(A['scale_or_permutation_error_estimate'])<m('1e-50')
    def gamma_check(hist,targets):
        assert [(h['nodes'],h['denominator']) for h in hist]==[(48,32),(80,32),(80,64)]
        for h in hist:assert m(h['imaginary_leak'])<m('1e-80')
        for a,row in enumerate(targets):
            for k,w in enumerate(row):
                for h in hist:check(m(h['Laurent'][a][k]),w,'Gamma','1e-40')
    scalarK={}
    for ri in range(2):
        src=A['scalar_soft'][str(ri)];r=rat(src['ratio']);h0,h1=src['history']
        scalarK[ri]=m(h1['K']);K=(r+1)/(2*(r-1)**2)-r*mp.log(r)/(r-1)**3
        check(scalarK[ri],K,'positive','1e-40')
        for h in [h0,h1]:assert m(h['error_estimate'])<m('1e-50')
        for v,w in zip(h0['finite'],h1['finite']):check(m(v),m(w),'quadrature','1e-45')
        gamma_check(src['scalar_Gamma'],[[m(0),m(0),m(h1['finite'][2])]])
    for row in A['vector_soft']:
        jj=m(row['j']);gamma_check(row['Gamma'],[[m(0),-m(2)/3,m(1)/9-4*jj/3],[m(0),-m(2),m(5)/3-2*jj/3],[m(0),m(2),-2+10*jj/3]])
    changes={};soft_count=0
    for label in ['replay_scalar0','replay_scalar1','replay_vector']:
        tab=packed(HERE/f'{label}_numeric_tables.json.gz');assert tab['dps']==240
        vector=label=='replay_vector';ri=0 if vector else int(label[-1]);r=rat(tab['ratio']);previous=None
        assert [h['d'] for h in tab['histories']]==['1e-44','1e-50','1e-56']
        for h in tab['histories']:
            dd=m(h['d']);assert m(h['imaginary_leak'])<m('1e-80');allmatched=[]
            for rec in h['scales']:
                jj=m(rec['j']);nativev=list(map(m,rec['native']));ss=list(map(m,rec['soft']));matched=list(map(m,rec['matched']))
                bf=0 if r==1 else 1-r*mp.log(r)/(r-1);K=m(1)/6 if r==1 else (r+1)/(2*(r-1)**2)-r*mp.log(r)/(r-1)**3
                soft=[10*jj/(3*dd)+m(5)/9+m(2)/3*(2*jj-mp.log(dd)),2*(2*jj-mp.log(dd)),-2*(2*jj-mp.log(dd))] if vector else [m(0),m(0),-(2*(jj+bf)-1)/(3*dd)-2*K/3]
                if vector:want=[m(1)/9-4*jj/3,m(5)/3-2*jj/3,-2+10*jj/3]
                else:
                    want=list(map(m,A['scalar_soft'][str(ri)]['history'][-1]['finite']));want[0]+=10*jj/(3*r);want[1]+=10*jj/3
                for a,b,c,sv,targetv in zip(nativev,ss,matched,soft,want):
                    check(b,sv,'native_reconstruction','1e-80');check(a-b,c,'native_reconstruction','1e-50');check(c,targetv,'soft','1e-35');soft_count+=1
                allmatched.extend(matched)
                if vector:
                    omitted=[2*(2*jj-mp.log(dd)),2*(2*jj-mp.log(dd)),-2*(2*jj-mp.log(dd))]
                    assert all(abs(v)>1 for v in omitted)
                    changes['soft_vector_missing_curvature_min_abs_change']=str(min(abs(v) for v in omitted))
                    changes['soft_vector_missing_kinetic_finite_matched_change']='5/9'
                else:changes[f'scalar{ri}_missing_kinetic_matched_change']=mp.nstr(-2*K/3,70)
            if previous is not None:
                for a,b in zip(previous,allmatched):check(a,b,'soft_refinement','1e-35')
            previous=allmatched
    assert soft_count==54
    assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<6*1024**2
    out={'schema':'VCK1_VALIDATION','execution_state':'COMPLETED','status':'QUALIFIED_COMPLETE_TWO_VECTOR_CUBIC_F2_MATCHING_KERNEL',
      'positive_mass_domain':'x,y,z>0; all3 charge axes','positive_comparison_axes':9,'scalar_soft_ratios':['3/253','253/3'],
      'soft_vector_domain':'(d,1,1), vector-edge reversal included','soft_numeric_comparisons':54,
      'positive_overall_poles':['0','0','0'],'positive_scale':['10/(3*x)','10/(3*y)','-2/(3*z)'],
      'soft_vector_hard_overall_poles':['-2/3','-2','2'],'soft_vector_hard_finite_Q1':['1/9','5/3','-2'],
      'soft_vector_hard_scale':['-4/3','-2/3','10/3'],'soft_scalar_hard_third_axis':'2K(r)-4log(r)/(r-1)',
      'max_scaled_errors':{k:mp.nstr(v,35) for k,v in maxima.items()},'actual_omission_controls':changes,'native_runs':native,
      'third_derivative_evidence':'QUALIFIED_SCK1_OLD240_NATIVE120SIG_REUSED_NOT_RERUN',
      'full_model_VVS_amplitude_calculated':False,'full_C1_or_E5_qualified':False,'overall_counterterm_adopted':False,
      'scientific_acceptance':'NOT_PERFORMED','authority':'34/39_UNCHANGED',
      'shared_limits':['action','reference','master convention','qualified scalar third-derivative histories','software','AI authorship'],
      'elapsed_after_imports':time.perf_counter()-start}
    raw=(json.dumps(out,sort_keys=True,indent=2)+'\n').encode()
    with (HERE/'validation_receipt.json').open('xb') as f:f.write(raw)
    print('RESULT '+json.dumps({'status':out['status'],'receipt_filename':'validation_receipt.json','receipt_sha256':sha256(raw).hexdigest(),
      'elapsed_after_imports':out['elapsed_after_imports']},sort_keys=True),flush=True)
if __name__=='__main__':main()
