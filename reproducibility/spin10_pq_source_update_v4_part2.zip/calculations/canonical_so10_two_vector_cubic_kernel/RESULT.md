# VCK1: complete VVS spin kernel with both actual soft limits

Qualified receipt SHA256
bd7b5365bf612511c719600a55e2baea86b626d7fc0dcf83f76637ef03281c5a,
QUALIFIED_COMPLETE_TWO_VECTOR_CUBIC_F2_MATCHING_KERNEL. Scientific acceptance
NOT_PERFORMED;state113/authority34of39 unchanged. This supplies the universal
unit for the full VVS1 support, not the model-specific amplitude or full C1.

The two vector heat kernels contract as Tr(K1 K2^transpose), giving the spin
factor D+4g2 B2(q1*s-q2*t)^2. The cross sign and D=4-2eps are essential.
All15 background placements are represented by the covariant inverse/heat
construction. A separate Fourier spin expansion and orbital integration by
parts recover the same3 charge-axis kernels. Only the local F2 coefficient
in the fixed xi1 reference is claimed, not arbitrary gauge independence.

For positive squared masses(x,y,z), the proper-subtracted finite units are

    R1=2x Ifin_xxx/3+4(Ifin_xx+Ifin_xy),
    R2=2y Ifin_yyy/3+4(Ifin_yy+Ifin_xy),
    R3=2z Ifin_zzz/3-4Ifin_xy+1/(3z).

Remaining poles are zero; scale slopes are(+10/(3x),+10/(3y),-2/(3z)).
These signs correct the opposite UNQUALIFIED slopes proposed in VVK1 NEXT.
They follow from2*barepole+forestpole and independent bubble scale dependence,
not a fitted scale choice. The scalar1/(3z) comes from the CLOSED vector
bubble's finite dimensional remnant. An early-D4 bare calculation shifts the
finite terms by-1/m_axis while leaving that pole diagnostic insensitive.

For a soft scalar(r,1,d), the actual soft scalar-axis contribution is
-[2(j+Bfin)-1]/(3d)-2K/3. Both the mass term,including the closed-vector
constant, and the finite kinetic term are retained. The matched scalar-axis
hard value is2K(r)-4log(r)/(r-1), with zero pole/scale log. The two heavy
axes are convergent positive-bubble limits at scalar mass0. At r3/253,
the hard finite units are approximately(281.7498738215661,20.46915764071647,
-17.02469451689916). These are universal unit coefficients,not observables.
Both actual mass-role ratios3/253 and253/3 were checked. At equal masses the
hard scalar value tends-11/3, rather than the scalar-spin kernel times4.

For a soft vector(d,1,1), the hard matched kernel has

| charge axis | Remaining pole | Finite j0 | Scale slope |
| --- | ---: | ---: | ---: |
| light vector | -2/3 | 1/9 | -4/3 |
| heavy vector | -2 | 5/3 | -2/3 |
| scalar | 2 | -2 | 10/3 |

These overall local poles are retained for the parent assembly. Positive
mass proper-subgraph pole cancellation does not remove the hard/EFT poles.
The independently opened heavy bubble has mass,kinetic and linear-curvature
coefficients. Closing it on the actual soft vector gives soft poles(2/3,2,-2)
and finite((10j)/(3d)+5/9+(2/3)(2j-log d),2(2j-log d),-2(2j-log d)).
The second j comes from O(eps) hard coefficients multiplying remaining poles.
Dropping the curvature term changes logarithms/poles; dropping the finite
kinetic contribution shifts the matched light-axis constant by5/9.

The hard heat time integrals were derived before analytic continuation through
Gamma/Beta factors and independently checked with elementary finite-bubble
asymptotics. The vector heat equation was used on Reeps>0,d>0 before
continuation; no universal unregulated rule Tr1=0 or scaleless discard was
assumed. Keep the full family forest before soft cancellation and the actual
matched poles; no overall counterterm or physical finite prescription is chosen.

Primary numerical method:110digit finite-bubble quadrature,refinements8/10,
and uncombined Gamma contours48/80nodes at radius1/32 plus80 at1/64.
Replay:240digit OLD dilog/direct second and mixed mass derivatives, with
qualified SCK1 OLD240 third-derivative histories reused at their recorded
120significant native digits. They were not recomputed or treated as fresh
240digit printed evidence. All3 positive cases/9axes and54 soft comparisons
at d1e-44/50/56 and j0/2/7 pass. Homogeneity/vector-role reversal also pass.

Max scaled positive error1.7024e-111,soft error4.8173e-43,soft successive
change4.8173e-43,Gamma change4.6709e-58,native reconstruction1.1106e-64.
Zero reported quadrature refinement is equality at the serialized precision,
not a proof of exact numerical integration. The analytic identities supply
the general-domain argument; sampled values do not prove all-g accuracy.

3407initial/3417numeric/3435validation bindings. Exact4.2837s,primarynumeric
19.5664s,replaypositive24.8624s,actualscalarsoft1.5323/1.5440s,softvector
4.2661s,verifier1.0255s. Sequential exclusive runs,600s caps,8GiB sampled
private/350MiB launch floor/6MiBpackage. Native private samples<53MB. No
scientific/controller/verifier failure,timeout,cancellation or native truncation.
A read-only missing-filename lookup was corrected; no frozen input changed.

TrackB shows reuse of qualified expensive derivatives while independently
measuring the new spin terms and detecting wrong provisional scale signs.
Methods share action,reference,master convention,scalar histories,software
and AI authorship; no external scientist,Lean or empirical validation is claimed.
Physical scalar-control/matching warnings and historical custodyexit2/seven
NOTPASS remain. Next: every actual spectral unit and complete VVS assembly,
not another selected coefficient or unrelated E1 tensor expansion.
