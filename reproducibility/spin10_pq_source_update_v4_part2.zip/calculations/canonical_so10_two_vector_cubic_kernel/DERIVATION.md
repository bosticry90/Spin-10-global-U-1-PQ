# VCK1 proposed complete dimensional derivation, frozen before evaluation

## Spin, orbital transport and positive masses

At the actual H-covariant symmetric cubic, three Wilson phases cancel.
For one normalized magnetic plane F12=B and charge matrices with eigenvalues
iq_i, q1+q2+q3=0, the two vector propagators contract as Tr(K1 K2^transpose).
Their spin product is exp(2igF(q1*s-q2*t)). Through B2 its trace is
D+4g2 B2(q1*s-q2*t)^2. Retain D-2 spectator directions. This uses the actual
vector Hessian -Dbar2 delta-2gT F, not a spin-zero loop counted D times.

The qualified scalar orbital coefficient is Ei=-ti2/6-ti2*tj*tk/(3U),
U=st+su+tu. Decomposing the full D*sum qi2 Ei+4(q1*s-q2*t)^2 gives
(D E1+4s2+4st,D E2+4t2+4st,D E3-4st). The independent Fourier inverse has
scalar orbital term -G3+2p_plane2 G4 and vector spin terms2gTF G2,
4g2 T2 Fmatrix2 G3. Contracting Lorentz indices gives self8qi2 G_i3
and cross-8q1q2 G_12 G_22. Rotational averaging p_plane2=2p2/D and integration
by parts recover the same heat axes. With I the bare sunset the differential
operators are ((4-D)/2+4)Ixx+4Ixy+2x Ixxx/3, its y exchange, and
(4-D)Izz/2-4Ixy+2z Izzz/3. These represent the15 inverse/connection words,
not15 different nonzero amplitudes. No constant A or zero-momentum shortcut.

Use authenticated Ibare=-sum v/(2eps2)+[sum A0(v)-sum v/2]/eps
+Ifin+sum Ae(v), A0=v(log v-1), Ae=v[-1-zeta2/2+log v-log2(v)/2].
Actual opened bubbles have momentum-independent UV pole1/eps for an outer
vector and4/eps for an outer scalar (closed vector Lorentz trace). All
background and momentum derivatives of those bubbles have negative UV degree.
Thus forests per charge axis are (D/6-4)H_x/(x eps), its y exchange, and
2H_z/(3z eps), with H_v=exp(gamma eps)Gamma(1+eps)(Q2/v)^eps.
This is a graph-local minimal pole grouping, not a physical finite scheme.
It predicts the positive units in RECORD and zero remaining overall poles.
The scalar1/(3z) is the closed-vector D/eps remnant, not adjustable.

Independent convergent finite-bubble representations at Q2=1 are
Rscalar_x=(1/x)int da du u(1-u)log[A+C*u/(1-u)],
Ifin_xx=-(2/x)int da du u log[A+C*u/(1-u)],
Ifin_xy=int da du a*u/[A(1-u)+C*u], A=ay+(1-a)z,C=a(1-a)x.
The last follows from the positive mixed mass derivative, which has no poles;
the second follows by subtracting the actual bubble pole before D4. The
inner integrals are elementary; numerical work need only1D quadrature.
Positive units are4Rscalar_x+4(Ifin_xx+Ifin_xy), y exchange and
4Rscalar_z-4Ifin_xy+1/(3z). This is independent of dilog differentiation.
Lambda_VVS=+3g10^4/2 times the ordered charge-weighted units, from Wick-1/4,
physical F2=2B2 and Lambda=-12Gamma_F2/(ell2*g10^2). No extra ghost sign.

## A soft scalar with two positive vectors

For(x,y,z)=(r,1,d), the opened two-vector bubble has Lorentz multiplicity
D: after its4/eps pole subtraction, its zero-momentum coefficient is
4(j+Bfin)-2 and kinetic coefficient-4K. Here j=log(Q2/y),
Bfin=1-r log(r)/(r-1), K=int a(1-a)/[1+(r-1)a]. Closing on the soft scalar
uses TrG_F2=-H_d/(6d), TrG(-Dbar2)_F2=H_d/6. Both follow from the actual
heat boundary on Reeps>0,d>0 before analytic continuation. Hence the soft
scalar-charge contribution is -[2(j+Bfin)-1]/(3d)-2K/3, including its finite
kinetic term. Other charge axes have no surviving scalar-soft closure.

Integrating the hard scalar heat time first gives D times SCK's uncombined
Gamma/Beta/hypergeometric expression, finite2K, minus4Ixy(r,1,0).
The latter integrates exactly to log(r)/(r-1): integrate the zero-mass
Schwinger time, then s+t and its fraction. Thus the hard scalar unit is
2K-4log(r)/(r-1); it has no pole or scale log. Positive heavy-axis bubbles
converge with inner scalar mass0. Keep full regulated forest before matching.

## A soft vector with equal positive vector/Goldstone masses

For(x,y,z)=(d,1,1), opening the heavy vector/scalar bubble gives
Sigma_mass=H_1/eps, Sigma_kinetic=-H_1/6, Sigma_F=-g T2 F H_1.
The last sign comes from K2^transpose. Its pole is only the mass1/eps;
kinetic and curvature terms are finite but must retain their O(eps) factors
when closing on a UV-divergent remaining loop. Put
H_1=1+eps*j+..., H_d=1+eps*(j-log d)+..., B_d=1/eps+j-log d+... .

The actual vector heat equation gives, in B2 units,
TrGv_F2=q1^2(4-D/6)H_d/d and
TrGv(-Dbar2)_F2=q1^2[(D/6-4)H_d+8B_d]. To prove the latter, use
(-Dbar2)K=-partial_t K+2gT1 F K; its F2 boundary at t0 is zero for Reeps>0,
not an unregulated universal claim Tr1=0. The linear bubble closes as
-4q1q2 H_1 B_d. Mass forest is the negative soft-vector trace/eps.
After that proper subtraction, charge-axis soft poles are(2/3,2,-2) and
finite terms are
((10j)/(3d)+5/9+(2/3)(2j-log d), 2(2j-log d), -2(2j-log d)).
The second j is from O(eps) hard coefficients, not a scale fit. Terms with
higher derivatives/curvature vanish as powers d times logarithms in the soft
expansion; the hard complement is separately integrated, not discarded.

Directly integrate the hard light-vector heat time using
int_0^infty ds s^n/(A*s+B)^b = B^(n+1-b) A^(-n-1)
Gamma(n+1)Gamma(b-n-1)/Gamma(b), continued from its convergent strip.
With beta=2-eps, A=t+u, B=tu, subsequent massive-time integration gives
exp(2gamma eps)Gamma(1+2eps). The remaining fraction integrals are
Beta(4-beta,4-beta), Beta(4-beta,3-beta), Beta(4-beta,2-beta).
All separate terms/orderings remain in the exact and numerical records.
Hard bare poles=(-2/3,4/3,4/3), finite(1/9,2,-2) at j0; remaining-heavy
forests are0,(D/6-4)H_1/eps,2H_1/(3eps). Matched Rprime therefore has
poles(-2/3,-2,2), finite(1/9,5/3,-2), slopes(-4/3,-2/3,10/3).
These local overall poles remain for parent assembly; do not remove them here.

A separate finite-bubble asymptotic check follows from elementary integrals:
at(d,1,1), Ifin_xx=(log d)/3-7/18+O(d log d),
Ifin_xy=-(log d)/2+1/2+O(d log d), Ifin_yy->0;
Rscalar_soft=1/18 at j0 after its leading mass term, while the two heavy
Rscalar axes tend-1/12. These establish the same full finite asymptotics
and hard-minus-soft constants without assigning values from cancellation.
The equal-mass soft mass term is insensitive at j0, so j2/7 is mandatory.

This construction addresses only the actual VVS unit/reference. It does not
prove a general IR regulator theorem, full parent renormalization or gauge
independence. No finite physical contact baseline is adopted or identified
with historical kappa/b0. The historical provisional scale slopes in VVK1
NEXT were opposite; they were unqualified notes, not an accepted theorem.
