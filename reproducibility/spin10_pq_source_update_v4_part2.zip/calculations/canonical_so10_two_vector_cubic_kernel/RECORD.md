# VCK1: complete two-vector/one-scalar cubic F2 kernel

Base3fcfe61f452f3002cdf493b9c2b9abf741843c48/main, clean preflight and no
live workers. Previous goal turn PROGRESS: complete VVS1 support/VVK1 charge
operators and spectral transport. Goal ACTIVE/incomplete; state113/34of39.

Question: what are the actual dimensional VVS kernels, proper forests and
matched one-soft limits required by the full30-profile support? Cheapest
competent test: heat/Fourier tensor derivation, exact Laurent algebra and
independent finite-bubble/master comparisons. No new large component tensor.
Use same C1 linearRxi xi1 action/point/reference, actual symmetric S vertex,
Wick-1/4 and15 background placements. Preserve physical reality, ordered color
roles and all3 squared-charge axes. No new scheme/point or fitted correction.

Domain: positive squared masses(x,y,z), vector edges1/2 and scalar edge3;
soft scalar(r,1,d) for actual ratios3/253 and253/3; soft vector(d,1,1), and
vector-edge reversal. Common auxiliary d>0 before Laurent expansion/limit.
Actual VVS1 excludes all multiply-soft/all-light assignments. No ghost
no-light theorem or scalar-spin multiplicity shortcut. Existing master and
SCK qualifications are inherited inputs, not fresh independent physics.

Freeze this record, DERIVATION, sources and complete qualified transitive
inputs before computation. Exact stage must derive spin trace from a magnetic
Lorentz plane plus D-2 spectators; compare Fourier self/cross spin insertions,
orbital integration by parts and all three charge axes. Extract all bare and
proper-forest Laurent coefficients, retaining D=4-2eps on remaining loops
and D4 only in CLOSED vector UV poles. Keep Ae and MSbar factors. Verify
scale slopes from2*barepole+forestpole instead of historical provisional notes.

Expected candidate conclusions (to test, not fit): positive Rprime pole0,
R1=2x Ifin_xxx/3+4(Ifin_xx+Ifin_xy), R2 its vector exchange,
R3=2z Ifin_zzz/3-4Ifin_xy+1/(3z). Scale(+10/(3x),+10/(3y),-2/(3z)).
Scalar-soft hard scalar axis2K(r)-4log(r)/(r-1), other axes positive finite
bubbles with z0, all poles0. Soft-vector matched poles(-2/3,-2,2), finite
(1/9,5/3,-2) at j0 and slopes(-4/3,-2/3,10/3). Its soft contributions must
be independently derived from opened vector/scalar bubble, including mass,
kinetic and linear-curvature terms. No missing finite constant may be chosen
to make agreement. Preserve overall hard poles for eventual parent assembly.

Exact analytic acceptance also requires uncombined Gamma/Beta derivation of
the hard limits and finite-bubble asymptotic proof, not only numerical limits.
Then freeze a numerical contract with positive3-case/all-axis comparisons,
actual two scalar-soft ratios plus equal-heavy soft-vector domain, multiple
deltas and scales. Primary finite bubbles/analytic-index contours; replay
OLD master second/mixed derivatives plus authenticated SCK OLD240 third-
derivative histories. Reuse is disclosed; do not rerun expensive qualified
third derivatives without scientific need. Keep shared inputs/software/AI.

Negative controls: early D4, missing closed-vector finite remnant, wrong
spin cross orientation, omitted scalar-soft kinetic term, omitted soft-vector
linear-curvature term or kinetic finite contribution, wrong scale signs and
omitted forest. Report insensitive pole projections separately from finite
sensitivity. A wrong proposed formula fails, it does not authorize fitting.

600s per exact/numeric/verifier stage,8GiB sampled private,350MiB launch floor,
6MiB entire package; sequential exclusive captures and resources. Freeze new
phases rather than edit old sources or retry over outputs. Native limit/failure
is INCOMPLETE/FAILED, not evidence of a theorem. Validate completed work before
local commit; preserve all26659 old tracked blobs, all failures and state.

Authority ceiling: universal VVS unit in the specified reference/graph-local
matching domain, not actual full-model spectral amplitude, family5 completion,
parent-minus-family/overall counterterm, C1, gauge unification or E5/A5. No
protected activation/publication/push; director acceptance NOT_PERFORMED.
