"""VCK1 Lorentz spin, Fourier/heat identities and actual soft forests."""
from data import *
def main():
    start=begin('preparation.json');U=st*tt+st*ut+tt*ut;times=[st,tt,ut];masses=[x,y,z]
    F=s.Matrix([[0,1],[-1,0]]);a=s.symbols('a',real=True)
    spin=lambda q,t:s.eye(2)+2*s.I*q*t*F+(2*s.I*q*t)**2*F**2/2
    b=s.symbols('b',real=True)
    tr=s.expand(s.trace(spin(q1,b*st)*spin(q2,b*tt).T)+D-2)
    assert clean(tr.coeff(b,2)-4*(q1*st-q2*tt)**2)==0 and tr.coeff(b,0)==D
    Ei=[-v**2/6-v**2*times[(i+1)%3]*times[(i+2)%3]/(3*U) for i,v in enumerate(times)]
    heat=axes(D*sum(q*q*v for q,v in zip([q1,q2,q3],Ei))+4*(q1*st-q2*tt)**2)
    wanted=[D*Ei[0]+4*st**2+4*st*tt,D*Ei[1]+4*tt**2+4*st*tt,D*Ei[2]-4*st*tt]
    assert all(clean(v-t)==0 for v,t in zip(heat,wanted))
    # Fourier spin self and cross terms independently follow from inverse powers.
    spinfour=axes(4*q1*q1*st**2+4*q2*q2*tt**2-8*q1*q2*st*tt)
    for i,tau in enumerate(times):
        others=[v for v in times if v!=tau]
        orbital=-D*tau**2/2+D*tau**3*(others[0]+others[1])/(3*U)
        assert clean(orbital+spinfour[i]-heat[i])==0
    If=s.Function('Ifin')(x,y,z)
    A0=lambda v:v*(s.log(v)-1)
    Ae=lambda v:v*(-1-s.zeta(2)/2+s.log(v)-s.log(v)**2/2)
    bare=-(x+y+z)/(2*eps**2)+(sum(A0(v) for v in masses)-(x+y+z)/2)/eps+If+sum(Ae(v) for v in masses)
    def op(I,k,dim):
        v=masses[k];base=(4-dim)*s.diff(I,v,2)/2+2*v*s.diff(I,v,3)/3
        return base+(4*s.diff(I,v,2)+4*s.diff(I,x,y) if k<2 else -4*s.diff(I,x,y))
    targets=[2*x*s.diff(If,x,3)/3+4*(s.diff(If,x,2)+s.diff(If,x,y)),
      2*y*s.diff(If,y,3)/3+4*(s.diff(If,y,2)+s.diff(If,x,y)),2*z*s.diff(If,z,3)/3-4*s.diff(If,x,y)+1/(3*z)]
    positive={};controls={}
    for k,v in enumerate(masses):
        bb=jet(op(bare,k,4-2*eps));H=1+eps*(j-s.log(v))
        ct=jet(((4-2*eps)/6-4)*H/(v*eps) if k<2 else 2*H/(3*v*eps))
        # Bare graph carries two scale factors, forest only the remaining loop.
        rp=[clean(bb[n]+ct[n]) for n in range(3)];rp[2]=clean(rp[2]+2*j*bb[1])
        slope=clean(2*bb[1]+ct[1]);want=s.Rational(10,3)/v if k<2 else -s.Rational(2,3)/v
        assert rp[0]==rp[1]==0 and clean(rp[2]-targets[k]-slope*j)==0 and slope==want
        positive[str(k)]={'heat':str(heat[k]),'bare_Laurent_Q1':list(map(str,bb)),'forest_Laurent':list(map(str,ct)),
          'Rprime_finite_Q1':str(targets[k]),'scale_j':str(slope),'remaining_overall_pole':'0'}
        controls[str(k)]={'early_D4_bare_finite_change':str(clean(jet(op(bare,k,4))[2]-bb[2])),
          'missing_forest_pole':str(bb[1]),'wrong_provisional_scale_change':str(-2*slope)}
    assert clean(targets[2]-(2*z*s.diff(If,z,3)/3-4*s.diff(If,x,y)))==1/(3*z)
    # Hard soft-vector time integration: raw Beta/Gamma factors and recurrences.
    be=2-eps;g3=1/((be-1)*(be-2)*(be-3));g2=1/((be-1)*(be-2));g1=1/(be-1)
    B22=(1+eps)**2/((1+2*eps)*(2+2*eps)*(3+2*eps))
    B21=(1+eps)/((1+2*eps)*(2+2*eps));B20=(1+eps)/(eps*(1+2*eps))
    hard=[2*(4-be/3)*g3*B22-s.Rational(4,3)*g2*B22+4*g2*B21,
      (4-be/3)*g1*B20-s.Rational(2,3)*g1*B21+4*g2*B21,
      -be*g1*B20/3-s.Rational(2,3)*g1*B21-4*g2*B21]
    hb=[jet((1+2*eps*j)*v) for v in hard]
    hf=[[0,0,0],jet(((4-2*eps)/6-4)*(1+eps*j)/eps),jet(2*(1+eps*j)/(3*eps))]
    hp=[-s.Rational(2,3),-2,2];hfin=[s.Rational(1,9)-4*j/3,s.Rational(5,3)-2*j/3,-2+10*j/3]
    for k in range(3):assert hb[k][0]==hf[k][0]==0 and clean(hb[k][1]+hf[k][1]-hp[k])==0 and clean(hb[k][2]+hf[k][2]-hfin[k])==0
    # Independently OPEN the equal-heavy bubble before its soft-vector closure.
    Hm=1+eps*j;Hd=1+eps*(j-s.log(d));Bd=1/eps+j-s.log(d);dim=4-2*eps
    mass=(4-dim/6)*Hd*(Hm-1)/(d*eps)*q1**2
    kinetic=-Hm*((dim/6-4)*Hd+8*Bd)*q1**2/6
    curvature=-4*q1*q2*Hm*Bd
    sa=axes(mass+kinetic+curvature);sj=[jet(v) for v in sa]
    sp=[s.Rational(2,3),2,-2]
    sf=[10*j/(3*d)+s.Rational(5,9)+s.Rational(2,3)*(2*j-s.log(d)),2*(2*j-s.log(d)),-2*(2*j-s.log(d))]
    for k in range(3):assert sj[k][0]==0 and sj[k][1]==sp[k] and clean(sj[k][2]-sf[k])==0 and hp[k]+sp[k]==0
    assert axes(-4*q1*q2)==[2,2,-2]
    # Independent elementary finite-bubble asymptotics establish all constants.
    L=s.symbols('logd',real=True);Rsc=[s.Rational(1,18),-s.Rational(1,12),-s.Rational(1,12)]
    Ixx=L/3-s.Rational(7,18);Ixy=-L/2+s.Rational(1,2);Iyy=0
    full=[4*Rsc[0]+4*(Ixx+Ixy),4*Rsc[1]+4*(Iyy+Ixy),4*Rsc[2]-4*Ixy+s.Rational(1,3)]
    sfinite=[s.Rational(5,9)-2*L/3,-2*L,2*L]
    assert [clean(a-b) for a,b in zip(full,sfinite)]==[s.Rational(1,9),s.Rational(5,3),-2]
    # Scalar-soft opened D-vector bubble and its nonzero kinetic closure.
    bf,kk=s.symbols('Bfin K',real=True)
    scalar=jet(-Hd*(dim*(1/eps+j+bf)-4/eps)/(6*d)-dim*kk/6)
    assert scalar[0]==scalar[1]==0 and clean(scalar[2]+(2*(j+bf)-1)/(3*d)+2*kk/3)==0
    r=s.symbols('r',positive=True);K=(r+1)/(2*(r-1)**2)-r*s.log(r)/(r-1)**3;lr=s.log(r)/(r-1)
    s3hard=2*K-4*lr;assert s.limit(s3hard,r,1)==-s.Rational(11,3)
    inv=load('vck_inventory',CAL/'canonical_so10_background_threshold_inputs/inventory.py');summary,words=inv.build('primary')
    assert ['VVS','-1/4',15] in summary['families']
    out={'schema':'VCK1_EXACT','positive':positive,'controls':controls,'Lorentz_spin_trace_B2':str(4*(q1*st-q2*tt)**2),
      'soft_vector':{'hard_rational_Gamma_reduction':list(map(str,hard)),'bare_hard_Laurent':[[str(v) for v in row] for row in hb],
        'heavy_forest_Laurent':[[str(v) for v in row] for row in hf],'Rprime_pole':list(map(str,hp)),
        'Rprime_finite':list(map(str,hfin)),'soft_pole':list(map(str,sp)),'soft_finite':list(map(str,sf)),
        'omitted_curvature_pole_change':['-2','-2','2'],'omitted_kinetic_finite_change':'-5/9'},
      'soft_scalar':{'soft_scalar_axis_finite':str(scalar[2]),'hard_scalar_axis_finite':str(s3hard),'equal_mass_hard':'-11/3',
        'pole':'0','scale':'0','omitted_kinetic_finite_change':str(-2*kk/3)},
      'Lambda_VVS_prefactor':'+3*g10^4/2','background_words':words['VVS'],'scientific_acceptance':'NOT_PERFORMED',
      'authority':'34/39_UNCHANGED','full_model_VVS_amplitude_calculated':False,'full_C1_or_E5_qualified':False}
    save('primary','exact',out,start)
if __name__=='__main__':main()
