# VCK1 full numerical comparison and acceptance

Freeze this contract and sources after the completed exact stage; no exact
output is read as a numerical answer. Primary fixed110digits,1D finite-bubble
quadrature maxdegree8/10 with error/refinement records. Positive cases
(1/2,1,2),(1,1,1),(2,3,7), all3 axes. Homogeneity at common factor7/5 and
vector-edge reversal on the first case. Scalar-soft actual ratios3/253 and
253/3, two heavy-axis bubble limits plus uncombined Gamma/hypergeometric
scalar hard integration. Soft-vector equal-heavy case uses uncombined
Gamma/Beta hard integration plus actual remaining-heavy forests. Three
contours48/80nodes at radius1/32 and80nodes at1/64, scales j0,2/7.

Replay fixed240digits uses OLD dilog master/direct second and mixed mass
derivatives. Already-qualified SCK1 OLD240 third-derivative native values
are authenticated and reused:9 positive axes, and all3axes at d1e-44/50/56
for both scalar-soft ratios and the permuted equal-heavy soft-vector case.
Do not pretend those reused values are fresh derivatives or240digit outputs:
SCK stored120significant native digits and80matched digits. Subsequent
large1/d cancellations must occur at240digits before new120/80digit output.
The reused precision leaves over60decimal places even at d1e-56. The only
fresh derivative work is the independently needed spin second/mixed terms.

Separate sequential workers: primary, replay_positive, replay_scalar0,
replay_scalar1, replay_vector. Compare finite positive/soft and scales at
scaled1e-35; soft successive-limit changes1e-35; positive1e-40; quadrature
refinement1e-45 and estimates1e-50; Gamma refinement1e-40; imaginary leak
1e-80. Retain all native values/subtractions and recompute them in validator,
not merely compare printed matched results. Verify each hard pole plus soft
pole reproduces the positive overall pole, with finite and log terms separate.

Actual opened scalar/vector mass,kinetic and linear-curvature terms must all
be present. Omit controls cannot pass by a convenient j0 mass projection:
also compare j2/7, actual unequal scalar-soft ratios, kinetic finite constants
and curvature logarithms. Native remaining hard poles are not fitted away.

600s each worker/verifier,8GiB sampled private,350MiB launch floor,6MiB
package; exclusive sequential captures, no silently changed precision/cache.
All shared action/reference/master/third-derivative histories/software/AI
authorship disclosed. Universal kernel only; no model amplitude,C1 orE5/A5.
