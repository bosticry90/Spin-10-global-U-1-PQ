"""VCK1 immutable input, exact and bounded numerical utilities."""
from pathlib import Path
from hashlib import sha256
import json,gzip,sys,time,threading,os,importlib.util
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
eps,D,d,j=s.symbols('eps D d j',real=True);st,tt,ut=s.symbols('s t u',positive=True);x,y,z=s.symbols('x y z',positive=True)
q1,q2,q3=s.symbols('q1 q2 q3',real=True)
def clean(v):return s.cancel(s.expand(v))
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def load(n,p):
    spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def begin(prep):
    start=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for p,h in json.loads((HERE/prep).read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
    return start
def save(role,kind,v,start):
    raw=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/f'{role}_{kind}_tables.json.gz').open('xb') as f:f.write(blob)
    print('RESULT '+json.dumps({'role':role,'kind':kind,'elapsed_after_imports':time.perf_counter()-start,
      'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)
def jet(v):
    v=s.series(v,eps,0,1).removeO().expand();return [clean(v.coeff(eps,k)) for k in [-2,-1,0]]
def axes(P):
    v=s.Poly(clean(P.subs(q3,-q1-q2)),q1,q2);cross=v.coeff_monomial(q1*q2)/2
    return [clean(v.coeff_monomial(q1*q1)-cross),clean(v.coeff_monomial(q2*q2)-cross),clean(cross)]
def rat(v):
    r=s.Rational(v);return mp.mpf(int(r.p))/int(r.q)
