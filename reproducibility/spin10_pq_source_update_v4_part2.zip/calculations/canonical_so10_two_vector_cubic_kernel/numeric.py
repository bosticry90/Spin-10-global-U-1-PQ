"""VCK1 independent finite-bubble/Gamma and OLD master spin-term comparisons."""
from functions import *
CASES=[['1/2','1','2'],['1','1','1'],['2','3','7']];RATIOS=['3/253','253/3']
def fmt(v,n=120):return mp.nstr(v,n)
def primary():
    old,fun=sck();positive={};soft={}
    for ci,c in enumerate(CASES):
        m=list(map(rat,c));history=[]
        for md in [8,10]:
            values,error=finite_units(m,md,fun);history.append({'maxdegree':md,'finite':list(map(fmt,values)),'error_estimate':fmt(error,20)})
        positive[str(ci)]={'masses':c,'history':history}
    m=list(map(rat,CASES[0]));scaled=list(map(lambda v:v*mp.mpf(7)/5,m));sv,se=finite_units(scaled,10,fun);pv,pe=finite_units([m[1],m[0],m[2]],10,fun)
    for ri,rt in enumerate(RATIOS):
        r=rat(rt);hist=[]
        for md in [8,10]:
            rs1,e1=fun.bubble_unit(r,1,0,md);rs2,e2=fun.bubble_unit(1,r,0,md)
            xx,ex=xx_unit(r,1,0,md);yy,ey=xx_unit(1,r,0,md);xy=mp.log(r)/(r-1)
            K,eK=mp.quad(lambda a:a*(1-a)/(1+(r-1)*a),[0,mp.mpf('.5'),1],maxdegree=md,error=True)
            vals=[4*rs1+4*(xx+xy),4*rs2+4*(yy+xy),2*K-4*xy]
            hist.append({'maxdegree':md,'finite':list(map(fmt,vals)),'K':fmt(K),'error_estimate':fmt(max(e1,e2,ex,ey,eK),20)})
        gammas=[contour(lambda e:raw_scalar_hard(r,e),N,den) for N,den in [(48,32),(80,32),(80,64)]]
        soft[str(ri)]={'ratio':rt,'history':hist,'scalar_Gamma':gammas}
    vector=[]
    for jj in [mp.mpf(0),mp.mpf(2)/7]:
        vector.append({'j':fmt(jj),'Gamma':[contour(lambda e:raw_vector_hard(e,jj),N,den) for N,den in [(48,32),(80,32),(80,64)]]})
    return {'method':'finite_renormalized_bubble_and_uncombined_Gamma','dps':mp.mp.dps,'positive':positive,'scalar_soft':soft,
      'vector_soft':vector,'homogeneity_factor':'7/5','scaled_first':list(map(fmt,sv)),'permuted_first':list(map(fmt,pv)),
      'scale_or_permutation_error_estimate':fmt(max(se,pe),20)}
def replay(which):
    old=load('vck_old_data',CAL/'canonical_so10_spinzero_cubic_kernel/data.py');master=old.old_master()
    def fresh(m,rs):
        vals=[];leak=mp.mpf(0)
        for ind in [(2,0,0),(0,2,0),(1,1,0)]:
            v=master.imaster_derivative(tuple(map(str,m)),ind);leak=max(leak,abs(mp.im(v)));vals.append(mp.re(v))
        xx,yy,xy=vals
        return [4*rs[0]+4*(xx+xy),4*rs[1]+4*(yy+xy),4*rs[2]-4*xy+1/(3*m[2])],leak
    src=CAL/'canonical_so10_spinzero_cubic_kernel'
    if which=='replay_positive':
        tab=packed(src/'replay_positive_numeric_v1_tables.json.gz')['data'];out={}
        for ci,c in enumerate(CASES):
            m=list(map(rat,c));rs=[mp.mpf(v['value']) for v in tab[str(ci)]['axes']];values,leak=fresh(m,rs)
            out[str(ci)]={'masses':c,'finite':list(map(fmt,values)),'imaginary_leak':fmt(leak,20)}
        return {'method':'OLD_direct_second_mixed_plus_qualified_OLD240_thirds','dps':mp.mp.dps,'positive':out}
    vector=which=='replay_vector';idx=1 if vector else 2+int(which[-1]);rt='1' if vector else RATIOS[int(which[-1])];r=rat(rt)
    tab=packed(src/f'replay_soft{idx}_numeric_v1_tables.json.gz')['data'];assert tab['ratio']==rt
    out=[]
    for hist in tab['histories']:
        dd=mp.mpf(hist['d']);m=[dd,mp.mpf(1),mp.mpf(1)] if vector else [r,mp.mpf(1),dd]
        rs=[mp.mpf(v['scales'][0]['native']) for v in hist['axes']]
        if vector:rs=[rs[2],rs[0],rs[1]]
        values,leak=fresh(m,rs);scales=[]
        bf=0 if r==1 else 1-r*mp.log(r)/(r-1)
        K=mp.mpf(1)/6 if r==1 else (r+1)/(2*(r-1)**2)-r*mp.log(r)/(r-1)**3
        for jj in [mp.mpf(0),mp.mpf(2)/7]:
            full=[values[0]+10*jj/(3*m[0]),values[1]+10*jj/(3*m[1]),values[2]-2*jj/(3*m[2])]
            soft=[10*jj/(3*dd)+mp.mpf(5)/9+mp.mpf(2)/3*(2*jj-mp.log(dd)),2*(2*jj-mp.log(dd)),-2*(2*jj-mp.log(dd))] if vector else [0,0,-(2*(jj+bf)-1)/(3*dd)-2*K/3]
            matched=[a-b for a,b in zip(full,soft)]
            scales.append({'j':fmt(jj),'native':list(map(fmt,full)),'soft':list(map(fmt,soft)),'matched':[fmt(v,80) for v in matched]})
        out.append({'d':hist['d'],'imaginary_leak':fmt(leak,20),'scales':scales})
    return {'method':'OLD_direct_second_mixed_plus_qualified_OLD240_thirds','dps':mp.mp.dps,'domain':'vector_soft' if vector else 'scalar_soft',
      'ratio':rt,'histories':out,'third_derivative_source':'QUALIFIED_SCK1_NATIVE120SIG_AT240WORKING_REUSED_NOT_RERUN'}
def main():
    which=sys.argv[1];assert which in ['primary','replay_positive','replay_scalar0','replay_scalar1','replay_vector']
    start=begin('numeric_preparation.json');mp.mp.dps=110 if which=='primary' else 240
    out=primary() if which=='primary' else replay(which);save(which,'numeric',out,start)
if __name__=='__main__':main()
