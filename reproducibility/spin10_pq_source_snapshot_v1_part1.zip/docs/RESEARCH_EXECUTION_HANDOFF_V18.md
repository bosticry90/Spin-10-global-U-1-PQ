# Research execution handoff, V18

Navigation supersedes V17, not authority. Baseline93ef4f0. Recover Git/processes
and [the checkpoint](A10_E5_AUXILIARY_VERTEX_CURRENT.md). Before seal select
frozen_a10_e5_joint_normalization/bindings.json; afterward explicitly select
frozen_a10_e5_auxiliary_vertex/bindings.json. Generic preflight/e5 remains an
older bounded delegate, not current scientific acceptance.

Complete selected g*xi^2 Lambda-ubar-C pole gives a first failure of the joint
candidate's previously unmatched cubic. All49,005 tensor entries compare,
888 nonzero differences. Actual coefficient48sqrt(10)/25 vs8sqrt(10)/5 at real
Lambda0,bar1,ghost14; Lambda Euler difference8sqrt(10)/25 thetaBar thetaGhost.
No boundary/EOM excuse or new primitive adoption. Other prior projections
and qualified physical/classical BV evidence keep their declared scopes.

Primary six graded Born words eachi/6, replay explicit Gaussian pairings,
two distinct internal ghost labels, full mixed inverse and all4 Lorentz
weights. Triangle and full648-quartic bubble give G=-2(T+B). Keep projected
nonsymmetric heavy matrices; do not use a false adjoint closure. The tested
2 A kappa shortcut has776 residual coefficients and is excluded.

External-antighost derivative triangle is UV degree-1. The720 Lambda BH BM
bosonic triangle has an exactly zero BH/heavy-Lambda edge; light-antighost
alternatives have zero H/M ghost edges. Three-cubic 1PI counting requires
one external per vertex. All other quartics are screened:648 atgxi,17480 atg^2,
418 atg^2xi. Nonnegative coupling degree excludes the last two from gxi^2.
No auxiliary elimination or hidden width/physical-mass cancellation.

UV Taylor only on k_E^2>R_UV^2, with negative-degree momentum remainder.
Triangle/bubble heat profiles6/4 retain distinct finite split terms. No whole
massless zero-momentum, full finite amplitude, IR/anomaly/restoration claim.

Next smallest increment: derive whether the measured antisymmetric difference
admits an H-compatible cubic gauge-fixing primitive in the allowed types/ring,
preserve old matching and qualify its quartic descendants. A primitive is
not quantum A5 or permission to adopt it. JC-C-C/JB-B-C stay stopped pending
reconciliation. Freeze its contract; stop on first failed/undefined requirement.

Preserve failed quartic-inventory auditor and native-integer test preflights.
Ordinary g^2 quartics are recorded, not deleted; exact SymPy test input is
required. Production/completed primary/replay bytes unchanged. Before receipt
take seal_a10_e5_auxiliary_vertex.py --process-snapshot, then
export_a10_e5_auxiliary_vertex_receipt.py.397 tests, two strict own-byte routes,
29 parents, all protected/state/new SHA and metadata. No edits during audit.
Seal, compare index/raw bytes, whitespace check, commit locally only. Keep
the archived-CRLF per-path Git attribute and all historical failed evidence.

All643 pairs,48 backgrounds,34 physical/nine source terms, physical parameters,
potential/vacuum, xi/R_H stay. Statev113/34of39 and custody2/seven unchanged;
custody not PASS. No activation/catalog/HB1/C5/C1_GS/matching, publication/push
or outside contact. Full E5/A1–A5, IR/anomalies/global boundedness/PQ quotient,
fermion/Yukawa/phenomenology remain open. Whole Spin(10)xglobal U(1)PQ goal
active/incomplete. Shared inputs/software/analyst; solo review. A validated
normalization counterexample is progress, not proof of a defective physical model.
