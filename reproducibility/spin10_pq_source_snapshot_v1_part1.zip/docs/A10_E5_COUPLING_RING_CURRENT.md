# E5 coupling-ring scope checkpoint

Navigation only; project_state.json remains the scientific authority.

The new [result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_COUPLING_RING_RESULT.md)
and [derivation](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_COUPLING_RING_DERIVATION_V1.md)
qualify a polynomial coupling-tangent obstruction in the unrestricted full
complex and a basic representative for its coupling-weighted family. The raw
obstruction fails the actual conditional background Ward requirement. It is
not a missing quantum-counterterm-class result or a full E5 PASS.

Use frozen_a10_e5_coupling_ring/bindings.json for explicit preflight after
sealing. audit_a10_e5_coupling_ring.py --fresh reruns only the new routes.
Generic research_check.py e5 retains its older checkpoint delegation.

Next: qualify Ward/basic-preserving nonminimal contraction, then the minimal
ring/primitive comparison. No inverse coupling is adopted. A1-A5 stay open.
Preserve all pairs, authority 34/39, custody exit 2/seven references, inactive
status and solo review. The overall completion goal remains active/incomplete.
