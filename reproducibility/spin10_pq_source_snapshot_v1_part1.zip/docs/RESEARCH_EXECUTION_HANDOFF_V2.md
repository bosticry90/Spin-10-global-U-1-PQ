# Research execution handoff, V2

This explanatory navigation record supersedes V1 for new work; it is not a
scientific ledger. Recover Git, live processes and actual evidence first.
The baseline for this increment is clean `76affe5`, qualified inactive D–E4,
authority 34/39, M08 blocked, finite C1_GS null and custody exit 2/seven bindings.
The old README immediate-decision text is byte sealed and remains historical.

Use [local conventions](LOCAL_RESEARCH_CONVENTIONS_V1.md) and
`python -B tools/research_check.py e4` for the existing authenticated checkpoint.
The new E5 contract and bounded result distinguish full retained-source joint
domain closure from literal counterterm coverage. Read their actual receipt
and auditor before accepting their classification. Once E5 is sealed,
`python -B tools/research_check.py e5` selects it explicitly; COMPLETED describes
delegated execution, including authenticated scientific stopping results.

E5 cannot be promoted solely because the proposed domain is closed. Its
source-renormalization control tests a dimension-four BRST-exact deformation
outside literal horizontality. An exact-term quotient or restricted Ward
renormalization target needs explicit justification. The next smallest
scientific task is that policy/equivalence proof, not a counterterm catalog.
The restricted 607-field domain equivalence and complete adequacy/descent
obligations remain unqualified unless the bounded result proves otherwise.

All historical actions, D–E4 artifacts, source definitions, potential
parameters and catalogs remain frozen. No activation, HB1/C5, quantum matching,
authority adjustment, publication, personal contact or push follows. Reuse
sealed evidence through byte authentication; disclose shared inputs, arithmetic,
Python/SymPy and analyst. Unfinished or canceled execution never supplies PASS.
