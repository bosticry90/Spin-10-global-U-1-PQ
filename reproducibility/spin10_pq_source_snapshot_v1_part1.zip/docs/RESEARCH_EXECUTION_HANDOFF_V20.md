# Research execution handoff, V20

Navigation supersedesV19, not authority. Recover Git/processes with preflight.
Before seal authenticate frozen_a10_e5_cubic_primitive/bindings.json; afterward
explicitly select frozen_a10_e5_quartic_companion/bindings.json. Read the actual
quartet result/current checkpoint and its versioned contract. Statev113/34of39,
whole goal active/incomplete; custody2/seven, not PASS.

Complete actual g^2*xi^2 quartet independently agrees across all980,100 slots,
6,576 nonzero. Frozen K0+Kjoint+K3 has4,944 and misses5,528. Real witness
antighost pair(12,13), ghost pair(12,13):16/25 actual,-16/25 candidate,
32/25 difference, nonzero left antighost Euler. First scientific failure of
this complete tested normalization. Keep the actual residual and all zeros.

The cubic primitive and its prior matching remain qualified/inactive. All
previous physical/classical/source/ghost/mixing/width scopes remain. No model,
anomaly, full Ward/A5/E5 or unification conclusion follows from this bounded
normalization failure. No new JC-C-C/JB-B-C loops or normalization adoption.

Actual calculation includes all6 box words,6 mixed triangle words,3 ordinary
g^2 B^2-ghost triangle words and full graded bubble. Full BB/BL/LB/LL=0 and
both odd starts, arbitrary widths, nonsymmetric matrices, all quartic splits
and4 Lorentz weights retained before exact contraction. Source/background0
is only this amplitude. Physical even/scalar/mass alternatives have explicit
external-incidence/edge/negative-UV-degree exclusions. No auxiliary elimination.

Boxes0 is exact: heavy f_M is a three-form; odd skew U,V give transpose and
odd cyclic trace cancellation. No false projected-adjoint closure. Ordinary
triangle7,170 nonzero slots; mixed5,908; bubble3,960; overlaps cancel to6,576.
Keep E1 heat profiles8/6/4 and UV Taylor only above R_UV>0. No full finite/IR
amplitude or whole scaleless zero-momentum prescription.

Replay geometry uses normalized physical10 commutators/H projectors and its
own literal crosscheck. Candidate is read only after actual routes agree.
Direct Euler symbols check even L derivatives after odd factors. The first
completed replay failed that parity rule; preserve its tensor/source and full
disagreement, excluded from qualification. Two canceled performance attempts,
schema precheck and failed comparison also stay. No edited/overwritten evidence.

Next smallest authorized derivation: classify allowed normalization types and
their exact image on the residual, retaining all earlier matches; independently
justify any added freedom and derive its companion amplitudes before loops.
Do not solve a mismatch by arbitrary coefficients or treat a new right section
as full quantum normalization. Keep source/Ward/measure/jet obligations.

Receipt owns executed checks/fresh own-byte routes/31 parents/protected/new/
state SHA and metadata. Validate before local commit; preserve raw archived
bytes and compare Git index/worktree bytes. Shared data/software/analyst; solo
review, no external endorsement. No activation/catalog/HB1/C5/C1_GS/matching,
state promotion, outside contact, publication or push. Broader global scalar,
PQ quotient, fermion/Yukawa/phenomenology and full quantum obligations stay open.
