# E5 ghost companion checkpoint

Navigation only; project_state.json remains the sole scientific authority.
Baseline e15219a, state v113/34of39. The full Spin(10)xglobal U(1)PQ goal is
active/incomplete. The supplied ab2b63a assessment is historical context;
the repository's later source/regulator evidence is preserved and reused.

The complete selected g*xi ghost kinetic logarithm is zero. Both mixed bubble
assignments and all648 quartic coefficients are retained. The prior ghost-only
image predicts a nonzero -kappa kinetic pairing, so that restricted ansatz
fails. This is not a failure of the qualified classical action/BV system.
Earlier matched source projections remain qualified within their scope.

See [the result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_GHOST_COMPANION_RESULT.md),
[the contract](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_GHOST_COMPANION_CONTRACT_V1.md),
and [the receipt](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_ghost_companion/validation_receipt.json).
The signed provisional +8 q_E^2 witness in original JSONs is superseded by
the direct Euler adjudication: -8 Box C -> -8 q_E^2 C. Original bytes remain.
The position-space matrix mismatch and nonzero Euler conclusion are preserved.

The cutoff power and finite term are retained separately from the zero pole.
An opposing free ghost/antighost/auxiliary scaling is a control, not an adopted
joint normalization. Stop before the other companion vertices. Next: derive
joint typed normalization and B-Lambda/width companions, retaining measure,
source and Ward/Slavnov obligations. No automatic restoration or full E5 PASS.

Explicit preflight selects frozen_a10_e5_ghost_companion/bindings.json after
seal. Generic preflight/e5 remains an older bounded delegate. Validation:
357 targeted tests, two fresh own-byte routes, independent quartic/Lorentz/
witness checks,27 predecessors, protected/new/state hashes and metadata.
Custody2/seven remains unresolved. Failed comparator/canceled supplemental
audit preserved, excluded. No activation/catalog/HB1/C5/C1_GS, authority
promotion, outside contact, publication or push. Shared software/data/analyst.
