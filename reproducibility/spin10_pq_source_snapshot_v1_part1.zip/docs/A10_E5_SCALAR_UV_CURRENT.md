# Current E5 scalar UV and symmetric width checkpoint

Read the [bounded result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_SCALAR_UV_RESULT.md)
and its contract. It supplies ordinary g=0 scalar UV membership of the actual
34-parameter potential, four kinetic metrics and separate vacuum normalization,
not a complete quantum target. Two routes match 331 potential second-variation
graph coefficients, 66 coupled norm-family coefficients and a 1120 mixed
complex coefficient in the existing zK direction. The accepted invariant-basis
character/rank evidence is authenticated, not recomputed.

The full 561-parameter symmetric H-width ansatz has exact nullity five. Rational
elimination and independent Cartan/raising connectivity agree. Five constant
spectral forms span it and contain the preceding ghost pole. Their full QPsi,
Q^2Psi and local background Ward checks retain all composite/nonsymmetric terms.
No frozen gauge-fixing fermion or physical coupling is altered.

Use the new explicit manifest after sealing:

    python -B tools/research_session_preflight.py --manifest tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_scalar_uv/bindings.json

For authentication use audit_a10_e5_scalar_uv.py under the established guard;
--fresh regenerates only these two new routes. Full receipt execution uses
export_a10_e5_scalar_uv_receipt.py after a process snapshot, once only.
The generic research_check.py e5 delegates the older bounded audit, not this
new scientific calculation. Checksums do not establish mathematical acceptance.

Formal authority is v113/34 of 39. Strict custody still exits 2/seven. Full E5,
M2--M5/all A1--A5, nonzero-g restoration, physical IR, general source-dependent
insertions and weighted gF quantum A5 equivalence are open. The next increment
is the bounded regulator-breaking/restoration and source-identity test. No
activation, catalog replacement, HB1/C5, C1_GS, matching, push or outreach.
