# Research execution handoff, V23

Navigation supersedes V22; sole authority remains project_state.json v113,
34/39. Preflight actual Git/processes with the explicit nonminimal-source
manifest after seal, or shear-space manifest before seal. Read the new V1
contract/result/current checkpoint. Whole goal active/incomplete; custody2/seven.

Complete actual g^2 xi nonminimal-source pole agrees in all 91,125 slots,
776 physical nonzero/236 raw canonical coefficients. Source is even (2,0,0).
Light -Jbar b and other linear source terms have zero second field derivative;
derive this from the model, not a textbook heavy-antighost equation. Nonlinear
heavy Jubar C_H ubar survives. Unique triangle uses light derivative ghost,
xi auxiliary, two distinct H/M ghost inverses and mixed B-Lambda. Bubble
g xi quartic cannot consume C_H through an anti_H edge. Full reference,
four Lorentz copies, currents, all source/anti/ghost directions and UV-only
R>0 scope remain. No whole scaleless or finite/IR result.

Primary literal tensor/Born and replay physical10/Casimir/Wick agree.
T_h=-ad_H projected, A_j=ad_M projected, C=-sum T_h^2 gives source matrix
-(C A_j+A_j C-A_Cj). Only true H-M covariance is used, never M-adjoint closure.
All twelve H identities, real/evaluation-dual frames and roundtrips pass.

Actual calculations never read the affine solution. After actual agreement,
old full source projection is zero and the source equations have rank39.
The previously saved 15-coefficient quartet representative matches unchanged;
all 39 kernel coordinates are uniquely zero. Extra K has236/QK11,780; total
inactive generator506/candidate54,823 with the old current. All980,100 quartet
and earlier matched scopes remain. It is not an adopted subtraction or quantum
A5. The combined flow is formal at one-loop; shear exact inverse and old joint
regulated measure keep their scopes, with no false finite combined inverse.

Preserve failed floating Lorentz precheck: integer division introduced502
floating coefficients/roundoff, with full source, attempt and diagnostic.
Corrected exact rational scaling recomputes inputs; no evidence rounded or
edited. Old elementary function bytes are unchanged and rechecked. Receipt
owns tests, fresh own-byte actual routes/comparison,34 parents/protected/new/
state SHA and metadata. Authenticate old expensive loops/125 images, don't
repeat them. Verify raw index/worktree bytes before local commit.

Next smallest authorized action: new prospective actual derivative-gauge and
auxiliary-cubic companion contract against this unique complete member. Keep
all coupling orders/reference-width graph contributions, both sectors and
graded blocks. First mismatch stops with exact real Euler evidence. No other
new or JC-C-C/JB-B-C amplitudes ran here; source matching does not unlock all
Ward/contact/restoration or physical matching. Keep shared inputs/software/
analyst and solo-review limits explicit, without external personnel requirements.

No physical/catalog activation, HB1/C5/C1_GS, authority promotion, outreach,
publication/push. Full E5/A5/Ward/IR/anomaly, scalar/PQ global, fermion/Yukawa/
phenomenology remain open. Do not shrink the original Spin(10) x U(1)PQ goal.
