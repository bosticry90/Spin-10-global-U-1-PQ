# Current complete-Hessian and finite-loop checkpoint

Read the [bounded result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_FULL_HESSIAN_RESULT.md)
and its contract. The complete E2 action has 391 physical differential graphs
and 354,321 source/gauge-fixing Hessian coefficients, independently matched.
All 643 integrated fields, 643 external sources and 48 backgrounds remain.
The full reference inverse retains auxiliaries and correct odd signs.

The heat-regulated one-loop Born family is UV finite at each finite formal
order on the stated Wick/IR domain. The actual nonexceptional xi ghost loop
is evaluated exactly. A nonlinear retained-source control matches nonzero
Slavnov variation to its breaking insertion. Full nonzero-g restoration,
general probes/contacts, quantum A5, physical IR and E5 remain unproved.

Before sealing select frozen_a10_e5_nonzero_regulator/bindings.json; afterward:

    python -B tools/research_session_preflight.py --manifest tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_full_hessian/bindings.json

audit_a10_e5_full_hessian.py authenticates this checkpoint; --fresh runs two
logical routes/four artifacts. Generic research_check e5 remains an older
bounded delegate. Neither command promotes scientific authority.

Next: actual nonzero-g one-loop local Ward/ST breaking/restoration and
insertion/contact normalization with the complete retained-source Hessian.
State v113/34 of39 remains unchanged; custody exit2/seven unresolved.
No activation, catalogs, HB1/C5, C1_GS, physical matching, outreach or push.
