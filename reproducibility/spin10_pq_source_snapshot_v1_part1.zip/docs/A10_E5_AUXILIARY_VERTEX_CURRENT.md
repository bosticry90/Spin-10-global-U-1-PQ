# E5 auxiliary cubic checkpoint

Navigation only; project_state.json is sole scientific authority.
Baseline93ef4f0, statev113/34of39,29 parents. Whole goal active/incomplete.

Actual g*xi^2 Lambda-ubar-C pole is complete within its selected scope.
Both graded Born and Gaussian/Wick routes agree on triangle and full quartic
bubble tensors. All49,005 entries compare;888 differ from the inactive joint
candidate. Real coefficient witness:48sqrt(10)/25 actual vs8sqrt(10)/5 candidate,
difference8sqrt(10)/25 with nonzero Lambda Euler derivative. First failure.

Previously qualified source/ghost/mixing/width projections, Stage D–E4 and
physical action/adapters remain preserved. No additional primitive is adopted.
The difference is antisymmetric in Lambda/antighost slots; next investigate
its possible H-compatible cubic fermion normalization and quartic descendants.
JC-C-C/JB-B-C loops remain unexecuted after this stop.

See [the result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_AUXILIARY_VERTEX_RESULT.md),
[the contract](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_AUXILIARY_VERTEX_CONTRACT_V1.md),
and [the receipt](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_auxiliary_vertex/validation_receipt.json).

UV Taylor is only in the UV region; no scaleless zero-momentum IR verdict.
720 Lambda-BH-BM terms vanish through the zero H/M mixed edge;648 g*xi
quartics retained. Other quartics are explicitly screened by coupling degree.
Simple2 A kappa compression fails; preserve its776-coefficient residual.
Failed quartic-inventory audit and exact-test input are archived/excluded.

Validation:397 targeted tests, two own-byte fresh routes,29 predecessors,
protected/new/state hashes and size/mtime metadata. Explicit preflight uses
frozen_a10_e5_auxiliary_vertex/bindings.json after seal; generic e5 remains
an older bounded delegate. Custody2/seven is unresolved. No full E5/A5,
activation/catalog/HB1/C5/C1_GS/matching, authority change, outreach/push.
Shared data/software/analyst; solo review, no external endorsement.
