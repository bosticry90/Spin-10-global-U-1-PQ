# GW231123 competing-explanation comparison

## Snapshot and authority

Snapshot date: 2026-09-23.

This is an anomaly-attribution case study, not a project physics result. The
LIGO–Virgo–KAGRA collaboration reports GW231123 as an exceptionally massive,
short signal. Its O4a lensing search identified it as the sole individual
event with notable lensing support while emphasizing that gravitational-wave
lensing has not yet been established observationally. The dedicated embedded
macro-plus-microlens analysis reports about `2.6 sigma` preference under its
model, a lensed source mass of roughly `100–180 M_sun`, and about `55%`
conditional probability of another detectable macro-image.

## Comparison matrix

| Explanation | Stage | What it explains | Current support and dependency | Discriminating predictions |
| --- | --- | --- | --- | --- |
| Macro-magnification plus wave-optics microlensing | Propagation | Apparent distance, inflated source-frame mass, spin/waveform discrepancies, and frequency-dependent distortion | Dedicated analysis favors its lens model at about `2.6 sigma`; depends on the embedded point-mass/macrolens model and mass-sheet assumptions | A delayed counter-image with consistent detector-frame masses and sky localization; lens galaxy/structure; coherent frequency-dependent transfer function across detectors |
| Hierarchical mergers in dense clusters | Source | Components in/above the pair-instability region and high spins from previous merger remnants | Several population calculations can reproduce such systems; conclusions depend strongly on cluster retention, spin priors, waveform inference, and population model | A population-level mass–spin–redshift pattern, cluster/AGN host demographics, merger remnants and rates; no required repeated lensed image |
| Primordial black holes with cosmological accretion | Source/new population | Large masses and spins from smaller primordial seeds | Published model can fit the event, but its required parameter space is near X-ray/CMB exclusions and the event alone does not identify a primordial origin | O5/next-generation mass–spin correlations, high-redshift population, rates consistent with CMB/X-ray limits |
| Two overlapping coherent signals | Detector/inference mixture | Waveform-model disagreement and biased single-source parameters | A flexible two-signal analysis reports Bayes factors around `10^2–10^4`, but the values are within the upper few percent of its background and can be mimicked by lensing or noise artifacts | Recover two coherent sky-consistent signals; cross-detector timing and morphology; persistence under injections, alternate waveform families, and nonstationary-noise models |
| Waveform systematics or nonstationary detector noise | Detector/inference | Short-signal parameter instability and apparent frequency features | LVK notes the signal is only about a tenth of a second and urges caution; support in both detectors disfavors one simple single-detector glitch but does not exhaust systematics | Calibration/noise marginalization, waveform convergence, off-source injections, and stable inference under independent detector subsets |
| Unusual isolated stellar/Pop-III evolution or direct collapse | Source | Large first-generation masses and spins without prior mergers | Some models can construct candidates, while a self-consistent 2026 population comparison found isolated Pop-III binaries failed its merger-redshift/rate requirements | Host metallicity/redshift distribution, electromagnetic environment, population rates and spins |

These alternatives are not mutually exclusive. A hierarchical binary could
also be lensed; an overlapping-signal model can absorb lensing-like
distortions; and waveform systematics can affect the inferred evidence for
every source model.

## Present disposition

```text
GW231123_ATTRIBUTION = OPEN
LENSING = INTRIGUING_NOT_UNAMBIGUOUS
NEW_FUNDAMENTAL_PHYSICS = NOT_ESTABLISHED
DARK_MATTER_LENS_IDENTITY = NOT_ESTABLISHED
```

The highest-value near-term discriminator is a consistent counter-image or
independent lens identification. Population accumulation in O5 and robust
two-signal/noise injection studies are complementary rather than secondary.

## Primary sources

- [LVK O4a lensing search summary](https://ligo.org/science-summaries/O4aLensing/)
- [Goyal, Villarrubia-Rojo, and Zumalacárregui, embedded macro/microlensing analysis](https://arxiv.org/abs/2512.17631)
- [Hu et al., overlapping-signal analysis](https://arxiv.org/abs/2512.17550)
- [Angeloni et al., Population III versus hierarchical formation](https://doi.org/10.1051/0004-6361/202660148)
- [Li et al., successive-merger interpretation](https://arxiv.org/abs/2507.17551)
- [De Luca, Franciolini, and Riotto, primordial-origin interpretation](https://arxiv.org/abs/2508.09965)
