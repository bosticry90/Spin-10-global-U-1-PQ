# Dark Dimension PBH benchmark: 4D versus 5D signatures

## Scope and current status

The 2026 accepted paper *Primordial black holes are five dimensional* is a
conditional result inside the Dark Dimension Scenario. It argues that, under
its quantum-gravity and early-universe assumptions and absent exotic
low-energy physics, the studied PBH formation routes produce PBHs on the 5D
side of the Gregory–Laflamme threshold. It is not evidence that PBHs exist or
that nature has a micron-sized extra dimension.

## Signature matrix

For a neutral, nonrotating black hole well below the compactification scale,
the leading dimensional scalings are:

| Observable | 4D Schwarzschild | 5D Tangherlini regime | Discriminating use and caveats |
| --- | --- | --- | --- |
| Horizon radius | `r_h proportional to M` | `r_h proportional to (G_5 M)^(1/2)` | Requires an independent mass and size/interaction probe; crossover and brane effects matter |
| Hawking temperature | `T_H proportional to M^(-1)` | `T_H proportional to M^(-1/2)` | Spectral inference is sensitive to greybody factors, spin, charge, species, and brane/bulk location |
| Entropy | `S proportional to M^2` | `S proportional to M^(3/2)` | Mostly a theory consistency relation rather than a direct observable |
| Mass-loss scaling | `dM/dt proportional to -M^(-2)` | `dM/dt proportional to -M^(-1) M_5^3` in the cited scenario | Particle content and greybody factors set normalization |
| Lifetime | `tau proportional to M^3` | `tau proportional to M^2/M_5^3` | Changes the surviving PBH mass window and burst epoch |
| Emission channels | Standard species available near the 4D horizon | Brane and bulk channels; a bulk PBH may be comparatively invisible to brane observers until late emission | This is model-dependent, not a universal property of every 5D black hole |
| Population constraints | Gamma-ray, charged-particle, CMB, BBN, lensing, dynamics | Some Hawking bounds can weaken, but KK, bulk, cosmology, short-range gravity, and transition constraints enter | A relaxed constraint is not positive evidence |
| Gravitational waveform/microlensing | 4D compact-object templates | Potential higher-dimensional mass-radius, tidal, ringdown, or bulk-location signatures | Requires predictions across the 4D/5D transition, not only asymptotic scaling |

A credible dimensionality claim should fit several rows with one parameter set.
One lifetime or spectrum can be mimicked by 4D spin, charge, environment,
modified evaporation, or a different particle spectrum.

## KM3-230213A assessment

The KM3NeT collaboration measured one extraordinary event: a `120 PeV`
muon with large uncertainty and a median inferred neutrino energy near
`220 PeV`, with a broad 90% neutrino-energy interval. The collaboration has
not identified a source and lists conventional astrophysical, cosmogenic,
dark-matter, black-hole, and new-physics possibilities.

The 5D-PBH proposal notes that

```text
E_nu ~ 10^8 GeV
M_*  ~ 10^9 GeV
```

are close on a logarithmic scale and constructs a bulk-PBH evaporation model
that can yield the event while satisfying the gamma-ray and IceCube limits it
tests. That establishes **viability within the selected model**, not evidence
for the model.

The connection currently has low evidentiary weight because:

- it is a one-event postdiction with a very broad energy posterior;
- energy-scale proximity over roughly an order of magnitude is not a unique
  spectral prediction;
- the event has no identified PBH, distance, mass, or counterpart;
- many source classes remain viable;
- the PBH abundance, lifetime distribution, brane/bulk population, final
  burst spectrum, flavor composition, and sky distribution introduce large
  model freedom;
- compatibility with upper limits is necessary but not a positive detection.

## What would materially strengthen the connection

1. A preregistered population spectrum and event rate for KM3NeT, IceCube-Gen2,
   radio arrays, and gamma-ray instruments.
2. A characteristic high-energy cutoff or flavor/arrival signature that
   conventional accelerators and cosmogenic models do not share.
3. A correlated PBH signature—microlensing, gravitational waves, or a
   compact-object population—using the same PBH mass and abundance function.
4. Joint consistency with short-range gravity, KK production, BBN/CMB,
   diffuse gamma-ray, and neutrino limits.
5. Multiple events with the predicted isotropy, spectrum, and temporal form;
   absence of those events where the model predicts them would falsify it.

Present classification:

```text
DARK_DIMENSION_5D_PBH = SPECULATIVE_CONDITIONAL_BENCHMARK
KM3NET_CONNECTION = MODEL_VIABLE_NOT_EVIDENTIARY
DIMENSIONALITY_RECOVERY_GATE = NOT_EXECUTED
```

## Primary sources

- [Anchordoqui, Bedroya, and Lüst, *Primordial Black Holes are 5D*](https://arxiv.org/abs/2506.14874)
- [APS accepted-paper record](https://journals.aps.org/prd/accepted/10.1103/g12h-93th)
- [Anchordoqui, Halzen, and Lüst, 5D-PBH neutrino model](https://doi.org/10.1103/5kt2-5pvj)
- [KM3NeT observation in Nature](https://www.nature.com/articles/s41586-024-08543-1)
- [KM3NeT possible-origin summary](https://www.km3net.org/km3-230213a/possible-origins/)
