# Quantum dynamical structure: future research specification

Status: `SPECIFICATION_ONLY`. This benchmark changes neither the active M08
calculation nor formal scientific authority. No candidate theory is selected,
no quantum-hardware job is launched and no new fundamental ingredient is added.

## Verified external result and limits

Dong et al., published 23 September 2026, studied a 24-qubit SSH-inspired ladder
on a 125-transmon processor. A three-parameter shallow variational ansatz and
TDVP reveal regular and chaotic trajectories; hybrid short-time evolution,
measurement and classical optimization locate/stabilize coherent trajectories.
These coordinates describe a projected emergent phase space, not a hidden
classical ontology or an exact three-parameter representation of the entire
Hilbert space. Regular trajectories still generate entanglement, and ansatz
enlargement can change resolved detail. The experiment's fidelity diagnostic is
a subsystem observable, not full-state tomography. These limitations matter
when extrapolating to larger systems or QFT. [Nature Physics](https://www.nature.com/articles/s41567-026-03431-z).

The earlier ScarFinder paper develops iterative evolution/projection to search
for low-entanglement coherent trajectories, with controls in spin-1 XY,
mixed-field Ising and PXP models. Its algorithm is a search strategy, not a
universal theorem that low-entanglement projection isolates an invariant
subspace. [PRX Quantum, 12 November 2025](https://journals.aps.org/prxquantum/abstract/10.1103/8g8w-nkwx).

Neither result demonstrates nonlinear fundamental quantum mechanics, a hidden
classical phase space, quantum-gravity effects or Spin(10) viability. The
following specifications are project recommendations, not conclusions proved
by these papers. The schematic iteration `project * evolve` is generally a
variational/optimization procedure, not a linear spectral projector.

## Future Dynamical Structure Gate

Before execution, freeze a particular Hamiltonian/sector, regulator and system
sizes, conserved charges, state-preparation ensemble, observables, time window,
noise model, resource budget and test thresholds. Do not infer a continuum or
thermodynamic claim from one finite system.

Test generic relaxation/ETH diagnostics, exact or approximate integrable limits,
scars versus finite-neighborhood regular motion, prethermal/metastable regimes,
entanglement growth and recurrence fidelity. Compare against independently
evolved exact small-system or controlled tensor-network benchmarks. Search for
counterexamples and measure ansatz leakage, not only optimized revival peaks.

Require perturbation and size/time scaling, uncertainties and an observable
prediction that distinguishes the proposed mechanism from ordinary finite-size
recurrence or feedback-induced stabilization. Explicitly separate behavior
under autonomous evolution from behavior with feedback. Insufficient scaling
or uncontrolled leakage yields `UNRESOLVED`, not a PASS.

## Future Representation Robustness Gate

Freeze which claim should survive changes of coordinates, gauge, ansatz,
truncation and coarse-graining. Coordinate changes should preserve the claimed
observable exactly; approximation changes need convergence/error evidence,
not identical coordinate trajectories.

Enlarge variational depth, compare distinct ansatz families and independently
evaluate full-dynamics observables. Track whether islands shift/disappear,
whether optimized states remain coherent without projection, and whether the
inferred mechanism persists under controlled perturbations. A feature supported
only by one projection is labeled representation-dependent. No fundamental
ontology or exact invariant manifold is promoted from that evidence alone.

## Authority and stopping rule

These two proposed gates are parked specifications, not additions to the eleven
machine-readable candidate gates or executed ledger gates. Reuse the existing
fail-closed hierarchy: discovery, independent reconstruction, physical
interpretation, robustness and empirical discrimination. Any QFT/black-hole
application needs its own model-specific derivation and authorization.
