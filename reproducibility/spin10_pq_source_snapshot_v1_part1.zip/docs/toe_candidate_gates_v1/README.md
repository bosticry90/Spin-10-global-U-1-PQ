# ToE candidate gates V1

This package contains eleven formal candidate-assessment specifications and
bounded case studies. A specification is not an executed or passed gate:

- [Source–Propagation–Detector Gate](SOURCE_PROPAGATION_DETECTOR_GATE_V1.md)
  with a [GW231123 comparison](GW231123_EXPLANATION_COMPARISON.md);
- [Dimensionality Recovery Gate](DIMENSIONALITY_RECOVERY_GATE_V1.md) with a
  [4D/5D PBH and KM3NeT benchmark](DARK_DIMENSION_PBH_BENCHMARK.md);
- [Quantum Distinguishability / Ontology Gate](QUANTUM_DISTINGUISHABILITY_GATE_V1.md)
  with a [quantum versus quantum-like benchmark](QUANTUM_VS_QUANTUM_LIKE_BENCHMARK.md).

The [foundational test matrices](FOUNDATIONAL_TEST_MATRICES.md) extend those
controls with action/propagator, gravity-fork, macroscopic quantum,
strong-field stability, RG/universality, joint cosmology, thermodynamic
gravity, and spacetime topology/smoothness requirements. They also cover
fiber anomaly replication, W/GHZ roles, 3D-light selection rules,
clock-to-parameter maps, quantum simulators/lattice QFT, and collapse/gravity
tests. The machine-readable records are generated deterministically by
`freeze_candidate_extensions.py` and remain `SPECIFICATION_ONLY`.

The separate [geometry and AI research benchmarks](GEOMETRY_AND_AI_RESEARCH_BENCHMARKS.md)
add a holofractographic falsification matrix, distinguish band-state geometry
from spacetime geometry, and specify AI-research verification practices. They
do not add a twelfth gate or promote an external theory.

The [quantum dynamical-structure benchmark](QUANTUM_DYNAMICAL_STRUCTURE_BENCHMARK.md)
records the 2026 mixed-phase-space experiment and proposes future dynamical
structure and representation-robustness controls. They remain parked
specifications, not additional machine-readable or passed ledger gates.

The machine-readable records conform to
[`candidate_gate.schema.json`](candidate_gate.schema.json). These are
candidate-theory and anomaly-attribution specifications only. They do not
modify `project_state.json`, select a new ToE, promote an external result, or
interfere with the active `UVP_M08` gate.

Run:

```powershell
python docs/toe_candidate_gates_v1/audit_candidate_gates.py
```

The audit validates structure, hashes, source boundaries, and the unchanged
scientific-state snapshot.
