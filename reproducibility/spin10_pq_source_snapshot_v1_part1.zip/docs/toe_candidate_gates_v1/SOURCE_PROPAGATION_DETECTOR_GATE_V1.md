# Source–Propagation–Detector Gate V1

## Authority boundary

This is a candidate-assessment and anomaly-attribution gate. It does not
declare an anomaly, select a ToE, or alter project scientific authority.

## Forward model

Every observational claim about fundamental physics must expose the complete
inference chain

```text
source S(theta_s)
  -> propagation P(theta_p)
  -> detector D(theta_d)
  -> inference I(theta_i, priors, selection)
  -> reported observable O.
```

Equivalently, the analysis must implement

```text
O = I[D[P[S(theta_fundamental, theta_nuisance)]]].
```

The decomposition is conceptual, not an assumption that the stages are
statistically independent. Coupled nuisance parameters and selection effects
must remain in the likelihood.

## Hypothesis partition

Before a discrepancy is promoted as evidence for fundamental physics, compare
at least:

1. source astrophysics or source-environment alternatives;
2. propagation effects under established physics;
3. detector calibration, noise, and data-conditioning effects;
4. inference-model or waveform misspecification;
5. an extreme but established-physics regime;
6. genuinely new fundamental physics.

An analysis need not rule out every imaginable model. It must demonstrate
that the leading alternatives capable of producing the observed statistic
were included or explicitly bounded.

## Passing conditions

An anomaly is attribution-ready only when:

- the staged forward model is reproducible;
- alternatives use the same conditioned data and comparable prior accounting;
- model preference survives calibration, noise, waveform, prior, and
  population robustness checks;
- at least one prospective discriminator separates the leading hypotheses;
- local significance, trials factors, selection effects, and population
  context are all reported;
- the promoted claim is no stronger than the surviving attribution.

Failure to pass is normally `ATTRIBUTION_BLOCKED`, not evidence against the
underlying theory. A result may remain a high-value anomaly while its cause is
unresolved.

## Gravitational-wave specialization

For gravitational waves, the propagation stage must consider where relevant:

- cosmological redshift and distance inference;
- strong-lens magnification and repeated images;
- wave-optics diffraction and interference;
- plasma/environmental effects if the proposed model permits them;
- overlap with another coherent signal;
- calibration, spectral lines, glitches, and nonstationary noise;
- waveform-systematic and prior sensitivity.

A modified-gravity phase residual must be compared against ordinary-GR
propagation effects before it is interpreted as new gravity.

## GW231123 pilot

The accompanying [comparison](GW231123_EXPLANATION_COMPARISON.md) exercises
the gate without adjudicating the event. It records that lensing, hierarchical
formation, primordial formation, overlapping signals/noise, and waveform
systematics are not interchangeable explanations: they live in different
stages of the forward model and make different follow-up predictions.
