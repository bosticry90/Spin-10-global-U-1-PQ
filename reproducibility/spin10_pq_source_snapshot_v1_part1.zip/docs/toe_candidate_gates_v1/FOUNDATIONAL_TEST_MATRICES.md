# Foundational physics tests for ToE candidates

These are candidate-assessment specifications and proposed experiments, not passed scientific gates. They sharpen the supplied research discussion without changing the physical action, the active calculation, or scientific authority. The current component calculation is canonical **Spin(10)** with residual-H/PQ structure; references to an active strict SU(5) calculation in the supplied prose must not be used to relabel it.

The external literature is a benchmark library, not input to the pole-blind A3/channel construction. No external framework is adopted. No monitoring automation is created. WATCH means an evidence ledger entry with stated future triggers, not an assertion that a scheduled monitor is running. Source verification date: 2 October 2026.

## Mathematical similarity and quantum recovery

The existing [quantum distinguishability gate](QUANTUM_DISTINGUISHABILITY_GATE_V1.md) remains the formal candidate specification. Scholes and Amati establish a product-basis/network-eigenstate map, not a derivation of all quantum physics. The classical-network architecture and later Hermitian-graph state synthesis do not establish biological implementation, Bell nonlocality, or efficient universal quantum computation. [PRL primary result](https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.134.060202); [later graph construction](https://arxiv.org/abs/2604.23991).

For each candidate, record three different claims: a mathematical map, equality of specified operational probabilities, and a proposed ontology. State the domain, observables, preparations, measurements, and approximation error of the map. A nonseparable classical mode decomposition is not automatically entanglement between separately controllable quantum subsystems. A resource objection must quantify hardware, modes, precision, preparation, readout, and time; Hilbert-space dimension alone is not a proof of a computational lower bound. If two ontologies have identical predictions throughout their declared domain, mark them operationally indistinguishable rather than awarding ontological completeness.

The [action and propagator benchmark](../QUANTUM_ACTION_PROPAGATOR_RECOVERY_BENCHMARK.md) supplies the action-first recovery specification. Prefer an action as an interface where available, not as an ontology axiom. Recover coherent composition, the properly normalized action phase, operator equivalence, physical QFT correlators, and a controlled classical limit. Equal-magnitude discretized path weights are not a universal rule for every gauge-fixed or interacting path integral. Stationary phase is neither decoherence nor a solution of the outcome problem. The photon-count and fidelity claims retain their existing source qualifications; the source's differing postulate-I fidelity numbers must not be collapsed silently into one figure. [Supplied primary photon record](https://pubmed.ncbi.nlm.nih.gov/42647606/).

## Quantum and post-quantum gravity comparison

Oppenheim and Weller-Davies' PRX paper was published on 15 July 2026. It supplies completely positive covariant classical–quantum path-integral constructions; it does not establish that nature uses them or that all high-energy and gravitational initial-value issues are solved. The decoherence–diffusion trade-off is a constraint on the specified hybrid dynamics, not a model-free universal noise formula. [PRX formulation](https://journals.aps.org/prx/abstract/10.1103/2rcd-dzcf); [trade-off theorem](https://www.nature.com/articles/s41467-023-43348-2).

| Test | Quantum-gravity candidate | Classical stochastic candidate | Evidence required for either branch |
|---|---|---|---|
| State and coupling | Specify geometry's quantum algebra and matter coupling | Specify a positive hybrid state over classical geometry and its quantum conditional states | Normalization, positivity, operational no-signalling, domain and boundary data |
| GR and QFT recovery | Derive the low-energy metric and matter limits | Bound diffusion and decoherence while recovering the same limits | One parameter set passing established gravity and matter data |
| Gravity-mediated entanglement | Compute a witness and its mass, distance and time dependence | Compute the corresponding witness for the precise locality/noise assumptions | Suppressed electromagnetic cross-talk, calibrated readout, quantitative competing models |
| Interference and heating | Include ordinary environments and any predicted corrections | Jointly fit decoherence and stochastic force/metric spectra | Environmental nuisance budgets and a common likelihood |
| Covariance and causality | Verify constraints, anomalies and physical observables | Verify hybrid covariance, propagation, positivity and constraints | Proofs for the actual equations, not notation alone |
| UV and strong fields | Demonstrate completion or bounded EFT validity | Demonstrate controlled UV behavior and black-hole/cosmological evolution | Explicit cutoff and failure domain |
| Dark matter claim | Predict abundance and structure if asserted | Derive any effective diffusion-induced component | CMB, growth, lensing and halos, not merely an effective dust term |

Entanglement by itself is not an assumption-free diagnosis of a quantum gravitational mediator: Aziz and Howl construct classical-gravity/QFT examples with entanglement, whereas the PRX paper proves a no-generation result under its stated conditions. Test the quantitative model and the mediator assumptions, not a universal slogan. [Aziz and Howl primary paper](https://www.nature.com/articles/s41586-025-09595-7).

**Disposition:** both branches remain candidates. No “Born rule derived from gravity,” experimentally classical metric, or solved dark matter is entered as earned evidence.

## Fiber timing anomaly and replication

Li's experiment reports optical-fiber timing behavior, not a direct measurement of a changed local vacuum causal speed. Keep the raw delay, fitted spectral feature, source motion, environmental channels, and inferred gravity claim as distinct records. [Scientific Reports primary report](https://www.nature.com/articles/s41598-026-44668-1).

Our dimensional estimate, not a measured result: with `M=72 kg`, `r=0.3 m`, `G=6.67430e-11 SI`, and `c=299792458 m/s`, `2GM/(rc^2)≈3.56e-25`. Multiplying by an illustrative `1e-4 s` transit gives `3.56e-29 s`; a picosecond signal is about `2.8e16` times larger. This is a weak-field scale check, not the full apparatus prediction. The extended delay must be derived using the metric, clocks, trajectory, material response, group index and dispersion. Across a metre of height, `gh/c^2≈1.09e-16`; convention-dependent coordinate-delay estimates must not be called a universal local-speed shift.

| Explanation | Prediction to calculate | Replication discriminator |
|---|---|---|
| GR timing/coordinate effect | Proper-time delays along the actual optical paths | Same apparatus clocks and geometry; compare the complete GR prediction |
| Fiber response | `δt/t=δn_g/n_g+δL/L` with temperature, strain and polarization transfer functions | Calibrated thermal/mechanical injections, different fiber and spool designs |
| Technical periodic response | Vibration, electronics, source-motion cross-talk and analysis window bias | Dummy mass motion, remote actuators, randomized blinded schedules and preregistered statistics |
| Nonminimal photon/gravity coupling | A dimensionless observable and a defined field-theory prediction | Independent mass/distance/sign scaling, vacuum or different-medium tests, astrophysical constraints |
| Fundamental causal-cone change | A local operational comparison against matter clocks and another propagation sector | Exclude unit conventions and altered apparatus/medium response; fit cross-sector dimensionless ratios |

Require phase/sign-resolved responses, null channels, multiple source masses/distances, independent laboratories, public time series and analysis code, and a global environmental model. A power-spectrum peak at the imposed drive frequency is not enough. **Disposition: WATCH; no relativity failure or varying-c promotion.** No exhaustive negative claim about replication is made from this bounded literature check.

## Multipartite measurements and selection rules

The primary abstract reports an entangled measurement of three-photon W states with average discrimination fidelity `0.871±0.039`, using cyclic symmetry and a discrete Fourier transform. This is a measurement primitive, not a completed teleportation protocol; arbitrary-N mathematical architecture is not demonstrated arbitrary-N hardware. The full-text access was unavailable in this review, so detailed apparatus and priority claims are not newly adjudicated. [Primary W-measurement record](https://pubmed.ncbi.nlm.nih.gov/40938974/).

The following is an analytic comparison of the ideal three-qubit states, not a claim about this apparatus:

| Feature | W state | GHZ state | Candidate recovery test |
|---|---|---|---|
| State | `(100+010+001)/sqrt(3)` | `(000+111)/sqrt(2)` | Preparation map and independently calibrated witness |
| Trace out one qubit | `(2/3)|Ψ+><Ψ+|+(1/3)|00><00|`, still entangled | Equal classical mixture of `00` and `11` | Correct marginal correlations and loss behavior |
| Useful role | Distributed single excitation and pairwise residual correlations | Global phase coherence and genuinely tripartite correlations | Recover both structures, not a single scalar entanglement score |
| Measurement | Global W projectors are not product measurements | Global GHZ projectors are likewise nonlocal measurements | POVM completeness, outcome probabilities, readout errors and resource scaling |

For symmetry-based verification, state which observable or sector label is sufficient for the particular claim. A compressed invariant does not generally identify an arbitrary state, and all claimed measurements must be compared against their alternative states.

The 3D-light experiment accesses all spherical dipole components by combining non-collinear beams; it does not introduce a third free-photon polarization. [PRR primary paper](https://journals.aps.org/prresearch/abstract/10.1103/r36b-vw82).

For a quantization axis z, `E_0=E_z`, `E_±1=∓(E_x±iE_y)/sqrt(2)` and `H_int=-Σ_q(-1)^q d_q E_-q`. The Wigner–Eckart factor `⟨j'm'|d_q|jm⟩∝⟨jm;1q|j'm'⟩` requires `m'=m+q`, with the other dipole angular-momentum and parity rules still intact. In a non-collinear arrangement a component longitudinal to the chosen laboratory axis can remain transverse to its own beam. Selection rules therefore depend on representation and accessible control, not new dimensions. The transferable ToE method is to distinguish forbidden channels from experimentally inaccessible ones; this is not new evidence for Spin(10) or SU(5).

## Precision clocks and parameter maps

The lutetium paper evaluates systematic uncertainties `1.2e-19` and `1.3e-19` for two single-ion references, but verifies their agreement at `5.7e-19` statistical precision after 200 hours. Those are different figures. No universal new-physics bound of `1e-19` follows from the clock uncertainty alone. [Nature primary paper](https://www.nature.com/articles/s41586-026-11072-8).

Proposed analysis interface: for a measured ratio `R=ν_A/ν_B`, fit

`δln R = ΔK_α δln α + ΔK_μ δln μ + Σ ΔK_q δln X_q + Δβ ΔU/c^2 + sidereal terms + nuisance terms`.

Specify `μ=m_e/m_p` and the dimensionless nuclear parameters `X_q`. Transition sensitivity coefficients, coherent integration time, bandwidth, sampling aliases and covariance turn ratio residuals into parameter limits. Use species with different sensitivities to break degeneracies. This parameter-map approach follows atomic searches for new physics, not an assertion that the supplied lutetium comparison already measured each coupling. [Atomic physics tests review](https://journals.aps.org/rmp/abstract/10.1103/RevModPhys.90.025008).

| Candidate parameter | Clock observable | Essential control |
|---|---|---|
| Scalar coupling to α or masses | Species-dependent oscillatory frequency ratios | Field amplitude/coherence model and nonzero sensitivity differences |
| Position-invariance parameter β | Differential potential-dependent ratios | Surveyed potential, tides and ordinary gravitational redshift |
| Lorentz-violating tensor coefficient | Orientation/sidereal frequency harmonics | Rotations, magnetic/thermal signals and specified effective operator |
| Metric stochastic-noise spectrum | Correlated timing residuals vs separation/frequency | Link noise and explicit conversion from metric model to clock response |
| Slow drift | Long-baseline ratio trend | Calibration stability and common covariance over the whole baseline |

For geodesy, ordinary GR gives `δν/ν=δU/c^2≈gδh/c^2`; `1e-19` corresponds to roughly `0.92 mm` only when all other terms are controlled. A universal redshift cancels between colocated species; anomalous *differential* sensitivity is a separate test.

| Architecture | Main comparative role | Trade-off to quantify |
|---|---|---|
| Lu+ single ion | Small evaluated environmental shifts and independent same-species verification | Single-particle projection noise, motion and species calibration |
| Sr or neutral Yb lattice | Many atoms provide averaging and network comparisons | Lattice, density and blackbody shifts; do not confuse Yb with Yb+ |
| Al+ ion | Complementary single-ion reference | Quantum-logic readout, motion, technical complexity |
| Yb+ ion transitions | Complementary transition sensitivities | Transition-specific Stark, quadrupole and probe shifts |

Compare architectures using measured stability and uncertainty, not an all-time ranking. [NIST ion/lattice explanation](https://www.nist.gov/atomic-clocks/how-atomic-clocks-work/optical-clocks-future-time); [NIST lattice review](https://www.nist.gov/publications/progress-optical-lattice-clock). The second has not been redefined using lutetium; BIPM describes redefinition as possibly in 2030. [BIPM roadmap](https://www.bipm.org/en/redefinition-second).

## Macroscopic quantum recovery and collapse models

The levitated-nanosphere preprint reports center-of-mass/traveling-light correlations violating separability bounds. The 100-nm silica sphere is not a spatially separated cat, its selected mode is cooled, and its entanglement is optically generated rather than gravitationally mediated. Preserve calibration and systematic errors of the covariance witness; do not identify classical mode coupling with the excluded separable quantum states. [Primary preprint](https://arxiv.org/html/2602.03456v2).

Our proposed collapse-model constraint map:

| Observable | Model dependence | Required nuisance separation |
|---|---|---|
| Excess momentum diffusion `D_pp` | CSL `(λ,r_C)`, density geometry and spatial noise kernel; `D_pp` has units momentum squared/time | Gas, photon recoil, thermal radiation, laser and vibration noise |
| Interference visibility vs time and separation | Compute `exp[-∫Γ_model(Δx(t),geometry)dt]` for the actual trajectory | Preparation/readout errors and known decoherence channels |
| Covariance/entanglement witness | Evolve the full optomechanical model with the additional diffusion channel | Detection efficiency, mode definition, drift, parameter-identification uncertainty |
| Gravitational collapse | Diósi–Penrose energy functional and its short-distance regulator | State mass distributions, not atom count alone |
| Hybrid classical gravity | Joint diffusion/decoherence prediction of a specified model | Simultaneous gravitational/force-noise and coherence likelihood |

For a proposed DP prescription, define `E_G=(G/2)∫d³x d³y Δρ(x)Δρ(y)/|x-y|` and `Γ≈E_G/ℏ`, including the density smoothing that makes the integral meaningful. For CSL use its actual mass-density form factor, not an unsupported universal `mass²` rule. Compare excluded parameter regions at stated confidence and include environmental uncertainty; this experiment alone does not furnish a new numerical CSL exclusion curve. [Collapse models and tests](https://arxiv.org/abs/1204.4325).

For two-mass gravity tests, preregister trajectories and calculate the four branch phases from `U_ab=-Gm_A m_B/r_ab`; the entangling combination is `φ_00+φ_11-φ_01-φ_10`. A direct mechanical witness, optically readout witness and spatial-interferometer witness require different transfer models. Bound Casimir/electrostatic forces, shared light, feedback and initial correlations. Test each classical alternative's quantitative prediction under its own assumptions; an optical bus deliberately entangling two masses is not a gravity-mediator test.

## Strong-field stability and waveform predictions

The resonant-hair study finds fission and absorption of modeled Einstein–Maxwell–scalar composites after releasing spherical symmetry. It is not an observed astrophysical process or destruction of a horizon. [PRD primary study](https://journals.aps.org/prd/abstract/10.1103/n179-gxrz).

| Endpoint | Physical bookkeeping | Proposed observable to compute |
|---|---|---|
| Absorption | Scalar energy/charge crosses the horizon; a bald black hole remains | Horizon growth, scalar/EM losses and final mass/spin/charge, then ringdown |
| Fission | Horizon and bosonic lump separate; account for radiated energy and recoil | Time-dependent multipoles, remnant oscillations, black-hole ringdown and any scalar/EM radiation |

Waveform description is a research proposal, not a waveform measured or derived here. Extract `Ψ4` or asymptotic strain in converged 3D evolution, separate tensor radiation from matter radiation, and compare finite-radius extraction with asymptotic extrapolation. In a weak-field picture tensor waves depend on the trace-free quadrupole's second derivative: a pure dipole translation is not itself tensor gravitational radiation. Whether fission produces a strong detectable signal depends on its quadrupole, timescale and distance. Spherical absorption emits no tensor waves; nonspherical absorption can. Do not promise a unique burst from the endpoint label alone.

The gate requires existence, all relevant perturbative modes, symmetry release, converged nonlinear evolution, endpoint conservation, and detector-ready observables. Changing spherical to axisymmetric evolution still excludes some modes. Validate different seeds, resolutions, boundaries and constraint damping before interpreting instability as physical. Rotating synchronized-hair results motivate other test models, not universal stability conclusions for every scalar potential. [Related rotating/resonant study](https://journals.aps.org/prd/abstract/10.1103/1btp-58hy).

## CFT spectra and field theory instruments

The strontium/Rydberg experiment probes Ising and tricritical-Ising spectral structure in finite chains, including boundary dependence and scaling over chains up to 35 atoms. It does not test spacetime gravity or AdS/CFT. [Nature primary experiment](https://www.nature.com/articles/s41586-026-10904-x).

Proposed fixed-point fingerprint: fit gaps, symmetry labels, correlation exponents and boundary spectra together. For an open conformal chain, `E_n-E_0≈πv(h_n-h_0)/L` plus boundary and irrelevant-operator corrections; for a periodic chain the corresponding bulk scaling uses `2πv/L` and left/right dimensions. Do not mix these conventions. Extract central charge from an appropriately fitted ground-state/Casimir or entanglement observable, not from a few gap ratios alone. An operator-product coefficient needs correlation-function normalization and matrix elements, not just energy levels.

| Instrument | Strength | Limitation | Shared ToE acceptance condition |
|---|---|---|---|
| Classical Euclidean lattice QFT | Controlled regulator and continuum/volume extrapolation, mature gauge observables | Some finite-density sign and real-time continuation problems | Renormalized observables with error budgets |
| Analog quantum simulator | Real-time many-body evolution and direct spectra | Imperfect Hamiltonian map, losses and finite size | Calibrated couplings and bounded departure from target theory |
| Digital quantum simulator | Programmable Hamiltonian and circuit checks | Truncation, gate noise, state preparation and resource cost | Lattice-spacing/time-step/volume limits and gauge constraints |
| Tensor networks | Strong low-dimensional checks and independent numerics | Entanglement-driven cost in some regimes | Convergence and declared approximation domain |

These methods overlap: quantum simulations commonly use a lattice regulator too. “Quantum simulator versus lattice QFT” is not a choice between lattice and no lattice, nor a proof of speedup. A circuit's time discretization and continuum scaling must be certified. [Primary discrete-time QFT construction](https://arxiv.org/abs/2002.02643).

The RG gate asks for a UV-to-IR map, relevant operators, fixed points, anomaly matching where applicable, and distinctive crossover predictions. A shared IR fingerprint is necessary recovery evidence, not a unique UV ontology. The simulator translation layer must specify the Hamiltonian, operator dictionary, scale map, boundary conditions, errors and observables before claiming a nonperturbative test.

## Cosmological recovery and dark energy models

Keep ΛCDM as the baseline. DESI's completion announcement expects the first full five-year dark-energy results in 2027; completed observations are not a released five-year cosmology likelihood. Its July 2026 Lyα discussion reports movement toward ΛCDM while retaining a combined evolving-energy preference; it is not a falsification. Numerical significances must be taken from the exact dataset combination and likelihood, not mixed across analyses. [Survey completion](https://www.desi.lbl.gov/2026/04/15/desi-reaches-mapping-milestone-surpassing-expectations/); [Lyα update](https://www.desi.lbl.gov/2026/07/30/new-desi-dr2-lyman-alpha-results-shed-light-on-dark-energy/).

| Model class | Defining choice | Distinguishing tests and failure conditions |
|---|---|---|
| ΛCDM | Constant Λ with `w=-1` | Joint background and growth consistency; nuisance robustness |
| Canonical quintessence | Positive kinetic term plus scalar potential | `w≥-1` for positive energy density; mass protection and fifth-force limits |
| CPL `w0-wa` | Phenomenological `w(a)=w0+wa(1-a)` | Parameterization robustness; apparent crossing is not a Lagrangian or proof of a ghost |
| Multiple/noncanonical fields | Additional dynamical degrees of freedom | Ghost/gradient stability, sound speeds, perturbations and cutoff |
| Modified gravity | Modified metric/extra-field equations | Expansion versus growth/lensing, local tests and gravitational-wave propagation |
| Interacting dark sector | Specified energy exchange | Conservation, perturbation stability and shared abundance/growth fit |
| Entropic cosmology | Defined entropy/horizon dynamics | Covariant derivation, no double counting, perturbations and predictive improvement |

A candidate must predict BBN, CMB spectra and the sound horizon; `H(z)`, `D_M/r_d`, `D_H/r_d`, supernova distances; and growth, `P(k,z)`, lensing and redshift-space distortions with **one parameter set**. Include neutrino masses, calibration, covariance and selection systematics in the same analysis. Use model evidence and predictive checks as well as improvement in fit. A nominal sigma threshold alone cannot certify a new component. Fits of `H(z)` do not independently identify modified gravity versus a dark fluid.

### Thermodynamic gravity and entropy driven expansion

Jacobson derives Einstein dynamics from local horizon thermodynamics under specified entropy and equilibrium assumptions. This does not identify unique spacetime microstates or independently derive cosmic acceleration. [Original derivation](https://arxiv.org/abs/gr-qc/9504004).

Desré's public project blends two expansion solutions with a sigmoid. The description itself says that additional parameters are disfavored by AIC/BIC and a full Boltzmann treatment is missing; its model-specific percentage match is not a probability of truth. It also gives differing new-parameter counts in different passages, so a fixed parameter ledger is required before model selection can be reproduced. [Project's own report](https://fairfolio.org/projects/cdm-s-thermodynamic-cosmology-simulating-the-universe-s-expa-9e8fcbd9).

To compare with ΛCDM or DESI, derive the covariant equations and horizon choice, prove compatible conservation/Bianchi identities, state entropy and temperature units, verify the generalized second law, and derive scalar/vector/tensor perturbations. Then implement a Boltzmann solver and joint likelihood, including parameter priors and penalties. Test whether an entropy term already represented by GR is being counted again. If microscopic completion is asserted, define the states counted by `Ω` in `S=k_B ln Ω`; otherwise mark the construction macroscopic/phenomenological. A peer-reviewed entropic-model fit is an additional candidate test, not validation of this sigmoid model. [Separate entropic analysis](https://journals.aps.org/prd/abstract/10.1103/zqkb-bqth).

The thermodynamic route to quantum gravity has two separate obligations: derive a controlled gravitational equation of state, and identify dynamics/quantum structure of a substrate that supplies the entropy. Neither follows solely from fitting acceleration. **Disposition: candidate family, not adopted dark-energy replacement.**

## Four manifolds and physical spacetime

A topology specifies continuity and global connectivity. A smooth atlas specifies differentiability; two homeomorphic spaces need not be diffeomorphic. A Lorentzian metric then supplies clocks and causal cones. The embedded-surface paper gives examples with identical boundary/genus yet different isotopy behavior, including topological versus smooth distinctions. It is mathematics, not evidence for extra dimensions or physical exotic smoothness. [Primary surface result](https://arxiv.org/abs/2205.15283).

The four-dimensional intersection count `2+2-4=0` means generic surface intersections are isolated points; it motivates, but is not a proof of, all exceptional four-manifold phenomena. Four Euclidean spatial coordinates and physical `3+1` Lorentzian spacetime have different metric/causal meanings despite sharing manifold dimension.

| Structure to specify | ToE obligation | Claim that remains unearned |
|---|---|---|
| Dimension/topology | State allowed manifolds and why the observed regime is 3+1 | Extra spatial dimensions from visualization |
| Smooth structure | State whether fixed, selected, emergent or summed over | Exotic smoothness explains observed particles |
| Lorentzian/time orientation | Derive or declare the causal structure and initial/boundary-value domain | Every mathematical four-manifold is an admissible spacetime |
| Spin and gauge bundles | Specify fermion structures, bundle topology, characteristic classes and global anomalies | Local Lie algebra alone specifies all global field configurations |
| Topology change | Define transition amplitudes and causal/constraint treatment | An unrestricted formal sum is a defined quantum theory |
| History measure | Specify gauge quotient, contour, measure and observables for any sum over metrics/manifolds | Successful notation uniquely identifies ontology |

Globally hyperbolic smooth spacetimes admit a smooth splitting with a Cauchy hypersurface; this restricts admissible histories and must not be silently imposed on a proposal allowing topology change. [Smooth splitting theorem](https://arxiv.org/abs/gr-qc/0306108). Gauge theory genuinely yields smooth four-manifold invariants, but those mathematical probes are not automatically measured physical signatures of our universe's smooth structure. [Witten's monopoles and four-manifolds](https://arxiv.org/abs/hep-th/9411102).

## Dark dimension neutrino hypothesis

Extend, do not replace, the existing [4D/5D PBH benchmark](DARK_DIMENSION_PBH_BENCHMARK.md). The formation result is conditional on the Dark Dimension Scenario; the source retrieved here records acceptance on 11 August 2026, not confirmation of nature's dimensionality. [APS accepted paper](https://journals.aps.org/prd/accepted/10.1103/g12h-93th).

The minimal 4D Schwarzschild-PBH burst explanation is strongly disfavored by predicted accompanying signals; that result does not exclude every PBH modification or establish a bulk 5D explanation. [Multimessenger calculation](https://journals.aps.org/prl/abstract/10.1103/w9dp-dfkx). Bulk evaporation and neutrino coupling can change the counterparts in a defined extra-dimensional model. [5D neutrino proposal](https://journals.aps.org/prd/abstract/10.1103/5kt2-5pvj).

A population likelihood must combine detector exposure/effective area, broad event-energy posterior, spectra, flavor, sky/time distributions and counterpart upper limits. Fit the same compactification, PBH abundance/lifetime and mixing parameters to BBN/CMB, short-range gravity and sterile/KK constraints. Predicted nondetections only discriminate when exposure and selection are included; “no photons” alone is not positive evidence for a dimension. Preserve conventional sources and cosmogenic neutrinos as alternatives. [KM3NeT's source discussion](https://www.km3net.org/scientific-interest-in-km3-230213a/).

**Disposition: WATCH, no foundational promotion.** A future monitor would notify on additional discriminating events, reproducible population/rate predictions, parameter exclusions or independent evidence; creating that monitor requires a separate scheduling request.
