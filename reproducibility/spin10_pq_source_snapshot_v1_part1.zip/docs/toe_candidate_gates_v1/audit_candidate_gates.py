"""Audit candidate gate specifications without changing scientific authority."""

from hashlib import sha256
import json
from pathlib import Path

from jsonschema import Draft202012Validator


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ZERO = "0" * 64


def file_digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def canonical(payload: dict, field: str = "artifact_sha256") -> str:
    work = dict(payload)
    work.pop(field, None)
    encoded = json.dumps(work, sort_keys=True, separators=(",", ":")).encode()
    return sha256(encoded).hexdigest()


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    schema = load(HERE / "candidate_gate.schema.json")
    validator = Draft202012Validator(schema)
    manifest = load(HERE / "manifest.json")

    assert manifest["package_id"] == "TOE_CANDIDATE_GATES_V1"
    assert manifest["authority_effect"] == "NONE_CANDIDATE_BENCHMARK_ONLY"
    assert manifest["scientific_state_modified"] is False
    assert manifest["artifact_sha256"] != ZERO
    assert manifest["artifact_sha256"] == canonical(manifest)

    listed = {item["path"]: item["sha256"] for item in manifest["artifacts"]}
    assert len(listed) == len(manifest["artifacts"])
    for relative, expected in listed.items():
        target = HERE / relative
        assert target.is_file(), relative
        assert expected != ZERO, relative
        assert file_digest(target) == expected, relative

    records = []
    for name in manifest["gate_records"]:
        record = load(HERE / name)
        errors = sorted(validator.iter_errors(record), key=lambda error: list(error.path))
        assert not errors, "\n".join(error.message for error in errors)
        assert record["artifact_sha256"] != ZERO
        assert record["artifact_sha256"] == canonical(record)
        assert record["authority_effect"] == "NONE_CANDIDATE_BENCHMARK_ONLY"
        assert record["scientific_state_modified"] is False
        assert record["status"] == "SPECIFICATION_ONLY"
        records.append(record)

    ids = {record["gate_id"] for record in records}
    assert ids == {
        "SOURCE_PROPAGATION_DETECTOR_GATE_V1",
        "DIMENSIONALITY_RECOVERY_GATE_V1",
        "QUANTUM_DISTINGUISHABILITY_ONTOLOGY_GATE_V1",
        "QUANTUM_ACTION_PROPAGATOR_RECOVERY_GATE_V1",
        "GRAVITY_FOUNDATIONAL_FORK_GATE_V1",
        "MACROSCOPIC_QUANTUM_RECOVERY_GATE_V1",
        "NONLINEAR_STRONG_FIELD_STABILITY_GATE_V1",
        "RG_UNIVERSALITY_RECOVERY_GATE_V1",
        "COSMOLOGICAL_RECOVERY_GATE_V1",
        "THERMODYNAMIC_GRAVITY_RECOVERY_GATE_V1",
        "SPACETIME_TOPOLOGY_SMOOTHNESS_GATE_V1",
    }

    state = ROOT / "project_state.json"
    assert file_digest(state) == manifest["project_state_snapshot_sha256"]
    payload = load(state)
    compiler = payload["scaffold"]["two_loop_qft_compiler_v1"]
    assert compiler["layer5a_M08"] == "BLOCKED"
    assert compiler["layer6_tensor_IBP_reduction_authorized"] is False
    assert compiler["layer5a_execution_progress"] == "34_OF_39_ENGINE_27_OF_27"

    print("TOE_CANDIDATE_GATES_V1_AUDIT_PASS")
    print("GATE_SPECIFICATIONS_VALID", len(records))
    print("GW231123_ATTRIBUTION_REMAINS_OPEN")
    print("DARK_DIMENSION_AND_KM3NET_NOT_PROMOTED")
    print("QUANTUM_LIKE_NOT_PROMOTED_TO_QUANTUM")
    print("SCIENTIFIC_AUTHORITY_UNCHANGED_M08_BLOCKED_LAYER6_LOCKED")
    print("MANIFEST_SHA256", manifest["artifact_sha256"])


if __name__ == "__main__":
    main()
