"""Deterministically serialize candidate gate specifications; no promotion."""
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]

# Requirements are specifications.  They are not results of executing a gate.
GATES = {
    "quantum_action_recovery": ("QUANTUM_ACTION_PROPAGATOR_RECOVERY_GATE_V1", "Quantum action and propagator recovery", [
        ("COMPOSITION", "Recover coherent propagator composition with a defined measure and state space."),
        ("ACTION_PHASE", "Recover normalized action-controlled phases, including constraints, gauge treatment and required determinants."),
        ("OPERATOR_EQUIVALENCE", "Recover tested operator quantum predictions in the common domain; identify representation changes separately from physical changes."),
        ("QFT", "Recover physical propagators, correlations, scattering, unitarity and Ward or ST identities to declared accuracy."),
        ("CLASSICAL_LIMIT", "Bound a stationary-phase limit and separately establish quasiclassical behavior; do not infer outcomes from stationary phase."),
        ("ONTOLOGY", "Declare operational equivalence or supply an observable that distinguishes proposed path ontology."),
    ]),
    "gravity_foundational_fork": ("GRAVITY_FOUNDATIONAL_FORK_GATE_V1", "Quantum and classical stochastic gravity tests", [
        ("STATE_AND_COUPLING", "Specify quantum or hybrid states, coupling law, positivity, normalization and operational causality."),
        ("GR_QFT_RECOVERY", "Recover precision GR and QFT in their tested regimes with one parameter set."),
        ("COVARIANCE", "Prove covariance and well-posed physical evolution for the actual equations and boundary conditions."),
        ("NOISE_COHERENCE", "Jointly predict and test diffusion, decoherence and environmental nuisance spectra."),
        ("MEDIATOR", "Compare quantitative entanglement witnesses against explicit alternative models and their assumptions."),
        ("UV_STRONG_FIELD", "Provide controlled high-energy validity and consistent compact-object and early-universe behavior."),
        ("OPTIONAL_DARK_MATTER", "If asserted, derive and fit dark-matter abundance and structure rather than promoting an effective dust term."),
    ]),
    "macroscopic_quantum_recovery": ("MACROSCOPIC_QUANTUM_RECOVERY_GATE_V1", "Quantum recovery across mass and complexity", [
        ("STATE_PREPARATION", "Reproduce interference, composition and calibrated state preparation across microscopic and collective degrees of freedom."),
        ("ENTANGLED_MEASUREMENT", "Recover multipartite and continuous-variable witnesses, POVMs and loss-dependent correlations."),
        ("ENVIRONMENT", "Fit gas, photon, thermal and technical decoherence before bounding additional channels."),
        ("COLLAPSE_MAP", "Map collapse parameters, geometry, noise kernel and regulator to measured diffusion, visibility and covariance."),
        ("GRAVITY_TEST", "Treat gravity-mediated witnesses as separate tests with optical and electrostatic alternatives controlled."),
    ]),
    "nonlinear_strong_field": ("NONLINEAR_STRONG_FIELD_STABILITY_GATE_V1", "Nonlinear strong field solution viability", [
        ("EXISTENCE", "Certify the full equations and constraints on the claimed solution."),
        ("ALL_MODES", "Test relevant perturbations beyond the restricted ansatz."),
        ("SYMMETRY_RELEASE", "Remove artificial symmetries and test general three-dimensional perturbations."),
        ("NONLINEAR_EVOLUTION", "Demonstrate converged nonlinear evolution with boundary and seed controls."),
        ("ENDPOINT", "Classify endpoints and account for energy, charge, angular momentum and radiation."),
        ("OBSERVABLE", "Provide converged detector-ready waveforms or other observables and alternative templates."),
    ]),
    "rg_universality_recovery": ("RG_UNIVERSALITY_RECOVERY_GATE_V1", "Renormalization and universality recovery", [
        ("FLOW", "Specify the UV-to-IR map, relevant operators, fixed points and domain of approximations."),
        ("SPECTROSCOPY", "Fit finite-size gaps, symmetry labels, correlations and boundary spectra with correct open or periodic conventions."),
        ("OPERATOR_DATA", "Extract operator data from appropriately normalized observables, not gap ratios alone."),
        ("SIMULATOR_MAP", "Specify Hamiltonian, operator dictionary, scale map, constraints, errors and boundaries before claiming a simulator test."),
        ("REGULATOR_LIMIT", "Certify truncation, lattice, time-step and volume limits with independent numerical comparisons."),
        ("UV_DISCRIMINATOR", "Distinguish theories sharing the same infrared fingerprint using crossover or other operational predictions."),
    ]),
    "cosmological_recovery": ("COSMOLOGICAL_RECOVERY_GATE_V1", "Joint cosmological recovery", [
        ("EARLY_UNIVERSE", "Predict BBN, CMB spectra and the sound horizon with specified primordial and neutrino parameters."),
        ("BACKGROUND", "Fit expansion, BAO distances and supernova distances with calibration covariances."),
        ("PERTURBATIONS", "Derive stable perturbation dynamics and jointly fit growth, matter spectra, lensing and redshift-space distortions."),
        ("ACCELERATION", "Predict late acceleration from a declared model, not infer a mechanism from a phenomenological w parameterization."),
        ("SHARED_PARAMETERS", "Use one parameter set and full nuisance likelihoods across probes; publish model and dataset versions."),
        ("MODEL_SELECTION", "Perform prior and parameterization robustness, model evidence and predictive tests; no sigma-only promotion."),
    ]),
    "thermodynamic_gravity": ("THERMODYNAMIC_GRAVITY_RECOVERY_GATE_V1", "Thermodynamic gravity and cosmology recovery", [
        ("DERIVATION", "Derive covariant dynamics, horizon choice and transition law rather than insert an unexplained interpolation."),
        ("CONSERVATION", "Certify conservation and Bianchi identities and exclude double counting of existing GR entropy physics."),
        ("THERMODYNAMICS", "Define entropy, temperature, heat and generalized second-law behavior with units and assumptions."),
        ("MICROSTATES", "For a microscopic claim identify counted states and their dynamics; otherwise declare phenomenological status."),
        ("PERTURBATIONS", "Derive ghost-free and gradient-stable perturbations and implement full Boltzmann predictions."),
        ("EVIDENCE", "Fit cosmological probes jointly with complexity penalties and a falsifiable distinguishing prediction."),
    ]),
    "spacetime_topology_smoothness": ("SPACETIME_TOPOLOGY_SMOOTHNESS_GATE_V1", "Physical spacetime topology and smooth structure", [
        ("DIMENSION", "Specify why the observed regime is 3+1 and distinguish manifold dimension from metric signature."),
        ("TOPOLOGY_SMOOTHNESS", "Specify allowed topologies and smooth structures and whether fixed, selected, emergent or summed over."),
        ("CAUSALITY", "Define Lorentzian and time-orientation structures and the admissible causal initial-value domain."),
        ("BUNDLES", "Specify spin or appropriate fermion structures, gauge bundles, characteristic classes and global anomaly constraints."),
        ("HISTORY_MEASURE", "Define topology-change amplitudes, gauge quotient, contours and measures before summing geometries."),
        ("OBSERVABLE", "Provide physical discriminators or explicitly withhold physical significance of mathematical smoothness distinctions."),
    ]),
}


def canonical(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def save(path, value):
    value["artifact_sha256"] = canonical(value)
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")


def main():
    for stem, (gate_id, title, requirements) in GATES.items():
        save(HERE / (stem + ".gate.json"), {
            "schema_version": 1, "gate_id": gate_id, "title": title,
            "gate_kind": "CANDIDATE_RECOVERY", "authority_effect": "NONE_CANDIDATE_BENCHMARK_ONLY",
            "scientific_state_modified": False, "status": "SPECIFICATION_ONLY",
            "question": "Does the candidate quantitatively satisfy the scoped recovery tests in " + title.lower() + "?",
            "requirements": [{"id": key, "requirement": requirement,
                              "pass_condition": "Independent reproducible proof or operational evidence establishes this requirement within a stated domain and error budget.",
                              "nonpass_meaning": "This requirement remains unearned; missing evidence is not automatically falsification."}
                             for key, requirement in requirements],
            "admissible_evidence": ["Scoped proofs, reproducible exact or error-controlled calculations and independently calibrated observations",
                                    "Explicit competing models, parameter maps, nuisance budgets and boundary conditions"],
            "prohibited_inferences": ["A gate specification is a passed scientific gate", "A mathematical analogue determines physical ontology",
                                      "An external benchmark promotes the active M08 calculation"],
        })
    manifest = json.loads((HERE / "manifest.json").read_text(encoding="utf-8"))
    manifest.pop("artifact_sha256")
    manifest["snapshot_date"] = "2026-10-07"
    manifest["project_state_snapshot_sha256"] = sha256((ROOT / "project_state.json").read_bytes()).hexdigest()
    manifest["gate_records"] = sorted(set(manifest["gate_records"]) | {stem + ".gate.json" for stem in GATES})
    files = {row["path"] for row in manifest["artifacts"]} | {"FOUNDATIONAL_TEST_MATRICES.md", "GEOMETRY_AND_AI_RESEARCH_BENCHMARKS.md", "QUANTUM_DYNAMICAL_STRUCTURE_BENCHMARK.md", "freeze_candidate_extensions.py"} | set(manifest["gate_records"])
    manifest["artifacts"] = [{"path": name, "sha256": sha256((HERE / name).read_bytes()).hexdigest()} for name in sorted(files)]
    save(HERE / "manifest.json", manifest)
    print("CANDIDATE_SPECIFICATIONS_FROZEN", len(manifest["gate_records"]), "NO_SCIENTIFIC_PROMOTION")


if __name__ == "__main__":
    main()
