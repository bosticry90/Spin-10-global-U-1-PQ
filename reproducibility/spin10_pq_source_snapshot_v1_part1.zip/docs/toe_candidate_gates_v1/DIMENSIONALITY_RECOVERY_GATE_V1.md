# Dimensionality Recovery Gate V1

## Purpose

A theory with fundamental spacetime dimension `D != 4` does not earn physical
authority merely by possessing a consistent higher-dimensional action. It
must derive why ordinary observations are effectively 3+1-dimensional and
identify where the higher-dimensional description becomes distinguishable.

## Required closure

1. **Matter localization.** Derive the Standard Model field content,
   interactions, leakage bounds, and induced operators on the observed
   3+1-dimensional sector.
2. **Four-dimensional gravity recovery.** Derive the long-distance potential,
   radiation, equivalence-principle behavior, and post-Newtonian limits with
   controlled corrections.
3. **Stabilization.** Supply a dynamical compactification and modulus history,
   not only a chosen compactification radius.
4. **Cosmology.** Check reheating/normalcy, KK production, BBN, CMB, structure,
   and dark-radiation/dark-matter constraints in one history.
5. **Crossover.** Match large-object 4D and small-object higher-dimensional
   solutions through the regime in which the horizon and compactification
   scales are comparable.
6. **Unique observable.** Identify a measurement that a flexible 4D effective
   model cannot reproduce without a distinguishable cost or correlation.
7. **Cross-channel consistency.** Use at least two independent observational
   channels—such as short-range gravity plus PBH evaporation, or microlensing
   plus neutrino/gamma-ray populations.

## Verdict vocabulary

- `DIMENSIONALITY_RECOVERY_PASS`: all recovery and discrimination conditions
  pass within an explicit domain.
- `DIMENSIONALITY_RECOVERY_BLOCKED`: a required map, stabilization mechanism,
  transition calculation, or data comparison is absent.
- `DIMENSIONALITY_RECOVERY_FAIL`: a complete calculation conflicts with a
  required bound or produces mutually inconsistent cross-channel predictions.

This gate does not infer ontology from one compact-object fit. A 5D black-hole
calculation is a conditional prediction of a theory; detecting an unexplained
compact object is not by itself a measurement of dimensionality.

## Dark Dimension pilot

The accompanying [PBH benchmark](DARK_DIMENSION_PBH_BENCHMARK.md) records the
signature differences and the present weakness of the KM3NeT connection. It
does not adopt the Dark Dimension Scenario.
