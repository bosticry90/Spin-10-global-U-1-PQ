# Geometry and AI research benchmarks

This review turns the supplied holofractographic, quantum-metric and AI-science discussion into bounded ToE tests. It adopts no external ontology, changes no physical action and authorizes no downstream calculation. The existing eleven candidate gates remain specification-only. Sources were checked on 4 October 2026.

## Holofractographic claims and falsification tests

Disposition: external speculative candidate, test rather than adopt. A source correction matters: OSTI record 21506835 describes **The Schwarzschild Proton**, an AIP conference article from 2010, not the newer 2025 formulation. The latter is the Haramein, Alirol and Guermonprez preprint, version 2 posted 20 October 2025; its landing page explicitly marks that version as not peer reviewed. Its mass, curvature and confinement assertions are the authors' claims, not independently earned results here. [OSTI record](https://www.osti.gov/biblio/21506835), [2025 preprint](https://www.preprints.org/manuscript/202509.1835).

The following is our proposed falsification matrix, not a conclusion of those papers. Vacuum correlations, holographic bounds and geometric descriptions do not validate a particular lattice, screening law or ontology.

| Claim | Required replay | Unearned or failing condition |
|---|---|---|
| Proton mass and radius | Freeze inputs, units, regulators and fitted scales; derive both without using either measured value for calibration | An input-dependent relation is not an independent two-observable prediction |
| Large internal energy and tiny exterior mass | Solve a covariantly conserved stress-energy problem and calculate exterior mass and gravitational observables | Surface-to-volume scaling alone does not establish screening |
| QCD from geometry | Derive colour gauge structure, running coupling, confinement, hadron spectra and a scattering or form-factor curve | One force magnitude or a fitted Yukawa curve does not recover QCD |
| Infrared gravity | Recover precision GR, compact-object and gravitational-wave limits | An attractive potential is not a complete relativistic theory |
| Electroweak and fermion recovery | Recover chirality, gauge representations, symmetry breaking, anomalies and observed interactions | Mass and confinement alone are not complete unification |
| Vacuum energy | Declare regulator, subtraction and conservation; predict cosmology without inserting observed cosmological scales | A cutoff estimate is not a solution of the cosmological-constant problem |
| Scaling and novelty | Preregister dimensionless predictions, domain, uncertainties and competing models | Post hoc numerical coincidence and mathematical similarity do not identify a substrate |

Illustrative dimensional check using the approximate inputs supplied in the request: `G=6.67430e-11`, `c=299792458`, `m=1.67e-27 kg`, `r=8.4e-16 m`. Ordinary Schwarzschild scaling gives `r_s≈2.48e-54 m`, `r/r_s≈3.39e38`, and `rc^2/(2G)≈5.66e11 kg`. This is not a calculation of the proposed screened model; charge radius is not automatically a gravitational boundary radius. The candidate must supply the missing dynamics, not treat this comparison as supporting evidence.

Consciousness claims are outside this physics package. No operational discriminator or reproducible evidence requiring consciousness was supplied for admission. This is a scope decision, not a metaphysical conclusion.

## Quantum metric and spacetime geometry

Sala and collaborators' paper was published on 22 May 2026. Its accessible primary abstract reports evidence for quantum-metric-driven nonlinear transport in Sb2Te3, including temperature/scattering-time independence below 30 K and gate control of surface contributions. This review checked the abstract and publisher metadata, not the full dataset or supplementary uncertainties. [Nature Materials primary paper](https://www.nature.com/articles/s41563-026-02617-3).

For a normalized band state, `Q_ij=<∂i u|(1-|u><u|)|∂j u>`. Its real part is the quantum metric. With Berry connection `A_i=i<u|∂i u>`, `Ω_ij=-2 Im Q_ij`; the sign depends on the connection convention. This metric measures distinguishability of states as parameters change, not Lorentzian spacetime intervals.

Our proposed benchmark requires a Hamiltonian, state/band dictionary, electromagnetic coupling, predicted transport and nuisance budget. A common origin of Hilbert-space, gauge-bundle and spacetime geometry would require an explicit map preserving their distinct operational meanings and a discriminator. Similar notation is not such a map. Berry curvature can encode topological invariants under appropriate conditions; the metric alone neither determines all topology nor derives gravity.

## AI research governance

Schwartz's 1 October 2026 guest account reports 36 manuscripts, 18 fields and 19 coauthors, selected from about 400 problems. It describes expert redirection, unfinished verification and premature success declarations. These are author-reported outcomes, not an audit certifying 36 peer-reviewed discoveries. [Schwartz's account](https://www.anthropic.com/research/claude-shaped-science).

BootLoops describes a model-independent instrument harness with acceptance batteries, independent-route checks, provenance and licensing. This review inspected documentation only: nothing was installed or reproduced locally. Its documentation explicitly distinguishes integrity certificates from a security sandbox. [BootLoops repository](https://github.com/BootLoops-ai/bootloops).

Proposed project practice: freeze scope, inputs and acceptance criteria; build reusable deterministic instruments where warranted; freeze results before comparison; use independent targets and unused witnesses; retain negative controls; audit provenance and resource scaling; explain the mechanism and failure conditions to a reviewer. Human review must distinguish technical correctness from physical relevance. Parallel agents may execute separately authorized subtasks, but an architecture discussion does not authorize new threads, spending, remote writes or expanded scientific scope.

This reinforces M08's current boundary: binary dual-map success cannot substitute for A3 reconstruction success, and neither can promote the complete ordered basis while INT7R is blocked.
