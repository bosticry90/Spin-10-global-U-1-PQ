# Quantum versus quantum-like benchmark

## Current classical-network result

Scholes and collaborators construct classical oscillator/network systems with
emergent eigenstates that can be represented in Hilbert spaces. The 2025 PRL
proves a one-to-one map between arbitrary multi-qubit **product-basis states**
and eigenstates of a constructed classical oscillator network, and describes
quantum-like gates. The earlier Proceedings A paper explicitly calls the
emergent states classical, says they can reproduce some but not all quantum
phenomena, and leaves quantum-like computational advantage open. Later graph
work expands complex state synthesis but does not by itself establish a
quantum substrate.

## Separation table

| Feature | Classical/quantum-like systems can show it? | Sufficient to certify quantum behavior? | Required stronger test |
| --- | --- | --- | --- |
| Linear superposition of modes | Yes | No | Operational state/preparation/measurement map |
| Complex amplitudes and phase | Yes | No | Universal probability and composition rules |
| Interference | Yes | No | Exclusion of the relevant classical wave model |
| Hilbert-space representation | Yes | No | Physical measurement semantics and Born rule |
| Product-state tensor notation | Yes, by explicit constructions | No | Genuine entanglement across independently addressable subsystems |
| Bell-like state labels | Yes | No | Loophole-controlled Bell inequality violation |
| Context-sensitive probability | Sometimes | No | Contextuality test with assumptions and compatibility controls |
| Quantum-like gates | Yes in encoded subspaces | No | Universal operational fidelity plus complete physical-resource accounting |
| Computational speedup in a small demonstration | Possibly | No | Asymptotic advantage against the best classical algorithm and equal resources |
| Bell nonlocality / device-independent randomness | Not reproducible by the excluded local-classical model class | Yes within the test assumptions | Close locality, detection, freedom-of-choice, and memory loopholes as relevant |
| Full relativistic QFT behavior | Not shown by these network mappings | Required for a ToE-level emergence claim | Recover locality/no-signalling, statistics, covariance, fields, and precision tests |

## Benchmark disposition

```text
HILBERT_SPACE_MIMICRY = ESTABLISHED_IN_RESTRICTED_CONSTRUCTIONS
PRODUCT_BASIS_MAPPING = ESTABLISHED
GENUINE_QUANTUM_NONCLASSICALITY = NOT_ESTABLISHED_BY_THESE RESULTS
QUANTUM_EMERGENCE = NOT_ESTABLISHED
BIOLOGICAL_USE = HYPOTHESIS_NOT_OBSERVATION
FORMAL_TOE_GATE = SPECIFIED_NOT_EXECUTED
```

The result is a useful mathematical-universality and ontology benchmark. It
also strengthens the control requirement for “quantum biology”: oscillation,
coherence-like spectra, and interference must be compared with classical
coupled-wave and network models before microscopic quantum function is
claimed.

## Primary sources

- [Scholes, *Quantum-like states on complex synchronized networks*](https://doi.org/10.1098/rspa.2024.0209)
- [Scholes and Amati, *Quantumlike Product States Constructed from Classical Networks*](https://doi.org/10.1103/PhysRevLett.134.060202)
- [Dickey and Kais, *Universal Complex Quantum-Like Bits from Hermitian Weighted Graphs*](https://arxiv.org/abs/2604.23991)
- [Boreiri et al., quantum network distributions not reproducible by classical network models](https://doi.org/10.1103/PhysRevLett.134.010202)
