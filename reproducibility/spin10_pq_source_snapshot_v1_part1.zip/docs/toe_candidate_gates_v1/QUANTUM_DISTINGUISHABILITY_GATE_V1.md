# Quantum Distinguishability / Ontology Gate V1

## Purpose

This gate prevents mathematical resemblance from being promoted to physical
identity. It applies whenever a classical, deterministic, statistical,
network, or informational substrate is claimed to reproduce or underlie
quantum mechanics.

## Three distinct equivalences

- **Mathematical equivalence:** an isomorphism exists between selected state
  spaces, operators, spectra, or equations.
- **Operational equivalence:** all specified preparation–transformation–
  measurement probabilities agree within a stated domain and tolerance.
- **Ontological equivalence:** the formulations make the same claim about
  what physically exists.

Mathematical equivalence does not establish operational equivalence, and
operational equivalence does not by itself establish ontology.

## Quantum-like tier

A construction remains `QUANTUM_LIKE` when it establishes some combination
of:

- linear modes or a Hilbert-space representation;
- complex amplitudes or phase;
- classical interference;
- synchronized superposition-like eigenstates;
- product-basis mappings;
- Bell-like notation without a Bell test;
- gate analogues over a restricted encoded space.

These are valuable mathematical and engineering results, but they are not
standalone evidence of microscopic quantum behavior.

## Quantum-operational tier

Promotion beyond `QUANTUM_LIKE` requires evidence appropriate to the claim:

1. a preparation and measurement map with universal Born probabilities;
2. tensor-product composition and genuine entanglement witnesses;
3. loophole-controlled Bell nonlocality against the relevant classical model
   class;
4. contextuality where the tested assumptions are explicit;
5. no-signalling and consistent update/composition rules;
6. resource accounting that exposes hidden classical state, communication,
   precision, energy, and control costs;
7. for foundational claims, quantitative recovery of relativistic QFT,
   indistinguishable-particle statistics, and tested Standard Model results.

## Resource rule

An `N`-qubit state-space mimic must report how physical resources scale with
`N`. A mapping that uses exponentially many oscillator nodes, couplings,
precision bits, or readout channels is a classical representation of the
state space, not evidence of native many-body quantum scaling or computational
advantage.

## Ontology rule

If the proposed substrate is operationally indistinguishable from quantum
theory over all accessible observables, report operational equivalence and
the underdetermination of ontology. If it predicts a difference, preregister
the observable and error budget. Do not infer ontology from notation.

## Verdicts

- `QUANTUM_LIKE_ONLY`: restricted analogue established; no irreducibly
  quantum claim earned.
- `QUANTUM_OPERATIONAL_EQUIVALENCE_BLOCKED`: required operational sectors are
  incomplete.
- `QUANTUM_OPERATIONAL_EQUIVALENCE_PASS`: the stated operational domain is
  quantitatively recovered, without implying ontology.
- `ONTOLOGY_DISCRIMINATOR_PROPOSED`: a distinct empirical prediction exists
  but is untested.
- `ONTOLOGY_DISCRIMINATOR_PASS/FAIL`: reserved for an executed, controlled
  experiment.
