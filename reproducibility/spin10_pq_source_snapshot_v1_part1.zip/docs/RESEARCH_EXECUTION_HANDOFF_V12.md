# Research execution handoff, V12

Navigation supersedes V11, not authority. Baseline760cb4c. Recover Git/process
state and [the new checkpoint](A10_E5_NONZERO_REGULATOR_CURRENT.md). Before seal
use frozen_a10_e5_scalar_uv/bindings.json; afterward select the new
frozen_a10_e5_nonzero_regulator/bindings.json explicitly. Generic preflight/e5
delegations remain older bounded audits, not latest scientific acceptance.

This increment stopped a nonzero-g regulator extension. Free-only multiplier
P fails local gauge covariance. The exact covariant scalar ordering is
x^T L P(L+m_reg^2)x/2, L=-D_B^2; not (Dx)^T P Dx. Full source/potential and
heavy/light fermion kernel programs retain every field/parameter and the actual
xi cubic. Full Q of the heavy H_total kernel must retain g[V,C_M]_H; the light
background kernel has Qbackground=0. No external45 background or new pair.

Resolved spectral derivatives give tree functional covariance. Classical
covariance does not prove UV regulation. log det(LP)=log det L+alpha log
det(L+m_reg^2)-alpha log(mu^2)Tr1. Scalar F^2 poles retain factor1+alpha, even
with positive regulator reference. The minimal phi gauge loop is nonzero.
The failed candidate's full-M2 claims stop; no action/kernel adoption follows.

Canonical versus physical tensor replay compares all8100 trace-pair entries:
Phi12,Sigma70,phi2,S0,total84. Hodge/wedge realification is essential. Independent
proper-time and direct dimensional bubble/seagull routes give Euclidean scalar
pole7g^2 F^2/(32pi^2 e), Pi7g^2/(8pi^2 e) transverse. Missing seagull fails.
The massless nonexceptional finite weight is log(mu^2/p^2)/3+8/9. This is an
off-shell scalar-loop control, not C1_GS, full beta or physical matching.

Formal odd-coordinate Jacobian checks all643 fields:264 nonzero diagonals
cancel by sectors. Do not infer continuum anomaly freedom or finite-mode
nilpotence. Proper-time scalar trace covariance does not extend by assumption
to the complete mixed gauge/ghost/source/auxiliary Hessian or local contacts.

Completed primary/replay bytes are immutable. The initial unit assertions lost
positive spectral symbol types; original tests/fingerprint/failing output are
preserved in test_preflight_v1 and excluded. Recover those types for matrix and
logarithm comparisons without forced complex branch identities. Own fresh
route output must remain byte-identical. No completed route edits.

Before receipt take seal_a10_e5_nonzero_regulator.py --process-snapshot. Then
export_a10_e5_nonzero_regulator_receipt.py runs279 tests (234 scientific,
24 process,21 governance), two fresh routes,23 predecessor manifests, protected/
state/new bytes and metadata. Custody must remain exit2/seven, never PASS.
No derivation edits during validation. Seal, stage raw validated bytes, check
index bytes/whitespace, local commit only. Preserve existing per-path local
Git attribute for the prior archived CRLF receipt; no frozen normalization.

Next scientific action: independently regulate the complete retained-source
one-loop functional; derive its643-field graded Hessian, source/nonminimal
mixing and Ward/ST variation/restoration. M2--M5, general probes/contacts,
weighted gF A5 equivalence and physical IR/zero modes remain open. No broad
framework, outside personnel or VPC transfer is needed for this next question.

Statev113/34 of39, M08/HB1/C5 blocked, C1_GS uncalculated. No source activation/
removal, auxiliary elimination, catalog, physical matching, contact, publication
or push. Whole Spin(10)xU(1)PQ goal active/incomplete: global boundedness, PQ
quotient, fermion/Yukawa and phenomenology remain. Shared data/chart/word/
Python/SymPy/analyst disclosed, no external endorsement. VPC review321a33e done.
