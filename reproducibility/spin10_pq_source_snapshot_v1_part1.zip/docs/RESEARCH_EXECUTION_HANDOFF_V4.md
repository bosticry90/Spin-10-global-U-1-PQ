# Research execution handoff, V4

This navigation record supersedes V3 for new work; it is not scientific authority.
Recover actual Git, live processes, state and declared byte seals first.
The baseline of this increment is clean e66d1d6. D/E1-E4, E5 joint closure and
the two-parameter canonical normalization family are preserved inactive.

Read [the Q6.1 checkpoint](A10_E5_THEOREM_BRIDGE_CURRENT.md), its result,
assumption map, contract and completed receipt. Exact background/Ward/generator
scope controls establish why the target choices matter. Q6.1 stops because the
renormalized Ward/insertion target is not yet justified. Later theorem and
cohomology gates remain unexecuted, not failed or implicitly passed.

Existing generic research_check.py e5 authenticates the older E5 checkpoint.
The separately versioned audit_a10_e5_theorem_bridge.py authenticates this new
record under the same pole-blind guard; --fresh explicitly reruns only its new
routes. For preflight, pass its repository-relative sealed bindings.json with
--manifest. A tool argument authenticates evidence; it does not grant scope.

Next smallest investigation: derive the retained-source 1PI Ward/Slavnov and
insertion contract, background-only/source/observable scope and canonical
operator transport, with an explicit locality/restoration argument. Then test
regularity/Koszul-Tate and theorem assumptions before comparing both quotients.
Do not omit backgrounds or source terms to force coverage, silently invert
physical couplings, or equate intrinsic and induced basic quotients.

All old evidence remains frozen. project_state.json alone owns authority:
34/39, M08/HB1/C5 blocked, C1_GS uncalculated, custody exit 2/seven unresolved.
No activation, catalogs, quantum matching, publication, contact or push.
Solo review discloses shared inputs, arithmetic/software and analyst.
