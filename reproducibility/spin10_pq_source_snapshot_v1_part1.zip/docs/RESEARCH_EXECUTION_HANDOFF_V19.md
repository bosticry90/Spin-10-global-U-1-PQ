# Research execution handoff, V19

Navigation supersedes V18, not scientific authority. Recover Git and processes
with the compact preflight, then read the cubic prerequisite checkpoint.
Before seal use frozen_a10_e5_auxiliary_vertex/bindings.json; after seal use
frozen_a10_e5_cubic_primitive/bindings.json explicitly. State v113/34of39 and
the whole goal remain unchanged/active/incomplete. Custody 2/seven, not PASS.

The interrupted V1 contract/derivation are preserved byte unchanged. The
prerequisite calculation derives a real H-compatible cubic primitive from
the full measured difference. All 49,005 slots and 888 nonzero differences,
444 primitive physical monomials, both exact transport directions, twelve
local H actions, 1,286 new canonical columns and prior matched projections
are checked. The complete candidate contains 48,283 C3 coefficients.

K0 is the pole generator: negative of the stored old subtraction primitive,
times xi^2. Retain its full g^2*xi^2 R_H quartic. Primitive and image additions
have directly checked grades; imported fixed numerical OrbitPullback values
retain dimension one under the existing qualified typed AST. Compare coupling
coefficients after removing the same coupling monomial from both operands.

All 99 new nonlinear external source shifts and their jet rules are retained.
The joint current and regulated field measure are reused unchanged. Sources
are not integrated and do not cancel that measure. Cubic matching is selected
inactive prediction matching, not quantum A5 or adoption.

The frozen quartet prediction has 4,944 nonzero coefficients over all 980,100
odd-pair slots. Its light-direction entries are zero; this does not prove zero
actual loop channels. No actual quartet calculation or complete E5 result yet.

Next smallest authorized physics action: complete the literal graph inventory
and actual quartet pole by primary sparse graded Born words and independent
full Gaussian/Schur expansion, then compare every declared slot. Include four
cubic boxes, g*xi quartic/g/xi triangles, ordinary g^2 B^2-ghost/two-xi
triangles and two-quartic bubbles. Keep all external splits, anomalous odd
Hessians, mixed inverse, actual nonsymmetric matrices, Gram/Grassmann/Lorentz
factors and distinct heat profiles. UV Taylor only above R_UV>0 with proven
negative-degree remainder. No whole scaleless zero-momentum IR prescription.

First required identity failure/underdefinition stops dependent work. A quartet
mismatch needs full residual and independent real Euler witness. No adjustable
coefficient fitting after seeing a residual. JC-C-C/JB-B-C remain stopped until
this reconciliation, and no HB1/C5/C1_GS or finite matching is authorized.

Preserve cancellation and two failed engineering prechecks with exact code,
logs and explicit exclusion from qualified evidence. No frozen predecessor or
authority edits. Validate before local commit; receipts own executed checks,
fresh own-byte routes and SHA/metadata assertions. Shared software/data/analyst,
solo review; no external endorsement, personal contact, publication or push.
