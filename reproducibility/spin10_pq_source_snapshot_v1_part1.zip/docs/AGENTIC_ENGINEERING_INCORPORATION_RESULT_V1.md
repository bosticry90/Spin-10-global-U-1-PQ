# Evidence-governed engineering incorporation result

The [gap analysis](AGENTIC_ENGINEERING_GAP_ANALYSIS_V1.md) preceded changes.
Recovery found a clean repository at `1dc61f0`, no surviving A10/M08 Python
calculations, authenticated inactive D–E3 evidence and unchanged formal state.
The existing epistemic ladder, role pilot, solo policy, scientific contracts,
independent routes, negative controls, read-only exporters, byte manifests,
dependency chains and authority audits were retained. No replacement research
framework or compulsory agent organization was introduced.

| Addition | Demonstrated purpose |
| --- | --- |
| Root `AGENTS.md` | Directs repository recovery, bounded execution and human-controlled acceptance through existing policies; distinguishes method diversity from model-instance multiplicity. |
| `RESEARCH_EXECUTION_HANDOFF_V1.md` | Provides a compact route from actual Git/process/evidence state to the current contract and authority limits. It resolves navigation past stale historical dashboard entries without editing them. |
| `tools/research_session_preflight.py` | Read-only Git, ledger, process and declared-byte snapshot. Reports exactly which manifest it authenticated; does not launch calculations or infer scientific acceptance. |
| Ten preflight regressions | Reject changed/missing evidence, outside paths, empty manifests, latest-state drift and unavailable process inventory; support the actual legacy decoder and historical-input schemas. Historical state snapshots stay historical. |
| Diagnostic-pipe regression and corrected capture | A 65,536-byte stderr control tests that verbose validation can complete. A stalled initial transaction remains an incomplete operational record, not PASS. |
| Bounded E4 contract and review packet | Apply the existing research methodology to the authorized next increment, explicitly separating full BV from restricted equivariant operations and their source chain rules. |
| E4 validation and retained parser-error control | Separate execution, exact comparison, adversarial tests, byte regeneration and director acceptance. The initial new-helper mistake remains visible instead of becoming a retroactive success. |

The human director retains authority over goals, priorities, assumptions,
scientific acceptance, publication and external acts. Agents investigate,
derive, implement, execute, challenge and report within authorized contracts.
No documentation or tool status changes the formal ledger. Execution,
reproducibility, mathematical validity, theoretical interpretation, empirical
agreement and broader physical claims remain separate under the existing
epistemic ladder.

The initial preflight counted 294 bindings in the newer schema families. A
strict schema check subsequently exposed unsupported legacy decoder families;
the corrected tool checks all six explicitly supported binding families and
authenticated 452 unique bindings across twelve manifests. The completed
preflight returned no matching active scientific processes. Its process
inventory covers matching Python command lines, not
every possible computation. Missing inventory is an error, not an empty list.
The default manifest is the named E3 baseline; newer evidence must be selected
explicitly with `--manifest`, so a successful byte check cannot imply that
every current research claim was checked.

The final bounded validation protocol includes 209 regressions, three freshly
regenerated E4 evidence routes, unchanged inherited bytes, existing authority,
read-only and structure audits, and strict historical custody exit 2 with seven
unresolved references. The completed E4 receipt records actual measurements.
Workspace inventory checks size/mtime metadata; it does not hash the entire
environment. Expensive previously qualified D–E3 mathematics is authenticated,
not rerun. No new proof-assistant formalization or external endorsement occurs.
The incomplete legacy-schema transaction had already regenerated all three E4
routes successfully, but earned no final receipt. Its failure is preserved.
Preflight now precedes expensive regeneration in the complete retry.

Generic repository instructions and recovery tooling are recorded in a tested
immutable process snapshot. Their live files are checked through validation
and commit, but are not made permanent scientific dependencies of E4. Future
process improvement can therefore preserve this tested version without
invalidating a mathematical result merely by editing a navigation tool.
Versioned reports and scientific evidence remain byte sealed.

Both new routes are independent calculations with disjoint output ownership;
their comparison and adversarial checks wait for completion. No multi-agent
pilot was launched. This avoids procedural overhead while preserving distinct
derivations and disclosure of shared inputs, SymPy/Python and analyst. Solo
review continues: published literature is researched, nobody is contacted.

No frozen action, source definition, potential parameter, historical catalog,
scientific receipt, formal state or authority classification was edited. No
activation, remote push, destructive operation or external publication occurs.
The bounded E4 result is separate from this process incorporation. Neither is
evidence of force unification or a calculated finite C1_GS.

The highest-value remaining improvements are to keep each new handoff tied to
its explicit current contract, add cheap typed-interface checks before costly
symbolic runs, and use general structural proofs when their assumptions are
qualified rather than enumerate redundant expressions. A shared runner
refactor, mandatory swarm, new acceptance state machine or mandatory specialist
participation is not justified. Existing sealed runners remain intact.

The next smallest scientific decision is a separately authorized E5 domain
contract using qualified E4 input. E5 must establish both preservation and
adequacy for the intended counterterm problem. No domain, catalog or downstream
calculation is activated by this incorporation.
