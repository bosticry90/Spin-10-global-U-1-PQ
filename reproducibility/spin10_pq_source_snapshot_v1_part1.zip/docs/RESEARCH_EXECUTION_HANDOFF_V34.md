# Research execution handoff, V34

Supersedes V33 navigation, not authority. Baseline9fdab81. Previous turn
PROGRESS: correctedWard sixopen targets. Currentincrement actualGP poles
close the leading measured source-Ward target. Recover Git/processes and
preflight gauge_source_partner/bindings afterseal,ward_reassembly before.
Statev113/34of39; full Spin(10)xglobalU(1)PQ goal remainsactive/incomplete.

Read GP V1 contract/result/current. Qualifying controls/prep1,primary/replay/
prep4,comparison/prep5 and original workers.1940nonzeroB colorcoefficients,
all16source/vectorLorentzpairs,1,458,000B+388,800AH=1,846,800slots. AHexact0
AFTER retaining216rawghost/216rawauxbackgroundcubes; H/Mprincipal edges0.
SourceJB ODD,ghostodd,B/Aeven. Fullcanonical/physical/real/all12rigidH.
Fullsource/xi/ghost,source/xi/auxiliary andsource/xi/YM triangles all6words;
proper gxiquartbubble cannot supplygauge without1PRsource bridge,otherquartics
higherg,scalarfermion/mass alternatives preserveexplicit exclusions.

All16 elementary Born/Wick residues and Gaussian/sphere moments agree:
anti derivative+1/2,ghost derivative-1/2,aux+1/2,YM-3/2. Gauge derivative
selectedzero withcurrent retained. Offdiagkernelsnonzero/residues0. YMeven
pipe3/4,3/4 provesfull6words; TRANSVERSEBBnecessary, not oldlongitudinalrule.
Actualroutes blind topriorE5pole/candidate/Ward-completion/peer reads after
45ancestorbyteauth. Independentphysical10source/GF/YM checksbeforeloops.

Afteractualcomparison newpoles cancelall720source-wave Wardterms: raw0,
anchored0,all12parameterEulers0/full388,800sourceWarddomain. Fullknownsum
30,595canonicalterms; knownWard12,448raw/fiveopen targets. Newnode0in both
existingSlavnovprojectors withall1286columns/support proof; priorGS selected
Slavnovscope andauxhigherprojectionopen unchanged. g^3candidateFAILpreserved.
UnknownG,Delta_b/s,measure/insertions/contacts/IR remainunbound; nofullrestoration.

Preserve two FAILED preloop attempts/source snapshots. Attempt1 wrongorder
Lorentzlabelalignment; attempt2 physicalparent-table misidentifiedasC3. Full
checks retained. Parenttable360independent rows usesE=[EH,EM]; BV886ordered
C3rows usesCinv/Cphys. Exact transformedF/source tensors agree beforeloop.
Neither changesaction/coefficientdata; failures notPASS, allstdout retained.

Nextsmallest ACTUAL action: NEW leadingg^2xi Lambda-B-B/Lambda-A_H-B nojet
auxiliary/vector contract, Lambda EVEN(d2,gh0), complete45aux/all45B/12AH,
allLorentz/Bose components. Recoverfullliteral source/gauge/GF and all
permitted diagrams, coupling/UV/1PI exclusions; do not assume triangle/bubble
zeros from Ward prediction or projectedMJacobi. Calculate independently of
requiredWard tensor, then enlarge mixing-Ward subsystem with fullcurrents/
Eulers andunknown complements. Higher g^3BBaC/ABaC,JaBB/JaAB,JLBC/JLAC
and nonlocal/regulated/source-insertion restoration remain open.

Receipt owns science/process/governance/delegatede5,fourfreshownbytes,
45protected/new/state/metadata invariance; custodyexit2/sevenrefs neverPASS.
Old expensive loops/images authenticateonly. Rawindex/worktree equality
beforelocalcommit. Noreset/evidenceedit/unrelatedtermination, physical/
catalog/HB1/C5/C1_GS/matching,authoritypromotion,push/publication/outreach.
FullW1-W7/A1-A5/equivalence/IR andscalarPQ/fermionYukawa/pheno remainopen.
Sharedinputs/reference/somealgebra/PythonSymPy/analyst; noagents/endorsement.
