# Solo-project review policy, 2026-10-10

The owner expressly directs that ToE-Next is a solo project, that no person is
to be contacted, and that research into external literature remains welcome.
This supersedes earlier plans to recruit external specialists or make their
participation a prerequisite. No review invitation is pending or authorized.

Current review uses independently derived calculations, explicit assumptions,
negative controls, dependency analysis and published primary literature.
Shared inputs, analyst, software libraries and runtime must remain disclosed.
These checks do not earn a claim of external verification or specialist
endorsement. The absence of external participation is a stated limitation,
not a pending recruitment task or an automatic solo-project stop gate.

Earlier contracts/results and four prepared packets are cryptographically bound
historical evidence. Their original bytes remain intact. The current versions
below supersede their outreach and personnel requirements while retaining the
technical questions. This policy does not resolve those scientific questions,
promote a physical action, change formal authority, or authorize HB1/C5.

| Historical packet | Current solo-project version |
| --- | --- |
| `SOURCE_DOMAIN_SPECIALIST_REVIEW_PACKET.md` | [Source-domain technical review](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SOURCE_DOMAIN_SOLO_REVIEW_PACKET_V2.md) |
| `SOURCE_COMPONENT_SPECIALIST_REVIEW_PACKET.md` | [Source-component technical review](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SOURCE_COMPONENT_SOLO_REVIEW_PACKET_V2.md) |
| `INTERACTING_BV_M08_REVIEW_PACKET.md` | [Interacting BV technical review](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/INTERACTING_BV_M08_SOLO_REVIEW_PACKET_V2.md) |
| `INTERACTING_ACTUAL_H_SPECIALIST_REVIEW_PACKET.md` | [Actual-H technical review](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/INTERACTING_ACTUAL_H_SOLO_REVIEW_PACKET_V2.md) |

Any historical instruction requiring a specialist before future promotion is
superseded as a personnel requirement. Its substantive obligation to settle
consequential mathematical and physical objections remains. A future promotion
still requires the owner's separately scoped authorization and exact evidence.

The latest [physical-action review packet](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_PHYSICAL_ACTION_TECHNICAL_REVIEW_PACKET_V1.md)
and [result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_PHYSICAL_ACTION_RECONCILIATION_RESULT.md)
apply this policy. No outreach draft, reviewer shortlist or personal contact
channel is part of the current deliverable.
