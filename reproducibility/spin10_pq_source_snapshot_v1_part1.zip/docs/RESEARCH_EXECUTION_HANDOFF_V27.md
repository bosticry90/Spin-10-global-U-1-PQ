# Research execution handoff, V27

Navigation supersedes V26; sole authority project_state.json v113/34 of39,
whole Spin(10) x global U(1)PQ investigation active/incomplete. Recover Git/
processes/preflight actual source-gauge manifest after seal; derivative-gauge
before seal. Read prospective SG1/SG2 contract/result/current before execution.

Actual g^2 J_a partial B one-loop pole qualified: all45x45=2025 slots, four
Lorentz components, full source/GF IBP currents. Signed Born/Fourier and
independently routed Wick unit residues agree(1,1,-2); literal source/GF
matrix trace versus physical10 Casimir give A=diag(0_H,-C_H),56 coefficients,
rank32, canonical32temporal/128allfour words. All12 homogeneousH,real/frame
and full45 H/M leading ghost reference check pass. Widths/xi vanish by edge
screening, not parameter fixing. Linear45source Hessians zero; nonlinear180
source words J_aM aM C_H; only proper two-cubic odd bubble closes. No finite/
whole-scaleless/IR amplitude or full local jet Ward inference.

Universal derivative carrier theorem BEFORE actual/candidate:643field+643source
Qcolumns and existing census screened. QJ_Lambda includes-J_a; other source
appearances cannot reach J_a partial B. J_Lambda partial B and its retained
source-derivative IBP current span2025 signed columns (-1),rank2025,kernel0
in this quotient, not a full invariant/source basis. Necessary coefficient
P=-A=diag(0,C_H) is fixed by actual source; do not flip/fill it from an old
derivative residual. No full generator/Q image/canonical flow/measure executed.

Old complete inactive candidate FAILS source companion: fullg² projection0,
lower0, residual32temporal/128allfour; real Jp13 Euler=-8partialBp13/5 and
one-momentum Fourier witness nonzero. Pure boundary excluded; no EOM/anomaly.
Current increment first failure stopped before dependent repair, old derivative
residual read/fitting, or new higher/source/quartet/physical loops.

Failed controls attempt1 exact source/start/stdout retained atpreparation1:
borrowed Born product assumed odd externaltokens butJ/gauge areEVEN, giving
primary0. Corrected explicit even product leaves all internal supertrace/
Hessian/inverse signs. Current goodcontrols attempt2/preparation2; actual
routes preparation3; comparison preparation4. FOUR strict own-byte fresh runs,
scientific/process/governance/delegatede5 tests,38chains/protected/new/state/
metadata invariance required. Preserve any validation failures. Custody2/seven
unresolvedrefs,neverPASS. Old expensive loops/125basis images authenticate
only; rawindex/worktree equality before localcommit.

Next smallest action: NEW prospective contract for full source-fixed
auxiliary derivative generator, with correct external-background-H connection
completion. Derive two full Q images, exact canonical/jet/measure obligations,
then compare ALL existing source/auxiliary/quartet/derivative companion records
without fitting. First mismatch stops. Previously predictedg³ quartet awaits
a later separate actual contract. No silent subtraction adoption or unlocking.

No catalog/physical/HB1/C5/C1_GS/matching, authority promotion or external
actions. FullE5/A5/Ward/contact/IR/anomaly, scalar/PQ global,
fermion/Yukawa/phenomenology and full goal remain. Shared inputs/software/
arithmetic/analyst, local conventions, ladder and solo-review without outside
personnel requirements apply. Validated failure evidence is not scientificPASS.
