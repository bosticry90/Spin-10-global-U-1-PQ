# Research execution handoff, V15

Navigation supersedes V14, not authority. Baselineea76c8d. Recover Git/process
state and [the checkpoint](A10_E5_SOURCE_VERTEX_CURRENT.md). Before seal use
frozen_a10_e5_regulated_slavnov/bindings.json; afterward select new
frozen_a10_e5_source_vertex/bindings.json explicitly. Generic preflight/e5
remains an older bounded delegate, not latest scientific acceptance.

Actual g xi JB-C bubble and g^2 xi Jx-C-x triangle poles match independent
graded Born and Wick routes. All4 Lorentz outputs, odd orientations and full
mixed gauge–auxiliary inverse retained. G_LL=0; do not eliminate auxiliary.
The literal xi ghost cubic has no g. The17 quadratic width coefficients are
separate; all276 cubics retained. Orbit term is g xi with mass dimension1.
The positive scalar reference makes the triangle UV Taylor integral IR finite;
massless zero-momentum Taylor is excluded. Bubble keeps nonzero momentum.

Heavy tensor35937 entries, gauge-source1485 and actual phi source18000 entries
including H zeros agree. Other scalar sectors extend structurally through
qualified representation/commutator data; no fresh exhaustive Sigma products.
N_M=kappa_aux G_M is the primal ghost endomorphism, not the auxiliary bilinear.
FullN killsH, trace132, all12 H identities pass. Wrong Gram shortcut fails.

Kbar=g xi JC^T N C gives complete54,194-coefficient Cbar=QKbar-div(theta),
with2688 current-divergence coefficients and22626 scalar-source coefficients.
Its two projections match the poles with1/(32pi^2 e). Candidate remains
inactive; other loop channels are not certified by this canonical image.
Full643 pairs,48 backgrounds,34 physical/nine source terms,xi/R_H,parameters
and vacuum unchanged. No source activation, catalog or physical matching.

Ghost/source linear transport preserves evaluation pairing and jets. External
sources do not cancel field measure. Regulated logBerezinian includes background
spacetime trace ofN; its action effect begins at hbar^2 for this hbar-order
change. Keep that term, not a fake background-independent normalization.
FullquantumA5, contacts, IR/anomalies and E5 remain open.

Preserve three execution preflights and the failed factored-E1 comparison.
Original completed primary uses the specifically archived pre-metadata-repair
module fingerprint; fresh current-code output must match original bytes.
Only that original binding may differ. All fresh fingerprints are strict.
Before receipt take seal_a10_e5_source_vertex.py --process-snapshot, then
export_a10_e5_source_vertex_receipt.py:337 tests, two fresh routes,26 parents,
protected/state/new SHA and metadata, custody2/seven. No edits in validation.
Seal, compare staged raw bytes, whitespace check, local commit only. Keep
the existing per-path archived-CRLF Git attribute; never normalize old evidence.

Next: actual g xi ghost two-point and g^2 xi JC-C-C/JB-B-C companions; compare
remaining canonical projections, then full relevant Ward/Slavnov restoration
with finite cutoff/source correction and any derived additional normalization.
No fullE5/M2–M5/A1–A5, HB1/C5,C1_GS,activation,catalog,authority promotion,
outreach,publication,push. Statev113/34of39 and custody2/seven unchanged.
Whole Spin(10)xU(1)PQ goal active/incomplete; global boundedness,PQ quotient,
fermion/Yukawa,phenomenology open. Shared data/software/analyst; solo review.
