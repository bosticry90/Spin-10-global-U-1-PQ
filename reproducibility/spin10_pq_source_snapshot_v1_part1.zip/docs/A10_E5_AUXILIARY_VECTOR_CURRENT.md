# Current auxiliary/vector poles and measured mixing Ward checkpoint

Read the [AV V1 result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_AUXILIARY_VECTOR_RESULT_V1.md)
and prospective contract. Independent Born and physical Wick routes agree over
all 1,174,770 Bose-symmetric auxiliary/vector component slots. Lambda is EVEN
(d2,gh0), distinct from BV J_Lambda. BB has 526 real color coefficients,
2,104 physical/all-Lorentz terms and 720 canonical terms; AB/AA poles vanish
after their complete vertex and edge/trace checks. The full triangle Bose sum
vanishes with nonzero ordered contractions preserved; the bubble supplies BB.

After actual comparison, new poles cancel all 720 leading mixing Ward terms.
Raw and anchored selected left sides and all twelve parameter Eulers vanish.
Updated known residue: 31,315 terms; known Ward: 11,728 raw terms/four open target
signatures. GS selected Slavnov and GP source-Ward scopes remain; g10^3 frozen
quartic candidate FAIL remains. Unknown Gamma/Delta, contacts/insertions/measure/
IR are unbound. This checkpoint does not establish complete quantum restoration.

Qualified controls/prep1, primary/prep2, replay/prep3, comparison/prep4. Two
development test-source failures and exact snapshots/full separate reproduction
stdout are archived as engineering_attempt_1/2, not PASS. Actual workers are
unchanged. Receipt/seal own validation; preflight authenticates bytes only.
Select auxiliary_vector/bindings after seal, gauge_source_partner before.
Statev113/34of39 and custodyexit2/sevenrefs remain. Next: new actual g10^3
BB/AB/AA-antighost/ghost graph contract; full symmetry, representations and
transverse/mixed propagators. Wider PQ/scalar/fermion/pheno goal remains open.
