# Actual auxiliary-source/ghost derivative companion, current navigation

Sole authority project_state.json v113/34 of39; whole Spin(10) x global
U(1)PQ investigation active/incomplete. Read AG1/AG2 contract/result and
frozen controls/primary/replay/comparison,receipt/bindings. Preflight this
auxiliary-ghost manifest afterseal; auxiliary-derivative beforeseal.

Actualg² JL BoxC=diag(0,-C_H),56physical/rank32,128rawallfour words matches
complete95155-word inactive member across2025Box/20250tensor components.
Both odd externals, complete GF/second-jet IBP, all10 Lorentz components,
full ghost/mixed leading references,real/frame and homogeneous12H pass.
Unitweights(+1,-1,0); omitted mixed edge/second denominator Taylor fail.
Source cubic180/quartic836 and scalar/Orbit6688 screened. Quartic tadpole
two-jet coefficient0 beforeintegration; heat2 versusbubble4 retained.
No no-jet power/mass, finiteIR or fulllocaljetWard/A5 promotion.

Preserve failedcontrol attempt1 (zero polynomial UV-degree assertion) and
freshcorrected prep2; fourstrict own-byte routes required.40chains/state/
metadata protected; custody2/seven unresolvedrefs neverPASS. Noadoption or
physicalactivation. Next separatelycontractactualfullg³ four-ghost companion
to966prediction; firstmismatchSTOP. g² longitudinal/mixing, no-jet power/
mass and otherhigher companions remain unqualified. Sharedsoftware/inputs/
analyst, localconventions/ladder/soloreview remain.
