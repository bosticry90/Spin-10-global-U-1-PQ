# Research execution handoff, V16

Navigation supersedes V15, not scientific authority. Baseline e15219a. Recover
Git/process state and [the checkpoint](A10_E5_GHOST_COMPANION_CURRENT.md).
Before seal select frozen_a10_e5_source_vertex/bindings.json; after seal select
frozen_a10_e5_ghost_companion/bindings.json explicitly. The generic preflight/e5
delegate is an older bounded checkpoint, not latest scientific acceptance.

Complete g*xi ghost kinetic logarithm=0. Both mixed bubble assignments give
opposite kinetic log weights. All45 ghost/antighost directions, all four
Lorentz copies, derivative placements and648 literal quartics are retained.
Fresh physical10 nonsymmetric quartic reconstruction/pullback and signed
graded tadpole trace verify the -kappa group matrix. Width and g-free xi cubic
remain distinct. G_LL=0; mixed Green nonzero. Keep nonexceptional momentum.

Prior ghost-only Kbar=g xi JC N C predicts nonzero ghost kinetic density.
Its previously matched source poles stay qualified. It is an incomplete
normalization, not a defective action/BV. All2025 kinetic entries compare.
Density witness +8 dbar.dC has Euler -8 Box C. Fourier q_E^2=-q_M^2 gives
-8 q_E^2 C. The shared +8 q_E^2 provisional line in original JSONs is
explicitly superseded in audit/receipt; original completed bytes stay intact.
Do not re-adopt it simply because two routes agree.

Whole heat profile produces g xi kappa(Jpair-Jsingle): cutoff power
-g xi kappa Lambda^2/(64pi^2), finite -3g xi kappa q_E^2/(128pi^2), log0.
Keep these distinct. No scaleless tadpole proof or early auxiliary elimination.
Free opposite ghost/nonminimal scaling preserves pairing and Q0 doublet,
but changes mixing/width and is not a qualified interacting normalization.

First failure stops JC-C-C/JB-B-C loops. Next smallest increment: derive a
typed joint ghost/nonminimal normalization with actual B-Lambda and width
pole companions and canonical sources/measure/Ward obligations. No fitting
to the observed zero. Freeze its own contract before computation.

Preserve archived failed integral comparator and canceled slow supplemental
audit. Batched replacement retains every quartic coefficient. No unfinished
check counts as PASS. Validation requires strict own-byte primary/replay,
independent quartic/Lorentz/witness checks,357 tests and27 predecessor chains.
Before receipt take seal_a10_e5_ghost_companion.py --process-snapshot, then
export_a10_e5_ghost_companion_receipt.py. No edits during validation. Seal,
compare index/raw bytes, whitespace check, commit locally only. Keep archived
CRLF per-path Git attribute; never normalize old evidence.

Full643 pairs,48 backgrounds,34 physical/nine source terms, xi/R_H, potential,
vacuum and physical parameters unchanged. Statev113/34of39 and custody2/seven
unchanged. No activation/catalog/HB1/C5/C1_GS/matching, publication/push/outreach.
FullE5, quantum restoration/A1–A5/contacts, IR/anomalies remain open. Whole
Spin(10)xU(1)PQ goal active/incomplete; global boundedness,PQ quotient, full
fermion/Yukawa and phenomenology unresolved. Shared data/software/analyst;
solo review, no external endorsement. A validated negative result is progress,
not scientific success or completion of the full investigation.
