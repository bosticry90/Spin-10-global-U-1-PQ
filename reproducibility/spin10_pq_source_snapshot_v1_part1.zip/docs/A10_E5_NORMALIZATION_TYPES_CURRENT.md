# Current E5 normalization-type checkpoint

This navigation note supersedes the quartet checkpoint for next-step navigation,
not authority. Read the normalization-types V1/V2 contracts and result in
`tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/` and use
`frozen_a10_e5_normalization_types/bindings.json` after it is sealed.
Before that, authenticate the preceding quartet manifest. Recover live
processes and Git with the read-only preflight; do not restart a worker solely
because its observation timed out.

The complete actual quartet and its 5,528-slot mismatch remain qualified.
Further source-free heavy repair is obstructed with the old width and cubic
matches fixed: the residual H-compatible skew bilinear has zero full Q image.
Five necessary generator carrier types were derived. They are not a complete
H-invariant basis or a general quantum counterterm classification.

The corrected unit auxiliary shear uses F=G_M E, where E is the existing
xi auxiliary Euler two-odd term. It has a complete canonical/H/real/jet image
and triangular field Berezinian one. All its companion terms are retained;
none are actual new loop calculations. The first unlowered proposal failed
H in 152 exact coefficients and remains preserved. The inherited typed
orbit grading precheck failure and all 3,936 rows are also preserved.

Next: classify the H-equivariant JLambda a C tensor space and the coordinated
image/companion requirements before any fitted subtraction or new loop.
Do not infer quantum A5 from classical canonicality or a unit Jacobian.
No residual fit, normalization adoption, new JC-C-C/JB-B-C or other loops,
catalog/physical activation, HB1/C5/C1_GS, authority change, publication or push.
State v113, 34/39; custody exit 2/seven. The whole investigation remains active.
