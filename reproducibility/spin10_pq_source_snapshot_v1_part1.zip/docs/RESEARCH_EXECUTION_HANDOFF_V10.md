# Research execution handoff, V10

Navigation supersedes V9, not authority. Baseline ab2b63a. Recover Git/process
state and [the new checkpoint](A10_E5_GHOST_NORMALIZATION_CURRENT.md).
The supplied latest E5 assessment requires actual nonempty quantum construction
evidence. This increment supplies an explicit regulator and finite ghost
subsector subtraction, not complete M2/W1--W7 or a replacement success criterion.

Before sealing authenticate frozen_a10_e5_minimal_target/bindings.json explicitly;
after sealing select frozen_a10_e5_ghost_normalization/bindings.json. Generic
research_check.py e5 remains its older delegation; checksums are not science.

The 276-term xi heavy interaction survives g=0. Never insert g into E1, set
xi=0 or erase it. Gaussian integration in ghosts FOR FIXED Lambda gives the
actual determinant; the full action remains interacting. Full physical-matrix
replay matches all 33 ghost operators and 1,089 kappa coefficients.
kappa_phys=8 I-2 C_H has relative eigenvalues 3,19/5,24/5,34/5,8. It cannot be
absorbed by uniform delta xi in the literal auxiliary term. The separately
computed matrix Psi_CT is H invariant and Q0 exact, not an adopted edit of E1.

P_e=((p_E^2+m_reg^2)/mu_reg^2)^(e/2) is source independent and commutes with
the actual linear Q0 and ordinary derivatives. The finite-mode measure has
unit Berezinian; local background shifts and expected light quantum breaking
are checked. All 643 pairs/48 backgrounds and the scalar potential remain.
Regulator parameters/nonlocal kernels do not belong to the local cochain ring
or the grammar admitted by physical Euler adapters. No new canonical pairs.

At g=0 auxiliary-auxiliary propagation vanishes, B has no interaction vertex
and scalars decouple from the ghost sector. One ghost polygon supplies its
complete UV pole; no higher loops in THIS disconnected sector. The finite
extensions explicitly subtract the nonexceptional bubble. Analytic MS has
[1+log(mu^2/q^2)]/(16 pi^2), dimensional MSbar has [2+log(mu^2/q^2)]/(16 pi^2).
Their local difference is retained. The finite logarithm is nonlocal.
Selected rho cubic-probe poles carry (1+rho)^2; first/second contacts have
the ordinary factors two, and the subtraction is source independent/Q0 exact.

The named torsion F remains a nonexact polynomial class. The realized affine
normalization excludes its constant ordinary-source correction only in this
specified family at rho=0. Do not infer general insertion exclusion or A5
quantum equivalence of weighted gF. Full scalar UV closure/IR, all-g anomaly
restoration and general source/contact normalizations remain unresolved.

Main and finite completed records must never be overwritten. The initial
validator compared equal finite formulas as strings; validation_preflight_v1
preserves original validator/test bytes and observed forms/exits, explicitly
not a full start attestation. Its failure is excluded. Exact symbolic equality
is now required, while each own fresh route output must be byte-identical.

Before receipt export take seal_a10_e5_ghost_normalization.py --process-snapshot.
Then export_a10_e5_ghost_normalization_receipt.py runs 239 tests (194 scientific,
24 process,21 governance), two fresh route suites/four artifacts, 21 predecessor
chains, protected/state bytes and workspace metadata, retaining custody exit
2/seven. No derivation edits during validation. Seal then stage the exact raw
validated file set, commit locally and recover a clean preflight. No push.

Next scientific action: g=0 scalar subtraction closure of the ACTUAL 29-potential/
34-real-parameter family and the admissible BRST-exact gauge-fermion normalization
space; then all-g restoration and A4/A5 equivalences. No unrestricted catalog,
VPC transfer, outside personnel or infrastructure expansion is needed.

State v113/34 of 39, M08/HB1/C5 blocked, C1_GS uncalculated, custody unresolved
and inactive scientific candidates remain. No source removal/activation,
auxiliary elimination, publication, contact or authority promotion. The full
Spin(10) x U(1)PQ goal stays active/incomplete, including global boundedness,
global PQ quotient, fermion/Yukawa content, matching and phenomenology. Shared
immutable inputs/chart/word routines/Python/SymPy/analyst are disclosed; no
external endorsement. VPC review at 321a33e remains completed engineering work.
