# Research execution handoff, V30

Supersedes V29 navigation. Recover actual Git/processes and run the read-only
preflight with the quartic-g3 bindings after sealing; auxiliary-ghost before
sealing. project_state.json v113, 34/39 is the sole scientific authority.
The whole Spin(10) x global U(1)PQ goal remains active/incomplete.

Read QG3 V1 contract/result/current and exact preparations/attempts/results.
The actual one-loop g^3 no-source quartet is qualified within its declared
UV scope by full Born versus physical Gaussian/Schur calculation. Their
formal-width and bound family tensors agree before prediction access.
QG3-2 fails against the unchanged 966-term prediction at 8ab7042: actual
also has 966 canonical terms, but 648 residual terms/3,960 physical slots.
There are 3,960 xi^2 and 3,544 xi*eta_H residual slots. Preserve every one.
All 980,100 antisymmetric pair polynomials, including computed zero channels,
are compared. The (12,13;12,13) residual is -16*xi^2/5 in common
hbar*g10^3/(32*pi^2*epsilon) units; the ap13 Euler witness is nonzero.

Keep full H/H, H/M and M/M ordinary W, curvature R, G/X/Q, both odd
orientations and mixed inverses. Born family word counts 4/3/6/6/2/2,
explicit W/Q zero after full Hessians, heat profiles 8/6/6/6/4/4.
Full-vector endpoint identities justify the leading direction reduction;
g^4 transverse counterexample forbids extending it outside its proof.
Formal widths distinct from vertex xi until complete tensors; real binding
only afterward. All 12 homogeneous H, real and frame checks pass. No complete
local jet Ward, Slavnov, source/contact, measure/regulator or finite IR claim.

First-failure rule is in effect: no candidate fitting, image adjustment,
higher or physical loops after comparison. Earlier qualified amplitudes,
including the a19b4b6 source/ghost two-jet match, remain intact. A failed
prospective scientific gate can have successfully authenticated failure
evidence; preserve these statuses separately.

Receipt owns tests, commands, exact starts/source bytes, runtimes, four
strict fresh routes, 41 protected chains and byte/size-mtime/state invariance.
Preserve all failed/unfinished attempts separately; never count them as PASS.
Custody expected exit 2/seven unresolved references, never PASS. Authenticate
old expensive qualifications only. Raw Git index/worktree equality before
local commit; no reset, evidence edits, unrelated process termination or push.

Next smallest bounded action is a NEW prospective measured-functional
assembly/dependency contract: retain each measured pole with its graph,
coupling, width, jet, source and UV scope; identify testable shared Ward,
Slavnov, source and insertion obligations and exact missing partners.
This audit must preserve the quartet obstruction and explicitly unknown
g^2 longitudinal gauge/auxiliary mixing, no-jet power/mass and higher poles.
Do not fit the candidate or claim that the measured subset is complete.

No adoption, catalog/physical activation, HB1/C5, C1_GS, matching, publication,
outreach or authority promotion. Full E5/A5/anomaly/global scalar-PQ,
fermion/Yukawa/phenomenology and the whole goal remain unfinished. Shared
inputs/arithmetic/software/analyst disclosed; no agents were used. Follow
local conventions, existing ladder and solo-review without recruitment.
