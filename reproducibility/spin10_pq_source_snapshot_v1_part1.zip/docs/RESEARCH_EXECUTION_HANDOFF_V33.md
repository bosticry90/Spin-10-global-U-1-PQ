# Research execution handoff, V33

Supersedes V32 navigation, not authority. Baseline878df08. Previous turn
PROGRESS: actualJC-CC and selectedSlavnovleftside qualified, inherited metric
error repaired. Current increment WR recomputes corrected full local Ward.
Recover Git/processes/preflight ward_reassembly/bindings afterseal,
ghost_source/bindings before. Statev113/34of39; whole goal incomplete.

Read WR V1 contract/result/current. Qualifying controls/primary/replay/
comparison are own original preparations and worker. All13sectors/27,971terms,
Ward13,168raw/34,464anchored/59,304realphysical agree. All1334operatorcolumns,
17,676homogeneous-g terms/96affine shifts, BOTH B_H/A_H, all12parameterEulers,
four3472termcurrents/frame/reality. ConstantH0 and newactualJC localWard0.
Nonzero realomega_p0 Euler witness -36g^3xi/25 Bp13_0 Cp12 partial0ap13;
fullpolynomial retained, noEOM. Known subset only, not fullbreaking/anomaly.

Exact old-to-corrected Warddifference540terms=Tb(old99termJBmetricerror).
Same sparse counts do not mean same coefficients. Old MF/GS records, failures,
sources/attempts/preparations and their bytes remain intact; do not use old
affected Ward coefficient interpretations as current science. New assembly
uses own actual gauge-source projection, canonical/physicalJCsource and
strictcoupling/frames. No new actual loop or candidatefit/image/adoption.

Forward/reverse complete dimension-zero typecensus agrees: sixWardtargets,
ten unmeasured inputtypes=fivefamilies with B_H/A_H alternatives: g^2LBB/LAB,
g^2JBBC/JBAC; g^3BBaC/ABaC,JaBB/JaAB,JLBC/JLAC (lastinputonejet, output
omega1/omega2). AffineconnectioncomponentH only; otherB fullrepresentation.
CoefficientsNone, notzeros; no invariantbasis or requirement each diagram
nonzero. Separate scalarindexed/powerfinite nodes keep scopes. Equation
Wb(Gknown+Gunknown)=Delta_b; unknownbreakings/contacts/measure/IR unbound.
GS selectedSlavnovleftside scope and priorg^3quartetcandidateFAIL preserved.

Next smallest ACTUAL action: NEW prospective g^2xi JB-B-C and JB-A_H-C graph
contract, J_B ODD, full45source/ghost/gauge/allLorentz/background directions,
complete literal source/GF/YM/other inventories and UV/coupling/1PI exclusions,
mixed/bothodd/transverse inverse, separate Born/Wick approaches, exact zeros
established independently. Do not use Ward target/candidate/peer/predictedzeros
as actual loop inputs. Compare complete calculated tensor first; THEN enlarge
the source Ward condition with currents/Eulers, keeping Delta_b/scope unknown.
SourceYM triangle can have transverse BB: no reuse of the pureg^3 quartet's
longitudinal-collapse proof for this new graph. Graphs/types remain proposals
until separately frozen/calculated. LBBg^2 and higher families also remain open.

Receipt owns fourfresh own-byte controls/primary/replay/comparison, scientific/
process/governance/delegatede5,44protected chains,new/protected/state/metadata
invariance. Custodyexit2/sevenrefs neverPASS; old expensive loops/images
authenticate only. Preserve failures/unfinished states; rawindex/worktree
equality beforelocalcommit. Noreset/evidenceediting/unrelatedtermination,
physical/catalog/HB1/C5/C1_GS/matching, authoritypromotion, push/publication/
outreach. Full W1-W7/A1-A5/nonlinearrestoration/insertion/transport/equivalence/
IR and scalarPQ/fermionYukawa/pheno remain open. Shared inputs/operators/some
arithmetic/PythonSymPy/analyst disclosed; noagents/independent scientists.
