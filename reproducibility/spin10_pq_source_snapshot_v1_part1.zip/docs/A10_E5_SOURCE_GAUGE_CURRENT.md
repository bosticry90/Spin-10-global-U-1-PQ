# Source–gauge derivative prerequisite, current navigation

project_state.json v113/34 of39 remains sole authority; whole Spin(10) x
global U(1)PQ investigation active/incomplete. Read package source-gauge
CONTRACT_V1 and RESULT_V1, controls/primary/replay/comparison, receipt and
bindings. Preflight source-gauge manifest after seal; before seal use the
derivative-gauge manifest at baseline7206e41.

Actual source pole is diag(0_H,-C_H),56 physical coefficients/rank32 across
2025 slots; allfour polarizations, real/frame and homogeneous12H checks pass.
Two-even-external unit residues are(1,1,-2) for internal a/C and external B
derivatives. Full actual/GF IBP currents retained. Frozen carrier theorem
screens1286 Q columns; J_Lambda partial B is the only projected carrier,
2025 signed columns/rank2025 with kernel0 in that quotient. Necessary P=+C_H
is input-derived; no full generator or image implemented or normalization
adopted. The old candidate projection zero FAILS, real Jp13 Euler=-8/5 dBp13.

Preserve failed controls attempt1 (wrong even external parity), excludePASS.
First mismatch stops before dependent repair or old derivative residual fit.
Next: separately contract complete source-fixed derivative generator, external
background-H connection completion, full Q/canonical/measure and ALL existing
companion comparisons. Preserve source-fixed signs. No fullE5/A5 or physical
activation; custody2/seven and shared-assumption/software/analyst limitations
remain. All current bounds retain solo-review and epistemic ladder policies.
