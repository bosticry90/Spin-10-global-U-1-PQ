# Actual g^3 quartet: stopped prospective candidate test

Sole authority: project_state.json v113, 34/39, unchanged. The whole Spin(10)
x global U(1)PQ investigation remains active and incomplete. Use the QG3 V1
contract, result and frozen controls/primary/replay/comparison; validation and
bindings authenticate the bounded result without director promotion.

Both actual routes agree on six complete graph families and all 980,100
antighost/ghost pair slots. Actual and candidate each have 4,944 nonzero
physical slots and 966 canonical words, but 3,960 physical coefficients
disagree: 648 canonical residual terms. There are 3,960 xi^2 and 3,544
xi*eta_H residual slots. In common hbar*g10^3/(32*pi^2*epsilon) units,
the (12,13;12,13) residual is -16*xi^2/5. Its ap13 Euler derivative is
nonzero, so it is not a pure boundary. Full differences are preserved.

Stop at this failure. No generator, image, fitting, higher or physical loop
was added after comparison. Earlier qualified amplitudes remain intact.
Full H/M W vertices and curvature R, arbitrary widths, both odd orientations,
mixed propagators, explicit W/Q block zero and full-vector endpoint proof
are retained. All 12 homogeneous H, reality and frame checks pass; the
complete Ward/Slavnov/source/insertion system remains unproved.

Validation requires four strict own-byte fresh routes, scientific/process/
governance/delegated e5 checks, 41 protected chains and byte/metadata/state
invariance. Custody remains exit 2/seven unresolved references, never PASS.
Preflight frozen_a10_e5_quartic_g3/bindings.json after sealing; use the
auxiliary-ghost manifest before sealing. No authority or physical activation.

Next: a separately frozen measured-functional assembly/dependency audit,
with this failure and missing partner amplitudes explicit. No residual
fitting or claim of complete one-loop restoration. The g^2 longitudinal/
mixing, no-jet power/mass, broader E5/A5, scalar/PQ, fermion/Yukawa and
phenomenological obligations remain open. Shared inputs/software/analyst,
local conventions, ladder and solo-review apply without outside recruitment.
