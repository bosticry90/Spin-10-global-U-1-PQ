# Research execution handoff, V32

Supersedes V31 navigation and affected MF V3 assembly interpretation, not
authority. Baseline791ddbe. Recover current Git/processes and preflight
frozen_a10_e5_ghost_source/bindings.json after seal, MF bindings before.
Statev113/34of39 and all43 protected chains remain immutable; goal incomplete.

Read GS contractsV1/V2/result/current. Qualifying outputs controls,primary,
replay,comparison_v2. Original comparison.json correctly varies a wrong
inherited assembly and is UNQUALIFIED as actual measured-functional evidence:
MF V3 inserts ETA[mu] in gauge_source_g1, but the qualified source_vertex
projection and literal Q_B derivative have no extra metric.99 source-sector
spatial-sign differences account exactly for the entire projected difference.
Original2,052canonical/6,363physical anchored residual/source/preparation/
attempt bytes and disposition remain archived; do not count them as PASS.

New actualg^2xiJC-CC pole: evenJC,oddC,all44,550slots;683nonzero physical,
226canonical,263light-source.707triangle/444bubble coefficients, six/two
Born words; full4Lorentz/mixed/bothodd/anomalousCC-aa retained. Independent
physical10Wick/source/Q checks, widths cancel, all12localnojetH and primal/
dual/reality. Actual methods were blind to peer/prediction/completion tensors.

Corrected13-sector residue has27,971terms; selectedg^2aCC,twojets/fullrawdomain
3,539,700 has4,264rawterms but zero anchored left side and all45 Euler
derivatives. Four472term currents reconstruct it exactly without EOM. Prefix/
jet-gradient agree. This is selected joint MEASURED consistency, not full
QGamma=Delta_s restoration or a calculation of Delta_s/measure/contacts/IR.
The g^3quartet candidate obstruction staysFAIL; no fitting/adoption/image.

MF V3 gauge-source/sum and dependent Ward/Slavnov coefficient interpretations
are superseded; frozen loops/other sector scopes and byte authentication stay.
Do NOT use old full local Ward witnesses as current actual-functional data.
Next smallest authorized action: NEW prospective corrected13-sector full local
Ward reassembly/census, both B_H/A_H affine connections, full currents,
unknown Gamma/Delta/insertion complements and exact coupling/scope gates.
Then actualJB-B-C/A_H loop contract; no automatic higher/physical loop or
candidate correction. Remaining higher sources/auxiliary, nonlinear Slavnov,
W5/W6/A1-A5/quantum equivalence/IR remain open. ScalarPQ/fermionYukawa/pheno
and whole Spin(10)xglobalU(1)PQ completion also remain open.

Use current audit_a10_e5_ghost_source.py and its four own-byte fresh routes:
old original workers/preparations for controls/primary/replay, run_v2/prep5
for comparison_v2. Validation receipt owns snapshots/starts/tests/commands/
runtimes and43protected/new/state/metadata invariance. Custodyexit2/sevenrefs
neverPASS; old expensive loops/images authenticate only. Rawindex/worktree
equality before localcommit. Noreset/evidenceedit/unrelatedtermination,
physical/catalog/HB1/C5/C1_GS/matching, authoritypromotion, push/publication/
outreach. Shared dependencies/analyst disclosed, no agents/independent scientists.
