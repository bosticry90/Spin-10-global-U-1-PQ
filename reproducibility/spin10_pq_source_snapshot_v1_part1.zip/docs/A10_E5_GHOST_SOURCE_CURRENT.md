# Current E5 actual ghost-source and selected measured Slavnov checkpoint

Read [GS result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_GHOST_SOURCE_RESULT_V1.md)
and GS contracts V1/V2. Actualg^2*xi JC-C-C has683 nonzero physical coefficients;
all44,550 slots and12 local no-jet H identities agree between Born and Wick.
The corrected13-sector measured residue has27,971 canonical terms. Its
selectedg^2aCC/twojet Slavnov left side is an exact divergence:4,264 raw terms,
zero anchored density/all45 antighost Eulers, four472-term boundary currents.

Qualifying outputs: controls.json, primary.json, replay.json, comparison_v2.json.
Original comparison.json is UNQUALIFIED because inherited MF V3 assembly
inserted an extra spatial metric sign into the gauge-source pole. Original
bytes/disposition are preserved. Corrected import is fixed by the qualified
source_vertex actual pole and literal E2 Q_B conventions, not by a fit. The
exact old-to-corrected projected difference is audited. MF V3 full Ward/sum
interpretations must be reassembled before current scientific use.

Receipt/seal own qualification; preflight authenticates bytes only. Use the
ghost_source bindings after seal, measured_functional bindings before it.
Statev113/34of39 unchanged. Previousg^3candidatefail remains. Full nonlinear
restoration, unknown breakings/contacts/measure/IR and whole E5 remain open;
HB1/C5blocked,C1_GSuncalculated. Shared software/inputs/analyst; no agents or
external endorsement. Next: corrected full local Ward/census, then prospective
actualJB-B-C/A_H partners. Whole investigation active/incomplete.
