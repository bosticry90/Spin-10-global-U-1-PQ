# Open Seams

Current review policy: this is a solo project. The owner prohibits personal
outreach and permits external literature research. The
[solo-review policy](SOLO_REVIEW_POLICY_V1.md) supersedes historical specialist
recruitment and participation requirements below and supplies current versions
of the four prepared review packets. Historical evidence remains byte-bound;
unresolved scientific obligations remain unresolved.

The latest [physical-action reconciliation](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_PHYSICAL_ACTION_RECONCILIATION_RESULT.md)
derives an inactive factorized classical candidate with the existing scalar
representations and potential. Its exact physical Ward checks pass while the
literal frozen A10 counterexample remains nonzero. This narrows A10's historical
complete-action interpretation and prioritizes physical-action implementation
and source/gauge-fixing reconciliation. Phase C remains stopped; 34/39,
project_state, HB1/C5 and finite C1_GS are unchanged.

## Current state

The separately admitted canonical Spin(10) finite gauge/scalar two-loop
threshold seam, `CANONICAL_SO10_FINITE_GAUGE_SCALAR_TWO_LOOP_THRESHOLD_C1_GS`,
is active. Its question is whether the missing finite centered `C1_GS`
threshold can materially alter the frozen benchmark's direct gauge mismatch.
The calculation is active but blocked at its M08 prerequisites; no finite
threshold has yet been obtained.

[`project_state.json`](../project_state.json) is the sole machine-readable
authority. It records the M08 C5 H-basic qualification sequence blocker,
`M08_C5_H_BASIC_COCHAIN_QUALIFICATION_PENDING`. The subsequent bounded
[source-transport result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/STC_SOURCE_TRANSPORT_RESULT.md)
localizes its unresolved prerequisite to the source-formalism consistency
problem, `M08_C5_EQUIVARIANT_SOURCE_FORMALISM_REQUIRES_REDESIGN`, within the
tested transport/extension classes. This localization is not a new formal
gate verdict. Formal progress remains `34/39`; M08 attempt 1 is blocked,
attempt 2 and Layer 6 are unauthorized, and `finite_C1_GS` remains null.
See the [current dashboard](../README.md#current-project-state).

The later [full source-convention impact preflight](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SOURCE_CONVENTION_IMPACT_RESULT.md)
reconstructs the 17 candidate expressions but rejects promotion: the coherent
left-source candidate has `Q^2 K_Lambda,0=-box(u_H,0)` in its free heavy jet
sector. The new localized diagnostic is
`M08_C5_COHERENT_SOURCE_CONVENTION_NONMINIMAL_PAIRING_NOT_CLOSED`.
It identifies an additional source/nonminimal consistency prerequisite, not a
change to the formal sequence blocker or a revision of the historical tests.
Specialist semantic review remains outstanding; HB1 and C5 are not executed.

The subsequent [free nonminimal BV comparator](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/NONMINIMAL_BV_FREE_RESULT.md)
solves that small counterexample off-shell using a complete canonical
antighost/source pairing. This qualifies a free model only. The full M08
nonminimal source architecture and partial-gauge identities still require
independent derivation and specialist review. No M08 source, action, image,
scientific gate or cochain authority is changed by the comparator.

The [interacting nonminimal BV architecture preflight](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/NONMINIMAL_BV_M08_ARCHITECTURE_RESULT.md)
then stops on a field-only prerequisite: the frozen scalar/ghost rules and
certified physical scalar action give a selected `Q^2 eta` coefficient `+1`.
Independent physical Phi-tensor replay agrees. No full candidate master action,
source extension, seventeen-role replacement or catalog rebuild is reached.
The localized diagnostic is
`M08_NONMINIMAL_BV_ARCHITECTURE_SCALAR_FORWARD_SQUARE_NOT_CLOSED`, not a new
formal gate verdict. A bounded scalar/ghost convention review and external
specialist scrutiny are needed before resuming the interacting BV extension.
The free comparator and all historical records remain unchanged.

The subsequent [scalar–ghost reconciliation](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SCALAR_GHOST_RECONCILIATION_RESULT.md)
derives a coherent inactive field convention from local covariance, not from
fitting the failed coefficient. Its complete parent scalar ghost-pair test
passes (990 pairs on 328 coordinates), and the old `+1` remains a negative
control of the unchanged rules. This does not promote a full M08 repair or
clear the formal sequence blocker. Complete nonminimal source/master,
gauge-fixing and H-basic domain consistency and external specialist review
are still required before HB1/C5. No new source or catalog is constructed.

The subsequent [interacting BV control](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/INTERACTING_BV_PREFLIGHT_RESULT.md)
combines the candidate orientation and complete nonminimal pairing in a small
four-dimensional SU(2) adjoint-Higgs theory. Complete actions and all 96 columns
agree across two exact routes; the master, generator/first-jet square and
canonical gauge-fixing checks pass with the shifted vacuum retained. This
qualifies an ordinary-gauge control only. The interacting partial-gauge M08
source/domain construction and specialist semantic review remain required;
the [review packet](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/INTERACTING_BV_M08_REVIEW_PACKET.md)
identifies their obligations. No frozen M08 rule, catalog, scientific state or
HB1/C5 authority is changed.

The [small interacting partial-gauge bridge](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/PARTIAL_GAUGE_BV_BRIDGE_RESULT.md)
stops on its preregistered global Cartan-square condition: the dynamical unfixed
U(1) connection yields `delta^2 A2,mu=-g partial_mu R`, not zero. Independent
physical-component replay agrees. The missing local affine curvature action
must be reconciled with the global contraction calculus before retrying the
bridge. This diagnoses its proposed contract, not a new full-Weil `Q^2`
failure or a physical-model rejection. Complete partial master/nilpotence
qualification and full M08 reconstruction are not reached; the formal sequence
blocker and 34/39 authority remain unchanged.

The subsequent [local residual reconciliation](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/LOCAL_RESIDUAL_CARTAN_RESULT.md)
derives the independent-parameter local action and its canonical source lift.
The old `-g partial_mu R` connection square is retained and equals that local
action. Two exact implementations now agree on all 88 columns and pass the
complete bounded Cartan-square, full-Weil square, master, canonical partial
gauge-fixing and local-domain checks. Parameter substitution after source
variation is explicitly distinguished from the different field-dependent
Hamiltonian and its nonzero chain-rule term; no moment/EOM quotient is imposed.
This closes the small abelian-H control's local/global ambiguity, not M08's
full non-Abelian source architecture. A scoped semantic/architecture review,
background/dual-coordinate map and specialist scrutiny remain needed before
any replacement or catalog application. HB1/C5, the formal blocker, 34/39,
project_state.json and finite_C1_GS remain unchanged.

The subsequent [non-Abelian semantic/architecture review](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/NONABELIAN_M08_SEMANTIC_RESULT.md)
passes bounded actual-H Lie, composite-curvature and canonical nonminimal source
controls. It distinguishes quantum residual transformations (Abar inert) from
affine background Ward transformations and demonstrates, in the free limit,
the nonzero antighost-source action induced by canonical light gauge fixing.
No complete M08 master action or H-basic domain is promoted. The next small
decision is the quantum/background/transported source-domain contract and its
specialist review, before full reconstruction or catalog expansion. The three
prospective nonminimal partner types remain specifications only. All active
scientific authority and the finite threshold seam remain unchanged.

The subsequent [source-coordinate/domain candidate](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SOURCE_DOMAIN_TRANSPORT_RESULT.md)
passes a small actual-H source-kinematic test of the pre-light quantum-basic
domain, separate background Ward condition and canonical gauge-fixing transport.
Both routes agree on 160 stored columns; keeping raw quantum source operations
after fixing fails a non-total-derivative control. This is a one-derivation,
source-only construction, not the full interacting M08 action or a proof of
complete counterterm coverage. The legacy source-component decoder, full heavy
and shifted-scalar master construction, catalog descent and specialist review
are still required. The prospective nine pair types remain inactive; no active
source, formal blocker, gate, finite threshold or HB1/C5 permission is changed.
The [specialist review packet](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SOURCE_DOMAIN_SPECIALIST_REVIEW_PACKET.md)
contains questions, not an endorsement or a completed external review.

The later [historical-source decoder preflight](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SOURCE_COMPONENT_DECODER_RESULT.md)
qualifies bounded coordinate triangles for the six original source couplings,
including the light evaluation/carrier Gram bridge and induced brackets. This
closes only that component-decoding prerequisite; it does not certify the legacy
source operation or the full interacting domain. A separately scoped interacting
reconstruction proposal may now be prepared, but no replacement, prospective
source, catalog expansion or HB1/C5 calculation is authorized. Full nonminimal
field semantics, master identities, domain/descent and specialist review remain
required. The authoritative state and finite threshold seam are unchanged.

The [interacting M08 reconstruction proposal](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/INTERACTING_M08_RECONSTRUCTION_PROPOSAL_V1.md)
specified the next possible bounded preflight and the later full-action,
joint-domain, catalog-descent and specialist-review acceptance gates. At that
checkpoint its status was `SPECIFIED_NOT_EXECUTED`. Preparing the proposal did
not authorize an interacting test, source activation, active M08 replacement or
HB1/C5 calculation. The next decision then was owner review of the architecture
and smallest actual-H test contract, not immediate full reconstruction. Formal authority,
scientific state, finite threshold and unresolved historical custody are unchanged.

The subsequent owner-authorized [Phase A/B actual-H preflight](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/INTERACTING_ACTUAL_H_PREFLIGHT_RESULT.md)
qualifies an inactive interacting gauge-kinetic model on [0,1,4,11], including
canonical sources, local quantum/background operations, gauge-fixing transport
and structural joint-domain preservation. The primary and replay agree exactly
on all 480 stored columns and the complete bounded records. This closes only
the smallest interacting actual-H preflight prerequisite. It neither repairs
historical M08 nor qualifies its complete shifted scalar, heavy coset, R_H,
nonminimal AST, counterterm completeness or catalog descent. A separate owner
decision is needed for Phase C; no full reconstruction, active source or HB1/C5
execution follows automatically. Independent specialist review is outstanding;
the [prepared packet](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/INTERACTING_ACTUAL_H_SPECIALIST_REVIEW_PACKET.md)
has not been sent or endorsed. The current scientific blocker, 34/39, finite
C1_GS seam and unresolved historical custody (exit 2) remain unchanged.

The earlier [project-wide seam-selection refresh](PROJECT_WIDE_SEAM_REFRESH.md)
is a historical search disposition: it admitted no additional broad research
seam from the inputs it compared. It does not cancel or describe the present
state of this separately admitted particle-physics calculation. No new gravity,
cosmology, ontology or flavor calculation is admitted by this clarification.

## Historical resolved and deferred seams

The records below retain their original bounded outcomes. Their deferred
flavor/threshold continuations are distinct from the active `C1_GS` lane.

The first admitted seam, `BK_SO10_HEAVY_VECTOR_PS_TO_D6_BNV_SMEFT`, resolved `PASS` at its tree-level authority ceiling. The [admission record](BABU_KHAN_SO10_BNV_MATCHING.md) and [calculation result](../calculations/bk_so10_bnv_matching/RESULT.md) preserve the derivation and qualification.

The focused [Pati-Salam literature audit and admission record](BABU_KHAN_PS_RUNNING_AND_MI_MATCHING.md) found reusable gauge-leading-log and tree-level matching machinery and admitted the next bounded seam. Its [calculation result](../calculations/bk_ps_bnv_running_mi_matching/RESULT.md) resolved `PASS` at the one-loop gauge-leading-log and tree-level `M_I` matching ceiling.

The subsequent [`H_T` threshold audit](BABU_KHAN_HT_THRESHOLD_AUDIT.md) corrected the interval sextet attribution: `Sigma_1=(6,1,1)` from `126_H`, not high-scale `H_T`, supplies the published Pati-Salam beta contribution. The numerical running result is unchanged. The proposed separate `H_T` running branch was not admitted; a future numerical high-scale threshold-systematics seam requires a frozen spectrum benchmark and downstream quantitative need.

The focused [SMEFT-plus-`N` running and singlet-neutrino threshold audit](BABU_KHAN_SMEFT_N_THRESHOLD_AUDIT.md) found that the complete one-loop BNV gauge-plus-Yukawa running equations already exist. It did not admit the proposed `M_I`-to-first-`N`-threshold seam because the source construction does not freeze the numerical fermion fit, physical singlet-neutrino masses and ordering, or common flavor basis needed by those equations. The `Q_qqdN` threshold must also be either matched into a declared dimension-seven BNV basis or omitted under an explicit bounded truncation. The next prerequisite is to identify and validate one attributable Babu-compatible fermion-fit benchmark; it is not an active seam or calculation.

The [published-fit provenance audit](BABU_KHAN_FERMION_FIT_PROVENANCE_AUDIT.md) found reconstructible numerical fits in related two-matrix SO(10) constructions, including the very point Babu-Khan quotes. Their published scale, breaking-chain and scalar-vev assumptions prevent direct adoption as the frozen Babu-Khan `M_I` input. No fit was selected or reconstructed. A separate decision would be required to admit a model-specific re-fit or to compare another source theory; neither is active.

Those records do not activate SMEFT/SMNEFT evolution below `M_I`,
right-handed-neutrino thresholds, LEFT/chiral matching, lifetime calculations,
or a switch to another source theory. Their historical non-admission must not
be read as an absence of the separately active finite gauge/scalar seam.

## Definition

A seam is a specific missing derivation, compatibility relation, recovery map, or explanatory connection between already identified parts of the scientific scaffold.

A seam is not:

- a famous unsolved problem named without a project-specific relation;
- a broad subject area;
- a desired theory or mechanism;
- an invitation to speculative calculation;
- a software feature or directory proposal.

## Admission requirements

An active seam must state:

1. the two or more scientific domains or objects being connected;
2. the exact missing relation;
3. the empirical or theoretical obligation motivating it;
4. the assumptions already fixed;
5. a falsifiable acceptance condition or stopping boundary;
6. the maximum authority its resolution could earn.

For example, “quantum gravity is unsolved” is not a seam. A controlled threshold-matching relation between a frozen unified matter sector and a specified low-energy effective theory could become one once its inputs and acceptance conditions are defined.

## Lifecycle

Potential seams are first compared with established literature and external frameworks. A seam is added to `project_state.json` only when it is precise enough to drive a calculation. It is removed or reclassified when resolved, refuted, absorbed into known physics, or shown to be underdefined.
