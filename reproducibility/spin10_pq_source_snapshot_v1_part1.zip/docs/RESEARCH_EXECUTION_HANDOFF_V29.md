# Research execution handoff, V29

SupersedesV28 navigation; soleauthority project_state.json v113/34 of39.
Whole Spin(10) x globalU(1)PQ active/incomplete. RecoveractualGit/processes
and preflightauxiliary-ghost manifest afterseal; auxiliary-derivative before.
Readprospective AG1/AG2 contract/result/current; no draftacceptance.

Actualg² JLambda BoxC qualifies andmatches currentcompleteinactive member:
2025Boxcoefficients,20250symmetricmomentumcomponents, all45source/ghost rows,
allfour diagonaleta weights/sixoffdiagonalzeros. A=diag(0_H,-C_H),56nonzero
physical/rank32,128canonicalallfour words, witnessA13,13=-8/5 withcommon
hbar g²/(32pi²epsilon). Born/Fourier versusorderedroutedWick, literalGF/source
versusphysical10Casimir agree. External source/ghostbothODD. All12homogeneousH,
frame/real and45ghost/mixedprincipalreference checks pass; fulllocaljetWard
requires partners,notclaimed.

Full sourcecubic180 andquartic836 retained. Cubicexternalghost leavesone
integratedleg zeroHessian. Quartic tadpole novertexjets/totalexternalmomentum0:
two-jet coefficient0 BEFOREintegration; profile2 retained, whole no-jet
cutoffpower/masslog notqualified. Mixed/odd bubbleprofile4, unitBox weights
(+1,-1,0) fora/C/Bderivatives. FullGFcurrent kernelsum0; internalBkernel
nonzero thoughitsBoxresidue0. All6688scalar/Orbit ghostcubics cannot supply
lightanti edge. Widths/xi drop byedge screening; lowerchannels graphzero.
UVdegree-2 power,-3 odd,-4 quadraticlog separated aboveR_UV>0; heatTaylor
finite/powernotlog. No scaleless/finiteIR inference.

Threeordinarysecond-jet reps andcompletecurrents retained. Candidate full
g² density/effective128words, current0, difference0 andlower0; odd-source
EL signeddeletion agrees, wrongeven-source EL residual -16BoxCp13/5.
No newimage/fitting/adoption, otherhigher/physicalloops or g3actualquarter.

Failedcontrols attempt1 exactsource/start/stdout retained atprep1: primary
linearpolynomial exactly0 hitnonzeroLaurentdegreeassertion. Currentguard
returns exact0 beforeall nonzero degreechecks; replayodd linearangle0.
Goodcontrols attempt2/prep2, actualroutesprep3, comparisonprep4. Fourstrict
own-bytefresh routes/scientific-process-governance/delegatede5,40chains,
protected/new/state/metadata invariant required. Custodyexpected2/seven,
neverPASS. Preserveany validationfailures; oldexpensiveloops/images only
authenticate. RawGitindex/worktree identicalbeforelocalcommit.

Nextcentral action: NEWprospective fullactualg³ four-ghost contract against
unchanged966prediction, all45odd directions/980100slots, allcoupling/width/
H-M sectors, fullpropergraph inventory, distinctBorn/Wick-or-Schur replay,
exactUVclassification. FirstmismatchSTOP, nofit. Lowerg² longitudinalgauge/
auxiliarymixing, no-jet power/mass andotherhigher predictions remain
visible/unqualified; no silentacceptance ofthem fromthismatch.

No catalog/physical/HB1/C5/C1_GS/matching, promotion/adoption or external
action. FullE5/A5/Ward/contact/IR/anomaly,global scalar/PQ,fermion/Yukawa/
phenomenology andwholegoalunfinished. Sharedinputs/software/arithmetic/
analyst, localconventions/ladder/soloreview withoutoutsiderecruitment apply.
