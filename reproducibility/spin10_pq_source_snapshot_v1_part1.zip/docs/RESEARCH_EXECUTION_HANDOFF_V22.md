# Research execution handoff, V22

Navigation supersedes V21; authority is unchanged project_state.json v113,
34/39. Recover actual Git/processes. After seal explicitly authenticate the
full-shear-space manifest; before seal authenticate the normalization-types
manifest. Read the shear-space contract/result/current checkpoint. The whole
goal remains active/incomplete; historical custody exit 2/seven, never PASS.

The complete H-equivariant Jaux a C family has 91,125 raw slots, 1,205
Cartan-zero slots, 4,416 nonzero covariance rows over the full output domain,
and 125 real directions. Exact DomainMatrix and independent sparse reduction
agree with a distinct full Weyl character calculation (order 12). All eight
light/heavy sectors and all 45 ghosts remain. This is a local connected-H
classification, not a global quotient or general counterterm theorem.

All 125 complete Q images agree with direct full-density first variation.
Preserve source/evaluation duality, typed OrbitPullback, all backgrounds and
both width parameters. The quartet map has rank 86/kernel 39. Source,
derivative-gauge and auxiliary-cubic maps are injective. The shared fixed
subalgebra gives exact canonical simultaneous flows, nonlinear jets and field
Berezinian one; composite expectations/insertions/contacts and A5 remain open.

Only after completed space/image agreement was the actual quartet opened.
The full 5,528-slot residual belongs to the image. Preserve its whole affine
solution, 15-nonzero-coefficient free-zero representative, 11,780-coefficient
complete representative image and all 39 complete kernel images. No tensor
subset or physical coefficient was fitted; no subtraction chosen. Prior actual
quartic/cubic/ghost/source failures remain. Source-free repair is still
obstructed under the prior matches. Actual 32/25 Euler witness remains intact.

Next smallest authorized step: a new prospective contract for actual
nonminimal-source/derivative-gauge/auxiliary-cubic companions against the full
affine solution, with complete coupling and reference-width/graded graph
coverage. Required image injectivity constrains all remaining coefficients.
Do not import textbook linear antighost equations, auxiliary elimination or
false heavy projected closure. No new loops or JC-C-C/JB-B-C were run here;
membership does not itself unlock withheld amplitudes or full restoration.

Receipt owns tests, fresh own-byte independent space routes followed by
dependent membership, 33 parent chains and protected/new/state/metadata checks.
Qualified old loops are authenticated, not rerun. Preserve all failed runs,
including the earlier 152-row wrong-carrier H failure and grading diagnostic.
Validate before local commit and compare Git-index raw bytes. Shared inputs,
software and analyst/solo review remain disclosed; no external endorsement.

No catalog/physical activation, HB1/C5/C1_GS/matching, authority promotion,
outreach/publication/push. Full E5/A5/Ward/IR/anomaly, scalar/PQ global and
fermion/Yukawa/phenomenology remain open. Do not shrink the original goal.
