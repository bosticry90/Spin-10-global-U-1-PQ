# Research execution handoff, V13

Navigation supersedes V12, not authority. Baseline 2f1bdf2. Recover Git/process
state and [the latest checkpoint](A10_E5_FULL_HESSIAN_CURRENT.md). Before seal
select frozen_a10_e5_nonzero_regulator/bindings.json; afterward select the new
frozen_a10_e5_full_hessian/bindings.json explicitly. Generic preflight/e5
delegations remain older audits, not latest scientific acceptance.

The complete E2 Hessian includes all34 physical terms and68,254 polynomial
monomials:391 physical graphs,354,321 polynomial Hessian coefficients,
73,218 source coefficients,2,455 g=0 coefficients. Source terms have minimum
g powers1/2; the actual xi ghost interaction survives g=0. Every coefficient
is traversed in canonical streams; four sample rows are not coverage.
Replay Euler columns MUST include the first-variation boundary current.

Full643 reference inverses and all413,449 literal free GF entries match.
Keep553 even/90 odd fields,643 external sources,48 external H backgrounds.
Use the qualified constant45-frame inverse factored through12/33 blocks;
never require another generic dense643 inverse. Odd block signs and free
Lorentz weights matter. All45 auxiliary-auxiliary Green entries are zero;
do not eliminate auxiliaries, invert widths/g or call this whole Hessian
a positive Laplace operator. Scalar reference masses are temporary, with
their difference subtracted in interactions; physical parameters are frozen.

Finite Born words use F=exp[-(-Dbar_H^2)/Lambda^2], G=F Gref F^ST and full
deltaH. Retain Gamma_ref[background], Wick/contour normalization and stipulated
IR restriction. Finite UV at each fixed order is not all-loop renormalization,
physical IR removal, full quantum restoration or a calculated C1_GS.

Full source symmetry variations are required for Hessian congruence, though
sources are fixed during fluctuation differentiation. Five-field control has
zero master/congruence residual; freezing QJ gives20 defects. Its genuine
regulated one-loop breaking matches its insertion and is NONZERO. This
control is not a full643-field amplitude. Actual xi ghost heat bubble has
exact E1 expression and local analytic-MS scheme difference. q^2>0 only.
The g=0 source normalization is realized for this ordinary loop family;
do not infer all counterterm/contact or weighted gF quantum A5 equivalences.

Preserve four excluded preflights and immutable completed bytes. The original
core primary has an archived helper binding; the heat primary has an archived
module binding. Exceptions apply only to those original receipts. Fresh runs
must bind current files strictly and reproduce original bytes. The E1 infinity
limit uses a proved exponential bound, not an assumed CAS limit evaluation.

Before receipt use seal_a10_e5_full_hessian.py --process-snapshot. Then
export_a10_e5_full_hessian_receipt.py runs299 regressions, two fresh logical
routes/four artifacts,24 predecessor chains, protected/state/new SHA checks,
metadata audit and strict custody2/seven. No derivation edits during validation.
Seal and stage raw validated bytes; compare index bytes, check whitespace,
local commit only. Keep existing per-path archived-CRLF Git attribute.

Next scientific action: actual nonzero-g one-loop local Ward/ST breaking and
restoration, including reference/regulator and insertion/contact normalization.
No fullM2–M5/A1–A5,E5,anomaly,IR or quantumA5 acceptance. Statev113/34of39,
M08/HB1/C5 blocked,C1_GS uncalculated. No source activation/removal, catalogs,
matching, authority change, contact, publication or push. Whole Spin(10)xU(1)PQ
goal remains active/incomplete, with global boundedness, PQ quotient,
fermion/Yukawa and phenomenology open. Solo review/shared dependencies apply.
