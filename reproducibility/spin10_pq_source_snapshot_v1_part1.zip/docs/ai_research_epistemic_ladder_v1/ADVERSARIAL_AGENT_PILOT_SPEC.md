# Bounded adversarial-agent pilot specification

## Purpose and authority

This specification defines a four-role research cell:

```text
CONSTRUCTOR -> VERIFIER -> FALSIFIER -> TRANSLATOR
```

It is not authorization for a large swarm, does not start an agent run, and
does not modify a scientific gate. A pilot may be launched only for a bounded,
preregistered task with immutable inputs and an explicit budget.

## Shared rules

- The scientific contract and immutable input hashes are fixed before work.
- Every role writes a separately hashed artifact.
- No role can promote scientific authority directly.
- The existing gate adjudicator remains the only promotion route.
- Disagreement is preserved; it is not averaged into consensus.
- Model-instance multiplicity alone is not treated as independence.
- Prompts, retrieved sources, code commits, tool/runtime identities, and
  timestamps are retained subject to security and licensing constraints.

## Role contracts

### Constructor

Receives:

- immutable action/basis/data inputs;
- the scientific contract and acceptance criteria;
- permitted tools and resource budget.

May produce a candidate derivation, implementation, inventory, or proof.

Must not see expected evaluator outputs unless the contract explicitly marks
them as post-freeze comparators.

### Verifier

Receives:

- the same immutable scientific inputs;
- the acceptance criteria;
- the constructor's final claim only after the verifier's own inventory or
  method is frozen.

Must not receive constructor chain-of-thought, intermediate notebooks,
derived graph lists, symmetry factors, residue tables, or fitted parameters.

Uses a different representation or algorithm wherever the contract requires
independence. Reports agreement and disagreement at the full operator or
artifact level, not only at an aggregate scalar.

### Falsifier

Receives:

- immutable inputs and acceptance criteria;
- the frozen promoted candidate claim;
- a failure-mode catalogue.

Must not receive instructions to make the claim pass. Searches for
counterexamples, missing cases, convention changes, out-of-basis structures,
semantic gaps, adversarial parameter points, and dependence on unearned
assumptions.

A falsification artifact distinguishes a genuine contradiction from missing
coverage or insufficient tooling.

### Translator

Receives only frozen evidence and adjudication artifacts after calculation.

Produces:

- a minimal dependency graph;
- decisive equations or lemmas;
- a concise mechanism account;
- scope and authority ceiling;
- failed alternatives;
- physical meaning and empirical connection;
- unresolved epistemic debt.

The translator may not alter residues, evidence, or gate status. If a compact
explanation is unavailable, it records `COMPRESSION=EXPLANATORILY_OPEN` or
`PARTIAL` rather than weakening the calculation.

## Information-flow certificate

Every pilot records a matrix of allowed inputs. At minimum it must prove:

| Artifact class | Constructor | Verifier | Falsifier | Translator |
| --- | --- | --- | --- | --- |
| Immutable scientific inputs | yes | yes | yes | frozen references |
| Acceptance criteria | yes | yes | yes | yes |
| Constructor intermediates | yes | no | no | no |
| Primary derived inventory | yes | no before freeze | only after candidate freeze | frozen evidence only |
| Primary final claim | produced | after independent freeze | yes | yes |
| Expected answer | comparator only if preregistered | comparator only after freeze | comparator only after freeze | may report provenance |

Any breach narrows the claimed independence and must be recorded.

## Stopping and adjudication

- `PASS`: the existing scientific gate, not the agent cell, determines pass.
- `BLOCKED`: missing coverage, unavailable tool, incomplete replay, or
  unresolved semantic map stops promotion.
- `FAIL`: only a complete and reproducible contradiction under the frozen
  failure rules earns failure authority.

The pilot terminates at its bounded budget or first contract-defined stopping
condition. It does not recursively spawn an open-ended organization.

## Suggested first use

The current M08 operator-closure problem is a suitable future pilot because
constructor and replay independence are scientifically material. This
specification does not launch that pilot and must not delay M08. A lower-risk
dry run may use the already-passed M06 result to test artifact isolation
without re-adjudicating M06.

## Non-goals

- reproducing a 10,000-agent research program;
- treating agent count as independent evidence;
- replacing formal proof, numerical validation, peer review, or experiment;
- allowing explanation quality to override a verified calculation;
- permitting downstream gates to compensate for an earlier non-pass.
