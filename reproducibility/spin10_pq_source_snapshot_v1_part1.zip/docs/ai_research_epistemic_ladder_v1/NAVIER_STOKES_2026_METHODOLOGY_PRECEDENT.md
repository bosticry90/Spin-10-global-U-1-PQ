# 2026 Navier-Stokes project: methodological precedent only

## Classification

This record classifies the 2026 OpenAI Navier-Stokes project solely as an
external methodological precedent for AI-assisted discovery, formalization,
provenance, evaluation, and explanatory compression.

It is explicitly prohibited as scientific evidence for:

- canonical Spin(10);
- gauge unification;
- bounded-from-below status;
- `C1_GS`;
- quantum gravity or any ToE physical hypothesis;
- any promotion in `TWO_LOOP_QFT_COMPILER_V1`.

## Recorded methodological observations

The OpenAI announcement reports a forced Navier-Stokes construction, an
AI-assisted research effort involving on the order of 10,000 concurrent
agents, and a subsequent Lean formalization. The public formalization
manifest maps informal results to Lean declarations, reports zero admitted
`sorry` placeholders for the stated main results, lists its axioms, and labels
its review status as self-assessed.

The Clay Mathematics Institute subsequently described the problem as
“apparently” settled while retaining its deliberately slower evaluation and
credit process.

Together these sources illustrate four distinct states:

```text
machine-checked
semantically aligned
externally accepted
humanly understood
```

None should be inferred automatically from another.

## Sources and retrieval provenance

Retrieved 2026-09-23:

1. OpenAI, “On the Navier-Stokes Millennium Prize Problem”:
   <https://openai.com/index/navier-stokes-solution/>
2. Clay Mathematics Institute, “Navier-Stokes Announcement”:
   <https://www.claymath.org/news/navier-stokes-announcement/>
3. OpenAI, `NavierStokesAndEuler` repository:
   <https://github.com/openai/NavierStokesAndEuler>
4. OpenAI formalization manifest:
   <https://github.com/openai/NavierStokesAndEuler/blob/main/formalization.yaml>

The external project is not imported as a code, theorem, or data dependency.
Future changes in its review status may warrant a new dated precedent record;
they do not retroactively alter this snapshot.
