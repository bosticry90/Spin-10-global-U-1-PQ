"""Read-only, bounded search for ORIGINAL recorded raw bytes, never a rehash fix."""
from hashlib import sha256
import base64
import json
import os
from pathlib import Path
import subprocess
import sys
import zlib

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def git(*args, check=True):
    return subprocess.run(["git", *args], cwd=ROOT, capture_output=True, check=check,
                          env=dict(os.environ, GIT_OPTIONAL_LOCKS="0", GIT_NO_REPLACE_OBJECTS="1"))


def build():
    manifest = json.loads((HERE / "methodology_manifest.json").read_text())
    bindings = {}
    for name in manifest["sidecars"]:
        record = json.loads((HERE / name).read_text())
        for ref in record["provenance"]["source_artifacts"]:
            key = (ref["path"], ref["file_sha256"])
            bindings.setdefault(key, []).append(record["record_id"])
    paths = sorted({p for p, _ in bindings})
    objects = git("rev-list", "--objects", "--all", "--reflog", "--", *paths).stdout.decode().splitlines()
    versions = {p: {} for p in paths}
    for line in objects:
        oid, _, path = line.partition(" ")
        if path not in versions:
            continue
        sys.audit("open", str(ROOT / path), "r", 0)
        data = git("cat-file", "blob", oid).stdout
        versions[path][oid] = data
    # Inventory named ToE locations, not all user documents or other projects.
    documents = ROOT.parent
    candidates = {ROOT, documents / "ToE-Next-active-data",
                  Path.home() / "OneDrive" / "ToE-Next",
                  Path.home() / "OneDrive" / "Documents" / "ToE-Next"}
    for entry in documents.iterdir():
        if "toe" in entry.name.casefold() and entry.is_dir():
            candidates.add(entry)
    existing = sorted((p for p in candidates if p.is_dir()), key=str)
    basenames = {Path(p).name for p in paths}
    copies, archives = [], []
    seen = set()
    for root in existing:
        for directory, children, files in os.walk(root, followlinks=False):
            children[:] = [c for c in children if c not in (".git", "__pycache__")
                           and not (Path(directory) / c).is_symlink()
                           and not (getattr((Path(directory) / c).lstat(), "st_file_attributes", 0) & 1024)]
            for name in files:
                path = Path(directory) / name
                if name.lower().endswith((".zip", ".7z", ".tar", ".bundle", ".bak")):
                    archives.append(str(path))
                if name not in basenames or str(path) in seen:
                    continue
                seen.add(str(path))
                copies.append({"path": str(path), "sha256": sha256(path.read_bytes()).hexdigest()})
    records = []
    for (path, expected), record_ids in sorted(bindings.items()):
        exact_git = [oid for oid, data in versions[path].items() if sha256(data).hexdigest() == expected]
        exact_copies = [copy["path"] for copy in copies if Path(copy["path"]).name == Path(path).name and copy["sha256"] == expected]
        diagnostics = []
        for oid, data in versions[path].items():
            if sha256(data.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")).hexdigest() == expected:
                diagnostics.append(oid)
        records.append({"path": path, "original_expected_sha256": expected, "sidecar_record_ids": record_ids,
                        "distinct_reflog_and_ref_git_blobs_checked": len(versions[path]),
                        "exact_git_blob_matches": sorted(exact_git), "exact_working_copy_matches": sorted(exact_copies),
                        "CRLF_conversion_diagnostic_only": sorted(diagnostics),
                        "custody": "RAW_BYTES_MATCH_HISTORICAL_BINDING_UNRESOLVED" if exact_copies or exact_git else "UNRESOLVED",
                        "original_snapshot_Git_binding_authenticated": git("rev-parse", f"{manifest['snapshot_commit']}:{path}").stdout.decode().strip() in exact_git})
    remote = git("ls-remote", "--heads", "--tags", "origin", check=False)
    reflog = sorted(set(git("reflog", "--all", "--format=%H").stdout.decode().splitlines()))
    return {"schema": "BOUNDED_HISTORICAL_CUSTODY_SEARCH_V1", "search_HEAD": git("rev-parse", "HEAD").stdout.decode().strip(),
            "recorded_snapshot": manifest["snapshot_commit"], "original_hashes_modified": False,
            "binding_count": sum(len(v) for v in bindings.values()), "unique_path_digest_count": len(bindings),
            "distinct_reflog_commit_count": len(reflog), "records": records, "searched_named_roots": [str(p) for p in existing],
            "absent_named_roots": sorted(str(p) for p in candidates if not p.is_dir()), "matching_basename_copy_count": len(copies),
            "archive_candidates": sorted(set(archives)), "registered_worktrees": git("worktree", "list", "--porcelain").stdout.decode().splitlines(),
            "remote_ref_inventory": {"exit_code": remote.returncode, "refs": remote.stdout.decode().splitlines()},
            "limits": ["No original raw bytes manufactured by line-ending normalization.", "No fetch, remote mutation or remote object download.",
                       "A live byte match authenticates content against the old digest, not its creation date or original Git binding.",
                       "No off-machine or inaccessible cloud backup search; only named local ToE roots.",
                       "Unreferenced dangling Git objects and unrelated Codex VPC worktree contents not searched.",
                       "Archives listed, not unpacked; any archive candidate requires separately bounded member inspection."]}


def capture_matching_live_bytes():
    """Lossless stdout-only preservation, NOT original-date/source authentication."""
    manifest = json.loads((HERE / "methodology_manifest.json").read_text())
    recovered = {}
    for name in manifest["sidecars"]:
        record = json.loads((HERE / name).read_text())
        for ref in record["provenance"]["source_artifacts"]:
            path, expected = ref["path"], ref["file_sha256"]
            if not (ROOT / path).is_file():
                continue
            raw = (ROOT / path).read_bytes()
            if sha256(raw).hexdigest() == expected:
                recovered[path] = {"original_expected_sha256": expected, "byte_count": len(raw),
                                   "zlib_base64": base64.b64encode(zlib.compress(raw, 9)).decode("ascii")}
    return {"schema": "RECORDED_DIGEST_MATCHING_BYTES_CAPTURE_V1", "capture_HEAD": git("rev-parse", "HEAD").stdout.decode().strip(),
            "original_snapshot_binding_authenticated": False, "line_endings_transformed": False,
            "origin": "Actual unchanged live bytes, captured only after exact raw SHA256 equality; no reconstruction from Git or newline conversion.",
            "recovered": recovered}


def authenticate_capture(payload, expected_by_path):
    """Verify content only; never upgrade original historical Git provenance."""
    if not __debug__:
        raise RuntimeError("CUSTODY_AUTHENTICATION_REQUIRES_ASSERTIONS_ENABLED")
    assert payload["schema"] == "RECORDED_DIGEST_MATCHING_BYTES_CAPTURE_V1"
    assert payload["original_snapshot_binding_authenticated"] is False
    assert payload["line_endings_transformed"] is False
    for path, item in payload["recovered"].items():
        assert path in expected_by_path, "UNRECORDED_SOURCE_PATH"
        assert item["original_expected_sha256"] == expected_by_path[path], "ORIGINAL_HASH_CHANGED"
        raw = zlib.decompress(base64.b64decode(item["zlib_base64"], validate=True))
        assert len(raw) == item["byte_count"], "BYTE_COUNT_MISMATCH"
        assert sha256(raw).hexdigest() == expected_by_path[path], "RECOVERED_BYTES_MISMATCH"
    return len(payload["recovered"])


if __name__ == "__main__":
    print(json.dumps(capture_matching_live_bytes() if "--capture-matches" in sys.argv else build(), indent=2, sort_keys=True))
