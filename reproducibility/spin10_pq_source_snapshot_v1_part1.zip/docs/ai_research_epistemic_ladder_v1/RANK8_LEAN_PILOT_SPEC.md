# Rank-eight Lean formalization pilot

## Authority boundary

This is a specification for a non-blocking formalization pilot. It does not
formalize a result, change the earned `UVP_P13` verdict, alter the active M08
critical path, or create scientific authority.

`FORMALIZATION=PASS` may be recorded only after the implementation described
here exists, builds from a pinned dependency manifest, contains no admitted
placeholders in the promoted dependency closure, and passes semantic review.

## Informal claim

For an integrable rotationally invariant rank-eight Euclidean tensor moment,

```text
Integral k_(mu1)...k_(mu8) f(k^2)
  = Sym_105[delta_(mu1 mu2) delta_(mu3 mu4)
            delta_(mu5 mu6) delta_(mu7 mu8)]
    / (d (d+2) (d+4) (d+6))
    * Integral (k^2)^4 f(k^2).
```

The symmetrized tensor contains exactly `(8-1)!! = 105` unique perfect
pairings. Contracting an index pair must reproduce the rank-six isotropic
identity with exact residual zero.

## Formal decomposition

The pilot should not begin with measure theory. It should prove three mapped
layers whose assumptions are explicit.

### L1 — combinatorics

- Define perfect matchings of `Fin 8` without ordered-pair or pair-order
  duplication.
- Prove that their cardinality is `105`.
- Prove invariance of the pairing sum under all permutations of the eight
  external slots.

### L2 — tensor algebra

- Work in a finite-dimensional real inner-product space of dimension `d`.
- Define the rank-eight metric-pairing sum.
- Prove the contraction recursion from rank eight to rank six.
- Prove the normalization denominator `d*(d+2)*(d+4)*(d+6)` under the stated
  nonzero-denominator assumptions.

### L3 — analytic lifting

- State integrability and finite eighth radial-moment assumptions.
- State rotational invariance of the measure/integrand or of the induced
  moment functional.
- Prove that the tensor moment is proportional to the invariant pairing sum.
- Use the L2 contraction result to identify the scalar coefficient.

If the analytic uniqueness theorem needed by L3 is not reasonably available
in Mathlib, L1 and L2 may be completed first with `FORMALIZATION=PARTIAL`.
They must not be mislabeled as a formal proof of the full integral identity.

## Proposed declarations

Names are provisional until implementation review:

```text
rankEightPerfectMatchings_card
rankEightPairingTensor_permInvariant
rankEightPairingTensor_contract
rankEightIsotropicMoment
```

The final manifest must map each declaration to the corresponding sentence in
the informal claim.

## Assumptions and trust boundary

Record explicitly:

- Euclidean versus Minkowski signature;
- `d` as a natural dimension and the conditions excluding zero denominators;
- integrability and moment-existence hypotheses;
- rotational-invariance hypothesis;
- proof-assistant kernel, Lean version, Mathlib revision, and build tool;
- any classical-choice or quotient axioms reported by the environment.

No statement about dimensional regularization at non-integer
`d = 4 - 2 epsilon` is earned merely by formalizing the finite-dimensional
Euclidean identity. The semantic audit must state how the algebraic identity
is used analytically in the UV-pole compiler.

## PASS requirements

- pinned Lean and Mathlib versions;
- reproducible clean build;
- zero `sorry`, admitted theorem, or equivalent placeholder in the promoted
  dependency closure;
- all four theorem mappings recorded;
- independent semantic-alignment review;
- comparison with the frozen `UVP_P13` convention and pairing order;
- no dependency on active M08 code or authority;
- a sidecar whose `FORMALIZATION` dimension alone is updated.

## Explicit non-goals

- formalizing the complete one-loop UV evaluator;
- formalizing the Spin(10) action or active M08 BRST machinery;
- proving dimensional regularization from first principles;
- changing `UVP_P13` scientific authority;
- blocking Layer 5 while the pilot is incomplete.
