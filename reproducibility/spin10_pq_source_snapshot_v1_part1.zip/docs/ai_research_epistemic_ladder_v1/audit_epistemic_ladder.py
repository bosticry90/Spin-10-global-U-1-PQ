"""Audit AI_RESEARCH_EPISTEMIC_LADDER_V1 sidecar governance artifacts.

This validates representation and provenance only.  It never adjudicates or
modifies a scientific gate.
"""

from hashlib import sha256
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys

from jsonschema import Draft202012Validator, FormatChecker


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ZERO = "0" * 64
# This is the commit that first froze the package, not the earlier scientific
# snapshot named by its sidecars. Never rebind it to HEAD or refresh its hashes.
HISTORICAL_PACKAGE_COMMIT = "0d3f679ed0cbb6cec6df042de50702eca0448a9c"
PACKAGE_PATH = "docs/ai_research_epistemic_ladder_v1"
MAINTAINED_ENTRY_POINTS = {
    "audit_epistemic_ladder.py", "AI_RESEARCH_EPISTEMIC_LADDER_V1.md",
}


class HistoricalReferenceUnresolved(RuntimeError):
    """The recorded historical bytes have not been authenticated."""


def repository_path(relative: str) -> str:
    path = PurePosixPath(relative)
    if (not relative or path.is_absolute() or "\\" in relative or ":" in relative
            or ".." in path.parts or path.as_posix() != relative):
        raise ValueError(f"INVALID_REPOSITORY_PATH: {relative}")
    return relative


def read_git_blob(commit: str, relative: str) -> bytes:
    """Read only the named immutable object, with no working-tree fallback.

    Subprocess pipes would otherwise bypass Python's opt-in pole-read guard.
    Emit the same path-level audit event BEFORE Git can read object bytes.
    """
    if re.fullmatch(r"[0-9a-f]{40}", commit) is None:
        raise ValueError("HISTORICAL_COMMIT_MUST_BE_FULL_SHA1")
    relative = repository_path(relative)
    sys.audit("open", str(ROOT / relative), "r", 0)
    env = dict(os.environ, GIT_OPTIONAL_LOCKS="0", GIT_NO_REPLACE_OBJECTS="1")
    kind = subprocess.run(
        ["git", "cat-file", "-t", commit], cwd=ROOT, env=env,
        capture_output=True, check=False,
    )
    if kind.returncode or kind.stdout.strip() != b"commit":
        raise HistoricalReferenceUnresolved(f"COMMIT_UNAVAILABLE: {commit}")
    result = subprocess.run(
        ["git", "cat-file", "blob", f"{commit}:{relative}"],
        cwd=ROOT, env=env, capture_output=True, check=False,
    )
    if result.returncode:
        raise HistoricalReferenceUnresolved(f"BLOB_UNAVAILABLE: {commit}:{relative}")
    return result.stdout


def verify_historical(commit: str, relative: str, expected: str) -> bytes:
    if re.fullmatch(r"[0-9a-f]{64}", expected) is None or expected == ZERO:
        raise ValueError(f"INVALID_RECORDED_DIGEST: {relative}")
    content = read_git_blob(commit, relative)
    actual = sha256(content).hexdigest()
    if actual != expected:
        raise HistoricalReferenceUnresolved(
            f"RECORDED_DIGEST_UNRESOLVED: {commit}:{relative} "
            f"expected={expected} git_blob={actual}"
        )
    return content


def file_digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def canonical_digest(payload: dict, field: str = "artifact_sha256") -> str:
    work = dict(payload)
    work.pop(field, None)
    encoded = json.dumps(work, sort_keys=True, separators=(",", ":")).encode()
    return sha256(encoded).hexdigest()


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def audit_package() -> dict:
    """Authenticate the original package and still-immutable live payloads."""
    manifest = load_json(HERE / "methodology_manifest.json")
    original_manifest = read_git_blob(
        HISTORICAL_PACKAGE_COMMIT, f"{PACKAGE_PATH}/methodology_manifest.json",
    )
    assert (HERE / "methodology_manifest.json").read_bytes() == original_manifest, (
        "HISTORICAL_MANIFEST_CHANGED"
    )
    assert manifest["contract"] == "AI_RESEARCH_EPISTEMIC_LADDER_V1"
    assert manifest["authority_effect"] == "NONE_SIDECAR_ONLY"
    assert manifest["scientific_state_modified"] is False
    assert manifest["artifact_sha256"] != ZERO
    assert manifest["artifact_sha256"] == canonical_digest(manifest)

    listed = {item["path"]: item["sha256"] for item in manifest["artifacts"]}
    assert len(listed) == len(manifest["artifacts"])
    for relative, expected in listed.items():
        repository_path(relative)
        path = HERE / relative
        assert path.is_file(), relative
        verify_historical(HISTORICAL_PACKAGE_COMMIT, f"{PACKAGE_PATH}/{relative}", expected)
        # These two current entry points have an explicitly documented repair.
        # Their original versions are checked above; current code is exercised by
        # bounded regression tests. All other frozen package bytes stay pinned.
        if relative not in MAINTAINED_ENTRY_POINTS:
            assert file_digest(path) == expected, f"FROZEN_PACKAGE_CHANGED: {relative}"
    assert set(manifest["sidecars"]) <= set(listed)
    assert "epistemic_sidecar.schema.json" in listed
    return manifest


def audit_sidecars(manifest: dict) -> tuple[list[dict], list[str]]:
    schema = load_json(HERE / "epistemic_sidecar.schema.json")
    validator = Draft202012Validator(schema, format_checker=FormatChecker())

    records = []
    unresolved = []
    for name in manifest["sidecars"]:
        record = load_json(HERE / name)
        errors = sorted(validator.iter_errors(record), key=lambda error: list(error.path))
        assert not errors, "\n".join(error.message for error in errors)
        assert record["artifact_sha256"] != ZERO
        assert record["artifact_sha256"] == canonical_digest(record)
        assert record["authority_effect"] == "NONE_SIDECAR_ONLY"
        assert "overall_status" not in record
        assert "epistemic_score" not in record
        commit = record["snapshot"]["repository_commit"]
        assert commit == manifest["snapshot_commit"], "SNAPSHOT_BINDING_CHANGED"
        for source in record["provenance"]["source_artifacts"]:
            try:
                verify_historical(commit, source["path"], source["file_sha256"])
            except HistoricalReferenceUnresolved as error:
                unresolved.append(f"{record['record_id']}: {error}")
        records.append(record)

    assert len({record["record_id"] for record in records}) == len(records)
    by_id = {record["record_id"]: record for record in records}

    m06 = by_id["AIREL_M06_SCALAR_RADIATIVE_CLOSURE"]
    assert m06["dimensions"]["VERIFICATION"]["status"] == "PASS"
    assert m06["dimensions"]["FORMALIZATION"]["status"] == "NOT_ATTEMPTED"
    assert m06["scientific_claim"]["scientific_authority_source"]["verdict"] == "PASS"

    m08 = by_id["AIREL_M08_BRST_BLOCKED"]
    assert m08["dimensions"]["VERIFICATION"]["status"] == "BLOCKED"
    assert m08["dimensions"]["INTERPRETATION"]["status"] == "OPEN"
    assert m08["scientific_claim"]["scientific_authority_source"]["verdict"] == "BLOCKED"
    return records, unresolved


def audit_current_state(project_state: dict) -> None:
    """Check this bounded lane's stable invariants, not a historical blocker."""
    compiler = project_state["scaffold"]["two_loop_qft_compiler_v1"]
    assert compiler["layer5a_M06"].startswith("PASS_RANK34")
    assert compiler["layer5a_M08"] == "BLOCKED"
    blocker = compiler["layer5a_M08_BRST_remaining_blocker"]
    assert isinstance(blocker, str) and blocker.startswith("M08_")
    assert compiler["layer5_blocker"] == blocker, "CURRENT_BLOCKERS_DISAGREE"
    assert compiler["layer6_tensor_IBP_reduction_authorized"] is False
    assert compiler["finite_C1_GS"] is None
    assert compiler["layer5a_execution_progress"] == "34_OF_39_ENGINE_27_OF_27"
    research = project_state["research"]
    assert "CANONICAL_SO10_FINITE_GAUGE_SCALAR_TWO_LOOP_THRESHOLD_C1_GS" in (
        research["active_seams"]
    )
    assert isinstance(research["active_physics_calculation"], str)
    assert "M08" in research["active_physics_calculation"]


def main() -> int:
    if not __debug__:
        raise RuntimeError("AUDIT_REQUIRES_ASSERTIONS_ENABLED")
    manifest = audit_package()
    records, unresolved = audit_sidecars(manifest)
    audit_current_state(load_json(ROOT / "project_state.json"))
    print("HISTORICAL_PACKAGE_INTEGRITY_PASS", HISTORICAL_PACKAGE_COMMIT)
    print("CURRENT_STATE_COHERENCE_PASS")
    print("SIDECARS_VALID", len(records))
    print("M06_VERIFICATION_PASS_FORMALIZATION_NOT_ATTEMPTED")
    print("M08_VERIFICATION_BLOCKED_INTERPRETATION_OPEN")
    print("SCIENTIFIC_AUTHORITY_UNCHANGED_LAYER6_LOCKED")
    print("MANIFEST_SHA256", manifest["artifact_sha256"])
    if unresolved:
        print("HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED", len(unresolved))
        for issue in unresolved:
            print(issue)
        print("NO_OVERALL_AUDIT_PASS_NO_HISTORICAL_HASH_REFRESH")
        return 2
    print("HISTORICAL_REFERENCE_INTEGRITY_PASS")
    print("AI_RESEARCH_EPISTEMIC_LADDER_V1_AUDIT_PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
