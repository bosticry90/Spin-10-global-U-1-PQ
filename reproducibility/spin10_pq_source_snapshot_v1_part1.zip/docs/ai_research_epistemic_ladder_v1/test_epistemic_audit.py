"""Bounded, read-only regressions for historical/live audit separation.

All corruption/evolution fixtures are in memory. No scientific input is edited,
no Git object is written, and no large mathematical catalog is reconstructed.
"""

from contextlib import redirect_stdout
from copy import deepcopy
from hashlib import sha256
import io
from pathlib import Path
import re
import subprocess
import sys
import unittest
from unittest.mock import patch

import audit_epistemic_ladder as audit


class HistoricalIntegrityTests(unittest.TestCase):
    def test_original_package_and_unchanged_live_payloads_are_authenticated(self):
        manifest = audit.audit_package()
        self.assertEqual(len(manifest["artifacts"]), 8)
        self.assertNotEqual(manifest["snapshot_commit"], audit.HISTORICAL_PACKAGE_COMMIT)

    def test_exact_historical_bytes_pass_without_a_current_file_read(self):
        frozen = b"immutable historical evidence\n"
        with patch.object(audit, "read_git_blob", return_value=frozen) as reader:
            with patch.object(audit, "file_digest", side_effect=AssertionError("LIVE_READ")):
                self.assertEqual(audit.verify_historical(
                    audit.HISTORICAL_PACKAGE_COMMIT, "project_state.json",
                    sha256(frozen).hexdigest(),
                ), frozen)
        reader.assert_called_once_with(audit.HISTORICAL_PACKAGE_COMMIT, "project_state.json")

    def test_corrupt_historical_bytes_do_not_pass(self):
        expected = sha256(b"original\n").hexdigest()
        with patch.object(audit, "read_git_blob", return_value=b"corrupted\n"):
            with self.assertRaisesRegex(audit.HistoricalReferenceUnresolved,
                                        "RECORDED_DIGEST_UNRESOLVED"):
                audit.verify_historical(audit.HISTORICAL_PACKAGE_COMMIT,
                                        "project_state.json", expected)

    def test_line_ending_conversion_is_not_silently_accepted(self):
        with patch.object(audit, "read_git_blob", return_value=b"original\n"):
            with self.assertRaises(audit.HistoricalReferenceUnresolved):
                audit.verify_historical(audit.HISTORICAL_PACKAGE_COMMIT,
                                        "project_state.json", sha256(b"original\r\n").hexdigest())

    def test_missing_commit_and_blob_are_unresolved_without_live_fallback(self):
        with self.assertRaisesRegex(audit.HistoricalReferenceUnresolved, "COMMIT_UNAVAILABLE"):
            audit.read_git_blob("0" * 40, "project_state.json")
        with self.assertRaisesRegex(audit.HistoricalReferenceUnresolved, "BLOB_UNAVAILABLE"):
            audit.read_git_blob(audit.HISTORICAL_PACKAGE_COMMIT,
                                "docs/ai_research_epistemic_ladder_v1/nonexistent_fixture.json")

    def test_frozen_live_record_corruption_is_still_rejected(self):
        real_digest = audit.file_digest

        def damaged(path):
            if path.name == "m08_brst_blocked.sidecar.json":
                return "f" * 64
            return real_digest(path)

        with patch.object(audit, "file_digest", side_effect=damaged):
            with self.assertRaisesRegex(AssertionError, "FROZEN_PACKAGE_CHANGED"):
                audit.audit_package()

    def test_manifest_corruption_cannot_refresh_historical_expectations(self):
        original_read = Path.read_bytes

        def damaged(path):
            if path == audit.HERE / "methodology_manifest.json":
                return b"modified historical manifest"
            return original_read(path)

        with patch.object(Path, "read_bytes", damaged):
            with self.assertRaisesRegex(AssertionError, "HISTORICAL_MANIFEST_CHANGED"):
                audit.audit_package()

    def test_git_pipes_cannot_bypass_the_path_read_guard(self):
        denied = "tools/two_loop_qft_compiler_v1/frozen_d5/never_read_fixture.json"
        with patch.object(audit.sys, "audit", side_effect=PermissionError("DENIED")) as event:
            with patch.object(audit.subprocess, "run") as git:
                with self.assertRaises(PermissionError):
                    audit.read_git_blob(audit.HISTORICAL_PACKAGE_COMMIT, denied)
                git.assert_not_called()
        event.assert_called_once_with("open", str(audit.ROOT / denied), "r", 0)

    def test_unsafe_refs_and_paths_are_rejected_before_git(self):
        with patch.object(audit.subprocess, "run") as git:
            with self.assertRaises(ValueError):
                audit.read_git_blob("HEAD", "project_state.json")
            for path in ("../project_state.json", "/project_state.json", "C:/state.json",
                         "docs\\state.json", "docs/../state.json", "docs//state.json"):
                with self.subTest(path=path), self.assertRaises(ValueError):
                    audit.read_git_blob(audit.HISTORICAL_PACKAGE_COMMIT, path)
            git.assert_not_called()

    def test_real_unresolved_references_are_not_reported_as_overall_pass(self):
        output = io.StringIO()
        with redirect_stdout(output):
            code = audit.main()
        self.assertEqual(code, 2)
        lines = output.getvalue().splitlines()
        self.assertIn("CURRENT_STATE_COHERENCE_PASS", lines)
        self.assertIn("HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7", lines)
        self.assertNotIn("AI_RESEARCH_EPISTEMIC_LADDER_V1_AUDIT_PASS", lines)

    def test_optimized_mode_is_refused(self):
        result = subprocess.run([sys.executable, "-O", str(audit.HERE / "audit_epistemic_ladder.py")],
                                cwd=audit.ROOT, capture_output=True, text=True, check=False)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("AUDIT_REQUIRES_ASSERTIONS_ENABLED", result.stderr)


class LiveCoherenceTests(unittest.TestCase):
    def setUp(self):
        self.state = audit.load_json(audit.ROOT / "project_state.json")

    def test_current_state_and_legitimate_blocker_evolution_pass(self):
        audit.audit_current_state(self.state)
        evolved = deepcopy(self.state)
        evolved["state_version"] += 1
        compiler = evolved["scaffold"]["two_loop_qft_compiler_v1"]
        compiler["layer5_blocker"] = "M08_FUTURE_BOUNDED_PREREQUISITE_PENDING"
        compiler["layer5a_M08_BRST_remaining_blocker"] = compiler["layer5_blocker"]
        evolved["research"]["active_physics_calculation"] = "TWO_LOOP_M08_FUTURE_PREREQUISITE"
        audit.audit_current_state(evolved)
        self.assertNotEqual(audit.canonical_digest(self.state), audit.canonical_digest(evolved))
        # Evolving live state does not change the historical byte expectation.
        frozen = b"old snapshot\n"
        with patch.object(audit, "read_git_blob", return_value=frozen):
            audit.verify_historical(audit.HISTORICAL_PACKAGE_COMMIT,
                                    "project_state.json", sha256(frozen).hexdigest())

    def test_authority_or_internal_coherence_drift_is_rejected(self):
        for key, value in (
            ("layer5a_M06", "PASS_RANK35"), ("layer5a_M08", "PASS"),
            ("layer6_tensor_IBP_reduction_authorized", True), ("finite_C1_GS", 0),
            ("layer5a_execution_progress", "35_OF_39_ENGINE_27_OF_27"),
            ("layer5_blocker", "M08_DISAGREES_WITH_OTHER_FIELD"),
        ):
            state = deepcopy(self.state)
            state["scaffold"]["two_loop_qft_compiler_v1"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                audit.audit_current_state(state)
        state = deepcopy(self.state)
        state["research"]["active_seams"] = []
        with self.assertRaises(AssertionError):
            audit.audit_current_state(state)

    def test_documentation_matches_live_lane_and_retains_separate_history(self):
        seams = (audit.ROOT / "docs/OPEN_SEAMS.md").read_text(encoding="utf-8")
        for seam in self.state["research"]["active_seams"]:
            self.assertIn(seam, seams)
        blocker = self.state["scaffold"]["two_loop_qft_compiler_v1"][
            "layer5a_M08_BRST_remaining_blocker"]
        self.assertIn(blocker, seams)
        self.assertIn("M08_C5_EQUIVARIANT_SOURCE_FORMALISM_REQUIRES_REDESIGN", seams)
        self.assertIn("Historical resolved and deferred seams", seams)
        self.assertNotIn("There are no active seams", seams)
        readme = (audit.ROOT / "README.md").read_text(encoding="utf-8")
        self.assertNotIn("No next calculation is currently admissible", readme)
        policy = (audit.ROOT / "tools/readiness/COMPUTATIONAL_AUTHORITY_POLICY.md").read_text(
            encoding="utf-8")
        for phrase in ("smallest decisive test domain", "prospective sequencing improvement",
                       "APPLIED", "DEFERRED", "NOT_APPLICABLE", "SPECIFIED_NOT_EXECUTED",
                       "REQUIRES_REVIEW"):
            self.assertIn(phrase, policy)

    def test_new_local_navigation_links_resolve(self):
        # Check repaired explanatory documents, not historical package prose.
        for relative in (
            "docs/OPEN_SEAMS.md", "docs/DEPENDENCY_SCAFFOLD.md",
            "tools/readiness/COMPUTATIONAL_AUTHORITY_POLICY.md",
            "docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md",
        ):
            doc = audit.ROOT / relative
            for target in re.findall(r"\[[^\]]*\]\(([^)]+)\)", doc.read_text(encoding="utf-8")):
                if "://" in target or target.startswith("#"):
                    continue
                path = target.split("#", 1)[0]
                with self.subTest(document=relative, target=target):
                    self.assertTrue((doc.parent / path).exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
