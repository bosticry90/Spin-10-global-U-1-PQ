# AI Research Epistemic Ladder V1

## Status and authority boundary

`AI_RESEARCH_EPISTEMIC_LADDER_V1` is a sidecar governance contract. It
describes what kind of knowledge a project artifact has earned; it does not
create, replace, reopen, delay, or promote scientific authority.

The sole machine-readable authority for current project state remains
[`project_state.json`](../../project_state.json). A missing or incomplete
epistemic sidecar must never block a scientific gate, change a gate verdict,
unlock a downstream layer, or supply a missing calculation.

The contract is deliberately orthogonal to `TWO_LOOP_QFT_COMPILER_V1`.
Sidecars point to immutable scientific evidence; they do not copy its
authority into a second state machine.

## Core distinction

The project records discovery as provenance, not as an authority dimension.
The independent dimensions are:

1. `PROVENANCE` — where the claim, inputs, methods, and evidence came from.
2. `VERIFICATION` — whether the claim passed its scientific acceptance test.
3. `FORMALIZATION` — whether a proof assistant has checked a mapped formal
   statement.
4. `COMPRESSION` — whether the evidence has a compact, auditable conceptual
   account.
5. `INTERPRETATION` — what the verified statement means within its stated
   scientific scope.
6. `EMPIRICAL_CONNECTION` — how, if at all, the statement is connected to
   observation or experiment.

These dimensions must not be collapsed into an average, score, grade, or
single machine-readable epistemic status. In particular:

```text
correctness != understanding != physical relevance != empirical truth
```

`VERIFIED_BUT_EXPLANATORILY_OPEN` is a permissible human-readable compound
label. It never replaces the independent dimension values.

## State vocabularies

| Dimension | Allowed states |
| --- | --- |
| `PROVENANCE` | `COMPLETE`, `PARTIAL`, `UNKNOWN` |
| `VERIFICATION` | `PASS`, `BLOCKED`, `FAIL`, `NOT_APPLICABLE` |
| `FORMALIZATION` | `PASS`, `PARTIAL`, `NOT_ATTEMPTED`, `NOT_APPLICABLE` |
| `COMPRESSION` | `PASS`, `PARTIAL`, `EXPLANATORILY_OPEN` |
| `INTERPRETATION` | `ESTABLISHED_WITHIN_SCOPE`, `PARTIAL`, `OPEN` |
| `EMPIRICAL_CONNECTION` | `DIRECT`, `INDIRECT`, `PROPOSED`, `NONE`, `NOT_APPLICABLE` |

Every state requires a scope statement and basis. `PASS` in one dimension
cannot upgrade another dimension.

## Sidecar requirements

Every result sidecar records, where applicable:

- the scientific claim and exact authority ceiling;
- the scientific artifact that actually owns authority;
- repository commit and immutable action, basis, contract, and evidence
  hashes;
- source and retrieval provenance;
- primary and replay methods;
- the explicit independence boundary;
- assumptions and imported results;
- a minimal dependency graph;
- decisive equations or lemmas;
- a concise mechanism explanation;
- alternative explanations and failed approaches;
- falsification conditions;
- observable or experimental consequences;
- unresolved semantic or implementation gaps.

The machine-readable representation is
[`epistemic_sidecar.schema.json`](epistemic_sidecar.schema.json). Unknown
metadata must be recorded as unknown; it must not be invented to make a
record appear complete.

## Formalization rules

A formal proof establishes only the mapped formal statement under its
recorded assumptions and proof-kernel trust boundary. It does not by itself
establish semantic alignment, physical truth, explanatory closure, or
empirical support.

A formalization record must identify:

- proof assistant and version;
- dependency versions;
- formal theorem declaration;
- mapped informal claim;
- axioms and assumptions;
- admitted placeholders or equivalent count;
- semantic-alignment audit;
- external-review status.

`FORMALIZATION=PASS` requires zero admitted placeholders in the promoted
theorem dependency closure. It does not modify the other dimensions.

## Independence

An independent replay must state which primary artifacts it was prohibited
from importing. Separate model instances with identical derived inputs do not
automatically constitute independent methods. Meaningful independence comes
from different representations, algorithms, inventories, evidence sources,
or constrained information flow.

The bounded four-role workflow is specified in
[`ADVERSARIAL_AGENT_PILOT_SPEC.md`](ADVERSARIAL_AGENT_PILOT_SPEC.md). It is a
pilot specification, not authorization for a large research swarm.

## Updating and historical custody

Sidecars are snapshots. If scientific authority later advances, the existing
sidecar remains historical evidence and a new version may be added. Historical
records are not rewritten to imply that a later result was known earlier.

Corrections identify the changed record, the reason, and affected downstream
interpretation. They do not rewrite or delete prior scientific attempt
evidence.

## Initial pilots

- [`m06_scalar_radiative_closure.sidecar.json`](m06_scalar_radiative_closure.sidecar.json)
  demonstrates an already-passed result whose verification is stronger than
  its formalization or empirical connection.
- [`m08_brst_blocked.sidecar.json`](m08_brst_blocked.sidecar.json)
  demonstrates a provenance-rich but scientifically blocked result.
- [`RANK8_LEAN_PILOT_SPEC.md`](RANK8_LEAN_PILOT_SPEC.md) defines a small,
  non-blocking formalization pilot.
- [`NAVIER_STOKES_2026_METHODOLOGY_PRECEDENT.md`](NAVIER_STOKES_2026_METHODOLOGY_PRECEDENT.md)
  records an external methodological precedent and an explicit prohibition
  against treating it as ToE physics evidence.

## Audit

Run:

```powershell
python docs/ai_research_epistemic_ladder_v1/audit_epistemic_ladder.py
```

The audit separates historical integrity from current-state coherence. It
does not adjudicate any scientific gate and all its entry points are read-only.

The original package is anchored to its introduction commit
`0d3f679ed0cbb6cec6df042de50702eca0448a9c`. Its unchanged manifest and recorded
artifact digests are verified against that commit's exact Git blob bytes.
This is distinct from the scientific snapshot commit
`c184d172467e6b113052f5a10e8aaa264cb01034` recorded by the two sidecars.
Each scientific source reference is checked at its recorded snapshot, never
against a mutable current file. No fallback to HEAD, hash refresh, newline
normalization or substitute provenance is permitted.

The current audit implementation and this explanatory document are maintained
entry points, not the original manifest's historical versions. Both original
versions remain hash-checked in Git. The live sidecars, schema, pilot
specifications, precedent and manifest must still match their original bytes;
their historical status is not permission to alter the current frozen records.
Current code is tested by the bounded regression suite:

```powershell
python docs/ai_research_epistemic_ladder_v1/test_epistemic_audit.py
```

Live `project_state.json` is checked separately for the bounded lane's stable
scientific invariants, internal agreement of its current blocker fields and
the active `C1_GS` investigation. It is not required to retain a historical
implementation-blocker string or historical file digest.

### Maintenance provenance disposition

The original package's eight listed artifact hashes match its Git versions.
However, at the recorded scientific snapshot, all seven source bindings
(six distinct paths; `project_state.json` is referenced twice) have unmatched
recorded byte digests. A bounded search of reachable local Git versions of
those paths also found no exact matching blob. Five non-state references
match a CRLF conversion of their snapshot blobs, but that observation does
not authenticate an original immutable byte artifact. The recorded historical
state digest remains unresolved as well. The expectations and sidecars are
preserved, not repaired by changing hashes or claiming corruption is proven.

Accordingly, the repaired audit reports package integrity and live coherence
separately, then returns exit code `2` with
`HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED` for unresolved historical sources.
It must not print an overall audit PASS in that case. A missing commit/blob
is likewise unresolved; an altered frozen live record is an integrity failure.
Resolving this custody gap requires the actual immutable bytes matching the
old expectations, not reinterpretation of a later scientific result.

When using the existing pole-blind guard, place
`tools/pole_blind_validation_guard` on `PYTHONPATH` and set
`PYTHONDONTWRITEBYTECODE=1`. Historical Git reads emit the same path-level
read event before accessing objects, so subprocess pipes cannot bypass the
guard. A protected legacy read remains a denied read, not a skipped PASS.
This maintenance audit does not reconstruct T5 or rerun full scientific
validation; linked scientific receipts remain existing evidence only.

### Bounded maintenance validation, 2026-10-08

The 15 new read-only regressions passed, including historical corruption,
missing objects, frozen-live-record tampering, legitimate live evolution,
guard-before-Git access and refusal of optimized assertion-free execution.
The candidate-gate specification, read-only-contract, structure-preserving-map
and authority-coherence audits also passed under the existing pole-blind guard.
The repaired epistemic audit returned its expected unresolved exit code `2`;
its historical source integrity was **not** reported as PASS.

Before/after metadata inventories covered 126,921 workspace/active-data files
(excluding `.git`) with zero audit-time changes. Exact digests of ten selected
scientific inputs, including current state, Sigma, the corrected 17 images,
JCAT/T5 checkpoints and all three STC records, were unchanged. Current state
retained SHA-256
`d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8`.
No T5 reconstruction, new source calculation or repository-wide `--all`
validation was run. References to prior scientific verification receipts are
explicit reuse of existing evidence, not claims of new full validation.
The documentation-only follow-up reruns the bounded regression and map-policy
checks; it reuses the preceding unchanged-input and other bounded-audit receipts.

### Subsequent bounded custody recovery

The [refs/reflog and named-location search](custody_search_02fb85c.json) extends
the earlier Git-only search. Five unchanged live files match their recorded
digests as **raw bytes**, without line-ending reconstruction. The new lossless
[byte capture](custody_recovered_bytes_02fb85c.json) preserves those exact bytes
and can be decoded and checked by
[read-only recovery tests](test_custody_recovery.py). This authenticates content
against the old hashes, not an original creation date or Git-snapshot binding.

The recorded state bytes are still unavailable. All seven original snapshot
bindings remain unresolved under the unchanged strict audit; it still returns
`2`. The original hashes, sidecars and manifest were not modified or rebound
to the recovery files. The search receipt explicitly excludes inaccessible
backups, dangling Git objects and unrelated project contents. The separate
[bounded source-convention investigation](../../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SOURCE_CONVENTION_REVIEW_RESULT.md)
does not depend on this custody uncertainty being closed.
