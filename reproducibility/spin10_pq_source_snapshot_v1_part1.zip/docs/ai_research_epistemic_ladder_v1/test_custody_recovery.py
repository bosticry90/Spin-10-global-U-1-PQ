import base64
import copy
from hashlib import sha256
import unittest
import zlib
from search_historical_custody import authenticate_capture


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.raw = b'{"historical":"bytes"}\r\n'
        self.expected = {"evidence.json": sha256(self.raw).hexdigest()}
        self.payload = {"schema": "RECORDED_DIGEST_MATCHING_BYTES_CAPTURE_V1", "original_snapshot_binding_authenticated": False,
                        "line_endings_transformed": False, "recovered": {"evidence.json": {
                            "original_expected_sha256": self.expected["evidence.json"], "byte_count": len(self.raw),
                            "zlib_base64": base64.b64encode(zlib.compress(self.raw, 9)).decode()}}}

    def test_exact_bytes_not_original_date(self):
        self.assertEqual(authenticate_capture(self.payload, self.expected), 1)
        self.assertFalse(self.payload["original_snapshot_binding_authenticated"])

    def test_corrupted_bytes_rejected(self):
        self.payload["recovered"]["evidence.json"]["zlib_base64"] = base64.b64encode(zlib.compress(self.raw.replace(b"bytes", b"BYTES"))).decode()
        with self.assertRaisesRegex(AssertionError, "RECOVERED_BYTES_MISMATCH"):
            authenticate_capture(self.payload, self.expected)

    def test_newline_reconstruction_not_a_raw_match(self):
        raw = self.raw.replace(b"\r\n", b"\n")
        self.payload["recovered"]["evidence.json"].update(byte_count=len(raw), zlib_base64=base64.b64encode(zlib.compress(raw)).decode())
        with self.assertRaisesRegex(AssertionError, "RECOVERED_BYTES_MISMATCH"):
            authenticate_capture(self.payload, self.expected)

    def test_expected_hash_cannot_be_refreshed(self):
        self.payload["recovered"]["evidence.json"]["original_expected_sha256"] = "0" * 64
        with self.assertRaisesRegex(AssertionError, "ORIGINAL_HASH_CHANGED"):
            authenticate_capture(self.payload, self.expected)

    def test_unrecorded_path_rejected(self):
        self.payload["recovered"]["invented.json"] = copy.deepcopy(self.payload["recovered"]["evidence.json"])
        with self.assertRaisesRegex(AssertionError, "UNRECORDED_SOURCE_PATH"):
            authenticate_capture(self.payload, self.expected)

    def test_content_match_does_not_certify_snapshot(self):
        self.payload["original_snapshot_binding_authenticated"] = True
        with self.assertRaises(AssertionError):
            authenticate_capture(self.payload, self.expected)


if __name__ == "__main__":
    unittest.main()
