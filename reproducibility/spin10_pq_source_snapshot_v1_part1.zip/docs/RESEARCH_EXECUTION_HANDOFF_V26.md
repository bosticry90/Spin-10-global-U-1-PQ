# Research execution handoff, V26

Navigation supersedes V25; project_state.json v113/34 of39 remains sole
authority. Whole Spin(10) x global U(1)PQ investigation active/incomplete.
Recover Git/processes with python -B tools/research_session_preflight.py,
using derivative-gauge bindings after seal (auxiliary-admissibility before).
Read current navigation and prospective V1 contract/result before execution.

Completed actual g^2 xi derivative B-a-C companion: five graph families,
fullBB transverse/longitudinal, BL/LB, both ghost inverse orientations,
45^3 x2=182,250 slots, allfour polarizations, full actual/candidate IBP
currents. Independent Born/Fourier and routed ordered Wick unit residues,
literal group tensors and physical10 replay agree. Arbitrary widths cancel;
1502/976 physical derivative slots,692 raw temporal words. All12 homogeneous
H checks/real/frame roundtrips pass; full local jet Ward not claimed. Lower
g xi^2 zero is an independent full-vector longitudinal/LL proof. Ordinary
g^3 and source companions were not calculated.

The complete inactive member from25bb6b7 FAILS this companion:512 raw
temporal residual words,2,048 allfour. Actual/candidate natural currents
276/416words are retained. Real Bp13 gauge Euler has36terms,18two-momentum
symbol terms; witness+8sqrt(10)xi/25 on Bp13 Cp12(partial ap14), with common
hbar g10^2/(32pi^2epsilon) suppressed. Not a pure boundary; no EOM/anomaly
conclusion. Lowercandidate effects zero; K4 derivative projection zero.
Do not promote the previous auxiliary/quartet matches to fullE5/A5 success.

Preserve four completed route attempts and three preparations. Additional
preliminary audit's wrong expected partial-C coefficient failed; exact audit
source and copied tool diagnostic are retained, start fingerprint/time
unrecorded, excluded from PASS. Validation attempt1 failed on unbound decoded
Fourier momenta; its exact source/start/stdout is retained. The current audit
binds both real momenta explicitly. Actual/control/comparison sources untouched.
Any validation failures remain separate exact attempts with source snapshots.
Receipt requires FOUR strict own-byte fresh routes, scientific/process/
governance tests, delegatede5,37predecessor chains and protected/new/state/
metadata invariance. Old expensive loops/125basis images are authenticated
without replay. Custody remains expectedexit2/seven, never PASS. Raw Git
index/worktree bytes must agree before localcommit.

Next smallest authorized scientific action: prospective source–gauge
derivative prerequisite and complete auxiliary-derivative admissibility
types, with coefficients derived from immutable input action rather than
this residual. Establish its actual source companion and preserve earlier
source/auxiliary/quartet matches before any new inactive extension. No fit
or normalization adoption. This increment first-failure stopped before
source/higherloops. Separately contract the predictedg^3 quartet later.

No catalog/physical activation,HB1/C5/C1_GS/matching, authority promotion,
outreach/publication/push. FullE5/A5/Ward/contact/IR/anomaly,global scalar/PQ,
fermion/Yukawa/phenomenology remain unfinished. Shared inputs/software/
arithmetic/analyst, epistemic ladder and solo-review apply without recruiting
people. A failed scientific gate can have validated failure evidence.
