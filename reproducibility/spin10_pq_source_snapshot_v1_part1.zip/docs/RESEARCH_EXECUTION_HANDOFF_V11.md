# Research execution handoff, V11

Navigation supersedes V10, not authority. Baseline bd1cb32. Recover Git/process
state and [the current checkpoint](A10_E5_SCALAR_UV_CURRENT.md). Before sealing
select frozen_a10_e5_ghost_normalization/bindings.json; afterward select
frozen_a10_e5_scalar_uv/bindings.json explicitly. Default preflight and the
generic research_check.py e5 still select older bounded audits.

The latest completed increment proves ordinary g=0 scalar UV membership and
the complete symmetric H-heavy width space, not a whole quantum prescription.
The state's accepted INVARIANT_BASIS_CLOSED with 34 real potential directions
is an authenticated input. Additional basis source/result files have raw
execution bindings. Never rerun expensive qualified counts without need.

Both routes derive all 29 potential second-variation programs, 331 graph
coefficients and every independent parameter. Canonical loops use the
qualified constrained Jacobian, not ambient/Riesz/raw complex traces. Literal
AST radial differentiation and block Hessian algebra match 66 coupled norm
coefficients; a distinct canonical Sigma loop gives 1120 z4* zD in zK. The
mass-dependent vacuum constant is a separate normalization. The one-loop
potential CT is +Tr(H^2)/(64 pi^2 e), with the literal minus-V action sign.

All-order ordinary scalar closure uses a massive-reference local forest
theorem, global Spin/PQ covariance and the complete accepted basis. Reference
masses remain temporary, with physical differences treated as vertices. The
physical IR limit/benchmark vacuum is not established. No dense beta table
or all-loop expansion was claimed. PQ is global, with no new gauge source.

Full symmetric heavy width constraints: 561 unknowns, 6732 rows, rank 556,
dimension five. Replay uses four Cartan weights, 17 possible opposite-weight
pairs and raising-generator connectivity. Five spectral forms K_nu span the
space; kappa=sum nu K_nu, nu=3,19/5,24/5,34/5,8. For each ub K_nu Lambda,
full QPsi, Q^2Psi and local background Ward identities pass. The 418 quartic
coefficients retain composite R_H. Canonical source pairings stay identity;
invariant width metrics are different objects. This space is qualified, not
adopted into frozen E1. No physical parameter inverses or fitted interactions.

The first start's list-flattening TypeError and original bytes are preserved
and excluded. Completed primary/replay files are immutable. No route or
derivation edit during final receipt validation. Take the process snapshot
with seal_a10_e5_scalar_uv.py --process-snapshot, then export the receipt.
The workflow runs 259 tests (214 scientific,24 process,21 governance), two new
byte-identical routes,22 predecessor chains and strict custody exit 2/seven.
Protected/state bytes and bounded metadata must remain unchanged. Seal, stage
the validated raw file set, verify index bytes, commit locally, no push.

Next: bounded nonzero-g regulator-breaking/restoration and source identity
qualification of this explicit ordinary UV class. General local probe/contact
normalization, weighted gF quantum A5 equivalence and full quantum M2--M5 remain
open. Ordinary UV closure is not the entire W1--W7/E5 acceptance contract.

State v113/34 of 39, M08/HB1/C5 blocked, C1_GS uncalculated. No source removal/
activation, auxiliary elimination, catalog construction, matching, publication,
outreach or authority promotion. The full Spin(10) x U(1)PQ objective is active/
incomplete; global boundedness, PQ quotient, fermion/Yukawa, finite matching and
phenomenology remain. Shared inputs/chart/word/Python/SymPy/analyst disclosed;
no external endorsement. VPC engineering review at 321a33e remains completed.
