# Measured-functional assembly, current navigation

Sole authority project_state.json v113, 34/39; whole goal active/incomplete.
Read MF V1 contract/result, then the qualified current files:
controls_v2.json, primary_v3.json, replay_v3.json, comparison_v3.json and the
validation receipt/bindings. Use audit_a10_e5_measured_functional_v2.py.
Older V1/V2 routes/results are historical unqualified executions, explicitly
classified in input_selection_failure_disposition_1.json and
coupling_unit_failure_disposition_1.json. Preserve them; never use them as PASS.

Twelve measured polynomial sectors assemble to 27,745 distinct canonical
terms, with complete paired agreement, frame/reality and sector coupling
gates. Retain the indexed g^0 scalar program and power/finite ghost profile
separately. Constant-H Ward passes; full local parameter jets give 13,168 raw
and 34,464 anchored Ward terms and six open partner families, including A_H.
All boundary currents and nonzero parameter Euler derivatives are preserved.

The two projected known Slavnov contributions have 2,842 and 1,932 canonical
terms on full raw jet domains 3,539,700 and 2,004,750. All1,286 columns /
214,340 source-polynomial terms are screened; 508 physical Euler programs
stay deferred with an exact projector-support proof. Known contributions
are not complete quantum breakings. Gamma_unknown, Delta_s/Delta_b, insertion
and contact terms remain unbound. Full E5/A5/restoration is not qualified.

Next actual question is the g^2*xi JC-C-C source pole, the only unmeasured
non-boundary type in the leading two-jet census. A new prospective graph and
insertion/breaking contract is required. Related JB-B-C/A_H and higher source
partners remain visible. No fit, new image or physical loop in this assembly.
The g^3 candidate obstruction remains unchanged. Four fresh own-byte routes,
scientific/process/governance/delegated e5, 42 protected chains, byte/metadata/
state invariance and custody exit2/seven references are required. Preflight
the measured-functional manifest after seal, quartic-g3 before. No activation,
authority promotion, HB1/C5/C1_GS, push/publication/outreach; solo policy applies.
