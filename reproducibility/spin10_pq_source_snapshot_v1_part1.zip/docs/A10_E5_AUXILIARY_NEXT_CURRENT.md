# E5 next-order auxiliary checkpoint

Sole authority project_state.json v113/34 of39. The whole Spin(10) x global
U(1)PQ investigation is active/incomplete. Latest bounded result:
[auxiliary result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_AUXILIARY_NEXT_RESULT.md).
ContractsV1/V2/V3 preserve the calculation, exact binding and Euler diagnostic.

Two complete actual methods agree in91,125 slots. Triangle600 and curvature
bubble776 physical slots combine into888/276 physical/raw words. The source-
fixed unique candidate misses xi eta_H and xi^2 auxiliary coefficients. A
nonzero real L_p13 Euler witness excludes a pure boundary term. All failures
are retained; no derivative-gauge/higher loop or primitive fit follows here.

Use frozen_a10_e5_auxiliary_next/bindings.json after seal for preflight byte
authentication; before seal use frozen_a10_e5_nonminimal_source/bindings.json.
Binding outputs primary_bound/replay_bound and comparison_v3 own the qualified
full density/comparison. Original primary/replay canonical densities have an
explicit parameter-binding failure, despite agreement of their formal tensors.
Read the receipt to distinguish successful evidence validation from the failed
scientific candidate gate. Custody remains2/seven. No activation or promotion.

The next prospective increment concerns admissible additional inactive
source-free normalization types at new coupling orders, with previous source,
quartet and lower-order evidence preserved. See handoffV24; no physical/HB1/
C5/C1_GS/matching, quantum A5 or publication authorization is added.
