# E5 named minimal-class checkpoint

Navigation only; project_state.json remains sole scientific authority.
Read the [result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_MINIMAL_TARGET_RESULT.md),
[V2 contract](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_MINIMAL_TARGET_CONTRACT_V2.md)
and [V2 derivation](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_MINIMAL_TARGET_DERIVATION_V2.md),
with retained V1 fields/proofs and explicit supersession of its Gaussian claim.

The two completed routes agree on 13,568 scalar-source coefficients, all
symmetrized kinetic/seagull tensors and 2,160 residual-H covariance identities.
The named Ward/basic polynomial source class is nonexact, has no source-free
representative, and becomes exact after multiplication by g. Its specified
local matter deformation has trace obstruction 24/25. This is not general
minimal classification or actual quantum admission/exclusion.

The literal g=0 sector is INTERACTING: 276 surviving heavy ghost/auxiliary
coefficients. Its real witness has density -xi tAux thetaBar thetaU/25.
Never insert g into E1, omit this term, or set xi=0 to claim Gaussianity.
Only the quadratic Hessian has a generic non-null-momentum inverse.
The 643 g=0 field columns are affine despite these interactions. Their
ordinary-source shift and graded Legendre identity are conditional on a
source-independent regulator/measure and normalization preserving that
dependence at rho=0. This normalization is not adopted for every W1--W7 scheme.

The V1 preflight failure and a later Python dict/set-union failed start remain
with original bytes/logs, excluded from qualification. No completed output may
be overwritten. Use frozen_a10_e5_minimal_target/bindings.json for explicit
preflight once sealed; before sealing use the nonminimal-retract predecessor.
audit_a10_e5_minimal_target.py --fresh reruns only these new bounded routes.
The initial primary/replay took about 151/104 seconds. Generic research_check.py
e5 still delegates its older scope. Finalization requires the new receipt and
seal, including 219 tests, two byte-identical routes and custody exit 2/seven.

Next: realize or expose an obstruction in the CONDITIONAL affine-source
normalization alongside the actual quantum Ward/Slavnov/insertion target,
then remaining minimal and intrinsic/induced quotient comparison. No fixed
strict Tq' is imposed on Gamma. All 643 pairs and 48 backgrounds remain.
Full E5/A1--A5 stay open; v113/34 of 39 unchanged, HB1/C5 blocked, C1_GS
uncalculated. The full Spin(10) x U(1)PQ goal remains incomplete.
