# Evidence-governed engineering gap analysis

Audit baseline: local commit `1dc61f001c02e634c3cfeb7e2aac18fecd39678f`, clean
working tree, no surviving A10/M08 Python calculation. The sealed E3 auditor
authenticated the bounded result and predecessor chain. `project_state.json`
remains the sole machine-readable scientific authority: 34/39, M08 blocked.
The current authorized scientific increment is inactive E4, not E5 or HB1/C5.

This analysis precedes implementation. It does not reopen scientific decisions.

| Existing mechanism | Decision | Reason |
| --- | --- | --- |
| Epistemic ladder and adversarial-role pilot | Retain | Already separate verification, interpretation, empirical connection and information flow; no second acceptance framework is needed. |
| Versioned contracts, results, technical packets and receipts | Retain | Already define bounded hypotheses, first-failure stops, dependencies and limitations. |
| Primary/replay derivations and adversarial controls | Retain | Method diversity supplies evidence; agent count alone does not. |
| Read-only runners, explicit exporters and byte manifests | Retain | Separate calculation from persistence, authenticate inherited work and preserve failed experiments. |
| Authority, structure-map and read-only audits | Retain | Already prevent process status from becoming scientific promotion. |
| Solo-review policy | Retain | Published primary literature is useful; recruiting people is prohibited and external endorsement is absent. |
| Separate stage-current documents | Retain; add a navigation handoff | Their historical bytes must remain intact, but recovery currently requires finding many scattered records. The explanatory README's immediate decision predates E3. |
| Recovery from Git and live process state | Add read-only preflight | A compact command can expose actual state, byte-bound references and active calculations without depending on conversational memory or launching old calculations. |
| Human/agent responsibility and execution planning | Add concise repository instructions | Point to existing contracts, distinguish validated evidence from director acceptance, and require independent read-only tasks before parallel execution. Avoid mandatory multi-agent roles or overhead. |
| E4 integration | New bounded scientific contract | The full BV differential and restricted equivariant differential are different operations; curvature, source chain rules and quartic coefficients require new evidence. |

The implementation will add only new instructions, a handoff, a read-only
preflight with meaningful tests, and separately versioned E4 evidence. Frozen
helpers, historical actions, catalogs, receipts and formal state remain intact.
No broad refactor, new authority state machine, compulsory agent swarm or
mandatory specialist review is justified by this audit.

The human research director owns priorities, foundational assumptions,
scientific acceptance, publication and external actions. Agents may construct,
execute, falsify, replay and document bounded results; a successful run or test
suite cannot promote them into physical truth or the formal ledger.

Potential changes to the physical assumptions, protected evidence, formal
authority or major architecture require a concrete separately scoped proposal.
They are not part of this incorporation. Safe process work continues if an E4
mathematical prerequisite stops. E5, activation, catalog replacement, HB1/C5,
finite C1_GS, publication and remote push remain withheld.
