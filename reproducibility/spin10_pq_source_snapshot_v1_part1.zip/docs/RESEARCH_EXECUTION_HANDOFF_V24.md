# Research execution handoff, V24

Navigation supersedes V23; project_state.json v113/34 of39 remains sole
authority. Whole Spin(10) x global U(1)PQ goal active/incomplete; custody2/seven.
Preflight actual Git/processes with auxiliary-next manifest after seal, or
nonminimal-source manifest before seal. Read new V1/V2/V3 contracts/result.

Next g^2 auxiliary-cubic actuals agree in all91,125 slots. Primary literal
Fourier/Hessian Born and replay physical10 Gaussian/Schur include all g,g,xi
triangles (external nonlinear g L B_H B_M included) and g^2 xi curvature
quartet /xi bubble. Triangle600 H-width and bubble776 physical nonzero slots
combine into888 physical /276 raw words. Full reference, both sectors, four
Lorentz, currents, real frames/H identities and UV-only R>0 scope remain.

The unique source-fixed inactive member FAILS this companion. Canonical
counts actual/candidate/difference: xi eta_H276/0/276; xi^2 236/236/256; xi0.
Full raw difference276. Word C_p12 L_p13 a_p14 coefficient
-16 sqrt(10) eta_H xi/25 has a nonzero real auxiliary Euler; full L_p13 Euler
34 terms agrees with independent deletion. It is not a pure boundary, with
no general EOM/anomaly conclusion. No39-direction reuse: source fixed them.
No new primitive fit or derivative-gauge/higher amplitude after first failure.

Preserve three failed preparations/attempts: wrong replay Lambda-gauge sign
(334-term residual, corrected using retained Qubar=-Lambda); missing real
symbol locals in original output parameter binding (600 unsubstituted H-width
terms); structural dictionary Euler equality false while exact difference0.
Original full formal primary/replay tensors are qualified and immutable, but
their canonical densities are explicitly UNQUALIFIED_PARAMETER_BINDING.
Qualified full densities are primary_bound/replay_bound; comparison_v3 owns
the corrected exact stopped result. No old output is overwritten or rounded.

Receipt requires five fresh strict own-byte starts/results: original full
primary/replay (qualifies formal tensors, reproduces classified binding defect),
both bound routes and comparison_v3. Authenticate35 predecessor chains and
protected/new/state/metadata. Failed comparisons are not PASS. No need to
rerun expensive old quartet/shear/source loops. Check raw Git index/worktree
bytes before local commit; no scientific authority promotion.

Next smallest authorized action: a new prospective admissibility contract for
additional inactive source-free normalization types at these new coupling
orders, preserving measured source/quartet/prior matches. Derive complete Q
images and constraints before fitting a primitive or dependent loops. V24
does not adopt an extension or silently unlock a physical or quantum gate.

No catalog/physical activation, HB1/C5/C1_GS/matching, authority change,
outreach, publication/push. Full E5/A5/Ward/contact/IR/anomaly, scalar/PQ global,
fermion/Yukawa/phenomenology stay open. Shared assumptions/software/data/analyst,
solo-review policy and epistemic ladder apply; no external-personnel prerequisite.
