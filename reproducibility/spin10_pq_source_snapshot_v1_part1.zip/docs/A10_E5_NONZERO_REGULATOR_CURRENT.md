# Current nonzero-g regulator extension checkpoint

Read the [stopping result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_NONZERO_REGULATOR_RESULT.md)
and its contract. The free-only fractional kernel fails local gauge covariance.
The precisely ordered covariant scalar kernel L P(L+m_reg^2) has a tree
functional covariance argument but does not regulate its gauge-loop UV pole:
the pole retains factor1+alpha. This is a failure of that extension, not the
physical action or previously qualified Stage D--E4.

All8100 scalar trace-pair entries agree: indices12,70,2,0, total84. Proper-time
and direct bubble/seagull calculations match the scalar F^2 pole and finite
transverse amplitude. The formal643-field Berezin divergence vanishes, without
proving continuum anomaly freedom. The proper-time scalar control is separate
from the full retained-source mixed gauge/ghost/nonminimal prescription.

Before sealing select frozen_a10_e5_scalar_uv/bindings.json; afterward use:

    python -B tools/research_session_preflight.py --manifest tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_nonzero_regulator/bindings.json

audit_a10_e5_nonzero_regulator.py authenticates the bounded failure evidence;
--fresh regenerates its two routes. Generic research_check.py e5 still delegates
an older audit. No command grants scientific acceptance or changes authority.

Next: separately regulate the complete retained-source one-loop functional,
derive its643-field graded Hessian and Ward/ST restoration/contact conditions.
Do not adopt the failed fractional action kernel as a full M2 prescription.
Full E5, IR, general probes/A4/A5 and weighted gF quantum equivalence remain.
State v113/34 of39 unchanged; custody exit2/seven remains unresolved. No
activation, catalogs, HB1/C5, C1_GS, physical matching, outreach or push.
