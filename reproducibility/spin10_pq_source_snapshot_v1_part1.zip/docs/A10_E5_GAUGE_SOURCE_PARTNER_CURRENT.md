# Current actual gauge-source partners and selected source Ward checkpoint

Read [GP result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_GAUGE_SOURCE_PARTNER_RESULT_V1.md)
and its prospective V1 contract. Actualg^2xiJB-B-C has1940physicalcolor
coefficients/all4Lorentz; JB-A_H-C is exactlyzero in its388,800slotdomain
despite nonzero literal background vertices. All1,846,800B/A component slots
agree between Born and physicalWick; all12rigidH/real/primaldual checks.

Ghost/auxiliary/YM triangle weights +1/2,-1/2,+1/2,-3/2, full16Lorentzpairs,
bothodd/mixed and transverseBB retained. Removingtransverse removesYM residue.
Do not reuse the old pureg^3longitudinal-collapse argument. SourceJB is ODD.

New actual poles cancel all720leading source-wave Ward terms: selected raw/
anchoredleftside0/all12Eulers0. Correctedknownsum30,595terms; knownWard12,448
raw/fiveopen targets. Newnode gives0in bothpreviousSlavnovprojectors. Delta/
unknownGamma/measure/contacts/IR stillunbound. PriorGSscope andg^3FAIL persist;
no normalizerfit/adoption or fullE5/quantumequivalence claim.

Two preloop label/frame errors and exactsnapshots/attempts/dispositions stay
archived, notPASS. Controls/prep1,primary/replay/prep4,comparison/prep5 current.
Receipt/seal own checks; preflight byte-only. Afterseal selectgauge_source_partner
bindings; before selectward_reassembly. Statev113/34of39 unchanged. Next:
actualg^2 auxiliary Lambda-B-B/A_H-B under a new complete graph/UV contract.
WiderPQ/scalar/fermion/pheno/wholeinvestigation remainopen; noagents/outreach.
