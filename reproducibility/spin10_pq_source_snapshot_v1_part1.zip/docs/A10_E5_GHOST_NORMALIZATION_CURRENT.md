# E5 concrete g=0 ghost-normalization checkpoint

Navigation only; project_state.json remains sole scientific authority.
Read the [contract](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_GHOST_NORMALIZATION_CONTRACT_V1.md),
[derivation](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_GHOST_NORMALIZATION_DERIVATION_V1.md),
[finite extension](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_GHOST_NORMALIZATION_FINITE_SPEC_V1.md)
and [result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_GHOST_NORMALIZATION_RESULT.md).

The source-independent four-dimensional spectral regulator realizes the
actual linear g=0 BRST/source structure at finite cutoff. The actual surviving
xi interaction produces a nonzero ghost pole with kappa=-tr(A_i A_j).
All 1,089 entries agree; the relative spectrum is 3(12),19/5(12),24/5(6),
34/5(2),8(1). Uniform delta xi in the literal auxiliary term cannot absorb it.
A separate local H-invariant BRST-exact matrix fermion subtraction exists;
the frozen E1 fermion is not edited or declared historically equivalent.

An explicit finite nonexceptional bubble supplies a nonempty selected ghost
prescription, plus a specified cubic probe/contact subtraction. Analytic MS
and dimensional MSbar differ by the computed local constant 1/(16 pi^2).
Retain the nonlocal log and the exact scheme distinction. The entire g=0
model remains non-Gaussian. Source-dependent insertions, weighted-gF quantum
equivalence, scalar closure/IR and all-g restoration remain unproved.

Use frozen_a10_e5_ghost_normalization/bindings.json for explicit preflight after
sealing; before that select the minimal-target predecessor. The new auditor
--fresh reruns two logical route suites (main and finite, four artifacts).
Main routes initially took about 14/13 seconds, finite extensions about one
second each. Each own output must regenerate byte-identically; between-route
finite formulas compare exactly symbolically. validation_preflight_v1 retains
the initial failed textual comparison, original code and observation scope.

Finalization requires the new receipt and seal: 239 tests, four fresh artifacts,
21 predecessor manifests, protected/state bytes and metadata checks, custody
exit 2/seven. Generic research_check.py e5 still selects its earlier scope.
Next: actual scalar ultraviolet/parameter closure and admissible exact
gauge-fermion normalization, then all-g restoration and general insertions.
All 643 pairs/48 backgrounds remain. Full E5/A1--A5 stay open, v113/34 of 39
unchanged, HB1/C5 blocked and C1_GS uncalculated; the full investigation continues.
