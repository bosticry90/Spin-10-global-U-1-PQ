# Current regulated source-operator checkpoint

Read the [bounded result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_REGULATED_SLAVNOV_RESULT.md)
and contract. All643 field tangents and70,935 coefficients match independently,
including180 first jets. The specified self-adjoint H heat profile has zero
Jacobian trace in all13 physical carriers. This is not general anomaly freedom.

The regulated and original source operators differ:

    Q Gamma1=insertion1(B_Lambda)-(V_Lambda,Gamma1)-i div_heat R.

The source correction is nonzero in the independent nonlinear control. The
actual phi finite-cutoff tree breaking also remains nonzero. Local restoration,
general contacts, IR projections/removal, quantumA5 and fullE5 are unproved.

Before seal use frozen_a10_e5_full_hessian/bindings.json; afterward select:

    python -B tools/research_session_preflight.py --manifest tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_regulated_slavnov/bindings.json

The named auditor authenticates this checkpoint; --fresh reruns its two
routes. Generic research_check e5 remains an older bounded delegate. No command
grants acceptance. Statev113/34of39 and custody2/seven remain unchanged.
Next: actual source-vertex UV/restoration with mixed gauge–auxiliary propagation
and xi cubic retained. No activation, catalog, HB1/C5, C1_GS, matching or push.
