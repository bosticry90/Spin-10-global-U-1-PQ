# Research execution handoff, V21

Navigation supersedes V20; authority remains project_state.json, v113/34 of 39.
Use read-only preflight with the explicit normalization-types manifest after
seal, or the quartet manifest before seal. Authenticate bytes without implying
scientific acceptance. Read the new result, current checkpoint and both V1/V2
contracts. The whole goal remains active/incomplete; custody exit 2/seven.

Actual quartet still has 6,576 nonzero slots; K0+Kjoint+K3 still misses 5,528
of 980,100. Its exact 32/25 real nonboundary witness remains. The new work
does not replace any failure, read/fit the residual, adopt a normalization or
calculate new loops. Earlier primitive and selected matching scopes remain.

Source-free heavy repair with prior width/full cubic fixed is obstructed.
The remaining skew a-Lambda bilinear must commute with all H connection
matrices; its curvature matrix product is symmetric and its full Q image
vanishes. Actual physical Q columns reconstruct every connection and curvature
term; no heavy-adjoint closure or symmetric-coset assumption. Five necessary
quartet carrier types include JC C, Ja a and JLambda a C; no general invariant
coefficient or full canonical-image classification is claimed.

V1 auxiliary shear used a primal Euler vector as a dual field shift and failed
its first H identity in 152 rows. Preserve the failed contract, preparation,
attempt and exact H variation. V2 froze the inherited G_M lowering separately.
Its unit F=G_M E direction has complete classical Q/first-variation, pairing,
exact inverse, real/H and nonlinear jet evidence. Raw orbit grading failed
in 3,936 preserved terms; the new check reconstructs precisely the typed
dimension-one E1 OrbitPullback image. Keep scalar-orbit companions.

The integrated-field map is triangular, Berezinian one. Nonlinear mean fields
still require composite expectations/insertion/contact normalization; A5,
retained-source quantum Ward and restoration remain open. The preceding joint
measure contribution is not canceled by this shear. Preserve every companion
type/coupling, full physical quartet image and justified zeros. Neither unit
coefficient nor prior matching is a scientific subtraction choice.

Next smallest authorized step: classify H-equivariant JLambda a C tensors and
their coordinated image/companion equations, independently of arbitrary
residual fitting. Freeze any next comparison/actual-amplitude contract first.
No JC-C-C/JB-B-C or other loops under the current contract; no activation,
physical/catalog/HB1/C5/C1_GS/matching, authority promotion, outreach,
publication or push. Global scalar/PQ, fermion/Yukawa/phenomenology remain open.

The receipt owns executed tests and fresh own-byte derivations, 32 parents,
protected/new/state hashes and metadata. Qualified expensive prior loops are
not rerun. Validate before local commit and check Git index/worktree raw bytes.
Shared data/software/analyst are disclosed under solo review; no external
scientist endorsement or proof-kernel certification.
