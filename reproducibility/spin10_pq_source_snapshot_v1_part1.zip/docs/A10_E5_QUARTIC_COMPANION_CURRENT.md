# E5 actual quartet checkpoint

Navigation only; project_state.json is sole scientific authority.
Baseline1e81980; statev113/34of39,31 parents, whole goal active/incomplete.

Complete actual g^2*xi^2 quartet routes agree:6,576 nonzero entries over all
980,100 physical odd-pair slots. The frozen inactive K0+Kjoint+K3 prediction
has4,944 entries and5,528 nonzero actual-minus-candidate differences. Real
witness at antighost/ghost pairs(12,13): actual16/25, candidate-16/25,
difference32/25, with nonzero left antighost Euler derivative.

All graph families retained. Box0 follows an odd-skew transpose/cyclicity
lemma, not projected-adjoint closure. Mixed/ordinary triangles and full
quartic bubble retained, including all anomalous odd blocks and four Lorentz
weights before reduction. Original heat profiles8/6/4 and UV-only scope remain.

The H-compatible primitive, cubic repair and earlier qualified projections
are preserved. The complete tested inactive normalization fails this companion.
No adoption or new source loops. Scope does not establish full E5/A5 or a
failure of the physical/classical theory.

See the [result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_QUARTIC_COMPANION_RESULT.md)
and [contract](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_QUARTIC_COMPANION_CONTRACT_V1.md).
Receipt and seal in frozen_a10_e5_quartic_companion own validation. Before seal
use cubic-primitive bindings; after seal explicitly select quartet bindings.
Generic research_check e5 is an older bounded delegate. Custody2/seven unresolved.

Preserve canceled attempts, schema precheck and failed even-derivative replay
with complete disagreement. Next classify allowed residual-carrying
normalizations and companion obligations before a new loop. JC-C-C/JB-B-C
and HB1/C5/C1_GS remain stopped. No state/physical changes, contact or push.
