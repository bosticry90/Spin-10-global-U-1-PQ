# Research execution handoff, V31

Supersedes V30 navigation, not authority. Previous turn PROGRESS: actualg^3
quartet qualified and prospective candidate failed. Current increment MF1-MF3
assembles the measured residue and exact open restoration dependencies.
Recover Git/processes and preflight frozen_a10_e5_measured_functional/bindings.json
after sealing; frozen_a10_e5_quartic_g3/bindings.json before. Statev113/34of39
and all protected bytes remain unchanged; whole goal active/incomplete.

Read MF V1 contract/result/current. Qualifying outputs are controls_v2,
primary_v3, replay_v3, comparison_v3. Current worker is run_a10_e5_measured_functional_v3.py,
auditor audit_a10_e5_measured_functional_v2.py. Four strict fresh own-byte
executions use their original preparations. Preserve archived controls/V1/V2
source/results and both failure dispositions. Original comparison failed
because it read an explicitly unqualified historical quartet replay; a later
shared omitted g^2 input-unit factor was caught by dependency review. V3
restores declared units and enforces every sector's g degree. Old calculation
agreement/labels alone are not qualification. No evidence bytes were edited.

The finite polynomial known residue has12sectors/27,745 canonical terms.
Indexed scalar Hessian-square and ghost cutoff-power/finite records remain
separate with their exact scope/conventions; no dense beta/Sigma loop rerun.
Full physical/canonical roundtrips and reality, all constant-H parameter
identities, paired assembly/differentials and forward/backward census agree.
The full local Ward variation has13,168 raw and34,464 anchored terms, complete
ordinary boundary currents and nonzero parameter Euler derivatives. Six open
partner families include BOTH totalB_H and externalA_H affine connections.

All1,286 E2columns/214,340 source-polynomial terms are screened.508 indexed
physical Euler slots are deferred, with a proof that neither selected odd/
auxiliary projector sees them; do not set them to zero in the full functional.
Known Slavnov projections: g^2aCC,twojets=2,842 canonical terms;
g^3Lambda aCC,nojets=1,932. Full raw domains3,539,700/2,004,750 retain equal
ghost colors at unequal jets. Physical projections have10,316/11,376 real
terms. Exact Euler witnesses exclude pure boundaries of the known subset.

The full one-loop equations still contain Gamma_unknown, Delta_s,Delta_b
and uncalculated insertions/contact normalizations. Nonzero known variations
are open dependencies, not a measured full breaking or an anomaly. W1-W7,
A1-A5, nonlinear higher Slavnov brackets, quantum H whole-product insertions,
canonical equivalence, regulator/measure and IR remain conditional/unproved.
The g^3 candidate obstruction is preserved; no fitting or new generator/image.

Next smallest ACTUAL action: NEW prospective leadingg^2*xi JC-C-C loop
contract, all45source/ghost directions, complete permitted triangle/bubble
inventory, both odd orientations/mixed inverse/full4Lorentz, real and complete
coupling/width/UV tests, distinct derivations and first-failure preservation.
This is the only unmeasured non-boundary INPUT TYPE in the leading two-jet
census; its coefficient is not determined by assuming restoration. Keep
Delta_s and other scope complements explicit when testing the enlarged
measured functional. Related JB-B-C/A_H partners are needed for the leading
local Ward source system. Do not fit the g^3 residual or silently declare
any typed higher source/auxiliary partner a calculated zero.

Validation receipt owns tests/commands/source-start bytes/runtimes, four
fresh routes,42protected chains,new/protected/state/size-mtime invariance.
Custody exit2/seven unresolved references is expected,neverPASS. Old expensive
loops/images authenticate only. Raw Git index/worktree equality before local
commit; no reset, unapproved source/evidence editing, process termination,
activation, push or publication. No physical/catalog/HB1/C5/C1_GS/matching,
authority promotion or outreach. Scalar/globalPQ,fermion/Yukawa,phenomenology
and whole Spin(10)xglobalU(1)PQ investigation remain open. Shared inputs/
arithmetic/software/analyst disclosed; no agents. Local conventions, ladder
and solo-review remain, without mandatory outside recruitment.
