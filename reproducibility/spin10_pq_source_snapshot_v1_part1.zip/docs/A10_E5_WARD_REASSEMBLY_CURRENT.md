# Current corrected measured local Ward checkpoint

Read [WR result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_WARD_REASSEMBLY_RESULT_V1.md)
and its prospective V1 contract. Corrected13-sector density:27,971terms;
Ward13,168raw/34,464anchored/59,304realphysical, all12parameterEulers and
four3,472termcurrents. Primary/replay assembly, prefix/jet-gradient variations,
frames and forward/reverse predecessor census agree. ConstantH0, newJC localH0.

Six targets admit ten unmeasured type classes, five amplitude families with
B_H/A_H alternatives. Coefficients stay None; these are not measured zeros or
an invariant basis. Known Ward Euler is nonzero, but Gamma_unknown/Delta_b/
measure/insertion/contact/IR are unbound. No complete breaking or anomaly claim.
Old MF V3 metric error causes EXACTLY540Ward coefficient differences; use
current records, preserving old bytes/dispositions. Term counts alone miss it.

Next actual question: leadingg^2xi J_B-B-C/J_B-A_H-C, oddJ_B and full45source/
ghost/gauge directions/allLorentz/completevertices; no predicted-zero pruning.
Lambda-B-B atg^2 and higher families remain open. GS selectedSlavnovleftside
qualification and priorg^3candidateFAIL keep their scopes. Full E5/A5/quantum
equivalence/HB1/C5/C1_GS and widerPQ/fermion/pheno objective remain open.

Receipt/seal own checks; preflight authenticates bytes only. Afterseal select
ward_reassembly/bindings; before selectghost_source/bindings. Statev113/34of39
unchanged. Shared dependencies/analyst, noagents/externalendorsement/outreach.
