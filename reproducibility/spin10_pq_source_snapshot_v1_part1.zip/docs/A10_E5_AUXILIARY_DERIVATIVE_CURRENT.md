# Source-fixed derivative extension, current navigation

Sole authority project_state.json v113/34 of39; whole Spin(10) x global
U(1)PQ investigation active/incomplete. Latest increment atbaselinea54fb17
constructs and qualifies a full inactive auxiliary derivative image. Read
package CONTRACT_V1/RESULT_V1 and frozen controls/primary/replay/comparison,
receipt/bindings. Preflight auxiliary-derivative manifest after seal; source-
gauge manifest before seal. Old expensive calculations authenticate only.

K_D=g² J_Lambda C_H D_(B_H).B_M,848raw/2328physical, completeQ47532 throughg4.
InputGF usesB_H connection; externalA_H is also a connection, homogeneous
B_H-A_H ambiguity not uniquelyfixed. FulllocalH withparameterjets passes.
Exactsinglecotangentflow:32auxiliaries/176gauge sources change;1286generators,
2572inverses,832firstjets, fullsmeared adjoint/Hessian kernels and exact
boundarycurrent. RegulatedsinglefieldBer1; oldjointmeasure retained, combined
old finiteinverse/fullquantumA5 notclaimed.

Newcompleteinactive generator/candidate1354/95155 words nowmatch both
measuredsource2025 and derivative182250 slots, withcompleteIBP currents,
andpreserveoldauxiliary91125,nonminimal-source91125,quartet980100 and lower
source/kinetic/mixing/width/cubic evidence. Allnewunmeasured terms retained;
totalg3 purequartet966 remains prediction. Noactualnewloop or adoption.

Next: separateactualg² auxiliary-source/ghosttwo-derivative companion contract,
all45x45 and full sourcequartic/mixedbubble/UV/mass classifications; then
separatelyactualg3quartet. Firstfailure stops, nofitting. Custody2/seven,
shared inputs/software/analyst, localconventions/ladder/soloreview remain.
Noauthority/physical/catalog/HB1/C5/C1_GS/matching or externalaction.
