# Current nonminimal-source checkpoint

Recover Git/processes with the read-only preflight. Before seal select the
full-shear-space manifest; afterward select frozen_a10_e5_nonminimal_source/
bindings.json. Read the nonminimal-source V1 contract and result in the replay
package. Authentication alone does not execute or scientifically accept work.

The actual g^2 xi J_antighost-a-C pole agrees across distinct Born/literal and
Wick/physical10-Casimir methods. All 91,125 slots compare, 776 are nonzero,
and 236 raw canonical coefficients remain. Linear source zero channels are
derived from the retained action; heavy nonlinear source and mixed/H ghost
flow remain. Real/H/frame/UV and four-Lorentz checks pass.

The complete old source projection is zero. Actual data equal the previous
quartet representative, and source injectivity fixes all 39 affine directions
to zero. The unique extra generator has 236 coefficients; one total inactive
generator/candidate has 506/54,823. Quartet and earlier matched scopes remain.
No subtraction or quantum A5 is accepted; all complete higher companions stay.

The floating Lorentz precheck failure, 502 coefficients and full diagnostic
are preserved. Exact weights recompute the result from the original inputs.
Next: prospective actual derivative-gauge/auxiliary-cubic companion contract,
including full coupling/width/graded coverage and first failure. No other new
or JC-C-C/JB-B-C loops here. No activation/catalog/HB1/C5/C1_GS/matching,
state promotion, outreach/publication/push. State v113/34 of 39; custody exit
2/seven. The whole investigation, scalar/PQ and fermion/Yukawa scopes stay open.
