# Current actual mixed source-pole checkpoint

Read the [result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_SOURCE_VERTEX_RESULT.md)
and contract. Actual leading gauge-source/ghost g*xi and scalar-source/ghost/
scalar g^2*xi poles agree independently. Keep the literal xi Lambda ub u and
mixed gauge–auxiliary Green function; auxiliary self-propagation remains zero.

The ghost endomorphism is N_M=kappa_aux G_M, not kappa_aux. Both source pole
projections match Kbar=g xi JC^T N C through Cbar=QKbar-div(theta). Its complete
54,194-coefficient image/current is a prospective inactive normalization;
other loop projections are not established. Scalar phi20 products are freshly
computed; other-sector extension uses qualified representation proofs.

Before seal select frozen_a10_e5_regulated_slavnov/bindings.json; afterward:

    python -B tools/research_session_preflight.py --manifest tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_source_vertex/bindings.json

The named auditor authenticates this checkpoint; --fresh reruns two routes.
Generic research_check e5 is an older bounded delegate. No command accepts
science. Statev113/34of39 and custody2/seven remain unchanged.

Next: ghost two-point, JC-C-C and JB-B-C companion poles and full local
Slavnov/Ward restoration. Retain current, measure, IR and source corrections.
FullE5, quantumA5 and all contacts unproved. No activation, catalogs,
HB1/C5,C1_GS,physical matching,outreach,publication or push.
