# Research execution handoff, V28

Navigation supersedesV27; project_state.json v113/34 of39 soleauthority.
Whole Spin(10) x globalU(1)PQ active/incomplete. RecoverGit/processes with
preflight auxiliary-derivative bindings afterseal; source-gauge beforeseal.
Read AD1/AD2 prospectivecontract/result/current; no historical draftacceptance.

Source-fixed K_D=g² JL C_H D_(B_H).B_M. BothB_H and externalA_H have
inhomogeneousH connectiontransform. ActualheavyGF usesB_H; explicitliteral
versusphysical10 derivations agree. B_H-A_H homogeneousambiguity meansno
fullgeneratoruniqueness.848raw/2328physicalK,47532fullQimage throughg4.
TypedE1 OrbitPullback image reconstructed exactly; no arbitrarygradeexception.

FullH arbitraryomega andparameterjets cancel; omittedconnectionfails.
PrefixQ andindependentwholeaction firstvariation agree withfullcurrent
QK+deltaS=D[-sum partial_(DB)K QB]. Do notreplace densityby pointwisezero.
Bothfullimages agree beforeoldcandidate/otheractualscope access. Source-fixed
matrix dependency intentionallyreads qualifiedSGinput; no derivativefit.

Exactsingleflow changes32integratedAux and176JB sources,208columns.
1286generator/2572inverse/832firstjet checks, secondproductjet andwrongsource-
adjoint sign controls pass. Differentialpairingformaladjoint andallsourcesource
smearedHessian blocks proved witharbitraryU/V. Sourcesexternal; finite-mode/
heat projections preserveN rowAux,columnB,N²0,strN0,fieldBer1. Oldjointmeasure
retainedseparately; combinedoldfiniteinverse/fullA5 notclaimed.

Completeinactive newgen/candidate1354/95155words. Measuredsource2025 and
derivative182250 match, completecurrents/all4/both3pointmomenta retained.
Priorauxiliary91125,nonminimal-source91125,quartet980100 andlower/source/
kinetic/mixing/width/cubic scopes preserved. Newhigher/source/longitudinal/
mixing/scalar terms retainedunmeasured. Pureg3 quartet unchanged966prediction,
NOTactual. No newactualloop, physicalfit or normalizationadoption.

Validate fourstrictown-bytefresh routes/unit+images+comparison, scientific/
process/governance/delegatede5,39chains,protected/new/state/metadata invariant.
Custody expectedexit2/seven unresolvedrefs,neverPASS. Preserve any failed/
unfinishedattempt exactsource/start/stdout. Oldexpensiveloops/125basisimages
authenticatewithoutreplay; rawGitindex/worktree identicalbeforelocalcommit.

Nextsmallest action: NEWprospective actualg² JL–C two-derivativecompanion,
all45x45source/ghost slots andall4polarizations, fullsourcequartictadpole/
mixedbubble/reference/UV andmass-dimension classification, fullIBP. Compare
to thismember; firstmismatchSTOP. Later separatelyactualg³ quartet. Keepall
unmeasuredpredictions visible andno silentactivation.

No catalog/physical/HB1/C5/C1_GS/matching,promotion,adoption or externalaction.
FullE5/A5/Ward/contact/IR/anomaly,global scalar/PQ,fermion/Yukawa/phenomenology
andwholegoal remainunfinished. Sharedinputs/software/arithmetic/analyst,
localconventions, ladder andsoloreview withoutoutsiderecruitment apply.
