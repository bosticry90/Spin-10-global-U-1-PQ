# Research execution handoff, V25

Navigation supersedes V24; project_state.json v113/34 of39 remains sole
authority. Whole Spin(10) x global U(1)PQ goal active/incomplete; custody2/seven.
Preflight actual Git/processes with admissibility manifest after seal, or
auxiliary-next manifest before seal. Read V1/V2/V3 contracts/result/current.

Completed universal source-free image theorem before actual residual access:
aL/aaC only carriers to LaC; Qa0=-Aux all45, Qa1/QAux1 single ghost onlyH;
other Q fields cannot supplyAux. Full32,670 signed aaC columns within66,825
heavy-ghost slots, symmetric complement34,155. Both derivations agree. All
91,125 residual slots, including both xi^2 and xi eta_H, are antisymmetric.
Do not infer a full source-dependent/H-invariant basis from this theorem.

V3 deterministic right section K4=-g^2 sum_(i<j,k)D_ijk a_i a_j C_k matches
the next auxiliary pole. Upper-pivot and Euler/homotopy plus full source-first-
variation Q images agree. K4 138raw/444physical;QK4 924raw=276aux+648quartet.
Full g^3 image has3,960 physical quartet slots;H ghosts cancel after fullQ,
with no M-Jacobi assumption. All12H/real/frame,1286generator/2572inverse,
pairing/264firstjet and wrong-sign/secondjet controls pass. Fields fixed;
66external sources translate;fieldBer1. No finite combined old flow/A5 claim.

Complete new inactive member repairs91,125 auxiliary slots and preserves
earlier source/kinetic/mixing/width/cubic and980,100 g^2 quartet matches.
Total generator/candidate506/54,823words have new coupling coefficients.
Total g^3 quartet prediction966rawwords is NOT an actual loop result.
No new actual amplitude ran; old joint regulated measure stays.

Preserve V1 comparer as unexecuted source after prospective Rational(1,2)
zero-slot correction V2. Preserve failed image-primary attempt1 (missing
ghostP12 registration) and its full source/start/stdout; no failed attemptPASS.
Do not overwrite old auxiliary/source/quartet failures or bound/unbound
density classifications. Receipt requires SIX strict own-byte fresh runs:
two algebras,comparisonV2,two fullimages,normalization;36predecessor chains,
protected/new/state/metadata and custody2/seven. No old expensive loops/
125basis images need replay. Check raw Git index/worktree before local commit.

Next smallest authorized action: a prospective actual derivative-gauge
companion contract against this complete member, all coupling/reference-width/
graded contributions and full IBP current. Its prediction is unchanged by
K4. Later separately freeze/test the total g^3 quartet prediction. First
mismatch stops; no arbitrary fit, adoption or physical gate unlock.

No catalog/physical activation,HB1/C5/C1_GS/matching,authority promotion,
outreach/publication/push. Full E5/A5/Ward/contact/IR/anomaly,scalar/PQ global,
fermion/Yukawa/phenomenology remain. Shared inputs/software/arithmetic/analyst,
solo-review and epistemic ladder apply without outside-personnel requirements.
