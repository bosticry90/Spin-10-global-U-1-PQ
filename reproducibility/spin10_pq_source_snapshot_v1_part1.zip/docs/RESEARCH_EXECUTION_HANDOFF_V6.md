# Research execution handoff, V6

This navigation supersedes V5 for new work and is not scientific authority.
Recover Git, processes, project_state.json and byte seals before computation.
Baseline 321a33e is clean. The VPC review is completed engineering work; it
does not complete or redirect the active Spin(10) x U(1)PQ scientific goal.

The [regularity checkpoint](A10_E5_REGULARITY_CURRENT.md) now supplies an
all-jet polynomial equation chart, complete minimal Noether/KT resolution,
normality and a canonical nonminimal doublet chart. Read its contract,
derivation, result, completed routes and receipt. The initial AST-parser failure
is preserved and excluded from PASS. No source is removed or activated.

Explicit preflight: tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_regularity/bindings.json.
audit_a10_e5_regularity.py authenticates the new work; --fresh reruns only its
two routes. Generic research_check.py e5 retains its older delegation. Neither
command changes scientific authority or grants scope.

Next smallest scientific action: establish the local-functional theorem/domain
and primitive bridge, including H(delta modulo d), global currents, external
background spectators and joint Ward/insertion/basic conditions. Do not infer
that the full-complex noncovariant contraction preserves a restricted domain.
No full/basic or intrinsic/induced isomorphism is currently proved. PQ is global,
not a 46th local gauge direction; its global quotient is still unfixed.

The prior W1-W7 quantum contract remains conditional on A1-A5: actual measure,
QAP, joint restoration, insertion renormalization and quantum canonical
equivalence are still unproved. Full E5 and quantum consistency remain open.
The candidate excludes the full fermion/Yukawa sector. Quantum matching,
global scalar boundedness, flavor/proton decay and physical unification are
uncompleted; do not shrink the active completion goal to this checkpoint.

All scientific predecessors remain frozen. project_state.json is 34/39,
M08/HB1/C5 blocked, C1_GS uncalculated, custody exit 2/seven unresolved. No
activation, catalogs, matching, publication, personal contact or push. Validate
completed bounded work before local commit. Continue under the solo-review
policy with shared assumptions/data/software/analyst and no external endorsement.
