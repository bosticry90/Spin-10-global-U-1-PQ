# Research execution handoff, V7

This navigation supersedes V6, not scientific authority. Recover Git,
processes, source state and seals. Baseline 2d0cdaf is clean. The previous
turn qualified regularity/Noether/KT/normality; this turn supplies new
[coupling-ring scope controls](A10_E5_COUPLING_RING_CURRENT.md).

Read the new contract, derivation, result and receipt. The full polynomial
class F_beta=partial_g S_beta has no unrestricted horizontal/source-free
representative, proved by stationary specialization and real H/heavy replay.
Its raw local background Ward identity fails, so it is not automatically
admitted by W6. The weighted g F_beta has a named basic representative with
a nonbasic canonical primitive. Neither result proves general E5 adequacy.
Do not divide by g, infer loop coupling powers, or mislabel this as a failure
of the qualified physical action or master system.

Both g-dependent coordinate connections are explicit. N(partial_g SD)
differs from partial_g S_beta by Q_beta K_N; partial_g S' differs from
U(partial_g SD) by Q' partial_g Psi. All sources, auxiliaries, the nonsymmetric
heavy bracket, composite curvature and actual H backgrounds remain present.

Explicit preflight: tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_coupling_ring/bindings.json.
audit_a10_e5_coupling_ring.py authenticates; --fresh repeats only its new routes.
The larger new replay performs indexed tangent construction and full source
current variation, taking several minutes. Preserve and poll any surviving
job before restarting. Generic research_check.py e5 keeps its older delegation.
Three preliminary primary outputs and two failed replays are preserved and
excluded. Verify input schema/parameter types before expensive dependent work.

Next smallest scientific action: derive the actual nonminimal counting
contraction and its compatibility with Q, iota, Tq and Tb, parameter jets,
dimension/ghost bounds, real/Lorentz structure and canonical E2 transport.
Do not infer restricted-domain reduction from the full-complex doublet proof.
Then investigate the remaining minimal coupling-ring/primitive and intrinsic/
induced comparison. W6 does not impose fixed strict Tq' quantum invariance.
Actual W1-W7 construction and A1-A5 remain separate unproved obligations.

project_state.json remains v113, 34/39. Full E5 and M08/HB1/C5 remain blocked;
C1_GS uncalculated, custody exit 2/seven unresolved. No activation, catalogs,
matching, publication, personal contact or push. The Spin(10) x U(1)PQ goal
remains incomplete, including global boundedness and later physical tests.
The full fermion/Yukawa sector and global PQ quotient are not supplied by this
gauge/scalar candidate. Validate before local commit and retain solo-review
limitations: shared data/assumptions/software/analyst, no outside endorsement.
