# Research execution handoff, V9

Navigation supersedes V8, not authority. Recover Git/processes/byte seals.
Baseline is 3642d07. The new [checkpoint](A10_E5_MINIMAL_TARGET_CURRENT.md)
is a named minimal polynomial class and conditional quantum-source lemma,
not complete E5, theorem coverage or an actual quantum prescription.

Before sealing, explicit preflight uses
tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_nonminimal_retract/bindings.json.
After sealing use frozen_a10_e5_minimal_target/bindings.json explicitly. Generic
research_check.py e5 keeps its earlier delegation. Snapshot checks authenticate
bytes; no calculation or scientific acceptance follows from them.

Read V2 plus preserved V1 contract/derivation and the result. The whole-sector
g=0 Gaussian hypothesis was REFUTED: E1's xi heavy cubic has no explicit g,
and Q0 produces 276 surviving auxiliary/ghost coefficients. The physical real
witness is -xi tAux thetaBar thetaU/25. Retain it and all nonsymmetric coset
terms. A quadratic inverse does not evaluate this whole interacting functional.

The actual 643 field columns at g=0 are affine, with 225 source drivers and
418 absent sources, all retained. The ordinary j shift and graded Legendre
proof use source-independent regulator/measure and affine-dependence-preserving
normalization at rho=0. Do not silently adopt it for all finite source/contact
schemes or infer nonempty restored prescriptions. Nonlinear operator/source
transport and nonlocal Gamma remain separate.

The actual H-singlet scalar rotation yields 818 primitive and 13,568 source
coefficients. A fresh kinetic/seagull comparison and H-matrix identities bind
the structural current proof, with qualified potential/Euler/master dependencies.
Its polynomial class is nonexact; g times it is basic exact. The real constant
field/source specialization and a trace 24/25 obstruct its specified LOCAL
deformation. Do not call this a failure of Stage D or quantum exclusion.
No inverse g or physical parameter is adopted. All 643 pairs/48 backgrounds
and the 508 physical Euler programs remain unchanged.

preflight_v1 preserves original source and a selected observed transcript,
explicitly not full execution-start attestation. superseded_start_v1 and
primary_attempt_1.json preserve the later dict/set-union execution failure
with start hashes/full log. Only completed routes count. Confirm live Python
processes before retrying; never overwrite completed evidence.

Finalization requires validation_receipt.json and bindings.json. If absent,
export_a10_e5_minimal_target_receipt.py under the pole-blind environment is the
next validation step; first take seal_a10_e5_minimal_target.py --process-snapshot.
It runs 219 tests (174 scientific,24 process,21 governance), two fresh new
routes, 20 predecessor manifests, protected/state bytes and workspace metadata.
Custody remains exit 2/seven. After receipt, seal then commit the exact raw
validated file set locally; no edits during read-only validation and no push.

Next scientific action: actual compatibility/realizability of the conditional
affine-source normalization with W1--W7/A1--A5 Ward, Slavnov and insertion/contact
requirements; then the remaining minimal/primitive and intrinsic-versus-induced
comparison. A closed classical cocycle is not automatically an allowed quantum
counterterm. W6 does not impose a fixed strict transported Tq' on Gamma.
Do not rerun expensive qualified predecessors without scientific need.

State v113/34 of 39, M08/HB1/C5 blocked, C1_GS uncalculated, unresolved custody
and solo-review limitations remain. No activation, source removal, auxiliary
elimination, catalogs, matching, contact, publication or authority promotion.
The full Spin(10) x U(1)PQ objective is incomplete: global scalar boundedness,
physical matching/later phenomenology, complete fermion/Yukawa content and global
PQ quotient remain open. VPC review at 321a33e is completed engineering work;
no VPC runtime is required. Shared assumptions/data/word arithmetic/Python/SymPy/
analyst are disclosed; personnel are not a gate and no external endorsement exists.
