# Research execution handoff, V17

Navigation supersedes V16, not authority. Baseline d138e58. Recover Git/live
processes and [the checkpoint](A10_E5_JOINT_NORMALIZATION_CURRENT.md). Before
seal select frozen_a10_e5_ghost_companion/bindings.json; afterward select
frozen_a10_e5_joint_normalization/bindings.json explicitly. Generic preflight/
e5 is an older bounded delegate, not current scientific acceptance.

Actual g*xi B-Lambda bubble passes all4 Lorentz weights and45x33 group slots.
Both graded Born and closed-ghost Gaussian routes keep odd starts and the
common nonexceptional heat profile. H derivative vertices are nonzero before
their trace; their full trace is zero. No ordinary derivative substitution
for the H covariant fermion or auxiliary elimination is permitted.

The literal Lambda cubics are g Lambda-B-B and xi Lambda-ubar-u. The one-loop
two-point leg/coupling inventory proves no g*xi^2 width pole. Old xi^2 width
pole remains qualified separately. Positive-dimensional orbit/mass insertions
cannot create its dimension-zero logarithmic coefficient.

Klin=g xi[JC N C-Jubar N_M^T ubar+JLambda N_M^T Lambda] changes the width
spuriously. The symmetric width equation derives Kwidth=g xi^2 ubar kappa_aux
Lambda. Do not call this a fitted physical interaction or a changed frozen
fermion. Antisymmetric primitive kernel exists; no universal uniqueness.
K=Klin+Kwidth has132 coefficients. Its complete47,958-coefficient candidate
Cjoint=QK-div(theta)=-delta_K P_E2 has8160 divergence coefficients. All1286
Hamiltonian lift slots compare; physical B/x are unchanged. Old gauge/scalar
source projections, zero ghost kinetic, B-Lambda and selected width agree.
Other interacting images remain untested against actual loop amplitudes.

1089 direct graded source-source checks, real physical pullback,12 H maps,
first-order inverse/pairings and jets pass. Canonical pairing is identity,
not carrier Gram. Retain second-order remainders. Field logBerezinian retains
the auxiliary regulated spacetime trace; source-free shifts only external J.
The action-measure effect begins at hbar^2. Keep background dependence and
the previously qualified regulator/source correction. No quantum A5 claim.

Next smallest increment: g*xi^2 Lambda-ubar-u companion, all three-cubic
triangles plus cubic/quartic bubbles, actual nonsymmetric tensor and proper
UV/IR separation. Compare complete tensor to the joint image, then assess
separately g^2*xi JC-C-C/JB-B-C. No fitting/adoption. Freeze a contract and
stop on the first essential failure/underdefinition. Full restoration still
needs other loops, finite cutoff/source terms, insertions/contacts and measure.

Before receipt take seal_a10_e5_joint_normalization.py --process-snapshot,
then export_a10_e5_joint_normalization_receipt.py. Validation:377 tests, two
strict own-byte routes,28 sealed parents, protected/state/new hashes and
metadata. No edits during audit. Seal, verify index/raw bytes, whitespace,
commit locally only. Keep archived CRLF per-path Git attribute and all old
failed/unfinished records, including the shared Fourier witness correction.

All643 pairs,48 H backgrounds,34 physical/nine source terms, potential/vacuum,
xi/R_H and physical parameters stay. Statev113/34of39 and custody2/seven stay;
custody is not PASS. No activation/catalog/HB1/C5/C1_GS/matching, external
contact, publication or push. Whole Spin(10)xglobal U(1)PQ goal remains active/
incomplete: full E5/A1–A5, IR/anomalies, global boundedness/PQ quotient,
fermion/Yukawa and phenomenology remain. Shared data/software/analyst; solo
review. New route agreement is not external endorsement or physical truth.
