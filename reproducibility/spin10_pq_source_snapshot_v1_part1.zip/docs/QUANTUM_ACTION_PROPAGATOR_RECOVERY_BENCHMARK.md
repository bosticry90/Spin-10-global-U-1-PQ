# Quantum action and propagator recovery benchmark

**Disposition:** foundational quantum-mechanics recovery benchmark established; **active seam: NONE**; **new physics claimed: NO**; **ontological interpretation selected: NONE**.

## What the 2026 photon experiment establishes

Wen *et al.* reconstructed amplitudes for (17^5=1{,}419{,}857) discretized paths in a paraxial single-photon optical system from measured propagators. The measured final distribution agreed with the coherent complex-amplitude sum and disagreed with the corresponding incoherent classical probability sum. The reconstructed path amplitudes were consistent with equal magnitude and phases controlled by the classical action in units of (hbar). The paper reports postulate-II fidelity (94.7%). For postulate I, its introduction reports (94.9%), while the detailed results section reports (94.4%); this benchmark preserves that internal numerical discrepancy rather than choosing one value silently. [Primary paper and full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC13510607/); [DOI](https://doi.org/10.1126/sciadv.aeh1011).

This is a direct operational test of the discrete propagator/path-amplitude structure in the stated optical regime. It is not literal observation of one photon traversing 1.4 million physical trajectories, a comparison that distinguishes path integrals from equivalent Schrödinger or Heisenberg formulations, evidence for quantum gravity, or evidence for physics beyond standard quantum mechanics. The authors argue that the result bears on the reality of paths but also state that more refined methods are required to settle that question.

## Canonical recovery target

When an action formulation exists, ToE-Next prefers it as the comparison interface because one object organizes symmetry, equations of motion, quantum phase, perturbation theory, and semiclassical limits. This is a methodological preference, not a declaration that every fundamental theory must be ontologically an action or that every useful theory admits a conventional local Lagrangian.

A candidate that modifies or underlies quantum theory must recover, in its declared low-energy domain:

1. **Propagator composition.** Intermediate alternatives compose coherently,

   \[
   K(C,A)=\int dB\,K(C,B)K(B,A),
   \]

   with the measure, boundary conditions, state space, and approximation stated.
2. **Action-controlled phase.** In a regime admitting an action description, path or field-history amplitudes reduce to the appropriate normalized form based on

   \[
   e^{iS/\hbar},
   \]

   including any gauge fixing, constraints, determinants, contour prescription, anomalies, and renormalization required for a well-defined prediction.
3. **Operational quantum equivalence.** The construction reproduces the tested Schrödinger/operator predictions in their common domain; a change of representation alone is not new physics.
4. **Field-theory recovery.** The corresponding generating functional yields the required propagators, correlation functions, unitarity or physical-state conditions, Ward/ST identities, and scattering observables to the claimed accuracy.
5. **Classical stationary-phase limit.** A controlled regime exists in which rapidly varying phases suppress nonstationary contributions and the surviving effective dynamics obey the appropriate stationary-action equations, with corrections and validity time bounded.
6. **Quasiclassical recovery.** Interference suppression, stable coarse variables, probability rules, records, and effective classical dynamics satisfy the separate [quasiclassical recovery audit](QUASICLASSICAL_RECOVERY_REFERENCE_AUDIT.md). Stationary phase alone does not establish decoherence, definite outcomes, or the Born rule.

For a candidate without a conventional action, the obligation is operational equivalence to this target where established physics uses it, not forced translation into misleading notation.

## Benchmark classification

| Claim | Authority |
|---|---|
| Coherent sum over the reconstructed discrete histories | Directly tested in the stated optical setup |
| Equal-magnitude/action-phase postulate | Directly tested in the stated optical setup, subject to reported experimental error |
| General interacting QFT path integral | Established theoretical/empirical framework, not tested by this experiment in full generality |
| Curved-spacetime or dynamical-geometry path integral | Future direction only |
| Literal reality of all paths | Unresolved interpretation question |
| Departure from quantum mechanics | None observed |
| New ToE active seam | None admitted |

## Future admission rule

Follow-up work becomes a ToE-Next active seam only if it supplies a specified interacting, decohering, curved-background, or field-theoretic system; a quantitative deviation or recovery claim; an operational observable; and an error-controlled discriminator against standard quantum theory. A proposal to “sum over geometries” without a measure, contour, gauge treatment, state/boundary data, and observable remains motivation rather than an earned quantum-gravity result.

