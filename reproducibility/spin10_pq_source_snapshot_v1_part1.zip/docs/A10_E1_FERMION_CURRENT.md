# A10 E1 typed fermion — current bounded result

The inactive `M08_PHYSICAL_FRAME_GAUGE_FERMION_V1` is qualified as a **derived replacement** under the bounded E1 contract. Equivalence to historical A4-V2/A5-V2 remains unproved; their bytes and the 95c0be0 failure remain preserved.

The complete eight-term expression agrees between indexed and physical-plane routes on 1,797 density coefficients, 691 canonical/background Euler columns, 4,668 nonzero Euler coefficients and 244 boundary coefficients. Required heavy local quantum/background and complete background Ward identities pass. The light quantum variation is the expected gauge fixing. First variations, source-frame pairings, conjugation and adversarial controls pass within their declared scope.

See [result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E1_FERMION_RESULT.md), [contract](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E1_FERMION_CONTRACT_V1.md), [solo review packet](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E1_FERMION_TECHNICAL_REVIEW_PACKET_V1.md), [candidate AST](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e1_fermion/M08_PHYSICAL_FRAME_GAUGE_FERMION_V1.json) and [validation receipt](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e1_fermion/validation_receipt.json).

Stage D remains qualified and inactive. E2–E5 were not executed. Sources, catalogs, HB1/C5 and C1_GS remain untouched; formal authority is 34/39. Historical custody remains exit 2 with seven unresolved references. The next decision is a separately scoped E2 authorization using the explicitly different replacement. Solo review continues without outreach or external endorsement.
