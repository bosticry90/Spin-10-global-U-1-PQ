# E5 joint normalization checkpoint

Navigation only; project_state.json is the sole scientific authority.
Baseline d138e58, statev113/34of39,28 predecessor chains. Full goal active.

The actual g*xi B-Lambda pole matches the paired ghost/nonminimal image.
The g*xi^2 Lambda width pole is absent by the literal graph inventory. Its
spurious source-linear normalization image is canceled by a derived
source-free primitive g xi^2 ubar^T kappa_aux Lambda. This does not fit a
physical coefficient or edit the frozen fermion. The primitive's symmetric
section is fixed; antisymmetric kernel directions are explicitly retained.

The complete inactive generator has132 coefficients and its candidate
47,958, with8,160 current-divergence coefficients. Both routes compare the
full image, all1286 lift slots and selected source/ghost/mixing/width poles.
Independent graded source-source checks cover1089 coefficients. Other
interacting columns remain unmatched to loops. The regulated field measure
retains its auxiliary trace; external sources do not cancel it. No full E5,
finite restoration/contact/quantum A5 or physical IR conclusion follows.

See [the result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_JOINT_NORMALIZATION_RESULT.md),
[the contract](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_JOINT_NORMALIZATION_CONTRACT_V1.md),
and [the receipt](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_joint_normalization/validation_receipt.json).

Next: actual g*xi^2 Lambda-ubar-u triangle and cubic/quartic bubble companions,
then separately g^2*xi JC-C-C/JB-B-C poles. Preserve nonexceptional/UV-IR
distinctions and first-failure stopping. No automatic adoption or activation.

Validation:377 targeted regressions, two strict fresh own-byte routes,
28 parents, protected/new/state SHA and size/mtime metadata. Explicit
preflight uses frozen_a10_e5_joint_normalization/bindings.json after seal;
generic e5 remains an older bounded delegate. Custody2/seven is unresolved.
No authority/catalog/HB1/C5/C1_GS/matching, outreach/publication/push.
Shared inputs/software/analyst; solo review without external endorsement.
