# Actual derivative-gauge evidence, current navigation

project_state.json v113/34 of39 remains sole scientific authority; whole
Spin(10) x global U(1)PQ goal active/incomplete. Latest completed increment is
the actual derivative-gauge companion at baseline25bb6b7. Read the package's
A10_E5_DERIVATIVE_GAUGE_CONTRACT_V1.md and RESULT_V1.md and its frozen
controls/primary/replay/comparison plus validation receipt and bindings.
Before sealing, use the auxiliary-admissibility manifest; after sealing use
frozen_a10_e5_derivative_gauge/bindings.json for preflight byte authentication.

Actual methods agree on all182,250 slots/two independent momentum placements
and allfour Lorentz copies. Full five-family sum has1502/976 physical
derivative slots, reference widths cancel and homogeneous12H checks pass.
The complete inactive member FAILS:512 raw temporal difference words,
2,048 acrossfour polarizations; real Bp13 Euler has36 terms and a nonzero
8sqrt(10)xi/25 witness. Complete actual/candidate IBP currents are retained.
This is not a pure boundary; no EOM/anomaly conclusion. K4 has no derivative
image; lowergxi^2 and lowercandidate projections vanish.

First mismatch stops: no higher/source actual loop, refitting or adoption in
this increment. Qualify the literal source–gauge derivative prerequisite and
complete admissible types under a NEW contract before a dependent repair.
The g^3 quartet remains a prediction. Evidence validation success does not
pass this scientific candidate gate or settle fullE5/quantumA5. Custody2/seven,
shared assumptions/software/analyst, solo-review and epistemic ladder apply.
No physical/catalog/HB1/C5/C1_GS/matching, authority promotion or external action.
