# Research execution handoff

This navigation record is explanatory, not a second scientific ledger.
Start with Git status and `python -B tools/research_session_preflight.py`.
The tool reads the ledger, sealed byte manifests and live process inventory;
it never launches, accepts or repairs a scientific calculation.

Baseline recovered at `1dc61f0`: Stage D, replacement E1, E2 and E3 have bounded
inactive qualifications. E3's sealed auditor passed authentication. All 643
canonical pairs, 48 external backgrounds and 508 physical Euler programs remain
in their declared gauge/scalar scope. Fermion/Yukawa sectors are absent.
See [E3 current record](A10_E3_SYMMETRY_CURRENT.md) and its linked result and
receipt for exact identities, limitations and original validation measurements.

The present user authorizes inactive E4 composite-curvature/nonminimal/quartic
reconciliation and targeted process improvements. Follow the separately
versioned E4 contract. Full BV nilpotence does not prove restricted equivariant
nilpotence; retain the actual nonsymmetric H12/M33 split and every required
source, auxiliary and composite chain rule. Stop at the first essential failure
or missing definition and preserve the exact evidence.

Formal authority remains 34/39, M08 blocked. Historical custody remains exit 2
with seven unresolved bindings. Candidate adoption, source activation, E5,
HB1/C5, catalog reconstruction, finite C1_GS, quantum matching and remote push
are withheld. A bounded E4 PASS would support a separate E5 decision, not
automatic continuation. Historical fermion equivalence remains unproved.

Reuse sealed D–E3 evidence rather than rerunning its expensive derivations.
For authentication, use the pole-blind environment and the E3 auditor without
`--fresh`. For new work, calculation runners stay read-only and exporters
persist only completed artifacts. Independent methods freeze their derivation
before comparison; comparison and adversarial validation follow completion.

Recovery must preserve any live calculations and unrelated working-tree edits.
Unfinished executions have no PASS classification. A preflight failure or
missing process inventory is reported explicitly rather than taken as proof
that nothing is running. Follow [solo review](SOLO_REVIEW_POLICY_V1.md): research
literature, preserve technical objections, contact nobody.

The [gap analysis](AGENTIC_ENGINEERING_GAP_ANALYSIS_V1.md) explains why this adds
navigation and recovery tooling instead of replacing existing research gates.
The [incorporation report](AGENTIC_ENGINEERING_INCORPORATION_RESULT_V1.md) and
[E4 current record](A10_E4_INTERACTION_CURRENT.md) record the measured outcome,
validation and next smallest decision; they do not alter prior sealed records.
After E4 sealing, select its manifest explicitly for a current byte snapshot:

```powershell
python -B tools/research_session_preflight.py --manifest tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e4_interaction/bindings.json
```

The default preflight manifest is the disclosed E3 baseline, not a claim to
have authenticated every newer result. Use the completed receipt and sealed
E4 auditor before its bounded qualification is accepted; E5 is a separate
decision and remains unexecuted.
