# E5 regularity checkpoint

Navigation only; project_state.json remains the sole scientific authority.

The new [result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_REGULARITY_RESULT.md)
and [derivation](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_REGULARITY_DERIVATION_V1.md)
qualify polynomial full-complex regularity, complete minimal Noether/KT
resolution and normality for the inactive ungauge-fixed gauge/scalar action.
The nonminimal chart is canonical with all sources retained. Its unrestricted
doublet contraction does not qualify a Ward/basic-restricted reduction.

Use the new frozen_a10_e5_regularity/bindings.json for explicit preflight after
sealing. audit_a10_e5_regularity.py --fresh repeats only the new read-only routes.
Generic research_check.py e5 still delegates the older declared checkpoint.

The next action is the local-functional theorem/domain/primitive bridge, not
HB1/C5 or matching. W1-W7/A1-A5 stay conditional; full E5 is not PASS. Preserve
34/39, custody exit 2/seven unresolved, all historical controls and solo review.
The overall Spin(10) x U(1)PQ completion goal remains incomplete.
