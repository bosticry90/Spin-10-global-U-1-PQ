# E5 nonminimal retract checkpoint

Navigation only; project_state.json remains the sole scientific authority.

The [result](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_NONMINIMAL_RETRACT_RESULT.md),
[contract](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_NONMINIMAL_RETRACT_CONTRACT_V1.md)
and [derivation](../tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_NONMINIMAL_RETRACT_DERIVATION_V1.md)
establish matching primary/replay nonminimal reduction maps for the full,
background-Ward and joint-basic polynomial complexes, including sources and
ordinary functional divergences. This is a nonminimal lemma, not full E5 or
quantum insertion/canonical equivalence.

All 643 pairs and 48 backgrounds remain. The minimal image has 553 pairs in
transported combinations. The 1,334-coordinate maps agree on 15,693 nonzero
coefficients and implicit zeros; both routes check 16,008 jet controls. Replay
reconstructs 540 physical evaluation-dual H commutators. General polynomial
degree and all-jet coverage follow from the explicit proof.

The homotopy is not canonical. Keep its post-U width/source corrections,
ghost-source cotangent count and gauge-condition projector. The light Gram
row contains its off-diagonal entry. E1's evaluated orbit coefficients retain
mass dimension one. Replay's local type adapter supplies those annotations
from the frozen executable fermion, independently checks the replay vacuum and
canonicalizes symbolic zero terms in its finite scale map. No numerical input
or predecessor is modified. Four failed attempts and their original source
bytes/fingerprints remain excluded from qualification.

Use frozen_a10_e5_nonminimal_retract/bindings.json for explicit preflight once
sealed. Before sealing, authenticate the preceding coupling-ring manifest.
audit_a10_e5_nonminimal_retract.py authenticates completed new routes;
--fresh reruns only these new routes, about 15-20 minutes each in initial runs.
Confirm live Python handles before restarting. Generic research_check.py e5
still authenticates its older declared scope.

Final evidence validation requires the matching new validation_receipt.json
and byte seal. If either is absent, local finalization remains incomplete.
The required receipt records 201 targeted tests, two fresh byte-identical new
routes, unchanged protected/state bytes and custody exit 2/seven references.
Neither a completed route nor a checksum grants director acceptance.

Next: the remaining MINIMAL polynomial source/primitive and intrinsic/induced
comparison against the actual conditional Ward/insertion target. No inverse g
or inferred loop coupling powers. The old raw coupling tangent fails background
Ward and is not a missing quantum class. A1-A5 and full E5 remain open.
Authority v113/34 of 39, M08/HB1/C5 blocked, C1_GS uncalculated, historical
custody unresolved, inactive candidates and solo-review limitations remain.
The full Spin(10) x U(1)PQ goal is incomplete; this lemma does not redefine it.
