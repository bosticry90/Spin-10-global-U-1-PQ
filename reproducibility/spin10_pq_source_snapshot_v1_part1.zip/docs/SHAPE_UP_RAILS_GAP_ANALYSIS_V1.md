# 37signals / Shape Up / Rails applicability audit

Baseline: clean Git `76affe53da3efe7e66bd5e35dc03af1467ee88bd`, authority
`project_state.json` version 113 / 34/39, M08 blocked. The E4 preflight checked
490 declared bindings in thirteen manifests; the sealed E4 auditor passed.
Only this session's read-only recovery processes were observed. D–E4 are
inactive bounded results, not a completed quantum theory. E5 is authorized by
the supplied assessment; catalogs, HB1/C5, activation and matching remain held.
This analysis precedes implementation.

| Principle | Classification | Existing mechanism / smallest response |
| --- | --- | --- |
| Scientific question to evidence to classification | Already satisfied | Versioned contracts, two derivations, adversarial controls, receipts and predecessor byte seals. Retain them. |
| Human-directed acceptance | Already satisfied | Sole formal ledger, epistemic ladder, solo policy, root instructions. No second authority system. |
| Small coherent increments | Already satisfied | D and E1–E4 gates, first-failure stops, inactive candidates. Continue with bounded E5. |
| Convention over configuration | Partially satisfied | Predictable investigation file names exist; environment setup and audit commands still require several manual decisions. Add a thin local check entry point that delegates to existing auditors. |
| Integrated workflow / observability | Partially satisfied | Existing calculation stage logs and complete receipts are good. Add JSON-line events and explicit terminal execution states at the entry point, separate from recorded scientific disposition. |
| Bounded effort | Partially satisfied | First-failure contracts and jet caps exist; add an optional between-step effort boundary and a compact contract checklist. Exhaustion means incomplete, never proof or PASS. |
| Recovery from checkpoints | Already satisfied for sealed work; partial for unfinished runs | Authenticate sealed receipts before reuse. Preserve unfinished attempts. Do not invent partial symbolic caches or count reused work as fresh replay. |
| Local ownership / reproducibility | Already satisfied | Python/SymPy, Git and local immutable evidence. New checks need no service, database, installation or network. |
| Simplicity / duplicate machinery | Potentially harmful if applied indiscriminately | Separate primary/replay mathematics is intentional; frozen runners are evidence dependencies. Do not consolidate them for aesthetic DRY. Consolidate only invocation setup. |
| Standard product deadlines / variable proof quality | Potentially harmful | Reduce engineering scope, never acceptance obligations. A negative or underdefined scientific result is legitimate completion. |
| Rails runtime, web stack, compulsory teams | Inapplicable | No Ruby migration, server, cloud, VPC/Foundry dependency or agent organization. |

The smallest improvement set is a documented delegation command, adversarial
tests for its execution classification, concise conventions/checklist and an
updated explanatory handoff. Existing protected artifacts remain untouched.
No catalog generator, job scheduler, checkpoint database or broad runner
refactor is justified. E5 retains priority over infrastructure expansion.

Adaptation follows primary sources: [Rails doctrine](https://rubyonrails.org/doctrine)
for predictable conventions and integrated operation; [Shape Up boundaries](https://basecamp.com/shapeup/1.2-chapter-03)
for an appetite and a narrow problem; [circuit breaker](https://basecamp.com/shapeup/2.2-chapter-08)
for bounded downside; [adjust to your size](https://basecamp.com/shapeup/4.1-appendix-02)
for avoiding a large-team process in a solo project. These are engineering
comparisons, not sources of mathematical truth or certification of ToE-Next.

Larger recovery changes are deferred until they demonstrate stale-input and
interrupted-step rejection, preserve byte-identical replay, disclose reuse,
and save measured calculation time without a second scientific status store.
Protected-code consolidation would require a versioned equivalence proof,
unchanged negative controls and measurable maintenance reduction first.
