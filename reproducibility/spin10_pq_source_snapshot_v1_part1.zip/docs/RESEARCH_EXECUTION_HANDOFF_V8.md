# Research execution handoff, V8

Navigation supersedes V7, not scientific authority. Recover Git, live processes
and byte seals. Baseline for this increment is 9e67f3b. The new
[nonminimal checkpoint](A10_E5_NONMINIMAL_RETRACT_CURRENT.md) has matching
complete primary/replay routes and a general polynomial Ward/basic retract
proof. All 643 pairs and 48 backgrounds remain; no source is physically removed.

Before sealing, explicit preflight uses
tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_coupling_ring/bindings.json.
After sealing select frozen_a10_e5_nonminimal_retract/bindings.json explicitly.
Never infer the newest scope from generic research_check.py e5; that command
keeps its older checkpoint delegation. A snapshot authenticates bytes, not math.

Read the new contract, derivation, result and receipt. The primary N/U
conjugation and physical-frame replay match 1,334-coordinate homotopy, count,
finite-scale and projection maps. Replay reconstructs 540 physical source H
commutators. Both routes check 16,008 jets and all generator QH+HQ identities.
The source-quadratic control has 47,411 matching counterterm coefficients.
Infinite degree/jet coverage is the stated structural proof, not enumeration.
Keep all physical Euler programs, nonsymmetric heavy terms and composite R_H.

h is not canonical despite h Psi=0. Its post-U source width terms and the
transported ghost-source count/projector are required for this specified
retract. Do not count/delete old source coordinates blindly. Word dimensions
include E1's dimension-one evaluated orbit coefficients. The complete light
Gram row includes its off-diagonal entry. Replay's distinct E1 record schema
is adapted only by declared type annotations and an independent vacuum check;
its finite-scale maps are canonicalized to remove exact symbolic zero terms.

Failed primary attempts 1-2 and replay attempts 1-2 remain with original code,
contracts, fingerprints and logs in superseded_start_v1-v4. They are excluded.
No frozen predecessor or numerical physical input was changed. Completed
primary/replay artifacts must never be overwritten. Preserve any live fresh
validator/runner rather than restarting because an observation timeout expires.
Initial full routes took about 15 and 20 minutes; fresh validation can be long.

Local finalization requires the matching validation_receipt.json and byte seal.
If absent, export_a10_e5_nonminimal_retract_receipt.py is the remaining validation
step under the established pole-blind environment. It runs 201 targeted tests,
authenticates 19 predecessor manifests, freshly regenerates both NEW routes,
checks bounded/protected bytes and workspace metadata, and retains strict
custody exit 2/seven references. No new PASS receipt exists merely because
the routes agree. Before receipt export take seal_a10_e5_nonminimal_retract.py
--process-snapshot once; after completed validation seal with that script.
Commit only the exact validated bounded file set, compare staged raw bytes,
then recover a clean preflight. Never push. Do not edit derivations or inputs
after the read-only transaction begins.

Next scientific action: minimal polynomial source/primitive and intrinsic versus
induced quotient comparison, then actual conditional Ward/insertion obligations.
This lemma reduces those questions separately; it does not identify their
quotients or prove source-free minimal representatives. Retain g=0 in the
declared ring, derive any coupling-power/normalization restriction, and do not
assume inverse g. The original raw coupling tangent fails background Ward and
is not a missing quantum class. W6 does not impose fixed strict Tq' on Gamma.
Actual quantum A1-A5, regulator/QAP/restoration and insertion normalization stay
unproved. The next contract must distinguish linearized cocycles from actual
admissible quantum counterterms.

State v113, 34/39, M08/HB1/C5 blocked, C1_GS uncalculated and custody exit 2/seven
references stay unchanged. No activation, source elimination, catalogs,
matching, personal contact, publication or authority promotion. The full
Spin(10) x U(1)PQ goal remains active/incomplete, including global scalar
boundedness, physical matching/later phenomenology, full fermion/Yukawa content
and global PQ quotient. VPC review is completed engineering work at 321a33e;
no VPC runtime is required here. Solo review discloses shared assumptions/data/
Python/SymPy/analyst and no external endorsement; personnel are not a stop gate.
