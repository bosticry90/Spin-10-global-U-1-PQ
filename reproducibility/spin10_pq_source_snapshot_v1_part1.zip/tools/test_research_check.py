"""Execution-state negative controls; no scientific assertions from process success."""
import json
from pathlib import Path
import subprocess
import unittest
from unittest.mock import patch
from research_check import execute,plan


class ResearchCheckTests(unittest.TestCase):
    def run_fixture(self,mutate=None,fresh=False,budget=None):
        events=[];calls=[]
        def child(command,**kwargs):
            index=len(calls);calls.append(command)
            if index==1:
                stdout='AUDIT '+json.dumps({'status':'PASS_BOUNDED_FAILURE_EVIDENCE_VALIDATION_ONLY',
                    'scientific_gate':'STOP_EXACT_WITNESS','fresh_routes_byte_identical':2})
            elif index==5:stdout='RECORDED_DIGEST_UNRESOLVED:\n'*7
            else:stdout='bounded check'
            result=subprocess.CompletedProcess(command,2 if index==5 else 0,stdout,'')
            return mutate(index,result) if mutate else result
        with patch.object(Path,'read_bytes',return_value=b'frozen authority'),patch.object(Path,'is_file',return_value=True):
            terminal=execute('e5',fresh=fresh,budget=budget,run=child,emit=events.append,clock=lambda:0)
        return terminal,events,calls

    def test_completed_negative_scientific_result_is_not_scientific_PASS(self):
        row,events,calls=self.run_fixture()
        self.assertEqual(row['execution_state'],'COMPLETED');self.assertEqual(len(calls),6)
        self.assertEqual(row['recorded_scientific_gate'],'STOP_EXACT_WITNESS')
        self.assertTrue(all(e['scientific_acceptance']=='NOT_PERFORMED' for e in events))

    def test_environment_and_commands_preserve_guard_and_no_bytecode(self):
        def change(i,result):return result
        with patch.object(Path,'read_bytes',return_value=b'x'),patch.object(Path,'is_file',return_value=True):
            captured=[]
            def run(cmd,**kw):
                captured.append(kw);return subprocess.CompletedProcess(cmd,1,'bad','')
            execute('e4',run=run,emit=lambda e:None)
        self.assertEqual(captured[0]['env']['PYTHONDONTWRITEBYTECODE'],'1')
        self.assertTrue(captured[0]['env']['PYTHONPATH'].endswith('pole_blind_validation_guard'))

    def test_failed_child_is_terminal_and_later_checks_not_run(self):
        def fail(i,result):result.returncode=1;return result
        row,_,calls=self.run_fixture(fail)
        self.assertEqual(row['execution_state'],'FAILED');self.assertEqual(len(calls),1)

    def test_protected_boundary_blocked_no_retry(self):
        def fail(i,result):result.returncode=1;result.stderr='POLE_BLIND_VALIDATION_READ_DENIED';return result
        row,_,calls=self.run_fixture(fail)
        self.assertEqual(row['execution_state'],'BLOCKED');self.assertEqual(len(calls),1)

    def test_budget_exhaustion_is_inconclusive_no_child(self):
        row,_,calls=self.run_fixture(budget=0)
        self.assertEqual(row['execution_state'],'INCONCLUSIVE');self.assertFalse(calls)

    def test_cancellation_is_never_complete(self):
        def stop(i,result):raise KeyboardInterrupt
        row,_,calls=self.run_fixture(stop)
        self.assertEqual(row['execution_state'],'CANCELED');self.assertEqual(len(calls),1)

    def test_missing_seal_does_not_launch_unsealed_work(self):
        with patch.object(Path,'read_bytes',return_value=b'x'),patch.object(Path,'is_file',return_value=False):
            row=execute('e5',run=lambda *a,**k:self.fail('child launched'),emit=lambda e:None)
        self.assertEqual(row['execution_state'],'BLOCKED')

    def test_wrong_custody_count_cannot_pass(self):
        def change(i,result):
            if i==5:result.stdout='RECORDED_DIGEST_UNRESOLVED:\n'*6
            return result
        row,_,_=self.run_fixture(change)
        self.assertEqual(row['execution_state'],'FAILED')

    def test_unexpected_custody_zero_not_treated_as_pass(self):
        def change(i,result):
            if i==5:result.returncode=0
            return result
        row,_,_=self.run_fixture(change)
        self.assertEqual(row['execution_state'],'FAILED')

    def test_missing_audit_result_blocks(self):
        def change(i,result):
            if i==1:result.stdout='process returned zero only'
            return result
        row,_,_=self.run_fixture(change)
        self.assertEqual(row['execution_state'],'BLOCKED')

    def test_fresh_request_needs_completed_fresh_receipt(self):
        def change(i,result):
            if i==1:result.stdout='AUDIT '+json.dumps({'status':'PASS_BOUNDED_EVIDENCE_VALIDATION_ONLY','scientific_gate':'bounded','fresh_routes_byte_identical':0})
            return result
        row,_,_=self.run_fixture(change,fresh=True)
        self.assertEqual(row['execution_state'],'FAILED')
        self.assertNotIn('--fresh',plan('e4')[1][1]);self.assertIn('--fresh',plan('e4',True)[1][1])

    def test_formal_state_drift_rejected(self):
        with patch.object(Path,'read_bytes',side_effect=[b'old',b'new']),patch.object(Path,'is_file',return_value=True):
            row=execute('e4',run=lambda cmd,**kw:subprocess.CompletedProcess(cmd,0,'',''),emit=lambda e:None)
        self.assertEqual(row['execution_state'],'FAILED')

    def test_E4_fresh_requires_all_three_routes(self):
        count=[0]
        def run(cmd,**kw):
            count[0]+=1
            value='AUDIT '+json.dumps({'status':'PASS_BOUNDED_EVIDENCE_VALIDATION_ONLY',
                'scientific_gate':'bounded','fresh_routes_byte_identical':2})
            return subprocess.CompletedProcess(cmd,0,value,'')
        with patch.object(Path,'read_bytes',return_value=b'x'),patch.object(Path,'is_file',return_value=True):
            row=execute('e4',fresh=True,run=run,emit=lambda e:None)
        self.assertEqual(row['execution_state'],'FAILED');self.assertEqual(count[0],2)


if __name__=='__main__':unittest.main()
