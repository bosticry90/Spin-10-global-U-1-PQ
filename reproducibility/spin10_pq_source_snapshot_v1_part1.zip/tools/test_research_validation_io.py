"""Large diagnostic stderr must not deadlock the validation capture operation."""
import os
from pathlib import Path
import sys
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from validate_a10_e4_interaction import run_captured


class ValidationIOTests(unittest.TestCase):
    def test_large_stderr_and_stdout_complete(self):
        child="import sys; sys.stderr.write('x'*65536); sys.stderr.flush(); print('COMPLETE')"
        p=run_captured([sys.executable,'-B','-c',child],Path(__file__).resolve().parents[1],os.environ.copy(),timeout=15)
        self.assertEqual(p.returncode,0)
        self.assertEqual(p.stderr,'x'*65536)
        self.assertEqual(p.stdout.strip(),'COMPLETE')


if __name__=='__main__':unittest.main()
