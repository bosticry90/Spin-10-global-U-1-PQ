"""Opt-in read guard for validating a pole-blind continuation.

Loaded only when this directory is explicitly placed on PYTHONPATH.  Legacy
audits are not silently skipped: a forbidden open fails visibly before access.
"""
from pathlib import Path
import sys

DENIED = {
    "frozen_current_rule_r6_primary", "frozen_current_rule_r7_replay",
    "frozen_current_rule_r8_r12", "frozen_d3", "frozen_d4",
    "frozen_d4_corrected", "frozen_d5", "frozen_d6",
}


def guard(event, arguments):
    if event != "open" or not arguments or not isinstance(arguments[0], (str, bytes)):
        return
    value = arguments[0]
    if isinstance(value, bytes):
        value = value.decode("utf-8", errors="replace")
    path = Path(value)
    if {part.casefold() for part in path.parts} & DENIED:
        raise PermissionError("POLE_BLIND_VALIDATION_READ_DENIED: " + str(path))


sys.addaudithook(guard)
