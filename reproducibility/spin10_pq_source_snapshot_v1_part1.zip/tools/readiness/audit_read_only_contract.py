"""Fail if a Python audit entry point contains filesystem mutation calls."""

from __future__ import annotations

import ast
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
MUTATORS = {
    "write_text", "write_bytes", "mkdir", "unlink", "rename", "replace",
    "rmdir", "touch", "save", "savez", "dump",
}


def call_name(node: ast.Call) -> str:
    target = node.func
    if isinstance(target, ast.Attribute):
        return target.attr
    if isinstance(target, ast.Name):
        return target.id
    return ""


def main() -> None:
    violations: list[str] = []
    audits = sorted(ROOT.rglob("audit_*.py"))
    for path in audits:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            name = call_name(node)
            if name in MUTATORS:
                violations.append(f"{path.relative_to(ROOT)}:{node.lineno}:{name}")
            if name == "open":
                mode = None
                if len(node.args) > 1 and isinstance(node.args[1], ast.Constant):
                    mode = node.args[1].value
                for keyword in node.keywords:
                    if keyword.arg == "mode" and isinstance(keyword.value, ast.Constant):
                        mode = keyword.value.value
                if isinstance(mode, str) and any(flag in mode for flag in "wax+"):
                    violations.append(f"{path.relative_to(ROOT)}:{node.lineno}:open({mode})")
    if violations:
        raise RuntimeError("AUDIT_MUTATION_CONTRACT_VIOLATION\n" + "\n".join(violations))
    print("AUDIT_READ_ONLY_CONTRACT_PASS")
    print("AUDIT_ENTRY_POINTS", len(audits))


if __name__ == "__main__":
    main()
