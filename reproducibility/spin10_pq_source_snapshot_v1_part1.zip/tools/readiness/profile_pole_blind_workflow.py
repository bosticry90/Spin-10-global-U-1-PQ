"""Opt-in diagnostic profiler; does not alter exact algorithms or promotion gates.

Run via execute/verify drivers, not as an audit. Reports are written after the
measured task, normally to a temporary directory outside the workspace. Python
subprocess.run stages are recursively measured; arbitrary native descendants
are not instrumented. No dependency installation or GPU execution is performed.
"""
from __future__ import annotations

import argparse
import cProfile
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import pstats
import runpy
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[2]
GUARD = ROOT / 'tools/pole_blind_validation_guard'
METRICS = {}


def record_metric(name, value):
    """Future stage hooks: cache counters, matrix sizes/ranks, worker census."""
    METRICS[name] = value


def process_counters():
    if os.name != 'nt':
        return {'cpu_seconds': time.process_time(), 'peak_working_set_bytes': None,
                'os_io_read_transfer_bytes': None, 'os_io_write_transfer_bytes': None}
    class Memory(ctypes.Structure):
        _fields_ = [('cb', wintypes.DWORD), ('PageFaultCount', wintypes.DWORD)] + [
            (n, ctypes.c_size_t) for n in ('PeakWorkingSetSize', 'WorkingSetSize',
            'QuotaPeakPagedPoolUsage', 'QuotaPagedPoolUsage',
            'QuotaPeakNonPagedPoolUsage', 'QuotaNonPagedPoolUsage',
            'PagefileUsage', 'PeakPagefileUsage')]
    class IO(ctypes.Structure):
        _fields_ = [(n, ctypes.c_ulonglong) for n in ('ReadOperationCount',
            'WriteOperationCount', 'OtherOperationCount', 'ReadTransferCount',
            'WriteTransferCount', 'OtherTransferCount')]
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
    kernel.GetProcessIoCounters.argtypes = [wintypes.HANDLE, ctypes.POINTER(IO)]
    psapi = ctypes.WinDLL('psapi', use_last_error=True)
    psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(Memory), wintypes.DWORD]
    handle = kernel.GetCurrentProcess()
    times = [wintypes.FILETIME() for _ in range(4)]
    mem = Memory(); mem.cb = ctypes.sizeof(mem)
    io = IO()
    if not (kernel.GetProcessTimes(handle, *(ctypes.byref(t) for t in times)) and
            kernel.GetProcessIoCounters(handle, ctypes.byref(io)) and
            psapi.GetProcessMemoryInfo(handle, ctypes.byref(mem), mem.cb)):
        raise ctypes.WinError(ctypes.get_last_error())
    ticks = lambda t: (t.dwHighDateTime << 32) + t.dwLowDateTime
    return {'cpu_seconds': (ticks(times[2]) + ticks(times[3])) / 10_000_000,
            'peak_working_set_bytes': mem.PeakWorkingSetSize,
            'os_io_read_transfer_bytes': io.ReadTransferCount,
            'os_io_write_transfer_bytes': io.WriteTransferCount}


def run_profiled(command, directory, *, cprofile_pattern='', read_only=True):
    """Return CompletedProcess plus per-process records; all output stays local."""
    report_dir = Path(directory).resolve()
    report_dir.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
               PYTHONPATH=str(GUARD), TOE_PROFILE_DIR=str(report_dir),
               TOE_PROFILE_CPROFILE_PATTERN=cprofile_pattern,
               TOE_PROFILE_READ_ONLY='1' if read_only else '0')
    result = subprocess.run([sys.executable, str(Path(__file__).resolve()),
                             '--child', *map(str, command)], cwd=ROOT, env=env,
                             capture_output=True, text=True, encoding='utf-8', errors='replace')
    records = [json.loads(p.read_text(encoding='utf-8')) for p in sorted(report_dir.glob('*.json'))]
    return result, records


def child(command):
    assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED'), 'POLE_GUARD_REQUIRED'
    sys.modules['profile_pole_blind_workflow'] = sys.modules[__name__]
    assert command and Path(command[0]).is_file()
    report_dir = Path(os.environ['TOE_PROFILE_DIR'])
    script = Path(command[0]).resolve()
    raw_run = subprocess.run
    started = time.perf_counter(); initial = process_counters()
    reads = set(); writes = set(); counts = {'python_read_open_attempts': 0,
                                            'python_write_open_attempts': 0}
    denied = []; child_stages = []
    protected = [ROOT, Path(str(ROOT) + '-active-data')]

    def open_hook(event, arguments):
        if event != 'open' or not arguments or not isinstance(arguments[0], (str, bytes)):
            return
        path = os.fsdecode(arguments[0]); mode = arguments[1] or ''
        flags = arguments[2] if len(arguments) > 2 else 0
        write = any(c in mode for c in 'wax+') or bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC))
        absolute = os.path.normcase(os.path.abspath(path))
        if write:
            counts['python_write_open_attempts'] += 1; writes.add(absolute)
            if os.environ.get('TOE_PROFILE_READ_ONLY') == '1' and any(
                absolute == os.path.normcase(str(p)) or absolute.startswith(os.path.normcase(str(p)) + os.sep)
                for p in protected):
                raise PermissionError('PROFILE_READ_ONLY_WRITE_DENIED: ' + path)
        else:
            counts['python_read_open_attempts'] += 1; reads.add(absolute)

    sys.addaudithook(open_hook)

    def measured_run(args, *positional, **kwargs):
        if isinstance(args, (tuple, list)) and len(args) >= 2 and str(args[0]) == sys.executable and str(args[1]).endswith('.py'):
            script_path = Path(args[1]).resolve()
            if script_path != Path(__file__).resolve():
                child_stages.append(str(script_path.relative_to(ROOT)) if script_path.is_relative_to(ROOT) else script_path.name)
                args = [args[0], str(Path(__file__).resolve()), '--child', *args[1:]]
        return raw_run(args, *positional, **kwargs)

    subprocess.run = measured_run
    sys.path.insert(0, str(script.parent)); sys.argv = [str(script), *command[1:]]
    label = script.relative_to(ROOT).as_posix() if script.is_relative_to(ROOT) else script.name
    profile = cProfile.Profile() if os.environ.get('TOE_PROFILE_CPROFILE_PATTERN') and os.environ['TOE_PROFILE_CPROFILE_PATTERN'] in label else None
    code = 0
    try:
        if profile: profile.enable()
        runpy.run_path(str(script), run_name='__main__')
    except SystemExit as error:
        code = error.code if isinstance(error.code, int) else (0 if error.code is None else 1)
        if code: raise
    except BaseException as error:
        code = 1
        if 'POLE_BLIND_VALIDATION_READ_DENIED' in str(error): denied.append(str(error))
        raise
    finally:
        if profile: profile.disable()
        final = process_counters(); wall = time.perf_counter() - started
        cpu = final['cpu_seconds'] - initial['cpu_seconds']
        top = []
        if profile:
            for (filename, line, function), (primitive, total, own, cumulative, _) in sorted(
                    pstats.Stats(profile).stats.items(), key=lambda item: item[1][3], reverse=True)[:50]:
                top.append({'file': filename, 'line': line, 'function': function,
                            'primitive_calls': primitive, 'total_calls': total,
                            'self_seconds': own, 'cumulative_seconds': cumulative})
        record = {'stage': label, 'arguments': command[1:], 'exit_code': code,
            'wall_seconds': wall, 'cpu_seconds_self': cpu,
            'average_cpu_cores_self': cpu / wall if wall else None,
            'peak_working_set_bytes': final['peak_working_set_bytes'],
            'os_io_read_transfer_bytes': None if final['os_io_read_transfer_bytes'] is None else final['os_io_read_transfer_bytes'] - initial['os_io_read_transfer_bytes'],
            'os_io_write_transfer_bytes': None if final['os_io_write_transfer_bytes'] is None else final['os_io_write_transfer_bytes'] - initial['os_io_write_transfer_bytes'],
            **counts, 'unique_python_read_paths': len(reads), 'unique_python_write_paths': len(writes),
            'cache_hits': METRICS.get('cache_hits'), 'cache_misses': METRICS.get('cache_misses'),
            'matrix_dimensions_and_ranks': METRICS.get('matrix_dimensions_and_ranks'),
            'worker_utilization': METRICS.get('worker_utilization'), 'custom_metrics': METRICS,
            'child_stages': child_stages, 'denied_pole_access': denied,
            'cprofile_enabled': profile is not None, 'top_cumulative_functions': top,
            'measurement_semantics': 'Open attempts are not successful reads or logical byte counts; OS transfers include runtime/pipe I/O. Peak RSS and CPU are this process only. Uninstrumented cache/matrix/worker metrics are null. Profiling overhead is not subtracted.'}
        record['profiler_source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        (report_dir / (uuid.uuid4().hex + '.json')).write_text(json.dumps(record, sort_keys=True, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--child', action='store_true', required=True)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    options = parser.parse_args(); child(options.command)
