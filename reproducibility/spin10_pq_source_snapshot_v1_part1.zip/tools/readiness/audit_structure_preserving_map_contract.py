"""Read-only methodological contract and invertible-map negative regression."""
from pathlib import Path
import sympy as s

ROOT=Path(__file__).resolve().parents[2]


def main():
    charter=(ROOT/'CHARTER.md').read_text(encoding='utf-8')
    policy=(ROOT/'tools/readiness/COMPUTATIONAL_AUTHORITY_POLICY.md').read_text(encoding='utf-8')
    rule='A translation map earns authority only for the structures it is proven to preserve.'
    assert rule in charter and rule in policy
    for phrase in ('domain, codomain','orientation','Equivariance','every relevant symmetry generator',
                   'Invariant-pairing','Constraint preservation','conjugation','independently defined physical action',
                   'negative or adversarial control','not retroactively certify'):
        assert phrase in policy,phrase
    generator=s.Matrix([[0,1],[1,0]])
    wrong=s.diag(1,2)
    assert wrong.rank()==2 and wrong*wrong.inv()==s.eye(2)
    assert generator*wrong-wrong*generator!=s.zeros(2)
    assert generator*s.eye(2)-s.eye(2)*generator==s.zeros(2)
    print('STRUCTURE_PRESERVING_MAP_CONTRACT_PASS_NO_SCIENTIFIC_PROMOTION')


if __name__=='__main__':
    main()
