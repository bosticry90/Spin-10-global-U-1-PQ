# Computational authority policy

Computational tools are selected by the claim they must support. Installing or invoking more engines does not by itself increase scientific authority.

| Claim need | Default | Authority ceiling | Escalation trigger |
|---|---|---|---|
| Exact rational or symbolic algebra | SymPy with Python-FLINT | Promotion-capable when exact and audited | expression growth or consequential independent replay |
| Exact rank, commutant, or projector algebra | FLINT or Nemo | Promotion-capable | basis-completeness and rank claims |
| Numerical exploration and eigensystems | NumPy/SciPy | Diagnostic by default | exact reconstruction or certified numerics |
| Independent exact backend | Julia/Nemo | Strong replay | consequential shared-Python failure risk |
| Tensor/QFT algebra | SymPy; Cadabra only when representation independence matters | Claim-dependent | convention or tensor-identity adjudication |
| Graph/AST invariants | Python plus property tests | Infrastructure verification | automorphism, routing, orientation, or serialization risks |
| Finite logical/state invariants | Z3/cvc5 or VPC | Exact bounded verification | authority, dependency, or finite combinatorial claims |
| Stable small theorem | Lean | Formal mathematical authority only | definitions and semantic map are frozen |
| AI | proposer, implementer, adversary, integrator | Never standalone authority | always bounded by frozen calculation evidence |

## Protected audit semantics

Every `audit_*` entry point is read-only. It validates frozen artifacts and exits nonzero on drift. State-changing operations must use an explicitly named `compute`, `execute`, `freeze`, `promote`, or `sync` command. The repository audit checks this rule statically; promotion review should also compare tracked-file hashes before and after audit execution.

## Required task header

Every new nontrivial computational task must state:

```text
Physics decision enabled:
Current blocker removed:
Why existing tools are insufficient:
Minimum new implementation surface:
Structure-preservation obligations (maps only; otherwise explain N/A):
Stopping condition:
What will be deleted or deactivated if this does not work:
```

If those fields cannot be answered concretely, the task should remain parked.

## Prerequisite consistency before costly expansion

Before constructing a costly catalog, representation space or computational
expansion for a proposed mathematical operation, establish that the operation
is fully defined and satisfies its required consistency identities on the
smallest decisive test domain. Bind the generating objects, source and sign
conventions, target domain, quotient/descent obligations and stopping condition
before scale-up. Reuse a previously qualified theorem or implementation where
its actual hypotheses cover the intended operation; do not substitute a name
or a successful dimension count for those hypotheses.

For BRST/BV or cohomological work, test the appropriate graded source,
closure/complex and domain-preservation identities before building new large
operator spaces intended for that operation. An exact failed identity stops
that proposed application; increasing the catalog or formalizing an unsettled
convention cannot repair it. A small passing test is a prerequisite, not a
substitute for the subsequent complete-space acceptance gates.

This is a prospective sequencing improvement. The existing
[JCAT catalog](../two_loop_qft_compiler_v1/m08_independent_replay_package_v1/JCAT_PACKET_CATALOG_RESULT.md)
and [T5 target language](../two_loop_qft_compiler_v1/m08_independent_replay_package_v1/T5_TARGET_CATALOG_RESULT.md)
retain their independently earned bounded authority. Their intended C5
application still requires source/domain consistency; the
[STC obstruction report](../two_loop_qft_compiler_v1/m08_independent_replay_package_v1/STC_SOURCE_TRANSPORT_RESULT.md)
localizes that missing prerequisite.
This rule neither changes an old result nor authorizes the next investigation.

The subsequent [interacting nonminimal BV architecture preflight](../two_loop_qft_compiler_v1/m08_independent_replay_package_v1/NONMINIMAL_BV_M08_ARCHITECTURE_RESULT.md)
applies the prerequisite rule before extending sources: an exact scalar
forward-square obstruction stops the proposed full-M08 construction. The
free comparator remains qualified only in its own scope; neither a new source
alphabet nor H-basic/C5 computation is authorized. Specialist semantic review
of the physical scalar/ghost convention remains outstanding.

## Independence record

Independent calculations report these flags separately:

```text
ALGORITHM_INDEPENDENT
CODE_PATH_INDEPENDENT
LIBRARY_INDEPENDENT
RUNTIME_INDEPENDENT
```

No aggregate independence score is permitted.

## Structure preserving map contract

A translation map earns authority only for the structures it is proven to preserve. This is a standing operating requirement for basis changes, embeddings, dualizations, field redefinitions, operator dictionaries, EFT matching and UV/IR recovery maps. It does not retroactively certify existing maps or add a scientific PASS to the ledger.

Before a map transfers authority, its calculation record must specify the domain, codomain, coordinate conventions, orientation, applicable structures and acceptance equations. Each obligation must be tested independently or marked not applicable with a reason:

- Rank or invertibility where required, and reconstruction or round trip.
- Equivariance under every relevant symmetry generator; for `A : physical -> registry`, test `T_registry A = A T_physical`. For nonlinear or limiting recovery maps, state the corresponding commuting relation and its domain of validity.
- Invariant-pairing and dual compatibility, including non-orthonormal metrics.
- Constraint preservation and conjugation, reality or statistics compatibility where those structures are in scope.
- Agreement with an independently defined physical action and the declared known limits.
- A negative or adversarial control capable of rejecting a structurally wrong but invertible map.

Exact claims require exact residuals. Numerical claims must declare tolerances, conditioning, uncertainty and their narrower authority ceiling before comparison. Inapplicable structures are not silently treated as passed. A map certified only for span or reconstruction may be used only for that purpose, not as an equivariant physical dictionary.

Freeze coefficients and conventions before comparison; retain failed historical maps as versioned negative controls. The M08 scalar-adapter counterexample provides concrete motivation: rank 328 and complete reconstruction survived a raw/orthonormal coordinate mismatch while symmetry covariance failed. Its evidence remains in the [versioned checkpoint report](../two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SCALAR_DUAL_BRIDGE_V2_RESULT.md). Adopting this requirement changes methodology, not formal scientific authority.

When a basis changes, transport coordinate-dependent tensors and coefficients through the certified maps. Unchanged physical values need not have unchanged coordinate entries. If an acceptance contract requires both when they are incompatible, preserve the discrepancy and request adjudication instead of rescaling a map or silently waiving a gate.

## Active scientific seam

The active decision remains whether the missing finite centered gauge/scalar two-loop threshold `C1_GS` can materially resolve the frozen canonical Spin(10) benchmark's direct gauge mismatch. Infrastructure work must remove a named blocker or increase the reliability of that decision. Layer 6 remains separately gated.

## Methodology navigation (scope-specific, not a second ledger)

These labels describe use or activation conditions, not scientific gate
verdicts, completeness percentages or a new authority hierarchy. Current
scientific state remains in [`project_state.json`](../../project_state.json).

| Method | Status in the present work | Evidence or activation condition |
|---|---|---|
| Exact bounded construction, independent replay and fail-fast controls | `APPLIED` within their stated independence boundaries | [JCAT](../two_loop_qft_compiler_v1/m08_independent_replay_package_v1/JCAT_PACKET_CATALOG_RESULT.md), [T5](../two_loop_qft_compiler_v1/m08_independent_replay_package_v1/T5_TARGET_CATALOG_RESULT.md), [STC](../two_loop_qft_compiler_v1/m08_independent_replay_package_v1/STC_SOURCE_TRANSPORT_RESULT.md); independent code or backend is not automatically independent source semantics. |
| Performance measurement | `APPLIED` diagnostically | Existing [HB0 profile interpretation](../two_loop_qft_compiler_v1/m08_independent_replay_package_v1/HB0_PERFORMANCE_INTERPRETATION.md); no new performance run is implied by this navigation. |
| Settled small-theorem Lean pilot | `SPECIFIED_NOT_EXECUTED` | [Rank-8 pilot specification](../../docs/ai_research_epistemic_ladder_v1/RANK8_LEAN_PILOT_SPEC.md); activate only after definitions, semantic mapping and proof obligations are frozen. No Lean certificate is claimed. |
| Bounded adversarial-agent pilot | `SPECIFIED_NOT_EXECUTED` | [Four-role pilot specification](../../docs/ai_research_epistemic_ladder_v1/ADVERSARIAL_AGENT_PILOT_SPEC.md), not evidence of its execution. |
| Large adversarial swarm | `DEFERRED` | A separately scoped claim, genuine independence and measured benefit must justify activation; the bounded pilot does not authorize a swarm. |
| GPU backend | `DEFERRED` | The [measured profile](../two_loop_qft_compiler_v1/m08_independent_replay_package_v1/HB0_PERFORMANCE_INTERPRETATION.md) does not establish a dominant GPU-suitable kernel; require profiling and a bounded exact CPU comparison first. |
| Quantum hardware for the current exact source-sign problem | `NOT_APPLICABLE` | This is a finite symbolic consistency question; no quantum-simulation observable is specified. Future use requires a candidate Hamiltonian, observable and independent error/representation controls. |
| Quantum-dynamics and broad gravity/ontology benchmarks | `SPECIFIED_NOT_EXECUTED` as candidate tests | [Quantum-dynamics benchmark](../../docs/toe_candidate_gates_v1/QUANTUM_DYNAMICAL_STRUCTURE_BENCHMARK.md) and [candidate-gate specifications](../../docs/toe_candidate_gates_v1/); require a separately admitted source and bounded test before execution. |
| Independent specialist review of source conventions | `REQUIRES_REVIEW` | The [bounded conventional/partial-gauge source review](../two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SOURCE_CONVENTION_REVIEW_RESULT.md) identifies a candidate convention replacement; the [full-source impact preflight](../two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SOURCE_CONVENTION_IMPACT_RESULT.md) then rejects its promotion on an exact nonminimal/source square. The [free nonminimal BV comparator](../two_loop_qft_compiler_v1/m08_independent_replay_package_v1/NONMINIMAL_BV_FREE_RESULT.md) resolves the small counterexample with complete canonical pairing, not the full M08 construction. Internal derivation and separate replay are not external specialist review or a full M08 repair. The [STC obstruction](../two_loop_qft_compiler_v1/m08_independent_replay_package_v1/STC_SOURCE_TRANSPORT_RESULT.md) remains historical evidence. |
| Model-wide assumption reduction | `REQUIRES_REVIEW` before any such claim | The [dependency scaffold](../../docs/DEPENDENCY_SCAFFOLD.md) requires before/after assumption accounting and controlled recoveries; catalog qualification is not evidence of net physical assumption reduction. |

