"""Derive current Layer-5 authority summaries from the canonical ledger.

The 39-row UV ledger is the scientific source of truth.  Development
checkpoints may refine the implementation blocker without changing the formal
M08 attempt-1 disposition.
"""

from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def artifact_hash(payload: dict[str, Any], field: str) -> str:
    work = dict(payload)
    work.pop(field, None)
    return sha256(json.dumps(work, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def load_ledger() -> dict[str, Any]:
    payload = json.loads((HERE / "uv_pole_evaluator_results.json").read_text(encoding="utf-8"))
    assert payload["result_sha256"] == artifact_hash(payload, "result_sha256")
    return payload


def load_checkpoint(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert payload["artifact_sha256"] == artifact_hash(payload, "artifact_sha256")
    return payload


def load_current_development_blocker() -> dict[str, Any]:
    base = HERE / "m08_independent_replay_package_v1"
    target = load_checkpoint(base / "T5_target_catalog_checkpoint.json")
    if target is not None:
        assert target["status"] == "PASS_COMPLETE_POSITIVE_GHOST_TARGET_CATALOG"
        assert target["target_catalog_promoted"] and target["weight_contract_qualified"]
        assert target["joint_catalog_promoted"] and not target["C5_promoted"]
        assert not target["H_basic_qualified"] and not target["definition_uses_B_Sigma_images"]
        links = target["preserved_authority_links"]
        return {
            "blocker": target["current_blocker"],
            "current_checkpoint_sha256": target["artifact_sha256"],
            "current_checkpoint_kind": "C5_POSITIVE_GHOST_TARGET_CATALOG_PROMOTED",
            "jcat2_v2_checkpoint_sha256": links["jcat2_v2_checkpoint_sha256"],
            "c2_d5_checkpoint_sha256": links["c2_d5_checkpoint_sha256"],
            "c3_c4_checkpoint_sha256": links["c3_c4_checkpoint_sha256"],
            "c5_checkpoint_sha256": target["artifact_sha256"],
            "st_seed_checkpoint_sha256": links["st_seed_checkpoint_sha256"],
            "action_ast_checkpoint_sha256": links["action_ast_checkpoint_sha256"],
        }
    weight_grading = load_checkpoint(base / "frozen_c5_weight_grading/C5_weight_grading_checkpoint.json")
    if weight_grading is not None:
        assert weight_grading["status"] == "BLOCKED_TARGET_CATALOG_QUALIFICATION_WEIGHT_CONTRACT_PASSED"
        assert weight_grading["weight_contract_qualified"] and weight_grading["joint_catalog_promoted"]
        assert not weight_grading["C5_promoted"] and not weight_grading["target_catalog_promoted"]
        links = weight_grading["preserved_authority_links"]
        return {
            "blocker": weight_grading["current_blocker"],
            "current_checkpoint_sha256": weight_grading["artifact_sha256"],
            "current_checkpoint_kind": "C5_WEIGHT_CONTRACT_TARGET_CATALOG_PENDING",
            "jcat2_v2_checkpoint_sha256": links["jcat2_v2_checkpoint_sha256"],
            "c2_d5_checkpoint_sha256": links["c2_d5_checkpoint_sha256"],
            "c3_c4_checkpoint_sha256": links["c3_c4_checkpoint_sha256"],
            "c5_checkpoint_sha256": weight_grading["artifact_sha256"],
            "st_seed_checkpoint_sha256": links["st_seed_checkpoint_sha256"],
            "action_ast_checkpoint_sha256": links["action_ast_checkpoint_sha256"],
        }
    complex_preflight = load_checkpoint(base / "frozen_c5_complex_preflight/C5_complex_preflight_checkpoint.json")
    if complex_preflight is not None:
        assert complex_preflight["status"] == "BLOCKED_C5_0_GRADED_CLOSURE_CONTRACT_C5_1_THROUGH_C5_12_NOT_EXECUTED"
        assert complex_preflight["joint_catalog_promoted"] and not complex_preflight["C5_promoted"]
        links = complex_preflight["preserved_authority_links"]
        return {
            "blocker": complex_preflight["current_blocker"],
            "current_checkpoint_sha256": complex_preflight["artifact_sha256"],
            "current_checkpoint_kind": "C5_GRADED_CLOSURE_CONTRACT_BLOCKED",
            "jcat2_v2_checkpoint_sha256": links["jcat2_v2_checkpoint_sha256"],
            "c2_d5_checkpoint_sha256": links["c2_d5_checkpoint_sha256"],
            "c3_c4_checkpoint_sha256": links["c3_c4_checkpoint_sha256"],
            "c5_checkpoint_sha256": complex_preflight["artifact_sha256"],
            "st_seed_checkpoint_sha256": links["st_seed_checkpoint_sha256"],
            "action_ast_checkpoint_sha256": links["action_ast_checkpoint_sha256"],
        }
    local_catalog = load_checkpoint(base / "frozen_jcat_packet_catalog/JCAT12_checkpoint.json")
    if local_catalog is not None:
        assert local_catalog["status"] == "PASS_COMPLETE_JOINT_LOCAL_OPERATOR_CATALOG_STOPPED_AT_JCAT12"
        assert local_catalog["joint_catalog_promoted"] and local_catalog["ordered_basis_promoted"]
        assert local_catalog["JCAT7_promoted"] and local_catalog["all_431_expansion_addresses_preserved"]
        links = local_catalog["preserved_authority_links"]
        return {
            "blocker": local_catalog["current_blocker"],
            "current_checkpoint_sha256": local_catalog["artifact_sha256"],
            "current_checkpoint_kind": "JCAT12_LOCAL_OPERATOR_CATALOG_PROMOTED",
            "jcat2_v2_checkpoint_sha256": links["jcat2_v2_checkpoint_sha256"],
            "c2_d5_checkpoint_sha256": links["c2_d5_checkpoint_sha256"],
            "c3_c4_checkpoint_sha256": links["c3_c4_checkpoint_sha256"],
            "c5_checkpoint_sha256": local_catalog["artifact_sha256"],
            "st_seed_checkpoint_sha256": links["st_seed_checkpoint_sha256"],
            "action_ast_checkpoint_sha256": links["action_ast_checkpoint_sha256"],
        }
    global_packets = load_checkpoint(base / "frozen_jcat_global_packets/JCAT7G_checkpoint.json")
    if global_packets is not None:
        assert global_packets["status"] == "PASS_GLOBAL_BACKGROUND_PACKETS_STOPPED_AT_JCAT7"
        assert global_packets["JCAT7_promoted"] and global_packets["full_packet_catalog_qualified"]
        assert global_packets["ordered_basis_promoted"] and not global_packets["joint_catalog_promoted"]
        assert global_packets["all_431_expansion_addresses_preserved"]
        assert global_packets["homogeneous_occurrences_tagged_until_JCAT11"]
        links = global_packets["preserved_authority_links"]
        return {
            "blocker": global_packets["current_blocker"],
            "current_checkpoint_sha256": global_packets["artifact_sha256"],
            "current_checkpoint_kind": "JCAT7_GLOBAL_BACKGROUND_PACKETS_PROMOTED",
            "jcat2_v2_checkpoint_sha256": links["jcat2_v2_checkpoint_sha256"],
            "c2_d5_checkpoint_sha256": links["c2_d5_checkpoint_sha256"],
            "c3_c4_checkpoint_sha256": links["c3_c4_checkpoint_sha256"],
            "c5_checkpoint_sha256": global_packets["artifact_sha256"],
            "st_seed_checkpoint_sha256": links["st_seed_checkpoint_sha256"],
            "action_ast_checkpoint_sha256": links["action_ast_checkpoint_sha256"],
        }
    realized = load_checkpoint(base / "frozen_jcat_realization_v3/JCAT_RealizationV3_custody_checkpoint.json")
    if realized is not None:
        assert realized["status"] == "PARTIAL_REALIZATION_QUALIFIED"
        assert realized["ordered_basis_promoted"] and not realized["joint_catalog_promoted"]
        assert realized["realization_quotient_qualified"] and not realized["full_packet_catalog_qualified"]
        assert realized["all_431_expansion_addresses_preserved"]
        assert realized["homogeneous_occurrences_tagged_until_JCAT11"]
        links = realized["preserved_authority_links"]
        return {
            "blocker": realized["current_blocker"],
            "current_checkpoint_sha256": realized["artifact_sha256"],
            "current_checkpoint_kind": "JCAT7_REALIZATION_V3_QUALIFIED_GLOBAL_PACKETS_PENDING",
            "jcat2_v2_checkpoint_sha256": links["jcat2_v2_checkpoint_sha256"],
            "c2_d5_checkpoint_sha256": links["c2_d5_checkpoint_sha256"],
            "c3_c4_checkpoint_sha256": links["c3_c4_checkpoint_sha256"],
            "c5_checkpoint_sha256": realized["artifact_sha256"],
            "st_seed_checkpoint_sha256": links["st_seed_checkpoint_sha256"],
            "action_ast_checkpoint_sha256": links["action_ast_checkpoint_sha256"],
        }
    packets = load_checkpoint(base / "frozen_jcat_background_packets_v2/JCAT_BackgroundPacketsV2_checkpoint.json")
    if packets is not None:
        assert packets["status"] == "BLOCKED_CONTRACT"
        assert packets["ordered_basis_promoted"] and not packets["joint_catalog_promoted"]
        assert packets["packet_semantics_frozen"] and packets["all_431_expansion_addresses_preserved"]
        assert packets["INT7R"] == "PASS_INDEPENDENT_A3_AST_CHANNEL_COMPARATOR"
        assert packets["INT8"] == "PASS_EXACT_MULTIPLICITY_BLOCK_CONJUGATION_V2"
        links = packets["preserved_authority_links"]
        return {
            "blocker": packets["current_blocker"],
            "current_checkpoint_sha256": packets["artifact_sha256"],
            "current_checkpoint_kind": "JCAT7_BACKGROUND_PACKETS_V2_KERNEL_BLOCKED",
            "jcat2_v2_checkpoint_sha256": links["jcat2_v2_checkpoint_sha256"],
            "c2_d5_checkpoint_sha256": links["c2_d5_checkpoint_sha256"],
            "c3_c4_checkpoint_sha256": links["c3_c4_checkpoint_sha256"],
            "c5_checkpoint_sha256": packets["artifact_sha256"],
            "st_seed_checkpoint_sha256": links["st_seed_checkpoint_sha256"],
            "action_ast_checkpoint_sha256": links["action_ast_checkpoint_sha256"],
        }
    joint_v2 = load_checkpoint(base / "frozen_jcat_lorentz_v2/JCAT_LorentzV2_checkpoint.json")
    if joint_v2 is not None:
        assert joint_v2["status"] == "BLOCKED_CONTRACT"
        assert joint_v2["ordered_basis_promoted"] and not joint_v2["joint_catalog_promoted"]
        assert joint_v2["Lorentz_policy_frozen"]
        assert joint_v2["INT7R"] == "PASS_INDEPENDENT_A3_AST_CHANNEL_COMPARATOR"
        assert joint_v2["INT8"] == "PASS_EXACT_MULTIPLICITY_BLOCK_CONJUGATION_V2"
        links = joint_v2["preserved_authority_links"]
        return {
            "blocker": joint_v2["current_blocker"],
            "current_checkpoint_sha256": joint_v2["artifact_sha256"],
            "current_checkpoint_kind": "JCAT_LORENTZ_V2_BACKGROUND_CONTRACT_BLOCKED",
            "jcat2_v2_checkpoint_sha256": links["jcat2_v2_checkpoint_sha256"],
            "c2_d5_checkpoint_sha256": links["c2_d5_checkpoint_sha256"],
            "c3_c4_checkpoint_sha256": links["c3_c4_checkpoint_sha256"],
            "c5_checkpoint_sha256": joint_v2["artifact_sha256"],
            "st_seed_checkpoint_sha256": links["st_seed_checkpoint_sha256"],
            "action_ast_checkpoint_sha256": links["action_ast_checkpoint_sha256"],
        }
    joint_contract = load_checkpoint(base / "frozen_jcat3_contract_preflight/JCAT3_checkpoint.json")
    if joint_contract is not None:
        assert joint_contract["status"] == "BLOCKED_CONTRACT"
        assert joint_contract["ordered_basis_promoted"] and not joint_contract["joint_catalog_promoted"]
        assert joint_contract["INT7R"] == "PASS_INDEPENDENT_A3_AST_CHANNEL_COMPARATOR"
        assert joint_contract["INT8"] == "PASS_EXACT_MULTIPLICITY_BLOCK_CONJUGATION_V2"
        links = joint_contract["preserved_authority_links"]
        return {
            "blocker": joint_contract["current_blocker"],
            "current_checkpoint_sha256": joint_contract["artifact_sha256"],
            "current_checkpoint_kind": "JCAT3_CONTRACT_PREFLIGHT_BLOCKED",
            "jcat2_v2_checkpoint_sha256": links["jcat2_v2_checkpoint_sha256"],
            "c2_d5_checkpoint_sha256": links["c2_d5_checkpoint_sha256"],
            "c3_c4_checkpoint_sha256": links["c3_c4_checkpoint_sha256"],
            "c5_checkpoint_sha256": joint_contract["artifact_sha256"],
            "st_seed_checkpoint_sha256": links["st_seed_checkpoint_sha256"],
            "action_ast_checkpoint_sha256": links["action_ast_checkpoint_sha256"],
        }
    rh_internal = load_checkpoint(base / "frozen_rh_composite_adjudication/INT9_INT15_checkpoint.json")
    internal = (rh_internal if rh_internal is not None and rh_internal["status"] in (
        "BLOCKED", "PASS_ORDERED_INTERNAL_BASIS_STOPPED") else
        load_checkpoint(base / "frozen_int9_int15/INT9_INT15_checkpoint.json"))
    if internal is not None and internal["status"] in (
            "BLOCKED", "PASS_ORDERED_INTERNAL_BASIS_STOPPED"):
        assert internal["INT7R"] == "PASS_INDEPENDENT_A3_AST_CHANNEL_COMPARATOR"
        assert internal["INT8"] == "PASS_EXACT_MULTIPLICITY_BLOCK_CONJUGATION_V2"
        links = internal["preserved_authority_links"]
        return {
            "blocker": internal["current_blocker"],
            "current_checkpoint_sha256": internal["artifact_sha256"],
            "current_checkpoint_kind": "INT9_INT15_ORDERED_INTERNAL_BASIS_ADJUDICATED",
            "jcat2_v2_checkpoint_sha256": links["jcat2_v2_checkpoint_sha256"],
            "c2_d5_checkpoint_sha256": links["c2_d5_checkpoint_sha256"],
            "c3_c4_checkpoint_sha256": links["c3_c4_checkpoint_sha256"],
            "c5_checkpoint_sha256": internal["artifact_sha256"],
            "st_seed_checkpoint_sha256": links["st_seed_checkpoint_sha256"],
            "action_ast_checkpoint_sha256": links["action_ast_checkpoint_sha256"],
        }
    int8v2 = load_checkpoint(base / "frozen_int8_block_conjugation_v2/INT8V2_checkpoint.json")
    if int8v2 is not None:
        assert int8v2["INT7R"] == "PASS_INDEPENDENT_A3_AST_CHANNEL_COMPARATOR"
        links = int8v2["preserved_authority_links"]
        return {
            "blocker": int8v2["current_blocker"],
            "current_checkpoint_sha256": int8v2["artifact_sha256"],
            "current_checkpoint_kind": "INT8_MULTIPLICITY_BLOCK_CONJUGATION_V2_ADJUDICATED",
            "jcat2_v2_checkpoint_sha256": links["jcat2_v2_checkpoint_sha256"],
            "c2_d5_checkpoint_sha256": links["c2_d5_checkpoint_sha256"],
            "c3_c4_checkpoint_sha256": links["c3_c4_checkpoint_sha256"],
            "c5_checkpoint_sha256": int8v2["artifact_sha256"],
            "st_seed_checkpoint_sha256": links["st_seed_checkpoint_sha256"],
            "action_ast_checkpoint_sha256": links["action_ast_checkpoint_sha256"],
        }
    int8 = load_checkpoint(base / "frozen_int8_conjugation_checkpoint/INT8_conjugation_checkpoint.json")
    if int8 is not None:
        assert int8["INT7R"] == "PASS_INDEPENDENT_A3_AST_CHANNEL_COMPARATOR"
        links = int8["preserved_authority_links"]
        return {
            "blocker": int8["current_blocker"],
            "current_checkpoint_sha256": int8["artifact_sha256"],
            "current_checkpoint_kind": "INT8_CONJUGATION_SINGLE_ADDRESS_CONTRACT_BLOCKED",
            "jcat2_v2_checkpoint_sha256": links["jcat2_v2_checkpoint_sha256"],
            "c2_d5_checkpoint_sha256": links["c2_d5_checkpoint_sha256"],
            "c3_c4_checkpoint_sha256": links["c3_c4_checkpoint_sha256"],
            "c5_checkpoint_sha256": int8["artifact_sha256"],
            "st_seed_checkpoint_sha256": links["st_seed_checkpoint_sha256"],
            "action_ast_checkpoint_sha256": links["action_ast_checkpoint_sha256"],
        }
    bridge_v3 = load_checkpoint(base / "frozen_scalar_bridge_v3/BRV3_checkpoint.json")
    if bridge_v3 is not None:
        links = bridge_v3["preserved_authority_links"]
        return {
            "blocker": bridge_v3["current_blocker"],
            "current_checkpoint_sha256": bridge_v3["artifact_sha256"],
            "current_checkpoint_kind": "SCALAR_BRIDGE_V3_INT7R_ADJUDICATION",
            "jcat2_v2_checkpoint_sha256": links["jcat2_v2_checkpoint_sha256"],
            "c2_d5_checkpoint_sha256": links["c2_d5_checkpoint_sha256"],
            "c3_c4_checkpoint_sha256": links["c3_c4_checkpoint_sha256"],
            "c5_checkpoint_sha256": bridge_v3["artifact_sha256"],
            "st_seed_checkpoint_sha256": links["st_seed_checkpoint_sha256"],
            "action_ast_checkpoint_sha256": links["action_ast_checkpoint_sha256"],
        }
    scalar_adapter = load_checkpoint(base / "frozen_scalar_adapter_v2/SA_checkpoint.json")
    if scalar_adapter is not None:
        links = scalar_adapter["preserved_authority_links"]
        return {
            "blocker": scalar_adapter["current_blocker"],
            "current_checkpoint_sha256": scalar_adapter["artifact_sha256"],
            "current_checkpoint_kind": "SCALAR_ADAPTER_V2_INT7R_BLOCKED",
            "jcat2_v2_checkpoint_sha256": links["jcat2_v2_checkpoint_sha256"],
            "c2_d5_checkpoint_sha256": links["c2_d5_checkpoint_sha256"],
            "c3_c4_checkpoint_sha256": links["c3_c4_checkpoint_sha256"],
            "c5_checkpoint_sha256": scalar_adapter["artifact_sha256"],
            "st_seed_checkpoint_sha256": links["st_seed_checkpoint_sha256"],
            "action_ast_checkpoint_sha256": links["action_ast_checkpoint_sha256"],
        }
    dual_bridge = load_checkpoint(base / "frozen_scalar_dual_bridge_v2/DUAL_checkpoint.json")
    if dual_bridge is not None:
        links = dual_bridge["preserved_authority_links"]
        return {
            "blocker": dual_bridge["current_blocker"],
            "current_checkpoint_sha256": dual_bridge["artifact_sha256"],
            "current_checkpoint_kind": "SCALAR_DUAL_BRIDGE_V2_ROLE_ADAPTER_BLOCKED",
            "jcat2_v2_checkpoint_sha256": links["jcat2_v2_checkpoint_sha256"],
            "c2_d5_checkpoint_sha256": links["c2_d5_checkpoint_sha256"],
            "c3_c4_checkpoint_sha256": links["c3_c4_checkpoint_sha256"],
            "c5_checkpoint_sha256": dual_bridge["artifact_sha256"],
            "st_seed_checkpoint_sha256": links["st_seed_checkpoint_sha256"],
            "action_ast_checkpoint_sha256": links["action_ast_checkpoint_sha256"],
        }
    bridge = load_checkpoint(base / "frozen_scalar_ast_channel_bridge_v1/BR_checkpoint.json")
    if bridge is not None:
        # Read only the new checkpoint and preserved summary hashes.  There is
        # no reason to open historical development payloads for this blocker.
        links = bridge["preserved_authority_links"]
        return {
            "blocker": bridge["current_blocker"],
            "current_checkpoint_sha256": bridge["artifact_sha256"],
            "current_checkpoint_kind": "SCALAR_AST_CHANNEL_BRIDGE_COVECTOR_BLOCKED",
            "jcat2_v2_checkpoint_sha256": links["jcat2_v2_checkpoint_sha256"],
            "c2_d5_checkpoint_sha256": links["c2_d5_checkpoint_sha256"],
            "c3_c4_checkpoint_sha256": links["c3_c4_checkpoint_sha256"],
            "c5_checkpoint_sha256": bridge["artifact_sha256"],
            "st_seed_checkpoint_sha256": links["st_seed_checkpoint_sha256"],
            "action_ast_checkpoint_sha256": links["action_ast_checkpoint_sha256"],
        }
    c2_d5 = load_checkpoint(base / "frozen_d5/C2_D5_checkpoint.json")
    c3_c4 = load_checkpoint(base / "frozen_c4/C3_C4_checkpoint.json")
    c5 = load_checkpoint(base / "frozen_c5/C5_checkpoint.json")
    st_seed = load_checkpoint(base / "frozen_st_seed/ST_seed_checkpoint.json")
    action_ast = load_checkpoint(base / "frozen_action_ast/ACTION_AST_checkpoint.json")
    action_ast_a4 = load_checkpoint(
        base / "frozen_action_ast_a4_preflight/A4_A5_PREFLIGHT_checkpoint.json")
    action_ast_a5 = load_checkpoint(
        base / "frozen_action_ast_a4_a5/A4_A5_checkpoint.json")
    action_ast_l6 = load_checkpoint(
        base / "frozen_ast_differential_l1_l6/L1_L6_checkpoint.json")
    action_ast_a5_l10 = load_checkpoint(
        base / "frozen_action_ast_a5_l7_l10/A5_L7_L10_checkpoint.json")
    action_ast_a5_v2_h10 = load_checkpoint(
        base / "frozen_action_ast_a5_v2_h10/H10_checkpoint.json")
    action_ast_a5_vh_j10 = load_checkpoint(
        base / "frozen_action_ast_a5_vh_j8_j10/J8_J10_checkpoint.json")
    current_rule_r12 = load_checkpoint(
        base / "frozen_current_rule_r8_r12/R12_checkpoint.json")
    action_ast_a10 = load_checkpoint(
        base / "frozen_action_ast_p1_a10/A10_checkpoint.json")
    source_seed_s3_s5 = load_checkpoint(
        base / "frozen_source_seed_s3_s5/S3_S8_checkpoint.json")
    variational_s8 = load_checkpoint(
        base / "frozen_variational_s5_s8/S8_checkpoint.json")
    c5_c6 = load_checkpoint(
        base / "frozen_c5_c6/C5_C6_checkpoint.json")
    catalog_cat0_cat4 = load_checkpoint(
        base / "frozen_catalog_cat0_cat4/CAT_checkpoint.json")
    joint_catalog_jcat2 = load_checkpoint(
        base / "frozen_joint_catalog_jcat0_jcat2/JCAT_checkpoint.json")
    intertwiner_int2 = load_checkpoint(
        base / "frozen_intertwiner_int0_int2/INT_checkpoint.json")
    carrier_registry = load_checkpoint(
        base / "frozen_irrep_carrier_registry/REG_checkpoint.json")
    intertwiner_channels = load_checkpoint(
        base / "frozen_intertwiner_channel_basis/INT_checkpoint.json")
    jcat2_v2 = load_checkpoint(
        base / "frozen_jcat2_v2_projected/JCAT2V2_checkpoint.json")
    intertwiner_int7 = load_checkpoint(
        base / "frozen_intertwiner_basis_int4r_int15/INT4R_INT15_checkpoint.json")
    if intertwiner_int7 is not None:
        return {
            "blocker": intertwiner_int7["current_blocker"],
            "current_checkpoint_sha256": intertwiner_int7["artifact_sha256"],
            "current_checkpoint_kind": "INTERTWINER_INT4R_INT7_PASS_INT7R_BLOCKED",
            "jcat2_v2_checkpoint_sha256": (
                jcat2_v2["artifact_sha256"] if jcat2_v2 is not None else None),
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": intertwiner_int7["artifact_sha256"],
            "st_seed_checkpoint_sha256": (
                variational_s8["artifact_sha256"] if variational_s8 is not None else None),
            "action_ast_checkpoint_sha256": (
                action_ast_a10["artifact_sha256"] if action_ast_a10 is not None else None),
        }
    if jcat2_v2 is not None:
        return {
            "blocker": jcat2_v2["current_blocker"],
            "current_checkpoint_sha256": jcat2_v2["artifact_sha256"],
            "current_checkpoint_kind": "JCAT2_V2_PROJECTED_PROMOTED_INT4_PASS",
            "jcat2_v2_checkpoint_sha256": jcat2_v2["artifact_sha256"],
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": jcat2_v2["artifact_sha256"],
            "st_seed_checkpoint_sha256": (
                variational_s8["artifact_sha256"] if variational_s8 is not None else None),
            "action_ast_checkpoint_sha256": (
                action_ast_a10["artifact_sha256"] if action_ast_a10 is not None else None),
        }
    if intertwiner_channels is not None:
        return {
            "blocker": intertwiner_channels["current_blocker"],
            "current_checkpoint_sha256": intertwiner_channels["artifact_sha256"],
            "current_checkpoint_kind": "INTERTWINER_INT3_PASS_INT4_MULTIPLICITY_BLOCKED",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": intertwiner_channels["artifact_sha256"],
            "st_seed_checkpoint_sha256": (
                variational_s8["artifact_sha256"] if variational_s8 is not None else None),
            "action_ast_checkpoint_sha256": (
                action_ast_a10["artifact_sha256"] if action_ast_a10 is not None else None),
        }
    if carrier_registry is not None:
        return {
            "blocker": carrier_registry["current_blocker"],
            "current_checkpoint_sha256": carrier_registry["artifact_sha256"],
            "current_checkpoint_kind": "IRREP_CARRIER_REGISTRY_PROMOTED",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": (
                intertwiner_int2["artifact_sha256"]
                if intertwiner_int2 is not None else None),
            "st_seed_checkpoint_sha256": (
                variational_s8["artifact_sha256"] if variational_s8 is not None else None),
            "action_ast_checkpoint_sha256": (
                action_ast_a10["artifact_sha256"] if action_ast_a10 is not None else None),
        }
    if intertwiner_int2 is not None:
        return {
            "blocker": intertwiner_int2["current_blocker"],
            "current_checkpoint_sha256": intertwiner_int2["artifact_sha256"],
            "current_checkpoint_kind": "INTERTWINER_INT0_INT2_BLOCKED",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": intertwiner_int2["artifact_sha256"],
            "st_seed_checkpoint_sha256": (
                variational_s8["artifact_sha256"] if variational_s8 is not None else None),
            "action_ast_checkpoint_sha256": (
                action_ast_a10["artifact_sha256"] if action_ast_a10 is not None else None),
        }
    if joint_catalog_jcat2 is not None:
        return {
            "blocker": joint_catalog_jcat2["current_blocker"],
            "current_checkpoint_sha256": joint_catalog_jcat2["artifact_sha256"],
            "current_checkpoint_kind": "JOINT_CATALOG_JCAT0_JCAT2_BLOCKED",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": joint_catalog_jcat2["artifact_sha256"],
            "st_seed_checkpoint_sha256": (
                variational_s8["artifact_sha256"] if variational_s8 is not None else None),
            "action_ast_checkpoint_sha256": (
                action_ast_a10["artifact_sha256"] if action_ast_a10 is not None else None),
        }
    if catalog_cat0_cat4 is not None:
        return {
            "blocker": catalog_cat0_cat4["current_blocker"],
            "current_checkpoint_sha256": catalog_cat0_cat4["artifact_sha256"],
            "current_checkpoint_kind": "CATALOG_CAT0_CAT4_CAT5_BLOCKED",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": catalog_cat0_cat4["artifact_sha256"],
            "st_seed_checkpoint_sha256": (
                variational_s8["artifact_sha256"] if variational_s8 is not None else None),
            "action_ast_checkpoint_sha256": (
                action_ast_a10["artifact_sha256"] if action_ast_a10 is not None else None),
        }
    if c5_c6 is not None:
        return {
            "blocker": c5_c6["current_blocker"],
            "current_checkpoint_sha256": c5_c6["artifact_sha256"],
            "current_checkpoint_kind": "C5_C6_POLE_BLIND_PREFLIGHT_BLOCKED",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": c5_c6["artifact_sha256"],
            "st_seed_checkpoint_sha256": (
                variational_s8["artifact_sha256"] if variational_s8 is not None else None),
            "action_ast_checkpoint_sha256": (
                action_ast_a10["artifact_sha256"] if action_ast_a10 is not None else None),
        }
    if variational_s8 is not None:
        return {
            "blocker": variational_s8["current_blocker"],
            "current_checkpoint_sha256": variational_s8["artifact_sha256"],
            "current_checkpoint_kind": "SOURCE_ST_SEED_S8_PROMOTED",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": (
                c5["artifact_sha256"] if c5 is not None else None),
            "st_seed_checkpoint_sha256": variational_s8["artifact_sha256"],
            "action_ast_checkpoint_sha256": (
                action_ast_a10["artifact_sha256"] if action_ast_a10 is not None else None),
        }
    if source_seed_s3_s5 is not None:
        return {
            "blocker": source_seed_s3_s5["current_blocker"],
            "current_checkpoint_sha256": source_seed_s3_s5["artifact_sha256"],
            "current_checkpoint_kind": "SOURCE_SEED_S3_S5_BLOCKED",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": (
                c5["artifact_sha256"] if c5 is not None else None),
            "st_seed_checkpoint_sha256": source_seed_s3_s5["artifact_sha256"],
            "action_ast_checkpoint_sha256": (
                action_ast_a10["artifact_sha256"] if action_ast_a10 is not None else None),
        }
    if action_ast_a10 is not None:
        return {
            "blocker": action_ast_a10["next_implementation_blocker"],
            "current_checkpoint_sha256": action_ast_a10["artifact_sha256"],
            "current_checkpoint_kind": "ACTION_AST_P1_A10_PROMOTED",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": (
                c5["artifact_sha256"] if c5 is not None else None),
            "st_seed_checkpoint_sha256": (
                st_seed["artifact_sha256"] if st_seed is not None else None),
            "action_ast_checkpoint_sha256": action_ast_a10["artifact_sha256"],
        }
    if current_rule_r12 is not None:
        return {
            "blocker": current_rule_r12["current_blocker"],
            "current_checkpoint_sha256": current_rule_r12["artifact_sha256"],
            "current_checkpoint_kind": "CURRENT_RULE_R1_R12",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": (
                c5["artifact_sha256"] if c5 is not None else None),
            "st_seed_checkpoint_sha256": (
                st_seed["artifact_sha256"] if st_seed is not None else None),
            "action_ast_checkpoint_sha256": current_rule_r12["artifact_sha256"],
        }
    if action_ast_a5_vh_j10 is not None:
        return {
            "blocker": action_ast_a5_vh_j10["current_blocker"],
            "current_checkpoint_sha256": action_ast_a5_vh_j10["artifact_sha256"],
            "current_checkpoint_kind": "ACTION_AST_A5_VH_J1_J10",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": (
                c5["artifact_sha256"] if c5 is not None else None),
            "st_seed_checkpoint_sha256": (
                st_seed["artifact_sha256"] if st_seed is not None else None),
            "action_ast_checkpoint_sha256": action_ast_a5_vh_j10["artifact_sha256"],
        }
    if action_ast_a5_v2_h10 is not None:
        return {
            "blocker": action_ast_a5_v2_h10["current_blocker"],
            "current_checkpoint_sha256": action_ast_a5_v2_h10["artifact_sha256"],
            "current_checkpoint_kind": "ACTION_AST_A5_V2_H10",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": (
                c5["artifact_sha256"] if c5 is not None else None),
            "st_seed_checkpoint_sha256": (
                st_seed["artifact_sha256"] if st_seed is not None else None),
            "action_ast_checkpoint_sha256": action_ast_a5_v2_h10["artifact_sha256"],
        }
    if action_ast_a5_l10 is not None:
        return {
            "blocker": action_ast_a5_l10["current_blocker"],
            "current_checkpoint_sha256": action_ast_a5_l10["artifact_sha256"],
            "current_checkpoint_kind": "ACTION_AST_A5_L10",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": (
                c5["artifact_sha256"] if c5 is not None else None),
            "st_seed_checkpoint_sha256": (
                st_seed["artifact_sha256"] if st_seed is not None else None),
            "action_ast_checkpoint_sha256": action_ast_a5_l10["artifact_sha256"],
        }
    if action_ast_l6 is not None:
        return {
            "blocker": action_ast_l6["current_blocker"],
            "current_checkpoint_sha256": action_ast_l6["artifact_sha256"],
            "current_checkpoint_kind": "ACTION_AST_DIFFERENTIAL_L6",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": (
                c5["artifact_sha256"] if c5 is not None else None),
            "st_seed_checkpoint_sha256": (
                st_seed["artifact_sha256"] if st_seed is not None else None),
            "action_ast_checkpoint_sha256": action_ast_l6["artifact_sha256"],
        }
    if action_ast_a5 is not None:
        return {
            "blocker": action_ast_a5["current_blocker"],
            "current_checkpoint_sha256": action_ast_a5["artifact_sha256"],
            "current_checkpoint_kind": "ACTION_AST_A4_A5",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": (
                c5["artifact_sha256"] if c5 is not None else None),
            "st_seed_checkpoint_sha256": (
                st_seed["artifact_sha256"] if st_seed is not None else None),
            "action_ast_checkpoint_sha256": action_ast_a5["artifact_sha256"],
        }
    if action_ast_a4 is not None:
        return {
            "blocker": action_ast_a4["current_blocker"],
            "current_checkpoint_sha256": action_ast_a4["artifact_sha256"],
            "current_checkpoint_kind": "ACTION_AST_A4_PREFLIGHT",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": (
                c5["artifact_sha256"] if c5 is not None else None),
            "st_seed_checkpoint_sha256": (
                st_seed["artifact_sha256"] if st_seed is not None else None),
            "action_ast_checkpoint_sha256": action_ast_a4["artifact_sha256"],
        }
    if action_ast is not None:
        return {
            "blocker": action_ast["current_blocker"],
            "current_checkpoint_sha256": action_ast["artifact_sha256"],
            "current_checkpoint_kind": "ACTION_AST",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": (
                c5["artifact_sha256"] if c5 is not None else None),
            "st_seed_checkpoint_sha256": (
                st_seed["artifact_sha256"] if st_seed is not None else None),
            "action_ast_checkpoint_sha256": action_ast["artifact_sha256"],
        }
    if st_seed is not None:
        return {
            "blocker": st_seed["current_blocker"],
            "current_checkpoint_sha256": st_seed["artifact_sha256"],
            "current_checkpoint_kind": "ST_SEED",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": (
                c5["artifact_sha256"] if c5 is not None else None),
            "st_seed_checkpoint_sha256": st_seed["artifact_sha256"],
            "action_ast_checkpoint_sha256": None,
        }
    if c5 is not None:
        return {
            "blocker": c5["current_blocker"],
            "current_checkpoint_sha256": c5["artifact_sha256"],
            "current_checkpoint_kind": "C5",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": (
                c3_c4["artifact_sha256"] if c3_c4 is not None else None),
            "c5_checkpoint_sha256": c5["artifact_sha256"],
            "st_seed_checkpoint_sha256": None,
            "action_ast_checkpoint_sha256": None,
        }
    if c3_c4 is not None:
        return {
            "blocker": c3_c4["current_blocker"],
            "current_checkpoint_sha256": c3_c4["artifact_sha256"],
            "current_checkpoint_kind": "C3_C4",
            "c2_d5_checkpoint_sha256": (
                c2_d5["artifact_sha256"] if c2_d5 is not None else None),
            "c3_c4_checkpoint_sha256": c3_c4["artifact_sha256"],
            "c5_checkpoint_sha256": None,
            "st_seed_checkpoint_sha256": None,
            "action_ast_checkpoint_sha256": None,
        }
    if c2_d5 is not None:
        return {
            "blocker": c2_d5["current_blocker"],
            "current_checkpoint_sha256": c2_d5["artifact_sha256"],
            "current_checkpoint_kind": "C2_D5",
            "c2_d5_checkpoint_sha256": c2_d5["artifact_sha256"],
            "c3_c4_checkpoint_sha256": None,
            "c5_checkpoint_sha256": None,
            "st_seed_checkpoint_sha256": None,
            "action_ast_checkpoint_sha256": None,
        }
    return {
        "blocker": "HEAVY_BRST_THREE_POINT_OPERATOR_CLOSURE_INCOMPLETE",
        "current_checkpoint_sha256": None,
        "current_checkpoint_kind": None,
        "c2_d5_checkpoint_sha256": None,
        "c3_c4_checkpoint_sha256": None,
        "c5_checkpoint_sha256": None,
        "st_seed_checkpoint_sha256": None,
        "action_ast_checkpoint_sha256": None,
    }


def derive() -> dict[str, Any]:
    ledger = load_ledger()
    tests = ledger["tests"]
    counters = ledger["counters"]
    executed = [row for row in tests if row["status"] != "NOT_RUN"]
    first_non_pass = next(row for row in tests if row["status"] != "PASS")
    development = load_current_development_blocker()
    assert len(executed) == counters["executed"]
    assert first_non_pass["test_id"] == "UVP_M08"
    assert first_non_pass["status"] == "BLOCKED"
    return {
        "progress": f"{counters['executed']}/{counters['total_required']}",
        "progress_code": (
            f"{counters['executed']}_OF_{counters['total_required']}_ENGINE_"
            f"{counters['engine_executed']}_OF_{counters['engine_required']}"
        ),
        "tests_executed": counters["executed"],
        "passed": counters["passed"],
        "blocked": counters["blocked"],
        "failed": counters["failed"],
        "first_non_pass": first_non_pass["test_id"],
        "first_non_pass_status": first_non_pass["status"],
        "formal_attempt": first_non_pass["attempt"],
        "current_implementation_blocker": development["blocker"],
        "current_checkpoint_kind": development["current_checkpoint_kind"],
        "current_checkpoint_artifact_sha256": development["current_checkpoint_sha256"],
        "c2_d5_checkpoint_artifact_sha256": development["c2_d5_checkpoint_sha256"],
        "c3_c4_checkpoint_artifact_sha256": development["c3_c4_checkpoint_sha256"],
        "c5_checkpoint_artifact_sha256": development["c5_checkpoint_sha256"],
        "jcat2_v2_checkpoint_artifact_sha256": development.get(
            "jcat2_v2_checkpoint_sha256"),
        "st_seed_checkpoint_artifact_sha256": development[
            "st_seed_checkpoint_sha256"],
        "action_ast_checkpoint_artifact_sha256": development[
            "action_ast_checkpoint_sha256"],
        "ledger_sha256": ledger["result_sha256"],
        "layer6_authorized": ledger["promotion"]["layer6_authorized"],
        "counterterm_compiler": ledger["promotion"]["counterterm_compiler"],
    }
