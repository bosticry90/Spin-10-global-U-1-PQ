# Mixed source loops and a possible ghost normalization

Prospective calculation, not completed evidence. Physical orthonormal heavy
ghost/antighost/auxiliary coordinates use the qualified33-dimensional carrier.
The literal cubic is xi Lambda_i ub_j A_i,jk u_k, A_i=P_M ad(T_i)|_M.
Gauge/scalar sources keep the canonical evaluation pairing and source-left
ordering. Fields x are the approved independent total real scalars.

Relevant source terms are +JB^mu f(B_mu,C)*g and -g Jx rho(C)x.
The scalar cubic is g (partial_mu x)^T rho(B^mu)x. Use the full gauge/auxiliary
Green block with G_BL=i p_mu/p^2, G_LB=-i p_mu/p^2, G_LL=0, and odd block
G_u,ub=1/p^2, G_ub,u=-1/p^2. Retain the four Lorentz metric weights.

The g*xi JB-C bubble joins the source gauge/ghost vertex to the actual xi
vertex through a ghost and mixed gauge/auxiliary line. The g^2*xi Jx-C-x
triangle adds a scalar/gauge vertex and scalar line. A source coupling with
only one integrated field is a bridge, not a 1PI loop. For these coupling
and parameter degrees, other cubic/quartic vertices either cannot match the
internal roles, have additional g/xi, or positive-dimensional vacuum/mass
insertions that reduce the local UV degree. Check this against the literal
inventory; power counting is not permission to drop a complete action.

For a constant external scalar, the triangle numerator contracts the four
mixed-vector factors to p^2. The remaining Euclidean local-pole integral is

    I3 = integral d^4k/(2pi)^4
               exp(-6k^2/Lambda^2)/[k^2(k^2+Mref^2)].

Mref^2>0 makes the Taylor point IR integrable. Its exact heat value is
exp(c)E1(c)/(16pi^2), c=6 Mref^2/Lambda^2. The dimensional residue is
1/(16pi^2); finite mass/reference and scheme terms are separate. The bubble
retains nonzero external momentum, with its exact vector routing/heat profile.

Let kappa_phys=-Tr_M(A_i A_j), as in the qualified ghost loop, and let U map
the primal heavy ghost to its orthonormal physical coordinates. The correct
ghost endomorphism is N=U^-1 kappa_phys U. Since the old auxiliary bilinear
is kappa_aux=U^-1 kappa_phys U^-T, N=kappa_aux G_M, not kappa_aux. Its full45
extension is zero on H and is real/self-adjoint in the physical carrier.
The expected group contraction follows independently from antisymmetry and
[rho_i,rho_j]=f_ij^a rho_a. Do not force its sign or factor to match a target.

If the two loop residues agree, compare their local representatives with
the complete Q image of a generator proportional to g xi JC^T N C. The
Hamiltonian image and a simultaneous ghost/source coordinate variation
must agree modulo an explicit current. The latter changes C by N C and
JC by -N^T JC; it leaves physical parameters and all other pairs fixed.
Its functional action change is -QK. This is a selected canonical candidate,
not a proof that the entire one-loop divergence has this primitive.

For Z_C=1+hbar a N, its field Berezinian has log=-hbar a Tr_spacetime N
at first order. Evaluation-dual external sources do not cancel an integration
measure. The regulated trace can depend on background H. Keep it; its
effective-action contribution starts at hbar^2 for this hbar-order change.
All sources, Green kernels, jets and operators require their typed transport.
No universal contact, anomaly, IR or quantum-equivalence claim follows.
