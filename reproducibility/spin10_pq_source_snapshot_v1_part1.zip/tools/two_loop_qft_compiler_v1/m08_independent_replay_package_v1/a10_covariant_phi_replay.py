"""Independent physical-tensor/word first control; no primary output import."""
import json
import sympy as s
from phase_c_complete_scalar_action_replay import physical_generator_and_embedding
from interacting_actual_h_preflight_replay import GaugeWords


def build(stage=lambda n, fn: fn()):
    rho, names = physical_generator_and_embedding(); w = GaugeWords(0); g = s.Symbol('g10')
    conn = ['B4_'+str(mu) for mu in range(4)]
    w.p = {**{n: 0 for n in names+conn}, 'C4': 1}; w.pairs = []
    x = {n: w.var(n) for n in w.p}
    transformed = [w.add(*(w.scale(x[names[k]], rho[i, k]) for k in range(54) if rho[i, k])) for i in range(54)]
    forward = {n: w.scale(w.mul(x['C4'], transformed[i]), -g) for i, n in enumerate(names)}
    forward.update({conn[mu]: w.D(x['C4'], mu) for mu in range(4)})
    ordinary = w.add(*(w.scale(w.mul(w.D(x[n], mu), w.D(x[n], mu)), s.Rational((1, -1, -1, -1)[mu], 2)) for n in names for mu in range(4)))
    Ds = [[w.add(w.D(x[n], mu), w.scale(w.mul(x[conn[mu]], transformed[i]), g)) for i, n in enumerate(names)] for mu in range(4)]
    kinetic = w.add(*(w.scale(w.mul(z, z), s.Rational((1, -1, -1, -1)[mu], 2)) for mu, vec in enumerate(Ds) for z in vec))
    old = stage('physical_tensor_literal_kinetic_Ward', lambda: w.act(ordinary, forward, parity=1))
    new = stage('physical_tensor_complete_covariant_Ward', lambda: w.act(kinetic, forward, parity=1))
    assert old and not new
    target = sorted(['C4__0', 'x_Phi_offdiag_0_4', 'x_Phi_offdiag_0_1__0'])
    coefficient = next(r['coefficient'] for r in w.record(old) if r['word'] == target)
    rows = w.record(kinetic)
    return {'schema': 'A10_INACTIVE_COVARIANT_PHI_CONTROL_V1', 'status': 'PASS_FULL_PHI_KINETIC_CONTROL_ONLY',
            'coordinates': 54, 'generator': 4, 'directions': 4, 'historical_selected_coefficient': coefficient,
            'historical_variation': w.record(old), 'historical_Euler': w.record(w.EL(old, 'C4')), 'candidate_density': rows, 'candidate_variation': w.record(new),
            'candidate_Euler': w.record(w.EL(new, 'C4')),
            'coupling_degree_monomials': {str(power): sum(s.expand(s.sympify(r['coefficient'])).coeff(g, power) != 0 for r in rows) for power in range(3)},
            'connection_projected_before_variation': False, 'candidate_adopted': False, 'physical_parameters_changed': False}


if __name__ == '__main__':
    assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED')
    print('RESULT '+json.dumps(build(), sort_keys=True, separators=(',', ':')))
