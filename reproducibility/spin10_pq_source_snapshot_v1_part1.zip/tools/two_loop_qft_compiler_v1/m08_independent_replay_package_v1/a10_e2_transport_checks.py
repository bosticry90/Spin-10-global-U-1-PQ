"""Graded parity, derivative, partial-transport and independent physical controls."""
from copy import deepcopy
from a10_e2_transport_common import *

def build(stage=lambda n,f:f()):
    from audit_a10_e2_transport import adjudicate
    p,r=[read(OUT/(n+'.json')) for n in ('primary','replay')]
    matching=adjudicate(p,r);w,e1,data,cols,psi,A=inputs('primary')
    # A minimal exact auxiliary block exposes loss of the parity factor.
    P=w.scale(w.mul(w.var('ub12'),w.var('L12')),-xi*s.Rational(1,10))
    wrongUb=w.add(w.var('Jub12'),w.scale(w.EL(P,'ub12'),-1))
    wrongL=w.add(w.var('JL12'),w.scale(w.EL(P,'L12'),-1))
    parity_residual=canonical(w.bracket(wrongUb,wrongL));assert parity_residual=={():xi/5}
    # With derivative terms, a bare coordinate bracket loses the delta-kernel.
    register(w,'test_t',(0,0,0));register(w,'test_s',(0,0,1))
    F=w.mul(w.var('test_t'),w.var('JB12_0'))
    G=w.mul(w.var('test_s'),w.add(w.var('Jub12'),w.D(w.var('B12_0'),0)))
    derivative_residual=canonical(w.bracket(F,G));euler=canonical(w.EL(derivative_residual,'test_s'))
    assert euler and not w.bracket(w.var('JB12_0'),w.add(w.var('Jub12'),w.D(w.var('B12_0'),0)))
    # Omitting the derivative of the inverse source map is partial transport.
    wrong=dict(cols)
    for z,J in w.pairs:wrong[J]=w.add(cols[J],shift_correction(cols[J],A,w))
    light_obstruction=canonical(w.act(wrong['Jb0'],wrong,parity=1));assert light_obstruction
    # Conjugation is the E1 real-structure automorphism, not a reversing adjoint.
    Q=mat(data['architecture']['C3_to_plane_field']);C=(Q.inv()*Q.conjugate()).applyfunc(clean)
    conj={}
    for mu in range(4):
        for a in IDS:conj[f'B{a}_{mu}']=w.add(*(w.scale(w.var(f'B{b}_{mu}'),C[a,b]) for b in IDS if C[a,b]))
        for h in H:conj[f'A{h}_{mu}']=w.add(*(w.scale(w.var(f'A{k}_{mu}'),C[h,k]) for k in H if C[h,k]))
    def block(prefix,ids,K):
        ids=list(ids)
        for i,a in enumerate(ids):conj[prefix+str(a)]=w.add(*(w.scale(w.var(prefix+str(ids[j])),c) for (k,j),c in K.todok().items() if k==i))
    block('C',IDS,C)
    for pre in ('ub','L'):block(pre,M,mat(e1['charts']['blocks']['heavy_dual']['conjugation']))
    for pre in ('bar','b'):block(pre,H,mat(e1['charts']['blocks']['light_primal']['conjugation']))
    Jconj=(Q.T*Q.inv().T.conjugate()).applyfunc(clean)
    source_groups=[]
    for mu in range(4):source_groups.append(([f'JB{a}_{mu}' for a in IDS],Jconj))
    source_groups.append(([f'JC{a}' for a in IDS],Jconj))
    for pre in ('Jub','JL'):source_groups.append(([pre+str(a) for a in M],mat(e1['charts']['blocks']['heavy_dual']['source_conjugation'])))
    for pre in ('Jbar','Jb'):source_groups.append(([pre+str(a) for a in H],mat(e1['charts']['blocks']['light_primal']['source_conjugation'])))
    for ids,K in source_groups:
        for i,n in enumerate(ids):
            star=w.replace({word:s.conjugate(c) for word,c in A[n].items()},conj)
            expected=w.add(*(w.scale(A[ids[j]],c) for (k,j),c in K.todok().items() if k==i))
            assert not canonical(w.add(star,w.scale(expected,-1))),('SOURCE_SHIFT_CONJUGATION',n)
    for z,J in w.pairs:
        if z.startswith('x_'):
            star=w.replace({word:s.conjugate(c) for word,c in A[J].items()},conj)
            assert not canonical(w.add(star,w.scale(A[J],-1))),('SCALAR_SOURCE_SHIFT_REAL',J)
    delta=decode_typed(p['gauge_fixing_density'])
    assert not canonical(w.add(w.replace({word:s.conjugate(c) for word,c in delta.items()},conj),w.scale(delta,-1)))
    jets=0
    selected=['B0_0','C12','ub13','L13','bar0','b0','x_Phi_0','x_Sigma_0','x_phi_0','x_S_0',
      'JB0_0','JC12','Jub13','JL13','Jbar0','Jb0','Jx_Phi_0','Jx_Sigma_0','Jx_phi_0','Jx_S_0']
    pos={J:w.add(w.var(J),P) for J,P in A.items() if P}
    for n in selected:
        for mu in range(4):
            lhs=w.replace(w.var(n,(mu,)),pos);rhs=w.D(w.add(w.var(n),A.get(n,{})),mu)
            assert not canonical(w.add(lhs,w.scale(rhs,-1)));jets+=1
    try:w.D(w.var('C12',(0,)*6),0)
    except RuntimeError:cap=True
    else:raise AssertionError('JET_LIMIT_RETURNED_ZERO')
    rejected=[]
    for flag in ('candidate_adopted','sources_activated','E3_E5_executed','auxiliaries_eliminated',
      'catalog_rebuilt','HB1_C5_run','C1_GS_calculated','historical_equivalence_proved',
      'physical_gauge_independence_established','personal_outreach','external_endorsement'):
        u,v=dict(p),dict(r);u[flag]=v[flag]=True
        try:adjudicate(u,v)
        except AssertionError:rejected.append(flag)
        else:raise AssertionError('FALSE_E2_AUTHORITY_'+flag)
    changed=dict(r);changed['gauge_fixing_density']=[dict(v) for v in r['gauge_fixing_density']]
    changed['gauge_fixing_density'][0]['coefficient']='0'
    try:adjudicate(p,changed)
    except AssertionError:pass
    else:raise AssertionError('CHANGED_TRANSPORTED_COEFFICIENT_ACCEPTED')
    from a10_e2_transport_exterior_control import build as exterior
    small=stage('distinct_exterior_full_physical_transport_and_jet_control',lambda:exterior(stage))
    quartic=[r for r in p['gauge_fixing_density'] if sum(n.startswith(('ub','bar')) for n in r['word'])==2
      and sum(n.startswith('C') for n in r['word'])==2]
    assert quartic
    return {'schema':'A10_E2_ADVERSARIAL_CONTROLS_V1','status':'PASS_E2_ADVERSARIAL_AND_EXTERIOR_CONTROLS',
      'matching_result':matching,'wrong_ungraded_shift_source_bracket':rows(parity_residual),
      'omitted_derivative_shift_smeared_bracket':rows(derivative_residual),'omitted_derivative_shift_Euler_test':rows(euler),
      'bare_derivative_coordinate_bracket_misses_failure':True,
      'partial_source_transport_Jb0_square':rows(light_obstruction),
      'all_643_source_shifts_real_structure_verified':True,'complete_gauge_fixing_real_structure_verified':True,
      'field_source_first_jet_transport_checks':jets,'jet_resource_cap_raises':cap,
      'false_promotion_flags_rejected':rejected,'changed_action_coefficient_rejected':True,
      'quartic_ghost_monomials_retained':len(quartic),'E4_quartic_reconciliation_qualified':False,
      'exterior_control':small,'historical_controls':'ten sealed predecessor chains; no frozen evidence changed',
      'E3_E5_executed':False,'sources_activated':False,'historical_equivalence_proved':False}
