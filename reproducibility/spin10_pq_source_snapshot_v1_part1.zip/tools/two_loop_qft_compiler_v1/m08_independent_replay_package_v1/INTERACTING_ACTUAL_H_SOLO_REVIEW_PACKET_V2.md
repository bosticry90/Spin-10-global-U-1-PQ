# Interacting actual-H preflight: solo technical review questions

Current version V2, 2026-10-10. Supersedes the outreach/personnel disposition of `INTERACTING_ACTUAL_H_SPECIALIST_REVIEW_PACKET.md` under [the owner's solo-review policy](../../../docs/SOLO_REVIEW_POLICY_V1.md). Retain its mathematical questions; no personal contact, recruitment or external-participation gate applies. Historical bytes remain unchanged. This packet does not resume Phase C or promote a replacement.

Status: retained for solo review, with no personal outreach planned. No external review or endorsement has occurred. This packet concerns the inactive Phase A/B control, not acceptance of the Spin(10) physical hypothesis or a full M08 replacement.

Read the [frozen contract](INTERACTING_ACTUAL_H_PREFLIGHT_CONTRACT_V1.md) and the separately frozen primary/replay evidence under `frozen_interacting_actual_h_preflight`. The lossless evidence capsules use zlib/base64 with a SHA-256 digest of canonical uncompressed JSON; `audit_interacting_actual_h_preflight.decode` reconstructs the full exact expressions. The script emits no files.

## Questions requiring challenge, not endorsement by citation

1. Translate the evaluation-source bracket and `z_star=(-1)^p J` into an independently chosen canonical BV convention. Do the source-left ordering, right/left Euler derivatives, odd product rule and gauge-fermion shift agree, including even-field variation?
2. Check `-Tr(T_a T_b)=G_ab` and the actual block `[0,1,4,11]`, including conjugation. Does the control retain the compact real form through its complex coordinates? Are its lower-index connection and Minkowski contractions consistent?
3. Independently derive the complete field/source transformations from the gauge kinetic action and nonminimal master action. Check the source terms containing second derivatives, and the hypotheses relating the master identity modulo divergences to off-shell nilpotence.
4. Challenge the candidate coordinate choice for light bar/b. The maps from dual typed columns to primal control fields are explicit, but this is not yet an identification of historical nonminimal AST components. What further evidence would a complete M08 replacement require? Do the prospective heavy dual and light primal source maps preserve the evaluation bracket and conjugation under simultaneous coordinate changes?
5. Check quantum versus background local transformations, especially the Q-inert external background. Do cotangent source lifts and the transported contraction/quantum actions remain consistent after fixing? Is the asserted unchanged background action justified by the gauge-fermion Ward identity and the actual transport calculation?
6. Assess the joint domain and its relevance. Structural preservation in a pure residual-gauge control does not establish that the eventual full domain contains all necessary renormalization counterterms. Identify any restrictions that could make it too small or incompatible with the light/heavy fixing sequence.
7. Verify the explicit four-component master and gauge-fixing divergence currents. No equations of motion or high-jet truncation are allowed. The source-bearing `J_b^T F_01` control is a tensor-component diagnostic, not a claimed Lorentz-invariant counterterm.
8. Identify what does not transfer to the nonsymmetric heavy coset, composite R_H, shifted 328-scalar vacuum, partial gauge fixing, nonminimal partners and catalog descent. In particular, independently varying a local parameter before composite substitution is not the field-dependent Hamiltonian operation.

## Review disposition

Record exact scope, independently derived conventions, counterexamples, objections and their resolution. Unresolved consequential mathematical or physical objections block full-M08 promotion. Two algorithms sharing Python/SymPy, definitions, conventions and analyst earn only the declared computational independence. Published literature remains a methodological comparator; no personal participation is sought or required.

Primary literature comparators: [BV review by Gomis, Paris and Samuel](https://arxiv.org/abs/hep-th/9412228), [Ferrari's partial gauge fixing](https://arxiv.org/abs/1308.6802), and [Thomsen's partially fixed background gauge](https://arxiv.org/abs/2404.11640). These are methodological precedents, not verification of this implementation.

No Phase C, active source, HB1/C5, catalog, finite C1_GS or authority promotion is requested by this packet.
