# Historical-source decoder: independent semantic review questions

This is a review packet, not evidence that a specialist has reviewed or approved the construction. No external person has been contacted. Formal authority remains 34/39.

## Exact objects to distinguish

The six S33 source-left couplings use an operational indexed evaluation convention: their left source Euler derivatives recover the six frozen forward images. These AST components are not automatically the same numerical components as CAT1 self-dual carriers or REG7 channel sources. In particular, K_q and L_c have primal adjoint CAT1 recipes but dual INT12 physical columns.

The proposed decoder starts with the actual frozen physical columns/extractors. Let F map AST field coordinates into physical components, X map typed field channels into physical components, and Y map typed sources into physical covectors. Define

`T=F_left_inverse X`, `E=F^T Y`, `E_inverse=A_source F^-T`.

Then `z_AST=T z_channel`, `J_AST=E k_channel`, and the literal coupling pairing requires

`E^T T=Y^T X`.

Changing only sources induces the field/source bracket `(-1)^p E^-T`, not an identity bracket. Changing both coordinates produces the corresponding terminal channel pairing, not automatically identity either. The canonical candidate uses `z_star=(-1)^p J_AST`. This does not retroactively certify the historical ST operator.

For light self-dual macro carriers, the physical C3 basis fixes `J_AST=G_H k_macro`. This is a coordinate expression of the unchanged coupling. Inserting G into the original AST while retaining the original source variable would instead change that coupling. The two operations must not be conflated.

## Questions that must be challenged before full reconstruction

1. Do S33's actual contractions and its frozen indexed derivative implementation justify the stated operational evaluation components, including free-index and Lorentz orientation? Are any implied metrics not represented in these operations?
2. Does the physical coordinate triangle correctly bind the C3, INT8 and INT12 endpoints and the REG7 dual-row/primal-column orientation, with the recorded sqrt(2) gauge normalization and partner ordering?
3. Are the constant-map inverse, evaluation and conjugation certificates sufficient to use the decoder in a proposed canonical BV construction? What additional symplectic, local-functional or reality obligations are needed beyond this bounded comparison?
4. Lambda_H is a dual field and K_Lambda is its double-dual source. Does the reconstruction preserve this distinction rather than assigning every source the same Gram map?
5. The light nonminimal fields cbar_L/lambda_L have self-dual macro labels but dual typed columns. Their complete component and gauge-fixing meanings need review before adding K_cbar/K_lambda. The heavy antighost partner needs its own canonical coupling. What coordinate choice gives a coherent off-shell nine-pair construction?
6. In the proposed full action, how must Q, quantum residual action, contraction and background Ward action be transported together? Can the pre-light joint domain actually support the physical counterterm question, not just the qualified kinematic control?
7. How are the corrected scalar orientation, shifted v+phi, nonsymmetric coset, derived R_H and all composite source-chain terms generated from one action? Can an explicit small actual-H source/connection sector refute the proposed architecture before all transformations are constructed?
8. What impact does the new canonical/nonminimal architecture have on existing source-containing catalog expressions and descent through realization, packets, IBP, statistics and conjugation? No existing catalog is silently complete for added sources.

The old -2i, +1, -Box(u), frozen scalar +1 and Sigma-nonhorizontal controls remain historical evidence. A successful decoder is not a cure for those old defining operations. A full replacement needs a separate versioned authority decision, not an interpretation chosen to preserve previous investment.

The established field/antifield and gauge-fixing framework is reviewed by [Gomis, Paris and Samuel](https://arxiv.org/abs/hep-th/9412228). That literature provides a comparator, not independent verification of these repository-specific component maps.
