# Actual auxiliary-source/ghost derivative companion, prospective V1

Baseline8ab704242401225923b7de6c652c515e1fccdbc7; sole authority
project_state.json v113/34 of39. Prior goal turn PROGRESS: complete inactive
source-fixed derivative extension matches existing source/derivative poles.
Whole Spin(10) x global U(1)PQ remains active/incomplete. Freeze auxiliary-
derivative manifest and40 predecessor chains, code/input/state before work.

AG1 calculates the actual one-loop g^2 J_Lambda–C two-ordinary-derivative
dimension-zero UV logarithmic coefficient. Sources(1,-1,odd),ghosts(1,1,odd),
two jets give(4,0,even). Keep all45x45=2025 source/ghost coefficients,
allfour diagonal derivative directions and six symmetric off-diagonal
momentum components:20250 component coefficients including zeros. Scalar
Lorentz covariance reduces to Box only AFTER full unit tensor checks.
There is one independent two-point momentum, unlike the prior three-point
derivative-gauge pair. Retain derivatives on source, ghost or both and full
IBP currents. AG2 tests the complete inactive member's prediction after
complete actual-method agreement, without changing a coefficient.

Inputs: frozen BV action/source, E2 GF/columns, all643 field leading reference
blocks, E1 real/dual/primal and physical10 frames, physical action/vacuum/
potential/parameters/catalog/regulator. Sources external, auxiliaries
integrated; no field elimination, EOM quotient, inverse physical coupling/
mass, projected-M Jacobi, parameter specializations or physical activation.
Actual routes do not read candidate/normalization coefficients or peer output.
Freeze/qualify unit loop/sign/momentum/UV controls before group contraction.

Full source inventory includes the nonlinear g J_Lambda C_H Lambda_M cubic
and g^2 J_Lambda a_M C C quartic. Extract them literally, including all H/M
ghost assignments and all45 source zeros. A proper one-loop two-external
graph has two cubics or one quartic. Source cubic plus derivative ghost
cubic closes one H odd inverse and one M mixed Lambda/B inverse; retain
full BB,BL/LB,LL0 and both odd starts before edge screening. An external
ghost in the source cubic leaves a single integrated leg, zero Hessian.
Other bosonic/scalar/orbit/gauge/auxiliary/Xi vertices cannot close the source's
H ghost with its M auxiliary while providing the required external ghost;
prove these exclusions for THIS word degree. Source-linear terms have zero
second integrated derivative; H source terms and other coupling families
must be explicitly screened, not imported as a default zero.

The source quartic tadpole has no derivatives at its vertex, one internal
odd covariance and external total momentum zero. Its two-derivative
coefficient is zero BEFORE integration. Keep its heat profile2 and classify
possible no-jet cutoff-power or mass^2 log contributions separately, without
calling the whole integral scaleless or zero. Those no-jet amplitudes are
not calculated/accepted by this derivative contract. Positive-dimensional
mass/OrbitPullback insertions lower the derivative logarithm's UV degree;
their no-jet partners remain unqualified. No artificial inverse masses.

Primary uses full seven-coordinate reference, signed Fourier Hessians, both
Born bubble words and literal source/GF tensor contraction. Replay uses
independently routed ordered Gaussian/Wick pairing plus physical10 Casimir,
with external-source/ghost both ODD and explicit external crossings. Keep
literal derivatives on antighost/B/C; the complete GF current identity must
hold. Qualify all10 symmetric external-momentum coefficients, including
off-diagonal zeros. Independent Gaussian angular moments versus sphere-IBP
moments, exact rational arithmetic, full external momentum Taylor degree2
(no width/group truncation). Disclose shared inputs,Python/SymPy/analyst;
these are distinct derivations, not independent scientists. No agents/duplicates.

UV domain k_E^2>R_UV^2>0 above all external/mass scales. Leading kernel has
degree-2 power behavior, linear term degree-3 odd, quadratic term degree-4
logarithm. Derive bubble profile4, Minkowski masterI/(16pi^2epsilon), d=4
angular residues. Heat first/second Taylor factors applied to degree-2/-3
kernels give degree-2/Lambda^2 or degree0/Lambda^4 finite/power terms with
Gamma(1-epsilon)/Gamma(2-epsilon), not the logarithmic pole. Do not infer
this from a whole zero-momentum integral or confuse power and log terms.
No finite/IR amplitude or whole-regulator quantum restoration claim.

After completed actual agreement require reality, exact source/dual/primal
frame roundtrip, full leading ghost/mixed reference and homogeneous12H
identities. Local H jet Ward identities require partner amplitudes and are
not inferred from an isolated two-point Box tensor. Then open the complete
inactive95155-word candidate, reduce its entire g^2 JL–C two-jet projection
with full currents, including every coupling/width coefficient. Compare
all20250 components/2025 Box coefficients. Lower coupling orders require
their own graph-based zero proof. Preserve the first mismatch and an
independently signed real odd-source Euler/Fourier witness excluding a pure
boundary; stop before fitting, new image/higher/quartet/physical calculation
or adoption. On match retain every unmeasured no-jet/higher companion.

Numeric controls: wrong odd external/source sign, omitted mixed edge,
omitted internal/external derivative or full GF current, wrong Lorentz
metric/momentum tensor, source/dual chart, omitted second Taylor denominator
term, wrong odd-source Euler sign. Reject whole-scaleless, tadpole derivative
promotion, power/log confusion, full Ward/A5 or physical-acceptance inference.
Preserve exact failed/unfinished preparations/source/start/stdout with
classification. Four strict own-byte fresh routes controls/primary/replay/
comparison. Validate scientific/process/governance/delegatede5,40 protected
chains, new/protected/state byte and metadata invariance. Authenticate old
expensive loops/images without replay. Custody expectedexit2/seven unresolved
refs,neverPASS. Raw Git index/worktree equality before localcommit.

Possible dispositions: selected actual auxiliary-source derivative companion
qualified; exact stopped inactive obstruction; underdefinition; necessary
gate failure; incomplete execution. No normalization adoption, authority/
catalog/physical/HB1/C5/C1_GS/matching promotion, external outreach/push/
publication, fullE5/A5/Ward/contact/IR/anomaly, whole goal completion.
Global scalar/PQ,fermion/Yukawa/phenomenology remain. Local conventions,
epistemic ladder and solo-review policy apply without outside recruitment.
