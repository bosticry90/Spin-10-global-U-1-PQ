# E5 H-compatible cubic primitive and actual quartic companion

1. Question: does the measured auxiliary cubic difference admit an H-compatible
   polynomial gauge-fixing primitive, and do its complete interacting descendants
   agree with the actual g^2*xi^2 four-ghost pole? Baselinef7f6054, statev113/
   34of39,30 sealed predecessor chains. The preceding turn was progress.
2. Preserve full643 pairs,48 H backgrounds,34 physical/nine source terms, E2
   action/fermion, potential/vacuum/parameters, both nonminimal sectors and the
   actual nonsymmetric coset/composite R_H. No activation or elimination.
3. Derive the primitive from all49,005 measured tensor entries, with the correct
   dual-heavy antighost/Lambda and primal ghost maps. Q0 ubar=-Lambda fixes the
   antisymmetric two-antighost right section; do not fit physical coefficients.
   Verify real structure, grade, all12 local H identities and primitive ambiguity.
4. Form one complete inactive normalization using the qualified joint generator,
   the derived cubic primitive and the previously measured xi^2 width pole's
   source-free generator. Retain the latter's g^2*xi^2 R_H descendant. Compare
   full Q image with independent canonical first variation and density current.
   Preserve previously matched source/ghost/mixing/width and actual cubic poles.
5. Screen the complete literal one-loop four-ghost graph inventory. Include:
   four-cubic boxes (two g, two xi); g*xi quartic plus g/xi cubic triangles;
   ordinary g^2 B^2-ghost quartic plus two xi cubics; and two g*xi quartic
   bubbles. Include all external splits and anomalous odd Hessian blocks.
   Exclude higher vertices/other couplings only by explicit leg/type/UV proof.
6. Scope is all45 antighost directions (12 light/33 heavy) and all45 ghosts,
   with each odd pair antisymmetrized. Compare all990^2=980,100 independent
   slots, including zero H/light channels. A reduced heavy calculation requires
   proof of every excluded channel, not a convenient choice of operator domain.
7. Primary sparse graded Hessian/Born words and replay independent full graded
   Gaussian/Schur determinant expansion must agree. Replay independently derives
   physical10 matrices, H projections and ghost quartics. No ordinary projected
   adjoint closure or symmetric-coset shortcut. All mixed/odd/reference blocks,
   Grassmann order, symmetry factors and four Lorentz weights are retained.
8. UV Taylor only in the homogeneous UV region k_E^2>R^2>0. Prove momentum
   remainders convergent; no whole scaleless zero-momentum integral. Contraction
   with mixed gauge–auxiliary edges may reduce Lorentz copies only after an
   exact k_mu k^mu proof. Heat profiles for box/triangle/bubble stay distinct.
9. Compare actual full quartic pole with the complete candidate at its exact
   coupling degree. First required identity mismatch/underdefinition stops;
   preserve real Euler witness and independently reproduce it. Resource limits
   report unfinished output, never truncate coefficients or lower acceptance.
10. Check canonical pairing/source shifts and nonlinear source-jet prolongation,
    background H and regulated field measure. Source-free primitives move
    external sources and cannot cancel the integrated-field Berezinian. No
    arbitrary auxiliary integration or source-dependent physical regulator.
11. Negative controls omit new/old primitives, ordinary B^2-ghost triangle,
    quartic splits, R_H, odd/Lorentz/Gram factors or nonlinear jet terms.
    Fresh strict own-byte routes,30 parents and protected/new/state SHA plus
    metadata checks. Custody2/seven, not PASS. Preserve failed/unfinished runs.
12. No new JC-C-C/JB-B-C loops, full restoration/contacts/A5/E5/IR/anomaly claim,
    catalogs/HB1/C5/C1_GS/matching, authority change, outreach/publication/push.
    Shared immutable data/arithmetic/Python/SymPy/analyst disclosed; solo review.
    Validate before local commit. Whole Spin(10)xglobal U(1)PQ goal stays active/
    incomplete, including global boundedness/PQ quotient/fermion/Yukawa/phenomenology.
