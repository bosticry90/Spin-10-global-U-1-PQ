# Complete auxiliary cubic pole and joint-normalization stop

Scientific disposition: `STOP_E5_JOINT_NORMALIZATION_MISSES_AUXILIARY_CUBIC`.
Baseline93ef4f0, statev113/34of39,29 sealed predecessor chains. Recovery found
a clean tree and no calculation worker beyond the preflight itself. The
preceding turn was progress: it qualified selected auxiliary poles and one
complete inactive canonical image. This result tests a previously unmatched
cubic projection and establishes that the same candidate is insufficient there.

The complete selected g*xi^2 Lambda-ubar-C pole is independently reproduced.
All49,005 physical tensor entries compare;888 differ from the inactive joint
candidate. This is a bounded normalization failure. The classical physical
action, Stage D–E4, derivative adapters and previously matched source/ghost/
mixing/width projections retain their qualifications. No full quantum failure,
physical observable or Spin(10) unification verdict follows.

## Literal graph coverage and independent calculations

External scope is33 real heavy auxiliaries,33 real heavy antighosts and all45
ghost directions, with their primal/dual physical maps explicitly retained.
All643 canonical pairs/48 backgrounds remain. Sources and background are set
to zero only in this selected amplitude; their full records stay protected.
The literal order-xi cubic has no g. The coset is actually nonsymmetric.

At one loop, E_internal=V gives sum(vertex degree-2)=3 for this three-point
amplitude. Thus the connected 1PI graph forms are three cubics or a cubic/
quartic pair. For three cubics, each vertex must have one external leg.
Physical gauge/scalar cubics have no required external Lambda/ubar/C leg.

The nonzero triangle uses the order-g derivative gauge/ghost cubic and two
order-xi Lambda/ubar/u cubics. The alternative attaches the external antighost
to the derivative vertex; its UV degree is -1, so its logarithmic coefficient
is zero. This is a UV-degree statement, not a claim that its full finite
amplitude vanishes. Derivatives on other literal ghost/gauge placements and
their entire integration-by-parts current are included. Residual-H external
ghost vertices cancel functionally, rather than being deleted by assumption.

The720 order-g Lambda-B_H-B_M coefficients supply another bosonic triangle
class. Each xi cubic uses a heavy auxiliary, so the required B_H-Lambda_M
edge is exactly zero in the orthogonal physical reference. The corresponding
light-antighost alternatives have a zero H/M ghost edge. These classes were
screened explicitly. No symmetric-coset condition or early auxiliary
elimination is imposed. Positive-dimensional orbit/mass/mixing insertions
lower the UV degree and cannot supply the dimension-zero cubic logarithm.

The cubic/quartic bubble includes all648 literal g*xi four-ghost coefficients.
They pull back to3,096 physical coefficients. The full quartic Hessian is
taken before tracing it against the actual order-xi auxiliary vertex. The
literal inventory also includes17,480 ordinary g^2 and418 g^2*xi nonminimal
quartics; their nonnegative g degree excludes them from the g*xi^2 target.
Reference width factors are retained. All nonzero selected graphs use mixed
gauge–auxiliary and/or ghost inverses, which do not generate inverse powers
of g or extra width factors in this channel.

Primary constructs graded Fourier Hessians and all six Born words for the
logarithmic triangle. Replay independently enumerates ordered Gaussian/Wick
pairings, including their external odd-variable order and momentum signs.
Two internal ghost component labels avoid collapsing distinct index paths.
All4 Lorentz weights and both odd starts survive. Each primary triangle word
has weight i/6, summing to i; the quartic role has coefficient -i. The extra
minus converting that role to the complete odd Gaussian operator is explicit.

For real heavy matrices A_a=P_M ad(e_a)|_M, define the full triangle tensor

    T_a = sum_i A_i A_a F_i,

where F_i=[0_H,A_i] is derived from the literal gauge/ghost vertex, with the
H functional cancellations included. Define B_a by the weighted quartic
operator trace, using left_C left_ubar of the complete physical quartic and
the matrix A_a. Primary pulls back and varies the literal action; replay
reconstructs the quartic from normalized physical10 commutators and signed
ordered-word deletion. An ordinary adjoint-representation closure is not
assumed for the projected heavy matrices.

In common hbar*g*xi^2/(32 pi^2 epsilon) units the actual pole matrices are

    G_a = -2(T_a+B_a).

Each separate triangle and bubble group has600 nonzero coefficients. Their
complete sum has600. Implicit zeros and all12 H ghost columns are included.

## UV extraction without a scaleless-IR verdict

The divergent homogeneous term is evaluated only in k_E^2>R_UV^2>0. R may
be chosen above the fixed external-momentum scales for the Taylor expansion;
its logarithmic residue is independent of R. The external-momentum remainder
has negative UV degree. No whole massless zero-momentum integral is assigned
a value and no physical mass is changed.

The primary four-dimensional analytic radial residue and the replay scalar
dimensional bubble at nonexceptional momentum give1/(16 pi^2), with explicit
Minkowski factor i. The UV heat integrals retain different profiles,

    triangle: E1(6 R_UV^2/Lambda^2)/(16 pi^2),
    bubble:   E1(4 R_UV^2/Lambda^2)/(16 pi^2).

They have equal logarithmic residues but different finite UV-split terms.
This is not a calculation of the complete finite amplitude, physical IR
limit, finite Slavnov restoration, general contacts or anomaly freedom.

## Exact comparison and real Euler witness

The g*xi^2 cubic projection is extracted directly from the sealed47,958-term
joint image. Independent paired field variation reproduces its heavy matrix

    C_a = sum_i kappa_ia A_i + kappa A_a - A_a kappa,

with H ghost columns zero. The full width primitive Q image is retained;
it does not remove the measured cubic discrepancy.

At real Lambda coordinate0, real antighost coordinate1 and full real ghost
coordinate14, the common-unit coefficients are

    actual:    48 sqrt(10)/25,
    candidate:  8 sqrt(10)/5,
    difference: 8 sqrt(10)/25.

With independent admissible coordinates tLambda, thetaBar and thetaGhost,

    difference density = (8 sqrt(10)/25) tLambda thetaBar thetaGhost,
    Euler_Lambda       = (8 sqrt(10)/25) thetaBar thetaGhost != 0.

Direct left Euler differentiation independently reproduces this witness.
It is off shell and cannot be an ordinary total derivative. All888 nonzero
difference coefficients are preserved. The difference is antisymmetric in
the Lambda/antighost slots, an informative tensor classification; no further
primitive is constructed or adopted in this increment.

A tested shortcut G_a=2 A_a kappa also fails, with776 residual coefficients.
Its entire residual is preserved as a negative control. It is not used to
compress the accepted actual tensor or justify the result.

## First-failure decision and validation

Stop before JC-C-C/JB-B-C loops or adoption of another normalization. The
next smallest scientific increment is to derive and independently qualify
whether the measured difference admits an H-compatible cubic gauge-fixing
normalization in the allowed polynomial/type space. That work must preserve
the already matched projections and then test its interacting quartic
descendants. An algebraically possible primitive alone cannot establish
quantum normalization admissibility or complete restoration.

The receipt owns actual executed checks, exits, counts and timings. The
targeted suite contains397 tests:20 new auxiliary-vertex controls,332 inherited
scientific,24 process and21 governance tests. Required validation freshly
reproduces both original route bytes with strict start fingerprints, compares
all tensors, independently screens the graph classes and Euler witness,
authenticates29 predecessor chains, and checks protected/new/state SHA bytes
and bounded size/mtime metadata. Old expensive qualified work is authenticated,
not rerun. Workspace metadata is not an unrestricted environment byte audit.

The initial graph auditor incorrectly restricted the quartic inventory to
xi-bearing orders. Its source and failed assertion are archived; ordinary
g^2 quartics are now explicitly recorded and excluded by coupling degree.
One regression supplied native p2=3, allowing Python 1/p2 to become a float;
its source/failure is archived, and its test input is corrected to exact
SymPy Integer. Production loop inputs were symbolic and exact. Neither
completed primary/replay record was edited. These failed preflights are
excluded from PASS evidence. The failed simple tensor compression is also
explicit, with the complete pole retained.

Shared immutable action/frame data, chart/word arithmetic, Python3.10.11,
SymPy1.14 and analyst remain. The replay is independent computational
derivation, not outside endorsement or proof-kernel certification. Solo review
continues without personal outreach. Formal authority remainsv113/34of39;
strict historical custody remains exit2 with seven unresolved references,
never PASS. No physical parameters, frozen action/fermion, source catalog,
activation, auxiliary elimination, HB1/C5/C1_GS/matching, publication or push.

Full E5/W1–W7/A1–A5, finite/IR/anomaly obligations, global scalar boundedness,
the PQ quotient, fermion/Yukawa and phenomenology remain open. The complete
Spin(10)xglobal U(1)PQ investigation remains active and incomplete.
