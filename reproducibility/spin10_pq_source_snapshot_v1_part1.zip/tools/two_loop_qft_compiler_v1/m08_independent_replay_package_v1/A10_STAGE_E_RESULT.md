# Stage E E1: historical fermion chart remains underdefined

Disposition: `STOP_E1_HISTORICAL_FERMION_CANONICAL_CHART_UNDERDEFINED`.

The authorized inactive Stage E investigation reached its first architecture prerequisite and stopped. The Stage D result of `f7d5868` authenticates successfully and remains qualified in its gauge/scalar scope. No transported full gauge-fixed candidate or complete H-basic domain has been qualified here.

## What prevents the transport

The current historical fermions are A4-V2 and A5-V2. A5-V2 already contains the total-H connection in its heavy divergence, `D[Abar_H+q_L] V`. The obsolete ordinary-derivative A5-V1 is not the input to this result.

Stage D fixes heavy antighost `ub` and auxiliary `L` as evaluation-dual heavy coordinates, with canonical sources in the opposite frame. The prospective nonminimal maps in the saved actual-H architecture explicitly record `historical_nonminimal_AST_identified=false`. The six-source decoder and the subsequent Euler adapters qualify their own field/source interfaces; they do not automatically identify the nonminimal leaves and all contractions in the historical gauge-fixing fermions. In particular, the historical A5-V2 auxiliary summand is the bare component contraction `-xi ubar_H Lambda_H/2`.

A canonical field/source evaluation pairing and an invariant bilinear pairing of **two dual-heavy fields** are different mathematical objects. Directly identifying the historical labels with Stage D `ub,L`, while retaining that bare auxiliary contraction, fails an essential residual-H covariance check. This rejects that identification. It does not prove that every interpretation of the historical AST fails, or that the Stage D physical action or BV bracket is defective.

The stopping condition is the missing typed fermion-to-canonical chart. The exact failure below explains why filling that gap by copying names and keeping a delta contraction is inadmissible. A complete newly derived typed fermion is the next necessary mathematical task.

## Exact auxiliary witness and full-fermion exclusion

For normalized Stage D structure constants define the 33-dimensional dual-heavy action

`D_h[i,j]=f[j,h,i]`, with `T ub=g10 D_h omega_h ub` and `T L=g10 D_h omega_h L`.

For the direct-identification auxiliary summand `psi_aux=-xi ub^T L/2`, its Ward variation is

`T psi_aux = -xi*g10/2 sum_h omega_h ub^T (D_h^T+D_h) L`.

Both routes compare all **13,068** entries of the twelve 33-by-33 coefficient matrices, including implicit zeros. All **264 nonzero coefficients** agree exactly. At H index 1, `f[13,1,13]=-i/sqrt(2)`, giving the selected monomial

`T psi_aux |_(omega1 ub13 L13) = i*g10*xi/sqrt(2) omega1 ub13 L13`.

The corresponding coefficient in the Euler derivative with respect to `L13` is `i*g10*xi/sqrt(2) omega1 ub13`, and is nonzero. The full Euler column is preserved in both evidence files. There are no derivative jets in this summand, and the nonzero Euler derivative rules out an ordinary total derivative. No equations of motion, auxiliary elimination or special parameter values are used.

This is not an isolated summand falsely promoted into a complete-fermion verdict. The complete recovered fermions were screened for this **specific auxiliary monomial** before any projection. The heavy divergence and orbit terms contain no `Lambda`; the cubic nonsymmetric-coset term also contains no `Lambda`; the light fermion has different nonminimal species. Their even H variations do not create this heavy `ub*Lambda` monomial. Thus they cannot cancel this coefficient under the rejected direct identification. All those historical terms and the actual nonsymmetric coset remain unchanged.

An admissible real physical-frame witness removes any reliance on freely assigning complex parent coordinates. Let `Q_M` be the heavy columns of the qualified C3-to-plane frame and `P_M=Q_M (Q_M^T Q_M)^-1 Q_M^T` its exact projector. Choose real physical inputs `ubar_plane=P_M e_1 theta`, `Lambda_plane=P_M e_2 t`, with real odd `theta`, real even `t` and real H parameter `omega1`. Both routes verify heavy projection and the induced parent conjugation. The Ward density becomes

`sqrt(2)*g10*xi*omega1*theta*t`,

whose Euler derivative in `t` is `sqrt(2)*g10*xi*omega1*theta`. The replay additionally derives this coefficient by an ordinary first variation in an independent even variation parameter, leaving `theta` as an odd exterior factor.

## Derived pairing control, not a completed repair

The physical embedding of dual-heavy coordinates is `Q_M G_M^-1`, where `G_M=Q_M^T Q_M`. Its induced bilinear is exactly `G_M^-1`. Consequently the separate control `-xi ub^T G_M^-1 L/2` has zero Ward residual for all twelve H generators:

`D_h^T G_M^-1 + G_M^-1 D_h = 0`.

That matrix follows from the already qualified physical frame; it is not fitted to the failed coefficient. It demonstrates the needed type distinction. It does **not** bind the historical fermion, settle its cubic tensor or orbit normalization, translate the light fermion, compute quartic ghost interactions, or establish complete canonical gauge-fixing transport. No historical AST was changed and no repaired fermion was adopted.

## Gate disposition and preserved results

| Gate | Result |
| --- | --- |
| Stage D authentication | Bounded PASS preserved |
| E1 current fermion recovery | A4-V2/A5-V2 authenticated; total-H divergence retained |
| E1 historical-to-canonical nonminimal chart | Underdefined; direct bare-pairing identification rejected exactly |
| E2 complete canonical gauge-fixing transport | Not executed |
| E3 complete quantum/background identities after fixing | Not executed |
| E4 complete composite/nonminimal/quartic-ghost reconciliation | Not executed |
| E5 useful full interacting H-basic domain | Not qualified |
| Independent replay of decisive E1 evidence | Exact agreement |

The homogeneous auxiliary H action is shared by the quantum and background descriptions in this selected constant-parameter channel. Their connection transformations remain distinct. This diagnostic does not substitute one for the other or claim that the full quantum/background identities have been checked.

The 643-pair Stage D candidate, its master functional under its declared boundary conditions, physical Euler programs, source-only algebra and structural source nilpotence remain sealed and inactive. Older scalar-action, five-form normalization, Lorentz-Euler, composite-curvature and missing-source-partner negative controls retain their qualifications. The scalar vacuum and potential parameters were not changed. There is no new physical-action counterexample, particle prediction or quantum observable.

## Independent evidence and validation

Primary applies an even graded Leibniz derivation to the 33 auxiliary monomials using authenticated Stage D structure coefficients. Replay independently computes **396 H-heavy commutators** from normalized physical antisymmetric 10-by-10 matrices and differentiates a bilinear directly. Replay imports no primary diagnostic output. Serialization, physical assumptions, Python/SymPy and the analyst are shared; external endorsement and runtime/library independence are not claimed.

During development, an attempted real witness used unprojected physical plane directions. They were not pure heavy directions, and the projector assertion rejected them. The final witness uses the exact `P_M` projections. This corrected the witness selection, not the Ward operation or its 264 coefficients. The failed development selection is disclosed in `execution_notes.json` and is not scientific PASS evidence.

The bounded receipt records **122 targeted regressions**: 14 new and 108 inherited. That total comprises 101 scientific and 21 governance regressions. Three fresh read-only routes regenerate byte-identically; eight predecessor evidence chains authenticate, inherited byte bindings remain unchanged and the final audit detects zero workspace/active-data metadata mutations. The metadata inventory checks size and modification time, not every byte of the workspace. Fourteen adversarial false claims are rejected separately. The older expensive source and representation calculations were authenticated rather than repeated. Timing, CPU, process peak and opened-path measurements are retained; unmeasured cache and per-operation subdivisions are disclosed. An initial receipt-count assertion omitted the governance tests after all checks passed; its bookkeeping was corrected before the final validation transaction and no successful receipt was issued for that attempt.

Evidence validation is `PASS_BOUNDED_STAGE_E_E1_STOP_EVIDENCE_VALIDATION_ONLY`. Scientific Stage E is **stopped**, not passed. Formal authority remains **34/39**, `project_state.json` is unchanged, historical custody remains strict exit **2** with **seven unresolved references**, HB1/C5 remain blocked and finite `C1_GS` is uncalculated. No source activation, catalog reconstruction/replacement, unrestricted validation or remote push occurred.

## Next decision

The next bounded investigation should derive an inactive, fully typed A4-V2/A5-V2-to-Stage-D fermion translation, or a separately named replacement fermion with an explicit historical comparison. It must bind both nonminimal charts, derive invariant primal/dual pairings, preserve `xi`, `eta_H` and `alpha=xi` under explicitly resolved normalization conventions, translate the nonsymmetric cubic ghost tensor and the exact shifted-vacuum orbit, and compare physical-frame first variations independently. The inverse-Gram auxiliary control alone is insufficient. Resume E2-E5 only after that E1 prerequisite is qualified.

Ferrari's [partial-gauge construction](https://arxiv.org/abs/1308.6802), section 3.1, requires an H-invariant partial fermion and distinguishes it from background gauge fixing. Thomsen's [partially fixed background gauges](https://arxiv.org/abs/2404.11640), section 2.3, provides the separate background/source transformation comparator. These publications support the methodological distinctions; neither certifies this project-specific chart or replaces reproducible qualification. Review continues under [the solo-review policy](../../../docs/SOLO_REVIEW_POLICY_V1.md), without contacting people.
