# A10 physical-action reconciliation: inactive candidate contract

The owner requests execution of the assessment following `2665832`, including
physical-action reconciliation before any resumed source reconstruction.
This contract authorizes a separately named classical physical-action candidate
and its exact tests. It does not authorize editing frozen A10/M08 definitions,
activating sources, rebuilding catalogs, HB1/C5, quantum matching, C1_GS,
formal-ledger changes, remote push, or Phase C resumption.

First authenticate the existing failed A10 channel and immutable inputs.
Establish A37/A10's intended scope from literal construction and acceptance
records, without inferring intentional truncation from a later failure.
Then derive the kinetic coefficient and matter orientation from local covariance
under the frozen connection normalization, before examining candidate residuals.
The original A10 must retain its exact nonzero coefficient and Euler witness.

The first candidate control is the full 54-coordinate Phi sector with H4 and a
nonzero connection in four Minkowski directions. Primary uses the certified H
matrix and exterior jets; replay reconstructs the physical tensor and ordered
words. Require the complete kinetic-density variation to vanish, including
cubic and quartic contributions, and reproduce the original coefficient.
Stop further physical expansion if this control fails or is undefined.

After this control passes, cover all four scalar sectors and all 45 Spin(10)
generators in the canonical real plane frame. Primary pushes frozen component
tensors through sparse slot replacements; replay constructs ambient tensor
functor matrices and projects through A31, without reading primary results.
Compare every exact representation coefficient. Prove full local covariance
and kinetic/gauge/potential invariance with complete matrix/tensor identities;
factorization is allowed and must be distinguished from a monomial catalog.
Preserve the original 29 potential directions and all scalar parameters.

Derive the shifted kinetic terms and actual frozen N5-N8 vacuum orbit, gauge
mass matrix, scalar-vector mixing and Goldstone mass/pairing implications.
Specify quantum and background actions separately. A frozen VEV is inert for
quantum symmetry; a background transformation may either transform the VEV as
a spurion or act affinely on the fluctuation. Derivatives must be varied before
a constant-VEV or zero-connection projection. Neither convention is silently
imposed on historical gauge-fixing or source rules.

Audit the full candidate physical action in both routes, preserve the exact
historical negative control, and classify prior claims by dependencies.
Issue a versioned scope correction for contradicted action-completeness claims;
do not rewrite historical PASS records. Potential-only Higgs stability remains
bounded, with global boundedness and phenomenology outside this calculation.
Stop if a required physical input or convention is inconsistent/undefined.

The owner subsequently directed that this is a solo project and no outreach
will take place. Prepare a self-contained technical review packet for the owner.
External specialist scrutiny was not performed; the independent computation is
not a substitute claim of external review. No outreach, reviewer recruitment,
or external-participation gate is imposed on this bounded review.

Freeze primary and replay evidence separately before comparison; use the
pole-blind guard and read-only calculation runners. Require byte-identical
regeneration of new bounded evidence, meaningful omission/normalization/shift
controls, preserved predecessor bindings and live project_state bytes. Reuse
qualified expensive historical results instead of repeating them. Historical
custody exit 2 remains unresolved, not PASS. Commit locally after validation.

The output ceiling is an inactive classical physical-action candidate with
explicit acceptance limits and a dependency/technical review packet. Even
successful candidate tests do not reconcile the source/gauge-fixing architecture
or authorize Phase C, HB1/C5 or matching to resume.
