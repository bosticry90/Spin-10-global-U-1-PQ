# Clarification of the propagator counterexample

The frozen controls and result V1 call the -1/79 example a transverse
counterexample. Its literal value is the FULL BB_22 component at
q=(2,3,5,7), K=q^2=-79, width=1. It contains a longitudinal contribution
-25/6241 and a transverse contribution -54/6241. The value -1/79 should
not be read as the isolated transverse part. Preserve the original bytes.

The supplementary exact unit uses v=(3,2,0,0), v.q=0, v^2=5. Directly
contracting all sixteen full propagator components gives v.BB.v=5/79 for
arbitrary width, while the rank-one longitudinal part gives zero. The
independent projector formula -v^2/K reproduces 5/79. This precisely
exhibits a nonzero transverse contribution outside the g^3 endpoint proof.

The preparation freezes source bytes, q/v, expected rational result, the
existing validation receipt and a Q[width] coefficient type before the
read-only computation. The complete output is preserved. This is a unit
clarification, not an actual g^4 W/W loop, new pole, candidate fit or change
of the g^3 qualification. The two actual routes, 3,960 residual slots,
all four fresh executions, 64 tests and scientific authority are unchanged.
Existing frozen report/navigation wording is interpreted with this note.
