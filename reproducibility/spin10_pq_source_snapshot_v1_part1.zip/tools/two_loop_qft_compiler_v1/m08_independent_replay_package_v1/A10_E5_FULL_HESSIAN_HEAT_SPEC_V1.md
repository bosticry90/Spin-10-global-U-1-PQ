# Explicit finite heat-cutoff ghost loop in the retained Hessian family

This independent completed control supplements, never replaces, the complete
643-field Hessian/reference and nonlinear retained-source Ward checks. Bind
the completed same-route core artifact before calculating; do not overwrite it.

For F(p)=exp(-p_E^2/Lambda^2), the reference Green program F G_ref F has
multiplier exp(-2p_E^2/Lambda^2). All auxiliaries/sources remain, and its
auxiliary-auxiliary Green block is still zero. At g=0 the actual xi Lambda ub u
vertex survives. Its two-leg loop is

    I_Lambda(q)=integral d^4k/(2pi)^4
         exp[-2(k^2+(k+q)^2)/Lambda^2]/[k^2(k+q)^2], q^2>0.

Primary completes the Gaussian square in two Schwinger parameters s,t>=a,
a=2/Lambda^2, then integrates their total scale. Replay differentiates the
two lower integration limits first and integrates the resulting boundary
integral from the zero large-a amplitude. Independently derive

    I_Lambda=1/(8pi^2)[E1(c)-E1(c/2)/2
                              +(exp(-c/2)-exp(-c))/c], c=a q^2>0.

The UV subtraction coefficient is1/(16pi^2), with finite remainder

    [log(mu^2/q^2)+1-EulerGamma-log4]/(16pi^2).

This is a concrete finite nonexceptional amplitude, not merely the statement
that a regulator could exist. Its local finite scheme difference from the
preceding analytic MS bubble is retained. q=0 instead has an IR problem and
must not be included silently in a PASS. Positivity and UV/IR convergence of
this one integral are explicit; they do not prove full physical IR existence.

Multiply by the already qualified xi^2 kappa density/2 with its exact closed
ghost sign. Reuse the actual33-coordinate metric and BRST primitive; never
insert g into the surviving interaction, drop sources or eliminate auxiliaries.
Freshly check the Q0 primitive and source independence in both routes. Full
nonzero-g restoration, all local probes/contacts and quantum A5 remain open.
