# E5 normalization types and auxiliary-shear prerequisite

Prospective bounded contract. Baseline is
`38c2a3f0ce707c4706298089ed4e85a8b326c642`, state v113, 34/39, with
32 sealed predecessor manifests. The previous increment qualified the actual
quartet and refuted the complete inactive K0 + Kjoint + K3 prediction. That
failure and every superseded or unfinished execution remain immutable.

## Question and claim ceiling

NT1: In the inherited polynomial, real, local H-compatible generator domain,
can additional source-free freedom change the heavy quartic residual while
preserving the already measured width and auxiliary cubic?

NT2: Which generator types can contribute to a source-zero, jet-zero
two-antighost/two-ghost density? Derive the companion terms of an auxiliary
shear whose tensor is obtained from the existing xi auxiliary interaction.
This is a classical canonical prerequisite, not a repaired normalization,
an actual loop calculation, quantum A5, a claim of residual membership in the
general canonical image, or complete E5/unification acceptance.

The complete actual quartet has 980,100 antisymmetric slots and a preserved
5,528-slot residual. Do not fit coefficients to this tensor in this increment.
Do not run new JC-C-C, JB-B-C or other loop amplitudes. Do not adopt a generator.

## Frozen domain and inputs

Use all 643 field/source evaluation pairs, 48 external H backgrounds, both
nonminimal sectors, ordinary symmetric jets, source-left Q, E1/E2/E3 and the
qualified real/dual/primal charts. Project grade of K is (3,-1,odd); QK is
(4,0,even). Sources have grade (3-d,-1-gh,1-p). Ghosts and antighosts have
dimension one, auxiliaries dimension two. Retain nonnegative-dimensional
parameters and polynomial physical couplings; no inverse mass/coupling,
new physical coefficient, auxiliary elimination, changed fermion/action,
regulator, canonical alphabet or parameter normalization.

The immutable input manifest is
`frozen_a10_e5_quartic_companion/bindings.json`. Its transitive bytes and
`project_state.json` are authenticated before execution. Own source/contract
bytes, input-manifest and state hashes are frozen for each attempted route.
Calculations run read-only under the established pole-blind guard. Distinct
primary/replay routes own separate outputs and are compared after completion.
Sequential execution is sufficient; no agent organization is authorized.

## Required derivations

1. Enumerate dimension/ghost/parity field and source type patterns, with
   finite jets and nonnegative coefficient dimensions. Prove that only
   a Lambda, a a C, JC C, Ja a and JLambda a C can carry the selected
   derivative-free quartet under Q. Other patterns, multiple sources,
   physical/background variables, jets and positive-dimensional parameters
   need explicit projection/grade exclusions. This is a carrier-type result,
   not a classification of all generators or their invariant coefficients.
2. In the source-free heavy carrier sector, the measured width fixes the
   symmetric a-Lambda bilinear and the complete cubic fixes the antisymmetric
   a-a-C right section injectively. Derive the remaining skew a-Lambda
   ambiguity and its interacting Q image. Check in a real physical frame that
   the connection matrices are skew, QLambda curvature lies in their span,
   and local H-compatible skew A commutes with them. A skew A times a commuting
   skew curvature matrix is symmetric, so its odd bilinear vanishes. Check
   the connection cancellation as well. This proves no additional source-free
   correction of this heavy quartet with the prior matches held fixed.
   Do not claim completeness for arbitrary source-dependent transformations.
3. Derive a minimal auxiliary shear without reading/fitting the residual:
   F_i(a,C) is the coefficient of xi in the two-odd part of the actual
   E2 auxiliary Euler column Q JLambda_i. Set
   Kshear = g^2 xi sum_i JLambda_i F_i.
   The unit coefficient defines an exact image, not a subtraction choice.
   Derive its full Q image and a distinct direct first variation of the
   entire source/gauge-fixing polynomial, retaining all sources and currents.
   Retain the full quartic image over 45 antighost/ghost directions, including
   justified zeros. Do not compare or solve it against the actual residual.
4. Check real structure, all 12 local H identities, Hamiltonian field/source
   signs, all 1,286 generator columns including zero spectators, exact
   polynomial inverse and canonical pairing. The integrated-field map shifts
   only Lambda by F(a,C); prove its triangular Berezinian is exactly one,
   independently of H/background regulator weights. Nonlinear mean-field
   transport and composite insertion/contact normalization remain unproved.
5. Derive every distinct field/source type and coupling degree in the image.
   In particular retain g^2 xi derivative B-a-C, g^2 xi^2 Lambda-a-C,
   g^2 xi^2 quartet and nonminimal-source companions. Verify that previously
   measured source/kinetic/mixing/width/cubic projections are unchanged at
   their measured coupling degrees. No new amplitude is presumed to match.
   Prove ordinary jet prolongation, including nonlinear second-jet terms.

## Methods, controls and validation

Primary uses graded prefix Q application and the literal auxiliary Euler
column. Replay differentiates the full inherited density with left Euler/IBP
and reconstructs that column and the shear independently. Full outputs agree.
The source-free exclusion also has an abstract transpose/commutator derivation
and explicit inherited physical representation checks. Do not infer projected
adjoint closure or a symmetric coset.

Controls must expose wrong odd signs, a non-H-compatible skew ambiguity,
wrong source pairing/Gram identification, omitted auxiliary-width/cubic/source
companions, missing nonlinear second jets and a false claim that a classical
triangular Jacobian proves quantum canonical equivalence. Every counted
negative control has a nonzero residual or an explicit rejected inference.

Validate both completed routes before local commit: fresh strict own-byte
reproduction, targeted scientific/process/governance checks, 32 predecessor
chains, protected/new/state SHA and audit-time size/mtime inventory. Run the
existing `python -B tools/research_check.py e5` delegate; historical custody
must remain exit 2 with seven unresolved references, never PASS. Do not rerun
qualified expensive loop calculations. Preserve exact failures/unfinished
attempts; resource limits report incomplete work, never truncate tensors.

Possible outcomes: bounded carrier/source-free obstruction and classical
shear qualification; exact identity obstruction; underdefinition; or
incomplete execution. Stop on the first necessary failed identity and preserve
its exact evidence. A qualified prerequisite does not overturn the preceding
normalization failure. Record the next smallest justified scientific action.

Shared immutable inputs, graded arithmetic, Python/SymPy and analyst remain
disclosed under the solo-review policy; no independent-scientist endorsement
or proof-kernel certification. No publication, outreach, remote push, catalog
activation, HB1/C5/C1_GS, matching, authority change or physical promotion.
The whole Spin(10) x global U(1)PQ investigation remains active/incomplete,
including full quantum, scalar/PQ, fermion/Yukawa and phenomenology obligations.
