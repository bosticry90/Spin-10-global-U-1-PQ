# Actual g^3 quartet qualifies; the frozen prediction fails

QG3-1 establishes the selected actual one-loop, source-free, dimension-zero
four-ghost logarithmic pole. The full graded Born and physical-commutator
Gaussian/Schur routes agree, family by family, before prediction access.
QG3-2 fails: the unchanged candidate frozen at 8ab7042 misses this pole.
This is an exact stopped candidate obstruction. No coefficient, generator,
image, physical parameter or prior result was adjusted.

Both the actual and predicted tensors have 4,944 nonzero physical entries
and 966 canonical terms. Equal support and term counts do not imply equal
coefficients. The comparison covers all 990 x 990 = 980,100 antisymmetric
antighost/ghost pair slots and all width coefficients, including 975,156
actual zero slots. There are 3,960 nonzero physical residual entries and
648 canonical residual terms. The xi^2 residual has 3,960 nonzero slots;
the xi*eta_H residual has 3,544. No eta_H^2 residual occurs.

With the common factor hbar*g10^3/(32*pi^2*epsilon), the coefficient of
a_12 a_13 C_12 C_13 in the physical real frame is

    actual:    -16*xi*(2*eta_H + 7*xi)/25
    predicted: -32*xi*(eta_H + xi)/25
    difference: -16*xi^2/5.

The full left Euler derivative of the residual with respect to ap13 starts
with +16*xi^2*Cp12*Cp13*ap12/5. Independently ordered odd deletion reproduces
it. Treating the odd antighost as even leaves a nonzero +32*xi^2/5 residual
in this component. Thus the discrepancy is not a pure total derivative.
No EOM quotient or anomaly interpretation is inferred. A mixed-width example,
the (12,13;17,31) residual, is
-3*sqrt(10)*eta_H*xi/10 - sqrt(10)*xi^2/2. The failure is not confined to the
width channel shown in the first example. Full differences and Euler
polynomials are preserved, rather than only these witnesses.

The complete leading Hessian inventory retains derivative ghost G, auxiliary
X, g*xi quartet Q, g^2*xi curvature quartet R and g^2 ordinary BBaC vertex W.
W includes all H/H, H/M and M/M gauge legs: 3,530 raw terms per Lorentz copy,
14,120 across all four. Q has 648 raw terms and R has 418. The replay derives
G/X/R from physical parent commutators and the qualified input BRST/GF signs,
then independently reconstructs full W and Q and checks its own literal
vertices before any trace. It does not import the new primary tensor.

| Family | Born words | Formal physical nonzero slots | Heat profile |
| --- | ---: | ---: | ---: |
| G,G,G,X box | 4 | 5,528 | 8 |
| G,G,Q triangle | 3 | 3,960 | 6 |
| G,X,W triangle | 6 | 7,470 | 6 |
| G,X,R triangle | 6 | 4,944 | 6 |
| Q,R bubble | 2 | 7,050 | 4 |
| W,Q bubble | 2 | 0 | 4 |

The W/Q zero follows from the complete even/odd Hessian blocks. It was not
used to restrict the actual tensor. The Gaussian route retains Ugg, both
Ugx splits, both W inverse corrections and Q/R cross terms; Uxx is zero
because the complete auxiliary/auxiliary reference block is zero. Both odd
propagator orientations and mixed gauge/auxiliary propagators are retained.
The permitted proper one-loop cycles obey n3+2*n4=4. Bosonic vertices without
odd external remainders cannot contribute to this proper quartet cycle;
positive-dimensional scalar/Orbit/mass insertions lower the requested UV
degree. Other coupling orders, external backgrounds and their amplitudes
are not silently accepted by these exclusions.

Before reducing the loop direction, the complete four-vector propagator
proves k.BB=-w*k/K and k.BB.k=-w. Every BB edge in these g^3 families has the
required derivative endpoint, directly or through W's metric. Full-vector
Born and Gaussian unit calculations and the reduced unit calculation agree
on all six classes. Each of the five nonzero classes has a nonzero omission
and loop-sign control. A transverse -1/79 counterexample excludes extending
this reduction to a g^4 W/W bubble. No general transverse, finite or IR zero
is asserted. The 180-coordinate contraction represents the qualified leading
643-field reference for this coefficient; no auxiliary elimination occurs.

Formal reference widths remain distinct from vertex xi until each complete
family tensor is obtained. Exact unbounded multiquadratic/width arithmetic
retains all 45 ghost and antighost directions; no sampling or group/width
cutoff. Only then are real width_M=xi and width_H=eta_H bound. H-direction
zeros are obtained from the actual sum, independently of predicted zeros.
Both actual routes deny prediction and peer result reads after their initial
byte-only ancestor authentication. Authentication hashes prior results; it
does not interpret them as amplitudes or execute their mathematics.

All 12 homogeneous H tensor identities, coefficient reality and exact
physical/canonical dual-primal roundtrips hold. Wrong dual pairing and wrong
width binding have nonzero complete-tensor residuals. These checks do not
establish the complete local Ward system, nonlinear Slavnov restoration,
source/insertion contact normalization or quantum canonical equivalence.
The logarithm is selected above k_E^2>R_UV^2>0; all leading words have UV
degree -4. External momentum/mass remainders, cutoff-power poles and the
finite/IR amplitude remain distinct. No whole-scaleless inference is used.

All four original scientific execution attempts completed. Their preparations
own exact contract/source/input/state bytes, starts, complete outputs and
runtimes. The separate validation receipt records scientific, process and
governance tests, delegated e5 checks, four strict own-byte fresh executions,
41 protected predecessor chains and new/protected/state/size-mtime invariance.
Any failed validation attempt must remain explicit and excluded from PASS.
Historical custody must remain exit 2 with seven unresolved references;
it is not PASS. Old expensive loops and images are authenticated only.
Raw Git index/worktree equality is required before a local commit.

Provenance is complete for this bounded artifact; reproduction/derivation
agreement is established within scope, while the prospective candidate match
fails. Proof-assistant formalization is not attempted. The broader mechanism
and interpretation remain open; empirical connection is none. Both routes
share action/representation inputs, some arithmetic, Python/SymPy and analyst.
They are computational corroboration, not external scientific endorsement.
The local conventions, epistemic ladder and solo-review policy still apply.

The earlier auxiliary-source/ghost derivative match at a19b4b6 remains
qualified within its original scope. The present failure identifies a new
limit of the accumulated inactive normalization. project_state.json v113,
34/39 and its exact bytes remain the sole machine-readable authority.
No normalization adoption, catalog/physical activation, HB1/C5, finite C1_GS,
remote push, publication or outreach occurred. Full E5/A5, regulator/measure,
Ward/Slavnov/contact/IR, anomaly, global scalar/PQ, fermion/Yukawa,
phenomenology and the whole Spin(10) x global U(1)PQ investigation remain open.

Next smallest scientific action: separately freeze an assembly and dependency
audit of the measured one-loop pole functional, preserving this obstruction
and every earlier scope. Identify which Ward, Slavnov, source and insertion
relations are testable with measured partners, and which require new actual
amplitudes. The unmeasured g^2 longitudinal gauge/auxiliary mixing, no-jet
power/mass poles and higher companions must remain explicit unknowns.
Do not fit a new candidate to this residual or call a partial measured
functional the complete divergent functional.
