"""Complete indexed replacement fermion, graded execution and Euler variation."""
from a10_e1_fermion_common import *
from a10_bv_primary import GradedExecutor, contraction
from a10_executable_action import contract, numeric_table
from m08_local_functional_ast import add,mul,scalar,field,derivative,tensor,parameter

def ast():
    gp=parameter('g10');xp=parameter('xi');ep=parameter('eta_H')
    ub=lambda i:field('ub',indices=(i,),parity=1)
    light=lambda h:field('bar',indices=(h,),parity=1)
    node=lambda name,inds:tensor('RepresentationGenerator',name,inds)
    lc=lambda P:dict(contract(P,('mu',),'LorentzContraction'),parity=P.get('parity',0))
    terms=[
      ('heavy_divergence',lc(contraction(mul(ub('i'),derivative('mu',field('V',indices=('i','mu')))),('i',)))),
      ('heavy_connection',lc(contraction(mul(gp,ub('i'),node('f_mHm',('i','h','j')),
          field('BH',indices=('h','mu')),field('V',indices=('j','mu'))),('i','h','j')))),
      ('heavy_orbit',contraction(mul(scalar(-1),xp,gp,ub('i'),node('OrbitPullback',('i','A')),
          field('eta',indices=('A',))),('i','A'))),
      ('heavy_auxiliary',contraction(mul(scalar(s.Rational(-1,2)),xp,ub('i'),node('GM_inverse',('i','j')),
          field('L',indices=('j',))),('i','j'))),
      ('heavy_cubic',contraction(mul(scalar(s.Rational(1,2)),xp,node('dual_cubic',('i','j','k')),
          ub('i'),ub('j'),field('u',indices=('k',),parity=1)),('i','j','k'))),
      ('light_divergence',lc(contraction(mul(light('h'),node('GH',('h','k')),
          derivative('mu',field('qH',indices=('k','mu')))),('h','k')))),
      ('light_connection',lc(contraction(mul(gp,light('h'),node('GH',('h','k')),node('f_HHH',('k','a','b')),
          field('Abar',indices=('a','mu')),field('qH',indices=('b','mu'))),('h','k','a','b')))),
      ('light_auxiliary',contraction(mul(scalar(s.Rational(-1,2)),ep,light('h'),node('GH',('h','k')),
          field('b',indices=('k',))),('h','k')))]
    return [{'node':'LocalActionTerm','term_id':name,'density':P,'parity':1} for name,P in terms]

def build(stage=lambda n,f:f()):
    from a10_bv_integration_common import geometry
    f,rho,Q=stage('reuse_authenticated_Stage_D_geometry',geometry)
    chart=stage('typed_nonminimal_and_evaluation_source_charts',lambda:charts(Q))
    evidence=read(HERE/'frozen_a10_physical_reconciliation/full_primary.json')
    O=mat(evidence['vacuum']['orbit']);v=mat(evidence['vacuum']['VEV'])
    QM=Q[:,12:];GM=(QM.T*QM).applyfunc(clean);GH=(Q[:,:12].T*Q[:,:12]).applyfunc(clean)
    OM=(O*QM).applyfunc(clean);Orbit=(GM.inv()*OM.T).applyfunc(clean)
    assert (O.T*v).applyfunc(clean)==s.zeros(45,1)
    offset=0
    for sec,n in DIM.items():
        for h in H:assert (rho[sec][h]*v[offset:offset+n,0]).applyfunc(clean)==s.zeros(n,1)
        offset+=n
    cubic={}
    for (i,a,k),value in f.items():
        if i in M and a in M and k in M:
            for j in M:
                if GM.inv()[a-12,j-12]:cubic[i,j,k]=clean(cubic.get((i,j,k),0)+value*GM.inv()[a-12,j-12])
    cubic={key:value for key,value in cubic.items() if value}
    assert cubic,'ACTUAL_NONSYMMETRIC_COSET_NOT_EMPTY'
    w=alphabet();tables={};jets={}
    for name,prefix,ids in [('V','B',M),('BH','B',H),('Abar','A',H)]:
        tables[name]={(i,mu):w.var(f'{prefix}{i}_{mu}') for i in ids for mu in range(4)}
    tables['qH']={(h,mu):w.add(w.var(f'B{h}_{mu}'),w.scale(w.var(f'A{h}_{mu}'),-1)) for h in H for mu in range(4)}
    for name in ('V','qH'):
        jets[name,'mu']={(i,nu,mu):w.D(P,mu) for (i,nu),P in tables[name].items() for mu in range(4)}
    for name,prefix,ids in [('ub','ub',M),('L','L',M),('u','C',M),('bar','bar',H),('b','b',H)]:
        tables[name]={(i,):w.var(prefix+str(i)) for i in ids}
    tables['eta']={(a,):w.add(w.var(n),{():-v[a,0]} if v[a,0] else {}) for a,n in enumerate(scalar_names())}
    tables['GM_inverse']={(i+12,j+12):{():c} for (i,j),c in GM.inv().todok().items()}
    tables['GH']=numeric_table(w,GH)
    tables['OrbitPullback']={(i+12,a):{():c} for (i,a),c in Orbit.todok().items()}
    tables['dual_cubic']={key:{():value} for key,value in cubic.items()}
    tables['f_mHm']={key:{():value} for key,value in f.items() if key[0] in M and key[1] in H and key[2] in M}
    tables['f_HHH']={key:{():value} for key,value in f.items() if all(i in H for i in key)}
    tree=ast();executor=GradedExecutor(w,tables,jets=jets)
    def execute():
        result={}
        for term in tree:
            value=executor.eval(term);assert not value.labels
            result[term['term_id']]=canonical(value.rows.get((),{}))
            # The evaluated orbit has one unit of mass dimension carried by
            # the frozen vacuum coefficient, not by a polynomial generator.
            target=(2 if term['term_id']=='heavy_orbit' else 3,-1,1)
            assert w.grade(result[term['term_id']],target),('FERMION_GRADE',term['term_id'])
        return result
    parts=stage('all_eight_terms_graded_indexed_AST_execution',execute)
    PM=w.add(*(P for n,P in parts.items() if n.startswith('heavy')))
    PH=w.add(*(P for n,P in parts.items() if n.startswith('light')))
    P=w.add(PM,PH);names=list(w.fields)+[f'A{h}_{mu}' for h in H for mu in range(4)]
    el=stage('691_complete_left_Euler_covectors',lambda:euler_columns(P,w,names))
    variation=stage('full_first_variation_with_graded_variations_and_boundary',lambda:first_variation(P,el,w,names,'primary'))
    wards=ward(PM,PH,w,f,rho,stage,'primary')
    return finish('primary',chart,tree,parts,el,variation,wards,
      {'orbit_pullback':matrix_rows(Orbit),'normalized_parent_f_sha256':digest([[*k,str(v)] for k,v in sorted(f.items())]),
       'dual_cubic_coefficients':[[*k,str(v)] for k,v in sorted(cubic.items())],
       'shifted_vacuum_used':True,'H_vacuum_stabilizer_verified':12,'O_transpose_v_zero':True,
       'coefficient_mass_dimensions':{'OrbitPullback':1,'f':0,'Gram':0,'xi':0,'eta_H':0},
       'old_representation_calculations_repeated':False,'nonsymmetric_cubic_nonzero':True})
