# E1 typed fermion qualification — frozen calculation contract

This bounded investigation follows 95c0be0. It qualifies a separately named, inactive replacement, `M08_PHYSICAL_FRAME_GAUGE_FERMION_V1`, rather than assuming that historical nonminimal labels specify a coordinate chart. A4-V2/A5-V2 and the qualified Stage D action remain byte-frozen. The historical chart is not determined by the surviving contracts; equivalence to that chart cannot be asserted by fitting coefficients.

The replacement is derived in the real orthonormal physical plane with normalized Spin(10) generators, then pulled back through the authenticated Stage D embeddings. Heavy connections/ghosts embed through Q_M; heavy antighost and auxiliary fields through F_M=Q_M G_M^-1. Light nonminimal fields embed through Q_H. Their invariant pairings are respectively G_M^-1 and G_H. Evaluation-dual sources use inverse transposes, so their canonical pairing remains the identity. Conjugation is induced from the real physical plane. Ambient maps have projectors and kernels, not unrestricted inverses.

With B=Abar_H+q, V=P_M q, u=P_M C, eta=x-v and O_a=rho_a v, define in the physical plane

    Psi_M = <ubar, D[Abar_H+q_H]^mu V_mu - xi*g10*O^T eta>
            - xi <ubar,Lambda>/2 + alpha <ubar,[ubar,u]>/2,
    Psi_H = <cbar,D[Abar_H]^mu q_H,mu - eta_H*b_H/2>, alpha=xi.

All brackets use the same normalized generators as Stage D; no extra g10 or numerical multiplier is inferred from an unbound historical `f` leaf. Xi is the coefficient of the invariant heavy auxiliary width and alpha=xi is the declared cubic coefficient. Eta_H is the independent light auxiliary width. Both are real dimensionless gauge parameters. This preserves their named coefficient roles, but does not establish historical numerical equivalence where the old tensor/frame interpretation is unbound. The classification is a derived replacement, not a certified historical translation. Physical action parameters are unchanged.

The shifted vacuum and full nonsymmetric coset are preserved. Every term must be represented in the existing executable AST grammar and compared with a separately derived physical-plane expression. Arbitrary off-shell fields and first jets are used; no sample point, field equation, or zero-connection projection supplies a proof.

Applicable local Ward requirements are: heavy Psi_M is invariant under residual quantum H and background H; complete Psi_M+Psi_H is invariant under background H. Ordinary light gauge fixing intentionally breaks quantum H. Its nonzero local quantum variation is an expected control, not a requirement to erase. Parameters and their first/second spacetime jets must be independent. No 45-component background connection is allowed.

Complete left Euler covectors, including the external 48-component H background, must agree between indexed AST differentiation and physical-plane variation followed by cotangent pullback. The full first-variation identity must include the explicit boundary current and graded variations. Primal/dual embeddings, conjugation and source evaluation pairing must be checked, retaining the previous bare-pairing counterexample and rejecting unprojected physical witnesses.

Stop at the first required failed or underdefined identity. Historical equivalence remains explicitly unresolved and cannot be promoted by a replacement PASS. E2–E5, canonical gauge-fixing transport of the master action, source activation, catalogs, HB1/C5, C1_GS, formal authority changes and remote push are outside this authorization. A PASS permits only proposing E2. The solo-review policy applies; no outreach or external endorsement is required or claimed.
