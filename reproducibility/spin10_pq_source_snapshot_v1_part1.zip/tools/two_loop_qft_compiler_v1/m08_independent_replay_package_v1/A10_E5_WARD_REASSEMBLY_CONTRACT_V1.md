# Corrected measured local Ward reassembly, WR V1

Freeze before computation at878df087032fc77e1d5023b643c9868089f5c85b.
Previous goal turn PROGRESS: actualg^2xiJC-CC and selected measured Slavnov
left side qualified; inherited source metric error was identified and repaired
under GS V2. Statev113/34of39 remains sole scientific authority. No promotion.

WR1: recover the complete explicit13-sector dimension-four, ghost-zero, even
logarithmic measured density in common hbar/(32pi^2epsilon_UV) units. Primary
reads the qualifying GS comparison_v2 corrected sum; replay independently
sums the own qualified MF sector records, replaces the gauge-source sector
using the own actual source_vertex projection, and pulls back its own physical
JC-CC pole. Neither imports peer WR output. Exact units and all13 sectors are
required. Original MF/GS failed assemblies stay archived and excluded. Keep
scalar Hessian-square and regulated power/finite nodes separate and unknown
scope complements explicit. Do not call this the complete divergent functional.

Immutable inputs are44 sealed chains, actual E3 background Tb operator on all
1286 field/source columns and48 external background components, full real
primal/dual charts, ordinary jets, all12 even local H parameters, and corrected
measured loop records. No new actual loop, candidate calculation, fit, image,
normalizer adoption, source activation, auxiliary elimination or EOM quotient.

WR2: calculate the FULL local background-H variation of this explicit known
density, retaining parameter jets and BOTH total B_H and external A_H affine
connections. Primary uses prefix Leibniz; replay uses graded jet gradients.
Verify zero constant-parameter projection, complete ordinary parameter IBP
currents, all12 independent parameter Eulers, and canonical/physical frame
roundtrips with real physical parameters. Local jets remain independent; do
not replace them by constants or omit equal-color unequal-jet odd generators.
No finite index, coefficient, coupling or jet truncation outside this finite
declared density. Resource limits produce INCOMPLETE, not a zero or PASS.

WR3: compare every computed coefficient BEFORE dependent census/interpretation.
Enumerate the exact finite dimension-zero, d4/gh0/even local type patterns that
can feed each measured Ward target. Forward incidence and reverse predecessor
enumerations must agree. The affine image is available only for H connection
components; homogeneous variations carry one additional g10. Record both A_H
and B_H alternatives, known contributions WITH scopes, unmeasured coefficients
as None, and ordinary boundary input qualifications. This is a type census,
not an invariant coefficient basis or evidence that an allowed loop is nonzero.

Compare the old MF V3 Ward result only AFTER the two corrected derivations
agree. Its complete difference must equal Tb acting on the exact inherited
gauge-source sign error; the new no-jet JC pole must have zero local H Ward
variation, proved independently rather than discarded. No fitted completion.

Answer which actual partner amplitudes remain necessary for the corrected
known local Ward system, with the smallest next actual graph question. A
nonzero known parameter Euler is an open obligation, not a full breaking or
anomaly: W_b(Gamma_known+Gamma_unknown)=Delta_b, with Delta_b/Gamma_unknown,
insertion/contact/measure/IR scopes unbound. Preserve priorg^3candidateFAIL
and the selected GS Slavnov left-side qualification; neither is reopened.

Negative controls require exact nonzero discrepancies or type rejection:
drop A_H or B_H affine action, parameter jets or currents; insert the old JB
metric sign; wrong source parity/primal pairing/coupling degree; bind unknown
partners to zero; conflate identical-color ghosts at different jets. Preserve
all starts/sources/full stdout and failed/unfinished attempts. First discrepancy
stops interpretation before any coefficient adjustment or new actual loop.

Validation: four own-byte fresh controls/primary/replay/comparison, meaningful
science/process/governance/delegatede5,44 protected chains, new/protected/state
and metadata invariance, custodyexit2/sevenrefs neverPASS, rawindex/worktree
equality before localcommit. Old expensive scientific loops/images authenticate
only. Full E5/A1-A5/W1-W7/quantum equivalence, HB1/C5, finiteC1_GS, scalarPQ,
fermionYukawa/pheno and whole investigation remain open. Shared inputs,
operators, some arithmetic, Python/SymPy and analyst disclosed; no agents or
external endorsement. No reset/evidence editing/unrelated termination,
authority promotion, push/publication/outreach or whole-goal completion.
