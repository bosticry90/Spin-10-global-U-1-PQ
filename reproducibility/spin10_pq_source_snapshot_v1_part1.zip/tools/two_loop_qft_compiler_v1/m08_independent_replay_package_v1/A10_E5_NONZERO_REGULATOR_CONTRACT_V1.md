# E5 nonzero-g regulator-extension test, V1

1. **Question.** Can the preceding fractional action kernel be extended to
   nonzero g as an actual UV prescription, with the admitted BV/background
   identities and unchanged affine g=0 source limit?
2. **Scope and stop.** Derive the free-only kernel's local gauge defect, a
   covariant full-action candidate and its exact functional covariance, then
   test one-loop regulation in the ACTUAL scalar representations. Stop this
   extension at its first failed regulation requirement. A proper-time scalar
   determinant and direct dimensional diagrams may serve as independent
   controls, not replacement of the complete quantum target by a selected loop.
3. **Inputs.** Clean 760cb4c, v113/34 of 39 and 23 sealed chains. All 643 pairs,
   48 H backgrounds, full potential, scalar embeddings and nonsymmetric/R_H
   ghost columns remain. Sources/auxiliaries are not eliminated. Reuse accepted
   representation, master, cotangent and invariant-basis results.
4. **Types.** Total B is the 45-generator connection, background A remains
   twelve-generator H. Four real scalar sectors have dimensions 54,252,20,2.
   The free multiplier P=((p_E^2+m_reg^2)/mu_reg^2)^alpha has alpha=e_reg/2.
   Temporary spectral variables, proper time, Euclidean reference masses and
   formal odd BRST test parameter belong outside the local cochain ring.
   Physical coefficients remain arbitrary; no inverse g, width or mass in
   local counterterms. PQ remains global, without a new gauge source.
5. **Covariant candidate.** Use the positive-reference operators
   K_r=-D_B,r^2+m_reg^2 and P_r=(K_r/mu_reg^2)^alpha, with actual scalar and
   adjoint representations. Replace gauge kinetics by F P_ad F. For scalars
   specify x^T L_r P_r x/2, L_r=-D_B,r^2; this reproduces the preceding free
   multiplier and the physical kinetic term at alpha=0. It is NOT the different
   ordering (Dx)^T P_r Dx. Retain the full potential and source action. Extend
   E1's heavy/light divergence parts using covariant kernels: heavy D[H_total],
   light D[background_H]; widths/cubic terms are unchanged. This must reduce to
   the preceding full free kernel at g=0. Derive nonlocal variational kernels
   explicitly, including delta P via its resolvent formula and full coset
   variations of H_total, never an H-only BRST substitute. This is
   an inactive regulator candidate, not an edit or activation of Stage D/E1/E2.
6. **Gauge/BRST checks.** Verify QK=[M,K], QP=[M,P], QM=M^2, Q^2P=0 and
   invariant kinetic pairings, with M=-g rho(C). Distinguish classical
   functional covariance from UV regulation and quantum anomaly freedom.
   The formal full 643-field Berezin divergence must be calculated with graded
   derivatives; its vanishing alone proves no continuum measure theorem.
7. **Decisive loop.** Compare all 8,100 scalar generator trace-pair entries
   (four sectors,45 by45), using canonical matrices versus physical tensor
   representation traces. Include the self-dual five-form's real-coordinate
   multiplicity. Derive the scalar two-gauge-leg bubble and seagull first,
   retain mass and local-parameter terms, and compare heat-kernel and direct
   diagram poles. Do not infer full beta functions or C1_GS from this subset.
8. **Negative controls.** Constant-parameter-only tests; omitted connection
   variation or seagull; wrong complex/self-dual multiplicity; wrong metric or
   Wick sign; equating a covariant propagator improvement with convergence of
   its complete determinant; replacing Q by background H; dropping sources,
   potential or nonsymmetric ghosts; treating zero formal divergence as proof
   of quantum anomaly freedom.
9. **Independent routes.** Primary canonical generator traces and covariant
   heat-kernel functional variation. Replay physical vector/symmetric/wedge
   tensors, direct dimensional Feynman parameterization and independent
   spectral-eigenvalue arithmetic. Shared inputs/chart/word/Python/SymPy and
   analyst are disclosed. Literature supports methods, not external approval.
10. **Output.** Exact defect/witness, typed inactive candidate, actual scalar
    pole and finite transverse control, independent evidence and bounded
    classification. If action covariantization fails to regulate, preserve
    that result and stop dependent whole-prescription claims. A scalar
    proper-time cutoff is not a full retained-source gauge/ghost regulator.
11. **Validation.** Start raw hashes before calculation, immutable completed
    route files, expected negative controls, exact comparisons, fresh own-byte
    replay, predecessor/state/protected/metadata checks and custody exit2/seven.
    Validate before local commit; no remote push or authority promotion.
12. **Ceiling.** Not full M2/M3/A1--A5, E5, physical IR or full anomaly
    qualification, general insertion/contact/A5 equivalence, catalog/HB1/C5,
    matching or phenomenology. The full Spin(10) x U(1)PQ objective remains.
