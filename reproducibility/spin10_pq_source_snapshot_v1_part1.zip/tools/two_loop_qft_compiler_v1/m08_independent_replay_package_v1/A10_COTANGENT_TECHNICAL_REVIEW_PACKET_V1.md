# Scalar cotangent adapter solo technical review packet V1

This packet applies [solo policy V1](../../../docs/SOLO_REVIEW_POLICY_V1.md).
It supersedes the scalar-derivative prerequisite in the prior executable
packet as a current result, without rewriting that sealed packet. No reviewer,
outreach draft, contact channel or personnel gate is pending. Technical
objections still require exact evidence.

Inputs and result: [contract](A10_COTANGENT_ADAPTER_CONTRACT_V1.md),
[result](A10_COTANGENT_ADAPTER_RESULT.md),
[primary](frozen_a10_cotangent_adapter/primary.json),
[replay](frozen_a10_cotangent_adapter/replay.json),
[source composition](frozen_a10_cotangent_adapter/source_composition.json).

Challenge the following before any complete master-action promotion:

1. Ordered covectors use a signed permutation sum, while `120*W(I)` requires
   prior antisymmetry. Conjugate aliases are varied independently before the
   real pullback. Verify the imaginary-component sign and the constrained
   cotangent quotient, rather than claiming a full ambient inverse.
2. Phi and Sigma have G=I; phi and S have G=2I. A covector uses E^T; the old
   E^T G bridge remains valid on G^-1 times that covector. Confirm that no
   normalization factor is applied twice.
3. The potential oracle is a universal factorized derivative of F(Jx), not a
   dense expansion. All 29 directions, 34 independent real parameters, seven
   aliases per direction and the full ordered J must remain linked. Challenge
   the binder/dummy normalization and the arbitrary-variation polynomial
   identities; selected field values are insufficient.
4. For kinetic Euler terms, retain ordinary connection derivatives and both
   cross terms; distinguish IBP boundary contributions from EOM quotients.
   Verify the scalar singlet and the shifted vacuum without varying v.
5. Source coordinates use the qualified Q=(S,.) left convention. The physical
   source column is +Euler_x, with actual K_phi source frame and induced
   bracket. A complete master candidate must add and differentiate all source
   terms coherently; this adapter does not establish their closure.
6. Continue distinguishing all-45 quantum physical symmetry from the frozen
   H-only background carrier and its 12 generators. No Stage E or joint-domain
   transport conclusion follows from the scalar cotangent calculation.

Published comparison is confined to foundations. Gomis, Paris and Samuel,
[Antibracket, Antifields and Gauge-Theory Quantization](https://arxiv.org/pdf/hep-th/9412228),
section 4.2 and appendix A, give the field/antifield bracket and left/right
derivative conventions. They support requiring an explicit convention, not
equating differently represented gradients. Our repository's source-left
convention and its sign control are declared separately.

Barnich, Brandt and Henneaux,
[Local BRST cohomology in gauge theories](https://arxiv.org/pdf/hep-th/0002245),
section 4.4, theorem 4.1, relates local total divergences to vanishing Euler
derivatives in its stated local-function setting. Here the kinetic IBP current
is displayed and the historical nonzero ghost Euler witness remains bound.

Neither publication independently certifies these Spin(10) tensors, source
frames or implementation. No claimed physical prediction or quantum result
follows from their comparison. The analyst, shared runtime, libraries, input
representations and factorized nature of the proofs remain limitations.
