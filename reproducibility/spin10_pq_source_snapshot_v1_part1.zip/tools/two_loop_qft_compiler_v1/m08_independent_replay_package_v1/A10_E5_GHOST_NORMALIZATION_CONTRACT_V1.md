# E5 interacting g=0 quantum-normalization test

1. **Question.** Can an explicit source-independent regulator and subtraction
   treat the actual surviving heavy auxiliary/ghost interaction while preserving
   the g=0 affine source identities, background Ward and BRST requirements? Is
   the literal one-width heavy fermion sufficient for its ultraviolet pole?
2. **Claim under test.** Construct a four-dimensional spectral analytic
   regulator commuting with ordinary derivatives and the ACTUAL linear Q0.
   Derive the complete heavy ghost determinant's ultraviolet quadratic
   auxiliary metric by distinct routes. Derive a local BRST-exact subtraction,
   selected local probe/contact normalization, and exact source dependence.
   Check admissibility limits against M1--M6 of the supplied latest assessment.
3. **Ceiling.** A concrete regulated g=0 construction and complete ghost-sector
   pole/subtraction, not full A1--A5, all-order anomaly freedom at g!=0, general
   insertion/contact equivalence, full scalar subtraction closure, or E5 PASS.
   A counterterm outside a literal parameter family is recorded, not silently
   adopted. A precise underdefinition/stop is an allowed scientific result.
4. **Inputs/types.** Clean ab2b63a, state v113/34 of 39; 21 sealed predecessor
   chains. All 643 pairs/48 backgrounds remain, four Lorentz coordinates,
   328 scalar fields, 29 potential directions, actual nonsymmetric coset,
   composite curvature, source-left left-derivative conventions. g=0 is the
   formal specialization; physical benchmark parameters are unchanged. Width
   xi and eta_H are not set to zero or fitted. No inverse physical parameters.
5. **Actual interaction.** Use the sealed 276-coefficient residual, not an
   assumed Gaussian action. Reconstruct its entire ghost operator independently
   from physical matrices. Ghost integration may be Gaussian for a FIXED
   auxiliary background; the full integrated action remains interacting.
6. **Regulator.** On Euclidean Fourier modes let P_e(p)=
   ((p^2+m_reg^2)/mu_reg^2)^(e/2), mu_reg,m_reg>0. Multiply free curvature and
   scalar kinetic terms by P_e; replace only the linear divergence fermions
   by P_e times their divergence, retaining cubic/width/orbit terms at g=0.
   A source-independent scalar IR regulator may be used as a temporary formal
   Gaussian reference, without changing the physical potential. At finite
   spectral cutoff the regulated functional is a finite graded formal
   perturbation, not a convergent measure or a new physical action. e,m are
   regulator variables outside the local cochain ring. Do not feed nonlocal
   P_e to an adapter qualified only for the local physical grammar.
7. **Primary.** Extract the literal heavy ghost matrix A(Lambda), perform
   signed Wick/finite-Berezin controls, and compute -tr A_i A_j. Derive the
   logarithmic residue from the four-dimensional regulated radial integral,
   keeping external auxiliary momenta nonexceptional to separate IR from UV.
8. **Replay.** Physical 10-by-10 commutators and real heavy/H projectors
   reconstruct A and its trace metric. Independently use the full adjoint
   Casimir minus twice the H Casimir and the dimensionally continued bubble
   residue. Dimensional integration is a scalar-loop cross-check, not an
   invented d-dimensional canonical alphabet. Compare every metric coefficient.
9. **Falsifiers.** Omitted xi vertex, incorrect closed-ghost-loop sign,
   scaleless zero-momentum UV/IR cancellation, symmetric-coset assumption,
   bare versus inverse Gram confusion, uniform width fitting, ungraded probe
   differentiation, or claiming finite-regulator symmetry proves full quantum
   restoration. Preserve failed/unfinished starts and first exact witnesses.
10. **Completion/stop.** Require exact matrix, residue, Ward/BRST, affine-source
    and selected probe/contact checks. Identify whether the pole is proportional
    to the old width metric. Keep the original fermion immutable. Stop global
    M2 acceptance if scalar/IR/restoration or unphysical normalization admission
    remains underdefined; continue safe independent bounded checks.
11. **Interpretation.** New unphysical BRST-exact width structure may require
    a declared gauge-fermion normalization rather than a new physical coupling.
    Do not infer quantum admissibility or equivalence of the named torsion F
    from a single pole calculation. Linearized cocycles, ordinary counterterms,
    operator insertions and source/contact finite normalization remain distinct.
12. **Evidence.** Read-only primary/replay start hashes, complete coefficient
    comparisons, negative controls, explicit structural proofs and literature
    comparison, fresh byte-identical regeneration, predecessor/protected/state
    audits, custody exit 2/seven, solo-review disclosure and validated local
    commit. No activation, source removal, auxiliary elimination, catalog/HB1/C5,
    C1_GS, matching, publication, contact, remote push or authority promotion.

This increment addresses the decisive missing quantum-construction evidence;
it does not redefine Spin(10) x U(1)PQ completion as a ghost-loop diagnostic.
