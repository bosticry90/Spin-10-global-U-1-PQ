# Full M08 source convention impact result

The coherent left convention fixes the two previously isolated light-source
defects, but **it does not by itself repair the full M08 source operation**.
Complete candidate expressions for all 17 roles have been reconstructed. The
first small nonminimal/source consistency test then fails, even at zero gauge
coupling. No replacement is promoted and HB1/C5 remain unauthorized.

The localized diagnostic blocker is
`M08_C5_COHERENT_SOURCE_CONVENTION_NONMINIMAL_PAIRING_NOT_CLOSED`.
This supplements, rather than edits, the historical obstructions. The formal
sequence blocker in `project_state.json` and scientific authority `34/39` are
unchanged. This is a source-formalism result, not a rejection of Spin(10).

## The exact new obstruction

The unchanged heavy gauge-fixing action contains the quadratic sector

```
S_free = integral [-ubar_i box(u_i) - Lambda_i partial_mu V_i^mu
                   + (xi/2) Lambda_i Lambda_i].
```

This is the quadratic heavy sector at `g10=0`, not the claim that the complete
action becomes quadratic. The heavy projector is the identity on its physical
image. Replay checks this with the exact split-coordinate inverse, not a
Euclidean transpose. Its selected heavy coordinate `0` has raw norm `5` but
evaluation-dual pairing `1` and commutes with all twelve residual-H generators.

The unchanged forward rules in this sector are

```
Q V_i^mu = partial^mu u_i,   Q u_i = 0,
Q ubar_i = -Lambda_i,        Q Lambda_i = 0.
```

The proposed coherent six-pair bracket derives, rather than assigns,

```
Q K_Lambda,i = delta_left Sigma / delta Lambda_i
             = -partial_mu V_i^mu + xi Lambda_i + higher terms.
Q^2 K_Lambda,i |_box(u),g10^0 = -box(u_i) != 0.
```

The primary route differentiates the complete unchanged action first, then
extracts this coefficient. Source-dependent terms in this reverse image carry
`g10`; other `g10^0` terms have higher field degree and cannot cancel the
degree-one second-derivative ghost coefficient. No image is truncated to make
a closure claim. A separately coded ordered-word/formal-variation replay
extracts the same free action directly from the frozen AST and obtains the
same coefficient `-1`.

There is also a scalar test polynomial

```
F = integral K_Lambda,0 Lambda_0,
Q^2 F |_(g10^0,Lambda_0 box(u_0)) = -integral Lambda_0 box(u_0) != 0.
```

It has `(d,gh,w)=(3,-1,4)` and its square has `(5,+1,4)`. The selected
physical components are H singlets. They are horizontal under the minimal
candidate contraction: `iota K_Lambda=0` by its grades, and `iota Lambda_0=0`
follows from the proposed Cartan identity on `ubar_0`. There is only one odd
source occurrence, so statistics do not kill it. Its square is not a total
derivative: its Euler derivative with respect to `Lambda_0` is `-box(u_0)`.
No EOM identification is used. This is a bounded polynomial/domain test, not
the construction or counting of any H-basic cochain space.

The square is neither zero nor a residual-H action on this singlet pairing.
Thus appealing to equivariant rather than ordinary nilpotence does not remove
this tested defect. Excluding the pairing would require an explicitly
different relative/source-domain contract; it is not an automatic repair of
the candidate reviewed here.

## Why the ST cancellation is insufficient

The free action still satisfies `Q S_free=0`. Its integrated half-master/ST
expression also vanishes:

```
(Sigma,Sigma)_src/2 -> integral (partial Lambda)(partial u)
                       = -integral Lambda box(u),
T Sigma               -> +integral Lambda box(u).
```

Here `T ubar=-Lambda` is the noncanonical part of the frozen ST specification.
The problem is that `Lambda` is also a canonical field paired with
`K_Lambda`. Consequently T is not a derivation of that six-pair antibracket:

```
T(ubar,K_Lambda)_src = 0,
(T ubar,K_Lambda)_src + (ubar,T K_Lambda)_src = -1.
```

The derivation residual is exactly `+1`. The standard implication from a
master identity to a square-zero Hamiltonian differential therefore cannot
be applied to this mixed canonical/noncanonical construction without further
hypotheses. The new zero ST control and nonzero square are compatible; neither
changes the immutable historical ST certificate on its original named domain.

The ordinary full BV construction treats nonminimal fields and their
antifields coherently. Its master and derivative conventions are described by
[Gomis, Paris and Samuel, sections 4 and 6 and appendix A](https://arxiv.org/pdf/hep-th/9412228).
The partial-gauge Cartan/Weil doublets are described by
[Ferrari, section 3](https://arxiv.org/html/1308.6802v3).
Those theorems do not certify M08's particular six-source truncation. The
previous 48-generator comparator included its nonminimal antifields; that
assumption must not be transferred silently to the smaller M08 source system.

## Complete candidate derivation and impact

The [contract](SOURCE_CONVENTION_IMPACT_CONTRACT_V1.md) fixes the source-left
bracket, left Leibniz rule, reverse left variation, composite chain rule and
off-shell nonminimal extension before the comparison. The
[primary evidence](frozen_source_convention_impact/primary.json) contains every
candidate row, the 328-real constrained scalar gradient construction and the
exact failed preflight. These expressions are diagnostic and inactive.

Six paired forward images and all six reverse images are rederived from the
unchanged action. The unpaired background/antighost/auxiliary rules come from
the explicit frozen ST specification, not fictitious missing antifields.
The heavy antighost expression is recovered from the actual gauge-fixing
action, and `Q R_H` is rederived by applying the graded product rule to its
composite. The action alone does not uniquely specify the unpaired rules.

| Roles | Impact within this bounded reconstruction |
|---|---|
| `V_H`, `q_L`, background, scalar, `u_H`, `Lambda_H`, `c_L`, `cbar_L`, `lambda_L` | Nine candidate ASTs are syntactically identical to the frozen images. |
| `ubar_H` | Same expression after dummy-index renaming; the ordered tensor comparison passes. |
| `R_H` | Derived from `u_H`, not independently varied. The expanded candidate retains the qualified composite definition; no new global identity qualification is claimed. |
| `K_V`, `K_q`, `K_Lambda` | Recomputed even-field derivatives expose additional parity errors in the historical indexed visitor, beyond the odd-source orientation mismatch. |
| `L_u`, `L_c` | Recomputed with left rather than positive right field derivatives. `L_u` also includes the previously omitted chain through composite R, including its `L_c` source contribution. |
| `K_phi` | New factorized serialization, same 71 potential-gradient templates and same ordered eta-gradient terms. The original constrained `E_dagger G` dual and 328 kinetic coordinates are retained. |

The old indexed product visitor uses crossed-factor parity without multiplying
it by the target parity. An even field between two odd factors gives the
opposite derivative from ordinary formal variation. The new visitor uses
`(-1)^(p_target * p_crossed)` in its own code path. It does not patch the old
engine or frozen evidence. Raw AST differences caused by dummy names or an
undistributed pair of minus signs are not classified as physical changes.

The initial test wording named a derivative-free heavy term and Lorentz trace.
Inspection localized the decisive test instead to the quadratic ordinary-jet
sector above. This is a disclosed test-domain refinement, not a successful
preregistered derivative-free test. No new derivative or Lorentz convention
was introduced. A regression initially demanded literal equality of scalar
gradient ASTs; it failed on dummy names and undistributed signs. The retained
comparison distributes scalars/sums and renames dummy indices, without
permuting factors or invoking new tensor identities.

## Acceptance disposition

| Gate | Result |
|---|---|
| Coherent convention fixed before comparison | Complete as a diagnostic candidate contract. |
| Complete 17-row candidate expressions | Materialized in factorized form, not promoted as qualified replacement images. |
| First nonminimal/source square test | **FAIL**, exact `-box(u_0)`, independently replayed. |
| Free action and integrated ST regression | PASS only in the explicit finite sector. |
| Complete M08 master/ST, all squares, Cartan identities and basic-domain/descent proof | **NOT REACHED** after the failed prerequisite. |
| External specialist semantic review | **NOT PERFORMED**; no person was contacted and no external endorsement is claimed. |
| Replacement, HB1, C5 or new catalogs | **NOT AUTHORIZED / NOT EXECUTED**. |

The prior `-2i`, `+1` and Sigma-nonhorizontal witnesses remain byte-unchanged.
The previous candidate's success on its two isolated coefficients and 66
source-self blocks is retained; it was not a complete-source success.
No source coefficient, frozen sign, field, parameter or action was changed.

## Independent replay and validation

[Replay evidence](frozen_source_convention_impact/replay.json) uses a separately
coded ordered-word algebra and formal variation, plus direct physical SO(10)
matrices for the selected singlet/projector check. It imports neither the
primary visitor nor its candidate coefficients. Algorithm and code-path
independence hold for this bounded test; Python, SymPy and physical inputs are
shared. No independent runtime, library, external expertise or full-M08 replay
is claimed.

[Byte bindings](frozen_source_convention_impact/bindings.json) and the
[validation receipt](frozen_source_convention_impact/validation_receipt.json)
record bounded regeneration, regressions, authority/map/read-only checks and
before/after audit inventories. An evidence-audit PASS authenticates this
**failed candidate**, not M08. Existing JCAT/T5 verification authority is reused;
neither catalog is rebuilt. There is no new repository-wide validation claim,
and no current or historical pole/projection payload is read. The strict
historical-custody audit remains unresolved with exit `2`; no new custody
search, historical hash substitution or historical rewrite is performed.

The recorded bounded runs pass 17 new regressions and 29 previous regressions,
the new evidence audit, the previous source-convention audit, and the four
read-only/map/authority/candidate-specification audits. Both measured evidence
audits observe zero workspace/active-data file mutations across 126,944 files.
The full candidate reconstruction/preflight takes 32.08 seconds wall and
31.89 seconds CPU in the measured audit, with a process peak of 162,230,272
bytes; the separate component replay takes 0.19 seconds. These are stage
measurements, not a parse/I/O attribution or a general performance claim.

## Next scientific decision

The next specialist review should examine the *nonminimal/source organization*,
not just the light-ghost sign. Its minimal review package is the six canonical
pairs, `T ubar=-Lambda+...`, the unchanged source term for `Q Lambda`, and the
three exact equations for `Q K_Lambda`, `Q^2 K_Lambda` and the bracket-derivation
defect above. A coherent full nonminimal BV lift, a justified raw-doublet
coordinate/source organization or an explicitly defined relative domain are
possible future research questions, not earned repairs or authorized changes.

Any proposal must first solve this free singlet sector and then preserve the
two earlier source controls before another large construction begins. No
source partner or new operator catalog is implemented here. Catalog authority,
the weight bound, formal `34/39`, blocked M08 attempt 1, unauthorized attempt 2
and Layer 6, and null `finite_C1_GS` remain unchanged.
