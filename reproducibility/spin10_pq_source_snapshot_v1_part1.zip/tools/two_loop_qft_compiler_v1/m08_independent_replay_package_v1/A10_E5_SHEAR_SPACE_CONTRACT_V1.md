# E5 complete equivariant auxiliary-shear space and companion equations

Prospective contract, baseline e053cc10b486b395a85fe4619939a5e792a71d86,
state v113, 34/39, 33 sealed predecessor manifests. The previous goal turn
made progress: further source-free heavy repair is obstructed with measured
width/cubic projections fixed, and a correctly typed classical shear has
qualified companions. Preserve the unlowered H failure, grading diagnostic,
actual quartic discrepancy and every earlier failed/unfinished execution.

## Question and domain

SS1: What is the entire real local H-equivariant tensor space of
Jauxiliary-antighost-ghost generators, with both nonminimal sectors retained?
SS2: What are its complete classical Q image and mandatory companion maps?
SS3: Does its independently constructed quartet image contain the preserved
actual-minus-K0-minus-Kjoint-minus-K3 residual, including every zero slot?
Membership is an algebraic classification, not acceptance of a subtraction,
quantum canonical equivalence, an actual new amplitude, or E5/unification.

Use all 45 auxiliaries (12 light b, 33 heavy Lambda), all 45 antighosts
(12 light bar, 33 heavy ubar) and 45 ghosts. The raw tensor domain has
45^3 = 91,125 slots. Fields/sources use their qualified primal/evaluation-dual
carriers, never an identity identification of two primal vectors. Keep all
643 canonical pairs, 48 external H backgrounds, source-left Q, real structure,
ordinary symmetric jets, both width parameters, nonsymmetric coset and R_H.

Each tensor defines K = sqrt(2) g^2 xi Jaux^T T(a,C), of grade (3,-1,odd).
The common nonzero sqrt(2) is a basis normalization, not a fitted coefficient
or altered coupling. Its coefficient space is the real invariant space;
calculation uses exact Gaussian-rational/algebraic numbers, never floating rank.
The basis is independent of the quartet residual. No inverse physical coupling,
inverse mass, EFT term, new physical parameter or canonical variable is allowed.
This class is not the entire space of all canonical or nontrivial counterterms.

Inputs are the transitive manifest
`frozen_a10_e5_normalization_types/bindings.json`, existing E1/E2/E3 geometry,
action and typed coefficient dimensions, and (only after space/image agreement)
the sealed completed actual primary_v3/replay_v2 quartet and cubic prediction.
Freeze own code/contract/state/input hashes and separate output ownership before
execution. No new loops, especially JC-C-C/JB-B-C, under this contract.

## Required evidence before residual access

1. Primary extracts complete field/evaluation-source H matrices from E3.
   Establish a full rank-four Cartan, exact weight-zero reduction of all
   91,125 tensor slots and all twelve covariance constraints, including rows
   outside the weight-zero input support. Exact RREF gives a complex kernel.
   Realify with the qualified conjugations and prove full real dimension and
   basis rank; authenticate raw/physical dual/primal maps. Keep all four
   light/heavy auxiliary-antighost sectors and all ghost directions.
2. Replay independently derives normalized physical10 commutators and H
   actions, transports them with the inherited frame, and uses a distinct
   exact sparse elimination. Its complete canonical kernel agrees. Independently
   compute the invariant multiplicity by the Weyl constant-term formula from
   its full representation character. Derive roots/reflections/Weyl group,
   check character invariance and the center's weight-zero constraint. Agreement
   in dimension plus all exact covariance identities proves completeness;
   do not infer a heavy projected Jacobi identity or a symmetric coset.
3. For every real basis generator retain its complete classical Q image.
   Primary graded prefix application and replay complete-density left
   Euler/first-variation agree, with exact currents if required. Treat the
   fixed numerical OrbitPullback as coefficient dimension one and preserve
   its precisely reconstructed image, not a blanket word-grading exception.
   Record all source/field/coupling/jet types, including eta_H companions.
   Prove preservation of prior measured projections at their coupling degrees.
4. Derive the quartet map from the literal two-odd auxiliary Euler column
   independently in both routes. Retain all 980,100 physical odd-pair slots,
   including light/mixed zeros and any mixed-antighost output. Compute its exact
   rank/kernel. Derive the source, derivative-gauge and auxiliary-cubic maps.
   Prove the latter companions are injective for the full generator tensor,
   using the actual nonsingular heavy/light width metrics as formal polynomial
   coefficient maps, without inverse width factors in a generator.
5. Generalize the preceding canonical/real/H/jet prerequisites to the full
   basis: both inverse directions, all 1,286 generator columns, complete
   elementary brackets, nonlinear jets and triangular integrated-field
   Berezinian one. Explain why composite expectations, source/observable
   insertions/contacts, the preceding joint measure contribution and quantum
   A5/Ward/restoration remain unresolved. Classical canonicality and a unit
   Jacobian cannot supply those missing quantum calculations.

Completed space/image outputs are compared before a dependent membership
worker can read the actual quartet. Calculations remain read-only under the
established pole-blind guard. Sequential execution is sufficient; no agents
or duplicate workers. Resource limits report INCOMPLETE, never truncate a
space, coefficient or evidence obligation to manufacture completion.

## Dependent membership and first failure

Only after required space/image identities pass: construct the complete actual
residual from the two qualified actual methods and the frozen prediction.
Check the actual methods agree, canonical/physical transport roundtrips,
real structure and all 980,100 comparison slots. Solve the complete linear
image membership problem in the already constructed real basis. Do not select
a convenient tensor subset after seeing the mismatch or adjust physical data.

If membership fails, preserve an exact image-annihilating linear functional
whose value on the residual is nonzero, a real off-shell witness with independent
Euler variation, and the full residual. Stop there; no dependent normalization
fit, further source-type extension or new loops in this increment.
If membership holds, preserve the full affine coefficient solution (a declared
particular solution and entire kernel), its reality and all required companion
equations. A free coefficient is not a chosen subtraction. No candidate is
adopted and no new companion is presumed to equal its actual loop amplitude.
The next actual-amplitude contract must specify all remaining quantum obligations.

Stop on the first necessary failed covariance, reality, rank, image, pairing,
grade or comparison identity. Preserve full exact failure/source/start bytes.
Possible dispositions are a bounded full-space/image classification with
conditional membership, an exact class obstruction, underdefinition or
incomplete execution. None replaces the preceding failed normalization.

## Controls, validation and authority

Controls remove a root constraint, omit light/ghost-H sectors, confuse
primal/dual or conjugation, reverse an odd/source sign, omit mandatory
source/width/derivative/orbit companions or nonlinear jets, corrupt the
quartet map, or promote image membership to quantum restoration. Count a
negative control only with a nonzero exact residual or explicitly rejected
inference. The earlier unlowered shear is preserved as a wrong-carrier witness.

Before local commit: validate targeted scientific/process/governance checks,
fresh strict own-byte primary/replay outputs and dependent membership,
33 predecessor chains, protected/new/state SHA and audit-time size/mtime
inventory. Authenticate expensive qualified loops without rerunning them.
Use the existing `python -B tools/research_check.py e5` delegate; custody must
remain exit 2 with seven unresolved references, never PASS. Compare staged
raw bytes with worktree bytes. Preserve every failed or unfinished attempt.

Shared immutable inputs, exact/graded arithmetic, Python/SymPy and analyst
remain disclosed under solo review; no independent-scientist endorsement or
proof-kernel certification. No activation, auxiliary/source elimination,
physical/catalog/HB1/C5/C1_GS/matching, state promotion, outreach/publication
or push. The full Spin(10) x global U(1)PQ goal remains active/incomplete,
including full quantum, scalar/PQ, fermion/Yukawa and phenomenology work.
