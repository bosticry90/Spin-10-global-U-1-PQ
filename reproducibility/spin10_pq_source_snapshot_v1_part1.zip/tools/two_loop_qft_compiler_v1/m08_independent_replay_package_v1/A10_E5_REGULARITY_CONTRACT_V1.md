# E5: actual-model regularity and Noether resolution, V1

1. **Question.** Does the qualified, ungauge-fixed 34-term gauge/scalar action
   admit a complete polynomial Noether/Koszul-Tate resolution in ordinary jets?
2. **Smallest claim.** Exhibit an invertible triangular equation/jet chart at
   every finite jet order, its complete 45-generator identity module, and a
   positive-antifield-number contraction. Check normality of this action and
   reconcile its nonminimal sector by an explicitly typed canonical chart.
3. **Ceiling.** An inactive mathematical prerequisite, not full E5, an intrinsic
   versus induced basic quotient theorem, quantum restoration, or unification.
   The director's completion goal remains larger than this increment.
4. **Inputs/types.** Clean baseline 321a33e; source state v113, 34/39. Bind the
   sealed D/E1-E4, E5 closure/quotient, theorem-stop and conditional W1-W7 chains.
   Use independent lower-index plane gauge coordinates B_mu^a (180), canonical
   real scalars x (328), all 45 ghosts and 90 nonminimal fields. Parent C3
   coordinates are related by the qualified constant Q and evaluation-dual
   source map. Keep 48 external backgrounds as spectators; no new source pairs.
   Polynomial coefficients include the existing physical parameters and exact
   algebraic constants in characteristic zero; no inverse physical coupling,
   inverse field, inverse mass, or field-dependent localization. Ordinary
   symmetric jets have finite support, with no fixed maximum in the theorem.
   PQ is global, with charges Phi=0, Sigma=2, phi=-2, S=-4; it is not a 46th
   local gauge generator. The scalar vacuum shift is constant.
5. **Comparator.** [Barnich, Brandt and Henneaux, sections 5 and 6.4.3](https://arxiv.org/html/hep-th/0002245).
   Their general argument is a comparator; actual action structure, complete
   identities, polynomiality and admitted domain must be justified here.
6. **Primary.** Extract the highest-jet operator from the literal executable
   action with the qualified Lorentz adapter; authenticate the all-sector
   scalar kinetic certificates. Construct a triangular jet chart and Noether
   reduction, with an all-order induction written explicitly. Reuse qualified
   Noether identities instead of repeating expensive full representation work.
7. **Replay.** Independently vary the free first-jet density; derive its Euler
   operator and reconstruct the jet pivots. Independently derive ghost-source
   covectors from physical field columns and nonminimal cotangent shifts from
   a graded generating functional. Compare completed exact outputs before
   dependent acceptance. Routes share immutable data, Python/SymPy, word
   arithmetic and analyst; they are not external scientific endorsement.
8. **Falsifiers.** Lost spatial Lorentz sign, counting all equation jets as
   independent, dropping the ghost antifield, gauging global PQ, bare/ungraded
   nonminimal source substitution, hidden division by g10, and finite-rank
   checks mislabeled as an all-jet proof. Retain predecessor negative evidence.
9. **Limits.** The g10=0 specialization must remain valid. General lower-jet
   polynomial interactions, all 29 potential directions, and a fixed vacuum
   must not change the leading pivots. Jets of ghosts and backgrounds are free
   spectators. Local-form resolution is distinct from homology modulo d;
   Lorentz/Ward/basic subspace preservation is a later obligation.
10. **Stop.** Stop at the first essential exact mismatch or unsupported proof
    step; preserve it. Computational caps raise and classify incomplete work.
    Complete only this prerequisite before reconsidering the next theorem gate.
11. **Meaning.** A PASS qualifies only the declared polynomial full-complex
    resolution and normality. Finite implementation controls alone cannot PASS.
    Refutation or underdefinition is not a Spin(10) no-go. W1-W7 stay conditional
    on A1-A5; no regulator, anomaly cancellation or quantum measure is inferred.
12. **Evidence.** Separate new primary/replay evidence, an explicit derivation,
    adversarial tests, fresh byte replay, predecessor hashes and a validation
    receipt. Preserve project_state.json and all frozen artifacts. Custody exit
    2/seven references remains unresolved. Validate before local commit; no push,
    activation, catalog generation, HB1/C5, C1_GS or publication.
