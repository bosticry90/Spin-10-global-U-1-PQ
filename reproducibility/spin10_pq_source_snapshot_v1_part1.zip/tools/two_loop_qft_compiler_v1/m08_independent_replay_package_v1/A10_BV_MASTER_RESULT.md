# Stage D canonical BV candidate: bounded gauge-Euler interface stop

The inactive gauge/scalar BV candidate is **not qualified**. The first decisive
physical source-column comparison fails at Gate 3: the existing indexed Euler
helper does not yield the canonical derivative for a free spatial Lorentz
component of the literal approved gauge action. This is a variational interface
failure, not another failure of the covariant physical action's local Ward test.

The b59d2e3 scalar cotangent adapter and its action dependencies authenticate.
The checkout began clean at b59d2e3, with no surviving earlier Phase C process.
Frozen evidence, source definitions, physical parameters, project_state.json,
the 34/39 ledger and the solo-review policy are preserved.

## Exact witness and independent replay

Use the real plane generator T_01=(E_01-E_10)/sqrt(2), Minkowski metric
diag(1,-1,-1,-1), and B_1=b(x^0)T_01. Every other connection and scalar is zero;
equivalently eta=-v is an allowed off-shell scalar configuration. Sources are
absent. The coupling g10 remains arbitrary. The self-commutator vanishes.

The literal gauge action gives

    L = (partial_0 b)^2/2,
    delta L = (partial_0 b)(partial_0 h)
            = -(partial_0^2 b)h + partial_0[(partial_0 b)h].

Consequently the canonical covector, defined by delta S = integral E h, is
E=-partial_0^2 b. Calling indexed_euler_lagrange on that same gauge term with
free indices (out_a,out_mu) gives +partial_0^2 b in this channel. Both
index_kinds=(generic,generic) and (generic,lorentz) give that result. The exact
indexed-minus-canonical residual is 2 partial_0^2 b.

The primary route evaluates the literal action and helper AST on arbitrary
b(x^nu), with ordinary jets retained. An independent replay counts the two
antisymmetric field-strength components and varies them with a formal epsilon,
then explicitly integrates by parts. It imports neither the indexed helper nor
the primary witness. It obtains the same canonical derivative. All 16 Lorentz
component/derivative pairs were compared: nine spatial-output pairs disagree;
diagonal curvature-zero pairs and the time-output controls are included.

The 29 potential terms contain no B. Scalar kinetic currents vanish at x=0.
Non-Abelian contributions to the selected generator vanish by antisymmetry.
Thus this is also a selected derivative of the complete approved physical
action, not an isolated term whose derivative another physical term could fix.
No gauge field is projected out before its variational derivative is taken.

A boundary term cannot change an Euler covector. The difference in the first
variation would be 2(partial_0^2 b)h; its Euler derivative with respect to the
arbitrary test variation h is 2 partial_0^2 b, not identically zero. No field
equation or numerical configuration was used to set it to zero.

## A metric multiplication is not a general repair

Multiplication by eta_11=-1 restores the free witness but fails a second exact
control. For constant B_0=a T_01 and B_1=b T_02,

    L = g10^2 a^2 b^2/4,
    E_(B_1,T_02) = g10^2 a^2 b/2.

Here the indexed helper already returns that canonical coefficient. A uniform
eta_11 multiplication reverses its correct sign. The replay derives the density
from physical 10x10 matrix commutators and the trace metric, independently of
the primary structure-constant evaluator. Both controls are stored exactly.

The discrepancy therefore cannot be classified away by declaring every output
a uniformly metric-raised vector. The helper's contraction simplification treats
KroneckerMetric factors as substitutions and removes contracted indices. A free
Lorentz slot can lose the diagonal metric weight associated with its binder.
That mechanism is the leading implementation explanation; a qualified general
replacement still requires its own normalization, index-variance and graded
Euler contract. The helper is preserved unchanged.

## What was constructed before the stop

The candidate declares 643 canonical pairs (1,286 generators): 180 connection,
328 scalar, 45 ghost, 66 heavy nonminimal and 24 light nonminimal pairs.
Q=(S,.) uses one source-left convention. Source grades follow
(d,gh,p)_J=(3-d,-1-gh,1-p). The real plane/C3 field map and inverse-transpose
source map preserve canonical evaluation; the physical gauge metric is not
substituted for canonical pairing. The six historical source-frame certificates
and K_phi composition remain explicit authenticated dependencies. The full
Lorentz interpretation of vector source components must be reconciled along
with the failed gauge Euler path, rather than inferred from internal Gram maps.

The unqualified AST contains the 34 approved physical terms and nine prospective
source terms. Every physical B is explicitly replaced by Q B_parent, avoiding
an accidental identification of plane and C3 components. Potential terms and
parameters remain identical. The H-only background connection and vacuum are
fixed under this quantum differential. R_H=-[u,u]_H/2 is composite; f(m,m,m)
is retained. Both nonminimal sectors are represented prospectively.

The 35,162 source monomials and 106,097 coefficients across all 1,286
source-only Euler columns agree between
indexed graded execution/one-pass differentiation and independently extracted
physical Lie geometry/direct pairing/separate-coordinate Euler variation.
Implicit zero columns are included. These columns omit the physical Euler
contributions, and are not a qualification of the complete source differential.
The saved metrics give the exact coefficient counts and read-only routes.

| Gate | Recorded disposition |
| --- | --- |
| 1. Canonical architecture | Declared inactive architecture and authenticated internal frames; vector Lorentz conversion reserved |
| 2. Minimal/source assembly | Inactive 43-term assembly; source-only polynomial compared exactly |
| 3. Complete variational source columns | STOP: selected canonical gauge Euler translation fails |
| 4. Full master equation and off-shell source nilpotence | Not established; no accepted calculation |
| 5. Full heavy canonical transport and compatibility | Not reached; earlier bounded map remains preserved |
| 6. Evidence and decision | Independent stop evidence and bounded validation receipt |

An exploratory source-square prototype used abstract Euler placeholders before
the physical Euler audit had completed. It supplied no accepted result; a
prototype covariance-sign error was discarded. No master or source-nilpotence
claim is drawn from that work. Final evidence routes stop at the Euler interface.
The previously unfinished mixed-kinetic calculation remains unestablished.

## Dependency impact and historical controls

The scalar adapter's free output indices are scalar representation coordinates,
not free Lorentz components. Its independently matched potential and kinetic
proofs remain qualified. Neither the original A10 scalar counterexample nor
the factor-120 negative control is altered. Earlier mixed source and heavy
canonical-map controls retain their original bounded status.

The helper is used for V_H and q_L derivatives in execute_variational_s5_s8.py
and feeds S6 reverse K_V/K_q columns and S7 EOM records. Those paths require
a targeted free-Lorentz interpretation review before reuse in a new canonical
master action. The source decoder also invokes the helper for forward source
images; its internal six-frame tests do not establish this new gauge Euler
interpretation. This call-site inventory is not a retrospective proof that
every stored derivative is wrong. Historical bytes and gate acceptance records
are retained. V4/V5 potential-only gradients, the Higgs potential benchmark,
representation geometry, catalogs and authority are not reclassified here.

## Validation, review limits and next decision

The receipt records 75 passing targeted regressions (12 new, 63 inherited),
authenticated predecessor evidence, independent source-only comparisons, and
byte-identical fresh regeneration of the two decisive gauge witness routes.
The large source assembly routes were calculated once each and authenticated
during final validation; they were not rerun for that receipt. Workspace/active
data size and mtime metadata and inherited byte bindings are checked separately.
These are bounded integrity checks, not an unrestricted all-byte workspace audit.

Historical custody remains strict exit 2 with seven unresolved references. The
audit status PASS_BOUNDED_FAILURE_EVIDENCE_VALIDATION_ONLY authenticates the
negative result; the scientific gate is STOP_GATE_3_CANONICAL_GAUGE_EULER_TRANSLATION_FAILED.

The implementations share the declared model, immutable inputs, Python/SymPy,
some graded arithmetic and the same analyst. There is no external endorsement.
SOLO_REVIEW_POLICY_V1 applies; no contact, recruitment or outreach is planned.

The next decision is a separately bounded **canonical gauge Euler / free-Lorentz
cotangent conversion qualification**, including kinetic and non-Abelian terms,
scalar currents, source Lorentz pairing, boundary currents and exact independent
coefficient comparisons. A free-index metric multiplier alone is refuted. Until
that operation is qualified, the complete BV source columns and master equation
remain unestablished. No Stage E, activation, HB1/C5, catalog rebuild, C1_GS,
physical parameter change, formal promotion or remote push occurred.
