"""Jet-gradient and cotangent-lift replay; never imports new primary outputs."""
from a10_bv_integration_common import *

def build(stage=lambda n,f:f()):
    from audit_a10_gauge_euler import authenticate
    stage('authenticate_qualified_dependencies',authenticate)
    data,cols=source_data('replay');w=algebra()
    results=[]
    for z,J in w.pairs:
        residual=canonical(derivative_action(cols[z],w,cols))
        assert not residual,('REPLAY_FIELD_SQUARE',z,rows(residual)[:8])
        results.append({'coordinate':z,'residual':[]})
    # Derive the master density independently from a variation of J_z R^z:
    # Q(J R)=QJ R+(-1)^(1-p_z) J Q R. The last term vanishes by the
    # all-coordinate squares just established. Integration by parts gives
    # Q(S1 density)=2 sum QJ R - div(JB QC). Therefore (S1,S1) density
    # equals 2 div(JB QC). This is a polynomial first-variation proof,
    # not an assumption that source nilpotence holds.
    current=[w.add(*(w.scale(w.mul(w.var(f'JB{a}_{mu}'),cols[f'C{a}']),2) for a in IDS)) for mu in range(4)]
    predicted=canonical(w.add(*(w.D(P,mu) for mu,P in enumerate(current))))
    from a10_bv_integration_physical import build as cross
    physical=stage('finite_covariance_physical_cotangent_replay',lambda:cross(stage,'replay'))
    from a10_bv_integration_replay_control import build as control,wrong_free_Euler_control
    independent=stage('independent_exterior_physical_source_control',lambda:control(stage))
    return {'schema':'A10_INACTIVE_STAGE_D_INTEGRATION_REPLAY_V1',
        'status':'PASS_BOUNDED_INACTIVE_STAGE_D_GAUGE_SCALAR_BV',
        'field_nilpotence':results,'physical_cross':physical,
        'source_degree_one_master':{'source_degree':1,'literal_master_density':rows(predicted),
            'boundary_current':[rows(P) for P in current],'density_minus_divergence':[],
            'boundary_formula':'2 sum_a JB_a^mu QC^a','EOM_used':False},
        'source_master_derivation':'odd jet-gradient first variation of the cotangent lift, with independently checked Q R=0; direct density Euler/bracket comparison is supplied separately by primary',
        'full_master_equation_established':True,'full_source_nilpotence_established':True,
        'source_nilpotence_derivation':'graded Jacobi and Euler annihilation of displayed divergences; physical covariance from finite contragredient coordinate variation and all source cross/Noether identities',
        'independent_exterior_control':independent,
        'wrong_free_Euler_negative_control':wrong_free_Euler_control(),
        'source_polynomial_sha256':digest(data['source_polynomial']),
        'Stage_E_reached':False,'sources_activated':False,'adopted':False}
