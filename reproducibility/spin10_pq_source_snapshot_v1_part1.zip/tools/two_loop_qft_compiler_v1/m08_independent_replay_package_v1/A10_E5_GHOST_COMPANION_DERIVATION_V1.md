# Ghost companion calculation and first-failure adjudication

Prospective derivation, not completed evidence. Use the exact source-free E2
density, not an isolated conventional FP action. The cubic of orderg is
assembled with every derivative placement. The orderxi cubic is the actual
Lambda/antighost/ghost term; orderg*xi quartics give the tadpole.

The mixed bubble has two background assignments: external antighost in the
g vertex and external ghost in the xi vertex; or the reverse assignment.
They have different derivative numerators. The kinetic UV coefficient must
be taken only after summing both. A quartic tadpole has no external derivative
but may contribute a regulated power divergence; do not ignore it.

For a=2/Lambda^2, q^2>0, the common two-propagator profile is
exp[-a(k^2+(k+q)^2)]. Define

    I2(q)=integral d^4k/(2pi)^4 exp[-a(k^2+(k+q)^2)]/[k^2(k+q)^2],
    Jpair(q)=integral d^4k/(2pi)^4 exp[-a(k^2+(k+q)^2)]/k^2,
    Jsingle=integral d^4k/(2pi)^4 exp[-a k^2]/k^2.

Shift/Gaussian and lower-parameter-limit constructions give

    Jpair=(exp(-c/2)-exp(-c))/(16pi^2 a c), c=a q^2,
    Jsingle=1/(16pi^2 a).

I2 is the authenticated nonexceptional E1 bubble with logarithmic residue
1/(16pi^2). Jpair is IR finite, has a power divergence and an analytic q^2
remainder; it has no q^2 UV logarithm. Its constant and first-q^2 coefficients
must be derived, not confused with I2. The complete ghost result and group
signs remain to be computed. Do not predeclare cancellation or matching.

The previous source poles fixed the inactive ghost-only generator
Kbar=g xi JC^T N C. Its candidate ghost kinetic projection is compared with
the actual sum; all density currents and source types remain as qualified.
If a mismatch is exact, its Euler derivative must distinguish it from an
ordinary divergence. Stop before other companion vertices.

Physical nonminimal coordinates are dual to the primal ghost, so an opposing
antighost/auxiliary scaling would use N^T in canonical dual coordinates,
with evaluation-dual source scaling. Keeping antighost and auxiliary together
preserves the free Q0 antighost=-auxiliary doublet. This is only a possible
typed control, not permission to insert that normalization or alter widths.

The UV pole, cutoff powers, finite local scheme terms, physical IR removal
and complete Slavnov restoration are different obligations. Preserve all
predecessor results and disclose shared software/input assumptions.
