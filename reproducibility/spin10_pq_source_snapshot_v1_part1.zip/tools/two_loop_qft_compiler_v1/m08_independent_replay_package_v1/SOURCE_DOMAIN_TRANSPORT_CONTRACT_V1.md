# M08 source coordinates and domain transport candidate

## Required task header

- **Physics decision enabled:** specify a consistent source/domain foundation for the later finite heavy-particle matching calculation; no matching result is computed.
- **Current blocker removed:** test the proposed pre-light-gauge-fixing domain and its canonical transport, with independent background Ward conditions. This can narrow, not automatically remove, the pending full-M08 domain qualification.
- **Why existing tools are insufficient:** the predecessor derives geometry and a free transport control, but does not test a non-Abelian connection/source block with a nontrivial pairing, background connection and joint restricted domain.
- **Minimum new implementation surface:** two bounded exact implementations, one read-only audit, regression tests and versioned evidence/report. Reuse qualified geometry and graded engines. No new active alphabet or catalog.
- **Structure-preservation obligations:** exact inverse, evaluation pairing, bracket including weighted carrier coordinates, H covariance, conjugation on the H coordinate bridge, ordinary derivative prolongation, canonical source shift and joint quantum/background constraints. Full catalog descent remains outside this bounded gate.
- **Stopping condition:** stop at the first failed prerequisite or after bounded source/domain adjudication. No full 17-image reconstruction, HB1, C5, ranks, EOM quotient, cohomology, finite C1_GS or subsequent gates.
- **What will be deleted or deactivated if this does not work:** no historical evidence is deleted. The new candidate stays inactive and its exact failed gate is preserved; no active definition is replaced.

## Candidate architecture fixed before solving

Use independent fields z and evaluation covectors J with canonical antifields z_star=(-1)^p J. For an even action, the left Hamiltonian bracket generates both forward fields and reverse sources using left Euler derivatives. Abar is external and Q-inert; it transforms affinely under a separate background Ward action. R_H is always the derived heavy-ghost composite.

In candidate evaluation coordinates the bracket is

`(F,G)=sum_z (-1)^p(z) [ (d^R F/dz)(d^L G/dJ_z) - (d^R F/dJ_z)(d^L G/dz) ]`,

with Euler derivatives for local functionals, symmetric ordinary jets, and a left odd derivation for Q. For an even S, `Qz=d^L S/dJ_z` and `QJ_z=d^L S/dz`. The gauge fermion is field-only; `U_psi J_z=J_z-(-1)^p(z) d^L psi/dz`, with the opposite shift as exact inverse. This convention is a new candidate, not a relabeling of the frozen source images.

### Prospective full-M08 canonical architecture, not activated

| Field | Candidate evaluation source / historical label | Source (dimension, ghost, parity) |
|---|---|---|
| V_H | J_V / K_V | (2,-1,odd) |
| q_L | J_q / K_q | (2,-1,odd) |
| phi | J_phi / K_phi | (2,-1,odd) |
| u_H | J_u / L_u | (2,-2,even) |
| Lambda_H | J_Lambda / K_Lambda | (1,-1,odd) |
| c_L | J_c / L_c | (2,-2,even) |
| ubar_H | J_ubar / prospective K_ubar | (2,0,even) |
| cbar_L | J_cbar / prospective K_cbar | (2,0,even) |
| lambda_L | J_lambda / prospective K_lambda | (1,-1,odd) |

Source Lorentz duals follow their paired fields. H sources are evaluation covectors, not inferred primal coordinates from a catalog label. The table identifies pair types and grades only: each historical component decoder and coupling contraction still needs an explicit binding to these coordinates. No equation `historical K=J` is assumed. The three prospective additions have 33+12+12 components and remain inactive.

The candidate quantum action uses `Tq Abar=0`, `Tq q=d omega+g10[Abar+q,omega]`; the separate background action uses `Tb Abar=d beta+g10[Abar,beta]`, `Tb q=g10[q,beta]`. Homogeneous fields use their qualified representation action and sources its cotangent lift. Abar has no canonical partner in this candidate. Parameters/couplings remain frozen scalars/spurions. The shifted scalar is `eta=v+phi`, with the candidate `Qphi=-g10 rho(c_L+u_H)(v+phi)` and the qualified physical VEV orbit; v is not discarded. Full source/gauge-fixing VEV terms require derivation. RH is `-1/2 P_H[u_H,u_H]`, and its action is obtained by the chain rule, never by an independent assignment. No symmetric-coset simplification is allowed.

Define provisionally the pre-light domain on local functionals modulo ordinary total derivatives by simultaneous conditions for every independent local parameter and its jets:

`D_pre = ker(Tq_omega) intersect ker(iota_omega) intersect ker(Tb_beta)`.

This is a subspace of the ambient functional algebra, not an EOM/source-zero quotient. Sigma need not belong to it. Its Q preservation requires Q^2=0, {iota,Q}=Tq, [Tq,Q]=0 and [Tb,Q]=0 in the actual intended algebra. Those identities are not presumed for full M08.

The candidate post-light domain is `D_psi=U_psi D_pre`. Transport Q, Tq and iota by conjugation. Transport Tb as well; it stays unchanged only if the gauge fermion is background invariant and the bracket/derivative structure makes Tb commute with U_psi. Preserve independent-parameter variation before composite substitution.

## Preregistered small decisive test

1. Test the full 12-dimensional H Gram/evaluation-dual coordinate bridge, its inverse and its induced bracket. A map from a self-dual source carrier to an evaluation covector is not a canonical map if the field is unchanged and the old bracket is incorrectly retained as delta. Include that negative control.
2. Select the smallest coordinate-word block containing H generators 0 and 4 and closed under the frozen bracket and Gram dual pairing. The selection rule is fixed before testing; do not fit it to a successful square. Freeze its nondegenerate pairing and structure constants.
3. In that actual-H block use q, c, cbar, lambda and a homogeneous adjoint scalar, their canonical sources, external Abar, independent local parameters omega/beta, and one ordinary derivation D. This is a bounded source-kinematic test algebra, not a new physical theory or a restriction theorem for all four-dimensional M08 fields. No Yang-Mills/scalar potential action is inferred from its source-only action.
4. Generate the minimal source action, contractions, quantum cotangent action and background Ward action under one convention. The light gauge fermion uses an explicitly invariant pairing; compare the wrong plain-dot version. Require master/Euler, nilpotence, Cartan, background covariance and canonical transport checks on all control generators.
5. Test a nonzero source-bearing pre-domain functional, its nonzero Q image, their transported versions and their joint constraints. Retain a wrong-raw-source action control with a nonzero Euler residual, not merely a displayed nonzero density.
6. The actual shifted 328-scalar, full non-symmetric coset and heavy nonminimal completion remain explicit full-M08 obligations; reuse their qualified predecessor controls without silently identifying them with this smaller algebra.

### Exact bounded conventions

The seed rule yields H coordinates `[0,1,4,11]`; no projection to an arbitrary numerical two-generator slice is made. Let G be the restricted actual H Gram matrix, B=Abar+q, and Dbar=D+g10[Abar,.]. In the control the homogeneous scalar p is adjoint (not the 328-component physical scalar). Use

`Qq=Dc+g10[B,c]; Qc=-g10[c,c]/2; Qcbar=-lambda; Qlambda=0; Qp=-g10[c,p]`.

The source-only master candidate is `S=sum_z J_z Qz`. It contains no physical Yang-Mills/scalar action. The contraction Hamiltonian is `I_omega=J_c omega+J_lambda g10[omega,cbar]`. The invariant candidate light fermion is `psi=cbar^T G (Dbar q-eta_H lambda/2)`; G is explicit here because these new control fields are primal coordinates. This does not diagnose a frozen M08 contraction until its component decoder is known.

Test the local cotangent lifts and their Lie brackets for independent omega/beta, contraction covariance, the Cartan identity and Q commutation on all 40 generators. Test all 210 unordered source/source canonical cross-pairs, not just 20 diagonal field/source pairs. The source control is `F=sum J_lambda p`, with a nonzero Q image. Its transported domain must use the transported operations; retaining the raw quantum action is a preregistered negative control.

## Authority and validation

All existing Sigma/source/images/catalog/state bytes stay immutable. Prospective partners remain inactive. The contract itself is a tested candidate/specification, not a promoted full-M08 H-basic theorem. Specialist semantic review is outstanding; no person is contacted or endorsement invented.

Freeze primary and replay outputs separately before comparison. Regenerate byte-identically under the pole-blind guard, retain exact negative controls, verify inherited hashes without refreshing them, and run read-only audits with zero workspace/active-data mutation. Record wall/CPU/process peak and I/O with unmeasured subdivisions explicit. Strict historical custody may remain exit 2. No unrestricted validation PASS, GPU, T5 rebuild or remote push. Formal authority remains 34/39. Commit locally and stop.
