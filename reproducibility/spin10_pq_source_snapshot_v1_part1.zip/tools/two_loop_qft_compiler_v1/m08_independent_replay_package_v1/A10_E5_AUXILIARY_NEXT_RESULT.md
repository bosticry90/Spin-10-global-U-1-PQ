# E5 next-order auxiliary companion: exact stopped inactive candidate

Scientific disposition: `STOP_E5_UNIQUE_INACTIVE_MEMBER_MISSES_NEXT_AUXILIARY`.
The two complete actual methods agree over all 91,125 auxiliary/antighost/ghost
slots, with formal reference widths retained. The unique previously source-
fixed inactive candidate does not reproduce this next auxiliary pole. This
is progress by an exact bounded obstruction, not full E5 failure, quantum
anomaly, model rejection, subtraction adoption or director acceptance.
project_state.json remains v113, 34/39, SHA
`d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8`.
Whole Spin(10) x global U(1)PQ investigation remains active/incomplete.

## Actual calculation and decisive evidence

V1 froze the prefix order before calculation: next g^2 auxiliary companion,
then derivative-gauge only if it passes. Primary uses literal E2 vertices,
signed Fourier Hessians and every g,g,xi Born shuffle / curvature-quartet
bubble word. Replay reconstructs physical10 commutator vertices independently
and expands the even Gaussian inverse and odd Schur determinant. Both retain
all45 directions, H/M sectors, BB, BL/LB, LL=0, both odd orientations, widths
and currents. All four derivative and nonlinear auxiliary Lorentz copies
agree; full four-component k.BB.k=-width and BL-BB-derivative contractions
qualify the longitudinal reduction before momentum-axis evaluation.

The literal g^2 xi curvature quartet has418 raw coefficients. Its xi bubble
gives776 nonzero physical slots. The entire g,g,xi triangle, including the
external g L B_H B_M vertex and the heavy internal-ghost derivative placement,
has600 nonzero physical slots proportional to the H reference width. No M
width or width-independent term survives that complete triangle. After exact
binding width_H=eta_H, width_M=xi, the total contains888 nonzero physical
words /276 raw canonical words. Reality, all12 H identities and raw/physical
roundtrips pass. UV extraction is only k_E^2>R_UV^2>0; heat profiles6/4 stay
distinct. Nothing here computes a whole scaleless integral or finite/IR amplitude.

In common hbar g10^2/(32 pi^2 epsilon) units, raw coefficient counts are:

| Monomial | Actual | Unique candidate | Difference |
| --- | ---: | ---: | ---: |
| xi | 0 | 0 | 0 |
| xi eta_H | 276 | 0 | 276 |
| xi^2 | 236 | 236 | 256 |

The complete raw difference has276 words (overlaps retained, not counts added).
One real physical canonical word is C_p12 L_p13 a_p14 with coefficient
`-16 sqrt(10) eta_H xi/25`. Its auxiliary L_p13 Euler coefficient on C_p12 a_p14
is the same nonzero polynomial. The full L_p13 Euler has34 words and agrees
with independent ordered deletion coefficientwise. This excludes a pure
total derivative; it establishes no general EOM or anomaly conclusion. All39
earlier affine directions were fixed by the source calculation, so they are
not available to absorb this difference. No new primitive was fitted.

## Exact execution and failure custody

Original formal actual outputs `primary.json` and `replay.json` agree exactly;
their recorded runtimes are375 and188 seconds. They remain immutable. Three
prevalidation engineering failures are retained with preparations and stdout:

1. Control attempt1 used the wrong sign for the replay auxiliary-gauge vertex:
   Qubar=-Lambda requires -Lambda.[B_H,B_M]. The334-word vertex residual, source
   and failed attempt remain. Corrected elementary controls and full vertex
   reconstruction completed before the actual loops; no candidate was read.
2. Original comparison attempt1 detected a real-symbol binding defect.
   sympify without locals produced an unassumed reference_width_H, so real-
   symbol substitution missed it in600 physical terms. V2 preserves those
   unqualified canonical densities and binds the unchanged exact formal tensors
   with declared-real locals. Both bound routes recheck full reality, H and
   frame conditions. No group/loop coefficient was rounded or modified.
3. V2 comparison attempt1 used structural dictionary equality for two Euler
   expressions. V3's complete diagnostic proves structural equality false but
   every exact difference coefficient zero. The failed source/start/output
   remain; the corrected comparison demands a nonzero Euler and exact zero
   Euler-minus-independent-deletion polynomial. It changes no candidate/data.

Qualified full densities are `primary_bound.json`, `replay_bound.json`; the
corrected dependent result is `comparison_v3.json`. Original bad densities
must never be treated as qualified. ContractsV2/V3 and bindings distinguish
formal-loop calculation, exact parameter binding, evidence validation and the
failed candidate scientific gate. No failed attempt counts as PASS.

Initial evidence-audit attempts are also FAILED with exact source snapshots
and stdout: the audit parser initially omitted declared-real locals, and its
attempt glob then included a separate disposition record. The corrected audit
imports real types and selects numbered execution attempts explicitly; it
changes no calculation, bound output or scientific comparison. The delegated
lexical read-only audit also rejected the pure graded-algebra method named
replace as a filesystem mutation; a named pure pullback alias removes that
false classification. Runtime metadata and write guards still require zero
file mutation, and the failed delegated audit remains preserved.

## Validation, dependencies and authority

Input is frozen_a10_e5_nonminimal_source/bindings.json, its35 predecessor
chains and baseline430b358. New preparations own code/contract/input/state
hashes and exclusive output ownership; workers run under the read-only
pole-blind guard. Primary/replay actuals and exact bindings do not open the
candidate. Bound agreement precedes the dependent candidate comparison.
The receipt requires targeted scientific/process/governance checks, the
existing research_check.py e5 delegate, protected/new/state hashes, audit-time
metadata, and FIVE strict fresh own-byte executions: original full primary/
replay loops (formal tensors qualified, binding defect reproduced), both exact
bound routes and V3 comparison. Historical custody remains exit2 with seven
unresolved references, never PASS. Raw index/worktree bytes must agree before
local commit. Expensive predecessor scientific work is authenticated, not rerun.

Shared immutable data, exact arithmetic, Python3.10.11/SymPy1.14.0 and analyst
remain disclosed; the two methods are not independent scientists or external
endorsement. Under the existing epistemic ladder, provenance is explicit;
verification of the selected actual tensor is bounded, candidate matching
fails, formalization is not attempted, mechanism compression is partial,
interpretation is restricted to this inactive normalization, and empirical
connection is none. No authority is promoted by a successful evidence audit.

No derivative-gauge or higher coupling companion ran after this first failure.
No new JC-C-C/JB-B-C amplitude, quantum A5, complete Ward/contact/IR/anomaly,
physical/catalog/HB1/C5/C1_GS/matching, publication/push or outreach is implied.
Global scalar/PQ and fermion/Yukawa/phenomenology remain open.

Next smallest authorized action: freeze a prospective admissibility contract
for additional inactive source-free normalization types at these new coupling
orders while preserving the already measured source/quartet/prior poles.
Derive complete Q images and their constraints before fitting or running
dependent derivative-gauge/higher companions. This is a proposed bounded
investigation, not an adopted extension or unlocked physical calculation.
