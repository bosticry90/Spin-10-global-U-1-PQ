# E5 retained-source quantum Ward and insertion acceptance contract

The assessment of bc6e71d authorizes W1-W7 as a bounded, inactive conditional
framework qualification. Baseline: clean bc6e71dc20d848ee75d4573d3fab3c81e8a2fee0,
state v113, 34/39; 562 byte bindings in 16 manifests authenticate. No surviving
matching calculation was found beyond the preflight itself. This contract is
frozen before the new calculation. It does not authorize loops or later E5 gates.

Question: which functional identities and insertion rules define a defensible
quantum counterterm target for the qualified retained-source gauge/scalar model?
The permissible result is a conditional contract with explicit quantum inputs,
not a claim that an anomaly-free renormalization scheme has been constructed.
Do not repeat the previous stop solely because a regulator or loop calculation
has not been supplied. Stop if a necessary identity is inconsistent or its
mathematical meaning cannot be specified even conditionally.

Freeze the literal Stage D/E1-E4 candidate: 643 integrated canonical fields,
643 external BV evaluation sources, 48 external H-background components,
12 residual generators, the source-left bracket and ordinary symmetric jets.
The 34 physical and nine source terms, physical parameters, nonsymmetric coset,
composite curvature, nonminimal sectors and quartic ghosts remain unchanged.
E1 is a replacement, not a proved translation of historical A4/A5. Retain all
sources and auxiliaries. Ordinary Legendre sources are a separate alphabet.
Optional insertion bookkeeping is external and creates no new canonical pairs.

W1 defines Z, W and Gamma, left graded differentiation, integration and Legendre
variables. W2 states the locality/power-counting/measure/IR assumptions of the
admissible prescription class. Full loop functionals need not be local.
W3 derives the nonlinear Slavnov identity with breakings, its linearization,
consistency/restoration equations and order expansion through order four.
W4 derives local background Ward identities and differentiated insertions,
retaining background-only functionals unless separately normalized by policy.
W5 derives the geometric quantum breaking and the insertion realization of
transported quantum H. Never replace a field-dependent product insertion by
its value at mean fields or impose strict classical Tq' on Gamma without proof.
W6 specifies canonical redefinition, operator/source transport, mixing/contact
normalization and the resulting conditional counterterm equivalence. No theorem
that all source terms are removable is to be inferred. W7 compares distinct
derivations, negative controls and completed reproducibility evidence.

The local counterterm ring retains dimension-four/ghost-zero/even densities,
finite ordinary jets, real structure and polynomial physical couplings and
nonnegative-dimensional parameters. No inverse physical couplings, inverse
dimensional parameters or EFT extension. Dimensionless normalization units of
the qualified two-parameter canonical family are distinct from physical
couplings. d_standard=d_project-gh is used explicitly. Exact terms require
admissible generators and transported insertions/operators, not just a label.

Primary: graded prefix variation, ordered symbolic functional identities and
coefficient convolution. Replay: left-gradient/IBP, independent generating
functional differentiation, physical-frame inherited geometry and moment
recursion. Check all 643 source corrections and frame/grading slots; decisive
local witnesses use actual E3 data. A formal Gaussian insertion control tests
connected terms and nonlinear mean-field transport; it is not a Spin(10) loop.
Authenticate L_bg, L_div, F', wrong-source-pairing and fixed-contraction controls
without rerunning expensive qualified construction. Freshly regenerate only
the new bounded routes. Shared inputs, Python/SymPy, assumptions and analyst
remain disclosed; no external endorsement or personnel requirement.

Possible outcomes: qualified conditional framework, partial derivation, exact
obstruction or underdefinition. Unproved QAP, joint restoration, measure,
insertion-renormalization and canonical quantum equivalence remain labeled
assumptions. A conditional PASS does not establish nonempty realization of the
prescription class, anomaly freedom, quantum gauge independence, a cohomology
theorem, full/basic surjectivity, regularity or Koszul-Tate completeness.
No source activation, catalogs, HB1/C5, C1_GS, authority change, contact, remote
push or publication. Validate completed bounded work before a local commit.
