# M08 source reconstruction technical review requirements

Current version V2, 2026-10-10. Supersedes the outreach/personnel disposition of `INTERACTING_BV_M08_REVIEW_PACKET.md` under [the owner's solo-review policy](../../../docs/SOLO_REVIEW_POLICY_V1.md). Retain its mathematical questions; no personal contact, recruitment or external-participation gate applies. Historical bytes remain unchanged. This packet does not resume Phase C or promote a replacement.

The interacting SU(2) control tests one canonical action with the negative scalar orientation and complete nonminimal pairs. It does not provide an equivalence to the frozen partially gauge-fixed M08 action. The following questions must be settled before that equivalence or a replacement can be accepted. This is a semantic review packet, not a new scientific authority or an active source specification.

## The proposed architecture

Retain the physical parent action, scalar coordinates, representation matrices and vacuum. Treat the affine background as an external BRST-inert variable unless an explicitly different background BV construction is justified. R_H remains the composite -P_H[u_H,u_H]/2, never an independent canonical generator.

The earlier [architecture inventory](NONMINIMAL_BV_M08_ARCHITECTURE_CONTRACT_V1.md) proposes nine canonical pair types: the existing six plus source partners for ubar_H, cbar_L and lambda_L. Their prospective grades follow from d(J)=3-d(z), gh(J)=-1-gh(z), p(J)=1-p(z). The antighost partners consequently have (d,gh,p)=(2,0,0), while the light auxiliary partner has (1,-1,1). Their representations must be the evaluation duals of the actual field roles, not guessed Euclidean transposes. These are inventory requirements only; no new M08 variable is activated here.

Begin with a gauge-invariant parent action and complete canonical minimal/nonminimal action. Derive the partial-gauge choice and light gauge choice through a declared fermion and, where necessary, an explicit canonical auxiliary-coordinate change. Do not append noncanonical antighost transformations to a bracket in which their auxiliaries are already canonical fields. A source-zero projection is not automatically a differential subalgebra.

## Required impact review by role

| Role or expression | Obligation before full M08 adoption |
|---|---|
| phi and K_phi Qphi | Replace the candidate orientation only by the derived -g10 rho(C)(v+phi). Reconstruct the entire source coupling, including the vacuum. The old image remains historical evidence. |
| V_H and q_L | Recover the total connection, background split and A_cf=g10 A_action convention from the same parent action; do not transfer orthonormal SU(2) component signs directly. |
| u_H and c_L | Derive split ghost rules from the full parent ghost, with the exact project structure constants and evaluation duals. |
| R_H | Differentiate the composite through u_H everywhere, including its appearances in the L_c coupling, nonminimal terms and gauge-fixing quartic ghosts. |
| ubar_H and Lambda_H | Use a complete canonical pair structure or an explicitly canonical redefinition into completed-Weil coordinates. Preserve off-shell closure and derive all additional source contributions. |
| cbar_L and lambda_L | Include both canonical partners if using a full nonminimal BV algebra. Derive the light gauge-fixing and reverse source rules together. |
| K_V, K_q, K_phi, L_u, K_Lambda and L_c | Recompute complete Euler derivatives under the coherent left convention, not selected sign patches. Account for the historical even-field parity bug and every composite chain term. |
| Abar_H and v | Distinguish quantum BRST inertia from background covariance. A stored numerical vacuum is not an invariant vector; its broken-generator orbit must appear in Qphi and Goldstone terms. |
| Source-zero action | Compare the candidate gauge-fixed action to the frozen physical and gauge-fixing actions separately. A change of gauge-fixing convention is not automatically a change of physical theory, but requires an explicit canonical/physical equivalence argument. |
| Local operator languages | Existing JCAT/T5 authority applies to the old alphabet. Additional source partners require a disposition and weight-selected recipe impact assessment; setting them to zero is not justified by their being external. No catalog rebuild precedes a coherent small partial-gauge test. |

## Decisive acceptance questions

1. Does one declared variational antibracket generate both forward fields and every reverse source image? Are its right/left signs and the antifield coordinate map consistent with the actual component evaluator?
2. Does the full classical master identity hold as a local functional modulo explicitly controlled divergences, and does its Hamiltonian differential square to zero off-shell? A separately vanishing ST scalar is insufficient without the bracket-derivation hypotheses.
3. Does the partial-gauge formulation reproduce the project-specific Cartan square and full-Weil completion, including quartic ghosts, without importing an ordinary-gauge theorem on an incompatible source domain?
4. Which structural contractions act on the complete nonminimal/source alphabet? Does the differential preserve the proposed basic domain through realization, background packets, IBP, statistics and conjugation? Sigma itself need not be horizontal.
5. Are all historical negative controls retained: the -2i source/basic defect, the +1 reverse-source square, the -box(u) omitted-partner square, the +1 frozen scalar square and the nonhorizontal Sigma coefficient? Candidate repairs must be distinguished from coordinate transports of the old failed operation.
6. Have the action, bracket, source roles and partial-gauge semantic map been challenged through independent derivations, exact negative controls and applicable published literature? Disclose the common analyst, assumptions and software. No external person or endorsement is required or claimed.

## Scope of the next decision

Only after these definitions and a small interacting partial-gauge source control are settled should a full M08 version be derived and its complete impact adjudicated. Do not treat the successful free comparator, ordinary interacting control, field-only scalar closure and earlier partial finite comparator as one already-proved M08 theorem: their hypotheses and domains differ.

HB1/C5, cochain dimensions, differential matrices, EOM quotients and cohomology remain unauthorized. Formal authority remains 34/39; finite_C1_GS remains null. This review packet does not contact a specialist, certify review or promote a replacement.
