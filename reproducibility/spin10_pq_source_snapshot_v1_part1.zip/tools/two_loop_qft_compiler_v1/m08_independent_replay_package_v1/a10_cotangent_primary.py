"""Indexed-Euler primary qualification; no active data writes."""
from itertools import permutations
import sympy as s
from a10_executable_action import HERE,read,build as action,mat,digest,SECTORS
from a10_cotangent_adapter import Adapter,ordered_jacobian,jacobian_certificate,SORTED,sign
from a10_cotangent_graphs import potential_covectors
from a10_cotangent_kinetic import qualify

def definitions():
    result={}
    for sec in SECTORS:
        a=Adapter(sec);P=a.E*a.E.T*a.G
        assert P*P==P and P.T*a.G==a.G*P
        assert a.E.T*a.G*a.E==s.eye(a.n)
        # Right-section equality is polynomial, for arbitrary complexified real covectors.
        ar,ai=s.symbols('alpha_Re alpha_Im');m=120 if sec=='Sigma' else 1
        wa=(ar-s.I*ai)/(2*m);wb=(ar+s.I*ai)/(2*m)
        assert s.expand(m*(wa+wb))==ar and s.expand(m*s.I*(wa-wb))==ai
        result[sec]=a.definition()
    # Constrained annihilators: trace and antisymmetric Phi directions vanish.
    p=Adapter('Phi');assert p.pullback({'Phi':{(i,i):1 for i in range(10)}})==s.zeros(54,1)
    assert p.pullback({'Phi':{(0,1):1,(1,0):-1}})==s.zeros(54,1)
    return result

def witness():
    a=Adapter('Sigma');t,m=s.symbols('t mSigma2',real=True);y=a.E[:,0]*t;raw={'Sigma':{},'SigmaBar':{}}
    L=0;sorted_cov=s.zeros(504,1)
    for i,I in enumerate(SORTED):
        z=y[i]+s.I*y[252+i]
        if not z:continue
        for J in permutations(I):
            v=sign(J)*z;L-=m*v*s.conjugate(v)/120
            raw['Sigma'][J]=-m*s.conjugate(v)/120;raw['SigmaBar'][J]=-m*v/120
        sorted_cov[i]=raw['Sigma'][I]+raw['SigmaBar'][I]
        sorted_cov[252+i]=s.I*(raw['Sigma'][I]-raw['SigmaBar'][I])
    direct=s.diff(s.expand(L),t);new=s.simplify(a.pullback(raw)[0]);bad=s.simplify((a.E.T*a.G*sorted_cov)[0])
    assert direct==new==-2*m*t and bad==-m*t/60
    frozen=read(HERE/'frozen_a10_executable_reconciliation/source_interface_primary.json')
    assert str(direct)==frozen['canonical_derivative'] and str(bad)==frozen['raw_real_to_sorted_Riesz_without_measure']
    # A covector supported on one ordered address is not antisymmetric. Blind
    # multiplication by 120 is wrong; the signed sum sees just that address.
    one={'Sigma':{SORTED[0]:1},'SigmaBar':{}}
    correct=a.pullback(one);naive=120*correct
    assert correct!=naive
    return {'density':str(s.expand(L)),'direct_derivative':str(direct),'adapter_derivative':str(new),
        'omitted_measure_derivative':str(bad),'ordered_nonzero_components':len(raw['Sigma']),
        'blind_120_arbitrary_covector_negative':{'correct_first_component':str(correct[0]),'incorrect_first_component':str(naive[0])}}

def kinetic_tensor_chain():
    """Universal ordered kinetic covector conversion, before specifying D²x.

    U is an arbitrary canonical D²x vector, including every connection jet.
    The complete Jacobian certificate makes this proof component independent.
    """
    r,i=s.symbols('U_Re U_Im');result={}
    for sec in SECTORS:
        a=Adapter(sec)
        if sec=='Phi':alpha=s.Matrix([-r]);target=s.Matrix([-r]);raw='-D^2 Phi'
        else:
            measure=120 if sec=='Sigma' else 1
            coefficient=s.Rational(1,240) if sec=='Sigma' else s.Integer(1)
            wz=-coefficient*(r-s.I*i);wb=-coefficient*(r+s.I*i)
            alpha=s.Matrix([s.expand(measure*(wz+wb)),s.expand(measure*s.I*(wz-wb))])
            metric=1 if sec=='Sigma' else 2
            target=-metric*s.Matrix([r,i]);raw='-(D^2 '+sec+')bar * '+str(coefficient)+'; conjugate alias paired separately'
        assert alpha==target
        assert a.E.T*a.G*a.E==s.eye(a.n)
        result[sec]={'ordered_complex_Euler_rule':raw,
            'sorted_real_Euler_rule':'alpha=-G E U, U=D_mu D^mu x',
            'pullback':'E^T alpha=-U since E^T G E=I',
            'ambient_covariant_carrier':'A E=E rho, qualified intertwiner reused; constant embedding commutes with partial',
            'boundary_pairing':'h_y^T G D^mu y = h_x^T D^mu x',
            'ordered_measure':120 if sec=='Sigma' else 1,
            'kernel_field_configuration':'arbitrary U, no zero-field projection or EOM'}
    return result

def mass_covectors():
    result={}
    for sec in SECTORS:
        a=Adapter(sec)
        if sec=='Phi':
            transpose=s.SparseMatrix(100,100,{(10*i+j,10*j+i):1 for i in range(10) for j in range(10)})
            H=-2*a.E.T*transpose*a.E
        else:H=-2*a.E.T*a.E
        coefficient=-2 if sec in ('Phi','Sigma') else -1
        assert H==coefficient*s.eye(a.n)
        result[sec]={'canonical_mass_covector_coefficient':coefficient,
            'symbolic_rule':str(coefficient)+' * m'+sec+'2 * x_'+sec,
            'all_coordinates':a.n,'Hessian_sha256':digest(__import__('a10_executable_action').record(H)),
            'ordered_measure_included':120 if sec=='Sigma' else 1}
    return result

def build(stage=lambda name,fn:fn()):
    defs=stage('all_four_typed_maps_and_quotient_sections',definitions)
    jac=stage('every_ordered_alias_Jacobian',lambda:{sec:jacobian_certificate(ordered_jacobian(sec)) for sec in SECTORS})
    act=action();pot=stage('all_29_potential_general_Euler_pairing_identities',lambda:[potential_covectors(t) for t in act['local_terms'][5:]])
    kin=stage('all_four_free_skew_matrix_kinetic_Euler_identities',lambda:[qualify(t) for t in act['local_terms'][1:5]])
    # The free skew-matrix proof applies to every frozen rho, not a selected
    # 3x3 gauge example; verify all 180 specialization premises freshly.
    data=read(HERE/'frozen_a10_physical_reconciliation/full_primary.json');checked=0
    for sec in SECTORS:
        for r in data['representation_matrices'][sec]:
            R=mat(r);assert R+R.T==s.zeros(*R.shape);checked+=1
    assert checked==180 and all(not r['entries'] for r in data['representation_matrices']['S'])
    return {'schema':'A10_CANONICAL_COTANGENT_ADAPTER_PRIMARY_V1','status':'PASS_BOUNDED_ADAPTER_ONLY_INACTIVE',
        'definitions':defs,'ordered_Jacobians':jac,'potential_covectors':pot,'kinetic_covectors':kin,
        'five_form_witness':stage('old_witness_and_nonantisymmetric_negative_control',witness),
        'kinetic_tensor_pullback':stage('ordered_kinetic_covectors_to_canonical_Euler',kinetic_tensor_chain),
        'all_coordinate_mass_covectors':stage('exact_mass_covectors_all_328_coordinates',mass_covectors),
        'skew_matrix_specializations':checked,'potential_independent_real_parameters':34,
        'general_chain_proof':'Every finite ordered field alias is linear y=Jx. Leaf differential J h commutes with every ordinary jet. Exact Leibniz and finite contraction induction prove Euler_x=J^T Euler_y modulo the displayed IBP boundary, for all local polynomial coefficients and all canonical coordinates.',
        'complete_master_action_constructed':False,'source_activation':False,'Stage_E_reached':False,
        'candidate_adopted':False,'formal_authority':'34/39_UNCHANGED','C1_GS':None}
