"""Exact even Einstein-graph normal forms; no field-value sampling.

Graphs retain every tensor slot and parameter coefficient. Exhaustive factor
permutations canonicalize bound dummy labels, not tensor symmetries. This
proves equal polynomials already on unrestricted ordered tensor variables.
"""
from copy import deepcopy
from itertools import permutations
import sympy as s
from a10_executable_action import contract, digest
from m08_local_functional_ast import add,mul,scalar,field
from m08_indexed_variational import indexed_euler_lagrange
from a10_cotangent_adapter import RANK

def directional(node):
    """Direct polynomial differential, before any variational lowering."""
    kind=node['node']
    if kind=='Field':return field('h_'+node['name'],indices=node['indices'])
    if kind in ('ExactScalar','Parameter'):return scalar(0)
    if kind=='Add':return add(*(directional(v) for v in node['terms']))
    if kind=='OrderedProduct':
        f=node['factors'];return add(*(mul(*f[:i],directional(v),*f[i+1:]) for i,v in enumerate(f)))
    if kind in ('LocalActionTerm','GroupContraction','LorentzContraction'):
        key='density' if kind=='LocalActionTerm' else 'expression' if 'expression' in node else 'argument'
        out=deepcopy(node);out[key]=directional(node[key]);return out
    raise ValueError('POTENTIAL_GRAPH_NODE_'+kind)

def expand_graph(node):
    """Distribute sums/products with lexically scoped contraction binders."""
    serial=0
    def walk(n, env):
        nonlocal serial
        k=n['node']
        if k=='ExactScalar':return [(s.sympify(n['value']),[],[],set())]
        if k=='Parameter':return [(s.Integer(1),[n['name']],[],set())]
        if k in ('Field','KroneckerMetric'):
            return [(s.Integer(1),[],[(k,n['name'],tuple(env.get(i,i) for i in n['indices']))],set())]
        if k=='LocalActionTerm':return walk(n['density'],env)
        if k in ('GroupContraction','LorentzContraction'):
            assert k=='GroupContraction','POTENTIAL_HAS_NO_LORENTZ_JETS'
            local=dict(env); bound=set()
            for i in n.get('contracted_indices',n.get('summed_indices',())):
                local[i]='b'+str(serial);serial+=1;bound.add(local[i])
            child=n.get('expression',n.get('argument'))
            return [(c,p,f,b|bound) for c,p,f,b in walk(child,local)]
        if k=='Add':return [v for term in n['terms'] for v in walk(term,env)]
        if k=='OrderedProduct':
            out=[(s.Integer(1),[],[],set())]
            for term in n['factors']:
                nxt=walk(term,env)
                out=[(c*d,p+q,f+g,b|e) for c,p,f,b in out for d,q,g,e in nxt]
            return out
        raise ValueError('GRAPH_NODE_'+k)
    return walk(node,{})

def normal_graphs(node):
    result={}
    for coefficient,params,factors,bound in expand_graph(node):
        if not coefficient:continue
        parent={}
        def root(i):
            parent.setdefault(i,i)
            if parent[i]!=i:parent[i]=root(parent[i])
            return parent[i]
        for k,name,indices in factors:
            if k=='KroneckerMetric':
                assert name=='delta_exact'
                a,b=map(root,indices);parent[b]=a
        fields=[(name,tuple(root(i) for i in indices)) for k,name,indices in factors if k=='Field']
        live={i for _,indices in fields for i in indices}; contracted={root(i) for i in bound}
        assert live<=contracted,('UNBOUND_GRAPH_SLOTS',live-contracted)
        coefficient*=10**len(contracted-live)
        candidates=[]
        for order in permutations(fields):
            labels={}; packed=[]
            for name,indices in order:
                slots=[]
                for i in indices:
                    if i not in labels:labels[i]=len(labels)
                    slots.append(labels[i])
                packed.append((name,tuple(slots)))
            candidates.append(tuple(packed))
        key=(tuple(sorted(params)),min(candidates) if candidates else ())
        result[key]=s.expand(result.get(key,0)+coefficient)
    return [[list(params),[[name,list(indices)] for name,indices in factors],str(s.simplify(value))]
            for (params,factors),value in sorted(result.items()) if value]

def potential_covectors(term):
    raw={}; pair=[]
    for name,rank in RANK.items():
        free=tuple('output_'+str(i) for i in range(rank))
        node=indexed_euler_lagrange(term,name=name,free_indices=free,index_kinds=('generic',)*rank,side='left')
        raw[name]=node
        pair.append(contract(mul(node,field('h_'+name,indices=free)),free))
    direct=normal_graphs(directional(term)); pulled=normal_graphs(add(*pair))
    assert direct==pulled,('POTENTIAL_DIFFERENTIAL_MISMATCH',term['term_id'])
    return {'term_id':term['term_id'],'raw_ordered_Euler_ASTs':raw,
            'differential_graph_coefficients':direct,'raw_paired_graph_sha256':digest(pulled),
            'canonical_covector_recipe':'J_ordered^T * raw_Euler; J_ordered bound by all-component Jacobian certificate',
            'identity_scope':'formal polynomial identity for every tensor component and independent parameter; no field samples'}
