# Source-coordinate and joint-domain transport result

Disposition: `QUALIFIED_BOUNDED_SOURCE_DOMAIN_TRANSPORT_NOT_FULL_M08`.

Base: local commit `96a9572`. This is an inactive architectural candidate and a qualified small source-kinematic control, not a replacement of M08. Formal authority stays **34/39**. No new physical prediction, source activation, cochain dimension or finite C1_GS value is earned.

## Assessment and execution

The supplied assessment correctly identifies the next prerequisite: source coordinates, quantum basicness and background covariance must be specified together, then transported consistently through gauge fixing. Its bounded successes do not establish a complete interacting master action. This execution follows the proposed pre-light-domain route, keeping its background Ward requirement separate and testing a small decisive actual-H block first.

The route succeeds in that control. It does **not** uniquely bind the historical source-component decoder or qualify the full-M08 domain. The [candidate contract](SOURCE_DOMAIN_TRANSPORT_CONTRACT_V1.md) therefore remains inactive. External specialist scrutiny is still required; the [review packet](SOURCE_DOMAIN_SPECIALIST_REVIEW_PACKET.md) contains questions, not an endorsement.

## Exact coordinate decision

Declare independent evaluation sources J and canonical antifields `z_star=(-1)^p J`. Use one explicitly signed bracket, left odd derivation and Euler variation. For an even action, both field and reverse-source columns follow from left Euler derivatives of that action.

In all 12 H coordinates, the Gram matrix G_H is invertible, nonidentity and invariant. The bridge `J=G_H k` from a self-dual carrier k to an evaluation covector preserves the pairing and has an exact inverse. Its H covariance and real-conjugation lift pass. But if the field is held fixed, the carrier bracket is weighted by G_H inverse: retaining a delta bracket is not a canonical transformation. The nonzero `G_H inverse - identity` is retained as a negative control.

This does not prove that a historical K already equals J or k. Some frozen source roles have contragredient actions, while self-dual roles use primal labels; labels alone do not supply their complete component contraction. No frozen coupling is altered and no Gram matrix is silently inserted into M08. The candidate's nine pair types and source grades are explicit; the three prospective nonminimal partners remain unactivated.

## Small decisive algebra

The preregistered selection starts with actual H coordinates 0 and 4, closing under the Lie bracket and Gram-dual pairing. It yields `[0,1,4,11]`, with a nondegenerate restricted Gram matrix. The control has q, c, cbar, lambda and an adjoint scalar p, their canonical evaluation sources, external Abar and independent local parameters omega/beta: **20 canonical pairs, 40 generators and one ordinary derivation**.

This is not the full four-dimensional M08 theory. It has no physical gauge/scalar kinetic or potential action, heavy coset or 328-component scalar. Its minimal source action is `S=sum J_z Qz`. All reverse sources are derived from this action, not separately fitted. The light fermion uses the invariant Gram pairing. A wrong plain-dot fermion has a nonzero background Ward residual.

Both exact routes pass the following:

| Check | Bounded coverage per route |
|---|---|
| Minimal and fixed Q squares | 40 generators in each presentation |
| Cartan relation `{iota,Q}=Tq` | 40 generators before and after fixing |
| Pre-fixing contraction square | 40 generators |
| Quantum/background commutation with Q | 80 pre-fixing and 80 fixed identities |
| Local Lie closure | 124 pre-fixing component equations |
| Local contraction covariance | 80 pre-fixing equations |
| Canonical transport | 40 inverse/intertwining checks; 20 paired brackets and 210 source/source cross-brackets |
| First-jet structural transport | 80 explicit checks; higher ordinary jets follow by prolongation |
| Source master identities | Both presentations modulo independently reconstructed ordinary total derivatives |

All **160 stored columns**—Q before/after fixing, fixed Tq and fixed iota—agree exactly, as do actions, shifts, master currents and decisive controls. Derivatives are created on demand; exceeding the computation safeguard raises an error, never imposes a zero relation. No equation of motion is used.

## Joint-domain theorem, within the control

For independent local parameters and their jets, define local functionals modulo ordinary total derivatives by

`D_pre = ker Tq_omega intersect ker iota_omega intersect ker Tb_beta`.

It is a subspace condition, not an EOM, source-elimination or new IBP quotient. Sigma itself need not be basic. Verified generator identities extend by graded derivation and ordinary prolongation. If F satisfies the joint conditions, then

`iota QF = Tq F - Q iota F = 0`,

`Tq QF = Q Tq F = 0`, and `Tb QF = Q Tb F = 0`.

These operations commute with ordinary differentiation and hence act on the existing total-derivative equivalence. The preservation statement is structural on this declared algebra, not inferred from a few closed samples. It does not prove that this is the physically complete counterterm domain for M08.

The fixed domain is `D_psi=U_psi D_pre`. Q, Tq and iota are conjugated by the same canonical source shift. Tb is transported too, then shown to be unchanged because the candidate fermion is background invariant and the relevant intertwiners pass. Its unchanged form is a tested conclusion here, not a universal default.

The nonzero source-bearing control `F=sum J_lambda p` has dimension 2, ghost number -1 and weight 3. F and its nonzero Q image satisfy all joint constraints before fixing; their transported counterparts satisfy them afterward. Retaining the raw quantum action on the fixed Q image instead produces a nonzero residual. Its p0 Euler derivative at g10=0 is

`-2 D^2 omega0 + D^2 omega1`.

Thus that wrong-domain defect cannot be dismissed as an ordinary total derivative. No EOM or source-zero restriction removes it. Independent-parameter source variation before field-dependent substitution remains mandatory; this control does not replace the earlier composite-parameter comparison.

## Independence and validation

Primary: frozen normalized geometry, exterior variables with SymPy even coefficients, Hamiltonian cotangent lifts and Euler source reconstruction. Replay: 990 freshly reconstructed physical parent commutators, ordered words, independent Euler variation and direct cotangent matrices. No primary model or output is imported by replay. They share conventions/model, Python, SymPy and analyst; neither library/runtime independence nor external specialist verification is claimed.

A development comparison caught a Python integer-power conversion to floating sign factors in replay. It was repaired with exact integers, not a convention change. Floating coefficient records now fail a regression. The prospective source-grade table is also checked against the frozen alphabet. Final evidence is exact and independently frozen before acceptance comparison.

Validation includes fresh byte-identical regeneration of both new outputs, exact comparisons, **36 rejected adversarial claim mutations**, **202 M08 regressions plus 21 governance/custody regressions**, authority coherence, structure-preserving-map and read-only-entry-point audits. The new binding manifest retains all 129 predecessor expectations verbatim and adds the new bounded inputs/evidence; historical hashes are not refreshed.

The final read-only audit receipt in `frozen_source_domain_transport/validation_receipt.json` records metadata inventories before/after, selected bound-byte hashes, process measurements and zero detected audit-time mutations. This is not a complete cryptographic rehash of every workspace file. The first measured fresh audit took about 112 seconds across instrumented stages, with about 111 CPU seconds and a cumulative peak working set of 246 MiB; final timings are in the receipt. The costly primary transport checks were about 28 seconds versus 2.6 seconds for the corresponding word stage. This is not a general speedup forecast. Parse/cache/file-count subdivisions are unmeasured, not guessed. No GPU was used.

The strict historical audit remains exit **2**, with seven original references unresolved and current-state coherence passing. Previous bounded scalar/partial-gauge controls and JCAT/T5 authority are reused as hash-bound evidence, not rebuilt. The unchanged classical Sigma ST identity is historical authority, not requalified as a full new M08 theorem. No pole/projection payload was used for this calculation. Repository-wide `--all` was unnecessary and was not run; no unrestricted validation PASS is claimed.

## Remaining scientific stop boundary

The following still precede a full-M08 replacement:

1. Bind the historical source component/contraction decoder and its canonical map; do not infer it from catalog module labels.
2. Derive the complete physical master action, heavy nonminimal structure, nonsymmetric coset, derived RH and shifted 328-scalar under one convention. The VEV and all composite chain terms must survive.
3. Establish complete quantum/background/partial-gauge identities and domain preservation, including transported sources and independent-parameter semantics.
4. Qualify descent through realization, background packets, full IBP, statistics and conjugation, and determine enlarged-source catalog coverage. Neither existing catalog is silently declared complete for nine pair types.
5. Obtain external semantic review and an explicit versioned authority decision before promotion.

The legacy Sigma, six couplings, 17 images, old exact negative controls and catalogs remain byte-bound unchanged. The authoritative blocker stays `M08_C5_H_BASIC_COCHAIN_QUALIFICATION_PENDING`; its new bounded prerequisites are explanatory, not a second state ledger. HB1/C5, cochain dimensions, complete differentials, ranks, EOM quotient, cohomology, finite C1_GS and every later locked stage remain unexecuted. Commit locally, do not push, and stop here.

## Literature comparators

Canonical field/antifield and gauge-fixing methodology has its standard comparator in [Gomis, Paris and Samuel](https://arxiv.org/abs/hep-th/9412228). The distinction between partial gauge fixing and background gauge fixing is explicit in [Ferrari](https://arxiv.org/abs/1308.6802). Contragredient background sources and partially fixed background matching provide relevant context in [Thomsen](https://arxiv.org/abs/2404.11640). These primary references motivate the architecture and review questions; none certifies the new candidate or its future finite two-loop matching calculation.
