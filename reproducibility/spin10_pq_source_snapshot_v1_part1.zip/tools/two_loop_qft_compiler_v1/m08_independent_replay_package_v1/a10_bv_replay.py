"""Physical Lie matrices and direct source pairing; independent EL routes.

Does not import the primary model, source AST, columns or outputs. Arithmetic
and immutable dependency assumptions are shared and disclosed.
"""
from itertools import combinations
from a10_bv_common import *

def geometry():
    data=read(HERE/'frozen_a10_physical_reconciliation/full_replay.json')
    Q=mat(data['C3_plane_to_parent']);Qi=Q.inv();planes=[]
    for i,j in combinations(range(10),2):
        T=s.zeros(10);T[i,j]=1/s.sqrt(2);T[j,i]=-1/s.sqrt(2);planes.append(T)
    parent=[sum((Q[k,a]*planes[k] for k in IDS if Q[k,a]),s.zeros(10)) for a in IDS]
    f={}
    for a,b in combinations(IDS,2):
        comm=parent[a]*parent[b]-parent[b]*parent[a]
        if not comm:continue
        pv=s.Matrix([s.simplify(s.sqrt(2)*comm[i,j]) for i,j in combinations(range(10),2)])
        value=Qi*pv
        for k,v in enumerate(value):
            v=s.simplify(v)
            if v:f[k,a,b]=v;f[k,b,a]=-v
    rho={}
    for sec in SECTORS:
        plane=[mat(r) for r in data['representation_matrices'][sec]];rho[sec]=[]
        for a in IDS:
            R=sum((Q[k,a]*plane[k] for k in IDS if Q[k,a]),s.SparseMatrix(DIM[sec],DIM[sec],{}))
            rho[sec].append(R.applyfunc(s.simplify))
    return f,rho,Q

def pairing_action(w,f,rho):
    x={n:w.var(n) for n in w.p};images={z:{} for z in w.fields}
    for a in IDS:
        for mu in range(4):
            images[f'B{a}_{mu}']=w.add(w.D(x[f'C{a}'],mu),
                *(w.scale(w.mul(x[f'B{b}_{mu}'],x[f'C{c}']),g*v) for (k,b,c),v in f.items() if k==a))
        images[f'C{a}']=w.add(*(w.scale(w.mul(x[f'C{b}'],x[f'C{c}']),-g*v)
                              for (k,b,c),v in f.items() if k==a and b<c))
    for sec,n in DIM.items():
        work={i:[] for i in range(n)}
        for a,R in enumerate(rho[sec]):
            for (i,j),v in R.todok().items():work[i].append(w.scale(w.mul(x[f'C{a}'],x[f'x_{sec}_{j}']),-g*v))
        images.update({f'x_{sec}_{i}':w.add(*P) for i,P in work.items()})
    R={h:w.add(*(w.scale(w.mul(x[f'C{a}'],x[f'C{b}']),-v)
                  for (k,a,b),v in f.items() if k==h and a in M and b in M and a<b)) for h in H}
    for i in M:
        entries=[(j,h,v) for (j,h,k),v in f.items() if j in M and h in H and k==i]
        images['ub'+str(i)]=w.add(w.scale(x['L'+str(i)],-1),
            *(w.scale(w.mul(x[f'C{h}'],x[f'ub{j}']),g*v) for j,h,v in entries))
        images['L'+str(i)]=w.add(*(w.scale(w.mul(x[f'C{h}'],x[f'L{j}']),g*v) for j,h,v in entries),
            *(w.scale(w.mul(R[h],x[f'ub{j}']),g*g*v) for j,h,v in entries))
    for i in H:images['bar'+str(i)]=w.scale(x['b'+str(i)],-1)
    S=w.add(*(w.mul(x[J],images[z]) for z,J in w.pairs))
    return S,images

def separate_Euler_columns(S,w):
    # Build support buckets, then use the previously qualified independent
    # left-Euler implementation for each individual coordinate.
    buckets={n:{} for n in w.grades}
    for word,c in S.items():
        for n in {n for n,_ in word}:buckets[n][word]=c
    el={n:w.EL(P,n) for n,P in buckets.items()}
    return {n:el[other] for z,J in w.pairs for n,other in ((z,J),(J,z))}

def build(stage=lambda name,fn:fn()):
    f,rho,Q=stage('replay_physical_10x10_Lie_commutators',geometry)
    w=algebra();S,images=stage('direct_source_pairing_action',lambda:pairing_action(w,f,rho))
    columns=stage('separate_coordinate_Euler_variations',lambda:separate_Euler_columns(S,w))
    for z in w.fields:zero(w.add(columns[z],w.scale(images[z],-1)),'direct_forward_'+z,w)
    return {'schema':'A10_INACTIVE_CANONICAL_BV_REPLAY_V1',
        'source_polynomial':rows(S,w),'source_only_columns':{n:rows(P,w) for n,P in sorted(columns.items())},
        'source_nonzero_coefficients':len(S),
        'geometry':{'f':[[*key,str(v)] for key,v in sorted(f.items())],
                    'rho_digests':{sec:[digest(record(R)) for R in rho[sec]] for sec in SECTORS}},
        'geometry_derivation':'all 990 physical 10x10 parent commutators, no stored primary structure constants',
        'status':'PARTIAL_CANDIDATE_STOP_GATE_3_GAUGE_EULER_TRANSLATION',
        'master_equation_checked':False,'source_nilpotence_checked':False,'heavy_canonical_transport_extended':False,
        'Stage_E_reached':False,'sources_activated':False,'adopted':False}
