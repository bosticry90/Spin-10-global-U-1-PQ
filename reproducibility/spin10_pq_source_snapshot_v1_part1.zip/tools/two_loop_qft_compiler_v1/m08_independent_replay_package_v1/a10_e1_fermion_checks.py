"""Adversarial controls for the full E1 replacement and its typed charts."""
from copy import deepcopy
from a10_e1_fermion_common import *

def build(stage=lambda n,f:f()):
    from audit_a10_e1_fermion import adjudicate
    p,r=[read(OUT/(n+'.json')) for n in ('primary','replay')]
    matching=adjudicate(p,r);w=alphabet()
    f={tuple(row[:3]):coefficient(row[3]) for row in read(HERE/'frozen_a10_bv_master/primary.json')['geometry']['f']}
    images=ward_images(w,f,{sec:[s.zeros(n) for h in H] for sec,n in DIM.items()},False)
    parts={n:decode_typed(P) for n,P in p['polynomial_parts'].items()}
    # Remove q_H from D[Abar+q_H] V, preserving Abar. This must fail locally.
    sub={f'B{h}_{mu}':w.var(f'A{h}_{mu}') for h in H for mu in range(4)}
    bad_connection=w.replace(parts['heavy_connection'],sub)
    local=canonical(w.act(w.add(parts['heavy_divergence'],bad_connection),images,parity=0))
    parameter_derivatives={word:c for word,c in local.items() if any(n.startswith('omega') and jets for n,jets in word)}
    assert parameter_derivatives,'OMITTED_qH_CONNECTION_MUST_FAIL_LOCAL_WARD'
    # The original bare bilinear remains a nonboundary exact failure.
    bare=w.add(*(w.scale(w.mul(w.var(f'ub{i}'),w.var(f'L{i}')),-xi/2) for i in M))
    bad=canonical(w.act(bare,images,parity=0));eb=canonical(w.EL(bad,'L13'))
    assert len(bad)==264 and eb
    from a10_stage_e_common import real_witness
    Q=mat(read(HERE/'frozen_a10_bv_master/primary.json')['architecture']['C3_to_plane_field'])
    D={h:s.Matrix(33,33,lambda i,j:f.get((j+12,h,i+12),0)) for h in H}
    real=real_witness(Q,D)
    PM=mat(p['charts']['blocks']['heavy_dual']['physical_projector'])
    assert PM*s.eye(45)[:,1]!=s.eye(45)[:,1],'UNPROJECTED_INPUT_NOT_A_HEAVY_WITNESS'
    assert real['heavy_projection_verified']
    # The canonical source pairing is still identity, while two dual fields use G^-1.
    block=p['charts']['blocks']['heavy_dual'];metric=mat(block['invariant_bilinear'])
    assert metric!=s.eye(33) and mat(block['canonical_pairing'])==s.eye(33)
    # Antilinear real structure preserves the order of Grassmann products.
    # It is not a Hermitian adjoint that reverses odd words.
    conj={}
    def conjugate_block(prefix,ids,C):
        ids=list(ids)
        for a,i in enumerate(ids):conj[prefix+str(i)]=w.add(*(w.scale(w.var(prefix+str(ids[j])),c)
          for (k,j),c in C.todok().items() if k==a))
    C=(Q.inv()*Q.conjugate()).applyfunc(clean)
    for mu in range(4):
        for a in IDS:conj[f'B{a}_{mu}']=w.add(*(w.scale(w.var(f'B{b}_{mu}'),C[a,b]) for b in IDS if C[a,b]))
        for h in H:conj[f'A{h}_{mu}']=w.add(*(w.scale(w.var(f'A{k}_{mu}'),C[h,k]) for k in H if C[h,k]))
    conjugate_block('C',IDS,C)
    dualC=mat(block['conjugation']);lightC=mat(p['charts']['blocks']['light_primal']['conjugation'])
    for pre in ('ub','L'):conjugate_block(pre,M,dualC)
    for pre in ('bar','b'):conjugate_block(pre,H,lightC)
    conjugation_residuals={}
    for name,P in parts.items():
        star=w.replace({word:s.conjugate(c) for word,c in P.items()},conj)
        residual=canonical(w.add(star,w.scale(P,-1)))
        assert not residual,('FERMION_REAL_STRUCTURE',name,rows(residual)[:8])
        conjugation_residuals[name]=[]
    rejected=[]
    for flag in ('historical_equivalence_proved','E2_E5_executed','full_fixed_master_constructed',
      'sources_activated','candidate_adopted','catalog_rebuilt','HB1_C5_run','C1_GS_calculated',
      'external_endorsement','personal_outreach'):
        a,b=deepcopy(p),deepcopy(r);a[flag]=b[flag]=True
        try:adjudicate(a,b)
        except AssertionError:rejected.append(flag)
        else:raise AssertionError('ACCEPTED_FALSE_PROMOTION_'+flag)
    corrupted=deepcopy(r);corrupted['polynomial_parts']['heavy_cubic'][0]['coefficient']='0'
    try:adjudicate(p,corrupted)
    except AssertionError:pass
    else:raise AssertionError('COEFFICIENT_COMPARISON_NOT_ENFORCED')
    return {'schema':'A10_E1_REPLACEMENT_CONTROLS_V1','status':'PASS_E1_ADVERSARIAL_AND_TYPE_CONTROLS',
      'matching_result':matching,'omitted_qH_parameter_jet_residual':rows(parameter_derivatives),
      'bare_pairing_Ward_coefficients':len(bad),'bare_pairing_Euler_L13':rows(eb),
      'real_negative_control':real,'unprojected_input_rejected':True,
      'complete_fermion_real_structure_residuals':conjugation_residuals,
      'conjugation_convention':'antilinear real structure, ordered-product automorphism; no unqualified Hermitian adjoint imposed',
      'canonical_pairing_not_invariant_dual_bilinear':True,'false_promotion_flags_rejected':rejected,
      'changed_cubic_coefficient_rejected':True,'local_light_quantum_variation_is_expected':True,
      'E2_E5_executed':False,'historical_equivalence_proved':False}
