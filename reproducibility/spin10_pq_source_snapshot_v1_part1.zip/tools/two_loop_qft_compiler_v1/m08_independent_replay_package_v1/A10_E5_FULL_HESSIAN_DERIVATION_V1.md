# Full fluctuation Hessian, regulator and Ward identities

Prospective derivation, not completed evidence.

Let S=S0+P, P the actual E2 source-plus-gauge-fixing polynomial. Hold all J,A
fixed and use even directional derivatives delta_h,delta_k, with h_z,k_z of
parity p_z. Their complete bilinear is delta_k delta_h S. For P the replay
uses its qualified field Euler columns plus current:

    delta_h P=sum_z h_z E_z^L(P)+partial_mu Theta_h^mu,
    Theta_h^mu=sum_z h_z partial^L P/partial(partial_mu z),
    delta_k delta_h P=sum_z h_z delta_k E_z^L(P)
                          +partial_mu delta_k Theta_h^mu.

This checks every jet/source/Grassmann coefficient. The h/k family exchange
must reproduce the same bilinear, including the canonical signs when their
odd variables are reordered. No undifferentiated-coordinate-only check is
sufficient for an action with derivative gauge conditions.

For S0 the literal indexed double variation is compared with direct polynomial
polarization. Its geometric kinetic interpretation is

    F_h=D_mu h_Bnu-D_nu h_Bmu,
    F_hk=g([h_Bmu,k_Bnu]+[k_Bmu,h_Bnu]),
    delta^2 L_YM=-1/2 <F_h,F_k>-1/2 <F,F_hk>,
    (Dx)_h=D h_x+g rho(h_B)x,
    (Dx)_hk=g rho(h_B)k_x+g rho(k_B)h_x,
    delta^2 L_x=<(Dx)_h,(Dx)_k>+<Dx,(Dx)_hk>-h_x^T V_xx k_x.

All Lorentz metric weights, fixed embeddings and total x=v+eta are retained.
The potential part reuses the qualified all29/34 second-differential program
as a comparison, without a dense new invariant or operator catalog.

In physical orthonormal gauge/auxiliary coordinates the free Minkowski block
is the actual five-component matrix

    K=[[ -p^2 eta+p^up(p^up)^T, i p^up],[-i(p^up)^T,width]],
    K^-1=[[ -eta/p^2+(1-width)pp^T/(p^2)^2, i p/p^2],
             [-i p^T/p^2,0]].

Use width xi for33 heavy and eta_H for12 light directions. The odd two-field
block in (C,antighost) order is [[0,-p^2],[p^2,0]]. Its inverse carries the
opposite ordered signs. Scalars have p^2-M_ref^2. Fixed parity-preserving
physical/C3 maps transport Hessians covariantly and Green functions
contravariantly; canonical source evaluation pairing remains identity.
Check all643 coordinates and both inverses, never invert physical widths.
Minkowski i0/Wick/IR prescriptions remain explicit formal inputs. No positive
Laplace semigroup is inferred for the whole mixed auxiliary Hessian.

For the UV construction use a source-independent positive covariant heat
cutoff on each actual H field representation, including both sides of the
graded reference Green function. Its flat multiplier is exp(-p_E^2/Lambda^2).
Each Born term is the exact retained trace

    Gamma_1,Lambda,int=(i/2)sum_(n>=1) (-1)^(n+1)/n
                         STr[(G_Lambda delta H)^n].

At each fixed perturbative order all vertices are polynomial and propagators
rational on the IR-regulated nonexceptional domain. The product of heat
factors damps every independent UV loop momentum. This proves finite UV
integrals for every admitted one-loop word; it evaluates neither all finite
amplitudes nor full restored counterterms. Include a separately defined
reference/vacuum/background determinant and its phase/normalization. The
default target retains background-only responses.

For a retained-source source-linear master action, differentiate its complete
functional master identity twice in the integrated fields. The result is a
graded Hessian congruence identity. Source transformations are essential:
QJ contains E_z(S), which cancels the term E_z R_z,ij from nonlinear field
rules. Setting sources or their variations to zero prematurely is invalid.
Differentiating a nonzero regulated master breaking instead leaves its full
Hessian insertion. Derive the regulator breaking before attempting restoration.

The reference and heat cutoff transform under background H, and the closed
Born words transform by similarity: their trace Ward identity is retained.
The quantum BRST operation holds A fixed and generally does not commute with
the cutoff/reference. Its regulated Slavnov identity contains the variation
of the regulated Gaussian kernel and the relevant breaking insertion, not
an automatically vanishing scalar heat-kernel trace.

At g=0 the complete field rules are affine. Thus source terms have identically
zero fluctuation Hessian, but the xi Lambda ub u vertex remains in P. The heat
cutoff commutes with the actual linear Q0 and its derivative jets. Ordinary
source dependence is exactly the affine shift of j, so loop-dependent source
columns vanish in this realized finite-cutoff g=0 normalization. At each
finite polynomial perturbative order source corrections carry nonnegative
powers of g and are divisible by g. This concerns this prescribed ordinary
loop family, not arbitrary insertions or all allowed restored schemes.

Full quantum Ward/ST restoration, general contact mixing, canonical quantum
A5 equivalence, physical IR removal and the complete E5 target remain separate.
