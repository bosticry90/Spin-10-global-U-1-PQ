"""All-component Euler proof in the free skew-matrix tensor algebra.

Keeps B, partial B, x, partial x and second jets independent. No gauge field
is projected out before variation. Ordinary IBP exposes the boundary current.
"""
from itertools import product,permutations,groupby
import sympy as s
from a10_executable_action import contract,digest
from m08_local_functional_ast import add,mul,scalar,field,parameter,derivative,tensor
from m08_indexed_variational import indexed_euler_lagrange,expand_spacetime_derivatives

def normal(node):
    serial=0
    def visit(n,env):
        nonlocal serial
        kind=n['node']
        if kind=='ExactScalar':return [(s.sympify(n['value']),[],set())]
        if kind=='Parameter':return [(1,[('Parameter',n['name'],(),())],set())]
        if kind=='PartialDerivative':
            jets=[]
            while n['node']=='PartialDerivative':
                jets.append(env.get(n['index'],n['index']));n=n['argument']
            assert n['node']=='Field'
            return [(1,[('Field',n['name'],tuple(jets),tuple(env.get(i,i) for i in n['indices']))],set())]
        if kind in ('Field','RepresentationGenerator','KroneckerMetric'):
            return [(1,[(kind,n['name'],(),tuple(env.get(i,i) for i in n['indices']))],set())]
        if kind=='LocalActionTerm':return visit(n['density'],env)
        if kind=='Add':return [v for t in n['terms'] for v in visit(t,env)]
        if kind=='OrderedProduct':
            out=[(1,[],set())]
            for t in n['factors']:out=[(a*b,f+g,bs|cs) for a,f,bs in out for b,g,cs in visit(t,env)]
            return out
        assert kind in ('GroupContraction','LorentzContraction'),kind
        loc=dict(env);bs=set();eta=[]
        for i in n.get('contracted_indices',n.get('summed_indices',())):
            loc[i]='d'+str(serial);serial+=1;bs.add(loc[i])
            if kind=='LorentzContraction':eta.append(('Metric','eta',(),(loc[i],)))
        return [(c,f+eta,b|bs) for c,f,b in visit(n.get('expression',n.get('argument')),loc)]
    out={}
    for coef,factors,bs in visit(expand_spacetime_derivatives(node),{}):
        if not coef:continue
        parent={}
        def root(i):
            parent.setdefault(i,i)
            if parent[i]!=i:parent[i]=root(parent[i])
            return parent[i]
        for k,name,jets,inds in factors:
            if k=='KroneckerMetric':
                assert name=='delta_exact';a,b=map(root,inds);parent[b]=a
        fs=[(k,name,tuple(root(i) for i in jets),tuple(root(i) for i in inds))
            for k,name,jets,inds in factors if k!='KroneckerMetric']
        live={i for _,_,jets,inds in fs for i in jets+inds}
        assert live<={root(i) for i in bs},'UNCONTRACTED_KINETIC_OUTPUT'
        assert {root(i) for i in bs}==live,'UNUSED_KINETIC_DUMMY'
        rho=[i for i,f in enumerate(fs) if f[0]=='RepresentationGenerator']; candidates=[]
        for flips in product((0,1),repeat=len(rho)):
            variant=list(fs);sgn=(-1)**sum(flips)
            for pos,flip in zip(rho,flips):
                if flip:
                    k,name,jets,(a,i,j)=variant[pos];variant[pos]=(k,name,jets,(a,j,i))
            groups=[list(g) for _,g in groupby(sorted(variant,key=lambda f:(f[0],f[1],len(f[2]),len(f[3]))),
                key=lambda f:(f[0],f[1],len(f[2]),len(f[3])))]
            for orders in product(*(permutations(g) for g in groups)):
                labels={};packed=[]
                for k,name,jets,inds in [v for group in orders for v in group]:
                    slots=[]
                    for i in jets+inds:
                        if i not in labels:labels[i]=len(labels)
                        slots.append(labels[i])
                    packed.append((k,name,tuple(slots[:len(jets)]),tuple(slots[len(jets):])))
                candidates.append((tuple(packed),sgn))
        key=min(k for k,_ in candidates);orient={v for k,v in candidates if k==key}
        if len(orient)>1:continue # graph equal to its negative by skew symmetry
        out[key]=s.expand(out.get(key,0)+coef*next(iter(orient)))
    return [[[k,name,list(jets),list(inds)] for k,name,jets,inds in key]+[['coefficient',str(s.simplify(c))]]
            for key,c in sorted(out.items()) if c]

def expected(sector):
    g=parameter('g10');x=lambda i:field('x_'+sector,indices=(i,))
    B=lambda a:field('B',indices=(a,'mu'))
    R=lambda a,i,j:tensor('RepresentationGenerator','rho_'+sector,(a,i,j))
    return contract(add(mul(scalar(-1),derivative('mu',derivative('mu',x('i')))),
        contract(mul(scalar(-1),g,R('a','i','j'),derivative('mu',B('a')),x('j')),('a','j')),
        contract(mul(scalar(-2),g,R('a','i','j'),B('a'),derivative('mu',x('j'))),('a','j')),
        contract(mul(scalar(-1),g,g,R('a','i','j'),R('b','j','k'),B('a'),B('b'),x('k')),('a','b','j','k'))),
        ('mu',),'LorentzContraction')

def qualify(term):
    sector=term['scalar_sector'];free=('output',)
    raw=indexed_euler_lagrange(term,name='x_'+sector,free_indices=free,index_kinds=('generic',),side='left')
    h=field('h_'+sector,indices=free)
    actual=normal(contract(mul(h,raw),free))
    desired=normal(contract(mul(field('h_'+sector,indices=('i',)),expected(sector)),('i',)))
    assert actual==desired,('KINETIC_EULER_GRAPH_MISMATCH',sector,actual,desired)
    return {'sector':sector,'canonical_Euler_AST':raw,'Euler_graph_coefficients':actual,
        'expected_graph_sha256':digest(desired),'identity':'Euler_x=-D_mu D^mu x',
        'expanded_terms':['-Box x','-g rho(partial_mu B^mu)x','-2g rho(B^mu)partial_mu x',
                          '-g^2 rho(B_mu)rho(B^mu)x'],
        'boundary_current':'h^T D^mu x',
        'singlet_specialization':'rho_S=0 gives -Box x',
        'constant_embedding_Euler_chain':'Euler_x=J_ordered^T Euler_ordered, at every jet order',
        'shifted_vacuum':'x=v+eta, partial v=0; vary first, including connection jets; v unchanged'}
