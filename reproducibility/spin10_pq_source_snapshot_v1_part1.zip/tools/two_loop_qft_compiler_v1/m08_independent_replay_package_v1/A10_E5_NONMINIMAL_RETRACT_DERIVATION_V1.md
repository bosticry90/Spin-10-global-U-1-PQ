# Nonminimal retract on the actual local Ward/basic complexes

This concerns polynomial cochains of the inactive gauge/scalar system. It does
not remove fields/sources from an action or define a quantum integral. The
symbols eta, beta below mean an antighost and its auxiliary in the doublet
chart, not one of the 328 physical scalar coordinates.

## 1. Doublet-chart operations and all polynomial degrees

The qualified point-canonical map N sends Stage D to

    S_beta=S_min+sum_(45 pairs) J_eta beta.

All four coordinates are retained for each pair. Source-left conventions give

    Q eta=beta, Q beta=0, Q J_beta=J_eta, Q J_eta=0.
    h beta=eta, h J_eta=J_beta, h eta=h J_beta=0.

Q on the remaining 553 minimal pairs is independent of these doublets. The
48 backgrounds remain external and Q/h-inert. Extend h by odd graded Leibniz
and ordinary derivative prolongation. Define n to count every one of the 180
nonminimal coordinates and each of their jets, all with positive weight one.
Generator calculation gives

    {Q,h}=n, h^2=0, [n,Q]=[n,h]=0, [h,partial_mu]=[n,partial_mu]=0.

These identities extend to all finite-support polynomials by graded derivation.
They do not rely on a finite jet cap. Let p set the doublet coordinates and
their jets to zero IN THIS CHART. For a polynomial F=sum F_k in n degree define

    H F=sum_(k>0) h F_k/k.

All sums terminate; only positive integer constants are divided. H has project
dimension -1, ghost number -1 and odd parity; n and p preserve grades. Thus
QH+HQ=1-p and p^2=p, pQ=Qp. Parameter, field, mass and width denominators never
appear. Source-degree-two and higher polynomials use the same argument.

If QF=0, F-pF=QHF. If QF=sum partial_mu m^mu, then on coefficient densities

    F-pF=QHF+sum partial_mu Hm^mu.

This supplies an explicit local primitive and current. On graded differential
forms one extends h with h(dx)=0 and the corresponding form-degree signs.
The density formula fixes the ordinary-divergence convention used by the code.

## 2. Why the restrictions are preserved

In the beta chart both quantum H and background H act on eta/beta in the same
carrier, and on J_eta/J_beta in its evaluation-dual carrier. Local parameters
are even; their arbitrary jets are retained. Thus [Tq,h]=[Tb,h]=0 on every
generator and, by prolongation, on every ordinary jet.

The transported contraction obeys, in this chart,

    iota eta=iota J_beta=0,
    iota beta=Tq eta, iota J_eta=Tq J_beta,

with the contraction fixing minimal sources/physical fields and shifting C_H
by omega_H. The exact matrices/signs are independently checked. Hence
{iota,h}=0. Qualified Cartan and Q/Ward identities then give [n,iota]=0 and
[n,Tq]=[n,Tb]=0. Equivalently these follow from their homogeneous doublet degree.
It follows that p and H preserve background invariance and the joint domain

    ker iota intersect ker Tq intersect ker Tb.

This remains true for functional kernels modulo ordinary divergences because
h/n/p commute with ordinary partial derivatives and do not act on parameters.
Counterterm grades (4,0,even) map to candidate primitive grades (3,-1,odd).
These mass grades include coefficient dimensions. E1 binds OrbitPullback to
dimension one while its normalized benchmark coefficients are evaluated numbers.
Introduce a real bookkeeping unit v_* of dimension one only on heavy_orbit,
derive the source shifts by left Euler variation, and transport with that
lifted fermion. O^T v=0 removes the constant offset; thus its lift is linear.
For each polynomial coefficient expand in v_*, and count its power in the
mass grade. Specializing v_*=1 must reproduce every frozen source shift,
transformed operator and new control exactly. This is not a new vacuum or
parameter choice. The initial word-only grading attempt omitted this documented
coefficient dimension and failed; its original sources/fingerprint/log are
preserved and excluded from qualified evidence. The repaired checker verifies
the coefficient-aware grades rather than accepting an inhomogeneous word grade.
Lorentz covariance follows from identical scalar spacetime carriers and jet
prolongation. Field/source real structures follow from their qualified carrier
conjugation matrices and the exact invariant bilinears. No Haar averaging,
inverse g or unproved restricted-space homotopy is assumed.

## 3. Complete N and E2 transport

Let C=U N^-1 map beta-chart cochains to the E2 description. The new operations
are h'=C h C^-1, n'=C n C^-1, p'=C p C^-1 and H'=C H C^-1. Q', Tq', Tb and
iota' use the same conjugation of their qualified beta-chart counterparts.
Thus all preceding identities and restriction properties transport. The code
also checks all 1,334 canonical/external columns and local parameter-jet
controls explicitly. Physical Euler programs are unchanged; h fixes all B/x
and never uses their source covectors in its own images, so no physical Euler
term is silently omitted from {Q',h'}.

General graded substitution is required: N and U act on ANY polynomial word,
including multiple source factors. The old source-linear optimization is used
only in its qualified action scope and is not extended here.

In Stage D coordinates h_D sends Lambda/b to minus its antighost, and J_eta
to minus J_Lambda/J_b. It fixes every other generator. Its count is not naive
old-chart variable counting: ghost-source columns include the cotangent
correction produced by N. The post-U source homotopy receives another correction.
For the actual auxiliary bilinears the derived post-U antighost-source column is

    h' J_ub = -J_Lambda - xi G_M^-1 ub,
    h' J_bar = -J_b - eta_H G_H bar.

These coefficients come from the E1 physical pairing/fermion, not fitting a
residual. Widths zero recover the pre-U form but do not establish good quantum
propagators. The count/projector also carry ghost-source and gauge-condition
corrections. In particular

    p_D JC = N^-1 JC,
    p' on a physical source J with antighost-dependent shift A_J gives J+A_J;
    p' J_eta contains minus the surviving gauge condition.

These are cochain maps on the retained alphabet, not an instruction to zero
shifted sources or integrate out auxiliaries. Their images are generated by
553 transported minimal pairs plus backgrounds, which can contain original
nonminimal coordinates in the required combinations.

## 4. h is not a canonical transformation

The source-left bracket on generators is (z,J_z)=(-1)^p_z. In Stage D,
although h_D Psi=0 (the auxiliary antighost square vanishes against its
symmetric bilinear), h_D is not a derivation of the antibracket. Its attempted
bracket derivation on Lambda and J_eta has the exact constant defect 2.
Consequently h_D Psi=0 does not imply [h_D,U]=0.

Keeping the untransported h_D after E2 loses the width source terms. The free
heavy selected Q/h defect is -xi Lambda_44/4 in the J_ub13 column; a light
control is -2 eta_H b0+eta_H b1, retaining G_H's off-diagonal entry. Both full
rows are derived from the physical invariant bilinears, never fitted to the
computed residual. The initial expected light witness omitted that off-diagonal
term and failed; its sources/fingerprint/log are preserved and excluded.
These are adversarial controls, not new physical-action
failures. An odd local HF may generate a canonical counterterm equivalence,
but h itself is just a chain homotopy.

## 5. Nontrivial source and current controls

Simple doublet invariants need not be horizontal: iota beta is nonzero. Use
the actual source carrier matrices D*_h (defined by T J_beta=g D*_h omega_h
J_beta), placing an odd C_H before an odd source in matrix notation. Then

    Y=J_eta-g D*_h C_H^h J_beta

is horizontal and covariant. Its real physical form is
Y_phys=J_eta,phys+g[J_beta,phys,C_H,phys] with the graded bracket. The invariant
primitive K_src=J_beta^T G_source Y is basic, of grades (3,-1,odd), degree two
in nonminimal sources. F_src=Q K_src is a basic (4,0,even) counterterm cochain
with pF_src=0 and HF_src=K_src. It retains the actual heavy-curvature contributions
in QC_H. This tests a meaningful case which a source-linear-only implementation
would reject. Pairing and bracket signs are derived independently in replay.
The final routes freshly reduce Q_beta^2 K_beta and compare the complete
post-U counterterm column with C(Q_beta K_beta). Their post-U closure then
uses the authenticated canonical/master nilpotence proof. The full transported
counterterm square is not freshly re-expanded in the final routes. An earlier
isolated primary tail probe did perform that larger expansion, but it is not
counted as a completed qualification route. No assumption or polynomial degree
is dropped by using the exact conjugacy proof.

Further controls use the actual H-singlet heavy ghost C12 and an evaluation
pair J_beta eta, and ordinary derivative currents. Wrong source-side h and
untransported source shifts must yield exact nonzero residuals. Input grades,
carrier subspaces, real structure and local parameter jets are checked before
these examples count as evidence.

## 6. What is, and is not, identified

This establishes nonminimal cohomology reduction for each admitted full,
background-Ward and joint-basic polynomial complex separately, with its own
primitive space and ordinary-boundary convention. It applies to densities and
local functionals. Intrinsic basic exactness and intersection with full exact
terms reduce to their respective MINIMAL questions; they are not equated.
The coupling-ring obstruction and quantum-target exclusions remain intact.

For W6 this proves a lemma about its algebraic Q'/Tb component, conditional on
the stated target. Quantum source/insertion normalization and canonical
equivalence remain A4/A5; no nonlinear mean-field substitution is inferred.
Full E5, regulator/QAP/anomaly obligations, catalogs and matching remain open.

[Barnich, Brandt and Henneaux](https://arxiv.org/html/hep-th/0002245), sections
2.6-2.7, supply the established doublet method. The project-specific extension
here checks the actual sources, Ward/basic restrictions, physical frame metrics,
local jets and E2 transport. Shared assumptions/data/software/analyst and lack
of external endorsement are disclosed; no proof-kernel certification is claimed.
