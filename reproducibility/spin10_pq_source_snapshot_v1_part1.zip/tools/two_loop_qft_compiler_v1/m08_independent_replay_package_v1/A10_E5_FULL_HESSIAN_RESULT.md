# Complete retained-source Hessian and finite-cutoff loop prerequisite

## Scientific disposition

**QUALIFIED_E5_COMPLETE_HESSIAN_AND_FINITE_CUTOFF_ONE_LOOP_PREREQUISITE_ONLY**.
The complete inactive E2 gauge/scalar action now has independently matching
graded second-variation programs and a verified 643-field reference inverse.
A source-retaining, UV-finite one-loop Born family is defined on the declared
formal Wick/IR domain. An exact nonexceptional ghost loop and a nonlinear
finite-dimensional source/Slavnov control support that construction.

This is a completed prerequisite, not full quantum restoration or E5. The
complete nonzero-g Ward/ST breaking, its local restoration, general probe and
contact identities, quantum A5 equivalences, continuum measure/anomalies and
physical IR removal remain unproved. No new physical prediction or finite
C1_GS matching calculation is produced.

Baseline 2f1bdf2 was clean, with no matching calculation worker. The actual
34 physical terms, nine source terms and E2 gauge-fixing correction are used;
the preceding failed fractional action kernel is not adopted. All 643 pairs,
48 external H backgrounds, 328 scalar coordinates, potential parameters,
heavy/light nonminimal fields and nonsymmetric/composite R_H structure remain.
State v113/34 of39 is unchanged. Twenty-four predecessor chains are reused
and authenticated; earlier expensive calculations are not freshly repeated.

## Complete second variation

Write S=S0+P, with P the full 68,254-monomial source/gauge-fixing polynomial.
Introduce two independent graded test families h,k, of each field's parity.
These are temporary directions, not extra physical fields or canonical pairs.
Sources and backgrounds are fixed only during fluctuation differentiation.
Their full symmetry transformations remain in the Ward/Slavnov calculations.

Primary directly differentiates every factor twice with Grassmann sorting.
Replay differentiates the qualified field Euler columns and the complete
first-variation current:

    delta_h P = sum_z h_z E_z^L(P) + partial_mu Theta_h^mu,
    delta_k delta_h P = sum_z h_z delta_k E_z^L(P)
                              + partial_mu delta_k Theta_h^mu.

The boundary current is essential: omitting it gives a nonzero density.
Both complete records agree, including graded h/k symmetry. Every coefficient
is traversed in a canonical row stream; hashes/counts/block profiles record
the whole stream. Four displayed sample rows are not used as coverage.

| Compared program | Exact coefficients |
| --- | ---: |
| Complete source and gauge-fixing second variation | 354,321 |
| Source degree zero | 281,103 |
| Source degree one | 73,218 |
| Complete g=0 polynomial second variation | 2,455 |
| All 34 physical-term differential graphs | 391 |

The complete second-variation stream SHA256 is
`c7cfd5bd5de039bcca405cd42c5dd4b285b45fc52702c49eb1a71521d7754cdf`.
The source stream SHA256 is
`980a05d2f897bb44c3a3f6a2c52142cb2e4137bdd3c96a1ad9dc283a3a04c982`.
The g=0 stream SHA256 is
`dcd904b03980ad70a70b61228f1b6343648ebf9b1f83519f4dbed14cce22f068`.

Physical primary indexed differentiation and replay ordinary two-variable
polynomial differentiation preserve the literal Lorentz weights, jet symmetry,
fixed representation tensors and x=v+eta. The 60 kinetic graphs and 331
potential graphs include every 29 potential direction and 34 real parameter.
The potential matches the previously qualified positive-V Hessian with the
physical action's minus-V sign. This is an executable factorized program;
it is not an expanded operator/interaction catalog.

## Full reference, with auxiliaries retained

There are 553 even and 90 odd integrated coordinates. The 643 sources and
48 backgrounds remain external. In physical gauge/auxiliary coordinates,
each of the 45 free blocks is

    K = [[-p^2 eta+p^up(p^up)^T, i p^up],[-i(p^up)^T,width]],
    G = [[-eta/p^2+(1-width)pp^T/(p^2)^2, i p/p^2],
                                         [-i p^T/p^2,0]].

Width is eta_H in 12 light directions and xi in 33 heavy directions. The
determinant is -(p^2)^4. The ghost/antighost block, in that order, is
[[0,-p^2],[p^2,0]], with inverse [[0,1/p^2],[-1/p^2,0]]. All four scalar
sectors have their temporary p^2-Mref^2 reference, subtracted exactly in
delta H; the physical potential and parameters do not change.

Constant parity-preserving C3/physical maps transport the kernel and inverse.
Both inverse directions are verified over all 643 coordinates. The literal
free gauge-fixing Fourier Hessian agrees in all 413,449 matrix entries,
including zeros. All 45 auxiliary-auxiliary Green components are zero.
No ghost or auxiliary is eliminated; neither a physical width nor g is
inverted. The canonical field/source evaluation pairing remains identity.

The reference determinant retains 45 log(p_E^2) plus the scalar half-log
sum, its scale normalization and constant Wick/contour phase. A separate
background-dependent reference determinant must also be retained. There is
no claim that the whole mixed ghost/auxiliary Hessian is a positive Laplace
operator. Positive scalar references and a temporary H-covariant IR spectral
restriction define a formal domain; physical zero-mode/IR existence is open.

## Finite UV prescription and its actual obligations

On each actual residual-H carrier use F_Lambda=exp[-(-Dbar_H^2)/Lambda^2].
The regulated Green program is G_Lambda=F_Lambda Gref F_Lambda^ST, with the
graded dual action on the right. Define interaction one-loop words by

    Gamma_1,Lambda,int = (i/2) sum_(n>=1) (-1)^(n+1)/n
                                      STr[(G_Lambda delta H)^n],
    delta H = H_full-H_ref.

All source, ghost, scalar, gauge and nonminimal mixing remains in H_full.
At fixed perturbative order, vertices are polynomial and propagators rational
on the stipulated IR domain. Heat factors suppress every UV loop momentum.
This establishes finite UV integrals for the defined one-loop word family,
not the evaluation of every finite amplitude or a renormalization theorem.
Gamma_ref,Lambda[background] is recorded separately; background-only responses
are not normalized away.

The full background covariance follows structurally from congruence of the
Hessian/reference and covariant heat factors: closed words transform by
similarity. At nonzero g, quantum BRST generally fails to commute with these
reference/cutoff choices. Its Gaussian-kernel variation and any IR/mode
projection contribute to a regulated breaking insertion. No unmodified
finite-cutoff Slavnov PASS is claimed.

This separation accords with the roles of regularization, retained antifields,
measure and counterterms in [Troost and Van Proeyen, sections 4–5](https://arxiv.org/html/hep-th/9307126).
Their Pauli–Villars construction is a comparison, not adopted new fields.
[Igarashi, Itoh and So](https://arxiv.org/html/hep-th/0109202) likewise distinguish
regulated master identities from an unregulated identity. Their Wilsonian
architecture is not silently identified with this one-loop 1PI construction.
Neither publication independently certifies these project calculations.

## Retained sources: decisive nonlinear control

Differentiating the complete classical master functional twice supplies the
graded Hessian congruence identity. The physical-source transformation QJ
cancels terms E_z R_z,ij from nonlinear field transformations. Freezing QJ
would invalidate the calculation even though J is external in the Hessian.

A distinct five-field, five-source control makes this explicit. With even
x,y,b and odd c,bar, take R_x=cy,R_y=-cx,R_c=0,R_bar=-b,R_b=0,
V=(x^2+y^2)^2 and Psi=bar(xy-b/2). Its full source-linear action has zero
master residual and zero lifted Hessian congruence residual. Freezing source
variations gives 20 nonzero defect coefficients.

Adding r*x^2/2 gives the genuine tree breaking r*c*x*y. The full graded
Gaussian inverse retains all auxiliary/source variables and four independent
odd nilpotent variables. Primary finite Neumann inversion and replay graded
Gauss–Jordan inversion agree. At x=1,y=2,b=0, off shell, the one-loop Slavnov
variation and the Hessian breaking insertion both equal

    [2 r (75-2r)/(3(51r+1028))] c.

Their difference is exactly zero while each is generally nonzero. Incorrect
source freezing fails. This demonstrates the insertion relationship and sign
conventions in a nonlinear control; it does not replay a full-size Spin(10)
amplitude or prove its restored identity.

## Actual zero-coupling ghost loop

The g=0 source Hessian is zero because the complete field rules are affine.
All 73,218 source-Hessian coefficients have at least one g: 68,202 have
minimum power one and 5,016 power two. The source-independent reference has
no inverse g. Thus ordinary source loop corrections in this finite-order Born
family vanish at g=0 and are divisible by g. This is not an exclusion theorem
for arbitrary counterterms, composite probes, contacts or all restored schemes.
The named unweighted polynomial obstruction and quantum A5 remain distinct.

The surviving xi*Lambda*ub*u vertex is retained. Its second variation accounts
for 1,656 cubic coefficients in addition to 799 quadratic coefficients.
The full zero-coupling theory is not Gaussian.

For F(p)=exp(-p_E^2/Lambda^2), the actual two-vertex ghost bubble is

    I_Lambda(q) = integral d^4k/(2pi)^4
           exp[-2(k^2+(k+q)^2)/Lambda^2]/[k^2(k+q)^2], q^2>0.

Primary Gaussian/Schwinger integration and replay lower-limit differentiation
give, with c=2q^2/Lambda^2,

    I_Lambda = [E1(c)-E1(c/2)/2
                          +(exp(-c/2)-exp(-c))/c]/(8pi^2).

Its logarithmic coefficient is 1/(16pi^2). Subtracting log(Lambda^2/mu^2)
leaves [log(mu^2/q^2)+1-EulerGamma-log4]/(16pi^2). The finite difference
from the earlier analytic-MS bubble is local: (EulerGamma+log4)/(16pi^2).
The exact closed-ghost sign and actual 33-coordinate kappa give the
Minkowski pole +xi^2 log(Lambda^2/mu^2) Lambda^T kappa Lambda/(32pi^2).
Both routes freshly check Q0(ub^T kappa Lambda)=-Lambda^T kappa Lambda,
so the opposite pole subtraction has a source-free BRST primitive.
Auxiliaries remain; their zero self-propagator prevents unwanted auxiliary
loop contractions. q=0 is IR divergent and excluded from this result.

## Execution recovery and validation

All completed science outputs are preserved. Four preflight dispositions are
retained and excluded from PASS evidence: an unfinished generic dense inverse,
a polynomial-versus-factored determinant assertion, an old replay-record
layout assumption, and SymPy's unevaluated E1 limit. The first is an execution
limitation; the other three are representation/assertion failures. No new
scientific counterexample is inferred from them.

An exploratory regression run was also stopped during test19 after tests01–18
passed: its old auditor repeatedly simplified already identical large records.
The exact-first comparison now avoids that redundant work and still applies
the same rational check to any differently printed coefficient. The unfinished
run is excluded. Its test file, reconstructed pre-optimization comparison
implementation and disposition are retained; there was no start fingerprint
for that exploratory test, so it is not an authenticated execution route.

The qualified constant-frame inverse replaces the unnecessary dense inversion.
Only verified owned unfinished workers were stopped. The completed primary
retains its original helper binding; the repaired helper accesses the common
sealed architecture, whose inverse agrees with replay in both directions.
The heat primary likewise retains its pre-limit-repair module binding. The
replay's E1 limit is justified by E1(z)<=exp(-z)/z for z>0 and an explicit
exponentially vanishing bound. Fresh routes must bind current code strictly
and reproduce the original completed bytes; exceptions apply only to the two
specifically archived original execution fingerprints.

The validation receipt records 299 targeted regressions: 254 scientific
(20 new and 234 inherited), 24 process and 21 governance. Two fresh logical
routes regenerate four artifacts byte-identically. The 24 sealed predecessor
chains, protected SHA256 bytes, state bytes, new bounded files and read-only
metadata inventory are checked. Metadata means size/mtime, not unrestricted
environment byte identity. Generic research_check e5 remains an older delegated
bounded audit; the named full-Hessian auditor validates this increment.
Historical custody still exits 2 with seven unresolved references.

Both routes share immutable geometry, action/source conventions, word
arithmetic, Python 3.10.11, SymPy 1.14, assumptions and analyst. Distinct
derivations and controls support reproducibility, not external endorsement.
No source activation/removal, parameter change, auxiliary elimination, catalog,
HB1/C5, C1_GS, matching, authority promotion, outreach, publication or push.

## Next smallest scientific action

Use this complete Hessian to derive the actual nonzero-g one-loop local
Ward/Slavnov breaking and restoration equations, including the regulator,
reference determinant and local insertion/contact normalization. Independently
verify a nontrivial source-containing Spin(10) channel before general claims.
Keep the g=0 ordinary-source normalization distinct from quantum A5 and from
general cochain admissibility. Stop on the first unjustified residual.

The full Spin(10)xU(1)PQ investigation remains active and incomplete. Full E5,
M2–M5/A1–A5, physical IR, fermion/Yukawa completion, global potential
boundedness, PQ quotient and phenomenological comparisons remain obligations.
