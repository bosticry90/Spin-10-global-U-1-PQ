# Polynomial regularity and resolution: derivation V1

This proves a property of the inactive, ungauge-fixed gauge/scalar action.
All coordinates below are independent real plane coordinates. The constant
C3 change of frame and its cotangent map transfer the result without changing
the canonical evaluation pairing. This is not a proof of quantum restoration
or a comparison theorem for the joint basic domain.

## 1. Principal operator and lower-order terms

Put eta=(1,-1,-1,-1). Direct variation of -F^2/4 gives

    E_B^nu = sum_mu eta_mu eta_nu (B_nu,mu mu - B_mu,mu nu) + lower jets.
    E_x    = -x,00 + sum_i x,ii + lower jets.

The gauge formula holds separately in all 45 orthonormal internal directions;
the scalar formula holds in all 328 real coordinates. The qualified action is
exactly this gauge term, four canonical covariant scalar kinetics and the 29
potential terms. In its Euler expressions the non-Abelian and scalar-current
terms have at most one derivative in total, and potential terms have none.
Consequently a prolongation D_alpha of those terms uses jets of order at most
|alpha|+1, below the principal order |alpha|+2. This is an action-specific fact,
not an assumption about an arbitrary invariant density. A constant vacuum shift
does not change it. Exact representation/potential and Euler certificates are
authenticated dependencies; their full expansions are not repeated.

## 2. An all-order equation/jet chart

At order r>=2 choose independent equation coordinates

    D_alpha E_B^i,a, i=1,2,3, |alpha|<=r-2;
    D_alpha E_x^I, I=1,...,328, |alpha|<=r-2;
    D_alpha E_B^0,a, alpha spatial, |alpha|<=r-2.

Their selected original jets z are respectively

    B_i^a,(00 alpha);  x^I,(00 alpha);  B_0^a,(11 alpha_spatial).

All other jets are y. Sort by total order; within an order sort spatial-gauge
and scalar pivot jets by their number of temporal derivatives, and temporal
gauge pivot jets by their number of 1 derivatives. Place the temporal-gauge
block after the other blocks. The selected coefficient is always -1.

Every same-order off-diagonal pivot in a spatial-gauge or scalar row has two
fewer temporal derivatives. A B_0 jet containing a time derivative is free,
so the mixed B_0,0i term never creates a temporal-gauge pivot in these rows.
In an E_B^0 row the mixed B_i,0i jets have only one time derivative and are free;
the other temporal-gauge pivots have two fewer 1 derivatives. All interactions
are already resolved at a lower total order. Thus each equation is

    L_A = -z_A + P_A(y,z_<A),

with polynomial P_A. Recursively z_A=-L_A+P_A(y,z_<A) is a polynomial inverse.
At any finite order there are finitely many steps; every finite-support local
polynomial is therefore covered. This induction, rather than a finite rank
test, establishes all ordinary jets. No division by g10, masses, fields or
potential coefficients occurs. The chart is not Lorentz covariant; its purpose
is to establish existence of regular coordinates, not choose a physical gauge.

The counts are

    total equations      = 508 binom(r+2,4),
    independent equations= 463 binom(r+2,4)+45 binom(r+1,3),
    dependent equations  = 45 binom(r+1,4).

The Pascal identity relates these counts. Counts do not supply the proof.

## 3. Completeness and irreducibility of the Noether identities

Use the qualified off-shell gauge Noether identities in the plane frame,

    N_a = D_nu E_B,a^nu + g10 sum_s E_x,s^T rho_a x_s = 0.

The dependent equations are precisely D_alpha partial_0 E_B^0,a. In
D_alpha N_a their coefficient is the identity. Other dependent equations in
that row have a strictly lower prolongation order: they come from derivatives
of algebraic field coefficients multiplying E. The remaining terms are
independent equation coordinates. The finite-order Noether matrix is therefore
unit triangular; its inverse is a finite polynomial geometric sum.

In the coordinates (y,L_ind), L_ind are independent polynomial generators.
Their only polynomial syzygies are the Koszul relations
L_A e_B-L_B e_A. This follows by eliminating one polynomial generator at a time
(equivalently the contraction in section 4); it holds over the physical
parameter ring and exterior ghost algebra because even polynomial generators
form a regular sequence over those spectator coefficients. Reducing a relation
among all equations through the unit-triangular Noether matrix leaves just
these trivial antisymmetric equation multiples. Thus the 45 gauge identities
and their derivatives are complete modulo trivial identities, and introduce
no independent higher-stage identities. This includes g10=0.

Global PQ conservation is a first-theorem current, not an extra off-shell local
identity. For the canonical singlet real pair (x,y), q=-4, a local PQ variation
of (partial x)^2/2+(partial y)^2/2 has parameter Euler derivative

    q (y Box x - x Box y),

which is not identically zero. The potential is PQ neutral, so it cannot cancel
this derivative term. A constant parameter test misses it. No 46th gauge ghost
or extra Noether antifield is introduced. This does not determine the global
PQ quotient, axion topology, or anomalies.

## 4. Koszul-Tate contraction in the stated source-left convention

Set delta=0 on original fields, ghosts and spectator backgrounds; set
delta J_B=E_B and delta J_x=E_x. Extract the ghost-antifield column of the
qualified source action at antifield number one. It has positive divergence
of J_B under the actual left-derivative convention. Its coefficients are the
Noether covector N with E replaced by J, not a guessed literature sign.
Thus delta JC_a=v_a and delta v_a=N_a=0. Prolong every column by ordinary D.

Keep the independent physical antifield jets u_A (delta u_A=L_A). Replace each
dependent gauge antifield jet by v_alpha=D_alpha(delta JC). The same unit
triangular matrix as in section 3 makes this antifield change polynomially
invertible. The complete minimal differential becomes

    delta = sum_A L_A partial/partial u_A + sum_alpha v_alpha partial/partial JC_alpha.

Here u and v are odd, L and JC are even, and antifield numbers are 1,1,0,2.
The odd homotopy h=L-to-u plus v-to-JC obeys {delta,h}=N, where N counts every
variable in these pairs. It is checked on the four generators and extended by
graded derivation. Decompose a finite polynomial into N-homogeneous terms.
For a closed term of positive antifield number its primitive is h(term)/N.
Only positive integer constants are divided; polynomiality and finite support
are preserved. H_m(delta)=0 for m>0 and H_0 is the stationary-surface quotient.
No boundary integrations are used: this is H(delta), not H(delta modulo d).

## 5. Nonminimal and canonical transport scope

For each of the 45 antighosts eta define beta=Q eta. In the heavy block
beta=-Lambda+v(C_H,eta), and in the light block beta=-b. The auxiliary coefficient
-1 gives a polynomial inverse; Q beta=0 follows from the qualified off-shell
field algebra and is independently checked. The cotangent lift must also
transform the ghost and antighost sources with their graded left signs.
For this bracket the odd generating functional is
sum_z (-1)^p_z J_new,z f_z(old fields), with
J_old,z=(-1)^p_z Euler_left_z F. Its identity limit is J_old,z=J_new,z.
It fixes the cross-source signs rather than importing an ungraded cotangent map.
After this map the full source action is S_min+sum_eta J_eta beta.

These are genuine doublets (eta,beta) and (J_beta,J_eta), with the canonical
sign in Q J_beta derived by left differentiation. Their counting homotopy
removes this contractible block in the unrestricted polynomial BRST complex.
It does not authorize dropping sources in an action or in a Ward/basic domain.
One may extend delta with transported weights eta=1,beta=0,J_eta=0,J_beta=1;
the extension is contractible. These weights are distinct from ghost number
and from physical engineering dimensions. Conjugating by the already qualified
E2 map transports this resolution with its filtration to the retained-source
gauge-fixed system. It need not be the naive antifield component in its old
chart. Backgrounds remain spectators and all 643 canonical pairs remain present.

## 6. Normality and the unproved next bridge

For the minimal ungauge-fixed complex use K=total ordinary derivative number
plus weight 2 for J_B,J_x and weight 3 for JC. Delta never increases K. Its
K-preserving part is free Maxwell plus 328 free Klein-Gordon resolutions;
all matter, non-Abelian and potential terms strictly decrease K. The free
triangular chart is homogeneous in this K and supplies its positive-degree
contraction. Hence the admitted action has this polynomial normality property.
This verifies the relevant regularity/normality input, not every hypothesis
of an anomaly or counterterm theorem.

The full-complex homotopy above is not asserted to preserve Lorentz invariance,
the joint Ward/insertion target, contraction horizontality, or their allowed
primitive space. H(delta modulo d), characteristic/global-current cohomology,
and full/basic intrinsic/induced comparison require separate arguments. W1-W7
still assume A1-A5. Those distinctions prevent this result from being labeled
full E5 or quantum consistency.

The established comparison is [Barnich, Brandt and Henneaux](https://arxiv.org/html/hep-th/0002245),
sections 5.1-5.2 and 6.4.3. The project-specific proof here identifies the actual
constant pivots, polynomial ring, source-left sign, spectator inputs, global
PQ distinction, and canonical nonminimal extension. Numerical samples and
multiple AI instances do not replace these assumptions or outside endorsement.
