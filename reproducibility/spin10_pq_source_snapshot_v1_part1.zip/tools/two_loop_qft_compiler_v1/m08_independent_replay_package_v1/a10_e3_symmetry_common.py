"""Typed residual-H operators and inactive E3 evidence, not an H-basic domain."""
from a10_e2_transport_common import (HERE,ROOT,read,mat,clean,rows,canonical,decode_typed,
 alphabet,register,xi,etaH,s,g,DIM,H,M,IDS,ETA,digest,source_data,shift_correction,
 PREDECESSORS as E2_PREDECESSORS,partials)
from a10_e1_fermion_common import euler_columns,ward_images
from a10_bv_integration_common import derivative_action
from hashlib import sha256

OUT=HERE/'frozen_a10_e3_symmetry'
STATUS='PASS_BOUNDED_INACTIVE_E3_QUANTUM_BACKGROUND_CONSISTENCY'
NAME='M08_E3_QUANTUM_BACKGROUND_SYMMETRY_INACTIVE_V1'
PREDECESSORS=(*E2_PREDECESSORS,'frozen_a10_e2_transport')

class Obstruction(Exception):
    def __init__(self,label,P,name=None):
        self.evidence={'status':'STOP_E3_EXACT_REQUIRED_IDENTITY','identity':label,
          'generator':name,'residual':rows(P),'first_exact_coefficient':rows(P)[:1]}
        super().__init__(label+' '+str(name)+' '+str(self.evidence['first_exact_coefficient']))

def zero(P,label,name=None):
    P=canonical(P)
    if P:raise Obstruction(label,P,name)

def inputs(route):
    w=alphabet()
    for h in H:register(w,f'beta{h}',(0,0,0))
    old,cols=source_data(route)
    e1=read(HERE/f'frozen_a10_e1_fermion/{route}.json')
    e2=read(HERE/f'frozen_a10_e2_transport/{route}.json')
    psi=w.add(*(decode_typed(P) for P in e1['polynomial_parts'].values()))
    A={n:decode_typed(P) for n,P in e2['source_shifts'].items()}
    fixedcols={n:decode_typed(v['source_polynomial']) for n,v in e2['complete_columns'].items()}
    S1=decode_typed(old['source_polynomial']);delta=decode_typed(e2['gauge_fixing_density'])
    return w,old,e1,e2,cols,psi,A,fixedcols,S1,delta

def act(P,w,I,route,parity=0):
    if route!='primary':return canonical(derivative_action(P,w,I))
    # Prefix Leibniz route: collect all replacements before expanding their
    # coefficients. Canonicalize each concatenated graded word once, with
    # the same odd-inversion and repeated-odd rules as the frozen engine.
    if not hasattr(w,'_e3_act_caches'):w._e3_act_caches={};w._e3_word_cache={}
    owner,cache=w._e3_act_caches.setdefault(id(I),(I,{}));assert owner is I
    out={}
    for word,c in P.items():
        prefix=0
        for pos,v in enumerate(word):
            if v not in cache:cache[v]=w.dword(I.get(v[0],{}),v[1])
            for replacement,d in cache[v].items():
                raw=word[:pos]+replacement+word[pos+1:]
                if raw not in w._e3_word_cache:
                    odd=[z for z in raw if w.p[z[0]]]
                    sign=0 if len(odd)!=len(set(odd)) else (-1)**sum(a>b for i,a in enumerate(odd) for b in odd[i+1:])
                    w._e3_word_cache[raw]=(tuple(sorted(raw)),sign)
                key,sign=w._e3_word_cache[raw]
                if sign:out[key]=out.get(key,0)+sign*(-1)**(parity*prefix)*c*d
            prefix+=w.p[v[0]]
    return canonical(w.add(out))

def generator(fields,w):
    return canonical(w.add(*(w.scale(w.mul(w.var(J),fields[z]),-(-1)**w.p[z]) for z,J in w.pairs)))

def Hamiltonian_lift(fields,w):
    gen=generator(fields,w);el=euler_columns(gen,w,list(w.grades))
    out={}
    for z,J in w.pairs:
        out[z]=canonical(w.scale(el[J],-(-1)**w.p[z]))
        out[J]=canonical(w.scale(el[z],(-1)**w.p[z]))
        zero(w.add(out[z],w.scale(fields[z],-1)),'ODD_WARD_GENERATOR_FIELD_COLUMN',z)
    return out,gen

def cotangent_lift(fields,w):
    out={z:canonical(P) for z,P in fields.items() if z in w.fields};bucket={J:[] for z,J in w.pairs}
    sources=dict(w.pairs)
    for z,P in out.items():
        for word,c in P.items():
            for pos,(n,jets) in enumerate(word):
                if n in w.fields:
                    assert not jets and w.p[n]==w.p[z]
                    bucket[sources[n]].append(w.scale(w.mul(w.var(sources[z]),{word[:pos]+word[pos+1:]:c}),-1))
    out.update({J:canonical(w.add(*P)) for J,P in bucket.items()});return out

def full_operator(canonical_columns,external,w,background):
    return canonical_columns|{n:(P if background else {}) for n,P in external.items()}

def transport(T,A,w,route):
    out=dict(T);correction={}
    for z,J in w.pairs:
        correction[J]=canonical(w.add(shift_correction(T[J],A,w),w.scale(act(A[J],w,T,route),-1)))
        out[J]=canonical(w.add(T[J],correction[J]))
    return out,correction

def divergence(current,w):return canonical(w.add(*(w.D(P,mu) for mu,P in enumerate(current))))

def parameter_sub(P,w,values,prefix='omega'):
    return canonical(w.replace(P,{prefix+str(h):v for h,v in zip(H,values)}))

def local_algebra(Tq,Tb,Dq,w,f,route,stage):
    beta={f'omega{h}':w.var(f'beta{h}') for h in H}
    qb={n:canonical(w.replace(P,beta)) for n,P in Tq.items()}
    bb={n:canonical(w.replace(P,beta)) for n,P in Tb.items()}
    parameter=[w.add(*(w.scale(w.mul(w.var(f'beta{b}'),w.var(f'omega{c}')),g*v)
      for (a,b,c),v in f.items() if a==h and b in H and c in H)) for h in H]
    qbr={n:parameter_sub(P,w,parameter) for n,P in Tq.items()}
    bbr={n:parameter_sub(P,w,parameter) for n,P in Tb.items()}
    total=0
    for label,first,second,expected in [('quantum',qb,Tq,qbr),('background',bb,Tb,bbr),('mixed',bb,Tq,qbr)]:
        def check():
            nonlocal total
            for n in sorted(set(second)|set(first)):
                P=w.add(act(second[n],w,first,route),w.scale(act(first[n],w,second,route),-1),w.scale(expected[n],-1))
                zero(P,'LOCAL_H_'+label,n);total+=1
        stage('local_'+label+'_Lie_all_canonical_and_external_columns',check)
    return {'all_generator_local_Lie_checks':total,'independent_parameters':['omega','beta'],
      'bracket_parameter':'g10 [beta,omega]_H','all_three_residuals_zero':True,
      'parameter_derivatives_retained':True,'domain_or_catalog_qualification':False}

def physical_certificate(e2):
    return {'operation':'differentiate the authenticated physical functional Ward identity under the affine zero-jet H field map: T E=-M^T E',
      'physical_slots':508,'program_unchanged':True,'physical_program_sha256':digest(e2['physical_Euler_program']),
      'all_45_physical_Noether_dependencies_authenticated':True,'H_restriction':12,
      'background_absent_from_S0':True,'H_vacuum_stabilizer_dependency':12,
      'fresh_exhaustive_physical_Euler_expansion':False,'EOM_used':False,
      'scope':'formal covector theorem plus exact qualified physical dependencies; separately challenged by full physical exterior replay'}

def calculate(route,fields,external,f,w,old,e1,e2,cols,psi,A,fixed,S1,delta,stage,method):
    canonical_columns,gen=stage('complete_1286_geometric_cotangent_columns',lambda:
      Hamiltonian_lift(fields,w) if route=='primary' else (cotangent_lift(fields,w),generator(fields,w)))
    Tq=full_operator(canonical_columns,external,w,False)
    Tb=full_operator(canonical_columns,external,w,True)
    W=stage('local_quantum_fermion_breaking_with_parameter_jets',lambda:act(psi,w,Tq,route))
    assert W,'EXPECTED_LIGHT_QUANTUM_BREAKING_ABSENT'
    zero(act(psi,w,Tb,route),'BACKGROUND_FERMION_WARD')
    assert len(W)==e1['local_Wards']['light_quantum_expected_breaking']['coefficients']
    old_Ward=stage('complete_old_source_action_quantum_Ward',lambda:act(S1,w,Tq,route))
    zero(old_Ward,'OLD_SOURCE_WARD_quantum')
    assert all(not n.startswith('A') for word in S1 for n,jets in word)
    assert all(Tq[n]==Tb[n] for n in w.grades)
    # S1 has no external background dependence and both geometric operators
    # have identical canonical columns. Reuse the exact result, not a second
    # expensive evaluation of the same polynomial.
    zero(old_Ward,'OLD_SOURCE_WARD_background')
    def baseline():
        for n in w.grades:
            zero(w.add(act(Tq[n],w,cols,route,1),w.scale(act(cols[n],w,Tq,route),-1)), 'PRE_Q_T_POLYNOMIAL_COLUMN',n)
    stage('all_1286_pretransport_BRST_residual_H_columns',baseline)
    qprime,Dq=stage('all_quantum_H_source_transport_columns',lambda:transport(Tq,A,w,route))
    bprime,Db=stage('all_background_H_source_transport_columns',lambda:transport(Tb,A,w,route))
    from a10_e1_fermion_replay import direct_euler
    EW=stage('independent_variational_quantum_source_correction',lambda:
      direct_euler(W,w,set(w.fields)) if route=='primary' else euler_columns(W,w,list(w.fields)))
    for z,J in w.pairs:
        zero(w.add(Dq[J],w.scale(EW[z],-(-1)**w.p[z])), 'QUANTUM_TRANSPORT_VS_BREAKING_COVECTOR',J)
        zero(Db[J],'BACKGROUND_TRANSPORT_CORRECTION',J)
        zero(w.add(bprime[J],w.scale(Tb[J],-1)),'BACKGROUND_OPERATOR_FIXED_BY_U',J)
    # The quantum generator transported through the same source tables must
    # give the same complete operator, including derivative kernels.
    gen_fixed=w.add(gen,shift_correction(gen,A,w))
    gel=stage('transported_odd_quantum_generator_all_Euler_columns',lambda:euler_columns(gen_fixed,w,list(w.grades)))
    for z,J in w.pairs:
        zero(w.add(w.scale(gel[J],-(-1)**w.p[z]),w.scale(qprime[z],-1)),'TRANSPORTED_QUANTUM_GENERATOR',z)
        zero(w.add(w.scale(gel[z],(-1)**w.p[z]),w.scale(qprime[J],-1)),'TRANSPORTED_QUANTUM_GENERATOR',J)
    boundary=[decode_typed(P) for P in e2['action_density_boundary']]
    bg=stage('complete_transformed_background_action_Ward',lambda:act(w.add(S1,delta),w,Tb,route))
    zero(bg,'COMPLETE_BACKGROUND_ACTION_WARD')
    geometric=stage('complete_geometric_quantum_action_Ward',lambda:act(w.add(S1,delta),w,Tq,route))
    QW=act(W,w,cols,route,1)
    TL=[act(P,w,Tq,route) for P in boundary]
    zero(w.add(geometric,w.scale(QW,-1),w.scale(divergence(TL,w),-1)),'QUANTUM_ACTION_WARD_WITH_BREAKING_CURRENT')
    assert geometric and canonical(w.EL(geometric,'b0')),'QUANTUM_BREAKING_NOT_EXACT_NONBOUNDARY'
    gradients=partials(W,w,set(w.fields))
    assert all(len(jets)<=1 for n,jets in gradients),'BREAKING_CANONICAL_FIRST_JET_TYPE'
    theta=[canonical(w.add(*(w.mul(cols[z],P) for (z,jets),P in gradients.items() if jets==(mu,)))) for mu in range(4)]
    QW_first=w.add(*(w.mul(cols[z],EW[z]) for z in w.fields),divergence(theta,w))
    zero(w.add(QW,w.scale(QW_first,-1)),'BREAKING_FIRST_VARIATION_BOUNDARY')
    transported=stage('complete_transported_quantum_action_Ward',lambda:act(w.add(S1,delta),w,qprime,route))
    tq_current=[canonical(w.add(TL[mu],theta[mu])) for mu in range(4)]
    zero(w.add(transported,w.scale(divergence(tq_current,w),-1)),'TRANSPORTED_QUANTUM_ACTION_WARD')
    EB=stage('geometric_quantum_action_breaking_all_Euler_columns',lambda:
      euler_columns(geometric,w,list(w.fields)) if route=='primary' else direct_euler(geometric,w,set(w.fields)))
    nonzero={};total=0
    def commutators():
        nonlocal total
        for label,T,expect in [('background',Tb,False),('transported_quantum',qprime,False),('geometric_quantum',Tq,True)]:
            for n in sorted(w.grades):
                C=canonical(w.add(act(T[n],w,fixed,route,1),w.scale(act(fixed[n],w,T,route),-1)))
                wanted=w.scale(EB[n[1:]],-1) if expect and n.startswith('J') else {}
                zero(w.add(C,w.scale(wanted,-1)),'FULL_QPRIME_'+label+'_COMMUTATOR',n)
                if expect:nonzero[n]=rows(C)
                total+=1
            for n in external:
                zero(act(T[n],w,fixed,route,1),'EXTERNAL_Q_T_COMMUTATOR',n);total+=1
    stage('complete_polynomial_BRST_Ward_commutators_all_sources',commutators)
    assert any(nonzero.values()),'GEOMETRIC_QUANTUM_DEFECT_NOT_DETECTED'
    alg=local_algebra(qprime,Tb,Dq,w,f,route,stage)
    RH={h:canonical(w.add(*(w.scale(w.mul(w.var(f'C{i}'),w.var(f'C{j}')),-v/2)
      for (a,i,j),v in f.items() if a==h and i in M and j in M))) for h in H}
    for h in H:
        expected=w.add(*(w.scale(w.mul(RH[k],w.var(f'omega{l}')),g*v)
          for (a,k,l),v in f.items() if a==h and k in H and l in H))
        zero(w.add(act(RH[h],w,Tb,route),w.scale(expected,-1)),'COMPOSITE_R_H_LOCAL_COVARIANCE',h)
    assert any(k in M and a in M and b in M for k,a,b in f),'NONSYMMETRIC_COSET_REMOVED'
    ward={'background_action_residual':rows(bg),'geometric_quantum_breaking':rows(geometric),
      'quantum_breaking_Euler_b0':rows(canonical(w.EL(geometric,'b0'))),
      'geometric_breaking_formula':'Tq Sprime=Qprime(Tq Psi)+div(Tq L); S0/S1 Ward certificates retained',
      'geometric_boundary_current':[rows(P) for P in TL],
      'transported_quantum_density':rows(transported),'transported_quantum_current':[rows(P) for P in tq_current],
      'transported_quantum_minus_divergence':[],'breaking_variation_boundary':[rows(P) for P in theta],
      'physical_Ward':'authenticated all-45 local physical identities restricted to actual H; no new expansion of S0',
      'boundary_conditions':'compact support local parameters or vanishing integrated displayed currents','EOM_used':False}
    comm={'pretransport_polynomial_checks':1286,'complete_polynomial_and_external_checks':total,
      'background_and_transported_quantum_residuals':[],
      'geometric_quantum_commutator':nonzero,
      'geometric_identity':'[Qprime,Tq]=-X_(Tq Sprime); canonical sources are -Euler_left(Tq Sprime)',
      'physical_contributions':'508 slots cancel by the bound affine-cotangent functional Ward proof; not expanded here',
      'all_admitted_jets':'ordinary symmetric prolongation commutes with Qprime and the extended Ward operators',
      'EOM_used':False,'all_source_nilpotence_dependency':'frozen_a10_e2_transport; not requalified by a different source restriction'}
    composite={'R_H':{str(h):rows(P) for h,P in RH.items()},'H_covariance_checks':12,
      'independent_coordinate_added':False,'nonsymmetric_f_MMM_preserved':True,'E4_quartic_interpretation_qualified':False}
    return finish(route,{'Tq_geometric':Tq,'Tb_geometric_and_transported':Tb,'Tq_transported':qprime},
      {'quantum':Dq,'background':Db},W,ward,comm,alg,composite,
      {'field_source_construction':method,'transported_quantum_generator_coefficients':len(canonical(gen_fixed)),
        'all_generator_Hamiltonian_transport_checks':1286,'primary_outputs_imported':False,
        'new_action_terms_added':0,'old_expensive_qualifications_repeated':False},e2)

def finish(route,ops,corrections,W,ward,comm,algebra_record,composite,extras,e2):
    return {'schema':'A10_E3_INACTIVE_SYMMETRY_V1','route':route,'status':STATUS,
      'contract':{'manifest_sha256':{n:sha256((HERE/n/'bindings.json').read_bytes()).hexdigest() for n in PREDECESSORS},
        'E2_candidate_sha256':digest(read(HERE/'frozen_a10_e2_transport/M08_CANONICAL_BV_GAUGE_FIXED_E2_INACTIVE_V1.json')),
        'canonical_pairs':643,'canonical_generators':1286,'external_background_components':48,
        'H_generators':12,'source_left_Q':'(S,.)','background_canonical_pairs':0,
        'Tq_vs_Tqprime':'geometric broken Ward versus canonically transported symmetry; never identified',
        'Tb_external':'partial omega+g10[Abar_H,omega]; Q Abar=0','historical_equivalence_proved':False},
      'operators':{tag:{n:rows(P) for n,P in sorted(I.items())} for tag,I in ops.items()},
      'source_transport_corrections':{tag:{n:rows(P) for n,P in sorted(I.items())} for tag,I in corrections.items()},
      'quantum_fermion_breaking':rows(W),'action_Wards':ward,'BRST_compatibility':comm,
      'local_algebra':algebra_record,'composite_R_H':composite,'physical_Euler_covariance':physical_certificate(e2),
      'route_evidence':extras,'inactive':True,'candidate_adopted':False,'sources_activated':False,
      'E4_E5_executed':False,'Stage_E_completed':False,'HB1_C5_run':False,'C1_GS_calculated':False,
      'catalog_rebuilt':False,'historical_equivalence_proved':False,'physical_gauge_independence_established':False,
      'quantum_master_equation_established':False,'auxiliaries_eliminated':False,
      'formal_authority':'34/39_UNCHANGED','external_endorsement':False,'personal_outreach':False}

def candidate(p):
    out={'schema':'M08_E3_INACTIVE_SYMMETRY_PROGRAM_V1','symmetry_id':NAME,'status':STATUS,
      'E2_action':'../frozen_a10_e2_transport/M08_CANONICAL_BV_GAUGE_FIXED_E2_INACTIVE_V1.json',
      'action_modified_here':False,'source_operators':'primary.json:operators',
      'Ward_and_commutator_programs':'primary.json:action_Wards,BRST_compatibility,physical_Euler_covariance',
      'contract':p['contract'],'E4_E5_executed':False,'sources_activated':False,'candidate_adopted':False,
      'historical_equivalence_proved':False,'physical_gauge_independence_established':False,
      'H_basic_domain_qualified':False,'formal_authority':'34/39_UNCHANGED'}
    out['candidate_sha256']=digest(out);return out
