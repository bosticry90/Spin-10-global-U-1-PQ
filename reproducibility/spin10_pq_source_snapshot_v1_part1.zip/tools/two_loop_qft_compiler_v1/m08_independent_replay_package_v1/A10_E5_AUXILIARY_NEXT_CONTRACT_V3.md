# E5 auxiliary Euler equality diagnostic, V3 supplement

V1/V2 remain in force. Both exact bound tensors are completed and immutable.
V2 comparison attempt1 stopped while checking independently derived even
auxiliary Euler polynomials. It used Python dictionary/structural expression
equality after SymPy simplify, which is not an exact polynomial equality test.
No V2 comparison result was exported or accepted. Preserve its exact source,
start and stdout. The new comparison computes the full coefficientwise
Euler-minus-ordered-deletion polynomial and demands exact zero instead, while
still requiring a nonzero Euler witness. If the difference does not vanish,
stop with complete diagnostic coefficients; do not suppress it or fit data.

Freeze new comparator/exporter, V3 and all original/bound actual hashes before
execution. Original actual and binding execution files stay byte-identical.
Fresh validation must reproduce original full primary/replay loops, both bound
routes and this comparator (five exact starts/results). The failed V1/V2
comparisons never count as PASS. No density, tensor, candidate, coupling,
scientific order, first-failure discipline or authority ceiling is changed.
