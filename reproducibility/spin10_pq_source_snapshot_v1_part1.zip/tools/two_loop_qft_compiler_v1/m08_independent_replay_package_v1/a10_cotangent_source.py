"""Scalar-only source frame composition; six-source decoder stays frozen.

One new direct composition audit, not a claim of a second decoder derivation.
No master action or BRST transformation is constructed here.
"""
import sympy as s
from a10_executable_action import HERE,read,record,digest

def clean(m):return s.SparseMatrix(m).applyfunc(s.simplify)
def matrix(r):return s.SparseMatrix(*r['shape'],{(i,j):s.sympify(v) for i,j,v in r['entries']})
def md(m):
    r=record(m);return {'shape':r['shape'],'nonzero_entries':len(r['entries']),'canonical_sparse_sha256':digest(r)}

def build():
    rows=[r for r in read(HERE/'frozen_int8_block_conjugation_v2/INT8V2_physical_copy_maps.json')['components'] if r['family']=='S']
    registry=read(HERE/'frozen_irrep_carrier_registry/REG7_dual_pairings.json')
    j3={tuple(r['left']):matrix(r['matrix']) for r in registry['SU3_pairings']}
    j2={r['n']:matrix(r['matrix']) for r in registry['SU2_pairings']}
    p={r['source_component']:matrix(r['physical_columns']) for r in rows}
    a={r['source_component']:matrix(r['physical_extractor']) for r in rows}
    dual={};inverse={}
    for r in rows:
        cid,partner=r['source_component'],r['target_component']
        label=next(v['source_label'] for v in rows if v['source_component']==partner)
        J=s.kronecker_product(j3[tuple(label[:2])],j2[label[2]]).T
        JJ=s.kronecker_product(s.eye(p[cid].cols//J.cols),J)
        dual[cid]=clean(a[partner].T*JJ);inverse[cid]=clean(JJ.inv()*p[partner].T)
    T=s.SparseMatrix(s.Matrix.hstack(*(p[r['source_component']] for r in rows)))
    Ti=s.SparseMatrix(s.Matrix.vstack(*(a[r['source_component']] for r in rows)))
    E=s.SparseMatrix(s.Matrix.hstack(*(dual[r['source_component']] for r in rows)))
    Ei=s.SparseMatrix(s.Matrix.vstack(*(inverse[r['source_component']] for r in rows)))
    I=s.eye(328)
    assert clean(Ti*T)==clean(T*Ti)==clean(Ei*E)==clean(E*Ei)==I
    pairing=clean(E.T*T);C=clean(Ei*E.conjugate())
    assert clean(C*C.conjugate())==I and clean(E*C-E.conjugate())==s.zeros(328)
    old=read(HERE/'frozen_source_component_decoder/primary.json')
    oldr=read(HERE/'frozen_source_component_decoder/replay.json')
    bound=next(r for r in old['physical_triangles'] if r['source']=='K_phi')
    replay=next(r for r in oldr['physical_triangles'] if r['source']=='K_phi')
    assert bound==replay
    maps={'AST_evaluation_from_typed_source':E,'inverse':Ei,'AST_field_from_typed_field':T,
          'field_inverse':Ti,'typed_pairing':pairing,'typed_source_conjugation':C,
          'induced_source_only_coordinate_bracket_unsigned':Ei.T}
    for key,m in maps.items():assert md(m)==bound[key],('FROZEN_SCALAR_FRAME_MISMATCH',key)
    both=clean(Ti*Ei.T)
    assert clean(T*both*E.T)==I
    invpair=clean(pairing.inv())
    assert both==invpair # (E^T T)^-1 = T^-1 E^-T
    # alpha_x pairs delta x. The channel derivative is T^T alpha_x;
    # multiplying by the simultaneously transported bracket recovers E^-1 alpha_x.
    assert clean(both.T*T.T)==Ei
    assert pairing!=I and clean(E-E.conjugate())!=s.zeros(328)
    grade=next(r for r in old['source_inventory'] if r['source']=='K_phi')
    assert grade['field_grade']==[1,0,0] and grade['source_grade']==[2,-1,1]
    # Authenticate the existing left convention explicitly: Q=(S, .), with
    # source-left products. For an even scalar, its physical source column is
    # +Euler_x S, not a freely adjustable sign.
    from source_convention_control import Exterior
    algebra=Exterior();x=algebra.variable('x',0);J=algebra.variable('J',1)
    m=s.Symbol('m');Sphys=algebra.scale(algebra.mul(x,x),-m)
    column=algebra.bracket(Sphys,J,[('x','J')]);expected=algebra.scale(x,-2*m)
    assert column==expected
    return {'source':'K_phi','components':328,'source_grade':[2,-1,1],'field_grade':[1,0,0],
        'maps':{key:md(m) for key,m in maps.items()},
        'both_fields_and_sources_bracket':md(both),
        'derivative_in_typed_field_coordinates':'alpha_channel=T^T alpha_x',
        'source_only_pullback':'J_eval=E k; coordinate derivative operator is E^-T',
        'canonical_evaluation_pairing':'sum_A J_A h_A; x_star=J because p(x)=0',
        'transported_source_component_of_Euler_covector':'+E^-1 alpha_x, physical-only column under qualified Q=(S,.) left convention',
        'physical_source_sign_control':algebra.record(column),
        'both_frames_source_composition':'(T^-1 E^-T)^T T^T=E^-1 exact',
        'ordinary_derivatives':'E,T constant even: commute with every spacetime jet; no derivative of frame',
        'conjugation':'canonical real alpha; typed alpha represented with E^-1 and C=E^-1 conjugate(E)',
        'grading':'Euler_phys=(dimension 3,gh 0,even); QK has those grades if Q=(1,1,odd)',
        'negative_controls':{'typed_pairing_identity_false':True,'typed_E_real_false':True,
                             'metric_double_insertion_in_canonical_pairing_forbidden':True},
        'source_triangle_scope':'single shared direct composition audit; old primary/replay decoder authenticated, not independently rebuilt here',
        'bracket_scope':'scalar field/source coordinate transport only; no master identity, nilpotence or gauge-fixing claim'}
