# Selected auxiliary poles and an inactive joint normalization

Disposition: `QUALIFIED_E5_SELECTED_AUXILIARY_POLES_AND_INACTIVE_JOINT_NORMALIZATION_ONLY`.
Baseline d138e58, statev113/34of39,28 sealed predecessor chains. Recovery found
a clean working tree and no calculation worker beyond the preflight itself.
The preceding turn made scientific progress by establishing the zero ghost
kinetic pole and refuting the ghost-only normalization. That negative result,
its signed-witness adjudication and all earlier qualified evidence remain.

The new result combines the matched source projections, zero ghost kinetic
pole and a freshly calculated gauge–auxiliary pole in one complete canonical
image. Its auxiliary-width correction is derived from the actual width
equation. No physical coefficient is fitted, no frozen action/fermion changes,
and the normalization is not adopted. Full E5 and quantum restoration remain
unqualified; the whole Spin(10)xglobal U(1)PQ investigation stays active.

## Actual mixed gauge–auxiliary loop

The selected amplitude uses external B(-q) and Lambda(+q), q_E^2=-q_M^2>0.
The primary constructs the literal derivative ghost vertex's graded Fourier
Hessian, the actual xi Lambda/ubar/u Hessian and their Born supertrace. The
replay independently expands -i Tr log of the odd Gaussian operator and
pairs k with -k-q in the common heat profile. All4 Lorentz weights and both
odd starts are retained. The full reference inverse remains available; no
auxiliary is integrated out and no exceptional scaleless bubble is used.

The common symmetrized scalar numerator for Lorentz output nu is

    -eta_nu q_nu/[2 k^2 (k+q)^2].

With the literal physical trace group -kappa on heavy directions and zero
on H, and the Minkowski scalar residue i/(16 pi^2 epsilon), the pole is

    Gamma_1,pole|B-Lambda = -g xi Lambda_phys^T kappa partial_mu B_M_phys^mu
                            /(32 pi^2 epsilon).

In canonical coordinates it is -g xi Lambda^T N_M partial_mu B_M^mu with
the same pole factor. N_M=kappa_aux G_M=U^-1 kappa U is the primal ghost
endomorphism; it is not the auxiliary bilinear itself.

The complete literal inventory retains 1,824 antighost-derivative and 720
ghost-derivative coefficients for the relevant internal heavy ghost pair.
Every Lorentz copy agrees before averaging. Derivatives on the gauge field,
where present, are integrated by parts with their complete current before
comparison. The resulting 45 physical matrices agree with the independently
derived partial-gauge FP operator. Additional H derivative vertices are
nonzero before contraction; their trace with every heavy auxiliary vertex is
zero. All1,485 gauge/auxiliary group entries, including H zeros, compare.
The final canonical mixing projection has132 coefficients.

## The width condition fixes a further unphysical primitive

The width pole at g=0, xi^2 Lambda^T kappa_aux Lambda/(32 pi^2 epsilon),
is an authenticated prior result. It is not recomputed or relabeled here.
The distinct coefficient at order g*xi^2 is zero.

This absence is established by the literal one-loop graph inventory. For a
two-point one-loop graph with cubic/quartic vertices, sum(degree-2)=2 gives
two cubics or one quartic. The only Lambda-bearing cubic orders are g
(720 Lambda-B-B coefficients) and xi (276 Lambda-ubar/u coefficients).
There is no quartic with two Lambdas and no pair at g*xi^2. The mixed g*xi
pair cannot connect a B leg to a ghost. A single-cubic tadpole has one
external leg. Positive-dimensional orbit/mass/mixing insertions lower the UV
degree and cannot create the dimension-zero coefficient of this Lambda^2
logarithm. Width factors remain in the reference; no inverse coupling or
unjustified auxiliary elimination is used.

The previously measured source poles fix delta C=+g xi N C. The zero ghost
kinetic pole and free doublet Q0 ubar=-Lambda then fix the opposite paired
nonminimal normalization delta ubar=delta Lambda=-g xi N_M^T times the field.
Their evaluation-dual sources transform oppositely. In the source-left bracket,

    Klin = g xi [JC^T N C - Jubar^T N_M^T ubar
                            + JLambda^T N_M^T Lambda].

This source-linear image correctly produces the mixed pole and zero ghost
kinetic coefficient. It also produces a spurious +g*xi^2 Lambda^T kappa_aux
Lambda width density, although the calculated pole at that order is zero.
That discrepancy is retained as a negative control, not silently ignored.

Let A be the symmetric matrix extracted from this actual source-linear width
image. Solving its required primitive equation gives

    Q0(ubar^T A Lambda)=-Lambda^T A Lambda,
    A=kappa_aux,
    Kwidth=g xi^2 ubar^T kappa_aux Lambda.

This is a derived, source-free gauge-fixing normalization. It introduces no
physical interaction coefficient and does not change the frozen E1 fermion.
The symmetric bilinear right section is fixed by the measured width equation;
an antisymmetric A lies in its kernel. That kernel is checked explicitly, so
no unique complete primitive or universal inverse is claimed.

## One complete canonical image

Use K=Klin+Kwidth. It contains132 exact coefficients and has grade(3,-1,odd).
Primary Q application and replay direct variation of the full68,254-coefficient
E2 source/gauge-fixing polynomial establish

    Cjoint = QK - partial_mu theta^mu = -delta_K P_E2.

The complete candidate has47,958 coefficients. The explicitly retained
boundary divergence has8,160 coefficients. Every term is preserved, including
higher interacting images from the nonsymmetric heavy coset and composite R_H.
No physical B/x is scaled, hence the34-term physical action has zero variation
under this normalization. Its Euler adapters remain unchanged dependencies.

The source-left Hamiltonian lift is checked across all1,286 generator slots,
including zero spectators. The measured JB-C and all328 scalar-source
projections agree with the earlier qualified image. The ghost kinetic
projection is zero, the mixed B-Lambda projection is the actual pole, and
the g*xi^2 width projection is zero after the derived primitive. Other
interacting columns are retained in the candidate but are not declared to
match actual loop amplitudes. This is not complete one-loop restoration.

Classical functional closedness follows from the qualified Stage D master
equation/Q^2 identity and the retained current. That structural implication
does not establish quantum A5, insertion equivalence or every contact term.

## Pairings, background geometry and measure

Independent left variations of the source-free primitive reproduce both
graded source shifts. All1,089 nontrivial source-source cross coefficients
cancel directly. Canonical evaluation pairings use identity, not G_M. The
field/source linear inverse is checked in both directions to first order;
the second-order remainder is explicit. No finite inverse is inferred from
a truncated series. The source-free shift and linear Hamiltonian together
define a formal canonical flow, with grading and ordinary jets preserved.

The physical width primitive pulls back to the real symmetric kappa matrix.
All12 H intertwining identities pass. Its pointwise invariant bilinear and
the evaluation-dual source maps support the classical local background
compatibility; no false geometric quantum invariance is imposed after light
gauge fixing. E3 and the regulated Slavnov/source correction remain dependencies.

For the integrated fields, the ghost and antighost log-Berezinian traces
cancel, but the auxiliary trace remains. The source-free primitive shifts
only external BV sources and contributes no field-measure cancellation:

    log Ber_field = -hbar g xi Tr_spacetime_reg(N)/(32 pi^2 epsilon).

The carrier trace is132. Keep the regulated H-background-dependent spacetime
trace; it is not a background-independent normalization constant. External
BV sources are not integrated variables. The effective-action measure term
starts at hbar^2 for this hbar-order map. Full quantum A5 and physical IR
removal are still unproved. Cutoff powers, finite local scheme terms and
logarithmic pole identities are distinct; the authenticated nonexceptional
heat bubble is retained, without claiming complete finite restoration.

## Validation and next scientific action

The validation receipt owns actual commands, exits, runtimes and byte checks.
The targeted suite contains377 tests:20 new joint-normalization controls,
312 inherited scientific,24 process and21 governance tests. Required checks
freshly regenerate both completed routes byte-identically, compare the full
candidate and currents, perform the independent pairing/width checks,
authenticate28 predecessor chains, audit protected/new/state SHA bytes and
bounded workspace metadata, and execute the existing historical custody
delegate. Metadata is size/mtime, not a whole-environment byte audit.

New negative controls reverse a spatial Lorentz contraction or source-shift
sign, omit/reverse the width primitive, confuse the Gram bilinear with its
endomorphism, assert a false primitive inverse or promote selected matching
to full quantum restoration. Prior failed/unfinished evidence and the Fourier
witness correction remain protected. Shared immutable data, chart/word
arithmetic, Python3.10.11/SymPy1.14 and analyst are disclosed. No outside
endorsement or proof-kernel certification is claimed; no personal outreach.

Next: compute the actual g*xi^2 Lambda-ubar-u companion, retaining both
three-cubic triangles and cubic/quartic bubbles, and compare its full tensor
with this complete joint image. Then test the previously withheld g^2*xi
JC-C-C/JB-B-C projections under their own contract. Keep UV/IR separation,
finite regulator/source corrections and the full nonlinear Slavnov obligations.
Stop at the first exact mismatch; do not adopt this candidate by assumption.

Full643 pairs/48 backgrounds, potential/vacuum, physical parameters, sources
and frozen catalogs remain. Statev113/34of39 and strict custody2/seven remain
unchanged. No activation, source/auxiliary elimination, HB1/C5/C1_GS, physical
matching, publication or push. Full E5/W1–W7/A1–A5, global scalar boundedness,
the PQ quotient, fermion/Yukawa and phenomenology remain unresolved. The
larger Spin(10)xU(1)PQ investigation is active and incomplete.
