"""Mixed physical/source identities, with actual variational dependencies.

E symbols below are a notation for the bound Euler programs, not additional
fields and not equations of motion. Their covariance follows by varying the
already invariant functional, not by fitting the source nilpotence residual.
"""
from a10_bv_integration_common import *

def build(stage=lambda n,f:f(),route='primary'):
    f,rho,Q=stage('materialize_bound_physical_parent_matrices',lambda:geometry(route))
    data,cols=source_data(route);w=algebra()
    assert [[*key,str(v)] for key,v in sorted(f.items())]==data['geometry']['f']
    E={z:w.var('E'+z) for z in w.fields if z.startswith(('B','x_'))}
    insertion={'J'+z:P for z,P in E.items()}
    QE={z:{} for z in E}
    # Differentiated Ward identity: Q E_i=-(linearization R)^adjoint_ij E_j.
    # Here R is affine/linear in physical coordinates, so the physical-coordinate
    # linearization is a multiplication operator; free Lorentz outputs stay fixed.
    for a in IDS:
        for mu in range(4):
            QE[f'B{a}_{mu}']=w.add(*(w.scale(w.mul(w.var(f'C{c}'),E[f'B{k}_{mu}']),g*v)
                for (k,c,i),v in f.items() if i==a))
    for sec,n in DIM.items():
        work={i:[] for i in range(n)}
        for a,R in enumerate(rho[sec]):
            for (j,i),v in R.todok().items():
                work[i].append(w.scale(w.mul(w.var(f'C{a}'),E[f'x_{sec}_{j}']),g*v))
        for i in range(n):QE[f'x_{sec}_{i}']=w.add(*work[i])
    N={}
    for a in IDS:
        terms=[w.D(E[f'B{a}_{mu}'],mu) for mu in range(4)]
        terms.extend(w.scale(w.mul(w.var(f'B{b}_{mu}'),E[f'B{k}_{mu}']),g*v)
            for (k,i,b),v in f.items() if i==a for mu in range(4))
        for sec in DIM:
            terms.extend(w.scale(w.mul(E[f'x_{sec}_{i}'],w.var(f'x_{sec}_{j}')),g*v)
                for (i,j),v in rho[sec][a].todok().items())
        N[a]=w.add(*terms)
    component_checks=[]
    for z,J in w.pairs:
        mixed=w.act(cols[J],insertion,parity=1) if route=='primary' else derivative_action(cols[J],w,insertion)
        if z in E:mixed=w.add(mixed,QE[z])
        expected=N[int(z[1:])] if z.startswith('C') else {}
        residual=canonical(w.add(mixed,w.scale(expected,-1)))
        assert not residual,('PHYSICAL_SOURCE_CROSS_RESIDUAL',J,rows(residual)[:8])
        component_checks.append({'source':J,'physical_cross_identity':
            'Noether_'+z if z.startswith('C') else 'zero','residual':[]})
    M0=w.add(*(w.scale(w.mul(E[z],cols[z]),2) for z in E))
    current=[w.add(*(w.scale(w.mul(E[f'B{a}_{mu}'],w.var(f'C{a}')),2) for a in IDS)) for mu in range(4)]
    remainder=w.add(M0,*(w.scale(w.D(P,mu),-1) for mu,P in enumerate(current)))
    Noether_term=w.add(*(w.scale(w.mul(w.var(f'C{a}'),N[a]),-2) for a in IDS))
    assert not canonical(w.add(remainder,w.scale(Noether_term,-1)))
    premises=read(HERE/'frozen_a10_gauge_euler_adapter/checks.json')['Noether']
    assert len(premises['pure_Yang_Mills_exact_expanded_components'])==45
    assert len(premises['matter_skew_pairing_checks'])==180
    assert premises['potential_directions']==29
    return {'schema':'A10_PHYSICAL_BV_CROSS_IDENTITIES_V1','status':'PASS_BOUND_PHYSICAL_NOETHER_AND_COTANGENT_LIFT',
        'physical_Euler_variables':'notation for 508 bound executable Euler components; not independent fields or imposed EOM',
        'Euler_covariance':{z:rows(P) for z,P in sorted(QE.items())},
        'Noether_parent':{str(a):rows(P) for a,P in N.items()},
        'all_643_source_cross_checks':component_checks,
        'source_degree_zero_master':{'density':rows(M0),'boundary_current':[rows(P) for P in current],
            'density_minus_divergence':'-2 sum_a C^a N_a','exact_coefficient_residual':[],
            'Noether_is_off_shell_identity':True,'EOM_used':False},
        'Euler_covariance_proof':('Euler_i(Q S0)=Q E_i+(linearization R)^adjoint E. Local-functional Ward identity is zero; affine/linear physical R gives the displayed coadjoint Euler covariance. No field equation is set to zero.' if route=='primary' else
            'For a finite fixed gauge function, invariant S0 and pointwise affine/linear physical coordinate transformation give E_new=(Jacobian field map)^(-T) E_old by arbitrary first variation. Differentiating this contragredient law gives the displayed Euler covariance, including unchanged free Lorentz slots; no equations of motion.'),
        'zero_derivative_source_contributions':'no gauge/scalar physical Euler for ghost or nonminimal sources',
        'inherited_Noether_premises':{'pure_gauge_components':45,'scalar_pairings':180,'potential_directions':29,
            'checks_sha256':digest(premises)},
        'coverage':'all physical-coordinate/source cross coefficients in formal Euler notation; actual full-action Noether and Euler covariance structural, with authenticated all-component action/adapter proofs',
        'Stage_E_reached':False,'sources_activated':False}
