"""Inactive canonical transport types, shifts and shared serialization."""
from hashlib import sha256
from a10_e1_fermion_common import (HERE,ROOT,read,mat,clean,rows,canonical,decode_typed,
 alphabet,register,xi,etaH,PREDECESSORS as E1_PREDECESSORS)
from a10_bv_common import g,DIM,H,M,IDS
from a10_executable_action import ETA,digest
from a10_bv_integration_common import source_data,derivative_action
import sympy as s

OUT=HERE/'frozen_a10_e2_transport'
NAME='M08_CANONICAL_BV_GAUGE_FIXED_E2_INACTIVE_V1'
STATUS='PASS_BOUNDED_INACTIVE_E2_CANONICAL_TRANSPORT'
PREDECESSORS=(*E1_PREDECESSORS,'frozen_a10_e1_fermion')

def dependency_contract():
    return {'manifests':{n:sha256((HERE/n/'bindings.json').read_bytes()).hexdigest() for n in PREDECESSORS},
      'Stage_D_candidate_sha256':digest(read(HERE/'frozen_a10_bv_integration/M08_CANONICAL_BV_STAGE_D_INACTIVE_V2.json')),
      'E1_candidate_sha256':digest(read(HERE/'frozen_a10_e1_fermion/M08_PHYSICAL_FRAME_GAUGE_FERMION_V1.json')),
      'canonical_pairs':643,'canonical_generators':1286,'external_background_components':48,
      'external_background_canonical_pairs':0,'quantum_background_held_fixed':True,
      'flow_orientation':'U=exp[-(Psi,.)]; inverse exp[+(Psi,.)]',
      'source_shift':'A_Jz=-(-1)^p_z Euler_left,z(Psi)',
      'source_left_Q':'(S,.)','historical_equivalence_proved':False,
      'physical_scope':'gauge/scalar only; no Yukawa or fermion sector',
      'physical_adapter_scope':'even physical Euler programs unchanged; odd fermion/source terms use graded calculus'}

def inputs(route):
    e1=read(HERE/f'frozen_a10_e1_fermion/{route}.json')
    data,cols=source_data(route);w=alphabet()
    psi=w.add(*(decode_typed(P) for P in e1['polynomial_parts'].values()))
    el={z:decode_typed(e1['Euler_columns'][z]) for z in w.fields}
    A={J:canonical(w.scale(el[z],-(-1)**w.p[z])) for z,J in w.pairs}
    assert all(not any(n.startswith('J') for n,jets in word) for P in A.values() for word in P)
    return w,e1,data,cols,psi,A

def partials(P,w,names):
    """Left jet gradients, retaining varied-factor positions and signs."""
    gradients={}
    for word,c in P.items():
        prefix=0
        for pos,v in enumerate(word):
            if v[0] in names:
                bucket=gradients.setdefault(v,{})
                rest=word[:pos]+word[pos+1:]
                bucket[rest]=bucket.get(rest,0)+(-1)**(w.p[v[0]]*prefix)*c
            prefix+=w.p[v[0]]
    return {key:canonical(P) for key,P in gradients.items()}

def shift_correction(P,A,w):
    """Exact source-linear affine substitution, with derivative prolongation."""
    terms=[]
    for word,c in P.items():
        slots=[(pos,name,jets) for pos,(name,jets) in enumerate(word) if name in A]
        assert len(slots)<=1,'SOURCE_LINEAR_DEPENDENCY_REQUIRED'
        if slots:
            pos,name,jets=slots[0]
            terms.append(w.mul({word[:pos]:c},w.dword(A[name],jets),{word[pos+1:]:1}))
    return canonical(w.add(*terms))

def canonical_checks(psi,A,w,stage):
    # All elementary inverse maps, two directions; U fixes fields and A.
    inverse_checks=0
    pos={J:w.add(w.var(J),P) for J,P in A.items() if P}
    neg={J:w.add(w.var(J),w.scale(P,-1)) for J,P in A.items() if P}
    for name in w.grades:
        forward=w.add(w.var(name),A.get(name,{}))
        reverse=w.add(w.var(name),w.scale(A.get(name,{}),-1))
        assert not canonical(w.add(w.replace(forward,neg),w.scale(w.var(name),-1)))
        assert not canonical(w.add(w.replace(reverse,pos),w.scale(w.var(name),-1)))
        inverse_checks+=2
    # Independent graded test fields make all source-source Hessian blocks
    # observable, including differential kernels hidden by bare generators.
    for z in w.fields:
        d,gh,p=w.fields[z];register(w,'t_'+z,(d,gh,p));register(w,'s_'+z,(d,gh,p))
    Fa=w.add(*(w.mul(w.var('t_'+z),A[J]) for z,J in w.pairs))
    Ga=w.add(*(w.mul(w.var('s_'+z),A[J]) for z,J in w.pairs))
    from a10_e1_fermion_common import euler_columns
    df=stage('smeared_source_Hessian_first_family',lambda:euler_columns(Fa,w,list(w.fields)))
    dg=stage('smeared_source_Hessian_second_family',lambda:euler_columns(Ga,w,list(w.fields)))
    cross=canonical(w.add(*(w.scale(w.add(w.mul(df[z],w.var('s_'+z)),
      w.scale(w.mul(w.var('t_'+z),dg[z]),-1)),(-1)**w.p[z]) for z in w.fields)))
    GH=mat(read(HERE/'frozen_a10_bv_master/primary.json')['architecture']['gauge_metric_C3'])[:12,:12]
    current=[]
    for mu in range(4):
        C=w.add(*(w.add(w.mul(w.var(f't_B{i}_{mu}'),w.var(f's_ub{i}')),
          w.scale(w.mul(w.var(f's_B{i}_{mu}'),w.var(f't_ub{i}')),-1)) for i in M),
          *(w.scale(w.add(w.mul(w.var(f't_B{k}_{mu}'),w.var(f's_bar{h}')),
          w.scale(w.mul(w.var(f's_B{k}_{mu}'),w.var(f't_bar{h}')),-1)),v) for (h,k),v in GH.todok().items()))
        current.append(w.scale(C,ETA[mu]))
    residual=canonical(w.add(cross,w.scale(w.add(*(w.D(P,mu) for mu,P in enumerate(current))),-1)))
    assert not residual,('SMEARED_SOURCE_PAIRING',rows(residual)[:8])
    # Fresh Hamiltonian sign derivation, using a uniform odd test functional.
    F=w.add(*(w.mul(w.var('s_'+z),w.var(J)) for z,J in w.pairs))
    generator=stage('bracket_derived_all_source_shift_signs',lambda:canonical(w.bracket(psi,F)))
    expected=w.add(*(w.mul(w.var('s_'+z),w.scale(A[J],-1)) for z,J in w.pairs))
    assert not canonical(w.add(generator,w.scale(expected,-1)))
    return {'inverse_generator_checks':inverse_checks,'field_source_pairing':'(-1)^p delta; identity evaluation pairing after zstar=(-1)^p J',
      'canonical_pairs':643,'all_field_field_pairs_zero':True,
      'all_source_source_blocks':'arbitrary independent graded t_z,s_z; coefficient identity including test-function jets',
      'smeared_cross_density':rows(cross),'smeared_boundary_current':[rows(P) for P in current],
      'smeared_cross_minus_divergence':[],'generator_signs_derived':True,
      'general_proof':'source shift is the variational gradient of one source-independent odd functional; exact graded Hessian and boundary identity',
      'EOM_used':False,'external_background_sources_added':False}

def action_boundary(A,cols,psi,w):
    GH=mat(read(HERE/'frozen_a10_bv_master/primary.json')['architecture']['gauge_metric_C3'])[:12,:12]
    L=[]
    for mu in range(4):
        L.append(w.scale(w.add(*(w.mul(w.var(f'ub{i}'),cols[f'B{i}_{mu}']) for i in M),
          *(w.scale(w.mul(w.var(f'bar{h}'),cols[f'B{k}_{mu}']),v) for (h,k),v in GH.todok().items())),ETA[mu]))
    return L

def master_certificate(delta,correction,cols,L,w,route):
    act=(lambda P:w.act(P,cols,parity=1)) if route=='primary' else (lambda P:derivative_action(P,w,cols))
    gradients=partials(delta,w,set(w.fields))
    assert all(len(jets)<=1 for name,jets in gradients),'GAUGE_FIXING_FIRST_JET_GRAMMAR'
    theta=[]
    for mu in range(4):theta.append(w.add(*(w.mul(cols[z],P) for (z,jets),P in gradients.items() if jets==(mu,))))
    current=[canonical(w.scale(w.add(act(L[mu]),w.scale(theta[mu],-1)),2)) for mu in range(4)]
    density=canonical(w.add(*(w.scale(w.mul(correction[J],cols[z]),2) for z,J in w.pairs)))
    divergence=w.add(*(w.D(P,mu) for mu,P in enumerate(current)))
    residual=canonical(w.add(density,w.scale(divergence,-1)))
    assert not residual,('TRANSPORTED_MASTER_GF',rows(residual)[:8])
    return {'new_source_degree_zero_density':rows(density),'new_boundary_current':[rows(P) for P in current],
      'new_density_minus_divergence':[],
      'source_degree_zero_physical':'unchanged Stage D: 2 div(E_B C)-2 C Noether; all 45 Noether identities authenticated',
      'source_degree_one':'unchanged Stage D source master divergence 2 div(J_B QC)',
      'higher_source_degrees':'absent; source terms remain linear; new gauge-fixing density is source free',
      'complete_current':'2 E_B C + 2 J_B QC + new_boundary_current',
      'boundary_conditions':'compact support or conditions annihilating the complete displayed current',
      'EOM_used':False,'physical_Euler_program_unchanged':True}

def complete_columns(cols,correction):
    physical=read(HERE/'frozen_a10_bv_integration/primary.json')['physical_Euler_program']
    w=alphabet()
    out={n:{'source_polynomial':rows(canonical(w.add(P,correction.get(n,{})))),
      'physical_program':physical['canonical_source_slots'].get(n)} for n,P in sorted(cols.items())}
    assert len(out)==1286
    return out,physical

def finish(route,A,delta,correction,canonicity,boundary,master,columns,physical,extra):
    return {'schema':'A10_INACTIVE_E2_CANONICAL_TRANSPORT_V1','route':route,'status':STATUS,
      'contract':dependency_contract(),'source_shifts':{n:rows(P) for n,P in sorted(A.items())},
      'gauge_fixing_density':rows(delta),'source_column_corrections':{n:rows(P) for n,P in sorted(correction.items())},
      'canonical_map':canonicity,'action_density_boundary':[rows(P) for P in boundary],
      'master':master,'complete_columns':columns,'physical_Euler_program':physical,'route_evidence':extra,
      'nilpotence':{'all_1286_generators':'Qprime=U Q U^-1, exact column conjugacy and canonical master-functional proof; graded Jacobi',
        'all_admitted_jets':'U and Q commute with ordinary partials by symmetric jet prolongation',
        'exhaustively_expanded_full_source_squares':False,'EOM_used':False},
      'canonical_pairs':643,'external_background_components':48,'background_canonical_pairs':0,
      'full_master_functional_established':True,'full_source_nilpotence_established':True,
      'historical_equivalence_proved':False,'physical_gauge_independence_established':False,
      'inactive':True,'candidate_adopted':False,'sources_activated':False,'E3_E5_executed':False,
      'auxiliaries_eliminated':False,'catalog_rebuilt':False,'HB1_C5_run':False,'C1_GS_calculated':False,
      'formal_authority':'34/39_UNCHANGED','personal_outreach':False,'external_endorsement':False}

def candidate(p):
    from copy import deepcopy
    old=read(HERE/'frozen_a10_bv_integration/M08_CANONICAL_BV_STAGE_D_INACTIVE_V2.json')
    out=deepcopy(old);out.pop('candidate_sha256',None)
    out.update({'schema':'M08_INACTIVE_CANONICAL_BV_GAUGE_FIXED_E2_V1','action_id':NAME,
      'status':'QUALIFIED_INACTIVE_E2_CANONICAL_TRANSPORT','predecessor_Stage_D_sha256':digest(old),
      'gauge_fixing_included':True,'Stage_E_reached':True,'E3_E5_executed':False,
      'gauge_fixing_fermion':'../frozen_a10_e1_fermion/M08_PHYSICAL_FRAME_GAUGE_FERMION_V1.json',
      'historical_fermion_equivalence_proved':False,'physical_gauge_independence_established':False,
      'component_source_pullback':'canonical J_old = J_new + A; A in primary.json:source_shifts; all fields and 48 external backgrounds unchanged',
      'source_shift_formula':p['contract']['source_shift'],'flow_orientation':p['contract']['flow_orientation'],
      'component_executor':'a10_e2_transport_primary.execute_source_AST; original nine source ASTs with supplied shifted J tables',
      'unchanged_local_terms':43,'gauge_fixing_density':'primary.json:gauge_fixing_density; exactly the source-table substitution correction',
      'complete_Euler_columns':'primary.json:complete_columns and physical_Euler_program',
      'integration_contract':p['contract'],'gauge_fixing_parameters':{'xi':'real dimensionless','eta_H':'real dimensionless','alpha':'xi'},
      'new_physical_parameters':[],'master_density_current':'2 E_B C + 2 J_B QC + primary.json:master.new_boundary_current',
      'source_nilpotence_coverage':'all 1286 canonical generators and ordinary symmetric jets by exact conjugacy U Q U^-1, canonical functional master proof and graded Jacobi; full source squares not exhaustively expanded',
      'external_background_canonical_pairs':0,'auxiliaries_eliminated':False,
      'partial_gauge_domain_and_gauge_fixing_transport_qualified':False,
      'E2_canonical_transport_qualified':True,'E3_E5_residual_domain_qualification':False})
    out['candidate_sha256']=digest(out);return out
