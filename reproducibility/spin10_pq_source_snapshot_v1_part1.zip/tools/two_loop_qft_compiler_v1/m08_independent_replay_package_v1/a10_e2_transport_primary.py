"""Executable source-table substitution followed by complete Euler transport."""
from a10_e2_transport_common import *
from a10_bv_primary import GradedExecutor
from a10_executable_action import numeric_table

def execute_source_AST(w,A,data):
    from a10_bv_integration_common import geometry
    f,rho,Q=geometry();x={n:w.add(w.var(n),A.get(n,{})) for n in w.p}
    tables={}
    for prefix in ('B','JB'):tables[prefix]={(a,mu):x[f'{prefix}{a}_{mu}'] for a in IDS for mu in range(4)}
    for prefix in ('C','JC'):tables[prefix]={(a,):x[prefix+str(a)] for a in IDS}
    for sec,n in DIM.items():
        for prefix in ('x_','Jx_'):tables[prefix+sec]={(i,):x[f'{prefix}{sec}_{i}'] for i in range(n)}
        tables['rho_'+sec]={}
        for a,R in enumerate(rho[sec]):tables['rho_'+sec].update(numeric_table(w,R,(a,)))
    for prefix,ids in [('ub',M),('L',M),('Jub',M),('JL',M),('bar',H),('b',H),('Jbar',H)]:
        tables[prefix]={(i,):x[prefix+str(i)] for i in ids}
    tables['f_parent']={key:{():v} for key,v in f.items()}
    tables['f_mHm']={key:{():v} for key,v in f.items() if key[0] in M and key[1] in H and key[2] in M}
    tables['f_Hmm']={key:{():v} for key,v in f.items() if key[0] in H and key[1] in M and key[2] in M}
    executor=GradedExecutor(w,tables)
    parts=[]
    for term in data['source_AST']:
        result=executor.eval(term);assert not result.labels;parts.append(result.rows.get((),{}))
    return canonical(w.add(*parts))

def build(stage=lambda n,f:f()):
    w,e1,data,cols,psi,A=stage('authenticated_E1_and_Stage_D_coordinate_inputs',lambda:inputs('primary'))
    can=stage('all_canonical_source_shifts_and_smeared_pairing',lambda:canonical_checks(psi,A,w,stage))
    transformed=stage('nine_source_AST_terms_with_all_shifted_component_tables',lambda:execute_source_AST(w,A,data))
    old=decode_typed(data['source_polynomial'])
    delta=canonical(w.add(transformed,w.scale(old,-1)))
    direct=canonical(w.add(*(w.mul(A[J],cols[z]) for z,J in w.pairs)))
    assert delta==direct,'INDEXED_SOURCE_TABLE_SUBSTITUTION_DIFFERS'
    L=action_boundary(A,cols,psi,w)
    Qpsi=canonical(w.act(psi,cols,parity=1))
    assert not canonical(w.add(delta,w.scale(Qpsi,-1),w.scale(w.add(*(w.D(P,mu) for mu,P in enumerate(L))),-1))), 'ACTION_BOUNDARY_SIGN'
    from a10_e1_fermion_common import euler_columns
    el=stage('complete_gauge_fixing_left_Euler_columns',lambda:euler_columns(delta,w,list(w.fields)))
    correction={J:el[z] for z,J in w.pairs}
    # All source columns must also implement the conjugate differential.
    for z,J in w.pairs:
        predicted=w.add(shift_correction(cols[J],A,w),w.scale(w.act(A[J],cols,parity=1),-1))
        residual=canonical(w.add(correction[J],w.scale(predicted,-1)))
        assert not residual,('COLUMN_CONJUGACY',J,rows(residual)[:8])
    master=stage('new_complete_master_density_and_boundary_current',lambda:master_certificate(delta,correction,cols,L,w,'primary'))
    columns,physical=stage('complete_1286_transported_columns_and_508_physical_programs',lambda:complete_columns(cols,correction))
    return finish('primary',A,delta,correction,can,L,master,columns,physical,
      {'source_terms_executed':9,'physical_terms_preserved':34,'transformed_source_polynomial_sha256':digest(rows(transformed)),
       'source_polynomial_coefficients':len(transformed),'exact_column_conjugacy_checks':1286,
       'source_substitution_method':'GradedExecutor on the nine original source ASTs, J component tables replaced by J+A',
       'action_boundary_identity':'Delta=Q Psi+div L; local densities compared without dropping div L'})
