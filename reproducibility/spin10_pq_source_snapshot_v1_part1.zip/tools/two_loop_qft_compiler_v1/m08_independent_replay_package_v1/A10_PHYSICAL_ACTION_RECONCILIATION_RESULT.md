# A10 physical-action reconciliation result

The intended Spin(10) scalar kinetic structure can be derived coherently with
the existing representations, charge normalization, scalar potential and VEV.
The separately named candidate passes exact classical factorized local
gauge-invariance checks. The frozen promoted A10 remains defective in its
previously established channel. No frozen physical action, source rule,
parameter, catalog, formal authority or quantum calculation is changed.

Status: `PASS_INACTIVE_CLASSICAL_PHYSICAL_CANDIDATE_ONLY`.
This is the ceiling of the [contract](A10_PHYSICAL_ACTION_RECONCILIATION_CONTRACT_V1.md),
not a full M08/BV promotion or permission to resume Phase C.

## Recovery and historical authentication

The review started on clean `main` at `2665832`, ahead of `origin/main` by 68
commits. No surviving Phase C calculation was identified. The prior recovery
files, mixed-source fiber and heavy nonminimal canonical-map primary/replay
pairs were authenticated and reused. Their bounded successes survive; neither
tests the complete physical scalar action. No completed mixed-kinetic output
exists in the supplied evidence, and none was inferred or rerun.

All 171 inherited preflight bindings and the 28 additional byte bindings of
the Phase C failure package remain unchanged. The literal A10 canonical action
hash remains `36abb0301627acf272a2904da3968781368b1d1d10a7115f7408e1767e20aa2b`.
The [versioned scope correction](A10_PHYSICAL_ACTION_SCOPE_CORRECTION_V1.md)
records why A37's free-coordinate PASS does not establish complete interacting
kinetics and why A10's complete-physical-action interpretation is narrowed.

## Derivation, rather than coefficient fitting

In the normalized physical plane frame,
`Tr_10(T_a.T T_b)=delta_ab` and the frozen convention is
`D=partial+g10*rho(B)`. Let the matter variation have unknown orientation t.
The independent local parameter derivative in `delta(Dx)` has coefficient
`(t+1)*g10*rho(partial omega)x`, fixing t=-1. The remaining connection/parameter
terms cancel by the representation homomorphism. This fixes the kinetic terms:

\[
\begin{split}
L_{\rm kin,s}={}&\tfrac12(\partial_\mu x_s)^T\partial^\mu x_s
 +g_{10}(\partial_\mu x_s)^T\rho_s(B^\mu)x_s\\
&+\tfrac{g_{10}^2}{2}(\rho_s(B_\mu)x_s)^T\rho_s(B^\mu)x_s .
\end{split}
\]

The complete classical candidate is the standard normalized gauge-curvature
kinetic density, these four scalar densities, and the 29 unchanged literal
potential terms. It is saved as
`frozen_a10_physical_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_CANDIDATE_V1.json`.
Its grammar is a factorized mathematical specification with bound exact
representation matrices and potential ASTs. It is not an executable replacement
for the frozen 14-node AST or a rebuilt vertex/operator catalog. Its C3 frame
map carries the bilinear gauge metric and compact reality condition explicitly.

## Exact evidence and independent replay

The first control uses all 54 Phi coordinates, H4 and a nonzero connection in
four Minkowski directions. Primary exterior jets and independent physical
tensor/word replay agree on 680 density coefficients: 216 ordinary, 400 linear
connection and 64 quadratic connection monomials. The complete density
variation and its ghost Euler derivative vanish exactly.

Both routes separately reproduce all 400 historical Phi variation coefficients
and all 400 ghost Euler coefficients. In particular, for the two-field witness,

\[
\delta L_{\rm A10}=\frac{i g_{10}}{\sqrt2}(\partial_\mu C^4)
(Y\partial^\mu X-X\partial^\mu Y),\qquad
E_{C^4}(\delta L_{\rm A10})=\frac{i g_{10}}{\sqrt2}(X\Box Y-Y\Box X)\ne0.
\]

The preserved complete 36-term scan excludes other literal A10 cancellations.
The candidate includes the compensating structure with independently fixed
coefficients. Connections are varied before projections. The negative control
still fails, rather than being overwritten by the passing candidate.

The full candidate covers Phi(54), Sigma(252), phi(20) and S(2), totaling 328
real coordinates. S is a Spin(10) singlet. Primary directly pushes canonical
component tensors through slot replacements; replay constructs symmetric,
five-form and vector tensor-functor matrices before A31 extraction. Replay
imports neither primary code/results nor SA10 matrices. All 180 representation
matrices agree, including 7,602 nonzero exact coefficients and every implicit
zero. Primary checks 990 brackets per sector (3,960 identities); replay checks
990 complete 328-coordinate brackets by independent trace projection. Each
route checks all embedding intertwiners and kinetic-metric skewness.

These are complete factorized local identities for arbitrary connections,
scalars, parameters and their derivative jets. They give
`delta(Dx)=-g10*rho(omega)Dx`, hence zero scalar kinetic density variation.
Curvature commutation and invariant trace give zero gauge density variation.
The paired-slot audit of all 29 potential contractions gives zero potential
variation, including their unchanged Hermitian completions. Thus the candidate
physical density is invariant exactly; no EOM, numerical tolerance or IBP
rescue is used. Factorized proofs do not claim a fully expanded vertex catalog.

## Actual shifted vacuum, masses and Goldstone implications

Both routes independently reconstruct the frozen physical VEV and
`O_a=rho(T_a)v`; their entire 328-by-45 orbit and Gram agree with N5-N8 after
explicit coordinate remapping. The preserved orbit rank is 33, with 12 unbroken
directions. The mass pairing is `g10**2 O.T O`; its raw eigenvalues/multiplicities
remain `{3/10:8, 3/2:1, 25:12, 253/10:12}` at `omega**2=60`. The spectrum is
reused from the authenticated certificate, not independently diagonalized anew.

Candidate kinetic mixing is `g10*(partial eta).T O B`, or
`-g10*eta.T O partial.B` modulo its explicit boundary current. The quadratic
ordinary R_xi diagnostic `F=P_m partial.B-xi*g10 O.T eta` cancels it because
`O P_m=O`. Its Goldstone GF pairing is `xi*g10**2 O O.T`, with the corresponding
ghost pairing expected on the broken gauge subspace. The full historical
partial gauge-fixing/ghost/source architecture is not qualified by this
diagnostic. Literal A10's ordinary physical scalar kinetics generate zero
scalar-induced vector mass and omit this mixing, so earlier physical mass
interpretations need the correction stated in the dependency review.

Quantum variation keeps Abar and numerical v inert and transforms eta through
v+eta. Background variation transforms Abar affinely and q homogeneously.
For the scalar split one may transform v as a spurion and eta homogeneously,
retaining derivatives until variation, or keep v inert and transform eta
affinely. Both give the correct total-field identity; setting `partial v=0`
before spurion variation loses `partial(delta v)`. Neither option is silently
imposed on historical BV or gauge-fixing definitions.

Here q denotes the total quantum fluctuation `V_H+q_L`, with its quantum
variation projected into those two sectors. The actual M08 background carrier
is H-only: its background parameter must lie in the 12-dimensional H algebra.
The additional `background_scope.json` certificate checks all 66 H–H brackets,
396 H–heavy brackets and `O Q_H=0` in both saved routes. Thus the declared H
background preserves the carrier split and the actual VEV, and eta transforms
homogeneously there. A generic 45-parameter affine background identity would
require a larger background carrier; none is introduced. The full 45-parameter
physical/quantum Ward identity remains qualified.

Writing `R_B=rho(B)`, the shifted kinetic expansion also fixes the Goldstone
interactions: `g10*(partial eta).T R_B eta`,
`g10**2*(R_B v).T R_B eta`, and `g10**2/2*(R_B eta).T R_B eta`, alongside the
mixing and vector mass above. Their Goldstone restrictions are obtained on
`eta in im(O)`; no independently expanded mass-eigenstate vertex catalog or
stationary-potential Goldstone theorem is newly claimed.

## Prior claims and present limits

Potential contractions and the qualified local potential-only Higgs benchmark
`lambda_eff=0.104858242929587` survive within their tested scope. The candidate
reduces to the same scalar kinetic metric at zero connection and preserves the
potential and every parameter. This is an algebraic dependency result; the
numerical benchmark, global boundedness and physical phenomenology are not
recalculated or promoted. Historical ST/source evidence and JCAT/T5 language
qualifications survive as historical mathematics; their applicability to this
candidate still needs action/source/domain reconciliation.

Algorithm and code-path independence are demonstrated. Both routes share
Python, SymPy, physical data, assumptions and analyst; no blind, library,
runtime-independent or external specialist verification is claimed. The
[technical packet](A10_PHYSICAL_ACTION_TECHNICAL_REVIEW_PACKET_V1.md) documents
the exact objects and primary literature comparators. Its literature supports
the local invariance/Euler and gauge-fixing methods, not this implementation's
physical validity. The owner's [solo-project policy](../../../docs/SOLO_REVIEW_POLICY_V1.md)
discontinues outreach and supersedes the personnel gates in four earlier
prepared packets. Their technical questions remain in current V2 solo packets.

## Validation and next decision

`frozen_a10_physical_reconciliation/validation_receipt.json` records fresh
byte-identical regeneration of the four new evidence routes under write
denial, adversarial coefficient/quartic/orientation/VEV/background controls,
preserved complete-action negative tests and governance checks. It records
successful bounded validation separately from the still-failed historical A10
gate. Audit-time metadata and bound-byte custody checks accompany that receipt.
The initial full fresh receipt and its byte bindings are also preserved as
`fresh_validation_receipt.json` and `fresh_validation_bindings.json`. After the
H-background scope clarification, final validation authenticates those fresh
results against every unchanged core calculation/result byte, checks the new
scope certificate and reruns the relevant regressions and governance audits.
It does not repeat the expensive unchanged candidate calculations.

Formal authority stays 34/39. Historical custody stays exit 2 with seven
unresolved references. Frozen M08, sources, catalogs and project_state are
unchanged. HB1/C5 and C1_GS were not run. No remote push or personal outreach
occurs. The candidate is inactive and Phase C remains stopped.

The next decision is whether to authorize a separately versioned executable
physical-action implementation and its source/gauge-fixing dependency
reconciliation using this candidate as a declared input. The factorized
classical result alone does not authorize adoption or resumption. Consequential
mathematical or physical objections must still be resolved through the
solo-project review process.
