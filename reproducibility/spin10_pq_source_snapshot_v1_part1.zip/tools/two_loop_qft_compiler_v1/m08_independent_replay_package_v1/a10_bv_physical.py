"""Stop evidence: canonical gauge Euler versus indexed free-Lorentz output.

Evaluate the literal AST on an abelian one-generator channel with arbitrary
b(x^nu). No equations of motion, coupling choices or fitted parameters.
"""
from itertools import product,permutations
import sympy as s
from a10_executable_action import HERE,read,ETA,digest
from interacting_actual_h_preflight_replay import GaugeWords
from m08_indexed_variational import indexed_euler_lagrange

class Slice:
    def __init__(self,mu,nu):
        self.mu,self.nu=mu,nu;self.w=GaugeWords(0);self.w.p={'b':0}
    def evaluate(self,n,env=None,jets=()):
        env=env or {};w=self.w;k=n['node']
        if k=='ExactScalar':return {():s.sympify(n['value'])}
        if k=='Parameter':return {():s.Symbol(n['name'],real=True)}
        if k=='LocalActionTerm':return self.evaluate(n['density'],env,jets)
        if k=='Field':
            assert n['name']=='B'
            a,mu=[env[i] for i in n['indices']]
            return w.var('b',jets) if a==0 and mu==self.mu and all(j==self.nu for j in jets) else {}
        if k=='StructureConstant':
            # All surviving B factors have the same generator. Antisymmetry
            # makes its self-commutator zero for arbitrary g10.
            return {}
        if k=='PartialDerivative':return self.evaluate(n['argument'],env,jets+(env[n['index']],))
        if k=='Add':return w.add(*(self.evaluate(t,env,jets) for t in n['terms']))
        if k=='OrderedProduct':
            out={():s.Integer(1)}
            for t in n['factors']:
                out=w.mul(out,self.evaluate(t,env,jets))
                if not out:break
            return out
        if k in ('GroupContraction','LorentzContraction'):
            inds=n.get('contracted_indices',n.get('summed_indices',()));terms=[]
            for values in product(*(range(4) if i in ('mu','nu') else range(1) for i in inds)):
                local=env|dict(zip(inds,values));P=self.evaluate(n.get('expression',n.get('argument')),local,jets)
                if k=='LorentzContraction':P=w.scale(P,s.prod(ETA[local[i]] for i in inds))
                terms.append(P)
            return w.add(*terms)
        raise ValueError('UNSUPPORTED_SLICE_NODE_'+k)

def nonlinear_control(term,raw):
    """Check whether a uniform free-index metric multiplication would suffice."""
    a,b,g=s.symbols('a b g10',real=True);constants={}
    for perm in permutations((9,0,1)):
        sign=(-1)**sum(perm[i]>perm[j] for i in range(3) for j in range(i+1,3))
        constants[perm]=-sign/s.sqrt(2) # [T_01,T_02]=-T_12/sqrt(2)
    B={(0,0):a,(1,1):b}
    def evaluate(n,env=None):
        env=env or {};k=n['node']
        if k=='ExactScalar':return s.sympify(n['value'])
        if k=='Parameter':return g
        if k=='Field':return B.get(tuple(env[i] for i in n['indices']),s.Integer(0))
        if k=='StructureConstant':return constants.get(tuple(env[i] for i in n['indices']),s.Integer(0))
        if k=='KroneckerMetric':
            i,j=[env[x] for x in n['indices']];assert n['name']=='delta_exact'
            return s.Integer(i==j)
        if k=='PartialDerivative':return s.Integer(0)
        if k=='LocalActionTerm':return evaluate(n['density'],env)
        if k=='Add':return sum(evaluate(t,env) for t in n['terms'])
        if k=='OrderedProduct':
            out=s.Integer(1)
            for t in n['factors']:
                out*=evaluate(t,env)
                if out==0:break
            return out
        if k in ('GroupContraction','LorentzContraction'):
            inds=n.get('contracted_indices',n.get('summed_indices',()));out=0
            for values in product(*(range(4) if i in ('mu','nu') else (0,1,9) for i in inds)):
                local=env|dict(zip(inds,values));P=evaluate(n.get('expression',n.get('argument')),local)
                if k=='LorentzContraction':P*=s.prod(ETA[local[i]] for i in inds)
                out+=P
            return out
        raise ValueError(k)
    L=s.simplify(evaluate(term));canonical=s.diff(L,b)
    actual=s.simplify(evaluate(raw,{'out_a':1,'out_mu':1}))
    return {'channel':'constant B_0=a*T_01, B_1=b*T_02; no ordinary jets, scalars zero',
        'physical_density':str(L),'canonical_Euler_B1_T02':str(canonical),
        'indexed_Euler_B1_T02':str(actual),'free_index_metric_times_indexed':str(-actual),
        'uniform_metric_shortcut_agrees':s.simplify(-actual-canonical)==0}

def build(stage=lambda name,fn:fn()):
    action=read(HERE/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json')
    term=action['local_terms'][0];assert term['term_id']=='gauge'
    raw={kind:indexed_euler_lagrange(term,name='B',free_indices=('out_a','out_mu'),
            index_kinds=('generic',kind),side='left') for kind in ('generic','lorentz')}
    comparisons=[]
    for mu,nu in product(range(4),repeat=2):
        q=Slice(mu,nu);w=q.w;L=q.evaluate(term);direct=w.EL(L,'b')
        output={kind:q.evaluate(n,{'out_a':0,'out_mu':mu}) for kind,n in raw.items()}
        assert output['generic']==output['lorentz']
        expected=w.scale(w.var('b',(nu,nu)),ETA[mu]*ETA[nu]) if mu!=nu else {}
        assert direct==expected
        comparisons.append({'connection_component':mu,'ordinary_jet_direction':nu,
            'physical_density':w.record(L),'canonical_Euler':w.record(direct),
            'indexed_Euler_generic':w.record(output['generic']),
            'indexed_Euler_lorentz':w.record(output['lorentz']),
            'residual_indexed_minus_canonical':w.record(w.add(output['generic'],w.scale(direct,-1))),
            'match':output['generic']==direct})
    witness=next(row for row in comparisons if row['connection_component']==1 and row['ordinary_jet_direction']==0)
    assert witness['canonical_Euler']==[{'word':['b__00'],'coefficient':'-1'}]
    assert witness['indexed_Euler_generic']==[{'word':['b__00'],'coefficient':'1'}]
    nonlinear=stage('uniform_metric_shortcut_negative_control',lambda:nonlinear_control(term,raw['generic']))
    return {'schema':'A10_BV_GAUGE_EULER_PRIMARY_STOP_V1','status':'FAILED_CANONICAL_FREE_LORENTZ_EULER_TRANSLATION',
        'scientific_gate':'STOP_GATE_3_GAUGE_EULER_INTERFACE','action_sha256':digest(action),
        'literal_gauge_term_sha256':digest(term),'raw_indexed_Euler_AST':raw,
        'comparisons':comparisons,'comparison_count':16,'mismatching_components':sum(not r['match'] for r in comparisons),
        'smallest_witness':witness,'nonlinear_metric_shortcut_control':nonlinear,
        'canonical_definition':'delta S=integral E^mu delta B_mu plus explicit boundary',
        'selected_channel':'one real plane generator T_01, B_1=b(x^0), every other B and scalar zero; sources absent',
        'full_action_exclusion':'29 potential terms have no B; scalar currents vanish at x=0; commutator variation in selected generator vanishes by antisymmetry',
        'couplings':'g10 remains arbitrary; no parameter set to repair discrepancy',
        'boundary_current':'delta b * partial_0 b',
        'residual_Euler_not_identically_zero':'2*partial_0^2 b; arbitrary off-shell field',
        'classification':'unqualified gauge variational conversion; not new physical-action Ward failure',
        'dependency_review':'do not infer that historical calculations used this helper with this canonical free-Lorentz interpretation',
        'EOM_used':False,'master_equation_checked':False,'source_nilpotence_checked':False,
        'Stage_E_reached':False,'physical_action_changed':False}
