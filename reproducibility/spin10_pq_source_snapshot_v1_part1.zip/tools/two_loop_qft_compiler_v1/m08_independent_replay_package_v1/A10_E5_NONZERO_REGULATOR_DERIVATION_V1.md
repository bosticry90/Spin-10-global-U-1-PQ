# Nonzero-g covariance and loop regulation are different obligations

Prospective calculations, not completed scientific evidence.

For a constant reference multiplier P, regulating only the free action adds
delta S_free. Q0 delta S_free=0, but at g!=0 the full nonlinear field rules
give Q delta S_free=<E_free,(P-1)R_nonlinear>. In a scalar generator plane,
the Fourier coefficient with p+q+r=0 is proportional to

    g rho_ij [(P(q^2)-1)q^2-(P(p^2)-1)p^2].

It vanishes for constant gauge parameter p=-q, not for arbitrary local
parameters. Use actual canonical rho_ij and a nonzero selected momentum
coefficient; its ghost Euler derivative witnesses a functional defect.
At small alpha it is O(alpha), with nonpolynomial logarithms. A finite local
polynomial counterterm cannot restore that exact finite-regulator expression.
The possible finite loop remnant is a different restoration problem.

For D=partial+g rho(B), let M=-g rho(C). Full BRST covariance gives

    QD=[M,D], QK=[M,K], QM=M^2, K=-D^2+m_reg^2.

For 0<alpha<1 the spectral power is defined by a resolvent integral. Its
variation is

    delta P = sin(pi alpha)/(pi mu^(2alpha))
                integral_0^infinity dt t^alpha (K+t)^-1 delta K (K+t)^-1,
    delta K=-delta D_mu D_mu-D_mu delta D_mu.

Consequently QP=[M,P], Q^2P=0. Since M is skew for the actual invariant
pairing, <X,PX> is invariant when QX=MX. For this specific candidate the
scalar kinetic operator is L P(L+m_reg^2), L=-D^2. It is self-adjoint because
L commutes with its own spectral power. This ordering is distinct from
(Dx)^T P Dx; commuting D through P in a curved connection would be wrong.
The adjoint curvature uses its invariant F P F pairing.
The full potential/source algebra is unchanged. In the fermion use heavy
P(D[H_total]) on the complete heavy gauge condition and light P(D[background_H])
on the light condition, leaving widths and the actual xi cubic unchanged.
At g=0 these become the preceding P times linear divergences. Full Q of the
heavy kernel includes the coset contribution to QH_total through the resolvent
derivative; the background kernel has Qbackground=0. With this field-only
canonical gauge fixing, a functional master argument is available
for this classical nonlocal candidate. No physical Euler adapter is extended
to nonlocal kernels merely by naming it; the resolvent variational program is
separate. It supplies a tree proof, not a quantum regularization theorem.

The determinant tests that latter assertion. In the massless covariant scalar
diagnostic, the actual kinetic operator is L (L+m_reg^2)^alpha/mu^(2alpha).
Physical mass parameters may be specialized to zero only for this formal
counterexample; the stored action/potential is never changed. Every nonzero
eigenvalue yields

    (1/2) log det[L P] = (1/2)log det L
                          +(alpha/2)log det(L+m_reg^2)
                          -alpha log(mu) Tr 1.

The field-independent normalization cannot cancel a field-strength pole.
The complete covariant vertices compensate the free propagator improvement.
A nonzero scalar gauge pole multiplied by 1+alpha remains divergent for
alpha>0, even with m_reg^2>0. A positive IR reference diagnostic leaves the same leading UV
field-strength pole. Verify by spectral asymptotics/direct diagrams, never
by dropping the regulator's induced interactions.

For a real canonical scalar representation define

    I_ab=-Tr(rho_a rho_b), Omega_mu_nu=g rho(F_mu_nu).

The covariant Laplace operator H=-D^2+V_xx gives the flat heat-kernel coefficient
(4pi)^-2 Tr[ (1/2)V_xx^2 +(1/12)Omega^2 -(1/6)Box V_xx ].
The bosonic determinant has an overall -1/2 in its proper-time integral. For
d=4-2e this gives

    Gamma_E,pole= -Tr(V_xx^2)/(64pi^2 e)
                    +g^2 I_ab F^a_mu_nu F^b_mu_nu/(384pi^2 e).

The potential part must match the preceding scalar UV program. The trace
directions include all mixed fields and conjugates. Boundary terms are
treated as before, without equations of motion. Use proper time as a
separate one-loop regulator, not proof that the action multiplier regularizes.

Direct bubble/seagull variation for two gauge legs gives

    Pi_mu_nu=(g^2 I_ab/2)(p^2 delta_mu_nu-p_mu p_nu)
              integral_0^1 da (1-2a)^2 J2(M^2+a(1-a)p^2),
    J2(Delta)=mu^(2e) Gamma(e) Delta^(-e)/(4pi)^(2-e).

The weighted integral is 1/3 in the pole. Retain the seagull identity
2[J1(M^2)-integral J1(Delta)]=p^2 integral(1-2a)^2 J2(Delta).
Removing the seagull yields a nonzero longitudinal mass term. At positive
reference mass, MSbar subtraction gives an explicit finite logarithmic
parameter integral. In the nonexceptional massless limit its weight is
(1/3)log(mu^2/p^2)+8/9. It is nonlocal and is not C1_GS or physical matching.

Physical replay: the normalized real vector trace is one; symmetric
traceless rank2 gives (n+2)=12 for n=10. The full five-form trace is
binomial(8,4)=70. Hodge star commutes with all physical generators, and its
trace against two generator actions vanishes because two replacements cannot
reach a five-index complement. Each complex self-dual half has index35;
realifying it restores70. The complex vector has two real copies, index2.
The singlet contributes zero. Derive and check all generator pairs rather
than assuming these normalizations from representation names.

The finite proper-time scalar determinant is covariant under the actual
45-generator total-connection rules and residual12 background H. It retains
the physical scalar Hessian program and uses no external45 background or new
canonical source. Its validity is one scalar determinant, not the complete
retained-source gauge/ghost/nonminimal/insertion framework. The action-kernel
test is the gate whose failure must stop that extension's whole-M2 claim.
