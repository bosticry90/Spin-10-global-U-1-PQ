# Bounded canonical gauge Euler and free-Lorentz cotangent qualification

This authorization implements a separate inactive operation for the approved
34-term gauge/scalar physical action. It preserves the historical helper and
every predecessor byte binding. It stops before full BV assembly or Stage D
resumption. Stage E, source activation, HB1/C5, catalog rebuilding, C1_GS,
physical-parameter changes, formal promotion and remote push are excluded.

The independent coordinates are B_mu^a in the orthonormal real plane frame.
Ordinary jets partial_lambda B_mu^a are independent first-jet coordinates;
prolongations have symmetric commuting derivative slots. The canonical Euler
covector E_a^mu is defined by delta L = E_a^mu h_mu^a + partial_mu Theta^mu.
Component partial differentiation uses identity deltas in both slots. Neither
the Lorentz metric nor the internal Gram matrix is a component identity.
All Lorentz contraction measures remain present until component execution.
Internal field changes B_plane=Q B_parent induce E_parent=Q^T E_plane;
canonical sources transform inversely to fields. Raising a Lorentz index is a
separate explicitly stated map, not a repair of a final Euler coefficient.

The new adapter accepts even first-jet densities, constant representation and
structure tensors, finite explicit contractions and ordinary derivatives. It
rejects odd/source calculus, unsupported nodes, higher input jets, output
index capture, and products of independently closed Lorentz sums outside the
physical compiler's whole-monomial summation scope. This is sufficient for physical gauge source columns; it is
not a general graded BV derivative engine. No background/gauge-fixing action
or Yukawa term is supplied by this qualification.

Acceptance requires: the historical 16 free controls and quartic shortcut
counterexample; general derivative/cubic/quartic Yang--Mills Euler and boundary
coefficients from the executable AST versus an independent two-form variation;
general four-sector scalar currents and nonzero-connection controls; a full
first-variation identity for arbitrary test fields; structural gauge Noether
identities using authenticated representation and potential proofs; explicit
canonical source/Lorentz/internal pairing and inverse maps; targeted historical
consumer impact analysis. Polynomial coefficient identities and structural
substitution proofs supply generality; sample configurations alone do not.

Any first essential failed or underdefined identity stops the investigation.
No final sign multiplier or fitted physical coefficient is permitted. A PASS
qualifies this operation only and permits proposing a later inactive Stage D
integration. It does not establish the master equation or source nilpotence.

SOLO_REVIEW_POLICY_V1 applies. Literature and independently derived computations
are technical controls; no outside person, outreach or endorsement is required
or claimed. Historical custody exit 2 remains unresolved, never PASS.
