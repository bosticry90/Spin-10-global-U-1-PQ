# Retained-source quantum functional and insertion specification

This is a conditional mathematical target for the inactive gauge/scalar model,
not an implemented quantum prescription or a new authority ledger. The tree
functional is the literal qualified S' from E2. All qualifications below are
subject to A1-A5; their realization has not been proved for this model.

## W1: variables, functional and graded conventions

Integrate the 643 canonical fields z: 180 total-connection coordinates B,
328 real scalar coordinates x=v+eta, 45 ghosts and 90 nonminimal coordinates.
All 643 evaluation sources J remain external, including auxiliary sources.
The 48 Abar_H components and their ordinary jets are external; Q Abar=0.
No background antifields or background BRST doublet are introduced. Integrating
B or q=B-Abar is a translation of integration coordinates, not an extra field.
The 12-generator background transforms Abar affinely and q homogeneously.

Ordinary sources j_z have parity p_z and ghost number -gh(z). They are distinct
from BV sources J_z, with parity 1-p_z and ghost number -1-gh(z). Define,
formally in Minkowski perturbation theory with a declared i-epsilon/IR treatment,

    Z[j,J,A,rho] = integral Dz exp{i/hbar [S_R[z,J,A] + integral j_z z
                                        + integral rho_I O_R^I[z,J,A]]},
    W = -i hbar log Z,    phi_z = EL^L_jz W,
    Gamma[phi,J,A,rho] = W - integral j_z phi_z.

Only j is Legendre transformed. Finite selected composite insertions are
bookkeeping probes rho, not integrated variables or new canonical pairs.
Their first derivatives are evaluated at rho=0. Multiple derivatives require
separately normalized contact products. Setting J=0 is not performed here.
Use left derivatives with variations placed on the left. With j_z z in that
order, EL^L_z(j_z z)=(-1)^p_z j_z, hence

    EL^L_phi Gamma = -(-1)^p_z j_z,
    EL^L_J Gamma = <EL^L_J S_R>,   EL^L_A Gamma = <EL^L_A S_R>,
    I_O := EL^L_rho Gamma|0 = <O_R>_1PI.

Brackets use the repository's source-left convention, Q'=(S',.). For even
F, X_F z=EL^L_J F and X_F J=EL^L_z F, and
S(F):=(F,F)/2=integral (EL^L_z F)(EL^L_J F). For odd K,
X_K z=-(-1)^p_z EL^L_J K, X_K J=(-1)^p_z EL^L_z K.
Products and jets retain their graded ordering and integration-by-parts currents.
These formulas fix signs, rather than importing a differently oriented bracket.

## W2: the admissible prescription class and assumptions

| ID | Conditional input | Status and reason it is separate |
| --- | --- | --- |
| A1 | Formal perturbative functional integral, suitable gauge-fixed propagators, graded Legendre transform, boundary/IR prescription and change-of-variables calculus | Assumed; no propagator inversion, convergent measure or IR prescription constructed here |
| A2 | A local power-counting subtraction construction with QAP for the retained sources, background jets and specified insertions | Assumed; published algebraic renormalization supplies the framework, not its project-specific realization |
| A3 | Simultaneous Slavnov/background restoration when the computed consistent breakings are trivial in the admitted ring and satisfy normalizations | Conditional existence requirement; no anomaly coefficient, triviality or nonempty all-order prescription class proved |
| A4 | Renormalized composite and contact insertions with declared mixing, local finite normalization and compatibility with the functional identities | Assumed construction; tree normalization is fixed, loop mixing matrices are not calculated |
| A5 | Admissible quantum field/source redefinitions carry their Jacobian, insertions, normalization and operators consistently, or are justified renormalized replacements | Conditional equivalence; classical canonicality alone is insufficient |

The class can include a suitable local subtraction scheme with QAP; no single
regulator is selected. Its nonemptiness for every required sector is unresolved.
Absence of chiral fermions in the approved scope is not an anomaly-freedom proof.
When lower-order identities have been restored, A2 asserts locality of the FIRST
nonzero breaking and of subtraction counterterms, not locality of all of Gamma.
Nonlocal finite loop functions and connected insertions are not polynomials in
mean fields. UV locality does not dispose of massless IR or boundary issues.

Counterterm densities are (d_project,gh,p)=(4,0,0), finite ordinary jets, with
Lorentz contraction and real structure. d_standard=d_project-gh. Breaking of
Slavnov has (5,1,1), standard dimension four; background/quantum Ward breakings
have (4,0,0) including an even local omega. Generators K have (3,-1,1), standard
dimension four. Preserve the polynomial physical parameter ring, nonnegative
parameter dimensions, no inverse physical couplings or dimensional parameters.
Insertion UV bounds follow their declared operator dimensions; contact terms
require bounds on the chosen products. This is not a newly enumerated catalog.
Closure/stability of the physical parameter list under subtraction is unproved.

## W3: Slavnov derivation, consistency and restoration

At rho=0 change the integration variables by the odd field operation
R_z=EL^L_Jz S_R with J,A held fixed. The source term contributes
sum (-1)^p_z j_z R_z. The action variation is S(S_R). Boundary terms use
the qualified local-functional convention. The regulated Berezinian and
subtraction terms are retained as measure/breaking insertions M_s. Therefore

    S(Gamma) = [S(S_R)]_Gamma + M_s =: Delta_s .

M_s is defined with this sign; no vanishing or universal unregulated functional
trace is assumed. If the bare action satisfies its master identity and the
measure/restoration conditions are met, Delta_s can be zero. The expression
is a Zinn-Justin 1PI identity, not a calculation of a BV measure Laplacian QME.
It is derived from the integration-variable change and Legendre identities,
not from demanding that quantum corrections repeat the classical formulas.

Write Gamma=S'+sum hbar^n Gamma_n. The orders are

    n=1: Q' Gamma_1,
    n=2: Q' Gamma_2 + (Gamma_1,Gamma_1)/2,
    n=3: Q' Gamma_3 + (Gamma_1,Gamma_2),
    n=4: Q' Gamma_4 + (Gamma_1,Gamma_3) + (Gamma_2,Gamma_2)/2.

The linearized operator B_Gamma F=(Gamma,F) obeys
B_Gamma^2 F=(S(Gamma),F) and B_Gamma S(Gamma)=0 by graded Jacobi.
At first nonzero breaking order n, Q' Delta_s,n=0; a local correction C_n
restores it only if Q' C_n=-Delta_s,n (addition convention). Also require the
background equation W_b C_n=-Delta_b,n and consistent insertion normalization.
A closed ghost-one breaking need not be exact. Joint solvability is A3, not
proved by consistency. A surviving nontrivial breaking is a stop, not a PASS.
Two restored constructions first differing at n have Q' delta_n=0; it is their
LOCAL counterterm difference that enters classification. Gamma_n individually
need not be Q'-closed or local. This removes the prior target ambiguity without
claiming an actual quantum solution.

## W4: local background Ward and retained background terms

For an even affine field transformation R and field-independent external
transformations sigma(J,A), change z at fixed external variables. Then use
the Legendre identities to obtain

    W_T Gamma := integral [R(phi) EL^L_phi Gamma
                          + sigma_J EL^L_J Gamma + sigma_A EL^L_A Gamma]
              = [T S_R]_Gamma + M_T.

This is exact formal change-of-variables calculus subject to A1; the chosen
quantum normalization/restoration of the insertions is A2-A4. R is affine in
integrated coordinates, so <R(z)>=R(phi), including local parameter jets.
The actual E3 background operation has evaluation-dual source transformations
linear in J, external A variation D[A]omega and no field-dependent correction.
Its tree T_b S'=0 as a functional. The restored target is W_b Gamma=0, with
a possible local Delta_b before restoration. Parameter derivatives must remain.
The Ward Lie consistency and mixed Slavnov consistency follow from the
qualified canonical/background algebra, e.g. Q'Delta_b-W_b Delta_s=0 at the
first common breaking order. They do not prove solvability of the joint system.

Differentiating the inserted functional at rho=0 gives
W_b I_O=[T_b O]_Gamma plus differentiated breaking/contact terms, in the
inert-rho convention. A multiplet can instead give rho the evaluation-dual
transformation, yielding the corresponding covariant insertion identity.
This requires the full local Frechet action on jets, not just constant H.
For an even ghost-zero probe, Slavnov differentiation gives
B_Gamma I_O=[(S_R,O_R)]_Gamma plus differentiated breaking/normalization terms
at rho=0; rho^2 contact contributions are outside the single-insertion identity.
This is not a claim that arbitrary probes preserve the unextended master
identity at nonzero rho. No auxiliary canonical probe partners are invented.

Default normalization subtracts an overall background-independent constant.
It does not divide away Z[0,0,A] or discard background-only responses.
Keep L_bg=-G_H Fbar Fbar/4 in the possible local language: it is already basic,
nontrivial in the declared polynomial complex and satisfies the local Ward.
L_div=G_H(partial.A)^2/2 fails the local background identity and is excluded.
Neither is proved loop-generated. Subtracting an invariant N[A] is an additional
observable normalization: it leaves the Slavnov bracket and background Ward
unchanged but changes pure-background derivatives of Gamma. It is not the
default equivalence. Dividing by a J-dependent functional requires further
Slavnov analysis and is not authorized as a harmless normalization.

## W5: geometric quantum H versus transported source realization

Let T_q have the authenticated affine quantum field rules, A fixed, and
evaluation-dual geometric source rules. Its justified quantum identity is

    W_q Gamma = [B_q,R]_Gamma + M_q,    B_q,R := T_q S_R.

It is broken even at tree level. The selected tree channel is -2 b_0 Box omega_0;
its Euler_b0 is -2 Box omega_0, not a removable ordinary divergence. Background
Ward preservation does not require this geometric quantum breaking to vanish.

At tree level write the E3 canonical operation as
T_q'=T_q+sum c_J[z,A,omega] partial_J, with 56 nonzero correction slots.
The qualified functional relation is

    B_q,0 + integral c_J EL^L_J S' = 0 modulo the explicit E3 current.

After quantization c_J is not an ordinary external-variable change: it depends
on integrated fields. Define a WHOLE renormalized product insertion
I_q=[integral c_J EL^L_J S_R]_Gamma, with any permitted higher-order completion
and mixing declared under A4. In the class retaining that completed action
relation, the insertion realization is W_q Gamma+I_q=M_q (and any completion
breaking). More generally keep B_q,R as the independent normalized breaking.
No unexplained claim of a strictly invariant fixed T_q' Gamma is imposed.

In particular, replacing I_q by sum c_J(phi,A) EL^L_J Gamma loses connected
products/contact normalization. The naive residual would be

    (W_q + c_J(phi) partial_J)Gamma
       = M_q - I_q + sum c_J(phi) EL^L_J Gamma

when the completed relation holds. Even the actual affine-in-quantum-field
corrections multiply field-dependent source insertions; affine c alone does
not justify factorizing their product. The Gaussian control below exhibits
the connected difference, not an actual Spin(10) anomaly or computed loop.
Renormalized realizations, if later imposed, must be derived with insertions.
The geometric broken identity is redundant change-of-variables information
when all its insertions are defined; it is not an extra homogeneous classical
T_q'-kernel restriction on counterterms.

## W6: source, observable and canonical equivalence contract

BV source differentiation fixes the normalization of the corresponding
renormalized field-variation insertions. A source redefinition must carry the
inverse evaluation-dual field map, grading, real structure, jets, background
scope and all operator insertions. Auxiliary and antighost equations of a
linear textbook gauge are not imported into the nonlinear E1 replacement.
Finite source/contact mixing is fixed by stated subtraction and normalization
conditions; its coefficients are unresolved. Tree values are the sealed E2/E3
values. The Ward and Slavnov identities constrain, but do not uniquely choose,
these finite normalizations or the physical parameters.

For a justified canonical map V the classical data transport as
S->VS, O->VO, Q->VQV^-1, T->VTV^-1, iota->ViotaV^-1.
The qualified ghost/source scaling family supplies one such map and inverse.
Infinitesimally X_K S'=-Q'K modulo currents for the source-left odd generator;
the inverse orientation supplies +Q'K. F' is trivial when its qualified
generator is admitted, not when all primitives are forbidden. This does not
remove arbitrary source deformations or prove basic quotient completeness.

At quantum level a canonical substitution involving field-dependent external
sources is not automatically a true change of integration variables or the
naive scalar law for Gamma. Even nonlinear changes of integrated fields send
mean fields to expectations of composites, not composites of mean fields.
Use a justified renormalized replacement or a change-of-variables construction
with local Jacobian and transported insertion sources/contacts; require A5.
Linear independent ghost scales before U are ordinary variable changes with
inverse source scales and field-independent Berezinian normalization. After U,
source shifts are field dependent; their quantum implementation still requires
the insertion/replacement contract. Do not enlarge the canonical alphabet to
a different master-functional formalism merely to assume equivalence.

The conditional admissible counterterm is a local real delta together with its
insertion/source-normalization changes. At first differing restored order it
satisfies Q'delta=0 and W_b delta=0, plus the differentiated broken quantum Ward
and probe normalization identities, whose right sides vary as insertions.
Equivalence requires an admitted canonical redefinition with A5 and transported
operators/observables, or a declared parameter/normalization change. It does
not impose iota'delta=0 or T_q'delta=0 by fiat. The earlier joint basic complex
remains qualified classically; its relation to this quantum insertion target
is a subsequent proof obligation, not an automatic surjectivity result.

## W7: evidence, literature and limits

The new routes check graded Legendre source signs, nonlinear Slavnov orders,
linearization/Jacobi on a graded canonical control, affine Ward/change-variable
identities, connected Gaussian products and nonlinear mean-field transport.
They compare all source correction slots using the separately authenticated
E3 routes, preserve local parameter jets and retain L_bg, L_div and F'.
These are bounded formal derivations/control calculations, not loop amplitudes.

[Barnich, Brandt and Henneaux, section 2.6](https://arxiv.org/html/hep-th/0002245)
separate anomaly restoration from ghost-zero stability and explain retained
antifields in the 1PI identity. Their theorem assumptions are still separate.
[Grassi, Hurth and Steinhauser, section 3](https://arxiv.org/html/hep-ph/0102005)
use QAP, normalized insertions and joint Ward/Slavnov restoration; their Standard
Model background BRST extension is not imported into these inert backgrounds.
[Anselmi, sections 1-2](https://arxiv.org/html/1205.3862) explains why canonical
maps mixing external sources with fields are not ordinary integral-variable
changes. His extended master-functional construction is not adopted here.
These foundations motivate A1-A5 and the insertion distinction, not certify
this particular model or establish its quantum consistency.

Qualification is CONDITIONAL_W1_W7_FRAMEWORK_ONLY. No anomaly freedom, actual
all-order scheme, quantum gauge independence, cohomology completeness, theorem
applicability, regularity/Koszul-Tate resolution or full E5 is proved. The next
smallest step is the regularity/Noether-resolution and theorem-domain bridge,
including the relation between this Ward/insertion target and the classical
joint basic quotient. It requires separate scoped execution; no catalog or
quantum matching is a substitute. Formal authority and custody remain frozen.
