# Actual derivative-gauge companion: stopped inactive-member comparison

DG1 fails for the complete member frozen at25bb6b7. DG2 qualifies the selected
actual g^2 xi UV derivative tensor under the V1 contract: signed Fourier/Born
and independently routed ordered Wick residues agree, with literal full
structure constants versus physical10 commutators. Both preserve all45 gauge,
antighost and ghost directions, two independent derivative placements, all
182,250 scalar slots, four Lorentz polarizations and arbitrary reference widths
until contraction. The lower g xi^2 linear residue is zero by the full
double-longitudinal Yang–Mills identity and LL edge exclusions before candidate
access. No ordinary g^3 or other-source amplitude was calculated here.

All five graph classes contribute before the sum. Physical nonzero (partial a,
partial C) counts are ghost(1652,1126), auxiliary-gauge(526,526),
Yang–Mills(1940,1414), ordinary quartet(1302,1302), ghost quartet(600,600).
Their total is(1502,976),692 raw temporal density words. External H gauge and
H ghost channels cancel after the full sum. Widths cancel; all12 homogeneous
H identities, exact frame roundtrips and reality pass. Full local jet Ward
identities require partner amplitudes and are not inferred from this tensor.

The complete candidate has4,848 derivative words across four polarizations,
1,212 temporal words,416 temporal current words and652 effective words after
full IBP reduction. The actual quartet bubble's natural derivative-on-B
current has276 words. Both complete currents are retained; their difference
gives the full natural-versus-effective difference identity. The residual has
512 raw temporal words,2,048 across four polarizations. K4 contributes no
derivative image. The lower candidate orders have zero residual.

A real-frame witness is gauge Bp13_0, antighost ap14 and ghost Cp12. In the
ordered (partial a) B C convention the actual/candidate coefficients are
-24sqrt(10)xi/25 versus-16sqrt(10)xi/25; in a B(partial C) they are
-8sqrt(10)xi/25 versus0. Thus the canonically ordered word
Bp13_0 Cp12(partial_0 ap14) has difference+8sqrt(10)xi/25. The full gauge Euler
derivative has36 terms and its two-momentum symbol18. This excludes a pure
total derivative for generic momentum and xi; it is not an EOM quotient or
anomaly conclusion. A restriction p_C=-p_a hides this witness and is excluded.
All quoted coefficients suppress the common hbar g10^2/(32pi^2epsilon).

The exact unit controls include full transverse BB (omission changes a unit
residue by3/2), both BL/LB orientations, both odd inverses, all derivative
assignments and ordinary and ghost quartets. Supplementary numerical controls
detect each omitted graph family, odd reversal, missing assignment, omitted
current and wrong primal antighost chart. Actual/candidate comparison occurs
only after complete actual agreement. The UV domain is k_E^2>R_UV^2>0;
triangle/bubble heat profiles6/4 are retained. First Taylor heat insertions
multiply the leading degree-3 odd kernel by k.p/Lambda^2, leaving radial
degree-2 with a 1/Lambda^2 factor and Gamma(1-epsilon), rather than the
degree-4 logarithmic pole. No whole-scaleless or finite/IR amplitude is used.

Validation must record scientific, process and governance tests, delegated
research_check.py e5,37 predecessor chains, unchanged new/protected/state
bytes and size/mtime inventory, plus FOUR strict own-byte fresh runs: controls,
primary, replay and comparison. The validation receipt owns actual counts,
commands, elapsed times and complete diagnostics. Custody remains exit2 with
seven unresolved references. The preliminary supplementary-audit failure
(incorrect expected ghost-derivative coefficient) is preserved with exact
source and copied tool diagnostic; its start fingerprint and elapsed time
were not recorded. Validation attempt1 also failed because serialized Fourier
momenta were decoded as symbols without their real assumptions; its exact
source/start/stdout snapshot is retained. The new audit explicitly binds the
two real momenta before evaluating the negative control. Both failures are
excluded from PASS. Frozen loop/comparison bytes
were not edited. A successful evidence audit authenticates this FAILED
candidate gate; it does not pass DG1 or constitute director acceptance.

Shared action/group inputs, Python/SymPy, exact arithmetic and analyst limit
independence. Provenance is recorded; selected actual reproduction and bounded
obstruction are verified by distinct routes, while the inactive candidate
match fails. Proof-assistant formalization was not attempted, explanatory
compression and broader physical interpretation remain open, and empirical
connection is none. project_state.json v113/34 of39 is the sole authority.
No normalization adoption, physical/catalog activation, HB1/C5/C1_GS/matching,
full E5/A5, Ward/contact/IR/anomaly, outreach/push/publication or whole-goal
completion is claimed. Old expensive loops and125-basis images are only
authenticated here; they are not repeated.

Next smallest action: freeze a separate prerequisite contract for the literal
source–gauge derivative sector and admissible auxiliary-derivative generator
types, with independent input-derived coefficients. Establish whether that
sector supplies a required companion before attempting any repair. Do not fit
this residual or adopt a counterterm. The g^3 quartet remains a prediction and
must await a separate prospective actual contract after this obstruction is
resolved. Scalar/PQ global, fermion/Yukawa and phenomenology remain unfinished.
