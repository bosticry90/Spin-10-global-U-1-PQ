# C5 positive-ghost target extension

Source checkpoint: `ac926ed`. This run is target-catalog-only. The promoted
54,148-dimensional dimension-four JCAT catalog and the qualified weight grading
remain immutable. No H-basic quotient, BRST differential, EOM quotient, rank or
cohomology calculation is authorized here.

## Scope and current disposition

The new target is independently defined by `gh=+1`, `d<=5`, `d-gh<=4`, with the
previously frozen physical four-dimensional metric/epsilon, realization,
background-covariance, IBP, diagonal statistics and conjugation conventions.
The dimension-five construction does not extend the action or introduce new
couplings. It is not defined as the image of the BRST differential.

The target is promoted as
`M08_C5_COMPLETE_POSITIVE_GHOST_TARGET_CATALOG_V1` following complete
construction, fresh byte-identical regeneration and read-only release and
post-promotion validation. The next blocker is
`M08_C5_H_BASIC_COCHAIN_QUALIFICATION_PENDING`. The existing 8,302
dimension-at-most-four positive-ghost operators are referenced immutably in a
C5-only union view; they are not rewritten. Neither H-basic cochains nor the
C5 differential complex is promoted.

The construction ledger for the new dimension-five extension is:

| Stage | Dimension |
|---|---:|
| Ordered expansion coordinates | 4,860,233 |
| Exact realization nullity | 15,914 |
| Realized tagged directions | 4,844,319 |
| Background-covariant tagged packets | 4,726,230 |
| Exact IBP relation rank | 23,443 |
| Post-IBP quotient | 4,702,787 |
| Final statistics-allowed target directions | 387,117 |
| New parity-even directions | 385,072 |
| New parity-odd directions | 2,045 |

All 242 completion classes (151 singleton and 91 active) are accounted for.
Primary final dimensions agree with the independently frozen character census.
The C5-only union target language has 395,419 directions: 393,374 parity-even
and 2,045 parity-odd. These are not H-basic cochain dimensions, counterterm
counts, anomaly dimensions or cohomology dimensions.

The independent census covers 318 recipes, including 131 five-occurrence
recipes. Recipes are field-content/derivative coverage, not operator dimensions.
Seventy-seven demanded internal families, including 35 five-slot families,
have exact fusion cardinality agreement with an independent weight-character
calculation. The new tree is `((01)(23))->dual(4)`, followed by the frozen
terminal pairing. Existing trees are unchanged.

The extension qualifies 102 new middle binary factors using the unchanged
carrier and REG7 pairing conventions. All embedding/decomposition identities,
covariance equations and cross-channel annihilation checks are exact.
Multiplicity Gram inverses are derived, never replaced by Euclidean transpose.

## Evidence and independence

Primary manifest covariant packets and independent affine Ward-kernel replay
are frozen separately. The realization quotient, packet space, IBP quotient
and statistics projector remain distinct with separate provenance. Ordinary
homogeneous occurrences remain tagged until final diagonal statistics;
repeated background connections are identified in the realization map.

Five bounded recoupling controls and five physical-conjugation component
controls pass, including the 32-dimensional SU(3) block. These use different
algorithms/code paths but share certified tensor inputs and the Python exact
stack. No library or runtime independence is claimed for those controls.

The largest demanded fixed-component arity-five internal block is separately
preregistered. Its 64-dimensional cardinality agrees with an independent Weyl
weight convolution. Bounded full-versus-thin tensor controls for this block are
included in the release recipe; the 32-dimensional control is not described as
the largest complete internal block.

All 11 preregistered packet/IBP replay controls pass, including the largest
96-direction packet block and its 24-dimensional IBP relation space. All ten
final operator reconstruction controls and their conjugation round-trips pass.

The Julia/Nemo check passes 47 checks and is an imported-matrix exact backend
replay, not independent target construction. Its frontend/runtime is distinct,
while FLINT is shared.
The initially incorrect endomorphism test on a mixed ordered word is retained
as a negative control. A swap between different ordered spaces must be composed
with the correctly typed return swap, not squared in one coordinate basis.

The mandatory `u_H_singlet*(Phi_H_singlet)^4` witness is preserved as a nonzero
dimension-five, ghost-one, weight-four target. Its bounded final operator
control passes, including the frozen physical heavy-0/scalar-4 value of one.
This witness does not by itself qualify the complete target.

All 151 derivative-free, no-background sectors have a final statistics census
of 357,834 directions, matching the independent Adams/weight-character route.
The remaining 29,283 directions come from the 91 background/derivative sectors,
whose primary statistics dimensions agree with the independent full-character
replay block by block.

The target serializer initially keyed projector views only by representation
matrices and parity. Thirty-one exact collisions demonstrate why that is
insufficient: the species-wise statistics character must also be bound.
The corrected 1,298 singleton evaluator views preserve the sector counts and
canonical intended bases. Historical unscoped files remain non-authoritative
evidence; active addresses reference character-qualified views only.

## Active data and reproducibility

New generated T5 data are stored at the explicitly declared active-data root
in `T5_ACTIVE_DATA_LOCATION.json`, outside Git under the Charter's storage rule.
This is not a dependency on historical custody and uses no junction, symlink
or silent fallback. Source, checkpoint, hashes and retrieval/reproduction
instructions belong in this repository. A missing declared payload is an
explicit unavailable condition.

The construction manifest binds 111,898 generated/provenance files with
330,888,588 payload bytes, through 28 independently hash-bound manifest shards.
The payload remains below the 500 MiB storage ceiling; no individual artifact
exceeds 10 MiB. Historical unscoped evaluator records remain explicitly
non-authoritative rather than being deleted or silently rewritten.

Use PowerShell with `PYTHONDONTWRITEBYTECODE=1` and `PYTHONPATH` pointing to
`tools/pole_blind_validation_guard`. Do not execute with Python optimized mode.
The complete construction order is encoded in the `RECIPE` in
`t5_release.py`; use its driver rather than manually reordering individual
steps. `t5_release.py --construct` performs incremental construction only.
Both singleton and active independent character censuses precede their
corresponding primary statistics comparisons. The driver also includes
custody, component-evaluator, typed-covariant-jet reuse and metadata controls.

When all construction gates have passed, use `t5_release.py --regenerate`,
then `t5_release.py --validate`. Only the passed release receipt permits
`t5_release.py --promote`; this synchronizes target-only status and performs
post-promotion read-only checks. These commands do not construct C5.

Every new target ID is serialized with its completion class, nonzero orbit
ordinal and exact local-basis column. The local decoder retains the statistics,
IBP, packet, realization, internal-channel and Lorentz/derivative ancestry;
materialization does not require a dense global matrix.

`--resume` reuses hash-bound completed local blocks; it is not by itself a claim
that every artifact was independently regenerated. Promotion requires the
separate acceptance and validation receipts.

The fresh regeneration driver uses neither background `--resume` nor
statistics `--resume`, and uses packet-structure `--force`. Hash reuse during
ordinary incremental construction is therefore not confused with the separate
byte-identical regeneration gate. Historical unscoped serializer outputs and
negative controls are immutable evidence, not silently rewritten using the
corrected rules.

Independent final reconstruction uses complete colored-polynomial comparisons
for manageable blocks and preregistered exact component comparisons for large
singleton tensor blocks. A component control is not described as independent
full-tensor reconstruction. Completeness rests separately on the qualified
factorized ranges, exact representation equations and independent censuses.

No current or historical pole/projection payload is an input. A guarded
repository-wide validation denied at the legacy D5 payload is recorded as
`GUARDED_ALL_VALIDATION_STOPPED_AT_FORBIDDEN_LEGACY_POLE_READ`, never as an
unrestricted validation PASS.

## Earned release and stop disposition

Fresh reconstruction reproduced all 111,898 active-data files byte for byte,
including all 387,117 newly materialized finite operator addresses. The 28
manifest shards and the bound scientific/release source hashes also reproduce.
The authoritative release records are:

- `T5_REGENERATION_RECEIPT.json`: fresh byte-identical regeneration, without
  importing completed construction blocks in place of reconstructing them.
- `T5_TARGET_VERIFICATION.json`: complete target audit, authority coherence,
  structure-preserving-map policy, read-only contract and candidate-gate audits.
- `T5_TARGET_POST_PROMOTION_VERIFICATION.json`: the same read-only obligations
  after target-only status synchronization, with zero workspace and active-data
  mutations.
- `T5_target_catalog_checkpoint.json`: earned target promotion, unchanged
  scientific authority and explicit H-basic/C5 stop boundary.

Both successful validation intervals record the denied historical D5 read;
neither claims unrestricted repository-wide validation PASS. Scientific payload
byte reproducibility is distinct from contextual release receipts and the
checkpoint's frozen release timestamp.

The first post-promotion authority audit detected a stale README blocker after
the complete target audit passed. This release-integration failure is preserved
in `T5_POST_PROMOTION_STATUS_NEGATIVE_CONTROL.json`. The explanatory dashboard
was synchronized and validation rerun; no mathematical condition, scientific
source hash or target coefficient was changed to obtain agreement.

A final read-only union API smoke check reconstructs the referenced old operator
`JOP_8d11558fc9b6808d9df78d6c` and the new mandatory witness
`T5OP_ed4e8df994747dfb3164a764`, each with a nonzero one-term representative.
Workspace and active-data metadata remain unchanged. This is an evaluator
dispatch check, not an additional independent construction or cohomology claim.

Execution stops at target-catalog adjudication. H-basic qualification,
`D_-1`, `D_0`, differential ranks, EOM quotient, `H^0`, `C^+2`, `H^1`, C6,
D6, E, formal M08 attempt 2, M09-M13, Layer 6 and `C1_GS` remain unexecuted.

## External AI-mathematics context — no active scientific authority

The [OpenAI mathematics repository](https://github.com/openai/math) reports
722 manuscripts in 372 families from roughly 4,000 problems, and explicitly
warns that unformalized results may contain issues. The
[announcement](https://openai.com/index/sharing-ai-progress-in-mathematics/)
describes an internal model, not a capability guaranteed in this execution.
These are reported release statistics, not a measured speedup for M08 or a
ToE result.

[AGMAI's statement](https://agmai.org/general-sep29/) emphasizes provenance,
formal checking and human interpretation. It also criticizes open-problem
evaluation of closed proprietary frontier systems; it must not be presented
as a blanket endorsement of the release. Formal correctness, understanding,
physical relevance and experimental truth remain separate obligations.

## Scientific ceiling

Formal authority stays `34/39`; M08 attempt 1 remains blocked, attempt 2 is
unauthorized, E is unexecuted, Layer 6 is unauthorized and `finite_C1_GS=null`.
Target qualification does not establish anomaly freedom, cohomology,
renormalization closure or phenomenological viability.
