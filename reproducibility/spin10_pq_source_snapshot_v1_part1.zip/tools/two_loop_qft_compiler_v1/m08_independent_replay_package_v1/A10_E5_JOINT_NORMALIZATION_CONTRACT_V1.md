# E5 joint ghost/nonminimal normalization and auxiliary companions

1. Question: can the actual source poles, zero g*xi ghost kinetic pole and
   g*xi gauge–auxiliary pole coexist in one typed canonical normalization,
   with the auxiliary width treated according to its actual loop coefficient?
   Baseline d138e58, statev113/34of39,28 sealed predecessor chains.
2. Keep full643 pairs,48 external H backgrounds,34 physical/nine source terms,
   E2 gauge fixing, potential/vacuum/parameters, nonsymmetric coset/R_H and
   both nonminimal sectors. No field/source removal or auxiliary elimination.
3. Freeze the coordinate types: C primal, ubar/Lambda dual-heavy, BV J their
   evaluation duals. N_M=kappa_aux G_M=U^-1 kappa_phys U. Ordinary derivative
   and source pairing are distinct from Lorentz/carrier metrics. Reuse the
   authenticated inverses; verify products rather than re-inverting them.
4. Derive the field/source normalization from the already computed JB-C and
   Jx-C-x source columns, zero ghost kinetic pole and free Q0 ubar=-Lambda.
   This fixes delta C=+g xi N C and delta ubar=delta Lambda=-g xi N_M^T times
   the corresponding field, with opposite evaluation-source transformations.
   Do not assume that this source-linear generator suffices for the full action.
5. Independently integrate the complete selected g*xi B-Lambda two-point
   bubble at nonzero spacelike momentum. Primary graded Hessian/Born and
   replay closed-ghost Gaussian determinant must retain all4 Lorentz weights,
   odd order, derivative placements, all45 external B/33 auxiliary directions,
   full qualified mixed reference and H zeros. Include any literal competing
   vertex/tadpole or prove absence by coupling, leg and derivative inventory.
6. Adjudicate the order-g*xi^2 Lambda-Lambda pole separately. Reuse the qualified
   order-xi^2 width result. A one-loop two-point cubic/quartic graph inventory
   must prove whether g*xi^2 is absent, rather than using an exceptional
   scaleless integral. Width/reference factors are retained with their types.
7. Compare the complete source-linear canonical image with these actual poles.
   If a width discrepancy requires a source-free fermion primitive, derive it
   from the exact first-variation/width equation and Q0 doublet, in the admitted
   polynomial ring and H-invariant tensor space. No fitted physical coefficient
   or frozen fermion change. Record the primitive ambiguity and scope of its
   uniqueness. A derived unphysical subtraction is an inactive candidate.
8. Form one complete generator, derive its Q image and explicit density current
   from the full E2 polynomial, and independently compare it with the direct
   canonical first variation. Preserve every term, composite and remaining
   unmatched projection. Check old source projections, the ghost kinetic zero,
   B-Lambda and selected width coefficients exactly before claiming a match.
9. Verify canonical evaluation pairings, grading, inverse to first order,
   all12 residual-H maps, real physical frames and jets for the resulting
   field/source transformation. Retain the regulated integrated-field
   Berezinian, distinguish external sources, and keep the hbar-order counting.
   These are classical/formal transport controls, not full quantum A5.
10. Keep heat-cutoff powers, kinetic/logarithmic poles, finite local terms,
    dimensional scalar residues and physical IR removal distinct. Required
    breaking/current terms are retained; no full restoration/anomaly claim
    follows from matched selected poles. No new JC-C-C/JB-B-C loop in this task.
11. First essential mismatch/underdefinition stops with an exact independent
    Euler witness. Negative controls omit the paired normalization, width
    primitive, Lorentz/odd/Gram factor or nonsymmetric tensor. Preserve failed
    and unfinished executions. Fresh own-byte routes,28 parent chains,
    protected/new/state hashes and metadata audit; custody2/seven never PASS.
12. Shared input/charts/arithmetic/Python/SymPy/analyst disclosed; solo review.
    No activation/catalog/HB1/C5/C1_GS/matching, authority change, outreach,
    publication or push. Validate before local commit. Full E5/A1–A5/contacts,
    physical IR, global boundedness/PQ quotient, fermion/Yukawa/phenomenology
    and the complete Spin(10)xU(1)PQ investigation remain active/incomplete.
