"""Fermion jet-gradient replay and independent affine differential transport."""
from a10_e2_transport_common import *
from a10_e1_fermion_replay import direct_euler

def build(stage=lambda n,f:f()):
    w,e1,data,cols,psi,A=stage('independent_E1_physical_pullbacks_and_Stage_D_columns',lambda:inputs('replay'))
    can=stage('graded_Hessian_and_inverse_replay',lambda:canonical_checks(psi,A,w,stage))
    Qpsi=stage('independent_fermion_jet_gradient_BRST_variation',lambda:canonical(derivative_action(psi,w,cols)))
    L=action_boundary(A,cols,psi,w)
    delta=canonical(w.add(Qpsi,w.add(*(w.D(P,mu) for mu,P in enumerate(L)))))
    # Direct affine transport of each old reverse column; no primary result read.
    correction={}
    for z,J in w.pairs:
        correction[J]=canonical(w.add(shift_correction(cols[J],A,w),w.scale(derivative_action(A[J],w,cols),-1)))
    el=stage('independent_gauge_fixing_physical_jet_covectors',lambda:direct_euler(delta,w,set(w.fields)))
    for z,J in w.pairs:assert el[z]==correction[J],('REPLAY_DIFFERENTIAL_CONJUGACY',J)
    master=stage('complete_master_replay_from_transported_columns',lambda:master_certificate(delta,correction,cols,L,w,'replay'))
    columns,physical=stage('complete_replay_1286_columns_and_physical_programs',lambda:complete_columns(cols,correction))
    old=decode_typed(data['source_polynomial']);transformed=canonical(w.add(old,delta))
    return finish('replay',A,delta,correction,can,L,master,columns,physical,
      {'source_terms_executed':0,'physical_terms_preserved':34,'transformed_source_polynomial_sha256':digest(rows(transformed)),
       'source_polynomial_coefficients':len(transformed),'exact_column_conjugacy_checks':1286,
       'source_substitution_method':'independent Q Psi jet-gradient with explicit boundary, affine U Q U^-1 reverse columns',
       'primary_outputs_imported':False,'action_boundary_identity':'Delta=Q Psi+div L, with the fixed source-left orientation'})
