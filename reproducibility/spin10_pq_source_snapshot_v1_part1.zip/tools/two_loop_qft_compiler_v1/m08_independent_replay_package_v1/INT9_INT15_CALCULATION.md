# Ordered internal basis qualification after conjugation

Resume local commit `183122a`. INT7R and INT8 V2 remain promoted and immutable.
This calculation qualifies the remaining internal basis interfaces; it does
not calculate a loop amplitude or change formal scientific authority.

## Task contract

Physics decision enabled: eventual calculation of the finite centered
gauge/scalar threshold for the frozen canonical benchmark.

Current blocker removed: `M08_INT9_INT15_EXACT_INTERTWINER_CHANNEL_BASIS_PENDING`,
only if every prescribed INT9 through INT15 gate passes.

Why existing tools are insufficient: INT6 supplies addresses and INT8 supplies
conjugation, but neither certifies the CAT3/C3 spans, complete parent and source
embeddings, or the bounded BRST interface.

Minimum new implementation surface: calculation-local exact swap, physical
span comparisons, extensions of the promoted lowering, readiness certificates,
bounded replay and read-only audits. Reuse qualified carriers and dual maps.

Structure-preservation obligations: typed coefficient maps, full tensor
reconstruction, H/PQ covariance, pairing and conjugation compatibility, exact
involutions, and independent physical-coordinate replays where prescribed.
Slot swap may be a finite multiplicity-block matrix. No coordinate simplicity
requirement or canonical basis rotation is introduced.

Stopping condition: the first exact failed obligation, or INT15 adjudication.
INT9 is only a bounded two-slot regression. Never enter JCAT3 through JCAT12,
Lorentz jets, IBP, final statistics, C5, C6, D6, E, formal attempt 2, M09 through
M13, Layer 6 or C1_GS.

What will be deleted or deactivated if this does not work: no historical or
promoted input is deleted. The failed candidate stays calculation-local and
cannot transfer scientific authority; its exact residual is frozen.

## Frozen acceptance sequence

INT9: all 89 bilinears, exact swap squared identity, spectrum 46 plus 43,
trace 3, and bidirectional full tensor span with the immutable CAT3 basis.
INT9R reconstructs swap from physical canonical-real bilinears without primary
swap coefficients. Higher-multiplicity mixing is permitted, not demanded if
none occurs in this particular frozen basis.

INT10 and INT10R: all 49 heavy and 19 light C3 trilinears, exact bidirectional
physical span, H/dual/conjugation compatibility and independent component solve.

INT11 and INT11R: all 29 parent families and 34 real directions through the
promoted independent A3 lowering; freeze coefficients before independent
reconstruction, retaining separate complex monomial and HC branches.

INT12 and INT12R: every prescribed source, ghost, auxiliary and gauge-fixing
role, exact frozen coefficients and independent action/component controls.

INT13: freeze eight-sector coverage before applying B_Sigma; exact finite
channel reconstruction only. No cochain census, rank, quotient or H0.

INT14: independent character counts for every current signature and the seven
preregistered controls. INT14N uses Julia/Nemo for bounded exact backend replay
and reports imported primary data honestly.

INT15: all seventeen completeness obligations in the user contract. Promote
the complete ordered basis only after all preceding gates pass.

## Custody and validation

The existing pole-blind guard remains enabled for every Python execution.
Current and historical loop pole/projection directories may not be opened.
Hash-bind incoming inputs, freeze primary maps before comparison, preserve
negative controls, and record independence dimensions separately.

All audits are read-only. Require deterministic byte regeneration and zero
workspace-file mutation during bounded audits and guarded full validation.
A forbidden legacy D5 open is denied before access and reported as
`GUARDED_ALL_VALIDATION_STOPPED_AT_FORBIDDEN_LEGACY_POLE_READ`, not a full PASS.
Commit locally without pushing. Preserve `34/39`, M08 attempt 1 BLOCKED,
attempt 2 unauthorized, E unexecuted, Layer 6 unauthorized and finite C1_GS null.
