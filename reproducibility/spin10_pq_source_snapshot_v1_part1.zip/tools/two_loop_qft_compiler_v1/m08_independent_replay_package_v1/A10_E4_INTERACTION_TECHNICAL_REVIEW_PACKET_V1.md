# E4 technical review packet

This packet records the derivation obligations, not external endorsement or a
formal-authority promotion. The completed result and validation receipt own
the bounded execution classification. The governing contract is
`A10_E4_INTERACTION_CONTRACT_V1.md`; the full D–E3 system remains inactive.

## Distinct operations and frames

The full source-left BV operator is Q'=(S',.). Its 643-pair canonical system,
all sources, auxiliaries and external H backgrounds remain intact. The heavy
restricted derivation delta acts on B, x, u=C_M, ub and L: 607 fields. It does
not act as a quotient of the full system by c_H=0. Full Qc_H at c_H=0 is g R_H,
so that ideal is not Q-stable. Light bar,b remain full-BV trivial pairs; they
are not mislabeled as heavy equivariant pairs.

Heavy ghosts and connections are primal. Heavy ub,L use FM=QM GM^-1;
GM=QM^T QM. Their invariant field bilinear is GM^-1. Their evaluation-dual
sources use QM and the canonical identity pairing. These two pairings must
not be interchanged. Light fields use QH and GH=QH^T QH. Backgrounds remain
external and fixed for delta; no canonical sources are invented for them.

With the exact parent structure constants and g=g10, the restricted rules are

    delta B=partial u+g[B,u], delta x=-g rho(u)x,
    delta u=-g[u,u]_M/2, R_H=-[u,u]_H/2,
    delta ub=-L, delta L=g^2 D(R_H)ub.

The D matrices here act on the dual-heavy carrier. Separating the residual
ghost terms from the qualified full rules yields delta R_H=0 and
delta^2=-g T_(R_H), where T already contains g in its homogeneous action.
For a local composite parameter, the gauge column includes partial R_H.
Ordinary derivatives commute with the prolonged derivation. Computational
jet caps raise and never identify an excessive jet with zero.

## Canonical composite chain rule

The restricted source Hamiltonian is S_delta,1=sum J_z delta z with sources
on the left. It is even. Its columns are Q_delta z=Euler_left,J S_delta and
Q_delta J=Euler_left,z S_delta. The separate odd Ward generator is

    H_R=-sum_z (-1)^p_z J_z T_(R_H) z.

The source-degree-one curved master density must obey

    (S_delta,S_delta)_1=-2g H_R+div(2 sum_(a in M) JB_a delta u_a).

The physical source-degree-zero term is the authenticated Noether divergence
2 div(E_B u), without imposing equations of motion. Graded Jacobi then gives
Q_delta^2=-g X_(H_R) on sources and fields as local functionals. This is a
curved diagnostic; it is not a failure of the full BV master equation.

Euler differentiation of H_R includes derivatives of R_H with respect to u.
Differentiating with an independent parameter first and substituting R_H
afterward discards those terms. The difference lies in heavy ghost-source
columns. The computation compares the complete curved master and canonical
columns, and explicitly expands selected source squares to challenge the
structural conclusion. All-source/all-jet conclusions use Jacobi and ordinary
prolongation, rather than claiming every source square was freshly enumerated.

In the complete full system the exact source-density decomposition is

    S1 |_(c_H=0)=S_delta,1+g sum_h JC_h R_h-sum_h Jbar_h b_h.

The derivative of the retained JC_h R_h bridge supplies further ghost-source
chain rules. This comparison keeps those full-system terms. It does not
eliminate sources, integrate out auxiliaries or promote a 607-pair replacement.

## Fermion, coefficients and boundaries

The replacement heavy fermion consists of the total-H covariant divergence,
shifted scalar orbit, inverse-Gram auxiliary pairing and nonsymmetric cubic
term. The light fermion is retained independently. The required comparison is

    Delta_E2=delta Psi_M+Q Psi_H+div L,
    L^mu=eta_mumu (sum_M ub_i QB_i^mu+sum_H bar_h GH_hk QB_k^mu).

Both complete densities and the explicit current must agree. The physical
action, its 508 Euler programs, all source terms and the E3 operators remain
byte-bound dependencies. Reproducing this complete E2 gauge-fixing density
preserves the E3 Ward and BRST conclusions through identity of the action;
E3's expensive calculations are authenticated, not re-expanded here.

For physical U=FM ub and u_phys=QM u, two quartic contributions follow before
any auxiliary elimination:

    curvature: (xi g^2/2) <U,[U,R_H,phys]>,
    nonsymmetric: -(alpha g/4) <U,[U,P_M[u,u]]>, alpha=xi.

The brackets are physical Lie brackets; only their admitted projections and
embeddings are used. The second term is nonzero for the actual nonsymmetric
coset. The coefficients follow from varying the frozen replacement fermion,
not from fitting a residual. Light variation and the displayed boundary
current must contribute no additional pure quartic ghost coefficients.

The comparison with [Ferrari, Sections 3 and 4](https://arxiv.org/html/1308.6802v3)
supports the restricted equivariant square, nonminimal pair and two quartic
structures. His coupling-absorbed conventions must not be substituted for
the project's unscaled u and explicit g. Here alpha=xi multiplies u; no
parameter or ghost rescaling is performed. The sign of the action contribution
is the project's qualified positive Q Psi plus its boundary current.
[Thomsen](https://arxiv.org/html/2404.11640v2) motivates retaining these
interactions in partial background gauges; it supplies no C1_GS calculation
or certification of this implementation.

## Adversarial and trust boundaries

Controls remove curvature, falsely impose a symmetric coset, discard each
quartic contribution, substitute the bare heavy pairing, freeze curvature
before source differentiation, or incorrectly extend the heavy square to
light trivial pairs. Each must fail with exact nonzero evidence. The initial
new-helper sign error is preserved separately: an odd-generator extraction
was used for an even Hamiltonian. Its failed runs are not E4 PASS evidence.
The correction restores the existing Stage D contract; it changes no physics.

Primary prefix/canonical variation and replay physical-matrix/jet-gradient
variation share Python/SymPy, multiplication, immutable representation inputs
and analyst. Their agreement is reproducible computational evidence, not
external endorsement or a proof-kernel formalization. E5 domain adequacy,
historical fermion equivalence, quantum anomalies, gauge independence, loop
matching and phenomenological viability remain outside this qualification.
