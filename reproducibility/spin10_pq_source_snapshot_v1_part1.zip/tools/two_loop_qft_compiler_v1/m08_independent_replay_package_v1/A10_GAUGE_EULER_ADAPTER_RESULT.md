# Canonical gauge Euler adapter: bounded inactive qualification

The separately named canonical gauge Euler operation passes its approved
gauge/scalar physical-action qualification. It reproduces the full first
variation, including its boundary current, without modifying the historical
helper, action, physical parameters or source definitions. The 643-pair
source-only construction remains authenticated and inactive. Full BV assembly
and Stage D resumption were not undertaken.

The checkout began clean at 6fc602d, with no relevant surviving calculation.
All predecessor bindings authenticate, including the historical A10 scalar
failure, scalar factor-120 witness, mixed-source/canonical-map controls and
the saved gauge-Euler failure. The solo-review policy remains in force.

## Exact general result

Independent coordinates are lower B_mu^a in the orthonormal real plane frame.
Canonical component differentiation uses identity deltas in both the internal
and Lorentz slots. eta weights belong to the literal action's summations.
For the approved -1/4 F^2 normalization, the new operation gives

    E_a^nu = partial_mu F_a^(mu,nu)
             +g10 f^(a,b,c) B_mu^b F_c^(mu,nu)
             +g10 sum_s (D^nu x_s)^T rho_a x_s,
    Theta^mu = -F_a^(mu,nu) h_nu^a,
    delta_B L = E_a^nu h_nu^a + partial_mu Theta^mu.

The gauge term includes all derivative, cubic and quartic contributions at
arbitrary fields and jets. Scalar currents cover Phi, Sigma, phi and S; the
singlet current is identically zero. The 29 potential terms contain no B and
have identically zero gauge first variation. Gauge connections are varied
before any projection. Neither equations of motion nor fitted parameters are
used. The total connection convention retains the full 45-generator quantum
symmetry; the H-only background and vacuum are fixed in this investigation.

| Independent coefficient comparison | Exact coverage |
| --- | --- |
| Gauge Euler covectors | 135,000 nonzero coefficients across 180 components |
| Boundary momentum | 9,720 nonzero coefficients across 720 components, including implicit zeros |
| Factorized scalar currents | 30,408 nonzero coefficients: Phi 4,488; Sigma 25,200; phi 720; S 0 |
| Historical free controls | All 16 Lorentz component/jet-direction pairs |
| Pure gauge Noether identities | All 45 components freshly expanded to zero |
| Matter skew-pairing controls | All 180 representation matrices |

The primary route applies component partials to the literal executable AST,
retaining each weighted binder, and derives ordinary integration by parts.
The replay derives physical 10x10 Lie brackets, varies the antisymmetric
two-form, collects arbitrary test-field and test-jet coefficients, and also
compares the result to the covariant field-strength divergence. All 135,000
Euler and 9,720 boundary coefficients agree exactly. The first-variation
identity is checked through both force and momentum coefficients, so a
boundary discrepancy cannot hide behind agreement on a final Euler column.

The scalar-current comparison treats Z=D x as an arbitrary vector in every
component and checks the literal-AST directional variation against an
independent bilinear construction. Substitution of the previously qualified
exact covariant derivative is a polynomial identity at arbitrary nonzero B.
Its 31,720 derivative coefficients are authenticated predecessor evidence,
not recalculated here. Fresh direct Euler controls keep all scalar coordinates
and two noncommuting nonzero connection directions. These controls supplement
the general factorized proof; they are not its only basis.

The full Noether identity is

    partial_nu E_a^nu+g10 f^(a,b,c) B_nu^b E_c^nu
       +g10 sum_s E_x,s^T rho_a x_s = 0.

The gauge part is independently expanded for all 45 components. The matter
part follows from skew pairings, qualified representation commutators,
E_x=-D_mu D^mu x-V_x supplied by the qualified scalar adapter, and the
authenticated 29-direction potential Ward identities. These latter
commutator/potential proofs are inherited structural dependencies, not a fresh
exhaustive expansion of every potential derivative. No off-shell identity is
made true by imposing E_x=0.

## Diagnosis, typed scope and source interpretation

An exact minimal AST demonstrates the old defect: simplifying
sum_mu eta_mu delta_(mu,out) W_mu removes the binder and yields W_out,
where the component result is eta_out W_out. This proves a metric-weight loss
in that contraction pathway. The old free witness remains +b'' versus
canonical -b'', with residual 2b''. Its non-Abelian quartic control remains
correct before a final eta multiplier and incorrect afterward. Thus the
diagnosed pathway does not justify a universal output sign repair.

The new adapter retains the action's sum measures and uses typed identity
deltas. Its accepted domain is the approved even first-jet physical compiler
grammar with a Lorentz sum covering the whole monomial. Odd/source calculus,
higher input jets, unsupported nodes, output index capture and products of
independently closed Lorentz sums outside that grammar are rejected. It is
not a general graded BV or unrestricted symbolic tensor derivative engine.
The qualifying calculations cover arbitrary field components, polynomial
interactions and jets of the declared physical action within this domain.

The canonical source is upper evaluation J_a^mu, paired with lower B_mu^a.
The literal historical eta-contracted lower vector source has the chart map
J_a^mu=eta_mu K_(a,mu). For the light catalog convention, compose the qualified
Gram bridge: J_(H,mu)=eta_mu G_H k_(H,mu). The corresponding induced raw-chart
brackets carry eta and G_H^(-T) tensor eta, respectively; the canonical bracket
remains identity. Internal fields B_plane=Q B_parent induce sources
J_plane=Q^(-T) J_parent and Euler covectors E_parent=Q^T E_plane. All 180
pairings, inverses, conjugation and ordinary-jet transport checks pass. The
source-left physical contribution is Q J=+E. No historical source chart or
source definition is edited or activated.

During development, a boundary projection initially placed its delta outside
the derivative-slot binder and failed an output-label assertion. The corrected
construction places that projection inside the original binder, as required by
the first variation. There was also a corrected predecessor JSON-key lookup
and zero-support handling in the historical slice evaluator. These development
exceptions supplied no accepted scientific output. The final code/evidence is
freshly regenerated during validation; no witness coefficient was adjusted.

## Historical dependency review

The investigation directly evaluates the saved S6 reverse K_V/K_q images and
S7 V_H/q_L EOM records on heavy/light free spatial channels. The complete old
source-zero density reduces to (partial_0 b)^2/2 in both. Direct component
variation gives -b'', while both saved outputs give +b''.

Those selected values cannot be canonical component Euler covectors. They
could match a lower-source chart in this free channel. The already preserved
interacting counterexample prevents promoting that observation to a uniform
chart interpretation of the defective helper. Full historical interacting,
gauge-fixed source columns require a later derivation in a declared chart.
This is not a claim that every historical source column is wrong.

The recorded dependency chain is execute_variational_s5_s8.field_derivative
to S6 reverse images and S7 EOM records; its V6/V7 gauge controls and vector
source_image paths are also flagged. source_component_decoder forward-vector
recovery remains a historical helper consumer. Its six internal frame proofs
remain authenticated, supplemented by this explicit Lorentz interpretation.
The scalar adapter, potential-only benchmark and representation results keep
their tested scopes. Historical bytes and acceptance ledgers are unchanged.

## Validation, limitations and next decision

The validation receipt records 92 passing targeted regressions: 17 new and 75
inherited. Three new read-only routes regenerate byte-identically. Inherited
expensive representation calculations and the 35,162-monomial source assembly
are authenticated rather than repeated. Workspace/active-data size-and-mtime
inventory and inherited byte bindings are checked separately; the inventory
is not an unrestricted all-byte workspace audit.

Audit status is PASS_BOUNDED_CANONICAL_GAUGE_EULER_ADAPTER_EVIDENCE_ONLY.
The scientific disposition is QUALIFIED_INACTIVE_EVEN_PHYSICAL_GAUGE_EULER_OPERATION.
Historical custody remains strict exit 2, seven unresolved references. Formal
authority and project_state.json remain 34/39 and unchanged.

Primary and replay share the physical assumptions, immutable representation
inputs, Python/SymPy, some arithmetic/serialization and the same analyst. No
external endorsement is claimed and no personal contact or outreach occurred.
Published literature supports the method, not this implementation's validity.

The next decision is whether to authorize a new inactive Stage D integration
that reuses this physical gauge Euler operation, the scalar cotangent adapter
and authenticated source-only construction under one canonical bracket. That
calculation must derive complete physical source columns and test the full
master equation and source-jet nilpotence. None is established here. Stage E,
Phase C continuation, activation, HB1/C5, catalog rebuilding and C1_GS remain
blocked or uncalculated. No physical parameter, formal authority or remote
repository changed.
