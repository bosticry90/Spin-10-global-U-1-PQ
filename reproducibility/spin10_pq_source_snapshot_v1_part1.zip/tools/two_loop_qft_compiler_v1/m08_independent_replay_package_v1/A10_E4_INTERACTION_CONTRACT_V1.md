# E4 inactive composite/nonminimal/quartic reconciliation contract

Authorization: the user assessment of `1dc61f0` and compatible process
incorporation request. Authenticate twelve D–E3 predecessor manifests; reuse
their qualified physical programs, canonical conventions and replacement
fermion. Preserve all prior bytes and formal authority 34/39. Solo review
permits primary literature, never personal contact or endorsement claims.

Keep the complete 643-pair E2/E3 BV system, all auxiliaries and 48 external
H backgrounds. Q' is its retained-source nilpotent BV differential. Define
the distinct restricted heavy derivation on B, x, u=C_M, ub and L, with
the background fixed. Its 607-field algebra excludes light ghosts and light
nonminimal fields; it is not a quotient by a Q-stable light-ghost ideal.
The full candidate and those excluded coordinates remain intact.

Derive the restricted field rules by separating residual-H terms from the
qualified field transformations. Independently reconstruct them from physical
Spin(10) matrices and primal/dual embeddings. Freeze R_H=-[u,u]_H/2 without g
in its definition. Verify its twelve components, delta R_H, local H covariance,
ordinary symmetric jets, and delta^2=-g10 T_(R_H), including derivative terms.
Do not impose a symmetric coset or delta^2=0 on unrestricted fields.

For restricted source diagnostics use evaluation-dual canonical partners of
those 607 fields and the source-linear Hamiltonian sum J delta z. Derive its
curved master identity, with explicit gauge boundary current, and the induced
cotangent square including derivatives of the composite curvature with respect
to u. A field-dependent residual parameter must be differentiated before any
substitution. This diagnostic is not the full 643-pair BV action restricted by
blindly setting c_H=0. Retain and compare the missing full-system terms and
their chain-rule contributions explicitly. Physical Euler terms use the
qualified adapters and local Noether proof, not invented covector variables.

Reconstruct delta Psi_heavy and Q Psi_light in complete local coefficients,
including divergence, total-H connection, shifted orbit, inverse-Gram auxiliary
pairing and nonsymmetric cubic term. Compare their sum, plus the independently
derived integration-by-parts current, with the actual E2 gauge-fixing density.
Compare every quartic ghost coefficient, including zeros and separate curvature
and nonsymmetric contributions, through an independent physical bilinear route.
Parameters g10, xi, eta_H and alpha=xi retain their replacement meanings.
No fitted rescaling, historical equivalence assertion or auxiliary elimination.

Check heavy equivariant action invariance, the full light/nonminimal source
relationships and composite chain rules. Preserve the E3 geometric quantum
breaking, transported quantum symmetry and background Ward identities through
authenticated unchanged E2/E3 action and operator programs. Negative controls
must detect removed curvature, removed nonsymmetric structure, wrong Gram
pairing, falsely nilpotent restricted rules and frozen composite source
derivatives. Two routes share assumptions, Python/SymPy and analyst; disclose
this. A completed matching computation is not external scientific verification.

Stop at the first failed or underdefined essential identity, preserve its exact
witness and independently reproduce it. If a scope definition would require
new foundational architecture, stop that portion for a concrete proposal while
continuing safe process work. Validate completed bounded results, including
historical custody exit 2/seven unresolved bindings, before a local commit.
E5, source activation/adoption, catalogs, HB1/C5, finite C1_GS, quantum matching,
formal promotion, publication and remote push remain withheld. A PASS supports
only a separate E5 decision, not automatic execution.
