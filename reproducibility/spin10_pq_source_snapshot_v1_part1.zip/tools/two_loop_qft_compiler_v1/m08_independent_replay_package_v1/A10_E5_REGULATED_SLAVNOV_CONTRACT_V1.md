# E5 complete-field regulated one-loop Slavnov identity contract

1. Question: what is the actual one-loop Slavnov breaking of the qualified
   retained-source Hessian family, and how do its regulated and original
   classical source operators differ? Derive before attempting restoration.
2. Baseline: clean89deb04, statev113/34of39,25 sealed predecessor chains.
   Reuse the complete Hessian/reference and StageD--E4 proofs, not the failed
   fractional action kernel. Preserve all643 fields/sources,48 H backgrounds,
  34 physical/nine source terms, potential parameters, xi cubic and R_H.
3. Types: even test transformation delta_epsilon z=epsilon_left Qz, epsilon
   odd external bookkeeping; full first-field-jet tangent Jacobian and ordinary
   symmetric jets. Freeze sources only during fluctuation differentiation.
   Sources keep their complete canonical Hamiltonian transformation.
4. Derive the full643 field-tangent program by direct graded replacement and
   independent left-gradient differentiation. Check complete row streams,
   implicit zeros, jet directions, conjugation and physical-frame diagonal
   carriers. Do not infer a continuum measure from the old formal divergence.
5. For each actual carrier check physical skewness of the diagonal Jacobian
   and H-covariant, self-adjoint heat-kernel trace at coincident points. The
   heat Jacobian is a specified one-loop measure control, not general anomaly
   freedom. Include wrong-frame and non-self-adjoint-profile negative controls.
6. Write S_Lambda=S+V_Lambda with source-free quadratic kernel
   DeltaK=F^-ST Kref F^-1-Kref. F is the qualified H-covariant heat cutoff;
   no physical parameter/field is added. This realizes the same interaction
   Born determinant. Its full Hessian is H+DeltaK, inverse G_Lambda,full.
   Retain the reference/background determinant and its contour normalization.
7. Derive B_Lambda=(S_Lambda,S_Lambda)/2=Q V_Lambda and
   Q_Lambda=Q+(V_Lambda,.). Compare direct Born variation with the Gaussian
   breaking insertion, including the correction (V_Lambda,Gamma1).
   The Hessian of B_Lambda contains V_i R^i_,jk; that contribution must cancel
   the corresponding source-derivative correction when using original Q.
   Never require B_Lambda or its full one-loop insertion to vanish at finite
   cutoff. Keep the heat Jacobian and all boundary currents explicit.
8. Verify an actual local phi generator-plane breaking with different Fourier
   momenta and the complete-action exclusion argument. Check the ghost Euler
   coefficient and source-column correction; constant parameters must miss
   the selected defect. No fitted interaction or action adoption follows.
9. Independently replay a nonlinear retained-source Gaussian with nonzero
   source correction; distinguish Q_Lambda Gamma1 from Q Gamma1 exactly.
   Verify finite perturbative Born coefficients and an all-order formal word
   induction without claiming all finite amplitudes were integrated.
10. Domain: formal Wick/contour inverse and nonexceptional external momenta.
   Any temporary IR spectral projection contributes its own breaking/contacts;
   it cannot be dropped or assumed BRST-preserved. The unprojected formal UV
   word identity is not a proof of a complete IR/continuum path integral.
11. First-failure rule: preserve an unexplained matrix/sign/source discrepancy
   and stop. Qualification of this identity, measure control or tree witness
   does not qualify local restoration, all probes/contacts, quantum A5,
   anomalies, physical IR, M2--M5/A1--A5, E5, HB1/C5 or C1_GS.
12. Start hashes precede calculations. Distinct routes, full exact comparisons,
   negative controls, immutable outputs, fresh own-byte reproduction,25 parent
   manifests, state/protected/new SHA and metadata checks, custody2/seven.
   Shared inputs/word arithmetic/Python/SymPy/analyst disclosed. No activation,
   elimination, catalog, authority change, outreach, publication or push.

The full Spin(10)xU(1)PQ goal stays active and incomplete. This investigation
advances the actual quantum consistency question rather than changing its target.
