# Finite selected ghost prescription, prospective extension

The completed main records are retained unchanged. This extension must compute
the finite subtracted nonexceptional two-auxiliary ghost amplitude, not merely
assume the existence of a subtraction. It uses their complete kappa and the
same frozen contracts, without promoting full M2/A1--A5.

For this ghost bubble alone take m_reg=0 and 0<Re(e)<1. Its nonzero external
Euclidean momentum separates its two soft regions, so each is integrable;
the UV is integrable for e>0. The exact four-dimensional analytic-regulator
bubble is derived by Feynman/Schwinger parameters with propagator powers
1+e/2. Subtract its Laurent pole and compute the finite momentum function.
Replay uses the scalar dimensionally continued bubble and modified minimal
subtraction. Record their finite LOCAL scheme difference rather than require
unexplained identical finite constants. That difference multiplies the same
kappa and is Q0-exact/source independent; it is a candidate finite
normalization, not a changed physical coupling or adopted frozen fermion.

For local rho, use chi=(1+rho)Lambda in the complete quadratic amplitude.
Its logarithm is a nonlocal finite kernel; only its pole/contact subtraction
is local. Never replace the whole finite kernel by a local counterterm.
One/two rho derivatives require their explicit contact/factorial conventions.

The exact finite expression supplies a nonempty selected renormalized ghost
subsector prescription. It does not solve the scalar/reference-mass IR limit,
all g!=0 Slavnov restoration, all insertion mixing, or quantum canonical
equivalence. No coupling-ring restrictions or new canonical pairs are added.
