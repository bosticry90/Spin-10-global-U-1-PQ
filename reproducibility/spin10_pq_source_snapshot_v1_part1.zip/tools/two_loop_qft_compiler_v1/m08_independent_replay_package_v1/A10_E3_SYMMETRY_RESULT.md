# A10 E3 inactive quantum/background consistency result

Scientific disposition: **PASS_BOUNDED_INACTIVE_E3_QUANTUM_BACKGROUND_CONSISTENCY**. The complete inactive E2 gauge/scalar system satisfies the correct local background Ward identity, the geometric quantum identity with its expected light gauge-fixing breaking, and the transported quantum/source identities. The primary, physical-matrix replay and adversarial route agree within the declared scope. Final evidence validation requires the completed read-only receipt and byte bindings. No later gate or source activation is promoted. Here “quantum” identifies the fluctuating field symmetry; no quantum loop calculation is performed.

The authorization is the user assessment of `c2c56ed`. The governing contract is `A10_E3_SYMMETRY_CONTRACT_V1.md`. Recovery began with a clean working tree at `c2c56edae8bbc8b407e8a5712ef0452ea5396247`, without surviving scientific calculations. The eleven sealed predecessor chains supply the complete Stage D/E1/E2 system. Their physical terms, source terms, parameters, 508 physical Euler programs and historical negative controls are retained unchanged.

## Typed residual symmetry and canonical sources

H is the actual 12-generator residual algebra. The total lower-Lorentz connection is B=Abar_H+q. All 48 background components remain external, with Q Abar=0 and no invented BV partners. The complete 643-pair alphabet contains 1,286 field/source generators. Local even parameters omega and beta have independent ordinary symmetric jets.

Geometric quantum Tq holds Abar fixed; background Tb varies it affinely. Both have the same canonical field columns:

    T B=partial omega+g10[B,omega], T x=-g10 rho(omega)x,
    Tq Abar=0, Tb Abar=partial omega+g10[Abar,omega].

Thus Tq q has the affine total-connection variation while Tb q is homogeneous. Ghosts and light nonminimal fields use primal H frames; the heavy nonminimal fields retain their dual-heavy frame. The fixed vacuum is H stabilized. No 45-generator background extension is made.

For Tz=a(omega,jets)+M(omega)z, canonical sources use the evaluation-cotangent action TJ=-M^T J. This is distinct from an invariant Gram bilinear between two representation fields. The primary derives all canonical columns from the odd generator

    H_T=-sum_z(-1)^p_z Jz Tz,
    Tz=-(-1)^p_z Euler_left,Jz(H_T), TJz=(-1)^p_z Euler_left,z(H_T).

The replay reconstructs 540 H commutators of normalized physical 10-by-10 matrices, pulls them into the primal/dual frames and independently takes the evaluation-cotangent transpose. Scalar H matrices are materialized from authenticated physical representations. This does not repeat the old expensive all-generator representation qualifications.

## Transported and geometric quantum operators

Use the qualified E2 negative flow U, whose source shift is A_Jz=-(-1)^p_z Euler_left,z(Psi). Transport the entire field/source operator:

    Tq'=U Tq U^-1, Tb'=U Tb U^-1,
    D_Jz=-M^T A_Jz-T A_Jz=(-1)^p_z Euler_left,z(T Psi).

The Euler route includes derivative kernels and the full external-background variation. Tb Psi=0 implies Tb'=Tb. The quantum fermion variation W_Psi=Tq Psi is the expected light gauge-fixing breaking. It is not a failed heavy partial-gauge requirement.

Both routes agree on 4,002 complete operator columns with 55,852 nonzero coefficients, covering three operators on all 1,286 canonical and 48 external generators. All 643 quantum correction slots are retained: 56 are nonzero, with 3,032 coefficients; 587 are zero. All 643 background source corrections are zero. The 1,760 coefficients of W_Psi retain local parameter jets. The transported odd generator separately yields all 1,286 canonical columns. No action term or physical coupling is added.

## Complete action Ward identities

The E2 density remains S'=S0+S1+Delta, with Delta=Q Psi+div L. Fresh variation of the complete source-plus-gauge-fixing polynomial establishes

    Tb S'=0,
    Tq S'=Q' W_Psi+div(Tq L),
    Tq' S'=div(Tq L+Theta_W),
    Theta_W^mu=sum_z Rz partial_left W_Psi/partial(z_mu).

The independent routes compare the action variations and currents before using functional boundary equivalence. In both calculations, Tq L, Theta_W, the transported quantum Ward density and its current all vanish identically. The geometric quantum breaking has 22,520 coefficients and a nonzero b0 Euler derivative. The physical S0 Ward identity is supplied by its authenticated all-45 local qualification restricted to H; S0 has no external Abar dependence. The old S1 source Ward is freshly checked. Neither equations of motion nor source restrictions are used.

The simplest selected light channel is

    Tq S' |_(b0,omega0)=-2 b0 Box omega0,
    Euler_b0(Tq S') |_(omega0)=-2 Box omega0,
    [Q',Tq]Jb0 |_(omega0)=+2 Box omega0,
    (Tq'-Tq)Jbar0 |_(omega0)=-2 Box omega0.

The coefficient 2 is the exact existing G_H,00. This is expected quantum gauge-fixing breaking, with a nonzero Euler derivative, not a new defect in the physical action. A constant-parameter projection hides this selected diagnostic. The transported operator restores its retained-source BV identity by its derived source correction; it is not the geometric quantum operator with an unsupported claim of invariance.

## BRST compatibility and local algebra

The required complete relations are

    [Q',Tb]=0, [Q',Tq']=0,
    [Q',Tq]=-X_(Tq S').

The geometric quantum commutator is zero on fields and equals -Euler_left,z(Tq S') on canonical sources. Both routes agree on all 4,002 polynomial/external commutator slots; the nonzero geometric source defect contains 66,368 coefficients. An additional 1,286 pretransport polynomial commutator checks establish the old Q/H compatibility.

The 508 physical Euler slots are not freshly exhaustively expanded. Their covariance follows by differentiating the authenticated physical functional Ward identity under the affine field map, whose field Jacobian has no field jets:

    T E_I+sum_J M^J_I E_J=0.

The field-independent inhomogeneous parameter derivative contributes no field Jacobian. Evaluation-cotangent sources cancel these physical terms in the commutator. U fixes the physical programs because they are source free. Their exact program digest and previous scalar/free-Lorentz adapter qualifications are bound dependencies. The technical packet supplies the variational argument, and a separate direct physical replay challenges it. This is a structural physical proof plus fresh complete source-polynomial checks, not a new brute-force expansion of every full source square.

The local quantum, background and mixed Lie brackets are checked on all 1,334 canonical/external generators, using independent beta and omega and bracket parameter g10[beta,omega]_H: 4,002 checks. Their jets remain present. Ordinary symmetric prolongation covers admitted derivative coordinates; resource caps raise. The composite R_H=-[u,u]_H/2 remains a ghost polynomial and passes all 12 H covariance identities. The actual nonsymmetric coset is retained. This neither adds an independent curvature source nor qualifies E4 quartic/equivariant interpretation or an E5 domain.

## Replay, negative controls and execution record

Exact primary/replay comparison passes for operators, source corrections, breaking densities, currents, BRST defects, Lie identities and physical-program bindings. The primary prefix action and replay jet-gradient variation use different derivations but share immutable inputs, exact word arithmetic, Python/SymPy and analyst.

The smaller exterior replay uses a closed three-plane algebra, one residual H generator, five scalars, 20 canonical pairs and two external backgrounds. It differentiates the full gauge/scalar physical action and all 40 source columns directly. Its 126 BRST commutators and 84 first-jet commutators vanish. Background and transported quantum action identities pass; incorrectly freezing the background produces a nonzero Ward/Euler witness. Its smaller coset is not a substitute for the actual nonsymmetric 12-H system. It changes polynomial storage and variational arithmetic but shares assumptions and software.

The adversarial route additionally verifies all 4,002 operator real-structure columns, 2,668 inverse-transport columns, 624 first/second-jet prolongation controls and 40 reference-arithmetic windows of at most 64 monomials. These arithmetic windows are supplemental; they are not the full-size coefficient comparison or an enumeration of source squares. Wrong source transpose, omitted source transport and omitted background variation produce the required nonzero witnesses. Invented 45-H backgrounds, changed source coefficients and thirteen false promotion/endorsement flags are rejected.

An initial unqualified per-term prefix execution was stopped for performance before it produced a complete result object. Its final drained stdout had reached the local quantum Lie stage. `frozen_a10_e3_symmetry/unfinished_reference_execution.json` preserves its operational record and explicitly excludes it from scientific pass evidence. Only the completed collected-prefix calculation, independent replay and validation contribute to the result. No predecessor calculation was terminated or repeated as an expensive qualification, and no unrelated process was stopped.

## Published comparisons and scientific limits

The separation of quantum transformations with a fixed background from affine background transformations, including their gauge-fixing Ward requirements, is compared with [Thomsen, Sections 2.3 and 3.3](https://arxiv.org/html/2404.11640v2). The publication supports the framework, not this implementation or a quantum effective-action calculation here. The heavy partial-gauge fermion and later equivariant/quartic obligations are compared with [Ferrari, Sections 3 and 4](https://arxiv.org/html/1308.6802v3). Those later obligations remain E4/E5 decisions.

The qualified E2 master functional and structural nilpotence remain bound to the same retained-source/auxiliary system and declared local-functional boundary conditions. Classical field-antifield transport follows the framework of [Gomis, Paris and Samuel](https://arxiv.org/abs/hep-th/9412228). Neither setting sources to zero nor integrating out auxiliaries is done. This work proves no quantum master equation, absence of anomalies, physical gauge independence, experimental prediction or force match. The approved action remains gauge/scalar only, without fermion/Yukawa sectors.

## Validation and next decision

Final validation is a bounded read-only transaction requiring eleven authenticated predecessor chains, three fresh byte-identical routes and 182 passing targeted regressions: 20 new and 162 inherited, comprising 161 scientific and 21 governance tests. The independent primary/replay regenerations may run in parallel; controls follow both fresh byte comparisons. `frozen_a10_e3_symmetry/validation_receipt.json` supplies the completed transaction's measured test counts, timings, resources, input hashes, custody result and inventory. A failed or unfinished transaction exports no passing receipt. No scientific result or code edits follow successful validation.

The workspace/active-data inventory checks size and modification-time metadata; separate manifests bind bounded bytes and authenticate historical actions, catalogs, authority and custody. It is not an unrestricted all-byte workspace audit. The older expensive representation/source qualifications are authenticated and reused; their input matrices and programs are materialized only as needed for the new E3 identities. The completed fresh route outputs must regenerate identically, with no workspace writes or audit-time mutations.

Formal authority remains **34/39**. Strict historical custody remains **exit 2, seven unresolved references**, not PASS. Historical A4-V2/A5-V2 equivalence is unproved. The solo review policy applies, without outreach or external endorsement.

The next decision is a separately scoped **E4 composite/nonminimal/quartic interaction reconciliation**. E5 must separately establish a useful H-basic counterterm domain. E4/E5 have not been executed here. Full Stage E, source activation, HB1/C5, catalog replacement and finite C1_GS remain withheld. No remote push occurs.
