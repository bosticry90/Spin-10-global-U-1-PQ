# Minimal polynomial source-family and zero-coupling derivation plan

These are claims to verify under the contract, not a recorded PASS. Sources
remain external evaluation covectors; all fields/nonminimal partners remain.
Use x for the total 328 real scalar coordinates, B for the total connection,
and g for the existing physical gauge coupling.

## 1. Typed source bounds and the actual real generator

In the minimal chart physical fields have (d,gh)=(1,0), ghosts (1,1),
their physical sources (2,-1) and ghost sources (2,-2). At density dimension
four with nonnegative parameter dimensions, two minimal source factors require
at least two dimension-one ghosts and thus dimension at least six. Ordinary
counterterms at zero probe sources are at most source linear. This argument
does not cover arbitrary insertions/contacts with their own source dimensions.
Dimension-three canonical generators are also source linear in this chart.

Choose the actual heavy H-singlet direction, label 12, from the qualified
physical field frame. Convert it to a real normalized parent generator using
only constant frame coefficients. Verify its real structure, heavy projector,
nonzero norm and all 12 H commutators. Let R_s be its scalar representations;
all R_s^T=-R_s and [rho_h,R_s]=0. S is a singlet. The generator is a mathematical
test direction, not a new interaction coefficient or physical parameter.

## 2. Complete first variation and source class

Define K=sum_s J_s^T R_s x_s and A_s,a=[rho_s,a,R_s]. With source-left signs
and canonical words ordered C before J, the prospective class is

    F_R,source=sum_s,a,i,j C^a J_s,i A_s,a,ij x_s,j,
    F_R,physical=sum_s,mu eta_mu (D_mu x_s)^T A_s(B_mu) x_s,
    Theta_R^mu=sum_s (D^mu x_s)^T R_s x_s.

Because the potential is Spin(10) invariant and the kinetic coefficient is
the qualified one half, direct rigid scalar variation gives

    delta_R L0=g F_R,physical,
    E_x^T R x=g F_R,physical-partial_mu Theta_R^mu,
    g F_R=QK+partial_mu Theta_R^mu.

The source formula must independently agree with the actual minimal source
columns. Compare every source coefficient, all first-derivative kinetic
coefficients and the symmetrized B_a B_b x_i x_j seagull coefficients across
all four sectors. Zero coefficients count. Gauge kinetic variation is zero
because B is held fixed; all 29 potential contractions are unchanged and their
existing invariance certificates are explicit dependencies.

Covariance gives Q(Dx)=-g rho(C)Dx. Then

    Q Theta_R^mu=g sum_s (D^mu x_s)^T [rho_s(C),R_s] x_s,
    QF_R=partial_mu m_R^mu,
    m_R^mu=sum_s (D^mu x_s)^T [rho_s(C),R_s] x_s.

No inverse g is adopted: verify the polynomial identities after multiplication
by g, then use that multiplication by the independent central parameter g is
injective on the underlying coefficient/Grassmann polynomial module. Its
cohomology may nevertheless have g torsion. R commuting with actual H makes
K, F_R and the currents H covariant/invariant with the required local parameter
jets; iota kills F_R because its H-ghost coefficients vanish. Transport through
N/U is the qualified cochain map, not a naive mean-field quantum substitution.

## 3. Stationary specialization and a source-free-representative test

At g=0, with a separate formal zero-potential-parameter specialization, set
all derivatives/gauge fields/backgrounds to zero. Set nonminimal fields and
their sources to zero. Keep an admissible constant real scalar component,
one real heavy ghost vector and one scalar evaluation source with independent
odd generators. Prove that every Q-image, physical Euler contribution and
ordinary divergence projects to zero. Choose only after input-domain checks
a nonzero exact matrix coefficient of F_R,source.

If its source Euler derivative remains nonzero, no polynomial local primitive
or source-free representative can remove that class under the stated ordinary
boundary convention. The identity in section 2 would make its g-weighted class
exact with a BASIC K. This does not show a missing actual quantum class or
equate the general intrinsic/induced quotients.

## 4. Local second-order test, separate from Gamma

Power counting makes scalar Q variations affine-linear in x and C and ghost
Q variations bilinear in C; no source-dependent scalar variation has the
required (2,1,odd) grade without inverse dimensional parameters. At g=0 the
original scalar/ghost variations vanish. A local deformation with the fixed
matter columns A_s,a at first order therefore requires

    [A_s,a,A_s,b]=sum_c f'_ab^c A_s,c

at second order, even allowing an arbitrary first-order ghost algebra f'.
Terms in the second-order scalar/ghost variations cannot repair it since the
original operations on those fields vanish. Affine scalar terms do not change
the matrix condition. This is a statement about a LOCAL power-counted BV action.

Trace with the real scalar R gives tr(R A_c)=0 for every c. Choose a real
heavy a with A_a nonzero and b=[R_parent,a_parent]. On a faithful scalar block,
A_b=[R,A_a]. Cyclic trace then gives

    -tr(R[A_a,A_b])=-tr(A_b^2),

which is positive when A_b is a nonzero real skew matrix. Verify the exact
value and the input subspaces independently. A nonzero value obstructs that
specified matter-source deformation regardless of f'. It does not reject
the original master action and is not automatically a result about nonlocal
Gamma or every combination of first-order deformations.

## 5. Literal g=0 action and a conditional quantum normalization

Keep all potential couplings here. The expected decomposition is an interacting
328-scalar action plus a retained Gaussian of 180 gauge, 45 ghost and 90
nonminimal fields. Lower the literal physical/source/E2 gauge-fixing action to
check this, including complete internal Gram matrices, all source drivers,
the 48 external backgrounds and explicit ordinary boundary currents.

In the fixed Stage D/E2 chart, prospective absent sources are the 328 scalar,
45 ghost and 45 auxiliary sources. The remaining 180 gauge and 45 antighost
sources are affine Gaussian drivers. Verify counts, never assume them.
External backgrounds may be affine forcing terms but must not acquire sources.

For one physical gauge/auxiliary direction at generic non-null momentum,
with covariant gauge coordinates B_mu and p^mu=eta_mu p_mu, the proposed
Gaussian kernel is

    M=[[ -p^2 eta^(mu,nu)+p^mu p^nu, +i p^mu ],
       [ -i p^nu,                         width ]].

Derive and check both inverse directions, the p->-p transpose/reality condition,
all four Lorentz components and the physical frame transports. Ghost pairing
and boundary signs come from the literal odd action. Momentum inverses are
Green-function objects, not local cochain coefficients; p^2=0/IR and the full
massive propagator problem remain open.

For a source-independent formal measure/regulator with the corresponding
zero-theory-preserving source normalization, the unaltered g=0 integrand's
absence of a source implies the corresponding W/Gamma source derivative is
zero before and after the graded Legendre transform. This suggests a conditional
restriction on ordinary local source counterterms regular in g. It is not
automatically imposed on all W1-W7 finite normalizations, insertions or A5
equivalences. An actual restored quantum prescription and compatibility with
all insertion/contact operators remain unproved. A closed classical F_R must
not be relabeled an actual allowed quantum correction without that evidence.
