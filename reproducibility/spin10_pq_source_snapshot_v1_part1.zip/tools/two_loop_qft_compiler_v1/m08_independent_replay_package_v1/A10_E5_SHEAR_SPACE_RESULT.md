# Complete H shear space and conditional quartet membership

Scientific disposition:
`QUALIFIED_CONDITIONAL_COMPLETE_H_SHEAR_IMAGE_MEMBERSHIP_ONLY`.
The validation receipt and byte seal own bounded evidence qualification.
Baseline e053cc1, state v113, 34/39, with 33 authenticated predecessor chains.
The full Spin(10) x global U(1)PQ investigation remains active/incomplete.

The complete 5,528-slot actual-minus-frozen-candidate quartet residual lies
in the independently constructed classical auxiliary-shear image. Its exact
affine solution has 39 free directions. This changes the next research action:
the source-dependent type can carry the residual, but its mandatory companions
must be compared with actual amplitudes. No subtraction or normalization is
adopted, and the failed K0 + Kjoint + K3 candidate remains failed.

## Full space, independent of the residual

The generator family is

    K(T) = sqrt(2) g^2 xi sum_(i,j,k) Jaux_i T_ijk a_j C_k.

All 45 auxiliary sources, 45 antighosts and 45 ghosts are retained, including
both nonminimal sectors: 91,125 raw tensor slots. The common sqrt(2) normalizes
the basis; it is not an adjusted physical coupling. Source/field carriers use
the qualified evaluation-dual/primal maps. The coefficients satisfy the full
local H covariance equations and qualified real structure.

The four Cartan generators leave 1,205 potentially nonzero slots. All twelve
generators impose 4,416 nonzero covariance rows within the full 1,093,500-row
output domain; the omitted rows are exact zeros, not a restricted codomain.
Exact elimination gives complex dimension 125. Conjugation realification and
independent rank checks give a complete 125-dimensional real basis.

Primary extracts the E3 field/source matrices and uses exact DomainMatrix
RREF. Replay independently constructs normalized physical10 commutators,
transports their primal/dual actions and performs ordered sparse elimination.
Their canonical kernels, real bases and every complete Q image agree.

Replay also computes the invariant multiplicity by a distinct character
calculation. The eight roots generate a Weyl group of order 12. The full
rank-four torus, including its center, is retained. The constant term of the
three-character product times the all-root Weyl denominator, divided by 12,
is 125. The method uses Weyl integration and character orthogonality as stated
in [Peter Woit's character-formula notes, sections 1-2](https://www.math.columbia.edu/~woit/LieGroups-2012/weylcharacter.pdf).
The numerical multiplicity is calculated from this repository's representation;
the notes do not verify its coefficients. This is invariance under the local
Lie algebra/connected compact action, not a resolution of global H/PQ quotients.

H and M below label light and heavy auxiliary-source, antighost and ghost
indices, in that order:

| Sector | Real invariant dimension |
| --- | ---: |
| HHH | 10 |
| HHM | 3 |
| HMH | 3 |
| HMM | 19 |
| MHH | 3 |
| MHM | 19 |
| MMH | 19 |
| MMM | 49 |
| Total | 125 |

Restricting to two heavy nonminimal indices would lose 57 directions.
Omitting ghost-H indices would lose 35. A Cartan-only tensor violates a
nonzero root equation. These are discriminating completeness controls. No
projected heavy Jacobi identity or symmetric-coset assumption is used.

## Complete images and mandatory companions

Every real basis generator has its complete classical Q image, exact field
and evaluation-source columns, physical quartet map and typed coefficient
inventory. Across the 125 images there are 93,352 coefficient records;
overlaps are not independent evidence counts. The earlier dimension-one
OrbitPullback coefficient is reconstructed precisely from the E1 orbit term,
including all scalar companions. No arbitrary grading exception is allowed.

Primary graded prefix Q application agrees with replay left differentiation
and direct first variation of the complete source/gauge-fixing density.
The physical action is fixed because all its B/x fields are fixed by the map.
No changed variable has a jet in that density, so the boundary current is zero.
Light companions include the retained eta_H width and external H background;
all source, gauge, scalar, auxiliary and higher-coupling terms remain.

For each generator and every linear combination, the integrated fields shift
only the auxiliaries by a quadratic polynomial in fixed antighosts/ghosts.
The paired sources shift by the same generator's left gradients. All 1,286
canonical slots, elementary bracket coefficients, both exact inverse directions
and nonlinear ordinary jets are checked. The common fixed subalgebra
a,C,Jaux is mutually canonical-commuting, so mixed quadratic terms and
X_beta Y_gamma vanish for simultaneous combinations. The field Berezinian is
exactly one. The earlier joint regulated measure term remains; composite
expectations, source/contact insertions and quantum A5 remain unproved.

The quartet map has rank 86 and kernel dimension 39. Every basis image defines
all 980,100 physical odd-pair slots, including light/mixed zeros. In contrast,
the source, derivative-gauge and auxiliary-cubic companion maps are injective
on the full tensor family. The leading source coefficient is -identity, and
the literal four-Lorentz derivative and independent xi/eta width blocks are
nonsingular. Thus a quartet-null direction still predicts nonzero companions;
it cannot be discarded as an invisible or automatically permissible scheme.
The proof uses formal polynomial parameters without inverse widths in K.

All previously measured source, ghost kinetic, mixing, width and cubic
projections retain their original coupling-degree matches. This is not
agreement of any newly predicted companion with its actual amplitude.

## Complete residual membership and its ceiling

Only after both full spaces and images completed and agreed did the dependent
worker open the actual quartet. It checked the two qualified actual methods,
reconstructed actual minus the frozen prediction, and checked exact physical/
canonical transport in both directions. The old real 32/25 nonboundary witness
and full 5,528-slot residual remain intact.

Exact full-image membership succeeds, including all zero channels. A Gaussian
representative with free parameters set to zero has 15 nonzero real rational
coefficients in the already fixed basis and a complete 11,780-coefficient Q
image. The evidence preserves those coefficients, all 39 kernel directions,
their complete Q images and every required companion equation. The free-zero
representative is a mathematical convention, not a chosen subtraction or an
accepted field redefinition. No physical parameter or tensor basis was changed
after observing the residual. The known actual loops were not rerun.

The old source-free obstruction is unchanged. The new classical family can
carry the residual, while quantum canonical realization and the remaining
amplitude identities are still open. The earlier normalization is not promoted
to a quantum success by adding this algebraic solution.

The next smallest scientific action is to freeze the actual nonminimal-source,
derivative-gauge and auxiliary-cubic companion calculation with the complete
affine coefficient solution held fixed. It must retain both sectors, all
coupling/width-dependent graph contributions and graded blocks, and use
distinct actual methods. Their injective maps constrain the 39 remaining
directions. No JC-C-C/JB-B-C or other new loop was executed under this contract.
Keep nonlinear Ward, measure/insertion/contact and A5 obligations separate.

The receipt owns executed scientific/process/governance tests, two fresh
own-byte full-space derivations followed by fresh dependent membership,
33 parent chains, protected/new/state SHA and size/mtime audit. Failure evidence
and the wrong-carrier H witness remain protected. Shared inputs, graded/exact
arithmetic, Python 3.10.11, SymPy 1.14 and analyst remain disclosed under solo
review; no external-scientist endorsement or proof-kernel certification.

No activation, source/auxiliary elimination, physical/catalog/HB1/C5/C1_GS,
matching, authority promotion, outside contact, publication or push. Custody
remains exit 2 with seven unresolved references, never PASS. Full E5/A5/Ward/IR/
anomaly, global scalar boundedness/PQ quotient, fermion/Yukawa and phenomenology
remain open. State v113/34 of 39 and the whole active goal remain unchanged.
