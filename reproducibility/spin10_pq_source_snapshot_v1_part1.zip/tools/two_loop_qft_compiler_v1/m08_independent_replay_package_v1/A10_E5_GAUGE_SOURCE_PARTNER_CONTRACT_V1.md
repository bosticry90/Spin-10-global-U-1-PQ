# Actual leading gauge-source partners, GP V1

Freeze before computation at9fdab81590dca1249389c9d19f31157a83671e05.
Previous goal turn PROGRESS: corrected13-sector full local Ward coefficients
and six open target signatures qualified. Current goal remains the complete
Spin(10)xglobalU(1)PQ investigation, not this bounded increment. project_state
v113/34of39 remains sole scientific authority; no promotion/adoption.

GP1: independently calculate the actual one-loop dimension-zero, no-jet
g10^2*xi poles J_B B C and J_B A_H C, common hbar/(32pi^2epsilon_UV) units.
J_B is ODD, dimension2/gh-1; B/A even dimension1/gh0; C odd dimension1/gh1.
Full density is (4,0,even). Retain all45source,45B,45ghost,12backgroundH
directions and every source/vector Lorentz pair:16*45^3=1,458,000 B slots,
16*45*12*45=388,800 A_H slots, total1,846,800. No antisymmetry between source
and ghost direction indices. Proven zeros remain in the complete domain.

Immutable dependencies:45 sealed chains, literal complete E2 GF and BV source
action, executable physical gauge action F=dB+g f BB, physical10 parent
commutators, full real primal/dual charts,643pairs/48external backgrounds,
leading principal reference inverse. Sources/backgrounds have no inverse or
Legendre transform. Actual routes cannot interpret Ward-target, candidate,
prior measured-source pole, completion tensor or peer results as loop inputs.
Ancestor byte authentication happens first and is not scientific execution.

First construct the complete literal coupling/field/jet inventory, including
A_H and all source vertices. Proper three-external-leg one-loop valence gives
n3+2n4=3, with at least two integrated incidences at every vertex. The expected
proper source cubic is g J_B B C. Its g0 linear derivative source has one
integrated incidence/Hessian0; assignments placing B or C on the source
cubic as another external leg are 1PR, not the target. No source inverse.

At g^2xi the eligible source/xi/g triangles include ALL SIX Born words for:
(1) full derivative ghost cubic with external B or A_H, both internal-odd
derivative placements and the retained external-gauge derivative/current;
(2) GF auxiliary L-B-B or L-A_H-B cubic, with two mixed inverse edges;
(3) physical Yang-Mills cubic with external B, mixed plus FULL BB inverse.
Do not omit the auxiliary cubic. Physical S0 has no A_H dependence, but prove
all actual GF A_H channels/zeros from its inventory. The source+gxi quartet
bubble cannot obtain an external gauge leg from the pure four-ghost vertex
without a one-quantum source bridge. Ordinary g^2 quartics give g^3 with the
source; curvature g^2xi quartics likewise lie outside g^2. Source quartics or
additional eligible classes discovered in the inventory require inclusion or
an explicit STOP before computation, never omission to match a prediction.

Retain scalar/fermion and positive-dimensional mass/Orbit alternatives in
the exclusion proof: their leading mixed reference edges/quantum incidences
must vanish, or their positive-dimensional insertion lowers this selected
dimension-zero UV degree. Reference widths are formal independent real H/M
polynomials before binding width_M=xi,width_H=eta_H; no width-power cutoff.
The selected vertex factor xi is not a license to omit higher width powers.

Primary: own literal source/GF/physical gauge vertices and graded Fourier
Hessians/Born expansion. Replay: independently reconstructed physical10
source/GF/YM tensors, own literal crosschecks before loops, routed Gaussian/
Wick pairings. Exact elementary full4-vector controls cover EVERY16 external
Lorentz pair for every family/derivative placement, both odd orientations,
both mixed directions and BB transverse contribution. Independent Gaussian
and sphere moments establish the UV logarithmic residues. The Yang-Mills
even inverse may be contracted structurally BEFORE its color trace only with
an exact all-Lorentz pipe identity, explicit orientation coefficients and
proof that the selected source/auxiliary endpoints exhaust the Born words.
This is not reuse of the pureg^3 quartet longitudinal-collapse assumption.

Complete source1/gauge1/ghost1 homogeneous projection is allowed; discarded
degrees cannot return under multiplication. No resource truncation or inferred
color zeros. Lorentz diagonal reduction is allowed ONLY after all16 exact
unit kernels/residues prove it for independently factorized color vertices.
Keep every color coefficient within the selected space. Exact natural root/I
arithmetic, no floating tolerances. Preserve all source/GF current identities,
full source parity, real charts/roundtrips and all12 constantH tensor identities.

UV scope: k_E^2>R_UV^2>0 above external/mass scales, leading degree-4,
triangle heat profile6, common Minkowski radial multiplier2I in32pi^2 units.
Momentum/mass remainders are outside this no-jet logarithmic coefficient.
No whole-scaleless, finite/IR, mass-log/cutoff-power, anomaly or complete
measure/restoration inference. All excluded scopes stay explicit.

GP2 AFTER complete actual methods/families/zero channels agree: append actual
B/A_H poles to the corrected measured residue and calculate the complete
leading g^2xi J_B-C/local-parameter derivative Ward subsystem. Independent
prefix/jet-gradient methods, all12 parameters, all388,800 raw source/ghost/
parameter-jet/Lorentz slots, full currents and parameter Eulers. Keep both
connection alternatives and establish actual zeros from graphs, not the Ward
target. Compare raw and anchored left side without EOM. Also verify that the
new no-jet densities have only this affine local Ward variation (their full
constantH action is zero), so unchanged remaining Ward targets stay explicit.
Do not fit any coefficients to obtain zero. If nonzero, preserve the real
signed Euler witness and stop before candidate/image changes or another loop.

Unknown Gamma,Delta_b/s, operator insertions/contact normalization, measure,
IR and wider scopes remain unbound even if the selected measured left side
vanishes. A_H zero is a qualified actual domain result, not silent absence.
Prior GS Slavnov qualification and g^3 candidate FAIL keep their scopes.
No canonical adoption or full E5/HB1/C5/C1_GS/physical matching/goal completion.

Negative controls: wrong source parity/primal pairing/coupling factor; omit
nonzero triangle/auxiliary/ghost assignment, mixed or reverse-odd inverse;
omit transverse BB; omit actual A_H vertices when nonzero or alter independently
proven zero channels; discard parameter jets/currents; set unknown partners
to zero. Each yields exact nonzero discrepancy or type rejection in its scope.
Preserve full failed/unfinished source/start/stdout/attempt classifications.

Validation: four own-byte fresh controls/primary/replay/comparison, meaningful
science/process/governance/delegatede5,45protected chains, new/protected/state/
metadata invariance, custodyexit2/sevenrefs neverPASS; old expensive loops/images
authenticate only. Raw Git index/worktree equality before localcommit. Noreset,
evidenceediting, unrelatedtermination, authoritypromotion, push/publication/
outreach. Shared action/representations/some arithmetic/PythonSymPy/analyst
disclosed; not independent scientists. Noagents. Scalar/globalPQ/fermionYukawa/
phenomenology and full quantum equivalence/restoration remain open.
