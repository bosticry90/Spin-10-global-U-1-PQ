"""Physical-plane bilinears, direct variations and independent cotangent pullback."""
from itertools import combinations
from a10_e1_fermion_common import *

def physical_structure(Q):
    planes=[];addresses=list(combinations(range(10),2))
    for i,j in addresses:
        T=s.zeros(10);T[i,j]=1/s.sqrt(2);T[j,i]=-1/s.sqrt(2);planes.append(T)
    fp={}
    for a,b in combinations(range(45),2):
        K=planes[a]*planes[b]-planes[b]*planes[a]
        for k,(i,j) in enumerate(addresses):
            value=clean(s.sqrt(2)*K[i,j])
            if value:fp[k,a,b]=value;fp[k,b,a]=-value
    Qi=Q.inv();f={}
    for (k,a,b),v in fp.items():
        for c in range(45):
            if Qi[c,k]:
                for h in range(45):
                    if Q[a,h]:
                        for j in range(45):
                            if Q[b,j]:f[c,h,j]=f.get((c,h,j),0)+Qi[c,k]*v*Q[a,h]*Q[b,j]
    return fp,{key:clean(v) for key,v in f.items() if clean(v)}

def direct_euler(P,w,names):
    """Independent jet-gradient buckets then integration by parts."""
    gradients={}
    for word,c in P.items():
        for pos,(name,jets) in enumerate(word):
            if name in names:
                sign=(-1)**(w.p[name]*sum(w.p[n] for n,_ in word[:pos]))
                bucket=gradients.setdefault((name,jets),{});rest=word[:pos]+word[pos+1:]
                bucket[rest]=bucket.get(rest,0)+sign*c
    result={n:{} for n in names}
    for (n,jets),P in gradients.items():result[n]=w.add(result[n],w.scale(w.dword(canonical(P),jets),(-1)**len(jets)))
    return {n:canonical(P) for n,P in result.items()}

def build(stage=lambda n,f:f()):
    evidence=read(HERE/'frozen_a10_physical_reconciliation/full_replay.json')
    Q=mat(evidence['C3_plane_to_parent']);chart=stage('physical_plane_chart_derivation',lambda:charts(Q))
    fp,f=stage('990_normalized_physical_matrix_commutators',lambda:physical_structure(Q))
    QH,QM=Q[:,:12],Q[:,12:];GH=(QH.T*QH).applyfunc(clean);GM=(QM.T*QM).applyfunc(clean)
    FM=(QM*GM.inv()).applyfunc(clean);PM=(QM*GM.inv()*QM.T).applyfunc(clean);PH=(QH*GH.inv()*QH.T).applyfunc(clean)
    O=mat(evidence['vacuum']['orbit']);v=mat(evidence['vacuum']['VEV'])
    assert (O*PH).applyfunc(clean)==s.zeros(328,45) and (O.T*v).applyfunc(clean)==s.zeros(45,1)
    # Ambient physical coordinates are redundant; project before constructing Psi.
    p=alphabet();physfields={f'{prefix}{i}':grade for prefix,grade in
      [('U',(1,-1,1)),('Lphys',(2,0,0)),('Cphys',(1,1,1)),('barphys',(1,-1,1)),('bphys',(2,0,0))] for i in IDS}
    physfields.update({f'q{i}_{mu}':(1,0,0) for i in IDS for mu in range(4)})
    physfields.update({n:(1,0,0) for n in scalar_names()})
    p.fields=physfields;p.grades=physfields;p.external={};p.p={n:gr[2] for n,gr in physfields.items()}
    for i in IDS:
        for mu in range(4):register(p,f'Aphys{i}_{mu}',(1,0,0))
    mv=lambda R,V:[p.add(*(p.scale(V[j],c) for (k,j),c in R.todok().items() if k==i)) for i in range(R.rows)]
    vec=lambda pre:[p.var(pre+str(i)) for i in IDS]
    dot=lambda X,Y:p.add(*(p.mul(a,b) for a,b in zip(X,Y)))
    comm=lambda X,Y:[p.add(*(p.scale(p.mul(X[a],Y[b]),c) for (k,a,b),c in fp.items() if k==i)) for i in IDS]
    U=mv(PM,vec('U'));L=mv(PM,vec('Lphys'));u=mv(PM,vec('Cphys'))
    bar=mv(PH,vec('barphys'));b=mv(PH,vec('bphys'))
    A=[];qH=[];V=[]
    for mu in range(4):
        A.append(mv(PH,[p.var(f'Aphys{i}_{mu}') for i in IDS]))
        q=[p.var(f'q{i}_{mu}') for i in IDS];qH.append(mv(PH,q));V.append(mv(PM,q))
    eta=[p.add(p.var(n),{():-v[i,0]} if v[i,0] else {}) for i,n in enumerate(scalar_names())]
    parts={
      'heavy_divergence':p.add(*(p.scale(dot(U,[p.D(z,mu) for z in V[mu]]),ETA[mu]) for mu in range(4))),
      'heavy_connection':p.add(*(p.scale(dot(U,comm([p.add(a,b) for a,b in zip(A[mu],qH[mu])],V[mu])),g*ETA[mu]) for mu in range(4))),
      'heavy_orbit':p.scale(dot(U,mv(O.T,eta)),-xi*g),
      'heavy_auxiliary':p.scale(dot(U,L),-xi/2),
      'heavy_cubic':p.scale(dot(U,comm(U,u)),xi/2),
      'light_divergence':p.add(*(p.scale(dot(bar,[p.D(z,mu) for z in qH[mu]]),ETA[mu]) for mu in range(4))),
      'light_connection':p.add(*(p.scale(dot(bar,comm(A[mu],qH[mu])),g*ETA[mu]) for mu in range(4))),
      'light_auxiliary':p.scale(dot(bar,b),-etaH/2)}
    full=p.add(*parts.values());physnames=list(physfields)+[f'Aphys{i}_{mu}' for i in IDS for mu in range(4)]
    pel=stage('ambient_physical_plane_left_variation_before_pullback',lambda:direct_euler(full,p,physnames))
    w=alphabet();sub={};maps={}
    def bind(pre,R,names):
        maps[pre]=(R,names)
        for i in range(45):sub[pre+str(i)]=w.add(*(w.scale(w.var(names[j]),c) for (k,j),c in R.todok().items() if k==i))
    bind('U',FM,[f'ub{i}' for i in M]);bind('Lphys',FM,[f'L{i}' for i in M])
    bind('Cphys',Q,[f'C{i}' for i in IDS]);bind('barphys',QH,[f'bar{i}' for i in H]);bind('bphys',QH,[f'b{i}' for i in H])
    for mu in range(4):
        for i in IDS:
            sub[f'Aphys{i}_{mu}']=w.add(*(w.scale(w.var(f'A{h}_{mu}'),Q[i,h]) for h in H if Q[i,h]))
            sub[f'q{i}_{mu}']=w.add(*(w.scale(w.var(f'B{a}_{mu}'),Q[i,a]) for a in IDS if Q[i,a]),w.scale(sub[f'Aphys{i}_{mu}'],-1))
    for n in scalar_names():sub[n]=w.var(n)
    # Replacement acts in the receiving alphabet, preserving symmetric jets.
    def pull(P):
        terms=[]
        for word,c in P.items():
            term={():c}
            for name,jets in word:term=w.mul(term,w.dword(sub[name],jets))
            terms.append(term)
        return canonical(w.add(*terms))
    pulled=stage('physical_density_pullback_all_terms',lambda:{n:pull(P) for n,P in parts.items()})
    names=list(w.fields)+[f'A{h}_{mu}' for h in H for mu in range(4)]
    def covectors():
        el={n:{} for n in names}
        for pre,(R,target) in maps.items():
            columns=[pull(pel[pre+str(i)]) for i in IDS]
            for (i,j),c in R.todok().items():el[target[j]]=w.add(el[target[j]],w.scale(columns[i],c))
        for mu in range(4):
            eq=[pull(pel[f'q{i}_{mu}']) for i in IDS];ea=[pull(pel[f'Aphys{i}_{mu}']) for i in IDS]
            for (i,a),c in Q.todok().items():el[f'B{a}_{mu}']=w.add(el[f'B{a}_{mu}'],w.scale(eq[i],c))
            for (i,h),c in QH.todok().items():el[f'A{h}_{mu}']=w.add(el[f'A{h}_{mu}'],w.scale(w.add(ea[i],w.scale(eq[i],-1)),c))
        for n in scalar_names():el[n]=pull(pel[n])
        return {n:canonical(P) for n,P in el.items()}
    el=stage('physical_cotangent_pullback_691_columns',covectors)
    PMpsi=w.add(*(P for n,P in pulled.items() if n.startswith('heavy')))
    PHpsi=w.add(*(P for n,P in pulled.items() if n.startswith('light')))
    variation=stage('independent_full_first_variation_boundary_check',lambda:first_variation(w.add(PMpsi,PHpsi),el,w,names,'replay'))
    # H-only scalar actions from independent physical representation certificates.
    rho={}
    for sec,n in DIM.items():
        planes=[mat(R) for R in evidence['representation_matrices'][sec]]
        rho[sec]=[(sum((Q[k,h]*planes[k] for k in IDS if Q[k,h]),s.zeros(n))).applyfunc(clean) for h in H]
    wards=ward(PMpsi,PHpsi,w,f,rho,stage,'replay')
    return finish('replay',chart,None,pulled,el,variation,wards,
      {'physical_commutators':990,'physical_nonzero_f':len(fp),'ambient_Euler_columns':len(physnames),
       'cotangent_pullback':'derivative in ambient physical plane, then E^T alpha; kernels retained',
       'old_representation_calculations_repeated':False,'nonsymmetric_cubic_nonzero':bool(pulled['heavy_cubic'])})
