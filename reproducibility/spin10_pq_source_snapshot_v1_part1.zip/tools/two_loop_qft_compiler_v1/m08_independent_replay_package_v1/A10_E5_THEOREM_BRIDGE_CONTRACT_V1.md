# E5 model/theorem and quantum Ward bridge contract

The assessment of e66d1d6 authorizes this bounded inactive investigation.
Baseline is clean e66d1d6a6091bf7947256ca2255a203cf692f5a3, state version 113,
34/39, 542 authenticated bindings in fifteen manifests and no surviving
matching calculation. Read-only recovery is not scientific acceptance.

Question Q6.1: does the actual repository specify and justify a quantum
counterterm target to which the proposed theorem can be applied? Freeze the
643 canonical pairs, 48 external H backgrounds, ordinary finite symmetric
jets, source-left antibracket, dimension-four/ghost-zero sector and existing
polynomial physical coefficient ring. No inverse physical couplings or
inverse-dimensional parameters. Arbitrary dimensionless normalization units
in the earlier family do not authorize inverses of physical couplings here.
The convention d_standard=d_project-gh is a grading map, not a theorem bridge.

Recover D/E1-E5 and the quotient records without repeating their expensive
qualified derivations. Preserve every original witness and byte binding.
Review published primary sources for the exact assumptions and conclusions.
Separate a conditional retained-source perturbative 1PI/Slavnov target from
its actual implementation, anomaly/measure proof and quantum Ward identities.
Neither classical Tq' invariance nor a classical master equation alone accepts
the corresponding quantum identities. Do not conflate Zinn-Justin identities
with a regularized BV quantum master equation or an antifield-zero projection.

Q6.1 controls must show why scope choices matter. Derive a full local H
background curvature density with the existing physical frame, metric and
coupling; independently check its background Ward identity. Q and Tq' fix
external backgrounds. Compare allowing versus removing background-only local
functionals. Establish the selected pure-background class is not merely an
ordinary divergence or a polynomial Q-exact term by an explicitly stated
stationary specialization in the pre-U chart. That specialization is a proof
test in the declared polynomial ring, not a change to physical parameters.
Construct a dimension-four background gauge-divergence density which is
Q-closed and Tq'-invariant but violates local Tb; retain parameter jets and a
nonzero Euler witness. Compare permitted canonical primitives versus no
primitives on the authenticated ghost-rescaling exact family, without claiming
that intrinsic and induced basic quotients coincide. Do not call a changed
domain a missing class in the original domain.

Primary uses frozen H structure constants and prefix jet variation. Replay
reconstructs physical matrix commutators and derives curvature variation and
Euler derivatives by a separate direct-gradient route. The perturbative
Slavnov expansion is derived both by symbolic expansion and ordered degree
convolution, including the nonlinear order-two term. Shared arithmetic,
inputs, Python/SymPy and analyst are disclosed; no outside endorsement.

Q6.2-Q6.6 are conditional on Q6.1 acceptance. If the quantum Ward/insertion
target is still unsupported, record the first underdefinition and do not
qualify regularity, Koszul-Tate completeness, theorem applicability,
surjectivity, intrinsic/induced equivalence or universal source removability.
A literature assumption map and a concrete next proof obligation may still
be prepared as analysis; they are not execution or acceptance of later gates.
No giant operator catalog compensates for an unsupported hypothesis.

One completed derivation per route, exact adversarial controls and fresh
byte-identical replay of the new bounded routes are the effort boundary.
Incomplete execution supplies no completed receipt. Valid outcomes include
qualified scope, partial result, exact obstruction or underdefinition. A
completed stopping result can pass evidence validation while Q6.1 fails to
qualify. Preserve full E5, M08/HB1/C5 and quantum matching as blocked. No
activation, catalog replacement, physical parameter change, authority change,
outreach, publication or remote push. Commit locally after bounded validation.
