# E5 regulated one-loop source-operator identity

## Scientific disposition

**QUALIFIED_E5_REGULATED_ONE_LOOP_SOURCE_OPERATOR_IDENTITY_ONLY**.
The complete 643-field tangent and its first jets agree independently. The
actual diagonal Jacobian carriers are real skew in their physical frames,
so their trace against the specified self-adjoint H-covariant heat profile
vanishes. Direct Born differentiation and regulated Gaussian insertion give
the same one-loop operator identity, with a necessary physical source
correction. An actual phi-sector witness retains the nonzero cutoff breaking.

This advances the nonzero-coupling consistency calculation. It does not prove
local restoration, anomaly freedom, all contacts/probes, quantum A5, physical
IR/continuum existence, full M2–M5/A1–A5 or E5. Full-size finite one-loop
source amplitudes were not independently integrated in this increment.

Baseline89deb04 was clean. No matching calculation worker survived recovery.
The 25 sealed chains authenticate; the expensive complete Hessian/reference
and all earlier physical/source proofs are reused, not repeated. The original
34 physical terms, nine source terms, E2 fermion correction, all643 pairs,
48 external H backgrounds, scalar vacuum, parameters, xi cubic and composite
R_H remain. Statev113/34of39 is unchanged. This introduces an inactive
regulator description and calculation tools, not a new physical action.

## Complete tangent and regulated measure

Primary derives each delta_h R_z by graded factor replacement. Replay uses
left jet gradients, independently reassembles their direction program and
compares it before converting to right derivatives. Both yield **70,935**
coefficients:70,755 zero-jet and180 first-jet terms. The latter are the actual
gauge-to-ghost derivative directions; all derivative directions and implicit
zeros are retained. The full canonical stream SHA256 is

`9ba057116aa636326bee5e19a444c104968f5fe379ad3528197274ec80970d22`.

For the even transformation delta_epsilon z=epsilon_left Qz, the odd tangent
matrix uses A_ij=right_j R_i=(-1)^(p_i p_j) left_j R_i. A universal ungraded
derivative would be wrong. No new canonical source or field is introduced.

The diagonal carrier matrices contain 34,544 raw coefficients. Both routes
transport them with the previously qualified full field-frame map and its
inverse. All45 generators, including zeros, are checked for reality and
skewness in each of the13 carriers:

| Physical carrier | Coordinates | Nonzero physical coefficients |
| --- | ---: | ---: |
| Gauge, each of four spacetime copies | 45 | 1,674 per copy |
| Phi | 54 | 1,760 |
| Sigma | 252 | 10,500 |
| phi | 20 | 300 |
| S | 2 | 0 |
| Ghost | 45 | 1,674 |
| Heavy antighost | 33 | 334 |
| Heavy auxiliary | 33 | 334 |
| Light antighost | 12 | 0 |
| Light auxiliary | 12 | 0 |

At coincident points, the kernel K_t(x,x) of a real self-adjoint H-covariant
heat operator is symmetric in these physical frames. For each real skew A_a,
Tr(K_t A_a)=0. Thus the specified heat-regulated Jacobian vanishes coefficient
by coefficient, rather than only after a formal unregulated sector sum.
Admitted boundary/smoothness conditions and the real compact-H structure are
assumptions of this heat-kernel statement. It is not a claim about every
regulator, finite-mode BRST closure, physical IR removal or anomaly freedom.

The bare canonical transpose fails in a selected nonorthonormal carrier.
A non-self-adjoint physical profile also gives a nonzero trace. Both controls
are retained. The kernel regulates the carrier measure; it is not obtained
by pretending the mixed gauge/auxiliary Hessian is a positive scalar Laplacian.

## The source correction that must survive

The qualified Born family can be written using a quadratic regulator V:

    DeltaK=F^-ST Kref F^-1-Kref,
    V=(1/2) z DeltaK z,
    S_Lambda=S+V,
    H_Lambda=H+DeltaK,
    B_Lambda=(S_Lambda,S_Lambda)/2=QV,
    Q_Lambda=Q+(V,.).

F is the existing H-covariant heat cutoff. Kref is the full retained643
reference; no auxiliary is integrated out. The inverse-series determinant is
the same previously defined interaction Born family. The reference/background
determinant, its contour/phase and normalization are retained separately.

Q and Q_Lambda have the same field transformations. Their source columns
differ by the physical Euler covector of V. This matters at one loop:

    Q_Lambda Gamma1 = insertion1(B_Lambda)-i div_heat R,
    Q Gamma1 = insertion1(B_Lambda)
                      -(V,Gamma1)-i div_heat R.

The regulator-breaking Hessian contains V_z R_z,jk. The complete source
Hessian contains J_z R_z,jk. Therefore the source derivative
(V,Gamma1) supplies exactly the term needed when returning to the original
operator Q. The 73,218-coefficient source Hessian is authenticated as the
explicit nonlinear dependency; its R_H/nonminimal terms are not suppressed.

Primary cyclic differentiation of each Born word and replay inverse-series
variation agree. Ten finite orders are checked. The all-order formal argument
is the n cyclic derivative positions cancelling1/n, giving the corresponding
geometric inverse-series coefficient. This is a structural word proof, not
ten samples standing in for an all-order integrated-amplitude result.

Gaussian reduction independently gives the same identity: H=H_Lambda-DeltaK
and G H_Lambda=H_Lambda G=1. Combine the common-profile free trace pieces
before any UV limit. No separate unregulated Tr1 or delta(0) is assigned a
value. Removing the nonlinear source correction leaves the nonzero word
(1/2)STr(G U), U=V_z R_z,jk.

The background identity remains a structural consequence of the inherited
Hessian/reference congruences, the H-covariant profile and retained background
determinant. Geometric quantum-H breaking remains distinct from background
preservation; no false invariance requirement is imposed on the light-fixed
action. The full E3 identities are preserved dependencies, not freshly
re-expanded loop calculations.

The quadratic V is written in the canonical total-connection coordinates.
Their background rule is affine: delta_b z=M_b z+a_b. Consequently a
covariant DeltaK does not by itself make V invariant; its bare variation is
z^ST DeltaK a_b, a linear regulator breaking. Its integrated-field Hessian
vanishes. The determinant Ward identity remains valid, while this tree
breaking must remain in the regulated identity and be subtracted with V
when forming the original-action target. No background-invariance claim for
S_Lambda itself is made. Centering V in q=B-Abar would be a separately typed
alternative; identical Hessians would not prove identical source/breaking
normalizations. That alternative is not silently adopted.

These distinctions are consistent with the retained-antifield and regulated
insertion treatment in [Troost and Van Proeyen, sections4–5](https://arxiv.org/html/hep-th/9307126).
Its Pauli–Villars partners are not adopted. The separate need for local joint
restoration and normalized insertions is discussed by
[Grassi, Hurth and Steinhauser](https://arxiv.org/html/hep-ph/0102005).
These papers support the methods, not verification of this implementation.

## Independently calculated source-operator control

The nonlinear five-field retained-source Gaussian is recomputed using the
two distinct inversions from the predecessor: finite nilpotent Neumann
expansion and graded Gaussian row elimination. All sources and auxiliaries
remain. The same off-shell x=1,y=2,b=0 control with V=r*x^2/2 gives

    Q_Lambda Gamma1 = [2r(75-2r)/(3(51r+1028))] c,
    Q Gamma1 = [274r/(3(51r+1028))] c,
    (V,Gamma1) = [-4r(r+31)/(3(51r+1028))] c.

The first is the breaking insertion. Original variation minus insertion plus
the source correction is exactly zero. Omitting the correction leaves
4r(r+31)c/[3(51r+1028)], which is generally nonzero. No equations of motion
are imposed. This qualifies the correction and graded signs in an actual
calculation. It is a control, not a full643-field quantum amplitude.

This clarifies the predecessor Gaussian scope: its equality used the
regulated source operator Q_Lambda. It cannot be reused as an equality for
the original Q without this additional term. The predecessor bytes and its
bounded conclusion are unchanged.

## Actual phi finite-cutoff breaking

Use the approved real phi representation, generator0, coordinates0 and2,
rho_02=1/sqrt(2). The primary projects the actual643-field transformation
through the qualified physical-to-C3 ghost map; replay derives it from the
physical matrix. Both recover R_X=-g C Y/sqrt(2), R_Y=+g C X/sqrt(2).

With p+q+r=0, the scalar regulator symbol is

    Rcut(p^2)=(exp(2p^2/Lambda^2)-1)(p^2+Mref^2).

The complete selected tree breaking is

    B_Lambda = g/sqrt(2)[Rcut(q^2)-Rcut(p^2)] C X Y.

The other regulator carriers have no two-phi monomial and cannot cancel it.
At p^2=1,q^2=4,Mref^2=1,Lambda^2=2 the coefficient is
g(5exp4-2exp1-3)/sqrt(2), exactly nonzero. Its ghost Euler coefficient is
nonzero, excluding an ordinary total derivative. Constant parameters miss
the witness. The tree breaking vanishes at g=0 or removed cutoff; neither
limit proves vanishing of a loop insertion.

The physical source correction is +Rcut x_phi. The finite-cutoff expression
is nonpolynomial in momenta; exact cancellation by a finite local polynomial
is not assumed. This is expected regulator breaking, not a new failure of the
qualified physical action or a fitted repair to it.

## Domain, unfinished obligations and validation

The word identity uses the declared unprojected formal Wick/nonexceptional
UV domain. Temporary IR spectral/mode projections produce additional
projection breakings and contact terms. Their preservation and physical
removal are NOT proved here. A self-adjoint heat Jacobian is not a proof of
an unrestricted continuum integration-variable change. A complete realized
quantum target still needs these IR/measure obligations and local restoration.

Two helper-call preflights failed before a replay identity could be evaluated.
Their exact source versions, failed logs and completed initial primary outputs
are preserved and excluded. The final routes bind the same corrected code
strictly; no original-fingerprint exception is used. One test compared an
unsimplified substituted zero expression to integer0; its original test and
failure are preserved, and exact simplification resolves it. Completed
scientific outputs were not edited.

The receipt records317 regressions:272 scientific (18 new,254 inherited),
24 process and21 governance. Two final routes freshly reproduce their own
bytes. Twenty-five parent chains, protected/state/new SHA256 bytes and
read-only size/mtime metadata are checked. The earlier expensive Hessian,
geometry and source assembly are authenticated rather than rerun. Metadata
checks are not an unrestricted environment byte audit. Strict historical
custody still exits2 with seven unresolved references, never PASS.

Primary/replay share immutable inputs, word arithmetic, Python3.10.11,
SymPy1.14, assumptions and analyst. No external endorsement is claimed or
outside person required. No source activation/removal, auxiliary elimination,
parameter change, catalog, HB1/C5, C1_GS, authority promotion, physical matching,
personal contact, publication or push occurred.

## Next smallest scientific action

Integrate the actual leading nonzero-coupling J_phi–C–phi one-loop vertex
and its Slavnov companion terms. Retain mixed gauge–auxiliary propagation
and the actual xi*Lambda*ub*u interaction; do not assume a conventional
ghost action or its leading coupling power. Compare the UV coefficient and
local restoration equations by independent routes, using this corrected
source operator. General contacts, IR, quantum A5 and full E5 remain open.
The larger Spin(10)xU(1)PQ goal, including fermion/Yukawa, global boundedness,
PQ quotient and phenomenological obligations, remains active and incomplete.
