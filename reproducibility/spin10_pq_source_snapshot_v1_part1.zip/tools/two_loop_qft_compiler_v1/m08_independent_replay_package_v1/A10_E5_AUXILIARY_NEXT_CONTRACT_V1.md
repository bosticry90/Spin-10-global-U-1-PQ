# E5 next-order actual auxiliary companion: prospective first-failure contract

Baseline 430b3586208bddf2d3c122b2dd9c52674f329aa5; state v113, 34/39,
35 sealed predecessor manifests. Sole scientific authority is project_state.json.
The source calculation fixed a unique inactive member; it did not accept a
subtraction or quantum A5. AN1 asks whether its next auxiliary-cubic prediction
matches the actual unchanged model. AN2 asks whether an exact real Euler
obstruction stops the proposed member. Derivative-gauge remains required but
is ordered after this gate and does not run after a mismatch.

## Frozen domain and order

Retain all 643 canonical pairs, 48 H backgrounds, sources and nonminimal
sectors, the original physical action, gauge fermion and both reference widths.
The selected density is L_aux a C: all 45 auxiliary, 45 antighost and 45 ghost
directions, 91,125 slots including exact zeros. Grades are (2,0,even),
(1,-1,odd), (1,1,odd), giving (4,0,even). Raw heavy auxiliary/antighosts are
evaluation dual; raw ghosts/gauges are primal. Light maps and inverse canonical
pairings must be checked. No delta contraction of two primal carriers.

This is the next prefix in a sequential full companion investigation, not a
claim that all coupling orders are complete. The previously qualified g xi^2
pole is authenticated. Here calculate the entire g^2 auxiliary-cubic UV pole:
the g,g,xi cubic triangles with arbitrary H/M reference widths and the
g^2 xi,xi curvature-quartet bubble. Keep width-independent, xiWidth and etaWidth
coefficients separate, then substitute xiWidth=xi, etaWidth=eta_H. Compare
all resulting formal monomials, including g^2 xi^2 and g^2 xi eta_H. Inventory
also lists all other coupling families without treating them as calculated;
first failure stops before g^3/higher amplitudes or derivative-gauge. No
post-residual change of this ordering, candidate, tensors or parameters.

## Inputs and independent ownership

Input frozen_a10_e5_nonminimal_source/bindings.json and its transitive bytes.
Freeze contract, execution code, input and state SHA before each execution.
Primary and replay outputs have exclusive ownership and no write access;
exporter writes exclusive attempt/output files. Actual methods do not open
the unique candidate, shear coefficients or comparison outputs. A dependent
comparison starts only after both completed actual outputs agree. No agents,
duplicate calculations, overwrites or evidence edits. Failed/unfinished
attempts retain exact source/start/stdout and explicit classification.

## Actual methods and completeness

Recover every literal cubic/quartic signature. For an auxiliary-cubic one-loop
1PI density, graphs have three cubics or one cubic and one quartic. An external
auxiliary arises from xi L a C or g L B_H B_M (the light b nonlinear vertex
contains an external A background). Include the full derivative-on-a/B/C
ghost inventory and retained IBP currents. In the g,g,xi class, retain both
the external-xi auxiliary and external-g auxiliary placements, both sectors,
all six labeled Born placements / three repeated-vertex shuffle words. The
g^2 xi quartic contains curvature ghosts; its xi bubble must not be discarded
using the earlier g xi quartet argument. Ordinary g^2 two-B/ghost quartics
with external xi auxiliary have disjoint odd/even internal edges and are zero
only after explicit edge screening. Scalar/orbit/mass alternatives have a
positive-dimensional insertion or missing leading reference edge: show why
they cannot contribute to this dimension-zero logarithmic coefficient.

Primary pulls literal E2 vertices to physical orthonormal coordinates, builds
signed graded Fourier Hessians and the full BB, BL/LB, LL=0, both odd inverses,
and contracts the supertrace Born expansion. Replay independently reconstructs
physical10 H/M commutator vertices and expands the even Gaussian inverse and
odd Schur determinant with independent ordered left derivatives. This shares
immutable data, Python/SymPy/exact arithmetic and analyst; it is not independent
scientific authorship or external review. Never assume M-adjoint Jacobi closure.

Qualify vertex reconstruction, arbitrary-width elementary contractions and
odd/even signs before full tensor contraction. For momentum-zero UV leading
symbols, an external derivative lowers UV degree and contributes zero only
to this logarithmic coefficient. Contract all four Lorentz directions before
using rotation to a time-axis momentum: mixed edges and internal derivatives
select longitudinal BB, but no transverse term may be discarded by assumption.
UV extraction is restricted to k_E^2>R_UV^2>0 above external/mass scales; retain
triangle/bubble heat profiles 6/4 and independently derive i/(16 pi^2 epsilon).
This is not a whole scaleless massless integral or complete finite/IR amplitude.

Both full actual polynomials must agree coefficientwise in formal widths,
be exact and real, obey all twelve H identities, and transport to raw canonical
coordinates and back. Controls must exhibit a nonzero exact residual when
curvature quartic, nonlinear auxiliary-gauge vertex, a required width, mixed
inverse or odd sign is omitted; controls that yield zero are not counted as
successful negative controls. Wrong carrier maps and unjustified quantum
restoration are rejected. Any necessary method/sign/frame/reality/UV failure
stops the scientific calculation and remains a preserved failure.

## Dependent comparison, validation and ceiling

After complete actual agreement, extract all g^2 L a C monomials from the frozen
complete unique inactive candidate, including eta_H, and compare every slot.
No further free affine directions remain. On first mismatch keep the full
actual-minus-candidate density and a nonzero real auxiliary Euler witness,
checked independently by ordered deletion. This excludes a pure boundary
density, not general equations of motion, cohomology or an anomaly. Stop before
fitting another primitive or running derivative-gauge/higher amplitudes.

Validate targeted scientific/process/governance checks, strict fresh own-byte
routes followed by comparison, all35 protected predecessor chains, new/state
SHA and audit-time metadata. Authenticate old expensive calculations without
rerunning them. Use python -B tools/research_check.py e5; custody stays expected
exit2/seven unresolved references, never PASS. Check raw Git-index/worktree
bytes before local commit. Engineering limits report incomplete work and
cannot relax scientific acceptance or truncate evidence.

Possible dispositions: qualified selected next-order auxiliary companion only;
exact stopped candidate obstruction; underdefinition; preserved necessary-gate
failure; incomplete execution. No full E5/A5/Ward/contact/IR/anomaly claim,
physical/catalog activation, HB1/C5/C1_GS/matching, authority promotion,
outreach, publication or push. Whole Spin(10) x global U(1)PQ goal remains
active/incomplete, including scalar/PQ and fermion/Yukawa/phenomenology.
