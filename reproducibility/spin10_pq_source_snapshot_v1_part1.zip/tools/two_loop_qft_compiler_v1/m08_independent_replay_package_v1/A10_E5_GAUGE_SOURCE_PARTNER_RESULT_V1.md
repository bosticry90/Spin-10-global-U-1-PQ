# Actual leading gauge-source partners and measured source Ward test, GP V1

The actualg10^2*xi J_B-B-C and J_B-A_H-C no-jet logarithmic poles agree between
the literal graded Born calculation and independently routed physical Wick
tensor sums. All1,846,800 source/vector/ghost/Lorentz component slots are
covered:1,458,000 B slots and388,800 A_H slots, including proven zeros.
J_B and C are ODD; gauge/background fields are even. Component counts are
not counts of independent physical amplitudes or independent observations.

In common hbar/(32pi^2epsilon_UV) units the actual B density is
g10^2*xi sum_(s,b,c,mu) V_(s;b,c) JBp_s^mu Bp_(b,mu) Cp_c, with no extra
Lorentz metric on this primal/dual source pairing. There are1,940 nonzero
physical COLOR coefficients and7,760 physical density terms over four
Lorentz components. For example V_(0;13,14)=18sqrt(10)/25. Source H rows
can contribute; they were not pruned using the lower source pole or Ward
target. Full canonical/physical roundtrip, reality and all12 constant-H
tensor identities are checked. Reference widths drop after full calculation.

The A_H pole is EXACTLY ZERO in its declared full domain. The calculation
retains216 raw A_H ghost and216 raw A_H auxiliary cubic terms. Their quantum
legs lie in H; the xi quartet vertex lies in M. The required H/M odd or mixed
inverse edge is zero in the complete principal reference. Physical S0 has no
A_H dependence. Thus the zero is established by the actual inventory and
contractions; it is not absence of A_H vertices or a predicted-zero omission.

## Complete triangle and Lorentz calculation

The permitted B families are the source/xi/derivative-ghost triangle,
source/xi/gauge-auxiliary triangle and source/xi/Yang-Mills triangle. They
have1,940/526/1,940 nonzero color coefficients. Each retains all six graded
Born words or all routed Wick contractions. The corresponding A_H ghost/
auxiliary families are explicitly calculated and zero. Source linear vertices
have Hessian0/one integrated incidence; source+gxi quartet cannot supply a
proper external gauge leg, higher-g quartics and positive-dimensional/scalar/
fermion alternatives keep their explicit coupling/UV/principal-edge exclusions.

Full-vector elementary controls calculate all16 source/vector Lorentz pairs,
both odd orientations, both mixed directions and all derivative placements.
Normalized diagonal weights are +1/2 (internal antighost derivative), -1/2
(internal ghost derivative), +1/2 (auxiliary cubic), -3/2 (Yang-Mills).
External gauge derivative has zero selected no-jet residue; its literal
vertex/current is retained. Off-diagonal intermediate kernels can be nonzero,
while their exact angular residues vanish. Gaussian and sphere moments agree.

The Yang-Mills triangle needs its transverse BB inverse. Removing that part
removes its nonzero residue. Its exact even-inverse pipe has orientation
weights3/4,3/4, verified against all six full-vector Born words for every
Lorentz pair. Contracting that pipe before the color trace is a structural
factorization, not the pureg^3 quartet's longitudinal-collapse rule. Source/
auxiliary endpoint exhaustiveness and three cyclic cuts/two orientations
are explicit. All color coefficients in the selected homogeneous degree
space are retained, with unbounded formal width arithmetic and no tolerance.

The two actual routes authenticate ancestors as BYTES, then deny prior E5
pole/completion and peer reads. Primary uses own literal vertices and exact
graded traces; replay reconstructs source/GF/YM tensors from physical10
commutators, crosschecks its own literal action before loops, and uses routed
Wick weights and separate color sums. No projected M-adjoint Jacobi, candidate
pole, required Ward completion, new normalizer or coefficient fit is used.

## Joint measured source Ward condition

Only after complete actual method agreement, the poles are appended to the
corrected known residue. Its canonical density now has30,595 terms. The new
actual source variation cancels ALL720 terms of the previously measured
leading source-wave Ward variation. The selectedg10^2*xi J_B-C/local-parameter
left side is zero RAW and after parameter IBP; all12 parameter Eulers vanish.
The full388,800 raw source/ghost/parameter-jet/Lorentz domain is retained.
Prefix and jet-gradient methods agree; no equations of motion or boundary
discard is needed to obtain this zero.

The updated complete KNOWN Ward variation has12,448 raw terms and five open
target signatures, reduced from six. New densities have no other local Ward
variation: their constant-H action is zero and only this affine source target
is present. Both previously selected Slavnov projectors receive EXACTLY ZERO
from the new node, checked against all1,286 E2 source columns and the existing
physical-Euler support proof. Earlier selected GS Slavnov qualification and
the higher auxiliary projection's open scope therefore remain unchanged.

Disposition: qualified actual gauge-source partner poles and zero selected
MEASURED source Ward left side, subject to the completed receipt and seal.
W_b(Gamma_known+Gamma_unknown)=Delta_b still has uncalculated complements.
Unknown Gamma, Delta_b/s, measure, operator/contact insertions and finite/IR
are not zero. This does not establish full quantum restoration, canonical
equivalence, anomaly freedom, full E5 or physical unification.

## Preserved pre-loop failures

Two implementation attempts stopped BEFORE any pole calculation. Attempt1
aligned background Lorentz labels before the raw-to-physical pullback; the
strict all-four-copy check failed. Attempt2 used the C3 chart on the physical
action's already normalized parent-plane structure table; the source/action
consistency check failed. The table has360 independent parent entries, while
BV geometry has886 ordered C3 entries. The repair uses E=[EH,EM] for the former
and Cinv/Cphys for the latter, requiring their FULL transformed tensors to
agree before the loop. It changes no physical coefficients or action inputs.

Both exact failed source snapshots/preparations/starts/full stdout and explicit
dispositions are preserved and excluded from PASS. No equality/type gate was
weakened. Qualifying controls use preparation1, primary/replay preparation4,
comparison preparation5; each fresh execution uses its original own bytes.

## Validation, authority and next action

The exclusive receipt owns tests, commands, source snapshots, starts/runtimes,
four fresh byte-identical executions,45 protected chains and protected/new/
state/metadata invariance. Historical custody remains exit2/seven unresolved
references, neverPASS. Old expensive loop/image calculations authenticate
only. Raw index/worktree byte equality precedes localcommit; no push/publication.

The existing epistemic ladder and solo-review policy apply. Verification is
bounded; formalization not attempted; empirical connection none; interpretation
established only within the stated UV/component/functional scope. Methods
share action, representations, some exact arithmetic/reference data,
Python/SymPy and analyst, not independent scientists or external endorsement.

Statev113/34of39 is unchanged. The priorg10^3 inactive-candidate quartet
mismatch remains FAIL. Full W1-W7/A1-A5, nonlinear Slavnov restoration,
whole-product/source-operator transport, regulator/measure and IR remain open.
HB1/C5 stay blocked; finiteC1_GS uncalculated. Scalar/globalPQ, fermion/Yukawa,
phenomenology and the complete Spin(10)xglobalU(1)PQ goal remain incomplete.

Next smallest actual action: prospectively freeze and calculate the leading
g10^2 auxiliary/vector partners Lambda-B-B and Lambda-A_H-B with complete
literal inventory, scalar-source parity, Bose/Lorentz symmetries, independent
zero proofs and full Ward comparison. Other higher source/derivative targets
remain unmeasured. No automatic fitting or normalizer adoption.
