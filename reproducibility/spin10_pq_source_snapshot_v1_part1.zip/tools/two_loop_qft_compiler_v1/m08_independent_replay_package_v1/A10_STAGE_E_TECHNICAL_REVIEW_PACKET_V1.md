# Solo technical review: Stage E E1 fermion binding

This packet requests no outreach and claims no external endorsement. The governing policy is `docs/SOLO_REVIEW_POLICY_V1.md`. The substantive objections remain mathematical requirements.

The bounded result is an underdefined fermion chart with an exact rejected direct-identification control. Challenge it through the following independent checks before E2:

1. Locate an actual binding of A4-V2/A5-V2 nonminimal leaves and all their contractions to the Stage D coordinates. A prospective map whose historical identification flag is false does not supply that binding. Source-coupling and Euler qualification alone do not settle the fermion.
2. Derive the auxiliary first variation directly in physical real coordinates. Compare the bare contraction's twelve matrices and its nonzero Euler column with `primary.json` and `replay.json`. Verify the projector/conjugation conditions of the real witness.
3. Check the complete recovered fermions for a possible contribution to the selected `omega*ub*Lambda` monomial. The existing total-H covariant divergence must be retained; an obsolete V1 failure is irrelevant to this input.
4. Derive the inverse-Gram bilinear from the dual-heavy physical embedding, without fitting a coefficient. Then investigate the cubic tensor and exact Goldstone/orbit contractions independently; one successful auxiliary control does not qualify the complete fermion.
5. Bind light antighost/auxiliary charts and derive their invariant pairing, including the physical Lorentz measure. Preserve the direct evaluation pairing for canonical sources as a distinct structure.
6. After E1 qualification, derive the complete canonical source shifts, master transport, quantum/background distinctions and composite chains before attempting the joint domain. Do not erase old evidence or declare source-zero restrictions invariant without proof.

The primary/replay methods share assumptions, Python/SymPy, immutable physical data and analyst. The replay's independently reconstructed physical commutators and first variation establish the specified coefficient agreement, not independent external verification or a complete partial-gauge theorem. Published comparators are Ferrari, arXiv:1308.6802, and Thomsen, arXiv:2404.11640. No personnel-dependent gate is imposed.

Formal authority stays 34/39. Historical custody remains seven unresolved references at strict exit 2. HB1/C5, catalog replacement, source activation and quantum matching remain outside authorization.
