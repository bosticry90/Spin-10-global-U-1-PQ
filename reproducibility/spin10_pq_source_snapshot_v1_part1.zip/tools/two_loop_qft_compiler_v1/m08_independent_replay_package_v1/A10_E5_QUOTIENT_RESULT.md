# E5 quotient: a qualified canonical family and a general-coverage stop

The contract is `A10_E5_QUOTIENT_CONTRACT_V1.md`; the accompanying policy
analysis defines the two quotients and the remaining proof obligations.
The completed routes agree on an arbitrary two-parameter ghost/source
renormalization family. The old exact witness is reconciled as the tangent
to a canonical redefinition, with all operators retained and transported.
This is a partial qualification. It does not qualify full E5 or a general
counterterm catalog, and it preserves the old literal-domain failure.

Disposition:

    PARTIAL_E5_QUOTIENT_CANONICAL_GHOST_FAMILY_QUALIFIED_GENERAL_COVERAGE_UNESTABLISHED

## Finite canonical construction

Before U, V scales C_H by zH and C_M by zM and their evaluation sources by
the inverse factors. Other coordinates are fixed. The normalization units
are real invertible dimensionless symbols in a Laurent coefficient ring;
identities hold for arbitrary units, not just sampled values. They are not
new physical parameters. Infinitesimally, K_H and K_M are the respective
sums JC_a C_a. Their grades are (3,-1,odd), so their Hamiltonian vector fields
preserve dimension, ghost number and parity.

After gauge-fixing transport the map is V'=U V U^-1. An independent form is

    Gamma=Psi-V Psi,
    V'=U_Gamma V,
    V' z=t_z z,
    V' Jz=t_Jz [Jz-(-1)^p_z Euler_left,z(Gamma)].

This derives every shifted source; names or invariant metrics are not used
in place of canonical evaluation pairing. Primary computes conjugation and
prefix variation. Replay differentiates Gamma and the complete finite action
by independent left jet gradients. It also reconstructs all 990 normalized
physical matrix commutators, preserving the actual H/M block structure and
the nonsymmetric heavy bracket. Both routes compare all 1,286 finite maps,
all 1,286 source-polynomial Euler columns, 2,572 inverse checks, 2,572 selected
first-jet checks and 1,286 finite Cartan checks. The receipt/auditor records
the actual nonzero coefficient counts.

The physical-frame maps and conjugation matrices commute with these real
block rescalings, while the evaluation sources use the inverse map. All 48
external backgrounds remain fixed external coordinates. All 508 physical
Euler programs and physical field/source coordinates remain literal spectators.
The physical action, potential, vacuum, g10, xi, eta_H and alpha=xi are unchanged.
Neither the historical action nor A4-V2/A5-V2 is retroactively rewritten.

## The original witness and the action sign

The full K_H+K_M reproduces the sealed K', F'=Q'K' and nonhorizontal Euler
witness with exact free coefficient +partial_0 omega_0. The calculation
derives the original Euler derivative again from the authenticated complete
horizontality defect; it does not overwrite or discount that defect.

With X_K=(K,.) and Q'=(S',.), the bracket gives X_K S'=-Q'K as a functional.
The finite forward flow therefore has tangent -F'; its inverse has +F'.
The complete density comparison is

    derivative_log(zH,zM) S_new at identity
      = -F' + partial_mu [U(sum_a JB_a^mu C_a)].

The explicit current is independently compared. No density equality without
this current is asserted. The negative orientation produces a nonzero Euler
coefficient +2 partial_0 C_0. Scaling a source in the same direction as its
ghost gives pairing defect zH^2-1. These are exact negative controls.

## What remains fixed and what is transported

For the entire tested family, V' commutes with both Tq' and Tb. Their complete
canonical source realization is retained. Their equality follows from the
actual H representation blocks and finite operator comparisons; it is not a
rule that all redefinitions must leave all Ward operators unchanged.

Q_new=V' Q' (V')^-1 and iota_new=V' iota' (V')^-1. In particular,

    iota_new C_H=omega_H/zH.

The Cartan relation survives. Keeping iota' fixed instead gives the exact
free defect (zH-1) partial_0 omega_0 on B0_0. Thus fixed Ward operators and a
fixed complete Cartan structure are different restrictions. A policy that
freezes contraction cannot silently admit the H ghost rescaling.

Canonicality follows both from the U/V factorization and the independent
generating-fermion realization. V preserves the evaluation pairing by inverse
source weights; U and U_Gamma have graded Hessian functional symmetry. Ordinary
jet prolongation commutes with these constant units and the qualified source
shifts. Consequently the existing smeared functional pairing proof applies
to Gamma as well. No new exhaustive 643-by-643 Hessian enumeration is claimed.

The transported master density is V' of the previously qualified divergence;
its current is V' of that current, because the map commutes with ordinary
derivatives. The master functional and full retained-source off-shell
nilpotence follow by canonical conjugation and graded Jacobi. All-source
squares and every higher jet are not newly brute-force expanded. The explicit
new maps, Euler columns and finite Cartan checks support this structural proof.
No antifields are set to zero and no auxiliaries are eliminated.

## Exact-family equivalence versus full adequacy

The exact family's first-order tangents have zero basic representatives in the full
quotient when their redefinitions and operator transport are retained. This
answers the recorded witness without contradicting its literal nonbasicness.
It qualifies the complete two-parameter family, not only one free channel.
The finite action and differential are transported together. The entire finite
action difference is not asserted closed or exact under the original fixed Q'.
It does not establish quantum Jacobian/measure invariance, observable
renormalization, perturbative renormalizability, anomalies or loop generation
of any term.

Q5 stops at GENERAL_COVERAGE_AND_QUANTUM_WARD_ADMISSIBILITY_UNESTABLISHED.
The policy analysis records the exact surjectivity and injectivity obligations.
An induced basic quotient by the intersection with permitted full exact terms
has an injective inclusion by definition; surjectivity is still a theorem to
prove. Intrinsic basic exactness is a different equivalence and has not been
identified with it. No missing nontrivial cohomology class is claimed here.

The published semisimple Yang–Mills representative theorem is relevant, but
its assumptions have not been bridged to the complete local coefficient ring,
regularity/Noether resolution, external-background counterterms and declared
Ward restrictions of this model. Strict classical Tq' symmetry is not by
itself a derivation of a required renormalized quantum Ward identity. These
are specific remaining mathematical obligations, not a demand for outside people.
The [policy analysis](A10_E5_RENORMALIZATION_POLICY_ANALYSIS_V1.md) cites the
primary literature and states precisely which uses remain conditional.

## Validation, custody and limits

The completed validation receipt owns exact test/fresh-route counts, runtime,
commands and bound hashes. It selects new quotient, E5 and E2–E4 scientific
regressions, existing process/governance checks, the local E5 delegation and
two fresh new routes. Fourteen predecessor manifests authenticate. Older
expensive mathematical derivations are authenticated, not rerun. Workspace
inventory covers size/mtime metadata; protected evidence receives byte hashes.
This is not a whole-environment byte audit or unrestricted repository PASS.

The routes share immutable inputs, word arithmetic, Python/SymPy and analyst.
There is no external endorsement or proof-kernel formalization. Historical
custody remains strict exit 2 with seven unresolved references. Formal
authority remains 34/39 and M08 blocked. No source activation, catalog change,
HB1/C5, finite C1_GS, quantum matching, personal contact, publication or push.

The next smallest scientific task is the model-to-cohomology-theorem and
quantum Ward-admissibility bridge, with explicit external-background/source
scope and both comparison directions. Retain the old witness, inverse-source
pairing control and fixed-contraction defect. Full E5 remains unqualified.
