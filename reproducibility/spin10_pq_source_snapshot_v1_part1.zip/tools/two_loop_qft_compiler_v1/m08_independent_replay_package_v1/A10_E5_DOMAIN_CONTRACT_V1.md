# E5 inactive domain closure and counterterm adequacy contract

Question: does a justified residual-H basic local-functional domain of the
qualified gauge/scalar retained-source BV system have both differential
closure and adequate counterterm content? These are independent obligations.
The attached assessment of `76affe5` authorizes this bounded attempt. D–E4,
their physical inputs, parameters and thirteen predecessor manifests remain
frozen. Formal authority stays 34/39; solo review applies without outreach.

Use the complete 643 canonical pairs and 48 external H backgrounds, ordinary
symmetric jets and the established source-left bracket. Derive dimensions,
ghost numbers and parity from the frozen alphabet and physical/source terms.
No fermion/Yukawa, inverse-dimensional coefficients, EFT extension or catalog
replacement. A declared polynomial coefficient ring treats the unchanged
dimensionless parameters as coefficients, not finitely sampled values.

First derive a local H contraction on the pre-transport full system, including
the light nonminimal correction required by its trivial-pair rules. Derive
every source image canonically; do not extend field rules by bare labels.
Require the full Cartan relationship {iota,Q}=Tq, contraction square zero,
background compatibility and prolonged local parameter jets. Independently
derive the correction using physical H matrices. Transport all fields/sources
through the qualified E2 canonical map, using odd Leibniz signs. Use Tq'
(transported), not the distinct geometric quantum operator.

The proposed domain is ker iota' intersect ker Tq' intersect ker Tb on local
functionals modulo explicitly retained ordinary divergences. Q' is the full
BV differential in this proposed deformation complex. Prove its closure using
the checked Cartan relationship and E3 commutators. Supply nonzero physical
and source-dependent controls. Do not claim that c_H=0 is a Q-stable quotient,
or that full BV nilpotence alone qualifies the E4 restricted domain.

Test adequacy independently of closure. The necessary starting deformation
language includes local ghost-number-zero, dimension-four BV-compatible
counterterms, including canonical field/source renormalizations. Test the
canonical ghost-rescaling generator sum JC_a C_a and its Q' image as a
source-dependent exact deformation. Check its background/quantum Ward
behavior, power counting and horizontality. A nonhorizontal permitted class
is a literal-domain adequacy obstruction; being BRST exact does not erase it
without an explicitly justified quotient and separate renormalization policy.
If this distinction is underdefined, preserve the witness and stop before
claiming universal adequacy or enumerating a counterterm catalog.

Primary prefix/canonical and replay physical-matrix/left-gradient routes must
agree exactly. Include omitted nonminimal correction, wrong contraction/source
sign, geometric-versus-transported substitution, and trivially closed-domain
controls where reached. General source/jet conclusions may use checked
Hamiltonian/Jacobi/prolongation arguments with disclosed dependencies.

Effort boundary: one complete initial derivation per route, decisive controls
and one fresh validation replay of newly completed bounded evidence. Scope
stops at the first essential failure or underdefinition. Resource caps raise;
interruption/exhaustion means incomplete, never scientific PASS. Engineering
work may continue independently. No brute-force catalog expansion is required
to preserve the first exact missing-class witness.

Classify closure separately from adequacy: qualified within scope, exact
obstruction, underdefinition, or bounded incomplete work. A full E5 PASS
requires both. No activation, historical catalog replacement, HB1/C5, finite
C1_GS, quantum matching, authority promotion, external publication or push.
Any narrower quotient/renormalization target is a concrete next proposal,
not a silent change to this test. Commit locally only after bounded validation.
