# Prospective cubic primitive and quartic calculation

The actual-minus-joint cubic tensor D_ab c is antisymmetric in Lambda/ubar
slots. In the declared no-source/no-jet two-antighost/one-ghost sector,

    K3 = -g xi^2/2 sum D_ab c ubar_a ubar_b C_c,
    Q0 K3 = g xi^2 sum D_ab c Lambda_a ubar_b C_c.

This right section follows by left graded variation and antisymmetry. Its
uniqueness is limited to that sector; broader Q0-closed primitive freedom
must not be erased. Test all12 H actions before accepting compatibility.

The xi^2 Lambda kappa_aux Lambda pole was already calculated. Its pole
generator is K0=-xi^2 ubar kappa_aux Lambda, since Q0 ubar=-Lambda. The
counterterm has opposite sign. The new full pole candidate is the Q image
of K0+Kjoint+K3, with the complete first-variation current. K0's nonlinear
Q Lambda contains R_H and supplies a quartic term at g^2*xi^2. Omitting it
would test a different candidate. None of these primitives is adopted.

For a one-loop four-point graph sum(degree-2)=4. With the literal maximum
degree4, forms are four cubics, two cubics plus a quartic, or two quartics.
All allowed coupling assignments at g^2*xi^2 must be included. In particular
the ordinary g^2 gauge/ghost quartic plus two xi Lambda/ghost cubics is
logarithmic and may involve the H projection of two heavy fields.

Gauge derivative vertices with external antighost have negative UV degree
after full integration by parts. Nonzero logarithmic g vertices instead have
external ghost and internal differentiated antighost. Xi vertices have heavy
auxiliary legs. An H/light channel is excluded only after the literal vertex
and full physical mixed/ghost edge proof. Each retained gauge leg joins an
auxiliary, giving k_mu k^mu rather than an assumed angular factor. The full
reference includes the gauge–gauge block, even when its target trace drops.

Primary computes coefficients of the graded Born log through order4, using
all shuffle words. Replay factors the same full quadratic supermatrix into
even/odd Gaussian blocks; it does not remove an auxiliary from the action.
For A even, D odd block and X/Y mixed blocks, the formal identity is

    STr log H = Tr log(A-X D^-1 Y) - Tr log D.

Expand the odd inverse and both logs to the exact coupling/external degree.
The odd block includes all CC, antighost-antighost and mixed Hessians from
the complete g*xi four-ghost vertex. The even B-B block contains the full
ordinary g^2 quartic. Mixed vertices carry odd background coefficients; their
order and Fourier momentum signs must be respected. Verify against a small
graded direct determinant control and the primary words before qualification.

The UV pole comes from k_E^2>R^2 and homogeneous degree-4. Zero-momentum
Taylor there is not an IR prescription for the entire massless amplitude.
Box/triangle/bubble heat factors give E1(8R^2/Lambda^2), E1(6R^2/Lambda^2),
E1(4R^2/Lambda^2) with equal pole residues and different finite split terms.
The full finite amplitude/IR/contact restoration is outside this increment.

All candidates use the frozen canonical bracket and qualified source columns.
Nonlinear source shifts are prolonged with full product rules. The field
rescaling's regulated spacetime trace remains; source-free shifts only affect
external BV sources. Classical Q exactness and matched selected poles cannot
establish the full quantum A5/Ward/renormalization target.
