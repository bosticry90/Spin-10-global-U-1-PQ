# A10 physical-action scope correction V1

The literal promoted A10 action cannot be treated as a complete locally
gauge-invariant physical action under the qualified transformations. Commit
`2665832` established the exact complete-action counterexample. This correction
narrows that scientific interpretation without rewriting historical acceptance
records or the formal 34/39 ledger.

## Construction and authority audit

`execute_a3_scalar_geometry.py:kinetic_ast` constructs ordinary canonical
kinetics, `1/2 sum_i (partial x_i)^2`, and their ordinary Euler operators.
`A37_scalar_kinetic_ASTs.json` qualifies exact real coordinates and the
free scalar metric. The A3 acceptance records qualify embeddings, constrained
tangents, invariant potential contractions and these kinetic coordinate maps.
They do not establish a complete interacting gauge-covariant kinetic action.

The unified-action construction in `execute_action_ast_p1_a10.py` inserts those four A37 terms
without covariantizing their derivative nodes. Its physical portion consists
of one gauge term, four scalar kinetic terms and 29 potential terms. Two
additional terms describe heavy and light gauge fixing/ghosts. A10's source-zero
promotion and `ACTION_AST_RESULT.md` gave this assembly a complete-action
interpretation. No contemporaneous construction contract examined here declares
an intentional omission of the scalar–connection interactions.

Therefore the supported classification is an omitted interacting kinetic
structure in an artifact whose promoted scope was too broad. It is not justified
to reinterpret the historical PASS retrospectively as proof of a complete
interacting physical action. A37's ordinary-coordinate qualification survives.
The literal A10 source-zero assembly and its arithmetic provenance remain
historical artifacts; their local gauge-invariance claim is contradicted in the
recorded channel. The correction neither asserts every historical acceptance
check was numerically wrong nor refutes Spin(10).

## Scientific disposition by dependency

| Result or claim | Current disposition |
| --- | --- |
| Spin(10) Lie algebra, canonical embeddings, representation geometry | Preserve the bounded results; all four representations are independently reproduced here. |
| Scalar potential/invariant contractions | Preserve the literal 29 directions and parameters. Their Spin(10) Ward identity holds by tensor-slot contraction. |
| Positive Higgs benchmark `lambda_eff=0.104858242929587` | Preserve as the reported local tree potential-only benchmark. Candidate kinetic terms reduce to the same canonical metric at zero connection, and the potential is unchanged; the review does not rerun or promote its numerical/phenomenological interpretation. |
| Global scalar boundedness | Still unresolved; no new boundedness calculation. |
| N1-N4 charge/gauge normalization | Preserve; supplies the coupling and kinetic normalization of the candidate, not a fitted coefficient. |
| N5-N8 orbit, mass and Goldstone pairing | Preserve the exact geometric orbit/Gram certificates. Both new routes reproduce them from the actual VEV. Their standard covariant-kinetic mass interpretation is recovered by the candidate, but is unsupported as a derivation from literal A10's ordinary scalar kinetics. |
| Gauge-boson masses and scalar–vector mixing attributed to literal A10 | Require correction: its physical ordinary scalar kinetic terms generate zero scalar-induced vector mass and no covariant kinetic mixing. Gauge-fixing contributions cannot establish physical masses. |
| Scalar–gauge vertices from historical complete A10 | Require reconstruction. The candidate defines them by expansion with coefficients fixed by covariance. No vertex catalog is rebuilt or claimed qualified. |
| Historical ST/BV/source and gauge-fixing identities | Preserve recorded mathematics and negative controls. Applicability to the candidate requires a separately scoped source/GF reconciliation. No complete master identity is claimed. |
| Mixed source fiber and heavy canonical map | Preserve their authenticated bounded PASS results; neither contains the physical scalar kinetic action. No expensive rerun. |
| Previously started mixed kinetic calculation | Completion remains unestablished; no completed evidence inferred and no rerun launched. |
| JCAT/T5 operator catalogs | Preserve historical language qualifications; counterterm applicability and descent under a revised differential/action remain unqualified. |
| HB1/C5 and finite C1_GS | Blocked/uncalculated; not run or authorized by these checks. |
| Formal project authority and historical custody | 34/39 unchanged; custody exit 2 with seven unresolved bindings remains unresolved. |

This is a scientific interpretation correction, not a machine-ledger mutation.
The inactive candidate is a separately named factorized classical physical
specification. Its successful checks do not change the frozen A10, resolve
historical source defects, or authorize adoption. Under the owner's
[solo-review policy](../../../docs/SOLO_REVIEW_POLICY_V1.md), literature and
independent derivations remain available; personal outreach is discontinued.
