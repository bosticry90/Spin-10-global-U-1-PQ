# Phase C: complete physical-action scalar prerequisite

**Disposition: STOP_PHASE_C_FOR_PHYSICAL_ACTION_RECONCILIATION.** The literal
promoted A10 physical action fails the selected local H4 scalar gauge-invariance
channel under the coherently derived scalar and connection transformations.
This is a completed bounded counterexample, independently reproduced; it does
not promote a replacement action or change formal scientific authority.

The governing evidence is [the unchanged Phase C contract](PHASE_C_MIXED_SECTOR_CONTRACT_V1.md).
Recovery began from local `4607c9d` on `main`, 67 commits ahead of the recorded
remote tracking branch. There were no tracked or staged changes and 14 surviving
untracked Phase C files. The process command-line inspection found no surviving
Phase C calculation. No process was terminated, calculation duplicated,
repository reset, evidence discarded, or remote operation performed.
[Recovery custody](frozen_phase_c_scalar_action/recovery.json) records the initial
file hashes. The old isolated scalar script remains an unqualified interrupted
draft; its output is not the evidence used for this verdict.

The saved mixed-source primary/replay pair is byte-identical and records
`PASS_MIXED_SOURCE_FIBER_ONLY`: 30 pairs, 60 generators, 60 Q squares, 60 Cartan
equations, 60 contraction squares, 60 TQ equations and five derived-R chain
checks. The saved heavy canonical-map pair is also byte-identical and records
`PASS`. Both are authenticated and reused, with their original bytes preserved;
neither calculation was rerun. Their surviving records had no separately saved
Phase C validation receipt; this recovery does not invent earlier signed custody.
All **171 predecessor byte bindings** authenticate without refreshing expectations.
The mixed-kinetic scripts survive as diagnostic drafts, but there is no saved
completed result. No new mixed-kinetic run was launched. Its completion remains
**not established**, rather than PASS or a scientific failure.

The frozen action is
`frozen_action_ast_p1_a10/M08_ELIMINATED_ACTION_AST_V1.json`, canonical action
hash `36abb0301627acf272a2904da3968781368b1d1d10a7115f7408e1767e20aa2b`.
Both its artifact hash and its canonical action hash are recomputed. It contains
36 terms: one Yang--Mills kinetic sector, four scalar kinetic sectors, 29 parent
potential directions and two gauge-fixing/ghost sectors. The first 34 terms
constitute the physical action for this test. A10 itself has zero external
sources; the later source-extended Sigma is a separate historical construction.

The derivative semantics are literal ordinary derivatives. `PartialDerivative`
stores an index and an argument in `m08_local_functional_ast.py`; it inserts no
connection or representation generator. Frozen A37 explicitly declares
`L_kin=1/2 sum_A partial_mu x_A partial_mu x_A`. The A10 Phi tree has exactly
54 terms, each `1/2 PartialDerivative(mu,x) PartialDerivative(mu,x)`, with no
hidden covariant node. The replay separately verifies that these names and
coefficients match the physical symmetric-tensor pairing from A31.

Gauge-field variations are considered **before** the zero-connection projection.
With action normalization, the total connection obeys
`delta B_mu=partial_mu C4+g10[B_mu,C4]`; the scalar rule is
`delta Phi=-g10 C4 rho_4 Phi`. For a quantum residual-H transformation the
background is fixed, the quantum light connection has the inhomogeneous term,
and the heavy connection transforms homogeneously. The absence proof deliberately
allows an inhomogeneous derivative-of-C4 variation for *every* connection carrier,
so it also covers other allocations between background and quantum fields.

Every action tree is expanded into field/derivative supports, varied with the
Leibniz rule, and only then projected to the selected scalar channel. Discarding
coefficients and contraction tensors makes this an overestimate of possible
support; cancellation is never used to prove absence. An independent replay
propagates scalar/connection/other bidegrees. Both scanners also admit the shifted
scalar's constant VEV contribution. Such shifts generate lower scalar degree and
cannot alter this quadratic-Phi witness.

| Literal sector | Why it cannot compensate the selected channel |
| --- | --- |
| Gauge kinetic | Contains no scalar carrier, including after connection variation |
| Other three scalar kinetics | Tensor representations preserve their separate scalar sectors; no Phi mixing |
| All 29 potential directions | Have no derivatives; variation has no parameter jets and its ghost Euler derivative has no scalar jets |
| Light gauge fixing/ghosts | Contains no scalar carrier |
| Heavy equivariant gauge fixing/ghosts | Scalar/VEV maps occur algebraically; derivative-bearing scalar cross terms have only one scalar carrier, and remaining derivative terms contain gauge/nonminimal carriers |
| Source terms | Absent from A10; cannot supply missing physical interactions by changing the separate source-extended action |

The Euler-channel scan additionally checks *total* derivative degree two, so a
possible `C4'' Phi Phi` compensator is not lost by looking only for `C4' Phi Phi'`.
It excludes every non-scalar-kinetic sector even with the overestimated variations.
The independent physical tensor construction acts on Phi as `h Phi+Phi h^T`,
with h reconstructed from C3 generator 4 divided by sqrt(2). A31 extraction
intertwines this action and has identity kinetic metric. Primary uses the saved
SA10 representation, exterior polynomials and prolonged kinetic variation;
replay uses physical 10-by-10 tensors, a local-parameter current and ordered words.

For the preregistered density word
`C4__0 x_Phi_offdiag_0_4 x_Phi_offdiag_0_1__0`, both routes give exactly

```text
coefficient = sqrt(2)*I*g10/2 = I*g10/sqrt(2).
```

All **400 quadratic-Phi variation coefficients** and **400 ghost Euler
coefficients** agree exactly across the two routes in four Minkowski directions.
These are the complete quadratic-Phi two-derivative channel of the relevant
action, not a claim that all potential or gauge-fixing variation channels were
evaluated or vanish. The result does not rely on the isolated kinetic variation
alone: the action-wide absence certificates are necessary parts of the proof.

Set `X=x_Phi_offdiag_0_1`, `Y=x_Phi_offdiag_0_4` and `k=I*g10/sqrt(2)`.
After variation, projection to these two fields preserves the smallest witness:

```text
delta L |two fields = k (partial_mu C4) (Y partial^mu X - X partial^mu Y)
Euler_C4(delta L)    = k (X box Y - Y box X).
```

In particular the independent jet word `X Y__00` has Euler coefficient `k`.
It is not a zero polynomial off shell. No equations of motion, field equations,
coupling adjustment or quotient are imposed. A local total derivative has zero
Euler derivative, so this is a functional obstruction under the frozen A2
boundary convention. The replay reproduces the same result through scalar
Euler derivatives of the physical kinetic action, independently of ghost IBP.

The projection-order control actually constructs a **diagnostic, absent** linear
connection/current term, varies its connection before setting it to zero, and
finds the exact opposite of the scalar residual. Premature projection would
erase this compensator. This validates the method's sensitivity to precisely
the interaction in question. The control is not an adopted completion, a new
action term, or a fitted parameter.

The physical action must satisfy its local gauge obligation. Gauge-fixing and
ghost sectors instead enter the appropriate BRST/equivariant formulation and
need not individually obey the physical-action Ward identity. No full
gauge-fixed BRST identity or historical source-extended master equation is
claimed to have been recomputed here. Failure of the necessary physical-action
channel is sufficient for this Phase C stop; it is not a substitute verdict
on every historical BRST formula.

| Prior result or dependency | Impact of this bounded witness |
| --- | --- |
| Mixed-source fiber and heavy nonminimal canonical map | Preserved bounded successes; neither contains the physical scalar kinetic action |
| C3 Lie/tensor geometry, A31 constrained embeddings, scalar representation and potential algebra | Not refuted by this missing-interaction witness |
| A37/A10 physical-action completeness and normalization/covariant-derivative assumptions | Require reconciliation of literal trees with their physical interpretation |
| Goldstone mixing/mass cancellation and eliminated-action claims depending on covariant scalar kinetic interactions | Dependency review required; no numerical falsification claimed here |
| Sigma/S5-S8 combined action/source consistency and subsequent BV reconstruction | Review required before treating the physical-action prerequisite as satisfied |
| Gauge--scalar vertices, matching and later quantum calculations | Depend on a physically reconciled action; no recalculation or new value is authorized here |
| Historical scalar-only calculations and formal 34/39 ledger | Preserved; no blanket invalidation or promotion is inferred |

[The validation receipt](frozen_phase_c_scalar_action/validation_receipt.json)
records byte-identical fresh **scalar-only** primary/replay regeneration, all
800 exact coefficient comparisons, agreement of all 36 sector classifications,
seven meaningful compensator/divergence regressions, 21 governance regressions,
authority coherence, structure-preserving-map and read-only-entrypoint audits.
The audit-time workspace/active-data metadata inventory covered 127087 files
and recorded zero changes. This is size/mtime preservation plus selected byte
authentication, not an all-byte audit. The route runners deny file writes and
use the existing pole-blind guard; no forbidden pole/projection payload is read.

Historical custody separately returns **exit 2 with seven unresolved original
references**. Current coherence and historical package integrity do not resolve
them. This receipt validates the bounded failure evidence; it is neither an
overall custody PASS nor a scientific prerequisite PASS.

Both routes share Python/SymPy, frozen C3/A31 physical inputs, conventions and
the analyst. Algorithm and code-path independence is demonstrated; library,
runtime, analyst-blind or external-specialist independence is not claimed.
External specialist review remains outstanding, and no specialist was contacted.

Formal authority remains **34/39**, M08 attempt 1 remains blocked, HB1/C5 remain
blocked and unexecuted, finite C1_GS remains null, and the authoritative
`project_state.json` bytes are unchanged. Frozen M08 definitions, sources,
catalogs and historical controls remain unchanged. No replacement is activated.

The next decision is a separately scoped physical-action reconciliation and
external specialist review of this exact witness and its dependency inventory.
Determine whether A10 omitted required scalar--connection terms or whether its
declared action semantics need correction, before authorizing any resumed Phase C
physical expansion. No such correction is made or assumed in this execution.
