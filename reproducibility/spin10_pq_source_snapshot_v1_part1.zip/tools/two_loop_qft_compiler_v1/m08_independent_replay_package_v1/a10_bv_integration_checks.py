"""Canonical transport, bracket axioms, jet and grammar adversarial checks."""
from itertools import product
import sympy as s
from a10_bv_integration_common import *

def bracket_axioms():
    from source_convention_control import Exterior
    a=Exterior();parities={'q':0,'Jq':1,'c':1,'Jc':0};pairs=[('q','Jq'),('c','Jc')]
    x={n:a.variable(n,p) for n,p in parities.items()}
    # Constant source-left bracket is the canonical odd Poisson bracket after
    # zstar=(-1)^p_z J. The coordinate map is invertible and constant, proving
    # graded antisymmetry, Leibniz and Jacobi generally. Check mixed products
    # independently, where left/right odd differentiation signs are decisive.
    pool=[(x[n],p) for n,p in parities.items()]
    pool+=[(a.mul(x[u],x[v]),(parities[u]+parities[v])%2) for u,v in product(parities,repeat=2) if a.mul(x[u],x[v])]
    count=0
    for (F,p),(G,q),(K,r) in product(pool,repeat=3):
        jac=a.add(a.scale(a.bracket(F,a.bracket(G,K,pairs),pairs),(-1)**((p+1)*(r+1))),
            a.scale(a.bracket(G,a.bracket(K,F,pairs),pairs),(-1)**((q+1)*(p+1))),
            a.scale(a.bracket(K,a.bracket(F,G,pairs),pairs),(-1)**((r+1)*(q+1))))
        assert not jac,'GRADED_JACOBI_NEGATIVE';count+=1
    return {'mixed_monomial_Jacobi_checks':count,'general_proof':'constant invertible zstar=(-1)^p J canonical odd Poisson coordinate map; prolongations and Euler IBP give the local-functional bracket',
        'source_left_even_action_columns':'Qz=EL_left_J S; QJ=EL_left_z S',
        'nilpotence_identity':'Q^2 F=1/2 ((S,S),F) modulo local-functional boundaries'}

def jets():
    _,cols=source_data();w=algebra();selected=['B0_0','x_Phi_0','x_Sigma_0','x_phi_0','x_S_0','C12','ub12','L12','bar0','b0','JB0_0','Jx_Phi_0','JC12','Jub12','JL12','Jbar0','Jb0']
    checks=0
    for n in selected:
        for mu in range(4):
            lhs=w.act(w.D(w.var(n),mu),cols,parity=1);rhs=w.D(cols[n],mu)
            assert not canonical(w.add(lhs,w.scale(rhs,-1)));checks+=1
    try:w.D(w.var('C12',(0,)*6),0)
    except RuntimeError:limit=True
    else:raise AssertionError('JET_LIMIT_RETURNED_ZERO')
    return {'source_and_field_prolongation_checks':checks,'all_ordinary_jet_proof':'Q D_I z=D_I Q z by the jet derivation definition and ordinary partial commutativity; all base identities prolong without an EOM',
        'computational_jet_cap_raises':limit,'truncated_jet_zero_relation':False}

def composite_omission():
    _,cols=source_data();w=algebra();wrong=dict(cols)
    for i in M:wrong[f'L{i}']={word:c for word,c in cols[f'L{i}'].items() if len(word)==2}
    residual=canonical(w.act(wrong['ub13'],wrong,parity=1))
    assert residual
    return {'coordinate':'ub13','omitted':'only cubic composite-R terms in QLambda',
        'residual':rows(residual),'H_singlet_control':'Q Lambda12=0; ubar12 is not a transforming-direction witness',
        'candidate_modified':False}

def build(stage=lambda n,f:f()):
    from a10_bv_integration_transport import build as transport
    from a10_bv_integration_replay_control import wrong_free_Euler_control
    return {'schema':'A10_INACTIVE_STAGE_D_ADVERSARIAL_CHECKS_V1',
        'status':'PASS_BOUNDED_STAGE_D_CONTROLS',
        'heavy_canonical_transport':stage('full_parent_111_pair_heavy_transport',lambda:transport(stage)),
        'bracket_axioms':stage('independent_mixed_graded_Jacobi_checks',bracket_axioms),
        'jets':stage('field_source_jet_prolongation_and_resource_limit',jets),
        'wrong_gauge_Euler_negative':wrong_free_Euler_control(),
        'composite_curvature_omission_negative':composite_omission(),
        'inherited_controls':'old A10 scalar residual, factor-120 shortcut, Lorentz sign and nonsymmetric mixed-source controls authenticated byte-for-byte through all seven manifests',
        'Stage_E_reached':False,'sources_activated':False,'personal_outreach':False}
