"""Typed final composition of qualified, already evaluated physical Euler ASTs.

This is not a derivative engine. Upstream inputs are evaluations of the five
gauge ASTs, four kinetic ASTs and 29 raw potential bundles bound in primary.
Keeping this layer linear preserves their general variational qualifications.
"""
import sympy as s
from a10_bv_integration_common import HERE,read,mat,DIM,IDS
from a10_cotangent_adapter import Adapter

def canonical_physical_values(gauge_plane,kinetic,ordered_potential):
    """Return the 508 physical source additions at arbitrary exact supplied jets.

    gauge_plane[(a,mu)] is the sum of the five qualified gauge Euler outputs.
    kinetic[sector] is its canonical kinetic Euler column. ordered_potential
    maps ALL 29 term IDs to ALL four raw alias/address covectors. Values may
    be arbitrary exact SymPy expressions. No eta/Gram is inserted into the
    canonical gauge pairing and no Riesz conversion is applied to covectors.
    """
    architecture=read(HERE/'frozen_a10_bv_master/primary.json')['architecture']
    Q=mat(architecture['C3_to_plane_field'])
    potential=read(HERE/'frozen_a10_cotangent_adapter/primary.json')['potential_covectors']
    assert set(gauge_plane)=={(a,mu) for a in IDS for mu in range(4)}
    assert set(kinetic)==set(DIM)
    assert set(ordered_potential)=={row['term_id'] for row in potential}
    result={}
    for mu in range(4):
        parent=Q.T*s.Matrix([gauge_plane[a,mu] for a in IDS])
        result.update({f'JB{a}_{mu}':s.expand(v) for a,v in enumerate(parent)})
    for sec,n in DIM.items():
        value=s.Matrix(kinetic[sec]);assert value.shape==(n,1)
        adapter=Adapter(sec)
        for term in potential:
            raw=ordered_potential[term['term_id']];assert set(raw)==set(DIM)
            value+=adapter.pullback(raw[sec])
        result.update({f'Jx_{sec}_{i}':s.expand(v) for i,v in enumerate(value)})
    assert len(result)==508 and all(not v.has(s.Float) for v in result.values())
    return result
