"""Source-degree integration using authenticated columns and typed Euler ASTs."""
from a10_bv_integration_common import *

def build(stage=lambda n,f:f()):
    from audit_a10_gauge_euler import authenticate
    dependency=stage('authenticate_seven_sealed_dependencies',authenticate)
    types=stage('freeze_canonical_integration_types',contract)
    physical=stage('bind_complete_contracted_physical_Euler_columns',physical_columns)
    data,columns=stage('decode_authenticated_source_only_columns',source_data);w=algebra()
    complete={n:{'source_only':rows(P),
                 'physical':physical['canonical_source_slots'].get(n)} for n,P in sorted(columns.items())}
    assert len(complete)==1286
    from a10_bv_integration_physical import build as physical_cross
    cross=stage('physical_source_cross_and_source_degree_zero_master',lambda:physical_cross(stage))
    master=stage('literal_source_degree_one_master_and_boundary',lambda:source_master(columns,w))
    if master['density_minus_divergence']:
        return {'status':'STOP_EXACT_MASTER_RESIDUAL','master':master,'full_master_equation_established':False}
    fields,failed=stage('all_643_field_nilpotence',lambda:field_nilpotence(columns,w,stage))
    return {'schema':'A10_INACTIVE_STAGE_D_INTEGRATION_PRIMARY_V1',
        'contract':types,'dependency_authentication':dependency,'physical_Euler_program':physical,
        'complete_columns':complete,'field_nilpotence':fields,'first_failure':failed,
        'physical_cross':cross,'source_degree_one_master':master,
        'source_only_polynomial_sha256':digest(data['source_polynomial']),
        'status':'STOP_EXACT_FIELD_NILPOTENCE' if failed else 'PASS_BOUNDED_INACTIVE_STAGE_D_GAUGE_SCALAR_BV',
        'full_master_equation_established':not bool(failed),'full_source_nilpotence_established':not bool(failed),
        'source_nilpotence_certificate':{
            'all_643_sources':'source-only square follows from exact source-degree-one master divergence and graded Jacobi; physical additions cancel by the 643 explicit cross checks and 45 off-shell Noether identities',
            'all_1286_generators':'Q^2 F=1/2 ((S,S),F); Euler of the displayed master divergence is zero',
            'source_degree_two_and_higher':'absent: S0 has no sources and S1 is linear in sources',
            'ordinary_jets':'Q commutes with every ordinary partial by prolongation, hence Q^2 D_I z=D_I Q^2 z for every symmetric jet; order cap raises',
            'expanded_source_squares_claimed':False,'EOM_used':False},
        'Stage_E_reached':False,'sources_activated':False,'adopted':False}
