# Scalar–ghost convention reconciliation

The frozen scalar sign is incompatible with the frozen connection convention.
A coherent **inactive field candidate** can be derived without fitting the
old failed coefficient. It passes the complete parent scalar ghost-pair
test: 990 pairs on all 328 scalar coordinates. This resolves the field-only
obstruction for that candidate, not for the unchanged M08 operation.

No replacement is adopted. The complete source action, nonminimal pairing,
master/ST identities and H-basic domain still require qualification and
external specialist review. HB1/C5 remain unauthorized, scientific authority
remains `34/39`, and `finite_C1_GS` remains null. The formal sequence blocker
in project_state.json is unchanged. The historical diagnostic
`M08_NONMINIMAL_BV_ARCHITECTURE_SCALAR_FORWARD_SQUARE_NOT_CLOSED` remains true
of the frozen rules; it is not silently cleared by an inactive candidate.

## The sign follows from local covariance

The [frozen normalization](frozen_normalization_orbit/N1_N4_coupling_normalization.json)
specifies `D=partial+g10*rho(A)`. The
[field seed](frozen_st_seed/S1_component_transformations.json) specifies
`Q A=partial C+g10[A,C]`, with `A=Abar+q+V` and `C=c+u`.
The certified physical matrices satisfy `[rho_a,rho_b]=C^k_ab rho_k`.
These are the inputs, rather than choices made after examining Q squared.

For a local group element `U=exp(g10*omega)`, take

```
eta' = rho(U^-1) eta,
A'   = U^-1 A U + U^-1 partial(U)/g10.
```

Here `rho(U)` denotes the group representation extending the Lie-algebra
matrices. Differentiating `rho(U^-1)rho(U)=I` gives
`partial rho(U^-1)=-rho(U^-1)(partial rho(U))rho(U^-1)`.
The derivative of U in `partial eta'` therefore cancels the inhomogeneous
connection term, leaving exactly `D' eta'=rho(U^-1)D eta`.
Infinitesimally this implies

```
delta A   = partial omega + g10[A,omega],
delta eta = -g10 rho(omega) eta.
```

This is a passive-coordinate convention. Equivalently, the active parameter
`theta=-g10*omega` gives `delta eta=rho(theta)eta` and
`delta A=[theta,A]-partial(theta)/g10`. That is also the orientation used by
the JCAT background grammar. The quantum BRST operation keeps Abar fixed;
the affine background symmetry is a different operation. They must not be
identified simply because both involve a connection.

The primary calculation checks local covariance as an exact free
noncommutative polynomial. If the matter variation has an unknown sign `s`,
the derivative-of-parameter term is `(s+1)g10*rho(partial omega)eta`.
It fixes `s=-1` before any candidate square is evaluated. With the old
`s=+1`, the complete residual is
`2*g10*(partial rho(omega)+g10[rho(A),rho(omega)])eta`, which is generally
nonzero. Constant-parameter potential invariance alone cannot detect this
local-derivative mismatch.

Changing only the scalar sign is not an invertible rewriting of the old
failed differential. It changes a defining rule and thus needs a versioned
authority decision. The earlier transport no-go results remain intact.

## Complete scalar and ghost checks

The candidate is

```
Q eta = -g10 rho(C) eta,
Q C   = -g10 [C,C]/2,
Q(FG) = Q(F)G + (-1)^parity(F) FQ(G).
```

For an ordered pair `a<b`, applying these rules twice gives
`g10^2*(C^k_ab rho_k-[rho_a,rho_b])*C^a C^b eta`, which is zero.
The raw positive representation map is unchanged. The physical generator
normalization is `(E_ab-E_ba)/sqrt(2)` throughout; the complex residual-H
frame is not treated as Euclidean.

| Exact test | Coverage | Result |
|---|---|---|
| Certified scalar H matrices and candidate square | All 66 H pairs, all 328 coordinates | Zero residual |
| Direct physical scalar reconstruction and square | All 990 parent pairs, all 328 coordinates | Zero residual |
| Pair sectors in the physical replay | 66 H/H, 396 H/heavy, 528 heavy/heavy | All retained |
| Tensor-to-canonical intertwining and kinetic pairing | All 45 generators, all four scalar sectors | Zero residual |
| Parent ghost square | All 45 ghosts; no selected-pair truncation | Zero residual |
| Total gauge-connection square | All 45 components at an arbitrary ordinary-derivative label | Zero residual |
| Derived R transformation | Full parent ghost algebra | `Q R=-g10[c,R]_H`; no heavy-cubic leakage |
| Heavy evaluation-dual Lie identity | All 66 H pairs on the 33-dimensional dual module | Zero residual |

The gauge calculation includes ordinary derivative ghosts, not only
spacetime-constant fields. Q commutes with ordinary differentiation; its
generator identities consequently extend to all ordinary jets by derivation.
This is not separate enumeration of infinitely many derivatives or a
ghost-number-two catalog. Factorized matrix identities cover complete
coefficients, not sparse samples of scalar coordinates.

The old witness remains exactly `+1`. Under the candidate, its two pieces
are `-1/2` and `+1/2`, and their sum is zero. The replay also reconstructs
that cancellation directly in the physical symmetric Phi tensor.
No EOM or IBP identification is used.

## Other fields, the VEV and physical action

The total connection and parent ghost rules already have the coherent
orientation. Their H/heavy projections give the corresponding quantum-vector
rules with inert Abar. Light antighost and auxiliary rules form the existing
nilpotent doublet `Q cbar=-lambda`, `Q lambda=0`.

For the heavy evaluation-dual antighost and auxiliary, let
`D_a=ad_a^T` in the qualified H/heavy frame. These matrices obey
`[D_a,D_b]=-C^k_ab D_k`. The completed field formulas

```
Q ubar   = -Lambda + g10 D(c)ubar,
Q Lambda = g10 D(c)Lambda + g10^2 D(R)ubar
```

square to zero by this identity, `Qc=g10*R-g10[c,c]/2`, and the derived QR.
In Q squared ubar, the two R terms cancel and the c/c terms cancel by the
anti-representation identity. In Q squared Lambda the remaining terms are
`g10^2*D(QR)ubar + g10^3*[D(R),D(c)]ubar`, which also cancel. This is a
factorized field-level proof, not a reconstruction of their source images.

A typed physical all-lowered f tensor in an orthonormal parent frame is not
the same array as upper-index bracket coordinates in the nonorthonormal
residual frame. Primal coordinates use the inverse basis map and evaluation
duals use its inverse transpose. The checks use that distinction. They do
not certify a new interpretation of every untyped f occurrence in the
seventeen-role source AST.

The shifted scalar is `eta=v+phi`. Keeping the expansion background v fixed
means `Qphi=-g10*rho(C)(v+phi)`, including the generally nonzero `rho(C)v`
term. It does not assert that the physical VEV is invariant under broken
generators. The representation, VEV coordinates and physical orbit are not
changed; only the candidate BRST orientation changes.

Kinetic covariance follows from the finite derivative identity and the
exact checks `rho_a^T+rho_a=0` in canonical real scalar coordinates.
For the potential, all 29 frozen AST coefficient directions (24 real and
5 complex, with their Hermitian completion) have been scanned. Every tensor
vector index is contracted exactly twice, and each field has its prescribed
tensor rank. On each such pair the two variations cancel by `h^T+h=0`.
This proves invariant-contraction compatibility with the candidate sign.
It reuses the frozen potential and real-compact tensor convention; it does
not expand the potential anew, redo its one-loop rank-34 closure calculation,
prove stability, or change a physical parameter. The abstract gauged
kinetic convention is checked; a complete interacting source/gauge-fixing
action and every generated vertex are not requalified here.

## Dependency impact and the next acceptance boundary

| Dependency | Consequence of adopting the candidate | Present status |
|---|---|---|
| Physical positive scalar representation, invariant tensors and potential coefficients | No change | Exact field checks above |
| Scalar forward rule, both light and heavy terms | Overall minus sign relative to frozen phi image | Inactive candidate only |
| `K_phi Qphi` source term | Scalar source coupling must be rederived under the declared bracket | Not changed or qualified |
| Reverse source images and composite chain rules | Recompute from one complete action, not a local sign patch | Outstanding |
| Goldstone/VEV gauge fixing and ghost vertices | Trace the changed inhomogeneous scalar image through the canonical gauge-fixing fermion | Outstanding |
| Nonminimal source partners and master/ST relation | Complete canonical pairing is still required | Free comparator only; interacting extension outstanding |
| H-basic structural calculus and its catalog descent | Must be established for the actual replacement, not inherited from this field test | Outstanding; HB1/C5 unauthorized |
| JCAT/T5 operator languages | No representation, parity, statistics, IBP or dimension contract is changed in this run | Immutable authority reused; no rebuild |
| Earlier scalar benchmark, loop and gauge-matching results | This test establishes no new failure or new phenomenological success | Unchanged; downstream dependence must be reviewed before reuse |

The next investigation should combine this explicitly derived field
orientation with the coherent graded variational convention and complete
nonminimal canonical pairing. Before any large construction, derive a small
interacting master action, verify its master/square relation, and trace
scalar/VEV gauge fixing. Then rederive every required M08 field/source image
and test the full Cartan/domain obligations. A source replacement or catalog
extension requires separate adjudication; it is not authorized by this result.

Specialist review must examine the finite active/passive dictionary, matrix
versus field-derivation Lie signs, the nonorthonormal primal/dual lift,
shifted-VEV convention, and complete nonminimal antifield bracket. No external
review has occurred. The standard references are
[Gomis, Paris and Samuel](https://arxiv.org/pdf/hep-th/9412228), sections 4 and
6–7, for BV/BRST consistency, and
[Ferrari](https://arxiv.org/html/1308.6802v3), sections 2–3, for graded
derivations and partial gauge fixing. Those frameworks motivate the review;
they do not independently certify these M08 coefficients.

## Reproduction, custody and authority

[Primary evidence](frozen_scalar_ghost_reconciliation/primary.json) uses
the certified scalar H matrices and independently qualified parent bracket.
[Replay evidence](frozen_scalar_ghost_reconciliation/replay.json) imports
neither the primary module/results nor SA10 matrices. It reconstructs all
45 physical generators, bracket coordinates and constrained symmetric,
five-form, vector and singlet actions directly through A3 embeddings. Both
outputs were frozen before comparison; the twelve H matrix hashes agree.

Algorithm and code-path independence hold within these declared routes.
Python/SymPy, the physical frame and convention assumptions are shared;
library/runtime independence, analyst blinding and external review are not
claimed. A valid tensor dictionary cannot establish the physics of the
chosen action by itself.

The [read-only audit](audit_scalar_ghost_reconciliation.py) regenerates the
new bounded artifacts byte-identically, rejects fifteen adversarial changes,
and freshly reproduces the historical scalar `+1`, source `-2i`/`+1`, and
free nonminimal `-box(u)` controls and their bounded successful comparators.
Those are separate controls, not one complete interacting M08 proof.
The [validation receipt](frozen_scalar_ghost_reconciliation/validation_receipt.json)
records actual regression/audit outcomes, unchanged scientific input hashes,
zero audit-time workspace/active-data mutation, and measured stage timings.
Fine-grained parse/cache/serialization timings remain uninstrumented.

No T5 reconstruction, GPU work, pole/projection read or unrestricted
repository-wide PASS is claimed. Historical custody remains a separate
unresolved condition with strict audit exit 2. This bounded result narrows a
mathematical convention problem; it is not evidence that Spin(10) describes
nature, a counterterm count, or a promotion of the formal scientific ledger.
