# Cubic primitive prerequisite: technical review

This reviews the prerequisite calculation only. The enclosing contract still
requires an independently calculated actual four-ghost pole. No candidate
is adopted, and no quantum restoration, measure cancellation or unification
conclusion follows from an exact local primitive.

The measured difference is an antisymmetric tensor on two heavy evaluation
dual slots and one full primal ghost slot. For each independent pair a<b,
left graded variation gives

    Q0(ubar_a ubar_b C_c)=-Lambda_a ubar_b C_c+Lambda_b ubar_a C_c.

Thus -D_ab,c times that monomial generates both required ordered components.
This proves the right section and its injectivity in the declared jet-free,
source-free sector. It does not eliminate additional closed generators in a
larger sector. An arbitrary adjustment to a measured quartic mismatch would
need separately justified types, invariance and coefficients.

The physical heavy dual and primal ghost maps are different. A raw C3
coefficient being imaginary does not refute reality: the qualified C3
conjugation exchanges complex coordinates. Both real-frame coefficients and
the transported qualified conjugation are checked. All twelve background H
operators act on the primitive before its full interacting image is accepted.
There are no primitive jets, so an arbitrary local H parameter introduces
no unexamined parameter-jet terms at this prerequisite.

[Ferrari, Eqs. 3.1-3.2 and 4.31](https://arxiv.org/html/1308.6802v3)
provides a primary literature comparison for an H-invariant ghost-number -1
gauge-fixing fermion and the cubic antighost structure. Its general argument
does not check this project's measured tensor or loop coefficients. The
project keeps its nonsymmetric coset and coupling conventions explicitly.

K0 must be the negative of the old stored subtraction primitive when forming
a candidate for the pole. Its complete Q image contains the already measured
auxiliary width and an R_H-dependent quartic term. Checking only Q0, or
discarding this earlier primitive, changes the candidate under investigation.
The canonical source-shift calculation therefore retains the whole new image
and the qualified joint current. Sources are external BV variables and their
source-free shifts leave the integrated field Berezinian unchanged.

The source shifts from K3 are nonlinear. Ordinary derivatives must include
product-rule cross terms: second derivatives of a quadratic source shift
contain two first-derivative factors as well as single second derivatives.
The explicit omission control distinguishes them. The general prolongation
rule is a derivation; the executable's order limit raises an error instead
of identifying higher jets with zero.

The earlier source polynomial includes fixed numerical OrbitPullback
coefficients with engineering dimension one. Their typed AST dimension
survives numerical evaluation. A field-only word-grade test fails on those
unchanged imported terms. That engineering precheck is preserved and excluded;
the new K0/K3 terms have dimensionless coefficient tensors and their grades
are checked directly. Coupling coefficient projections likewise remove their
specified monomial from BOTH operands. The failed mixed-unit comparison is
preserved, with its complete residual reproduced in the completed record.

The predicted quartet tensor is an exact consequence to be tested, not an
actual quantum measurement. The graph calculation must retain the ordinary
g^2 B^2 antighost/ghost quartic, all odd Hessian blocks, mixed inverses,
external splits, four Lorentz weights and distinct UV heat profiles. The
complete domain is 990 squared odd-pair slots, including light directions.
[Thomsen's discussion of quartic ghosts](https://arxiv.org/html/2404.11640v2)
concerns their first contribution at two loops when there are no external
ghosts. Here four ghosts are external; that statement does not exclude the
specified one-loop companion calculation.

Independent routes share immutable measured inputs, word arithmetic,
Python/SymPy and analyst. Primary derives the primitive by ordered pairs and
prefix variation; replay derives it by Euler contraction and chain-rule/source
substitution. This is computational independence within a solo project, not
outside endorsement or proof-kernel certification. The evidence receipt owns
executed checks. Historical custody remains exit 2/seven unresolved references.
