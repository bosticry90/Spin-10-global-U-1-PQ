# Solo technical review packet — typed E1 replacement

This packet follows `docs/SOLO_REVIEW_POLICY_V1.md`. It requires no reviewer recruitment or outreach and claims no external endorsement. Its evidence is independently constructed within the stated shared computational dependencies.

The result is `PASS_BOUNDED_E1_DERIVED_REPLACEMENT_NOT_HISTORICAL_EQUIVALENCE`. See `A10_E1_FERMION_RESULT.md`, the preregistered contract and `frozen_a10_e1_fermion` for the complete AST, coefficients, first variations, local Ward identities, negative controls and receipt. Historical A4-V2/A5-V2 and the 95c0be0 bare-pair failure remain frozen.

The decisive review questions and dispositions are:

| Question | Evidence and limitation |
|---|---|
| Are field/field and field/source pairings distinguished? | Exact embeddings, left sections, invariant bilinears and identity evaluation-source pairings in both chart records. |
| Is every fermion term translated, including the shifted vacuum and nonsymmetric coset? | All eight terms and 1,797 coefficients agree between indexed execution and physical-plane construction; cubic has 138 coefficients. |
| Is this historical equivalence? | No. The old nonminimal, shifted auxiliary and tensor/frame bindings remain underdetermined. The result is an explicitly different, derived replacement. |
| Were xi, eta_H or alpha fitted? | No. Xi and eta_H are declared real dimensionless widths, alpha=xi, with normalized coupling-free Stage D f. Numerical historical equivalence is not inferred. |
| Does constant-parameter covariance hide a local failure? | Heavy quantum and background local Wards, full background local Ward and omitted-q_H parameter-jet negative control retain derivative parameters. |
| Must the light fermion remain quantum-H invariant? | No. Its independently matched nonboundary quantum variation is the expected light gauge fixing; the full background Ward is zero. |
| Are gradients substituted for covectors? | Replay varies redundant physical coordinates first and pulls back by embedding transpose. All 691 Euler columns and 244 boundary coefficients match. |
| Does conjugation conceal a ghost adjoint assumption? | The tested conjugation is an antilinear real-structure automorphism of ordered products, not an unqualified reversing Hermitian adjoint. |
| Are witnesses inside their physical domain? | Heavy projector applied and checked. The earlier unprojected plane vectors are explicitly rejected. |
| Does this prove E2, quartic ghosts or an H-basic domain? | No. No full master transport or graded BRST application to Psi is performed. Those obligations remain separate. |

Published comparison: Ferrari's H-invariant heavy fermion and independent light fixing, including Eq. (4.31), in [*Partial gauge fixing and equivariant cohomology*](https://arxiv.org/html/1308.6802v3); quantum/background separation in [Thomsen, *A partially fixed background field gauge*](https://arxiv.org/html/2404.11640v2). Neither publication verifies this repository or proves equivalence to its historical artifacts.

After the bounded receipt is exported, `audit_a10_e1_fermion.py --fresh` reproduces all three routes read-only. Run with assertions, the pole-blind validation guard and bytecode disabled. Frozen predecessors, the 34/39 ledger and custody exit 2 with seven unresolved references must stay intact. A PASS permits proposing E2 on the replacement; it grants no downstream activation or quantum authorization.
