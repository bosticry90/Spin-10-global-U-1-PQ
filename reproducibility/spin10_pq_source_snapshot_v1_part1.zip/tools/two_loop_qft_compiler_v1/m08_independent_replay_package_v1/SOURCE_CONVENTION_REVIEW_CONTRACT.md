# Bounded source convention review

This investigation tests whether a coherent conventional BRST/BV source
calculus explains the two frozen M08 source obstructions. It does not replace
Sigma, any of its six source couplings or any of the 17 current images.
Historical custody recovery is a separate maintenance track, not a prerequisite
for independently deriving these controls.

## Task and stopping rule

| Required field | Binding |
|---|---|
| Physics decision enabled | Decide whether a source-convention replacement deserves a separately scoped M08 impact analysis; no threshold or unification claim. |
| Current blocker removed | None presumed. Investigate the source-formalism prerequisite of the unchanged C5 H-basic sequence blocker. |
| Why existing tools are insufficient | Replaying frozen M08 conventions cannot independently establish their semantic consistency. |
| Minimum new implementation surface | Small exact conventional and partially gauge-fixed models, a separate sign derivation and bounded historical-byte search. |
| Structure-preservation obligations | Source/field pairing, odd bracket, graded derivation, Lie and Cartan identities, nilpotence, physical action invariance and immutable M08 provenance. No equivalence map to a repaired full M08 is assumed. |
| Stopping condition | Stop at bounded comparator and candidate-sign adjudication. Do not construct or promote a replacement M08 calculus, H-basic cochains, differential matrices or catalogs. |
| What will be deleted or deactivated if this does not work | Activate nothing; preserve failed sign choices and exact witnesses as negative controls. |

## Independent conventional control

Use the non-Abelian SU(2) gauge algebra with structure constants
`f^a_bc = epsilon_abc`, coupling `g`, two adjoint bosonic matrices represented
by vectors `X,Y`, and the dimensionally reduced Yang-Mills polynomial
`S0 = (X cross Y)^2/4`. This is a finite generator-level gauge model, not a
replacement four-dimensional field theory or a quantum partition-function
calculation. Its ghost image is `s c = -g[c,c]/2` and its field image is
`s X = -g[c,X]`, likewise for Y. The left odd derivation obeys
`s(FG)=(sF)G+(-1)^parity(F) F(sG)`.

Sources are placed on the left: `S = S0 + sum_z z_source * s z`.
For an independent field z of parity p, define the odd bracket

`(F,G)_src = sum_z (-1)^p [ (d_r F/dz)(d_l G/dz_source)
                         -(d_r F/dz_source)(d_l G/dz) ]`.

This is the canonical BV bracket after the constant coordinate change
`z_star = (-1)^p z_source`; its inverse is the same sign change. The action
in canonical coordinates has source term `(-1)^p z_star*s z`. Thus the
bracket is fixed before testing, not chosen by fitting a residual.
Take `Q F = (S,F)_src`, a left odd Hamiltonian derivation. Derive both field
and source images from this single bracket and require `(S,S)_src=0` and
`Q^2=0` on every generator. For even S, the exact conversion rule is
`d_r S/dz = (-1)^p d_l S/dz`. Test deliberately replacing an odd field's
reverse source image by `+d_r S/dz` while retaining the same left derivation
and forward field images; this must be distinguished from a coherent change
to a right-acting differential.

## Partial gauge fixing control

Use `G=SU(2) x SU(2)`, `H=SU(2)_diagonal`, with generators h and m such that
`[h,h]=epsilon*h`, `[h,m]=epsilon*m`, `[m,m]=epsilon*h`.
Keep four adjoint vectors, two for each factor, so the gauge action is locally
faithful at a generic pair in each factor. Set
`c_left=c+u`, `c_right=c-u`, and derive the split ghost rules from the two
ordinary SU(2) BRST rules, rather than importing M08 images.
Keep `R=-[u,u]/2` derived. The intended normalization is
`Q c=g R-g[c,c]/2`, `Q u=-g[c,u]`, `Q R=-g[c,R]`.

Derive all minimal source images from the same odd bracket. Test the residual
Lie action and contraction `iota_a c_b=delta_ab`, with all minimal physical,
heavy-ghost and source generators horizontal. Require
`{iota_a,Q}=g L_a`, Lie closure, `[L_a,Q]=0` and anticommuting contractions.
Separately include the equivariant antighost/auxiliary pair
`Q bar=-Lambda-g[c,bar]`,
`Q Lambda=-g[c,Lambda]-g^2[R,bar]`,
These are comparator variables only. The initially preregistered trial
`iota_a Lambda=-g A_a bar` failed the Cartan identity on bar and is retained
as a negative control. Deriving contraction from the ordinary doublet
`b=Lambda+g[c,bar]`, `Q bar=-b`, `Q b=0`, gives
`iota_a b=g A_a bar`, hence `iota_a Lambda=0` in these *completed-Weil*
coordinates. This does not assign the same zero action to M08's differently
defined auxiliary. The trial failure and this coordinate derivation must both
be reported; the initial table is not treated as a successful prediction.

On the source-free Cartan model, set c to zero and require
`delta^2=-g^2 R_a L_a`, `delta R=0`. Use
`F=X1 cross Y1 + X2 cross Y2` and
`psi=bar_i*(F_i-xi*Lambda_i/2)`.
Test H invariance, a nonsingular local broken-generator gauge-fixing Jacobian
at `X1=Y1=e1, X2=Y2=e2`, `delta(S0-delta psi)=0`, and a nonzero quartic
ghost term at nonzero xi. This is a local algebraic gauge-fixing control;
global Gribov or path-integral equivalence is outside its authority.
Complete the comparator's nonminimal BV source system as a further bounded
check: derive all source images from the gauge-fixed action and require its
master equation, generator nilpotence and Cartan identities. These additional
comparator sources are not additions to M08's alphabet or catalogs.

## M08 comparison and independence

Only after the conventional controls are frozen, compare their source-derivative
semantics with the actual frozen M08 source-coupling AST, reverse-image code,
current images and physical residual-H matrices. Reproduce the unchanged
`-2i` and `+1` witnesses before testing a candidate on those isolated sectors.
A vanishing candidate residual there is not a full 17-image repair, source ST
certificate or arbitrary-operator basicness theorem. No old image is edited.

The primary route uses an explicit odd bracket and sparse exterior algebra.
Replay derives source signs separately by the field/source pairing and exact
representation commutators, without importing primary differential columns.
Shared Python, SymPy, mathematical assumptions and literature must remain
explicit; neither route is an external specialist review.

## Historical custody scope

Preserve all original recorded hashes. Search only relevant named source paths
in local reachable/ref-log Git history, registered ToE worktrees and identified
ToE backup/archive locations. Inspect remote refs read-only, without fetching,
pushing or creating another checkout. Do not scan unrelated project contents
or claim inaccessible backups have been searched. Raw byte matches alone earn
recovery; line-ending conversions are diagnostic, not replacement provenance.
All historical reads remain subject to the existing pole-blind path guard.

## Validation and authority

Require exact generator identities, meaningful wrong-sign controls, independent
sign replay, byte-identical new bounded evidence, unchanged scientific-input
hashes and zero audit-time workspace/active-data mutation. Use only bounded
audits, not T5 reconstruction or unrestricted repository-wide validation.
Keep formal authority `34/39`, M08 attempt 2 and Layer 6 unauthorized,
`finite_C1_GS=null`, and all existing scientific results immutable.

Primary references: [Gomis, Paris and Samuel, sections 4.2, 4.6 and appendix A](https://arxiv.org/pdf/hep-th/9412228),
[Ferrari, equations 2.35 and 3.15 through 3.33](https://arxiv.org/html/1308.6802v3),
and [Barnich, Brandt and Henneaux, sections 4 and 5](https://arxiv.org/html/hep-th/9405109).
These establish comparator conventions, not an automatic source extension of M08.
