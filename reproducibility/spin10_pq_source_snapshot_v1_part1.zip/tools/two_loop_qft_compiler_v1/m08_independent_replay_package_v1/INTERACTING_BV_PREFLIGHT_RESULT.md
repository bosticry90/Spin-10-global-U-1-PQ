# Interacting BV consistency preflight result

The corrected scalar orientation and complete nonminimal source pairing coexist in one coherent interacting continuum BV control. Two exact implementations agree on the complete actions and all 48 transformation images both before and after gauge fixing. The master equations hold as local functionals, and the differential squares to zero off-shell in the tested generating algebra.

This is an inactive four-dimensional SU(2) adjoint-Higgs comparator, not a full M08 repair. No Spin(10) action, source coupling, frozen transformation, catalog or scientific authority is changed. HB1/C5 remain unauthorized; formal authority remains 34/39 and finite_C1_GS remains null.

## One action and one bracket

The [preregistered contract](INTERACTING_BV_PREFLIGHT_CONTRACT_V1.md) binds a non-Abelian connection, a real scalar triplet with eta=(phi0,phi1,v+phi2), all three ghosts, antighosts and auxiliary fields, and a canonical source for every field component. There are 24 canonical pairs and 48 generators. The invariant density includes Yang-Mills interactions, the scalar covariant kinetic term and h(eta squared-v squared) squared/4. Couplings remain symbolic; neither g nor v is set to zero in the consistency tests.

The convention is D=partial+g A cross, QA=Dc, Qphi=-g c cross(v+phi), Qc=-g(c cross c)/2, Qbar=-b and Qb=0. Every reverse source image is an Euler derivative of the same master action, using the coherent left convention and z*=(-1)^p(z)J_z. No selected source coefficient is fitted.

Gauge fixing follows from psi=bar dot(div A-xi g(v_vector cross phi)-xi b/2). The source shift is the Hamiltonian flow U=exp(-ad_psi). Its inverse and all 48 differential-intertwining equations pass exactly. The action comparison is modulo an explicitly reconstructed divergence, not a dropped remainder.

## Exact results and their scope

| Test | Result |
|---|---|
| Complete primary/replay action and column comparison | Five action polynomials and all 96 columns agree exactly |
| Minimal master equation | All 48 Euler residuals zero; explicit divergence current reconstructed |
| Gauge-fixed master equation | All 48 Euler residuals zero; explicit divergence current reconstructed |
| Minimal generator squares | 48 exact zeros per route |
| Gauge-fixed generator squares | 48 exact zeros per route |
| Gauge-fixed first ordinary derivative squares | 192 exact zeros per route |
| Scalar derivative and curvature covariance | Exact; derivative-of-ghost terms retained |
| Invariant kinetic and quartic-potential densities | Pointwise invariant |
| Canonical gauge-fixing shift | Exact inverse, grades and all-generator intertwining |
| Primary exact assertions | 935, not independent discoveries |
| Fast regression suites | 108 passing tests, including 19 new tests |
| Adversarial evidence mutations | 19 rejected |

The half-master densities are not claimed to vanish pointwise: the minimal and gauge-fixed densities have 1,292 and 1,424 canonical monomials respectively. Both are exactly divergences. The current reconstruction uses polynomial scaling and integration by parts; it does not impose equations of motion. All auxiliary fields and sources remain present in the nilpotence tests.

Only base generators and every first derivative are separately square-tested in this comparator. Higher ordinary derivatives follow from the evolutionary prolongation identity Q D_I=D_I Q; no claim of separately enumerating every higher jet is made. The maximum encountered derivative order is four. A safety limit at six raises rather than declaring an out-of-range expression zero.

## Vacuum and Goldstone checks

The full shifted scalar term survives. At phi=0 its first two components transform as -g v c1 and +g v c0; the third has zero vacuum shift. The derived gauge mass-squared matrix is diag(g squared v squared,g squared v squared,0), and the scalar potential Hessian is diag(0,0,2 h v squared). The interpretation as two broken directions assumes nonzero g and v; the polynomial consistency identities do not require either to be nonzero.

For nonzero xi, completing the auxiliary square cancels the quadratic gauge/Goldstone kinetic mixing modulo a reconstructed current. Its quadratic ghost density is -xi g squared v squared(bar0 c0+bar1 c1), with the same overall sign as -bar box c. These are constant-vacuum Hessian diagnostics, not differential restrictions or an EOM quotient; the master and nilpotence tests retain the auxiliary and hold polynomially in xi. They are properties of this control model, not a recalculation of the Spin(10) benchmark.

Two diagnostic implementation errors were caught before final primary evidence was frozen: an initially positive expected ghost-mass sign contradicted Q(bar G)=-b G-bar QG, and a prefix-based auxiliary selector also selected antighost names. The final expectation follows the declared product rule; the selector now uses exact roles and has a dedicated regression. Neither correction changes the action or transformation rules. The independent word replay retains the same final mass term.

## Negative controls and historical evidence

Restoring the wrong positive scalar orientation produces an exact nonzero scalar square. Omitting the canonical antighost partner reproduces -box(c0) at g=0. Flipping its source sign changes the forward antighost image, rather than legitimately repairing the declared rule. Setting the new partner source to zero is not a Q-invariant restriction.

The historical -2i basic/source defect, +1 reverse-source square, -box(u) omitted-partner defect, +1 frozen scalar square and nonhorizontal Sigma witness remain unchanged. The fresh bounded audit replays the earlier small scalar/source/free-BV controls. The previous complete 990-pair scalar test and JCAT/T5 authorities are referenced by immutable evidence and hashes, not reconstructed or newly certified here.

## Independence and remaining M08 gate

The primary uses Euler differentiation in an exterior algebra over commuting exact polynomials. The replay separately assembles the model using ordered graded words and formal variational deletion, cyclic cross products and an independent monomial boundary reconstruction. It imports no primary action, columns or contraction table. Both outputs were frozen separately before comparison.

Algorithm and code-path independence are earned within that scope. Python, SymPy, the declared model and canonical-bracket assumptions are shared; library/runtime independence and analyst blindness are not claimed. External specialist review has not occurred. The conventional nonminimal and canonical-gauge-fixing precedent is [Gomis, Paris and Samuel, sections 4 and 7.2](https://arxiv.org/abs/hep-th/9412228); the distinct partial-gauge requirements are [Ferrari, sections 2 and 3](https://arxiv.org/abs/1308.6802). Neither reference verifies this implementation or supplies the missing M08 source map.

The control is an ordinary fully gauge-fixed theory. It is not an interacting partial-gauge/source-domain qualification. The earlier finite partial comparator, this continuum control and the complete M08 scalar representation cannot be combined by assuming their different hypotheses match. Full-M08 source expansion stops at that semantic review boundary; no seventeen-image replacement is derived or promoted in this run.

The [M08 review packet](INTERACTING_BV_M08_REVIEW_PACKET.md) identifies the next obligations: one declared partial-gauge master action, both nonminimal sectors, complete composite-R chain rules, the shifted VEV/gauge-fixing terms, evaluation-dual source maps and basic-domain preservation. It also identifies the prospective partners already inventoried upstream and why the old catalog cannot automatically classify an enlarged alphabet. No new full catalog is authorized.

## Release validation

The [release receipt](frozen_interacting_bv_preflight/validation_receipt.json) records fresh byte-identical primary and replay regeneration, complete polynomial agreement, 19 rejected adversarial mutations, 108 passing regressions and four passing targeted governance audits. All 102 bounded-run bindings were verified, including 34 scientific inputs; inherited bounded-run digests were retained unchanged. This does not authenticate the seven unresolved original historical references. The project-state digest remains d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8.

Workspace and active-data metadata inventories (file size and nanosecond modification time, excluding .git) agree before and after the fresh audit across 126,987 files; bound inputs are additionally checked by SHA-256. This is zero detected audit-time mutation, not a claim that every unbound catalog byte was rehashed or regenerated. No T5 reconstruction was performed. The final report/receipt edits occur after that read-only audit; follow-up hash checks reuse its completed mathematical evidence rather than claim another full run.

The fresh historical controls reproduce the earlier small scalar, source and free-BV results, including the 2,004-assertion source comparator and its finite partial-gauge control. The previous full 990-pair scalar result is reused by immutable evidence, not rerun. The strict historical custody audit separately returns exit 2 for seven unresolved references. Repository-wide --all was unnecessary and was not run; no unrestricted validation PASS or new guarded D5-stop event is claimed.

## Measured performance

| Profiled stage | Wall seconds | CPU seconds |
|---|---:|---:|
| Primary model and minimal/gauge-fixed Euler columns | 3.87 | 3.83 |
| Primary base and first-jet squares | 215.84 | 215.14 |
| Primary master equations and divergence reconstruction | 90.91 | 90.67 |
| Primary canonical gauge fixing | 25.70 | 25.61 |
| Primary negative controls | 1.88 | 1.88 |
| Word replay Euler columns | 0.34 | 0.33 |
| Word replay squares | 46.47 | 46.34 |
| Word replay master and boundary reconstruction | 12.79 | 12.77 |
| Word replay canonical shift | 1.05 | 1.05 |
| Fresh historical controls | 28.66 | 28.52 |

Peak working set for the audit process was 178,946,048 bytes, about 179 MB. Measured stages report zero OS write-transfer bytes. These are stage measurements, not the entire development runtime or isolated stage memory peaks. Parsing, normalization, serialization/hash time, file-operation counts, cache hits/misses and worker utilization were not separately instrumented. The two routes also perform different algorithms and some different assertions; their timings are not a universal backend speedup or a full-M08 forecast. The measured cost here is exact polynomial work, not evidence for introducing a GPU backend.

Stop after this bounded adjudication. No H-basic dimensions, C5 differential/rank/cohomology, EOM quotient, C6/D6/E, M08 attempt 2, Layer 6, loop payload, C1_GS or gauge refit is reached. The physical unification verdict is unchanged.
