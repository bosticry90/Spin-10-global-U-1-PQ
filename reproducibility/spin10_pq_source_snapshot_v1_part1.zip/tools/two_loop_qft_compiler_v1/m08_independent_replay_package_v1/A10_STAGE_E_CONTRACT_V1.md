# Inactive Stage E: partial-gauge architecture and transport

The owner's assessment of `f7d5868` authorizes a bounded Stage E attempt in the gauge/scalar system. Authenticate and reuse Stage D and its 643 canonical pairs. No fermions, Yukawa terms, source activation, catalog replacement, HB1/C5, quantum matching, authority changes or remote push are authorized. The solo-review policy applies; no outreach or external endorsement is required or claimed.

## Ordered gates and first stop

E1 binds the actual A4-V2/A5-V2 fermions to the Stage D field/source charts, their grading, Lorentz contractions, internal tensor pairings, vacuum orbit and the 12-generator residual H action. E2 transports the complete master action, sources and operations canonically. E3 separates quantum and background transformations. E4 verifies nonminimal/composite chains and quartic ghosts. E5 qualifies a useful joint H-basic domain on local functionals modulo ordinary divergences. E6 independently replays decisive evidence. Stop at the first failed identity or essential underdefinition; later gates are conditional.

The current A5-V2 divergence is already covariant with respect to the total H connection. Do not substitute the obsolete ordinary-derivative A5-V1 into this investigation. Neither a small preflight control nor the successful Stage D heavy auxiliary map identifies the historical nonminimal fermion coordinates automatically.

## E1 coordinate prerequisite

The qualified prospective maps explicitly record `historical_nonminimal_AST_identified=false`. Stage D uses dual-heavy `ub` and `L`, primal light `bar` and `b`, and direct canonical evaluation sources. The historical A5-V2 AST contains a bare component contraction `-xi ubar_H Lambda_H/2`. The qualified evaluation bracket is not the internal invariant bilinear form on two dual-heavy fields. A coordinate decoder for source couplings does not settle this different contraction.

First recover the exact historical fermions and the reserved chart identification. If that identification remains underdefined, stop E1 and preserve an exact diagnostic of direct label reuse. This diagnostic is a rejected identification, not an assertion that every possible interpretation of the historical AST is defective. Deriving a full new typed fermion after the stop requires a subsequent bounded decision.

## Preregistered decisive diagnostic

Take the entire auxiliary bilinear of A5-V2 under the proposed direct label identification `ubar_H=ub`, `Lambda_H=L`. Use all 33 dual-heavy coordinates and all 12 H generators; no symmetric-coset truncation. Write `D_h[i,j]=f[j,h,i]` with the normalized Stage D structure constants. Then `T ub=g10 D_h omega_h ub`, `T L=g10 D_h omega_h L`. Independently compute the full auxiliary Ward coefficient matrix by graded Leibniz variation and by physical 10x10 commutators plus first variation of a bilinear.

Check its Euler derivative, not only a displayed nonzero density. All other heavy-fermion summands contain a gauge connection, scalar fluctuation, or heavy ghost; the light fermion contains a light antighost or light auxiliary. Derive the selected auxiliary monomial before projection and exclude all possible cancellations in this channel. Constant H parameters already suffice. Do not use equations of motion, an auxiliary elimination, source-zero differential restrictions or fitted coefficients.

As a separate mathematical control derive the inverse-Gram pairing from the physical dual embedding. Verify its invariance for all 12 generators. This control tests the distinction between internal dual pairing and canonical evaluation; it does not replace A5-V2, qualify the cubic/orbit terms, or earn E2-E5. Include a witness on real physical-frame input directions, respecting the parent conjugation chart.

## Evidence and validation

Primary consumes authenticated Stage D structure coefficients and applies a left even derivation to the auxiliary polynomial. Replay reconstructs H-heavy commutators from normalized physical antisymmetric matrices and derives the matrix first variation without importing primary output. Both share physical assumptions, Python/SymPy and the analyst. Freeze outputs separately, compare exact coefficients including implicit zeros, reproduce the minimal witness, and reject adversarial false PASS claims.

Read-only routes run under the pole-blind guard, with writes blocked by an audit hook. Authenticate all eight predecessor chains, retain the historical action and negative controls, regenerate new outputs byte-identically, and compare selected byte hashes and workspace/active-data size/mtime metadata. Metadata checks are not an all-byte repository audit. Formal authority remains 34/39; strict custody exit 2 with seven unresolved references remains unresolved. Validate the bounded stop evidence, commit locally and stop.
