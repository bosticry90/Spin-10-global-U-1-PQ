# E5 next-order source-free primitive and complete inactive image, V3

V1/V2 remain in force. Both completed universal-image routes agree before
residual access. The completed V2 comparison covers91,125 slots and finds the
entire888-term real physical residual antisymmetric (symmetric part zero)
for both xi^2 and xi eta_H. No primitive has been fitted/adopted yet.

AA4 prospectively constructs the unique aaC primitive for this projected
residual using the ALREADY derived right section, not arbitrary coefficients:

    Delta = g10^2 sum_ijk D_ijk Aux_i a_j C_k,
    K4 = -g10^2 sum_(i<j,k) D_ijk a_i a_j C_k
       = -(g10^2/2) sum_i a_i Euler_Aux_i(Delta/g10^2).

Freeze this contract, new image/runner/export code and completed algebra/
comparison input hashes before execution. Primary uses ordered upper pivots;
replay uses the Euler/Koszul contraction. Both transport to the unchanged
raw dual-antighost/primal-ghost charts. The support must be all-heavy; no
unmeasured sector is discarded. Derive COMPLETE QK4 from all relevant literal
E2 Q columns and independently from the full retained source action's direct
variation under its Hamiltonian source translation. Keep all g^3 quartet
descendants and prove all H-ghost cancellations from the full expression.
Do not invoke a projected M-adjoint Jacobi identity.

Check grade(3,-1,odd), raw/physical roundtrips, qualified conjugation, all12
local background H identities and every one of1286 canonical generators.
K4 is source-free/no-jet: fields stay fixed, sources shift by graded Euler
columns; prove both exact inverse directions, all elementary pairings, first
jet prolongations, nonzero wrong-source-sign/second-jet omission controls,
and integrated-field Berezinian1 (sources external). This is a separate exact
source translation; do not claim an exact finite combined inverse for the
old source-dependent normalization or quantum A5. Old regulated measure stays.

Only after both completed K4/full-Q images agree does dependent normalization
open the previously unique complete candidate. Add K4 and QK4 with the old
boundary current retained. Compare the complete new g^2 auxiliary image to
the measured residual, all91,125 slots and coupling monomials. Prove zero new
source/derivative/width/kinetic projections, unchanged g^2 xi^2 quartet and
all earlier g^0/g^1 matched orders. Preserve the entire resulting inactive
generator/candidate and the new COMPLETE g^3 quartet prediction, clearly
classified as a prediction rather than an actual calculation. Wrong sign,
wrong g degree and quartet omission must give exact nonzero controls.

First necessary type/sign/frame/canonical/H/real/matching failure stops with
complete source/start/failed evidence; no dependent new actual loop runs.
No actual derivative-gauge, g^3 quartet/auxiliary or other-source amplitude
is calculated here. Successful construction remains an inactive local
one-loop Hamiltonian-image candidate, not adopted subtraction/restoration.

Validation now requires SIX fresh strict exact-start/own-byte executions:
original algebra-primary/replay, V2 admissibility comparison, image-primary/
replay and dependent normalization. Preserve original execution bytes and
all unexecuted/failed source classifications, all36 predecessor chains,
protected/new/state hashes and metadata, custody2/seven, raw Git bytes.
No original scientific acceptance obligation is reduced. The whole Spin(10)
x global U(1)PQ goal stays active/incomplete atv113/34 of39. No physical/catalog/
HB1/C5/C1_GS/matching, quantum A5/fullE5/Ward/IR/anomaly, authority promotion,
external outreach/publication/push or independent-scientist claim.
