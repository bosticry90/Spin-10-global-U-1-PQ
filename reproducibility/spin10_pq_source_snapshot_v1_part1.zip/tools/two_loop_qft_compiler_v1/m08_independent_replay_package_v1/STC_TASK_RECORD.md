# STC bounded source transport and extension preflight

Resume custody: `353ab9a`. This execution concerns the source/composite
obstruction only. The minimal polynomial basic calculus is retired as an
intended C5 architecture. All upstream action, image and catalog evidence
remains immutable.

## Task header

| Field | Binding |
|---|---|
| Physics decision enabled | None; decide whether the proposed source calculus can be repaired by equivalent transport or an acyclic extension. |
| Current blocker removed | Test M08_C5_H_BASIC_SOURCE_CARTAN_SIGN_OBSTRUCTION, without presuming a solution. |
| Why existing tools are insufficient | Source-free Kalkman equivalence does not establish the source Cartan identities. |
| Minimum new implementation surface | Bounded exact obstruction replay, conjugacy theorem, non-source comparator and abstract source-extension consistency equations. |
| Structure-preservation obligations | Exact source/ST information, inverse transport, evaluation-dual pairing, derived R, grading, locality and original evidence custody. |
| Stopping condition | Adjudicate the bounded transport class and extension feasibility; never construct catalogs, HB1 or differential matrices. |
| What will be deleted or deactivated if this does not work | Activate nothing; retain failed candidates and exact obstruction evidence. |

## Calculation record

| Field | Binding |
|---|---|
| Scientific question | Can an exact equivalent presentation on the existing alphabet remove the source/composite basicness obstruction? |
| Claim under test | Transported B preserves a transported, provably equivalent cochain domain containing the transported F_R. |
| Scope and authority ceiling | Bounded source/Weil sector, no physical or formal-authority advancement; 34/39. |
| Frozen inputs and assumptions | Current 17 images, right/left convention, six couplings, Sigma, derived negative BR, evaluation-dual H action, C4, JCAT/T5 and weight grading. |
| Primary method and tool | Current source-image AST, exact split-frame tensors, conjugacy/descent identities and abstract generator equations. |
| Independent replay decision and reason | Action right-derivative and physical matrices, plus independently coded exterior-polynomial equations; no primary coefficients imported. |
| Known-limit and physical-assumption checks | Verify a source-free abelian Kalkman comparator; distinguish global background action, Cartan action and restricted historical ST authority. |
| Adversarial checks and falsifiers | Opposite source sign is a rejected repair; rescaling and invertible basis changes must not erase a nonzero defect. Test necessary nilpotence/curvature equations before any extension claim. |
| Provenance and comparators | Bind existing source AST and frozen frame. Ferrari 1308.6802 equations 2.59-2.66 are external comparator conventions only. |
| Failure interpretation | Failure of the preregistered source-cochain equivalence/extension class, not a Spin(10), catalog or historical ST-zero failure. |
| Result and reproducibility record | Freeze primary and replay separately before comparison; timing observations are not scientific artifacts. |
| Stopping rule | No new source generators in the project alphabet, full transported catalogs, cochain dimensions, differential matrices, EOM, H0, GPU or later stages. |

## Preregistered transport class

The class consists of exact local invertible algebra automorphisms U of the
existing polynomial source/Weil algebra, finite on the bounded sector, with
an exact inverse. They preserve parity, residual-H representation content,
canonical-dimension filtration and ghost grading (or an explicitly invertible
transported grading), introduce no independent symbol or physical parameter,
and keep R derived. All source information and the functional ST structure
must be transported. A bracket may be conjugated, not discarded.

For equivalent transport of the existing domain, require
B_T=U B U^-1, L_T=U L U^-1 and iota_T=U iota U^-1. A different Cartan
description must provide an explicit invertible chain equivalence on the
cochain domain, intertwining B and admitting U F_R. Merely replacing the
basic domain by all invariants is not such an equivalence. Test the identity
iota_T B_T U F_R = U(iota B F_R) before solving any ansatz coefficients.
This exhausts equivalent transports of the rejected domain, not all possible
new definitions of equivariant source cohomology.

## Preregistered extension feasibility tests

If transport is obstructed, derive abstract chi_alpha,b=iota_alpha Lc_b
with degree (-1,-1), without registering a new source. Require Lie covariance,
anticommuting contractions and the Cartan identity {iota_alpha,B}=g10 L_alpha
on the obstruction sector, or exhibit an explicitly different consistent
identity before claiming success. Keep B on old generators unchanged.

Test both nilpotent full-Weil closure and the historical curvature-only
equivariant closure on the R=0 slice. Any such extension must reproduce old
B squared on the old algebra. Do not assume the old ambient source algebra
was historically certified nilpotent. A contradiction on that slice excludes
these extensions without enumerating a source tower. If no contradiction is
found, derive the contraction tower and an actual contracting homotopy before
calling an extension acyclic. Otherwise report only necessary module grades
and recipe bounds, not a qualified extension or changed cohomology.

Primary uses frozen AST signs and coordinate brackets. Replay uses the actual
source action/right derivative and physical 10x10 matrices. An independently
coded exterior calculation tests the decisive source equations. Both routes
share Python/SymPy and frozen inputs; no library/runtime independence claim.
