"""Indexed source AST -> finite graded execution -> one-pass Euler columns."""
from copy import deepcopy
import sympy as s
from a10_bv_common import *
from a10_executable_action import Executor, contract, numeric_table
from m08_local_functional_ast import add,mul,scalar,field,derivative,tensor,parameter

def contraction(n,inds):
    result=contract(n,inds);result['parity']=n.get('parity',0);return result

def build_source_ast():
    C=lambda a:field('C',indices=(a,),parity=1)
    B=lambda a:field('B',indices=(a,'mu'))
    f=lambda a,b,c:tensor('StructureConstant','f_parent',(a,b,c))
    gp=parameter('g10')
    QB=add(derivative('mu',C('a')),contraction(mul(gp,f('a','b','c'),B('b'),C('c')),('b','c')))
    QC=contraction(mul(scalar(s.Rational(-1,2)),gp,f('a','b','c'),C('b'),C('c')),('b','c'))
    terms=[('source_gauge',contraction(mul(field('JB',indices=('a','mu'),parity=1),QB),('a','mu')))]
    for sec in SECTORS:
        Qx=contraction(mul(scalar(-1),gp,tensor('RepresentationGenerator','rho_'+sec,('a','i','j')),
                            C('a'),field('x_'+sec,indices=('j',))),('a','j'))
        terms.append(('source_'+sec,contraction(mul(field('Jx_'+sec,indices=('i',),parity=1),Qx),('i',))))
    terms.append(('source_ghost',contraction(mul(field('JC',indices=('a',)),QC),('a',))))
    ub=lambda i:field('ub',indices=(i,),parity=1)
    L=lambda i:field('L',indices=(i,))
    # f(j,h,i) acts on the evaluation-dual heavy carrier, hence the transpose.
    shift=contraction(mul(gp,tensor('StructureConstant','f_mHm',('j','h','i')),C('h'),ub('j')),('h','j'))
    Qub=add(mul(scalar(-1),L('i')),shift)
    R=contraction(mul(scalar(s.Rational(-1,2)),tensor('StructureConstant','f_Hmm',('h','a','b')),
                      C('a'),C('b')),('a','b'))
    QL=add(contraction(mul(gp,tensor('StructureConstant','f_mHm',('j','h','i')),C('h'),L('j')),('h','j')),
           contraction(mul(gp,gp,tensor('StructureConstant','f_mHm',('j','h','i')),R,ub('j')),('h','j')))
    terms.extend([('source_heavy_antighost',contraction(mul(field('Jub',indices=('i',)),Qub),('i',))),
                  ('source_heavy_auxiliary',contraction(mul(field('JL',indices=('i',),parity=1),QL),('i',))),
                  ('source_light_antighost',contraction(mul(scalar(-1),field('Jbar',indices=('h',)),field('b',indices=('h',))),('h',)))])
    result=[{'node':'LocalActionTerm','term_id':name,'density':n,'parity':0} for name,n in terms]
    assert len(result)==9 and all(n['density']['parity']==0 for n in result)
    return result

class GradedExecutor(Executor):
    """Same finite index rules as the physical executor, with graded products.

    Strip only redundant parity metadata at the old even-only entry point.
    Actual Grassmann multiplication and differentiation retain the alphabet's
    parity. Reject any field leaf whose declared parity disagrees with it.
    """
    def eval(self,n):
        if n['node']=='Field':
            table=self.tables[n['name']]
            for P in table.values():
                for word in P:
                    assert sum(self.a.p[name] for name,_ in word)%2==n.get('parity',0)
        clean=dict(n);clean['parity']=0
        return super().eval(clean)

def compile_source(w,f,rho,ast):
    tables={};x={n:w.var(n) for n in w.p}
    for prefix in ('B','JB'):
        tables[prefix]={(a,mu):x[f'{prefix}{a}_{mu}'] for a in IDS for mu in range(4)}
    for prefix in ('C','JC'):tables[prefix]={(a,):x[prefix+str(a)] for a in IDS}
    for sec,n in DIM.items():
        for prefix in ('x_','Jx_'):tables[prefix+sec]={(i,):x[f'{prefix}{sec}_{i}'] for i in range(n)}
        tables['rho_'+sec]={}
        for a,R in enumerate(rho[sec]):tables['rho_'+sec].update(numeric_table(w,R,(a,)))
    for prefix,ids in [('ub',M),('L',M),('Jub',M),('JL',M),('bar',H),('b',H),('Jbar',H)]:
        tables[prefix]={(i,):x[prefix+str(i)] for i in ids}
    tables['f_parent']={key:{():v} for key,v in f.items()}
    tables['f_mHm']={key:{():v} for key,v in f.items() if key[0] in M and key[1] in H and key[2] in M}
    tables['f_Hmm']={key:{():v} for key,v in f.items() if key[0] in H and key[1] in M and key[2] in M}
    e=GradedExecutor(w,tables)
    components=[]
    for node in ast:
        output=e.eval(node);assert output.labels==();components.append(output.rows.get((),{}))
    return w.add(*components)

def build(stage=lambda name,fn:fn()):
    from audit_a10_cotangent import authenticate
    dependencies=stage('authenticate_qualified_dependencies',authenticate)
    f,rho,Q=stage('primary_C3_geometry',geometry_primary)
    arch=stage('canonical_architecture',lambda:architecture(Q));w=algebra()
    ast=build_source_ast()
    S=stage('graded_indexed_source_AST_execution',lambda:compile_source(w,f,rho,ast))
    assert w.grade(S,(4,0,0))
    columns=stage('all_source_action_left_Euler_columns',lambda:source_columns(S,w))
    for z,J in w.pairs:
        d,gh,p=w.grades[z];assert w.grade(columns[z],(d+1,gh+1,1-p))
        d,gh,p=w.grades[J];assert w.grade(columns[J],(d+1,gh+1,1-p))
    return {'schema':'A10_INACTIVE_CANONICAL_BV_PRIMARY_V1','architecture':arch,
        'source_AST':ast,'source_polynomial':rows(S,w),'source_only_columns':{n:rows(P,w) for n,P in sorted(columns.items())},
        'source_nonzero_coefficients':len(S),'dependency_authentication':dependencies,
        'full_columns_recipe':'QJ=source_only_column+physical Euler for B,x; all other columns source_only; physical scalar Euler uses qualified cotangent adapter',
        'geometry':{'f':[[*key,str(v)] for key,v in sorted(f.items())],
                    'rho_digests':{sec:[digest(record(R)) for R in rho[sec]] for sec in SECTORS}},
        'status':'PARTIAL_CANDIDATE_STOP_GATE_3_GAUGE_EULER_TRANSLATION',
        'master_equation_checked':False,'source_nilpotence_checked':False,'heavy_canonical_transport_extended':False,
        'Stage_E_reached':False,'sources_activated':False,'adopted':False}
