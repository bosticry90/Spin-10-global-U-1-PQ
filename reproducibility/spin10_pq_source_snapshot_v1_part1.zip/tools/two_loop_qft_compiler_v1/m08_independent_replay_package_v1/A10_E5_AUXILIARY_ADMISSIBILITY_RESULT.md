# E5 next auxiliary source-free primitive and complete inactive extension

Disposition: `QUALIFIED_NEXT_AUXILIARY_SOURCE_FREE_PRIMITIVE_AND_COMPLETE_INACTIVE_EXTENSION_ONLY`.
The preceding g^2 auxiliary mismatch admits a source-free cubic primitive.
Both constructions and complete Q images agree. Adding this image repairs
all91,125 next auxiliary slots and preserves every previously measured source,
kinetic, mixing, width, cubic and g^2 quartet scope. The result remains
inactive; no adopted subtraction, quantum A5 or full E5 is claimed. Sole
authority project_state.json staysv113, 34/39 and SHA
`d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8`.
Original Spin(10) x global U(1)PQ goal remains active/incomplete.

## Source-free image theorem before residual access

V1 froze the local source-free polynomial domain: generator grade(3,-1,odd),
nonnegative coefficient dimensions, no inverse physical coupling/mass or EOM
quotient, all643 canonical pairs and48 backgrounds unchanged. Complete type
census and all643 qualified field Q columns show that aL and aaC are the only
carriers reaching a derivative-free auxiliary–antighost–ghost density.
Qa0=-Aux in all45 directions. Qa1/QAux1 single-ghost terms use only C_H;
curvature QAux2 cannot reach this cubic. Other field Q columns never supply
an auxiliary. Jets/positive coefficient dimensions cannot reach this target.

For k in M, Q0(a_i a_j C_k)=-Aux_i a_j C_k+Aux_j a_i C_k. The full image
therefore has32,670 distinct signed upper pivots in66,825 heavy-ghost slots,
with34,155 symmetric complementary slots. Primary enumerates all columns;
replay derives the Euler/Koszul homotopy. Both completed outputs agree before
the actual residual is opened. This is a complete projected source-free image,
not a full source-dependent or H-invariant normalization classification.
The source-dependent diagonal shear control explicitly prevents that inference.

After exact all91,125-slot comparison, the entire saved real residual D is
antisymmetric:888 physical /276 raw words, symmetric part zero. Both xi^2
and xi eta_H are retained; their raw counts are256 and276 respectively.
No component is fitted by ignoring its companion or a zero slot.

## Determined primitive and full descendants

V3 froze the already derived right section before constructing a correction:

    K4 = -g10^2 sum_(i<j,k) D_ijk a_i a_j C_k
       = -(g10^2/2) sum_i a_i Euler_Aux_i(sum D_ijk Aux_i a_j C_k).

Primary uses upper pivots; replay uses the homotopy. K4 has444 physical and138
raw canonical words, is real in the qualified dual-antighost/primal-ghost
charts, and obeys all12 local background H identities. The full Q image,
independently derived from the retained source action's first variation,
has924 raw words:276 g^2 auxiliary words and648 g^3 quartet words. The new
quartet image has3,960 physical slots; H-ghost coefficients cancel only after
the complete Q calculation. No projected M-adjoint Jacobi identity is used.

The exact separate canonical source translation shifts66 sources and fixes
all643 integrated fields. All1,286 generators,2,572 inverse checks, every
elementary pairing and264 first-jet checks pass. Wrong source sign and missing
second-jet cross terms give nonzero exact controls. Its integrated-field
Berezinian is1 because sources remain external. The old regulated joint
measure is retained. This does not prove a finite combined inverse or quantum
equivalence for the older source-dependent flow.

Dependent normalization opens the previous complete candidate only after full
new-image agreement. New source/derivative/kinetic/width projections vanish,
allg^0/g^1 orders and980,100 old quartet slots are unchanged. The complete
next auxiliary pole now matches. Complete inactive generator/candidate remain
506/54,823 canonical words (their coefficients acquire new coupling orders).
The full total g^3 quartet prediction has966 raw words, including inherited
contributions. It is NOT an actual g^3 calculation. Wrong primitive sign,
wrong g degree and omission of the new quartet give complete nonzero controls.

## Execution, provenance and validation

Baseline8657da8; input frozen_a10_e5_auxiliary_next/bindings.json and36
predecessor chains. All worker starts freeze source/contract/input/state hashes
and completed dependency hashes. Outputs have exclusive ownership; workers
are read-only under the established pole-blind guard. No old expensive actual
loop,125 shear-space image or source calculation is rerun.

V2's exact Rational(1,2) projector was frozen after a pre-comparison inspection
identified floating zero from Python literal division. The V1 comparer never
executed; its exact source stays classified unexecuted, not PASS or scientific
failure. No floating coefficient is rounded or rationalized. Image-primary
attempt1 failed because the inherited quartet projector's ghostP alphabet
was not registered. Its source/start/stdout and FAILED disposition remain;
the corrected attempt registers all45 odd ghosts before the projector. No
failed attempt is counted as qualified image work.

Receipt obligations: targeted scientific/process/governance checks, existing
research_check.py e5 delegate, all36 protected chains, new/state SHA and
audit-time metadata, and SIX strict fresh own-byte starts/results: both
universal algebras, V2 comparison, both complete images and normalization.
Custody stays expected exit2/seven unresolved references, never PASS. Check
raw Git-index/worktree bytes before local commit. Evidence validation and
scientific scope/director acceptance remain distinct.

Shared immutable inputs, Python3.10.11/SymPy1.14.0, exact arithmetic and analyst
are disclosed; two derivations are not independent scientists or external
endorsement. Existing solo-review policy and epistemic ladder apply:
provenance explicit, verification bounded to stated images/matches,
formalization not attempted, mechanism compression within the doublet sector,
interpretation restricted to an inactive normalization, empirical connection none.

No new actual loop ran here. Derivative-gauge, higher quartet/auxiliary and
other-source amplitudes, full quantum A5/E5/Ward/contact/IR/anomaly, global
scalar/PQ and fermion/Yukawa/phenomenology remain open. No physical/catalog/
HB1/C5/C1_GS/matching, authority promotion, outreach/publication/push.

Next smallest authorized scientific action: freeze the actual derivative-gauge
companion contract against this complete inactive member, retaining every
coupling/reference-width/graded contribution and its full IBP current. The
next g^3 quartet prediction also needs its own actual calculation. First
mismatch stops; no normalization adoption or physical gate is unlocked.
