# Local residual gauge and Cartan closure reconciliation contract

Physics decision enabled: decide whether the existing interacting SU(2)-to-U(1) source control admits the required local Cartan interpretation before completing the bridge or proposing an M08 replacement.

Current blocker removed: only the small bridge's global-versus-local closure ambiguity, if earned. Scientific gate status does not change automatically.

Why existing tools are insufficient: the previous contract omits the derivative of the local curvature parameter on the unfixed connection. Its global contraction identities do not establish a local source-extended Cartan square.

Minimum new implementation surface: one bounded local-action derivation, a separate ordered-word replay, a read-only audit, tests and frozen evidence. Reuse the existing 22-pair control; do not add generators, change its action, or reconstruct a large catalog.

Structure-preservation obligations (maps only; otherwise explain N/A): derive the local gauge cotangent lift in the existing canonical bracket. Preserve the evaluation pairing and bracket, statistics and derivative prolongation. Distinguish independent-parameter substitution after variation from field-dependent substitution before variation. If the bridge gates are reached, require canonical gauge-fixing inverse, action equality modulo explicit divergence and all-generator intertwining. No M08 dual/basis map is certified.

Stopping condition: stop at the first failed exact local/source closure gate. Localize and independently replay that counterexample, including the two parameter-substitution conventions, but do not repair the domain, delete a source, impose equations of motion or proceed to the unreached master/nilpotence/gauge-fixing gates. Preserve historical failures. Implementation mistakes are distinct from mathematical gate failures and must be disclosed.

What will be deleted or deactivated if this does not work: the candidate remains inactive and cannot authorize a full-M08 reconstruction, HB1/C5 or catalog use. Retain the failed equation and its evidence.

## Frozen model and authority

Use unchanged `partial_gauge_bv_bridge.setup()` from commit 2b18510: physical 4D Minkowski metric, SU(2) epsilon012=+1, H=U(1) along e2, eta=phi+v e2, D=partial+g A cross, QA=DC, Qphi=-g C cross eta, QC=-g C cross C/2, R=-C0*C1. Retain both coset antighost/auxiliary pairs, completed-Weil auxiliary rule, all 22 canonical field/source pairs and the source J_C2. No light nonminimal doublet is introduced because H remains unfixed.

Use the unchanged canonical bracket, left odd product rule and zstar=(-1)^p Jz. Each reverse source image is an Euler derivative of Smin or S=Smin+Qmin psi. No source coefficient is fitted. Canonical dimensions and ghost numbers remain those already declared. The safety jet bound raises; it never truncates.

## Derive the independent local parameter action first

Let omega(x) be an independent, even, dimension-zero, ghost-number-zero test parameter, with arbitrary ordinary jets and Q omega=0. It is not a new physical field, source, coupling or catalog symbol.

Derive from the finite U(1) transformation with the retained connection convention:

```
T_omega A2,mu = partial_mu omega
T_omega X = -g omega (e2 cross X)
```

The second line acts on coset connections, eta, parent ghosts, coset antighosts and completed auxiliaries, with neutral components zero. The VEV v e2 is fixed by H, not discarded. Extend through ordinary derivatives as an evolutionary action. Derive sources by the evaluation-dual/cotangent lift, not by representation names.

The odd Hamiltonian density is

`G_omega = -sum_z (-1)^pz Jz T_omega z`.

Require `(G_omega,z)=T_omega z`; derive `(G_omega,Jz)` from Euler variation and compare the expected dual pairing. This is a canonical local action with an independent parameter. Verify the elementary bracket derivation equations. Bind the exact moment/current relation to the unchanged source action, accounting explicitly for integrations by parts.

Define local contraction iota_omega(C2)=omega, all other independent contractions zero, and prolong through jets. Require `{iota_omega,Q}=T_omega` and `[T_omega,Q]=0` on all 44 generators, plus the unchanged global identities. This tests local derivatives of omega without inferring them from the global table.

## Local Cartan square gate

Define delta exactly as before by removing C2 and its jets from operator coefficients on the other 43 generators, including J_C2. This is not a Q-stable C2=0 quotient.

First compare delta squared to `T_omega|omega=-gR`, where the independent-parameter cotangent/source variation is performed **before** substitution. Test every required base generator, then every first ordinary derivative if all base tests pass. This is the precise meaning of the proposed local residual transformation with a composite parameter. No source-zero restriction is permitted.

Separately distinguish the canonical field-dependent Hamiltonian `G_omega|omega=-gR`, varied **after** substitution. It can generate additional chain-rule source terms because R depends on coset ghosts. On the first failing source sector, compute this second action as a bounded diagnostic, not as an automatic replacement for the preregistered identity. If neither action reproduces the square, freeze both discrepancies. Do not suppress a term proportional to a moment/Ward generator by declaring a relative quotient that has not been authorized.

Preserve the old connection result delta squared A2,mu=-g partial_mu R and its source-paired nonzero Euler witness. Explicitly evaluate the product with J_A2,mu, including the source action, rather than dropping a derivative or invoking EOM.

## Conditional bridge continuation

Only if the complete local/source square passes, resume the previously unreached gates: both master identities modulo reconstructed currents, Q squared on all generators and specified jets, canonical partial gauge fixing, local H Ward invariance, generic nonzero quartic ghost structure, and preservation of the explicitly defined local-invariant/horizontal functional domain. Derive domain preservation structurally; bounded examples are controls, not a substitute. Freeze independent outputs before comparing complete actions/columns. A success with abelian H and a symmetric coset does not qualify non-Abelian residual-H M08.

## Custody and stop boundary

Require byte-identical bounded regeneration, independent decisive replay, meaningful negative controls, inherited SHA256 expectations unchanged, authority coherence, structure-preserving-map and read-only audits, and zero detected audit-time workspace/active-data mutation. Record wall/CPU time and process peak memory, and identify unavailable fine-grained telemetry. No GPU or large reconstruction.

Use the existing pole-blind guard. Broader --all only if necessary; a denied forbidden D5 read is GUARDED_ALL_VALIDATION_STOPPED_AT_FORBIDDEN_LEGACY_POLE_READ, never unrestricted PASS. Historical custody exit 2 remains unresolved unless authentic evidence closes it independently.

No M08 action/source/image edits, new catalog, HB1/C5, EOM quotient, ranks, cohomology, M08 attempt 2, later gates, Layer 6, finite C1_GS or authority increment. Formal authority stays 34/39. External specialist review remains outstanding; prepare questions but do not contact anyone automatically. Commit locally, do not push, and stop after this bounded adjudication.

The local connection comparator is motivated by [Ferrari equations 5.16–5.17](https://arxiv.org/html/1308.6802v3#S5), which include the residual covariant derivative. It does not supply or certify this source lift. Canonical source semantics follow the declared project bracket, not a fitted reading of a literature sign.
