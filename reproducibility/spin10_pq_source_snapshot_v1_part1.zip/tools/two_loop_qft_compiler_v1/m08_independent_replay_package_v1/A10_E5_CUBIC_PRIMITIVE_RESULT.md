# Inactive H-compatible cubic primitive and frozen quartet prediction

Scope: the prerequisite under the enclosing cubic-primitive/four-ghost
contract. The result is a local inactive generator and its derived prediction;
the actual four-ghost pole and enclosing contract remain incomplete. The
validation receipt and byte seal own qualification of the completed evidence.
Baseline f7f6054, state v113/34of39 unchanged, 30 predecessor chains reused.

The complete measured actual-minus-joint difference admits the declared
primitive. All 49,005 tensor slots, including zeros, satisfy antisymmetry.
The physical primitive has 444 monomials, and its Q0 image reproduces all
888 nonzero difference entries exactly. Dual-heavy/primal-ghost roundtrips,
the qualified real structure, grade (3,-1,1) and all twelve local background
H identities pass in both calculations.

In common hbar/(32*pi^2*epsilon) pole units,

    K3=-g*xi^2 sum_{a<b,c} D_ab,c ubar_a ubar_b C_c,
    Q0 K3=g*xi^2 sum_{a,b,c} D_ab,c Lambda_a ubar_b C_c.

This primitive is unique only in the declared no-source/no-jet two-heavy-
antighost/one-ghost sector. Additional closed generators outside that sector
are not excluded. No generator is adopted or inserted into the frozen action.

The complete candidate combines the already qualified joint generator, K3
and K0, the pole generator for the old width subtraction. The sign of K0 is
the negative of the archived subtraction primitive. Its full interacting Q
image retains the R_H-dependent quartic. The complete canonical generator
has 270 C3 monomials, and the candidate density has 48,283 coefficients.

Independent direct source variation agrees with the new Q images. All 1,286
new canonical columns are checked; source-free additions leave fields fixed
and shift 99 external source components. The joint boundary current is
retained, with zero additional current. There are 396 first source-jet checks
and an explicit nonzero second-jet cross-term omission control. The new image
grade is (4,0,0); inherited coefficient dimensions reuse the qualified E1/E2
typed AST, including numerical OrbitPullback coefficients of dimension one.

The previously matched source, ghost kinetic, gauge/auxiliary mixing and
width projections are preserved. The total selected cubic equals the
measured pole. At the earlier real witness the added coefficient is
8*sqrt(10)/25, restoring the measured 48*sqrt(10)/25 in the declared units.
This repairs the selected algebraic prediction; it does not establish a
complete quantum normalization or cancel the regulated field Berezinian.
The new source-free generators only shift external sources, and the prior
joint field measure remains an explicitly reused dependency.

The g^2*xi^2 quartet prediction has 4,944 nonzero physical odd-pair slots over
the complete 990^2=980,100 domain. Light-direction slots are exactly zero in
this prediction. The actual amplitude may not be restricted on that basis.
For example, physical antighost pair (12,13) and ghost pair (12,13) has
predicted coefficient -16/25 after factoring g^2*xi^2. The full sparse tensor
and C3 density are retained in each route record. No actual quartet loop has
been evaluated or compared here.

Primary uses the ordered antisymmetric right section and prefix Q variation;
replay uses Euler contraction and the independent gradient/source chain
rule. Each reads its own sealed cubic measurement. Complete result records
agree, apart from route labels. The existing cubic loops and earlier expensive
science are authenticated dependencies, not fresh calculations. The receipt
owns fresh own-byte reproduction, bracket/source checks, mutation controls,
test counts, protected/state/new hashes and audit-time metadata checks.

Negative controls reverse the primitive sign, remove a primitive coefficient
from its H action, omit K3 from the cubic, omit K0/R_H from the quartet, and
omit nonlinear jet cross terms. They produce explicit nonzero residuals.
One deliberately canceled generic-inversion attempt and two failed engineering
prechecks are preserved with their exact source and logs. The prechecks used
an unweighted grade on imported dimensional coefficients and mismatched
coupling-factor units, respectively. They are excluded from qualified
evidence; the complete mixed-unit residual is reproduced in the final record.
The original interrupted drafts remain byte unchanged. No silent evidence
repair or replacement of failed/unfinished attempts occurred.

Shared immutable data, word arithmetic, Python 3.10.11, SymPy 1.14 and analyst
remain disclosed. The [technical review](A10_E5_CUBIC_PRIMITIVE_TECHNICAL_REVIEW_V1.md)
compares the structure with primary literature and identifies the independence
boundary. This is solo computational review, with no external endorsement.
Historical custody remains exit 2/seven unresolved references, never PASS.

The next dependent action is to screen the complete literal quartet graph
inventory and calculate all actual g^2*xi^2 four-ghost poles by the sparse
graded Born and independent full Gaussian/Schur routes. Include ordinary
g^2 B^2-ghost triangles, all anomalous odd blocks, mixed/Gram/Lorentz factors,
external splits and distinct box/triangle/bubble heat profiles. Stop on the
first failed required identity and preserve a real Euler witness if matching
fails. JC-C-C/JB-B-C loops remain stopped pending that reconciliation.

No full E5/A5/restoration, finite/IR/anomaly, activation/catalog/HB1/C5/C1_GS,
matching, physical change, authority promotion, outreach, publication or push.
Global boundedness, PQ quotient, fermion/Yukawa and phenomenology remain open.
The whole Spin(10) x global U(1)PQ investigation remains active/incomplete.
