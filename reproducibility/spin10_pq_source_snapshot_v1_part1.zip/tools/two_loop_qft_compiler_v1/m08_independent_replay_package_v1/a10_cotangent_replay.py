"""Independent value-Jacobian/polynomial replay, no indexed-Euler imports.

Reconstructs physical aliases from the qualified real basis states. Direct
epsilon differentiation of literal action polynomials is the potential oracle.
Kinetic Euler coefficients follow differentiation of the free bilinear form,
IBP, and matrix transpose; no scalar field configuration is substituted.
"""
from itertools import combinations,permutations
from hashlib import sha256
import json
from pathlib import Path
import sympy as s

HERE=Path(__file__).resolve().parent
SECTORS=('Phi','Sigma','phi','S')
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def digest(x):return sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def parity(p):
    cycles=0;seen=set()
    for i in range(len(p)):
        if i in seen:continue
        cycles+=1;j=i
        while j not in seen:seen.add(j);j=p[j]
    return (-1)**(len(p)-cycles)

def jacobians():
    from execute_a3_scalar_geometry import canonical_real_basis
    basis=canonical_real_basis();ordered={};positions=list(combinations(range(10),5))
    cert={};embeddings={}
    for sec in SECTORS:
        local=[v for v in basis if v.sector==sec];rows={sec:[]} if sec=='Phi' else {sec:[],sec+'Bar':[]}
        d={'Phi':100,'Sigma':504,'phi':20,'S':2}[sec];E=s.zeros(d,len(local))
        for j,v in enumerate(local):
            if sec=='Phi':
                for i in range(10):
                    for k in range(10):
                        z=v.state.Phi[i,k]
                        if z:rows[sec].append([[i,k],j,str(z)]);E[10*i+k,j]=z
            else:
                values=v.state.Sigma if sec=='Sigma' else {(i,):s.expand_complex(z).as_real_imag() for i,z in enumerate(v.state.phi)} if sec=='phi' else {():s.expand_complex(v.state.S).as_real_imag()}
                for address,(re,im) in values.items():
                    idx=positions.index(address) if sec=='Sigma' else address[0] if sec=='phi' else 0
                    E[idx,j]=re;E[d//2+idx,j]=im
                    z=re+s.I*im
                    if not z:continue
                    rank=5 if sec=='Sigma' else len(address)
                    for order in (permutations(range(rank)) if sec=='Sigma' else [tuple(range(rank))]):
                        t=tuple(address[k] for k in order);value=s.expand(parity(order)*z)
                        rows[sec].append([list(t),j,str(value)])
                        rows[sec+'Bar'].append([list(t),j,str(s.conjugate(value))])
        rows={key:sorted(v) for key,v in rows.items()};ordered[sec]=rows
        cert[sec]={key:{'nonzero_coefficients':len(v),'sha256':digest(v)} for key,v in rows.items()}
        embeddings[sec]=s.SparseMatrix(E)
    return cert,embeddings

def polynomial_differential(term):
    epsilon=s.Symbol('epsilon');serial=0;variables={};params={};bound=set()
    def evaluate(n,env):
        nonlocal serial
        kind=n['node']
        if kind=='ExactScalar':return s.sympify(n['value'])
        if kind=='Parameter':
            v=s.Symbol('parameter_'+n['name'],real=True);params[v]=n['name'];return v
        if kind=='Field':
            indices=tuple(env.get(i,i) for i in n['indices']);name=n['name']
            key=(name,indices)
            if key not in variables:
                k=len(variables);variables[key]=(s.Symbol('value_'+str(k)),s.Symbol('tangent_'+str(k)))
            value,tangent=variables[key];return value+epsilon*tangent
        if kind=='LocalActionTerm':return evaluate(n['density'],env)
        if kind in ('GroupContraction','LorentzContraction'):
            assert kind=='GroupContraction'
            local=dict(env)
            for i in n.get('contracted_indices',n.get('summed_indices',())):
                local[i]='index_'+str(serial);serial+=1;bound.add(local[i])
            return evaluate(n.get('expression',n.get('argument')),local)
        if kind=='Add':return sum(evaluate(v,env) for v in n['terms'])
        if kind=='OrderedProduct':return s.prod(evaluate(v,env) for v in n['factors'])
        raise ValueError(kind)
    F=evaluate(term,{})
    differential=s.expand(s.diff(F,epsilon).subs(epsilon,0))
    tokens={v:(name,indices) for (name,indices),(v,h) in variables.items()}
    tokens.update({h:('h_'+name,indices) for (name,indices),(v,h) in variables.items()})
    result={}
    for monomial in s.Add.make_args(differential):
        coefficient=1;fields=[];parameters=[]
        for factor in s.Mul.make_args(monomial):
            base,power=factor.as_base_exp()
            if base in params:parameters.extend([params[base]]*int(power))
            elif base in tokens:fields.extend([tokens[base]]*int(power))
            else:assert not factor.free_symbols;coefficient*=factor
        live={i for _,inds in fields for i in inds};assert live<=bound
        # Each monomial arises from one original contraction branch; all
        # binder variables present in that branch occur in its tensor slots.
        candidates=[]
        for order in permutations(fields):
            names={};canonical=[]
            for name,inds in order:
                addr=[]
                for i in inds:
                    if i not in names:names[i]=len(names)
                    addr.append(names[i])
                canonical.append((name,tuple(addr)))
            candidates.append(tuple(canonical))
        key=(tuple(sorted(parameters)),min(candidates));result[key]=s.expand(result.get(key,0)+coefficient)
    packed=[[list(p),[[name,list(i)] for name,i in f],str(s.simplify(v))] for (p,f),v in sorted(result.items()) if v]
    return {'term_id':term['term_id'],'differential_graph_coefficients':packed,
        'canonical_directional_oracle':'physical basis aliases Y=Jx and variation H=Jh; epsilon derivative of literal polynomial F(Y+epsilon H)',
        'no_field_values_substituted':True}

def kinetic_words():
    # Universal bilinear algebra: d(1/2 u^T u)=u^T du, with u=p+g Kx.
    # Direct differentiation yields p momentum u and x covector g K^T u.
    # Ordinary IBP replaces hdot^T u by -h^T partial(u)+partial(h^T u).
    g=s.Symbol('g');K,Kt,Kdot,X,P,DD=s.symbols('K Kt Kdot X P DD',commutative=False)
    momentum=P+g*K*X;force=g*Kt*momentum
    total_derivative=DD+g*Kdot*X+g*K*P
    Euler=s.expand(force-total_derivative).subs(Kt,-K).expand()
    expected=-DD-g*Kdot*X-2*g*K*P-g**2*K*K*X
    assert s.expand(Euler-expected)==0
    return {'noncommuting_matrix_Euler':str(Euler),'kernel_coefficients':[-1,-1,-2,-1],
        'kernel_order':['Box x','g rho(partial B)x','g rho(B)partial x','g^2 rho(B)rho(B)x'],
        'boundary_current':'h^T D^mu x','spacetime_weights':[1,-1,-1,-1],
        'scope':'free skew-matrix ring in any finite dimension; all 45-generator matrices specialized by authenticated representation data',
        'Euler_pullback':'constant J^T commutes with every ordinary jet and integration by parts'}

def witness(E):
    t,m=s.symbols('t mSigma2',real=True);z=E[:,0]*t
    density=0;gradient=0
    for i,I in enumerate(combinations(range(10),5)):
        value=z[i]+s.I*z[252+i]
        if not value:continue
        for order in permutations(range(5)):
            v=parity(order)*value
            density-=m*v*s.conjugate(v)/120
            # Differentiate the two ordered complex aliases, then their
            # physical canonical Jacobians. Each permutation is included.
            gradient+=(-m*s.conjugate(v)/120)*s.diff(v,t)+(-m*v/120)*s.diff(s.conjugate(v),t)
    assert s.expand(gradient)==s.diff(s.expand(density),t)==-2*m*t
    return {'density':str(s.expand(density)),'direct_derivative':str(s.diff(s.expand(density),t)),
        'adapter_derivative':str(s.expand(gradient)),'omitted_measure_derivative':str(s.expand(gradient/120)),
        'ordered_nonzero_components':240,
        'blind_120_arbitrary_covector_negative':{'correct_first_component':str(E[0,0]),'incorrect_first_component':str(120*E[0,0])}}

def masses(embeddings):
    result={}
    for sec,E in embeddings.items():
        if sec=='Phi':
            # Direct differentiation of trace Phi^2, from each basis column.
            H=s.SparseMatrix(E.cols,E.cols,{(i,j):-2*s.trace(s.Matrix(10,10,list(E[:,i]))*s.Matrix(10,10,list(E[:,j])))
                for i in range(E.cols) for j in range(E.cols)})
        else:
            # F=-m sum_s z_s zbar_s, with ordered Sigma measure already
            # exhausted by all 120 permutations of each sorted component.
            H=-2*E.T*E
        coefficient=-2 if sec in ('Phi','Sigma') else -1
        assert H==coefficient*s.eye(E.cols)
        payload={'shape':list(H.shape),'entries':[[int(i),int(j),str(v)] for (i,j),v in sorted(H.todok().items()) if v]}
        result[sec]={'canonical_mass_covector_coefficient':coefficient,
            'symbolic_rule':str(coefficient)+' * m'+sec+'2 * x_'+sec,
            'all_coordinates':E.cols,'Hessian_sha256':digest(payload),
            'ordered_measure_included':120 if sec=='Sigma' else 1}
    return result

def build(stage=lambda name,fn:fn()):
    jac,embeddings=stage('physical_basis_all_ordered_alias_Jacobians',jacobians)
    act=read(HERE/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json')
    pot=stage('direct_epsilon_differentiation_all_29_literal_potential_polynomials',lambda:[polynomial_differential(t) for t in act['local_terms'][5:]])
    return {'schema':'A10_CANONICAL_COTANGENT_ADAPTER_REPLAY_V1','status':'PASS_BOUNDED_ADAPTER_ONLY_INACTIVE',
        'ordered_Jacobians':jac,'potential_differentials':pot,
        'kinetic':stage('universal_noncommuting_kinetic_Euler_and_boundary',kinetic_words),
        'five_form_witness':stage('ordered_polynomial_240_component_witness',lambda:witness(embeddings['Sigma'])),
        'all_coordinate_mass_covectors':stage('direct_basis_mass_Hessians_all_328_coordinates',lambda:masses(embeddings)),
        'independence':'no primary adapter, graph normalizer or indexed Euler operation imported; basis states and literal frozen action shared authorities',
        'shared_limitations':'same analyst, Python/Sympy runtime, representation and action assumptions; no external endorsement',
        'complete_master_action_constructed':False,'source_activation':False,'Stage_E_reached':False,
        'candidate_adopted':False,'formal_authority':'34/39_UNCHANGED','C1_GS':None}
