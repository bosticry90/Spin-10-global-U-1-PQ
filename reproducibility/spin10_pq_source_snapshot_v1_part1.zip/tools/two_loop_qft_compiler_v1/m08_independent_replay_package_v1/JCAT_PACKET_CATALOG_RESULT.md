# JCAT8–JCAT12 bounded local-operator catalog

JCAT8–JCAT12 pass under the frozen C5.1 bounds. The promoted object is
`M08_JCAT3_JCAT12_JOINT_PERMUTATION_LORENTZ_IBP_CATALOG_V1`.
The next blocker is `M08_C5_COMPLETE_LOCAL_FUNCTIONAL_COMPLEX_PENDING`.
Execution stops before C5; no differential, EOM quotient or cohomology is built.

## Exact counting ledger

| Space or relation | Dimension / coverage |
|---|---:|
| Immutable expansion signatures | 431 |
| Ordered expansion coordinates | 369,980 |
| Realization-null directions | 1,356 |
| Realized tagged directions | 368,624 |
| Covariant tagged packet directions | 359,524 |
| Exact packet IBP relation rank | 2,132 |
| Post-IBP tagged quotient | 357,392 |
| Final statistics-allowed local operators | 54,148 |
| Parity-even final operators | 54,033 |
| Parity-odd final operators | 115 |

The final dimension is that of the bounded local-operator catalog, not a
counterterm count, a set of new tree couplings, or a cohomology dimension.
The original 431 signatures remain expansion provenance; a packet or final
operator can span several of them.

## What was qualified

JCAT8 acts jointly on internal covectors, Lorentz indices, derivative placements
and signature provenance before realization and packet projection. All 362
classes and 2,524 active carrier/copy blocks close exactly. Coxeter, independent
species commutation, realization descent and conjugation diagrams pass.
The 478 frozen internal recoupling factors retain their exact conjugation
compatibility. Five replay cases reconstruct selected actions without importing
the primary packet matrices, including the largest affine packet block (18).

JCAT9 constructs the complete ordinary total-derivative image, applies the
qualified realization, and intersects that image with the covariant packet
span. The frozen boundary rule does not require the generating current itself
to be covariant: its divergence must be admissible. This retains legitimate
parity-odd transgression relations. The exact support census proves that
ordinary field content, derivative grade, parity and constant internal
carrier/copy tensors keep each relation inside its declared connected block
at these bounds; this is checked, not assumed from JCAT7's partition.
Six replay controls use ordinary colored current words and literal Leibniz
prolongation, independently of the primary relation matrices. Every IBP map
has an exact section and preserves permutation and conjugation descent.

JCAT10 stores the full quotient representation by carrier/copy orbits,
exact local stabilizer matrices and coset transport: 293 reusable patterns.
Exact characters reconstruct every Young decomposition. The largest quotient
and largest Young-multiplicity roles coincide; a second explicit coset-matrix
route verifies their characters and exact central-idempotent ranks.

JCAT11 projects the complete packet/IBP quotient, not either tensor factor
alone. Bosonic species use the trivial character and Grassmann-odd species the
sign character. Background connections are not projected again. The actual
finite basis is stored as exact allowed local columns with coset transport,
not just dimensions. An independent coset-trace census reproduces every final
block count without importing JCAT11 projector coefficients or JCAT10 characters.
The Yang–Mills-style regression proves that antisymmetric internal times
antisymmetric jet survives; a nonzero one-negative-factor S2 input is killed.
The positive direction is explicitly transported into the certified packet
quotient. It is not assumed to exhaust that block's other allowed directions.

JCAT12 checks complete original-address coverage, exact quotient/projection
matrices, all finite operator IDs, source selectors and conjugation/parity
metadata. Seven addressed reconstruction controls span the largest final
class, affine/null ancestry, joint gauge structure, parity-odd, Grassmann,
source and auxiliary sectors. The evaluator returns an exact local density
representative modulo IBP with its original expansion coefficients. Tags in
that serialization retain provenance; final identical-field algebra is
enforced by the species statistics projector.

## Independence and custody

The packet-action replay uses complete colored tensor polynomials and exact
coefficient solves; it is not a second numerical sampling of four-dimensional
components. The IBP route independently prolongs current words. Young replay
uses explicit induced matrices and idempotent ranks rather than the primary
character inner products; statistics replay independently sums coset traces.
These are algorithm/code-path checks with shared carrier/dual data, the
Lorentz normalizer and Python/SymPy. No new library/runtime independence is
claimed. JCAT7's already-qualified direct physical controls remain immutable.

No canonical INT3/INT6 basis, INT7R, INT8, realization relation or JCAT7 packet
is changed. Lossless selector/coset recipes and compact JSON replace verbose
unqualified provenance serialization; receipts retain its old hashes and
inverse recipes. This avoids a dense global map and keeps the new generated
tranche below 100 MiB, with every individual file below 10 MiB.

## Validation and authority ceiling

`JCAT_PACKET_CATALOG_VERIFICATION.json` binds the reproducible generators,
scientific sources, exact artifacts and read-only audits. Release qualification
requires byte-identical regeneration, bounded audits and zero workspace-file
mutations. Repository-wide validation is attempted only through the existing
pole-blind guard. Denied historical D5 access is recorded as
`GUARDED_ALL_VALIDATION_STOPPED_AT_FORBIDDEN_LEGACY_POLE_READ`, not unrestricted
validation PASS and not a scientific calculation FAIL.

Formal authority remains `34/39`; `UVP_M08` remains BLOCKED attempt 1.
Attempt 2 and Layer 6 remain unauthorized, E remains NOT_EXECUTED, and
`finite_C1_GS` remains null. C5, C6, D6, E, M09–M13 and C1_GS are not executed.
`DISTANCE_TO_C1_GS = ONE_GATE_REMOVED` is project-management metadata only.
This is implementation qualification, not evidence of Spin(10) viability.
