# A10 canonical scalar cotangent adapter: bounded result

The ordered-complex-to-canonical-real adapter passes the separately authorized
five gates for the inactive executable action at `4315518`. The historical
factor-120 diagnostic is reproduced and its missing conversion is now supplied
as a typed mathematical operation. This qualifies a prerequisite for proposing
the next Stage D calculation. It does not construct or qualify a complete BV
master action, resume Phase C, enter Stage E or activate sources.

Contract: [A10_COTANGENT_ADAPTER_CONTRACT_V1.md](A10_COTANGENT_ADAPTER_CONTRACT_V1.md).
Evidence: [primary](frozen_a10_cotangent_adapter/primary.json),
[independent replay](frozen_a10_cotangent_adapter/replay.json),
[scalar source composition](frozen_a10_cotangent_adapter/source_composition.json),
[validation receipt](frozen_a10_cotangent_adapter/validation_receipt.json).
All predecessor definitions and evidence remain unchanged.

## Typed conversion and its inverse domain

For a differential, the pairing is bilinear: `dF = W^T dy`. A raw ordered
complex tensor derivative is a covector. It is not an ambient Riesz vector.
For each independent sorted five-tuple `I`, form

\[
 \widehat W_z(I)=\sum_{\pi\in S_5}\operatorname{sgn}(\pi)W_z(\pi I),
 \qquad
 \widehat W_{\bar z}(I)=\sum_{\pi\in S_5}\operatorname{sgn}(\pi)W_{\bar z}(\pi I).
\]

Then `alpha_Re = W_hat_z + W_hat_zbar` and
`alpha_Im = i*(W_hat_z - W_hat_zbar)`. Repeated-index components vanish upon
pullback. For phi and S the same Wirtinger conversion has measure one. Phi
uses its complete ordered real matrix covector. The scalar canonical output is

\[
 \alpha_x=E^T\alpha_y,
 \qquad r_y=G^{-1}\alpha_y,
 \qquad E^T G r_y=\alpha_x.
\]

The metrics are identity for Phi and sorted real Sigma, and twice identity for
physical Re/Im phi and S. Inserting an already converted covector into `E^T G`
would double the last two sectors. The new API exposes the two operations
separately. Conjugation is a separate real-structure map; the transpose in a
differential pairing is not replaced with conjugate transpose.

`E^T G E=I` gives a right section `alpha_y=G E alpha_x`. Its ordered complex
section is `(alpha_Re-i alpha_Im)/(2m)` and its conjugate-alias partner
`(alpha_Re+i alpha_Im)/(2m)`, with `m=120` for Sigma and one for phi/S.
The section returns a selected constrained representative. The forward map
has a kernel: trace and antisymmetric Phi directions, the complementary Sigma
cotangent directions, and redundant ordered form directions. No inverse on
the whole redundant space is asserted. The projector, its idempotence and
metric self-adjointness are checked exactly for all four sectors.

## General coefficient and potential coverage

Primary Jacobians come from A31 embeddings. Replay reconstructs the physical
tensor aliases directly from the qualified independent real basis states,
using cycle parity for form permutations. They agree on **121,148 nonzero
ordered alias Jacobian coefficients** and the implicit zeros in their declared
domains. This covers Phi54, Sigma252, phi20 and S2, both complex aliases where
applicable, and every ordered address. The coordinate order agrees with the
frozen 328-coordinate scalar/source order.

The primary generates **203 raw ordered Euler templates**: seven field aliases
for each of the 29 executable potential terms, including zero derivatives.
It pairs each with an arbitrary tensor variation. Exact Einstein-graph
normalization retains parameter coefficients, tensor slot order and finite
contractions; it uses neither tensor symmetry nor field sample values to
identify the two potential differentials.

Replay reads the frozen executable action directly and differentiates its
literal polynomial with an epsilon variation. It does not import the primary
adapter, graph normalizer or indexed Euler operation. All **124 normalized
potential differential graph coefficients** agree exactly. Coverage includes
all **34 independent real potential parameter coordinates**: 24 real and Re/Im
coordinates for the five complex directions. The action's minus-V sign and
Hermitian completions remain literal, without adjusted parameters.

This is a factorized direct-canonical oracle. Its value and variation leaves
mean `Y=Jx` and `H=Jh`, using independently reconstructed full component
Jacobians. Differentiating `F(J(x+epsilon h))` gives the saved differential
graphs with these leaves; no expansion into a dense quartic component catalog
is needed. Leaf equality, the ordinary product rule, linear finite contraction
and constant-embedding jet prolongation prove the pullback identity by
induction for every polynomial in the declared executable grammar. It is not
an inference from a few chosen configurations. Exact mass Hessians additionally
agree for all 328 coordinates: `-2mPhi2*x`, `-2mSigma2*x`, `-mphi2*x`, and
`-mS2*x`, with the inherited normalization of each sector.

## Preserved witness and kinetic Euler terms

The frozen one-coordinate Sigma result remains

\[
 L=-m_\Sigma^2t^2,\qquad dL/dt=-2m_\Sigma^2t.
\]

Both new routes reproduce the 240 nonzero ordered components. Omitting the
ordered measure still gives `-mSigma2*t/60`; the new signed pullback gives the
direct derivative exactly. A new unrestricted covector supported on a single
ordered address refutes the shortcut of multiplying every covector by 120:
its first canonical coefficient is `sqrt(2)/2`, whereas that shortcut gives
`60*sqrt(2)`. The factorial shortcut is valid only after establishing the
appropriate antisymmetry of the input covector.

For every scalar kinetic term, primary indexed Euler differentiation and an
independent free bilinear/matrix-ring replay give

\[
 \mathcal E_x=-\Box x-g\rho(\partial_\mu B^\mu)x
 -2g\rho(B^\mu)\partial_\mu x
 -g^2\rho(B_\mu)\rho(B^\mu)x=-D_\mu D^\mu x.
\]

The free skew-matrix identity holds in arbitrary finite dimension. Primary
specialization freshly checks skewness of all 180 frozen representation
matrices; the full representation derivations are authenticated and reused.
The integration-by-parts boundary current is `h^T D^mu x`. No equations of
motion or zero-connection projection are used. A regression retains a nonzero
`partial B` contribution when the value of B is zero.

The ordered tensor kinetic covector conversion is checked separately. Sigma's
ordered kinetic Wirtinger coefficient is `1/240`, which becomes the sorted
real covector `-G E D^2x` after the permutation and conjugate-alias sums. Phi,
phi and S give the corresponding metric-weighted covectors. Applying `E^T`
returns `-D^2x` in every sector. The singlet specializes to `-Box x`.
The constant shift `x=v+eta` leaves these Euler/jet rules intact; gauge-field
variations and connection jets are retained before any projection.

## Canonical K_phi compatibility

The previously qualified six-source decoder is authenticated. A new direct
composition audit uses its actual scalar physical frames and REG7 pairings.
This shared source-frame audit is not described as a second independent source
decoder. It verifies both inverse products, pairing, conjugation and the
simultaneously transported bracket for all 328 components.

Write `x=T z_channel`, `J_eval=E_source k_channel`. Then
`P=E_source^T T` is the computed typed pairing, not an assumed identity.
The unsigned simultaneous bracket is
`M=T^-1 E_source^-T=P^-1`. The canonical field derivative pulls back as
`T^T alpha_x`, and `M^T T^T alpha_x=E_source^-1 alpha_x` exactly. Source-only
transport uses `E_source^-T` in the bracket. Constant even frames commute
with ordinary derivatives at every jet order. The typed source conjugation is
`C=E_source^-1 conjugate(E_source)`; both its involution and evaluation reality
are checked. Scalar/source grades remain `(1,0,even)` and `(2,-1,odd)`.

Under the previously qualified source-left convention `Q=(S,.)`, the physical
scalar source column has sign **plus** the canonical Euler covector. A direct
bracket control for `Sphys=-m*x^2` gives `QJ=-2m*x`. In typed source coordinates
that physical contribution is therefore `+E_source^-1 alpha_x`. The full source
column would also depend on the as-yet unconstructed source terms. This
compatibility check does not establish a master equation or nilpotence.

## Validation, limitations and next decision

The bounded validation receipt records fresh byte-identical regeneration of
the three new read-only routes and **63 passing targeted regressions** (13 new,
50 inherited). Scientific calculations attempt no writes and run under the
pole-blind guard. Authentication checks inherited bindings; the validation
inventory checks size/mtime metadata for the workspace and active data and
finds no changes during auditing. The receipt identifies its record count and
runtime. This is not an unrestricted all-byte workspace audit.

The historical A10 physical-action counterexample, mixed-source PASS and heavy
canonical-map PASS remain preserved within their original bounded scopes. The
unfinished mixed-kinetic calculation remains unestablished. Historical custody
still exits **2**, with **seven unresolved references**. Authority stays **34/39**.
No catalogs, sources, frozen action, physical parameters or project state are
changed. There is no quantum matching, HB1/C5 or finite C1_GS calculation.

The adapter and physical candidate remain inactive. The proof uses factorized
graphs and linear maps, not a fresh dense expansion of the full 328-coordinate
action. It covers the approved scalar/gauge physical action, including all its
scalar Euler contributions; Yukawa terms and the complete graded BV executor
remain outside this contract. The legacy V4/V5 calculations are not declared
wrong without reconstructing what conversion their consumers actually used.
The negative control establishes the danger of an untyped direct substitution.

Solo review uses independent derivations, exact controls and published primary
literature. Both routes share the analyst, runtime, Sympy, physical assumptions
and frozen inputs. No external endorsement is claimed or sought. The
[technical packet](A10_COTANGENT_TECHNICAL_REVIEW_PACKET_V1.md) records the
remaining challenges and published comparators.

The next decision is whether to separately authorize a bounded **complete
canonical BV master-action candidate** around the inactive executable action,
using this cotangent adapter and the authenticated source/nonminimal controls.
Its master identity, source columns and off-shell squares would require fresh
independent evidence. Stage E, source activation and HB1/C5 remain separate
gates and are not authorized by this result.
