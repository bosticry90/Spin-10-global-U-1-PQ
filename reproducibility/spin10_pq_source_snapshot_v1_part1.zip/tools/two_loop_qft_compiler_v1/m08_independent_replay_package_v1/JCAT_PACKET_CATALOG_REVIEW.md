# JCAT8 to JCAT12 packet catalog calculation

Resume from `0797910`. The complete JCAT7 tagged packet basis and upstream
internal, realization, Lorentz, conjugation and recoupling authorities remain
immutable. Only packet permutation, IBP and final statistics are authorized.

## Task header

- Physics decision enabled: give the later C5 calculation a complete admissible
  local-operator catalog, rather than ordered coordinates or unquotiented packets.
- Current blocker removed: packet-level permutation, IBP and statistics have not
  yet been qualified.
- Why existing tools are insufficient: ordinary signature-local jet quotients
  do not certify operations on complete affine-background packets.
- Minimum new implementation surface: exact induced finite packet actions,
  packet-compatible total derivatives, quotient maps, character/statistics
  projectors and independent controls.
- Structure obligations: full joint action, quotient descent, covariance,
  conjugation, parity, Coxeter relations and immutable expansion provenance.
- Stop: the first failed required equation or unresolved contract; otherwise
  JCAT12 adjudication. No C5 or downstream execution.
- Failure disposition: retain versioned failed controls, do not modify passing
  upstream maps or manufacture absent operators, and do not promote the catalog.

## Calculation record

1. Question: which complete covariant packets define distinct admissible local
   operators after exact IBP and diagonal identical-field statistics?
2. Claim: a finite exact catalog with complete provenance and independent
   reconstruction/character checks under the frozen bounds.
3. Ceiling: implementation authority only; formal scientific authority is 34/39.
4. Inputs: all 431 signatures, 369980 ordered coordinates, realization nullity
   1356, 368624 tagged realized directions and 359524 covariant tagged packets;
   physical 4D metric/epsilon algebra and frozen derivative/field/ghost bounds.
5. Comparators: promoted JCAT4/JCAT5 and INT8 factors, physical component tensors,
   ordinary total derivatives and independent finite characters.
6. Primary: induce the full internal plus jet action; expand total derivatives
   exactly; use finite factorized blocks for quotient and statistics operations.
7. Replay: full colored-tensor packet actions and ordinary expansion derivatives,
   frozen before comparison. Exact characters check materialized ranks.
8. Falsifiers: leakage, failed Coxeter or conjugation diagram, noncovariant IBP
   relation, missing total derivative, unmatched character dimension or lost address.
9. Limits: singleton, affine kinetic completion, realization-null ancestry,
   epsilon, repeated bosonic and Grassmann occurrences and joint antisymmetric
   internal/antisymmetric Lorentz survival.
10. Separate stages: realization, IBP and statistics have distinct provenance;
    no EOM, BRST differential or C5 cochains are constructed.
11. Interpretation: a failed map or incomplete quotient blocks catalog promotion;
    it does not adjudicate the empirical viability of Spin(10).
12. Reproduction: frozen inputs and outputs, deterministic bytes, read-only audits,
    zero audit mutations, pole-blind guarded validation and local commit only.

## Map orientation

An expansion column is a covector/tensor in frozen ordered coordinates. The
realization map removes only qualified identically-zero directions. Packet
columns embed into the faithful realized space. A permutation acts jointly on
the entire expansion and is then re-expressed in packet coordinates; it is not
assumed to be monomial. IBP quotient maps have domain packet coordinates.
Grassmann statistics signs are absent until the final diagonal projector.

The frozen boundary rule drops exact total derivatives of local densities.
Whether a generating current is covariant must be distinguished from whether
its divergence is an admissible covariant relation; no narrower current rule
may silently replace the frozen boundary convention.

## Implementation refinements

The Young replay's exact numerical multiplicities agreed before comparison;
its first comparator confused in-memory tuples with JSON lists inside nested
dictionaries. Canonical serialization fixes that software comparison without
changing any coefficients. Parity sectors are explicitly selected in the
joint-statistics control, and its positive vector is transported into the
certified packet quotient rather than assuming it exhausts that block.

Verbose unqualified orbit provenance is represented losslessly by finite
source selectors and coset transport recipes. Two encoding receipts preserve
earlier layout hashes and inverse recipes. Neither compaction rotates a basis
nor changes an operator coefficient. Physical density representatives are
coordinate representatives modulo IBP, not claims that arbitrary pointwise
field evaluations are invariant under adding a total derivative.
