# Free nonminimal BV comparator contract

This bounded investigation tests a complete field and antifield construction
for the free auxiliary source obstruction recorded at commit `707c3ab`.
It is a separate comparator, not a modification of M08 or a new cochain catalog.
The contract is fixed before deriving or comparing its transformation images.

## Decision and scope

Physics decision enabled: determine whether a coherent off-shell nonminimal BV
construction can solve the smallest `Q^2 K_Lambda = -box(u)` counterexample,
justifying a later, separately authorized full M08 source-architecture review.

Current blocker removed: none automatically. The tested M08 construction
remains blocked by `M08_C5_COHERENT_SOURCE_CONVENTION_NONMINIMAL_PAIRING_NOT_CLOSED`.
A successful comparator does not qualify a replacement M08 operation.

Why existing tools are insufficient: the six-pair M08 proposal makes the heavy
antighost transformation noncanonical while pairing its auxiliary canonically.
The previous successful non-Abelian comparator includes nonminimal antifields,
but does not derive the continuum ordinary-jet cancellation in this witness.

Minimum new implementation surface: one four-dimensional free Abelian gauge
model, an exact differential-polynomial calculation and a separately coded
formal-variation replay; bounded evidence, tests and a read-only audit.

Structure-preservation obligations: the comparator source coordinate map and
gauge-fixing canonical shift must have explicit inverses, preserve ghost number,
canonical dimension and parity, and intertwine the derived differential.
Local derivatives commute and integration by parts is certified by explicit
total derivatives. No map into the full M08 catalogs is asserted.

Stopping condition: stop on the first failed exact prerequisite. If the free
model passes, replay the previous isolated ghost-source controls and the existing
small partially gauge-fixed comparator. Stop before any full M08 reconstruction,
new catalog, H-basic sector, C5 differential or cohomology.

What will be deleted or deactivated if this does not work: no frozen evidence
will be deleted. New code remains an inactive comparator and its counterexample
is preserved. It must never replace an authoritative M08 transformation.

## Algebra and grading

Use one free gauge coordinate with four Lorentz components, constant metric
`eta = diag(1,-1,-1,-1)` and commuting ordinary derivatives. There is no gauge
coupling. All fields and sources are independent off-shell comparator symbols.
The selected M08 heavy singlet and its physical dual are already qualified by
the previous bounded evidence; no identification with the interacting theory
is inferred.

| Field | d | gh | parity | Source J | d | gh | parity |
|---|---:|---:|---:|---|---:|---:|---:|
| V_mu | 1 | 0 | 0 | KV^mu | 2 | -1 | 1 |
| u | 1 | 1 | 1 | Lu | 2 | -2 | 0 |
| bar | 1 | -1 | 1 | Kbar | 2 | 0 | 0 |
| Lambda | 2 | 0 | 0 | KL | 1 | -1 | 1 |

`Kbar` is the additional comparator antighost source. It is NOT added to M08.
The gauge parameter `xi` is an inert dimension-zero, ghost-zero even symbol.
A derivative raises dimension by one, not ghost number or parity. Q has
degree `(Delta d,Delta gh,parity)=(1,1,1)`, preserving `w=d-gh`.

There are seven canonical pairs and fourteen base generators. Jets of each
generator are formal independent graded-commutative coordinates, symmetric in
their derivative indices. There is no numerical evaluation, EOM relation,
wave equation, finite-mode approximation or silent highest-jet truncation.
Finite tests cover every jet required by the tested identities, with nonzero
higher jets retained. Prolongation extends the base identities to arbitrary
jets by `Q partial_mu = partial_mu Q` and the graded Leibniz rule.

## Fixed bracket and action

Use the coherent left source convention already reviewed, now for ALL pairs:

```
(F,G)_J = sum_z (-1)^p(z) [
 (delta_r F/delta z)(delta_l G/delta J_z)
 -(delta_r F/delta J_z)(delta_l G/delta z)]
Q F = (S,F)_J, with LEFT odd Leibniz rule.
z_star = (-1)^p(z) J_z; J_z = (-1)^p(z) z_star.
```

Euler derivatives are graded left/right variations followed only by integration
by parts. For even S, the generator images are derived as
`Q z = delta_l S/delta J_z`, `Q J_z = delta_l S/delta z`.
The source terms have dimension four and ghost number zero.

Let `F_mu_nu = partial_mu V_nu - partial_nu V_mu`,
`div V = sum_mu eta_mu partial_mu V_mu`,
`box = sum_mu eta_mu partial_mu partial_mu`. Fix

```
S_min = integral [-1/4 F_mu_nu F^mu_nu + KV^mu partial_mu u
                  - Kbar Lambda].
psi   = integral bar (div V - xi Lambda/2).
S_gf  = integral [-1/4 F_mu_nu F^mu_nu - bar box u
                  - Lambda div V + xi Lambda^2/2
                  + KV^mu partial_mu u - Kbar Lambda].
```

The last term is motivated by the canonical nonminimal construction, not fitted
to the failed coefficient. Its source coordinate convention must generate
`Q bar=-Lambda` from the SAME bracket. The free gauge kinetic term makes this a
conventional free gauge comparator; it is not claimed to equal the whole M08
action. Its gauge-fixing sector exactly matches the frozen free witness.

Derive the canonical shift from psi, including signs in these source coordinates;
require finite invertibility and `U(S_min)=S_gf` modulo an explicit total
derivative. No desired source image may be inserted by hand in the primary
calculation. Derive every forward and reverse image from S_gf.

## Gates and controls

1. Reproduce the old mixed canonical/noncanonical failure and ST cancellation.
2. Derive all fourteen images and grade them term by term.
3. Require the full classical master equation modulo an explicit total derivative.
4. Require Q squared to vanish on every field/source and the bounded witness
   `integral KL Lambda`, with ordinary jets and all sources retained.
5. Require the canonical shift, inverse, differential intertwining and derivative
   prolongation checks; no EOM quotient is allowed.
6. Reject deletion of Kbar, a flipped partner sign, a fitted square, and a falsely
   claimed full M08 repair. In particular test whether `Kbar=0` is Q-invariant.
7. Independently derive the decisive source images and identities without reading
   primary matrix columns or primary frozen results. Freeze before comparison.
8. Only after success, recheck earlier bounded `-2i`, `+1` and nonhorizontal Sigma
   controls, and the already qualified partially gauge-fixed comparator. These
   are separate regression sectors, not a coupled full M08 proof.

The primary route may reuse the qualified exterior-polynomial engine. Replay
must use separate word/formal-variation code. Python and SymPy are shared;
library/runtime/external specialist independence must not be claimed.
Primary references are [Gomis, Paris and Samuel, sections 4, 6 and 7.2](https://arxiv.org/pdf/hep-th/9412228)
and [Ferrari, section 3](https://arxiv.org/html/1308.6802v3). Their assumptions are
comparators, not certificates for the frozen M08 source truncation.

## Custody and stop boundary

Preserve Sigma_M08, all six sources and all seventeen frozen images byte-for-byte.
Preserve historical `-2i`, `+1`, Sigma nonhorizontality and `-box(u)` evidence.
No pole/projection payload reads. No HB1/C5, cochain dimensions, differential
matrices/ranks, EOM quotient, H0/H1, C6/D6/E, attempt 2, Layer 6, gauge refit or
C1_GS. Formal authority stays `34/39`; finite_C1_GS stays null.

Audit entry points are read-only, regenerate new evidence byte-identically and
check workspace/active-data inventories and scientific input hashes. Existing
JCAT/T5 authority is reused without reconstruction. Record measured wall/CPU,
peak memory and OS I/O without inventing unmeasured parsing/cache timings.
No GPU implementation. Historical custody remains separate and unresolved.
Commit locally after bounded validation; do not push or begin the next stage.
