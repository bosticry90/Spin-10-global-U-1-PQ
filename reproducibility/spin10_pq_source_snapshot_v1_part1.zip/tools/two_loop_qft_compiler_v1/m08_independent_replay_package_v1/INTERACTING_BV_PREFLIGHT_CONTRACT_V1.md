# Interacting BV consistency preflight

Physics decision enabled: test whether the corrected matter orientation and complete nonminimal pairing coexist in one interacting continuum BV control. No unification verdict is enabled.

Current blocker removed: investigate the prerequisite for an interacting M08 source reconstruction. A comparator cannot remove the active M08 blocker by itself.

Why existing tools are insufficient: the qualified free comparator has no interacting scalar; the scalar reconciliation has no complete interacting reverse sources. Separate successes do not prove a common master action exists.

Minimum new implementation surface: an inactive SU(2) adjoint-Higgs continuum comparator, a separately assembled ordered-word replay, frozen bounded evidence, tests and read-only audit. Reuse the existing two polynomial engines without modifying them. No active M08 source or catalog extension.

Structure-preservation obligations (maps only; otherwise explain N/A): derive the gauge-fixing source shift from a field-only fermion and the declared canonical bracket; check its exact inverse, grades, action equivalence modulo reconstructed divergence and differential intertwining. The shifted vacuum is a coordinate translation, not an invariant scalar. No dictionary from this orthonormal SU(2) control to M08's nonorthonormal representation is claimed.

Stopping condition: first exact master, source-square, covariance, derivative or gauge-fixing failure. Full M08 replacement also requires a declared partial-gauge/source-domain architecture and specialist semantic review. Neither is supplied by a successful ordinary gauge control; stop at that review boundary without HB1/C5 or large expansion.

What will be deleted or deactivated if this does not work: comparator remains inactive and its exact counterexample is retained. No historical evidence is deleted or edited.

## Frozen control model

Work in physical four-dimensional Minkowski signature diag(1,-1,-1,-1), with epsilon(0,1,2)=+1 in the orthonormal SU(2) adjoint. All ordinary derivative jets commute. The regulator is not used. Couplings g, h and xi have dimension zero; v has dimension one and is spacetime constant. The scalar is eta=(phi0,phi1,v+phi2); Qv=0 but Qphi includes the full eta.

Fields are A_mu^a, phi^a, c^a, bar^a, b^a (12+3+3+3+3=24 components). Their (dimension, ghost number, parity) are respectively (1,0,0), (1,0,0), (1,1,1), (1,-1,1), (2,0,0). Each field z has its own source J_z of grades (3-d(z),-1-gh(z),1-p(z)): 24 pairs and 48 generators. These are comparator variables only.

Bind D_mu eta=partial_mu eta+g A_mu cross eta, F_mu_nu=partial_mu A_nu-partial_nu A_mu+g A_mu cross A_nu. The invariant density is -F^2/4+(D eta)^2/2-h(eta^2-v^2)^2/4.

Use the already derived convention QA=Dc, Qphi=-g c cross eta, Qc=-g(c cross c)/2, Qbar=-b, Qb=0. Source transformations are not assigned: derive all 48 columns from S_min=S_invariant+sum J_z Qz. The bracket is (F,G)_J=sum_z (-1)^p(z)[(delta_r F/delta z)(delta_l G/delta J_z)-(delta_r F/delta J_z)(delta_l G/delta z)], QF=(S,F)_J. Its canonical antifield coordinate is z*=(-1)^p(z)J_z. Q is a left odd derivation of degree (d,gh)=(1,1).

Gauge fermion psi=bar dot(G-xi b/2), with G=div A-xi g(v_vector cross phi). The Goldstone sign follows from cancellation of the quadratic kinetic mixing after completing the auxiliary square, not from fitting nilpotence. This algebraic completion is a gauge-fixing diagnostic, not an EOM quotient. Keep b and every source in all consistency tests. Define S_gf=S_min+Q_min psi and U=exp(-ad_psi), J_z shifts by -(-1)^p(z)Euler_left(psi,z).

## Acceptance order

1. Derive all columns from S_min and S_gf; check forward images, all term grades, full scalar shift, curvature and scalar-derivative covariance and potential invariance.
2. Check exact squares on all 48 base generators in both presentations and every first ordinary derivative in the gauge-fixed presentation. Higher jets follow from the explicitly tested evolutionary prolongation; they are not separately exhaustively enumerated. A jet safety limit raises, never truncates.
3. Compute the half master density in both presentations. Require every Euler derivative to vanish and reconstruct an exact total-derivative current, without EOM. Check the canonical shift, inverse and all 48 differential intertwining equations.
4. Check the vacuum's Goldstone and gauge mass matrices, quadratic gauge/Goldstone mixing and ghost mass terms. Retain nonzero interactions and gauge parameter dependence. No physical benchmark or loop calculation is repeated.
5. Reproduce the free omitted-partner obstruction, reject the old positive scalar orientation and a wrong nonminimal source sign. Reuse or freshly replay historical source/composite controls with reuse accurately identified.
6. Freeze primary and replay outputs separately before comparing complete polynomial columns, actions and currents. Shared Python, SymPy and model/bracket assumptions limit independence. No external review is implied.

## M08 boundary and validation

The control is an ordinary fully gauge-fixed SU(2) theory, not an earned residual-H/full-Weil source formulation. Successful control identities authorize a review packet, not promotion of the 17 M08 images. A later full M08 reconstruction must address both light/heavy nonminimal sectors, all composite-R chain terms, VEV/gauge-fixing derivatives, six old sources versus complete antifields, non-Euclidean duals and partial-gauge quartic ghosts under one declared master action. Specialist semantic review remains outstanding.

Keep Sigma_M08, six source couplings, 17 frozen images, representations, scalar potential, JCAT/T5, grading and project_state.json byte-identical. No pole/projection payload read, EOM identification, H-basic spaces, C5 matrices/ranks/cohomology, C6/D6/E, attempt 2, Layer 6 or C1_GS. Authority remains 34/39. No GPU work or full catalog reconstruction.

Audit entry points are read-only and compare before/after workspace and active-data inventories. Require fresh byte-identical bounded regeneration, immutable scientific-input digests, meaningful tamper controls and guarded Python. Record wall/CPU/peak/OS I/O measurements without invented parse/cache telemetry. Historical custody exit 2 remains unresolved, not PASS. Commit locally only after bounded validation; do not push.

The mathematical comparators are the nonminimal construction and canonical gauge fixing in Gomis, Paris and Samuel, sections 4 and 7.2 (https://arxiv.org/abs/hep-th/9412228), and the distinct partial-gauge/equivariant requirements in Ferrari, sections 2 and 3 (https://arxiv.org/abs/1308.6802). These references motivate the framework; they do not certify these expressions or supply a full M08 source lift.
