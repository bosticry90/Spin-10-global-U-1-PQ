# Canonical scalar loop trace and complete width-space proof

Prospective derivation: none of these statements is a recorded PASS yet.

## Ordinary scalar UV space and a full normalized program

The accepted invariant-basis gate gives 34 real field-dependent directions:
four quadratic, four cubic and 26 quartic, with complete Hermitian pairs. Its
bound is an exact D5 character count and exact contraction ranks. Authenticate
that gate and the literal 29-term executable action; do not infer completeness
from merely listing coefficients or from radial checks.

For ordered aliases y=Jx with constant embeddings, the real canonical Hessian is

    H_V,x=J^T H_V,y J.

Primary differentiation of the indexed Euler covectors and replay direct
epsilon/eta variation must give identical bilinear Einstein graphs for every
potential term. Their leaves mean h_y=Jh_x,k_y=Jk_x. Loop propagation contracts
CANONICAL real coordinates with identity. Therefore

    Tr H_V,x^2 = Tr[(J J^T H_V,y)^2].

A raw ambient trace, an extra Riesz metric, or treating complex conjugate
aliases as independent propagating coordinates is not this operation.

For d=4-2e, the Euclidean boson determinant +Tr log/2 has pole
-Tr(H_V^2)/(64 pi^2 e). Thus V_CT=+Tr(H_V^2)/(64 pi^2 e) and the literal
Minkowski L_CT=-V_CT. The one-loop derivative term proportional to Box Tr H
is an admitted ordinary boundary; there is no one-loop scalar wave pole for
a derivative-free renormalizable potential. Do not reverse the minus-V sign.

Global transformations are real orthogonal and traceless on all canonical
sectors. Constant basis transport of the Hessian conjugates it, so its squared
trace is Spin/PQ invariant. Any symmetry-preserving local forest subtraction
commutes with those INTERNAL transformations. Scalar power counting bounds
counterterms by dimension four. The complete invariant basis then contains
all field-dependent potential poles; invariant two-derivative terms have one
metric per irreducible scalar/PQ sector. The unit operator is a separate vacuum
normalization. This is an all-order ordinary UV-membership proof, not a dense
all-coupling beta computation, physical IR theorem, or global-stability claim.

Use positive source-independent IR Gaussian reference masses for the formal
forest construction if needed, keeping physical mass terms as their literal
interaction/reference-difference data. Physical coefficients are not fitted
or reset. Removing those references and proving a benchmark's IR/vacuum
conditions are separate. At g=0 scalars have Q0x=0 and no ghost/gauge vertices.
Their local subtractions are BV-source independent, so the explicit ghost
prescription and scalar forest construction form an ordinary g=0 UV class
preserving the affine source identities. General probes and all-g restoration
do not follow automatically.

## Coupled four-sector coefficient control

Let q_a=x_a^T x_a and V=sum m_a q_a+sum A_aa q_a^2+sum_{a<b} A_ab q_a q_b.
Canonical masses are mPhi2,mSigma2,mphi2/2,mS2/2. The self coefficients are
lambdaPhi1,lambdaSigma1,lambdaPhiVector1/4,lambdaS/4; cross coefficients retain
the actual halves/quarter induced by phi and S metrics. Primary AST execution
must derive them, not assume their normalizations.

For alpha_a=2V_a and beta_ab=4V_ab, block differentiation gives

    H_aa=alpha_a I+beta_aa x_a x_a^T,
    H_ab=beta_ab x_a x_b^T,
    Tr H^2=sum_a[n_a alpha_a^2+2alpha_a beta_aa q_a+beta_aa^2 q_a^2]
             +2sum_{a<b} beta_ab^2 q_a q_b.

Primary direct radial differentiation plus all n_a-1 transverse modes and
replay block algebra must compare every parameter/field monomial exactly.
O(n_a) transitivity proves the radial identity for this subfamily; it is not
sampling used as proof for the entire potential. A nonzero field-independent
mass pole is kept as the vacuum normalization, never silently erased.

## A mixed complex coefficient needing zK

With Sigma=0, Phi=diag(1,-1,0,...), phi=e0 and S=1, form canonical holomorphic
Hessians of Phi_ij T_ij S and T_ij phi_i phi_j. Primary uses the actual constant
Sigma Jacobian and ordered four-index sums. Replay counts complementary
five-form pairs: among 126 containing index 0, 56 also contain 1 and 70 do not.
Their self-dual partner contributes the opposite square. Compare the exact
coefficient of z4* zD in Tr H^2 with Phi_ij phi_i phi_j S*. Repeat with
phi=(1+i)e0/sqrt(2) to test the imaginary coefficient and Hermitian partner.
This tests a non-norm direction; zK must not be omitted. No numerical coupling
is adjusted and no new operator is inserted into the action.

## Every symmetric heavy-width normalization

Unknown real symmetric width forms have 33*34/2=561 coordinates. In a real
rational heavy frame Z, solve D_h^T K+K D_h=0 for all twelve generators using
exact rational row reduction; obtain an upper bound, not merely examples.
Replay uses actual dual C3 Cartan weights: only opposite weights and the zero
Cartan pair can support K. The raising generators connect their normalized
metric coefficients; prove the upper bound by this separate connectivity graph.

The preceding ghost metric gives E=G_M kappa with five distinct eigenvalues.
Its constant spectral projectors P_nu provide forms K_nu=G_M^-1 P_nu. Verify
symmetry, real structure, H covariance, ranks, metric sum and kappa=sum nu K_nu.
Matching the independent upper bounds proves they span the symmetric width
space. Constant spectral gaps are not physical-parameter divisions.

For each primitive Psi_nu=ub^T K_nu Lambda, derive QPsi_nu with the actual full
Stage D field columns, including the composite R_H and nonsymmetric coset.
Check Q^2Psi_nu=0, local H Ward invariance and the exact g=0 pole/primitive.
Their BRST-exact action changes are J-free and have vanishing self-antibracket;
the master functional therefore remains valid structurally. This qualifies a
candidate normalization space, not its adoption or arbitrary quantum A5
equivalence. Evaluation-dual BV source pairings remain identity, not K_nu.
