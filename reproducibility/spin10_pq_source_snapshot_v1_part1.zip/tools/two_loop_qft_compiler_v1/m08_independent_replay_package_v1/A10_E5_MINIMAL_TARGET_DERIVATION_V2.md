# Corrected zero-coupling source derivation

The field-rotation and local integrability arguments in V1 remain hypotheses
to verify. Its whole-sector Gaussian assertion was refuted by the literal
action. This record replaces that assertion with the complete interacting
density and an affine source identity; no physical action is changed.

At g=0 the heavy cubic E1 term is still

    Psi_cubic=(xi/2) <ub_phys,[ub_phys,u_phys]_M>.

Q ub=-Lambda and Q u=Q Lambda=0 at this limit. Its contribution is

    Q Psi_cubic=-xi <Lambda_phys,[ub_phys,u_phys]_M>.

In canonical words C_k Lambda_i ub_j, the coefficient is +xi times the
physically derived dual cubic tensor. Independently compare the entire tensor
with the actual g=0 E2 density minus its quadratic/affine-source part.
For real heavy vectors a,b and c=P_M[a,b] nonzero, assign

    ub_phys=a thetaBar, u_phys=b thetaU, Lambda_phys=c tAux.

The selected density is -xi ||c||^2 tAux thetaBar thetaU. Its tAux Euler
derivative is nonzero. Validate the real heavy subspace, dual/primal maps,
Grassmann signs and complete-term exclusion before accepting this witness.
It is a nonlinear gauge-fixing interaction, not a new physical particle or
failure of the original master action. The actual nonsymmetric coset matters.

The zero-field quadratic gauge/auxiliary Hessian and ghost kernel can still
be inverted at generic p^2 nonzero. Higher-degree vertices remain in the
action and can contribute to loops. The quadratic inverse is not a full
Gaussian path-integral calculation and is not an IR prescription.

The relevant source argument does not require a Gaussian action. Check the
actual field-variation columns at g=0. Prospective nonzero columns are
Q B_mu=partial_mu C, Q ub=-Lambda and Q bar=-b; all remaining field columns
vanish. The external BV source density is therefore

    sum J_B^mu partial_mu C - sum J_ub Lambda - sum J_bar b.

Integrate the first term by parts with the explicit current J_B^mu C.
With ordinary sources j_z z in that order, this is a source shift

    j_C -> j_C - partial_mu J_B^mu,
    j_Lambda -> j_Lambda - J_ub,
    j_b -> j_b - J_bar.

All source dimensions, ghost numbers and parities must agree. If the formal
measure/regulator and subtraction/source normalization preserve this exact
dependence, Z[j,J]=Z_0[j+shift(J)] even with all nonlinear ghost/auxiliary
interactions retained. The graded Legendre transform then gives

    Gamma[phi,J]=Gamma_0[phi]+sum J_z R_z(g=0,phi),

modulo the displayed ordinary current. Verify the signs through the W1
left-derivative convention, not an ungraded Legendre rule. Absent-source
derivatives vanish, and the affine source columns retain their specified
linear mean-field form. This is conditional and at rho=0; it is not a proof
of the actual A1-A5 prescription, all finite source/contact normalizations,
nonlinear source transport or the quantum target's general completeness.
