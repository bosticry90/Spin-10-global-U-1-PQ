# E4 inactive composite/nonminimal/quartic reconciliation

The result is governed by `A10_E4_INTERACTION_CONTRACT_V1.md`. Qualification
requires exact primary/replay agreement, completed adversarial checks and the
read-only validation receipt; the sealed auditor records the final disposition.
The completed initial routes and controls report
**PASS_BOUNDED_INACTIVE_E4_COMPOSITE_NONMINIMAL_QUARTIC_RECONCILIATION** for
director assessment; formal ledger acceptance is not inferred from execution.
No source activation, E5, catalog replacement, HB1/C5, quantum matching or
formal-authority promotion follows automatically.

Recovery began with a clean working tree at `1dc61f0`, without surviving
A10/M08 Python calculations. Twelve predecessor manifests authenticated;
their D–E3 construction remains unchanged. The approved physical scope is
classical gauge/scalar, with 643 canonical pairs and 48 external backgrounds.
Fermion/Yukawa interactions and quantum-loop calculations remain absent.

## Restricted algebra and complete BV are distinct

The restricted heavy derivation acts on B, x, u=C_M, ub and L, comprising
607 fields. Its action is derived from the full field columns and independently
from normalized physical Spin(10) matrices and the qualified embeddings.
It retains the actual H12/M33 nonsymmetric split. The full 643-pair retained-source
BV system remains present and nilpotent within its prior qualification.

All twelve composite components R_H=-[u,u]_H/2 are represented by 100 nonzero
coefficients. The definition contains no g10. Both derivations establish

    delta R_H=0, delta^2=-g10 T_(R_H),

where T includes g10 in its homogeneous action. All 607 field squares and
1,214 first-jet squares vanish after subtracting this residual transformation.
Local parameter derivatives are retained, including partial R_H in gauge
columns. This is not delta^2=0 on unrestricted expressions. No E5 domain is
selected or qualified. The full BV light bar,b trivial pairs are not falsely
extended into this restricted equivariant-square claim.

## Canonical curvature and sources

A separately declared restricted cotangent diagnostic uses the same canonical
evaluation pairing for those 607 fields. Its 1,214 source/field columns contain
79,838 coefficients. It satisfies the curved source master identity

    (S_delta,S_delta)_1=-2g10 H_R+div(2 sum_M JB delta u),
    H_R=-sum_z (-1)^p_z J_z T_(R_H)z.

The 47,244 master-density coefficients agree with the curvature generator
and divergence of a 552-coefficient boundary current. The physical
source-degree-zero part uses the qualified all-45 Noether identity restricted
to heavy parameters; its 508 physical Euler programs are authenticated and
reused rather than freshly expanded. No equations of motion are imposed.

Graded Jacobi then gives the full restricted cotangent square -g10 X_(H_R).
Differentiating the composite R_H before substitution is essential. Freezing
an independent parameter during differentiation loses 90,624 source-chain
coefficients, all in heavy ghost-source slots. Both routes compare these
complete corrections. Four selected source squares are also expanded directly,
with three additional nonzero charged source squares in the adversarial route;
the remaining all-source conclusion uses the curved master and Jacobi proof.
Ordinary jet prolongation supplies the declared higher-jet statement and caps
raise. This is not an exhaustive expansion of every higher source square.

The full system at c_H=0 retains

    S1 |_(c_H=0)=S_delta,1+g10 sum_H JC_h R_h-sum_H Jbar_h b_h.

The 100-coefficient curvature bridge and its variational source contributions
are compared explicitly with the full source columns. Thus the diagnostic
does not pretend that c_H=0 defines a BRST-stable quotient or discard the
light ghost sources. It changes neither the Stage D action nor its alphabet.

## Complete interactions and action comparison

Both routes reconstruct every heavy replacement-fermion term and the full
light variation. The heavy contributions contain 27,951 coefficients counted
by their five separately recorded terms; the light variation has 5,841.
They compare with the actual E2 density using the explicit current

    Delta_E2=delta Psi_M+Q Psi_H+div L.

The sum agrees exactly, including connection, shifted orbit, auxiliaries,
derivatives and boundary terms. The heavy partial density is delta invariant
off shell. No auxiliaries or sources are eliminated. Identity of the complete
E2 gauge-fixing contribution, together with the unchanged physical/source
programs and E3 manifest, preserves the E3 Ward and BRST identities. Those
expensive E3 calculations are authenticated, not repeated.

There are 966 combined pure quartic ghost coefficients. The independently
derived curvature and nonsymmetric contributions contain 418 and 648
coefficients respectively; they overlap before collection. Every coefficient
and implicit zero is compared. Light variation and the boundary current
contribute no additional pure quartic ghosts. In physical bilinears the terms
are

    (xi g10^2/2) <U,[U,R_H,phys]>,
    -(alpha g10/4) <U,[U,P_M[u,u]]>, alpha=xi.

Here U=QM GM^-1 ub, u_phys=QM u and brackets use normalized physical matrices.
All coupling powers and signs follow from the frozen replacement fermion and
nonminimal transformations. Alpha=xi multiplies the unscaled ghost coordinates;
no coefficient fitting or convention-changing rescaling occurs. The second
structure is nonzero and cannot be suppressed as a symmetric-coset term.
Historical A4-V2/A5-V2 equivalence remains unproved.

## Replay, controls and initial implementation error

The primary separates the full canonical columns, derives the restricted
source Hamiltonian and varies the replacement density by collected prefix
Leibniz rules. The replay reconstructs 990 normalized physical matrix
commutators, projects physical curvature and dual-heavy bilinears, and varies
through independent left jet gradients. They share immutable representation
inputs, word multiplication, Python/SymPy and analyst. No external endorsement
or proof-kernel formalization is claimed.

Controls independently test local H covariance of all twelve curvature
components. Removing curvature, imposing a symmetric coset, omitting either
quartic contribution, using the bare heavy pairing, freezing composite source
derivatives or extending the restricted square to light trivial pairs gives
the recorded exact nonzero witnesses. These are necessary mathematical
distinctions, not altered physical models used to make a test pass.

An initial new-helper error incorrectly used odd Ward-generator extraction
for an even source Hamiltonian. Both initial runs rejected the first gauge
column. Their outputs, metrics, original helper and incident classification
remain in the frozen directory, excluded from PASS evidence. The corrected
helper uses the already frozen Stage D rule Qz=Euler_left,J S. This fixes a
new implementation error, not an established physical or predecessor defect.
A cheap even/odd-coordinate regression protects subsequent fresh replay.
An initial adversarial fixture also wrongly demanded a nonzero square from the
H-singlet ub12. Its failed expectation is preserved; the completed controls
retain the zero singlet result and select charged inputs from the exact
representation rather than assuming every component is charged.

## Validation, authority and next decision

The validation protocol targets 209 regressions: 16 new E4, eleven new process,
182 inherited. Three fresh E4 read-only routes must regenerate byte-identical
evidence. The completed receipt owns the actual measurements, twelve-chain
authentication, bounded byte comparisons and workspace size/mtime inventory;
that inventory is not a byte audit of the whole environment. The original
historical custody audit must still exit 2 with seven unresolved references.
An incomplete first validation stopped at a stdout/stderr capture stall before
fresh regeneration. Its code and incident record are retained, excluded from
PASS evidence. The corrected harness drains both streams; a 65,536-byte stderr
control verifies completion. Only a complete restarted receipt is accepted.
A second incomplete transaction regenerated all E4 routes correctly before the
new preflight rejected an older manifest schema. The process tool now supports
that existing schema explicitly and tests drift within it; preflight precedes
regeneration on the final retry. This failure did not alter scientific code
or completed evidence and contributes no final validation PASS.

The methodology additions are reported separately in
`docs/AGENTIC_ENGINEERING_INCORPORATION_RESULT_V1.md`. They add recovery and
navigation to existing gates; they confer no scientific acceptance.

Published comparisons with [Ferrari](https://arxiv.org/html/1308.6802v3) support
the equivariant and quartic structures, with coupling conventions explicitly
kept distinct. [Thomsen](https://arxiv.org/html/2404.11640v2) supports retaining
quartic interactions in partial background gauges. Neither certifies this
Spin(10) implementation or supplies a C1_GS result.

Formal authority remains 34/39 and M08 remains blocked. All candidates are
inactive. E5, activation, catalogs, HB1/C5, C1_GS, quantum master/anomaly claims,
physical gauge independence and observational conclusions remain unresolved
or withheld. The next smallest scientific decision is a separately scoped E5
domain contract assessing closure and adequacy for the intended counterterm
problem. An E4 qualification supplies algebraic input, not an E5 result.
