# Coupling tangents, coefficient ring and Ward scope

This is a full-complex mathematical control. Its quantum-target membership is
checked separately. The current regularity/KT certificate is a dependency,
not a proof that antifields can be removed in every restricted complex.

## Canonical views and closed coupling tangents

Use the regularity chart N(g) with beta=Q eta. Its complete cotangent lift is
polynomial and canonical; it retains all 643 pairs. In that chart

    S_beta = S0 + sum_physical J R + sum_a JC_a QC_a + sum_eta J_eta beta,
    F_beta = partial_g S_beta,   g=g10.

Only the first five physical terms and the minimal source terms depend on g.
The doublets do not, with the NEW beta coordinates held fixed. The full ghost
bracket retains both heavy-heavy projections, including the nonsymmetric one.
The full source coupling tangent is compared by distinct derivations.

The established canonical master functional is valid as a polynomial identity
in g. Differentiating it gives

    Q_beta F_beta = (S_beta,F_beta)
                 = (1/2) partial_g (S_beta,S_beta)
                 = partial_mu (partial_g j_master^mu / 2).

Thus F_beta is closed as a local functional with the qualified boundaries.
This uses neither equations of motion nor a loop calculation. The source-degree
one current is independently checked. The source-free current uses the bound
Euler/Noether programs and their g derivative, not new independent Euler fields.

The g-dependent chart must not be treated as constant during differentiation.
Write v=g v1 in beta=-Lambda+v and K_N=sum J_beta v1. Its infinitesimal
connection is X_KN; the source-left convention yields

    N(partial_g S_D) = F_beta + Q_beta K_N modulo a current.

For E2, UJ=J-(-1)^p EL_z Psi and Y_U=-X_partial_g_Psi. Consequently

    partial_g S' = U(partial_g S_D) + Q' partial_g Psi modulo a current.

These are polynomial canonical coboundaries, not an unjustified identification
of the literal derivatives in three different source charts. Source/field
maps, jets, real structure and the external-background scope remain qualified.

## A full polynomial class which cannot be made horizontal

Specialize g and all potential coefficients to zero, set original physical
fields and their jets, nonminimal fields/sources, physical sources and all source
jets to zero. Retain undifferentiated C and JC. External backgrounds may be zero
in this control. In the beta chart every Q image restricts to zero: QB=dC has
zero ghost jets, Qx=QC=0, Qeta=beta=0, QJ_beta=J_eta=0, and the physical free
Euler covectors and source divergences vanish. Therefore a polynomial QK
restricts to zero. An ordinary divergence of a polynomial without explicit
spacetime coordinates also restricts to zero.

F_beta restricts instead to

    F_bar = -1/2 sum_(a,b,c) JC_a f^a_bc C^b C^c.

It is nonzero, real under the qualified frame map and has grades (4,0,even).
It cannot be removed by a polynomial canonical primitive or divergence.
In particular it cannot have a source-free representative: the surviving JC
Euler derivative would then be zero. The g=0 H contraction on this quotient
sends C_H to an arbitrary even omega_H and fixes JC; its nonzero image on
F_bar also excludes a horizontal representative. The projection commutes with
that contraction; all discarded nonminimal contraction images contain g.

For a real physical check choose Y=P_H e_i, X=P_M e_j with nonzero real
Z=[Y,X], using the actual projectors and normalized 10-dimensional generators.
With C=theta1 Y+theta2 X and JC=t Z in the physical evaluation-dual frame,

    F_bar = -||Z||^2 t theta1 theta2,
    iota_(sigma Y) F_bar = -||Z||^2 t sigma theta2.

All three vectors are checked in their physical subspaces. The bracket norm is
an exact positive real algebraic constant. No fitted interaction is introduced.
This is a counterexample to UNRESTRICTED full-polynomial horizontal/source-free
representability. It is not yet a counterexample to the quantum Ward target.
The semisimple theorem at a fixed nonzero coupling is not refuted by a ring
which admits the free 45-abelian-gauge specialization.

## The weighted family has a pole-free basic representative

Let K=-sum_(a,mu) JB_a^mu B_mu^a + sum_a JC_a C^a. The minus sign in its
gauge-field part is required: X_K B=B, X_K C=C, X_K JB=-JB, X_K JC=-JC.
It acts trivially on scalars, doublets and backgrounds. Literal dilation of the
AST gives, for gauge terms, B-degree=2+g-degree; for scalar kinetics B-degree
equals g-degree; potential terms have both degrees zero. The minimal source
interaction terms have dilation weight one and g-degree one; JB dC and the
doublet terms have both weights zero. Hence

    X_K L = 2 L_YM + g F_beta.

Left Euler differentiation and ordinary IBP give the independent identity

    X_K L = -Q_beta K + partial_mu Theta^mu,
    Theta^mu = -F_a^(mu,nu) B_nu^a + JB_a^mu C^a.

The gauge portion of Theta follows from the qualified physical first variation;
scalars do not vary in this dilation. The source portion is freshly checked
coefficient by coefficient. Therefore

    g F_beta = -2 L_YM - Q_beta K + partial_mu Theta^mu.

The physical Yang-Mills density is Q-closed, H-horizontal and invariant under
the declared quantum/background operations as a functional. Its E2 image is
unchanged because U fixes fields. This proves a named polynomial full-class
representative for g F_beta without 1/g. It does not remove F_beta itself.
At fixed nonzero g division would be possible in a different coefficient ring;
that ring is not adopted. K is not an intrinsic basic primitive: iota K=JC_H
omega_H and Tb K=-JB_H d omega_H are nonzero. Quantum admissibility of that
canonical redefinition also depends on A5 and operator/insertion transport.

## Why the unrestricted obstruction is not a quantum counterexample

W6 requires a first local counterterm difference to satisfy both Q' delta=0
and W_b delta=0, with the broken quantum identity realized by insertions.
It does not demand iota' delta=0 by fiat. Coupling differentiation of Tb(g)S=0
instead gives

    Tb(g) F = -(partial_g Tb(g)) S.

The right side need not vanish: the operator itself depends on g. At g=0 the
source contribution contains

    sum_(a,h,c,mu) JB_a^mu f^a_hc C^c partial_mu omega^h.

Its gauge-source Euler derivative is nonzero, so it is not an ordinary
divergence. The same admissible real H/heavy vectors above give the source-left
Euler witness +||Z||^2 sigmaDot theta when the source is JB^0=zeta Z and
partial_0 omega=sigmaDot Y. The undifferentiated sigma has dimension zero;
sigmaDot is a separate dimension-one jet probe. This fails the local background Ward
requirement for the raw coupling tangent. The full physical action contributes
nothing to this selected source coefficient. E2 transport and its exact term
do not turn that selected source variation into a quantum-target PASS.

Therefore the unrestricted obstruction alone cannot refute actual E5
counterterm adequacy. Nor does exclusion of this one tangent prove adequacy.
The admitted coupling-power/normalization conditions and joint primitive space
must be derived from the Ward/insertion prescription. Perturbative intuition
about factors of g is not adopted as a theorem or as a way to delete this class.
No quantum amplitudes or beta function are computed.

The relevant established comparison is [local BRST cohomology](https://arxiv.org/html/hep-th/0002245)
and [consistent master-action deformations](https://arxiv.org/abs/hep-th/9304057).
The novel evidence here concerns this action, parameter ring, canonical charts,
local Ward requirement and real H/heavy witness. Full/basic and intrinsic/
induced isomorphisms, A1-A5, anomalies and physical unification remain unproved.
