# Actual leading auxiliary/vector partners, AV V1

Freeze before computation at5f3b542491f94a0d7f85019fcd57fe15beff3154.
Previous goal turn PROGRESS: actual gauge-source partners close the selected
source Ward left side; five Ward targets remain open. The full investigation
remains active/incomplete. Statev113/34of39 is sole scientific authority.

AV1: actual dimension-zero, no-jet one-loop g10^2*xi auxiliary/vector-pair pole.
Lambda denotes an EVEN integrated auxiliary field (d2,gh0), not the ODD BV
source J_Lambda. B/A_H are even d1/gh0. Density is (4,0,even). Include all45
auxiliary,45B,12A_H and all4Lorentz directions, with full Bose symmetry on the
two vector legs. The228 distinct vector components give45*228*229/2=1,174,770
symmetric slots:733,050 BB,388,800 A_HB,52,920 A_HA_H. Identical even vector
components are allowed. A_HA_H is included to prove the full pair inventory,
not silently discarded because the current Ward target has one B.

Immutable inputs:46 sealed chains, complete literal GF/BV/physical action,
full real primal/evaluation-dual charts, normalized physical10 commutators,
principal inverse/all45 ghosts and antighosts,643pairs/48backgrounds. No new
source inverse/Legendre transform, physical parameter or foundation change.
Actual routes use no prior measured mixing/partner pole, candidate, required
Ward completion tensor or peer result after ancestor BYTE authentication.

First freeze and execute the full literal coupling/field/jet inventory. Proper
three-external-leg one-loop counting n3+2n4=3, at least two integrated
incidences at every vertex. At this explicitg^2xi order, eligible families are
the xi Lambda-antighost-ghost cubic plus two full derivative gauge/background
ghost cubics (all3Source-G-G Born words, both vector assignments and all
derivative placements), and the xi cubic plus the full g^2 vector-pair/
antighost/ghost quartic (both bubble words). Recover BB/AB/AA quartics, not just
the earlier BB projection. Retain all source-gauge/auxiliary/YM/scalar/fermion/
other alternatives in a coupling/incidence/principal-edge/positive-dimension
exclusion proof. If another eligible class is found, include it or STOP before
computation; no prediction-driven omissions. Linear auxiliary insertions with
one quantum leg are 1PR, not proper vertices; widths are part of the reference.

Construct full inverse blocks before proving that the selected xi insertion
and these graph classes close only odd cycles. Keep BOTH odd orientations,
H/M directions and all permitted vertices; no inferred color zeros or false
projected-M Jacobi. Formal H/M widths are independent real polynomials before
binding, without degree cutoff. Resource limits mean INCOMPLETE, not truncation.

Primary: literal graded Fourier Hessians and complete Born words. Replay:
own normalized physical10 reconstruction of derivative/xi/BB/AB/AA quartics,
literal crosschecks before loops, independently routed Gaussian/Wick or exact
Gaussian ghost determinant contractions. Exact full-vector elementary checks
cover every16 external Lorentz pair, both derivative placements on each cubic,
gauge derivative evaluated in its zero-jet scope, both vertex assignments,
and bubble normalizations. Gaussian/sphere angular moments must agree.

Bose symmetrization, equal-color diagonal terms and off-diagonal Lorentz
zeros must be calculated. If an antisymmetry/trace proof eliminates a whole
family, preserve nonzero ordered/intermediate contractions and qualify the
complete cancellation independently; do not omit graphs because the desired
Ward completion predicts their zero. Complete source1/vector2 homogeneous
projection is legitimate; discarded degrees cannot return under multiplication.

Exact natural-root/I arithmetic, no tolerances. Correct auxiliary evaluation-
dual map differs from the gauge/ghost primal chart. Verify full canonical/
physical roundtrip, reality, all12 rigidH tensor identities, explicit g^2xi
units, all4Lorentz copy factors and full pair-slot comparison. UV only
k_E^2>R_UV^2>0, degree-4; triangle/bubble heat profiles6/4, radial multiplier2I
in32pi^2 units. Momentum/mass remainders, mass/power/finite/IR and full
scaleless amplitudes remain outside this selected coefficient.

AV2 AFTER full actual methods/graph families/Bose/zero channels agree: append
the actual poles to the current corrected known residue and test the full
leadingg^2xi Lambda-B/local-parameter derivative Ward subsystem. Separate
prefix/jet-gradient methods, all12 parameters/all45aux/B/all16Lorentz pairs,
388,800 raw component domain, full IBP currents/parameter Eulers without EOM.
Verify the new no-jet densities have only the declared affine Ward targets;
AA or AB contributions must not introduce unreported targets. Compare raw and
anchored left sides. Keep Gamma_unknown/Delta_b/s/insertions/contacts/measure/
IR unbound. If nonzero, preserve the real signed Euler witness and STOP before
any fit, image/candidate adjustment or another actual loop. Zero qualifies
only the selected MEASURED condition, not complete quantum restoration.

Preserve earlier GP source Ward/GS Slavnov scopes and priorg^3candidateFAIL.
The new densities contain only B/A/L; check their support on previous selected
Slavnov projectors using the existing all-column/physical-Euler support proof,
without silently setting full physical Euler programs to zero.

Negative controls require nonzero exact discrepancies or type rejection:
wrong Lambda parity, evaluation-dual/primal pairing or coupling; drop a
nonzero graph/ordered vector assignment/odd inverse orientation; treat even
diagonal vectors as nilpotent; suppress nonzero background vertices before
their edge proof; alter independently proven zeros; omit parameter jets/
currents or bind unknown partners to zero. Preserve exact failed/unfinished
sources/preparations/starts/full stdout and explicit dispositions.

Validation: four own-byte fresh controls/primary/replay/comparison, meaningful
science/process/governance/delegatede5,46protected chains, new/protected/state/
metadata invariance, custodyexit2/sevenrefs neverPASS. Old expensive loops/
images authenticate only; rawindex/worktree equality before localcommit.
Noreset/evidenceediting/unrelatedtermination, adoption/sourceactivation,
physical/catalog/HB1/C5/C1_GS/matching, authoritypromotion, push/publication/
outreach. FullE5/W1-W7/A1-A5/equivalence/IR and scalarPQ/fermionYukawa/pheno
remainopen. Shared action/representations/reference/some arithmetic/PythonSymPy/
analyst disclosed; noagents/independent scientists. Whole goal notcomplete.
