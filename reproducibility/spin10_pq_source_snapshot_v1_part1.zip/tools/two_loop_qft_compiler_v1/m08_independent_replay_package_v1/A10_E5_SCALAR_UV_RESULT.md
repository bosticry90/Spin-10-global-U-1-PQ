# E5 ordinary scalar ultraviolet closure and complete symmetric heavy widths

## Result and authority ceiling

**QUALIFIED_E5_ORDINARY_G0_SCALAR_UV_SPACE_AND_SYMMETRIC_WIDTH_PREREQUISITE_ONLY**.
The actual gauge/scalar theory at formal g=0 admits an ordinary scalar UV
subtraction space containing its complete 34-real-parameter potential, four
kinetic metrics and a separate constant vacuum term. A massive-reference
forest prescription defines this space to every finite perturbative order.
Two independent calculations give an executable one-loop second-variation
program for every potential term and decisive exact coefficient controls.
They also classify the entire real symmetric H-invariant heavy-width space:
it is five dimensional and contains the previously computed ghost pole.

This closes ordinary UV-membership and symmetric-width prerequisites. It is
not a complete M2 quantum prescription, a physical IR/vacuum theorem, a dense
all-coupling beta table, nonzero-g restoration, general source-dependent
insertion/contact normalization or A4/A5 equivalence. The complete E5 target
and Spin(10) x U(1)PQ investigation remain incomplete. No source is activated
or removed; there is no auxiliary elimination, catalog construction, HB1/C5,
C1_GS calculation, matching, publication, outreach or remote push. State v113,
34/39 and its bytes remain unchanged. All 643 pairs/48 external backgrounds
and the Stage D--E4 qualifications retain their original scopes.

## Accepted inputs, rather than another invariant inventory

Baseline bd1cb32597a2c5df217fbb81deda6f785c84d320 had no matching live workers.
The three draft files were preserved and completed. The explicit latest
preflight authenticates frozen_a10_e5_ghost_normalization/bindings.json; a
default preflight still selects the older E3 checkpoint and is not a latest
science verdict. This increment authenticates 22 sealed predecessor chains.

The actual authority already records INVARIANT_BASIS_CLOSED and
complete_explicit_invariant_basis=true. Its exact D5 character calculation
covered 44 PQ-neutral multisets, 26 nonzero families and 34 complex slots,
which become 34 real Hermitian parameter directions. Independent contraction
ranks supply the matching lower bound, including the four Sigma quartics.
PARENT_ACTION_V1.md remains bound to
01323e0f6a025edd6f6669b43e7c730f5350e28d8561e72df89636862ca358ed.
Eight additional definition/result/count/rank input files are raw-hashed at
execution start and sealed as read-only dependencies; none is edited.
The expensive character and contraction-rank calculations are authenticated,
not rerun. Their older reports' narrower benchmark statements must not replace
the current state's separately qualified potential-only local benchmark.

The literal executable action has 34 terms: five kinetics and 29 potential
terms with minus-V sign. Every parameter/field signature matches the accepted
slot ledger, including all conjugates. There are four quadratic, four cubic
and 26 quartic real directions. No scalar potential parameter changes.
The PQ charges are 0,2,-2,-4 for Phi,Sigma,phi,S. PQ is global; no additional
gauge direction or canonical pair is invented.

## Canonical Hessian and ordinary scalar UV construction

Let y=Jx denote the ordered complex/conjugate aliases expressed in the 328
independent real coordinates through the qualified constant embeddings.
For the physical potential,

    H_V,x = J^T H_V,y J,
    Tr(H_V,x^2) = Tr[(JJ^T H_V,y)^2].

The primary differentiates the previously qualified indexed Euler templates.
The replay directly varies each literal action term with two independent
directions and differentiates a polynomial in epsilon and eta. They use
different binder/graph construction and agree on **331 bilinear Einstein-graph
coefficients across all 29 terms and all 34 parameters**, before constrained
pullback. The graphs and constant Jacobian dependencies define the full
canonical Hessian program. This is not a freshly expanded table of every
one-loop coupling coefficient.

All 180 Spin/PQ representation commutators are freshly checked, with skew,
traceless real generators and identity canonical kinetic metrics. Global
transformations conjugate the Hessian, leaving its squared trace invariant.
Canonical contractions are essential: the wrong raw Phi mass trace has 100
ambient directions instead of 54. A raw complex-singlet Hessian squared
produces charged z^4 and zbar^4 terms. Inserting the actual alias propagator
gives 40 lambdaS^2 z^2 zbar^2 instead, matching real coordinates.

Independent massive-bubble differentiation and the dimensionally regulated
boson determinant give the Euclidean one-loop pole

    Gamma_1,pole = -Tr(H_V,x^2)/(64 pi^2 e),   d=4-2e.

Consequently V_CT has the positive sign, while the literal Minkowski L_CT
has the negative sign. The one-loop derivative term is an ordinary boundary.
Derivative-free scalar potentials have no one-loop wavefunction pole;
invariant kinetic counterterms remain necessary in the all-order space.

The ordinary commutative forest operation recursively subtracts nested and
disjoint UV subgraphs. It produces finite massive amplitudes and local
counterterms. See the authored [BPHZ treatment, sections 2.3--2.9](https://arxiv.org/html/1307.4650v2).
This literature supplies the general theorem, not certification of this model.

Here its premises are explicit: polynomial scalar vertices of valence at most
four; canonical propagators; finite-order perturbation theory; positive
source-independent reference masses per irreducible sector; Taylor subtraction
commuting with constant internal symmetry; power counting bounding local
terms by dimension four. Physical mass differences remain quadratic vertices,
with their literal coefficients. The IR references are not adopted physical
masses, and their physical removal is unproved. Invariant Hermitian potential
counterterms lie in the accepted complete basis; two-derivative counterterms
have the four invariant metrics. The unit operator requires its own vacuum
normalization. This proves ordinary UV membership to all orders under those
premises, not explicit evaluation of every diagram or coefficient.

At g=0 scalars are Q0-inert and decoupled from gauge/ghost interactions. These
forest subtractions are BV-source independent. Combined with the preceding
explicit ghost determinant subtraction and free sectors, they define a
nonempty ordinary g=0 UV prescription with positive scalar IR references and
the predecessor's nonexceptional ghost momenta/free-mode restrictions. This
does not prove a complete physical measure, zero-mode treatment or IR limit.
It preserves the ordinary affine source identity in this specified family,
not every local composite-operator or contact identity.

## Exact coupled and non-norm coefficient checks

For q_a=x_a^T x_a, retain the 14 mass, self-norm and cross-norm coefficients.
The primary executes their literal AST on one canonical radial direction per
sector, differentiates all radial modes and includes every transverse mode.
The replay uses the independent block-Hessian formula

    H_aa = alpha_a I + beta_aa x_a x_a^T,
    H_ab = beta_ab x_a x_b^T,
    Tr H^2 = sum[n_a alpha_a^2+2 alpha_a beta_aa q_a+beta_aa^2 q_a^2]
               +2 sum_(a<b) beta_ab^2 q_a q_b,
    alpha_a=2 V_a, beta_ab=4 V_ab.

All **66 parameter/field monomial coefficients** agree. O(n) transitivity
proves the radial reduction for this norm subfamily; it is not used as proof
of the complete potential. The exact field-independent part is

    216 mPhi2^2 + 1008 mSigma2^2 + 20 mphi2^2 + 2 mS2^2.

It is preserved as vacuum subtraction, not discarded. All field-dependent
terms have dimension four with the actual half/quarter phi/S normalizations.

A separate non-norm control uses Phi=diag(1,-1,0,...), phi=e0 and S=1.
The primary contracts actual canonical Sigma holomorphic Hessians of
Phi_ij T_ij S and T_ij phi_i phi_j. The replay counts the complementary
self-dual five-form components. Their contraction is **560**, so Tr H^2 has
coefficient **1120** multiplying z4_conjugate zD in the existing zK direction.
The same-chirality contraction vanishes. Changing phi to (1+i)e0/sqrt(2)
gives 1120i, checking the complex phase and conjugate completion. Thus

    delta zK = 1120 z4_conjugate zD/(64 pi^2 e)

in these declared normalizations, with its Hermitian conjugate. Omitting zK
would not close this channel. No new operator or fitted physical coefficient
is introduced, and the formal control does not reset the benchmark couplings.

## Complete symmetric heavy-width classification

The primary uses a real rational frame for all 33 heavy coordinates. It
constructs every equation D_h^T K+K D_h=0 for the 561 real symmetric unknowns
and twelve H generators: **6,732 rows, 12,936 nonzero constraint coefficients,
exact rank 556, nullity five**. No floating rank or symmetric-coset assumption.

The replay independently uses four residual Cartan directions and their
actual dual-frame weights. Only 17 opposite-weight/zero-weight symmetric
pairs are allowed. Every remaining generator equation relates normalized
pair coefficients. The connectivity graph has five components of sizes
1,1,3,6,6, hence real representation ranks 1,2,6,12,12. This supplies a
second upper bound, rather than five invariant examples alone.

Let kappa be the preceding ghost pole metric and G_M the physical Gram
matrix. The endomorphism G_M kappa has eigenvalues

| nu | 3 | 19/5 | 24/5 | 34/5 | 8 |
| --- | --- | --- | --- | --- | --- |
| Real rank | 12 | 12 | 6 | 2 | 1 |

Its constant spectral projectors P_nu give K_nu=G_M^-1 P_nu. All five are
symmetric, real under the actual dual-chart conjugation, H invariant and
linearly independent. They satisfy

    sum K_nu=G_M^-1,       kappa=sum nu K_nu.

The independent upper bounds therefore prove completeness of this symmetric
width space. Spectral denominators are fixed numerical gaps; no physical
coupling, mass, xi or g is inverted. Bare component pairing remains a negative
control. Canonical evaluation-dual sources still pair through identity;
K_nu must not be substituted into that distinct pairing.

For every Psi_nu=ub^T K_nu Lambda, both routes freshly derive full QPsi_nu
with the actual Stage D field columns (unchanged on fields under E2). They
check Q^2Psi_nu=0 and the local background-H Ward identity. Together the five
densities have **435 coefficients**, including **418 quartic-ghost
coefficients** distributed 156,174,72,16,0. The singlet has no quartic part.
At g=0 their exact result is -Lambda^T K_nu Lambda. Removing the g^2 composite
curvature contribution from QLambda gives a nonzero Q_bad^2 ub13 control.
All actual heavy/light and nonsymmetric-coset columns remain in the good
calculation. The densities are source independent; their self-antibrackets
vanish and their cross master bracket vanishes by Q^2Psi=0. This is a
qualified normalization space, not an adopted change to frozen E1 or proof
of arbitrary quantum gauge-fermion/insertion equivalence.

## Evidence validation, failures and reproducibility

The first start stopped at an engineering TypeError: the parameter set had
not flattened lists. Its complete start hashes, log and original four source/
contract bytes are preserved in failed_start_v1 and primary_attempt_1.json.
It reached no mathematical stopping gate and is excluded from PASS evidence.
After correcting only that list operation, both full routes completed.
No completed result was overwritten or edited. This failed run is distinct
from deliberately nonzero scientific negative controls.

The validation workflow requires **259 targeted regressions**: 214 scientific
(20 new, 194 inherited), 24 process and 21 governance. It freshly regenerates
both new routes byte-identically, authenticates all 22 predecessor manifests,
checks raw protected/new/state bytes and workspace/active-data size and mtime,
and retains strict historical custody exit **2** with **seven unresolved
references**. See frozen_a10_e5_scalar_uv/validation_receipt.json for observed
commands, exits, counts and inventory scope. Passing validation authenticates
this bounded result; custody and the whole quantum target do not pass.

No old expensive character, representation, source-assembly or prior loop
route is rerun. Some all-order conclusions are structural proofs using the
accepted complete basis and the forest theorem; they are not fresh all-loop
enumerations. No physical IR limit, anomaly calculation, general insertion
contact suite, nonzero-g restoration or dense full beta table was run.
The routes share immutable physical/basis inputs, qualified constant charts,
word arithmetic, Python/SymPy and analyst. They use different derivations,
but no external endorsement or independent scientist is claimed. Solo review
continues without personnel requirements.

## Next decision

The next smallest productive increment is a bounded nonzero-g restoration
and affine-source/insertion test of this explicit UV construction, retaining
the actual five-width BRST primitives and every scalar direction. Start with
the precise regulator breaking and admissible local restoration class; do not
assume that ordinary g=0 closure proves the Ward/ST quantum target. General
local probe contacts, A4/A5 equivalence (including weighted gF), the physical
IR/zero-mode conditions and full E5 remain necessary. No historical catalog
descent or HB1/C5 can follow automatically.

The full investigation also retains global scalar boundedness, global PQ
quotient, fermion/Yukawa content, finite matching and phenomenological tests.
This result improves prerequisites for those questions; it establishes no
new prediction, coupling unification or Theory of Everything.
