# Historical M08 source-component decoder preflight

## Required task header

- **Physics decision enabled:** determine whether the historical source couplings can be interpreted in one explicit canonical coordinate system before proposing an interacting M08 reconstruction. No physical matching is computed.
- **Current blocker narrowed:** the unqualified historical component decoder, not the complete M08 source calculus or H-basic domain.
- **Why existing tools are insufficient:** the qualified actual-H control specifies new evaluation sources but expressly leaves historical component meanings unbound. Historical indexed variation, catalog module recipes and typed channel lowering must be compared rather than identified by source names.
- **Minimum new implementation surface:** a bounded six-coupling inventory, two exact coordinate/pairing derivations, a read-only audit, tests and evidence. No new active source, physical action, catalog or state ledger.
- **Structure-preservation obligations:** literal source couplings, component identity derivatives, evaluation duality, Gram inverse, H covariance, conjugation, the induced bracket, ordinary derivative prolongation and the distinction between quantum and background actions. A valid abstract map is not proof that historical coordinates implement it.
- **Stopping condition:** first incompatible or underdetermined historical decoder prerequisite, or completed bounded decoder adjudication. No full interacting reconstruction, 17-image replacement, HB1/C5, catalog dimensions, ranks, EOM quotient, cohomology, finite C1_GS or later gates.
- **What is deactivated on failure:** the proposed historical-to-canonical identification remains unqualified. Preserve all historical evidence and the qualified control; no existing scientific artifact is deleted or rewritten.

## Preregistered derivation and decisive controls

Inventory the six S33 couplings and their source-left ordered ASTs. Recover each forward image by the frozen indexed left Euler operation and compare it with the exact frozen full-Weil field image. Record dimensions, parity, ghost number, Lorentz slots and independent/composite/background status from existing alphabet authority.

Compare three distinct historical layers: (1) source-coupling/indexed-variation component convention; (2) CAT1 source module recipes; (3) INT12/REG7 typed physical source columns. Do not silently treat a carrier label as an evaluation covector or insert a Gram tensor absent from the literal AST. REG7 representation pairings alone do not prove a canonical BV map. Examine whether they actually bind the six source occurrences.

For the actual residual H basis, reconstruct the full Gram matrix from frozen physical columns, its inverse and conjugation. Derive evaluation action from invariance of `J^T z`: if `L z=M z`, then `L J=-M^T J`. A carrier identification `J=P k` with unchanged fields must satisfy `N^T P+P M=0`; its bracket is `(-1)^p P^-T`, not an identity bracket unless P is identity. Test the entire 12-generator H block and freeze the first nonzero component in lexicographic generator/row/column order. Test both light source roles, K_q and L_c, with all other source types inventoried.

Replay the decisive source-pairing equations using direct physical generator commutators and component sums, not the primary decoder result or source table. Freeze primary and replay before comparison. State shared assumptions and Python/SymPy dependencies accurately.

The decisive bridge gate uses the already-frozen INT8 physical primal columns/extractors and INT12 dual-column formula, not source labels. For each source derive the exact triangle between AST evaluation components, C3/catalog carrier components and REG7 channel components. Require both inverse products, the literal evaluation pairing, physical reconstruction and conjugation. Derive the channel bracket from that triangle; never retain an identity bracket after changing only source coordinates. The field/source project bases may differ, especially for Lambda_H. Sparse factorized matrix digests may be used for the 328-dimensional scalar decoder rather than duplicating dense data. If these six triangles pass, qualify only the bounded coordinate decoder and permit a separately scoped interacting-reconstruction proposal. This does not repair legacy implementation code or prove the full M08 domain.

If the existing bytes do not establish one compatible historical map, classify precisely which layers are incompatible or unresolved. A conditional `J=G k` repair may be displayed to explain the missing obligation, but is not adopted and must not be used to alter historical Sigma. Stop before testing a full replacement. Reconcile the three prospective nonminimal source types only as unactivated grade/pairing obligations. Reuse the qualified joint-domain transport as explicitly identified immutable evidence, not a fresh full-domain qualification.

## Authority and validation

Formal authority stays 34/39; Sigma, six couplings, all frozen B_Sigma images, corrected R_H convention, JCAT/T5 and project_state bytes remain unchanged. Historical negative controls remain bound evidence. No source activation, GPU, remote push or specialist endorsement. External review is outstanding.

Require exact bounded regeneration, independent replay comparison, meaningful wrong-pairing and false-promotion mutations, inherited byte bindings retained verbatim, authority coherence and zero audit-time workspace/active-data mutation. Instrument wall/CPU/process peak and OS I/O; unmeasured subdivisions remain explicit. Use the existing pole-blind guard for Python validation. Do not rebuild T5. Strict historical custody may remain exit 2; do not claim unrestricted validation PASS. Commit locally after bounded validation and stop.
