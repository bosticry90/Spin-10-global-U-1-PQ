"""Real structure, local-parameter witnesses and distinct physical replay."""
from a10_e3_symmetry_common import *

def build(stage=lambda n,f:f()):
    from audit_a10_e3_symmetry import adjudicate
    p,r=[read(OUT/(n+'.json')) for n in ('primary','replay')];match=adjudicate(p,r)
    w,old,e1,e2,cols,psi,A,fixed,S1,delta=inputs('primary')
    ops={tag:{n:decode_typed(P) for n,P in I.items()} for tag,I in p['operators'].items()}
    Tq,Tb,Tp=[ops[n] for n in ('Tq_geometric','Tb_geometric_and_transported','Tq_transported')]
    def project(P,allowed):return canonical({word:c for word,c in P.items() if all(n in allowed for n,jets in word)})
    minimal=project(decode_typed(p['action_Wards']['geometric_quantum_breaking']),{'b0','omega0'})
    G=mat(old['architecture']['gauge_metric_C3']);box=w.add(*(w.scale(w.var('omega0',(mu,mu)),ETA[mu]) for mu in range(4)))
    assert minimal==canonical(w.scale(w.mul(w.var('b0'),box),-G[0,0]))
    eb=canonical(w.EL(minimal,'b0'));assert eb
    defect=project(decode_typed(p['BRST_compatibility']['geometric_quantum_commutator']['Jb0']),{'omega0'})
    assert defect==canonical(w.scale(box,G[0,0]))
    source=project(decode_typed(p['source_transport_corrections']['quantum']['Jbar0']),{'omega0'})
    assert source==canonical(w.scale(box,-G[0,0]))
    assert not {word:c for word,c in minimal.items() if all(not jets for n,jets in word)}
    # Incorrectly holding Abar fixed in a background transport reproduces the
    # nonzero quantum correction rather than the actual zero Tb correction.
    missing={n:rows(w.add(Tp[n],w.scale(Tb[n],-1))) for n in w.grades if Tp[n]!=Tb[n]}
    assert missing and source
    # Reject a source transpose sign independently of any field bilinear.
    first=next((a,b) for a in IDS for b in IDS if any(n==f'C{b}' for word in Tq[f'C{a}'] for n,jets in word))
    a,b=first
    correct=w.add(w.bracket(Tq[f'C{a}'],w.var(f'JC{b}')),w.bracket(w.var(f'C{a}'),Tq[f'JC{b}']))
    zero(correct,'GEOMETRIC_CANONICAL_PAIRING')
    sign_witness=canonical(w.add(w.bracket(Tq[f'C{a}'],w.var(f'JC{b}')),w.bracket(w.var(f'C{a}'),w.scale(Tq[f'JC{b}'],-1))))
    assert sign_witness
    # Arithmetic adversaries sample both ends of representative columns.
    # The full E3 comparison is independent and exhaustive in its declared
    # coefficient scope; these 64-word windows do not enumerate Q source
    # squares or repeat the slow reference expansion of whole columns.
    fast_checks=0
    for n in ['B0_0','C13','ub13','L13','bar0','b0','x_Phi_0','x_Sigma_0','x_phi_0','x_S_0',
      'JB0_0','JC13','Jub13','JL13','Jbar0','Jb0','Jx_Phi_0','Jx_Sigma_0','Jx_phi_0','Jx_S_0']:
        for images,parity,P in ((Tq,0,fixed[n]),(fixed,1,Tq[n])):
            words=sorted(P);selected_words=set(words[:32]+words[-32:])
            P={word:P[word] for word in selected_words}
            zero(w.add(act(P,w,images,'primary',parity),w.scale(w.act(P,images,parity),-1)), 'CACHED_PREFIX_VS_PRESERVED_ENGINE',n);fast_checks+=1
    inverse_checks=0
    negative={J:w.scale(P,-1) for J,P in A.items()}
    for I,expected in ((Tp,Tq),(Tb,Tb)):
        inverse,_=transport(I,negative,w,'primary')
        for n in I:zero(w.add(inverse[n],w.scale(expected[n],-1)),'INVERSE_OPERATOR_TRANSPORT',n);inverse_checks+=1
    # All physical-plane reality involutions, including local parameter jets.
    Q=mat(old['architecture']['C3_to_plane_field']);C=(Q.inv()*Q.conjugate()).applyfunc(clean)
    CJ=(Q.T*Q.inv().T.conjugate()).applyfunc(clean);conj={};groups=[]
    def block(names,K):
        groups.append((names,K))
        for i,n in enumerate(names):conj[n]=w.add(*(w.scale(w.var(names[j]),v) for (k,j),v in K.todok().items() if k==i))
    for mu in range(4):
        block([f'B{a}_{mu}' for a in IDS],C);block([f'JB{a}_{mu}' for a in IDS],CJ)
        block([f'A{h}_{mu}' for h in H],C[:12,:12])
    block([f'C{a}' for a in IDS],C);block([f'JC{a}' for a in IDS],CJ)
    for pre in ('omega','beta'):block([pre+str(h) for h in H],C[:12,:12])
    for pre in ('ub','L'):block([pre+str(i) for i in M],mat(e1['charts']['blocks']['heavy_dual']['conjugation']))
    for pre in ('Jub','JL'):block([pre+str(i) for i in M],mat(e1['charts']['blocks']['heavy_dual']['source_conjugation']))
    for pre in ('bar','b'):block([pre+str(h) for h in H],mat(e1['charts']['blocks']['light_primal']['conjugation']))
    for pre in ('Jbar','Jb'):block([pre+str(h) for h in H],mat(e1['charts']['blocks']['light_primal']['source_conjugation']))
    for sec,n in DIM.items():
        for pre in ('x_','Jx_'):block([f'{pre}{sec}_{i}' for i in range(n)],s.eye(n))
    real_checks=0
    for tag,I in ops.items():
        for names,K in groups:
            if names[0] not in I:continue
            for i,n in enumerate(names):
                star=w.replace({word:s.conjugate(c) for word,c in I[n].items()},conj)
                expected=w.add(*(w.scale(I[names[j]],v) for (k,j),v in K.todok().items() if k==i))
                zero(w.add(star,w.scale(expected,-1)),'OPERATOR_REAL_STRUCTURE',tag+':'+n);real_checks+=1
    jets=0
    selected=['B0_0','B13_1','C0','C13','ub13','L13','bar0','b0','x_Phi_0','x_Sigma_0','x_phi_0','x_S_0',
      'JB0_0','JB13_1','JC0','JC13','Jub13','JL13','Jbar0','Jb0','Jx_Phi_0','Jx_Sigma_0','Jx_phi_0','Jx_S_0','A0_0','A11_3']
    for I in ops.values():
        for n in selected:
            for mu in range(4):
                for indices in ((mu,),(mu,mu)):
                    zero(w.add(act(w.var(n,indices),w,I,'primary'),w.scale(w.dword(I[n],indices),-1)), 'JET_PROLONGATION',n);jets+=1
    try:w.D(w.var('omega0',(0,)*6),0)
    except RuntimeError:cap=True
    else:raise AssertionError('JET_RESOURCE_CAP_RETURNED_ZERO')
    rejected=[]
    for flag in ('candidate_adopted','sources_activated','E4_E5_executed','Stage_E_completed','HB1_C5_run','C1_GS_calculated',
      'catalog_rebuilt','historical_equivalence_proved','physical_gauge_independence_established',
      'quantum_master_equation_established','auxiliaries_eliminated','external_endorsement','personal_outreach'):
        u,v=dict(p),dict(r);u[flag]=v[flag]=True
        try:adjudicate(u,v)
        except AssertionError:rejected.append(flag)
        else:raise AssertionError('FALSE_E3_PROMOTION_'+flag)
    u,v=dict(p),dict(r);u['contract']=dict(p['contract']);v['contract']=dict(r['contract'])
    u['contract']['H_generators']=v['contract']['H_generators']=45
    try:adjudicate(u,v)
    except AssertionError:bad_background_rejected=True
    else:raise AssertionError('INVENTED_FULL_BACKGROUND_ACCEPTED')
    u=dict(p);u['operators']={tag:dict(I) for tag,I in p['operators'].items()}
    u['operators']['Tq_transported']['Jbar0']=[]
    try:adjudicate(u,r)
    except AssertionError:changed_column_rejected=True
    else:raise AssertionError('CHANGED_TRANSPORTED_SOURCE_COLUMN_ACCEPTED')
    from a10_e3_symmetry_exterior_control import build as exterior
    control=stage('distinct_exterior_full_physical_E3_replay',lambda:exterior(stage))
    return {'schema':'A10_E3_ADVERSARIAL_CONTROLS_V1','status':'PASS_E3_ADVERSARIAL_AND_PHYSICAL_REPLAY',
      'matching_result':match,'minimal_quantum_Ward':rows(minimal),'minimal_quantum_Euler_b0':rows(eb),
      'minimal_geometric_Qprime_Tq_Jb0':rows(defect),'required_transported_Jbar0_correction':rows(source),
      'constant_parameter_projection_hides_minimal_failure':True,'missing_background_transport_source_columns':missing,
      'wrong_source_transpose_sign_witness':rows(sign_witness),'wrong_source_transpose_pair':list(first),
      'cached_prefix_preserved_engine_checks':fast_checks,'inverse_operator_transport_checks':inverse_checks,
      'reference_engine_window_monomials_at_most':64,'full_source_squares_enumerated':False,
      'complete_real_structure_operator_checks':real_checks,'first_and_second_jet_transport_checks':jets,
      'jet_resource_cap_raises':cap,'false_promotion_flags_rejected':rejected,
      'invented_45_background_rejected':bad_background_rejected,'changed_source_column_rejected':changed_column_rejected,
      'exterior_control':control,
      'E4_E5_executed':False,'sources_activated':False,'historical_equivalence_proved':False,
      'historical_controls':'all eleven sealed predecessor chains retained unchanged'}
