# E5 polynomial regularity and resolution: bounded result

The inactive, ungauge-fixed gauge/scalar action admits the polynomial regularity
chart and complete Noether/Koszul-Tate resolution stated in the V1 contract.
Its minimal differential also has the verified normality filtration. This is a
qualified prerequisite; the full E5, quantum and unification goals remain open.

The [derivation](A10_E5_REGULARITY_DERIVATION_V1.md) supplies an all-order
triangular inverse, a complete identity-module argument and a graded counting
homotopy. Every finite-support polynomial is covered. No physical coupling,
mass, field or potential coefficient is inverted. The proof includes g10=0,
all four scalar sectors, the fixed vacuum and all 29 potential directions.

## New exact evidence

Primary evaluates the literal gauge Euler AST and qualified scalar kinetic
ASTs. Replay independently varies the free first-jet physical density. All
508 principal Euler columns agree. The literal density scan confirms that
interactions have lower derivative order and the potential has no derivatives.

Finite controls at jet orders 2, 3, 4 and 5 compare 27,503 independent equation
pivots. Their diagonals are -1 and their same-order off-diagonal pivot entries
are triangular. The independent equation counts are 508, 2,495, 7,395, 17,105;
dependent counts are 0, 45, 225, 675. Those controls test the implementation.
The written induction establishes all orders; finite matrix ranks alone do not.

All 45 ghost-antifield Noether covectors match, comprising 33,478 coefficients.
Primary extracts their antifield-number-one physical part from the sealed
columns. Replay derives them from the physical field source action by left
gradient differentiation and integration by parts. The actual source-left
divergence coefficient is +1. The complete interacting Noether identities and
representation/potential invariance are authenticated predecessor proofs, not
newly expanded here. The unit-triangular prolonged identity matrix accounts for
all dependent equations modulo trivial Koszul relations.

The full 45-doublet nonminimal sector has a new explicitly typed point chart
beta=Q eta. Its constant auxiliary coefficient gives a polynomial inverse.
Two derivations agree on all 270 ghost/nonminimal coordinate and source maps.
They check 18,225 field/source pairings, 9,180 source/source and 9,180 field/field
pairings, 270 inverses and 540 first-jet maps. All 45 beta squares vanish. The
complete ghost/nonminimal source block transforms into a 488-coefficient
minimal-ghost plus doublet block; the other 508 pairs are spectators.
No sources or auxiliary fields are discarded. E2 transports this resolution
with its filtration; it is not a claim about the naive old-chart grading.

Omitting the ghost-source cotangent correction gives the exact cross-pairing
defect -i g10 ub13/sqrt(2). Transporting fields alone leaves 1,304 nonzero action
coefficients. These negative controls show why the complete canonical map is
required. The 64 graded homotopy monomial controls agree; removing the ghost
antifield leaves the dependent closed variable v without its primitive.

PQ remains global, with frozen scalar charges 0,2,-2,-4. A singlet local-PQ
parameter variation has nonzero Euler derivative

    -4 (y Box x - x Box y).

It is not an extra off-shell local Noether identity. A constant-parameter check
misses this distinction. This preserves the 45-generator gauge architecture
without fixing the global PQ quotient or studying anomalies.

## Execution, validation and limits

The initial primary attempt stopped on an unsupported AST wrapper lookup before
the principal calculation. Its traceback, execution fingerprint and FAILED
classification are retained in primary_attempt_1.json and excluded from PASS.
The parser was corrected to support both existing binder child conventions.
No scientific residual was changed to manufacture success. Completed primary
and replay runs preserve prospective code/contract/input/runtime fingerprints.

The validation receipt records the exact checks, fresh byte-identical replay,
runtime, protected hashes and local authority controls. Sixteen new regressions
supplement the existing relevant scientific, execution and governance suites.
Seventeen predecessor manifests authenticate; expensive qualified physical,
representation and source expansions are reused. The broader workspace audit
is size/mtime metadata; protected evidence is checked by byte hashes. The result
does not claim a formal proof-kernel certificate or external endorsement.

The comparison with [Barnich, Brandt and Henneaux](https://arxiv.org/html/hep-th/0002245)
is established mathematics applied to this specific action and polynomial ring.
Both routes share immutable data, graded arithmetic, Python/SymPy and analyst.
H(delta) is proved here; H(delta modulo d), characteristic-current cohomology
and Lorentz/Ward/basic-restricted homotopies are different obligations. The
canonical nonminimal contraction in the full complex does not authorize source
deletion or prove reduction inside the joint basic domain.

W1-W7 remain conditional on A1-A5. No actual quantum prescription, QAP,
restoration, anomaly freedom, renormalized insertion or quantum canonical
equivalence has been established. The fermion/Yukawa sector remains outside
this candidate. No force matching, global scalar boundedness, particle
prediction, proton lifetime or gravity conclusion follows.

project_state.json remains 34/39. M08/HB1/C5 stay blocked, C1_GS uncalculated,
historical custody exit 2/seven references unresolved. There is no activation,
catalog change, publication, personal contact or push. The Spin(10) x U(1)PQ
completion goal remains active and larger than this bounded milestone.

## Next scientific increment

Use this regularity/normality certificate to examine the theorem's actual
local-functional domain and primitive space: H(delta modulo d), global-current
terms, background spectators and the joint Ward/insertion/basic conditions.
Prove any asserted full/basic or intrinsic/induced comparison explicitly.
The new noncovariant full-complex homotopy is not a substitute for that bridge.
Actual discharge of A1-A5 remains a separate quantum obligation.
