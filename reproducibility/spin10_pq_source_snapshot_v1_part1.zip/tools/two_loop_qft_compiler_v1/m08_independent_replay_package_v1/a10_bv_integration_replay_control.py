"""Independent exterior-ring BV control from physical Spin(10) matrices.

This is a closed three-plane, two-coordinate diagnostic, not the all-45
qualification. Its role is to challenge the structural proof and bracket
implementation with independently differentiated physical/source densities.
"""
from itertools import combinations
import sympy as s
from nonminimal_bv_free import Jets
from source_convention_control import Exterior
from a10_bv_integration_common import g

class Control(Jets):
    def __init__(self,fields):
        self.fields=fields;self.pairs=[(z,'J'+z) for z in fields]
        self.grades=fields|{J:(3-d,-1-gh,1-p) for z,J in self.pairs for d,gh,p in [fields[z]]}
        self.a=Exterior();self.meta={};self.values={};self.limit=6;self.max_order=0;self.cache={}
        for name in self.grades:self.var(name)
    def var(self,base,indices=()):
        indices=tuple(sorted(indices))
        if len(indices)>self.limit:raise RuntimeError('JET_LIMIT_NOT_ZERO')
        name=base+('__'+''.join(map(str,indices)) if indices else '')
        if name not in self.meta:
            self.meta[name]=(base,indices);self.values[name]=self.a.variable(name,self.grades[base][2])
            self.max_order=max(self.max_order,len(indices))
        return self.values[name]
    def bracket(self,F,G):
        a=self.a
        return a.add(*(a.scale(a.add(a.mul(self.euler(F,z,'right'),self.euler(G,J)),
             a.scale(a.mul(self.euler(F,J,'right'),self.euler(G,z)),-1)),(-1)**self.grades[z][2]) for z,J in self.pairs))
    def columns(self,S):return {n:self.euler(S,other) for z,J in self.pairs for n,other in ((z,J),(J,z))}
    def Q(self,P,images):
        key=id(images)
        if key not in self.cache:self.cache[key]=(images,{})
        owner,cache=self.cache[key];assert owner is images
        for n in self.support(P):
            if n not in cache:
                base,jets=self.meta[n];cache[n]=self.multiD(images.get(base,{}),jets)
        return self.a.derive(P,{n:cache[n] for n in self.support(P)})
    def rows(self,P):
        out={}
        for odds,c in P.items():
            even=sorted((x for x in c.free_symbols if str(x) in self.meta),key=str)
            terms=s.Poly(c,*even).terms() if even else [((),c)]
            sign=(-1)**sum(a>b for i,a in enumerate(odds) for b in odds[i+1:])
            for powers,value in terms:
                word=tuple(sorted(list(odds)+[str(x) for x,k in zip(even,powers) for _ in range(k)]))
                out[word]=s.expand(out.get(word,0)+sign*value)
        return [{'word':list(word),'coefficient':str(s.simplify(c))} for word,c in sorted(out.items()) if c]

def geometry():
    # Three planes T01,T02,T12 form a closed physical Spin(10) subalgebra.
    T=[]
    for i,j in ((0,1),(0,2),(1,2)):
        A=s.zeros(3);A[i,j]=1/s.sqrt(2);A[j,i]=-1/s.sqrt(2);T.append(A)
    f={(k,a,b):s.simplify(-s.trace(T[k]*(T[a]*T[b]-T[b]*T[a])))
       for k in range(3) for a in range(3) for b in range(3)}
    E=[s.diag(1,-1,0)/s.sqrt(2),s.diag(1,1,-2)/s.sqrt(6)]
    for i,j in ((0,1),(0,2),(1,2)):
        A=s.zeros(3);A[i,j]=A[j,i]=1/s.sqrt(2);E.append(A)
    rho=[s.Matrix(5,5,lambda i,j:s.simplify(s.trace(E[i]*(A*E[j]-E[j]*A)))) for A in T]
    for a,b in combinations(range(3),2):
        assert (rho[a]*rho[b]-rho[b]*rho[a]-sum((f[k,a,b]*rho[k] for k in range(3)),s.zeros(5))).applyfunc(s.simplify)==s.zeros(5)
    return f,rho

def build(stage=lambda n,f:f()):
    f,rho=geometry()
    fields={**{f'B{a}_{mu}':(1,0,0) for a in range(3) for mu in range(2)},
        **{f'x{i}':(1,0,0) for i in range(5)},**{f'C{a}':(1,1,1) for a in range(3)},
        **{f'bar{a}':(1,-1,1) for a in range(3)},**{f'b{a}':(2,0,0) for a in range(3)}}
    j=Control(fields);a=j.a;x={n:j.var(n) for n in j.grades};eta=(1,-1)
    F={k:a.add(j.D(x[f'B{k}_1'],0),a.scale(j.D(x[f'B{k}_0'],1),-1),
        *(a.scale(a.mul(x[f'B{b}_0'],x[f'B{c}_1']),g*v) for (k0,b,c),v in f.items() if k0==k and v)) for k in range(3)}
    Z={(i,mu):a.add(j.D(x[f'x{i}'],mu),*(a.scale(a.mul(x[f'B{k}_{mu}'],x[f'x{q}']),g*R[i,q])
        for k,R in enumerate(rho) for q in range(5) if R[i,q])) for i in range(5) for mu in range(2)}
    norm=a.add(*(a.mul(x[f'x{i}'],x[f'x{i}']) for i in range(5)))
    m,lam=s.symbols('mPhi2 lambdaPhi1',real=True)
    S0=a.add(*(a.scale(a.mul(P,P),s.Rational(1,2)) for P in F.values()),
        *(a.scale(a.mul(P,P),s.Rational(1,2)*eta[mu]) for (i,mu),P in Z.items()),
        a.scale(norm,-m),a.scale(a.mul(norm,norm),-lam))
    R={}
    for k in range(3):
        for mu in range(2):R[f'B{k}_{mu}']=a.add(j.D(x[f'C{k}'],mu),*(a.scale(a.mul(x[f'B{b}_{mu}'],x[f'C{c}']),g*v)
            for (k0,b,c),v in f.items() if k0==k and v))
        R[f'C{k}']=a.add(*(a.scale(a.mul(x[f'C{b}'],x[f'C{c}']),-g*v)
            for (k0,b,c),v in f.items() if k0==k and b<c and v))
        R[f'bar{k}']=a.scale(x[f'b{k}'],-1);R[f'b{k}']={}
    for i in range(5):R[f'x{i}']=a.add(*(a.scale(a.mul(x[f'C{k}'],x[f'x{q}']),-g*A[i,q])
        for k,A in enumerate(rho) for q in range(5) if A[i,q]))
    S1=a.add(*(a.mul(x[J],R[z]) for z,J in j.pairs));S=a.add(S0,S1)
    columns=stage('exterior_direct_full_Euler_columns',lambda:j.columns(S))
    checks=[]
    for n in j.grades:
        residual=j.Q(columns[n],columns)
        assert not residual,('EXTERIOR_FULL_SOURCE_SQUARE',n,j.rows(residual)[:8])
        checks.append(n)
    E={z:j.euler(S0,z) for z in fields}
    current=[a.add(*(a.scale(a.add(a.mul(E[f'B{k}_{mu}'],x[f'C{k}']),
        a.mul(x[f'JB{k}_{mu}'],R[f'C{k}'])),2) for k in range(3))) for mu in range(2)]
    master=j.bracket(S,S);residual=a.add(master,*(a.scale(j.D(P,mu),-1) for mu,P in enumerate(current)))
    assert not residual,('EXTERIOR_MASTER_BOUNDARY',j.rows(residual)[:8])
    # First jets are actual off-shell polynomials, not substituted Fourier modes.
    for n in j.grades:
        for mu in range(2):assert not j.Q(j.Q(j.var(n,(mu,)),columns),columns)
    return {'schema':'A10_INDEPENDENT_EXTERIOR_SPIN10_BV_CONTROL_V1','status':'PASS_EXACT_DIAGNOSTIC',
        'physical_plane_indices':[0,1,9],'scalar_representation':'5-coordinate symmetric traceless tensor on the selected three planes',
        'canonical_pairs':len(j.pairs),'full_generator_squares':checks,'first_jet_squares':2*len(checks),
        'master_density':j.rows(master),'boundary_current':[j.rows(P) for P in current],
        'master_minus_divergence':[],'Euler_columns':{n:j.rows(P) for n,P in columns.items()},
        'new_physical_parameters':False,'control_potential':'restriction -mPhi2 tr(Phi^2)-lambdaPhi1 tr(Phi^2)^2',
        'scope':'independent arithmetic/variation diagnostic, not an all-45 expansion or a substitute for full candidate proofs',
        'EOM_used':False}

def wrong_free_Euler_control():
    fields={'B0':(1,0,0),'B1':(1,0,0),'C':(1,1,1)}
    j=Control(fields);a=j.a;x={n:j.var(n) for n in j.grades}
    F=a.add(j.D(x['B1'],0),a.scale(j.D(x['B0'],1),-1))
    S=a.add(a.scale(a.mul(F,F),s.Rational(1,2)),a.mul(x['JB0'],j.D(x['C'],0)),a.mul(x['JB1'],j.D(x['C'],1)))
    Q=j.columns(S);assert not j.Q(Q['JC'],Q)
    wrong=dict(Q);wrong['JB1']=a.scale(Q['JB1'],-1)
    residual=j.Q(wrong['JC'],wrong)
    assert residual
    return {'correct_ghost_source_square':[],'wrong_spatial_Euler_ghost_source_square':j.rows(residual),
        'classification':'violates off-shell Maxwell Noether; detects the historical free-Lorentz sign error',
        'boundary_adjudication':'nonzero local Q^2 JC; no EOM or boundary equivalence applies to generator nilpotence'}
