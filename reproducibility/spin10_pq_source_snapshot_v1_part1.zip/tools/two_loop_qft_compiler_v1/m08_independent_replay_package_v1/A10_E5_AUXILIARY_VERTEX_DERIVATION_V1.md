# Prospective auxiliary cubic calculation

Use the literal E2 gauge-fixing polynomial and previously qualified full
reference inverse. The selected pole has external Lambda, antighost and ghost.
Its total coupling is g*xi^2. For a one-loop graph E_internal=V, hence the
external leg count is sum(degree(vertex)-2). With three external legs, the
allowed connected 1PI forms are three cubics or one cubic plus one quartic.

The actual order-xi vertex is Lambda/ubar/u; it has no explicit g. The order-g
ghost vertex has one derivative and a gauge field. Its gauge field must join
an internal Lambda through the mixed propagator. The g vertex is attached to
either external antighost or external ghost. The first derivative is external
and lowers the UV degree; the second derivative is internal and can give a
logarithm together with the mixed propagator. Compute both, with an explicit
UV-degree argument for a vanishing logarithmic coefficient.

The actual order-g*xi quartic has four ghosts and no derivative. Join its
remaining ghost pair to the order-xi vertex carrying external Lambda. Take
the complete graded Hessian, including every external split, before its trace.
No auxiliary tadpole/onePR bridge or scalar/orbit term may be counted as a
missing cancellation without its leg/coupling/UV proof.

In the real heavy frame let A_a=P_M ad(e_a)|_M. Reconstruct the triangle
matrix products through actual contractions. Reconstruct the quartic from
the physical tensors f_i k a f_a b c with their graded factorials; the primary
also varies the literal canonical quartic and pulls its covector back. Do not
assume an ordinary representation closure for the projected A_a: the coset
is nonsymmetric, and residual-H contributions cannot be discarded.

For the logarithmic homogeneous term use the UV radial domain k_E^2>R^2,
R>0. The four-dimensional analytic radial residue of integral 1/(k_E^2)^2 is
1/(16pi^2). The independent dimensional scalar bubble at nonexceptional
momentum has the same residue. Applying zero-momentum Taylor only to the UV
homogeneous term is valid when its remaining terms have negative UV degree;
it does not set the full massless amplitude or its IR contribution to zero.
The physical IR limit and finite cutoff/contact restoration remain open.

The candidate is read from frozen_a10_e5_joint_normalization unchanged.
Convert both actual pole and candidate into Lambda*ubar*C order and compare
all33*33*45 coefficients. A real nonzero Euler derivative forbids an ordinary
divergence explanation. A mismatch ends this gate; prospective additional
fermion tensors are not adopted within this calculation.
