# E5 actual auxiliary–antighost–ghost companion contract

1. Question: does the complete actual one-loop g*xi^2 Lambda-ubar-C pole
   equal the corresponding projection of the qualified inactive joint
   normalization? Baseline93ef4f0, statev113/34of39,29 sealed parent chains.
2. Preserve all643 field/source pairs,48 H backgrounds,34 physical/nine source
   terms, E2 gauge fixing, potential/vacuum/parameters, both nonminimal sectors,
   actual nonsymmetric coset and composite R_H. No activation or elimination.
3. Typed external scope:33 dual-heavy Lambdas,33 dual-heavy antighosts and
   all45 primal ghosts, with real physical frames used before comparison.
   Retain all49,005 tensor entries including zeros/H channels. Canonical
   evaluation pairing, carrier Gram and Lorentz metric remain distinct.
4. Prove complete graph coverage from the literal E2 polynomial at g*xi^2.
   One-loop three-point leg counting admits three cubics or cubic/quartic.
   Retain both external assignments to the g derivative ghost vertex and
   xi Lambda/ubar/u vertices. Include the complete g*xi quartic with the
   xi cubic. No symmetric-coset shortcut or convenient partial ghost action.
5. Primary graded Fourier Hessians/Born words include every required order
   and odd start. Replay independent Gaussian/Wick contraction derives the
   elementary signs and physical10 commutator contractions. Independent
   derivations must not merely assume the candidate tensor is the loop result.
6. Extract UV logarithms only after separating the UV region |k_E|>R>0,
   or by a justified nonexceptional construction. Zero external momenta may
   be used in the divergent homogeneous UV term, never as a whole massless
   integral. Establish that the omitted external-momentum terms are UV
   convergent. Retain all4 Lorentz contractions and the full qualified mixed
   B-Lambda/odd inverse, with G_Lambda,Lambda=0. No new physical mass.
7. Compute the triangle and complete quartic bubble tensor separately in
   both routes. Include H external-ghost channels and prove any zeros. Pull
   the literal primary quartic into its proper physical frame; replay derives
   it from physical commutators. Use the correct odd right/left Hessian.
8. Directly extract the g*xi^2 cubic projection from the complete47,958-term
   joint candidate, including the width primitive's full Q image. Compare
   every coefficient, not just symmetry or sampled rays. Preserve all other
   projections. A nonzero difference needs an exact real Euler witness.
9. First essential mismatch/underdefinition stops this comparison before
   JC-C-C/JB-B-C loops or any normalization adoption. Do not insert a fitted
   interaction or new primitive to force this gate to pass. A possible
   further unphysical primitive is a separately classified next investigation.
10. Negative controls omit the quartic, nonzero triangle, nonsymmetric tensor,
    mixed propagation, odd/Lorentz/Gram factor or confuse the UV Taylor
    extraction with an exceptional scaleless integral. Fresh own-byte replay,
    strict start hashes,29 parents, protected/new/state hashes and metadata.
11. Keep pole matching, evidence validation, classical exactness, quantum
    restoration, source/contact equivalence and physical predictions separate.
    No finite/IR/anomaly/all-Ward/A5/E5 claim follows from this selected pole.
12. Solo review; shared immutable input/charts/arithmetic/Python/SymPy/analyst
    disclosed. Custody2/seven, not PASS. No catalogs/HB1/C5/C1_GS/matching,
    authority change, outreach/publication/push. Validate before local commit.
    Whole Spin(10)xglobal U(1)PQ goal stays active/incomplete, including global
    boundedness/PQ quotient, full fermion/Yukawa and phenomenology obligations.
