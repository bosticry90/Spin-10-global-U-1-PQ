# Bounded historical M08 source-component decoder

## Disposition

**Qualified bounded six-source coordinate decoder; not a full M08 repair.**

The six literal source couplings are recovered exactly, and two routes agree on six physical coordinate triangles linking AST evaluation components, C3/catalog macro components and REG7 channel components. This earns only the prerequisite needed to prepare a separately scoped interacting reconstruction proposal. It does not authorize that reconstruction, added active sources, HB1 or C5. Formal authority remains **34/39**; finite C1_GS remains uncalculated.

The assessment of `57db593` correctly identifies a qualified small joint-domain control, not a full physical master action. Its historical-source decoder uncertainty can now be narrowed with actual component evidence rather than source labels.

## What was decoded

Every S33 coupling is an explicitly source-left ordered product inside its existing group/Lorentz contraction. Fresh indexed left source Euler derivatives reproduce all six frozen forward images byte-content-exactly at AST level. Independent ordered-source extraction reproduces the same expressions. No Gram matrix is inserted into the historical AST.

| Historical AST source | Paired field | Map from CAT macro components to AST evaluation components |
|---|---|---|
| K_V | V_H | identity, with evaluation-dual heavy source |
| K_q | q_L | `J_AST=G_H k_macro` |
| K_phi | eta_328 / phi | identity in the frozen 328-coordinate evaluation convention |
| L_u | u_H | identity, with evaluation-dual heavy source |
| K_Lambda | Lambda_H | identity; Lambda is dual and its source is double-dual |
| L_c | c_L | `J_AST=G_H k_macro` |

These are coordinate meanings, not alterations to source couplings. Internal component dimensions are 33, 12, 328, 33, 33 and 12; vector roles retain their frozen Lorentz pairing. This is not a new determination of Lorentz signature or a census of full spacetime/vector components.

CAT1's two light source rows use primal adjoint recipes. INT12 instead gives them explicit dual physical columns. Both can be represented coherently, but their same-named coordinates cannot be identified numerically. The physical-column triangle supplies the missing bridge.

## Exact triangle and bracket

Let F embed AST field coordinates into physical components; X and Y embed typed field and source channels. With the existing normalized physical extractors,

`z_AST=T z_channel`, `T=F_left_inverse X`,

`J_AST=E k_channel`, `E=F^T Y`,

`E_inverse=A_source F^-T`.

All six maps pass both inverse products, physical reconstruction, the literal evaluation identity `E^T T=Y^T X`, and conjugation transport. The light macro bridge is fixed by the actual C3 physical basis: its Gram matrix is `G_H=F^T F`, not identity. REG7's partner columns and dual-row/primal-column orientation are retained; Lambda's dual field basis is not replaced by a primal one.

Changing only sources gives the bracket `(-1)^p E^-T`. Changing both fields and sources gives `(-1)^p T_inverse E_inverse^T`, the inverse-transpose of the terminal pairing. Neither change licenses retaining an identity bracket by default. The candidate canonical antifield remains `z_star=(-1)^p J_AST`; none of this repairs the historical mixed variational convention or frozen B_Sigma images.

Sparse matrix shapes, entry counts and canonical sparse digests are frozen. The exact matrices are generated from bound physical columns, extractors, C3 bases and REG7 factors; the 328-dimensional maps are not duplicated as dense artifacts.

## Negative controls that remain nonzero

Using the same primal action for source and field while retaining an identity evaluation pairing produces

`[N^T+M]_(generator 0, source 4, image 4)=-sqrt(2) i`.

The two routes reproduce this for both light source meanings, with all 12 H generators examined. Replay checks 1,728 component pairing equations. Correct evaluation duality or the correctly weighted carrier pairing cancels the residual; a global sign tweak is not the coordinate decoder.

The literal selected identity-pairing coefficient is 1, whereas inserting G without changing the original source variable would give 0 in that slot. That is why reexpressing a source via a coordinate map must not be confused with modifying its coupling. All old -2i, +1, -Box(u), scalar +1 and Sigma-nonhorizontal evidence remains byte-bound and unchanged.

## Domain and prospective partners

Constant, even, invertible source maps preserve grades and commute with ordinary differentiation. With the induced bracket and simultaneous conjugation of Q, Tq, iota and Tb, operator identities and their joint kernels transport exactly. This gives coordinate compatibility with the previously qualified control; it is not a new full-M08 domain-preservation theorem. Quantum and background actions remain distinct, and independent-parameter variation must precede field-dependent substitution.

The preceding 40-generator joint-domain model is explicitly reused as immutable evidence, not rerun or identified with the historical interacting action. No assumption that Sigma itself is basic is added.

The prospective partners remain specifications only: K_ubar (33 components, dimension 2, ghost 0, even), K_cbar (12, 2, 0, even), and K_lambda (12, 1, -1, odd). Their canonical pairing must follow the actual nonminimal field components. In particular, the light nonminimal field macro/typed meanings must be reconciled in the full architecture, not inferred from their self-dual labels. No partner is activated, source term added or catalog extended.

## Independence and validation scope

Primary uses frozen indexed Euler lowering and stored physical extractors. Replay independently extracts the source-left word, reconstructs 990 physical parent commutators and recalculates physical-column inverses from Hermitian Gram matrices without importing the serialized extractors or primary decoder. The Hermitian Gram is only an inverse solver; it does not replace the bilinear evaluation, REG7 pairing or BV bracket. They agree on all six matrix triangles and decisive pairing results. Both share frozen component inputs, mathematical conventions, Python, SymPy and analyst. External specialist review remains outstanding. The 328-coordinate source decoder is checked; the scalar dynamics, potential and physical benchmark are not recalculated.

The read-only audit regenerates the two new outputs byte-identically, compares them, retains inherited binding expectations without refreshing historical hashes, checks authority coherence and rejects false-claim mutations. Its receipt records wall/CPU time, process peak, OS transfer counts and before/after workspace/active-data metadata inventories supplemented by bound cryptographic hashes. Unmeasured parse/cache/linear-algebra subdivisions are stated, not estimated. This is not an all-byte repository rehash or T5 reconstruction.

Final targeted results and timings are in `frozen_source_component_decoder/validation_receipt.json`. Historical custody remains a separate unresolved issue; strict exit 2 is not PASS. Repository-wide `--all` is not needed for this bounded prerequisite and no unrestricted validation PASS is claimed. No pole/projection payload, GPU or remote push is used.

## Next permitted decision, not automatic execution

Prepare a separately scoped interacting M08 reconstruction proposal using the decoded evaluation sources, coherent scalar orientation and complete nonminimal pairings. Its smallest actual-H source/connection sector must pass before full expansion. The proposal must specify the full master action, shifted VEV, nonsymmetric coset, derived R_H chain contributions, light/heavy gauge fixing and transported quantum/background/domain operators.

Complete source/master consistency, full-domain completeness, quotient descent, enlarged-source catalog coverage and specialist semantic review remain unearned. Legacy implementation code is not silently upgraded. The authoritative blocker remains `M08_C5_H_BASIC_COCHAIN_QUALIFICATION_PENDING`; no physical gate, finite threshold, cochain dimension, rank, EOM quotient or cohomology is computed.

The [specialist packet](SOURCE_COMPONENT_SPECIALIST_REVIEW_PACKET.md) contains questions, not an endorsement. [Gomis, Paris and Samuel](https://arxiv.org/abs/hep-th/9412228) provides the standard field/antifield comparator, not certification of these component maps. The repository-writing skill kept this investigation in the existing contract/evidence/report format; it introduced no second authority ledger.
