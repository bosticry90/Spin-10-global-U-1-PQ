# E5 minimal Ward source class and zero-coupling target contract, V1

1. **Question.** Does the admitted polynomial minimal complex have a
   background/joint-basic source class that cannot be made source free, and
   what does the actual g=0 action imply about its prospective quantum use?
2. **Claim under test.** Derive a field-rotation family from an actual real
   H-singlet heavy Spin(10) generator. Test its complete source coefficients,
   physical first variation, Ward/contraction identities and ordinary currents.
   Establish or refute polynomial nonexactness by an exact stationary
   specialization. Test the same matter-source pattern's local second-order
   integrability. Independently derive the full retained action's g=0 split.
3. **Ceiling.** A named minimal polynomial class/obstruction and a conditional
   zero-coupling source identity; not complete E5, an actual quantum prescription
   or universal classification. A proposed Gaussian-preserving normalization
   is not silently imposed on W1-W7. Nonlocal Gamma and insertion/contact
   transport remain different from a local BV-action deformation.
4. **Types/inputs.** Clean 3642d07, state v113/34 of 39; 20 sealed chains.
   All 643 pairs and 48 actual H backgrounds remain. Use the 553-pair minimal
   chart as a cochain image, not physical source elimination. Counterterms have
   (d,gh,p)=(4,0,0), generators (3,-1,1), source-left bracket. Coefficients are
   translation-invariant polynomials in the existing physical parameters,
   with nonnegative dimensions; no inverse g, mass, width or field. Ordinary
   symmetric jets, real physical input vectors and Minkowski contractions apply.
   All four scalar sectors, 29 potentials, nonsymmetric coset/R_H and E1-E3
   transport are retained. No fermion/Yukawa sector or new coupling is added.
5. **Comparator/dependencies.** Reuse qualified canonical physical/Euler,
   representation, Noether/master, cotangent and nonminimal-retract results.
   [Local BRST cohomology](https://arxiv.org/html/hep-th/0002245), sections
   11-13, is the comparison for counterterms and consistent deformations.
   Its semisimple statement is not assumed uniform in this project's g=0
   polynomial family. An exact counterexample is not a refutation of that
   theorem, the physical action or Spin(10).
6. **Primary route.** Use actual source columns and scalar representation
   commutators, plus the normalized real kinetic action/first variation.
   Extract complete coefficients before applying the witness specialization.
   Lower g=0 in the literal E2 source/gauge-fixing density and physical action.
7. **Replay route.** Reconstruct 10-by-10 physical commutators and their scalar
   representations; derive evaluation-dual source variation and the covariant
   current independently. Derive the retained Gaussian in physical primal/dual
   frames, its generic non-null-momentum inverse and graded Legendre source
   dependence. Share immutable representation inputs/Python/SymPy/analyst
   openly; do not consume primary residuals or select a fitted cancellation.
8. **Falsifiers.** Wrong scalar/source bracket sign, omitted seagull/current,
   non-real or non-heavy witness vectors, symmetric-coset replacement, treating
   every Q-closed class as an actual quantum counterterm, or imposing an
   unproved g-power rule. Retain exact failed and unfinished attempts.
9. **Known limits.** Keep potential parameters unchanged in the Gaussian
   g=0 split. A SEPARATE formal all-masses/potential-couplings-zero stationary
   specialization may prove polynomial nonexactness; it is not a new physical
   benchmark or a fit. Momentum inverses belong to the formal Gaussian Green
   function, never the local cochain ring. Generic p^2 nonzero is not an IR
   prescription or proof of the full massive A1 propagator problem.
10. **Stop.** First unexplained essential mismatch stops the dependent gate.
    Preserve any local-deformation obstruction without adding interactions.
    Leave quantum admissibility unresolved where A1-A5 or finite normalization
    remain unspecified. Do not tighten the quantum target merely to pass.
11. **Possible outcomes.** A qualified Ward/basic polynomial source class,
    an exact local integrability obstruction, a faithfully derived Gaussian
    conditional source identity, refutation, underdefinition or bounded
    inconclusiveness. A local second-order obstruction alone does not prove
    exclusion from the full nonlocal quantum functional. The proposed
    source-independent/zero-theory-preserving prescription must stay explicitly
    conditional; no nonempty restored prescription class is inferred.
12. **Evidence/recovery.** Distinct routes, exact coefficient comparisons,
    structural all-polynomial arguments and negative controls; declared input
    schemas checked before expensive operations, execution-start raw bindings,
    logs and failure receipt preservation, fresh byte replay and read-only
    validation. Preserve predecessors, authority, custody exit 2/seven references
    and solo policy. Local commit after validation only; no activation,
    auxiliary elimination, catalogs, HB1/C5, C1_GS, matching, contact or push.

The full Spin(10) x U(1)PQ goal is unchanged. This task serves the remaining
minimal/quantum-target obligation; it does not redefine completion as this class.
