# Actual auxiliary/vector poles and measured mixing Ward condition, AV V1

The independently calculated dimension-zero one-loop g10^2*xi auxiliary/vector
poles agree over the complete 1,174,770 symmetric component slots. Adding these
measured poles cancels all 720 terms in the leading auxiliary mixing Ward left
side. Qualification is limited to these actual poles and this selected measured
condition. Complete quantum restoration, full E5 and quantum A5 remain open.

This increment follows the prospective AV V1 contract at baseline
5f3b542491f94a0d7f85019fcd57fe15beff3154. The earlier actual g10^3 four-ghost
calculation already failed its frozen candidate comparison at df9b452. That
failure remains exact evidence; no candidate is adjusted or adopted here.

## Claim AV1: actual poles

Lambda is an EVEN integrated auxiliary field with dimension 2 and ghost number
0. It is distinct from the ODD BV source J_Lambda. All 45 auxiliary directions,
45 B directions and 12 background A_H directions are retained. The 228 vector
components have full Bose symmetry, including identical even components.

| Pair | Complete symmetric component domain | Nonzero color coefficients |
| --- | ---: | ---: |
| BB | 733,050 | 526 |
| A_H B | 388,800 | 0 |
| A_H A_H | 52,920 | 0 |
| Total | 1,174,770 | 526 |

These are component slots, not distinct measured physical scattering amplitudes.
The nonzero real physical polynomial has 2,104 terms, four Lorentz copies of the
526 color coefficients. The canonical polynomial has 720 terms. In the frozen
physical chart its residue is

\[
\Gamma^{(1)}_{\mathrm{pole},AV}=
\frac{\hbar g_{10}^{2}\xi}{32\pi^{2}\epsilon}
\sum_{\mu}\eta_{\mu\mu}\sum_{\lambda,\,b\leq c}
V_{\lambda;bc}\Lambda^p_\lambda B^p_{b\mu}B^p_{c\mu}.
\]

For example V_(13;0,14)=-18*sqrt(10)/25 and V_(13;3,25)=12/5.
No additional symmetry factor is implicit in this polynomial convention.

Proper three-external-leg one-loop counting gives n3+2*n4=3. At g10^2*xi the
eligible families are the xi Lambda-antighost-ghost insertion with two full
derivative gauge/background ghost cubics, and that insertion with the full
g10^2 vector-pair/antighost/ghost quartic. The three SourceGG Born words contain
both vector assignments; the bubble contains both words. The literal inventory
retains 276 raw xi cubics, all derivative B/A_H vertices, 14,120 raw BB quartic
terms and 3,360 A_H B quartic terms over all four Lorentz copies. A_H A_H is
screened rather than omitted from the component domain.

Other external-auxiliary g Lambda BB or g b A_H B choices cannot supply the xi
insertion and three selected external legs with at least two integrated
incidences at every vertex at this coupling. A xi vertex with no selected
external leg forces a one-integrated-leg bridge elsewhere; this is 1PR.
Pure YM, scalar or fermion vertices cannot connect the two odd legs of the
external-Lambda xi insertion; positive-dimensional insertions lower the UV
degree and belong to separate mass/power obligations. The recorded inventory
keeps other coupling families and their exclusions. None is omitted using a
Ward prediction, candidate zero or projected-M Jacobi identity.

The primary method constructs the complete graded Fourier Hessians and principal
inverse before proving the selected classes close only odd cycles. The replay
reconstructs its vertices from physical Spin(10) commutators, crosschecks its own
literal BB/A_H B quartics before the loop, and calculates routed Gaussian/Wick
color traces. Both ghost orientations, H/M directions, mixed inverse and formal
widths are retained until the edge proof. No width or component cutoff is used.
The auxiliary evaluation-dual chart is used separately from the vector primal
chart; full roundtrip, reality and all twelve rigid-H identities are checked.

For each of the 16 external Lorentz pairs, separate Born/Wick and Gaussian/sphere
controls calculate all nine cubic derivative placements and the quartic bubble.
The nonzero diagonal weights, after dividing out eta_mu, are

| Internal derivative placements | Triangle residue |
| --- | ---: |
| antighost, antighost | -1/2 |
| antighost, ghost | +1/2 |
| ghost, antighost | +1/2 |
| ghost, ghost | -1/2 |
| a derivative on an external vector | 0 in the selected zero-jet coefficient |

The bubble weight is -2. Off-diagonal kernels can be nonzero while their angular
residues vanish. Removing the reverse odd propagator gives -1/4 and -1 instead
of -1/2 and -2. Those changes are detected.

The complete triangle cancels only after Bose symmetrization. The independent
trace route proves that X_lambda is antisymmetric on M, the projected ghost
matrices F_b are antisymmetric, and the full H-to-M edge vanishes. Thus
Tr[X_lambda*(F_b*F_c+F_c*F_b)]=0, including equal-vector diagonals. It also
evaluates the complete sums and preserves nonzero ordered witnesses. At
lambda=12, vectors B13/B14, the two ordered coefficients are respectively
-6*sqrt(10)/25 and +6*sqrt(10)/25. The primary retains 2,574 nonzero ordered
source/G intermediate cells. Dropping one assignment would destroy cancellation.
Nonzero background ghost and A_H B quartic vertices are retained before their
zero-pole edge/trace proofs. All 526 nonzero coefficients arise from the bubble.

UV extraction is on k_E^2>R_UV^2>0 with triangle/bubble heat profiles 6/4 and the
radial multiplier 2I. External-momentum remainders, derivative-free power terms,
mass-dependent logs, finite amplitudes and IR treatment are outside this result.
No whole-scaleless-amplitude inference is made.

## Claim AV2: selected measured mixing Ward condition

Only after complete actual tensor agreement does comparison read the previous
measured mixing pole and Ward evidence. Separate prefix and jet-gradient actions
give

\[
W_b(\Gamma_{\mathrm{mix},g\xi}+
\Gamma_{AV,g^2\xi})\big|_{\Lambda B\,\partial\Omega}=0.
\]

All 720 original mixing Ward terms cancel against 720 new partner terms, over
the 388,800 raw component domain. The raw left side, full omega-anchored density,
all twelve parameter Euler derivatives and all four combined IBP currents are
zero without EOM or auxiliary elimination. Full enlarged known-Ward projection
also checks that no new Lambda A_H target is concealed. Omitting the measured
partner leaves the original nonzero obligation.

The updated known residue has 31,315 canonical terms and its Ward action has
11,728 raw terms in FOUR target signatures: g10^3 B/antighost/ghost with one
parameter derivative; g10^3 J_antighost/B with one parameter derivative; and
g10^3 J_Lambda/ghost with one or two parameter derivatives. Their unknown
predecessor coefficients remain null, not zero. The type census is not an
invariant coefficient basis or a solution of the remaining restoration problem.

The new node contributes zero to both previous selected Slavnov projectors,
using all 1,286 source columns and the qualified physical-Euler support proof.
This preserves the GS selected Slavnov and GP selected source-Ward scopes. It
does not set the deferred full physical Euler program to zero. Gamma_unknown,
Delta_b/s, insertion/contact normalization, measure/regulator and IR obligations
remain unbound; a vanishing measured projection is not complete restoration.

## Execution, validation and limitations

Qualified workers are controls/preparation_1, primary/preparation_2,
replay/preparation_3 and comparison/preparation_4. Their initial calculations
took approximately 1.08, 171.38, 275.95 and 89.70 seconds respectively. Actual
workers deny prior E5 pole, candidate, required completion tensor and peer reads
after byte authentication of 46 ancestor chains. Authentication is not scientific
execution or acceptance. Exact preparations and completed stdout are retained.

Two early interactive test-source checks failed: first from an unregistered
light auxiliary name and a nonexistent exact-domain constant; second from an
incorrect assumption that deleting explicit parameter jets from field images
also deletes jets generated by differentiating those images. Both source versions
and separate unchanged-source reproductions with complete stdout are retained
as engineering_attempt_1/2, expressly excluded from PASS. The interactive outputs
are in the conversation; the archived stdout is labeled as reproduction. The
correction retains a negative control that removes parameter jets from the
computed old Ward expression and exposes the false zero. No actual worker,
control or comparison calculation bytes are changed by these test repairs.

The validation receipt owns scientific tests, process/governance tests,
delegated e5 checks, four fresh own-byte executions, protected/new/state hashes
and metadata invariance. It is created only after those checks finish. The
delegated e5 check authenticates existing bounded evidence; old expensive loops
and normalization images are not repeated. Custody exit 2 with seven unresolved
references remains unresolved, never PASS. Local raw-index/worktree equality is
required before commit. No sources are activated and no normalization is fitted.

Under the existing epistemic ladder, provenance is complete within this bound;
verification passes the AV1/AV2 contract only after its receipt; formalization is
not attempted; compression is partial with the Bose/odd-cycle mechanism above;
interpretation is established within the specified UV scope; empirical connection
is none. The routes share action, representations, some exact arithmetic/reference
machinery, Python 3.10.11, SymPy 1.14.0 and analyst. They are computational
corroboration, not independent scientists or external endorsement.

The sole authority remains project_state.json v113, 34/39 with unchanged SHA
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8.
HB1/C5 remains blocked and finite C1_GS is uncalculated. Full E5, nonlinear
Slavnov restoration, W1-W7 realization, quantum canonical equivalence, anomalies,
scalar/global-PQ/vacuum, fermion/Yukawa and phenomenological obligations remain
open. The whole Spin(10) x global U(1)PQ goal remains active and incomplete.

The next smallest authorized scientific increment is the ACTUAL g10^3 no-jet
vector-pair/antighost/ghost pole, including background companions, under a new
prospective complete graph contract. Its complete one-loop inventory must be
obtained independently of the remaining Ward tensor and must retain transverse
BB propagation wherever it contributes. Compare the measured enlargement before
fitting any counterterm or moving to dependent higher source amplitudes.
