# Source-free obstruction and a classical auxiliary shear

Bounded disposition:
`QUALIFIED_E5_SOURCE_FREE_OBSTRUCTION_AND_CLASSICAL_SHEAR_PREREQUISITE_ONLY`.
The completed validation receipt and byte seal, when present, own evidence
qualification. Baseline is 38c2a3f, state v113, 34/39. This result neither
replaces the actual-quartet normalization failure nor completes E5 or the
Spin(10) x global U(1)PQ investigation.

## What the source-free residual permits

Dimension-three, ghost-minus-one, odd generators can contribute to a
source-zero, jet-zero quartet only through five type sectors:

| Generator type | How Q can supply the quartet |
| --- | --- |
| a Lambda | Curvature part of Q Lambda |
| a a C | Interacting ghost/nonminimal variations |
| JC C | Quartet part of the ghost Euler column |
| Ja a | Quartet part of the antighost Euler column |
| JLambda a C | Two-odd part of the auxiliary Euler column |

The type enumeration retains both nonminimal sectors, all 45 ghost directions,
finite ordinary jets and nonnegative coefficient dimensions. It gives
necessary carrier types, not an invariant tensor basis or a general solution
for the canonical image. A quartet already has dimension four; positive
dimensional parameters cannot multiply it. Multiple-source generators leave
a source after a single Q variation. Physical/background variables and jets
have explicit odd-degree/projection exclusions. Physical Euler terms are
source-zero bosonic terms and cannot supply the required four odd fields.

For the target with two heavy antighosts, source-free carriers containing
light antighosts or auxiliaries do not contribute. Let A be the heavy bilinear
coefficient in a^T A Lambda. The already measured width fixes its symmetric
part because Q0 gives -Lambda^T A Lambda. The complete measured cubic fixes
the a-a-C primitive injectively: its independent Lambda_a a_b C_c coefficients
force every antisymmetric primitive coefficient. The remaining ambiguity is
a skew A.

In the real physical frame the complete nonminimal transformations are

    Qa = -Lambda + g T(C_H) a,
    QLambda = g T(C_H) Lambda + g^2 T(R_H) a.

All twelve connection matrices T_h are real and skew. The exact curvature
column lies in their span; no projected heavy adjoint closure is assumed.
Local H compatibility of A gives T_h^T A + A T_h = 0. Thus [A,T_h] = 0.
The connection part of Q(a^T A Lambda) vanishes, and

    (A T(R_H))^T = T(R_H) A = A T(R_H).

The remaining odd bilinear a^T A T(R_H) a vanishes since its coefficient is
symmetric. Consequently every H-compatible skew ambiguity is fully Q-closed.
It cannot change the preserved quartic residual. A non-H-compatible elementary
skew A has a nonzero complete Q image and provides an exact negative control.

This rules out a further source-free repair with the previous width and
complete cubic matches fixed. It does not rule out coordinated changes in
source-dependent canonical maps, physical field normalizations, or a jointly
restored quantum subtraction scheme. The linear JC/Ja sectors are already
constrained in the preceding candidate; their most general coupled freedom
has not been classified here.

## A typed auxiliary shear and its required companions

There is an independently available classical type, JLambda a C. It is
already in the qualified polynomial ring; no new physical interaction or
free fitted tensor is needed to examine its image. Define the unit direction
from the existing xi auxiliary interaction:

    E = coeff_xi(Q JLambda)|two odd fields,
    F = G_M E,
    Kshear = g^2 xi JLambda^T F.

E is primal while Lambda and F are evaluation-dual. G_M is the inherited heavy
Gram matrix. The canonical evaluation pairing remains identity between
opposite carriers. In physical coordinates

    raw Lambda = U^T Lambda_phys,
    raw JLambda = U^-1 JLambda_phys,
    G_M = U^T U.

The first contract incorrectly used E itself as the field shift. That V1
generator failed its first H identity in 152 exact coefficients. Its complete
failure, contract, source and execution are retained and not counted as PASS.
V2 froze the metric lowering before execution; no coefficient was inferred
from the actual quartic discrepancy. Both raw and corrected proposals are
distinct evidence, and the failed proposal is an explicit wrong-carrier control.

The corrected Hamiltonian map shifts only Lambda among integrated fields:
delta Lambda = -g^2 xi F. Its evaluation sources shift by the left variational
gradients of the same K. The map has an exact polynomial inverse because
F, a, C and JLambda are fixed by its flow. Full elementary bracket coefficients
cancel, including the quadratic part of the finite map, across all 1,286
generator slots and zero spectators. All twelve local H identities and the
qualified real/dual/primal structure pass.

The integrated-field Jacobian is triangular with identity diagonal blocks,
so its Berezinian is exactly one. This differs from the preceding joint
normalization's regulated measure contribution, which remains present. A
unit Jacobian does not prove quantum canonical equivalence: nonlinear mean
fields transform with <F(a,C)>, not F(<a>,<C>). A formal two-odd Gaussian
control has <a>=<C>=0 but <aC>=-1/m. Composite insertion and contact
normalizations, the retained-source Ward equations and A5 remain obligations.

The full Q image and independent complete-density first variation agree,
with no boundary current for this shear. The image contains all its nonzero
derivative B-a-C, auxiliary Lambda-a-C, four-ghost, nonminimal-source and
scalar-orbit companions. Their type/coupling inventory and full coefficients
are in the route evidence. The quartet image defines all 980,100 slots with
the exact physical dual/primal maps; it is not an actual loop tensor.

The unit generator has 276 canonical coefficients and its complete image
has 13,514. Its physical quartet image has 4,128 nonzero slots. These counts
do not measure agreement with the actual residual; no such comparison was
performed. The complete image inventory is:

| Coupling | Field/source type | Canonical coefficients |
| --- | --- | ---: |
| g^2 xi | one derivative on B-a-C | 1,104 |
| g^2 xi | JLambda-Lambda-C | 276 |
| g^2 xi | Ja-a-C | 276 |
| g^2 xi^2 | Lambda-a-C | 276 |
| g^2 xi^2 | a-a-C-C | 942 |
| g^3 xi | B-B-a-C | 5,408 |
| g^3 xi | JLambda-a-C-C | 1,296 |
| g^3 xi^2 | scalar-a-C with typed OrbitPullback | 3,936 |

Canonical sparse counts and physical-frame counts differ under the qualified
coordinate map. All 99 nonzero Hamiltonian columns are retained, with 396
first-jet checks and both inverse directions checked for all 1,286 generators.

The inherited OrbitPullback has coefficient dimension one after inserting
the fixed numerical vacuum. A raw-word grading precheck failed in 3,936 exact
terms; that attempt and every term remain. The qualified check reconstructs
precisely the orbit image from the sealed E1 heavy-orbit fermion and checks
its coefficient dimension. It grants no blanket grading exception. The
g^3 xi^2 scalar-antighost-ghost companion is retained.

Prior measured source, ghost kinetic, mixing, width and cubic projections
are preserved at their original coupling degrees. This does not establish
agreement of any newly predicted companion with a loop calculation. All
ordinary first jets and a nonzero omitted nonlinear second-jet term are
checked. Omitting cubic, source, derivative, orbit or quartet companions gives
explicit nonzero densities, not a permitted partial normalization.

## Evidence and next scientific action

Primary uses literal E2 columns and graded prefix Q variation. Replay
independently differentiates the whole gauge-fixing density and uses direct
canonical first variation of the complete source/gauge-fixing polynomial.
Completed outputs agree. The source-free argument also has an abstract
transpose/commutator derivation and a noncommuting skew control. Shared
immutable charts, arithmetic, Python 3.10.11, SymPy 1.14 and analyst remain
disclosed; this is solo computational review, not external endorsement or
proof-kernel certification.

The receipt owns executed scientific/process/governance tests, fresh strict
own-byte routes, 32 predecessor chains, protected/new/state SHA and audit-time
size/mtime inventory. The earlier expensive loops are authenticated, not rerun.
Historical custody remains exit 2 with seven unresolved references, never PASS.
Failed attempts are not qualification passes. The frozen V1/V2 contracts
distinguish proposals, calculations, evidence validation and director acceptance.

The actual 5,528-slot quartic discrepancy remains intact. This increment does
not read or fit it in the new calculation and does not select a subtraction
coefficient or claim that the unit shear solves it. The next smallest justified
action is to classify the H-equivariant coefficient space of JLambda a C and
its full image together with the required companion equations, then test a
fully specified allowed direction against actual amplitudes under a new
prospective contract. The unit direction provides exact companion types and
a falsifiable basis for that decision; it is not an adopted normalization.

No new loops, source/auxiliary elimination, activation/catalog/HB1/C5/C1_GS,
physical matching, authority promotion, outside contact, publication or push.
Full E5/A5/Ward/IR/anomaly, global scalar boundedness/PQ quotient,
fermion/Yukawa and phenomenology remain open. The whole goal stays active.
