# Concrete regulator, ghost pole and selected source normalization

These are prospective claims, not a PASS record. Keep all sources and fields.

## Regulated functional and symmetry

Let P_e be the positive Euclidean multiplier in the contract. It commutes with
every ordinary derivative, is source independent, and tends to one at e=0.
For a finite mode cutoff, expand the actual g=0 action as a graded formal
perturbation of its regulated quadratic kernel. Q0B=dC, Q0ub=-Lambda,
Q0bar=-b and all other field columns vanish. Its finite-mode Jacobian is
upper triangular with identity diagonal and zero supertrace. The regulator
adds Q0-exact changes of the linear divergence fermions and free-curvature
terms annihilated by Q0. Scalar terms are annihilated because Q0x=0.
No vertex or potential is dropped. Q0 commutes with the mode projection.

At g=0 background H shifts B_H and A_H together by d omega. Their difference
and the curvature are invariant, while all homogeneous field/source rules
vanish. The regulator commutes with these local derivatives. The geometric
quantum identity still has its light breaking, now with P_e in the displayed
parameter derivatives; do not demand homogeneous quantum invariance. These
finite-regulator identities are exact but do not prove restoration at g!=0.

The source shifts in ab2b63a remain unchanged, because regulator/measure/
counterterms in this construction are source independent. Thus this is an
EXPLICIT regulator realizing their integrand premise at finite cutoff, not
another abstract assumption. Infinite-cutoff renormalization, scalar closure
and the physical IR limit have separate obligations.

## Ghost operator and pole

Write heavy dual fields as Lambda_phys=F_M Lambda, ub_phys=F_M ub and heavy
primal ghosts u_phys=Q_M u, where F_M=Q_M G_M^-1. For fixed Lambda the ghost
matrix from the actual interaction is

    A(Lambda)=P_M ad(Lambda_phys)|_M,
    L_ghost = ub^T[-Box I + xi A(Lambda)] u.

This is quadratic in ghost variables for a fixed auxiliary field, even though
the full integrated theory is non-Gaussian. Minkowski conventions give

    Gamma_1,ghost = -i hbar Tr log(K0 + xi A),
    Gamma_1,quadratic = +i hbar xi^2/2 Tr(K0^-1 A K0^-1 A).

All tr A_i vanish. With nonexceptional external momentum the scalar bubble
has residue i/(16 pi^2 e) for the analytic propagator regulator specified here.
Derive it independently from the radial UV asymptotics and a scalar
dimensionally continued bubble. Never set k=0 and call a scaleless integral
zero. Therefore define

    kappa_ij=-tr_M(A_i A_j),
    Gamma_1,pole = hbar xi^2/(32 pi^2 e) Lambda^T kappa Lambda,
    L_CT = -hbar xi^2/(32 pi^2 e) Lambda^T kappa Lambda.

The replay uses real orthonormal H/M frames and also verifies

    kappa_phys=C_adj I_M - 2 C_H|_M,

with C_adj derived in the declared normalized physical basis. Constant frame
factors may be inverted, never g/xi/mass. All coefficients and the spectrum
of kappa relative to the induced metric must agree independently.

The quadratic auxiliary-auxiliary propagator is zero, including with P_e and
arbitrary constant width matrix; a direct block inverse must establish this.
At g=0 no B interaction vertex exists, and scalar interactions are disconnected
from this sector. Every cubic vertex has one Lambda, one ub and one u. Hence
there are no internal auxiliary lines connecting such vertices, and the only
loop graphs in this sector are one closed ghost polygon with external Lambda
legs. Tadpole traces vanish, n>=3 polygons are UV convergent at nonexceptional
momenta, and n=2 gives the stated complete ghost-sector UV pole. This is not
an all-order statement about scalar loops or the g!=0 model.

## Subtraction and a specified insertion/contact family

The candidate primitive

    Psi_CT = hbar xi^2/(32 pi^2 e) ub^T kappa Lambda

gives Q0Psi_CT=L_CT. Its parity/ghost/dimension are the declared fermion grade.
Verify all 12 physical H covariance identities of kappa. The scalar physical
parameters and the frozen E1 fermion are not changed. If kappa is not a scalar
multiple of G_M^-1, the pole cannot be absorbed by delta xi in that literal
auxiliary term. A broader BRST-exact quantum fermion normalization is a
separately named possibility, not historical equivalence or automatic adoption.

For a local even dimension-zero probe rho coupled to the actual cubic
Q0-exact density, the ghost matrix is K0+xi(1+rho)A. Its local UV pole is
proportional to (1+rho)^2 Lambda^T kappa Lambda. Derive the first insertion
and second contact coefficients, including the factorial convention. There
are no higher probe poles from this one-loop sector. The candidate subtraction
Q0[(1+rho)^2 Psi_CT] preserves the same affine BV-source shifts. This is a
concrete selected insertion prescription, not all A4 products; source-dependent
probes and nonlinear source/observable transport remain unqualified.

## Decision boundary

No claim of a nonempty complete W1--W7 restored class follows until scalar
subtraction/parameter closure, IR/boundaries, g!=0 anomaly/restoration and the
required A4/A5 insertion/canonical normalizations are justified. The named F
is excluded as an ORDINARY constant source correction in this specific affine
normalization at rho=0. Its use as an operator insertion and the quantum
equivalence of gF require separate transported normalization evidence. Do not
erase the polynomial torsion result or infer a universal quantum exclusion.
