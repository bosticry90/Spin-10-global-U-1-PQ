# Full M08 source convention impact contract

This bounded review tests the coherent left convention identified at commit
`451c0e1` against the unchanged complete M08 action and its 17 roles. It is not
a repair or promotion of M08. The existing source images, historical failures,
JCAT and T5 remain immutable. External specialist review remains outstanding.

## Task boundary

Physics decision enabled: determine whether the proposed source convention can
support the intended C5 operation without changing the physical action.

Current blocker removed: none by declaration; the source convention and domain
consistency prerequisite must pass exact tests before any replacement is earned.

Why existing tools are insufficient: the previous review certified conventional
comparators and isolated source coefficients, not the complete M08 reverse
images or the six-pair nonminimal Slavnov operator.

Minimum new implementation surface: a versioned parity-aware indexed variation
visitor, complete factorized candidate expressions, and a small exact
nonminimal/source consistency test with a separately coded component replay.

Structure-preservation obligations: preserve source-left placement, exact
evaluation duals, graded Leibniz and variational integration-by-parts signs;
derive the composite before variation; compare complete expressions, not just
the two historical failing coefficients. Full master/ST, square, Cartan,
derivative and basic-domain obligations are successive acceptance gates, not
assumed consequences of comparator success.

Stopping condition: the first exact failed consistency prerequisite blocks
promotion and all later domain/cochain work. Freeze its exact scope and replay
before stopping. An implementation defect discovered during independent
rederivation is recorded as impact, not repaired in the frozen implementation.

What will be deleted or deactivated if this does not work: no historical
evidence is deleted; the new candidate remains diagnostic and inactive.

## Candidate convention frozen before comparison

For a field `z` of parity `p` and source `J_z` of parity `p+1`, retain
`Sigma = S0 + sum J_z Qz`, with sources on the left. On the six canonical
pairs use

```
(F,G)_src = sum_z (-1)^p [
  (d_right F/dz)(d_left G/dJ_z)
  - (d_right F/dJ_z)(d_left G/dz)]
Q F = (Sigma,F)_src + T F
```

Here `T` acts only on the unpaired nonminimal fields with their frozen images:
`T ubar_H = -Lambda_H + g10 f c_L ubar_H`,
`T cbar_L = -lambda_L`; the background and `lambda_L` are inert.
`T` is extended as a left odd derivation. This is precisely the candidate
extension of the six-pair ST specification, not a claim that it is a complete
canonical BV bracket on all fields. No missing antifields are added.

For even `Sigma`, the six paired forward images are its left source
derivatives; the reverse images are its left field derivatives. Odd field
derivatives therefore differ by a minus sign from right derivatives. Even
field differentiation has no Grassmann crossing sign. In a product the sign
is `(-1)^(p_target * parity_of_crossed_factors)`, not merely the parity of
the crossed factors.

The source coordinates correspond to conventional BV coordinates by the
already-tested invertible map `z_star = (-1)^p J_z`. This fixes orientation;
it does not certify M08's master equation or nonminimal truncation.

Retain all parameters, VEVs, source coefficients, physical transformations,
off-shell auxiliaries, physical four-dimensional Lorentz conventions and
ordinary derivative prolongation. VEVs are inert under Q, while the shifted
scalar transforms as the frozen `v+phi` representation. Do not confuse that
with invariance of the VEV under residual-H Lie action.

`R_H = -1/2 P_H[u_H,u_H]` is derived, never independently varied. Substitute
that definition before reverse differentiation; its Q image follows by the
graded product rule and must agree with the qualified corrected convention.

## Complete expressions and decisive gates

Materialize the 17 candidate rows without importing old reverse columns.
For the scalar source retain the constrained `E_dagger G` tensor-gradient
construction rather than substituting a Euclidean dual. The input action and
all derivative terms participate in the variation. Compare candidate and old
expressions as an impact record; syntactic differences are not automatically
physical inequivalences.

Before expensive global normalization, test the source `K_Lambda` and its
paired auxiliary `Lambda_H` against the unpaired antighost `ubar_H` in the
actual action. Use the derivative-free heavy gauge-fixing term, its explicit
frozen Lorentz trace and source coupling as a decisive finite sector. Extract
the relevant component before setting fields to zero. Setting fields to zero
before differentiation is forbidden.

The six-pair operation must obey the appropriate full-Weil/ST square on this
sector; neither EOM nor a convenient representative may remove a nonzero
off-shell residual. Ordinary global nilpotence is not imposed on a Cartan-only
equivariant operation, but the full-Weil candidate and the claimed basic-domain
restriction must be distinguished explicitly. A failure on an ambient source
must not be advertised as a complete no-go for every possible restricted
relative/BV domain.

Only if this prerequisite passes proceed to the complete master/ST identity,
all required square identities, Cartan identities, derivative extension and
structural preservation/descent of the basic domain. No HB1, cochain dimension,
C5 differential matrix, EOM quotient, cohomology, new source, new catalog or
transport is authorized. No pole/projection payload may be read.

## Semantic reference and authority limits

The left/right conversion and canonical BV comparison use Gomis, Paris and
Samuel, [Antibracket, Antifields and Gauge-Theory Quantization](https://arxiv.org/abs/hep-th/9412228),
Appendix A and section 4.6. Nonminimal field dependence and partial gauge fixing
are checked against Ferrari, [Partial Gauge Fixing and Equivariant Cohomology](https://arxiv.org/abs/1308.6802),
sections 2 and 3. Neither reference certifies this project's source truncation.

Primary indexed AST variation and a direct finite component calculation must
be separately frozen. Shared Python/SymPy and shared physical inputs are
declared; internal replay is not external specialist review. No review request
is sent to another person or service without user authorization.

Validation is pole-blind and read-only. Regenerate new bounded evidence
byte-identically; bind scientific inputs and verify before/after audit
inventories. Reuse existing catalog verification receipts explicitly, without
claiming new JCAT/T5 reconstruction. Formal authority stays `34/39`, attempt 2
and Layer 6 remain unauthorized, and `finite_C1_GS` remains null.
