# E5: joint closure and a literal source-counterterm coverage stop

The governing contract is `A10_E5_DOMAIN_CONTRACT_V1.md`. The completed route
comparison and validation receipt own the actual classification. This is a
bounded stopping investigation, not an E5 PASS or a new catalog. D–E4 and
formal authority 34/39 remain unchanged.

## Domain and differential

The candidate uses all 643 canonical pairs and 48 external backgrounds. The
ordinary polynomial jet language retains parity and ghost number, with the
frozen unscaled ghosts of dimension one. Evaluation sources have grades
(3-d,-1-gh,1-p). Parameters retain their existing coefficient dimensions;
dimensionless parameters form a coefficient ring, not a finite set of samples.

The full retained-source Q' is the deformation differential here. This is
explicitly different from the E4 restricted 607-field operation delta. No
equivalence of their basic-domain realizations is established by this test.
No light-ghost-zero projection is interpreted as a Q-stable quotient.

Before gauge-fixing transport, contraction has

    iota C_h = omega_h,
    iota b_a = -g10 f^a_(b h) bar_b omega_h,

with other field images zero. The light nonminimal correction follows from
Q bar=-b, Q b=0 and the actual residual-H field action. Every source image
is derived from the even canonical generator

    I=sum_h JC_h omega_h-g10 sum_(a b h) Jb_a f^a_(b h)bar_b omega_h.

The independent physical replay reconstructs the normalized matrix brackets;
it does not import primary outputs. Both routes compare all 1,286 contraction
columns and prove {iota,Q}=Tq and iota squared zero across that alphabet. They
retain local parameter derivatives and check 1,286 selected first-jet Cartan
identities (directions 0 and 1). Other ordinary jets follow by prolongation.
Background covariance is checked on 643 fields and extends by the canonical
lift. Physical Euler cross-terms vanish because contraction fixes every
physical B/x coordinate and has no gauge/scalar-source image; the 508 qualified
physical Euler programs are authenticated, not re-expanded as formal variables.

The complete odd contraction is transported canonically through the E2 map:
iota'=U iota U^-1. Its source images independently agree with the Euler
columns of UI. The odd Leibniz sign is retained. E3 already supplies
[Q',Tq']=0 and [Q',Tb]=0, with Tq'=UTqU^-1 distinct from geometric Tq.

Consequently the proposed full joint local-functional domain

    D_joint=ker iota' intersect ker Tq' intersect ker Tb

is Q' preserved under the declared boundary conditions. This follows from
the checked Cartan relation, E3 commutators and full BV nilpotence. It is an
untruncated graded domain, not a dimension-four-only space falsely claimed
to be closed: Q raises dimension and ghost number together. Dimension-four,
ghost-zero action counterterms are a selected component. No finite inventory
or universal cohomology completeness claim follows from this closure proof.

The physical gauge/scalar action is a nonzero basic control by its qualified
invariance and contraction rules. A separately calculated nonzero source
control U(sum_h JC_h R_h) and its Q' image are also basic. The domain is not
the artificially closed zero space. Removing the light correction produces
the exact recorded Cartan failure.

## Necessary source-counterterm test

Canonical ghost/source renormalization is tested independently of closure.
Let

    K=sum_(a=0..44) JC_a C_a,       grade(K)=(3,-1,odd),
    F'=Q'(UK)=U(QK),               grade(F')=(4,0,even).

F' is BRST exact, hence closed by the qualified master/Jacobi identity. Both
routes verify its transported quantum and background Ward identities and
canonical transport. It is a permissible source-dependent deformation in the
contract's starting BV-compatible language. It is not literally horizontal:

    iota' F' != 0,
    Euler_(JB0_0)(iota' F') contains +partial_0 omega_0.

The selected derivative-parameter coefficient is exactly +1, independent of
g10. The nonzero Euler derivative excludes an ordinary-divergence dismissal.
The computation derives the full variation and Euler covector before extracting
this free coefficient; no physical parameter is changed or fitted.

This establishes a necessary literal-coverage failure of this proposed domain.
It does NOT refute counterterm adequacy modulo an appropriately justified
exact-term quotient. F' is itself exact. A correct cohomological reduction may
represent it as a trivial class while separately accounting for canonical
field/source renormalization and the associated Ward-operator transport.
Neither that reduction nor a policy excluding such deformations is supplied
by D–E4. Silently deleting F' would change the tested target. E5 therefore
stops before a full adequacy, quotient or descent claim and before enumeration.

Disposition:

    STOP_E5_LITERAL_SOURCE_COUNTERTERM_COVERAGE_REQUIRES_JUSTIFIED_QUOTIENT

Closure and coverage have separate results. The complete E5 gate remains
unqualified. The narrow conclusion is a missing literal source class and an
unestablished quotient/renormalization policy, not a physical-action failure,
an anomaly or a falsification of Spin(10).

## Independent routes, controls and integrity

Primary prefix variation/canonical differentiation and replay physical-matrix/
left-gradient variation use separate derivations but share immutable inputs,
word multiplication, Python/SymPy and analyst. No external endorsement or
proof-kernel formalization is claimed. Structural all-source/jet conclusions
are disclosed rather than described as exhaustive fresh square expansions.

An initial test expected the opposite free Euler sign. Both routes rejected
that expectation with residual 2 partial_0 omega_0. The original code, failed
outputs, metrics and incident classification remain preserved and excluded
from final qualification. The correction follows explicit left variation of
JB partial C: the odd-factor sign and integration-by-parts sign cancel in
Q JC=+partial JB, and the contraction has Euler +partial omega. This is a new
test-expectation correction, not a change to frozen scientific evidence.

The validation receipt records newly fresh byte-identical E5 routes, selected
E2–E4 regressions, process/governance checks, thirteen predecessor-chain
authentication and unchanged protected bytes. Older expensive mathematics is
authenticated, not rerun. Whole-workspace inventory checks size and mtime;
it is not a byte audit of the entire environment. Historical custody remains
exit 2 with seven unresolved references. Partial/canceled validation earns no
completed receipt and no global PASS.

[Local BRST cohomology](https://arxiv.org/abs/hep-th/0002245) supplies the
general antifield/counterterm framework; [gauge-fixed cohomological analysis](https://arxiv.org/abs/hep-th/9910201)
explains why comparing such formulations needs deformation and nilpotence
conditions. [Ferrari](https://arxiv.org/html/1308.6802v3) supplies the partial
equivariant comparison. These primary sources motivate obligations, not this
implementation's certification or the choice of its renormalization target.

The next smallest scientific task is an explicit exact-term/renormalization
policy and equivalence proof: does the intended target admit basic
representatives plus separately tracked canonical redefinitions, and do
local divergences, power-counting bounds, background Ward identities and
source transport respect that reduction? Retain this exact F' witness as a
required control. No HB1/C5, catalog replacement, activation, C1_GS, matching,
authority promotion, publication or push is authorized by this result.
