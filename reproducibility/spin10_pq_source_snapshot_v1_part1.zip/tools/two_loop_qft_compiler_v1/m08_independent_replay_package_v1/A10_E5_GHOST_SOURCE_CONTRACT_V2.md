# Ghost-source joint test: prospective input-convention repair, GS V2

GS1 contract V1 and completed controls/primary/replay stay unchanged. Before
any corrected GS2 calculation, freeze the following dependency repair.
Baseline791ddbe/statev113/34of39 and all43 parent manifests remain immutable.

Completed comparison.json used the MF V3 assembly exactly and found a real
nonboundary residual. Its physical anchored terms occur only in spatial
directions. Dependency review identifies a specific inherited input error:
MF V3 multiplies gauge_source_g1 by ETA[mu], whereas the qualified source_vertex
actual pole and canonical_normalization.gauge_source_derivative_projection
contain -g10*xi*JB^mu*partial_mu(N C), without ETA. The literal E2 Q_B column
also has +partial_mu C for each of four components. The extra metric is an
assembly error, not a newly calculated counterterm or a fitted coefficient.

Preserve every GS V1 source/preparation/attempt/output byte. comparison.json
is UNQUALIFIED_AS_ACTUAL_MEASURED_FUNCTIONAL: it correctly calculates the
variation of an incorrectly assembled input. Its derived nonzero residual
must not be promoted to a physical restoration obstruction. MF V3 gauge-source
sector, assembled sum and dependent Ward/Slavnov coefficient claims are likewise
superseded for current interpretation; other sectors, loop records, custody
authentication and prior g^3 candidate failure retain their scopes. No edit
or invalidation of the scientific authority ledger.

GS2 V2 must read BOTH qualified source_vertex route records, independently
verify their full gauge-source projection against literal E2 derivative
columns and all45x45x4 source/ghost coefficient slots, reject the old spatial
sign and wrong source parity/chart, and replace exactly that assembled sector.
All other12-sector coefficients, normalization units and input scopes stay
frozen. Append the unchanged newly computed JC-C-C pole only after complete
actual-route agreement. Store the corrected13-sector canonical residue.

Calculate the complete3,539,700-slot selected g^2 aCC/twojet variation by
prefix and jet-gradient methods. Verify full ordinary antighost IBP currents
and all45 independent Euler derivatives. Zero anchored residual qualifies
only this selected MEASURED functional left side, never Delta_s=0 or full
restoration. If nonzero remains, preserve its real signed Euler witness and
stop without adjusting any coefficients, candidate, image or higher loop.

Compare original and corrected assemblies explicitly, including the exact
old spatial-sign discrepancy and resulting projected difference. This is
not a fresh old-loop replay: it authenticates and correctly imports an already
qualified actual pole. Four fresh own-byte controls/primary/replay/comparison_v2,
negative controls, science/process/governance/delegatede5, protected/new/state/
metadata invariance, custodyexit2/sevenrefs and rawindex/worktree equality
remain required. Original failed interpretation is not counted as PASS.

Remaining full local Ward coefficients must be reassembled with this corrected
source sector before using MF V3 witnesses. Related JB-B-C/A_H actual partners,
regulated breakings/measure/IR/contact insertions, higher source/auxiliary
relations, nonlinear restoration and quantum equivalence remain open.
No adoption, activation, push/publication/outreach, HB1/C5/C1_GS or whole-goal
completion. Shared software/arithmetic/inputs/analyst disclosed.
