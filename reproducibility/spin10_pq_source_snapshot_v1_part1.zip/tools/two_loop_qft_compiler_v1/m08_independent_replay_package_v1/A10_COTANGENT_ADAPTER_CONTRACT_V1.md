# A10 ordered tensor cotangent adapter contract V1

Authorized scope: qualify a separately named, inactive adapter for the scalar
derivatives of the executable candidate at `4315518`. No complete master
action, Stage E, source activation, catalog rebuild, HB1/C5, C1_GS, ledger
change, frozen-definition change, parameter adjustment or remote push.

Stop at the first failed or undefined requirement. Preserve exact negative
controls and all inherited bytes. A PASS authorizes a proposal for the next
bounded Stage D master-action calculation, not that calculation itself.

1. Define ordered complex tensor covectors, sorted real ambient covectors,
   metric-dependent Riesz vectors, independent real Euler covectors and
   canonical evaluation-source covectors. Fix directions, real structure,
   ordered measure and the domains of sections/inverses. No inverse on the
   entire redundant tensor space may be claimed.
2. Reproduce `-mSigma2*t^2`, direct derivative `-2*mSigma2*t`, incorrect
   `-mSigma2*t/60`, and the signed ordered recovery independently. Include a
   nonantisymmetric input that refutes blindly multiplying by 120.
3. Cover all Phi54, Sigma252, phi20 and S2 coordinates, every ordered alias
   Jacobian, exact metric duality, constrained kernels, real/imaginary signs,
   right sections, conjugation and jet prolongation. Independent coefficient
   agreement must establish a general linear map, not selected point values.
4. Generate raw indexed Euler templates for every alias in all 29 literal
   potential terms. Compare their arbitrary-variation pairing against direct
   polynomial differentiation, retaining all 34 independent real parameter
   coordinates (24 real, Re/Im for five complex). Keep the minus-V convention.
   Chain-rule induction on the executable grammar and the complete alias
   Jacobians must prove the canonical result for all fields and parameters.
   Derivative-bearing kinetic terms require a general Euler/IBP proof, fresh
   specialization of all skew-representation premises, and a boundary current.
5. Compose with the already decoded 328-coordinate K_phi evaluation source.
   Check exact pairing, inverse products, conjugation, grades, constant-frame
   derivatives and the induced bracket. Shared authentication of the six-source
   decoder is permitted and must be distinguished from independent new adapter
   derivations. Do not infer a BRST transformation or master identity from this.

The proof may remain factorized in tensor slots and constant linear maps. A
dense expanded 328-coordinate quartic catalog is not required. Finite samples
may challenge an implementation but cannot substitute for universal identities.

Validation: pole-blind, read-only calculation routes; independent replay;
byte-identical fresh regeneration of new evidence; meaningful adversarial
regressions and relevant inherited tests; inherited bindings and authority
unchanged; metadata inventory stable during auditing. Historical custody exit
2 and its seven unresolved bindings remain failures of custody, never PASS.
Solo review policy V1 applies. Published literature is context, not independent
certification. No personnel outreach is required or planned.
