# Non-Abelian residual-H / M08 semantic architecture preflight V1

## Preregistered computational task

- **Claim type:** bounded exact non-Abelian kinematics and source/gauge-fixing architecture review; no full-M08 replacement claim.
- **Primary authority:** the immutable C3 physical split, corrected RH normalization, S1 background convention, scalar-covariance candidate and A4V2 gauge-fixing function. The active scientific state remains unchanged.
- **Independent check:** reconstruct adjoint and curvature tensors from physical antisymmetric 10-by-10 matrices; independently implement a local source/gauge-fixing control with ordered graded words rather than exterior coefficients and Euler brackets.
- **Required independence:** algebra/algorithm and code-path independence for decisive identities. Shared model, input split, Python, SymPy and analyst are explicitly not independent.
- **Representation-risk controls:** evaluation dual versus primal coordinates in the nonorthonormal H basis; background versus quantum residual actions; independent parameter versus composite substitution; transported versus raw gauge-fixed source action.
- **Physical reconstruction:** physical SO(10) matrices, all 66 actual residual-H generator pairs, all 12 composite-curvature covariance equations, and the free continuum nonminimal source limit.
- **Promotion gate:** record bounded outcomes and remaining obligations only. No replacement, H-basic domain, full master action, catalog extension or scientific gate is promoted by this review.

## Scope fixed before calculation

1. Compare two local H actions, not one ambiguous action. Quantum residual transformations leave Abar inert and act affinely on q. Background transformations act affinely on Abar and homogeneously on q. Both act on Abar+q as a connection. Freeze independent even parameter jets; these are test variables, not new physical fields.
2. Use action-normalized constants f=F_raw/sqrt(2). Check exact Lie closure on H, the 33-dimensional heavy module, the physical 10-dimensional representation and their evaluation duals. Do not rerun the previously qualified 990-pair/328-scalar reconstruction; bind and explicitly identify reuse of that evidence.
3. Derive R_H=-P_H[u,u]/2 as a composite and test covariance, including a non-symmetric-coset control. Do not make R independent or assume the SU(2)/U(1) symmetric-coset formulas apply.
4. Derive a canonical contraction/source lift on the prospective light nonminimal block. This is a necessary generator-level test, not all M08 reverse source images.
5. Test the effect of complete light gauge fixing on local source transformations in the already-qualified free BV limit. Transport the structural operators with the canonical source shift. Require a nonzero source control distinguishing a transported action from an incorrectly retained raw source action.
6. Inspect all historical role/source bindings and the affine-background/light-gauge-fixing structure. Quantify prospective additional partner grades and component counts, without adding them to the active alphabet or constructing operators.

## Mandatory distinctions and stops

The background Ward action is not {iota,Q} on a BRST-inert Abar. Light quantum gauge fixing need not be invariant under the raw quantum local action. A canonical gauge-fixing change transports Q, the local action and contraction together. No raw-source-domain transfer is assumed.

The restricted functional domain of the qualified SU(2)/U(1) model is not promoted as the M08 domain. Before full M08 reconstruction, the choice of quantum/background/transported residual conditions, full canonical source map, partial/light gauge fixing and quotient descent must be specified and independently checked. A specialist review remains required; a review packet is not specialist endorsement.

Preserve Sigma, all six old source couplings, all 17 old images, corrected derived RH history, the old exact negative controls, JCAT/T5 and d-gh<=4. Do not compute HB1, cochain dimensions, C5 columns, ranks, EOM quotients, cohomology, C1_GS, M08 attempt 2 or subsequent gates. No GPU or T5 reconstruction. Formal authority remains 34/39.

## Validation contract

New evidence is generated to stdout and frozen separately before exact comparison. Audits regenerate bytes, hash bound inputs, compare workspace/active-data metadata before and after, reject adversarial evidence changes and remain read-only. Performance records wall/CPU/process peak and OS I/O, with unavailable parse/cache/file-operation counters labeled unavailable. Historical custody is separate and may remain exit 2. No unrestricted repository-wide PASS is asserted. Commit locally; do not push; stop after this review.
