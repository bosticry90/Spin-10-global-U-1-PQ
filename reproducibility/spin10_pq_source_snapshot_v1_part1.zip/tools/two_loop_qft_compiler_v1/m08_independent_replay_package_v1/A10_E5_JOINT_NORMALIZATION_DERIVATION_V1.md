# Prospective joint-normalization derivation

This freezes the derivational strategy before calculation, not its verdict.
Use the actual transported E2 polynomial and retained reference inverse.
The already qualified source poles and ghost kinetic zero constrain the
leading field normalization. Free doublet compatibility transports the
antighost and auxiliary together. Their evaluated source maps follow by
cotangent duality, not by assigning the carrier Gram to canonical brackets.

The source-linear generator in the declared source-left convention is

    Klin = g xi [JC^T N C - Jubar^T N_M^T ubar
                            + JLambda^T N_M^T Lambda].

Its physical action variation is zero because no physical B/x is scaled.
The complete source/gauge-fixing variation must be calculated. In particular
it changes the free gauge–auxiliary mixing and the quadratic auxiliary width.
Do not declare those changes to be the actual quantum poles in advance.

The selected mixing bubble combines a derivative gauge/ghost cubic with
the literal xi Lambda/ubar/u vertex. Use both matrix Hessians with Fourier
momenta, or independently expand -i Tr log of the odd Gaussian operator.
At nonzero momentum the vector integral is fixed by k -> -k-q symmetry of
the paired heat profile; the scalar bubble is the authenticated E1 integral.
Every derivative placement and H-zero group channel must be compared.

For a one-loop two-point graph without lower-degree insertions, E_internal=V
implies sum(degree(vertex)-2)=2. Thus either two cubics or one quartic occur.
Apply this criterion to the literal coupling/field inventory, not a schematic
textbook ghost action. In particular the order-xi^2 Lambda width pole was
already qualified; a distinct g*xi^2 pole is not implied by field normalization.
Positive-dimensional orbit/mass insertions cannot manufacture the same
dimension-four logarithmic coefficient. Keep their preserved records.

If the field-normalization width image disagrees with the calculated width
coefficient, solve the corresponding Q0 primitive equation on a symmetric
H-invariant dual-heavy bilinear. Q0 ubar=-Lambda supplies the linear map from
ubar^T A Lambda to -Lambda^T A Lambda. Antisymmetric A belongs to its kernel
at this projection and is not fixed by the width equation; no claim of a
unique complete primitive follows. Higher-order interacting images must remain
in the full Q image and require later loop comparison.

For the complete candidate K, independently establish

    candidate = QK - partial_mu theta^mu = -delta_K(P_E2).

Use qualified source columns for the primary Q image; replay directly varies
the full polynomial with the canonical Hamiltonian field/source vector and
derives its boundary current. Ordinary jets are prolonged without truncation.
The existing physical Euler adapters remain unchanged verified dependencies.

The transformation and source-free primitive are only prospective local
normalization data. Verify their canonical/real/H structure and retain the
background-dependent regulated field measure. Sources are not integrated
variables and cannot cancel that measure. Matching selected UV poles cannot
prove the remaining Ward/Slavnov/contact identities or full quantum A5.
