# E5 normalization types: corrected auxiliary carrier

This prospective V2 retains all NT1, NT2, evidence, failure, quantum and
authority requirements of `A10_E5_NORMALIZATION_TYPES_CONTRACT_V1.md`, except
for its incorrectly typed definition of the shear F. V1 remains immutable.
Its first H failure is preserved in primary_attempt_2, preparation_2 and an
exact failure disposition. V1's direct Euler-column contraction is rejected;
it is not counted as qualified work or overwritten.

The E2 auxiliary field Lambda is evaluation-dual heavy. Its Euler column
Q JLambda is primal heavy. A shear of Lambda must therefore lower the Euler
column using the inherited G_M, not contract two primal indices with delta.
Freeze this correction before any V2 execution:

    E_i = coeff_xi(Q JLambda_i)|two odd fields,
    F_i = sum_j (G_M)_ij E_j,
    Kshear = g^2 xi sum_i JLambda_i F_i.

Here G_M = U^T U is the unchanged qualified heavy Gram matrix and
raw Lambda = U^T Lambda_phys, raw JLambda = U^-1 JLambda_phys. Independently
derive E from the complete gauge-fixing density and check both source/field
charts and every H identity. No metric entry or coefficient is fitted to the
actual quartic residual. The unit coefficient remains a prescribed classical
image, not a subtraction choice. Add the unlowered V1 shear as an exact
non-H-compatible negative control with its complete failed H variation.

The known dimension-one E1 OrbitPullback coefficients stay typed after fixed
numerical vacuum insertion. Reconstruct their exact QK image from the sealed
E1 heavy-orbit fermion term; check its coefficient dimension and retain the
g^3 xi^2 scalar-antighost-ghost companion. Do not grant a blanket exception
to grading or discard these terms. The previous raw-word precheck failure and
all 3,936 failed terms remain preserved.

V2 investigates the corrected mathematical type and its complete classical
descendants. It does not further fit or adopt the failed V1 normalization.
Both full actual-quartet and earlier cubic normalization failures remain.
No new loops, general invariant-tensor solution, quantum A5/E5, physical or
machine-authority change, external action, publication or push is authorized.
The full Spin(10) x global U(1)PQ goal stays active/incomplete.
