"""Shared serialization, alphabet and graded arithmetic; no scientific verdict.

The two derivations share this arithmetic, Python/SymPy, input assumptions and
analyst. Their geometry extraction and source differentiation are separate.
"""
import itertools
import sympy as s
from a10_executable_action import HERE, ROOT, read, mat, record, digest, SECTORS, ETA
from interacting_actual_h_preflight_replay import GaugeWords

g=s.Symbol('g10', real=True)
H=range(12); M=range(12,45); IDS=range(45)
DIM={'Phi':54,'Sigma':252,'phi':20,'S':2}

def algebra():
    w=GaugeWords(0)
    fields={**{f'B{a}_{mu}':(1,0,0) for a in IDS for mu in range(4)},
            **{f'x_{sec}_{i}':(1,0,0) for sec,n in DIM.items() for i in range(n)},
            **{f'C{a}':(1,1,1) for a in IDS},
            **{f'ub{i}':(1,-1,1) for i in M},**{f'L{i}':(2,0,0) for i in M},
            **{f'bar{i}':(1,-1,1) for i in H},**{f'b{i}':(2,0,0) for i in H}}
    w.fields=fields;w.pairs=[(z,'J'+z) for z in fields]
    w.grades=fields|{J:(3-d,-1-gh,1-p) for z,J in w.pairs for d,gh,p in [fields[z]]}
    w.external={f'E{z}':(3,0,0) for z in fields if z.startswith(('B','x_'))}
    w.p={n:v[2] for n,v in (w.grades|w.external).items()}
    assert len(w.pairs)==643
    return w

def rows(P,w):return w.record(P)
def zero(P,label,w):
    if P:raise AssertionError((label,rows(P,w)[:8]))

def source_columns(action,w):
    """One-pass left Euler differentiation of every ordered source monomial."""
    terms={name:[] for name in w.grades}
    for word,c in action.items():
        prefix=0
        for pos,(name,jets) in enumerate(word):
            if name in terms:
                sign=(-1)**(w.p[name]*prefix+len(jets))
                terms[name].append(w.scale(w.dword({word[:pos]+word[pos+1:]:c},jets),sign))
            prefix+=w.p[name]
    el={n:w.add(*v) for n,v in terms.items()}
    return {n:el[other] for z,J in w.pairs for n,other in ((z,J),(J,z))}

def geometry_primary():
    data=read(HERE/'frozen_a10_physical_reconciliation/full_primary.json')
    Q=mat(data['C3_plane_to_parent']); f={}
    for k,a,b,v in read(HERE/'frozen_rh_composite_adjudication/RH_primary_closed.json')['upper_index_structure_constants_raw']:
        f[k,a,b]=s.simplify(s.sympify(v)/s.sqrt(2));f[k,b,a]=-f[k,a,b]
    rho={sec:[s.SparseMatrix(DIM[sec],DIM[sec],{}) for a in IDS] for sec in SECTORS}
    for sec in SECTORS:
        plane=[mat(r) for r in data['representation_matrices'][sec]]
        for a in IDS:
            values={}
            for k in IDS:
                if Q[k,a]:
                    for address,v in plane[k].todok().items():values[address]=values.get(address,0)+Q[k,a]*v
            rho[sec][a]=s.SparseMatrix(DIM[sec],DIM[sec],{key:s.simplify(v) for key,v in values.items() if v})
    return f,rho,Q

def architecture(Q):
    w=algebra(); G=Q.T*Q;Qi=Q.inv()
    source=read(HERE/'frozen_a10_cotangent_adapter/source_composition.json')
    return {'schema':'A10_BV_CANONICAL_ARCHITECTURE_V1','inactive':True,
        'pairs':[[z,J,list(w.grades[z]),list(w.grades[J])] for z,J in w.pairs],
        'canonical_pairs':643,'canonical_generators':1286,'source_left_Q':'(S,.)',
        'bracket':'(-1)^p_z (F right_z G left_J - F right_J G left_z)',
        'even_action_columns':'Qz=Euler_left_J S; QJ=Euler_left_z S',
        'C3_to_plane_field':record(Q),'plane_to_C3_field':record(Qi),
        'C3_to_plane_source':record(Qi.T),'plane_to_C3_source':record(Q.T),
        'gauge_metric_C3':record(G),'canonical_pairing':'identity; not gauge_metric_C3',
        'conjugation':'real plane fields; parent conjugation Q^-1 conjugate(Q); source conjugation Q^T conjugate(Q^-T)',
        'historical_sources':['K_V','K_q','K_phi','L_u','K_Lambda','L_c'],
        'source_decoder':'frozen_source_component_decoder/bindings.json; evaluation and typed frames remain distinct',
        'K_phi_composition_sha256':digest(source),
        'prospective_sources':['K_ubar','K_cbar','K_lambda'],
        'quantum_split':'B_plane=Q*(Abar_H+q_parent); QAbar_H=0; Abar has 12 H components only',
        'scalar_split':'x=v+eta; v fixed; Qeta=-g rho(C)(v+eta)',
        'nonminimal_representation':'ubar,Lambda evaluation-dual heavy; paired sources primal heavy',
        'composite_R_H':'R_H=-[u,u]_H/2; not a canonical independent field',
        'source_action':'sum J_z Qz, sources on the left; source parity is 1-p_z',
        'field_source_frame_identity':record((Qi.T).T*Q),
        'physical_action':'../frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json',
        'scalar_Euler_dependency':'../frozen_a10_cotangent_adapter/primary.json; Adapter.pullback(raw ordered Euler)',
        'boundaries':'compact support variations, or boundary conditions annihilating the stated divergence current',
        'jet_scope':'all symmetric ordinary jets by prolongation; computational order limit raises, never zero',
        'Stage_E_authorized':False,'adopted':False,'sources_activated':False}
