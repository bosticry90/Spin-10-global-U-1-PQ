# Measured one-loop pole assembly and restoration dependencies, MF V1

Baseline df9b452653dbb89c7fb264b21a32033fa31f5b94. Previous turn PROGRESS:
the actual g^3 quartet qualified, but the frozen prospective prediction failed
in 3,960 physical slots. Preserve that obstruction and every prior scope.
The next action is the measured-functional assembly authorized in V30 and the
user's assessment. No normalization fitting, generator/image adjustment or
new actual higher/physical loop occurs in this increment. project_state.json
v113, 34/39 and its bytes remain the sole machine-readable authority.

MF1 assembles the finite canonical polynomial part of the measured local
one-loop residue in common Minkowski hbar/(32*pi^2*epsilon_UV) units:
g^0 xi^2 auxiliary width; g*xi auxiliary/gauge mixing; g*xi gauge-source
derivative; g^2*xi scalar-source/ghost/scalar; g*xi^2 auxiliary/antighost/ghost;
g^2*xi^2 quartet; g^2*xi nonminimal-source/antighost/ghost;
g^2 auxiliary/antighost/ghost with its reconciled real widths; g^2*xi
derivative-gauge/antighost/ghost; g^2 antighost-source/gauge derivative;
g^2 auxiliary-source/Box ghost; and g^3 quartet. Retain the measured zero
g*xi ghost kinetic and g*xi^2 width logarithms as separate zero records.
These are one-loop residues, not subtraction densities with opposite signs.

Freeze own-route actual input fields in 42 sealed chains. Reconstruct source
and mixing expressions from actual group tensors and literal action/frame
inputs, not counterterm candidates. Old JSON records contain candidate fields;
the loader selects declared actual fields and never decodes their candidate
nodes. Primary direct canonical imports and replay own physical tensors,
constant dual/primal pullbacks and independent contraction/typed reconstruction
must agree on each sector and the sum. All 643 pairs, 48 background components,
45 ghost/antighost directions and source parities remain in the alphabet.

Retain separately: the qualified indexed ordinary g^0 scalar Hessian-square
program, its Euclidean/Minkowski subtraction conventions and unexpanded beta
coefficients; the g*xi ghost cutoff-power and finite profile; regulators,
reference masses, finite subtractions and IR limitations. These nodes are
not silently converted into explicit canonical polynomials or combined finite
prescriptions. The scalar-source phi tensor was directly checked; extension
to other scalar representations uses the previously qualified commutator
theorem. Mark that dependence explicitly. No dense Sigma or scalar beta
recalculation. A coefficient collection is not a complete quantum prescription.

MF2 computes the complete local background Ward variation of the finite
measured polynomial sum with all 12 arbitrary omega fields and their ordinary
jets, using actual E3 operations. Compare prefix prolongation with independent
graded jet-gradient action. Keep every nonzero parameter-jet coefficient,
and require constant-parameter identities. Preserve ordinary IBP currents
and nonzero Euler witnesses when a residual is not a boundary. A nonzero
variation of the measured subset is an open partner obligation, not the
actual complete quantum Ward breaking.

For every Ward residual type, derive complete necessary backward local-input
types within d_project=4, gh=0, even, nonnegative parameter dimensions and
finite ordinary jets. Include both total B_H and external A_H connections:
their affine shifts can supply missing partners. Linear transformations keep
the field/source types and move existing jets onto omega; affine connection
shifts remove B/A and add one omega derivative. Record coupling predecessor
orders, measured/unknown provenance and source count. Types are necessary,
not a complete Lorentz/H invariant coefficient basis, graph evaluation or
solved completion. Unknown partner coefficients stay unbound.

MF3 computes TWO projected first-order Slavnov contributions Q' Gamma_known:
(a) g^2, one antighost and two ghosts, total ordinary jet order 2;
(b) g^3, one auxiliary, one antighost and two ghosts, no jets.
All source/background/gauge/scalar factors are excluded only by these exact
monomial projectors; no field equation or source activation is used. The
full raw jet domains are 3,539,700 and 2,004,750 respectively. Equal ghost
indices with unequal jets remain distinct odd generators in (a).

Screen all 1,286 actual E2 source-polynomial columns and classify coupling,
jet, field/source types and coefficient dimension before selecting terms.
Q raises (dimension,ghost number,parity) by (1,1,1). Positive-dimensional
Orbit/mass terms stay explicit outside the selected coefficient-dimension-zero
targets. The separately indexed physical Euler programs are not zero: prove
that their bosonic field content cannot enter these two projectors and retain
them as deferred in the full Slavnov functional. The indexed scalar program
has no antighost/auxiliary source and likewise cannot enter these projectors.
This does not compute its full Slavnov variation.

Derive the exhaustive necessary dimension-four input-type/coupling census
for both projected Slavnov targets from the actual column signatures, by
forward substitution and independent backward multiset subtraction. No
coefficient image, inverse problem or fit to the residual is solved. Missing
JC-C-C, higher source and other eligible partner amplitudes remain explicit
unknowns, even when their predicted values occur in old artifacts. Retain
the uncalculated regulator/measure/breaking insertion Delta_s: never require
Q' Gamma_known=0 or infer an anomaly from its residual alone.

At one loop the shared system is W_b Gamma_1=Delta_b,1 and
Q' Gamma_1=Delta_s,1, with Gamma_1=Gamma_known+Gamma_unknown. W3's higher
nonlinear brackets, W5 whole-product insertions, W6 source/observable mixing,
rho-contact products, A1-A5 and IR removal retain their previous conditional
status. Neither an isolated amplitude match nor this assembly implements
those assumptions. Record the exact unmeasured partners needed for the next
actual calculation, including backgrounds and insertion right sides.

Before computation freeze contract, source, input manifest/state and any unit
controls. Require exact arithmetic/real width locals, complete source parity,
constant-frame roundtrips and matching distinct assembly/differential/census
routes. Negative controls must detect incorrect loop-to-density units,
source parity, omitted sector/partner, equal-index unequal-jet deletion,
external-background omission and replacing unknown amplitudes/breakings by
zero. Shared assumptions/action/data/arithmetic/Python/SymPy/analyst disclosed;
no agents or outside endorsement. Resource limits mean INCOMPLETE, not a cap.

Preserve failed/unfinished source/start/full outputs and dispositions. Stop on
an assembly, type, signed-action or dependency completeness discrepancy before
claiming qualification. Nonzero partial variations with unmeasured partners
are an intended open disposition, not a failed full quantum identity.
Validation requires scientific/process/governance and delegated e5 checks,
four own-byte fresh controls/primary/replay/comparison, 42 protected chains,
new/protected/state and size-mtime invariance, custody exit 2/seven unresolved
references (never PASS), and raw index/worktree equality before local commit.
Authenticate old expensive loops/images only; no new physical/catalog/HB1/C5/
C1_GS/matching, adoption/promotion, outreach/push/publication or full goal claim.

Possible disposition: qualified measured-residue assembly with exact open
restoration dependencies; exact stopped inconsistency; underdefinition; or
incomplete execution. The g^3 candidate failure remains intact. The next
smallest actual source/partner calculation must have a separate prospective
contract and must not be chosen by fitting the frozen quartet residual.
