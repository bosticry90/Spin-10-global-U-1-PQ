"""Typed inactive E1 replacement, immutable dependencies and exact utilities."""
from functools import lru_cache
from a10_stage_e_common import recovery, matrix_rows, HISTORICAL
from a10_bv_integration_common import HERE, ROOT, read, mat, clean, coefficient, rows, canonical
from a10_bv_common import algebra, g, H, M, DIM, IDS
from a10_executable_action import ETA, digest
import sympy as s

OUT=HERE/'frozen_a10_e1_fermion'
xi=s.Symbol('xi',real=True); etaH=s.Symbol('eta_H',real=True)
STATUS='PASS_BOUNDED_E1_DERIVED_REPLACEMENT_NOT_HISTORICAL_EQUIVALENCE'
NAME='M08_PHYSICAL_FRAME_GAUGE_FERMION_V1'
PREDECESSORS=('frozen_source_component_decoder','frozen_phase_c_scalar_action',
 'frozen_a10_physical_reconciliation','frozen_a10_executable_reconciliation',
 'frozen_a10_cotangent_adapter','frozen_a10_bv_master','frozen_a10_gauge_euler_adapter',
 'frozen_a10_bv_integration','frozen_a10_stage_e')

def decode_typed(records):
    from a10_bv_integration_common import decode
    return {word:c.subs({s.Symbol('xi'):xi,s.Symbol('eta_H'):etaH}) for word,c in decode(records).items()}

def register(w,name,grade):
    w.external[name]=grade;w.p[name]=grade[2]

def alphabet():
    w=algebra()
    for h in H:
        for mu in range(4):register(w,f'A{h}_{mu}',(1,0,0))
        register(w,f'omega{h}',(0,0,0))
    return w

def scalar_names():return [f'x_{sec}_{i}' for sec,n in DIM.items() for i in range(n)]

def charts(Q):
    QH,QM=Q[:,:12],Q[:,12:];GH=(QH.T*QH).applyfunc(clean);GM=(QM.T*QM).applyfunc(clean)
    GHinv, GMinv=GH.inv(),GM.inv();FH=QH;FM=(QM*GMinv).applyfunc(clean)
    assert QH.T*QM==s.zeros(12,33)
    blocks={}
    for label,F,left,source in (
      ('heavy_primal',QM,GMinv*QM.T,FM),
      ('heavy_dual',FM,QM.T,QM),
      ('light_primal',FH,GHinv*QH.T,QH*GHinv)):
        F,left,source=[R.applyfunc(clean) for R in (F,left,source)]
        P=(F*left).applyfunc(clean);C=(left*F.conjugate()).applyfunc(clean)
        Cs=((source.T*source).inv()*source.T*source.conjugate()).applyfunc(clean)
        assert (left*F).applyfunc(clean)==s.eye(F.cols)
        assert (P*P-P).applyfunc(clean)==s.zeros(45)
        assert (source.T*F).applyfunc(clean)==s.eye(F.cols)
        assert (F*C-F.conjugate()).applyfunc(clean)==s.zeros(*F.shape)
        assert (C*C.conjugate()).applyfunc(clean)==s.eye(F.cols)
        assert (Cs.T*C).applyfunc(clean)==s.eye(F.cols)
        blocks[label]={'field_embedding':matrix_rows(F),'left_section':matrix_rows(left),
          'source_embedding':matrix_rows(source),'invariant_bilinear':matrix_rows((F.T*F).applyfunc(clean)),
          'physical_projector':matrix_rows(P),'conjugation':matrix_rows(C),
          'source_conjugation':matrix_rows(Cs),'canonical_pairing':matrix_rows((source.T*F).applyfunc(clean)),
          'ambient_inverse_claimed':False,'field_rank':F.cols,'ambient_kernel_dimension':45-F.cols}
    return {'blocks':blocks,'scalar_source_dependency':'frozen_a10_cotangent_adapter/bindings.json',
      'heavy_antighost_auxiliary_chart':'heavy_dual','light_antighost_auxiliary_chart':'light_primal',
      'gauge_ghost_chart':'heavy_primal and light_primal','canonical_pairing':'identity field/evaluation source',
      'parameters':{'xi':'real dimensionless heavy width','eta_H':'real dimensionless light width','alpha':'xi'},
      'historical_equivalence_proved':False}

def euler_columns(P,w,names):
    """Primary prefix differentiation, all left Euler covectors in one pass."""
    buckets={name:[] for name in names}
    for word,c in P.items():
        prefix=0
        for pos,(name,jets) in enumerate(word):
            if name in buckets:
                buckets[name].append(w.scale(w.dword({word[:pos]+word[pos+1:]:c},jets),
                    (-1)**(w.p[name]*prefix+len(jets))))
            prefix+=w.p[name]
    return {n:canonical(w.add(*parts)) for n,parts in buckets.items()}

def first_variation(P,el,w,names,route):
    for n in names:register(w,'h'+n,(w.grades|w.external)[n])
    images={n:w.var('h'+n) for n in names}
    if route=='primary':delta=w.act(P,images,parity=0)
    else:
        from a10_bv_integration_common import derivative_action
        delta=derivative_action(P,w,images)
    GH=mat(read(HERE/'frozen_a10_bv_master/primary.json')['architecture']['gauge_metric_C3'])[:12,:12]
    theta=[]
    for mu in range(4):
        T=w.add(*(w.mul(w.var(f'ub{i}'),w.var(f'hB{i}_{mu}')) for i in M),
          *(w.scale(w.mul(w.var(f'bar{h}'),w.add(w.var(f'hB{k}_{mu}'),w.scale(w.var(f'hA{k}_{mu}'),-1))),v)
            for (h,k),v in GH.todok().items()))
        theta.append(w.scale(T,ETA[mu]))
    rhs=w.add(*(w.mul(w.var('h'+n),el[n]) for n in names),*(w.D(T,mu) for mu,T in enumerate(theta)))
    residual=canonical(w.add(delta,w.scale(rhs,-1)))
    assert not residual,('FIRST_VARIATION',rows(residual)[:8])
    return {'delta_coefficients':len(canonical(delta)),'Euler_pairing_coefficients':len(canonical(w.add(*(w.mul(w.var('h'+n),el[n]) for n in names)))),
      'boundary_current':[rows(T) for T in theta],'residual':[],'arbitrary_graded_variations':True,
      'boundary_conditions':'compact support variations, or vanishing integrated boundary current','EOM_used':False}

def ward_images(w,f,rho,background):
    images={}
    for a in IDS:
        for mu in range(4):
            images[f'B{a}_{mu}']=w.add(w.D(w.var(f'omega{a}'),mu) if a in H else {},
              *(w.scale(w.mul(w.var(f'B{b}_{mu}'),w.var(f'omega{h}')),g*v)
                for (k,b,h),v in f.items() if k==a and h in H))
    for h in H:
        for mu in range(4):
            images[f'A{h}_{mu}']=w.add(w.D(w.var(f'omega{h}'),mu),
              *(w.scale(w.mul(w.var(f'A{b}_{mu}'),w.var(f'omega{c}')),g*v)
                for (k,b,c),v in f.items() if k==h and b in H and c in H)) if background else {}
    for prefix,ids in [('C',IDS),('bar',H),('b',H)]:
        for a in ids:images[prefix+str(a)]=w.add(*(w.scale(w.mul(w.var(prefix+str(b)),w.var(f'omega{h}')),g*v)
            for (k,b,h),v in f.items() if k==a and h in H and b in ids))
    for prefix in ('ub','L'):
        for a in M:images[prefix+str(a)]=w.add(*(w.scale(w.mul(w.var(prefix+str(b)),w.var(f'omega{h}')),g*v)
            for (b,h,k),v in f.items() if k==a and h in H and b in M))
    for sec,n in DIM.items():
        for i in range(n):images[f'x_{sec}_{i}']=w.add(*(w.scale(w.mul(w.var(f'omega{h}'),w.var(f'x_{sec}_{j}')),-g*v)
          for h in H for (k,j),v in rho[sec][h].todok().items() if k==i))
    return images

def ward(PM,PH,w,f,rho,stage,route):
    result={}
    from a10_bv_integration_common import derivative_action
    act=(lambda P,I:w.act(P,I,parity=0)) if route=='primary' else (lambda P,I:derivative_action(P,w,I))
    for background in (False,True):
        images=ward_images(w,f,rho,background)
        heavy=stage(('background' if background else 'quantum')+'_heavy_local_Ward',lambda:canonical(act(PM,images)))
        assert not heavy,('HEAVY_LOCAL_WARD',background,rows(heavy)[:8])
        full=stage(('background' if background else 'quantum')+'_complete_local_Ward',lambda:canonical(act(w.add(PM,PH),images)))
        if background:assert not full,('BACKGROUND_LOCAL_WARD',rows(full)[:8])
        else:
            assert full,'LIGHT_QUANTUM_FIXING_MUST_BREAK_H'
            witness=canonical(w.EL(full,'bar0'));assert witness
            result['light_quantum_expected_breaking']={'coefficients':len(full),'Euler_bar0':rows(witness),
              'not_boundary_only':True,'requirement':'light quantum H is fixed; background H is retained'}
        result[('background' if background else 'quantum')+'_heavy_residual']=[]
    result['background_complete_residual']=[]
    result['parameter_jet_scope']='independent local omega and first/second jets; no constant-parameter substitution'
    return result

def finish(route,chart,ast,parts,el,variation,wards,geometry_record):
    return {'schema':'A10_TYPED_E1_FERMION_REPLACEMENT_V1','route':route,'status':STATUS,
      'candidate_name':NAME,'classification':'genuinely_modified_derived_replacement; historical equivalence unestablished',
      'recovery':recovery(),'charts':chart,'executable_AST':ast,
      'polynomial_parts':{n:rows(P) for n,P in parts.items()},'Euler_columns':{n:rows(P) for n,P in el.items()},
      'first_variation':variation,'local_Wards':wards,'geometry':geometry_record,
      'canonical_field_columns':643,'external_background_columns':48,'inactive':True,
      'old_fermion_modified':False,'historical_equivalence_proved':False,'Stage_D_preserved':True,
      'E2_E5_executed':False,'full_fixed_master_constructed':False,'sources_activated':False,
      'candidate_adopted':False,'catalog_rebuilt':False,'HB1_C5_run':False,'C1_GS_calculated':False,
      'formal_authority':'34/39_UNCHANGED','external_endorsement':False,'personal_outreach':False}

def candidate(p):
    """Separate executable AST artifact with exact finite tensor bindings."""
    f=read(HERE/'frozen_a10_bv_master/primary.json')['geometry']['f']
    out={'schema':'M08_INACTIVE_TYPED_GAUGE_FIXING_FERMION_V1','fermion_id':NAME,
      'AST_schema':'M08_EXACT_OFFSHELL_LOCAL_FUNCTIONAL_AST_SCHEMA_V1',
      'local_terms':p['executable_AST'],'status':'INACTIVE_DERIVED_REPLACEMENT',
      'historical_equivalence_proved':False,'parameter_coordinates':{'g10':{'real':True,'mass_dimension':0},
        'xi':{'real':True,'mass_dimension':0},'eta_H':{'real':True,'mass_dimension':0}},'alpha_alias':'xi',
      'tensor_bindings':{
        'GM_inverse':p['charts']['blocks']['heavy_dual']['invariant_bilinear'],
        'GH':p['charts']['blocks']['light_primal']['invariant_bilinear'],
        'OrbitPullback':p['geometry']['orbit_pullback'],
        'dual_cubic':p['geometry']['dual_cubic_coefficients'],
        'f_mHm':[row for row in f if row[0] in M and row[1] in H and row[2] in M],
        'f_HHH':[row for row in f if all(i in H for i in row[:3])]},
      'tensor_index_addresses':'heavy matrix/Orbit local rows 0..32 map to actual labels 12..44; f and dual_cubic use parent labels',
      'field_bindings':{'V':'B_M','BH':'B_H=Abar_H+q_H','Abar':'A_H (12 components per spacetime direction)',
        'qH':'B_H-A_H','ub':'StageD evaluation-dual ub','L':'StageD evaluation-dual L',
        'u':'C_M','bar':'StageD light primal bar','b':'StageD light primal b','eta':'x-v, 328 real coordinates'},
      'coefficient_mass_dimensions':p['geometry']['coefficient_mass_dimensions'],
      'component_execution':'a10_e1_fermion_primary.py; GradedExecutor; supplied first jets retain diagonal derivative labels',
      'finite_index_domains':{'H':list(H),'M':list(M),'A':list(range(328)),'mu':list(range(4))},
      'Lorentz_metric':list(ETA),'no_canonical_source_shift_performed':True,
      'candidate_adopted':False,'E2_E5_executed':False}
    out['fermion_sha256']=digest(out);return out
