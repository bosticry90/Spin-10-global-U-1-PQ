# Actual ghost-source pole and selected measured Slavnov consistency, GS result V1

The actual leading g10^2*xi J_C-C-C logarithmic pole agrees between the literal
graded Fourier/Born calculation and the independently routed physical Wick
tensor calculation. All44,550 source/antisymmetric-ghost coefficients compare,
including calculated zeros. The unchanged actual pole has683 nonzero physical
coefficients:263 have a light source direction. The source is EVEN; both
ghosts are odd. These are finite component coefficients, not44,550 distinct
physical amplitudes or externally independent scientific observations.

In common hbar/(32*pi^2*epsilon_UV) units the full density is
g10^2*xi sum_(s,i<j) V_(s;i,j) JCp_s Cp_i Cp_j. For example
V_(14;12,13)=-8*sqrt(10)/5. The physical density has683 terms and its canonical
primal/dual pullback has226. Both full densities and coupling-stripped slots
are stored; the missing/double coupling gate is explicit. All12 local no-jet
H identities, reality and canonical/physical roundtrips agree.

The complete eligible families are the source/derivative-ghost/auxiliary
triangle and source/four-ghost bubble. Their707/444 nonzero physical tensors
combine to683. Primary retains all six triangle and both bubble Born words,
all180 integrated reference components, anomalous CC/aa Hessian blocks,
both odd orientations and mixed B/Lambda propagators. The full4Lorentz
elementary Born/Wick weights are triangle_antighost=-2,
triangle_gauge=+2, triangle_external_ghost=0, bubble=-2. The literal derivative
current is retained and verified. The mixed edge forces the quantum gauge
direction to M after all45 directions are constructed; this is not a
prediction-based exclusion. Reference widths drop from the full calculation.

Replay reconstructs the source sign and dual pairing from the physical10
commutators, crosschecks its own literal action before calculating the loop,
and uses routed Wick contractions followed by antisymmetric group sums.
It does not import a primary pole, canonical candidate, projected completion
tensor or an M-adjoint Jacobi assumption. Separate graph incidence/coupling/
UV exclusions, full heat profiles6/4 and k_E^2>R_UV^2>0 keep the calculation
within its dimension-zero logarithmic coefficient. No finite/IR/scaleless,
mass-log/cutoff-power, chiral-anomaly or measure-restoration result is inferred.

## Joint measured functional

After the complete actual tensor comparison, the new pole is added to the
properly imported measured residue. The resulting13-sector canonical density
has27,971 terms. Prefix and graded jet-gradient calculations of the selected
g10^2 a-C-C/twojet Slavnov left side agree over the full3,539,700 raw monomial
domain, including equal ghost colors at distinct jets.

The raw left side has4,264 terms. It is exactly an ordinary divergence: its
antighost-anchored representative and ALL45 antighost Euler derivatives are
zero. Four full boundary currents,472 terms each, reconstruct the raw
variation without equations of motion. Dropping those currents gives a
nonzero exact discrepancy. Omitting the newly measured source pole leaves a
nonboundary variation. This qualifies a selected joint consistency condition
among independently calculated poles, not merely another canonical expansion.

Disposition: qualified actual source pole and zero selected MEASURED Slavnov
functional left side, subject to the completed validation receipt and seal.
Gamma_unknown, Delta_s, Delta_b, regulated measure and insertion/contact
normalizations remain unbound. The zero left side does not prove a zero
regulated breaking or complete nonlinear quantum restoration.

## Preserved input-convention failure

The original comparison.json correctly evaluated the frozen MF V3 assembly
and found2,052 canonical/6,363 physical anchored terms. Dependency review
then exposed an inherited assembly error: MF V3 added ETA[mu] to the leading
gauge-source pole. The qualified source_vertex actual record and its canonical
source projection instead contain -g10*xi JB^mu partial_mu(N C), without that
extra metric factor. The literal E2 Q_B derivative is +partial_mu C in every
component. The resulting original residual appears only in spatial components.

GS V2 was frozen BEFORE the corrected comparison. It imports both qualified
source_vertex projections, verifies the exact full source/ghost domain and
literal Q_B conventions, and replaces only that assembled sector. Both routes
reject the old99-term spatial-sign discrepancy. The auditor verifies that its
projected variation is EXACTLY the difference between the original and
corrected Slavnov left sides. No pole or normalization coefficient was fitted.

Original comparison/source/preparation/start/output bytes and the explicit
input_convention_failure_disposition_1.json are preserved. comparison.json
is UNQUALIFIED as a calculation of the actual measured functional and is not
counted as PASS. The current qualifying comparison is comparison_v2.json,
using comparison_v2/run_v2 sources and preparation_5. Original controls,
primary and replay remain qualifying, with their original preparations.

MF V3 gauge-source assembly, total-sum and dependent Ward/Slavnov coefficient
interpretations are superseded by this input repair. Their byte authentication
remains valid. Other measured sectors and actual loop records retain their
declared scopes. Do not use the old full local Ward witnesses as the current
actual functional until reassembly. The g10^3 four-ghost candidate mismatch
remains FAIL; no change here repairs it or adopts its normalization.

## Validation and authority

The exclusive validation receipt owns the exact commands, source snapshots,
starts, stdout, tests, runtimes, four byte-identical fresh executions,
43 protected predecessor chains and protected/new/state/metadata invariance.
Historical custody remains exit2 with seven unresolved references, neverPASS.
Older expensive loops/images are authenticated, not repeated. Every excluded
completed/failed interpretation stays archived. Local raw Git index/worktree
byte equality is required before commit; no push or publication is authorized.

Verification is bounded computational corroboration with shared action,
representation data, some exact word/ring arithmetic, Python/SymPy and analyst.
Formalization is not attempted; empirical connection is none; interpretation
is established only in the stated UV/component/functional scope. These are
not independent scientists or external endorsement. The existing epistemic
ladder and solo-review policy apply.

project_state.json v113/34of39 is unchanged and remains the sole scientific
authority. Full E5, A1-A5, W1-W7 quantum assumptions, source/operator transport,
whole-product insertions, nonlinear higher Slavnov brackets, quantum canonical
equivalence and IR remain unqualified. HB1/C5 stay blocked; finite C1_GS is
uncalculated. Scalar/globalPQ, fermion/Yukawa, phenomenological and broader
Spin(10)xglobalU(1)PQ obligations remain open.

Next smallest action: reassemble the complete local Ward variation and its
dependency census from the corrected13-sector measured density, retaining
B_H and external A_H affine connections, exact currents and unknown partners.
Then scope actual JB-B-C/A_H partner loops prospectively. The whole goal
remains active/incomplete.
