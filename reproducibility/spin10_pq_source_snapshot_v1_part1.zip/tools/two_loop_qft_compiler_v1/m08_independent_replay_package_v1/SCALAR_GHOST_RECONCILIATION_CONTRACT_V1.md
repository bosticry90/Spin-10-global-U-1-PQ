# Scalar–ghost convention reconciliation: bounded investigation V1

Physics decision enabled: determine whether a coherent field convention can support a future M08 BV/source review; no unification verdict is enabled.

Current blocker removed: investigate `M08_NONMINIMAL_BV_ARCHITECTURE_SCALAR_FORWARD_SQUARE_NOT_CLOSED`; removal is conditional, not assumed.

Why existing tools are insufficient: the previous exact witness checks an incompatible frozen combination, but does not derive the local gauge/matter convention or its full generator-pair consequences.

Minimum new implementation surface: one inactive finite generator-level primary calculation, a direct physical replay, bounded tests/audit and this report. Reuse certified representations and historical controls. No source replacement, operator catalog or differential matrix.

Structure-preservation obligations (maps only; otherwise explain N/A): distinguish physical positive matrix representations from coordinate-field Lie derivations; bind action normalization, non-Euclidean primal/dual transport, invariant scalar pairing and shifted VEV. A candidate sign is not an automorphism of the old failed differential. No authority transfers to untested sources, quotients or cochains.

Stopping condition: first failed exact forward-consistency or physical-convention prerequisite. Unavailable convention authority or specialist review must be reported, not supplied by assumption. Do not build M08 sources, HB1/C5 or catalogs even if bounded field checks pass.

What will be deleted or deactivated if this does not work: candidate implementation remains diagnostic/inactive; retain all failed and passing evidence. Nothing historical is deleted.

## Preregistered derivation and acceptance order

1. Recover the physical representation and connection convention. Derive the finite local transformation of the covariant derivative and the active/passive dictionary before inspecting a candidate scalar square. If the physical gauged kinetic convention is not uniquely frozen, state the conditional alternatives explicitly; do not claim a repair of the physical action.
2. Bind left odd Leibniz, ghost ordering and `Q C = -g10 [C,C]/2`. Derive the matter sign from the connection convention. Retain the old pair `(0,4)`, output/input `(0,3)` and coefficient `+1` as a negative control.
3. Test the complete residual-H generator-pair/scalar-coordinate equations, and the complete parent ghost/representation equations where the recovered conventions permit. Do not truncate ghosts to the selected pair. Keep the composite R derived, not independent.
4. Check kinetic/covariant derivative and potential symmetry using exact identities or explicitly identified reused authority. Check other frozen field sectors with variance-aware role maps, not an all-lowered structure tensor in a nonorthonormal frame. Stop if their convention is incompatible or underspecified.
5. Preserve and replay earlier source-convention and free-BV controls. These regressions do not qualify an interacting M08 source architecture.
6. Record every candidate difference, dependency impact and untested obligation. External specialist semantic review is required before adopting any replacement; internal replay does not satisfy it.

## Immutable boundaries

`Sigma_M08`, all six sources, the 17 current images, corrected R rule, JCAT/T5, weight grading and scientific state remain byte-identical. Do not read any current/historical M08 pole or projection payload. All Python runs use the existing pole-blind guard and disable bytecode writes. No EOM identification, H-basic dimension, C+2 catalog, C5 differential/rank/cohomology, C6/D6/E, attempt 2, Layer 6 or C1_GS calculation. Formal authority stays `34/39`.

New evidence is frozen before comparison with replay. Audits are read-only, verify byte-identical bounded regeneration and input hashes, and compare workspace/active-data inventories before and after. Historical custody unresolved status is not converted to PASS. Performance records distinguish measured wall/CPU/peak/I/O from unavailable finer timings. No GPU work.
