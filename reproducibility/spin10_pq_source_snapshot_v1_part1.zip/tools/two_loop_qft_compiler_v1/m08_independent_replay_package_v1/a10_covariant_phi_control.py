"""First exact small-Phi kinetic control, separate from frozen A10."""
import json
import sympy as s
from nonminimal_bv_m08_architecture import load, matrix
from interacting_actual_h_preflight import GaugeJets
from nonminimal_bv_free import ETA


def build(stage=lambda n, fn: fn()):
    data = load('frozen_action_ast_a3/A31_embeddings.json')['sectors']['Phi']
    names = ['x_'+n.replace('.', '_') for n in data['coordinate_names']]
    rho = matrix(load('frozen_scalar_adapter_v2/SA10_physical_actions.json')['physical_H_parent'][4])[:54, :54]/s.sqrt(2)
    assert rho+rho.T == s.zeros(54)
    j = GaugeJets(0); a = j.a; g = s.Symbol('g10')
    conn = ['B4_'+str(mu) for mu in range(4)]
    j.fields = {n: (1, 0, 0) for n in names+conn}; j.grades = {**j.fields, 'C4': (1, 1, 1)}
    j.external = {}; j.pairs = []; x = {n: j.var(n) for n in j.grades}
    rx = [a.add(*(a.scale(x[names[k]], v) for (row, k), v in rho.todok().items() if row == i)) for i in range(54)]
    forward = {names[i]: a.scale(a.mul(x['C4'], rx[i]), -g) for i in range(54)}
    forward.update({conn[mu]: j.D(x['C4'], mu) for mu in range(4)})
    ordinary = a.add(*(a.scale(a.mul(j.D(x[n], mu), j.D(x[n], mu)), s.Rational(ETA[mu], 2)) for n in names for mu in range(4)))
    covariant = [[a.add(j.D(x[n], mu), a.scale(a.mul(x[conn[mu]], rx[i]), g)) for i, n in enumerate(names)] for mu in range(4)]
    candidate = a.add(*(a.scale(a.mul(z, z), s.Rational(ETA[mu], 2)) for mu, vec in enumerate(covariant) for z in vec))
    old = stage('literal_Phi_control', lambda: j.Q(ordinary, forward))
    new = stage('full_nonzero_connection_cubic_quartic_Phi_Ward', lambda: j.Q(candidate, forward))
    assert old and not new
    target = sorted(['C4__0', 'x_Phi_offdiag_0_4', 'x_Phi_offdiag_0_1__0'])
    coefficient = next(r['coefficient'] for r in j.record(old) if r['word'] == target)
    rows = j.record(candidate)
    counts = {str(power): sum(s.expand(s.sympify(r['coefficient'])).coeff(g, power) != 0 for r in rows) for power in range(3)}
    assert counts['1'] and counts['2']
    return {'schema': 'A10_INACTIVE_COVARIANT_PHI_CONTROL_V1', 'status': 'PASS_FULL_PHI_KINETIC_CONTROL_ONLY',
            'coordinates': 54, 'generator': 4, 'directions': 4, 'historical_selected_coefficient': coefficient,
            'historical_variation': j.record(old), 'historical_Euler': j.record(j.euler(old, 'C4')), 'candidate_density': rows, 'candidate_variation': j.record(new),
            'candidate_Euler': j.record(j.euler(new, 'C4')), 'coupling_degree_monomials': counts,
            'connection_projected_before_variation': False, 'candidate_adopted': False, 'physical_parameters_changed': False}


if __name__ == '__main__':
    assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED')
    print('RESULT '+json.dumps(build(), sort_keys=True, separators=(',', ':')))
