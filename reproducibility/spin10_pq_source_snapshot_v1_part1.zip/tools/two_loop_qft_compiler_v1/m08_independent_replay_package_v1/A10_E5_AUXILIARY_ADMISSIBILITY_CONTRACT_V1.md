# E5 additional source-free auxiliary normalization admissibility, V1

Prospective bounded contract, baseline8657da85bb81654049320a3d5515654f767fca19.
Input frozen_a10_e5_auxiliary_next/bindings.json and36 transitive predecessor
manifests; project_state.json v113, 34/39 is sole authority. Previous turn is
PROGRESS: a complete next-order actual auxiliary pole stopped the unique
source-fixed inactive candidate. This contract investigates a necessary
condition on additional source-free normalizations, not a chosen correction.

AA1: classify every source-free local polynomial generator of grade(3,-1,odd)
that can reach a derivative-free L_aux a C density of grade(4,0,even), with
dimensionless real polynomial coefficients in g10,xi,eta_H and other existing
nonnegative-dimension inputs. AA2: derive its complete projected image for
heavy-ghost directions before opening the actual residual. AA3: test whether
the entire saved actual-minus-unique-candidate residual passes that condition,
retaining both xi^2 and xi eta_H coefficients and every zero slot.

## Invariants, types and methods

No action/source/regulator/vacuum/parameter/catalog change, inverse physical
coupling or mass, field elimination, EOM quotient, or independent-scientist
claim. Retain all643 canonical pairs,48 external backgrounds,45 auxiliary/
45 antighost/45 ghost directions. Auxiliaries and antighosts have the same
qualified evaluation-dual heavy and primal light charts; gauges/ghosts and
evaluation sources keep opposite carriers. Source-free means literally no BV
source, not evaluation of a source-dependent primitive at source zero.

Freeze code, contract, input/state SHA, independent output ownership and
dependency order before computation. Algebra-primary/replay workers are
read-only and do not read any actual auxiliary residual or candidate.
Only after both completed algebra outputs agree does the dependent comparison
open the sealed actual-minus-candidate data. No agents, duplicate workers,
overwrite, failed-evidence editing or expensive old loop/image reruns.

Type census covers ordinary jets, external A backgrounds and nonnegative
coefficient dimensions. A dimension-four no-jet L a C target leaves no positive
coefficient dimension; Q prolongation/IBP cannot remove total derivative order
in this target without EOM or coordinate-dependent coefficients. Relevant
source-free carrier types are aL and aaC; QB,Qx,QC cannot supply an auxiliary
to other carriers. Authenticate and check all643 field Q columns, all45 Qa
and QAux, and their complete coupling/field signatures. In particular Qa0=-Aux;
Qa1 and QAux1 contain only C_H. Curvature QAux2 has two ghosts and an antighost
and cannot reach a single-ghost auxiliary cubic. The H/M ghost chart is block
diagonal and must be checked rather than identified with a metric delta.

Primary enumerates every signed doublet image column of a_i a_j C_k (i<j,
k in M), preserving the upper/lower auxiliary-antighost coefficients. Replay
derives the Koszul/Euler homotopy and independently checks ordered deletion
and its projector. Complete heavy-ghost target has45^2*33=66,825 slots;
image rank=choose(45,2)*33=32,670, symmetric complement=34,155. Full target
also retains the12 H-ghost channels, totaling91,125 slots. Do not claim a full
source-dependent or H-invariant tensor classification from this projection.
The universal heavy-ghost symmetry condition applies even without H or prior
matching restrictions, so its failure refutes every more constrained
source-free repair in the declared polynomial local domain.

Record complete generic Q images using indexed Leibniz formulas for aL and
aaC and every qualified field Q column; retain their higher coupling/quartet
descendants instead of pretending the projection is the complete image.
Negative controls: incorrect doublet sign; symmetrization vs antisymmetrization;
dropping off-diagonal channels; wrong raw auxiliary/antighost carrier; and a
source-dependent auxiliary shear exhibiting a diagonal cubic image. The last
is a scope counterexample: a source-free obstruction is not a general
canonical, quantum, EOM or anomaly obstruction. Controls must have exact
nonzero residuals or explicitly rejected inferences before comparison.

## Comparison and first failure

Use only qualified primary_bound/replay_bound and comparison_v3 from the
sealed predecessor; original unbound densities remain classified failures.
Verify bound method agreement first. Transport the complete raw difference
to real physical coordinates, derive ordered L_i a_j C_k coefficients, and
check reality, every slot, all coupling coefficients and both frame directions.
Keep full symmetric/antisymmetric decompositions and an exact real functional
D_ijk+D_jik (or diagonal D_iik) annihilating every projected source-free image
column. If its value is nonzero, stop with that complete obstruction and
independently signed coefficient/Euler evidence: no partial primitive fit,
new loop, derivative-gauge or other-source/source-dependent repair runs here.
If all heavy-ghost coefficients pass, record only necessary projected
admissibility and freeze a subsequent complete-Q-image contract before a
normalization choice or dependent loops. This does not assert sufficiency.

Any necessary type/sign/frame/real-method failure stops with exact source,
start, complete diagnostic and explicit FAILED/INCOMPLETE classification.
Resource boundaries cannot truncate evidence or weaken the image obligation.
Shared immutable inputs, exact arithmetic, Python/SymPy and analyst are
disclosed under the existing solo-review policy and epistemic ladder.

## Validation and ceiling

Targeted scientific/process/governance checks, python -B tools/research_check.py
e5 delegate, all36 predecessor/protected/new/state hashes and audit metadata.
Three strict fresh own-byte algebra-primary/replay and dependent comparison
starts/results are required before local commit. Authenticate old actual
loops,125 shear images and source/quartet calculations without rerunning them.
Custody remains expected exit2/seven unresolved references, never PASS. Verify
raw Git-index/worktree bytes and preserve all failed/unfinished attempts.

Possible dispositions: exact projected source-free obstruction; necessary
projected admissibility only; underdefinition; necessary-gate failure; or
unfinished execution. A successful evidence audit may validate failure data;
it is not director acceptance. No physical/catalog activation, HB1/C5/C1_GS/
matching, quantum A5/fullE5/Ward/contact/IR/anomaly, authority promotion,
outreach/publication/push. Original Spin(10) x global U(1)PQ goal stays active
and incomplete, including scalar/PQ and fermion/Yukawa/phenomenology.
