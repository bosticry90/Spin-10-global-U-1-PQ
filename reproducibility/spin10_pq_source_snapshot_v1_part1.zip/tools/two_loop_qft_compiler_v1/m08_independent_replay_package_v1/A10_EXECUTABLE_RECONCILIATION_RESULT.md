# Executable covariant action: bounded result and source-interface stop

The inactive classical candidate from `cadfca2` now has a separately named,
executable physical-action AST. Its declared value semantics, local
coefficients, parameters and physical vacuum agree with the independent
factorized replay in the tested scope. Stages A–C pass. Stage D stops at an
undefined conversion on the constrained scalar cotangent interface. Stage E
is not reached. No replacement is adopted and historical Phase C stays stopped.

Disposition: `PASS_EXECUTABLE_A_B_C_WITH_D_INTERFACE_STOP`.
Validation is authentication of these bounded results and the stop, not a
full-source or physical-model PASS. The [contract](A10_EXECUTABLE_RECONCILIATION_CONTRACT_V1.md)
implements the owner's ordered acceptance gates and solo-review policy.

## Recovery and custody

Work began on clean `main` at `cadfca2dcf82c34f03b3e7ab0a68248c80c092be`.
No surviving Phase C calculation was identified. The previous inactive
candidate, complete A10 failure, mixed-source fiber and heavy canonical-map
evidence authenticate. Their expensive qualified representation/fiber
calculations are reused, not reconstructed. No completed mixed-kinetic result
is inferred from the earlier interrupted diagnostic, and it is not rerun.

All inherited preflight byte bindings, the Phase C failure bindings and all
31 `cadfca2` package bindings remain unchanged. README and OPEN_SEAMS are among
those historical bound bytes; this new result and
[current pointer](../../../docs/A10_EXECUTABLE_RECONCILIATION_CURRENT.md) record
the continuation without rewriting them. Frozen A10 keeps canonical hash
`36abb0301627acf272a2904da3968781368b1d1d10a7115f7408e1767e20aa2b`.

## A. Executable physical action and direct equivalence

`frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json`
contains 34 physical terms using the existing 14 node types: normalized
curvature, four scalar kinetic terms and all 29 original potential graphs.
There are no source or gauge-fixing terms. The action is inactive.

The parent [record](../../../calculations/canonical_so10_scalar_reconstruction/RECORD.md)
defines `L=L_gauge+L_kin+L_Yukawa-V`. The present scalar/gauge scope excludes
Yukawa, as did the approved candidate. Potential row metadata is lowered to
explicit minus signs and Parameter nodes. The five complex coefficients use
`z=z_Re+i*z_Im`, with both coefficient and tensor monomial conjugated in the
second term. These are aliases for existing parameters, not new interactions
or fitted coefficients. All 24 real and five complex potential directions
and their frozen contractions/normalizations survive unchanged.

[The executor](a10_executable_action.py) performs finite sparse Einstein sums,
ordinary derivative-jet operations and explicit Minkowski contractions.
`evaluate_complete_action` accepts one canonical scalar carrier, its ordinary
jets, and connection/connection jets. It constructs the physical tensor views
through the frozen A31 embeddings, so the kinetic and potential field values
come from the same 328 coordinates. Arbitrary first jets may be supplied at
`x=v`; setting a field's value at a point does not set its derivatives to zero.

The original qualified sparse potential-network kernels accelerate only
exactly hashed explicit frozen graphs. They are not opaque AST invariant
nodes. Changed graphs cannot hit the original kernel key. The replay uses
the independent physical invariant oracle instead of those graph kernels.
This is a bounded executor; it does not generate a complete vertex catalog.

Primary finite-index AST execution and replay matrix/polynomial expansion
agree on all 31,720 local covariant-derivative coefficients: four spacetime
copies of 7,602 representation coefficients plus 328 derivative identities.
Every one of the 1,312 derivative components is covered. Thus all four
representations and all 45 connections are bound directly, including their
implicit zeros. This compares the actual construction and `g10` dependence,
rather than inferring equivalence from symmetry alone.

They also agree on 680 complete Phi/H4 density coefficients and 180 expanded
non-Abelian gauge density coefficients for the closed normalized plane triple
`(01),(02),(12)` in all four spacetime directions. Both cubic and quartic
connection contributions are retained. The gauge point replay independently
uses physical 10-by-10 matrix commutators and trace, rather than stored f.

Two exact potential points compare all free parameter coefficients. A third
complete-action point executes every one of the 34 terms from canonical
coordinates. Together the points provide fresh nonzero controls for every
potential direction, including zEta. At that declared third point,
`L_zEta=sqrt(2)*(76*zEta_Im+132*zEta_Re)` in both implementations. It is a
symbolic parameter test, not a physical benchmark or chosen parameter fit.
The unchanged graph comparison supplies the general contraction equivalence;
the finite point tests do not alone prove arbitrary-polynomial equality.

## B. Local identities and historical negative control

The complete 54-coordinate Phi kinetic action, with nonzero H4 connection in
four Minkowski directions, has exactly zero local variation and ghost Euler
derivative. The new AST route and independent physical symmetric-tensor route
both reproduce its full 680-term density and the historical 400 variation
plus 400 ghost-Euler coefficients. Gauge connections are varied before
projection. The frozen two-field witness and its nonzero Euler derivative
remain unchanged; no EOM or integration-by-parts assumption removes them.

The fresh non-Abelian gauge regression varies the executable 180-term density
and obtains zero exactly at nonzero connection. Adversarial controls show
that changing a gauge-invariant kinetic prefactor or a complex parameter
orientation changes the action despite preserving its symmetry.

Full 45-parameter classical Ward acceptance is structural/factorized. The
AST has the exact D/F form and authenticated full representation/f constants;
all D coefficients are directly compared. The previously qualified complete
commutator, metric, embedding, curvature and 29 potential-slot identities
therefore apply. Those expensive identities are authenticated, not recomputed.
This is not a fresh dense expansion of every full-action quartic variation.

## C. Shifted vacuum, mass and mixing

Executable evaluation at the actual frozen VEV yields 75 exact internal vector
mass density coefficients and 424 scalar/vector derivative-mixing coefficients
at mu=0. Independent tensor replay reproduces both sets, reconstructs
`O_a=rho_a v` from its saved independent matrices, and agrees with the full
orbit and Gram. The Lorentz factors are explicit in the action and checked
across four directions in the derivative/density controls.

The mass matrix is `g10**2 O.T O`; mixing is
`g10*(partial eta).T O B`, or `-g10*eta.T O partial.B` plus its boundary current.
Replay checks `O P_m=O`, so the bounded diagnostic
`F=P_m partial.B-xi*g10 O.T eta`, `L_GF=-F.T F/(2xi)` cancels this mixing.
This does not qualify the complete heavy/light partial-gauge ghost/source
architecture. The rank 33, 12 unbroken directions and raw N5–N8 spectrum at
omega squared 60 are authenticated inherited results, not a new diagonalization.
No new stationary-potential Goldstone theorem or mass-eigenstate vertex
catalog is claimed.

## D. First undefined source prerequisite

The proposed full canonical master action must use the physical action's
Euler covectors in the same canonical coordinates as K_phi. The existing
V4/V5 scalar-gradient bundle supplies raw potential templates with ordered
complex tensor slots. Its lowering formula is
`gradient_real=E_X^dagger G_X gradient_tensor`. A35/A34 certify that formula
for a real ambient **Riesz vector** and certify `E^dagger G E=I`. Those facts
do not specify how an ordered complex Euler covector becomes that input.

For Sigma the AST contraction sums all ordered five-index tuples, while A31
has 252 sorted form components and their real/imaginary copies. The stored
bundle has no composed executable adapter joining those endpoints, including
the ordered-to-sorted measure, conjugate Wirtinger derivatives and Riesz
conversion. It cannot be reused as an already qualified canonical potential
source image. This is an interface underdefinition, not a refutation of the
abstract embedding/metric theorem.

The smallest control takes the first real Sigma coordinate `t`, all other
scalar coordinates zero, and retains only its original quadratic potential
direction. The constrained field is `Sigma=t E_0`; direct action evaluation
and independent ordered-form replay give

```text
L = -mSigma2*t**2
dL/dt = -2*mSigma2*t
raw ordered derivative w.r.t. SigmaBar_I = -mSigma2*Sigma_I/120
```

Combine both raw Wirtinger derivatives into real components, sample them on
sorted tuples, and directly apply the stored E/metric lowering without the
ordered measure. This deliberately literal substitution instead gives
`-mSigma2*t/60`, with discrepancy `119*mSigma2*t/60`. Summing all `5!=120`
signed permutations before canonical pullback restores `-2*mSigma2*t` exactly.
Both implementations derive the measure from the tensor slots and preserve
the same density, selected form, derivative and discrepancy.

This diagnostic does **not** prove that every historical use of the abstract
bundle chose the erroneous substitution. The missing conversion could have
been intended implicitly. Nor does it show that a complete BV construction
is impossible. It demonstrates why the raw template type cannot be silently
identified with the required Riesz type. The correctly derived one-coordinate
pullback is a control, not an adopted all-sector adapter or a parameter change.

The contract stops here before constructing or qualifying a complete master
action. The six decoded source coordinate triangles and three prospective
nonminimal partners remain preserved inputs. They do not cure this potential
cotangent interface. No full-source nilpotence, composite-R, partial gauge,
canonical gauge-fixing transport or joint-domain PASS is earned. Stage E is
not reached.

## Validation, limits and next decision

The saved primary/replay files, interface pair, performance record, read-only
validation receipt and byte bindings are in `frozen_a10_executable_reconciliation`.
Validation freshly regenerated the four new routes byte-identically under
write denial. All 50 tests passed: nine new adversarial regressions and the
41 existing candidate/failure/governance regressions. The authority, structure
and read-only audits passed; the custody audit retained its expected exit 2.
The audit recorded no changes among 127,142 workspace/active-data metadata
records and authenticated all 171 inherited preflight byte bindings, along
with the additional predecessor-package bindings. The receipt distinguishes successful evidence validation from the
Stage-D scientific stop. Historical custody remains exit 2 with seven
unresolved references; it is not reported as PASS.

Algorithms and code paths differ. Shared frozen representations, input points,
Python, SymPy, inherited sample helpers and analyst are disclosed. The full
45-generator proof inputs are reused and authenticated. No external
endorsement, library/runtime independence or blind review is claimed.
The [technical packet](A10_EXECUTABLE_TECHNICAL_REVIEW_PACKET_V1.md) and current
[solo policy](../../../docs/SOLO_REVIEW_POLICY_V1.md) retain mathematical review
requirements without recruiting or contacting anyone.

The next scientific decision is to scope and qualify the explicit
ordered-complex-covector to sorted-real-covector/Riesz to canonical-covector
adapter for every potential direction and all four sectors. Compare it
against direct differentiation of the canonical physical action, with the
minus-V sign, all free parameters and Hermitian completions. Only then derive
the complete canonical master action and its full source/nonminimal identities.
The present scalar/gauge implementation supplies the executable physical
input for that work. It grants no automatic continuation or adoption.

The [versioned cotangent scope note](A10_CANONICAL_COTANGENT_SCOPE_NOTE_V1.md)
limits reuse of the historical V4/V5 assembly without erasing its valid
embedding, variational-template or Riesz metadata results.

Formal authority stays 34/39; Phase C, HB1/C5 and quantum matching remain
blocked. C1_GS is uncalculated. The potential-only local Higgs benchmark keeps
its original scope. Frozen physics, sources, catalogs, ledger and historical
controls are unchanged. No remote push or personal outreach occurs.
