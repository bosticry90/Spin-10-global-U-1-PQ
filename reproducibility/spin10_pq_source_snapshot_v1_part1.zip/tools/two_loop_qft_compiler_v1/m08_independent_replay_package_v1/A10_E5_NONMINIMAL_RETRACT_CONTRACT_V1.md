# E5 Ward/basic nonminimal polynomial retract, V1

1. **Question.** Does the qualified nonminimal doublet contraction preserve
   the actual residual Ward/basic local cochain domains, including sources?
2. **Claim.** Derive a polynomial deformation retract of the full retained-source
   complex onto its transported minimal image. Prove the Q/h counting identity,
   Ward/contraction compatibility, locality and grading, including modulo
   ordinary divergences; keep intrinsic and induced quotients distinct.
3. **Ceiling.** A nonminimal-sector domain lemma, not full E5 or a classification
   of remaining minimal cocycles, quantum insertions, anomalies or matching.
4. **Types/inputs.** Clean 9e67f3b, state v113/34 of 39, 19 sealed predecessor
   chains. All 643 canonical pairs, 48 external H backgrounds, actual 45-generator
   algebra, nonsymmetric heavy coset, R_H, physical Euler programs, qualified
   N(g) doublet chart, E1 fermion, E2 U, E3 operators and E5 contraction remain.
   Use eta only for a nonminimal antighost in this record: heavy ub_i/light bar_h;
   beta=Q eta is the auxiliary chart. Physical scalar fluctuations are different
   variables and remain spectators. Their source partners are evaluation duals.
   Polynomial physical parameters, ordinary finite-support symmetric jets,
   actual component real structure and Lorentz conventions apply. No inverse
   physical coupling, mass, width or field. Xi/eta_H are real dimensionless.
   Evaluated OrbitPullback coefficients retain E1's documented mass dimension
   one. Derive their bookkeeping lift from heavy_orbit Euler derivatives;
   normalization must recover every frozen source shift, operator and control.
   Word-only dimensions cannot discard this inherited coefficient dimension.
5. **Comparator.** [Barnich, Brandt and Henneaux, sections 2.6-2.7](https://arxiv.org/html/hep-th/0002245)
   explain ordinary nonminimal pairs. Their argument does not automatically
   preserve this project's extra Ward/basic restrictions; verify those here.
6. **Primary.** Conjugate the beta-chart homotopy, count and projector through
   the complete N and U maps, using general graded polynomial substitution.
   Check all canonical/external operator columns and admitted parameter jets.
7. **Replay.** Derive pre-U homotopy and post-U source corrections from the
   physical nonminimal pairings and independent fermion variations; derive H
   carrier matrices from physical commutators. Compare completed maps and
   checks. Share inputs, exact word arithmetic, Python/SymPy and analyst openly.
8. **Falsifiers.** Omitting source-side homotopy, dropping width corrections,
   treating h as canonical because h Psi=0, counting old sources blindly,
   zeroing shifted sources without transport, or using source-linear-only U
   on multiple-source cochains. Preserve all exact witnesses/unfinished runs.
9. **Limits.** Include arbitrary nonnegative Nm degrees and jets by an explicit
   structural proof; finite controls alone cannot PASS. Q's physical Euler
   programs must be fixed by h and counting. Keep local H parameters and their
   jets. Zero widths/g are admitted as algebraic checks, not propagator claims.
10. **Stop.** First unexplained essential exact mismatch stops the dependent
    gate. An underdefined primitive/quantum admissibility condition stays open;
    do not silently weaken that requirement or infer A1-A5.
11. **Meaning.** A PASS establishes nonminimal reduction separately for full
    polynomial, background-Ward and joint-basic complexes with each declared
    primitive space. It does not identify intrinsic and induced minimal quotients
    or impose fixed strict Tq' on the quantum insertion target. H itself is not
    a canonical coordinate change. Its odd primitives may generate candidate
    canonical equivalences, whose quantum admissibility remains A5.
12. **Evidence.** Freeze derivation, two new read-only routes, all-generator/jet
    identities, real/graded checks, nontrivial multiple-source/basic controls,
    exact boundary treatment, negative controls, fresh byte replay and validation
    receipt. Authenticate predecessors; do not repeat expensive qualified work
   without need. For the large source-quadratic control, freshly reduce its
   beta-chart square and compare its full transported Q column to the exact
   conjugate. Reuse qualified canonical nilpotence for the transported square;
   disclose that structural method rather than claim a fresh full expansion.
   Preserve authority, frozen evidence and custody exit 2/seven
    references. Validate before local commit. No source removal/activation,
    catalogs, HB1/C5, C1_GS, matching, contact, publication or push.
