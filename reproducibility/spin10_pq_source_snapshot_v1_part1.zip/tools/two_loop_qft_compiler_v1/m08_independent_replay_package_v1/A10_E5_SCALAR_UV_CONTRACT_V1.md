# E5 g=0 scalar ultraviolet closure and symmetric heavy-width qualification

1. **Question.** Does the actual 29-term/34-real-parameter scalar family close
   under ordinary scalar ultraviolet subtraction at g=0, and does a defined
   H-invariant BRST-exact width space contain the preceding ghost pole?
2. **Claims.** Authenticate the accepted complete invariant basis and its
   literal executable translation. Derive full canonical second-variation and
   one-loop Tr(H_V^2) programs. Prove ordinary UV closure by global Spin(10)/PQ,
   power counting and the exact basis, with explicit mass/norm and mixed-complex
   coefficient checks. Classify every symmetric H-heavy width and transport its
   primitive through the actual nonminimal differential, retaining R_H.
3. **Ceiling.** Ordinary g=0 UV closure and a concrete source-independent
   IR-regulated formal subtraction construction. Not all g!=0 restoration,
   physical IR/vacuum existence, all source-dependent insertion/contact/A5
   equivalence, full E5, scalar beta tables at every coupling, or quantum
   matching. No director acceptance or authority promotion is inferred.
4. **Inputs.** Clean bd1cb32, v113/34 of 39, 22 sealed chains. The state's
   INVARIANT_BASIS_CLOSED and complete_explicit_invariant_basis=true, PARENT_ACTION
   hash, result/definition/count/rank source files, the 34-term executable action,
   typed cotangent embeddings and immutable representation data are inputs.
   Record raw hashes before calculating; never rewrite any predecessor.
5. **Mathematical domain.** Four canonical real scalar sectors of dimensions
   54,252,20,2; actual integer PQ charges 0,2,-2,-4; source-left BV conventions.
   Existing physical coefficients remain arbitrary symbols with nonnegative
   dimensions. No inverse g/mass/width. g=0 and the norm-only subfamily are
   FORMAL diagnostics, not changed benchmark parameters. Constant frame/metric
   factors may be inverted. PQ remains global, with no 46th gauge source.
6. **Primary.** Differentiate the saved indexed ordered Euler templates and
   pull back through constant canonical embeddings. Compile the norm-family
   radial potential from the literal AST before its Hessian trace. Contract the
   actual holomorphic Sigma bilinear in canonical coordinates for z4* zD.
   Use rational physical H/M coordinates and exact linear elimination for
   symmetric-width invariance constraints.
7. **Replay.** Direct two-parameter polynomial variation of the literal action,
   independent tensor-graph packing, O(n) block Hessian algebra for the coupled
   norm-family trace, physical five-form combinatorics for the mixed channel,
   and Cartan-weight/raising connectivity for the width-space upper bound.
   Reuse qualified character/rank/Jacobian results instead of expensive reruns.
8. **Specific checks.** All 29 second differentials and all 34 independent
   real coefficients; Hermitian completion and minus-potential action sign;
   180 Spin/PQ commutators; coupled norm-family scalar coefficients and a
   separate constant vacuum subtraction; real and imaginary mixed-channel
   controls. Classify the full 561-dimensional symmetric-width ansatz and all
   twelve H constraints; derive complete QPsi and Q^2Psi for its basis.
9. **Falsifiers.** Raw ambient loop trace (100 Phi rather than 54, doubled
   Sigma or unconverted complex Hessian), omitted zK or complex completion,
   wrong scalar determinant sign, claiming norm-only sampling proves full
   closure, imposing symmetric coset, using invariant width metrics as canonical
   source pairings, or assuming complete quantum insertion/IR realization.
10. **Proof scope/stop.** All-order ordinary scalar UV closure may use the
    standard local forest-subtraction theorem after explicitly checking its
    polynomial, covariance, dimension and IR-regulated premises. It proves
    membership, not every beta coefficient. Stop at an exact mismatch or missing
    essential input; preserve the first witness. Do not promote a finite
    regulator or local UV theorem to a full physical quantum construction.
11. **Normalization.** Include invariant kinetic renormalizations and a
    source-independent constant vacuum normalization separately from the 34
    field-dependent potential coefficients. Width poles may be separately
    named BRST-exact fermion counterterms with fixed loop coefficients; do not
    fit new physical interactions or edit E1. Ordinary counterterms and operator
    insertion/contact normalizations remain different domains.
12. **Evidence.** Bound input/type/implementation hashes at execution start,
    separate primary/replay outputs, exact coefficient comparison, structural
    proofs and negative controls, fresh byte replay, protected/state/metadata
    checks and custody exit 2/seven. Local commit after validation only. No
    source removal/activation, auxiliary elimination, catalog/HB1/C5/C1_GS,
    matching, outreach, publication, push or formal-authority change.

The full Spin(10) x U(1)PQ objective is unchanged. This work addresses the
scalar and normalization obligations preventing a full quantum construction.
