# Regulated source operators and the one-loop identity

Prospective derivation, not completed evidence. All signs below use the
qualified source-left bracket and an even transformation epsilon_left Q.
Right/left field derivatives and supertranspose are those of the existing
graded kernel program; odd breaking Hessians are defined with an external odd
probe before differentiation, then its left derivative is taken.

Let S be the qualified source-linear E2 action, H its integrated-field Hessian,
R_z=Qz and A its tangent field Jacobian. Let F be the source-independent UV
heat cutoff and Kref the verified full643 reference. Define

    DeltaK=F^-ST Kref F^-1-Kref,
    V=(1/2) z DeltaK z,
    S_Lambda=S+V, H_Lambda=H+DeltaK,
    B_Lambda=(S_Lambda,S_Lambda)/2=QV,
    Q_Lambda=Q+(V,.).

No auxiliary is eliminated. This quadratic term is a regulator definition,
not an extra physical interaction. In the original functional, source columns
are unchanged. The temporary regulated source columns have the additional
Euler covector V_z, in the specified source-left sign convention.

The full master identity and its second variation give the Hessian congruence
under the original Q, with physical source variations retained. Q background
is zero. Q_Lambda changes the source variation by V_z. The corresponding
regulator-breaking Hessian contains both a bilinear DeltaK/A term and the
nonlinear V_z R_z,jk term. That latter term is precisely the source derivative
of the loop functional multiplied by V_z; it cannot be discarded.

For Gamma1=(i/2) STr log H_Lambda, interpret all identities as finite formal
Born words, retaining Gamma_ref[background] separately. Direct differentiation
of the convergent word family and Gaussian insertion give two expressions:

    Q_Lambda Gamma1 = insertion_1(B_Lambda) - i div_heat R,
    Q Gamma1 = insertion_1(B_Lambda)
                   -(V,Gamma1) - i div_heat R.

An individual unregulated trace of the identity operator is not assigned a
value. Combine the reference/free trace pieces in a common profile first;
only the convergent Born differences and explicitly controlled heat Jacobian
are interpreted. At each fixed formal order, the derivative of
STr[(G_Lambda deltaH)^n]/n is a cyclic sum which reduces to the inverse-series
variation. Its induction must retain graded signs, external sources, parameter
jets and admitted boundaries. A finite-order check alone is not all-order proof.

For the actual field measure, the diagonal carriers in physical real frames
are gauge45 (four copies), scalar54/252/20/2, ghost45, heavy antighost33,
heavy auxiliary33, light antighost12 and light auxiliary12. The kernel at
coincident points of a self-adjoint real H-covariant heat operator is symmetric
in these physical frames. A skew Jacobian matrix contracts to zero with that
kernel. This provides a specified regulated Jacobian check, not an all-scheme
anomaly theorem or proof of a finite-mode integration-variable change.

The actual phi two-coordinate Fourier witness uses R_x=-g rho(C)x,
rho_ij=1/sqrt(2). With p+q+r=0 and positive scalar reference M^2, the quadratic
regulator symbol is Rcut(p^2)=(exp(2p^2/Lambda^2)-1)(p^2+M^2).
Its selected full tree breaking has coefficient

    g/sqrt(2) [Rcut(q^2)-Rcut(p^2)] C X Y.

Other regulator carriers have no two-phi monomial. This is expected finite
cutoff breaking, not a new failure of the physical action. It vanishes at
constant parameter and in the zero-coupling or removed-cutoff tree limits.
Finite-cutoff exact cancellation by a finite local polynomial is not presumed;
the loop limit and restoration problem remain separate.

Temporary IR/mode projections require extra projection breakings. The stated
unprojected UV word identity does not certify those terms or physical IR
removal. Source/probe differentiation of the insertion must include its own
field/source dependence and later contact normalization. No broad QAP,
restoration, quantum A5 or full E5 claim follows from these formulas alone.
