# E5 coupling ring: qualified controls, general target comparison still open

The polynomial coupling-ring control has completed through two independent
routes. It establishes an unrestricted full-complex representability obstruction
and a constructive coupling-weighted family. The raw obstruction fails the
conditional quantum target's background Ward requirement, so it is not evidence
of a missing quantum counterterm class. Full E5 remains unqualified.

The [contract](A10_E5_COUPLING_RING_CONTRACT_V1.md) and
[derivation](A10_E5_COUPLING_RING_DERIVATION_V1.md) freeze the exact scopes.
The clean baseline is 2d0cdaf, with 18 sealed predecessor chains and unchanged
source state v113. The canonical nonminimal chart retains all 643 pairs and
has an exact inverse restoring the original Stage D view; no heavy curvature
or nonsymmetric bracket is discarded. The physical action and parameters stay
literal and inactive. No new physical term is inserted.

## Completed mathematical results

Let g=g10, S_beta the qualified action in the beta=Q eta chart, and
F_beta=partial_g S_beta with those coordinates held fixed. Differentiating
the complete master-functional identity proves Q_beta F_beta is a boundary
divergence. No equations of motion are imposed. Primary differentiates the
sealed source polynomial; replay differentiates the indexed source AST and
executes it with its separately qualified representation/frame data. Their
complete normalized coefficient-array hashes agree:

| Calculation | Exact coefficient count |
| --- | ---: |
| Original source coupling tangent | 34,937 |
| Tangent in the beta chart | 33,741 |
| Parameter-dependent chart correction | 1,484 |
| Source part of Q_beta K in the weighted identity | 34,101 |
| Coupling cocycle master density | 5,316 |
| Corresponding master boundary current | 1,772 |

Replay derives the full source-current identity by independent left Euler
columns and the graded chain rule. It agrees with primary's derivative of the
qualified master-density certificate. The full physical closure uses the bound
Euler/Noether programs structurally; their expensive expansions are not repeated.
The literal physical AST verifies the B/g dilation weights in all 34 terms;
all 29 potential directions have zero g derivative.

The g-dependent nonminimal and E2 charts have explicit canonical connection
terms. Derivatives in different charts are not identified by field names:

    N(partial_g S_D) = F_beta + Q_beta K_N,
    partial_g S' = U(partial_g S_D) + Q' partial_g Psi

as local functionals with their qualified boundary convention. The first
source identity is freshly checked. The second follows from the qualified
field-only E2 source shift and its commuting generating fermions.

### Unrestricted polynomial obstruction

At g=0 and zero potential coefficients, a stationary algebraic projection
sets physical/nonminimal coordinates, their sources and all jets to zero,
retaining undifferentiated C and JC. All 1,286 source-polynomial images vanish,
as do the bound free physical Euler covectors. The source coupling tangent
retains 443 coefficients in -JC f CC/2. Its H contraction has 230 nonzero
coefficients. Its ghost-source Euler derivative is nonzero.

Every polynomial QK and ordinary divergence restricts to zero there, whereas
this polynomial survives. Thus F_beta has neither a source-free nor an
H-horizontal full-class representative in this unrestricted ring. For the
horizontal argument the projection is extended to constant even H parameters,
setting their derivative jets to zero too; it then commutes with contraction.
This is an all-polynomial argument, not a numerical search or finite rank test.
It relies on the declared exclusion of inverse physical couplings and explicit
spacetime coordinates. It is not a statement about only the selected nonzero
physical coupling or about a ring permitting 1/g.

The real physical replay uses Y=P_H e0, X=P_M e1 and Z=[Y,X]. All vectors pass
their actual subspace checks, with ||Z||^2=9/100. With C=theta1 Y+theta2 X and
JC=t Z, the class and its contraction are

    F_bar = -(9/100) t theta1 theta2,
    iota_(sigma Y) F_bar = -(9/100) t sigma theta2.

These are exact diagnostic expressions in ghost/source coordinates, not
particle measurements. The physical source frame uses the evaluation-dual map.

### A constructive family without a coupling pole

For K=-sum JB B+sum JC C, both routes derive

    g F_beta = -2 L_YM - Q_beta K
               + partial_mu(-F_a^(mu,nu) B_nu^a + JB_a^mu C^a).

The source boundary divergence has 360 coefficients and zero residual after
subtraction. The physical current follows from the qualified gauge first
variation. The source-left signs are explicitly verified on the full alphabet.
The representative -2 L_YM is source-free and joint basic as a functional;
the E2 map fixes it. This qualifies that named weighted family, without dividing
by g. It does not remove the unweighted F_beta.

The primitive K itself is not intrinsic basic: its local background variation
is -sum_H JB d omega and its contraction includes JC_H omega_H. Thus this is
a full-complex equivalence, not a proof of intrinsic/induced quotient equality
or quantum admissibility under A5.

### Why this does not refute the quantum target

The actual conditional W6 target requires a local first counterterm difference
to obey the background Ward identity. The raw tangent's selected source Euler
witness is

    Euler_JB13_0(Tb F_beta)|g=0 = -i C13 partial_0 omega1 / sqrt(2)

in the selected channel. The source-only local Ward variation has 920
coefficients. Its real physical Euler witness is +(9/100) sigmaDot theta2.
The probe sigma denotes an undifferentiated dimension-zero parameter; sigmaDot denotes
its independently typed dimension-one first jet. A constant-parameter check
would miss the Ward failure. Physical terms cannot cancel this selected source
coefficient. The raw tangent therefore is not a counterterm satisfying the
fixed background identity. This follows also by differentiating Tb(g)S=0 and
retaining partial_g Tb.

A combined parameter/source/background normalization package could behave
differently; none is derived or excluded here. Coupling-power constraints and
the admitted joint primitive space still need proof. Perturbative intuition
cannot be used to delete a problematic class, and raw background exclusion
cannot establish full target adequacy. No strictly invariant fixed Tq' quantum
identity is imposed; W5's whole product insertions remain required.

## Execution and validation

Three preliminary primary outputs are preserved, superseded and excluded from
the completed evidence: an initially aliased parameter/jet probe; the version
before zero-subtree normalization; and the version before replay-frame schema
recovery. Two failed replays are preserved: an unbound-index wrapper around
an identically zero derivative, and a lookup of a primary-only architecture
envelope. Their implementation bytes, prospective fingerprints, logs and
classification receipts remain available. The initial derivation copy was
recovered using only its recorded corrective paragraph and verified against
its original prospective hash. No numerical coefficient was fitted or changed.

Only the final completed routes count. Their inputs, contracts, implementations,
runtime and no-write metrics are prospectively fingerprinted. Sixteen new
adversarial regressions cover the ring, local Ward requirement, graded signs,
real input domain, canonical chart connection, parameter types, typed zero
variation and exclusion of preliminary/failed runs. The validation receipt
records exact commands, fresh byte reproduction, inherited tests and integrity
checks. Expensive predecessor qualifications are authenticated; the new replay
does perform its own indexed tangent and full source-current calculation.

Both methods share immutable data, word arithmetic, Python/SymPy and analyst.
No proof-kernel formalization or external endorsement is claimed. The literature
comparison with [local BRST cohomology](https://arxiv.org/html/hep-th/0002245)
and [consistent master-action deformations](https://arxiv.org/abs/hep-th/9304057)
supports the methods, not this implementation or physical unification.

Authority stays 34/39; custody stays exit 2/seven unresolved references.
The protected artifacts and physical parameters remain unchanged. There is
no activation, catalog replacement, HB1/C5, C1_GS, quantum matching, publication,
personal contact or push. A1-A5, full E5 and Spin(10) x U(1)PQ completion remain
unproved. The current result preserves the qualified physical action, D-E4
and regularity; it is not a new physical inconsistency.

## Next smallest scientific action

Qualify the nonminimal doublet contraction on the actual Ward/basic-restricted
polynomial language, including its source correction, dimension/ghost bounds,
local parameter jets and E2 transport. Test the counting/homotopy relationships
with Q, contraction, quantum H and background H explicitly before using that
reduction. Then address the remaining minimal coupling-ring and allowed
primitive comparison. This advances the domain bridge without adopting 1/g
or assuming a quantum prescription. Full counterterm/insertion adequacy and
actual discharge of A1-A5 remain separate obligations.
