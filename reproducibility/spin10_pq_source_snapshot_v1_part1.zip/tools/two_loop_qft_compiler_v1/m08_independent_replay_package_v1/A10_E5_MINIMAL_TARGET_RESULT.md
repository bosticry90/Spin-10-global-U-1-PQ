# E5 named minimal source class and interacting zero-coupling target

Disposition: PARTIAL_E5_MINIMAL_WARD_SOURCE_TORSION_AND_G0_TARGET_SCOPE_ONLY.
The completed primary and replay records agree. This qualifies the named
polynomial class and its specified local obstruction, refutes the proposed
whole-sector Gaussian hypothesis, and derives a conditional affine-source
identity. It does not qualify complete E5 or an actual quantum prescription.

Baseline is 3642d07, state v113/34 of 39, with 20 predecessor manifests
authenticated. All 643 canonical pairs and 48 external H backgrounds remain.
The qualified Stage D--E4 action, potential and nonminimal retract are unchanged.

## The polynomial result

The real unit parent generator is the actual heavy H-singlet C3 direction 12,
with nonzero parent entries 0,17,30,39,44 equal to sqrt(5)/5. Its scalar matrices
R_s are real skew and centralize all 12 residual generators. Define

    K = sum_s J_s^T R_s x_s,
    A_s,a = [rho_s,a,R_s],
    F_source = sum_s,a C^a J_s^T A_s,a x_s,
    F_physical = sum_s,mu eta_mu (D_mu x_s)^T A_s(B_mu) x_s.

There are 818 K coefficients and 13,568 F_source coefficients. The actual
qualified source columns agree with the physical-matrix replay exactly. The
literal rigid kinetic variation and independent covariant expression agree
on 54,272 first-derivative coefficients and 280,204 seagull coefficients per
Lorentz direction. The four metric weights represent 1,120,816 seagull
coefficients; their shared tensor is computed once per route, not four separate
experiments. Implicit zeros and the singlet sector are included. All 29
potential invariants are authenticated dependencies, not newly expanded.

The explicit matrix programs and functional proof give

    Theta_R^mu = sum_s (D^mu x_s)^T R_s x_s,
    g F = QK + partial_mu Theta_R^mu,
    QF = partial_mu m_R^mu,
    m_R^mu = sum_s (D^mu x_s)^T [rho_s(C),R_s] x_s.

The proof uses the qualified scalar Euler/covariant-derivative and master
identities, the fresh coefficient comparison, and injectivity of multiplication
by independent g on the polynomial COCHAIN module. It does not invert g or
assume injectivity on cohomology. 2,160 matrix H-covariance identities pass.
K and F satisfy the Ward/basic restrictions: R centralizes H, A_h=0, iota
annihilates them, and the covariant derivative retains local parameter jets.
The qualified N/U cochain maps transport these statements with sources and
jets retained. This is not a mean-field quantum transport assertion. A fresh
exhaustive full-model expansion of QF was not performed; closure and the
ordinary boundary current have the stated structural proof.

At the SEPARATE formal g=0/all-potential-parameters-zero specialization, keep
constant real Phi_1=tPhi, scalar source J_Phi,0=thetaJ and the real heavy ghost
vector obtained from the projected parent plane seed 1. All 1,286 source
polynomial Q columns project to zero. Physical Euler terms also vanish in this
free constant-field specialization. Every ordinary divergence projects to
zero because explicit spacetime coordinates are excluded. Nevertheless

    F -> sqrt(5)/10 tPhi thetaC thetaJ,
    Euler_thetaJ F -> -sqrt(5)/10 tPhi thetaC != 0.

The independent symmetric-tensor contraction gives the same coefficient.
No polynomial local primitive or source-free representative can remove this
named class in the declared ring: their specialized source Euler derivative
would be zero. Its g-weighted class IS exact with the basic K. Thus this is
nonzero g torsion in the stated polynomial cohomology, including the background
and joint-basic restrictions. No benchmark parameter was changed.

## A local obstruction, not quantum exclusion

For the same matter-source pattern, a power-counted local BV deformation at
g=0 would require [A_a,A_b]=sum_c f'_ab^c A_c at second order. Scalar symmetry
columns of grade (2,1,odd) can only have C x or C times a dimension-one constant
in this minimal Lorentz-scalar scope; source terms or derivatives cannot have
that grade. Ghost columns are bilinear C C. Thus second-order columns cannot
repair the first-order matrix-closure condition at this specialization.

For the real heavy a and b=[R_parent,a], the Phi block gives

    tr(R A_c)=0 for all 45 c,
    -tr(R[A_a,A_b]) = -tr(A_b^2) = 24/25 > 0.

No choice of the first-order ghost structure constants can cancel this trace.
This obstructs this specified LOCAL deformation pattern. It does not refute
the original master action, every combination of deformations, or admission
in a nonlocal Gamma with insertions. Those are different questions.

The comparison with [Local BRST cohomology in gauge theories, sections 11--13](https://arxiv.org/html/hep-th/0002245)
is a scope comparison: fixed interacting Yang--Mills hypotheses and a family
whose polynomial ring includes the free g=0 specialization cannot be identified
without proof. The named torsion result is not a counterexample to that paper's
semisimple counterterm theorem. Published literature does not certify this
implementation.

## The Gaussian hypothesis is refuted; source dependence remains tractable

V1 incorrectly proposed a completely Gaussian gauge/ghost/nonminimal sector
at g=0. The literal E2 action disproves it. E1's heavy cubic fermion is

    Psi_cubic = xi/2 <ub_phys,[ub_phys,u_phys]_M>,
    Q0 Psi_cubic = -xi <Lambda_phys,[ub_phys,u_phys]_M>.

It contains no explicit g. Both derivations match all 276 residual coefficients
after subtracting the actual quadratic/affine-source density. One canonical
coefficient is C12 Lambda13 ub44: sqrt(2) i xi/4. The replay reconstructs the
entire tensor from physical 10-by-10 commutators and dual-heavy embeddings.
Real heavy vectors from parent seeds 0 and 1 have projected bracket norm 1/25:

    density = -xi/25 tAux thetaBar thetaU,
    Euler_tAux = -xi/25 thetaBar thetaU != 0.

The admissible real domain, nonsymmetric heavy projection, primal/dual maps
and full residual exclusion are checked. This interaction cannot be dropped
or called a boundary term. It is retained; no g is inserted and xi is not
set to zero. The failed V1 source and selected observed trace remain in
preflight_v1, whose log is explicitly not a full start attestation.

The zero-field QUADRATIC gauge/auxiliary Hessian alone has a checked inverse
for both heavy xi and light eta_H at generic p^2 != 0, with all four Lorentz
components, both inverse directions and p -> -p transpose/reality. No width,
mass or coupling is inverted. Its momentum denominators are Green-function
objects outside the local polynomial ring. This is neither a Gaussian
evaluation of the interacting action, a massive benchmark inverse nor an IR
prescription. Scalar potentials and all nonlinear ghost vertices remain.

The actual g=0 field columns are affine:

    Q0 B_mu = partial_mu C,  Q0 ub = -Lambda,  Q0 bar = -b,
    all other field columns = 0.

All 643 are checked. 225 BV source drivers are present and 418 sources absent
from this limit, without deleting any coordinate. The ordinary source shift is

    j_C -> j_C - partial_mu J_B^mu,
    j_Lambda -> j_Lambda - J_ub,   j_b -> j_b - J_bar,

with boundary current sum_a J_B,a^mu C^a. The graded density identity passes;
even/odd left-derivative Legendre controls reject an ungraded sign rule.
For a SOURCE-INDEPENDENT formal regulator/measure and a normalization that
preserves this exact affine dependence, at rho=0,

    Z[j,J] = Z0[j+shift(J)],
    Gamma[phi,J] = Gamma0[phi] + sum_z J_z R0_z(phi),

modulo the ordinary current. This argument works with the surviving
interactions; it never uses a Gaussian integral. In such a prescription the
absent-source derivatives vanish and loop-dependent source columns vanish
at g=0. Polynomial local source counterterms would consequently be divisible
by g. In particular, a bare constant coefficient of the named F is excluded
by THAT normalization, whereas g F is cochain exact. This conditional
observation is not adopted as a universal W1--W7 restriction.

## Validation, limitations and next decision

The read-only receipt transaction requires 219 targeted regressions (18 new,
156 inherited scientific, 24 process, 21 governance), two byte-identical fresh
new routes, authentication of 20 predecessor manifests, unchanged protected
and state bytes, and unchanged workspace/active-data size/mtime records.
The matching receipt and seal record the actual completed checks; this report
does not substitute for them. Old expensive calculations are authenticated,
not rerun. The failed dict/set-union primary start, original code, fingerprint
and full log remain in superseded_start_v1 and primary_attempt_1.json, excluded.

The main routes use different source differentiation, matrix-commutator and
kinetic-coefficient derivations but share immutable physical inputs, word
arithmetic, Python 3.10.11, SymPy 1.14 and analyst. Some witness selection and
structural proof code is shared. No external endorsement is claimed under
the solo policy. Protected-byte auditing is bounded; workspace inventory is
metadata, not every environment byte. Strict historical custody remains exit
2 with seven unresolved references, never PASS.

Next smallest action: derive whether the conditional affine-source
normalization can be realized alongside the actual W1--W7/A1--A5
Ward/Slavnov/insertion target and its allowed finite contact/canonical
equivalences; then compare the remaining minimal classes and intrinsic versus
induced quotients. Do not assume this normalized target is nonempty, or infer
strict transported quantum Ward invariance of Gamma. General minimal
classification, insertion normalization, regulator/QAP/restoration, the full
massive/IR problem and complete E5 remain unresolved.

State stays v113/34 of 39; M08/HB1/C5 remain blocked and C1_GS uncalculated.
No source activation/removal, auxiliary elimination, catalog generation,
matching, personal outreach, publication or remote push occurred. The entire
Spin(10) x U(1)PQ investigation remains incomplete, including global scalar
boundedness, later physical matching/phenomenology, full fermion/Yukawa content
and global PQ quotient. This bounded result does not redefine that goal.
