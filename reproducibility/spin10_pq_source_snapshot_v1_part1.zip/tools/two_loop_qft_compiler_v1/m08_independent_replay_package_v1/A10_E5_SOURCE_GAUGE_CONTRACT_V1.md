# E5 source–gauge derivative prerequisite, prospective V1

Baseline7206e419a0983537007761cef406cfc09dfd34bd, sole authority
project_state.json v113/34 of39, inherited derivative-gauge manifest and38
predecessor chains. Previous goal turn is PROGRESS: actual derivative tensor
qualified but the complete inactive normalization fails. Whole Spin(10) x
global U(1)PQ investigation remains active/incomplete. This is a separately
authorized prerequisite, not a restart or a fit of that residual.

SG1 calculates the actual one-loop g^2 antighost-source–gauge linear derivative
UV pole: all45 source and45 gauge directions,2025 coefficients including zeros,
four Lorentz polarizations. Preserve both derivative-on-source and derivative-
on-gauge representatives/current; two-point momentum conservation leaves ONE
independent vector, unlike the two independent vectors of the prior three-
point tensor. Keep all coupling/reference-width possibilities at this word
degree until literal graph/edge/dimensional proofs exclude them. No source
evaluations to dynamical fields, EOM quotient, inverse physical couplings,
field elimination or M-adjoint Jacobi assumption.

SG2 classifies dimension3, ghost number-1, odd local polynomial generator
carriers that can produce J_a partial B (dimension4,gh0,even) in QK. Before
actual/candidate access, screen all inherited643 field and643 source Q
columns and the existing complete carrier census. Identify all relevant
derivative placements modulo a retained full IBP current, with2025 universal
signed image columns and independently differentiated unit controls. This
does not by itself classify all H-invariant generators or a full subtraction.
Check H-covariance of the input-derived coefficient, and distinguish the
background-connection completion from an unproved quantum Ward statement.

Freeze action/source/GF/frames/state/code bytes before computation. Inputs:
frozen BV master, E2 transport, physical reconciliation, E3 homogeneous/local
H operators and executable physical action; transitive protected manifests
remain unchanged. Actual calculations never read normalization coefficients,
derivative-gauge residuals or peer output. Unit momentum/sign controls qualify
before group contraction. Primary uses all signed Fourier-Hessian/Born bubble
words and literal source/GF vertices. Replay uses independently routed ordered
Gaussian/Wick contractions and physical10 commutators/Casimir, checking full
literal agreement. Shared exact arithmetic, Python/SymPy, inputs and analyst
are disclosed; these are not independent scientists. No agents/duplicates.

One source cubic with one derivative ghost cubic is the possible bubble.
The full nonlinear source, H and M inverse orientations and literal GF
derivatives on a/B/C must be retained. Each source-linear term has one
integrated leg and zero second derivative; prove this for all45. No source
quartic exists in the input, and one external-source cubic in a three-vertex
cycle cannot have only one external gauge leg with every vertex degree2:
remaining incidence is odd. One-vertex source tadpoles cannot contain a gauge
leg. Prove scalar/orbit/mass, auxiliary-gauge and Xi alternatives have zero
ghost closure or wrong word/coupling dimension, rather than borrowing an
exclusion from a different amplitude. Retain full BB/BL/LB/LL0 reference,
then derive that this bubble uses only the two odd inverses. Thus widths/xi
drop through edge screening; do not fix them to special values.

Unit source is even, J a_A C_B; external gauge is even. Check internal
derivative-a/C and external derivative-B placements, all4 polarizations,
all odd ordering signs, complete GF IBP identity and opposite orientations.
Primary Gaussian angular moments and independent sphere-IBP replay remain.
Use k_E^2>R_UV^2>0, first-order external momentum Taylor exactly, no whole
scaleless integral; derive linear log coefficient with bubble heat profile4.
Leading odd moments vanish on that UV domain. Heat first-Taylor insertions
give degree-2/Lambda^2 finite or power terms, not the logarithmic pole.
No arbitrary loop/group/width cutoff or finite/IR amplitude.

Compare completed actual methods first. Require real/dual/primal roundtrips,
all12 homogeneous H identities and complete2025 coefficient comparisons.
Only then open the old complete candidate, extract its full g^2 source–gauge
derivative density and retained current and compare all2025 slots. If it
misses, preserve the full difference and real source Euler/Fourier witness,
excluding a pure boundary. The input-derived actual coefficient plus the
universal signed image can identify a necessary generator coefficient only;
no fitted/constructed/adopted inactive extension, full nonlinear Q image,
canonical flow or regulated measure is claimed in this increment. First
mismatch stops before a dependent repair, old derivative residual comparison,
new physical/higher/quartet/source-loop calculation or acceptance.

Numeric negative controls: wrong loop/odd order/sign, missed internal
derivative/IBP current, wrong source chart/pairing, omitted H ghost edge,
wrong generator sign, wrong derivative placement and spurious source-free
carrier. Exclusion/authority tests reject whole-scaleless, full Ward/A5 or
adoption inference. Validate original four own-byte routes (controls,primary,
replay,comparison), scientific/process/governance/delegated e5, all38 chains,
protected/new/state byte and metadata invariance. Preserve every failed or
unfinished exact source/start/stdout attempt with classification. Custody
remains expectedexit2/seven unresolved refs, never PASS. Authenticate old
expensive loops/images without repeating; raw Git index/worktree equality
before local commit. Evidence validation does not imply scientific gatePASS.

Possible dispositions: selected actual source pole qualified; exact stopped
inactive-member obstruction; underdefinition; necessary gate failure;
incomplete execution. No authority/catalog/physical/HB1/C5/C1_GS/matching,
normalization adoption, full E5/quantumA5/Ward/contact/IR/anomaly, outreach,
push/publication. Global scalar/PQ, fermion/Yukawa/phenomenology and original
whole goal remain unfinished. Existing local conventions, ladder and solo
review policy apply without requiring external personnel.
