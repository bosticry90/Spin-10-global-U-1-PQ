# HBC structural-contract derivation: preregistration

Custody inputs: `c84e437`, `85f2a31`. This execution is HBC only. It does
not activate HB1, cochain selectors, differential columns, EOM or cohomology.

## Task header

| Field | Binding |
|---|---|
| Physics decision enabled | None; decide whether a proposed source-extended basic domain is compatible with the unchanged action. |
| Current blocker removed | Test the structural-definition gap; removal is conditional, not presumed. |
| Why existing tools are insufficient | Earlier domain labels do not define contraction on arbitrary source-extended operators. |
| Minimum new implementation surface | Exact necessary-condition preflight, separate component replay, deterministic blocked/qualified receipt and read-only validation. |
| Structure-preservation obligations | Derivation signs, dual evaluation, composite ancestry and unchanged input custody; full descent only if the preflight passes. |
| Stopping condition | First exact incompatibility with the frozen algebra or Sigma; no repair or subsequent qualification. |
| What will be deleted or deactivated if this does not work | No candidate is activated; retain counterexample and provenance. |

## Calculation record

| Field | Binding |
|---|---|
| Scientific question | Does the normalized minimal full-Weil Cartan contraction admit unchanged source-extended Sigma as an H-basic element? |
| Claim under test | Basicness is the intersection of Lie-invariance and horizontality kernels, as a subspace rather than a quotient. |
| Scope and authority ceiling | Structural necessary conditions only until all gates pass; no scientific-authority increment. |
| Frozen inputs and assumptions | Current 17 B images, C4, exact six source ASTs, C3 H basis, nonnegative-dimension polynomial coefficient algebra, weight contract and catalog authorities. |
| Primary method and tool | Exact frozen-AST graded contraction and residual-H bracket reconstruction in the certified SO(10) frame. |
| Independent replay decision and reason | Independently reconstruct a physical matrix bracket and extract an odd-shift coefficient; do not import primary structure constants or contraction coefficients. |
| Known-limit and physical-assumption checks | R is derived from u; normalized connection contraction, source covector evaluation, off-shell auxiliaries and physical dimensions remain distinct. |
| Adversarial checks and falsifiers | A permitted source contraction canceling the isolated L_c*c coefficient would falsify the preflight; enumerate its required grades rather than assume it zero. |
| Provenance and comparators | Frozen input hashes and source JSON pointers; Ferrari arXiv:1308.6802 is a convention comparator, not replacement project authority. |
| Failure interpretation | Incompatibility of the candidate lift/action-domain requirement, not a failure of the catalog or a refutation of Spin(10). |
| Result and reproducibility record | Deterministic primary/replay evidence, regenerated before comparison; telemetry is a separate observation. |
| Stopping rule | If the unchanged Sigma is not horizontal, do not complete/promote the table, run HB1 or change upstream transformations. |

## Candidate and preregistered decisive control

The full-Weil connection candidate has normalized contraction
`iota_alpha(c_L^beta)=delta_alpha^beta`. A nonzero normalization rescaling
cannot turn a nonzero horizontality residual into zero. With B of degree
`(+1,+1)` and global residual-H Lie action of degree `(0,0)`, its minimal
Cartan-compatible homogeneous contraction has degree `(-1,-1)`.
Coefficients are the existing local polynomial parameters/VEVs, with no inverse
mass/VEV or new negative-ghost coefficient. Higher-degree or nonpolynomial lifts
are not silently authorized by this ansatz.

Before attempting an exhaustive lift, test the unique `L_c` source term.
The isolated coefficient of `L_c[4]*c_L[4]` under `iota_0`, in the frozen C3
complexified H frame, is preregistered. Reconstruct its structure constant
`f[4,0,4]` from physical SO(10) generators with the frozen `1/sqrt(2)`
normalization. Test whether the grades admit a source contraction that can
cancel it. Other sources, u-composite terms, derivatives and backgrounds are
independent polynomial variables and cannot cancel this selected monomial.

Independently freeze the replay matrix/odd-shift result before reading the
primary output. A nonzero exact coefficient is a fail-fast witness against
the candidate's required inclusion of Sigma. It is not permission to change
Sigma, add sources, impose source equations, perform EOM or erase ghost terms.
