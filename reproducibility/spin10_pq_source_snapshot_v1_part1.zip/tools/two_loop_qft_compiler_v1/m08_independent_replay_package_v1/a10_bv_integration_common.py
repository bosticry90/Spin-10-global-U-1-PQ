"""Inactive integration types, immutable inputs and exact serialization."""
from functools import lru_cache
from hashlib import sha256
import sympy as s
from a10_bv_common import HERE, ROOT, algebra, g, DIM, IDS, H, M
from a10_executable_action import read, digest, mat

OUT=HERE/'frozen_a10_bv_integration'

@lru_cache(None)
def coefficient(text):return s.sympify(text,locals={'g10':g})

@lru_cache(None)
def clean(c):return s.simplify(c)

def decode(rows):
    result={}
    for row in rows:
        word=[]
        for name in row['word']:
            base,sep,jets=name.partition('__')
            word.append((base,tuple(map(int,jets)) if sep else ()))
        result[tuple(word)]=coefficient(row['coefficient'])
    return result

def rows(P):
    return [{'word':[n+('__'+''.join(map(str,j)) if j else '') for n,j in word],
             'coefficient':str(clean(c))} for word,c in sorted(P.items()) if clean(c)]

def canonical(P):return {word:clean(c) for word,c in P.items() if clean(c)}

def geometry(route='primary'):
    """Materialize qualified matrices with repeated coefficient simplification cached.

    This consumes the authenticated representation and source-frame artifacts;
    it does not repeat their expensive representation qualifications.
    """
    evidence=read(HERE/f'frozen_a10_physical_reconciliation/full_{route}.json')
    source=read(HERE/f'frozen_a10_bv_master/{route}.json')
    Q=mat(evidence['C3_plane_to_parent'])
    f={tuple(row[:3]):coefficient(row[3]) for row in source['geometry']['f']}
    rho={}
    for sec,n in DIM.items():
        planes=[{(i,j):coefficient(v) for i,j,v in row['entries']} for row in evidence['representation_matrices'][sec]]
        out=[]
        for a in IDS:
            values={}
            for k in IDS:
                if Q[k,a]:
                    for address,v in planes[k].items():values[address]=values.get(address,0)+Q[k,a]*v
            values={key:clean(v) for key,v in values.items() if clean(v)}
            R=s.SparseMatrix(n,n,values);out.append(R)
            serialized={'shape':[n,n],'entries':[[int(i),int(j),str(v)] for (i,j),v in sorted(values.items())]}
            assert digest(serialized)==source['geometry']['rho_digests'][sec][a],('REPRESENTATION_REUSE_MISMATCH',sec,a)
        rho[sec]=out
    return f,rho,Q

def derivative_action(P,w,images):
    """Independent jet-gradient chain rule, images placed before LEFT partials.

    Unlike the primary prefix Leibniz action, collect each independent partial
    first, then apply its variation. Multiplication uses shared exact words.
    """
    gradients={}
    for word,c in P.items():
        prefix=0
        for pos,v in enumerate(word):
            if images.get(v[0]):
                rest=word[:pos]+word[pos+1:];bucket=gradients.setdefault(v,{})
                bucket[rest]=bucket.get(rest,0)+(-1)**(w.p[v[0]]*prefix)*c
            prefix+=w.p[v[0]]
    return w.add(*(w.mul(w.dword(images[name],jets),w.add(partial))
                  for (name,jets),partial in gradients.items()))

def source_data(route='primary'):
    data=read(HERE/f'frozen_a10_bv_master/{route}.json')
    if route=='primary':assert len(data['architecture']['pairs'])==643
    return data,{n:decode(v) for n,v in data['source_only_columns'].items()}

def contract():
    manifests=('frozen_source_component_decoder','frozen_phase_c_scalar_action',
        'frozen_a10_physical_reconciliation','frozen_a10_executable_reconciliation',
        'frozen_a10_cotangent_adapter','frozen_a10_bv_master','frozen_a10_gauge_euler_adapter')
    data,_=source_data()
    checks=read(HERE/'frozen_a10_gauge_euler_adapter/checks.json')
    return {'schema':'A10_INACTIVE_STAGE_D_INTEGRATION_TYPES_V1',
        'dependency_manifest_sha256':{n:sha256((HERE/n/'bindings.json').read_bytes()).hexdigest() for n in manifests},
        'architecture':data['architecture'],'gauge_cotangent_source_maps':checks['source_maps'],
        'gauge_adapter_input_scope':'even physical first-jet grammar only; not graded source densities',
        'scalar_adapter_operation':'Adapter.pullback; ordered complex covector to canonical real covector',
        'physical_coordinate':'B_parent lower Lorentz; x=v+eta; fixed H-only Abar',
        'physical_source_sign':'QJ=+Euler_physical+source_only_column',
        'candidate_inactive':True,'Stage_E_authorized':False,'authority':'34/39_UNCHANGED'}

def field_nilpotence(columns,w,stage=lambda n,f:f()):
    results=[]
    for z,J in w.pairs:
        residual=canonical(w.act(columns[z],columns,parity=1))
        results.append({'coordinate':z,'residual':rows(residual)})
        if residual:return results,{'coordinate':z,'residual':rows(residual)}
    return results,None

def source_master(columns,w):
    """Literal Euler antibracket density and its explicit source-degree current."""
    coefficients={}
    for z,J in w.pairs:
        for word,c in w.mul(columns[J],columns[z]).items():
            coefficients[word]=coefficients.get(word,0)+2*c
    density=canonical(w.add(coefficients))
    current=[w.add(*(w.scale(w.mul(w.var(f'JB{a}_{mu}'),columns[f'C{a}']),2)
                      for a in IDS)) for mu in range(4)]
    divergence=w.add(*(w.D(P,mu) for mu,P in enumerate(current)))
    residual=canonical(w.add(density,w.scale(divergence,-1)))
    return {'source_degree':1,'literal_master_density':rows(density),
        'boundary_current':[rows(P) for P in current],'density_minus_divergence':rows(residual),
        'boundary_formula':'2 sum_a JB_a^mu QC^a','EOM_used':False}

def physical_columns():
    """Explicit contracted Euler program; no new variational engine.

    Slots bind the qualified executable ASTs and adapter operation, rather
    than treating E as an independent field or inventing its transformation.
    Large potential tensors remain contracted, exactly as their qualification.
    """
    from a10_gauge_euler_adapter import canonical_euler
    from a10_cotangent_adapter import Adapter
    act=read(HERE/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json')
    scalar=read(HERE/'frozen_a10_cotangent_adapter/primary.json')
    gauge=read(HERE/'frozen_a10_gauge_euler_adapter/primary.json')
    primary,_=source_data();arch=primary['architecture'];Q=mat(arch['C3_to_plane_field'])
    gauge_AST=[canonical_euler(t) for t in act['local_terms'][:5]]
    assert gauge_AST[0]==gauge['Euler_AST']
    definitions={sec:Adapter(sec).definition() for sec in DIM}
    assert definitions==scalar['definitions']
    slots={}
    for a in IDS:
        for mu in range(4):
            slots[f'JB{a}_{mu}']={'operation':'sum Q[k,a] * canonical_gauge_Euler_plane[k,mu]',
                'parent_coordinate':[a,mu],
                'frame_coefficients':[[k,str(Q[k,a])] for k in IDS if Q[k,a]],
                'gauge_AST_terms':list(range(5)),
                'total_connection_substitution':'B_plane=Q B_parent before variation',
                'pairing':'direct evaluation on lower B_parent; no extra eta or Gram'}
    for sec,n in DIM.items():
        for i in range(n):
            slots[f'Jx_{sec}_{i}']={'operation':'canonical kinetic Euler + sum Adapter(sector).pullback(raw_ordered_potential_Euler)[i]',
                'sector':sec,'component':i,'kinetic_AST':sec,'potential_AST_terms':list(range(29)),
                'ordered_aliases':list(__import__('a10_cotangent_adapter').ALIASES[sec]),
                'canonical_scalar_coordinate':'x=v+eta; fixed v',
                'physical_sign':1,'metric_or_factorial_shortcut':False}
    assert len(slots)==508
    return {'action_sha256':digest(act),'canonical_source_slots':slots,
        'gauge_AST_terms':gauge_AST,'scalar_kinetic_ASTs':{row['sector']:row['canonical_Euler_AST'] for row in scalar['kinetic_covectors']},
        'potential_ordered_ASTs':scalar['potential_covectors'],'scalar_adapter_definitions':definitions,
        'implementation':'a10_gauge_euler_adapter.canonical_euler and a10_cotangent_adapter.Adapter.pullback',
        'coverage':'180 gauge and 328 scalar canonical source contributions; contracted exact Euler program, not a new expanded vertex catalog',
        'nonphysical_source_Euler_contribution':0}
