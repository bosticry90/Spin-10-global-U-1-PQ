# Q6.1 target specification and conditional theorem map

This analysis uses the actual clean e66d1d6 baseline and its authenticated
inactive D/E1-E5/quotient artifacts. It is not an adopted quantum prescription
or scientific-authority record. The sole authority remains project_state.json.

## A precise conditional quantum target

For the approved gauge/scalar scope, the natural proposal is a perturbative
retained-source 1PI functional Gamma[mean fields, J, Abar_H]. Legendre sources
used to define mean fields are distinct from the 643 external canonical BV
evaluation sources J. The 48 background components remain external, Q Abar=0,
without invented canonical partners or a background BRST doublet. Keep the
nonminimal fields and their sources; do not eliminate auxiliaries or project
antifields to zero. The tree term is the literal qualified transported S'.

Under a separately justified renormalization/measure construction, the proposed
Zinn-Justin identity is (Gamma,Gamma)/2=0, together with the appropriate local
background Ward identity. This is an identity to restore/prove order by order,
not a consequence of having tested (S',S')=0. A regularized quantum BV master
equation involving a measure operator is a different statement. Neither was
calculated here. A concrete scheme need not be unique; a proof can work for
a declared class of schemes if its locality and symmetry assumptions hold.

Write Gamma=S'+hbar Gamma1+hbar^2 Gamma2+... . The exact formal expansion gives

    order 1: Q' Gamma1,
    order 2: Q' Gamma2 + (Gamma1,Gamma1)/2.

Thus not every coefficient Gamma_n is itself Q'-closed. Comparing two restored
solutions that first differ at order n gives the homogeneous condition Q' Delta_n=0.
Locality of counterterms and allowed breakings is an additional quantum action
principle input. A possible anomaly is a different ghost-one obstruction; no
anomaly-freedom or loop coefficient is inferred from these formal identities.
Both computations reproduce this expansion through order three.

Proposed local counterterm densities have project grades (4,0,even), no
explicit spacetime coordinates and Lorentz-contracted ordinary finite jets.
Use polynomials in the canonical coordinates and background jets, with the
unchanged physical parameter dimensions; no inverse-dimensional coefficients,
inverse physical couplings or EFT extension. The dimensionless normalization
units in the earlier canonical family are an explicitly separate Laurent ring.
The map d_standard=d_project-gh translates every field/source/jet grade but
does not prove that a published homotopy preserves this entire coefficient ring.

## The first unsupported gate

No authenticated predecessor specifies and derives the complete renormalized
Ward/insertion system of this proposed Gamma. E3 proves classical Tq', Tb and
Q' identities, and explicitly withholds quantum master, anomaly and gauge-
independence claims. E5 and the quotient analysis also withhold strict quantum
Tq' admissibility. Those records are positive evidence of the scope limit;
this investigation does not infer an absence from a filename search alone.

The remaining target distinctions are consequential:

| Item | What is established | What the quantum target still needs |
| --- | --- | --- |
| Slavnov identity | Canonical classical master functional | Measure/renormalization assumptions, local breaking and restoration argument |
| Background H | Classical local Ward identity, 12 directions | Derive the identity for Gamma and its composite insertions/possible breakings |
| Quantum H | Geometric breaking and transported classical symmetry | Decide fixed Tq', transported/renormalized realization or a derived breaking identity; prove the choice |
| Canonical sources | Exact evaluation pairing and qualified family | Permitted insertion/source renormalization and auxiliary normalization conditions |
| External backgrounds | Q-inert 48-coordinate jet space | Retain, exclude or additionally quotient background-only terms with a justified physical target |
| Observables | No new observable-renormalization proof | Record their transport and selected generating-functional/observable scope |

The default *proposal* retains background-only terms: an effective action used
to study background gauge responses cannot silently throw them away. Excluding
them, or normalizing a generating functional modulo them, is a different target.
None is adopted by this result. Strict classical Tq' is neither automatically
required nor automatically inappropriate for quantum counterterms. The next
proof must derive its role, rather than selecting it to make basic coverage work.
Auxiliary/antighost equations of a standard linear gauge cannot be imported
unchanged into this nonlinear nonsymmetric partial-gauge construction.

Q6.1 therefore remains unqualified. Q6.2-Q6.6 have not been executed as scientific
acceptance gates. The map below is analysis of dependencies, not their proof.

## Published assumptions mapped to this model

[Barnich, Brandt and Henneaux](https://arxiv.org/html/hep-th/0002245), sections
2.6, 5.1, 11.1 and 12.2, distinguish Slavnov stability from anomaly restoration,
require normality/regularity and a specified local-form space, and give
semisimple ghost-zero invariant representatives. These conclusions do not by
themselves classify this additional background/basic restriction.

| Hypothesis or comparison | Repository support | Remaining bridge |
| --- | --- | --- |
| Four-dimensional Yang-Mills type action | Qualified covariant gauge/scalar action and Euler adapters | Exact convention dictionary; theorem model excludes extra quantum sectors here |
| Full semisimple algebra and linear matter reps | 45 Spin(10) generators and 328 coordinates qualified | Full G theorem cannot be replaced by one for residual H, which contains abelian structure |
| Regularity, normality and complete Noether resolution | Off-shell Noether and master identities qualified | Independent/dependent jet equations at all orders, regular local coordinates, completeness/acyclicity of Koszul-Tate complex |
| Contractible nonminimal pairs | Canonical heavy auxiliary transport qualified | Explicit homotopy on this admitted ring and domain, including source/jet rules |
| Polynomial/Poincare local forms | Declared finite ordinary jets and grading | Homotopies and primitives must respect power bounds, parameters and real structure |
| External background jets | Deliberately inert under Q | Additional spectator cohomology, background Ward constraints and normalization scope |
| Gauge-fixing transport | E2 canonical functional map qualified | Valid full-complex transport does not automatically identify a restricted quantum or basic complex |
| Full/basic inclusion | Induced quotient injection by definition | Surjectivity and any intrinsic/induced identification need distinct proofs |

[Henneaux](https://arxiv.org/html/hep-th/9510116) exhibits failures when one
changes to gauge-fixed antifield reconstruction assumptions. The retained-
source canonical map used here does not perform that projection. This guards
against importing the wrong complex; it does not refute the qualified map.
[Barnich, Henneaux, Hurth and Skenderis](https://arxiv.org/html/hep-th/9910201)
require the appropriate nilpotence-preserving deformation condition for their
gauge-fixed comparison. The tested classical nilpotence is a dependency, not
automatic satisfaction of every quantum deformation condition.

## Exact sensitivity controls and their interpretation

The new background control is L_bg=-G_H,ab Fbar^a_mn Fbar^b,mn/4. Both routes
derive all 72 curvature columns and 48 background Euler covectors using the
actual H frame and coupling. It is Q-closed, Tq'-invariant, horizontal and
locally Tb-invariant. It is already basic; it is not a missing-basic-class
counterexample. It demonstrates why adding external inert coordinates changes
the possible classification compared with a theorem language lacking them.

Its real Abar^0_1=b(t) specialization gives L_bg=dot b^2 and Euler_b=-2 ddot b.
Nonexactness in the declared polynomial ring follows by pulling back U, then
setting all canonical jets, g and potential coefficients to zero. All 1,286
source-polynomial images vanish; the qualified free physical Euler programs
also vanish, independently of external backgrounds. Every polynomial QK
therefore restricts to zero and any divergence remains a divergence, while
the displayed pure-background Euler derivative survives. This does not apply
to a ring allowing inverse physical couplings; no such enlarged ring is adopted.
In the post-U chart this is the transported stationary specialization, not
the assertion that zero shifted sources are stationary for arbitrary Abar.

A second control L_div=G_H,ab (partial.Abar^a)(partial.Abar^b)/2 is Q-closed
and Tq'-invariant but fails Tb. The real temporal g=0 channel has
Euler_omega0(Tb L_div)=2 partial_0^3 Abar^0_0, not a boundary-only residual.
Dropping the background Ward requirement admits this otherwise excluded
cocycle. Changing background scope can remove the first class by definition.
These are exact target-sensitivity demonstrations, not newly added actions.

The old F' is zero in the quotient when its qualified primitive family is
admitted. With no primitives permitted it is nonzero modulo divergences,
as its gauge-source Euler control shows. This comparison does not assert that
all restricted primitive spaces have the same effect, or identify intrinsic
basic exactness. Inverse-source pairing and fixed-contraction failures remain
mandatory authenticated controls. No arbitrary source deformation is removed.

Next smallest scientific increment: derive a retained-source 1PI Ward/Slavnov
and insertion contract from the chosen functional formulation, with explicit
background-only terms, source/observable scope and canonical operator transport.
Supply a restoration/QAP assumption argument and exact breaking identities.
Only then attempt the regularity/Koszul-Tate and theorem-domain bridge. No
catalog enumeration, activation, HB1/C5 or quantum matching follows here.
