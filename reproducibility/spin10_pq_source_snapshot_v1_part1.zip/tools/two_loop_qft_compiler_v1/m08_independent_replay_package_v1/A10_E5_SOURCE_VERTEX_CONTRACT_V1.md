# Actual mixed source-vertex ultraviolet calculation contract

1. Question: what are the complete leading g*xi gauge-source/ghost and
   g^2*xi scalar-source/ghost/scalar one-loop poles of the qualified E2 action?
   Do their two projections agree with one admissible canonical normalization?
2. Baseline clean ea76c8d, statev113/34of39,26 sealed chains. Bind all34
   physical/nine source terms, E2 correction,643 pairs,48 backgrounds and
   the qualified Hessian/regulator/source-operator identities. No old edits.
3. Target is the local UV coefficient, not C1_GS, finite heavy matching,
   physical parameters or an observable. Keep all ghosts/auxiliaries. Use
   real physical gauge frames and canonical evaluation-dual sources; source
   J_phi denotes the328 real scalar sources. Check actual phi20 directly
   and extend other sectors only through explicitly qualified representations.
4. Inventory literal vertices before selecting graphs. The xi Lambda ub u
   vertex has no g. The mixed gauge-auxiliary Green function is nonzero;
   auxiliary self-propagation is zero. Count source valence/1PI loops and
   physical coupling powers; include the actual nonsymmetric coset. Do not
   substitute textbook ghost rules, auxiliary elimination or symmetric coset.
5. Primary graded Hessian Born traces retain all loop orientations, external
   odd-source ordering, Lorentz weights and source/ghost signs. Replay direct
   Gaussian contractions and momentum routing independently derive the same
   coefficients. Use full reference blocks, not an invented sign correction.
6. Compute the gauge-source bubble at nonzero external momentum; compute
   the scalar-source triangle UV coefficient with a positive temporary scalar
   reference mass. Zero external Taylor momenta are allowed for the latter
   only after proving this integral is IR finite and not scaleless. No physical
   vacuum or scalar potential parameter is set to a new value.
7. Compare heat-cutoff radial/Schwinger and dimensionally regulated integrals.
   Record local residues, finite scheme difference and explicit Wick factors.
   Keep any finite nonlocal amplitude separate from its UV counterterm.
8. Derive the full internal heavy tensor from the literal276-coefficient
   interaction and physical commutators. Derive its ghost ENDOMORPHISM from
   primal/dual maps; the auxiliary kappa bilinear is not that endomorphism.
   Check the actual phi matrix products and an independent Casimir/representation
   replay. Authenticate other-sector structural dependencies rather than claim
   freshly expanded coefficients. Include all12 H intertwining identities.
9. If both poles have a common canonical primitive, derive its complete
   source/gauge-fixing image with current, not just the two selected terms.
   Compare Hamiltonian Euler and field/source coordinate-change routes.
   Keep this counterterm a prospective inactive normalization. Do not fit it
   to an observed physical value or assume all other poles equal this image.
10. Check evaluation pairing, inverses, real structure, jet transport and
    measure consequence of the selected linear ghost/source change. A constant
    carrier matrix need not have a background-independent regulated spacetime
    Jacobian. Retain that trace and its loop order; do not discard background
    responses. Full composite/contact normalization and quantumA5 remain open.
11. Stop on the first unexplained discrepancy. Possible outcomes include
    matched bounded poles, partial qualification, exact failure or underdefinition.
    No complete restoration, anomaly/IR theorem, A1–A5/E5/HB1/C5/C1_GS claim,
    source activation/removal, catalog, authority change, outreach or push.
12. Fingerprints precede computation. Independent routes and adversarial
    signs/metrics/vertices, immutable output, fresh own-byte replay,26 parents,
    protected/state/new SHA and metadata, custody2/seven. Validate before
    local commit. Shared data, arithmetic, Python/SymPy and analyst disclosed.

The full Spin(10)xU(1)PQ investigation remains active and incomplete.
