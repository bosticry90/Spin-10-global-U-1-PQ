# Exact terms, canonical coordinates and the two different quotients

This is a scoped mathematical analysis, not a new scientific authority ledger
or adoption of a quantum renormalization prescription. The sole authority is
unchanged `project_state.json`. The user authorized testing equivalences, not
deleting the E5 witness or choosing a smaller counterterm target automatically.

Let W denote the local functionals satisfying the two declared classical Ward
conditions, modulo ordinary divergences, and Z_W its Q'-closed, dimension-four,
ghost-zero component. Let B=Z_W intersect ker iota'. Permitted generators must
be local, real, odd, dimension three and ghost minus one; their flows must
retain grading, admitted jets, evaluation-dual sources and external backgrounds.
For Ward-invariant generators k, Hamiltonian conjugation preserves the Ward
conditions. It transports Q' and iota' and need not leave either fixed.
Generators which are not Ward invariant require separately proved transport of
the Ward identities. No blanket admissibility claim for all such generators
is made here. Neither physical parameter changes nor gauge-variant arbitrary
deformations are automatically quotiented out.

Three distinct operations must be kept visible:

1. An ordinary divergence leaves the declared functional unchanged.
2. A Q'-exact term is the tangent to a canonical redefinition, with the actual
   bracket sign and a separately tracked action, sources, observables and operators.
3. A nontrivial physical coupling deformation is a separate direction. Its
   possible renormalization is not a coordinate equivalence by assertion.

For a proposed admissible generator space K_W, the comparison target is

    H_W = Z_W / (Z_W intersect (Q' K_W + d currents)).

Two basic quotients are different:

    H_basic_intrinsic = B / (Q' K_basic + d currents),
    H_basic_induced   = B / (B intersect (Q' K_W + d currents)).

The inclusion of the induced quotient into H_W is injective by its precise
intersection definition. That fact does not prove surjectivity or identify
the induced quotient with the intrinsic basic cohomology. Full adequacy needs
every admitted class to have a basic representative and needs any claimed
intrinsic identification to control full-exact basic elements whose primitives
are nonbasic. A full-complex exactness statement alone supplies neither result.

The tested family is k=a K_H+b K_M, with the real dimensionless normalization
units exponentiated. Its first-order exact tangents have zero representatives in H_W
and in the induced comparison, while their canonical maps and operator transport
remain recorded. The primitive is not silently promoted into K_basic. This is
a general two-parameter subclass statement, not coverage of all counterterms.
At finite units the differential also changes. No claim is made that the
entire finite action difference is a cocycle or exact under the original fixed
Q'; the finite master equation supplies the corresponding nonlinear completion.

The finite map is V'=U V U^-1. V C_a=z_H C_a in H and z_M C_a in M;
V JC_a uses the inverse factor, and all other pre-U coordinates are fixed.
V'=U_(Psi-V Psi) V gives an independent generating-fermion description.
The actual family commutes with both classical Ward operators. Q' and iota'
are conjugated; a fixed contraction is incompatible with the H rescaling.
Thus fixed Ward operators and a fixed complete Cartan structure are distinct
restrictions. The computation derives this result without choosing a policy
to fit the old residual or changing g10, xi, eta_H or alpha=xi.

With X_k=(k,.) and Q'=(S',.), the odd bracket gives X_k S'=-Q'k as a
functional identity. The inverse flow supplies +Q'k. The density comparison
retains the current U(sum_a JB_a^mu C_a), not a false pointwise equality.
The master functional and nilpotence remain valid by canonical conjugation;
ordinary derivatives and all stated boundary currents are transported too.
This is a retained-source classical result. Quantum measure/Jacobian effects,
correlation-function normalization and loop-generated coefficients are unproved.

## First unestablished Q5 bridge

The literature offers a route, not an automatic qualification.
[Barnich–Brandt–Henneaux, sections 2.6 and 12.2](https://arxiv.org/html/hep-th/0002245)
relate exact counterterms to redefinitions and give semisimple Yang–Mills
representative results under their model/cohomology assumptions. Spin(10)'s
semisimplicity is already qualified. Applying that theorem still needs an
explicit bridge for the literal covariant action, local coefficient ring,
Koszul–Tate regularity/complete Noether identities, nonminimal canonical charts,
external background jets and dimension bounds. The unscaled project grades
map to conventional power counting by d_standard=d_project-gh, so the degree
shift itself is explained; preservation of the whole allowed ring still needs proof.

Strict Tq' invariance is established for the classical retained-source action.
No predecessor establishes that it is the independently required condition
on every renormalized effective-action counterterm. Background-only vacuum
terms and source/observable renormalizations also need an explicit target rule.
They cannot be silently omitted. Nor may an unrestricted theorem be applied
to a restricted Ward/basic complex without verifying its comparison maps.

[Henneaux's gauge-fixed warning](https://arxiv.org/html/hep-th/9510116) and
[the deformation analysis](https://arxiv.org/html/hep-th/9910201) distinguish
functional spaces and gauge-fixed cohomological obligations. Full canonical
equivalence is not a theorem about arbitrary restrictions or an antifield-zero
projection. These primary sources do not certify this implementation.

Q5 therefore stops at GENERAL_COVERAGE_AND_QUANTUM_WARD_ADMISSIBILITY_UNESTABLISHED.
No missing nontrivial class or universal adequacy is inferred. The next smallest
task is the model-to-theorem and Ward-admissibility bridge, explicitly deciding
the external-background/source target and proving both comparison directions.
The old witness and this finite family must remain mandatory controls.
