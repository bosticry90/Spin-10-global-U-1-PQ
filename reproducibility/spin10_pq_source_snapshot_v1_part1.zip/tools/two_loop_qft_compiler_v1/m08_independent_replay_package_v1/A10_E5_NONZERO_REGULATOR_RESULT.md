# E5 nonzero-g fractional-regulator extension: stopping result

## Scientific disposition

**STOP_E5_COVARIANT_FRACTIONAL_ACTION_KERNEL_NOT_ONE_LOOP_UV_REGULATOR**.
The preceding source-independent free fractional multiplier cannot simply be
used on free kinetic terms at nonzero g: it has a nonzero local gauge defect.
A precisely ordered covariant replacement has a valid classical functional
covariance argument, but fails the next quantum-regulation requirement.
Its complete scalar determinant retains a nonzero gauge-field UV logarithm
for positive regulator exponent. Propagator improvement alone does not regulate
the determinant when all covariant vertices are retained.

Two different derivations agree. The smallest actual-sector witness is the
complex phi representation's two-gauge-leg scalar loop. The full four-sector
calculation also gives the nonzero pole. A separate proper-time scalar
determinant and direct dimensionally regulated bubble/seagull calculation
provide positive controls; they are not a complete retained-source quantum
prescription. This stops this particular action-kernel extension's M2 claim,
not the reconstructed action, Stage D--E4 or Spin(10).

Baseline 760cb4c was clean, with no matching calculation worker. Twenty-three
sealed chains are authenticated; prior expensive work is reused. State v113
and 34/39 remain unchanged. All 643 pairs,48 actual H backgrounds,34 physical
terms,29 potential terms and nonsymmetric/R_H interactions remain. No source
activation/removal, auxiliary elimination, catalog/HB1/C5, C1_GS, matching,
physical parameter changes, publication, outreach or remote push.

## Free-only regulator: exact local failure

The prior free kernel is P(p^2)=((p^2+m_reg^2)/mu_reg^2)^alpha,
alpha=e_reg/2. At g=0 it commutes with linear Q0. Full local transformations
mix momenta, so that statement does not extend to nonzero g.
For the actual canonical phi generator0 and its first selected two-component
plane, rho_ij=1/sqrt(2). With p+q+r=0 the free-only action variation has coefficient

    g rho_ij [(P(q^2)-1)q^2-(P(p^2)-1)p^2].

At p^2=1,q^2=4,m_reg^2=mu_reg^2=1 it is

    g/sqrt(2) [-2^alpha+4*5^alpha-3] != 0.

Its first-alpha coefficient is g/sqrt(2)[4 log5-log2]. The gauge-parameter/
ghost Euler coefficient is nonzero, so it is not an ordinary boundary.
At p=-q the coefficient vanishes: constant-parameter tests miss this defect.
The generic first-alpha expression contains nonpolynomial momentum logarithms,
with nonzero fourth momentum derivative. Finite-alpha exact restoration is
outside a finite local polynomial counterterm space. The potential loop
remnant as alpha->0 is a separate Ward/ST restoration question; it has not
been declared an anomaly or physical-action failure.

## Typed covariant candidate and its classical limit

For this inactive candidate use L_r=-D_B,r^2, K_r=L_r+m_reg^2 and
P_r=(K_r/mu_reg^2)^alpha. The scalar action kernel is explicitly

    (1/2) x_r^T L_r P_r x_r.

It has the original physical kinetic limit at alpha=0 and the preceding
free multiplier at g=0. It is NOT the different ordering (Dx)^T P Dx:
commuting D through a spectral kernel in a curved connection is unjustified.
Gauge kinetics use the invariant F P_ad F pairing. The complete scalar
potential and canonical source algebra stay unchanged.

Extend E1's heavy condition with a kernel built from D[H_total] and its light
condition with D[background_H], keeping the actual xi cubic and widths.
At g=0 these reduce to the prior P times linear divergences. The heavy full-Q
kernel variation includes g[V,C_M]_H through the Frechet derivative; H-only
BRST substitution is forbidden. The light background kernel has Qbackground=0.
Only the actual twelve-generator background and48 external coordinates occur.

For M=-g rho(C), inherited representation/BRST closure gives QD=[M,D],
QK=[M,K], QM=M^2. The resolved variation program is

    delta P = sin(pi alpha)/(pi mu^(2alpha))
               integral dt t^alpha (K+t)^-1 delta K (K+t)^-1,
    delta K=-delta D_mu D_mu-D_mu delta D_mu,
    delta(LP)=delta L P+L delta P.

Thus QP=[M,P], Q^2P=0 and the invariant physical pairings have zero functional
variation. Primary divided-difference spectral differentiation and replay
direct rotation agree on actual normalized-generator plane controls. Dropping
the connection variation fails. The full tree master argument uses unchanged
closed source algebra and field-only fermion canonical transport with these
variational programs. Its nonlocal source columns are not freshly expanded,
and the local14-node physical Euler adapter is not granted new authority.
This is a classical functional argument, not quantum regulation.

## Actual scalar loop: normalization, pole and finite control

For the canonical real representations I_ab=-Tr(rho_a rho_b), all **8,100**
entries agree between saved canonical matrices and a fresh physical tensor
derivation, including implicit zeros:

| Sector | Real coordinates | I_ab / delta_ab |
| --- | --- | --- |
| Phi | 54 | 12 |
| Sigma | 252 | 70 |
| phi | 20 | 2 |
| S | 2 | 0 |
| Total | 328 | 84 |

Replay uses normalized10-by10 matrices, symmetric-tensor trace factorization
and all45 physical five-form generator actions. Hodge star commutes with all
of them and squares to minus identity. Two generator replacements cannot
reach a disjoint five-index complement, so its trace against every generator
pair vanishes. The complex self-dual half has index35; its realification
restores70. Using35 for the real Sigma loop would incorrectly give total49.
The singlet has zero current.

The flat covariant heat-kernel coefficient contains
Tr[(1/2)V_xx^2+(1/12)Omega^2-(1/6)Box V_xx], with Omega=g rho(F).
The boson determinant supplies the factor minus one half. Compare
[Vassilevich's equations (1.18),(4.28)](https://arxiv.org/html/hep-th/0306138).
This published method does not certify the project. The full29-term Hessian
program and its canonical normalization are retained; the potential part
matches the preceding -Tr(V_xx^2)/(64pi^2 e) pole and its boundary convention.

For d=4-2e, the scalar gauge part is

    Gamma_E,pole = 7 g^2/(32pi^2 e) integral F^a_mu_nu F^a_mu_nu.

Its Euclidean counterterm has the negative sign; Wick transport gives the
positive Minkowski F^2 counterterm. These are loop coefficients in the
specified gauge/scalar theory, not adopted physical parameters or matching.

The replay varies the Gaussian scalar determinant into bubble and seagull
vertices before integration. Feynman parameterization gives

    Pi_mu_nu = (g^2 I_ab/2)(p^2 delta_mu_nu-p_mu p_nu)
                  integral_0^1 da (1-2a)^2 J2(M^2+a(1-a)p^2),
    residue J2 = 1/(16pi^2), integral(1-2a)^2=1/3.

All four momentum contractions vanish exactly. The total Pi pole is
7g^2/(8pi^2 e) times the transverse tensor, agreeing with the heat-kernel
density. Omitting the seagull gives a nonzero longitudinal mass pole.
At zero total scalar background the canonical mass squares are 2mPhi2,
2mSigma2,mphi2,mS2. This off-shell configuration is allowed; it is not the
physical vacuum. Positive reference masses delimit the finite integral's
domain without altering the stored benchmark or proving its IR conditions.

The explicit MSbar finite scalar amplitude uses

    (g^2 I_ab)/(32pi^2) transverse_tensor
      integral_0^1 da (1-2a)^2 log[mu^2/(M^2+a(1-a)p^2)].

Its nonexceptional massless weight is (1/3)log(mu^2/p^2)+8/9, independently
obtained by direct integration and elementary logarithmic moments. It is
nonlocal. A separate finite proper-time interval gives a covariant scalar
trace: primary heat-kernel variation and replay rotation have zero trace.
This physical scalar contribution is compatible with all45 total-connection
gauge rules and actual residual-H background transformations. It does not
erase the full action's expected light quantum-H breaking. The complete
gauge/ghost/source one-loop sum, all beta functions and C1_GS are not computed.

## The decisive regulator failure

Specialize only the physical quadratic masses to zero at zero total scalar
background for the formal witness; the stored action and higher couplings are
unchanged. For every nonzero eigenvalue lambda, the ACTUAL scalar kinetic
operator has eigenvalue lambda((lambda+m_reg^2)/mu^2)^alpha. Therefore

    (1/2)log det(LP) = (1/2)log det L
                       +(alpha/2)log det(L+m_reg^2)
                       -alpha log(mu) Tr1.

Primary differentiates its spectral logarithm; replay independently checks
eigenvalue products. The positive-reference shifted determinant has the same
leading F^2 UV pole as the unshifted determinant. Consequently

    Gamma_E,pole^(LP) = 7 g^2(1+alpha)/(32pi^2 e) integral F^2 != 0.

The phi sector alone gives g^2(1+alpha)/(192pi^2 e). This fails for every
positive alpha and nonzero g; a field-independent normalization cannot
cancel it. The covariant induced vertices are retained in the determinant.
Discarding them would falsely infer regulation from the free propagator's
improved power. This refutes this specified scalar action-kernel prescription
as a sufficient one-loop regulator. It does not prove that every covariant
ordering fails, that the complete model's poles cancel or fail to cancel,
or that a separately regulated restored scheme cannot exist.

Dependent whole-quantum-prescription claims stop here. The proper-time scalar
control remains a separate positive comparison, not a substitute for M2.

## Formal measure, validation and limitations

Both routes calculate the left Jacobian of z->z+epsilon_left Qz over all643
integrated fields, using the actual ghost and dual nonminimal frames.
There are264 nonzero diagonal terms before sector sums; every sector
supertrace and the total vanish. This formal Berezin divergence is not proof
of a continuum measure, anomaly freedom or nilpotence after mode projection.
The two routes share this graded word/derivative machinery and immutable
source columns; their trace, spectral and loop derivations differ. They also
share Python/SymPy and analyst, without external endorsement.

Two initial unit assertions decoded spectral powers without their declared
positive mu/alpha types and could not prove equal factorizations. Original
tests, a start fingerprint and the observed failing output are preserved in
test_preflight_v1, excluded from final validation. Typed spectral decoding
fixes those assertions; no completed scientific output is edited. Cross-route
logarithms are compared by exact expansion using positive reference/momentum
and real-g assumptions, without force=True branch changes. Each route must
still reproduce its own exact bytes.

The required final receipt runs **279 regressions**:234 scientific (20 new,
214 inherited),24 process,21 governance. It freshly regenerates both new
routes byte-identically, authenticates23 predecessor chains, and checks
protected/new/state bytes and bounded workspace/active-data size/mtime.
Strict custody remains exit **2**, seven unresolved references. See
frozen_a10_e5_nonzero_regulator/validation_receipt.json for observed results.
This is validation of a failed scientific gate and its bounded controls.
Older expensive representation/source/basis/loop work is authenticated, not
repeated. No full anomaly, IR, source insertion/contact, quantum A5, all-loop
restoration or unrestricted environment audit has been performed.

## Next action toward completion

Use a separately defined loop regulator for the complete retained-source
one-loop functional, rather than relying on this fractional action multiplier.
The next bounded task should derive the actual643-field graded Hessian,
its ghost/nonminimal and source mixing, and the regulator's Ward/ST variation
and allowed restoration terms. The scalar proper-time control is one input;
it is not automatically a regulator of that whole mixed system. Full IR/zero
modes, general local probes/contacts, weighted gF quantum A5 equivalence and
M2--M5/E5 remain open. This is a scientific next step, not a new infrastructure
program or permission to activate sources or run HB1/C5.

The full Spin(10) x U(1)PQ investigation remains incomplete, including global
boundedness, PQ quotient, fermion/Yukawa content and physical matching/
phenomenology. No new physical unification claim follows from this result.
