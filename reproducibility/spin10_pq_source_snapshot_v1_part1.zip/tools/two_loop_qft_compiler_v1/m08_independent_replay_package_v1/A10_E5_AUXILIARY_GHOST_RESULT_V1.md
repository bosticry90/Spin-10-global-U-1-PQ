# Actual auxiliary-source/ghost derivative companion matches

AG1 qualifies the selected actual g^2 J_Lambda Box C UV logarithmic pole;
AG2 matches the complete inactive member frozen at8ab7042. All45x45=2025
Box coefficients and20250 symmetric derivative components, including six
off-diagonal zeros and allfour Minkowski diagonal weights, are retained.
The coefficient is A=diag(0_H,-C_H), C_H=-sum_h T_h^2. It has56 physical
nonzero slots/rank32 and128 canonical allfour density words. For example
A_13,13=-8/5, with common hbar g10^2/(32pi^2epsilon). No coefficients changed.

Signed Fourier-Hessian/Born and independently routed ordered Gaussian/Wick
unit calculations agree on the full ten-component tensor. Their Box weights
are(+1,-1,0) for internal-antighost, external-ghost and internal-gauge
derivatives. The complete GF vertex current cancels at kernel level;
the gauge-derivative kernel is nonzero even though its two-jet log residue is
zero. Full BB/BL/LB/LL0 and both odd starts are included before edge screening.
Removing the mixed edge or the second inverse-denominator Taylor term turns
the nonzero unit Box residue to zero; a loop-sign flip changes it by2.

Primary contracts the full literal source/GF vertices; replay derives the
same -C_H tensor from physical10 commutators. Source and ghost are BOTH odd.
All12 homogeneous H, exact source/dual/primal frame roundtrips and reality
checks pass. The complete leading45 H/M ghost and auxiliary/gauge mixed
reference symbols are checked in the real frame. Widths/xi disappear through
mixed/odd edge screening. Full local H jet Ward identities require additional
partner amplitudes and are not inferred from this isolated Box tensor.

The literal action has180 relevant source cubics and836 source quartics;
all45 source rows are screened. External ghost in the source cubic leaves
one integrated leg, so its Hessian vanishes. The source-quartic tadpole has
no vertex jets and total external momentum zero: its two-derivative
coefficient is zero before integration, with heat profile2 retained. Its
no-derivative cutoff-power and mass^2 logarithmic coefficients remain
unqualified. The only derivative bubble has one H odd inverse and one M
mixed inverse, heat profile4. All6688 scalar/Orbit ghost cubics are screened;
none supplies the light-antighost edge. Other bosonic vertices cannot close
the source H ghost; positive-dimensional reference insertions lower this
two-jet logarithm's UV degree. Lowerg0/g1xi derivative channels vanish by
the source inventory and zero H/M odd or Lambda/Lambda edges.

UV domain k_E^2>R_UV^2>0; no whole scaleless integral. Degree-2 power and
degree-3 odd Taylor terms stay distinct from the degree-4 quadratic logarithm.
Gaussian angular moments versus sphere-IBP moments agree; all momentum
Taylor derivatives through degree2 are exact, with no width/group cutoff.
Heat Taylor insertions give degree-2/Lambda^2 or degree0/Lambda^4 terms with
Gamma(1-epsilon)/Gamma(2-epsilon), not the logarithmic pole. No finite/IR
amplitude or power-divergence cancellation is claimed.

All three derivative representatives are retained with exact currents:
J Box C, -(partial J)(partial C) and (Box J)C. Candidate reduction covers
every source/ghost jet placement and all coupling/reference-width coefficients.
The candidate's selected/effective density has128 words and zero new current;
actual-minus-candidate and lower-order residuals are zero. An independent
odd-source Euler/deletion control on JLp13 gives -8Box Cp13/5; treating the
source as even leaves residual -16Box Cp13/5. Wrong source evaluation chart
also yields a nonzero complete-tensor residual. These are controls, not a
scientific mismatch, EOM quotient or anomaly claim.

Controls attempt1 failed because a zero polynomial was sent to a nonzero
Laurent UV-degree assertion. Preserve its exact preparation/source/start/
stdout and disposition. Primary linear Taylor polynomial was exactly zero;
replay's nonzero odd polynomial has zero angular average. Current code
returns exact zero before nonzero monomial-degree checks and keeps every
nonzero check. Qualified controls attempt2 uses a new preparation. Failed
attempt1 is excluded from PASS; no earlier evidence was edited.

Validation receipt owns scientific/process/governance/delegatede5 tests,
FOUR strict own-byte fresh controls/primary/replay/comparison,40 protected
predecessor chains, new/protected/state byte and size/mtime invariance.
Custody remains expectedexit2/seven unresolved refs,neverPASS. Old expensive
loops/images authenticate without replay. Raw Git index/worktree equality
before localcommit. Preparations/attempts/receipt/bindings retain exact hashes,
commands, code, starts, outputs and runtimes. Any failed validation attempts
remain separate exact snapshots/dispositions.

Shared action/geometry, exact arithmetic, Python/SymPy and analyst limit
independence; distinct mathematical routes are not independent scientists.
Selected reproduction/derivation/match verified within scope; proof-assistant
formalization not attempted, broader interpretation/explanatory compression
open, empirical connection none. project_state.json v113/34 of39 remains
sole authority. FullE5/A5/Ward/contact/IR/anomaly, global scalar/PQ,
fermion/Yukawa/phenomenology and whole Spin(10) x global U(1)PQ remain
unfinished. No adoption, physical/catalog/HB1/C5/C1_GS/matching, promotion,
outreach/push/publication. Local conventions, ladder and solo-review apply.

Next central scientific action: separately freeze and calculate the actual
full g^3 four-ghost companion against the unchanged966-word prediction,
retaining every coupling/reference-width/H/M contribution and full proper
graph inventory. First mismatch stops before fitting. The lower g^2
longitudinal gauge/auxiliary mixing, no-jet power/mass and other higher
predictions remain visible and unqualified; this match does not accept them.
