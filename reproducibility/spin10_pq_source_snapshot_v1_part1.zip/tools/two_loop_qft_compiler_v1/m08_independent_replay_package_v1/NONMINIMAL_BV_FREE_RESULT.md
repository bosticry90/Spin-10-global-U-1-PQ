# Free nonminimal BV consistency result

The small free-sector obstruction has a coherent off-shell BV resolution in
a separately constructed comparator. One antighost source completes its
canonical pairing, and the missing cancellation then follows from the same
action and bracket as every other transformation. Both implementations derive
all fourteen images and obtain zero squares, including the old auxiliary-source
witness. No equation of motion is imposed.

This qualifies only `M08_NONMINIMAL_BV_FREE_COMPARATOR_V1`. It does **not** repair
or replace the frozen M08 construction, promote a C5 contract, or authorize
HB1. The exact M08 obstruction remains evidence against its tested six-pair
construction. Formal scientific authority stays `34/39`; `finite_C1_GS` remains
null. The [preregistered contract](NONMINIMAL_BV_FREE_CONTRACT_V1.md) fixes this
scope, the action, pairing and signs before calculation.

## The cancellation and its origin

The free model has a vector V, ghost u, antighost bar and auxiliary Lambda.
All four types have canonical source partners, including the new comparator
symbol Kbar. It is not added to the M08 alphabet. In the coherent left-source
coordinates, the action is

```
S = integral [-1/4 F_mu_nu F^mu_nu
              - bar box(u) - Lambda div(V) + xi Lambda^2/2
              + KV^mu partial_mu u - Kbar Lambda].
```

The gauge-fixing part is exactly the frozen free witness. The Maxwell term
supplies a conventional free gauge kinetic action; this is not an assertion
that the complete M08 action becomes quadratic at zero coupling.

The canonical nonminimal pairing is the motivation for `-Kbar Lambda`, not
a coefficient fitted to the failed square. A common bracket generates both
the antighost rule and the reverse source rule. This use of nonminimal fields
and antifields follows the construction described by
[Gomis, Paris and Samuel, sections 4, 6 and 7.2](https://arxiv.org/pdf/hep-th/9412228).
The calculation here fixes its own left-source signs explicitly rather than
copying a differently oriented BRST formula.

Every image is derived by graded Euler variation of S:

| Generator | Exact image |
|---|---|
| V_mu | partial_mu u |
| u | 0 |
| bar | -Lambda |
| Lambda | 0 |
| KV^mu | E^mu + partial^mu Lambda |
| Lu | box(bar) + partial_mu KV^mu |
| Kbar | -box(u) |
| KL | -div(V) + xi Lambda - Kbar |

Here E is the Euler derivative of the Maxwell kinetic action. Its divergence
vanishes as a differential identity, not an equation of motion. Four vector
components and their four sources give fourteen base generators in seven
canonical pairs. The additional source has `(d,gh,parity)=(2,0,even)`;
all images raise dimension and ghost number by one and preserve `d-gh`.

The previously missing cancellation is now local and exact:

```
Q^2 KL = -box(u) - Q Kbar = -box(u) + box(u) = 0.
Q^2 Lu = -box(Lambda) + div(E) + box(Lambda) = 0.
```

All other generator squares vanish as well. Thus the correction does not just
remove one selected coefficient while leaving other sources untested.
The old functional `integral KL Lambda` also has zero square in this model.

## The master equation and gauge fixing

The source bracket is the fixed coherent left bracket from the preceding
review, now applied to every nonminimal pair. The invertible map to canonical
antifields is `z_star=(-1)^parity(z) J_z`; the canonical pair brackets are
checked exactly in both orientations.

The half-master density is not pointwise zero. It is the explicit divergence

```
(S,S)/2 = integral partial_mu J^mu = 0 modulo IBP,
J^mu = E^mu u + Lambda partial^mu u.
```

The ordinary-jet calculation verifies this polynomial equality and the zero
Euler residual for every field and source. The functional equation uses the
usual local-functional convention modulo total derivatives, not an EOM
quotient. The squares above vanish even before IBP reduction.

The gauge-fixing fermion is `psi=integral bar(div(V)-xi Lambda/2)`.
Starting with the ungauge-fixed nonminimal master action, the finite canonical
shift `U=exp(-ad_psi)` gives, in these source coordinates,

```
KV^mu -> KV^mu + partial^mu bar,
Kbar  -> Kbar + div(V) - xi Lambda/2,
KL    -> KL + xi bar/2,
Lu and all fields unchanged.
```

The inverse changes the sign of every shift. Its expanded action equals S
modulo the explicit current `bar partial^mu u`. Both routes verify the inverse
and `Q_gf U = U Q_min` on every generator. The shifts arise from the declared
Hamiltonian generator psi, so bracket preservation uses the canonical BV
identity, not invertibility alone. An invertible shift with one wrong sign
fails the tested intertwining equation and is retained as a negative control.

These maps preserve ghost number, dimension, parity and locality, and extend
through commuting ordinary derivatives. There is no internal H transport here:
the original selected heavy component is already a qualified H singlet.
No physical INT8 conjugation map, interacting background descent or transport
between complete M08 catalogs is certified by this free real-coefficient model.

## Why deleting the partner does not repair the old construction

Omitting Kbar and retaining the separate noncanonical antighost rule reproduces
the historical results exactly:

```
Q_old^2 KL = -box(u),
Q_old^2 integral KL Lambda = -integral Lambda box(u).
```

The old ST scalar still cancels modulo the displayed total derivative, while
the old noncanonical bracket-derivation defect is `+1`. This preserves the
reason a zero ST test did not imply a square-zero source differential.

In the complete comparator, the surface `Kbar=0` is NOT invariant, because
`Q Kbar=-box(u)` is nonzero there. Keeping the auxiliary source while simply
discarding its antighost partner therefore cannot recover a consistent
off-shell source-containing complex. The old witness remains non-IBP-null.
Flipping the partner coefficient instead gives `Q bar=+Lambda` and
`Q^2 KL=-2 box(u)`; it fails the master test too.

The field-only algebra is a different matter: its forward rules close without
sources. This result does not forbid using that smaller physical-field
algebra. It does forbid treating deletion of Kbar as a chain-compatible
restriction of the full source algebra tested here. No equivalence of full
cohomology, physical parameter census or acyclic M08 source extension is claimed.

## Independent replay and earlier controls

[Primary evidence](frozen_nonminimal_bv_free/primary.json) contains 594 exact
assertions, the complete derived images, the total-derivative certificates,
canonical shifts and retained failures. It reuses the existing exterior engine.
[Replay](frozen_nonminimal_bv_free/replay.json) uses a separately coded
ordered-word polynomial algebra and formal variation, including an independent
Maxwell contraction sum and extraction of the gauge-fixing coefficients from
the frozen M08 action. It imports no primary columns or primary coefficients.
Both outputs are frozen separately before full-polynomial comparison.

All fourteen images and all shifts agree. Each implementation checks 210
squares: fourteen generators with zero, one or two symmetric ordinary
derivatives in four dimensions. Nonzero jets through order five occur; no
highest-jet term is set to zero. Higher-jet limits raise an error. Commuting
prolongation and the left graded derivation imply arbitrary-jet nilpotence
from the base equations; this is an algebraic argument, not a Lean certificate.
Regressions also check selected third mixed source jets explicitly.

Algorithm and code-path independence hold for the bounded polynomial/variation
calculation. The model, bracket convention, Python and SymPy are shared.
Library independence and runtime independence are false. External specialist
review remains outstanding.

After the free gates passed, [fresh follow-up regressions](frozen_nonminimal_bv_free/regressions.json)
reproduced the old comparator evidence byte-for-byte: 2,004 assertions, the
48-generator partially gauge-fixed nonminimal BV model, and 66 selected M08
light-source self-square blocks. The isolated coherent candidate retains zeros
in place of `-2i` and `+1`; the frozen old nonzero values and the Sigma
nonhorizontal coefficient remain unchanged. The partial-gauge model retains
its exact master, square and Cartan checks. Its nonminimal assumptions are
consistent with [Ferrari, section 3](https://arxiv.org/html/1308.6802v3), but do
not certify M08's particular source algebra. These are separate bounded
regressions, not a combined interacting M08 construction.

## Validation and scientific boundary

The [read-only audit](audit_nonminimal_bv_free.py) regenerates the three new
evidence artifacts byte-identically, compares all images and shifts, rejects
seven adversarial evidence mutations, and checks historical byte bindings,
live stable scientific invariants and before/after workspace inventories.
The [validation receipt](frozen_nonminimal_bv_free/validation_receipt.json)
records measured tests, audit results and stage timings. Audit success qualifies
this comparator only; it does not turn the failed M08 candidate into a PASS.

No source coefficient, Sigma, frozen transformation, catalog or project-state
authority is changed. Existing JCAT/T5 authority is reused explicitly; no large
regeneration, differential matrix, rank, cochain dimension or cohomology is
computed. No pole/projection payload is read, and no unrestricted repository-wide
validation is claimed. Historical custody remains unresolved separately.

## Next bounded decision

The free counterexample now has a demonstrated mechanism, not a speculative
missing-sign explanation. The next useful investigation is an independently
reviewed nonminimal BV architecture for the full M08 field/source system:
derive its complete pairing and gauge-fixing construction, account for both
antighost/auxiliary sectors and composite R, and test interacting master,
source-square, Cartan and derivative identities before considering catalog
impact. That requires a separately versioned proposal and explicit impact
analysis; this comparator is not permission to edit the frozen action/images.

Specialist review should distinguish the valid field-only BRST sector from an
invalid source-deletion restriction, confirm the source-coordinate orientation
and canonical gauge-fixing shift, and assess how M08's partial gauge fixing
changes the nonminimal source module. Only a fully qualified replacement could
restart H-basic/C5 work. The physical Spin(10) verdict, finite threshold and
formal scientific ledger have not advanced in this execution.
