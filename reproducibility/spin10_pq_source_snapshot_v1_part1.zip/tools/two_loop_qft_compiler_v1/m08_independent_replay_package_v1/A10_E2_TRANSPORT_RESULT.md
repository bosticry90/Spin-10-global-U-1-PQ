# A10 E2 inactive canonical gauge-fixing transport result

Scientific disposition: **PASS_BOUNDED_INACTIVE_E2_CANONICAL_TRANSPORT**. This qualifies the complete classical canonical transport of the inactive 643-pair gauge/scalar Stage D candidate using the E1 replacement `M08_PHYSICAL_FRAME_GAUGE_FERMION_V1`. Historical A4-V2/A5-V2 equivalence remains **unproved**. E3–E5 have not been executed. No source, action, catalog or authority promotion occurs.

The governing authorization is the user assessment of `fca61d1`; the calculation contract is `A10_E2_TRANSPORT_CONTRACT_V1.md`. All ten sealed predecessor chains authenticate. Stage D's 34 physical terms and nine source terms, its physical Euler programs, the E1 fermion and all historical negative controls are reused without modification. There were no surviving scientific calculation processes at recovery. The repository began clean at `fca61d1a88766efec6608b03789427a7403f69c5`.

## Typed canonical map

There are 643 canonical field/source pairs and 1,286 generators: 180 gauge, 328 scalar, 45 ghost, 66 heavy nonminimal and 24 light nonminimal field coordinates, each with its evaluation source. The 48 H-background components remain external parameters, held fixed by Q. They acquire no canonical partners. All auxiliary and source coordinates are retained.

The frozen source-left convention is Q=(S,.), with bracket

    (F,G) = sum_z (-1)^p_z [F right_z G left_Jz - F right_Jz G left_z].

Choose the earlier bounded source-left flow orientation U=exp[-(Psi,.)]. Fresh differentiation with the qualified bracket gives

    (Psi,Jz)=(-1)^p_z Euler_left,z(Psi),
    Uz=z, UJz=Jz+A_Jz,
    A_Jz=-(-1)^p_z Euler_left,z(Psi).

Thus the canonical antifield zstar=(-1)^p_z Jz shifts by -Euler_left,z(Psi). The inverse sends A to -A. The overall orientation is explicitly chosen; the opposite uniform orientation is also canonical. Dropping the parity factor is the defective alternative tested here. No sign is inferred solely from a generic textbook antifield formula.

All 643 shifts, including 140 zero shifts, agree exactly between routes. There are 503 nonzero shifts with 4,396 coefficients. These are the canonical part of the E1 Euler covectors; its 272 external-background coefficients are not added as canonical sources. Conjugation, grading and the field/source evaluation pairing are preserved. The invariant heavy dual-field bilinear G_M^-1 remains distinct from the canonical identity evaluation pairing.

Both inverse directions are checked on all 1,286 generators: 2,572 checks. U fixes every field and every source-free coefficient of A. Ordinary symmetric derivative jets are transported by prolongation, with 80 additional first-jet controls. Resource limits raise exceptions rather than returning zero.

Canonicity is tested with arbitrary independent graded smearing functions t_z and s_z over the entire source alphabet, rather than only brackets of bare coordinate symbols. The complete shifted source-source bracket density has 752 coefficients and is the divergence of a 376-coefficient current. The density-minus-divergence residual is exactly zero. This tests the derivative kernels of the Hessian, including mixed gauge/antighost blocks. The corresponding current is

    K^mu = eta_mumu [sum_i(t_BM,i,mu s_ub,i - s_BM,i,mu t_ub,i)
             + sum_hk (G_H)_hk(t_BH,k,mu s_bar,h - s_BH,k,mu t_bar,h)].

Arbitrary test functions and their jets make the coefficient identity cover all source blocks, including zero blocks. Field/field brackets stay zero and field/source brackets keep the declared canonical sign. The exact variational-Hessian argument and this explicit boundary identity jointly establish functional canonicity.

## Complete transported action and columns

Write the authenticated Stage D density as S=S0+sum_z Jz Rz. Execute the original nine source ASTs with shifted source component tables, while preserving the entire physical action:

    S'=S0+sum_z(Jz+A_Jz)Rz = S+Delta,
    Delta=sum_z A_Jz Rz.

The native 14-node grammar and all 43 original AST terms are retained. The new candidate's explicitly bound component-source pullback supplies gauge fixing; unchanged AST terms alone must not be mistaken for an unchanged action. This adds no physical coupling or fitted coefficient. Xi and eta_H retain the replacement's declared gauge meanings, with alpha=xi. It does not establish numerical equivalence to unbound historical parameter conventions.

The primary evaluates all nine source terms directly with the graded executor. The replay derives Delta from the E1 fermion's jet-gradient variation and the explicit integration-by-parts current. They match all 33,092 coefficients of Delta and the 68,254 coefficients in the transformed source-plus-gauge-fixing polynomial. The original source polynomial contains 35,162 coefficients. The complete heavy/light interactions, nonsymmetric coset and composite R_H are retained. Nonzero quartic ghost monomials are present; this does not qualify their E4 interpretation.

The local density identity is

    Delta=Q Psi+partial_mu L^mu,
    L^mu=eta_mumu [sum_i ub_i R_BM,i,mu
                  + sum_hk bar_h (G_H)_hk R_BH,k,mu].

All 3,668 current coefficients agree. The positive divergence is derived from the literal graded first variation and chosen flow, not assumed from earlier diagnostic boundary formulas. Densities agree with the displayed current before taking their functional equivalence. Boundary terms are not silently discarded.

Direct graded Euler differentiation gives K_Jz=Euler_left,z(Delta). Independently, conjugating the old differential gives

    K_Jz=U(QJz_source)-QJz_source-Q A_Jz.

All 643 correction columns match, including zero columns, with 108,243 coefficients. All 1,286 complete polynomial columns match, with 214,340 coefficients: the authenticated 106,097 source-only coefficients plus these new corrections. The field columns remain unchanged. Each relevant source column retains its qualified physical Euler program; all 508 physical slots and their program bindings agree with Stage D. U fixes them because they are source free. The even physical adapters are not extended to odd fermion/source expressions.

The executable candidate is `frozen_a10_e2_transport/M08_CANONICAL_BV_GAUGE_FIXED_E2_INACTIVE_V1.json`; its source-shift, complete-column and current programs are bound to the completed evidence. It is inactive and distinct from the historical action and catalogs.

## Master functional and off-shell nilpotence

The master calculation is decomposed by source degree. The degree-zero physical part remains the Stage D certificate

    2 partial_mu(E_B,a^mu C^a)-2 C^a N_a,

with all 45 off-shell Noether identities N_a=0 authenticated. The degree-one part remains 2 partial_mu(J_B,a^mu QC^a), with the original 5,316-density/1,772-current coefficient certificate. Higher source degrees are absent because the source action stays linear and Delta is source free.

The complete new degree-zero density is freshly computed:

    M_GF=2 sum_z K_Jz Rz,
    Theta_Delta^mu=sum_z Rz partial_left Delta/partial(z_mu),
    C_GF^mu=2(Q L^mu-Theta_Delta^mu).

Both routes agree on 88,180 density coefficients and 23,984 current coefficients and explicitly reduce M_GF-partial_mu C_GF^mu to zero. Therefore the complete master current is

    C_complete^mu=2 E_B,a^mu C^a+2 J_B,a^mu QC^a+C_GF^mu.

The master functional vanishes under compact support or boundary conditions annihilating this complete current. It is not claimed that the local master density vanishes identically. No field equation, zero-field projection or auxiliary elimination is used.

The canonical map, complete master functional and exact column conjugacy establish Q'=U Q U^-1 and off-shell nilpotence across all 1,286 generators and admitted ordinary symmetric jets. The graded Jacobi argument is structural; all full-size source squares are **not** exhaustively expanded. Retaining all sources and auxiliaries is essential to this declared system. This is not a claim of off-shell nilpotence after antifield restriction or integrating out auxiliary variables.

Canonical transformations preserve the classical master equation within the functional bracket. Gauge-fixed coordinates can retain antifields as sources; eliminating them changes the nilpotence question. These distinctions are explained in [Gomis, Paris and Samuel, *Antibracket, Antifields and Gauge-Theory Quantization*, Sections 4 and 6.6](https://arxiv.org/abs/hep-th/9412228). The publication supports the method, not this implementation. Classical transport alone does not establish the quantum master equation, functional measure or physical gauge independence.

## Distinct physical replay and adversarial controls

A separate exterior-ring calculation uses a closed three-plane Spin(10) algebra, five symmetric-traceless scalar coordinates and 20 pairs in two spacetime directions. It directly differentiates the full physical, source and gauge-fixed actions, including covariant scalar kinetics and an invariant quartic potential. A shifted-vacuum orbit and nonzero cubic fermion are retained. Its diagnostic parameters are not new parameters of the full candidate.

All 40 full Euler columns agree with affine conjugacy in this different arithmetic. The complete master density matches its explicit current, and all 240 field/source squares at orders zero, one and two vanish off shell. This control challenges the structural proof and derivative conventions; it does not replace the full-size coefficient comparison.

An ungraded shift in a minimal auxiliary block produces the exact source-bracket obstruction xi/5. Omitting a derivative-dependent shift fails a smeared bracket and its Euler test even though a bare coordinate bracket misses it. Omitting the Q A inverse-map contribution produces a nonzero light auxiliary-source square. The exterior control also fails when an antighost source column is removed. Changed action coefficients and eleven false promotion/endorsement flags are rejected. Historical A10, five-form, free-Lorentz and bare-heavy-pairing witnesses remain sealed and covered by inherited regressions.

The primary and replay differ in action construction, differential application and source-column derivation. They share exact word arithmetic, Python/SymPy, immutable physical inputs, conventions and analyst. The additional exterior control shares Python/SymPy and assumptions but uses different polynomial storage and variational arithmetic. No external endorsement is claimed; the solo-review policy applies without outreach.

## Validation, historical controls and next decision

The receipt records 162 targeted tests: 20 new and 142 inherited, comprising 141 scientific and 21 governance regressions. Three guarded read-only routes regenerate byte-identically. Ten predecessor chains authenticate. Their expensive representation/source qualifications are not repeated; their materialized inputs and established certificates are reused. The receipt includes fresh route timing, resources, exact coverage and measured workspace inventory. The inventory checks size and modification-time metadata, not every byte of the workspace; separate manifests bind completed bounded files and inherited evidence. No audit-time mutation is detected.

Formal authority remains **34/39**. Strict historical custody remains **exit 2 with seven unresolved references**, not PASS. Frozen actions, definitions, catalogs, history and authority bytes remain unchanged. No activation, auxiliary elimination, HB1/C5, C1_GS calculation, catalog rebuild, external contact or remote push occurs.

The next decision is whether to authorize **E3 quantum/background consistency** for this transported candidate. E4 composite/nonminimal/quartic reconciliation and E5 the useful H-basic domain remain separate obligations. Historical equivalence and physical gauge independence remain unproved. HB1/C5 and finite C1_GS remain blocked. The action covers gauge/scalar fields and excludes fermion/Yukawa sectors. E2 provides no new particle prediction, quantum-consistency conclusion or numerical unification result.
