"""Independent physical two-form and formal first variation of gauge witness.

No indexed helper, primary slice evaluator or primary evidence is imported.
The two antisymmetric components are counted explicitly with Minkowski signs.
"""
from itertools import product
import sympy as s
from a10_executable_action import HERE,read,ETA,digest

def build(stage=lambda name,fn:fn()):
    action=read(HERE/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json')
    term=action['local_terms'][0]
    # Inspect the actual prefactor and contraction signature, independently.
    density=term['density'];assert density['node']=='LorentzContraction'
    assert density['contracted_indices']==['mu','nu'] and density['metric']=='diag(1,-1,-1,-1)'
    factors=density['expression']['expression']['factors']
    prefactor=s.sympify(factors[0]['value']);assert prefactor==-s.Rational(1,4)
    b,d1,d2,h,dh,eps=s.symbols('b d1 d2 h dh eps')
    comparisons=[]
    for mu,nu in product(range(4),repeat=2):
        def curvature(r,t):return d1*((r==nu and t==mu)-(t==nu and r==mu))
        L=s.expand(prefactor*sum(ETA[r]*ETA[t]*curvature(r,t)**2 for r,t in product(range(4),repeat=2)))
        variation=s.expand(L.subs(d1,d1+eps*dh)).coeff(eps,1)
        momentum=s.diff(variation,dh);Euler=s.expand(-s.diff(momentum,d1)*d2)
        boundary=s.expand(momentum*h)
        # Fundamental lemma for arbitrary compact-support h; explicitly retain
        # the boundary current. The replay never imposes d2=0.
        assert s.expand(variation-(Euler*h+s.diff(boundary,h)*dh+s.diff(boundary,d1)*d2))==0
        coeff=s.diff(Euler,d2)
        comparisons.append({'connection_component':mu,'ordinary_jet_direction':nu,
            'physical_density_coefficient':str(s.diff(L,d1,2)/2),
            'canonical_Euler_coefficient':str(coeff),'boundary_current':str(boundary),
            'first_variation':str(variation)})
    witness=next(r for r in comparisons if r['connection_component']==1 and r['ordinary_jet_direction']==0)
    assert witness['canonical_Euler_coefficient']=='-1'
    a,b,g=s.symbols('a b g10',real=True)
    T01=s.zeros(10);T01[0,1]=1/s.sqrt(2);T01[1,0]=-1/s.sqrt(2)
    T02=s.zeros(10);T02[0,2]=1/s.sqrt(2);T02[2,0]=-1/s.sqrt(2)
    F=g*a*b*(T01*T02-T02*T01)
    nonlinear_L=s.simplify(s.Rational(1,4)*2*ETA[0]*ETA[1]*s.trace(F*F))
    nonlinear={'physical_density':str(nonlinear_L),'canonical_Euler_B1_T02':str(s.diff(nonlinear_L,b))}
    return {'schema':'A10_BV_GAUGE_EULER_INDEPENDENT_PHYSICAL_REPLAY_V1',
        'status':'PASS_EXACT_CANONICAL_EULER_NEGATIVE_CONTROL_REPLAY_ONLY',
        'action_sha256':digest(action),'comparisons':comparisons,'smallest_witness':witness,
        'nonlinear_10x10_matrix_control':nonlinear,
        'derivation':'explicit antisymmetric two-form, canonical first variation and integration by parts',
        'scope':'arbitrary b(x^nu), all 16 Lorentz component/derivative pairs in the selected abelian generator channel',
        'EOM_used':False,'indexed_helper_imported':False,'primary_evidence_imported':False,
        'physical_action_repaired_or_changed':False,'master_action_qualified':False}
