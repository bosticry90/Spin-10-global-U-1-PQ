# E5 minimal source class and interacting zero-coupling target, V2

This prospectively supersedes V1's proposed full-Gaussian g=0 hypothesis.
V1, its source and the observed failure remain in preflight_v1. The exact
literal residual includes C12 Lambda13 ub44 with coefficient sqrt(2) i xi/4.
E1's heavy cubic fermion has no explicit g. No g factor is inserted and xi
is not set to zero. The inactive action and its qualifications stay unchanged.

All twelve V1 contract fields and its authority ceiling continue, with these
explicit corrections frozen before the dependent calculation:

1. Independently reproduce the complete nonquadratic g=0 residual and a real
   admissible physical heavy-vector witness, with nonzero auxiliary Euler
   derivative. Classify the full-Gaussian hypothesis as refuted if confirmed.
2. Keep the whole interacting gauge/ghost/nonminimal g=0 density. Separate
   its quadratic Hessian only to derive the generic non-null-momentum free
   propagator kernel. This is not elimination of its interactions or a
   Gaussian evaluation of its complete quantum functional.
3. Verify directly all 643 g=0 field-variation/source columns. If they are
   affine in integrated fields, derive the ordinary-source shift and graded
   Legendre identity without any Gaussian assumption. Retain all interactions,
   643 BV sources and 48 backgrounds. Probe sources are evaluated at rho=0.
4. The conditional source identity requires a source-independent formal
   regulator/measure and source normalization preserving the original affine
   dependence at that limit. Do not impose it on every W1-W7/A4/A5 scheme or
   claim an actual quantum prescription exists. Source/operator transport and
   nonlocal Gamma remain separate obligations.
5. The minimal field-rotation class, its polynomial nonexactness and its
   specified LOCAL integrability test are independent of the refuted Gaussian
   claim. Continue them with unchanged source pattern, potential and parameter
   ring. Their Ward/boundary checks must finish before they are qualified.

This changes a disproved research hypothesis, not physical parameters,
foundational assumptions, formal authority or the full investigation objective.
Preserve failed/unfinished evidence, stop on an unexplained essential mismatch,
and validate before local commit. No source activation/removal, auxiliary
elimination, catalogs, HB1/C5, C1_GS, contact, publication or remote push.
