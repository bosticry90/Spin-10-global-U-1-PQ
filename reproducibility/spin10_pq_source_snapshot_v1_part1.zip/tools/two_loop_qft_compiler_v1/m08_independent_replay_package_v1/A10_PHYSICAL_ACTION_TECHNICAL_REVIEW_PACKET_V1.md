# Physical-action technical review packet V1

This packet is for the solo project. It solicits no personal response or
endorsement. It assembles the exact negative control, inactive candidate,
independent evidence and unresolved questions for reproducible scrutiny.

## Frozen witness and complete-action exclusion

The frozen action is
`frozen_action_ast_p1_a10/M08_ELIMINATED_ACTION_AST_V1.json`, canonical action
SHA-256 `36abb0301627acf272a2904da3968781368b1d1d10a7115f7408e1767e20aa2b`.
Its derivative nodes in the scalar sector are ordinary partial derivatives.
The [Phase C result](PHASE_C_SCALAR_ACTION_RESULT.md) and separately saved
`frozen_phase_c_scalar_action/primary.json` and `replay.json` screen all 36
terms, with connection variation performed before zero-connection projection.

For `X=Phi.offdiag.0.1`, `Y=Phi.offdiag.0.4`, `k=i*g10/sqrt(2)`, the selected
restriction has

\[
\delta L=k(\partial_\mu C^4)(Y\partial^\mu X-X\partial^\mu Y),\qquad
E_{C^4}(\delta L)=k(X\Box Y-Y\Box X)\ne0.
\]

The nonzero Euler derivative excludes an ordinary local total derivative;
no equations of motion are imposed. Pure gauge, derivative-free potential,
separate scalar representations, and the literal gauge-fixing/ghost sectors
cannot provide this selected scalar/ghost-jet channel. The old scan's absent
linear connection term control cancels it when explicitly supplied in the
control calculation. That control did not edit A10.

## Declared candidate and independently checked construction

`frozen_a10_physical_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_CANDIDATE_V1.json`
is an inactive factorized mathematical specification, with exact matrices
bound in `full_primary.json` and separately reproduced in `full_replay.json`.
It has four canonical scalar representations of dimensions 54, 252, 20, 2
and 45 normalized real plane generators. The S sector is a Spin(10) singlet.

\[
D_\mu x=\partial_\mu x+g_{10}\rho(B_\mu)x,\quad
\delta x=-g_{10}\rho(\omega)x,\quad
\delta B_\mu=\partial_\mu\omega+g_{10}[B_\mu,\omega].
\]

The frozen charge normalization fixes the connection coefficient in D. Local
covariance fixes the scalar orientation and hence the expanded scalar kinetic
coefficients `g10` and `g10**2/2`. They are derived before the selected Phi
cancellation is considered. The original potential terms and parameters are
copied literally. The gauge term uses the canonical real-plane trace metric;
the C3 frame map, its bilinear metric and reality condition are explicit.

The direct 54-component Phi control includes a nonzero H4 connection in four
Minkowski directions. Exterior-jet and independent physical-tensor/word routes
agree on all 680 density coefficients and reproduce all 800 historical
variation/Euler coefficients. Candidate density variation is exactly zero.

The full physical checks are factorized identities for arbitrary fields,
connections, local parameters and parameter jets. Each representation preserves
its canonical metric and intertwines its physical embedding. All 990 generator
pairs are checked in each sector. Together these identities give
`delta(Dx)=-g*rho(omega)Dx`; the remaining scalar density variation is zero by
skewness. Curvature transforms by commutation, and its invariant trace is
unchanged. Every potential contraction pairs tensor slots, so their skew
generator insertions cancel. This proves the declared classical physical
identity without a high-jet truncation or an expanded vertex catalog.

## Shift, background split and dependency questions

The actual N5-N8 VEV and orbit `O_a=rho(T_a)v` are independently reconstructed.
Candidate vector mass is `g10**2 O.T O`. Scalar–vector mixing, after explicit
IBP, is `-g10 eta.T O partial.B`. An ordinary quadratic R_xi diagnostic
`F=P_m partial.B-xi*g10 O.T eta` cancels that mixing because `O P_m=O`.
It gives `xi*g10**2 O O.T` for the GF Goldstone pairing. This is a diagnostic,
not qualification of historical partial gauge fixing or ghost/source rules.

Quantum transformations leave the external background and numerical v inert
and act affinely on eta through v+eta. Background transformations act affinely
on Abar and homogeneously on q. For scalars, either v transforms as a background
spurion with its derivative retained until variation, or inert v induces an
affine eta transformation. Prematurely setting `partial v=0` in the spurion
variation misses `partial(delta v)`. Both correct conventions produce the same
total-field physical identity, but neither silently selects a historical
source/gauge-fixing convention.

For the actual M08 carrier, q means `V_H+q_L` and Abar_H is H-valued. Only an
H-valued parameter acts as its background gauge symmetry. The scope certificate
checks H closure, H preservation of the heavy complement and vanishing H orbit
of the frozen VEV. The generic full-parent background identity does not
authorize enlarging this carrier or adopting new source/background rules.

Remaining questions are the candidate's translation into an independently
qualified executable local AST; the complete source and gauge-fermion
construction; partial-coset, domain and catalog descent; and downstream
physical/quantum interpretation. The [scope correction](A10_PHYSICAL_ACTION_SCOPE_CORRECTION_V1.md)
classifies prior results by these dependencies.

## Primary literature comparator and limits

[Barnich, Brandt and Henneaux, sections 2.2 and 4.3–4.4](https://arxiv.org/pdf/hep-th/0002245)
describe Yang–Mills matter/connection transformations and the local Euler
criterion for total derivatives. These support the methodology; they do not
validate this repository. Their conventions must be translated explicitly.

[Gomis, Paris and Samuel, sections 6 and 7.2](https://arxiv.org/pdf/hep-th/9412228)
treat antifields, nonminimal variables and gauge fixing. Physical invariance
and gauge-fixed BRST consistency are distinct obligations; the paper does not
resolve M08's partial-gauge/source conventions.

The two implementations have independent algorithms and code paths, but share
Python/SymPy, physical data, assumptions and analyst. External scrutiny and
blind/library/runtime-independent review are not claimed. Personal outreach
is not a project prerequisite under the owner's current policy.

Reproduce only this bounded package with the pole-blind guard:

```powershell
$env:PYTHONPATH=(Resolve-Path tools/pole_blind_validation_guard).Path
$env:PYTHONDONTWRITEBYTECODE='1'
python -B tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/audit_a10_physical_reconciliation.py --fresh-new-only
```

It authenticates the old failure and completed mixed controls, regenerates
only new candidate evidence under write denial, and changes no scientific
authority. The full validation receipt separately records unresolved custody.
