# Inactive E3 quantum/background technical review

This packet implements the solo review policy. It is an internal reproducibility and objection packet, with no recruitment, contact channel, outreach requirement or external endorsement. The scientific disposition and measured coverage belong to `A10_E3_SYMMETRY_RESULT.md` and `frozen_a10_e3_symmetry/validation_receipt.json`; this packet does not independently certify them.

## Bound inputs and questions

Use the eleven sealed predecessor chains, the complete E2 action, the E1 replacement, the source-left bracket and the negative E2 flow. All 643 pairs, 1,286 canonical generators, 508 physical Euler programs and 48 external backgrounds retain their existing meanings. The gauge/scalar action excludes fermions and Yukawa interactions. Historical A4-V2/A5-V2 equivalence remains unproved.

1. Does the actual 12-H action, reconstructed from physical matrices, agree with the parent-frame action on all canonical coordinates and evaluation-dual sources?
2. Is every transported source correction the independently derived Euler covector of the appropriate fermion Ward variation, with its parity sign and derivative kernels?
3. Does the complete background identity hold with the external background varied, while the geometric quantum identity retains the actual light gauge-fixing breaking?
4. Are BRST compatibility and the mixed local H algebra established on sources and parameter jets, rather than only physical fields and constant parameters?
5. Are the physical Euler covariance assumptions sufficiently explicit, authenticated and challenged by a distinct direct physical calculation?

## Three operators with different meanings

Write B=Abar_H+q and keep Q Abar=0. Geometric Tq and Tb have the same canonical field columns: T B=partial omega+g[B,omega], T x=-g rho(omega)x, with the qualified primal/dual H actions on ghosts and nonminimal fields. They differ externally: Tq Abar=0; Tb Abar=partial omega+g[Abar,omega]. The internal heavy invariant bilinear is not the canonical source evaluation pairing.

The source lift is -M^T J. Independently generate it using the odd local Hamiltonian H_T=-sum_z(-1)^p_z Jz Tz and the declared BV bracket. The affine connection transformation has a field-independent local parameter derivative; its field Jacobian M has no field jets. Both routes must include all zero slots.

With A_J=-(-1)^p_z Euler_left,z(Psi), the transported operators obey

    Tq'=U Tq U^-1, Tb'=U Tb U^-1,
    D_J=-M^T A_J-T A_J=(-1)^p_z Euler_left,z(T Psi).

The full external action in T A_J is essential. Tb Psi=0 implies Tb'=Tb. Tq Psi=W_Psi is generally nonzero because the complete fermion fixes the light quantum freedom. Tq' adds source corrections and must not be identified with geometric Tq. Its symmetry of the retained-source BV action does not imply geometric quantum invariance after source restriction.

## Local-functional and physical proofs

The E2 action density is S'=S0+S1+Delta, with Delta=Q Psi+div L. Fresh source-polynomial calculations must establish

    Tb S'=0,
    Tq S'=Q' W_Psi+div(Tq L),
    Tq' S'=div(Tq L+Theta_W),
    Theta_W^mu=sum_z Rz partial_left W_Psi/partial(z_mu).

Currents must be computed before any functional boundary identification. Compact support of local parameters or vanishing integrated displayed currents is the stated functional assumption. Euler derivatives adjudicate any claimed total derivative. No equations of motion, auxiliary elimination or premature zero-field projection are permitted.

The physical action is unchanged and has no Abar dependence. Its all-45 local Ward/Noether qualifications restrict to H. To derive physical Euler covariance, differentiate the functional identity under T z=a(omega,jets)+M(omega)z. The inhomogeneous term has zero field derivative. M depends on the local parameter but has no field jets. Varying the identity with arbitrary independent field variations gives

    T E_I+sum_J M^J_I E_J=0.

Thus the existing physical contribution Q J_I=+E_I obeys [Q,T]J_I=0 with evaluation-cotangent sources. This is a general affine-cotangent proof using the qualified scalar and free-Lorentz Euler programs, not a freshly expanded list of every physical monomial. U leaves these programs unchanged because they are source free. The full physical 20-pair exterior calculation separately challenges this proof and its signs.

The complete source-polynomial checks must distinguish

    [Q',Tb]=0, [Q',Tq']=0,
    [Q',Tq]=-X_(Tq S').

For the last identity, field columns vanish and source columns are -Euler_left,z(Tq S'). The local H Lie and mixed brackets use two independent even parameters beta and omega and bracket parameter g[beta,omega]_H. Ordinary symmetric prolongation covers admitted jets; resource limits must raise. The composite R_H remains a ghost polynomial, not an independent coordinate. Its H covariance does not establish E4 equivariant or quartic-ghost interpretation, or the E5 domain.

## Adversarial review

The simplest light-channel diagnostic is Tq S'=-2 b0 Box omega0 plus other channels. Its Euler derivative in b0 is -2 Box omega0. The corresponding geometric [Q',Tq]Jb0 is +2 Box omega0, and the required Tq'Jbar0 correction is -2 Box omega0. A constant-parameter test hides this diagnostic. Do not misclassify the expected breaking as a new physical-action failure.

Hold the external background fixed incorrectly and require a nonzero Ward/source residual. Reverse the source transpose sign and require a failed canonical evaluation pairing. Remove the transported source correction and require the expected source commutator defect. Reject invented 45-generator backgrounds, changed source coefficients, false activation, E4/E5 qualification, quantum master claims and authority promotion. Historical missing-connection, five-form, free-Lorentz and bare-heavy-pairing witnesses remain available as sealed negative controls.

The smaller exterior replay has a closed three-plane algebra, one H generator, five scalar coordinates, nonzero R_H and all 20 physical/source pairs. It varies the full physical action directly. Its coset is a diagnostic, not the full nonsymmetric Spin(10)/H calculation. Agreement in that control alone is insufficient; the actual full-size source and Ward identities remain required.

## Literature and limits

Quantum gauge transformations with a fixed background and background transformations that act on the external connection obey distinct Ward requirements. Partially fixed background-field constructions retain residual background covariance while gauge fixing the quantum residual freedom; see [Thomsen, Sections 2.3 and 3.3](https://arxiv.org/html/2404.11640v2). This supplies a comparison framework, not a qualification of a quantum effective action here.

H invariance of the heavy partial-gauge fermion, equivariant structure and quartic interactions belong to the broader partial-gauge construction; see [Ferrari, Sections 3 and 4](https://arxiv.org/html/1308.6802v3). E3 preserves the composite structures needed for that future review without performing E4 or E5. Classical functional BV transport follows the field-antifield framework described by [Gomis, Paris and Samuel](https://arxiv.org/abs/hep-th/9412228).

The primary and replay use distinct H geometry and variational routes, but share inputs, conventions, exact word arithmetic, Python/SymPy and analyst. The exterior route changes polynomial storage and direct variational arithmetic but shares assumptions and software. No outside person verifies this work. The unchanged formal ledger is 34/39. Historical custody remains exit 2 with seven unresolved references. A bounded E3 pass permits a separately scoped E4 decision only; it does not qualify an H-basic counterterm domain, source activation, HB1/C5, catalog replacement, quantum matching, anomalies, physical gauge independence or the Spin(10) phenomenology.
