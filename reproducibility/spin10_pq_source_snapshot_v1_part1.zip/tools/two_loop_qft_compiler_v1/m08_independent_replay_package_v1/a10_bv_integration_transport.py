"""Full-parent heavy cotangent shift; the other 532 pairs are identities."""
from itertools import combinations_with_replacement
import sympy as s
from source_convention_control import Exterior
from a10_bv_integration_common import *

def build(stage=lambda n,f:f()):
    data,columns=source_data();f={tuple(r[:3]):coefficient(r[3]) for r in data['geometry']['f']}
    a=Exterior();fields={**{f'C{i}':1 for i in IDS},**{f'ub{i}':1 for i in M},**{f'L{i}':0 for i in M}}
    pairs=[(z,'J'+z) for z in fields]
    x={n:a.variable(n,p) for n,p in (fields|{J:1-fields[z] for z,J in pairs}).items()}
    U=dict(x)
    for i in M:
        shift=a.add(*(a.scale(a.mul(x[f'C{h}'],x[f'ub{j}']),g*v)
            for (j,h,k),v in f.items() if j in M and h in H and k==i))
        U[f'L{i}']=a.add(x[f'L{i}'],a.scale(shift,-1))
        U[f'Jub{i}']=a.add(x[f'Jub{i}'],*(a.scale(a.mul(x[f'JL{j}'],x[f'C{h}']),-g*v)
            for (k,h,j),v in f.items() if k==i and h in H and j in M))
    for h in H:
        U[f'JC{h}']=a.add(x[f'JC{h}'],*(a.scale(a.mul(x[f'JL{i}'],x[f'ub{j}']),g*v)
            for (j,k,i),v in f.items() if j in M and k==h and i in M))
    def support(P):
        return {n for word in P for n in word}|{str(v) for c in P.values() for v in c.free_symbols if str(v) in x}
    def bracket(F,G):
        sf,sg=support(F),support(G);out=[]
        for z,J in pairs:
            if z in sf and J in sg:out.append(a.scale(a.mul(a.partial(F,z,'right'),a.partial(G,J)),(-1)**fields[z]))
            if J in sf and z in sg:out.append(a.scale(a.mul(a.partial(F,J,'right'),a.partial(G,z)),-(-1)**fields[z]))
        return a.add(*out)
    def canonical_rows(P):
        out={}
        for word,c in P.items():
            even=sorted((v for v in c.free_symbols if str(v) in x),key=str)
            terms=s.Poly(c,*even).terms() if even else [((),c)]
            sign=(-1)**sum(u>v for i,u in enumerate(word) for v in word[i+1:])
            for powers,k in terms:
                key=tuple(sorted(list(word)+[str(v) for v,p in zip(even,powers) for _ in range(p)]))
                out[key]=out.get(key,0)+sign*k
        return [{'word':list(word),'coefficient':str(clean(c))} for word,c in sorted(out.items()) if clean(c)]
    def replace(P,table):
        terms=[]
        for row in canonical_rows(P):
            terms.append(a.scale(a.mul(*(table[n] for n in row['word'])),coefficient(row['coefficient'])))
        return a.add(*terms)
    for z in fields:
        for y in fields:
            target={():s.Integer((-1)**fields[z])} if z==y else {}
            assert not a.add(bracket(U[z],U['J'+y]),a.scale(target,-1)),('COTANGENT_PAIR',z,y)
    for (_,J),(_,K) in combinations_with_replacement(pairs,2):
        assert not bracket(U[J],U[K]),('COTANGENT_SOURCE_CROSS',J,K)
    inverse={n:{word:s.expand(c.subs(g,-g)) for word,c in P.items()} for n,P in U.items()}
    for n in x:
        assert not a.add(replace(U[n],inverse),a.scale(x[n],-1)),('INVERSE',n)
        assert not a.add(replace(inverse[n],U),a.scale(x[n],-1)),('FORWARD',n)
    qc={f'C{k}':a.add(*(a.scale(a.mul(x[f'C{b}'],x[f'C{c}']),-g*v)
        for (i,b,c),v in f.items() if i==k and b<c)) for k in IDS}
    oldS=a.add(*(a.mul(x['J'+n],P) for n,P in qc.items()),
        *(a.scale(a.mul(x[f'Jub{i}'],x[f'L{i}']),-1) for i in M))
    transformed=replace(oldS,U)
    expected=[]
    for n in fields:
        for row in rows(columns[n]):
            expected.append(a.scale(a.mul(x['J'+n],*(x[v] for v in row['word'])),coefficient(row['coefficient'])))
    assert not a.add(transformed,a.scale(a.add(*expected),-1)),'FULL_HEAVY_GHOST_ACTION_TRANSPORT'
    return {'schema':'A10_FULL_PARENT_HEAVY_COTANGENT_TRANSPORT_V1','status':'PASS_CANONICAL_INACTIVE_TRANSPORT',
        'nontrivial_block_pairs':111,'identity_spectator_pairs':532,
        'field_source_pair_checks':len(pairs)**2,'source_cross_checks':len(pairs)*(len(pairs)+1)//2,
        'inverse_checks':2*len(x),'old_coordinates_in_new':{n:canonical_rows(P) for n,P in U.items()},
        'transported_ghost_heavy_action':canonical_rows(transformed),
        'transport_matches_saved_source_columns':True,'full_nonsymmetric_parent_algebra_retained':True,
        'composite_R_H_not_independent':True,'physical_S0_unchanged':'map acts on C,ub,L and their sources only; S0 independent of these',
        'light_nonminimal_spectator':True,'gauge_fixing_transport_done':False,'Stage_E_reached':False}
