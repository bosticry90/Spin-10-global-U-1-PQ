# Cubic primitive recovery and prerequisite calculation, V1

Prospective execution contract, baseline f7f605443062b76f38ca3569ba2fe38e66d80d26.
The two interrupted V1 drafts remain byte unchanged. The enclosing scientific
contract is A10_E5_CUBIC_PRIMITIVE_CONTRACT_V1.md; this prerequisite checkpoint
does not replace or reduce its four-ghost or quantum acceptance obligations.

Question CP-P1: does the complete sealed actual-minus-joint tensor D admit the
declared real, local, H-invariant odd dimension-three/ghost-number-minus-one
two-heavy-antighost/one-ghost primitive? Question CP-P2: what is the complete
inactive canonical image of K0+Kjoint+K3 and its predicted quartic coefficient?

Inputs are the authenticated 30-parent chain terminating in
frozen_a10_e5_auxiliary_vertex/bindings.json, both own-route sealed measurement
records, physical charts, E1 real structures, E2 complete BRST columns, E3
background H operators, the old width subtraction and the joint candidate.
The preparation record freezes their bytes, interrupted drafts, current state
and all new executable/contract bytes before running either route. Full 643
pairs, 48 backgrounds, nonsymmetric coset, parameters and actions stay fixed.

In common hbar/(32*pi^2*epsilon) pole units, Delta=g*xi^2 D Lambda ubar C.
Q0 ubar=-Lambda. Primary constructs K3=-g*xi^2 sum(a<b) D_ab,c ubar_a ubar_b C_c.
Replay uses the Euler contraction K3=-1/2 sum_a ubar_a Euler_Lambda_a(Delta).
Each route reads only its own sealed cubic tensor. The measured loop is reused
as qualified input, not recalculated. All 49,005 entries including zeros are
checked for antisymmetry and the right-section identity. Sector uniqueness
follows from injectivity of Q0 on the no-source/no-jet wedge^2(ubar)*C sector;
broader closed-generator ambiguity remains open.

Use dual heavy maps for ubar/Lambda and primal maps for C. Prove chart
roundtrips and the qualified conjugation rule; check all 12 local H actions.
No jets in K3 means parameter derivatives cannot occur. A failed real, grade,
H or right-section identity stops before the complete canonical image.

K0 is the NEGATIVE of the sealed old subtraction primitive, multiplied by
xi^2: it is a pole generator, not the counterterm. Compare Q0 K0 to the sealed
width pole density. Retain complete nonlinear Q Lambda, including g^2 R_H.
Kjoint is reused byte authenticated. Calculate full Q(K0+Kjoint+K3), all
canonical columns and an independent direct variation of the source/gauge
fixing density. Retain the qualified joint current and prove no new current
is needed for source-free primitives with undifferentiated source shifts.
New terms have only dimensionless coefficient data and their image word
grade is (4,0,0). Imported OrbitPullback coefficients retain their qualified
mass dimension one after numerical evaluation: inherited E1/E2 typed AST
obligations are reused, not replaced by a field-only word-grade test.

Check nonlinear source shifts and their first/second ordinary jet product
rules; arbitrary-order prolongation is the derivation rule, with unsupported
computational orders raising rather than truncating. Source-free generators
change only external sources; the joint field Berezinian is unchanged, with
its regulated background trace retained. Compare previously matched source,
kinetic, mixing and width projections and the full measured cubic. Extract
the candidate g^2*xi^2 four-ghost prediction over all 990^2 physical odd-pair
slots, with sparse exact zeros and an explicit full-domain statement.

Primary uses prefix Leibniz Q variation and left Euler derivatives; replay
uses jet-gradient chain rule and the direct source substitution. Shared word
arithmetic, immutable data, Python/SymPy and analyst are disclosed. These are
different bounded calculations, not external verification. Negative controls
reverse Q0/primitive signs, omit K3/K0/R_H, and omit nonlinear jet cross terms.
They must produce explicit nonzero residuals; a control that is zero is not
counted as a successful discrimination.

Completion of this checkpoint requires both routes, fresh own-byte replay,
exact comparison, meaningful negative controls, protected/state hashes and
metadata plus delegated custody check (expected exit 2/seven unresolved).
Failures and unfinished attempts are preserved without overwrite. Resource
boundaries may leave this prerequisite unfinished; they never qualify partial
coefficients or the enclosing contract. Validate before any local commit.

Authority ceiling: a qualified inactive primitive and frozen quartic
PREDICTION only. No actual quartet loops, equality with actual quartet poles,
full E5/A5/restoration, activation, HB1/C5/C1_GS, matching, physical changes,
authority promotion, outreach, publication or remote push. State v113/34of39
and the whole Spin(10) x global U(1)PQ goal remain active/incomplete. The next
dependent action is the complete literal graph inventory and independent
actual quartet calculation required by the enclosing contract.
