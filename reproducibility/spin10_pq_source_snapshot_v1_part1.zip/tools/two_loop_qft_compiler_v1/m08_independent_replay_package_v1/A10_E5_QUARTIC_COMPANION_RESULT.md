# Complete actual quartet and normalization failure

Scientific disposition: STOP_E5_INACTIVE_NORMALIZATION_MISSES_ACTUAL_QUARTIC.
Baseline1e81980, statev113/34of39 unchanged,31 authenticated predecessor chains.
The validation receipt and byte seal own qualification of this bounded result.
The whole Spin(10) x global U(1)PQ investigation remains active/incomplete.

The independently calculated actual g^2*xi^2 four-ghost pole disagrees with
the frozen K0+Kjoint+K3 prediction in5,528 of980,100 independent physical
odd-pair slots. The actual tensor has6,576 nonzero coefficients; the prediction
has4,944. Light-direction slots vanish by literal vertex/reference-edge and
UV-degree arguments, with all45 directions retained in the operators and
comparison. Their absence was not inferred from the prediction.

At real antighost pair(12,13) and ghost pair(12,13), in common
hbar*g^2*xi^2/(32*pi^2*epsilon) units,

    actual       =  16/25,
    candidate    = -16/25,
    difference   =  32/25,
    Delta density = (32/25) a12 a13 C12 C13,
    Euler_left,a12(Delta) = (32/25) a13 C12 C13 != 0.

Independent left differentiation and ordered-word deletion agree. This is a
real off-shell discrepancy and not a pure total derivative. No general EOM
equivalence or complete quantum inconsistency is inferred from this witness.
The complete residual is preserved, including all zero channels.

The preceding H-compatible primitive remains qualified in its declared
no-source/no-jet sector. Its Q0 right section, canonical first variation,
real structure, local H invariance and repaired cubic projection are preserved.
The previously matched source, ghost kinetic, mixing and width projections
retain their qualifications. The tested complete inactive normalization is
insufficient in its quartic companion; no generator is adopted.

## Literal coverage and distinct calculations

For a connected one-loop1PI four-point graph, sum(degree-2)=4 and every
vertex has at least two internal incidences. With maximum literal degree4,
the possibilities are four cubics, two cubics/one quartic, or two quartics.
Each vertex attains its maximum external incidence. Physical bosonic vertices
cannot supply the required odd external legs. Dimensionful mass/orbit and
quadratic insertions lower the homogeneous UV degree, with no inverse
physical parameter in the reference UV expansion. Their finite effects are
not assigned zero by this argument.

The literal quartic inventory is648 atg*xi,17,480 atg^2 and418 atg^2*xi.
All are recorded and screened. The retained ordinary g^2 B^2-antighost-C
vertex has1,540 raw coefficients per Lorentz copy with both heavy B legs.
Both legs join heavy auxiliaries from xi vertices; H or scalar alternatives
have zero required reference edges. The complete derivative-placement
integration-by-parts current and four Lorentz copies are checked before
extracting the leading UV operator. A differentiated external antighost
lowers UV degree. All anomalous CC/aa and mixed odd quartic blocks survive.

| Graph family | Complete nonzero physical pole slots |
| --- | ---: |
| Four-cubic boxes | 0 |
| g*xi quartic/g/xi triangles | 5,908 |
| Ordinary g^2 B^2-ghost/two-xi triangles | 7,170 |
| Two g*xi quartic bubbles | 3,960 |
| Sum, with overlaps and cancellations | 6,576 |

Primary evaluates all six box shuffle words, all six mixed triangle words,
all three ordinary-quartic triangle words and the full graded bubble trace.
Replay reconstructs normalized physical10 commutators, H/heavy projectors
and vertices, compares them to its own literal action, then expands the full
even/odd Gaussian determinant. Neither route reads the candidate tensor
while calculating the actual pole. Completed family tensors agree before
the frozen candidate is opened.

The full reference retains arbitrary H/heavy widths, BB, BL/LB, LL=0 and
both odd inverse orientations. Generic four-Lorentz elementary Born/Gaussian
controls agree in every graph family and keep all quartic external splits.
Only after k_mu*k^mu=k^2 is proved are Lorentz copies reduced in group
contractions. No auxiliary is eliminated from the action and no projected
adjoint closure or symmetric-coset shortcut is used.

## Exact box cancellation and UV scope

The boxes were calculated. Their zero is independently reproduced and has
a structural explanation. The projected heavy tensor is an antisymmetric
three-form. The corresponding ghost/antighost-background matrices U,V are
odd and skew. Transpose gives Tr(UVUV)=Tr(VUVU); odd cyclicity gives the
negative of the same trace. Thus the selected box is zero. This needs no
projected-adjoint Jacobi identity. The generic box control is nonzero, so a
group zero is not a hardcoded omitted graph. Omitting the zero box is explicitly
nondiscriminating and not counted as a successful negative control.

UV Taylor is only above R_UV>0 and fixed external/mass scales. Momentum
remainders have negative UV degree. The homogeneous denominator is(k^2)^2
and the Minkowski residue is i/(16*pi^2). Original box/triangle/bubble heat
profiles retain8/6/4 in E1(profile*R_UV^2/Lambda^2); equal log residues do not
identify their finite pieces. No whole scaleless zero-momentum, complete finite
amplitude, physical IR limit or anomaly conclusion is made.

Exact rational multiquadratic/exterior arithmetic retains all coefficients,
with256 basis multiplication checks, reversible conversions and symbolic
reference widths. Closed trace contractions use associativity and verified
even-superoperator cyclicity; they avoid unneeded off-diagonal degree-four
products without reducing the tensor space. Gaussian rectangular factors
preserve their odd-coefficient order. Input-polynomial mutation controls pass.

## Recovery, validation and interpretation

Two unfinished engineering executions are preserved as cancellations. A
replay schema precheck incorrectly requested primary-only metadata; the
qualified Cinv H block supplies the same chart with both cross blocks checked.
The first completed replay used an odd prefix sign while differentiating an
even auxiliary. Its full tensor, source, route disagreement and failed
comparison are preserved and excluded from qualified evidence. Correct left
variation multiplies prefix parity by the varied field parity. Independent
Euler-symbol controls now check the affected mixed vertices before calculation.
The original and replacement primary result records remain byte identical.

The receipt owns targeted tests, fresh strict own-byte primary/replay runs,
all12 actual local H identities, independent Euler/Fourier and radial checks,
omission/mutation controls,31 parent chains and protected/new/state SHA plus
audit-time metadata. Old expensive predecessor calculations are authenticated,
not replayed. Custody remains exit2/seven unresolved references, never PASS.

Controls remove ordinary W, all g*xi quartics, anomalous quartic splits,
odd/Lorentz/Gram factors and old/new primitive contributions. Every counted
control has a nonzero exact residual. Source-free primitive additions retain
the prior joint regulated field Berezinian and cannot cancel it through
external sources. Canonical/real/H/jet/current prerequisites are reused with
their exact scope; matching other projections cannot rescue this mismatch.

Shared immutable inputs, word and exact coefficient arithmetic, Python3.10.11,
SymPy1.14 and analyst remain disclosed. This is solo computational review,
not external endorsement or proof-kernel certification. The classical physical
action and prior qualified evidence keep their declared scopes.

First-failure stop: do not run JC-C-C/JB-B-C or adopt/further fit a normalization
in this increment. Next smallest derivation is to classify which independently
justified allowed normalization types could carry the preserved residual while
keeping earlier matches, and derive their required companion identities before
any new loop. The full interacting Ward/source problem remains open.

No full E5/A5/contact/restoration, activation/catalog/HB1/C5/C1_GS/matching,
physical or authority change, outreach, publication or push. Global boundedness,
PQ quotient, fermion/Yukawa and phenomenology remain open. The bounded
normalization refutation is progress toward the original investigation.
