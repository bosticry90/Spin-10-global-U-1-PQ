# Inactive canonical BV Stage D integration result

Scientific gate: `QUALIFIED_INACTIVE_GAUGE_SCALAR_CANONICAL_BV_STAGE_D`.
Evidence audit: `PASS_BOUNDED_INACTIVE_STAGE_D_EVIDENCE_VALIDATION_ONLY`.
Authorization: the user assessment of local commit `7920561`.

The previously qualified physical action, scalar cotangent adapter, gauge Euler
adapter and source-only construction coexist in one classical canonical BV
candidate. The master functional vanishes under the declared boundary
conditions, and its Hamiltonian differential is nilpotent off shell on the
declared fields, sources and ordinary jets. This is an inactive gauge/scalar
Stage D result. It establishes neither the complete partial-gauge M08 system
nor quantum consistency or a phenomenological Spin(10) model.

## Recovery, reuse and construction

Execution began at clean local HEAD `7920561`, on `main`, with no surviving
Phase C Python calculation identified. Seven sealed dependency manifests were
authenticated. The expensive earlier representation and source assemblies were
reused; they were not restarted or treated as newly calculated results.
Frozen actions, helpers, source definitions, counterexamples and authority
records remain unchanged.

The new `M08_CANONICAL_BV_STAGE_D_INACTIVE_V2.json` preserves every one of the
43 predecessor action terms: 34 physical and nine source terms. Its parameters
and scalar potential are unchanged. The physical action covers the gauge
connection and all four scalar sectors, with no fermions or Yukawa terms.

The 643 canonical pairs comprise 180 gauge, 328 scalar, 45 ghost, 66 heavy
nonminimal and 24 light nonminimal pairs. Their 1,286 columns combine the
authenticated 106,097 source-only coefficients with 508 physical Euler
contributions. Gauge coordinates have lower Lorentz indices; evaluation
sources are their direct duals. Lorentz and internal source-chart conversions
remain explicit. They are not inserted as extra canonical pairing factors.

The physical columns are an exact contracted executable Euler program:
five typed gauge Euler ASTs, four scalar kinetic Euler ASTs, 29 ordered
potential derivative bundles and the qualified scalar pullback operation.
They are bound component by component. This investigation does not claim a
new fully expanded potential/interaction catalog. Gauge Euler applies only
to the approved even first-jet physical grammar; graded source terms use the
separately qualified left Euler calculus.

`a10_bv_integration_euler.canonical_physical_values` executes the final linear
composition on evaluations of those bound ASTs: `Q^T` for gauge covectors and
the actual `Adapter.pullback` for each ordered potential covector. It requires
all 29 directions and all four sectors; no Riesz/metric shortcut is substituted.

## Classical master equation by source degree

Write `S=S0+S1`, with `S1=sum J_z Qz` and the frozen source-left bracket.
The source-free physical part of the master density obeys the exact identity

`(S,S)_degree0 = 2 partial_mu(E_B_a^mu C^a) - 2 C^a N_a`.

Here `N_a` is the off-shell gauge Noether identity, not an equation of motion.
All 45 parent-frame coefficient identities are matched between the two routes.
Their vanishing uses the authenticated physical-action/adapter results:
45 expanded pure-gauge Noether components, 180 scalar invariant pairings and
29 potential Ward directions. The entire matter identity was not expanded
again from scratch. No physical Euler component is set to zero.

For source degree one the primary route directly multiplies the literal
Euler columns of `S1`. Its 5,316 surviving master-density coefficients equal
the divergence of a 1,772-coefficient current exactly:

`(S,S)_degree1 = 2 partial_mu(JB_a^mu QC^a)`.

The replay derives the same density and current by odd first variation of
the cotangent lift, after independently checking the field squares through a
jet-gradient chain rule. The density is nonzero; its functional is a boundary.
No higher source degree occurs because `S0` contains no sources and `S1` is
linear in sources. The complete current is therefore

`M^mu = 2 sum_a (E_B_a^mu C^a + JB_a^mu QC^a)`.

Compact support or boundary conditions annihilating this current are required.
The Euler derivative of a divergence vanishes identically. Integration by
parts is explicit, and no equations of motion or numerical tolerances enter.

## Off-shell nilpotence and its coverage

Both routes freshly reduce all 643 field squares to exact zero. Both
nonminimal sectors, the nonsymmetric coset coefficients and the composite
`R_H=-[u,u]_H/2` are retained. The scalar coordinates are total `x=v+eta`, with
fixed `v`; the quantum connection is total `B`, with a fixed H-only background.
This does not qualify a full 45-component affine background transformation.

All 643 physical/source cross identities are also checked coefficient by
coefficient in formal Euler notation. The 508 gauge/scalar source contributions
cancel using the actual Euler covector covariance. The 45 ghost-source
contributions are precisely the off-shell Noether identities; nonminimal
sources receive no physical Euler contribution. Euler symbols are notation
for the bound physical variational programs, not additional independent fields.

The primary derives Euler covariance by differentiating the Ward functional.
The replay derives it from the inverse-transpose Jacobian of a finite fixed
gauge transformation. This distinguishes covectors from metric-dependent
vectors and preserves the free Lorentz output slot.

For all 1,286 generators, source nilpotence follows from graded Jacobi,
`Q^2 F=1/2 ((S,S),F)`, and the explicit master divergence. All ordinary jets
follow by prolongation, `Q^2 partial_I z=partial_I Q^2 z`. There are 68 fresh
field/source prolongation controls covering four directions. The computational
jet cap raises an error and never returns a zero relation.

**This is a structural all-source/all-jet proof, not a fresh brute-force
expansion of every source square.** An exploratory source-square expansion
was stopped after the exact master certificate supplied the general proof;
only that specifically identified task process was stopped. Its incomplete
output is recorded in `execution_notes.json` and is not counted as a PASS.

## Canonical heavy compatibility and independent controls

The full 111-pair ghost/heavy block now passes 12,321 field/source pair checks,
6,216 source cross-pair checks and 444 two-way inverse checks. The other 532
pairs are identity spectators. Transport of the complete parent ghost/heavy
source action reproduces the saved candidate transformations exactly,
including composite curvature and nonsymmetric coset terms. `S0` is unchanged
because it contains none of the coordinates shifted by this map. This is
canonical action transport; partial-gauge fixing transport is not performed.

A separate exterior-ring implementation differentiates a closed physical
three-plane Spin(10) control with five symmetric-traceless scalar coordinates,
20 canonical pairs and the restricted existing potential. All 40 generator
squares, 80 first-jet squares and its full master-boundary identity pass.
This is a diagnostic, not an all-45 substitute. Replacing its Abelian spatial
Euler sign by the historical wrong sign produces the exact local obstruction

`Q^2 JC = 2 partial_0 partial_1(partial_0 B_1-partial_1 B_0)`.

Tests also reject omission of the composite heavy curvature and omission of
the cotangent ghost-source correction. Historical A10, factorial and Lorentz
counterexamples remain sealed and unchanged.

The curvature-omission witness uses the transforming heavy coordinate `ubar13`.
The initial diagnostic choice `ubar12` is an H singlet with `QLambda12=0`,
so it cannot test that omission. Correcting that test selection changed no
candidate coefficient, source definition or scientific identity.

## Validation, preserved authority and limitations

The receipt records 108 targeted regressions: 16 new and 92 inherited. Three
new read-only routes regenerate byte-identically. The seven historical
manifest chains and project-state bytes are authenticated; audit-time
workspace/active-data size and modification-time inventory changes are absent.
The inventory is not an all-byte audit of the entire workspace.

The primary and replay share physical assumptions, Python/SymPy, some exact
word arithmetic, immutable inputs and the same analyst. Their new field
differentiation and Euler-covariance derivations differ, and the smaller
physical/source control uses exterior-ring arithmetic. None constitutes
external endorsement. The solo-review policy applies, with published
literature and reproducible objections; no personnel outreach is planned.

The historical S6/S7 gauge outputs retain the limits established by 7920561.
They are not reused as canonical physical Euler columns. Representation,
potential, source-frame and prior bounded canonical evidence retain their
original scope. No Higgs benchmark, vector spectrum or quantum observable is
recalculated here.

Formal authority remains **34/39**. Historical custody remains strict **exit 2**
with **seven unresolved references**, not PASS. Frozen M08 definitions,
activation state, catalogs and physical parameters are unchanged. HB1/C5
remain blocked; finite `C1_GS` remains uncalculated. Nothing is pushed remotely.

## Next decision

The inactive gauge/scalar canonical BV candidate passes bounded Stage D.
The next separately authorized investigation may address Stage E: complete
partial-gauge quantum/background distinctions, composite chain rules under
gauge-fixing transport and joint H-basic domain preservation. No Stage E
calculation or downstream promotion is authorized by this receipt. Full
interacting M08 remains unqualified until those obligations are resolved.
