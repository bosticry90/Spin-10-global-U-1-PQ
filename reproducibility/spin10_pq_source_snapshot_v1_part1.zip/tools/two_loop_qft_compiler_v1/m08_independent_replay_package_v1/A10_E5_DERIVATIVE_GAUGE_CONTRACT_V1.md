# E5 actual derivative-gauge companion, V1 prospective contract

Baseline25bb6b76dd4046a760bfa455dc2ba36973c98557; sole authority
project_state.json v113,34/39. Input frozen_a10_e5_auxiliary_admissibility/
bindings.json and37 predecessor chains. Previous turn is PROGRESS: additional
source-free K4 repaired the complete g^2 auxiliary pole while preserving prior
matches. Its g^3 quartet is still a prediction; no subtraction or quantum A5
was adopted. Whole Spin(10) x global U(1)PQ objective remains active/incomplete.

DG1 asks whether the actual next derivative-gauge pole matches that complete
inactive member. DG2 checks its complete momentum/sector/frame/coupling scope.
Calculate the full g^2 xi one-loop derivative B-a-C UV residue, retaining
arbitrary H/M reference widths until all diagrams combine; therefore include
any g^2 xi^2 or g^2 xi eta_H terms from reference inverses. Cover45 gauge,
45 antighost,45 ghost directions and TWO independent derivative placements:
(partial a) B C and a B(partial C), totaling182,250 scalar tensor slots.
All four Lorentz components and every zero channel remain. Include a separate
necessary proof of the lower g xi^2 contribution, not a candidate-based zero.
Inventory other coupling families explicitly; ordinary g^3 amplitudes and the
g^3 quartet are not included here and do not silently count as calculated.

## Inputs, types, dependency order and ceiling

Grades B(1,0,even),a(1,-1,odd),C(1,1,odd),one ordinary jet give(4,0,even).
All643 canonical pairs,48 external H backgrounds, source action, gauge fermion,
physical action/potential/vacuum/parameters/regulator/catalog are retained.
Auxiliaries integrated, sources external. No field elimination, inverse
physical coupling/mass, EOM quotient or projected M-adjoint Jacobi assumption.
Qualified real orthonormal charts use dual heavy antighost/auxiliary and primal
gauge/ghost carriers, with separate source evaluation pairings.

Freeze code/contract/input/state and execution ownership before computation.
Qualify universal graph/sign/momentum/Lorentz/UV controls BEFORE group tensors.
Actual primary/replay read only immutable action/source/gauge-fixing/group data,
not any candidate pole, normalization coefficient or actual peer output.
Compare completed actual outputs before dependent candidate comparison.
Workers guarded read-only, exclusive outer exports, no agents/duplicates/
overwrite. Preserve exact failed/unfinished source/start/output classifications.

## Literal graph and momentum obligations

A proper one-loop three-point graph has three cubic vertices or one cubic
and one quartic. Atg^2 xi include:
1. Two g derivative-ghost vertices plus xi auxiliary vertex, both external
   antighost/ghost assignments and every derivative placement.
2. Nonlinear g auxiliary-gauge vertex, g derivative-ghost and xi auxiliary,
   including H external gauge and both assignments; prove other sector zeros
   only after full reference-edge screening.
3. Physical Yang–Mills cubic, g derivative-ghost and xi auxiliary, including
   BOTH transverse and longitudinal BB pieces, every H/M internal gauge
   sector, all Lorentz components and external momentum placements.
4. g xi four-ghost vertex with g external-gauge ghost vertex; all ordered odd
   splits and derivative placements. Retain its derivative-on-B current.
5. Ordinary g^2 two-gauge/ghost quartet with xi auxiliary, every eligible
   external gauge leg and antighost/ghost assignment. Do not reuse a previous
   quartet-edge exclusion that fails for this amplitude.

Recover the complete literal cubic/quartic/source/physical inventory, including
the curvature g^2 xi quartet, scalar/orbit/mass, external-A and other gauge
vertices. Give dimensional/edge/1PI proofs for excluded channels in THIS
dimension-zero coefficient. No auxiliary self edge: LL=0; full BB,BL/LB and
both odd inverse orientations remain. At lower g xi^2 the ghost/auxiliary-
gauge triangles have a zero LL edge, while Yang–Mills with two mixed edges
has a double-longitudinal contraction of order external momentum squared;
derive that identity from the full vertex before excluding a linear residue.

Keep literal derivative-on-a/B/C vertices and complete IBP currents. Momentum
conservation q_B=-p_a-p_C leaves two independent vector coefficients. One
external polarization and collinear formal p_a,p_C determine them only after
proving Lorentz covariance and checking all four polarizations. No collinear
zero may be imported as a general tensor identity without that proof.

Primary uses signed Fourier Hessians and all Born words; replay uses ordered
Gaussian/Wick contractions with independently routed edge momenta and explicit
external odd ordering. Derive physical10 replay tensors separately from
literal primary tensors. Qualify unit group-operator conversions, including
quartic odd Hessian signs, before actual group contraction. Disclose shared
inputs, exact arithmetic, Python/SymPy and analyst, not independent scientists.

UV Taylor retains exactly the linear external momentum polynomial above
k_E^2>R_UV^2>0 above external/mass scales. Odd leading angular moments vanish
on this UV domain, not by a whole scaleless integral. Higher momentum/mass
remainders have negative UV degree. Prove Taylor terms of the heat factors
change finite/power terms but not this logarithmic coefficient. Keep triangle/
bubble profiles6/4 and derive i/(16pi^2epsilon), tensor moments atd=4 for the
pole (O(epsilon) corrections affect finite terms). No finite/IR amplitude.

Negative controls must detect omitted transverse BB, wrong odd order/sign,
missing assignments/quartic classes/current, single-momentum reduction,
wrong real/dual/primal map and whole-scaleless or quantum-restoration inference.
Each counted numeric control needs a nonzero exact residual. Width and Taylor
powers have no arbitrary cutoff; first-order momentum projection is exact
for the specified residue and never truncates group/tensor evidence.

## Dependent comparison and validation

After full actual agreement: reality/frame roundtrips, all homogeneous12 H
tensor covariance identities, and all182,250 coefficient/coupling comparisons.
Full local H jet Ward identities require partner amplitudes; do not claim
them from this isolated tensor. Extract the complete inactive candidate's
derivative-on-a/B/C projection, reduce with its full IBP current, then compare
both independent derivative coefficients. K4 gives zero new derivative image,
but check the complete current/candidate rather than assuming another piece
is zero. On first mismatch preserve full difference and independently signed
real Euler/Fourier witness excluding a pure boundary (not EOM/anomaly).
Stop before new fitting, higher quartet/g^3/other-source loops or adoption.

Validate scientific/process/governance checks, existing research_check.py e5,
all37 protected chains and new/state SHA/metadata, strict fresh own-byte
controls, actual-primary/replay and dependent comparison. Authenticate old
expensive loops/images without repeating them. Custody remains expectedexit2
with seven unresolved references, never PASS. Raw Git index/worktree bytes
must agree before local commit. A successful evidence audit may authenticate
a failed scientific gate; director acceptance/publication remain separate.

Possible dispositions: qualified selected actual derivative companion only;
exact stopped inactive candidate obstruction; underdefinition; necessary-gate
failure; incomplete execution. No physical/catalog/HB1/C5/C1_GS/matching,
authority promotion, quantum A5/fullE5/Ward/contact/IR/anomaly, outreach/push/
publication. Global scalar/PQ, fermion/Yukawa/phenomenology and original goal
remain unfinished. Local research conventions, epistemic ladder and solo-
review policy apply without external-personnel requirements.
