# Solo technical review: canonical gauge Euler conversion

The review target is a separately named, inactive even first-jet operation.
SOLO_REVIEW_POLICY_V1 supersedes personnel/outreach requirements. This packet
records technical questions and reproducible evidence, not external endorsement.

## Types and literal action

B_mu^a are the independent lower-component coordinates of the total connection,
in real orthonormal plane generators T_ij=(E_ij-E_ji)/sqrt(2). Their trace metric
is -Tr(T_a T_b)=delta_ab. eta=diag(1,-1,-1,-1). A LorentzContraction multiplies
one eta weight per bound spacetime slot. The independent first jets are
partial_lambda B_mu^a. Canonical covectors satisfy delta S=integral E_a^mu h_mu^a;
they are dual evaluation coordinates, rather than Lorentz or internal Riesz
vectors. Ordinary prolongations commute and have symmetric derivative slots.

The approved 34 terms are -F_a^(mu,nu) F_(a,mu,nu)/4, four covariant scalar
kinetics and 29 minus-potential terms. F=dB+g[B,B], D x=partial x+g rho(B)x.
The 45-generator quantum convention is delta B=D omega, delta x=-g rho(omega)x.
The H-only background and vacuum are fixed in this calculation; no 45-component
affine background transformation or Stage E claim is introduced.

## Derivation and implementation correspondence

Vary the literal action before applying any field projection:

    delta F_mu,nu = D_mu h_nu-D_nu h_mu,
    delta L_YM = -F_a^(mu,nu) (D_mu h_nu)^a,
    E_YM,a^nu = partial_mu F_a^(mu,nu)
               +g f^(a,b,c) B_mu^b F_c^(mu,nu),
    Theta^mu = -F_a^(mu,nu) h_nu^a.

The normalization is derived from -1/4 and the two antisymmetric curvature
components, with the internal trace metric above. Free, cubic and quartic
terms follow by expansion; no coefficient is fitted to a witness.

The component adapter independently differentiates the executable AST using
identity deltas. Every sum wrapper retains its original metric measure. For
each first-jet occurrence it takes the component partial and applies ordinary
integration by parts. A derivative direction exposed in the boundary momentum
is projected inside its original binder. The executor supports a derivative
direction already carried by a coefficient's label, without adding a second
sum. Induction on sums, products, constant tensors and retained finite sums
establishes the component chain rule for the declared even first-jet physical
grammar, where a Lorentz sum covers its whole monomial. Products of independently
closed spacetime sums require a broader lowering pass and are rejected; no
claim is made for arbitrary expression trees outside this physical grammar.
The input action has no higher jets or odd/source factors. Such inputs are
rejected rather than assigned an unqualified derivative convention.

The replay uses trace-derived 10x10 Lie brackets, the physical antisymmetric
two-form, and independently collected coefficients of arbitrary h and its
jets. It does not import the new Euler adapter or the primary evidence. A
second replay comparison checks the covariant divergence directly. The first
variation is adjudicated coefficient by coefficient, including the boundary
momentum, not just by comparison of final Euler columns.

For every scalar sector Z_mu=D_mu x, with arbitrary component jets and B:

    delta_B L_kin = g (Z^nu)^T rho_a x h_nu^a,
    J_a^nu = g eta_nu Z_nu^T rho_a x.

The literal-AST first variation is compared to the independent bilinear current
with Z treated as an arbitrary vector. Substitution of the authenticated exact
D AST is a polynomial identity, covering its nonzero connection terms. Fresh
nonzero-field controls also evaluate the direct new Euler operation with two
noncommuting connection directions and every scalar coordinate retained. The
singlet current is identically zero. The potential contains no B and contributes
no gauge Euler or gauge-variation boundary current.

## Noether and scalar adapter dependencies

The full off-shell identity is

    partial_nu E_a^nu + g f^(a,b,c) B_nu^b E_c^nu
      + g sum_s E_x,s^T rho_a x_s = 0.

The pure gauge part is freshly expanded for all 45 components. Structurally it
is D_nu D_mu F^(mu,nu)=[D_nu,D_mu]F^(mu,nu)/2=0. For matter, representation
commutators and skew pairings give D_nu J_a^nu=g(D_nu D^nu x)^T rho_a x;
the Z^T rho_a Z term vanishes. The qualified scalar cotangent adapter supplies
E_x=-D_nu D^nu x-V_x. The remainder is -g V_x^T rho_a x, zero by the
authenticated 29-direction invariant-potential proof. The representation
commutator and potential proofs are inherited structural evidence, not fresh
exhaustive expansion of the full scalar potential. No EOM is imposed.

The standard local-functional Euler operation and boundary adjudication are
discussed in [Barnich, Brandt and Henneaux, sections 4.3-4.4 and 6.2](https://arxiv.org/html/hep-th/0002245v3).
That reference supports the method; it does not certify this implementation.

## Canonical sources and historical charts

The literal vector source coupling is sum_mu eta_mu K_(a,mu) Q B_mu^a. In this
raw lower-component chart the canonical evaluation source is J_a^mu=eta_mu K.
Thus its unsigned induced field/source pairing is eta, whereas (B_mu,J^mu)
has identity pairing. This follows from the literal coupling and the first
variation, not from multiplying a defective helper output. For the light
catalog carrier convention, compose J_(H,mu)=eta_mu G_H k_(H,mu). K_phi has no
free Lorentz slot and keeps its qualified scalar cotangent/source bridge.

For B_plane=Q B_parent, J_plane=Q^(-T) J_parent and E_parent=Q^T E_plane.
The lower raw plane source is eta Q^(-T) J_parent. All 180 component pairings,
inverse products, induced light brackets, constant-jet transport and conjugation
are checked. Internal Gram, Lorentz metric and canonical evaluation remain
separate. In the source-left convention Q=(S,.), the physical contribution to
Q J is +E. These are chart qualifications; no source is activated and no full
source differential is assembled.

The minimal old contraction counterexample explicitly loses eta when its
identity delta frees the Lorentz dummy. The old helper and all 16 controls
remain unchanged, as does the quartic control refuting a final eta multiplier.
Actual frozen S6/S7 heavy/light free-channel outputs are tested. Their +b''
value cannot be the canonical lower-field Euler -b''; it could match a lower
source chart in that channel. The nonuniform interacting helper failure prevents
that observation from certifying the complete historical source interpretation.
Historical acceptance ledgers and bytes are retained; full historical interacting
and gauge-fixed reverse columns require later derivation in a declared chart.

## Review limitations and next decision

The derivations share immutable assumptions, Python/SymPy, some arithmetic and
serialization, and the same analyst. The independent replay and negative
controls reduce implementation dependence but are not external verification.
No particle prediction, gauge matching, quantum correction or full BV master
identity is established. The operation may become a dependency of a separately
authorized inactive Stage D integration; that integration and Stage E remain
outside this investigation. Historical custody remains strict exit 2 with
seven unresolved references. Formal authority remains 34/39.
