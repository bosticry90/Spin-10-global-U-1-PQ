# E5 Ward/basic nonminimal polynomial retract result

The complete primary and independent replay agree on a nonminimal deformation
retract for the inactive retained-source gauge/scalar complex. It preserves
the full polynomial domain, its background-Ward kernel and its joint
quantum/background/contraction basic kernel, each with the declared primitive
space and ordinary-divergence convention. This resolves the nonminimal-domain
prerequisite left open by the regularity and coupling-ring checkpoints.

Disposition: `QUALIFIED_E5_WARD_BASIC_NONMINIMAL_POLYNOMIAL_DEFORMATION_RETRACT_ONLY`.
It is a bounded mathematical lemma, not full E5, quantum consistency, catalog
acceptance or a physical unification result. `project_state.json` remains v113,
34/39. All 643 pairs and 48 external backgrounds remain in the candidate.

## Exact scope and result

The [contract](A10_E5_NONMINIMAL_RETRACT_CONTRACT_V1.md) and
[derivation](A10_E5_NONMINIMAL_RETRACT_DERIVATION_V1.md) specify the polynomial
parameter ring, types, field/source pairings, component real structure,
Lorentz conventions, ordinary symmetric jets and the 19 sealed predecessors.
No physical coupling, width, mass or field is inverted. The nonsymmetric
heavy coset and composite R_H are retained. The 508 physical Euler programs
are authenticated and unchanged; they are not freshly expanded.

In the beta chart each of the 45 nonminimal quartets obeys

    Q eta=beta, Q beta=0, Q J_beta=J_eta, Q J_eta=0,
    h beta=eta, h J_eta=J_beta, h eta=h J_beta=0.

Counting all four coordinates and their jets with positive weight one gives
{Q,h}=n and h^2=0. For F=sum F_k in that degree, H F=sum_(k>0) h F_k/k and
p sets nonminimal variables to zero IN THE BETA CHART. Thus

    QH+HQ=1-p, p^2=p.

Only positive integer constants are divided. The proof covers all finite-support
polynomials, including multiple sources and arbitrary ordinary jet order.
H commutes with ordinary derivatives. For QF=sum partial_mu m^mu,

    F-pF=QHF+sum partial_mu Hm^mu.

The actual Ward operators commute with h, while the odd contraction
anticommutes with h. Count, projection and H preserve their respective kernels,
also modulo ordinary divergences. The operations are transported through the
complete N and E2 U maps. Their image contains 553 transported minimal pairs;
its generators can contain original nonminimal coordinates in the required
combinations. This is a cochain reduction, not source removal or auxiliary
elimination from the action.

## Independent calculation coverage

Primary constructs the quartet operations in the beta chart and conjugates
through N/U using general graded substitution. Replay derives the H carriers
from physical 10-by-10 matrix commutators, evaluation-dual source embeddings
and physical auxiliary bilinears, then derives the finite scale/count/projector
by its closed cochain-scaling formula. It freshly checks 540 physical dual-source
H commutators. The two routes compare every represented coefficient and implicit
zero of the following maps on all 1,334 canonical/external coordinates.

| Map | Nonzero columns | Nonzero coefficients |
| --- | ---: | ---: |
| h after N/U | 90 | 137 |
| Counting operation | 605 | 4,476 |
| Finite polynomial scale | 1,334 | 5,630 |
| Transported projection | 1,199 | 5,450 |
| Total coefficient comparisons | | 15,693 |

Both routes check all 1,334 coordinates against Q, iota, transported Tq and Tb;
16,008 first/mixed-second jet controls; projector idempotence, scale semigroup,
h square, scale/count relations; and 2,466 component real-structure matrix
entries. Local parameter jets are retained. The all-order claim follows from
the graded derivation/prolongation and finite-degree proof, not enumeration of
those finite controls. The inherited evaluator raises above jet order six;
that cap is never treated as a zero relation.

The dimension checks retain E1's documented dimension-one evaluated
OrbitPullback coefficients. Both routes derive a bookkeeping lift from the
heavy-orbit Euler covectors and recover every frozen coefficient at normalized
unit one. Replay gets the declared dimensions from the frozen executable E1
fermion and freshly checks O^T v=0 from its own vacuum record. These are type
annotations, not a new vacuum, interaction coefficient or parameter choice.

## Nontrivial controls and exact exclusions

The source-quadratic basic primitive produces 47,411 complete transported
counterterm coefficients. Its 3,890-coefficient primitive is recovered exactly
by H; pF=0. A separate actual H-singlet ghost/evaluation-pair control has 2,327
counterterm coefficients and a 45-coefficient recovered primitive. Their Q
columns agree independently, with source-degree-two terms retained.

Final routes freshly reduce the beta-chart squares and compare the complete
transported counterterm columns to their conjugates. Post-transport closure
then uses the authenticated canonical master/nilpotence proof. They do not
freshly re-expand the larger full transported counterterm squares. An isolated
earlier primary tail probe did that expansion, but is not counted as a completed
qualification route. All 1,334 generator QH+HQ identities are freshly checked.
The regression suite additionally tests a nonzero full-model boundary current
and its exact Q/H/projector identity; it does not rely only on a zero current.

h is not canonical even though h_D Psi=0. Its attempted antibracket derivation
has constant defect 2. Complete transport gives

    h' J_ub=-J_Lambda-xi G_M^-1 ub,
    h' J_bar=-J_b-eta_H G_H bar.

Keeping h_D after gauge fixing yields the exact free source defects

    J_ub13: -xi Lambda_44/4,
    J_bar0: -2 eta_H b0+eta_H b1.

The full rows follow from the physical invariant bilinears, including the
light off-diagonal entry. They are not fitted to a residual. Naive old-chart
counting/deletion misses ghost-source cotangent and gauge-condition corrections.
The finite scale and projector are cochain maps, not canonical transformations.
An odd H F may be a classical canonical generator, but quantum admissibility
and insertion transport remain A5.

Four failed qualification attempts retain their exact start fingerprints,
logs and original source bytes in superseded_start_v1-v4. They concern a
word-only dimension check, an incomplete expected light Gram row, a replay
metadata-schema assumption and symbolic zero terms retained in raw replay
scale dictionaries. The last diagnostic found 465 raw dictionary differences
and zero nonzero polynomial residuals. The replay launcher canonicalizes those
scale maps before structural comparison. No protected evidence or numerical
input was changed. All four attempts are excluded from qualification.

## Validation and limitations

The two complete routes agree and all 18 new adversarial regressions passed.
Local sealing additionally requires the read-only validation receipt: exactly
201 targeted tests (18 new, 138 inherited science, 24 process, 21 governance),
two fresh byte-identical new routes, unchanged bounded/protected byte hashes,
unchanged authority and the recorded strict custody exit 2/seven unresolved
references. Consult frozen_a10_e5_nonminimal_retract/validation_receipt.json
for the executed commands, outcomes and integrity counts. If that receipt is
absent or mismatched, final evidence validation and local sealing are incomplete.
A passing receipt authenticates this bounded lemma; custody is not PASS.

No expensive predecessor scientific calculation is repeated. The workspace
inventory records size/mtime, not every byte of the environment. Explicit
protected and new files are byte-hashed. Execution-start fingerprints bind
declared code/contracts, predecessor manifest, state, interpreter and SymPy
version; they do not attest every installed package byte or grant scientific
acceptance. Failed attempts preserve their original bindings.

The derivations share immutable inputs, exact word arithmetic, Python/SymPy
and analyst. No independent external endorsement or proof-kernel certification
is claimed. Published [local BRST cohomology, sections 2.6-2.7](https://arxiv.org/html/hep-th/0002245)
supplies the standard doublet method; the actual Ward/basic, source, metric and
transport extension is established here under the stated project assumptions.

## Remaining scientific decision

Nonminimal reduction is now available separately in the full, background-Ward
and joint-basic polynomial complexes. It does not equate the intrinsic basic
quotient with the intersection of full exact terms. Those questions reduce to
their respective MINIMAL problems. Nor does it prove source-free minimal
representatives over the polynomial coupling ring. The coupling-tangent
counterexample and its failed background-Ward admission remain unchanged.

Next address the remaining minimal polynomial source/primitive and target
comparison, retaining g=0 as an algebraic specialization and distinguishing
linearized Ward cocycles from actually admissible quantum counterterms. Derive
any coupling-power or normalization restriction rather than assume it. The
conditional W1-W7 construction, A1-A5, regulator/QAP/restoration, insertion
mixing and quantum canonical equivalence are still open. W6 does not impose
naive fixed strict Tq' invariance on the quantum functional.

Full E5, M08/HB1/C5 and C1_GS remain unqualified or blocked. No activation,
source elimination, catalog generation, matching, authority change, contact,
publication or remote push occurred. The full Spin(10) x U(1)PQ investigation
remains incomplete, including global scalar boundedness, physical matching,
later phenomenological tests, full fermion/Yukawa content and the global PQ
quotient. This checkpoint does not redefine that goal as a smaller calculation.
