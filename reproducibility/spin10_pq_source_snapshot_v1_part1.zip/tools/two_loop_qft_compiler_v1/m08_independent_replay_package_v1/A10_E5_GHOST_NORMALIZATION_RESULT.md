# E5 explicit interacting g=0 ghost normalization

Disposition: PARTIAL_E5_EXPLICIT_G0_REGULATOR_GHOST_SUBTRACTION_AND_SELECTED_PROBE_ONLY.
Baseline ab2b63a, state v113/34 of 39, 21 sealed predecessor chains.
The supplied latest E5 assessment is the reference for M1--M6: the next work
must exhibit a nonempty construction, not repeat a conditional implication.
This result supplies a concrete regulated functional and an explicit finite
renormalized prescription for the actual disconnected g=0 ghost sector. It
also discovers a pole not absorbable by changing only the literal heavy width.
Complete M2/W1--W7 realization remains unqualified for the reasons below.

## Actual operator and independently computed ultraviolet pole

No frozen action or numerical parameter is changed. All 643 pairs, 48 H
backgrounds, 328 scalar fields, 29 potential directions and the non-Gaussian
276-coefficient auxiliary/ghost vertex remain. For fixed auxiliary field,

    Lambda_phys=F_M Lambda, ub_phys=F_M ub, u_phys=Q_M u,
    F_M=Q_M G_M^-1,
    A(Lambda)=P_M ad(Lambda_phys)|_M,
    L_ghost=ub^T[-Box I+xi A(Lambda)]u.

The ghost integral is Gaussian in the ODD variables for fixed Lambda. This
does not make the complete integrated action Gaussian. Primary differentiation
of the literal vertex and physical-matrix replay reproduce all 33 operator
matrices. Every tadpole trace vanishes. Define

    kappa_ij=-tr_M(A_i A_j).

All 1,089 matrix entries agree, with 33 nonzero canonical entries. The replay
also independently derives, in a real orthonormal heavy frame,

    kappa_phys=8 I_M-2 C_H|_M.

The full adjoint Casimir 8 is calculated from the normalized 45 physical
generators, not imported from an incompatible normalization. The relative
spectrum is

| Eigenvalue relative to the induced width metric | Multiplicity |
| --- | --- |
| 3 | 12 |
| 19/5 | 12 |
| 24/5 | 6 |
| 34/5 | 2 |
| 8 | 1 |

These are counterterm-matrix eigenvalues, not particle masses. Two admissible
real heavy rays have pole/metric ratios 8 and 24/5. Therefore kappa is not a
scalar multiple of G_M^-1, and delta xi in the literal -xi ub^T G_M^-1 Lambda/2
cannot absorb this complete pole by itself. This is a limitation of that
parameter-only renormalization ansatz, not a failure of the physical action.
Other quantum field/source normalizations are not ruled out universally.

With W=-i hbar log Z, a finite Berezin determinant control and the independent
closed-loop derivation fix the sign. At nonexceptional external momentum,

    Gamma_1,pole = hbar xi^2/(32 pi^2 e) Lambda^T kappa Lambda,
    L_CT = -hbar xi^2/(32 pi^2 e) Lambda^T kappa Lambda.

The primary four-dimensional analytic-regulator radial residue and the replay
scalar dimensional bubble give the same 1/(16 pi^2) Euclidean residue. The
Minkowski loop integral supplies its explicit i. No zero-momentum scaleless
integral or numerical tolerance is used. The density has 17 canonical
commuting-field coefficients after symmetric products are combined.

## A concrete regulator and finite subtraction

On Euclidean modes the source-independent regulator is

    P_e(p)=((p^2+m_reg^2)/mu_reg^2)^(e/2), mu_reg,m_reg>0.

Multiply free curvature/scalar kinetic terms by P_e and replace the LINEAR
divergence fermions by their P_e-regulated versions. Retain the cubic/width
terms and the entire potential. Scalar IR reference terms, when used, are
temporary source-independent regulator terms; no physical mass is changed.
This is a four-dimensional spectral regulator, not a new canonical alphabet
or an attempted execution of nonlocal nodes through a local-only Euler helper.

At a finite Fourier cutoff this specifies a finite graded formal perturbation.
P_e commutes with ordinary derivatives and the actual linear Q0. All 643
field squares and 2,572 first-jet commutation controls pass. Its integrated
field change has identity diagonal and zero supertrace, hence unit finite-mode
Berezinian. Free curvature is Q0-invariant and the fermion changes are Q0-exact.
Scalar terms are annihilated because Q0x=0. All 48 background/quantum differences
B_H-A_H are invariant under the g=0 simultaneous background shifts. Local
geometric quantum breaking is retained: the selected -2 P_e b0 Box omega0
has a nonzero auxiliary Euler derivative. False quantum invariance is not
imposed. These are exact finite-regulator statements, not an all-g anomaly proof.

The regulated quadratic gauge/auxiliary block has a checked inverse for an
arbitrary width and multiplier P_e. Its auxiliary-auxiliary inverse is zero.
At g=0 there is no B interaction vertex and the scalar sector is disconnected.
Every surviving heavy vertex has one Lambda, one ub and one u. Consequently,
the only loop graphs in this sector are a single closed ghost polygon with
external Lambda legs. One-leg traces vanish; polygons with three or more
Lambda legs are UV convergent at nonexceptional momenta. There are no higher
loops within this disconnected sector. This graph proof does not cover scalar
loops or the g!=0 theory.

The finite extension calculates, rather than assumes, a renormalized bubble.
For the selected ghost amplitude set m_reg=0 and 0<Re(e)<1 with q_E^2 nonzero;
the two soft regions are separate and integrable. Feynman parameters with
propagator powers a=b=1+e/2 give

    I_an = mu^(2e) (q^2)^(-e)/(16 pi^2)
           Gamma(e) Gamma(1-e/2)^2 /
           [Gamma(1+e/2)^2 Gamma(2-e)],
    I_an,MS = [1+log(mu^2/q^2)]/(16 pi^2).

Explicitly, the parameter integral uses
Gamma(a+b)/[Gamma(a)Gamma(b)] times u^(a-1)(1-u)^(b-1), the shifted four-dimensional
Gaussian momentum integral contributes Gamma(a+b-2)/[16 pi^2 Gamma(a+b)],
and the remaining beta integral contributes
Gamma(2-a)Gamma(2-b)/Gamma(4-a-b). The replay continues only the scalar-loop
integration dimension, then uses modified minimal subtraction, obtaining

    I_dim,MSbar = [2+log(mu^2/q^2)]/(16 pi^2).

Their difference 1/(16 pi^2) is local and multiplies the SAME kappa density.
It is a fixed source-independent BRST-exact finite scheme normalization. It
is not fitted to remove the torsion class or declared a unique project scheme.
The logarithmic finite amplitude remains nonlocal; only the ultraviolet pole
and the scheme difference are local. This supplies a nonempty explicit selected
ghost prescription rather than the earlier conditional source-independence
assumption. The complete scalar/IR limit is not inferred from this one bubble.

Analytic regularization is compared with the primary work of
[Bollini, Giambiagi and Dominguez](https://bibliotecadigital.exactas.uba.ar/greenstone3/exa/collection/paper/document/paper_00296341_v31_n3_p550_Bollini).
The normal-product/insertion distinction is compared with
[Zimmermann's composite-operator construction](https://www.sciencedirect.com/science/article/pii/0003491673904296)
and the [BPHZ renormalized BV master equation](https://arxiv.org/abs/hep-th/9603012).
Those provide methodological comparators; none certifies this implementation
or proves the complete model's quantum assumptions.

## Local BRST subtraction and a selected insertion/contact prescription

The candidate fermion counterterm is

    Psi_CT=hbar xi^2/(32 pi^2 e) ub^T kappa Lambda,
    Q0 Psi_CT=L_CT.

It has grade (3,-1,odd). All twelve dual-heavy H metric identities pass,
D_h^T kappa+kappa D_h=0, so the undifferentiated primitive is pointwise H
invariant. This candidate is a computed unphysical BRST-exact normalization.
It introduces no new physical coupling and is kept separately; the frozen
E1 fermion is immutable. Renormalizing its width by a matrix counterterm is
different from claiming historical equivalence or silently fitting delta xi.

Couple a local even dimension-zero rho to the ACTUAL Q0-exact cubic density.
Then chi=(1+rho)Lambda and the ultraviolet pole is (1+rho)^2 times the same
kappa density. The candidate subtraction Q0[(1+rho)^2 Psi_CT] is local,
source independent and BRST exact, without imposing rho constant. The first
and second rho derivatives have coefficients 2(1+rho) and 2; the third and
higher pole derivatives vanish. These are ordinary derivatives, not an implicit
rho^2/2 convention. The finite chi amplitude retains its nonlocal log kernel.
This is a specified operator/contact family with explicit subtraction, not
all source-dependent probes, arbitrary contacts or A4/A5 equivalence.

The actual finite regulator and selected counterterms/probes contain no BV J.
Thus the ab2b63a ordinary-source shift is realized in this construction, and
at rho=0 its Gamma source columns keep their affine tree form. In this explicit
family a constant unweighted F correction to those ORDINARY source columns
is excluded. F as a separately normalized insertion is not universally
excluded, and the quantum A5 equivalence of weighted gF remains unproved.
Classical basic exactness must not be silently promoted into that equivalence.

## M1--M6 disposition and the next scientific action

| Gate | Evidence achieved | Remaining obligation |
| --- | --- | --- |
| M1 | Literal interaction and all 33 ghost operators reconstructed; all 643 pairs retained | None in this bounded specialization |
| M2 | Explicit source-independent finite regulator; finite renormalized ghost-subsector prescription | Full scalar subtraction/parameter closure, physical IR/boundaries and all-g restored class |
| M3 | Exact g=0 finite-regulator linear BRST/background identity and expected geometric quantum breaking; local subtraction exact | g!=0 anomaly/restoration and complete quantum Slavnov/insertion realization |
| M4 | Explicit local cubic-probe first/second contact subtraction and nonlocal finite kernel | General source-dependent probes, mixing and A4/A5 normalization |
| M5 | Ordinary unweighted F excluded in this realized family at rho=0; its polynomial torsion result preserved | Full target admission and quantum equivalence of weighted gF |
| M6 | Distinct operator/residue/finite calculations and adversaries | Full target remains underdefined; no complete E5 PASS |

Next smallest productive action: determine the g=0 scalar subtraction closure
of the actual 29-potential/34-real-parameter family and the admissible BRST-exact
gauge-fermion normalization space, then address all-g restoration and the
required insertion/canonical equivalences. This will decide whether the
selected construction extends to a nonempty complete W1--W7 prescription.
No unrestricted catalog, VPC transfer or software redesign is needed.

## Validation and preserved controls

The receipt transaction requires 239 targeted tests: 20 new and 174 inherited
scientific, 24 process and 21 governance. Both new route suites freshly
regenerate four evidence artifacts byte-for-byte. Across principal/replay
finite records exact symbolic equality is required, while the local difference
between the two SUBTRACTION SCHEMES is retained. The initial validator's
string comparison of equivalent finite forms failed; original validator/test
bytes, exits and exact forms are preserved in validation_preflight_v1, with
its observation scope disclosed. It is excluded from final validation.
No completed calculation record was edited or overwritten.

The receipt and seal record completed protected/state byte checks, 21 inherited
manifests and bounded workspace/active-data metadata auditing. Old expensive
calculations are authenticated, not rerun. Shared physical inputs, some chart
and word arithmetic, Python/SymPy and analyst remain; no outside endorsement
or unrestricted environment audit is claimed. Historical custody stays exit
2 with seven unresolved references, never PASS.

Formal authority stays v113/34 of 39. M08/HB1/C5 stay blocked and C1_GS is
uncalculated. There is no activation, source removal, auxiliary elimination,
catalog replacement, physical matching, publication, outreach or remote push.
The full Spin(10) x U(1)PQ investigation remains active and incomplete,
including full E5/A1--A5, global scalar boundedness/PQ quotient, the complete
fermion/Yukawa sector, physical matching and phenomenology. A concrete
unphysical ghost subtraction is not a physical unification result.
