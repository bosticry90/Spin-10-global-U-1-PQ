"""Read-only first integration identity; no qualification or file writes."""
import json,time,sys
from a10_bv_integration_common import *

def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    data,columns=source_data();w=algebra();start=time.perf_counter()
    print('LOADED '+str(len(columns)),flush=True)
    if '--master' in sys.argv:
        r=source_master(columns,w)
        print('MASTER '+json.dumps({'density_coefficients':len(r['literal_master_density']),
            'current_coefficients':sum(len(P) for P in r['boundary_current']),
            'residual':r['density_minus_divergence']}),flush=True);return
    for i,(z,J) in enumerate(w.pairs):
        n=J if '--sources' in sys.argv else z
        residual=canonical(w.act(columns[n],columns,parity=1))
        if residual:
            print('FIRST_FAILURE '+json.dumps({'coordinate':n,'residual':rows(residual)}),flush=True);return
        if i%100==0:print('COORDINATE_ZERO '+n+' '+str(i)+' '+str(time.perf_counter()-start),flush=True)
    print(('ALL_643_SOURCE_SQUARES_ZERO ' if '--sources' in sys.argv else 'ALL_643_FIELDS_ZERO ')+str(time.perf_counter()-start),flush=True)
if __name__=='__main__':main()
