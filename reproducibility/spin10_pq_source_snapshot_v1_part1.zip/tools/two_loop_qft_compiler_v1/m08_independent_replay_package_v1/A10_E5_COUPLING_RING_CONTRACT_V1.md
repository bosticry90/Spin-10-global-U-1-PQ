# E5 coupling-ring and target-domain control, V1

1. **Question.** Can the full-complex semisimple source-removal argument be
   applied over the declared polynomial physical-coupling ring, and does a
   coupling-tangent control belong to the actual conditional quantum target?
2. **Claim.** Derive F=dS/dg10 in a qualified canonical doublet chart, compare
   its full-local-functional class with horizontal/source-free representatives,
   derive a pole-free representative for g10 F, and check the local background
   Ward requirement before interpreting either as a counterterm obligation.
3. **Ceiling.** A bounded theorem/domain and primitive-space control, not full
   E5, unrestricted quantum stability, an anomaly or a physical-action failure.
4. **Types/inputs.** Clean 2d0cdaf; state v113/34 of 39. Authenticate 18 sealed
   manifests and use the 34-term ungauge-fixed physical action, 643 canonical
   pairs, source-left bracket, actual 45-generator nonsymmetric algebra, 328
   real scalars and 48 external H backgrounds. Reuse the new exact nonminimal
   chart N(g), E2 U(g), scalar/gauge Euler programs and Noether certificates.
   All fields/sources/auxiliaries remain; no fermion/Yukawa or new source pairs.
   Parameters are independent polynomial variables in characteristic zero;
   no inverse g10, mass, field or dimensional parameter. Finite ordinary jets,
   no explicit spacetime coordinates, qualified real/Lorentz structure and
   boundary currents are required. PQ remains global.
5. **Comparison.** [Barnich, Brandt and Henneaux, section 12.2](https://arxiv.org/html/hep-th/0002245)
   and [Barnich and Henneaux](https://arxiv.org/abs/hep-th/9304057) distinguish
   fixed-theory cohomology from consistent deformations. Do not infer that a
   fixed nonzero semisimple-coupling theorem holds over a ring admitting g10=0.
6. **Primary.** Differentiate the authenticated source polynomial; use the
   literal physical AST's dilation weights and master-boundary certificate.
   Evaluate a stationary g10=0 polynomial projection retaining C and JC; derive
   horizontality and background-Ward Euler witnesses with local parameter jets.
7. **Replay.** Derive source coupling variations from the indexed source AST
   and independent qualified matrix data; derive the real H/heavy witnesses
   directly with physical Spin(10) matrix commutators and evaluation-dual maps.
   Compare complete computed coefficients/hashes, not sample tolerances.
   Shared input data, graded arithmetic, Python/SymPy and analyst are disclosed.
8. **Adversaries.** Hidden inverse g10, lost graded dilation sign, treating a
   constant-H test as local Ward acceptance, failing to transport g-dependent
   charts, or claiming a nonhorizontal full cocycle is a quantum counterterm
   without W_b=0. Preserve the nonsymmetric heavy bracket and old controls.
9. **Limits.** g10=0 is a ring specialization, not the selected physical
   benchmark. All potential parameters may be set to zero in the algebraic
   nonexactness test. This is not using physical equations to cancel a failure.
   The weighted g10 F family must be compared without dividing by g10.
10. **Stop.** First unexplained exact mismatch stops its dependent gate.
    Expected nonzero negative controls are results. If quantum admissibility
    or primitive-space completeness is unproved, classify that scope explicitly
    and do not claim general E5 adequacy; continue separable declared controls.
11. **Meaning.** An unrestricted-ring obstruction does not establish failure
    of the Ward/insertion-admissible target. A constructive named family does
    not prove all-family surjectivity, intrinsic/induced equality or A1-A5.
12. **Record.** Preserve completed primary/replay routes, current/primitive
    identities, exact real and local Ward witnesses, failed/unfinished attempts,
    fresh reproducibility, predecessor hashes and receipt. Validate before local
    commit. No frozen changes, authority promotion, activation, catalogs,
    HB1/C5, C1_GS, quantum matching, contact, publication or push.
