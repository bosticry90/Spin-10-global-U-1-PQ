# Measured poles assembled; restoration dependencies remain open

MF1-MF3 organize the measured one-loop residues into one explicitly scoped
functional collection. The qualified finite canonical polynomial part has
27,745 distinct terms. Two routes agree on every sector, their sum, the local
background Ward variation, its full boundary currents, both selected Slavnov
projections and independent forward/backward input-type censuses.

This is QUALIFIED_MEASURED_RESIDUE_ASSEMBLY_AND_OPEN_RESTORATION_DEPENDENCIES_ONLY.
It is not complete one-loop restoration or the complete divergent functional.
The g^3 quartet candidate obstruction at df9b452 remains intact. No candidate,
generator, image, physical parameter or pole coefficient was fitted, and no
new actual loop was calculated in this increment.

The action's pole contribution is hbar/(32*pi^2*epsilon_UV) times the following
finite polynomial collection. Input residues with a stripped coupling are
restored before addition; records that already include it are not multiplied
twice. Each individual sector must pass its declared coupling-degree gate.

| Measured sector | Coupling/width order | Canonical terms before addition |
| --- | --- | ---: |
| Heavy auxiliary width | xi^2, g^0 | 17 |
| Longitudinal gauge/auxiliary mixing | g*xi | 132 |
| Gauge-source/derivative ghost | g*xi | 132 |
| Scalar-source/ghost/scalar | g^2*xi | 22,626 |
| Auxiliary/antighost/ghost | g*xi^2 | 276 |
| Four ghosts | g^2*xi^2 | 1,302 |
| Nonminimal-source/antighost/ghost | g^2*xi | 236 |
| Next auxiliary/antighost/ghost | g^2, xi^2 and xi*eta_H | 276 |
| Derivative gauge/antighost/ghost | g^2*xi, all four Lorentz copies | 2,768 |
| Antighost-source/gauge derivative | g^2 | 128 |
| Auxiliary-source/Box ghost | g^2 | 128 |
| Four ghosts | g^3, xi^2 and xi*eta_H | 966 |

Terms shared across coupling orders combine as polynomials. The g*xi ghost
kinetic logarithm and g*xi^2 width logarithm remain explicit measured zero
records with their original scopes. Other width/coupling channels are not
set to zero by these records. All 643 pairs, 48 background components and
source parities remain unchanged. Physical/canonical roundtrips and reality
hold for every explicit sector.

The source/scalar pole was directly calculated for phi. Its extension to the
other scalar representations uses the qualified commutator theorem and
literal source columns; it is not a new dense Sigma loop calculation. The
ordinary g^0 scalar Hessian-square program is retained separately with 331
graph coefficients, all 29 terms/34 parameters, its original Euclidean and
Minkowski subtraction conventions and unexpanded beta coefficients. Its
potential field content cannot enter the two selected Slavnov projections.
The g*xi ghost cutoff-power and finite heat profile are also retained
separately. They are not logarithmic residue terms. Different regulator,
reference-mass, finite and IR prescriptions have not become one implemented
quantum prescription merely through this assembly.

The measured polynomial obeys the constant-H identities. Its complete local
background Ward variation has 13,168 raw terms involving ordinary omega jets.
Moving all parameter derivatives by integration by parts gives 34,464 anchored
terms, with every boundary current retained. The independent parameter Euler
derivatives reproduce that anchored density and are nonzero. Thus the local
variation of the measured subset is not a pure boundary. It is an open
restoration obligation; missing amplitudes and Delta_b remain unknown.

Six Ward target families require additional partners. Their necessary affine
predecessors include both B_H and the external A_H connection:

| Known variation | Necessary unmeasured local partner types |
| --- | --- |
| g^2 gauge-source/ghost parameter jet | g^2 JB*B*C and JB*A*C |
| g^2 longitudinal mixing parameter jet | g^2 Lambda*B*B and Lambda*A*B |
| g^3 derivative-gauge parameter jet | g^3 B*B*a*C and A*B*a*C |
| g^3 antighost-source/gauge parameter jet | g^3 Ja*B*B and Ja*A*B |
| g^3 auxiliary-source/ghost, one parameter jet | g^3 JL*B*C and JL*A*C with one ordinary jet |
| g^3 auxiliary-source/ghost, two parameter jets | the same one-jet source partners, with complete jet placements |

These are complete necessary types in the declared local language, not
coefficient solutions, Lorentz/H invariant bases or calculated graph poles.
For example, background-only or background-dependent partners cannot be
discarded because the preceding amplitude was measured at A_H=0. Omitting
A_H loses six predecessor families in the adversarial census.

All 1,286 E2 source-polynomial columns and 214,340 terms were screened.
Positive-dimensional Orbit terms are explicitly outside the coefficient-
dimension-zero projections. All 508 separately indexed physical Euler
program slots remain deferred. Their bosonic content or positive-dimensional
constants cannot supply either selected odd/auxiliary target from an admitted
dimension-four input. This support proof does not set the full physical
Euler programs or their full Slavnov variation to zero.

The g^2 antighost/two-ghost, two-jet known contribution has 2,842 canonical
terms, or 10,316 terms in the physical real frame. The g^3 auxiliary/
antighost/two-ghost, no-jet contribution has 1,932 canonical terms, or 11,376
physical real terms. Both have real physical coefficients and nonzero Euler
witnesses. The former has a canonical bar0 Euler coefficient
96*sqrt(2)*I*xi*C14*Box(C43)/5. The latter's L12 Euler derivative starts with
16*xi^2*C12*C13*ub13/5. These are variations of the KNOWN subset, not measured
complete quantum breaking coefficients or anomaly witnesses.

The complete raw coefficient domains are 3,539,700 for the two-jet target
and 2,004,750 for the no-jet target. They index local monomials, color and jet
placements; physical amplitudes have many such coefficients. Equal ghost
colors with unequal jets are distinct odd generators and remain present.
Forward substitution and backward multiset subtraction yield the same
necessary source/field/coupling input census. Single-field positive-jet
inputs are marked pure boundaries, not independent unknown amplitudes.

Within the leading two-jet census, the only unmeasured non-boundary input
type is g^2 JC*C*C. The measured derivative-gauge, gauge-source, auxiliary-
source, nonminimal-source and zero ghost-kinetic contributions supply its
other input types at their declared width scopes. Unknown complements and
Delta_s are not bound. In the higher no-jet census, unmeasured inputs include
g^3 JC*C*C, JL*a*C*C, JL*Lambda*C and Ja*a*C, and g^1/g^2 Ja*Lambda.
Their actual graph zeros or poles have not been inferred from type eligibility.

The shared one-loop problem remains

    W_b(Gamma_known + Gamma_unknown) = Delta_b,1,
    Qprime(Gamma_known + Gamma_unknown) = Delta_s,1.

Neither unknown function nor right side is set to zero. Higher nonlinear
Slavnov brackets, W5 whole-product insertions, W6 operator/source mixing,
rho contacts, measure/regulator realization, canonical equivalence and IR
removal retain their previous conditional W1-W7/A1-A5 status. No naive fixed
classical quantum-H operation is imposed on Gamma. The source covariance
and insertion language remain distinct from classical canonical algebra.

Two import failures were caught before qualification and are preserved.
First, the initial replay selected the historical unqualified g^2 quartet
replay.json. Its sealed failure disposition identifies an even-variable
derivative-sign failure; primary_v3.json and replay_v2.json are the qualified
historical outputs. Second, both initial assemblers omitted the stripped g^2
factor from the reconciled auxiliary coefficient. Pairwise agreement did not
detect that shared unit error. The final V3 workers restore the declared
factor, enforce every sector's g degree, and retain a strict negative check
that rejects the archived wrong-unit data. Nothing was fitted to make the
functional identities vanish. Earlier outputs, source/preparation/start/full
stdout, comparison failure and both dispositions remain exact and excluded.

Current qualifying outputs are controls_v2.json, primary_v3.json,
replay_v3.json and comparison_v3.json. Their calculation labels are distinct
from the comparison/validation qualification. Validation owns scientific,
process/governance and delegated e5 checks, four own-byte fresh executions,
42 protected predecessor chains and byte/state/size-mtime invariance.
Custody remains exit 2/seven unresolved references, never PASS. Old expensive
physical loops/images are authenticated only. Raw index/worktree equality
is required before local commit. Failed or unqualified runs are not PASS.

Shared action/data/representations, some arithmetic, Python/SymPy and analyst
limit independence. Reproduction and derivation agreement are established
within the declared scope; proof-assistant formalization is not attempted.
Full restoration and broader interpretation remain open; empirical connection
is none. project_state.json v113, 34/39 remains sole authority. No adoption,
physical/catalog/HB1/C5/C1_GS/matching, publication, push or outreach occurred.
The full Spin(10) x global U(1)PQ, scalar/global-PQ, fermion/Yukawa and
phenomenological investigation remains active and incomplete.

Next smallest actual scientific action: separately freeze the leading
g^2*xi JC-C-C loop, complete graphs/all45 source and ghost directions, and
its insertion/breaking scope. Compare the enlarged measured functional in
the two-jet Slavnov projection. Keep the related JB-B-C/A_H partners visible
for a subsequent joint local Ward test. This is an actual partner measurement,
not a fit to the g^3 residual or another expansion of a candidate image.
