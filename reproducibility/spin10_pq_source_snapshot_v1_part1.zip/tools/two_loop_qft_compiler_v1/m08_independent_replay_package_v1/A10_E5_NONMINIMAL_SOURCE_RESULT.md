# Actual nonminimal-source pole fixes the quartet affine member

Disposition:
`QUALIFIED_SELECTED_NONMINIMAL_SOURCE_AND_UNIQUE_INACTIVE_AFFINE_MEMBER_ONLY`.
The completed validation receipt and byte seal own bounded evidence
qualification. Baseline f68619f, state v113, 34/39, with 34 authenticated
predecessor chains. The full Spin(10) x global U(1)PQ goal remains active.

The independently calculated actual g^2 xi J_antighost-a-C logarithmic pole
matches the previously recorded quartet representative exactly. All 91,125
source/antighost/ghost slots are compared, including zero channels. The source
equations have rank 39 on the full quartet affine kernel, so they fix its
remaining 39 directions uniquely, all at zero in the saved kernel coordinates.
No coefficient was changed after observing this new amplitude.

This is a new actual interacting pole and a stronger normalization hypothesis.
It is not an adopted subtraction, quantum canonical equivalence, complete E5,
or force unification. Other predicted companions still require actual tests.

## Complete actual calculation

The 45 antighost sources are even and have dimension two/ghost number zero.
The external antighost and ghost are odd, with opposite ghost numbers and
dimension one. Their local density has grade (4,0,even). All sources remain
external; auxiliaries and the original 643 fields stay in the integration
domain. Evaluation sources and raw field carriers use opposite qualified
primal/dual maps, not an identity identification of two primal vectors.

The literal source action has 45 linear -J_antighost*auxiliary terms and
180 nonlinear heavy source coefficients. The second integrated derivative
of every linear term is zero: its first derivative is an external source,
and every other field gradient is zero. An independent Gaussian/generating-
functional argument shifts the ordinary linear source without changing the
covariance. Thus the light source has zero regulated one-loop determinant
response. This is derived from the retained model, not an imported textbook
antighost equation or a general contact-normalization theorem.

The nonlinear source contains C_H and a heavy antighost as its quantum legs.
The only contributing three-cubic topology uses that source vertex, the xi
auxiliary vertex and the light-antighost derivative ghost vertex. All six
Born words and both ghost inverse orientations are kept. Ordered Wick
contraction with two distinct H/M ghost labels independently gives the same
homogeneous coefficient I/(k^2)^2. The Minkowski master i/(16 pi^2 epsilon)
gives multiplier -2 in common hbar*g^2*xi/(32*pi^2*epsilon) units.

Every eligible cubic/quartic bubble is screened. The g xi quartic has only
heavy antighosts and cannot consume the source's C_H through its required
light-antighost inverse edge. Source vertices with one quantum leg have zero
Hessian and cannot generate a proper loop vertex. Other physical vertices
cannot consume the odd source legs; mass/orbit insertions lower UV degree.
These exclusions establish zero light-source, light-antighost and ghost-H
channels over the entire 45^3 domain. No diagram is omitted by its prediction.

The full reference retains BB, BL/LB, LL=0, both H/M ghost inverses and arbitrary
widths. Only after edge screening and exact four-Lorentz contraction do the
unused BB widths drop out. The complete derivative-placement IBP current is
retained. External momentum remainders have negative UV degree above R_UV>0;
there is no whole scaleless zero-momentum or full finite/IR amplitude. Triangle
and bubble heat profiles remain distinct. Omitting the zero bubble is not
counted as a discriminating control.

Primary pulls literal source, gauge and xi tensors to the real physical frame
and contracts their exact ordered indices. Replay independently derives
normalized physical10 commutators and uses the H Casimir identity. Define

    T_h = -E_M^T ad(E_H,h) E_M,
    A_j = E_M^T ad(E_M,j) E_M,
    C_H,M = -sum_h T_h T_h.

For fixed external heavy antighost j, the physical source/ghost pole matrix is

    -(C_H,M A_j + A_j C_H,M - sum_p C_H,M[p,j] A_p).

Replay checks every H-M intertwiner before using this identity. It assumes
neither projected heavy-adjoint closure nor a symmetric coset. Both complete
actual tensors agree, with 776 nonzero physical slots and 236 raw canonical
coefficients. All twelve local H identities, real structure and source/field
chart roundtrips pass. The first physical nonzero coefficient at source 13,
antighost 12, ghost 14 is -16*sqrt(10)/25 in the common pole units.

## Independent source test of the frozen affine family

The source calculation did not read candidate tensors, affine coordinates or
shear-space images. Those were opened only after completed actual agreement.
The source projection of the complete old K0+Kjoint+K3 image is computed to be
zero; it was not assumed. The full particular and all 39 complete kernel
images enter the simultaneous 91,125-equation source comparison.

The already recorded 15-coefficient Gaussian quartet representative equals
the actual source pole. Injectivity fixes all kernel coordinates to zero.
The unique extra generator has 236 coefficients, and its complete Q image
has 11,780. Together with the old generator/current, the one complete inactive
generator has 506 coefficients and its candidate density has 54,823.
The complete selected quartet match over 980,100 slots and all earlier source,
ghost kinetic, mixing, width and cubic scopes remain intact.

The total is a one-loop infinitesimal Hamiltonian image with a formal canonical
flow. The shear alone has the previously qualified exact polynomial inverse;
no new exact finite inverse of the entire combined normalization is claimed.
The source-free additions and the new auxiliary shear do not cancel the
preceding joint regulated field-measure contribution. Operator/source/contact
transport, composite expectations and quantum A5/restoration remain open.

The old normalization failures and source-free obstruction retain their scope.
The new member is inactive and has not yet passed the new derivative-gauge,
auxiliary-cubic, further source or finite/IR amplitudes. In particular, this
source match does not automatically unlock JC-C-C/JB-B-C calculations.

## Failure preservation, validation and next action

The first full execution failed an exact vertex comparison because Python
integer division of a Lorentz weight introduced 502 floating-point coefficients
and spurious roundoff entries. Its entire source preparation, attempt and full
literal/expected/residual diagnostic are preserved as an engineering precheck
failure, not qualified science. The corrected run uses exact rational weights
before pullback and recomputes from immutable inputs; no failed coefficient
was rounded, rationalized or edited. Elementary control function bytes are
unchanged, and both controls are independently reproduced after the correction.

The receipt owns targeted tests, fresh strict own-byte actual primary/replay
and dependent comparison, 34 parents, protected/new/state SHA and audit-time
size/mtime. Expensive old loops and full 125-image derivations are authenticated,
not rerun. Wrong source/odd signs, primal source pairing, Lorentz weights,
H ghost flow and mixed-edge omission have nonzero exact controls. Shared inputs,
graded/chart/exact arithmetic, Python 3.10.11, SymPy 1.14 and analyst remain
disclosed under solo review; no external endorsement or proof-kernel certificate.

Next smallest scientific action: freeze and calculate the actual derivative-
gauge and auxiliary-cubic companions against this unique complete member.
Retain all coupling/width-dependent graph assignments, graded blocks and both
nonminimal sectors. Stop at the first new mismatch, preserving its full tensor
and real Euler evidence. Do not infer success from this source amplitude.

No other new companion or JC-C-C/JB-B-C loop, source/auxiliary elimination,
activation/catalog/HB1/C5/C1_GS/matching, physical/state change, outreach,
publication or push occurred. Historical custody remains exit 2/seven, never
PASS. Full E5/A5/Ward/IR/anomaly, global scalar/PQ quotient, fermion/Yukawa
and phenomenology remain open. State v113/34 of 39 and the full goal stay active.
