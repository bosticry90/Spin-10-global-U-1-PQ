# HBP ambient-action / basic-cochain structural preflight

Resume custody: `91bf039`. Sigma remains in the ambient full-Weil algebra;
its horizontality is not an acceptance condition. The historical HBC witness
is retained as `SIGMA_NONHORIZONTAL_NEGATIVE_CONTROL`. This run is HBP only.

## Task header

| Field | Binding |
|---|---|
| Physics decision enabled | None; test whether the unchanged differential preserves the proposed basic cochain domain. |
| Current blocker removed | Test the ambient/basic revision, without presuming that it removes the structural obstruction. |
| Why existing tools are insufficient | Historical ST/domain labels do not certify an arbitrary source-extended Cartan lift or basicness preservation. |
| Minimum new implementation surface | Exact necessary-condition generator/source preflight, independent physical replay and guarded read-only receipts. |
| Structure-preservation obligations | Distinguish background-Ward from quantum residual-H action; retain dual/source evaluation, graded signs and immutable action/image custody. |
| Stopping condition | First exact failure of basicness preservation or structural compatibility; no upstream repair or transport. |
| What will be deleted or deactivated if this does not work | Nothing is activated; retain the exact counterexample and all expansion provenance. |

## Calculation record

| Field | Binding |
|---|---|
| Scientific question | Does the minimal normalized source-extended Cartan calculus preserve basic cochains although Sigma is ambient and nonhorizontal? |
| Claim under test | L-invariant, iota-horizontal cochains remain so under the current B_Sigma. |
| Scope and authority ceiling | Necessary structural tests before complete tables, descent or promotion; formal authority stays 34/39. |
| Frozen inputs and assumptions | Current 17 images, unchanged six source couplings/Sigma, C4 Weil splitting, C3 frame, weight contract, polynomial coefficient ring and promoted catalogs. |
| Primary method and tool | Extract actual frozen image AST terms, apply exact graded derivations and reconstruct brackets in the frozen split frame. |
| Independent replay decision and reason | Derive the selected source term from the unchanged action using physical matrix/index algebra, without importing primary residual coefficients. |
| Known-limit and physical-assumption checks | B_Abar=0; iota c=delta; the H projection of the full ghost gives iota u=0; source contractions are forced zero by grades; sources use evaluation-dual lifts. |
| Adversarial checks and falsifiers | Test both homogeneous background-Ward and Cartan-induced quantum-H interpretations; exact cancellation of the selected residual would falsify the proposed obstruction. |
| Provenance and comparators | Bind source AST pointers, current image hashes and historical ST evidence; external Cartan/Weil literature is a comparator only. |
| Failure interpretation | A failure of this minimal frozen source calculus/domain pairing, not a failure of the local catalogs, the historical ST certificate or Spin(10). |
| Result and reproducibility record | Primary and replay frozen separately before comparison; deterministic scientific artifacts separate from timings. |
| Stopping rule | No H-basic dimensions, complete differential columns/matrices, EOM, cohomology, transport, GPU or later gates. |

## Preregistered structural controls

The candidate basic space is an intersection of kernels, not a new quotient.
The contraction is a degree (-1,-1) polynomial odd derivation. Derive the
heavy-ghost zero contraction from the frozen H/complement Weil splitting;
do not infer it just from a name. Keep all six source contractions zero only
where the exact grade envelopes force that result.

First distinguish the Lie action obtained by contracting B_q from the
homogeneous catalog/background action. With B_Abar=0 and iota_Abar=0, the
normalized Cartan generator has Abar fixed and acts affinely on q through
Abar+q. The homogeneous catalog action remains separate immutable authority.

Preregister the source-pairing control F=integral L_u,i u^i, using the certified
evaluation-dual pairing, not a Euclidean identification in the complex frame.
It has dimension 3, ghost number -1, weight 4. Test its basicness and the exact
source-free residual in L_alpha(B F) originating from the light ghost term
with cbar_L, Abar_H, V_H and u_H. Treat independent field values as polynomial
variables, not sampled numerical approximations. Also retain the q*q control
to detect accidental substitution of the background-Ward Lie action into the
Cartan identity.

Inspection of the actual action shows that its light ghost term uses the
ordinary-H image (no V*u term). Therefore no cbar-containing contribution is
assumed in B(L_u). Also preregister F_R=integral L_c,a R_H^a, dimension 4,
ghost number 0, weight 4. R is replaced by its exact u*u definition. Test the
source-free light-ghost Euler derivative in B(L_c), contracted with R, and its
Lie variation with the background held fixed. Check the entire selected
constant-jet component polynomial, not just a guessed sign/formula.

The current reverse source image uses the frozen right odd functional
derivative. Before the background-dependent test, compare its isolated L_c*c
sector to the evaluation-dual Lie lift, together with the current negative
B_R image. Contract B(F_R) in that sector and then substitute the physical
u*u realization of R. This lower-cost zero-derivative necessary test has
priority; do not continue to larger tests if it gives an exact obstruction.

Freeze primary and independent replay before opening both for comparison.
Any exact nonzero residual on a legitimately basic authorized cochain is fatal;
do not cancel it by modifying Sigma, source images, background conventions or
by choosing an unqualified representative/transport.
