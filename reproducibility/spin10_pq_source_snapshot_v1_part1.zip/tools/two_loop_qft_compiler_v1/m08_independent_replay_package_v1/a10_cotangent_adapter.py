"""Inactive exact cotangent pullback. Raw inputs are covectors, never vectors.

The general Sigma map sums signed ordered components. Multiplication by 5!
is a shortcut only on the antisymmetric subspace. Inverses are sections of
the constrained quotient, not inverses on the redundant tensor space.
"""
from itertools import combinations, permutations
import sympy as s
from a10_executable_action import HERE, read, record, digest, SECTORS

ALIASES={'Phi':('Phi',),'Sigma':('Sigma','SigmaBar'),
         'phi':('phi','phiBar'),'S':('S','SBar')}
RANK={'Phi':2,'Sigma':5,'SigmaBar':5,'phi':1,'phiBar':1,'S':0,'SBar':0}
SORTED=tuple(combinations(range(10),5))

def sign(t): return (-1)**sum(t[i]>t[j] for i in range(len(t)) for j in range(i+1,len(t)))

class Adapter:
    def __init__(self, sector):
        self.sector=sector
        row=read(HERE/'frozen_action_ast_a3/A31_embeddings.json')['sectors'][sector]
        self.n=row['domain_dimension']; self.d=row['ambient_real_dimension']
        self.E=s.SparseMatrix(self.d,self.n,{(i,j):s.sympify(v) for i,j,v in row['embedding_entries']})
        self.G=s.diag(*map(s.sympify,row['tensor_metric_diagonal']))
        self.Ginv=s.diag(*(1/v for v in self.G.diagonal()))
        self.names=row['coordinate_names']
        assert self.E.T*self.G*self.E==s.eye(self.n)

    def real_covector(self, raw):
        """raw[alias][ordered address] is an unrestricted complex covector.

        Repeated five-form indices annihilate the embedding. Missing entries
        mean exact zero; unknown aliases/invalid addresses are rejected.
        """
        assert set(raw)<=set(ALIASES[self.sector])
        for name, rows in raw.items():
            for t in rows:
                assert len(t)==RANK[name] and all(isinstance(i,int) and 0<=i<10 for i in t)
        out=s.zeros(self.d,1)
        if self.sector=='Phi':
            for (i,j),v in raw.get('Phi',{}).items():out[10*i+j]+=v
            return out
        size=self.d//2; a,b=ALIASES[self.sector]
        if self.sector=='Sigma':
            positions={t:i for i,t in enumerate(SORTED)}
            sums={a:[0]*size,b:[0]*size}
            for name in (a,b):
                for t,v in raw.get(name,{}).items():
                    if len(set(t))==5:sums[name][positions[tuple(sorted(t))]]+=sign(t)*v
        else:
            sums={name:[raw.get(name,{}).get((i,) if self.sector=='phi' else (),0)
                        for i in range(size)] for name in (a,b)}
        for i in range(size):
            out[i]=s.expand(sums[a][i]+sums[b][i])
            out[size+i]=s.expand(s.I*(sums[a][i]-sums[b][i]))
        return out

    def pullback(self, raw):return self.E.T*self.real_covector(raw)
    def riesz(self, raw):return self.Ginv*self.real_covector(raw)
    def lower_riesz(self, vector):return self.E.T*self.G*vector

    def section(self, canonical):
        """A right inverse: ambient covector G E a, then ordered Wirtinger.

        Its image is a chosen constrained cotangent representative. It does
        not reconstruct components in the kernel of the forward map.
        """
        assert canonical.shape==(self.n,1)
        alpha=self.G*self.E*canonical
        if self.sector=='Phi':return {'Phi':{divmod(i,10):v for i,v in enumerate(alpha) if v}}
        size=self.d//2; a,b=ALIASES[self.sector]; out={a:{},b:{}}
        for i in range(size):
            va=(alpha[i]-s.I*alpha[size+i])/2
            vb=(alpha[i]+s.I*alpha[size+i])/2
            addresses=permutations(SORTED[i]) if self.sector=='Sigma' else [(i,) if self.sector=='phi' else ()]
            for t in addresses:
                weight=s.Rational(sign(t),120) if self.sector=='Sigma' else 1
                if va:out[a][t]=weight*va
                if vb:out[b][t]=weight*vb
        return out

    def definition(self):
        return {'canonical_dimension':self.n,'ambient_real_dimension':self.d,
            'coordinate_names':self.names,'embedding':record(self.E),'metric':record(self.G),
            'covector_pullback':record(self.E.T),'Riesz_to_canonical':record(self.E.T*self.G),
            'canonical_covector_section_to_ambient':record(self.G*self.E),
            'tangent_Riesz_projector':record(self.E*self.E.T*self.G),
            'ordered_rule':'signed permutation sum' if self.sector=='Sigma' else 'identity address map',
            'Wirtinger_rule':None if self.sector=='Phi' else 'alpha_Re=W_z+W_zbar; alpha_Im=i*(W_z-W_zbar)',
            'inverse_domain':'canonical covectors; redundant ambient cotangent modulo ker(E^T)',
            'real_differential_pairing':'bilinear transpose; conjugation is a separate real-structure operation'}

def ordered_jacobian(sector, E=None):
    """Sparse exact Jacobian of every physical ordered alias, from A31 E."""
    a=Adapter(sector); E=a.E if E is None else E
    rows={name:[] for name in ALIASES[sector]}
    if sector=='Phi':
        for (i,j),v in sorted(E.todok().items()):rows['Phi'].append([list(divmod(i,10)),int(j),str(v)])
    else:
        size=E.rows//2; colrows={}
        for (i,j),v in E.todok().items():colrows.setdefault(i,[]).append((j,v))
        for i in range(size):
            positive={j:v for j,v in colrows.get(i,[])}
            for j,v in colrows.get(size+i,[]):positive[j]=positive.get(j,0)+s.I*v
            for t in (permutations(SORTED[i]) if sector=='Sigma' else [(i,) if sector=='phi' else ()]):
                weight=sign(t) if sector=='Sigma' else 1
                for j,v in sorted(positive.items()):
                    if v:
                        rows[ALIASES[sector][0]].append([list(t),int(j),str(s.expand(weight*v))])
                        rows[ALIASES[sector][1]].append([list(t),int(j),str(s.expand(weight*s.conjugate(v)))])
    return {name:sorted(items) for name,items in rows.items()}

def jacobian_certificate(rows):
    return {name:{'nonzero_coefficients':len(items),'sha256':digest(items)} for name,items in rows.items()}
