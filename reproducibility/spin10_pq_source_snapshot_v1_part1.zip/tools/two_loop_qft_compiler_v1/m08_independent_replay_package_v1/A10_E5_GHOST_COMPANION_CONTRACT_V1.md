# Complete leading ghost two-point companion contract

1. Question: does the actual g*xi ghost two-point UV coefficient agree with
   the ghost-only canonical image whose JB-C and Jx-C-x projections passed?
   Include all selected bubbles and quartic tadpoles before giving a verdict.
2. Baseline clean e15219a, statev113/34of39,27 sealed parent chains. Reuse
   qualified action, full643 Hessian/reference, source vertices, representations
   and canonical candidate; do not repeat expensive accepted computations.
3. Keep all643 field/source pairs,48 H backgrounds,34 physical/nine source
   terms, vacuum/potential, xi width and cubic, nonsymmetric coset and R_H.
   No auxiliary elimination, physical parameter change or new canonical field.
4. Freeze physical ghost/antighost frames:45 ghosts,12 light antighosts plus
   33 heavy dual antighosts; mixed B-L Green nonzero, L-L zero. Canonical
   evaluation sources and invariant carrier metrics remain different types.
5. Inventory literal source-free E2 cubic terms at g and quartics at g*xi.
   Retain derivatives on antighost, ghost and gauge field; combine their full
   Fourier vertices, not one convenient representative. Authenticate positive
   dimensional orbit/mass terms and prove why they cannot change this selected
   kinetic UV logarithm. Background/source fields are zero only in the selected
   amplitude; their full records remain protected.
6. Primary graded Hessian/Born loops and replay independent Gaussian/Wick
   contraction with physical commutators must agree. Include both possible
   assignments of external antighost/ghost to the two cubics and the full
   quartic tadpole. Retain odd signs, momentum routing and all four Lorentz
   weights. No scaleless zero-momentum bubble used to infer a kinetic pole.
7. At nonzero Euclidean q derive heat-cutoff bubble, paired one-denominator
   integral and single tadpole separately. Keep UV powers, q^2 log coefficients
   and finite remainder distinct. Compare dimensional scalar residues only
   after separating momentum-independent tadpoles from the kinetic coefficient.
   A vanishing dimensional scaleless tadpole is not a whole UV/IR proof.
8. Derive actual full ghost-pair group matrices and H-zero channels, preserving
   the heavy nonminimal primal/dual maps. Compare every admitted kinetic entry
   with the qualified N=kappa_aux G_M source-normalization candidate. Require
   a nonzero Euler witness if they disagree; no boundary/EOM excuse.
9. First-failure stop: a genuine ghost-only normalization mismatch stops
   before JC-C-C or JB-B-C loops and before adopting a replacement. Preserve
   matched source poles and every failed/unfinished run. This is a verdict on
   that restricted normalization, not automatically on the action or full BV.
10. A separately labeled nonminimal pairing/doublet control may identify the
    next typed normalization direction; it is not a fitted full-loop repair.
    No complete restoration, anomaly/IR, A4/A5, M2--M5/E5/HB1/C5/C1_GS claim.
11. Distinct routes, negative controls (missing assignment/quartic, wrong odd
    signs, metric/Gram, symmetric coset, zero momentum), strict start hashes,
    immutable evidence, fresh own-byte replay,27 parents and protected/state/
    new SHA plus metadata checks. Custody2/seven, never PASS.
12. Shared data, arithmetic, Python/SymPy and analyst disclosed; solo review.
    No activation, catalog, authority change, outreach, publication or push.
    Validate completed bounded work before local commit. Whole goal remains.
