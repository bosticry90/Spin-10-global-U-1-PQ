# Executable covariant action and source reconciliation contract

The owner's assessment of `cadfca2` authorizes this new inactive continuation.
The historical Phase C stop and frozen A10 failure remain in force. This work
does not activate a replacement, change the formal ledger, or resume HB1/C5.

Authenticate the completed candidate, mixed-source and canonical-map evidence;
reuse their qualified expensive representation calculations. Preserve running
and uncommitted work. No reset, remote push, personnel outreach, frozen edit,
catalog rebuild, pole calculation or finite C1_GS calculation is authorized.
The solo-review policy applies; missing personnel is not a scientific stop.

Acceptance is conditional and ordered:

1. A: encode all four kinetic sectors, normalized curvature and 29 unchanged
   potential contractions in a separately named executable 14-node AST. Lower
   coupling parameters and Hermitian completions explicitly. The parent record
   fixes L=T-V. Compare local coefficients and parameter dependence directly
   with the factorized candidate, rather than using invariance as equivalence.
2. B: require the full factorized local Ward identities and independent exact
   component replay of selected expanded sectors. Retain the frozen A10
   variation and its nonzero Euler derivative. Vary connections before zero
   projections; retain nonzero-connection cubic and quartic controls.
3. C: implement the actual shift and compare orbit, mass and mixing
   coefficients. Reuse the inherited rank/spectrum with their original scope.
   Verify the bounded R_xi cancellation; it is not the complete partial gauge.
4. D: derive one complete canonical candidate master action, all sources and
   nonminimal partners, and the simultaneous component maps. Require the
   master-functional divergence, full-source nilpotence and evaluation pairing.
5. E: only after D, reconcile partial gauge fixing, H-only background, composite
   R_H chain rules, canonical transport and joint-domain preservation. No
   counterterm/catalog completeness follows from structural preservation.

Stop at the first exact failed or undefined prerequisite. Preserve the smallest
witness and independently replay it. Do not invent a needed input, silently
fit a coefficient, or treat an implementation limitation as a physical no-go.
Document shared data, analyst, libraries and runtime. Commit locally only after
validating the completed bounded evidence and unchanged historical controls.
