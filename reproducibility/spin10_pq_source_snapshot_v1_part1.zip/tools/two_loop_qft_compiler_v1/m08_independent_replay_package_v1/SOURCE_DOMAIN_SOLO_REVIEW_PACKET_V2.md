# Source-coordinate and transported-domain technical review questions

Current version V2, 2026-10-10. Supersedes the outreach/personnel disposition of `SOURCE_DOMAIN_SPECIALIST_REVIEW_PACKET.md` under [the owner's solo-review policy](../../../docs/SOLO_REVIEW_POLICY_V1.md). Retain its mathematical questions; no personal contact, recruitment or external-participation gate applies. Historical bytes remain unchanged. This packet does not resume Phase C or promote a replacement.

Status: retained for solo technical review. No outreach is planned; no external review or endorsement has occurred. This packet accompanies an inactive bounded candidate; it does not request approval of the physical Spin(10) hypothesis.

## What needs independent scrutiny

1. Does the declared bracket, `z_star=(-1)^p J`, left Hamiltonian action and field-only gauge-fermion shift define one coherent convention for local functionals? Check the signs using an independent BV convention, not a preferred zero residual.
2. In the actual nonorthonormal H frame, is `J=G_H k` the correct evaluation-source bridge for each historical component decoder? Which frozen source contractions, if any, already implement G implicitly? A representation label or intertwiner does not establish a canonical bracket.
3. Does the joint domain `ker Tq intersect ker iota intersect ker Tb`, before light fixing and then transported, express the intended quantum cohomology and background Ward problem? Could simultaneous quantum/background requirements exclude needed source-bearing counterterms? The current control proves preservation, not physical completeness or necessity of this domain for renormalization.
4. What extra assumptions are needed to extend the one-derivation source-kinematic test to the full four-dimensional physical action, affine background packets and their IBP/conjugation quotients? All local parameter jets must be accounted for.
5. How should partial gauge fixing, the nonsymmetric coset, derived RH and heavy antighost/auxiliary partners be combined with the corrected shifted-scalar action? Keep independent-parameter cotangent variation distinct from varying a field-dependent Hamiltonian after substituting `omega=-g10 RH`.
6. Can the prospective nine pair types be related to the six historical source couplings through a qualified map, or is a versioned enlarged algebra needed? Setting new sources to zero is not assumed to define a differential ideal or a physically neutral restriction.
7. Before any promotion, identify the dependency impact on all 17 historical roles, source coefficients, gauge fixing, master identities and catalog coverage. Preserve the original -2i, +1, -box(u), scalar +1 and Sigma-nonhorizontal controls as immutable historical evidence.

## Evidence and its limits

See [candidate contract](SOURCE_DOMAIN_TRANSPORT_CONTRACT_V1.md), [result](SOURCE_DOMAIN_TRANSPORT_RESULT.md) and `frozen_source_domain_transport`. The primary uses an exterior/SymPy-even-coefficient engine and Hamiltonian source lifts. Replay reconstructs physical matrix commutators, uses ordered words/Euler variation and direct cotangent matrices. They share model/convention, Python, SymPy and analyst; they are not external specialist verification.

The current test uses a closed actual-H block, external background, a homogeneous adjoint scalar and one ordinary derivation. It includes no heavy coset or physical kinetic/potential action. Passing it cannot promote a complete M08 master action, H-basic domain or enlarged catalog.

Relevant primary methodological comparators are [Gomis, Paris and Samuel](https://arxiv.org/abs/hep-th/9412228), [Ferrari](https://arxiv.org/abs/1308.6802) and [Thomsen](https://arxiv.org/abs/2404.11640). Their constructions motivate the review questions; none endorses this implementation. Solo review must seek counterexamples and mismatched assumptions in the derivations and published literature, beyond successful software tests.
