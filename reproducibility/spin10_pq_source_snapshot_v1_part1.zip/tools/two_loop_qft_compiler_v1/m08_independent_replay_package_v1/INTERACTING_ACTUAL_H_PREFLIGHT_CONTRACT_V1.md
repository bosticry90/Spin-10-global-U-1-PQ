# Phase A/B interacting actual-H preflight contract

## Authorization, purpose and boundary

The owner's execution request following the assessment of `9aa54c8` authorizes Phase A and conditional Phase B only. This contract instantiates those phases, not Phase C. All constructions here are inactive comparators. The historical Sigma, six couplings, 17 images, catalogs, sole authoritative project state, `34/39` ledger and uncalculated finite C1_GS remain unchanged.

- Physics decision enabled: determine whether an interacting actual residual-H connection/source sector supports the proposed architecture before any complete M08 reconstruction.
- Blocker narrowed: compatibility of gauge dynamics, canonical nonminimal sources, local quantum/background actions and simultaneous gauge-fixing/domain transport in this bounded sector. No full-M08 blocker is cleared.
- Why existing evidence is insufficient: the actual-H domain control has no kinetic action; the interacting controls use different gauge algebras.
- Minimum implementation: a finite architecture record, two bounded builders, an evidence audit, regression controls and a result/review packet. Reuse the qualified exact graded engines and authenticated geometry/decoder inputs.
- Structure preservation: inverse component maps, evaluation pairing, conjugation, induced bracket, grading, all canonical source cross-pairs, local operator identities, ordinary derivatives and functional divergence certificates.
- Stop: the first failed or underdetermined prerequisite. A Phase B pass permits only a later owner decision, not automatic Phase C.
- Failure disposition: retain the inactive candidate and exact counterexample. Delete no historical evidence and activate no source.

## Phase A finite architecture

The seed is `[0,4]`, closed under physical brackets, the Gram pairing and conjugation. The permitted result is `[0,1,4,11]`; any enlargement stops the task. Fundamental antisymmetric SO(10) matrices are normalized by `1/sqrt(2)`. The invariant pairing is `G_ab=-Tr(T_a T_b)`, agreeing with the C3 raw-coordinate Gram matrix. Verify nondegeneracy, all restricted commutators, invariant pairing and conjugation rather than projecting unclosed terms away.

The complete candidate pair-type inventory is the six historical pairs plus prospective antighost/auxiliary partners. Reuse the six decoder maps without replacing their expectations. The prospective partners are specified, not activated:

| Field | Candidate evaluation source | Internal count | Source (dimension, ghost, parity) |
|---|---|---|---|
| heavy antighost, in the declared dual C3 field frame | J_ubar / K_ubar | 33 | (2,0,even) |
| light antighost, in the declared primal C3 control frame | J_bar / K_cbar | 12 | (2,0,even) |
| light auxiliary, in the declared primal C3 control frame | J_b / K_lambda | 12 | (1,-1,odd) |

The light choice is an explicit candidate coordinate choice, not a claim that the historical antighost/auxiliary AST already used those components. INT12's dual typed columns are converted through their actual physical embeddings. Let `B` be the C3 frame, `L=(B^T B)^-1 B^T`, and `BD=B(B^T B)^-1`. Typed primal/dual columns and extractors are `P,A,DP,DA`, reconstructed using INT8/REG7. For heavy ubar choose `F=BD, FL=B^T`; for light bar/b choose `F=B, FL=L`. Their typed field is `X=DP, XA=DA`, and prospective typed source is `Y=P, YA=A`. Define exactly:

```text
z_candidate=T z_typed,       T=FL X,        T^-1=XA F
J_candidate=E k_typed,       E=F^T Y,       E^-1=YA FL^T
E^T T=Y^T X;                J_candidate^T z_candidate=k_typed^T Y^T X z_typed.
```

Prove both inverse products, physical reconstruction and conjugation. Source-only changes induce the unsigned bracket `E^-T`; simultaneous field/source changes induce `T^-1 E^-T`. Never retain an identity bracket in incompatible coordinates. New macro source carriers use the physical evaluation frame; they do not acquire historical status merely from a label. Constant maps prolong through all ordinary derivatives. This freezes the candidate pairings needed here; full interacting nonminimal AST reconstruction and heavy/light partial fermions belong to Phase C, not this control.

Canonical fields have grades `(d,gh,p)`: q `(1,0,0)`, c `(1,1,1)`, bar `(1,-1,1)`, b `(2,0,0)`. Each evaluation source J has `(3-d,-1-gh,1-p)`. Canonical antifield is `z_star=(-1)^p J`. All coefficients are exact; g10 and xi are even dimensionless formal parameters, not fitted numbers. The background is external, dimension one and Q-inert. Independent omega/beta are even dimension-zero local parameters, with independent symmetric ordinary jets.

The inherited comparator serializes this control's `xi` as the symbol `eta_H`. This is a declared notation alias, not an identification or modification of M08's physical light/heavy gauge-fixing parameter conventions.

The functional bracket and left odd derivation are exactly those of the proposal:

```text
(F,G)=sum_z (-1)^p [EL^R_z(F) EL^L_J(G)-EL^R_J(F) EL^L_z(G)]
Qz=EL^L_J(S), QJ=EL^L_z(S), Q(FG)=Q(F)G+(-1)^p(F)F Q(G).
```

## Frozen Phase B action and operations

The block has four internal indices and four spacetime directions, metric `diag(1,-1,-1,-1)`, 28 canonical field/source pairs (56 generators) and 16 external background components. This Lorentz convention is declared for the control, not a new certification of all historical Lorentz packets. q has 16 components; c/bar/b each four. There is no scalar, heavy coset or R_H in this test.

Use lower-index connections and `B_mu=Abar_mu+q_mu`:

```text
F_mn=partial_m B_n-partial_n B_m+g10[B_m,B_n]
S0=-1/4 sum_mn eta_m eta_n F_mn^T G F_mn
Qq_mu=partial_mu c+g10[B_mu,c]
Qc=-g10[c,c]/2; Qbar=-b; Qb=0; QAbar=0
Smin=S0+sum_z J_z Qz                  (source-left ordering)
psi=bar^T G (sum_mu eta_mu Dbar_mu q_mu-xi b/2)
U J_z=J_z-(-1)^p EL^L_z(psi), U z=z; inverse has opposite shift
Sfixed=U Smin                         (do not silently substitute a different density).
```

The fixed density may differ from `Smin+Qpsi` by an explicitly reconstructed divergence. The two must be compared, not assumed identical as densities. Both master residuals require four-component reconstructed currents and zero Euler residuals; Euler-null alone is insufficient. Include external background and parameter jets in the divergence certificate, not equations of motion.

Derive local field actions from these conventions and source actions by cotangent lift, not source names:

```text
Tq Abar=0; Tq q_mu=partial_mu omega+g10[B_mu,omega]
Tb Abar_mu=partial_mu beta+g10[Abar_mu,beta]; Tb q_mu=g10[q_mu,beta]
Tq/Tb z=g10[z,parameter] for c,bar,b
I_generator=J_c^T omega+J_b^T g10[omega,bar]; iota=(I_generator,-).
```

Parameters remain independent during source differentiation. This control does not contain a field-dependent R_H substitution; the previous substitution-chain witness is retained as reused evidence, not retested here.

Test `Q^2=0`, `{iota,Q}=Tq`, `iota^2=0`, `[Tq,Q]=[Tb,Q]=0`, local Lie closure with composite bracket parameter `g10[beta,omega]`, contraction covariance, curvature covariance and action Ward invariance. Transport Q, iota, Tq and Tb by U simultaneously. Tb may remain raw only after the explicit commutation proof. Test all 56 generators before/after fixing and their first ordinary jets. Higher jets follow by commuting derivations, with a jet safety limit that raises an error, never sets a high jet to zero.

The preregistered source-bearing domain functional is `Fcontrol=integral J_b^T F_01(B)`. It has grade `(3,-1,odd)` and a nonzero Q image. It is a tensor-component functional diagnostic, not a Lorentz-singlet C5 counterterm or a cochain-catalog entry. Require pre/fixed joint constraints and the Q intertwiner. A wrong raw post-fixing source action is a negative control; if its residual is nonzero require a nonzero Euler derivative before saying it is not IBP-null.

## Domain, order of gates and independent replay

`Dpre=ker Tq intersect ker iota intersect ker Tb` for all independent local parameters/jets on local functionals modulo ordinary total derivatives; `Dfixed=U Dpre`. Prove preservation from verified generator identities and prolongation. This establishes a bounded domain-preservation theorem, not completeness of the full M08 counterterm domain, conjugation/packet/catalog descent or C5.

Gate order: authenticate inputs and Phase A maps; reproduce free omitted-partner obstruction; derive interacting columns; test pre identities/master; canonical gauge fixing and fixed identities/master; nonzero domain control; independent comparison. Preserve the earliest failure and do not run later scientific gates after it. The free omitted-partner witness in evaluation coordinates is `Q^2 J_b=-G Box c`; the raised expression is `-Box c`. This is the same free mechanism in certified coordinates, not a fitted coefficient.

Primary uses exterior/Euler algebra and Hamiltonian local lifts. Replay uses ordered words, direct cotangent matrices and physical matrix commutators, with no import of primary columns/residuals. Freeze outputs separately before comparison. Shared SymPy, Python, input conventions, physical data and analyst remain disclosed. No external specialist review is claimed. Consequential specialist objections must be settled before full-M08 promotion.

## Evidence and stop

Bind unchanged historical negative controls and all 156 inherited byte expectations. Identify their reuse explicitly; no claim that historical calculations were rerun. New bounded evidence must regenerate byte-identically. Audits are read-only under the pole-blind guard, with selected hashes and before/after workspace/active-data metadata. Metadata inventories are not an all-byte audit. Strict custody exit 2 remains unresolved independently.

Record wall/CPU/peak memory, available OS I/O and stage timings. Mark uninstrumented parsing, cache and exact-linear-algebra counters unavailable rather than inferring percentages. No GPU, T5 rebuild or unrestricted --all validation is required. Stop after Phase A/B adjudication and local commit; do not push.
