# Source-fixed derivative extension: both measured companions now match

AD1 qualifies the full source-fixed inactive derivative generator and its
single canonical flow. AD2 matches all existing tested companions, including
the source–gauge and derivative-gauge poles that the old member missed. This
is a bounded inactive extension, not adoption, fullE5/A5, quantum restoration,
physical interpretation or completion of Spin(10) x global U(1)PQ research.
project_state.json v113/34 of39 remains sole authority.

The source pole fixes P=diag(0,C_H). The prospective completion is
K_D=g10^2 sum_i J_Lambda,i (P D_(B_H).B_M)_i. Primary recovers the actual
heavy gauge-fixing function from the pure-B component of QJ_Lambda; replay
rebuilds it from physical10 commutators. In the real frame it is
sum_mu eta_mu[partial_mu B_M^mu+g10 ad(B_H^mu)B_M^mu]. Both B_H and external
A_H have the inherited connection transformation. The input gauge-fixing
function uses B_H; replacing it with A_H adds a homogeneous B_H-A_H ambiguity
not fixed by the source pole. No full-generator uniqueness is claimed.

K_D has848 raw/2,328 physical terms, grade(3,-1,odd). The full Q image has
47,532 raw terms throughg^4, with all source/field/jet/width descendants.
Literal prefix Q and independent full action first variation agree modulo
the exact stored current. On a unit J_Lambda partial B, the bracket gives
Lambda shift=-partial B and J_B shift=-partial J_Lambda. QK+delta_Y S is
the divergence of -J_Lambda QB; it is not a pointwise zero density. The four
full currents are retained in the image and complete member. The imported
dimension-one OrbitPullback image is reconstructed exactly from E1 and
separated from the dimension-four word grade; no arbitrary grading exception.

All local-H parameter and parameter-jet coefficients cancel. Removing the
connection completion leaves an exact nonzero parameter-jet residual. Reality
and source/dual/primal frame roundtrips pass. The source-fixed coefficient
dependency is the qualified actual source-gauge result; image construction
does not read the other actual companions or old candidate until comparison.

The exact triangular flow changes32 integrated auxiliaries and176 gauge
sources (208columns); all gauge fields and auxiliary sources stay fixed.
All1286 canonical generators have2,572 two-direction inverse checks;832
first-jet checks and a nonzero omitted second-product-jet control pass.
Differential field/source kernels use a full formal-adjoint IBP identity
with arbitrary smearing fields. Every source/source Hessian block is checked
with two independent smearing families, with no bare-generator shortcut.
Wrong source-adjoint sign leaves a nonzero residual. Other pairs are zero by
complete dependency support. The integrated-field Jacobian has only a
B-to-Lambda off-diagonal block N, with N^2=0 and strN=0 after every
type-preserving finite-mode/heat projection: this single flow has Berezinian1.
The old joint regulated measure is retained separately. No exact finite
combined-old-flow inverse or quantum A5 follows from this single map.

Complete new inactive member has1,354 generator words and95,155 candidate
words. Its full source–gauge2025 coefficients and derivative-gauge182250
coefficients match the measured poles, including zeros, coupling/width
coefficients, allfour polarizations and both independent three-point
derivative placements. New derivative temporal/effective/current counts
are1,232/692/436; source effective count32. Residuals in both scopes are zero.
The prior auxiliary91125, nonminimal-source91125 and g^2 quartet980100
matches, plus all earlier lower source/kinetic/mixing/width/cubic scopes, are
preserved. Omission restores the old derivative obstruction; wrong generator
sign fails the source companion; wrong coupling degree changes old orders.

All unmeasured image terms remain in a complete coupling/word/jet/source
inventory. The total pure g^3 four-ghost prediction is unchanged966raw words;
it is not an actual loop calculation. Newly predicted g^2 source-J_Lambda
two-derivative ghost, longitudinal gauge/auxiliary mixing and higher source/
field/scalar companions remain untested. No new actual loop ran here.

Validation receipt owns scientific/process/governance tests, delegatede5,
FOUR strict own-byte fresh routes (unit,primary,replay,comparison),39
protected predecessor chains, unchanged new/protected/state bytes and
size/mtime inventory. Custody remains expectedexit2/seven unresolved refs,
neverPASS. Old expensive loops/125basis images authenticate without replay.
Raw Git index/worktree bytes must agree before localcommit. Preparations,
attempts, receipt and bindings retain exact hashes/start/code/output/runtime.
Any failed/unfinished validation attempts remain separately classified.

Shared inputs, exact arithmetic, Python/SymPy and analyst limit independence;
these are distinct mathematical routes, not independent scientists. Selected
image/flow and companion matching have bounded verification; proof-assistant
formalization not attempted; broader interpretation/explanatory compression
and empirical connection remain open/none. No physical/catalog/HB1/C5/C1_GS/
matching, promotion, adoption, outreach/push/publication. FullE5/A5/Ward/
contact/IR/anomaly, global scalar/PQ,fermion/Yukawa/phenomenology and fullgoal
remain unfinished under local conventions, ladder and solo-review policy.

Next smallest scientific action: a separate prospective actual g^2
auxiliary-source/ghost two-derivative companion, retaining all45x45 directions,
full source-quartic tadpole/bubble/reference/UV classifications, masses and
different derivative representatives in their proper scopes. Compare its
complete independently calculated pole with this frozen member; first
mismatch stops. The unchanged g^3 quartet prediction also requires a later
separately contracted actual calculation. Do not promote either prediction.
