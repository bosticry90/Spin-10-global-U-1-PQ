# E5 exact reference-width binding and preserved formal loop evidence, V2

This supplements V1, not its scientific scope, first-failure rule or authority
ceiling. Original primary/replay formal-width tensors agree exactly. Both
completed original outputs remain immutable. Their later canonical densities
failed the dependent reality check: sympify(text) creates an unassumed width
symbol, distinct from the declared real reference_width_H/M, so substitution
by the real symbol missed it. Comparison attempt1 is FAILED and unaccepted;
all source/preparation/stdout bytes and wrong densities remain preserved.

Freeze a new exact binding module, runner/exporter, both completed formal-loop
output hashes, V1/V2, predecessor and state hashes BEFORE binding computation.
No group/loop coefficient, vertex, propagator, source candidate, physical
parameter or normalized group tensor changes. Original execution bytes remain
unchanged. Primary-bound and replay-bound workers independently read only their
immutable original formal triangle and curvature-bubble tensors; parse with
explicit real-symbol locals, retain every width power, then bind width_M=xi
and width_H=eta_H. No rounding, residual fitting or premature actual agreement.
Recheck full density reality, all12 H identities and raw/physical roundtrips.
The derivative/auxiliary Lorentz, UV, edge and elementary proofs remain V1.

Only after both completed bound tensors agree, compare against the full g^2
projection of the already unique inactive candidate. Save full actual-minus-
candidate and independently checked nonzero real auxiliary Euler evidence on
first mismatch. Stop before new primitives, derivative-gauge or higher orders.

Before local commit, reproduce the ORIGINAL full actual primary and replay
calculations with their exact original starts and own bytes. This validates
the formal tensors and reproduces their classified binding defect; it does
not qualify the defective canonical density. ALSO freshly reproduce both new
bound routes and the dependent corrected comparison with their own exact
starts/bytes. Five successful fresh executions are required, and the original
failed comparison is never counted as PASS. Targeted scientific/process/
governance checks, all35 predecessor chains, unchanged state/metadata and
custody exit2/seven remain mandatory. No scientific acceptance obligation is
removed to avoid repeating the old full loops; qualified formal tensors are
reused only in the new binding computation.

Possible dispositions and original whole Spin(10) x global U(1)PQ objective,
solo-review limits, no activation/catalog/HB1/C5/C1_GS/matching/push/publication,
and v113/34 of39 authority are unchanged. A successful evidence audit may
authenticate an exact failed candidate gate, without accepting a subtraction,
quantum A5, physical interpretation, formal proof or empirical result.
