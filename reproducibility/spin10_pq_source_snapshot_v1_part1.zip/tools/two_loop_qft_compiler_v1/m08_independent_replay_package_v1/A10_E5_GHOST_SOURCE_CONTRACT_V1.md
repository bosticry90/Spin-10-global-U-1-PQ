# Actual leading ghost-source pole and measured Slavnov test, GS V1

Baseline791ddbe2739439fe6ee8af5df0838a45aa34ff7c. Previous turn PROGRESS:
the measured-functional assembly identifies the missing g^2*xi JC-C-C pole
in the leading two-jet ghost Slavnov projection. Freeze this NEW prospective
actual calculation, not a fit to that projection or the stopped g^3 quartet.
project_state.json v113/34of39 and its bytes remain sole scientific authority.
The whole Spin(10) x global U(1)PQ investigation stays active/incomplete.

GS1: calculate the actual one-loop dimension-zero, no-jet coefficient of
J_C C C at g^2*xi, in common hbar*g10^2*xi/(32*pi^2*epsilon_UV) units.
J_C is an EVEN external BV source, dimension2/gh-2; both ghosts are odd,
dimension1/gh+1. The density is (4,0,even). All45source directions and
45ghost directions,45*choose(45,2)=44,550 antisymmetric pair coefficients,
including independently established zeros. No source Legendre transform or
source inverse. No additional canonical/background/PQ gauge variables.

Immutable inputs: full qualified source/GF/physical E2 action,643 pairs,
48 external H background components, full real primal/dual charts, physical
10-by-10 parent commutators, leading reference and43 sealed predecessor
chains. Actual routes use own literal/geometry inputs; no measured-functional,
counterterm, candidate, peer or required-completion tensor is an actual input.
Byte-only ancestor authentication is distinct from interpreting pole data.

First recover every literal source and GF coupling/field/jet signature.
Source JC vertices are the g*JC*C*C cubic. In a proper one-loop three-external-
leg cycle, n3+2*n4=3 and each vertex has at least two integrated incidences.
At g^2*xi the complete nonzero eligible families are:
(1) all six Born orderings of the source cubic, derivative gauge/ghost cubic
g and auxiliary/antighost/ghost cubic xi, including both external-ghost
assignments and both odd starts;
(2) both Born bubble orderings of the source cubic and full g*xi four-ghost
vertex, including the anomalous CC/aa Hessian blocks and every split.
Source/external-ghost assignments leaving one integrated incidence are 1PR,
not this proper coefficient. Retain and justify other families: curvature
quartic has g^2*xi and gives higher g with the source; ordinary gauge quartic
cannot supply two external ghosts; pure bosonic cubics cannot supply the
required external ghost at their proper three-cubic valence; positive-
dimensional scalar/Orbit/mass insertions lower this dimension-zero UV degree.
Do not use predicted zeros to select source rows or graphs.

Keep the complete derivative-on-antighost/gauge/ghost GF vertices and their
IBP currents. At leading no-external-jet order the external ghost derivative
is zero by UV selection, not deletion of its literal vertex. The mixed edge
forces the quantum gauge direction to M; prove the full H/M reference-edge
screening AFTER all45 directions are built. Source H rows can contribute.
The triangle has two odd inverse edges and a mixed B/Lambda edge; bubble
has two odd edges. Retain BB, BL/LB, LL=0 and both odd orientations before
screening. No BB survives these two families, so arbitrary light/heavy widths
drop through edge structure. No general transverse or higher-amplitude zero.

Primary: literal source/GF pullback, ordered left Euler/Fourier Hessians and
complete graded Born traces. Replay: independent normalized physical10
commutators, actual source-variation sign and independently reconstructed
projected cubic/quartic vertices, with own literal crosschecks before loops;
explicit routed Gaussian/Wick contractions and antisymmetric tensor sums.
Full four-Lorentz elementary Born/Wick controls qualify both family weights,
derivative-placement signs, source parity and opposite ghost assignment.
Never assume projected M adjoint Jacobi. Shared inputs, some exact word/ring
arithmetic, Python/SymPy and analyst disclosed; no independent scientists.

Exact Q[sqrt2,sqrt3,sqrt5,I,formal real reference widths] arithmetic, no
numeric tolerance or width/group cutoff. Polynomial external-source degree1
and ghost degree2 are the complete selected homogeneous projection: higher
degrees cannot return to it under multiplication. Keep all coefficients
within that projection, not a resource truncation. Resource limits mean
INCOMPLETE. Real/canonical frame roundtrips, real source pairing, complete
44,550 coefficient comparison and all12 homogeneous/local no-jet H identities.
Store normalized coefficients AND full g^2*xi densities with explicit units;
the degree gate must reject a missing or double coupling factor.

UV only k_E^2>R_UV^2>0 above external/mass scales, leading degree-4;
triangle/bubble heat profiles6/4 and common Minkowski radial factor
i/(16*pi^2*epsilon). External momentum/mass remainders are convergent in this
coefficient. No whole-scaleless, finite/IR, cutoff-power/mass-log, chiral
anomaly or full regulator-restoration inference. Preserve other scopes.

GS2 only AFTER complete actual-method agreement: add this actual density to
the frozen measured residue at791ddbe and compute the full g^2 aCC/two-jet
Slavnov LEFT SIDE in the3,539,700 raw canonical jet-monomial domain. Equal
ghost colors at unequal jets remain distinct. Use the actual1286 E2 columns
and the previously qualified backward census/projector-support proof; no
physical Euler program is silently zero. Compare separate prefix and graded
jet-gradient variations. Move antighost jets by ordinary IBP with all currents,
verify independent antighost Euler identities on all45 directions, and record
the full raw and anchored residual. A raw nonzero boundary must not be called
a functional discrepancy. No EOM quotient.

Question: does the enlarged MEASURED left side vanish as a local functional?
Do not require it by fitting. Retain Gamma_unknown and Delta_s/Delta_b,
regulated measure/breaking insertions and scope complements; none is set to
zero. Zero left side qualifies only this selected residue/functional test,
not complete quantum Slavnov restoration. Nonzero anchored residue is an
exact stopped open obligation with a real signed Euler witness, not by itself
an anomaly or a defective physical model. Stop before any fit, image change,
higher/physical loop or normalizer adoption. The prior g^3 failure stays FAIL.
Local Ward partners JB-B-C/A_H, higher sources, contacts, nonlinear higher
Slavnov orders, W5 whole-product insertions, W6 source/operator transport,
A1-A5, quantum equivalence, full E5 and IR remain unqualified.

Negative controls: omit a nonzero family or ghost assignment; omit mixed or
one odd orientation; use wrong source parity, source/dual chart, loop sign or
coupling units; drop anomalous quartet block/current; treat equal-color
unequal-jet ghosts as nilpotent; replace unknown partners/breakings by zero.
Each control must have a nonzero exact discrepancy or an explicit type
rejection. Completed source/fingerprint/full stdout/preparations must be
preserved for every failed/unfinished execution with its classification.

Validation: four own-byte fresh controls/primary/replay/comparison, meaningful
scientific/process/governance and delegated research_check.py e5;43 protected
chains, new/protected/state and size-mtime invariance, custody exit2/seven
unresolved references neverPASS. Old expensive loops/images authenticate
only. Raw Git index/worktree equality before local commit. No reset, evidence
edits, unrelated process termination, physical/catalog/HB1/C5/C1_GS/matching,
authority promotion, publication/push/outreach or whole-goal completion.
Possible dispositions: qualified actual source pole with zero selected
measured Slavnov left side; qualified pole with preserved nonzero open
projection; stopped derivation/type gate; underdefinition; incomplete run.
