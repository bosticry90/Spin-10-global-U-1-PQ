# E5 retained-source one-loop Hessian and finite-cutoff contract

1. **Question.** Can the complete qualified E2 action be given a faithful
   graded fluctuation Hessian and an explicit UV-finite one-loop expansion,
   retaining every source and heavy/light interaction? What are its actual
   background/Slavnov identities and g=0 source limit before restoration?
2. **Baseline.** Clean2f1bdf2,statev113/34 of39,24 sealed predecessor chains.
   The failed fractional action-kernel candidate is not used. Bind the actual
   34 physical terms, nine source terms and E2 gauge-fixing correction.
3. **Alphabet.** All643 integrated fields (553 even,90 odd),643 external BV
   evaluation sources and48 external H backgrounds. Introduce two independent
   graded test-direction families h,k with each field's parity. They are not
   new physical fields or canonical pairs. External sources/backgrounds are
   fixed during fluctuation differentiation; their symmetry action is retained.
4. **Complete Hessian.** Produce the mixed second-variation program for all34
   physical terms, preserving embeddings, tensor, jet and Lorentz contractions.
   Independently polarize every source/gauge-fixing polynomial coefficient.
   Primary direct double variation; replay variation of qualified Euler columns
   plus the explicit first-variation current. Require full coefficient/hash
   equality, graded symmetry, no sampling or silent resource truncation.
5. **Reference propagator.** Derive the full gauge/auxiliary and odd ghost
   matrices, scalar reference masses and their constant physical/C3 frame maps.
   Reuse the qualified constant45-frame inverse and factor the12/33 carrier
   blocks and unchanged scalar coordinates; a generic dense inverse is not a
   proof obligation. Verify both inverse directions for all643 coordinates, correct odd signs,
   no inverse physical width or g, and zero auxiliary-auxiliary propagation.
   Auxiliaries and ghosts remain in the operator; do not eliminate them.
6. **Finite-loop construction.** Choose an actual H-covariant positive heat
   cutoff F_Lambda and define G_Lambda=F_Lambda G_ref F_Lambda^ST on the full
   retained graded space. One-loop interaction terms are the complete Born
   traces of (G_Lambda delta H)^n/n, with the reference background/vacuum
   determinant recorded separately rather than silently discarded. Reference
   masses/UV and IR cutoffs are temporary outside the polynomial cochain ring.
   Define the nonexceptional/IR-regulated formal domain explicitly; no physical
   IR-limit, vacuum, continuum measure or all-order restoration theorem follows.
7. **Ward/Slavnov typing.** Derive the Hessian congruence identity using the
   full field/source master identity, including the physical-source variation
   which cancels nonlinear R second derivatives. Background H acts on the
   actual reference and cutoff. Quantum BRST holds backgrounds fixed. Retain
   expected finite-cutoff breakings and their composite insertions. A bare
   Jacobian trace or scalar heat-kernel control is not full quantum restoration.
8. **g=0 and source test.** Derive the complete source-dependent Hessian's
   g power, not a fitted rule. At g=0 the actual affine source dependence must
   give zero fluctuation Hessian for source terms, while the xi ghost vertex
   remains. Show how this finite-loop prescription preserves that source
   normalization; do not infer all composite/contact/A5 equivalences.
9. **Negative controls.** Freeze sources during Hessian differentiation but
   do not freeze their BRST variations; incorrect odd signs, missing currents,
   lost Lorentz weights, ambient/complex trace shortcuts, omitted R_H/cubic,
   deleted auxiliaries, exponentiating a non-Laplace Hessian as a positive
   scalar kernel, or equating finite-cutoff breaking with anomaly failure.
10. **Routes.** Independent graded directional and Euler/IBP constructions,
    physical/indexed kinetic derivations and ordinary even polynomial replay.
    Reuse accepted geometry/basis/master proofs. Record complete exact coverage
    and genuinely distinct controls while disclosing shared inputs, arithmetic,
    Python/SymPy and analyst. Primary published literature supports methods.
11. **Stop and ceiling.** Stop on an unexplained mismatch or missing essential
    type; preserve exact failed/unfinished starts. Qualification of Hessian and
    finite-cutoff identities does not qualify restored M2--M5,anomaly freedom,
    all source/contact/A5 identities,E5,HB1/C5,C1_GS,matching or the complete
    particle model. No source activation/removal,parameter reset,catalog,
    authority change,personal contact,publication or push.
12. **Validation.** Start hashes before all calculations, two immutable route
    outputs, exact comparisons and negative controls, fresh own-byte replay,
    24 protected predecessor manifests,state/protected/new hashes and metadata,
    strict custody exit2/seven. Local commit only after bounded validation.

The full Spin(10)xU(1)PQ investigation is unchanged and remains incomplete.
