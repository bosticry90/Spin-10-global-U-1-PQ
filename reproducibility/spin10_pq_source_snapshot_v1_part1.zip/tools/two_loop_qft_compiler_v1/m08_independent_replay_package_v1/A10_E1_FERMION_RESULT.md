# A10 E1 — typed gauge-fixing fermion qualification

## Disposition

`PASS_BOUNDED_E1_DERIVED_REPLACEMENT_NOT_HISTORICAL_EQUIVALENCE`.

The complete separately named `M08_PHYSICAL_FRAME_GAUGE_FERMION_V1` passes the declared E1 requirements in the qualified Stage D coordinates. The two derivations agree on all eight terms, 1,797 local coefficients, 691 left Euler covector columns (643 canonical fields and 48 external background components), 4,668 nonzero Euler coefficients and 244 boundary-current coefficients, including implicit zero columns. The heavy fermion passes local quantum-H and background-H Ward identities; the complete fermion passes local background-H invariance. Every statement uses arbitrary off-shell fields and independent jets.

This is a **derived replacement**, not a certified translation of A4-V2/A5-V2. The historical field/frame and cubic-tensor normalization bindings remain insufficient to prove equivalence. The replacement is fully defined without guessing those bindings. It does not retrospectively repair, reinterpret as PASS, or overwrite the historical stop at 95c0be0.

E1 work ends here. E2–E5, master-action gauge-fixing transport, source activation, HB1/C5, catalogs, quantum matching and scientific-authority promotion were not executed. Stage D remains qualified and inactive. No physical parameter was changed.

## Derived expression and its mathematical types

Use the authenticated real orthonormal physical plane, normalized Spin(10) generators and its invariant Euclidean internal bilinear. The Lorentz metric is diag(1,-1,-1,-1). Let B=Abar_H+q, V=P_M q, q_H=P_H q, u=P_M C, eta=x-v and O_a=rho_a v. The replacement is

    Psi_M = <ubar,D[Abar_H+q_H]^mu V_mu - xi*g10*O^T eta>
            - (xi/2)<ubar,Lambda> + (alpha/2)<ubar,[ubar,u]>,
    Psi_H = <cbar,D[Abar_H]^mu q_H,mu> - (eta_H/2)<cbar,b_H>,
    Psi = Psi_M + Psi_H, alpha=xi.

The scalar coordinates remain the original 328 real coordinates. O and v are reused from the authenticated vacuum certificate, with O^T v=0 and rho_h v=0 for all twelve H generators checked in this calculation. The vacuum coefficient carries mass dimension one: evaluating it numerically does not turn the orbit term into an operator of dimension two. Psi has dimension three, ghost number minus one and odd parity. All derivative contractions retain their Lorentz weights.

Define Q_H,Q_M as the light and heavy columns of the qualified physical embedding, G_H=Q_H^T Q_H and G_M=Q_M^T Q_M. The canonical embeddings are

| Object | Field embedding into the physical plane | Invariant field bilinear | Evaluation-source embedding |
|---|---|---|---|
| Heavy connection and ghost | Q_M | G_M | Q_M G_M^-1 |
| Heavy antighost and auxiliary | Q_M G_M^-1 | G_M^-1 | Q_M |
| Light nonminimal fields | Q_H | G_H | Q_H G_H^-1 |

Every left section, projector, source evaluation pairing and induced conjugation is checked exactly. The field/source pairing is identity; it is distinct from the bilinear between two heavy dual fields. Ambient maps are rectangular and have nontrivial kernels. Their left sections are not unrestricted ambient inverses. The K_phi scalar cotangent/source dependency remains the previously qualified adapter. These are prospective chart compatibility checks, not application of a source shift to the Stage D master action.

Conjugation here is the antilinear real structure induced by real physical-plane fields and preserves the order of Grassmann products. All eight pulled-back terms satisfy this real structure exactly. A Hermitian adjoint reversing odd products is a different operation; no additional unqualified ghost-adjoint convention is asserted.

## Complete canonical pullback

The eight executable AST terms are bound to exact finite tensor tables in `frozen_a10_e1_fermion/M08_PHYSICAL_FRAME_GAUGE_FERMION_V1.json`. The primary evaluates the existing AST grammar with the graded executor; no frozen helper is patched.

| Term | Canonical expression or binding | Compared coefficients |
|---|---|---:|
| Heavy divergence | ub^T partial^mu B_M,mu | 132 |
| Heavy connection | g10 ub_i f^i_hj B_H^h,mu B_M^j,mu | 720 |
| Shifted-vacuum orbit | -xi*g10 ub^T G_M^-1 (O Q_M)^T (x-v) | 432 |
| Heavy auxiliary | -xi ub^T G_M^-1 L/2 | 33 |
| Nonsymmetric cubic | xi t^ij_k ub_i ub_j C_M^k/2, t^ij_k=f^i_ak (G_M^-1)^aj | 138 |
| Light divergence | bar^T G_H partial^mu (B_H-Abar_H)_mu | 112 |
| Light connection | g10 bar^T G_H [Abar_H^mu,(B_H-Abar_H)_mu] | 216 |
| Light auxiliary | -eta_H bar^T G_H b/2 | 14 |

The cubic is nonzero for the actual nonsymmetric coset. It is derived from the physical invariant trilinear, not deleted or normalized by fitting a residual. The heavy connection is the full Abar_H+q_H connection; A5-V2 already had that dependence. The old ordinary-derivative A5-V1 is not substituted.

Xi and eta_H remain independent real dimensionless gauge parameters. Xi is the declared invariant heavy auxiliary width; alpha=xi is its declared cubic coefficient. Eta_H is the light auxiliary width. The new f is the coupling-free structure tensor of the same normalized generators used in Stage D. No extra g10 or numerical multiplier is inferred for the old unbound f leaf. These are explicit replacement conventions preserving the named coefficient roles. **Numerical equivalence to the historical parameter/chart conventions is unproved.** Even a Ward-invariant rescaling would not establish that equivalence.

The unresolved historical questions include whether its Lambda_H meant the present L or an earlier shifted auxiliary chart, which carrier was assigned to its antighosts, which invariant contraction its component sums meant, and which normalized trilinear its f leaf encoded. This report does not answer those questions by relabeling fields. It uses the replacement alternative explicitly authorized for E1.

## Local symmetry requirements

The quantum H transformation holds Abar fixed and acts affinely on B. The background H transformation acts affinely on both B and the actual 12-component Abar_H, so q transforms homogeneously. Both use the declared scalar transformation -g10 rho(omega)x. Heavy dual nonminimal fields transform by +g10 ad_H^T; light primal fields and ghosts transform in the primal adjoint chart.

Psi_M is invariant under each transformation. Psi_H intentionally fixes the light quantum H freedom and therefore has a nonzero quantum variation. Its 1,760 coefficients and nonzero bar_0 Euler derivative are independently reproduced; this is not an ordinary total derivative. The complete Psi is background-H invariant. These local tests retain independent first and second derivatives of omega. Requiring the complete light gauge-fixing fermion to retain quantum-H invariance would impose the wrong requirement.

Published partial-gauge work requires the heavy gauge-fixing fermion to be H invariant, while ordinary light gauge fixing then fixes H. Ferrari's Eq. (4.31) also displays the independent cubic fermion structure. [Ferrari, *Partial gauge fixing and equivariant cohomology*](https://arxiv.org/html/1308.6802v3). The distinction between retained background symmetry and fixed quantum symmetry is also used in [Thomsen, *A partially fixed background field gauge*](https://arxiv.org/html/2404.11640v2). These establish comparison points, not certification of this implementation or proof of its historical equivalence.

## Independent first variation

The primary differentiates the complete indexed AST using left Grassmann derivatives and explicit integration by parts. The replay constructs physical-plane projectors and bilinears, freshly derives all 990 normalized generator commutators, varies the redundant ambient physical expression first, and only then pulls each covector back by the transpose of its field embedding. All 691 canonical/background covectors agree, including zeros. The gauge-physical even adapter is not applied to this odd fermion.

Both routes establish

    delta Psi = sum_z h_z Euler_left,z(Psi) + partial_mu Theta^mu

for arbitrary variations of the same parity as each coordinate. Variations are on the left of the left Euler derivative. In canonical coordinates the boundary current is

    Theta^mu = eta_mumu [sum_i ub_i h_BM,i,mu
                 + sum_hk bar_h (G_H)_hk (h_BH,k,mu-h_Abar,k,mu)].

The explicit current contains 244 coefficients across four spacetime directions. The identity holds as a polynomial identity before integration; compact-support or vanishing integrated boundary current supplies the local-functional interpretation. No field equation is imposed. The full first variation, not only its final Euler coefficients, is compared.

The replay does not import primary outputs during its derivation. Both routes share the exact word arithmetic, Python/SymPy, authenticated physical inputs, conventions and analyst. Distinct construction and variation routes provide computational independence within those dependencies, not external scientific endorsement.

## Preserved controls and validation

The 264-coefficient historical bare auxiliary Ward obstruction and its real, correctly projected witness remain exact and nonboundary. An unprojected physical plane vector is rejected as a heavy input. Omitting q_H from the heavy connection produces a nonzero parameter-derivative Ward residual. Changing the cubic coefficient is rejected by direct coefficient comparison. False equivalence, activation, later-stage and external-endorsement claims are rejected. Conjugation, parameter decoding, all source evaluation maps and Grassmann gradings have dedicated regressions.

Two implementation checks were corrected before acceptance: the dimensional checker initially omitted the mass dimension carried by the evaluated orbit coefficient, and generic coefficient deserialization initially omitted the declared real assumptions of xi and eta_H in the conjugation control. Both were type-accounting issues, not failed physical identities. The final code explicitly preserves those types; final fresh regeneration and regressions validate it.

The validation receipt records 142 targeted regressions: 20 new and 122 inherited, comprising 121 scientific and 21 governance tests. Three guarded read-only routes regenerate byte-identically. Nine sealed predecessor chains authenticate; their expensive calculations are reused. Historical and formal-authority bytes remain unchanged. Workspace/active-data inventory uses file size and modification-time metadata, not a byte audit of every file. The receipt records the measured count and time, and the byte manifest binds the completed bounded files separately.

Strict historical custody still exits **2**, with **seven unresolved references**. That is not PASS. Formal authority remains **34/39**. Stage D is preserved; M08/H-basic qualification and HB1/C5 remain blocked; finite C1_GS is uncalculated. The solo-review policy applies without contact or endorsement from outside personnel.

## Next decision and limitations

E1 provides a fully specified replacement input for considering a separately authorized E2 investigation. The next decision is whether to use this explicitly different gauge-fixing choice for canonical transport of the complete inactive Stage D master action. E2 must verify the entire action/source transformation and preserve the master/nilpotence identities; nothing here executes or substitutes for those checks.

Historical equivalence, physical equivalence of the eventual gauge-fixed construction, composite/nonminimal and quartic-ghost reconciliation, the useful H-basic domain and subsequent quantum calculations remain unestablished. A replacement E1 PASS is not a full Stage E PASS or a complete gauge-fixed Spin(10) theory. The approved physical action still excludes fermion/Yukawa sectors, and no numerical unification or observational conclusion changed.
