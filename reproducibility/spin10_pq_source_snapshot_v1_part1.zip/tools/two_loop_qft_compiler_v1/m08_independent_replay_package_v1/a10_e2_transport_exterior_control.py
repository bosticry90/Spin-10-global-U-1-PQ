"""Distinct physical/exterior-ring replay of full gauge-fixing transport."""
from itertools import combinations_with_replacement
from a10_bv_integration_replay_control import Control,geometry
from a10_e2_transport_common import g,xi,clean
import sympy as s

def build(stage=lambda n,f:f()):
    f,rho=geometry()
    fields={**{f'B{a}_{mu}':(1,0,0) for a in range(3) for mu in range(2)},
      **{f'x{i}':(1,0,0) for i in range(5)},**{f'C{a}':(1,1,1) for a in range(3)},
      **{f'bar{a}':(1,-1,1) for a in range(3)},**{f'b{a}':(2,0,0) for a in range(3)}}
    j=Control(fields);a=j.a;x={n:j.var(n) for n in j.grades};eta=(1,-1)
    F={k:a.add(j.D(x[f'B{k}_1'],0),a.scale(j.D(x[f'B{k}_0'],1),-1),
      *(a.scale(a.mul(x[f'B{b}_0'],x[f'B{c}_1']),g*v) for (q,b,c),v in f.items() if q==k and v)) for k in range(3)}
    Z={(i,mu):a.add(j.D(x[f'x{i}'],mu),*(a.scale(a.mul(x[f'B{k}_{mu}'],x[f'x{q}']),g*R[i,q])
      for k,R in enumerate(rho) for q in range(5) if R[i,q])) for i in range(5) for mu in range(2)}
    norm=a.add(*(a.mul(x[f'x{i}'],x[f'x{i}']) for i in range(5)))
    m,lam=s.symbols('control_m2 control_lambda',real=True)
    S0=a.add(*(a.scale(a.mul(P,P),s.Rational(1,2)) for P in F.values()),
      *(a.scale(a.mul(P,P),s.Rational(1,2)*eta[mu]) for (i,mu),P in Z.items()),
      a.scale(norm,-m),a.scale(a.mul(norm,norm),-lam))
    R={}
    for k in range(3):
        for mu in range(2):R[f'B{k}_{mu}']=a.add(j.D(x[f'C{k}'],mu),*(a.scale(a.mul(x[f'B{b}_{mu}'],x[f'C{c}']),g*v)
          for (q,b,c),v in f.items() if q==k and v))
        R[f'C{k}']=a.add(*(a.scale(a.mul(x[f'C{b}'],x[f'C{c}']),-g*v) for (q,b,c),v in f.items() if q==k and b<c and v))
        R[f'bar{k}']=a.scale(x[f'b{k}'],-1);R[f'b{k}']={}
    for i in range(5):R[f'x{i}']=a.add(*(a.scale(a.mul(x[f'C{k}'],x[f'x{q}']),-g*A[i,q])
      for k,A in enumerate(rho) for q in range(5) if A[i,q]))
    S=a.add(S0,*(a.mul(x[J],R[z]) for z,J in j.pairs))
    v=s.Symbol('control_v',real=True);vac=s.Matrix([v,0,0,0,0]);O=s.Matrix.hstack(*(A*vac for A in rho))
    condition={k:a.add(*(a.scale(j.D(x[f'B{k}_{mu}'],mu),eta[mu]) for mu in range(2)),
      *(a.scale(x[f'x{i}'],-xi*g*O[i,k]) for i in range(5) if O[i,k])) for k in range(3)}
    psi=a.add(*(a.mul(x[f'bar{k}'],a.add(condition[k],a.scale(x[f'b{k}'],-xi/2))) for k in range(3)),
      *(a.scale(a.mul(x[f'bar{k}'],x[f'bar{b}'],x[f'C{c}']),xi*v0/2) for (k,b,c),v0 in f.items() if v0))
    A={J:a.scale(j.euler(psi,z),-(-1)**fields[z][2]) for z,J in j.pairs}
    for z,J in j.pairs:assert not a.add(j.bracket(psi,x[J]),A[J]),('EXTERIOR_SHIFT_SIGN',J)
    fixed=a.add(S0,*(a.mul(a.add(x[J],A[J]),R[z]) for z,J in j.pairs))
    old=stage('exterior_original_complete_physical_Euler_columns',lambda:j.columns(S))
    new=stage('exterior_transported_complete_physical_Euler_columns',lambda:j.columns(fixed))
    def substitute(P,positive=True):
        images={n:a.add(x[n],a.scale(A.get(n,{}),1 if positive else -1)) for n in j.grades}
        terms=[]
        for odds,c in P.items():
            variables=sorted((v for v in c.free_symbols if str(v) in j.meta),key=str)
            monomials=s.Poly(c,*variables).terms() if variables else [((),c)]
            for powers,value in monomials:
                factors=[]
                for variable,power in zip(variables,powers):
                    base,jets=j.meta[str(variable)];image=images.get(base,j.var(base))
                    factors.extend([j.multiD(image,jets)]*power)
                for n in odds:
                    base,jets=j.meta[n];factors.append(j.multiD(images.get(base,j.var(base)),jets))
                terms.append(a.scale(a.mul(*factors),value))
        return a.add(*terms)
    assert not a.add(substitute(S),a.scale(fixed,-1))
    for n in j.grades:
        inverse=a.add(x[n],a.scale(A.get(n,{}),-1))
        predicted=substitute(j.Q(inverse,old))
        assert not a.add(predicted,a.scale(new[n],-1)),('EXTERIOR_COLUMN_TRANSPORT',n)
        assert not a.add(substitute(substitute(x[n]),False),a.scale(x[n],-1))
    checks=0
    for n in j.grades:
        for order in range(3):
            for jets in combinations_with_replacement(range(2),order):
                residual=j.Q(j.Q(j.var(n,jets),new),new)
                assert not residual,('EXTERIOR_GAUGE_FIXED_SQUARE',n,jets,j.rows(residual)[:6]);checks+=1
    delta=a.add(fixed,a.scale(S,-1));L=[a.scale(a.add(*(a.mul(x[f'bar{k}'],R[f'B{k}_{mu}']) for k in range(3))),eta[mu]) for mu in range(2)]
    assert not a.add(delta,a.scale(j.Q(psi,old),-1),*(a.scale(j.D(P,mu),-1) for mu,P in enumerate(L)))
    theta=[]
    for mu in range(2):theta.append(a.add(*(a.mul(R[base],a.partial(delta,n)) for n in j.support(delta)
      for base,jets in [j.meta[n]] if jets==(mu,) and base in fields)))
    E={f'B{k}_{mu}':j.euler(S0,f'B{k}_{mu}') for k in range(3) for mu in range(2)}
    currents=[]
    for mu in range(2):currents.append(a.add(a.scale(a.add(*(a.add(a.mul(E[f'B{k}_{mu}'],x[f'C{k}']),a.mul(x[f'JB{k}_{mu}'],R[f'C{k}'])) for k in range(3))),2),
      a.scale(a.add(j.Q(L[mu],old),a.scale(theta[mu],-1)),2)))
    master=stage('exterior_complete_transported_master_density',lambda:j.bracket(fixed,fixed))
    assert not a.add(master,*(a.scale(j.D(P,mu),-1) for mu,P in enumerate(currents)))
    wrong=dict(new);wrong['Jbar0']={}
    obstruction=j.Q(wrong['Jb0'],wrong);assert obstruction
    return {'schema':'A10_E2_DISTINCT_EXTERIOR_CONTROL_V1','status':'PASS_EXACT_PHYSICAL_CONTROL',
      'canonical_pairs':20,'generator_columns':40,'base_and_order_two_jet_squares':checks,
      'full_fixed_Euler_columns':{n:j.rows(P) for n,P in new.items()},
      'master_density':j.rows(master),'master_current':[j.rows(P) for P in currents],
      'master_minus_divergence':[],'all_column_conjugacy_checks':40,
      'missing_antighost_source_column_obstruction':j.rows(obstruction),
      'scalar_shifted_vacuum_in_fermion':True,'nonzero_cubic_fermion':True,
      'physical_action':'closed three-plane Spin(10) algebra with five symmetric-traceless scalar coordinates; even kinetic and invariant quartic potential',
      'control_parameters_are_candidate_physical_parameters':False,'EOM_used':False,
      'scope':'distinct arithmetic and full physical source/jet calculation; does not replace the all-643 transport certificate'}
