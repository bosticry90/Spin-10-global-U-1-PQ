# Actual four-ghost companion, V1

Prospective contract under A10_E5_CUBIC_PRIMITIVE_CONTRACT_V1.md. Baseline
1e8198037ded95b3992fcca5255aa5bf92dff987. State v113/34of39 unchanged. The
previous turn qualified only the inactive primitive and froze a prediction;
this increment must calculate the actual loop without reading that prediction
until the route's actual tensor is complete.

Question QC1: what is the complete selected one-loop g^2*xi^2 four-ghost UV
pole, and does it equal the already frozen candidate? External domain is all
45 real antighosts and all45 real ghosts, each pair antisymmetrized: 980,100
independent slots. Exact sparse zeros retain the whole domain. No sample,
heavy-only verdict or coefficient fitting can replace this comparison.

Immutable inputs: the 31-chain sealed primitive checkpoint, qualified E2
literal density, original physical action/type/vacuum/ref records, own-route
physical charts and source/auxiliary/ghost vertex records. Full643 pairs,
48 H backgrounds, all34 physical/nine source terms, parameters, potential,
vacuum and actual nonsymmetric coset stay fixed. Sources/backgrounds are zero
only for this amplitude. Freeze executable/contract/input/state bytes before
computation; each attempt keeps its exact code, fingerprint and complete log.

First prove literal coverage. For a connected one-loop 1PI four-point graph,
sum(vertex-degree-2)=4 and every vertex has at least two internal incidences.
With degree<=4 this gives four cubics, two cubics/one quartic, or two quartics.
Each vertex must attain its maximal external incidence. Physical bosonic
vertices therefore have no required odd external leg. Dimensionful quadratic
insertions and orbit/mass vertices lower the homogeneous UV degree, with no
inverse physical mass/g/width from the UV inverse. Keep their inventories;
do not reinterpret their finite amplitudes as zero.

Retained coupling assignments are (g,g,xi,xi), (g*xi,g,xi), (g^2,xi,xi), and
(g*xi,g*xi). Include every external split and all odd Hessian CC, aa and aC
blocks. The ordinary g^2 B^2-antighost-C vertex is required. Its selected two
B legs must be heavy because both attach to the xi vertices' heavy auxiliaries;
other Lorentz/group/scalar legs are excluded only by the exact reference
edges. The full literal quartic inventory is recorded before these exclusions.

After integration by parts, a differentiated external antighost lowers UV
degree. Prove the complete derivative placement cancellation for the selected
B_M vertex. Include all45 internal antighost/ghost directions before using
zero H/M edges. All xi cubics and the g*xi quartic are pulled back with dual
heavy/primal ghost maps. The full reference retains BB, BL, LB, LL=0 and both
odd inverse orientations, arbitrary heavy/light widths and four Lorentz
copies. Do not eliminate an auxiliary or assume projected adjoint closure.

Primary derives Hessians by left jet gradients/Fourier factors and evaluates
all Born shuffle words through degree four. Replay derives physical10
commutators, H/heavy projections, xi vertices and ghost quartics independently.
For selected ordinary heavy gauge legs it derives

    W = g^2 antighost_M . [B_M, P_H [B_M,C]],

from Q acting on the H-covariant heavy connection fermion; compare it with
the literal primary before interpretation. Replay uses the full even-block
Gaussian factorization D-Y A^-1 X, independently expanding the odd determinant.
The two factorizations are checked on a small Grassmann supermatrix and on
the complete elementary four-Lorentz graphs before the group calculation.

Every retained gauge edge pairs with an auxiliary. Prove k_mu*k^mu=k^2
exactly before reducing Lorentz copies in group contractions. A BB edge in a
retained box forces an LL=0 edge; the other retained families require BL/LB
or only odd edges. Retain the full arbitrary-width reference in controls and
the group implementation. UV Taylor is only k_E^2>R_UV^2>0, above fixed
external/mass scales; the momentum remainder has strictly negative UV degree.
Original box/triangle/bubble heat profiles8/6/4 remain separate despite equal
log residues. Neither whole scaleless integrals nor a finite/IR verdict occurs.

Exact exterior-polynomial arithmetic over Q(sqrt(2),sqrt(3),sqrt(5),I), extended by symbolic
reference widths, is an engineering representation. Every conversion must be
exact and reversible; a coefficient outside it raises an explicit arithmetic
underdefinition rather than truncating or floating. No external-field degree
is silently cut: vertices/Hessians fix the relevant degree exactly.

Compare completed primary/replay family tensors and actual full pole before
reading/comparing the frozen candidate. Include all zero channels. A first
required identity failure/underdefinition stops dependent work. An actual
quartic mismatch is preserved in full, with a real odd Euler witness and an
independent differentiation check. Do not adjust the candidate after seeing
it. Preserve failed/unfinished attempts, with separate execution and science
dispositions. A resource boundary reports incomplete output, never acceptance.

Negative controls remove ordinary W, ghost quartics/splits, anomalous odd
blocks, mixed propagation, an odd trace sign, a Lorentz metric weight, or old/
new primitive contributions. Each claimed discrimination needs a nonzero
exact residual. Independent exact ring/Grassmann controls check signs and
coefficients. Fresh own-byte routes, protected/new/state SHA, metadata and
31 predecessor chains are required before a local commit. Delegated custody
must remain exit2/seven unresolved, not PASS. Existing expensive calculations
are authenticated, not replayed without a new need.

Authority ceiling: this selected actual quartet and its inactive normalization
comparison only. Canonical shifts/current/real/H/jet/measure prerequisites are
reused with their exact qualifications; source-free generators do not cancel
the field Berezinian. No JC-C-C/JB-B-C loops, complete E5/A5/Ward/contact/
finite/IR/anomaly claim, activation/catalog/HB1/C5/C1_GS/matching, physical
changes, authority promotion, outreach, publication or push. Shared input/
arithmetic/Python/SymPy/analyst and solo review remain disclosed. The entire
Spin(10) x global U(1)PQ objective stays active/incomplete beyond this increment.
