# Source-fixed auxiliary derivative image, prospective V1

Baselinea54fb1768d89e70eec5b0cb52bbf32677ee292fa; sole authority
project_state.json v113/34 of39. Previous turn PROGRESS: selected actual
source–gauge pole and universal projected carrier theorem qualified. Whole
Spin(10) x global U(1)PQ goal active/incomplete. Freeze current source-gauge
bindings and39 predecessor chains, exact code/action/frames/state before work.

AD1 derives full Q image and exact canonical flow of the source-fixed
derivative generator. AD2 compares the complete inactive extension with ALL
existing companion evidence, retaining every old coefficient/order and full
IBP current. No new actual loop, fitted coefficient or adoption. The source
pole uniquely fixes P=diag(0,C_H) for J_Lambda partial B in its universal
projection, not a unique full nonlinear generator.

Both quantum B_H and fixed external A_H have the inherited inhomogeneous
background-H transformation. The literal heavy gauge-fixing function uses
B_H: recover F_GF=-the pure-B component of QJ_Lambda, not a guessed external
connection. Choose the input-derived completion K=g^2 J_Lambda P F_GF,
with F_GF=D_(B_H).B_M. Replay rebuilds it from physical10 commutators and
the full local H transformation. Record D_(A_H) and B_H-A_H homogeneous
ambiguity; this choice is a separately tested inactive member, not proof
of uniqueness. No gauge-fixing action or foundational assumption changes.

K has dimension3,gh-1,odd; derivatives ordinary first jets, fields643 and
canonical sources643, fixed external backgrounds48. Full Q uses immutable
E2 columns, all coupling/width/source/field/jet descendants retained. No
M-adjoint Jacobi assumption, EOM quotient, field elimination or inverse
physical coupling/mass. All real/dual/primal evaluation pairings retained.
Any imported dimension-one OrbitPullback coefficient must be reconstructed
exactly as in E1, not accepted as an arbitrary word-grade exception.

Qualify the jet/canonical convention first on a unit J_Lambda partial B,
with both even field coordinates and odd sources. Prefix Q and independent
literal field/source first variation of full BV+GF action must agree after
the EXACT retained current from K's gauge-field jets. Infer no pointwise
zero where only an integrated functional equality holds. Replay derivatives
use variational Euler covectors, primary ordered partials and independent
IBP. Both completed full images must agree before dependent comparisons.

Check full local-H identities with arbitrary omega_h and parameter jets,
including inhomogeneous connection terms, not only constant omega. Removing
the connection completion must produce an exact nonzero parameter-jet
control. Keep the full literal physical/source/scalar/potential/vacuum
columns while varying fields/sources; no selected image only.

Canonical flow: Lambda shifts by a B-only polynomial/differential function;
B and J_Lambda fixed, gauge sources shift by its Euler adjoint. Establish
both inverses on all1286 generators, ordinary first-jet prolongations and
second-jet/product-rule controls. Bare-generator pairings do not suffice:
prove every differential field/source kernel through formal-adjoint IBP,
and all source/source Hessian blocks with arbitrary independent graded
smearing test functions and retained currents. Cotangent signs must be
derived from the inherited odd bracket. Flip the source sign as a nonzero
control. Other elementary pairs and external backgrounds remain fixed.

The integrated-field Jacobian is triangular from B to Lambda, with sources
external. Show N^2=0 and zero supertrace even after arbitrary type-preserving
finite-mode/heat projections, so this single shift has Berezinian1. State
the existing joint regulated measure separately. Do not infer an exact finite
combined old flow, full quantum A5 or Ward restoration from this single map.

Only after full image agreement open existing actual source and derivative
pole records and old complete candidate. Construct complete new inactive
generator/candidate including ALL new terms. Compare actual source-gauge2025
slots, derivative-gauge182250, prior auxiliary91125 and g^2 quartet980100,
and unchanged earlier source/kinetic/mixing/width/cubic scopes. Use full IBP
currents and coupling coefficients, including all lower/higher predictions;
do not discard newly unmeasured companions. Preserve total g^3 quartet as
prediction, not actual result. Authenticate old expensive loops/125basis
images without rerunning. On first mismatch preserve full real Euler/
Fourier witness and STOP before refitting or new higher/physical calculations.

Numeric controls: omitted connection, wrong source sign/adjoint, omitted
boundary current, missing derivative/product terms, wrong real/source chart,
wrong coupling degree and fitted sign. Preserve every failed/unfinished
exact preparation/source/start/stdout with classification; no overwrite.
Four strict own-byte fresh routes: unit controls, primary full image, replay
full image, dependent comparison. Validate scientific/process/governance,
research_check.py e5,39 protected chains, new/protected/state bytes and
size/mtime inventory; custody expectedexit2/seven unresolved refs, neverPASS.
Raw Git index/worktree bytes identical before localcommit. Evidence validation
and director/scientific acceptance remain distinct.

Possible dispositions: selected source-fixed inactive extension qualified;
exact stopped companion obstruction; underdefinition; necessary gate failure;
incomplete execution. No physical/catalog/HB1/C5/C1_GS/matching, adoption,
authority promotion, external outreach/push/publication, fullE5/A5/Ward/
contact/IR/anomaly. Global scalar/PQ,fermion/Yukawa/phenomenology and full
goal remain unfinished. Local conventions, epistemic ladder and solo review
apply; shared inputs/software/arithmetic/analyst do not imply independent
scientists or mandatory outside personnel.
