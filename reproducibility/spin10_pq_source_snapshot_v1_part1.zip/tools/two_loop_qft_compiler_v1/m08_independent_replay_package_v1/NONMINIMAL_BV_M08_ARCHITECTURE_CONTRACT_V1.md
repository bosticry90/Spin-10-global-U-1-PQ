# Full-M08 nonminimal BV architecture review contract

This is an inactive, bounded architecture investigation following `febd580`.
It does not replace Sigma_M08, its six source couplings, or its seventeen
transformation roles. Freeze this contract before new exact calculations.

## Decision, minimum scope and stop rule

Physics decision enabled: determine whether the qualified free nonminimal BV
repair can be extended coherently to the interacting M08 field/source algebra,
before authorizing any new catalog or H-basic/C5 computation.

Current blocker removed: none automatically. The current nonminimal-pairing
and H-basic blockers remain until a complete replacement is qualified and
separately adjudicated. Formal scientific authority remains 34/39.

Why existing tools are insufficient: the free comparator proves the missing
antighost partner cancellation only at zero coupling. Its theorem does not
establish the interacting forward rules, partial gauge fixing, residual-H
calculus, or the full M08 master equation. Adding antifields cannot repair a
non-nilpotent field-only differential while leaving that differential unchanged.

Minimum new implementation surface: a small exact interacting prerequisite
calculation from frozen M08 rules and certified representation/dual data, a
separate direct component replay, bounded evidence, regression tests, and a
read-only audit. Expand to a full candidate action and all seventeen impact
roles only if the earlier prerequisites pass. Do not rebuild JCAT or T5.

Structure-preservation obligations: distinguish primal heavy coordinates from
their evaluation dual and distinguish structure coordinates from lowered
tensors. Any proposed auxiliary change must have an explicit inverse and a
cotangent/source lift preserving the bracket, grades and residual action.
Gauge fixing must be a declared canonical transformation, not a fitted sign.
No equivalence from a comparator to M08 is presumed.

Stopping condition: test the smallest interacting forward-rule consistency
requirements first. Stop the proposed extension at the first exact nonzero
residual or genuinely unresolved tensor convention. Preserve the failure;
do not silently repair a frozen rule or proceed to a larger action. If those
pass, require a coherent master action, canonical gauge fixing, source and
Cartan compatibility, and full impact/descent review before promotion.

What will be deleted or deactivated if this does not work: no evidence is
deleted. New code stays an inactive diagnostic; no candidate action, source
partner or transformation becomes active in M08.

## Prospective pairing inventory (not an implemented extension)

Use the coherent left source bracket of the free comparator, with
`z_star=(-1)^p(z) J_z` and `QF=(S,F)_J`. Each candidate canonical pair has
`d(J)=3-d(z)`, `gh(J)=-1-gh(z)`, `p(J)=1-p(z)` for Q degree (1,1,1).

| Field | d | gh | p | Candidate source | d | gh | p | Status |
|---|---:|---:|---:|---|---:|---:|---:|---|
| V_H_mu | 1 | 0 | 0 | K_V | 2 | -1 | 1 | Existing pair |
| q_L_mu | 1 | 0 | 0 | K_q | 2 | -1 | 1 | Existing pair |
| phi | 1 | 0 | 0 | K_phi | 2 | -1 | 1 | Existing pair |
| u_H | 1 | 1 | 1 | L_u | 2 | -2 | 0 | Existing pair |
| Lambda_H | 2 | 0 | 0 | K_Lambda | 1 | -1 | 1 | Existing pair |
| c_L | 1 | 1 | 1 | L_c | 2 | -2 | 0 | Existing pair |
| ubar_H | 1 | -1 | 1 | K_ubar | 2 | 0 | 0 | Prospective only |
| cbar_L | 1 | -1 | 1 | K_cbar | 2 | 0 | 0 | Prospective only |
| lambda_L | 2 | 0 | 0 | K_lambda | 1 | -1 | 1 | Prospective only |

Sources are evaluation duals of their fields, not Euclidean transposes chosen
by name. In particular ubar_H and Lambda_H are dual-heavy roles, so their
prospective source partners are primal-heavy. Abar_H remains an external
background with its frozen transformation, not a new canonical dynamical
field. R_H stays the derived polynomial `-1/2 P_H[u_H,u_H]`, never an
independent paired coordinate. Parameters remain frozen scalar/spurion roles;
the shifted scalar uses its certified VEV/representation convention.

This table specifies possible grades, not a proof of neutrality, completeness,
master-equation closure, or catalog applicability. A source set to zero is
not a legitimate differential restriction unless its ideal is invariant.

## Ordered acceptance gates

1. Recover actual field rules, residual actions, structure tensors, evaluation
   duals, and the distinction between Cartan and full-Weil conventions.
2. Independently check the smallest interacting forward nonminimal identities
   before source pairing. Compare the already-earned source-free comparator
   only within its own assumptions. Retain all failed frozen controls.
3. If gate 2 passes, derive the complete canonical nonminimal master action and
   its gauge fixing, including both nonminimal sectors, composite chain rules
   and derivative prolongation. Check the free -box(u) cancellation and prior
   -2i/+1 controls without fitting coefficients.
4. If gate 3 passes, reconstruct all seventeen old roles and the new source
   partner roles from that single action; prove the requisite master,
   nilpotence, residual-H/Cartan and domain-preservation identities. Assess
   physical source-zero action equality and every changed source expression.
5. If gate 4 passes, assess catalog/weight/provenance impact without building
   catalogs. No automatic deletion of partners or acyclicity claim is allowed.
   External specialist semantic review remains a distinct prerequisite for
   promoting a full M08 replacement; it is not supplied by internal replay.

The BV and partial-gauge-fixing precedents are
[Gomis, Paris and Samuel](https://arxiv.org/pdf/hep-th/9412228), sections 6-7,
and [Ferrari](https://arxiv.org/html/1308.6802v3), section 3. They are primary
comparators, not verification of M08's source or nonminimal conventions.

## Evidence and boundaries

Primary and replay outputs must be frozen before comparison. Report algorithm,
code-path, library and runtime independence separately. A direct calculation
may share physical input and SymPy without being an independent semantic review.

No pole/projection payload reads; all Python runs use the pole-blind guard.
Preserve frozen scientific input bytes. Audit entry points are read-only;
regenerate new bounded evidence byte-identically and compare workspace and
active-data inventories. Retain measured wall/CPU, peak memory and OS I/O;
mark unmeasured substage/cache metrics as unavailable. No GPU work.

No HB1, H-basic dimensions, new full operator catalogs, C5 matrices/ranks,
EOM quotient, H0/H1, C6/D6/E, formal attempt 2, M09-M13, Layer 6, gauge refit,
or C1_GS. finite_C1_GS remains null. Historical custody stays unresolved unless
authentic evidence independently resolves it. Stop after bounded adjudication,
validate and commit locally; do not push or begin a new investigation.
