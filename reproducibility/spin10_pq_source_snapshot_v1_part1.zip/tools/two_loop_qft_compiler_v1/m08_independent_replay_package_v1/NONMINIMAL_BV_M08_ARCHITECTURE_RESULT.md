# Interacting M08 nonminimal BV architecture preflight

The free BV repair does not yet extend to the unchanged interacting M08
rules. The first interacting prerequisite fails in the physical scalar
sector, before new sources or auxiliary partners are needed:

```
[Q^2 eta_328[0]]_(g10^2 c_L^0 c_L^4 eta_328[3]) = +1 != 0.
```

Two exact routes reproduce this coefficient. The proposed extension stops
here under the [frozen review contract](NONMINIMAL_BV_M08_ARCHITECTURE_CONTRACT_V1.md).
No full interacting replacement, master action, or new source alphabet is
promoted. Formal authority remains `34/39`, HB1/C5 remain unauthorized, and
`finite_C1_GS` remains null. This is an obstruction to preserving these forward
rules in the requested off-shell nilpotent full-Weil BV architecture, not a
rejection of Spin(10) physics or every possible relative formulation.

The localized diagnostic is
`M08_NONMINIMAL_BV_ARCHITECTURE_SCALAR_FORWARD_SQUARE_NOT_CLOSED`.
It does not overwrite the formal sequence blocker in project_state.json or
the earlier source/nonminimal diagnostics.

## What was reviewed, in the right order

The contract inventories nine prospective canonical field/source pair types:
the existing six plus partners for the heavy antighost, light antighost and
light auxiliary. It records grades, parities, primal/evaluation-dual roles,
the external status of Abar, and the derived status of R. These are a proposal
inventory, not active additions or a completeness certificate.

The next gate asks whether the interacting field rules that such an action
would generate are themselves consistent. That must precede gauge fixing,
source reconstruction or catalog expansion. Adding a nonminimal source can
fix the previously missing free source cancellation, but cannot make an
unchanged field-only differential square to zero if it already fails there.

| Review gate | Actual disposition |
|---|---|
| Candidate pairing/grade inventory and source convention | Specified, inactive; no new M08 symbols |
| Interacting forward-rule prerequisite | Failed in a selected scalar/H-ghost coefficient |
| Independent physical-tensor replay | Same exact nonzero coefficient |
| Full candidate master action and canonical gauge fixing | Not reached |
| Full seventeen-role plus partner reconstruction | Not reached; the previous seventeen-role reconstruction remains historical evidence |
| Full Cartan/basicness and quotient-descent qualification | Not reached |
| Complete catalog impact and any rebuild | Not reached; existing JCAT/T5 remain unchanged |
| External specialist semantic review | Outstanding; internal replay is not a substitute |

This is the first failed gate, not a completed full-M08 BV qualification.

## The precise mismatch

The unchanged expression table uses the coherent left odd product rule and
contains, in the light-ghost sector,

```
Q eta = +g10 c^a rho_a eta,    eta = v + phi,
Q c^a = -g10/2 C^a_bc c^b c^c + g10 R^a.
```

The certified physical scalar dictionary represents generators with
`[rho_a,rho_b] = C^k_ab rho_k`. The physical index evaluator likewise uses
the direct positive tensor action; no negative dictionary is silently
substituted here. The selected coefficient contains no heavy ghost, so the
composite R contributes nothing to it. This is polynomial coefficient
extraction, not a claim that setting heavy fields to zero defines an invariant
restriction of the complete theory. The eta-dependent coefficient does not
depend on the numerical VEV.

Applying the frozen rules with left graded differentiation gives

```
[Q^2 eta]_(g10^2 c^a c^b eta)
    = -C^k_ab rho_k - [rho_a,rho_b]
    = -2 C^k_ab rho_k.
```

The two contributions add. For the action-normalized H pair `(0,4)`,

```
C^4_04 = -i/sqrt(2),
[rho_0,rho_4] = (-i/sqrt(2)) rho_4.
```

On scalar input coordinate 3 and output coordinate 0, the variation of the
ghost contributes `+1/2` and the iteration of the scalar action contributes
`+1/2`. Their sum is `+1`. These coordinates are the actual Phi components
`Phi.offdiag.0.4` and `Phi.offdiag.0.1` in the qualified canonical scalar basis.
The direct symmetric-tensor reconstruction is nonzero as a physical 10-by-10
matrix, not just in a serialized coordinate calculation.

The calculation uses normalized physical generators
`T_ab=(E_ab-E_ba)/sqrt(2)`. SA10's raw H representation matrices are divided
by sqrt(2), consistently with the independently qualified bracket constants.
The representation commutator itself passes exactly. The defect is the
combination of the forward ghost sign, forward scalar sign, and left product
rule, not a failure of the physical representation or its evaluation dual.

Changing the scalar sign in this isolated calculation would make this
selected square vanish. That is recorded only as a semantic diagnostic.
It is **not** a qualified correction, an edit of the frozen rule, or proof
that all other sectors then close. Reversing a generator dictionary also
requires transporting its algebra/action conventions; it is not permission
to retain incompatible frozen coefficients.

## Why the scope matters

This is an elementary full-Weil/off-shell test, not a C5 matrix, H-basic
cochain count, or construction of a ghost-number-two catalog. The input has
`(d,gh)=(1,0)`; the twice-applied result has `(3,2)`, preserving weight one.
No derivative, integration-by-parts identification, equation of motion, source
elimination or auxiliary elimination was used. A nonzero coefficient in the
complexified H root frame also detects a nonzero complexification of the
underlying real polynomial; it is not a new complex physical field.

The result does not say that every residual-H-invariant functional has a
nonzero square. A relative or equivariant restricted construction would need
its own explicit contract and proof. It also does not establish a no-go for
BV actions with different, justified forward rules or more general antifield
dependence. It blocks the requested preservation of the present field-only
rules as an off-shell nilpotent differential. An invertible coordinate change
alone transports the same nonzero square rather than removing it.

The [free nonminimal comparator](NONMINIMAL_BV_FREE_RESULT.md) remains a
qualified success. Its source partner cancels `-box(u)` at zero coupling,
where this new `g10^2` scalar coefficient is absent. Likewise the coherent
left-source candidate still removes the isolated historical `-2i` and `+1`
defects in their tested source sectors. None of these successes claims a
complete interacting M08 differential. The older Cartan-side identities
and ST-zero certificates remain immutable within their original tested
domains; they are not rewritten as a proof of this failed full-Weil identity.

## Independent calculation and retained evidence

[Primary evidence](frozen_nonminimal_bv_m08_architecture/primary.json) extracts
signs and ordering from the actual frozen images, uses the certified SA10
scalar matrices, and computes the two contributions separately. Its witness
is the first nonzero matrix entry for the selected H pair. That selection
was fixed before comparison, not preregistered before exploratory inspection.
The primary also applies the qualified left exterior-polynomial derivation
twice, retaining all twelve light ghosts and all scalar components used by
the first image, and checks the complete selected ghost-word coefficient
against the matrix calculation. It does not set other light ghosts to zero
before differentiating.

[Replay evidence](frozen_nonminimal_bv_m08_architecture/replay.json) imports
neither the primary implementation/output nor SA10's scalar action matrices.
It reconstructs normalized physical H matrices from C3, projects their
commutator with the non-Euclidean trace-Gram dual, lifts the input and output
Phi coordinates with the A3 embedding, and differentiates both odd slots
directly in symmetric-tensor space. Both outputs were frozen separately
before comparison.

Algorithm and code-path independence hold for these bounded constructions.
The physical frame, AST conventions, Python and SymPy are shared; library and
runtime independence are false. The replay target was known and analyst
blinding is not claimed. External specialist review has not occurred.

The [read-only audit](audit_nonminimal_bv_m08_architecture.py) regenerates both
artifacts byte-identically, compares the exact components and rejects nine
adversarial mutations, including erased failure, fitted cancellation, changed
sign, premature promotion and overstated independence. The
[validation receipt](frozen_nonminimal_bv_m08_architecture/validation_receipt.json)
records actual bounded tests, old comparator regressions, scientific-input
byte checks, workspace/active-data inventory comparisons and measured timings.
An evidence-audit PASS is not a scientific architecture PASS.

No large catalog was regenerated. JCAT/T5 authority and previous verification
evidence are referenced immutably. No pole/projection data was read, no
unrestricted repository-wide validation is claimed, and historical custody
remains a separate unresolved condition with strict audit exit 2.

## Next bounded investigation, not executed here

Before extending the source architecture, independently reconcile the actual
physical scalar representation action with the ghost and left/right BRST
conventions, starting with this two-generator Phi example. The specialist
review should check the direction of the matter action, passive versus active
coordinate conventions, bracket orientation, and the map from the physical
tensor action to rho in the frozen expressions. Any correction needs a
versioned full impact analysis; it must not be chosen solely to zero this
component or silently change the physical action.

Only after that foundational gate passes should the project resume the
canonical nonminimal action, both doublet sectors, complete source and
composite-chain reconstruction, Cartan/domain tests and catalog impact.
The conventional precedents remain
[Gomis, Paris and Samuel](https://arxiv.org/pdf/hep-th/9412228), sections 6-7,
and [Ferrari](https://arxiv.org/html/1308.6802v3), section 3. They motivate a
coherent derivation; they do not certify the current M08 rules.

The physical theory is still unresolved. The practical gain is that another
small prerequisite has been exposed before constructing an interacting
source extension or rebuilding hundreds of thousands of operators.
