# E5 admissibility exact half projector, V2 supplement

V1 scientific scope, image obligation, first failure and authority ceiling
remain. Completed primary/replay universal algebra outputs agree exactly and
their source/preparation bytes stay unchanged. Before actual residual access,
code inspection identified that Python's (0-0)/2 produces a floating zero,
violating the exact projector's type when a tensor slot is absent. The V1
comparer has NOT executed and is not accepted as a computation.

Freeze a separate V2 comparer/exporter, this contract and completed algebra
hashes. Its only arithmetic change is explicit s.Rational(1,2)*(u-v) and
s.Rational(1,2)*(u+v), so exact zero slots remain exact. Qualify a zero-slot
type control before comparison. No coefficients are rounded/rationalized,
no actual tensor or candidate is fitted, and no algebra output is overwritten.
Fresh validation still reproduces original primary/replay with exact original
starts/bytes plus this V2 comparison with its exact own start/bytes. All
original obligations and unfinished goal remain; the V1 comparer is retained
as unexecuted source, not a failed scientific gate or a PASS.
