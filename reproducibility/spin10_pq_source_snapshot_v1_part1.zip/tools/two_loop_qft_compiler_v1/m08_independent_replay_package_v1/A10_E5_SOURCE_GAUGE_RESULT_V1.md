# Actual source–gauge derivative prerequisite and stopped candidate

SG1 qualifies the selected actual one-loop antighost-source–gauge derivative
pole. All2025 source/gauge coefficient slots, four Lorentz polarizations and
literal GF derivatives on antighost/gauge/ghost are retained. The primary
full signed Hessian/Born bubble and independently routed ordered Gaussian/Wick
unit residues are(1,1,-2) for those three placements. Their sum is zero,
proving the full GF vertex IBP identity. Two even external legs commute;
internal ghost supertrace/left-Hessian/inverse signs remain graded.

Literal source/GF contraction and physical10 Casimir derivation agree. With
T_h=-E_M^T ad(E_Hh) E_M and C_H=-sum_h T_h^2, the actual source coefficient
matrix is A=diag(0_H,-C_H). It has56 physical nonzero entries and rank32, with
all H source/gauge rows and columns zero and one heavy singlet zero. All12
homogeneous H identities, reality and frame roundtrips pass. Canonical
temporal/allfour density word counts are32/128. The common pole factor is
hbar g10^2/(32pi^2epsilon). For example A_13,13=-8/5.

The full literal source has45 linear terms with one integrated leg and hence
zero integrated Hessian, and180 nonlinear terms, only J_aM a_M C_H atg.
No source quartet exists. One source cubic and one derivative ghost cubic
are the sole one-loop two-external-leg cycle; three cubics leave an odd
internal incidence count. Non-ghost bubbles cannot close the source's two
odd legs; the Xi vertex has no gauge leg. Widths/xi therefore drop by complete
reference-edge screening. The full H/M leading ghost quadratic symbol is
separately checked against the unit inverse in the real dual/primal frame.
No arbitrary width specialization, whole-scaleless or finite/IR integral.
The UV domain k_E^2>R_UV^2>0 and bubble heat profile4 are retained. Heat Taylor
insertions give degree-2/Lambda^2 with Gamma(1-epsilon), not a log pole.

The physical source-derivative alternative and allfour complete actual IBP
currents are stored: J partial B = -(partial J)B +partial(JB). A two-point
amplitude has one independent momentum; this does not restrict either of
the two momenta in the previous three-point derivative-gauge calculation.

SG2 universal projected image theorem was calculated before actual pole or
candidate access. All643 field and643 source Q columns and the existing
complete dimension3/gh-1/odd/nonnegative-coefficient carrier census are
screened. Terms containing J_a occur only in QJ_C~J_a a, QJ_a~C_H J_a and
QJ_Lambda=-J_a+other terms. Only J_Lambda partial B (or its source-derivative
IBP equivalent) can supply J_a partial B in this projection. The universal
2025 signed image columns are diagonal -1, rank2025 and kernel0 in this
specific quotient. Source-free carriers cannot supply this source target.
This is not a complete H-invariant generator basis or a full nonlinear image.

Consequently the calculated A fixes the NECESSARY projected coefficient
P=-A=diag(0_H,C_H), corresponding formally to +g^2 J_Lambda P partial B.
No generator, full Q image, background-connection completion, canonical flow
or regulated measure is constructed/adopted in this increment. The input-
derived source pole, rather than the old derivative residual, fixes the sign.
Do not change it to improve another amplitude's agreement.

After actual agreement the complete inactive candidate is opened. Its entire
g^2 source–gauge derivative projection is zero, as are its lower projections.
It therefore FAILS this source companion:32 temporal residual words,128
allfour. A real-source Euler witness is Jp13: -8partial_0 Bp13_0/5, with
Fourier symbol -8 i p_B Bp13_0/5. Ordered even deletion independently agrees;
the difference is not a pure total derivative. No EOM/anomaly conclusion.
First failure stops before a dependent repair or old derivative residual
comparison, refitting, new actual higher/source/quartet/physical calculations.

Preserve the failed controls attempt1 and its exact preparation/source/start/
stdout: a borrowed Born external-word product incorrectly treated source and
gauge tokens as odd, giving primary0 against replay(1,1,-2). The corrected
even-token product retains all internal graded signs; qualified controls
attempt2 uses its new frozen preparation. The failed attempt is not PASS.
Any later validation failures have separate immutable snapshots/dispositions.

Validation receipt must own scientific/process/governance/delegatede5 tests,
FOUR strict own-byte fresh routes,38 protected predecessor chains, unchanged
new/protected/state bytes and size/mtime inventory. Custody remains expected
exit2/seven unresolved refs. Old expensive loops/125basis images are only
authenticated. Raw Git index/worktree bytes must agree before localcommit.
Successful evidence validation does not pass the failed candidate gate or
constitute director acceptance. Commands, exact hashes, runtimes and diagnostic
outputs reside in frozen preparations/attempts/receipt/bindings.

Shared action/geometry, exact arithmetic, Python/SymPy and analyst limit
independence. Bounded actual reproduction and projected carrier theorem have
verified derivations; candidate match fails. Proof-assistant formalization
was not attempted, explanatory compression and wider physical interpretation
remain open, empirical connection none. project_state.json v113/34 of39 stays
sole authority. FullE5/A5/Ward/contact/IR/anomaly, scalar/PQ global,
fermion/Yukawa/phenomenology and whole investigation remain unfinished.
No catalog/physical/HB1/C5/C1_GS/matching, adoption, promotion or external action.

Next smallest scientific action: a separate prospective contract for the
source-fixed auxiliary derivative generator with the correct external-H-
background connection completion. Derive both full Q images and canonical/
measure obligations, then compare existing source, auxiliary, quartet and
derivative-gauge evidence without fitting any new coefficient. First mismatch
must stop that dependent extension. The g^3 quartet remains a prediction for
a later separately contracted actual calculation.
