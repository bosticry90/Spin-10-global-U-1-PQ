# Actual g^3 four-ghost pole, prospective QG3 V1

Baselinea19b4b6dd2f0ec73706d7e3950ee466b169889ba; sole scientific authority
project_state.json v113/34 of39. Previous turn PROGRESS: actual auxiliary-
source/ghost derivative pole matched the earlier frozen member. Whole
Spin(10) x global U(1)PQ investigation active/incomplete. The user's latest
scientific assessment requests this prospective test, then increasing emphasis
on coherent measured-functional Ward/Slavnov/source/insertion obligations.
Freeze auxiliary-ghost bindings and41 predecessor chains, exact code/action/
frames/state before calculation. Preserve the unchanged pureg^3 prediction
in auxiliary-derivative/comparison.json (966canonical words) without using it
in either actual route. Candidate-blind workers cannot read that result.

QG3-1 calculates the actual one-loop dimension-zero, no-jet a^2 C^2 UV pole
atg^3. Four odd fields dimension1, gh0/even in total. All45 antighost and45
ghost directions,990x990=980100 independent antisymmetric pair coefficients
including zeros, arbitrary real heavy/light inverse widths and full coupling
orders retained. QG3-2 compares the completed tensor to that frozen candidate.
No candidate zeros, coefficients or normalizations decide a graph exclusion.

Inputs: full immutable BV/source/GF E2 action, physical action/potential/
vacuum, E1 real primal/dual charts, physical10 parent commutators and inherited
complete643-field leading reference qualification. Sources external, full
parameter/catalog/regulator unchanged. Actual scope is a no-source quartet;
source vertices cannot survive with all sources zero. No source evaluation
as dynamical field, auxiliary elimination, inverse physical coupling/mass,
EOM quotient, physical fitting or M-adjoint Jacobi assumption.

Recover the complete literal vertex inventory before restriction. Relevant
leading Hessians at constant external odd fields: derivative ghost cubic Gg,
auxiliary ghost cubic Xxi, ghost quartet Qgxi, curvature ghost quartet Rg^2xi
and ordinary BBaC quartet Wg^2 with ALLH/M gauge legs. At a proper one-loop
four-external-leg cycle, n3+2n4=4. Atg^3 include:
1. All4 cyclic-placement Born words for G,G,G,X boxes (g^3xi).
2. All3 G,G,Q triangle words (g^3xi).
3. All6 G,X,W triangle words (g^3xi), retaining H/M gauge legs.
4. All6 G,X,R curvature triangle words (g^3xi^2).
5. Both Q,R quartic-bubble words (g^3xi^2).
6. Both W,Q bubble words (g^3xi), with even/odd reference-block zero proven
   only after full Hessian construction. Retain this zero family explicitly.

Other coupling families are not thisg^3 coefficient. Purely bosonic/scalar/
auxiliary-gauge cubics have no eligible odd external remainder after two
integrated derivatives; a no-external-odd cubic cannot lie on a proper 1PI
one-loop ring. Physical bosonic higher vertices likewise have vanishing
eligible Hessian at constant odd backgrounds. Positive-dimensional scalar/
Orbit/mass insertions lower this dimension-zero quartet UV degree; their
other poles remain unqualified. Do not apply the oldg^2 H-gauge-leg exclusion
at this order. Keep all derivative-on-a/B/C vertices and complete GF IBP
currents before setting external derivative remainders to negative UV degree.

Full four-vector reference BB=-eta/K+(1-w)kk/K^2, BL=+ik/K,
LB=-ik/K,LL=0, both odd inverses. EVERYBB edge in theseg^3 families has a
derivative-ghost k endpoint (or one through ordinary W's eta contraction).
Prove k.BB=-w k/K and k.BB.k=-w using the full tensor before collapsing the
loop direction. Transverse terms remain in the proof; no omitted-transverse
claim is accepted as a general amplitude zero. The sparse180-coordinate
longitudinal operator (90even/90odd) is then an exact contraction for this
coefficient, not an auxiliary integration or a claim aboutg^4/finite/IR graphs.

Primary uses ordered left Euler/Fourier Hessians and complete graded Born
words. Replay constructs G/X/Q/R/W from independent physical10 commutators
and the input gauge-fermion/source curvature sign, verifies own literal
vertices, then uses exact Gaussian/Schur inversion before the odd logarithm.
Retain Ugg and Ugx, ordinary W inverse corrections, Q/R cross terms; prove
Uxx=0 fromLL before dropping it. Authenticate and reuse qualified closed-
trace associativity/even-superoperator cyclicity, with independent unit
control of every new word class. Shared inputs, exact ring/word arithmetic,
Python/SymPy and analyst are disclosed, not independent scientists. No agents.

Exact coefficient ring Q[sqrt2,sqrt3,sqrt5,I,ref_width_M,ref_width_H] has
unbounded polynomial width powers; no evidence/group cutoff. Vertexxi powers
are distinct from inverse widths until the formal family tensors are complete.
Bind ref_width_M=xi and ref_width_H=eta_H with explicit REAL symbol locals,
not unassumed string symbols. Preserve full formal-width and bound outputs.
Represent every zero implicitly on the declared full domain, with no silent
slot sampling. No repeat of oldg^2 loops or125-basis images.

UV domain k_E^2>R_UV^2>0 above all external/mass scales, heat box8/triangle6/
bubble4. All selected leading closed words have degree-4, masterI/(16pi^2eps),
common polehbar g10^3/(32pi^2eps). Negative-degree external momentum/mass
remainders excluded only from this logarithm. No whole-scaleless, finite/IR,
power-divergence or complete regulator-restoration inference.

Actual routes never read prediction/peer output; compare completed family
tensors before candidate access. Require exact primal/dual roundtrips, real
coefficients, all12 homogeneous H tensor identities and full980100 coupling/
width coefficient comparisons. Any H or singlet zeros must arise from the
actual calculation, not the candidate. Full local jet Ward identities need
partner amplitudes, not inferred from this quartet. On first discrepancy
preserve full formal/bound difference and a real signed antighost Euler
witness excluding a pure boundary, thenSTOP before image/coefficient fitting
or new higher/physical loops. Prior failures stay immutable.

Numeric/unit controls must detect wrong odd order/sign, omission of each
nonzero class/split, missing curvature Q/R, wrong width binding, wrong real/
dual pairing and misuse of the longitudinal projection outside its proof.
Compare full4-vector unit contraction to reduced Born and Gaussian routes;
all new class weights qualified before the expensive group trace. Resource
limits mean INCOMPLETE, never truncation/PASS. Preserve exact failed/unfinished
code/start/output/preparation with classification; no restart on observation
timeout if the same process handle remains live.

Validation: four strict own-byte fresh controls/primary/replay/comparison,
scientific/process/governance and research_check.py e5,41 protected chains,
new/protected/state bytes and size/mtime invariance. Custodyexpectedexit2/
seven unresolvedrefs,neverPASS. Old expensive qualifications authenticate
only. Raw Git index/worktree equality before localcommit. Successful evidence
validation is separate from candidate gate, director acceptance or promotion.

Possible dispositions: selected actualg^3 quartet qualified/matched; exact
stopped candidate obstruction; underdefinition; necessary gate failure;
incomplete execution. No adoption/authority/catalog/physical/HB1/C5/C1_GS/
matching, external outreach/push/publication, fullE5/A5/Ward/contact/IR/anomaly
or wholegoal completion. g^2 longitudinal/mixing, no-jet power/mass and other
higher predictions, scalar/PQ global,fermion/Yukawa/phenomenology remain open.
After this test organize the complete measured divergent functional against
one coherent Ward/Slavnov/source/insertion contract, marking missing partner
amplitudes explicitly; no algebraic image substitutes for actual loops.
Existing local conventions, ladder and solo-review apply without recruitment.
