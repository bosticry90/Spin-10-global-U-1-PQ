# E5 exact-term quotient and canonical renormalization contract

Question: can the recorded nonhorizontal exact counterterm be accounted for
by a typed canonical redefinition, and what further proof makes a basic
counterterm classification equivalent to the intended full deformation problem?
The assessment of `19c5783` authorizes this inactive bounded investigation.
Baseline: clean `19c5783bb0f4f0264bae8aad7bb75b215df42135`, 520 authenticated
bindings in fourteen manifests, no surviving matching calculation, authority
34/39. D–E4 and the E5 literal witness stay frozen. Solo review applies.

Use all 643 canonical pairs, 48 external H backgrounds, the exact source-left
bracket, approved physical Euler programs and ordinary local-functional
boundary convention. Physical couplings, vacuum, tensor representations,
nonminimal charts and the E1 replacement fermion are unchanged. No historical
fermion equivalence, fermions/Yukawa, auxiliary elimination or loop calculation.

Q1 defines two separate matters. A local real odd generator of grades
(3,-1,odd) gives a dimension/ghost-preserving canonical coordinate change.
Its sources, action and operators must be transported together. This is a
mathematical equivalence; it does not establish the quantum measure, Jacobian,
observables or the actual renormalized Ward conditions. Physical coupling
changes are separate nontrivial deformation directions, not erased as exact.
Ordinary divergences are removed only under the established boundary conditions.

Q2–Q4 qualify a general two-parameter subclass: homogeneous independent real
invertible rescalings of the twelve H ghosts and thirty-three heavy ghosts,
with evaluation sources rescaled inversely. The parameters are dimensionless
coordinate units, not fitted interactions. Work over a Laurent coefficient
ring; infinitesimal generators are K_H=sum_H JC C and K_M=sum_M JC C.
After E2 transport, V'=U V U^-1. Derive its complete maps, inverse, grading,
real structure, physical-frame and jet compatibility. Compare all transformed
source-polynomial Euler columns and the unchanged 508 physical programs.
Derive the action first variation with the actual bracket sign. Recover the
old +partial_0 omega_0 Euler witness exactly, without rerunning old expensive
calculations. Check both Ward operators and the contraction. Holding an
operator fixed is permissible only if its conjugation is actually identical.

Primary uses weight substitution/conjugation and frozen canonical columns;
replay uses physical H commutators, an independently differentiated generating
fermion and direct left Euler differentiation of the finite action. Require
exact agreement, source-pair inverse checks, arbitrary local parameter jets,
and adversarial controls for wrong source scaling, wrong action orientation,
and omitted contraction transport. Do not force all exact generators to be
basic or discard their transformations.

Q5–Q6 distinguish a full Ward-admissible complex from its basic subcomplex.
For any proposed permitted primitive space K_adm, both obligations are needed:
Z_full=Z_basic+Q' K_adm+d currents (surjectivity), and the kernel of the
inclusion must be the stated basic equivalence (injectivity). Quotienting
basic cocycles by their intersection with full exact terms is different from
quotienting only by basic primitives. Define both; assume neither adequate.
The ghost-rescaling family can qualify without proving these equalities for
all local dimension-four, ghost-zero counterterms. Strict transported quantum
Ward invariance as a quantum requirement needs its own derivation.

Published semisimple Yang–Mills cohomology may provide a route to general
coverage. Authenticate its model, locality, regularity, coefficient-ring,
power-counting and nonminimal assumptions before applying it to this model
with external backgrounds and the chosen restrictions. If this bridge is not
established, stop Q5 with a precise proof-obligation record, not an invented
full PASS or unsupported missing nontrivial class.

Effort boundary: two initial bounded routes and one fresh byte-identical replay
of completed new evidence. First essential identity failure/underdefinition
stops the dependent gate; preserve partial qualifications and exact controls.
All-source/jet master and nilpotence may use qualified canonical/Jacobi proofs
with disclosed dependencies rather than exhaustive new source squares.

Possible dispositions: bounded equivalence for a named subclass, exact
obstruction, underdefined general target, or incomplete execution. Full E5,
catalogs, HB1/C5, activation, finite C1_GS, quantum matching, authority changes,
external publication/contact and remote push remain withheld. Validate before
a local commit; execution success is distinct from scientific completion.
