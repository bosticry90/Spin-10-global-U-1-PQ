# Actual leading mixed source poles

## Scientific disposition

**QUALIFIED_E5_LEADING_MIXED_SOURCE_POLES_AND_CANONICAL_PROJECTIONS_ONLY**.
Two distinct computations reproduce the actual leading gauge-source/ghost
and scalar-source/ghost/scalar one-loop ultraviolet coefficients. Their
coupling orders are g*xi and g^2*xi. The actual coupling-independent cubic
ghost interaction and mixed gauge–auxiliary propagation are indispensable.
The selected poles agree with two projections of one complete canonical
ghost/source normalization image, including its boundary current.

This is a nonzero-coupling source calculation, beyond the previous formal
operator identity. It qualifies these local UV poles and their candidate
canonical projections. It does not establish the complete one-loop divergence,
all Slavnov/Ward restoration, quantum A5, probes/contacts, IR/anomaly freedom,
M2–M5/A1–A5 or E5. No physical threshold, C1_GS or force matching is calculated.

Baseline ea76c8d was clean with no surviving matching calculation worker.
Twenty-six sealed predecessor chains authenticate. All34 physical/nine source
terms, E2 gauge fixing,643 pairs,48 external H backgrounds,328 real scalar
coordinates,29 potential directions, vacuum, physical parameters, nonsymmetric
coset and R_H remain. Statev113/34of39 is unchanged. Expensive predecessor
Hessian/representation/source results are reused under their exact contracts.

## Actual vertices and complete selected graph scope

The literal xi*Lambda*ub*u density has276 coefficients and no explicit g.
Its17 quadratic heavy-width coefficients are separately retained in the free
reference. The7,120 other scalar-dependent gauge-fixing coefficients are
authenticated, not replaced by textbook ghost interactions. The scalar orbit
term has g*xi and one unit of mass dimension from the fixed vacuum certificate.

A source vertex with only one integrated field is a bridge, not a1PI loop.
For the local Jx-C-x coefficient, the source has two internal legs. Counting
1PI valences leaves either two cubic vertices or a compatible quartic. At
g^2*xi the scalar–gauge cubic and the literal auxiliary–ghost cubic are the
only role-compatible dimension-zero choice. Other vertices require additional
g/xi, fail the internal-role matching, or have positive-dimensional insertions
which lower the UV degree. The g*xi JB-C coefficient has its two-vertex bubble.
Physical potential/vacuum parameters are not reset; this is a UV-degree and
coupling-coefficient selection, not deletion of the remaining action.

The reference used in both routes retains

    G_Bmu,L=i p_mu/p^2, G_L,Bmu=-i p_mu/p^2, G_LL=0,
    G_u,ub=1/p^2, G_ub,u=-1/p^2,
    G_scalar=1/(p^2-Mref^2).

The complete eight-coordinate elementary contraction block also retains all
four vector components and the full width-dependent gauge propagator. Both
inverse directions are checked. It represents the selected loop contractions,
not an independent replacement for the complete643-field system.

Primary graded Hessian Born traces include all six triangle orderings, both
orientations, odd external sources and the four Lorentz weights. Replay
direct Gaussian contractions and momentum routing recover the same result.
For generic vertex coefficients a,b,d, the triangle before integration is

    -i a b d/[p^2(p^2-Mref^2)],

with the source-left J*C*x ordering understood. The bubble gives
q_mu/[2 p^2(p+q)^2]. Its Minkowski integral supplies i, consistent with the
derivative on the external C. Dropping the mixed propagator removes both
nonzero poles. Flipping the odd propagator sign gives a different result;
omitting the Lorentz metric leaves a nonzero spatial numerator.

## Explicit UV and IR adjudication

For the triangle UV Taylor coefficient, the four-vector numerator contracts
to p^2. The positive temporary scalar reference gives the exact heat integral

    I3 = integral d^4k/(2pi)^4
           exp[-6k^2/Lambda^2]/[k^2(k^2+Mref^2)]
       = exp(c)E1(c)/(16pi^2), c=6Mref^2/Lambda^2>0.

At k=0 the radial integral is finite for Mref^2>0; this Taylor point is not
scaleless. The massless zero-momentum version is excluded. The four-dimensional
heat-radial and independent d=4-2e Feynman-parameter calculations both give
residue1/(16pi^2). The dimensional parameter integral is1/(1-e).

The finite heat subtraction is
[log(mu^2/Mref^2)-EulerGamma-log6]/(16pi^2), while modified dimensional minimal
subtraction gives [1+log(mu^2/Mref^2)]/(16pi^2). Their difference is the local
constant [1+EulerGamma+log6]/(16pi^2), not a fitted coefficient. These reference
finite values are not a physical mass prediction or a full finite vertex.
The gauge-source bubble retains nonzero external momentum and the qualified
finite heat-bubble program. Its zero-momentum massless integral is excluded.
No physical IR-removal theorem follows from either selected integral.

## Actual internal tensor and ghost-coordinate bridge

Primary derives the heavy tensor from the literal276-coefficient interaction
and the primal/dual maps. Replay reconstructs physical10-by10 commutators
and independently derives kappa_phys=8I_M-2C_H|_M. All33 cubics,35,937 tensor
entries including zeros, and1,485 gauge-source group entries agree. The latter
have zero H rows and heavy block -kappa_phys.

For the actual20-coordinate phi representation, primary reconstructs its
matrices from the literal scalar source columns and computes276 ordered
matrix-product pairs. Replay uses interleaved real/imaginary realification
of the normalized physical vector tensors. All18,000 source-matrix entries
(45 ghost directions times20 times20, including the12 zero H directions)
agree. The group contraction is one half of kappa_phys times the scalar
representation. The other scalar sectors extend by the qualified representation
commutator theorem and source columns. Fresh exhaustive Sigma matrix products
were not calculated; the complete328-source canonical projection is compared
independently below. The singlet contribution is zero.

The crucial typed conversion is

    N_M=U^-1 kappa_phys U=kappa_aux G_M,

where U maps the primal heavy ghost to the physical orthonormal carrier.
The old auxiliary kappa is a bilinear on dual-heavy coordinates; it cannot
be inserted as a ghost endomorphism. That shortcut has an exact nonzero
matrix difference. The full45-by45 N is zero on H and has trace132.
All12 H intertwining identities pass. Its reality is the qualified physical
real structure, rather than a guessed bare canonical transpose convention.

## The computed poles and canonical candidate

In the declared Minkowski/source-left convention the local residues are

    Gamma1,pole|JB-C = -g xi/(32pi^2 e) JB^mu partial_mu(N C),
    Gamma1,pole|Jx-C-x = +g^2 xi/(32pi^2 e)
                               sum_s J_s^T rho_s(N C) x_s.

Here Gamma=S+hbar Gamma1+..., so the action contribution includes hbar.
The coefficients follow from the matrix loops, Wick factors and actual tensor;
they were not chosen to fit a desired primitive. Both vanish at g=0, consistent
with the earlier ordinary-source normalization, while xi cubic interactions
still exist there.

Define the inactive generator

    Kbar=g xi JC^T N C.

It has grade(3,-1,odd). Primary computes QKbar using the complete E2 ghost
Euler/source columns. Replay simultaneously varies C by +g xi N C and JC
by -g xi N^T JC in the full68,254-coefficient E2 polynomial. Physical S0 is
unchanged because this generator acts only on the ghost/source pair.

The exact first-variation identity is

    delta_K P=-QKbar+partial_mu theta^mu,
    Cbar=QKbar-partial_mu theta^mu=-delta_K P.

Both routes agree on54,194 candidate coefficients. The current's divergence
has2,688 coefficients and cannot be silently discarded as a density. The
complete scalar projection has22,626 coefficients over all328 real components.
Its SHA256 is
`26eec2f65b7b3772a1ade5d4bbfa8ff55aab9204d24fb592f5e3ee9f2dc58b39`.
The leading gauge and scalar projections of Cbar match the independently
calculated loop residues with their common1/(32pi^2 e) factor.

The prospective counterterm is -hbar Cbar/(32pi^2 e). The remaining terms
of this full canonical image are predictions of that normalization candidate,
not already verified loop divergences. They require companion calculations.
No frozen action, fermion, source definition or physical parameter is altered,
and this counterterm is not adopted or activated.

## Canonical versus quantum transport scope

For Z=1+hbar a N, C transforms by Z and JC by Z^-T; the other598 pairs are
spectators. Evaluation pairing and both inverse directions hold through the
specified hbar order. Constant Z commutes with ordinary jets and the actual
H carrier derivative because N intertwines H. All sources and Green kernels
must follow their proper covariant/contravariant transformation; a field-only
replacement is not the claimed operation.

External JC does not cancel an integration measure. The ghost field log
Berezinian begins -hbar a Tr_spacetime,regulated(N), with carrier trace132.
Its regulated spacetime trace can depend on the H background and is retained.
Since the field change itself is order hbar, its effective-action measure
term starts at hbar^2. It is not silently normalized away as an overall
constant, nor treated as a calculated two-loop physical correction.
Composite operator/contact normalization and full quantum A5 remain unproved.

This distinction between retained sources, regularization and the measure is
consistent with [Troost and Van Proeyen, sections4–5](https://arxiv.org/html/hep-th/9307126).
The need for companion antifield/ghost amplitudes and joint identity restoration
is compared with [Grassi, Hurth and Steinhauser](https://arxiv.org/html/hep-ph/0102005).
The external-source cautions in [Anselmi](https://arxiv.org/html/1205.3862) are
retained; this selected constant linear map is not a proof for general
field-dependent source replacements. These sources support methods, not
independent scientific certification of these calculations.

## Execution, evidence and authority

Three execution preflights are preserved and excluded: coupling-only inventory
mixed the quadratic width with the cubic; a local jet-assertion name was
misspelled; the replay record lacked the common E1 dimension metadata.
No mathematical loop discrepancy is inferred from those failures. Each has
its exact source snapshot and failed log. The completed primary retains its
original source fingerprint; current-code fresh reproduction must match its
original bytes. The one specifically archived original primary binding is
the only exception; every fresh fingerprint is strict.

An initial comparator also rejected differently factored forms of the same
inherited E1 heat-bubble expression. Its exact difference is zero. The failed
comparison and old auditor are preserved; the corrected typed expansion is
restricted to that expression. Completed route bytes are unedited. The
different Born/Wick route descriptions are recorded separately, not falsely
required to have identical derivation prose.

The receipt records337 tests:292 scientific (20 new,272 inherited),24 process
and21 governance. Two new routes regenerate byte-identically;26 parent chains,
protected/state/new SHA256 bytes and read-only size/mtime metadata authenticate.
Metadata is not a whole-environment byte audit. Old expensive physics and
source assembly are reused. Historical custody remains exit2 with seven
unresolved references, never PASS. Both routes share immutable data, some
word arithmetic, Python3.10.11, SymPy1.14, assumptions and analyst. No external
endorsement or personnel requirement is claimed.

Statev113/34of39 is unchanged. No source activation/removal, auxiliary
elimination, catalog, HB1/C5, C1_GS, physical matching, personal outreach,
publication, remote push or unapproved authority change occurred.

## Next smallest scientific action

Calculate the actual g*xi ghost two-point pole and the g^2*xi JC-C-C and
JB-B-C companion poles. Compare them with the remaining projections of
this complete canonical image, allowing only independently derived additional
normalizations if needed. Then test the complete relevant Slavnov/Ward package
and its finite restoration, retaining the original-versus-regulated source
correction. Current success cannot be used to infer those remaining results.

Full E5, IR/anomalies, general contacts and quantum A5 remain open. The whole
Spin(10)xU(1)PQ investigation, including global scalar boundedness, PQ quotient,
fermion/Yukawa and phenomenological obligations, remains active and incomplete.
