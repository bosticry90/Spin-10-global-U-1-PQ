# E5 actual nonminimal-source companion and full affine normalization gate

Prospective contract. Baseline f68619f7af9838e07081165ba8144e658f398926,
state v113, 34/39, 34 sealed predecessor manifests. The previous turn made
progress by classifying the complete auxiliary-shear space and establishing
conditional full quartet membership. Its 39 directions are free only under
that quartet equation. Neither a subtraction nor quantum equivalence was chosen.

NS1: Calculate the complete actual one-loop logarithmic pole at g^2 xi for
J_antighost a C in the unchanged retained-source gauge/scalar model.
NS2: Does this pole agree with any member of the already frozen complete
quartet affine solution, and does it fix all 39 remaining directions?

## Inputs, types and authority ceiling

The input manifest is frozen_a10_e5_shear_space/bindings.json, with its full
transitive bytes. Preserve every earlier result, failed/unfinished run and
the original source/gauge-fixing/physical action, potential/vacuum/parameters,
all 643 canonical pairs, 48 external H backgrounds and both nonminimal sectors.
Sources remain external, auxiliaries integrated and R_H composite. No extra
physical coefficient, inverse physical coupling/mass, altered fermion, field
elimination, catalog, regulator or source-variable replacement is allowed.

Scope is all 45 antighost evaluation sources, all 45 antighosts and 45 ghosts:
91,125 tensor slots including justified zeros. J_antighost has grade (2,0,even),
a (1,-1,odd), C (1,1,odd). The density has (4,0,even). Raw light antighosts are
primal H and heavy antighosts are evaluation-dual M; paired sources use the
opposite carriers. Physical orthonormal maps and canonical identity evaluation
pairings must be derived, not identify two primal vectors with delta.

Freeze code/contract/input/state SHA and independent output ownership before
execution. Actual primary and replay do not read any candidate pole, affine
coefficient solution or shear-space image while calculating the actual tensor.
Compare completed actual outputs before a dependent comparison opens them.
Guard calculations read-only with the established pole-blind environment.
No agents or duplicate workers. Parallel actual routes are optional only after
independent inputs/write ownership/dependency order are established.

## Actual source and graph obligations

1. Recover the literal source columns. Light Qbar=-b gives a source term
linear in an integrated field. Prove its one-loop Hessian response is zero
and independently derive the corresponding source response from the retained
generating functional/graded Gaussian construction. Do not import a textbook
antighost equation or infer arbitrary renormalized contact identities.
Heavy Qubar retains -Lambda plus g C_H acting on the dual heavy carrier.
Its nonlinear source vertex and both odd inverse orientations must stay.
2. Screen every literal cubic/quartic graph and all reference edges for the
selected source–antighost–ghost amplitude. A connected one-loop 1PI three-point
graph has three cubics or a cubic/quartic pair; one-leg source vertices have
zero Hessian and cannot produce a proper loop vertex. Include the cubic source,
light/heavy derivative ghost vertices, xi auxiliary vertex and every possible
quartic at the relevant coupling. Prove zero channels by source/H-M ghost edge,
external incidence and UV degree, not by looking at the prediction.
Retain reference BB, BL/LB, LL=0, both ghost orientations, arbitrary light/heavy
widths and all four Lorentz copies. No auxiliary elimination or false projected
heavy adjoint closure. Mass/orbit/scalar alternatives require dimensional/edge
exclusions in the dimension-zero logarithmic coefficient.
3. Primary uses literal source/gauge-fixing tensors, graded Fourier Hessians
and all six Born triangle words, plus the full eligible bubble inventory.
Replay independently derives normalized physical10/H tensors and uses ordered
Gaussian/Wick contraction with explicit external odd ordering. Retain derivative
placements and the full integration-by-parts current before UV extraction.
Prove every excluded light-source/light-antighost/ghost-H channel over all
91,125 slots. Distinct real Euler/Fourier symbol controls check even source
variations and odd factor signs.
4. UV Taylor is only above a fixed R_UV>0 and the external/mass scales. Prove
negative UV degree of momentum remainders; no whole scaleless zero-momentum
massless integral or complete finite/IR amplitude. Keep triangle/bubble heat
profiles distinct and derive the common Minkowski pole units independently.
The numerator contraction uses all four Lorentz weights before reduction.
5. Both complete actual tensors agree, are real in physical coordinates and
obey all twelve local H identities. Transport to raw canonical coordinates
and back, preserving source evaluation duality, and keep every zero slot.

## Dependent comparison and first failure

Only after actual agreement, extract the source projection at g^2 xi from
the complete old K0+Kjoint+K3 image and from the frozen particular plus all
39 complete kernel images. Do not assume the old projection is zero.
Solve all 91,125 source equations simultaneously. Their inherited injective
map permits at most one member of the affine family. If consistent, preserve
the unique coefficients, full generator/Q image and currents, all prior matches
and the exact quartet match. It remains inactive and has not passed any other
new companion amplitude or quantum A5.

If no affine member matches, preserve the complete actual-minus-affine
obstruction, an exact affine-image annihilator and real source Euler witness
with independent signed differentiation. Stop there: no auxiliary/derivative
or JC-C-C/JB-B-C loops, extended tensor fit or normalization adoption in this
increment. A necessary actual-method, reality, frame, H, sign, UV or matching
failure similarly stops and preserves exact source/start/failure bytes.
Resource limits report unfinished work; never truncate coefficients or lower
acceptance. Scientific gate failure and successful evidence validation remain
different statuses.

## Controls and validation

Controls omit source/H ghost flow, mixed propagators, the light derivative
vertex or a Lorentz weight, reverse odd/source ordering, use a wrong primal
source map, ignore light-source equations/free directions or promote selected
matching to quantum restoration. Every counted negative control must have a
nonzero exact residual or a rejected inference. Qualify elementary controls
before actual group contraction. Shared immutable data, graded/exact arithmetic,
Python/SymPy and analyst remain disclosed under the solo-review policy.

Validate before local commit: targeted scientific/process/governance checks,
fresh strict own-byte actual primary/replay followed by dependent comparison,
34 predecessor chains, protected/new/state SHA and audit-time size/mtime.
Authenticate expensive old scientific work without rerunning it. Use the
existing python -B tools/research_check.py e5 delegate; historical custody
must remain exit 2 with seven unresolved references, never PASS. Check raw
Git-index/worktree bytes. Preserve failed and unfinished attempts explicitly.

Possible dispositions: qualified selected actual source pole and unique
inactive affine member; exact companion obstruction; underdefinition; or
incomplete execution. State stays v113/34 of 39. No full E5/A5/Ward/IR/anomaly,
physical/catalog/HB1/C5/C1_GS/matching, authority promotion, outside contact,
publication or push. The whole Spin(10) x global U(1)PQ investigation remains
active/incomplete, including global scalar/PQ and fermion/Yukawa/phenomenology.
