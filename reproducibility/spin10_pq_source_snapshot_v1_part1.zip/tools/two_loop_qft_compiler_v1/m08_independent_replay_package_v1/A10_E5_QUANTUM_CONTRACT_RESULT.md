# A10 E5 retained-source quantum Ward and insertion result

Disposition: QUALIFIED_CONDITIONAL_E5_W1_W7_WARD_SLAVNOV_INSERTION_FRAMEWORK_ONLY.
The assessment of bc6e71d explicitly permits a qualified conditional framework.
This result supplies that framework rather than requiring a loop computation
merely to define its target. It does not construct or prove the existence of an
all-order anomaly-free prescription. project_state.json remains sole authority.

## Baseline and preserved scope

Recovery found clean bc6e71dc20d848ee75d4573d3fab3c81e8a2fee0, state v113,
34/39, 562 authenticated bindings in 16 manifests and no surviving matching
worker. D/E1-E4, E5 joint closure, the qualified canonical ghost family and the
Q6.1 background controls were reused, not expensively reconstructed. The actual
643 canonical pairs, 48 external H backgrounds, 34 physical/nine source terms,
nonsymmetric coset, quartic ghosts, scalar vacuum and physical parameters stay
frozen. E1 remains a replacement with historical A4/A5 equivalence unproved.

## W1-W7 outcomes

| Gate | Bounded finding | Qualification |
| --- | --- | --- |
| W1 | Defined Z, W and Gamma with 643 integrated fields, distinct ordinary Legendre sources and 643 external BV sources | Formal perturbative definition; all 643 graded source/sign contracts checked |
| W2 | Declared a class of local QAP subtraction/measure/IR/insertion constructions and exact coefficient ring | Assumptions A1-A5; model-specific realization unproved |
| W3 | Derived nonlinear Slavnov, linearized consistency, joint restoration and first-differing-order counterterm condition | Formal derivation; no anomaly calculation or restoration proof |
| W4 | Derived local background Ward and probe identities; background-only functionals retained | Conditional quantum restoration, with all local parameter jets and breakings retained |
| W5 | Derived geometric broken quantum Ward and whole-product insertion realization of transported quantum H | Does not impose a naive fixed classical Tq' on Gamma |
| W6 | Defined source/observable mixing, canonical equivalence and operator transport requirements | Tree maps qualified; actual quantum mixing/Jacobian/equivalence unproved |
| W7 | Distinct bounded routes agree, preserve decisive controls, and regenerate byte-identically | Internal computational reproducibility under shared assumptions, software and analyst |

The detailed derivation, signs, assumptions and normalized target are in
[the functional specification](A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md); the frozen
acceptance scope is in [the contract](A10_E5_QUANTUM_CONTRACT_V1.md).

## The substantive new distinction

The background operation has affine field rules and field-independent external
source rules, so its restored target is the ordinary local W_b Gamma=0, subject
to the declared quantum assumptions. The geometric quantum operation instead
obeys W_q Gamma=[T_q S_R]_Gamma+M_q. It is intentionally broken by light gauge
fixing. The selected tree Euler_b0 remains -2 Box omega0.

The transported classical operation has 56 nonzero source correction slots,
3,032 coefficients; 55 slots depend on integrated fields. Both routes compare
all 643 slots, including zeros, and all background source corrections vanish.
Primary uses the authenticated field-variation columns. Replay independently
differentiates the literal complete source-plus-gauge-fixing density for the
56 needed sources. Multiplying these Euler insertions by the corrections gives
22,520 tree product coefficients. The COMPLETE geometric breaking plus product
minus the authenticated transported current is zero exactly. That particular
transported current is zero in the existing density convention; other inherited
BV/boundary currents are not discarded or declared zero.

At quantum level the product must remain a renormalized insertion. It cannot
be replaced without proof by c_J(phi) times Gamma_J. A separate exact Gaussian
calculation derives moments through degree four both by generating-functional
differentiation and by integration-by-parts recursion. With precision matrix
[[a,k],[k,c]], it finds

    <xy> - <x><y> = -hbar k/(a c-k^2),
    <x^2> - <x>^2 = hbar c/(a c-k^2).

These are controls of product insertion and nonlinear mean-field semantics,
not Spin(10) amplitudes. The full affine Gaussian Ward identity also matches.
Differentiating a genuine probe-dependent Gaussian shows that the old breaking
insertion must be differentiated too: its contribution is -2 hbar c/(a c-k^2).
Ignoring it gives an incorrect single-probe Ward identity. No actual quantum
defect of the Spin(10) construction is inferred from this finite control.

The Slavnov expansion is checked independently through fourth order, including
(Gamma1,Gamma3)+(Gamma2,Gamma2)/2. A graded six-pair canonical control verifies
the linearized square X_S(Gamma), consistency of a nonzero breaking and the
source-left orientation X_K S=-QK. It deliberately distinguishes consistency
of an anomaly from its vanishing. All quantum corrections are not declared
local or individually Q-closed; only the appropriate local first difference
of restored prescriptions has the homogeneous counterterm condition.

## Counterterm and equivalence target

The conditional target is a retained-source 1PI functional and normalized
insertion system. At the first differing restored order its local counterterm
delta obeys Q'delta=0 and W_b delta=0, accompanied by the VARIED geometric
quantum-breaking and observable-insertion identities. No unproved strict
Tq'-kernel or horizontality condition is imposed on this quantum target.
The relation to the previously qualified classical joint basic complex remains
a later theorem/domain obligation, not automatic coverage or surjectivity.

The default retains background-only terms. The sealed L_bg control is already
basic and nontrivial in the declared polynomial complex; its selected Euler is
-2 ddot b. L_div still fails local background Ward with Euler_omega0 equal to
2 partial0^3 A0_0. Neither is proved loop-generated. An additional invariant
background normalization can remove background responses from a narrower
target, but is not adopted here.

F' remains trivial with its qualified canonical generator admitted and nonzero
modulo ordinary divergences when all primitives are forbidden. Its original
nonhorizontal witness, wrong-source-pairing defect zH^2-1 and fixed-contraction
defect remain sealed. No universal source-removability theorem follows.
Quantum canonical replacements must carry insertions, Jacobian/normalization
and Q/T/iota/observable transport. A field-dependent external-source map is not
automatically an ordinary change of integration variables or a scalar Gamma
transformation. No extended master-functional alphabet is introduced.

## Assumptions and literature comparison

A1: formal measure/Legendre, suitable propagators and boundary/IR prescription.
A2: local QAP with source/background/probe power counting in the declared ring.
A3: joint restoration if breakings are trivial and normalizations compatible.
A4: renormalized composite/contact insertions with controlled mixing.
A5: justified quantum canonical replacement or measure/insertion equivalence.
All are explicit conditional inputs. Their simultaneous realization, anomaly
freedom and all-order nonempty prescription class are UNPROVED. This conditional
framework does not promote any assumption into a scientific fact.

[Barnich, Brandt and Henneaux](https://arxiv.org/html/hep-th/0002245) supplies
the retained-antifield stability/anomaly distinction. [Grassi, Hurth and
Steinhauser](https://arxiv.org/html/hep-ph/0102005) supplies QAP and joint
Ward/Slavnov restoration with normalized insertions. [Anselmi](https://arxiv.org/html/1205.3862)
supplies the warning about field-dependent external-source canonical changes.
Their additional model hypotheses and background/master-functional extensions
are not imported. Published theory supports methods, not external certification.

## Execution and validation

An initial unaccepted assertion compared a selected omega0 witness with an
unprojected column containing omega1 via the light Gram matrix. The complete
tree insertion identity had passed. The corrected selected control projects
only that witness and retains all four second parameter jets; the full 643-slot
comparison remains unprojected. The failed attempt is recorded separately.
Initial completed routes preceding the stronger single-probe check are kept
under superseded_initial_routes, excluded from final PASS evidence. Nothing
was overwritten, reset or counted as a completed final route prematurely.
The first validation transaction then detected differently factored rational
forms for two fourth moments. Their exact differences reduce to zero. Those
routes and the failed validation disposition are also preserved, excluded from
final evidence. Canonical rational serialization resolves the representation
mismatch; the final routes must regenerate and agree without such adjustments.

The completed validation receipt records 151 targeted regressions: 16 new and
135 inherited (106 scientific, 24 process, 21 governance). Two FINAL new routes
regenerate byte-identically, with write attempts denied. Six declared validation
commands return their expected exits; the delegated historical custody step
still returns 2 with seven unresolved references. Sixteen predecessor manifests
authenticate; all declared protected bytes and project_state.json are unchanged.
The receipt records exact commands, diagnostic output, runtimes, Python/SymPy,
new hashes and protected hashes. Workspace/active-data inventory checks size
and modification time, not every byte of the environment. Old expensive model
calculations were authenticated rather than rerun. Bounded evidence validation
is distinct from actual quantum-scheme construction or physical correctness.

Only new versioned derivation, tooling, evidence and navigation files were added;
the live AGENTS handoff link moved to V5 and was snapshotted separately. No old
scientific artifact, catalog, action, parameter or authority record was edited.
No activation, personal contact, HB1/C5, C1_GS, publication or remote push.

## Stop and next decision

Stop after conditional W1-W7 qualification. Q6.2-Q6.6, full E5, theorem
applicability, regularity/Koszul-Tate completeness and full/basic equivalence
remain unqualified. The next smallest investigation is the regularity and
complete Noether-resolution bridge in the actual admitted polynomial/jet
language, followed conditionally by the Ward/insertion-to-basic theorem-domain
comparison. These require separate bounded execution, not catalog generation.
Actual realization of A1-A5 remains an explicit quantum obligation alongside
that mathematical bridge. M08/HB1/C5 remain blocked, C1_GS uncalculated,
formal authority 34/39 and custody exit 2/seven references unchanged.
