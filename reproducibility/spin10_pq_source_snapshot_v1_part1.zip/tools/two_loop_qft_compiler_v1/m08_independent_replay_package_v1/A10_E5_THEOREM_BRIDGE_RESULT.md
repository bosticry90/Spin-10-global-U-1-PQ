# E5 theorem bridge: quantum target stop with exact scope controls

The bounded investigation of e66d1d6 completed at the first unsupported gate,
Q6.1. Its disposition is

    STOP_E5_Q6_1_QUANTUM_COUNTERTERM_WARD_TARGET_UNQUALIFIED

The repository supplies a qualified classical retained-source construction and
canonical normalization family. It does not yet supply a justified complete
renormalized Ward/insertion target for the proposed counterterm theorem. This
is underdefinition, not a new contradiction of the physical action or D/E1-E4.

## What was completed

The frozen contract is A10_E5_THEOREM_BRIDGE_CONTRACT_V1.md. The accompanying
[assumption map](A10_E5_THEOREM_ASSUMPTION_MAP_V1.md) supplies a concrete conditional
1PI/Slavnov formulation, dimensions, local polynomial ring, external-background
and source scope, primary-literature comparison and remaining proof obligations.
It preserves the distinction between full/basic, intrinsic/induced and quantum
versus classical statements. No quantum renormalization policy is adopted.

Both routes independently derive a background curvature control in the actual
12-generator H frame, with all 48 background components and local parameter
jets. They match 444 curvature coefficients, 1,392 density coefficients and
4,308 background Euler coefficients. All 72 curvature transformation columns
satisfy the expected local H law, and the complete density has zero background
Ward variation. The singlet/physical/source action is unchanged; this control
is not inserted into any action or catalog.

Primary uses authenticated H constants and prefix Leibniz variation. Replay
reconstructs 990 physical Spin(10) matrix commutators, varies the curvature first
and derives Euler covectors by independent left-gradient integration by parts.
They share the existing exact word arithmetic, inputs, Python/SymPy and analyst.
No outside endorsement or proof-kernel formalization is claimed.

The ordinary jet, real-structure and Lorentz conventions matter. The selected
real physical H direction obeys the authenticated conjugation rule. Its spatial
time-dependent background Abar^0_1=b(t) gives

    L_bg=dot b^2,   Euler_b=-2 ddot b.

The coefficient two follows from G_H,00=2. It is not fitted and no parameters
are changed. This derivative is nonzero, so the density is not an ordinary
divergence. Since backgrounds are Q-inert, the control is Q-closed, horizontal
and invariant under both declared Ward operators. It is already basic.

The nonexactness argument is explicitly bounded to the declared polynomial
physical coefficient ring. Pull back the canonical U, specialize g and potential
coefficients to zero, and set canonical fields, sources and all their jets to
zero while retaining arbitrary background jets. All 1,286 source-polynomial
images vanish; the authenticated physical free Euler programs vanish too and
contain no pre-U external Abar. Every admitted polynomial QK then restricts to
zero, and a divergence stays a divergence, while the displayed background Euler
derivative survives. The post-U specialization is transported, not all shifted
sources set to zero. Inverse physical couplings would invalidate this argument;
the broader ring is neither adopted nor classified.

This provides a concrete nontrivial class in the specified polynomial complex.
Keeping background-only functionals admits it; excluding or further quotienting
them removes it by an additional target rule. That is not a missing-class
counterexample to the original basic domain. No loop generation of this class
or measured coupling correction is established.

## Further adversarial checks

A dimension-four background gauge-divergence density remains Q-closed and
Tq'-invariant but violates local Tb. Its exact free temporal witness is

    Euler_omega0(Tb L_div)=+2 partial_0^3 Abar^0_0.

It cannot be dismissed as a divergence, and a constant-parameter test misses
the failure. Removing Tb therefore changes the admitted cocycle target. The
same polynomial stationary argument controls its nonexactness. This is an
adversarial scope comparison, not a proposal to weaken the background identity.

The authenticated canonical-family F' has the exact free derivative

    Euler_JB0_0 F'=-partial_0 C0.

It is zero in the quotient permitting its qualified primitive, but remains
nonzero modulo divergences if no primitives are admitted. This demonstrates
generator-scope sensitivity without claiming that arbitrary source-dependent
deformations can be removed. The old nonhorizontal +partial_0 omega0 witness,
inverse-source pairing defect zH^2-1 and fixed-contraction defect remain intact.
The earlier expensive canonical family is authenticated, not freshly rerun.

The two formal Slavnov expansions agree through order three. Order two includes
(Gamma1,Gamma1)/2. Dropping it would incorrectly impose Q'-closure on every
Gamma_n. Homogeneous closure applies conditionally to the first differing
counterterm order between restored solutions. This is algebraic bookkeeping,
not a computation of Gamma, anomalies, the measure or the quantum action principle.
All 643 pair grades translate consistently to conventional power counting;
that check alone does not qualify a homotopy or a theorem's full function space.

## Stop and validation

Q6.1 remains unqualified because the complete quantum Ward/insertion and
background-normalization system has not been derived. Q6.2-Q6.6 are not executed
as acceptance gates. The normality/regularity and Koszul-Tate bridge, full/basic
surjectivity and intrinsic/induced equivalence remain unproved. The literature
matrix records these dependencies without treating a semisimple group, a
classical master PASS or regression counts as proof of their hypotheses.

The completed receipt records targeted regressions, two fresh byte-identical
new routes, exact commands, runtime and hashes. Fifteen predecessor chains
authenticate; their expensive mathematical calculations are not repeated.
Protected evidence is checked by byte hashes; the broader workspace inventory
uses size/mtime metadata, not unrestricted byte validation. The receipt is
validation of a stopping result, not quantum target acceptance or full E5 PASS.

Formal authority remains 34/39 and M08 blocked. Strict custody remains exit 2
with seven unresolved references. No frozen evidence, physical parameters,
sources, action or catalogs are modified. No activation, HB1/C5, C1_GS,
matching, publication, personal contact or remote push occurs.

The next smallest scientific increment is to derive the retained-source quantum
Ward/Slavnov and insertion contract, including the role of Tq', background-only
terms, observables and canonical operator renormalization. This requires a
concrete functional/renormalization argument or a proved class of admissible
constructions, not a mandatory external person or arbitrary regulator choice.
Only after that prerequisite qualifies should the theorem applicability and
both cohomology comparisons proceed.
