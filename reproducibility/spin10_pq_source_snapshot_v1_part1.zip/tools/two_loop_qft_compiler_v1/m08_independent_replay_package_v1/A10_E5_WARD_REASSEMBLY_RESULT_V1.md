# Corrected measured local Ward system, WR result V1

The corrected13-sector measured logarithmic residue has been reassembled and
its FULL local background-H variation independently recalculated. Primary
uses the qualifying GS corrected sum and prefix Leibniz variation. Replay
independently sums its own sector records, imports the actual gauge-source
projection, pulls back its physical JC-CC pole and uses graded jet gradients.
Every sector, Ward coefficient, parameter Euler and boundary current agrees.

The known residue has27,971 canonical terms. The local Ward variation has
13,168 canonical terms,34,464 parameter-anchored terms and59,304 real physical
terms. All1,334 operator columns are retained:1,286 field/source coordinates
and48 external background components. The operator inventory proves17,676
homogeneous linear-g terms and96 affine H-connection shifts, including BOTH
B_H and A_H. No affine heavy connection or hidden scalar/source shift is
assumed. Every constant-H parameter projection is zero; all12 local parameter
Eulers and four3,472-term ordinary boundary currents are retained.

The new actual JC-CC pole has exactly zero local H variation in both routes.
This is calculated, not discarded because of a predicted zero. The full Ward
parameter/primal/dual frame roundtrip and physical reality are checked. The
remaining measured variation is not an ordinary boundary: one real physical
omega_p0 Euler coefficient is -36*g10^3*xi/25 multiplying
Bp13_0*Cp12*partial_0(ap13). Its complete Euler polynomial is stored, rather
than treating a single coefficient as the whole obligation. No EOM quotient.

## Corrected open dependencies

Independent forward-incidence and reverse-predecessor enumerations agree.
There are six Ward target signatures and ten unmeasured input TYPE classes.
The last two targets have one/two parameter derivatives and share the same
source/connection/ghost input classes. They yield five amplitude families:

| g10 order | Unmeasured input types | Ordinary input jets |
| --- | --- | --- |
| 2 | Lambda B B; Lambda A_H B | 0 |
| 2 | J_B B C; J_B A_H C | 0 |
| 3 | B B antighost C; A_H B antighost C | 0 |
| 3 | J_antighost B B; J_antighost A_H B | 0 |
| 3 | J_Lambda B C; J_Lambda A_H C | 1 |

The B component varied by an affine image must be in H; other B components
remain in their full representation. These are admitted alternatives, not
claims that every listed coefficient or diagram is nonzero. No invariant
coefficient basis is inferred from a type census. Known contributions keep
their original loop/width/coupling scopes; unknown coefficients remain None,
never zero. An actual graph calculation must independently establish zeros
and retain all source/ghost/gauge directions, irrespective of the target
support or previously predicted zeros.

The lowest-order open source condition is the actualg10^2*xi J_B-B-C and
J_B-A_H-C system. Its calculation should retain source parity (J_B is ODD),
both odd orientations, mixed inverses, full Lorentz components, all actual
source/gauge/background vertices and complete coupling/UV/1PI exclusions.
The Ward census supplies the question, not the required tensor as loop input.
The auxiliary Lambda-B-B family atg10^2 is also open. Higher derivative/source
families, insertion/contact and regulated breaking obligations remain.

## Superseded coefficient interpretation

The old MF V3 Ward result has the same sparse term COUNTS, but not the same
coefficients. Its540-term difference from the corrected result is exactly
Tb acting on the99-term inherited gauge-source metric error. This identity
is checked only after complete corrected-method agreement. Old Ward bytes,
MF/GS failed assemblies, preparations, outputs and dispositions are preserved;
byte authentication of those records does not scientifically qualify them.
Current corrected coefficients and the real witness above supersede their
affected coefficient interpretations. No source pole or normalizer was fitted.

## Qualification and remaining scope

Disposition: qualified corrected MEASURED local Ward variation and open partner
dependencies, subject to the completed receipt and seal. The exact equation is
W_b(Gamma_known+Gamma_unknown)=Delta_b. Neither Gamma_unknown nor Delta_b,
regulated measure, insertions/contact normalizations or finite/IR complements
has been set to zero. A nonzero known Euler does not establish a measured
complete breaking, anomaly, defective model or full E5 failure.

The preceding selectedg10^2 antighost-CC/twojet Slavnov LEFT SIDE remains
qualified as an ordinary divergence with zero anchored representative. That
does not prove Delta_s=0 or full quantum restoration. The g10^3 four-ghost
inactive-candidate mismatch remains FAIL. No canonical candidate, completion
coefficient, image or new actual loop is computed in this reassembly.

The indexed scalar Hessian-square and regulated ghost power/finite programs
remain separate with their conventions/scopes; they are not silently merged
or assigned a full Ward value. Higher nonlinear Slavnov brackets, W1-W7/A1-A5,
quantum canonical equivalence and whole-product/source-operator transport are
unqualified. HB1/C5 stay blocked, finiteC1_GS uncalculated. Scalar/globalPQ,
fermionYukawa, phenomenology and the complete Spin(10)xglobalU(1)PQ objective
remain open. Statev113/34of39 and all protected bytes remain unchanged.

The exclusive receipt owns tests/commands/source snapshots/starts/full stdout,
four fresh own-byte executions,44 protected predecessor chains and new/
protected/state/metadata invariance. Custodyexit2/seven unresolved references
is expected, neverPASS. Old expensive loops/images authenticate only. Raw
Git index/worktree equality is required before localcommit; no push/publication.

Provenance and verification are bounded and explicit under the existing
epistemic ladder. Formalization is not attempted; empirical connection is
none; interpretation is established within the declared measured/type scope.
Methods share actual inputs, qualified Ward operators, some arithmetic,
Python/SymPy and analyst. They are not independent scientists or external
endorsement. Solo-review policy and no-outreach direction remain in force.

Next: freeze the actual leading J_B-B-C/A_H source-pole graph/Lorentz contract,
calculate independently of this Ward target, then test the enlarged measured
source condition with full currents. The whole goal stays active/incomplete.
