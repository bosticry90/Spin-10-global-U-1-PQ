"""Read-only audit that all current authority summaries match the ledger."""

from __future__ import annotations

import json

from authority_state import HERE, ROOT, derive


def main() -> None:
    summary = derive()
    compiler = json.loads((HERE / "compiler_status.json").read_text(encoding="utf-8"))
    state = json.loads((ROOT / "project_state.json").read_text(encoding="utf-8"))
    node = state["scaffold"]["two_loop_qft_compiler_v1"]
    layer5 = json.loads((HERE / "layer5_status.json").read_text(encoding="utf-8"))

    for payload in (compiler, node):
        assert payload["layer5a_tests_executed"] == summary["tests_executed"]
        assert payload["layer5a_execution_progress"] == summary["progress_code"]
        assert payload["layer5a_current_result_sha256"] == summary["ledger_sha256"]
        assert payload["layer5a_M08"] == "BLOCKED"
        assert payload["layer6_tensor_IBP_reduction_authorized"] is False
    assert compiler["layer5a_M08_current_implementation_blocker"] == summary[
        "current_implementation_blocker"]
    assert node["layer5a_M08_BRST_remaining_blocker"] == summary[
        "current_implementation_blocker"]
    assert compiler["layer5a_M08_C2_D5_checkpoint_sha256"] == summary[
        "c2_d5_checkpoint_artifact_sha256"]
    assert node["layer5a_M08_C2_D5_checkpoint_sha256"] == summary[
        "c2_d5_checkpoint_artifact_sha256"]
    assert compiler["layer5a_M08_C3_C4_checkpoint_sha256"] == summary[
        "c3_c4_checkpoint_artifact_sha256"]
    assert node["layer5a_M08_C3_C4_checkpoint_sha256"] == summary[
        "c3_c4_checkpoint_artifact_sha256"]
    assert compiler["layer5a_M08_C5_checkpoint_sha256"] == summary[
        "c5_checkpoint_artifact_sha256"]
    assert node["layer5a_M08_C5_checkpoint_sha256"] == summary[
        "c5_checkpoint_artifact_sha256"]
    assert compiler["layer5a_M08_ST_seed_checkpoint_sha256"] == summary[
        "st_seed_checkpoint_artifact_sha256"]
    assert node["layer5a_M08_ST_seed_checkpoint_sha256"] == summary[
        "st_seed_checkpoint_artifact_sha256"]
    assert compiler["layer5a_M08_action_AST_checkpoint_sha256"] == summary[
        "action_ast_checkpoint_artifact_sha256"]
    assert node["layer5a_M08_action_AST_checkpoint_sha256"] == summary[
        "action_ast_checkpoint_artifact_sha256"]
    assert layer5["layer5a_progress"] == summary["progress"]
    assert layer5["blocker"] == summary["current_implementation_blocker"]
    assert layer5["layer6_authorized"] is False
    assert layer5["M08_C3_C4_checkpoint_sha256"] == summary[
        "c3_c4_checkpoint_artifact_sha256"]
    assert layer5["M08_C5_checkpoint_sha256"] == summary[
        "c5_checkpoint_artifact_sha256"]
    assert layer5["M08_ST_seed_checkpoint_sha256"] == summary[
        "st_seed_checkpoint_artifact_sha256"]
    assert layer5["M08_action_AST_checkpoint_sha256"] == summary[
        "action_ast_checkpoint_artifact_sha256"]
    if summary["current_checkpoint_kind"] == "C5_POSITIVE_GHOST_TARGET_CATALOG_PROMOTED":
        assert summary["progress"] == "34/39" and summary["formal_attempt"] == 1
        assert summary["layer6_authorized"] is False and layer5["finite_C1_GS"] is None
        assert state["research"]["active_physics_calculation"] == (
            "TWO_LOOP_QFT_COMPILER_V1_LAYER5B_M08_C5_H_BASIC_QUALIFICATION_PENDING")
        target = json.loads((HERE / "m08_independent_replay_package_v1/T5_target_catalog_checkpoint.json").read_text(encoding="utf-8"))
        assert target["target_catalog_promoted"] and not target["H_basic_qualified"]
        for payload in (compiler, node):
            assert payload["layer5a_M08_C5_target_checkpoint_sha256"] == summary["current_checkpoint_artifact_sha256"]
            assert payload["layer5a_M08_C5_weight_contract_qualified"] is True
            assert payload["layer5a_M08_C5_target_catalog_promoted"] is True
            assert not payload["layer5a_M08_C5_complex_promoted"] and not payload["layer5a_M08_C5_H_basic_qualified"]
            assert payload["layer5a_M08_C5_target_counts"] == target["counts"]
            assert payload["layer5a_M08_local_operator_dimension"] == 54148
            assert payload["layer5a_M08_joint_catalog_promoted"] is True
        assert layer5["M08_C5_target_checkpoint_sha256"] == summary["current_checkpoint_artifact_sha256"]
        assert layer5["M08_C5_target_catalog_promoted"] and not layer5["M08_C5_complex_promoted"]
        assert not layer5["M08_C5_H_basic_qualified"] and layer5["M08_C5_target_counts"] == target["counts"]
    elif summary["current_checkpoint_kind"] == "C5_WEIGHT_CONTRACT_TARGET_CATALOG_PENDING":
        assert summary["progress"] == "34/39" and summary["formal_attempt"] == 1
        assert summary["layer6_authorized"] is False and layer5["finite_C1_GS"] is None
        assert state["research"]["active_physics_calculation"] == (
            "TWO_LOOP_QFT_COMPILER_V1_LAYER5B_M08_C5_WEIGHT_GRADED_TARGET_PENDING")
        for payload in (compiler, node):
            assert payload["layer5a_M08_C5_weight_grading_checkpoint_sha256"] == summary["current_checkpoint_artifact_sha256"]
            assert payload["layer5a_M08_C5_weight_contract_qualified"] is True
            assert payload["layer5a_M08_C5_target_catalog_promoted"] is False
            assert payload["layer5a_M08_C5_complex_promoted"] is False
            assert payload["layer5a_M08_joint_catalog_promoted"] is True
            assert payload["layer5a_M08_local_operator_dimension"] == 54148
        assert layer5["M08_C5_weight_grading_checkpoint_sha256"] == summary["current_checkpoint_artifact_sha256"]
        assert layer5["M08_C5_weight_contract_qualified"] is True
        assert not layer5["M08_C5_complex_promoted"] and not layer5["M08_C5_target_catalog_promoted"]
    elif summary["current_checkpoint_kind"] == "C5_GRADED_CLOSURE_CONTRACT_BLOCKED":
        assert summary["progress"] == "34/39" and summary["formal_attempt"] == 1
        assert summary["layer6_authorized"] is False and layer5["finite_C1_GS"] is None
        assert state["research"]["active_physics_calculation"] == (
            "TWO_LOOP_QFT_COMPILER_V1_LAYER5B_M08_C5_GRADED_CLOSURE_CONTRACT_BLOCKED")
        for payload in (compiler, node):
            assert payload["layer5a_M08_C5_complex_preflight_checkpoint_sha256"] == summary["current_checkpoint_artifact_sha256"]
            assert payload["layer5a_M08_C5_complex_promoted"] is False
            assert payload["layer5a_M08_ordered_internal_basis_promoted"] is True
            assert payload["layer5a_M08_background_packet_basis_promoted"] is True
            assert payload["layer5a_M08_joint_catalog_promoted"] is True
            assert payload["layer5a_M08_realization_quotient_qualified"] is True
            assert payload["layer5a_M08_local_operator_dimension"] == 54148
        assert layer5["M08_C5_complex_preflight_checkpoint_sha256"] == summary["current_checkpoint_artifact_sha256"]
        assert layer5["M08_C5_complex_promoted"] is False and layer5["M08_joint_catalog_promoted"] is True
        assert layer5["M08_local_operator_dimension"] == 54148
    elif summary["current_checkpoint_kind"] == "JCAT12_LOCAL_OPERATOR_CATALOG_PROMOTED":
        assert summary["progress"] == "34/39" and summary["formal_attempt"] == 1
        assert summary["layer6_authorized"] is False and layer5["finite_C1_GS"] is None
        assert state["research"]["active_physics_calculation"] == (
            "TWO_LOOP_QFT_COMPILER_V1_LAYER5B_M08_JCAT12_LOCAL_OPERATOR_CATALOG_PROMOTED")
        for payload in (compiler, node):
            assert payload["layer5a_M08_jcat12_checkpoint_sha256"] == summary["current_checkpoint_artifact_sha256"]
            assert payload["layer5a_M08_ordered_internal_basis_promoted"] is True
            assert payload["layer5a_M08_background_packet_basis_promoted"] is True
            assert payload["layer5a_M08_joint_catalog_promoted"] is True
            assert payload["layer5a_M08_realization_quotient_qualified"] is True
            assert payload["layer5a_M08_homogeneous_occurrence_realization"] == "FINAL_DIAGONAL_STATISTICS_APPLIED_AT_JCAT11"
            assert payload["layer5a_M08_local_operator_dimension"] == 54148
        assert layer5["M08_jcat12_checkpoint_sha256"] == summary["current_checkpoint_artifact_sha256"]
        assert layer5["M08_joint_catalog_promoted"] is True
        assert layer5["M08_local_operator_dimension"] == 54148
    elif summary["current_checkpoint_kind"] == "JCAT7_GLOBAL_BACKGROUND_PACKETS_PROMOTED":
        assert summary["progress"] == "34/39" and summary["formal_attempt"] == 1
        assert summary["layer6_authorized"] is False and layer5["finite_C1_GS"] is None
        assert state["research"]["active_physics_calculation"] == (
            "TWO_LOOP_QFT_COMPILER_V1_LAYER5B_M08_JCAT7_GLOBAL_PACKETS_PROMOTED")
        for payload in (compiler, node):
            assert payload["layer5a_M08_jcat7_global_checkpoint_sha256"] == summary[
                "current_checkpoint_artifact_sha256"]
            assert payload["layer5a_M08_ordered_internal_basis_promoted"] is True
            assert payload["layer5a_M08_background_packet_basis_promoted"] is True
            assert payload["layer5a_M08_joint_catalog_promoted"] is False
            assert payload["layer5a_M08_realization_quotient_qualified"] is True
            assert payload["layer5a_M08_homogeneous_occurrence_realization"] == "TAGGED_UNTIL_JCAT11"
        assert layer5["M08_jcat7_global_checkpoint_sha256"] == summary[
            "current_checkpoint_artifact_sha256"]
        assert layer5["M08_background_packet_basis_promoted"] is True
        assert layer5["M08_joint_catalog_promoted"] is False
        assert layer5["M08_realization_quotient_qualified"] is True
    elif summary["current_checkpoint_kind"] == "JCAT7_REALIZATION_V3_QUALIFIED_GLOBAL_PACKETS_PENDING":
        assert state["research"]["active_physics_calculation"] == (
            "TWO_LOOP_QFT_COMPILER_V1_LAYER5B_M08_JCAT7_REALIZATION_QUALIFIED_PACKETS_PENDING")
        for payload in (compiler, node):
            assert payload["layer5a_M08_jcat_realization_v3_checkpoint_sha256"] == summary[
                "current_checkpoint_artifact_sha256"]
            assert payload["layer5a_M08_ordered_internal_basis_promoted"] is True
            assert payload["layer5a_M08_joint_catalog_promoted"] is False
            assert payload["layer5a_M08_realization_quotient_qualified"] is True
        assert layer5["M08_jcat_realization_v3_checkpoint_sha256"] == summary[
            "current_checkpoint_artifact_sha256"]
        assert layer5["M08_realization_quotient_qualified"] is True
        assert layer5["M08_joint_catalog_promoted"] is False
    elif summary["current_checkpoint_kind"] == "JCAT7_BACKGROUND_PACKETS_V2_KERNEL_BLOCKED":
        assert state["research"]["active_physics_calculation"] == (
            "TWO_LOOP_QFT_COMPILER_V1_LAYER5B_M08_JCAT7_PACKET_KERNEL_BLOCKED")
        for payload in (compiler, node):
            assert payload["layer5a_M08_jcat_background_packets_v2_checkpoint_sha256"] == summary[
                "current_checkpoint_artifact_sha256"]
            assert payload["layer5a_M08_ordered_internal_basis_promoted"] is True
            assert payload["layer5a_M08_joint_catalog_promoted"] is False
        assert layer5["M08_jcat_background_packets_v2_checkpoint_sha256"] == summary[
            "current_checkpoint_artifact_sha256"]
        assert layer5["M08_ordered_internal_basis_promoted"] is True
        assert layer5["M08_joint_catalog_promoted"] is False
    elif summary["current_checkpoint_kind"] == "JCAT_LORENTZ_V2_BACKGROUND_CONTRACT_BLOCKED":
        assert state["research"]["active_physics_calculation"] == (
            "TWO_LOOP_QFT_COMPILER_V1_LAYER5B_M08_JCAT7_BACKGROUND_CONTRACT_BLOCKED")
        for payload in (compiler, node):
            assert payload["layer5a_M08_jcat_lorentz_v2_checkpoint_sha256"] == summary[
                "current_checkpoint_artifact_sha256"]
            assert payload["layer5a_M08_ordered_internal_basis_promoted"] is True
            assert payload["layer5a_M08_joint_catalog_promoted"] is False
        assert layer5["M08_jcat_lorentz_v2_checkpoint_sha256"] == summary[
            "current_checkpoint_artifact_sha256"]
        assert layer5["M08_ordered_internal_basis_promoted"] is True
        assert layer5["M08_joint_catalog_promoted"] is False
    elif summary["current_checkpoint_kind"] == "JCAT3_CONTRACT_PREFLIGHT_BLOCKED":
        assert state["research"]["active_physics_calculation"] == (
            "TWO_LOOP_QFT_COMPILER_V1_LAYER5B_M08_JCAT3_CONTRACT_BLOCKED")
        for payload in (compiler, node):
            assert payload["layer5a_M08_jcat3_checkpoint_sha256"] == summary[
                "current_checkpoint_artifact_sha256"]
            assert payload["layer5a_M08_ordered_internal_basis_promoted"] is True
            assert payload["layer5a_M08_joint_catalog_promoted"] is False
        assert layer5["M08_jcat3_checkpoint_sha256"] == summary[
            "current_checkpoint_artifact_sha256"]
        assert layer5["M08_ordered_internal_basis_promoted"] is True
        assert layer5["M08_joint_catalog_promoted"] is False
    elif summary["current_checkpoint_kind"] == "INT9_INT15_ORDERED_INTERNAL_BASIS_ADJUDICATED":
        assert state["research"]["active_physics_calculation"] == (
            "TWO_LOOP_QFT_COMPILER_V1_LAYER5B_M08_INT9_INT15_ADJUDICATED")
        for payload in (compiler, node):
            assert payload["layer5a_M08_int9_int15_checkpoint_sha256"] == summary[
                "current_checkpoint_artifact_sha256"]
        assert layer5["M08_int9_int15_checkpoint_sha256"] == summary[
            "current_checkpoint_artifact_sha256"]
    elif summary["current_checkpoint_kind"] == "INT8_MULTIPLICITY_BLOCK_CONJUGATION_V2_ADJUDICATED":
        assert state["research"]["active_physics_calculation"] == (
            "TWO_LOOP_QFT_COMPILER_V1_LAYER5B_M08_INT8_BLOCK_CONJUGATION_V2_ADJUDICATED")
        for payload in (compiler, node):
            assert payload["layer5a_M08_int8_conjugation_checkpoint_sha256"] == summary[
                "current_checkpoint_artifact_sha256"]
        assert layer5["M08_int8_conjugation_checkpoint_sha256"] == summary[
            "current_checkpoint_artifact_sha256"]
    elif summary["current_checkpoint_kind"] == "INT8_CONJUGATION_SINGLE_ADDRESS_CONTRACT_BLOCKED":
        assert state["research"]["active_physics_calculation"] == (
            "TWO_LOOP_QFT_COMPILER_V1_LAYER5B_M08_INT8_CONJUGATION_CONTRACT_BLOCKED")
        for payload in (compiler, node):
            assert payload["layer5a_M08_int8_conjugation_checkpoint_sha256"] == summary[
                "current_checkpoint_artifact_sha256"]
        assert layer5["M08_int8_conjugation_checkpoint_sha256"] == summary[
            "current_checkpoint_artifact_sha256"]
    elif summary["current_checkpoint_kind"] == "SCALAR_BRIDGE_V3_INT7R_ADJUDICATION":
        assert state["research"]["active_physics_calculation"] == (
            "TWO_LOOP_QFT_COMPILER_V1_LAYER5B_M08_INT7R_SCALAR_BRIDGE_V3_ADJUDICATED")
    else:
        assert summary["current_checkpoint_kind"] == "SCALAR_ADAPTER_V2_INT7R_BLOCKED"
        assert state["research"]["active_physics_calculation"] == (
            "TWO_LOOP_QFT_COMPILER_V1_LAYER5B_M08_INT7R_SCALAR_ADAPTER_V2_CHECKPOINT_BLOCKED")
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    assert summary["current_implementation_blocker"] in readme
    assert "authoritative ledger remains `34/39`" in readme
    assert "action-AST amendment" in readme
    assert "17/17" in readme
    assert "joint permutation-resolved group/Lorentz-jet catalog" in readme
    assert "dimension `46`" in readme
    assert "431" in readme
    assert "198,060" in readme
    assert "intertwiner" in readme
    assert "271" in readme
    assert "236" in readme
    assert "205,332" in readme
    assert "affine" in readme
    assert "1,984" in readme
    assert "INT4R" in readme
    assert "INT7R" in readme
    assert "205,332" in readme
    print("AUTHORITY_COHERENCE_AUDIT_PASS")
    print("PROGRESS", summary["progress"])
    print("FIRST_NON_PASS", summary["first_non_pass"], summary["first_non_pass_status"])
    print("CURRENT_BLOCKER", summary["current_implementation_blocker"])
    print("LAYER6_AUTHORIZED=false")


if __name__ == "__main__":
    main()
