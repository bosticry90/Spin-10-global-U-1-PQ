"""Local read-only delegation; execution completion never promotes scientific authority."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
PACKAGE='tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
SCOPES={'e4':('a10_e4_interaction','frozen_a10_e4_interaction'),
        'e5':('a10_e5_domain','frozen_a10_e5_domain')}
SCHEMA='TOE_LOCAL_RESEARCH_CHECK_EVENT_V1'


def plan(scope,fresh=False):
    stem,folder=SCOPES[scope]
    return [('preflight',['tools/research_session_preflight.py','--manifest',PACKAGE+'/'+folder+'/bindings.json'],0),
            ('bounded_evidence',[PACKAGE+'/audit_'+stem+'.py']+(['--fresh'] if fresh else []),0),
            ('authority',['tools/two_loop_qft_compiler_v1/audit_authority_coherence.py'],0),
            ('structure',['tools/readiness/audit_structure_preserving_map_contract.py'],0),
            ('read_only',['tools/readiness/audit_read_only_contract.py'],0),
            ('historical_custody',['docs/ai_research_epistemic_ladder_v1/audit_epistemic_ladder.py'],2)]


def emit_json(event):print(json.dumps(event,sort_keys=True,separators=(',',':')),flush=True)


def execute(scope,*,fresh=False,budget=None,run=subprocess.run,emit=emit_json,clock=time.monotonic,root=ROOT):
    started=clock();records=[];recorded_gate=None
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(root/'tools/pole_blind_validation_guard'))
    before=sha256((root/'project_state.json').read_bytes()).hexdigest()
    def event(kind,**values):
        row={'schema':SCHEMA,'event':kind,'scope':scope,'scientific_acceptance':'NOT_PERFORMED',**values}
        emit(row);return row
    def terminal(state,reason):
        return event('terminal',execution_state=state,reason=reason,steps_completed=len(records),
            recorded_scientific_gate=recorded_gate,fresh_requested=fresh,
            interpretation='bounded delegated checks only; custody exit 2 is unresolved, never global PASS')
    event('started',mode='fresh_replay_requested' if fresh else 'authenticate_existing_evidence',
          state_sha256=before,effort_boundary_seconds=budget,scope_is_authorization=False)
    try:
        for name,args,expected in plan(scope,fresh):
            if budget is not None and clock()-started>=budget:
                return terminal('INCONCLUSIVE','EFFORT_BOUNDARY_BEFORE_NEXT_ATOMIC_STEP')
            if not (root/args[0]).is_file():return terminal('BLOCKED','MISSING_DELEGATE_'+args[0])
            if name=='preflight' and not (root/args[-1]).is_file():return terminal('BLOCKED','MISSING_SEALED_MANIFEST')
            command=[sys.executable,'-B',*args]
            event('step_started',step=name,command=command,expected_exit_code=expected)
            tick=clock()
            result=run(command,cwd=root,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
            row={'step':name,'exit_code':result.returncode,'expected_exit_code':expected,
                 'seconds':clock()-tick,'stdout':result.stdout,'stderr':result.stderr}
            event('step_finished',**row)
            if result.returncode!=expected:
                text=result.stdout+result.stderr
                protected=any(s in text for s in ('POLE_BLIND_VALIDATION_READ_DENIED','READ_ONLY_WRITE_DENIED'))
                return terminal('BLOCKED' if protected else 'FAILED',
                                'PROTECTED_BOUNDARY' if protected else 'UNEXPECTED_EXIT_'+name)
            if sha256((root/'project_state.json').read_bytes()).hexdigest()!=before:
                return terminal('FAILED','FORMAL_STATE_CHANGED_DURING_CHECK')
            if name=='bounded_evidence':
                values=[json.loads(line[6:]) for line in result.stdout.splitlines() if line.startswith('AUDIT ')]
                if len(values)!=1 or not values[0].get('status','').startswith('PASS_BOUNDED_'):
                    return terminal('BLOCKED','MISSING_OR_UNRECOGNIZED_BOUNDED_AUDIT')
                recorded_gate=values[0].get('scientific_gate')
                if not recorded_gate:return terminal('BLOCKED','MISSING_RECORDED_SCIENTIFIC_DISPOSITION')
                if fresh and values[0].get('fresh_routes_byte_identical')!={'e4':3,'e5':2}[scope]:
                    return terminal('FAILED','FRESH_COMPLETION_NOT_RECORDED')
            if name=='historical_custody' and result.stdout.count('RECORDED_DIGEST_UNRESOLVED:')!=7:
                return terminal('FAILED','CUSTODY_EXPECTATION_CHANGED_REQUIRES_REVIEW')
            records.append(row)
    except KeyboardInterrupt:return terminal('CANCELED','VALIDATION_INCOMPLETE_CHECK_PROCESS_INVENTORY_BEFORE_RETRY')
    except (OSError,ValueError) as error:return terminal('BLOCKED','EXECUTION_OR_RECEIPT_ERROR: '+str(error))
    return terminal('COMPLETED','ALL_DECLARED_EXIT_CODES_MATCHED; SCIENTIFIC_ACCEPTANCE_NOT_PERFORMED')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('scope',choices=SCOPES)
    parser.add_argument('--fresh',action='store_true',help='explicitly rerun existing bounded evidence routes')
    parser.add_argument('--budget-seconds',type=float,help='stop before another atomic step; never weaken a check')
    args=parser.parse_args()
    if args.budget_seconds is not None and args.budget_seconds<0:parser.error('budget must be nonnegative')
    row=execute(args.scope,fresh=args.fresh,budget=args.budget_seconds)
    return 0 if row['execution_state']=='COMPLETED' else 2


if __name__=='__main__':sys.exit(main())
