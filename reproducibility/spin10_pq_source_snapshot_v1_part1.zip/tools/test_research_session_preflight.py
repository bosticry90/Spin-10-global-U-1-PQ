"""Adversarial tests for recovery integrity, not tests of scientific physics."""
from hashlib import sha256
import json
from pathlib import Path
import unittest
from unittest.mock import patch
from research_session_preflight import authenticate_bytes, inside, active_processes


class PreflightTests(unittest.TestCase):
    def fixture(self, changed=False, conflict=False):
        root = Path("C:/preflight_fixture")
        payload = b"frozen evidence\n"
        digest = sha256(payload).hexdigest()
        child = {"byte_sha256": {"evidence": digest if not conflict else "0" * 64}}
        child_bytes = json.dumps(child).encode()
        parent = {"byte_sha256": {"evidence": digest},
                  "inherited_manifest_sha256": {"child": sha256(child_bytes).hexdigest()}}
        values = {"parent": json.dumps(parent).encode(), "child": child_bytes,
                  "evidence": payload if not changed else b"edited"}
        return root, values

    def test_checks_inherited_evidence(self):
        root, values = self.fixture()
        with patch.object(Path, "read_bytes", lambda p: values[p.name]):
            result = authenticate_bytes(root, "parent")
        self.assertEqual(result["manifests_visited"], 2)
        self.assertFalse(result["scientific_acceptance_inferred"])

    def test_changed_evidence_rejected(self):
        root, values = self.fixture(changed=True)
        with patch.object(Path, "read_bytes", lambda p: values[p.name]):
            with self.assertRaisesRegex(ValueError, "BOUND_BYTE_CHANGED"):
                authenticate_bytes(root, "parent")

    def test_outside_reference_rejected(self):
        with self.assertRaisesRegex(ValueError, "REFERENCE_OUTSIDE_REPOSITORY"):
            inside(Path("C:/preflight_fixture"), "../outside")

    def test_missing_binding_is_not_skipped(self):
        root, values = self.fixture()
        del values["evidence"]
        with patch.object(Path, "read_bytes", lambda p: values[p.name]):
            with self.assertRaises(KeyError):
                authenticate_bytes(root, "parent")

    def test_state_snapshot_drift_rejected(self):
        root = Path("C:/preflight_fixture")
        values = {"parent": json.dumps({"state_sha256": "0" * 64,
                  "byte_sha256": {"evidence": sha256(b"ok").hexdigest()}}).encode(),
                  "evidence": b"ok",
                  "project_state.json": b"{}"}
        with patch.object(Path, "read_bytes", lambda p: values[p.name]):
            with self.assertRaisesRegex(ValueError, "STATE_DIFFERS"):
                authenticate_bytes(root, "parent")

    def test_empty_manifest_cannot_authenticate(self):
        with patch.object(Path, "read_bytes", lambda p: b"{}"):
            with self.assertRaisesRegex(ValueError, "UNSUPPORTED_OR_EMPTY_MANIFEST"):
                authenticate_bytes(Path("C:/preflight_fixture"), "parent")

    def test_historical_state_is_not_current_authority(self):
        root, values = self.fixture()
        child = json.loads(values["child"])
        child["state_sha256"] = "0" * 64
        values["child"] = json.dumps(child).encode()
        parent = json.loads(values["parent"])
        parent["inherited_manifest_sha256"]["child"] = sha256(values["child"]).hexdigest()
        values["parent"] = json.dumps(parent).encode()
        values["project_state.json"] = b"{}"
        with patch.object(Path, "read_bytes", lambda p: values[p.name]):
            result = authenticate_bytes(root, "parent")
        self.assertEqual(result["historical_state_snapshots"]["child"], "0" * 64)

    def test_process_inventory_failure_not_empty(self):
        with patch("research_session_preflight.subprocess.run") as run:
            run.return_value.returncode = 1
            run.return_value.stderr = "unavailable"
            with self.assertRaisesRegex(RuntimeError, "PROCESS_INVENTORY_UNAVAILABLE"):
                active_processes()

    def test_legacy_decoder_and_historical_input_bindings(self):
        root = Path("C:/preflight_fixture")
        data = {key:{key:sha256(key.encode()).hexdigest()} for key in
                ("evidence_byte_sha256","implementation_byte_sha256","scientific_input_byte_sha256","historical_input_sha256")}
        values = {key:key.encode() for key in data}
        values["parent"] = json.dumps(data).encode()
        with patch.object(Path, "read_bytes", lambda p: values[p.name]):
            result = authenticate_bytes(root, "parent")
        self.assertEqual(result["file_bindings_checked"],4)

    def test_legacy_scientific_input_drift_rejected(self):
        data = {"scientific_input_byte_sha256":{"evidence":sha256(b"old").hexdigest()}}
        values = {"parent":json.dumps(data).encode(),"evidence":b"changed"}
        with patch.object(Path,"read_bytes",lambda p:values[p.name]):
            with self.assertRaisesRegex(ValueError,"BOUND_BYTE_CHANGED"):
                authenticate_bytes(Path("C:/preflight_fixture"),"parent")


if __name__ == "__main__":
    unittest.main()
