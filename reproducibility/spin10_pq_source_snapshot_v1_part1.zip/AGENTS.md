# ToE-Next research execution

Recover actual state from Git, live processes and repository evidence before
starting work. Use `python -B tools/research_session_preflight.py` for a compact
read-only snapshot, then follow [the handoff](docs/RESEARCH_EXECUTION_HANDOFF_V18.md)
and the task's versioned acceptance contract. A snapshot authenticates bytes;
it does not execute or scientifically accept their calculations.

`project_state.json` is the sole machine-readable scientific authority. The
human director sets scope, foundational assumptions, priorities, acceptance,
publication and external actions. Agents investigate, implement, test,
challenge and report; do not silently promote bounded findings or unlock work.

Reuse the existing [epistemic ladder](docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md)
and [solo-review policy](docs/SOLO_REVIEW_POLICY_V1.md). No personal outreach,
recruitment or mandatory outside reviewer. Disclose shared assumptions, data,
software and authorship; multiple AI instances are not independent scientists.

For each bounded increment, freeze types, assumptions, immutable inputs,
expected evidence, failure conditions and authority ceiling before computation.
Keep proposals, calculations, evidence validation and director acceptance
distinct. Preserve exact failed and unfinished runs with explicit classifications.
Use distinct derivations and negative controls where scientifically meaningful.

Before parallel execution, establish independent inputs, write ownership and
dependency order. Prefer read-only independent calculations; compare completed
outputs before dependent checks or mutations. Parallelism is optional. Do not
launch agent organizations or repeat expensive qualified work without need.
Use suitable existing tools and structural proofs with explicit dependencies;
resource limits must report incomplete work, never silently truncate evidence.

Preserve uncommitted work and running calculations. No reset, evidence editing,
unrelated process termination, activation, remote push or unapproved publication.
Do not treat historical custody exit 2 as PASS. Validate completed bounded work
before a local commit, and record checks omitted, limitations and the next
smallest authorized scientific action. A failed scientific gate may have
successfully authenticated failure evidence; keep those statuses separate.

Use [local research conventions](docs/LOCAL_RESEARCH_CONVENTIONS_V1.md) for
the delegated validation command and execution states. Effort boundaries may
reduce engineering scope; they never reduce scientific acceptance obligations.
