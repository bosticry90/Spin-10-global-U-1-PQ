# Standing research autonomy — effective 2026-10-16

The director expressly authorized this operational-policy transition and
autonomous scientific continuation in the supplied “Standing ToE-Next Research
Autonomy Directive.” Its preserved complete message has SHA256
466cebcfae4f5ad5320396176358f90e238258222713d314194245c7a725c128,
held at the external research-control location
`research-autonomy-transition-v1-2026-10-16/director_message.txt` under the
existing ToE-Next control-record root. Baseline:
66de6a6cfd58cd87801455bebd9b6be39f7fa0c6.

> The desired operating model is maximum scientifically justified autonomy,
> rigorous verification, minimal unnecessary user interruption and clear
> accountability for results.

This is standing human delegation, not an AI-granted waiver. It supersedes
routine per-increment permission requirements prospectively. It changes no
scientific result, foundational theory, acceptance standard or state authority.

## Ordinary scientific discretion

Codex may select questions and priorities within the established mission,
choose mathematical/computational methods, review literature, define bounded
experiments, write and run code, verify derivations, correct implementation
errors, investigate provisional hypotheses/parameter regions, reject failed
candidates and redirect or deprioritize unproductive exploratory lines.
After each result, verify and interpret it, then continue the next justified
bounded step. No routine director choice between technical alternatives,
separate run-count approval or automatic stop after a milestone is required.

Exploration permitted by the established action is not foundational adoption.
An exploratory parameter point is not an accepted physical benchmark. Compare
plausible outcomes, existing evidence and the cheapest competent tests before
expensive work. Use known exclusions and complete necessary-condition coverage
early. Avoid indefinite low-value testing or successive parameter releases
whose only motivation is avoiding a negative result.

Scientific investigation and AI scientific-capability evaluation remain equal
objectives. The director's education is voluntary, concurrent and nonblocking;
no lesson, examination, teach-back or proficiency prerequisite is introduced.
Scope and significance must remain understandable, while scientific evidence
and verification determine the authority of a claim.

## Verification, resources and corrections

Keep versioned calculation records with explicit questions, assumptions,
definitions, immutable inputs, evidence, negative controls, failure outcomes,
authority ceilings and resource limits before substantial execution. Preserve
separate proposal, execution, validation and scientific acceptance semantics.
Use independent derivations where warranted; acknowledge inherited human
literature, shared assumptions/data/software/analyst and limited independence.
AI agreement does not validate a shared physical premise or constitute external
expert endorsement. Reproducibility and hashes do not establish physical truth.

Ordinary parsing, encoding, serialization, numerical, assertion or verification
harness repairs are delegated. Preserve failed sources, complete captures and
their classifications. A correction may not change physical inputs, weaken
mathematical obligations, hide a failed run or manufacture a scientific PASS.

Historical contracts and their exact run limits stay immutable. Once exhausted,
a new versioned bounded continuation may be established under this directive,
with its own rationale, frozen inputs, resource observations and stopping rules.
That does not retroactively authorize or qualify any earlier execution. Use
proportionate budgets and actual machine resources; report resource exhaustion
as incomplete. Reassess methods after repeated failures. No unrestricted
computation, silent truncation or evasion of binding resource/security limits.

## Reserved director decisions

Explicit director authorization remains required for foundational adoption or
replacement, changed overarching objectives, protected scientific promotions
outside an approved acceptance process, publication, outreach, remote push,
deployment, spending, restricted-system access, destructive or irreversible
changes to protected evidence/data, explicitly blocked-stage activation or
resumption of an area on human-controlled pause. Ask only when such a decision
is unavoidable and no valuable authorized alternative remains. Application and
environment permissions remain binding.

The accepted scalar-contact filter and closure of the eta=eps^3 route remain
in force. The fixed-eta exclusion and every qualified positive/negative result
retain their scope. This transition does not qualify E5/A5, activate HB1/C5, calculate
C1_GS, resume flavor, adopt a benchmark, choose a gauge/IR prescription or
claim complete scattering, global stability, quantum control or physical GUT
viability. Historical custody exit 2/seven is not PASS. Authority remains 34/39.

## Non-destructive policy transition and conflict resolution

The root [AGENTS.override.md](../AGENTS.override.md) is the live instruction
entry point. Official OpenAI documentation specifies that Codex checks it
before AGENTS.md in the same directory, loading at most one file per directory.
The current conversation also has direct human authorization; this does not
claim that a running session dynamically reloads instruction files.
[OpenAI instruction discovery](https://learn.chatgpt.com/docs/agent-configuration/agents-md#how-codex-discovers-guidance).

Keep AGENTS.md, CHARTER.md, README.md, local conventions, authority policy,
preflight and every old contract/receipt byte-identical. Their scientific,
provenance and solo-review obligations continue. Apply these narrow live
interpretations rather than rewriting their bound historical bytes:

| Historical language | Effective prospective interpretation |
| --- | --- |
| Director sets scope/priorities/acceptance | Director retains strategic/reserved decisions; ordinary research scope, priorities, methods and bounded validation are delegated |
| No following execution allowance; separate approval required | Historical increment ended as recorded; a justified new versioned increment may start under this standing authorization |
| No automatic retry; run count exhausted | No mutation or retroactive retry under that frozen contract; prepare a bounded continuation/correction version autonomously |
| Rerun unfinished work only under its existing contract | Preserve it; use a new explicit continuation when needed, with unchanged scientific obligations |
| Remote/local alignment expected at normal completion | No remote push is authorized; local commits follow validation |
| Active seam names a blocked physical threshold | Do not unlock it; pursue justified existing scalar/structural/AI objectives within standing delegation |

project_state.json remains the sole machine-readable scientific authority.
This policy and handoffs are operating guidance and provenance, not an alternate
scientific status ledger. Do not change state merely to register governance.
Future calculation bindings should include the live override/directive as well
as whichever historical premises they actually use. Original preflight and
integrity checks run unchanged; no hash exception, rebinding, skipped drift
check or alteration of historical evidence is permitted.

The transition is complete only after UTF-8/link and policy consistency review,
protected-byte authentication, original preflight and raw staged/committed checks.
No physics calculation qualifies through the governance checks. Continue with
the general coherent-Sigma inequality against the actual mass/Higgs/stability
conditions after this transition; choose its scientifically best bounded test
without another routine authorization request.
