# ToE-Next — standing research delegation

The director's 2026-10-16
[Research Autonomy Directive](docs/RESEARCH_AUTONOMY_DIRECTIVE_V1.md) is the
effective operating policy. Read it before interpreting old scope/approval
language. It authorizes ordinary research and versioned bounded continuations;
do not ask for routine per-calculation or engineering-repair permissions.

Retain the scientific rigor, evidence preservation, solo review, three-track
model and repository protections in [AGENTS.md](AGENTS.md),
[CHARTER.md](CHARTER.md) and
[local conventions](docs/LOCAL_RESEARCH_CONVENTIONS_V1.md). Their historically
bound bytes remain unchanged. The new directive supersedes their routine
scope/priority/next-run approval requirements, not their scientific standards.

Start with `python -B tools/research_session_preflight.py`. Read the current
research handoff (the highest numbered `docs/RESEARCH_EXECUTION_HANDOFF_V*.md`)
and the relevant calculation contracts/actual receipts. A preflight authenticates
declared bytes; it does not accept mathematics. project_state.json remains
the sole machine-readable scientific authority.

Choose the most informative justified next scientific question and cheapest
competent method. Freeze assumptions, inputs, outcomes, verification and
resource limits before substantial computation. Use separate derivations and
meaningful negative controls. Preserve every failed/incomplete attempt and
shared-error limitation. Never weaken a scientific gate to obtain PASS.

After a bounded result, verify it, reassess significance and continue justified
work. Exhausted historical run allowances remain historical; create a new
versioned bounded continuation under the standing delegation when warranted.
Diagnose and correct ordinary implementation/encoding/serialization/numerical
or harness defects without another approval request. Reassess repeated failures
and computational cost; never silently expand resources or truncate evidence.

Exploratory hypotheses and provisional parameter regions allowed by the parent
action may be tested and rejected autonomously. They are not accepted physics
inputs or validated benchmarks. Closed failed curves and prior exclusions keep
their qualified dispositions. Do not repeatedly release inputs merely to rescue
a favored hypothesis. Do not reuse parameter-specific evidence outside its scope.

Ask only for an unavoidable reserved decision: foundational adoption/change,
protected scientific promotion outside an approved process, changed overarching
goals, explicitly blocked-stage activation, human-paused work, publication,
outreach, remote push, spending, restricted access or destructive/irreversible
protected-data action. Preserve main; no new branch/worktree or remote action.

Science and AI-capability evaluation remain equally important. Education is
voluntary, concurrent and nonblocking. Multiple AI implementations are not
independent scientists. Report meaningful findings, failures and limits concisely;
do not manufacture activity or treat completion of one increment as goal completion.
