# SMP1 extension before computation: retain the complete free source action

The same bounded comparison can test every principal quadratic source
degree,not only the ordinary projection. Use Sigma_free=S0+sum(-1)^p J R0,
then qJ=(-1)^p Euler Sigma_free BEFORE any restriction. Test all free
field/source flow parities,nilpotence and free-action invariance. This
retains cotangent source terms as well as ordinary Euler terms.

Primary still receives ONLY actual G;replay receives ONLY actual QG.
Both retain every degree2,principal,intrinsic0 term with source degrees
0/1/2. A source-free-only comparison is insufficient to qualify this
extended quadratic premise. At this combined degree nonlinear field or
cotangent rules from cubic-and-higher Sigma raise degree;G has no
principal linear term. Confirm this support premise from the actual input.
Physical matter terms cannot contribute without a matter field/source in
G at this degree. This does not close nonlinear or higher-intrinsic masters.

The whole four-momentum polynomial is retained. Endpoint and source
orientation controls must be derived from this operation,not inferred
from the known one-loop cutoff coefficient. If the source sectors disagree,
record their exact difference even when the ordinary projection agrees.
The native outputs retain both the complete quadratic polynomial and its
ordinary projection. All original RECORD limits/ceilings remain binding.
