from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from functools import lru_cache
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith(('replay'if role=='primary'else'primary')):raise PermissionError('SMP1_PEER_DENIED')
  if p.parent.name in ['canonical_so10_intrinsic_source_cutoff_defect','canonical_so10_intrinsic_auxiliary_ghost_source']and p.name.endswith('tables.json.gz'):raise PermissionError('SMP1_QUANTUM_TARGET_DENIED')
  if p.parent.name=='canonical_so10_probe_mass_dimension_one':raise PermissionError('SMP1_OLD_U_TARGET_DENIED')
sys.addaudithook(guard)
d=load(O/(role+'_inputs.json.gz'));sys.path.insert(0,str(Path(read(O/'ring_inputs.json')['coefficient_ring']).parent));from coefficient_ring import coefficient,constant,I as CI,verify_basis_products
assert verify_basis_products()==1024
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
def pw(a,n):
 z=constant(1)
 for _ in range(n):z=z*a
 return z
xs=[f'x_{sec}_{i}'for sec,n in [('Phi',54),('Sigma',252),('phi',20),('S',2)]for i in range(n)];aux=[('b'if i<12 else'L')+str(i)for i in range(45)];ants=[('bar'if i<12 else'ub')+str(i)for i in range(45)];cs=['C'+str(i)for i in range(45)];phys=[f'B{i}_{mu}'for i in range(45)for mu in range(4)]+xs+aux+cs+ants;assert len(phys)==643;ni={n:i for i,n in enumerate(phys)};nf=643;src0=2*nf
def parity(i):return int(i%nf>=553)if i<src0 else 1-int((i-src0)%nf>=553)
def dim(n):return 2 if n in aux else 1
zero=(0,0,0,0)
def mom(*inds):
 z=[0]*4
 for i in inds:z[i]+=1
 return tuple(z)
def canon(w):
 odds=[i for i in w if parity(i)]
 if len(set(odds))!=len(odds):return (),0
 return tuple(sorted(w)),(-1)**sum(parity(a)*parity(b)*(a>b)for j,a in enumerate(w)for b in w[j+1:])
def add(out,w,p,v):
 ww,sg=canon(w)
 if sg and v:out[ww,p]+=sg*v
def clean(z):return {k:v for k,v in z.items()if v!=0}
def plus(*terms):
 out=defaultdict(lambda:0)
 for z,f in terms:
  for k,v in z.items():out[k]+=f*v
 return clean(out)
def mul(A,B):
 out=defaultdict(lambda:0)
 for(w,p),v in A.items():
  for(ww,pp),z in B.items():add(out,w+ww,tuple(a+b for a,b in zip(p,pp)),v*z)
 return clean(out)
def deriv(A,i,right=False):
 out=defaultdict(lambda:0)
 for(w,p),v in A.items():
  for at,n in enumerate(w):
   if n==i:
    sg=(-1)**(parity(i)*sum(parity(j)for j in(w[at+1:]if right else w[:at])));out[w[:at]+w[at+1:],p]+=sg*v
 return clean(out)
def vary(A,flow):
 out=defaultdict(lambda:0)
 for(w,p),v in A.items():
  for at,n in enumerate(w):
   for(ww,pp),z in flow.get(n,{}).items():add(out,w[:at]+ww+w[at+1:],tuple(a+b for a,b in zip(p,pp)),(-1)**sum(parity(k)for k in w[:at])*v*z)
 return clean(out)
def encode(z):return [[list(w),list(p),str(v)]for(w,p),v in sorted(z.items())]
def field(k,m):return m*nf+k
def source(k,m):return src0+m*nf+k
def free():
 S=defaultdict(lambda:0);Q={};half=co('1/2')
 for m,q in [(0,1),(1,-1)]:
  opp=1-m
  for a in range(45):
   for mu in range(4):
    i=4*a+mu
    for nu in range(4):
     j=4*a+nu;w=(field(i,opp),field(j,m))
     if mu==nu:
      for z in range(4):add(S,w,mom(z,z),half)
     add(S,w,mom(mu,nu),-half)
    L=ni[aux[a]];add(S,(field(i,opp),field(L,m)),mom(mu),q*half);add(S,(field(L,opp),field(i,m)),mom(mu),-q*half);Q[field(i,m)]={((field(ni[cs[a]],m),),mom(mu)):q*CI}
   L=ni[aux[a]];add(S,(field(L,opp),field(L,m)),zero,half*co('eta_H'if a<12 else'xi'))
   Q[field(ni[ants[a]],m)]={((field(L,m),),zero):CI}
   for z in range(4):add(S,(field(ni[ants[a]],opp),field(ni[cs[a]],m)),mom(z,z),constant(1))
  for n in xs:
   for z in range(4):add(S,(field(ni[n],opp),field(ni[n],m)),mom(z,z),half)
 S=clean(S);assert not vary(S,Q),'free_action_BRST_failed'
 Sigma=dict(S)
 for f,F in Q.items():
  m,k=divmod(f,nf);J=source(k,1-m)
  Sigma=plus((Sigma,1),(mul({((J,),zero):constant((-1)**int(k>=553))},F),1))
 for m in range(2):
  for k in range(nf):Q[source(k,m)]={key:(-1)**int(k>=553)*v for key,v in deriv(Sigma,field(k,1-m)).items()}
 for f,F in Q.items():assert not vary(F,Q),('free_source_field_nilpotence_failed',f)
 return S,Sigma,Q
a=d['audit'];names=a['names'];geo=a['geometry'];base=geo['names'];fields={names.index(base[f]):base[f]for f,J,h,k in geo['field_source_h_k']};sources={names.index(base[J]):base[f]for f,J,h,k in geo['field_source_h_k']}
def number(n,m):
 if n in fields:return field(ni[names[n]],m)
 return source(ni[sources[n]],m)
def fphase(n):
 if n in aux:return -CI
 if n.startswith('B')and n.endswith('_0'):return CI
 return constant(1)
def wphase(n,wrong=False):
 f=sources[n]if n in sources else names[n];v=fphase(f)
 if n in sources:
  v=pw(v,3)if v==CI or v==-CI else v
  v=v*((-1)**(int(ni[f]>=553)+1))
  if wrong and f in aux:v=-v
 return v
def rawco(p,ci,gp):
 z=0
 for xp,ep,m,num,den in p['coefficients'][ci]:
  v=s.Rational(num,den)*g**gp*xi**xp*eta**ep
  for j,p0 in enumerate([2,3,5,7]):
   if m&(1<<j):v*=s.sqrt(p0)
  if m&16:v*=s.I
  z+=v
 return co(str(z))
def density(p,pdim,wrong_phase=False,wrong_reverse=False):
 out=defaultdict(lambda:0);audit=Counter()
 for idx,(gp,w,ci)in enumerate(p['monomials']):
  if any(n not in fields and n not in sources for n,I in w):audit['A0_background_or_control']+=1;continue
  n=pdim-sum((3-dim(sources[k]))if k in sources else dim(names[k])for k,I in w)-sum(len(I)for k,I in w)
  if n!=0:audit['other_intrinsic_grade']+=1;continue
  if len(w)!=2:audit['other_combined_polynomial_degree']+=1;continue
  assert all((sources[k]if k in sources else names[k])in ni for k,I in w)
  source_count=sum(k in sources for k,I in w);audit['retained_source_degree'+str(source_count)]+=1
  v=-rawco(p,ci,gp);pp=[0]*4
  for k,I in w:
   v=v*wphase(k,wrong_phase)
   for j in I:pp[int(j)]+=1;v=v*(CI if int(j)==0 else constant(1))
  for m,q in [(0,1),(1,-1)]:
   z=v;ww=[]
   for at,(k,I)in enumerate(w):
    im=1-m if at==0 else m;fac=q if at or wrong_reverse else-q;z=z*pw(CI*fac,len(I));ww.append(number(k,im))
   add(out,tuple(ww),tuple(pp),z)
 return clean(out),dict(audit)
results=[]
if role=='primary':
 S,Sigma,Q=free()
 for probe,p in enumerate(a['physical_G']):
  G,aa=density(p,3);qG=vary(G,Q);ordinary={key:v for key,v in qG.items()if not any(n>=src0 for n in key[0])}
  elementary=vary(G,{f:F for f,F in Q.items()if f<src0});badW,_=density(p,3,wrong_phase=True);badR,_=density(p,3,wrong_reverse=True)
  controls={'omit_source_Euler_changed_positions':len(plus((qG,1),(elementary,-1))),'wrong_auxiliary_source_Wick_phase_changed_positions':len(plus((qG,1),(vary(badW,Q),-1))),'wrong_first_momentum_orientation_changed_positions':len(plus((qG,1),(vary(badR,Q),-1)))}
  results.append({'probe':probe,'density':encode(qG),'ordinary_density':encode(ordinary),'input_audit':aa,'controls':controls});print('STAGE SMP1 primary',probe,'full',len(qG),'ordinary',len(ordinary),controls,flush=True)
else:
 for probe,p in enumerate(a['physical_QG']):
  qG,aa=density(p,4);ordinary={key:v for key,v in qG.items()if not any(n>=src0 for n in key[0])};assert all(sum(parity(i)for i in w)%2==0 for w,pp in qG);results.append({'probe':probe,'density':encode(qG),'ordinary_density':encode(ordinary),'input_audit':aa});print('STAGE SMP1 replay',probe,'full',len(qG),'ordinary',len(ordinary),flush=True)
out={'schema':'SMP1_ACTUAL_PRINCIPAL_QUADRATIC_SOURCE_MASTER_COMPARISON','role':role,'field_order':phys,'paired_modes':[1,-1],'results':results,'four_momentum_polynomial_retained':True,'free_field_and_source_nilpotence_checked':role=='primary','qG_is_not_a_quantum_counterterm':True,'full_nonlinear_master_or_QAP_not_inferred':True};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/(role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'source_master_positions':[[z['probe'],len(z['density']),len(z['ordinary_density'])]for z in results]},sort_keys=True),flush=True);timer.cancel()
