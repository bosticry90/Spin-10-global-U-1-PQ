# SMP5: final interpretation and evidence review

Prospective after SMP4 qualification. Freeze RESULT.md and its source copy,
all prior preparations, six native captures (one expected FAILED), every
source copy, actual receipts and external E4 capture. Independently inspect
the principal coefficient/zero typing counts and selected quartic symbol;
check every bound byte, resource observation, output hash and expected
failure classification. Do not rerun all previously qualified science.

Run E4 once: python -B tools/research_check.py e4, full capture external.
Require native0, declared steps[0,0,0,0,0,2], COMPLETED; custody exit2/seven
is NOTPASS. This authenticates the bounded sealed records and declared
audits, not fresh whole scientific replay. No state changes permitted.

SMP5 native180s afterimports,8GiB sampled private,350MiB pagefile floor,
32MiB packet unchanged. Missing or inconsistent evidence means FAILED or
INCONCLUSIVE, no scientific receipt. The original reduction FAILED is not
overwritten or relabeled PASS. Full color tensor remains UNMEASURED;
full Ward/QAP/E5 remain unqualified. Then preserve old blob/mode IDs,
state and exact new raw bytes before a local main commit. No remote action.
