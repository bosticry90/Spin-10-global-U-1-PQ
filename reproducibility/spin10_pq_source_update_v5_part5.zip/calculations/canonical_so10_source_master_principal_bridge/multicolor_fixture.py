def multicolor(seed):
 free=[];terms=[];n,x,J,C,rho=[dim+k for k in [4,5,2,3,1]];roots={k:{}for k in ['BC','aL','MC','MX','MR','higher']};half=co('1/2')
 N=[[1,2],[-1,1],[2,3],[1,-2]];XX0=[[2,1],[-1,3]];W=[[1,2],[2,-1],[-1,3],[2,1]];JB=[[1,2],[-2,1]];JL=[[2,-1],[1,3]];RB=[[2,-1],[1,2]];RL=[[-1,2],[3,1]];MC=[[[1,2],[0,-1]],[[2,1],[-1,3]],[[-1,1],[2,0]],[[3,2],[1,-2]],[[1,-1],[2,2]]];MX=[[1,2],[-1,1]];MRB=[[1,2],[-1,1]];MRL=[[1,0],[2,-1]];MRA=[[-1,2],[1,0]]
 for mode,q in [(0,1),(1,-1)]:
  off=mode*per;opp=(1-mode)*per
  for a in range(2):
   free.append((half*q,(opp+a,off+2+a)));free.append((-half*q,(opp+2+a,off+a)));free.append((half*(3+a+seed),(opp+2+a,off+2+a)));free.append((half,(opp+4+a,off+4+a)));free.append((constant(1),(opp+8+a,off+6+a)))
   add(roots['BC'],off+a,off+6+a,1,CI*q);add(roots['aL'],off+8+a,off+2+a,1,CI)
  for b in range(4):
   for i in range(2):
    v=constant(N[b][i]+seed);terms.append((half*v,(n,opp+b,off+4+i)));terms.append((half*v,(n,opp+4+i,off+b)))
  for a in range(2):
   for i in range(2):
    v=CI*q*(XX0[a][i]+seed);terms.append((-half*v,(x,opp+a,off+4+i)));terms.append((half*v,(x,opp+4+i,off+a)))
  for b in range(4):
   for c in range(2):terms.append((constant(W[b][c]+seed),(J,off+6+c,opp+b)))
  for a in range(2):
   for b in range(2):
    terms.append((CI*q*(JB[a][b]+seed),(opp+8+a,C,off+b)));terms.append((constant(JL[a][b]-seed),(opp+8+a,C,off+2+b)));terms.append((CI*q*(RB[a][b]-seed),(opp+8+a,rho,off+b)));terms.append((constant(RL[a][b]+seed),(opp+8+a,rho,off+2+b)))
    terms.append((half*(1+a+b+seed),(rho,J,opp+a,off+b)));terms.append((constant(1+a-b+seed),(n,x,opp+8+a,off+6+b)));terms.append((constant(2-a+b+seed),(J,C,opp+8+a,off+6+b)))
    for sector,mat in enumerate(MC):add(roots['MC'],off+2*sector+a,off+2*sector+b,9,constant(mat[a][b]+seed))
    add(roots['MX'],off+4+a,off+6+b,33,constant(MX[a][b]+seed));add(roots['MR'],off+2+a,off+b,3,CI*q*(MRB[a][b]+seed));add(roots['MR'],off+2+a,off+2+b,3,constant(MRL[a][b]));add(roots['MR'],off+8+a,off+8+b,3,constant(MRA[a][b]));add(roots['higher'],off+2+a,off+8+b,11,constant(1));add(roots['higher'],off+2+a,off+4+b,19,CI)
 Q={}
 for mode,q in [(0,1),(1,-1)]:
  off=mode*per
  for a in range(2):Q[off+a]=(CI*q,(off+6+a,));Q[off+8+a]=(CI,(off+2+a,))
 varied=defaultdict(lambda:0)
 for v,w in free:
  for at,i in enumerate(w):
   if i in Q:
    c,ww=Q[i];www,sg=canon(w[:at]+ww+w[at+1:]);varied[www]+=(-1)**sum(par(k)for k in w[:at])*sg*v*c
 assert not tidy(varied)
 H0=hessian(free);V=hessian(terms);G=invert_body(H0);assert mm(H0,G)=={(i,i):{0:constant(1)}for i in range(dim)}
 return G,V,roots
