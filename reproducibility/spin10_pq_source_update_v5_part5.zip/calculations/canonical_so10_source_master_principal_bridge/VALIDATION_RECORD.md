# SMP2: exact comparison and free-reference normalization

Prospective after completed SMP1 primary/replay. Compare actual qG and QG
at every four-momentum coefficient in the complete opposite-mode quadratic
domain,including source degrees0/1/2. Counts alone do not establish equality.
Derive the zero-completed domain by field/source dimension,ghost number,
parity and momentum degree,not a list of previously observed terms.

Authenticate the new free reference independently against the actual EDS
K0/G0 and its two inverse orders. Extract the new free action's complete
longitudinal matrix at p=e3 and compare all90x90 positions;check scalar and
ghost inverse normalization too. This is an external reference check of
the literal free action,not a fit to the new QG result. The qualified EDS
full-symbol/Lorentz proof supplies the transverse normal form;the full
symbolic p polynomial in SMP1 is not replaced by axis samples.

Confirm the ACTUAL G has no principal degree0/1 terms that could invalidate
the combined-degree argument. The complete free source operation must
obey its nilpotence checks. Source Euler and orientation/phase controls
must be sensitive in both actual probes. No quantum cutoff/remainder is
read. Compare the actual principal ordinary QG with the old EDS U only
afterward as a dependency check,not an input that determines the answer.

Bind sources,copies,inputs and completed captures before review.180s,
8GiB sampled,350MiB launch floor,32MiB packet. A discrepancy preserves
all completed outputs and receives no qualification receipt. Do not change
source phases or free inputs to obtain agreement. This is not full nonlinear
Slavnov,quantum restoration,QAP,measure or physical source-reality authority.
