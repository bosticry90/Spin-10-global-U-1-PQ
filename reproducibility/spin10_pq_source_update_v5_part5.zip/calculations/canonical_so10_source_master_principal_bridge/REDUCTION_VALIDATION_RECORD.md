# SMP4: actual support,free-tangent premises and model normalization

Prospective after SMP3 V2 completes. Authenticate its six literal Gaussian
fixtures,the original failed source/capture and the strengthened controls.
Prove the finite-operator lemma in PROOF.md using actual free invariance
and the qualified Gaussian pairing identity. Independently check the actual
RSH target grading and all rooted port paths against the72-word reduction.
No n5 word may be discarded until its root is identified as the complete
free tangent. Check the actual scalar R antisymmetry premise separately.

Add a two-scalar antisymmetric rotation to the noncommuting fixtures and
test its complete trace zero. A partial rotation must be sensitive where
available. Compare the72-word formula to the previously qualified selected
RSH coefficient only AFTER operator/coverage checks. This is an actual
normalization control,not a fresh full model tensor or an inferred cancelling
coefficient. No old IAG F5 or desired Ward image is a reduction input.

All sources,helpers,preparations and completed/failed observations are bound
before review. Review180s,8GiB sampled,350MiB floor,32MiB packet. Keep the
operator/typed reduction separate from coefficient measurement and full
continuum/master/source-product interpretation. No promotion or scheme change.
