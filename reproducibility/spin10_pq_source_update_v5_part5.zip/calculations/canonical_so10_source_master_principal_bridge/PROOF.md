# Conditional finite-operator reduction for the full formal log5 tensor

This proof concerns the fixed A0 principal symbol and finite graded Gaussian
coefficients. It does not assert cyclicity of an arbitrary continuum finite
part,or construct coincident quantum source products.

Let M_f be the epsilon-left constant free field tangent. SMP1 verifies
invariance of the actual free action,so

    M_f sharp H0+H0 M_f=0.

At A0 the specified common heat E=exp(-2t p^2) is central and commutes
with this constant-coefficient tangent. Thus for Rt=(E^-1-1)H0,

    M_f sharp Rt+Rt M_f=0.

The finite Gaussian pairing identity equates
STr(Gt M_f sharp Rt) and STr(Gt Rt M_f),including odd coefficients and
momentum adjoints. Their sum is zero,hence STr(Gt Rt M_f)=0. Expand in
an independent commuting formal amplitude multiplying V. At each degree
n,for positive heat and nonzero momentum,E^n(1-E) is nonzero. Consequently

    STr((G0 V)^n M_f)=0

coefficientwise. No inverse physical coupling or finite normalization is
used. The statement is for the COMPLETE free tangent;its B<-C and a<-
Lambda summands are not separately zero in general. Literal two-mode
fixtures test both mixed odd coefficients and sensitive omissions.

Exactly the same argument applies to a scalar-only linear tangent with
antisymmetric matrix R_h,since the scalar reference metric is identity.
The actual45 R_h were reconstructed and checked in USR3;this premise is
authenticated here. The scalar rotation contribution to M_C can therefore
be removed as a complete operator group,not because one sampled term is zero.

Now project the actual RSH cutoff family to target positive grades
(intrinsic,rho,J,C,x)=(1,1,1,1,1). Each non-reference V consumes positive
grade. Its n5 words have exactly M_f roots,so their complete sum C5=0
for every source,ghost and scalar index in this retained symbol domain.
At n4,free roots again give zero. All surviving roots have a single
positive grade: M_C,M_x or M_rho0. Every V must then have a single grade.
All higher-grade vertices and roots are excluded by this grading alone.

Write X_a=G0 V_a with a in {n,rho,J,C,x},including its external graded
coefficient. The complete coefficient of formal log5 is

    [epsilon n rho J C x] {
        sum_(permutations n,rho,J,x) STr(X_n X_rho X_J X_x M_C)
      + sum_(permutations n,rho,J,C) STr(X_n X_rho X_J X_C M_x)
      + sum_(permutations n,J,C,x)   STr(X_n X_J X_C X_x M_rho0)
    }.

The displayed products stand for all24 permutations in each line. Matrix
order and odd external order are retained. This is72 formal operator words,
not72 independent diagrams. The paired-q average and common hbar/(16pi^2)
normalization are unchanged. The generic C5 term was retained until its
complete free-root cancellation was established.

In the actual RSH port inventory,each probe has82 non-free quartic typed
paths before scalar-root reduction. Six belong to the separately zero
scalar rotation group. The remaining76 raw port paths lie inside the
72 supermatrix words because each supermatrix sums several actual port/
derivative structures. These counts measure different representations.
Coverage is checked on the actual paths;zero formal words need not be
assigned amplitudes.

This supplies a compact full-color operator whose coefficients can be
contracted with actual beta,J0,Jrho,N0,R and tangent matrices. It does
not supply the unmeasured full coefficient tensor or qualify the entire
augmented-source quantum Ward construction. The independently measured
selected witness remains a normalization control,not a fitted operand.
