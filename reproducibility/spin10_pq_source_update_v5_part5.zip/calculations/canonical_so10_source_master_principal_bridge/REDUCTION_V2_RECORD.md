# SMP3 V2: preserve zero fixtures and add noncommuting-color controls

The original reduction native exited1 at its last control-coverage assertion.
All four literal-Gaussian free-root identities and72-word comparisons had
passed,but fixtures2/3 have zero target and all three root omissions were
insensitive. The one-ghost-color MX omission is insensitive in all four.
No original execution/qualification receipt exists. Preserve the original
source,preparation,complete stdout/capture and failed controller.

V2 keeps those exact four fixtures and explicitly requires the observed
zero cases to remain zero. It adds two genuinely two-color noncommuting
Gaussian fixtures,with two scalars and two ghost pairs per momentum mode.
All three quartic root contributions must be nonzero there,so each root
omission is tested sensitively. The original insensitive controls remain
reported as such. This adds a stronger adversarial check rather than
pretending the old branch agreement checked an omitted root.

Finite operator/proof,physical inputs,normalizations and bounds are unchanged.
These are algebra fixtures,not a changed model or a quantum coefficient
chosen to cancel an old remainder. Source files and outputs receive V2
names;no original evidence is edited or relabeled PASS.
