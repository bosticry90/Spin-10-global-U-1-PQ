# Principal source/master bridge and compact cutoff operator

PROGRESS, bounded mathematical qualification. Goal ACTIVE/INCOMPLETE.
Base c9fce1ee8a83639dd3195aca0f79cd8a70c4c134, handoff V632.
No scientific-authority promotion, new physical benchmark, scheme adoption,
normalization choice or change of action. State113, authority34/39, E5/A5
OPEN; historical custody exit2/seven NOTPASS remain unchanged.

## What is established

The actual principal quadratic first-probe source/master relation passes
for both probes. Independently extracting the stored QG agrees with q0G
reconstructed from the actual G and the free action, retaining all source
Euler terms before restriction. The free operation is nilpotent on the
fields and their dual sources. All four momentum components are symbolic;
this is not agreement at selected momentum axes.

| Probe | Ordinary positions | One-source | Two-source | Total nonzero |
| --- | ---: | ---: | ---: | ---: |
| 0 | 300 | 120 | 12 | 432 |
| 1 | 825 | 330 | 33 | 1188 |

The typed comparison domain has 3,218,380 positions per probe: 2,806,045
ordinary, 410,310 one-source and 2,025 two-source momentum/field positions.
It includes the implicit zero complement. These are coefficient slots,
not independent physical tests. Omission of source Euler terms changes
624/1716 positions; wrong auxiliary-source Wick phase changes432/1188;
wrong first momentum orientation changes576/1584. All are sensitive.

The separately qualified EDS longitudinal K0/G0 satisfy both inverse
orders and agree with the newly constructed free action at every90x90
position. The328 scalar and45 ghost metrics are checked. A late comparison
with old U agrees48/132 longitudinal positions; U was not a native operand.

This establishes a prerequisite for the cutoff analysis, rather than
assuming an elementary operation with qJ=0. It does not establish the
full nonlinear or intrinsic-degree-one augmented master identity.

## The complete free-root group vanishes in the retained symbol

At fixed A0 the specified common heat factor E is central. The complete
free field tangent preserves H0, and hence Rt=(E^-1-1)H0. Finite graded
Gaussian transposition then gives STr(Gt Rt M_free)=0. Expanding in an
independent formal interaction amplitude proves the vanishing at every
V degree. This uses the complete tangent, including both B<-C and
a<-Lambda endpoints; neither endpoint can be discarded separately.

All actual fifth-degree RSH words have this free root. Their complete
coefficient C5 therefore vanishes for the full retained color tensor.
This is a new operator argument; V632's selected C5=0 alone did not
justify a global omission. All45 scalar rotation matrices are also
antisymmetric (12,560 nonzero entries authenticated), so the scalar-only
M_C rotation group vanishes by the same argument with the identity scalar
reference metric. See PROOF.md for hypotheses and the ordered formula.

The full formal log5 coefficient is consequently C4, represented by72
ordered trace words:24 each with roots M_C, M_x and M_rho0. Every actual
non-free quartic port path maps into this expression. Per probe there
are82 such raw paths, six in the zero scalar-rotation group, leaving76.
Port paths and supermatrix words are different representations and need
not have equal counts. Higher-grade roots are excluded by positive
target grading, not assumed numerically small.

The reduced operator, evaluated using actual classical matrices at the
previous selected witness (source13, ghost0, scalar137), gives

    probe0: 0
    probe1: i sqrt(6) eta_H g10^4 xi /16

in the existing common hbar/(16pi^2) units, in both momentum orientations.
Only afterward is it compared with the measured V4 cutoff coefficient.
No old IAG F5 or desired Ward remainder is used to define this operator.
This comparison is a normalization control, not a measurement of the
full tensor and not a new full Ward cancellation.

## Verification and preserved failure

SMP1 uses literal odd Leibniz variation of G versus independently supplied
QG with Fourier/Wick transport. The primary is denied QG and the old
quantum cutoff outputs; the replay receives QG without G. Review checks
the reference normalization, typing, implicit zeros and sensitive controls.

The first SMP3 native FAILED at a control-coverage assertion. Its four
Gaussian identities and ordered comparisons passed, but two original
fixtures have zero target, and the M_x omission is insensitive in all
four one-color fixtures. There is no original successful execution
receipt. Original source, preparation, full output and controller failure
are retained unchanged. V2 retains all four fixtures, including their
zeros, and adds two noncommuting two-color/two-scalar Gaussian fixtures.
All three root omissions are sensitive in both added fixtures. Full free
root vanishing is checked at degrees1..5; ordinary-trace and partial-root
controls detect errors. The two new direct C4 values are6272+1980i and
37392-4632i, with C5=0. These algebra fixtures are not physical parameters.

Independent review authenticates the72-term comparisons, checks the
actual rooted support reduction and all45 scalar rotations, and verifies
the selected normalization against the authenticated V4 result. Partial
scalar-rotation controls are sensitive at degrees2..4, not at1 or5;
their insensitivity is retained, not reported as detection.

Native/reviewer times after imports: primary9.7447s, replay1.0966s,
principal review15.5698s, V2 reduction1.5342s, reduction review5.1705s.
Every native has a full capture and sampled private-memory observations.
Limits remain300s native/180s review,8GiB sampled private memory,
350MiB available-pagefile launch floor and32MiB retained packet.
Sampled observations are not a continuously measured memory peak.

## Reference and interpretation

The supplied assessment describes the earlier ce3e35d8 checkpoint. Its
36,222-byte attachment a3020d5d-8adf-434c-b027-547c26d2f0ba has SHA256
8e0ef34707413fc44e2c9a5c284ecf2ea7f0a1bc105b945c9ef7690afdfd5c77.
Its complete text was read, including the finite-logarithm argument. Its
proposal to derive the actual regulator/source contribution independently,
retain normalization freedom and compare late is adopted as research
guidance. It is reference material, not evidence qualification. Its
reported operational pause is historical: the current human continuation
and fresh goal observation are ACTIVE. No external claims in the supplied
assessment were newly validated here. The subsequent V632 selected
cutoff computation and the present reduction are distinct newer evidence.

The epistemic position is verification within scope, analytic compression,
no proof-assistant formalization and no new empirical connection. Methods
share action definitions, source conventions, charts, coefficient software,
Python/SymPy and AI authorship. Agreement cannot validate those shared
premises. The principal bridge and adversarial noncommuting fixtures
address concrete failure modes, not independent scientific validation.

## Limits and next calculation

Same original unshifted SMA/CSW/EDS, A0, constant first probes, symbolic
g10/xi/eta_H; the cutoff projection has intrinsic degree1 and external
jets0. It is a nonexceptional Euclidean local RELATIVE comparison, not
physical scaleless p0, a massive/causal vacuum or absolute products.
chi4, b0, kappa and infrared freedom remain distinct and unfixed.

The full color coefficient tensor is UNMEASURED. The next competent test
is its exact contraction from the72-word operator, before reading IAG N5.
Exploit the single contracted scalar segment, using sparse N0 R_b
products, rather than repeat a508-coordinate calculation664,200 times.
Derive all source/ghost directions and constant probe tangents from the
actual maps; preserve ordered color products and both q orientations.
Use a different reassociation or path contraction as replay, sensitive
root/source/momentum controls, and compare the earlier tensor only late.
If contraction exceeds a frozen bound, retain it as incomplete.

Even full log5 agreement would not close other logarithmic carriers,
the remaining ordinary source roots, all u contacts, T/F, general BBx,
renormalized connected products, full chiral QAP/measure/global phase,
source reality, massive/causal limits or physical viability. No continuum
trace theorem follows from this finite Gaussian argument. No protected
flavor/HB1/C5 stage was activated. No normalization or unknown quantum
input was fitted. project_state.json remains the sole authority.

Reproduction is through the frozen commands in run.py, run_validation.py,
run_reduction.py (expected failure), run_reduction_v2.py and
run_reduction_validation.py, using their separate source copies and
preparation bindings. They use exclusive output creation; replay in a
separate evidence destination rather than overwriting this packet.
