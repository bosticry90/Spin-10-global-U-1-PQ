from pathlib import Path
from hashlib import sha256
from collections import Counter
from itertools import permutations
from functools import lru_cache
import ast,json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'reduction_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
z=read(O/'reduction_tables_v2.json');assert len(z['results'])==6 and len(z['operator_terms'])==72
for q in z['results']:assert q['free_root_zero_at_all_five_V_degrees']and q['direct_C5']=='0'and q['direct_C4']==q['seventy_two_word_log5']
assert all(all(q['root_omission_controls'].values())for q in z['results'][4:]);assert all(not any(q['root_omission_controls'].values())for q in z['results'][2:4]);assert not(O/'reduction_execution_receipt.json').exists();assert read(O/'reduction_capture.json')['exit_code']==1
ip=read(O/'reduction_validation_inputs.json');rsh=load(Path(ip['RSH_support']));formal={(q['root'],tuple(q['ordered_single_grades']))for q in z['operator_terms']};labels=['n','rho','J','C','x'];rootlabels={(0,0,0,1,0):'M_C',(0,0,0,0,1):'M_x',(0,1,0,0,0):'M_rho0'};counts=[]
for pr in rsh['results']:
 cc=Counter()
 for w in pr['words']:
  n=len(w['V_word']);root=rsh['M_roots'][w['root_M']];grade=tuple(root['grade'])
  if n==5:
   assert sum(grade)==0 and root['origin']=='M0'and root['ports']in[['B','C'],['a','L']];cc['five_V_complete_free_root_words']+=1
  if n!=4:continue
  if sum(grade)==0:
   assert root['origin']=='M0'and root['ports']in[['B','C'],['a','L']];cc['quartic_complete_free_root_words']+=1;continue
  assert grade in rootlabels;ww=[]
  for vid in w['V_word']:
   v=rsh['V_letters'][vid];assert sum(v['grade'])==1;ww.append(labels[v['grade'].index(1)])
  name=rootlabels[grade];assert(name,tuple(ww))in formal;cc[name]+=1
  if root['ports']==['x','x']:assert name=='M_C';cc['scalar_rotation_words']+=1
 assert cc['five_V_complete_free_root_words']==48 and cc['M_C']==24 and cc['M_x']==4 and cc['M_rho0']==54 and cc['scalar_rotation_words']==6;counts.append({'probe':pr['probe'],**dict(cc),'nonfree_quartic_after_scalar_group':cc['M_C']+cc['M_x']+cc['M_rho0']-cc['scalar_rotation_words']})
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def val(v):return s.expand(s.sympify(v,locals=loc))
rr=load(Path(ip['scalar_operands']))['R'];antisym=0
for M in rr:
 d={(i,j):val(v)for i,j,v in M['entries']}
 for(i,j),v in d.items():assert s.expand(v+d.get((j,i),0))==0;antisym+=1
# Reuse the frozen fixture definitions,not their output loop.
p=O/'reduction_v2.py';src=p.read_text();tree=ast.parse(src);cut=next(n.lineno for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='results'for t in n.targets));ns={'__file__':str(p),'__name__':'SMP4_GENERIC_REVIEW'};exec(compile('\n'.join(src.splitlines()[:cut-1]),str(p),'exec'),ns);ns['timer'].cancel();ns.update(dim=20,per=10,nb=6);partial_controls=[]
for seed in [0,1]:
 G,V,roots=ns['multicolor'](seed);X=ns['mm'](G,V);M={};partial={}
 for mode in range(2):
  off=mode*10;ns['add'](M,off+4,off+5,9,ns['constant'](2));ns['add'](M,off+5,off+4,9,ns['constant'](-2));ns['add'](partial,off+4,off+5,9,ns['constant'](2))
 power={(i,i):{0:ns['constant'](1)}for i in range(20)};controls=[]
 for n in range(1,6):power=ns['mm'](power,X);assert not ns['tr'](ns['mm'](power,M));controls.append(bool(ns['tr'](ns['mm'](power,partial))))
 assert any(controls);partial_controls.append(controls)
# Actual-model normalization uses CLASSICAL blocks only until comparison.
p=Path(ip['RSH_kernel_source']);src=p.read_text();tree=ast.parse(src);cut=next(n.lineno for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='results'for t in n.targets));model={'__file__':str(p),'__name__':'SMP4_SELECTED_MODEL_REDUCTION'};oldargs=sys.argv;sys.argv=[str(p),'primary'];helper='\n'.join(src.splitlines()[:cut-1]).replace('sys.addaudithook(guard)','assert True # frozen reviewer permits authenticated late model comparator');exec(compile(helper,str(p),'exec'),model);sys.argv=oldargs;model['timer'].cancel();ns.update(dim=508,per=508,nb=418);selected=[]
for probe in range(2):
 qq=[]
 for q in [1,-1]:
  G,V,roots=model['pieces'](probe,q);single={mask:ns['mm'](G,{ij:{mask:p0[mask]}for ij,p0 in V.items()if mask in p0})for mask in [2,4,8,16,32]};rootset={'M_C':roots['M0_diagonal_C'],'M_x':roots['M0_xC'],'M_rho0':{ij:{3:p0[3]}for ij,p0 in roots['Mrho'].items()if 3 in p0}};out=ns['constant'](0)
  for name,seq in [('M_C',[16,2,4,32]),('M_x',[16,2,4,8]),('M_rho0',[16,4,8,32])]:
   for ww in permutations(seq):
    prod={(i,i):{0:ns['constant'](1)}for i in range(508)}
    for mask in ww:prod=ns['mm'](prod,single[mask])
    out+=ns['tr'](ns['mm'](prod,rootset[name])).get(63,0)
  qq.append(out)
 assert qq[0]==qq[1];selected.append(model['co']('1/2')*(qq[0]+qq[1]))
old=load(Path(ip['RSH_selected_output']))
for probe,v in enumerate(selected):assert v==model['co'](old['results'][probe]['cutoff_pair_coefficients']['4'])and old['results'][probe]['cutoff_pair_coefficients']['5']=='0'
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'finite_free_tangent_annihilation_and_degree_reduction_qualified':True,'actual_RSH_rooted_support_reduction':counts,'all45_scalar_rotations_antisymmetry_positions':antisym,'two_scalar_rotation_trace_zero_and_sensitive_partial_controls':partial_controls,'six_generic_fixture_reductions_authenticated':True,'all_three_roots_sensitively_tested_in_noncommuting_fixtures':True,'ordered_quartic_operator_words':72,'selected_actual_model_reduction_coefficients':[str(v)for v in selected],'full_color_tensor_measured':False,'complete_source_Ward_QAP_or_E5_promotion':False},sort_keys=True),flush=True);timer.cancel()
