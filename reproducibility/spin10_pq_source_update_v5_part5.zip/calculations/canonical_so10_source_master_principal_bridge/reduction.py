from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
from itertools import permutations
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'reduction_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
sys.path.insert(0,str(Path(read(O/'ring_inputs.json')['coefficient_ring']).parent));from coefficient_ring import coefficient,constant,I as CI
co=lambda z:coefficient(s.expand(s.sympify(z)));dim=10;per=5;target=63
def par(i):return int(i%per>=3)if i<dim else int(i-dim<4)
def tidy(A):return{k:v for k,v in A.items()if v!=0}
def addpoly(A,B):
 z=dict(A)
 for k,v in B.items():z[k]=z.get(k,0)+v
 return tidy(z)
def mulpoly(A,B):
 z=defaultdict(lambda:0)
 for a,v in A.items():
  for b,w in B.items():
   if not a&b:z[a|b]+=(-1)**sum((b&((1<<i)-1)).bit_count()for i in range(4)if a&(1<<i))*v*w
 return tidy(z)
def mm(A,B):
 by=defaultdict(list);out={}
 for(i,j),v in B.items():by[i].append((j,v))
 for(i,k),v in A.items():
  for j,w in by[k]:
   z=mulpoly(v,w)
   if z:out[i,j]=addpoly(out.get((i,j),{}),z)
 return {k:v for k,v in out.items()if v}
def tr(A,ordinary=False):return tidy(sum_polys([({m:(1 if ordinary else(-1)**par(i))*v for m,v in z.items()})for(i,j),z in A.items()if i==j]))
def sum_polys(aa):
 out={}
 for z in aa:out=addpoly(out,z)
 return out
def madd(*aa):
 out={}
 for A in aa:
  for k,v in A.items():out[k]=addpoly(out.get(k,{}),v)
 return {k:v for k,v in out.items()if v}
def add(A,i,j,m,v):
 if v:A[i,j]=addpoly(A.get((i,j),{}),{m:v})
def canon(word):
 odds=[i for i in word if par(i)]
 if len(set(odds))!=len(odds):return (),0
 return tuple(sorted(word)),(-1)**sum(par(a)*par(b)*(a>b)for j,a in enumerate(word)for b in word[j+1:])
def der(word,i):
 for at,v in enumerate(word):
  if v==i:yield word[:at]+word[at+1:],(-1)**(par(i)*sum(par(j)for j in word[:at]))
def hessian(terms):
 out={}
 for v,w in terms:
  for i in set(j for j in w if j<dim):
   for ww,sg in der(w,i):
    for j in set(k for k in ww if k<dim):
     for www,tg in der(ww,j):
      assert all(k>=dim for k in www);ww2,phase=canon(www)
      if phase:
       mask=sum(1<<(k-dim)for k in ww2);add(out,i,j,mask,phase*sg*tg*(-1)**(par(j)*(par(i)+1))*v)
 return out
def invert_body(A):
 z=s.Matrix(dim,dim,lambda i,j:s.expand(s.sympify(str(A.get((i,j),{}).get(0,0)))));inv=z.inv();return {(i,j):{0:co(v)}for i in range(dim)for j in range(dim)if(v:=inv[i,j])!=0}
def fixture(seed):
 free=[];terms=[];n,x,J,C,rho=[dim+k for k in [4,5,2,3,1]];roots={k:{}for k in ['BC','aL','MC','MX','MR','higher']}
 for mode,q in [(0,1),(1,-1)]:
  off=mode*per;opp=(1-mode)*per;K=[[0,q,0],[-q,3+seed,0],[0,0,1]];N=[[0,0,1+seed],[0,0,2-seed],[1+seed,2-seed,0]];X=[[0,0,-s.I*q*(2+seed)],[0,0,0],[s.I*q*(2+seed),0,0]]
  for i in range(3):
   for j in range(3):
    if K[i][j]:free.append((co(K[i][j])*co('1/2'),(opp+i,off+j)))
    if N[i][j]:terms.append((co(N[i][j])*co('1/2'),(n,opp+i,off+j)))
    if X[i][j]:terms.append((co(X[i][j])*co('1/2'),(x,opp+i,off+j)))
  free.append((constant(1),(opp+4,off+3)))
  for b,w in [(0,2+seed),(1,3-seed)]:terms.append((constant(w),(J,off+3,opp+b)))
  for theta,jb,jl in [(C,2+seed,1-seed),(rho,3-seed,2+seed)]:
   terms.append((CI*q*jb,(opp+4,theta,off)));terms.append((constant(jl),(opp+4,theta,off+1)))
  terms.append((co('1/2')*(1+seed),(rho,J,opp,off)));terms.append((constant(1-seed),(n,x,opp+4,off+3)));terms.append((constant(2+seed),(J,C,opp+4,off+3)))
  add(roots['BC'],off,off+3,1,CI*q);add(roots['aL'],off+4,off+1,1,CI)
  for i,w in enumerate([2,-1,3,4,-2]):add(roots['MC'],off+i,off+i,9,constant(w+seed))
  add(roots['MX'],off+2,off+3,33,constant(2+seed));add(roots['MR'],off+1,off,3,CI*q*(1+seed));add(roots['MR'],off+1,off+1,3,constant(2));add(roots['MR'],off+4,off+4,3,constant(-1-seed));add(roots['higher'],off+1,off+4,11,constant(1));add(roots['higher'],off+1,off+2,19,CI)
 # Literal odd variation of the free action,without relying on an operator transpose.
 Q={}
 for mode,q in [(0,1),(1,-1)]:
  off=mode*per;Q[off]=(CI*q,(off+3,));Q[off+4]=(CI,(off+1,))
 varied=defaultdict(lambda:0)
 for v,w in free:
  for at,i in enumerate(w):
   if i in Q:
    c,ww=Q[i];www,sg=canon(w[:at]+ww+w[at+1:]);varied[www]+=(-1)**sum(par(k)for k in w[:at])*sg*v*c
 assert not tidy(varied)
 H0=hessian(free);V=hessian(terms);G=invert_body(H0);assert mm(H0,G)=={(i,i):{0:constant(1)}for i in range(dim)}
 return G,V,roots
results=[]
for seed in range(4):
 G,V,roots=fixture(seed);X=mm(G,V);Mf=madd(roots['BC'],roots['aL']);M=madd(*roots.values());power={(i,i):{0:constant(1)}for i in range(dim)};pairs={};partial=[];wrongtrace=[]
 for n in range(1,6):
  power=mm(power,X);z=tr(mm(power,Mf));assert not z,('free_root_not_zero',seed,n,{m:str(v)for m,v in z.items()});pairs[n]=(-1)**n*tr(mm(power,M)).get(target,0);partial.append(bool(tr(mm(power,roots['BC']))));wrongtrace.append(bool(tr(mm(power,Mf),True)))
 assert not mm(power,X),'positive_grade_bound_failed'
 sing={m:mm(G,{ij:{m:p[m]}for ij,p in V.items()if m in p})for m in [2,4,8,16,32]}
 reduced=constant(0);by={}
 for name,labels in [('MC',[16,2,4,32]),('MX',[16,2,4,8]),('MR',[16,4,8,32])]:
  out=constant(0)
  for ww in permutations(labels):
   prod={(i,i):{0:constant(1)}for i in range(dim)}
   for label in ww:prod=mm(prod,sing[label])
   out+=tr(mm(prod,roots[name])).get(target,0)
  by[name]=out;reduced+=out
 assert pairs[5]==0 and pairs[4]-pairs[5]==reduced,('quartic_reduction_failed',seed,str(pairs[4]),str(pairs[5]),str(reduced))
 changed={k:bool(v)for k,v in by.items()};results.append({'fixture':seed,'free_root_zero_at_all_five_V_degrees':True,'partial_BC_omission_sensitive_by_degree':partial,'ordinary_trace_sensitive_by_degree':wrongtrace,'direct_C4':str(pairs[4]),'direct_C5':str(pairs[5]),'seventy_two_word_log5':str(reduced),'root_groups':{k:str(v)for k,v in by.items()},'root_omission_controls':changed});print('STAGE SMP3',json.dumps(results[-1],sort_keys=True),flush=True)
assert any(any(z['partial_BC_omission_sensitive_by_degree'])for z in results)
assert any(any(z['ordinary_trace_sensitive_by_degree'])for z in results)
assert all(any(z['root_omission_controls'].values())for z in results)
out={'schema':'SMP3_FREE_TANGENT_ANNIHILATION_AND_FULL_COLOR_QUARTIC_OPERATOR','results':results,'actual_full_model_color_tensor_measured':False,'operator_terms':[{'root':root,'ordered_single_grades':list(p)}for root,labels in [('M_C',['n','rho','J','x']),('M_x',['n','rho','J','C']),('M_rho0',['n','J','C','x'])]for p in permutations(labels)],'finite_gaussian_and_local_symbol_only':True,'continuum_source_products_or_full_QAP_not_inferred':True};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode()
with(O/'reduction_tables.json').open('xb')as f:f.write(raw)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'tables_sha256':sha256(raw).hexdigest(),'four_literal_gaussian_fixtures_and_full_free_root_zero_pass':True,'complete_ordered_quartic_terms':len(out['operator_terms']),'generic_full_color_operator_not_measured_tensor':True},sort_keys=True),flush=True);timer.cancel()
