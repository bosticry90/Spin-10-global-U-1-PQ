# SMP1+: augmented-source principal quadratic bridge

Prospective at c9fce1ee8a83639dd3195aca0f79cd8a70c4c134,V632. Previous
goal turn PROGRESS. Fresh preflight clean main,no matching workers,goal
ACTIVE. State113,authority34/39,E5/A5 OPEN,custodyexit2/seven NOTPASS.
Live AGENTS,charter,solo review and epistemic boundaries apply. No agents,
branch/worktree,remote action,publication,outreach,foundation/scheme/benchmark
adoption,flavor/HB1/C5 activation,protected promotion or state edit.

Question: does the actual first-probe principal quadratic QG agree with
the source/master operation on the actual G and free action? This is a
necessary applicability premise for extending the selected cutoff result
to a full operator. It is not another desired quantum cancellation.

Original unshifted canonical SMA/CSW/EDS,A0,first probes0/1,principal
intrinsicdegree0,source-free quadratic output. All643 bosonic/gauge/ghost
coordinates(including328 scalars),all four vector components,and their
actual dual source roles. Work with independent symbolic Euclidean p0..p3
and both paired momentum orientations;not axis interpolation. g10,xi,eta_H
remain symbolic. IntrinsicN0,physical masses and higher field degree are
excluded only by this exact grading,not set to zero in the theory.

Primary reconstructs q0 G from the free action and the full ACTUAL G
polynomial,including source degrees0/1/2 before any restriction. Replay
independently extracts the actual QG density and Wick/Fourier transports
it. Primary must not read QG,Ur,old quantum cutoff coefficients or desired
Ward remainder. Compare all coefficients and implicit zeros only afterward.

Free physical scalar/ghost metrics and the full vector reference normal
form are qualified EDS/USR reuse. Free K_BB=p^2 delta-p p,K_BL=+p,
K_LB=-p,K_LL=diag(eta_H on12,xi on33),ghost D=p^2. Bind actual K0/G0
and check the longitudinal inverse normalization rather than silently
select a convenient free reference. Scalar free kernel=p^2 identity.

Euclidean source action is sum(-1)^parity J R. Therefore qfield=R and
qJ=(-1)^parity leftEuler_field Sigma. In paired Fourier coordinates J_-q
is conjugate to field_q. Use qB_q=i p_q C_q,qa_q=i Lambda_q,other free
field rules zero. Source Euler derivatives are taken BEFORE J0. A pure
elementary qJ=0 operation is an omission control,not the intended theorem.
Full source-quadratic G terms must be retained;they cannot produce ordinary
quadratic output after one source-lowering derivative,but retain their
source-containing images as evidence of the projection.

Homogeneous degree proves only the FREE field/source operation contributes
to source-free quadratic qG:nonlinear field rules or interaction Euler
terms raise ordinary degree,and source-linear flows preserve a source.
Do not infer a full nonlinear augmented-master identity from this premise.
No direct principal fermion term is generated because G contains no matter
source or matter field;this excludes only the degree2 principal projection.

Primary literal graded Leibniz polynomial vs replay density/Fourier route.
Check free-action invariance and both Euclidean pairing/ghost signs.
Negative controls omit source Euler,reverse one momentum endpoint or
misorient source Wick phases where the actual coefficient is sensitive.
Keep exact polynomial coupling/momentum coefficients,not numerical samples.
Unexpected field/source/derivative support leaves completion unqualified.

If the premise passes,derive the next compact full-color cutoff expression
from the complete RSH family,retaining generic five-V terms and ordinary/
probe tangents. If it fails,preserve the exact difference before interpreting
it as an implementation or theoretical mismatch. No fitting of an unknown
quantum input. A qualified quadratic bridge is not full QAP,measure,source
reality,full chiral restoration or E5/A5.

Sequential native300/review180s afterimports,8GiB sampled private memory,
350MiB available-pagefile launch floor,32MiB packet. Freeze source,copies,
inputs and failure conditions before computation. Full captures/resources;
no silent limit expansion,truncation or altered acceptance requirements.
Reuse exact Fraction/multiquadratic ring as software,not independent physics.
Shared action,charts,data,conventions,runtime and AI author remain limits.
