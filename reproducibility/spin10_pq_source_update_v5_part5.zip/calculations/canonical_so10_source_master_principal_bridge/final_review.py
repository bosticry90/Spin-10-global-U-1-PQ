from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/source-master-principal-bridge-v1-2026-10-25');H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();bindings=copies=0;peak=0
for p in O.glob('*preparation*.json'):
 for f,h in read(p)['input_sha256'].items():assert H(Path(f))==h,(p,f);bindings+=1
for p in O.glob('*.source.txt'):assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes();copies+=1
caps={p.name:read(p)for p in O.glob('*capture.json')};assert set(caps)=={'primary_capture.json','replay_capture.json','verify_capture.json','reduction_capture.json','reduction_v2_capture.json','reduction_verify_capture.json'}
for n,z in caps.items():
 assert z['post_run_observations_qualified']and z['launch']['memory']['available_pagefile']>=350*1024**2;peak=max(peak,max(q['private_bytes']for q in z['all_resource_samples']));assert peak<=8*1024**3 and not z['failed_or_incomplete_counted_as_PASS']
 if n=='reduction_capture.json':assert z['exit_code']==1 and z['execution_state']=='FAILED'and not z['calculation_completed']
 else:assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']
assert read(O/'reduction_controller_failure.json')['execution_state']=='FAILED'and not(O/'reduction_execution_receipt.json').exists()and not(O/'reduction_tables.json').exists()
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta};val=lambda z:s.expand(s.sympify(z,locals=loc));tab=lambda z:{(tuple(w),tuple(p)):val(v)for w,p,v in z};a,b=[load(O/(role+'_tables.json.gz'))for role in ['primary','replay']];hist=[]
assert a['field_order']==b['field_order']and len(a['field_order'])==643
for aa,bb in zip(a['results'],b['results']):
 assert aa['probe']==bb['probe']and tab(aa['density'])==tab(bb['density'])and tab(aa['ordinary_density'])==tab(bb['ordinary_density']);assert all(aa['controls'].values());cc=Counter(sum(i>=1286 for i in w)for w,p,v in aa['density']);hist.append([aa['probe'],dict(cc)])
assert hist==[[0,{0:300,1:120,2:12}],[1,{0:825,1:330,2:33}]]
for role in ['primary','replay']:
 rr=read(O/(role+'_result.json'));raw=gzip.decompress((O/(role+'_tables.json.gz')).read_bytes());assert H(O/(role+'_tables.json.gz'))==rr['packed_sha256']and sha256(raw).hexdigest()==rr['raw_sha256']and rr['elapsed_after_imports']<300
v=read(O/'validation_receipt.json');assert v['actual_qG_vs_QG_all_four_momentum_and_source_coefficients_agree']and v['actual_K0_G0_two_inverse_orders_and_new_free_action_match']and v['free_field_and_source_nilpotence_rechecked']and not v['full_nonlinear_master_quantum_QAP_or_E5_promoted'];assert v['zero_completed_quadratic_positions_by_source_degree']=={'0':2806045,'1':410310,'2':2025}
rv=read(O/'reduction_execution_receipt_v2.json');rt=read(O/'reduction_tables_v2.json');assert rv['tables_sha256']==H(O/'reduction_tables_v2.json')and rv['elapsed_after_imports']<300 and len(rt['operator_terms'])==72 and len(rt['results'])==6
for z in rt['results']:assert z['direct_C4']==z['seventy_two_word_log5']and z['direct_C5']=='0'and z['free_root_zero_at_all_five_V_degrees']
assert all(all(z['root_omission_controls'].values())for z in rt['results'][4:]);assert all(z['direct_C4']=='0'and not any(z['root_omission_controls'].values())for z in rt['results'][2:4]);assert all(not z['root_omission_controls']['MX']for z in rt['results'][:4]);assert not rt['actual_full_model_color_tensor_measured']
rv=read(O/'reduction_validation_receipt.json');assert rv['finite_free_tangent_annihilation_and_degree_reduction_qualified']and rv['all45_scalar_rotations_antisymmetry_positions']==12560 and rv['ordered_quartic_operator_words']==72 and not rv['full_color_tensor_measured']and not rv['complete_source_Ward_QAP_or_E5_promotion'];assert list(map(val,rv['selected_actual_model_reduction_coefficients']))==[s.Integer(0),s.sqrt(6)*s.I*eta*g**4*xi/16]
for z in rv['actual_RSH_rooted_support_reduction']:assert z['five_V_complete_free_root_words']==48 and z['M_C']+z['M_x']+z['M_rho0']==82 and z['scalar_rotation_words']==6 and z['nonfree_quartic_after_scalar_group']==76
e=read(C/'e4_full_capture.json');ev=[json.loads(q)for q in e['stdout_and_stderr'].splitlines()];ex=[q['exit_code']for q in ev if q['event']=='step_finished'];assert e['native_exit']==0 and ex==[0,0,0,0,0,2]and ev[-1]['execution_state']=='COMPLETED';assert H(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
report=(O/'RESULT.md').read_text()
assert all(z in report for z in ['ACTIVE/INCOMPLETE','UNMEASURED','not a new full Ward cancellation','No continuum','No normalization or unknown quantum'])
assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'preparation_bindings_authenticated':bindings,'frozen_source_copies_equal':copies,'pre_review_native_captures':len(caps),'largest_pre_review_private_sample':peak,'principal_source_degree_histograms':hist,'full_four_momentum_source_comparison_and_zero_domain_authenticated':True,'free_root_and_scalar_rotation_reduction_authenticated':True,'seventy_two_ordered_words_and_selected_normalization_qualified':True,'original_failed_control_coverage_preserved_with_insensitivities':True,'E4_native_exit':e['native_exit'],'E4_step_exits':ex,'custody':'EXIT2_SEVEN_NOTPASS','full_color_tensor_measured':False,'full_Ward_QAP_or_E5_promoted':False},sort_keys=True),flush=True);timer.cancel()
