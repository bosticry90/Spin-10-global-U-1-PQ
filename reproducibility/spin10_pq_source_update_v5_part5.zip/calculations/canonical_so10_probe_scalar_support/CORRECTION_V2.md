# RXS2 V2: reduce the rational BB contraction before equality

The original primary stopped at quantum.py's explicit six-component
GBB*k=Wk/K2 check. expand alone leaves an equivalent rational expression
over Q=sum k_i^2. Use cancel, which puts the exact rational expression over
a common denominator and reduces it; the operator identity and equality
requirement remain unchanged. This is a symbolic-comparison implementation
error, not a nonzero quantum coefficient or failed Ward test.

Original quantum.py, prepare/verify/controller, source copies, full primary
capture and quantum_controller_failure.json remain immutable. No original
primary table/result exists; replay and verifier were NOT_LAUNCHED. V2 changes
only this reduction and versioned filenames/manifest references. All eight
profiles, both chiralities, full maps, source-target exclusion, assumptions,
600s/8GiB sampled/350MiB floor/16MiB limits remain unchanged. Freeze original
failure and new exact source versions before sequential V2 workers/gate.

No new scheme/physical point, scientific promotion or evidence relabeling.
Whole investigation remains active/incomplete,State113/34of39 unchanged.
