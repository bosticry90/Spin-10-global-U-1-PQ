from pathlib import Path
from hashlib import sha256
from collections import Counter
import gzip,json,time,threading,os
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
tick=time.perf_counter();t=threading.Timer(120,lambda:os._exit(124));t.daemon=True;t.start()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
P=load(O/'primary_tables.json.gz');Z=load(O/'replay_tables.json.gz')
for k in ['profiles','G_vertices','targets','controls','G_inventory_reused']:assert P[k]==Z[k],k
summaries=[]
for r,tab in enumerate(P['targets']):
 units=Counter();placement=Counter()
 for w in tab['candidate']:
  seq,ex,es,ld,ej,g,y,md=json.loads(w);assert ld==ej==md==0
  units[g,y]+=1
  origins=[json.loads(k)[0] for k in seq]
  assert origins.count('rhoG'+str(r))==1 and sum(k.startswith('E_') for k in origins)==1
  placement[json.dumps(sorted(origins),separators=(',',':'))]+=1
 assert P['controls'][r]['omit_PS_SP']==len(tab['candidate'])
 assert P['controls'][r]['omit_Yukawa']==len(tab['candidate'])
 summaries.append({'classifications':{k:len(v) for k,v in tab.items()},'coupling_orders':[[*k,v] for k,v in sorted(units.items())],'origin_families':dict(sorted(placement.items()))})
print('RESULT '+json.dumps({'schema':'RHO_SCALAR_SUPPORT_VALIDATION_V1','elapsed_after_imports':time.perf_counter()-tick,'complete_independent_pairing_and_cycle_witness_sets_agree':True,'summaries':summaries,'controls':P['controls'],'new_quantum_coefficients_measured':False,'full_QAP_or_authority_changed':False},sort_keys=True),flush=True)
