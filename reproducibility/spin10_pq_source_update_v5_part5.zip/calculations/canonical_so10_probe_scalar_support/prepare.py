from pathlib import Path
from hashlib import sha256
import ast,gzip,json,subprocess
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='707c8566621e446499c940e536bbf22ab15c0b3e'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R).strip()
files=[R/n for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V595.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']]
for folder,receipt in [('canonical_so10_rho_vector_support','validation_receipt_v3.json'),('canonical_so10_matter_breaking_support','validation_receipt.json'),('canonical_so10_sterile_matter_action','validation_receipt.json')]:files.extend([O.parent/folder/receipt,O.parent/folder/'RESULT.md'])
assert H(O.parent/'canonical_so10_rho_vector_support/validation_receipt_v3.json')=='e32a3f35a56b5ca40586b0b12edbdc0dad44291b942501ca2f1f7beaa2f5b81d'
for role in ['primary','replay']:
 rg=O.parent/'canonical_so10_rho_vector_support';ib=O.parent/'canonical_so10_matter_breaking_support'
 p=rg/(role+'_v3_tables.json.gz');m=read(rg/'validation_preparation_v3.json');assert H(p)==m['input_sha256'][str(p)];files.extend([p,rg/'validation_preparation_v3.json']);g=load(p)
 p=ib/(role+'_tables.json.gz');m=read(ib/'validation_preparation_v2.json');assert H(p)==m['input_sha256'][str(p)];files.extend([p,ib/'validation_preparation_v2.json']);v=load(p)
 z={'names':g['names'],'marginal_G':g['complete_marginal_G'],'G_inventory':g['G_inventory'],'vertices':v['vertices'],'GF_positions':v['GF_positions'],'homogeneous_GF_components':v['homogeneous_GF_components'],'extraction':'QUALIFIED_CLASSICAL_MARGINAL_ACTION_ONLY_NO_QUANTUM_OR_COUNTERTERM_TARGET'}
 dst=O/(role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 files.append(dst)
for n in ['RECORD.md','prepare.py','native.py','verify.py','run.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 files.extend([p,O/(n+'.source.txt')])
b={str(p):H(p) for p in set(files)}
with(O/'preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'limits':{'seconds_after_imports':120,'sampled_private_bytes':8*1024**3,'launch_floor':350*1024**2,'packet_bytes':8*1024**2},'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,separators=(',',':'))+'\n').encode())
print('PREPARED_RXS1',len(b))
