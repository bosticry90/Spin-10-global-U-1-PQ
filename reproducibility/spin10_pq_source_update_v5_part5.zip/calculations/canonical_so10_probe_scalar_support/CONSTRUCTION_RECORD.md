# RXS3: post-measurement scalar primitive and its complete operator companion

RXS2 V3 primary/replay/separate gate completed0. Every7225344 retained
part/operator/holomorphic/anti map position agrees including zeros; all12
residual-H commutators,mass symmetry and conjugation pass. The actual rho
scalar quantum kernel is NONZERO. The fixed old candidate's ordinary
rho*x*PP zero-jet projection is0. Its insufficiency in this newly measured
sector is preserved; previous five selected matches are not retracted.

Freeze this post-result construction AFTER those quantum checks. Let
C_r=sum_(a in sector r) Tphysical_a^2 and J_r(M)=sum_a Ta.T M Ta. Test the
compact expression for the complete measured kernel, in common1/(16pi2)
units with outerg10^2:

 R_r(M)=w_r^2[J_r(M)/12+(C_r.T M+M C_r)/8].

Derive it from actual V=-wP/2,H=-w^2P/4 and the newly measured eight parts;
do not assign an unknown loop from this formula. Check full256x256 operator
equality for both labels first. Then construct the particular source-free
local mass-density correction with deltaM=-g10^2 sum_r u_r R_r(M(x)) and
its conjugate, using SMA's SAME alternating quadratic1/2 normalization.
Its d image supplies -g10^2 rho_r R_r. No old coefficient is changed.

The primitive is a construction from measured quantum input, not another
quantum calculation, a unique counterterm classification, an adopted
canonical action or physical finite scheme. Source-containing equivalent
directions and homogeneous freedom are not excluded. This term is
derivative-free,ghost0/dimension4,complex linear in M,polynomial in widths,
with no inverse physical parameter. It retains all328 scalar directions
and both symmetric family matrices. Symmetry/reality and residual-H
admissibility use qualified RXS2 checks plus full symmetric-subspace
operator tests. PQ charge is preserved by complex linearity, not a new
quantum PQ/measure statement.

For A_c(M)=i(Tc.T M+M Tc), retain the complete source-free u*C*scalar
counterterm image -g10^3 u_r C_c [A_c,R_r](M), with its conjugate. Calculate
ALL45 full mass operators per probe using the actual charge columns. Store
the exact K=-R program plus bound T inputs, and hashes/nonzero counts of
all45 descendants, rather than an enormous physical component expansion.
This is a complete reconstructable COUNTERTERM program; its quantum
counterpart is still UNKNOWN. No scalar/source/mass quantum coefficient
is inferred from the desired image. The old source/Euler companion must
be added exactly once in the later u*C*x*PP comparison.

The new term contains at least one scalar and no source,vector or jet.
Therefore its five previously tested scalar-zero marginal projections
vanish by monomial support. Positive-dimension vacuum/GF amplitudes,
external sterile/hatted fields, varying backgrounds and full finite/contact
products are not covered by this argument. Do not set them0 or transfer
the result to the physical constant-vacuum limit.

One bounded native construction check300s after imports,8GiB sampled,
350MiB launch floor,whole packet16MiB. Independent quantum routes/gate have
already finished; the rho cancellation is a constructed image, not a third
independent quantum verification. Freeze source/inputs first. Check a generic
odd-left derivative on u times an even alternating mass density with its1/2,
full compact-vs-measured operators, symmetric carrier, all45 descendants,
and sign/half/source-free-support controls. As an explicitly labelled
diagnostic compare the failed V2 total with V3: test whether equal widths
hide the wrong frame. These OLD V2 arrays remain unqualified physics.

Retain all failed sources/captures and every quantum V3 receipt unchanged.
All accepted foundations,physical schemes/benchmarks,State113/34of39,
flavor/HB1/C5 blocks, historical custody2/seven NOTPASS and old adverse
physical results remain unchanged. Shared action,analytic premises,software
and AI author limit independence. No agents,branch/worktree,push/outreach/
publication or E5/A5 promotion. Whole investigation remains incomplete.
