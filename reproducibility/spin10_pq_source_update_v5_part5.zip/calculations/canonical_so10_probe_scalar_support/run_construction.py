from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/probe-scalar-support-v1-2026-10-24')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
stage='construction_preparation'
try:
 b=dict(json.loads((O/'quantum_validation_preparation_v3.json').read_bytes())['input_sha256'])
 for p,h in b.items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
 for n in ['CONSTRUCTION_RECORD.md','construct.py','run_construction.py']:
  p=O/n
  if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
  with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 for p in O.iterdir():
  if p.is_file():b[str(p)]=sha256(p.read_bytes()).hexdigest()
 dump(O/'construction_preparation.json',{'input_sha256':b,'limits':{'seconds_after_imports':300,'sampled_private_bytes':8*1024**3,'launch_floor':350*1024**2,'packet_bytes':16*1024**2},'scientific_acceptance':'NOT_PERFORMED'})
 stage='construction';c=capture([sys.executable,'-B',str(O/'construct.py')]);dump(O/'construction_capture.json',c);dump(C/'construction_full_capture.json',c)
 # Full machine stdout is retained in both captures; avoid printing large
 # reconstructable operator programs into the terminal transcript.
 assert c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3
 rr=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<300
 dump(O/'construction_receipt.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<16*1024**2
 print('CONSTRUCTION_COMPLETE',rr[0]['elapsed_after_imports'],rr[0]['failed_V2_equal_width_diagnostic'],flush=True)
except BaseException:
 dump(O/'construction_failure.json',{'stage':stage,'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
