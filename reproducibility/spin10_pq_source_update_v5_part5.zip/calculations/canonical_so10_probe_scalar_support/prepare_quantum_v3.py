from pathlib import Path
from hashlib import sha256
import ast,json
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
old=read(O/'quantum_preparation_v2.json')
for p,h in old['input_sha256'].items():assert H(Path(p))==h,p
c=read(O/'quantum_verify_v2_capture.json');assert c['exit_code']==1 and not c['calculation_completed'] and not c['failed_or_incomplete_counted_as_PASS']
assert read(O/'quantum_controller_failure_v2.json')['stage']=='quantum_verify_v2'
for n in ['CORRECTION_V3.md','generate_quantum_v3.py','quantum_v3.py','verify_quantum_v3.py','prepare_quantum_v3.py','run_quantum_v3.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
b=dict(old['input_sha256'])
for p in O.iterdir():
 if p.is_file():b[str(p)]=H(p)
with(O/'quantum_preparation_v3.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'limits':old['limits'],'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,separators=(',',':'))+'\n').encode())
print('PREPARED_RXS2_V3',len(b))
