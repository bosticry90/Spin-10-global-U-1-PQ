from pathlib import Path
from hashlib import sha256
from collections import Counter
from itertools import combinations,combinations_with_replacement,permutations,product
import gzip,json,sys,time,threading,os
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('replay' if role=='primary' else'primary'):raise PermissionError('RXS1_PEER_DENIED')
  if any(x in p.parts for x in ['canonical_so10_even_probe_vertices','canonical_so10_probe_fermion_onejet','canonical_so10_probe_matter_source_consistency']):raise PermissionError('RXS1_COUNTERTERM_TARGET_DENIED')
sys.addaudithook(guard)
inp=json.loads(gzip.decompress((O/(role+'_inputs.json.gz')).read_bytes()));names=inp['names']
D2={'P':3,'S':3,'B':2,'x':2,'c':2,'a':2,'L':4,'rho':2}
fall={tuple(sorted(k)):v for k,v in [(('P','P'),1),(('P','S'),1),(('S','S'),1),(('B','B'),2),(('B','L'),1),(('x','x'),2),(('a','c'),2)]}
def classify(n):
 if role=='primary':
  if n.startswith('x_'):return 'x'
  if n.startswith(('bar','ub')):return 'a'
  if n.startswith(('b','L')):return 'L'
  if n.startswith('B'):return 'B'
  if n.startswith('C'):return 'c'
 else:
  prefix=n.split('_')[0]
  if prefix=='x':return 'x'
  for head,k in [('bar','a'),('ub','a'),('L','L'),('b','L'),('B','B'),('C','c')]:
   if n.startswith(head) and n[len(head):].split('_')[0].isdigit():return k
 raise AssertionError(n)
def vid(v):return json.dumps([v['origin'],v['ports'],v['mass_dimension'],v['g_degree'],v['Y_degree']],separators=(',',':'))
def canonical(seq,ex,es,meta):
 candidates=[]
 for order in permutations(range(len(seq))):
  if [seq[i] for i in order]!=sorted(seq):continue
  mp={old:new for new,old in enumerate(order)}
  xx=sorted((mp[i],k,j) for i,k,j,no in ex)
  ee=sorted(tuple(sorted(((mp[a[0]],a[1],a[2]),(mp[b[0]],b[1],b[2])))) for a,b in es)
  candidates.append(json.dumps([sorted(seq),xx,ee,*meta],separators=(',',':')))
 return min(candidates)
def connected(es,n,skip=-1):
 seen={0}
 while True:
  old=set(seen)
  for j,(a,b) in enumerate(es):
   if j==skip:continue
   if a[0] in seen:seen.add(b[0])
   if b[0] in seen:seen.add(a[0])
  if old==seen:return len(seen)==n
def pairings(pp,powers):
 if not pp:yield [];return
 a=pp[0]
 for i,b in enumerate(pp[1:],1):
  if a[0]==b[0] or tuple(sorted([a[1],b[1]])) not in powers:continue
  for tail in pairings(pp[1:i]+pp[i+1:],powers):yield [(a,b)]+tail
def enumerate_graphs(V,G,powers):
 E=[k for k,v in V.items() if v['origin'].startswith('E_')]
 cub=[k for k,v in V.items() if len(v['ports'])==3 and k not in E and v['origin']!='KCP']
 qua=[k for k,v in V.items() if len(v['ports'])==4]
 VV={**V,**G};out={k:set() for k in ['candidate','external_hat_zero','positive_dimension','UV_convergent']}
 for e in E:
  for gr,gv in G.items():
   ordinary=[tuple(v) for v in combinations_with_replacement(cub,2)]+[(q,) for q in qua] if len(gv['ports'])==3 else [(c,) for c in cub]
   for extra in ordinary:
    seq=[e,gr,*extra];n=len(seq);ports=[[(i,k,j,no) for no,(k,j) in enumerate(VV[name]['ports'])] for i,name in enumerate(seq)]
    choices=[[v for v in combinations(pp,len(pp)-2) if all(a[1] in ['rho','x','P'] for a in v)] for pp in ports]
    for selected in product(*choices):
     ext=[v for part in selected for v in part]
     if sorted(a[1] for a in ext)!=['P','P','rho','x']:continue
     inside=[v for pp,xx in zip(ports,selected) for v in pp if v not in xx]
     if role=='primary':
      esets=(es for es in pairings(inside,powers) if connected(es,n) and all(connected(es,n,j) for j in range(len(es))))
     else:
      pairs=[[v for v in pp if v not in xx] for pp,xx in zip(ports,selected)]
      def cycles():
       for tail in permutations(range(1,n)):
        if tail[0]>tail[-1]:continue
        order=(0,*tail)
        for flips in product([0,1],repeat=n):
         es=[(pairs[a][flips[a]],pairs[order[(i+1)%n]][1-flips[order[(i+1)%n]]]) for i,a in enumerate(order)]
         if all(tuple(sorted([a[1],b[1]])) in powers for a,b in es):yield es
      esets=cycles()
     for es in esets:
      md=sum(VV[k]['mass_dimension'] for k in seq);gp=sum(VV[k]['g_degree'] for k in seq);yp=sum(VV[k]['Y_degree'] for k in seq)
      ej=sum(len(j) for i,k,j,no in ext);ij=sum(len(j) for i,k,j,no in inside);ld=4-sum(powers[tuple(sorted([a[1],b[1]]))] for a,b in es)+ij
      assert ld+ej==-md
      status='external_hat_zero' if any('h' in j for i,k,j,no in ext) else'positive_dimension' if md else'UV_convergent' if ld<0 else'candidate'
      out[status].add(canonical(seq,ext,es,[ld,ej,gp,yp,md]))
 return {k:sorted(v) for k,v in out.items()}
V=inp['vertices'];G=[];profiles=[]
for r,packet in enumerate(inp['marginal_G']):
 gs={};counts=Counter()
 for gp,word,ci in packet['monomials']:
  ports=sorted([[classify(names[i]),'b'*len(j)] for i,j in word]+[['rho','']]);counts[json.dumps([ports,gp],separators=(',',':'))]+=1
  assert sum(D2[k]+2*len(j) for k,j in ports)==8
  v={'origin':'rhoG'+str(r),'ports':ports,'mass_dimension':0,'g_degree':gp,'Y_degree':0};gs[vid(v)]=v
 G.append(gs);profiles.append(dict(sorted(counts.items())))
out=[];controls=[]
for r,gs in enumerate(G):
 d=enumerate_graphs(V,gs,fall);out.append(d)
 c={}
 variants={'omit_PS_SP':(V,gs,{k:v for k,v in fall.items() if k!=('P','S')}),'omit_BL_LB':(V,gs,{k:v for k,v in fall.items() if k!=('B','L')}),'omit_Yukawa':({k:v for k,v in V.items() if v['origin']!='PPx'},gs,fall),'omit_scalar_current':({k:v for k,v in V.items() if not(v['origin']=='PHY' and sorted(p[0] for p in v['ports'])==['B','x','x'])},gs,fall),'omit_rho_aBB':(V,{k:v for k,v in gs.items() if len(v['ports'])!=4},fall)}
 for tag,(vv,gg,ff) in variants.items():
  dd=enumerate_graphs(vv,gg,ff);c[tag]=len(set(d['candidate'])^set(dd['candidate']))
 controls.append(c)
 print('STAGE COMPLETE_RHO_SCALAR_SUPPORT',role,r,{k:len(v) for k,v in d.items()},flush=True)
raw=(json.dumps({'schema':'RHO_SCALAR_SUPPORT_V1','role':role,'profiles':profiles,'G_vertices':G,'targets':out,'controls':controls,'G_inventory_reused':inp['G_inventory'],'qualified_full_Yukawa_carrier_reused':True,'new_quantum_coefficients_measured':False,'authority_changed':False},sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True)
