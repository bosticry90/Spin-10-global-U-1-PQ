# RXS2: actual first-rho scalar kernel before correction construction

RXS1 completed both independent support enumerations and verification:
eight marginal profiles for EACH rho label, all g10^2 Y. Four are auxiliary
BL/LB paths; four ordinary BB paths. There are four positive-dimension
and four convergent envelopes per probe, not assertions about their finite
massive amplitudes. The eight external-hat-zero envelopes remain separate.
No quantum coefficient has been measured by that support step.

Question: what is the complete allowed scalar kernel? In the SAME inherited
mass-independent nonexceptional Euclidean UV-local family, calculate all
eight profiles and both holomorphic/conjugate masses BEFORE comparison with
the previously fixed candidate. Unknown quantum input is not determined by
that candidate. External rho and scalar momentum0 is a local coefficient
projection, not a new constant-vacuum or finite massive propagator limit.
Keep h=-2epsilon and full-D bosonic endpoints until exact UV extraction.

Actual classical ending vertices from qualified PFJ1/RGS1 are V_r,A_r,H_r
and the real vector/ghost frame RB. Their scalar kinetic map and all actual
Tminus,B10,B126 come from YCT1. Extract ONLY these classical members into
new native inputs. The historical packet also contains old one-jet quantum
data, but no such member is supplied/used in this calculation. General
symmetric family factors remain independent and all328 scalar directions
are checked, including the physical zero complement. No flavor fit or new
mass/vacuum point is adopted. All positive-dimension scalar/GF terms are
excluded ONLY from this dimension-zero target by RXS1's degree proof.

Use SMA's actual free split PS/SP blocks and the insertion E, with all raw
orientations. At scalar M=0 the derivative is S1=-S0 diag(V_M,0) S0,
V_M=PL M+PR Mdagger. Thus S1_PS=b V_M h/K2^2 and S1_SP=h V_M b/K2^2.
No finite-hat massive denominator is substituted. The two fermion-line
numerators are the ordered ASB1 expressions with actual rho endpoint:
(-i b A_b) S1_PS (-h A_a) (+1)(+i), and
(Atilde_a h) S1_SP (-i b A_b) (-1)(+i).
The scalar-current expressions are V_j(-i h)(-h A_a) and
(Atilde_a h)(-i h)V_j, with the actual two bosonic resolvent derivatives.
The scalar kinetic density gives -ig tau_b(M)/K2 in BOTH mixed orientations.
tau_b(M)=i(Tb.T M+M Tb), U_a=-Ta.T, by actual qualified covariance.

The ghost at E stays internal. Relabelling the odd external endpoint C of
the inherited a C Lambda/B vertex by rho preserves its parity order and
the three/four-vertex Grassmann cumulant. PFJ1 has already independently
fixed the rho phases -i for the vector,+i for the auxiliary. Recheck the
literal -i V k vs+i H endpoint ratios and the full-D BB identity GBB*k=Wk/K2.
The B endpoint is MINUS the auxiliary unit times WV; Lambda has H. Do not
strip another width or coupling: the outer matter factor is g10^2 and all
widths in V/H remain actual. A_r=0 is checked, not inferred from rho's name.

Primary uses explicit split Clifford matrices/resolvents plus Gamma moments;
replay uses abstract Clifford words, inherited qualified cumulant signs
and independent Schwinger differentiation. The normalization assumptions
and cumulant/analytic-domain theorems of SMA/GTT/ASB/PFJ are shared REUSE,
not a new proof of QAP or all Grassmann statistics. The joint moments are
derived before substituting h=-2epsilon. An integer-rank Clifford witness
checks numerator identities, not the analytic value of h.

Retain raw ordered programs for each boson type and endpoint:
F_EC acting on U_b M T_a; F_ES on U_a M T_b;
SC_EC on tau_b(M)T_a; SC_ES on U_a tau_b(M).
Do NOT use ASB1's antisymmetric-H simplification for these symmetric rho
color weights. A fermion-line pair zero under an antisymmetric old tensor
can be nonzero here. Preserve ordered pieces before summing/symmetrizing.

Primary transforms actual generators with RB and forms sparse Kronecker
operators on all256 mass coordinates. Replay uses independent component
index events for the same full operators and scalar maps. Compare all
eight part operators, totals, complete holomorphic/anti B10/B126 maps,
zero complement, physical mass symmetry/reality, polynomial widths and
the residual-H covariance needed for admissibility. No unknown kernel or
counterterm target enters workers. Only AFTER complete agreement may the
verifier test the old candidate's rho*x*PP projection: u kinetic jets give
rho derivative terms, -K_P X(uC)P still contains K under d, and -iu BPP
gives rho BPP. At zero jets,B,K,C none produces rho*x*PP. A nonzero measured
remainder is preserved; it does not imply an anomaly or authorize retuning.

Controls omit each nonzero part, remove auxiliary paths, replace full-D
scalar contraction by its barred part, impose old antisymmetry, insert an
extra Nambu half/family3, or omit a Yukawa carrier. State honest insensitive
projections. No physical finite constants are chosen. A new scalar primitive
may be constructed ONLY after quantum calculation and verification, with all
its u*C*scalar, source/hatted companions kept for later independent tests.

Sequential primary/replay/verifier each600s after imports,8GiB sampled,
350MiB launch floor,whole RXS1/RXS2 packet16MiB. This is a distinct quantum
continuation, not a retrospective expansion of RXS1's120s/8MiB limits.
Freeze new sources/copies and inputs first. Stop first failure; preserve
failed/unfinished evidence and all samples. No silently expanded caps.
State113/34of39 and all protected physical failures/blocks unchanged.
No agents,branches/worktrees,push/outreach/publication,foundation/physical
scheme/benchmark adoption,flavor/HB1/C5 activation or promotion. Shared
action,analytic premises,software and AI author limit independence. Full
finite products,measure/global phase,massive matching,E5/A5 stay open.
