# RXS1–3: a measured nonzero scalar probe kernel and its local primitive

PROGRESS. In the declared bare mass-independent Euclidean UV-local family,
the complete first-rho*x*PP coefficient is now measured. It is NONZERO and
was missing from the previously fixed candidate. A new particular scalar
term, constructed AFTER quantum verification, cancels this projection and
preserves the five earlier scalar-zero marginal comparisons. The candidate
has been extended; it is not the unchanged old candidate predicting a sixth
quantum coefficient. No canonical action or physical scheme was adopted.

State113/scientific authority34of39 unchanged; E5/A5 and physical unification
remain open. This is not a percentage of investigation completion.

## Complete support before calculation

Current preflight recovered main707c8566,clean tracked tree,no matching
live research Python and452 historical bindings authenticated only. The
actual highest handoffV595,policy,qualified action/contracts and receipts
were read. RXS1 reuses the actual IBS1 action catalog and RGS1 independently
derived marginal G, instead of repeating their large qualified parsing.

For each independently labelled rho, pairing enumeration and separate cycle
enumeration agree on the full rho*x*PP witness domain:

| Classification | Profiles per probe |
|---|---:|
| Marginal candidates |8|
| External hatted derivative excluded |8|
| Positive coefficient dimension |4|
| Ordinary-jet/UV-convergent envelope |4|

All eight candidates are g10^2 Y: four ordinary BB and four mixed auxiliary
BL/LB paths. Removing PS/SP or Yukawa removes all8; removing BL/LB or the
scalar current changes4; removing the nonlinear rho*aBB vertex changes0.
These are typed support profiles, not independent nonzero quantum amplitudes.
The actual positive-dimension G/GF terms stay outside THIS marginal target;
their finite or massive effects have not been declared zero.

## Actual quantum kernel

Use the actual SMA split inverse and S1=-S0 diag(V_M,0)S0, keeping both raw
PS/SP orientations. Explicit split Clifford/Gamma versus abstract-word/
Schwinger routes rederive the common moments I0=-1/2,IB=-1/3,IH=-1/6.
The scalar-current full-D contraction retains IB+IH=I0. Qualified SMA/GTT/
ASB cumulant,analytic-domain and PFJ phase premises are shared REUSE.
An integer-rank Clifford witness does not replace h=-2epsilon analytically.

The four auxiliary ordered units are F_EC=F_ES=1/3,SC_EC=-i/2,SC_ES=i/2;
the vector endpoint has their checked minus sign times WV. Actual ending
V=-wP/2,H=-w^2P/4,A=0 are classical inputs, not chosen quantum corrections.
No extra width, Nambu half or family3 was inserted. Fermion-line terms
cannot be dropped by the old antisymmetric-H simplification: these rho
color weights are symmetric.

Let T_a be the correctly transported physical charges,

 C_r=sum_(a in sector r) T_a^2,
 J_r(M)=sum_(a in sector r) T_a.T M T_a.

The complete mass-kernel coefficient, in common1/(16pi2) units, is

 R_rho,r(M)=g10^2 w_r^2 [J_r(M)/12+(C_r.T M+M C_r)/8],
 (r,w_r)=(0,eta_H),(1,xi).

M is the full scalar-linear SMA Yukawa polynomial with generic symmetric
Y10/Y126. Its conjugate is retained. All328 scalar maps, the family factors
and zero complements are preserved. No numerical flavor input is chosen.
Both probes' eight part operators,total and physical maps agree across
7225344 retained coefficient positions. Counts include related pieces;
they are not independent experimental confirmations.

| Nonzero positions | rho0 | rho1 |
|---|---:|---:|
| Full holomorphic mass operator |383|768|
| B10 map, per chirality |320|320|
| B126 map, per chirality |4000|4032|

Total mass symmetry and conjugation hold. All12 actual residual-H operator
commutators vanish. Omitting auxiliary paths, prematurely barring the scalar
current, imposing old antisymmetry or adding an extra half/family3 changes
383/768 unrestricted mass-operator positions. Every individual nonzero
part omission is sensitive in its declared operator domain.

The previously fixed functional's ordinary rho*x*PP image is0 by actual
monomial/jet support: d(u kinetic) gives rho kinetic, d(-K_P u C x P)
retains K, and d(-iu BPP) gives rho BPP. At zero jets,B,C,K none supplies
this scalar target. Thus its measured remainder is the NONZERO kernel above,
not an anomaly verdict or permission to fit an uncalculated contribution.

## Post-result primitive and correlated image

After complete quantum verification, construct the particular mass-density
term using SMA's same alternating1/2 normalization:

 deltaM(x)=-g10^2 sum_r u_r w_r^2
           [J_r(M(x))/12+(C_r.T M(x)+M(x) C_r)/8],

with its conjugate. Its d image cancels the measured rho component. This is
construction from independently measured input, not another quantum match.
Full compact-vs-measured256x256 operator equality, symmetric-subspace
preservation and a generic alternating-half/odd-left-u derivative are checked.

The new term is derivative-free,source-free,ghost0/dimension4,complex linear
in M,polynomial in widths and has no inverse physical parameter. Existing
mass symmetry/reality/H covariance and PQ carrier charge are retained. This
does not prove a quantum PQ identity or a complete invariant-counterterm
classification. Source-containing alternatives/homogeneous freedoms are not
excluded and no physical normalization constant has been selected.

All45 full u*C*scalar COUNTERTERM descendants per probe are reconstructed as
g10^3 u_r C_c [A_c,K_r](M),K_r=-R_r/g10^2,
A_c(M)=i(Tc.T M+M Tc). Direct matrix composition and independent four-index
events agree. Bound K/T programs plus complete hashes/nonzero counts make
every operator reconstructable without expanding millions of scalar words.
The first12 and one additional color image vanish;32 per probe are nonzero.
Their QUANTUM counterpart is still unknown. The old source/Euler image must
join this new scalar image exactly once in the future comparison.

The correction has at least one scalar and no source/vector/jet. Its five
earlier scalar-zero marginal images vanish by support. Positive-dimension
VEV/GF terms,sterile/hatted external fields and finite nonlocal products
remain separate; substituting a vacuum into this one term is not a complete
massive amplitude or physical constant-vacuum matching calculation.

## Preserved failed runs and the shared-error lesson

Original quantum primary stopped before a table at a rational BB contraction:
expand alone did not reduce an exact expression over sum k_i^2. Original
source/copies/full capture/controller remain; replay/verifier NOT_LAUNCHED.
V2 uses cancel without changing the equality or physics requirement.

V2 primary/replay then completed and agreed, but the verifier FAILED the
residual-H test. Their arrays remain UNQUALIFIED. Both routes used RB in
the wrong direction. Actual RB has original plane ROW/physical field COLUMN:
Tphysical_a=sum_k RB[k,a]Tplane_k. V2 used RB[a,k]. This was a shared
implementation error, not a failure of the physical model. Older qualified
PFJ1/UCB1 programs use correct columns; their inputs/results are unchanged.

V3 primary uses correct physical charges; replay separately contracts in
the original plane basis with RB*weight_physical*RB.T. The same full covariance
test now passes alongside every quantum part/map comparison. No requirement
was weakened. A diagnostic on the FAILED V2 arrays shows their normalized
two-probe SUM still agrees, even though each separate operator differs at
2976 positions. Identifying probe labels and equalizing widths can hide the
mistake; equal widths alone with independent labels need not. Read
DIAGNOSTIC_SCOPE_NOTE.md for the precise equation and metadata qualification.

This demonstrates why AI agreement,orthogonality and a combined-limit check
did not certify the transport. It also records two avoidable implementation
failures. All failed/unqualified bytes remain; no failed run was relabelled.

## Execution, custody and limits

| Completed stage | Seconds after imports | Samples | Max sampled private bytes |
|---|---:|---:|---:|
| Support primary |0.1283127|1|925696|
| Support replay |0.2694115|1|393216|
| Support verifier |0.0123767|1|397312|
| Quantum primary V3 |30.1560716|16|96542720|
| Quantum replay V3 |29.5962581|16|100904960|
| Quantum verifier V3 |97.8731162|50|123711488|
| Post-result construction |13.1248453|8|165126144|

Samples are not continuous peaks; short census samples are startup evidence.
Failed original primary has2 samples/max52076544B. V2 unqualified primary/
replay77.6203200/77.8825510s,40/40 samples,max162201600/162537472B. Failed
V2 verifier56 samples/max221904896B,last observed110.3168114s. No run exhausted
its frozen cap. Support120s/8MiB,distinct quantum600s/16MiB,construction300s/
16MiB; all8GiB sampled-private/350MiB launch floor. Caps never expanded after
failures.25 exact source copies; manifest binding counts32/40,72,88/96,
111/119,128. Packet~4.80MB before this report/handoff.

Receipt SHA256:

- Support241f952e9c49380ba415cdd85091474760c97ab06e2c6913b1be5ce651e89c6a
- QuantumV3 9b7bfc7adbefab898c1bfa7421b21eada7d5ac702e66c290de3a76fbffd71300
- Constructionb6c88f60ba387356d7fa42145fb778243bc3eefb14476a85c0e9a0a9bcc861be

Current-turn E4 readiness native0,exits[0,0,0,0,0,2],custody exit2/seven
NOTPASS. This authenticates/reuses historical science,not a fresh E4 replay
or E5 acceptance. External full captures/readiness/before/index/postcommit
seals: C:/Users/psboy/.codex/research-control-records/ToE-Next/
probe-scalar-support-v1-2026-10-24/. Preserve all35066 prior tracked blobs,
main and project_state.json through local sealing/commit.

## Next scientific decision and limitations

Measure the complete first-u*C*x*PP kernel from the actual unexpanded
ghost triangle and its scalar derivative,using the qualified u inverse and
ending response. The paired physical fermion-edge zero needs its actual
scalar-derivative proof,not an early hat deletion. Retain all possible
QG/source companions until target-specific support excludes them. Compare
independently measured input only AFTERWARD with the combined old source
Euler and new scalar commutator programs. NEXT_UC_SCALAR.md is a target note,
not an executed/frozen next calculation or presumed cancellation.

The methods share action,frames,analytic/cumulant premises,software and AI
author. Agreement is internal computational corroboration,not independent
scientific or experimental confirmation. Full finite/contact products,
multiple insertions,chiral measure/global phase,varying-background/causal
and constant-vacuum domains,massive fermion matching,physical unification
and E5/A5 remain open. kappa,b0,chi4 stay distinct/unselected; prior scalar/
benchmark/quartet failures and flavor/HB1/C5 boundaries remain protected.
