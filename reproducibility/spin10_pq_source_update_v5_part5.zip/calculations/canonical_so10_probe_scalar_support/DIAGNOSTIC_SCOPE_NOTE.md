# Precise interpretation of the combined-probe diagnostic

construction_receipt.json's key failed_V2_equal_width_diagnostic is a short
metadata label. The actual checked equation is

 R0_new/eta_H^2+R1_new/xi^2=R0_failedV2/eta_H^2+R1_failedV2/xi^2.

This is a NORMALIZED SUM of two different probe kernels. It does not say
that setting equal widths alone conceals the error while keeping rho0 and
rho1 independent. To interpret it as a common-width amplitude one must ALSO
identify their external probe coefficients. Separate normalized operators
still differ at2976 positions each. Preserve the independent probe labels.

The receipt's mathematics and all original source/report bytes remain
unchanged. This clarification narrows the label's interpretation; it does
not requalify the failed V2 physics or create another failed execution.
