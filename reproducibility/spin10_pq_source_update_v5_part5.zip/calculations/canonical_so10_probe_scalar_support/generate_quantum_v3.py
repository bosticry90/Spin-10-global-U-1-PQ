from pathlib import Path
import ast
O=Path(__file__).resolve().parent
q=(O/'quantum_v2.py').read_text(encoding='utf-8')
old="T=[tidy(sum((RB[a,b]*Tp[b] for b in range(45) if RB[a,b]),s.zeros(16))) for a in range(45)]"
new="T=[tidy(sum((RB[b,a]*Tp[b] for b in range(45) if RB[b,a]),s.zeros(16))) for a in range(45)]"
assert q.count(old)==1;q=q.replace(old,new)
old="  sign=-1 if bose=='B' else 1\n"
new=old+"  tensor_weight=weight if role=='primary' else tidy(RB*weight*RB.T)\n  Tc=T if role=='primary' else Tp\n"
assert q.count(old)==1;q=q.replace(old,new).replace('weight.todok()','tensor_weight.todok()').replace('co*T[b]*T[a]','co*Tc[b]*Tc[a]').replace('kron(T[b].T,T[a].T)','kron(Tc[b].T,Tc[a].T)').replace('kron(T[a].T,T[b].T)','kron(Tc[a].T,Tc[b].T)').replace('T[b].todok()','Tc[b].todok()').replace('T[a].todok()','Tc[a].todok()')
q=q.replace('quantum_preparation_v2.json','quantum_preparation_v3.json').replace("role+'_v2_tables.json.gz'","role+'_v3_tables.json.gz'")
v=(O/'verify_quantum_v2.py').read_text(encoding='utf-8')
old="T=[tidy(sum((RB[a,b]*Tp[b] for b in range(45) if RB[a,b]),s.zeros(16))) for a in range(12)]"
new="T=[tidy(sum((RB[b,a]*Tp[b] for b in range(45) if RB[b,a]),s.zeros(16))) for a in range(12)]"
assert v.count(old)==1;v=v.replace(old,new).replace('quantum_validation_preparation_v2.json','quantum_validation_preparation_v3.json').replace('quantum_primary_v2_tables.json.gz','quantum_primary_v3_tables.json.gz').replace('quantum_replay_v2_tables.json.gz','quantum_replay_v3_tables.json.gz')
for n,source in [('quantum_v3.py',q),('verify_quantum_v3.py',v)]:
 ast.parse(source)
 with(O/n).open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print('GENERATED_RXS2_V3_COLUMN_TRANSPORT_AND_SEPARATE_PLANE_REPLAY')
