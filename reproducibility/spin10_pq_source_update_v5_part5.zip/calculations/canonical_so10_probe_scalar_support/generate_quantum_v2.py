from pathlib import Path
import ast
O=Path(__file__).resolve().parent
q=(O/'quantum.py').read_text(encoding='utf-8')
old="for mu in range(6):assert s.expand(sum((int(mu==nu)+(ww-1)*v6[mu]*v6[nu]/Q)*v6[nu] for nu in range(6))-ww*v6[mu])==0"
new=old.replace('s.expand','s.cancel');assert q.count(old)==1;q=q.replace(old,new)
q=q.replace("O/'quantum_preparation.json'","O/'quantum_preparation_v2.json'").replace("role+'_tables.json.gz'","role+'_v2_tables.json.gz'")
v=(O/'verify_quantum.py').read_text(encoding='utf-8').replace("O/'quantum_validation_preparation.json'","O/'quantum_validation_preparation_v2.json'").replace('quantum_primary_tables.json.gz','quantum_primary_v2_tables.json.gz').replace('quantum_replay_tables.json.gz','quantum_replay_v2_tables.json.gz')
for n,source in [('quantum_v2.py',q),('verify_quantum_v2.py',v)]:
 ast.parse(source)
 with(O/n).open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print('GENERATED_RXS2_V2_EXACT_RATIONAL_COMPARISON')
