from pathlib import Path
from hashlib import sha256
import gzip,json,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
tick=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start()
for p,h in read(O/'quantum_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
P=load(O/'quantum_primary_tables.json.gz');Z=load(O/'quantum_replay_tables.json.gz')
for k in ['raw_spin_units','raw_conjugate_spin_units','finite_moments','units','vector_to_auxiliary_phase_ratios','color','operators','models']:assert P[k]==Z[k],k
xi,eta=s.symbols('xi eta_H',real=True);loc={'xi':xi,'eta_H':eta}
dec=lambda d:s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z,locals=loc) for i,j,z in d['entries']})
tidy=lambda M:s.SparseMatrix(M).applyfunc(s.expand)
def zero(M):assert not tidy(M).todok()
def swapped(M):return s.SparseMatrix(256,M.cols,{((i%16)*16+i//16,j):v for (i,j),v in M.todok().items()})
inp=load(O/'quantum_primary_inputs.json.gz');RB=dec(inp['RB']);Tp=list(map(dec,inp['Tminus']));T=[tidy(sum((RB[a,b]*Tp[b] for b in range(45) if RB[a,b]),s.zeros(16))) for a in range(12)]
def kron(A,B):return s.SparseMatrix(A.rows*B.rows,A.cols*B.cols,{(i*B.rows+k,j*B.cols+l):x*y for (i,j),x in s.SparseMatrix(A).todok().items() for (k,l),y in s.SparseMatrix(B).todok().items()})
Hops=[s.I*(kron(v.T,s.eye(16))+kron(s.eye(16),v.T)) for v in T]
summaries=[];checked=0
for r in range(2):
 ops={k:dec(v) for k,v in P['operators'][r].items()};checked+=len(ops)*256**2
 zero(sum((v for k,v in ops.items() if k!='total'),s.zeros(256))-ops['total'])
 c={};parts={}
 for tag,rows in P['models'][r].items():
  for bi,row in enumerate(rows):
   M,N=dec(row['holomorphic']),dec(row['antiholomorphic']);checked+=2*256*328;zero(N-s.conjugate(M));parts[tag+'_'+str(bi)]=len(M.todok())
   if tag=='total':zero(M-swapped(M))
 for bi in range(2):
  M=dec(P['models'][r]['total'][bi]['holomorphic']);c['B'+['10','126'][bi]]=len(M.todok())
  for tag in ops:
   if tag=='total':continue
   assert len(dec(P['models'][r][tag][bi]['holomorphic']).todok())==parts[tag+'_'+str(bi)]
 for hh in Hops:zero(hh*ops['total']-ops['total']*hh)
 scalar_parts=sum((v for k,v in ops.items() if '_SC_' in k),s.zeros(256));bar_ratio=s.sympify(P['finite_moments']['IB'])/s.sympify(P['finite_moments']['I0'])
 controls={'omit_all_auxiliary':len(tidy(sum((v for k,v in ops.items() if k.startswith('L_')),s.zeros(256))).todok()),'extra_half_or_family3':len(ops['total'].todok()),'force_old_antisymmetric_weight':len(ops['total'].todok()),'premature_barred_scalar_current':len(tidy((1-bar_ratio)*scalar_parts).todok())}
 for tag,op in ops.items():
  if tag!='total':controls['omit_'+tag]=len(op.todok())
 summaries.append({'operator_nonzeros':{k:len(v.todok()) for k,v in ops.items()},'physical_map_nonzeros_per_chirality':c,'part_map_nonzeros':parts,'controls_unrestricted_mass_operator':controls})
# This projection test follows the actual fixed-functional monomial support:
# d(u kinetic)=rho kinetic; d(K u C P) contains K; d(u B PP)=rho B PP.
# Ordinary rho*x*PP at zero jets,B,C,K is absent. No target determined input.
assert P['general_symmetric_families_factorized'] and not P['counterterm_target_used']
print('RESULT '+json.dumps({'schema':'RHO_SCALAR_QUANTUM_VALIDATION_V1','elapsed_after_imports':time.perf_counter()-tick,'full_parts_operators_maps_and_zero_complements_agree':True,'retained_operator_and_map_positions_compared':checked,'all12_H_mass_operator_commutators_zero':True,'summaries':summaries,'fixed_old_candidate_rho_scalar_projection':'ZERO_BY_FUNCTIONAL_ROLE_AND_JET_SUPPORT','fixed_old_candidate_remainder':'MEASURED_QUANTUM_KERNEL_NO_COEFFICIENT_ADJUSTMENT','physical_mass_symmetry_and_conjugation_pass':True,'counterterm_constructed':False,'full_QAP_or_authority_changed':False},sort_keys=True),flush=True)
