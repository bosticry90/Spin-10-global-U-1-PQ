from pathlib import Path
from hashlib import sha256
import ast,gzip,json
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
b=dict(read(O/'validation_preparation.json')['input_sha256'])
for p,h in b.items():assert H(Path(p))==h,p
assert read(O/'validation_receipt.json')['complete_independent_pairing_and_cycle_witness_sets_agree']
for role in ['primary','replay']:
 pp=O.parent/'canonical_so10_probe_fermion_onejet';yy=O.parent/'canonical_so10_yukawa_carrier_transport'
 p=pp/(role+'_tables.json.gz');m=read(pp/'validation_preparation.json');assert H(p)==m['input_sha256'][str(p)];b[str(p)]=H(p);b[str(pp/'validation_preparation.json')]=H(pp/'validation_preparation.json');d=load(p)
 p=yy/(role+'_tables.json.gz');m=read(yy/'validation_preparation.json');assert H(p)==m['input_sha256'][str(p)];b[str(p)]=H(p);b[str(yy/'validation_preparation.json')]=H(yy/'validation_preparation.json');y=load(p)
 z={'RB':d['RB'],'V_A_H':d['V_A_H'],'Tminus':y['Tminus'],'B10':y['B10'],'B126':y['B126'],'extraction':'ONLY_ACTUAL_CLASSICAL_ENDPOINTS_FRAME_AND_YUKAWA_MAPS_NO_QUANTUM_OR_COUNTERTERM'}
 p=O/('quantum_'+role+'_inputs.json.gz')
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 b[str(p)]=H(p)
for folder,ns in {'canonical_so10_auxiliary_scalar_matter_breaking':['DERIVATION.md','RESULT.md','validation_receipt.json'],'canonical_so10_ordinary_scalar_matter_breaking':['DERIVATION.md','RESULT.md','validation_receipt_v5.json'],'canonical_so10_sterile_matter_action':['ACTION_V1.md','validation_receipt.json'],'canonical_so10_probe_fermion_onejet':['DERIVATION.md','validation_receipt.json','COMPANION_CONSTRUCTION.md'],'canonical_so10_even_probe_vertices':['RESULT.md']}.items():
 for n in ns:p=O.parent/folder/n;b[str(p)]=H(p)
for n in ['QUANTUM_RECORD.md','prepare_quantum.py','quantum.py','verify_quantum.py','run_quantum.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
for p in O.iterdir():
 if p.is_file():b[str(p)]=H(p)
with(O/'quantum_preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'limits':{'seconds_after_imports':600,'sampled_private_bytes':8*1024**3,'launch_floor':350*1024**2,'packet_bytes':16*1024**2},'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,separators=(',',':'))+'\n').encode())
print('PREPARED_RXS2',len(b))
