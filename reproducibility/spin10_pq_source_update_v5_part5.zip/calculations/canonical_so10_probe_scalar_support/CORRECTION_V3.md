# RXS2 V3: actual frame columns, independently contracted replay basis

V2's quantum primary and replay completed and their retained parts/maps
agreed. The separate verifier then FAILED the residual-H mass-operator
commutator. No V2 validation receipt exists. These arrays are UNQUALIFIED,
not a quantum obstruction, and must not be used as measured Spin(10) input.

The cause is a shared transport implementation mistake. PFJ1's actual RB
has original plane generator ROW and physical field COLUMN. The coefficient
of Bphysical_a in sum_k Tplane_k RB[k,a] Bphysical_a is therefore
Tphysical_a=sum_k RB[k,a] Tplane_k. RXS2 incorrectly used RB[a,k]. This
orthogonal matrix is not symmetric. Orthogonality or primary/replay agreement
does not certify the direction of a representation map. The old PFJ1 and
PUV1/UCB1 actual programs use the correct column convention; they are not
changed or requalified by this new result.

V3 primary uses correct physical charges. Replay separately contracts in
the ORIGINAL plane basis with weight RB*weight_physical*RB.T, rather than
sharing primary's physical-charge contraction. The verifier's actual
residual-H generators use correct columns and retains the full original
commutator, mass symmetry/reality, all maps/zeros and all part comparisons.
This is action-density coefficient transport, not a change of physical
input, a favorable basis selection or a weakened scientific condition.

Original V1/V2 sources, copies, complete primary/replay/verifier captures,
results and failure controllers remain immutable. V2 input1 is preserved;
V3 uses the SAME classical input bytes, radial/spin units, scalar maps,
coupling/width powers and600s/8GiB sampled/350MiB floor/16MiB limits. Only
after all new checks complete may the new arrays be called qualified.
No failed verification is relabelled PASS; source-count corrections and
remaining product/measure/physical/E5 obligations remain separate.
