from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start()
role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'quantum_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('quantum_'+('replay' if role=='primary' else'primary')):raise PermissionError('RXS2_PEER_DENIED')
  if any(x in p.parts for x in ['canonical_so10_even_probe_vertices','canonical_so10_probe_fermion_onejet','canonical_so10_probe_matter_source_consistency','canonical_so10_scalar_matter_primitive']):raise PermissionError('RXS2_OLD_QUANTUM_OR_COUNTERTERM_DENIED')
sys.addaudithook(guard)
xi,eta=s.symbols('xi eta_H',real=True);loc={'xi':xi,'eta_H':eta}
dec=lambda d:s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z,locals=loc) for i,j,z in d['entries']})
@lru_cache(None)
def simp(z):return s.expand(z)
def tidy(M):return s.SparseMatrix(M).applyfunc(simp)
def zero(M):assert not tidy(M).todok()
def enc(M):return {'shape':list(M.shape),'entries':[[i,j,str(simp(v))] for (i,j),v in sorted(s.SparseMatrix(M).todok().items()) if simp(v)!=0]}
def kron(A,B):return s.SparseMatrix(A.rows*B.rows,A.cols*B.cols,{(i*B.rows+k,j*B.cols+l):x*y for (i,j),x in s.SparseMatrix(A).todok().items() for (k,l),y in s.SparseMatrix(B).todok().items()})
eps,h,ir=s.symbols('epsilon h m_IR2',positive=True)
if role=='primary':
 pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
 gg=[s.kronecker_product(pa[1],v) for v in pa]+[s.kronecker_product(pa[0],s.eye(2))]
 gam=[s.kronecker_product(v,pa[2]) for v in gg]+[s.kronecker_product(s.eye(4),v) for v in pa[:2]]
 chi=s.prod(gam[:4]);PL=(s.eye(8)+chi)/2;PR=s.eye(8)-PL;Z=s.zeros(8);k=s.symbols('k0:6')
 bb=sum((k[i]*gam[i] for i in range(4)),Z);hh=sum((k[i]*gam[i] for i in [4,5]),Z);B=sum(v*v for v in k[:4]);HH=sum(v*v for v in k[4:]);K=B+HH
 aL,aR,bL,bR,m,md,n,nd=s.symbols('aL aR bL bR m md n nd');Aa=aL*PL+aR*PR;At=aR*PL+aL*PR;Ab=bL*PL+bR*PR;V=m*PL+md*PR;Tau=n*PL+nd*PR
 N=bb.row_join(hh).col_join(hh.row_join(bb));S=-s.I*N;VM=V.row_join(Z).col_join(Z.row_join(Z));S1=(-S*VM*S).applyfunc(s.expand)
 zero(N*N-K*s.eye(16));zero(S1[:8,8:]-bb*V*hh);zero(S1[8:,:8]-hh*V*bb)
 terms={'F_EC':((-s.I*bb*Ab)*S1[:8,8:]*(-hh*Aa)*s.I,B*HH,bR*m*aL),'F_ES':((At*hh)*S1[8:,:8]*(-s.I*bb*Ab)*(-1)*s.I,B*HH,aR*m*bL),'SC_EC':(Tau*(-s.I*hh)*(-hh*Aa)*(-s.I*K)*s.I,HH*K,n*aL),'SC_ES':((At*hh)*(-s.I*hh)*Tau*(-s.I*K)*s.I,HH*K,aR*n)}
 raw={};anti_raw={}
 for tag,(M,base,charge) in terms.items():
  co=s.simplify(s.trace(PL*M)/(s.trace(PL)*base*charge));zero(M*PL-co*base*charge*PL);raw[tag]=co
  ac={'F_EC':bL*md*aR,'F_ES':aL*md*bR,'SC_EC':nd*aR,'SC_ES':aL*nd}[tag]
  aq=s.simplify(s.trace(PR*M)/(s.trace(PR)*base*ac));zero(M*PR-aq*base*ac*PR);anti_raw[tag]=aq
 D=4-2*eps
 def reg(p,n):return ir**(-eps)*s.gamma(p+D/2)*s.gamma(1+eps)/(s.gamma(D/2)*s.gamma(n))
 rr=[h/D*reg(1,3),4*h/(D*(D+2))*reg(2,4),h*(h+2)/(D*(D+2))*reg(2,4)]
else:
 B,HH=s.symbols('B H');aL,aR,bL,bR,m,md,n,nd=s.symbols('aL aR bL bR m md n nd')
 def spin(seq,side=0):
  chir=side;co=s.S.One
  for v in reversed(seq):
   if v=='b':chir=1-chir
   elif v in ['Aa','At','Ab','V','Tau']:co*=dict(Aa=[aL,aR],At=[aR,aL],Ab=[bL,bR],V=[m,md],Tau=[n,nd])[v][chir]
  mask=0
  for v in seq:
   if v not in ['b','h']:continue
   bit=1 if v=='b' else 2
   co*=(-1)**((mask>>(1 if bit==1 else 2)).bit_count())
   if mask&bit:co*=B if bit==1 else HH
   mask^=bit
  assert mask==0 and chir==side;return s.expand(co)
 # These phases reuse the qualified complete ASB1 Berezin cumulants and
 # identical external-odd endpoint ordering; only numerator algebra is new.
 seqs={'F_EC':(['b','Ab','b','V','h','h','Aa'],-1,B*HH,bR*m*aL),'F_ES':(['At','h','h','V','b','b','Ab'],-1,B*HH,aR*m*bL),'SC_EC':(['Tau','h','h','Aa'],s.I,HH,n*aL),'SC_ES':(['At','h','h','Tau'],-s.I,HH,aR*n)}
 raw={tag:s.simplify(phase*spin(seq)/(base*charge)) for tag,(seq,phase,base,charge) in seqs.items()}
 anti_charges={'F_EC':bL*md*aR,'F_ES':aL*md*bR,'SC_EC':nd*aR,'SC_ES':aL*nd}
 anti_raw={tag:s.simplify(phase*spin(seq,1)/(base*anti_charges[tag])) for tag,(seq,phase,base,charge) in seqs.items()}
 rr=[h*s.gamma(1+eps)*ir**(-eps)/4,h*4*s.gamma(1+eps)*ir**(-eps)/24,h*(h+2)*s.gamma(1+eps)*ir**(-eps)/24]
assert raw==anti_raw
finite=lambda z:s.simplify(s.diff(z.subs(h,-2*eps),eps).subs(eps,0))
I0,IB,IH=map(finite,rr);assert s.simplify(IB+IH-I0)==0
units={tag:s.simplify(co*(IB if tag.startswith('F_') else I0)) for tag,co in raw.items()}
# Direct endpoint assignments: -i V k divided by+i H k is minus V/H.
ua,ub,kk=s.symbols('UA UB k',nonzero=True)
oriented=[s.simplify(s.I*(ua*(-kk)+ub*kk)/((ua-ub)*kk)),s.simplify(s.I*(ua*kk+ub*(-kk))/((ua-ub)*kk))]
ratios=[s.simplify(oriented[0]/s.I),s.simplify(oriented[1]/(-s.I))];assert ratios==[-1,-1]
v6=s.symbols('q0:6');Q=sum(v*v for v in v6);ww=s.symbols('w')
for mu in range(6):assert s.expand(sum((int(mu==nu)+(ww-1)*v6[mu]*v6[nu]/Q)*v6[nu] for nu in range(6))-ww*v6[mu])==0
inp=json.loads(gzip.decompress((O/('quantum_'+role+'_inputs.json.gz')).read_bytes()));RB=dec(inp['RB']);zero(RB*RB.T-s.eye(45));Tp=list(map(dec,inp['Tminus']));T=[tidy(sum((RB[a,b]*Tp[b] for b in range(45) if RB[a,b]),s.zeros(16))) for a in range(45)]
for v in T:zero(v-v.H)
Bs=[dec(inp[n]) for n in ['B10','B126']];I=s.eye(16);tables=[];models=[];color=[]
for r,vah in enumerate(inp['V_A_H']):
 V=dec(vah['V']);Hc=dec(vah['H']);zero(dec(vah['A']));W=s.diag(*([eta]*12+[xi]*33));C=tidy(W*V)
 for M in [C,Hc]:zero(M-M.T)
 bosons={};partops={}
 for bose,weight in [('B',C),('L',Hc)]:
  sign=-1 if bose=='B' else 1
  if role=='primary':
   J1=s.SparseMatrix(256,256,{});J2=s.SparseMatrix(256,256,{});P1=s.zeros(16)
   for (b,a),co in weight.todok().items():
    P1+=co*T[b]*T[a];J1+=co*kron(T[b].T,T[a].T);J2+=co*kron(T[a].T,T[b].T)
   P1=tidy(P1);J1=tidy(J1);J2=tidy(J2);L=kron(P1.T,I);R=kron(I,P1.T)
  else:
   p=defaultdict(lambda:s.S.Zero);j1=defaultdict(lambda:s.S.Zero);j2=defaultdict(lambda:s.S.Zero)
   for (b,a),co in weight.todok().items():
    for (i,j),x in T[b].todok().items():
     for (k,l),y in T[a].todok().items():
      if j==k:p[i,l]+=co*x*y
      j1[j*16+l,i*16+k]+=co*x*y;j2[l*16+j,k*16+i]+=co*x*y
   P1=tidy(s.SparseMatrix(16,16,p));J1=tidy(s.SparseMatrix(256,256,j1));J2=tidy(s.SparseMatrix(256,256,j2));ld={};rd={}
   for (i,j),co in P1.todok().items():
    for k in range(16):ld[j*16+k,i*16+k]=co;rd[k*16+j,k*16+i]=co
   L=s.SparseMatrix(256,256,ld);R=s.SparseMatrix(256,256,rd)
  parts={'F_EC':-units['F_EC']*J1,'F_ES':-units['F_ES']*J2,'SC_EC':s.I*units['SC_EC']*(J1+R),'SC_ES':-s.I*units['SC_ES']*(J2+L)}
  for tag,op in parts.items():partops[bose+'_'+tag]=tidy(sign*op)
  bosons[bose]={'weight':enc(weight),'P1':enc(P1),'J1':enc(J1),'J2':enc(J2)}
 partops['total']=tidy(sum(partops.values(),s.zeros(256)));tables.append({k:enc(v) for k,v in partops.items()});color.append(bosons)
 model={}
 for tag,op in partops.items():
  model[tag]=[{'holomorphic':enc(tidy(op*b)),'antiholomorphic':enc(tidy(s.conjugate(op)*s.conjugate(b)))} for b in Bs]
 models.append(model);print('STAGE COMPLETE_RHO_SCALAR_OPERATORS_AND_MAPS',role,r,flush=True)
out={'schema':'RHO_SCALAR_QUANTUM_V1','role':role,'raw_spin_units':{k:str(v) for k,v in raw.items()},'raw_conjugate_spin_units':{k:str(v) for k,v in anti_raw.items()},'finite_moments':dict(zip(['I0','IB','IH'],map(str,[I0,IB,IH]))),'units':{k:str(v) for k,v in units.items()},'vector_to_auxiliary_phase_ratios':list(map(str,ratios)),'color':color,'operators':tables,'models':models,'general_symmetric_families_factorized':True,'counterterm_target_used':False,'new_finite_massive_QAP_claim':False}
blobraw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(blobraw,mtime=0)
with(O/('quantum_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(blobraw).hexdigest()},sort_keys=True),flush=True)
