# RXS1: first-probe scalar bilinear support

Base/main707c8566621e446499c940e536bbf22ab15c0b3e. Previous turn PROGRESS:
PUV1/UCB1 independently measured the complete first-u*C*BPP local coefficient
and matched the unchanged candidate. Whole Spin(10)xPQ investigation remains
ACTIVE/INCOMPLETE. State113/34of39 unchanged, E5/A5 open, custody2/sevenNOTPASS.
Current read-only preflight:clean tree,no matching Python workers,452 bindings
authenticated only. AGENTS.md remains live policy.

Question: what is the COMPLETE first-rho*x*PP zero-ordinary-jet marginal
bare-insertion support? The vector/derivative matches do not test this allowed
Majorana/Yukawa carrier. A complete small operator family would justify its
next quantum calculation; another unstructured scalar expansion would not.

Use the inherited mass-independent nonexceptional Euclidean UV-local domain,
physical external fermions with hats0, independent rho labels, external
scalar dimension1 and full internal PS/SP,BB,BL/LB,ghost/scalar edges. Ihat
has ghost1/dimension5; rho dimension1/ghost1, P dimension3/2, x dimension1.
The target has no ordinary-jet budget and admits coefficient mass dimension0.
Positive-dimension terms, finite nonlocal amplitudes, exceptional/physical
constant-vacuum limits, external sterile fields and independent A are OUTSIDE,
not zero. General symmetric Y10/Y126 and all328 scalar maps remain available;
no numerical flavor/benchmark choice or blocked-stage activation.

Authenticate and reuse IBS1's actual complete typed action catalog and RGS1's
literal/Euler complete marginal G, with the actual qualified receipts. The
296 positive-coefficient-dimension G rows and inherited positive-dimension GF
vertices remain preserved and cannot contribute to THIS dimension-zero
coefficient without forbidden inverse physical parameters. This is a marginal
support calculation, not a new massive-operator census or loop integral.

For connected bridgeless one-loop graphs every internal vertex has degree2,
since E=V and no bridges/tadpole attachments are allowed. Thus each vertex
has exactly valence-2 external ports and sum(valence-2)=4 for rho*x*PP.
There is exactly one E_C/E_P/E_S, exactly one rho*G, and ordinary action
vertices. G has marginal two- or three-field terms. For a three-valent
rho*G the remaining ordinary choices are two cubics or one quartic; for
four-valent rho*G they are one cubic. No matter quartic or direct sterile
interaction is invented. Auxiliary LL free propagation is zero, not a
license to omit BL/LB. Conservative color support is distinct from a
nonzero Spin(10) coefficient.

Primary reads the actual marginal monomials, classifies role/jet/g power,
then enumerates every compatible internal pairing and tests all edge
deletions. Replay uses independently completed marginal monomials, a
separate role classifier, explicit cycle orders and port flips. Compare
the complete canonical witness sets, zero complements/classifications,
g/Y/jet budgets, both probe labels and action-profile counts. Independent
algorithms share catalog, free-edge power counting, conventions/software/
AI author; their agreement is not independent physics validation.

Controls remove PS/SP, BL/LB, PPx, scalar current or nonlinear rho*aBB,
and report actual sensitive/insensitive effects. No amplitude, source-flow
or counterterm target is supplied to either worker. The result chooses a
complete calculational class, not a cancellation or full QAP claim.

Freeze source copies, native inputs and historical hashes before sequential
primary/replay/verifier. Each120s after imports,8GiB sampled private,
350MiB available-commit launch floor,whole packet8MiB. Stop first failure;
preserve full stdout/stderr/all samples and sources. Resource exhaustion
stays incomplete, no truncation or silent cap expansion. No new physical
scheme/foundation/benchmark, canonical action or authority change. No agents,
branch/worktree,push,publication/outreach,flavor/HB1/C5 activation. Full finite
products, chiral measure/global phase, physical matching and E5/A5 stay open.
