from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import gzip,json,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
tick=time.perf_counter();t=threading.Timer(300,lambda:os._exit(124));t.daemon=True;t.start()
for p,h in read(O/'construction_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
receipt=read(O/'quantum_validation_receipt_v3.json');assert receipt['full_parts_operators_maps_and_zero_complements_agree'] and receipt['all12_H_mass_operator_commutators_zero']
xi,eta=s.symbols('xi eta_H',real=True);loc={'xi':xi,'eta_H':eta};dec=lambda d:s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z,locals=loc) for i,j,z in d['entries']});tidy=lambda M:s.SparseMatrix(M).applyfunc(s.expand)
def zero(M):assert not tidy(M).todok()
def enc(M):return {'shape':list(M.shape),'entries':[[i,j,str(s.expand(v))] for (i,j),v in sorted(s.SparseMatrix(M).todok().items()) if s.expand(v)!=0]}
def kron(A,B):return s.SparseMatrix(A.rows*B.rows,A.cols*B.cols,{(i*B.rows+k,j*B.cols+l):x*y for (i,j),x in s.SparseMatrix(A).todok().items() for (k,l),y in s.SparseMatrix(B).todok().items()})
d=load(O/'quantum_primary_inputs.json.gz');RB=dec(d['RB']);Tp=list(map(dec,d['Tminus']));T=[tidy(sum((RB[k,a]*Tp[k] for k in range(45) if RB[k,a]),s.zeros(16))) for a in range(45)];I=s.eye(16)
q=load(O/'quantum_primary_v3_tables.json.gz');old=load(O/'quantum_primary_v2_tables.json.gz');oldops=[];newops=[];K=[];comp=[];checks=[]
Swap=s.SparseMatrix(256,256,{(16*j+i,16*i+j):1 for i in range(16) for j in range(16)})
for r in range(2):
 sector=range(12) if r==0 else range(12,45);w=[eta,xi][r]
 C=tidy(sum((T[a]*T[a] for a in sector),s.zeros(16)));J=tidy(sum((kron(T[a].T,T[a].T) for a in sector),s.zeros(256)))
 compact=tidy(w**2*(J/12+(kron(C.T,I)+kron(I,C.T))/8));R=dec(q['operators'][r]['total']);zero(compact-R)
 kk=-compact;zero(R+kk);zero(Swap*kk-kk*Swap);K.append(enc(kk));newops.append(R/w**2);oldops.append(dec(old['operators'][r]['total'])/w**2)
 desc=[]
 for c,Tc in enumerate(T):
  A=s.I*(kron(Tc.T,I)+kron(I,Tc.T));D=tidy(A*kk-kk*A)
  # Independent four-index composition, evaluated on EVERY operator entry.
  arows=defaultdict(list);acols=defaultdict(list)
  for (i,j),v in A.todok().items():arows[j].append((i,v));acols[i].append((j,v))
  events=defaultdict(lambda:s.S.Zero)
  for (i,j),v in kk.todok().items():
   for h,z in arows[i]:events[h,j]+=z*v
   for h,z in acols[j]:events[i,h]-=v*z
  EE=tidy(s.SparseMatrix(256,256,events));zero(D-EE)
  raw=(json.dumps(enc(D),sort_keys=True,separators=(',',':'))+'\n').encode();desc.append({'color':c,'nonzero_positions':len(D.todok()),'full_operator_sha256':sha256(raw).hexdigest()})
  if c<12:zero(D)
 comp.append(desc);checks.append({'compact_operator_matches_full_measured_input':True,'K_nonzero_positions':len(kk.todok()),'reversed_sign_remainder_positions':len(R.todok()),'extra_half_remainder_positions':len(R.todok()),'five_prior_scalar_zero_images':'ZERO_BY_MONOMIAL_SUPPORT'})
 print('STAGE CONSTRUCTED_RHO_SCALAR_PRIMITIVE_AND_ALL45_COMPANIONS',r,flush=True)
# A generic two-odd-coordinate alternating density. Its 1/2 occurs once:
# (theta0*m*theta1 + theta1*(-m)*theta0)/2 = m*theta0*theta1.
m=s.Symbol('m');direct=s.expand((m+(-1)*(-m))/2);assert direct==m and s.diff(s.Symbol('u')*direct,s.Symbol('u'))==m
zero(newops[0]+newops[1]-oldops[0]-oldops[1])
diag=[len(tidy(newops[r]-oldops[r]).todok()) for r in range(2)]
out={'schema':'RHO_SCALAR_PRIMITIVE_V1','K_mass_operators_without_outer_g10_squared':K,'complete_uC_scalar_program':'g10^3*u_r*C_c*[A_c,K_r](M); K_r=-R_r','all45_companion_hashes':comp,'checks':checks,'compact_kernel':'w_r^2*(J_r(M)/12+(C_r.T*M+M*C_r)/8)','symmetric_carrier_preserved':True,'alternating_half_and_odd_left_u_derivative_pass':True,'failed_V2_equal_width_diagnostic':{'equal_width_sum_difference_positions':0,'separate_probe_operator_difference_positions':diag,'old_V2_physics_qualified':False},'new_quantum_coefficients_measured':False,'mixed_uC_scalar_quantum_match_established':False,'unique_counterterm_or_physical_scheme_claimed':False,'full_QAP_or_authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True)
