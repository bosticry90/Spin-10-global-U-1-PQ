from pathlib import Path
from hashlib import sha256
import ast,gzip,json,subprocess
O=Path(__file__).resolve().parent;R=O.parents[1];H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));b={}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='6374392a5b211c571f676bdbbd078e5b9e0012f3'
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V600.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:
 p=R/n;b[str(p)]=H(p)
rg=O.parent/'canonical_so10_rho_vector_support';pv=O.parent/'canonical_so10_probe_vector_response';hp=O.parent/'canonical_so10_first_probe_local_module'
for role in ['primary','replay']:
 rows=[]
 for folder,n,manifest,key in [(rg,'loop_'+role+'_inputs.json.gz',rg/'loop_preparation_v2.json','native_input_sha256'),(pv,role+'_inputs.json.gz',pv/'preparation.json','input_sha256'),(hp,'endpoint_'+role+'_inputs.json.gz',hp/'endpoint_preparation.json','input_sha256')]:
  p=folder/n;assert H(p)==read(manifest)[key][str(p)],p;b[str(p)]=H(p);b[str(manifest)]=H(manifest);rows.append(load(p))
 dst=O/(role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps({'rho':rows[0],'probe':rows[1],'endpoint':rows[2]},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 b[str(dst)]=H(dst)
for folder,ns in [(rg,['native_v3.py','loop_v2.py','validation_receipt_v3.json','loop_validation_receipt_v2.json']), (pv,['RECORD.md','RESULT.md','validation_receipt.json','loop_validation_receipt_v2.json','review_receipt.json']), (hp,['validation_receipt.json','endpoint_validation_receipt.json'])]:
 for n in ns:
  p=folder/n;b[str(p)]=H(p)
for n in ['RECORD.md','prepare.py','native.py','verify.py','run.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
with(O/'preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'seconds_after_imports':180,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'whole_packet_cap':12*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_RPV1',len(b),flush=True)
