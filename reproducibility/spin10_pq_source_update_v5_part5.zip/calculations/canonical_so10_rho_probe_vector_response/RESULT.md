# The mixed rho/vector ending is independent of the even probes

PROGRESS,2026-10-25,base6374392a/main. RPV1 primary,replay and verification
completed. The two actual rho insertions acquire no positive even-probe
coefficient in the complete tested one-vector principal ending. The resulting
mixed local chiral coefficients are zero in the inherited bare UV reference.
This closes V600's next dependency without fitting a correction.

Scope is constant external rho,u,B,all2rho/2u labels,45vector and45internal
boson/antighost directions,both chiralities,original unshifted SMA and symbolic
polynomial g10,xi,eta_H. No new physical parameter point or finite normalization
is chosen. This is not a finite massive amplitude or renormalized product.

The actual RGS rho aB/aL Hessians are reconstructed, not assigned from a
required cancellation. They match HP's currents, and all Gr*Jrho products
vanish. E_rho=Gminus*Jrho is therefore independent of u. RGS rho0 has no
aBB contact; rho1 has668 entries. Those contacts are retained alongside
all PUV old/probe BBB,LambdaBB and mixed inverse placements. Independent
extractors' old auxiliary and Lie tensors agree before use.

The full response is Gminus*Jrho_B-Gminus*K_B*E_rho. Actual probe AC=0,
constant E_rho and the Yang-Mills double-longitudinal identity exclude
positive-u ghost,physical fermion-leg and physicalYM contributions. Their
ordinary rho contributions are not set zero. The remaining polynomial has
maximum even-probe degree2; no infinite series has been numerically cut off.

Sparse block convolution and independently associated component contractions
agree over1,822,500 longitudinal and911,250 transverse total coefficient
positions,including their zero complements. All positive-u totals vanish.
The two scalar-free Lorentz tensors are reconstructed without aDtrace.
All relevant auxiliary outputs and both ordinary-vector orientations remain.

The qualified RGS/UCB linear chiral sewing uses I0=-1/2,J=-1/12 in common
1/(16pi^2) units. Ordered generator products and independent i*f*T reduction
agree in all230,400 declared local positions,both chiralities. Every total0.
This is a structural local-reference consequence,not a newly integrated finite
amplitude or independent physical prediction. The old fixed candidate needs
no additional term in this projection. Full chiral restoration does not follow.

Sensitive omissions change the following represented positions:

| Omission | Longitudinal ending | Local quantum coefficient |
|---|---:|---:|
| rho contact |1336|1130|
| BBB |4008|4052|
| BL |3340|3156|
| LB |2672|2260|

Transverse BBB/BL omissions each change668 positions. Omitting rho Lambda
currents breaks90 endpoint-null positions. Flipping the mixed signs of the
left inverse changes2672 higher response positions. I0->4J is INSENSITIVE
here because the total cancels before moment application; it is not fresh
validation of the inherited full-D moments. Counts describe algebraic slots,
not particles,experiments or fractions of E5 completion.

Sources/input types,caps and failure conditions were frozen in RECORD.md.
Primary23.6374474s,replay12.0410430s,verifier.0719895s after imports. Samples
13/7/1,private maxima136183808/127922176/393216B; not continuous peak bounds.
The180s/8GiB-sampled/350MiB-floor/12MiB limits held. No worker/preparer or
verifier failed. Five exact source copies,40 preparation/48 validation bindings.
Packet~1.23MB before this report. Receipt SHA256:
0b573234c80744d399a30a671555956d2475304b13549f263119f63cf35a002f.

Current E4 completed native0 with expected[0,0,0,0,0,2]. Custody remains
exit2/sevenNOTPASS; historical authentication is not new scientific replay
or director acceptance. Captures and before/index/postcommit seals are at
C:/Users/psboy/.codex/research-control-records/ToE-Next/rho-probe-vector-response-v1-2026-10-25/.
Keep all35421 preexisting tracked blobs and new raw/index/HEAD bytes identical.

The completed result justified the next actual calculation, HPA1/2 in
canonical_so10_higher_probe_local_audit. That audit tests finite-transfer
jets,complete untruncated source kernels and higher carrier sufficiency,
rather than extrapolating this vector-only zero to every local operator.
Full finite products,QAP,measure/global phase,physical limits,E5/A5 and
the Spin(10)xPQ investigation remain incomplete. State113/34of39 unchanged;
no flavor/HB1/C5 activation,scheme/benchmark/foundation adoption or remote
action. Shared action,reference,frames,software and AI authorship limit
independence; no external physical validation is claimed.
