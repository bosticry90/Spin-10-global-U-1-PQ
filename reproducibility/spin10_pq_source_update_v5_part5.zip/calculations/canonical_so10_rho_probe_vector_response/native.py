from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('replay' if role=='primary' else'primary'):raise PermissionError('RPV_PEER_DENIED')
  if any(x in p.parts for x in ['canonical_so10_even_probe_vertices','canonical_so10_probe_fermion_onejet','canonical_so10_probe_scalar_support']):raise PermissionError('RPV_COUNTERTERM_DENIED')
sys.addaudithook(guard)
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.sympify(z,locals=loc)
dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v) for i,j,v in z['entries']});tidy=lambda M:s.SparseMatrix(M).applyfunc(s.expand)
def enc(M):return {'shape':list(M.shape),'entries':[[int(i),int(j),str(v)] for(i,j),v in sorted(tidy(M).todok().items()) if v]}
def expr(p):
 out=0
 for power,w,cid in p['monomials']:
  assert not w
  for xp,hp,mask,n,den in p['coefficients'][cid]:
   z=s.Rational(n,den)*g**power*xi**xp*eta**hp
   for j,q in enumerate([2,3,5,7]):
    if mask&(1<<j):z*=s.sqrt(q)
   if mask&16:z*=s.I
   out+=z
 return s.expand(out)
tab=lambda rows:{tuple(z[:-1]):expr(z[-1]) for z in rows}
def mm(A,B):
 if role=='primary':return tidy(A*B)
 rr=defaultdict(list);out=defaultdict(list)
 for(k,j),v in B.todok().items():rr[k].append((j,v))
 for(i,k),v in A.todok().items():
  for j,z in rr[k]:out[i,j].append(v*z)
 return tidy(s.SparseMatrix(A.rows,B.cols,{k:s.Add(*vals) for k,vals in out.items()}))
zero=lambda M:not tidy(M).todok()
d=json.loads(gzip.decompress((O/(role+'_inputs.json.gz')).read_bytes()));rd,pd,ep=d['rho'],d['probe'],d['endpoint'];rv=rd['vertices'];pv=pd['vertices'];qb=[{k:tab(rows) for k,rows in z.items()} for z in rv['probe_quadratics']];contacts=list(map(tab,rv['rho_aBB']));aux=[tab(z['auxiliary']) for z in pv];abc=[{k:tab(rows) for k,rows in z['BBB'].items()} for z in pv];curr=[{k:tab(rows) for k,rows in z['current'].items()} for z in pv]
assert tab(rv['GF_auxiliary'])==aux[0] and tab(rv['physical_f'])==tab(pd['physical_f']);assert not curr[1]['AC'] and not curr[2]['AC'] and curr[0]['AC']
P=[s.diag(*[int((i<12)==(r==0)) for i in range(45)]) for r in range(2)];W=s.diag(*([eta]*12+[xi]*33));I=s.eye(45);Z=s.zeros(45);weights=[eta,xi];pows=[(0,0),(1,0),(0,1)];powers=[(1,0),(0,1),(2,0),(1,1),(0,2)]
GG={(0,0):s.SparseMatrix.vstack(s.SparseMatrix.hstack(W,I),s.SparseMatrix.hstack(-I,Z))};WP={(0,0):W};MP={(0,0):s.SparseMatrix(I)};LL={(0,0):s.SparseMatrix(Z)}
assert zero(GG[0,0]-dec(ep['G0']).T)
for r,w in enumerate(weights):
 p=pows[r+1];WP[p]=w*w*P[r]/2;MP[p]=w*P[r];LL[p]=-2*P[r];GG[p]=s.SparseMatrix.vstack(s.SparseMatrix.hstack(WP[p],MP[p]),s.SparseMatrix.hstack(-MP[p],LL[p]));assert zero(GG[p]-dec(ep['probe_quadratics'][r]['Gr']).T)
def add(A,B):
 out=dict(A)
 for p,M in B.items():out[p]=tidy(out.get(p,s.zeros(*M.shape))+M)
 return out
def mul(A,B):
 out={}
 for p,A0 in A.items():
  for q,B0 in B.items():
   k=(p[0]+q[0],p[1]+q[1]);N=mm(A0,B0);out[k]=tidy(out.get(k,s.zeros(*N.shape))+N)
 return out
neg=lambda A:{p:-M for p,M in A.items()};stack=lambda A,B:A.col_join(B)
def restrict(A,shape):return {str(p[0])+','+str(p[1]):enc(A.get(p,s.zeros(*shape))) for p in powers}
Jr=[];Er=[];badH=0
for r in range(2):
 Jb=s.SparseMatrix(45,45,{(b,a):v for(a,b),v in qb[r]['aB'].items()});Jl=s.SparseMatrix(45,45,{(b,a):v for(a,b),v in qb[r]['aL'].items()});JJ=stack(Jb,Jl);assert zero(JJ-dec(ep['rho'][r]['J']).T);Jr.append(JJ)
 E=mm(GG[0,0],JJ) if role=='primary' else stack(tidy(mm(W,Jb)+Jl),-Jb)
 for p in pows[1:]:assert zero(mm(GG[p],JJ));badH+=len(mm(GG[p],stack(Jb,s.zeros(45))).todok())
 Er.append(E)
fr=pd['frame'];assert fr==rd['frame'] and pd['Tminus']==rd['Tminus'];Ti=dec(fr['physical_to_raw_inverse']);Q=dec(fr['Q']);order=fr['field_order'];phys=[f'B{i}_{mu}' for i in range(45) for mu in range(4)]+[f'x_{ss}_{i}' for ss,nn in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(nn)]+[('b'+str(i) if i<12 else'L'+str(i)) for i in range(45)]+['C'+str(i) for i in range(45)]+[('bar'+str(i) if i<12 else'ub'+str(i)) for i in range(45)]
RB=tidy(Q*Ti.extract([order.index(f'B{i}_0') for i in range(45)],[phys.index(f'B{i}_0') for i in range(45)]));TP=list(map(dec,pd['Tminus']));T=[tidy(sum((RB[k,a]*TP[k] for k in range(45) if RB[k,a]),s.zeros(16))) for a in range(45)];fc=defaultdict(list)
for(b,a,c),f in tab(pd['physical_f']).items():fc[b,a].append((c,f))
for b in range(45):
 for a in range(45):assert zero(T[b]*T[a]-T[a]*T[b]-s.I*sum((f*T[e] for e,f in fc[b,a]),s.zeros(16)))
eps,h=s.symbols('epsilon h');finite=lambda z:s.simplify(s.diff(z.subs(h,-2*eps),eps).subs(eps,0));I0=finite(h*s.gamma(1+eps)/4) if role=='primary' else finite(h*s.gamma(1+eps)/(2*s.gamma(3)));J=finite(h*s.gamma(1+eps)/24) if role=='primary' else finite(h*s.gamma(1+eps)/(4*s.gamma(4)));assert I0==-s.Rational(1,2) and J==-s.Rational(1,12)
def kd(tab0,d0):return s.SparseMatrix(45,45,{(i,j):v for(i,j,k),v in tab0.items() if k==d0})
commcache={}
def sew(M,tt,right):
 if role=='primary':
  out=s.zeros(16)
  for(b,a),val in M.todok().items():
   if(right,b,a) not in commcache:commcache[right,b,a]=tidy(tt[b]*tt[a]-tt[a]*tt[b])
   out+=g*g*val*commcache[right,b,a]
  return tidy(out)
 co=defaultdict(list)
 for(b,a),val in M.todok().items():
  for e,f in fc[b,a]:co[e].append(s.I*g*g*val*f)
 return tidy(sum((s.expand(s.Add(*vals))*tt[e] for e,vals in co.items()),s.zeros(16)))
outputs=[];controls=defaultdict(int);controls['omit_rho_Lambda_endpoint_null_positions']=badH
for r in range(2):
 E={(0,0):Er[r]};EB={(0,0):Er[r][:45,:]};EL={(0,0):Er[r][45:,:]}
 for d0 in range(45):
  S0=s.SparseMatrix(45,45,{(b,a):v for(a,b,k),v in contacts[r].items() if k==d0});SS={(0,0):S0};AA={p:kd(aux[t],d0) for t,p in enumerate(pows)};AT={p:M.T for p,M in AA.items()};BB={p:sum((kd(abc[t][k],d0) for k in ['A','B','C']),s.zeros(45)) for t,p in enumerate(pows)};CC={p:kd(abc[t]['C'],d0) for t,p in enumerate(pows)}
  if role=='primary':
   KBBB={p:s.SparseMatrix.vstack(s.SparseMatrix.hstack(M,Z),s.SparseMatrix.hstack(Z,Z)) for p,M in BB.items()};KBL={p:s.SparseMatrix.vstack(s.SparseMatrix.hstack(Z,M.T),s.SparseMatrix.hstack(Z,Z)) for p,M in AA.items()};KLB={p:s.SparseMatrix.vstack(s.SparseMatrix.hstack(Z,Z),s.SparseMatrix.hstack(M,Z)) for p,M in AA.items()}
   lp={'contact':mul(GG,{(0,0):stack(S0,s.zeros(45))}),'BBB':neg(mul(GG,mul(KBBB,E))),'BL':neg(mul(GG,mul(KBL,E))),'LB':neg(mul(GG,mul(KLB,E)))}
  else:
   lo=neg(mul(MP,SS));up=mul(WP,SS);lp={'contact':{p:stack(up.get(p,s.zeros(45)),lo.get(p,s.zeros(45))) for p in set(up)|set(lo)}}
   for name,A in [('BBB',mul(BB,EB)),('BL',mul(AT,EL))]:
    up=neg(mul(WP,A));lo=mul(MP,A);lp[name]={p:stack(up.get(p,s.zeros(45)),lo.get(p,s.zeros(45))) for p in set(up)|set(lo)}
   A=mul(AA,EB);up=neg(mul(MP,A));lo=neg(mul(LL,A));lp['LB']={p:stack(up.get(p,s.zeros(45)),lo.get(p,s.zeros(45))) for p in set(up)|set(lo)}
  tp={'contact':SS,'BBB':neg(mul(CC,EB)),'BL':neg(mul(AT,EL)),'LB':{(0,0):s.zeros(45)}};lt={};tr={}
  for A in lp.values():lt=add(lt,A)
  for A in tp.values():tr=add(tr,A)
  for name,A in lp.items():
   for p,M in A.items():
    if sum(p):controls['omit_long_'+name]+=len(M.todok())
  for name,A in tp.items():
   for p,M in A.items():
    if sum(p):controls['omit_trans_'+name]+=len(M.todok())
  bad={}
  for p in powers:
   U=lt.get(p,s.zeros(90,45));LB=lp['LB'].get(p,s.zeros(90,45));delta=stack(-2*LB[:45,:],tidy(-2*U[45:,:]+2*LB[45:,:]));bad[p]=delta;controls['wrong_left_mixed_sign_response_difference']+=len(delta.todok())
  quant=[]
  for right,tt in [(False,T),(True,[-t.T for t in T])]:
   for p in powers:
    qi={};qj={};qp={}
    for name in lp:
     A=tp[name].get(p,s.zeros(45));L0=lp[name].get(p,s.zeros(90,45))[:45,:];qi[name]=sew(A,tt,right);qj[name]=sew(tidy(L0-A),tt,right);qp[name]=tidy(I0*qi[name]+J*qj[name])
    it=tidy(sum(qi.values(),s.zeros(16)));jt=tidy(sum(qj.values(),s.zeros(16)));total=tidy(I0*it+J*jt);badmom=tidy(4*J*it+J*jt);controls['I0_to_4J_quantum_difference']+=len(tidy(badmom-total).todok())
    for name,M in qp.items():controls['omit_quantum_'+name]+=len(M.todok())
    quant.append({'right':right,'power':list(p),'I':enc(it),'J':enc(jt),'total':enc(total),'parts':{k:enc(M) for k,M in qp.items()},'I0_to_4J_control':enc(badmom)})
  outputs.append({'rho':r,'B_external':d0,'long_parts':{k:restrict(A,(90,45)) for k,A in lp.items()},'trans_parts':{k:restrict(A,(45,45)) for k,A in tp.items()},'long_total':restrict(lt,(90,45)),'trans_total':restrict(tr,(45,45)),'wrong_left_mixed_sign_difference':restrict(bad,(90,45)),'quantum':quant})
 print('STAGE '+role+' rho'+str(r)+' all vectors complete',flush=True)
# Noncommuting tensor/sign reconstruction, valid without a D trace.
WW,MM,LL0,A0,B0,C0,KK,KT,DD,EE,SS0,XX,YY=s.symbols('W M LL A B C K KT D E S X Y',commutative=False);trans=SS0-s.I*C0*DD-s.I*KT*EE;rad=(WW-1)*SS0-s.I*((A0+B0)+(WW-1)*(A0+B0+C0))*DD-s.I*(WW-1)*KT*EE-s.I*MM*KK*DD;parallel=WW*SS0-s.I*WW*(A0+B0+C0)*DD-s.I*WW*KT*EE-s.I*MM*KK*DD;assert s.expand(trans+rad-parallel)==0
G=s.Matrix([[WW,MM],[-MM,LL0]]);Gbad=s.Matrix([[WW,-MM],[MM,LL0]]);xx=s.Matrix([XX,YY]);R=G*xx;lb=G*s.Matrix([0,YY]);assert all(s.expand(v)==0 for v in (Gbad-G)*xx-s.Matrix([-2*lb[0],-2*R[1]+2*lb[1]]))
out={'schema':'RHO_EVEN_PROBE_VECTOR_RESPONSE_V1','role':role,'RB':enc(RB),'current_from_actual_rho_quadratics_matches_HP':True,'rho_ending_independent_of_even_probes_checked':True,'old_rho_probe_GF_auxiliary_and_Lie_tensors_match':True,'actual_probe_AC_zero_old_AC_nonzero':True,'noncommuting_tensor_and_mixed_sign_proofs_pass':True,'I0':str(I0),'J':str(J),'outputs':outputs,'controls':dict(controls),'counterterm_target_read_or_fitted':False,'new_finite_product_or_QAP_or_authority':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True);timer.cancel()
