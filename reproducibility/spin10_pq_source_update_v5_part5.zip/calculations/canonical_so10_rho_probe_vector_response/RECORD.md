# RPV1: mixed rho/even-probe one-vector response

Frozen before computation,2026-10-25,base6374392a/main. Question: does the
actual rho insertion's one-vector principal ending acquire positive powers
of either even probe, and what is the corresponding local chiral UV result?
This resolves the next dependency left by V600 without presuming that the
pure even-probe zero also holds for rho. No counterterm target is an input.

Domain: original unshifted SMA; constant external rho,u,B; all two rho labels,
two independent even probes,45 externalB and45 internal boson/antighostcolors,
both chiralities, exact polynomial g10/xi/eta_H. This is the mass-independent
nonexceptional Euclidean bare-local reference, not a finite physical amplitude,
new coincident product, full source module or all transfer-momentum result.
No externalC in this projection. Keep transverse/longitudinal/auxiliary fields,
all mixed inverse placements and actual Grassmann/source orientations.

Use RGS actual rho aB/aL quadratics and rho_aBB contacts, PUV old/probe
BBB/LambdaBB and measured AC currents, HP1 actual endpoint tables. Rebuild
Jrho from measured aB/aL and match HP1; reconstruct opposite-momentum Gminus
and match G0^T/Gr^T. Check every Gr*Jrho=0 before using E_rho=Gminus*Jrho
independent of u. Check RGS/PUV old auxiliary/Lie tensors agree; no universal
old V substitution. RGS rho0 contact is empty; rho1 has668 actual entries.
Neither absence nor nonzero support is a quantum conclusion by itself.

Evaluate the full ordered boson response
 Gminus(u)*Jrho_B-Gminus(u)*K_B(u)*E_rho.
Jrho_B is the ACTUAL rho_aBB vertex, not a required cancellation chosen
afterward. Old ghost inverse and physical fermion B-leg responses multiply
E_rho and hence have no positive u coefficient; actual probe AC=0 excludes
an additional ghost response. PhysicalYM has zero double-longitudinal but
nonzero single contraction. Since E_rho is constant and the transverse
left inverse has no probe response, its positive-u response is0. These are
positive-u exclusions, not omission of their ordinary rho amplitudes.

Primary: sparse90x90 block polynomial multiplication. Replay: independent
component contractions/association in parallel/transverse channels. Retain
all degree1/2 monomials; higher degrees are excluded by the affine inverse,
affine cubic and constant E_rho, not truncated from an infinite sum. Recover
the delta_mu,r/kk tensor without a four-dimensional metric trace, within the
inherited bosonic Lorentz continuation. Compare full arrays and implicit zeros.

Then sew ordinary B output A delta+B kk/k2 into the qualified RGS/UCB raw
PS/SP chiral insertion reference: g10^2*(I0 A+J B)[Tb,Ta] in common1/(16pi^2)
units,I0=-1/2,J=-1/12,not I0=4J. Primary uses ordered16x16 commutators;
replay uses i f_bae T_e before matrix assembly. Reconstruct both actual
RB-column frames, verify Lie identities and use -T^T for the right sector.
Keep every coupling power. No unknown quantum coefficient or desired
counterterm cancellation is loaded. Distinguish structural local consequences
of a pointwise zero from independently evaluated new finite loop integrals.

Controls omit rho contact,BBB,BL/LB placements or rho Lambda current; flip
both mixed signs in the left inverse and change I0 to4J. Record actual
sensitive AND insensitive controls. A nonzero total is a valid remainder,
not automatic anomaly/failure and not permission to retune the old candidate.
Input hash mismatch, inconsistent qualified endpoint/frame/Lie identities or
route disagreement fails qualification. Freeze inputs/sources first.

Sequential primary/replay/verifier each180s after imports,8GiB sampled private,
350MiB launch floor,whole packet12MiB. Exhaustion INCOMPLETE; no cap widening,
hidden truncation, source overwrite or failure relabeling. Independent current
E4 authentication may run read-only with captures only in its external control
folder; it consumes no worker outputs and cannot qualify these calculations.

Authority ceiling: bounded mixed principal/local chiral projection only.
No full higher-probe module, jet completion, renormalized products,QAP/measure/
phase, physical vacuum/massive matching or E5/A5 promotion. State113/34of39,
custody2/sevenNOTPASS unchanged. Live AGENTS bound; no agents,branch/worktree,
push/outreach/publication,flavor/HB1/C5 activation,foundation/scheme/benchmark
adoption or protected evidence edits. Shared action,reference,software,frames
and AI author limit independence. This is not independent physical validation.
