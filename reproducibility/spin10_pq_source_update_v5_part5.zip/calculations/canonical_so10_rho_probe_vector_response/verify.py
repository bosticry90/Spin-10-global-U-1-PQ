from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import gzip,json,time
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[json.loads(gzip.decompress((O/(r+'_tables.json.gz')).read_bytes())) for r in ['primary','replay']];assert a['outputs']==b['outputs'] and a['controls']==b['controls'] and a['RB']==b['RB']
counts=defaultdict(int);positions=defaultdict(int);wit=[]
for z in a['outputs']:
 for name in ['long_total','trans_total']:
  for p,M in z[name].items():
   counts[name]+=len(M['entries']);positions[name]+=M['shape'][0]*M['shape'][1]
   if M['entries'] and len(wit)<6:wit.append({'rho':z['rho'],'B':z['B_external'],'type':name,'power':p,'first':M['entries'][0]})
 for zq in z['quantum']:
  M=zq['total'];counts['quantum_total']+=len(M['entries']);positions['quantum_total']+=M['shape'][0]*M['shape'][1]
  if M['entries'] and len(wit)<10:wit.append({'rho':z['rho'],'B':z['B_external'],'type':'quantum','power':zq['power'],'right':zq['right'],'first':M['entries'][0]})
assert a['controls']['omit_rho_Lambda_endpoint_null_positions']>0
out={'schema':'RPV1_VALIDATION_RECEIPT','elapsed_after_imports':time.perf_counter()-tick,'full_operator_and_both_chiral_quantum_routes_agree':True,'implicit_total_positions_compared':dict(positions),'nonzero_total_positions':dict(counts),'mixed_rho_vector_ending_independent_of_even_probes':counts['long_total']==counts['trans_total']==0,'positive_even_probe_rho_vector_local_quantum_coefficients_zero':counts['quantum_total']==0,'controls':a['controls'],'witnesses':wit,'operator_local_reference_consequence_not_new_finite_loop':True,'new_counterterm_fitted':False,'full_higher_probe_module_jets_QAP_or_authority_qualified':False,'primary_packed_sha256':H(O/'primary_tables.json.gz'),'replay_packed_sha256':H(O/'replay_tables.json.gz')}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
