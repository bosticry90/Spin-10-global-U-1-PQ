from pathlib import Path
from hashlib import sha256
import ast,json,gzip
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
old=read(O/'preparation_v2.json')
for p,h in read(O/'validation_preparation_v2.json')['input_sha256'].items():assert H(Path(p))==h,p
assert read(O/'controller_failure_v2.json')['stage']=='verify_v2' and read(O/'verify_v2_capture.json')['exit_code']==1
P,Z=[json.loads(gzip.decompress((O/(role+'_v2_tables.json.gz')).read_bytes())) for role in ['primary','replay']]
for key in ['probe_quadratics','rho_aBB','GF_auxiliary','GF_ghost_B','GF_other_marginal_cubics','complete_marginal_G','physical_f']:assert P[key]==Z[key],key
for n in ['CORRECTION_V3.md','generate_v3.py','native_v3.py','verify_v3.py','prepare_v3.py','run_v3.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
b=dict(read(O/'validation_preparation_v2.json')['input_sha256'])
for p in O.iterdir():
 if p.is_file():b[str(p)]=H(p)
nb={p:h for p,h in old['native_input_sha256'].items() if Path(p).name!='native_v2.py'};nb[str(O/'native_v3.py')]=H(O/'native_v3.py')
with(O/'preparation_v3.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'native_input_sha256':nb,'limits':old['limits'],'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,separators=(',',':'))+'\n').encode())
print('PREPARED_RGS_V3',len(b))
