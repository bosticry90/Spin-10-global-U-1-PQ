from pathlib import Path
import ast
O=Path(__file__).resolve().parent
n=(O/'native.py').read_text(encoding='utf-8')
n=n.replace("O/'preparation.json'","O/'preparation_v2.json'").replace("role+'_tables.json.gz'","role+'_v2_tables.json.gz'").replace("'replay_tables.json.gz' if role=='primary' else 'primary_tables.json.gz'","'replay_v2_tables.json.gz' if role=='primary' else 'primary_v2_tables.json.gz'")
old=" def mpblock(names,L):return (L*Ti.extract([ix[n] for n in names],[ix[n] for n in names])).applyfunc(s.expand)"
new=" phys=[f'B{i}_{mu}' for i in range(45) for mu in range(4)]+[f'x_{ss}_{i}' for ss,nn in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(nn)]+[A.names[k] for k in ln+cn+an]\n assert len(phys)==643 and set(phys)==set(order);pix={n:i for i,n in enumerate(phys)}\n def mpblock(names,L):return (L*Ti.extract([ix[n] for n in names],[pix[n] for n in names])).applyfunc(s.expand)"
assert n.count(old)==1;n=n.replace(old,new)
old=" assert zero(RB-RC) and zero(RB*RB.T-s.eye(45)) and zero(RC*RA.T-s.eye(45)) and zero(RB*RL.T-s.eye(45))"
assert n.count(old)==1;n=n.replace(old,old+"\n for mu in range(1,4):assert zero(mpblock([f'B{i}_{mu}' for i in range(45)],Q)-RB)")
assert n.count('order[j]')==2;n=n.replace('order[j]','phys[j]')
v=(O/'verify.py').read_text(encoding='utf-8').replace("O/'validation_preparation.json'","O/'validation_preparation_v2.json'").replace("O/'primary_tables.json.gz'","O/'primary_v2_tables.json.gz'").replace("O/'replay_tables.json.gz'","O/'replay_v2_tables.json.gz'")
needle="block=lambda ns,L:(L*Ti.extract([ix[n] for n in ns],[ix[n] for n in ns])).applyfunc(s.expand)"
replacement="phys=[f'B{i}_{mu}' for i in range(45) for mu in range(4)]+[f'x_{ss}_{i}' for ss,nn in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(nn)]+[('b'+str(i) if i<12 else'L'+str(i)) for i in range(45)]+['C'+str(i) for i in range(45)]+[('bar'+str(i) if i<12 else'ub'+str(i)) for i in range(45)]\nassert len(phys)==643 and set(phys)==set(ix);pix={n:i for i,n in enumerate(phys)}\nblock=lambda ns,L:(L*Ti.extract([ix[n] for n in ns],[pix[n] for n in ns])).applyfunc(s.expand)"
assert v.count(needle)==1;v=v.replace(needle,replacement)
for name,t in [('native_v2.py',n),('verify_v2.py',v)]:
 ast.parse(t)
 with(O/name).open('x',encoding='utf-8',newline='\n') as f:f.write(t)
print('GENERATED_RGS_V2_DISTINCT_RAW_AND_PHYSICAL_AXES')
