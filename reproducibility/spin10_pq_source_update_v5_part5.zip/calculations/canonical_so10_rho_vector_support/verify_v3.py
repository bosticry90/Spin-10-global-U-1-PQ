from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict,Counter
import gzip,json,time,threading,os,sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'validation_preparation_v3.json')['input_sha256'].items():assert H(Path(p))==h,p
P=load(O/'primary_v3_tables.json.gz');Z=load(O/'replay_v3_tables.json.gz')
for key in ['names','parities','probe_quadratics','rho_aBB','GF_auxiliary','GF_ghost_B','GF_other_marginal_cubics','G_inventory','complete_marginal_G','physical_f','profiles','controls']:assert P[key]==Z[key],key
for d in [P,Z]:
 assert all(d[k] for k in ['all_Lorentz_components_checked','paired_E_C_E_S_roles_preserved','E_P_external_hat_derivative_zero_only','pure_vector_action_operator_authenticated_reuse','no_quantum_coefficients_or_counterterm_comparison']) and not d['authority_changed']
print('STAGE RGS literal_vs_Euler_and_cycle_vs_edge_insertion_agree',flush=True)
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.sympify(z,locals=loc)
dec=lambda d:s.SparseMatrix(*d['shape'],{(i,j):parse(z) for i,j,z in d['entries']})
def zero(M):assert not s.SparseMatrix(M).applyfunc(s.expand).todok()
def expr(p):
 out=0
 for power,w,cid in p['monomials']:
  assert not w
  for xp,hp,mask,n,d in p['coefficients'][cid]:
   v=s.Rational(n,d)*g**power*xi**xp*eta**hp
   for k,q in enumerate([2,3,5,7]):
    if mask&(1<<k):v*=s.sqrt(q)
   if mask&16:v*=s.I
   out+=v
 return s.expand(out)
tables=lambda rows:{tuple(row[:-1]):expr(row[-1]) for row in rows}
# Only after full native agreement: compare previously derived classical limits.
inp=load(O/'primary_inputs.json.gz');fr=inp['frame'];Ti=dec(fr['physical_to_raw_inverse']);Q=dec(fr['Q']);Ad=dec(fr['Adual']);ix={n:i for i,n in enumerate(fr['field_order'])}
phys=[f'B{i}_{mu}' for i in range(45) for mu in range(4)]+[f'x_{ss}_{i}' for ss,nn in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(nn)]+[('b'+str(i) if i<12 else'L'+str(i)) for i in range(45)]+['C'+str(i) for i in range(45)]+[('bar'+str(i) if i<12 else'ub'+str(i)) for i in range(45)]
assert len(phys)==643 and set(phys)==set(ix);pix={n:i for i,n in enumerate(phys)}
block=lambda ns,L:(L*Ti.extract([ix[n] for n in ns],[pix[n] for n in ns])).applyfunc(s.expand)
RB=block([f'B{i}_0' for i in range(45)],Q);RC=block(['C'+str(i) for i in range(45)],Q);RA=block([('bar'+str(i) if i<12 else'ub'+str(i)) for i in range(45)],Ad);RL=block([('b'+str(i) if i<12 else'L'+str(i)) for i in range(45)],Ad)
for rr in range(2):
 old=load(O.parent/'canonical_so10_probe_fermion_onejet/primary_tables.json.gz')['V_A_H'][rr]
 # V_A_H packets are the action-derived vertices, not old quantum amplitudes.
 V=dec(old['V']).todok();HH=dec(old['H']).todok();vb=tables(P['probe_quadratics'][rr]['aB']);hb=tables(P['probe_quadratics'][rr]['aL'])
 for a in range(45):
  for b in range(45):assert s.expand(vb.get((a,b),0)+s.I*V.get((b,a),0))==0;assert s.expand(hb.get((a,b),0)-s.I*HH.get((b,a),0))==0
row=lambda M:{i:[(j,z) for(ii,j),z in M.todok().items() if ii==i] for i in range(45)}
rb,rc,ra,rl=map(row,[RB,RC,RA,RL])
def transport(old,first,second,third):
 out=defaultdict(lambda:s.S.Zero)
 for a,b,c,z in old:
  for i,x in first[a]:
   for j,y in second[b]:
    for k,w in third[c]:out[i,j,k]+=parse(z)*x*y*w
 return {key:s.expand(z) for key,z in out.items() if s.expand(z)!=0}
GTT=load(O.parent/'canonical_so10_ghost_triangle_field_insertion/primary_tables.json.gz')
expected=transport(GTT['plane_A'],rb,ra,rc);actual=tables(P['GF_ghost_B'])
assert set(expected)==set(actual)
for key,z in actual.items():assert s.expand(z+s.I*g*expected[key])==0,('GHOST_CLASSICAL_LIMIT',key)
FAV=load(O.parent/'canonical_so10_fermion_auxiliary_gauge_vertex/replay_tables.json.gz')
expected=transport(FAV['plane_U']['B'],rl,rb,rb);actual=tables(P['GF_auxiliary'])
assert set(expected)==set(actual)
for key,z in actual.items():assert s.expand(z+s.I*g*expected[key])==0,('AUXILIARY_CLASSICAL_LIMIT',key)
zz=s.Symbol('zz');witness=s.Matrix([[1,zz],[zz,2]]).inv();assert witness[0,1].subs(zz,0)==0 and s.diff(witness[0,1],zz).subs(zz,0)==-s.Rational(1,2)
families=[]
for profiles in P['profiles']:
 ct=Counter()
 for p in profiles:
  names=[v[0] for v in p];name=next((n for n in names if n.endswith('_edge')),'G_aBB');ct[name]+=1
 families.append(dict(sorted(ct.items())))
print('RESULT '+json.dumps({'schema':'RHO_VECTOR_SUPPORT_VALIDATION_V1','elapsed_after_imports':time.perf_counter()-tick,'full_literal_Euler_vertices_and_profile_sets_agree':True,'late_PFJ_GTT_FAV_classical_limits_match':True,'profile_counts':[len(v) for v in P['profiles']],'families':families,'rho_contact_color_entries':[len(v) for v in P['rho_aBB']],'GF_auxiliary_color_entries':len(P['GF_auxiliary']),'GF_ghost_B_color_entries':len(P['GF_ghost_B']),'controls':P['controls'],'actual_G_inventory':P['G_inventory'],'zero_free_component_nonzero_derivative_control':'-1/2','quantum_loop_or_counterterm_comparison_performed':False,'full_QAP_or_authority_changed':False,'shared_action_frames_software_AI_author':True},sort_keys=True),flush=True);timer.cancel()
