from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import Counter
import gzip,json,time,threading,os,sympy as s
O=Path(__file__).resolve().parent
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'loop_validation_preparation_v2.json')['input_sha256'].items():assert H(Path(p))==h,p
P=load(O/'loop_primary_v2_tables.json.gz');Z=load(O/'loop_replay_v2_tables.json.gz');g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.sympify(z,locals=loc)
dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v) for i,j,v in z['entries']})
clean=lambda M:s.SparseMatrix(M).applyfunc(s.expand)
enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(z)] for(i,j),z in sorted(clean(M).todok().items()) if z]}
def zero(M):assert not clean(M).todok()
def nz(M):return len(clean(M).todok())
for k in ['RB','I0','J','H4','units']:assert P[k]==Z[k],k
for obj in [P,Z]:assert obj['all_supported_families_exact_once'] and not obj['counterterm_target_read'] and obj['no_new_finite_QAP_or_physical_scheme'] and not obj['authority_changed']
compared=0;counts=[];controls=[];RB=dec(P['RB']);plane=[]
for r in range(2):
 cc=Counter();ctrl=Counter();pl={}
 for ch in ['left','right']:
  A=P['amplitudes'][r][ch];B=Z['amplitudes'][r][ch];zero(dec(A['D'])-dec(B['D']));zero(dec(A['V'])-dec(B['V']));rr=[]
  for a in range(45):
   M=dec(A['total'][a]);zero(M-dec(B['total'][a]));compared+=256;parts={n:dec(v[a]) for n,v in A['parts'].items()};zero(M-sum(parts.values(),s.zeros(16)))
   for n,V in parts.items():zero(V-dec(B['parts'][n][a]));compared+=256;cc[ch+'_'+n]+=nz(V)
   cc[ch+'_total']+=nz(M)
   for mon in [2,3,4]:cc[ch+'_g'+str(mon)]+=nz(M.applyfunc(lambda v:s.expand(v).coeff(g,mon)))
   if ch=='left':
    for n,V in parts.items():ctrl['omit_'+n]+=nz(V)
    ctrl['omit_L1_and_C_together']+=nz(parts['L1']+parts['C']);ctrl['omit_auxiliary_cubic']+=nz(parts['L1']+parts['L2']);ctrl['extra_half_or_family3']+=nz(M)
    for label,key in [('wrong_barred_YM','wrong_barred_YM'),('wrong_unweighted_angle','wrong_unweighted_angle'),('omit_probe_Lambda','omit_probe_Lambda')]:
     bad=dec(P[key][r]['total'][a]);zero(bad-dec(Z[key][r]['total'][a]));ctrl[label]+=nz(M-bad)
   rr.append(M)
  pl[ch]=[clean(sum((RB[c,a]*rr[a] for a in range(45) if RB[c,a]),s.zeros(16))) for c in range(45)]
 for a in range(45):zero(pl['right'][a]+pl['left'][a].T);zero(pl['left'][a]+pl['left'][a].H)
 counts.append(dict(cc));controls.append(dict(ctrl));plane.append(pl)
print('STAGE complete_quantum_arrays_and_reality_agree_BEFORE_counterterm_read',flush=True)
# Only now compare the previously fixed single candidate, without presuming zero.
C=load(O.parent/'canonical_so10_even_probe_vertices/gauge_tables.json.gz');remainders=[];rescounts=[]
for r in range(2):
 rr={};nn={}
 for ch in ['left','right']:
  KK=list(map(dec,C['candidate'][r]['plane'][ch]));res=[clean(plane[r][ch][a]-s.I*KK[a]) for a in range(45)]
  rr[ch]=list(map(enc,res));nn[ch]=sum(nz(v) for v in res)
 remainders.append(rr);rescounts.append(nn)
out={'schema':'RHO_VECTOR_QUANTUM_COMPARISON_V1','plane_quantum':[{ch:list(map(enc,z)) for ch,z in d.items()} for d in plane],'remainders':remainders,'remainder_positions':rescounts,'old_candidate_changed':False,'uBCPP_or_full_QAP_or_physical_matching_qualified':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'loop_comparison_v2_tables.json.gz').open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'schema':'RHO_VECTOR_QUANTUM_VALIDATION_V1','elapsed_after_imports':time.perf_counter()-tick,'complete_quantum_matrix_positions_compared':compared,'all_independent_quantum_families_agree':True,'nonzero_positions':counts,'controls':controls,'late_single_candidate_remainder_positions':rescounts,'single_candidate_matches_complete_selected_rhoBPP':not any(n for d in rescounts for n in d.values()),'comparison_packed_sha256':sha256(blob).hexdigest(),'comparison_raw_sha256':sha256(raw).hexdigest(),'full_QAP_or_authority_changed':False,'shared_action_frames_GTT_SMA_analytic_domain_software_AI_author':True},sort_keys=True),flush=True);timer.cancel()
