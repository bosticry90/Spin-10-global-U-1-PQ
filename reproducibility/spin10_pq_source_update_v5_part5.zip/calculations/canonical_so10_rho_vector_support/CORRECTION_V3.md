# RGS1 V3: nonzero support and sector-changing edge insertions

V2 primary/replay completed their classical vertex extraction. The verifier
compared all full vertex arrays FIRST and found exact agreement, then FAILED
at the typed profile comparison. Preserve all completed V2 arrays/results,
sources, manifests, captures and the failed verifier/controller unchanged.
They are not a completed support qualification.

Two support-harness errors caused the mismatch. Primary left canceled-zero
dictionary keys in the ghost-current support, though packed coefficient
arrays already exclude them. Clean exact zeros BEFORE forming typed roles;
do not change any coefficient or any Lorentz/late classical comparison.

Replay incorrectly required a compatible free triangle before inserting an
external B on one edge. The insertion can connect H/M sectors whose free
propagator component is zero. Test the final inserted cycle and its remaining
free edges; do not demand that the replaced edge itself be a supported free
edge. A derivative of a zero free component can be nonzero. For example,
K(z)=[[1,z],[z,2]] has G01(0)=0 but dG01/dz(0)=-1/2. This is an inverse-
response support control, not a new physical mass or normalization.

V3 changes only these two rules and versioned IO. Keep the independent full
cycle versus edge-insertion constructions and exact profile equality. Same
inputs, action, frames, vertex coefficients,300s/8GiB/350MiB/16MiB limits,
authority ceiling and quantum nonclaim. Repetition is justified because
V2 support FAILED; no expensive qualified calculation is repeated.
