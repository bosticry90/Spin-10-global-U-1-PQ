# RGS1 V2: restore the qualified two-axis field-order convention

The original primary FAILED at its first frame assertion, before vertex
extraction, arrays, replay or verifier. Preserve its original sources,
preparation, full capture and controller failure unchanged. It is not PASS.

The frozen inverse is Ti[raw row,physical column]. Raw order has C,ub,L,
bar,b blocks; physical order is B,x_Phi/x_Sigma/x_phi/x_S,Lambda,C,a.
Using raw labels for both axes yields nonzero inverse/covariance defects.
The correct type is already explicit in QUALIFIED CGK1 native_v2 and PFJ1.
RGS1 mistakenly repeated the old, failed CGK1 generator's indexing pattern.
This is an avoidable reuse error; the early frame assertion detected it.

V2 changes both block extraction and full raw-GF substitution to use the
actual physical column names. It also changes the verifier's frame
extraction. Check all four vector-component maps against the ghost map.
Bind the actual qualified CGK1 corrected native and its correction note,
not an unqualified historical generator, as the semantic frame reference.
Original CGK1 qualification already uses the corrected axes; this failure
does not identify a dependency on the failed CGK1 source in its accepted
outputs. No earlier physics claim is silently withdrawn or reaffirmed.

Keep the SAME raw inputs, action coefficients, density/Euler methods,
support/degree assertions, late classical checks, and300s/8GiB/350MiB/
16MiB limits. New versioned native/verifier/controller and manifests/output
names preserve every original byte. No loop coefficient or desired
counterterm enters this classical support calculation.
