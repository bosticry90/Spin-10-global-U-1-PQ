from pathlib import Path
import ast
O=Path(__file__).resolve().parent
n=(O/'loop.py').read_text(encoding='utf-8').replace("O/'loop_preparation.json'","O/'loop_preparation_v2.json'").replace("'loop_replay_tables.json.gz'","'loop_replay_v2_tables.json.gz'").replace("'loop_primary_tables.json.gz'","'loop_primary_v2_tables.json.gz'").replace("'loop_'+role+'_tables.json.gz'","'loop_'+role+'_v2_tables.json.gz'")
old='zero(K.inv().diff(z)+K.inv()*K.diff(z)*K.inv())';new='zero((K.inv().diff(z)+K.inv()*K.diff(z)*K.inv()).applyfunc(s.cancel))'
assert n.count(old)==1;n=n.replace(old,new)
v=(O/'verify_loop.py').read_text(encoding='utf-8').replace('loop_validation_preparation.json','loop_validation_preparation_v2.json').replace('loop_primary_tables.json.gz','loop_primary_v2_tables.json.gz').replace('loop_replay_tables.json.gz','loop_replay_v2_tables.json.gz').replace('loop_comparison_tables.json.gz','loop_comparison_v2_tables.json.gz')
for name,t in [('loop_v2.py',n),('verify_loop_v2.py',v)]:
 ast.parse(t)
 with(O/name).open('x',encoding='utf-8',newline='\n') as f:f.write(t)
print('GENERATED_RBG_V2_RATIONAL_WITNESS_CANCELLATION_ONLY')
