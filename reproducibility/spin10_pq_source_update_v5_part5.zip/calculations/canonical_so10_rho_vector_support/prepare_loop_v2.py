from pathlib import Path
from hashlib import sha256
import ast,json
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
old=read(O/'loop_preparation.json')
for p,h in old['input_sha256'].items():assert H(Path(p))==h,p
assert read(O/'loop_controller_failure.json')['stage']=='loop_primary' and read(O/'loop_primary_capture.json')['exit_code']==1
for n in ['LOOP_CORRECTION_V2.md','generate_loop_v2.py','loop_v2.py','verify_loop_v2.py','prepare_loop_v2.py','run_loop_v2.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
b=dict(old['input_sha256'])
for p in O.iterdir():
 if p.is_file():b[str(p)]=H(p)
nb={p:h for p,h in old['native_input_sha256'].items() if Path(p).name!='loop.py'};nb[str(O/'loop_v2.py')]=H(O/'loop_v2.py')
with(O/'loop_preparation_v2.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'native_input_sha256':nb,'limits':old['limits'],'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,separators=(',',':'))+'\n').encode())
print('PREPARED_RBG_V2',len(b))
