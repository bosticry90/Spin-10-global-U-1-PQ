from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import gzip,json,sys,time,threading,os,sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1]
for p,h in read(O/'loop_preparation.json')['native_input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if 'canonical_so10_even_probe_vertices' in p.parts or(p.parent.resolve()==O and p.name==('loop_replay_tables.json.gz' if role=='primary' else'loop_primary_tables.json.gz')):raise PermissionError('RBG_TARGET_OR_PEER_DENIED')
  if len(args)>1 and isinstance(args[1],str) and any(z in args[1] for z in 'wax+'):assert p.resolve()==O/('loop_'+role+'_tables.json.gz')
sys.addaudithook(guard)
d=load(O/('loop_'+role+'_inputs.json.gz'));g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.sympify(z,locals=loc)
dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v) for i,j,v in z['entries']})
clean=lambda M:s.SparseMatrix(M).applyfunc(s.expand)
enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(s.expand(z))] for(i,j),z in sorted(clean(M).todok().items()) if z]}
def zero(M):assert not clean(M).todok()
def expr(p):
 out=0
 for power,w,cid in p['monomials']:
  assert not w
  for xp,hp,mask,n,den in p['coefficients'][cid]:
   z=s.Rational(n,den)*g**power*xi**xp*eta**hp
   for k,p0 in enumerate([2,3,5,7]):
    if mask&(1<<k):z*=s.sqrt(p0)
   if mask&16:z*=s.I
   out+=z
 return s.expand(out)
tab=lambda rows:{tuple(row[:-1]):expr(row[-1]) for row in rows}
verts=d['vertices'];qb=[{k:tab(rows) for k,rows in v.items()} for v in verts['probe_quadratics']];contact=list(map(tab,verts['rho_aBB']));AG=tab(verts['GF_ghost_B']);AL=tab(verts['GF_auxiliary']);fc=defaultdict(list)
for a,b,c,z in verts['physical_f']:fc[a,b].append((c,expr(z)))
fr=d['frame'];Ti=dec(fr['physical_to_raw_inverse']);Q=dec(fr['Q']);order=fr['field_order'];phys=[f'B{i}_{mu}' for i in range(45) for mu in range(4)]+[f'x_{ss}_{i}' for ss,nn in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(nn)]+[('b'+str(i) if i<12 else'L'+str(i)) for i in range(45)]+['C'+str(i) for i in range(45)]+[('bar'+str(i) if i<12 else'ub'+str(i)) for i in range(45)]
RB=clean(Q*Ti.extract([order.index(f'B{i}_0') for i in range(45)],[phys.index(f'B{i}_0') for i in range(45)]));TP=list(map(dec,d['Tminus']));T=[clean(sum((RB[k,a]*TP[k] for k in range(45) if RB[k,a]),s.zeros(16))) for a in range(45)]
W=s.diag(*([eta]*12+[xi]*33));epsilon,h=s.symbols('epsilon h');Ddim=4-2*epsilon
finite=lambda z:s.simplify(s.diff(z.subs(h,-2*epsilon),epsilon).subs(epsilon,0))
if role=='primary':
 I0=finite(h*s.gamma(1+epsilon)/4);J=finite(h*s.gamma(1+epsilon)/24)
 # Literal four-barred Clifford factors, keeping total k^2 distinct.
 pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];gam=[s.kronecker_product(pa[1],x) for x in pa]+[s.kronecker_product(pa[0],s.eye(2))];kk=s.symbols('k0:4');K2,hat2=s.symbols('K2 hat2');slash=sum((kk[i]*gam[i] for i in range(4)),s.zeros(4));bar2=sum(x*x for x in kk)
 for rho in range(4):
  zero(slash*slash*gam[rho]-bar2*gam[rho]);zero(gam[rho]*slash*slash-bar2*gam[rho])
  for mu in range(4):
   full=sum((2*kk[rho]*int(mu==nu)-kk[mu]*int(nu==rho)-kk[nu]*int(rho==mu))*kk[nu] for nu in range(4))-hat2*int(mu==rho)
   assert s.expand(full-(kk[rho]*kk[mu]-(bar2+hat2)*int(mu==rho)))==0
  transverse=sum(kk[mu]*(kk[rho]*kk[mu]-K2*int(mu==rho)) for mu in range(4))+hat2*kk[rho]
  assert s.expand(transverse.subs(K2,bar2+hat2))==0
 units={'F':4*J,'G':J,'Y':I0-J,'L1I':I0,'L1J':J,'L2':J,'CI':I0,'CJ':J}
else:
 # Schwinger radial/angle cancellation: h/2 with denominator Gamma(n).
 t=s.symbols('t',positive=True);I0=finite((h/2)*s.gamma(1+epsilon)/s.gamma(3));J=finite((h/4)*s.gamma(1+epsilon)/s.gamma(4))
 # Full-D transversality first; the remaining projector average is I0-J.
 units={'F':sum(J for _ in range(4)),'G':J,'Y':I0*(1-J/I0),'L1I':I0,'L1J':J,'L2':J,'CI':I0,'CJ':J}
assert I0==-s.Rational(1,2) and J==-s.Rational(1,12)
z=s.Symbol('z');K=s.Matrix([[2,z],[z,3]]);zero(K.inv().diff(z)+K.inv()*K.diff(z)*K.inv());H4=s.simplify(I0-4*J);assert H4==-s.Rational(1,6)
def calculate(r,right,joint=J,Yunit=None,omitH=False):
 tt=[-t.T for t in T] if right else T
 V=s.SparseMatrix(45,45,{(a,b):s.I*x for(a,b),x in qb[r]['aB'].items()});HH=s.SparseMatrix(45,45,{(a,b):-s.I*x for(a,b),x in qb[r]['aL'].items()});HH=s.zeros(45) if omitH else HH;DD=clean(HH.T-W*V.T);zero(DD-DD.T)
 ZZ=I0*s.eye(45)+joint*(W-s.eye(45));jr=defaultdict(list);vr=defaultdict(list);dr=defaultdict(list)
 for(b,j),v in s.SparseMatrix(ZZ).todok().items():jr[j].append((b,v))
 for(a,r0),v in V.todok().items():vr[r0].append((a,v))
 for(j,a),v in DD.todok().items():dr[j].append((a,v))
 maps={name:defaultdict(lambda:s.S.Zero) for name in ['G','Y','L1','L2','C']}
 for(c,d0,a),v in AG.items():
  for b,x in [(b,DD[b,a]) for b in range(45) if DD[b,a]]:maps['G'][c,b,d0]+=-s.I*g*g*joint*x*v
 for(b,e),zs in fc.items():
  for c,f in zs:
   for a,x in dr[e]:maps['Y'][c,b,a]+=g**3*(I0-joint if Yunit is None else Yunit)*f*x
 for(r0,j,c),v in AL.items():
  for b,x in jr[j]:
   for a,y in vr[r0]:maps['L1'][c,b,a]+=-s.I*g*g*x*v*y
  for a,x in dr[j]:maps['L2'][c,r0,a]+=-s.I*g*g*joint*v*x
 for(a,j,c),v in contact[r].items():
  for b,x in jr[j]:maps['C'][c,b,a]+=g*g*x*v
 parts={name:[s.zeros(16) for _ in range(45)] for name in ['F','G','Y','L1','L2','C']}
 if role=='primary':
  for(b,a),x in DD.todok().items():
   for c in range(45):parts['F'][c]+=s.I*g**3*(4*joint)*x*(tt[b]*tt[c]*tt[a]+tt[a]*tt[c]*tt[b])
  for name,mp in maps.items():
   for(c,b,a),x in mp.items():parts[name][c]+=x*(tt[b]*tt[a]-tt[a]*tt[b])
 else:
  CD=sum((x*tt[b]*tt[a] for(b,a),x in DD.todok().items()),s.zeros(16))
  for c in range(45):
   N=defaultdict(lambda:s.S.Zero)
   for(b,a),x in DD.todok().items():
    for u,f in fc[a,c]:
     for v,ff in fc[b,u]:N[v]-=x*f*ff
   DDC=sum((x*tt[a] for a,x in N.items()),s.zeros(16));parts['F'][c]=s.I*g**3*(4*joint)*(CD*tt[c]+tt[c]*CD-DDC)
  for name,mp in maps.items():
   reduced=defaultdict(lambda:s.S.Zero)
   for(c,b,a),x in mp.items():
    for e,f in fc[b,a]:reduced[c,e]+=s.I*x*f
   for(c,e),x in reduced.items():parts[name][c]+=x*tt[e]
 parts={name:[clean(M) for M in ms] for name,ms in parts.items()};total=[clean(sum((ms[c] for ms in parts.values()),s.zeros(16))) for c in range(45)]
 return {'parts':{name:list(map(enc,ms)) for name,ms in parts.items()},'total':list(map(enc,total)),'D':enc(DD),'V':enc(V)}
actual=[{ch:calculate(r,ch=='right') for ch in ['left','right']} for r in range(2)]
badbar=[calculate(r,False,Yunit=3*J) for r in range(2)];badangle=[calculate(r,False,joint=-s.Rational(1,8)) for r in range(2)];badH=[calculate(r,False,omitH=True) for r in range(2)]
out={'schema':'RHO_VECTOR_QUANTUM_V1','role':role,'RB':enc(RB),'I0':str(I0),'J':str(J),'H4':str(H4),'units':{k:str(v) for k,v in units.items()},'amplitudes':actual,'wrong_barred_YM':badbar,'wrong_unweighted_angle':badangle,'omit_probe_Lambda':badH,'all_supported_families_exact_once':True,'counterterm_target_read':False,'no_new_finite_QAP_or_physical_scheme':True,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('loop_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True);timer.cancel()
