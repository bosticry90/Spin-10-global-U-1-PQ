"""Actual augmented action: mixed and companion local quantum coefficients."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from itertools import permutations
from collections import defaultdict
import gzip,json,sys,time,threading,os
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra,ONE,put,scale,scale_coefficient
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def add(*pp):
 out={}
 for p in pp:
  for k,c in p.items():put(out,k,c)
 return out
def main():
 tick=time.perf_counter();watch=threading.Timer(300,lambda:os._exit(124));watch.daemon=True;watch.start()
 role=sys.argv[1];assert role in ['primary','replay'];prep=read(O/'preparation.json')
 for p,h in prep['native_input_sha256'].items():assert digest(Path(p))==h,p
 def guard(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   path=Path(os.fsdecode(args[0]))
   if 'canonical_so10_even_probe_vertices' in path.parts:raise PermissionError('RGS_COUNTERTERM_AND_OLD_LOOP_TARGET_DENIED')
   if 'canonical_so10_probe_matter_source_consistency' in path.parts or(path.parent.resolve()==O and path.name==('replay_tables.json.gz' if role=='primary' else 'primary_tables.json.gz')):raise PermissionError('PFJ_TARGET_OR_PEER_DENIED')
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):
   assert Path(os.fsdecode(args[0])).resolve()==O/(role+'_tables.json.gz')
 sys.addaudithook(guard)
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry']
 extra=['mw_u0','mw_u1','mw_rho0','mw_rho1']+['mw_a'+str(i) for i in range(45)]+['mw_L'+str(i) for i in range(45)]+['mw_q'+str(i) for i in range(4)]+['mw_chi','mw_l32','mw_l2']
 A=Algebra(geo['names']+extra,geo['parities']+[0,0,1,1]+[1]*45+[0]*52)
 u=[A.index['mw_u'+str(i)] for i in range(2)];rho=[A.index['mw_rho'+str(i)] for i in range(2)]
 bg=[A.index['mw_a'+str(i)] for i in range(45)];bl=[A.index['mw_L'+str(i)] for i in range(45)];qs=[A.index['mw_q'+str(i)] for i in range(4)];cs=[A.index[n] for n in ['mw_chi','mw_l32','mw_l2']]
 pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};Jof={i:J for i,J,h,k in pairs};sources=set(Jof.values())
 bn=[[A.index[f'B{i}_{mu}'] for mu in range(4)] for i in range(45)];an=[A.index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];ln=[A.index[('b' if i<12 else 'L')+str(i)] for i in range(45)];cn=[A.index[f'C{i}'] for i in range(45)]
 jl=[Jof[i] for i in ln];ja=[Jof[i] for i in an];jc=[Jof[i] for i in cn];chi=set(jl+bg);anchors=set(bl+ja);ext=chi|anchors;probe=set(u+rho);core={n for b in bn for n in b}|set(an+ln+cn);bset={n for b in bn for n in b}
 dims={i:2 if i in ln else 1 for i in fields};ew={**dict.fromkeys(chi,1),**dict.fromkeys(anchors,2),**dict.fromkeys(rho,1)}
 def elem(n,j=()):
  if isinstance(n,str):n=A.index[n]
  return {(0,((n,j),)):ONE}
 @lru_cache(None)
 def scalar(z):return A.rows([{'word':[],'coefficient':str(z)}])
 def mul(*pp):
  p={(0,()):ONE}
  for q in pp:p=A.product(p,q)
  return p
 def rows(p):return A.rows(p)
 def pack(p):
  cc=[];ix={};mm=[]
  for(g,w),c in sorted(p.items()):
   if c not in ix:ix[c]=len(cc);cc.append([[*k,v.numerator,v.denominator] for k,v in c])
   mm.append([g,[[n,list(j)] for n,j in w],ix[c]])
  return {'coefficients':cc,'monomials':mm,'positions':len(p),'sha256':A.fingerprint(p)}
 def unpack(p,names=None):
  co=[tuple(((x,h,m),F(n,d)) for x,h,m,n,d in c) for c in p['coefficients']];out={}
  for g,w,k in p['monomials']:
   ww,sg=A.canonical(tuple((A.index[names[n]] if names else n,tuple(j)) for n,j in w))
   if sg:put(out,(g,ww),scale_coefficient(co[k],sg))
  return out
 def D(p,mu):
  out={}
  for(g,w),c in p.items():
   for at,(n,j) in enumerate(w):
    ww,sg=A.canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
    if sg:put(out,(g,ww),scale_coefficient(c,sg))
  return out
 def DD(p,j):
  for mu in j:p=D(p,mu)
  return p
 def sub(p,mp):
  out={}
  for(g,w),c in p.items():
   z={(g,()):c}
   for n,j in w:z=mul(z,DD(mp.get(n,elem(n)),j))
   for k,v in z.items():put(out,k,v)
  return out
 def grad(p):
  out={}
  for(g,w),c in p.items():
   total=sum(A.parities[n] for n,j in w);prefix=0
   for at,(n,j) in enumerate(w):
    sg=(-1)**(A.parities[n]*prefix) if role=='primary' else (-1)**(A.parities[n]*(total-prefix-A.parities[n])+A.parities[n]*(total-A.parities[n]))
    put(out.setdefault((n,j),{}),(g,w[:at]+w[at+1:]),scale_coefficient(c,sg));prefix+=A.parities[n]
  return {k:p for k,p in out.items() if p}
 def op(p,v,odd):
  out={}
  if role=='replay':
   for(n,j),df in grad(p).items():
    if n in v:
     for k,c in mul(DD(v[n],j),df).items():put(out,k,c)
  else:
   for(g,w),c in p.items():
    prefix=0
    for at,(n,j) in enumerate(w):
     if n in v:
      z=mul({(g,w[:at]):scale_coefficient(c,(-1)**prefix if odd else 1)},DD(v[n],j),{(0,w[at+1:]):ONE})
      for k,t in z.items():put(out,k,t)
     prefix+=A.parities[n]
  return out
 def wick(p):
  phases={**{b[0]:'I' for b in bn},**dict.fromkeys(ln+jl,'-I'),**dict.fromkeys(ja+jc,'-1')};out={}
  for(g,w),c in p.items():
   fac=scalar('-1')
   for n,j in w:
    fac=mul(fac,scalar(phases.get(n,'1')),scalar(['1','I','-1','-I'][j.count(0)%4]))
   for k,v in mul({(g,w):c},fac).items():put(out,k,v)
  return out



 import sympy as s
 from itertools import product
 from exact_algebra import multiply_coefficients
 inp=json.loads(gzip.decompress((O/(role+'_inputs.json.gz')).read_bytes()));assert inp['names']==list(A.names)
 dec=lambda d:s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z) for i,j,z in d['entries']})
 ref=inp['frame'];order=ref['field_order'];Ti=dec(ref['physical_to_raw_inverse']);Q=dec(ref['Q']);Ad=dec(ref['Adual']);ix={n:i for i,n in enumerate(order)}
 def mpblock(names,L):return (L*Ti.extract([ix[n] for n in names],[ix[n] for n in names])).applyfunc(s.expand)
 RC=mpblock(['C'+str(i) for i in range(45)],Q);RB=mpblock([f'B{i}_0' for i in range(45)],Q);RA=mpblock([('bar'+str(i) if i<12 else'ub'+str(i)) for i in range(45)],Ad);RL=mpblock([('b'+str(i) if i<12 else'L'+str(i)) for i in range(45)],Ad)
 zero=lambda M:not s.SparseMatrix(M).applyfunc(s.expand).todok()
 assert zero(RB-RC) and zero(RB*RB.T-s.eye(45)) and zero(RC*RA.T-s.eye(45)) and zero(RB*RL.T-s.eye(45))
 aset=set(an);cset=set(cn);lset=set(ln);bose=bset|lset
 bp={n:(i,mu) for i,v in enumerate(bn) for mu,n in enumerate(v)};ap={n:i for i,n in enumerate(an)};cp={n:i for i,n in enumerate(cn)};lp={n:i for i,n in enumerate(ln)}
 def el(p):
  out={}
  for(n,j),df in grad(p).items():out[n]=add(out.get(n,{}),scale(DD(df,j),(-1)**len(j)))
  return {n:v for n,v in out.items() if v}
 def cv(text):return scalar(str(text)).get((0,()),())
 def pm(M):return [[*key,pack(v)] for key,v in sorted(M.items()) if v]
 def cm(M):return {key:v for key,v in M.items() if v}
 def addentry(M,key,p):M[key]=add(M.get(key,{}),p)
 def strip(p,allowed):
  out={}
  for(g,w),co in p.items():
   if all(n in allowed and not j for n,j in w):put(out,(g,()),co)
   else:assert False,('UNEXPECTED_REMAINDER',w)
  return out
 def fo(p,mom,external):
  out={}
  for(g,w),co in p.items():
   z={(g,()):co}
   for n,j in w:
    if n in external:
     if j:z={};break
    else:
     for mu in j:z=mul(z,scalar('I'),scale(elem(qs[mu]),mom.get(n,1)))
   out=add(out,z)
  return out
 # Physical raw-GF transport, preserving field types and action coefficients.
 raw={}
 for(g,w),co in A.rows(inp['gauge_fixing_density']).items():
  if len(w)==3 and all(n in core for n,j in w) and sum(dims[n]+len(j) for n,j in w)==4:raw[g,w]=co
 mp={}
 for(i,j),z in Ti.todok().items():
  if order[i] in A.index and order[j] in A.index:
   n=A.index[order[i]];m=A.index[order[j]]
   if n in core and m in core:mp[n]=add(mp.get(n,{}),mul(scalar(str(z)),elem(m)))
 GF=wick(sub(raw,mp));aux={};ghost={};ggsource={};quad=[];contacts=[];inventory=[];marginalG=[]
 # Complete relevant GF classes; no assumed common coupling is stripped.
 Aux={key:co for key,co in GF.items() if sum(n in lset for n,j in key[1])==1 and sum(n in bset for n,j in key[1])==2}
 Ghost={key:co for key,co in GF.items() if sum(n in aset for n,j in key[1])==1 and sum(n in cset for n,j in key[1])==1 and sum(n in bset for n,j in key[1])==1}
 Other={key:co for key,co in GF.items() if key not in Aux and key not in Ghost}
 def cubic(p,oddnode=None,probe=None):
  out={}
  if role=='primary':
   for(g,w),co in p.items():
    vec=[i for i,(n,j) in enumerate(w) if n in bset];base=next(n for n,j in w if n in (aset if oddnode=='a' else lset));assert len(vec)==2 and all(not j for n,j in w)
    for ii,jj in permutations(vec):
     i,mu=bp[w[ii][0]];j,nu=bp[w[jj][0]];z={(g,()):co}
     # Canonical a precedes rho; no fermion is replaced by an even scalar.
     if probe is not None:
      oo=[n for n,j in w if A.parities[n]];assert oo==[base,probe]
     addentry(out,(ap[base] if oddnode=='a' else lp[base],i,j,mu,nu),z)
  else:
   for n,E in el(p).items():
    if n not in (aset if oddnode=='a' else lset):continue
    for(b,I),v in grad(E).items():
     if b not in bset:continue
     for(c,J),z in grad(v).items():
      if c not in bset:continue
      assert not I and not J;i,mu=bp[b];j,nu=bp[c]
      addentry(out,(ap[n] if oddnode=='a' else lp[n],i,j,mu,nu),strip(z,{probe} if probe is not None else set()))
  compact={}
  for(a,b,c,mu,nu),v in out.items():
   assert mu==nu
   if mu==0:compact[a,b,c]=v
  for key,v in compact.items():
   for mu in range(4):assert out.get((*key,mu,mu),{})==v
  assert len(out)==4*len(compact)
  return cm(compact)
 aux=cubic(Aux)
 # Constant external B: linearized ghost current at ghost +k, antighost -k.
 gfull={}
 if role=='primary':
  for(g,w),co in Ghost.items():
   ai=next(i for i,(n,j) in enumerate(w) if n in aset);ci=next(i for i,(n,j) in enumerate(w) if n in cset);bi=next(i for i,(n,j) in enumerate(w) if n in bset);b,mu=bp[w[bi][0]];sg=-1 if ci<ai else 1
   z=fo({(g,w):scale_coefficient(co,sg)},dict.fromkeys(aset,-1),bset)
   addentry(gfull,(b,ap[w[ai][0]],cp[w[ci][0]],mu),z)
 else:
  for a,E in el(Ghost).items():
   if a not in aset:continue
   for(c,J),v in grad(E).items():
    if c not in cset:continue
    for(g,w),co in v.items():
     assert len(w)==1 and w[0][0] in bset;b,mu=bp[w[0][0]]
     z=fo({(g,w):co},{},bset)
     for jj in J:z=mul(z,scalar('I'),elem(qs[jj]))
     addentry(gfull,(b,ap[a],cp[c],mu),z)
 for(b,a,c,mu),v in gfull.items():
  coeff={}
  for(g,w),co in v.items():assert w==((qs[mu],()),);put(coeff,(g,()),co)
  if mu==0:ghost[b,a,c]=coeff
 for key,v in ghost.items():
  for mu in range(4):assert gfull.get((*key,mu),{})==mul(v,elem(qs[mu]))
 assert len(gfull)==4*len(ghost)
 for rr in range(2):
  G=unpack(inp['physical_G'][rr]);stat=defaultdict(int);marg={}
  for key,co in G.items():
   g,w=key
   if not all(n in fields for n,j in w):stat['source_or_external_rows']+=1;continue
   dim=sum(dims[n]+len(j) for n,j in w)
   if dim!=3:assert dim<3;stat['positive_dimension_coefficient_rows']+=1;continue
   stat['marginal_'+str(len(w))+'_field_rows']+=1;marg[key]=co
  q0={key:co for key,co in marg.items() if len(key[1])==2};cc={key:co for key,co in marg.items() if len(key[1])==3 and sum(n in aset for n,j in key[1])==1 and sum(n in bset for n,j in key[1])==2}
  for key in marg:
   if len(key[1])==3 and any(n in bset for n,j in key[1]):assert key in cc,('UNACCOUNTED_G_EXTERNAL_B_CONTACT',key)
  marginalG.append(pack(marg))
  Q0=wick(mul(elem(rho[rr]),q0));CC=wick(mul(elem(rho[rr]),cc));ct=cubic(CC,'a',rho[rr]);contacts.append(ct);inventory.append(dict(stat))
  # Euler at constant rho, with all q_mu dependence retained until checked.
  hv={};hl={}
  if role=='primary':
   for(g,w),co in Q0.items():
    aa=[n for n,j in w if n in aset];bb=[n for n,j in w if n in bose];assert len(aa)==len(bb)==1;a=aa[0];b=bb[0]
    z=fo({(g,w):co},dict.fromkeys(aset,-1),{rho[rr]})
    if b in bset:addentry(hv,(ap[a],*bp[b]),z)
    else:addentry(hl,(ap[a],lp[b]),z)
  else:
   for a,E in el(Q0).items():
    if a not in aset:continue
    for(b,J),v in grad(E).items():
     if b not in bose:continue
     z=fo(v,{},set(rho))
     for mu in J:z=mul(z,scalar('I'),elem(qs[mu]))
     if b in bset:addentry(hv,(ap[a],*bp[b]),z)
     else:addentry(hl,(ap[a],lp[b]),z)
  vv={}
  for(a,b,mu),v in hv.items():
   co={}
   for(g,w),z in v.items():assert w==((qs[mu],()),);put(co,(g,()),z)
   if mu==0:vv[a,b]=co
  for key,z in vv.items():
   for mu in range(4):assert hv.get((*key,mu),{})==mul(z,elem(qs[mu]))
  assert len(hv)==4*len(vv);quad.append({'aB':cm(vv),'aL':cm(hl)})
 print('STAGE '+role+' all_actual_probe_ghost_and_auxiliary_vertices_complete',flush=True)
 # Exact physical Lie tensor: no replacement of color charges by an average.
 rb={i:[(j,cv(z)) for(ii,j),z in RB.todok().items() if ii==i] for i in range(45)};fp={}
 for a,b,c,z in inp['plane_f']:
  co=cv(z)
  for i,x in rb[a]:
   for j,y in rb[b]:
    for k,z0 in rb[c]:put(fp,(i,j,k),multiply_coefficients(multiply_coefficients(multiply_coefficients(co,x),y),z0))
 ftypes={tuple('H' if i<12 else'M' for i in key) for key in fp}
 def sector(i):return 'H' if i<12 else'M'
 typedG=[]
 for rr in range(2):
  opts=set()
  for kind,tab in quad[rr].items():
   for(a,b),v in tab.items():opts.add(('G'+kind,('a'+sector(a),('B' if kind=='aB' else'L')+sector(b)),1 if kind=='aB' else 0))
  typedG.append(opts)
 gtypes={(('a'+sector(a),'C'+sector(c)),'B'+sector(b)) for b,a,c in ghost}
 atypes={(('L'+sector(a),'B'+sector(b)),'B'+sector(c)) for a,b,c in aux}
 ytypes={(('B'+a,'B'+b),'B'+c) for a,b,c in ftypes}
 ctypes=[{(('a'+sector(a),'B'+sector(b)),'B'+sector(c)) for a,b,c in tab} for tab in contacts]
 # Cycle item: name,external tuple,incoming type,outgoing type,internal jets.
 def both(name,ext,pair,j):return [(name,ext,*pair,j),(name,ext,*reversed(pair),j)]
 def canon(path):
  pp=tuple(path);back=tuple((n,e,b,a,j) for n,e,a,b,j in reversed(pp));return min(seq[i:]+seq[:i] for seq in [pp,back] for i in range(len(seq)))
 def edge(a,b):
  if a==b=='F':return 1
  if a[1:]==b[1:] and {a[:1],b[:1]}=={'C','a'}:return 2
  if a==b and a.startswith('B'):return 2
  if a[1:]==b[1:] and {a[:1],b[:1]}=={'B','L'}:return 1
  return None
 def valid(path,expected_degree=0):
  es=[edge(path[i][3],path[(i+1)%len(path)][2]) for i in range(len(path))]
  if any(x is None for x in es):return None
  deg=4+sum(v[4] for v in path)-sum(es);assert deg==expected_degree,('BAD_UV_DEGREE',path,deg)
  return canon(path)
 Es=sum((both('E',('P',),('F','C'+sec),1) for sec in ['H','M']),[])
 Ms=sum((both('PPB',('P',),('F','B'+sec),0) for sec in ['H','M']),[])
 Ws=sum((both('fermion_edge',('B'+sec,),('F','F'),0) for sec in ['H','M']),[])
 Ws+=sum((both('ghost_edge',(ext,),pair,1) for pair,ext in sorted(gtypes)),[])
 Ws+=sum((both('auxiliary_edge',(ext,),pair,0) for pair,ext in sorted(atypes)),[])
 Ws+=sum((both('YM_edge',(ext,),pair,1) for pair,ext in sorted(ytypes)),[])
 def calculate(rr,omit=None):
  Gs=sum((both(n,('rho'+str(rr),),pair,j) for n,pair,j in sorted(typedG[rr])),[])
  G3=sum((both('G_aBB',('rho'+str(rr),ext),pair,0) for pair,ext in sorted(ctypes[rr])),[])
  ww=[v for v in Ws if v[0]!=omit];out=set()
  if role=='primary':
   for E,M,G in product(Es,Ms,G3):
    for v in permutations([M,G]):
     z=valid((E,*v))
     if z is not None and omit!='G_aBB':out.add(z)
   for E,M,G,W0 in product(Es,Ms,Gs,ww):
    for v in permutations([M,G,W0]):
     z=valid((E,*v))
     if z is not None:out.add(z)
  else:
   # Forced E->ghost->G->boson->M->fermion->E cycle, then edge insertions.
   for E in Es:
    if E[2]!='F':continue
    for G,M in product(Gs,Ms):
     base=(E,G,M)
     if valid(base,1) is None:continue
     for at in range(3):
      for W0 in ww:
       path=base[:at+1]+(W0,)+base[at+1:];z=valid(path)
       if z is not None:out.add(z)
    for G,M in product(G3,Ms):
     z=valid((E,G,M))
     if z is not None and omit!='G_aBB':out.add(z)
  if omit=='mixed_edges':out={p for p in out if all(not({p[i][3][:1],p[(i+1)%len(p)][2][:1]}=={'B','L'}) for i in range(len(p)))}
  return sorted(out)
 profiles=[calculate(rr) for rr in range(2)];controls=[]
 for rr in range(2):controls.append({name:len(set(profiles[rr])-set(calculate(rr,name))) for name in ['mixed_edges','auxiliary_edge','ghost_edge','G_aBB','fermion_edge','YM_edge']})
 out={'schema':'RHO_VECTOR_ACTUAL_SUPPORT_V1','role':role,'names':list(A.names),'parities':list(A.parities),'probe_quadratics':[{k:pm(v) for k,v in tab.items()} for tab in quad],'rho_aBB':[pm(t) for t in contacts],'GF_auxiliary':pm(aux),'GF_ghost_B':pm(ghost),'GF_other_marginal_cubics':pack(Other),'G_inventory':inventory,'complete_marginal_G':marginalG,'physical_f':[[*key,pack({(0,()):co})] for key,co in sorted(fp.items())],'profiles':profiles,'controls':controls,'all_Lorentz_components_checked':True,'paired_E_C_E_S_roles_preserved':True,'E_P_external_hat_derivative_zero_only':True,'pure_vector_action_operator_authenticated_reuse':True,'no_quantum_coefficients_or_counterterm_comparison':True,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
 raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with(O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'profiles':[len(v) for v in profiles],'contact_color_entries':[len(v) for v in contacts],'auxiliary_color_entries':len(aux),'ghost_color_entries':len(ghost)},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
