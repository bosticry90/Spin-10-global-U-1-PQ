from pathlib import Path
import ast
O=Path(__file__).resolve().parent
n=(O/'native_v2.py').read_text(encoding='utf-8').replace("O/'preparation_v2.json'","O/'preparation_v3.json'").replace("'_v2_tables.json.gz'","'_v3_tables.json.gz'").replace("'replay_v2_tables.json.gz'","'replay_v3_tables.json.gz'").replace("'primary_v2_tables.json.gz'","'primary_v3_tables.json.gz'")
needle=' assert len(gfull)==4*len(ghost)'
assert n.count(needle)==1;n=n.replace(needle,needle+'\n ghost=cm(ghost)')
needle='     if valid(base,1) is None:continue\n'
assert n.count(needle)==1;n=n.replace(needle,'')
v=(O/'verify_v2.py').read_text(encoding='utf-8').replace("O/'validation_preparation_v2.json'","O/'validation_preparation_v3.json'").replace("O/'primary_v2_tables.json.gz'","O/'primary_v3_tables.json.gz'").replace("O/'replay_v2_tables.json.gz'","O/'replay_v3_tables.json.gz'")
needle="families=[]"
assert v.count(needle)==1;v=v.replace(needle,"zz=s.Symbol('zz');witness=s.Matrix([[1,zz],[zz,2]]).inv();assert witness[0,1].subs(zz,0)==0 and s.diff(witness[0,1],zz).subs(zz,0)==-s.Rational(1,2)\nfamilies=[]")
v=v.replace("'quantum_loop_or_counterterm_comparison_performed':False","'zero_free_component_nonzero_derivative_control':'-1/2','quantum_loop_or_counterterm_comparison_performed':False")
for name,t in [('native_v3.py',n),('verify_v3.py',v)]:
 ast.parse(t)
 with(O/name).open('x',encoding='utf-8',newline='\n') as f:f.write(t)
print('GENERATED_RGS_V3_EXACT_NONZERO_SUPPORT_AND_FINAL_EDGE_COMPATIBILITY')
