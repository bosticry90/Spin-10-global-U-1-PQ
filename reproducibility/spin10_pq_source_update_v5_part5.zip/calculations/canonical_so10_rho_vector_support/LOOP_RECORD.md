# RBG1: complete first-rho*BPP quantum tensor from the unexpanded triangle

RGS1 V3 completed before this continuation: full density/Euler vertices and
cycle/edge-insertion sets agree, with12/22 profiles. Classical limits match
PFJ1, GTT1 and FAV1. The heavy rho aBB contact is nonzero with668 color
entries. The first-rho*BPP quantum tensor remains unknown. Measure it before
comparing the QVC1 counterterm. Same mass-independent nonexceptional
Euclidean local UV-leading family, external hats/ordinary jets0, internal
hats and full-D bosonic endpoints retained. No physical mass limit is taken.

Let V_ar=i Gamma_(rho aB), H_ar=-i Gamma_(rho aLambda), so the actual
quadratic vertex is -i V_ar k_mu or i H_ar. Let W=eta_H PH+xi PM and
D_ba=H_ab-sum_j W_bj V_aj. All of these are measured classical matrices;
the compact diagonal relation, if present, is checked, not assumed.

At rho/P momenta0 the actual bosonic sewing, before the fermion/ghost
denominators, is

    J_B,mu = i D_ba k_mu/k^2,   J_Lambda = i V_ar.

Use G_BB(-k)=(I+(W-I)kk/k^2)/k^2, G_BLambda(-k)=+k/k^2,
G_LambdaB(-k)=-k/k^2, G_LambdaLambda=0. J_Lambda requires FULL k^2.
The actual E_SP/S_PS and E_PS/S_SP products supply hatk^2; the paired
raw blocks, action phases and open three-even-vertex units are qualified
GTT/SMA REUSE. There is no physical S interaction. Differentiate the
UNEXPANDED propagators: delta S=-S V_B S and delta G=-G Gamma_B G.
For example delta S_PS=-S_PP V_B S_PS, with S_PP=-i barslash(k)/k^2,
S_PS=-i hatslash(k)/k^2 and V_B=-i g gamma_rho T_c. Keep both orientations.
This differentiates the actual Gaussian operator, not a target counterterm.

In common1/(16pi^2) units the correlated finite hatted radial moments are

    I0=FP int hatk^2/(k^2+m^2)^3=-1/2,
    J delta_mu_nu=FP int hatk^2 kbar_mu kbar_nu/(k^2+m^2)^4=-delta/12.

Derive these by dimensional h=-2epsilon residues and by shifted Schwinger
moments. 4J is the barred k^2 moment, not I0. H4=I0-4J=-1/6 is nonzero.
The positive mass m is only the inherited local UV rearrangement after
the exact numerator/denominator reductions. UV-convergent evanescent
remainders vanish under the inherited nonexceptional assumptions. No
finite nonlocal/heat/IR amplitude is declared zero or independently proved.

Write the measured old ghost-current coefficient at constant external B
as A^G_(c,d,a) k_rho (including its actual coupling/complex phase), the
measured auxiliary cubic as A^L_(r,j,c), and rho contact as C_(a,j,c).
Set Z=I0 I+J(W-I). For generators T, define the following COMPLETE ordered
zero-jet families, retaining all actual coupling powers:

 F_c = i g^3 4J sum_ba D_ba (Tb Tc Ta+Ta Tc Tb),
 G_c = -i g^2 J sum_bda D_ba A^G_(c,d,a) [Tb,Td],
 Y_c = g^3 (I0-J) sum_bea f_bec D_ea [Tb,Ta],
 L1_c = -i g^2 sum_brja Z_bj A^L_(r,j,c) V_ar [Tb,Ta],
 L2_c = -i g^2 J sum_rja A^L_(r,j,c) D_ja [Tr,Ta],
 C_c = g^2 sum_bja Z_bj C_(a,j,c) [Tb,Ta].

Their sum is the measured tensor. Do not replace any family by the
correction needed to cancel the rest. L1/L2 are ordered mixed placements,
not independent invented diagrams. Keep them separately even if a contact
relationship later cancels a sum. Right generators are U=-T^T; calculate
them independently, then test R_right=-R_left^T after plane transport.

These units follow from differentiating actual propagators. The two
orientations give the sum in F, commutators in the other families. Ghost
response is -G_Ca delta K_aC G_Ca, not an extra closed-loop ghost sign.
The full-D curvature contraction is

    V_(rho mu nu)(k) k_nu=k_rho k_mu-k^2 delta_rho_mu.

It kills the left longitudinal propagator exactly, yielding I0-J. Replacing
this k^2 by bark^2 changes the finite answer: its unit becomes3J instead.
No four-dimensional-only bosonic ghost-endpoint contraction is allowed.
The literal barred Clifford/ordered inverse route and the independent
Schwinger/transverse-Lie/double-commutator route must agree.

Primary sews full physical ordered products; replay reduces each commutator
with the actual physical f and the symmetric F color tensor by
{C_D,Tc}-sum_ab D_ab[Ta,[Tb,Tc]]. Neither reads QVC1 or a peer output.
The verifier compares all families and zeros BEFORE reading the old
candidate. It then reports, without presuming zero, R_quantum-i K in
both chiralities/all45 plane and physical directions. Preserve a nonzero
result and distinguish an insufficient candidate from a complete anomaly
obstruction. No finite normalization is chosen to force cancellation.

Controls: omit/reverse each required family, omit Lambda response, wrong
full-D versus barred-only cubic contraction, wrong angular factor and
extra half/family3. Report insensitive controls honestly. Keep proof
ordering and actual Lorentz/ghost signs. Reused analytic premises, action,
frames, software and AI author limit independence.

Freeze sources and CLASSICAL restricted inputs before execution. Sequential
P/R/V each600s after imports,8GiB sampled private,350MiB launch floor,
whole RGS1/RBG1 packet16MiB. No cap expansion of a failed RGS run. Preserve
all original frame/support failures and complete captures. State113/34of39,
custodyexit2/seven NOTPASS, E5/A5 open. No agents, branches/worktrees, push,
publication, physical scheme/benchmark adoption, flavor/HB1C5 activation or
promotion. u*C*BPP, other quantum companions, finite heat/contact/QAP,
background, measure/global phase, massive matching and unification remain
separate. kappa,b0,chi4 stay distinct and unselected.
