# RGS1: actual first-rho*BPP support before the quantum comparison

Base main8c4c8b242b3dd7254143e1d616a88c68582a17a0. Previous goal turn made
PROGRESS: verified complete first-u*C*PP quantum input and one common local
candidate. Its new rho*BPP quantum companion is unknown. Preflight now
reports clean tracked bytes, no matching live research Python worker,
State113/34of39 unchanged and custody exit2/seven NOTPASS.

Question: which complete actual vertices and one-loop cycles contribute to
the first-rho*BPP zero-ordinary-jet bare evanescent insertion, for both
probes/chiralities and all45 total-field B directions? This is needed to
test the SAME candidate, not enlarge a catalogue without a required test.
No value is inferred from its -i K counterterm image.

This first bounded increment calculates CLASSICAL vertices and complete
typed support, not a loop amplitude. Keep rho odd/dimension1/ghost1,
u even/dimension0, P dimension3/2, B/C/a dimension1 and Lambda dimension2.
Use the inherited mass-independent nonexceptional Euclidean local UV
family. External ordinary momenta have jet degree0; external hats0,
internal hats and full-D bosonic/ghost endpoints remain. Positive mass/VEV
coefficients lower this marginal degree and do not vanish as full finite
physical amplitudes. No inverse physical parameter is introduced.

Extract actual marginal source-free G quadratics/cubics, including any
rho*a*B*B contact, the full constant-external-B ghost principal current,
and auxiliary/vector cubics. Transform the ACTUAL raw GF density with its
authenticated field inverse, then Wick rotate; do not identify raw and
physical frames. Primary uses literal ordered density coefficients with
all repeated-field multiplicities. Replay takes full graded Euler-a or
Euler-Lambda first and then field derivatives. Derivative-rho terms are
retained through Euler and only then removed by this zero-jet target.
Check every Lorentz component before reducing to color tensors.

The pure vector cubic is the qualified FCV1 full45 Lie/curvature operator
-i*g*f_abc(2 k_rho delta_mu_nu-k_mu delta_nu_rho-k_nu delta_rho_mu).
Its action normalization/full Lie reconstruction are authenticated REUSE;
do not reinterpret its ordinary pole angular factors as the finite hatted
insertion kernel. Preserve full-D internal vector indices in the later
kernel. Derive its physical Lie tensor from actual plane fields, retaining
both H/M sectors and all polynomial widths/couplings in other vertices.

For a bridgeless connected unicyclic1PI graph, every internal degree is2.
Ihat contains C,P,S and no B or probes. With no external ordinary ghost,
one physical external P is at Ihat; the other is at a matter vertex.
Ordinary dimension-zero kinetic terms are already resummed. The full
target is the field derivative of the UNEXPANDED rho triangle: emissions
on its fermion, ghost and bosonic edges, plus G's actual aBB contact.
Do not differentiate its already integrated one-jet result instead.
Scalar/other classes must be excluded by actual roles/dimensions, not by
the names of the external fields. A source-free quartic/matter seagull
must not be invented; use the authenticated SMA/CPS action inventory.

Primary enumerates all compatible rooted cycles from actual typed vertices;
replay independently inserts an external-B vertex on each of the forced
triangle edges and adds the actual G contact. Compare full canonical
profile sets and weighted UV degrees. Preserve the separate E_C/E_S raw
blocks for the later kernel. E_P can be excluded only because its external
physical hatted derivative is0, not by deleting internal mixed hats.
Typed profiles are a support envelope, not multiplicities or measured
amplitudes. Negative controls remove BL, auxiliary cubics, ghost emission
or the G contact; record genuinely insensitive controls honestly.

Native workers read restricted CLASSICAL inputs only; deny the previous
counterterm/quantum targets and peer output. The verifier first compares
full vertex/support outputs, then checks inherited PFJ1/GTT1/FAV1 classical
limits with the appropriate frames. Mismatch is failure, not an anomaly.
Sequential P/R/V each300s after imports,8GiB sampled private,350MiB launch
floor,whole packet16MiB. Freeze sources, immutable inputs, expected evidence
and ceiling before execution; preserve exact failures/captures/unfinished
outputs. No silent cap expansion or truncation.

Next use these vertices to derive and integrate the complete zero-jet
ordered hatted numerator, BEFORE comparing with -i K. A support result is
not that quantum calculation. No finite heat/contact/QAP, varying-background,
measure/global phase, massive matching, E5/A5 or physical unification claim.
kappa,b0,chi4 remain distinct/unselected. No agents, branch/worktree, push,
outreach/publication, physical scheme/benchmark/foundation adoption,
flavor/HB1C5 activation or protected promotion. Shared action/frames/domain,
software and AI author limit independent corroboration.
