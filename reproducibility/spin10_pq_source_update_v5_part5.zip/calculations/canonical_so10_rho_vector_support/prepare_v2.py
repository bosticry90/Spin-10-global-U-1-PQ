from pathlib import Path
from hashlib import sha256
import ast,json
O=Path(__file__).resolve().parent;R=O.parents[1]
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
old=read(O/'preparation.json')
for p,h in old['input_sha256'].items():assert H(Path(p))==h,p
assert read(O/'controller_failure.json')['stage']=='primary' and read(O/'primary_capture.json')['exit_code']==1
for n in ['CORRECTION_V2.md','generate_v2.py','native_v2.py','verify_v2.py','prepare_v2.py','run_v2.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
b=dict(old['input_sha256'])
for p in O.iterdir():
 if p.is_file():b[str(p)]=H(p)
K=O.parent/'canonical_so10_probe_chiral_ghost_kernel';m=read(K/'validation_preparation_v2.json')['input_sha256']
for name in ['native_v2.py','CORRECTION_V2.md']:
 p=K/name;assert H(p)==m[str(p.resolve())];b[str(p)]=H(p)
nb={p:h for p,h in old['native_input_sha256'].items() if Path(p).name!='native.py'};nb[str(O/'native_v2.py')]=H(O/'native_v2.py')
with(O/'preparation_v2.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'native_input_sha256':nb,'limits':old['limits'],'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,separators=(',',':'))+'\n').encode())
print('PREPARED_RGS_V2',len(b))
