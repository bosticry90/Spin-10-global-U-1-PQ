# RBG1 V2: cancel the rational inverse-response control before comparison

Original primary FAILED before any color/amplitude extraction or output.
The polynomial zero helper expands but cannot cancel the denominators in
the finite2x2 identity dK^-1=-K^-1(dK)K^-1. Preserve source/source copy,
preparation, complete capture and controller failure. No replay/verifier ran.

Apply exact SymPy cancel entrywise to THIS rational witness before the
unchanged polynomial zero helper. Do not change the loop coefficients,
physical inputs, gamma/radial/color algebra, comparison requirements or
600s/8GiB/350MiB/16MiB limits. New versioned source/manifests/captures and
tables preserve the failed execution; no failed status is relabelled PASS.
