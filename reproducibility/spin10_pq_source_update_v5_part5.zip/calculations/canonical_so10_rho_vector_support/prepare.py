from pathlib import Path
from hashlib import sha256
import ast,gzip,json,subprocess
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;K=O.parent/'canonical_so10_probe_chiral_ghost_kernel'
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert base=='8c4c8b242b3dd7254143e1d616a88c68582a17a0'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R).strip()
files=[R/n for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V593.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/portable_dh_v1/inputs.json.gz','tools/portable_dh_v1/exact_algebra.py','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']]
deps={'canonical_so10_even_probe_vertices':['RESULT.md','NEXT_RHO_BPP.md','gauge_validation_receipt_v2.json'],'canonical_so10_probe_fermion_onejet':['DERIVATION.md','RESULT.md','validation_preparation.json','validation_receipt.json'],'canonical_so10_probe_chiral_ghost_kernel':['validation_preparation_v2.json','validation_receipt_v2.json'],'canonical_so10_chiral_probe_support':['DERIVATION.md','RESULT.md','validation_receipt.json'],'canonical_so10_gauge_fermion_insertion':['DERIVATION.md','RESULT.md','validation_receipt.json'],'canonical_so10_ghost_triangle_field_insertion':['DERIVATION.md','RESULT.md','validation_preparation.json','validation_receipt.json','qualified_reference_inputs.json.gz','primary_tables.json.gz','replay_tables.json.gz'],'canonical_so10_fermion_cubic_vector_vertex':['DERIVATION.md','RESULT.md','validation_receipt.json','primary_v3_tables.json.gz'],'canonical_so10_fermion_auxiliary_gauge_vertex':['DERIVATION.md','RESULT.md','validation_receipt.json','validation_preparation_v2.json','replay_tables.json.gz'],'canonical_so10_sterile_matter_action':['ACTION_V1.md','validation_receipt.json']}
for folder,names in deps.items():files.extend(O.parent/folder/n for n in names)
assert H(O.parent/'canonical_so10_even_probe_vertices/gauge_validation_receipt_v2.json')=='d8952be558c2aa73549f7829be3afaeb7f4e516811d95eb82ba0e7ac4e75b476'
for role in ['primary','replay']:
 p=K/(role+'_inputs.json.gz');assert H(p)==read(K/'validation_preparation_v2.json')['input_sha256'][str(p.resolve())];files.append(p);d=load(p)
 z={n:d[n] for n in ['names','parities','physical_G','gauge_fixing_density','frame','plane_f','Tminus']};z['extraction']='ACTUAL_CLASSICAL_INPUTS_ONLY_NO_COUNTERTERM_OR_UNKNOWN_QUANTUM_TARGET'
 dst=O/(role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 files.append(dst)
for folder,names,manifest in [('canonical_so10_probe_fermion_onejet',['primary_tables.json.gz','replay_tables.json.gz'],'validation_preparation.json'),('canonical_so10_ghost_triangle_field_insertion',['primary_tables.json.gz','replay_tables.json.gz','qualified_reference_inputs.json.gz'],'validation_preparation.json'),('canonical_so10_fermion_auxiliary_gauge_vertex',['replay_tables.json.gz'],'validation_preparation_v2.json')]:
 m=read(O.parent/folder/manifest)['input_sha256']
 for n in names:p=O.parent/folder/n;assert H(p)==m[str(p.resolve())];files.append(p)
for n in ['RECORD.md','build_native.py','native.py','prepare.py','verify.py','run.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 files.extend([p,O/(n+'.source.txt')])
b={str(p):H(p) for p in set(files)};nb={str(p):H(p) for p in [R/'AGENTS.md',R/'project_state.json',R/'tools/portable_dh_v1/inputs.json.gz',R/'tools/portable_dh_v1/exact_algebra.py',O/'native.py',O/'primary_inputs.json.gz',O/'replay_inputs.json.gz']}
with(O/'preparation.json').open('xb') as f:f.write((json.dumps({'base':base,'input_sha256':b,'native_input_sha256':nb,'limits':{'seconds_after_imports':300,'sampled_private_bytes':8*1024**3,'launch_floor':350*1024**2,'packet_bytes':16*1024**2},'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,separators=(',',':'))+'\n').encode())
print('PREPARED_RGS1',len(b))
