# RGS1/RBG1: the same candidate passes the complete first-rho*BPP test

Disposition: PROGRESS. The complete selected zero-ordinary-jet bare
evanescent-insertion coefficient has been calculated before its counterterm
comparison. It is NONZERO and matches the previously fixed QVC1 candidate
in all45 B directions, both probes and both chiralities. No candidate
coefficient was changed. This is a fourth selected projection of that one
functional, not a complete finite/QAP or physical unification theorem.

Base main8c4c8b242b3dd7254143e1d616a88c68582a17a0. Preflight recovered clean
tracked bytes and no matching live research Python workers;452 historical
bindings authenticate declared bytes only. State113/34of39 remains unchanged.
Historical custody remains exit2/seven unresolved references NOTPASS.

## Complete support and actual classical inputs

The previous checkpoint constructed C_full=C_probe-i u B barP gamma K P
from independently measured u*C*PP data. Its rho*BPP image -i K was a
COUNTERTERM image, not a quantum result. Testing it requires a new actual
calculation. The most economical route differentiates the unexpanded rho
triangle with respect to total B, rather than its already integrated jet.

RGS1 derives the full marginal probe quadratics/contact, old GF ghost
current and auxiliary cubic from authenticated classical densities. Raw
rows and physical columns of the inverse frame are distinct. All four
vector maps, dual ghost/auxiliary identities, Grassmann signs, repeated-B
multiplicities and Lorentz components are checked. Primary literal density
and replay full Euler routes agree, and late PFJ1/GTT1/FAV1 classical
limits agree with their actual coupling/phase/frame conventions.

The old constant-external-B ghost current has1340 nonzero color entries;
the auxiliary cubic has668. The light probe's rho aBB contact is0; the
heavy contact has668 entries with actual couplingg10*xi. The full raw
physical G scan includes source rows and positive-dimension terms before
their target-specific exclusion; no finite massive amplitude is set zero.

For a bridgeless unicyclic1PI graph every internal degree is2. With no
external ordinary ghost, Ihat supplies one physical external P and internal
C,S. The other P is on a matter vertex. The complete saturated possibilities
are an external B insertion on its fermion, ghost or bosonic edge, plus an
actual G aBB vertex. Bosonic insertions include pure-vector and nonlinear
auxiliary/vector cubics, with both mixed placements. Source nondynamical
restrictions do not delete later source derivatives. Scalar paths are
excluded by the actual marginal G/matter roles and positive-dimensional
coefficients, not by the external field names. The SMA/CPS action contains
no extra matter seagull; no physical interaction was invented.

| Typed family | Light probe | Heavy probe |
|---|---:|---:|
| Fermion edge | 4 | 4 |
| Ghost edge | 2 | 6 |
| Pure-vector edge | 4 | 6 |
| Auxiliary/vector edge | 2 | 4 |
| G aBB vertex | 0 | 2 |
| Total | 12 | 22 |

These are canonical typed support profiles, not multiplicity factors or
independent integrations. General cycle enumeration and independent forced
edge insertion agree on their full sets and degree0 UV power counting.
Removing mixed propagation loses7/12 profiles. A sector-changing insertion
can connect a free zero component: the finite control G01(0)=0 but
dG01/dz(0)=-1/2 for K=[[1,z],[z,2]] distinguishes the correct support rule.

## Ordered quantum calculation and full-D normalization

The exact same inherited mass-independent, nonexceptional Euclidean local
UV family is used. External ordinary jets and hats are0; internal hats and
full-D vector/ghost endpoints are retained. GTT/SMA full PS/SP numerators,
raw phases and analytic UV-rearrangement premises are authenticated REUSE,
not fresh unrestricted chiral/QAP proofs. An external family is I3 with
no extra3 or closed-line half.

Writing the measured rho quadratics as -i V_ar k_mu and i H_ar, define
D_ba=H_ab-W_bj V_aj with W=eta_H PH+xi PM. Direct ordered bosonic sewing
gives J_B=i D k/k^2 and J_Lambda=i V. Both Lambda signs are retained.
Differentiate the actual inverses using delta S=-S V_B S and
delta G=-G Gamma_B G. There is no new B vertex in Ihat. The fixed free
PS/SP products and physical PP inverse determine the fermion-edge response.

The correlated dimensional residues, in common1/(16pi^2) units, are

    I0=FP int hatk^2/(k^2+m^2)^3=-1/2,
    J delta_mu_nu=FP int hatk^2 kbar_mu kbar_nu/(k^2+m^2)^4=-delta/12.

Barred k^2 gives4J, while the FULL k^2 gives I0. Their difference
H4=I0-4J=-1/6 survives. The pure-vector Ward contraction is
k_nu V_(rho mu nu)=k_rho k_mu-k^2 delta_rho_mu, with full k^2.
Its left longitudinal response cancels exactly; its finite unit is I0-J.
Replacing k^2 by bark^2 incorrectly gives3J and changes the answer.
The temporary positive mass is local UV rearrangement only, not an adopted
physical mass or an assertion about finite nonlocal/infrared terms.

LOOP_RECORD.md freezes all six ordered contributions BEFORE execution:
fermion F, ghost G, pure-vector Y, two auxiliary placements L1/L2 and the
probe vertex C. All actual coupling powers and both endpoint orientations
are kept. The two auxiliary pieces are not two invented diagram families.

Primary uses literal barred Clifford/full-D curvature contractions,
dimensional h=-2epsilon residues and physical ordered matrix products.
Replay uses Schwinger moments, the transverse operator reduction, actual
Lie commutators and a different symmetric double-commutator color formula.
Both native workers are denied the old candidate and peer output. Only
after all322560 complete family/matrix positions agree, including zeros,
does the verifier read QVC1's fixed K. Right generators U=-T.T are used
directly; real-plane anti-Hermiticity and R_right=-R_left.T are checked.

## Measured outcome

The total is nonzero, with576/581 physical matrix positions per chirality
for the light/heavy probe, respectively. It has couplingg10^3 times the
corresponding width squared. No g10^2 or g10^4 contribution survives.
In real plane coordinates the exact result is

    R_rhoBPP = i K,
    R_rhoBPP + (C_full's rhoBPP image) = i K-i K=0.

K is the UNCHANGED matrix determined in the previous checkpoint; its715/720
plane positions and576/581 physical positions differ only by coordinates.
The independently computed new quantum result was not inferred from K.
Both probes, both chiralities and all45 directions have zero remainder.
The candidate's previously matched rho*PP, selected K_P-source and complete
u*C*PP p/q/s projections are unchanged. Their earlier evidence is reused,
not scientifically replayed by this new calculation.

| Physical coefficient positions per chirality | Light | Heavy |
|---|---:|---:|
| Fermion F | 516 | 581 |
| Ghost G | 108 | 581 |
| Pure-vector Y | 556 | 581 |
| Auxiliary L1 | 0 | 565 |
| Auxiliary L2 | 448 | 117 |
| Probe vertex C | 0 | 565 |
| Sum | 576 | 581 |

The heavy C and L1 pieces cancel exactly, though each is nonzero. Erasing
both is therefore INSENSITIVE, while erasing either changes565 positions.
This ordinary point vertex must not be confused with a renormalized finite
coincidence/contact normalization such as kappa. Other controls are sensitive:
wrong full-D/barred-only Y changes556/581; wrong angular moment516/581;
omitting the probe Lambda quadratic576/581; extra half/family3 changes
576/581. Every omitted individual nonzero family is detected. Full control
counts are in the receipt. No normalization constant was fitted or selected.

## Preserved failures and actual resources

Three frozen executions FAILED and remain so:

1. Original RGS primary treated raw and physical orders alike. The initial
   frame assertion stopped it before vertices. The correct convention already
   existed in qualified CGK native_v2/PFJ; repeating the failed historical
   generator's pattern was an avoidable reuse error. V2 fixes both matrix
   axes and full raw-density substitution without changing inputs.
2. RGS V2 native vertex arrays agreed, but its support verifier failed.
   Primary kept canceled-zero support keys; replay excluded sector-changing
   insertions by demanding a compatible free replaced edge. V3 cleans only
   exact zero keys and tests the final inserted cycle. V2 completed arrays
   remain completed-but-unqualified support evidence, with the failed gate.
3. Original RBG primary stopped before amplitudes because the polynomial
   helper expanded a rational2x2 inverse witness without canceling its
   denominator. V2 adds exact cancel only to that witness. Loop formulas,
   inputs, scientific comparisons and resource caps are unchanged.

All original sources/source copies, manifests, completed arrays and complete
native/controller captures are preserved. No failed run became PASS; new
versioned executions have their own completed receipts. No cap exhausted,
and no cap was silently expanded. No new preparer failed.

| Qualified stage | Seconds after imports | Samples | Max sampled private bytes |
|---|---:|---:|---:|
| RGS primary V3 | 19.6470919 | 11 | 262770688 |
| RGS replay V3 | 18.4210705 | 11 | 259223552 |
| RGS verifier V3 | 1.0874698 | 2 | 83116032 |
| RBG primary V2 | 72.7021956 | 38 | 74674176 |
| RBG replay V2 | 27.1989882 | 16 | 73011200 |
| RBG verifier V2 | 8.2142697 | 6 | 128204800 |

These are sampled observations, not continuous peaks. Original failed
captures have4/2/2 samples with189952000/42573824/57372672B maxima. RGS V2
P/R completed18.0793993/13.0724447s,10/8 samples,254185472/256299008B maxima;
their coefficients were not erased when their support gate failed.

RGS stages retain300s after-import caps; the distinct RBG continuation froze
600s per stage before computation. All use8GiB sampled-private ceilings,
350MiB available-commit launch floors and16MiB whole-packet ceiling. The
packet was1.44MB before result/handoff additions, with29 source copies.
Binding counts:61,79/87,102/110 (RGS versions),126,143/151 (RBG versions).

Receipt SHA256:

- RGS V3:e32a3f35a56b5ca40586b0b12edbdc0dad44291b942501ca2f1f7beaa2f5b81d
- RBG V2:bf39fa4237c5e50c534f714b76212c11d903df4682f18749d2db2d5ac36ad115

Current E4 readiness returns native0 and step exits[0,0,0,0,0,2]. Custody
exit2/seven remains NOTPASS. This is authenticated reuse of historical E4
science, not fresh replay or E5 acceptance. Complete captures and local
before/index/postcommit preservation seals are under
C:/Users/psboy/.codex/research-control-records/ToE-Next/
rho-vector-support-v1-2026-10-24/. Preserve all34852 previous tracked blobs
and the unchanged State113 hash through the local commit.

## Significance and next required test

This increment predicts and measures a previously unknown quantum companion
using the actual action, then finds it agrees with an already fixed common
candidate. That is stronger than constructing another permitted correction
after seeing a new remainder. It also exhibits sensitive full-D/hatted and
mixed-auxiliary checks. The preserved frame/support/rational failures expose
continued orchestration weaknesses; reading qualified executables rather
than stale generators is a concrete lesson for the AI-capability objective.

The methods share the action, field maps, universal operator formulas,
GTT/SMA normalization/domain, software and AI author. Agreement corroborates
the implementation and derivation within those premises; it is not external
scientific confirmation or validation of the physical model.

Next measure first-u*C*BPP at zero ordinary jets, whose source/gauge image
is already retained but whose quantum tensor is unknown. NEXT_UCBPP.md
identifies its actual vertex/support dependencies and keeps it distinct
from this completed rho test. Full finite/contact products, augmented
Ward/QAP, varying-background and real-time domains, measure/global phase,
massive fermion thresholds, physical unification and E5/A5 remain open.
kappa,b0,chi4 remain distinct/unselected; all prior scalar/benchmark/quartet
failures and flavor/HB1C5 boundaries stay protected. No physical scheme,
benchmark, foundation, canonical action or scientific promotion was adopted.
