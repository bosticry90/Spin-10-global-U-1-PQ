from pathlib import Path
from hashlib import sha256
import ast,gzip,json
O=Path(__file__).resolve().parent;R=O.parents[1]
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
old=read(O/'validation_preparation_v3.json')['input_sha256']
for p,h in old.items():assert H(Path(p))==h,p
v=read(O/'validation_receipt_v3.json');assert v['full_literal_Euler_vertices_and_profile_sets_agree'] and v['profile_counts']==[12,22] and v['late_PFJ_GTT_FAV_classical_limits_match']
b=dict(old)
for role in ['primary','replay']:
 src=O/(role+'_v3_tables.json.gz');d=load(src);base=load(O/(role+'_inputs.json.gz'))
 z={'vertices':{k:d[k] for k in ['probe_quadratics','rho_aBB','GF_auxiliary','GF_ghost_B','physical_f']},'frame':base['frame'],'Tminus':base['Tminus'],'support_profiles':d['profiles'],'extraction':'QUALIFIED_CLASSICAL_VERTICES_ONLY_NO_COUNTERTERM_OR_UNKNOWN_QUANTUM_TARGET'}
 dst=O/('loop_'+role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 b[str(src)]=H(src);b[str(dst)]=H(dst)
for n in ['LOOP_RECORD.md','loop.py','prepare_loop.py','verify_loop.py','run_loop.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
for p in [O/'validation_receipt_v3.json',O/'validation_preparation_v3.json',O.parent/'canonical_so10_even_probe_vertices/gauge_tables.json.gz',O.parent/'canonical_so10_even_probe_vertices/gauge_construction_receipt.json',O.parent/'canonical_so10_even_probe_vertices/gauge_validation_receipt_v2.json']:
 b[str(p)]=H(p)
q=read(O.parent/'canonical_so10_even_probe_vertices/gauge_construction_receipt.json');assert H(O.parent/'canonical_so10_even_probe_vertices/gauge_tables.json.gz')==q['packed_sha256']
nb={str(p):H(p) for p in [R/'AGENTS.md',R/'project_state.json',O/'loop.py',O/'loop_primary_inputs.json.gz',O/'loop_replay_inputs.json.gz']}
with(O/'loop_preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'native_input_sha256':nb,'limits':{'seconds_after_imports':600,'sampled_private_bytes':8*1024**3,'launch_floor':350*1024**2,'packet_bytes':16*1024**2},'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,separators=(',',':'))+'\n').encode())
print('PREPARED_RBG1',len(b))
