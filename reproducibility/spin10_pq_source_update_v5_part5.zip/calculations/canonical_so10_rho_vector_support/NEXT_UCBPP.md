# Next indispensable measured input: first-u*C*BPP, zero ordinary jets

RBG1 independently measures the complete rho*BPP bare insertion and matches
the SAME unmodified QVC1 candidate in both probes/chiralities. Its ordinary
u*C*BPP quantum companion is still unknown. Read the actual QUALIFIED
RGS1 native_v3/verify_v3 and RBG1 loop_v2/verify_loop_v2 with their receipts;
do not reuse a failed historical generator as the semantic reference.

This is a target note, not a frozen/executed continuation. Recover current
Git/process state and freeze the next actual question, methods, inputs and
limits before execution. The selected u*C*BPP local coefficient has degree0
in ordinary momenta by mass-independent dimension counting. Keep all45 ghost
and45 total-field B directions, both probes/chiralities, and full internal
hats. The known counterterm program is NOT a quantum measurement.

The economical route is an external-B derivative of the UNEXPANDED first-u
u*C*PP graph family. It requires the actual marginal uQG bosonic/ghost
cubics and any uQG aCBB quartic, in addition to the already measured local-u
quadratic/current vertices and the old GF/YM interactions. Determine these
from actual QG and complete field roles before excluding a family.

At this zero-jet target u may be constant only AFTER the transfer/jet bound
has been proved. Do not convert a nonzero local-u symbol into zero by
premature integration by parts. Likewise external-C momentum0 is not
permission to remove a raw hatted insertion before its full sewn blocks
and any external-B derivative are evaluated. A zero free PP block can
have nonzero mixed blocks; justify the actual projection with both raw
PS/SP placements. Do not assume full Q_full nilpotence at finite hats.

Differentiate all required internal fermion/ghost/boson propagators and
probe/ordinary vertices exactly once, with actual matrix order. The replaced
edge can connect H/M sectors whose FREE matrix element vanishes; require
compatibility only for the final inserted graph. Remove canceled exact-zero
coefficient keys before forming any support inventory. Preserve all nonzero
Lambda and full-D ghost-endpoint contributions. Read actual source/Euler
counterterm programs only AFTER independent complete quantum comparison.

If a remainder survives, first distinguish a calculation error, missing
operator family, insufficient same-functional candidate and an underdefined
renormalized construction. Do not fit an unknown quantum input, modify
previously matched sectors or call a partial counterterm-space failure an
anomaly. A full augmented Ward/QAP, measure/phase and physical matching
conclusion still needs the separate finite/contact/background/massive
obligations. No kappa,b0,chi4 value or physical scheme is selected.
