# SMC1: the necessary equation and the independent component action

YCT1 fixes [Ta,Tb]=i f_ab^d Td. On symmetric mass matrices,
L_a(M)=Ta.T M+M Ta has [L_a,L_b]=-i f_ab^d L_d,so A_a=iL_a is a
representation with [A_a,A_b]=f_ab^d A_d. On arbitrary scalar-to-mass maps,
D_aK=A_aK-Krho_a has the same Lie law. Expanding D(DK) gives0 by Jacobi
and that law. The overall sign of the counterterm equation does not alter
the necessary closedness condition. The actual inherited scalar rule is
qx=-g c^a rho_a x,and qM=-ig c^a L_a(M),with the fermion endpoints supplying
the compensating+iL action in a Yukawa density.

For measured r_b=R_bB,qualified B rho_a=A_aB implies
D_a r_b=(A_aR_b-R_bA_a)B. No scalar-generator truncation or replacement of
the physical scalar complement occurs. Apply the same equation to B10
and B126; general family matrices factor through. The antilinear conjugate
has Abar=conjugate(A),Rbar=conjugate(R),with real f. Thus the full operator
conjugation check supplies the conjugate condition without a new loop.

Primary forms A=i(Ta.T tensor I+I tensor Ta.T) in row-major convention and
uses exact sparse matrix multiplication. Replay never reads that measured
R packet: it rebuilds Omega from actual C,T and ordered endpoint products,
then adds i(xR M-MxL). For each R entry R_(ij),(kl)=z,its component
commutator [A_a,R] receives,for every w,

 output(w,j),input(k,l): +i Ta[i,w]z,
 output(i,w),input(k,l): +i Ta[j,w]z,
 output(i,j),input(w,l): -i z Ta[w,k],
 output(i,j),input(k,w): -i z Ta[w,l].

This is derived by expanding the two physical endpoint actions on the
input and output matrix indices. The complete four slots are retained.
All coefficients use the frozen exact rational multiquadratic polynomial
ring. No approximate rank test or numerical parameter specialization.

The control N is fixed independently of measured R,diagonal with weight
delta_i0+delta_j0 on M_ij. Its cochain [A,N] has proper cocycle0. The
oppositely oriented f term adds2 sum f[A,N]. Find the first pair whose
physical map of that term is nonzero,then compare the proper zero and
wrong-sign nonzero explicitly. This is a sensitive sign control,not a
target fit or physical normalization choice.

A nonzero first physical pair suffices to refute r=D K for ANY local
source-free K in this component; no counterterm-space completeness theorem
is needed for that necessary-condition counterexample. A source-dependent
term can contribute through physical Eulers and is outside that exclusion.
If all990 pairs vanish,the result is closedness only. Neither branch
promotes E5/A5 or supplies the full renormalized quantum prescription.
