"""SMC1 completed-route comparison and actual physical witness verification."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
for key in set(P)|set(R):
 if key not in ['role','elapsed_after_imports','method']:assert P[key]==R[key],key
assert not P['full_coupled_restoration_or_anomaly_claimed'] and not P['quantum_loops_rerun'] and P['all_45_conjugate_operator_remainders']==0 and P['general_family_factorization']
assert P['control']['proper_exact_cocycle_nonzero_positions']==0 and any(P['control']['wrong_f_sign_physical_nonzero_positions'])
assert P['source_omission_control']['unrestricted_operator_positions_changed']>0
pairs=list(combinations(range(45),2));assert len(pairs)==990
ss=P['pair_summaries'];assert len(ss)==P['scanned_pairs'] and [v['pair'] for v in ss]==[list(v) for v in pairs[:len(ss)]]
assert all(not any(v['physical_nonzero']) for v in ss[:-1])
T,BB,f=inputs('replay');I=ident(16);A=[scale(plus(kron(trans(t),I),kron(I,trans(t))),II) for t in T];fixed=list(map(dec,P['fixed_R']))
actual=packed(OSM/'comparison_tables.json.gz')['fixed_source_sum_operators']
for a in range(45):zero(minus(fixed[a],dec(actual['holomorphic'][a])));zero(minus(star(fixed[a]),dec(actual['antiholomorphic'][a])))
if P['closed']:
 assert len(ss)==990 and not any(ss[-1]['physical_nonzero']) and P['first_physical_witness'] is None
 disposition='QUALIFIED_COMPLETE_PHYSICAL_SCALAR_COCYCLE_CLOSED';witness_counts=None
else:
 assert any(ss[-1]['physical_nonzero']);w=P['first_physical_witness'];a,b=w['ghost_pair'];assert [a,b]==ss[-1]['pair']
 delta=minus(minus(minus(mul(A[a],fixed[b]),mul(fixed[b],A[a])),minus(mul(A[b],fixed[a]),mul(fixed[a],A[b]))),lie_sum(f,a,b,fixed))
 zero(minus(delta,dec(P['witness_operator'])))
 mm=[mul(delta,v) for v in BB];witness_counts=[len(m.d) for m in mm]
 assert witness_counts==ss[-1]['physical_nonzero']
 for ri,m in enumerate(mm):
  zero(minus(m,dec(P['witness_holomorphic_maps'][ri])));zero(minus(star(m),dec(P['witness_antiholomorphic_maps'][ri])))
 ri=['B10','B126'].index(w['carrier']);i,j=w['matrix_indices'];assert mm[ri].d[i*16+j,w['scalar_column']]==Q(w['coefficient']) and Q(w['coefficient'])
 disposition='QUALIFIED_NONCLOSED_SCALAR_REMAINDER_FIELD_ONLY_COMPLETION_EXCLUDED'
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_SCALAR_MATTER_COCYCLE_TEST','disposition':disposition,'elapsed_after_imports':time.perf_counter()-start,'scanned_pairs':P['scanned_pairs'],'closed_on_complete_actual_carriers':P['closed'],'first_physical_witness':P['first_physical_witness'],'witness_physical_counts_per_chirality':witness_counts,'control':P['control'],'source_omission_control':P['source_omission_control'],'fixed_R_operator_positions_compared':45*256*256,'all45_conjugate_operator_remainders':0,'source_free_mass_map_completion_excluded':not P['closed'],'full_coupled_prescription_excluded':False,'quantum_loops_rerun':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
