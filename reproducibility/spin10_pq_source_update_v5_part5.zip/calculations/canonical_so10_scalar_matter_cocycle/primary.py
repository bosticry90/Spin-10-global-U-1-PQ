"""SMC1 measured full superoperators and direct exact commutators."""
from data import *
start=begin('primary');T,BB,f=inputs('primary');I=ident(16)
A=[scale(plus(kron(trans(t),I),kron(I,trans(t))),II) for t in T]
d=packed(OSM/'comparison_tables.json.gz');R=list(map(dec,d['fixed_source_sum_operators']['holomorphic']));anti=list(map(dec,d['fixed_source_sum_operators']['antiholomorphic']))
for a in range(45):zero(minus(anti[a],star(R[a])))
def comm(a,r):return minus(mul(A[a],r),mul(r,A[a]))
out=run_scan(R,A,BB,f,comm);out.update({'method':'measured_unrestricted_operators_direct_sparse_superoperator_commutators','fixed_R':list(map(enc,R)),'all_45_conjugate_operator_remainders':0,'general_family_factorization':True})
finish('primary',out,start)
