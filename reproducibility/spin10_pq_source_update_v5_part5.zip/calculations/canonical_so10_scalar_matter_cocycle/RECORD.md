# SMC1: necessary scalar-matter consistency before counterterm construction

Base c26ffe38d1df768662908dd25d67a562f4ddc3b8/main31681 tracked blobs.
Current goal turn PROGRESS:ASB1/OSM1; whole Spin(10)xPQ ACTIVE/incomplete.
State113/authority34of39 unchanged. Live AGENTS standing delegation applies.

Question: can the complete OSM1 scalar remainder, after its already fixed
MSP1 source term, be the Ward image of a source-free local Yukawa correction?
This is a necessary consistency test,not a new quantum integral or a fit.
It may rule out that field-only completion,or qualify closedness before a
subsequent admissible primitive construction. Neither outcome establishes
the full coupled source prescription,QAP or an anomaly of the physical model.

OSM1 final receipt529cd63e... fixes R_a(M)=Omega_a(M)+source_a(M) independently
of this test. Its150272 nonzero positions per chirality are not adjustable.
Use the exact complete fixed-source operators and independently reconstruct
them from OSM1 replay C,actual YCT T and fixed MSP1 upper X^[4]. Retain all45
generators,all328 scalar coordinates,both actual B10/B126 maps,both
chiralities,general symmetric families,formal real eta_H/xi and g grading.
Auxiliary g2Y remainder is already0; ordinary g3Y is tested at g4Y after q.
Positive-dimension,derivative,background and massive physical sectors remain
separate. No finite baseline or physical flavor point is chosen.

For L_a(M)=Ta.T M+M Ta set A_a=i L_a. Qualified actual Lie/covariance gives
[A_a,A_b]=f_ab^d A_d and B rho_a=A_a B. For any local mass map K the action
is D_a K=A_a K-K rho_a. Its image r_a=D_a K necessarily obeys
D_a r_b-D_b r_a-f_ab^d r_d=0. Since measured r_a=R_a B, test
([A_a,R_b]-[A_b,R_a]-sum_d f_ab^d R_d)B=0.

The zero-jet,dimension-four cxPP projection of a source-free counterterm
can arise only from its xPP component: qP,qscalar are homogeneous gauge
actions; qB has a ghost derivative or vector; nonminimal rules have no
matter Euler. Ordinary derivatives/IBP preserve total jet degree and
positive-dimension terms cannot enter this graded component without
forbidden inverse inputs. Thus a nonzero physical cocycle witness excludes
even the unrestricted source-free mass-map completion,including every
admissible H/PQ/reality subspace. It does not exclude source-dependent
counterterms and their matter Euler contributions,which are the unresolved
coupled obligation. This is not a full local-cohomology classification or
activation of HB1/C5.

Primary: direct sparse superoperator commutators of the measured full R.
Replay: reconstruct R from ordered color contractions/endpoints/source;
apply A commutators by explicit four-index events,not primary's matrix
products. Both scan canonical unordered ghost pairs lexicographically.
For each pair evaluate both complete physical scalar maps. Stop at the
FIRST nonzero physical pair,which is a complete necessary-condition
counterexample,or exhaust all990 for a complete physical closedness result.
An unrestricted nonzero operator alone is insufficient; both actual scalar
maps must be evaluated before a verdict. All preceding tested pairs and
their full zero complements are retained through counts/hashes. On a
nonzero pair store complete operator and both physical maps,conjugates,
and an exact first coefficient witness. No selected zero is called full
closedness. Resource exhaustion remains INCOMPLETE,no receipt.

Controls: use the fixed algebraic test correction N(M)=E00 M+M E00.
Its exact cochain [A_a,N] must have zero proper cocycle; reversing the f
sign must give a nonzero physical image on a deterministically selected
first sensitive pair. This fixes signs independently of the actual R.
Retain actual source-omission sensitivity without assuming it is always
visible in the cocycle. Verify all full R conjugation/mass transpose
relations and peer operators/maps. Shared exact-ring arithmetic is frozen
OSM1 reuse; the two routes share action,data,assumptions and AI authorship,
not independent scientists. No new literature premise or physical scheme.

Freeze eight source files/copies and exact inputs before sequential
primary/replay/gate. Each600s afterimports,8GiB sampled private cap,
350MiB available-commit launch floor,16MiB total packet. Stop first
failure,preserve complete captures,no silent expansion/truncation. Fresh
read-only byte preflight; earlier ASB1 E4 command this goal turn is
authenticated reuse,not another scientific replay. Custodyexit2/seven
NOTPASS. Maintain source/state/evidence,main,flavor pause,HB1/C5 blocks,
quartetFAIL and both adverse scalar benchmarks. No agents,new branch/
worktree,outreach,publication,push or scientific promotion.

Expected dispositions: QUALIFIED_NONCLOSED_SCALAR_REMAINDER_FIELD_ONLY
COMPLETION_EXCLUDED,or QUALIFIED_COMPLETE_PHYSICAL_SCALAR_COCYCLE_CLOSED.
Closed does not mean exact,admissible or physically accepted. Nonclosed
means this fixed-input field-only route is insufficient,not model failure.
Next decision: coupled source/Euler completion if nonclosed; admissible
finite primitive/domain test if closed. Keep unknown quantum inputs fixed
or explicitly missing; do not fit them to rescue a desired conclusion.
