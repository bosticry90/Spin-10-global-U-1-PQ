"""SMC1 frozen IO, exact arithmetic reuse and common complete scan protocol."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from itertools import combinations
import gzip,json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
OSM=CAL/'canonical_so10_ordinary_scalar_matter_breaking'
sys.path.insert(0,str(OSM))
from exact_ring_v4 import *
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def begin(role):
 start=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start()
 assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and p.name.startswith(peer):raise PermissionError('SMC1_PEER_DENIED')
   if role=='replay' and p.parent.resolve()==OSM and p.name in ['primary_tables.json.gz','comparison_tables.json.gz']:raise PermissionError('SMC1_MEASURED_OPERATOR_PACKET_DENIED_TO_REPLAY')
 sys.addaudithook(audit);return start
def inputs(role):
 y=packed(CAL/('canonical_so10_yukawa_carrier_transport/'+role+'_tables.json.gz'));T=list(map(dec,y['Tminus']));BB=[dec(y[k]) for k in ['B10','B126']]
 f=defaultdict(list)
 for a,b,c,z in packed(CAL/'canonical_so10_ghost_triangle_field_insertion/qualified_reference_inputs.json.gz')['reference_fields']['plane_f']:f[a,b].append((c,Q(z)))
 return T,BB,f
def lie_sum(f,a,b,ops):
 out=Mat(256,256)
 for d,z in f[a,b]:out=plus(out,scale(ops[d],z))
 return out
def source_control(BB):
 d=packed(CAL/'canonical_so10_matter_source_primitive/primary_tables.json.gz');I=ident(16);nn=0;physical=[0,0]
 for l,r in zip(d['X_left']['4'],d['X_right']['4']):
  xl=scale(dec(l),neg(II));xr=scale(dec(r),neg(II));ss=scale(minus(kron(xr,I),kron(I,trans(xl))),II);nn+=len(ss.d)
  for ri,b in enumerate(BB):physical[ri]+=len(mul(ss,b).d)
 assert nn and any(physical)
 return {'unrestricted_operator_positions_changed':nn,'physical_positions_changed':physical}
def run_scan(R,A,BB,f,comm):
 # Input matrices are the entire fixed map; the shared loop never assigns
 # a quantum or source coefficient. Distinct routes supply distinct comm.
 pairs=list(combinations(range(45),2));assert len(pairs)==990
 N=Mat(256,256,{(i*16+j,i*16+j):Q(int(i==0)+int(j==0)) for i in range(16) for j in range(16) if i==0 or j==0})
 exact=[comm(a,N) for a in range(45)];control=None
 for a,b in pairs:
  ff=lie_sum(f,a,b,exact);wrong=[mul(scale(ff,Q(2)),v) for v in BB]
  if any(m.d for m in wrong):
   zero(minus(minus(comm(a,exact[b]),comm(b,exact[a])),ff))
   zero(minus(minus(mul(A[a],A[b]),mul(A[b],A[a])),lie_sum(f,a,b,A)))
   control={'pair':[a,b],'proper_exact_cocycle_nonzero_positions':0,'wrong_f_sign_physical_nonzero_positions':[len(m.d) for m in wrong]};break
 assert control is not None
 summaries=[];witness=None;Cstored=None;maps=None
 for a,b in pairs:
  C=minus(minus(comm(a,R[b]),comm(b,R[a])),lie_sum(f,a,b,R))
  mm=[mul(C,v) if C.d else Mat(256,328) for v in BB]
  hashes=[sha256(json.dumps(enc(m),sort_keys=True).encode()).hexdigest() for m in mm]
  summaries.append({'pair':[a,b],'unrestricted_operator_nonzero':len(C.d),'physical_nonzero':[len(m.d) for m in mm],'physical_map_sha256':hashes})
  if any(m.d for m in mm):
   ri=next(i for i,m in enumerate(mm) if m.d);key=sorted(mm[ri].d)[0];flat,col=key
   witness={'ghost_pair':[a,b],'carrier':['B10','B126'][ri],'matrix_indices':[flat//16,flat%16],'scalar_column':col,'coefficient':textq(mm[ri].d[key])};Cstored=enc(C);maps=[enc(m) for m in mm];break
  if len(summaries)%100==0:print('STAGE COMPLETE_SCALAR_COCYCLE_PAIRS',len(summaries),flush=True)
 closed=witness is None
 assert closed and len(summaries)==990 or not closed and summaries[-1]['pair']==witness['ghost_pair']
 return {'closed':closed,'scanned_pairs':len(summaries),'pair_summaries':summaries,'first_physical_witness':witness,'witness_operator':Cstored,'witness_holomorphic_maps':maps,'witness_antiholomorphic_maps':[enc(star(dec(m))) for m in maps] if maps else None,'control':control,'source_omission_control':source_control(BB)}
def finish(role,d,start):
 d.update({'role':role,'elapsed_after_imports':time.perf_counter()-start,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','full_coupled_restoration_or_anomaly_claimed':False,'quantum_loops_rerun':False})
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':d['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw),'closed':d['closed'],'scanned_pairs':d['scanned_pairs']},sort_keys=True),flush=True)
