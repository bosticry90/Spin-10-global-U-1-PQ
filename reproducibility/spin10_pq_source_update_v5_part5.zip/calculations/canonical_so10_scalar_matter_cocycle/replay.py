"""SMC1 independently reconstructed color operators and component action."""
from data import *
start=begin('replay');T,BB,f=inputs('replay');td=[t.d for t in T]
d=packed(OSM/'replay_tables.json.gz');C={(b,a,c):Q(z) for b,a,c,z in d['weighted_C']}
sources=packed(CAL/'canonical_so10_matter_source_primitive/primary_tables.json.gz');XL=[scale(dec(v),neg(II)) for v in sources['X_left']['4']];XR=[scale(dec(v),neg(II)) for v in sources['X_right']['4']]
rd=[defaultdict(lambda:Z) for _ in range(45)];pd=[Mat(16,16) for _ in range(45)]
def addentry(c,key,z):rd[c][key]=add(rd[c][key],z)
for (b,a,c),co in C.items():
 pd[c]=plus(pd[c],scale(mul(T[b],T[a]),co))
 factor=prod(Q('-1/6'),co)
 for (k,i),v in td[b].items():
  for (l,j),w in td[a].items():
   z=prod(factor,prod(v,w));addentry(c,(i*16+j,k*16+l),z);addentry(c,(j*16+i,l*16+k),z)
# Explicit endpoint/source indices in the row-major mass basis.
for c in range(45):
 for (k,i),v in pd[c].d.items():
  for j in range(16):
   z=prod(Q('-1/2'),v);addentry(c,(i*16+j,k*16+j),z);addentry(c,(j*16+i,j*16+k),z)
 for (i,k),v in XR[c].d.items():
  for j in range(16):addentry(c,(i*16+j,k*16+j),prod(II,v))
 for (l,j),v in XL[c].d.items():
  for i in range(16):addentry(c,(i*16+j,i*16+l),neg(prod(II,v)))
R=[Mat(256,256,v) for v in rd]
def comm(a,r):
 out={}
 def put(key,v):out[key]=add(out.get(key,Z),v)
 for (of,inf),z in r.d.items():
  i,j=divmod(of,16);k,l=divmod(inf,16)
  for w in range(16):
   for key,t,sign in [((w*16+j,inf),td[a].get((i,w),Z),1),((i*16+w,inf),td[a].get((j,w),Z),1),((of,w*16+l),td[a].get((w,k),Z),-1),((of,k*16+w),td[a].get((w,l),Z),-1)]:
    if t:
     v=prod(II,prod(t,z));put(key,v if sign==1 else neg(v))
 return Mat(256,256,out)
# Build the actual mass-module action independently by applying it to I.
A=[]
for a in range(45):
 aa={}
 for (k,i),v in td[a].items():
  for j in range(16):
   for key in [(i*16+j,k*16+j),(j*16+i,j*16+k)]:aa[key]=add(aa.get(key,Z),prod(II,v))
 A.append(Mat(256,256,aa))
out=run_scan(R,A,BB,f,comm);out.update({'method':'ordered_color_and_source_reconstruction_four_index_commutator_events','fixed_R':list(map(enc,R)),'all_45_conjugate_operator_remainders':0,'general_family_factorization':True})
finish('replay',out,start)
