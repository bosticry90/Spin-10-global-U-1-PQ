"""PSF1 typed source orders and generic two-sided source-Euler image."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import gzip,json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_ordinary_scalar_matter_breaking'))
from exact_ring_v4 import *
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def begin(role):
 start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
 assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and p.name.startswith(peer):raise PermissionError('PSF1_PEER_DENIED')
 sys.addaudithook(audit);return start
def source_images(source,T,U):
 out={}
 for order,parts in source.items():
  out[order]={}
  for part,sides in parts.items():
   out[order][part]={}
   for side,other,ts in [('left','right',T),('right','left',U)]:
    this=list(map(dec,sides[side]));opp=list(map(dec,sides[other]));pp=[];qq=[];gg=[]
    for c,m in enumerate(this):
     pp.append(enc(scale(plus(m,trans(opp[c])),II)));qq.append(enc(scale(m,II)))
     for b,t in enumerate(ts):
      v=scale(plus(mul(trans(opp[c]),t),mul(t,m)),neg(II))
      if v.d:gg.append([b,c,enc(v)])
    out[order][part][side]={'p':pp,'q':qq,'gauge':gg}
 return out
def triple_dict(rows):return {(a,b,c):Q(z) for a,b,c,z in rows}
def check_derivatives(mvs):
 a=triple_dict(mvs['raw_antighost_jet']);b=triple_dict(mvs['raw_vector_jet']);v=triple_dict(mvs['raw_effective_vertex']);assert {k:sub(a.get(k,Z),b.get(k,Z)) for k in set(a)|set(b) if sub(a.get(k,Z),b.get(k,Z))}==v
 return {'antighost_positions':len(a),'vector_positions':len(b),'complete_effective_positions':len(v)}
def finish(role,d,start):
 d.update({'role':role,'elapsed_after_imports':time.perf_counter()-start,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','comparison_member':'RAW_DIMENSIONAL_MINUS_COMMON_SCALAR_HEAT_LENGTH6_LOCAL_UV','proper_source_families':2,'source_overall_factors':{'ordinary':'g10^3/(16*pi^2)','auxiliary':'g10^2*xi/(16*pi^2)'},'auxiliary_xi_factored_out_exactly_once':True,'physical_scheme_adopted':False,'quantum_coefficient_fitted':False,'full_coupled_restoration_claimed':False,'new_model_color_integrations':0,'other_source_hatted_scalar_images':'UNCOMPUTED_RETAINED_OBLIGATIONS'})
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':d['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
