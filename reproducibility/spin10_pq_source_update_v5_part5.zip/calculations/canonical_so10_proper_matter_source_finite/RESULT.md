# PSF1: both proper matter-source local finite families are constructed

Primary, independent replay and separate gate completed native0. Receipt
validation_receipt.json SHA256:
a7391732aed88f1d985ac99b90a142b1bf7bddf740e1fc7e751338d0643d6211.
Status QUALIFIED_COMPLETE_TWO_FAMILY_PROPER_SOURCE_LOCAL_FINITE_COMPARISON.
Scientific/director acceptance NOT_PERFORMED; state113/34of39 unchanged.

For both required proper source orders,the local relative amplitude is

 M_relative=[chi4+log(3/2)+1/2]*M_measured_pole.

The ordinary source has outer g10³/(16pi²),with both symbolic widths retained
inside its matrix. The auxiliary source has outer g10²*xi/(16pi²),with xi
factored out exactly once. These are distinct polynomial coupling orders.
The auxiliary result is reproduced exactly from MAF;the ordinary family is
new. All138240 source coefficient positions,including zeros,agree between
the two routes. No finite coefficient was chosen from a symmetry target.

The ordinary derivation uses its actual full longitudinal vector inverse
and bar_slash/Q fermion numerator. G_BB k=Wk is contracted in the full
internal space before restricting the gauge endpoint to four barred indices.
The complete source unit is+4/D,whose finite dimension unit is+1/2.
A prematurely barred derivative contraction is demonstrably different at
nonzero hats. The reference retains internal hats;no full-slash replacement
or positive-rank witness is taken as a physical particle multiplicity.

The actual old derivative tensors are independently checked:870 antighost
and180 vector entries per temporal component combine into690 effective
entries. This preserves all3480/720 actual four-component derivative
placements and their routing sign VA-VB. Symmetric/nonadjoint current
products and both widths are retained. The old independent color routes
are authenticated reuse,not new model integrations. Replay checks the
actual rank4 Schwinger/Gamma finite comparison with a common IR completion.

## Generic source images are essential

For arbitrary source blocks ML,MR,the gauge Euler image is

 left=-i(MR.T*T_b+T_b*ML),
 right=-i(ML.T*U_b+U_b*MR), U=-T.T.

Direct odd-left density variation and independent Clifford congruence agree
before actual quantum matrices are inserted. The source p/q slots are
p_L=i(ML+MR.T),q_L=iML,with the corresponding right expressions.
The auxiliary shortcut [iML,T_b] applies only when MR=-ML.T. It is invalid
for the complete ordinary source. Replacing the generic formula by that
shortcut changes23040 ordinary gauge-image positions in each finite
direction;the exact missing term is-p_L*T_b. The auxiliary control is
correctly insensitive and its previously qualified images remain identical.

| Source family | Source nonzeros/chirality | p image | q image | Gauge image |
| --- | ---: | ---: | ---: | ---: |
| ordinary g10³ | 720 | 512 | 720 | 28,416 |
| auxiliary g10²*xi | 592 | 0 | 592 | 19,008 |

These counts hold for each chi4/log(3/2)/fixed direction. They count algebraic
positions,not independent experiments. Full tables retain all zeros.
Both chiral blocks are calculated,not inferred by imposing an inappropriate
anti-Hermitian source restriction. Actual reality MR=ML* gives
p_L^dag=-p_L,q_L^dag=q_L-p_L,p_R=p_L.T,q_R=(p_L-q_L).T,and the gauge image
is anti-Hermitian with right=-left.T. All relations and3240 H-cochain
coefficient checks pass. The nonzero ordinary p component is preserved.

Other scalar,hatted and highest-source descendants are not qualified by
these projections. The boundary-current/source-Euler convention remains
the existing CLO/MSP operation;the elementary qK=0 rule is not replaced.

## Scope,execution and next calculation

This completes two proper source INPUT families in the declared zero-jet,
coefficient-dimension-zero,Euclidean raw-dimensional-minus-common-scalar-
heat comparison member. It is not completion of all source products or a
coupled Slavnov identity. The heat member is not an adopted or uniquely
historical physical chiral regulator,measure,scheme or full QAP. No claim
that Q commutes with a gamma5 dimension lift is used. The common chi4 and
all other distinct free normalizations remain symbolic.

P/R/gate completed in12.6720055/13.1025836/14.7952218s after imports,each
native0,with no new failed worker/verifier. Their8/8/9 sampled private
maxima137498624/131670016/227344384 bytes are observations,not peaks.
Frozen600s/8GiB sampled/350MiB available-commit floor/16MiB stored-packet
bounds held. Eight source copies,1133 preparation/1141 validation bindings
and full captures remain. THIS-goal-turn LSF fresh E4 honestly reused;
fresh byte preflight,custodyexit2/seven NOTPASS. State/old evidence unchanged.

Track B demonstrates finite input completion with independent tensor/integral
and generic-image derivations. It also shows why a valid special-case formula
must not be promoted to a broader operation without checking its premises.
Shared action,old independently measured color data,Clifford/reference
assumptions,exact software and AI author remain common-error limits.

Next:derive the actual source-free fermion kinetic heat/dimensional finite
comparison. It requires its two-propagator heat length4,positive heat Taylor
jets and fixed barred rank,not the source triangle length6. Keep gauge
Feynman/longitudinal and factorized general-family Yukawa pieces separately.
Use full-D angular numerators and an independent nonexceptional integral
comparison before combining actual kinetic color matrices. That supplies
the missing p-slot input;proper gauge-vertex finite conversion then controls
the q slot. Do not fit either from the desired source cancellation or repeat
the already refuted unchanged direct sum.

Full coupled/chiral restoration,QAP/products/measure/phase,physical scheme,
massiveC1,E5/A5 and physical GUT remain unqualified. Bothscalarwarnings,
quartetFAIL,flavorpause,HB1/C5blocks,custody and distinct freeconstants remain.
No physical benchmark,state change,branch/worktree,publication/outreach/push.
