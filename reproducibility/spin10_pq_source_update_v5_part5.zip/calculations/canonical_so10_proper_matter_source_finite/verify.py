"""PSF1 complete two-family source comparison and generic source reality."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');d=packed(HERE/'primary_inputs.json.gz')
for k in ['ordinary_unit_D','ordinary_UV_unit','ordinary_fixed_unit','ordinary_fixed_to_pole_ratio','derivative_counts','generic_gauge_derivation_remainder','wrong_barred_longitudinal_truncation_sensitive','source_matrices','source_Euler_images','source_overall_factors','auxiliary_xi_factored_out_exactly_once']:assert P[k]==R[k],k
assert P['ordinary_unit_D']=='4/D' and P['ordinary_UV_unit']=='1' and P['ordinary_fixed_unit']=='1/2' and P['ordinary_fixed_to_pole_ratio']=='1/2' and P['generic_gauge_derivation_remainder']==0
assert P['source_matrices']['auxiliary']==d['MAF']['source_matrices'] and P['source_Euler_images']['auxiliary']==d['MAF']['source_Euler_images']
T=list(map(dec,d['Y']['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];HF=dec(d['Y']['H_new']);f=defaultdict(list)
for a,b,e,z in d['plane_f']:f[a,b].append((e,Q(z)))
counts={};positions=0;covariance_checks=0;wrong_shortcut={}
for order,parts in P['source_matrices'].items():
 counts[order]={};wrong_shortcut[order]={}
 for part,sides in parts.items():
  counts[order][part]={};left=list(map(dec,sides['left']));right=list(map(dec,sides['right']));assert len(left)==len(right)==45
  for l,r in zip(left,right):zero(minus(r,star(l)))
  ims=P['source_Euler_images'][order][part];pL=list(map(dec,ims['left']['p']));qL=list(map(dec,ims['left']['q']));pR=list(map(dec,ims['right']['p']));qR=list(map(dec,ims['right']['q']))
  for p,q,pr,qr in zip(pL,qL,pR,qR):zero(plus(p,trans(star(p))));zero(minus(trans(star(q)),minus(q,p)));zero(minus(pr,trans(p)));zero(minus(qr,trans(minus(p,q))))
  gl={(b,c):dec(m) for b,c,m in ims['left']['gauge']};gr={(b,c):dec(m) for b,c,m in ims['right']['gauge']};assert set(gl)==set(gr)
  for k,m in gl.items():zero(plus(m,trans(star(m))));zero(plus(gr[k],trans(m)))
  for side,ms in [('left',left),('right',right)]:counts[order][part][side]={'source':sum(len(m.d) for m in ms),'p':sum(len(dec(m).d) for m in ims[side]['p']),'q':sum(len(dec(m).d) for m in ims[side]['q']),'gauge':sum(len(dec(m).d) for b,c,m in ims[side]['gauge'])};positions+=45*16**2
  for h in range(12):
   th=Mat(16,16);fh=defaultdict(lambda:Z)
   for a in range(45):
    z=HF.d.get((a,h),Z)
    if z:
     th=plus(th,scale(T[a],z))
     for c in range(45):
      for e,v in f[a,c]:fh[c,e]=add(fh[c,e],prod(z,v))
   for c,m in enumerate(qL):
    res=scale(minus(mul(th,m),mul(m,th)),neg(II))
    for (cc,e),v in fh.items():
     if cc==c:res=minus(res,scale(qL[e],v))
    zero(res);covariance_checks+=1
  changed=0
  for c,m in enumerate(qL):
   for b,t in enumerate(T):
    special=minus(mul(m,t),mul(t,m));diff=minus(gl.get((b,c),Mat(16,16)),special);changed+=len(diff.d)
    # The precise omitted two-sided term is -p*T,not an arbitrary mismatch.
    zero(plus(diff,mul(pL[c],t)))
  wrong_shortcut[order][part]=changed
  old=d['MVS'] if order=='ordinary' else None
  if old:
   for side in ['left','right']:
    for actual,pole in zip(sides[side],old['loop_'+side]):zero(minus(dec(actual),scale(dec(pole),Q('1/2') if part=='fixed' else ONE)))
assert positions==138240 and covariance_checks==3240
assert all(counts['ordinary'][p]['left']['p']>0 and wrong_shortcut['ordinary'][p]>0 for p in ['chi4','log3over2','fixed'])
assert all(counts['auxiliary'][p]['left']['p']==0 and wrong_shortcut['auxiliary'][p]==0 for p in ['chi4','log3over2','fixed'])
assert P['source_overall_factors']=={'ordinary':'g10^3/(16*pi^2)','auxiliary':'g10^2*xi/(16*pi^2)'} and P['auxiliary_xi_factored_out_exactly_once']
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
for x in [P,R]:assert x['proper_source_families']==2 and not any(x[k] for k in ['physical_scheme_adopted','quantum_coefficient_fitted','full_coupled_restoration_claimed','new_model_color_integrations'])
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_TWO_FAMILY_PROPER_SOURCE_LOCAL_FINITE_COMPARISON','elapsed_after_imports':time.perf_counter()-start,'proper_source_families':2,'source_coefficient_positions_compared':positions,'H_cochain_coefficient_checks':covariance_checks,'ordinary_angular_unit':P['ordinary_unit_D'],'ordinary_fixed_unit':P['ordinary_fixed_unit'],'common_finite_to_pole_fixed_ratio':'1/2','source_and_image_nonzero_counts':counts,'incorrect_auxiliary_gauge_shortcut_changes_positions':wrong_shortcut,'actual_nonadjoint_p_image_retained':True,'generic_gauge_Euler_identity_remainders':0,'all_coefficients_and_zero_complements_match':True,'physical_reality_and_right_relations_checked':True,'auxiliary_MAF_reproduced_exactly':True,'derivative_counts':P['derivative_counts'],'wrong_barred_longitudinal_truncation_sensitive':True,'source_overall_factors':P['source_overall_factors'],'auxiliary_xi_factored_out_exactly_once':True,'comparison_member':P['comparison_member'],'sourcefree_kinetic_and_vertex_finite_comparison_completed':False,'other_scalar_hatted_and_highest_source_images_qualified':False,'physical_scheme_adopted':False,'quantum_coefficient_fitted':False,'full_coupled_restoration_claimed':False,'scientific_authority_changed':False,'full_QAP_measure_phase_massiveC1_E5A5_unification_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
