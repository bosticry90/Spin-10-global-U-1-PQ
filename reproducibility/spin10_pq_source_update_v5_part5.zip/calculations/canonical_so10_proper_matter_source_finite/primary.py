"""PSF1 complete ordinary longitudinal numerator and odd-left generic density."""
from data import *
start=begin('primary');D=sy.Symbol('D');w=sy.Symbol('unfixed_width');k=sy.Matrix(sy.symbols('k0:6'));norm=(k.T*k)[0];projector=sy.eye(6)+(w-1)*k*k.T/norm
for mu in range(4):assert sy.factor((projector*k)[mu]-w*k[mu])==0
wrong=sy.factor(sum(projector[0,nu]*k[nu] for nu in range(4))-w*k[0]);assert wrong!=0
pa=[sy.Matrix([[0,1],[1,0]]),sy.Matrix([[0,-sy.I],[sy.I,0]]),sy.diag(1,-1)];gam=[sy.kronecker_product(pa[1],m) for m in pa]+[sy.kronecker_product(pa[0],sy.eye(2))];bar=sum((k[i]*g for i,g in enumerate(gam)),sy.zeros(4));assert not (bar*bar-sum(k[i]**2 for i in range(4))*sy.eye(4)).applyfunc(sy.expand).todok()
phase=sy.I*(-sy.I)*(-sy.I)*sy.I*(-sy.I*sy.I);assert phase==1
unit=4/D;uv=unit.subs(D,4);fixed=-2*sy.diff(unit,D).subs(D,4);ratio=sy.simplify(fixed/uv)
# Generic left odd density: qbar=c bar MR.T, qP=c ML P. Do not replace MR.
ML=sy.Matrix(2,2,sy.symbols('ml0:4'));MR=sy.Matrix(2,2,sy.symbols('mr0:4'));Tb=sy.Matrix(2,2,sy.symbols('t0:4'))
def word(seq,co=1):
 if len(set(seq))!=len(seq):return {}
 sg=(-1)**sum(seq[i]>seq[j] for i in range(len(seq)) for j in range(i+1,len(seq)));return {tuple(sorted(seq)):sg*co}
def accum(out,p):
 for k0,v in p.items():out[k0]=sy.expand(out.get(k0,0)+v)
actual={};expected={}
for i in range(2):
 for j in range(2):
  for a in range(2):
   accum(actual,word([0,1+a,3+j],-sy.I*MR.T[a,i]*Tb[i,j]))
   accum(actual,word([1+i,0,3+a],sy.I*Tb[i,j]*ML[j,a]))
gauge=-sy.I*(MR.T*Tb+Tb*ML)
for i in range(2):
 for j in range(2):accum(expected,word([0,1+i,3+j],gauge[i,j]))
assert actual==expected
d=packed(HERE/'primary_inputs.json.gz');mvs=d['MVS'];assert sy.sympify(mvs['angular_unit'],locals={'d':D})==unit and mvs['UV_unit']=='1' and mvs['formal_order']=='g10^3'
derivative_counts=check_derivatives(mvs);source={'ordinary':{},'auxiliary':d['MAF']['source_matrices']}
for part,z in [('chi4',Q(1)),('log3over2',Q(1)),('fixed',Q(str(ratio)))]:source['ordinary'][part]={side:[enc(scale(dec(m),z)) for m in mvs['loop_'+side]] for side in ['left','right']}
T=list(map(dec,d['Y']['Tminus']));U=[scale(trans(t),Q(-1)) for t in T]
finish('primary',{'method':'full_projector_before_barred_endpoint_Djet_and_generic_odd_density','ordinary_unit_D':str(unit),'ordinary_UV_unit':str(uv),'ordinary_fixed_unit':str(fixed),'ordinary_fixed_to_pole_ratio':str(ratio),'derivative_counts':derivative_counts,'generic_gauge_derivation_remainder':0,'wrong_barred_longitudinal_truncation_sensitive':True,'source_matrices':source,'source_Euler_images':source_images(source,T,U)},start)
