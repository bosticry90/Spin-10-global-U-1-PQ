# PSF1: fixed-barred source amplitude and generic physical Euler image

MVS's actual internal ghost derivative has momentum+k;the internal vector
derivative has-k. Their literal tensor is VA-VB. For the full vector inverse,
P_W=I+(W-1)kk^T/Q gives P_W k=Wk in ANY total dimension. Apply this identity
before selecting barred gauge endpoints. Restricting the derivative momentum
sum to four coordinates prematurely would leave an erroneous hat-dependent
longitudinal contribution. With the actual pp numerator,the ordinary spin
unit is+bar_k²,so u_D=+4/D after its old Gaussian/Wick/derivative phase.
No closed numerical Lorentz trace or extra physical spin multiplicity occurs.

MAF's actual rank4 Gamma/Schwinger comparison therefore applies with the
opposite numerator sign. At length6,the ordinary complete source amplitude
is to be derived as [chi4+log(3/2)+1/2]*M_MVS,pole. All VA/VB terms share
this critical unit;their widths and noncommuting color products are already
retained by the independent measured MVS tables. This is not finite-from-
unresolved-pole inference. External-ghost derivatives have a convergent
relative UV coefficient and cannot supply a local dimension4 zero-jet term.

For a general source matrix M=PL ML+PR MR,the odd-left source flow has
qP=c M P and qbarP=c barP Msharp,with
Msharp=PL ML.T+PR MR.T. On the kinetic action the selected images are

 p_L=i(ML+MR.T),q_L=iML; p_R=i(MR+ML.T),q_R=iMR.

For the physical gauge quadratic -ig barP gamma_bar A_b P,odd-left variation
gives -ig c barP(Msharp gamma_bar A_b+gamma_bar A_b M)P. Chirality flip at
gamma_bar gives the generic gauge matrices

 gauge_L=-i(MR.T*T_b+T_b*ML),
 gauge_R=-i(ML.T*U_b+U_b*MR), U=-T.T.

This reduces to [iML,T_b] ONLY when MR=-ML.T. MVS generally does not have
that special relation. Prove the generic ordered identity with arbitrary
noncommuting color matrices before applying it. An independent alternating
quadratic/Clifford congruence gives the same two endpoint insertions.

Physical reality of the actual source is MR=ML^*. It implies p_L^dag=-p_L,
q_L^dag=q_L-p_L,p_R=p_L.T,q_R=(p_L-q_L).T. The gauge matrix is anti-Hermitian
and gauge_R=-gauge_L.T. Test these relations coefficientwise. Do not demand
the isolated source coefficient itself be anti-Hermitian or discard its
nonadjoint contribution. Retain the inherited source-Euler boundary current.

The two coupling orders remain distinct. Both selected gauge images acquire
one extra g;the lower source tensors still have their explicit xi outside.
No scalar,hatted or highest-source descendant is covered by these projections.
The auxiliary family must reproduce MAF exactly under the generic rule.
Completion of this source input still leaves actual source-free kinetic and
gauge-vertex finite comparisons before any complete coupled one-jet theorem.
