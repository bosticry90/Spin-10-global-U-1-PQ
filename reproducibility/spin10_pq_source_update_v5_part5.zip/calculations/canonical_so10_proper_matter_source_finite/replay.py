"""PSF1 actual integral comparison and full charge-transpose Clifford congruence."""
from data import *
start=begin('replay');D=sy.Symbol('D');r=sy.Symbol('bar_rank');z=sy.Symbol('z',positive=True);m,c=sy.symbols('m2 heat_length',positive=True);eps=sy.Symbol('eps',positive=True);nl=sy.Symbol('n_log')
heat=(1+z)*sy.exp(z)*sy.expint(1,z)-1;hFP=sy.expand(sy.series(heat,z,0,1).removeO()).subs(z,c*m)+nl;dfp=sy.expand(sy.series(sy.gamma(eps)*sy.exp(eps*sy.log(4*sy.pi/m)),eps,0,1).removeO()-1/eps)
rank=sy.combsimp((r/D)*sy.gamma(D/2+1)/(2*sy.gamma(D/2)));assert rank==r/4
delta=sy.expand_log(dfp-hFP+sy.Rational(1,2),force=True);chi=1+sy.log(4*sy.pi*c)-nl;assert sy.simplify(delta-chi-sy.Rational(1,2))==0
pa=[sy.Matrix([[0,1],[1,0]]),sy.Matrix([[0,-sy.I],[sy.I,0]]),sy.diag(1,-1)];gam=[sy.kronecker_product(pa[1],m0) for m0 in pa]+[sy.kronecker_product(pa[0],sy.eye(2))];chir=sy.prod(gam);PL=(sy.eye(4)+chir)/2;PR=sy.eye(4)-PL
ML=sy.Matrix(2,2,sy.symbols('l0:4'));MR=sy.Matrix(2,2,sy.symbols('r0:4'));Tb=sy.Matrix(2,2,sy.symbols('t0:4'));Ub=sy.Matrix(2,2,sy.symbols('u0:4'));M=sy.kronecker_product(PL,ML)+sy.kronecker_product(PR,MR);Ms=sy.kronecker_product(PL,ML.T)+sy.kronecker_product(PR,MR.T);A=sy.kronecker_product(PL,Tb)+sy.kronecker_product(PR,Ub)
gL=-sy.I*(MR.T*Tb+Tb*ML);gR=-sy.I*(ML.T*Ub+Ub*MR)
for gm in gam:
 gamma=sy.kronecker_product(gm,sy.eye(2));full=-sy.I*(Ms*gamma*A+gamma*A*M);expected=gamma*(sy.kronecker_product(PL,gL)+sy.kronecker_product(PR,gR));assert not (full-expected).applyfunc(sy.expand).todok()
# Full D projector identity can be written without a rank witness:
q,bq,hq,ww=sy.symbols('Q barQ hatQ width');assert sy.expand(1+(ww-1)*(bq+hq)/q-ww).subs(hq,q-bq).expand()==0
d=packed(HERE/'replay_inputs.json.gz');mvs=d['MVS'];assert mvs['formal_order']=='g10^3' and mvs['UV_unit']=='1';derivative_counts=check_derivatives(mvs)
source={'ordinary':{},'auxiliary':d['MAF']['source_matrices']}
for part,zz in [('chi4',Q(1)),('log3over2',Q(1)),('fixed',Q('1/2'))]:source['ordinary'][part]={side:[enc(scale(dec(v),zz)) for v in mvs['loop_'+side]] for side in ['left','right']}
T=list(map(dec,d['Y']['Tminus']));U=[scale(trans(t),Q(-1)) for t in T]
finish('replay',{'method':'rank4_Schwinger_Gamma_then_generic_Clifford_congruence','ordinary_unit_D':'4/D','ordinary_UV_unit':'1','ordinary_fixed_unit':'1/2','ordinary_fixed_to_pole_ratio':'1/2','derivative_counts':derivative_counts,'generic_gauge_derivation_remainder':0,'wrong_barred_longitudinal_truncation_sensitive':True,'source_matrices':source,'source_Euler_images':source_images(source,T,U),'actual_ordinary_integral_difference':str(delta),'rank_r_to_I2_ratio':str(rank)},start)
