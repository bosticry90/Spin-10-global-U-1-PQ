# PSF1: complete two-family local proper matter-source finite comparison

Basec8fe2baf33e0f2ae86c9c2ba5486dcfc99e885c4/main32295oldblobs. Current
AGENTS,state113/34of39,wholegoal ACTIVE. MAF1 measured the lower auxiliary
proper source finite amplitude and exposed remaining selected finite terms.
Complete the ordinary g10³ source family and assemble both required proper
families before the source-free kinetic/vertex finite comparison.

Same explicitly provisional common-flat-heat Euclidean comparison member as
MAF1,raw dimensional finite part minus symmetric length6 heat on all inverse
edges. It is not an adopted physical regulator/scheme,full chiral Stokes
theorem,measure or QAP construction. Retain fixed bar rank4 and internal hats
in Q. SourceK_P/ghost/fermion dimensions3/2,1,3/2,total4,zero ordinary jets,
coefficient dimension0. External-C derivative amplitudes are not deleted:
power counting excludes them only from this local relative dimension4 term.

Use actual MVS derivative placement tensors,raw longitudinal inverse result,
old independent left/right proper color tables and MAF's constructed finite
auxiliary input. MVS has3480 internal antighost jets and720 internal vector
jets;the relative VA-VB sign is routing-derived. Keep both symbolic widths
and every nonadjoint symmetric-current contribution. Full G_BB(k)k=Wk must
be contracted before restricting the gauge endpoint to the barred subspace.
The source-free chiral kinetic numerator is bar_slash/Q,not a full slash.

Primary derives the complete metric numerator and D jet from actual routing/
Clifford/projector identities,then uses its qualified Born color table.
Replay uses full-rank projector contraction,split Clifford and the actual
rank4 Schwinger/Gamma integral comparison from MAF,with the independently
reconstructed MVS color table. Require the finite unit before importing any
bosonic restoration or desired counterterm. No new full model integration.

Freeze the two source orders separately:g10³ and g10²*xi,all3 directions
chi4/log(3/2)/fixed,both chiralities,all45x16x16 entries/zeros. Derive the
GENERIC p/q/gauge Euler rule,not the auxiliary special commutator. Retain
the nonzero ordinary p image and correct conjugation/physical reality.
All H checks,old tensor/placement matches,MAF auxiliary agreement and
negative controls are necessary. Other scalar/hatted/highest-source images
stay explicit uncomputed obligations. No full source/Slavnov claim follows.

Freeze eight sources/copies,inputs,proof/caps before sequential P/R/gate:
600s afterimports each,8GiB sampledprivate,350MiB available-commit floor,
16MiB stored packet. Honest current-turn LSF fresh E4 reuse;fresh byte
preflight. Firstfailure stops;preserve full sources/captures and version
corrections. No agents,resource expansion,truncation or expensive replay.
Possible outcomes:complete relative coefficient,invalid lift/transport,
actual method mismatch,underdefinition or bounded incompleteness.

Keep chi4/all distinct freedoms symbolic;no physical width/coupling/mass/
flavor/finite baseline chosen. Ceiling excludes full coupled restoration,
physical chiral scheme,QAP/products/measure/phase,massiveC1,E5/A5 and GUT.
Bothscalarwarnings,quartetFAIL,flavorpause,HB1/C5blocks,custody2sevenNOTPASS
remain. Preserve main/state/oldbytes;no branches,adoption,outreach/publication/
push. Shared action,color data,Clifford/reference/software/AI author remain
common-error limits,not independent scientific confirmation.
