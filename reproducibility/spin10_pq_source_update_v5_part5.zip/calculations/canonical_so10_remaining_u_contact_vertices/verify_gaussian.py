from pathlib import Path
from hashlib import sha256
import ast, gzip, json, os, threading, time
import sympy as s

O = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_bytes())
load = lambda p: json.loads(gzip.decompress(p.read_bytes()))
H = lambda p: sha256(p.read_bytes()).hexdigest()
tick = time.perf_counter()
timer = threading.Timer(180, lambda: os._exit(124))
timer.daemon = True
timer.start()
for path, digest in read(O / 'gaussian_validation_preparation.json')['input_sha256'].items():
    assert H(Path(path)) == digest, path
primary, replay = [load(O / ('gaussian_' + role + '_tables.json.gz')) for role in ['primary', 'replay']]
for key in ['fixtures', 'controls', 'sensitive_required_controls', 'source_and_ghost_pair_exchange_and_diagonal_checks', 'heat_edges_preserved_through_Schur_inverse']:
    assert primary[key] == replay[key], key
assert len(primary['fixtures']) == 12
assert all(primary['sensitive_required_controls'].values())
source = (O / 'gaussian.py').read_text()
node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == 'data')
namespace = {'s': s}
exec(compile(ast.get_source_segment(source, node), '<UCV4_bound_generic_data_only>', 'exec'), namespace)
checks = []
for fixture in primary['fixtures']:
    D, axis, seed = fixture['D'], fixture['axis'], fixture['seed']
    result = {m: s.Integer(0) for m in range(1, 6)}
    for q in [1, -1]:
        K, Ku, Y, M, Mu, W, A, V, Z, Zu, P, Pu, Q = namespace['data'](D, axis, q, seed)
        G = K.inv()
        values = {2: s.trace(A * Zu[0][0] + V * Z[0][0]),
                  3: s.trace(A * Mu[0] * G * W[0] + V * M[0] * G * W[0] + M[0] * G * Y * G * W[0]),
                  4: -s.trace(A * M[0] * G * Ku * G * W[0])}
        for m, value in values.items():
            result[m] += s.expand(value) / 2
    assert all(s.expand(result[m] - s.sympify(fixture['heat']['K'][str(m)])) == 0 for m in range(1, 6))
    checks.append({'seed': seed, 'D': D, 'axis': axis, 'K_trace_formula': {str(m): str(s.expand(v)) for m, v in result.items()}})
for role in ['primary', 'replay']:
    record = read(O / ('gaussian_' + role + '_result.json'))
    path = O / ('gaussian_' + role + '_tables.json.gz')
    assert H(path) == record['packed_sha256']
    assert sha256(gzip.decompress(path.read_bytes())).hexdigest() == record['raw_sha256']
    assert record['elapsed_after_imports'] < 300
assert not primary['actual_model_quantum_coefficients_used'] and not replay['actual_model_quantum_coefficients_used']
print('RESULT ' + json.dumps({'elapsed_after_imports': time.perf_counter() - tick,
      'all12_literal_Nambu_Schur_and_compact_K_formulas_agree': True,
      'source_and_ghost_pair_normalizations_verified': True,
      'every_internal_heat_edge_retained': True, 'required_omission_controls_sensitive': primary['sensitive_required_controls'],
      'K_trace_formula_checks': checks, 'second_contact_still_requires_full_Nambu_and_five_edges': True,
      'model_quantum_contact_coefficients_or_QAP_E5_claim': False}, sort_keys=True), flush=True)
timer.cancel()
