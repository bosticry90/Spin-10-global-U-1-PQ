# The next u source contact is measured with a complete ghost-pair treatment

PROGRESS. Actual marginal u-contact vertices and their full doubled-ghost
Gaussian normalization are constructed. The complete u Ja_s JL_r C_h
contact is then measured and independently checked. Probe0 is zero;
probe1 is nonzero in its two- and three-edge components. The remaining
u JL JL CC contact still requires its model coefficient calculation.

This advances the existing five-type contact inventory to four measured
types. It is not a percentage of E5 or quantum consistency. Authority
remains34/39,state113,E5/A5 OPEN,custodyexit2/seven NOTPASS. Goal remains
ACTIVE/INCOMPLETE. No scheme,foundation or physical benchmark changed.

## Actual vertices and ghost pair blocks

Two distinct derivative/coordinate orders agree on every classical
coefficient,internal jet and implicit zero. The source-free u0/u1 quantum
Hessians contain300/37233 entries in this declared domain;the newly
needed ordinary GF quartic block contains6624. All8 signed Euclidean
unit-axis Fourier evaluations and reverse graded orientations agree.
The actual uJa aC tensor matches earlier qualified classical data at
0/600 nonzero positions for the two probes. That is a late classical
comparison,not a prior quantum target used as a coefficient input.

The ghost matrix contains nonzero aa and CC blocks. The ordinary GF
aa|CC block has6624 entries;probe1 has9816 u aa|CC and3344 u CC|JLJL
entries. These cannot be erased by assuming an ordinary ghost determinant.
The two JL and two C variables are separately antisymmetric pairs. A
literal four-odd-variable calculation gives the sorted-pair coefficient
of(u/4)JL_s JL_r C_h C_k T_srhk exactlyT,with no extra half.

Actual vector/jet and metric structures,combined with every UCS profile,
give1500 pins,226 metric links and1286 pinned vector components. No free
Lorentz trace remains,so the fixed dimensional jet is zero in these
specified marginal proper targets. D3/4/5 examples corroborate that
structural proof;they are not its basis. All225 retained source-only/
one-port terms remain recorded and are not promoted to proper loops.

## Full Gaussian normalization,then a smaller complete first-contact formula

The literal paired Hessian quarter-STrlog and an explicit boson Schur
complement followed by negative half-Trlog of the full doubled ghost
matrix agree in12 noncommuting fixtures. Each heat edge,including every
edge inside the bosonic inverse,is tracked separately through degree5.
Source/ghost exchange reverses the appropriate coefficient and equal
directions vanish. Pair-block and source/heat omission controls detect
the tested errors. Generic fifth-edge terms in the second contact are
nonzero,so its support cannot be truncated at four edges.

The first target has only one JL and one C. Its exterior grade excludes
the aa/CC pair blocks;the complete reduction in that target alone is

 K2=Tr(A_s Zu_rh+V_s Z_rh),
 K3=Tr(A_s Ju_h G W_r+V_s J_h G W_r+J_h G Y_s G W_r),
 K4=-Tr(A_s J_h G Ku G W_r).

Definitions are in GAUSSIAN_REVIEW_RECORD.md. A third scalar-trace route
matches all generic fixtures. The generic base K2 happens to cancel in
these chosen fixtures;separate bubble-omission controls change it. This
does not establish a model bubble zero. The actual model K2 is nonzero.
The first contact's scalar-trace reduction does not replace the doubled
ghost construction still required for the second contact.

## Complete model u Ja JL C result

Actual UCV Ku,Ju,V,Zu,Y and qualified original A,W,Z,J,G0 supply the
quantum input. Primary sparse index paths and replay matrix-unfolded
traces with different associations agree on all91125 positions per probe
and tensor,including all coupling/root coefficients and implicit zeros.

| Probe1 heat group | Nonzero | Implicit zero |
| --- | ---: | ---: |
| K2 | 776 | 90,349 |
| K3 | 282 | 90,843 |
| K4 | 0 | 91,125 |
| Pole,sumK | 1,058 | 90,067 |

Every probe0 group is zero. Probe1 K2 comes fromV_s Z_rh;K3 comes from
J_h G Y_s G W_r. Other complete contractions vanish after calculation.
K4 is generically nonzero but zero in this actual model tensor. Do not
infer that its intermediate operators vanish or transfer that zero to
the second contact's five-edge family.

Parameter powers areg10^2 xi andg10^3 eta_H. For example,

 K2[12,13,14]=-16 i sqrt10 g10^2 xi/25,
 K3[13,14,0]=-i sqrt10 eta_H g10^3/4.

The relative contribution,with commonhbar/(16pi^2),is

    u Ja_s JL_r C_h [chi4*(K2+K3)+log(3/2)*K3].

No extra half,no chosen chi4,zero log5/fixed term within this target.
The finite triangle is retained;neither its nonzero value nor the pole
is an anomaly verdict. Other quantum source/Euler terms have not yet
been assembled into the complete T/F identities.

Literal180-coordinate Hessian logarithms agree at the selected triples
in bothq and both probes. Omitting actual Y changes K3;omitting V or
original Z changes K2 where nonzero. Insensitive uKu/uJu/uZu projections
are explicitly retained. These literal samples supplement the full
reduced tensor replay;they are not full180 replay of every coefficient.

## Failure record,resources and limits

Two original PREPARATIONS failed before a native launch:the vertex source
had compressed return/else numeric tokens;the reviewer had compressed
and/else numeric tokens. Both original sources,copies,runners and complete
controller tracebacks remain. Neither original preparation manifest nor
native output exists. V2 inserts only required lexical whitespace and
uses new preparation paths. No science input,formula,sign or test was
weakened and no costly native repeated. Repeating the same preventable
compression error is an engineering weakness and remains research evidence.

Completed native/review seconds afterimports:vertices25.2764/23.0086,
vertexreview14.9645;Gaussian19.6609/7.9551,review.3051;model1.3143/1.1656,
modelreview2.2210. Bounds300s native/180s review,8GiB sampled private,
350MiB available-pagefile floor,32MiBpacket unchanged. Complete resource
samples,captures,source copies and preparation bindings are retained.
Sampled memory is not a continuous peak. E4 native0,steps[0,0,0,0,0,2],
COMPLETED in27.8771s;sealed evidence/declared audit scope,not fresh whole
scientific replay,custodyPASS or director scientific promotion.

Methods share action/data/maps/charts,coefficient ring,Python/SymPy,
software and AI authorship. Agreement is internal mathematical evidence,
not independent scientists,experimental confirmation or validation of
physical premises. No proof assistant or external reviewer claimed.

## Next required calculation

Calculate the full uJLJLCC model contact using the already qualified
doubled-ghost Schur construction,all actual source-pair/ghost-pair blocks
and up to5 heat edges. Keep separately antisymmetric JL/C pairs and
derive any compact trace reduction before a45^4 expansion. Do not infer
its coefficients or fifth-edge zero from the first contact result.
Then derive actual source/Euler lowering and test complete T/F relations
using all independently measured inputs. No Ward-fitted remainder.

Original unshifted SMA/CSW/EDS,A0,constant probes,externaljets0,marginal
intrinsic0 and symbolic parameters remain. This is the nonexceptional
Euclidean LOCAL RELATIVE construction,not physical scalelessp0,absolute
products or massive/causal vacuum amplitudes. chi4,b0,kappa,IR freedoms
stay distinct/unfixed. Full nonlinear master applicability,continuum
products,chiral QAP/measure/global phase,source reality,ordinary BBx and
physical viability remain separate/open. No flavor/HB1/C5 activation,
publication,remote action or authority promotion. project_state is sole
machine scientific authority. This report is frozen before final review.
