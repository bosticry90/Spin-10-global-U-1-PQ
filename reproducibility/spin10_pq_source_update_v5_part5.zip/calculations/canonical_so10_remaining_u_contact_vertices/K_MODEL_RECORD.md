# UCV5: complete first remaining u contact,not a substitute for the second

Prospective after UCV4 passed. Measure the whole u Ja_s JL_r C_h contact
for all45^3=91125 positions/probe/heat. Use actual u vertices and the
qualified compact K2/K3/K4 formula in GAUSSIAN_REVIEW_RECORD.md. The other
u JLJLCC contact remains required and unmeasured;its full doubled-ghost
five-edge construction is retained for subsequent work.

Curate Ku,Ju_h,V_s,Zu_rh,Y_s from each independently derived actual UCV
Fourier table. Reuse qualified original A_s,W_r,Z_rh,J_h,G0 from RSH/ICR
classical containers,with their original signs/frames. No previous quantum
contact or desired T/F identity is a native operand. Retain K2 terms
separately,K3 current/V/Y terms and K4. No assumed probe0 or pole zero.

Primary direct sparse trace paths versus replay matrix-unfolded trace
and different product associations. Complete coefficient/root/coupling/
implicit-zero equality required. Relative bases chi4=sumK,log2=K4-K3,
log3=K3,log5=0,fixed=0 within qualified allD/radial scope. No extra half:
density is u Ja_s JL_r C_h K_srh. chi4,b0,kappa,IR remain distinct/unfixed.

Native300s/review180s,8GiB sampled,350MiBfloor,32MiB wholepacket. Freeze
sources/copies/input hashes before computation. Preserve failures/new
versions for routine correction. Separate review will use selected literal
180-coordinate Hessian logs,bothq,bothprobes and sensitive omissions where
present. No whole source identity,QAP/E5 or physical promotion.
