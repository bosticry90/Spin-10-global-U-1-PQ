# UCV4: doubled-ghost normalization and compact first-contact formula

Prospective after generic Gaussian natives. Require exact equality of all
12 paired-Hessian and Schur fixtures,each heat edge,all omission controls,
pair-exchange/diagonal checks and output hashes. Retain any zero fixture
coefficient as a zero example,not a general structural result.

For the smaller u Ja JL C target,the doubled aa/CC blocks exceed its
source/ghost grades. Derive its complete ordinary ghost subcase without
discarding those blocks from the second target. Write A_s for original
Ja aC,V_s for uJa aC,Z_rh/Zu_rh for original/u JL C aC,J_h/Ju_h for
ordinary/u external-ghost current,W_r for JL C Lambda,Ku for the source-
free u boson Hessian,Y_s for uJaBB and G for the boson inverse. Proposed
complete first-contact heat coefficients are

 K2=Tr(A_s Zu_rh+V_s Z_rh),
 K3=Tr(A_s Ju_h G W_r+V_s J_h G W_r+J_h G Y_s G W_r),
 K4=-Tr(A_s J_h G Ku G W_r).

Derivation:boson inverse supplies the Ku and Y insertions;the ghost
minus-Trlog supplies one ghost-edge Y term and two ghost-edge bubble/
current terms. Test these independent scalar traces on every generic
fixture and both q before model contraction. No u ghost-principal term
is present in the actual qualified support. The second target retains
the full doubled ghost matrix and up to5edges. No Ward-fitted coefficient.

Review180s/8GiB sampled/350MiBfloor/32MiBpacket. Freeze exact sourcecopy/
hash inputs;preserve failures. Authority/state/domain ceiling unchanged.
