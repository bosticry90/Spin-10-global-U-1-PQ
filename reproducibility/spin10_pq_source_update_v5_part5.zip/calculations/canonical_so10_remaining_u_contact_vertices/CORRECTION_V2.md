# UCV1 V2: lexical whitespace correction before native execution

Original preparation FAILED ast.parse:compressed return2/else1 and
return180/return270/return405/return4/return225/else360 tokens lack required
keyword spacing. No native worker was launched,no preparation manifest or
scientific output exists. Preserve original vertices.py,its existing copy,
run.py,RECORD and controller traceback. This is a source-preparation error.

V2 inserts only the required whitespace at those numeric keyword boundaries
and uses a new preparation path. All mathematical operations,inputs,
coefficients,signs,domains and limits unchanged. Reuse the already written
input containers;do not overwrite them. Freeze original failed sources,
corrected source,copies and hashes before any native execution. Native
300s/review180s/8GiB/350MiB/32MiB remain unchanged.
