from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import gzip, json, os, re, sys, threading, time
import sympy as s

O = Path(__file__).resolve().parent
R = O.parents[1]
control_root = Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/remaining-u-contact-vertices-v1-2026-10-26')
read = lambda p: json.loads(p.read_bytes())
load = lambda p: json.loads(gzip.decompress(p.read_bytes()))
H = lambda p: sha256(p.read_bytes()).hexdigest()
tick = time.perf_counter()
timer = threading.Timer(180, lambda: os._exit(124))
timer.daemon = True
timer.start()
bindings = copies = peak = 0
for path in O.glob('*preparation*.json'):
    for filename, digest in read(path)['input_sha256'].items():
        assert H(Path(filename)) == digest, (path, filename)
        bindings += 1
for path in O.glob('*.source.txt'):
    assert path.read_bytes() == Path(str(path)[:-len('.source.txt')]).read_bytes()
    copies += 1
assert not (O / 'preparation.json').exists() and not (O / 'review_preparation.json').exists()
assert read(O / 'controller_failure.json')['execution_state'] == 'FAILED'
assert read(O / 'review_controller_failure.json')['execution_state'] == 'FAILED'
corrected = re.sub(r'\b(return|else)(?=[0-9])', r'\1 ', (O / 'vertices.py').read_text()).replace("O/'preparation.json'", "O/'preparation_v2.json'")
assert corrected == (O / 'vertices_v2.py').read_text()
corrected = re.sub(r'\b(and|or|if|else|return)(?=[0-9])', r'\1 ', (O / 'verify.py').read_text()).replace("O/'review_preparation.json'", "O/'review_preparation_v2.json'")
assert corrected == (O / 'verify_v2.py').read_text()
captures = {path.name: read(path) for path in O.glob('*capture.json')}
assert len(captures) == 9
for name, capture in captures.items():
    assert capture['exit_code'] == 0 and capture['execution_state'] == 'COMPLETED' and capture['calculation_completed'] and capture['post_run_observations_qualified']
    assert capture['launch']['memory']['available_pagefile'] >= 350 * 1024 ** 2
    peak = max(peak, max(row['private_bytes'] for row in capture['all_resource_samples']))
    assert peak <= 8 * 1024 ** 3
vertex_review = read(O / 'validation_receipt.json')
assert vertex_review['complete_actual_vertex_and_all8_Fourier_tables_agree']
assert vertex_review['classical_uJa_V_late_match_counts'] == [0, 600]
assert vertex_review['fixed_Djet0_structural_for_declared_contacts']
gaussian_review = read(O / 'gaussian_validation_receipt.json')
assert gaussian_review['all12_literal_Nambu_Schur_and_compact_K_formulas_agree']
assert gaussian_review['every_internal_heat_edge_retained']
assert all(gaussian_review['required_omission_controls_sensitive'].values())
gaussian_primary, gaussian_replay = [load(O / ('gaussian_' + role + '_tables.json.gz')) for role in ['primary', 'replay']]
assert gaussian_primary['fixtures'] == gaussian_replay['fixtures'] and gaussian_primary['controls'] == gaussian_replay['controls']
assert any(2 in row['changed_heat']['K'] for row in gaussian_primary['controls'] if row['control'] == 'omitUJaGhost')
model_review = read(O / 'k_model_validation_receipt.json')
assert model_review['full_group_heat_pole_prime_and_zero_complement_agreement']
assert model_review['u_JL_JL_CC_still_unmeasured'] and not model_review['whole_source_identity_QAP_E5_or_physical_promotion']
cp = Path(read(O / 'inputs.json')['coefficient_ring'])
sys.path.insert(0, str(cp.parent))
from coefficient_ring import coefficient
g, xi, eta = s.symbols('g10 xi eta_H', real=True)
@lru_cache(None)
def co(value):
    return coefficient(s.expand(s.sympify(value, locals={'g10': g, 'xi': xi, 'eta_H': eta})))
tab = lambda rows: {tuple(row[:-1]): co(row[-1]) for row in rows}
def plus(*terms):
    values = defaultdict(lambda: 0)
    for table, factor in terms:
        for key, value in table.items():
            values[key] += factor * value
    return {key: value for key, value in values.items() if value}
native_primary, native_replay = [load(O / ('k_model_' + role + '_tables.json.gz')) for role in ['primary', 'replay']]
summaries = []
for probe in range(2):
    first, second = native_primary['results'][probe], native_replay['results'][probe]
    groups = {key: tab(rows) for key, rows in first['groups'].items()}
    assert groups == {key: tab(rows) for key, rows in second['groups'].items()}
    heat = {int(m): tab(rows) for m, rows in first['heat'].items()}
    assert heat == {int(m): tab(rows) for m, rows in second['heat'].items()}
    assert heat[2] == plus((groups['A_Zu'], 1), (groups['V_Z'], 1))
    assert heat[3] == plus((groups['A_Ju_G_W'], 1), (groups['V_J_G_W'], 1), (groups['J_G_Y_G_W'], 1))
    assert heat[4] == groups['minus_A_J_G_Ku_G_W']
    pole = plus(*[(values, 1) for values in heat.values()])
    basis = {'chi4': pole, 'log2': plus((heat[4], 1), (heat[3], -1)), 'log3': heat[3], 'log5': {}, 'fixed': {}}
    assert basis == {key: tab(rows) for key, rows in first['relative'].items()} == {key: tab(rows) for key, rows in second['relative'].items()}
    assert first['parameter_powers'] == second['parameter_powers']
    summaries.append({'probe': probe, 'heat_pole_nonzero': [len(heat[m]) for m in [2, 3, 4]] + [len(pole)], 'parameter_powers': first['parameter_powers']})
assert summaries[0]['heat_pole_nonzero'] == [0, 0, 0, 0]
assert summaries[1]['heat_pole_nonzero'] == [776, 282, 0, 1058]
assert summaries[1]['parameter_powers'] == [[2, 1, 0], [3, 0, 1]]
for stem in ['vertices_primary', 'vertices_replay', 'gaussian_primary', 'gaussian_replay', 'k_model_primary', 'k_model_replay']:
    record = read(O / (stem + '_result.json'))
    path = O / (stem + '_tables.json.gz')
    assert H(path) == record['packed_sha256']
    assert sha256(gzip.decompress(path.read_bytes())).hexdigest() == record['raw_sha256']
    assert record['elapsed_after_imports'] < 300
E4 = read(control_root / 'e4_full_capture.json')
events = [json.loads(row) for row in E4['stdout_and_stderr'].splitlines()]
exits = [row['exit_code'] for row in events if row['event'] == 'step_finished']
assert E4['native_exit'] == 0 and exits == [0, 0, 0, 0, 0, 2] and events[-1]['execution_state'] == 'COMPLETED'
assert H(R / 'project_state.json') == 'd610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
assert sum(path.stat().st_size for path in O.iterdir() if path.is_file()) < 32 * 1024 ** 2
print('RESULT ' + json.dumps({'elapsed_after_imports': time.perf_counter() - tick,
      'preparation_bindings_authenticated': bindings, 'source_copies_equal': copies,
      'pre_review_native_captures': len(captures), 'largest_pre_review_private_sample': peak,
      'two_prelaunch_failures_preserved_not_native_or_PASS': True,
      'actual_vertices_allD_Nambu_normalization_and_literal_checks_authenticated': True,
      'complete_first_contact_group_heat_pole_prime_recomputed': summaries,
      'remaining_contact': 'u JL JL CC unmeasured', 'E4_step_exits': exits,
      'custody': 'EXIT2_SEVEN_NOTPASS', 'whole_source_identity_QAP_E5_or_physical_promotion': False}, sort_keys=True), flush=True)
timer.cancel()
