from pathlib import Path
from hashlib import sha256
import ast, json, sys, traceback
O = Path(__file__).resolve().parent
R = O.parents[1]
C = Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/remaining-u-contact-vertices-v1-2026-10-26')
sys.path.insert(0, str(R / 'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H = lambda p: sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_bytes())
def dump(path, value):
    with path.open('xb') as f:
        f.write((json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode())
try:
    bindings = dict(read(O / 'k_model_validation_preparation.json')['input_sha256'])
    for path, digest in bindings.items():
        assert H(Path(path)) == digest, path
    bindings[str(C / 'e4_full_capture.json')] = H(C / 'e4_full_capture.json')
    for name in ['RESULT.md', 'FINAL_REVIEW_RECORD.md', 'final_review.py', 'run_final_review.py']:
        path = O / name
        with (O / (name + '.source.txt')).open('xb') as f:
            f.write(path.read_bytes())
        if path.suffix == '.py':
            ast.parse(path.read_bytes())
    for path in O.iterdir():
        if path.is_file():
            bindings[str(path)] = H(path)
    dump(O / 'final_review_preparation.json', {'input_sha256': bindings, 'seconds_after_imports': 180, 'scientific_acceptance': 'NOT_PERFORMED'})
    result = capture([sys.executable, '-B', str(O / 'final_review.py')])
    dump(O / 'final_review_capture.json', result)
    dump(C / 'final_review_full_capture.json', result)
    assert result['exit_code'] == 0 and result['execution_state'] == 'COMPLETED' and result['calculation_completed'] and result['post_run_observations_qualified']
    assert result['launch']['memory']['available_pagefile'] >= 350 * 1024 ** 2
    assert max(row['private_bytes'] for row in result['all_resource_samples']) <= 8 * 1024 ** 3
    values = [json.loads(row[7:]) for row in result['stdout_and_stderr'].splitlines() if row.startswith('RESULT ')]
    assert len(values) == 1 and values[0]['elapsed_after_imports'] < 180
    dump(O / 'final_review_validation_receipt.json', values[0])
    assert sum(path.stat().st_size for path in O.iterdir() if path.is_file()) < 32 * 1024 ** 2
    print(json.dumps(values[0], sort_keys=True), flush=True)
except BaseException:
    dump(O / 'final_review_controller_failure.json', {'execution_state': 'FAILED', 'traceback': traceback.format_exc(), 'failure_relabelled_PASS': False})
    raise
