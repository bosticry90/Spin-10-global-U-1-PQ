from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import gzip, json, os, sys, threading, time
import sympy as s

O = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_bytes())
H = lambda p: sha256(p.read_bytes()).hexdigest()
role = sys.argv[1]
assert role in ['primary', 'replay']
tick = time.perf_counter()
timer = threading.Timer(300, lambda: os._exit(124))
timer.daemon = True
timer.start()
for path, digest in read(O / 'gaussian_preparation.json')['input_sha256'].items():
    assert H(Path(path)) == digest, path
cp = Path(read(O / 'inputs.json')['coefficient_ring'])
sys.path.insert(0, str(cp.parent))
from coefficient_ring import coefficient, constant, expression

@lru_cache(None)
def co(value):
    return coefficient(s.expand(s.sympify(value)))

def clean(values):
    return {key: value for key, value in values.items() if value}

def add(first, second):
    result = dict(first)
    for key, value in second.items():
        result[key] = result.get(key, 0) + value
    return clean(result)

def scale(values, factor):
    return clean({key: factor * value for key, value in values.items()})

def multiply(first, second):
    result = defaultdict(lambda: 0)
    for (a, e), value in first.items():
        for (b, f), other in second.items():
            if a & b or e + f > 5:
                continue
            crossings = sum(i > j for i in range(2, 6) for j in range(2, 6)
                            if a & (1 << i) and b & (1 << j))
            result[a | b, e + f] += (-1) ** crossings * value * other
    return clean(result)

def mm(first, second):
    rows = defaultdict(list)
    result = {}
    for (i, j), value in second.items():
        rows[i].append((j, value))
    for (i, k), value in first.items():
        for j, other in rows[k]:
            result[i, j] = add(result.get((i, j), {}), multiply(value, other))
    return clean(result)

def matrix_add(first, second, factor=1):
    result = dict(first)
    for key, value in second.items():
        result[key] = add(result.get(key, {}), scale(value, factor))
    return clean(result)

def const(matrix, edge=0):
    return {key: {(0, edge): co(str(value))}
            for key, value in s.SparseMatrix(matrix).todok().items()}

def trace(matrix, parities=None):
    result = {}
    for (i, j), value in matrix.items():
        if i == j:
            result = add(result, scale(value, (-1) ** parities[i] if parities else 1))
    return result

def data(D, axis, q, seed=0, control=None):
    nb = 2 * D + 2
    K = s.zeros(nb)
    Ku = s.zeros(nb)
    Y = s.zeros(nb)
    widths = [5, 7] if control == 'widthChange' else [2, 3]
    BB = s.Matrix([[2 + seed, 1], [1, -2]])
    BL = s.Matrix([[1, 2], [-1, 3 + seed]])
    LL = s.Matrix([[2, -1], [-1, 1]])
    YY = s.Matrix([[3, 1], [1, -1 - seed]])
    for a in range(2):
        for mu in range(D):
            K[a * D + mu, a * D + mu] = int(mu != axis)
            for b in range(2):
                Y[a * D + mu, b * D + mu] = YY[a, b]
        B = a * D + axis
        L = 2 * D + a
        K[B, L], K[L, B], K[L, L] = q, -q, widths[a]
        for b in range(2):
            Ku[B, b * D + axis] = BB[a, b]
            Ku[B, 2 * D + b] = q * BL[a, b]
            Ku[2 * D + b, B] = -q * BL[a, b]
            Ku[L, 2 * D + b] = LL[a, b]
    M, Mu, W = [], [], []
    for h in range(2):
        current, changed = s.zeros(2, nb), s.zeros(2, nb)
        jb = s.I * s.Matrix([[1 + h + seed, 2 - h], [-1, 3 + h]])
        jl = s.Matrix([[2 + h, 1], [4, -1 - seed]])
        ub = s.I * s.Matrix([[3 - h, -1], [2 + h, 1 + seed]])
        ul = s.Matrix([[1, 2 + h], [-2, 3]])
        for a in range(2):
            for c in range(2):
                current[c, a * D + axis] = q * jb[c, a]
                current[c, 2 * D + a] = jl[c, a]
                changed[c, a * D + axis] = q * ub[c, a]
                changed[c, 2 * D + a] = ul[c, a]
        M.append(current)
        Mu.append(changed)
    for r in range(2):
        ww = s.zeros(nb, 2)
        color = s.Matrix([[1 + r, -1], [2 - r, 2 + r + seed]])
        for a in range(2):
            for c in range(2):
                ww[2 * D + a, c] = color[a, c]
        W.append(ww)
    A = s.Matrix([[2, -1], [3, 1 + seed]])
    Au = s.I * s.Matrix([[1, 2], [-2, 3 + seed]])
    Z = [[s.I * s.Matrix([[2 + r, 1 + h], [-3 + h, 1 + r + seed]])
          for h in range(2)] for r in range(2)]
    Zu = [[s.Matrix([[1 + r + h, -2], [2 - h, 3 + r + seed]])
           for h in range(2)] for r in range(2)]
    P = s.Matrix([[0, 3 + seed], [-3 - seed, 0]])
    Pu = s.Matrix([[0, -2], [2, 0]])
    Q = s.I * s.Matrix([[0, 2 + seed], [-2 - seed, 0]])
    if control == 'omitAA':
        P, Pu = s.zeros(2), s.zeros(2)
    if control == 'omitCC':
        Q = s.zeros(2)
    if control == 'omitUQuadratic':
        Ku = s.zeros(nb)
    if control == 'omitUJaBB':
        Y = s.zeros(nb)
    if control == 'omitUCurrent':
        Mu = [s.zeros(2, nb), s.zeros(2, nb)]
    if control == 'omitUJaGhost':
        Au = s.zeros(2)
    if control == 'omitUJLZ':
        Zu = [[s.zeros(2) for h in range(2)] for r in range(2)]
    if control == 'omitBaseZ':
        Z = [[s.zeros(2) for h in range(2)] for r in range(2)]
    if control == 'omitBaseJa':
        A = s.zeros(2)
    if control == 'omitBaseW':
        W = [s.zeros(nb, 2), s.zeros(nb, 2)]
    if control == 'exchangeJL':
        W, Z, Zu, Q = W[::-1], Z[::-1], Zu[::-1], -Q
    if control == 'sameJL':
        W[1], Z[1], Zu[1], Q = W[0], Z[0], Zu[0], s.zeros(2)
    if control == 'exchangeC':
        M, Mu = M[::-1], Mu[::-1]
        Z, Zu = [row[::-1] for row in Z], [row[::-1] for row in Zu]
        P, Pu = -P, -Pu
    if control == 'sameC':
        M[1], Mu[1], P, Pu = M[0], Mu[0], s.zeros(2), s.zeros(2)
        for r in range(2):
            Z[r][1], Zu[r][1] = Z[r][0], Zu[r][0]
    return K, Ku, Y, M, Mu, W, A, Au, Z, Zu, P, Pu, Q

def literal(D, axis, seed=0, control=None, omit_classical=False):
    nb = 2 * D + 2
    per = nb + 4
    dimension = 2 * per
    parities = ([0] * nb + [1] * 4) * 2
    ext = [dimension + j for j in range(6)]
    pp = lambda i: parities[i] if i < dimension else int(i >= dimension + 2)
    field = lambda mode, i: mode * per + i
    free, terms = [], []
    K = data(D, axis, 1, seed, control)[0]
    for (i, j), value in s.SparseMatrix(K).todok().items():
        free.append((co(str(value)), (field(1, i), field(0, j))))
    for mode in [0, 1]:
        other, q = 1 - mode, 1 if mode == 0 else -1
        K, Ku, Y, M, Mu, W, A, Au, Z, Zu, P, Pu, Q = data(D, axis, q, seed, control)
        for a in range(2):
            free.append((constant(1), (field(other, nb + 2 + a), field(mode, nb + a))))
        if mode == 0:
            for prefix, matrix in [((ext[0],), Ku), ((ext[0], ext[1]), Y)]:
                for (i, j), value in s.SparseMatrix(matrix).todok().items():
                    terms.append((co(str(value)), prefix + (field(1, i), field(0, j))))
            for prefix, matrix, offset in [((ext[4], ext[5]), P, 2),
                    ((ext[0], ext[4], ext[5]), Pu, 2),
                    ((ext[0], ext[2], ext[3]), Q, 0)]:
                for (a, b), value in s.SparseMatrix(matrix).todok().items():
                    terms.append((co(str(value)), prefix + (field(1, nb + offset + a), field(0, nb + offset + b))))
        for prefix, matrix in [((ext[1],), A), ((ext[0], ext[1]), Au)]:
            for (a, c), value in s.SparseMatrix(matrix).todok().items():
                terms.append((co(str(value)), prefix + (field(other, nb + 2 + a), field(mode, nb + c))))
        for r in range(2):
            for h in range(2):
                for prefix, matrix in [((ext[2 + r], ext[4 + h]), Z[r][h]),
                        ((ext[0], ext[2 + r], ext[4 + h]), Zu[r][h])]:
                    for (a, c), value in s.SparseMatrix(matrix).todok().items():
                        terms.append((co(str(value)), prefix + (field(other, nb + 2 + a), field(mode, nb + c))))
            for (b, c), value in s.SparseMatrix(W[r]).todok().items():
                terms.append((co(str(value)), (ext[2 + r], field(mode, nb + c), field(other, b))))
        for h in range(2):
            for prefix, matrix in [((), M[h]), ((ext[0],), Mu[h])]:
                for (a, b), value in s.SparseMatrix(matrix).todok().items():
                    terms.append((co(str(value)), prefix + (field(other, nb + 2 + a), ext[4 + h], field(mode, b))))
    if not omit_classical:
        terms.extend([(constant(7), (ext[0], ext[1], ext[2], ext[4])),
                      (constant(3), (ext[0], ext[1], field(0, 2 * D)))])
    def hessian(density):
        result = {}
        for value, word in density:
            for at, i in enumerate(word):
                if i >= dimension:
                    continue
                remaining = word[:at] + word[at + 1:]
                first = pp(i) * sum(pp(n) for n in word[:at])
                for pos, j in enumerate(remaining):
                    if j >= dimension:
                        continue
                    rest = remaining[:pos] + remaining[pos + 1:]
                    assert all(n >= dimension for n in rest)
                    if len(set(rest)) != len(rest):
                        continue
                    crossing = first + pp(j) * sum(pp(n) for n in remaining[:pos]) + pp(j) * (pp(i) + 1)
                    crossing += sum(a > b for k, a in enumerate(rest) for b in rest[k + 1:] if pp(a) and pp(b))
                    mask = sum(1 << (n - dimension) for n in rest)
                    result[i, j] = add(result.get((i, j), {}), {(mask, 0): (-1) ** crossing * value})
        return clean(result)
    freeH = hessian(free)
    Kfull = s.SparseMatrix(dimension, dimension,
                         {ij: expression(p[0, 0].terms) for ij, p in freeH.items()})
    G = const(Kfull.inv(), 1)
    Mfull = mm(G, hessian(terms))
    power = const(s.eye(dimension))
    result = {}
    for order in range(1, 6):
        power = mm(power, Mfull)
        result = add(result, scale(trace(power, parities), co(str(s.Rational((-1) ** (order + 1), 4 * order)))))
    return {target: {m: result.get((mask, m), 0) for m in range(1, 6)}
            for target, mask in [('K', 23), ('T', 61)]}

def schur(D, axis, seed=0, control=None):
    result = {'K': {m: constant(0) for m in range(1, 6)},
              'T': {m: constant(0) for m in range(1, 6)}}
    nb = 2 * D + 2
    for q in [1, -1]:
        K, Ku, Y, M, Mu, W, A, Au, Z, Zu, P, Pu, Q = data(D, axis, q, seed, control)
        V = {}
        def insert(i, j, mask, value):
            if value:
                V[i, j] = add(V.get((i, j), {}), {(mask, 0): co(str(value))})
        for mask, matrix in [(1, Ku), (3, Y)]:
            for (i, j), value in s.SparseMatrix(matrix).todok().items():
                insert(i, j, mask, value)
        potentials = [(2, A), (3, Au)]
        for r in range(2):
            for h in range(2):
                mask = (1 << (2 + r)) | (1 << (4 + h))
                potentials.extend([(mask, Z[r][h]), (mask | 1, Zu[r][h])])
        for mask, matrix in potentials:
            for (a, c), value in s.SparseMatrix(matrix).todok().items():
                insert(nb + 2 + a, nb + c, mask, value)
                insert(nb + c, nb + 2 + a, mask, -value)
        for mask, matrix, offset in [(48, P, 2), (49, Pu, 2), (13, Q, 0)]:
            for (a, b), value in s.SparseMatrix(matrix).todok().items():
                insert(nb + offset + a, nb + offset + b, mask, value)
        for h in range(2):
            for mask, matrix in [(1 << (4 + h), M[h]), ((1 << (4 + h)) | 1, Mu[h])]:
                for (a, b), value in s.SparseMatrix(matrix).todok().items():
                    insert(nb + 2 + a, b, mask, value)
                    insert(b, nb + 2 + a, mask, value if b < 2 * D else -value)
        for r in range(2):
            for (b, c), value in s.SparseMatrix(W[r]).todok().items():
                insert(b, nb + c, 1 << (2 + r), value)
                insert(nb + c, b, 1 << (2 + r), -value)
        BB = {ij: p for ij, p in V.items() if ij[0] < nb and ij[1] < nb}
        BF = {(i, j - nb): p for (i, j), p in V.items() if i < nb <= j}
        FB = {(i - nb, j): p for (i, j), p in V.items() if j < nb <= i}
        FF = {(i - nb, j - nb): p for (i, j), p in V.items() if i >= nb and j >= nb}
        Gb = const(K.inv(), 1)
        freeF = s.zeros(4)
        for a in range(2):
            freeF[a, 2 + a], freeF[2 + a, a] = -1, 1
        Gf = const(freeF.inv(), 1)
        inverse, power = {}, const(s.eye(nb))
        block = mm(Gb, BB)
        for order in range(6):
            inverse = matrix_add(inverse, mm(power, Gb), (-1) ** order)
            power = mm(power, block)
        effective = matrix_add(FF, mm(mm(FB, inverse), BF), -1)
        total = {}
        for GG, vertices, sign in [(Gb, BB, 1), (Gf, effective, -1)]:
            n = nb if sign == 1 else 4
            power, block = const(s.eye(n)), mm(GG, vertices)
            for order in range(1, 6):
                power = mm(power, block)
                total = add(total, scale(trace(power), co(str(s.Rational(sign * (-1) ** (order + 1), 2 * order)))))
        for target, mask in [('K', 23), ('T', 61)]:
            for m in range(1, 6):
                result[target][m] += co('1/2') * total.get((mask, m), 0)
    return result

def encoded(values):
    return {target: {str(m): str(v) for m, v in heat.items()} for target, heat in values.items()}

method = literal if role == 'primary' else schur
fixtures, controls = [], []
detection = {'omitAA': False, 'omitCC': False, 'omitBaseW': False, 'omitUQuadratic': False}
for seed in [0, 1]:
    baseline = None
    for D in [3, 4, 5]:
        for axis in [0, D - 1]:
            value = method(D, axis, seed)
            assert not value['K'][1] and not value['T'][1]
            if baseline is None:
                baseline = value
            else:
                assert baseline == value
            fixtures.append({'seed': seed, 'D': D, 'axis': axis, 'heat': encoded(value)})
    assert any(baseline['K'].values()) and any(baseline['T'].values())
    print('STAGE UCV3', role, seed, encoded(baseline), flush=True)
    for control in ['omitAA', 'omitCC', 'omitUQuadratic', 'omitUJaBB', 'omitUCurrent',
                    'omitUJaGhost', 'omitUJLZ', 'omitBaseZ', 'omitBaseJa', 'omitBaseW', 'widthChange']:
        changed = method(3, 0, seed, control)
        differences = {target: [m for m in range(1, 6) if changed[target][m] != baseline[target][m]]
                       for target in ['K', 'T']}
        if control in detection:
            detection[control] |= any(differences.values())
        controls.append({'seed': seed, 'control': control, 'changed_heat': differences})
    for control in ['exchangeJL', 'exchangeC']:
        changed = method(3, 0, seed, control)
        assert all(changed['T'][m] == -baseline['T'][m] for m in range(1, 6))
    for control in ['sameJL', 'sameC']:
        changed = method(3, 0, seed, control)
        assert not any(changed['T'].values())
assert all(detection.values())
if role == 'primary':
    assert literal(3, 0, omit_classical=True) == literal(3, 0)
out = {'schema': 'UCV3_FULL_NAMBU_PAIRED_GAUSSIAN_SCHUR_KERNEL', 'role': role,
       'fixtures': fixtures, 'controls': controls, 'sensitive_required_controls': detection,
       'source_and_ghost_pair_exchange_and_diagonal_checks': True,
       'heat_edges_preserved_through_Schur_inverse': True,
       'actual_model_quantum_coefficients_used': False}
raw = (json.dumps(out, sort_keys=True, separators=(',', ':')) + '\n').encode()
blob = gzip.compress(raw, mtime=0)
with (O / ('gaussian_' + role + '_tables.json.gz')).open('xb') as f:
    f.write(blob)
print('RESULT ' + json.dumps({'elapsed_after_imports': time.perf_counter() - tick,
      'packed_sha256': sha256(blob).hexdigest(), 'raw_sha256': sha256(raw).hexdigest(),
      'fixtures': len(fixtures), 'first_heat': fixtures[0]['heat'],
      'required_controls': detection, 'model_contact_coefficients_measured': False}, sort_keys=True), flush=True)
timer.cancel()
