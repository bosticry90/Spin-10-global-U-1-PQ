# UCV7: final full coefficient and provenance review

Prospective after UCV6. Authenticate every immutable input/sourcecopy,
complete native capture and resource bound. Preserve both prelaunch
syntax/controller failures with absent original manifests,without calling
them native runs or PASS. Verify exact lexical-only V2 differences.

Recompute complete first-contact group/heat/pole/prime sums and zero
complements from both native outputs. Authenticate actual vertex/pair/
allD review,literal paired-Nambu/Schur/third-trace equality and selected
literal180 model checks. Keep generic zeros and model controls scoped.
Reconfirm E4 exits and unchanged authority hash. No coefficient assigned
to remaining uJLJLCC,full source identity,QAP/E5 or physical promotion.

180s/8GiB sampled/350MiBfloor/32MiBpacket. Freeze sourcecopy and hashes
before run;preserve a failed final check instead of editing frozen report.
