# UCV2: actual vertex and allD support qualification

Freeze completed UCV1 V2 outputs. Require complete primary/replay jet and
Fourier equality,all8 signed axes and implicit zeros;check graded reverse
orientations,external canonical pair order and no odd duplicates. Recompute
Fourier factors independently. Derive the u/4 JLJLCC ordered-pair density
factor on four odd variables;keep same-index zero directions by algebra.

Late compare actual uJa aC with the independently qualified IQC classical
V extraction,including zero probe0 and all45 source/ghost directions.
No IQC quantum coefficient is an operand. Confirm actual vector/jet labels,
metric-only uJaBB and uniform Lorentz components. Propagate actual pins
through every UCS support word;no unpinned metric component may remain.
This qualifies fixed Djet0 for these declared marginal proper targets
only. It does not measure contact amplitudes or their normalization.

Preserve the original syntax/preparation failure and unchanged sources.
Verify V2 only fixes lexical spacing and versioned preparation path.
Review180s/8GiB sampled/350MiB pagefilefloor/32MiBpacket. Source copies,
hashes and complete captures required. No scientific authority change.
