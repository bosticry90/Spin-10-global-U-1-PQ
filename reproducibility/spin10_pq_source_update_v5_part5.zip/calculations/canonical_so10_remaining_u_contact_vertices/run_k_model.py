from pathlib import Path
from hashlib import sha256
import ast, gzip, json, sys, traceback
O = Path(__file__).resolve().parent
R = O.parents[1]
C = Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/remaining-u-contact-vertices-v1-2026-10-26')
sys.path.insert(0, str(R / 'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H = lambda p: sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_bytes())
load = lambda p: json.loads(gzip.decompress(p.read_bytes()))
def dump(path, value):
    with path.open('xb') as f:
        f.write((json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode())
def boson(i):
    if i < 180:
        return i // 4 if i % 4 == 3 else None
    if i < 225:
        return 45 + i - 180
    return None
try:
    assert read(O / 'gaussian_validation_receipt.json')['all12_literal_Nambu_Schur_and_compact_K_formulas_agree']
    bindings = dict(read(O / 'gaussian_validation_preparation.json')['input_sha256'])
    for path, digest in bindings.items():
        assert H(Path(path)) == digest, path
    for role in ['primary', 'replay']:
        path = O.parent / 'canonical_so10_intrinsic_source_cutoff_defect' / ('kernel_v2_' + role + '_inputs.json.gz')
        bindings[str(path)] = H(path)
        old = load(path)
        path = O / ('vertices_' + role + '_tables.json.gz')
        bindings[str(path)] = H(path)
        native = load(path)
        F = next(row['groups'] for row in native['Fourier_unit_axes'] if row['axis'] == 3 and row['q'] == 1)
        value = {'A': [[r, a, c, v] for r, c, a, v in old['maps']['B_C_a']],
                 'W': [[r, 45 + a, c, v] for r, c, a, v in old['maps']['beta_C_L']],
                 'J0': old['endings']['J0'], 'G0': old['endings']['G0'], 'Z0': old['Z0'], 'u_vertices': []}
        for probe in range(2):
            new = {key: [] for key in ['Ku', 'Ju', 'V', 'Zu', 'Y']}
            for i, j, ext, v in F['u' + str(probe)]:
                b, d = boson(i), boson(j)
                if not ext and b is not None and d is not None:
                    new['Ku'].append([b, d, v])
                if len(ext) == 1 and 225 <= ext[0] < 270 and 270 <= i < 315 and d is not None:
                    new['Ju'].append([ext[0] - 225, i - 270, d, v])
                if len(ext) == 1 and 360 <= ext[0] < 405:
                    source = ext[0] - 360
                    if 270 <= i < 315 and 225 <= j < 270:
                        new['V'].append([source, i - 270, j - 225, v])
                    if b is not None and d is not None:
                        assert b < 45 and d < 45
                        new['Y'].append([source, b, d, v])
                if len(ext) == 2 and 315 <= ext[0] < 360 and 225 <= ext[1] < 270 and 270 <= i < 315 and 225 <= j < 270:
                    new['Zu'].append([ext[0] - 315, ext[1] - 225, i - 270, j - 225, v])
            value['u_vertices'].append(new)
        path = O / ('k_model_' + role + '_inputs.json.gz')
        with path.open('xb') as f:
            f.write(gzip.compress((json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode(), mtime=0))
    for name in ['K_MODEL_RECORD.md', 'k_model.py', 'run_k_model.py']:
        path = O / name
        with (O / (name + '.source.txt')).open('xb') as f:
            f.write(path.read_bytes())
        if path.suffix == '.py':
            ast.parse(path.read_bytes())
    for path in O.iterdir():
        if path.is_file():
            bindings[str(path)] = H(path)
    dump(O / 'k_model_preparation.json', {'input_sha256': bindings, 'seconds_after_imports': 300, 'scientific_acceptance': 'NOT_PERFORMED'})
    for role in ['primary', 'replay']:
        result = capture([sys.executable, '-B', str(O / 'k_model.py'), role])
        dump(O / ('k_model_' + role + '_capture.json'), result)
        dump(C / ('k_model_' + role + '_full_capture.json'), result)
        assert result['exit_code'] == 0 and result['execution_state'] == 'COMPLETED' and result['calculation_completed'] and result['post_run_observations_qualified']
        assert result['launch']['memory']['available_pagefile'] >= 350 * 1024 ** 2
        assert max(row['private_bytes'] for row in result['all_resource_samples']) <= 8 * 1024 ** 3
        values = [json.loads(row[7:]) for row in result['stdout_and_stderr'].splitlines() if row.startswith('RESULT ')]
        assert len(values) == 1 and values[0]['elapsed_after_imports'] < 300
        dump(O / ('k_model_' + role + '_result.json'), values[0])
        assert sum(path.stat().st_size for path in O.iterdir() if path.is_file()) < 32 * 1024 ** 2
        print('COMPLETED_UCV5', role, json.dumps(values[0], sort_keys=True), flush=True)
except BaseException:
    dump(O / 'k_model_controller_failure.json', {'execution_state': 'FAILED', 'traceback': traceback.format_exc(), 'failure_relabelled_PASS': False})
    raise
