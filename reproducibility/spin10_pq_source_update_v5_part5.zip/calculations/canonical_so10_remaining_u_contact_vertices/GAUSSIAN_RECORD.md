# UCV3: complete doubled-ghost ordered Gaussian kernel

Prospective after UCV2 V2 qualified actual vertices/allD pinning. The
aa and CC blocks are nonzero,so retain the full ghost Nambu matrix rather
than assume an ordinary ghost determinant. Target densities are u Ja JL C
and(u/4)JL_s JL_r C_h C_k T_srhk,with T antisymmetric in each odd pair.
The sorted-pair coefficient equals T,as already derived in UCV2.

Generic independent noncommuting two-vector-color/two-ghost fixtures:
literal paired graded Hessian quarter-STrlog versus explicit one-mode
bosonic Schur complement and negative half-Trlog of the doubled ghost
matrix. Keep one formal heat variable E on EVERY original free edge,
including each edge inside a bosonic inverse. Extract each E degree2..5
separately. Do not collapse inverse-edge cancellations or ordinary/ghost
pair blocks. Bosonic determinant contribution is retained before target
projection. No actual model quantum coefficient or Ward target input.

Include source-free uBB/uBL/uLL,ordinary/u external-ghost currents,Ja aC,
uJa aC/uJaBB,JL C Lambda,JL C aC anduJL C aC,ordinary/u aa|CC anduCC|JLJL.
U and Ja are commuting variables truncated to first target degree;
JL1,JL2,C1,C2 form an exact exterior algebra. Both target coefficients,
q orientations,D3/4/5,first/last axes,two seeds. Test aa/CC omission,
uquadratic/source/direct-current terms,source/ghost exchange and equal
source/ghost directions. Record insensitive controls honestly;require
pair-block and base-source omission detection in generic fixtures.

Agreement qualifies this finite ordered normalization/reduction only,
not model coefficients,continuum products,QAP or E5/A5. AllD fixed jet0
uses the separately qualified actual support proof,not interpolation.
Native300s/review180s,8GiB sampled,350MiBfloor,32MiBpacket. Freeze sources/
copies/hashes before computation,preserve exact failures,new versions for
routine corrections. Standing authority/domain/normalization limits apply.
