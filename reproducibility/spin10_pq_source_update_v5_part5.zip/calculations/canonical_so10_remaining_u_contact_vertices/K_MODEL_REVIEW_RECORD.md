# UCV6: full first-contact qualification

Prospective after both model natives. Require complete group,heat,pole,
prime/coupling/root and implicit-zero agreement at91125 positions per
probe/tensor. Recompute each sum rather than infer equality from counts.

Use the actual UCV Fourier Hessians plus qualified original A,W,Z,J,G0
in a literal180-coordinate graded logarithm for bothq,bothprobes. Sample
min/max nonzero K2/K3/K4/Y and(13,13,0),at most7triples. Direct source and
ghost pair blocks excluded from K only by its positive exterior grade;
they remain required for the second contact. Test actual Y/V/sourceZ,
uZu/uJu/uKu omissions,recording insensitivity. Require detection of
nonzero sampled Y/V groups. No favorable pole/normalization imposed.

180s review,8GiB sampled,350MiBfloor,32MiBpacket. Preserve failures/versions.
All model/domain/master/QAP/authority limits unchanged. Literal samples
corroborate the full reduced tensor replay,not full180 replay of all entries.
