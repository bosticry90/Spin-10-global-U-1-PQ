# UCV1: actual marginal u-contact Hessians

Prospective at729c0ebe12a2f7840ae57951bb5eb3f168c6ae7c,V639. Fresh preflight
clean main,no matching workers;previous turn PROGRESS,goal ACTIVE.
Live AGENTS,charter,solo review,epistemic ladder/local conventions apply.
State113,authority34/39,E5/A5 OPEN,custodyexit2/seven NOTPASS unchanged.
No agents,branch/worktree,remote action,publication,scheme/foundation/
benchmark adoption,flavor/HB1/C5 activation or protected promotion.

Question:which actual Hessians enter the two remaining u Ja JL C and
u JL JL CC proper contacts? UCS joint support has32 letters and up to5
edges,no scalar paths. Derive their coefficients from actual physical_QG
and GF,not from a Ward remainder. Marginal intrinsic0,externaljets0,A0,
original unshifted SMA/CSW/EDS,both probes,all45 directions,symbolic
g10/xi/eta_H. SourcesJa even,JL odd,ghostC odd. External order is Ja,JL,C,
with ascending indices within each family;odd duplicates vanish.

Use actual canonical QG coefficients. Euclidean action is-Wick(action),
auxiliary/B0/temporaljet phases-i/+i/+i,sourceJa phase1,JL phase-i.
Literal left derivatives carry the established Hessian sign
(-1)^(p_second*(p_first+1)). Quantum row momentum-q,column+q.
Retain all four vector/jet components before Fourier evaluation.

Primary canonicalizes the Euclidean density before differentiation;
replay differentiates original ordered positions,computes crossing signs
directly,then normalizes residual source/ghost order. Ordinary GF quartic
aaCC is transformed with the authenticated ghost charts:primary density
first versus replay Hessian first. Original mixed ghost current,JaCa,
JLCLambda andJLCCa vertices remain authenticated classical dependencies,
not targets to rederive from a guessed sign. New uJa aC will be compared
late with the previously qualified actual classical V,not quantum values.

Preserve source-only/one-port terms and exclusions. Select two quantum
ports before restricting remaining ordinary means toC0..2. Keep source
degreesJa0..1,JL0..2 and all actual quantum bosonic/ghost blocks in that
domain. In particular retain H_CC|JLJL and H_aa|CC,including mixed-source
pair signs. Do not simplify to an ordinary ghost-Trlog until a full doubled
ghost determinant or equivalent Pfaffian reduction has justified it.

Acceptance:full distinct-derivation coefficient/implicit-zero agreement,
actual typed-pattern coverage,Lorentz/jet and reverse graded orientations,
all8 signed unit axes and late classical V comparison. Prove allD support
or retain unqualified dimensional terms. This is a classical prerequisite,
not measured u-contact amplitudes or a full QAP/master theorem.

Natives300s,review180s afterimports,8GiB sampled private,350MiB available-
pagefile launch floor,32MiBpacket. Freeze sources/copies/inputs/hashes first.
Preserve failures/exhaustion,new version for routine corrections. No
unknown coefficient/chi4/b0/kappa/IR choice or negative residual operand.
Shared action/maps/charts/data/ring/runtime/AI authorship limit independence.
