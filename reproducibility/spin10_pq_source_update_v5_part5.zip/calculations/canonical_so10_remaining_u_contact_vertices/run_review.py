from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/remaining-u-contact-vertices-v1-2026-10-26');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'preparation_v2.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 ip={'old_classical_container':str(O.parent/'canonical_so10_intrinsic_quadratic_source_contacts/color_primary_tables.json.gz'),'support':str(O.parent/'canonical_so10_remaining_u_contacts_support/support_primary_tables.json.gz')};dump(O/'review_inputs.json',ip)
 for p in map(Path,ip.values()):b[str(p)]=H(p)
 for n in['REVIEW_RECORD.md','verify.py','run_review.py']:
  p=O/n
  with(O/(n+'.source.txt')).open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
 for p in O.iterdir():
  if p.is_file():b[str(p)]=H(p)
 dump(O/'review_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
 z=capture([sys.executable,'-B',str(O/'verify.py')]);dump(O/'review_capture.json',z);dump(C/'review_full_capture.json',z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
 rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<180;dump(O/'validation_receipt.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2;print(json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'review_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
