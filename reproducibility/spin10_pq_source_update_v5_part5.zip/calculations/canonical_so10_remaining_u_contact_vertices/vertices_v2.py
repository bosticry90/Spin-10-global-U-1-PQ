from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from fractions import Fraction
from collections import defaultdict,Counter
from itertools import product
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'preparation_v2.json')['input_sha256'].items():assert H(Path(p))==h,p
cp=Path(read(O/'inputs.json')['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient,Coeff,constant,I as CI,verify_basis_products
assert verify_basis_products()==1024;g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
d=load(O/('vertices_'+role+'_inputs.json.gz'));audit=d['audit'];names=audit['names'];geo=audit['geometry'];base=geo['names'];fields={names.index(base[f]):base[f]for f,J,h,k in geo['field_source_h_k']};sources={names.index(base[J]):base[f]for f,J,h,k in geo['field_source_h_k']};aux=[('b'if i<12 else'L')+str(i)for i in range(45)];ants=[('bar'if i<12 else'ub')+str(i)for i in range(45)];xs=d['xs'];xid={n:i for i,n in enumerate(xs)}
def idx(n):
 if n in aux:return 180+aux.index(n)
 if n in ants:return 270+ants.index(n)
 if n in xid:return 405+xid[n]
 if n.startswith('B'):a,mu=n[1:].split('_');return 4*int(a)+int(mu)
 if n.startswith('C'):return 225+int(n[1:])
 raise AssertionError(('unclassified_field',n))
def pp(i):return int(225<=i<360)
def isfield(i):return i<315 or i>=405
def kind(i):return'B'if i<180 else'L'if i<225 else'C'if i<270 else'a'if i<315 else'JL'if i<360 else'Ja'if i<405 else'x'
def dim(i):return 2 if kind(i)in['L','Ja']else 1
def fieldphase(i):return-CI if kind(i)in['L','JL']else CI if kind(i)=='B'and i%4==0 else constant(1)
def wick(w):
 v=constant(-1)
 for i,jets in w:
  v=v*fieldphase(i)
  for mu in jets:
   if mu=='0':v=v*CI
 return v
def clean(D):return{k:v for k,v in D.items()if v}
@lru_cache(None)
def canon(w,ext=False):
 key=lambda t:({'Ja':0,'JL':1,'C':2}.get(kind(t[0]),3),t)if ext else t
 odd=[z for z in w if pp(z[0])]
 if len(set(odd))!=len(odd):return(),0
 sg=(-1)**sum(key(a)>key(b)for at,a in enumerate(odd)for b in odd[at+1:]);return tuple(sorted(w,key=key)),sg
def eligible(w):return all(not jets and kind(i)in['Ja','JL','C']for i,jets in w)and sum(kind(i)=='Ja'for i,jets in w)<=1 and sum(kind(i)=='JL'for i,jets in w)<=2 and sum(kind(i)=='C'for i,jets in w)<=2
raw={};excluded=Counter();low=[]
for probe,p in enumerate(audit['physical_QG']):
 rows=[]
 for at,(gp,w,ci)in enumerate(p['monomials']):
  if any(n not in fields and n not in sources for n,I in w):excluded['background_or_control_at_A0']+=1;continue
  ww=tuple(((315+aux.index(sources[n])if sources[n]in aux else 360+ants.index(sources[n]))if n in sources else idx(names[n]),''.join(map(str,I)))for n,I in w)
  if any(kind(i)in['JL','Ja']and jets for i,jets in ww):excluded['external_source_jet']+=1;continue
  if 4-sum(dim(i)+len(jets)for i,jets in ww)!=0:excluded['other_intrinsic_degree']+=1;continue
  if sum(kind(i)=='Ja'for i,jets in ww)>1 or sum(kind(i)=='JL'for i,jets in ww)>2:excluded['other_source_grade']+=1;continue
  v=Coeff([((gp,xp,ep,m),Fraction(num,den))for xp,ep,m,num,den in p['coefficients'][ci]])
  if sum(isfield(i)for i,jets in ww)<2:low.append({'probe':probe,'reference':at,'word':[[i,jets]for i,jets in ww],'coefficient_E':str(v*wick(ww))})
  rows.append((ww,v))
 raw['u'+str(probe)]=rows
# Only the ordinary quartic aaCC block is newly needed from GF. Other
# qualified currents/source vertices are reused separately,not recomputed.
frame=d['frame'];phys=[f'B{i}_{mu}'for i in range(45)for mu in range(4)]+xs+aux+['C'+str(i)for i in range(45)]+ants;ri={n:i for i,n in enumerate(frame['field_order'])};pi={n:i for i,n in enumerate(phys)};by=defaultdict(list)
for a,b,z in frame['physical_to_raw_inverse']['entries']:
 if a>=0:
  n=frame['field_order'][a]
  if n in ants or n.startswith('C'):
   nn=phys[b];assert nn in ants or nn.startswith('C');by[idx(n)].append((idx(nn),co(z)))
GF=[]
for row in d['GF']:
 ww=[]
 for token in row['word']:
  n,sep,jets=token.partition('__')
  if jets or not(n in ants or n.startswith('C')):break
  ww.append((idx(n),jets))
 else:
  if len(ww)==4 and sum(kind(i)=='a'for i,jets in ww)==2 and sum(kind(i)=='C'for i,jets in ww)==2:GF.append((tuple(ww),co(row['coefficient'])))
raw['GFquartic']=GF
def expansions(w,group):
 if group!='GFquartic':yield tuple((i,jets,constant(1))for i,jets in w);return
 yield from product(*[[(j,jets,z)for j,z in by[i]]for i,jets in w])
tables={}
for group,rows in raw.items():
 out=defaultdict(lambda:0)
 if role=='primary':
  density=defaultdict(lambda:0)
  for w,v in rows:
   for chosen in expansions(w,group):
    ww=tuple((i,jets)for i,jets,z in chosen);cw,sg=canon(ww)
    if not sg:continue
    z=v*wick(w)*sg
    for i,jets,fac in chosen:z=z*fac
    density[cw]+=z
  for w,v in clean(density).items():
   for at,(i,ji)in enumerate(w):
    if not isfield(i):continue
    ww=w[:at]+w[at+1:];sg=(-1)**(pp(i)*sum(pp(n)for n,jets in w[:at]))
    for pos,(j,jj)in enumerate(ww):
     if not isfield(j):continue
     rest=ww[:pos]+ww[pos+1:]
     if not eligible(rest):continue
     ext,es=canon(rest,True);tg=(-1)**(pp(j)*sum(pp(n)for n,jets in ww[:pos])+pp(j)*(pp(i)+1));out[i,ji,j,jj,tuple(n for n,jets in ext)]+=v*sg*tg*es
 else:
  rawH=defaultdict(lambda:0)
  for w,v in rows:
   for at,(i,ji)in enumerate(w):
    if not isfield(i):continue
    for pos,(j,jj)in enumerate(w):
     if at==pos or not isfield(j):continue
     rest=tuple(z for k,z in enumerate(w)if k not in[at,pos])
     if not eligible(rest):continue
     crossing=pp(i)*sum(pp(n)for n,jets in w[:at])+pp(j)*(sum(pp(n)for n,jets in w[:pos])-pp(i)*int(at<pos))+pp(j)*(pp(i)+1);rawH[i,ji,j,jj,rest]+=v*wick(w)*((-1)**crossing)
  for(i,ji,j,jj,rest),v in clean(rawH).items():
   for chosen in expansions(((i,ji),(j,jj))+rest,group):
    (a,ja,va),(b,jb,vb),*other=chosen;cw,sg=canon(tuple((n,jets)for n,jets,z in other),True)
    if not sg:continue
    z=v*va*vb*sg
    for n,jets,fac in other:z=z*fac
    out[a,ja,b,jb,tuple(n for n,jets in cw)]+=z
 tables[group]=clean(out)
def fourier(axis,q):
 out={}
 for group,D in tables.items():
  T=defaultdict(lambda:0)
  for(i,ji,j,jj,ext),v in D.items():
   if any(int(mu)!=axis for mu in ji+jj):continue
   z=v
   for mu in ji:z=z*(-CI*q)
   for mu in jj:z=z*(CI*q)
   T[i,j,ext]+=z
  out[group]=clean(T)
 return out
enc=lambda D:[[i,ji,j,jj,list(ext),str(v)]for(i,ji,j,jj,ext),v in sorted(D.items())];fenc=lambda D:[[i,j,list(ext),str(v)]for(i,j,ext),v in sorted(D.items())];patterns={}
for group,D in tables.items():
 counts=Counter()
 for i,ji,j,jj,ext in D:counts[kind(i),kind(j),tuple(kind(n)for n in ext),len(ji),len(jj)]+=1
 patterns[group]=[[*key,n]for key,n in sorted(counts.items())]
out={'schema':'UCV1_ACTUAL_MARGINAL_U_CONTACT_HESSIANS','role':role,'groups':{k:enc(v)for k,v in tables.items()},'Fourier_unit_axes':[{'axis':a,'q':q,'groups':{k:fenc(v)for k,v in fourier(a,q).items()}}for a in range(4)for q in[1,-1]],'patterns':patterns,'excluded':dict(excluded),'low_port_classical_terms':low,'field_layout':'B0..179,L180..224,C225..269,a270..314,JL315..359,Ja360..404,x405..732','external_order':'Ja then JL then C;ascending within each family','actual_quantum_contact_coefficients_measured':False};rawbytes=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(rawbytes,mtime=0)
with(O/('vertices_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(rawbytes).hexdigest(),'Hessian_counts':{k:len(v)for k,v in tables.items()},'patterns':patterns,'classical_low_port_terms':len(low),'quantum_contact_coefficients_measured':False},sort_keys=True),flush=True);timer.cancel()
