from pathlib import Path
from hashlib import sha256
import ast, json, sys, traceback
O = Path(__file__).resolve().parent
R = O.parents[1]
C = Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/remaining-u-contact-vertices-v1-2026-10-26')
sys.path.insert(0, str(R / 'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H = lambda p: sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_bytes())
def dump(path, value):
    with path.open('xb') as f:
        f.write((json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode())
try:
    assert read(O / 'validation_receipt.json')['fixed_Djet0_structural_for_declared_contacts']
    bindings = dict(read(O / 'review_preparation_v2.json')['input_sha256'])
    for path, digest in bindings.items():
        assert H(Path(path)) == digest, path
    for name in ['GAUSSIAN_RECORD.md', 'gaussian.py', 'run_gaussian.py']:
        path = O / name
        with (O / (name + '.source.txt')).open('xb') as f:
            f.write(path.read_bytes())
        if path.suffix == '.py':
            ast.parse(path.read_bytes())
    for path in O.iterdir():
        if path.is_file():
            bindings[str(path)] = H(path)
    dump(O / 'gaussian_preparation.json', {'input_sha256': bindings, 'seconds_after_imports': 300, 'scientific_acceptance': 'NOT_PERFORMED'})
    for role in ['primary', 'replay']:
        result = capture([sys.executable, '-B', str(O / 'gaussian.py'), role])
        dump(O / ('gaussian_' + role + '_capture.json'), result)
        dump(C / ('gaussian_' + role + '_full_capture.json'), result)
        assert result['exit_code'] == 0 and result['execution_state'] == 'COMPLETED' and result['calculation_completed'] and result['post_run_observations_qualified']
        assert result['launch']['memory']['available_pagefile'] >= 350 * 1024 ** 2
        assert max(row['private_bytes'] for row in result['all_resource_samples']) <= 8 * 1024 ** 3
        values = [json.loads(row[7:]) for row in result['stdout_and_stderr'].splitlines() if row.startswith('RESULT ')]
        assert len(values) == 1 and values[0]['elapsed_after_imports'] < 300
        dump(O / ('gaussian_' + role + '_result.json'), values[0])
        assert sum(path.stat().st_size for path in O.iterdir() if path.is_file()) < 32 * 1024 ** 2
        print('COMPLETED_UCV3', role, json.dumps(values[0], sort_keys=True), flush=True)
except BaseException:
    dump(O / 'gaussian_controller_failure.json', {'execution_state': 'FAILED', 'traceback': traceback.format_exc(), 'failure_relabelled_PASS': False})
    raise
