from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import gzip, json, os, sys, threading, time
import sympy as s

O = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_bytes())
load = lambda p: json.loads(gzip.decompress(p.read_bytes()))
H = lambda p: sha256(p.read_bytes()).hexdigest()
role = sys.argv[1]
assert role in ['primary', 'replay']
tick = time.perf_counter()
timer = threading.Timer(300, lambda: os._exit(124))
timer.daemon = True
timer.start()
for path, digest in read(O / 'k_model_preparation.json')['input_sha256'].items():
    assert H(Path(path)) == digest, path
def guard(event, args):
    if event == 'open' and args and isinstance(args[0], (str, bytes)):
        path = Path(os.fsdecode(args[0]))
        peer = 'replay' if role == 'primary' else 'primary'
        if path.parent.resolve() == O and path.name.startswith('k_model_' + peer):
            raise PermissionError('UCV5_PEER_DENIED')
        if path.parent.name in ['canonical_so10_intrinsic_full_source_descent', 'canonical_so10_intrinsic_correlated_source_contacts'] and path.name.startswith(('variation', 'partial_H', 'lowering', 'contact_color')):
            raise PermissionError('UCV5_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard)
cp = Path(read(O / 'inputs.json')['coefficient_ring'])
sys.path.insert(0, str(cp.parent))
from coefficient_ring import coefficient
g, xi, eta = s.symbols('g10 xi eta_H', real=True)
@lru_cache(None)
def co(value):
    return coefficient(s.expand(s.sympify(value, locals={'g10': g, 'xi': xi, 'eta_H': eta})))
def clean(values):
    return {key: value for key, value in values.items() if value}
def dec(value):
    return {(i, j): co(v) for i, j, v in value['entries']}
def tab(rows):
    return {tuple(row[:-1]): co(row[-1]) for row in rows}
def mm(first, second):
    rows, result = defaultdict(list), defaultdict(lambda: 0)
    for (i, j), value in second.items():
        rows[i].append((j, value))
    for (i, k), value in first.items():
        for j, other in rows[k]:
            result[i, j] += value * other
    return clean(result)
def plus(*terms):
    result = defaultdict(lambda: 0)
    for values, factor in terms:
        for key, value in values.items():
            result[key] += factor * value
    return clean(result)
def family(rows, indices=45):
    result = [{} for j in range(indices)]
    for source, a, c, value in rows:
        result[source][a, c] = co(value)
    return result
def trace_index(fam):
    result = defaultdict(list)
    for source, matrix in enumerate(fam):
        for key, value in matrix.items():
            result[key].append((source, value))
    return result
def trace_direct(fam_index, matrix, r, h, output, factor=1):
    for (a, c), value in matrix.items():
        for source, other in fam_index[c, a]:
            output[source, r, h] += factor * value * other
def trace_unfold(fam, matrices):
    left = {(source, a * 45 + c): value for source, matrix in enumerate(fam) for (a, c), value in matrix.items()}
    right = {(c * 45 + a, r * 45 + h): value for (r, h), matrix in matrices.items() for (a, c), value in matrix.items()}
    return {(source, rh // 45, rh % 45): value for (source, rh), value in mm(left, right).items()}
d = load(O / ('k_model_' + role + '_inputs.json.gz'))
G = dec(d['G0'])
A, W = family(d['A']), family(d['W'])
J = list(map(dec, d['J0']))
Zraw = tab(d['Z0'])
Z = defaultdict(dict)
for (r, h, a, c), value in Zraw.items():
    Z[r, h][a, c] = value
GW = [mm(G, matrix) for matrix in W]
JG = [mm(matrix, G) for matrix in J]
GWb = [{(b, c): value for (b, c), value in matrix.items() if b < 45} for matrix in GW]
JGb = [{(a, b): value for (a, b), value in matrix.items() if b < 45} for matrix in JG]
results = []
for probe, new in enumerate(d['u_vertices']):
    Ku = tab(new['Ku'])
    V, Y = family(new['V']), family(new['Y'])
    Ju = family(new['Ju'])
    Zu = defaultdict(dict)
    for (r, h, a, c), value in tab(new['Zu']).items():
        Zu[r, h][a, c] = value
    groups = {key: defaultdict(lambda: 0) for key in ['A_Zu', 'V_Z', 'A_Ju_G_W', 'V_J_G_W', 'J_G_Y_G_W', 'minus_A_J_G_Ku_G_W']}
    if role == 'primary':
        ai, vi, yi = trace_index(A), trace_index(V), trace_index(Y)
        Qr = [mm(mm(G, Ku), matrix) for matrix in GW]
        for r in range(45):
            for h in range(45):
                trace_direct(ai, Zu[r, h], r, h, groups['A_Zu'])
                trace_direct(vi, Z[r, h], r, h, groups['V_Z'])
                trace_direct(ai, mm(Ju[h], GW[r]), r, h, groups['A_Ju_G_W'])
                trace_direct(vi, mm(J[h], GW[r]), r, h, groups['V_J_G_W'])
                trace_direct(yi, mm(GWb[r], JGb[h]), r, h, groups['J_G_Y_G_W'])
                trace_direct(ai, mm(J[h], Qr[r]), r, h, groups['minus_A_J_G_Ku_G_W'], -1)
    else:
        groups['A_Zu'] = trace_unfold(A, Zu)
        groups['V_Z'] = trace_unfold(V, Z)
        JuG = [mm(matrix, G) for matrix in Ju]
        JGKuG = [mm(mm(matrix, Ku), G) for matrix in JG]
        matrices = {name: {} for name in ['A_Ju_G_W', 'V_J_G_W', 'minus_A_J_G_Ku_G_W']}
        for r in range(45):
            for h in range(45):
                matrices['A_Ju_G_W'][r, h] = mm(JuG[h], W[r])
                matrices['V_J_G_W'][r, h] = mm(JG[h], W[r])
                matrices['minus_A_J_G_Ku_G_W'][r, h] = mm(JGKuG[h], W[r])
        groups['A_Ju_G_W'] = trace_unfold(A, matrices['A_Ju_G_W'])
        groups['V_J_G_W'] = trace_unfold(V, matrices['V_J_G_W'])
        groups['minus_A_J_G_Ku_G_W'] = {key: -value for key, value in trace_unfold(A, matrices['minus_A_J_G_Ku_G_W']).items()}
        left = {(h, a * 45 + b): value for h, matrix in enumerate(JGb) for (a, b), value in matrix.items()}
        right = {}
        for source in range(45):
            for r in range(45):
                for (b, a), value in mm(Y[source], GWb[r]).items():
                    right[a * 45 + b, source * 45 + r] = value
        groups['J_G_Y_G_W'] = {(sr // 45, sr % 45, h): value for (h, sr), value in mm(left, right).items()}
    groups = {key: clean(values) for key, values in groups.items()}
    heat = {2: plus((groups['A_Zu'], 1), (groups['V_Z'], 1)),
            3: plus((groups['A_Ju_G_W'], 1), (groups['V_J_G_W'], 1), (groups['J_G_Y_G_W'], 1)),
            4: groups['minus_A_J_G_Ku_G_W']}
    pole = plus(*[(values, 1) for values in heat.values()])
    basis = {'chi4': pole, 'log2': plus((heat[4], 1), (heat[3], -1)), 'log3': heat[3], 'log5': {}, 'fixed': {}}
    encode = lambda values: [[*key, str(value)] for key, value in sorted(values.items())]
    for values in list(groups.values()) + list(heat.values()) + list(basis.values()):
        assert all(0 <= source < 45 and 0 <= r < 45 and 0 <= h < 45 for source, r, h in values)
    powers = sorted({key[:3] for values in heat.values() for value in values.values() for key, q in value.terms})
    results.append({'probe': probe, 'groups': {key: encode(values) for key, values in groups.items()},
                    'heat': {str(m): encode(values) for m, values in heat.items()},
                    'relative': {key: encode(values) for key, values in basis.items()}, 'parameter_powers': powers})
    print('STAGE UCV5', role, probe, [len(heat[m]) for m in [2, 3, 4]], 'pole', len(pole), flush=True)
out = {'schema': 'UCV5_COMPLETE_U_JA_JL_C_MODEL_CONTACT', 'role': role, 'results': results,
       'full_positions_per_tensor_probe': 91125, 'density': 'u Ja_s JL_r C_h K_srh;no extra half',
       'common_normalization': 'hbar/(16pi^2)', 'second_contact_unmeasured_not_discarded': True,
       'whole_source_identity_QAP_E5_or_physical_promotion': False}
raw = (json.dumps(out, sort_keys=True, separators=(',', ':')) + '\n').encode()
blob = gzip.compress(raw, mtime=0)
with (O / ('k_model_' + role + '_tables.json.gz')).open('xb') as f:
    f.write(blob)
print('RESULT ' + json.dumps({'elapsed_after_imports': time.perf_counter() - tick,
      'packed_sha256': sha256(blob).hexdigest(), 'raw_sha256': sha256(raw).hexdigest(),
      'heat_pole_counts': [[len(row['heat'][str(m)]) for m in [2, 3, 4]] + [len(row['relative']['chi4'])] for row in results],
      'group_counts': [{key: len(values) for key, values in row['groups'].items()} for row in results],
      'model_second_contact_or_QAP_E5_claim': False}, sort_keys=True), flush=True)
timer.cancel()
