from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import gzip, json, os, sys, threading, time
import sympy as s

O = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_bytes())
load = lambda p: json.loads(gzip.decompress(p.read_bytes()))
H = lambda p: sha256(p.read_bytes()).hexdigest()
tick = time.perf_counter()
timer = threading.Timer(180, lambda: os._exit(124))
timer.daemon = True
timer.start()
for path, digest in read(O / 'k_model_validation_preparation.json')['input_sha256'].items():
    assert H(Path(path)) == digest, path
cp = Path(read(O / 'inputs.json')['coefficient_ring'])
sys.path.insert(0, str(cp.parent))
from coefficient_ring import coefficient, constant
g, xi, eta = s.symbols('g10 xi eta_H', real=True)
@lru_cache(None)
def co(value):
    return coefficient(s.expand(s.sympify(value, locals={'g10': g, 'xi': xi, 'eta_H': eta})))
def clean(values):
    return {key: value for key, value in values.items() if value}
def plus(*terms):
    result = defaultdict(lambda: 0)
    for values, factor in terms:
        for key, value in values.items():
            result[key] += factor * value
    return clean(result)
tab = lambda rows: {tuple(row[:-1]): co(row[-1]) for row in rows}
dec = lambda matrix: {(i, j): co(v) for i, j, v in matrix['entries']}
primary, replay = [load(O / ('k_model_' + role + '_tables.json.gz')) for role in ['primary', 'replay']]
data = load(O / 'k_model_primary_inputs.json.gz')
actual = load(Path(read(O / 'k_model_validation_inputs.json')['actual_vertices']))
A, W = tab(data['A']), tab(data['W'])
Z = tab(data['Z0'])
J, G0 = list(map(dec, data['J0'])), dec(data['G0'])
def pmul(first, second):
    result = defaultdict(lambda: 0)
    for a, value in first.items():
        for b, other in second.items():
            if a & b:
                continue
            crossing = sum(i > j for i in [2, 3] for j in [2, 3] if a & (1 << i) and b & (1 << j))
            result[a | b] += (-1) ** crossing * value * other
    return clean(result)
def mm(first, second):
    rows, result = defaultdict(list), {}
    for (i, j), value in second.items():
        rows[i].append((j, value))
    for (i, k), value in first.items():
        for j, other in rows[k]:
            result[i, j] = plus((result.get((i, j), {}), 1), (pmul(value, other), 1))
    return clean(result)
def insert(matrix, i, j, mask, value):
    if value:
        matrix[i, j] = plus((matrix.get((i, j), {}), 1), ({mask: value}, 1))
def index(i):
    if i < 180:
        return i // 4 if i % 4 == 3 else None
    if i < 225:
        return 45 + i - 180
    if i < 270:
        return 90 + i - 225
    if i < 315:
        return 135 + i - 270
    return None
def pieces(probe, source, r, h, q):
    GG, VV = {}, {}
    for (i, j), value in G0.items():
        insert(GG, i, j, 0, value * q if (i < 45 <= j or j < 45 <= i) else value)
    for c in range(45):
        insert(GG, 90 + c, 135 + c, 0, constant(1))
        insert(GG, 135 + c, 90 + c, 0, constant(-1))
    for (ss, a, c), value in A.items():
        if ss == source:
            insert(VV, 135 + a, 90 + c, 2, value)
            insert(VV, 90 + c, 135 + a, 2, -value)
    for (rr, b, c), value in W.items():
        if rr == r:
            insert(VV, b, 90 + c, 4, value)
            insert(VV, 90 + c, b, 4, -value)
    for (a, b), value in J[h].items():
        vv = q * value if b < 45 else value
        insert(VV, 135 + a, b, 8, vv)
        insert(VV, b, 135 + a, 8, vv if b < 45 else -vv)
    for (rr, hh, a, c), value in Z.items():
        if rr == r and hh == h:
            insert(VV, 135 + a, 90 + c, 12, value)
            insert(VV, 90 + c, 135 + a, 12, -value)
    rows = next(row['groups']['u' + str(probe)] for row in actual['Fourier_unit_axes'] if row['axis'] == 3 and row['q'] == q)
    external = {360 + source: 2, 315 + r: 4, 225 + h: 8}
    for i, j, ext, value in rows:
        if any(n not in external for n in ext):
            continue
        bits = [external[n] for n in ext]
        if len(set(bits)) != len(bits):
            continue
        ii, jj = index(i), index(j)
        if ii is None or jj is None:
            continue
        insert(VV, ii, jj, 1 | sum(bits), co(value))
    return GG, VV
def logarithm(GG, VV):
    operator = mm(GG, VV)
    power = {(i, i): {0: constant(1)} for i in range(180)}
    result = {}
    for m in range(1, 5):
        power = mm(power, operator)
        trace = sum(((-1) ** int(i >= 90) * values.get(15, 0) for (i, j), values in power.items() if i == j), 0)
        result[m] = co(str(s.Rational((-1) ** (m + 1), 2 * m))) * trace
    return result
summaries, literal_checks, controls = [], [], []
for probe in range(2):
    first, second = primary['results'][probe], replay['results'][probe]
    groups = {key: tab(rows) for key, rows in first['groups'].items()}
    assert groups == {key: tab(rows) for key, rows in second['groups'].items()}
    heat = {int(m): tab(rows) for m, rows in first['heat'].items()}
    assert heat == {int(m): tab(rows) for m, rows in second['heat'].items()}
    assert heat[2] == plus((groups['A_Zu'], 1), (groups['V_Z'], 1))
    assert heat[3] == plus((groups['A_Ju_G_W'], 1), (groups['V_J_G_W'], 1), (groups['J_G_Y_G_W'], 1))
    assert heat[4] == groups['minus_A_J_G_Ku_G_W']
    pole = plus(*[(values, 1) for values in heat.values()])
    basis = {'chi4': pole, 'log2': plus((heat[4], 1), (heat[3], -1)), 'log3': heat[3], 'log5': {}, 'fixed': {}}
    assert basis == {key: tab(rows) for key, rows in first['relative'].items()} == {key: tab(rows) for key, rows in second['relative'].items()}
    assert first['parameter_powers'] == second['parameter_powers']
    for values in list(groups.values()) + list(heat.values()) + list(basis.values()):
        assert all(0 <= source < 45 and 0 <= r < 45 and 0 <= h < 45 for source, r, h in values)
    samples = {(13, 13, 0)}
    for values in list(heat.values()) + [groups['J_G_Y_G_W']]:
        if values:
            samples.update([min(values), max(values)])
    assert len(samples) <= 7
    detected = {'Y': False, 'V': False}
    for source, r, h in sorted(samples):
        for q in [1, -1]:
            GG, VV = pieces(probe, source, r, h, q)
            value = logarithm(GG, VV)
            assert not value[1] and all(value[m] == heat[m].get((source, r, h), 0) for m in [2, 3, 4]), ('literal180_mismatch', probe, source, r, h, q, {m: str(v) for m, v in value.items()})
            literal_checks.append([probe, source, r, h, q, {str(m): str(value[m]) for m in [2, 3, 4]}])
            if q == 1:
                for ctrl in ['Y', 'V', 'Zu', 'Ju', 'Ku', 'sourceZ']:
                    changed = {ij: dict(poly) for ij, poly in VV.items()}
                    for (i, j), poly in changed.items():
                        if ctrl == 'Y' and i < 90 and j < 90:
                            poly.pop(3, None)
                        elif ctrl == 'V' and i >= 90 and j >= 90:
                            poly.pop(3, None)
                        elif ctrl == 'Zu':
                            poly.pop(13, None)
                        elif ctrl == 'Ju':
                            poly.pop(9, None)
                        elif ctrl == 'Ku':
                            poly.pop(1, None)
                        elif ctrl == 'sourceZ':
                            poly.pop(12, None)
                    altered = logarithm(GG, clean({ij: clean(poly) for ij, poly in changed.items()}))
                    different = [m for m in range(1, 5) if altered[m] != value[m]]
                    if ctrl in detected:
                        detected[ctrl] |= bool(different)
                    controls.append({'probe': probe, 'sample': [source, r, h], 'control': ctrl, 'changed_heat': different})
    for control, group in [('Y', 'J_G_Y_G_W'), ('V', 'V_Z')]:
        if any(groups[group].get(sample, 0) for sample in samples):
            assert detected[control]
    summaries.append({'probe': probe, 'heat_nonzero_zero': [[m, len(heat[m]), 91125 - len(heat[m])] for m in [2, 3, 4]], 'pole_nonzero': len(pole), 'parameter_powers': first['parameter_powers'], 'sensitive_sampled_Y_V': detected})
for role in ['primary', 'replay']:
    record = read(O / ('k_model_' + role + '_result.json'))
    path = O / ('k_model_' + role + '_tables.json.gz')
    assert H(path) == record['packed_sha256'] and sha256(gzip.decompress(path.read_bytes())).hexdigest() == record['raw_sha256']
print('RESULT ' + json.dumps({'elapsed_after_imports': time.perf_counter() - tick,
      'full_group_heat_pole_prime_and_zero_complement_agreement': True,
      'summaries': summaries, 'literal180_checks_both_q': literal_checks, 'model_controls': controls,
      'u_JL_JL_CC_still_unmeasured': True, 'whole_source_identity_QAP_E5_or_physical_promotion': False}, sort_keys=True), flush=True)
timer.cancel()
