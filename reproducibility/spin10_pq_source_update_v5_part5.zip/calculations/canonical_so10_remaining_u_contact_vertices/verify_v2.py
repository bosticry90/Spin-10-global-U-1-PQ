from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
from itertools import permutations
import re,json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'review_preparation_v2.json')['input_sha256'].items():assert H(Path(p))==h,p
assert not(O/'preparation.json').exists()and read(O/'controller_failure.json')['execution_state']=='FAILED';original=(O/'vertices.py').read_text();assert re.sub(r'\b(return|else)(?=[0-9])',r'\1 ',original).replace("O/'preparation.json'","O/'preparation_v2.json'")==(O/'vertices_v2.py').read_text()
cp=Path(read(O/'inputs.json')['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient,constant,I as CI
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
def htab(rows):return{(i,ji,j,jj,tuple(ext)):co(v)for i,ji,j,jj,ext,v in rows}
def ftab(rows):return{(i,j,tuple(ext)):co(v)for i,j,ext,v in rows}
def clean(D):return{k:v for k,v in D.items()if v}
def pp(i):return int(225<=i<360)
def kind(i):return'B'if i<180 else'L'if i<225 else'C'if i<270 else'a'if i<315 else'JL'if i<360 else'Ja'if i<405 else'x'
native_primary,native_replay=[load(O/('vertices_'+role+'_tables.json.gz'))for role in['primary','replay']];TT={k:htab(v)for k,v in native_primary['groups'].items()};assert TT=={k:htab(v)for k,v in native_replay['groups'].items()};assert native_primary['patterns']==native_replay['patterns']and native_primary['low_port_classical_terms']==native_replay['low_port_classical_terms'];uniformY={};vector_jet=0
for group,D in TT.items():
 for(i,ji,j,jj,ext),v in D.items():
  assert D.get((j,jj,i,ji,ext),0)==((-1)**(pp(i)+pp(j)+pp(i)*pp(j)))*v
  assert len([n for n in ext if pp(n)])==len(set(n for n in ext if pp(n)))
  if i<180:
   if ji or jj:assert ji==str(i%4),('unmatched_vector_jet',group,i,ji,j,jj);vector_jet+=1
   else:
    assert j<180 and i%4==j%4;uniformY.setdefault((group,i//4,j//4,ext),{})[i%4]=v
  if j<180 and(ji or jj):assert jj==str(j%4)
for key,DD in uniformY.items():assert set(DD)=={0,1,2,3}and len(set(DD.values()))==1
FF={}
for primary,replay in zip(native_primary['Fourier_unit_axes'],native_replay['Fourier_unit_axes']):
 axis,q=primary['axis'],primary['q'];assert(axis,q)==(replay['axis'],replay['q']);F={k:ftab(rows)for k,rows in primary['groups'].items()};assert F=={k:ftab(rows)for k,rows in replay['groups'].items()}
 for group,D in TT.items():
  calc=defaultdict(lambda:0)
  for(i,ji,j,jj,ext),v in D.items():
   if any(int(mu)!=axis for mu in ji+jj):continue
   calc[i,j,ext]+=co(str((-s.I*q)**len(ji)*(s.I*q)**len(jj)))*v
  assert clean(calc)==F[group]
 FF[axis,q]=F
for axis in range(4):
 for group,D in FF[axis,1].items():
  for(i,j,ext),v in D.items():assert FF[axis,-1][group].get((j,i,ext),0)==((-1)**(pp(i)+pp(j)+pp(i)*pp(j)))*v
# The full antisymmetric pair sum has4 equal signed contributions;1/4
# makes its sorted-source/sorted-ghost coefficient exactly the tensor.
weight=s.Rational(0)
for sr in permutations([0,1]):
 for hk in permutations([2,3]):
  word=sr+hk;tensor_sign=(-1)**(int(sr[0]>sr[1])+int(hk[0]>hk[1]));reorder=(-1)**sum(a>b for at,a in enumerate(word)for b in word[at+1:]);weight+=s.Rational(tensor_sign*reorder,4)
assert weight==1
ip=read(O/'review_inputs.json');old=load(Path(ip['old_classical_container']));late=[]
for probe in range(2):
 V={}
 for(i,j,ext),v in FF[3,1]['u'+str(probe)].items():
  if 270<=i<315 and 225<=j<270 and len(ext)==1 and 360<=ext[0]<405:V[ext[0]-360,i-270,j-225]=v
 expected={(r,a,c):co(v)for r,M in enumerate(old['results'][probe]['V_u_Ja_aC'])for a,c,v in M['entries']};assert V==expected,('actual_uJa_classical_V_disagrees',probe);late.append(len(V))
support=load(Path(ip['support']));pins=metriclinks=components=0
for target in support['results']:
 for word in target['ordered_words']:
  ww=word['letters'];path=word['Green_path'];nodes=set();marks=set();edges=[];n=len(ww)
  for at,ix in enumerate(ww):
   z=support['letters'][ix];left,right=z['H_ports'];before=path[at]
   for side,k in[(0,left),(1,right)]:
    if k=='B':nodes.add((at,side))
   if left==right=='B':
    if any(z['internal_jet_orders']):assert z['internal_jet_orders']==[1,1];marks.update([(at,0),(at,1)])
    else:edges.append(((at,0),(at,1)))
   elif'B'in[left,right]:assert sum(z['internal_jet_orders'])==1;marks.add((at,0 if left=='B'else 1))
   if before==left=='B':edges.append((((at-1)%n,1),(at,0)))
   elif(before=='B')!=(left=='B'):assert{before,left}=={'B','L'};marks.add(((at-1)%n,1)if before=='B'else(at,0))
  adj={p:set()for p in nodes}
  for a,b in edges:assert a in nodes and b in nodes;adj[a].add(b);adj[b].add(a)
  seen=set()
  for start in nodes:
   if start in seen:continue
   todo=[start];comp=set()
   while todo:
    p=todo.pop()
    if p in comp:continue
    comp.add(p);todo.extend(adj[p]-comp)
   assert comp&marks,('unpinned_Lorentz_cycle',target['target'],word);seen|=comp;components+=1
  pins+=len(marks);metriclinks+=len(edges)
for role in['primary','replay']:
 rr=read(O/('vertices_'+role+'_result.json'));p=O/('vertices_'+role+'_tables.json.gz');assert H(p)==rr['packed_sha256']and sha256(gzip.decompress(p.read_bytes())).hexdigest()==rr['raw_sha256']and rr['elapsed_after_imports']<300
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'complete_actual_vertex_and_all8_Fourier_tables_agree':True,'reverse_graded_and_external_pair_conventions_verified':True,'u_over4_sorted_pair_coefficient':1,'classical_uJa_V_late_match_counts':late,'actual_vector_jet_entries_checked':vector_jet,'metric_Y_Lorentz_entries_checked':4*len(uniformY),'all_supported_vector_components_pinned':components,'pin_occurrences':pins,'metric_links':metriclinks,'fixed_Djet0_structural_for_declared_contacts':True,'doubled_ghost_blocks_nonzero':{group:sum(kind(i)==kind(j)=='a'or kind(i)==kind(j)=='C'for i,ji,j,jj,ext in D)for group,D in TT.items()},'original_prelaunch_syntax_failure_preserved':True,'quantum_contact_coefficients_or_QAP_E5_claim':False},sort_keys=True),flush=True);timer.cancel()
