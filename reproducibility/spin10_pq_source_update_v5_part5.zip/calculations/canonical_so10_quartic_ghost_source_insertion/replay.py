"""QSI1 exact exterior Gaussian, Euler reconstruction and scalar-Lie reduction."""
from data import *
from collections import defaultdict
from functools import lru_cache
from itertools import combinations
start=begin('replay');g=s.Symbol('g10')
# Full eta-even Gaussian with arbitrary two-ghost kinetic matrix.
def add(A,B):
 out=dict(A)
 for k,v in B.items():out[k]=out.get(k,0)+v
 return {k:s.expand(v) for k,v in out.items() if s.expand(v)!=0}
def scale(a,A):return {k:s.expand(a*v) for k,v in A.items() if s.expand(a*v)!=0}
def wedge(A,B):
 out={}
 for a,x in A.items():
  for b,y in B.items():
   if a&b:continue
   sign=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(10) if a&(1<<i));out[a|b]=out.get(a|b,0)+sign*x*y
 return {k:s.expand(v) for k,v in out.items() if s.expand(v)!=0}
def word(indices,co):
 out={0:co}
 for j in indices:out=wedge(out,{1<<j:1})
 return out
F,q11,q12,q21,q22,a,b,u=s.symbols('F q11 q12 q21 q22 alpha beta upsilon',nonzero=True)
action={}
for ww,co in [([4,5],-F),([6,7],-q11),([6,9],-q12),([8,7],-q21),([8,9],-q22),([6,4],a),([0,8,5,3],b),([7,9,1,2],u)]:action=add(action,word(ww,co))
term={0:s.S.One};exponential=dict(term)
for n in range(1,6):term=scale(-s.Rational(1,n),wedge(term,action));exponential=add(exponential,term)
inside=sum(1<<i for i in range(4,10));Z={k^inside:v for k,v in exponential.items() if k&inside==inside};detQ=q11*q22-q12*q21
assert s.expand(Z[0]-F*detQ)==0 and set(Z)=={0,15}
gauss=s.simplify(-Z[15]*F*detQ/(Z[0]*a*b*u))
# Alternating cross term, with eta*c even, has no residual Nambu half.
cross=add(word([0,1,2,3],s.Rational(1,2)),word([0,1,3,2],-s.Rational(1,2)));assert cross=={15:1}
k,l1,l2=s.symbols('k l1 l2');assert s.solve([k+l1,-k+l2,-l1-l2],[l1,l2])=={l1:-k,l2:k}
# Both raw action terms have Fourier coefficient -g/2. Their alternating
# C/charge transpose relation makes the sum -g; source+i,propagator-i,
# all-ghost Euclidean vertex minus follow the fixed action conventions.
unitE=-2*s.Rational(1,2);phase=s.simplify(s.I*unitE*(-s.I)*(-1))
eps,h=s.symbols('epsilon h',positive=True);x,y=s.symbols('x y',nonnegative=True)
area=s.integrate(s.integrate(1,(y,0,1-x)),(x,0,1));reg=h*area*s.gamma(1+eps)/2
radial=s.simplify(s.diff(reg.subs(h,-2*eps),eps).subs(eps,0));wrong_radial=s.simplify(s.diff(reg.subs(h,2*eps),eps).subs(eps,0));pref=s.simplify(gauss*phase*radial)
def key_word(word):
 def tag(n):
  if n.startswith('C'):return 1,int(n[1:])
  if n.startswith('ub'):return 0,int(n[2:])
  if n.startswith('bar'):return 0,int(n[3:])
  return None
 tags=[tag(n) for n in word]
 if len(tags)!=4 or any(t is None for t in tags) or sorted(t for t,j in tags)!=[0,0,1,1]:return None
 assert len(set(tags))==4
 sign=1
 for i in range(4):
  for j in range(i+1,4):
   if tags[i]>tags[j]:sign=-sign
 return tuple(j for t,j in sorted(tags)),sign
E1=read(PK/'frozen_a10_e1_fermion/replay.json');master=packed(ROOT/'tools/portable_dh_v1/inputs.json.gz')['master_field_maps'];H=defaultdict(lambda:s.S.Zero)
for name,erows in E1['Euler_columns'].items():
 if name not in master:continue
 parity=int(name.startswith(('C','bar','ub')));shift=-(-1)**parity
 for er in erows:
  for mr in master[name]:
   ww=er['word']+mr['word']
   if any('__' in v for v in ww):continue
   key=key_word(ww)
   if key is None:continue
   indices,sign=key;H[indices]+=shift*sign*s.sympify(er['coefficient'],locals={'xi':WM,'eta_H':WH})*s.sympify(mr['coefficient'],locals={'xi':WM,'eta_H':WH})
H={k:s.expand(v) for k,v in H.items() if s.expand(v)!=0};components=[]
for key,co in sorted(H.items()):
 for mon,v in s.Poly(co,g).terms():
  if v!=0:components.append((int(mon[0]),*key,s.expand(v)))
Q=dec(read(PK/'frozen_a10_physical_reconciliation/full_replay.json')['C3_plane_to_parent']);Qi=Q.inv();FM=dec(E1['charts']['blocks']['heavy_dual']['field_embedding']);Ad=s.SparseMatrix.hstack(Q[:,:12],FM);Ai=Ad.inv();CG=Qi*Ai.T
def make_minor(M):
 rows={i:[(j,v) for (ii,j),v in s.SparseMatrix(M).todok().items() if ii==i] for i in range(45)}
 @lru_cache(None)
 def minor(a,b):
  out=defaultdict(lambda:s.S.Zero)
  for r,x in rows[a]:
   for t,y in rows[b]:
    if r!=t:out[min(r,t),max(r,t)]+=(1 if r<t else -1)*x*y
  return {k:s.expand(v) for k,v in out.items() if s.expand(v)!=0}
 return minor
anti=make_minor(Ai);ghost=make_minor(Qi);Hp=defaultdict(lambda:s.S.Zero)
for power,a0,b0,c0,d0,co in components:
 for (a1,b1),v in anti(a0,b0).items():
  for (c1,d1),w in ghost(c0,d0).items():Hp[power,a1,b1,c1,d1]+=co*v*w
Hp={k:s.expand(v) for k,v in Hp.items() if s.expand(v)!=0}
fc=defaultdict(list)
for a0,b0,c0,v in packed(HERE/'qualified_reference_inputs.json.gz')['reference_fields']['plane_f']:
 if a0<b0:fc[a0,b0].append((c0,s.sympify(v)))
N=defaultdict(lambda:s.S.Zero)
for (power,a0,b0,c0,d0),co in Hp.items():
 for e,v in fc[a0,b0]:N[power+2,c0,d0,e]+=co*v
N={k:s.expand(v) for k,v in N.items() if s.expand(v)!=0};Ts=list(map(dec,packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz')['Tminus']));degrees=sorted({p+2 for p,a0,b0,c0,d0,co in components});pairs=list(combinations(range(45),2));left={};right={}
for power in degrees:
 ll=[];rr=[]
 for c0,d0 in pairs:
  ll.append(enc((pref*s.I*sum((N.get((power,c0,d0,e),0)*Ts[e] for e in range(45)),s.zeros(16))).applyfunc(s.expand)))
  rr.append(enc((pref*s.I*sum((N.get((power,c0,d0,e),0)*(-Ts[e].T) for e in range(45)),s.zeros(16))).applyfunc(s.expand)))
 left[str(power)]=ll;right[str(power)]=rr
finish('replay',{'method':'exact_eta_even_Gaussian_Euler_quartic_reconstruction_and_scalar_Lie_contraction','raw_quartic':[[*key,str(co)] for key,co in sorted(H.items())],'coupling_components':[[p,a0,b0,c0,d0,str(co)] for p,a0,b0,c0,d0,co in components],
 'raw_Gca':enc(CG),'C3_plane_chart':enc(Q),'left':left,'right':right,'external_pairs':[list(v) for v in pairs],'plane_quartic_components':[[*key,str(v)] for key,v in sorted(Hp.items())],'Lie_contraction':[[*key,str(v)] for key,v in sorted(N.items())],
 'cumulant_unit':str(gauss),'polarized_action_E_unit':str(unitE),'Euclidean_quartic_Wick_phase':'-1','source_fermion_insertion_phase':str(phase),'hatted_integral_finite':str(radial),'wrong_h_sign_integral_finite':str(wrong_radial),'complete_family_prefactor':str(pref),'simplex_volume':str(area),
 'coupling_orders':degrees,'source_qS_or_qK_changed':False,'open_line_half_or_family_three':False,'new_one_loop_insertion_families':1,'new_two_loop_integrals':0,'physical_scheme_adopted':False},start)
