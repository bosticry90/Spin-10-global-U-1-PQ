"""QSI1 literal quartic density, Nambu action phase and direct ghost sewing."""
from data import *
from collections import defaultdict
from functools import lru_cache
from itertools import permutations,combinations
start=begin('primary');g=s.Symbol('g10')
def zero(M):assert not s.SparseMatrix(M).applyfunc(s.expand).todok()
# Every action vertex is even after adding the odd insertion parameter eta.
words=[[6,4],[0,8,5,3],[7,9,1,2]];signs=[]
for perm in permutations(range(3)):
 w=sum((words[j] for j in perm),[]);signs.append((-1)**sum(w[i]>w[j] for i in range(10) for j in range(i+1,10)))
gauss=s.Rational(sum(signs),6)
# Actual C/chi source relation and alternating Nambu cross polarization.
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
gam4=[s.kronecker_product(pa[1],v) for v in pa]+[s.kronecker_product(pa[0],s.eye(2))]
gam8=[s.kronecker_product(v,pa[2]) for v in gam4]+[s.kronecker_product(s.eye(4),v) for v in pa[:2]]
gam=[s.kronecker_product(v,s.eye(2)) for v in gam8];C=s.kronecker_product(gam8[0]*gam8[2]*gam8[5],pa[1]);chi=s.kronecker_product(s.prod(gam4),s.eye(4));PL=(s.eye(16)+chi)/2;PR=s.eye(16)-PL
zero(C.T+C);zero(C.inv()*chi*C-chi.T)
for v in gam:zero(C.inv()*v*C+v.T)
T=s.Matrix(2,2,s.symbols('a0:4'));CC=s.kronecker_product(C,s.eye(2));HH=s.kronecker_product(gam[4],s.eye(2));AA=s.kronecker_product(PL,T)-s.kronecker_product(PR,T.T);At=s.kronecker_product(PR,T)-s.kronecker_product(PL,T.T)
zero(AA.T*CC+CC*At);zero(HH*AA-AA*HH)
rawSP=-g*CC*HH*AA/2;rawPS=-g*CC*At*HH/2;polarized=rawSP-rawPS.T;target=CC*HH*AA
den=s.trace(target.H*target);unitE=s.simplify(s.trace(target.H*polarized)/den);zero(polarized-unitE*target)
wrongAC=s.I*s.prod(gam);wrongC=(C.inv()*wrongAC*C-wrongAC.T).applyfunc(s.expand);assert s.SparseMatrix(wrongC).todok()
# Momentum constraints at source,E,quartic: source ghost=-k,E ghost=+k.
k,l1,l2=s.symbols('k l1 l2');route=s.solve([k+l1,-k+l2,-l1-l2],[l1,l2]);assert route[l1]==-k and route[l2]==k
quarticWick=-s.S.One;sourcePhase=s.I;fermionPhase=-s.I
phase=s.simplify(sourcePhase*(unitE/g)*fermionPhase*quarticWick)
eps,h,mir=s.symbols('epsilon h m_IR',positive=True);regular=h*s.gamma(1+eps)*mir**(-2*eps)/4
radial=s.simplify(s.diff(regular.subs(h,-2*eps),eps).subs(eps,0));wrong_radial=s.simplify(s.diff(regular.subs(h,2*eps),eps).subs(eps,0));pref=s.simplify(gauss*phase*radial)
def canonical(word):
 keys=[]
 for name in word:
  assert '__' not in name
  if name.startswith('C'):keys.append((1,int(name[1:])))
  elif name.startswith('bar'):keys.append((0,int(name[3:])))
  else:assert name.startswith('ub');keys.append((0,int(name[2:])))
 assert len(set(keys))==4 and sorted(t for t,j in keys)==[0,0,1,1]
 sign=(-1)**sum(keys[i]>keys[j] for i in range(4) for j in range(i+1,4));ordered=sorted(keys)
 return tuple(j for t,j in ordered),sign
H=defaultdict(lambda:s.S.Zero);selected=[]
for ordinal,row in enumerate(packed(ROOT/'tools/portable_dh_v1/inputs.json.gz')['gauge_fixing_density']):
 if len(row['word'])!=4 or any('__' in n for n in row['word']):continue
 if sum(n.startswith(('bar','ub')) for n in row['word'])!=2 or sum(n.startswith('C') for n in row['word'])!=2:continue
 key,sign=canonical(row['word']);H[key]+=sign*s.sympify(row['coefficient'],locals={'xi':WM,'eta_H':WH});selected.append(ordinal)
H={k:s.expand(v) for k,v in H.items() if s.expand(v)!=0};components=[]
for key,co in sorted(H.items()):
 for mon,v in s.Poly(co,g).terms():
  if v!=0:components.append((int(mon[0]),*key,s.expand(v)))
phys=read(PK/'frozen_a10_physical_reconciliation/full_primary.json');Q=dec(phys['C3_plane_to_parent']);Qi=Q.inv();M=packed(HERE/'qualified_reference_inputs.json.gz')['reference_fields'];CG=dec(M['raw_ghost_Green']);Y=packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz');Ts=list(map(dec,Y['Tminus']))
TR=[sum((Q[d,c]*Ts[d] for d in range(45) if Q[d,c]),s.zeros(16)) for c in range(45)]
TG=[sum((CG[c,a]*TR[c] for c in range(45) if CG[c,a]),s.zeros(16)) for a in range(45)]
@lru_cache(None)
def products(a,b):
 ab=TG[a]*TG[b];ba=TG[b]*TG[a];return (ab-ba,ab,TG[a].T*TG[b].T-TG[b].T*TG[a].T)
rawL=defaultdict(lambda:s.zeros(16));rawR=defaultdict(lambda:s.zeros(16));one=defaultdict(lambda:s.zeros(16))
for power,a,b,c,d,co in components:
 comm,single,right=products(a,b);rawL[power,c,d]+=pref*co*comm;rawR[power,c,d]+=pref*co*right;one[power,c,d]+=pref*co*single
qrows={i:[(j,v) for (ii,j),v in s.SparseMatrix(Qi).todok().items() if ii==i] for i in range(45)}
def transport(inp):
 out=defaultdict(lambda:s.zeros(16))
 for (power,c,d),mat in inp.items():
  for u,x in qrows[c]:
   for v,y in qrows[d]:
    if u==v:continue
    out[power+2,min(u,v),max(u,v)]+=(1 if u<v else -1)*x*y*mat
 return out
left=transport(rawL);right=transport(rawR);onepair=transport(one);
wrongchart=defaultdict(lambda:s.zeros(16))
for power,a,b,c,d,co in components:wrongchart[power+2,c,d]+=pref*co*(Ts[a]*Ts[b]-Ts[b]*Ts[a])
degrees=sorted({p+2 for p,a,b,c,d,co in components});pairs=list(combinations(range(45),2))
def serialize(tab):return {str(power):[enc(tab.get((power,c,d),s.zeros(16)).applyfunc(s.expand)) for c,d in pairs] for power in degrees}
finish('primary',{'method':'literal_quartic_word_permutations_Nambu_C_polarization_and_ordered_raw_Green_sewing','raw_quartic':[[*key,str(co)] for key,co in sorted(H.items())],'coupling_components':[[p,a,b,c,d,str(co)] for p,a,b,c,d,co in components],
 'raw_quartic_ordinals':selected,'raw_Gca':enc(CG),'C3_plane_chart':enc(Q),'left':serialize(left),'right':serialize(right),'one_ghost_pairing_left':serialize(onepair),'wrong_untransported_chart_left':serialize(wrongchart),'external_pairs':[list(v) for v in pairs],
 'cumulant_permutation_signs':signs,'cumulant_unit':str(gauss),'polarized_action_E_unit':str(unitE/g),'Euclidean_quartic_Wick_phase':str(quarticWick),'source_fermion_insertion_phase':str(phase),
 'hatted_integral_finite':str(radial),'wrong_h_sign_integral_finite':str(wrong_radial),'complete_family_prefactor':str(pref),'wrong_comparison_chi_in_actual_C_relation_nonzero_positions':len(s.SparseMatrix(wrongC).todok()),
 'coupling_orders':degrees,'source_qS_or_qK_changed':False,'open_line_half_or_family_three':False,'new_one_loop_insertion_families':1,'new_two_loop_integrals':0,'physical_scheme_adopted':False},start)
