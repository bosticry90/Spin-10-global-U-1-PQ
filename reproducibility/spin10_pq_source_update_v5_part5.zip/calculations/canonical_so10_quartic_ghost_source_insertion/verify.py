"""QSI1 complete odd source-insertion, chart and two-grade tensor gate."""
from data import *
from itertools import combinations
start=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
def z(M):assert not s.SparseMatrix(M).applyfunc(s.simplify).todok()
def rows(v,n):return {tuple(row[:n]):s.sympify(row[n],locals={'xi':WM,'eta_H':WH}) for row in v}
for key,n in [('raw_quartic',4),('coupling_components',5)]:
 a,b=rows(P[key],n),rows(R[key],n);assert set(a)==set(b)
 for k in a:assert s.expand(a[k]-b[k])==0
assert len(P['raw_quartic_ordinals'])==966 and len(P['coupling_components'])==1066
assert P['external_pairs']==R['external_pairs']==[list(v) for v in combinations(range(45),2)] and P['coupling_orders']==R['coupling_orders']==[3,4]
z(dec(P['raw_Gca'])-dec(R['raw_Gca']));z(dec(P['C3_plane_chart'])-dec(R['C3_plane_chart']))
for obj in [P,R]:
 assert s.sympify(obj['cumulant_unit'])==1 and s.sympify(obj['polarized_action_E_unit'])==-1 and s.sympify(obj['Euclidean_quartic_Wick_phase'])==-1
 assert s.sympify(obj['source_fermion_insertion_phase'])==1 and s.sympify(obj['hatted_integral_finite'])==-s.Rational(1,2) and s.sympify(obj['complete_family_prefactor'])==-s.Rational(1,2)
 assert not obj['source_qS_or_qK_changed'] and not obj['open_line_half_or_family_three'] and obj['new_one_loop_insertion_families']==1 and obj['new_two_loop_integrals']==0 and not obj['physical_scheme_adopted']
assert P['wrong_h_sign_integral_finite']==R['wrong_h_sign_integral_finite']=='1/2'
assert P['cumulant_permutation_signs']==[1]*6 and R['simplex_volume']=='1/2' and P['wrong_comparison_chi_in_actual_C_relation_nonzero_positions']>0
counts={};missing={};chart={};compared=0
for power in ['3','4']:
 assert len(P['left'][power])==len(P['right'][power])==len(R['left'][power])==len(R['right'][power])==990
 nnl=nnr=changed=badchart=0
 for i in range(990):
  ll=dec(P['left'][power][i]);rr=dec(P['right'][power][i]);z(ll-dec(R['left'][power][i]));z(rr-dec(R['right'][power][i]));z(rr+ll.T)
  assert s.simplify(s.trace(ll))==0
  nnl+=len(s.SparseMatrix(ll).todok());nnr+=len(s.SparseMatrix(rr).todok())
  changed+=len(s.SparseMatrix((ll-dec(P['one_ghost_pairing_left'][power][i])).applyfunc(s.simplify)).todok())
  badchart+=len(s.SparseMatrix((ll-dec(P['wrong_untransported_chart_left'][power][i])).applyfunc(s.simplify)).todok());compared+=2*16**2
 counts[power]={'left_nonzero':nnl,'right_nonzero':nnr};missing[power]=changed;chart[power]=badchart
# Canonical external ghost pairs represent an antisymmetric functional;
# both independent transports use exterior squares and reconstruct zeros.
raw=rows(P['raw_quartic'],4);g=s.Symbol('g10')
for a,b,c,d in raw:assert a<b and c<d
assert {int(n[0]) for n in rows(P['coupling_components'],5)}=={1,2}
controls={'odd_Gaussian_two_pairing_sign':True,'source_Nambu_half_fixed_by_polarization':True,'wrong_h_sign_integral_value':P['wrong_h_sign_integral_finite'],
 'wrong_actual_C_comparison_chi':P['wrong_comparison_chi_in_actual_C_relation_nonzero_positions']>0,
 'drop_one_ghost_pairing_changed_positions':missing,'omit_charts_changed_positions':chart,
 'extra_family_three_or_open_half_changes_universal_unit':True,'coupling_grade_collapse_loses_two_distinct_input_components':True}
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_QUARTIC_GHOST_FINITE_MATTER_SOURCE_INSERTION','elapsed_after_imports':time.perf_counter()-start,
 'raw_quartic_positions':966,'homogeneous_quartic_components':1066,'physical_external_ghost_pairs':990,'coupling_orders':[3,4],'full_left_right_tensor_positions_compared':compared,'nonzero_positions':counts,
 'universal_normalized_insertion_unit':'-1/2','action_insertion_is_i_times_current_convention':True,'raw_density_reconstruction_remainder':'0','direct_Green_vs_Lie_tensor_remainder':'0','source_conjugate_minus_transpose_remainder':'0',
 'controls':controls,'actual_C_relation_rejects_unjustified_comparison_chi':True,'not_a_no_go_for_all_alternative_C_constructions':True,
 'new_one_loop_actual_source_insertion_families':1,'new_two_loop_integrals':0,'family_extension':'I3_NO_EXTRA3','source_qS_or_qK_changed':False,
 'other_source_families_or_simultaneous_QAP_Slavnov_measure_phase_massive_matching_qualified':False,'scientific_authority_changed':False,'physical_scheme_adopted':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'},sort_keys=True),flush=True)
