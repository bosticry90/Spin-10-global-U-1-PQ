# QSI1 result: nonzero quartic-ghost contribution to the actual source insertion

Qualified complete single-quartic-ghost source-insertion family within the
frozen one-loop bare local Euclidean domain. Receipt SHA256
2e8d4600a9f30e73ca720edd70677b16b0fa92d53bc95882c9a6370039ec9ee4.
State113/authority34of39 unchanged; scientific acceptance NOT_PERFORMED.
The complete investigation remains active and incomplete.

The family is nonzero at both g10^3 and g10^4. Each chirality has7424
nonzero internal/source coefficient positions at g^3 and1560 at g^4.
They come from all966 actual quartic-ghost density positions, including
1066 separate homogeneous components. They are not independent experiments,
particles or anomalies. No other missing family is assigned a cancellation.

Let H_ab;cd^[r] be the actual coefficient of a_a a_b C_c C_d after
canonical ordering a<b,c<d and stripping g^r. Define raw-to-plane Q,
Traw_s=sum_j Q_js T_j and TG_a=sum_s Gca_sa Traw_s. In common1/(16pi^2),
the measured left operator at order g^(r+2) is the exterior-square Q^-1
transport of

 -(1/2) sum_(a<b) H_ab;cd^[r] [TG_a,TG_b],  r=1,2.

The right operator is minus the full transpose. Its family extension is
identity only, without another3. Tables retain all990 canonical external
ghost pairs and every16x16 entry, including zeros at both grades/chiralities:
1013760 coefficient positions compared. Canonical pairs absorb no hidden
second factorial. Both Wick contractions are necessary to obtain the
commutator; discarding one changes7384/1560 left positions at g^3/g^4.
Omitting coordinate transport changes10488/3560 positions.

The action normalization is derived, not copied from a Ward target.
The actual action insertion is i*g times the free current-Ward defect.
SMA1's C/charge transpose identities and literal Fourier momenta show
that the two raw Nambu half-bilinears combine into an insertion coefficient
-g Gamma_hat A. The source vertex+i g and mixed propagator-i hatSlash,
together with the all-ghost Euclidean Wick minus, fix the pre-integral
phase. An odd bookkeeping eta makes eta E even; the exact three-vertex
cumulant has unit1. No closed-loop/Pfaffian half or witness trace divisor
is inserted on this open line.

The remaining hatted integral is independently calculated as-1/2 in16pi^2
units. Primary uses the Gaussian rank h and radial Gamma function; replay
uses a three-denominator Schwinger simplex. Both continue h=-2epsilon only
after the polynomial contractions; reversing that sign gives+1/2. Their
complete normalized family unit is consequently-1/2. The UV-convergent
remainder vanishes only under the specified nonexceptional Euclidean
assumptions; no constant-vacuum,infrared or massive equivalence is asserted.

Primary canonicalizes all literal quartic words with their Grassmann
permutation signs, contracts the actual raw ghost Green and ordered
spinor generators, then transports both external ghosts. Replay reconstructs
the quartic density from frozen E1 Euler/source shifts and actual master
maps, evaluates -log of an exterior Gaussian with an arbitrary2x2 ghost
kinetic matrix, transforms the density through independent dual charts,
and contracts qualified scalar Lie constants. Raw density reconstruction,
direct Green versus Lie tensors and source-conjugate transpose remainders
are exactly0. Only the old Green and Lie fields are exposed to workers;
prior source UV loop targets are excluded by an authenticated extraction
and read guard. Previously qualified group/action premises are shared.

An additional control rejects substituting the full-AC comparison chi into
the actual fixed charge-conjugation relation. This is a failure of that
unjustified substitution, not a no-go theorem for every alternative C or a
withdrawal of earlier restricted kernel comparisons. A complete physical
reference/source construction still needs its own statistics/domain proof.

Primary5.73903430000064s,replay15.889265999998315s,verifier69.04344619999756s
after imports, native0 throughout.4/9/35 resource samples with private
maxima79335424/91451392/75198464 bytes, not continuous peaks. Frozen600s/
8GiBsampled/350MiBfloor/16MiB respected.49initial58validationbindings,
8source copies plus a restricted reference extraction. No frozen worker or
verifier failure. Readiness is authenticated IBS1 fresh E4 from this same
logical turn, not a second execution or old scientific replay. Historical
custody remains exit2/seven NOTPASS. Earlier IBS1 mixed-grade failure stays
preserved. Shared action, Green/Lie data, conventions, software and AI author
remain limitations; no independent expert or experimental validation.

The next work must complete the remaining source classes. One promising
structural reduction is the paired fermion-edge insertion at physical
external ghost momentum: its sewn PP block carries an ordinary external
q, while KccP's local target has jet budget0. That reduction requires a
separate applicability proof before removing any classes. The remaining
two-ghost-vertex cycles require careful verification of the actual bosonic
Lorentz continuation at BOTH ghost endpoints; a barred fermion current
does not establish that a purely bosonic contraction stays barred.

This result gives a real, indispensable source-breaking input. It does not
establish its cancellation, a full renormalized composite-product/QAP/source
construction, nonlinear Slavnov restoration, measure/phase, finite massive
matter C1,E5/A5 or physical unification. Source qS0/qK0 and all physical
inputs remain; no scheme/baseline/foundation adopted, no rescue fit. Earlier
eta=.3 exclusions, eta=.0001 singlet140% warning, flavorpause/HB1C5blocks,
quartetFAIL and historical custody persist. Old evidence/state unchanged.
