# QSI1 fixed action, Gaussian order and chart conventions

SMA1 uses actual chi commuting with hats and C^T=-C,
C^-1 Gamma C=-Gamma^T, C^-1 chi C=chi^T. For arbitrary internal T,
A=PLT-PRT^T,At=PRT-PLT^T satisfy A^T C=-C At. With q=k-r,
the free Ward defect is E_mat=[[0,-iAt hat r],[i hat k A,0]].
Graded variation of the Nambu quadratic and the physical gauge variation
give qS_hat=(ig/2)c Psi^T C E_mat Psi. Check against the literal first/
third SMA1 terms, including the sign from passing q through the first odd
fermion. The normalized action insertion differs by i from the earlier
linear-current convention; do not confuse their numerical coefficients.

Place K at x1,E at x2 and the quartic at x3. Matter S_PS(k) is ordered
from x1 to x2. Ghost source momentum l1 flows x1->x3 and E ghost momentum
l2 flows x2->x3. At the UV Taylor point, l1=-k,l2=+k. Thus the E ghost
derivative has+i k while the internal S derivative has-i k. With external
physical P_hat=0, the two raw Nambu bilinears have coefficients proportional
to -g C Gamma_hat A/2 and -g C At Gamma_hat/2. Their alternating transpose
relation doubles the cross term; derive the normalized coefficient before
contracting S_PS=-i hatSlash/k^2 and source+i g. The C inverse cancels
between the Nambu propagator and insertion vertex. No closed-loop half.

Canonical odd ordering is eta,C_external_c,C_external_d,P_external,
P_internal,barS_internal,C_source,a_alpha,C_E,a_beta. Source vertex word
is(C_source,P_internal); eta insertion word is(eta,C_E,barS,P_external);
quartic word is(a_alpha,a_beta,C_external_c,C_external_d). All three action
vertices are even. Their -log cumulant and both ghost contractions must
be calculated with this order. The ghost covariance determinant, not a
commuting-field product, supplies the second pairing's minus. K is even.

Let H_ab;cd denote the actual Minkowski density coefficient after
canonicalizing a_a a_b C_c C_d with a<b,c<d. No factorial is implicit.
The Euclidean all-ghost vertex has the global action Wick minus (there is
no vector or auxiliary field Wick factor). Compare independently with the
existing convention for the free ghost covariance. Keep grades separately.

Q maps raw ghost components to plane components; C_raw=Q^-1 C_plane.
Raw current generators Traw_s=sum_r Q_rs T_r and ghost covariance Gca
give TG_a=sum_s Gca_sa Traw_s. The two Wick contractions produce ordered
products TG_a TG_b and TG_b TG_a, before their relative sign is tested.
Transport both external ghosts by the exterior square of Q^-1. Replay uses
Adual=(Q_H,F_M), Gca=Q^-1 Adual^-T, so TG_a=sum_r Adual^-1_ar T_r;
it first transports H by Adual^-1 on each antighost and Q^-1 on each ghost.
Then use the independently qualified [T_a,T_b]=i f_ab^c T_c.

The local loop numerator is hat k^2 and denominator degree6. Primary uses
integral hat k^2/(k^2+m_IR^2)^3=(h/4)Gamma(eps)m_IR^(-2eps), h=-2eps.
Replay uses the three-denominator Schwinger simplex and its hatted Gaussian
moment. The UV-convergent subtracted remainder vanishes with h only on
the specified nonexceptional Euclidean domain. Do not claim an IR/constant-
vacuum or massive-field equivalence from this calculation.

The result is one complete bare source-insertion family. Other ordinary/
auxiliary ghost cycles and fermion-line insertions remain. Its individual
value need not vanish and cannot establish or refute the simultaneous
Slavnov identity without those contributions and their renormalized products.
