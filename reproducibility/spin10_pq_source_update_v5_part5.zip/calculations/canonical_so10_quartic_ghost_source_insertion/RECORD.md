# QSI1: actual quartic-ghost finite matter-source insertion

Question: what does the newly required quartic-ghost KccP family contribute
to the actual one-loop matter breaking insertion? IBS1 qualified its complete
candidate support at both g^3 and g^4; it is absent from an ordinary KcP pole
inventory. Base9306f524b90a85ac93e86c3f625fdeb2983b36d6/main31300trackedblobs.
Whole goal active/incomplete, previous increment PROGRESS, no live workers.

Claim under test: derive the actual odd-insertion cumulant/Nambu sign, the
hatted finite integral and all canonical physical ghost-pair/source tensors
for this complete single-quartic family, including both coupling grades and
zero complements. A zero or nonzero answer is acceptable; no desired
Slavnov cancellation is used to determine it. This does not complete the
other31/32 source support classes, QAP, finite source restoration, quantum
measure/phase, E5/A5 or physical viability. Do not call a partial remainder
an anomaly. It is a bare formal Euclidean local insertion within this scope.

Freeze current AGENTS/CHARTER/state113/V518/local/solo conventions; actual
all33092 GF rows and966 raw quartic positions; IBS1 receipt/grade inventory;
SMA1 action/source/qS0 and its C-Clifford identities; SMP1 mixed free inverse;
qualified MAS1 raw ghost Green and independent scalar-Lie constants; YCT1
actual45 generators, physical C3 plane chart, E1 frozen Euler columns and
master maps for independent quartic reconstruction. Authenticate old byte
bindings without replacing their historical policy or hashes. Keep g,xi and
all widths formal. No family/Yukawa spectrum or physical parameter selected.

Domain: one E=qS_hat, one KcP source, one actual aaCC vertex, loop with one
mixed PS edge and two ghost edges; physical external hats0, nonexceptional
off-shell Euclidean momenta, mass-independent dimension5 local source
target. The two physical external ghosts anticommute; report canonical
pairs c<d, not a symmetric tensor or a hidden second factorial. Coupling
orders include two source/E powers plus each measured quartic g-grade.
Source K is even, qK=0; physical fermion P and ghosts are odd. E is odd,
so introduce an external odd bookkeeping eta and differentiate its even
action eta E. This defines the insertion, not a new physical source sector.

Normalize from the actual action. The current-Ward free defect is E_mat;
the action insertion is i*g*E_mat, not g*E_mat. Derive that relation using
graded variation/kinetic charge conjugation and literal SMA1 qS_hat. For
external P with hat momentum0, first/third raw bilinears polarize the
alternating Nambu action; check the half explicitly, never insert a new
open-line half or witness trace divisor. Use actual hat-commuting chi,
not the full-AC comparison chi. Source vertex is+i g K C A P. Ghost
quartic Euclidean coefficient follows the same action/contour Wick rule,
not a sign chosen from an expected restoration coefficient.

Primary: canonicalize every raw quartic word with its Grassmann sign and
split both g-grades exactly. Derive the three-vertex odd-insertion cumulant
by all even-vertex permutations, literal momentum constraints and actual
C-Clifford Nambu polarization. Integrate hat k^2 by the d-dimensional
Gaussian/radial Gamma formula. Contract both ghost Wick pairings using the
actual raw ghost Green and ordered matter generators; transport both
external ghosts by Q^-1 as an exterior square, preserving all990 pairs.
Replay: reconstruct the quartic density from the frozen E1 Euler/source
shift and actual master field maps; calculate -log of an exact exterior
Gaussian with eta and arbitrary two-ghost kinetic matrix. Reconstruct the
dual antighost chart independently, transport the four-ghost density first,
then reduce ordered spinor commutators through qualified scalar Lie data.
Use a Schwinger simplex derivation of the finite hatted moment.

Acceptance: both raw quartic polynomials and their grades agree; cumulant,
Nambu,phase,radial and coordinate conventions match; compare both chiral
tensors at both coupling orders for every external ghost pair and16x16
internal entry, including zeros. Family extension is identity only, never
extra3. Check external ghost antisymmetry and conjugate/source transpose
from actual A=PLT-PRT^T. Controls test one missing ghost pairing, a wrong
chart, h-sign, open half/family3 and coupling-grade collapse; record actual
sensitivity if a completed projection vanishes. No finite coefficient fit.

Freeze eight sources/copies, compile before launch, sequential peer-denied
primary/replay/verifier,600s after imports each,8GiB sampled cap,350MiB
launch floor,16MiB package. Reuse authenticated IBS1 fresh E4 from this
logical goal turn, not another execution or old scientific replay. Stop
at first failure/resource limit, preserve all source/capture bytes and version
any continuation. No agents,branch/worktree,push,publication or old evidence
edits. Authority34/39 unchanged; flavorpause/HB1C5blocks/quartetFAIL,
physical exclusions/140%singlet warning,custodyexit2/seven NOTPASS persist.

Comparator: arXiv2004.14398v2 Sec6.2.2 motivates source/breaking insertions
but does not specify this nonlinear GF quartic family. Shared action, Green
matrix, algebra, physical assumptions, software and AI author remain common
error risks. Result/receipt report the bounded finding and the next unmeasured
source/auxiliary family, not a complete quantum-restoration theorem.
