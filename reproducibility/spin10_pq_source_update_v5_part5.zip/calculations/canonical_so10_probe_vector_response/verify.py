from pathlib import Path
from hashlib import sha256
import gzip,json,time,threading,os
O=Path(__file__).resolve().parent;tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[json.loads(gzip.decompress((O/(r+'_tables.json.gz')).read_bytes())) for r in ['primary','replay']]
assert a['outputs']==b['outputs'] and a['controls']==b['controls'];counts={};witnesses=[];positions=0
for z in a['outputs']:
 for channel in ['longitudinal_total','transverse_total']:
  for p,M in z[channel].items():
   n=len(M['entries']);counts[channel+':'+p]=counts.get(channel+':'+p,0)+n;positions+=M['shape'][0]*M['shape'][1]
   if n and len(witnesses)<12:witnesses.append({'B':z['B_external'],'channel':channel,'power':p,'first':M['entries'][0]})
assert sum(a['controls'].values())>0
out={'schema':'PVR1_VALIDATION_RECEIPT','elapsed_after_imports':time.perf_counter()-tick,'all_declared_higher_vector_response_coefficients_compared':True,'complete_implicit_total_positions_compared':positions,'nonzero_by_channel_and_power':counts,'nonzero_total_positions':sum(counts.values()),'pointwise_higher_probe_affinity':sum(counts.values())==0,'witnesses':witnesses,'controls':a['controls'],'new_integrated_fermionic_quantum_coefficient_measured':False,'full_higher_probe_module_or_QAP_qualified':False,'scientific_authority_changed':False,'primary_packed_sha256':H(O/'primary_tables.json.gz'),'replay_packed_sha256':H(O/'replay_tables.json.gz')}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
