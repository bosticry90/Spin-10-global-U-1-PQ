from pathlib import Path
from hashlib import sha256
import ast,json
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());b=dict(read(O/'validation_preparation.json')['input_sha256'])
for p,h in b.items():assert H(Path(p))==h,p
assert read(O/'validation_receipt.json')['all_declared_higher_vector_response_coefficients_compared']
for n in ['primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json','loop_preparation_capture.json','loop_controller_failure.json','LOOP_RECORD.md','loop.py','prepare_loop.py','run_loop.py','verify_loop.py']:b[str(O/n)]=H(O/n)
for n in ['LOOP_RECORD_V2.md','prepare_loop_v2.py','loop_v2.py','verify_loop_v2.py','run_loop_v2.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
with(O/'loop_preparation_v2.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'seconds_after_imports':300,'private_byte_cap_sampled':8*1024**3,'whole_packet_cap':32*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_LVR1 '+str(len(b)),flush=True)
