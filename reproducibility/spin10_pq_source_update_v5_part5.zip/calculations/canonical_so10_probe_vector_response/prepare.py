from pathlib import Path
from hashlib import sha256
import ast,gzip,json,subprocess
O=Path(__file__).resolve().parent;R=O.parents[1]
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());b={}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='29bdad60bf3a9a15094db27a9b6f977f0564c4ce'
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V599.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:
 p=R/n;b[str(p)]=H(p)
pu=O.parent/'canonical_so10_probe_ghost_vector_vertices';hp=O.parent/'canonical_so10_first_probe_local_module'
manifest=pu/'loop_preparation_v3.json';m=read(manifest);b[str(manifest)]=H(manifest)
for role in ['primary','replay']:
 p=pu/('loop_'+role+'_inputs.json.gz');assert H(p)==m['native_input_sha256'][str(p)];b[str(p)]=H(p)
 dst=O/(role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(p.read_bytes())
 b[str(dst)]=H(dst)
for folder,ns in [(pu,['native_v2.py','validation_receipt_v2.json','loop_validation_receipt_v3.json','LOOP_RECORD.md']), (hp,['endpoint_validation_receipt.json','endpoint_validation_preparation.json','ENDPOINT_RECORD.md']), (O.parent/'canonical_so10_even_probe_vertices',['validation_receipt.json','primary_tables.json.gz','replay_tables.json.gz']), (O.parent/'canonical_so10_probe_auxiliary_resolvent',['compression_receipt.json','validation_receipt_v2.json'])]:
 for n in ns:
  p=folder/n;b[str(p)]=H(p)
assert read(hp/'endpoint_validation_receipt.json')['all_tested_principal_endings_affine_and_higher_intrinsic_scalar_coefficients_zero']
for n in ['RECORD.md','prepare.py','native.py','verify.py','run.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
with(O/'preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'seconds_after_imports':600,'private_byte_cap_sampled':8*1024**3,'packet_byte_cap':32*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_PVR1 '+str(len(b)),flush=True)
