# PVR/LVR tensor and sign review

Bounded dependent review, frozen before execution. Authenticate completed
PVR1 and LVR2 preparations/captures/receipts first. Check that the parallel
and transverse tests reconstruct dimension-independent delta_mu,r and
k_mu k_r/k^2 tensor coefficients with ordered color matrices; no trace of a
four-dimensional metric may replace an analytic D contraction. Independently
prove the complete left-inverse mixed-sign control: if R=G X and R_L's
higher coefficients vanish, flipping both mixed signs in the LEFT inverse
changes the higher response by diag(-2,+2) times the LB placement. Evaluate
the nonzero-position count and witnesses from all actual LB coefficients.
This supplies the control promised in RECORD.md, in a separate frozen audit
instead of modifying the completed workers.

Use noncommuting free symbols for the basis reconstruction and sign identity,
actual full arrays for zero/sensitivity, and the authenticated current/vertex
extraction for tensor completeness. Retain the distinction between a raw
operator zero, a local UV projection and finite coincident products. No new
scientific promotion. Sequential single verifier180s/8GiB-sampled/350MiB floor,
whole32MiB cap, full failure capture/source retention. A failed identity,
binding or parent disagreement blocks this qualification.
