from pathlib import Path
from hashlib import sha256
import gzip,json,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'review_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
for n in ['validation_preparation.json','loop_validation_preparation_v2.json']:
 for p,h in read(O/n)['input_sha256'].items():assert H(Path(p))==h,p
v=read(O/'validation_receipt.json');q=read(O/'loop_validation_receipt_v2.json');assert v['pointwise_higher_probe_affinity'] and v['nonzero_total_positions']==0;assert q['all_higher_even_probe_marginal_vector_local_coefficients_zero'] and q['nonzero_total_positions']==0
W,M,L,AA,BB,CC,LL,LT,D,E,S,X,Y=s.symbols('W M L A B C LL LT D E S X Y',commutative=False)
trans=S-s.I*CC*D-s.I*LT*E
radial=(W-1)*S-s.I*((AA+BB)+(W-1)*(AA+BB+CC))*D-s.I*(W-1)*LT*E-s.I*M*LL*D
parallel=W*S-s.I*W*(AA+BB+CC)*D-s.I*W*LT*E-s.I*M*LL*D
assert s.expand(trans+radial-parallel)==0
G=s.Matrix([[W,M],[-M,L]]);bad=s.Matrix([[W,-M],[M,L]]);xx=s.Matrix([X,Y]);R=G*xx;lb=G*s.Matrix([0,Y]);delta=(bad-G)*xx;expected=s.Matrix([-2*lb[0],-2*R[1]+2*lb[1]])
assert all(s.expand(z)==0 for z in delta-expected)
d=json.loads(gzip.decompress((O/'primary_tables.json.gz').read_bytes()));count=0;wit=[];monomials=set()
for z in d['outputs']:
 for p,A in z['longitudinal_total'].items():assert not A['entries']
 for p,A in z['longitudinal_parts']['LB'].items():
  count+=len(A['entries']);monomials.add(p)
  for i,j,value in A['entries'][:1]:
   if len(wit)<8:wit.append({'B':z['B_external'],'power':p,'row':i,'column':j,'wrong_minus_right_coefficient':str(s.expand((-2 if i<45 else 2)*s.sympify(value,locals={x:s.Symbol(x,real=True) for x in ['g10','xi','eta_H']})))})
assert count==v['controls']['omit_long_LB'] and count>0
assert all(z['noncommuting_first_probe_limit_recovers_UCB_seagull_and_both_auxiliary_parts'] for z in [json.loads(gzip.decompress((O/('loop_'+r+'_v2_tables.json.gz')).read_bytes())) for r in ['primary','replay']])
out={'schema':'PVR_LVR_TENSOR_REVIEW','elapsed_after_imports':time.perf_counter()-tick,'noncommuting_tensor_reconstruction_no_D_trace':True,'constant_external_field_tensor_identity_not_a_finite_regulator_theorem':True,'wrong_left_mixed_inverse_sign_sensitive_positions':count,'wrong_left_mixed_sign_control_witnesses':wit,'complete_seven_even_probe_degree_monomials_checked':sorted(monomials),'actual_first_probe_UCB_sewing_orientation_recovered':True,'new_counterterm_or_finite_normalization':False,'full_QAP_or_authority_promoted':False}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
