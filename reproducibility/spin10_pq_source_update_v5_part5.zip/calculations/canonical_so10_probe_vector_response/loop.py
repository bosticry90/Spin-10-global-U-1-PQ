from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'loop_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and(p.name.startswith('loop_'+('replay' if role=='primary' else'primary')) or p.name==('replay' if role=='primary' else'primary')+'_tables.json.gz'):raise PermissionError('LVR_PEER_DENIED')
  if any(x in p.parts for x in ['canonical_so10_probe_fermion_onejet','canonical_so10_probe_scalar_support']):raise PermissionError('LVR_COUNTERTERM_DENIED')
sys.addaudithook(guard)
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.sympify(z,locals=loc)
dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v) for i,j,v in z['entries']});tidy=lambda M:s.SparseMatrix(M).applyfunc(s.expand)
def enc(M):return {'shape':list(M.shape),'entries':[[int(i),int(j),str(v)] for(i,j),v in sorted(tidy(M).todok().items()) if v]}
def expr(p):
 z=0
 for power,w,cid in p['monomials']:
  assert not w
  for xp,hp,mask,n,den in p['coefficients'][cid]:
   v=s.Rational(n,den)*g**power*xi**xp*eta**hp
   for j,a in enumerate([2,3,5,7]):
    if mask&(1<<j):v*=s.sqrt(a)
   if mask&16:v*=s.I
   z+=v
 return s.expand(z)
d=json.loads(gzip.decompress((O/(role+'_inputs.json.gz')).read_bytes()));v=json.loads(gzip.decompress((O/(role+'_tables.json.gz')).read_bytes()));fr=d['frame'];Ti=dec(fr['physical_to_raw_inverse']);Q=dec(fr['Q']);order=fr['field_order'];phys=[f'B{i}_{mu}' for i in range(45) for mu in range(4)]+[f'x_{ss}_{i}' for ss,nn in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(nn)]+[('b'+str(i) if i<12 else'L'+str(i)) for i in range(45)]+['C'+str(i) for i in range(45)]+[('bar'+str(i) if i<12 else'ub'+str(i)) for i in range(45)]
RB=tidy(Q*Ti.extract([order.index(f'B{i}_0') for i in range(45)],[phys.index(f'B{i}_0') for i in range(45)]));TP=list(map(dec,d['Tminus']));T=[tidy(sum((RB[k,a]*TP[k] for k in range(45) if RB[k,a]),s.zeros(16))) for a in range(45)]
fc=defaultdict(list)
for b,a,c,z in d['physical_f']:fc[b,a].append((c,expr(z)))
for b in range(45):
 for a in range(45):assert not tidy(T[b]*T[a]-T[a]*T[b]-s.I*sum((f*T[e] for e,f in fc[b,a]),s.zeros(16))).todok()
eps,h=s.symbols('epsilon h');finite=lambda z:s.simplify(s.diff(z.subs(h,-2*eps),eps).subs(eps,0));I0=finite(h*s.gamma(1+eps)/4) if role=='primary' else finite(h*s.gamma(1+eps)/(2*s.gamma(3)));J=finite(h*s.gamma(1+eps)/24) if role=='primary' else finite(h*s.gamma(1+eps)/(4*s.gamma(4)));assert I0==-s.Rational(1,2) and J==-s.Rational(1,12) and I0!=4*J
# Reconcile the low-order sewing convention with the qualified UCB1 parts.
# The free symbols are NONCOMMUTING; no color-order interchange is used.
u=s.symbols('u');W,Wp,Mp,L0,L1,D0,Du,V0,Eu,S0,S1=s.symbols('W Wp Mp L0 L1 D0 Du V0 Eu S0 S1',commutative=False);Z0=I0+J*(W-1);Zu=I0+J*(W+u*Wp-1);coef=lambda z:s.expand(z).coeff(u,1)
assert s.expand(coef(Zu*(S0+u*S1))-(J*Wp*S0+Z0*S1))==0
assert s.expand(coef(-s.I*Zu*(L0+u*L1)*(V0+u*Eu))+s.I*(J*Wp*L0*V0+Z0*L0*Eu+Z0*L1*V0))==0
assert s.expand(coef(-s.I*J*(1+u*Mp)*(L0+u*L1)*(D0+u*Du))+s.I*J*(Mp*L0*D0+L0*Du+L1*D0))==0
powers=['2,0','1,1','0,2','3,0','2,1','1,2','0,3'];parts=['current','BBB','BL','LB'];outputs=[]
for chir,tt in [('left',T),('right',[-t.T for t in T])]:
 @lru_cache(None)
 def comm(b,a):return tidy(tt[b]*tt[a]-tt[a]*tt[b]).todok()
 for z in v['outputs']:
  d0=z['B_external'];sheet={}
  for name in parts:
   for p in powers:
    L=dec(z['longitudinal_parts'][name][p])[:45,:] if p in z['longitudinal_parts'][name] else s.zeros(45,2025)
    A=dec(z['transverse_parts'].get(name,{}).get(p,{'shape':[45,2025],'entries':[]}));B=tidy(L-A)
    for moment,M in [('I',A),('J',B)]:
     sums=defaultdict(list)
     if role=='primary':
      for(b,ac),val in M.todok().items():
       a,c=divmod(ac,45)
       for ij,tval in comm(b,a).items():sums[c,*ij].append(g*g*val*tval)
     else:
      reduced=defaultdict(list)
      for(b,ac),val in M.todok().items():
       a,c=divmod(ac,45)
       for e,f in fc[b,a]:reduced[c,e].append(s.I*g*g*val*f)
      for(c,e),terms in reduced.items():
       val=s.expand(s.Add(*terms))
       for ij,tval in tt[e].todok().items():sums[c,*ij].append(val*tval)
     sheet[name,p,moment]=s.SparseMatrix(45,256,{(c,i*16+j):s.expand(s.Add(*terms)) for(c,i,j),terms in sums.items()})
  grouped={}
  for p in powers:
   group={'I':tidy(sum((sheet[name,p,'I'] for name in parts),s.zeros(45,256))),'J':tidy(sum((sheet[name,p,'J'] for name in parts),s.zeros(45,256)))};group['total']=tidy(I0*group['I']+J*group['J']);group['I0_to_4J_control']=tidy(4*J*group['I']+J*group['J']);group['parts']={name:enc(tidy(I0*sheet[name,p,'I']+J*sheet[name,p,'J'])) for name in parts};grouped[p]={key:({n:m for n,m in val.items()} if key=='parts' else enc(val)) for key,val in group.items()}
  outputs.append({'chirality':chir,'B_external':d0,'coefficients':grouped})
  if d0%15==0:print('STAGE '+role+' '+chir+' B'+str(d0),flush=True)
out={'schema':'LVR1_LOCAL_QUANTUM','role':role,'RB':enc(RB),'I0':str(I0),'J':str(J),'outputs':outputs,'all_actual_color_Lie_identities_checked':True,'noncommuting_first_probe_limit_recovers_UCB_seagull_and_both_auxiliary_parts':True,'full_D_inherited_UCB_sewing_not_4J':True,'new_finite_contact_product_or_physical_amplitude':False,'counterterm_read_or_fitted':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('loop_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True);timer.cancel()
