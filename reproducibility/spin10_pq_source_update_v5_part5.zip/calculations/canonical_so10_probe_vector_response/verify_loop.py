from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import gzip,json,time
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();read=lambda p:json.loads(p.read_bytes())
for p,h in read(O/'loop_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[json.loads(gzip.decompress((O/('loop_'+r+'_tables.json.gz')).read_bytes())) for r in ['primary','replay']];assert a['outputs']==b['outputs'] and a['RB']==b['RB'];counts=defaultdict(int);controls=defaultdict(int);positions=0;witness=[]
for row in a['outputs']:
 for power,tab in row['coefficients'].items():
  counts[row['chirality']+':'+power]+=len(tab['total']['entries']);positions+=45*256;controls['I0_to_4J']+=len(tab['I0_to_4J_control']['entries'])
  for n,M in tab['parts'].items():controls['omit_'+n]+=len(M['entries'])
  if tab['total']['entries'] and len(witness)<8:witness.append({'chirality':row['chirality'],'B':row['B_external'],'power':power,'first':tab['total']['entries'][0]})
out={'schema':'LVR1_VALIDATION_RECEIPT','elapsed_after_imports':time.perf_counter()-tick,'ordered_matrix_vs_Lie_reduction_all_coefficients_and_zeros_agree':True,'full_total_coefficient_positions_compared':positions,'nonzero_positions_by_chirality_and_power':dict(counts),'nonzero_total_positions':sum(counts.values()),'all_higher_even_probe_marginal_vector_local_coefficients_zero':sum(counts.values())==0,'controls':dict(controls),'witnesses':witness,'reference':'INHERITED_UCB1_BARE_LOCAL_EVANESCENT_UV_NOT_FINITE_PRODUCT','new_counterterm_fitted':False,'rho_or_jet_or_full_higher_probe_module_qualified':False,'QAP_measure_phase_or_authority_promoted':False,'primary_packed_sha256':H(O/'loop_primary_tables.json.gz'),'replay_packed_sha256':H(O/'loop_replay_tables.json.gz')}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
