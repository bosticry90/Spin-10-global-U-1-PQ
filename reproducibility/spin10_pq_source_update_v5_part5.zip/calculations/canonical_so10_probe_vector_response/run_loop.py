from pathlib import Path
O=Path(__file__).resolve().parent
# Distinct frozen controller; the PVR1 controller logic is reused with explicit
# dependent filenames/caps. No historical source or manifest is modified.
src=(O/'run.py').read_text(encoding='utf-8')
src=src.replace("stage='preparation'","stage='loop_preparation'").replace("O/'prepare.py'","O/'prepare_loop.py'").replace("O/'preparation_capture.json'","O/'loop_preparation_capture.json'").replace("C/'preparation_full_capture.json'","C/'loop_preparation_full_capture.json'")
src=src.replace("O/'preparation.json'","O/'loop_preparation.json'").replace("O/'validation_preparation.json'","O/'loop_validation_preparation.json'").replace("'verify.py' if role=='verify' else'native.py'","'verify_loop.py' if role=='verify' else'loop.py'")
src=src.replace("O/(role+'_capture.json')","O/('loop_'+role+'_capture.json')").replace("C/(role+'_full_capture.json')","C/('loop_'+role+'_full_capture.json')").replace("O/(role+'_tables.json.gz')","O/('loop_'+role+'_tables.json.gz')").replace("'validation_receipt.json' if role=='verify' else role+'_result.json'","'loop_validation_receipt.json' if role=='verify' else 'loop_'+role+'_result.json'").replace("<600","<300").replace("O/'controller_failure.json'","O/'loop_controller_failure.json'").replace('COMPLETED_PVR1','COMPLETED_LVR1')
exec(compile(src,str(O/'run_loop.py')+'[frozen-controller-adapter]','exec'))
