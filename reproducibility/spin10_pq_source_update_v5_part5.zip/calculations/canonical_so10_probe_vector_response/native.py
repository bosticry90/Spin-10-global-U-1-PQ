from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith(('replay' if role=='primary' else'primary')):raise PermissionError('PVR_PEER_DENIED')
  if any(x in p.parts for x in ['canonical_so10_probe_fermion_onejet','canonical_so10_probe_scalar_support']):raise PermissionError('PVR_COUNTERTERM_DENIED')
sys.addaudithook(guard)
g,xi,eta=s.symbols('g10 xi eta_H',real=True)
@lru_cache(None)
def expr(packed):
 p=json.loads(packed);out=0
 for power,w,cid in p['monomials']:
  assert not w
  for xp,hp,mask,n,den in p['coefficients'][cid]:
   z=s.Rational(n,den)*g**power*xi**xp*eta**hp
   for k,q in enumerate([2,3,5,7]):
    if mask&(1<<k):z*=s.sqrt(q)
   if mask&16:z*=s.I
   out+=z
 return s.expand(out)
tab=lambda rows:{tuple(row[:-1]):expr(json.dumps(row[-1],sort_keys=True)) for row in rows}
tidy=lambda M:s.SparseMatrix(M).applyfunc(s.expand)
def mm(A,B):
 if role=='primary':return tidy(A*B)
 rows=defaultdict(list);out=defaultdict(list)
 for(k,j),v in B.todok().items():rows[k].append((j,v))
 for(i,k),v in A.todok().items():
  for j,z in rows[k]:out[i,j].append(v*z)
 return tidy(s.SparseMatrix(A.rows,B.cols,{k:s.Add(*v) for k,v in out.items()}))
def enc(M):return {'shape':list(M.shape),'entries':[[int(i),int(j),str(v)] for(i,j),v in sorted(tidy(M).todok().items()) if v]}
zero=lambda M:not tidy(M).todok()
d=json.loads(gzip.decompress((O/(role+'_inputs.json.gz')).read_bytes()));vv=d['vertices'];curr=[{k:tab(v) for k,v in z['current'].items()} for z in vv];aux=[tab(z['auxiliary']) for z in vv];sg=[tab(z['aCBB']) for z in vv];abc=[{k:tab(v) for k,v in z['BBB'].items()} for z in vv]
assert not curr[1]['AC'] and not curr[2]['AC'];assert curr[0]['AC']
P=[s.diag(*[int((i<12)==(r==0)) for i in range(45)]) for r in range(2)];W=s.diag(*([eta]*12+[xi]*33));weights=[eta,xi];powers=[(0,0),(1,0),(0,1)]
def addp(a,b):return (a[0]+b[0],a[1]+b[1])
def add(A,B):
 out=dict(A)
 for p,M in B.items():out[p]=tidy(out.get(p,s.zeros(*M.shape))+M)
 return out
def mul(A,B):
 out={}
 for p,L in A.items():
  for q,M in B.items():
   t=addp(p,q);N=mm(L,M);out[t]=tidy(out.get(t,s.zeros(*N.shape))+N)
 return out
def neg(A):return {p:-M for p,M in A.items()}
def restrict(A):return {str(p[0])+','+str(p[1]):enc(M) for p,M in sorted(A.items()) if sum(p)>=2}
def stacked(A,B):return A.col_join(B)
Z=s.zeros(45);I=s.eye(45)
GG={(0,0):s.SparseMatrix.vstack(s.SparseMatrix.hstack(W,I),s.SparseMatrix.hstack(-I,Z))}
WP={(0,0):W};MP={(0,0):s.SparseMatrix(I)};LL={(0,0):s.SparseMatrix(Z)}
for r,w in enumerate(weights):
 p=powers[r+1];wp=w*w*P[r]/2;mp=w*P[r];ll=-2*P[r];WP[p]=wp;MP[p]=mp;LL[p]=ll
 GG[p]=s.SparseMatrix.vstack(s.SparseMatrix.hstack(wp,mp),s.SparseMatrix.hstack(-mp,ll))
sheet=lambda z:s.SparseMatrix(45,2025,{(b,a*45+c):v for(b,a,c),v in z.items()})
V=list(map(lambda z:sheet(z['V']),curr));HH=list(map(lambda z:sheet(z['H']),curr));JJ={p:stacked(-s.I*V[r],s.I*HH[r]) for r,p in enumerate(powers)}
if role=='primary':EE=mul(GG,JJ)
else:
 EE={(0,0):stacked(s.I*(HH[0]-mm(W,V[0])),s.I*V[0])}
 for r,w in enumerate(weights):
  p=powers[r+1];eb=s.I*(mm(w*P[r],HH[0])+HH[r+1]-mm(w*w*P[r]/2,V[0])-mm(W,V[r+1]));el=s.I*(mm(w*P[r],V[0])+V[r+1]-2*mm(P[r],HH[0]));EE[p]=stacked(tidy(eb),tidy(el))
 for r in range(2):
  for t in range(2):assert zero(mm(GG[powers[r+1]],JJ[powers[t+1]]))
assert all(zero(M) for p,M in EE.items() if sum(p)>=2)
EE={p:M for p,M in EE.items() if sum(p)<=1};EB={p:M[:45,:] for p,M in EE.items()};EL={p:M[45:,:] for p,M in EE.items()}
def for_d(tab0,d0,kind):
 if kind=='S':return s.SparseMatrix(45,2025,{(b,a*45+c):v for(a,c,b,d1),v in tab0.items() if d1==d0})
 return s.SparseMatrix(45,45,{(i,j):v for(i,j,d1),v in tab0.items() if d1==d0})
outputs=[];controls=defaultdict(int)
for d0 in range(45):
 SS={p:for_d(sg[r],d0,'S') for r,p in enumerate(powers)};AA={p:for_d(aux[r],d0,'L') for r,p in enumerate(powers)};AT={p:M.T for p,M in AA.items()};CC={p:for_d(abc[r]['C'],d0,'B') for r,p in enumerate(powers)};BB={p:sum((for_d(abc[r][k],d0,'B') for k in ['A','B','C']),s.zeros(45)) for r,p in enumerate(powers)}
 if role=='primary':
  KBBB={p:s.SparseMatrix.vstack(s.SparseMatrix.hstack(M,Z),s.SparseMatrix.hstack(Z,Z)) for p,M in BB.items()}
  KBL={p:s.SparseMatrix.vstack(s.SparseMatrix.hstack(Z,M.T),s.SparseMatrix.hstack(Z,Z)) for p,M in AA.items()}
  KLB={p:s.SparseMatrix.vstack(s.SparseMatrix.hstack(Z,Z),s.SparseMatrix.hstack(M,Z)) for p,M in AA.items()}
  parts={'current':mul(GG,{p:stacked(M,s.zeros(45,2025)) for p,M in SS.items()}),'BBB':neg(mul(GG,mul(KBBB,EE))),'BL':neg(mul(GG,mul(KBL,EE))),'LB':neg(mul(GG,mul(KLB,EE)))}
  longtot={}
  for a in parts.values():longtot=add(longtot,a)
  transverse={'current':SS,'BBB':neg(mul(CC,EB)),'BL':neg(mul(AT,EL))}
 else:
  X=mul(BB,EB);Y=mul(AT,EL);T=mul(AA,EB)
  parts={'current':{p:stacked(M,neg(mul(MP,SS)).get(p,s.zeros(45,2025))) for p,M in mul(WP,SS).items()}}
  for name,A in [('BBB',X),('BL',Y)]:
   upper=neg(mul(WP,A));lower=mul(MP,A);parts[name]={p:stacked(upper.get(p,s.zeros(45,2025)),lower.get(p,s.zeros(45,2025))) for p in set(upper)|set(lower)}
  upper=neg(mul(MP,T));lower=neg(mul(LL,T));parts['LB']={p:stacked(upper.get(p,s.zeros(45,2025)),lower.get(p,s.zeros(45,2025))) for p in set(upper)|set(lower)}
  longtot={}
  for a in parts.values():longtot=add(longtot,a)
  transverse={'current':SS,'BBB':neg(mul(CC,EB)),'BL':neg(mul(AT,EL))}
 trtot={}
 for a in transverse.values():trtot=add(trtot,a)
 for name,A in parts.items():
  for p,M in A.items():
   if sum(p)>=2:controls['omit_long_'+name]+=len(tidy(M).todok())
 for name,A in transverse.items():
  for p,M in A.items():
   if sum(p)>=2:controls['omit_transverse_'+name]+=len(tidy(M).todok())
 outputs.append({'B_external':d0,'longitudinal_parts':{k:restrict(v) for k,v in parts.items()},'longitudinal_total':restrict(longtot),'transverse_parts':{k:restrict(v) for k,v in transverse.items()},'transverse_total':restrict(trtot)})
 if d0%10==0:print('STAGE '+role+' vector '+str(d0),flush=True)
# Exact dimension-independent tensor identities: k K_YM k=0; K_YM k nonzero.
k2,kmu,knu,kr=s.symbols('k2 kmu knu kr');double=s.expand(2*k2*kr-k2*kr-k2*kr);single=kr*kmu-k2*s.Symbol('delta_mr');assert double==0 and single!=0
# Generic geometric derivative tests both inverse placements, without matrix commutation.
t=s.symbols('t');K=s.Matrix([[2,t],[t,3]]);assert zero((K.inv().diff(t)+K.inv()*K.diff(t)*K.inv()).applyfunc(s.cancel))
out={'schema':'PVR_HIGHER_PROBE_VECTOR_RESPONSE_V1','role':role,'powers_retained':[[2,0],[1,1],[0,2],[3,0],[2,1],[1,2],[0,3]],'endpoint_affine_checked':True,'actual_new_ghost_AC_zero':True,'old_ghost_AC_nonzero_retained_below_degree2':True,'physical_YM_double_longitudinal_zero':str(double),'physical_YM_single_longitudinal_not_zero':str(single),'all45_external_C_B_and_internal_antighost_color':True,'Lorentz_channels':['external_parallel_output_Bparallel_Lambda','external_transverse_output_Btransverse'],'outputs':outputs,'controls':dict(controls),'quantum_loop_or_counterterm_read':False,'full_QAP_or_authority_changed':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True);timer.cancel()
