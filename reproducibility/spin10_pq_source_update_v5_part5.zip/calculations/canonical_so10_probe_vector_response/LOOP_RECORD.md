# LVR1: higher-probe vector local quantum projection

Frozen before its computation. This is a dependent follow-up to PVR1: require
completed agreeing parent tables first, then bind their exact hashes. Question:
what are the degree2/3 even-probe coefficients in the marginal local
u^n C B barP P bare one-loop chiral insertion, at constant external u,C,B?
Keep both probes, all45x45 C/B directions, both chiralities, exact g/xi/eta
polynomials and implicit zeros. No counterterm or desired answer is input.

Use PVR1 to differentiate the full open boson ending. The actual probe ghost
AC kernel is0, so the nonzero old ghost inverse response multiplies an affine
ending and has degree<=1. The separate physical fermion B-leg response also
multiplies that affine ending. Actual u probes do not alter the matter Hessian,
the hatted insertion or the ghost quadratic kernel. Thus their degree>=2
coefficients vanish algebraically, without declaring the underlying diagrams0.
Reuse the UCB1 saturated one-loop role/port budget and raw PS/SP physical-PP
pairing proof (including its nonzero mixed-block control), not a nilpotence
assumption. The remaining higher coefficients are precisely the PVR1 boson
response sewn into the same paired fermionic reference as qualified UCB1.

For each ordered pair(b,a), write the ordinary vector response as
A_ba delta_mu,r+B_ba k_mu k_r/k^2. Its transverse channel is A, and
its longitudinal B-output channel is A+B. The auxiliary output is retained
by PVR1 but has no direct physical-PP vector vertex; all internal auxiliary
placements are already included in A,B. No four-dimensional trace replaces
the analytic dimensional momentum contraction. In common1/(16pi^2) units,
the qualified UCB1 sewing is g10^2 sum_ba [I0 A_ba+J B_ba][Tb,Ta],
I0=-1/2,J=-1/12. This relation is linear and independent of probe degree.
It is the UCB1 seagull/BBB/auxiliary formula, with all polynomial placements
summed. It is not an assumption that I0=4J; their difference is nonzero.

Primary: ordered16x16 generator commutators with the complete response
polynomial. Replay: independently contract i f_bae T_e before matrix
assembly. Reconstruct actual T_a by RB COLUMNS from both authenticated
frames, check the commutator against supplied f, and use U_a=-T_a^T for
the right representation. Re-derive I0,J using the two inherited gamma/
Schwinger expressions. Compare full left/right matrices and zero complements
for seven degree2/3 monomials, source/BBB/BL/LB parts, total and I/J tensors.
Record omission and I0->4J controls whether sensitive or insensitive.

No unknown correction is solved or fitted; keep any nonzero quantum remainder.
A zero qualifies only this constant-external marginal bare-local projection,
conditional on the reused UCB1 reference/graph premises. It is not a finite
multiple-insertion product, full transfer-momentum theorem, rho response,
source-module completion, renormalized chiral identity or E5/A5. A nonzero
result is not an anomaly verdict. It identifies a required remaining term.

Sources/inputs frozen before execution. Sequential primary/replay/verifier
each300s after imports,8GiB sampled private,350MiB launch floor, whole packet
32MiB. Preserve failures/incomplete captures, no silent cap widening. Input
hash mismatch, incorrect color frame/Lie algebra or route disagreement fails
qualification. Authority/state, live policy boundaries and shared-error limits
are those of RECORD.md; no authority promotion or physical scheme change.
