# PVR1: higher-probe one-vector principal response

Frozen before calculation, 2026-10-24. Base29bdad60, main preserved.
Question: does the previously qualified zero-background endpoint affinity
persist after differentiating once in an ordinary vector B, at zero external
momenta? This is a principal, marginal, bare local operator test, not a new
fermionic loop, finite massive amplitude or renormalized product construction.

Use original unshifted SMA, generic real xi/eta_H and polynomial g10, both
even probes with independent commuting coefficients u0/u1. All45 external
ghosts,45 external vectors,45 internal antighost/color directions. No choice
of physical coupling, width, vacuum, finite baseline or favorable benchmark.
Full transverse/longitudinal vector and auxiliary response retained. Independent
external momenta are NOT claimed: this is the constant-external-field marginal
u^n B C endpoint coefficient; derivative carriers require their own test.

Reuse authenticated action-derived PUV1 old GF and two QG vertex sets, separate
V/AC/H, repeated-B seagulls, auxiliary LambdaBB and all three BBB Lorentz
coefficients. Reuse qualified EPV/PAR/HP1 principal inverse/jet statements.
At unit internal momentum along direction0 use the opposite-momentum inverse
Gminus=[[W,M],[-M,-2U]], where W=W0+sum u w^2 P/2,
M=I+sum u w P and U=sum u P. Each transverse inverse is I.
J=[-i V,+i H]^T, so E=Gminus J has E_B=i(H-WV),
E_L=iV at zero probe and the measured full first-probe responses. Verify
the complete degree2 endpoint coefficients before using their affinity.

The differentiated ending is Gghost*(Gminus J_B-Gminus K_B E)
minus the ghost inverse response, with color order inherited from the action.
For the higher degree>=2 coefficients the latter is exactly zero because
the actual two probe AC currents vanish and E is affine. This does NOT
discard the nonzero old ghost kernel at degree0/1; no new low-degree amplitude
is claimed. The physical YM BBB tensor is proportional to
2 delta_mn k_r-delta_nr k_m-delta_mr k_n. Its contraction with two
longitudinal momenta is zero. Its transverse response is affine because
E is affine and the transverse left inverse has no probe dependence.
Thus physical YM also contributes no degree>=2 response; demonstrate this
full Lorentz identity without assuming its individual one-vector response0.

Primary: polynomial convolution of sparse90x90 block matrices with45x2025
current sheets; direct seagull and each cubic block placement separated.
Replay: independent coefficient/index contractions in the reduced Lorentz
channels, with different multiplication association. Compare every retained
coefficient and implicit zero. Preserve all actual higher-degree remainders;
zero is a HYPOTHESIS, not a success condition. Negative controls omit seagull,
auxiliary vertices or one cubic inverse block, and flip the opposite-momentum
mixed-inverse sign. Do not fit a counterterm to an observed remainder.

First-failure gates: input/source hash mismatch, inconsistent endpoint affinity,
invalid Lorentz support or disagreement between routes. Resource exhaustion
is INCOMPLETE. Sequential workers/verifier each600s after imports,8GiB sampled
private bytes,350MiB launch floor, packet32MiB. No automatic widening. Freeze
source copies and inputs before computation. Retain failed sources/captures.

Authority ceiling: bounded principal operator qualification or refuted affinity
only. Full higher-probe local fermionic module, integrated chiral quantum
coefficient, finite/contact QAP, hatted/global measure/phase, physical massive
limits and E5/A5 remain open. State113/34of39 unchanged; custody2/sevenNOTPASS.
No agents, branch/worktree, push, outreach/publication, foundation/benchmark/
scheme change, flavor/HB1C5 activation or authority promotion. Shared action,
operator premises, software and AI author limit independence.
