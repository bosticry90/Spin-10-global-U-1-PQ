# LVR2 compatibility continuation

The scientific question, domain, derivation, expected evidence and exclusions
in LOOP_RECORD.md remain unchanged. Same sequential300s/8GiB-sampled/350MiB
floor/whole32MiB caps. No scientific condition has been weakened.

V1 preparation failed AST parsing before any quantum worker launch: Python3.10
does not accept an unpacked tuple directly inside a subscript. loop.py and its
failed_source copy preserve both occurrences, complete preparation capture
and loop_controller_failure.json preserve the failed prelaunch. No validation
receipt exists for V1. The two already copied V1 sources and all five complete
failed_source copies remain unchanged. This is a language-compatibility error,
not a measured quantum disagreement or a failed physical hypothesis.

New loop_v2.py changes the two subscript keys to an explicit c,i,j tuple.
Its controller/preparer/verifier use distinct V2 output/preparation/capture
paths; the original sources, contracts and failed receipts are not overwritten.
The previously completed PVR1 primary/replay/verifier remain valid. Ordinary
delegated harness correction justifies this bounded continuation; it does not
retroactively label the old attempt authorized success or PASS.
