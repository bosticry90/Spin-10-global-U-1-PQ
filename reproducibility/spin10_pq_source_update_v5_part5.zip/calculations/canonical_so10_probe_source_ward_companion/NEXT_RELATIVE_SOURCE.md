# Next indispensable comparison: the source companion of the relative Ward term

PCW1 measures a nonzero heat response, not the missing relative variation.
Keep Crel=Gamma_D,FP-Gamma_H,FP and the existing Mlight/Mheavy probes.
At u0, the actual source-companion comparison is

 R_Ja = Pi_Ja [Qp + C01-C10 + X_G0 I1-X_G1 I0].

Here p is the already measured rho0*rho1 contact, C_rs is the ACTUAL local
u_r*rho_s conversion coefficient, and I_s is the actual first-probe
conversion. The operation includes full source Eulers and the independently
labelled EVEN rho_r*G_r Hamiltonian flow, in the existing orientation.
Do not assign R_Ja from the negative of PCW1, and do not identify a naive
dimensional comparison with the entire T_kappa prescription.

Reuse MPA's authenticated classical H_G/H_QG/V symbols and already measured
first-probe Lambda/Ja companions. First check from the complete actual G
flows which other first-probe carriers could feed Ja*(JL,a). Reuse those
old companions only after that support exclusion is proved; do not put
physical fields or sources to zero before differentiation. New input is
the Ja projection of both mixed u*rho conversion coefficients, including
all ordered n2/n3/n4 groups and any permitted residue jets.

The same dimension5 rho^2*Ja*chi target has no external jet or positive-
dimension mass/vacuum coefficient. This excludes such local terms, not
their nonlocal amplitudes. Keep symbolic Lorentz numerators, all derivative
placements and the finite D-dimensional residue derivative. A fresh fifth-
transverse-component check must determine that derivative, even if it is
ultimately zero. An axes-only four-dimensional comparison cannot prove it.

After independent construction and validation, compare R_Ja+B_H,source
over every4050 carrier slot, with its separate coupling/log/rational
components and sensitive source/companion omissions. A remaining nonzero
value is classified before proposing any finite normalization. Neither
zero nor nonzero by itself decides the other Ward carriers, full connected
U, complete T_kappa normalization, chiral measure/phase or E5/A5.

This is the next bounded target, not a completed calculation or an expanded
resource authorization for an old frozen run. Freeze its own sources,
types, independent inputs, proof dependencies and proportionate limits
before launching it under the standing delegation.
