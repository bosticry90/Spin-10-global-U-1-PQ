# Exact tensor comparison after the independent heat calculations

Both PCW1 natives and its expanded-Fraction verifier completed. Compare the
entire measured source-companion tensor with the separately qualified PHR1
tensor under JL_i*Lambda_j -> a_i*Ja_j, including canonical Grassmann order.
Do not choose a sign or rescale a coefficient to achieve a match. Test exact
equality as well as the full zero complement; preserve a mismatch if present.
This is a stdlib serialization/tensor check, not another loop derivation.
Inputs are both sets of completed arrays and their actual validation receipts.
Freeze all hashes and sources before execution. Limit60seconds after imports,
8GiB sampled private,350MiB launch floor; existing16MiB PCW1 packet bound.
No scientific authority, parameter, normalization or physical scheme changes.
