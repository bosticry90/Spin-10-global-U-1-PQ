# PCW1: source companion of the qualified probe-pair heat Ward response

Prospective follow-on, base6f48364d/main, current AGENTS. PHR1's V2
validation has completed: two actual ordered constructions agree over the
4050 Lambda*(JL,a) slots. Its finite heat response offsets the independently
measured relative Ward term; no full QAP/restoration claim follows.

Question: what is the complete same-grade SOURCE companion with Ja replacing
Lambda? Ja has dimension2, parity0 and ghostnumber0, just like Lambda.
Thus rho0*rho1*Ja*(JL,a) is a second complete4050-slot carrier, needed before
using an auxiliary/source restriction to assess a broader quantum identity.
Possible outcomes are a nonzero measured response, a complete projected zero,
or a mismatch/incomplete calculation. None is a global anomaly verdict.

Reuse the authenticated FULL PHR1 tangent and full action/source/probe deltaV
symbols, before its target filter. Reuse the same actual classical Hessian
symbols; exclude all old heat/finite/relative-Ward target arrays from worker
inputs. This avoids repeating qualified raw-frame and tangent calculations.
No source is set to zero before variation. Both primary closed index paths
and replay rooted products calculate the whole formal heat polynomial.
A third expanded-Fraction signature convolution checks both constructions,
all4050 carrier slots and their zero complement. The PHR1 reviewed analytic
domain, finite-cutoff identity and degree envelope apply unchanged because
the replaced external anchor has identical dimension/parity/ghost grade.
This is ONE Slavnov tangent, not two independent symmetry insertions.

Freeze scripts, provenance and input hashes before computation. Each native
and verifier600s after imports,8GiB sampled private,350MiB launch floor,
whole PCW1 packet16MiB. No cap expansion; preserve failures and full captures.
Primary/replay derivative symbols are independently derived but share the
action, classical Hessians, analytic assumptions, software and AI author.
The third check reuses those qualified derivative symbols, not a third raw
action/frame derivation. No external scientific validation is asserted.

Other physical/source/derivative Ward carriers, full nonlocal connected U,
T_kappa completion, chiral/SMA/measure/phase/physical limits, E5/A5 and massive
fermion threshold remain separate. State113/34of39/custodyexit2/sevenNOTPASS
unchanged. No scheme/benchmark/foundation/promotion/blocked stage activation,
branch/worktree/push/publication/outreach. Validate before local commit and
identify the next indispensable dependency rather than accumulating slots.
