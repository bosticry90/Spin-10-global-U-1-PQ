"""Independent heat insertion and direct Born-variation calculations."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from collections import defaultdict
import json,gzip,sys,time,threading,os
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra,ONE,put,scale,scale_coefficient
read=lambda p:json.loads(p.read_bytes());dig=lambda p:sha256(p.read_bytes()).hexdigest()
def add(*pp):
 out={}
 for p in pp:
  for k,c in p.items():put(out,k,c)
 return out
def main():
 tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
 role=sys.argv[1];assert role in ['primary','replay'];prep=read(O/'preparation.json')
 for p,h in prep['native_input_sha256'].items():assert dig(Path(p))==h,p
 inp=json.loads(gzip.decompress((O/(role+'_classical_inputs.json.gz')).read_bytes()));data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry']
 A=Algebra(inp['names']+['hr_epsilon'],inp['parities']+[1]);eps=A.index['hr_epsilon'];fields={i for i,J,h,k in geo['field_source_h_k']};Jof={i:J for i,J,h,k in geo['field_source_h_k']};Hof={i:h for i,J,h,k in geo['field_source_h_k']}
 u=[A.index['mw_u'+str(i)] for i in range(2)];rho=[A.index['mw_rho'+str(i)] for i in range(2)];bg=[A.index['mw_a'+str(i)] for i in range(45)];bl=[A.index['mw_L'+str(i)] for i in range(45)];qs=[A.index['mw_q'+str(i)] for i in range(4)]
 bn=[[A.index[f'B{i}_{mu}'] for mu in range(4)] for i in range(45)];an=[A.index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];ln=[A.index[('b' if i<12 else 'L')+str(i)] for i in range(45)];cn=[A.index[f'C{i}'] for i in range(45)]
 jl=[Jof[n] for n in ln];ja=[Jof[n] for n in an];jc=[Jof[n] for n in cn];chi=set(jl+bg);anchors=set(bl+ja);core={n for b in bn for n in b}|set(an+ln+cn);bset={n for b in bn for n in b};dims={n:2 if n in ln else 1 for n in fields};ew={**dict.fromkeys(chi,1),**dict.fromkeys(anchors,2),**dict.fromkeys(rho,1)}
 bgmap={**dict(zip(an,bg)),**dict(zip(ln,bl))};par=A.parities
 def elem(n,j=()):
  if isinstance(n,str):n=A.index[n]
  return {(0,((n,j),)):ONE}
 @lru_cache(None)
 def scalar(z):return A.rows([{'word':[],'coefficient':str(z)}])
 def mul(*pp):
  p={(0,()):ONE}
  for q in pp:p=A.product(p,q)
  return p
 def unpack(p):
  cc=[tuple(((x,h,m),F(n,d)) for x,h,m,n,d in c) for c in p['coefficients']]
  return {(g,tuple((n,tuple(j)) for n,j in w)):cc[k] for g,w,k in p['monomials']}
 def pack(p):
  cc=[];ix={};mm=[]
  for(g,w),c in sorted(p.items()):
   if c not in ix:ix[c]=len(cc);cc.append([[*k,v.numerator,v.denominator] for k,v in c])
   mm.append([g,[[n,list(j)] for n,j in w],ix[c]])
  return {'coefficients':cc,'monomials':mm,'positions':len(p),'sha256':A.fingerprint(p)}
 def D(p,mu):
  out={}
  for(g,w),c in p.items():
   for at,(n,j) in enumerate(w):
    ww,sg=A.canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
    if sg:put(out,(g,ww),scale_coefficient(c,sg))
  return out
 def DD(p,j):
  for mu in j:p=D(p,mu)
  return p
 def sub(p,v):
  out={}
  for(g,w),c in p.items():
   z={(g,()):c}
   for n,j in w:z=mul(z,DD(v.get(n,elem(n)),j))
   for k,c0 in z.items():put(out,k,c0)
  return out
 def grad(p):
  out={}
  for(g,w),c in p.items():
   total=sum(par[n] for n,j in w);prefix=0
   for at,(n,j) in enumerate(w):
    sg=(-1)**(par[n]*prefix) if role=='primary' else (-1)**(par[n]*(total-prefix-par[n])+par[n]*(total-par[n]))
    put(out.setdefault((n,j),{}),(g,w[:at]+w[at+1:]),scale_coefficient(c,sg));prefix+=par[n]
  return {k:p for k,p in out.items() if p}
 def EL(p,domain):
  out={n:{} for n in domain}
  for(n,j),p0 in grad(p).items():
   if n in domain:out[n]=add(out[n],scale(DD(p0,j),(-1)**len(j)))
  return out
 def oddop(p,v):
  out={}
  for(n,j),df in grad(p).items():
   if n in v:
    for k,c in mul(DD(v[n],j),df).items():put(out,k,c)
  return out
 phase={n:scalar('I' if n in {b[0] for b in bn} else '-I' if n in ln else '1') for n in fields}
 for n,J in Jof.items():phase[J]=mul(scalar('-1'),scalar('-I') if n in {b[0] for b in bn} else scalar('I') if n in ln else scalar('1'))
 def wick(p,density=True):
  out={}
  for(g,w),c in p.items():
   z={(g,w):c}
   if density:z=scale(z,-1)
   for n,j in w:z=mul(z,phase.get(n,scalar('1')),scalar(['1','I','-1','-I'][j.count(0)%4]))
   for k,c0 in z.items():put(out,k,c0)
  return out
 G=[wick(unpack(p)) for p in inp['physical_G']]
 assert all(not j for p in G for g,w in p for n,j in w if n in set(jl+ja))
 flows=[]
 for p in G:
  el=EL(p,set(jl+ja+ln+an+cn));v={}
  for a,l,aa,jj in zip(an,ln,ja,jl):v[a]=el[aa];v[l]=scale(el[jj],-1);v[aa]=scale(el[a],-1);v[jj]=el[l]
  for c,J in zip(cn,jc):v[J]=scale(el[c],-1)
  flows.append(v)
 allowed=chi|anchors|set(jc)|set(rho+u)
 def bgproject(p):
  z=sub(p,{n:elem(v) for n,v in bgmap.items()});return {k:c for k,c in z.items() if all(n in allowed and not j for n,j in k[1])}
 def fm(pkt):return {(i,j):unpack(p) for i,j,p in pkt}
 HS=[fm(p) for p in inp['H_symbols']];US=[fm(p) for p in inp['U_symbols']];VS=fm(inp['V_symbols'])
 source=unpack(inp['euclidean_source']);sp=unpack(inp['ghost_source_lorentz']);sp={k:c for k,c in sp.items() if any(n in jc for n,j in k[1])};SJC=wick(sp);source=add(source,SJC)
 # Actual ghost-source Hessian and Euler columns are retained before source0.
 VJC={}
 for(n,I),p0 in grad(SJC).items():
  if n in cn:
   for(m,J),c in grad(p0).items():
    if m in cn:assert not I and not J;VJC[n,m]=add(VJC.get((n,m),{}),c)
 VFULL=dict(VS)
 for k,p in VJC.items():VFULL[k]=add(VFULL.get(k,{}),p)
 N=fm(inp['root_symbols']);qfields={}
 vec=[F(1),F(0),F(0),F(0)] if role=='primary' else [F(0),F(0),F(0),F(1)]
 def ev(p):return sub(p,{n:scalar(str(z)) for n,z in zip(qs,vec)})
 def signature(w,root):
  if any(j or n not in chi|set(ja+rho+qs)|({eps} if root else set()) for n,j in w):return None
  if sum(n==eps for n,j in w)!=int(root):return None
  d=(sum(n==rho[0] for n,j in w),sum(n==rho[1] for n,j in w),sum(n in ja for n,j in w),sum(n in chi for n,j in w))
  return d if all(v<=1 for v in d) else None
 def split(M,root=False):
  out={}
  for(i,j),p in M.items():
   for k,c in ev(p).items():
    sg=signature(k[1],root)
    if sg is not None:put(out.setdefault(sg,{}).setdefault((i,j),{}),k,c)
  return out
 G0={}
 for i in range(45):
  w=scalar('eta_H' if i<12 else 'xi')
  for mu in range(4):
   for nu in range(4):
    z=add(scalar(str(int(mu==nu))),scale(add(w,scalar('-1')),vec[mu]*vec[nu]))
    if z:G0[bn[i][mu],bn[i][nu]]=z
   if vec[mu]:G0[bn[i][mu],ln[i]]=scalar(str(-vec[mu]));G0[ln[i],bn[i][mu]]=scalar(str(vec[mu]))
  G0[cn[i],an[i]]=scalar('1');G0[an[i],cn[i]]=scalar('-1')
 def mm(L,B):
  rows=defaultdict(list);out={}
  for(k,j),p in B.items():rows[k].append((j,p))
  for(i,k),p in L.items():
   for j,q in rows[k]:
    z=mul(p,q)
    if z:out[i,j]=add(out.get((i,j),{}),z)
  return {k:p for k,p in out.items() if p}
 M=dict(VS)
 for H in HS:
  for k,p in H.items():M[k]=add(M.get(k,{}),p)
 blocks={sg:mm(G0,b) for sg,b in split(M).items()};assert all(any(sg) for sg in blocks)
 roots=split(N,True)
 if role=='replay':roots={sg:mm(G0,b) for sg,b in roots.items()}
 def paths(ms):
  if any(not m for m in ms):return {},{}
  ix=[]
  for m in ms[1:]:
   rows=defaultdict(list)
   for(i,j),p in m.items():rows[i].append((j,p))
   ix.append(rows)
  out={};ordinary={}
  def walk(root,at,d,p):
   if d==len(ix):
    if at==root:
     for k,c in p.items():put(ordinary,k,c);put(out,k,scale_coefficient(c,(-1)**par[root]))
    return
   for j,q in ix[d].get(at,[]):
    if d==len(ix)-1 and j!=root:continue
    z=mul(p,q)
    if z:walk(root,j,d+1,z)
  for(i,j),p in ms[0].items():walk(i,j,0,p)
  return out,ordinary
 def traceproduct(ms):
  if role=='primary':return paths(ms)
  p=ms[0]
  for b in ms[1:]:p=mm(p,b)
  return add(*(scale(p0,(-1)**par[i]) for(i,j),p0 in p.items() if i==j)),add(*(p0 for(i,j),p0 in p.items() if i==j))
 target=(1,1,1,1)
 def sequences(rem,k):
  if not k:
   if not any(rem):yield []
   return
  for sg,b in blocks.items():
   rr=tuple(a-v for a,v in zip(rem,sg))
   if min(rr)>=0:
    for tail in sequences(rr,k-1):yield [b]+tail
 heat={str(n):{} for n in range(1,6)};raw={};ordinary_heat={str(n):{} for n in range(1,6)};walkcounts={}
 for sg,root in roots.items():
  rem=tuple(a-v for a,v in zip(target,sg));assert min(rem)>=0
  assert role=='primary' or any(sg)
  for k in range(0,5 if role=='primary' else 4):
   total={};ord0={};cnt=0
   for seq in sequences(rem,k):
    p,o=traceproduct(seq+[root]);total=add(total,p);ord0=add(ord0,o);cnt+=1
   if not cnt:continue
   key=str(sg)+':'+str(k);raw[key]=total;walkcounts[key]=cnt
   if role=='primary':
    assert k>=1 or not total
    if k:
     heat[str(k)]=add(heat[str(k)],scale(total,(-1)**k));heat[str(k+1)]=add(heat[str(k+1)],scale(total,-(-1)**k));ordinary_heat[str(k)]=add(ordinary_heat[str(k)],scale(ord0,(-1)**k));ordinary_heat[str(k+1)]=add(ordinary_heat[str(k+1)],scale(ord0,-(-1)**k))
   else:
    heat[str(k+1)]=add(heat[str(k+1)],scale(total,F((-1)**k,2)));ordinary_heat[str(k+1)]=add(ordinary_heat[str(k+1)],scale(ord0,F((-1)**k,2)))
 def strip(p):
  for n in [eps,rho[0],rho[1]]:p=grad(p).get((n,()),{})
  return p
 heat={n:strip(p) for n,p in heat.items()};ordinary_heat={n:strip(p) for n,p in ordinary_heat.items()}
 print('STAGE '+role+' complete_ordered_heat_polynomial_before_any_target_comparison',flush=True)
 def pm(M):return [[i,j,pack(p)] for(i,j),p in sorted(M.items())]
 out={'schema':'PROBE_SOURCE_WARD_COMPANION_V1','role':role,'names':list(A.names),'parities':list(par),'qfields':{A.names[n]:pack(p) for n,p in qfields.items()},'G_E':[pack(p) for p in G],'source_E':pack(source),'tangent_or_delta_symbols':pm(N),'heat_polynomial':{n:pack(p) for n,p in heat.items()},'ordinary_trace_polynomial':{n:pack(p) for n,p in ordinary_heat.items()},'unweighted_sum':pack(add(*heat.values())),'root_sequence_counts':walkcounts,'root_raw':{k:pack(p) for k,p in raw.items()},'regulator_reference_variations':'ZERO_BY_FROZEN_EXTERNAL_A_FIXED_REFERENCE_DEPENDENCE_NOT_BY_DROPPING_INSERTIONS','target_slots':4050,'full_QAP_chiral_physical_restoration':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
 rawbytes=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(rawbytes,mtime=0)
 with (O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'heat_positions':{n:len(p) for n,p in heat.items()},'unweighted_sum_positions':len(add(*heat.values())),'ordinary_trace_differs':ordinary_heat!=heat,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(rawbytes).hexdigest(),'elapsed_after_imports':out['elapsed_after_imports']},sort_keys=True),flush=True);timer.cancel()
if __name__=='__main__':main()
