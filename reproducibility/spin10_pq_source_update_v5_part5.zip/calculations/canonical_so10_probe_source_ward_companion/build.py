from pathlib import Path
import ast
O=Path(__file__).resolve().parent;B=O.parent/'canonical_so10_probe_heat_ward_response'
p=(B/'response.py').read_text(encoding='utf-8');a=p.index(' N={};qfields={}');b=p.index(' vec=',a)
p=p[:a]+" N=fm(inp['root_symbols']);qfields={}\n"+p[b:]
assert p.count('chi|set(bl+rho+qs)')==1 and p.count('sum(n in bl for n,j in w)')==1
p=p.replace('chi|set(bl+rho+qs)','chi|set(ja+rho+qs)').replace('sum(n in bl for n,j in w)','sum(n in ja for n,j in w)').replace('PROBE_HEAT_WARD_RESPONSE_V1','PROBE_SOURCE_WARD_COMPANION_V1')
ast.parse(p)
with (O/'native.py').open('x',encoding='utf-8',newline='\n') as f:f.write(p)
q=(B/'verify_v2.py').read_text(encoding='utf-8');head=q[:q.index('inp=json.loads')]
head=head.replace("O/'validation_preparation_v2.json'","O/'validation_preparation.json'")
tail=q[q.index('# Third orientation'):q.index('# Quantum targets')]
tail=tail.replace('chi|set(bl+rho+qs)','chi|set(ja+rho+qs)').replace('sum(n in bl for n,j in w)','sum(n in ja for n,j in w)')
tail=tail.replace("len(w)==2 and sum(n in bl for n,j in w)==1","len(w)==2 and sum(n in ja for n,j in w)==1").replace('for l in bl:','for l in ja:')
# Companion uses authenticated derivative symbols. It does not re-run or
# selectively bypass the old derivative assertions in a validation program.
setup='''
inp=json.loads(gzip.decompress((O/'primary_classical_inputs.json.gz').read_bytes()));rinp=json.loads(gzip.decompress((O/'replay_classical_inputs.json.gz').read_bytes()))
u=[index['mw_u'+str(i)] for i in range(2)];rho=[index['mw_rho'+str(i)] for i in range(2)];eps=index['hr_epsilon'];bg=[index['mw_a'+str(i)] for i in range(45)];bl=[index['mw_L'+str(i)] for i in range(45)];qs=[index['mw_q'+str(i)] for i in range(4)]
bn=[[index[f'B{i}_{mu}'] for mu in range(4)] for i in range(45)];an=[index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];ln=[index[('b' if i<12 else 'L')+str(i)] for i in range(45)];cn=[index[f'C{i}'] for i in range(45)]
jl=[Jof[n] for n in ln];ja=[Jof[n] for n in an];jc=[Jof[n] for n in cn];chi=set(jl+bg)
def fm(p):return {(i,j):unpack(v) for i,j,v in p}
HS=[fm(p) for p in inp['H_symbols']];VS=fm(inp['V_symbols']);N=fm(inp['root_symbols']);delta=fm(rinp['root_symbols']);VJC={}
def even(p):return {}
'''
finish='''
finite={prime:{} for prime in [2,3,5]}
for n,p in heat.items():
 for prime,power in s.factorint(int(n)).items():finite[prime]=add(finite[prime],scaled(p,-int(power)))
result={'schema':'PROBE_SOURCE_WARD_COMPANION_VALIDATION_V1','elapsed_after_imports':time.perf_counter()-tick,'full_carrier_slots':4050,'heat_positions':{n:summary(p) for n,p in heat.items()},'finite_by_prime':{str(n):summary(p) for n,p in finite.items()},'complete_heat_polynomial_zero':not any(heat.values()),'ordinary_trace_differs':ordinary!=heat,'qualified_derivative_symbols_reused':True,'full_QAP_or_other_Ward_carriers_qualified':False,'authority_changed':False}
print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
'''
out=head+setup+tail+finish;ast.parse(out)
with (O/'verify.py').open('x',encoding='utf-8',newline='\n') as f:f.write(out)
print('GENERATED_PCW1_NATIVE_AND_CONVOLUTION_VERIFIER')
