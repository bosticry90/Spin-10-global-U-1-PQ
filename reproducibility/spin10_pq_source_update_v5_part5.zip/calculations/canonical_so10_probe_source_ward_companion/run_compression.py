from pathlib import Path
from hashlib import sha256
import json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=O.parent/'canonical_so10_probe_heat_ward_response';C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/probe-source-ward-companion-v1-2026-10-24')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
files=[O/n for n in ['COMPRESSION.md','compress.py','run_compression.py','validation_receipt.json']]+[B/'validation_receipt_v2.json']+[d/(r+'_tables.json.gz') for d in [O,B] for r in ['primary','replay']]
for n in ['COMPRESSION.md','compress.py','run_compression.py']:
 with (O/(n+'.source.txt')).open('xb') as f:f.write((O/n).read_bytes())
dump(O/'compression_preparation.json',{'input_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in files},'seconds':60,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2})
c=capture([sys.executable,'-B',str(O/'compress.py')]);dump(O/'compression_capture.json',c);dump(C/'compression_full_capture.json',c);print(c['stdout_and_stderr'],flush=True)
assert c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
rr=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<60;dump(O/'compression_receipt.json',rr[0])
