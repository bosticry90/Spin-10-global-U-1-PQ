from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,ast
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=O.parent/'canonical_so10_probe_heat_ward_response'
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert base=='6f48364dd612901080207ee9e78a1d1acc859deb'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R).strip()
v=json.loads((B/'validation_receipt_v2.json').read_bytes());assert v['complete_selected_heat_identity'] and v['full_carrier_slots']==4050
files=[R/'AGENTS.md',R/'project_state.json',R/'tools/portable_dh_v1/inputs.json.gz',R/'tools/portable_dh_v1/exact_algebra.py',R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py',B/'DERIVATION.md',B/'validation_receipt_v2.json',B/'validation_preparation_v2.json']
for p,h in json.loads((B/'validation_preparation_v2.json').read_bytes())['input_sha256'].items():assert H(Path(p))==h,p
for role in ['primary','replay']:
 m=B/(role+'_classical_inputs.json.gz');s=B/(role+'_tables.json.gz');files.extend([m,s]);z=json.loads(gzip.decompress(m.read_bytes()));root=json.loads(gzip.decompress(s.read_bytes()));z['root_symbols']=root['tangent_or_delta_symbols'];z['extraction']='CLASSICAL_HESSIANS_AND_QUALIFIED_DERIVATIVE_SYMBOL_ONLY_NO_HEAT_TARGET'
 dst=O/(role+'_classical_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 files.append(dst)
for n in ['RECORD.md','build.py','native.py','verify.py','prepare.py','run.py']:
 p=O/n;files.append(p)
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with (O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
files.extend(O.glob('*.source.txt'));bindings={str(p):H(p) for p in sorted(set(files))};native={str(p):bindings[str(p)] for p in [R/'AGENTS.md',R/'project_state.json',R/'tools/portable_dh_v1/inputs.json.gz',R/'tools/portable_dh_v1/exact_algebra.py',O/'native.py',O/'primary_classical_inputs.json.gz',O/'replay_classical_inputs.json.gz']}
dump(O/'preparation.json',{'base':base,'input_sha256':bindings,'native_input_sha256':native,'limits':{'seconds_after_imports':600,'sampled_private_bytes':8*1024**3,'launch_floor':350*1024**2,'packet':16*1024**2},'scientific_acceptance':'NOT_PERFORMED'})
print('PREPARED_PCW1',len(bindings))
