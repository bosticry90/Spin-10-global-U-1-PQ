from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from collections import defaultdict
import json,gzip,time,threading,os,sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
def guard(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('PHR_VERIFIER_WRITE')
os.sys.addaudithook(guard)
role='verifier'
P=json.loads(gzip.decompress((O/'primary_tables.json.gz').read_bytes()));Z=json.loads(gzip.decompress((O/'replay_tables.json.gz').read_bytes()))
assert P['names']==Z['names'] and P['parities']==Z['parities']
names=P['names'];par=P['parities'];index={n:i for i,n in enumerate(names)}
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry']
pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};sources={J for i,J,h,k in pairs};canon=fields|sources;Jof={i:J for i,J,h,k in pairs};Hof={i:h for i,J,h,k in pairs}
g,xi,eta=s.symbols('g10 xi eta_H');loc={'g10':g,'xi':xi,'eta_H':eta,'reference_width_M':xi,'reference_width_H':eta}
squares=[2,3,5,7,-1];factors={(i,j):int(s.prod(squares[k] for k in range(5) if i&j&(1<<k))) for i in range(32) for j in range(32)}
def put(p,k,v):
 if not v:return
 p[k]=p.get(k,F(0))+v
 if not p[k]:del p[k]
def add(*pp):
 out={}
 for p in pp:
  for k,v in p.items():put(out,k,v)
 return out
def scaled(p,c):return {k:v*c for k,v in p.items() if v*c}
@lru_cache(None)
def canonical(w):
 out=[];sg=1
 for token in w:
  if par[token[0]] and token in out:return (),0
  at=len(out)
  while at and out[at-1]>token:
   if par[token[0]] and par[out[at-1][0]]:sg=-sg
   at-=1
  out.insert(at,token)
 return tuple(out),sg
def product(p,q):
 out={}
 for (gp,xp,hp,m,w),c in p.items():
  for (gq,xq,hq,n,v),d in q.items():
   word,sg=canonical(w+v)
   if sg:put(out,(gp+gq,xp+xq,hp+hq,m^n,word),c*d*(sg*factors[m,n]))
 return out
@lru_cache(None)
def coefficients(text):
 z=s.expand(s.sympify(text,locals=loc));out={}
 assert not z.has(s.Float) and z.free_symbols<={g,xi,eta}
 for powers,co in s.Poly(z,g,xi,eta).terms():
  for term in s.Add.make_args(s.expand(co)):
   rat,rest=term.as_coeff_Mul(rational=True);assert rat.is_Rational;number=F(int(rat.p),int(rat.q));mask=0
   for factor in s.Mul.make_args(rest):
    if factor==s.I:mask^=16
    elif factor.is_Rational:number*=F(int(factor.p),int(factor.q))
    else:
     assert factor.is_Pow and factor.exp==s.Rational(1,2) and factor.base.is_Integer and factor.base>0,factor
     value=int(factor.base)
     for bit,prime in enumerate(squares[:4]):
      exponent=0
      while value%prime==0:value//=prime;exponent+=1
      number*=prime**(exponent//2)
      if exponent%2:mask^=1<<bit
     assert value==1
   put(out,(*powers,mask),number)
 return tuple(out.items())
def token(t):
 n,_,j=t.partition('__');return index[n],tuple(map(int,j))
def rows(rr):
 out={}
 for row in rr:
  w=tuple(map(token,row['word']));assert canonical(w)==(w,1)
  for (gp,xp,hp,m),v in coefficients(row['coefficient']):
   if 'g' in row:assert gp==0;gp=row['g']
   put(out,(gp,xp,hp,m,w),v)
 return out
def unpack(packet):
 out={}
 for gp,word,cid in packet['monomials']:
  w=tuple((n,tuple(j)) for n,j in word);assert canonical(w)==(w,1)
  for xp,hp,m,num,den in packet['coefficients'][cid]:put(out,(gp,xp,hp,m,w),F(num,den))
 return out
def elem(n,j=()):
 if isinstance(n,str):n=index[n]
 return {(0,0,0,0,((n,j),)):F(1)}
def D(p,mu):
 out={}
 for(gp,xp,hp,m,w),v in p.items():
  for at,(n,j) in enumerate(w):
   word,sg=canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
   if sg:put(out,(gp,xp,hp,m,word),v*sg)
 return out
def DD(p,j):
 for mu in j:p=D(p,mu)
 return p
def gradient(p):
 out={}
 for(gp,xp,hp,m,w),v in p.items():
  total=sum(par[n] for n,j in w)%2
  for at,(n,j) in enumerate(w):
   suffix=sum(par[t] for t,k in w[at+1:]);sg=(-1)**((par[n]*suffix+par[n]*(total-par[n]))%2);put(out.setdefault((n,j),{}),(gp,xp,hp,m,w[:at]+w[at+1:]),v*sg)
 return out
def EL(p,domain):
 out={n:{} for n in domain}
 for(n,j),df in gradient(p).items():
  if n in domain:out[n]=add(out[n],scaled(DD(df,j),(-1)**len(j)))
 return out
def vector(p):
 el=EL(p,canon);v={}
 for i in fields:v[i]=scaled(el[Jof[i]],-(-1)**par[i]);v[Jof[i]]=scaled(el[i],(-1)**par[i])
 return v
def operation(images,odd=False):
 images={n:p for n,p in images.items() if p};cache={}
 def act(p):
  out={}
  for(gp,xp,hp,m,w),c in p.items():
   total=sum(par[n] for n,j in w)%2
   for at,(n,j) in enumerate(w):
    if n not in images:continue
    if(n,j) not in cache:cache[n,j]=DD(images[n],j)
    suffix=sum(par[t] for t,k in w[at+1:]);sg0=(-1)**((par[n]*suffix+(total+par[n] if odd else 0))%2);rest=w[:at]+w[at+1:]
    for(gq,xq,hq,mask,repl),v in cache[n,j].items():
     word,sg=canonical(rest+repl)
     if sg:put(out,(gp+gq,xp+xq,hp+hq,m^mask,word),c*v*(sg0*sg*factors[m,mask]))
  return out
 return act
def collapsed(p):
 out={}
 for(gp,xp,hp,m,w),v in p.items():out.setdefault((gp,w),{})[xp,hp,m]=v
 return out
def summary(p):
 h=sha256();h.update(b'[');cc=collapsed(p)
 for i,((gp,w),co) in enumerate(sorted(cc.items())):
  if i:h.update(b',')
  row=[gp,[[names[n],list(j)] for n,j in w],[[list(k),str(v)] for k,v in sorted(co.items())]];h.update(json.dumps(row,separators=(',',':'),ensure_ascii=True).encode())
 h.update(b']');return {'g_word_positions':len(cc),'field_words':len({w for gp,w in cc}),'sha256_exact_cells':h.hexdigest()}

def mul(*pp):
 out={(0,0,0,0,()):F(1)}
 for p in pp:out=product(out,p)
 return out
def subst(p,images):
 out={}
 for(gp,xp,hp,m,w),c in p.items():
  pp={(gp,xp,hp,m,()):c}
  for n,j in w:pp=product(pp,DD(images.get(n,elem(n)),j))
  for key,value in pp.items():put(out,key,value)
 return out
def scalar(z):return rows([{'word':[],'coefficient':str(z)}])




inp=json.loads(gzip.decompress((O/'primary_classical_inputs.json.gz').read_bytes()));rinp=json.loads(gzip.decompress((O/'replay_classical_inputs.json.gz').read_bytes()))
u=[index['mw_u'+str(i)] for i in range(2)];rho=[index['mw_rho'+str(i)] for i in range(2)];eps=index['hr_epsilon'];bg=[index['mw_a'+str(i)] for i in range(45)];bl=[index['mw_L'+str(i)] for i in range(45)];qs=[index['mw_q'+str(i)] for i in range(4)]
bn=[[index[f'B{i}_{mu}'] for mu in range(4)] for i in range(45)];an=[index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];ln=[index[('b' if i<12 else 'L')+str(i)] for i in range(45)];cn=[index[f'C{i}'] for i in range(45)]
jl=[Jof[n] for n in ln];ja=[Jof[n] for n in an];jc=[Jof[n] for n in cn];chi=set(jl+bg)
def fm(p):return {(i,j):unpack(v) for i,j,v in p}
HS=[fm(p) for p in inp['H_symbols']];VS=fm(inp['V_symbols']);N=fm(inp['root_symbols']);delta=fm(rinp['root_symbols']);VJC={}
def even(p):return {}
# Third orientation and signature convolution replace closed index paths.
vec=[F(0),F(1),F(0),F(0)]
def ev(p):return subst(p,{q:scalar(z) for q,z in zip(qs,vec)})
def sig(w,root):
 if any(j or n not in chi|set(ja+rho+qs)|({eps} if root else set()) for n,j in w):return None
 if sum(n==eps for n,j in w)!=int(root):return None
 d=(sum(n==rho[0] for n,j in w),sum(n==rho[1] for n,j in w),sum(n in ja for n,j in w),sum(n in chi for n,j in w))
 return d if max(d)<=1 else None
def split(M,root=False):
 out={}
 for ij,p in M.items():
  for k,v in ev(p).items():
   sg=sig(k[-1],root)
   if sg is not None:put(out.setdefault(sg,{}).setdefault(ij,{}),k,v)
 return out
def mm(A,B):
 rows=defaultdict(list);out={}
 for(k,j),p in B.items():rows[k].append((j,p))
 for(i,k),p in A.items():
  for j,q in rows[k]:
   z=product(p,q)
   if z:out[i,j]=add(out.get((i,j),{}),z)
 return {ij:p for ij,p in out.items() if p}
def ma(A,B):
 out=dict(A)
 for ij,p in B.items():out[ij]=add(out.get(ij,{}),p)
 return {ij:p for ij,p in out.items() if p}
def trace(A,graded=True):return add(*(scaled(p,(-1)**par[i] if graded else 1) for(i,j),p in A.items() if i==j))
G={}
for i in range(45):
 for mu in range(4):G[bn[i][mu],bn[i][mu]]=scalar('eta_H' if i<12 else 'xi') if mu==1 else scalar('1')
 G[bn[i][1],ln[i]]=scalar('-1');G[ln[i],bn[i][1]]=scalar('1');G[cn[i],an[i]]=scalar('1');G[an[i],cn[i]]=scalar('-1')
V=dict(VS)
for H in HS:V=ma(V,H)
blocks={sg:mm(G,p) for sg,p in split(V).items()};assert all(any(sg) for sg in blocks)
roots=split(N,True);droots={sg:mm(G,p) for sg,p in split(delta,True).items()};noJC={k:add(p,scaled(even(VJC.get(k,{})),-1)) for k,p in delta.items()};noJroots={sg:mm(G,p) for sg,p in split(noJC,True).items()}
target=(1,1,1,1);zero=(0,0,0,0)
I={(i,i):scalar('1') for i in set(n for ij in G for n in ij)};products={zero:I};heat={str(n):{} for n in range(1,6)};born={str(n):{} for n in range(1,6)};ordinary={str(n):{} for n in range(1,6)};omit_roots={};born_noJC={str(n):{} for n in range(1,6)}
for k in range(5):
 total={};ord0={}
 for sg,root in roots.items():
  rem=tuple(a-b for a,b in zip(target,sg))
  if rem in products:
   z=mm(products[rem],root);t=trace(z);total=add(total,t);ord0=add(ord0,trace(z,False));omit_roots[str(sg)+':'+str(k)]=t
 if k:
  heat[str(k)]=add(heat[str(k)],scaled(total,(-1)**k));heat[str(k+1)]=add(heat[str(k+1)],scaled(total,-(-1)**k));ordinary[str(k)]=add(ordinary[str(k)],scaled(ord0,(-1)**k));ordinary[str(k+1)]=add(ordinary[str(k+1)],scaled(ord0,-(-1)**k))
 else:assert not total
 if k<4:
  for sg,root in droots.items():
   rem=tuple(a-b for a,b in zip(target,sg))
   if rem in products:born[str(k+1)]=add(born[str(k+1)],scaled(trace(mm(products[rem],root)),F((-1)**k,2)))
  for sg,root in noJroots.items():
   rem=tuple(a-b for a,b in zip(target,sg))
   if rem in products:born_noJC[str(k+1)]=add(born_noJC[str(k+1)],scaled(trace(mm(products[rem],root)),F((-1)**k,2)))
 next0={}
 for a,A in products.items():
  for b,B in blocks.items():
   sg=tuple(x+y for x,y in zip(a,b))
   if max(sg)<=1:next0[sg]=ma(next0.get(sg,{}),mm(A,B))
 products=next0
def strip(p):
 for n in [eps,rho[0],rho[1]]:p=gradient(p).get((n,()),{})
 return p
heat={n:strip(p) for n,p in heat.items()};born={n:strip(p) for n,p in born.items()};ordinary={n:strip(p) for n,p in ordinary.items()}
assert heat=={n:unpack(p) for n,p in P['heat_polynomial'].items()}
assert born=={n:unpack(p) for n,p in Z['heat_polynomial'].items()}
assert heat==born,'ACTUAL_REGULATED_WARD_IDENTITY_MISMATCH'
assert not add(*heat.values()),'UNCANCELLED_RADIAL_LOG'
for p in heat.values():
 for gp,xp,hp,m,w in p:assert len(w)==2 and sum(n in ja for n,j in w)==1 and sum(n in chi for n,j in w)==1 and all(not j for n,j in w)
# Full4050 carrier includes the zero complement, not a sparse-only match.
for l in ja:
 for c in sorted(chi):
  w,sg=canonical(((l,()),(c,())))
  for n in heat:
   assert {k:v for k,v in heat[n].items() if k[-1]==w}=={k:v for k,v in born[n].items() if k[-1]==w}
e=s.symbols('e',positive=True)
for k in range(1,5):assert s.simplify(s.limit(s.gamma(e)*((2*k)**(-e)-(2*(k+1))**(-e)),e,0)-s.log(s.Rational(k+1,k)))==0
print('STAGE verifier full4050_heat_and_radial_comparison_complete',flush=True)

finite={prime:{} for prime in [2,3,5]}
for n,p in heat.items():
 for prime,power in s.factorint(int(n)).items():finite[prime]=add(finite[prime],scaled(p,-int(power)))
result={'schema':'PROBE_SOURCE_WARD_COMPANION_VALIDATION_V1','elapsed_after_imports':time.perf_counter()-tick,'full_carrier_slots':4050,'heat_positions':{n:summary(p) for n,p in heat.items()},'finite_by_prime':{str(n):summary(p) for n,p in finite.items()},'complete_heat_polynomial_zero':not any(heat.values()),'ordinary_trace_differs':ordinary!=heat,'qualified_derivative_symbols_reused':True,'full_QAP_or_other_Ward_carriers_qualified':False,'authority_changed':False}
print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
