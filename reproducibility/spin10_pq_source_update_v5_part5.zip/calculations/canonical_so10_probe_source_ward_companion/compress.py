from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import gzip,json,time,threading,os
O=Path(__file__).resolve().parent;B=O.parent/'canonical_so10_probe_heat_ward_response';tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
for p,h in json.loads((O/'compression_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
def load(p):return json.loads(gzip.decompress(p.read_bytes()))
def unpack(p):
 out={}
 for g,w,c in p['monomials']:
  for x,h,m,n,d in p['coefficients'][c]:out[g,x,h,m,tuple((i,tuple(j)) for i,j in w)]=F(n,d)
 return out
findings=[]
for role in ['primary','replay']:
 a=load(B/(role+'_tables.json.gz'));b=load(O/(role+'_tables.json.gz'));assert a['names']==b['names'] and a['parities']==b['parities'];ix={n:i for i,n in enumerate(a['names'])};par=a['parities']
 jl=[ix[('Jb' if i<12 else 'JL')+str(i)] for i in range(45)];ja=[ix[('Jbar' if i<12 else 'Jub')+str(i)] for i in range(45)];bl=[ix['mw_L'+str(i)] for i in range(45)];bg=[ix['mw_a'+str(i)] for i in range(45)];rename={**dict(zip(jl,bg)),**dict(zip(bl,ja))}
 mapped_heat={};right_heat={}
 for n in map(str,range(1,6)):
  left=unpack(a['heat_polynomial'][n]);right=unpack(b['heat_polynomial'][n]);mapped={}
  for(g,x,h,m,w),v in left.items():
   ww=tuple((rename[i],j) for i,j in w);sg=(-1)**sum(par[i]*par[k] for at,(i,j) in enumerate(ww) for k,l in ww[at+1:] if i>k);ww=tuple(sorted(ww));key=(g,x,h,m,ww);assert key not in mapped;mapped[key]=v*sg
  mapped_heat[n]=mapped;right_heat[n]=right;findings.append({'role':role,'heat_power':int(n),'mapped_cells':len(mapped),'exact_equal':mapped==right})
 assert len(unpack(b['heat_polynomial']['3']))==56
 cells=unpack(b['heat_polynomial']['3']);assert all(g==2 and x==1 and h==2 and m==0 and all(not j for i,j in w) for g,x,h,m,w in cells)
 w=tuple(sorted(((ja[13],()),(bg[13],()))));assert cells[2,1,2,0,w]==F(1,5)
 # Check every carrier word, including the3994 zero positions, exactly.
 for J in ja:
  for c in jl+bg:
   w=tuple(sorted(((J,()),(c,()))))
   for n in map(str,range(1,6)):assert {k:v for k,v in right_heat[n].items() if k[-1]==w}=={k:v for k,v in mapped_heat[n].items() if k[-1]==w}
assert all(x['exact_equal'] for x in findings)
print('RESULT '+json.dumps({'schema':'PROBE_SOURCE_TENSOR_COMPRESSION_V1','elapsed_after_imports':time.perf_counter()-tick,'both_routes_exact_same_K_under_JL_Lambda_to_a_Ja':True,'nonzero_tensor_entries':56,'anchor_13_13':'1/5','all_coupling_width_and_radical_cells_checked':True,'full_arrays_including_zero_complement_equal':True,'findings':findings,'new_loop_derivation':False,'authority_changed':False},sort_keys=True),flush=True);watch.cancel()
