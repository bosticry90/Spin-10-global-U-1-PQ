# A nonzero source companion uses the same measured tensor

The primary, replay and separate expanded-Fraction checks completed over
the full 4,050-position Ja*(JL,a) carrier. The exact tensor compression also
passed. This extends the local heat-response calculation, not the complete
renormalized quantum construction or scientific authority.

After extracting rho0*rho1, in units of hbar/(16 pi^2), the result is

    B_H,source = +g10^2 xi eta_H^2 log(4/3) sum_ij K_ij a_i Ja_j.

Ja_j is the source for the ordinary antighost. K is exactly the 56-entry
tensor of the separately qualified auxiliary response, with K_13,13=1/5.
The tensor relation, including its order and sign, was checked after the
new calculations; no coefficient was supplied from that expected mapping.
There is no JL*Ja component. All other carrier positions vanish.

Both routes also agree before radial integration: the complete polynomial
is the displayed tensor times (E^3-E^4). The E, E^2 and E^5 coefficients
vanish, and the unweighted heat sum is zero. A leading logarithm therefore
vanishes while a finite log(4/3) response survives. Ordinary trace changes
the result; its use would lose the required graded signs.

Together with PHR1, the complete retained anchor-linear response is

    B_H,anchors = +g10^2 xi eta_H^2 log(4/3)
                  sum_ij K_ij (JL_i Lambda_j + a_i Ja_j).

This is 112 nonzero coefficient positions across two 4,050-position
carriers. It is not a count of physical interactions or independent tests.

## Methods and evidence

Inputs contain the already qualified full field tangent or independently
derived full source/field/probe variation, before the old auxiliary target
filter. Classical Hessians and derivative symbols are extracted separately
from all heat/finite target arrays. No raw action/frame calculation is
repeated. The source is differentiated before restriction.

Primary closed index paths, replay rooted products and third expanded-
Fraction signature convolution check the entire ordered heat polynomials
and zero complement. The finite-cutoff identity and the reviewed single-
variation infrared/ultraviolet argument transfer because Ja and Lambda
have the same dimension, parity and ghost number. Other operator grades
are not inferred from that transfer.

Native runtimes were 9.748 and 18.322 seconds; the verifier took 34.330
seconds. Their maximum sampled private allocation was 1,329,025,024 bytes,
not a true peak. Compression took 2.875 seconds. No worker or verifier
failed. The frozen time, sampled-memory, launch-floor and packet limits
held. The PHR1 failed verifier remains preserved in its own packet.

Validation receipt SHA256:
39fd510ed36983d8591a42dba5a4863807ba4368780e706888f0090c275f542a.

The calculations share action, classical symbols, conventions, analytic
premises, software and AI author. The third method reuses qualified
derivative symbols; it is not a third action derivation or external
scientific validation.

## What this decides and what is next

The source companion is genuinely nonzero. Thus the auxiliary-only
projection must not be substituted for the full source-dependent Ward
response. The same-tensor relationship is measured, not a chosen finite
normalization or an anomaly finding.

PHR1 has independently compared its auxiliary coefficient with the old
relative Ward variation. The corresponding full relative Ja companion
has NOT yet been computed. No such cancellation is claimed here. The
next smallest necessary calculation is that companion from the actual
mixed and one-probe conversion terms, including dimensional residue jets
and source derivatives. It must be derived before comparing it with this
measured heat response; assigning its value as -B_H,source would be invalid.

Other Ward carriers, full connected U, the prescribed T_kappa finite
conversion, chiral/measure/global-phase and physical limits remain open.
Kappa, b0 and infrared constants are not fixed or equated. E5/A5 and the
physical Spin(10) x PQ hypothesis remain unqualified. Authority stays
34/39; historical custody stays exit2 with seven unresolved references.
