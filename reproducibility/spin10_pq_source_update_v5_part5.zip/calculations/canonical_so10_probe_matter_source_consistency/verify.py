from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from collections import defaultdict
import json,gzip,time,threading,os,sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(300,lambda:os._exit(124));watch.daemon=True;watch.start()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
def guard(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('CGK_VERIFIER_WRITE')
os.sys.addaudithook(guard)
P=json.loads(gzip.decompress((O/'primary_tables.json.gz').read_bytes()));Z=json.loads(gzip.decompress((O/'replay_tables.json.gz').read_bytes()))
names=P['names'];par=P['parities'];index={n:i for i,n in enumerate(names)};inp=json.loads(gzip.decompress((O/'primary_inputs.json.gz').read_bytes()));geo=inp['geometry'];pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};sources={J for i,J,h,k in pairs};canon=fields|sources;Jof={i:J for i,J,h,k in pairs}
g,xi,eta=s.symbols('g10 xi eta_H');loc={'g10':g,'xi':xi,'eta_H':eta,'reference_width_M':xi,'reference_width_H':eta}
squares=[2,3,5,7,-1];factors={(i,j):int(s.prod(squares[k] for k in range(5) if i&j&(1<<k))) for i in range(32) for j in range(32)}
def put(p,k,v):
 if not v:return
 p[k]=p.get(k,F(0))+v
 if not p[k]:del p[k]
def add(*pp):
 out={}
 for p in pp:
  for k,v in p.items():put(out,k,v)
 return out
def scaled(p,c):return {k:v*c for k,v in p.items() if v*c}
@lru_cache(None)
def canonical(w):
 out=[];sg=1
 for token in w:
  if par[token[0]] and token in out:return (),0
  at=len(out)
  while at and out[at-1]>token:
   if par[token[0]] and par[out[at-1][0]]:sg=-sg
   at-=1
  out.insert(at,token)
 return tuple(out),sg
def product(p,q):
 out={}
 for (gp,xp,hp,m,w),c in p.items():
  for (gq,xq,hq,n,v),d in q.items():
   word,sg=canonical(w+v)
   if sg:put(out,(gp+gq,xp+xq,hp+hq,m^n,word),c*d*(sg*factors[m,n]))
 return out
@lru_cache(None)
def coefficients(text):
 z=s.expand(s.sympify(text,locals=loc));out={}
 assert not z.has(s.Float) and z.free_symbols<={g,xi,eta}
 for powers,co in s.Poly(z,g,xi,eta).terms():
  for term in s.Add.make_args(s.expand(co)):
   rat,rest=term.as_coeff_Mul(rational=True);assert rat.is_Rational;number=F(int(rat.p),int(rat.q));mask=0
   for factor in s.Mul.make_args(rest):
    if factor==s.I:mask^=16
    elif factor.is_Rational:number*=F(int(factor.p),int(factor.q))
    else:
     assert factor.is_Pow and factor.exp==s.Rational(1,2) and factor.base.is_Integer and factor.base>0,factor
     value=int(factor.base)
     for bit,prime in enumerate(squares[:4]):
      exponent=0
      while value%prime==0:value//=prime;exponent+=1
      number*=prime**(exponent//2)
      if exponent%2:mask^=1<<bit
     assert value==1
   put(out,(*powers,mask),number)
 return tuple(out.items())
def token(t):
 n,_,j=t.partition('__');return index[n],tuple(map(int,j))
def rows(rr):
 out={}
 for row in rr:
  w=tuple(map(token,row['word']));assert canonical(w)==(w,1)
  for (gp,xp,hp,m),v in coefficients(row['coefficient']):
   if 'g' in row:assert gp==0;gp=row['g']
   put(out,(gp,xp,hp,m,w),v)
 return out
def unpack(packet):
 out={}
 for gp,word,cid in packet['monomials']:
  w=tuple((n,tuple(j)) for n,j in word);assert canonical(w)==(w,1)
  for xp,hp,m,num,den in packet['coefficients'][cid]:put(out,(gp,xp,hp,m,w),F(num,den))
 return out
def elem(n,j=()):
 if isinstance(n,str):n=index[n]
 return {(0,0,0,0,((n,j),)):F(1)}
def D(p,mu):
 out={}
 for(gp,xp,hp,m,w),v in p.items():
  for at,(n,j) in enumerate(w):
   word,sg=canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
   if sg:put(out,(gp,xp,hp,m,word),v*sg)
 return out
def DD(p,j):
 for mu in j:p=D(p,mu)
 return p
def gradient(p):
 out={}
 for(gp,xp,hp,m,w),v in p.items():
  total=sum(par[n] for n,j in w)%2
  for at,(n,j) in enumerate(w):
   suffix=sum(par[t] for t,k in w[at+1:]);sg=(-1)**((par[n]*suffix+par[n]*(total-par[n]))%2);put(out.setdefault((n,j),{}),(gp,xp,hp,m,w[:at]+w[at+1:]),v*sg)
 return out
def EL(p,domain):
 out={n:{} for n in domain}
 for(n,j),df in gradient(p).items():
  if n in domain:out[n]=add(out[n],scaled(DD(df,j),(-1)**len(j)))
 return out
def vector(p):
 el=EL(p,canon);v={}
 for i in fields:v[i]=scaled(el[Jof[i]],-(-1)**par[i]);v[Jof[i]]=scaled(el[i],(-1)**par[i])
 return v
def operation(images,odd=False):
 images={n:p for n,p in images.items() if p};cache={}
 def act(p):
  out={}
  for(gp,xp,hp,m,w),c in p.items():
   total=sum(par[n] for n,j in w)%2
   for at,(n,j) in enumerate(w):
    if n not in images:continue
    if(n,j) not in cache:cache[n,j]=DD(images[n],j)
    suffix=sum(par[t] for t,k in w[at+1:]);sg0=(-1)**((par[n]*suffix+(total+par[n] if odd else 0))%2);rest=w[:at]+w[at+1:]
    for(gq,xq,hq,mask,repl),v in cache[n,j].items():
     word,sg=canonical(rest+repl)
     if sg:put(out,(gp+gq,xp+xq,hp+hq,m^mask,word),c*v*(sg0*sg*factors[m,mask]))
  return out
 return act
def collapsed(p):
 out={}
 for(gp,xp,hp,m,w),v in p.items():out.setdefault((gp,w),{})[xp,hp,m]=v
 return out
def summary(p):
 h=sha256();h.update(b'[');cc=collapsed(p)
 for i,((gp,w),co) in enumerate(sorted(cc.items())):
  if i:h.update(b',')
  row=[gp,[[names[n],list(j)] for n,j in w],[[list(k),str(v)] for k,v in sorted(co.items())]];h.update(json.dumps(row,separators=(',',':'),ensure_ascii=True).encode())
 h.update(b']');return {'g_word_positions':len(cc),'field_words':len({w for gp,w in cc}),'sha256_exact_cells':h.hexdigest()}

def mul(*pp):
 out={(0,0,0,0,()):F(1)}
 for p in pp:out=product(out,p)
 return out
def subst(p,images):
 out={}
 for(gp,xp,hp,m,w),c in p.items():
  pp={(gp,xp,hp,m,()):c}
  for n,j in w:pp=product(pp,DD(images.get(n,elem(n)),j))
  for key,value in pp.items():put(out,key,value)
 return out
def scalar(z):return rows([{'word':[],'coefficient':str(z)}])




for k in ['names','parities','qghost','field_image','module_image','total_image','source_matrix','source_nonzero_positions','total_image_zero','controls']:
 assert P[k]==Z[k],k
fm=lambda pkt:{(i,j):unpack(p) for i,j,p in pkt}
field=fm(P['field_image']);module=fm(P['module_image']);total=fm(P['total_image'])
for i in range(16):
 for j in range(16):assert total.get((i,j),{})==add(field.get((i,j),{}),module.get((i,j),{}))
q={n:unpack(p) for n,p in P['qghost']};u=[index['mw_u'+str(i)] for i in range(2)];rho=[index['mw_rho'+str(i)] for i in range(2)];cn=[index['C'+str(i)] for i in range(45)];probe=set(u+rho)
for c in cn:assert not operation(q,True)(q.get(c,{}))
for out in [P,Z]:
 assert out['nonconstant_cochain_image_nonzero'] and out['nonconstant_D_squared_zero']
 assert out['ordinary_matter_ghost_rows_unchanged_by_actual_generator_ports']
 assert not out['full_Slavnov_QAP_exactness_or_quantum_restoration'] and not out['authority_changed']
controls=P['controls'];assert min(controls.values())>0
counts=lambda M:{str(d):sum(len({(g,w) for g,x,h,m,w in p if sum(n in probe for n,j in w)==d}) for p in M.values()) for d in range(3)}
assert not total,'NONZERO_COMPUTED_MODULE_IMAGE_REQUIRES_SCIENTIFIC_DISPOSITION'
print('RESULT '+json.dumps({'schema':'PROBE_MATTER_SOURCE_CONSISTENCY_VALIDATION_V1','elapsed_after_imports':time.perf_counter()-tick,'all45_actual_vs_generator_ghost_columns_agree':True,'all16x16_matrix_images_and_zero_complements_agree':True,'field_image_nonzero_by_probe_degree':counts(field),'module_image_nonzero_by_probe_degree':counts(module),'augmented_source_consistency_image_zero':not total,'nonconstant_D_squared_zero':True,'controls':controls,'counterterm_primitive_constructed':False,'complete_quantum_Slavnov_QAP_measure_or_phase':False,'authority_changed':False,'shared_action_frame_normalization_software_AI_author':True},sort_keys=True),flush=True);watch.cancel()
