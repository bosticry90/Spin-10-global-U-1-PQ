from pathlib import Path
from hashlib import sha256
import gzip,json,sys,ast
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/probe-matter-source-consistency-v1-2026-10-24')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
v=read(O/'validation_receipt_v3.json');assert v['augmented_source_consistency_image_zero']
b={}
for n in ['PRIMITIVE.md','PRIMITIVE_PRELAUNCH.md','primitive_generator_failure.json','build_primitive.py','generate_primitive_v2.py','build_primitive_v2.py','primitive.py','run_primitive.py']:
 p=O/n
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(O/(n+'.source.txt'))
for n in ['primary_inputs_v2.json.gz','replay_inputs_v2.json.gz','primary_v3_tables.json.gz','replay_v3_tables.json.gz','validation_receipt_v3.json','validation_preparation_v3.json']:b[str(O/n)]=H(O/n)
for name,h in read(O/'validation_preparation_v3.json')['input_sha256'].items():assert H(Path(name))==h,name
nb={str(p):H(p) for p in [R/'AGENTS.md',R/'project_state.json',R/'tools/portable_dh_v1/inputs.json.gz',R/'tools/portable_dh_v1/exact_algebra.py',O/'primitive.py',O/'primary_inputs_v2.json.gz',O/'replay_inputs_v2.json.gz']}
dump(O/'primitive_preparation.json',{'input_sha256':b,'native_input_sha256':nb,'seconds_after_imports':120,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2})
c=capture([sys.executable,'-B',str(O/'primitive.py'),'primary']);dump(O/'primitive_capture.json',c);dump(C/'primitive_full_capture.json',c);print(c['stdout_and_stderr'],flush=True)
assert c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
assert max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3 and c['launch']['memory']['available_pagefile']>=350*1024**2
rr=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<120
blob=(O/'primitive_tables.json.gz').read_bytes();assert sha256(blob).hexdigest()==rr[0]['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==rr[0]['raw_sha256']
dump(O/'primitive_receipt.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<16*1024**2
