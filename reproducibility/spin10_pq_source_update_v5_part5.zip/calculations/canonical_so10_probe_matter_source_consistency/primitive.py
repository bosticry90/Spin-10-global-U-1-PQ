"""Actual augmented action: mixed and companion local quantum coefficients."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from itertools import permutations
from collections import defaultdict
import gzip,json,sys,time,threading,os
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra,ONE,put,scale,scale_coefficient
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def add(*pp):
 out={}
 for p in pp:
  for k,c in p.items():put(out,k,c)
 return out
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 role=sys.argv[1];assert role in ['primary','replay'];prep=read(O/'primitive_preparation.json')
 for p,h in prep['native_input_sha256'].items():assert digest(Path(p))==h,p
 def guard(event,args):
  if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):
   assert Path(os.fsdecode(args[0])).resolve()==O/'primitive_tables.json.gz'
 sys.addaudithook(guard)
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry']
 extra=['mw_u0','mw_u1','mw_rho0','mw_rho1']+['mw_a'+str(i) for i in range(45)]+['mw_L'+str(i) for i in range(45)]+['mw_q'+str(i) for i in range(4)]+['mw_chi','mw_l32','mw_l2']
 A=Algebra(geo['names']+extra,geo['parities']+[0,0,1,1]+[1]*45+[0]*52)
 u=[A.index['mw_u'+str(i)] for i in range(2)];rho=[A.index['mw_rho'+str(i)] for i in range(2)]
 bg=[A.index['mw_a'+str(i)] for i in range(45)];bl=[A.index['mw_L'+str(i)] for i in range(45)];qs=[A.index['mw_q'+str(i)] for i in range(4)];cs=[A.index[n] for n in ['mw_chi','mw_l32','mw_l2']]
 pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};Jof={i:J for i,J,h,k in pairs};sources=set(Jof.values())
 bn=[[A.index[f'B{i}_{mu}'] for mu in range(4)] for i in range(45)];an=[A.index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];ln=[A.index[('b' if i<12 else 'L')+str(i)] for i in range(45)];cn=[A.index[f'C{i}'] for i in range(45)]
 jl=[Jof[i] for i in ln];ja=[Jof[i] for i in an];jc=[Jof[i] for i in cn];chi=set(jl+bg);anchors=set(bl+ja);ext=chi|anchors;probe=set(u+rho);core={n for b in bn for n in b}|set(an+ln+cn);bset={n for b in bn for n in b}
 dims={i:2 if i in ln else 1 for i in fields};ew={**dict.fromkeys(chi,1),**dict.fromkeys(anchors,2),**dict.fromkeys(rho,1)}
 def elem(n,j=()):
  if isinstance(n,str):n=A.index[n]
  return {(0,((n,j),)):ONE}
 @lru_cache(None)
 def scalar(z):return A.rows([{'word':[],'coefficient':str(z)}])
 def mul(*pp):
  p={(0,()):ONE}
  for q in pp:p=A.product(p,q)
  return p
 def rows(p):return A.rows(p)
 def pack(p):
  cc=[];ix={};mm=[]
  for(g,w),c in sorted(p.items()):
   if c not in ix:ix[c]=len(cc);cc.append([[*k,v.numerator,v.denominator] for k,v in c])
   mm.append([g,[[n,list(j)] for n,j in w],ix[c]])
  return {'coefficients':cc,'monomials':mm,'positions':len(p),'sha256':A.fingerprint(p)}
 def unpack(p,names=None):
  co=[tuple(((x,h,m),F(n,d)) for x,h,m,n,d in c) for c in p['coefficients']];out={}
  for g,w,k in p['monomials']:
   ww,sg=A.canonical(tuple((A.index[names[n]] if names else n,tuple(j)) for n,j in w))
   if sg:put(out,(g,ww),scale_coefficient(co[k],sg))
  return out
 def D(p,mu):
  out={}
  for(g,w),c in p.items():
   for at,(n,j) in enumerate(w):
    ww,sg=A.canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
    if sg:put(out,(g,ww),scale_coefficient(c,sg))
  return out
 def DD(p,j):
  for mu in j:p=D(p,mu)
  return p
 def sub(p,mp):
  out={}
  for(g,w),c in p.items():
   z={(g,()):c}
   for n,j in w:z=mul(z,DD(mp.get(n,elem(n)),j))
   for k,v in z.items():put(out,k,v)
  return out
 def grad(p):
  out={}
  for(g,w),c in p.items():
   total=sum(A.parities[n] for n,j in w);prefix=0
   for at,(n,j) in enumerate(w):
    sg=(-1)**(A.parities[n]*prefix) if role=='primary' else (-1)**(A.parities[n]*(total-prefix-A.parities[n])+A.parities[n]*(total-A.parities[n]))
    put(out.setdefault((n,j),{}),(g,w[:at]+w[at+1:]),scale_coefficient(c,sg));prefix+=A.parities[n]
  return {k:p for k,p in out.items() if p}
 def op(p,v,odd):
  out={}
  if role=='replay':
   for(n,j),df in grad(p).items():
    if n in v:
     for k,c in mul(DD(v[n],j),df).items():put(out,k,c)
  else:
   for(g,w),c in p.items():
    prefix=0
    for at,(n,j) in enumerate(w):
     if n in v:
      z=mul({(g,w[:at]):scale_coefficient(c,(-1)**prefix if odd else 1)},DD(v[n],j),{(0,w[at+1:]):ONE})
      for k,t in z.items():put(out,k,t)
     prefix+=A.parities[n]
  return out
 def wick(p):
  phases={**{b[0]:'I' for b in bn},**dict.fromkeys(ln+jl,'-I'),**dict.fromkeys(ja+jc,'-1')};out={}
  for(g,w),c in p.items():
   fac=scalar('-1')
   for n,j in w:
    fac=mul(fac,scalar(phases.get(n,'1')),scalar(['1','I','-1','-I'][j.count(0)%4]))
   for k,v in mul({(g,w):c},fac).items():put(out,k,v)
  return out


 import sympy as s
 inp=json.loads(gzip.decompress((O/(role+'_inputs_v2.json.gz')).read_bytes()));assert inp['names']==list(A.names)
 dec=lambda d:s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z) for i,j,z in d['entries']})
 Rcp=dec(inp['R_Cphysical_to_plane']);Rap=dec(inp['R_aphysical_to_plane']);Rinv=Rap.T
 fr=inp['frame'];order=fr['field_order'];phys=[f'B{i}_{mu}' for i in range(45) for mu in range(4)]+[f'x_{ss}_{i}' for ss,nn in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(nn)]+[A.names[n] for n in ln+cn+an]
 rc=[order.index('C'+str(i)) for i in range(45)];pc=[phys.index('C'+str(i)) for i in range(45)]
 TC=dec(fr['physical_to_raw_kernel']).extract(pc,rc);TiC=dec(fr['physical_to_raw_inverse']).extract(rc,pc)
 zz=lambda M:not s.SparseMatrix(M).applyfunc(s.expand).todok()
 assert zz(TC*TiC-s.eye(45)) and zz(dec(inp['Q'])*TiC-Rcp)
 print('STAGE '+role+' authenticated_explicit_inverse_ghost_frame_checked',flush=True)
 rawC={cn[r]:add(*(mul(scalar(str(TiC[r,i])),elem(cn[i])) for i in range(45) if TiC[r,i])) for r in range(45)}
 Rsource={k:unpack(p) for k,p in inp['source_plane_Lie']}
 pf=defaultdict(list)
 for a,b,k,z in inp['plane_f']:pf[a,b].append((k,scalar(z)))
 rp=defaultdict(list)
 for(r,i),z in Rcp.todok().items():rp[i].append((r,scalar(str(z))))
 qghost={}
 if role=='primary':
  rawcols=[rows(inp['raw_ghost_BRST'][str(i)]) for i in range(45)]
  for i in range(45):qghost[cn[i]]=sub(add(*(mul(scalar(str(TC[i,j])),rawcols[j]) for j in range(45) if TC[i,j])),rawC)
 else:
  for i in range(45):qghost[cn[i]]={}
  for a in range(45):
   for b in range(a+1,45):
    f={}
    for r,x in rp[a]:
     for t,y in rp[b]:
      for k,z in pf[r,t]:f[k]=add(f.get(k,{}),mul(x,y,z))
    for k,z in f.items():
     for i in range(45):
      if Rinv[i,k]:qghost[cn[i]]=add(qghost[cn[i]],mul(scalar('-g10'),elem(cn[a]),elem(cn[b]),z,scalar(str(Rinv[i,k]))))
 print('STAGE '+role+' complete_actual_ghost_columns_derived',flush=True)
 qghost={k:p for k,p in qghost.items() if p};dprobe={u[r]:elem(rho[r]) for r in range(2)}
 def fop(p,withprobe=True):return op(p,{**qghost,**(dprobe if withprobe else {})},True)
 def ma(*MM):
  out={}
  for M in MM:
   for ij,p in M.items():out[ij]=add(out.get(ij,{}),p)
  return {ij:p for ij,p in out.items() if p}
 def mm(M,N):
  rr=defaultdict(list);out={}
  for(k,j),p in N.items():rr[k].append((j,p))
  for(i,k),p in M.items():
   for j,q in rr[k]:out[i,j]=add(out.get((i,j),{}),mul(p,q))
  return {ij:p for ij,p in out.items() if p}
 ms=lambda M,z:{ij:scale(p,z) for ij,p in M.items() if p}
 Tp=[{(i,j):scalar(z) for i,j,z in M['entries']} for M in inp['Tminus']]
 Tphys=[ma(*({ij:mul(z,p) for ij,p in Tp[r].items()} for r,z in rp[a])) for a in range(45)]
 to_matrix=lambda L:ma(*({ij:mul(c,p) for ij,c in Tp[k].items()} for k,p in L.items()))
 Rmat=to_matrix(Rsource)
 print('STAGE '+role+' source_fundamental_matrix_reconstructed',flush=True)
 connection=ma(*({ij:mul(elem(cn[a]),p) for ij,p in Tphys[a].items()} for a in range(45)))
 def module(M):return {ij:mul(scalar('-I*g10'),p) for ij,p in ma(mm(connection,M),ms(mm(M,connection),-1)).items()}
 def direct(M,withprobe=True):return ma({ij:fop(p,withprobe) for ij,p in M.items()},module(M))

 def dL(L):
  result={k:fop(p) for k,p in L.items()}
  for a in range(45):
   for r,x in rp[a]:
    for k,p in L.items():
     for e,f in pf[r,k]:result[e]=add(result.get(e,{}),mul(scalar('g10'),elem(cn[a]),x,p,f))
  return {k:p for k,p in result.items() if p}
 def la(*LL):
  out={}
  for L in LL:
   for k,p in L.items():out[k]=add(out.get(k,{}),p)
  return {k:p for k,p in out.items() if p}
 def ls(L,z):return {k:scale(p,z) for k,p in L.items() if p}
 Xparts=[];Bparts=[];Dparts=[]
 for r in range(2):
  B={k:grad(p).get((rho[r],()),{}) for k,p in Rsource.items()};B={k:p for k,p in B.items() if p};Bparts.append(B)
  X={k:mul(elem(u[r]),p) for k,p in B.items()};X={k:p for k,p in X.items() if p};Xparts.append(X)
  manual={}
  for k,p in Rsource.items():
   for(g,w),c in p.items():
    for at,(n,j) in enumerate(w):
     if n!=rho[r]:continue
     assert not j;sg=(-1)**sum(A.parities[t] for t,jj in w[:at]);ww,sg2=A.canonical(w[:at]+w[at+1:]+((u[r],()),))
     if sg2:put(manual.setdefault(k,{}),(g,ww),scale_coefficient(c,sg*sg2))
  manual={k:p for k,p in manual.items() if p};assert manual==X
  Dparts.append(dL(X))
 X=la(*Xparts);DX=dL(X);assert DX==la(*Dparts)
 target={k:{key:c for key,c in p.items() if any(n in probe for n,j in key[1])} for k,p in Rsource.items()};target={k:p for k,p in target.items() if p}
 assert DX==target
 for r in range(2):
  one={k:{key:c for key,c in p.items() if any(n in [u[r],rho[r]] for n,j in key[1])} for k,p in target.items()};one={k:p for k,p in one.items() if p};assert Dparts[r]==one and one
 for p in X.values():
  for(g,w),co in p.items():
   assert g==3 and len(w)==2 and sum(n in u for n,j in w)==1 and sum(n in cn for n,j in w)==1 and all(not j for n,j in w)
   assert all(xp>=0 and hp>=0 for(xp,hp,m),v in co)
 # Cartan L_h = D i_h + i_h D, with the actual odd-left ghost derivative.
 Hremainders=[]
 for h in range(12):
  iX={k:grad(p).get((cn[h],()),{}) for k,p in X.items()};iX={k:p for k,p in iX.items() if p}
  iDX={k:grad(p).get((cn[h],()),{}) for k,p in DX.items()};iDX={k:p for k,p in iDX.items() if p}
  Hremainders.append(la(dL(iX),iDX))
 # Plane-ghost coefficient diagnostics use the established real-plane convention.
 cg={cn[i]:add(*(mul(scalar(str(Rinv[i,j])),elem(cn[j])) for j in range(45) if Rinv[i,j])) for i in range(45)}
 Xmatrix=to_matrix(X);plane={ij:sub(p,cg) for ij,p in Xmatrix.items()}
 def conjugate(p):return {key:tuple((cell,v*(-1 if cell[2]&16 else 1)) for cell,v in c) for key,c in p.items()}
 dagger={(j,i):conjugate(p) for(i,j),p in plane.items()};reality=ma(plane,dagger)
 def pp(L):return [[k,pack(p)] for k,p in sorted(L.items())]
 out={'schema':'PROBE_MATTER_SOURCE_PRIMITIVE_V1','names':list(A.names),'B_parts':[pp(L) for L in Bparts],'X_parts':[pp(L) for L in Xparts],'X':pp(X),'D_X':pp(DX),'X_plane_matrix':[[i,j,pack(p)] for(i,j),p in sorted(plane.items())],'both_odd_extraction_routes_agree':True,'complete_primitive_image_matches_measured_probe_part':True,'each_independent_label_image_matches':True,'g10_order':3,'nonnegative_width_and_coupling_powers':True,'global_H_Cartan_remainder_positions':[sum(len(p) for p in L.values()) for L in Hremainders],'plane_coefficient_antiHermitian_remainder_positions':sum(len(p) for p in reality.values()),'source_primitive_positions':sum(len(p) for p in X.values()),'full_sourcefree_Euler_companions_constructed':False,'full_renormalized_contact_or_QAP_restoration':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
 raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with(O/'primitive_tables.json.gz').open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({**{k:v for k,v in out.items() if k not in ['names','B_parts','X_parts','X','D_X','X_plane_matrix']},'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
