# SMP1: an explicit finite Yukawa correction cancels the selected scalar remainder

Receipt SHA256
`0a7cf416cc8777095a9ec879193aad84d77c92a179e338ca8c3147ce0ba10737`:
QUALIFIED_SCALAR_MATTER_FINITE_YUKAWA_PRIMITIVE,
COMPLETE_SELECTED_SCALAR_REMAINDER_CANCELLED_WITH_SYMBOLIC_INVARIANT_ADDITIONS.
Scientific acceptance NOT_PERFORMED. State113/authority34of39 unchanged.

## From the independently measured remainder to a constructed correction

OSM1 measured all ordinary scalar profiles before comparing them with the
fixed MSP1 source primitive. That comparison left150272 nonzero positions
per chirality. SMC1 then qualified all990 necessary cocycle equations on
the full mass operator module. Those fixed results are the inputs here.
No quantum coefficient is inferred from cancellation and no quantum loop
is repeated. K below is a constructed counterterm,not another measured
quantum amplitude or a selected physical renormalization condition.

Let A_a(M)=i(Ta.T M+M Ta),D_a=ad(A_a),and let R_a be the full source-summed
ordinary scalar operator. Define

 h=sum_a D_a R_a, C=sum_a D_a^2.

Both independent methods derive the exact first Krylov relation

 (C^3+40 C^2+516 C+2160)h=0.

Its polynomial factors as(C+10)(C+12)(C+18). These are internal Casimir
constants in the actual module,not particle masses,couplings or fit
parameters. No representation labels are inferred merely from those roots.
The relation has nonzero constant coefficient,so the particular correction
is explicitly

 K=(C^2 h+40 C h+516 h)/2160.

The gate independently checks the polynomial relation and CK=-h. More
decisively,it verifies the ACTUAL required image

 [A_a,K]=-R_a

for every one of45 full256x256 mass operators,including every zero entry.
Both complete actual B10/B126 maps and their conjugates then cancel the
measured scalar remainder. This image test,rather than a generic
cohomology theorem or the Krylov relation alone,owns the positive result.
The degree-three relation is within the frozen bound24;no limit was raised.

The g10^2/(16pi2) source-free Yukawa correction uses deltaM=K(M). Its
classical variation supplies the required g10^3Y term. The fixed auxiliary
g10^2Y component already cancelled separately in ASB1. Thus the complete
24-profile scalar candidate catalogue now has a selected correction within
the same mass-independent,physical external-hats0,formal one-loop
Euclidean domain. No assertion about positive-dimension/massive limits,
complete finite Slavnov restoration or the chiral measure follows.

## Admissibility and remaining freedom

K is a local,derivative-free,ghost-zero,dimension-four Yukawa correction
with nonnegative polynomial widths. Only internal rational constants are
inverted. Physical masses,couplings,widths and vacuum coordinates are not
inverted or evaluated. All328 scalar directions and both general complex
symmetric family matrices are retained. No flavor point is chosen.

Every actual corrected mass map remains symmetric. Antiholomorphic K is
the checked conjugate,and all45 conjugate operator images cancel too.
All12 residual-H operator commutators vanish. Since no derivatives enter,
this is pointwise local-H compatibility in the declared field module.
Complex linearity preserves the qualified PQ charge of each B map;it does
not establish a quantum PQ identity or determinant phase prescription.

The particular K has896 nonzero mass-operator entries. Its holomorphic
physical maps contain320 B10 and4032 B126 coefficients. These are compact
factorized algebraic coordinates,not new particles or experimental tests.

Retain the illustrated homogeneous family

 deltaM=K(M)+u10 M10+u126 M126,

with the conjugate anti terms. The complex u10/u126 are not fixed to zero.
Their Ward images vanish by the qualified B rho=A B covariance. Their
disjoint nonzero scalar supports make the two displayed directions
independent. This is not a complete classification of invariant Yukawa,
family,source or normalization freedom. They are not identified with the
earlier z_psi/z_10/z_126,b0,kappa or bosonic zeta. The displayed particular
representative does not adopt a physical finite normalization.

K contains no sources,so the qualified highest KccP source image is
unchanged. At zero scalars its one-jet cPP image vanishes. Homogeneous
fermion/scalar transformations give no cBPP image from this monomial.
These are structural projection statements,not acceptance of the complete
coupled bosonic/matter source prescription. Future common assembly must
retain all source/Euler contributions exactly once;this calculation has
not applied a new physical counterterm to the canonical action.

## Distinct construction,controls and execution

Primary uses direct sparse superoperator Casimir actions and incremental
rational pivot elimination on full coefficient vectors. Replay uses
four-index actions and exact coordinate Gram systems with complete
residual tests. Its Gram product diagnoses linear independence,not a
physical inner product. Both match h,K,the relation,the complete Krylov
hash sequence,all images and all physical maps. The gate rederives them
from the fixed input. The coefficient basis retains radical,imaginary
and width slots independently,so no physical specialization enters a
division or rank decision.

Omitting K,reversing its sign or adding an extra Nambu half each leaves
8576 B10 and141696 B126 positions. These controls have the same support
because they rescale the same nonzero residual;they are not three
independent physical confirmations. The odd-left mass-density derivation
fixes both fermion endpoint signs and the inherited common1/2 separately
from the cancellation target.

All new workers completed native0 without failed or unfinished runs.
Primary/replay/gate runtimes34.1027119/42.0643940/36.6246181s;sample
counts18/22/19,private maxima70684672/66699264/78348288 bytes. These are
sampled maxima,not continuous peaks.600s/8GiB sampled/350MiB floor/16MiB
packet and degree24 bounds held. Eight source copies;200/208 bindings.

Primary packed/raw SHA256:
`430421cc0b28d907a5bbb1b32a8b8894a150bce7aa71f15548c1329633149c1a` /
`959350a3aaf0c35c505f66b49d13ece71841f130c91846f52d65b85721efe339`.
Replay packed/raw SHA256:
`314ef7112ea966900c1fe08372614baaf25a3fab69b338d6b35336adaf2e6977` /
`061a1fb2a6e124fb2e1f9f30c0a01727dc90608d6c2caa2ac379df0ed72fa657`.

Fresh byte preflight/native resources observed;earlier-this-goal ASB1 E4
readiness authenticated and reused,not newly executed here. Historical
custodyexit2/seven NOTPASS. Prior OSM1 timeouts/control correction and all
historical failed physical inputs remain unchanged.

## Significance and next justified calculation

The work has advanced through complete scalar quantum measurement,
nonzero fixed-source remainder,full cocycle test and explicit admissible
primitive. This closes the selected scalar correction problem,not all
one-loop chiral restoration. It also demonstrates a constructive use of
structural representation methods instead of a65536-variable generic
counterterm solve. Shared action,regulator,data,exact-ring/helper routines,
family conventions and AI authorship remain common-error limits. No
independent scientist,proof-kernel or experimental validation is claimed.

The next specific missing input is the42 degree-zero internal-ghost vector
profiles:30 ordinary g4 and12 auxiliary g3. CFC1 already retains their
counterterm/source images,but the corresponding quantum kernels remain
unmeasured. First reduce their actual complete MDS1 witness set into common
ordered sewing families,retaining GF quartics,auxiliary paths and full-D
vector numerators,before selecting integrals. The scalar coefficients
cannot be copied into that vector calculation merely because its topology
looks similar. Compare only independently derived kernels with the fixed
CFC1 images. Unknown bosonic/matter source Euler completions remain an
explicit coupled-prescription issue,not a license to fit missing loops.

Full QAP/products/measure/phase,physical chiral prescription,massive C1,
E5/A5 and physical unification remain unqualified. The two adverse scalar
benchmarks,quartetFAIL,flavor pause,HB1/C5 blocks and custody2/seven persist.
No foundation,benchmark,physical scheme or authority adopted. Preserve
main,state and historical bytes. No agents,branch/worktree,publication,
outreach or push. Whole investigation remains active/incomplete.
