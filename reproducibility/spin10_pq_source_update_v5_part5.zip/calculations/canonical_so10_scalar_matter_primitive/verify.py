"""SMP1 independent relation/image/admissibility gate."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h0 in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h0,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz')
for key in set(P)|set(R):
 if key not in ['role','method','elapsed_after_imports']:assert P[key]==R[key],key
assert P['relation_degree']==P['minimal_relation_rank'] and 1<=P['relation_degree']<=24 and P['casimir_inverse_divisors_are_internal_rational_constants']
assert not P['quantum_loops_rerun'] and not P['physical_scheme_adopted'] and P['counterterm_constructed_from_fixed_quantum_input']
T,BB,HF,fixed=inputs('replay');I=ident(16);A=[scale(plus(kron(trans(t),I),kron(I,trans(t))),II) for t in T]
def comm(a,m):return minus(mul(A[a],m),mul(m,A[a]))
def cas(m):
 out=Mat(256,256)
 for a in range(45):out=plus(out,comm(a,comm(a,m)))
 return out
h=Mat(256,256)
for a in range(45):h=plus(h,comm(a,fixed[a]))
zero(minus(h,dec(P['h'])));relation=list(map(F,P['relation']));assert relation[0] and relation[-1]==1
seq=[h]
for _ in range(P['relation_degree']):seq.append(cas(seq[-1]))
assert [sha256(json.dumps(enc(v),sort_keys=True).encode()).hexdigest() for v in seq]==P['krylov_hashes']
zero(combination(seq,relation));K=dec(P['K']);zero(minus(K,combination(seq[:-1],[v/relation[0] for v in relation[1:]])));zero(plus(cas(K),h))
checks=physical_checks(K,h,fixed,A,BB,HF,comm)
for key,v in checks.items():assert v==P[key],key
for a in range(45):zero(plus(minus(mul(star(A[a]),star(K)),mul(star(K),star(A[a]))),star(fixed[a])))
assert not P['invariant_parameters_fixed'] and not P['homogeneous_family_exhaustive'] and P['invariant_additions']==['u10*M10','u126*M126']
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_SCALAR_MATTER_FINITE_YUKAWA_PRIMITIVE','disposition':'COMPLETE_SELECTED_SCALAR_REMAINDER_CANCELLED_WITH_SYMBOLIC_INVARIANT_ADDITIONS','elapsed_after_imports':time.perf_counter()-start,'relation_degree':P['relation_degree'],'relation':P['relation'],'all45_full_operator_image_remainders':P['all45_full_operator_image_remainders'],'all12_H_operator_remainders':P['all12_H_operator_remainders'],'all45_antiholomorphic_operator_remainders':0,'physical_kernel_nonzero_counts':P['physical_kernel_nonzero_counts'],'controls':P['controls'],'invariant_additions':P['invariant_additions'],'invariant_parameters_fixed':False,'homogeneous_family_exhaustive':False,'widths_formal_and_nonnegative_polynomial':True,'inverse_physical_parameters_used':False,'counterterm_gauge_order':2,'breaking_gauge_order':3,'general_symmetric_families_retained':True,'highest_source_and_zero_scalar_onejet_preserved':True,'full_coupled_restoration_QAP_measure_phase_massiveC1_E5A5_or_unification_qualified':False,'quantum_loops_rerun':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
