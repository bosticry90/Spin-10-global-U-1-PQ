"""SMP1 direct Casimir action and sparse rational vector elimination."""
from data import *
start=begin('primary');T,BB,HF,R=inputs('primary');I=ident(16)
A=[scale(plus(kron(trans(t),I),kron(I,trans(t))),II) for t in T]
def comm(a,m):return minus(mul(A[a],m),mul(m,A[a]))
def cas(m):
 out=Mat(256,256)
 for a in range(45):out=plus(out,comm(a,comm(a,m)))
 return out
h=Mat(256,256)
for a in range(45):h=plus(h,comm(a,R[a]))
assert h.d
seq=[];basis=[];relation=None;v=h
for n in range(25):
 seq.append(v);d=flat(v);rep={n:F(1)}
 for pivot,b,br in basis:
  z=d.get(pivot,F(0))
  if z:d=axpy(d,b,-z);rep=axpy(rep,br,-z)
 if not d:
  relation=[rep.get(i,F(0)) for i in range(n+1)];break
 pivot=min(d);z=d[pivot];basis.append((pivot,{k:w/z for k,w in d.items()},{k:w/z for k,w in rep.items()}))
 if n==24:raise RuntimeError('INCOMPLETE_KRYLOV_DEGREE_BOUND:24')
 v=cas(v);print('STAGE DIRECT_KRYLOV_DEGREE',n+1,flush=True)
assert relation and relation[-1]==1 and relation[0]!=0,'INCOMPLETE_ZERO_CONSTANT_KRYLOV_RELATION'
zero(combination(seq,relation));degree=len(relation)-1
K=combination(seq[:-1],[v/relation[0] for v in relation[1:]])
zero(plus(cas(K),h));checks=physical_checks(K,h,R,A,BB,HF,comm)
finish('primary',dict(checks,method='direct_superoperator_Casimir_sparse_rational_pivots',h=enc(h),K=enc(K),relation=list(map(str,relation)),relation_degree=degree,krylov_hashes=[sha256(json.dumps(enc(v),sort_keys=True).encode()).hexdigest() for v in seq],minimal_relation_rank=degree,casimir_inverse_divisors_are_internal_rational_constants=True),start)
