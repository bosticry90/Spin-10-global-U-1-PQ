# SMP1: a constructive Casimir inverse with an independently checked image

Let D_a=ad(A_a),[D_a,D_b]=f_ab^c D_c. SMC1 fixes
D_a R_b-D_b R_a=f_ab^c R_c on the complete mass operator module. With the
invariant internal metric and antisymmetric f,commuting D_b through
h=sum_a D_a R_a gives D_b h=C R_b,C=sum_a D_a^2. Terms containing f
cancel in their two summed internal indices. This supplies a reason to
seek a C inverse,not permission to accept an untested formal primitive.

A finite Krylov relation p(C)h=0 with p(0)=c0 nonzero gives
K=sum_(j>=1)c_j C^(j-1)h/c0 and CK=-h. The construction admits only
rational constants c_j;the complete independent radical/imaginary/width
coordinates are used by both relation solvers. No width or coupling is
evaluated or inverted. Both minimal relation and final45 images are
checked directly,so generic anomaly/cohomology classification is not an
acceptance premise. A24-degree failure is bounded inconclusiveness.

For a source-free correction to the scalar mass polynomial,odd-left
variation of psi_i psi_j has both endpoint contributions with the same
sign after the ghost is moved left. Thus the alternating mass density
with its inherited1/2 varies through
g c^a(iL_a deltaM-deltaM rho_a). Qualified qx=-g c rho x fixes the scalar
slot independently. For deltaM=KB and B rho_a=A_a B,the kernel is
g c^a[A_a,K]B. The same common Nambu half is present on both sides;there
is no additional factor1/2 in the operator equation. Adding the g2/(16pi2)
correction therefore cancels the fixed g3Y remainder iff [A_a,K]=-R_a.

The conjugate construction uses Abar=conj(A),Kbar=conj(K),Rbar=conj(R).
Mass transpose symmetry,H covariance,PQ charge and locality are separate
admissibility checks. A derivative-free H intertwiner is pointwise local-H
compatible without moving a heat operator or claiming a general QAP.
The source-free field correction does not alter the highest-source
primitive,or the already selected one-jet image at zero scalars. New
higher-loop or physical normalization effects are not evaluated here.

For every actual carrier,adding a constant multiple of B has image0 by
B rho=A B. Hence the u10/u126 example remains a homogeneous family.
This illustrates allowed freedom;it does not fix physical Yukawa matrices
or exhaust possible invariant field/source counterterms.
