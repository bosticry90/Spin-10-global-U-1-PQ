"""SMP1 component Casimir action and positive coordinate Gram systems."""
from data import *
start=begin('replay');T,BB,HF,R=inputs('replay');td=[t.d for t in T];I=ident(16)
A=[scale(plus(kron(trans(t),I),kron(I,trans(t))),II) for t in T]
def comm(a,m):
 out={}
 def put(key,v):out[key]=add(out.get(key,Z),v)
 for (of,inf),z in m.d.items():
  i,j=divmod(of,16);k,l=divmod(inf,16)
  for w in range(16):
   for key,t,sign in [((w*16+j,inf),td[a].get((i,w),Z),1),((i*16+w,inf),td[a].get((j,w),Z),1),((of,w*16+l),td[a].get((w,k),Z),-1),((of,k*16+w),td[a].get((w,l),Z),-1)]:
    if t:
     v=prod(II,prod(t,z));put(key,v if sign==1 else neg(v))
 return Mat(256,256,out)
def cas(m):
 out=Mat(256,256)
 for a in reversed(range(45)):out=plus(out,comm(a,comm(a,m)))
 return out
def dot(a,b):return sum((v*b.get(k,F(0)) for k,v in a.items()),F(0))
def solve(g,b):
 n=len(b);a=[list(row)+[v] for row,v in zip(g,b)]
 for col in range(n):
  pivot=next(i for i in range(col,n) if a[i][col]);a[col],a[pivot]=a[pivot],a[col]
  z=a[col][col];a[col]=[v/z for v in a[col]]
  for i in range(n):
   if i!=col:
    z=a[i][col];a[i]=[v-z*w for v,w in zip(a[i],a[col])]
 return [row[-1] for row in a]
h=Mat(256,256)
for a in reversed(range(45)):h=plus(h,comm(a,R[a]))
assert h.d
seq=[];ff=[];relation=None;v=h
for n in range(25):
 seq.append(v);d=flat(v)
 if ff:
  gram=[[dot(x,y) for y in ff] for x in ff];beta=solve(gram,[dot(x,d) for x in ff]);res=dict(d)
  for co,x in zip(beta,ff):res=axpy(res,x,-co)
  if not res:relation=[-b for b in beta]+[F(1)];break
 ff.append(d)
 if n==24:raise RuntimeError('INCOMPLETE_KRYLOV_DEGREE_BOUND:24')
 v=cas(v);print('STAGE COMPONENT_GRAM_KRYLOV_DEGREE',n+1,flush=True)
assert relation and relation[0]!=0 and relation[-1]==1,'INCOMPLETE_ZERO_CONSTANT_KRYLOV_RELATION'
zero(combination(seq,relation));degree=len(relation)-1;K=combination(seq[:-1],[v/relation[0] for v in relation[1:]])
zero(plus(cas(K),h));checks=physical_checks(K,h,R,A,BB,HF,comm)
finish('replay',dict(checks,method='four_index_Casimir_exact_coordinate_Gram_systems',h=enc(h),K=enc(K),relation=list(map(str,relation)),relation_degree=degree,krylov_hashes=[sha256(json.dumps(enc(v),sort_keys=True).encode()).hexdigest() for v in seq],minimal_relation_rank=degree,casimir_inverse_divisors_are_internal_rational_constants=True),start)
