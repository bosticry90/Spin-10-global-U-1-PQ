"""SMP1 immutable IO and exact coefficient-coordinate utilities."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import defaultdict
import gzip,json,os,sys,time,threading
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
SMC=CAL/'canonical_so10_scalar_matter_cocycle';OSM=CAL/'canonical_so10_ordinary_scalar_matter_breaking'
sys.path.insert(0,str(OSM));from exact_ring_v4 import *
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def begin(role):
 start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
 assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and p.name.startswith(peer):raise PermissionError('SMP1_PEER_DENIED')
 sys.addaudithook(audit);return start
def inputs(role):
 y=packed(CAL/('canonical_so10_yukawa_carrier_transport/'+role+'_tables.json.gz'));T=list(map(dec,y['Tminus']));BB=[dec(y[k]) for k in ['B10','B126']];HF=dec(y['H_new'])
 r=packed(SMC/(role+'_tables.json.gz'));assert r['closed'] and r['scanned_pairs']==990 and all(v['unrestricted_operator_nonzero']==0 for v in r['pair_summaries'])
 return T,BB,HF,list(map(dec,r['fixed_R']))
def flat(m):return {(i,j,*k):v for (i,j),q in m.d.items() for k,v in q}
def axpy(d,b,k):
 out=dict(d)
 for key,v in b.items():
  z=out.get(key,F(0))+k*v
  if z:out[key]=z
  elif key in out:del out[key]
 return out
def combination(mm,co):
 out=Mat(256,256)
 for m,c in zip(mm,co):out=plus(out,scale(m,Q(str(c))))
 return out
def physical_checks(K,h,R,A,BB,HF,comm):
 full=[];maps=[];counts=[];controls={'omit_counterterm':[0,0],'reverse_counterterm':[0,0],'extra_Nambu_half':[0,0]}
 for a in range(45):
  image=comm(a,K);zero(plus(image,R[a]));full.append(0)
  for ri,b in enumerate(BB):
   rr=mul(R[a],b);zero(mul(plus(image,R[a]),b))
   controls['omit_counterterm'][ri]+=len(rr.d);controls['reverse_counterterm'][ri]+=len(scale(rr,Q(2)).d);controls['extra_Nambu_half'][ri]+=len(scale(rr,Q('1/2')).d)
 assert all(n for row in controls.values() for n in row)
 for b in BB:
  m=mul(K,b);zero(minus(m,rowtrans(m)));maps.append(enc(m));counts.append(len(m.d))
 hc=[]
 for u in range(12):
  z=Mat(256,256)
  for a in range(45):
   c=HF.d.get((a,u),Z)
   if c:z=plus(z,scale(comm(a,K),c))
  zero(z);hc.append(0)
 for q in K.d.values():assert all(k[0]>=0 and k[1]>=0 and k[0]+k[1]<=1 for k,v in q)
 assert all(b.d for b in BB) and not ({j for i,j in BB[0].d}&{j for i,j in BB[1].d})
 return {'all45_full_operator_image_remainders':full,'all12_H_operator_remainders':hc,'physical_holomorphic_maps':maps,'physical_antiholomorphic_maps':[enc(star(dec(m))) for m in maps],'physical_kernel_nonzero_counts':counts,'controls':controls,'invariant_additions':['u10*M10','u126*M126'],'invariant_parameters_fixed':False,'homogeneous_family_exhaustive':False,'highest_source_and_zero_scalar_onejet_preserved':True,'complex_linear_PQ_charge_preserved_from_YCT':True,'ordinary_width_degree_at_most_one':True}
def finish(role,d,start):
 d.update({'role':role,'elapsed_after_imports':time.perf_counter()-start,'authority':'34/39','scientific_acceptance':'NOT_PERFORMED','quantum_loops_rerun':False,'counterterm_constructed_from_fixed_quantum_input':True,'physical_scheme_adopted':False})
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':d['elapsed_after_imports'],'relation_degree':d['relation_degree'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
