# SMP1: construct an admissible primitive of the measured scalar remainder

Base184cd5cb6b425e315f29de71e13d2d80be093f08/main31710 old tracked blobs.
Goal ACTIVE/incomplete;current goal-turn progress ASB1/OSM1/SMC1. State113,
authority34of39 unchanged. Live AGENTS standing delegation applies.

Question: does the fixed,complete,nonzero OSM1 scalar remainder admit an
explicit source-free finite Yukawa correction in the tested local module?
SMC1 independently qualified all990 cocycles,including unrestricted mass
operators. That necessary result justifies this constructive test; it is
not itself a counterterm or a physical scheme. No quantum loop is rerun.

Inputs: SMC1 paired R operators/receipt cd30b631...,OSM1 final scalar
receipt529cd63e...,actual YCT paired generators,H_new,B10/B126,SMA1 action,
qualified Lie/covariance,MSP source primitive and CFC selected one-jet/source
results through their bound chain. Keep all45 ghosts,328 scalars,both
chiralities,general symmetric family matrices,formal eta_H/xi and g orders.
No physical flavor,vacuum,mass,width,scale or finite baseline is selected.

For A_a=iL(Ta),D_a=ad(A_a),form h=sum_a D_a R_a and C=sum_a D_a^2 on
mass endomorphisms. Find the first exact rational-coefficient Krylov relation
sum_j c_j C^j h=0,monic at highest degree. Bound the search at24 applications;
failure to close is INCOMPLETE_KRYLOV_DEGREE_BOUND,not a theorem of absence.
If c0 is nonzero,define K=sum_(j>=1)(c_j/c0) C^(j-1) h. Then CK=-h.
DIRECTLY require [A_a,K]=-R_a for all45 complete operators and actual maps.
The relation alone is insufficient. Any zero c0 or image failure is
preserved as a failed/inconclusive construction,not an anomaly verdict.

Primary uses direct sparse superoperator actions and incremental rational
pivot elimination on complete flattened coefficient vectors. Replay uses
independent four-index actions and exact Gram-system solves/residuals to
detect the relation. The Gram product is only an exact coordinate-space
linear-independence tool,not a physical inner product. Expand all algebraic
radical and width monomials as independent rational coordinates,so no
physical parameter can enter a divisor. Polynomial relation coefficients
are internal constants. Both routes keep complete h,K,relation and maps.

Expected evidence: exact h/K/relation agreement;independent gate rederives
the relation and CK=-h;all45 images vanish against fixed R including zeros;
both complete physical Yukawa maps have symmetric mass matrices and their
conjugates;all12 H actions commute with K. K is complex-linear on M,so
qualified B QPQ=-2iB implies identical PQ charge for KB. Its width powers
must be nonnegative and coupling degree is g2:ordinary q adds the required
g factor,without admitting inverse g,mass,width or vacuum inputs. No new
derivatives,backgrounds,hatted fields,physical particles or sources enter.

Keep illustrative invariant additions u10 M10+u126 M126 (with conjugate
anti part) symbolic. They have zero Ward image by qualified YCT covariance.
They are not an exhaustive ambiguity classification,not fixed zero and
not identified with z_psi/z_10/z_126,b0,kappa or bosonic zeta. The displayed
particular K is a representative,not a physical finite normalization.

Controls: omit/reverse K or insert an extra Nambu half;actual nonzero R
must remain visible on both scalar carriers. Direct generic mass-density
variation fixes D_a K using the inherited odd-left/source conventions;
do not infer it solely from the desired cancellation. Source-free K has
no highest KccP image;at x0 its cPP one-jet image is0,with no cBPP image
because the homogeneous field transformations contain neither B nor
derivatives in this monomial. This structural projection statement does
not complete every coupled source/Euler or quantum normalization condition.

Freeze eight sources/copies,all exact inputs and caps before computation.
Sequential primary/replay/gate,each600s afterimports,8GiB sampled private
cap,350MiB available-commit floor,16MiB total packet;Krylov degree24.
Stop first failure,preserve full sources/captures,no silent expansion or
coefficient truncation. Fresh byte preflight;earlier-this-goal ASB1 E4 is
authenticated reuse,not fresh science. Custodyexit2/seven remains NOTPASS.

Possible positive result: a fully checked selected scalar primitive and
displayed compatible ambiguity family. This is counterterm construction
from measured quantum input,not independent measurement of K. Negative or
resource outcomes restrict this construction only. Full finite Slavnov,
QAP,products,measure/phase,physical chiral prescription,massiveC1,E5/A5 and
unification remain unqualified. Other42 vector profiles/positive-dimension
sectors stay separate. Preserve both adverse scalar points,quartetFAIL,
flavor pause,HB1/C5 blocks,state and historical evidence. No agents,branch/
worktree,physical scheme/benchmark/foundation adoption,publication or push.
