# Actual polarized quantum contacts: a selected zero family and a nonzero extension

The first quantum pair calculation from SPM's linear augmented action is now
complete in its declared highest-source local sector. The actual Ksrc carrier
polarizations have zero contact there. A separate physical-carrier pair is
nonzero and has an explicitly matched Euclidean free-bubble extension. Its
fixed vector contact cannot be hidden in one common scalar normalization.

These results concern independently labelled external insertions. They do not
establish the full connected products, second-probe Ward identity, measure,
QAP, E5/A5 or physical viability. State113 and authority34of39 remain unchanged.

## The selected actual family is zero, without forcing the answer

The authenticated70-term pre-U Ksrc seed splits into14 light JL*Ja terms,
33 heavy JL*Ja terms,23 light JL*JL*C terms and zero heavy JL*JL*C terms.
After full source/field transport their physical polynomials have1344,4560,
144,0 coupling-resolved positions. These components are polarization carriers,
not separately adopted invariant counterterms. Their sum is the old actual
generator; there is no new choice of physical coefficients.

For all six distinct pairs, the complete rho_r*rho_s*JL_i*JL_j local contact
is zero across all990 exterior source positions. The zero component makes
three pairs structural zero-component cases. The other three were calculated.
The bubble, triangle, box and first dimension jet EACH give zero in these
selected polarizations. This is not merely a cancellation of their UV sum.

The triangle and box terms were still required in the calculation. Ordinary
H_G has source degree0 and1; the old action's JL*C*Lambda vertex also changes
the propagator. Primary ordered-log words and replay of the source-dressed
inverse G-GVG+GVGVG include every relevant order. The loop coefficients were
not set from the desired zero, and all zero complements remain explicit.

Because these particular graphs vanish, omitting their heat-length differences
or dimension jets is an INSENSITIVE control on this family. No universal G2
zero is inferred. No claim is made that its nonlocal/UV-convergent or lower-
source products vanish. The earlier nonzero DSF source contact is a different
operator/domain and is unaffected.

## A physical-carrier pair supplies a sensitive nonzero result

To test whether the machinery could detect a nonzero contact, V3 froze two
specific pre-U operators in the actual orthonormal physical SOURCE chart:

    G_A0=JL13*Ja13,          G_B0=JL14*Ja13.

The inverse SOURCE frame, actual raw U and forward physical chart are all
retained and round-trip checked. Each is an allowed component of the classified
carrier family. They are not individually claimed invariant counterterms or
new physical action terms. Independent odd local probes rho4,rho5 retain their
own labels; neither is replaced by the other before differentiation.

Across the full990-position exterior source domain, one field word is nonzero:

    W=rho4*rho5*JL13*JL14.

In the declared Euclidean one-loop16pi^2 density units, its bubble residue is

    T = -(8/5)*(eta_H*g10^2*xi + 3*g10^2 + 3*xi^2).

It has two coupling orders, including an actual g10^0*xi^2 term. No assumed
g10 counting is imposed on that term. The triangle and box LOCAL tensors are
again zero. Their full convergent kernels are not declared zero.

The actual vector and ordered-ghost contractions independently give

    A  = -(8/5)*g10^2,
    AW = -(8/5)*eta_H*xi*g10^2,
    F  =  (12/5)*xi^2,
    Z  = -(8/5)*g10^2*(1-eta_H)*(1-xi),
    T  = 3*A+AW-2*F.

A equals d_D T(D)|4, freshly checked by adding one transverse vector component
to the complete ordered calculation. Z retains both physical width factors.
The fixed dimension contact is therefore

    -2*A = +(16/5)*g10^2.

This nonzero result is a genuine coefficient of a specified action-derived
carrier insertion, as well as a sensitivity test. It is not a measured new
particle effect or an adopted finite physical normalization.

## An actual Euclidean free-kernel extension follows

The source-linear quadratic insertions have the full BB-metric and ordered
C-a shapes required by the already qualified dimension2 composite bubble.
Their effective probes rho4*JL13 and rho5*JL14 are even and dimension2.
The old scalar/projector integral and distributional extension are reused,
not counted as another independently evaluated integral. For p_E^2>0 the
same prescribed extension gives the coefficient of W:

    K_free,R(p) = T*[log(mu^2/p_E^2)+1-gamma_E-2*log2+kappa]
                    +(12/5)*g10^2*(1-eta_H)*(1-xi)
                    +(16/5)*g10^2.

The second line is the finite vector projector term; the last is the dimension
jet. Both are required by the fixed lift. Kappa remains free. It is not set
equal to b0,chi4 or the fixed IR normalization.

This is the free principal two-vertex kernel. The COMPLETE specified product
is K_free,R+U, where U is the remaining convergent ordered mass/reference/
source-inverse contribution. U has not been extracted and is not zero by
assumption. Local Schwartz labels and the inherited joint UV-then-IR ordering
are retained. There is no exceptional constant-probe or arbitrary diagonal
pullback, Lorentzian/causal or physical-vacuum claim.

The full highest-source LOCAL finite comparison is separately fixed:

    C_rel = [chi4*T +(16/5)*g10^2]*W/(16pi^2).

The general heat lengths4,6,8 give relative shifts chi4,chi4+log(3/2),
chi4+log2. The measured triangle/box zeros remove the latter two here;
they were not assigned a common heat length. The vector projector term is
shared by both prescriptions and cancels from this relative comparison.

No constant shift of a common finite normalization absorbs the dimension
offset over the polynomial parameter domain. The coefficient minor of T
and -2A on xi^2 and g10^2 is -384/25, hence rank2. This is a finite mixing
fact, not an anomaly or incompatibility finding: other admissible correlated
normalizations remain to be examined. No parameter or finite constant was fit.

## What the verification actually covers

Each native route derives the field/source chart and Wick vertices separately.
Primary expands the ordered logarithm; replay differentiates the source-dressed
inverse. They use different exact unit momentum orientations. The full Lorentz
tensor shapes are checked before rotational invariance replaces angular
integration; the closed D trace is retained explicitly.

A mixed finite boson/ghost Gaussian fixes a subtle orientation: an even
action's Frechet Hessian is

    K_ij=(-1)^[p_j*(p_i+1)] partial_left,j partial_left,i S.

Omitting that row/column conversion changes the Gaussian answer. The actual
gauge/auxiliary/ghost quadratic density also reproduces its full two-sided
principal inverse. Ordinary even-even/odd-odd checks alone would not detect
the mixed-block mistake.

The separate verifier imports no new native module. It uses independent
expanded-Fraction/right-gradient arithmetic, freshly differentiates the full
physical primitives/source action, recomputes ALL group coefficients and
zero complements, adds the fifth transverse component, and derives the three
radial finite differences. It does not reconstruct the raw-to-physical frame
a third time; that uses agreement of the two native constructions and the
qualified frame premises. V4 additionally uses independent expanded SymPy
and explicit exterior-sign/odd-inverse contractions for A,AW,Z,F and rank2.

One verifier execution failed after vertex checks because a new function
shadowed the old coefficient parser. Its exact source, full capture and
controller failure remain. V2 only renamed that helper and reused completed
native results. No original receipt was manufactured. There were no failed
native scientific workers, no discarded tensors and no cap expansion.

Native P/R times26.5085541/37.0157109s; V2 verifier54.0791586s. V3 P/R times
21.5906642/15.0979097s; verifier48.4802707s. V4 assessment1.1560307s. Private
memory samples14/19/28/12/8/25/2 have maxima499712000/521789440/207310848/
487948288/485773312/205262848/179462144bytes. The failed verifier has26
samples/max204947456bytes. These are sampled observations, not true peaks.
All600s/8GiB/350MiB-floor/16MiB limits held. The pre-report packet816285bytes,
20 exact source snapshots and50/58/69/84/92/101 bound-input counts remain.

V2 receipt SHA256:
4c9567698e95ff4d2a2523d337fe5892edd491bacf7731d7cdd319529ee7c4b0.
V3 receipt:
625cfb97c8d494ea49980a717cf1b6235e92644f14cc581a81b6cb813507969f.
V4 extension receipt:
ddf66f762d29bc5485e0b5837d867c409ecbeaa7cb9e95128de79e19009801e4.
All full native arrays, source/frame bridges and controller captures remain.

Shared action, reference, E2/SPM/NDPC analytic premises, software/arithmetic
and AI authorship limit independence. This is internal mathematical evidence,
not an outside scientist's, proof assistant's or experimental endorsement.
No change is made to the ordinary canonical functional at rho0: these are
external-probe products, not additional physical coefficients to append twice.

## Next scientific action and preserved limits

Complete the remaining local rho^2 contact types for the ACTUAL generator
family before claiming its common quantum Ward construction. Power counting
suggests the dimension2/ghost-2 coefficient carriers JC,JL*JL,JL*a,a*a;
verify that census against the actual grades first. This turn completes the
JL*JL highest-source projection only. Source/ordinary companions must be
derived from the same functional, including the source-JC and antighost
background Hessians, with local labels and connected products retained.

Keep the complete quantum breaking B1 explicit. The free extension alone
does not prove B1=0 or all lower-source contacts, remove a chiral phase, define
arbitrary products or establish quantum equivalence. Earlier generic w/h
transport needs its full extension; no frozen orbit is transferred unchanged.
Massive fermionic C1, full physical limits and viability remain open.

External before/index/after seals authenticate all34140 prior tracked blobs,
old failures, current E4 and the final commit/clean state. Custody remains
exit2/seven NOTPASS, never overall PASS. No project_state, physical scheme,
benchmark, foundation, old evidence or flavor/HB1/C5 boundary changed. No
push/publication/outreach. The Spin10 x PQ investigation stays active/incomplete.
