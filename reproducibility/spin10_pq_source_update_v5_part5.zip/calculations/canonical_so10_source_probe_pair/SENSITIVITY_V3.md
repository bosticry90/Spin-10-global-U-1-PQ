# A nonzero physical-carrier polarization, without changing the measured zeros

The actual Ksrc decomposition gives three nonzero seed components and one
zero component. Both native routes find every selected highest-source graph
group zero. Preserve that result. Before treating those zeros as meaningful,
test a different, explicitly specified carrier pair for which the actual
quadratic gauge-fixing operator has a nonzero vector norm.

In the inherited orthonormal physical PRE-U chart take

    G_A0=JL_13 Ja_13,       G_B0=JL_14 Ja_13.

Map these seeds BACK with the correct inverse SOURCE frame, then apply the
actual raw U and return to the physical chart. Using the field frame on the
sources is forbidden. These are members of the classified JL*Ja carrier
family; individual components are not asserted invariant counterterms.
Their local probes carry the dual carrier transformation when needed. No
physical coupling, action, invariant tensor, vacuum or scheme is adopted.

They share the real physical nonlinear F_13=UJa_13-Ja_13, while carrying
different remaining odd sources. Its complete vector Hessian norm predicts
a nonzero transverse dimension jet in the bubble. This is a predeclared
sensitive test, not a demand that the complete contact or pole be nonzero.
The triangle/box source-inverse contributions must still be derived, and
may cancel some coefficients. If the norm prediction fails, preserve that
failure and inspect the frame/type premise; do not choose new indices until
a nonzero result appears.

Compute the ENTIRE selected highest-source pair over all990 JL exterior
positions, at heat lengths4,6,8 and with the same dimension jet. Add two
independent odd probes rho4,rho5; the prior four primitives and their measured
zero tables remain unchanged and are reused, not recomputed. Native V3
reconstructs the primitive vertices but computes only this one new pair.
The full raw/physical round trip of both seeds must be checked.

Same600s/8GiB/350MiB/16MiB limits per worker and verifier. Same full graded
Frechet, finite Gaussian, free inverse, independent orientations, two ordered
methods, complete expanded verifier contractions and fifth-component test.
Freeze this contract and all V3 sources before execution. The two original
native tables, failed verifier, corrected V2 validation and all original
sources/captures remain immutable. No broad G2 quantum/QAP/E5 promotion.

This is both a real carrier-component quantum coefficient and a necessary
sensitivity control for the preceding selected zero result. It does not
replace that actual-family result, nor prove simultaneous Ward normalization
of these contacts. The remaining source-linear/ordinary companions and full
nonlocal products still require their own calculation.
