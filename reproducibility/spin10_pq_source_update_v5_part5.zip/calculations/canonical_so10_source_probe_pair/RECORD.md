# Polarized two-source primitive pair: highest-source local quantum kernel SPP1

Base cc50abdf49c291deb5cd3135f83c0367cdc638dd/main; previous goal turn PROGRESS.
Use current AGENTS, State113/34of39 unchanged, custody exit2/seven NOTPASS.

Question: what is the ACTUAL highest-source local one-loop comparison for
two independently labelled odd primitive insertions from the previously
qualified Ksrc? SPM proves the classical augmented action is linear in probes;
it does not evaluate its quantum pair kernel. This calculation must include
source-dependent inverse propagators, rather than only the obvious bubble.

Freeze the four carrier projections of Ksrc's authenticated70-term pre-U
seed: JL*Ja versus JL*JL*C, each on the light or heavy source block. Zero
projections remain zero. Their sum is the old actual generator. These are
polarized carrier components, not separately adopted invariant counterterms.
Independent odd rho labels have project dimension1,ghost1; Wick pullback of
rho is identity. Use all six distinct pairs and all990 exterior JL pairs.
Self pairs are retained as zero-local-contact controls. No arbitrary M,N
tensor coefficient table or full Ward restoration is claimed.

At rho^2 JL^2 the dimension4 local parent is saturated: no ordinary field,
external derivative, mass/positive-dimensional coefficient, scalar-vacuum
or extra source may occur. Consequently the actual zero-field principal
gauge/auxiliary/ghost Hessians suffice. This is a UV-symbol calculation, NOT
an exceptional-momentum definition of the complete amplitude. Source-linear
JC or JL*a and source-free a*a contacts remain separate obligations.

Include bubble, triangle and box terms. H_G has source degree0 and1; the
old action supplies the source-degree1 C-Lambda Hessian V. The source-dressed
inverse G_J=G-GVG+GVGVG must be expanded consistently through JL degree2.
All derivatives and field/source frame duals are derived before projection.
The old physical action is auxiliary/antighost independent; no physical Euler
program is put on shell. Scalar orbit pieces are positive-dimensional here,
not silently transferred unchanged to generic w/h. No fermion cycle can
contain one of these actual nonminimal insertion Hessians at this target.

Primary reconstructs U(seed), then the full physical field/source chart and
the Wick action. Replay composes these maps in reverse construction order,
using its own E2/reference artifacts. Primary sums ordered logarithm words;
replay differentiates the source-dressed inverse. They use different unit
momentum orientations. Check actual Lorentz tensor forms before reducing
angular integration by rotational invariance. A closed vector dimension jet
is retained; no numerical4 trace is promoted to D dimensions by assertion.

The Hessian must be a Frechet map, not an untyped left-left bilinear. Freeze
K_ij=(-1)^[p_j(p_i+1)] leftpartial_j leftpartial_i S for an even density,
with Fourier adjoints on differentiated slots. A finite mixed even/odd Gaussian
check and the actual free two-sided inverse must verify this orientation.

Every Green edge carries exp(-2tQ); lengths4,6,8 stay distinct. Derive each
radial finite comparison and the first angular dimension jet. Retain chi4,
kappa,b0 and IR constants as distinct free quantities. Never set an unknown
quantum coefficient from a desired cancellation; a zero total is acceptable
only after all actual ordered families are calculated.

Two sequential native routes,600s after imports,8GiB sampled private limit,
350MiB available-commit floor; separate600s verifier, same memory/floor.
Packet16MiB. Freeze sources, inputs, evidence expectations and caps before
launch. Preserve all failed/incomplete sources and full captures; no silent
truncation, cap expansion or old evidence changes. Verifier uses independent
expanded arithmetic for the complete frozen principal-vertex contractions;
the two natives reconstruct those vertices independently. Shared action,
frames, analytic UV/IR comparison proof, software and AI authorship remain.

Success is a qualified highest-source local quantum comparison of this FULL
four-component actual polarization family, with zero complements, normalization
and sensitive controls. It is not the entire G2 module's coefficient tensor,
nonlocal kernel, all renormalized products, full QAP/measure, E5/A5, physical
vacuum, Lorentzian/causal/global limits or physical unification. No physical
scheme, benchmark, foundation/state/authority change, flavor/HB1/C5 activation,
branch/worktree, push, publication or outreach. Continue from the measured
result to its necessary correlated source/contact descendants.
