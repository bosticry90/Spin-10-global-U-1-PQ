# Prospective ordered local pair calculation

Let G_r be the four carrier projections specified in RECORD and use
S_ext=S+sum_r rho_r G_r at u=0 in SPM's complete linear augmented action.
The classical second vertex is zero. Sources and rho are external Schwartz
functions; the calculation differentiates the same augmented determinant,
not a product of separate expectation values or an arbitrary diagonal pullback.

At ordinary fields0 the principal Hessian is

 H=H0+V_J+sum_r A_r,       A_r=H_(rho_r G_r).

Discarding external derivatives is ONLY a Taylor projection of this saturated
UV-local symbol. Positive-dimensional mass/orbit pieces are UV subleading.
A_r has JL degree0 or1; V_J has degree1 and comes from the actual JL*qLambda
action term. The complete rho_r rho_s JL^2 coefficient is obtained from

 sum_(n=2..4) [(-1)^(n+1)/(2n)] STr[(G(V_J+A_r+A_s))^n].

Only words with one A_r, one A_s and n-2 V_J survive. Retain all orders and
Grassmann signs. This defines tensors T2,T3,T4 in16pi^2 local residue units.
The independent inverse derivative gives exactly the same groups from
-STr(G_J A_r G_J A_s)/2, G_J=G-GVG+GVGVG. Each n has heat length2n.
Finite internal matrix cyclicity may organize words of the same length;
it is not bare infinite-dimensional finite-part trace cyclicity.

The physical chart is the actual643-field inverse congruence with its source
dual. Wick: B0_M=i B0_E, Lambda_M=-i Lambda_E, JL_M=-i JL_E,
Ja_M=-Ja_E; C,a and rho unchanged; time derivatives acquire i and
S_E=-S_M after pullback. These rules reproduce the inherited Euclidean
principal inverse: G_BB=delta+(w-1)nn, G_BL=-n, G_LB=n,
G_Ca=1,G_aC=-1 on n^2=1. The actual free quadratic density must reproduce
this inverse before any new color coefficient is evaluated.

For an even density the left-left second derivative has its coefficient
to the RIGHT of a varied coordinate. Moving it to the left gives the
Frechet map K_ij=(-1)^[p_j(p_i+1)] partial_left,j partial_left,i S.
Jet slots supply (-iq)^I(iq)^J. This distinction is invisible on the
free even-even and odd-odd blocks, but matters on new mixed blocks.

Every principal vertex is a Lorentz scalar: BB metric, C-a scalar,
a-Lambda scalar, or a-divB derivative. Check these full tensor shapes.
Then the zero-external-jet traced symbol depends only on q^2. Evaluate
at two different exact unit orientations in the distinct routes.
Only the pure BB bubble contains a closed free Lorentz trace. Its extra
transverse component supplies d_D T2|4; mixed triangle/box paths contract
their vector indices with q and have no closed D trace. Check with a
one-extra-transverse-component construction, not a guessed factor4/D.

For the common positive auxiliary IR comparator m2 (not a physical mass),
the scalar radial n-edge representatives have numerator(q^2)^(n-2):

 D_n=(4pi)^eps*(m2)^(-eps)*Gamma(eps)*Gamma(n-eps)
                                      /[Gamma(2-eps)*Gamma(n)],
 H_n,FP=-gamma-log(2n)-log(m2)-Harmonic(n-1)+n_log.

Thus D_n,FP-H_n,FP=chi4+log(n/2), chi4=1+log(16pi)-n_log.
This is checked for n2,3,4 without choosing chi4. In D=4-2eps the first
dimension jet also contributes -2*d_D T2|4. The complete candidate local
comparison in these conventions is

 C_rel=chi4*(T2+T3+T4)+log(3/2)*T3+log2*T4-2*d_D T2|4.

The target contains four odd external factors rho_r,rho_s,JL_i,JL_j.
All interchanges and identical repetitions obey the exterior algebra.
Do not infer zero from setting all rho equal BEFORE polarized differentiation.
Do not adjust a tensor to make the common chi4 term cancel.

The old relative-symbol remainder proof and joint labelled-node IR completion
apply only to the stated local comparison: UV finite part precedes the
prescribed joint IR limit. No exceptional source/test transfer is pulled
back. Remaining convergent/nonlocal terms of the pair kernel are retained
as unextracted operator remainders; this local calculation does not set them
to zero or prove the full second-probe Ward equation B1=0. Reference and
measure/heat responses for that later equation remain explicit.
