from pathlib import Path
O=Path(__file__).resolve().parent
def write(n,t):
 with (O/n).open('x',encoding='utf-8',newline='\n') as f:f.write(t)
t=(O/'pair.py').read_text(encoding='utf-8')
t=t.replace("read(O/'preparation.json')","read(O/'preparation_v3.json')")
t=t.replace("geo['names']+['spp_rho'+str(i) for i in range(4)],geo['parities']+[1]*4","geo['names']+['spp_rho'+str(i) for i in range(6)],geo['parities']+[1]*6")
t=t.replace("rho=[A.index['spp_rho'+str(i)] for i in range(4)]","rho=[A.index['spp_rho'+str(i)] for i in range(6)]")
t=t.replace("role+'_tables.json.gz'","role+'_sensitivity_v3_tables.json.gz'")
needle=' assert add(*parts)==seed\n'
insert=''' assert add(*parts)==seed
 backsource={}
 for i,pname in enumerate(phys):
  backsource[Jof[A.index[pname]]]=add(*(mul(z,elem(Jof[A.index[order[j]]])) for (j,col),z in Ti.items() if col==i))
 fixtures=[mul(elem(jl[13]),elem(ja[13])),mul(elem(jl[14]),elem(ja[13]))]
 for p in fixtures:
  rawseed=sub(p,backsource);assert sub(rawseed,frame)==p,'PHYSICAL_SOURCE_SEED_ROUNDTRIP'
  assert all(n in jset|set(ja) and not j for g,w in rawseed for n,j in w)
  parts.append(rawseed)
 labels+=['physical_JL13_Ja13','physical_JL14_Ja13']
'''
assert needle in t;t=t.replace(needle,insert)
t=t.replace('for r,s in combinations(range(4),2):','for r,s in [(4,5)]:')
t=t.replace("'complete_polarized_pairs':6","'complete_polarized_pairs':1")
t=t.replace(" allvals=[unpack(p) for d in result.values() for p in d.values()]"," assert any(unpack(d['Djet']) for d in result.values()),'PHYSICAL_SHARED_NONLINEAR_F_CARRIER_UNEXPECTED_ZERO'\n allvals=[unpack(p) for d in result.values() for p in d.values()]")
write('pair_v3.py',t)
t=(O/'verify_v2.py').read_text(encoding='utf-8')
t=t.replace('validation_preparation_v2.json','validation_preparation_v3.json').replace('primary_tables.json.gz','primary_sensitivity_v3_tables.json.gz').replace('replay_tables.json.gz','replay_sensitivity_v3_tables.json.gz').replace("role+'_capture.json'","role+'_sensitivity_v3_capture.json'")
t=t.replace("names=geo['names']+['spp_rho'+str(i) for i in range(4)];par=geo['parities']+[1]*4","names=geo['names']+['spp_rho'+str(i) for i in range(6)];par=geo['parities']+[1]*6")
t=t.replace("rho=[index['spp_rho'+str(i)] for i in range(4)]","rho=[index['spp_rho'+str(i)] for i in range(6)]")
t=t.replace('for r,t in combinations(range(4),2):','for r,t in [(4,5)]:').replace('for z in range(4):','for z in range(6):').replace("'complete_pairs':6","'complete_pairs':1")
t=t.replace("'QUALIFIED_COMPLETE_HIGHEST_SOURCE_LOCAL_PAIR_COMPARISON_OF_ACTUAL_FOUR_COMPONENT_POLARIZATION_FAMILY'","'QUALIFIED_COMPLETE_HIGHEST_SOURCE_LOCAL_COMPARISON_OF_PHYSICAL_SHARED_F13_CARRIER_PAIR'")
t=t.replace("receipt={'schema'","assert nonzero['4,5']['Djet']>0\nreceipt={'schema'")
write('verify_v3.py',t)
print('BUILT_SPP1_SENSITIVITY_V3')
