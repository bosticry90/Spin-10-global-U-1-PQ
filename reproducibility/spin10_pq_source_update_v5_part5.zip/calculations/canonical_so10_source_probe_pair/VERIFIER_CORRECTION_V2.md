# Verifier name collision; completed native calculations are reused

Both native routes completed. Each selected contact group was zero. The
verifier reconstructed the full physical vertices and began its first pair,
then failed because its new pair-contraction function was named coefficients,
shadowing the inherited scalar-coefficient parser. The exact failed source,
full capture and controller failure remain. No original validation receipt.

V2 renames ONLY that pair-contraction helper. Same independent arithmetic,
all six pairs/990 source slots, extra transverse component, radial and mixed
Gaussian requirements,600s/8GiB/350MiB/16MiB caps. Completed native results
are authenticated/reused without rerun. No zero tensor is changed or labeled
a scientific failure because a nonzero result was anticipated.

The four actual seed components have14,33,23,0 terms. Thus N_heavy is a
genuine zero component; its three pairs are structural zero-component cases.
The other three polarized contacts are tested, not inferred from rho squared.
Their individual zero graphs make several omission controls insensitive;
this is disclosed. A separate frozen physical-carrier calculation is needed
as a sensitive nonzero test of the pair machinery before broader interpretation.
