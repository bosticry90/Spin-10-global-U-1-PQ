# Construct the measured free bubble extension, retaining the complete remainder

Both V3 native routes and their separate verifier completed. The physical
JL13*Ja13 versus JL14*Ja13 polarization has one nonzero JL exterior word.
The bubble T has two coupling orders; the dimension jet A has one. Its
triangle and box LOCAL symbols are zero. No conclusion that their full
convergent/nonlocal kernels vanish follows.

Next bounded calculation: reconstruct the actual BB and ordered C-a traces
of the TWO ALREADY QUALIFIED principal insertion vertices. Do not rerun the
old primitives, frames or ordered loop groups. Retain the existing physical
widths and compute A,AW,Z,F from these vertices by two arithmetic methods.
Check T=3A+AW-2F against the full V3 measured T and A against its independently
qualified fifth-component jet. Use Z with both(1-W) factors, not an averaged
width. The measured coefficient is not an input assigning A,Z or F.

These actual scalar quadratic composites have the exact operator types of
the qualified NDPC dimension2 composite bubble. Their even effective probes
are rho4*JL13 and rho5*JL14 (with the already fixed Wick phases). Therefore
the SAME Euclidean nonzero-momentum free-bubble extension is

 K_free,R(p)=T[log(mu^2/p_E^2)+1-gamma_E-2log2+kappa]-3Z/2-2A,

in the current16pi^2 density units and canonical rho4*rho5*JL13*JL14 order.
This is the free principal two-vertex kernel ONLY. The complete specified
pair has a separate convergent ordered remainder U(p), including the full
mass/reference/source-inverse terms. Preserve U, not zero. The full second
Ward equation and lower-source contacts are not established by this extension.

The scalar bubble distribution and projector ratio J_D/I_D were already
qualified in NDPC. Authenticate/reuse that universal integral result; do not
count this as another independent integral evaluation. Check its actual
applicability through complete BB/C-a Hessian shapes and the measured A,Z,F.
Independent rho/source functions remain Schwartz labels; p_E^2>0 is the
declared free kernel domain. No constant-probe or arbitrary diagonal limit.

The native extraction uses exact sparse coefficient cells. Separate expanded
SymPy arithmetic independently contracts the complete measured vertex arrays,
reconstructs A,AW,Z,F and the fixed finite offset, and tests whether a CONSTANT
change of the common normalization can absorb it as a polynomial identity.
No result is fitted to a desired Ward cancellation; kappa,b0,chi4,IR constants
remain distinct and unfixed. A nonproportional finite term is not an anomaly.

Same600s/8GiB/350MiB floor/16MiB packet limits. Freeze this record and V4
sources/inputs before execution; preserve all earlier failures and complete
V2/V3 results. Scope is this measured scalar free-kernel extension, not all
G2 operators, full contact mixing, QAP, measure, E5/A5 or physical viability.
