# Both proper scalar-source finite comparisons are qualified

The ordinaryg3 and lowerg2xi proper J_x C x families now have complete
selected dimensional-minus-heat local coefficients in the current physical
ghost frame, for all328 real scalar coordinates. No scalar Ward target or
physical finite normalization was used to assign a quantum coefficient.

Receipt [validation_receipt.json](validation_receipt.json), SHA256
`429e1b2abb38cc3944341f99cdccbbbb3d2a498f0e7839b01b2b23028b828a14`, records
`QUALIFIED_COMPLETE_SELECTED_PROPER_SCALAR_SOURCE_DIMENSIONAL_MINUS_HEAT_COMPARISON`.
Scientific/director acceptance NOT_PERFORMED; state113/34of39 remains unchanged.

## The result and its meaning

Let P denote the actual previously measured source pole, transported to the
current ghost frame, in the old hbar/(32pi^2 epsilon) units. For either family,
the finite local comparison in hbar/(16pi^2) units is

    (chi4+log(3/2))*P/2.

The coefficient outside this bracket is g10^3 for the ordinary family and
g10^2*xi for the mixed family. The latter xi is retained outside exactly
once. The ordinary reference-width polynomials remain eta_H and xi; no
width averaging or special gauge is selected.

Both actual triangles have heatlength6. Full-D contractions k.GBB.k and
k.BL contain no numerical Lorentz trace, so their first dimension jets are
zero. Thus the additional fixed part in this particular decomposition is
zero. This does **not** mean a whole finite heat amplitude vanishes or that
chi4 has been set to zero. The old positive-reference-mass lower kernel and
the common bubble calibration give exactly the relative log(6/4), with the
finite radial constants retained. No physical zero-mass/IR limit is taken.

The source and scalar coordinates keep their evaluation-dual canonical
pairing. Only the ghost input changes. Primary uses Pold.Li; replay passes
through raw C3 with Pold.Qold.Qi. The exact equality Qold.Qi=Li is checked.
The lower primary reconstructs the source coefficient from all29,754 literal
scalar field-rule entries and the measured N endomorphism. Replay extracts
the already qualified complete canonical lower scalar projection, including
the sign from exchanging the odd ghost and source. Those complete tensors
agree, rather than only their selected phi block or a desired cancellation.

| Current-frame family | Nonzero chi4 coefficients | Nonzero log(3/2) coefficients | Fixed |
| --- | ---: | ---: | ---: |
| Ordinaryg3 | 40,746 | 40,746 | 0 |
| Lowerg2xi | 17,658 | 17,658 | 0 |

These are sparse polynomial coefficient positions. The coordinate transport
changes the representation's support counts relative to the old source
tables; it does not change particles, interactions or physical parameters.
Both routes compare the complete29,047,680-position domain across two
families/three finite parts, including1,834,200 structural cross-sector zero
positions per family/part. This is exact sparse/structural coverage, not
millions of new integrations. Old pole calculations are authenticated and
reused. Local-H covariance follows the qualified old tensor identities and
authenticated frame intertwiners; no new large all-H replay is claimed.

Reversing odd-source ordering, omitting the32-to16 factor1/2, using bubble
heatlength4 for a triangle, or removing either family changes the respective
40,746 or17,658 nonzero positions. Using the wrong ghost map changes87,986
ordinary coefficient positions. No ghost-output L is applied to scalar Jx.

## Execution, scope and continuation

All first-version stages completed with native0: primary34.558912s,
replay63.181655s and separate gate9.456548s after imports. Their19/33/6 samples
have maximum private bytes142,585,856 /163,676,160 /173,256,704, observations
rather than continuous peaks. The600s/8GiB/350MiB-floor/16MiB-packet caps held.
Eight source copies and1806/1814 preparation/validation bindings are frozen.
Thisgoalturn's fresh bounded YHC E4 readiness is authenticated without another
replay; custody remains exit2 with seven unresolved references. No new failed
worker, verifier or controller occurred; all historical failures remain.

This completes another required parent, not the full scalar heat identity.
Next derive the proper matter-source scalar Euler image from the actual
graded mass action, then combine these source terms with the new proper
Yukawa comparison and measured OSM/ASB bare insertions. Compare the fixed
SMP scalar primitive and existing three-projection family only after the
quantum coefficients are assembled. Do not fit a source phase or finite
coefficient to produce a zero remainder.

Full source/Slavnov completion, positive masses, multiple insertions/QAP,
measure/phase, physical massive fermionic C1, E5/A5 and GUT viability remain
unqualified. Free chi4,kappa,b0 and other normalization directions remain
distinct. Both adverse scalar points, quartetFAIL, flavorpause, HB1/C5 blocks,
and authority34/39 are unchanged. The separate routes share action data,
qualified old quantum coefficients, analytic assumptions, exact arithmetic,
software and AI authorship; their agreement is computational corroboration.
