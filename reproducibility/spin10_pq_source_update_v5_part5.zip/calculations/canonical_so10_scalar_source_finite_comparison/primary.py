"""SCF1 direct scalar-source transport and literal lower source contraction."""
from data import *
tick=begin('primary');d=packed(HERE/'primary_inputs.json.gz')
q,w,D=sy.symbols('q w D');kernel=sy.cancel(sy.I*(-q/q**3+(1-w)*q*q/q**4));assert sy.cancel(kernel+sy.I*w/q**2)==0
jet=sy.diff(kernel,D);assert jet==0;factor=sy.Rational(16,32);length=2*3
unit={'chi4':str(factor),'log3over2':str(factor),'fixed':str(jet),'dimension_jet':str(jet),'heat_length':length}
Li,Qi,N=map(dec,[d['frame']['Li'],d['frame']['Qi'],d['Nraw']]);old=oldblocks(d['ordinary']);raw=raw_rules(d['raw_scalar_rules'])
ordinary={sec:transport(ms,Li) for sec,ms in old.items()};lower={sec:transport(transport(ms,N),Qi) for sec,ms in raw.items()};tree={sec:transport(ms,Qi) for sec,ms in raw.items()}
finish('primary',{'ordinary_g3':ordinary,'lower_g2xi':lower},tree,unit,tick,'fullD_scalar_kernel_cancellation_direct_qualified_ordinary_color_Li_and_literal_scalar_rule_N_Qi')
