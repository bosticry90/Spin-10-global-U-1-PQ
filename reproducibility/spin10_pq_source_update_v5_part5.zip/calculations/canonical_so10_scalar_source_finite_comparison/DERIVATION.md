# SCF1: dimension-independent actual ordered scalar-source triangles

The ordinary full-momentum scalar-source kernel was measured from all six
graded Hessian orders and independent routed Wick contractions in the old
scalar_source_g3_units result. With Q=k^2 it is

    i[-Q/Q^3+(1-W)Q^2/Q^4]=-i W/Q^2.

The contractions are full-D bosonic indices from the metric lift. This formula
therefore holds before setting D=4. It is not a sum of a fixed number4 or a
barred-spinor trace. Longitudinal projection k.GBB.k=W fixes its symbolic width.
The lower mixed triangle's actual kernel is -i*a*b*d/[Q(Q-Mref^2)], with a
positive Euclidean scalar reference after rotation. BL.k cancels a full Q;
again there is no D-dependent angular numerator. External scalar/ghost
derivative placements give zero no-jet Taylor coefficient in the old complete
units, not an absent interaction. Thus both first-D-jet fixed coefficients0.

Each triangle has three e^-2tQ edges, common heatlength6. With the GSF
calibration relative to length4, each actual pole coefficientP in old
hbar/(32pi^2 epsilon) units gives

    Gamma_dim-Gamma_heat = hbar/(16pi^2) *
                          (chi4+log(3/2))*P/2.

The lower radial pair is exact for M2>0:
heat exp(6tM2)E1(6tM2), dimensional Gamma(eps)(M2)^-eps/(1-eps).
For the normalized logarithmic bubble, heat=(1+4tM2)exp(4tM2)E1(4tM2)-1,
dimensional Gamma(eps)(M2)^-eps. Their local comparison constants differ
only by log(6/4); the +1 from the lower dimensional parameter integral equals
the +1 from the bubble heat finite subtraction. The same auxiliary reference
is compared, never removed before integration. No scaleless integral is set0.
Nonexceptional convergent completions cancel; finite massive kernels and
physical IR limits are not computed here.

Fields x and evaluation-dual Jx stay in their existing real canonical chart.
Only the ghost changes: C_old=Li C_new, C_raw=Qi C_new,
Qold*Qi=Li, L*Qold=Qnew. Accordingly Pnew=Pold.Li, with no L on Jx.
Replay forms Praw=Pold.Qold and then Praw.Qi. The source being odd does not
turn its scalar coordinate into a ghost-output index. From literal qx=-gRraw Cx,
the lower measured pole is Rraw.N.Qi with overall g^2xi. Its companion replay
parses the already qualified lower canonical scalar density: bringing an
odd ghost past Jx changes the coefficient sign. Keep that sign explicit.

All four scalar blocks and their cross-sector zero complement are retained.
The ordinary widths reference_width_H/M are the old names of eta_H/xi,
verified by the actual old symbolic width definitions. The lower matrix has
its xi outside exactly once. The finite comparison does not correlate chi4
with kappa,b0,zpsi,z10,z126,uR or any physical normalization.
