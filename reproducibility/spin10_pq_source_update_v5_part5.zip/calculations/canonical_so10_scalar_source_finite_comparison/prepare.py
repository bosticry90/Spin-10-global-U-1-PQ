"""SCF1 freeze actual source poles, raw fields and the verified current frame."""
from pathlib import Path
from hashlib import sha256
import json,gzip,sys,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-source-finite-comparison-v1-2026-10-23');OLD=CONTROL.with_name('yukawa-vertex-heat-comparison-v1-2026-10-23');PRED=CAL/'canonical_so10_yukawa_vertex_heat_comparison'
BASE='62a8ea2fed2ba8cf373d7d17e5bee57ef0ffbe2b';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
bind=dict(read(PRED/'validation_preparation_v3.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
CONTROL.mkdir(parents=True,exist_ok=False)
def add(p):p=p.resolve();bind[str(p)]=digest(p)
def dump(p,d):
 with p.open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
def gz(p,d):
 with p.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==32765
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(old)
add(CONTROL/'old_git_tree.txt')
for n in ['validation_receipt_v3.json','verify_v3_capture.json','RESULT.md','validation_preparation_v3.json']:add(PRED/n)
for n in ['before_commit_seal.json','successful_index_gate.json','postcommit_seal.json','seal.py','after_seal_full_capture.json']:add(OLD/n)
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V556.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md']:add(ROOT/n)
for folder,h in [('canonical_so10_scalar_source_g3_color','78d1c0641b0b205d73729eaaaa23bebefe76ce54f719196ea70e02af40a76874'),('canonical_so10_scalar_source_g3_units','08f2307cbe6a1b6be74e94254daec27bf90dc096c9e91018fcf6063082072a55')]:
 p=CAL/folder/'validation_receipt.json';assert digest(p)==h;add(p)
 for n in ['RECORD.md','RESULT.md']:add(CAL/folder/n)
low=PK/'frozen_a10_e5_source_vertex';assert digest(low/'validation_receipt.json')=='1c6488260827864c38665d14cad85b2d4345c85280b8ee37486e3edf8c6460f2';add(low/'validation_receipt.json')
for n in ['a10_e5_source_vertex.py','A10_E5_SOURCE_VERTEX_RESULT.md','a10_e5_nonminimal_source.py']:add(PK/n)
add(CAL/'canonical_so10_ordinary_scalar_matter_breaking/exact_ring_v4.py')
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;b=p.read_bytes();assert b'\r' not in b
 if p.suffix=='.py':compile(b,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(b)
 add(p);add(HERE/(n+'.source.txt'))
for role in ['primary','replay']:
 op=CAL/'canonical_so10_scalar_source_g3_color'/('primary_v2_result.json' if role=='primary' else 'replay_v3_result.json');lp=low/(role+'.json');bp=PK/'frozen_a10_bv_master'/(role+'.json');sp=CAL/'canonical_so10_source_vector_finite_transport'/(role+'_v2_tables.json.gz');qp=CAL/'canonical_so10_bosonic_source_onejet_finite'/('primary_v2_tables.json.gz' if role=='primary' else 'replay_v3_tables.json.gz')
 for p in [op,lp,bp,sp,qp]:add(p)
 ordinary=read(op);lower=read(lp);bv=read(bp);sv=packed(sp);qs=packed(qp)
 assert ordinary['full_domain']==4841280 and ordinary['complete180_source_kinetic_matrices_agree'] and lower['actual_leading_source_poles_qualified']
 packet={'ordinary':ordinary['sectors'],'frame':{**{k:sv[k] for k in ['L','Li','Qold','Qold_inverse','E']},**{k:qs[k] for k in ['Qchart','Qi']}},'raw_scalar_rules':{k:v for k,v in bv['source_only_columns'].items() if k.startswith('x_')}}
 if role=='primary':packet['Nraw']=lower['actual_internal_group']['ghost_endomorphism_C3']
 else:
  packet['lower_canonical_projection']=[r for r in lower['canonical_normalization']['complete_normalization_candidate'] if any(n.startswith('Jx_') for n in r['word'])];assert len(packet['lower_canonical_projection'])==22626
 gz(HERE/(role+'_inputs.json.gz'),packet);add(HERE/(role+'_inputs.json.gz'))
ready=read(OLD/'readiness_result.json');assert ready['native_exit']==0 and ready['step_exits']==[0,0,0,0,0,2]
for n in ['readiness_result.json','readiness.jsonl','readiness_stderr.txt']:add(OLD/n)
dump(CONTROL/'readiness_reuse.json',{'source':str(OLD/'readiness_result.json'),'sha256':digest(OLD/'readiness_result.json'),'same_goalturn_fresh_command_authenticated_not_repeated':True,'scientific_acceptance':'NOT_PERFORMED'});add(CONTROL/'readiness_reuse.json')
with (CONTROL/'prelaunch_preflight.json').open('xb') as out,(CONTROL/'prelaunch_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],stdout=out,stderr=err)
d=read(CONTROL/'prelaunch_preflight.json');assert r.returncode==0 and d['git_HEAD']==BASE and not d['active_A10_M08_python_processes']
for n in ['prelaunch_preflight.json','prelaunch_preflight_stderr.txt']:add(CONTROL/n)
dump(HERE/'preparation.json',{'schema':'SCF1_PREPARATION','input_sha256':dict(sorted(bind.items())),'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
print('SCF1_FROZEN',len(bind),'bindings',flush=True)
