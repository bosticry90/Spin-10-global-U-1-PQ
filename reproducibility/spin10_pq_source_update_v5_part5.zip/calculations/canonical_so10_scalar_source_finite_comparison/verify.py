"""SCF1 complete scalar-block equality, zero complement, radial and type gate."""
from data import *
tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');d=packed(HERE/'primary_inputs.json.gz')
fr={k:dec(v) for k,v in d['frame'].items()};zero(minus(mul(fr['Qold'],fr['Qi']),fr['Li']));zero(minus(mul(fr['L'],fr['Qold']),fr['Qchart']));zero(minus(mul(fr['Qchart'],fr['Qi']),ident(45)))
assert P['finite_unit']==R['finite_unit']=={'chi4':'1/2','log3over2':'1/2','fixed':'0','dimension_jet':'0','heat_length':6}
eps=sy.Symbol('eps');c4,c6,m=sy.symbols('c4 c6 m',positive=True)
# Exact lower/bubble radial comparison; retained finite constants, no zero-mass limit.
dim_extra=sy.limit(sy.gamma(1+eps)/(1-eps),eps,0);assert dim_extra==1
heat_extra=1-sy.log(sy.Rational(6,4));relative=sy.simplify(dim_extra-heat_extra);assert relative==sy.log(sy.Rational(3,2))
positions=0;counts={};controls={};full_domain=45*328**2;cross=45*(328**2-sum(n*n for n in DIMS.values()))
for family in ['ordinary_g3','lower_g2xi']:
 counts[family]={};controls[family]={}
 for part in PARTS:
  A=deserialize(P['finite_coefficients'][family][part]);B=deserialize(R['finite_coefficients'][family][part]);counts[family][part]=nz(A)
  for sec,n in DIMS.items():
   assert len(A[sec])==len(B[sec])==45
   for a,b in zip(A[sec],B[sec]):assert (a.r,a.c)==(b.r,b.c)==(n,n);zero(minus(a,b))
  positions+=full_domain
  if part=='fixed':assert not nz(A)
 for sec,n in DIMS.items():
  pa=list(map(dec,P['poles_old32'][family][sec]));rb=list(map(dec,R['poles_old32'][family][sec]));chi=list(map(dec,P['finite_coefficients'][family]['chi4'][sec]))
  for a,b,c in zip(pa,rb,chi):zero(minus(a,b));zero(minus(a,scale(c,Q(2))))
 chi=deserialize(P['finite_coefficients'][family]['chi4']);assert nz(chi)>0
 controls[family]['reverse_odd_source_order_changed_positions']=nz(chi)
 controls[family]['omit_half_old32_to_finite16_changed_positions']=nz(chi)
 controls[family]['wrong_triangle_heat_length4_changed_log_positions']=nz(chi)
 controls[family]['omit_family_changed_positions']=nz(chi)
for sec,n in DIMS.items():
 for a,b in zip(P['classical_Rnew'][sec],R['classical_Rnew'][sec]):zero(minus(dec(a),dec(b)))
old=oldblocks(d['ordinary']);wrong={sec:transport(ms,fr['L']) for sec,ms in old.items()};correct=deserialize(P['poles_old32']['ordinary_g3']);wrong_chart=sum(len(minus(a,b).d) for sec in DIMS for a,b in zip(wrong[sec],correct[sec]));assert wrong_chart>0
assert positions==29047680 and cross==1834200
for obj in [P,R]:
 assert obj['lower_xi_outside_once'] and obj['scalar_source_and_field_chart_unchanged'] and obj['old_width_aliases']=='reference_width_H/M=eta_H/xi'
 assert not any(obj[k] for k in ['quantum_coefficient_fitted','physical_scheme_adopted','full_scalar_heat_response_qualified'])
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'status':'QUALIFIED_COMPLETE_SELECTED_PROPER_SCALAR_SOURCE_DIMENSIONAL_MINUS_HEAT_COMPARISON','elapsed_after_imports':time.perf_counter()-tick,'finite_coefficient_positions_including_structural_cross_sector_zeros':positions,'cross_sector_zero_positions_per_family_part':cross,'families':['ordinary_g3','lower_g2xi'],'all45_ghosts_all328_scalars_both_independent_old_coefficient_routes':True,'finite_unit':P['finite_unit'],'nonzero_counts':counts,'negative_controls':controls,'wrong_ghost_chart_changed_positions':wrong_chart,'local_H_covariance':'INHERITED_QUALIFIED_OLD_TENSORS_AND_AUTHENTICATED_FRAME_INTERTWINERS','lower_actual_source_pole_vs_previously_qualified_complete_canonical_projection_match':True,'new_direct_old_loop_integrations':False,'dimension_jet_zero_from_fullD_longitudinal_contraction':True,'finite_IR_or_physical_amplitude_computed':False,'full_scalar_heat_response_qualified':False,'free_constant_selected':False,'physical_scheme_adopted':False,'full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified':False,'scientific_authority_changed':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
