"""SCF1 two-step raw ghost path and graded canonical lower pole extraction."""
from data import *
tick=begin('replay');d=packed(HERE/'replay_inputs.json.gz')
q,w,D=sy.symbols('q w D');contraction=sy.cancel(q*(1+(w-1)*q/q)/q);assert sy.cancel(contraction-w)==0
jet=sy.diff(contraction,D);assert jet==0;factor=F(16,32);length=sum([2,2,2])
unit={'chi4':str(factor),'log3over2':str(factor),'fixed':str(jet),'dimension_jet':str(jet),'heat_length':length}
Qo,Qi=map(dec,[d['frame']['Qold'],d['frame']['Qi']]);old=oldblocks(d['ordinary']);raw=raw_rules(d['raw_scalar_rules']);canon=scalar_rows(d['lower_canonical_projection'])
ordinary={sec:transport(transport(ms,Qo),Qi) for sec,ms in old.items()};lower={sec:transport(ms,Qi) for sec,ms in canon.items()};tree={sec:transport(ms,Qi) for sec,ms in raw.items()}
finish('replay',{'ordinary_g3':ordinary,'lower_g2xi':lower},tree,unit,tick,'independent_longitudinal_contraction_qualified_ordinary_raw_C3_path_and_odd_source_ordered_lower_density')
