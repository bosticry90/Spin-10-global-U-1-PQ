"""SCF1 exact scalar blocks and ghost-only transport; immutable IO."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,gzip,sys,os,time,threading,re
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
sys.path.insert(0,str(CAL/'canonical_so10_ordinary_scalar_matter_breaking'))
from exact_ring_v4 import *
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
DIMS={'Phi':54,'Sigma':252,'phi':20,'S':2};PARTS=['chi4','log3over2','fixed']
def begin(role):
 tick=time.perf_counter();t=threading.Timer(600,lambda:os._exit(124));t.daemon=True;t.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and (p.name.startswith(peer) or p.name=='validation_control_inputs.json.gz'):raise PermissionError('SCF1_PEER_OR_TARGET_DENIED')
   if p.parent.name in ['canonical_so10_scalar_matter_primitive','canonical_so10_heat_highest_matter_source'] and p.suffix=='.gz':raise PermissionError('SCF1_WARD_TARGET_DENIED')
 sys.addaudithook(audit);return tick
def coeff(z):return Q(str(z).replace('reference_width_H','eta_H').replace('reference_width_M','xi'))
def oldblocks(d):return {sec:[Mat(n,n,{(i,j):coeff(z) for i,j,z in a}) for a in d[sec]['all45_ghost_matrices']] for sec,n in DIMS.items()}
def transport(ms,K):
 assert len(ms)==45 and K.r==K.c==45
 return [combine([K.d.get((a,b),Z) for a in range(45)],ms) for b in range(45)]
def raw_rules(rows):
 out={sec:[Mat(n,n) for _ in range(45)] for sec,n in DIMS.items()};g=sy.Symbol('g10');count=0
 for name,rr in rows.items():
  m=re.fullmatch(r'x_(Phi|Sigma|phi|S)_(\d+)',name);assert m;sec,i=m[1],int(m[2])
  for row in rr:
   names=row['word'];assert len(names)==2
   c=next(v for v in names if re.fullmatch(r'C\d+',v));x=next(v for v in names if v.startswith('x_'));mm=re.fullmatch(r'x_'+sec+r'_(\d+)',x);assert mm
   a=int(c[1:]);j=int(mm[1]);v=sy.Poly(sy.sympify(row['coefficient']),g);assert v.monoms()==[(1,)]
   out[sec][a].d[i,j]=coeff(-v.coeff_monomial(g));count+=1
 assert count==29754;return out
def scalar_rows(rows):
 out={sec:[Mat(n,n) for _ in range(45)] for sec,n in DIMS.items()};g=sy.Symbol('g10');xi=sy.Symbol('xi')
 for row in rows:
  names=row['word'];assert len(names)==3
  cs=next(v for v in names if re.fullmatch(r'C\d+',v));J=next(v for v in names if v.startswith('Jx_'));x=next(v for v in names if v.startswith('x_'))
  m=re.fullmatch(r'Jx_(Phi|Sigma|phi|S)_(\d+)',J);assert m;sec,i=m[1],int(m[2]);mm=re.fullmatch(r'x_'+sec+r'_(\d+)',x);assert mm
  poly=sy.Poly(sy.sympify(row['coefficient']),g,xi);assert poly.monoms()==[(2,1)]
  v=coeff(poly.coeff_monomial(g**2*xi));v=neg(v) if names.index(cs)<names.index(J) else v
  a=int(cs[1:]);j=int(mm[1]);assert (i,j) not in out[sec][a].d;out[sec][a].d[i,j]=v
 return out
def serialize(blocks):return {sec:[enc(m) for m in ms] for sec,ms in blocks.items()}
def deserialize(blocks):return {sec:list(map(dec,ms)) for sec,ms in blocks.items()}
def nz(blocks):return sum(len(m.d) for ms in blocks.values() for m in ms)
def finish(role,poles,tree,unit,tick,method):
 finite={family:{part:{sec:[scale(m,Q(unit[part])) for m in ms] for sec,ms in blocks.items()} for part in PARTS} for family,blocks in poles.items()}
 out={'method':method,'poles_old32':{k:serialize(v) for k,v in poles.items()},'finite_coefficients':{k:{p:serialize(v) for p,v in parts.items()} for k,parts in finite.items()},'classical_Rnew':serialize(tree),'family_nonzero':{k:nz(v) for k,v in poles.items()},'finite_unit':unit,'lower_xi_outside_once':True,'old_width_aliases':'reference_width_H/M=eta_H/xi','scalar_source_and_field_chart_unchanged':True,'quantum_coefficient_fitted':False,'physical_scheme_adopted':False,'full_scalar_heat_response_qualified':False,'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39'}
 raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
