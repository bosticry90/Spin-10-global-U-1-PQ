"""Build a new version; never edit the qualified SPP sources."""
from pathlib import Path
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
old=R/'calculations/canonical_so10_source_probe_pair'
def change(t,a,b):
 assert a in t,a[:120]
 return t.replace(a,b)
def save(name,t):
 with (O/name).open('x',encoding='utf-8',newline='\n') as f:f.write(t)
t=(old/'pair.py').read_text(encoding='utf-8')
t=change(t,'highest-source primitive-pair','complete-local-carrier primitive-pair')
t=change(t,"'spp_rho'","'spc_rho'")
t=change(t,"A=Algebra(geo['names']+['spc_rho'+str(i) for i in range(4)],geo['parities']+[1]*4)","A=Algebra(geo['names']+['spc_rho'+str(i) for i in range(4)]+['spc_a'+str(i) for i in range(45)],geo['parities']+[1]*49)")
t=change(t,"corefields={n for b in bn for n in b}|set(an+ln+cn)","""jc=[Jof[n] for n in cn];bg=[A.index['spc_a'+str(i)] for i in range(45)]
 bgmap=dict(zip(an,bg));extweight={**dict.fromkeys(jl+bg,1),**dict.fromkeys(jc,2)}
 extset=set(extweight);corefields={n for b in bn for n in b}|set(an+ln+cn)
 # Exhaustive type enumeration, independent of the later graph projection.
 types={'B':(1,0,0,180),'x':(1,0,0,328),'A':(1,0,0,48),'C':(1,1,1,45),'a':(1,-1,1,45),'L':(2,0,0,45),'JB':(2,-1,1,180),'Jx':(2,-1,1,328),'JC':(2,-2,0,45),'Ja':(2,0,0,45),'JL':(1,-1,1,45)}
 candidates=[]
 for n,(d,h,p,count) in types.items():
  if d<=2 and h==-2 and p==0:candidates.append((n,))
 for n in types:
  for m in types:
   if n>m:continue
   d,h,p,_=types[n];e,k,q,_=types[m]
   if d+e<=2 and h+k==-2 and (p+q)%2==0:candidates.append((n,m))
 assert set(candidates)=={('JC',),('JL','JL'),('JL','a'),('a','a')}
 assert all(sum(types[n][0] for n in c)==2 for c in candidates)
 assert all(A.parities[n]==1 for n in jl+bg) and all(A.parities[n]==0 for n in jc)
 census={'JC':45,'JLJL':990,'JLa':2025,'aa':990};assert sum(census.values())==4050""")
t=change(t,"else '-1' if n in set(ja) else '1'","else '-1' if n in set(ja+jc) else '1'")
t=change(t,"co={k:z for k,z in co.items() if not any(t in fields for t,j in k[1])}","""# Project residual ordinary antighosts only AFTER both derivatives.
    co=sub(co,{n:elem(bgmap[n]) for n in an})
    co={k:z for k,z in co.items() if not any(t in fields or j for t,j in k[1])}""")
t=change(t,'all(t in jset|rs for t,j in k[1])','all(t in extset|rs for t,j in k[1])')
t=change(t,'sum(n in jset for n,j in k[1])<=2','sum(extweight.get(n,0) for n,j in k[1])<=2')
t=change(t,"src=add(*(mul(elem(jl[i]),rows(data['master_field_maps'][A.names[ln[i]]])) for i in range(45)))", """# All residual-a action terms and the full relevant source action.
 src=add(rows(data['gauge_fixing_density']),*(mul(elem(jl[i]),rows(data['master_field_maps'][A.names[ln[i]]])) for i in range(45)),*(mul(elem(jc[i]),rows(data['master_field_maps'][A.names[cn[i]]])) for i in range(45)))""")
t=change(t,'srcphys=sub(src,frame);V=hess(wick(srcphys))','''srcphys=sub(src,frame);fullV=hess(wick(srcphys))
 V={k:{z:c for z,c in p.items() if any(n in extset for n,j in z[1])} for k,p in fullV.items()};V={k:p for k,p in V.items() if p}''')
t=change(t,"assert V and all(sum(n in jset for n,j in w)==1 and not any(n in rs for n,j in w) for p in V.values() for g,w in p)","""assert V and all(1<=sum(extweight.get(n,0) for n,j in w)<=2 and not any(n in rs for n,j in w) for p in V.values() for g,w in p)
 assert not any(i in {n for b in bn for n in b} and j in {n for b in bn for n in b} for i,j in V)""")
t=change(t,'for M in H:','for M in H+[V]:')
t=change(t,'for a in an+cn:','for a in an+cn+ln:')
t=change(t,'assert all(sum(n in jset for n,j in w)<=1 and sum(n in rs for n,j in w)==1 for p in M.values() for g,w in p)',"assert all(sum(extweight.get(n,0) for n,j in w)<=2 and sum(n in rs for n,j in w)==(0 if M is V else 1) for p in M.values() for g,w in p)")
t=change(t,'sum(n in jset for n,j in k[1])==2','sum(extweight.get(n,0) for n,j in k[1])==2')
t=change(t,"'local_exterior_JL_domain_per_pair':990","'local_carrier_domain_per_pair':4050,'carrier_census':census,'background_antighosts':bg")
t=change(t,"'SOURCE_PROBE_PAIR_V1'","'SOURCE_PROBE_CONTACT_COMPLETE_V1'")
save('pair.py',t)

v=(old/'verify_v2.py').read_text(encoding='utf-8')
v=change(v,"'validation_preparation_v2.json'","'validation_preparation.json'")
v=change(v,"'spp_rho'","'spc_rho'")
v=change(v,"names=geo['names']+['spc_rho'+str(i) for i in range(4)];par=geo['parities']+[1]*4", "names=geo['names']+['spc_rho'+str(i) for i in range(4)]+['spc_a'+str(i) for i in range(45)];par=geo['parities']+[1]*49")
v=change(v,"'local_exterior_JL_domain_per_pair'","'local_carrier_domain_per_pair','carrier_census','background_antighosts'")
v=change(v,"qvec=[F(1),F(0),F(0),F(0)]","""jc=[Jof[n] for n in cn];bg=[index['spc_a'+str(i)] for i in range(45)];bgmap=dict(zip(an,bg))
extweight={**dict.fromkeys(jl+bg,1),**dict.fromkeys(jc,2)};extset=set(extweight)
qvec=[F(1),F(0),F(0),F(0)]""")
v=change(v,"else '-1' if n in set(ja) else '1'","else '-1' if n in set(ja+jc) else '1'")
v=change(v,"co={k:c for k,c in co.items() if not any(t in fields for t,j in k[-1]) and all(t in jset|rs for t,j in k[-1])}","""co=subst(co,{n:elem(bgmap[n]) for n in an})
   co={k:c for k,c in co.items() if not any(t in fields or j for t,j in k[-1]) and all(t in extset|rs for t,j in k[-1])}""")
v=change(v,'sum(n in jset for n,j in k[-1])<=2','sum(extweight.get(n,0) for n,j in k[-1])<=2')
v=change(v,'sum(n in jset for n,j in k[-1])==2','sum(extweight.get(n,0) for n,j in k[-1])==2')
v=change(v,"V=hess(wick(unpack(P['source_action_physical'])))","""fullV=hess(wick(unpack(P['source_action_physical'])))
V={k:{z:c for z,c in p.items() if any(n in extset for n,j in z[-1])} for k,p in fullV.items()};V={k:p for k,p in V.items() if p}""")
v=change(v,"assert all(len(w)==4 and sum(n in jset for n,j in w)==2 and sum(n in rs for n,j in w)==2 and not any(j for n,j in w) for gp,xp,hp,m,w in p)","""assert all(sum(extweight.get(n,0) for n,j in w)==2 and sum(n in rs for n,j in w)==2 and not any(j for n,j in w) for gp,xp,hp,m,w in p)
  for gp,xp,hp,m,w in p:
   ext=[n for n,j in w if n not in rs]
   assert (len(ext)==1 and ext[0] in jc) or (len(ext)==2 and all(n in set(jl+bg) for n in ext))""")
v=change(v,"'QUALIFIED_COMPLETE_HIGHEST_SOURCE_LOCAL_PAIR_COMPARISON_OF_ACTUAL_FOUR_COMPONENT_POLARIZATION_FAMILY'","'QUALIFIED_COMPLETE_SATURATED_LOCAL_PAIR_CARRIER_OF_ACTUAL_FOUR_COMPONENT_POLARIZATION_FAMILY'")
v=change(v,"'JL_exterior_positions_per_pair':990","'carrier_positions_per_pair':4050,'carrier_census':P['carrier_census']")
# Fresh orthogonal carrier census, not inferred from the nonzero output.
v=change(v,"# Exact radial normalization,", """# Exhaust the concrete local words (not an inferred output support list).
domain=[(n,) for n in jc]+list(combinations(jl,2))+[(n,m) for n in jl for m in bg]+list(combinations(bg,2))
assert len(domain)==len(set(domain))==4050
assert P['carrier_census']=={'JC':45,'JLJL':990,'JLa':2025,'aa':990}
# Old highest-source projection is authenticated reuse, not a fresh old run.
old=json.loads(gzip.decompress((R/'calculations/canonical_so10_source_probe_pair/primary_tables.json.gz').read_bytes()))
for k,d in P['pair_tensors'].items():
 for n in ['2','3','4','Djet','common_chi4','finite_Djet']:
  pp=unpack(d[n]);assert not {z:c for z,c in pp.items() if sum(i in jset for i,j in z[-1])==2}
  assert old['pair_tensors'][k][n]['positions']==0
# Exact radial normalization,""")
save('verify.py',v)
print('BUILT_SPC1_NATIVE_AND_VERIFIER')
