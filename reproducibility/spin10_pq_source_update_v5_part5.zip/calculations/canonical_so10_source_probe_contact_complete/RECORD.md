# Complete local pair carrier of the actual source primitive, SPC1

Base e698d75d62ec35da6f7073381f09eea5e6b5575d/main. New work binds current
AGENTS; old policies, inputs and evidence remain immutable. State113/34of39
and historical custody exit2/seven NOTPASS remain unchanged.

1. Question: do the remaining lower-source local pair contacts of the actual
four Ksrc polarizations vanish, or supply further finite mixing data needed
before testing the selected second-probe Ward identity?
2. Claim: calculate the COMPLETE dimension2,ghost-2,even coefficient carrier
at rho_r rho_s,u=0, for all six pairs of the existing four projections.
Its four patterns are JC, JL*JL, JL*a, a*a; 45+990+2025+990=4050 slots per
pair before covariance restrictions. Independently enumerate this census.
3. Ceiling: local Euclidean UV-symbol relative comparison ONLY. No complete
nonlocal product, second Ward equation, QAP/measure, chiral/physical/causal
limit, E5/A5 or physical unification. No state/authority/foundation/scheme/
benchmark change, flavor/HB1/C5 activation, agent, branch/worktree or push.
4. Inputs: original action/GF/maps, E2 shifts, full643 field/source-dual frames,
SPM actual70-term pre-U seed, and SPP's conventions/analytic radial proof.
Same four projections Mlight,Mheavy,Nlight,Nheavy; last is zero. Keep local
Schwartz probes independent. Other external backgrounds/partners are zero
only at this specified local Taylor projection; no physical Euler equation.
5. Comparators: SPP highest JLJL result; SQP grades and canonical source map;
SPM classical linear augmented action; prior relative-symbol/IR theorem.
Use these authenticated results, without claiming a fresh analytic replay.
6. Primary: reconstruct actual U and physical/source-dual chart, differentiate
the even Wick action before background projection, sum full ordered log
words of lengths2,3,4. Include action GF antighost backgrounds, JL*qLambda,
JC*qC. Ordinary action is a/Lambda independent. Retain external antighosts
as separate odd variables AFTER both fluctuation derivatives.
7. Replay: independent raw artifacts and composed transport, right-gradient
implementation of the same Frechet Hessian, another exact unit momentum,
and differentiated background-dressed inverse. Separate expanded-Fraction
verifier freshly differentiates physical densities and contracts rooted paths.
Shared action/frames/analytic proofs/software/AI author remain; no external
scientific confirmation. No automatic universal G2 claim.
8. Falsifiers: two-sided free inverse and finite mixed Gaussian; physical
Lorentz shapes; fresh 5th transverse component; all three ordered groups,
complete zero complements and old990-slot projection. Omission sensitivities
are measured, never described as sensitive if the actual result is zero.
9. Limits: saturated grades exclude external jets, masses and scalar orbit
coefficients from THIS local symbol. They do not set the full remainder U=0.
Polynomial g,xi,eta retained; no fitting quantum coefficients or division by g.
10. Caps: each sequential native and separate verifier600s after imports,
8GiB sampled private allocation;350MiB available-commit launch floor;
whole packet16MiB. All sources/hashes frozen before execution. Stop on
failure/incomplete/resource exhaustion; preserve exact originals/full captures.
11. Failure: mismatch is not an anomaly verdict; classify type/implementation,
coverage/analytic underdefinition or incomplete calculation before interpretation.
No gate weakened, no old manifest rebound, no failed evidence overwritten.
12. Outputs: full exact physical densities/Hessians/group tensors, complete
captures, independent receipt, result/limits/next action. Validate bounded
work and existing delegated E4 command before local commit. A bounded result
is not completion of the investigation; continue the next justified dependency.
