# A finite lower-source contact survives the complete local pair calculation

SPC1 qualifies the complete saturated LOCAL relative comparison for all six
pairs of the four actual Ksrc carrier projections. It does not qualify the
full connected products or the second-probe quantum Ward identity.

The highest-source zero in SPP remains correct. Extending that zero to the
whole local carrier would have missed a nonzero JL*a contribution.

## Result and complete domain

Independent grade enumeration leaves JC, JLJL, JL*a and aa: respectively
45,990,2025,990 concrete positions per polarized pair,4050 total before
covariance restrictions. These are carrier positions, not independent
counterterms or physical observations. All6 pairs were retained, including
the3 structural zeros involving the identically zero Nheavy projection.

Only Mlight/Mheavy has a nonzero local relative comparison. In16pi^2
one-loop density units its groups obey

    T2=0,  T3=-P,  T4=P,  partial_D T2=0,
    Crel=log(4/3) P.

P contains56 positions, all order g10^2*xi*eta_H^2, in JL*a only.
Its total UV pole is zero. Heat lengths6 and8 leave the finite difference
log8-log6=log(4/3). The common chi4 ambiguity cancels; it was not fixed.
All other five pairs and all JC/JLJL/aa positions are zero in this declared
local comparison. Across24300 carrier slots,56 survive and24244 are zero.
This says nothing about the full nonlocal remainders.

For the literal Euclidean chart, write

    P=i*g10^2*xi*eta_H^2*rho0*rho1*sum_ij Kij JL_i a_j.

K has56 real rational entries, supported on13..44. Their values and counts
are 1/5(6),23/80(24),1/40(12),-1/40(12),3/40(2). The full indexed matrix is
in pair_tensors['0,1']['4'] of both primary_v2_tables.json.gz and
replay_v3_tables.json.gz. For example K13,13=1/5. Background a in the native
tables is a bookkeeping label for the residual ordinary antighost, not a
new inert variable or a new physical field. The factor i belongs to the
declared Wick/source chart; no physical observable is inferred from it.

The result is a relative local regulator/subtraction comparison. It does
not identify absolute product extensions, kappa, b0, an IR constant or a
physical normalization. It is not added to ordinary rho0 canonical Gamma.

## Verification and preserved incomplete work

The primary reconstructs raw U and the643-field/source-dual frame, uses
the full ordered log, and evaluates a temporal unit momentum. Replay
reconstructs its own frozen artifacts, differentiates the dressed inverse,
resolves external grades and uses a spatial unit momentum. Their full
physical densities and all pair tensors agree.

The separate verifier freshly differentiates all physical primitive/action
vertices in expanded Fraction/exterior arithmetic, enumerates closed index
paths, checks all four momentum axes with a proved linear momentum envelope,
and adds a fresh transverse vector component to check the dimension jet.
It checks all groups, the complete zero complement, the old highest-source
projection, the mixed Gaussian sign control and each radial comparison.
Source/background inverse omission and common heat-length controls are
sensitive on the measured56-position result. Dropping antighost-background
action vertices eliminates its box sector by degree support. The closed
vector-D-jet omission control is insensitive here; no sensitivity is claimed.

Two native attempts exhausted600s: original primary during assembly, and
V2 replay during dense/ungraded contraction. Neither wrote scientific
tables or earned a receipt. Exact original sources, manifests, full captures
and controller failures are preserved. Streaming accumulation corrected the
first engineering bottleneck; grade selection, sparse rotation and rooted
inverse products corrected the second. No input or graph was removed from
the target. No resource cap or scientific test was weakened.

Completed after-import times: primaryV2 502.109024s, replayV3 115.306599s,
verifierV3 303.993617s. Sampled private maxima761257984,734318592,569540608 B;
254,62,155 samples respectively. Failed attempts have299 samples each,
maxima600469504 and746762240 B. All launch floors350MiB and memory caps8GiB
held; sampled maxima are not exact peaks. Packet cap16MiB held. Preparation
bindings53/69/88 and final validation93;19 source snapshots.

Sole new scientific validation receipt: validation_receipt_v3.json,
SHA256 a01c8a56f9dc5f64eabf070b41c85db962a611f3198576e4a732dc33e85548d0.
No original/V2 validation receipt exists. All command captures are also
preserved outside Git in the matching source-probe-contact-complete control
directory. Controllers write exclusively; do not rerun them in the sealed
folder. Reproduction must preserve the recorded historical input/policy
bytes and use a fresh output location, without rebinding old manifests.

## Assessment and next calculation

The supplied deeper assessment was reviewed against the actual current
handoff/receipts and used to prioritize this missing COMPLETE local carrier.
Attachment SHA2561e789e00a50c3fc681b18b7b5d71eba67aab86b9c0f8aaf665c57af107eb9dff.
This is not a fresh replay of every historical result or an external review.

The result supplies a necessary, nonzero quantum input for the selected
two-probe investigation. It demonstrates why classical absence of a second
vertex and a zero highest-source quantum projection do not fix lower-source
finite products. It is not an anomaly or a successful Ward-restoration test.
The AI methods share action, reference conventions, analytic relative-symbol/
radial/IR proofs, software and AI authorship. No external expert, experiment
or proof assistant confirms the physical premises. Two resource failures are
workflow weaknesses; the successful structural reduction is bounded evidence
of improved computational organization, not a general reliability score.

The next smallest useful target is the correlated mixed u*rho comparison
along this measured direction, retaining BOTH source and ordinary-field
Euler legs. DESCENT_NOTE.md derives a symbolic possible completion and its
precise limitation; it does not assign the actual mixed quantum kernel.
Then compare the selected complete Ward breaking from the same augmented
functional, including the convergent remainder U, reference and measure
terms. Do not substitute a formal completion for measured quantum inputs.

The unrestricted invariant counterterm space/HB1-C5, full nonlinear products,
QAP, global/chiral/measure/causal/physical limits and massive fermion C1
remain open. Old benchmark exclusions, scalar perturbative warning, quartet
failure and flavor/HB1/C5 blocks remain. State113/34of39 unchanged; custody
exit2/seven NOTPASS. No scheme/foundation/benchmark/state/authority adoption,
branch/worktree, agent, remote push, publication or outreach. Goal incomplete.
