from pathlib import Path
O=Path(__file__).resolve().parent
def save(n,t):
 with (O/n).open('x',encoding='utf-8',newline='\n') as f:f.write(t)
def change(t,a,b):
 assert a in t,a
 return t.replace(a,b)
t=(O/'pair.py').read_text(encoding='utf-8')
t=change(t,"'preparation.json'","'preparation_v2.json'")
t=change(t,"role+'_tables.json.gz'","role+'_v2_tables.json.gz'")
t=change(t,'   out=add(out,term)','   for key,value in term.items():put(out,key,value)')
t=change(t,'   out=add(out,mul({(g,w):co},fac))','   for key,value in mul({(g,w):co},fac).items():put(out,key,value)')
save('pair_v2.py',t)
v=(O/'verify.py').read_text(encoding='utf-8')
v=change(v,"'validation_preparation.json'","'validation_preparation_v2.json'")
for a,b in [('primary_tables.json.gz','primary_v2_tables.json.gz'),('replay_tables.json.gz','replay_v2_tables.json.gz'),("role+'_capture.json'","role+'_v2_capture.json'")]:
 # Keep the old qualified highest-source input path unchanged.
 if a=='primary_tables.json.gz':v=v.replace("(O/'primary_tables.json.gz')","(O/'primary_v2_tables.json.gz')")
 else:v=change(v,a,b)
v=change(v,'  out=add(out,term)','  for key,value in term.items():put(out,key,value)')
v=change(v,'  out=add(out,pp)','  for key,value in pp.items():put(out,key,value)')
save('verify_v2.py',v)
p=(O/'prepare.py').read_text(encoding='utf-8')
start=p.index("for n in ['RECORD.md'")
p=p[:start]+'''old=json.loads((O/'preparation.json').read_bytes())
for q,h in old['input_sha256'].items():assert H(Path(q))==h,q
failure=json.loads((O/'primary_capture.json').read_bytes());assert failure['exit_code']==124 and not failure['calculation_completed']
assert not any((O/n).exists() for n in ['primary_tables.json.gz','replay_capture.json','verify_capture.json','validation_receipt.json'])
files.extend(p for p in O.iterdir() if p.is_file())
for n in ['CORRECTION_V2.md','build_v2.py','pair_v2.py','verify_v2.py','prepare_v2.py','run_v2.py']:
 p=O/n
 with (O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
files.extend(O.glob('*.source.txt'))
dump(O/'preparation_v2.json',{'base':base,'input_sha256':{str(p):H(p) for p in sorted(set(files))},'artifacts':art,'read_json_by_role':{r:[a['reference'],a['e2']] for r,a in art.items()},'limits':old['limits'],'scientific_acceptance':'NOT_PERFORMED','original_attempt':'INCOMPLETE_RESOURCE_EXHAUSTION_PRESERVED'})
print('PREPARED_SPC1_V2',len(set(files)))
'''
save('prepare_v2.py',p)
r=(O/'run.py').read_text(encoding='utf-8')
r=change(r," C.mkdir(parents=True,exist_ok=False)\n with (C/'old_git_tree.txt').open('xb') as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))"," assert C.is_dir() and (C/'old_git_tree.txt').exists()")
r=change(r,"'prepare.py'","'prepare_v2.py'")
for a,b in [('preparation_capture.json','preparation_v2_capture.json'),('preparation_full_capture.json','preparation_v2_full_capture.json'),("'preparation.json'","'preparation_v2.json'"),("'validation_preparation.json'","'validation_preparation_v2.json'"),("'verify.py' if role=='verify' else 'pair.py'","'verify_v2.py' if role=='verify' else 'pair_v2.py'"),("role+'_capture.json'","role+'_v2_capture.json'"),("role+'_full_capture.json'","role+'_v2_full_capture.json'"),("role+'_tables.json.gz'","role+'_v2_tables.json.gz'"),("'validation_receipt.json' if role=='verify' else role+'_result.json'","'validation_receipt_v2.json' if role=='verify' else role+'_v2_result.json'"),("'controller_failure.json'","'controller_failure_v2.json'")]:r=change(r,a,b)
save('run_v2.py',r)
print('BUILT_STREAMING_V2')
