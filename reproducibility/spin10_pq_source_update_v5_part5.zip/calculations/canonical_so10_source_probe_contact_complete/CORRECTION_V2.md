# Streaming accumulation continuation, before new execution

The original primary reached its600s after-imports watchdog (native124)
before completing the physical principal vertices. It produced no scientific
tables or validation receipt. Original sources,53 bindings and full internal/
external captures remain unchanged. Controller FAILED is separate from the
scientific disposition INCOMPLETE_RESOURCE_EXHAUSTION; no theorem failed.
Replay and verifier were never launched in that attempt.

Code inspection identifies quadratic engineering work in substitution and
Wick pullback: out=add(out,new_term) recopies the entire growing polynomial
at each summand. V2 replaces ONLY these accumulator calls with insertion
of new_term's cells through the SAME exact put operation used by add. This
is algebraically the same ordered sequence of exact coefficient additions;
no input, term, sign, derivative, graph, test, acceptance condition or cap
changes. The separate verifier applies the analogous expanded-Fraction fix.

New files and input hashes are frozen separately. Same600s per sequential
native/verifier,8GiB sampled private,350MiB launch floor,16MiB total packet.
No old output is rebound or relabelled PASS. If this attempt exhausts again,
preserve it and reassess structural computation rather than expanding caps.
