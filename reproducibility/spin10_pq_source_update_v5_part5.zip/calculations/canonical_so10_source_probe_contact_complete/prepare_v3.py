from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert base=='e698d75d62ec35da6f7073381f09eea5e6b5575d'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R).strip()
art={r:{'reference':str(P/'frozen_a10_e5_full_hessian'/(r+'.json')),'e2':str(P/'frozen_a10_e2_transport'/(r+'.json')),'seed':str(R/'calculations/canonical_so10_second_probe_master'/(r+'_v2_tables.json.gz'))} for r in ['primary','replay']}
files=[R/'AGENTS.md',R/'CHARTER.md',R/'project_state.json',R/'docs/LOCAL_RESEARCH_CONVENTIONS_V1.md',R/'docs/SOLO_REVIEW_POLICY_V1.md',R/'docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V585.md',R/'tools/portable_dh_v1/inputs.json.gz',R/'tools/portable_dh_v1/exact_algebra.py',P/'export_a10_e5_antighost_vector.py']
for a in art.values():files.extend(Path(p) for p in a.values())
for sub in ['frozen_a10_e5_full_hessian','frozen_a10_e2_transport']:files.extend([P/sub/'validation_receipt.json',P/sub/'bindings.json'])
for folder,names in {'canonical_so10_second_probe_master':['RESULT.md','DERIVATION.md','CORRECTION_V2.md','validation_receipt_v2.json'],'canonical_so10_sourcequadratic_primitive_probe':['DERIVATION.md','TRACE_DOMAIN_NOTE.md','RESULT.md','validation_receipt.json'],'canonical_so10_source_probe_pair':['pair.py','verify_v2.py','RECORD.md','DERIVATION.md','RESULT.md','validation_receipt_v2.json','validation_receipt_v3.json','extension_receipt_v4.json','primary_tables.json.gz'],'canonical_so10_joint_born_ir_trace_domain':['DERIVATION_V2.md','validation_receipt.json']}.items():files.extend(R/'calculations'/folder/n for n in names)
old=json.loads((O/'preparation.json').read_bytes())
for q,h in old['input_sha256'].items():assert H(Path(q))==h,q
failure=json.loads((O/'replay_v2_capture.json').read_bytes());assert failure['exit_code']==124 and not failure['calculation_completed']
assert not (O/'validation_receipt_v2.json').exists()
files.extend(p for p in O.iterdir() if p.is_file())
for n in ['CONTINUATION_V3.md','build_v3.py','pair_v3.py','verify_v3.py','prepare_v3.py','run_v3.py']:
 p=O/n
 with (O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
files.extend(O.glob('*.source.txt'))
dump(O/'preparation_v3.json',{'base':base,'input_sha256':{str(p):H(p) for p in sorted(set(files))},'artifacts':art,'read_json_by_role':{r:[a['reference'],a['e2']] for r,a in art.items()},'limits':old['limits'],'scientific_acceptance':'NOT_PERFORMED','two_prior_resource_exhaustions':'PRESERVED_NOT_QUALIFIED'})
print('PREPARED_SPC1_V3',len(set(files)))
