"""Independent expanded arithmetic, differentiated full physical vertices."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from collections import defaultdict
from itertools import permutations,combinations
import json,gzip,time,threading,os
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
for p,h in read(O/'validation_preparation_v3.json')['input_sha256'].items():assert digest(Path(p))==h,p
def guard(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('SPP_VERIFIER_WRITE')
os.sys.addaudithook(guard)
P=json.loads(gzip.decompress((O/'primary_v2_tables.json.gz').read_bytes()));Q=json.loads(gzip.decompress((O/'replay_v3_tables.json.gz').read_bytes()))
for k in ['labels','seed_parts','physical_G','source_action_physical','mixed_Gaussian','wrong_mixed_Gaussian','pair_tensors','controls','local_carrier_domain_per_pair','carrier_census','background_antighosts','complete_polarized_pairs','heat_lengths']:
 assert P[k]==Q[k],k
for role in ['primary','replay']:
 cap=read(O/(role+('_v2_capture.json' if role=='primary' else '_v3_capture.json')));assert cap['exit_code']==0 and cap['execution_state']=='COMPLETED' and cap['calculation_completed']
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry']
names=geo['names']+['spc_rho'+str(i) for i in range(4)]+['spc_a'+str(i) for i in range(45)];par=geo['parities']+[1]*49;index={n:i for i,n in enumerate(names)}
pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};sources={J for i,J,h,k in pairs};canon=fields|sources;Jof={i:J for i,J,h,k in pairs}
g,xi,eta=s.symbols('g10 xi eta_H');loc={'g10':g,'xi':xi,'eta_H':eta,'reference_width_M':xi,'reference_width_H':eta}
squares=[2,3,5,7,-1]
factors={(i,j):s.prod(squares[k] for k in range(5) if i&j&(1<<k)) for i in range(32) for j in range(32)};factors={k:int(v) for k,v in factors.items()}
def put(p,k,v):
 if not v:return
 p[k]=p.get(k,F(0))+v
 if not p[k]:del p[k]
def add(*pp):
 out={}
 for p in pp:
  for k,v in p.items():put(out,k,v)
 return out
def scaled(p,c):return {k:v*c for k,v in p.items() if v*c}
@lru_cache(None)
def canonical(w):
 out=[];sg=1
 for token in w:
  if par[token[0]] and token in out:return (),0
  at=len(out)
  while at and out[at-1]>token:
   if par[token[0]] and par[out[at-1][0]]:sg=-sg
   at-=1
  out.insert(at,token)
 return tuple(out),sg
def product(p,q):
 out={}
 for (gp,xp,hp,m,w),c in p.items():
  for (gq,xq,hq,n,v),d in q.items():
   word,sg=canonical(w+v)
   if sg:put(out,(gp+gq,xp+xq,hp+hq,m^n,word),c*d*(sg*factors[m,n]))
 return out
@lru_cache(None)
def coefficients(text):
 z=s.expand(s.sympify(text,locals=loc));out={}
 assert not z.has(s.Float) and z.free_symbols<={g,xi,eta}
 for powers,co in s.Poly(z,g,xi,eta).terms():
  for term in s.Add.make_args(s.expand(co)):
   rat,rest=term.as_coeff_Mul(rational=True);assert rat.is_Rational;number=F(int(rat.p),int(rat.q));mask=0
   for factor in s.Mul.make_args(rest):
    if factor==s.I:mask^=16
    elif factor.is_Rational:number*=F(int(factor.p),int(factor.q))
    else:
     assert factor.is_Pow and factor.exp==s.Rational(1,2) and factor.base.is_Integer and factor.base>0,factor
     value=int(factor.base)
     for bit,prime in enumerate(squares[:4]):
      exponent=0
      while value%prime==0:value//=prime;exponent+=1
      number*=prime**(exponent//2)
      if exponent%2:mask^=1<<bit
     assert value==1
   put(out,(*powers,mask),number)
 return tuple(out.items())
def token(t):
 n,_,j=t.partition('__');return index[n],tuple(map(int,j))
def rows(rr):
 out={}
 for row in rr:
  w=tuple(map(token,row['word']));assert canonical(w)==(w,1)
  for (gp,xp,hp,m),v in coefficients(row['coefficient']):
   if 'g' in row:assert gp==0;gp=row['g']
   put(out,(gp,xp,hp,m,w),v)
 return out
def unpack(packet):
 out={}
 for gp,word,cid in packet['monomials']:
  w=tuple((n,tuple(j)) for n,j in word);assert canonical(w)==(w,1)
  for xp,hp,m,num,den in packet['coefficients'][cid]:put(out,(gp,xp,hp,m,w),F(num,den))
 return out
def elem(n,j=()):
 if isinstance(n,str):n=index[n]
 return {(0,0,0,0,((n,j),)):F(1)}
def D(p,mu):
 out={}
 for(gp,xp,hp,m,w),v in p.items():
  for at,(n,j) in enumerate(w):
   word,sg=canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
   if sg:put(out,(gp,xp,hp,m,word),v*sg)
 return out
def DD(p,j):
 for mu in j:p=D(p,mu)
 return p
def gradient(p):
 out={}
 for(gp,xp,hp,m,w),v in p.items():
  total=sum(par[n] for n,j in w)%2
  for at,(n,j) in enumerate(w):
   suffix=sum(par[t] for t,k in w[at+1:]);sg=(-1)**((par[n]*suffix+par[n]*(total-par[n]))%2);put(out.setdefault((n,j),{}),(gp,xp,hp,m,w[:at]+w[at+1:]),v*sg)
 return out
def EL(p,domain):
 out={n:{} for n in domain}
 for(n,j),df in gradient(p).items():
  if n in domain:out[n]=add(out[n],scaled(DD(df,j),(-1)**len(j)))
 return out
def vector(p):
 el=EL(p,canon);v={}
 for i in fields:v[i]=scaled(el[Jof[i]],-(-1)**par[i]);v[Jof[i]]=scaled(el[i],(-1)**par[i])
 return v
def operation(images,odd=False):
 images={n:p for n,p in images.items() if p};cache={}
 def act(p):
  out={}
  for(gp,xp,hp,m,w),c in p.items():
   total=sum(par[n] for n,j in w)%2
   for at,(n,j) in enumerate(w):
    if n not in images:continue
    if(n,j) not in cache:cache[n,j]=DD(images[n],j)
    suffix=sum(par[t] for t,k in w[at+1:]);sg0=(-1)**((par[n]*suffix+(total+par[n] if odd else 0))%2);rest=w[:at]+w[at+1:]
    for(gq,xq,hq,mask,repl),v in cache[n,j].items():
     word,sg=canonical(rest+repl)
     if sg:put(out,(gp+gq,xp+xq,hp+hq,m^mask,word),c*v*(sg0*sg*factors[m,mask]))
  return out
 return act
def collapsed(p):
 out={}
 for(gp,xp,hp,m,w),v in p.items():out.setdefault((gp,w),{})[xp,hp,m]=v
 return out
def summary(p):
 h=sha256();h.update(b'[');cc=collapsed(p)
 for i,((gp,w),co) in enumerate(sorted(cc.items())):
  if i:h.update(b',')
  row=[gp,[[names[n],list(j)] for n,j in w],[[list(k),str(v)] for k,v in sorted(co.items())]];h.update(json.dumps(row,separators=(',',':'),ensure_ascii=True).encode())
 h.update(b']');return {'g_word_positions':len(cc),'field_words':len({w for gp,w in cc}),'sha256_exact_cells':h.hexdigest()}

def mul(*pp):
 out={(0,0,0,0,()):F(1)}
 for p in pp:out=product(out,p)
 return out
def subst(p,images):
 out={}
 for(gp,xp,hp,m,w),c in p.items():
  pp={(gp,xp,hp,m,()):c}
  for n,j in w:pp=product(pp,DD(images.get(n,elem(n)),j))
  for key,value in pp.items():put(out,key,value)
 return out
def scalar(z):return rows([{'word':[],'coefficient':str(z)}])

bn=[[index[f'B{i}_{mu}'] for mu in range(4)] for i in range(45)];an=[index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];ln=[index[('b' if i<12 else 'L')+str(i)] for i in range(45)];cn=[index[f'C{i}'] for i in range(45)]
jl=[Jof[i] for i in ln];ja=[Jof[i] for i in an];jset=set(jl);rho=[index['spc_rho'+str(i)] for i in range(4)];rs=set(rho);corefields={n for b in bn for n in b}|set(an+ln+cn)
jc=[Jof[n] for n in cn];bg=[index['spc_a'+str(i)] for i in range(45)];bgmap=dict(zip(an,bg))
extweight={**dict.fromkeys(jl+bg,1),**dict.fromkeys(jc,2)};extset=set(extweight)
qvec=[F(1),F(0),F(0),F(0)]
def wick(p):
 out={}
 for(gp,xp,hp,m,w),c in p.items():
  term={(gp,xp,hp,m,w):-c}
  for n,j in w:
   term=product(term,scalar('I' if n in {b[0] for b in bn} else '-I' if n in set(ln+jl) else '-1' if n in set(ja+jc) else '1'))
   for k in range(j.count(0)):term=product(term,scalar('I'))
  for key,value in term.items():put(out,key,value)
 return out
def hess(p,wrong=False):
 out={}
 for(n,I),f in gradient(p).items():
  if n not in corefields:continue
  for(m,J),co in gradient(f).items():
   if m not in corefields:continue
   co=subst(co,{n:elem(bgmap[n]) for n in an})
   co={k:c for k,c in co.items() if not any(t in fields or j for t,j in k[-1]) and all(t in extset|rs for t,j in k[-1])}
   if any(any(t in extset|rs for t,j in k[-1]) for k in co):assert len(I)+len(J)<=1,'COMPLETE_VERTEX_MOMENTUM_DEGREE'
   factor=scalar(str((-1)**(par[m]*(par[n]+1)) if not wrong else 1))
   for mu in I:factor=mul(factor,scalar(str(qvec[mu])),scalar('-I'))
   for mu in J:factor=mul(factor,scalar(str(qvec[mu])),scalar('I'))
   z=product(co,factor)
   if z:out[n,m]=add(out.get((n,m),{}),z)
 return {k:p for k,p in out.items() if p}
def trim(p):return {k:c for k,c in p.items() if sum(extweight.get(n,0) for n,j in k[-1])<=2 and sum(n in rs for n,j in k[-1])<=2}
def mm(A,B):
 by=defaultdict(list);out={}
 for(k,j),p in B.items():by[k].append((j,p))
 for(i,k),p in A.items():
  for j,q in by[k]:
   z=trim(product(p,q))
   if z:out[i,j]=add(out.get((i,j),{}),z)
 return {k:p for k,p in out.items() if p}
def st(M):return add(*(scaled(p,(-1)**(par[i] if i<len(par) else 0)) for(i,j),p in M.items() if i==j))
def target(p,r,t):return {k:c for k,c in p.items() if sum(extweight.get(n,0) for n,j in k[-1])==2 and {n for n,j in k[-1] if n in rs}=={rho[r],rho[t]}}
def frommat(pkt):return {(i,j):unpack(p) for i,j,p in pkt}
Hs=[hess(wick(mul(elem(rr),unpack(p)))) for rr,p in zip(rho,P['physical_G'])]
fullV=hess(wick(unpack(P['source_action_physical'])))
V={k:{z:c for z,c in p.items() if any(n in extset for n,j in z[-1])} for k,p in fullV.items()};V={k:p for k,p in V.items() if p}
for H,pkt in zip(Hs,P['principal_vertices']):assert H==frommat(pkt)
assert V==frommat(P['source_vertex'])
print('STAGE verifier independent_full_physical_vertex_differentiation',flush=True)
# Complete Fourier-coefficient audit: degree<=1 was checked before evaluation.
densities=[wick(mul(elem(rr),unpack(p))) for rr,p in zip(rho,P['physical_G'])]
srcdensity=wick(unpack(P['source_action_physical']))
for axis in [1,2,3]:
 qvec=[F(int(mu==axis)) for mu in range(4)]
 swap={bn[i][0]:bn[i][axis] for i in range(45)}|{bn[i][axis]:bn[i][0] for i in range(45)}
 for expected,density in list(zip(Hs,densities))+[(V,srcdensity)]:
  got=hess(density)
  if expected is V:got={k:q for k,p in got.items() if (q:={z:c for z,c in p.items() if any(n in extset for n,j in z[-1])})}
  assert got=={(swap.get(i,i),swap.get(j,j)):p for (i,j),p in expected.items()},('FULL_FOURIER_AXIS_COVARIANCE',axis)
 print('STAGE verifier complete_momentum_axis_'+str(axis),flush=True)
qvec=[F(1),F(0),F(0),F(0)]

G={}
for i in range(45):
 width=scalar('eta_H' if i<12 else 'xi')
 for mu in range(4):
  for nu in range(4):
   z=add(scalar(str(int(mu==nu))),scaled(add(width,scalar('-1')),qvec[mu]*qvec[nu]))
   if z:G[bn[i][mu],bn[i][nu]]=z
  if qvec[mu]:G[bn[i][mu],ln[i]]=scalar(str(-qvec[mu]));G[ln[i],bn[i][mu]]=scalar(str(qvec[mu]))
 G[cn[i],an[i]]=scalar('1');G[an[i],cn[i]]=scalar('-1')
# Recheck the mixed Gaussian by independently integrating the boson first.
b0,a0,c0=bn[0][0],an[0],cn[0];rr,lam=rho[0],jl[0]
toyV=add(mul(elem(rr),elem(a0),elem(b0)),mul(elem(lam),elem(c0),elem(b0)));Gt={(b0,b0):scalar('1'),(c0,a0):scalar('-1'),(a0,c0):scalar('1')}
Hv=hess(toyV);raw=scaled(st(mm(mm(Gt,Hv),mm(Gt,Hv))),F(-1,4))
f=add(mul(elem(rr),elem(a0)),mul(elem(lam),elem(c0)));w=add(scaled(mul(elem(c0),elem(a0)),-1),scaled(product(f,f),F(1,2)))
Z=gradient(gradient(w)[a0,()])[c0,()];direct=add(scalar('1'),scaled(Z,-1))
assert raw==direct==unpack(P['mixed_Gaussian']) and raw!=unpack(P['wrong_mixed_Gaussian'])
def selectdegree(M,d):
 return {k:q for k,p in M.items() if (q:={z:c for z,c in p.items() if sum(extweight.get(n,0) for n,j in z[-1])==d})}
def closedpaths(matrices):
 if any(not M for M in matrices):return {}
 indexes=[]
 for M in matrices[1:]:
  row=defaultdict(list)
  for (i,j),p in M.items():row[i].append((j,p))
  indexes.append(row)
 out={}
 def walk(origin,at,depth,p):
  if depth==len(indexes):
   if at==origin:
    for k,c in p.items():put(out,k,c*(-1 if origin<len(par) and par[origin] else 1))
   return
  for j,q in indexes[depth].get(at,[]):
   if depth==len(indexes)-1 and j!=origin:continue
   z=trim(product(p,q))
   if z:walk(origin,j,depth+1,z)
 for(i,j),p in matrices[0].items():walk(i,j,0,p)
 return out
def paircoefficients(G,Hs,V,r,t):
 GH={d:[mm(G,selectdegree(H,d)) for H in Hs] for d in [0,1]}
 W={d:mm(G,selectdegree(V,d)) for d in [1,2]}
 assert all(selectdegree(H,0)|selectdegree(H,1)==H for H in Hs)
 out={str(n):{} for n in [2,3,4]}
 if not Hs[r] or not Hs[t]:return out
 out['2']=scaled(target(closedpaths([GH[1][r],GH[1][t]]),r,t),F(-1,2))
 for a,b,c in [(0,1,1),(1,0,1),(0,0,2)]:
  for word in [[GH[a][r],GH[b][t],W[c]],[GH[a][r],W[c],GH[b][t]]]:out['3']=add(out['3'],scaled(target(closedpaths(word),r,t),F(1,2)))
 for word in [[GH[0][r],GH[0][t],W[1],W[1]],[GH[0][r],W[1],GH[0][t],W[1]],[GH[0][r],W[1],W[1],GH[0][t]]]:out['4']=add(out['4'],scaled(target(closedpaths(word),r,t),F(-1,2)))
 return out
nonzero={};allzero=0
for r,t in combinations(range(4),2):
 key=str(r)+','+str(t);print('STAGE verifier polarized_'+key,flush=True);out=paircoefficients(G,Hs,V,r,t)
 for n in ['2','3','4']:assert out[n]==unpack(P['pair_tensors'][key][n]),(key,n)
 # Reconstruct one additional transverse vector direction and repeat ALL groups.
 G5=dict(G);H5=[dict(H) for H in Hs]
 for i in range(45):
  ii=len(names)+i;G5[ii,ii]=scalar('1')
  for j in range(45):
   jj=len(names)+j
   for z in range(4):
    p=Hs[z].get((bn[i][0],bn[j][0]),{})
    if p:H5[z][ii,jj]=p
 lifted=paircoefficients(G5,H5,V,r,t)
 jet=add(lifted['2'],scaled(out['2'],-1));assert jet==unpack(P['pair_tensors'][key]['Djet'])
 assert lifted['3']==out['3'] and lifted['4']==out['4']
 total=add(*out.values());assert total==unpack(P['pair_tensors'][key]['common_chi4'])
 assert scaled(jet,-2)==unpack(P['pair_tensors'][key]['finite_Djet'])
 for p in list(out.values())+[jet]:
  assert all(sum(extweight.get(n,0) for n,j in w)==2 and sum(n in rs for n,j in w)==2 and not any(j for n,j in w) for gp,xp,hp,m,w in p)
  for gp,xp,hp,m,w in p:
   ext=[n for n,j in w if n not in rs]
   assert (len(ext)==1 and ext[0] in jc) or (len(ext)==2 and all(n in set(jl+bg) for n in ext))
 nonzero[key]={n:len(collapsed(p)) for n,p in out.items()};nonzero[key]['Djet']=len(collapsed(jet));allzero+=int(not total)
# Exhaust the concrete local words (not an inferred output support list).
domain=[(n,) for n in jc]+list(combinations(jl,2))+[(n,m) for n in jl for m in bg]+list(combinations(bg,2))
assert len(domain)==len(set(domain))==4050
assert P['carrier_census']=={'JC':45,'JLJL':990,'JLa':2025,'aa':990}
# Old highest-source projection is authenticated reuse, not a fresh old run.
old=json.loads(gzip.decompress((R/'calculations/canonical_so10_source_probe_pair/primary_tables.json.gz').read_bytes()))
for k,d in P['pair_tensors'].items():
 for n in ['2','3','4','Djet','common_chi4','finite_Djet']:
  pp=unpack(d[n]);assert not {z:c for z,c in pp.items() if sum(i in jset for i,j in z[-1])==2}
  assert old['pair_tensors'][k][n]['positions']==0
# Exact radial normalization, without setting the common free constant.
eps,m2,nlog=s.symbols('eps m2 n_log',positive=True);radial={}
for n in [2,3,4]:
 ratio=s.gamma(n-eps)/(s.gamma(2-eps)*s.gamma(n));derivative=s.simplify(s.diff(ratio,eps).subs(eps,0));assert derivative==1-s.harmonic(n-1)
 df=s.log(4*s.pi)-s.EulerGamma-s.log(m2)+derivative
 hf=-s.EulerGamma-s.log(2*n)-s.log(m2)-s.harmonic(n-1)+nlog
 difference=s.expand_log(df-hf,force=True);expect=1+s.log(16*s.pi)-nlog+s.log(s.Rational(n,2))
 assert s.simplify(difference-expect)==0
 radial[str(n)]=str(s.simplify(difference-(1+s.log(16*s.pi)-nlog)))
receipt={'schema':'SOURCE_PROBE_PAIR_VALIDATION_V1','scientific_disposition':'QUALIFIED_COMPLETE_SATURATED_LOCAL_PAIR_CARRIER_OF_ACTUAL_FOUR_COMPONENT_POLARIZATION_FAMILY','complete_pairs':6,'carrier_positions_per_pair':4050,'carrier_census':P['carrier_census'],'nonzero_group_positions':nonzero,'pairs_with_zero_total_pole':allzero,'all_full_physical_vertices_independently_differentiated':True,'raw_to_physical_transport_reconstructed_by_native_routes_not_third_time':True,'all_group_contractions_fresh_expanded_arithmetic':True,'Djet_by_one_extra_transverse_component':True,'all_four_axes_exhaust_linear_vertex_symbols':True,'grade_resolved_closed_index_paths':True,'radial_relative_shifts':radial,'mixed_Gaussian_orientation_and_wrong_sign_control':True,'full_nonlocal_kernel_or_second_Ward_identity_QAP':False,'authority_changed':False,'shared_action_software_AI_authorship':True,'elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(receipt,sort_keys=True),flush=True);watch.cancel()
