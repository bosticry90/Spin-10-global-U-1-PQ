# Grade-resolved replay and closed-path verification

V2 primary completed502.109s and wrote complete arrays. V2 replay reached
the600s watchdog before a result; the V2 verifier was never launched. Both
this exhaustion and original primary exhaustion are preserved; no failed
or unfinished run supplies a validation receipt. Primary's56-position
finite tensor remains PROVISIONAL until this new comparison completes.

Reassessment: the dense unit direction expands sparse vector paths, while
ungraded products construct many external degrees that cannot contribute.
V3 keeps the physical target, inputs, acceptance and caps unchanged. It reuses
the completed V2 PRIMARY rather than repeating it. Replay uses unit direction
(0,0,0,1). A fresh verifier checks all four unit axes and proves the surviving
vertices are at most linear in q, so the axis check exhausts their momentum
coefficients. BB metric and mixed q-vector shapes remain explicit.

Exact degree decomposition: H_r=H_r0+H_r1, V=V1+V2, where degree counts
JL/a_bg as1, JC as2 and ignores rho. Target degree2 leaves only

 n2: H_r1 H_s1;
 n3: (H_r0,H_s1,V1),(H_r1,H_s0,V1),(H_r0,H_s0,V2), all orders;
 n4: H_r0 H_s0 V1 V1, all orders.

There is no H_r2. The native route still differentiates the dressed inverse;
finite graded matrix cyclicity roots its terms at H_r before multiplication.
An empty H_r is a structural zero, not an invitation to build V squared.
The verifier instead enumerates closed index paths before multiplying exact
expanded cells. This changes the computational method, not the graph list.
All finite-length and D-jet checks, zero complements and wrong controls stay.

One bounded continuation: replay600s, separate verifier600s; same8GiB sampled
private/350MiB launch floor/16MiB packet. Freeze new sources and all old
evidence. If this organization fails, preserve it and stop this computational
attempt for reassessment; no further cap expansion or automatic full rerun.
