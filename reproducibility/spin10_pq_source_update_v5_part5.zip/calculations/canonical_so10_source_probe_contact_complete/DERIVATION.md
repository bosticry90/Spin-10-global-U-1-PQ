# Complete saturated local carrier and ordered kernel

The project grades B,x,A,C,a,Lambda are dimensions1,1,1,1,1,2 and ghosts
0,0,0,1,-1,0. BV sources JB,Jx,JC,Ja,JL have dimensions2,2,2,2,1,
ghosts-1,-1,-2,0,-1, parities1,1,0,0,1. With rho dimension1,ghost1,odd,
the rho_r rho_s coefficient is dimension2,ghost-2,even. Enumerating all
one- and two-factor carriers of dimension<=2 leaves exactly JC, JLJL,
JL*a, aa. Each saturates the dimension budget. Jets and positive-dimensional
coefficients cannot occur. Covariance/reality restrict tensors within this
carrier;4050 is not the invariant rank or a count of independent counterterms.

Write a=A_bg+delta a, but implement this by differentiating the FULL density
twice in its original ordinary coordinates before replacing residual a by
A_bg. Dropping a before Hessian differentiation loses mixed and ghost
vertices. Residual antighost jets are absent in the saturated target, not
discarded in a general kernel. All other ordinary backgrounds are zero.

The principal action Hessian is H0+V, where V contains the Taylor projections
of GF, JL*qLambda and JC*qC. Its coefficients have external weight1 or2;
H_r=H_(rho_r G_r) has external weight0 or1 apart from rho. Thus two probe
vertices and at most two V vertices exhaust the weight2 carrier. The full
answer is the rho pair projection of ordered log words n=2,3,4. A vertex
with JC or a*a already carries weight2. No source inverse term is omitted.
The replay uses -STr(G_V H_r G_V H_s)/2 with
G_V=G-GVG+GVGVG to the same weight. Cyclicity here is finite graded matrix
algebra at fixed UV-symbol order, not unqualified finite-part trace cyclicity.

Wick pullback extends the SAME source-dual rule: fields B0_M=iB0_E,
Lambda_M=-iLambda_E, C/a unchanged; sources satisfy
J_i,M * (field phase_i)=-J_i,E. Hence JL_M=-iJL_E,
Ja_M=-Ja_E and JC_M=-JC_E. This preserves the same common BV two-form
phase on every field/source pair, rather than choosing JC independently.
New rho and A_bg use identity pullback; S_E=-S_M, dt derivatives gain i.
Use Frechet H_ij=(-1)^[p_j(p_i+1)]partial_left,j partial_left,i S, with
(-iq)^I(iq)^J on fluctuation jets. Check the actual free two-sided inverse.

All surviving zero-external-jet tensors are scalar in loop momentum. Check
BB metric and mixed q_mu shapes, with scalar odd/aux blocks. V has no BB
block. Only the BB bubble may carry a closed D trace. A fresh extra
transverse component tests triangles/boxes rather than assuming their jet0.
The inherited radial comparisons for lengths4,6,8 give

 Crel=chi4*(T2+T3+T4)+log(3/2)*T3+log2*T4-2*A,
 A=partial_D T2 at4, chi4=1+log(16pi)-n_log.

All tensors are in 1/(16pi^2) density units; chi4,kappa,b0 and IR constants
remain distinct/free. This is a local RELATIVE comparison; retain the full
convergent ordered remainder U, reference/measure responses and second Ward
breaking B1 as unextracted, not zero. No addition to the ordinary rho0 Gamma.
