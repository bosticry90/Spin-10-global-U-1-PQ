from pathlib import Path
O=Path(__file__).resolve().parent
def save(n,t):
 with (O/n).open('x',encoding='utf-8',newline='\n') as f:f.write(t)
def change(t,a,b):
 assert a in t,a[:100]
 return t.replace(a,b)
t=(O/'pair_v2.py').read_text(encoding='utf-8')
t=change(t,"'preparation_v2.json'","'preparation_v3.json'")
t=change(t,"role+'_v2_tables.json.gz'","role+'_v3_tables.json.gz'")
t=change(t,"else [F(1,2)]*4","else [F(0),F(0),F(0),F(1)]")
start=t.index(' def kernel(r,s):');end=t.index(' result={}',start)
t=t[:start]+''' def degree(M,d):
  return {k:q for k,p in M.items() if (q:={z:c for z,c in p.items() if sum(extweight.get(n,0) for n,j in z[1])==d})}
 H0=[mm(G,degree(h,0)) for h in H];H1=[mm(G,degree(h,1)) for h in H]
 assert all(madd(degree(h,0),degree(h,1))==h for h in H)
 VV={d:mm(G,degree(V,d)) for d in [1,2]}
 def chain(*args):
  out=args[0]
  for b in args[1:]:out=mm(out,b)
  return st(out)
 def kernel(r,s):
  out={str(n):{} for n in [2,3,4]}
  if H[r] and H[s]:
   out['2']=scale(target(chain(H1[r],H1[s]),r,s),F(-1,2))
   for a,b,v in [(0,1,1),(1,0,1),(0,0,2)]:
    L=(H0 if a==0 else H1)[r];B=(H0 if b==0 else H1)[s];W=VV[v]
    out['3']=add(out['3'],scale(target(add(chain(L,B,W),chain(L,W,B)),r,s),F(1,2)))
   L=H0[r];B=H0[s];W=VV[1]
   out['4']=scale(target(add(chain(L,W,W,B),chain(L,W,B,W),chain(L,B,W,W)),r,s),F(-1,2))
  extra={}
  for i in range(45):
   for j in range(45):extra=add(extra,scale(mul(H[r].get((bn[i][0],bn[j][0]),{}),H[s].get((bn[j][0],bn[i][0]),{})),F(-1,2)))
  out['Djet']=target(extra,r,s);out['common_chi4']=add(out['2'],out['3'],out['4']);out['finite_Djet']=scale(out['Djet'],-2)
  return out
''' +t[end:]
save('pair_v3.py',t)
v=(O/'verify_v2.py').read_text(encoding='utf-8')
v=change(v,"'validation_preparation_v2.json'","'validation_preparation_v3.json'")
v=change(v,"(O/'replay_v2_tables.json.gz')","(O/'replay_v3_tables.json.gz')")
v=change(v,"cap=read(O/(role+'_v2_capture.json'))","cap=read(O/(role+('_v2_capture.json' if role=='primary' else '_v3_capture.json')))")
v=change(v,"   factor=scalar(str((-1)**(par[m]*(par[n]+1)) if not wrong else 1))","   if any(any(t in extset|rs for t,j in k[-1]) for k in co):assert len(I)+len(J)<=1,'COMPLETE_VERTEX_MOMENTUM_DEGREE'\n   factor=scalar(str((-1)**(par[m]*(par[n]+1)) if not wrong else 1))")
mark="print('STAGE verifier independent_full_physical_vertex_differentiation',flush=True)"
v=change(v,mark,mark+'''
# Complete Fourier-coefficient audit: degree<=1 was checked before evaluation.
densities=[wick(mul(elem(rr),unpack(p))) for rr,p in zip(rho,P['physical_G'])]
srcdensity=wick(unpack(P['source_action_physical']))
for axis in [1,2,3]:
 qvec=[F(int(mu==axis)) for mu in range(4)]
 swap={bn[i][0]:bn[i][axis] for i in range(45)}|{bn[i][axis]:bn[i][0] for i in range(45)}
 for expected,density in list(zip(Hs,densities))+[(V,srcdensity)]:
  got=hess(density)
  if expected is V:got={k:q for k,p in got.items() if (q:={z:c for z,c in p.items() if any(n in extset for n,j in z[-1])})}
  assert got=={(swap.get(i,i),swap.get(j,j)):p for (i,j),p in expected.items()},('FULL_FOURIER_AXIS_COVARIANCE',axis)
 print('STAGE verifier complete_momentum_axis_'+str(axis),flush=True)
qvec=[F(1),F(0),F(0),F(0)]
''')
start=v.index('def paircoefficients(');end=v.index('nonzero={}',start)
v=v[:start]+'''def selectdegree(M,d):
 return {k:q for k,p in M.items() if (q:={z:c for z,c in p.items() if sum(extweight.get(n,0) for n,j in z[-1])==d})}
def closedpaths(matrices):
 if any(not M for M in matrices):return {}
 indexes=[]
 for M in matrices[1:]:
  row=defaultdict(list)
  for (i,j),p in M.items():row[i].append((j,p))
  indexes.append(row)
 out={}
 def walk(origin,at,depth,p):
  if depth==len(indexes):
   if at==origin:
    for k,c in p.items():put(out,k,c*(-1 if origin<len(par) and par[origin] else 1))
   return
  for j,q in indexes[depth].get(at,[]):
   if depth==len(indexes)-1 and j!=origin:continue
   z=trim(product(p,q))
   if z:walk(origin,j,depth+1,z)
 for(i,j),p in matrices[0].items():walk(i,j,0,p)
 return out
def paircoefficients(G,Hs,V,r,t):
 GH={d:[mm(G,selectdegree(H,d)) for H in Hs] for d in [0,1]}
 W={d:mm(G,selectdegree(V,d)) for d in [1,2]}
 assert all(selectdegree(H,0)|selectdegree(H,1)==H for H in Hs)
 out={str(n):{} for n in [2,3,4]}
 if not Hs[r] or not Hs[t]:return out
 out['2']=scaled(target(closedpaths([GH[1][r],GH[1][t]]),r,t),F(-1,2))
 for a,b,c in [(0,1,1),(1,0,1),(0,0,2)]:
  for word in [[GH[a][r],GH[b][t],W[c]],[GH[a][r],W[c],GH[b][t]]]:out['3']=add(out['3'],scaled(target(closedpaths(word),r,t),F(1,2)))
 for word in [[GH[0][r],GH[0][t],W[1],W[1]],[GH[0][r],W[1],GH[0][t],W[1]],[GH[0][r],W[1],W[1],GH[0][t]]]:out['4']=add(out['4'],scaled(target(closedpaths(word),r,t),F(-1,2)))
 return out
''' +v[end:]
v=change(v,"'Djet_by_one_extra_transverse_component':True","'Djet_by_one_extra_transverse_component':True,'all_four_axes_exhaust_linear_vertex_symbols':True,'grade_resolved_closed_index_paths':True")
save('verify_v3.py',v)
p=(O/'prepare_v2.py').read_text(encoding='utf-8')
start=p.index("failure=json.loads")
p=p[:start]+'''failure=json.loads((O/'replay_v2_capture.json').read_bytes());assert failure['exit_code']==124 and not failure['calculation_completed']
assert not (O/'validation_receipt_v2.json').exists()
files.extend(p for p in O.iterdir() if p.is_file())
for n in ['CONTINUATION_V3.md','build_v3.py','pair_v3.py','verify_v3.py','prepare_v3.py','run_v3.py']:
 p=O/n
 with (O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
files.extend(O.glob('*.source.txt'))
dump(O/'preparation_v3.json',{'base':base,'input_sha256':{str(p):H(p) for p in sorted(set(files))},'artifacts':art,'read_json_by_role':{r:[a['reference'],a['e2']] for r,a in art.items()},'limits':old['limits'],'scientific_acceptance':'NOT_PERFORMED','two_prior_resource_exhaustions':'PRESERVED_NOT_QUALIFIED'})
print('PREPARED_SPC1_V3',len(set(files)))
'''
save('prepare_v3.py',p)
r=(O/'run_v2.py').read_text(encoding='utf-8')
r=change(r,"for role in ['primary','replay','verify']:","for role in ['replay','verify']:")
for a,b in [('prepare_v2.py','prepare_v3.py'),('preparation_v2_capture.json','preparation_v3_capture.json'),('preparation_v2_full_capture.json','preparation_v3_full_capture.json'),("'preparation_v2.json'","'preparation_v3.json'"),("'validation_preparation_v2.json'","'validation_preparation_v3.json'"),('verify_v2.py','verify_v3.py'),('pair_v2.py','pair_v3.py'),("role+'_v2_capture.json'","role+'_v3_capture.json'"),("role+'_v2_full_capture.json'","role+'_v3_full_capture.json'"),("role+'_v2_tables.json.gz'","role+'_v3_tables.json.gz'"),("'validation_receipt_v2.json' if role=='verify' else role+'_v2_result.json'","'validation_receipt_v3.json' if role=='verify' else role+'_v3_result.json'"),('controller_failure_v2.json','controller_failure_v3.json')]:r=change(r,a,b)
save('run_v3.py',r)
print('BUILT_GRADE_RESOLVED_V3')
