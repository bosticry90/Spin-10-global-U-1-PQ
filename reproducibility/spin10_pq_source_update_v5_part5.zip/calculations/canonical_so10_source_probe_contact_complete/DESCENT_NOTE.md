# Following the measured contact into the existing probe doublet

Question: does the nonzero rho0*rho1 contact by itself demonstrate an
algebraic obstruction, or is there a possible correlated LOCAL probe
completion? This is an analytic follow-through after the local quantum
measurement, not another loop computation or an accepted subtraction choice.

Let P=rho0*rho1*p, using the verified tensor in RESULT. Replace residual
antighost bookkeeping labels by the actual ordinary antighost before taking
Q. The local p is even, dimension2,ghost-2; parameters are inert in the same
frozen ring. Use the actual qualified classical Q, not a source-free proxy.
Both Euler legs are required:

 Qp=i*g10^2*xi*eta_H^2*sum Kij[(Q JL_i)*a_j-JL_i*(Q a_j)].

This formula preserves all field/source companions of the actual Q columns.
It does NOT supply a newly evaluated coefficient table or a generic-w/h
extension of the fixed-reference quantum result.
All equalities are of integrated local functionals modulo the admitted
boundary currents. Local probes remain Schwartz functions; Euler adjoints
must retain their derivative companions rather than treating u/rho as constants.

For the already existing even u and odd rho, d u_r=rho_r, Q u=Q rho=0,
d rho=0. Then s0=Q+d is nilpotent in the inherited classical domain. Set

 Omega=(u0*rho1-u1*rho0)*p/2,
 E=s0 Omega=rho0*rho1*p-(u0*rho1-u1*rho0)*Qp/2.

Omega is odd dimension3,ghost-1; E is even dimension4,ghost0. Direct graded
Leibniz differentiation gives d Omega=rho0*rho1*p and
Q Omega=-(u0*rho1-u1*rho0)*Qp/2. Q^2=d^2=Qd+dQ=0 hence s0 E=0.
The actual augmented differential differs from s0 by probe degree>=1, so
this is a closure statement through quadratic probe degree. Dropping the
mixed term leaves rho0*rho1*Qp; its actual coefficients have not been
extracted here and no measured sensitivity or zero is asserted for them.

This constructs a symbolic algebraic candidate in the graded local carrier.
It is NOT proof of admissibility under all background/reality/normalization
conditions, an H-basic/C5 construction, or a measured renormalized u*rho
product. It does not cancel independently unknown quantum terms by decree.
The actual mixed kernel and all lower-order bracket companions must be
derived from S_ext and compared with the candidate before any quantum Ward
claim. Nonlocal U and the reference/measure defects remain explicit. Kappa,
b0 and IR constants have not been identified or fixed.

Thus the finite term is not by itself an algebraic anomaly finding. The
next test is concrete: does the actual mixed quantum construction supply a
compatible descendant once its other required terms are included? Preserve
a mismatch or underdefinition instead of assigning that descendant its
desired value. No change to scientific authority or physical assumptions.
