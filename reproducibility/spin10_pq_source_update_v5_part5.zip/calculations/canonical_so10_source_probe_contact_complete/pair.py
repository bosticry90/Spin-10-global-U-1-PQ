"""Full ordered complete-local-carrier primitive-pair local symbols, no Ward fit."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from collections import defaultdict
from itertools import permutations,combinations
import gzip,json,sys,time,threading,os
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra,ONE,put,scale,scale_coefficient
read=lambda p:json.loads(p.read_bytes());dig=lambda p:sha256(p.read_bytes()).hexdigest()
def add(*polys):
 out={}
 for p in polys:
  for k,c in p.items():put(out,k,c)
 return out
def main():
 tick=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
 role=sys.argv[1];assert role in ['primary','replay'];prep=read(O/'preparation.json')
 for p,h in prep['input_sha256'].items():assert dig(Path(p))==h,p
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):assert p==O/(role+'_tables.json.gz')
  if p.suffix=='.json':assert str(p) in prep['read_json_by_role'][role],('SPP_JSON',str(p))
 sys.addaudithook(guard)
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry']
 A=Algebra(geo['names']+['spc_rho'+str(i) for i in range(4)]+['spc_a'+str(i) for i in range(45)],geo['parities']+[1]*49);rho=[A.index['spc_rho'+str(i)] for i in range(4)]
 pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};Jof={i:J for i,J,h,k in pairs};sources=set(Jof.values())
 bn=[[A.index[f'B{i}_{mu}'] for mu in range(4)] for i in range(45)]
 an=[A.index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];ln=[A.index[('b' if i<12 else 'L')+str(i)] for i in range(45)];cn=[A.index[f'C{i}'] for i in range(45)]
 jl=[Jof[i] for i in ln];ja=[Jof[i] for i in an];jset=set(jl);jpos={n:i for i,n in enumerate(jl)};rs=set(rho)
 jc=[Jof[n] for n in cn];bg=[A.index['spc_a'+str(i)] for i in range(45)]
 bgmap=dict(zip(an,bg));extweight={**dict.fromkeys(jl+bg,1),**dict.fromkeys(jc,2)}
 extset=set(extweight);corefields={n for b in bn for n in b}|set(an+ln+cn)
 # Exhaustive type enumeration, independent of the later graph projection.
 types={'B':(1,0,0,180),'x':(1,0,0,328),'A':(1,0,0,48),'C':(1,1,1,45),'a':(1,-1,1,45),'L':(2,0,0,45),'JB':(2,-1,1,180),'Jx':(2,-1,1,328),'JC':(2,-2,0,45),'Ja':(2,0,0,45),'JL':(1,-1,1,45)}
 candidates=[]
 for n,(d,h,p,count) in types.items():
  if d<=2 and h==-2 and p==0:candidates.append((n,))
 for n in types:
  for m in types:
   if n>m:continue
   d,h,p,_=types[n];e,k,q,_=types[m]
   if d+e<=2 and h+k==-2 and (p+q)%2==0:candidates.append((n,m))
 assert set(candidates)=={('JC',),('JL','JL'),('JL','a'),('a','a')}
 assert all(sum(types[n][0] for n in c)==2 for c in candidates)
 assert all(A.parities[n]==1 for n in jl+bg) and all(A.parities[n]==0 for n in jc)
 census={'JC':45,'JLJL':990,'JLa':2025,'aa':990};assert sum(census.values())==4050
 def elem(n,j=()):
  if isinstance(n,str):n=A.index[n]
  return {(0,((n,j),)):ONE}
 def scalar(z):return A.rows([{'coefficient':str(z),'word':[]}])
 def mul(*polys):
  p={(0,()):ONE}
  for q in polys:p=A.product(p,q)
  return p
 def rows(rr):return A.rows(rr)
 def stats(p):return {'positions':len(p),'sha256':A.fingerprint(p)}
 def pack(p):
  cs=[];ci={};rr=[]
  for(g,w),co in sorted(p.items()):
   if co not in ci:ci[co]=len(cs);cs.append([[*key,z.numerator,z.denominator] for key,z in co])
   rr.append([g,[[n,list(j)] for n,j in w],ci[co]])
  return {'coefficients':cs,'monomials':rr,**stats(p)}
 def unpack(p):
  cs=[tuple(((x,h,m),F(n,d)) for x,h,m,n,d in co) for co in p['coefficients']]
  return {(g,tuple((n,tuple(j)) for n,j in w)):cs[k] for g,w,k in p['monomials']}
 def D(p,mu):
  out={}
  for(g,w),co in p.items():
   for at,(n,j) in enumerate(w):
    ww,sg=A.canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
    if sg:put(out,(g,ww),scale_coefficient(co,sg))
  return out
 def DD(p,j):
  for mu in j:p=D(p,mu)
  return p
 def sub(p,mp):
  out={}
  for(g,w),co in p.items():
   term={(g,()):co}
   for n,j in w:term=mul(term,DD(mp.get(n,elem(n)),j))
   out=add(out,term)
  return out
 def grad(p):
  out={}
  for(g,w),co in p.items():
   total=sum(A.parities[n] for n,j in w);prefix=0
   for at,(n,j) in enumerate(w):
    if role=='primary':sg=(-1)**(A.parities[n]*prefix)
    else:sg=(-1)**(A.parities[n]*(total-prefix-A.parities[n]))*(-1)**(A.parities[n]*(total-A.parities[n]))
    put(out.setdefault((n,j),{}),(g,w[:at]+w[at+1:]),scale_coefficient(co,sg));prefix+=A.parities[n]
  return {k:p for k,p in out.items() if p}
 def wick(p):
  out={}
  for(g,w),co in p.items():
   fac=scalar('-1')
   for n,j in w:
    nm=A.names[n];phase='I' if n in {b[0] for b in bn} else '-I' if n in set(ln+jl) else '-1' if n in set(ja+jc) else '1'
    fac=mul(fac,scalar(phase),scalar('I') if j.count(0)%4==1 else scalar('-1') if j.count(0)%4==2 else scalar('-I') if j.count(0)%4==3 else scalar('1'))
   out=add(out,mul({(g,w):co},fac))
  return out
 qvec=[F(1),F(0),F(0),F(0)] if role=='primary' else [F(1,2)]*4
 assert sum(q*q for q in qvec)==1
 def hess(p,wrong=False):
  H={}
  for(n,I),f in grad(p).items():
   if n not in corefields:continue
   for(m,J),co in grad(f).items():
    if m not in corefields:continue
    # Project residual ordinary antighosts only AFTER both derivatives.
    co=sub(co,{n:elem(bgmap[n]) for n in an})
    co={k:z for k,z in co.items() if not any(t in fields or j for t,j in k[1])}
    if not co:continue
    co={k:z for k,z in co.items() if all(t in extset|rs for t,j in k[1])}
    fac=scalar(str((-1)**(A.parities[m]*(A.parities[n]+1)) if not wrong else 1))
    for mu in I:fac=mul(fac,scalar(str(qvec[mu])),scalar('-I'))
    for mu in J:fac=mul(fac,scalar(str(qvec[mu])),scalar('I'))
    co=mul(co,fac)
    if co:H[n,m]=add(H.get((n,m),{}),co)
  return {k:p for k,p in H.items() if p}
 def trim(p):return {k:c for k,c in p.items() if sum(extweight.get(n,0) for n,j in k[1])<=2 and sum(n in rs for n,j in k[1])<=2}
 def mm(L,B):
  by=defaultdict(list);out={}
  for(k,j),p in B.items():by[k].append((j,p))
  for(i,k),p in L.items():
   for j,q in by[k]:
    z=trim(mul(p,q))
    if z:out[i,j]=add(out.get((i,j),{}),z)
  return {k:p for k,p in out.items() if p}
 def st(L):return add(*(scale(p,(-1)**A.parities[i]) for(i,j),p in L.items() if i==j))
 def madd(*L):
  out={}
  for M in L:
   for k,p in M.items():out[k]=add(out.get(k,{}),p)
  return {k:p for k,p in out.items() if p}
 def mscale(M,z):return {k:scale(p,z) for k,p in M.items() if z}
 # Independent finite Gaussian calibration of the mixed even/odd Frechet map.
 b,a,c=bn[0][0],an[0],cn[0];rr,lam=rho[0],jl[0]
 toyV=add(mul(elem(rr),elem(a),elem(b)),mul(elem(lam),elem(c),elem(b)))
 Gtoy={(b,b):scalar('1'),(c,a):scalar('-1'),(a,c):scalar('1')}
 Hv=hess(toyV);rawtoy=scale(st(mm(mm(Gtoy,Hv),mm(Gtoy,Hv))),F(-1,4))
 f=add(mul(elem(rr),elem(a)),mul(elem(lam),elem(c)))
 w=add(scale(mul(elem(c),elem(a)),-1),scale(mul(f,f),F(1,2)))
 Z=grad(grad(w)[a,()])[c,()];normalized=add(scalar('1'),scale(Z,-1))
 assert rawtoy==normalized and normalized,('MIXED_GAUSSIAN_HESSIAN',stats(rawtoy),stats(normalized))
 wrongtoy=scale(st(mm(mm(Gtoy,hess(toyV,True)),mm(Gtoy,hess(toyV,True)))),F(-1,4))
 assert wrongtoy!=rawtoy
 print('STAGE '+role+' mixed_Gaussian_Frechet_orientation_qualified',flush=True)
 ref=read(Path(prep['artifacts'][role]['reference']))['retained_reference'];order=ref['field_order'];pos={n:i for i,n in enumerate(order)}
 phys=['']*643
 for i in range(45):
  for mu in range(4):phys[4*i+mu]=f'B{i}_{mu}'
 off=180
 for sec,count in [('Phi',54),('Sigma',252),('phi',20),('S',2)]:
  for i in range(count):phys[off+i]=f'x_{sec}_{i}'
  off+=count
 for i in range(45):phys[508+i]=A.names[ln[i]];phys[553+i]=f'C{i}';phys[598+i]=A.names[an[i]]
 assert set(phys)==set(order) and not any(not n for n in phys)
 T={(i,j):scalar(co) for i,j,co in ref['physical_to_raw_kernel']['entries']};Ti={(i,j):scalar(co) for i,j,co in ref['physical_to_raw_inverse']['entries']}
 frame={}
 for name,j in pos.items():
  n=A.index[name];frame[n]=add(*(mul(z,elem(phys[i])) for (r,i),z in Ti.items() if r==j))
  frame[Jof[n]]=add(*(mul(z,elem(Jof[A.index[phys[i]]])) for (i,r),z in T.items() if r==j))
 e2=read(Path(prep['artifacts'][role]['e2']));shifts={A.index[n]:rows(p) for n,p in e2['source_shifts'].items()};U={n:add(elem(n),p) for n,p in shifts.items()}
 old=json.loads(gzip.decompress(Path(prep['artifacts'][role]['seed']).read_bytes()));seed=unpack(old['actual_preU_seed'])
 parts=[{} for i in range(4)];labels=['M_light','M_heavy','N_light','N_heavy']
 for k,co in seed.items():
  g,w=k;jj=[jpos[n] for n,j in w if n in jset];assert jj and (all(i<12 for i in jj) or all(i>=12 for i in jj))
  tag=(0 if any(n in ja for n,j in w) else 2)+int(jj[0]>=12);put(parts[tag],k,co)
 assert add(*parts)==seed
 combined={n:sub(p,frame) for n,p in U.items()}
 physical=[]
 for p in parts:
  if role=='primary':physical.append(sub(sub(p,U),frame))
  else:physical.append(sub(p,{**frame,**combined}))
 # The actual scalar-bearing insertions are affine scalar/orbit pieces;
 # no quadratic scalar Hessian was silently excluded from the local target.
 scalarids={A.index[n] for n in phys if n.startswith('x_')}
 assert all(sum(n in scalarids for n,j in w)<=1 for p in physical for g,w in p)
 assert all(all(n in scalarids|set(an+jl) for n,j in w) and len(w)==2 for p in physical for g,w in p if any(n in scalarids for n,j in w))
 # Free gauge/auxiliary/odd density from actual GF; no reference mass change.
 gf=rows(data['gauge_fixing_density']);gf={k:c for k,c in gf.items() if k[0]==0 and len(k[1])==2 and all(n in corefields for n,j in k[1])}
 free=hess(wick(sub(gf,frame)))
 for i in range(45):
  for mu in range(4):
   for nu in range(4):
    z=F(int(mu==nu))-qvec[mu]*qvec[nu]
    if z:free[bn[i][mu],bn[i][nu]]=add(free.get((bn[i][mu],bn[i][nu]),{}),scalar(str(z)))
 G={}
 for i in range(45):
  width=scalar('eta_H' if i<12 else 'xi')
  for mu in range(4):
   for nu in range(4):
    z=add(scalar(str(int(mu==nu))),scale(add(width,scalar('-1')),qvec[mu]*qvec[nu]))
    if z:G[bn[i][mu],bn[i][nu]]=z
   if qvec[mu]:G[bn[i][mu],ln[i]]=scalar(str(-qvec[mu]));G[ln[i],bn[i][mu]]=scalar(str(qvec[mu]))
  G[cn[i],an[i]]=scalar('1');G[an[i],cn[i]]=scalar('-1')
 identity={(i,i):scalar('1') for i in corefields}
 assert mm(free,G)==identity and mm(G,free)==identity,('ACTUAL_FREE_TWO_SIDED_INVERSE',len(free),len(G))
 # All residual-a action terms and the full relevant source action.
 src=add(rows(data['gauge_fixing_density']),*(mul(elem(jl[i]),rows(data['master_field_maps'][A.names[ln[i]]])) for i in range(45)),*(mul(elem(jc[i]),rows(data['master_field_maps'][A.names[cn[i]]])) for i in range(45)))
 srcphys=sub(src,frame);fullV=hess(wick(srcphys))
 V={k:{z:c for z,c in p.items() if any(n in extset for n,j in z[1])} for k,p in fullV.items()};V={k:p for k,p in V.items() if p}
 assert V and all(1<=sum(extweight.get(n,0) for n,j in w)<=2 and not any(n in rs for n,j in w) for p in V.values() for g,w in p)
 assert not any(i in {n for b in bn for n in b} and j in {n for b in bn for n in b} for i,j in V)
 H=[hess(wick(mul(elem(rr),p))) for rr,p in zip(rho,physical)]
 # Entire explicit Lorentz tensor form, including the off-direction zero complement.
 for M in H+[V]:
  bb={(i,j):p for(i,j),p in M.items() if i in {n for b in bn for n in b} and j in {n for b in bn for n in b}}
  expected={}
  for i in range(45):
   for j in range(45):
    p=M.get((bn[i][0],bn[j][0]),{})
    if p:
     for mu in range(4):expected[bn[i][mu],bn[j][mu]]=p
  assert bb==expected,'EXPLICIT_BB_METRIC_SHAPE'
  for a in an+cn+ln:
   for b in bn:
    for left in [True,False]:
     vals=[M.get((a,z) if left else (z,a),{}) for z in b]
     chosen=next((mu for mu in range(4) if qvec[mu]),None)
     factor=scale(vals[chosen],1/qvec[chosen])
     assert all(p==scale(factor,qvec[mu]) for mu,p in enumerate(vals)),'EXPLICIT_MIXED_DIV_VECTOR_SHAPE'
  assert all(sum(extweight.get(n,0) for n,j in w)<=2 and sum(n in rs for n,j in w)==(0 if M is V else 1) for p in M.values() for g,w in p)
 print('STAGE '+role+' complete_physical_principal_vertices_and_source_inverse',flush=True)
 GH=[mm(G,h) for h in H];GV=mm(G,V)
 def target(p,r,s):
  return {k:c for k,c in p.items() if sum(extweight.get(n,0) for n,j in k[1])==2 and {n for n,j in k[1] if n in rs}=={rho[r],rho[s]}}
 def kernel(r,s):
  out={}
  for n in [2,3,4]:
   value={}
   if role=='primary':
    words=sorted(set(permutations([r,s]+[-1]*(n-2))))
    for word in words:
     M=GV if word[0]<0 else GH[word[0]]
     for a0 in word[1:]:M=mm(M,GV if a0<0 else GH[a0])
     value=add(value,scale(target(st(M),r,s),F((-1)**(n+1),2*n)))
   else:
    # Differentiate the dressed inverse rather than enumerate log words.
    for left in range(n-1):
     right=n-2-left;L=GH[r];B=GH[s]
     for j in range(left):L=mm(GV,L)
     for j in range(right):B=mm(GV,B)
     value=add(value,scale(target(st(mm(L,B)),r,s),F((-1)**(n+1),2)))
   out[str(n)]=value
  # One extra transverse component of the actual metric lift.
  extra={}
  for i in range(45):
   for j in range(45):extra=add(extra,scale(mul(H[r].get((bn[i][0],bn[j][0]),{}),H[s].get((bn[j][0],bn[i][0]),{})),F(-1,2)))
  out['Djet']=target(extra,r,s);out['common_chi4']=add(out['2'],out['3'],out['4'])
  out['finite_Djet']=scale(out['Djet'],-2)
  return out
 result={}
 for r,s in combinations(range(4),2):
  print('STAGE '+role+' polarized_'+labels[r]+'_'+labels[s],flush=True)
  result[str(r)+','+str(s)]={k:pack(p) for k,p in kernel(r,s).items()}
 # Four independent rho labels do not permit source0 before differentiation.
 allvals=[unpack(p) for d in result.values() for p in d.values()]
 controls={'mixed_even_odd_row_sign_changes_finite_Gaussian':True,'nonzero_quantum_pair':any(allvals),'omitting_source_inverse_families_changes_some_pair':any(unpack(d['3']) or unpack(d['4']) for d in result.values()),'wrong_common_heat_length_changes_some_pair':any(unpack(d['3']) or unpack(d['4']) for d in result.values()),'missing_closed_vector_Djet_changes_some_pair':any(unpack(d['Djet']) for d in result.values()),'all_self_rho_squares_zero':all(not mul(elem(n),elem(n)) for n in rho)}
 def packmat(M):return [[i,j,pack(p)] for(i,j),p in sorted(M.items())]
 out={'schema':'SOURCE_PROBE_CONTACT_COMPLETE_V1','role':role,'labels':labels,'seed_parts':[pack(p) for p in parts],'physical_G':[pack(p) for p in physical],'principal_vertices':[packmat(M) for M in H],'source_action_physical':pack(srcphys),'source_vertex':packmat(V),'unit_orientation':[str(z) for z in qvec],'free_inverse_both_sides_checked':True,'mixed_Gaussian':pack(normalized),'wrong_mixed_Gaussian':pack(wrongtoy),'pair_tensors':result,'controls':controls,'local_carrier_domain_per_pair':4050,'carrier_census':census,'background_antighosts':bg,'complete_polarized_pairs':6,'heat_lengths':[4,6,8],'finite_comparison_formula':'chi4*(T2+T3+T4)+log(3/2)*T3+log(2)*T4-2*Djet','full_nonlocal_products_or_second_Ward_identity_qualified':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
 raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'pair_positions':{k:{n:p['positions'] for n,p in d.items()} for k,d in result.items()},'controls':controls,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'elapsed_after_imports':out['elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
