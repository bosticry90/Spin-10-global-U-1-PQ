# Source support, complete words and finite dimensional residue

Use the existing S_ext=S+sum(u_r QG_r+rho_r G_r), d u=rho. Crel is
Gamma_D,FP-Gamma_H,FP. After extracting rho0rho1, the target has dimension3,
ghost number-1, parity odd. Ja has dimension2/gh0/parity even; its companion
must be a or JL, dimension1/gh-1/parity odd. No jet, positive-dimensional
mass/vacuum factor or other field fits this target. All45*90 slots remain.

For each FULL actual G verify: its BV sources are only Ja/JL; every term
containing Ja is bilinear Ja*(a or JL), with no jet. Derive all1286 canonical
flow columns by Euler differentiation before source/field restriction.
The only images which can contain Ja are Lambda and Ja. Other integrated
physical fields are fixed, and physical-source/JC images cannot produce Ja.
Therefore a first-probe functional can feed this target only if it already
contains Lambda or Ja. Its dimension3/gh-1 leaves exactly anchor*(a,JL),
the previously calculated8100-position carrier. This proves the reuse scope
rather than dropping every other one-probe quantum contribution by assertion.
The projected full flows must agree with the Hamiltonian of the retained
bilinear G. Their omitted terms remain in other grades/nonlocal amplitudes.

With I_r the actual first-probe relative coefficients, p the measured pair
contact before its log(4/3), and C_rs the actual u_r*rho_s conversion, the
complete source projection is

 R_Ja = Pi_Ja[(log2-log(3/2))*Qp + C01-C10
                              + X_G0 I1-X_G1 I0].

Odd G has X_G z=(-1)^(p_z+1) EL_JG and X_GJ=(-1)^p_z EL_zG. The augmented
operation is odd, with even density rho*G and its independently labelled
rho. Keep the existing orientation; a direct EVEN rho-Hamiltonian Euler
check verifies it over the source carrier. Qp uses actual EL_Lambda S and
EL_Ja S. Source differentiation precedes restriction. Physical S has no
auxiliary/source arguments, so these Euler columns use the complete actual
GF/source action without any physical EOM substitution.

Principal Hessians are authenticated MPA symbols, with full formal Fourier
q0..q3 and saturated degree4-di-dj-dexternal. Scalars and positive-degree
mass/orbit terms are excluded only from this local coefficient. The old
shape checks include off-diagonal q_mu*q_nu; recheck the complete tensors.
Let H=H_(rho G), U=H_(u QG), V=H_(GF/source interaction). H supports0,chi;
U supports0,chi,Ja; V supportschi,Ja at this projection. Complete words:

 n2: U_Ja H_chi;
 n3: (U_Ja,H0,Vchi), (Uchi,H0,VJa), (U0,Hchi,VJa);
 n4: (U0,H0,Vchi,VJa).

Retain all orders, with log weight(-1)^(n+1)/(2n) or its rooted equivalent.
No new classical second-order vertex is inserted. Do not truncate by graph
count; this degree argument exhausts the carrier.

Every zero-jet Lorentz scalar one-loop word has affine D dependence: a
two-index vector vertex has only delta and n_mu*n_nu structures, and the
closed chain carries at most one free transverse trace. Scalar/nonminimal
legs break such a trace rather than create another. Compute that derivative
by one additional transverse vector component with the actual metric BB
blocks. A fresh two-extra-component control checks the affine property.
No guessed4/D angular correction or vanished residue derivative is assumed.

For each word length n the fixed relative finite map is

 C_n = [chi4 + log(n/2)] T_n - 2 partial_D T_n at D4.

Thus C=chi4*sum Tn+log(3/2)T3+log2*T4-2sum dD Tn. chi4 remains a free
formal common constant; kappa, b0 and IR constants remain distinct. Check
the inherited heat/dimensional Gamma radial normalization independently.
Retain all source/ordinary companions and their signs when assembling R.

Only after constructing R from these inputs compare it with the measured
PCW heat response, in the same literal Euclidean hbar/(16pi2) normalization.
The comparison is a result, not an acceptance condition forcing cancellation.
Even a zero in this carrier does not determine the prescribed complete
T_kappa functional, all other carriers, full connected U, chiral measure,
global phase, physical limits or E5/A5. The joint one-variation test-field
domain and UV finite part before IR removal are inherited within their
qualified scope; no constant-probe diagonal or two-Q theorem is imported.
