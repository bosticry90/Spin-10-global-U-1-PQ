# The independently calculated relative source variation matches the heat response

Both native calculations and the separate verifier completed. The result is
qualified within the same formal Euclidean bosonic one-loop, independent
Schwartz-probe and first-Slavnov-variation scope as the preceding work.

After extracting rho0*rho1, in hbar/(16 pi^2) density units,

 R_Ja = -g10^2 xi eta_H^2 log(4/3) sum_ij K_ij a_i Ja_j.

K is the existing 56-entry rational tensor, K_13,13=1/5. The full source
carrier has 4,050 positions. There is no JL*Ja component, rational finite
term or other coupling dependence in the assembled result. The 112 stored
formal positions reflect separate log2 and log(3/2) basis elements; they
represent 56 coefficient positions after combining the logarithms.

The calculation did not supply the negative of the known heat coefficient.
It evaluated the actual mixed u*rho terms, actual Q variation of the pair
contact, and the full field/source brackets of the qualified first-probe
inputs. Only the verifier's final comparison consulted the heat target:

 R_Ja + B_H,source = 0.

Combined with PHR1, the complete retained Lambda/Ja anchor-linear carrier
has its actual heat response and relative variation reconciled. This
implies a zero formal dimensional-comparison variation in these retained
carriers, not a new direct dimensional integration, full physical scheme,
chiral identity or E5/A5 qualification.

## What was calculated and reused

The source orientation is the actual full augmented operation. Fresh Euler
calculations checked all 1,286 canonical flow slots per generator before
restriction. Ja-bearing images occur only in Lambda and Ja. Actual G has
BV sources only Ja/JL, with its Ja-containing terms bilinear Ja*(JL,a).
Dimensions and ghost number then prove that the old 8,100-position
first-probe Lambda/Ja carrier is sufficient for this target. Those qualified
first-probe loop coefficients were reused; omitted carriers were excluded
by this support proof, not presumed zero.

The mixed coefficients have the following nonzero group counts:

| Orientation | n2 | n3 | n4 |
| --- | ---: | ---: | ---: |
| C01 | 0 | 0 | 0 |
| C10 | 0 | 56 | 0 |

Every associated first dimensional residue derivative is zero. This was
calculated using a new transverse vector component, with an additional
sixth-component affine-D check in the verifier. Omitting the dimension
jet is therefore an insensitive control here; no universal zero is inferred.

Qp contributes 56 positions before logarithms. Field and source companions
contribute 224 and 112 formal positions respectively. Omitting source flows
or the first-probe companions changes the result. Their cancellation in the
assembled expression must not be replaced by separately dropping them.

Primary ordered-log closed paths and replay rooted-inverse products use
distinct derivative routes and exact momentum orientations. The independent
expanded-Fraction verifier rederives the complete flows, source Euler
columns, even rho-Hamiltonian brackets, mixed contractions, dimension jets
and zero complement. It authenticates and reuses classical Hessian symbols
and old first-probe data, rather than repeating their qualified derivations.

Native runtimes were 19.429 and 16.086 seconds; verification took 51.808
seconds. Maximum sampled private allocation was 1,005,576,192 bytes, not a
true peak. All 600-second/8-GiB/350-MiB/16-MiB limits held. No worker or
verifier failed in this increment.

Validation receipt SHA256:
9009d2ce6158d73d6b95ae4ce61a837441eb8b5962ba4c0dcdb6133d8f8ef75a.

## Scientific decision

The remaining obstacle should now be addressed at the level of the common
functional and its nonlocal products, rather than extrapolating these two
local projections or immediately accumulating another component table.
The follow-on TPW1 investigates whether the existing metric-lift/trace
construction applies to the complete degree-two probe quotient.

Shared action, classical data, analytic premises, software and AI authorship
remain limitations. This is internal computational corroboration. Authority
stays34/39; full QAP/E5/A5, chiral/measure/global and physical limits remain
unqualified. Kappa, b0 and IR constants remain distinct. Historical custody
stays exit2/seven unresolved NOTPASS; prior physical exclusions are intact.
