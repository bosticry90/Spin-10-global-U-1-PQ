from pathlib import Path
import ast
O=Path(__file__).resolve().parent;B=O.parent/'canonical_so10_mixed_probe_auxiliary_ward';old=(B/'verify_v2.py').read_text(encoding='utf-8')
helpers=old[old.index('def put('):old.index("u=[index['mw_u'")]
types=old[old.index("u=[index['mw_u'"):old.index('def hess(')]
head='''from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from collections import defaultdict
from itertools import permutations
import json,gzip,time,threading,os,sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
def guard(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('PSR_VERIFIER_WRITE')
os.sys.addaudithook(guard)
role='verifier'
P=json.loads(gzip.decompress((O/'primary_tables.json.gz').read_bytes()));Z=json.loads(gzip.decompress((O/'replay_tables.json.gz').read_bytes()))
for k in ['names','parities','G_E','source_E','full_flows','Ja_bearing_flow_outputs','flows','G_bilinear','groups','Djets','contacts','I_reused','Qp_source','mixed_difference','cross_field','cross_source','relative_Ward_source']:assert P[k]==Z[k],k
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry']
names=P['names'];par=P['parities'];index={n:i for i,n in enumerate(names)}
pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};sources={J for i,J,h,k in pairs};canon=fields|sources;Jof={i:J for i,J,h,k in pairs}
g,xi,eta=s.symbols('g10 xi eta_H');loc={'g10':g,'xi':xi,'eta_H':eta,'reference_width_M':xi,'reference_width_H':eta}
squares=[2,3,5,7,-1];factors={(i,j):int(s.prod(squares[k] for k in range(5) if i&j&(1<<k))) for i in range(32) for j in range(32)}
'''
setup=r'''
inp=json.loads(gzip.decompress((O/'primary_inputs.json.gz').read_bytes()))
def wick(p):
 phases={**{b[0]:'I' for b in bn},**dict.fromkeys(ln+jl,'-I'),**dict.fromkeys(ja+jc,'-1')};out={}
 for(gp,xp,hp,m,w),v in p.items():
  z={(gp,xp,hp,m,w):-v}
  for n,j in w:z=mul(z,scalar(phases.get(n,'1')),scalar(['1','I','-1','-I'][j.count(0)%4]))
  out=add(out,z)
 return out
GE=[wick(unpack(p)) for p in inp['physical_G']];assert GE==[unpack(p) for p in P['G_E']]
source=unpack(inp['source_E']);assert source==unpack(P['source_E'])
def project(p):
 z=subst(p,{n:elem(v) for n,v in bgmap.items()});return {k:v for k,v in z.items() if all(n in ext and not j for n,j in k[-1])}
flows=[];gm=[]
for r,p in enumerate(GE):
 assert all(n not in sources or n in set(ja+jl) for gp,xp,hp,m,w in p for n,j in w)
 jap={k:v for k,v in p.items() if any(n in ja for n,j in k[-1])}
 assert all(len(w)==2 and sum(n in ja for n,j in w)==1 and sum(n in set(an+jl) for n,j in w)==1 and all(not j for n,j in w) for gp,xp,hp,m,w in jap)
 full=vector(p);assert all(not full[n] for n in fields-set(an+ln))
 assert {names[n]:q for n,q in full.items() if q}=={n:unpack(q) for n,q in P['full_flows'][r].items()}
 jout={n for n,q in full.items() if any(t in ja for gp,xp,hp,m,w in q for t,j in w)};assert jout<=set(ln+ja)
 ff={bgmap.get(n,n):project(q) for n,q in full.items() if bgmap.get(n,n) in ext};gp=project(p);gm.append(gp);el=EL(gp,ext);v={}
 for a,l,aa,jj in zip(bg,bl,ja,jl):v[a]=el[aa];v[l]=scaled(el[jj],-1);v[aa]=scaled(el[a],-1);v[jj]=el[l]
 assert ff==v=={index[n]:unpack(q) for n,q in P['flows'][r].items()};flows.append(v)
assert gm==[unpack(p) for p in P['G_bilinear']]
print('STAGE verifier all1286_flows_and_complete_one_probe_reuse_support',flush=True)
fm=lambda pkt:{(i,j):unpack(p) for i,j,p in pkt}
HS=[fm(p) for p in inp['H_symbols']];US=[fm(p) for p in inp['U_symbols']];VS=fm(inp['V_symbols']);assert all(i in core and j in core for M in HS+US+[VS] for i,j in M)
def evaluate(p,vec):return subst(p,{q:scalar(v) for q,v in zip(qs,vec)})
'''
math=old[old.index('def checkshape('):old.index('def groups(')]
math=math.replace('vec=[F(1),F(0),F(0),F(0)]','vec=[F(0),F(0),F(1),F(0)]')
groups=r'''
def groups(G,H,UU,V):
 HH={d:[mm(G,select(h,d)) for h in H] for d in ['0','c']};UV={d:[mm(G,select(h,d)) for h in UU] for d in ['0','c','J']};VV={d:mm(G,select(V,d)) for d in ['c','J']};out={}
 for r,rs in [(0,1),(1,0)]:
  vals={str(n):{} for n in [2,3,4]};vals['2']=target(contractions([UV['J'][r],HH['c'][rs]]),'J',rs,r)
  for a,b,c in [('J','0','c'),('c','0','J'),('0','c','J')]:vals['3']=add(vals['3'],target(contractions([UV[a][r],HH[b][rs],VV[c]]),'J',rs,r))
  vals['4']=target(contractions([UV['0'][r],HH['0'][rs],VV['c'],VV['J']]),'J',rs,r);out['C'+str(r)+str(rs)]=vals
 return out
four=groups(G,H,UU,V)
def extra(count):
 GG=dict(G);HH=[dict(M) for M in H];UU0=[dict(M) for M in UU];VV=dict(V)
 for a in range(count):
  for i in range(45):
   ii=len(names)+45*a+i;GG[ii,ii]=scalar('1')
   for j in range(45):
    jj=len(names)+45*a+j
    for M,N in list(zip(H,HH))+list(zip(UU,UU0))+[(V,VV)]:
     p=M.get((bn[i][0],bn[j][0]),{})
     if p:N[ii,jj]=p
 return groups(GG,HH,UU0,VV)
five=extra(1);six=extra(2);jets={};contacts={}
for key,vs in four.items():
 for n,p in vs.items():assert p==unpack(P['groups'][key][n]),(key,n)
 jets[key]={n:add(five[key][n],scaled(p,-1)) for n,p in vs.items()}
 for n,p in jets[key].items():
  assert p==unpack(P['Djets'][key][n]),(key,n,'Djet')
  assert not add(six[key][n],scaled(five[key][n],-2),four[key][n]),(key,n,'nonaffine_D')
 z=mul(elem(cs[0]),add(*vs.values()))
 for n,slot in [('3',1),('4',2)]:z=add(z,mul(elem(cs[slot]),vs[n]))
 z=add(z,scaled(add(*jets[key].values()),-2));assert z==unpack(P['contacts'][key]);contacts[key]=z
print('STAGE verifier mixed_source_groups_and_fifth_sixth_dimension_checks',flush=True)
coeff=lambda p,n:gradient(p).get((n,()),{})
I=[coeff(add(*(unpack(inp['one_probe_contacts']['I'+str(r)+a]) for a in ['L','J'])),rho[r]) for r in range(2)];assert I==[unpack(p) for p in P['I_reused']]
C={k:coeff(coeff(contacts[k],u[int(k[1])]),rho[int(k[2])]) for k in ['C01','C10']}
def projection(p):return {k:v for k,v in p.items() if sum(n in ja for n,j in k[-1])==1 and sum(n in chi for n,j in k[-1])==1 and all(n in set(ja)|chi|set(cs) and not j for n,j in k[-1])}
F0=add(*(mul(elem(r),p) for r,p in zip(rho,gm)));B=add(*(mul(elem(r),p) for r,p in zip(rho,I)));eF=EL(F0,set(bg+bl+ja+jl));dB=gradient(B);field={};src={}
for a,l,aa,jj in zip(bg,bl,ja,jl):
 for n,v in [(a,eF[aa]),(l,eF[jj])]:field=add(field,mul(v,dB.get((n,()),{})))
 for n,v in [(aa,eF[a]),(jj,eF[l])]:src=add(src,mul(v,dB.get((n,()),{})))
field=projection(coeff(coeff(field,rho[0]),rho[1]));src=projection(coeff(coeff(src,rho[0]),rho[1]));assert field==unpack(P['cross_field']) and src==unpack(P['cross_source'])
ell=EL(source,set(ln+ja));qi={}
for a,l,aa,jj in zip(bg,ln,ja,jl):qi[a]=subst(ell[aa],{n:elem(v) for n,v in bgmap.items()});qi[jj]=subst(ell[l],{n:elem(v) for n,v in bgmap.items()})
p=unpack(inp['pair_contact']);qp=projection(operation(qi,odd=True)(p));assert qp==unpack(P['Qp_source'])
mixed=add(C['C01'],scaled(C['C10'],-1));ward=add(mul(elem(cs[2]),qp),scaled(mul(elem(cs[1]),qp),-1),mixed,field,src);assert mixed==unpack(P['mixed_difference']) and ward==unpack(P['relative_Ward_source'])
for J in ja:
 for c in chi:
  w,sg=canonical(((J,()),(c,())))
  for key in four:
   for n in four[key]:assert {k:v for k,v in four[key][n].items() if tuple(t for t in k[-1] if t[0] not in set(u+rho))==w}=={k:v for k,v in unpack(P['groups'][key][n]).items() if tuple(t for t in k[-1] if t[0] not in set(u+rho))==w}
eps,m2,nlog=s.symbols('eps m2 n_log',positive=True)
for n in [2,3,4]:
 ratio=s.gamma(n-eps)/(s.gamma(2-eps)*s.gamma(n));a=s.simplify(s.diff(ratio,eps).subs(eps,0));assert a==1-s.harmonic(n-1)
 dim=s.log(4*s.pi)-s.EulerGamma-s.log(m2)+a;heat=-s.EulerGamma-s.log(2*n)-s.log(m2)-s.harmonic(n-1)+nlog
 assert s.simplify(dim-heat-(1+s.log(16*s.pi)-nlog+s.log(s.Rational(n,2))))==0
print('STAGE verifier complete_relative_source_Ward_before_heat_comparison',flush=True)
# Only now access the independently measured heat target.
hp=json.loads(gzip.decompress((R/'calculations/canonical_so10_probe_source_ward_companion/primary_tables.json.gz').read_bytes()));hr=json.loads(gzip.decompress((R/'calculations/canonical_so10_probe_source_ward_companion/replay_tables.json.gz').read_bytes()));assert hp['heat_polynomial']==hr['heat_polynomial']
hh={n:unpack(p) for n,p in hp['heat_polynomial'].items()};assert not add(*hh.values()) and not hh['1'] and not hh['2'] and not hh['5'];assert hh['4']==scaled(hh['3'],-1)
heat=add(mul(elem(cs[2]),hh['3']),scaled(mul(elem(cs[1]),hh['3']),-1));comparison=add(ward,heat)
result={'schema':'PROBE_SOURCE_RELATIVE_WARD_VALIDATION_V1','full_carrier_slots':4050,'full_flow_columns_per_G':1286,'complete_one_probe_reuse_support_freshly_verified':True,'classical_Hessian_symbols_reused_not_redifferentiated':True,'groups':{k:{n:summary(p) for n,p in vs.items()} for k,vs in four.items()},'Djets':{k:{n:summary(p) for n,p in vs.items()} for k,vs in jets.items()},'Qp_source':summary(qp),'cross_field':summary(field),'cross_source':summary(src),'relative_Ward':summary(ward),'relative_Ward_zero':not ward,'heat_plus_relative_Ward':summary(comparison),'selected_dimensional_comparison_zero':not comparison,'fixed_source_omission_sensitive':bool(src),'one_probe_omission_sensitive':bool(add(field,src)),'Djet_omission_sensitive':any(jets[k][n] for k in jets for n in jets[k]),'sixth_component_affinity_check':True,'elapsed_after_imports':time.perf_counter()-tick,'full_QAP_chiral_physical_restoration':False,'authority_changed':False,'shared_action_proofs_software_AI_author':True}
print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
'''
code=head+helpers+types+setup+math+groups;ast.parse(code)
with (O/'verify.py').open('x',encoding='utf-8',newline='\n') as f:f.write(code)
print('GENERATED_PSR1_EXPANDED_FLOW_AND_DIMENSION_VERIFIER')
