# PSR1: actual relative source companion of the two-probe Ward variation

Base/main5c0698fa9aaf3e327b203203bbf44ee20b4b683a. Previous goal turn
PROGRESS; whole investigation active/incomplete. Bind current AGENTS and
State113/34of39; custody exit2/seven NOTPASS. No agents, branch/worktree,
push/publication/outreach, adopted physical scheme/benchmark/foundation,
state/promotion or flavor/HB1/C5 activation.

Question: what is the actual relative Ja*(JL,a) Ward coefficient of the
same augmented Mlight/Mheavy action? PCW1 measured a nonzero heat response;
its relative companion must not be assigned the value required to cancel it.
Calculate both mixed u*rho conversion terms, then combine them with the
qualified pair contact and first-probe companions through the actual full
field/source/probe operation. Relevant complete carrier:4050 slots. This
decides a necessary missing source part of the tested quantum identity,
not every Ward carrier, full connected U or complete QAP/E5/A5.

Reuse authenticated classical physical G/QG and principal Hessian symbols
from the two distinct MPA derivations. Reuse its completed first-probe
Lambda/Ja companions only after a fresh full-flow support check. Inputs
contain those first-probe coefficients and the pair contact, but exclude
old Ward outputs and all PCW heat targets. The heat comparison is read only
by validation after new relative coefficients have been independently found.

Primary sums all ordered log/index paths; replay uses rooted inverse/sparse
products and right-to-left derivative conversion. Both derive actual source
Euler columns and full G flows, retain every mixed n2/n3/n4 group, and
calculate a new fifth-transverse residue derivative. Separate expanded-
Fraction verification freshly derives flows/Eulers and all contractions;
it also checks a sixth-component linearity control. Shared action/Hessians,
proofs, conventions, software and AI authorship are disclosed. No external
expert, experimental or proof-assistant validation is asserted.

Freeze types, source/input hashes, degree envelope and limits before running:
each sequential native600s after imports; separate verifier600s;8GiB sampled
private;350MiB launch floor; entire packet16MiB. Failures/caps produce explicit
failed/incomplete evidence, never truncated PASS. No cap expansion or edits
to frozen sources. Correctness requires full route and verifier agreement,
zero complement, source support and radial/derivative checks. It does NOT
require a desired sign, zero remainder or match to the heat response.

Possible outcomes: qualified zero/nonzero relative coefficient with a measured
comparison; a precisely classified mismatch; or incomplete/underdefined
construction. No result alone promotes E5/A5, selects finite constants,
establishes physical unification or rescues an excluded physical benchmark.
Validate completed work and the existing E4 command before local commit;
continue the next justified dependency under the same standing delegation.
