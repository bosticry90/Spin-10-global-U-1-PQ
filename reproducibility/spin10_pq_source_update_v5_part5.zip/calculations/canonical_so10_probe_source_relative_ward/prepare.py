from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,ast
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;M=O.parent/'canonical_so10_mixed_probe_auxiliary_ward';B=O.parent/'canonical_so10_probe_heat_ward_response';P=O.parent/'canonical_so10_probe_source_ward_companion'
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert base=='5c0698fa9aaf3e327b203203bbf44ee20b4b683a'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R).strip()
assert H(M/'validation_receipt_v2.json')=='d12adeb1808cf870aecd197d8e00bd9b93030dd1e862803676c6a97012976f68'
assert H(B/'validation_receipt_v2.json')=='0698fb0d8b2249515f2465d97cdd2b4220730b4956d89ca0d355336740f98ca7'
assert H(P/'validation_receipt.json')=='39fd510ed36983d8591a42dba5a4863807ba4368780e706888f0090c275f542a'
files=[R/n for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V588.md','tools/portable_dh_v1/inputs.json.gz','tools/portable_dh_v1/exact_algebra.py','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']]
for folder,nn in [(M,['DERIVATION.md','RESULT.md','validation_receipt_v2.json','native.py','verify_v2.py']),(B,['DERIVATION.md','RESULT.md','validation_receipt_v2.json']),(P,['RESULT.md','NEXT_RELATIVE_SOURCE.md','validation_receipt.json','compression_receipt.json'])]:files.extend(folder/n for n in nn)
for folder in [M,B,P]:
 n='validation_preparation_v2.json' if folder!=P else 'validation_preparation.json';p=folder/n;files.append(p)
 for fn,h in json.loads(p.read_bytes())['input_sha256'].items():assert H(Path(fn))==h,fn
for role in ['primary','replay']:
 mp=M/(role+'_tables.json.gz');bp=B/(role+'_tables.json.gz');hp=P/(role+'_tables.json.gz');files.extend([mp,bp,hp])
 m=json.loads(gzip.decompress(mp.read_bytes()));b=json.loads(gzip.decompress(bp.read_bytes()))
 z={k:m[k] for k in ['names','parities','physical_G','H_symbols','U_symbols','V_symbols']};z['source_E']=b['source_E'];z['one_probe_contacts']={k:v for k,v in m['contacts'].items() if k.startswith('I')};assert set(z['one_probe_contacts'])=={'I0L','I0J','I1L','I1J'};z['pair_contact']=m['p'];z['extraction']='NO_MIXED_OR_WARD_OR_HEAT_TARGETS_ONLY_ACTUAL_INPUTS'
 dst=O/(role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 files.append(dst)
for n in ['RECORD.md','DERIVATION.md','build_native.py','native.py','build_verifier.py','verify.py','prepare.py','run.py']:
 p=O/n;files.append(p)
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with (O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
files.extend(O.glob('*.source.txt'));bindings={str(p):H(p) for p in sorted(set(files))};native={str(p):bindings[str(p)] for p in [R/'AGENTS.md',R/'project_state.json',R/'tools/portable_dh_v1/inputs.json.gz',R/'tools/portable_dh_v1/exact_algebra.py',O/'native.py',O/'primary_inputs.json.gz',O/'replay_inputs.json.gz']}
dump(O/'preparation.json',{'base':base,'input_sha256':bindings,'native_input_sha256':native,'limits':{'seconds_after_imports':600,'sampled_private_bytes':8*1024**3,'launch_floor':350*1024**2,'packet_bytes':16*1024**2},'scientific_acceptance':'NOT_PERFORMED'})
print('PREPARED_PSR1',len(bindings))
