from pathlib import Path
import ast
O=Path(__file__).resolve().parent;B=O.parent/'canonical_so10_mixed_probe_auxiliary_ward'
old=(B/'native.py').read_text(encoding='utf-8')
prefix=old[:old.index(' ref=read(')].replace("prep['input_sha256']","prep['native_input_sha256']")
setup=r'''
 inp=json.loads(gzip.decompress((O/(role+'_inputs.json.gz')).read_bytes()));assert list(A.names)==inp['names'] and list(A.parities)==inp['parities']
 Gm=[unpack(p) for p in inp['physical_G']];GE=[wick(p) for p in Gm];source=unpack(inp['source_E'])
 fm=lambda pkt:{(i,j):unpack(p) for i,j,p in pkt}
 HS=[fm(p) for p in inp['H_symbols']];US=[fm(p) for p in inp['U_symbols']];VS=fm(inp['V_symbols'])
 assert all(i in core and j in core for M in HS+US+[VS] for i,j in M)
 bgmap={**dict(zip(an,bg)),**dict(zip(ln,bl))}
 def EL(p,domain):
  out={n:{} for n in domain}
  for(n,j),df in grad(p).items():
   if n in domain:out[n]=add(out[n],scale(DD(df,j),(-1)**len(j)))
  return out
 def project(p):
  z=sub(p,{n:elem(v) for n,v in bgmap.items()});return {k:c for k,c in z.items() if all(n in ext and not j for n,j in k[1])}
 fullflows=[];flows=[];gm=[];jaoutputs=[]
 for p in GE:
  assert all(n not in sources or n in set(ja+jl) for g,w in p for n,j in w)
  ja_sector={k:c for k,c in p.items() if any(n in ja for n,j in k[1])}
  assert all(len(w)==2 and sum(n in ja for n,j in w)==1 and sum(n in set(an+jl) for n,j in w)==1 and all(not j for n,j in w) for g,w in ja_sector)
  el=EL(p,fields|sources);full={}
  for n in fields:full[n]=scale(el[Jof[n]],-(-1)**A.parities[n]);full[Jof[n]]=scale(el[n],(-1)**A.parities[n])
  assert all(not full[n] for n in fields-set(an+ln))
  jout=[n for n,z in full.items() if any(t in ja for g,w in z for t,j in w)];assert set(jout)<=set(ln+ja);jaoutputs.append(jout)
  ff={bgmap.get(n,n):project(z) for n,z in full.items() if bgmap.get(n,n) in ext};fullflows.append(full)
  gp=project(p);gm.append(gp);df=grad(gp);v={}
  for a,l,aa,jj in zip(bg,bl,ja,jl):v[a]=df.get((aa,()),{});v[l]=scale(df.get((jj,()),{}),-1);v[aa]=scale(df.get((a,()),{}),-1);v[jj]=df.get((l,()),{})
  assert ff==v;flows.append(v)
 print('STAGE '+role+' complete1286_flow_support_and_one_probe_reuse_scope',flush=True)
'''
helpers=old[old.index(' def evaluate('):old.index(' def groups(')]
groups=r'''
 def groups(G,H,UU,V):
  HH={d:[mm(G,select(h,d)) for h in H] for d in ['0','c']};UV={d:[mm(G,select(h,d)) for h in UU] for d in ['0','c','J']};VV={d:mm(G,select(V,d)) for d in ['c','J']};out={}
  for r,s in [(0,1),(1,0)]:
   vals={str(n):{} for n in [2,3,4]};vals['2']=target(contractions([UV['J'][r],HH['c'][s]]),'J',s,r)
   for a,b,c in [('J','0','c'),('c','0','J'),('0','c','J')]:vals['3']=add(vals['3'],target(contractions([UV[a][r],HH[b][s],VV[c]]),'J',s,r))
   vals['4']=target(contractions([UV['0'][r],HH['0'][s],VV['c'],VV['J']]),'J',s,r);out['C'+str(r)+str(s)]=vals
  return out
'''
finite=old[old.index(' four=groups('):old.index(" print('STAGE '+role+' actual_one_probe")]
finish=r'''
 print('STAGE '+role+' actual_mixed_source_groups_and_fresh_dimension_jets',flush=True)
 coeff=lambda p,n:grad(p).get((n,()),{})
 I=[coeff(add(*(unpack(inp['one_probe_contacts']['I'+str(r)+a]) for a in ['L','J'])),rho[r]) for r in range(2)]
 C={k:coeff(coeff(contacts[k],u[int(k[1])]),rho[int(k[2])]) for k in ['C01','C10']}
 def source_part(p):return {k:c for k,c in p.items() if sum(n in ja for n,j in k[1])==1 and sum(n in chi for n,j in k[1])==1 and all(n in set(ja)|chi|set(cs) and not j for n,j in k[1])}
 crossfield=add(source_part(op(I[1],{n:p for n,p in flows[0].items() if n in set(bg+bl)},False)),scale(source_part(op(I[0],{n:p for n,p in flows[1].items() if n in set(bg+bl)},False)),-1))
 crosssource=add(source_part(op(I[1],{n:p for n,p in flows[0].items() if n in set(ja+jl)},False)),scale(source_part(op(I[0],{n:p for n,p in flows[1].items() if n in set(ja+jl)},False)),-1))
 eS=EL(source,set(ln+ja));qimages={}
 for a,l,aa,jj in zip(bg,ln,ja,jl):qimages[a]=sub(eS[aa],{n:elem(v) for n,v in bgmap.items()});qimages[jj]=sub(eS[l],{n:elem(v) for n,v in bgmap.items()})
 p=unpack(inp['pair_contact']);qp=source_part(op(p,qimages,True));mixed=add(C['C01'],scale(C['C10'],-1));ward=add(mul(elem(cs[2]),qp),scale(mul(elem(cs[1]),qp),-1),mixed,crossfield,crosssource)
 def pm(M):return [[i,j,pack(p)] for(i,j),p in sorted(M.items())]
 output={'schema':'PROBE_SOURCE_RELATIVE_WARD_V1','role':role,'names':list(A.names),'parities':list(A.parities),'G_E':[pack(p) for p in GE],'source_E':pack(source),'full_flows':[{A.names[n]:pack(p) for n,p in v.items() if p} for v in fullflows],'Ja_bearing_flow_outputs':[[A.names[n] for n in ns] for ns in jaoutputs],'flows':[{A.names[n]:pack(p) for n,p in v.items()} for v in flows],'G_bilinear':[pack(p) for p in gm],'groups':{k:{n:pack(p) for n,p in vs.items()} for k,vs in four.items()},'Djets':{k:{n:pack(p) for n,p in vs.items()} for k,vs in jets.items()},'contacts':{k:pack(p) for k,p in contacts.items()},'I_reused':[pack(p) for p in I],'Qp_source':pack(qp),'mixed_difference':pack(mixed),'cross_field':pack(crossfield),'cross_source':pack(crosssource),'relative_Ward_source':pack(ward),'full_flow_column_slots_per_G':1286,'target_slots':4050,'source_support_reuse_proved':True,'full_QAP_chiral_physical_restoration':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
 raw=(json.dumps(output,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'group_positions':{k:{n:len(p) for n,p in vs.items()} for k,vs in four.items()},'Djet_positions':{k:{n:len(p) for n,p in vs.items()} for k,vs in jets.items()},'ward_positions':len(ward),'ward_zero':not ward,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'elapsed_after_imports':output['elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
'''
code=prefix+setup+helpers+groups+finite+finish;ast.parse(code)
with (O/'native.py').open('x',encoding='utf-8',newline='\n') as f:f.write(code)
print('GENERATED_PSR1_SOURCE_NATIVE')
