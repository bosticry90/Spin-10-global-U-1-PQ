"""Reuse an authenticated independent verifier arithmetic kernel, not native code."""
from pathlib import Path
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
old=(R/'calculations/canonical_so10_sourcequadratic_primitive_probe/verify.py').read_text(encoding='utf-8')
kernel=old[old.index('squares=[2,3,5,7,-1]'):old.index("e1=get('e1');")]
header='''"""Expanded-Fraction/right-gradient SPM check; imports no new native module."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
import json,gzip,sys,time,threading,os
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
vp=read(O/'validation_preparation.json')
for p,h in vp['input_sha256'].items():assert digest(Path(p))==h,p
def guard(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(x in args[1] for x in 'wax+'):raise PermissionError('SPM_VERIFIER_WRITE')
sys.addaudithook(guard)
prep=read(O/'preparation.json');a=json.loads(gzip.decompress((O/'primary_tables.json.gz').read_bytes()));b=json.loads(gzip.decompress((O/'replay_tables.json.gz').read_bytes()))
assert {k:v for k,v in a.items() if k not in ['route','elapsed_after_imports']}=={k:v for k,v in b.items() if k not in ['route','elapsed_after_imports']}
for role in ['primary','replay']:
 cap=read(O/(role+'_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed']
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry']
names=geo['names']+['spm_u','spm_v','spm_rho','spm_sigma'];par=geo['parities']+[0,0,1,1];index={n:i for i,n in enumerate(names)}
u=index['spm_u'];v=index['spm_v'];pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};sources={J for i,J,h,k in pairs};canon=fields|sources;Jof={i:J for i,J,h,k in pairs}
g,xi,eta=s.symbols('g10 xi eta_H');loc={'g10':g,'xi':xi,'eta_H':eta,'reference_width_M':xi,'reference_width_H':eta}
'''
body='''
e2=read(Path(prep['artifacts']['replay']['e2']));old=read(Path(prep['artifacts']['replay']['sqp']))
q={i:rows(data['master_field_maps'][names[i]]) for i in fields}
aa=[index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];ll=[index[('b' if i<12 else 'L')+str(i)] for i in range(45)]
ja=[Jof[i] for i in aa];jl=[Jof[i] for i in ll];cc=[index['C'+str(i)] for i in range(45)];nonphys=set(aa+ll);chi=set(ja+jl+cc)
source_action={}
for i in fields:
 if any(n in nonphys for gp,xp,hp,m,w in q[i] for n,j in w):source_action=add(source_action,mul(elem(Jof[i]),q[i]))
euler=EL(source_action,nonphys);q0={n:q[n] for n in cc};q0.update({Jof[i]:euler[i] for i in aa+ll})
assert len(q0)==135 and all(n in chi and not j for p in q0.values() for gp,xp,hp,m,w in p for n,j in w)
assert all(not(i in chi and J in chi) for i,J,h,k in pairs)
for n,p in q0.items():assert p==unpack(a['q0_columns'][names[n]]),('FULL_Q0_COLUMN',names[n])
U={index[n]:add(elem(n),rows(f)) for n,f in e2['source_shifts'].items()};Ui={index[n]:add(elem(n),scaled(rows(f),-1)) for n,f in e2['source_shifts'].items()}
actual=unpack(old['families']['actual_basic_Ksrc']['G_packet']);seed=subst(actual,Ui)
assert seed==unpack(a['actual_preU_seed']) and subst(seed,U)==actual and all(n in chi and not j for gp,xp,hp,m,w in seed for n,j in w)
assert summary(actual)==old['families']['actual_basic_Ksrc']['G']
def checkstat(p,native):
 ss=summary(p);assert (ss['g_word_positions'],ss['field_words'],ss['sha256_exact_cells'])==(native['positions'],native['field_words'],native['sha256'])
def ham(B,Fp,pB):
 ee=EL(B,canon);vf={};vs={}
 for i in fields:
  vf[i]=scaled(ee[Jof[i]],(-1)**(pB*(par[i]+1)));vs[Jof[i]]=scaled(ee[i],(-1)**(pB*par[i]))
 f=operation(vf,not pB)(Fp);sleg=operation(vs,not pB)(Fp);return add(f,sleg),f,sleg
def anchor(p):
 nf={};curr=[{} for _ in range(4)]
 for(gp,xp,hp,m,w),co in p.items():
  ats=[at for at,(n,j) in enumerate(w) if n==u];assert len(ats)==1;at=ats[0];jj=w[at][1]
  f={(gp,xp,hp,m,w[:at]+w[at+1:]):co};nf=add(nf,mul(elem(u),scaled(DD(f,jj),(-1)**len(jj))))
  for k,mu in enumerate(jj):curr[mu]=add(curr[mu],scaled(mul(elem(u,jj[k+1:]),DD(f,jj[:k])),(-1)**k))
 assert add(nf,*(D(f,mu) for mu,f in enumerate(curr)))==p
 return nf,curr
fixtures={'light_JLJa':mul(elem('Jb0'),elem('Jbar0')),'heavy_JLJa':mul(elem('JL13'),elem('Jub14')),'light_JLJLC':mul(elem('Jb0'),elem('Jb1'),elem('C12')),'heavy_JLJLC':mul(elem('JL13'),elem('JL14'),elem('C12'))}
sensitive=0;adjoints=0;currents=0
for name,g0 in fixtures.items():
 G=subst(g0,U);Fq=subst(operation(q0,True)(g0),U)
 for tag,B,Fp,pB in [('GG',mul(elem(v),G),mul(elem(u),G),1),('GQ',mul(elem(v),G),mul(elem(u),Fq),1),('QQ',mul(elem(v),Fq),mul(elem(u),Fq),0)]:
  value,fieldleg,sourceleg=ham(B,Fp,pB);nf,cur=anchor(value);assert not nf
  native=a['local_fixture_checks'][name][tag]
  for p,key in [(value,'density'),(fieldleg,'field_leg'),(sourceleg,'source_leg')]:checkstat(p,native[key])
  for p,pkt in zip(cur,native['currents']):assert p==unpack(pkt)
  sensitive+=bool(fieldleg);currents+=sum(len(p) for p in cur)
 ev=EL(mul(elem(u),G),canon);eg=EL(G,canon)
 jets={n:add(ev[n],scaled(mul(elem(u),eg[n]),-1)) for n in canon};jets={n:p for n,p in jets.items() if p}
 assert {names[n]:p for n,p in jets.items()}=={n:unpack(p) for n,p in a['local_fixture_checks'][name]['probe_adjoint_defect'].items()}
 adjoints+=sum(len(collapsed(p)) for p in jets.values())
assert sensitive==a['sensitive_individual_field_legs'] and adjoints==a['local_probe_adjoint_positions'] and sensitive and adjoints
# Independent power series: log(2+a+b)/2 has coefficient -ab/8.
aa0,bb0,t=s.symbols('aa bb t');series=s.series(s.log(2+t*(aa0+bb0))/2,t,0,3).removeO().expand()
mixed=series.coeff(t,2).coeff(aa0,1).coeff(bb0,1);assert mixed==-s.Rational(1,8) and str(mixed)==a['finite_double_log_control']['half_log_mixed_derivative']
result={'schema':'SECOND_PROBE_MASTER_VALIDATION_V1','scientific_disposition':'QUALIFIED_Q_STABLE_ISOTROPIC_TRANSPORTED_TWO_SOURCE_MODULE_AND_EXACT_CLASSICAL_LOCAL_PROBE_EXTENSION_ONLY','135_actual_Q0_coordinate_images_freshly_recomputed':True,'all_actual_primitive_carrier_coefficients_checked':True,'local_polarized_bracket_classes_checked':12,'sensitive_individual_field_legs':sensitive,'local_probe_adjoint_positions':adjoints,'full_fixture_boundary_currents_positions':currents,'second_quantum_product_or_QAP_qualified':False,'finite_double_log_control':str(mixed),'state_authority_changed':False,'shared_assumptions_software_and_AI_authorship':True,'elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
'''
with (O/'verify.py').open('x',encoding='utf-8',newline='\n') as f:f.write(header+kernel+body)
print('BUILT_INDEPENDENT_VERIFIER')
