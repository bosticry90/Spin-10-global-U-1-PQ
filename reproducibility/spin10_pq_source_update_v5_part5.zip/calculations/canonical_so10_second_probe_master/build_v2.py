from pathlib import Path
O=Path(__file__).resolve().parent
def write(n,t):
 with (O/n).open('x',encoding='utf-8',newline='\n') as f:f.write(t)
t=(O/'closure.py').read_text(encoding='utf-8')
t=t.replace("read(O/'preparation.json')","read(O/'preparation_v2.json')")
t=t.replace("role+'_tables.json.gz'","role+'_v2_tables.json.gz'")
old="q0[J]=sub(plus(full,scale(op(shifts[J],q,True),-1)),Ui)"
assert old in t;t=t.replace(old,"q0[J]=sub(plus(full,op(shifts[J],q,True)),Ui)")
write('closure_v2.py',t)
t=(O/'verify.py').read_text(encoding='utf-8').replace("validation_preparation.json","validation_preparation_v2.json").replace("preparation.json","preparation_v2.json").replace("primary_tables.json.gz","primary_v2_tables.json.gz").replace("replay_tables.json.gz","replay_v2_tables.json.gz").replace("role+'_capture.json'","role+'_v2_capture.json'")
write('verify_v2.py',t)
t=(O/'prepare.py').read_text(encoding='utf-8')
t=t.replace("'closure.py','prepare.py','run.py','verify.py','build_verifier.py'","'closure_v2.py','prepare_v2.py','run_v2.py','verify_v2.py','build_v2.py','CORRECTION_V2.md'")
t=t.replace("files.extend(O.glob('*.source.txt'))","files.extend(p for p in O.iterdir() if p.is_file())")
t=t.replace("dump(O/'preparation.json'","dump(O/'preparation_v2.json'")
write('prepare_v2.py',t)
t=(O/'run.py').read_text(encoding='utf-8')
t=t.replace(" C.mkdir(parents=True,exist_ok=False)\n tree=subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)\n with (C/'old_git_tree.txt').open('xb') as f:f.write(tree)"," assert C.is_dir() and (O/'controller_failure.json').exists()")
t=t.replace("'prepare.py'","'prepare_v2.py'")
for a,b in [('preparation_capture.json','preparation_v2_capture.json'),('preparation_full_capture.json','preparation_v2_full_capture.json'),('preparation.json','preparation_v2.json'),('validation_preparation.json','validation_preparation_v2.json'),("'verify.py'","'verify_v2.py'"),("'closure.py'","'closure_v2.py'"),("role+'_capture.json'","role+'_v2_capture.json'"),("role+'_full_capture.json'","role+'_v2_full_capture.json'"),("role+'_tables.json.gz'","role+'_v2_tables.json.gz'"),('validation_receipt.json','validation_receipt_v2.json'),("role+'_result.json'","role+'_v2_result.json'"),('controller_failure.json','controller_failure_v2.json')]:t=t.replace(a,b)
# The historical failed controller is a required input, not a V2 prerequisite.
t=t.replace("(O/'controller_failure_v2.json').exists()","(O/'controller_failure.json').exists()")
write('run_v2.py',t)
print('BUILT_SPM1_V2_WITH_ORIGINAL_FAILURE_PRESERVED')
