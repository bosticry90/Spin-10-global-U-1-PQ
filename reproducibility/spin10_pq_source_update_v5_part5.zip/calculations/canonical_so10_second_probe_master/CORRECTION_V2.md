# Correct the untwisting composition, preserving the failed V1 run

V1 primary failed native1 at its135-coordinate closure assertion before a
table, replay or verifier. The full source/capture/controller failure remains.
The failure was an implementation of the WRONG conjugation, not evidence that
the carrier algebra fails closure. The original formula/derivation is retained.

For UJ=J+A and Q=U Q0 U^-1, composition gives

 Q0 J=U^-1 Q(UJ)=U^-1[QJ+q A_J],

with a PLUS. The V1 record's minus composed U^-1 on both sides instead.
This follows by applying the recorded canonical map to a coordinate, before
testing any Ward remainder. For example A_Jb0=eta_H*(bar0-bar1/2); the actual
QJb0 column, its Ja shift and q A_Jb0 cancel their b-dependent terms with this
orientation. The source-action Euler route remains unchanged and provides a
separate test. No tensor, action input or acceptance condition is fitted.

V2 uses this corrected conjugation and versioned outputs. Same complete135
columns, local bracket/current/adjoint requirements,600s/8GiB/350MiB/8MiB caps
and authority ceiling. Original failed sources are not edited or relabeled.
No quantum product/QAP result is inferred from a passing classical closure.
