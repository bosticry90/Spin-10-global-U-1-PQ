from pathlib import Path
O=Path(__file__).resolve().parent
t=(O/'run_v2.py').read_text(encoding='utf-8')
t=t.replace("'prepare_v2.py'","'prepare_v3.py'").replace('preparation_v2_capture.json','preparation_v3_capture.json').replace('preparation_v2_full_capture.json','preparation_v3_full_capture.json').replace('controller_failure_v2.json','controller_failure_v3.json')
with (O/'run_v3.py').open('x',encoding='utf-8',newline='\n') as f:f.write(t)
print('BUILT_PREPARATION_ONLY_CONTROLLER_V3')
