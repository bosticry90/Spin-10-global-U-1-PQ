# Prospective reduction and the remaining second-product problem

Let chi=(C,Ja,JL), with all45 directions of each, in the ungauge-fixed source
chart. No conjugate of a chi coordinate is in chi. Thus local functions of
chi have zero mutual BV functional brackets, INCLUDING independent local
test functions and derivatives of tests. The complete two-source generators
G0=M JL Ja+N JL JL C lie in this isotropic algebra. Power counting and the
antisymmetric JL pair were already qualified by SQP; invariant tensor ranks
are not asserted here.

This only helps if the ACTUAL untwisted Q maps this algebra to itself. Write
U J=J+A_J, U fixes fields. The coordinate check is

 Q0 J=U^-1[Q J-q A_J],       Q0 C=qC.

An alternative differentiates the ACTUAL ungauge-fixed source action
sum J_i qz_i with respect to a and Lambda, using left Euler derivatives.
All field rules are scanned for the required dependence; none may be omitted
merely because its name was expected to be irrelevant. This yields Q0 on
Ja,JL without using the gauge-fixing columns or their subtraction. Compare
the full coefficients, rather than only checking that both have the desired
support. The inherited physical action is a,Lambda independent; its Eulers
are not being put on shell.

If every actual coordinate image lies in chi, Q0 G0 also lies in chi for
arbitrary coefficient tensors. All polarized brackets of G0 and Q0 G0 then
vanish. U is the qualified anticanonical source shift with full local jet
currents, so the corresponding TRANSPORTED brackets vanish as integrated
functionals. A density need not be zero: its complete Euler derivative and
ordinary current must be distinguished. Do not replace this argument with
the tautological odd-generator self bracket or with Q squared.

For independent even local u_a and odd local rho_a, define

 S_ext=S+sum_a [u_a QG_a+rho_a G_a],   d=sum_a integral rho_a delta/ delta u_a.

The qualified linear identity cancels the probe-linear master breaking.
The three polarized quadratic bracket classes above are precisely the
remaining tree terms. If they vanish, no second classical vertex is needed
for this COMPLETE module. This is a structural statement about the actual
action, not a finite contact normalization choice. Derivative-probe adjoints
of its Hessian must still remain in quantum insertions.

For even marked insertions V_a obtained by differentiating this augmented
action, the second one-loop derivative is the ordered expression

 Gamma1,ab=(i/2) T_kappa[G H_ab-G H_a G H_b],

with graded ordered polarization for odd tracking derivatives. A genuine
zero tree H_ab does not set the second term to zero. T_kappa here denotes
the required COMPLETE heat/reference/power/dimension-jet conversion on a
common domain, not free cyclicity of bare singular traces. The same action
defines the connected product; arbitrary diagonal pullback is not allowed.

The next Ward equation is the corresponding second probe coefficient of

 B1[u,rho]=(S_ext,Gamma1[u,rho])+d Gamma1[u,rho].

Keep B1 explicit. Classical master closure does not establish B1=0, especially
for a full chiral matter measure. Sources must be differentiated before zero.
The scalar finite-matrix control in this packet must demonstrate a nonzero
double-log derivative even when H_ab=0. It is a diagnostic, not a Spin10 loop.

For two distinct labelled vertices, the inherited rooted independent-transfer
argument can be applied coefficientwise to the complete grouped family. A
single vertex carrying two labels is still a single total transfer, and uses
the separate first-probe paired-congruence endpoint argument. Neither case
licenses two unlabelled constant tangents or arbitrary coincident products.
This packet does not silently extend that analytic proof to all second
Slavnov variations or claim its remaining finite contact coefficients.
