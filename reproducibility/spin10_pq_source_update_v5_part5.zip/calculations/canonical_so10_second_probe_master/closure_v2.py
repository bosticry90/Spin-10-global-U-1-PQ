"""Actual isotropic carrier closure; no quantum product result is assumed."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
import gzip,json,sys,time,threading,os
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra,ONE,put,scale,scale_coefficient
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def plus(*polys):
 out={}
 for p in polys:
  for k,c in p.items():put(out,k,c)
 return out
def main():
 tick=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
 role=sys.argv[1];assert role in ['primary','replay'];prep=read(O/'preparation_v2.json')
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 assert digest(Path(__file__))==prep['input_sha256'][str(Path(__file__))]
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):
   assert p==O/(role+'_v2_tables.json.gz'),('SPM_WRITE',str(p))
  if p.suffix=='.json':assert str(p) in prep['read_json_by_role'][role],('SPM_JSON',str(p))
 sys.addaudithook(guard)
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry']
 b=Algebra(geo['names'],geo['parities']);u=len(b.names);v=u+1;rho=u+2;sigma=u+3
 A=Algebra(list(b.names)+['spm_u','spm_v','spm_rho','spm_sigma'],list(b.parities)+[0,0,1,1])
 pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};sources={J for i,J,h,k in pairs};Jof={i:J for i,J,h,k in pairs}
 def elem(n,j=()):
  if isinstance(n,str):n=A.index[n]
  return {(0,((n,j),)):ONE}
 def mul(*polys):
  out={(0,()):ONE}
  for p in polys:out=A.product(out,p)
  return out
 def rows(rr):return A.rows(rr,explicit_g=False)
 def stats(p):return {'positions':len(p),'field_words':len({w for g,w in p}),'sha256':A.fingerprint(p)}
 def pack(p):
  cs=[];idx={};out=[]
  for(g,w),co in sorted(p.items()):
   if co not in idx:idx[co]=len(cs);cs.append([[*k,x.numerator,x.denominator] for k,x in co])
   out.append([g,[[n,list(j)] for n,j in w],idx[co]])
  return {'coefficients':cs,'monomials':out,**stats(p)}
 def unpack(pkt):
  cc=[tuple(((x,h,m),F(n,d)) for x,h,m,n,d in c) for c in pkt['coefficients']]
  return {(g,tuple((n,tuple(j)) for n,j in w)):cc[k] for g,w,k in pkt['monomials']}
 def D(p,mu):
  out={}
  for(g,w),c in p.items():
   for at,(n,j) in enumerate(w):
    ww,sg=A.canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
    if sg:put(out,(g,ww),scale_coefficient(c,sg))
  return out
 def DD(p,j):
  for mu in j:p=D(p,mu)
  return p
 def grad(p):
  out={}
  for(g,w),c in p.items():
   total=sum(A.parities[n] for n,j in w);pref=0
   for at,(n,j) in enumerate(w):
    if role=='primary':sg=(-1)**(A.parities[n]*pref)
    else:
     suffix=total-pref-A.parities[n]
     sg=(-1)**(A.parities[n]*suffix)*(-1)**(A.parities[n]*(total-A.parities[n]))
    put(out.setdefault((n,j),{}),(g,w[:at]+w[at+1:]),scale_coefficient(c,sg));pref+=A.parities[n]
  return {k:p for k,p in out.items() if p}
 def EL(p,domain):
  out={n:{} for n in domain}
  for(n,j),f in grad(p).items():
   if n in domain:out[n]=plus(out[n],scale(DD(f,j),(-1)**len(j)))
  return out
 def op(p,flow,odd=False):
  if role=='replay':return plus(*(mul(DD(flow[n],j),f) for(n,j),f in grad(p).items() if flow.get(n)))
  out={};cache={}
  for(g,w),c in p.items():
   pref=0
   for at,(n,j) in enumerate(w):
    if flow.get(n):
     if(n,j) not in cache:cache[n,j]=DD(flow[n],j)
     pp=mul({(g,w[:at]):scale_coefficient(c,(-1)**pref if odd else 1)},cache[n,j],{(0,w[at+1:]):ONE})
     out=plus(out,pp)
    pref+=A.parities[n]
  return out
 def sub(p,mp):
  out={}
  for(g,w),c in p.items():
   pp={(g,()):c}
   for n,j in w:pp=mul(pp,DD(mp.get(n,elem(n)),j))
   out=plus(out,pp)
  return out
 e2=read(Path(prep['artifacts'][role]['e2']));old=read(Path(prep['artifacts'][role]['sqp']))
 shifts={A.index[n]:rows(rr) for n,rr in e2['source_shifts'].items()}
 U={n:plus(elem(n),f) for n,f in shifts.items()};Ui={n:plus(elem(n),scale(f,-1)) for n,f in shifts.items()}
 q={i:rows(data['master_field_maps'][A.names[i]]) for i in fields}
 aa=[A.index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)]
 ll=[A.index[('b' if i<12 else 'L')+str(i)] for i in range(45)]
 ja=[Jof[i] for i in aa];jl=[Jof[i] for i in ll];cc=[A.index['C'+str(i)] for i in range(45)]
 chi=set(ja+jl+cc);nonphys=set(aa+ll);q0={n:q[n] for n in cc}
 print('STAGE '+role+' actual_untwisted_135_coordinate_images',flush=True)
 if role=='primary':
  for J in ja+jl:
   full=rows(e2['complete_columns'][A.names[J]]['source_polynomial'])
   q0[J]=sub(plus(full,op(shifts[J],q,True)),Ui)
 else:
  terms=[];used=[]
  for i in sorted(fields):
   if any(n in nonphys for g,w in q[i] for n,j in w):terms.append(mul(elem(Jof[i]),q[i]));used.append(A.names[i])
  src=plus(*terms);e=EL(src,nonphys)
  for i in aa+ll:q0[Jof[i]]=e[i]
  print('SOURCE_ACTION_SELECTED '+json.dumps(used),flush=True)
 bad={A.names[n]:sorted({A.names[m] for g,w in p for m,j in w if m not in chi or j}) for n,p in q0.items() if any(m not in chi or j for g,w in p for m,j in w)}
 assert not bad,('Q0_NOT_CLOSED',bad)
 # Every conjugate of chi is outside chi. This proves all coefficient-tensor brackets.
 assert all(not(i in chi and J in chi) for i,J,h,k in pairs)
 assert len(q0)==135 and set(q0)==chi
 for n,p in q0.items():assert all(not j for g,w in p for m,j in w)
 actual=unpack(old['families']['actual_basic_Ksrc']['G_packet'])
 assert stats(actual)['sha256']==old['families']['actual_basic_Ksrc']['G']['sha256_exact_cells']
 seed=sub(actual,Ui);assert seed and all(n in chi and not j for g,w in seed for n,j in w)
 assert sub(seed,U)==actual
 print('STAGE '+role+' local_polarized_functional_brackets_and_probe_currents',flush=True)
 # The graded source-left Hamiltonian operation. Zero bracket tests do not
 # depend on naming left versus right antibrackets; signs inside each leg do.
 def ham(B,Fp,pB):
  ef=EL(B,fields);ej=EL(B,sources)
  flow={i:scale(ej[Jof[i]],(-1)**(pB*(A.parities[i]+1))) for i in fields}
  flow.update({Jof[i]:scale(ef[i],(-1)**(pB*A.parities[i])) for i in fields})
  a=op(Fp,{i:f for i,f in flow.items() if i in fields},not pB)
  s=op(Fp,{i:f for i,f in flow.items() if i in sources},not pB)
  return plus(a,s),a,s
 def anchored(p):
  # Exact IBP with unique EVEN u; return canonical representative and current.
  nf={};curr=[{} for _ in range(4)]
  for(g,w),co in p.items():
   ats=[at for at,(n,j) in enumerate(w) if n==u];assert len(ats)==1
   at=ats[0];jj=w[at][1];f={(g,w[:at]+w[at+1:]):co}
   nf=plus(nf,mul(elem(u),scale(DD(f,jj),(-1)**len(jj))))
   for k,mu in enumerate(jj):curr[mu]=plus(curr[mu],scale(mul(elem(u,jj[k+1:]),DD(f,jj[:k])),(-1)**k))
  assert plus(nf,*(D(f,mu) for mu,f in enumerate(curr)))==p
  return nf,curr
 fixtures={
  'light_JLJa':mul(elem('Jb0'),elem('Jbar0')),
  'heavy_JLJa':mul(elem('JL13'),elem('Jub14')),
  'light_JLJLC':mul(elem('Jb0'),elem('Jb1'),elem('C12')),
  'heavy_JLJLC':mul(elem('JL13'),elem('JL14'),elem('C12'))}
 checks={};sensitive=0;adjoints=0
 for label,g0 in fixtures.items():
  G=sub(g0,U);F0=op(g0,q0,True);Fq=sub(F0,U)
  # The density qG differs by no source-current for this local evolutionary q.
  Q={**q,**{J:rows(e2['complete_columns'][A.names[J]]['source_polynomial']) for J in ja+jl}}
  assert Fq==op(G,Q,True),(label,'Q_TRANSPORT')
  checks[label]={}
  for tag,B,Fp,pB in [('GG',mul(elem(v),G),mul(elem(u),G),1),('GQ',mul(elem(v),G),mul(elem(u),Fq),1),('QQ',mul(elem(v),Fq),mul(elem(u),Fq),0)]:
   value,fieldleg,sourceleg=ham(B,Fp,pB);nf,cur=anchored(value);assert not nf,(label,tag,'LOCAL_BRACKET_NONZERO',stats(nf))
   sensitive+=bool(fieldleg)
   checks[label][tag]={'density':stats(value),'field_leg':stats(fieldleg),'source_leg':stats(sourceleg),'currents':[pack(f) for f in cur],'anchored_representative_zero':True}
  ev=EL(mul(elem(u),G),fields|sources)
  naive=EL(G,fields|sources)
  jetdef={n:plus(ev[n],scale(mul(elem(u),naive[n]),-1)) for n in ev}
  jetdef={n:f for n,f in jetdef.items() if f}
  assert all(any(m==u and j for m,j in w) for p in jetdef.values() for g,w in p)
  adjoints+=sum(len(p) for p in jetdef.values());checks[label]['probe_adjoint_defect']={A.names[n]:pack(p) for n,p in sorted(jetdef.items())}
 assert sensitive and adjoints,('INSENSITIVE_CONTROLS',sensitive,adjoints)
 # Explicit finite Hessian diagnostic: H(a,b)=2+a+b, H_ab=0.
 # 1/2 d_a d_b log H|0 = -1/8, not zero. Independent series check in verifier.
 diag={'H0':2,'Ha':1,'Hb':1,'Hab':0,'half_log_mixed_derivative':'-1/8','not_Spin10_amplitude':True}
 result={'schema':'SECOND_PROBE_MASTER_V1','route':role,'q0_columns':{A.names[n]:pack(p) for n,p in sorted(q0.items())},'q0_coordinate_count':135,'q0_total_positions':sum(len(p) for p in q0.values()),'q0_support':[A.names[n] for n in sorted({n for p in q0.values() for g,w in p for n,j in w})],'actual_G':stats(actual),'actual_preU_seed':pack(seed),'local_fixture_checks':checks,'sensitive_individual_field_legs':sensitive,'local_probe_adjoint_positions':adjoints,'finite_double_log_control':diag,'tree_second_probe_vertices_zero_for_complete_transported_two_source_module':True,'quantum_second_products_or_full_QAP_qualified':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
 raw=(json.dumps(result,sort_keys=True,separators=(',',':'))+'\n').encode();packed=gzip.compress(raw,mtime=0)
 with (O/(role+'_v2_tables.json.gz')).open('xb') as f:f.write(packed)
 print('RESULT '+json.dumps({'route':role,'q0_columns':135,'q0_positions':result['q0_total_positions'],'seed':stats(seed),'sensitive_field_legs':sensitive,'probe_adjoint_positions':adjoints,'packed_sha256':sha256(packed).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'elapsed_after_imports':result['elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
