# Preparation-only exclusive-copy correction

The V2 controller stopped in preparation: it tried to create RECORD.md.source.txt
although that exact V1 snapshot already existed. No V2 scientific worker,
table, replay or verifier ran. The exact preparation output/controller failure
is preserved. This was an avoidable provenance-harness error, not physics.

Preparation V3 uses new .v3.source.txt names for all current inputs and binds
all older files unchanged. It then prepares the unchanged corrected V2 native
and verifier programs. Their output/receipt names remain V2; the preparation
capture and controller are V3. No scientific condition, input, cap or outcome
is changed. Neither failed V1 execution nor V2 preparation is called PASS.
