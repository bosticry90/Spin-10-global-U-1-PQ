"""Expanded-Fraction/right-gradient SPM check; imports no new native module."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
import json,gzip,sys,time,threading,os
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(600,lambda:os._exit(124));watch.daemon=True;watch.start()
vp=read(O/'validation_preparation.json')
for p,h in vp['input_sha256'].items():assert digest(Path(p))==h,p
def guard(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(x in args[1] for x in 'wax+'):raise PermissionError('SPM_VERIFIER_WRITE')
sys.addaudithook(guard)
prep=read(O/'preparation.json');a=json.loads(gzip.decompress((O/'primary_tables.json.gz').read_bytes()));b=json.loads(gzip.decompress((O/'replay_tables.json.gz').read_bytes()))
assert {k:v for k,v in a.items() if k not in ['route','elapsed_after_imports']}=={k:v for k,v in b.items() if k not in ['route','elapsed_after_imports']}
for role in ['primary','replay']:
 cap=read(O/(role+'_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed']
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry']
names=geo['names']+['spm_u','spm_v','spm_rho','spm_sigma'];par=geo['parities']+[0,0,1,1];index={n:i for i,n in enumerate(names)}
u=index['spm_u'];v=index['spm_v'];pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};sources={J for i,J,h,k in pairs};canon=fields|sources;Jof={i:J for i,J,h,k in pairs}
g,xi,eta=s.symbols('g10 xi eta_H');loc={'g10':g,'xi':xi,'eta_H':eta,'reference_width_M':xi,'reference_width_H':eta}
squares=[2,3,5,7,-1]
factors={(i,j):s.prod(squares[k] for k in range(5) if i&j&(1<<k)) for i in range(32) for j in range(32)};factors={k:int(v) for k,v in factors.items()}
def put(p,k,v):
 if not v:return
 p[k]=p.get(k,F(0))+v
 if not p[k]:del p[k]
def add(*pp):
 out={}
 for p in pp:
  for k,v in p.items():put(out,k,v)
 return out
def scaled(p,c):return {k:v*c for k,v in p.items() if v*c}
@lru_cache(None)
def canonical(w):
 out=[];sg=1
 for token in w:
  if par[token[0]] and token in out:return (),0
  at=len(out)
  while at and out[at-1]>token:
   if par[token[0]] and par[out[at-1][0]]:sg=-sg
   at-=1
  out.insert(at,token)
 return tuple(out),sg
def product(p,q):
 out={}
 for (gp,xp,hp,m,w),c in p.items():
  for (gq,xq,hq,n,v),d in q.items():
   word,sg=canonical(w+v)
   if sg:put(out,(gp+gq,xp+xq,hp+hq,m^n,word),c*d*(sg*factors[m,n]))
 return out
@lru_cache(None)
def coefficients(text):
 z=s.expand(s.sympify(text,locals=loc));out={}
 assert not z.has(s.Float) and z.free_symbols<={g,xi,eta}
 for powers,co in s.Poly(z,g,xi,eta).terms():
  for term in s.Add.make_args(s.expand(co)):
   rat,rest=term.as_coeff_Mul(rational=True);assert rat.is_Rational;number=F(int(rat.p),int(rat.q));mask=0
   for factor in s.Mul.make_args(rest):
    if factor==s.I:mask^=16
    elif factor.is_Rational:number*=F(int(factor.p),int(factor.q))
    else:
     assert factor.is_Pow and factor.exp==s.Rational(1,2) and factor.base.is_Integer and factor.base>0,factor
     value=int(factor.base)
     for bit,prime in enumerate(squares[:4]):
      exponent=0
      while value%prime==0:value//=prime;exponent+=1
      number*=prime**(exponent//2)
      if exponent%2:mask^=1<<bit
     assert value==1
   put(out,(*powers,mask),number)
 return tuple(out.items())
def token(t):
 n,_,j=t.partition('__');return index[n],tuple(map(int,j))
def rows(rr):
 out={}
 for row in rr:
  w=tuple(map(token,row['word']));assert canonical(w)==(w,1)
  for (gp,xp,hp,m),v in coefficients(row['coefficient']):
   if 'g' in row:assert gp==0;gp=row['g']
   put(out,(gp,xp,hp,m,w),v)
 return out
def unpack(packet):
 out={}
 for gp,word,cid in packet['monomials']:
  w=tuple((n,tuple(j)) for n,j in word);assert canonical(w)==(w,1)
  for xp,hp,m,num,den in packet['coefficients'][cid]:put(out,(gp,xp,hp,m,w),F(num,den))
 return out
def elem(n,j=()):
 if isinstance(n,str):n=index[n]
 return {(0,0,0,0,((n,j),)):F(1)}
def D(p,mu):
 out={}
 for(gp,xp,hp,m,w),v in p.items():
  for at,(n,j) in enumerate(w):
   word,sg=canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
   if sg:put(out,(gp,xp,hp,m,word),v*sg)
 return out
def DD(p,j):
 for mu in j:p=D(p,mu)
 return p
def gradient(p):
 out={}
 for(gp,xp,hp,m,w),v in p.items():
  total=sum(par[n] for n,j in w)%2
  for at,(n,j) in enumerate(w):
   suffix=sum(par[t] for t,k in w[at+1:]);sg=(-1)**((par[n]*suffix+par[n]*(total-par[n]))%2);put(out.setdefault((n,j),{}),(gp,xp,hp,m,w[:at]+w[at+1:]),v*sg)
 return out
def EL(p,domain):
 out={n:{} for n in domain}
 for(n,j),df in gradient(p).items():
  if n in domain:out[n]=add(out[n],scaled(DD(df,j),(-1)**len(j)))
 return out
def vector(p):
 el=EL(p,canon);v={}
 for i in fields:v[i]=scaled(el[Jof[i]],-(-1)**par[i]);v[Jof[i]]=scaled(el[i],(-1)**par[i])
 return v
def operation(images,odd=False):
 images={n:p for n,p in images.items() if p};cache={}
 def act(p):
  out={}
  for(gp,xp,hp,m,w),c in p.items():
   total=sum(par[n] for n,j in w)%2
   for at,(n,j) in enumerate(w):
    if n not in images:continue
    if(n,j) not in cache:cache[n,j]=DD(images[n],j)
    suffix=sum(par[t] for t,k in w[at+1:]);sg0=(-1)**((par[n]*suffix+(total+par[n] if odd else 0))%2);rest=w[:at]+w[at+1:]
    for(gq,xq,hq,mask,repl),v in cache[n,j].items():
     word,sg=canonical(rest+repl)
     if sg:put(out,(gp+gq,xp+xq,hp+hq,m^mask,word),c*v*(sg0*sg*factors[m,mask]))
  return out
 return act
def collapsed(p):
 out={}
 for(gp,xp,hp,m,w),v in p.items():out.setdefault((gp,w),{})[xp,hp,m]=v
 return out
def summary(p):
 h=sha256();h.update(b'[');cc=collapsed(p)
 for i,((gp,w),co) in enumerate(sorted(cc.items())):
  if i:h.update(b',')
  row=[gp,[[names[n],list(j)] for n,j in w],[[list(k),str(v)] for k,v in sorted(co.items())]];h.update(json.dumps(row,separators=(',',':'),ensure_ascii=True).encode())
 h.update(b']');return {'g_word_positions':len(cc),'field_words':len({w for gp,w in cc}),'sha256_exact_cells':h.hexdigest()}

def mul(*pp):
 out={(0,0,0,0,()):F(1)}
 for p in pp:out=product(out,p)
 return out
def subst(p,images):
 out={}
 for(gp,xp,hp,m,w),c in p.items():
  pp={(gp,xp,hp,m,()):c}
  for n,j in w:pp=product(pp,DD(images.get(n,elem(n)),j))
  out=add(out,pp)
 return out
def scalar(z):return rows([{'word':[],'coefficient':str(z)}])

e2=read(Path(prep['artifacts']['replay']['e2']));old=read(Path(prep['artifacts']['replay']['sqp']))
q={i:rows(data['master_field_maps'][names[i]]) for i in fields}
aa=[index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];ll=[index[('b' if i<12 else 'L')+str(i)] for i in range(45)]
ja=[Jof[i] for i in aa];jl=[Jof[i] for i in ll];cc=[index['C'+str(i)] for i in range(45)];nonphys=set(aa+ll);chi=set(ja+jl+cc)
source_action={}
for i in fields:
 if any(n in nonphys for gp,xp,hp,m,w in q[i] for n,j in w):source_action=add(source_action,mul(elem(Jof[i]),q[i]))
euler=EL(source_action,nonphys);q0={n:q[n] for n in cc};q0.update({Jof[i]:euler[i] for i in aa+ll})
assert len(q0)==135 and all(n in chi and not j for p in q0.values() for gp,xp,hp,m,w in p for n,j in w)
assert all(not(i in chi and J in chi) for i,J,h,k in pairs)
for n,p in q0.items():assert p==unpack(a['q0_columns'][names[n]]),('FULL_Q0_COLUMN',names[n])
U={index[n]:add(elem(n),rows(f)) for n,f in e2['source_shifts'].items()};Ui={index[n]:add(elem(n),scaled(rows(f),-1)) for n,f in e2['source_shifts'].items()}
actual=unpack(old['families']['actual_basic_Ksrc']['G_packet']);seed=subst(actual,Ui)
assert seed==unpack(a['actual_preU_seed']) and subst(seed,U)==actual and all(n in chi and not j for gp,xp,hp,m,w in seed for n,j in w)
assert summary(actual)==old['families']['actual_basic_Ksrc']['G']
def checkstat(p,native):
 ss=summary(p);assert (ss['g_word_positions'],ss['field_words'],ss['sha256_exact_cells'])==(native['positions'],native['field_words'],native['sha256'])
def ham(B,Fp,pB):
 ee=EL(B,canon);vf={};vs={}
 for i in fields:
  vf[i]=scaled(ee[Jof[i]],(-1)**(pB*(par[i]+1)));vs[Jof[i]]=scaled(ee[i],(-1)**(pB*par[i]))
 f=operation(vf,not pB)(Fp);sleg=operation(vs,not pB)(Fp);return add(f,sleg),f,sleg
def anchor(p):
 nf={};curr=[{} for _ in range(4)]
 for(gp,xp,hp,m,w),co in p.items():
  ats=[at for at,(n,j) in enumerate(w) if n==u];assert len(ats)==1;at=ats[0];jj=w[at][1]
  f={(gp,xp,hp,m,w[:at]+w[at+1:]):co};nf=add(nf,mul(elem(u),scaled(DD(f,jj),(-1)**len(jj))))
  for k,mu in enumerate(jj):curr[mu]=add(curr[mu],scaled(mul(elem(u,jj[k+1:]),DD(f,jj[:k])),(-1)**k))
 assert add(nf,*(D(f,mu) for mu,f in enumerate(curr)))==p
 return nf,curr
fixtures={'light_JLJa':mul(elem('Jb0'),elem('Jbar0')),'heavy_JLJa':mul(elem('JL13'),elem('Jub14')),'light_JLJLC':mul(elem('Jb0'),elem('Jb1'),elem('C12')),'heavy_JLJLC':mul(elem('JL13'),elem('JL14'),elem('C12'))}
sensitive=0;adjoints=0;currents=0
for name,g0 in fixtures.items():
 G=subst(g0,U);Fq=subst(operation(q0,True)(g0),U)
 for tag,B,Fp,pB in [('GG',mul(elem(v),G),mul(elem(u),G),1),('GQ',mul(elem(v),G),mul(elem(u),Fq),1),('QQ',mul(elem(v),Fq),mul(elem(u),Fq),0)]:
  value,fieldleg,sourceleg=ham(B,Fp,pB);nf,cur=anchor(value);assert not nf
  native=a['local_fixture_checks'][name][tag]
  for p,key in [(value,'density'),(fieldleg,'field_leg'),(sourceleg,'source_leg')]:checkstat(p,native[key])
  for p,pkt in zip(cur,native['currents']):assert p==unpack(pkt)
  sensitive+=bool(fieldleg);currents+=sum(len(p) for p in cur)
 ev=EL(mul(elem(u),G),canon);eg=EL(G,canon)
 jets={n:add(ev[n],scaled(mul(elem(u),eg[n]),-1)) for n in canon};jets={n:p for n,p in jets.items() if p}
 assert {names[n]:p for n,p in jets.items()}=={n:unpack(p) for n,p in a['local_fixture_checks'][name]['probe_adjoint_defect'].items()}
 adjoints+=sum(len(collapsed(p)) for p in jets.values())
assert sensitive==a['sensitive_individual_field_legs'] and adjoints==a['local_probe_adjoint_positions'] and sensitive and adjoints
# Independent power series: log(2+a+b)/2 has coefficient -ab/8.
aa0,bb0,t=s.symbols('aa bb t');series=s.series(s.log(2+t*(aa0+bb0))/2,t,0,3).removeO().expand()
mixed=series.coeff(t,2).coeff(aa0,1).coeff(bb0,1);assert mixed==-s.Rational(1,8) and str(mixed)==a['finite_double_log_control']['half_log_mixed_derivative']
result={'schema':'SECOND_PROBE_MASTER_VALIDATION_V1','scientific_disposition':'QUALIFIED_Q_STABLE_ISOTROPIC_TRANSPORTED_TWO_SOURCE_MODULE_AND_EXACT_CLASSICAL_LOCAL_PROBE_EXTENSION_ONLY','135_actual_Q0_coordinate_images_freshly_recomputed':True,'all_actual_primitive_carrier_coefficients_checked':True,'local_polarized_bracket_classes_checked':12,'sensitive_individual_field_legs':sensitive,'local_probe_adjoint_positions':adjoints,'full_fixture_boundary_currents_positions':currents,'second_quantum_product_or_QAP_qualified':False,'finite_double_log_control':str(mixed),'state_authority_changed':False,'shared_assumptions_software_and_AI_authorship':True,'elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
