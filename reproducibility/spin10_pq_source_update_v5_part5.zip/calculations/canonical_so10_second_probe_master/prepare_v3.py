from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
assert subprocess.check_output(['git','status','--short','--untracked-files=no'],cwd=R)==b''
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert base=='e6c4fbd0025d22a98161cb4690f708a4e97c79b2'
original=json.loads((O/'preparation.json').read_bytes())
art=original['artifacts'];files=[Path(p) for p in original['input_sha256']]
for n in ['closure_v2.py','verify_v2.py','prepare_v3.py','run_v3.py','CORRECTION_V2.md','CORRECTION_V3.md']:
 p=O/n;assert p.exists();files.append(p)
 with (O/(n+'.v3.source.txt')).open('xb') as f:f.write(p.read_bytes())
files.extend(p for p in O.iterdir() if p.is_file())
inputs={str(p):H(p) for p in sorted(set(files))}
dump(O/'preparation_v2.json',{'base':base,'input_sha256':inputs,'artifacts':art,'read_json_by_role':original['read_json_by_role'],'state_sha256':H(R/'project_state.json'),'limits':original['limits'],'preparation_controller_version':3,'scientific_source_version':2,'scientific_acceptance':'NOT_PERFORMED'})
print('PREPARED_SPM1_SOURCE_V2_CONTROLLER_V3',len(inputs))
