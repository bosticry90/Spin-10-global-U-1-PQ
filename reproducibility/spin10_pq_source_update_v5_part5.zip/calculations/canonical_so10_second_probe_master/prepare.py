from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
assert subprocess.check_output(['git','status','--short','--untracked-files=no'],cwd=R)==b''
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert base=='e6c4fbd0025d22a98161cb4690f708a4e97c79b2'
art={role:{'e2':str(P/'frozen_a10_e2_transport'/(role+'.json')),'sqp':str(R/'calculations/canonical_so10_sourcequadratic_primitive_probe'/(role+'_v5_result.json'))} for role in ['primary','replay']}
files=[R/'AGENTS.md',R/'CHARTER.md',R/'project_state.json',R/'docs/LOCAL_RESEARCH_CONVENTIONS_V1.md',R/'docs/SOLO_REVIEW_POLICY_V1.md',R/'docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V583.md',R/'tools/portable_dh_v1/inputs.json.gz',R/'tools/portable_dh_v1/exact_algebra.py',P/'export_a10_e5_antighost_vector.py',P/'frozen_a10_e2_transport/validation_receipt.json',P/'frozen_a10_e2_transport/bindings.json',R/'calculations/canonical_so10_sourcequadratic_primitive_probe/verify.py']
for sub in ['canonical_so10_sourcequadratic_primitive_probe','canonical_so10_double_source_finite_ward']:
 d=R/'calculations'/sub
 for n in (['RESULT.md','DERIVATION.md','TRACE_DOMAIN_NOTE.md','validation_receipt.json'] if 'sourcequadratic' in sub else ['RESULT.md','validation_receipt_v3.json','orbit_receipt_v4.json']):files.append(d/n)
for byrole in art.values():files.extend(Path(p) for p in byrole.values())
for n in ['RECORD.md','DERIVATION.md','closure.py','prepare.py','run.py','verify.py','build_verifier.py']:
 p=O/n;assert p.exists(),str(p);files.append(p)
 with (O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
files.extend(O.glob('*.source.txt'))
inputs={str(p):H(p) for p in sorted(set(files))}
dump(O/'preparation.json',{'base':base,'input_sha256':inputs,'artifacts':art,'read_json_by_role':{r:list(a.values()) for r,a in art.items()},'state_sha256':H(R/'project_state.json'),'limits':{'seconds_after_imports':600,'sampled_private_bytes':8*1024**3,'launch_available_commit_floor':350*1024**2,'packet_bytes':8*1024**2},'scientific_acceptance':'NOT_PERFORMED'})
print('PREPARED_SPM1',len(inputs))
