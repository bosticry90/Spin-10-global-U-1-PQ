# Second local probes: actual master closure before quantum products (SPM1)

Base e6c4fbd0025d22a98161cb4690f708a4e97c79b2 on main. The previous goal
turn was PROGRESS. State113/34of39 and custody exit2/seven remain unchanged.

Question: does the COMPLETE transported two-source dimension3 odd primitive
module require new classical second-probe/contact vertices, or is the actual
module a Q-stable isotropic subalgebra? This decides the correct augmented
functional from which nonlinear quantum products must be constructed. It does
not infer those products from classical canonicality or from Q squared.

Reuse SQP's qualified first-probe result, not its execution. Its old actual
3890-term primitive is an authenticated input. Reconstruct only its pre-U
carrier and the actual source operation needed for this new closure question.
The complete carriers are JL*Ja and JL*JL*C. Their coefficients may be local
independent even tests; odd rho tracking tests and ALL local jets remain.
No new physical parameter, action, source projection or vacuum is adopted.

Primary: derive U-inverse Q U on all90 relevant source coordinates from the
full E2 source columns and q of the actual gauge-fixing shifts. Replay:
differentiate the actual ungauge-fixed source action sum J_i qz_i directly,
scanning ALL field rules for a,Lambda dependence. Both retain all45 qC.
Test whether all135 coordinate images use only C,Ja,JL and no jets. A single
outside variable refutes the proposed closure. Preserve its exact remainder.
The canonical variational source-shift proof in E2 includes arbitrary test
jets and currents; it is an inherited dependency, not freshly re-proved.

Fresh direct local functional brackets of light/heavy transported component
fixtures must include source derivatives and probe jets. Their polarized
G-G, G-QG, QG-QG classes are zero ONLY if the actual reconstruction supports
the general proof. Keep a nonzero individual Euler-leg control, and check
that forcing probes constant loses actual adjoint terms. Component fixtures
are not separately claimed invariant physical counterterms.

Two sequential routes, each600s after imports,8GiB sampled private allocation,
350MiB available-commit launch floor. Separate600s verifier, same memory/floor.
Package8MiB. Freeze this record, derivation, code, controller and each route's
inputs before execution. Preserve every source/capture and exact failed or
unfinished execution; no cap expansion. Native results are not validation.

The distinct verifier must freshly reconstruct all135 coordinate images,
use independent differentiation order on local fixtures and validate the
actual carrier bridge. Shared action/reference, E2 proof, exact arithmetic,
software and AI authorship remain limits. No outside scientist/Lean/experiment.

Acceptance: actual Q-stable isotropic carrier theorem and a correctly typed
second-probe operator problem, or a precise counterexample/underdefinition.
Do not assert a quantum double-insertion extension, raw heat-Jacobian zero,
full chiral measure, QAP, E5/A5, causal/physical/global limits from this alone.
Retain Gamma_ref, all heat/reference/inverse/measure conversion defects and
the distinct finite constants. No new naked G M0 G M0 G domain is inferred.

Next decision: if closure holds, use the SAME linear augmented master action
to derive its ordered second derivatives; retain an explicit quantum breaking
until its actual finite/contact construction is established. If not, derive
the missing higher-probe vertices from the actual bracket, never fit them.
No flavor/HB1/C5 activation, evidence/state changes, branch/worktree, push,
publication or outreach. Historical policies and failed physics remain intact.
