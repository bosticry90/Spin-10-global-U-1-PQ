# The complete two-source module has an exact classical local-probe extension

The actual source operation closes on the ungauge-fixed carrier algebra
chi=(C,Ja,JL). Two distinct routes and a separate expanded-arithmetic verifier
agree on all135 coordinate images and their1,684 nonzero coefficient positions.
No coordinate conjugate to a member of chi belongs to chi. Consequently the
complete transported two-source primitive module is a Q-stable isotropic
algebra. This removes a specific possible source of new second-probe TREE
vertices. It does not construct or cancel the quantum connected products.

Scientific authority remains state113/34of39. This is an action-based classical
reduction within the fixed qualified chart, not full QAP, quantum equivalence,
E5/A5 or physical viability. The earlier generic w/h family needs its own
complete extended transport when these factors are used there; no frozen
scalar column is transferred unchanged to a new vacuum.

## What was reconstructed

The complete source-degree>=2, dimension3, ghost-number-1 odd primitive
carriers were already qualified by SQP:

    G0=M_ij JL_i Ja_j + N_ij;k JL_i JL_j C_k.

There are2,025 ordered JL*Ja slots and44,550 exterior JL*JL*C slots before
reality/background restrictions. These are carrier positions, not invariant
ranks or independent physical counterterms. U is the existing variational
gauge-fixing source shift; all correlated lower-source terms remain.

The primary reconstructed the untwisted operation from the COMPLETE E2
source columns, the actual field rules and the gauge-fixing shifts:

    Q0 J = U^-1[QJ + q A_J],       UJ=J+A_J.

The replay instead differentiated the actual ungauge-fixed source action
sum J_i qz_i with respect to all90 antighost/auxiliary field coordinates.
Every one of the643 field rules was scanned for that dependence. The relevant
physical action has none of these variables; its Eulers were not set on shell.
Both routes retain all45 actual qC columns. Their full135 coordinate outputs,
including zeros and all parameter powers, agree. Their combined support uses
122 of the135 carrier names, and contains no ordinary-field or jet remainder.

The previous3890-term actual Ksrc was reused as authenticated input, not
recalculated as another first-probe result. Undoing U gives its exact70-term
carrier seed. Forward transport recovers every old coefficient and fingerprint.
The seed fingerprint is
c23de1ef152a8241ece5415f57ee447ad2f7ad3b3d5224ce3551c94ae9eebad9.

## Why the reduction holds for arbitrary coefficient tensors

Local functions of chi have zero mutual BV brackets, since their coordinate
set contains no complete canonical pair. The135-coordinate calculation
establishes that Q0 sends this whole algebra to itself. Thus all polarized
G0-G0, G0-Q0G0 and Q0G0-Q0G0 brackets vanish, for arbitrary admitted tensors
and independent local test functions. This is stronger than testing an odd
generator's automatically zero self bracket or appealing to Q squared.

The inherited E2 source-shift proof is anticanonical with arbitrary test jets
and ordinary currents. It transports these integrated functional statements
to the actual gauge-fixed G=UG0. Therefore the SAME augmented action

    S_ext=S+sum_a [u_a QG_a+rho_a G_a],
    d=sum_a integral rho_a delta/ delta u_a,

already satisfies the classical extended master relation, including the
quadratic probe terms. No second-order classical connection or action vertex
is needed for THIS complete module. This is not a claim about all one-source
primitives, all insertions or arbitrary changes of integrated variables.

The fresh local tests cover light/heavy representatives of both carrier types
and all three bracket classes. Their12 complete local brackets vanish. The
test code supplies and checks exact boundary-current identities; these
particular representatives have zero final density and zero current. They
are not advertised as nonzero-current controls. The light JL*Ja example has
129 and946 nonzero positions in separate field Euler legs which cancel their
source companions. Those two omission controls are sensitive; the zero
individual legs in the other projections are explicitly insensitive.

Separately,32 actual local-probe adjoint positions are nonzero across the
fixtures. Treating the probes as constants would lose them. Full source
and field differentiation precedes source0 and probe projections.

## What is still required at the quantum level

Absence of a classical seagull does not remove the second ordered log term.
For even marked insertions, its operator form is

    Gamma1,ab=(i/2) T_kappa[G H_ab-G H_a G H_b],

with graded ordered polarization for odd tracking derivatives. Here the
classical H_ab is zero, but the product term has not thereby been evaluated.
A separate finite diagnostic verifies this distinction: H=2+a+b has H_ab=0,
yet the mixed derivative of log(H)/2 is-1/8. This is a diagnostic, not a
Spin10 amplitude or a contact coefficient to insert into the theory.

The actual second-probe Ward question is the corresponding coefficient of

    B1[u,rho]=(S_ext,Gamma1[u,rho])+d Gamma1[u,rho].

B1 remains explicit. A classical master equation does not determine its
finite quantum/contact part or the chiral measure. Keep the complete heat,
reference, inverse, power and dimension-jet defects, all source derivatives
and local probe jets. No unrestricted trace cyclicity, coincident-product
pullback, two naked constant-tangent product or Q-squared shortcut is used.
Gamma_ref and the distinct kappa,b0,chi4 and IR normalizations remain.

Next: derive the actual two-labelled-insertion kernel from this linear
augmented functional, beginning with the complete highest-source part of the
transported JL*Ja and JL*JL*C Hessians. The existing dimension2 composite
bubble construction supplies a comparator, but its tensor cannot simply be
assigned to this different module. Cross-generator probes must be retained:
the vanishing square of one odd rho is not coverage of polarized products.
Local contact coefficients must be measured before declaring the selected
quantum equation zero. This reduction avoids computing spurious tree vertices.

## Execution, verification and limitations

V2 native primary/replay elapsed8.7214357/5.0176249seconds after imports;
the separate verifier took10.9185114seconds. They used5/3/7 private-memory
samples with maxima518,463,488/484,155,392/500,273,152bytes. These are sampled
observations, not true peaks. All600s/8GiB/350MiB-floor/8MiB limits held.
The packet before this report was361,079bytes. Preparations bind60 inputs;
validation binds68;13 exact source snapshots are preserved.

One scientific worker failed before a table: V1 used the wrong minus sign
in the untwisting composition. Applying U^-1 Q U to a coordinate fixes a
PLUS independently of the desired closure; the separate source-action route
agrees. The original formula, source, full diagnostic and failed controller
remain. Its8 memory samples have maximum479,928,320bytes. V2 preparation
also failed before any worker because an exclusive source-copy path already
existed. V3 preparation uses fresh snapshot names and executes unchanged
corrected V2 workers. Both failures remain failures, with no fabricated
original/V2-preparation validation. There was no failed scientific verifier.

The verifier imports no new native module. It uses the independently written
expanded-Fraction/right-gradient arithmetic from the qualified SQP verifier,
reconstructs all135 action-derived images, the actual carrier bridge, local
brackets/adjoints/currents, and a power-series double-log control. It does not
re-execute the old first-probe or loop calculations. Both methods still share
action, reference, E2 canonical theorem, some conventions, software and AI
authorship. Their agreement is internal mathematical corroboration, not an
external scientist's confirmation, a Lean proof or physical evidence.

Validation receipt SHA256:
bd6c85f72d4990d9dba97fd9d0084d672fd6e921ef7197b3b003b974757ca632.
Primary packed/raw:
c49db2cd7a0ea603332a59eaa8f26a711851f3bd35bce9c5200ab031eb482de4 /
db702a096bbaf5008f3cab57bb2f0d4e30fbfc86efa414e51355e1ef646438b8.
Replay packed/raw:
c32894980ef7ed87059193cd336f23db5e6e316975159a66575c474b322fda44 /
550b9f8bd9dd9f06f2e034a8ce0c18c50a591911649662b016bec2d12bebc799.

Inspect the external second-probe-master-v1-2026-10-24 preservation seals for
final Git/clean status, all old tracked blobs and the current E4 capture.
Historical custody remains exit2/seven NOTPASS; it is not an overall PASS.
No state, action, scheme, foundation, physical benchmark, flavor/HB1/C5 block
or old evidence changed. No push/publication/outreach. The complete Spin10 x
PQ investigation, nonlinear quantum products, full measure/global phase,
physical limits, massive fermionic threshold and physical viability remain open.
