from pathlib import Path
from hashlib import sha256
import ast,json,gzip,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/remaining-u-contacts-support-v1-2026-10-26');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b={}
 for n in['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V638.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:p=R/n;b[str(p)]=H(p)
 IQC=O.parent/'canonical_so10_intrinsic_quadratic_source_contacts';ICR=O.parent/'canonical_so10_intrinsic_correlated_source_contacts'
 for n in['support_preparation.json','support_validation_preparation.json','support_validation_receipt.json']:
  p=IQC/n;b[str(p)]=H(p)
  if 'preparation'in n:
   for pp,hh in read(p)['input_sha256'].items():assert H(Path(pp))==hh
 for role in['primary','replay']:
  p=IQC/('support_'+role+'_inputs.json.gz');b[str(p)]=H(p);d=load(p);p=ICR/('contact_support_'+role+'_inputs.json.gz');b[str(p)]=H(p);d['GF']=load(p)['GF'];p=IQC/('support_'+role+'_tables.json.gz');b[str(p)]=H(p);d['qualified_u_ghost_principal_counts']=load(p)['full_u_ghost_principal_symbol_nonzero_counts'];p=O/('support_'+role+'_inputs.json.gz')
  with p.open('xb')as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 for n in['RECORD.md','support.py','run.py']:
  p=O/n
  with(O/(n+'.source.txt')).open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
 for p in O.iterdir():
  if p.is_file():b[str(p)]=H(p)
 dump(O/'preparation.json',{'input_sha256':b,'seconds_after_imports':300,'scientific_acceptance':'NOT_PERFORMED'})
 for role in['primary','replay']:
  z=capture([sys.executable,'-B',str(O/'support.py'),role]);dump(O/('support_'+role+'_capture.json'),z);dump(C/('support_'+role+'_full_capture.json'),z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<300;dump(O/('support_'+role+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2;print('COMPLETED_UCS1',role,json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
