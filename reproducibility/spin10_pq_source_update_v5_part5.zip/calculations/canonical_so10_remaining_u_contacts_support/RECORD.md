# UCS1: joint support for the two remaining u quadratic-source contacts

Prospective at2ce7c0c8d324637fc20b10f709c728a0cff35c9a,V638. The selected
rho JL Cx relative relation is qualified zero;this does not supply another
contact coefficient. Goal ACTIVE/INCOMPLETE. State113,authority34/39,
E5/A5 OPEN,custodyexit2/seven NOTPASS. Live AGENTS and existing charter/
solo review/epistemic ladder apply. No agents,branch/worktree,remote action,
publication,scheme/foundation/benchmark adoption,protected activation or
promotion. Preserve all prior evidence and failed checks.

Question:do the two remaining u Ja JL C and u JL JL CC contact TYPES have
a common finite proper-loop construction? First derive their complete
marginal ordered support jointly from actual QG,qa,qLambda and GF,not from
desired Ward cancellation. All45 directions,both constant probes,original
unshifted SMA/CSW/EDS,A0,externaljets0,intrinsicdegree0,symbolic parameters.
Subsequent coefficients retain the same Euclidean LOCAL RELATIVE domain.

Grade is(u,Ja,JL,C). Targets(1,1,1,1)and(1,0,2,2). Each typed Hessian
entry retains its original component references and both quantum-port
orders. Select quantum ports BEFORE excluding unused mean fields. Preserve
all source degrees,source-only/one-port terms and derivative exclusions.
QG source counts/roles are inspected before filtering. Include ordinary
GF ghost currents/seagulls and Ja C a,JL C Lambda,JL CCa source vertices.
Do not transfer Ja-family zero or old four-edge bound to these new grades.

Directed cycle enumeration versus multiset/permutation/port attachment.
Exact positive-grade bound is sum(target),up to5edges. Keep heat lengths,
field ports,internal jets,STr signs and ordered logarithm weights. Reuse
only the already qualified complete zero u ghost principal symbol from
IQC as an explicit dependency;do not reinterpret missing coefficients as
zero. Every ordinary zero-grade free edge is resummed in the reference.
At zero mean fields and A0,physical interactions have unused B/x/fermion
means or intrinsic mass degree;isolated free kinetic blocks are reference
edges. An unexpected actual QG matter/source role fails for audit instead
of being silently excluded. This is typed support,not nonzero amplitudes.

Acceptance:full independent catalog/word/reference equality,cyclic closure,
exact heat bound and exclusions,all source/one-port evidence preserved.
Sensitive support controls remove any source family/actual u insertion
that appears in a supported path;record insensitive controls if absent.
Then identify the complete common ordered operator expression and needed
classical vertices;no model coefficient,normalization or quantum identity
is qualified by this inventory alone. Further Gaussian/model work needs
its own bounded frozen record. No chi4/b0/kappa/IR constant selection.

Natives300s,review180s afterimports,8GiB sampled private,350MiB available-
pagefile floor,32MiB wholepacket. Freeze sources/copies and actual inputs/
hashes before computation. Preserve failures/exhaustion,new version for
routine corrections. Shared action/maps/charts/Python/AI authorship limit
independence. Full QAP/products/master/chiral measure/physical claims open.
