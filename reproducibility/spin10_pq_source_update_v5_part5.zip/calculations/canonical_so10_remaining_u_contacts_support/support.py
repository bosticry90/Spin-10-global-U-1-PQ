from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from itertools import combinations,permutations
import json,gzip,sys,time,threading,os
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
d=load(O/('support_'+role+'_inputs.json.gz'));audit=d['audit'];names=audit['names'];geo=audit['geometry'];base=geo['names'];fields={names.index(base[f]):base[f]for f,J,h,k in geo['field_source_h_k']};sources={names.index(base[J]):base[f]for f,J,h,k in geo['field_source_h_k']};aux={('b'if i<12 else'L')+str(i)for i in range(45)};ants={('bar'if i<12 else'ub')+str(i)for i in range(45)}
def kind(n):
 if n in aux:return'L'
 if n in ants:return'a'
 if n.startswith('B'):return'B'
 if n.startswith('C'):return'C'
 if n.startswith('x_'):return'x'
 return None
dims={'B':1,'L':2,'C':1,'a':1,'x':1};catalog=defaultdict(list);excluded=Counter();lowports=[];hist=[]
def add(origin,n,u,ja,jl,ww,ref):
 if n!=0:excluded['other_intrinsic_grade']+=1;return
 if ja>1 or jl>2:excluded['too_many_target_sources']+=1;return
 if len(ww)<2:lowports.append({'origin':origin,'grade':[u,ja,jl,0],'fields':ww,'reference':ref});excluded['zero_or_one_quantum_port']+=1;return
 pairs=((i,j)for i in range(len(ww))for j in range(len(ww))if i!=j)if role=='primary'else(pair for ij in combinations(range(len(ww)),2)for pair in[ij,ij[::-1]])
 for i,j in pairs:
  ext=[v for k,v in enumerate(ww)if k not in[i,j]]
  if any(k!='C'or jets for k,jets in ext)or len(ext)>2:excluded['unused_mean_field_or_external_jet']+=1;continue
  gr=(u,ja,jl,len(ext))
  if not any(gr):excluded['resummed_zero_grade_reference']+=1;continue
  L,R=ww[i],ww[j];key=(origin,*gr,L[0],R[0],L[1],R[1]);catalog[key].append([*ref,i,j])
for probe,p in enumerate(audit['physical_QG']):
 hh=Counter()
 for at,(gp,w,ci)in enumerate(p['monomials']):
  js=[(n,I)for n,I in w if n in sources];hh[len(js)]+=1
  if any(sources[n]not in aux|ants for n,I in js):raise AssertionError(('unexpected_QG_source_role',probe,at))
  if any(n not in fields and n not in sources for n,I in w):excluded['background_or_control_at_A0']+=1;continue
  if any(I for n,I in js):excluded['external_source_jet']+=1;continue
  ww=[(kind(names[n]),len(I))for n,I in w if n in fields];assert all(k in dims for k,j in ww),('unclassified_actual_QG_field',probe,at)
  ja=sum(sources[n]in ants for n,I in js);jl=sum(sources[n]in aux for n,I in js);add('uQG'+str(probe),4-2*ja-jl-sum(dims[k]+j for k,j in ww),1,ja,jl,ww,[at])
 hist.append(dict(hh))
for source,maps in[('Ja',d['qa']),('JL',d['qLambda'])]:
 for out,rows in maps.items():
  assert out in(ants if source=='Ja'else aux)
  for at,row in enumerate(rows):
   ww=[]
   for token in row['word']:
    n,sep,jets=token.partition('__');k=kind(n);assert k in dims;ww.append((k,len(jets)))
   add('Jqa'if source=='Ja'else'JqLambda',4-(2 if source=='Ja'else 1)-sum(dims[k]+j for k,j in ww),0,int(source=='Ja'),int(source=='JL'),ww,[out,at])
for at,row in enumerate(d['GF']):
 ww=[]
 for token in row['word']:
  n,sep,jets=token.partition('__');k=kind(n)
  if k is None:excluded['GF_background_at_A0']+=1;break
  ww.append((k,len(jets)))
 else:add('GF',4-sum(dims[k]+j for k,j in ww),0,0,0,ww,[at])
assert d['qualified_u_ghost_principal_counts']==[0,0];letters=[];zero_principal=[]
for key,refs in sorted(catalog.items()):
 origin,u,ja,jl,c,L,R,j1,j2=key
 if origin.startswith('uQG')and(u,ja,jl,c)==(1,0,0,0)and{L,R}=={'a','C'}:
  assert j1+j2==2;zero_principal.append({'origin':origin,'H_ports':[L,R],'jets':[j1,j2],'references':sorted(refs,key=str)});continue
 letters.append({'id':len(letters),'origin':origin,'grade':[u,ja,jl,c],'H_ports':[L,R],'internal_jet_orders':[j1,j2],'member_references':sorted(refs,key=str)})
green={('B','B'),('B','L'),('L','B'),('C','a'),('a','C'),('x','x')};ks=sorted(dims);sub=lambda aa,bb:tuple(a-b for a,b in zip(aa,bb));sat=lambda aa:all(a>=0 for a in aa);results=[]
for probe in range(2):
 for name,target in[('u_Ja_JL_C',(1,1,1,1)),('u_JL_JL_CC',(1,0,2,2))]:
  active=[z['id']for z in letters if sat(sub(target,z['grade']))and(not z['origin'].startswith('uQG')or z['origin'].endswith(str(probe)))];opts={i:[(r,letters[i]['H_ports'][1])for r in ks if(r,letters[i]['H_ports'][0])in green]for i in active};found=set()
  if role=='primary':
   edges=defaultdict(list)
   for i in active:
    for r,c in opts[i]:edges[r].append((i,c))
   def walk(start,at,left,ww,path):
    if not any(left):
     if at==start:found.add((tuple(ww),tuple(path)))
     return
    for i,to in edges[at]:
     rem=sub(left,letters[i]['grade'])
     if sat(rem):walk(start,to,rem,ww+[i],path+[to])
   for start in ks:walk(start,start,target,[],[start])
  else:
   multis=[]
   def choose(lo,left,ww):
    if not any(left):multis.append(tuple(ww));return
    for at in range(lo,len(active)):
     i=active[at];rem=sub(left,letters[i]['grade'])
     if sat(rem):choose(at,rem,ww+[i])
   choose(0,target,[])
   for ms in multis:
    for ww in set(permutations(ms)):
     def attach(at,path):
      if at==len(ww):
       if path[-1]==path[0]:found.add((ww,tuple(path)))
       return
      for r,c in opts[ww[at]]:
       if not path or path[-1]==r:attach(at+1,(path or[r])+[c])
     attach(0,[])
  words=[];families=Counter();heat=Counter()
  for ww,path in sorted(found):
   assert len(ww)<=sum(target)
   for at in range(len(ww)):assert(ww[at:]+ww[:at],path[at:-1]+path[:at]+(path[at],))in found
   words.append({'letters':list(ww),'Green_path':list(path),'STr_sign':(-1)**int(path[0]in['a','C']),'ordered_log_weight':[(-1)**(len(ww)+1),2*len(ww)]});heat[len(ww)]+=1;families[len(ww),tuple(sorted(letters[i]['origin']for i in ww))]+=1
  results.append({'probe':probe,'target':name,'grade':list(target),'ordered_words':words,'heat_counts':dict(heat),'families':[{'heat':m,'origins':list(orig),'profiles':n}for(m,orig),n in sorted(families.items())]})
out={'schema':'UCS1_JOINT_REMAINING_U_CONTACT_TYPED_SUPPORT','role':role,'letters':letters,'results':results,'excluded':dict(excluded),'zero_or_one_port_classical_terms':lowports,'full_QG_source_inventory':hist,'qualified_zero_u_ghost_principal_exclusions':zero_principal,'typed_support_not_quantum_coefficient':True,'no_inferred_Ward_or_QAP_claim':True};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('support_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'letters':len(letters),'targets':[[q['probe'],q['target'],len(q['ordered_words']),q['heat_counts']]for q in results],'proper_loop_coefficients_measured':False},sort_keys=True),flush=True);timer.cancel()
