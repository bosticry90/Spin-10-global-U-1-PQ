from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,gzip,time,threading,os
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'review_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
primary,replay=[load(O/('support_'+role+'_tables.json.gz'))for role in['primary','replay']]
for key in['letters','results','excluded','zero_or_one_port_classical_terms','full_QG_source_inventory','qualified_zero_u_ghost_principal_exclusions']:assert primary[key]==replay[key],key
letters=primary['letters'];green={('B','B'),('B','L'),('L','B'),('C','a'),('a','C'),('x','x')};assert all(z['id']==j and any(z['grade'])and z['member_references']for j,z in enumerate(letters));reports=[]
for q in primary['results']:
 words=q['ordered_words'];target=tuple(q['grade']);by={(tuple(z['letters']),tuple(z['Green_path']))for z in words};assert len(by)==len(words);heat=Counter();families=Counter();controls=Counter();scalar=0;source2_u=0
 for z in words:
  ww=z['letters'];path=z['Green_path'];assert len(path)==len(ww)+1 and path[0]==path[-1]and 1<=len(ww)<=sum(target)
  grade=tuple(sum(letters[i]['grade'][j]for i in ww)for j in range(4));assert grade==target
  for at,i in enumerate(ww):
   L,R=letters[i]['H_ports'];assert(path[at],L)in green and R==path[at+1]
   origin=letters[i]['origin'];assert not origin.startswith('uQG')or origin.endswith(str(q['probe']))
   if origin.startswith('uQG')and letters[i]['grade'][1]+letters[i]['grade'][2]==2:source2_u+=1
  for at in range(len(ww)):assert(tuple(ww[at:]+ww[:at]),tuple(path[at:-1]+path[:at]+[path[at]]))in by
  assert z['ordered_log_weight']==[(-1)**(len(ww)+1),2*len(ww)]and z['STr_sign']==(-1)**int(path[0]in['a','C']);heat[len(ww)]+=1;origins=tuple(sorted(letters[i]['origin']for i in ww));families[len(ww),origins]+=1
  for family in['uQG','Jqa','JqLambda','GF']:
   if any(letters[i]['origin'].startswith(family)for i in ww):controls[family]+=1
  scalar+=int(any('x'in letters[i]['H_ports']for i in ww))
 assert dict(heat)=={int(k):v for k,v in q['heat_counts'].items()}
 assert q['families']==[{'heat':m,'origins':list(orig),'profiles':n}for(m,orig),n in sorted(families.items())]
 assert controls['uQG']==len(words)
 reports.append({'probe':q['probe'],'target':q['target'],'ordered_profiles':len(words),'heat_counts':dict(heat),'interaction_families':len(families),'scalar_port_profiles':scalar,'direct_source2_u_occurrences':source2_u,'support_omission_removed_profiles':dict(controls)})
for role in['primary','replay']:
 rr=read(O/('support_'+role+'_result.json'));p=O/('support_'+role+'_tables.json.gz');assert H(p)==rr['packed_sha256']and sha256(gzip.decompress(p.read_bytes())).hexdigest()==rr['raw_sha256']and rr['elapsed_after_imports']<300
assert len(reports)==4;print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'complete_catalog_references_and_ordered_words_agree':True,'all_target_grades_Green_paths_weights_and_cyclic_rotations_verified':True,'exact_positive_grade_bound_not_truncation':True,'qualified_zero_principal_exclusions_authenticated':len(primary['qualified_zero_u_ghost_principal_exclusions']),'reports':reports,'quantum_coefficients_or_QAP_E5_claim':False},sort_keys=True),flush=True);timer.cancel()
