# UCS2: full joint-support qualification

Authenticate all actual inputs and inherited zero-principal evidence.
Require equality of the two complete letters/reference catalogs,each
ordered word/path,exclusion/source inventory and preserved low-port term.
Check every word's target grade,propagator compatibility,cyclic closure,
ordered logarithm weight,Grassmann trace sign and exact positive-grade
bound. Inspect every active letter origin/source role. Identify omissions
of actual u,Ja,JL and GF families as support controls,recording any
insensitivity. These controls test loop support,not quantum amplitudes.

The resulting common operator is the retained target projection of
1/2 STr log(1+G H),or equivalently its linear-u resolvent coefficient.
Explicit finite ordered words are the output,not a measured contraction
or a global restoration theorem. No Born rule,physical model,renormalization
scheme or authority change. Keep all coefficient/product/QAP limits.

Review180s,8GiB sampled private,350MiB available-pagefile floor,32MiBpacket.
Freeze sources/copies/preparation before execution;preserve failed runs.
