# The two remaining u contact types have a common finite support

PROGRESS. The complete marginal proper-loop support for u Ja JL C and
u JL JL CC is constructed jointly from actual QG,qa,qLambda and GF.
Independent directed cycles and multiset/permutation port attachment
agree on every letter,original component reference and ordered word.
No scalar propagator occurs in either target's supported profiles.

This is support and an ordered calculation domain,not a measured contact
coefficient or a proof that every allowed profile is nonzero. State113,
authority34/39,E5/A5 OPEN,custodyexit2/seven NOTPASS remain unchanged.
The selected rho JL Cx relation closed in the prior checkpoint supplies
no coefficient for these distinct contacts. Goal ACTIVE/INCOMPLETE.

| Probe | Target | Heat2 | Heat3 | Heat4 | Heat5 | Total |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 0 | u Ja JL C | 0 | 0 | 40 | 0 | 40 |
| 0 | u JL JL CC | 0 | 0 | 44 | 140 | 184 |
| 1 | u Ja JL C | 8 | 36 | 40 | 0 | 84 |
| 1 | u JL JL CC | 6 | 42 | 60 | 140 | 248 |

The joint catalogue has32 letters. The per-target source-origin family
counts are1,2,5,7 in table order. Source2 u insertions occur26 times among
the last target's profiles. All270 source-only/one-port classical terms
are retained separately;their absence from proper loops does not remove
them from the action or source operation. Source-degree inventories were
inspected before target filtering. No unexpected source/matter role was
silently dropped. The already qualified zero u ghost principal symbol is
bound as a dependency;no new principal letter required exclusion here.

The five-edge terms are genuine members of this support. The four-edge
bound of the earlier ordinary aCx/JL Cx kernels does not transfer. A
future radial calculation must retain separate edge lengths and possible
dimensional finite terms. No claim about a particular log5 coefficient
follows from support alone. Likewise,nonempty probe0 support does not prove
its actual color contraction is nonzero;projector identities may matter.

The common ordered expression is the target projection of

    1/2 sum_m (-1)^(m+1)/m STr[(G H)^m],

with m bounded by the actual positive target grade. Equivalently,the
linear-u coefficient is the appropriately ordered resolvent with one
H_u insertion. Explicit finite word/port tables preserve that order.
No scalar spectral reconstruction is needed for these proper-loop targets;
the necessary vector,auxiliary and ghost/source vertices must still be
derived with their real coefficients and phases.

Verification checks every target grade,Green compatibility,cyclic
rotation,STr sign and ordered logarithm weight. Source-family omission
controls remove the recorded supported profiles;absent Ja dependence in
u JL JL CC is correctly not credited as a sensitivity test. These are
support controls,not tested quantum amplitudes. Proper coefficient
normalization,Grassmann pair conventions and quantum kernel comparisons
remain work to perform under a separate frozen increment.

Native primary/replay2.4724/2.5787s,review.0859s afterimports. No failed
native or incomplete capture. Preparations65bindings,sixsourcecopies,
threecaptures;largest sampled private125911040B,not continuous peak.
Packet1633931B before this report. Bounds300s native/180sreview,8GiB
sampled,350MiB available-pagefile floor,32MiBpacket unchanged. Shared
action/maps/charts/runtime/software and AI authorship limit independence.
No proof assistant or external physical validation is claimed.

Next derive a complete paired Gaussian/Schur kernel for these two targets,
including u source-free quadratic insertions,probe1 external-ghost and
direct source2 Hessians,the ordinary quartic ghost CC endpoint and both
nonminimal source vertices. Retain up to five heat edges. Set exterior
pair conventions explicitly for the two JL and two C variables. Compare
actual vertices and generic controls before any full model tensor or
identity test. A smaller complete trace reduction is preferable to blind
45^4 expansion,but it cannot replace missing quantum inputs by a zero.

Original unshifted SMA/CSW/EDS,A0,externaljets0,intrinsicdegree0,both
constant probes and symbolic parameters remain. Subsequent coefficients
use the existing Euclidean LOCAL RELATIVE symbol. chi4,b0,kappa and
infrared freedoms stay distinct/unfixed. Full T/F,ordinary BBx,nonlinear
master applicability,renormalized products,chiral QAP/measure/global phase,
source reality,massive/causal domains and physical viability remain open.
No flavor/HB1/C5 activation,protected promotion,foundation/scheme adoption
or remote action follows. project_state remains sole scientific authority.
