"""Check all gauge outputs of the selected two-edge contact."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)
seagull = source.seagull


def check(phase):
    _, _, _, f, _, _ = source.owner.inputs(phase)
    folder = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    cubic, quartic = {}, defaultdict(list)
    for g, word, cells in rows:
        ids = [i for i, _ in word]
        if g == 1 and len(ids) == 3 and 48 <= ids[0] < 180 and ids[0] % 4 == 1 and 565 <= ids[1] < 598 and 643 <= ids[2] < 823 and (ids[2]-643) % 4 == 1:
            assert all(not d for _, d in word) and all(p[:2] == [0, 0] for p, _, _ in cells)
            a, u, k = (ids[2]-643)//4, ids[0]//4, ids[1]-553
            z = seagull.unpack([([0, *p], n, d) for p, n, d in cells])
            assert (a, u, k) not in cubic
            cubic[a, u, k] = z
        if g == 2 and len(ids) == 4 and ids[1] < 180 and ids[0] % 4 == ids[1] % 4 == 1 and 565 <= ids[2] < 598 and 610 <= ids[3] < 643:
            assert all(not d for _, d in word) and all(p[:2] == [0, 0] for p, _, _ in cells)
            b, d, c, k = ids[0]//4, ids[1]//4, ids[2]-553, ids[3]-598
            z = seagull.unpack([([0, *p], n, d) for p, n, d in cells])
            if b >= 12:
                quartic[b, k].append((d, c, z*(1+int(b == d))))
            if d >= 12 and b != d:
                quartic[d, k].append((b, c, z))
    D = defaultdict(lambda: sp.S.Zero)
    for (a, u, k), z in cubic.items():
        for b, c, value in quartic[u, k]:
            D[a, b, c] += z*value
    D = source.owner.clean(D)
    keys = set(D) | {(b, a, c) for a, b, c in D}
    symmetric = source.owner.clean({(a,b,c): D.get((a,b,c),0)+D.get((b,a,c),0) for a,b,c in keys})
    assert len(D) == 1830 and len(symmetric) == 1552
    assert D[1,30,23] == -D[30,1,23] == sp.Rational(1, 10)
    assert (1,30,23) not in symmetric
    witness = (0,13,14)
    assert symmetric[witness] == 57*sp.sqrt(10)/40
    # Even arbitrary lower changes [B,P C] are skew on output/input.
    for (b,c), values in f.items():
        for a,z in values:
            assert dict(f[a,c]).get(b,0) == -z
    c, d = 30, 23
    assert not f[c, d]
    def ad_s(ad_color, matrix_color, a, b):
        return sum(dict(f[ad_color,k]).get(a,0)*symmetric.get((k,b,matrix_color),0)
                   for k in range(45))

    terms = [sp.expand(ad_s(c,d,0,14)), sp.expand(ad_s(c,d,14,0)),
             sp.expand(ad_s(d,c,0,14)), sp.expand(ad_s(d,c,14,0))]
    defect = sp.expand(terms[0]+terms[1]-terms[2]-terms[3])
    assert defect == -sp.sqrt(10)/40
    return {"commuting_metric_defect": str(defect), "commuting_metric_terms": [str(z) for z in terms],
            "all_source_nonzero": len(D), "output_input_symmetric_nonzero": len(symmetric),
            "previous_pair_cancels": True, "new_pair": list(witness),
            "ordered_new_pair": [str(D.get(witness,0)), str(D.get((13,0,14),0))],
            "symmetric_new_pair": str(symmetric[witness]),
            "lower_driver_subtraction_changes_symmetric_part": False}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
