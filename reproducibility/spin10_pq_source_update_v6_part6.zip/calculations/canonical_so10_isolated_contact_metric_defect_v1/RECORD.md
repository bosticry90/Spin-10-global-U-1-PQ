# V939 pre-execution contract

Test the isolated V936 two-edge kernel after including
all gauge-source outputs and all available ordinary
gauge inputs. Freeze the V879 current, typed broken
B and ghost edges, the spatial index 1 and the
constant-ghost transverse Maxwell comparison.

Compare the complete color support to its transpose.
Check the earlier commuting row and an independent
metric-variation witness. Test the necessary
commuting-adjoint relation for any additional
symmetric metric using the full fixed kernel.
A missing such witness will leave that stronger
case open. Exclude independent other source
contacts and quantum right-hand sides from this
isolated test. No authority change.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.
