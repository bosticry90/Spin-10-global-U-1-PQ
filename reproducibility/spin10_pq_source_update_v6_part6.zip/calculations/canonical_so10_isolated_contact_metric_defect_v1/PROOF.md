# Transverse metric test of the complete isolated gauge-source tensor

Use the V936 two-edge local contact with one broken
gauge and one broken ghost edge. Retain every gauge
source output a and every external ordinary gauge
input b in the literal current. The ghost input c
is broken by the quartic port rule. Let D_c be the
resulting matrix in output and gauge input, with one
common phase and finite coefficient suppressed.

For constant ghost, the ordinary transverse quadratic
variation at the linearized order tests D_c+D_c^t.
Normalizing a changed lower derivative driver P
subtracts [B,P C] from the homogeneous driver.
Its output and input indices are skew by invariance
of the original color metric. Thus this subtraction
cannot alter the symmetric part. Ordinary cubic
terms varied by the free partial C vanish on the
constant-ghost jet. The isolated contact would
need another term if its symmetric part is nonzero.

Including all gauge outputs makes the earlier
(1,30,23) row cancel with its transposed row. The
full tensor nevertheless has nonzero symmetric
part. The new row (0,13,14) gives 57 sqrt(10)/40.
The support count includes both the original and
transposed ordered supports, including entries
created solely by transposition.

One can also test an arbitrary symmetric correction
M of the transverse color metric. In the orientation
q_B=[B,C], its compatibility equation is

    S_c = -[ad_c,M],    S_c=D_c+D_c^t.

The opposite sign convention multiplies the equation
by a common sign. For any commuting c,d it follows
by Jacobi that

    [ad_c,S_d]-[ad_d,S_c]=0.

The replay constructs the matrices from the literal
action and tests this necessary relation. A failure
excludes even a symmetric Maxwell compensation for
this isolated source tensor. Independent source terms
could change S_c. An unknown quantum right-hand side
could also change the condition. Both routes use
the same action, conventions, software and authorship.
