# V992 result

At first background degree, a local light
parameter requires the affine second cutoff
slot and a product of two first cutoff
responses. Full covariance fixes the affine
second edge by the ordered first edges.
The paired formula avoids a standalone
inverse heat operator.

The direct cutoff trace and the derivative
of the proper functional agree with the
same retained source and direct insertions.
The finite Ca and cutoff fixtures detect
omission of either ordered second path.
A separate M-ghost subtrace stays nonzero
after both exterior assignments.

One inherited left mark gives three inverse
placements. The constant parameter reduces
to V990. The finite subtraces are controls
for the local proper formula, with the
original compact analytic domain and
separate pure reference retained.
