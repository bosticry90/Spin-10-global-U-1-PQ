# Local light parameter at first background degree

Use the V984 proper affine identity with
the same V869 compact parent P. The full
light operation T_b and the fixed-A
operation T_q share the even ordinary
carrier M and its evaluation dual M^sharp.
Their difference T_A acts on A. For a
local parameter omega it varies A by
chi+M A, with chi=d omega and the
coupling in the homogeneous carrier.

Write C_A for the covariant free edge,
K_A for its ordered reference Hessian,
R_A=C_A^-1-K_A for the paired cutoff.
Let first and second derivatives be
C_1[a],C_2[a,b] and similarly for
K and R. The second derivative is
bilinear with no factor 1/2. At zero
background the exact covariances give

    C_1[chi]=M C_0+C_0 M^sharp,
    C_2[a,chi]+C_1[M a]=M C_1[a]+C_1[a] M^sharp,
    R_1[chi]=-E_0,
    R_2[a,chi]+R_1[M a]=-M^sharp R_1[a]-R_1[a] M,
    E_0=M^sharp R_0+R_0 M.

Here E_0 need not vanish because the
local parameter changes momentum.
The affine slot of the second A
derivative is fixed by first edges.
An arbitrary transverse second
background slot is outside that
conclusion.

For a direct check, differentiate
F_A G_A F_A^sharp in order. Keep
each factor's second derivative
and all six products of two first
derivatives. The inverse derivative
is

    G_2[a,b]=G K_1[a] G K_1[b] G
             +G K_1[b] G K_1[a] G-G K_2[a,b] G.

The second heat derivative has one
L_2 insertion and two ordered L_1
insertions. For each exponential
it uses its first divided difference
on L_2 and its second divided
difference on both orders of L_1
with the intermediate node retained.
On L_A=-D_A², L_2[a,b] is minus g²
times the Lorentz sum of the two
ordered products of the connection
matrices. Both paired half times
are retained separately.

No standalone inverse heat action
is needed for the cutoff comparison.
The whole paired expression is

    C_A E_q C_A
      = C_A M^sharp (1-K_A C_A)
        +(1-C_A K_A) M C_A,

where E_q=M^sharp R_A+R_A M. Its
derivative uses C_1 and K_1 and
also differentiates both adjacent
C factors. In the actual relative
trace let G^0 be the common full
mean-dependent inverse at zero A.
The first inverse difference from
covariant to fixed-flat is
-G^0 R_1[a] G^0. Therefore the
explicit fixed-A regulator
difference at first A is

    -1/2 STr G^0 (R_2[a,chi]+R_1[M a])
       +1/2 STr G^0 R_1[a] G^0 R_1[chi].

This retains the derivative of
the inverse against E_0 as well
as the new second cutoff slot.
Both vanish in the appropriate
constant-parameter reduction
except for R_1[M a], yielding V990.

Keep each insertion separately.
If U(A) is any retained direct
or source insertion, its first-A
covariant-minus-flat insertion
difference is

    -1/2 STr G^0 R_1[a] G^0 H_(U(0)).

Its explicit U derivative
multiplies the common zero-
background propagator and
cancels in the difference.
This applies separately to
T_q P, CP and T_b P. The V879
source relation gives
T_A P-CP=(1-sigma)T_A R_A
in the unmarked compact parent.
Keep the actual reference and
switch terms. A local parameter
does not allow the first-A
insertions to be set to zero
by the constant argument.

As an independent functional
check, differentiate the
difference of proper logarithms
twice. For H_1[a] the first
ordinary Hessian derivative,
twice the mixed difference is
the trace of

    G R_2[a,b]-G H_1[b] G R_1[a]
              -G H_1[a] G R_1[b]
              -G R_1[b] G R_1[a].

Use b=chi and add the homogeneous
first derivative on M a. In
T_b Delta N-Delta I_(T_b P),
the covariant cutoff is zero
and the fixed-flat E_0 remains.
Its derivative contributes
+1/2 STr G H_1[a] G E_0.
Subtract the T_A functional
variation and add its direct
insertion difference. The
H_1[chi] terms cancel and the
H_1[a] terms cancel using
R_1[chi]=-E_0. This recovers
the explicit fixed-A expression
with both cutoff terms and
the same ordered sign.

All identities are on paired
regulated ordered coefficients,
before taking UV finite parts
and then paired IR. For the
single inherited left rho
derivative the regulator is
independent of rho. Replacing
one G at a time by -G H_K G
in the displayed formula gives
one placement in the single
inverse term and two in the
double inverse term. The direct
T_q K and mixed source and
geometric insertion companions
remain as in V984. The pure
reference stays in its
separate original branch.

For comparison at the edge level,
write C_ff for the fixed-flat Born
inverse and Delta C=C_A-C_ff.
At zero A its affine first
derivative is C_0 E_0 C_0,
where E_0 is paired on both sides.
Differentiating the fixed-flat
inverse congruence gives

    Delta C_2[a,chi]
     = M Delta C_1[a]+Delta C_1[a] M^sharp
       -Delta C_1[M a]
       -C_0 K_1[a] Delta C_1[chi]
       -Delta C_1[chi] K_1[a] C_0.

The two last terms are the
two actual fixed-flat bridge
placements. A second relative
trace also differentiates the
interaction letters and has
ordered products of its first
edge derivatives. The edge
formula does not substitute
for these factors.

The actual finite check uses
the V869 light generators
r_3,r_6,r_1 and the ordinary
Ca block. At q=e2 take a=A6
along e2 with transfer e1,
and omega3 with transfer
2e1. The spectral nodes are
Q=1,R=2,S=5,P=10. The
directions are Lorentz
orthogonal so L_2 is zero.
Both ordered first-derivative
paths remain. At color row
(2,5) the products r_3 r_6
and r_6 r_3 are -sqrt(6)/6
and -sqrt(6)/24. The common
rotated carrier r_1 has entry
-sqrt(6)/4.

Use the exact finite profile
F(x)=2^-x(1-2^-x) in this
fixture. For the functions
h(x)=F(x)^2/x and
r(x)=-x(F(x)^-2-1), the
ordered second coefficient
after dividing by i sqrt(6)
is

    8 f[10,2,1]/3 + f[10,5,1]/3.

The first coefficient on M a
is -f[10,1]/4 and the endpoint
commutator is
-f[2,1]/3+f[10,5]/12.
Both functions satisfy the
affine second-edge identity.
The physical Ca covariance
uses f=-h and the cutoff f=r.
Both second values are nonzero
and removing either ordered
path spoils the check.

A separate finite M-ghost
coefficient keeps both
exterior B20/B33 assignments.
The direct second cutoff
subtrace is nonzero after
exchange, so an accidental
single-order zero cannot
remove the affine term. These
are finite labelled carrier
tests, not integrated loop
amplitudes. The general paired
reduction is algebraic and
uses the common compact
analytic domain. Both routes
share the action and software.
