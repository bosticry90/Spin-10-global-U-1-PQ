"""Check ordered affine second edges and the local proper cutoff trace."""

import importlib.util
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def actual(phase):
    path = ROOT/"calculations/canonical_so10_scalar_source_transport_v2/source_transport.py"
    spec = importlib.util.spec_from_file_location("scalar_transport_owner",path)
    owner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(owner)
    _,_,_,bracket,_,_ = owner.inputs(phase)
    f = {(i,a,b):z for (a,b),pairs in bracket.items() for i,z in pairs}
    base = ROOT/"calculations/canonical_so10_current_background_reference_bridge_v1/result_a.json"
    rows = json.loads(base.read_bytes())["compared"]["twelve_current_homogeneous_carriers"]
    R = {}
    for h in (1,3,6):
        v = {(i-553,j-553):sp.sympify(z) for i,j,z in rows[h] if 553<=i<598 and 553<=j<598}
        assert v=={(i,j):-z for (i,a,j),z in f.items() if a==h}
        R[h] = sp.SparseMatrix(45,45,v)
    assert R[3][:,6]==sp.eye(45)[:,1]/2
    assert (R[3]*R[6]-R[6]*R[3]-R[1]/2).applyfunc(sp.expand)==sp.zeros(45)
    return R,f


def divided(values,x,y,z=None):
    first = (values(x)-values(y))/(x-y)
    if z is None:
        return first
    return (first-(values(y)-values(z))/(y-z))/(x-z)


def profile(x):
    return sp.Rational(1,2)**x*(1-sp.Rational(1,2)**x)


def propagator(x):
    return profile(x)**2/x


def cutoff(x):
    return -x*(profile(x)**-2-1)


def affine_fixture(R):
    r1,r3,r6 = (R[h] for h in (1,3,6))
    color_a = sp.expand((r3*r6)[2,5])
    color_b = sp.expand((r6*r3)[2,5])
    assert (color_a,color_b,r1[2,5])==(-sp.sqrt(6)/6,-sp.sqrt(6)/24,-sp.sqrt(6)/4)
    Q,S,T,P = 1,2,5,10
    values = []
    for fun in (propagator,cutoff):
        from_a = sp.expand(-(P-S)*2*color_a/sp.sqrt(6))*divided(fun,P,S,Q)
        from_chi = sp.expand(-(T-Q)*2*color_b/sp.sqrt(6))*divided(fun,P,T,Q)
        direct = from_a+from_chi
        rotation = r1[2,5]/sp.sqrt(6)*divided(fun,P,Q)
        commutator = 2*color_a/sp.sqrt(6)*divided(fun,S,Q)-2*color_b/sp.sqrt(6)*divided(fun,P,T)
        assert direct+rotation==commutator
        assert from_a!=0 and from_chi!=0 and direct!=0
        values.append(direct)
    assert values==[sp.Rational(3274157848577,247390116249600),
                    -sp.Rational(4397057526316,9418761)]
    return [-values[0],values[1]]


def exchanged_subtrace(R,f):
    M = sp.diag(*([0]*12+[1]*33),cls=sp.SparseMatrix)
    T = {a:sp.SparseMatrix(45,45,{(i,j):z for (i,c,j),z in f.items() if c==a and min(i,j)>=12})
         for a in (20,33)}
    A,B = M*R[3]*R[6]*M,M*R[6]*R[3]*M
    traces = [[sp.expand(sp.trace(P*T[a]*T[b])) for P in (A,B)] for a,b in ((20,33),(33,20))]
    assert traces==[[0,sp.Rational(1,20)],[sp.Rational(1,20),0]]
    Q,S,T,P = 2,5,3,6
    roots = [-2*(x*divided(cutoff,P,S,Q)+y*divided(cutoff,P,T,Q)) for x,y in traces]
    assert roots==[sp.Rational(115904,567),sp.Rational(575536960,1271403)]
    weight = propagator(6)*propagator(2)*(propagator(3)*roots[0]+2*propagator(7)*roots[1])
    assert weight==sp.Rational(138230771864293,242365717546570612736)
    return weight


def ordered_trace():
    G = sp.diag(2,3)
    K = sp.Matrix([[1,2],[2,3]])
    H_a,H_c = sp.Matrix([[2,1],[1,0]]),sp.Matrix([[1,1],[1,1]])
    R_a,R_c = sp.Matrix([[1,0],[0,2]]),sp.Matrix([[2,1],[1,2]])
    R_2,R_M = sp.Matrix([[1,-1],[-1,1]]),sp.Matrix([[2,0],[0,0]])
    E_0,E_a = -R_c,-(R_2+R_M)
    tr = sp.trace
    direct = tr(G*E_a-G*R_a*G*E_0)
    full = tr(G*H_a*G*E_0)
    affine = tr(G*(R_2+R_M)-G*H_c*G*R_a-G*H_a*G*R_c-G*R_c*G*R_a)
    insertion = -tr(G*R_a*G*H_c)
    assert direct==full-affine+insertion
    assert tr(G*R_2)!=0 and tr(G*R_a*G*E_0)!=0 and insertion!=0
    dG = -G*K*G
    terms = [tr(dG*E_a),-tr(dG*R_a*G*E_0),-tr(G*R_a*dG*E_0)]
    u = sp.Symbol("u")
    G_r = G+u*dG
    assert sp.diff(tr(G_r*E_a-G_r*R_a*G_r*E_0),u).subs(u,0)==sum(terms)
    assert all(term!=0 for term in terms)


def adjacent():
    C = sp.diag(sp.Rational(1,5),sp.Rational(1,3))
    dC = sp.Matrix([[1,2],[2,0]])
    K = sp.Matrix([[4,1],[1,3]])
    dK = sp.Matrix([[1,1],[1,2]])
    M = sp.Matrix([[0,1],[-1,0]])
    inv = C.inv()
    R = inv-K
    dR = -inv*dC*inv-dK
    E = M.T*R+R*M
    dE = M.T*dR+dR*M
    I = sp.eye(2)
    direct = dC*E*C+C*dE*C+C*E*dC
    paired = (dC*M.T*(I-K*C)-C*M.T*(dK*C+K*dC)
              -(dC*K+C*dK)*M*C+(I-C*K)*M*dC)
    assert direct==paired and direct!=C*dE*C


def check(phase):
    R,f = actual(phase)
    affine = affine_fixture(R)
    weight = exchanged_subtrace(R,f)
    ordered_trace()
    adjacent()
    return {"direct_affine_second_Ca_and_cutoff":[str(x) for x in affine],
            "ordered_M_subtrace_after_exterior_exchange":str(weight),
            "paired_derivative_contains_both_adjacent_edges":True,
            "local_cutoff_and_functional_derivation_match":True,
            "three_single_mark_inverse_placements_verified":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
