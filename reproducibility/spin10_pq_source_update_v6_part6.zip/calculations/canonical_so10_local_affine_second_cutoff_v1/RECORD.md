# V992 pre-execution contract

Freeze V991, V990, V984, V983 and the
V869/V879 current, connection and source
identities. At first background degree
and one local light parameter, derive the
ordered affine second edge, paired cutoff
trace and retained source insertions.
Use independent compact labels on the
admitted proper one-loop domain. Check the
literal local affine second derivative by
ordered divided differences and carrier
congruence. Require a nonblind second-edge
and second-cutoff fixture. Keep one left
rho only on its inherited domain.
No new product or normalization adopted.

Native 120 s, final 180 s including E4
cap 120 s, 8 GiB sampled private,
350 MiB launch floor, 8 MiB artifact and
32 MiB packet. No authority change.
