from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Fr
import importlib.util,json,os,re,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/leading-local-BC-module-g1-v1-2026-11-08')
sp=importlib.util.spec_from_file_location('LBC_final_algebra',O/'compute.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a);m=a.m;J=a.J;p=a.p;read=a.read;load=a.load;digest=a.digest;plus=a.plus;scale=a.scale
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='be285423f14a0bcc5d5b8cf69efd9355fcac5013'
 for n,h in read(O/'preparation_validation.json')['sha256'].items():assert digest(R/n)==h,n
 old=(C/'README_before.md').read_bytes();oldsha=sha256(old).hexdigest();prep=read(O/'preparation.json');assert prep==read(C/'preparation.json')and old==subprocess.check_output(['git','show',head+':README.md'],cwd=R)
 for n,h in prep['sha256'].items():assert(oldsha if n=='README.md'else digest(R/n))==h,n
 for q in O.glob('*.source.txt'):assert q.read_bytes()==q.with_name(q.name.removesuffix('.source.txt')).read_bytes(),q.name
 cap=read(O/'capture.json');assert cap==read(C/'capture.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and not cap['failed_or_incomplete_counted_as_PASS'];assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and cap['all_resource_samples']and all(0<q['private_bytes']<=8*1024**3 for q in cap['all_resource_samples']);assert read(O/'result.json')['elapsed_after_imports']<120
 owner=read(m.B/'canonical_so10_leading_minimal_shadow_g1_v1/validation_receipt.json');assert owner['evidence_validation']=='PASS_LEADING_CURRENT_COCHAIN_RETRACTION_AND_KNOWN_QUANTUM_SHADOW'and owner['map_equations']==2160
 z=load(O/'complete_Lorentz_and_symbolic_module.json.gz');assert z==dict(Lorentz=a.lorentz(),module=a.sparse_maps());assert len(z['Lorentz']['all_derivative_delta_contractions'])==86 and len(z['Lorentz']['all_epsilon_contractions_after_IBP'])==28 and len(z['Lorentz']['all30_type_dispositions'])==30
 s=z['module'];Y=[tuple(x)for x in s['Y_order']];assert Y==[(i,j)for i in range(45)for j in range(45)];idx={ij:k for k,ij in enumerate(Y)};sym=[(i,j)for i in range(45)for j in range(i,45)];anti=[(i,j)for i in range(45)for j in range(i+1,45)];cols=s['quadratic_columns'];assert len(cols)==4095 and len(s['antisymmetric_D_rows'])==990;H={};K={};N={}
 for at,(lab,i,j,entries)in enumerate(cols):
  col=dict(entries);target={idx[i,j]:1,idx[j,i]:1}if i!=j else{idx[i,j]:1}
  if lab=='H':assert col==target;H[i,j]=col
  elif lab=='K':assert col=={k:-v for k,v in target.items()};K[i,j]=col
  else:assert lab=='N'and not col;N[i,j]=col
 assert set(H)==set(K)==set(sym)and set(N)==set(Y)
 for i,j,entries in s['antisymmetric_D_rows']:
  assert i<j and entries==[[idx[i,j],1],[idx[j,i],-1]]
  for col in H.values():assert col.get(idx[i,j],0)==col.get(idx[j,i],0)
 for i,j,sy,an in s['all2025_symmetric_antisymmetric_splittings']:
  sy={(r,c):Fr(n,d)for r,c,n,d in sy};an={(r,c):Fr(n,d)for r,c,n,d in an};assert all(v==sy.get((c,r),Fr(0))for(r,c),v in sy.items())and all(v==-an.get((c,r),Fr(0))for(r,c),v in an.items());assert m.clean({k:sy.get(k,Fr(0))+an.get(k,Fr(0))for k in set(sy)|set(an)})=={(i,j):Fr(1)}
 for role in['native','replay']:
  stored=load(O/(role+'_actual_polynomial_calibrations.json.gz'));assert a.calibrations(role)==stored
  for row in stored['all_generic_polynomial_calibrations']:
   q=J.decode(row['complete_Q'])
   if row['carrier']=='F':normal=J.decode(row['complete_antisymmetric_representative']);curr=[J.decode(v)for v in row['four_full_antisymmetry_currents']]
   else:normal=J.decode(row['complete_B_normal']);curr=[J.decode(v)for v in row['four_currents']]
   assert plus(q,scale(normal,-1),scale(m.div(curr),-1))=={}
 assert(O/'native_actual_polynomial_calibrations.json.gz').read_bytes()==(O/'replay_actual_polynomial_calibrations.json.gz').read_bytes()
 assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)and subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md'];state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'and b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V843.md)'in live;links=[]
 for q,text in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V843.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V843.md').read_text(encoding='utf-8')),(O/'RESULT.md',(O/'RESULT.md').read_text(encoding='utf-8'))]:
  for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',text):
   if target.startswith(('http:','https:','#')):continue
   dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([q.relative_to(R).as_posix(),target])
 command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0;events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[q['exit_code']for q in events if q['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(q for q in events if q['event']=='step_finished'and q['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 files=[q for q in O.iterdir()if q.is_file()]+[R/'README.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V843.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_COMPLETE_HOMOGENEOUS_LEADING_LOCAL_BC_IMAGE_CLOSURE_MODULE',base_HEAD=head,state_sha256=state,complete_Lorentz_type_and_actual_operator_routes_match=True,delta_contractions=86,epsilon_dispositions=28,Y_coefficients=2025,quadratic_coefficients=4095,antisymmetric_rows=990,free_rank_image_and_closed_kernel=1035,quadratic_kernel_free_rank=3060,explicit_unit_pivots_splittings_no_parameter_inverses=True,unknown_BC_locality_lower_WZ_full_admissibility_and_common_normalization_NOT_established=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',checked_local_links=links,files_excluding_pending_receipt_capture={q.relative_to(R).as_posix():digest(q)for q in files},shared_action_algebra_software_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','free_rank_image_and_closed_kernel','quadratic_kernel_free_rank','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
