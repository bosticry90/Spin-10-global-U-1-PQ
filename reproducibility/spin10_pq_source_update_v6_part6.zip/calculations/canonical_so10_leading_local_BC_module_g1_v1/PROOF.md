# Complete homogeneous leading two-leg calculation

This is a local A0 leading-Qmin diagnostic on V842's checked closed gauge
shadow. It is not completeness of the full admissible correction module.
Coefficients are constant, dimension zero and in the original ring containing
Q; no background tensor, explicit coordinate, mass or cutoff power enters.
Lower-jet sectors allowed by dimensionful coefficients are outside this result.

## Type and Lorentz completeness

The minimal species B,C,JBmin,JCmin have respectively ghost numbers
0,1,-1,-2 and dimensions1,1,2,2. All30 type/target dispositions are retained.
Only BB with two derivatives and JBmin C with one derivative can enter the
declared dim4/ghost0 quadratic sector. Only BC with three derivatives enters
dim5/ghost1; only CC with four derivatives enters dim6/ghost2.

For a constant-coefficient bilinear, IBP moves every derivative to either
leg. Algebraically impose d_first=p,d_second=-p. This is a formal polynomial
IBP relation, not a numeric momentum or new Fourier convention. Enumerate
every placement and every delta perfect matching of vector/derivative
indices. The86 complete symbol contractions reduce to:

    BB: (B_s dot B_c)p² and (B_s dot p)(B_c dot p),
    JBmin C: JB_s dot p times C_c,
    BC: B_s dot p times p² C_c,
    CC: C_s p4 C_c.

All28 epsilon contractions vanish in this quotient: after IBP at least two
commuting derivatives occur in antisymmetric epsilon slots. This covers the
parity-odd invariant as well. Delta pairings plus epsilon span the stated
four-dimensional scalar contractions, without an external preferred tensor.
The BB transverse and longitudinal symbols are independent, as is the BC
symbol. This is an algebraic quotient of local bilinears, not a locality
proof for an unknown quantum kernel.

Exchange of the two even B factors and IBP make the BB color matrices
symmetric. The analogous four-derivative odd-ghost bilinear retains only an
antisymmetric color matrix. Distinct JBmin/C factors impose no color symmetry;
their ordering signs are handled by the actual source-left polynomial algebra.

## Actual Qmin map

Define

    F_Y=sum Y_sc B_s,mu partial_mu Box C_c,
    G_HKN=1/2 H_sc B_s,mu Box B_c,mu
          +1/2 K_sc divB_s divB_c +N_sc JBmin_s,mu partial_mu C_c.

H,K are symmetric, N arbitrary. All180 actual source columns are verified
against E_Maxwell=-BoxB+partial divB. With QB=partial C,QC=0,

    QG_HKN = F_(H-K) modulo ordinary divergence.

The source term contributes E_Maxwell dot partial C, a divergence by the
actual Maxwell Noether identity, for every N. It supplies no extra BC image.
Generic diagonal and both offdiagonal color orientations, both arithmetic
routes and explicit four currents test all universal polynomial coefficients;
the all-color Maxwell-template equality licenses lifting the slot identity.

For arbitrary Y,

    QF_Y = -1/2 (Y-Yt)_sc C_s Box² C_c modulo divergence.

Both the first IBP and the full ghost-antisymmetry currents are saved. The
latter follows from the actual odd order and the ordinary Green identity

    div[Ci dBoxCj-dCi BoxCj+BoxCi dCj-dBoxCi Cj]
        =Ci Box²Cj+Cj Box²Ci.

The LEFT ghost Euler coefficient is -(Y-Yt)Box²C. A lower consistency
contribution written +1/2 W_sc C_s Box²C_c, W antisymmetric, therefore
requires W=Y-Yt. W is not assigned a value or assumed zero.

## Complete symbolic splitting

There are2025 ordered Y slots,1035 symmetric slots and990 antisymmetric
slots. The full4095 quadratic columns are H1035,K1035,N2025. In the saved
sparse maps H embeds the symmetric tensor, K its negative and N is zero.
The derivative map D has rows (i<j):Y_ij-Y_ji. All990 rows of DG vanish.

All1035 H columns give explicit unit pivots for the image. All990 Y_ij
columns with i<j give explicit unit pivots for D. The full2025 splitting
Y=(Y+Yt)/2+(Y-Yt)/2 is checked with exact Fraction coefficients. Thus
image(G) has free rank1035=kernel(D); the quadratic kernel consists of
H=K and arbitrary N, free rank3060. No numerical tolerance, inverse g/xi,
or field-of-fractions assumption enters. The closed sector is exact over
the original coefficient ring containing rational1/2.

For W=0 and Y symmetric a primitive is -1/2 Y_sc divB_s divB_c. This is
the general form of V842's known JaC primitive. An arbitrary symmetric
unknown coefficient changes that primitive, not the existence verdict in
THIS ambient local leading sector. No unknown coefficient has been measured
or chosen. W nonzero, nonlocality, lower-jet sectors, and correlated higher-
order/marked/background constraints require their own evidence.

The wrong odd-ghost symmetrization has nonzero Eulers; omission of an actual
Maxwell longitudinal source term has a nonzero BC normal. Omitting the
entire source route is BLIND on the normal image because that route is
itself a divergence. Its actual operator is checked separately instead of
claiming a sensitive control that the mathematics cannot supply.
