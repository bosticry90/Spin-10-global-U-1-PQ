from pathlib import Path
from fractions import Fraction as Fr
from itertools import product,permutations
from hashlib import sha256
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/leading-local-BC-module-g1-v1-2026-11-08')
sp=importlib.util.spec_from_file_location('LBC_leading_actual_algebra',O.parent/'canonical_so10_leading_minimal_shadow_g1_v1/compute.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);J=m.J;p=m.p;A=m.A;one=m.one;zero=m.zero;plus=m.plus;scale=m.scale;load=m.load;read=m.read;digest=m.digest
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 if len(blob)>8*1024**2:
  with(C/(name+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
  raise AssertionError('COMPLETE_OVERFLOW_PRESERVED_NOTPASS')
 with(O/name).open('xb')as f:f.write(blob)
 assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def matchings(ids):
 if not ids:return[()]
 a=ids[0];return[((a,b),)+tail for b in ids[1:]for tail in matchings(tuple(i for i in ids if i not in[a,b]))]
def sym_add(P,k,v):P[k]=P.get(k,0)+v
def sym_clean(P):return{k:v for k,v in P.items()if v}
def contraction(vec,der,placement,pairs):
 out={}
 for values in product(range(4),repeat=len(pairs)):
  vals={i:v for pair,v in zip(pairs,values)for i in pair};expo=tuple(sum(vals[i]==mu for i in der)for mu in range(4));key=tuple(vals[i]for i in vec)+expo;sym_add(out,key,(-1)**sum(placement))
 return sym_clean(out)
def expected(kind,placement,mode):
 out={};sg=(-1)**sum(placement)
 if kind=='BB':
  for mu in range(4):
   for nu in range(4):
    if mode=='transverse':key=(mu,mu)+tuple(2*int(i==nu)for i in range(4))
    else:key=(mu,nu)+tuple(int(i==mu)+int(i==nu)for i in range(4))
    sym_add(out,key,sg)
 elif kind in['BC','JBC']:
  for mu in range(4):
   for nu in(range(4)if kind=='BC'else[None]):sym_add(out,(mu,)+tuple(int(i==mu)+(2*int(i==nu)if nu is not None else 0)for i in range(4)),sg)
 else:
  for mu in range(4):
   for nu in range(4):sym_add(out,tuple(2*int(i==mu)+2*int(i==nu)for i in range(4)),sg)
 return sym_clean(out)
def lorentz():
 rows=[];epsilon=[]
 for kind,vec,der in[('BB',(0,1),(2,3)),('BC',(0,),(1,2,3)),('JBC',(0,),(1,)),('CC',(),(0,1,2,3))]:
  for placement in product(range(2),repeat=len(der)):
   for pairs in matchings(tuple(range(len(vec)+len(der)))):
    mode='transverse'if kind=='BB'and(0,1)in pairs else'longitudinal';got=contraction(vec,der,placement,pairs);want=expected(kind,placement,mode);rows.append(dict(kind=kind,placement=list(placement),pairs=[list(x)for x in pairs],mode=mode,complete_symbol=[[list(k),v]for k,v in sorted(got.items())],difference=[[list(k),got.get(k,0)-want.get(k,0)]for k in sorted(set(got)|set(want))if got.get(k,0)!=want.get(k,0)]));assert got==want
   if len(vec)+len(der)==4:
    out={}
    for perm in permutations(range(4)):
     sg=(-1)**sum(perm[i]>perm[j]for i in range(4)for j in range(i+1,4));expo=tuple(sum(perm[i]==mu for i in der)for mu in range(4));sym_add(out,tuple(perm[i]for i in vec)+expo,sg*(-1)**sum(placement))
    assert not sym_clean(out);epsilon.append([kind,list(placement),[]])
 species=[('B',0),('C',553),('JBmin',3000),('JCmin',3180)];types=[];admitted={}
 for dim,gh in[(4,0),(5,1),(6,2)]:
  found=[]
  for at,(label,n)in enumerate(species):
   for lab,nn in species[at:]:
    g=p.s.ghost(m.BACK.get(n,n))+p.s.ghost(m.BACK.get(nn,nn));d=dim-J.dimension(n)-J.dimension(nn);ok=g==gh and d>=0;types.append([dim,gh,label,lab,d,g,ok])
    if ok:found.append([label,lab,d])
  admitted[str(gh)]=found
 assert admitted=={'0':[['B','B',2],['C','JBmin',1]],'1':[['B','C',3]],'2':[['C','C',4]]}
 return dict(all_derivative_delta_contractions=rows,all_epsilon_contractions_after_IBP=epsilon,IBP_convention='first-leg derivative p, second-leg -p; formal derivative symbols, no Fourier i',all30_type_dispositions=types,admitted_homogeneous_types=admitted)
def sparse_maps():
 sym=[(i,j)for i in range(45)for j in range(i,45)];anti=[(i,j)for i in range(45)for j in range(i+1,45)];Y=[(i,j)for i in range(45)for j in range(45)];idx={ij:k for k,ij in enumerate(Y)};G=[]
 for label,sg in[('H',1),('K',-1)]:
  for i,j in sym:G.append([label,i,j,[[idx[i,j],sg]]if i==j else[[idx[i,j],sg],[idx[j,i],sg]]])
 for i,j in Y:G.append(['N',i,j,[]])
 D=[[i,j,[[idx[i,j],1],[idx[j,i],-1]]]for i,j in anti];rows={k:{}for k in range(2025)}
 for col,(_,i,j,vals)in enumerate(G):
  for row,v in vals:rows[row][col]=v
 DG=[]
 for i,j,ds in D:
  z={}
  for row,v in ds:
   for col,c in rows[row].items():z[col]=z.get(col,0)+v*c
  DG.append([i,j,[[c,v]for c,v in sorted(z.items())if v]])
 assert all(not z for i,j,z in DG)
 # A second coefficient-slot construction, independent of the column assembly.
 expectedG=[]
 for label in['H','K','N']:
  for i,j in(sym if label!='N'else Y):
   vals=[[k,(1 if label=='H'else-1)]for k,(r,s)in enumerate(Y)if label!='N'and((r,s)==(i,j)or(r,s)==(j,i))];expectedG.append([label,i,j,vals])
 assert G==expectedG
 splitting=[]
 for i,j in Y:
  sy={(i,j):Fr(1,2),(j,i):Fr(1,2)}if i!=j else{(i,i):Fr(1)};an={(i,j):Fr(1,2),(j,i):Fr(-1,2)}if i!=j else{};total={k:sy.get(k,Fr(0))+an.get(k,Fr(0))for k in set(sy)|set(an)};assert m.clean(total)=={(i,j):Fr(1)};splitting.append([i,j,[[r,s,v.numerator,v.denominator]for(r,s),v in sorted(sy.items())],[[r,s,v.numerator,v.denominator]for(r,s),v in sorted(an.items())]])
 return dict(Y_order=[list(x)for x in Y],quadratic_columns=G,antisymmetric_D_rows=D,complete_D_times_G=DG,all2025_symmetric_antisymmetric_splittings=splitting,rank_image=1035,rank_D=990,quadratic_kernel_rank=3060,closed_kernel_rank=1035,pivots_G='all1035 H columns; K gives their negatives; all2025 N zero',pivots_D='Y_ij for i<j; split by1/2, no physical denominator',lower_WZ_condition='W=Y-Ytranspose; W symbolic antisymmetric, not set0')
def box(P):return plus(*(J.D(J.D(P,mu),mu)for mu in range(4)))
def divergence(c):return plus(*(p.atom(4*c+mu,(mu,))for mu in range(4)))
def F(i,j):return plus(*(J.mul(p.atom(4*i+mu),J.D(box(p.atom(553+j)),mu))for mu in range(4)))
def BB(i,j):return plus(*(J.mul(p.atom(4*i+mu),box(p.atom(4*j+mu)))for mu in range(4)))
def N(i,j):return plus(*(J.mul(p.atom(3000+4*i+mu),p.atom(553+j,(mu,)))for mu in range(4)))
def calibrations(role):
 Q,pi,inc,qm,E,hats=m.maps(role);maxwell=[]
 for n in range(180):
  c,mu=divmod(n,4);want=plus(scale(box(p.atom(n)),-1),J.D(divergence(c),mu));d=plus(E[n],scale(want,-1));maxwell.append([n,J.encode(d)]);assert not d
 rows=[]
 for i,j in[(0,0),(0,1),(1,0)]:
  forms={'H':scale(plus(BB(i,j),BB(j,i)),Fr(1,4)),'K':scale(J.mul(divergence(i),divergence(j)),Fr(1,2)),'N':N(i,j)}
  for label,G in forms.items():
   q=m.operate(G,qm,role);normal,curr=p.normal(q,set(range(180)));want=scale(plus(F(i,j),F(j,i)),Fr(1,2)if label=='H'else Fr(-1,2))if label!='N'else{};d=plus(normal,scale(want,-1));assert not d;rows.append(dict(i=i,j=j,carrier=label,complete_input=J.encode(G),complete_Q=J.encode(q),complete_B_normal=J.encode(normal),four_currents=[J.encode(z)for z in curr],complete_difference=J.encode(d)))
  f=F(i,j);q=m.operate(f,qm,role);target=scale(plus(J.mul(p.atom(553+i),box(box(p.atom(553+j)))),scale(J.mul(p.atom(553+j),box(box(p.atom(553+i)))),-1)),Fr(-1,2));d=plus(q,scale(target,-1));el=J.euler(d,set(range(553,598)));assert not el
  # Explicit QF + C_i Box² C_j = div[(C_i partial_mu Box C_j)].
  ci=p.atom(553+i);cj=p.atom(553+j);currents=[J.mul(ci,J.D(box(cj),mu))for mu in range(4)];rawtarget=scale(J.mul(ci,box(box(cj))),-1);assert plus(q,scale(rawtarget,-1),scale(m.div(currents),-1))=={}
  green=[plus(J.mul(ci,J.D(box(cj),mu)),scale(J.mul(J.D(ci,mu),box(cj)),-1),J.mul(box(ci),J.D(cj,mu)),scale(J.mul(J.D(box(ci),mu),cj),-1))for mu in range(4)];finalcurr=[plus(x,scale(y,Fr(-1,2)))for x,y in zip(currents,green)];assert plus(q,scale(target,-1),scale(m.div(finalcurr),-1))=={}
  rows.append(dict(i=i,j=j,carrier='F',complete_input=J.encode(f),complete_Q=J.encode(q),complete_antisymmetric_representative=J.encode(target),complete_raw_representative=J.encode(rawtarget),four_first_IBP_currents=[J.encode(z)for z in currents],four_full_antisymmetry_currents=[J.encode(z)for z in finalcurr],all_ghost_Euler_differences=[[n,J.encode(v)]for n,v in sorted(el.items())]))
 # Negative controls on a true offdiagonal odd-ghost Euler and actual source route.
 q=m.operate(F(0,1),qm,role);wrong=scale(plus(J.mul(p.atom(553),box(box(p.atom(554)))),J.mul(p.atom(554),box(box(p.atom(553))))),Fr(-1,2));bad=J.euler(plus(q,scale(wrong,-1)),{553,554});assert bad
 badqm={n:v for n,v in qm.items()};badqm[3000]=scale(box(p.atom(0)),-1);bad=m.operate(N(0,1),badqm,role);normal,curr=p.normal(bad,set(range(180)));assert normal
 return dict(actual180_Maxwell_differences=maxwell,all_generic_polynomial_calibrations=rows,controls=dict(wrong_ghost_symmetrization_nonzero_Eulers=[[n,J.encode(v)]for n,v in sorted(J.euler(plus(q,scale(wrong,-1)),{553,554}).items())],omitted_Maxwell_longitudinal_complete_image=J.encode(bad),omitted_Maxwell_longitudinal_B_normal=J.encode(normal),omitted_source_route_control='BLIND_ON_NORMAL_IMAGE: correct N image is a divergence; actual Maxwell template independently checked'),no_locality_or_full_counterterm_admissibility_claim=True)
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 l=lorentz();s=sparse_maps();save('complete_Lorentz_and_symbolic_module.json.gz',dict(Lorentz=l,module=s));outputs=[]
 for role in['native','replay']:z=calibrations(role);save(role+'_actual_polynomial_calibrations.json.gz',z);outputs.append(z)
 assert outputs[0]==outputs[1];out=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='COMPLETE_HOMOGENEOUS_LEADING_LOCAL_BC_IMAGE_CLOSURE_MODULE_PENDING_VALIDATION',delta_contractions=len(l['all_derivative_delta_contractions']),epsilon_dispositions=len(l['all_epsilon_contractions_after_IBP']),Y_coefficients=2025,quadratic_coefficients=4095,antisymmetric_rows=990,rank_image=1035,quadratic_kernel=3060,closed_kernel=1035,all_closed_local_Y_exact_in_declared_ambient_module=True,unknown_BC_locality_lower_WZ_and_full_common_normalization_NOT_established=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
