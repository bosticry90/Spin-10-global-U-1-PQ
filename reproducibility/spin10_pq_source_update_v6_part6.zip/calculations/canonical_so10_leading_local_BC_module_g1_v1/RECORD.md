# Complete symbolic homogeneous leading BC diagnostic

V843 prospective continuation of V842/be285423f14a0bcc5d5b8cf69efd9355fcac5013,
main,D:,goalACTIVE under live AGENTS/charter/solo/epistemic policy. Root
writes and runs one worker; two AI reviews read only. State113/34of39,
flavor pause,HB1/C5 blocks,E5/A5 open and seven custodyNOTPASS unchanged.
No adoption, new branch/worktree, protected promotion or external action.

Question: which SYMBOLIC entries of a local leading BC coefficient can
affect a homogeneous two-leg consistency/existence test? Do this before
calculating26 candidate paths. Input the actual V842 closed leading gauge
shadow and Maxwell source operator. Do not assume that an unmeasured finite
BC kernel is local or that its lower WZ companions vanish.

Domain: original Euclidean A0, finite local two-leg polynomials, ordinary
commuting jets, full four-dimensional Lorentz contractions by delta/epsilon,
constant coefficients in the original dimension-zero parameter/radical ring
containing rational1/2. No inverse physical parameter, no new tensor/vector,
explicit coordinate or dimensionful coefficient. Minimal B,C,JBmin,JCmin
types only. Declared HOMOGENEOUS sectors: BC three derivatives(dim5,gh1),
quadratic BB two and JBmin C one derivative(dim4,gh0), CC four derivatives
(dim6,gh2). Power/mass-dependent lower-jet sectors are OUTSIDE this domain,
not excluded from the quantum theory. Scalar/matter and background/marked
restrictions are outside; this is a complete ambient kinematic module for
these sectors, not the complete admissible counterterm or cohomology module.

First prove IBP/Lorentz/type completeness. Enumerate all derivative placements
and delta perfect matchings; epsilon contractions vanish after all derivatives
are moved onto one leg. Native contraction enumeration versus independent
momentum-partition identities must agree. Generic color slots lift to all45
colors, with actual all180 Maxwell columns verified against the template.

Freeze conventions F_Y=sum Y_sc B_s,mu partial_mu Box C_c and
G=1/2 H_sc B_s,mu Box B_c,mu+1/2 K_sc divB_s divB_c
  +N_sc JBmin_s,mu partial_mu C_c,
H,K symmetric and N arbitrary. Test Qmin G=F_(H-K) modulo explicit IBP,
including the source route's actual Maxwell Noether identity. Test
Qmin F_Y=-1/2(Y-Yt)_sc C_s Box² C_c modulo explicit currents/LEFT Eulers.
Lower WZ density is +1/2 W_sc C_s Box² C_c, W antisymmetric and UNKNOWN.
Thus test the exact coefficient condition W=Y-Yt, without assigning W or Y.

Construct all2025 Y columns,4095 quadratic columns and990 antisymmetric
rows over rationals, retaining original coefficients symbolically. Verify
image/closure/kernel ranks via explicit pivots/splitting identities, not a
numerical rank tolerance: image rank1035 equals closed-kernel rank1035,
quadratic kernel3060; QF antisymmetric rank990. Independent dictionary
row arithmetic and closed formulas compare the complete sparse maps.
Nonzero generic diagonal/offdiagonal polynomial calibrations, wrong ghost
exchange sign, omitted Maxwell longitudinal term and source-image control
must report sensitive/blind outcomes honestly. Do not demand sensitivity
from a mathematically redundant primitive route.

If these pass, the conclusion is that every LOCAL, homogeneous, leading,
closed BC tensor is exact in this ambient module. Its value alone then
cannot establish an obstruction in this diagnostic; antisymmetry/lower-WZ
and locality remain the decision-relevant missing data. This does not fit
unknown coefficients, adopt a correction, fix V839's composite/contact map,
qualify a full correlated quantum prescription or earn E5/A5.

One120s primary after imports,8GiB sampled/350MiB launch floor,32MiBpacket,
8MiBartifact. Freeze source copies, exact actual input/receipt hashes, old
Git tree/README before computation. Full repo/externalD: captures; complete
overflow/failure preserved NOTPASS. Final one180s worker rederives decisive
maps/currents/controls, authenticates all packets, state/history/links and
delegated E4 once(fixedcontext,outer0/components0,0,0,0,0,2/sevenNOTPASS).
Validate before local commit. Shared action, algebra/software and AI authorship
limit independence. No new loop or physical validation is supplied.
