# The exterior Feynman transition on real compact switches

Keep the actual V898 color-12 and color-17 soft constants
and the V882 ordinary source order. This increment treats
their local transition projection and the nonconstant
V883 kernel with inner transfers set to zero. The two
exterior lines are the inherited normalized Feynman
inverses. All switch functions are defined directly on
real spacetime. This calculation does not continue a
Euclidean switch or interchange a switched graph's
inner-transfer boundary with its adiabatic limit.

## Ordered phase and the transferred exterior pair

Use P(p)=p0²−|p_vec|² and d⁴p/(2 pi)^4. Strip the
common Wick phase and the loop prefactor from the
proper coefficient m. Use G_F=(P+i0)^-1 rather than
C_F=iG_F in the following sewing formula. The actual
source-first means are a=−G_F j_C and C=G_F j_a in
this stripped order, so the exterior contribution of
m a C is −m times the two simple G_F factors. Converting
both to C_F changes the displayed factor by i².
The two factors at finite transfer are distributions
in independent momenta p and p+K, with the linear
coordinate map of determinant one. No restriction to
K=0 is used in their product.

For a smooth compact momentum test f(p,K) near the
soft region, the p-integral has singular part

    J_F(K)=−i f(0,0) log(−P(K)−i0)/(16 pi²)
             + a term continuous at K=0
             + O(|K|) log(−P(K)−i0).

The assertion uses the joint distribution in p,K.
At positive imaginary part use the usual two-denominator
parameter t and translate p to ell=p+tK. The denominator
is (P(ell)+t(1−t)P(K)+i eta)^2. Split the test into
its value at ell=0 times a fixed smooth cutoff, plus a
remainder with a first-order zero there. On each
Euclidean-radius shell ell=r y, P(y) is a submersion
on the unit annulus. The one-dimensional translated
square-pole distribution has uniformly bounded test
seminorms for real shift on that annulus and eta/r²
small or large. At large shifts it is smooth there.
The test zero gives a summable O(r) bound. The same
method applied to a hard difference of squared poles
with distinct shifts gives a summable r^-2 bound on
large shells. The subtracted test remainder therefore
has a continuous p-pairing at K=0. This argument uses
distributional normal coordinates at the cone.

For the constant cutoff piece one may replace the
hard part by the difference of two unweighted squared
poles, one with a fixed positive reference mass. The
hard difference is continuous by the large-shell bound.
The unweighted difference has log coefficient −i/(16 pi²).
For a direct phase calculation, represent the squared
pole as minus the integral of t exp(i t(P+lambda+i eta)).
The Lorentzian Gaussian over the four components has
Fresnel phase exp(i pi/4−3i pi/4)=−i. The remaining
subtracted t integral is the logarithm difference.
An independent Wick evaluation of the convergent
mass-subtracted integral gives i times the Euclidean
integral with squared mass −lambda−i0. Integration
over the Feynman parameter adds only an integrable
log(t(1−t)) and the O(|K|) variation of f(−tK,K).
These give the stated soft form.

If K were set to zero on an isolated constant, the
double exterior pole would not have its unextended
boundary at the tip. For example the Gaussian test
exp(−|p|_E²) on (P+i eta)^-2 gives the large-Schwinger
term i pi² log(1/eta) before the Fourier measure.
Its exact Gaussian factor is
pi²(1−it)^-1/2(1+it)^-3/2, asymptotic to −i pi²/t².
The minus in the squared-pole Schwinger formula
gives the sign shown. This is a separate control
on dropping the independent transfer.

## Actual transition and two real switch profiles

For each color the V898 graph weights give the local
m h_R(x), where h=chi²(1−chi) and h_R(x)=h(x/R).
Here chi is real, smooth, compact in Minkowski space
and equal to one near the origin. Then h(0)=0.
In the weak limit the dilation of hhat removes the
continuous constant and the log R part of J_F. The
O(|K|) times log term vanishes by local integrability
and rapid Fourier tails. The remaining log pairing
uses the Fourier boundary

    F^-1 log(−P−i0)(x)=−i/[pi² (−x²+i0)^2]

off the origin. This follows by differentiating the
complex power (−P−i0)^−a at a=0, or by the
massless Feynman product in position. The product
away from the origin uses the same i0 boundary at
the light cone. Terms supported at the origin
in this logarithm extension drop out for a plateau.
Thus the ordered weak residue of the local
transition projection is

    m f(0,0)/(16 pi^4) <(−x²+i0)^−2,h>.

There is a direct real-spacetime check with compact
ordinary sources. Take two plateau profiles chi_1
and chi_2 equal outside a compact spacelike patch
U separated from the origin and cone. Choose the
first shoulder with values in (0,2/3) there, and
add a nonzero sufficiently small nonnegative bump
to obtain the second profile. The difference h_2−h_1
is nonnegative and nonzero on U since
d/dchi [chi²(1−chi)]=chi(2−3chi). In the pairing
with this difference the two position Feynman
kernels are smooth. If J_a and J_C are the compact
source integrals, then at x=R y in this patch
R²(G_F*j)(Ry) tends uniformly to
−i J/[4 pi² (−y²)]. The volume gives R^4,
canceling the two R^-2 factors. Together with
the ordered minus this gives precisely the
displayed residue with f(0,0)=J_a J_C. The
profile difference is strictly nonzero for
nonzero common scalar source product and m.
This proof does not involve analytic
continuation of a test.

For a further phase control, one can choose a
real compact profile radial in the Euclidean
length of the four real spacetime coordinates.
On a unit-radius shell use a=−1+i eta and
b=1+i eta for the time and spatial terms. The
angular integral of (a u0²+b |u_vec|²)^−2 is
2 pi²/(sqrt(a) b^(3/2)), obtained from the
four-dimensional Gaussian and then its
analytic boundary. It tends to −2i pi².
Equivalently the imaginary term is given by
the derivative of a delta on the two cone
sections of the sphere. The ordered residue
is −i m f(0,0)/(8 pi²) times integral h(r)dr/r.
This uses a real radial test in Minkowski
coordinates, not a rotation of the profile.

With matched source shapes the V898 combination
m_17−(2017/170)m_12 still gives
300 log(M_Sigma/M_Phi) multiplying this same
profile pairing in stripped units. For distinct
positive squared reference masses it is nonzero
at every common kappa.

## The continuous part with zero inner transfers

For the V883 nonconstant coefficient after
setting inner transfers to zero, near the
soft cone the proper function is
P[A(P)+B(P)log(−P−i0)] with analytic A,B on
a small invariant neighborhood. Multiplication
by the first outer inverse uses P G_F=1
before sewing the second. This leaves a
smooth term and a logarithm times one
simple shifted outer pole.

The latter has continuous p-pairing at K=0.
For example use the derivative at a=0 of
(−P−i0)^−a times the shifted simple inverse.
For Re a>0 combine the powers with Feynman
parameter t and exponent 1+a. At t=0
subtract the simple shifted endpoint from
the parameter integrand before continuing
in a. On a dyadic shell the resulting
power has tip margin 2−2 Re a>0 near a=0.
The endpoint difference tends to zero by a
positive power of t, using the smooth shell
bound away from r≤sqrt(t) and the margin
inside. This controls the t^(a−1) endpoint
and its derivative near zero. The argument
gives continuity also for the logarithmic
derivative. Thus there is no additional
annulus residue from that nonconstant
piece at zero inner transfer.

The calculation qualifies the causal
local transition projection and the
zero-inner-transfer nonconstant test.
For the actual independently switched
inner graphs the FMY and FFMM massless
thresholds move with the transfers.
Their joint boundary with both outer
poles on a nonzero cone patch still
requires a uniform sector estimate.
The switched exterior inverse is also
a distinct question. The routes share
the action, convention and AI authorship.
