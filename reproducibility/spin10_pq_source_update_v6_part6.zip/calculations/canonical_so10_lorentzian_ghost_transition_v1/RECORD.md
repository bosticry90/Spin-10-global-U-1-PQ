# V899 pre-execution contract

Compute the exterior Feynman weak transition from the actual
V898 two-color constants. Use real smooth compact Lorentzian
plateau switches, the V882 ordinary source order and the
V892/LIB1 phase conventions. Keep the two pole momenta
independent through the finite transfer. Require the weighted
logarithm, nonzero spacelike profile-pair test, independent
real radial angular control and retained normalization
elimination. Treat the nonconstant V883 part at zero
inner transfer. Distinguish the whole causal switching limit.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB
sampled private, 350 MiB launch commit floor, 8 MiB artifact,
32 MiB packet. Freeze proof, source and owner bytes.
Require final replay and exact staged bytes. No inverse
coupling or physical normalization choice.
