"""Exact phase and source controls for the causal transition."""

import gzip
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def read(owner, name):
    return json.loads((ROOT/"calculations"/("canonical_so10_"+owner)/name).read_bytes())


def source_order(role):
    root=ROOT/"calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1"
    with gzip.open(root/(role+"_inverse.json.gz"),"rt",encoding="utf-8") as file:
        inverse=json.load(file)
    slots={565,610,570,615}
    q=sp.symbols("q0:4")
    p2=sum(x*x for x in q)
    table={(i,j):sp.sympify(v) for i,j,v in inverse["Greference"] if i in slots and j in slots}
    assert table=={(565,610):1/p2,(610,565):-1/p2,(570,615):1/p2,(615,570):-1/p2}
    owner=read("uncut_ghost_profile_v1","result.json")["checks"]["source_profile"]
    assert owner["ghost_ordered_sign"] == -1
    return {"ordered_ghost_sign":-1,"covariance_conversion_squared":-1}


def phase(role):
    fresnel=sp.simplify(sp.exp(sp.I*sp.pi/4)*sp.exp(-3*sp.I*sp.pi/4))
    assert fresnel == -sp.I
    log_coefficient=fresnel/(16*sp.pi**2)
    assert log_coefficient == -sp.I/(16*sp.pi**2)
    if role=="native":
        angular=2*sp.pi**2/sp.sqrt(-1)
    else:
        u=sp.Symbol("u",positive=True)
        weight=sp.sqrt(1-u)/sp.sqrt(u)
        angular=sp.simplify(4*sp.pi*sp.I*sp.pi*sp.diff(weight,u).subs(u,sp.Rational(1,2))/4)
    assert angular == -2*sp.I*sp.pi**2
    a=sp.Symbol("a",positive=True)
    riesz=sp.I*sp.gamma(2-a)/(4**a*sp.pi**2*sp.gamma(a))
    log_inverse=-sp.limit(riesz/a,a,0,dir="+")
    assert log_inverse == -sp.I/sp.pi**2
    ordered=-log_coefficient*log_inverse
    assert ordered==1/(16*sp.pi**4)
    radial=sp.simplify(ordered*angular)
    assert radial == -sp.I/(8*sp.pi**2)
    return {"outer_log_coefficient":"-I/(16*pi^2)",
            "log_inverse_off_origin":"-I/pi^2",
            "radial_angular":"-2*I*pi^2",
            "ordered_spacelike_prefactor":"1/(16*pi^4)",
            "ordered_real_radial_prefactor":"-I/(8*pi^2)",
            "collapsed_tip_log_before_measure":"I*pi^2"}


def color_and_profile():
    source=read("ghost_two_color_transition_v2","result.json")["checks"]["normalization"]
    assert source["color17_minus_2017_over_170_color12"]=="300*log(M_Sigma/M_Phi)"
    h=sp.Symbol("h",positive=True)
    f=h*h*(1-h)
    assert sp.expand(sp.diff(f,h)+h*(3*h-2))==0
    return {"color_combination":source["color17_minus_2017_over_170_color12"],
            "profile_shoulder_monotone_on":"0<chi<2/3",
            "one_outer_pole_log_tip_margin":"2-2*Re(a)"}


def checks(role):
    return {"source":source_order(role),"phase":phase(role),"profile":color_and_profile()}


if __name__=="__main__":
    run_worker(checks,sys.argv[1])
