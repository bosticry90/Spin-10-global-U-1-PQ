# Lorentzian exterior ghost transition V899

The weighted exterior Feynman pair in the inherited stripped convention has
a joint soft logarithm with coefficient `-i f(0,0)/(16 pi^2)`. The ordered
ordinary-source ghost sign is minus. For a pair of real compact plateau
switches differing by a spacelike shoulder bump, the constant inner
coefficient therefore gives the smooth profile pairing with prefactor
`+m f(0,0)/(16 pi^4)` and kernel `(-x^2+i0)^(-2)`. The profile variation of
`h=chi^2(1-chi)` on that patch is strictly positive. The phase was checked
by an independent real-coordinate angular boundary calculation, and the
ordinary covariance conversion was retained.

For distinct positive squared reference masses the actual two-color
combination is `m_17-(2017/170)m_12=300 log(M_Sigma/M_Phi)`. It retains this
nonzero constant exterior profile contribution independently of the common
reference normalization. The inherited nonconstant form factor is
continuous under the exterior transfer when the inner transfers are set to
zero. The exact phase, color and local profile controls are in the machine
record. The distribution estimates and separation of limits are in the proof.

This qualifies the constant inner term and the zero-inner-transfer control.
The independently switched massive and massless thresholds against both
exterior poles, the fully switched Lorentzian inverse, and the complete
causal weak limit remain open. No absolute causal obstruction or accepted
normalization follows from this packet. The two calculations share the
action, source chart, and symbolic infrastructure.
