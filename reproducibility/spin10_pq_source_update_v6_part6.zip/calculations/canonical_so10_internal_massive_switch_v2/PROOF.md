# Full internal massive scalar switch sum

Use the V908 selected connected g^4 two-explicit-xi ghost group
in both V898 colors. In each proper cycle and the kinetic
one-port cycle there is one original positive-mass scalar
edge. Sum all quadratic switches on that edge, retaining bare
internal ghost, mixed and auxiliary gauge edges. The exterior
ghosts and massive feedback bridge remain exact as in V907
and V908. Keep the actual derivative-switch path at color 17,
the original UV forest and the common sequential Feynman
boundary. Use Schwartz ordinary sources in the small compact
momentum domain of V907 and the same broad profile pair.
The mass M in each block denotes positive mass squared.

## Each fixed positive scalar count

Every massive scalar switch is V_R=Box sigma_R/2, with
physical scale lambda², lambda=1/R. At count n keep all
independent transfers. The n+1 massive propagators with
momentum shifts K_j and common Feynman sign can first be
combined on their own simplex beta. Let

    Kbar=sum beta_j K_j,
    M_beta=M−sum_(i<j) beta_i beta_j P(K_i−K_j).

Their product equals the simplex integral of
partial_(M_beta)^n [P(q+Kbar)−M_beta+i0]^-1.
The usual n! simplex factor is exactly the mass derivative
factor. The Born factor (−V_R)^n remains. For each fixed n,
on small physical transfers M_beta stays in [M/2,3M/2].
Large transfer bands use the original tempered finite graph
and rapid compact-switch Fourier tails, not an assumed
uniform positive M_beta. In particular the reduction does
not assert positivity uniformly over all cumulative counts.

For the proper loops this is the V904 core with one massive
parameter t and the same massless groups. Finite mass
derivatives preserve its bounds. In the radial integrals
a derivative in M gives a factor t, and raises the inverse
power of Delta by one. The n derivatives therefore give
t^n. Integrate by parts n times using partial_t Delta,
whose real part is uniformly bounded below by a positive
multiple of M on the small-transfer region. Each
integration reduces the excess inverse power by one.
The t=0 boundary in these n reductions vanishes because a
positive power of t remains before differentiation at that
stage. The t=1 boundary is regular. For the logarithmic
radial term the last integration returns to a logarithm.
The resulting bulk radial powers are at most the original
powers used in V904. Their coefficients and fixed
derivatives are uniformly smooth in beta and M_beta.
For the original second-inverse FFMM term, the remaining
t=0 face reduction retains its actual N0 numerator
quadratic in the independent mixed-line transfer. The
mass differentiation creates no inverse power of that
numerator. The common-sign shell and tip estimates
therefore still apply to each fixed differentiated word
after subtracting its own actual zero-transfer constant.
Extra polynomial powers from t derivatives have no
adverse soft degree.

Equivalently, the mass dependence of the remainder is
handled in the same shell proof with the differentiated
coefficients, rather than continuing M across a cut.
The beta average preserves the constants for fixed n.
Any UV difference between a derivative of an already
converted kernel and the original n-insertion conversion
is local and carries the physical V_R factors. In the
proper paths the positive scalar counts are UV convergent.
In the kinetic one-port with the internal derivative,
the first scalar switch still requires its inherited
logarithmic subtraction. At n>=2 it is UV convergent.
If the derivative is on the rooted scalar port instead,
move it to the source as in V908. Keep the whole original
regulated forest and the actual local terms in that
one-port subtraction. The raw clock cannot be replaced
by a derivative of the bare clock. For example the
radial zero-transfer clock diagnostic gives the finite
difference −log(3/2)/(16 pi²) between clocks six and
four on the same logarithmic symbol. With the common
radial measure stripped it is the Frullani integral of
(exp(−6u)−exp(−4u))/u on the positive half-line. This diagnostic
does not choose a new finite part.

For the one-port the massless–massive parameter has
Delta=t[M_beta−(1−t)P(k)] with small switch-only k.
The positive bracket is separated from threshold.
The t factors of finite mass derivatives leave only
integrable polynomial and t-log terms at t=0.
Thus the normalized source for the bridge is
lambda^(2n)(f_0+O_C^k(lambda)) on a fixed compact
rescaled set. Its leading coefficient has the factor
V^n, supported away from the origin. This statement
also covers the original first-switch local
subtraction. The converted one-edge Y ghost tadpole
has no such massive line and is unchanged.

The exact-exterior comparison for a fixed n now uses
V907's finite asymmetric peeling, with orders chosen
after n, and the corresponding V904 tip and shell
bounds for the differentiated remainder. The massive
insertions supply the positive factor lambda^(2n),
also on the near-shell transfers. A local collapsed
proper coefficient is lambda^(2n) times ordinary
switches times V^n, which pairs with a bounded
V902 product away from the origin. The small variation
of M_beta from M is part of the subtracted remainder.
For the one-port use V908's exact bridge expansion.
The leading source factor V^n gives the same bounded
away-origin pairing, and the O(lambda^(2n+1)) or higher
terms beat the crude O(lambda^-2) two-root cost.
Thus every fixed positive scalar count vanishes.
This does not justify summing the counts by itself.

## A large-mass estimate on a compact time slab

After rescaling the massive edge has mass
m=sqrt(M)/lambda and fixed potential V=Box chi/2.
At positive absorption its temporal kernel, as an
operator on spatial L², is

    −i exp(−i E_eta |t−t'|)/(2 E_eta),
    E_eta=sqrt(|D_space|²+m²−i eta_scaled),

with the root of positive real part and nonpositive
imaginary part. Its norm is at most 1/(2m) at every
time separation. On one fixed time slab containing
all switch and endpoint cutoffs, Schur gives
||G_m||_(L²→L²)<=C/m, uniformly in m and absorption.
One time derivative cancels E_eta^-1 and one spatial
derivative has multiplier norm at most one in the
ratio |D_space|/|E_eta|. The first time derivative
has no delta from the absolute-time kernel.
Consequently the localized map gains one ordinary
spacetime Sobolev derivative uniformly in m.
Higher input derivatives commute with the free
inverse; derivatives on the fixed cutoffs and V are
bounded independently of m. Norm convergence on
these fixed slabs for each finite m follows from the
same Fourier kernel, or from strong convergence and
uniform derivative bounds.

The exact restricted massive inverse follows from
the slab Neumann equation since ||G_m V||<=C/m.
It agrees with V905 on compact smooth data, because
the V905 solution equals the same free inverse of
a compact effective source and hence obeys the
slab equation. These are time-local estimates.
They do not claim a 1/m bound for each separate
temporal Helmholtz fibre near the scaled mass shell.

For any fixed integers L and K, peel L factors at
both endpoints and K additional factors in the
middle. The exact remainder after counts below
2L+K is

    (−G_m V)^L [(−G_m V)^K G_(m,V)] (−V G_m)^L.

This identity follows from both resolvent identities
and holds first with positive absorption. The middle
has localized L² norm O(m^(-K−1)), while each wing
gains L derivatives with constants independent of m.
The right wing is the transpose counterpart for
kernel estimates. With L sufficiently large, point
evaluation and its derivatives on fixed compact
endpoints are bounded by the Sobolev embedding of
the wing range. Thus the cutoff remainder kernel
H_m on the two rescaled endpoints has

    ||H_m||_(C^k) <= C_(k,K) m^(-K−1)

for any chosen finite k. The Neumann tail is
absolutely convergent in these finitely many
seminorms after the wings. This holds also at
the sequential boundary. One way to see the
boundary in the kernel is to use norm convergence
of the fixed-mass wings on the slabs in the
derivative gains, followed by their evaluation
bounds. The fixed endpoints and absorption
limits are kept before sending R to infinity.
The physical kernel is lambda² H_m(lambda x,lambda y).

## Sewing the exact high-count tail

Removing the massive edge opens the single loop.
The remaining bare mixed and ghost lines are
tree distributions in independent relative
coordinates, with their inherited Feynman
signs. In rescaled coordinates all ordinary
vertex supports and the tail endpoint cutoffs
are fixed compact sets. The resulting tree
distribution has finite order independent of
L and K. Its cutoff test is smooth in the tail
kernel and in the exact exterior roots for each
finite R. Every fixed derivative of the exterior
roots on these sets has at most polynomial
growth in 1/lambda. In fact their rescaled
weighted L² norms and each fixed derivative
are controlled from V901 by the corresponding
scaled ordinary source norms. Differentiating
the exact equation produces only compact
lower-derivative sources from V, as in V908.
The scaled source derivative norms grow as
R^(1+derivative order). Local Sobolev embedding
gives the required polynomial C^k bound.
There is no assumption of a uniformly smooth
point-source limit at the origin.

For each graph first choose k for this fixed
tree distribution, then L for the smooth wings,
then K large enough that m^(-K−1) beats the
volume, homogeneity and exterior losses.
The remaining vertex measures and physical
derivatives contribute fixed powers of lambda,
independent of K. The exact tail therefore
vanishes. In the kinetic one-port the same
tree estimate, with its root left open, gives
arbitrarily high positive powers in each fixed
compact source C^k norm. Relative coordinates
can be chosen from the rooted vertex so that
root derivatives act on the smooth test factors.
The exact massive bridge and exterior roots
then preserve its vanishing by V908 and the
weighted root bound.

For high counts the wing kernel convergence
also identifies the tail with the sum of
the separately converted graph terms. The
finite low counts retain their original
normalizations. Beyond the peeling depth
the smooth kernel is paired with an open
tree, so no new loop coincidence extension
has been made. This avoids a uniform
finite-count transfer estimate across the
whole cumulative massive shell.

The scalar-internal switch sum contributes
zero to the selected causal difference with
bare internal ghost and gauge lines, exact
exterior roots, and the exact feedback
bridge. The V908 profile difference survives
this sum. Simultaneous internal scalar and
ghost switching and all internally switched
mixed and auxiliary gauge products require
their own joint estimates.
