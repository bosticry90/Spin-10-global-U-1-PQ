# Exact causal internal massive switch sum V910

Every quadratic switch on the original positive-mass scalar edge
inside the selected proper and kinetic one-port loops is controlled,
with bare internal ghost and gauge lines. At each fixed positive
count, independent transfers combine into a mass simplex and the
mass derivatives preserve the soft bounds. The one-port subtraction
retains its original UV forest and the actual heat clock.

On the rescaled compact time slab the massive Feynman inverse has
an inverse-mass factor. Peeling at both ends and in the middle makes
the exact high-count tail smooth and small. Removing that edge
leaves a tree distribution, so the tail can be sewn and bounded
without a uniform finite-count assumption about cumulative
transfers through the massive shell.

The whole internal massive correction vanishes. The V908 causal
profile difference survives, with the exact exterior ghosts and
massive bridge. Simultaneous internal ghost and scalar switching
and internally switched mixed and auxiliary gauge products remain
open. V1 stopped at an exact logarithm equality in structural
form. V2 simplifies the difference, retaining the proof and
conditions. The failed packet remains preserved.
