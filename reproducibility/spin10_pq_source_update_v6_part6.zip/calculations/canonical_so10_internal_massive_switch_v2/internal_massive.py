"""Exact mass-simplex, UV-clock and high-mass tail controls for V910."""

import json
import sys
import sympy as sp

from execute import ROOT, run_worker


def mass_route(phase):
    a,b = sp.symbols("a b")
    betas=[a,b,1-a-b]
    points=[sp.Matrix(sp.symbols(f"k{j}t k{j}x")) for j in range(3)]
    metric=sp.diag(1,-1)

    def P(z):
        return (z.T*metric*z)[0]

    center=sum((x*y for x,y in zip(betas,points)),sp.zeros(2,1))
    variance=sum(betas[i]*betas[j]*P(points[i]-points[j])
                 for i in range(3) for j in range(i+1,3))
    if phase=="native":
        difference=sum(x*P(y) for x,y in zip(betas,points))-P(center)-variance
    else:
        q=sp.Matrix(sp.symbols("qt qx"))
        difference=sum(x*P(q+y) for x,y in zip(betas,points))-P(q+center)-variance
    assert sp.expand(difference)==0

    M,z,t=sp.symbols("M z t",positive=True)
    for n in range(1,5):
        actual=sp.diff(1/(z-M),M,n)
        assert sp.simplify(actual-sp.factorial(n)/(z-M)**(n+1))==0
        assert sp.simplify(sp.diff(1/(z+t*M)**2,M,n) - (
            (-1)**n*sp.factorial(n+1)*t**n/(z+t*M)**(n+2)
        ))==0
        for j in range(n):
            assert sp.diff(t**n,t,j).subs(t,0)==0
    assert M-(2*sp.sqrt(M))**2/4==0
    return {"shifted_mass":"M-pair_variance",
            "mass_derivative_pays_simplex_factor":True,
            "premature_t0_faces":"zero until original radial degree",
            "unbounded_cumulative_transfer_control":"M_beta can reach zero"}


def clock_and_tail(phase):
    c,u=sp.symbols("c u",positive=True)
    if phase=="native":
        assert sp.integrate(sp.exp(-c*u),(u,0,sp.oo))==1/c
        clock=-sp.integrate(1/c,(c,4,6))
    else:
        clock=-(sp.log(c).subs(c,6)-sp.log(c).subs(c,4))
    assert sp.simplify(clock+sp.log(sp.Rational(3,2)))==0
    l,M=sp.symbols("lambda M",positive=True)
    n,k=sp.symbols("n K",integer=True,nonnegative=True)
    assert sp.simplify(l**2*(sp.sqrt(M)/l)**(-k-1)-l**(k+3)*M**(-(k+1)/2))==0
    assert sp.expand(2*n+1-2).subs(n,1)==1
    return {"raw_clock_change":"-log(3/2)/(16*pi**2)",
            "compact_slab_line_norm":"O(1/m)",
            "middle_norm_after_K_factors":"O(m**(-K-1))",
            "physical_smooth_tail_power":"lambda**(K+3)",
            "one_port_worst_residual_margin":1}


def check(phase):
    d=ROOT/"calculations"
    prior=json.loads((d/"canonical_so10_switched_massive_bridge_v1/result.json").read_bytes())["checks"]
    assert prior["reference_combination"]=="300*log(M_Sigma/M_Phi)"
    assert prior["bridge"]["fixed_derivative_remainder"]=="O(lambda**4)"
    return {"mass":mass_route(phase),"tail":clock_and_tail(phase),
            "reference_combination":prior["reference_combination"]}


if __name__=="__main__":
    run_worker(check,sys.argv[1])
