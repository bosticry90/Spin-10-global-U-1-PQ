# V910 logarithm equality correction

The first worker reached the clock diagnostic but left
-log(6)+log(2)+log(3) in structural form after expansion.
V2 simplifies the difference of the original two expressions
and still requires exact zero. The proof, contract and
negative controls are unchanged. Failed V1 sources, capture
and hash inventory remain in preserved_active_v1 under the
V1 D control directory.
