"""Check the light-output color span of the ordinary and ghost-source contacts."""

from collections import defaultdict
import importlib.util
from itertools import product
import sys

import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)
seagull = source.seagull
clean = source.owner.clean
H, M = range(12), range(12, 45)


def check(phase):
    _, _, _, f, _, _ = source.owner.inputs(phase)
    folder = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    light, broken, quartic, JC = {}, {}, defaultdict(list), {}
    for g, word, cells in rows:
        ids = [i for i, _ in word]
        jets = [d for _, d in word]
        if g == 1 and len(ids) == 3 and ids[0] < 180 and ids[0] % 4 == 1 and 565 <= ids[1] < 598:
            if 598 <= ids[2] < 643 and jets == [[], [], [1]]:
                a, b, c = ids[2]-598, ids[0]//4, ids[1]-553
                target = light if a in H else broken
                target[a, b, c] = seagull.unpack([([0, *p], n, d) for p, n, d in cells])
        if g == 2 and len(ids) == 4 and ids[1] < 180 and ids[0] % 4 == ids[1] % 4 == 1 and 565 <= ids[2] < 598 and 610 <= ids[3] < 643:
            assert jets == [[], [], [], []]
            b, d, c, k = ids[0]//4, ids[1]//4, ids[2]-553, ids[3]-598
            z = seagull.unpack([([0, *p], n, d) for p, n, d in cells])
            quartic[b, k].append((d, c, z*(1+int(b == d))))
            if b != d:
                quartic[d, k].append((b, c, z))
        if g == 1 and len(ids) == 3 and 565 <= ids[0] < ids[1] < 598 and 1196 <= ids[2] < 1208:
            assert jets == [[], [], []]
            h, i, j = ids[2]-1196, ids[0]-553, ids[1]-553
            JC[h, i, j] = seagull.unpack([([0, *p], n, d) for p, n, d in cells])

    def compare_sign(actual, expected):
        assert set(actual) == set(expected) and expected
        first = next(iter(expected))
        ratio = sp.cancel(actual[first]/expected[first])
        assert ratio in (1, -1)
        assert actual == {key: ratio*z for key, z in expected.items()}
        return int(ratio)

    ghost_bracket = {(h, i, j): z for (i, j), values in f.items()
                     if i in M and j in M for h, z in values if h in H}
    sign_JC = compare_sign(JC, {key: z for key, z in ghost_bracket.items() if key[1] < key[2]})
    sign_F = compare_sign(broken, {(a, b, c): z for (b, c), values in f.items()
                                    if c in M for a, z in values if a in M})
    D = defaultdict(lambda: sp.S.Zero)
    for (h, u, k), z in light.items():
        if u in M:
            for b, c, value in quartic[u, k]:
                if b in M:
                    D[h, b, c] += z*value
    D = clean(D)
    assert len(D) == 528 and D[1, 30, 23] == sp.Rational(1, 10)

    ports = defaultdict(list)
    for (a, b, c), z in broken.items():
        ports[b, a].append((c, z))
    contributions = []
    for internal in (H, M):
        W = defaultdict(lambda: sp.S.Zero)
        for k in internal:
            for (h, i, j), z in ghost_bracket.items():
                for (b, left), (c, right) in product(ports[k, i], ports[k, j]):
                    W[h, b, c] += z*left*right
        contributions.append(clean(W))
    WH, WM = contributions
    assert (len(WH), len(WM)) == (528, 526)
    selected = (1, 30, 23)
    assert (WH[selected], WM[selected]) == (-sp.Rational(1, 10), sp.Rational(1, 10))
    keys = D.keys() | WH.keys() | WM.keys()
    assert all(sp.expand(D.get(key, 0)+3*WH.get(key, 0)+2*WM.get(key, 0)) == 0 for key in keys)
    for tensor in (D, WH, WM):
        assert all(sp.expand(z+tensor.get((h, c, b), 0)) == 0 for (h, b, c), z in tensor.items())
    pivot = next(key for key in sorted(keys)
                 if sp.expand(WH[selected]*WM.get(key, 0)-WM[selected]*WH.get(key, 0)))
    matrix = sp.Matrix([[WH[selected], WM[selected]], [WH.get(pivot, 0), WM.get(pivot, 0)]])
    weights = matrix.inv()*sp.Matrix([D[selected], D.get(pivot, 0)])
    assert weights == sp.Matrix([-3, -2])
    assert not f[30, 23]
    return {"ordered_color_positions": len(H)*len(M)**2,
            "nonzero": {"D": len(D), "W_H": len(WH), "W_M": len(WM)},
            "literal_signs": {"J_C": sign_JC, "F": sign_F},
            "rank_pivot": [list(selected), list(pivot)],
            "rank_determinant": str(sp.expand(matrix.det())),
            "fixed_L_weights_in_stripped_basis": [int(z) for z in weights],
            "commuting_target": str(D[selected])}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
