# The light-output gauge and ghost source color span

The V936 graph direction links an ordinary derivative
ghost coefficient to the light gauge source. Write D
for its stripped current-order color tensor on HMM.
The lower linear gauge driver is fixed in this
comparison. With q_0 B=partial C and the sign convention
delta q_C=-W(C,C)/2, the projected off-shell gauge
square gives D(b,c)-W(b,c) on the independent
(partial C=b,C=c) jets. Coupling powers and common
phases are suppressed. If lower gauge normalization
also changes, its separate commutator terms enter
this equation. The tensor D below uses the current
orientation before the left derivative. The overall
factor converting D to a signed driver multiplies
the required W in the same source equation.

A literal g1 J_C^H C_M C_M vertex supplies two ghost
ports. Use two g1 B C_M partial a_M vertices with the
two ghosts external and contract their antighosts to
the source vertex. The remaining B ports contract
with each other. The light and broken B internal
sectors give two candidate directions. With the
common Grassmann, chart and kernel factors outside
the color tensors, these are

    W_S[h,b,c] =
        sum_(k in S,i,j in M) f_(h i j) f_(i k b) f_(j k c),
    S=H or M.

The executable verifies both literal vertex signs
against the joined bracket and reconstructs D from
the actual cubic and quartic tables. It compares
all 13,068 ordered HMM positions. In the stripped
basis the result is

    D = -3 W_H - 2 W_M.

At (h,b,c)=(1,30,23) the original bracket is zero
and the three tensors are 1/10,-1/10,1/10. This
single witness would allow equal H/M weights to hide
the ghost-source direction. The full comparison has
rank two, with an exact independent pivot. Independent
coefficients at the level of the two color tensors
can therefore reproduce the whole HMM target.

The triangle has short-distance degree eight in
eight relative dimensions when the two internal
ghost derivatives are retained. This allows a local
extension by power counting. It does not certify
two independent coefficients in the common causal
scheme. The allowed Lorentz extension, action Ward
identity, gauge and scalar source companions and
the full right-hand sides still require comparison.
In particular, if the scalar driver is fixed up to
linear conjugation, a nonzero W on the commuting
pair cannot by itself preserve the faithful scalar
representation. Other scalar normalizations or
quantum source inputs need their own equation.
Both routes share the same model, conventions,
symbolic software and AI authorship.
