# V937 result — light ghost-source contact color span

Two literal ghost-source triangle directions span the
V936 light-output broken-input color tensor. In stripped
current order, D=-3 W_H-2 W_M across all 13,068 ordered
positions, including zeros. An exact rank-two pivot
distinguishes the two directions. Native and replay
verify the signs of the contributing literal vertices.

On the selected commuting pair the original bracket is
zero while D is 1/10. The two ghost-source colors are
-1/10 and +1/10 there. Thus the required light ghost
bracket is in the candidate color span at fixed lower
linear gauge normalization. The nonzero D alone would
fail the projected gauge-square equation.

This comparison does not authorize two independent
finite weights in a common causal prescription. Their
operator extensions, scalar-driver response, ghost
Jacobi, gauge kinetic variation, and other companions
remain separate tests. The quantum source right-hand
sides are not assigned zero. Both routes share the
model, symbolic software and AI authorship.

Next test the common source deformation with the
transverse Maxwell form, ghost Jacobi and faithful
scalar representation. Those tests can decide whether
this color-level fit survives a full set of necessary
local equations before further loop evaluation.
