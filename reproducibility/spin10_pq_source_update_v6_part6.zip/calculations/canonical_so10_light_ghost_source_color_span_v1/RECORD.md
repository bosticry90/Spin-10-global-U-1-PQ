# V937 pre-execution contract

Compare the full light-output broken-input color tensor of
V936 with two literal ghost-source triangle directions.
Freeze the V879 action, current order, unprobed A=0 domain,
all ordered HMM color positions and the spatial index 1.
Keep the independent common factors of the two projected
triangle kernels symbolic. Work at fixed lower linear
gauge driver for this comparison.

Check the ordered ghost-source vertex against the joined
bracket, the differentiated ghost vertex against the
signed current and both internal H/M color contractions.
Require agreement in the full ordered coefficient domain,
a rank witness and native/replay equality. The claim is
a color span, with common contact admissibility separate.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.
No authority change.
