from pathlib import Path
from hashlib import sha256
import importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('cross_known_images',O/'images.py');im=importlib.util.module_from_spec(sp);sp.loader.exec_module(im)
sp=importlib.util.spec_from_file_location('cross_existing_census',O.parent/'canonical_so10_g1_consistency_companion_carriers_v1/census.py');c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c)
J=im.J;w=im.w;read=im.read;load=im.load;digest=im.digest
assert c.J is J

def maps(packet):
 states={k:dict(v) for k,v in packet['states'].items()};out={};sigs={}
 for pr in [0,1]:
  rows=[];sig=set()
  for n in range(1286):
   if n<643:raw=J.decode(states['Fu1_'+str(pr)][n])
   else:
    nn=n-643;raw=w.scale(J.decode(states['Eu1_'+str(pr)][nn]),J.constant((-1)**J.parity(nn)))
   assert all(k[0]==1 for cc in raw.values() for k,v in cc.terms)
   raw=im.m.v.grade(raw,1,strip=True);keep={};bad=[]
   for at,(ww,cc) in enumerate(sorted(raw.items())):
    cnt=[0]*10;der=0
    for nn,js in ww:cnt[c.species(nn)]+=1;der+=len(js)
    if any(cnt[i]>c.target[i] for i in range(10)):bad.append(at);continue
    keep[ww]=cc;sig.add((c.species(n),tuple(cnt),der))
   rows.append(dict(port=n,raw=J.encode(raw),selected=J.encode(keep),rejected_raw_indices=bad))
  out['Qu1_'+str(pr)]=rows;sigs['Qu1_'+str(pr)]=sig
 return out,sigs

def main():
 tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'cross_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 old=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1'
 raw,sigs=maps(load(old/'native_inputs.json.gz'));replay,rs=maps(load(old/'replay_inputs.json.gz'));assert raw==replay and sigs==rs
 found={};reject={};summary={}
 for label,sig in sigs.items():
  classes,bad=c.direct(sig);assert set(classes)==c.inverse(sig)
  found[label]=list(classes.values());reject[label]=bad
  summary[label]=dict(patterns=len(classes),raw_Lorentz=sum(len(v['Lorentz']['basis']) for v in classes.values()),after_IBP=sum(v['Lorentz']['quotient'] for v in classes.values()),intrinsic1_patterns=sum(v['intrinsic']==1 for v in classes.values()))
 a=im.save('cross_census_tables.json.gz',dict(schema='ACTUAL_QU1_LAMBDA_CC_PREIMAGE_CENSUS_V1',all1286_port_maps_per_probe=raw,actual_map_signatures={label:[[i,list(ct),j] for i,ct,j in sorted(sig)] for label,sig in sigs.items()},preimages=found,odd_Lorentz_rejections=reject,summary=summary,no_physical_u_action=True,no_quantum_coefficient_assigned=True))
 result=dict(schema='ACTUAL_QU1_PREIMAGE_CENSUS_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',summary=summary,artifact=a,all2572_ports_before_projection=True,native_replay_full_and_projected_maps_equal=True,direct_inverse_preimages_equal=True,no_quantum_coefficient_assigned=True,no_global_consistency_claim=True,elapsed_after_imports=time.perf_counter()-tick)
 im.dump(O/'cross_census_result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
