from pathlib import Path
from hashlib import sha256
import ast,importlib.util,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/known-consistency-images-g1-v1-2026-11-07')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
assert not (O/'preparation.json').exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='ceee357bf56a30aa3c5a5966c8f4ab12ae06776a'
names=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V806.md']
for folder,files in [('canonical_so10_proper_normalization_transfer_g1_v1',['proper_reference.json.gz','validation_receipt.json','PROOF.md']),('canonical_so10_JaC_companion_g1_recovery_v1',['proper_reference.json.gz','validation_receipt.json','PROOF.md','late_tensor_result.json']),('canonical_so10_unmarked_g0_common_kinetic_recovery_v1',['derivation_tables_v2.json.gz','validation_receipt.json','PROOF.md']),('canonical_so10_proper_slavnov_actual_operators_g1_v1',['native_inputs.json.gz','replay_inputs.json.gz','validation_receipt.json','factory.py']),('canonical_so10_same_parent_slavnov_g1_recovery_v1',['validation_receipt.json']),('canonical_so10_g1_consistency_companion_carriers_v1',['validation_receipt.json','PROOF.md','census_tables.json.gz'])]:names+=['calculations/'+folder+'/'+n for n in files]
for n in ['RECORD.md','images.py','run.py']:
 if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
sp=importlib.util.spec_from_file_location('known_images_preflight',O/'images.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
for mod in list(sys.modules.values())+[m.m,m.m.v,m.w,m.J,m.A]:
 p=getattr(mod,'__file__',None)
 if p:
  pp=Path(p).resolve()
  if pp.is_relative_to(R) and pp!=O/'images.py':names.append(pp.relative_to(R).as_posix())
for n in sorted(set(names)):assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
dump(O/'preparation.json',dict(base_HEAD=head,sha256={**{n:digest(R/n) for n in sorted(set(names))},**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
C.mkdir(parents=True,exist_ok=False)
with (C/'old_git_tree.txt').open('xb') as h:h.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'images.py')]);dump(O/'images_capture.json',cap);dump(C/'images_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
