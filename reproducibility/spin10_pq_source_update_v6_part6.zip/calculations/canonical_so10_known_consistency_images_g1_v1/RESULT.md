# Known portions are checked; the missing quantum companions remain

The measured M contributions to Lambda-C-C have nonzero rational and
log(9/8) functional normals. Prefix odd variation and LEFT-jet gradients
agree on every full image. Four explicit divergence currents reconstruct
each density, with direct Lambda-Euler checks. The Ja-C pure-ghost piece
cancels exactly; the remaining Ja-C and lower g0 terms each change the
rational consistency contribution. No missing term is fitted or setzero.

A follow-on intrinsic-aware support proof excludes Q_u1 Delta_g0 in this
A0/intrinsic01 target. The only possible M replacement is Jx -> Lambda
at operator intrinsic1: its two candidate preimages fail respectively
Lorentz scalar typing or the total intrinsic01 bound. This does not imply
other cross terms vanish. The initial census failed because it ignored
operator intrinsic degree; its full evidence remains NOTPASS. The corrected
census preserves the original physical types/action/domain.

This is progress on common-normalization prerequisites, not completion of
the consistency equation, an inconsistency finding, or E5/A5 promotion.
The next indispensable quantum inputs are the aCC/JBCC/JLambdaCC g1-u
companions and the unprobed g1 companions reached by Q_u0. Reproject actual
full raw vertices for each new mean budget; neither old Ja nor vector
returning catalogs exclude those additional source/antighost ports.

See PROOF.md and images_result.json for exact claims, full polynomials,
controls, failure accounting, shared-error limits and resources. Full goal
remains ACTIVE; state113/34of39/E5/A5open unchanged, no adoption or remote
action. Two pre-worker preparation failures and one failed cross census
are preserved alongside successful bounded work, not counted as PASS.
