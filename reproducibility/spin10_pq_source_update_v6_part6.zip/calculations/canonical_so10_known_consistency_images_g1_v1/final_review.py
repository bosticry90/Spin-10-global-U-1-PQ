from pathlib import Path
from hashlib import sha256
import importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/known-consistency-images-g1-v1-2026-11-07')
sp=importlib.util.spec_from_file_location('known_images_final',O/'images.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
sp=importlib.util.spec_from_file_location('cross_v2_final',O/'cross_census_v2.py');cv=importlib.util.module_from_spec(sp);sp.loader.exec_module(cv)
J=m.J;w=m.w;read=m.read;load=m.load;digest=m.digest;dump=m.dump

def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in ['preparation.json','cross_preparation.json','cross_diagnostic_preparation.json','cross_v2_preparation.json','final_preparation.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 seconds={};caps={}
 for cf,rf,bound in [('images_capture.json','images_result.json',180),('cross_diagnostic_capture.json','cross_diagnostic_result.json',60),('cross_census_v2_capture.json','cross_census_v2_result.json',60)]:
  cap=read(O/cf);res=read(O/rf);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and res['execution_state']=='COMPLETED' and res['elapsed_after_imports']<bound
  assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and all(0<s['private_bytes']<=8*1024**3 for s in cap['all_resource_samples']);seconds[cf]=res['elapsed_after_imports'];caps[cf]=cap
 failed=read(O/'cross_census_capture.json');assert failed['exit_code']==1 and not failed['calculation_completed'] and failed['post_run_observations_qualified'] and 'assert all(jets+z[2]==2-intrinsic' in failed['stdout_and_stderr']
 assert failed['launch']['memory']['available_pagefile']>=350*1024**2 and max(s['seconds'] for s in failed['all_resource_samples'])<60 and all(0<s['private_bytes']<=8*1024**3 for s in failed['all_resource_samples'])
 for name in ['failed_preparation_observation.json','failed_preparation_observation_v2.json']:
  f=read(O/name);assert f['classification']=='FAILED_PREPARATION_BEFORE_WORKER' and not f['monitored_capture'] and f['exit_code']==1
 result=read(O/'images_result.json');operands=m.build_operands();flow=load(O/'actual_derivative_maps.json.gz');q0={n:J.decode(p) for n,p in flow['Q0_fields_and_required_Ja']};q1={n:J.decode(p) for n,p in flow['Q1_all_fields_g1_polynomial_coefficient']}
 states={k:dict(rows) for k,rows in load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/native_inputs.json.gz')['states'].items()}
 assert all(q0[n]==J.decode(states['F0'][n]) for n in range(643))
 assert all(q0[1241+r]==w.scale(J.decode(states['E0'][598+r]),J.constant(-1)) for r in range(45))
 assert all(q1[n]==m.m.v.grade(J.decode(states['F1'][n]),1,True) for n in range(643))
 for a in result['artifacts']:assert digest(O/a['file'])==a['sha256']
 selected={};normal={}
 for row in result['rows']:
  key=row['probe'],row['operand'],row['carrier'];z=load(O/row['artifact']['file']);P=J.decode(z['coordinate_operand']);assert P==operands[key]
  full=J.decode(z['full_odd_prefix_image']);assert full==J.decode(z['full_LEFT_image'])==m.prefix(P,q1 if row['operand']=='lower' else q0)
  image,journal=m.target(full);assert J.encode(image)==z['selected_image'] and journal==z['target_projection']
  currents,norm=m.normal_form(image);assert [J.encode(p) for p in currents]==z['IBP_currents'] and J.encode(norm)==z['normal']
  assert len(P)==row['operand_terms'] and len(full)==row['full_image_terms'] and len(image)==row['selected_terms'] and len(norm)==row['normal_terms']
  assert J.encode(w.plus(m.prefix(P,q1 if row['operand']=='lower' else q0,False),w.scale(full,J.constant(-1))))==z['wrong_even_variation_difference']
  if row['operand']=='JaC':assert z['pure_ghost_source_four_derivative_image']==[] and full==image
  selected[key]=image;normal[key]=norm
 expected={'omit_JaC':[1,0,1],'omit_lower':[1,1,0],'wrong_Fourier_vector_sign':[-1,1,1]}
 for row in result['combined']:
  keys=[(row['probe'],n,row['carrier']) for n in ['vector','JaC','lower']];z=load(O/row['artifact']['file']);P=w.plus(*(selected[k] for k in keys));assert J.encode(P)==z['known_partial_sum']
  cc,nn=m.normal_form(P);assert [J.encode(p) for p in cc]==z['IBP_currents'] and J.encode(nn)==z['normal'] and nn==w.plus(*(normal[k] for k in keys))
  assert len(P)==row['raw_terms'] and len(nn)==row['normal_terms']
  for cr in z['control_differences']:
   cp=w.plus(*(w.scale(selected[k],J.constant(a)) for k,a in zip(keys,expected[cr['control']])));diff=w.plus(cp,w.scale(P,J.constant(-1)));cur,norm=m.normal_form(diff)
   assert J.encode(diff)==cr['raw_difference'] and J.encode(norm)==cr['normal_difference'] and len(norm)==cr['normal_difference_terms']
 assert [(r['probe'],r['carrier'],r['normal_terms']) for r in result['combined']]==[(0,'rational',0),(0,'log9over8',0),(1,'rational',10112),(1,'log9over8',6608)]
 print('STAGE complete_operands_variations_projection_IBP_Euler_and_controls_verified',flush=True)
 diag=load(O/'cross_diagnostic_tables.json.gz');base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';nm,ns=cv.x.maps(load(base/'native_inputs.json.gz'));rm,rs=cv.x.maps(load(base/'replay_inputs.json.gz'));assert nm==rm==diag['all_raw_selected_maps'] and ns==rs
 cross=load(O/'cross_census_v2_tables.json.gz');cr=read(O/'cross_census_v2_result.json');assert digest(O/'cross_census_v2_tables.json.gz')==cr['artifact']['sha256']
 for label,rows in nm.items():
  sig,counts=cv.signatures(rows);found,journal=cv.direct(sig);other,rj=cv.inverse(sig);saved=cross['operators'][label]
  assert found==other=={} and saved['admitted']==[] and saved['all_rejected_candidates']==journal
  assert {str(k):v for k,v in counts.items()}==saved['full_map_intrinsic_counts']
  for row in rows:
   n=row['port']
   for ww,c in J.decode(row['raw']).items():
    assert sum(cv.c.gh[cv.c.species(i)] for i,js in ww)-cv.c.gh[cv.c.species(n)]==1
    assert (sum(J.parity(i) for i,js in ww)-J.parity(n))%2==1
 assert [r['disposition'] for r in cross['operators']['Qu1_1']['all_rejected_candidates']]==['ODD_LORENTZ_RANK_NO_A0_SCALAR','TOTAL_INTRINSIC_OUTSIDE_01']
 assert len(cross['operators']['Qu1_1']['omit_Lorentz_false_candidates'])==1
 print('STAGE intrinsic_aware_cross_support_and_preserved_failed_census_verified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
 ec=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert p.returncode==0
 ev=[json.loads(row) for row in p.stdout.splitlines() if row.strip()];exits=[row['exit_code'] for row in ev if row['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and ev[-1]['execution_state']=='COMPLETED'
 assert next(row for row in ev if row['event']=='step_finished' and row['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 oldtree=(C/'old_git_tree.txt').read_bytes();assert oldtree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True)
 state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V807.md'];size=sum(p.stat().st_size for p in files);assert size<64*1024**2
 out=dict(schema='KNOWN_CONSISTENCY_IMAGES_AND_INTRINSIC_CROSS_SUPPORT_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_KNOWN_IMAGES_AND_QU1_TARGET_SUPPORT_WITH_FAILURES_PRESERVED',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,all_full_odd_prefix_LEFT_images_equal=True,all_actual_operand_and_map_coefficients_verified=True,all_density_IBP_Euler_and_control_checks=True,known_M_rational_normal_terms=10112,known_M_log_normal_terms=6608,known_H_images_zero=True,pure_ghost_JaC_cancellation=True,Qu1_Delta_g0_excluded_only_A0_intrinsic01_LambdaCC_target=True,other_missing_terms_not_zeroed_or_fitted=True,prior_cross_census='FAILED_NOTPASS_DERIVATIVE_PREMISE_INAPPLICABLE_OPERATOR_INTRINSIC1',failed_preparations=2,failed_workers=1,worker_seconds_after_imports=seconds,largest_private_sample=max(s['private_bytes'] for cap in caps.values() for s in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(oldtree.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,complete_consistency_obstruction_QAP_E5_viability_or_goal_completion_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','evidence_validation','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
