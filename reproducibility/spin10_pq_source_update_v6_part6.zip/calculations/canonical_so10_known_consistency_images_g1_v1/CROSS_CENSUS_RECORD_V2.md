# Intrinsic-aware Q_u1 preimage census V2

The60s V1 FAILED; its full source/capture is NOTPASS. The separate completed
60s diagnostic saved all2572 raw/projected ports and found: H is empty,
M raw shifts are1(112728 terms) or0(19296 terms), all ghost/parity shifts
correct. The296 target-compatible terms have shift0 only, at Jx -> Lambda.
The old derivative premise was thus inapplicable. The inherited full-jet
bridge proof already identifies the broken scalar input at intrinsic1.
This is not a change to the action, type, physical input or intrinsic01 bound.

Claim/test: compute total intrinsic degree = breaking-input intrinsic plus
operator-coefficient intrinsic. Define operator intrinsic exactly by
1+dim(input port)-dim(output word including jets), and require it be0/1.
Read all actual maps before target restriction. Classify every candidate
by typed ghost/parity/dimension/derivative count, total intrinsic0/1, and
Lorentz scalar at A0. Direct all-counts vs inverse target-replacement
enumerations must agree. Save all rejected derivative, intrinsic and odd-
Lorentz candidates; no skipped item becomes an accepted zero coefficient.

This tests whether Q_u1 Delta_g0 can contribute in THIS intrinsic01,
Lambda-C-C sector without calculating unknown g0 amplitudes. Empty result
is support exclusion only; nonempty identifies outstanding coefficients.
No expected empty result is imposed. Controls omit all source maps (may
be blind at the final census) and omit Lorentz requirement (report false
candidates). No normalization/counterterm or QAP/measure/E5/A5 claim.

One60s worker after imports, same8GiB sampled private/350MiB launch,
same64MiB complete packet. Freeze new source and full diagnostic artifact
before launch. Preserve failures; no automatic rerun. Final E4 once shared
with known images. V805 Q0/Qu0 census remains in its qualified scope; this
V2 explicitly adds the operator intrinsic needed only by this new Q_u1 test.
Independent enumerations share actual action/types/algebra/AI author and
are not independent scientists or physical validation. Written dimensional
and Lorentz argument anchors the result; all quantum coefficients remain
unassigned. The director's acceptance authority and project_state unchanged.
