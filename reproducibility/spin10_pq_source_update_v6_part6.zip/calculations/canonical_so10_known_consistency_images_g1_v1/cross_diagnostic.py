from pathlib import Path
from collections import Counter
import importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('failed_cross_maps',O/'cross_census.py');x=importlib.util.module_from_spec(sp);sp.loader.exec_module(x)
im=x.im;c=x.c;J=x.J;read=x.read;load=x.load;digest=x.digest

def main():
 tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'cross_diagnostic_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1'
 maps,sigs=x.maps(load(base/'native_inputs.json.gz'));rm,rs=x.maps(load(base/'replay_inputs.json.gz'));assert maps==rm and sigs==rs
 audits=[];matches=[];summary={}
 for label,rows in maps.items():
  dh=Counter();selected_dh=Counter();ghostbad=0;paritybad=0
  for row in rows:
   port=row['port'];dim=J.dimension(port);gh=c.gh[c.species(port)];par=J.parity(port)
   for ww,cc in J.decode(row['raw']).items():
    degree=sum(J.dimension(n)+len(js) for n,js in ww)-dim
    gdegree=sum(c.gh[c.species(n)] for n,js in ww)-gh
    pdegree=(sum(J.parity(n) for n,js in ww)-par)%2
    if gdegree!=1:ghostbad+=1
    if pdegree!=1:paritybad+=1
    dh[degree]+=1
    if ww in J.decode(row['selected']):selected_dh[degree]+=1
    if degree!=1 or gdegree!=1 or pdegree!=1:audits.append(dict(operator=label,port=port,word=J.encode({ww:cc})[0],dimension_shift=degree,ghost_shift=gdegree,parity_shift=pdegree))
  mm=[]
  for cnt in c.all_counts():
   if sum(a*b for a,b in zip(cnt,c.gh))!=1 or sum(a*b for a,b in zip(cnt,c.par))%2!=1:continue
   for intrinsic in [0,1]:
    jets=5-intrinsic-sum(a*b for a,b in zip(cnt,c.dims))
    if jets<0:continue
    for n,outs,der in sigs[label]:
     if cnt[n] and tuple(cnt[i]-int(i==n)+outs[i] for i in range(10))==c.target:
      mm.append(dict(input_species_counts=list(cnt),input_pattern=[c.names[i] for i,v in enumerate(cnt) for j in range(v)],input_jets=jets,intrinsic=intrinsic,replaced_species=c.names[n],map_output_counts=list(outs),map_derivatives=der,actual_output_derivatives=jets+der,required_output_derivatives=2-intrinsic,old_derivative_assertion_holds=jets+der==2-intrinsic))
  matches.extend(dict(operator=label,**v) for v in mm)
  summary[label]=dict(raw_dimension_shift_counts=dict(sorted(dh.items())),selected_dimension_shift_counts=dict(sorted(selected_dh.items())),ghost_shift_failures=ghostbad,parity_shift_failures=paritybad,matches=len(mm),old_derivative_assertion_failures=sum(not v['old_derivative_assertion_holds'] for v in mm))
 a=im.save('cross_diagnostic_tables.json.gz',dict(all_raw_selected_maps=maps,signatures={label:[[i,list(ct),j] for i,ct,j in sorted(sig)] for label,sig in sigs.items()},type_deviations=audits,all_preimage_matches=matches,summary=summary))
 result=dict(schema='ACTUAL_QU1_TYPE_DIAGNOSTIC_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',summary=summary,type_deviations=len(audits),artifact=a,prior_census_FAILED_NOTPASS=True,no_corrected_census_claim=True,elapsed_after_imports=time.perf_counter()-tick)
 im.dump(O/'cross_diagnostic_result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
