# Measured partial consistency images and intrinsic-aware cross-term support

## Exact operands and operation

This is the original Euclidean A0 first-u one-loop local ordered reference,
all45 colors. Overall hbar*g10*u/(16pi2) is suppressed. No additional
subtraction or physical parameter choice is made. V803/V804/V806 own the
quantum coefficients; this calculation operates on them and does not rerun
any loop integrations. The vector coefficients are already proper-signed.
V806's correction to an old compact source-current label does not flip them.

For each serialized vector row, with p on B and ell on Lambda,

    V = -i pcoef (partial_mu B_mu) Lambda C
        -i ellcoef B_mu (partial_mu Lambda) C,

separately for rational and log(9/8) coefficients. This is p=-i partial,
not a new reality prescription. The source operand is

    S = -(3/8) T_cs Ja_s box C_c,

and the lower operand is the serialized V804 proper coordinate density

    L = +i (11Q/36)_bc Lambda_b box C_c.

Q0 uses all643 actual F0 field maps and the complete required Ja source map
Q0Ja=-E0_a=boxC-Lambda M C. Other source maps are not required by these
operands, rather than assigned zero. Q1 uses all643 actual F1 maps with the
polynomial g1 coefficient extracted; there is no division by g10. The
V800 full source pairing sign and V802 actual-action operands are retained.
Native/replay classical input packets agree before use.

The odd prefix Leibniz operation is compared on each COMPLETE image with

    QP = sum_(n,jets) D_jets(Qn) * LEFTpartial_(n,jets) P.

The varied flow is on the left. Sources remain until variation is finished.
All full images, selected terms and raw index projection journals are saved.
The new source's pure (boxC)(boxC) part cancels by symmetric T and odd ghost
exchange; its nonlinear Lambda-C-C part is retained and nonzero for M.
The even-variation control changes3552 M-source terms and is blind for the
other operands. Agreement shares action, coefficient ring, jet algebra and
AI author, so it tests implementation/sign errors within that construction.

## Complete target integration by parts

The target contains one even Lambda and two odd C, ghost2/dimension6/two
ordinary derivatives, no other means/sources. For a word (D_J Lambda)R,
repeated ordinary Leibniz gives four explicit boundary currents and normal
form (-1)^|J| Lambda D_J R. Lambda is even, so extracting it creates no
odd sign. This establishes exact density reconstruction, not only equality
at a selected momentum. Direct LEFT Euler variation with respect to Lambda
independently gives the same normal form. No field equations, p2=0,
kinematic specialization or dropped divergence is used. For polynomials
linear in a distinguished Lambda, the resulting derivative-free-Lambda
coefficient is a complete functional IBP normal form in this target.

The saved M table counts are computational monomials, not physical
parameters, counterterms, amplitudes or progress percentages:

| Contribution | Raw target words | IBP normal words |
| --- | ---: | ---: |
| Q0 vector, rational |9008|7808|
| Q0 vector, log(9/8) |6608|6608|
| Q0 Ja-C, rational |3552|3552|
| Q1 lower, rational |9536|9536|
| Known sum, rational |14616|10112|
| Known sum, log(9/8) |6608|6608|

All H known images and source/lower logarithmic carriers are zero in their
qualified scopes. Omitting Ja-C changes3552 normal words; omitting the
lower image changes9536; reversing the vector Fourier sign changes7808
rational and6608 log normal words. Omissions of rational-only terms are
blind to the logarithmic carrier; H controls are also blind. Full exact
control polynomials, not just counts, are preserved.

These are measured portions of the consistency expression. They do not
constitute the full expression. In particular Q0 Delta_gu(aCC/JBCC/JLambdaCC)
and Q_u0 Delta_g1 remain unmeasured. They must not be set zero, solved by
fitting a remainder, or replaced with a chosen counterterm. Nonzero known
normals cannot be called an obstruction to the theory or an anomaly proof.

## Next bounded test: Q_u1 Delta_g0 support

The first follow-on census FAILED. It reused V805's derivative assertion,
which presupposes operator intrinsic degree0, on Q_u1. The new diagnostic
checks all2572 field/source maps before selection, both probes and both
classical input routes. All ghost/parity shifts are correct. M has112728
raw terms of field/jet dimension shift1 and19296 of shift0; the latter
carry operator intrinsic1. H is empty. Only296 M terms can match the
Lambda/C target, all at the scalar source Jx -> Lambda, with no derivatives
and intrinsic1. This is consistent with the inherited full-jet source
bridge's explicit intrinsic1 scalar block, not an adopted new mass or a
changed action. These numerical coefficients do not erase their degree.

V2 restores total-degree accounting, rather than bypassing the failed
assertion. It defines operator intrinsic by

    d_op = 1 + dim(input port) - dim(output word including jets),

checks d_op in{0,1} on EVERY raw term, then requires d_input+d_op in{0,1}.
The complete direct multiplicity enumeration and inverse target-minus-
output-plus-input construction agree, with every rejected candidate saved.
The only two typed M candidates are:

* Jx C C with input intrinsic0 needs one ordinary derivative. Adding the
  intrinsic1 source operation leaves a single Lorentz derivative and no
  vector slot: no A0 Lorentz scalar exists.
* Jx C C with input intrinsic1 needs no derivative, but output intrinsic2
  lies outside the retained01 domain.

Thus neither probe admits a Lorentz-scalar preimage in this target/domain:
Q_u1 Delta_g0 cannot contribute HERE under the inherited polynomial types.
No unknown g0 coefficient was assigned. Dropping Lorentz invariance falsely
admits one candidate. Dropping all source maps is blind at the final empty
census and is not evidence for source-free operation. This exclusion does
not extend to intrinsic2, external backgrounds, different targets, full
fermion/measure/phase questions or nonlocal functionals. V805 Q0/Qu0
censuses remain unchanged in their original scope.

## Interpretation, failures and authority

The meaningful scientific advance is an explicit checked partial functional
normal and a support exclusion for one remaining cross term, reducing the
next needed quantum questions to unmeasured aCC/JBCC/JLambdaCC g1-u
companions and unprobed g1 companions entering through Q_u0. Nothing here
selects common normalization, validates source products or establishes full
QAP, physical reality, background transport, measure, equivalence or E5/A5.

Two preparation errors occurred before any scientific worker: V1 classified
its new __main__ as a committed helper; V2 attempted to recreate a preserved
source copy. Sources and full returned observations remain. V3 authenticated
existing copies and froze all new files. The cross V1 monitored worker
FAILED the derivative premise; full capture/source remain NOTPASS. Separate
new diagnostic and V2 bounded contracts exposed and corrected the census
applicability, without editing an old source or loosening intrinsic01.

AI capability: exact source-aware operations, explicit IBP witnesses and
negative controls are demonstrated. The reused census premise was an AI
method-selection failure, detected by its assertion. Native/replay agreement
alone did not supply dimensional applicability. All implementations share
inputs/algebra/AI authorship; these are not independent scientists or a
physical validation standard. The independent mathematical anchors are odd
Leibniz, LEFT Euler variation, ordinary IBP and Lorentz scalar typing.

Resources: images24.361s/180, diagnostic11.998s/60, corrected census2.172s/60.
All full successful and failed captures remain. Final verification separately
checks provenance, operands, full variations, density reconstruction,
controls, dimensional support, resources, state, old tree and E4 once. No
scientific authority change or director acceptance is inferred from it.
