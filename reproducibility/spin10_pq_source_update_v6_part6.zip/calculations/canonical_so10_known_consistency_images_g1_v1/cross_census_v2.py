from pathlib import Path
import importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('intrinsic_cross_support',O/'cross_census.py');x=importlib.util.module_from_spec(sp);sp.loader.exec_module(x)
im=x.im;c=x.c;J=x.J;read=x.read;load=x.load;digest=x.digest

def signatures(rows):
 sig=set();intrinsic_counts={}
 for row in rows:
  n=row['port'];dim=J.dimension(n)
  for ww,cc in J.decode(row['raw']).items():
   intrinsic=1+dim-sum(J.dimension(nn)+len(js) for nn,js in ww);assert intrinsic in [0,1],('UNSUPPORTED_OPERATOR_INTRINSIC',n,ww,intrinsic)
   intrinsic_counts[intrinsic]=intrinsic_counts.get(intrinsic,0)+1
  for ww,cc in J.decode(row['selected']).items():
   ct=[0]*10;der=0
   for nn,js in ww:ct[c.species(nn)]+=1;der+=len(js)
   intrinsic=1+dim-sum(J.dimension(nn)+len(js) for nn,js in ww)
   sig.add((c.species(n),tuple(ct),der,intrinsic))
 return sig,intrinsic_counts

def dispositions(cnt,signature):
 n,outputs,der,operator_intrinsic=signature;out=[]
 if not cnt[n] or tuple(cnt[i]-int(i==n)+outputs[i] for i in range(10))!=c.target:return []
 if sum(a*b for a,b in zip(cnt,c.gh))!=1 or sum(a*b for a,b in zip(cnt,c.par))%2!=1:return []
 for input_intrinsic in [0,1]:
  jets=5-input_intrinsic-sum(a*b for a,b in zip(cnt,c.dims))
  if jets<0:continue
  total_intrinsic=input_intrinsic+operator_intrinsic
  reason=None;lorentz=None
  if total_intrinsic not in [0,1]:reason='TOTAL_INTRINSIC_OUTSIDE_01'
  elif jets+der!=2-total_intrinsic:reason='OUTPUT_DERIVATIVE_MISMATCH'
  else:
   lorentz=c.lorentz(cnt,jets)
   if lorentz is None:reason='ODD_LORENTZ_RANK_NO_A0_SCALAR'
  key=(cnt,jets,input_intrinsic,operator_intrinsic)
  out.append((key,dict(input_counts=list(cnt),input_pattern=[c.names[i] for i,v in enumerate(cnt) for j in range(v)],input_jets=jets,input_intrinsic=input_intrinsic,operator_intrinsic=operator_intrinsic,total_intrinsic=total_intrinsic,output_derivatives=jets+der,required_output_derivatives=2-total_intrinsic,source_species=c.names[n],map_output=list(outputs),map_derivatives=der,disposition=reason or 'ADMITTED',Lorentz=lorentz)))
 return out

def direct(sig):
 found={};journal=[]
 for cnt in c.all_counts():
  for signature in sorted(sig):
   for key,row in dispositions(cnt,signature):
    journal.append(row)
    if row['disposition']=='ADMITTED':found[key]=row
 return found,journal

def inverse(sig):
 found={};journal=[]
 for signature in sorted(sig):
  n,outputs,der,op_intrinsic=signature
  cnt=tuple(c.target[i]-outputs[i]+int(i==n) for i in range(10))
  if min(cnt)<0:continue
  for key,row in dispositions(cnt,signature):
   journal.append(row)
   if row['disposition']=='ADMITTED':found[key]=row
 return found,journal

def main():
 tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'cross_v2_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 diag=load(O/'cross_diagnostic_tables.json.gz');maps=diag['all_raw_selected_maps'];out={};summary={}
 for label,rows in maps.items():
  sig,counts=signatures(rows);found,journal=direct(sig);other,rj=inverse(sig);assert found==other and sorted(map(json.dumps,journal))==sorted(map(json.dumps,rj))
  nosource,_=direct({r for r in sig if r[0]<5});without_lorentz=[r for r in journal if r['disposition']=='ODD_LORENTZ_RANK_NO_A0_SCALAR']
  out[label]=dict(full_map_intrinsic_counts=counts,actual_target_signatures=[[n,list(outs),der,ii] for n,outs,der,ii in sorted(sig)],admitted=list(found.values()),all_rejected_candidates=[r for r in journal if r['disposition']!='ADMITTED'],omit_source_control_admitted=list(nosource.values()),omit_Lorentz_false_candidates=without_lorentz)
  summary[label]=dict(admitted_patterns=len(found),raw_Lorentz=sum(len(r['Lorentz']['basis']) for r in found.values()),after_IBP=sum(r['Lorentz']['quotient'] for r in found.values()),rejected_candidates=len(journal)-len(found),odd_Lorentz_rejections=len(without_lorentz),total_intrinsic_rejections=sum(r['disposition']=='TOTAL_INTRINSIC_OUTSIDE_01' for r in journal),omit_source_final_census_blind=set(found)==set(nosource),omit_Lorentz_false_admissions=len(without_lorentz))
 a=im.save('cross_census_v2_tables.json.gz',dict(schema='INTRINSIC_AWARE_ACTUAL_QU1_PREIMAGE_CENSUS_V2',operators=out,summary=summary,all2572_raw_port_maps_bound_by_diagnostic_artifact=digest(O/'cross_diagnostic_tables.json.gz'),no_quantum_coefficient_assigned=True))
 result=dict(schema='INTRINSIC_AWARE_QU1_CENSUS_RESULT_V2',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',summary=summary,artifact=a,complete_this_domain_preimage_census=True,direct_inverse_equal=True,previous_V1_FAILED_NOTPASS=True,no_global_conclusion=True,elapsed_after_imports=time.perf_counter()-tick)
 im.dump(O/'cross_census_v2_result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
