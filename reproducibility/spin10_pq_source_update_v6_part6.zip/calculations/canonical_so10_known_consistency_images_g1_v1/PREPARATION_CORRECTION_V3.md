# Preparation correction V3

V2 stopped before worker/manifest creation when create-only source capture
encountered the already preserved V1 RECORD.md.source.txt. V3 verifies
existing source-copy byte equality and creates missing copies only. All
V1/V2 sources and returned observations remain, neither is a worker
capture/PASS. No scientific or physical change, no resources expanded;
V1 record and V2 historical-helper exclusion otherwise unchanged.
