from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('known_image_actual',O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/factory.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
J=m.J;w=m.w;A=w.A
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
atom=lambda n,js=():{((n,tuple(js)),):J.constant(1)}
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/name).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=64*1024**2
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def prefix(P,Q,odd=True):return m.v.act(P,Q,odd=odd)
def gradient(P,Q):
 out={}
 for n,js in sorted({t for ww in P for t in ww}):
  if Q.get(n):J.add(out,J.mul(J.Ds(Q[n],js),J.leftjet(P,(n,js))))
 return J.clean(out)
def target(P):
 keep={};bad=defaultdict(list);ids=[]
 for at,(ww,c) in enumerate(sorted(P.items())):
  L=sum(508<=n<553 for n,js in ww);C=sum(553<=n<598 for n,js in ww)
  why=None
  if L!=1 or C!=2 or len(ww)!=3:why='NOT_LAMBDA1_C2_ONLY'
  elif sum(len(js) for n,js in ww)!=2:why='NOT_TWO_DERIVATIVES'
  if why:bad[why].append(at)
  else:keep[ww]=c;ids.append(at)
 return keep,dict(kept_raw_indices=ids,rejected=[dict(reason=k,raw_indices=v) for k,v in sorted(bad.items())])
def normal_form(P):
 groups={};currents=[{} for _ in range(4)];normal={}
 for ww,c in P.items():
  at=[i for i,(n,js) in enumerate(ww) if 508<=n<553];assert len(at)==1
  pos=at[0];n,jets=ww[pos];assert J.parity(n)==0
  J.put(groups.setdefault((n,jets),{}),ww[:pos]+ww[pos+1:],c)
 for (n,jets),rest in groups.items():
  for r,mu in enumerate(jets):
   for ww,c in rest.items():J.put(currents[mu],((n,tuple(jets[r+1:])),)+ww,c*((-1)**r))
   rest=J.D(rest,mu)
  for ww,c in rest.items():J.put(normal,((n,()),)+ww,c*((-1)**len(jets)))
 currents=[J.clean(p) for p in currents];normal=J.clean(normal);div={}
 for mu,cur in enumerate(currents):J.add(div,J.D(cur,mu))
 assert J.clean(div)==w.plus(P,w.scale(normal,J.constant(-1))),'EXACT_IBP_RECONSTRUCTION'
 euler=J.euler(P,range(508,553));direct={}
 for n,p in euler.items():J.add(direct,J.mul(atom(n),p))
 assert J.clean(direct)==normal,'DIRECT_EULER_NORMAL_FORM'
 return currents,normal
def build_operands():
 vector=load(O.parent/'canonical_so10_proper_normalization_transfer_g1_v1/proper_reference.json.gz');source=load(O.parent/'canonical_so10_JaC_companion_g1_recovery_v1/proper_reference.json.gz');lower=load(O.parent/'canonical_so10_unmarked_g0_common_kinetic_recovery_v1/derivation_tables_v2.json.gz')
 out={(pr,name,carrier):{} for pr in [0,1] for name in ['vector','JaC','lower'] for carrier in ['rational','log9over8']}
 assert len(vector['M_vector_all_positions'])==45**3 and len(source['source_color_rows'])==4050
 for row in vector['M_vector_all_positions']:
  a,b,c=[row[k] for k in ['B','Lambda','C']]
  for carrier,suffix in [('rational','rational'),('log9over8','log')]:
   pc=A.decode_coeff(row['p_'+suffix]);lc=A.decode_coeff(row['ell_'+suffix])
   if not pc and not lc:continue
   for mu in range(4):
    B=4*a+mu;L=508+b;C=553+c
    J.put(out[1,'vector',carrier],((B,(mu,)),(L,()),(C,())),J.times(-J.I,pc))
    J.put(out[1,'vector',carrier],((B,()),(L,(mu,)),(C,())),J.times(-J.I,lc))
 for row in source['source_color_rows']:
  cc=A.decode_coeff(row['proper_QGamma_p2'])
  for mu in range(4):J.put(out[row['probe'],'JaC','rational'],((1241+row['Ja'],()),(553+row['C'],(mu,mu))),-cc)
 for case in lower['cases']:out[case['probe'],'lower','rational']=J.decode(case['finite_unmarked_QGamma'])
 return {k:J.clean(p) for k,p in out.items()}
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 pn=load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/native_inputs.json.gz');pr=load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/replay_inputs.json.gz');assert pn==pr
 states={k:dict(v) for k,v in pn['states'].items()};q0={n:J.decode(p) for n,p in states['F0'].items()};q1={}
 for n,raw in states['F1'].items():
  P=J.decode(raw);assert all(k[0]==1 for cc in P.values() for k,v in cc.terms)
  q1[n]=m.v.grade(P,1,strip=True)
 for r in range(45):q0[1241+r]=w.scale(J.decode(states['E0'][598+r]),J.constant(-1))
 operands=build_operands();rows=[];selected={};art=[];norms={};fulls={}
 art.append(save('actual_derivative_maps.json.gz',dict(Q0_fields_and_required_Ja=[[n,J.encode(p)] for n,p in sorted(q0.items())],Q1_all_fields_g1_polynomial_coefficient=[[n,J.encode(p)] for n,p in sorted(q1.items())],Q0_other_source_ports_not_required_by_operand_support=True,Q1_source_ports_not_required_by_lower_operand_support=True)))
 for key,P in sorted(operands.items()):
  probe,name,carrier=key;Q=q1 if name=='lower' else q0
  assert all(k[0]==0 for cc in P.values() for k,v in cc.terms)
  assert all(n in Q for ww in P for n,js in ww),'OPERAND_DERIVATIVE_PORT_MISSING'
  full=prefix(P,Q);left=gradient(P,Q);assert full==left,'ODD_PREFIX_LEFT_MISMATCH'
  image,journal=target(full);fulls[key]=full;selected[key]=image
  if name=='JaC':assert full==image,'PURE_GHOST_JAC_CANCELLATION_OR_EXTRA_SECTOR_FAILURE'
  currents,normal=normal_form(image);norms[key]=normal
  even=prefix(P,Q,False);even_difference=w.plus(even,w.scale(full,J.constant(-1)))
  label=f'probe{probe}_{name}_{carrier}'
  a=save(label+'.json.gz',dict(probe=probe,operand=name,carrier=carrier,coordinate_operand=J.encode(P),full_odd_prefix_image=J.encode(full),full_LEFT_image=J.encode(left),target_projection=journal,selected_image=J.encode(image),IBP_currents=[J.encode(p) for p in currents],normal=J.encode(normal),exact_IBP_reconstruction=True,direct_Euler_agrees=True,pure_ghost_source_four_derivative_image=J.encode(w.plus(full,w.scale(image,J.constant(-1)))) if name=='JaC' else None,wrong_even_variation_difference=J.encode(even_difference)))
  art.append(a);rows.append(dict(probe=probe,operand=name,carrier=carrier,operand_terms=len(P),full_image_terms=len(full),selected_terms=len(image),normal_terms=len(normal),even_difference_terms=len(even_difference),artifact=a))
  print('STAGE '+json.dumps(rows[-1],sort_keys=True),flush=True)
 combined=[];controls=[]
 for prb in [0,1]:
  for carrier in ['rational','log9over8']:
   keys=[(prb,name,carrier) for name in ['vector','JaC','lower']];P=w.plus(*(selected[k] for k in keys));currents,normal=normal_form(P)
   assert normal==w.plus(*(norms[k] for k in keys))
   crows=[]
   for cn,coeff in [('omit_JaC',[1,0,1]),('omit_lower',[1,1,0]),('wrong_Fourier_vector_sign',[-1,1,1])]:
    cp=w.plus(*(w.scale(selected[k],J.constant(a)) for k,a in zip(keys,coeff)));diff=w.plus(cp,w.scale(P,J.constant(-1)));cc,nn=normal_form(diff)
    crows.append(dict(control=cn,raw_difference=J.encode(diff),normal_difference=J.encode(nn),normal_difference_terms=len(nn),raw_difference_terms=len(diff)))
    controls.append(dict(probe=prb,carrier=carrier,control=cn,normal_difference_terms=len(nn),raw_difference_terms=len(diff)))
   a=save(f'probe{prb}_known_sum_{carrier}.json.gz',dict(probe=prb,carrier=carrier,known_partial_sum=J.encode(P),IBP_currents=[J.encode(p) for p in currents],normal=J.encode(normal),control_differences=crows,exact_IBP_reconstruction=True,direct_Euler_agrees=True,missing_other_gu_companions_and_Qu0_Delta_g1_Qu1_Delta_g0_explicit=True,not_complete_consistency_equation=True,not_obstruction=True))
   art.append(a);combined.append(dict(probe=prb,carrier=carrier,raw_terms=len(P),normal_terms=len(normal),artifact=a));print('STAGE '+json.dumps(combined[-1],sort_keys=True),flush=True)
 result=dict(schema='KNOWN_G1_U_CONSISTENCY_IMAGES_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',rows=rows,combined=combined,controls=controls,artifacts=art,all_full_prefix_LEFT_images_equal=True,all_exact_IBP_and_direct_Euler_checks_equal=True,all_required_source_operations_before_projection=True,pure_ghost_JaC_four_derivative_part_zero=True,missing_terms_not_set_zero=True,normalization_not_selected=True,loop_integrations_reexecuted=0,complete_consistency_or_obstruction_claim=False,elapsed_after_imports=time.perf_counter()-tick)
 dump(O/'images_result.json',result);print('RESULT '+json.dumps({k:v for k,v in result.items() if k not in ['rows','artifacts','controls']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
