# Preparation correction V2

V1 preparer failed before manifest/control directory/worker launch: import
inventory included __main__ (the new run.py) as an existing committed helper.
All V1 sources and full returned failure observation are retained. This is
not a monitored worker capture and not a scientific calculation failure.
V2 excludes this new packet directory from the historical helper check;
all its new files are separately frozen in the same preparation manifest.
No input, algorithm, authority,180s worker,8GiB/350MiB/64MiB limit changes.
No reexecution of a scientific worker: none was launched by failed V1.
