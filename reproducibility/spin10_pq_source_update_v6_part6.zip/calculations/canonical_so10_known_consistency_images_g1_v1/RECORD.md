# Known g1-u consistency images, bounded record V1

Question: What is the actual Lambda-C-C component of Q0 acting on the
measured proper vector and Ja-C references, plus Q1 acting on the measured
unmarked g0 first-u reference? This is the next prerequisite for testing
common normalization, not a test of the complete quantum theory.

Claim: exact polynomial odd variation in the original Euclidean A0 chart,
all45 colors, intrinsic0, target Lambda1 C2 / ghost2 / dimension6 /
two derivatives. Overall hbar*g10*u/(16pi2) suppressed. Rational and log(9/8)
carriers remain separate. No physical coupling or width is specialized.
Translate Fourier p=-i partial; source Ja-C p2=-Ja boxC; lower coordinate
reference is used directly. No new integration or finite subtraction.

Inputs: committed V803 proper vector and zero Ja-Lambda-C reference,
V806 proper Ja-C reference, V804 finite_unmarked_QGamma, V802 native/replay
classical maps, V800 sign/source convention and V805 complete carrier census.
Current AGENTS and project_state bind new work. Preparation hashes exact
committed bytes and imported helper modules. Historical receipts are reused
as qualified inputs, not rerun loops, independent scientists or global QAP.

Method: construct coordinate operands from serialized coefficients; apply
actual full field flows (all643) and the Ja source Euler map before target
restriction. Q1 is extracted as the polynomial g1 coefficient, never by
dividing a physical coupling. Other source derivatives are not needed:
operands contain no other sources. They are not assigned zero. Physical
Euler maps at unrelated source ports and chiral/measure completion remain
uncomputed and do not enter these three exact operand variations.

Independent method: prefix odd Leibniz versus LEFT-jet gradients with flow
on the left. Compare complete images before projecting. Preserve complete
operands/images, kept/rejected raw index journals and derivative flows.
For each target image integrate by parts to undifferentiated Lambda using
explicit four divergence currents; compare to direct LEFT Euler derivative.
Check exact reconstruction, without equations of motion or on-shell momenta.
This is a complete functional normal form only for this linear-Lambda target.

Controls: retain pure-ghost fourth-derivative source image separately and
check it is zero by symmetric tensor/odd exchange; compare even variation,
omitting Ja-C, omitting the lower image, and reversing the Fourier sign.
Report actual sensitivity or blindness, never define a desired nonzero
answer. H-probe and log-source/lower zero complements are retained.

Failure: any input/hash, dual-variation, type, projection, full IBP or Euler
mismatch is FAILED, not a changed physical assumption. A nonzero known
normal is a partial contribution, not an obstruction. Missing aCC/JBCC/
JLambdaCC g1-u terms, Qu0 Delta_g1 and Qu1 Delta_g0 remain explicit. No
unknown coefficient is fitted; no restoring counterterm or normalization
is adopted. Classical consistency cannot be asserted for an incomplete sum.

Resources: one180s after-import worker,8GiB sampled private memory,
350MiB launch available-pagefile floor; complete packet64MiB. Capture full
stdout/stderr and samples, preserve failed sources/captures. A separate
180s final validation owns exactly one existing E4 no-fresh audit using
D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4. Expected step
exits0,0,0,0,0,2 and seven custody unresolved NOTPASS. No automatic rerun.

Authority: bounded executable derivation and evidence validation only;
project_state/E5/A5/adoption/flavor/HB1/C5 unchanged, no remote action.
Shared action/chart, coefficient ring, helper algebra and AI author limit
independence. Established odd Leibniz and Euler/IBP identities anchor the
checks; this does not validate the physical regulator/source assumptions.
Possible outcomes: zero or nonzero measured partial normal, invalid
translation/derivation, or incomplete execution. Each changes only the next
missing-coefficient question. Record actual result and next test after run.
