# Next discriminating test: actual Q_u1 preimage census V1

The completed known images leave a nonzero partial target. Before computing
another quantum graph, determine which still-unmeasured g0 breaking carriers
can feed Lambda-C-C through Q_u1. This does not assign those coefficients.
Reuse V805 types/ring/single-replacement completeness/physical-potential and
CPS support proof. Same original Euclidean A0,intrinsic01, dimension5 ghost1
odd breaking; dimension6 ghost2 target Lambda1 C2 with two derivatives.

Read every one of1286 ports for both Fu1/Eu1 probes before projection.
Q_u1 source map is (-1)^p Eu1; the physical action has no u dependence,
so no unknown physical-potential Euler is setzero. Strip exactly polynomial
g1 from coefficients (reject any different grade). Full native/replay
operands must agree; retain all raw/selected maps and rejection indices.
Use direct all-typed-candidate and inverse target-minus-output-plus-input
censuses with exact Lorentz/IBP ranks already derived in V805. Expected
outcome not stipulated: empty census supports only this intrinsic01 target
exclusion; nonempty census identifies mandatory remaining g0 coefficients.

One60s after-import worker,8GiB sampled private/350MiB launch floor,
same64MiB complete packet. Preserve any failure; no automatic retry. Freeze
all sources and inputs before launch. Final evidence check/E4 once is shared
with the known-images increment. No foundational adoption, source products,
QAP, chiral phase, E5/A5 or full consistency assertion. Shared action/chart/
ring/helper enumeration/AI author; two enumeration routes are not independent
physical validation. This structural support test is cheaper than new loop
integrations and determines the next indispensable missing-input question.
