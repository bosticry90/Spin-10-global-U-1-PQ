# Final evidence validation V1

One180s after-import worker,8GiB sampled private/350MiB available-pagefile
launch floor,64MiB whole packet, all failed sources/captures preserved.
Freeze final source/result/proof/handoff and all current files before run.
Authenticate every earlier preparation; verify source copies, actual
coordinate operands and required maps, all complete odd prefix/LEFT saved
images, full target projection journals, explicit IBP reconstructions and
Lambda Euler normals, sums/control polynomials and recorded counts.

Authenticate and inspect the FAILED cross capture separately from success.
Verify diagnostic raw/projected map equality against native/replay inputs,
all intrinsic degrees and ghost/parity checks, corrected direct/inverse
census/rejection classifications. Preserve two non-monitored failed
preparation observations as such. No loop integration replay or external
physical validation. State/old tracked modes/blobs and scientific boundaries
unchanged. Run E4 exactly once, no --fresh, existing D evidence context;
expect0,0,0,0,0,2 and seven unresolved historical custody NOTPASS. Capture
full stdout/stderr before assertions. A completed final receipt may validate
bounded evidence including a qualified failure; it does not retroactively
pass the failed run or scientifically accept the model. No local commit
until this validation and exact staged-byte/mode guard complete.
