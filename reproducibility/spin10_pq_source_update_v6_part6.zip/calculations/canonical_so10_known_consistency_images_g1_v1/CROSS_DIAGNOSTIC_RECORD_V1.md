# Diagnose failed Q_u1 census before any revised census

The first60s cross worker FAILED V805's jets+map-derivatives=2-intrinsic
assertion. Its source/preparation/full monitored capture remain unchanged
and NOTPASS. No census result or quantum exclusion was produced.

This new60s diagnostic (same8GiB/350MiB/64MiB packet) inspects the actual
full Fu1/Eu1 maps with V805 dimensions, ghost numbers and parity. It saves
all maps, targeted signatures and every preimage match with actual derivative
counts. It does not remove the failing assertion from an accepted census,
assume the maps satisfy its premise or change physical inputs. Both original
and replay must agree. Bind owning g1 source densities and source type code.

Question: does the failed census reflect an incorrect reuse of a type premise,
a defect in existing source maps, or a missing intrinsic-dimension treatment?
Possible outputs are a precise mismatch needing correction, a valid additional
signature outside the old premise, or bounded inconclusive execution. Do not
promote an empty/nonempty census before resolving that question. No new loop,
normalization, accepted assumption, project_state change or global conclusion.
