# Joint internal simple-pole switching in the selected causal group

Use the V910 two-color selected connected coefficient, with both
positive squared scalar reference masses, the actual V898
derivative paths, the same V903 real compact profile pair, exact
exterior ghost roots and exact massive feedback bridge. Sum the
quadratic switches on the internal simple-pole ghost and massive
scalar edges together. Internal mixed and auxiliary gauge edges
remain bare. Keep the original normalized one-port and proper
forests, the sequential same-sign Feynman boundary and the V907
Schwartz sources with small compact momentum supports. The small
momentum ball is chosen below the positive scalar threshold for
all the fixed soft-region constants used below.

## Fixed positive internal ghost counts

The proper diagrams with an internal ghost edge are YY, FMY
and FFMM. Keep one derivative on the internal ghost where it
occurs. In FFMM retain the exterior antighost derivative or its
color-17 switch replacement. Let n>=1 be the number of internal
ghost switches, k>=0 the fixed massive scalar count, and delta
the maximum physical transfer scale in one normalized band.
Each ghost or scalar switch carries its actual transfer square.
There are n+1 simple ghost denominators. A finite scalar chain
can be left as its original denominators in this argument.
It is uniformly off shell in the small loop region, and on
hard loop annuli uses the same combined-phase submersion as
the massless and mixed denominators. The positive scalar
count adds delta^(2k). Its ultraviolet improvement and the
positive ghost count require no new proper counterterm.

At the exterior momentum tip |p|<=C delta use the joint
rescaling and independent edge coordinates of V904. Each
additional simple ghost denominator has degree two, canceled
by its switch square. The mixed numerators and the actual
derivatives give at least a delta² loop gain: YY has a simple
ghost, FMY has a mixed edge and a differentiated ghost or an
exterior derivative, and FFMM has two mixed edges, one internal
derivative and one exterior or switch derivative. All these
momenta scale together at the tip. The exterior poles and any
fixed exterior switches have degree zero after the p measure.
The hard q annuli at the tip are treated by the same-ray
estimate below. These are estimates of the joint distributions,
not pointwise bounds on null denominators.

For |p| of size r≫delta, orient the loop so that the ghost
momenta are q+O(delta) and the mixed and massive momenta are
q−p+O(delta). On a small angular patch choose a component p_j
with sign nu and a normalized interval nu p_j/r in [a,b],
where a>0 and b−a<a/4. In the compact loop region |q|<=C r
split using a smooth function of nu q_j/r equal to one below
a/2 and zero above 3a/4. On its first part keep q real through
the ghost group. Every mixed phase has nu(q_j−p_j)<=−a r/4,
up to the small shifts. Deform p_j as in V904 by i eta r
with the sign of its Lorentz gradient. This gives positive
imaginary part at least c eta r² for all mixed and exterior
poles. The massive phase is off shell on this support.

In this first region each mixed numerator/denominator costs
at most C eta^-N/r, with bounded normalized derivatives.
The FMY derivative supplies either the internal q scale or r.
The FFMM derivatives supply both and cancel the two possible
inverse powers of r, since the internal scale is at most r.
Thus the ghost cluster can be estimated with no extra negative
power of r. On |q|<=C delta its tensor rescaling gives
delta^(4−2(n+1)+2n)=delta². On annuli of size v from delta to
r combine the same-sign ghost denominators. Their shifted
phases are submersions in a fixed unit-annulus chart, giving
delta^(2n) v^(2−2n) per annulus in the appropriate finite
seminorms. The sum is O(delta²(1+log(r/delta))).
Normalized derivatives of the deformed smooth factors
only cost further finite powers of eta^-1.

On the second part of the split reroute the real loop variable
as q'=q−p before deforming the external component. The support
union satisfies nu q'_j/r>=a/2−b. For every p_j in the patch
the ghost phases therefore gain the same positive imaginary
part. The mixed cluster remains real with the original common
sign. Its at most two order-one factors have integrated
seminorms O(r^(4−b_m)), where b_m is their number, by joint
scaling at delta and same-ray annuli above delta. The actual
derivatives supply r^b_m or more on this support. With the
deformed ghost denominators the bound is
C eta^-N delta^(2n) r^(2−2n)<=C eta^-N delta².
The massive factors again stay off shell. The rerouted
cutoffs and ordinary source factors are smooth test factors;
extend them almost analytically in p_j as in V904. Their
real supports have the fixed margins above, so the deformed
rational factors are holomorphic on the required strip.
The boundary pairing therefore loses only a finite test
order in that component, not an inverse delta. The original
same-sign boundary in the other loop variables is retained.

On |q|>=C r no inner deformation is needed. Integrate on
real Euclidean loop annuli after Feynman combining the
same-sign factors. All shifts are small compared with the
annulus radius, so the phase has a fixed submersion
coordinate, including through the massive shell.
After this integration the inner factor is smooth in the
normalized exterior and transfer arguments. Before the
large ultraviolet annuli, the bound is
delta^(2n) v^(2−2n) on a loop annulus of size v,
or better. At large v the extra ghost denominator
ensures integrability. Thus this portion costs at most
O(delta²(1+|log r|)), with finite normalized derivatives
for sewing to the exterior poles. This use of the
submersion differentiates the real smooth parameter
dependence; it does not deform a shifted hard loop pole
with the wrong imaginary sign.

Together these bounds give at most a second logarithm
when summing the dyadic p shells. For every fixed positive
ghost count, every fixed scalar count and every fixed
exterior count the correction tends to zero. The bound on
large transfer bands is by the original tempered finite
graph and the rapid switch transforms as in V904. It does
not assume positivity of a combined massive parameter on
those bands. The small-transfer estimates also allow
exact exterior roots by the V907 asymmetric peeling.
When an exterior tail is used the total momenta are in
the joint tip band, with its positive power. The cases
n=0 with positive scalar count are already V910.

## Exact internal tails and the joint sum

On rescaled compact endpoints the exact massless ghost
inverse obeys the V901 contraction. Peel L factors on
each wing, leaving the exact inverse in the middle,
as in V910 but without a large-mass factor. Each wing
has the localized time or space Sobolev gain of V907.
The cutoff middle operator is bounded on L², since its
compact source and output weights are bounded. Thus the
remainder after 2L counts has a jointly C^k kernel
H(x,y) on the fixed compact endpoints for any prescribed
finite k after choosing L. The weighted Neumann series
converges there in those seminorms after the wings.
At fixed scale the finite-absorption wings converge
in the gains, using the local kernel-difference bound
of V909 and spatial interpolation. Strong convergence of
the middle suffices for the joint kernel, since the
wing evaluation vectors and their fixed derivatives
range over compact subsets of L². The physical smooth
tail is lambda² H(lambda x,lambda y).

Cutting that ghost edge opens the loop. With finitely
many scalar switches, the remaining graph is a tree.
The two smooth ghost endpoint Fourier variables are
independent and have arbitrarily many prescribed finite
rapid seminorms. Include them in the rescaled transfer
bands. In the physical soft band, conservation forces
each remaining mixed momentum to be −p+O(delta), and
the scalar chain is off shell. For r≫delta use the
common-sign p deformation on those mixed and exterior
poles. The two derivatives in FFMM cost at most
r delta and its two mixed poles cost at most r^-2
up to finite eta powers. FMY costs at most r/r
or delta/r, and YY has no mixed pole. Thus the tail
contributes lambda² times at most the p-shell logarithms.
At the p tip all massless edge factors scale together;
the derivative and mixed powers are neutral or better.
If a smooth exterior tail is used its Fourier localization
puts the term in this same joint tip band. The rapid
endpoint and switch seminorms control the complementary
bands with the original tree distributions. These
estimates apply to the exact ghost tail and any fixed
scalar count, including the bare scalar.

For clarity the combined peeling can be ordered without
an order chosen against itself. First peel the internal
ghost sufficiently for a term in which both internal
edges are smooth and for the corresponding fixed tree
seminorms. In terms with finite ghost counts peel the
massive edge using V910, with its middle powers chosen
after those counts. Its suppression beats the polynomial
cost of the exact exterior roots. In terms with the
ghost tail and the massive tail the remaining graph has
two edges removed and a fixed distribution order; the
massive middle again beats the fixed losses. The
remaining terms have a ghost tail and finitely many
scalar counts. For these use the preceding smooth-ghost
tree estimate and V907 exterior peeling. A tail may be
peeled further after the other rough counts are fixed.
Every such change produces finitely many terms with
one fewer exact tail. Induction on the number of tails
terminates, and the finite terms use the fixed-count
estimates above. No contour constant uniform in count
is needed. The kernel convergence after the wings
identifies the sewn tails with the separately normalized
series, since the removed edges leave tree products
against smooth factors. Thus the joint simple-pole
proper correction vanishes.

## The exact Y ghost tadpole and its bridge

The converted one-edge ghost tadpole is zero at count
zero by V883. At count one, keep the inherited common
UV subtraction of the two massless propagators. The
finite Fourier symbol is the same-sign
log(−P(k)−i0) and a local constant, with its actual
ordered trace coefficient. Under k=lambda ell it gives
lambda² times a smooth compact source after multiplying
the ordinary Y switch, of C^k size O(1+|log lambda|).
The log at the cone and at the tip is locally integrable
as a distribution, and multiplication by the Schwartz
potential transform gives all the needed derivatives.
The constant and logarithm use the original normalization.

At n>=2 the cycle has total scaling degree 2(n+1)
in 4n relative dimensions and no divergent proper
cycle subgraph. The original same-sign extension is
homogeneous, and each fixed word gives physical scale
lambda² after its n switch powers and n relative
integrations. The rescaled diagonal tadpole is smooth
as a source: in relative coordinates all center
derivatives hit the compact switch factors. The exact
high-count remainder has the smooth diagonal of the
two-wing ghost peel above, and the converted high
terms converge there. Hence the full source has fixed
compact support after its ordinary switch, with
C^k size O(lambda²(1+|log lambda|)). The actual V883
trace is retained, not replaced by a vanishing trace
assumption. This loop has no internal massive edge.
The kinetic one-port has no internal ghost edge and
is already covered by V910.

The V908 exact massive bridge maps this soft source
to the same order in each fixed compact C^k norm.
Here its leading coefficient may touch the origin.
The exact exterior pair against an arbitrary bounded
family of smooth compact tests of sufficient finite
order costs at most O(1+|log lambda|), not the crude
lambda^-2 weighted bound. For the bare pair use the
V899 soft logarithm before removing the origin value
of the test. The double correction and the bare times
the two-or-more insertion remainder are uniformly
bounded by V902 Sobolev estimates. For the bare times
single-insertion triangle the V902 no-cancellation
argument extends through x=0. The potential vertex
y is away from zero. At x=0 the two y-edge conormals
have the same orientation at y, so their sum cannot
vanish unless both are zero. Then the remaining
tip-edge covector is zero as well. Away from x=0 use
the original argument. Thus the compact pushforward
is smooth in the two source parameters near zero.
Its bounds extend to bounded test families by
distributional continuity on fixed compact supports
and uniform boundedness. The Schwartz source tails
are controlled by the V901 polynomial weighted
estimate as in V907. Hence the full Y feedback
is O(lambda²(1+|log lambda|)^2) and tends to zero.

The nonzero V908 two-color profile difference
survives all internal simple-pole switches, with
the two exterior roots and massive bridge exact.
It still requires the internally switched mixed
and auxiliary gauge loop estimates for a full causal
comparison. The V909 line inverse alone does not
supply those loop products.
