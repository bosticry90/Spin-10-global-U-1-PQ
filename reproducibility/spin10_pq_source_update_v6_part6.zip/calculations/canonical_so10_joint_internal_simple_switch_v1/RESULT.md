# Joint internal simple-pole switching V911

The internal ghost and massive scalar switches can be summed
together in the selected causal proper and one-port group, with
bare internal mixed and auxiliary gauge lines. The finite ghost
terms route the loop through its ghost or mixed cluster before
deforming the exterior momentum. The resulting common-sign
bounds have a positive transfer power. Exact tails are sewn
through tree distributions after the corresponding edge is
removed, with the exterior roots and massive bridge exact.

The exact Y tadpole keeps its actual nonzero trace and original
first-switch logarithmic subtraction. Its bridged contribution
vanishes as O(R^-2(1+log R)^2). The two-color causal profile
difference at unequal reference masses survives the full
internal simple-pole sum.

The internally switched mixed and auxiliary gauge products
remain outside this result. Exact replay checks the cone
routing margins, scaling and inherited trace and color inputs.
The distributional estimates are in the proof.
