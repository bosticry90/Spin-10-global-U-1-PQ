"""Exact cone routing, scaling and tadpole controls for V911."""

import json
import sys
import sympy as sp

from execute import ROOT, run_worker


def routing(phase):
    a,gap,r,eta=sp.symbols("a gap r eta",positive=True)
    b=a+gap
    assert sp.expand((a/2-b)+a-(a/2-gap))==0
    assert sp.expand((a/2-gap-a/4).subs(gap,a/4))==0
    assert sp.expand(a-3*a/4)==a/4
    signs=[]
    for metric in (1,-1):
        if phase=="native":
            mixed=-a*r/4-sp.I*metric*eta*r
            ghost=a*r/4+sp.I*metric*eta*r
            values=[sp.im(metric*mixed**2),sp.im(metric*ghost**2)]
        else:
            values=[2*metric*(-a*r/4)*(-metric*eta*r),
                    2*metric*(a*r/4)*(metric*eta*r)]
        assert all(sp.simplify(v-a*eta*r**2/2)==0 for v in values)
        signs.append("same positive")
    return {"first_region":"real ghost group, deformed mixed group",
            "second_region":"real mixed group, deformed ghost group",
            "imaginary_signs":signs,"patch_margin":"a*r/4"}


def scaling():
    n,k = sp.symbols("n k",integer=True,nonnegative=True)
    assert sp.expand(4-2*(n+1)+2*n)==2
    assert sp.expand(2*n+4-2*(n+1))==2
    assert sp.expand(4-(2+n)*2+2*n)==0
    for count in range(2,8):
        assert 2*(count+1)<4*count
    assert 2*(1+1)==4
    assert sp.expand(2*(n+1)+2*n-4*n)==2
    for mixed,derivs in ((0,0),(1,1),(2,2)):
        assert 4-mixed+derivs==4
    assert sp.expand(2*k+2).subs(k,0)==2
    return {"ghost_cluster_tip_margin":2,
            "fixed_count_soft_bound":"delta**2*(1+abs(log(delta)))**2",
            "tadpole_first_switch":"logarithmic normalization",
            "tadpole_higher_counts":"strictly below total diagonal dimension",
            "full_tadpole_bridge_bound":"lambda**2*(1+abs(log(lambda)))**2"}


def check(phase):
    d=ROOT/"calculations"
    prior=json.loads((d/"canonical_so10_internal_massive_switch_v2/result.json").read_bytes())["checks"]
    assert prior["reference_combination"]=="300*log(M_Sigma/M_Phi)"
    tad=json.loads((d/"canonical_so10_uncut_ghost_boundary_v1/result_v2.json").read_bytes())["checks"]["actual_tadpole"]
    assert tad["actual_trace_compared_scalar_positions"]==328
    assert tad["trace_nonzero_by_blocks"]==[4,16,0]
    return {"routing":routing(phase),"scaling":scaling(),"actual_trace_positions":tad["trace_nonzero_by_blocks"],
            "reference_combination":prior["reference_combination"]}


if __name__=="__main__":
    run_worker(check,sys.argv[1])
