# The switched Lorentzian exterior inverse on weighted sources

## Actual ghost operator

Use the unprobed ordinary color-diagonal g0 exterior inverse in the
V875 compact connected master calculation and the V882 ordered source
chart. In real Minkowski coordinates P=−Box, with symbol
p0^2−|p_spatial|^2. The literal density is −partial C partial a.
Its difference from the Euler-normal reference is −Box(C a)/2
in C-before-a order. Switching and integrating by parts gives
−V C a, where V=Box sigma/2. The two LEFT Eulers are
E_a=(P+V)C and E_C=−(P+V)a. Thus for unswitched source-first j,

    C=G_sigma j_a,   a=−G_sigma j_C,
    G_sigma=(P+V+i0)^−1.

Keep the Feynman boundary, with outgoing spatial wave number for both
signs of the temporal Fourier variable. There is no rotation of the
switch test and no change of ghost ordering.

## Weighted Feynman sum at finite switch scale

Let rho=|x_spatial|, W=rho^−1 and let the unweighted L2 be over
spacetime. For eta>0 the partial temporal Fourier kernel of G_eta is

    −exp(i sqrt(tau^2+i eta)|x−y|)/(4 pi |x−y|),

with the square root in the upper half plane. Its modulus is bounded
by the Newton kernel N. Thus T_eta=W G_eta W has norm at most 4,
uniformly in tau and eta. Indeed the spatial Hardy inequality
||W f||²≤4||grad f||² follows by expanding
||grad f+x f/(2 rho²)||². It bounds W N W by factorizing the Laplace
inverse. A separate positive-kernel Schur test uses weight rho^−3/2.
The Newton angular average is 1/max(rho,s) and gives

    (W N W rho^−3/2)(rho)
      = rho^−1 [rho^−1 integral_0^rho s^−1/2 ds
                        + integral_rho^infty s^−3/2 ds]
      = 4 rho^−3/2.

For a dense set of spatial L2 tests smooth and compact away from
rho=0, the weighted kernels converge strongly at each tau by
pointwise kernel convergence and L2 domination by W N W |f|.
Uniform boundedness extends this convergence to all spatial L2.
Plancherel and dominated convergence in tau give a strong spacetime
operator limit T_0. This argument also covers tau=0.

Use a fixed smooth real b equal to one below zero and zero above one.
Set r²=t²+rho² and sigma_R=b(log(r/R)/ell). This is smooth, real,
compact and flat near zero. Direct radial differentiation gives

    r² V_R = (b''/(2 ell²)) (t²−rho²)/r²
                     − (2 b'/ell) t²/r².

Set B_R=rho² V_R. The factor rho² t²/r^4≤1/4 gives
||B_R||∞≤||b'||∞/(2 ell)+||b''||∞/(2 ell²), independently of R.
Choose ell with q=4 sup_R ||B_R||∞<1. For f=rho j, v=W u,
the exact exterior inverse has the convergent Neumann form

    v=(1+T_eta B_R)^−1 T_eta f.

In particular all exterior quadratic switch insertions on a single
ordinary ghost root are summed. Multiplication by B_R need not be
diagonal in tau. For smooth compact j at eta>0, V_R u=rho V_R v is
in unweighted L2 since rho V_R is bounded, so u coincides with the
ordinary resolvent solution by uniqueness for the self-adjoint
free Fourier multiplier plus the bounded real potential. The
strong weighted eta boundary at each fixed R follows from the
resolvent identity and the uniform Neumann estimate. The two
resulting roots can be paired against a compact bounded test
as locally L2 functions. This is a finite-R assertion.

## Joint limit for fixed sources and the moving test boundary

B_R is zero on r<R and is uniformly bounded. Hence B_R→0 strongly
on L2. For fixed f=rho j, let v_free=T_0 f and v_eta,R be the above
inverse. Then

    ||v_eta,R−v_free||
       ≤ (1−q)^−1 (||(T_eta−T_0)f|| + 4||B_R v_free||).

The right side tends to zero along every eta↓0, R→infty. This
qualifies the joint weighted strong exterior limit for a fixed
source, including separate ordered ghost orientations.

This estimate cannot evaluate the moving h_R profile in the V899
transition. In that comparison the rescaled source is
j^[R](y)=R^4 j(Ry), and ||rho j^[R]||_2=R||rho j||_2.
For nonzero source integral it tends to a point source. The bare
Feynman point-source kernel has a light-cone singularity away from
the tip and is not in the weighted solution L2 space on that cone.
For these real radial switches the cone coefficient of V is
−b'/(ell r²), generally nonzero. Thus multiplying the point-source
kernel by V does not provide the regular L2 forcing used in the
finite-R proof. In addition a test supported on r=O(R) can cost
O(R²) when the weighted product bound is converted to unweighted
roots. Neither strong fixed-source convergence nor the uniform
Neumann estimate justifies the full transition. The moving inner
thresholds remain a separate dependency.
