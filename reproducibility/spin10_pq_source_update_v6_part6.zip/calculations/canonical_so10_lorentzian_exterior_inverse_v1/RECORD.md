# V901 pre-execution contract

Derive the actual unprobed exterior ghost Feynman inverse for broad
real compact Lorentzian switches and weighted smooth compact sources.
Require exact sign and radial-potential checks, an independently
computed Newton Schur constant, strong positive-eta boundary and
a joint fixed-source strong limit. Bind the inherited ordered
source and exterior proof bytes. Explicitly test why rescaled delta
sources and moving transition profiles are beyond the estimate.
No new amplitude, source normalization, or scientific promotion.

Native 120 s, final 180 s including E4 cap 120 s, sampled private
8 GiB, 350 MiB launch commit floor, 8 MiB artifact, 32 MiB packet.
Require exact control replay, receipt and staged byte checks.
