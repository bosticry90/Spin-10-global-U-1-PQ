"""Exact controls for the real-spacetime exterior inverse."""

import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def scalar_route(phase):
    z, ell, d1, d2 = sp.symbols("z ell d1 d2", real=True)
    if phase == "native":
        # z=t^2/r^2. Apply the chain rule to F(log(r/R)/ell).
        wave_log_r = -4*z
        log_r_gradient_norm = 2*z - 1
        wave = (wave_log_r*d1/ell + log_r_gradient_norm*d2/ell**2)/2
        p = sp.symbols("p", positive=True)
        schur = (sp.integrate(p**(-sp.Rational(1, 2)), (p, 0, 1))
                 + sp.integrate(p**(-sp.Rational(3, 2)), (p, 1, sp.oo)))
    else:
        # Resolve the radial Hessian into radial and tangential eigenvalues.
        radial = d2/ell**2 - d1/ell
        tangent = d1/ell
        a = 2*z - 1
        wave = (a*radial + (-2-a)*tangent)/2
        # Let s=rho*q^2 in the two Newton radial integrals.
        q = sp.symbols("q", positive=True)
        schur = sp.integrate(2, (q, 0, 1)) + sp.integrate(2/q**2, (q, 1, sp.oo))
    assert sp.expand(wave - ((2*z-1)*d2/(2*ell**2) - 2*z*d1/ell)) == 0
    assert sp.simplify(wave.subs(z, sp.Rational(1, 2))) == -d1/ell
    spatially_weighted = sp.expand((1-z)*wave)
    maximum = sp.Rational(1, 4)
    assert sp.expand(maximum - z*(1-z)) == (z**2 - z + maximum)
    assert sp.factor(maximum - z*(1-z)) == (2*z - 1)**2/4
    assert sp.simplify(spatially_weighted.subs(z, sp.Rational(1, 2))) == -d1/(2*ell)
    assert schur == 4
    # Replacing the wave operator by the radial Euclidean Laplacian
    # would produce a nonzero extra b' term at t=0.
    assert sp.simplify(d1/ell + d2/(2*ell**2) + wave.subs(z, 0)) == d1/ell
    return {"spatial_schur_constant": 4, "cone_r2_V": "-b'/ell",
            "broad_q_bound": "2*||b'||/ell+2*||b''||/ell**2",
            "euclidean_substitution_rejected": True}


def left_sign(word, slot):
    return (-1)**word.index(slot)


def source_route():
    owner = ROOT / "calculations/canonical_so10_lorentzian_ghost_transition_v1/result.json"
    previous = json.loads(owner.read_bytes())["checks"]["source"]
    kinetic, ja, jc = sp.symbols("K j_a j_C")
    a, c = sp.symbols("a C")
    # Literal order C,a and source-first j_i,z_i.
    e_a = -left_sign(("C", "a"), "a")*kinetic*c
    e_c = -left_sign(("C", "a"), "C")*kinetic*a
    assert sp.solve(e_a + left_sign(("j_a", "a"), "a")*ja, c) == [ja/kinetic]
    assert sp.solve(e_c + left_sign(("j_C", "C"), "C")*jc, a) == [-jc/kinetic]
    assert previous["ordered_ghost_sign"] == -1
    return {"a_mean_sign": -1, "C_mean_sign": 1, "first_switch_Born_sign": -1}


def scale_route():
    r = sp.symbols("R", positive=True)
    # Squared source prefactor, spatial weight, spacetime Jacobian.
    source_norm_squared = r**8 * r**(-2) * r**(-4)
    assert sp.sqrt(source_norm_squared) == r
    return {"scaled_source_weighted_norm_factor": "R",
            "moving_test_unweighted_product_cost": "R**2",
            "Feynman_spatial_wave_number": "sqrt(tau**2+i*eta), Im>0"}


def check(phase):
    return {"radial": scalar_route(phase), "source": source_route(), "scale": scale_route()}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
