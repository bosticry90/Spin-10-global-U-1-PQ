# Weighted Lorentzian exterior inverse V901

For the actual switched ghost operator P+Box sigma/2, the spatial
Coulomb bound gives norm at most four for the inverse with one
inverse-radius weight on either side. The positive-imaginary-part
resolvent tends strongly to the weighted Feynman inverse. With a
sufficiently broad log-radial compact switch on real spacetime, the
weighted potential makes the full exterior series a contraction.
This gives the fixed-switch boundary for both ordinary ghost
source orientations and their local two-root product at fixed R.
It also gives a joint strong weighted limit back to the free
exterior inverse for fixed sources as R grows and eta decreases.

The moving transition test has a rescaled source whose weighted
L2 norm grows linearly with R. The limiting free point kernel
has a light-cone singularity, and the switched potential need
not vanish there. The present weighted estimate therefore cannot
replace the rescaled source by the point source or pass its
two-root product to a weak limit. The moving inner cut problem
is also open. The exact controls independently check the
radial derivative and Newton Schur integral within the same
action, conventions, and symbolic infrastructure.
