"""Check the full converted BB boundary and a literal massless log control."""

import importlib.util
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def load(name,file):
    p = ROOT/"calculations"/("canonical_so10_"+name)/file
    spec = importlib.util.spec_from_file_location(name,p)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def endpoints():
    # Actual massless powers are one and two. Larger j only improves this.
    for a in (1,2):
        d = 2*a-2
        assert all(1+j-a+max(d-2*j,0)>=0 for j in range(8))
    assert 1+0-2+max(0-2*0,0)==-1
    Q,M,x = sp.symbols("Q M x",positive=True)
    for a in (1,2):
        for b in (1,2,3):
            value = 1/(Q**a*(Q+M)**b)
            terms = sp.apart(value,Q)
            assert sp.cancel(terms-value)==0
            assert sp.limit(Q**a*terms,Q,0)==M**(-b)
    # A numerator-safe mixed bubble moment has a nonzero analytic slope.
    assert sp.integrate((1-x)**2/M,(x,0,1))==1/(3*M)
    assert sp.integrate(sp.log(x),(x,0,1))==-1


def actual(phase):
    owner = load("scalar_source_transport_v2","source_transport.py")
    _,_,_,bracket,_,_ = owner.inputs(phase)
    f = {(i,a,b):z for (a,b),pairs in bracket.items() for i,z in pairs}
    ad = {a:sp.SparseMatrix(45,45,{(i,j):z for (i,h,j),z in f.items() if h==a}) for a in range(45)}
    M = sp.diag(*([0]*12+[1]*33),cls=sp.SparseMatrix)
    CH = (-sum((ad[a]**2 for a in range(12)),sp.SparseMatrix(45,45,{}))).applyfunc(sp.expand)
    total = (-sum((ad[a]**2 for a in range(45)),sp.SparseMatrix(45,45,{}))).applyfunc(sp.expand)
    assert total==8*sp.eye(45)
    r = -ad[1]
    rows = json.loads((ROOT/"calculations/canonical_so10_current_background_reference_bridge_v1/result_a.json").read_bytes())["compared"]["twelve_current_homogeneous_carriers"][1]
    assert {(i-553,j-553):sp.sympify(v) for i,j,v in rows if 553<=i<598 and 553<=j<598}==r.todok()
    assert r[20,33]==0 and sp.expand((CH*r)[20,33])==sp.Rational(1,10)
    assert CH[20,23]==-sp.Rational(1,5)
    for b in range(12,45):
        cmm = -sp.expand(sp.trace(M*ad[20]*M*ad[b]))
        assert cmm==(8*M-2*CH)[20,b]
    I_log,D_log = -sp.Rational(3,4),sp.Rational(1,12)
    core_log = 2*CH*(I_log+D_log)+(8*M-2*CH)*D_log
    assert core_log[20,23]==sp.Rational(3,10)
    value = sp.expand((core_log*r)[20,33])
    assert value==-sp.Rational(3,20)

    # The Lorentzian ordered projection is independent of the color choice.
    ref = load("massive_background_feynman_boundary_v1","massive_background_feynman_boundary.py")
    assert ref.cone_projection(sp.sqrt(10)/4)!=0
    return value


def normal():
    z = sp.Symbol("z",positive=True)
    for n in range(1,7):
        exact = sp.diff(sp.log(z)**2,z,n)
        expected = 2*(-1)**(n-1)*sp.factorial(n-1)*(sp.log(z)-sp.harmonic(n-1))/z**n
        assert sp.simplify(exact-expected)==0
    assert sp.integrate(sp.log(z)**2,(z,0,1))==2
    j = sp.Symbol("j",integer=True,nonnegative=True)
    geometric = sp.summation(sp.Rational(1,4)**j,(j,0,sp.oo))
    weighted = sp.summation(j*sp.Rational(1,4)**j,(j,0,sp.oo))
    assert (geometric,weighted)==(sp.Rational(4,3),sp.Rational(4,9))

    x,e = sp.symbols("x e",positive=True)
    assert sp.simplify(sp.diff(sp.atan(x/e),x)-e/(x*x+e*e))==0
    assert sp.atan(1)==sp.pi/4
    primitive = sp.log(x*x+e*e)/2
    assert sp.diff(primitive,x)==x/(x*x+e*e)
    lower = sp.pi*(primitive.subs(x,1)-primitive.subs(x,e))/2
    assert sp.limit(lower,e,0,dir="+")==sp.oo


def check(phase):
    endpoints()
    value = actual(phase)
    normal()
    return {"massive_endpoint_safe_with_actual_numerator":True,
            "constant_vector_mass_negative_exponent":-1,
            "transverse_massless_log_color_over_P":str(value),
            "common_sign_logarithmic_dyadic_bound_verified":True,
            "opposite_sign_imaginary_log_diverges":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
