# V997 pre-execution contract

Freeze V996, V994, V884, V880, V986–V988
and actual V869/V788/V879 carrier evidence.
Classify the already converted unshifted
ordinary 643-field BB two-port at one loop
for each admitted fixed finite chain.
Keep all physical numerator factors.
Derive a mixed-mass endpoint bound and
the same-sign Lorentzian shell estimate
with an independent post-background
bridge momentum. Require a nonzero
actual massless logarithm projection
and an opposite-sign failure control.
The target is the converted local
boundary, with no real-time heat
prelimit or weak adiabatic claim.

Native 120 s, final 180 s including E4
cap 120 s, 8 GiB sampled private,
350 MiB launch floor, 8 MiB artifact
and 32 MiB packet. No authority change.
