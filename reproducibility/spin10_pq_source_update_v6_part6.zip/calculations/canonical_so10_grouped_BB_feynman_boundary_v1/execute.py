"""Freeze and review the V997 evidence in the active D: workspace."""

import ast
import json
import os
import subprocess
import sys
import threading
import time
from hashlib import sha256
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CONTROL = Path("D:/Codex-Research/ToE-Next/research-control-records/grouped-bb-feynman-boundary-v1-2026-11-09")
PK = ROOT / "tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1"
BASE = "af4ce88abc441741a5946221a263fc34fa3df2d4"
NAV = ["README.md", "docs/COMMON_RESTORATION_CAMPAIGN_V1.md", "docs/RESEARCH_EXECUTION_HANDOFF_V997.md"]


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def save(name, data):
    raw = (json.dumps(data, sort_keys=True) + "\n").encode()
    if len(raw) > 8 * 1024**2:
        name += ".COMPLETE_OVERFLOW_NOTPASS"
    for folder in (HERE, CONTROL):
        with (folder / name).open("xb") as f:
            f.write(raw)
    assert len(raw) <= 8 * 1024**2


def prepare(phase):
    assert git("rev-parse", "HEAD").decode().strip() == BASE
    assert not git("diff", "--cached", "--name-only")
    if phase == "native":
        assert not git("diff", "--name-only", "HEAD")
        CONTROL.mkdir(exist_ok=False)
        with (CONTROL / "old_git_tree.txt").open("xb") as f:
            f.write(git("ls-tree", "-r", "HEAD"))
        snapshots = ("RECORD.md", "PROOF.md", "grouped_bb_feynman_boundary.py", "execute.py")
        owners = {
            "scalar_source_transport_v2": ("source_transport.py", "PROOF.md", "result.json", "validation_receipt.json"),
            "linear_nonminimal_transport_v1": ("nonminimal_transport.py", "PROOF.md", "validation_receipt.json"),
            "joint_nonlinear_source_span_v2": ("joint_nonlinear.py", "PROOF.md", "validation_receipt.json"),
            "ordinary_derivative_ghost_companion_v1": ("PROOF.md", "result.json", "validation_receipt.json"),
            "light_edge_metric_completion_v1": ("PROOF.md", "result.json", "validation_receipt.json"),
            "joint_contact_gauge_square_v1": ("PROOF.md", "result.json", "validation_receipt.json"),
            "isolated_contact_metric_defect_v1": ("PROOF.md", "result.json", "validation_receipt.json"),
            "derivative_ghost_mass_support_v1": ("PROOF.md", "validation_receipt.json"),
            "light_antighost_contact_pair_v1": ("PROOF.md", "result.json", "validation_receipt.json"),
            "regulator_free_inverse_g1_recovery_v1": ("PROOF.md", "native_inverse.json.gz",
                                                     "replay_inverse.json.gz", "validation_receipt.json"),
            "forced_gauge_fixing_companion_v1": ("PROOF.md", "result.json", "validation_receipt.json"),
            "local_ghost_compensation_v1": ("PROOF.md", "validation_receipt.json"),
            "gauge_scalar_seagull_residue_v1": ("seagull_residue.py", "validation_receipt.json"),
            "unprobed_compact_all_coupling_v1": (
                "native_full_current.json.gz", "replay_full_current.json.gz", "validation_receipt.json"),
            "physical_current_input_recovery_g1_v1": (
                "PROOF.md", "validation_receipt.json", "native_v2_coefficients.json.gz", "replay_v4_coefficients.json.gz"),
        }
        owners.update({'mixed_gauge_source_triangle_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'light_edge_metric_completion_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'combined_gauge_color_transport_v2': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'regulator_free_inverse_g1_recovery_v1': ['PROOF.md', 'native_inverse.json.gz', 'replay_inverse.json.gz', 'validation_receipt.json']})
        owners.update({'lower_gauge_source_companion_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'compact_mixed_source_transport_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'heat_mellin_matching': ['DERIVATION.md']})
        owners.update({'lower_gauge_source_companion_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'background_seagull_contacts_v1': ['PROOF.md', 'validation_receipt.json']})
        owners.update({'ordinary_scalar_bubble_span_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'linear_nonminimal_transport_v1': ['PROOF.md', 'validation_receipt.json'], 'lower_gauge_source_companion_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'mixed_scalar_color_companion_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'linked_scalar_kinetic_bubble_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'regulator_free_inverse_g1_recovery_v1': ['PROOF.md', 'native_inverse.json.gz', 'replay_inverse.json.gz', 'validation_receipt.json'], 'heat_mellin_matching': ['DERIVATION.md']})
        owners.update({'ordinary_ghost_kinetic_companion_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'lower_gauge_source_companion_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'mixed_scalar_color_companion_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'scalar_ghost_reference_weights_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'separated_scalar_triangle_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'mass_tag_transport_v1': ['PROOF.md', 'validation_receipt.json']})
        owners.update({'joint_contact_gauge_square_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'mixed_gauge_source_triangle_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'mixed_scalar_color_companion_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'compact_plateau_restriction_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'master_mass_tangent_v2': ['PROOF.md', 'validation_receipt.json']})
        owners.update({'compact_mixed_reference_span_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'lower_gauge_source_companion_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'compact_scalar_reference_complement_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'light_mixed_reference_completion_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'massive_scalar_insertion_transport_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'scalar_plateau_sector_transport_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'linear_nonminimal_transport_v1': ['PROOF.md', 'validation_receipt.json']})
        owners.update({'mixed_first_switch_carrier_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'linked_scalar_kinetic_bubble_v1': ['linked_scalar.py', 'PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'linked_scalar_first_switch_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'massive_scalar_insertion_transport_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'scalar_sector_finite_match_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'physical_current_input_recovery_g1_v1': ['PROOF.md', 'validation_receipt.json', 'native_v2_coefficients.json.gz', 'replay_v4_coefficients.json.gz', 'native_v2_action.json.gz', 'replay_v4_action.json.gz'], 'graded_causal_qap': ['DERIVATION.md', 'RESULT.md'], 'causal_wick_bridge': ['DERIVATION.md', 'RESULT.md']})
        owners.update({'scalar_causal_conversion_check_v3': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'mixed_gauge_source_triangle_v1': ['mixed_triangle.py', 'PROOF.md', 'result.json', 'validation_receipt.json'], 'mixed_first_switch_carrier_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'gauge_plateau_sector_transport_v2': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'scalar_causal_conversion_check_v3': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'scalar_sector_finite_match_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'scalar_ghost_reference_weights_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'broken_singlet_mass_contrast_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'ghost_switch_transition_v1': ['PROOF.md', 'validation_receipt.json'], 'collapsed_profile_heat_offset_v2': ['PROOF.md', 'validation_receipt.json']})
        owners.update({'auxiliary_switch_inverse_pair_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'gauge_plateau_sector_transport_v2': ['gauge_plateau.py', 'PROOF.md', 'result.json', 'validation_receipt.json'], 'compact_mixed_source_transport_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'gauge_first_switch_rank_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'marked_regulator_parent_g1_v1': ['PROOF.md', 'validation_receipt.json'], 'gaussian_current_reduction_g1_v1': ['PROOF.md', 'validation_receipt.json']})
        owners.update({'auxiliary_regulator_switch_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'gauge_first_switch_rank_v1': ['first_switch_rank.py', 'PROOF.md', 'result.json', 'validation_receipt.json'], 'ghost_switch_transition_v1': ['PROOF.md', 'validation_receipt.json']})
        owners.update({'gauge_switch_cubic_profile_v2': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'ghost_source_finite_comparison': ['DERIVATION.md', 'RESULT.md'], 'internal_gauge_switch_v1': ['PROOF.md', 'validation_receipt.json']})
        owners.update({'ghost_source_local_width_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'gauge_first_switch_rank_v1': ['first_switch_rank.py', 'PROOF.md', 'result.json', 'validation_receipt.json'], 'gauge_plateau_sector_transport_v2': ['gauge_plateau.py', 'PROOF.md', 'validation_receipt.json'], 'auxiliary_regulator_switch_v1': ['PROOF.md', 'validation_receipt.json']})
        owners.update({'regulator_second_switch_profile_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'gauge_switch_cubic_profile_v2': ['cubic_switch_profile.py', 'PROOF.md', 'result.json', 'validation_receipt.json'], 'gauge_first_switch_rank_v1': ['first_switch_rank.py', 'PROOF.md', 'validation_receipt.json'], 'gauge_plateau_sector_transport_v2': ['gauge_plateau.py', 'PROOF.md', 'validation_receipt.json']})
        owners.update({'regulator_cubic_switch_profile_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'lower_gauge_source_companion_v1': ['PROOF.md', 'validation_receipt.json'], 'ghost_source_local_width_v1': ['PROOF.md', 'validation_receipt.json'], 'heat_mellin_matching': ['DERIVATION.md', 'RESULT.md']})
        owners.update({'longitudinal_heat_transfer_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'auxiliary_regulator_switch_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'regulator_second_switch_profile_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'regulator_cubic_switch_profile_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'ghost_source_local_width_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'transverse_switch_support_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'longitudinal_heat_transfer_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'nonlinear_source_insertion_extension_v1': ['PROOF.md', 'validation_receipt.json'], 'unprobed_compact_all_coupling_v1': ['PROOF.md', 'native_full_current.json.gz', 'replay_full_current.json.gz', 'validation_receipt.json'], 'heat_mellin_matching': ['DERIVATION.md', 'RESULT.md']})
        owners.update({'relative_profile_functional_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'current_background_reference_bridge_v1': ['PROOF.md', 'result_a.json', 'result_b.json', 'validation_receipt.json'], 'background_reference_normalization': ['DERIVATION.md', 'RESULT.md', 'validation_receipt_v6.json'], 'gauge_first_switch_rank_v1': ['first_switch_rank.py', 'validation_receipt.json']})
        owners.update({'background_profile_reference_v2': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'compact_switched_master_domain_v1': ['PROOF.md', 'validation_receipt.json'], 'cartan_generator_residual_g1_v1': ['PROOF.md', 'v2_fixed_ward_and_old_affine_endpoints.json.gz', 'validation_receipt.json'], 'ghost_switch_transition_v1': ['PROOF.md', 'validation_receipt.json'], 'connected_marked_master_v1': ['PROOF.md', 'validation_receipt.json']})
        owners.update({'marked_profile_functional_v3': ['marked_profile_functional.py', 'PROOF.md', 'result.json', 'validation_receipt.json'], 'marked_regulator_parent_g1_v1': ['PROOF.md', 'validation_receipt.json'], 'regulator_free_inverse_g1_recovery_v1': ['PROOF.md', 'native_inverse.json.gz', 'replay_inverse.json.gz', 'validation_receipt.json']})
        owners.update({'marked_regulator_profile_v2': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'marked_profile_functional_v3': ['marked_profile_functional.py', 'PROOF.md', 'validation_receipt.json'], 'connected_marked_master_v1': ['PROOF.md', 'validation_receipt.json'], 'causal_one_loop_sewing': ['DERIVATION.md', 'RESULT.md', 'validation_receipt.json']})
        owners.update({'relative_profile_forest_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'joint_compact_background_geometric_v1': ['RESULT.md', 'validation_receipt.json'], 'current_background_reference_bridge_v1': ['PROOF.md', 'result_a.json', 'validation_receipt.json'], 'background_profile_reference_v2': ['PROOF.md', 'validation_receipt.json'], 'marked_profile_functional_v3': ['PROOF.md', 'validation_receipt.json'], 'marked_regulator_profile_v2': ['PROOF.md', 'validation_receipt.json']})
        owners.update({'affine_profile_regulator_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'current_background_reference_bridge_v1': ['PROOF.md', 'result_a.json', 'result_b.json', 'validation_receipt.json'], 'background_profile_reference_v2': ['PROOF.md', 'validation_receipt.json'], 'heat_mellin_matching': ['DERIVATION.md']})
        owners.update({'covariant_profile_first_edge_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'ordered_multiheat_uv_log': ['DERIVATION.md', 'validation_receipt.json'], 'joint_born_ir_trace_domain': ['DERIVATION.md', 'validation_receipt.json'], 'current_background_reference_bridge_v1': ['PROOF.md', 'result_a.json', 'result_b.json', 'validation_receipt.json'], 'gauge_plateau_sector_transport_v2': ['gauge_plateau.py', 'validation_receipt.json']})
        owners.update({'covariant_relative_conversion_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'covariant_marked_regulator_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'broken_singlet_mass_contrast_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'transverse_scalar_mass_master_v3': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'explicit_contact_metric_v2': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'transverse_gauge_metric_master_v2': ['transverse_gauge_metric_master.py', 'PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'unequal_gauge_metric_master_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'covariant_marked_regulator_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'mixed_background_edge_finite_v1': ['mixed_background_edge_finite.py', 'PROOF.md', 'result.json', 'validation_receipt.json'], 'unprobed_compact_all_coupling_v1': ['native_full_current.json.gz', 'replay_full_current.json.gz', 'validation_receipt.json', 'PROOF.md']})
        owners.update({'background_ABB_finite_sum_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'background_ABB_geometric_cutoff_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'relative_profile_forest_v1': ['relative_profile_forest.py', 'PROOF.md', 'result.json', 'validation_receipt.json']})
        owners.update({'covariant_background_forest_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'unprobed_compact_all_coupling_v1': ['native_full_current.json.gz', 'replay_full_current.json.gz', 'PROOF.md', 'validation_receipt.json']})
        owners.update({'local_affine_second_cutoff_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'connected_marked_master_v1': ['marked.py', 'PROOF.md', 'result.json', 'validation_receipt.json'], 'augmented_metric_lift_v1': ['tensor_0.json.gz', 'tensor_6.json.gz', 'tensor_7.json.gz', 'validation_receipt.json'], 'joint_common_family_applicability_v1': ['native_complete_full_background_extension.json.gz', 'replay_complete_full_background_extension.json.gz', 'validation_receipt.json']})
        owners.update({'background_marked_connected_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'covariant_background_forest_v1': ['covariant_background_forest.py', 'PROOF.md', 'validation_receipt.json'], 'uncut_connected_infrared_v1': ['PROOF.md', 'RESULT.md', 'validation_receipt_v3.json'], 'uncut_vector_boundary_v1': ['PROOF.md', 'RESULT.md', 'validation_receipt_v2.json']})
        owners.update({'uncut_background_bridge_boundary_v1': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'uncut_local_common_primitive_v1': ['PROOF.md', 'RESULT.md', 'validation_receipt.json']})
        owners.update({'uncut_background_core_boundary_v2': ['PROOF.md', 'result.json', 'validation_receipt.json'], 'compact_direct_overlap_v2': ['PROOF.md', 'RESULT.md', 'validation_receipt.json'], 'phi_switching_limit_v1': ['PROOF.md', 'RESULT.md', 'validation_receipt.json']})
        owners.update({'massive_background_feynman_boundary_v1': ['massive_background_feynman_boundary.py', 'PROOF.md', 'result.json', 'validation_receipt.json'], 'unequal_gauge_metric_master_v1': ['PROOF.md', 'result.json', 'validation_receipt.json']})
        names = {"AGENTS.md", "CHARTER.md", "project_state.json",
                 "docs/RESEARCH_EXECUTION_HANDOFF_V996.md",
                 "calculations/canonical_so10_causal_one_loop_sewing/DERIVATION.md",
                 "calculations/canonical_so10_causal_one_loop_sewing/RESULT.md",
                 "calculations/canonical_so10_mass_tag_transport_v1/PROOF.md"}
        names.add((PK / "source_convention_control.py").relative_to(ROOT).as_posix())
        names.update(("calculations/canonical_so10_original_Ja_ghost_bubble/algebra.py",
                      "calculations/canonical_so10_intrinsic_full_source_descent/coefficient_ring.py"))
        for path in ("export_a10_e5_antighost_vector.py",
                     "frozen_a10_physical_reconciliation/full_primary.json",
                     "frozen_a10_physical_reconciliation/full_replay.json"):
            names.add((PK / path).relative_to(ROOT).as_posix())
        for owner, paths in owners.items():
            names.update(f"calculations/canonical_so10_{owner}/{path}" for path in paths)
    else:
        assert phase == "validation"
        assert set(git("diff", "--name-only", "HEAD").decode().splitlines()) == set(NAV[:2])
        for name, backup in zip(NAV[:2], ("README_before_final.bytes", "campaign_before_final.bytes")):
            assert (CONTROL / backup).read_bytes().replace(b"\r\n", b"\n") == git("show", "HEAD:" + name)
        first = read(HERE / "preparation_native.json")
        for name, expected in first["sha256"].items():
            assert digest(ROOT / name) == expected, name
        names = set(first["sha256"]) | set(NAV) | {"docs/LOCAL_RESEARCH_CONVENTIONS_V1.md"}
        snapshots = ("RESULT.md",)
    for name in snapshots:
        raw = (HERE / name).read_bytes()
        if name.endswith(".py"):
            ast.parse(raw)
        with (HERE / (name + ".source.txt")).open("xb") as f:
            f.write(raw)
    names.update(path.relative_to(ROOT).as_posix() for path in HERE.iterdir() if path.is_file())
    save(f"preparation_{phase}.json", {
        "base_HEAD": BASE, "sha256": {name: digest(ROOT / name) for name in sorted(names)},
        "scientific_acceptance": "NOT_PERFORMED",
        "limits": {"seconds": 120 if phase == "native" else 180, "e4_seconds": 120,
                   "sampled_private_bytes": 8 * 1024**3, "minimum_available_commit_bytes": 350 * 1024**2,
                   "artifact_bytes": 8 * 1024**2, "packet_bytes": 32 * 1024**2},
    })


def run_worker(check, phase):
    started = time.perf_counter()
    prep = read(HERE / f"preparation_{phase}.json")
    timer = threading.Timer(prep["limits"]["seconds"], lambda: os._exit(124))
    timer.daemon = True
    timer.start()
    assert git("rev-parse", "HEAD").decode().strip() == BASE == prep["base_HEAD"]
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    if phase == "native":
        save("result.json", {"execution_state": "COMPLETED", "checks": check("native")})
        print("STAGE grouped BB Feynman boundary controls checked", flush=True)
    else:
        review(check, prep, started)
    timer.cancel()


def review(check, prep, started):
    assert not git("diff", "--cached", "--name-only")
    assert git("ls-tree", "-r", "HEAD") == (CONTROL / "old_git_tree.txt").read_bytes()
    for name in ("preparation_native.json", "capture_native.json", "result.json"):
        assert (HERE / name).read_bytes() == (CONTROL / name).read_bytes()
    cap = read(HERE / "capture_native.json")
    assert cap["calculation_completed"] and cap["post_run_observations_qualified"]
    for source in HERE.glob("*.source.txt"):
        assert source.read_bytes() == (HERE / source.name.removesuffix(".source.txt")).read_bytes()
    owners = sorted(n for n in prep["sha256"] if "validation_receipt" in Path(n).name and n.endswith(".json"))
    for name in owners:
        owner = read(ROOT / name)
        if "execution_state" in owner:
            assert owner["execution_state"] == "COMPLETED", name
        else:
            assert owner["status"].startswith("PASS_BOUNDED_"), name
    result = read(HERE / "result.json")
    assert result["execution_state"] == "COMPLETED"
    checks = result["checks"]
    assert checks == check("replay")
    assert checks["transverse_massless_log_color_over_P"] == "-3/20"
    assert checks["common_sign_logarithmic_dyadic_bound_verified"]
    assert checks["opposite_sign_imaginary_log_diverges"]
    print("STAGE grouped BB Feynman boundary replay agrees", flush=True)

    command = [sys.executable, "-B", "tools/research_check.py", "e4", "--historical-context",
               "D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4"]
    try:
        e4 = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=120)
    except subprocess.TimeoutExpired as err:
        save("e4_timeout.json", {"command": command, "state": "INCOMPLETE_TIMEOUT",
                                 "stdout": (err.stdout or b"").decode("utf-8", errors="replace"),
                                 "stderr": (err.stderr or b"").decode("utf-8", errors="replace")})
        raise
    save("e4_capture.json", {"exit_code": e4.returncode, "stdout": e4.stdout, "stderr": e4.stderr})
    events = [json.loads(line) for line in e4.stdout.splitlines() if line.strip()]
    steps = [event for event in events if event.get("event") == "step_finished"]
    exits = [event["exit_code"] for event in steps]
    assert e4.returncode == 0 and exits == [0, 0, 0, 0, 0, 2]
    custody = next(event for event in steps if event["step"] == "historical_custody")
    assert custody["stdout"].count("RECORDED_DIGEST_UNRESOLVED:") == 7
    hist = git("show", "ef70f255a667b9a81e37b344dc78967ada4ed896:README.md")
    assert sha256(hist).hexdigest() == "4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792"
    assert (ROOT / "README.md").read_bytes().replace(b"\r\n", b"\n").endswith(hist)
    state = digest(ROOT / "project_state.json")
    assert state == "d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8"
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    files = [p for p in HERE.iterdir() if p.is_file()] + [ROOT / name for name in NAV]
    save("validation_receipt.json", {"base_HEAD": BASE, "execution_state": "COMPLETED",
         "evidence_validation": "PASS_BOUNDED_GROUPED_BB_FEYNMAN_BOUNDARY",
         "scientific_acceptance": "NOT_PERFORMED", "state_sha256": state,
         "E4_step_exits": exits, "historical_custody": "SEVEN_UNRESOLVED_NOTPASS", "owner_receipts": owners,
         "checks": checks,
         "files_excluding_pending_receipt_capture": {p.relative_to(ROOT).as_posix(): digest(p) for p in files},
         "elapsed_after_imports": time.perf_counter() - started})


def main():
    phase = sys.argv[1]
    prepare(phase)
    sys.path.insert(0, str(PK))
    from export_a10_e5_antighost_vector import capture

    report = capture([sys.executable, "-B", str(HERE / "grouped_bb_feynman_boundary.py"), phase])
    save(f"capture_{phase}.json", report)
    print(report["stdout_and_stderr"], end="")
    assert report["calculation_completed"] and report["post_run_observations_qualified"]
    assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file()) <= 32 * 1024**2


if __name__ == "__main__":
    main()
