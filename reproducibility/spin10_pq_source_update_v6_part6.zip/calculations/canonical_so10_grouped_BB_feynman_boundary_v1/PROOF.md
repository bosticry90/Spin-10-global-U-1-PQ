# Local Lorentzian boundary of the complete converted BB group

Retain the V884 ordinary unshifted 643-field
BB two-port, the V991 matched UV subtraction
and the V994 first-A insertion on one exit.
Keep zero mean, A=0 in the loop core, and
the admitted fixed finite constant chains.
Use the already converted core. The tied
inner momentum is p, the independent outer
momentum is q, and A transfers q-p.
No statement about the unconverted
Lorentzian heat profiles is used.

After the V880 constant chains, the core
is a seagull or two-cubic bubble. The
massless ordinary line is a rational
matrix with denominator q² or (q²)^2,
including its actual momentum numerator.
The order-one mixed inverse retains its
one numerator. A pair of auxiliary–scalar
attachments adds q_mu q_nu/(q²)^2 with
positive-mass factors. Thus at a massless
node of denominator degree a, the numerator
in its own loop momentum has degree
d at least 2a-2. The invariant scalar mass
insertions change only the positive-mass
factors. This bound is nodewise in the
literal ordered products and is retained
before the Lorentz contraction.

Combine multiple positive-mass factors
at one node by their finite simplex.
The resulting mass is a positive convex
combination. For a node with both massless
and positive-mass factors, partial fraction
only those denominators. The elementary
difference 1/x-1/(x+M) over M and its
finite recurrences suffice. It keeps the
numerator and never increases the massless
power. All mass inverses here are of the
positive reference combination. No
division by a mass difference is needed.
This also covers equal reference masses.

For a mixed bubble write the two
denominators Q^a and (K+M)^b with
Q=l², K=(l+p)², z=p_E². With parameter
x for the massive denominator, the
shift l=ell-x p gives
Delta=x(M+(1-x)z). At x=0 an even
loop monomial of degree 2j retains at
least x^max(d-2j,0). Extra momentum
factors can improve this estimate.
The parameter weight x^(b-1) and
radial moment Delta^(2+j-a-b) give
the net endpoint exponent

    1+j-a+max(d-2j,0) >= 0.

For j>=a-1 the first part is nonnegative.
For j<a-1 the actual lower bound
d>=2a-2 supplies at least a-1-j.
Thus logs of x and the small dimensional
jets remain integrable. M+(1-x)z is
uniformly away from zero on smaller
subthreshold disks |z|<M. The other
endpoint is ordinary. The parameter
integrals and finite mass derivatives
therefore give analytic tensors near
zero. Dropping the numerator for a
double massless pole would give an
x^-1 endpoint already at j=0.
Two positive masses are analytic
by the same positive simplex bound.

For two massless nodes the same endpoint
argument applies at both ends, with
Delta=x(1-x)z. For each homogeneous
numerator the radial integrals give
powers of z and at most one log z.
There is no additional endpoint
dimensional pole because the actual
numerators make the integrals locally
integrable. The one-loop UV pole is
simple. V884's two-cubic numerator
budget gives momentum degree at least
two. Partial fraction never worsens
that budget for a two-massless term.
Lorentz covariance and evenness give
z times the metric and p_mu p_nu
times nonnegative powers of z, each
with a possible single log. A
seagull is local. V884's common
converted constant cancellation,
including the dimension jet, makes
the complete remaining analytic
tensor vanish at order zero.
It is therefore O(p²) at the tip.
This form is derived from the
actual loop structure rather than
from the Euclidean bound alone.

## Common Feynman boundary and its actual sign control

In the Lorentzian boundary put
P=p² with signature (+---), and
continue z as -P-i e. Retain the
real tensor numerators. The two
tied inner inverses and the core
logarithm use the same absorption
e>0. The independent q line has
its Feynman sign and need not use
the same size of absorption.
All actual longitudinal and mixed
numerators remain. Even without
transversality, the grouped core
supplies two momentum powers.
The worst combined p scaling
is order minus two with a log.

On a nonzero light-cone patch use
P as normal coordinate. On a unit
annulus the powers of (P+i e)^-1
are uniformly bounded distributions
as in V996. For n>=1, use

    d^n log²(z)/dz^n
      = 2 (-1)^(n-1) (n-1)! z^-n
          [log(z)-H_(n-1)].

With z=P+i e and
log(-P-i e)=log(P+i e)-i pi,
this reduces the log times a
pole to derivatives of uniformly
locally integrable log² and
ordinary same-sign pole powers.
For absorption larger than a unit
annulus scale, the original
rational-log expression is
uniformly bounded directly.
On dyadic shells |p|~r and
|q|~s, the bounded seminorm
including measures is
C r²(1+|log r|)s².
The independent q coordinate
allows the tensor product.
This sum converges at the
joint tip. The analytic
massive and mixed terms use
the V996 log-free bound.

A literal massless test uses
the M-exterior transverse
metric at eta_H=xi=intrinsic=0.
Keep the pure Yang-Mills and
ghost loop and the BB Lambda
cross term. The pure YM log
has color proportional to
the identity. The surviving
ghost loop has color
8 I_M-2 C_H. The mixed
term has color 2 C_H and
kernel P I_T-A+D in the
notation of V986/V987.
The coefficient of log z
for D/P is +1/12 and for
I_T is -3/4. A is local.
The C_H part of the total
transverse log matrix is
therefore -3 C_H/2 in
g²/(16 pi²) units. This
matches the actual
V986 off-diagonal
(20,23) coefficient.

Choose the ordinary exit
B20 and a light color-1
background ending at
Lambda33. The literal
carrier r_1[20,33] is zero
and (C_H r_1)[20,33]=1/10.
Thus the identity part
cannot enter this test.
The transverse logarithm
has nonzero stripped
coefficient -3/20.
Use V996's cone patch
p=(1,1,0,0), q=e1 and
A polarization e2 with
the smooth transverse
ordinary polarization.
The ordered Weyl B-B
block contracted with
the outer mixed q
inverse has nonzero
projection there.
The actual tied
normal factor is a
nonzero multiple of

    P log(-P-i e)/(P+i e)^2.

Under opposite signs
on the two tied
denominators the
denominator becomes
P²+e². With an even
nonnegative normal
test equal to one
near zero, the odd
constant part of the
log's imaginary angle
integrates to zero.
The remaining part
is proportional to

    -2 integral_0^R
          P arctan(P/e)/(P²+e²) dP.

On e<=P<=R the angle
is at least pi/4.
The imaginary
magnitude diverges
logarithmically.
The common sign
instead has the
finite normal
distribution just
proved. Thus an
actual massless
coefficient detects
a stronger failure
than the missing
massive delta
contact of V996.

This qualifies the
local boundary of
the already converted
grouped ordinary
BB placement.
A simultaneous
real-time Euclidean
heat continuation,
a switching limit
and the other
source/marked
domains are separate.
Both routes share
the action and
symbolic software.
