# V997 result

The complete converted ordinary BB group has
a local common-sign Feynman boundary with one
background insertion on an exterior bridge.
Actual momentum numerators make the mixed-mass
parameter endpoints integrable. The purely
massless terms have degree at least two and
carry at most one logarithm. The grouped
constant vanishes in the inherited conversion.

The literal B20 to Lambda33 color projection
has a nonzero massless logarithm. Common
Feynman signs give a finite logarithmic
normal distribution and a summable joint
dyadic bound. Opposite signs give an
imaginary logarithmic divergence in
the same actual projection.

This is a boundary of the already converted
group. The finite heat limits and weak
adiabatic normalization remain separate.
