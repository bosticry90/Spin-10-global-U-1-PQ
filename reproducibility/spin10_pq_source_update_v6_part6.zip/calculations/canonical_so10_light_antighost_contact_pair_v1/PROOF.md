# A causal two-vertex direction and its fixed source partner

In the V879 current chart set the background to zero and
take xi^0. The ordinary monomials containing a light
antighost are the g0 kinetic bilinear and g1 B C partial
a_H. The terms with one light gauge source and otherwise
ordinary fields are g0 J_B^H partial C_H and g1 B C J_B^H.
Once the specified spectator is supplied, a bilinear has
just one ordinary port. It cannot be a proper cycle vertex.

The literal cubic tables coincide after replacing the
spectator partial_mu a_H by J_B^H_mu in the same odd
order. This covers 1,624 rows, with 1,336 in the broken
B,C pair. A source spectator has the same parity and
engineering dimension as partial a_H. The COS1 fixed
contracted-kernel rule multiplies the extended kernel by
the remaining field or source. Therefore the two
coefficients cannot be varied separately by assigning
different extensions to these spectators. This statement
concerns the paired proper or graph-supported contact
kernels. Reducible products, independent source
renormalizations and modified action inputs are separate.

For a concrete two-vertex direction use the g1 cubic
and the g2 B B C a vertex, joined by a B edge and a
C-to-a edge. At spatial index 1 and light spectator h=1,
the external pair (B,C)=(30,23) gives +1/20 for each of
the two nonzero internal color choices (19,29),(24,34).
The exchanged external pair gives -1/20 for each
reversed internal pair. The quartic carries only broken
antighosts, so it cannot carry the light spectator.
The ordinary and source contractions have the same
literal current-order result.

The B and ghost lines each have leading short-distance
degree two. Their product has scaling degree four in
the four relative dimensions, so a local delta is an
extension direction for the contracted kernel. The
displayed factors omit its common phase and arbitrary
extension coefficient. Moving the derivative from a to
C at constant B gives the antisymmetric factor -1/10.
Taking the left odd source derivative in C-first order
gives the same sign for the associated gauge driver.
A contact in this direction changes that driver whenever
it supplies the corresponding ordinary V933 coefficient.

V934 excludes the scalar mass from the bare proper
graph. A fixed-anchor finite coefficient has independent
normalization data. Following a moving mass logarithm
across splits requires separate operator transport as in
V927, whose scalar-field comparator is Drago, Hack and
Pinamonti, arXiv:1502.02705. No such transport or
restoration is inferred here. Both current routes share
the action, conventions, symbolic software and authorship.
