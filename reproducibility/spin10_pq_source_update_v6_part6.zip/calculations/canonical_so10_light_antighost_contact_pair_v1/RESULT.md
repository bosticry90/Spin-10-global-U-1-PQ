# V936 result — paired ordinary and light gauge-source contact

There is a nonzero two-vertex local graph direction for
the V933 derivative-ghost projection. In stripped units
its antisymmetric coefficient is -1/10, with the same
signed coefficient in the associated light gauge driver.
Its overall finite extension coefficient stays symbolic.

Native and replay match all 1,624 literal light cubic
spectators after replacing partial a_H by J_B^H, including
1,336 broken input rows. The contact calculation matches
the two nonzero internal color contributions in each
ordering. Under the same contracted-kernel prescription,
varying the ordinary response alone is therefore unavailable.
The source response must be included in the common test.

This is a direction in a local extension space. It does
not determine a physical loop amplitude, choose a finite
normalization, or establish the full linked products.
A fixed reference anchor and a family varied with the
reference mass are distinct tests. Both data routes
share the model, software and AI authorship.

Next apply the paired gauge driver to the free and
interacting Slavnov equations. In particular the selected
broken input colors commute in the original bracket, so
a new antisymmetric light output tests the proposed ghost
and scalar-driver companions without another integral.
