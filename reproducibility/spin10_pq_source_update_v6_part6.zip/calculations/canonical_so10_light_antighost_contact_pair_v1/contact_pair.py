"""Test the light antighost and gauge-source spectators."""

import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)
seagull = source.seagull


def check(phase):
    folder = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    ordinary, retained, quartic = {}, {}, {}
    free = [0, 0]
    for g, word, raw_cells in rows:
        cells = [(p, n, d) for p, n, d in raw_cells if p[0] == 0]
        if not cells:
            continue
        ids = [i for i, _ in word]
        jets = [d for _, d in word]
        a_light = any(598 <= i < 610 for i in ids) and max(ids) < 643
        J_light = sum(i >= 643 for i in ids) == 1 and 643 <= ids[-1] < 691
        D_type = g == 2 and len(ids) == 4 and ids[1] < 180 and 553 <= ids[2] < 598 and 598 <= ids[3] < 643
        if not (a_light or J_light or D_type):
            continue
        assert sum((a_light, J_light, D_type)) == 1
        assert all(p[:2] == [0, 0] for p, _, _ in cells)
        z = seagull.unpack([([0, *p], n, d) for p, n, d in cells])
        if D_type:
            assert jets == [[], [], [], []]
            assert ids[2] >= 565 and ids[3] >= 610 and ids[0] % 4 == ids[1] % 4
            assert tuple(ids) not in quartic and z
            quartic[tuple(ids)] = z
            continue
        if g == 0:
            c, spectator = ids
            assert 553 <= c < 565
            if a_light:
                assert spectator-598 == c-553 and len(jets[0]) == 1 and jets[0] == jets[1]
            else:
                h, mu = divmod(spectator-643, 4)
                assert h == c-553 and jets == [[mu], []]
            free[int(J_light)] += 1
            continue
        assert g == 1
        B, c, spectator = ids
        assert B < 180 and 553 <= c < 598
        b, mu = divmod(B, 4)
        if a_light:
            assert jets == [[], [], [mu]]
            target, h = ordinary, spectator-598
        else:
            assert jets == [[], [], []] and (spectator-643) % 4 == mu
            target, h = retained, (spectator-643)//4
        key = (h, mu, b, c-553)
        assert key not in target and z
        target[key] = z

    assert free == [48, 48]
    assert len(ordinary) == len(retained) == 1624 and ordinary == retained
    assert sum(b >= 12 and c >= 12 for _, _, b, c in ordinary) == 1336
    assert all((b >= 12) == (c >= 12) for _, _, b, c in ordinary)
    assert len(quartic) == 53016

    def contract(spectators, b, c):
        out = {}
        for (h, mu, u, k), z in spectators.items():
            if (h, mu) != (1, 1):
                continue
            key = (*sorted((4*u+mu, 4*b+mu)), 553+c, 598+k)
            value = sp.expand(z*quartic.get(key, 0)*(1+int(u == b)))
            if value:
                out[u, k] = value
        return out

    expected = ({(19, 29): sp.Rational(1, 20), (24, 34): sp.Rational(1, 20)},
                {(29, 19): -sp.Rational(1, 20), (34, 24): -sp.Rational(1, 20)})
    checks = []
    for (b, c), target in zip(((30, 23), (23, 30)), expected):
        assert contract(ordinary, b, c) == contract(retained, b, c) == target
        checks.append({"B": b, "C": c, "entries": [[u, k, str(z)] for (u, k), z in target.items()],
                       "current_before_IBP": str(sum(target.values()))})
    assert (sum(expected[1].values())-sum(expected[0].values()))/2 == -sp.Rational(1, 10)
    assert sum(expected[0].values()) != expected[0][19, 29]
    _, _, _, f, _, _ = source.owner.inputs(phase)
    assert not f[30, 23]
    return {"quadratic_spectators": free, "equal_cubic_spectators": len(ordinary),
            "equal_broken_cubic_spectators": 1336, "ordinary_quartic_rows": len(quartic),
            "two_vertex_projections": checks, "antisymmetric_ordinary_stripped": "-1/10",
            "left_gauge_source_stripped": "-1/10", "original_color_pair_commutes": True}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
