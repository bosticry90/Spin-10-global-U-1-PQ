# V936 pre-execution contract

Test a finite local two-vertex graph direction for the V933
ordinary derivative-ghost coefficient and its gauge-source
partner. Freeze V879, V933, V934 and the fixed contracted
kernel rule of COS1. Work at unit switch and A=0, xi^0,
with one light antighost or its light gauge source.

Check the literal equality of the g1 spectator kernels and
the omitted quadratic's one-port support. Compute the two
ordered T2 color contractions with the literal g2 BBaC
vertex in both frozen routes. Require exact signs, the
matching source replacement and a nonzero antisymmetric
result. The finite coefficient stays symbolic. No promotion.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.
