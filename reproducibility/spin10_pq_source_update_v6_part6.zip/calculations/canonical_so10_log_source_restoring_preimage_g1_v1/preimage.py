from pathlib import Path
from fractions import Fraction as Fr
from collections import Counter
from hashlib import sha256
import gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
def module(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
s=module('preimage_full_BV_tools',O.parent/'canonical_so10_selected_BV_square_g1_u1_v1/square_v2.py');J=s.J;w=s.w;A=s.v.A;one=J.constant(1);zero=J.ZERO;read=s.read;load=s.load;digest=s.digest
atom=lambda n,js=():{((n,tuple(js)),):one}
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2,'ARTIFACT_LIMIT_NO_TRUNCATION'
 with(O/name).open('xb')as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=64*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def clean(P):return J.clean(P)
def plus(*P):return w.plus(*P)
def scale(P,k):return w.scale(P,k)
def g1(coef):
 assert all(k[0]==0 for k,v in coef.terms);return J.Coeff([((1,*k[1:]),v)for k,v in coef.terms])
def LEFT(P,Q):
 out={}
 for n,js in sorted({t for ww in P for t in ww}):
  if Q.get(n):J.add(out,J.mul(J.Ds(Q[n],js),J.leftjet(P,(n,js))))
 return clean(out)
def act(P,Q,odd):
 native=s.v.act(P,Q,odd=odd);peer=LEFT(P,Q);assert native==peer,'COMPLETE_PREFIX_LEFT_VARIATION';return native
def species(n):
 if 1286<=n<1319:return 'epsilon'
 if n>=643:return 'J'+species(n-643)
 return 'B'if n<180 else 'x'if n<508 else'Lambda'if n<553 else'C'if n<598 else'a'
def pattern(ww):return tuple(sorted(species(n)for n,js in ww))
PATTERNS={'vector':tuple(sorted(['B','Lambda','C'])),'JBCC':tuple(sorted(['JB','C','C'])),'aCC':tuple(sorted(['a','C','C'])),'JLambdaCC':tuple(sorted(['JLambda','C','C'])),'JaC':tuple(sorted(['Ja','C'])),'JaLambdaC':tuple(sorted(['Ja','Lambda','C']))}
def select(P,key):return{ww:v for ww,v in P.items()if pattern(ww)==PATTERNS[key]}
def census(P):
 out=Counter()
 for ww,coef in P.items():
  for(k,v)in coef.terms:out[(pattern(ww),sum(len(js)for n,js in ww),k[0])]+=1
 return[[list(pa),jets,g,n]for(pa,jets,g),n in sorted(out.items())]
def normal(P,ids):
 out={};curr=[{}for mu in range(4)]
 for ww,coef in P.items():
  ats=[at for at,(n,js)in enumerate(ww)if n in ids];assert len(ats)==1
  at=ats[0];n,js=ww[at];prefix=ww[:at];suffix=ww[at+1:];sg=(-1)**(J.parity(n)*sum(J.parity(i)for i,jj in prefix));rest={prefix+suffix:coef*sg}
  while js:
   mu=js[-1];js=js[:-1];J.add(curr[mu],J.mul(atom(n,js),rest));rest=scale(J.D(rest,mu),-one)
  J.add(out,J.mul(atom(n),rest))
 out=clean(out);curr=[clean(p)for p in curr];div={}
 for mu,p in enumerate(curr):J.add(div,J.D(p,mu))
 assert plus(P,scale(out,-one))==clean(div),'LITERAL_IBP_RECONSTRUCTION'
 E=J.euler(P,set(ids));peer={}
 for n,pp in E.items():J.add(peer,J.mul(atom(n),pp))
 assert out==clean(peer),'EULER_LITERAL_IBP_NORMAL'
 return out,curr
def homotopy(P,mode):
 out={}
 for ww,coef in P.items():
  found=0
  for at,(n,js)in enumerate(ww):
   if mode=='ghost'and 553<=n<598 and len(js)==1:nn=4*(n-553)+js[0];jj=();factor=one
   elif mode=='Lambda'and 508<=n<553:assert not js;nn=n+90;jj=();factor=-J.I
   else:continue
   sg=(-1)**sum(J.parity(i)for i,kk in ww[:at]);J.put(out,ww[:at]+((nn,jj),)+ww[at+1:],J.times(coef,factor)*sg);found+=1
  assert found==1,('NOT_UNIT_HOMOTOPY_DOMAIN',mode)
 return clean(out)
def decode_canonical(rows,geometry):
 names={name:i for i,name in enumerate(geometry['names'])};out={}
 for row in rows:
  word=[]
  for text in row['word']:
   parts=text.split('__');assert len(parts)<=2
   if len(parts)==2:assert len(parts[1])==1 and parts[1]in'0123'
   word.append((names[parts[0]],(int(parts[1]),)if len(parts)==2 else()))
  coef=J.Coeff([((row['g'],x,e,root),Fr(num,den))for x,e,root,num,den in row['coefficient_cells']]);J.put(out,tuple(word),coef)
 return clean(out)
def main():
 tick=time.perf_counter();watch=threading.Timer(240,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'DEPENDENT_PREDICTION_AND_REMAINDER_READ_DENIED'
 sys.addaudithook(guard)
 inputs=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';packet=load(inputs/'native_inputs.json.gz');assert packet==load(inputs/'replay_inputs.json.gz');states={name:{n:J.decode(rows)for n,rows in pp}for name,pp in packet['states'].items()};physical={n:J.decode(p)for n,p in packet['physical']['P_E0']};Q={n:states['F0'][n]for n in range(643)}
 for n in range(643):Q[643+n]=scale(plus(states['E0'][n],physical.get(n,{})if n<508 else{}),J.constant((-1)**J.parity(n)))
 assert all(Q[n]==atom(553+n//4,(n%4,))for n in range(180))and all(not Q[n]for n in range(553,598))and all(Q[598+c]==scale(atom(508+c),J.I)for c in range(45))
 vec=load(O.parent/'canonical_so10_proper_normalization_transfer_g1_v1/proper_reference.json.gz');vector={}
 for row in vec['M_vector_all_positions']:
  aa,bb,cc=row['B'],row['Lambda'],row['C'];cp=g1(A.decode_coeff(row['p_log']));ce=g1(A.decode_coeff(row['ell_log']))
  for mu in range(4):
   J.add(vector,scale(J.mul(J.mul(atom(4*aa+mu,(mu,)),atom(508+bb)),atom(553+cc)),J.times(-J.I,cp)));J.add(vector,scale(J.mul(J.mul(atom(4*aa+mu),atom(508+bb,(mu,))),atom(553+cc)),J.times(-J.I,ce)))
 vector=clean(vector);jb=load(O.parent/'canonical_so10_JBCC_companion_g1_recovery_v1/proper_reference_v2.json.gz');JBCC={ww:g1(coef)for ww,coef in J.decode(jb['coordinate_proper_reference_log']).items()};own=load(O.parent/'canonical_so10_aCC_full_color_factorization_g1_v1/direct_full_color_reference.json.gz');aCC={};nonzero=0
 for row in own['all91125_ordered_rows']:
  aa,cp,cr=row[:3];values={(x,y,ln):A.decode_coeff(packed)for x,y,ln,packed in row[3]};log={}
  for x,y in[(2,0),(1,1),(0,2)]:
   coef=J.times(values.get((x,y,3),zero),J.constant(Fr(1,2)));assert values.get((x,y,2),zero)==coef*(-3);log[x,y]=coef
  nonzero+=any(log.values())
  if cp>=cr:
   if cp==cr:assert not any(log.values())
   continue
  for(x,y),coef in log.items():
   if not coef:continue
   for mu in range(4):J.put(aCC,((553+cp,(mu,)*x),(553+cr,(mu,)*y),(598+aa,())),-coef)
 aCC=clean(aCC);assert nonzero and len(own['all91125_ordered_rows'])==91125;measured=plus(vector,JBCC,aCC);parents=save('measured_log_parents.json.gz',dict(actual_vector=J.encode(vector),actual_JBCC=J.encode(JBCC),direct_actual_aCC=J.encode(aCC),direct_full91125_log_rows_checked=True,log_prime_relation_exact=True,dependent_prediction_not_read=True))
 normJ,curJ=normal(JBCC,set(range(643,823)));P1=scale(homotopy(normJ,'ghost'),-one);Q1=act(P1,Q,True);n1,j1=normal(plus(JBCC,select(Q1,'JBCC')),set(range(643,823)));assert not n1,'JBCC_RIGHT_INVERSE_FAILED';print('STAGE source_JBCC_preimage '+str(len(P1)),flush=True)
 remaining=plus(vector,select(Q1,'vector'));normL,curL=normal(remaining,set(range(508,553)));P2=scale(homotopy(normL,'Lambda'),-one);Q2=act(P2,Q,True);P=plus(P1,P2);QP=plus(Q1,Q2);fullres=plus(measured,QP);selected={};allmatch=True
 ids={'vector':set(range(508,553)),'JBCC':set(range(643,823)),'aCC':set(range(598,643)),'JLambdaCC':set(range(1151,1196)),'JaC':set(range(1241,1286)),'JaLambdaC':set(range(1241,1286))}
 for name in PATTERNS:
  residual=select(fullres,name);nm,cur=normal(residual,ids[name]);allmatch&=not nm;selected[name]=dict(full_residual=J.encode(residual),exact_normal=J.encode(nm),four_IBP_currents=[J.encode(p)for p in cur],match_modulo_divergence=not nm)
 spill={ww:v for ww,v in fullres.items()if pattern(ww)not in set(PATTERNS.values())};candidate=save('complete_log_preimage.json.gz',dict(P1=J.encode(P1),P2=J.encode(P2),complete_candidate=J.encode(P),full_Q0_P1=J.encode(Q1),full_Q0_P2=J.encode(Q2),full_Q0_candidate=J.encode(QP),complete_measured_plus_Q0candidate=J.encode(fullres),all_six_selected_checks=selected,full_unmeasured_spillover=J.encode(spill),spillover_census=census(spill),source_normal=J.encode(normJ),source_four_IBP_currents=[J.encode(p)for p in curJ],remaining_vector_normal=J.encode(normL),vector_four_IBP_currents=[J.encode(p)for p in curL],full_source_physical_rows_retained=True,all_selected_match_modulo_IBP=allmatch));print('STAGE selected_six_patterns_match='+str(allmatch)+' spillover_words='+str(len(spill)),flush=True)
 ct=load(O.parent/'canonical_so10_Ward_primitive_canonical/canonical_tables.json.gz');geo=ct['geometry'];assert geo['EPS']==1286 and all(J.parity(i)==geo['parities'][i]for i in range(1319));KD=decode_canonical(ct['K'],geo);D={int(n):decode_canonical(rows,geo)for n,rows in ct['D'].items()};E=J.euler(KD,set(range(1286)));derived={}
 for n in range(643):
  if E.get(643+n):derived[n]=scale(E[643+n],-one)
  if E.get(n):derived[643+n]=E[n]
 assert D==derived,'FULL_MARKED_CANONICAL_EULER_FLOW_MISMATCH';assert all(D.get(598+aa,{})==(atom(1286+aa-12)if aa>=12 else{})for aa in range(45));DP=act(P,D,False);Dfield={n:pp for n,pp in D.items()if n<643};Dwrong=s.v.act(P,Dfield,odd=False);Ddiff=plus(Dwrong,scale(DP,-one));badQ={n:pp for n,pp in Q.items()if n<643};Qwrong=s.v.act(P,badQ,odd=True);Qdiff=plus(Qwrong,scale(QP,-one));wrongres=plus(measured,scale(QP,-one));wrongselected={name:J.encode(normal(select(wrongres,name),ids[name])[0])for name in PATTERNS};controls=save('full_marked_image_and_controls.json.gz',dict(actual_full_D={str(n):J.encode(pp)for n,pp in sorted(D.items())},all1286_canonical_columns_rederived_from_K=True,full_D_candidate=J.encode(DP),full_marked_image_census=census(DP),antighost_field_only_D_complete_difference=J.encode(Ddiff),source_omitted_Q0_complete_difference=J.encode(Qdiff),reversed_correction_sign_selected_normals=wrongselected,marked_quantum_loop_NOT_MEASURED=True,marked_insertion_primitive_NOT_CHOSEN=True))
 for ww,coef in P.items():assert sum(J.dimension(n)+len(js)for n,js in ww)==4 and sum(s.ghost(n)for n,js in ww)==0 and sum(J.parity(n)for n,js in ww)%2==0 and all(k[0]==1 for k,v in coef.terms)
 for ww,coef in QP.items():assert sum(J.dimension(n)+len(js)for n,js in ww)==5 and sum(s.ghost(n)for n,js in ww)==1 and sum(J.parity(n)for n,js in ww)%2==1 and all(k[0]==1 for k,v in coef.terms)
 assert Qdiff and Ddiff and any(wrongselected.values()),'INSENSITIVE_OMISSION_CONTROL'
 out=dict(schema='MEASURED_LOG_SELECTED_SOURCE_PREIMAGE_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',selected_six_pattern_disposition='MATCH_MODULO_EXPLICIT_IBP'if allmatch else'MISMATCH_PRESERVED_NOTPASS',all_six_selected_patterns_match=allmatch,P1_words=len(P1),P2_words=len(P2),candidate_words=len(P),full_Q0_image_words=len(QP),unmeasured_spillover_words=len(spill),spillover_census=census(spill),full_marked_image_words=len(DP),marked_image_census=census(DP),full1286_marked_flow_columns_from_canonical_K_match=True,source_omission_and_field_only_marked_controls_sensitive=True,parents_artifact=parents,candidate_artifact=candidate,marked_artifact=controls,dependent_prediction_not_read=True,lower_V804_kinetic_family_NOT_SELECTED=True,admissible_common_restoration_NOT_ESTABLISHED=True,background_reality_marked_quantum_and_spillover_equations_still_required=True,common_normalization_E5_A5_goal_completion_NOT_CLAIMED=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'preimage_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
