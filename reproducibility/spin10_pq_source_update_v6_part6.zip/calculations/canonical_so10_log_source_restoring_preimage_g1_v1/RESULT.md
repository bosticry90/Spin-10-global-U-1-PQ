# Logarithmic correction passes selected equations; simple completion fails

One explicit local correction now matches all six measured logarithmic
consistency-parent patterns, including vector, JBCC and the independently
calculated full-color aCC reference. All source and physical Q0 rows are
retained. This is a common algebraic preimage for those selected terms,
not an admissible common restoration or an adopted finite normalization.

The full image shows why the distinction matters. The correction produces
a nonzero BBC/two-derivative remainder and a nonzero full marked image.
Both survive integration by parts. The marked operation includes its source
shifts, and its actual g2 epsilon-BBC terms remain preserved alongside g1.
None is identified with an unknown quantum amplitude or fitted away.

A source-free correction at the same gu/Q0 step cannot remove this particular
BBC remainder while other coupled terms stay fixed. Its Q0 closure passes,
but it fails a stronger necessary constant-ghost functional test:2,616 of
8,100 Euler columns are nonzero, covering ghost colors13..44. That excludes
the source-free-only completion route for this candidate. It is NOT a
general anomaly, physical exclusion or failure of every common normalization.
The coupled lower-order/source images have not been fixed by this test.

Exact evidence: P1/P2 have4,504/13,216 words; complete Q0 image60,212;
BBC remainder27,024. Complete marked image66,240; after epsilon IBP61,440,
with6,608 g1 and54,832 g2 positions. Every direct aCC color row is reproduced
by two full-eight-momentum Fourier methods. Complete derivative/IBP/source/
marked arrays and sensitive omission/sign controls are saved, not just counts.

Primary executions after imports: preimage120.055s/240, functional diagnostic
31.296s/180, closure65.596s/120, constant ghost10.394s/120. No failed scientific
worker. Source/record/preparation/capture bytes are immutable.8GiB sampled
private/350MiB launch floor/64MiB packet/10MiB artifact; observations are not
true or nested-process peak measurements. Final receipt owns fresh replay,
E4 and evidence-validation disposition; execution is not director acceptance.

Next: inspect the already admissible lower-order/source normalization module
and its full coupled Q1/Qu0/marked images. Do not spend a new cubic solve on
the excluded fixed-step source-free route, invent unknown cancellations or
release arbitrary parameters. Rational normalization, reality/background,
marked quantum/insertion and other complete quantum obligations remain open.

Track A gains a concrete full-source correction plus a sharply scoped failed
completion route. Track B demonstrates that closure and projected matching
can both pass while a stronger exactness requirement fails. All routes share
physical action/conventions/ring/code/AI authorship; no external scientist,
Lean or experimental validation is claimed. State113/authority34of39 and
seven custody NOTPASS stay unchanged. Full E5/A5 and overall goal remain active.
