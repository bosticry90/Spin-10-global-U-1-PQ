# Final evidence validation freeze

Fresh sequential recomputation of all four completed results and all six
complete artifacts. Aggregate bound480s after imports; constituent bounds
240/180/120/120 unchanged.8GiB sampled/350MiB floor/64MiB packet/10MiB
artifact. No parallel scientific worker, hidden truncation or automatic
expansion. Exact failed/unfinished capture if any check fails or exhausts.

Authenticate every preparation/source copy/dependency/capture, including
current AGENTS/state. Fresh complete artifacts must be byte-identical;
every non-runtime result field must agree. Verify six selected parent
matches with full explicit IBP currents, all direct inverse-Fourier rows,
all1286 canonical marked columns, nonzero full functional images, all643
nilpotent source-free field squares, CLOSED spillover result, and the later
constant-ghost exclusion. Do not conflate closure with exactness or turn a
restricted failed completion route into a no-go for the theory.

E4 once/no fresh/fixed D: historical context; expected0,0,0,0,0,2 and exactly
seven historical custody unresolved references NOTPASS. Preserve all old
mode/blob entries and state SHA. Local commit only after validation. No
branch/worktree/adoption/protected promotion/push/external action. V823
handoff records the actual limitation and next smallest authorized test.
