from pathlib import Path
import importlib.util,json,os,sys,threading,time
sp=importlib.util.spec_from_file_location('log_completion_closure_tools',Path(__file__).resolve().with_name('preimage.py'));p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p);J=p.J;O=p.O;R=p.R
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in p.read(O/'closure_preparation.json')['sha256'].items():assert p.digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'PREDICTION_AND_REMAINDER_READ_DENIED'
 sys.addaudithook(guard)
 packet=p.load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/native_inputs.json.gz');Q={n:J.decode(pp)for n,pp in packet['states']['F0']};expected={n:p.atom(553+n//4,(n%4,))for n in range(180)};expected.update({598+a:p.scale(p.atom(508+a),J.I)for a in range(45)});assert all(Q[n]==expected.get(n,{})for n in range(643));squares=[]
 for n in range(643):sq=p.act(Q[n],Q,True);assert not sq;squares.append([n,J.encode(sq)])
 res=p.read(O/'preimage_result.json');candidate=p.load(O/res['candidate_artifact']['file']);spill=J.decode(candidate['full_unmeasured_spillover']);variation=p.act(spill,Q,True);normal,curr=p.normal(variation,set(range(180)));assert all(p.pattern(ww)==tuple(sorted(['B','C','C']))and sum(len(js)for n,js in ww)==3 and sum(J.dimension(n)+len(js)for n,js in ww)==6 and sum(p.s.ghost(n)for n,js in ww)==2 and sum(J.parity(n)for n,js in ww)%2==0 for ww in normal)
 artifact=p.save('sourcefree_completion_closure.json.gz',dict(all643_field_coordinate_Q0_squares=squares,full_Q0_spillover=J.encode(variation),undifferentiated_B_normal=J.encode(normal),four_IBP_currents=[J.encode(pp)for pp in curr],full_normal_census=p.census(normal),sourcefree_field_flows={str(n):J.encode(pp)for n,pp in Q.items()},finite_jet_sourcefree_nilpotency_by_generator_derivation_lemma=True,actual_BBC_quantum_breaking_NOT_ASSIGNED=True,not_a_general_anomaly_or_no_go=True))
 out=dict(schema='LOG_PREIMAGE_SOURCEFREE_COMPLETION_CLOSURE_TEST_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',all643_sourcefree_coordinate_Q0_squares_zero=True,Q0_spillover_normal_words=len(normal),Q0_spillover_normal_census=p.census(normal),spillover_Q0_closed_as_integrated_functional=not normal,sourcefree_only_completion_of_this_candidate='EXCLUDED_BY_NONCLOSURE'if normal else'NOT_EXCLUDED_CLOSURE_ONLY',not_general_normalization_or_physical_obstruction=True,actual_BBC_quantum_coefficient_NOT_SELECTED=True,artifact=artifact,elapsed_after_imports=time.perf_counter()-tick);p.dump(O/'closure_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
