from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/log-source-restoring-preimage-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
C.mkdir(parents=True,exist_ok=True)
deps={'canonical_so10_proper_slavnov_actual_operators_g1_v1':['native_inputs.json.gz','replay_inputs.json.gz','validation_receipt.json'],'canonical_so10_selected_BV_square_g1_u1_v1':['square_v2.py','validation_receipt.json','PROOF.md'],'canonical_so10_proper_normalization_transfer_g1_v1':['proper_reference.json.gz','validation_receipt.json'],'canonical_so10_JBCC_companion_g1_recovery_v1':['proper_reference_v2.json.gz','validation_receipt.json'],'canonical_so10_aCC_full_color_factorization_g1_v1':['direct_full_color_reference.json.gz','validation_receipt.json','PROOF.md'],'canonical_so10_aCC_full_finite_comparison_g1_v1':['validation_receipt.json','PROOF.md'],'canonical_so10_unmarked_g0_common_kinetic_recovery_v1':['validation_receipt.json','PROOF.md'],'canonical_so10_Ward_primitive_canonical':['canonical_tables.json.gz','canonical_result.json','validation_receipt_v2.json','final_review_validation_receipt.json','PROOF.md']}
names=['AGENTS.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V822.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md']+['calculations/'+d+'/'+n for d,nn in deps.items()for n in nn]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='50113d4aa74c3f0f49f0e92594831d87b28983c8'
for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in['RECORD.md','preimage.py','run.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as h:h.write((O/n).read_bytes())
dump(O/'preparation.json',dict(base_HEAD=head,sha256={**{n:digest(R/n)for n in names},**{p.relative_to(R).as_posix():digest(p)for p in O.iterdir()if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'preimage.py')]);dump(O/'preimage_capture.json',cap);dump(C/'preimage_capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
