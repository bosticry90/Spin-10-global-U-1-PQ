# Constant-ghost necessary condition for source-free completion

Closure test completed65.596s/120: all643 field squares vanish and the BBC
spillover is Q0 closed modulo the full saved divergence. Closure does not
prove triviality. Before a cubic coefficient solve, freeze a second cheap
necessary condition,120s after imports,8GiB sampled/350MiB floor/64MiB
packet/10MiB artifact. Only existing own local spillover is used; preserve
all earlier evidence and allowances. No quantum input/prediction/new loop.

For the BBC component of any source-free finite local Q0 counterterm,
only QB=partial C can supply its single ghost. Qa=iLambda supplies a
Lambda and cannot produce BBC; all other field flows vanish. Hence its
BBC image contains at least one differentiated ghost before IBP. Replacing
C_c by a formal constant odd parameter zeta_c and all nonzero C jets by0
commutes with the even total derivative. Thus its integrated image must
vanish at constant ghost, irrespective of its original density representative.
This is an ALGEBRAIC necessary test on already qualified LOCAL reference
coefficients, not an exceptional-momentum shortcut on an unseparated loop.

Apply that constant-ghost map to the full spillover. Store all45 coefficient
polynomials R_c(B) and their zero complement. Compute every field Euler
column of each quadratic B polynomial two ways: the inherited LEFT Euler
routine and literal sum over its two even B positions with (-D)^jets.
Preserve complete columns and differences before failing. Nonzero Euler
means the integrated functional is not a divergence and rules out a purely
source-free finite correction with image minus THIS spillover, at this
fixed gu/g0-Q0 step. It is not a general obstruction to common normalization:
lower-degree Q1/Qu0 images, further source terms, or measured additional
quantum companions have not been fixed or tested by this criterion.

If all Euler columns vanish, the necessary test passes but exactness remains
unproved; an actual cubic preimage is then justified. Do not invent a repair
or treat an unmeasured quantum coefficient as zero. Retain both possible
outcomes honestly. Final review replays the complete test under120s.
