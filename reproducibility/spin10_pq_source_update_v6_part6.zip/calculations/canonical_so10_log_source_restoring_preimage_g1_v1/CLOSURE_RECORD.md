# Source-free completion discriminant

The full functional diagnostic completed31.296s/180. Both the BBC spillover
and full marked image remain nonzero integrated functionals; all91125
direct inverse-Fourier rows match by both methods. Before trying another
counterterm ansatz, use a cheaper structural test: is this candidate's BBC
spillover Q0 closed as an INTEGRATED local functional?

Freeze120s after imports,8GiB sampled/350MiB floor/64MiB packet/10MiB
artifact. Inputs only completed own candidate and actual Q0 source packet.
No new loop, missing coefficient, finite normalization or prediction input.
Keep old records/sources/allowances/captures immutable.

Verify all643 source-free coordinate flows exactly: QB=partial C,
Qa=iLambda, all others0. Compute all643 coordinate squares by prefix and
LEFT and keep the full zero complement. Since an odd derivation's square
is an even derivation and commutes with total derivatives, these generator
identities prove nilpotency on finite source-free jet polynomials.

Apply actual Q0 to the FULL BBC spillover with prefix and independent LEFT
operations. Normalize its single remaining B by literal IBP and independently
Euler_B, preserving all four currents and complete normal. No source-zero
shortcut on an unknown quantum term. If normal is nonzero, then no purely
source-free finite local correction can have Q0 image equal to minus THIS
spillover modulo a divergence: every such image is Q0 closed. This excludes
that specified completion route for this candidate, not all source-containing
normalizations, not other quantum companions, not the theory. It does not
assign the actual unmeasured BBC quantum breaking a value.

If the normal vanishes, closure only permits a preimage search; it does not
prove exactness or choose a counterterm. Retain either outcome. This test
selects whether a source-free cubic repair is scientifically justified
before spending resources on a large linear system. Full common restoration,
marked amplitudes/insertion, invariance/reality, E5/A5 and authority remain
unchanged. Final validation replays this test under its own120s bound.
