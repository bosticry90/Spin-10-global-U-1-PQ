from pathlib import Path
from collections import Counter
import importlib.util,json,os,sys,threading,time
sp=importlib.util.spec_from_file_location('constant_ghost_local_tools',Path(__file__).resolve().with_name('preimage.py'));p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p);J=p.J;O=p.O;R=p.R
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in p.read(O/'constant_ghost_preparation.json')['sha256'].items():assert p.digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'PREDICTION_AND_REMAINDER_READ_DENIED'
 sys.addaudithook(guard)
 result=p.read(O/'preimage_result.json');candidate=p.load(O/result['candidate_artifact']['file']);spill=J.decode(candidate['full_unmeasured_spillover']);blocks={n:{}for n in range(45)};removed=0
 for ww,coef in spill.items():
  ats=[at for at,(n,js)in enumerate(ww)if 553<=n<598];assert len(ats)==1 and p.pattern(ww)==tuple(sorted(['B','B','C']));at=ats[0];n,js=ww[at]
  if js:removed+=1;continue
  J.put(blocks[n-553],ww[:at]+ww[at+1:],coef)
 rows=[];nonzero=[];allcolumns=0;maxword=0
 for c,P in blocks.items():
  P=p.clean(P);native=J.euler(P,set(range(180)));peer={}
  for ww,coef in P.items():
   for at,(n,js)in enumerate(ww):J.add(peer.setdefault(n,{}),J.Ds({ww[:at]+ww[at+1:]:coef*((-1)**len(js))},js))
  peer={n:p.clean(poly)for n,poly in peer.items()if p.clean(poly)};assert native==peer,('CONSTANT_GHOST_EULER_REPLAY',c);columns=[[n,J.encode(native.get(n,{}))]for n in range(180)];nonzero+=[[c,n]for n,Pn in native.items()if Pn];allcolumns+=len(columns);maxword=max(maxword,len(P));rows.append(dict(ghost_color=c,full_constant_ghost_polynomial=J.encode(P),all180_field_Euler_columns=columns,all_literal_peer_nonzero_columns=[[n,J.encode(Pn)]for n,Pn in sorted(peer.items())],all_columns_equal=True))
 assert len(rows)==45 and allcolumns==8100
 artifact=p.save('constant_ghost_completion_condition.json.gz',dict(all45_ghost_coefficient_polynomials_and_8100_Euler_columns=rows,nonzero_Euler_positions=nonzero,discarded_nonconstant_ghost_jet_words=removed,formal_constant_ghost_map_not_loop_momentum_specialization=True,only_QB_can_supply_BBC_from_sourcefree_counterterm=True,sourcefree_Q0_image_necessary_constantghost_functional_zero=True,actual_unmeasured_quantum_coefficient_NOT_SELECTED=True))
 out=dict(schema='SOURCEFREE_COMPLETION_CONSTANT_GHOST_CONDITION_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',all45_constant_ghost_colors_8100_field_Euler_columns_checked=True,complete_literal_Euler_replay_equal=True,nonzero_Euler_columns=len(nonzero),ghost_colors_with_nonzero_Euler=sorted({c for c,n in nonzero}),sourcefree_only_completion_of_this_candidate='EXCLUDED_BY_CONSTANT_GHOST_FUNCTIONAL'if nonzero else'NOT_EXCLUDED_NECESSARY_CONDITION_ONLY',not_general_common_normalization_or_physical_no_go=True,artifact=artifact,elapsed_after_imports=time.perf_counter()-tick);p.dump(O/'constant_ghost_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
