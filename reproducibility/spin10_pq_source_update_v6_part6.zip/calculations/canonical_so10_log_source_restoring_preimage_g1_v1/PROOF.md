# A measured logarithmic preimage and a failed source-free completion route

Claim LOG-PREIMAGE-1 is a local algebraic preimage for all six measured
logarithmic consistency-parent patterns at first actual g10/first u_M in
the unshifted Euclidean A0 intrinsic0/1 domain. Claim LOG-PREIMAGE-2 is the
complete source/physical/marked image of that particular correction. Claim
LOG-PREIMAGE-3 excludes completing it solely by a source-free gu correction
acted on by Q0, with all other coupled terms held fixed. None asserts a
common admissible restoring prescription, a general anomaly or E5/A5.

The quantum inputs are the actual proper vector/JBCC logarithmic references
and V821's direct aCC tensor. The dependent V814 prediction and assembled
remainders are denied to these workers. The full91,125 ordered direct aCC
rows have log2=-3L/log3=2L. The coordinate representative has undifferentiated
a and canonical ghost colors c<d; derivative phases supply i²=-1. Both
distinct V822 full-eight-momentum Fourier constructions reconstruct every
direct color row, including zeros/same-color, from this coordinate polynomial.
No ghost half, coefficient fit or inverse physical coupling is introduced.

Let Delta_log denote those measured parent polynomials, with the other
qualified logarithmic parent references zero. First put its JBCC part into
an undifferentiated-JB representative N_J. Literal repeated integration by
parts equals JB Euler normalization and gives all four currents. The actual
free flows are QB_mu=partial_mu C, QC=0, Qa=iLambda. On this representative
the odd homotopy h_J(partial_mu C)=B_mu has unit derivative-ghost count.
Consequently P1=-h_J N_J removes the JBCC projection. Its FULL Q0 variation
is calculated before projection, including QJB and physical E0_B.

Next normalize the remaining B-Lambda-C part to undifferentiated Lambda,
again with Euler/literal-IBP agreement and all currents. The odd homotopy
h_Lambda(Lambda)=-i a gives P2=-h_Lambda N_Lambda. This removes the remaining
vector projection. Both FULL variations are independently reconstructed by
odd-prefix and LEFT-jet operations. The measured aCC part and all three
other qualified source-parent patterns match simultaneously modulo explicit
currents. P1 has4,504 words, P2 has13,216, total17,720; Q0(P1+P2) has60,212.
These are representation counts, not independent quantum predictions.

The complete measured-plus-correction functional has a source-free BBC,
two-derivative, actual-g1 remainder with27,024 words. Its undifferentiated-C
normal is nonzero, with Euler/literal IBP agreement. It is not a disposable
boundary. It is this constructed candidate's spillover; no value has been
assigned to an unmeasured actual BBC quantum breaking.

The FULL marked Dminus is used on the source-dependent correction. All1,286
canonical columns are independently rederived by Euler differentiation of
the preserved canonical K_D and agree with its qualified transported maps.
An antighost-only shift would omit nonzero source terms. Prefix and LEFT
operations agree on D(P1+P2). Its complete image has66,240 words. After
epsilon IBP normalization it still has61,440:6,608 g1 epsilon-BC/one-jet
and54,832 g2 epsilon-BBC/no-jet terms. The higher gauge grade is retained,
not silently truncated. This is a counterterm's marked image, not a measured
marked quantum amplitude or a chosen compensating insertion primitive.

All643 source-free coordinate squares Q0² vanish with both derivative
routes. The square of an odd derivation is even and commutes with total
derivatives, so this proves source-free finite-jet nilpotency. Applying Q0
to the BBC spillover gives a zero integrated normal with full saved currents.
Thus the simple closure test PASSES; it does not prove a source-free preimage.
This positive result is retained rather than misreported as an obstruction.

There is a stronger necessary condition. Only QB=partial C can supply BBC
in a source-free Q0 image; Qa=iLambda supplies a forbidden Lambda. Every
such BBC density therefore has a differentiated ghost before IBP. Replacing
ghosts by formal constant odd parameters and their nonzero jets by0 commutes
with total derivatives. Hence a source-free Q0 image must be an integrated
zero under that replacement. This is a formal local-functional criterion
applied AFTER the continuum reference is qualified; no loop momentum is
specialized and no UV/IR limit or contact term is discarded.

For this spillover, all45 constant-ghost coefficient polynomials and all180
B Euler columns per color are evaluated. LEFT Euler and literal even-position
variation agree at all8,100 columns. There are2,616 nonzero columns, for
ghost colors13..44. They prove its constant-ghost integrated functional is
nonzero. Therefore a source-free finite correction F_gu with
Q0 F_gu=-spillover modulo a divergence does NOT exist for this candidate at
this fixed step. A large pure-gauge cubic solve would pursue an excluded
route and is unnecessary. Closure without this condition would have been
insufficient evidence of exactness.

This failure has a deliberately qualified scope. It holds other coupled
terms fixed. It neither excludes lower-degree Q1/Qu0 normalization images,
other source-dependent corrections nor measured additional quantum parents.
It does not prove that the actual total breaking has this residual, or
that all admissible common prescriptions fail. Background/reality checks,
the lower V804 homogeneous family, actual marked g1 quantum terms, source
products and higher complete identities remain to be addressed. No finite
normalization, vacuum or foundational assumption has been adopted.

Negative controls preserve complete differences for omitted Q0 source rows,
an antighost-field-only marked D and reversed correction sign. All candidate
and Q0-image dimensions/ghost/parity/actual gauge grades pass. Shared action,
chart, exact ring, inherited code and AI author constrain independence.
There is no Lean proof, outside scientist or empirical validation. The
AI-capability evidence includes a successful full-source preimage and the
distinction between a closed functional and a source-free exact functional;
the restricted negative route remains part of the evidence.

Next inspect the EXISTING admissible lower-order/source normalization module
and its coupled Q1/Qu0/marked images against this measured obstruction.
Do not repeatedly add arbitrary carriers to rescue a preferred ansatz.
If the frozen admitted module cannot supply it, classify that restriction
before choosing another quantum calculation. Rational components are not
solved by this logarithmic construction. Full common restoration, QAP,
measure, products, equivalence, E5/A5, physical viability and the overall
investigation remain open; authority state113/34of39 stays unchanged.
