from pathlib import Path
from fractions import Fraction as Fr
import importlib.util,json,os,sys,threading,time
sp=importlib.util.spec_from_file_location('log_preimage_diagnostic_tools',Path(__file__).resolve().with_name('preimage.py'));p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p);J=p.J;A=p.A;O=p.O;R=p.R
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in p.read(O/'diagnostic_preparation.json')['sha256'].items():assert p.digest(R/n)==h,n
 def guard(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   name=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in name for t in['aCC_reference_integrability_prediction','known_consistency_images','consistency_tables.json','hard_response_v2.json']),'PREDICTION_AND_REMAINDER_READ_DENIED'
 sys.addaudithook(guard)
 result=p.read(O/'preimage_result.json');assert result['execution_state']=='COMPLETED';candidate=p.load(O/result['candidate_artifact']['file']);marked=p.load(O/result['marked_artifact']['file']);spill=J.decode(candidate['full_unmeasured_spillover']);DP=J.decode(marked['full_D_candidate']);sn,sc=p.normal(spill,set(range(553,598)));mn,mc=p.normal(DP,set(range(1286,1319)));print('STAGE full_spillover_and_epsilon_Euler_IBP_normals',flush=True)
 ct=p.module('independent_full_momentum_interface',O.parent/'canonical_so10_aCC_full_finite_comparison_g1_v1/compare.py');parents=p.load(O/result['parents_artifact']['file']);actual=J.decode(parents['direct_actual_aCC']);suppressed={}
 for ww,coef in actual.items():assert all(k[0]==1 for k,v in coef.terms);suppressed[ww]=J.Coeff([((0,*k[1:]),v)for k,v in coef.terms])
 primary,journal=ct.all_fourier(suppressed);peer,count=ct.literal_all_fourier(suppressed);assert len(journal)==count;replaydiff=[]
 for ext in set(primary)|set(peer):
  diff=ct.c.difference(primary.get(ext,{}),peer.get(ext,{}))
  if diff:replaydiff.append([*ext,ct.enc8(diff)])
 own=p.load(O.parent/'canonical_so10_aCC_full_color_factorization_g1_v1/direct_full_color_reference.json.gz');differences=[];checked=0
 for row in own['all91125_ordered_rows']:
  aa,cp,cr=row[:3];want={}
  for x,y,ln,packed in row[3]:
   if ln!=3:continue
   coef=J.times(A.decode_coeff(packed),J.constant(Fr(1,2)))
   for mu in range(4):ex=[0]*8;ex[mu]+=x;ex[4+mu]+=y;ct.add(want,tuple(ex),coef)
  want=ct.clean(want);diff=ct.c.difference(primary.get((cp,cr,aa),{}),want)
  if diff:differences.append([aa,cp,cr,ct.enc8(diff)])
  checked+=1
 artifact=p.save('full_image_functional_diagnostics.json.gz',dict(full_spillover=J.encode(spill),undifferentiated_C_spillover_normal=J.encode(sn),spillover_four_IBP_currents=[J.encode(pp)for pp in sc],spillover_normal_census=p.census(sn),full_marked_image=J.encode(DP),undifferentiated_epsilon_marked_normal=J.encode(mn),marked_four_IBP_currents=[J.encode(pp)for pp in mc],marked_normal_census=p.census(mn),complete_aCC_Fourier_primary=[[*ex,ct.enc8(poly)]for ex,poly in sorted(primary.items())],complete_aCC_Fourier_permutation_peer=[[*ex,ct.enc8(poly)]for ex,poly in sorted(peer.items())],all_aCC_coordinate_word_assignments=journal,all91125_momentum_reconstruction_differences=differences,full_Fourier_replay_differences=replaydiff,all_unlisted_color_and_quadratic_slots_exact_zero=True,polynomial_g1_extraction_not_coupling_division=True));assert not differences and not replaydiff and checked==91125,'DIRECT_ACC_COORDINATE_INVERSE_FOURIER_MISMATCH'
 out=dict(schema='LOG_CORRECTION_FULL_IMAGE_FUNCTIONAL_DIAGNOSTICS_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',spillover_is_nonzero_integrated_functional=bool(sn),spillover_normal_words=len(sn),spillover_normal_census=p.census(sn),full_marked_image_is_nonzero_integrated_functional=bool(mn),marked_normal_words=len(mn),marked_normal_census=p.census(mn),all91125_direct_aCC_inverse_Fourier_reconstructed=True,both_full_Fourier_methods_equal=True,inverse_Fourier_assignments=count,artifact=artifact,not_a_new_loop_calculation_or_common_restoration=True,background_reality_and_quantum_marked_spillover_equations_open=True,elapsed_after_imports=time.perf_counter()-tick);p.dump(O/'diagnostic_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
