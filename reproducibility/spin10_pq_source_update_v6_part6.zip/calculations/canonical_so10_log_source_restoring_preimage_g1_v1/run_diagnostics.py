from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/log-source-restoring-preimage-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
for n,h in json.loads((O/'preparation.json').read_bytes())['sha256'].items():assert digest(R/n)==h,n
cap=json.loads((O/'preimage_capture.json').read_bytes());assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
dep='calculations/canonical_so10_aCC_full_finite_comparison_g1_v1/compare.py';assert(R/dep).read_bytes()==subprocess.check_output(['git','show','HEAD:'+dep],cwd=R)
for n in['DIAGNOSTIC_RECORD.md','image_diagnostics.py','run_diagnostics.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as h:h.write((O/n).read_bytes())
dump(O/'diagnostic_preparation.json',dict(sha256={**json.loads((O/'preparation.json').read_bytes())['sha256'],dep:digest(R/dep),**{p.relative_to(R).as_posix():digest(p)for p in O.iterdir()if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'image_diagnostics.py')]);dump(O/'diagnostic_capture.json',cap);dump(C/'diagnostic_capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
