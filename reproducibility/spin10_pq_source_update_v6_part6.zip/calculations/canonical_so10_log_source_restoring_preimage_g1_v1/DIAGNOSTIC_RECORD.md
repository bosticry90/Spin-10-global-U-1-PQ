# Full-image functional diagnostic freeze

The first worker completed120.055s/240: P1 has4504 words, P2 has13216,
full candidate17720, complete Q0 image60212. All six measured logarithmic
parent patterns match modulo explicit IBP. The complete unmeasured spillover
has27024 BBC/two-derivative/g1 coefficient cells. Full marked D image has
66240 words, including g1 epsilon-BC/one-derivative and g2 epsilon-BBC/no-jet
terms. No common-restoration/admissibility claim. Existing sources immutable.

Before interpreting those images as genuine functional obligations, freeze
180s after imports/8GiB sampled/350MiB floor/64MiB packet/10MiB artifact.
Use existing completed candidate inputs only; no unknown quantum calculation
or prediction/remainder read. Put the BBC spillover into an undifferentiated
single-C representative by literal IBP and independently by Euler_C, keeping
all four currents and the FULL resulting polynomial. This determines whether
it is a nonzero integrated local functional or a pure boundary.

Put the complete marked image into an undifferentiated-epsilon representative
with literal IBP and independent Euler_epsilon, all33 markers and ALL gauge
grades retained. Store complete currents/normal and counts by grade/field
pattern. A nonzero image still is not the marked quantum amplitude or an
obstruction; lower counterterm/marked insertion/loop equations remain separate.

Independently verify the direct aCC momentum-to-coordinate reconstruction.
Extract the ACTUAL g1 coefficient polynomially to the helper's suppressed-g0
representation, then use BOTH V822 full eight-momentum Fourier constructions
on the complete measured coordinate aCC log polynomial. Require both tensors
equal and compare against ALL91125 direct rows lifted to p²/p.r/r², including
zeros/same-color and the exact log2=-3L/log3=2L relation. No coupling division,
factor fit, unknown contact, ghost half or dependent prediction read.

Preserve complete mismatches before failing. This diagnostic is not a new
loop calculation, full invariant/reality test, marked restoration or E5/A5
promotion. It discriminates a genuine candidate-completion obligation from
an artifact of density representatives and checks the new inverse Fourier
interface. Final validation must replay both completed workers separately
under their original240/180s bounds and retain all evidence.
