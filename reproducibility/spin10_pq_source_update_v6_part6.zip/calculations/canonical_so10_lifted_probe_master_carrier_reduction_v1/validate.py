from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
from itertools import product
from hashlib import sha256
import gzip,importlib.util,json,os,re,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/lifted-probe-master-carrier-reduction-v1-2026-11-08')
sp=importlib.util.spec_from_file_location('V854_SHARED_FROZEN_WORD_CODEC',B/'canonical_so10_augmented_metric_lift_v1/algebra.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def d(n):return 3-d(n-643)if n>=643 else 1+int(n in range(508,553))
def choose(raw,D,g=None):return{k:v for k,v in a.flat(raw).items()if 0<=D-sum(d(n)+len(js)for n,js in k[0])<=1 and k[1][0]<=1 and(g is None or k[1][0]==g)}
def phase(n):
    i=n-643 if n>=643 else n
    if 508<=i<553:return 3
    if i<180 and i%4==0:return 1
    return 2 if n>=643 and i<508 else 0
def wick_inverse(q,drop_jets=False):
    out={}
    for(word,key),v in q.items():
        p=(-sum(phase(n)for n,js in word)-(0 if drop_jets else sum(js.count(0)for n,js in word)))%4;kk=list(key);sign=[1,1,-1,-1][p]
        if p%2:
            if kk[3]&16:sign=-sign
            kk[3]^=16
        out[word,tuple(kk)]=-v*sign
    return out
def difference(q,p):
    out=dict(q)
    for k,v in p.items():out[k]=out.get(k,F(0))-v
    return{k:v for k,v in out.items()if v}
def scalar_pair_lift(q,record):
    groups=defaultdict(dict)
    for(w,k),v in q.items():groups[a.describe(w)].setdefault(w,{})[k]=v
    assert len(groups)==len(record['tensor_groups']);wrong=0;totaldomain=0
    for(desc,target),row in zip(sorted(groups.items()),record['tensor_groups']):
        rank=len(a.slots(desc));assert rank in[0,2]and row['rank']==rank and row['descriptor']==[list(x)for x in desc]
        assert len(row['all_pairing_coefficients'])==1 and row['independent_pairing_columns']==[0]
        coefficient={tuple(k):F(num,den)for k,num,den in row['all_pairing_coefficients'][0]};column={};badcolumn={}
        choices=[()]if rank==0 else[(mu,mu)for mu in range(4)]
        variance=a.slots(desc)
        for assignments in choices:
            word,sg=a.word(desc,assignments)
            if not sg:continue
            metric=-1 if rank and assignments[0]and variance[0]==variance[1]else 1
            column[word]=column.get(word,0)+sg*metric;badcolumn[word]=badcolumn.get(word,0)+sg
        projected={(w,k):v*c for w,c in column.items()if c for k,v in coefficient.items()if v*c};actual={(w,k):v for w,co in target.items()for k,v in co.items()};assert projected==actual
        bad={(w,k):v*c for w,c in badcolumn.items()if c for k,v in coefficient.items()if v*c};wrong+=bool(difference(bad,actual))
        domain={w for assignments in product(range(4),repeat=rank)for w,sg in[a.word(desc,assignments)]if sg};assert set(target)<=domain and row['canonical_component_domain']==len(domain)and row['zero_component_count']==len(domain)-len(target)and not row['complete_residual'];totaldomain+=len(domain)
    assert a.flat(record['complete_reconstructed_density'])==q and record['match']and not record['complete_residual']and record['component_domain_count']==totaldomain
    assert record['controls']['wrong_metric_sensitive_groups']==wrong and wrong>0 and record['controls']['wrong_source_variance_sensitive_groups']==0
def check_lineage():
    portable='tools/portable_dh_v1/inputs.json.gz';ast='tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json';dc=B/'canonical_so10_dimensional_counterterm_applicability';old=read(dc/'preparation.json')['input_sha256'];oldmap={n.replace('\\','/'):h for n,h in old.items()}
    def find(name):return next(h for n,h in oldmap.items()if n.endswith('/'+name))
    assert digest(R/portable)==find(portable)==read(B/'canonical_so10_acceptance_parent_reconciliation_v1/preparation_c_v2.json')['sha256'][portable]
    assert digest(R/ast)==find(ast)==read(B/'canonical_so10_physical_current_input_recovery_g1_v1/preparation_v2.json')['input_sha256'][ast]
    oldlift=read(B/'canonical_so10_augmented_metric_lift_v1/preparation.json')['sha256']
    for root in[dc,B/'canonical_so10_acceptance_parent_reconciliation_v1']:assert digest(root/'validation_receipt.json')==oldlift[(root/'validation_receipt.json').relative_to(R).as_posix()]
    receipt=read(B/'canonical_so10_source_homotopy_applicability_g1_v1/validation_receipt.json');assert receipt['execution_state']=='COMPLETED'and receipt['all12_union_divergences_exact']and receipt['all15432_constructing_owner_F_E_columns_equal']
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='4ba9c18bdea331c49f68af06d13a5e4839bb5d8c'
    for n,h in read(O/'preparation_validation.json')['sha256'].items():assert digest(R/n)==h,n
    saved={'README.md':C/'README_before.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':C/'campaign_before.md'};prep=read(O/'preparation.json');assert prep==read(C/'preparation.json')
    for n,h in prep['sha256'].items():assert digest(saved[n]if n in saved else R/n)==h,n
    enc=read(O/'input_encoding_bindings.json');assert enc==read(C/'input_encoding_bindings.json')
    for row in enc['bindings']:
        n=row['file'];live=(saved[n]if n in saved else R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R);assert sha256(live).hexdigest()==row['checkout_sha256']and sha256(stored).hexdigest()==row['git_blob_sha256'];assert row['exact_equal']==(live==stored)and row['only_CRLF_to_LF']==(live.replace(b'\r\n',b'\n')==stored)and(row['exact_equal']or row['only_CRLF_to_LF'])
        if live!=stored:assert subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set')
    for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes()
    cap=read(O/'capture.json');assert cap==read(C/'capture.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);result=read(O/'result.json');assert result['elapsed_after_imports']<180;check_lineage();summaries=[]
    for rr,owner in zip(result['roles'],['primary','replay']):
        role=rr['role'];art=rr['artifact'];assert digest(O/art['file'])==art['sha256']and(O/art['file']).stat().st_size==art['bytes'];z=load(O/art['file']);assert z['lineage']==result['lineage'];old=load(B/'canonical_so10_full_jet_source_master_bridge'/(owner+'_tables.json.gz'));u0=load(B/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_GF_common.json.gz'));u1=load(B/'canonical_so10_full_current_inventory_g1_recovery_v1'/(role+'_route_densities.json.gz'));ops=load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));states={n:dict(rows)for n,rows in ops['states'].items()};zeros=[];ng=[];groups=[]
        for pr,c in enumerate(z['all_probe_cases']):
            assert c['probe']==['H','M'][pr];G=choose(old['probes'][pr]['G'],3);QG=choose(old['probes'][pr]['qG'],4);GM=wick_inverse(G);assert a.flat(c['complete_selected_G_Euclidean'])==G and a.flat(c['complete_G_Minkowski'])==GM;scalar_pair_lift(GM,c['fixed_G_tensor_lift'])
            source=sorted({n for w,k in G for n,js in w if n>=643});assert source==c['nonminimal_only_source_ports']and all(n in range(1151,1196)or n in range(1241,1286)for n in source)
            wrong=difference(wick_inverse(G,True),GM);assert wrong and a.flat(c['complete_wrong_time_jet_phase_difference'])==wrong;assert a.flat(c['complete_qualified_source_omission_difference'])==choose(old['probes'][pr]['source_omission_difference'],4)
            assert c['wrong_source_variance_control']=='BLIND_SCALAR_Ja_JLambda_SOURCES'and c['wrong_source_variance_sensitive_groups']==0
            for g,comparison in enumerate(c['all_g0_g1_current_interfaces']):
                target={key:v for key,v in QG.items()if key[1][0]==g};current=choose(u0['probes'][pr]['U']if g==0 else u1['U1'][pr],4,g);assert target==current==a.flat(comparison['complete_reused_FJB_qG'])==a.flat(comparison['complete_current_U']);assert comparison['g']==g and all(not comparison[n]for n in['complete_Euclidean_difference','complete_Minkowski_difference','complete_symmetric_normal'])and comparison['all_four_actual_Minkowski_currents']==[[],[],[],[]]
                clift=comparison['fixed_current_lift'];assert clift['match']and not clift['tensor_groups']and not clift['complete_reconstructed_density']and not clift['complete_residual'];fn='Fu'+str(g)+'_'+str(pr)
                for n in range(508):assert not states[fn][n];zeros.append([fn,n,0])
            ng.append(len(a.encode(G)));groups.append(len(c['fixed_G_tensor_lift']['tensor_groups']))
        assert ng==rr['G_words']==[144,4560]and groups==rr['G_tensor_groups']==[72,2358]and zeros==z['all2032_Fu_physical_port_zeros']and len(zeros)==2032;assert z['surviving_first_u_DS_insertion']=='C_second[U,D_S]+C_first[D_U]'and z['SMA_Ihat_higher_u_and_local_beta_NOT_zeroed'];summaries.append(dict(role=role,primitive_words=ng,tensor_groups=groups,all4_exact_current_probe_density_equalities=True,physical_Fu_zero_ports=len(zeros)));print('STAGE '+role+' independent_G_tensor_current_lineage_complete',flush=True)
    assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)
    assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md']
    state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'and b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V854.md)'in live
    links=[]
    for q,txt in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V854.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V854.md').read_text(encoding='utf-8')),(O/'RESULT.md',(O/'RESULT.md').read_text(encoding='utf-8'))]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([q.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0
    events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[q['exit_code']for q in events if q['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(q for q in events if q['event']=='step_finished'and q['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=32*1024**2
    files=[p for p in O.iterdir()if p.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V854.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_FIXED_LIFTED_BOSONIC_PROBE_MASTER_AND_CARRIER_REDUCTION',base_HEAD=head,state_sha256=state,roles=summaries,full_source_GF_and_separate_physical_base_lineage_authenticated=True,fixed_G_constructor_no_new_D_loop_and_Jacobi_proof_reviewed=True,ordinary_and_first_D_jet_master_root_zeros_supported_in_declared_quotient=True,only_C_second_KD_BSigma_covariance_removed=True,surviving_DS_and_even_U_covariance_NOT_zeroed=True,actual_profile_color_coefficients_fixed_normalizations_W5_E5_NOT_qualified=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',maximum_sampled_primary_private_bytes=max(x['private_bytes']for x in cap['all_resource_samples']),sampled_not_continuous_peak=True,checked_local_links=links,files_excluding_pending_receipt_capture={p.relative_to(R).as_posix():digest(p)for p in files},shared_action_constructor_codec_Python_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
