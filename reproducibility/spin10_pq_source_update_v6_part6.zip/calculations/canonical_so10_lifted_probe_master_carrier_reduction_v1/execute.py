from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/lifted-probe-master-carrier-reduction-v1-2026-11-08')
def digest(p):return sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='4ba9c18bdea331c49f68af06d13a5e4839bb5d8c'and not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).strip()
old=json.loads((R/'calculations/canonical_so10_common_conversion_carrier_v1/preparation_validation.json').read_bytes());names=set(old['sha256'])|{'docs/RESEARCH_EXECUTION_HANDOFF_V853.md','calculations/canonical_so10_common_conversion_carrier_v1/validation_receipt.json','calculations/canonical_so10_common_conversion_carrier_v1/capture_validation.json'}
for folder in['canonical_so10_source_homotopy_applicability_g1_v1','canonical_so10_dimensional_counterterm_applicability','canonical_so10_acceptance_parent_reconciliation_v1','canonical_so10_physical_current_input_recovery_g1_v1','canonical_so10_full_jet_source_master_bridge']:
    for p in(R/'calculations'/folder).iterdir():
        if p.name in['PROOF.md','DERIVATION.md','RESULT.md','validation_receipt.json','final_review_validation_receipt.json','preparation.json','preparation_v2.json','preparation_c_v2.json','primary_tables.json.gz','replay_tables.json.gz','comparison_tables.json.gz','native_union_divergences.json.gz','replay_union_divergences.json.gz','native.py','audit.py']:names.add(p.relative_to(R).as_posix())
names|={'tools/portable_dh_v1/inputs.json.gz','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_GAUGE_EULER_ADAPTER_RESULT.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_gauge_euler_adapter/validation_receipt.json'}
encodings=[]
for n in sorted(names):
    live=(R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R)
    if live!=stored:assert live.replace(b'\r\n',b'\n')==stored and subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set'),n
    encodings.append(dict(file=n,checkout_sha256=sha256(live).hexdigest(),git_blob_sha256=sha256(stored).hexdigest(),exact_equal=live==stored,only_CRLF_to_LF=live.replace(b'\r\n',b'\n')==stored))
C.mkdir(exist_ok=False)
for name,out in[('README.md','README_before.md'),('docs/COMMON_RESTORATION_CAMPAIGN_V1.md','campaign_before.md')]:
    with(C/out).open('xb')as f:f.write((R/name).read_bytes())
with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
dump(O/'input_encoding_bindings.json',dict(bindings=encodings));dump(C/'input_encoding_bindings.json',dict(bindings=encodings))
for n in['RECORD.md','compute.py','execute.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={p.relative_to(R).as_posix()for p in O.iterdir()if p.is_file()};prep=dict(base_HEAD=head,sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation.json',prep);dump(C/'preparation.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute.py')]);dump(O/'capture.json',cap);dump(C/'capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
