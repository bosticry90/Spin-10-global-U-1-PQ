from pathlib import Path
from hashlib import sha256
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/lifted-probe-master-carrier-reduction-v1-2026-11-08')
spec=importlib.util.spec_from_file_location('V854_FIXED_V848_WORD_AND_TENSOR_CONSTRUCTOR',B/'canonical_so10_augmented_metric_lift_v1/algebra.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def dim(n):return 3-dim(n-643)if n>=643 else 2 if 508<=n<553 else 1
def selected(raw,D,g=None):
    out={}
    for(w,k),v in a.flat(raw).items():
        intrinsic=D-sum(dim(n)+len(js)for n,js in w)
        assert intrinsic>=0
        if intrinsic<=1 and k[0]<=1 and(g is None or k[0]==g):out[w,k]=v
    return out
def save(name,z):
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(blob)>8*1024**2:
        with(C/(name+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
        raise AssertionError('COMPLETE_OVERFLOW_NOTPASS')
    with(O/name).open('xb')as f:f.write(blob)
    assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=32*1024**2
    return dict(file=name,sha256=digest(O/name),bytes=len(blob))
def lineage():
    dc=B/'canonical_so10_dimensional_counterterm_applicability';v846=B/'canonical_so10_acceptance_parent_reconciliation_v1';v848=read(B/'canonical_so10_augmented_metric_lift_v1/preparation.json')['sha256'];physical=B/'canonical_so10_physical_current_input_recovery_g1_v1';old=read(dc/'preparation.json')['input_sha256'];portable='tools/portable_dh_v1/inputs.json.gz';ast='tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json'
    def oldbinding(suffix):
        rows=[h for n,h in old.items()if n.replace('\\','/').endswith('/'+suffix)];assert len(rows)==1;return rows[0]
    assert digest(R/portable)==oldbinding(portable)==read(v846/'preparation_c_v2.json')['sha256'][portable]=='7cb864dcef9d47e664c2a7cec3a5d457f2e9872eae7af4f015a0e0bd3fc0edcb'
    assert digest(R/ast)==oldbinding(ast)==read(physical/'preparation_v2.json')['input_sha256'][ast]=='f3cec919dfb38b4a32d0f6ad923961d3fc9ba1b7ecf7b6c63f6c2d00c65bf575'
    assert digest(dc/'validation_receipt.json')==v848[(dc/'validation_receipt.json').relative_to(R).as_posix()]
    assert digest(v846/'validation_receipt.json')==v848[(v846/'validation_receipt.json').relative_to(R).as_posix()]
    sha=read(B/'canonical_so10_source_homotopy_applicability_g1_v1/validation_receipt.json');assert sha['execution_state']=='COMPLETED'and sha['all12_union_divergences_exact']and sha['all15432_constructing_owner_F_E_columns_equal']
    return dict(same_portable_full_GF_source_payload=digest(R/portable),same_approved_physical_AST=digest(R/ast),DCA_receipt_bound_by_V848=digest(dc/'validation_receipt.json'),V846_parent_receipt_bound_by_V848=digest(v846/'validation_receipt.json'),current_SHA_GF1_all12_union_witnesses_authenticated=True,separate_physical_BRST_representation_and_full_Noether_dependencies_bound=True,old_scientific_derivations_reused_NOT_freshly_replayed=True)
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
    bound=lineage();roles=[]
    for role,owner in[('native','primary'),('replay','replay')]:
        fjb=load(B/'canonical_so10_full_jet_source_master_bridge'/(owner+'_tables.json.gz'));u0=load(B/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_GF_common.json.gz'));u1=load(B/'canonical_so10_full_current_inventory_g1_recovery_v1'/(role+'_route_densities.json.gz'));ops=load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));states={n:dict(rows)for n,rows in ops['states'].items()};cases=[];portzeros=[]
        for pr,name in enumerate(['H','M']):
            G=selected(fjb['probes'][pr]['G'],3);QG=selected(fjb['probes'][pr]['qG'],4);sources=sorted({n for w,k in G for n,js in w if n>=643});assert all(1151<=n<1196 or 1241<=n<1286 for n in sources)
            GM=a.unwick(G);lift=a.reconstruct(GM,role);assert lift['match']and all(row['rank']in[0,2]for row in lift['tensor_groups']);wrong=a.unwick(G,omit_time_jets=True);timediff=a.add(wrong,a.scale(GM,-1));assert timediff
            omissions=selected(fjb['probes'][pr]['source_omission_difference'],4);assert omissions
            comparisons=[]
            for g in[0,1]:
                raw=u0['probes'][pr]['U']if g==0 else u1['U1'][pr];current=selected(raw,4,g);target={k:v for k,v in QG.items()if k[1][0]==g};delta=a.add(target,a.scale(current,-1));deltaM=a.unwick(delta);normal,currents=a.sym_normal(deltaM);assert not normal and deltaM==a.div(currents)
                tagged=a.tag_current(currents);clift=a.reconstruct(tagged,role);assert clift['match']and all(row['rank']<=4 for row in clift['tensor_groups'])
                comparisons.append(dict(g=g,complete_reused_FJB_qG=a.encode(target),complete_current_U=a.encode(current),complete_Euclidean_difference=a.encode(delta),complete_Minkowski_difference=a.encode(deltaM),complete_symmetric_normal=a.encode(normal),all_four_actual_Minkowski_currents=[a.encode(q)for q in currents],fixed_current_lift=clift))
                fn='Fu'+str(g)+'_'+str(pr)
                for n in range(508):assert not states[fn][n];portzeros.append([fn,n,0])
            cases.append(dict(probe=name,complete_selected_G_Euclidean=a.encode(G),complete_G_Minkowski=a.encode(GM),nonminimal_only_source_ports=sources,fixed_G_tensor_lift=lift,all_g0_g1_current_interfaces=comparisons,complete_wrong_time_jet_phase_difference=a.encode(timediff),complete_qualified_source_omission_difference=a.encode(omissions),wrong_source_variance_control='BLIND_SCALAR_Ja_JLambda_SOURCES',wrong_source_variance_sensitive_groups=lift['controls']['wrong_source_variance_sensitive_groups']))
        assert len(portzeros)==2032
        artifact=save(role+'_complete_lifted_probe_master_lineage.json.gz',dict(lineage=bound,all_probe_cases=cases,all2032_Fu_physical_port_zeros=portzeros,source_or_field_Wick_phases_NOT_dropped=True,actual_Q_is_transported_V852_operator_NOT_naive_new_bracket=True,rho0_B_blocks_are_scoped_integrated_zeros_subject_to_final_proof=True,surviving_first_u_DS_insertion='C_second[U,D_S]+C_first[D_U]',SMA_Ihat_higher_u_and_local_beta_NOT_zeroed=True))
        roles.append(dict(role=role,artifact=artifact,G_words=[len(c['complete_selected_G_Euclidean'])for c in cases],G_tensor_groups=[len(c['fixed_G_tensor_lift']['tensor_groups'])for c in cases],qG_current_density_difference_words=[[len(z['complete_Euclidean_difference'])for z in c['all_g0_g1_current_interfaces']]for c in cases],actual_current_words=[[sum(len(q)for q in z['all_four_actual_Minkowski_currents'])for z in c['all_g0_g1_current_interfaces']]for c in cases],physical_Fu_zero_ports=len(portzeros)))
        print('STAGE '+role+' G_lift_and_actual_current_interfaces_complete',flush=True)
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='FIXED_LIFTED_BOSONIC_PROBE_MASTER_CARRIER_REDUCTION_SUPPORTED',roles=roles,lineage=bound,all_ordinary_and_first_D_jet_zero_claims_require_final_graph_Jacobi_review=True,discarded_covariance='C_second[K_D,B_Sigma]ONLY',surviving_carrier='C_first[D_Sigma]',surviving_first_u_covariance_NOT_zeroed=True,full_E5_geometric_W5_actual_contact_coefficients_NOT_qualified=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
