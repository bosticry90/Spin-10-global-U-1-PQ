"""Compare the compact scalar Euler root and the linked first-switch jet."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


def load_owner():
    path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
    spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
    owner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(owner)
    return owner


def skew(a, b, c):
    return sp.Matrix([[0, a, b], [-a, 0, c], [-b, -c, 0]])


def compact_jets():
    s, ds, g = sp.symbols("s ds g")
    x = sp.Matrix(sp.symbols("x:3"))
    dx = sp.Matrix(sp.symbols("dx:3"))
    B = skew(1, 2, 0)
    C = skew(-1, 0, 3)
    dC = skew(2, 1, -2)
    assert B*C != C*B and C != dC
    qx = -s*g*C*x
    qdx = -g*(ds*C*x+s*dC*x+s*C*dx)
    qB = s*dC+s*g*(B*C-C*B)
    Bx = B*x
    qBx = qB*x+B*qx
    master = dx.dot(qdx)+s*g*(qdx.dot(Bx)+dx.dot(qBx))+s*g**2*Bx.dot(qBx)
    carrier = -s*ds*Bx.dot(C*x)
    quadratic = sp.expand(master).coeff(g, 2)
    assert sp.expand(quadratic-carrier) == 0
    assert sp.expand(quadratic.subs(ds, 0)) == 0
    assert sp.expand(carrier) != 0

    Y = s*dx+ds*x/2
    qY = s*qdx+ds*qx/2
    assert (qY+s*g*C*Y+s**2*g*dC*x+s*g*ds*C*x).applyfunc(sp.expand) == sp.zeros(3,1)
    Z = sp.Matrix([[2, 1, 0], [1, -3, 2], [0, 2, 1]])
    raw = sp.expand(Y.dot(Z*qY)).coeff(ds, 1).coeff(g, 1).subs(s, 1)
    tensor = sp.Matrix(3, 3, lambda i, j: raw.coeff(dx[i]).coeff(x[j]))
    assert (tensor-tensor.T)/2 == -(Z*C+C*Z)/2
    assert tensor+tensor.T != sp.zeros(3)


def check(phase):
    compact_jets()
    source = load_owner()
    _, entries, _, f, _, _ = source.owner.inputs(phase)
    sectors = (range(12), range(12, 45))
    colors = (1, 12, 13)
    casimir = {}
    for sector in sectors:
        for b in colors:
            K = defaultdict(lambda: sp.S.Zero)
            for a in sector:
                for k, first in f[a,b]:
                    for j, second in f[a,k]:
                        K[j] -= first*second
            casimir[sector.start,b] = source.owner.clean(K)

    omission = []
    for lo, hi, C_s in ((0,54,10), (54,306,sp.Rational(25,2)), (306,326,sp.Rational(9,2))):
        n = hi-lo
        rho = {a:sp.SparseMatrix(n,n,{(i-lo,j-lo):z for (i,j),z in data.items()
                                     if lo<=i<hi and lo<=j<hi}) for a,data in entries.items()}
        zero = sp.SparseMatrix(n,n,{})
        A = [-sum((rho[a]**2 for a in sector),zero).applyfunc(sp.expand) for sector in sectors]
        assert A[0]+A[1] == C_s*sp.eye(n)
        for b in colors:
            first_switch = zero.copy()
            omitted = zero.copy()
            for sector, wave in zip(sectors,A):
                Z = -4*wave
                left = -(Z*rho[b]+rho[b]*Z)/2
                right = zero.copy()
                for a in sector:
                    seagull = -(rho[a]*rho[b]+rho[b]*rho[a])
                    right += seagull*rho[a]+rho[a]*seagull
                term = (left-right).applyfunc(sp.expand)
                K = casimir[sector.start,b]
                target = sum((z*rho[a] for a,z in K.items()),zero).applyfunc(sp.expand)
                assert term == target
                first_switch += term
                omitted += left
            assert rho[b] != zero
            assert first_switch == 8*rho[b]
            assert omitted == 4*C_s*rho[b]
            assert omitted != first_switch
        omission.append(int(4*C_s))
    return {"compact_quadratic_root_from_action": True,
            "compact_wavefunction_skew_part": True,
            "exact_block_sector_color_comparisons": 18,
            "matched_scalar_block_factor": 8,
            "omit_master_factors": omission,
            "first_switch_matrix": "rho((K+sum_S W_S K_S) C)"}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
