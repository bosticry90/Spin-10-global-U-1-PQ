# V962 · Linked scalar kinetic first-switch coefficient

The switched scalar kinetic master equation contributes
`−s(∂s)(ρ_B x)^t ρ_C x` at order `g²`. Its two-edge
pairing cancels the scalar Casimir dependence of the
ordinary wavefunction variation in the local skew
first-switch projection. After adding the lower gauge
source, the coefficient in units of `s²∂s` is
`ρ((K+Σ_S W_S K_S)C)`.

The two exports agree on 18 block, sector and color
comparisons. At equal scalar weights the linked
coefficient gives eight times the scalar generator
in every tested block. The omission control would
give 40, 50 and 18 in Phi, Sigma and ordinary phi.
The symmetric projection and full compact products
are separate. The unit mixed triangle still requires
its own finite matching.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
