# Linked scalar kinetic first-switch coefficient

Use the real scalar convention D x=partial x+g B x,
with B and C represented by skew matrices. Switch the
cubic and seagull by s. The ordinary field drivers are
q x=-s g C x and q B=s partial C+s g[B,C].
At order g2 the derivative-of-ghost terms of the
cubic and seagull cancel. The homogeneous terms
also cancel by skewness. The derivative in q partial x
supplies the remaining compact master root

    -s (partial s) (B x)^t C x.

Thus the root is the negative ordinary seagull
linear in an exterior B, with the latter replaced by
(partial s) C. Paired with one ordinary scalar cubic
this supplies -2 W_S R_S(C) in the skew first-switch
coefficient on the master right-hand side, in units
s^2 partial s. It enters left minus right with plus sign.

At the preserved transverse BB port the switched
cubic derivative is 2Y, with Y=s partial x+(partial s)x/2.
The ordinary two-cubic kinetic term is Y^t Z_S Y/2,
where Z_S=-4 W_S A_S. The compact scalar variation is

    q Y=-s g C Y-s^2 g (partial C)x-s g (partial s) C x.

The homogeneous variation has symmetric scalar matrix.
In the first-switch skew projection the last term
gives -{Z_S,rho(C)}/2. In the ordinary seagull-cubic
variation q B has no free derivative of s. An explicit
derivative of s in 2Y multiplies x^t skew x and vanishes
here. It is outside this argument in the symmetric
projection. V961 accounts for the selected paired mixed
reference terms, which cancel for matched within-pair
profiles. The lower gauge-source first-switch term of
V946 contributes rho(K C) for its gauge-source matrix K.

Therefore the selected linked two-edge residue, in
units s^2 partial s, has matrix

    rho(K C) + sum_S (2 W_S R_S(C)-{Z_S,rho(C)}/2)
      = rho((K+sum_S W_S K_S) C).

The last equality uses the V951 double commutator
with K_S=-sum_(a in S) ad_a^2. The executable checks
the compact Euler root using noncommuting skew
matrices, the wavefunction coefficient, and the color
reduction with both action exports in Phi, Sigma and
ordinary phi. For equal scalar weights W it gives
8 W rho(C) before the gauge-source addition. Omitting
the compact master term leaves 4 C_s W rho(C) in a
block of Casimir C_s, yielding three distinct factors.
These results concern the specified local skew scalar
projection. The mixed unit triangle, exact finite
weights, symmetric longitudinal terms and full compact
products require separate comparisons. Both routes
share the action, conventions, software and authorship.
