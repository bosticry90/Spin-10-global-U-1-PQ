# V962 pre-execution contract

Freeze the ordinary scalar kinetic action at zero background,
the common compact switch, the V961 mixed comparison, the
V946 lower source, and the V951 linked two-edge color map.
Test the first derivative of the common switch in the
local skew B-free scalar jet. Derive the g2 compact master
root directly before using the V951 two-edge trace. Compare
its sign and coefficient with the wavefunction variation,
and check exact scalar blocks with both action exports.
Reject a comparison that omits the g2 master root.
Leave finite weight matching, symmetric scalar tensors
and full compact products separate. No weights adopted.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority change.
