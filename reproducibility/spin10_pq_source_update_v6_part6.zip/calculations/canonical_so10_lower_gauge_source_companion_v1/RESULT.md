# V945 result — the literal lower source matches the upper color map

The lower two-vertex source calculation retains every
derivative placement on the actual B C a cubic and
separates all four internal gauge and ghost sectors.
Both exports give the same exact lower color matrices.

A common stripped weight on the four sectors, with
the transverse free derivative identity preserved,
gives L_B=8 P_M+C_H per unit weight. This differs
from the V944 lower map by 8 I. That scalar shift
does not change the required ghost bracket, so the
lower and upper color comparisons are compatible.
The external ghost derivative is essential to this
agreement. Omitting it fails the comparison.

The result identifies the lower source coefficient
of the specified graph directions. It leaves the
relative physical normalizations, ordinary kinetic
companions, compact switch derivative, auxiliary
partial diagonals and marked products open. Both
routes share the model, software and AI authorship.
