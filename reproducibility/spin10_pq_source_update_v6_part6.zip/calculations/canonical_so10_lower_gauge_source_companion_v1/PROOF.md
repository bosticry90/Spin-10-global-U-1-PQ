# Literal lower derivative companion of the upper color transport

The lower source contraction uses one J_B B C cubic and
one ordinary B C a cubic. The external C belongs to the
ordinary cubic. The two contracted fields there are B
and a. At spatial index 1, separate each placement of
the ordinary derivative and each pair of internal H/M
sectors. The current-order signs are taken from V879
before the common loop and source conversion, as in
V936. The conversion is shared with the upper source
direction when their lower extension weights are compared.

Let w multiply the unjetted two-edge local distribution
and let alpha_a,alpha_B be the coefficients after
integrating their internal derivatives against the
external C jet. The Action Ward identity gives

    alpha_a + alpha_B = -w.

The derivative on the external C has its direct
coefficient +w. In the preserved transverse-numerator
prescription the contraction of the internal B
derivative is exactly zero, hence alpha_B=0. This uses
the preserved free transverse identity in addition to
the Action Ward relation. It need not hold for every
independent finite balanced normalization.

Write C_h and C_m for the H and M blocks of C_H.
The complete stripped color matrices are

    sector         d_a                 d_B           d_C
    HH             -C_h                0             0
    HM             -C_m                0             +C_m
    MH             -C_m                0             0
    MM             -8 I+C_h+2 C_m      -8 P_H+C_h    -8 P_H+C_h

Each matrix is derived twice from the frozen action
exports. Taking the same w on all sectors and using
the transverse derivative allocation gives

    L_B = w(8 P_M+C_H) = w(-8 P_H+C_H)+8 w I.

Thus the literal lower map agrees with the V944
gauge-square requirement up to a scalar identity,
which leaves its required W=0 unchanged. The two
lower sectors with a light internal ghost do not
change the V940 bubble because its quartic has an
internal broken antighost. The external C derivative
is essential. Omitting it changes the H block and
incorrectly alters the comparison.

For a symmetric lower difference R, alternation of W
requires [R b,c]=[b,R c]. Distinct eigenspaces of R
then commute. Metric invariance makes each eigenspace
an ideal, so compact simplicity forces R to be scalar.
The explicit shift above is in precisely that allowed
direction. The corresponding canonical transverse
metric differs from the V944 representative by an
invariant scalar term. This is a positive lower
source color comparison. No finite weight, ordinary
quadratic form or causal scheme has been adopted.
Both routes share the action, conventions, software
and AI authorship.
