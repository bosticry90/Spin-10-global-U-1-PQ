# V945 pre-execution contract

Reconstruct the lower g2 gauge derivative driver for the
V944 upper color tensor. Freeze the literal V879 J_B and
ghost cubics, spatial index 1, the four internal H/M
gauge and ghost sectors, and all derivative placements.
Use the selected transverse contraction convention
and the Action Ward relation on the total derivative
of the two contracted fields.

Compare complete literal lower color matrices with the
light adjoint Casimir formula. Test the common unit
weight on all four lower sectors and its relation to
V944 modulo a scalar identity. Retain the derivative
on the external ghost and require a negative control
without it. This is a lower color and derivative test.
Actual normalization and higher products remain open.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB
sampled private, 350 MiB launch floor, 8 MiB artifact and
32 MiB packet. No authority change.
