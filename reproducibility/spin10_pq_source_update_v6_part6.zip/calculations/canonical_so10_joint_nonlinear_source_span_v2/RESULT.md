# V931 result — common nonlinear source span and fixed-width obstruction

At the V928 unit switch, a single broken-sector auxiliary source
matrix can match the two scalar blocks in the selected Lambda x C
projection when its symmetric part is free. The common map is
constructed from the two orthogonal orbit kernels. The remaining
block terms factor through the scalar orbit matrices, using their
fixed direction with overall vacuum scales canceled.

Keeping the ordinary broken auxiliary width forces that matrix to
be skew when the other width-producing terms are fixed. The exact
pairs for C28 and C20 give the rows (-1/5,-1/4) and (1/5,3/4).
Their determinant is -1/10, so both block logarithmic weights would
have to vanish. The distinct positive reference masses forbid that
at a shared subtraction scale. This witness allows arbitrary scalar
source matrices in the selected projection.

The executable checks all 33 broken width rows, the common lift
conditions for all 33 broken ghost basis directions, and the four
complete literal signed null rows used in the obstruction. The
same-row rank control verifies sensitivity to the second witness.
Native and replay compare separate frozen raw exports and use
the same field conventions, symbolic software and AI research
process. No integration or physical inference enters this result.

The next test is the coupled ordinary and source response of a
companion that supplies the required symmetric width. Include the
mixed auxiliary-gauge term, the scalar mixing and the antighost
driver. In particular, a complete canonical field change already
satisfies the linearized master identity, so its net response must
be distinguished from the effect of a partial companion. Other
source grades, marked terms, loop dependencies and protected
scientific acceptance are outside this test.


The first execution passed replay but was stopped at exact staging
by Windows line endings. The first packet is preserved externally.
The LF V2 packet was rerun against the same scientific criteria.
