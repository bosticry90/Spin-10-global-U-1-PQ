# Shared nonlinear auxiliary source and the ordinary width

Use the V929 current-chart signs, unit switch and constant ordinary
jets. For each active block let E_s have row j equal to
(rho_j v_s)^t and write G_s=E_s E_s^t. The broken ghost c is fixed
in each equation. After the V928 gauge-fermion subtraction, the
V929 residual has row vector

    Delta_s(c)_j^t = [A_s,rho_j] E_s^t e_c,
    A_s = -sum_{h in H} rho_h^2.

The joined representation gives A_s E_s^t = E_s^t K on
the broken columns, where K is the light Casimir on M. The
infinitesimal representation identity gives
rho_j E_s^t e_c = rho_c E_s^t e_j + E_s^t [j,c].
Hence

    Delta_s(c)_j^t = (A_s rho_c - rho_(Kc)) E_s^t e_j
                     + E_s^t U_c e_j,
    U_c j = K[j,c] - [j,Kc].

The right side uses the full joined color bracket, and E_s kills H.
In the executable, the literal row is the signed Euler derivative
of the two gauge fields in V879's C,a current, plus the subtracted
gauge-fermion term. The four complete null rows used below are
checked against the independently derived U_c expression.

For the source equation write

    epsilon_s Delta_s(c) = E_s X_s(c) + V(c)^t E_s.

Here V is a single real matrix in the M auxiliary sector, X_s
is arbitrary per scalar block and a shared nonzero overall factor
is suppressed. Use epsilon_Phi=(6/5)L_Phi,
epsilon_Sigma=(34/25)L_Sigma and
L_Phi-L_Sigma=log(M_Sigma/M_Phi), with the V928 positive distinct
reference masses. On the fixed scalar orbit directions let N_s be
the orthogonal projector onto ker(E_s^t) in M. The exact matrices
have kernel dimensions nine and twelve and N_Phi N_Sigma=0.
Consequently

    V(c) = U_c (epsilon_Phi N_Phi + epsilon_Sigma N_Sigma)

on the broken color subspace, with U_c projected to M, gives
N_s (epsilon_s U_c^t - V^t) E_s=0 for each s. The remaining source
matrix has every column in im E_s, and is absorbed by X_s.
Explicitly one can take

    X_s(c) = epsilon_s (A_s rho_c - rho_(Kc))^t
              + E_s^+ (epsilon_s U_c^t - V^t) E_s.

The two appearances of E_s in the second term have equal overall
vacuum scaling, which cancels before taking a fixed dimensionless
inverse on the admitted orbit direction. This shows unrestricted
source span in this projection.

The ordinary free broken width is xi Lambda^t Lambda/2. With its
action and other width-producing drivers fixed, a source change
V(c)Lambda contributes xi Lambda^t V(c)Lambda, so V(c) must be
skew on M. For j in the Phi kernel and k in the Sigma kernel
the source equation fixes the projection of V(c)j onto the Phi
orbit and of V(c)k onto the Sigma orbit. In particular k lies in
the Phi orbit and j lies in the Sigma orbit. Skewness requires

    epsilon_Phi <k,U_c j> + epsilon_Sigma <j,U_c k> = 0.

The paired rows have k=e21-e18 in both cases. The choices
(j,c)=(e13,e28),(e43,e20) give

    [ -1/5  -1/4 ] [ epsilon_Phi   ]   [ 0 ]
    [  1/5   3/4 ] [ epsilon_Sigma ] = [ 0 ].

The determinant is -1/10. Both epsilons would have to vanish,
incompatible with their nonzero log separation. Allowing any
block scalar matrix in the displayed source equation cannot
change these null pairings. Mixed H/M entries also cannot
change a test entirely in M.

This excludes a common nonlinear source correction at fixed
ordinary width within the stated projection. It also identifies
the symmetric width companion any broader construction must
supply. It leaves the nonlinear antighost partners, correlated
ordinary terms, nilpotency, other quantum profiles and physical
viability as separate obligations. Both data routes share the
action, representation conventions, symbolic software and AI
authorship.

