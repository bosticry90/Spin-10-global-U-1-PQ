# V931 pre-execution contract

Determine whether the residual V928 unit-switch Lambda x C coefficient
after the gauge-fermion subtraction admits a common nonlinear
auxiliary driver. Hold the ordinary width fixed and allow arbitrary
block scalar matrices in this projection. A shared unrestricted source
lift and a fixed-width obstruction are separate results.

Freeze the two real scalar orbit directions, V879 signed source
density and width, V929 residual convention, distinct positive
reference masses, one symbolic common subtraction scale, and broken
colors 12 to 44. Establish orthogonal orbit kernels, check a common
lift on both kernels for every broken ghost color and verify four
full null-row targets directly from the signed source density against
the orbit formula. Test two predeclared symmetric pairings in both
input routes. Fail on a wrong sign, missing width row, failure of the
shared lift, loss of rank, or nonmatching replay. An ordinary
action/driver compensation outside this ansatz is a separate test.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.
Local bounded evidence validation only.


The V1 run and replay completed, but exact Git staging stopped on
a Windows line-ending transformation. The original packet stays
in the V1 D: control record with a complete byte inventory. V2
replays the same scientific criteria with LF source bytes.
