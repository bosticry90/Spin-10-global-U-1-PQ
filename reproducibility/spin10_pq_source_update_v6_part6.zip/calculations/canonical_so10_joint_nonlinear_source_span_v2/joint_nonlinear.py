"""Test common nonlinear source span and its required auxiliary-width term."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


OWNER = ROOT / "calculations/canonical_so10_scalar_source_transport_v2/source_transport.py"
SPEC = importlib.util.spec_from_file_location("scalar_transport_owner", OWNER)
owner = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(owner)
seagull = owner.seagull
M = range(12, 45)
WITNESSES = (({13: 1}, {18: -1, 21: 1}, 28),
             ({43: 1}, {18: -1, 21: 1}, 20))


def column(values):
    return sp.Matrix([values.get(j, 0) for j in M])


def sparse(vector):
    return {j: z for j, z in zip(M, vector) if z}


def add(left, right, alpha=1):
    out = defaultdict(lambda: sp.S.Zero, left)
    seagull.axpy(out, alpha, right)
    return owner.clean(out)


def bracket(f, left, right):
    out = defaultdict(lambda: sp.S.Zero)
    for a, x in left.items():
        for b, y in right.items():
            for i, z in f[a, b]:
                out[i] += x*y*z
    return owner.clean(out)


def on_colors(K, values):
    out = defaultdict(lambda: sp.S.Zero)
    for a, x in values.items():
        seagull.axpy(out, x, K[a])
    return owner.clean(out)


def u_column(f, K, j, c):
    return add(on_colors(K, bracket(f, j, {c: 1})), bracket(f, j, K[c]), -1)


def raw_null_row(rho, K, ghosts, orbit, v, j, c):
    raw = defaultdict(lambda: sp.S.Zero)
    for a, b, i, ghost, z in ghosts:
        if ghost == c and i in j:
            seagull.axpy(raw, -j[i]*z, seagull.apply(rho[b], orbit[a]))
            seagull.axpy(raw, -j[i]*z, seagull.apply(rho[a], orbit[b]))
    gauge_fermion = seagull.apply(rho[c], owner.act(rho, on_colors(K, j), v))
    return add(raw, gauge_fermion)


def literal_width(phase):
    folder = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    width = {}
    for g, word, cells in rows:
        if g == 0 and len(word) == 2 and all(520 <= i < 553 for i, _ in word):
            a, b = [i for i, _ in word]
            assert all(not jets for _, jets in word) and a == b
            assert a not in width and cells == [[[1, 0, 0], 1, 2]]
            width[a] = cells
    assert set(width) == {508+j for j in M}
    return len(width)


def check(phase):
    v_all, _, rho, f, K, ghosts = owner.inputs(phase)
    identity = sp.eye(len(M))
    blocks, projectors = {}, {}
    for name, (start, stop, _) in seagull.BLOCKS.items():
        v = {i: z for i, z in v_all.items() if start <= i < stop}
        orbit = {a: seagull.apply(rho[a], v) for a in range(45)}
        assert all(not orbit[h] for h in range(12))
        G = sp.Matrix([[seagull.dot(orbit[a], orbit[b]) for b in M] for a in M])
        if name == "Phi":
            N = identity-G/25
        else:
            N = (identity-2*G/3)*(identity-10*G/3)
        N = N.applyfunc(sp.expand)
        assert N == N.T and N*N == N and G*N == sp.zeros(len(M))
        # Evaluate the complementary inverse polynomial as a kernel control.
        # For Sigma, G has two distinct nonzero eigenvalues.
        inverse = G/625 if name == "Phi" else (sp.Rational(124, 9)*G-sp.Rational(80, 9)*G**2)
        assert (G*inverse).applyfunc(sp.expand) == identity-N
        projectors[name] = N
        blocks[name] = v, orbit
    NP, NS = projectors["Phi"], projectors["Sigma"]
    assert NP*NS == NS*NP == sp.zeros(len(M))
    assert (NP.trace(), NS.trace()) == (9, 12)
    ep, es = sp.symbols("epsilon_Phi epsilon_Sigma", real=True)
    pairings = []
    checked_ghosts = []
    for j, k, c in WITNESSES:
        jc, kc = column(j), column(k)
        assert NP*jc == jc and NS*kc == kc
        uj, uk = u_column(f, K, j, c), u_column(f, K, k, c)
        for name, null, target in (("Phi", j, uj), ("Sigma", k, uk)):
            v, orbit = blocks[name]
            assert not owner.act(rho, null, v)
            raw = raw_null_row(rho, K, ghosts, orbit, v, null, c)
            assert raw and raw == owner.act(rho, target, v)
        pairings.append([seagull.dot(k, uj), seagull.dot(j, uk)])
    # Verify the simultaneous source lift on the two complete null spaces
    # for every broken ghost basis color, using the joined structure constants.
    for c in M:
        U = sp.Matrix.hstack(*(column(u_column(f, K, {j: 1}, c)) for j in M))
        V = U*(ep*NP+es*NS)
        assert (V*NP-ep*U*NP).applyfunc(sp.expand) == sp.zeros(len(M))
        assert (V*NS-es*U*NS).applyfunc(sp.expand) == sp.zeros(len(M))
        checked_ghosts.append(c)
    matrix = sp.Matrix(pairings)
    assert matrix == sp.Matrix([[-sp.Rational(1, 5), -sp.Rational(1, 4)],
                               [sp.Rational(1, 5), sp.Rational(3, 4)]])
    assert matrix.det() == -sp.Rational(1, 10)
    assert sp.Matrix([[matrix[0, 0], matrix[0, 1]],
                      [-matrix[0, 0], -matrix[0, 1]]]).det() == 0
    ell, lp, ls = sp.symbols("ell L_Phi L_Sigma")
    assert sp.solve((sp.Rational(6, 5)*lp, sp.Rational(34, 25)*ls, lp-ls-ell),
                    (lp, ls, ell)) == {lp: 0, ls: 0, ell: 0}
    return {"kernel_dimensions": {name: int(N.trace()) for name, N in projectors.items()},
            "common_lift_ghosts": len(checked_ghosts),
            "raw_null_rows": 2*len(WITNESSES),
            "width_rows": literal_width(phase),
            "symmetric_pairings": [[str(z) for z in row] for row in pairings],
            "width_determinant": str(matrix.det()),
            "same_row_negative_control": "rank_one",
            "distinct_mass_solution_with_fixed_width": False}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])

