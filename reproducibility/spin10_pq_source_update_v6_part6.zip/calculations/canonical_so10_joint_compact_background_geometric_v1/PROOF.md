# Joint compact background and geometric derivative

Use the same literal V869 parent P=R_A+sigma(S_A+uU−R_A) and the fixed
flat COS1 reference. Take rho=beta=0, first g and first H or M u, with all
sources. Use independent compact even test parameters nu and omega. B
denotes the background operation extended by its action on the quantum
test argument omega. T denotes the geometric quantum operation at fixed
A. C denotes the whole source shift from the full background W.

## Mixed root before traces

Put L=BP, H=TP, M=CP and G=H+M. Work at theta=0 and define M as a
direction in the same parent map. From the full V865 canonical columns,
[B,T]=0 with the extended test transformation. The full W satisfies
BW=0, and canonicality and the left Euler rule give [B,C]=0. For example
on a source the commutator is EL_z(BW). Phase A checks all light-vector
and antighost-source columns and gives two sensitive controls for frozen
omega and a truncated W. The fixed-label brackets instead contain the
negative transformed-parameter operators. Keep these terms if that
convention is used.

The directed first derivative of F at P is I_V. Differentiate the
arbitrary-parent affine Ward identity with respect to an even strength
on V, taking the variation of the whole V. This gives

    B I_V = I_(BV) + F''[L,V].

The same rule with T on L gives T I_L=I_(TL)+F''[H,L]. Hence the mixed
proper identity with the source-shift insertion is

    T I_L + I_(CL) + F''[L,M] = I_((T+C)L) + F''[L,G].

Here BH=TL and BM=CL. In the two even strengths the covariance is symmetric
after summing all ordered derivatives, with both placements of the
insertions in the trace words. This is a derivative of the whole normalized
insertion, so the field-dependent source shift is not applied as an affine
change on a quantum effective action. The direct mixed root must be formed
before evaluating the ordinary Hessian. For the C branch use
(1+sB)(1+theta C)P at the mixed strength. For the T branch use
(1+sB)(1+tT)P and theta=0. Acting with T on the theta-active parent using
the same omega would be a different label count.

## All actual ordinary supports at the selected grades

The exact current grade-zero operations T0 and B0 are translations. T0
replaces only an ordinary light-vector factor. B0 can also replace the
external A factor. They do not act on the already inserted parameter
at grade zero. At grade one the full operator census verifies that the
homogeneous rules preserve the ordinary-field count and the active B_H
and A classes. This includes the grade-one rotation of omega by B. Jet
prolongation redistributes derivatives and preserves these counts.

The literal current source/GF and both complete U packets have no two
remaining ordinary slots after either single grade-zero affine action
on their grade-zero terms. On grade one no term has two slots after one
T0 followed by one B0, including B0 on A. These exclusions use positions
within each word and an independent count inequality, without cancellation
between words. Thus terms with one homogeneous and one affine action on
P0 also have at most one slot. This covers B1T0 and B0T1, including B1
acting on the parameter from T0. It covers grade zero and both grade-one
mixed orders through the verified commutator. All five physical kinetic
ASTs and 29 scalar potential ASTs are retained. The grade-zero terms with
B are quadratic and the grade-one kinetic terms with B are cubic and
have no A. The scalar-only potential terms are unaffected by the affine
actions and remain so after homogeneous rotation. The AST check uses all
field labels and treats every physical B as possibly light for the bound.

The reference at g0 is quadratic. At g1 each ordered linear-connection
term has two ordinary factors and one A or A-jet. T0 removes one ordinary
factor even when B0 acts on A. The scalar masses and widths stay fixed.
Because the switch is inert, the same bounds apply to the literal compact
parent. Integration by parts and the switch-jet currents cannot increase
ordinary degree. In particular the actual affine reference term and the
unreduced cutoff currents remain in L and H.

The full current CS and CU polynomials provide M because C annihilates
R_A and the switch. Their grade-zero terms have at most one ordinary
factor, which the homogeneous B1 preserves. The grade-one B0 action has
at most one ordinary factor after the checked affine replacements. This
checks BM without assuming that an arbitrary C1 source substitution
preserves ordinary degree. Transfer to CL using the full background
commutator. The actual CS1 term with B0_0, b1 and partial0 omega2 has
two ordinary ports. It supplies a positive control on the **single**
insertion. An injected dimension-four quartic with one A and one B gives
a surviving Hessian under the mixed support test. That fixture is separate
from the physical action.

Consequently H_L0, H_H0 and H_M0 vanish, where H_V is the ordinary graded
Hessian of V. All direct mixed roots BH, BM, TL and CL have zero ordinary
Hessian through g1. The zeros are by ordinary slot count, with no
four-dimensional coefficient cancellation that could hide a D jet. The
metric-natural V865/V869 lift and the open-endpoint Euler proof preserve
the same support types. The causal b contraction also needs two ordinary
slots. The full interacting g0 inverse is retained. It has no negative
g powers in the fixed flat Born expansion, so the second derivatives in
the displayed identity start at g2. This proves a zero of the selected
mixed one-loop proper insertion response. It leaves the nonzero tree
parameter and cutoff contacts, and the individual g1 insertions, intact.

## Common coefficient domain and normalization

The two affine field variations have ordinary-field-independent tangent
matrices. In the full A-labeled parent T fixes A and B acts on A, sources
and the test argument. Each additional root has a compact nu or omega
label. A direct mixed root may carry both at one vertex. They are smooth
independent test functions, so their multiplication at a vertex leaves
the independent transfer variables of distinct vertices in the joint
pairing. As in V868 and V869, every fixed expanded flat word uses the same
free edges, balanced jets, and joint soft domain. Ordinary derivatives
add polynomial numerators. The one-loop UV defect formula still holds
with nonnegative defects and no ungraded marginal perturbation of K0.
Four bounded grades g,u,s,t (or theta in place of t) allow at most four
marginal roots, so eight is a conservative bound for local conversion
words. The full nonlocal series stays coefficientwise untruncated.
All new vector substitutions end on actual field, parameter or derivative
slots. The fixed local first dimension jet and the internal quantum traces
are retained. Apply the same converted cyclic trace and independent
Schwartz boundary before smearing. No diagonal restriction of two
distributional observables or second nonlinear Q is made.

Use the total fixed-flat functional for both derivatives. If displaying
the V869 relative split, vary X, Y and the expanded G_A under B. The
isolated pure-reference T derivative is zero as T fixes A, while the
independent A responses and the inherited nonzero Phi reference kernel
remain. The V869 Laurent translation stays in force. Use actual flat
word lengths, both ordered covariance positions and the complete
regulated forest subtraction for the raw heat and COS1 comparison.

For example the raw mixed difference under BT is

    BT F_raw − I_(BH),raw − F_raw''[L,H]
      = I_(BH),D + D''[L,H] − BT D,

where D=C_fin in the heat chart and D=C_fin+b in the causal chart. An
analogous derivative with the actual M applies to the whole product
insertion. This is an identity of the common prescriptions. The mixed
insertion support zeros do not infer that BT of the raw map vanishes,
nor may separate finite raw regulator or affine-measure terms be erased.
The compact proper comparison uses one prescription, with the same
correction for both Ward derivatives. Full connected observable
transport and coincident nonlinear products remain separate obligations.

The input definitions, proofs of the analytic domain and AI authorship
are shared by the two routes. The new coefficient checks address the
actual support and parameter signs. They do not prove the full W1–W7
contract, E5/A5, global limits, or physical viability.
