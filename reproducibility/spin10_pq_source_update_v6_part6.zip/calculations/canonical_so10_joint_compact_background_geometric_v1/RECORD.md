# V870 joint compact background and geometric Ward derivatives

Continue V869 on main, D:, under the current AGENTS policy. Use the same
literal compact R_A-relative parent and fixed flat trace. The new domain has
independent compact even background nu and quantum omega parameters, one
of each, and first g and first H or M u. Start with rho=beta=0 and theta=0
for the mixed Ward equation. An even insertion strength for C_omega(P)
is differentiated once. Keep all external sources. The coupled two-label
Ward derivative is the question, without a second Q variation or a
coincident-point restriction of the two test parameters.

Phase A checks the concrete mixed transport before admitting its quantum
word algebra. Use both V865 packets and V855's quantum columns. Compute
the complete 48 light-vector mixed commutator at first g, including the
prolongation of the background variation of omega. Independently use the
literal W Euler to check the antighost-source columns of [T_b,C_omega].
Compare against a frozen-omega calculation and retain a nonzero actual
J_bar11, nu10, omega9 witness. Dropping full-A terms is an independent
sensitive control. These are classical insertions, not new loop amplitudes.
Root owns writes and execution. Freeze sources and inputs before the run.
Limits are 120 seconds, 8 GiB sampled private allocation, a 350 MiB launch
floor, 8 MiB result and 32 MiB packet.

Phase B must bind the direct mixed insertion, both orders of the second
functional derivative, and the derivatives of the full reference split.
Keep the classical cutoff terms, actual source correction, affine parameter
terms, fixed metric first jet and complete ordered heat and forest factors.
An untransformed quantum parameter requires an explicit commutator term.
The shared compact product domain and allowed root grades must be proved
before inferring a joint proper Ward identity. No protected promotion,
physical adoption, global connected transport, or full E5/A5 claim.
