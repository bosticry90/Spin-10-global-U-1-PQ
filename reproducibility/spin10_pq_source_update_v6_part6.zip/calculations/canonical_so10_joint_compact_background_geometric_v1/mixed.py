"""Exact transport controls for two independently labeled Ward parameters."""

from collections import defaultdict
from functools import lru_cache
from hashlib import sha256
from itertools import product
from pathlib import Path
import json
import os
import sys
import threading
import time


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "canonical_so10_current_background_reference_bridge_v1"))
from compare import CALC, CURRENT, ROOT, clean, coefficient, read


@lru_cache(maxsize=5000)
def prolong(word, jets):
    for_slots = []
    for placements in product(range(len(word)), repeat=len(jets)):
        parts = [(n, list(derivatives)) for n, derivatives in word]
        for mu, slot in zip(jets, placements):
            parts[slot][1].append(mu)
        for_slots.append(tuple((n, tuple(sorted(derivatives))) for n, derivatives in parts))
    return for_slots


def decode(rows, quantum=False):
    def index(n):
        return n + 33 if quantum and 1286 <= n < 1298 else n

    return {(g, tuple((index(n), tuple(jets)) for n, jets in word)): coefficient(cells) for g, word, cells in rows}


def add(*operands):
    total = defaultdict(int)
    for factor, operand in operands:
        for key, value in operand.items():
            total[key] += factor * value
    return clean(total)


def act(poly, rules, parity):
    out = defaultdict(int)
    for (g, word), value in poly.items():
        for slot, (n, jets) in enumerate(word):
            for (h, term), factor in rules.get(n, {}).items():
                if g + h > 1:
                    continue
                for replacement in prolong(term, jets):
                    result = word[:slot] + replacement + word[slot + 1:]
                    # All tested polynomials have at most one odd factor.
                    assert sum(parity[i] for i, _ in result) <= 1
                    out[g + h, tuple(sorted(result))] += value * factor
    return clean(out)


def source_shift(W, parity):
    rows = defaultdict(lambda: defaultdict(int))
    for (g, word), value in W.items():
        odd = [(at, n, jets) for at, (n, jets) in enumerate(word) if parity[n]]
        assert len(odd) == 1
        at, n, jets = odd[0]
        assert 598 <= n < 643
        # The unique odd factor has no odd prefix, so the LEFT jet partial
        # has positive parity sign. Keep the Euler adjoint sign.
        for derivative in prolong(word[:at] + word[at + 1:], jets):
            rows[643 + n][g, tuple(sorted(derivative))] += (-1) ** len(jets) * value
    return {n: clean(poly) for n, poly in rows.items()}


def encode(poly):
    return [[g, word, str(value)] for (g, word), value in sorted(poly.items())]


def run_role(role, owner):
    packet = read(CURRENT / f"{role}_complete_full_background_extension.json.gz")
    geo = read(CALC / "canonical_so10_geometric_ward_current_source_chart_v1" / f"{owner}_complete_geometric_current_source_chart.json.gz")
    parity = packet["joined_parities"]
    tb = {i: decode(rows) for i, rows in packet["all1391_Tb_columns"]}
    tq = {i: decode(rows, quantum=True) for i, rows in geo["all1286_direct_Tq_columns"]}
    parameter = {i: tb[i] for i in range(1319, 1331)}
    fixed = {i: rules for i, rules in tb.items() if i not in parameter}
    vectors = []
    for i in range(48):
        reverse = act(tb[i], tq, parity)
        forward = act(tq[i], fixed, parity)
        transport = act(tq[i], parameter, parity)
        residual = add((1, forward), (-1, reverse))
        assert not add((1, residual), (1, transport))
        vectors.append({"coordinate": i, "frozen_quantum_parameter_residual": encode(residual), "parameter_transport": encode(transport)})
    assert any(row["frozen_quantum_parameter_residual"] for row in vectors)

    W = decode(packet["complete_W"])
    C = source_shift(W, parity)
    no_A = source_shift({(g, word): value for (g, word), value in W.items() if all(not 1331 <= i < 1379 for i, jets in word)}, parity)
    sources = []
    selected = {}
    for j in range(1241, 1286):
        frozen = add((1, act(C.get(j, {}), fixed, parity)), (-1, act(tb[j], C, parity)))
        transport = act(C.get(j, {}), parameter, parity)
        assert not add((1, frozen), (1, transport))
        omitted = add((1, act(no_A.get(j, {}), tb, parity)), (-1, act(tb[j], no_A, parity)))
        sources.append({"coordinate": j, "frozen_quantum_parameter_residual": encode(frozen),
                        "parameter_transport": encode(transport), "omitted_background_residual": encode(omitted)})
        if j == 1252:
            def projection(poly):
                return {key: value for key, value in poly.items() if tuple(i for i, jets in key[1]) == (1328, 1389)}

            witness = {}
            wrong_A = {}
            for mu in range(4):
                first = (1, ((1328, (mu,)), (1389, (mu,))))
                second = (1, ((1328, ()), (1389, (mu, mu))))
                third = (1, ((1328, (mu, mu)), (1389, ())))
                witness.update({first: -2, second: -1, third: -1})
                wrong_A.update({first: 1, second: 1})
            assert projection(frozen) == witness and projection(omitted) == wrong_A
            selected = {"frozen": encode(witness), "no_background": encode(wrong_A)}
    return {"vectors": vectors, "antighost_sources": sources, "selected_J_bar11": selected}


def main():
    started = time.perf_counter()
    watch = threading.Timer(120, lambda: os._exit(124))
    watch.daemon = True
    watch.start()
    for name, expected in read(HERE / "preparation_a.json")["sha256"].items():
        assert sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    native = run_role("native", "primary")
    print("STAGE native actual mixed parameter and source-shift controls matched", flush=True)
    replay = run_role("replay", "replay")
    assert native == replay
    print("STAGE replay actual mixed parameter and source-shift controls matched", flush=True)
    report = {"execution_state": "COMPLETED", "scientific_acceptance": "NOT_PERFORMED",
              "phase": "A_ACTUAL_CLASSICAL_TRANSPORT_CONTROLS", "comparison": native,
              "seconds": time.perf_counter() - started}
    data = (json.dumps(report, sort_keys=True) + "\n").encode()
    name = "result_a.json" if len(data) <= 8 * 1024**2 else "result_a.COMPLETE_OVERFLOW_NOTPASS"
    with (HERE / name).open("xb") as stream:
        stream.write(data)
    assert name == "result_a.json"
    watch.cancel()


if __name__ == "__main__":
    main()
