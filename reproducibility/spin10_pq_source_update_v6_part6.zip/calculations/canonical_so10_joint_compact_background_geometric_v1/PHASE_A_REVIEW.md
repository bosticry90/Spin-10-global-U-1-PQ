# V870 phase A disposition and mixed trace question

Both frozen producer routes agree. The worker took 3.033 seconds and used
242,892,800 bytes peak sampled private memory. All 48 light-vector and all
45 antighost-source mixed commutators cancel with the quantum-parameter
transport included. Freezing that parameter leaves 576 vector and 864
antighost-source coefficient positions. Omitting the background terms in
W leaves 576 source positions. These are actual classical chart controls.
The two-label proper product and final review remain pending.

In the selected J_bar11 column with nu10 and omega9 the frozen-parameter
defect is −g Box(nu10 omega9). The transported parameter supplies the
opposite contact. Dropping full A terms instead leaves
g[(partial nu10)·(partial omega9)+omega9 Box nu10]. All three jet types
are explicit in the saved comparison. The Euler is LEFT and its input is
the full background W, with source-free reference correction zero.

For the next gate write B for the extended T_b, with quantum test argument
transforming as in V865, T for T_q, C for the canonical shift from W, and
L=BP, H=TP, M=CP, G=H+M. The admitted affine derivative of an insertion
is B I_V=I_(BV)+F''[L,V]. The extended classical operators satisfy
[B,T]=[B,C]=0. Therefore the candidate joint proper identity is

    T I_L + I_CL + F''[L,M] = I_((T+C)L) + F''[L,G].

Here T I_L=I_TL+F''[H,L]. In the fixed-label convention include the
negative adjoint test contact explicitly. The mixed root and the full
ordered covariance are defined by derivatives of the same functional.
The raw heat and causal residuals are the derivatives of the respective
complete C_fin or C_fin+b differences, including the whole parent and
insertion normalization. In a split reference notation B acts on G_A and
Y. The isolated pure-reference T variation is zero because T fixes A,
while the separate A responses of the reference are retained.

A read-only support diagnostic suggests a cheaper phase B route. At g0
no GF/source, H or M probe word retains two ordinary ports after an active
affine B or A replacement. The qualified g0 CS/CU have at most one ordinary
factor. At g1 the diagnostic finds no two-ordinary-port surviving placements
from two affine replacements in those S/U words, or one affine replacement
in the C(S/U) words. Freeze and independently check these full support
conditions, the physical AST and R_A. Homogeneous first-g substitutions
must preserve the active affine support classes. Derivatives of the switch
do not increase ordinary degree. If the gates pass, the g1 mixed one-loop
coefficient can be disposed of by support, while the tree cutoff and
parameter terms stay nonzero. This scan is not phase B evidence and gives
no higher-g covariance zero.
