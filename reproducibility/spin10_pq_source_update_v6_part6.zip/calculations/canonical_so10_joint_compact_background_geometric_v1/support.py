"""Certify ordinary-field support without expanding unneeded insertions."""

from collections import Counter
from fractions import Fraction
from hashlib import sha256
from itertools import product
import json
import os
import threading
import time

from mixed import CALC, CURRENT, HERE, ROOT, read


PHYSICAL = ROOT / "tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json"


def category(i):
    for end, label in ((48, "B"), (643, "field"), (1286, "J"), (1319, "eps"), (1331, "omega"), (1379, "A"), (1391, "nu")):
        if i < end:
            return label
    raise ValueError(i)


def verify_columns(tb, tq):
    shapes = []
    for background, columns in ((True, tb), (False, tq)):
        assert [i for i, rows in columns] == list(range(1391 if background else 1286))
        affine = []
        homogeneous = Counter()
        for i, rows in columns:
            target = category(i)
            for grade, word, cells in rows:
                assert cells
                if grade == 0:
                    assert target == "B" or background and target == "A"
                    offset = i if target == "B" else i - 1331
                    base = 1379 if background else 1286
                    assert word == [[base + offset // 4, [offset % 4]]]
                    assert cells == [[[0, 0, 0], 1, 1]]
                    affine.append(i)
                else:
                    assert grade == 1 and len(word) == 2 and all(not jets for _, jets in word)
                    source, label = (n for n, jets in word)
                    assert category(source) == target
                    assert (1379 <= label < 1391 if background else 1286 <= label < 1298)
                    assert target in {"B", "field", "J", "A", "omega"}
                    homogeneous[target] += 1
        assert affine == list(range(48)) + (list(range(1331, 1379)) if background else [])
        shapes.append({"affine_outputs": affine, "homogeneous_counts": homogeneous})
    return shapes


def degrees(types):
    return sum(label in {"B", "field"} for label in types)


def bound_by_slots(types, actions):
    if not actions:
        return degrees(types)
    first, *remaining = actions
    return max((bound_by_slots(types[:i] + types[i + 1:], remaining) for i, label in enumerate(types) if label in first), default=-1)


def bound_by_counts(types, actions):
    ordinary, B, A = degrees(types), types.count("B"), types.count("A")
    if len(actions) == 2:
        assert actions == ("B", "BA")
        return max(ordinary - 2 if B >= 2 else -1, ordinary - 1 if B and A else -1)
    return max(ordinary - 1 if B else -1, ordinary if actions == ("BA",) and A else -1)


def support_table(rows, source_shift=False):
    census = Counter()
    maxima = Counter()
    bad = []
    for row_id, (grade, types) in enumerate(rows):
        assert grade in (0, 1)
        n = degrees(types)
        census[grade, n, types.count("B"), types.count("A")] += 1
        if source_shift and grade == 0:
            # The homogeneous first-g background operation preserves n.
            possibilities = {"M0_and_B1M0": n, "B0M0": bound_by_slots(types, ("BA",))}
        elif source_shift:
            possibilities = {"B0M1": bound_by_slots(types, ("BA",))}
        elif grade == 0:
            # One affine is necessary in every mixed first-g term from P0.
            # The other action preserves the active classes or acts on omega.
            possibilities = {"T0P0": bound_by_slots(types, ("B",)), "B0P0": bound_by_slots(types, ("BA",))}
        else:
            possibilities = {"B0T0P1": bound_by_slots(types, ("B", "BA"))}
        for name, value in possibilities.items():
            actions = {"T0P0": ("B",), "B0T0P1": ("B", "BA")}.get(name, ("BA",))
            if name != "M0_and_B1M0":
                assert value == bound_by_counts(types, actions)
            if value >= 0:
                maxima[name, value] += 1
            if value > 1:
                bad.append([row_id, name, value])
    return {"census": [[*key, count] for key, count in sorted(census.items())],
            "remaining_degree_counts": [[*key, count] for key, count in sorted(maxima.items())], "survivors": bad}


def ast_support(node):
    kind = node["node"]
    if kind == "Field":
        return {(0, ("B" if node["name"] == "B" else "field",))}
    if kind in {"ExactScalar", "Parameter", "RepresentationGenerator", "StructureConstant"}:
        return {(int(kind == "Parameter" and node["name"] == "g10"), ())}
    if kind == "PartialDerivative":
        return ast_support(node["argument"])
    if kind in {"LorentzContraction", "GroupContraction"}:
        return ast_support(node["expression"] if "expression" in node else node["argument"])
    if kind == "Add":
        return set.union(*(ast_support(term) for term in node["terms"]))
    assert kind == "OrderedProduct", kind
    result = {(0, ())}
    for factor in node["factors"]:
        result = {(g + h, tuple(sorted(left + right))) for (g, left), (h, right) in product(result, ast_support(factor))}
    return result


def physical_support():
    packet = read(PHYSICAL)
    assert not packet["sources"] and not packet["gauge_fixing_included"]
    assert len(packet["local_terms"]) == 34
    report = []
    allowed_fields = {"B", "Phi", "Sigma", "SigmaBar", "phi", "phiBar", "S", "SBar", "x_Phi", "x_Sigma", "x_phi", "x_S"}

    def check_fields(node):
        if isinstance(node, dict):
            if node.get("node") == "Field":
                assert node["name"] in allowed_fields
            for value in node.values():
                check_fields(value)
        elif isinstance(node, list):
            for value in node:
                check_fields(value)

    for term in packet["local_terms"]:
        check_fields(term["density"])
        types = sorted(ast_support(term["density"]))
        support = support_table((grade, fields) for grade, fields in types if grade <= 1)
        if term["sector"] == "PARENT_SCALAR_POTENTIAL":
            assert all("B" not in fields and grade == 0 for grade, fields in types)
        report.append({"term": term["term_id"], "sector": term["sector"], "signatures": types, **support})
    assert sum(row["sector"] == "PARENT_SCALAR_POTENTIAL" for row in report) == 29
    return report


def reference_support():
    v869 = CALC / "canonical_so10_current_background_reference_bridge_v1"
    base = read(v869 / "result_a.json")["compared"]["transported_ordered_Weyl_coefficients"]
    linear = read(v869 / "result_b.json")["connection_expansion"]
    assert len(base) == 4025 and len(linear) == 78640
    rows = [(0, (category(i), category(j))) for i, j, jets, value in base]
    rows.extend((1, (category(i), category(j), "A")) for h, mu, jets, on_field, i, j, value in linear)
    assert all(degrees(types) == 2 for grade, types in rows)
    return support_table(rows)


def role_support(role, owner):
    data = read(CURRENT / f"{role}_complete_full_background_extension.json.gz")
    geometric = read(CALC / "canonical_so10_geometric_ward_current_source_chart_v1" / f"{owner}_complete_geometric_current_source_chart.json.gz")
    assert not data["complete_TbW"] and len(data["all1286_mixed_algebra_residuals"]) == 1286
    assert not any(rows for i, rows in data["all1286_mixed_algebra_residuals"])
    polynomials = {"S_GF_source": data["complete_S_GF_source"], "CS": data["complete_CS"]}
    for probe in data["probes"]:
        polynomials[f"U_{probe['probe']}"] = probe["complete_U"]
        polynomials[f"CU_{probe['probe']}"] = probe["complete_CU"]
    tables = {}
    for name, rows in polynomials.items():
        types = ((g, tuple(category(i) for i, jets in word)) for g, word, cells in rows)
        tables[name] = support_table(types, source_shift=name.startswith("C"))
    witness = [1, [[0, []], [509, []], [1321, [0]]], [[[0, 0, 21], 1, 4]]]
    assert witness in polynomials["CS"]
    return {"operators": verify_columns(data["all1391_Tb_columns"], geometric["all1286_direct_Tq_columns"]),
            "tables": tables, "actual_CS1_two_ordinary_ports": witness}


def controls():
    fixture = support_table([(1, ("A", "B", "field", "field"))])
    assert fixture["survivors"] == [[0, "B0T0P1", 2]]
    # Finite proper log fixture: H=diag(2,3), L=diag(1,0), Hq=I,
    # mixed derivative N=diag(0,1). No physical coefficient is inferred.
    inverse = (Fraction(1, 2), Fraction(1, 3))
    direct = sum(G * n for G, n in zip(inverse, (0, 1)))
    each_order = sum(G * l * G * h for G, l, h in zip(inverse, (1, 0), (1, 1))) / 2
    assert direct - 2 * each_order == Fraction(1, 12)
    return {"two_affine_surviving_quadratic": fixture, "log_derivative_without_common_half": str(direct - 2 * each_order),
            "direct": str(direct), "each_order": str(each_order)}


def main():
    started = time.perf_counter()
    watch = threading.Timer(120, lambda: os._exit(124))
    watch.daemon = True
    watch.start()
    for name, expected in read(HERE / "preparation_b.json")["sha256"].items():
        assert sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    native = role_support("native", "primary")
    print("STAGE native complete support tables built", flush=True)
    replay = role_support("replay", "replay")
    assert native == replay
    print("STAGE replay complete support tables agree", flush=True)
    physical = physical_support()
    reference = reference_support()
    bad = [name for name, table in native["tables"].items() if table["survivors"]]
    bad += [row["term"] for row in physical if row["survivors"]]
    if reference["survivors"]:
        bad.append("reference")
    result = {"execution_state": "FAILED_SUPPORT_GATE" if bad else "COMPLETED", "scientific_acceptance": "NOT_PERFORMED",
              "role_comparison": native, "physical": physical, "reference": reference, "controls": controls(),
              "nonempty_survivor_tables": bad, "seconds": time.perf_counter() - started}
    data = (json.dumps(result, sort_keys=True) + "\n").encode()
    name = "result_b.json" if len(data) <= 8 * 1024**2 else "result_b.COMPLETE_OVERFLOW_NOTPASS"
    with (HERE / name).open("xb") as stream:
        stream.write(data)
    assert name == "result_b.json" and not bad
    watch.cancel()


if __name__ == "__main__":
    main()
