"""Final support and exact transport verification, followed by the E4 audit."""

from fractions import Fraction
from hashlib import sha256
import json
import os
import subprocess
import sys
import threading
import time

from execute_a import CONTROL, HERE, ROOT, git, save
from support import CALC, CURRENT, PHYSICAL, read
from compare import exact


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def current_audit(result):
    report = {}
    for role in ("native", "replay"):
        data = read(CURRENT / f"{role}_complete_full_background_extension.json.gz")
        polynomials = {"S_GF_source": data["complete_S_GF_source"], "CS": data["complete_CS"]}
        for probe in data["probes"]:
            polynomials[f"U_{probe['probe']}"] = probe["complete_U"]
            polynomials[f"CU_{probe['probe']}"] = probe["complete_CU"]
        for name, rows in polynomials.items():
            for g, word, cells in rows:
                fields = [i for i, jets in word if i < 643]
                light = [i for i in fields if i < 48]
                background = any(1331 <= i < 1379 for i, jets in word)
                if name.startswith("C"):
                    if g == 0:
                        assert len(fields) < 2, name
                    elif background or light:
                        assert len(fields) < (2 if background else 3), name
                elif g == 0:
                    if background or light:
                        assert len(fields) < (2 if background else 3), name
                elif light:
                    assert not (background and len(fields) >= 3), name
                    assert not (len(light) > 1 and len(fields) >= 4), name
            entry = result["role_comparison"]["tables"][name]
            assert not entry["survivors"] and sum(row[-1] for row in entry["census"]) == len(rows)
            assert all(degree <= 1 for _, degree, _ in entry["remaining_degree_counts"])
        report[role] = {name: len(rows) for name, rows in polynomials.items()}
    return report


def owner_support(result):
    terms = read(PHYSICAL)["local_terms"]
    assert [term["term_id"] for term in terms] == [term["term"] for term in result["physical"]]
    for term in result["physical"]:
        assert not term["survivors"]
        if term["sector"] == "PARENT_SCALAR_POTENTIAL":
            assert all(g == 0 and "B" not in names and "A" not in names for g, names in term["signatures"])
        else:
            for g, names in term["signatures"]:
                assert "A" not in names
                if "B" in names and g <= 1:
                    assert len(names) == 2 + g
    assert len(result["physical"]) == 34
    ref = result["reference"]
    assert not ref["survivors"]
    assert sum(row[-1] for row in ref["census"]) == 4025 + 78640
    assert all(degree == 2 and A == grade for grade, degree, B, A, count in ref["census"])
    fixture = result["controls"]
    assert fixture["two_affine_surviving_quadratic"]["survivors"] == [[0, "B0T0P1", 2]]
    # The diagonal two-by-two fixture reduces to scalar log derivatives.
    first, second = Fraction(-1, 2 * 2), Fraction(1, 3)
    assert first + second == Fraction(fixture["log_derivative_without_common_half"]) == Fraction(1, 12)


def transport_audit():
    def coefficients(rows):
        return {(g, tuple((i, tuple(jets)) for i, jets in word)): value for g, word, value in rows}

    packet = read(HERE / "result_a.json")["comparison"]
    for section, expected in (("vectors", 576), ("antighost_sources", 864)):
        positions = 0
        for row in packet[section]:
            frozen = coefficients(row["frozen_quantum_parameter_residual"])
            actual = coefficients(row["parameter_transport"])
            assert frozen.keys() == actual.keys()
            assert all(exact(value) + exact(actual[key]) == 0 for key, value in frozen.items())
            positions += len(frozen)
        assert positions == expected
    assert len(packet["vectors"]) == 48 and len(packet["antighost_sources"]) == 45
    assert sum(len(row["omitted_background_residual"]) for row in packet["antighost_sources"]) == 576
    selected = packet["selected_J_bar11"]
    assert sorted(int(row[2]) for row in selected["frozen"]) == [-2] * 4 + [-1] * 8
    assert sorted(int(row[2]) for row in selected["no_background"]) == [1] * 8
    return {"vector_positions": 576, "source_positions": 864, "omitted_background_source_positions": 576}


def main():
    started = time.perf_counter()
    watch = threading.Timer(180, lambda: os._exit(124))
    watch.daemon = True
    watch.start()
    prep = read(HERE / "preparation_validation.json")
    assert prep["base_HEAD"] == git("rev-parse", "HEAD").decode().strip()
    assert git("ls-tree", "-r", "HEAD") == (CONTROL / "old_git_tree.txt").read_bytes()
    assert not git("diff", "--cached", "--name-only")
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    for phase in ("a", "b"):
        for prefix in ("preparation", "capture"):
            name = f"{prefix}_{phase}.json"
            assert (HERE / name).read_bytes() == (CONTROL / name).read_bytes()
        capture = read(HERE / f"capture_{phase}.json")
        assert capture["calculation_completed"] and capture["post_run_observations_qualified"]
    for source in HERE.glob("*.source.txt"):
        assert source.read_bytes() == (HERE / source.name.removesuffix(".source.txt")).read_bytes()
    for name in prep["owner_receipts"]:
        assert read(ROOT / name)["execution_state"] == "COMPLETED", name

    b = read(HERE / "result_b.json")
    assert b["execution_state"] == "COMPLETED" and not b["nonempty_survivor_tables"]
    owners = current_audit(b)
    owner_support(b)
    transport = transport_audit()
    print("STAGE complete support and mixed source transport independently checked", flush=True)

    e4 = subprocess.run([sys.executable, "-B", "tools/research_check.py", "e4", "--historical-context",
                         "D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4"],
                        cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=120)
    save("e4_capture.json", {"exit_code": e4.returncode, "stdout": e4.stdout, "stderr": e4.stderr})
    events = [json.loads(line) for line in e4.stdout.splitlines() if line.strip()]
    steps = [event for event in events if event.get("event") == "step_finished"]
    exits = [event["exit_code"] for event in steps]
    assert e4.returncode == 0 and exits == [0, 0, 0, 0, 0, 2]
    custody = next(event for event in steps if event["step"] == "historical_custody")
    assert custody["stdout"].count("RECORDED_DIGEST_UNRESOLVED:") == 7
    historic = git("show", "ef70f255a667b9a81e37b344dc78967ada4ed896:README.md")
    assert sha256(historic).hexdigest() == "4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792"
    assert (ROOT / "README.md").read_bytes().replace(b"\r\n", b"\n").endswith(historic)
    assert digest(ROOT / "project_state.json") == "d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8"
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    paths = [path for path in HERE.iterdir() if path.is_file()]
    assert sum(path.stat().st_size for path in paths) <= 32 * 1024**2
    paths.extend(ROOT / name for name in prep["navigation"])
    save("validation_receipt.json", {
        "execution_state": "COMPLETED", "evidence_validation": "PASS_SELECTED_JOINT_COMPACT_WARD_MIXED_SUPPORT",
        "scientific_acceptance": "NOT_PERFORMED", "base_HEAD": prep["base_HEAD"],
        "state_sha256": digest(ROOT / "project_state.json"), "owner_receipts": prep["owner_receipts"],
        "current_ordinary_support_counts": owners, "transport_checks": transport,
        "E4_step_exits": exits, "historical_custody": "SEVEN_UNRESOLVED_NOTPASS",
        "files_excluding_pending_receipt_capture": {path.relative_to(ROOT).as_posix(): digest(path) for path in paths},
        "elapsed_after_imports": time.perf_counter() - started,
    })
    watch.cancel()


if __name__ == "__main__":
    main()
