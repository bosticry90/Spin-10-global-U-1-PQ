"""Freeze the compact mixed Ward phase A check before running it."""

from hashlib import sha256
from pathlib import Path
import ast
import json
import subprocess
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CONTROL = Path("D:/Codex-Research/ToE-Next/research-control-records/joint-compact-background-geometric-v1-2026-11-08")
PK = ROOT / "tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1"


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def save(filename, report):
    data = (json.dumps(report, sort_keys=True) + "\n").encode()
    for folder in (HERE, CONTROL):
        with (folder / filename).open("xb") as stream:
            stream.write(data)


def main():
    head = git("rev-parse", "HEAD").decode().strip()
    assert head == "3fd9ae1f31734ba84f458e0804701d912cc4b6fd"
    assert not git("diff", "--name-only", "HEAD")
    names = {"AGENTS.md", "CHARTER.md", "project_state.json", "docs/RESEARCH_EXECUTION_HANDOFF_V869.md"}
    records = {
        "current_background_reference_bridge_v1": ("compare.py", "PROOF.md", "validation_receipt.json"),
        "joint_common_family_applicability_v1": ("PROOF.md", "validation_receipt.json", "native_complete_full_background_extension.json.gz", "replay_complete_full_background_extension.json.gz"),
        "geometric_ward_current_source_chart_v1": ("validation_receipt_v2.json", "primary_complete_geometric_current_source_chart.json.gz", "replay_complete_geometric_current_source_chart.json.gz"),
    }
    for folder, filenames in records.items():
        names.update(f"calculations/canonical_so10_{folder}/{name}" for name in filenames)
    names.add((PK / "export_a10_e5_antighost_vector.py").relative_to(ROOT).as_posix())
    assert all((ROOT / name).is_file() for name in names)
    CONTROL.mkdir(exist_ok=False)
    with (CONTROL / "old_git_tree.txt").open("xb") as stream:
        stream.write(git("ls-tree", "-r", "HEAD"))
    for name in ("RECORD.md", "mixed.py", "execute_a.py"):
        data = (HERE / name).read_bytes()
        if name.endswith(".py"):
            ast.parse(data)
        with (HERE / (name + ".source.txt")).open("xb") as stream:
            stream.write(data)
    names.update(path.relative_to(ROOT).as_posix() for path in HERE.iterdir() if path.is_file())
    save("preparation_a.json", {
        "base_HEAD": head,
        "sha256": {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in sorted(names)},
        "limits": {"seconds": 120, "sampled_private_bytes": 8 * 1024**3, "packet_bytes": 32 * 1024**2,
                   "artifact_bytes": 8 * 1024**2, "minimum_available_commit_bytes": 350 * 1024**2},
        "scientific_acceptance": "NOT_PERFORMED",
    })
    sys.path.insert(0, str(PK))
    from export_a10_e5_antighost_vector import capture

    report = capture([sys.executable, "-B", str(HERE / "mixed.py")])
    save("capture_a.json", report)
    print(report["stdout_and_stderr"], end="")
    assert report["calculation_completed"] and report["post_run_observations_qualified"]
    assert sum(path.stat().st_size for path in HERE.iterdir() if path.is_file()) <= 32 * 1024**2


if __name__ == "__main__":
    main()
