# V870 phase B support and shared proper map

Bind the completed phase A evidence, V869 base and exact current parent
owners before execution. Keep the original scoped domain. Use one local
even background parameter and one local even quantum parameter, first g,
first H or M probe, rho=beta=0. The source-shift insertion is differentiated
once. Use the fixed flat proper map and literal compact R_A-relative action.
All external sources and cutoff currents stay in the equations.

Check the whole homogeneous and affine operator shape on the current
V855/V865 charts. For every current S_GF/source, U_H/M and their whole
C images, compare exact active-slot enumeration with count inequalities.
Admit the five kinetic and 29 potential terms from the physical action
AST and the two grades of the reference from V869's ordered kernels.
Require each relevant single g0 direction and mixed g0/g1 root to have
at most one ordinary field. A nonzero survivor is retained, not declared
zero. Check a two-affine quartic fixture with an external A factor to
ensure the test would detect a surviving Hessian. Test the two distinct
ordered covariance factors on a finite matrix fixture.

The worker has 120 seconds, 8 GiB sampled private allocation, a 350 MiB
launch floor, 8 MiB result and 32 MiB packet. Keep exact captures. Only
claim support zeros on the actual proper coefficients in this domain.
Keep full classical root expressions and the raw map's differentiated
regulator and normalization defects. The proof uses the qualified domain
and common converted trace. A mismatch or analytic gap leaves the claim
unqualified. Separate review and E4 validation precede any local commit.
