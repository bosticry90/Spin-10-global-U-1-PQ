# V870 separate final review

Bind the two producer packets and the source snapshots, input manifests,
owner receipts and current navigation before the final run. The limit is
180 seconds, 8 GiB sampled private allocation and a 350 MiB launch floor.
The E4 subprocess has 120 seconds. Retain the original 32 MiB packet limit.

Independently test all actual current rows with the support predicates,
both physical and reference families, and the full phase A cancellation
and sensitive controls. Check the maximum remaining ordinary degree and
the actual g1 single-insertion witness. The proof review must retain the
actual affine, source and parameter transformations, the ordered proper
derivative, and the unremoved classical and raw-map terms.

Require E4 exit 0 with steps 0,0,0,0,0,2 and seven recorded unresolved
custody references. Preserve the historical README suffix and unchanged
project_state.json. A failure or exhausted limit leaves the relevant claim
unqualified. The review permits a scoped local evidence commit and no
protected scientific promotion.
