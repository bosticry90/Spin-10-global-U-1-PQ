# V905 pre-execution contract

Bind the actual Minkowski switched kinetic and mixed
quadratic sources. Test the scalar Hardy route on the
generic free gauge double pole and mixed derivative.
Derive the exact conjugated density and the divergence
equation, and qualify the two normally hyperbolic
preconditioners and individual massive scalar lines
by the V901 bound. Retain all width and source factors,
no substitution of the auxiliary preconditioning gauge
into the actual equations. Require the actual retarded and advanced constrained inverse
by a propagated constraint. Keep the coupled Feynman kernel
and loop sums explicitly open.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB
sampled private, 350 MiB launch floor, 8 MiB artifact and
32 MiB packet. Require exact replay and staged receipt.
