"""Exact switch-density and constrained-wave controls for V905."""

import json
import sys

import sympy as sp

from execute import PK, run_worker


def wedge_route(phase):
    metric = sp.diag(1, -1, -1, -1)
    s = sp.Matrix(sp.symbols("s0:4"))
    B = sp.Matrix(sp.symbols("B0:4"))
    u = sp.symbols("F0:6")
    F = sp.zeros(4)
    for index, (i, j) in enumerate((i, j) for i in range(4) for j in range(i+1, 4)):
        F[i, j], F[j, i] = u[index], -u[index]
    wedge = s*B.T-B*s.T

    def contract(A, D):
        return sp.trace(A.T*metric*D*metric)

    if phase == "native":
        original = -contract(F, F)/4+(s.T*metric*F*metric*B)[0]/2
        completed = -contract(F-wedge/2, F-wedge/2)/4+contract(wedge, wedge)/16
    else:
        original = -contract(F, F)/4+contract(F, wedge)/4
        completed = -(contract(F, F)-contract(F, wedge)+contract(wedge, wedge)/4)/4 \
                    + contract(wedge, wedge)/16
    assert sp.expand(original-completed) == 0
    V = contract(wedge, wedge)/16
    raised_euler = sp.Matrix([sp.diff(V,b) for b in B])
    expected = ((s.T*metric*s)[0]*metric*B-metric*s*(s.T*metric*B)[0])/4
    assert all(sp.expand(x) == 0 for x in raised_euler-expected)
    return {"square_completion": "exact", "potential": "a*(s2*I-s_up*s_down)/4",
            "mixed_transform": "-lambda*div(b)"}


def residual_route(phase):
    t, x, w = sp.symbols("t x w", real=True)
    sigma = t*x+x*x/3 if phase == "native" else t*t/2-t*x
    a = sp.exp(sigma)
    coords = (t, x)
    metric = sp.diag(1, -1)
    lower_s = sp.Matrix([sp.diff(sigma,q) for q in coords])
    upper_s = metric*lower_s

    def grad(f):
        return metric*sp.Matrix([sp.diff(f,q) for q in coords])

    def div(v):
        return sum(sp.diff(c,q) for c,q in zip(v,coords))

    b = sp.Matrix([t*t+x,t-x*x]) if phase == "native" else sp.Matrix([x*t,x*x+t])
    lam, j = t+2*x*x, t*x
    J = sp.Matrix([t*x*x,x+t*t])
    F = grad(b[1])[0]-grad(b[0])[1]
    M = sp.Matrix([-sp.diff(a*F,x),sp.diff(a*F,t)])
    W = a*((lower_s.T*upper_s)[0]*sp.eye(2)-upper_s*lower_s.T)/4
    assert sp.simplify(div(M)) == 0

    L = div(b)+(lower_s.T*b)[0]
    N = M/a+grad(L)+W*b/a
    Hess = metric*sp.hessian(sigma,coords)
    wave = sp.Matrix([div(grad(c)) for c in b])
    along = b.jacobian(coords)*upper_s
    assert all(sp.simplify(z) == 0 for z in N-wave-along-Hess*b-W*b/a)

    C = div(b)+j-w*lam/a
    rhs = J/a-grad(j)+grad((lower_s.T*b)[0])+(w-1)*grad(lam)/a-w*upper_s*lam/a
    original = M+W*b+grad(lam)-J
    assert all(sp.simplify(z) == 0 for z in original-a*(N-rhs-grad(C)))
    assert sp.simplify(div(original)-(div(grad(lam))+div(W*b)-div(J))) == 0
    # Width zero does not remove the first-order lambda coupling.
    assert (w-1).subs(w,0) == -1

    f = t*t+t*x+x
    for beta, alpha, U in (
        (1,-sp.Rational(1,2),-div(grad(sigma))/2-(lower_s.T*upper_s)[0]/4),
        (-sp.Rational(1,2),sp.Rational(1,4),div(grad(sigma))/4-(lower_s.T*upper_s)[0]/16),
    ):
        Y = sp.exp(alpha*sigma)*f
        conjugated = (div(grad(Y))+beta*(lower_s.T*grad(Y))[0])*sp.exp(-alpha*sigma)
        assert sp.simplify(conjugated-div(grad(f))-U*f) == 0
    return {"constraint": "div(a*d*C)=0", "vector_residual": "-a*d*C",
            "normally_hyperbolic_principal": "Box*I5",
            "gradient_potential": "Box(sigma)/4-s2/16"}


def inverse_controls():
    z, r = sp.symbols("z r", positive=True)
    G = -sp.exp(sp.I*sp.sqrt(z)*r)/(4*sp.pi*r)
    dipole = sp.I*sp.exp(sp.I*sp.sqrt(z)*r)/(8*sp.pi*sp.sqrt(z))
    assert sp.simplify(-sp.diff(G,z)-dipole) == 0
    gamma = sp.symbols("gamma", positive=True)
    assert sp.integrate(sp.exp(-2*gamma*r),(r,0,sp.oo)) == 1/(2*gamma)
    return {"dipole_kernel_prefactor": "i/(8*pi*k)", "dipole_squared_weighted_norm": "O(1/Im(k))",
            "mixed_same_weight_high_tau_factor": "abs(tau)",
            "massive_bound": "same Newton domination"}


def check(phase):
    file = PK / "frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json"
    first = json.loads(file.read_bytes())["local_terms"][0]
    assert first["term_id"] == "gauge" and first["density"]["metric"] == "diag(1,-1,-1,-1)"
    assert first["density"]["expression"]["expression"]["factors"][0]["value"] == "-1/4"
    return {"density": wedge_route(phase), "residual": residual_route(phase),
            "inverse": inverse_controls()}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
