# Lorentzian gauge and auxiliary inverse V905

The actual switched gauge and auxiliary equations have advanced
and retarded inverses for smooth compact switches, including
zero auxiliary width. An exact local change of variables puts
the equations in a normally hyperbolic residual system. The
original auxiliary constraint follows from its own homogeneous
wave equation and causal support. The calculation keeps all
source and width factors.

For the Feynman problem, the same spatial Hardy estimate as
V901 controls individual massive scalar and ghost lines and
the conjugated scalar and matrix preconditioners. The direct
extension of that norm to the free gauge block fails. At generic
width the temporal dipole has a weighted outgoing tail whose
squared norm diverges as the absorption vanishes. The mixed
temporal derivative also grows with frequency in that norm.
These tests separate the coupled Feynman question from the
advanced and retarded result.

The exact sign, constraint, dipole and conjugation checks
replay under the inherited action and Lorentz conventions.
The coupled Feynman inverse and its products in the inner
loop sums remain open. No gauge width has been adopted.
