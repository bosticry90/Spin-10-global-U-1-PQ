# Exact preconditioners for the Lorentzian internal inverse

Use the actual flat color-diagonal g0 Minkowski quadratic
switch, with symbolic real auxiliary width w and the sequential
Feynman boundary. Use the V901 broad real compact profile and
spatial weight rho^-1. The goal is to identify which parts of
the Euclidean gauge form argument transfer and construct
normally hyperbolic replacements for the derivative blocks.

## The free Hardy obstruction and massive simple poles

The scalar Hardy bound in V901 also applies to P−M+i eta for
any fixed positive squared reference mass M. Its spatial kernel
is −exp(i k r)/(4 pi r), with k=sqrt(tau²−M+i eta) in the
upper half plane. Both the oscillatory and evanescent ranges
are dominated by the Newton kernel. Pointwise kernel convergence,
this domination and Plancherel give the same strong weighted
boundary. The actual scalar switch adds V=Box sigma/2. Thus
individual massive scalar and ghost lines have the convergent
V901 weighted Neumann series with the same smallness constant.
This is a statement about lines, not their coincidence products.

The same weight on both sides fails for the generic free
gauge block. The width-dependent dipole in G_BB has numerator
proportional to (w−1)p_mu p_nu. The spatial kernel of
(P+i eta)^-2 is obtained by minus differentiation of the
simple resolvent with respect to tau²:

    i exp(i sqrt(tau²+i eta) r)/(8 pi sqrt(tau²+i eta)).

Fix tau≠0 and choose a compact smooth g away from the spatial
axis with its spatial Fourier transform nonzero on an open
subset of the sphere of radius |tau|. Put f=rho g. Convolving
the dipole with g and multiplying by rho^-1 gives an outgoing
term of size exp(−Im(k) rho)/rho with a nonzero angular
coefficient on that subset. The expansion of |x−y| for y
in fixed compact support gives a uniform relative O(rho^-1)
error there. The squared radial norm diverges like
1/Im(k) as eta decreases. In G_B0B0 the dipole coefficient
contains tau² and is nonzero at generic w. The weighted simple
part is bounded and cannot cancel the diverging norm.
A small open interval of tau gives the same test with
ordinary temporal Fourier packets.

Even the mixed block with one tau times the simple resolvent
does not have a uniform bound in tau with those two weights.
At eta=0 and tau>0, spatial dilation makes
rho^-1 G_F(tau) rho^-1 unitarily equivalent to its tau=1
value. The factor tau in the temporal mixed numerator is
then unbounded. The obstruction is to applying the scalar
Hardy argument unchanged. It is not an exclusion of a
different gauge inverse, and does not select w.

## Transform the actual switched density

Let s_mu=partial_mu sigma and a=exp(sigma).
The frozen physical kinetic term is −F²/4 at g0.
Subtract its Euler-normal quadratic, integrate the switched
divergence by parts, and retain the Minkowski mixed switch
from V873. The resulting density in the original B,Lambda
variables is

    −F(B)²/4 + s_mu B_nu F(B)^(mu nu)/2
    −Lambda (div B−s·B/2) + w Lambda²/2.

Complete the square in F(B)−(s wedge B)/2 and put
B=exp(sigma/2)b, Lambda=exp(−sigma/2)lambda. The literal
transformed density is

    −a F(b)²/4 + a(s wedge b)²/16
    −lambda div b + w a^-1 lambda²/2.

No width inverse or gradient gauge condition has been imposed.
The weighted Maxwell operator is
M_a(b)^nu=partial_mu(a F(b)^(mu nu)). The zero-order remainder is

    W^nu_mu = a(s² delta^nu_mu − s^nu s_mu)/4.

The vector and auxiliary Euler equations, with general right
sides J and j after the corresponding source multiplication,
are

    M_a b + W b + d lambda = J,
    −div b + w a^-1 lambda = j.

The divergence of M_a is identically zero by antisymmetry.
Consequently the auxiliary divergence equation is
Box lambda + div(W b)=div J. In this chart the first
coupling of b back into that equation has two switch-gradient
factors. This is consistent with the V896 two-switch
auxiliary entry, whose Euclidean estimate is separate.

## Normally hyperbolic parts

Define the auxiliary preconditioning gauge
L_a b=div b+s·b. In the vector equation use the identity

    a^-1 M_a b + d L_a b
       = Box b + s·partial b + (Hess sigma)b.

Indeed the gradient of div b cancels, and
d(s·b) cancels the cross first derivative except for the
Hessian of sigma. The substitution b=exp(−sigma/2)c gives
Box plus the zero-order matrix
Hess sigma−(Box sigma/2+s²/4)I. Adding a^-1 W leaves the simpler zero-order matrix
Hess sigma−(Box sigma/2)I−s^nu s_mu/4. The real Lorentz metric
is retained throughout, including the raised Hessian index.

Independently, the original mixed gauge differential
L_sigma=div−s·/2 on a gradient gives
L_sigma d=Box−s·partial/2. Conjugation by exp(sigma/4)
reduces it to Box+Box sigma/4−s²/16. This provides a scalar
preconditioner for this exact gradient equation. The bound
is on its scalar potential inverse, without asserting an
unweighted norm for the output gradient.

For sigma=b_0(log(r/R)/ell), r²=t²+rho², the Euclidean
Hessian norm is bounded by
( ||b_0'||/ell+||b_0''||/ell² )/r².
Raising one Lorentz index changes no Euclidean matrix norm.
The remaining Box and s² terms satisfy the same O(ell^-1)
bound after multiplication by rho², uniformly in R.
The positive scalar conjugation factors are bounded above
and below. Componentwise V901 then gives a norm-convergent
weighted Feynman inverse and strong boundary for each
conjugated potential operator. The small nonradial perturbation
of V903 can also preserve these strict bounds for a fixed
dip scale by choosing its amplitude sufficiently small.

## The actual retarded and advanced coupled inverse

With N=a^-1 M_a+d L_a+a^-1 W, the equivalent constrained
system is

    N b = a^-1 J − d j + d(s·b)
            + (w−1)a^-1 d lambda − w a^-1 s lambda,
    Box lambda = div J − div(W b).

Move the terms with b and lambda to the left. All cross
couplings and d(s·b) are first order or lower. The principal
symbol is the wave symbol times the identity on five
components. For every smooth compact switch and real width,
this is a normally hyperbolic system on Minkowski spacetime.
For compact smooth J and j, its sources and their derivatives
have the same support. The advanced and retarded existence
and uniqueness theorem therefore applies to this actual
residual system. See Bär, arXiv:1310.0738, and Bär, Ginoux
and Pfäffle, arXiv:0806.1036, for the wave Cauchy theorem.

The constraint C=div b+j−w a^-1 lambda is not imposed by
hand. Substitution of the residual system into the original
vector equation gives the residual −a d C, and its divergence
vanishes by the second residual equation. Thus
div(a d C)=0. Equivalently C satisfies the scalar wave
operator Box+s·partial and has past-compact or future-compact
support for the retarded or advanced solution. Its Cauchy
uniqueness forces C=0. Therefore these solutions solve the
original two equations. Uniqueness for the residual system
also gives the left inverse on compact fields, by applying
it to the original differential operator and comparing
solutions with the same causal support. Multiplication by
the conjugation factors does not enlarge support.
No division by w was used, including at w=0.

The fixed Feynman boundary for the full coupled gauge
inverse remains separate from the advanced and retarded
result. The artificial gradient d L_a b and div(W b)
would still have to be controlled in a coupled Feynman
space with the correct dipole and mixed port behavior.
The free Hardy obstruction rules out using the unchanged
scalar weight norm for this purpose. No coincidence products,
causal loop sum, or longitudinal width are fixed here.
