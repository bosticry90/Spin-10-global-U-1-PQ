# V942 result — exact joint restriction on the two contact directions

The light and broken gauge-edge contacts cannot
simultaneously meet the homogeneous gauge square and
transverse metric conditions as an isolated pair.
The complete transverse metric condition forces equal
weights. A difference of two gauge-square coefficients
requires the broken weight to be twice the light weight.
The two conditions have rank two.

The gauge-square test removes every alternating ghost
bracket contribution by exchange and every lower
linear gauge map contribution by an exact row
difference. It allows an arbitrary constant symmetric
transverse metric in the independent condition. Both
native and replay reproduce the four ordered literal
contractions and the bracket identity. The only
solution in this class has zero weight for both
contacts, while the ordinary target needs a nonzero
broken weight.

This excludes a two-direction local completion, not
the full quantum restoration problem. The two-vertex
color span and the explicit transverse metric primitive
remain qualified on their own projections. Additional
gauge-source contractions and quantum source terms have
not been assigned zero. The next test should classify
the actual returning gauge-source triangle directions
on the two existing exact witnesses before any momentum
expansion. Both routes share the action, software and
AI authorship.
