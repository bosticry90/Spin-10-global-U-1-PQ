"""Check all gauge outputs of the selected two-edge contact."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)
seagull = source.seagull


def check(phase):
    _, _, _, f, _, _ = source.owner.inputs(phase)
    folder = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    cubic, quartic = {}, defaultdict(list)
    for g, word, cells in rows:
        ids = [i for i, _ in word]
        if g == 1 and len(ids) == 3 and 0 <= ids[0] < 180 and ids[0] % 4 == 1 and 565 <= ids[1] < 598 and 643 <= ids[2] < 823 and (ids[2]-643) % 4 == 1:
            assert all(not d for _, d in word) and all(p[:2] == [0, 0] for p, _, _ in cells)
            a, u, k = (ids[2]-643)//4, ids[0]//4, ids[1]-553
            z = seagull.unpack([([0, *p], n, d) for p, n, d in cells])
            assert (a, u, k) not in cubic
            cubic[a, u, k] = z
        if g == 2 and len(ids) == 4 and ids[1] < 180 and ids[0] % 4 == ids[1] % 4 == 1 and 565 <= ids[2] < 598 and 610 <= ids[3] < 643:
            assert all(not d for _, d in word) and all(p[:2] == [0, 0] for p, _, _ in cells)
            b, d, c, k = ids[0]//4, ids[1]//4, ids[2]-553, ids[3]-598
            z = seagull.unpack([([0, *p], n, d) for p, n, d in cells])
            quartic[b, k].append((d, c, z*(1+int(b == d))))
            if b != d:
                quartic[d, k].append((b, c, z))
    tensors = []
    for internal in (range(12), range(12,45)):
        D = defaultdict(lambda: sp.S.Zero)
        for (a,u,k),z in cubic.items():
            if u in internal:
                for b,c,value in quartic[u,k]:
                    D[a,b,c] += z*value
        tensors.append(source.owner.clean(D))
    DH, DM = tensors
    assert len(DH) == 1360 and len(DM) == 1830
    assert DH.get((1,30,23),0) == 0 and DM[1,30,23] == sp.Rational(1,10)

    a, b1, b2, c = 17, 1, 13, 32
    assert not f[a,c]
    assert f[a,b1] == f[a,b2] == [(27,sp.Rational(1,2))]
    candidates = []
    for b in (b1,b2):
        candidates.append([str(D.get(key,0)) for key in ((a,b,c),(a,c,b)) for D in (DH,DM)])
    assert candidates == [["1/5","-1/10","0","0"],["-1/10","-1/10","1/10","1/10"]]
    H, M = sp.symbols("weight_H weight_M")
    targets = [sp.expand(sum(weight*D.get(key,0) for key in ((a,b,c),(a,c,b))
                             for weight,D in ((H,DH),(M,DM)))) for b in (b1,b2)]
    assert targets == [H/5-M/10,0]
    gauge_square = targets[0]-targets[1]
    metric = H-M
    assert sp.solve((gauge_square,metric),(H,M)) == {H:0,M:0}
    assert sp.Matrix([[sp.Rational(1,5),-sp.Rational(1,10)],[1,-1]]).det() == -sp.Rational(1,10)
    return {"literal_ordered_sector_rows": candidates, "shared_lower_entry": "-L[27,32]/2",
            "gauge_square_weight_relation": "weight_M=2*weight_H",
            "metric_weight_relation": "weight_M=weight_H", "joint_rank":2,
            "nonzero_contact_solution":False}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
