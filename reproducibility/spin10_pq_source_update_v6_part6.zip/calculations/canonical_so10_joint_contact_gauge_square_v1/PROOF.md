# An exact joint gauge-square and metric restriction

Use the two V940 contact directions with stripped weights
w_H and w_M. Let D be the corresponding ordinary gauge
driver coefficient after its common chart factor, L the
lower derivative map and W the ghost bracket correction.
The independent partial C=b, C=c term in the homogeneous
gauge square is

    D(b,c)+[L b,c]-L[b,c]-W(b,c).

Adding its exchanged row eliminates W and L[b,c], because
both are alternating. The remaining expression is

    D(b,c)+D(c,b)+[L b,c]-[b,L c].

Use output a=e17, fixed c=e32, and compare b=e1 with b=e13.
In the original bracket [a,c]=0 and [a,b]=e27/2 in both
cases. The invariant metric then gives exactly the same
contribution -L[27,32]/2 in the two equations, with no
restriction on the other entries of L. Their difference
is independent of every lower linear gauge driver.

The actual H and M sector current values in the first
ordering are (1/5,-1/10) and in its exchange (0,0).
The second ordering gives (-1/10,-1/10) and its exchange
(1/10,1/10). Thus gauge square requires w_M=2 w_H.
The independent V940 metric witness requires w_M=w_H,
even with an arbitrary constant symmetric metric. The
joint rank is two, so both weights must vanish. The
selected ordinary coefficient is nonzero per unit w_M.

The result excludes the isolated pair of directions as
a homogeneous local completion of the selected
nonzero coefficient. It allows arbitrary L, arbitrary
alternating W and any constant symmetric transverse
color metric in that test. Additional gauge-source
directions or independently determined quantum terms
may alter the two-row difference. The actual common
normalization remains open. Both routes share the
action, conventions, software and authorship.
