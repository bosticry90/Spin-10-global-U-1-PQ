"""Check all gauge outputs of the selected two-edge contact."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)
seagull = source.seagull


def check(phase):
    _, _, _, f, _, _ = source.owner.inputs(phase)
    folder = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    cubic, quartic = {}, defaultdict(list)
    for g, word, cells in rows:
        ids = [i for i, _ in word]
        if g == 1 and len(ids) == 3 and 0 <= ids[0] < 180 and ids[0] % 4 == 1 and 565 <= ids[1] < 598 and 643 <= ids[2] < 823 and (ids[2]-643) % 4 == 1:
            assert all(not d for _, d in word) and all(p[:2] == [0, 0] for p, _, _ in cells)
            a, u, k = (ids[2]-643)//4, ids[0]//4, ids[1]-553
            z = seagull.unpack([([0, *p], n, d) for p, n, d in cells])
            assert (a, u, k) not in cubic
            cubic[a, u, k] = z
        if g == 2 and len(ids) == 4 and ids[1] < 180 and ids[0] % 4 == ids[1] % 4 == 1 and 565 <= ids[2] < 598 and 610 <= ids[3] < 643:
            assert all(not d for _, d in word) and all(p[:2] == [0, 0] for p, _, _ in cells)
            b, d, c, k = ids[0]//4, ids[1]//4, ids[2]-553, ids[3]-598
            z = seagull.unpack([([0, *p], n, d) for p, n, d in cells])
            quartic[b, k].append((d, c, z*(1+int(b == d))))
            if b != d:
                quartic[d, k].append((b, c, z))
    tensors = []
    for internal in (range(12), range(12,45)):
        D = defaultdict(lambda: sp.S.Zero)
        for (a,u,k),z in cubic.items():
            if u in internal:
                for b,c,value in quartic[u,k]:
                    D[a,b,c] += z*value
        tensors.append(source.owner.clean(D))
    DH, DM = tensors
    assert len(DH) == 1360 and len(DM) == 1830
    assert DH.get((1,30,23),0) == 0 and DM[1,30,23] == sp.Rational(1,10)

    def symmetric(D):
        S = [defaultdict(lambda: sp.S.Zero) for _ in range(45)]
        for (a,b,c),z in D.items():
            S[c][a,b] += z
            S[c][b,a] += z
        return [source.owner.clean(matrix) for matrix in S]

    def commutator(c, S):
        out = defaultdict(lambda: sp.S.Zero)
        for (k,b),value in S.items():
            for a,z in f[c,k]:
                out[a,b] += z*value
                out[b,a] += z*value
        return out

    def coboundary(S,c,d):
        out = commutator(c,S[d])
        source.seagull.axpy(out,-1,commutator(d,S[c]))
        for a,z in f[c,d]:
            source.seagull.axpy(out,-z,S[a])
        return source.owner.clean(out)

    SH, SM = symmetric(DH), symmetric(DM)
    assert not f[30,23]
    assert coboundary(SH,30,23)[0,14] == sp.sqrt(10)/40
    assert coboundary(SM,30,23)[0,14] == -sp.sqrt(10)/40
    S = [source.add(x,y) for x,y in zip(SH,SM)]
    first = None
    nonzero = 0
    for c in range(45):
        for d in range(c+1,45):
            defect = coboundary(S,c,d)
            nonzero += len(defect)
            if defect and first is None:
                a,b = min(defect)
                first = [c,d,a,b,str(defect[a,b])]
    return {"basis_pairs": 990, "equal_weight_defect_positions": nonzero,
            "first_equal_weight_defect": first, "independent_weights_required_relation": "weight_H=weight_M",
            "selected_ordinary_color_preserved_per_unit": "1/10",
            "metric_primitive_exists_in_real_symmetric_color_space": nonzero == 0}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
