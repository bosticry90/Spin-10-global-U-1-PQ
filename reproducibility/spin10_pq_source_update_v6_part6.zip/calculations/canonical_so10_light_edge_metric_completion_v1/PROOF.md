# Light gauge-edge companion of the transverse metric condition

Use the same contact as V939 and add the independent
direction in which the internal gauge edge is light.
The internal ghost stays broken and the other ports
remain those of the literal current. Call the output
and gauge-input symmetric tensors S_H and S_M.
At the selected V936 ordinary row the H direction
has zero and the M direction has its nonzero unit
coefficient. The V936 spectator identity identifies
the ordinary and source responses in that row.

A compatible transverse metric must give
S_c=-[ad_c,M], up to the common chart convention.
For all color pairs its adjoint derivative must vanish,

    [ad_c,S_d] - [ad_d,S_c] - S_[c,d] = 0.

The isolated M direction gives -sqrt(10)/40 at the
V939 commuting witness, and the H direction gives the
opposite. Any combined metric solution in this pair
of directions must therefore use equal weights.

The executable computes the symmetric matrix on each
input color from both literal contractions and checks
the full adjoint derivative on all 990 pairs for that
equal-weight tensor. By linearity this is the full
cocycle condition on the real Lie algebra. The
representation on real symmetric matrices is
c dot X=[ad_c,X], which preserves symmetry because
ad_c is skew. If the full test is zero, the First
Whitehead Lemma for the finite-dimensional real
semisimple algebra gives S_c=[ad_c,M0] for a real
symmetric M0. Changing the common sign gives the
metric convention above. See Zusmanovich,
arXiv:0704.3864, introduction for the classical
vanishing statement. If the test has a nonzero row,
no such metric works for this two-direction class
with the nonzero ordinary coefficient.

Neither outcome fixes whether the two extensions
may be varied independently in the admitted causal
prescription. Other source, ordinary and quantum
relations retain their own obligations. Native and
replay share the action, conventions, software and
authorship.
