# V940 result — the light gauge-edge companion restores metric compatibility

The light internal gauge direction cancels the V939
commuting-adjoint defect with equal stripped weight.
It has zero contribution to the required ordinary
coefficient, which retains the broken-edge value.

The equal-weight symmetric tensor has zero adjoint
derivative on all 990 independent basis pairs. This
includes all noncommuting pairs and all light ghost
pairs. The First Whitehead Lemma therefore gives a
real symmetric metric primitive for the complete
linearized transverse color equation in this pair
of contact directions. The V939 witness fixes the
relative weights in this basis.

This is a constructive existence result for the
metric equation. The admissible causal scheme has
not yet supplied a normalization choosing these
weights or an independently matched Maxwell form.
The scalar and ghost equations, source products,
and allowed mass dependence of the common contact
still need their own checks. Both frozen routes
share the action, software and authorship.

Next recover an explicit metric primitive and
compare it to the ordinary Maxwell two-vertex
normalization under the same finite map. Then
carry the same light and broken contact weights
through the linked ghost and scalar source rows.
