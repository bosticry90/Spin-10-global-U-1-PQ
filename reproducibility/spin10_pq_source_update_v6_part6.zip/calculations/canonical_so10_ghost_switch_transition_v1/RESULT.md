# V894 — Ghost transition term and normalization test

At color 12 the switched lift of the V883 group, before explicit
switch-only quadratic insertions, has the soft constant
(51/2)L_Sigma sigma²(1−sigma). The kinetic tadpole feedback carries
three switches including its massive Y root. The YY bubble carries
two. The ordinary uncut constant cancels at unit switching. After
sewing the two massless exterior ghost propagators, the Euclidean
weak limit of this group has an additional finite term supported by
the switching transition. In stripped proper units it is
m_12 f(0,0) integral chi²(1−chi)/|x|^4 divided by 16 pi^4.
The exact Fourier and radial log checks agree. The nonconstant
pieces converge to the ordinary paired V883 result.

A separate calculation of the actual rank-one Maxwell and auxiliary
switch shows that their mixed insertion is a finite difference of
longitudinal propagators and that its LambdaLambda entry is zero.
An exterior ghost switch can contribute at the same soft order as
the transition term. The complete switched limit remains unresolved.

The individual differentiated YY product fails the direct N.wAL
check in the current common normalization. Eliminating the color-12
constant leaves 300 log(M_Sigma/M_Phi) at color 17 for distinct
reference masses. The grouped cancellation does not repair that
subproduct. V883's independent-rate negative control is retained.

Require the final receipt and capture. Both routes share the action,
software and AI authorship. The weak discrepancy is for the lifted
Euclidean group and the specified density representative. Full
causal and Ward equivalence, the normalization of remaining products
and E5/A5 remain open.
