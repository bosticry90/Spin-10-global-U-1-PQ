# The switching transition in the selected ghost coefficient

Use the V883 unprobed g^4 xi^2 one-loop coefficient with two
ordinary odd sources, the V879 literal interaction density,
zero A and retained sources, zero scalar mass difference and
the inherited common conversion. Keep the actual massive
radial feedback. This increment evaluates the lift of the
V883 group to switched vertex weights with zero explicit
switch-only quadratic insertions, in the Euclidean weak test.
It also checks actual first-order quadratic switch vertices
and the normalization premise of a direct theorem route.

## Why constant unit switching loses information

Let DMM, FMY, YY and FFMM have their V883 meaning. DMM and
FMY have three vertices, YY has two and FFMM has four. The
kinetic scalar tadpole has a kinetic Bxx and an auxiliary
M vertex, then a scalar bridge to the Y vertex with the two
external odd leaves. Thus the feedback has three switched
vertices including the massive root vertex. The Y ghost
tadpole and its Y root have two, with zero common converted
massless one-edge value. Its separate paired finite-cutoff
artifact from V883 is kept when comparing regulator orders.
The FFMM and external-derivative FMY have zero soft constant.

In the stripped ordered proper units put
L_s=log(mu²/M_s)+kappa−gamma_E−2 log 2.
For actual color 12 only Sigma contributes to the constant.
The DMM, FMY and YY weights are 0,12,51/2 and the retained
feedback is −75/2 in the same units. With common constant
switch value s, the local constant of the lifted group is

    m_12 s²(1−s),  m_12=(51/2)L_Sigma.

The same powers follow by multilinearity of the common
counterterms and the full regulated forest subtraction.
This is zero at s=1. Its first variation there is −m_12.
Subtracting the YY constant alone would instead leave
−m_12 in the uncut group.

## Weak test of the actual lifted group

Choose a real smooth compact chi between zero and one,
equal to one near the origin with a nontrivial transition.
Set sigma_R(x)=chi(x/R). The ordinary source tests in
momentum are Schwartz with compact support, and may be
nonzero at p=0. Use the same two simple free ghost roots,
with source order and the overall sign from V882. In this
finite switching comparison the total transferred momentum
K is an independent variable. After common UV conversion
the two Euclidean roots 1/[p²(p+K)²] are locally integrable
as distributions in the independent variables p,K. The
calculation is made in the continuum for each finite R.

Each graph of the lifted V883 group has its own independent
small vertex transfers k_i with sum K. Its proper core or
massive-root factor can be replaced by the zero-transfer
in k_i expression at fixed p, with an error tending to zero
after pairing. In this color the literal F derivatives in
the lift have the V883 placements. In particular the raw
B_M C_H a_M divergences which turn into switch vertices
cannot feed an ordered a12,C12 F–Y or F–F path. Neither
external slot can go on this divergence in F–F. In F–Y an
internal C_H cannot contract into Y, whose two ghost
carriers are M. The owner row check binds this statement. The external diagonal
pair also has no ordinary B or Lambda cubic at these degrees.
The sixteen g² cubic rows for it have Sigma as third port.
For the remaining cores the massless loop pole orders,
including derivative gains, are at most three. DMM has
two mixed poles of order one, FMY a mixed and a ghost
pole, YY one ghost pole, and FFMM has two mixed poles
and the internally differentiated ghost. The mixed
lines in the kinetic feedback and its massive bridge
also have the strict integrability margin. The one-edge
massless tadpole has zero converted continuum value.

To see the transfer estimate, take a shift of size h<1.
Split the Euclidean loop near all displaced massless
nodes into balls of radius sqrt(h) and their complement.
Use the weighted arithmetic-geometric mean bound on
products of translated inverse powers. Total order at
most three bounds the small-ball integrals by
O(sqrt(h)). Away from the balls, one derivative raises
the pole order by at most one. The mean-value estimate
there is O(h(1+|log h|)) on bounded loop momentum.
Use the same differentiated UV subtraction on the
large loop region. Its local polynomials are smooth
in transfer. The positive scalar mass gives a uniform
bound on the massive bridge and its derivatives.
Thus an O(h^alpha) modulus, with any fixed alpha<1/2,
suffices uniformly on compact external momentum sets.
The argument counts only the lifted V883 paths. Extra
switch-induced paths require their own census.

The two exterior ghost roots cost at most
O(1+|log |K||) against smooth compact momentum tests.
For the scaled vertex transfers k_i=ell_i/R the
Hölder error is O(R^-alpha(1+log R)) after integration.
The logarithmic singularity of sum ell_i is integrable
in these independent transfers. The Schwartz tails of
the Fourier switch beat the polynomial seminorms of
the finite Euclidean kernels outside the small-transfer
region. For each remaining zero-k_i core, subtract its
own constant. Its residue O(p²(1+|log p²|)) from V883
makes the two-root pairing continuous at K=0. For
example near p=0 the p² removes one inverse square
and the remaining locally integrable log is controlled
by a slightly higher inverse power. Convolution of the
identical switch transforms at total K then gives
Fourier(chi^n)(R K) R^4, whose limit in that pairing
uses chi(0)^n=1. These nonconstant pieces give the
ordinary grouped uncut V883 coefficient.

The constants instead yield h=chi²(1−chi), with h(0)=0.
In Fourier convention integral dp/(2 pi)^4, the exterior
bubble tested by f(p,K) has the expansion

    J(K)=−f(0,0) log(K²)/(16 pi²)+c_f+o(1).

The logarithm follows by subtracting a radial ball times
f(0,0) and using the exact angular mean 1/max(p²,K²).
The remainder after subtraction is continuous at K=0,
by the linear gain from the test and shifted-ball
estimates. Both log R and c_f drop out since h(0)=0.
The limiting contribution in the stripped proper sign is

    m_12 f(0,0)/(16 pi^4) integral h(x)/|x|^4 dx.

The source-first ghost coefficient carries the inherited
overall minus. To verify the coefficient, integrate the
Schwinger representation of log(K²) against hhat. The
constant term has zero pairing and the inverse transform
off x=0 is −1/(pi² |x|^4), from the four-dimensional heat
kernel. Since h is nonnegative and vanishes near zero,
the integral is finite and strictly positive. This is an
actual profile term of the lifted V883 group, for
m_12 nonzero. At the special symbolic value L_Sigma=0
the color-12 control is blind. It demonstrates a
failure of replacing the graphwise switches by unit
weight before sewing the critical roots.

## Rank-one switch algebra and scope of the discrepancy

In the fixed Euclidean representative the free ghost
switch contributes −(Delta sigma) C a/2. The mixed
Lambda–B switch has Fourier off-diagonal r/2, and the
Maxwell switch gives, with u=v+r,

    Q_BB = (−r² I−v r^T+r u^T)/2.

The last expression follows from the actual switched
divergence −(partial_mu sigma) B_nu F_mu,nu/2.
Use G_BB(v)=I/v²+(w−1)vv^T/(v²)^2,
G_B,Lambda(v)=−v/v² and G_Lambda,B(v)=v^T/v².
The ordered G(u) Q G(v) has Lambda,Lambda block zero
and B,Lambda block (v/v²−u/u²)/2. The other mixed
block is the transpose of this difference. These
identities use u^T Q_BB v=0, so the dipole width drops
out at unequal transfer. With either Maxwell or mixed
switch alone the mixed result generally differs.
The common massless paired profiles multiply the two
sides equally. This is a structural simplification of
the rank-one kernel, with finite Euclidean gain
|r|/(2|u||v|) on the mixed block.

An exterior ghost switch on the ungrouped soft constant
adds one propagator of order two and a switch momentum
factor of degree two. Under joint p,k scaling these
degrees compensate. After the normalized switch
measure and p integration this can contribute at the
same order as the displayed transition term. The
zero-explicit-switch result depends on the fixed
density representative. It does not evaluate the
complete switched coefficient, which includes those
insertions and the new transfer assignments. The V883
independent-rate negative control is distinct and remains
a necessary check on alternative regulator comparisons.

## The current normalization and the weak adiabatic theorem

Duch's N.wAL condition tests individually differentiated
vacuum time-ordered products at soft momentum. For two Y
vertices differentiate in an external a and an external C.
Their total canonical dimension is two, and the
dimension-four vertex convention gives required zero
of order two by eqs. (3.40),(3.43). The actual YY
massive–massless bubble is analytic at zero with the
common converted constant tested here. Color 12 has
(51/2)L_Sigma. Color 17 has
300 L_Phi+(51/20)L_Sigma. Setting the first to zero
leaves 300 log(M_Sigma/M_Phi) in the second for distinct
positive reference masses. Thus the current common
one-parameter normalization fails this necessary
subproduct check for the cited sufficient condition.
One may not substitute a cancellation between different
proper and rooted products for that hypothesis.
A different normalization and its Ward and source
compatibility would require a separate construction.
This result makes no assertion against the existence
of a full weak adiabatic limit by direct grouping.
[Primary paper, §3.6](https://arxiv.org/pdf/1801.10147)

The frozen comparisons share the action, reference,
software and AI authorship. No inverse g, new finite
normalization, or scientific promotion is used.
