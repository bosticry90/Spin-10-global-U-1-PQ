"""Actual color, switch-jet and exterior-bubble checks."""

import gzip
import json
import sys
from pathlib import Path

import sympy as sp

from execute import ROOT, run_worker


def load(owner, name):
    path = ROOT/"calculations"/("canonical_so10_"+owner)/name
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            return json.load(stream)
    return json.loads(path.read_bytes())


def ghost_colors(role):
    route = "primary" if role == "native" else "replay"
    pole = load("ghost_mass_g4_pole", route+"_v2_result.json")
    table = pole["physical_scalar_sector_family_poles"]

    def weight(sector, family, color):
        return sum(sp.sympify(v) for a,c,v in table[sector][family] if (a,c) == (color,color))

    d,f,y = [weight("Sigma", kind, 12) for kind in ("DMM","FMY","YY")]
    assert (d,f,y) == (0,12,sp.Rational(51,2))
    assert all(weight("Phi",kind,12) == 0 for kind in ("DMM","FMY","YY"))
    assert all(12 <= a < 45 and 12 <= c < 45 for _,a,c,_ in pole["physical_Y_aC_density"])
    yy_phi = weight("Phi","YY",17)
    yy_sigma = weight("Sigma","YY",17)
    assert (yy_phi,yy_sigma) == (300,sp.Rational(51,20))
    owner = load("uncut_ghost_profile_v1","result.json")["checks"]["radial"]
    feedback = sp.sympify(owner["row12_massive_feedback_slope"])
    assert feedback == -(d+f+y)
    s,L,difference = sp.symbols("s L_Sigma log_MSigma_over_MPhi")
    total = ((d+f+feedback)*s**3+y*s**2)*L
    assert sp.expand(total-y*L*s**2*(1-s)) == 0
    assert sp.diff(total,s).subs(s,1) == -y*L
    assert (yy_phi*(L+difference)+yy_sigma*L).subs(L,0) == 300*difference
    old = load("uncut_ghost_boundary_v1","result_v2.json")["checks"]["actual_tadpole"]
    v = sp.Symbol("v")
    residual = (d+f)*sp.integrate(sp.cancel(((1-v)**4-(1-v)**2)/v),(v,0,1))
    assert residual == old["row12_unpaired_residual_leading_in_epsilon_squared_over_M"] == -7
    return {"row12_D_F_YY":[str(x) for x in (d,f,y)],"massive_feedback":str(feedback),
            "row12_switch_constant_over_L":"51*s**2*(1-s)/2",
            "row12_derivative_at_unit_switch_over_L":"-51/2",
            "row17_YY_after_row12_subtraction":"300*log(M_Sigma/M_Phi)",
            "unpaired_control_over_epsilon_squared_times_M":int(residual)}


def literal_support(role):
    actual = load("unprobed_compact_all_coupling_v1",role+"_full_current.json.gz")["current"]
    rows = actual["complete_S_GF_source"]
    both = [(grade,word) for grade,word,_ in rows if len(word) == 3 and
            {565,610} <= {n for n,_ in word}]
    assert len(both) == 16 and all(grade == 2 and 234 <= word[0][0] < 486 for grade,word in both)
    divergence = {}
    for degree,word,cells in rows:
        if degree != 1 or len(word) != 3:
            continue
        (B,jB),(C,jC),(a,ja) = word
        if 48 <= B < 180 and 553 <= C < 565 and 610 <= a < 643:
            assert a != 610
            jets = [jB,jC,ja]
            assert [jet for jet in jets if jet] == [[B%4]]
            divergence.setdefault((B,C,a),{})[next(i for i,jet in enumerate(jets) if jet)] = cells
    assert len(divergence) == 1336
    assert all(set(v) == {0,1,2} and v[0] == v[1] == v[2] for v in divergence.values())
    for mu in range(4):
        assert [0,[[48+mu,[mu]],[520,[]]],[[[0,0,16],1,1]]] in rows
        assert [0,[[565,[mu]],[610,[mu]]],[[[0,0,0],-1,1]]] in rows
    return {"raw_divergence_triplets":len(divergence),
            "color12_diagonal_cubic_Sigma_rows":len(both),
            "external_color12_divergence_rows":0}


def mixed_switch(role):
    width = sp.Symbol("eta_H")
    inverse = load("regulator_free_inverse_g1_recovery_v1",role+"_inverse.json.gz")
    slots = [0,1,2,3,508]
    q = sp.Matrix(sp.symbols("q0:4"))
    v = sp.Matrix([1,2,0,1])
    u = sp.Matrix([2,1,3,1])
    r = u-v
    def square(x):
        return x.dot(x)

    def free(k):
        k2 = square(k)
        D = sp.eye(4)/k2+(width-1)*k*k.T/k2**2
        return D.row_join(-k/k2).col_join((k.T/k2).row_join(sp.zeros(1,1)))

    raw = {(i,j):sp.sympify(value) for i,j,value in inverse["Greference"] if i in slots and j in slots}
    for mom in (v,u):
        read = sp.Matrix(5,5,lambda i,j: raw.get((slots[i],slots[j]),sp.S.Zero))
        assert (read.subs(dict(zip(q,mom)),simultaneous=True)-free(mom)).applyfunc(sp.expand) == sp.zeros(5)
    maxwell = (-square(r)*sp.eye(4)-v*r.T+r*u.T)/2
    mixed = (r/2).col_join(sp.zeros(1,1))
    Q = maxwell.row_join(r/2).col_join(mixed.T)
    assert (u.T*maxwell*v)[0] == 0
    combined = (free(u)*Q*free(v)).applyfunc(sp.expand)
    difference = (v/square(v)-u/square(u))/2
    assert combined[:4,4] == difference
    assert combined[4,:4] == difference.T and combined[4,4] == 0
    assert (free(u)*sp.diag(maxwell,0)*free(v)).applyfunc(sp.expand)[:4,4] != difference
    assert sp.expand(square(difference)-square(r)/(4*square(u)*square(v))) == 0
    return {"LambdaLambda":0,"mixed_difference":"(v/v^2-u/u^2)/2",
            "mixed_squared_norm":"r^2/(4*u^2*v^2)","drop_mixed_changes_result":True}


def annulus_control(role):
    s,t = sp.symbols("s t",positive=True)
    if role == "native":
        # Radial h=e^(-|x|^2)-e^(-2|x|^2) verifies the log pairing.
        # Integrate its Schwinger difference without separating divergent terms.
        integral = sp.integrate(1/t,(t,1,2))
        h_over_r4 = sp.pi**2*integral
        answer = h_over_r4/(16*sp.pi**4)
    else:
        # Normalized Fourier log moment of the two Gaussian transforms.
        log_moment = sp.integrate(s*sp.exp(-s)*sp.log(s),(s,0,sp.oo))
        pair = sp.expand((log_moment+sp.log(4))-(log_moment+sp.log(8)))
        answer = -pair/(16*sp.pi**2)
    assert sp.simplify(answer-sp.log(2)/(16*sp.pi**2)) == 0
    assert 4-2*2 == 0 and 4+2-3*2 == 0
    return {"stripped_transition_coefficient":"m*f0*integral(h/|x|^4)/(16*pi^4)",
            "analytic_log_pair_control":"log(2)/(16*pi^2)",
            "exterior_switch_joint_soft_power":0}


def checks(role):
    return {"color":ghost_colors(role),"support":literal_support(role),
            "mixed_switch":mixed_switch(role),"annulus":annulus_control(role)}


if __name__ == "__main__":
    run_worker(checks,sys.argv[1])
