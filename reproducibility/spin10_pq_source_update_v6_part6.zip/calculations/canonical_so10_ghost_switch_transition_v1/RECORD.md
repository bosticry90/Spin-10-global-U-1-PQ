# V894 pre-execution contract

Test the Euclidean weak switching limit of the actual color-12
V883 ordinary ghost group in the literal V879 representative
at zero explicit switch-only quadratic count. Keep the massive
radial root, both derivative paths, full UV forests and the
V883 regulator-rate negative control. Admit compact Fourier
source tests nonzero at the tip and compact smooth plateau
switches. Compare the separate switched graph weights before
sewing. Freeze the two-root logarithm and the expected
transition term, with normalization inherited.

Test the actual rank-one mixed and Maxwell switch jets using
both free inverse files. Confirm the color-12 cubic support
and independent mass constants for the differentiated YY
normalization check. The exact Euclidean graphwise result
has the declared scope; further switch counts, newly admitted
graphs and the Lorentzian weak limit require separate evidence.
No new finite counterterm or inversion of the coupling.

Native limit 120 s, final 180 s including E4 cap of 120 s,
8 GiB sampled private, 350 MiB launch commit floor, 8 MiB
artifact, 32 MiB packet. Freeze code and proof. Require final
replay and exact staged bytes. Scientific ceiling is the
selected weak transition discrepancy and rank-one controls,
with a specific condition failure for the direct theorem route.
