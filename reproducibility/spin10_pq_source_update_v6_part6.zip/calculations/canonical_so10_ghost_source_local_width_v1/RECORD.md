# V971 pre-execution contract

Freeze the V879 literal source and odd-vertex
census, V791 free inverse, V945 ghost derivative
placements and V970 cubic-switch comparison. At
zero background and broken width, identify the
actual one-loop local g3 ghost-source coefficient.
Check the returning graph support, both free
gauge numerators, the signed light-longitudinal
color and its switch power. Use both action
exports. Keep local logarithmic coefficients
separate from nonlocal and exceptional limits.
No new finite contacts or normalization adopted.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority change.
