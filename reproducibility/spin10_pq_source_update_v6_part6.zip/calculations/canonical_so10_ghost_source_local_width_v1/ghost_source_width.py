"""Check the actual transverse and light longitudinal ghost-source core."""

from collections import Counter, defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


def previous():
    path = ROOT / "calculations/canonical_so10_gauge_first_switch_rank_v1/first_switch_rank.py"
    spec = importlib.util.spec_from_file_location("first_switch_owner",path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def census(owner,phase):
    path = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = owner.seagull.read(path / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    odd = Counter()
    source = Counter()
    for grade,word,cells in rows:
        names = [i for i,_ in word]
        if any(1196 <= i < 1241 for i in names):
            assert grade == 1 and len(names) == 3
            assert all(553 <= i < 598 for i in names[:2])
            assert 1196 <= names[2] < 1241 and not any(d for _,d in word)
            assert all(p[:2] == [0,0] for p,_,_ in cells)
            source[grade] += 1
        if not grade or not all(i < 643 for i in names):
            continue
        if not any(553 <= i < 643 for i in names):
            continue
        if not any(p[0] == 0 for p,_,_ in cells):
            continue
        assert all(i < 180 or 553 <= i < 643 for i in names)
        v = sum(i < 180 for i in names)
        c = sum(553 <= i < 598 for i in names)
        a = sum(598 <= i < 643 for i in names)
        odd[grade,v,c,a] += 1
    assert source == {1:837}
    assert set(odd) == {(1,1,1,1),(2,2,1,1)}
    return source[1]


def tensor(prior,owner,phase,f):
    gauge = prior.load_literal()
    _, _, da, db, _, JC, _, _ = gauge.literal_tables(owner,phase)
    endpoints = defaultdict(list)
    for (i,v,b),z in da.items():
        if v<12:
            assert (i,v,b) not in db
            assert (i<12) == (b<12)
            endpoints[v,i].append((b,z))
    W = [prior.table() for _ in range(3)]
    for (a,i,j),x in JC.items():
        for v in range(12):
            for b,y in endpoints[v,i]:
                for c,z in endpoints[v,j]:
                    if b != c:
                        n = int(i>=12)+int(j>=12)
                        W[n][a,min(b,c),max(b,c)] += (1 if b<c else -1)*x*y*z

    clean = owner.owner.clean
    W = [clean(D) for D in W]
    K_H = prior.table()
    for v in range(12):
        for b in range(45):
            for j,x in f[v,b]:
                for a,y in f[v,j]:
                    K_H[a,b] -= x*y
    combined = clean(prior.plus(*((D,1) for D in W)))
    target = clean(prior.plus((prior.square(f,clean(K_H),{}),-sp.S.Half)))
    assert combined == target and W[0][0,1,2] == 3*sp.sqrt(10)/8
    return [len(D) for D in W]


def lorentz_and_switch():
    eta, s, ds = sp.symbols("eta s ds")
    k = sp.Matrix(sp.symbols("k0:4"))
    Q = k.dot(k)
    G = sp.eye(4)/Q+(eta-1)*k*k.T/Q**2
    contracted = sp.cancel((k.T*G*k)[0])
    assert contracted == eta and contracted.subs(eta,0) == 0
    assert s*sp.diff(s**3,s)*ds == 3*s**3*ds


def check(phase):
    prior = previous()
    owner = prior.load_literal().load_owner()
    _, _, _, f, _, _ = owner.owner.inputs(phase)
    rows = census(owner,phase)
    cells = tensor(prior,owner,phase,f)
    lorentz_and_switch()
    return {"literal_JC_rows":rows,"width_zero_proper_core":"J_C CC with two F vertices",
            "transverse_local_coefficient_zero":True,
            "light_longitudinal_color":"delta K_H / 2",
            "light_longitudinal_cells_by_broken_ghost_count":cells,
            "light_width_pivot":"3*sqrt(10)/8",
            "first_switch_from_qC":"3*s^3*ds","no_s2_contribution":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
