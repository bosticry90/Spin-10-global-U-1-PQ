# Actual ghost-source support for the gauge first-switch equation

Use one proper loop and one retained J_C source,
with output C_b,C_c and g³ at zero background
and intrinsic grade zero. The literal source
is only g J_C CC. Both C ports must be internal
for a proper returning loop. The scalar and
matter kinetic and potential vertices have no
antighost ports. At zero broken width the
literal positive-g odd vertices are the
ordinary F=B C a and quartic B² C a. The
four-ghost vertices carry the broken width.
The quartic B² C a cannot supply two antighost
ports. The surviving core is the triangle
with one exterior ghost at each F and one
ordinary gauge propagator. Free quadratic
switch insertions carry a positive switch jet
and cannot supply the derivative-free local
J_C CC coefficient of dimension four.

At fixed first local order, both F hard
derivatives lie along the loop momentum k.
At a transverse BB line they both annihilate
its numerator. After integrating the
derivative transfer the triangle has two
exterior derivatives; these can appear in
the separated nonlocal coefficient, not the
local derivative-free normalization tested
here. With light width eta_H retained
k^t G_BB(k) k=eta_H on its longitudinal
line. There is no constant transverse term.
This contraction holds before the angular
dimension jet.

The light internal B has d_B=0 and the two
d_a residues are -f_(i v b), -f_(j v c).
The even J_C has raw coefficient f_(a i j)
for i<j. In the ordered loop moving the two
external C's to the front gives one odd
permutation, and the alternating C_i C_j
a_i a_j Wick pairing gives the second.
The opposite endpoint momenta give +k k,
and the three-vertex logarithm has positive
sign in the raw Euclidean action. The
resulting raw color after stripping eta_H
and the positive log primitive is

    W_H(a,b,c)=sum_(v in H,i,j)
                    f_(a i j) f_(i v b) f_(j v c).

The signed q_C driver has the opposite
source sign. Color is grouped by whether
the internal ghosts are H or M. For v in
H their sectors follow those of b,c. The
common hard scalar kernel in each group
has F_B F_C F_C divided by Q². The Jacobi
derivation of the color is
W_H=( [K_H b,c]+[b,K_H c]-K_H[b,c] )/2.
The code compares this directly to the
literal contraction in both exports.

The loop carries s³. Applying the classical
s partial C source rule to this ghost-source
correction produces a term with s partial(s³)
=3s³ partial s. Therefore this particular
proper direction does not repair an s² first-
switch coefficient. It vanishes in the fully
transverse selected comparison and survives
in the separate light longitudinal sector.
No finite nonexceptional kernel, independent
balanced source contact, or full master
closure is claimed. Both routes share the
action and software.
