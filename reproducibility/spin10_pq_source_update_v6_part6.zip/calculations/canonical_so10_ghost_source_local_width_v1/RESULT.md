# V971 · Local ghost-source width dependence

Both exports give 837 literal ghost-source rows.
At zero broken width the proper local g³ source
has one returning topology, with two ordinary
ghost vertices and one BB edge. The transverse
line kills both hard derivative contractions.
There is no local transverse `J_C CC` term
at the selected order.

With light longitudinal width retained, the
ordered color is `δ K_H/2`. The three broken
ghost count groups have 36, 282 and 652 nonzero
color cells. The raw Euclidean source coefficient
is proportional to `eta_H`; the signed ghost
driver has the opposite source sign. Its compact
first-switch contribution has shape `3s³∂s`.

The nonlocal source kernel and any independent
finite source contacts are outside this check.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
