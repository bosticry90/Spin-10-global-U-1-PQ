"""Check the mixed compact reference-master scalar color span."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)
seagull = source.seagull


def check(phase):
    _, _, _, f, _, _ = source.owner.inputs(phase)
    folder = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    H, M = range(12), range(12,45)
    tensors = [defaultdict(lambda:sp.S.Zero) for _ in range(4)]
    used = 0
    for g,word,cells in rows:
        if g != 1 or len(word) != 3:
            continue
        (b,db),(c,dc),(j,dj) = word
        if b >= 180 or b%4 != 1 or not 553 <= c < 598 or not 643 <= j < 823 or (j-643)%4 != 1:
            continue
        assert not(db or dc or dj) and all(p[:2] == [0,0] for p,_,_ in cells)
        v,c,u = b//4,c-553,(j-643)//4
        z = seagull.unpack([([0,*p],n,d) for p,n,d in cells])
        assert z == -dict(f[v,c])[u]
        out = tensors[2*int(u in M)+int(v in M)]
        for a,value in f[u,v]:
            out[a,c] -= z*value/2
        used += 1
    assert used == 1674
    HH,HM,MH,MM = map(source.owner.clean,tensors)
    C = defaultdict(lambda:sp.S.Zero)
    for h in H:
        for j in range(45):
            for k,x in f[h,j]:
                for i,y in f[h,k]:
                    C[i,j] -= x*y
    C = source.owner.clean(C)
    Ch = {(i,j):z for (i,j),z in C.items() if i in H and j in H}
    Cm = {(i,j):z for (i,j),z in C.items() if i in M and j in M}
    I = {(i,i):sp.S.One for i in range(45)}
    Ph = {(i,i):sp.S.One for i in H}
    Pm = {(i,i):sp.S.One for i in M}
    assert HH == source.add({},Ch,sp.Rational(1,2))
    assert HM == MH == source.add({},Cm,sp.Rational(1,2))
    assert MM == source.add(source.add(source.add({},I,4),HH,-1),Cm,-1)
    light = source.add(HH,HM)
    broken = source.add(MH,MM)
    W = source.add(light,broken)
    assert W == source.add({},I,4)

    # The V958 light-ghost sum is the light-mixed sum.
    R_light = source.add({},C,sp.Rational(1,2))
    R_broken = source.add({},Pm,4)
    assert light == R_light
    R = source.add(R_light,R_broken)
    target = source.add(source.add({},C,sp.Rational(1,2)),Ph,-4)
    assert source.add(R,W,-1) == target
    assert source.add(R,broken,-1) != target
    assert source.add(R,W) != target

    free = ROOT / "calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1"
    inv = seagull.read(free / f"{phase}_inverse.json.gz")
    G = {(i,j):value for i,j,value in inv["Greference"]}
    q = sp.symbols("q0:4")
    assert all(sp.cancel(sp.sympify(G[4*a,508+a])+q[0]*sp.sympify(G[553+a,598+a])) == 0
               for a in H)
    return {"literal_all_gauge_driver_rows":used,
            "light_mixed_equals_light_ghost_color_sum":True,
            "full_reference_mixed_map":"4 I","full_reference_scalar_map":"C_H/2+4 P_M",
            "combined_color_identity":"T=R-W",
            "equal_same_sign_weights_suffice":False}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
