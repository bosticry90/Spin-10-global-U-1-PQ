# The light mixed reference port completes the scalar color span

V957 restricted the reference-master mixed index u to M.
That restriction was appropriate for its stated test.
The free V791 reference also has the light B Lambda
edge. It is present at zero ordinary width. The literal
F_B E_(R,B) carrier therefore admits u in H as well,
independent of the broken restriction of the separate
ordinary BB Lambda cubic.

Use the same ordered scalar projection as V957 and
include all literal J_B B C rows. In the (mixed u,
ordinary v) sector order the four maps are

    W_HH=C_H|H/2,  W_HM=C_H|M/2,
    W_MH=C_H|M/2,  W_MM=4 I-C_H|H/2-C_H|M.

Their sum is 4 I. The added light mixed sum is
C_H/2, exactly the light-ghost sum from the
distinct scalar reference placement of V958.
The two complete families thus satisfy

    R-W = (C_H/2+4 P_M)-4 I
        = (-8 P_H+C_H)/2 = T.

The literal signs at the roots distinguish the
two families. For the mixed root the gauge
driver is +f B C and the reference Euler has
-i partial Lambda. The scalar root uses
F_x=-rho(C)x, which gives the negative
scalar-ghost derivative term after integration
by parts. With the marker kept left, its
internal C crosses the exterior C once before
the ghost contraction. In the common skew
ordering the two placements have opposite
stripped signs on the local derivative jet.
Their hard numerator has the same scalar
quadratic factor and the same transverse
angular projection under matched mixed/ghost
profiles. This sign comparison does not
identify the complete regulated insertions.

The executable verifies every color map,
the actual light mixed Green identity and the
failure of both the omitted-light and same-sign
comparisons. The result is a full color
completion for this scalar residual if the
common normalized weights have the required
relation. It does not establish that relation
for all compact, mass, geometric or marked
products. In particular equality of profiles
and finite weights across all sectors is
separate. Both frozen routes share the model,
software and authorship.
