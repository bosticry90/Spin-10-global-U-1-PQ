# V959 result — light mixed reference port completes the scalar color map

Including the literal light B Lambda reference edge
adds the missing C_H/2. The full mixed reference
family sums to 4 I and the scalar family to
C_H/2+4 P_M. In the opposite-sign stripped
combination their difference equals the V949
scalar target T in the complete color basis.

Both routes check all 1,674 literal spatial gauge
driver rows and the light mixed Green relation.
Omitting the light port or giving the families
the same sign fails the comparison.

The color solution requires the actual normalized
profiles and coefficients to satisfy its matching
conditions. The calculation does not identify
complete compact, mass, geometric or marked
products. Both routes share the model, conventions
and software. No finite coefficient adopted.
