"""Test a jointly varied linear source ansatz at unit switch."""

from collections import defaultdict
import importlib.util
from itertools import product
import sys

import sympy as sp

from execute import PK, ROOT, run_worker


OWNER=ROOT/"calculations/canonical_so10_gauge_scalar_seagull_residue_v1/seagull_residue.py"
SPEC=importlib.util.spec_from_file_location("seagull_owner",OWNER)
seagull=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(seagull)


def check_free(phase):
    root=ROOT/"calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    data=seagull.read(root/f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    free={tuple((i,tuple(jets)) for i,jets in word):cells for g,word,cells in data if g==0}
    for a,mu in product(range(45),range(4)):
        lam=508+a
        c=553+a
        anti=598+a
        B=4*a+mu
        assert free[((B,(mu,)),(lam,()))]==[[[0,0,16],1,1]]
        assert free[((c,(mu,)),(anti,(mu,)))]==[[[0,0,0],-1,1]]
        assert free[((c,(mu,)),(643+B,()))]==[[[0,0,0],-1,1]]
    for a in range(45):
        assert free[((508+a,()),(1241+a,()))]==[[[0,0,16],-1,1]]
    for a in range(12,45):
        lam=508+a
        assert free[((lam,()),(lam,()))]==[[[1,0,0],1,2]]

    w=sp.Symbol("w")
    M=sp.Matrix([[1,0,w],[0,1,-1],[0,1,1]])
    assert M.det()==2 and M.rank()==3

    # Derive the commuting scalar-probe restriction without
    # imposing diagonality on the two transported matrices.
    l=sp.Matrix(2,2,sp.symbols("l:4"))
    n=sp.Matrix([[0,1],[-1,0]])
    G=sp.diag(sp.Symbol("g1"),sp.Symbol("g2"))
    z=sp.Matrix([1,0])
    assert (z.T*(l*G-G*l+w*n*G)*z)[0]==0
    return {"free":{"single_color_rank":3,"literal_rows":618,
                    "width_independent":True}}


def eigen(phase):
    role="primary" if phase=="native" else "replay"
    root=ROOT/"calculations/canonical_so10_physical_current_input_recovery_g1_v1"
    data=seagull.read(root/("native_v2_coefficients.json.gz" if phase=="native" else "replay_v4_coefficients.json.gz"))
    frame=seagull.read(PK/"frozen_a10_physical_reconciliation"/f"full_{role}.json")
    v_all={i:sp.sympify(z) for i,_,z in frame["vacuum"]["VEV"]["entries"]}
    rho={}
    for a,rows in data["rho"]:
        rho[a]=defaultdict(list)
        for i,j,cells in rows:
            rho[a][j].append((i,seagull.unpack(cells)))
    f=defaultdict(list)
    for (j,h,a),cells in data["f"]:
        if h<12<=a:
            f[h,a].append((j,seagull.unpack(cells)))
    KH=sp.zeros(45)
    for rows in f.values():
        for (i,x),(j,y) in product(rows,repeat=2):
            KH[i,j]+=x*y
    c=sp.zeros(45,1)
    c[17],c[22]=1,-1
    assert all(sp.expand(z)==0 for z in KH*c-sp.Rational(21,10)*c)
    values={}
    for name,(start,stop,_) in seagull.BLOCKS.items():
        v={i:z for i,z in v_all.items() if start<=i<stop}
        E=[seagull.apply(rho[a],v) for a in range(45)]
        G=sp.Matrix([[seagull.dot(x,y) for y in E] for x in E])
        lam=sp.Rational(25) if name=="Phi" else sp.Rational(3,10)
        assert all(sp.expand(z)==0 for z in G*c-lam*c)
        if phase=="native":
            defect=(c.T*KH*G*c)[0]
        else:
            defect=sp.Rational(21,10)*lam*(c.T*c)[0]
        assert sp.expand(defect)!=0
        values[name]={"eigenvalue":str(lam),"defect":str(sp.expand(defect))}
    return values


def check(phase):
    return check_free(phase) | {"eigen":eigen(phase)}


if __name__=="__main__":
    run_worker(check,sys.argv[1])
