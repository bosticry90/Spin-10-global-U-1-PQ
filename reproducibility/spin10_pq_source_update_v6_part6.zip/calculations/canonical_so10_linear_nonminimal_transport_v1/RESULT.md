# V930 result

The literal free mixed, ghost and source rows constrain the
joint linear gauge, antighost and auxiliary source changes.
The single-color free test has rank three at every width.
In the full matrix test the auxiliary coefficient remains
skew, while the antighost coefficient is tied to the common
gauge derivative and the width.

Allow the corresponding homogeneous scalar driver in all
faithful scalar blocks. After imposing the free and ordinary
kinetic conditions, the remaining tested unit-switch master
change is a commutator with the orbit Gram plus a skew term.
Both vanish on the actual common broken eigenvector
e17-e22. The required V928 coefficients on that vector are
105 and 63/50 in the two blocks before their nonzero
normalization factors. No common kappa removes both.

This excludes the displayed joint linear source repair
with the ordinary action held fixed. Nonlinear nonminimal
sources and tied ordinary changes remain open. The literal
and replay checks share physical inputs and software.
No scientific authority change.
