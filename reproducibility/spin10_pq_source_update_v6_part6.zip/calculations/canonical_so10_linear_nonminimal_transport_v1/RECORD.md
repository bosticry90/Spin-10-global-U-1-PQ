# V930 pre-execution contract

Test the joint linear gauge and nonminimal source ansatz for
the V928 unit-switch defect. Keep the ordinary free action,
free BRST identities and the ordinary scalar kinetic response.
Allow a common gauge derivative driver, linear antighost and
auxiliary partners, and the corresponding homogeneous scalar
driver in every faithful block. Test the actual joined
free GF/source signs and a common broken orbit eigenvector
in the two active blocks.

Require exact free coefficient rank and a trace-independent
bilinear obstruction after all allowed linear partners are
included. Do not extend the exclusion to nonlinear,
field-dependent or ordinary action changes. No authority change.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.
