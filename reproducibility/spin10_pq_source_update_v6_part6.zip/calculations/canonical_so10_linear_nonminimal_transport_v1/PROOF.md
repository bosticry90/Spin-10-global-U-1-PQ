# Joint linear gauge and nonminimal source test

## Unit-switch free equations in the literal current chart

Work with A=0, all retained sources set to zero after
differentiation, and the actual unit-switch free polynomial.
Write P0=Delta for the differential operator in this
calculation. In the current chart the mixed term is
+i Lambda div B, the antighost Euler is -P0 C, and the
auxiliary Euler is i div B+w Lambda-i J_a. The two free
drivers are F_B=partial C and F_a=+i Lambda.
The ordered ghost action has C before a. Moving the
source J_B before the odd C and using the signed left
derivative for a gives the stated signs. The test reads
the equal-index mixed rows, ghost kinetic rows and
source rows from both actual V879 routes. The broken
width has its actual symbolic coefficient xi.

Consider the following joint linear source changes,
with their common first-loop and grade factor suppressed:

    delta F_B = L_B partial C,
    delta F_a = i L_a Lambda - M div B,
    delta F_Lambda = i N P0 C.

The matrices may mix gauge colors within the admitted
linear ansatz. No diagonality or symmetry is assumed
before imposing the identities. Hold the ordinary free
action fixed. The Maxwell Euler has zero divergence,
so the gauge-driver change tests the mixed auxiliary
Euler only. After one integration by parts, the
coefficient of i Lambda P0 C is
L_B-L_a^t+wN. The coefficient of (div B) P0 C is
M^t-N. The free antighost square gives M+N=0, equivalently
the retained J_a P0 C row. Thus the joint constraints are

    L_a^t = L_B + wN,     N^t=-N,     M=-N.

For a single color with L_B held fixed, the three
constraints on the remaining three entries have
determinant of magnitude two at every width. The
matrix version retains skew N rather than silently
discarding mixed-color changes.

The ordinary scalar kinetic identity at the same
source deformation order is the V929 rank-45 test.
If its ordinary action is fixed and the homogeneous
scalar gauge driver compensates the common L_B change,
its derivative is delta F_x=-g rho_(L_B C)x in each
nontrivial scalar block. In this calculation allow
that change in all such blocks, including phi.
Thus the test does not depend on keeping the phi
driver unchanged.

## Joint effect on the forced master coefficient

Evaluate the selected ordinary Lambda x C grade at
x=v_s. In the current chart the original Y Euler
on that direction is +g² xi G_s C. Its product with
delta F_a supplies +i g² xi Lambda^t L_a^t G_s C
in the fixed zero-ordinary-derivative projection.
The original scalar mixing has coefficient +i g xi
Lambda E_s x. Its product with the compensating
delta F_x supplies -i g² xi Lambda^t G_s L_B C.
The derivative-only parts of the changed sources
vanish in this ordinary jet. With the free
constraints imposed the remaining possible change is

    i g² xi Lambda^t ([L_B,G_s]+w N G_s) C.

The V928 defect in these units is proportional to
K_H G_s, with the scalar-block normalization factor
retained. Test both ordinary Lambda and C along
z=e17-e22. The joined exact representations give

    K_H z=(21/10)z,
    G_Phi z=25 z,
    G_Sigma z=(3/10)z.

The native check forms the matrices and contracts
the bilinear directly. Replay uses the checked
eigenvalues and the squared norm two. They give
z^t K_H G_s z equal to 105 and 63/50. Neither is
zero. For any L_B, the commutator with G_s has zero
z,z entry because G_s is symmetric and z an
eigenvector. The width is scalar on the broken
direction z and N is skew, so the other possible
change also has zero z,z entry. No joint linear
source weights in this ansatz can supply the
required term on a block with nonzero L_s.
Distinct positive reference masses prevent both
blocks' L_s from vanishing at a common kappa.

This test retains the free and ordinary kinetic
responses simultaneously. A free test alone
would allow L_B to accompany the other sources,
and a vacuum coefficient fit alone misses its
linked free restrictions. The exclusion is
limited to the displayed linear nonminimal
drivers and homogeneous scalar and gauge
compensation at fixed ordinary action. Nonlinear
J_Lambda and J_a terms, changes in the ordinary
action, and open-algebra source terms are
separate possibilities. Their own free and
source rows must be carried along.

Native and replay share the literal action,
joined representations and symbolic software.
No loop integration, physical parameter or
authority change.
