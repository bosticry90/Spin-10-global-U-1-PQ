# Integrated first-probe one-ghost result

Disposition: INTEGRATED_FIRST_U_QGamma1_C_ZERO.

Both routes audit every GF operation and scalar source insertion before the
C-only restriction. See complete support artifacts and PROOF.md. Physical
potential Euler constants remain arbitrary and are never assigned a value.
The source-partner and boundary inference is qualified only when all recorded
premises pass; any counterexamples remain explicitly unqualified. The proof
retains cutoff powers and requires translation-invariant one-point data. This concerns the
integrated selected Q Gamma1 coefficient, not its local density or Gamma1.

The g2 scalar return, other five extra g1 profiles, common correcting module,
physical viability and E5/A5 remain open. Authority stays 34/39. Seven custody
references remain NOTPASS. Shared assumptions/software/AI limit independence.
