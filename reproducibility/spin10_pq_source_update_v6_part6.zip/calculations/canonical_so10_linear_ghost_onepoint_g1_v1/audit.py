from pathlib import Path
from collections import defaultdict
from fractions import Fraction as Fr
from hashlib import sha256
import gc,gzip,json,os,re,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/linear-ghost-onepoint-g1-v1-2026-11-07')
P='canonical_so10_proper_slavnov_actual_operators_g1_v1';G='canonical_so10_new_physical_returning_inventory_g1_recovery_v1';I='canonical_so10_regulator_free_inverse_g1_recovery_v1';V='canonical_so10_source_homotopy_applicability_g1_v1'
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
INPUTS=['AGENTS.md','CHARTER.md','project_state.json','README.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V831.md','docs/RESEARCH_EXECUTION_HANDOFF_V832.md']
for folder,names in[(P,['validation_receipt.json','PROOF.md','native_inputs.json.gz','replay_inputs.json.gz']),(G,['validation_receipt.json','inventory.py','native_GF_common.json.gz','replay_GF_common.json.gz']),(I,['validation_receipt.json','PROOF.md','native_inverse.json.gz','replay_inverse.json.gz']),(V,['validation_receipt.json','PROOF.md','final_preparation.json']),('canonical_so10_proper_slavnov_source_chain_g1_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_chiral_probe_support',['validation_receipt.json','DERIVATION.md']),('canonical_so10_sterile_matter_action',['validation_receipt.json','ACTION_V1.md']),('canonical_so10_sourceful_proper_zero_transfer_g1_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_full_source_response_support_g1_v1',['validation_receipt.json','PROOF.md','ward_result.json'])]:INPUTS+=['calculations/'+folder+'/'+n for n in names]
INPUTS+=['tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/'+n for n in['export_a10_e5_antighost_vector.py','export_a10_e5_vector_ghost_closed_controls_v3.py','export_a10_e5_vector_ghost_closed_actual_v3.py']]
INFO={'F0':(0,0,None),'E0':(0,0,None),'F1':(1,0,None),'E1':(1,0,None)}
for p in[0,1]:
 for g in[0,1]:
  for letter in['F','E']:INFO[letter+'u'+str(g)+'_'+str(p)]=(g,1,p)
def dump(path,z):
 with path.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def mathhash(z):return sha256((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest()
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 if len(blob)>4*1024**2:
  with(C/(name+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as h:h.write(blob)
  raise AssertionError('COMPLETE_OVERFLOW_PRESERVED_NO_TRUNCATION')
 with(O/name).open('xb')as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=16*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def ghost(n):return 553<=n<598
def scalar(n):return 180<=n<508
def Cproject(rows,role):
 if role=='native':return[[w,c]for w,c in rows if len(w)<=1 and all(ghost(n)for n,js in w)]
 out=[]
 for w,c in rows:
  forbidden=sum(not(553<=n<=597)for n,js in w);degree=sum(553<=n<=597 for n,js in w)
  if forbidden==0 and degree in[0,1]:out.append([w,c])
 return out
def signrows(rows,sign):return[[w,[[k,sign*num,den]for k,num,den in c]]for w,c in rows]
def erase_jets(rows):
 d=defaultdict(lambda:defaultdict(Fr))
 for w,c in rows:
  key=tuple((n,())for n,js in w)
  for k,num,den in c:d[key][tuple(k)]+=Fr(num,den)
 return[[[[n,list(js)]for n,js in w],[[list(k),v.numerator,v.denominator]for k,v in sorted(cs.items())if v]]for w,cs in sorted(d.items())if any(cs.values())]
def block_control():
 diagonal=[[1,0],[0,1]];cross=[[0,1],[1,0]];wrong=[[1,1],[1,1]]
 trace=lambda left,right:sum(left[i][j]*right[j][i]for i in range(2)for j in range(2))
 correct,bad=trace(diagonal,cross),trace(wrong,cross);assert correct==0 and bad==2
 return dict(correct_block_diagonal_single_cross_trace_paths=correct,artificial_wrong_g0_cross_trace_paths=bad,support_only_NOT_physical_amplitude=True)
def route(role):
 packet=load(B/P/(role+'_inputs.json.gz'));states={k:dict(v)for k,v in packet['states'].items()};assert set(states)==set(INFO);journal=[];bad=[];linear=[];sensitive=0
 for name,table in sorted(states.items()):
  assert set(table)==set(range(643));isF=name.startswith('F')
  for n,raw in sorted(table.items()):
   projected=Cproject(raw,role);projected=signrows(projected,-1 if not isF and n>=553 else 1);constants=[r for r in projected if not r[0]];zeroderivative=[r for r in projected if r[0]and not r[0][0][1]];port=n if isF else n+643;currents=[]
   for w,c in projected:
    if w and w[0][1]:i,js=w[0];currents.append(dict(direction=js[0],C_index=i,remaining_C_jets=js[1:],proper_onepoint_symbol='Gamma1_derivative_at_port_'+str(port),coefficient=c))
   if constants or zeroderivative:bad.append(dict(state=name,port=port,constants=constants,zero_jet_C=zeroderivative))
   if projected:linear.append(dict(state=name,port=port,complete_projected_operation=projected))
   control=erase_jets([r for r in projected if r[0]]);sensitive+=bool(control);journal.append(dict(state=name,port=port,g_u_probe=list(INFO[name]),full_map_words=len(raw),full_map_math_sha256=mathhash(raw),complete_Cdegree01_projection=projected,complete_boundary_current_factors=currents,wrong_erased_C_jets=control))
 assert len(journal)==7716
 physical=[]
 for name,rows in sorted(packet['physical'].items()):
  for n,raw in rows:
   projected=Cproject(raw,role);physical.append(dict(state=name,source_port=643+n,words=len(raw),full_math_sha256=mathhash(raw),complete_projection=projected))
   if projected:bad.append(dict(state=name,port=643+n,known_physical_C_projection=projected))
 scalar_journal=[];scalar_bad=[];scalar_words=0
 for name in['F0','F1','Fu0_0','Fu0_1','Fu1_0','Fu1_1']:
  for n in range(180,508):
   raw=states[name][n];fail=[]
   if name!='F1'and raw:fail=list(range(len(raw)))
   if name=='F1':
    for at,(w,c)in enumerate(raw):
     types=sorted('C'if ghost(i)else'X'if scalar(i)else'OTHER'for i,js in w)
     if len(w)!=2 or types!=['C','X']or any(js for i,js in w)or not c or any(k[0]!=1 or not num for k,num,den in c):fail.append(at)
    scalar_words+=len(raw)
   scalar_journal.append(dict(state=name,field=n,words=len(raw),full_math_sha256=mathhash(raw),bad_word_indices=fail))
   if fail:scalar_bad.append(dict(state=name,field=n,complete_failed_words=[raw[at]for at in fail]))
 assert len(scalar_journal)==1968;del packet,states;gc.collect()
 common=load(B/G/(role+'_GF_common.json.gz'));ordinary=[('original_g0',common['original_ordinary'])]+[('probe'+str(p)+'_g0',common['probe_ordinary'][p])for p in[0,1]];block=[];cross=[]
 for name,rows in ordinary:
  kept=[];rejected=[];decisions=[]
  for at,(w,c)in enumerate(rows):
   qq=[n-1319 for n,js in w if 1319<=n<1962];means=[(n,js)for n,js in w if not(1319<=n<1962)];assert len(qq)==2
   if not all(ghost(n)for n,js in means):rejected.append(at);continue
   kept.append(at);tags=['X'if scalar(n)else'GF'for n in qq];mixed=(scalar(qq[0])!=scalar(qq[1]))if role=='native'else set(tags)=={'GF','X'};decisions.append([at,qq,tags,mixed])
   if mixed:cross.append(dict(owner=name,index=at,complete_word=rows[at]))
  assert sorted(kept+rejected)==list(range(len(rows)));block.append(dict(owner=name,full_raw_words=len(rows),full_math_sha256=mathhash(rows),Cplane_kept_raw_indices=kept,other_mean_rejected_raw_indices=rejected,all_selected_quantum_block_decisions=decisions))
 del common,ordinary;gc.collect();inverse=load(B/I/(role+'_inverse.json.gz'));matrix=[];inverse_cross=[]
 for name in['G_F','Greference','Pphysical','Preference','full_regulator']:
  rows=inverse[name];decisions=[]
  for at,(i,j,value)in enumerate(rows):
   assert 0<=i<643 and 0<=j<643;mixed=(scalar(i)!=scalar(j))if role=='native'else len({'X'if scalar(n)else'GF'for n in[i,j]})==2;decisions.append([at,i,j,mixed])
   if mixed:inverse_cross.append(dict(matrix=name,index=at,complete_entry=rows[at]))
  matrix.append(dict(matrix=name,full_entries=len(rows),full_math_sha256=mathhash(rows),all_block_decisions=decisions))
 del inverse;gc.collect();ok=not(bad or scalar_bad or cross or inverse_cross);art=save(role+'_complete_support.json.gz',dict(all7716_GF_operation_columns=journal,all_known_physical_Euler_columns=physical,all1968_scalar_flow_columns=scalar_journal,all_g0_Cplane_ordinary_Hessian_decisions=block,all_complete_free_matrix_block_decisions=matrix,complete_operation_premise_counterexamples=bad,complete_scalar_flow_counterexamples=scalar_bad,complete_ordinary_cross_counterexamples=cross,complete_inverse_cross_counterexamples=inverse_cross,full_surviving_C_operations=linear,wrong_erased_jet_sensitive_columns=sensitive,F1_scalar_Cx_words=scalar_words,unknown_physical_scalar_Euler_constants='RETAINED_ARBITRARY_SYMBOLS_NO_VALUES_ASSIGNED_SOURCE_PARTNER_SUPPORT_RECORDED',matter_PS_K_restriction_AFTER_allowed_operations=True,block_control=block_control(),all_four_gu_terms_retained=['Q0 Gamma_gu','Q1 Gamma_u','Qu0 Gamma_g','Qu1 Gamma_0']));print('STAGE '+role+' derivative_C_columns='+str(len(linear))+' constant_or_zerojet_violations='+str(len(bad))+' block_or_scalar_violations='+str(len(scalar_bad)+len(cross)+len(inverse_cross)),flush=True);return dict(route=role,all_premises_pass=ok,artifact=art,derivative_C_columns=len(linear),erased_jet_control_sensitive_columns=sensitive,F1_scalar_words=scalar_words)
def main():
 tick=time.perf_counter();watch=threading.Timer(240,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 assert read(B/V/'validation_receipt.json')['all15432_constructing_owner_F_E_columns_equal'];bind=read(B/V/'final_preparation.json')['sha256']
 for role in['native','replay']:
  for folder,suffix in[(P,'inputs'),(G,'GF_common')]:n='calculations/'+folder+'/'+role+'_'+suffix+'.json.gz';assert bind[n]==digest(R/n)
 results=[route(role)for role in['native','replay']];assert(O/'native_complete_support.json.gz').read_bytes()==(O/'replay_complete_support.json.gz').read_bytes();ok=all(z['all_premises_pass']for z in results);assert len({tuple((k,v)for k,v in z.items()if k not in['route','artifact'])for z in results})==1
 art=results[0]['artifact'];cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120);ec=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert p.returncode==0
 events=[json.loads(z)for z in p.stdout.splitlines()if z.strip()];exits=[z['exit_code']for z in events if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and events[-1]['execution_state']=='COMPLETED'and next(z for z in events if z['event']=='step_finished'and z['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);raw=(R/'README.md').read_bytes();assert raw.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792';assert(C/'README_before.md').read_bytes()==subprocess.check_output(['git','show','HEAD:README.md'],cwd=R);tree=(C/'old_git_tree.txt').read_bytes();assert tree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R).decode().splitlines()==['README.md'];state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';links=[]
 for path,body in[(R/'README.md',raw[:-len(history)].decode('utf-8')),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V832.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V832.md').read_text(encoding='utf-8'))]:
  for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',body):
   if target.startswith(('https:','http:','#','mailto:')):continue
   pp=(path.parent/target.split('#')[0]).resolve();assert pp.is_relative_to(R)and pp.exists();links.append([path.relative_to(R).as_posix(),target])
 out=dict(schema='LINEAR_GHOST_ONEPOINT_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='INTEGRATED_FIRST_U_QGamma1_C_ZERO'if ok else'COUNTEREXAMPLE_RETAINED_C_ZERO_NOT_ESTABLISHED',routes=results,unknown_potential_tadpoles_NOT_assigned_zero=True,source_partner_proof='V801_T2Fx_SINGLE_CROSS_g1_WITH_BLOCK_DIAGONAL_g0_COVARIANCE_ON_C_ONLY_PLANE',all_gu_convolutions_and_constant_operation_products_retained=True,local_density_Gamma1_and_g2_zeros_NOT_CLAIMED=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',out)
 text='# Integrated first-probe one-ghost result\n\nDisposition: '+out['scientific_disposition']+'.\n\nBoth routes audit every GF operation and scalar source insertion before the\nC-only restriction. See complete support artifacts and PROOF.md. Physical\npotential Euler constants remain arbitrary and are never assigned a value.\nThe source-partner and boundary inference is qualified only when all recorded\npremises pass; any counterexamples remain explicitly unqualified. The proof\nretains cutoff powers and requires translation-invariant one-point data. This concerns the\nintegrated selected Q Gamma1 coefficient, not its local density or Gamma1.\n\nThe g2 scalar return, other five extra g1 profiles, common correcting module,\nphysical viability and E5/A5 remain open. Authority stays 34/39. Seven custody\nreferences remain NOTPASS. Shared assumptions/software/AI limit independence.\n'
 with(O/'RESULT.md').open('x',encoding='utf-8',newline='\n')as h:h.write(text)
 files=[q for q in O.iterdir()if q.is_file()]+[R/'README.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V832.md'];size=sum(q.stat().st_size for q in files);assert size<=16*1024**2 and all(q.stat().st_size<=4*1024**2 for q in files)
 receipt=dict(schema='LINEAR_GHOST_ONEPOINT_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_INTEGRATED_FIRST_U_C_ZERO'if ok else'PASS_AUTHENTICATED_COUNTEREXAMPLES_C_ZERO_NOTPASS',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,complete_native_replay_artifacts_equal=True,all15432_GF_and3936_scalar_flow_columns_audited=True,all_known_physical_and_g0_ordinary_free_blocks_audited=True,cutoff_powers_and_unknown_potential_tadpoles_retained=True,source_partner_and_translation_invariance='WRITTEN_GENERAL_PROOF_WITH_ACTUAL_SUPPORT_PREMISES',no_local_density_Gamma1_g2_or_general_QAP_claim=True,no_HB1_C5_activation_module_restoration_E5A5_or_goal_claim=True,shared_action_chart_software_AI_limit_independence=True,artifact=art,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries=len(tree.splitlines()),README_historical_suffix_sha256=sha256(history).hexdigest(),checked_local_links=links,files_excluding_pending_receipt_capture={q.relative_to(R).as_posix():digest(q)for q in files},packet_bytes_excluding_pending_receipt_capture=size,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['execution_state','evidence_validation','historical_custody','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
