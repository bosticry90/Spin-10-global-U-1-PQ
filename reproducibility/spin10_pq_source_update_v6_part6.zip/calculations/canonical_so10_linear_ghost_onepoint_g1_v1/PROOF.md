# A derivative test for the integrated one-ghost coefficient

LGO-1 is conditional on the actual support audit and validation receipt.
The target is the integrated first-u coefficient of Q Gamma1, on the C-only
mean/source plane, g<=1 and intrinsic 0/1 in the original fixed finite/formal
Euclidean prescription. It is not the local density, Gamma1 itself or the
full quantum tadpole. No physical parameter point or normalizing baseline
is adopted.

Expand each product in Q Gamma1 to first degree in the mean ghost:

    [Qz_i Gamma1_z_i]_C
      = [Qz_i]_C [Gamma1_z_i]_0 + [Qz_i]_0 [Gamma1_z_i]_C.

Use the full source operations with their LEFT pairing. At gu retain
Q0 Gamma_gu + Q1 Gamma_u + Qu0 Gamma_g + Qu1 Gamma_0; at g0u retain both
Q0 Gamma_u and Qu0 Gamma_0. No Q1 or Qu1 cross-order tadpole is inferred
from V804's Q0 result. Ghost/mean expansions are nonnegative.

## Retaining the unknown scalar-potential constants

The actual GF maps and known physical kinetic/gauge/scalar Euler rows are
tested before restriction for every constant and linear-C term. Physical
potential gradients can leave UNKNOWN scalar Euler constants at zero scalar
mean. Keep each of them symbolically; differentiating a discarded potential
and asserting zero would be invalid here. Physical potential is ghost free,
so it supplies no other C-only term. No mean shift removes its tadpole.

V801's exact fixed-mean determinant derivative gives, for every scalar
coordinate x (indices 180..507),

    Gamma1_Jx = < T² F_x / 2 >.

Audit the complete scalar F maps. F0_x and both probe flows vanish, while
F1_x has precisely the g Cx shape. Its quadratic fluctuation insertion has
one GF ghost leg and one scalar leg. Since that insertion already costs
g1, only g0 covariance can contribute through g1. The complete g0 GF
ordinary/probe Hessians and free inverse preserve GF plus scalar blocks
on this plane. Arbitrary pure-scalar potential chains preserve them too.
One cross insertion cannot close a trace, regardless of its coefficient,
sign, derivative placement or number of within-block insertions.

Thus Gamma1_Jx vanishes through g1 on the DECLARED plane, including all
first-u coefficients needed in the four products above. This is a separate
source-derivative identity derived from the actual F maps, not an automatic
extension of V830's allowed external source list. It removes each unknown
potential-Euler constant by multiplication with an independently proved
zero partner. It assigns none of those constants a value. At g2 a second
g1 crossing can return, so the argument cannot be extended to that order.

The matter action has only the K_P qP source term, no Jx coupling. The
PSK ideal is stable under the operations used here; its mixed fermion/boson
Hessians vanish after restriction. Matter cannot supply the missing scalar/
GF return. Actual matter operations carry P,S or K and vanish on the plane.
The hatted defect and source-sensitive counterexample remain in their scope.
Block preservation is a formal operator statement for the existing defined
determinant, not a new convergence or fully resummed potential theorem.

## Boundary identity for the remaining linear-C maps

If the audited actual maps have no other constant term and each surviving
linear-C term is a constant coefficient times an ordinary derivative jet
of C of positive order, its remaining proper derivative is a one-point
functional derivative evaluated at zero means/sources and constant u.
Translation invariance of the action, regulator and reference prescription
makes that one-point derivative spacetime constant. This holds separately
at every g/u order and every finite common cutoff.

Integrating by parts therefore gives

    integral (D_mu1 ... D_muk C_c) T_i = 0,  k>=1,

on the inherited ordinary-boundary/test-function domain. T_i may contain
power divergences, logarithms, arbitrary symbolic parameters and tensor
indices; none is assumed small or zero. The argument would fail for a
position-dependent T_i, yielding C times derivatives of T_i. It does not
discard cutoff^4 C by type or substitute zero external momentum into an
unevaluated loop. The boundary identity is established first.

The full integrated C coefficient consequently vanishes if all audited
premises pass. Its existing sequential reference is zero for the same
boundary family; no new general UV/IR interchange or detached inverse
profile theorem is claimed. Raw returning paths may remain nonempty.
There is no claim that they each vanish or that a local C density is zero.

The positive source/potential distinction and block argument received two
read-only AI reviews. Action, chart, software and AI authorship are shared;
this is not external independent validation. A failed premise must leave
the C contribution unresolved and its exact counterexample retained.

On success, five extra g1 profiles still remain: Lambda C, Lambda² C,
BC, Lambda aCC and BaCC. Their coefficients are not supplied by the
similarly named g0 results. Next audit their actual coupled dependencies
and the V824 witness's inverse carrier support before more integrations.
Do not construct an H-basic selector/cohomology matrix under a new name;
HB1/C5 remain blocked. Ambient non-Q-closed correction candidates differ
from Q-closed differences of already restored constructions. Full quantum
admissibility, common restoration, E5/A5 and physical viability remain open.
