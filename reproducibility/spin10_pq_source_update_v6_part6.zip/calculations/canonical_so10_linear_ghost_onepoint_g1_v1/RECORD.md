# Linear-ghost one-point test

LGO-1 continues V831 / bdc562058574d898b83e7e2895bc386b0ebde1ae, main,
D: repository. Fresh preflight is clean/no matching Python workers. Full
goal active; current AGENTS.md, state 113 / authority 34/39 unchanged.
Flavor paused and HB1/C5 blocked. No adoption, protected promotion,
branch/worktree, remote or destructive action. Root owns all writes/runs;
two AI reviewers provided read-only semantic reviews with shared-error limits.

Question: does the integrated single-C coefficient of Q Gamma1 vanish at
first-u H/M, g<=1, intrinsic 0/1, in the fixed formal Euclidean determinant
domain? V827 leaves 20 M and 10 H g1 typed paths; they are not amplitudes.
No g0 result is transferred to g1 by name. Do not discard a possible
cutoff^4 times C tadpole by dimensional bookkeeping.

Freeze complete source-first native/replay F/E packets, V801 determinant
derivative identity, g0 full GF ordinary Hessians, V791 inverse and CPS/SMA
matter premises. All source derivatives precede restrictions. On the C-only
mean/source plane audit all 7,716 GF operation columns per route for C-degree
zero and one, retaining full projected polynomials. Known physical E0 and
E1_B gauge/scalar rows are audited separately. Test whether all actual
constants are absent and every linear-C survivor has ordinary derivatives.
Any counterexample stays nonzero and blocks this inference.

UNKNOWN physical scalar Euler constants are not set zero. Audit all 328
scalar field ports: F0=Fu0=Fu1=0 and every F1 word has exactly one C and
one scalar. V801 gives Gamma1_Jx=<T²F_x/2>. Through g1 this is a single
GF/scalar cross insertion contracted against only g0 covariance. Audit the
complete g0 ordinary Hessians on the C-only plane and complete free inverse
for block preservation. Arbitrary pure-scalar potential chains preserve the
same splitting. Thus their source derivatives vanish on this plane if the
audit passes, independently of the unknown potential tadpoles. Keep both
constant-operation times linear-C proper derivative AND linear-C operation
times constant proper derivative in every full g/u convolution.

The remaining one-point proper derivatives are translation invariant at
zero means/sources and constant u, even with cutoff-dependent coefficients.
Only then integrate differentiated C by parts. This proves an INTEGRATED
functional coefficient zero, not a zero local density or a zero Gamma1.
Keep PSK restrictions after permitted operations, no scalar/matter-source
derivatives except the explicitly proved Jx partner identity, no inverse
mean/ghost expansion, no g2 claim or shifted tadpole baseline.

Controls retain full maps with C jets artificially erased, and a two-block
adjacency control admitting a false GF/scalar return. The latter is support
only, not a physical Gaussian amplitude. Preserve blind cases. A nonconstant
one-point coefficient would leave a C times derivative-of-coefficient term;
the translation-invariance premise is substantive.

One sequential job executes both new support routes and final verification,
with exact native/replay comparison and independent count/type checks. Bound
240 seconds after imports, 8 GiB sampled private memory, 350 MiB launch
floor, 16 MiB packet / 4 MiB artifact. Preserve complete overflow on D: and
stop incomplete, never truncate. Full captures repo and D: controls/
linear-ghost-onepoint-g1-v1-2026-11-07 before judging. E4 once/no fresh/fixed
D: context; expected 0,0,0,0,0,2 and seven custody references NOTPASS. Verify
old tree except README live prefix, historical suffix, unchanged state and
staged raw bytes before local commit. No loop integration or large basis.

Possible dispositions: supported integrated C zero; measured zero-jet or
constant operation requiring a genuinely unknown quantum companion; failed
scalar-source/block premise; or incomplete execution. No missing coefficient
is chosen to obtain zero. Common restoration, full admitted module and
QAP/measure/products/equivalence/E5/A5 remain open.
