# V898 — The Euclidean transition survives every common kappa

Color 17 adds a genuine DMM seagull and a switch divergence FFMM
term. Its two scalar root blocks remain. Native and replay agree on
the literal 140 D rows, 14 Y rows and 44 switched divergence triplets,
including the nonzero Phi and Sigma contractions. The DMM tail and
its improved UV difference are integrable. The extra FFMM term has
the same differentiated internal ghost and a switch derivative
which makes it vanish. The V897 normalized tadpole estimates apply
in each positive mass block.

The fully summed transition coefficients are
m_12=(51/2)L_Sigma and m_17=300 L_Phi+(51/20)L_Sigma.
With matched source shapes the same positive exterior Green
integral multiplies both. Subtracting (2017/170) times the color-12
coefficient from color 17 leaves 300 log(M_Sigma/M_Phi). Thus the
selected Euclidean switched and direct prescriptions disagree for
at least one of these colors at every common kappa when the positive
reference masses differ. Equal masses leave this combination blind.

V1 stopped at an incorrect slope subtraction. V2 uses the sum of
both color-17 YY weights and checks the special L_Sigma=0 case
separately. The failed packet is retained. Require final replay and
capture. These are the stated Euclidean graphwise UV sums, with the
inherited reference and normalization. The causal weak boundary,
other normalization prescriptions and physical equivalence remain
open. The routes share model inputs, software and AI authorship.
