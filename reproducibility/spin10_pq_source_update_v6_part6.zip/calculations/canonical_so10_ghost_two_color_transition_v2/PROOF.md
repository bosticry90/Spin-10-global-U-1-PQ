# Two-color test of the summed Euclidean transition

Keep the V897 prescription, full internal and exterior quadratic
switch sums, and the same source shapes on the two ordered color
projections. The coupling order is g^4 with two explicit xi powers
at one loop. A and retained sources are zero and scalar mass
differences are at degree zero. The squared reference masses
M_Phi and M_Sigma are positive and distinct. Use the same broad
monotone compact radial switch on both colors, with fixed width
before dilation and the original common symbolic kappa.

## Actual color-17 additions

The two exterior ghosts are C570 and a615 in the joined chart.
There is no diagonal cubic with a B or Lambda port. The actual
Y cubic inventory has six Phi and eight Sigma rows. The general
valence and explicit-coupling argument of V896 is unchanged.
For the proper seagull D, color 17 has 140 literal rows: 64 HH,
40 HM and 36 MM. Both B ports must connect through M=x Lambda
to the scalar line, so only MM can contribute. Quadratic switch
dressings are color diagonal and preserve the H/M exclusion.
The resulting DMM loop uses two mixed edges and one scalar.

The raw derivative-triplet inventory contains 44 equal-cell
B_M C_H a17 triplets with all three placements. At compact
switching their divergence gives a genuine derivative of the
switch with external a17. The internal C_H cannot enter Y,
whose two ghost colors are M, so it contributes only in FFMM.
There its partner is the ordinary F with external C17 and
internal a_H. The partner differentiates its internal
antighost. In the new divergence vertex the switch derivative
replaces the derivative on the exterior antighost. The two
color contractions against M are nonzero in both Phi and
Sigma in the actual joined rows. The bare products before
the switch divergence sign, orientation and loop factors are
−115/2 and −63/200. The covariance does not create a second
such divergence vertex on the C17 end.

The one-port attachment again has exactly one Y with the two
exterior colors. It now opens a scalar in either block. In
each block the possible remaining loops and their exclusions
are those of V896. In particular the gauge trace contractions
are against a diagonal pair, and the crossed H/M pair in the
BB Lambda vertex remains zero. The new LambdaLambda inverse
cannot create a different trivalent attachment. The retained
feedback is the massive kinetic tadpole bridge and the Y
ghost tadpole, whose finite massless residue must remain in
paired regulator comparisons. Their normalized continuum
calculations are made block by block.

## Transfer of the full switching estimate

The added DMM cycle has relative powers 3+3+2=8 in eight
dimensions. Its total logarithmic UV divergence is treated
by the original common conversion on the bare internal
part. One switched-edge difference improves that power,
so the switched difference is absolutely integrable at
the total diagonal. Individual relative powers below four
handle partial diagonals. With the massive link integrated,
the two mixed factors decay as r^-6, with a tail O(T^-2).
The tail estimate with finite massive separation follows
by the same split and exponential decay as in V897.

The added switched divergence FFMM cycle has powers
3+3+3+2=11 in twelve dimensions. One derivative is on
the internal ghost and one is on the compact switch.
Its relative integral is already locally integrable and
has the FFMM tail of V897. All the dressed internal
kernels obey the same uniform bounds. The factor
||grad sigma_R||_infinity=O(R^-1) beats the O(log R)
exterior cost. Therefore this extra branch vanishes
even after the internal and exterior sums. The ordinary
nondivergence FFMM and FMY derivative assignments keep
their original bounds.

The massive feedback has the identical finite list of
UV-sensitive switch counts as V897 in each positive
reference block. Use the full regulated forest for
the subtractions, including when the switch sits on
the massive bridge alone. The differentiated bridge
and the action Ward identity for local derivatives
are the same as there. Thus the complete difference
from switched internal edges again vanishes. The
ordinary switches of the bare internal group have
the V894 independent-transfer estimate with the
added DMM massless degree two. The sole new explicit
divergence vertex has already been estimated.

## Inherited constants and a normalization-independent witness

The independently bound pole rows and V882 radial
conversion give (D,F,Y)=(115,85,300) for Phi and
(63/100,57/100,51/20) for Sigma. The massive feedback
has the negative sum in each scalar block. Its kinetic
part carries three ordinary switches including the
root Y. The proper DMM and FMY also carry three, and
YY carries two. The vanishing continuum Y one-edge
tadpole gives no constant. The color-17 transition is
therefore m_17 sigma²(1−sigma) with

    m_17=300 L_Phi+(51/20)L_Sigma,
    L_s=log(mu²/M_s)+kappa−gamma_E−2 log 2.

The exterior ghost operator and source ordering are
identical for these two colors. Let H_chi be the
positive integral of chi²(1−chi) G_chi² from V895.
For the same two nonzero source integrals J_a and J_C,
the signed switched-minus-uncut difference in each
projection has the common prefactor and factor
m_i H_chi J_a J_C in stripped proper units. The
linear combination of the color-17 projection minus
(2017/170) times color 12 isolates

    m_17−(2017/170)m_12=300 log(M_Sigma/M_Phi).

It is nonzero for the stated distinct positive
reference masses at every common kappa. This
combination tests the same switched prescription
and uses the same normalization in both colors.
It preserves the nonconstant terms' ordinary uncut
limits. At equal masses the combination is blind.
No choice of physical parameters is made.

The result is a discrepancy between the selected
fully summed Euclidean switched coefficient and its
direct paired counterpart for the admitted profiles.
It uses the common graphwise UV conversion before
summing. The full Lorentzian causal weak boundary,
different normalization prescriptions, and general
physical equivalence are separate obligations.
Shared action, conventions, software and AI authorship
limit the independence of the exact checks.
