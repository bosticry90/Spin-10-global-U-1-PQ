# V898 pre-execution contract

Test whether the common symbolic normalization can remove
the fully summed V897 Euclidean discrepancy in both
color-12 and color-17 ordinary ghost projections. Keep
one loop, g^4 and two explicit xi factors, degree-zero mass
differences, A and retained sources zero, common exterior
source shapes and broad compact radial switching. Both
positive squared scalar reference masses are retained
and taken distinct for the discriminating comparison.

Bind both current and physical pole routes. Require the
literal additional D and Y rows, the extra F divergence
assignment, its actual color contractions and its vanishing
switch estimate. Check the one-port coefficient by the
blockwise orbit norm. Preserve the full inherited common
normalization and the V883 paired control. Qualify the
two-color Euclidean comparison only.

Native 120 s, final 180 s including E4 cap of 120 s,
8 GiB sampled private, 350 MiB launch commit floor,
8 MiB artifact, 32 MiB packet. Freeze proof, code and
owner bytes. Require replay and exact staged bytes.
