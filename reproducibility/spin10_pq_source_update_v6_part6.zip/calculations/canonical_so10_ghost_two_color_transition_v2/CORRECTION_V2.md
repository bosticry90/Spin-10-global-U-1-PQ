# V898 versioned common-constant correction

V1 passed the literal checks and stopped at the two-color
elimination assertion. The proposed 1/10 multiple only
subtracted the Sigma contribution to the common coefficient.
With L_Phi=L_Sigma+log(M_Sigma/M_Phi), the Phi YY weight also
contributes to the common slope. V2 derives the multiplier
(300+51/20)/(51/2)=2017/170 from the bound rows. It tests
exact cancellation and independently evaluates at L_Sigma=0.
The graph, loop and scope requirements are unchanged.
The complete failed V1 packet and hash inventory are in
preserved_active_v1 under the V1 D control directory.
