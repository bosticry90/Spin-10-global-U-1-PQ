"""Compare the literal color-17 paths and the common normalization."""

from collections import Counter, defaultdict
import gzip
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def path(owner, name):
    return ROOT/"calculations"/("canonical_so10_"+owner)/name


def read(owner, name):
    return json.loads(path(owner,name).read_bytes())


def coefficient(cells):
    return sp.expand(sum(sp.Rational(n,d)*sp.sqrt(sp.prod(p for i,p in enumerate((2,3,5,7))
                         if mask&(1<<i)))*(sp.I if mask&16 else 1)
                         for (_,_,mask),n,d in cells))


def literal(role):
    with gzip.open(path("unprobed_compact_all_coupling_v1",role+"_full_current.json.gz"),"rt",encoding="utf-8") as stream:
        rows = json.load(stream)["current"]["complete_S_GF_source"]
    D,Y = Counter(),Counter()
    divergence = defaultdict(dict)
    ordinary = {}
    E = {}
    for grade,word,cells in rows:
        ids = [i for i,_ in word]
        if any(i>=643 for i in ids):
            continue
        if grade == 1 and len(ids)==2 and 180<=ids[0]<508 and 520<=ids[1]<553:
            E[ids[1]-508,ids[0]] = coefficient(cells)/sp.I
        if {570,615} <= set(ids):
            if len(ids)==3:
                assert grade==2 and 180<=ids[0]<486
                Y["Phi" if ids[0]<234 else "Sigma"] += 1
            if len(ids)==4 and ids[1]<180:
                assert grade==2
                D["".join("H" if i<48 else "M" for i in ids[:2])] += 1
        if grade!=1 or len(ids)!=3 or not (48<=ids[0]<180):
            continue
        B,C,a=ids
        if 553<=C<565 and a==615:
            places=[i for i,(_,jet) in enumerate(word) if jet]
            assert len(places)==1 and word[places[0]][1]==[B%4]
            divergence[B,C-553][places[0]]=cells
        if C==570 and 598<=a<610:
            assert word[0][1]==word[1][1]==[] and word[2][1]==[B%4]
            if B%4==0:
                ordinary[B//4,a-598]=coefficient(cells)
    assert D == {"HH":64,"HM":40,"MM":36}
    assert Y == {"Phi":6,"Sigma":8}
    assert len(divergence)==44
    assert all(set(c)=={0,1,2} and c[0]==c[1]==c[2] for c in divergence.values())
    d={(B//4,k):coefficient(cells[0]) for (B,k),cells in divergence.items() if B%4==0}
    assert len(d)==11 and ordinary == {key:-v for key,v in d.items()}
    contracted={}
    for label,lo,hi in (("Phi",180,234),("Sigma",234,486)):
        result=sp.S.Zero
        for x in range(lo,hi):
            for k in range(12):
                left=sum(E.get((b,x),0)*d.get((b,k),0) for b in range(12,45))
                if role=="native":
                    right=sum(E.get((b,x),0)*ordinary.get((b,k),0) for b in range(12,45))
                    result+=left*right
                else:
                    result-=left**2
        contracted[label]=sp.simplify(result)
    assert contracted=={"Phi":-sp.Rational(115,2),"Sigma":-sp.Rational(63,200)}
    feedback = {label:sp.simplify(2*casimir*sum(E.get((17,x),0)**2 for x in range(lo,hi)))
                for label,lo,hi,casimir in (("Phi",180,234,10),("Sigma",234,486,sp.Rational(25,2)))}
    assert feedback == {"Phi":500,"Sigma":sp.Rational(15,4)}
    return {"kinetic_feedback_weight":{k:str(v) for k,v in feedback.items()},
            "D_literal_rows":dict(D),"Y_literal_rows":dict(Y),
            "divergence_triplets":len(divergence),"raw_divergence_F_E_pair":
            {k:str(v) for k,v in contracted.items()}}


def normalization(role):
    variant="primary" if role=="native" else "replay"
    rows=read("ghost_mass_g4_pole",variant+"_v2_result.json")["physical_scalar_sector_family_poles"]
    profiles=read("uncut_ghost_profile_v1","result.json")["checks"]["actual_scalar_algebra"]
    table={}
    for block in ("Phi","Sigma"):
        table[block]=[sum(sp.sympify(v) for a,c,v in rows[block][f] if (a,c)==(17,17))
                      for f in ("DMM","FMY","YY")]
        assert table[block]==[sp.sympify(x) for x in profiles[block]["row17_families"]]
    assert table=={"Phi":[115,85,300],"Sigma":[sp.Rational(63,100),sp.Rational(57,100),sp.Rational(51,20)]}
    s,L,ratio=sp.symbols("s L_Sigma log_MSigma_over_MPhi")
    def switched(block):
        d,f,y=table[block]
        return (d+f-sum(table[block]))*s**3+y*s**2
    m17=table["Phi"][2]*(L+ratio)+table["Sigma"][2]*L
    m12=sp.Rational(51,2)*L
    assert sp.expand(switched("Phi")*(L+ratio)+switched("Sigma")*L-m17*s**2*(1-s))==0
    slope_ratio=(table["Phi"][2]+table["Sigma"][2])/sp.Rational(51,2)
    assert slope_ratio==sp.Rational(2017,170)
    assert sp.expand(m17-slope_ratio*m12)==300*ratio
    assert m17.subs(L,0)==300*ratio
    assert sum((3,3,2))-8==0 and sum((3,3,3,2))-12==-1
    return {"color17_poles":{k:[str(v) for v in values] for k,values in table.items()},
            "color17_minus_2017_over_170_color12":"300*log(M_Sigma/M_Phi)",
            "DMM_relative_UV_excess":0,"divergence_FFMM_relative_UV_excess":-1}


def checks(role):
    return {"literal":literal(role),"normalization":normalization(role)}


if __name__=="__main__":
    run_worker(checks,sys.argv[1])
