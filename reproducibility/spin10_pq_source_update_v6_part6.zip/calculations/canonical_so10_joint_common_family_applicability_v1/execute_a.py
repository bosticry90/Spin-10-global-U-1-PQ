from common import *
import ast,subprocess,sys
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='9a60ecbedf81d60568cad7b20578057f8ce7bfb6'
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).strip()
names=set(a.read(B/'canonical_so10_g0_common_profile_applicability_v1/preparation_v2.json')['sha256'])
folders=['canonical_so10_geometric_marked_contact_support_v1','canonical_so10_geometric_metric_insertion_lift_v1','canonical_so10_marked_geometric_primitive_transport_v1','canonical_so10_fixed_log_candidate_reality_g1_v1','canonical_so10_geometric_ward_current_source_chart_v1']
for folder in folders:
    names|={q.relative_to(R).as_posix()for q in(B/folder).iterdir()if q.is_file()}
for n in ['common.py','compute_a.py','execute_a.py','RECORD.md']:
    q=O/n
    if n.endswith('.py'):ast.parse(q.read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write(q.read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()}
enc=[]
for n in sorted(names):
    if n.startswith(O.relative_to(R).as_posix()+'/'):continue
    live=(R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R)
    if live!=stored:assert live.replace(b'\r\n',b'\n')==stored and subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set'),n
    enc.append(dict(file=n,checkout_sha256=sha256(live).hexdigest(),git_blob_sha256=sha256(stored).hexdigest(),exact_equal=live==stored))
dump(O/'input_encoding_bindings_a.json',dict(bindings=enc));dump(C/'input_encoding_bindings_a.json',dict(bindings=enc))
with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
prep=dict(base_HEAD=head,sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED',limits=dict(seconds=120,sampled_private_bytes=8*1024**3,packet_bytes=32*1024**2,artifact_bytes=8*1024**2))
dump(O/'preparation_a.json',prep);dump(C/'preparation_a.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute_a.py')]);dump(O/'capture_a.json',cap);dump(C/'capture_a.json',cap);print(cap['stdout_and_stderr']);assert cap['calculation_completed']and cap['post_run_observations_qualified']and cap['exit_code']==0
