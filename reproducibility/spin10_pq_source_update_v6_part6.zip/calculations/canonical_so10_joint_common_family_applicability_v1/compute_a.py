from common import *
import os,threading,time
def main():
    tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in a.read(O/'preparation_a.json')['sha256'].items():assert digest(R/n)==h,n
    old=a.load(B/'canonical_so10_fixed_log_candidate_reality_g1_v1/complete_phase_and_basis_checks.json.gz')
    assert old['all32_conjugation_involutions']and not old['basis_mismatches']and not old['phase_mismatch_ports']
    assert all(s==sigma(i)==sigma((i+643)%1286)for i,cs,s in old['all1286_actual_phases_and_induced_signs'])
    receipt=a.read(B/'canonical_so10_fixed_log_candidate_reality_g1_v1/validation_receipt.json');assert receipt['full_all1286_source_field_Euler_checks']and len(receipt['all12_full_sourceful_classical_anchor_densities_real'])==12
    reports=[]
    for role,owner in [('native','primary'),('replay','replay')]:
        star=native if role=='native'else replay
        ch=a.load(B/'canonical_so10_geometric_ward_current_source_chart_v1'/(owner+'_complete_geometric_current_source_chart.json.gz'));A=alphabet(ch)
        gates=a.load(B/'canonical_so10_geometric_marked_contact_support_v1'/(role+'_complete_geometric_marked_contact_support.json.gz'))
        mr=a.load(B/'canonical_so10_geometric_metric_insertion_lift_v1'/(role+'_complete_geometric_metric_insertions.json.gz'))
        roots={'K_raw':a.decode(gates['complete_K']),'K_normal':a.decode(gates['complete_K_normal'])}
        roots.update({r['name']:rename(A,a.decode(r['complete_Euclidean']))for r in mr['all_fixed_density_roots']if r['name']in['W','C_S','C_U_H','C_U_M']})
        for row in gates['all_carrier_support_gates']:
            for mode in ['raw','normal']:roots['DS_'+row['case']+'_'+mode]=a.decode(row['complete_'+mode+'_DS'])
        rootchecks=[];failures=[]
        for name,P in roots.items():
            S=star(P);diff=a.plus(S,a.scale(P,-1));assert star(S)==P
            # Preserve every discrepancy before a failure; no root is rephased.
            E=a.eulers(A,diff,set(range(1391)))if diff else{}
            row=dict(name=name,words=len(P),complete_root=a.encode(P),complete_star_minus_root=a.encode(diff),all_nonzero_Eulers=[[n,a.encode(q)]for n,q in E.items()],classification='REAL_DENSITY'if not diff else'NONREAL_DENSITY_REQUIRES_CURRENT_REVIEW')
            rootchecks.append(row)
            if diff:failures.append(name)
        ops={'D':{i:a.decode(q)for i,q in gates['all1286_D']},'C':{i:rename(A,a.decode(q))for i,q in ch['all1286_source_difference_columns']},'T':{i:rename(A,a.decode(q))for i,q in ch['all1286_direct_Tq_columns']}}
        rot=a.load(B/'canonical_so10_marked_geometric_primitive_transport_v1'/(role+'_complete_marked_geometric_transport.json.gz'));ops['epsilon_rotation']={i:a.decode(q)for i,q in rot['all33_epsilon_rotation_rules']}
        opchecks=[]
        for name,rules in ops.items():
            bad=[]
            for n,P in rules.items():
                q=a.plus(star(P),a.scale(P,-sigma(n)))
                if q:bad.append([n,a.encode(q)])
            opchecks.append(dict(name=name,columns=len(rules),nonzero_columns=sum(bool(q)for q in rules.values()),complete_discrepancies=bad))
            if bad:failures.append(name)
        # Actual Q/E programs, with physical-potential E1_x left symbolic.
        known=a.load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));flow=[]
        for group in ['states','physical']:
            for name,rows in known[group].items():
                bad=[];words=0
                for n,raw in rows:
                    P=p.old(raw);words+=len(P);q=a.plus(star(P),a.scale(P,-sigma(n)))
                    if q:bad.append([n,a.encode(q)])
                flow.append(dict(group=group,name=name,columns=len(rows),words=words,complete_discrepancies=bad))
                if bad:failures.append(name)
        controls={name:len(a.plus(native(roots['K_raw'],name),a.scale(native(roots['K_raw']),-1)))for name in ['wrong_sources','omit_time_jets','reverse_odd_order']}
        DS=roots['DS_g1_normal'];assert DS;controls['reversed_beta_rho_coefficient_difference']=len(a.scale(DS,-2));assert controls['reversed_beta_rho_coefficient_difference']>0
        # LEFT extraction has no reversal under an order-preserving star.
        assert roots['K_raw']and roots['W']and roots['C_S']and roots['DS_g1_normal']
        pins=dict(u=1,rho=1,beta=1,theta=1)
        art=save(role+'_complete_real_joint_roots.json.gz',dict(joined_names=list(A.names),joined_parities=list(A.parities),all1391_signs=[sigma(n)for n in range(1391)],complete_root_checks=rootchecks,all_operation_checks=opchecks,all_known_Q_E_checks=flow,failures=failures,strength_pins_proposed_only_until_all_checks_pass=pins,controls=controls,unknown_physical_potential_Eulers='INHERITED_REAL_ACTION_PROGRAM_NOT_ZERO',LEFT_order='partial_rho_LEFT partial_beta_LEFT extracts beta*rho; conjugation preserves order'))
        print('STAGE '+role+' complete_reality_roots_saved failures='+str(failures),flush=True)
        assert not failures,('SCOPED_REALITY_GATE_FAILED_EVIDENCE_SAVED',failures)
        reports.append(dict(role=role,artifact=art,root_words={n:len(q)for n,q in roots.items()},controls=controls,strength_pins=pins))
    dump(O/'result_a.json',dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',roles=reports,scope='CURRENT_SELECTED_CLASSICAL_ROOT_REALITY_AND_EQUIVARIANCE_ONLY',elapsed_after_imports=time.perf_counter()-tick));watch.cancel()
if __name__=='__main__':main()
