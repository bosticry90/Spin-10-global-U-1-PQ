from background import *
import os,threading,time
E3=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e3_symmetry'
def gate(label,ok,data):
    if not ok:
        save('FAILED_'+label+'.json.gz',data,64);raise AssertionError(label+'_COMPLETE_EVIDENCE_SAVED')
def main():
    tick=time.perf_counter();watch=threading.Timer(240,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in a.read(O/'preparation_b.json')['sha256'].items():assert digest(R/n)==h,n
    assert a.read(O/'capture_a.json')['calculation_completed'];reports=[]
    for role,owner in [('native','primary'),('replay','replay')]:
        ch=a.Chart(owner);saved=a.load(B/'canonical_so10_geometric_ward_current_source_chart_v1'/(owner+'_complete_geometric_current_source_chart.json.gz'));A=alphabet(saved);maps=full_maps(ch,A);e3=a.read(E3/(owner+'.json'));ops=e3['operators'];rawtb={ch.raw.index[n]:ch.rows(q)for n,q in ops['Tb_geometric_and_transported'].items()};rawtq={ch.raw.index[n]:ch.rows(q)for n,q in ops['Tq_geometric'].items()}
        canonical={ch.raw.index[n]for n in ch.frame['field_order']}|set(ch.rawJ.values())
        assert all(rawtb[n]==rawtq[n]and all(i not in ch.extA for g,w in rawtb[n]for i,j in w)for n in canonical)
        pushed=ch.vector(rawtb);assert all(pushed[n]==a.decode(q)for n,q in saved['all1286_direct_Tq_columns'])
        T={n:rename(A,q)for n,q in pushed.items()};local=a.load(B/'canonical_so10_fixed_log_candidate_background_g1_v1'/(owner+'_local_basis.json.gz'));tb=background_rules(A,ch,T,local)
        # Independently push each full raw A output through the inverse V frame.
        ara={ch.raw.index['omega'+str(h)]:a.plus(*(a.factor(a.atom(1379+i),c)for(hh,i),c in ch.V.items()if hh==h))for h in range(12)}
        amap={**maps,**ara};actualA={1331+i:{}for i in range(48)}
        for h in range(12):
            for mu in range(4):
                rawout=substitute(A,rawtb[ch.raw.index['A'+str(h)+'_'+str(mu)]],amap)
                for(i,hh),co in ch.W.items():
                    if hh==h:actualA[1331+4*i+mu]=a.plus(actualA[1331+4*i+mu],a.factor(rawout,a.multiply_coefficients(co,a.ph(-(mu==0)))))
        assert all(actualA[n]==tb[n]for n in actualA),'FULL_A_TRANSPORT_VS_SAVED_CARRIER_MISMATCH'
        for n,q in tb.items():assert not a.plus(native(q),a.scale(q,-sigma(n))),('NONREAL_BACKGROUND_COLUMN',n)
        comm=[]
        for n in range(1286):
            q=a.plus(p.action(A,T[n],tb,owner),a.scale(p.action(A,tb[n],T,owner),-1));comm.append([n,a.encode(q)])
        assert not any(q for n,q in comm),'EXTENDED_BACKGROUND_QUANTUM_MIXED_ALGEBRA_FAILED'
        # Full portable S includes GF and ALL 643 canonical source couplings.
        rawS=ch.rows(ch.data['gauge_fixing_density']);rawgf=dict(rawS)
        for f,j,h,k in ch.pairs:
            q=ch.rows(ch.data['master_field_maps'][ch.raw.names[f]])
            for key,co in ch.raw.product(a.atom(j),q).items():a.put(rawS,key,co)
        Sf=selected(substitute(A,rawS,maps,True),4)
        W=selected(substitute(A,ch.rows(e3['quantum_fermion_breaking']),maps,True),3)
        assert flat(W)==rename(A,a.decode(saved['complete_W']))
        for g in range(2):
            old=a.load(B/'canonical_so10_acceptance_parent_reconciliation_v1'/(role+'_v2_complete_parent_g'+str(g)+'.json.gz'))
            assert p.grade(flat(Sf),g)==p.old(old['complete_transported_portable_parent'])
        gate(role+'_FULL_A_ROOT_REALITY',not a.plus(native(Sf),a.scale(Sf,-1))and not a.plus(native(W),a.scale(W,-1)),dict(complete_S=a.encode(Sf),complete_W=a.encode(W),complete_S_delta=a.encode(a.plus(native(Sf),a.scale(Sf,-1))),complete_W_delta=a.encode(a.plus(native(W),a.scale(W,-1)))))
        tw=p.action(A,W,tb,owner)
        K=a.decode(a.load(B/'canonical_so10_geometric_marked_contact_support_v1'/(role+'_complete_geometric_marked_contact_support.json.gz'))['complete_K'])
        EW=a.eulers(A,W,set(range(643)));cs={643+i:q for i,q in EW.items()};CK=p.action(A,K,cs,owner);assert not CK
        # C and T do not differentiate the external fields as canonical sources.
        CS=p.action(A,Sf,cs,owner);assert not a.plus(native(CS),a.scale(CS,-1));assert all(sum(n<643 for n,j in w)<=1 for g,w in p.grade(CS,0))
        inputs=a.load(B/'canonical_so10_mixed_probe_auxiliary_ward'/(owner+'_tables.json.gz'));oldFJB=a.load(B/'canonical_so10_full_jet_source_master_bridge'/(owner+'_tables.json.gz'));probes=[]
        for pr,label in enumerate(['H','M']):
            G=selected(full_packet(ch,A,inputs,inputs['physical_G'][pr]),3);U=selected(full_packet(ch,A,inputs,inputs['physical_QG'][pr]),4)
            gate(role+'_'+label+'_FLAT_G',flat(G)==p.old(oldFJB['probes'][pr]['G']),dict(complete_G=a.encode(G),complete_flat_minus_old=a.encode(a.plus(flat(G),a.scale(p.old(oldFJB['probes'][pr]['G']),-1)))))
            ref=a.load(B/'canonical_so10_geometric_probe_Ward_insertion_v1'/(role+'_complete_'+label+'_even_geometric_insertion_v2.json.gz'))
            gate(role+'_'+label+'_FLAT_U',flat(U)==a.decode(ref['complete_selected_U']),dict(complete_U=a.encode(U),complete_flat_minus_old=a.encode(a.plus(flat(U),a.scale(a.decode(ref['complete_selected_U']),-1)))))
            gate(role+'_'+label+'_FULL_A_PROBE_REALITY',not a.plus(native(G),a.scale(G,-1))and not a.plus(native(U),a.scale(U,-1)),dict(complete_G=a.encode(G),complete_U=a.encode(U),complete_G_delta=a.encode(a.plus(native(G),a.scale(G,-1))),complete_U_delta=a.encode(a.plus(native(U),a.scale(U,-1)))))
            tg=p.action(A,G,tb,owner);CU=p.action(A,U,cs,owner);DU=p.action(A,U,{n:a.decode(q)for n,q in a.load(B/'canonical_so10_geometric_marked_contact_support_v1'/(role+'_complete_geometric_marked_contact_support.json.gz'))['all1286_D']},owner)
            assert not a.plus(native(CU),a.scale(CU,-1));assert all(sum(n<643 for n,j in w)<=1 for g,w in p.grade(CU,0))
            probes.append(dict(probe=label,complete_G=a.encode(G),complete_U=a.encode(U),complete_TbG=a.encode(tg),complete_CU=a.encode(CU),complete_DU=a.encode(DU),G_raw_positions=inputs['physical_G'][pr]['positions'],QG_raw_positions=inputs['physical_QG'][pr]['positions'],excluded_G_positions=inputs['physical_G'][pr]['positions']-len(selected(full_packet(ch,A,inputs,inputs['physical_G'][pr]),3)),U_QG_lineage='MWA_PRIMARY_Q0_THEN_SOURCE_SHIFT_VS_REPLAY_QPRIME_AFTER_SHIFT; FULL_E3_CANONICAL_CONJUGACY',background_U_proof='TbG=0 and inherited [Tb,Q]=0',no_new_U_Ward_expansion=True))
            print('STAGE '+role+' full_'+label+'_probe_transported',flush=True)
        failures=[]
        if tw:failures.append('TbW')
        for row in probes:
            if row['complete_TbG']:failures.append('TbG_'+row['probe'])
            if row['complete_DU']:failures.append('DU_'+row['probe'])
        artifact=save(role+'_complete_full_background_extension.json.gz',dict(joined_names=list(A.names),joined_parities=list(A.parities),all1391_Tb_columns=[[n,a.encode(tb.get(n,{}))]for n in range(1391)],all1286_mixed_algebra_residuals=comm,complete_S_GF_source=a.encode(Sf),complete_W=a.encode(W),complete_TbW=a.encode(tw),complete_CK=a.encode(CK),complete_CS=a.encode(CS),probes=probes,failures=failures,full_physical_action='UNCHANGED_REAL_BACKGROUND_COVARIANT_AST; NO_PHYSICAL_POTENTIAL_EULER_ZERO',source_operations=1286,full_A_lineage_not_flat_only=True,phase_A_flat_strength_pins='UNCHANGED; FULL_A_ROOT_REALITY_CHECKED'),64)
        print('STAGE '+role+' full_background_evidence_saved failures='+str(failures),flush=True);assert not failures,('FULL_A_GATE_FAILED_EVIDENCE_SAVED',failures)
        reports.append(dict(role=role,artifact=artifact,full_S_words=len(Sf),full_W_words=len(W),probes=[{k:len(v)if isinstance(v,list)else v for k,v in z.items()if not k.startswith('complete_')}for z in probes]))
    dump(O/'result_b.json',dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',roles=reports,full_background_heat_profile_NOT_identified=True,elapsed_after_imports=time.perf_counter()-tick));watch.cancel()
if __name__=='__main__':main()
