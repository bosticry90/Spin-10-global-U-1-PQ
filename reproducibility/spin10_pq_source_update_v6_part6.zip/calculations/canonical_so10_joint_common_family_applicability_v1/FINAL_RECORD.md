# V865 separate final review

Review uses300s/8GiB sampled/64MiB combined packet/8MiB artifact, unchanged
from RECORD. Freeze code, inputs and current navigation before execution.
Authenticate earlier A/B preparations against their original bytes; archive
old README/campaign bytes before updating live navigation. Historical binds
are not changed. Root owns all writes/runs/Git; AI reviews are read-only.

Use independent sparse Fraction conjugation/action with explicit graded
permutations, all completed new roots and current background columns,
direct full-G/W background tests, a sensitive frozen-A control, the explicit
epsilon multiplet extension and its nonzero inert insertion. Compare complete
full-A portable GF and all643 field maps with E2 BEFORE A0. This closes the
parent lineage used by MWA U=QG; physical-potential Euler programs stay intact.
U background covariance uses that lineage and the full E3 commutator, not a
new U amplitude or a repeated huge U Ward expansion.

Check the generic LEFT extraction lemma, a sensitive canonical-source master
calibration, and all160 finite local-grammar budget states. Retain local
n<=9 versus the full nonlocal determinant distinction. DSP §7's complete
local-breaking reality theorem is required in addition to classical reality;
no arbitrary effective action is real-projected and no nonlinear master
commutation with projection is asserted.

Metadata correction: compute_b's excluded_G_positions is raw positions minus
FINAL output positions, which is not an excluded raw-row count under a
nontrivial linear A map. Preserve that completed worker/source/output
unchanged. Final review supplies the full raw-row coupling/intrinsic
disposition census and explicitly supersedes that proxy label. This corrects
reporting, without changing an operand, exclusion rule or scientific check.

Authenticate preparations/captures/encodings, old Git tree, unchanged state,
current navigation and preserved historical README. Fixed E4 runs once with
expected0,0,0,0,0,2 and exactly seven custody NOTPASS. Failure/exhaustion keeps
complete captures and no qualification. No protected promotion, physical
normalization/baseline choice, profile identification, push or publication.

Primary A completed30.48s, primary B116.97s. Shared old action, algebra,
analytic premises, symbolic software and AI authorship limit independence.
No external scientist, experiment or Lean verification is claimed.
