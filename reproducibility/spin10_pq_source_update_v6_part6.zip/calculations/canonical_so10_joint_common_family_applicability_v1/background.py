from common import *
def substitute(A,P,maps,density=False):
    out={};cache={}
    for(g,w),cs in P.items():
        if g>1:continue
        term={(g,()):a.scale_coefficient(cs,-1 if density else 1)}
        for n,j in w:
            if(n,j)not in cache:
                assert n in maps,('UNMAPPED_FULL_A_PORT',n)
                cache[n,j]=a.factor(a.jets(A,maps[n],j),a.ph(j.count(0)))
            term=A.product(term,cache[n,j])
        for k,v in term.items():a.put(out,k,v)
    return out
def replace(A,P,fn):
    out={}
    for(g,w),co in P.items():
        ww,sg=A.canonical(tuple((fn(n),j)for n,j in w))
        if sg:a.put(out,(g,ww),a.scale_coefficient(co,sg))
    return out
def full_maps(ch,A):
    maps={n:rename(A,q)for n,q in ch.maps.items()}
    for h in range(12):
        for mu in range(4):maps[ch.raw.index['A'+str(h)+'_'+str(mu)]]=a.plus(*(a.factor(a.atom(1331+i*4+mu),a.multiply_coefficients(c,a.ph(mu==0)))for(hh,i),c in ch.V.items()if hh==h))
    assert set(maps)==set(ch.maps)|ch.extA
    return maps
def full_packet(ch,A,z,packet):
    # These operands ALREADY use canonical physical field/source coordinates.
    # Only raw E3 external A receives a nontrivial matrix transformation.
    maps={};rawJ={ch.raw.names[j]:643+A.index[ch.raw.names[f]]for f,j,h,k in ch.pairs};fm=full_maps(ch,A)
    for n,name in enumerate(z['names']):
        if name in A.index and A.index[name]<1286:i=A.index[name];maps[n]=a.factor(a.atom(i),a.ph(phase(i)))
        elif name in rawJ:i=rawJ[name];maps[n]=a.factor(a.atom(i),a.ph(phase(i)))
        elif name in ch.raw.index and ch.raw.index[name]in ch.extA:maps[n]=fm[ch.raw.index[name]]
    P={}
    for g,w,ci in packet['monomials']:
        co=tuple(((x,e,m),F(num,den))for x,e,m,num,den in packet['coefficients'][ci]);a.put(P,(g,tuple((n,tuple(j))for n,j in w)),co)
    return substitute(A,P,maps,True)
def flat(P):return {k:v for k,v in P.items()if all(not 1331<=n<1379 for n,j in k[1])}
def co4(rows):
    assert all(k[0]==0 for k,num,den in rows)
    return tuple((tuple(k[1:]),F(num,den))for k,num,den in rows)
def background_rules(A,ch,T,local):
    tb={n:replace(A,q,lambda i:i+60 if 1319<=i<1331 else i)for n,q in T.items()}
    for i in range(48):tb[1331+i]=a.atom(1379+i//4,(i%4,))
    for h,mat in enumerate(local['all12_complete_A48_carriers']):
        for i,j,co in mat:
            assert 2605<=i<2653 and 2605<=j<2653
            a.put(tb[1331+i-2605],(1,((1331+j-2605,()),(1379+h,()))),co4(co))
    # Actual canonical LIGHT-GHOST carrier fixes the quantum-parameter rule.
    for i in range(12):
        P=replace(A,tb[553+i],lambda n:1319+n-553 if 553<=n<565 else n)
        expected={}
        for h,mat in enumerate(local['all12_complete_A12_carriers']):
            for ii,j,co in mat:
                if ii==i:a.put(expected,(1,((1319+j,()),(1379+h,()))),co4(co))
        assert P==expected,('ACTUAL_GHOST_PARAMETER_CARRIER_DIFFERS',i);tb[1319+i]=P
    return tb
