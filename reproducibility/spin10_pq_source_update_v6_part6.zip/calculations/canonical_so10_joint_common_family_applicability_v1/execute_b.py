from common import *
import ast,subprocess,sys
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='9a60ecbedf81d60568cad7b20578057f8ce7bfb6'
old=a.read(O/'preparation_a.json')
for n,h in old['sha256'].items():assert digest(R/n)==h,n
assert a.read(O/'capture_a.json')['calculation_completed']and a.read(O/'result_a.json')['execution_state']=='COMPLETED'
names=set(old['sha256'])
for folder in ['canonical_so10_mixed_probe_auxiliary_ward','canonical_so10_full_jet_source_master_bridge']:
    names|={q.relative_to(R).as_posix()for q in(B/folder).iterdir()if q.is_file()}
for n in ['background.py','compute_b.py','execute_b.py']:
    ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()}
enc=[]
for n in sorted(names):
    if n.startswith(O.relative_to(R).as_posix()+'/'):continue
    live=(R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R)
    if live!=stored:assert live.replace(b'\r\n',b'\n')==stored and subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set'),n
    enc.append(dict(file=n,checkout_sha256=sha256(live).hexdigest(),git_blob_sha256=sha256(stored).hexdigest(),exact_equal=live==stored))
dump(O/'input_encoding_bindings_b.json',dict(bindings=enc));dump(C/'input_encoding_bindings_b.json',dict(bindings=enc))
prep=dict(base_HEAD=old['base_HEAD'],sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED',limits=dict(seconds=240,sampled_private_bytes=8*1024**3,packet_bytes=64*1024**2,artifact_bytes=8*1024**2))
dump(O/'preparation_b.json',prep);dump(C/'preparation_b.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute_b.py')]);dump(O/'capture_b.json',cap);dump(C/'capture_b.json',cap);print(cap['stdout_and_stderr']);assert cap['calculation_completed']and cap['post_run_observations_qualified']and cap['exit_code']==0
