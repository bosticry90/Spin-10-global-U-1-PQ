"""Separate V865 review: sparse Fraction coefficients and explicit generators."""
from common import *
from collections import defaultdict
import os,threading,time,subprocess
def cells(rows):return{(tuple((n,tuple(j))for n,j in w),(g,x,e,m)):F(num,den)for g,w,co in rows for(x,e,m),num,den in co}
def clean(P):return{k:v for k,v in P.items()if v}
def add(*items):
    q=defaultdict(F)
    for P,s in items:
        for k,v in P.items():q[k]+=v*s
    return clean(q)
def rawstar(P,signs):return{k:v*(-1)**(bool(k[1][3]&16)+sum(j.count(0)for n,j in k[0]))*__import__('math').prod(signs[n]for n,j in k[0])for k,v in P.items()}
def canon(w,par):
    if any(par[n]and w.count((n,j))>1 for n,j in w):return None,0
    sg=(-1)**sum(par[w[i][0]]*par[w[j][0]]for i in range(len(w))for j in range(i+1,len(w))if w[i]>w[j]);return tuple(sorted(w)),sg
def mul(P,Q,par):
    out=defaultdict(F)
    for(w,k),v in P.items():
        for(z,l),b in Q.items():
            if k[0]+l[0]>1:continue
            ww,s=canon(w+z,par)
            if not s:continue
            f=1
            for bit,sq in enumerate([2,3,5,7,-1]):
                if k[3]&l[3]&(1<<bit):f*=sq
            out[ww,(k[0]+l[0],k[1]+l[1],k[2]+l[2],k[3]^l[3])]+=v*b*s*f
    return clean(out)
def dx(P,mu,par):
    out=defaultdict(F)
    for(w,k),v in P.items():
        for at,(n,j)in enumerate(w):
            ww,s=canon(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:],par)
            if s:out[ww,k]+=v*s
    return clean(out)
def action(P,rules,par):
    out=defaultdict(F);cache={}
    for(w,k),v in P.items():
        pref=0
        for at,(n,j)in enumerate(w):
            if rules.get(n):
                if(n,j)not in cache:
                    q=rules[n]
                    for mu in j:q=dx(q,mu,par)
                    cache[n,j]=q
                rest={(w[:at]+w[at+1:],k):v*(-1)**(par[n]*pref)}
                for key,value in mul(cache[n,j],rest,par).items():out[key]+=value
            pref+=par[n]
    return clean(out)
def main():
    tick=time.perf_counter();watch=threading.Timer(300,lambda:os._exit(124));watch.daemon=True;watch.start();prep=a.read(O/'preparation_validation.json')
    for n,h in prep['sha256'].items():assert digest(R/n)==h,n
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==prep['base_HEAD'];assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)
    for stage in ['a','b']:
        z=a.read(O/('capture_'+stage+'.json'));assert z==a.read(C/('capture_'+stage+'.json'))and z['calculation_completed']and z['exit_code']==0 and z['post_run_observations_qualified'];assert max(q['private_bytes']for q in z['all_resource_samples'])<=8*1024**3
        old=a.read(O/('preparation_'+stage+'.json'))
        for n,h in old['sha256'].items():
            if n in ['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md']:
                archived=C/('README_before_final.bytes'if n=='README.md'else'campaign_before_final.bytes');assert digest(archived)==h
                stored=subprocess.check_output(['git','show',prep['base_HEAD']+':'+n],cwd=R);assert archived.read_bytes().replace(b'\r\n',b'\n')==stored
            else:assert digest(R/n)==h,n
    real=[];background=[];dispositions=[];peers=[]
    for role,owner in [('native','primary'),('replay','replay')]:
        aa=a.load(O/(role+'_complete_real_joint_roots.json.gz'));bb=a.load(O/(role+'_complete_full_background_extension.json.gz'));par=bb['joined_parities'];signs=aa['all1391_signs'];assert not aa['failures']and not bb['failures'];assert all(signs[i]==signs[643+i]for i in range(643))
        for z in aa['complete_root_checks']:
            P=cells(z['complete_root']);assert rawstar(P,signs)==P and not z['complete_star_minus_root']and not z['all_nonzero_Eulers'];real.append([role,z['name'],len(P)])
        assert all(not r['complete_discrepancies']for r in aa['all_operation_checks']+aa['all_known_Q_E_checks'])
        tb={i:cells(q)for i,q in bb['all1391_Tb_columns']};assert all(rawstar(q,signs)=={k:v*signs[n]for k,v in q.items()}for n,q in tb.items())
        for name in ['complete_S_GF_source','complete_W','complete_CS']:
            P=cells(bb[name]);assert rawstar(P,signs)==P
        W=cells(bb['complete_W']);assert not action(W,tb,par)
        controls={}
        for row in bb['probes']:
            G=cells(row['complete_G']);U=cells(row['complete_U']);assert rawstar(G,signs)==G and rawstar(U,signs)==U;assert not action(G,tb,par);assert not row['complete_DU']
            # Literal inert-A control; this tests the full-background extension.
            frozen={n:q for n,q in tb.items()if not 1331<=n<1379};controls['frozen_A_'+row['probe']]=len(action(G,frozen,par))
        assert controls['frozen_A_H']>0
        rot=a.load(B/'canonical_so10_marked_geometric_primitive_transport_v1'/(role+'_complete_marked_geometric_transport.json.gz'));ext={}
        for n,rows in rot['all33_epsilon_rotation_rules']:
            P=cells(rows);out={}
            for(w,k),v in P.items():out[tuple((i+60 if 1319<=i<1331 else i,j)for i,j in w),k]=v
            ext[n]=out
        K=cells(next(r for r in aa['complete_root_checks']if r['name']=='K_raw')['complete_root']);inert=action(K,tb,par);rotated=action(K,ext,par);assert inert and not add((inert,1),(rotated,1))
        augmented=save(role+'_complete_augmented_background_epsilon_rules.json.gz',dict(all33_additional_Tb_epsilon_columns=[[n,[[[[i,list(j)]for i,j in w],list(k),v.numerator,v.denominator]for(w,k),v in sorted(q.items())]]for n,q in sorted(ext.items())],complete_inert_TbK=[[[[i,list(j)]for i,j in w],list(k),v.numerator,v.denominator]for(w,k),v in sorted(inert.items())],complete_multiplet_TbK=[],physical_epsilon_is_fixed=True),64)
        # Bind the complete full-A parent to the actual E2 owner, BEFORE A0.
        ch=a.Chart(owner);e2=a.read(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e2_transport'/(owner+'.json'))
        assert ch.rows(e2['gauge_fixing_density'])==ch.rows(ch.data['gauge_fixing_density'])
        for f,j,h,k in ch.pairs:assert ch.rows(e2['complete_columns'][ch.raw.names[f]]['source_polynomial'])==ch.rows(ch.data['master_field_maps'][ch.raw.names[f]]),ch.raw.names[f]
        # Complete disposition of each saved MWA raw packet row. The old B
        # positions-minus-output proxy is explicitly NOT an exclusion census.
        z=a.load(B/'canonical_so10_mixed_probe_auxiliary_ward'/(owner+'_tables.json.gz'));index={n:i for i,n in enumerate(bb['joined_names'][:643])};index.update({ch.raw.names[j]:643+index[ch.raw.names[f]]for f,j,h,k in ch.pairs});index.update({'A'+str(i)+'_'+str(mu):1331+4*i+mu for i in range(12)for mu in range(4)})
        def dim(i):return 3-dim(i-643)if 643<=i<1286 else 2 if 508<=i<553 else 1
        journal=[]
        for name,D in [('physical_G',3),('physical_QG',4)]:
            for pr,packet in enumerate(z[name]):
                rows=[]
                for at,(g,w,ci)in enumerate(packet['monomials']):
                    degree=D-sum(dim(index[z['names'][i]])+len(j)for i,j in w);rows.append([at,g,degree,'HIGHER_G'if g>1 else'OUTSIDE_INTRINSIC01'if degree not in[0,1]else'RETAINED_BEFORE_LINEAR_A_FRAME'])
                counts={key:sum(r[3]==key for r in rows)for key in ['HIGHER_G','OUTSIDE_INTRINSIC01','RETAINED_BEFORE_LINEAR_A_FRAME']};assert sum(counts.values())==packet['positions'];journal.append(dict(packet=name,probe=['H','M'][pr],all_raw_row_dispositions=rows,counts=counts))
        dispositions.append(dict(role=role,artifact=save(role+'_complete_raw_packet_dispositions.json.gz',dict(journal=journal,erratum='compute_b excluded_G_positions is a positions-minus-output proxy; not raw exclusions. This complete row census supersedes that label.'),64)))
        background.append(dict(role=role,augmented_epsilon_artifact=augmented,controls=controls,all643_full_E2_field_maps_and_complete_GF_equal=True));peers.append(bb)
        print('STAGE '+role+' independent_Fraction_background_reality_full_E2_lineage_complete',flush=True)
    for key in ['all1391_Tb_columns','complete_S_GF_source','complete_W','complete_CS','probes']:assert peers[0][key]==peers[1][key],key
    # Finite coefficient grammar, not a finite nonlocal determinant.
    grammar=[]
    for budget in range(5):
        for mask in range(32):
            best={(0,0):0}
            for cost in range(budget+1):
                for used in range(32):
                    if used&~mask or(cost,used)not in best:continue
                    value=best[cost,used]
                    if cost<budget:best[cost+1,used]=max(best.get((cost+1,used),-1),value+1)
                    for bit in range(5):
                        if mask&(1<<bit)and not used&(1<<bit):best[cost,used|(1<<bit)]=max(best.get((cost,used|(1<<bit)),-1),value+1)
            maximum=max(best.values());assert maximum==budget+mask.bit_count();grammar.append([budget,mask,maximum])
    assert max(r[2]for r in grammar)==9
    # Sensitive canonical-source calibration of the Jacobi argument used to
    # reduce the parent. No old parity-weighted C is imported into this chart.
    toy=a.Algebra(['x','c','b','Jx','Jc','Jb'],[0,1,1,1,0,0]);tx,tc,tb,tjx,tjc,tjb=[a.atom(i)for i in range(6)];S=a.plus(toy.product(tjx,tc),toy.product(tjb,tx));W=toy.product(tx,tb);E=a.eulers(toy,S);CW=a.eulers(toy,W);good={3+i:q for i,q in CW.items()};bad={n:a.scale(q,-1)if n==5 else q for n,q in good.items()}
    def master(P):
        ee=a.eulers(toy,P);return a.plus(*(a.scale(toy.product(ee.get(3+i,{}),ee.get(i,{})),(-1)**toy.parities[i])for i in range(3)))
    B0=master(S);checks=[]
    for label,rules in [('correct',good),('wrong_odd_source_sign',bad)]:
        CS=a.act(toy,S,rules);ec=a.eulers(toy,CS);lhs=a.plus(*(a.scale(a.plus(toy.product(ec.get(3+i,{}),E.get(i,{})),toy.product(E.get(3+i,{}),ec.get(i,{}))),(-1)**toy.parities[i])for i in range(3)));rhs=a.act(toy,B0,rules);res=a.plus(lhs,a.scale(rhs,-1));assert bool(res)==(label!='correct');checks.append(dict(label=label,complete_lhs=a.encode(lhs),complete_rhs=a.encode(rhs),complete_difference=a.encode(res)))
    save('complete_canonical_source_master_calibration.json.gz',dict(complete_S=a.encode(S),complete_W=a.encode(W),checks=checks),64)
    # All16 squarefree strength monomials: explicit LEFT exterior extraction.
    left=[]
    def extract(w,n):
        if n not in w:return None,0
        at=w.index(n);return w[:at]+w[at+1:],(-1)**sum(j in[0,1]for j in w[:at])if n in[0,1]else 1
    for mask in range(16):
        w=tuple(n for n in range(4)if mask&(1<<n));r,s=extract(w,0);rr,ss=extract(r,1)if r is not None else(None,0);t,v=extract(w,1);tt,vv=extract(t,0)if t is not None else(None,0)
        assert s*ss==-v*vv;left.append([mask,s*ss,v*vv])
    save('complete_joint_grammar_and_LEFT_checks.json.gz',dict(all160_grammar_states=grammar,all16_LEFT_strength_checks=left,maximum_local_word_length=9,zero_cost_ungraded_selfcycle_rejected=True,nonlocal_Born_series_NOT_truncated=True),64)
    print('STAGE joint_LEFT_and_local_grammar_complete',flush=True)
    # No historical custody exit is relabeled PASS.
    command=[__import__('sys').executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e4=subprocess.run(command,cwd=R,text=True,encoding='utf-8',stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    ec=dict(command=command,exit_code=e4.returncode,stdout_and_stderr=e4.stdout);dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);events=[json.loads(q)for q in e4.stdout.splitlines()if q.startswith('{')];steps=[q['exit_code']for q in events if q.get('event')=='step_finished'];assert e4.returncode==0 and steps==[0,0,0,0,0,2]and next(q for q in events if q.get('event')=='step_finished'and q.get('step')=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    for n,h in prep['sha256'].items():assert digest(R/n)==h,n
    assert digest(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    historic=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);assert sha256(historic).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792';assert(R/'README.md').read_bytes().replace(b'\r\n',b'\n').endswith(historic)
    files={q.relative_to(R).as_posix():digest(q)for q in O.iterdir()if q.is_file()};files.update({n:digest(R/n)for n in ['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V865.md']})
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=64*1024**2
    dump(O/'validation_receipt.json',dict(execution_state='COMPLETED',evidence_validation='PASS_SELECTED_JOINT_REAL_BACKGROUND_AND_DERIVATIVE_APPLICABILITY',scientific_acceptance='NOT_PERFORMED',base_HEAD=prep['base_HEAD'],reality_checks=real,background_checks=background,raw_dispositions=dispositions,local_word_bound=9,E4_step_exits=steps,historical_custody='SEVEN_UNRESOLVED_NOTPASS',state_sha256=digest(R/'project_state.json'),files_excluding_pending_receipt_capture=files,conversion_reality_requires_DSP_complete_normalization_premises=True,complete_recovered_heat_QAP_E5_A5_physical_viability_NOT_established=True,elapsed_after_imports=time.perf_counter()-tick));watch.cancel()
if __name__=='__main__':main()
