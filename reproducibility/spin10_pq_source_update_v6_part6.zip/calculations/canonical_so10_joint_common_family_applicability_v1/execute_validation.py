from common import *
import ast,subprocess,sys
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='9a60ecbedf81d60568cad7b20578057f8ce7bfb6'
names=set(a.read(O/'preparation_b.json')['sha256'])
for n in ['DERIVATION.md','validation_receipt.json']:
    names.add('calculations/canonical_so10_dimensional_stokes_primitive/'+n)
for role in ['primary','replay']:
    names.add('tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e2_transport/'+role+'.json')
names.add('tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e2_transport/validation_receipt.json')
for n in ['validate.py','execute_validation.py','PROOF.md','RESULT.md','FINAL_RECORD.md']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()}|{'README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V865.md'}
for n in ['README_before_final.bytes','campaign_before_final.bytes']:assert(C/n).is_file()
dump(O/'preparation_validation.json',dict(base_HEAD=head,sha256={n:digest(R/n)for n in sorted(names)},limits=dict(seconds=300,sampled_private_bytes=8*1024**3,packet_bytes=64*1024**2,artifact_bytes=8*1024**2),scientific_acceptance='NOT_PERFORMED'));dump(C/'preparation_validation.json',a.read(O/'preparation_validation.json'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'validate.py')]);dump(O/'capture_validation.json',cap);dump(C/'capture_validation.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
assert digest(O/'validation_receipt.json');dump(C/'validation_receipt.json',a.read(O/'validation_receipt.json'))
