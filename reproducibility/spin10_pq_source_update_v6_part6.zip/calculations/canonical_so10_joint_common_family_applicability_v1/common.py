"""V865 typed polynomial interface. Imported predecessors are pure helpers."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import gzip,importlib.util,json
R=Path(__file__).resolve().parents[2]; B=R/'calculations'; O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/joint-common-family-applicability-v1-2026-11-08')
sp=importlib.util.spec_from_file_location('V865_BOUND_POLYNOMIAL_HELPERS',B/'canonical_so10_geometric_probe_Ward_insertion_v1/compute_v2.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p);a=p.a
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(n,z,limit=32):
    data=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(data)>8*1024**2:
        with(C/(n+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(data)
        raise AssertionError('COMPLETE_OVERFLOW_NOTPASS')
    with(O/n).open('xb')as f:f.write(data)
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=limit*1024**2
    return dict(file=n,bytes=len(data),sha256=digest(O/n))
def phase(n):
    if n<1286:return a.phase_power(n)
    if 1286<=n<1331 or 1379<=n<1391:return 0
    assert 1331<=n<1379
    return int((n-1331)%4==0)
def sigma(n):return (-1)**(phase(n)%2)
def native(P,control=None):
    out={}
    for(g,w),cs in P.items():
        power=sum(phase(n)%2+(0 if control=='omit_time_jets'else j.count(0))for n,j in w)
        if control=='wrong_sources':power+=sum(643<=n<1286 for n,j in w)
        if control=='reverse_odd_order':
            count=sum(553<=n<643 or 643<=n<1196 or 1286<=n<1319 for n,j in w);power+=count*(count-1)//2
        a.put(out,(g,w),tuple((k,v*(-1)**(power+bool(k[2]&16)))for k,v in cs))
    return out
def conjugate(P):return {k:tuple((b,-v if b[2]&16 else v)for b,v in cs)for k,cs in P.items()}
def replay(P):
    out={}
    for(g,w),cs in P.items():
        # Pull back the full Wick density, conjugate, push forward. The
        # constant density minus cancels; there is no odd-order reversal.
        power=2-sum(phase(n)+j.count(0)for n,j in w)
        raw=a.factor({(g,w):cs},a.ph(power));back=a.factor(conjugate(raw),a.ph(-power))
        for k,v in back.items():a.put(out,k,v)
    return out
def rename(A,P):
    out={}
    for(g,w),cs in P.items():
        assert all(n<1298 for n,j in w)
        ww,sg=A.canonical(tuple((n+33 if n>=1286 else n,j)for n,j in w));assert sg==1;a.put(out,(g,ww),cs)
    return out
def alphabet(ch):
    return a.Algebra(ch['all_current_names'][:1286]+['epsilon_'+str(i)for i in range(33)]+ch['all_current_names'][1286:]+['A_current_'+str(i)for i in range(48)]+['omega_background_'+str(i)for i in range(12)],ch['all_current_parities'][:1286]+[1]*33+[0]*72)
def selected(P,D):
    def dim(n):return 3-dim(n-643)if 643<=n<1286 else 2 if 508<=n<553 else 1 if n<1319 or 1331<=n<1379 else 0
    return{k:v for k,v in P.items()if k[0]<=1 and 0<=D-sum(dim(n)+len(j)for n,j in k[1])<=1}
