"""Verify the longitudinal lower-source contact at unequal heat lengths."""

from collections import defaultdict
import importlib.util
import sys

import mpmath as mp
import sympy as sp

from execute import ROOT, run_worker


def previous():
    path = ROOT / "calculations/canonical_so10_gauge_first_switch_rank_v1/first_switch_rank.py"
    spec = importlib.util.spec_from_file_location("switch_rank_owner",path)
    prior = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(prior)
    return prior


def input_tables(phase):
    prior = previous()
    literal = prior.load_literal()
    source = literal.load_owner()
    _, _, _, f, _, _ = source.owner.inputs(phase)
    J, _, da, db, dc, _, _, _ = literal.literal_tables(source,phase)
    sources = defaultdict(list)
    for (a,v,i),j in J.items():
        if v<12:
            sources[v,i].append((a,j))
    count = [0,0]
    raw = prior.table()
    for (i,v,c),z in da.items():
        if v>=12:
            continue
        assert (i<12) == (c<12)
        assert (i,v,c) not in db
        h = int(c<12)
        assert dc.get((i,v,c),0) == -(1-h)*z
        assert z == -dict(f[v,c])[i]
        for a,j in sources[v,i]:
            raw[a,c] -= j*z
        count[1-h] += 1
    KH = prior.table()
    for v in range(12):
        for c in range(45):
            for i,x in f[v,c]:
                for a,y in f[v,i]:
                    KH[a,c] -= x*y
    KH = source.owner.clean(KH)
    assert source.owner.clean(raw) == KH and KH[13,13] != 0
    return count,KH[13,13]


def inverse_rows(phase):
    role = "native" if phase == "native" else "replay"
    prior = previous()
    owner = prior.load_literal().load_owner()
    path = ROOT / "calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1"
    entries = owner.seagull.read(path / f"{role}_inverse.json.gz")["Greference"]
    data = {(a,b):z for a,b,z in entries}
    eta = sp.Symbol("eta_H")
    q = sp.symbols("q0:4")
    Q = sum(x*x for x in q)
    count = 0
    for v in range(12):
        for mu,k in enumerate(q):
            for nu,j in enumerate(q):
                item = sp.sympify(data[4*v+mu,4*v+nu])
                assert sp.cancel(sp.diff(item,eta)-k*j/Q**2) == 0
                count += 1
    return count


def radial():
    a,b,u,y,t,x = sp.symbols("a b u y t x",positive=True)
    denominator = u+y
    assert sp.cancel(-sp.diff(u/denominator**2,u)-(u-y)/denominator**3) == 0
    strip = sp.integrate(a/(a+y)**2,(y,b,a))
    centered = (a-b)/(a+b)
    assert sp.cancel(2*strip-centered) == 0
    gaussian = sp.integrate(sp.exp(-t*(a+b)*x),(x,0,sp.oo))
    assert sp.cancel(t*(a-b)*gaussian-centered) == 0
    assert centered.subs(b,a) == 0
    h = sp.Symbol("h")
    L = sp.log((a+b)/4)
    ratio = sp.expand((-sp.Rational(1,2)+(2-h)/4)*(-4*L)+centered)
    assert sp.simplify(ratio-(h*L+centered)) == 0
    same_length = {a:1,b:3,h:0}
    assert ratio.subs(same_length) == -sp.S.Half
    assert L.subs(same_length) == 0
    with mp.workdps(32):
        for aa,bb in ((3,1),(5,2)):
            def inner(v):
                def transformed(z):
                    # u=aa+z/(1-z); include the Jacobian.
                    d = 1-z
                    return ((aa-v)*d+z)/(((aa+v)*d+z)**3)
                return mp.quad(transformed,[0,1])
            direct = mp.quad(inner,[bb,aa])
            assert abs(2*direct-mp.mpf(aa-bb)/(aa+bb)) < mp.mpf("1e-28")


def check(phase):
    count,pivot = input_tables(phase)
    inv = inverse_rows(phase)
    radial()
    return {"light_internal_derivative_rows":count,
            "light_longitudinal_inverse_rows":inv,
            "broken_color_pivot":str(pivot),
            "relative_scaled_coefficient":"h*log((a+b)/4)+(a-b)/(a+b)",
            "fixed_total_length_negative_control":"-1/2",
            "schwinger_strip_matches_hard_transfer":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
