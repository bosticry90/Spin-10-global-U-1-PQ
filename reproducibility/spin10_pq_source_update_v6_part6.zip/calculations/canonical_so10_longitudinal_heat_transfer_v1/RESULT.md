# V974 · Longitudinal heat-transfer contact

The light longitudinal lower-source bubble has a
finite relative coefficient proportional to

    h_c log((a+b)/4) + (a-b)/(a+b)

in units `eta_H p K_H/(64π²)`. For a broken
exterior ghost the logarithmic pieces cancel.
Only the first heat transfer term remains.

The hard angular calculation and a Schwinger-strip
calculation agree. Both action exports verify the
light longitudinal inverse and literal color rows.
The control `a=1,b=3` holds total length fixed and
gives `−1/2` in the stripped coefficient. The actual
broken-color diagonal of `K_H` at e13 is `8/5`.

A conversion back to the common clock must carry
this contact. No width or clock was adopted.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
