# Unequal-clock contact for the light longitudinal lower source

In the g² lower J_B C bubble keep internal B light
and extract its coefficient linear in eta_H.
Use the literal vertex with incoming momenta
k on B, p on the exterior C and -k-p on the
antighost. Keep p²>0 through the cutoff limits.
The V945 derivative rows give d_B=0, d_a=-f,
d_C=(1-h_c)f for exterior color c. Thus the
ordinary derivative factor after stripping i f
is k+(2-h_c)p. Contract with the light longitudinal
Green P_L(k)/k², P_L=kk^T/k². In common loop
and source units the coefficient uses

    [k+(2-h_c) P_L(k)p] /
                 [k²(k+p)²].

The returning color is the light adjoint sum K_H.
Indeed the J_B coefficient and derivative residue
multiply as (-f_(a v i)) f_(i v c), with v light.
Its ghost i is in the exterior sector c. Both action
exports verify all derivative relations and this
color map. The width coefficient is retained
symbolically.

Let a>0 be the heat length on B and b>0 the
length on the ghost. The reference is a=b=2.
Split k into (k+p/2)-p/2. The -p/2 term
changes by the ordinary scalar log. The
P_L(k)p term changes by p/4 times that log.
Their scalar weight difference is
-log((a+b)/4)/(16 pi²), by hard rescaling.

For the centered integral set q=k+p/2.
The denominator is even in q. The first heat
transfer factor is -t(b-a)q dot p against the
Gaussian exp[-t(a+b)q²]. With the measure
d⁴q/(2 pi)^4 its hard angular moment gives

    I_center = p (a-b)/(64 pi² (a+b)).

The O(t) scalar shift and remaining odd heat
terms have zero finite relative limit. On a
bounded domain the unheated integrand has the
same limit at fixed nonexceptional transfer,
so this term is localized at the hard scale.
The two small-momentum poles are locally
integrable. At fixed IR cutoff the difference
of heat lengths vanishes on bounded domains,
and IR profiles approach one uniformly on the
rescaled hard shell away from zero. This
justifies the UV-then-IR relative comparison.

An independent derivation with heat profiles
uses Schwinger lengths A>=ta and B>=tb.
After integrating the shifted Gaussian, the
centered first moment is proportional to
(A-B)/(A+B)^3 times exp[-p² AB/(A+B)].
For a>b the common square A,B>=ta cancels by
antisymmetry. Rescale the strip B in [tb,ta]
by t. Its limiting integral is
a/(a+b)-1/2. Multiplying by p/(32 pi²)
reproduces the centered term. Exchanging a,b
changes its sign. This strip is integrable,
so the limit is dominated.

Combining both pieces, the finite difference
from the common clock, after stripping width,
p and the returning color, is

    [h_c log((a+b)/4)+(a-b)/(a+b)]/(64 pi²).

For c light, a=b is the light length and only
the logarithm remains. For c broken, the two
logarithmic contributions cancel and only the
first heat transfer term remains. Taking
a=1,b=3 leaves the total length unchanged and
gives a nonzero rational coefficient. An actual
broken-color K_H row makes this a sensitive test
of a log-only conversion. A profile conversion
to the old common clock has to subtract this
relative contact in this channel. Neither clock
nor width is selected physically by this test.
The other longitudinal, ordinary and marked
products require separate comparisons.
Both routes share the action and software.
