from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/leading-minimal-shadow-g1-v1-2026-11-08');digest=lambda q:sha256(q.read_bytes()).hexdigest()
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='72ecc64dfb536782af58f6838038801f48d66698';assert not(O/'preparation.json').exists();names=set(json.loads((R/'calculations/canonical_so10_fixed_log_candidate_background_g1_v1/preparation_validation.json').read_bytes())['sha256'])
names|={'AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V841.md','calculations/canonical_so10_fixed_log_candidate_background_g1_v1/validation_receipt.json','calculations/canonical_so10_marked_source_projection_g1_v1/native_source_interfaces.json.gz','calculations/canonical_so10_marked_source_projection_g1_v1/replay_source_interfaces.json.gz','calculations/canonical_so10_marked_source_projection_g1_v1/validation_receipt.json','calculations/canonical_so10_JaC_companion_g1_recovery_v1/proper_reference.json.gz','calculations/canonical_so10_JaC_companion_g1_recovery_v1/PROOF.md','calculations/canonical_so10_JaC_companion_g1_recovery_v1/validation_receipt.json','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_NONMINIMAL_RETRACT_DERIVATION_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_NONMINIMAL_RETRACT_RESULT.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_nonminimal_retract/validation_receipt.json'}
for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
C.mkdir(exist_ok=False)
for n in['RECORD.md','compute.py','execute.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
with(C/'README_before.md').open('xb')as f:f.write((R/'README.md').read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()};prep=dict(base_HEAD=head,sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation.json',prep);dump(C/'preparation.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute.py')]);dump(O/'capture.json',cap);dump(C/'capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
