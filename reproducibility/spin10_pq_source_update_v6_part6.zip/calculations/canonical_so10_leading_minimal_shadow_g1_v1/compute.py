from pathlib import Path
from fractions import Fraction as Fr
from hashlib import sha256
from functools import lru_cache
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/leading-minimal-shadow-g1-v1-2026-11-08')
def module(name,q):
 sp=importlib.util.spec_from_file_location(name,q);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
b=module('LMS_existing_action',B/'canonical_so10_correlated_ghost_source_log_g1_v1/action.py');p=b.p;J=b.J;A=b.A;one=b.one;zero=b.zero;load=b.load;read=b.read;digest=b.digest;plus=b.plus;scale=b.scale
raw=module('LMS_fraction_helpers',B/'canonical_so10_cartan_generator_residual_g1_v1/final_review_v4.py')
FIELDS=list(range(180))+list(range(508,643));PORTS=FIELDS+[643+n for n in FIELDS];MIN=list(range(180))+list(range(553,598))+list(range(3000,3225));COPY={643+n:3000+n for n in range(180)}|{1196+c:3180+c for c in range(45)};BACK={v:k for k,v in COPY.items()}
oldpar=J.parity;olddim=J.dimension
J.parity=lambda n:oldpar(BACK[n])if n in BACK else oldpar(n)
J.dimension=lambda n:olddim(BACK[n])if n in BACK else olddim(n)
raw.par=J.parity
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 if len(blob)>8*1024**2:
  with(C/(name+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
  raise AssertionError('COMPLETE_OVERFLOW_PRESERVED_NOTPASS')
 with(O/name).open('xb')as f:f.write(blob)
 assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def clean(P):return{k:v for k,v in P.items()if v}
def sub(x,y):return clean({k:x.get(k,Fr(0))-y.get(k,Fr(0))for k in set(x)|set(y)})
def rd(P,mu):
 out={}
 for(w,k),v in P.items():
  for at,(n,js)in enumerate(w):raw.put(out,w[:at]+((n,tuple(sorted(js+(mu,)))),)+w[at+1:],k,v)
 return clean(out)
def rds(P,js):
 for mu in js:P=rd(P,mu)
 return P
def rm(X,Y):
 out={}
 for(w,k),v in X.items():
  for(ww,kk),c in Y.items():
   f=-1 if k[3]&kk[3]&16 else 1
   for bit,prime in enumerate([2,3,5,7]):
    if k[3]&kk[3]&(1<<bit):f*=prime
   raw.put(out,w+ww,(k[0]+kk[0],k[1]+kk[1],k[2]+kk[2],k[3]^kk[3]),v*c*f)
 return clean(out)
def radd(out,P,sg=1):
 for k,v in P.items():out[k]=out.get(k,Fr(0))+sg*v
def unflat(P):
 out={}
 for(w,k),v in P.items():out.setdefault(w,[]).append((k,v))
 return{w:J.Coeff(cs)for w,cs in out.items()}
def ports(P):return{n for w in P for n,js in w}
def substitute(P,M,role):
 assert ports(P)<=set(M),('UNPROVIDED_SUBSTITUTION_PORT',sorted(ports(P)-set(M)))
 if role=='native':
  @lru_cache(None)
  def jet(n,js):return J.Ds(M[n],js)
  out={}
  for w,c in P.items():
   term={():c}
   for n,js in w:term=J.mul(term,jet(n,js))
   J.add(out,term)
  return J.clean(out)
 maps={n:raw.flat(J.encode(q))for n,q in M.items()}
 @lru_cache(None)
 def jet(n,js):return rds(maps[n],js)
 out={}
 for(w,k),v in raw.flat(J.encode(P)).items():
  term={((),k):v}
  for n,js in w:term=rm(term,jet(n,js))
  radd(out,term)
 return unflat(clean(out))
def operate(P,Q,role):
 assert ports(P)<=set(Q),('UNPROVIDED_OPERATION_PORT',sorted(ports(P)-set(Q)))
 if role=='native':return p.s.v.act(P,Q,odd=True)
 out={};partials={};qr={n:raw.flat(J.encode(q))for n,q in Q.items()}
 for(w,k),v in raw.flat(J.encode(P)).items():
  for at,t in enumerate(w):
   sg=(-1)**(J.parity(t[0])*sum(J.parity(n)for n,js in w[:at]));part=partials.setdefault(t,{});raw.put(part,w[:at]+w[at+1:],k,sg*v)
 for(n,js),part in partials.items():radd(out,rm(rds(qr[n],js),clean(part)))
 return unflat(clean(out))
def div(Ps):
 out={}
 for mu,P in enumerate(Ps):J.add(out,J.D(P,mu))
 return J.clean(out)
def maps(role):
 packet=load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));allQ,physical=b.make_Q0(packet);Q={n:allQ[n]for n in PORTS};assert len(Q)==630 and all(ports(q)<=set(PORTS)for q in Q.values()),'Q0_GAUGE_SUBALGEBRA_NOT_CLOSED'
 grads={n:J.decode(v)for n,v in load(B/'canonical_so10_correlated_ghost_source_log_g1_v1'/(role+'_g0_gaugefermion.json.gz'))['all643_Psi_field_Eulers']};hats={643+n:plus(p.atom(643+n),scale(grads.get(n,{}),-1))for n in FIELDS}
 old=load(B/'canonical_so10_correlated_ghost_source_log_g1_v1/full_transported_source_checks.json.gz');assert all(hats[n]==J.decode(v)for n,v in old['all_transported_source_polynomials'])
 old=load(B/'canonical_so10_marked_source_projection_g1_v1'/(role+'_source_interfaces.json.gz'));assert all(hats[n]==J.decode(v)for n,v in old['all90_hatted_sources'])
 pi={n:(p.atom(n)if n<180 or 553<=n<598 else p.atom(COPY[n])if n in COPY else plus(*(p.atom(4*(n-1241)+mu,(mu,))for mu in range(4)))if 1241<=n<1286 else{})for n in PORTS}
 inc={n:(hats[BACK[n]]if n in BACK else p.atom(n))for n in MIN};qm={n:(p.atom(553+n//4,(n%4,))if n<180 else physical[n-3000]if 3000<=n<3180 else scale(plus(*(p.atom(3000+4*(n-3180)+mu,(mu,))for mu in range(4))),-1)if n>=3180 else{})for n in MIN}
 assert all(ports(v)<=set(MIN)for v in qm.values())and all(ports(v)<=set(PORTS)for v in inc.values())
 return Q,pi,inc,qm,physical,hats
def check_maps(role):
 Q,pi,inc,qm,E,hats=maps(role);checks=[];diff=[]
 for n in PORTS:
  d=plus(substitute(Q[n],pi,role),scale(operate(pi[n],qm,role),-1));checks.append(['piQ0',n,not d])
  if d:diff.append(['piQ0',n,J.encode(d)])
  ip=substitute(pi[n],inc,role);dd=plus(substitute(substitute(ip,pi,role),inc,role),scale(ip,-1));checks.append(['idempotent',n,not dd])
  if dd:diff.append(['idempotent',n,J.encode(dd)])
 for n in MIN:
  d=plus(substitute(inc[n],pi,role),scale(p.atom(n),-1));checks.append(['pij',n,not d])
  if d:diff.append(['pij',n,J.encode(d)])
  d=plus(operate(inc[n],Q,role),scale(substitute(qm[n],inc,role),-1));checks.append(['Q0j',n,not d])
  if d:diff.append(['Q0j',n,J.encode(d)])
 noether=[div([E[4*c+mu]for mu in range(4)])for c in range(45)];nil=[operate(qm[n],qm,role)for n in MIN]
 wrong={n:({}if 1241<=n<1286 else q)for n,q in pi.items()};wc=[]
 for n in PORTS:
  d=plus(substitute(Q[n],wrong,role),scale(operate(wrong[n],qm,role),-1))
  if d:wc.append([n,J.encode(d)])
 badqm={n:(scale(v,-1)if n>=3180 else v)for n,v in qm.items()};sc=[]
 for n in MIN:
  d=plus(operate(inc[n],Q,role),scale(substitute(badqm[n],inc,role),-1))
  if d:sc.append([n,J.encode(d)])
 out=dict(original630_Q0=[[n,J.encode(Q[n])]for n in PORTS],all630_pi=[[n,J.encode(pi[n])]for n in PORTS],all450_inclusion=[[n,J.encode(inc[n])]for n in MIN],all450_Qmin=[[n,J.encode(qm[n])]for n in MIN],all2160_generator_checks=checks,complete_differences=diff,all45_Maxwell_Noether=[J.encode(z)for z in noether],all450_Qmin_squares=[J.encode(z)for z in nil],wrong_naive_Ja_deletion_chain_differences=wc,wrong_JC_source_sign_differences=sc)
 save(role+'_maps.json.gz',out);assert not diff and not any(noether)and not any(nil),'LEADING_COCHAIN_GATE_FAILED';assert wc and sc
 return Q,pi,inc,qm,out
def shadows(role,pi,qm):
 old=load(B/'canonical_so10_correlated_ghost_source_log_g1_v1/transported_fixed_candidate.json.gz');parents=load(B/'canonical_so10_log_source_restoring_preimage_g1_v1/measured_log_parents.json.gz');P=J.decode(old['complete_Pnew']);Delta=plus(*(J.decode(parents[k])for k in['actual_vector','actual_JBCC','direct_actual_aCC']));cur=[J.decode(z)for z in old['four_full_known_residual_currents']];Pm=substitute(P,pi,role);Dm=substitute(Delta,pi,role);cm=[substitute(z,pi,role)for z in cur];im=operate(Pm,qm,role);delta=plus(Dm,im,scale(div(cm),-1));oldim=substitute(J.decode(old['complete_Q0_Pnew']),pi,role);chain=plus(im,scale(oldim,-1));save(role+'_log_shadow.json.gz',dict(full_projected_Pnew=J.encode(Pm),full_projected_known_Delta=J.encode(Dm),full_Qmin_Pnew=J.encode(im),four_projected_currents=[J.encode(z)for z in cm],complete_projected_identity_difference=J.encode(delta),complete_projected_Q_identity_difference=J.encode(chain)));assert not delta and not chain
 table=load(B/'canonical_so10_JaC_companion_g1_recovery_v1/proper_reference.json.gz');assert table['normalization']=='overall g10*u/(16*pi^2); original Euclidean A0; proper coefficient +T*B_F'and table['ordered_reference']=='+3*T*p2/8';seen=set();jac={};tensor={};nonzero=[]
 for at,row in enumerate(table['source_color_rows']):
  pr,c,s=row['probe'],row['C'],row['Ja'];assert(pr,c,s)not in seen;seen.add((pr,c,s));co=A.decode_coeff(row['proper_QGamma_p2']);assert all(k[0]==0 for k,v in co.terms),'JAC_ALREADY_HAS_G_POWER';tensor[pr,c,s]=co
  if co:nonzero.append(at)
  for mu in range(4):J.add(jac,p.scale(J.mul(p.atom(1241+s),p.atom(553+c,(mu,mu))),-p.g1(co)))
 assert len(seen)==4050 and seen=={(pr,c,s)for pr in range(2)for c in range(45)for s in range(45)}
 jac=J.clean(jac);jm=substitute(jac,pi,role);normal,curr=p.normal(jm,set(range(180)));ibp=plus(jm,scale(normal,-1),scale(div(curr),-1));assert not ibp
 symmetry=[[pr,c,s,A.encode_coeff(tensor[pr,c,s]-tensor[pr,s,c])]for pr in range(2)for c in range(45)for s in range(45)if tensor[pr,c,s]!=tensor[pr,s,c]];q=operate(normal,qm,role);qcur=[scale(operate(z,qm,role),-1)for z in curr];qn=plus(q,scale(div(qcur),-1));K={}
 for(pr,c,s),co in tensor.items():
  dbs=plus(*(p.atom(4*s+mu,(mu,))for mu in range(4)));dbc=plus(*(p.atom(4*c+mu,(mu,))for mu in range(4)));J.add(K,p.scale(J.mul(dbs,dbc),J.times(p.g1(co),J.constant(Fr(-1,2)))))
 K=J.clean(K);qK=operate(K,qm,role);kd=plus(qK,scale(jm,-1));qjm=operate(jm,qm,role)
 if not symmetry:assert not qn and not qjm and not kd,'SYMMETRIC_KNOWN_JAC_SHADOW_EXACTNESS_FAILED'
 save(role+'_JaC_shadow.json.gz',dict(normalization='overall u/(16*pi^2), g10 restored once; p=-i partial,p2=-Box; ordered local reference ONLY',all4050_color_tensor=[[pr,c,s,A.encode_coeff(tensor[pr,c,s])]for pr in range(2)for c in range(45)for s in range(45)],nonzero_input_indices=nonzero,complete_actual_JaC_local_reference=J.encode(jac),complete_projected_BC_reference=J.encode(jm),complete_B_undifferentiated_normal=J.encode(normal),four_explicit_IBP_currents=[J.encode(z)for z in curr],complete_IBP_difference=J.encode(ibp),tensor_antisymmetric_differences=symmetry,complete_Qmin_known_BC_shadow=J.encode(q),complete_Qmin_shadow_mod_divergence_difference=J.encode(qn),four_Qmin_shadow_currents=[J.encode(z)for z in qcur],complete_Qmin_raw_shadow=J.encode(qjm),complete_leading_algebraic_primitive=J.encode(K),complete_Qmin_primitive=J.encode(qK),complete_primitive_difference=J.encode(kd),primitive_NOT_adopted_or_full_admissibility_proved=True,unknown_BC_kernel_and_lower_WZ_companions_NOT_zero=True,not_a_quantum_source_substitution_theorem=True))
 profile=[]
 for label,word in [('LambdaC',[508,553]),('Lambda2C',[508,509,553]),('Lambda_aCC',[508,598,553,554]),('BaCC',[0,598,553,554]),('BC',[0,553])]:
  F={():one}
  for n in word:F=J.mul(F,p.atom(n))
  got=substitute(F,pi,role);profile.append([label,J.encode(got)]);assert bool(got)==(label=='BC')
 save(role+'_profile_dependency.json.gz',dict(representative_species_support_only=profile,all_jets_extend_by_derivative_homomorphism=True,not_full_gu_closure_or_global_loop_exclusion=True,gu_closure='Q0 Delta_gu+Q1 Delta_u0+Qu0 Delta_g1+Qu1 Delta_g0=0'))
 return dict(projected_Pnew_words=len(Pm),projected_known_log_Delta_words=len(Dm),actual_JaC_reference_nonzero_color_rows=len(nonzero),JaC_shadow_words=len(jm),JaC_B_normal_words=len(normal),JaC_tensor_symmetric=not symmetry,Qmin_JaC_shadow_normal_words=len(qn))
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 fixture=plus(J.mul(p.atom(643,(1,)),J.mul(p.atom(553),p.atom(598))),p.scale(J.mul(p.atom(1196),J.mul(p.atom(553),p.atom(554,(2,)))),J.I));foutputs=[];summ=[]
 for role in['native','replay']:
  Q,pi,inc,qm,z=check_maps(role);foutputs.append((substitute(fixture,pi,role),operate(fixture,Q,role)));summ.append(shadows(role,pi,qm));print('STAGE '+role+' complete leading projection and known shadows',flush=True)
 assert foutputs[0]==foutputs[1]and all(foutputs[0]),'NONZERO_GRADED_JET_FIXTURE_FAILED';save('graded_jet_fixture.json.gz',dict(input=J.encode(fixture),complete_projection=J.encode(foutputs[0][0]),complete_Q0_variation=J.encode(foutputs[0][1])))
 for suffix in['maps','log_shadow','JaC_shadow','profile_dependency']:assert(O/('native_'+suffix+'.json.gz')).read_bytes()==(O/('replay_'+suffix+'.json.gz')).read_bytes(),suffix
 assert summ[0]==summ[1];out=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='LEADING_CURRENT_COCHAIN_RETRACTION_AND_KNOWN_SHADOW_QUALIFIED_PENDING_FINAL_VALIDATION',all630_original_and450_minimal_ports_closed=True,all2160_generator_checks_match=True,all45_Noether_and450_Qmin_squares_zero=True,complete_native_Fraction_outputs_equal=True,**summ[0],no_full_gu_quantum_contact_or_common_restoration_claim=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
