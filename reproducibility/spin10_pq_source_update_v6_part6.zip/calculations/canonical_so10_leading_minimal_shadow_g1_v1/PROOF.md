# What the leading retraction licenses

All statements below are at original Euclidean A0 and leading Q0. The
actual630-generator gauge/nonminimal source subalgebra is checked closed.
The328 scalar pairs are outside this algebra and outside the conclusion;
their source Euler functions are not set to zero. All coefficients retain
the original real-parameter/radical/imaginary ring without inverses of xi,
eta or g. The copied225 minimal-source labels are a distinct chart.

Write hatJ_i=J_i-Psi_i, using the actual current gaugefermion Eulers.
The qualified source identities and the new complete checks give

    Q0 B=partial C, Q0 C=0, Q0 a=i Lambda, Q0 Lambda=0,
    Q0 hatJB=E_Maxwell(B), Q0 hatJC=-div hatJB,
    Q0 hatJLambda=-i hatJa, Q0 hatJa=0.

The inclusion j retains B,C and sends copied minimal sources to hatJB/hatJC.
The projection pi kills a,Lambda,hatJLambda,hatJa and retains the minimal
generators. Expressed in ORIGINAL coordinates it sends Ja to divB,
JLambda to0 and JB/JC to their distinct minimal-source labels. This is not
source deletion. The actual gaugefermion shifts, rather than an assumed
source-free simplification, establish these original-coordinate formulas.

All630 piQ0=Qmin pi checks,450 Q0j=jQmin checks,450 pi j=id checks and
630 (j pi)^2=j pi checks pass. Actual Maxwell Noether divergences vanish,
and all450 Qmin generator squares vanish. The maps are homomorphisms of
the graded polynomial algebra and prolong by ordinary derivatives. Q0 and
Qmin are odd derivations with the same prolongation. Generator identities
therefore extend to every finite polynomial of arbitrary ordinary jets.
This is a cochain retraction. The existing quartet theorem is a comparator;
no new quasi-isomorphism, full interacting retract or local-basic theorem
is inferred from these map checks alone.

The projected fixed logarithmic correction contains563 words. Its2252-word
known quantum breaking cancels its Qmin image modulo the projected four
currents. This transports an already qualified identity; it is not another
measurement of a loop or a complete counterterm basis.

V806 supplies c_cs=3T_cs/8, with suppressed common g*u/(16pi2).
All4050 H/M positions are inspected;57 M entries are nonzero and the full
table is symmetric. Restoring only g once, p=-i partial gives

    F_JaC=-g sum c_cs Ja_s Box C_c,
    pi F_JaC=-g sum c_cs (divB_s) Box C_c.

The known ordered-reference shadow is nonzero. Both routes retain the912
projected words,912 B-undifferentiated words and four exact IBP currents.
Symmetry of c and odd C imply Qmin(pi F_JaC)=0 as a density. Also

    K=-g/2 sum c_cs (divB_s)(divB_c),
    Qmin K=pi F_JaC.

The full522-word K and its912-word image are saved. The half arises from
the symmetric quadratic primitive, not an extra half in the JaC loop.
K is an algebraic A0 leading primitive. It is not adopted, subtracted from
Gamma, or proved to possess all interacting/marked/background companions.
The source-to-field substitution is applied to an already local ordered
reference representative, not to an unspecified finite quantum functional.

Of the five unmeasured profile families, LambdaC,Lambda2C,Lambda aCC,BaCC
are annihilated in this diagnostic, while BC remains. No amplitude in any
of those families has been newly calculated. Their disappearance here
does not establish global irrelevance, nor allow a nonlocal quantum
cochain to be replaced by a local polynomial without an applicability proof.

In particular the gu consistency equation contains lower companions:

    Q0 Delta_gu+Q1 Delta_u0+Qu0 Delta_g1+Qu1 Delta_g0=0.

Without their qualified restoration, Delta_gu need not be Q0 closed.
The known JaC shadow being exact neither fixes nor predicts the missing BC
kernel. That kernel and the lower companions remain symbolic. V839's
broader marked/contact underdefinition also remains; this leading map
does not construct a compatible quantum insertion-renormalization map.
