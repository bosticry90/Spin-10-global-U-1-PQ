# Leading current-source cochain retraction and known quantum shadow

V842 proposal, frozen before execution at V841/72ecc64dfb536782af58f6838038801f48d66698,
main,D:,goal active under live AGENTS/charter/solo/epistemic rules. Root owns
writes, one serial worker and Git; existing two AI reviews are read only.
State113/34of39 unchanged; flavor paused,HB1/C5 blocked,E5/A5 open, seven
custody NOTPASS. No adoption, protected promotion, new branch or external action.

Question: does the actual leading Q0 gauge/nonminimal source algebra admit
the proposed minimal cochain projection, and what known/unknown selected
quantum profiles survive it? This is a dependency test before new loops.
Use qualified V833225 and V83590 source interfaces, actual P_E0 and Q0,
and V806's corrected proper JaC ordered reference. Reuse the existing
finite-polynomial quartet theorem as a comparator, not a full interacting
Q-conjugacy or QAP assumption. No new literature claim is needed here.

Original closed domain: B180,Lambda45,C45,a45 and their315 sources,630
generators, all ordinary finite jets. Explicitly verify closure; any scalar
or other unprovided source operand fails, never projects to zero. Minimal
codomain: B180,C45 and225 distinct copied source coordinates: JBmin IDs
3000..3179, JCmin3180..3224. These label a separate polynomial chart, not
new physical/action variables or BV partners. Inherit each source's parity,
dimension and coefficient ring. Original0..1285 types stay unchanged.

Projection pi: B,C fixed; a,Lambda zero; original JB/JC map to copied
minimal sources; Ja maps to divB; JLambda zero. Inclusion j: minimal JB/JC
map to current hatted J=J-Psi_i, B/C fixed. Thus j*pi(JB)=hatJB, NOT plain
originalJB. Require pi*j=id on450, idempotence j*pi on630, pi Q0=Qmin pi
on630 and Q0 j=j Qmin on450. Qmin JBmin=actual Maxwell E0_B and Qmin
JCmin=-divJBmin; test actual divergence and Qmin E0_B as well. All
identities extend by algebra homomorphism, derivation and jet prolongation.
This proves a cochain retraction, not by itself a quasi-isomorphism or
deformation retract. No Q1,Qu0,Qu1, scalar, local-background/basic or full
quantum-functional intertwining is claimed.

Compare native ordered substitution/prefix operation with independent plain
Fraction/radical polynomial products and LEFT partial operation. Keep both
complete maps/checks and differences before assertions. Nonzero graded/jet
fixture, wrong Ja projection and wrong minimal source signs must be tested
and their actual sensitivity reported, not assumed.

Apply the maps to full fixed V833 Pnew, its known logarithmic Delta and all
four divergence currents; compare the projected existing identity. This
is a consequence of an existing identity, not independent loop evidence.
Reconstruct V806's all4050 H/M proper JaC p2 rows; coefficient g power is
suppressed there and must be checked then appended exactly once. With the
qualified momentum convention p=-i partial, p2=-Box. Project this known
local ordered-reference representative, retain explicit IBP currents and
the complete BC tensor; no finite-regulator or nonlocal quantum-source
substitution theorem is inferred. Check tensor symmetry, not presume it.
If symmetric, test the exact leading identity Qmin[-1/2 sum cc_cs
(divB_s)(divB_c)]=the projected JaC reference. This is an algebraic
primitive in the A0 leading complex, not an adopted admissible correction;
no background, marked, lower-order or full interacting completion follows.

Known selected profile diagnostic: LambdaC,Lambda2C,Lambda aCC,BaCC
vanish under this projection, whereas BC survives and JaC feeds BC.
This is only algebraic support of this diagnostic. Unknown BC kernels,
lower Wess-Zumino companions and all missing insertion/contact definitions
remain symbolic and can be nonlocal. In particular the gu equation is
Q0 Delta_gu+Q1 Delta_u0+Qu0 Delta_g1+Qu1 Delta_g0=0, not automatically
Q0 Delta_gu=0. No loop is globally declared dispensable by this projection.

One worker180s after imports, sampled8GiB/launch350MiB floor; packet32MiB,
single artifact8MiB, complete overflow preserved externally then NOTPASS.
Freeze actual committed inputs, current policy, sources, owner receipts,
old Git tree and README bytes before computation; full repo/external capture.
On failure preserve all output, no silent retries or weakened requirements.
Possible outcomes: exact leading retraction and known-shadow qualification,
explicit interface mismatch, or incomplete bounded work. Final validation
must authenticate all inputs/captures, recompute decisive checks, verify
unchanged state/history and run delegated E4 with its fixed historical
context, retaining exit2/seven NOTPASS. Local commit only after validation.
Shared action, conventions, algebra/software and AI authorship limit
independence; neither mathematical agreement nor counts validate physics.
