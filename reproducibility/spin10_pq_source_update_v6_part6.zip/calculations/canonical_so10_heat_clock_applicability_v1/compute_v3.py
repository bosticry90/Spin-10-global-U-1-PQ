from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import gzip,json,math,os,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/heat-clock-applicability-v1-2026-11-08')
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def main():
    tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
    prep=json.loads((O/'preparation_v3.json').read_bytes())
    for n,h in prep['sha256'].items():assert sha256((R/n).read_bytes()).hexdigest()==h,n
    z=json.loads(gzip.decompress((O/'complete_profile_and_clock_evidence_v2.json.gz').read_bytes()))
    a,v=s.symbols('a v',positive=True)
    primitive=v*s.expint(1,a*v)-s.exp(-a*v)/a
    assert s.simplify(s.diff(primitive,v)-s.expint(1,a*v))==0
    actual=2*(primitive.subs(v,1)-primitive.subs(v,s.Rational(1,2)))
    J=lambda x:2*s.expint(1,2*x)-s.expint(1,x)+(s.exp(-x)-s.exp(-2*x))/x
    assert s.simplify(actual-J(a/2))==0 and s.simplify(actual.subs(a,2*a)-J(a))==0
    new=s.expand(s.series(actual,a,0,1).removeO()+s.log(a));old=s.expand(s.series(actual.subs(a,2*a),a,0,1).removeO()+s.log(a))
    assert s.simplify(new-(1-s.EulerGamma-s.log(2)))==0 and s.simplify(old-(1-s.EulerGamma-2*s.log(2)))==0
    peer=[]
    for clock in[F(1,2),F(1)]:
        out=[]
        for k in range(7):
            value=F((-clock)**(k+1)-(-2*clock)**(k+1),clock*math.factorial(k+1))
            if k:value+=F((-1)**(k+1)*(2**(k+1)-1)*clock**k,k*math.factorial(k))
            out.append([value.numerator,value.denominator])
        peer.append(dict(rational_coefficients=out,gamma=-1,log_a=-1,log2=-1 if clock==F(1,2)else-2))
    for expression,data in[(actual,peer[0]),(actual.subs(a,2*a),peer[1])]:
        expansion=s.expand(s.series(expression,a,0,6).removeO()+s.EulerGamma+s.log(a)-data['log2']*s.log(2))
        assert expansion==sum(s.Rational(*data['rational_coefficients'][k])*a**k for k in range(6))
    z['Fraction_bubble_new'],z['Fraction_bubble_old']=peer;z['native_bubble_new']=str(new);z['native_bubble_old']=str(old)
    z['actual_single_edge_heat_Schwinger_domain']='alpha,beta>=lambda; s>=lambda/min(v,1-v)'
    z['actual_single_edge_heat_normalized_integral']='2*integral_1/2^1 E1(lambda*p_squared*v)dv = J(lambda*p_squared/2)'
    z['controls']['wrong_absolute_bubble_clock_sensitive']=bool(s.simplify(new-(1-s.EulerGamma-2*s.log(2))))
    z['V2_INTERNAL_PASS_SCOPE_CORRECTION']='ABSOLUTE_BUBBLE_CLOCK_INTERPRETATION_WITHHELD; RELATIVE_SHIFT_AND_MATRIX_INTERFACE_RETAINED'
    assert len(z['controls'])==7 and all(z['controls'].values())
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<8*1024**2
    with(O/'complete_profile_and_clock_evidence_v3.json.gz').open('xb')as f:f.write(blob)
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='ACTUAL_SCHWINGER_DOMAIN_FIXES_ABSOLUTE_CLOCK_AND_PRESERVES_RELATIVE_CONVERSION',actual_normalized_bubble='I_new=J(t_new*p_squared/2); I_old=J(t_old*p_squared)',new_minus_old='log(2)/(16*pi**2)',controls=z['controls'],packet_sha256=sha256(blob).hexdigest(),elapsed_after_imports=time.perf_counter()-tick);dump(O/'result_v3.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
