# Complete historical navigation authentication

V4 final worker completed its matrix/bubble checks but FAILED authenticating
the historical V3 preparation against the live campaign guide. V3 producer
froze THREE navigation files before semantic correction; all three exact byte
copies were already preserved by build_semantic_v3.py. The verifier used only
the README copy. Preserve V4 source/preparation/capture NOTPASS.

V5 explicitly maps README,campaign guide and handoff to their corresponding
immutable pre-semantic V3 byte copies when authenticating preparation_v3.json.
All other paths remain current exact hash checks. No alternate path fallback,
rebinding,normalization or skipped digest is permitted. Each copy must equal
the original expected SHA. Current navigation has its separate NEW frozen
preparation and E4 check. Preserve the handoff before this V5 pointer update.

Same180s/8GiB bounds and all scientific obligations,including matrices,seven
controls,Schwinger formula and corrected absolute clocks. No new producer or
amplitude needed. Resource use and repeated bookkeeping failures will remain
in evidence; they are workflow cost,not new scientific progress or a model
obstruction. The competent correction is complete historical-byte mapping,
not accepting changed navigation under old hashes.
