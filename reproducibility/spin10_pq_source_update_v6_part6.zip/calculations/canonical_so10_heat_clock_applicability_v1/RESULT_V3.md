# V847 — corrected actual heat-clock interface

Prospective report; qualification requires the completed final receipt.
V846/8ef9051e is the parent. No scientific-state or physical-scheme adoption.

The selected A0 broken-sector covariance matches the older two-sided heat/IR
edge exactly at t_new=2t_old,delta=epsilon. All231 participating coordinates,
858 Green entries,891 inverse entries and implied zero matrix positions are
retained. This proves a necessary prescription interface for identical
vertices/reference. It does not compare every augmented vertex or firstDjet.

Equal positive kernels after rescaling do NOT have equal finite baselines
in the two original clocks. With F_old=L logt+C+powers+o(1), the conversion is
C_new=C_old-L log2. The inherited normalized two-edge bubble confirms a
new-minus-old shift log2/(16pi²), independently by symbolic and Fraction series.
Heat-power-prefactor finite terms and the complete IR inverse defect remain.
No new model amplitude was integrated or color coefficient fitted.

The old fixed metric-lift construction already exists in
canonical_so10_dimensional_counterterm_applicability. The next question is its
applicability to the SAME current augmented KD/probe parent, not choosing an
arbitrary continuation. Transport the original typed contractions and check
whole components; do not infer a dimensionjet from4D equality or choose an
evanescent addition to cancel a remainder. Old QPC/FNPL use different original
generators. Full conversion/contact compatibility and geometric W5 remain open.

First worker failed in the independent handwritten clock series: it rescaled
exponentials but missed the denominator clock. That disagreement was preserved
with source/copy/preparation/fullcapture. V2 corrects only that denominator
and uses distinct outputs under unchanged120s/8GiB bounds. It completed in
7.051s; final validation must independently reproduce its result, controls and
the failed denominator's sensitivity. Failure is not relabeled successful.

This closes an avoidable normalization ambiguity before broader reuse of the
old trace construction. Scope is the actual selected M profile only: other
sector profiles,background heat,all physical vertices,firstDjets,renormalized
products,QAP/equivalence and E5/A5 are not established. V791 and old IR/domain
results are authenticated/reused, not rerun. Shared action/software/AI and
absent experimental/independent human verification limit the inference.
Authority34/39,physicalwarnings and seven custodyNOTPASS remain unchanged.

Subsequent semantic review found that V2 labelled the old J(a) bubble with
the new clock. Its internal final PASS did not detect that shared premise.
V3 derives alpha,beta>=lambda directly: actual I_new=J(t_new*p²/2),
I_old=J(t_old*p²). The new absolute constant is1-gamma_E-log2-logp²; the
relative+log2/(16pi²) shift stands. V3 uses a new producer and separate
validation, preserving V2 and its internal receipt without scientific
promotion. A prior final preparer also failed before worker launch on the
actual suffixed MPA receipt; its tool-transcribed traceback and correction
are preserved. See [corrected proof](PROOF_V3.md) and
[semantic correction](SEMANTIC_CORRECTION_V3.md).
