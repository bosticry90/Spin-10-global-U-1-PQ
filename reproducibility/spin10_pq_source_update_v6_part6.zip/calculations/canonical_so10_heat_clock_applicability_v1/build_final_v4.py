from pathlib import Path
import ast
O=Path(__file__).resolve().parent;R=O.parents[1]
with(O/'handoff_before_final_V4.bytes').open('xb')as f:f.write((R/'docs/RESEARCH_EXECUTION_HANDOFF_V847.md').read_bytes())
s=(O/'validate_v3.py').read_text(encoding='utf-8');rows=s.splitlines(True);matched=0
for i,line in enumerate(rows):
    if "old=(O/'compute.py')"in line:
        assert line.count('complete_profile_and_clock_evidence_v3.json.gz')==1
        rows[i]=line.replace('complete_profile_and_clock_evidence_v3.json.gz','complete_profile_and_clock_evidence_v2.json.gz');matched+=1
assert matched==1
s=''.join(rows).replace("'preparation_validation_v3.json'","'preparation_validation_v4.json'").replace("'e4_capture_v3.json'","'e4_capture_v4.json'").replace("'validation_receipt_v3.json',receipt","'validation_receipt_v4.json',receipt")
ast.parse(s)
with(O/'validate_v4.py').open('x',encoding='utf-8',newline='\n')as f:f.write(s)
s=(O/'execute_v3.py').read_text(encoding='utf-8').replace("'preparation_validation_v3.json'","'preparation_validation_v4.json'").replace("'capture_validation_v3.json'","'capture_validation_v4.json'").replace("else'validate_v3.py'","else'validate_v4.py'")
ast.parse(s)
with(O/'execute_final_v4.py').open('x',encoding='utf-8',newline='\n')as f:f.write(s)
