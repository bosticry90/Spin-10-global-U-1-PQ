# V3: regulated-propagator derivation corrects the absolute bubble clock

V2 and its final validator passed their internal coefficient comparisons.
Read-only mathematical review then found a shared interpretation error:
the inherited J(a) belongs to a=t_old*p², with TWO heat factors per old edge.
It is not J(t_new*p²) for the current single-heat-edge covariance. No V847
commit or scientific qualification was made. Preserve all old sources,
preparations,output,capture,internal PASS receipt and navigation bytes.
Their matrix/relative-shift checks stand in scope; absolute-clock applicability
is WITHHELD by this correction. An internal PASS is not semantic validation.

Derive directly: for e^-lambda*q²/q² on each of two edges, Schwinger parameters
alpha,beta>=lambda give the normalized integral

  16pi² I_lambda=2 integral_(1/2)^1 E1(lambda*p²*v) dv
               =J(lambda*p²/2).

Thus I_new=J(t_new*p²/2), I_old=J(t_old*p²); equality at t_new=2*t_old and
new-minus-old finite shift+log2/(16pi²) remain correct. The NEW absolute
constant is1-gamma_E-log2-logp², while OLD is1-gamma_E-2log2-logp².
The original finite_heat_transgression owner is correct and unchanged.

Freeze a new60s producer and180s separate validator,8GiB sampled/350MiBfloor,
16MiBpacket/8MiBartifact. Derive the actual Schwinger domain, primitive/endpoints,
native expansion and independent rational E1 coefficients including half-clock.
Add a wrong-absolute-clock control. Recheck the complete M covariance/inverse
interface and original six controls in finalvalidation. Preserve both older
worker failure and preworker missing-receipt failure; no silent authoritychange.
V3 exactsources/newartifacts/receipts distinguish correction from old evidence.

Existing source/trace scopes,fullIRdefect,powerprefactors,reference and all
unproved augmentedlift/contact/QAP/E5 obligations remain. Navigation will link
the correctedV3 report, retaining the old reports as historical failed
interpretation evidence. No modelinput,acceptancerequirement or finitecoefficient
is fitted. State113/34of39 and protectedboundaries unchanged.
