# Correct final provenance replay without altering V3 mathematics

V3 final worker FAILED at its deterministic V2 source-transform check, before
scientific matrix/bubble stages or E4. Its builder had globally replaced the
new evidence filename inside the HISTORICAL V2 transform assertion too. That
assertion must compare V2 source to V2 output names, not V3 names. Preserve
validate_v3.py,preparation_validation_v3.json and capture_validation_v3.json
unchanged NOTPASS. V3 scientific producer/corrected Schwinger derivation is
unaffected and not yet finally qualified.

Generate validate_v4.py fixing ONLY that historical assertion's target filename,
with fresh final preparation/E4/receipt/capture names. Same180s/8GiB contract,
all matrices,seven controls,actual Schwinger-domain and old failure requirements
unchanged. No new scientific producer needed. V4 is the final evidence endpoint
for the V3 mathematical correction if it passes; no automatic PASS inferred.
