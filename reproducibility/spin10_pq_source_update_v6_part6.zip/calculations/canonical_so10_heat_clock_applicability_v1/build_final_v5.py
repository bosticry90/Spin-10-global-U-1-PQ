from pathlib import Path
import ast
O=Path(__file__).resolve().parent;R=O.parents[1]
with(O/'handoff_before_final_V5.bytes').open('xb')as f:f.write((R/'docs/RESEARCH_EXECUTION_HANDOFF_V847.md').read_bytes())
s=(O/'validate_v4.py').read_text(encoding='utf-8')
old="(digest(O/'README_before_semantic_V3.bytes')if n=='README.md'else digest(R/n))"
new="digest(O/({'README.md':'README_before_semantic_V3.bytes','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':'campaign_before_semantic_V3.bytes','docs/RESEARCH_EXECUTION_HANDOFF_V847.md':'handoff_before_semantic_V3.bytes'}[n]))if n in{'README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V847.md'}else digest(R/n)"
assert s.count(old)==1
s=s.replace(old,'('+new+')').replace("'preparation_validation_v4.json'","'preparation_validation_v5.json'").replace("'e4_capture_v4.json'","'e4_capture_v5.json'").replace("'validation_receipt_v4.json',receipt","'validation_receipt_v5.json',receipt")
ast.parse(s)
with(O/'validate_v5.py').open('x',encoding='utf-8',newline='\n')as f:f.write(s)
s=(O/'execute_final_v4.py').read_text(encoding='utf-8').replace("'preparation_validation_v4.json'","'preparation_validation_v5.json'").replace("'capture_validation_v4.json'","'capture_validation_v5.json'").replace("else'validate_v4.py'","else'validate_v5.py'")
ast.parse(s)
with(O/'execute_final_v5.py').open('x',encoding='utf-8',newline='\n')as f:f.write(s)
