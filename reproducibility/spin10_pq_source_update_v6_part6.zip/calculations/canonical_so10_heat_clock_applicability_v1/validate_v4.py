from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import gzip,json,math,os,re,subprocess,sys,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/heat-clock-applicability-v1-2026-11-08')
read=lambda q:json.loads(q.read_bytes())
load=lambda q:json.loads(gzip.decompress(q.read_bytes()))
digest=lambda q:sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='8ef9051e7a3398207be4ebfe0698343ae90f3648'
    for n,h in read(O/'preparation_validation_v4.json')['sha256'].items():assert digest(R/n)==h,n
    before=(C/'README_before.md').read_bytes();assert before==subprocess.check_output(['git','show',head+':README.md'],cwd=R)
    for pn in['preparation.json','preparation_v2.json']:
        prep=read(O/pn);assert prep==read(C/pn)
        for n,h in prep['sha256'].items():assert(sha256(before).hexdigest()if n=='README.md'else digest(R/n))==h,(pn,n)
    for q in O.glob('*.source.txt'):assert q.read_bytes()==q.with_name(q.name.removesuffix('.source.txt')).read_bytes()
    old=(O/'compute.py').read_text(encoding='utf-8');new=old.replace('Q((-clock)**(k+1)-(-2*clock)**(k+1),math.factorial(k+1))','Q((-clock)**(k+1)-(-2*clock)**(k+1),clock*math.factorial(k+1))').replace("'preparation.json'","'preparation_v2.json'").replace("'complete_profile_and_clock_evidence.json.gz'","'complete_profile_and_clock_evidence_v2.json.gz'").replace("'result.json'","'result_v2.json'");assert new==(O/'compute_v2.py').read_text(encoding='utf-8')
    samples=[]
    for cn,code in[('capture.json',1),('capture_v2.json',0)]:
        cap=read(O/cn);assert cap==read(C/cn)and cap['exit_code']==code and cap['calculation_completed']==(code==0)and cap['post_run_observations_qualified']and not cap['failed_or_incomplete_counted_as_PASS'];assert all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);samples.extend(x['private_bytes']for x in cap['all_resource_samples'])
    assert 'AssertionError'in read(O/'capture.json')['stdout_and_stderr']and read(O/'result_v2.json')['elapsed_after_imports']<120
    ev=load(O/'complete_profile_and_clock_evidence_v3.json.gz');assert digest(O/'complete_profile_and_clock_evidence_v3.json.gz')==read(O/'result_v3.json')['packet_sha256']
    src=B/'canonical_so10_regulator_free_inverse_g1_recovery_v1';up=read(src/'validation_receipt.json');assert up['execution_state']=='COMPLETED'and up['evidence_validation'].startswith('PASS_')
    assert digest(src/'native_inverse.json.gz')==up['paired_math_sha256']and(src/'native_inverse.json.gz').read_bytes()==(src/'replay_inverse.json.gz').read_bytes()
    oldprep=read(src/'preparation.json')
    for role in['primary','replay']:
        n='tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_full_hessian/'+role+'.json';assert digest(R/n)==oldprep['input_sha256'][n]
    z=load(src/'native_inverse.json.gz');assert z['other_sector_profiles_not_selected']and z['active_M_profiles']==dict(E='exp(-t*q_squared)',f='(1-exp(-q_squared/delta_squared))**2')
    q=s.symbols('q0:4');q2=sum(x*x for x in q);xi=s.Symbol('xi');ee=s.Symbol('E_profile',nonzero=True,real=True);ff=s.Symbol('f_profile',nonzero=True,real=True);locals0={'E_profile':ee,'f_profile':ff};G={};P={};ids=set()
    for color in range(12,45):
        ll,ghost,anti=508+color,553+color,598+color;ids|={4*color+mu for mu in range(4)}|{ll,ghost,anti}
        for mu in range(4):
            for nu in range(4):
                G[4*color+mu,4*color+nu]=int(mu==nu)/q2+(xi-1)*q[mu]*q[nu]/q2**2
                P[4*color+mu,4*color+nu]=q2*int(mu==nu)-q[mu]*q[nu]
            G[4*color+mu,ll]=-q[mu]/q2;G[ll,4*color+mu]=q[mu]/q2;P[4*color+mu,ll]=q[mu];P[ll,4*color+mu]=-q[mu]
        P[ll,ll]=xi;G[ghost,anti]=1/q2;G[anti,ghost]=-1/q2;P[ghost,anti]=-q2;P[anti,ghost]=q2
    assert len(ids)==231 and len(G)==858 and len(P)==891 and sorted(ids)==ev['selected_M_coordinate_ids']
    for key,wanted in[('Greference',G),('Preference',P),('Pphysical',P),('G_F',{ij:c*ff*ee for ij,c in G.items()}),('full_regulator',{ij:c*(1/(ff*ee)-1)for ij,c in P.items()}),('heat_product',{(i,i):ff*(1-ee)for i in ids}),('IR_product',{(i,i):1-ff for i in ids}),('reference_defect',{}),('reference_product',{})]:
        rows=[r for r in z[key]if r[0]in ids and r[1]in ids];assert rows==ev['complete_selected_matrix_entries'][key]
        actual={(i,j):s.sympify(c,locals=locals0)for i,j,c in rows};assert actual.keys()==wanted.keys()
        for ij,c in actual.items():assert s.cancel(c-wanted[ij])==0,(key,ij)
    # Reconstruct the logarithmic and rational coefficients without expint
    # or the native peer function. The exponential difference has denominator
    # (clock*a), and its kth coefficient follows from differentiating at0.
    for edge_clock,label in[(1,'Fraction_bubble_new'),(2,'Fraction_bubble_old')]:
        rat=[[1,1]]
        for k in range(1,7):
            value=F(2*(-1)**(k+1)*edge_clock**k,k*math.factorial(k))*F(1-F(1,2**(k+1)),k+1)
            rat.append([value.numerator,value.denominator])
        assert dict(rational_coefficients=rat,gamma=-1,log_a=-1,log2=-edge_clock)==ev[label]
    aa,vv=s.symbols('a v',positive=True)
    primitive=vv*s.expint(1,aa*vv)-s.exp(-aa*vv)/aa
    assert s.simplify(s.diff(primitive,vv)-s.expint(1,aa*vv))==0
    actual=2*(primitive.subs(vv,1)-primitive.subs(vv,s.Rational(1,2)))
    J=lambda x:2*s.expint(1,2*x)-s.expint(1,x)+(s.exp(-x)-s.exp(-2*x))/x
    assert s.simplify(actual-J(aa/2))==0
    newconst=1-s.EulerGamma-s.log(2);oldconst=1-s.EulerGamma-2*s.log(2)
    assert s.simplify(newconst-oldconst-s.log(2))==0
    assert s.simplify(s.series(actual,aa,0,1).removeO()+s.log(aa)-newconst)==0
    assert newconst!=oldconst
    assert ev['Fraction_bubble_new']['log2']-ev['Fraction_bubble_old']['log2']==1
    assert 2*F(*ev['Fraction_bubble_old']['rational_coefficients'][0])!=F(*ev['Fraction_bubble_old']['rational_coefficients'][0])
    for pn in['preparation_v3.json']:
        pp=read(O/pn);assert pp==read(C/pn)
        for n,hh in pp['sha256'].items():assert (digest(O/'README_before_semantic_V3.bytes')if n=='README.md'else digest(R/n))==hh,(pn,n)
    cap=read(O/'capture_v3.json');assert cap==read(C/'capture_v3.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
    assert read(O/'result_v3.json')['elapsed_after_imports']<60
    oldreceipt=read(O/'validation_receipt.json');assert oldreceipt['execution_state']=='COMPLETED'
    assert digest(O/'README_before_semantic_V3.bytes')==oldreceipt['files_excluding_pending_receipt_capture']['README.md']
    assert digest(O/'campaign_before_semantic_V3.bytes')==oldreceipt['files_excluding_pending_receipt_capture']['docs/COMMON_RESTORATION_CAMPAIGN_V1.md']
    assert digest(O/'handoff_before_semantic_V3.bytes')==oldreceipt['files_excluding_pending_receipt_capture']['docs/RESEARCH_EXECUTION_HANDOFF_V847.md']
    r,t,d=s.symbols('r t d',positive=True);ch=1-s.exp(-r/d**2);expected=ch**2*s.exp(-2*t*r)
    assert s.simplify(ch*s.exp(-t*r)*ch*s.exp(-t*r)-expected)==0
    assert s.simplify(ch*s.exp(-t*r)*ch-expected)!=0 and s.simplify(ch*s.exp(-2*t*r)-expected)!=0
    assert s.expand((1-ff*ee)-ff*(1-ee))==1-ff
    A,Bb,L,Cc,u,v=s.symbols('A B L C u v');expr=s.expand((A/t**2+Bb/t+L*s.log(t)+Cc)*(1+u*t+v*t*t));constant=expr.coeff(t,0).subs(s.log(t),0);assert s.expand(constant-(Cc+u*Bb+v*A))==0 and s.expand(constant-(Cc+u*Bb))!=0
    assert s.expand((L*s.log(t/2)+Cc)-(L*s.log(t)+Cc)).simplify()==-L*s.log(2)
    j=s.symbols('j',positive=True);assert s.simplify(2**j/(2**j)-1)==0 and s.simplify(2**(-j)-1)!=0
    D=s.symbols('D');sphere=s.Function('sphere');f=(D-4)*sphere(D);assert f.subs(D,4)==0 and s.diff(f,D).subs(D,4)==sphere(4)
    assert len(ev['controls'])==7 and all(ev['controls'].values())
    assert (C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)
    assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md']
    state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'
    assert b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V847.md)'in live
    links=[]
    for p,txt in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V847.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V847.md').read_text(encoding='utf-8')),(O/'RESULT_V3.md',(O/'RESULT_V3.md').read_text(encoding='utf-8'))]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(p.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([p.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture_v4.json',ec);dump(C/'e4_capture_v4.json',ec);assert e.returncode==0
    events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[z['exit_code']for z in events if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(z for z in events if z['event']=='step_finished'and z['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    files=[q for q in O.iterdir()if q.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V847.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_ACTUAL_SCHWINGER_HEAT_CLOCK_INTERFACE_AND_CORRECTED_FINITE_BASELINES',base_HEAD=head,state_sha256=state,selected_M_coordinates=231,all_M_Green_entries=858,all_M_inverse_entries=891,implied_matrix_zeros_checked=True,finite_clock_rule='C_new=C_old-L_log_t*log(2)',inherited_bubble_shift='log(2)/(16*pi**2)',all_seven_controls_sensitive=True,V2_internal_PASS_semantic_scope_corrected=True,failed_denominator_run='FAILED_PRESERVED_NOTPASS',old_reference_raw_bindings_authenticated_NOT_replayed=True,firstDjet_augmented_parent_background_contact_QAP_E5_NOT_established=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',maximum_sampled_primary_private_bytes=max(samples),sampled_not_continuous_peak=True,checked_local_links=links,files_excluding_pending_receipt_capture={q.relative_to(R).as_posix():digest(q)for q in files},shared_inputs_software_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt_v4.json',receipt);dump(C/'validation_receipt_v4.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','finite_clock_rule','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
