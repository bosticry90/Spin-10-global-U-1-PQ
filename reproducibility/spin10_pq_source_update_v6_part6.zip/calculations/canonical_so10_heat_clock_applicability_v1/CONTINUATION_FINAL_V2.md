# Exact receipt-path correction before final worker

The first final preparer failed BEFORE freezing preparation or launching a
worker. It assumed an unsuffixed MPA receipt; the actual completed MPA owner is
validation_receipt_v2.json. Original execute_validation.py/sourcecopy and the
complete tool-transcribed traceback remain preserved. No final validation or
E4 run happened. This is a preparation failure, not a scientific mismatch.

New controller selects that EXACT qualified receipt name for MPA only, retaining
all other named inputs. Existing final source copies are checked byte-equal,
not overwritten; freeze new controller/builder/this record too. The same
unchanged validate.py and180s/8GiB/16MiB/8MiB final contract apply. The original
preparation_validation.json/capture names were never created, so they are
first-created by this bound continuation, not rebound or overwritten.
