# Full-clock rational-series correction

The first120s worker FAILED exit1 at independent bubble comparison. The native
SymPy expression computes I(clock*a),including its denominator clock*a.
The separate Fraction recipe rescaled both exponentials but left denominator
a,so its clock2 rational constant incorrectly became2 rather than1. The
agreement requirement detected this actual algebraic harness error. Preserve
original source/copy/preparation/fullcapture unchanged NOTPASS.

Generate compute_v2.py with ONLY denominator clock*factorial(k+1) in that
Fraction term; this implements the frozen whole-clock comparison. Distinct
preparation/artifact/result/capture names, same120s/8GiB bounds, all inputs,
controls and acceptance obligations unchanged. No adjusted physical input,
desired quantum coefficient or relaxed comparison. Before rerun authenticate
the frozen failed bytes and newsourcecopies. Final validation must independently
derive the rational series and demonstrate that the wrong old denominator is
sensitive. This failure is not a new physical mismatch or a completed result.
