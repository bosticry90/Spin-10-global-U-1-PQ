# Positive-edge equality does not mean equal finite normalization

V791's selected actual-M covariance is f_delta exp(-t_new q²) Gref, with
f_delta=(1-exp(-q²/delta²))². The older joint trace proof puts
chi_epsilon=1-exp(-q²/epsilon²) on BOTH sides of every free edge, and uses
F_old=exp(-t_old P) on both sides. At A0, P=q² times the identity. Scalar
Fourier multipliers commute with the free reference Green matrix, including
its mixed gauge/auxiliary and ordered odd blocks. Therefore exactly

    chi F_old Gref F_old chi
      =chi² exp(-2t_old q²) Gref
      =G_new(2t_old,epsilon).

No heat is moved across an external vertex. Consequently every ordered word
of the SAME matrices, with independent transferred momenta on each edge,
has identical finite-profile kernels after t_new=2t_old,delta=epsilon. Sources,
proper-mean derivatives and inert local probe labels remain in their original
order. Equality is pointwise off singular nodes and also equality of their
common smoothed extension; inverseheat is not integrated separately.

This is an operator-algebra proof for arbitrary finite words. Checking the
actual M blocks and a bubble substantiates input applicability and signs;
finite examples alone are not a completeness proof. The underlying reference
is already related to frozen_full_hessian by V791; we authenticate that
qualified binding, rather than claim another raw Hessian reconstruction.

Rall=Pref/(fE)-Pphysical remains intact, including reference and IR defects.
At M,Pref=Pphysical, so Rall G_new=(1-fE)Id. Its two terms are f(1-E) and
1-f. The profile equality carries the complete defect, not heat-only f(1-E).
Other643-coordinate blocks use formal E/f matrix identities in V791, but
their actual sector profiles were not selected. No full-background claim
follows from this flat M identity; covariant heat need not commute with Gref.

## Finite part under the actual clock conversion

Let a complete coefficient have fixed-IR asymptotics

    F_old(t)=sum_(r<0,m) a_rm t^r(log t)^m+L log t+C+o(1).

The comparison is F_new(t)=F_old(t/2). Complete subtraction in the NEW
clock, with the same frozen logarithmic scale terms, gives

    FP_new F_new=FP_old F_old-L log2.

All negative powers/logged powers are still subtracted, and their coefficients
rescale. Products with analytic heat prefactors must be expanded FIRST. For
example the finite constant in (A/t²+B/t+Llogt+C)(1+c1t+c2t²) is
C+B c1+A c2. Dropping a power term before multiplying loses that constant.
For the ordered-symbol radial terms t^j r^(2j-4), the finite coefficient is
Gamma(j)/(2c^j),j>=1. A clock dilation rescales BOTH t^j and heat length c,
and these factors cancel. Rescaling only the exponential gives a false finite
conversion. This homogeneity proof covers every positive j, not a chosen cap.

The actual qualified normalized two-edge massless bubble is

    16pi² I_new(a)=2E1(2a)-E1(a)+(exp(-a)-exp(-2a))/a,
    a=t_new p_E²,
    FP I_new*16pi²=1-gamma_E-2log2-log p_E².

I_old(t_old)=I_new(2t_old), so the new-minus-old finite coefficient is
+log2/(16pi²), consistent with L=-1/(16pi²). This is an inherited diagnostic
integral evaluated in two clocks, not a newly integrated Spin(10) amplitude.
Common mu/kappa normalization and Gamma_ref[A] are retained in both. The
clock shift is fixed by the prescription comparison, not a fitted parameter.

## What can and cannot now be transferred

Positive finite kernels agree for the same vertices/reference after parameter
conversion. Since this holds at every positive UV/IR parameter, the inherited
UV-FP-before-IR order may be used with the explicit finiteclock shift. No new
limit exchange, deletion of inverse/source defects or critical IR contact is
licensed. The old joint-domain proof remains an imported restricted premise.

The conversion to old T_kappa is still larger:

    C_fin=-Lheat-(i/2)alpha'_4(log(1+Gref,D V_D))

with the separately fixed common logarithmic term and reference retained.
The current4D parent match and clock identity do not define V_D,its firstjet
or multi-insertion normalization. (D-4)/p^4 has zero4D image and nonzero first
jet, so forgetting that input is testably invalid. The actual KD/probe must
be matched to the same admissible augmented fixed-lift parent before taking
rho derivatives of C_fin. A bare mixed zero does not set normalized contacts
zero. Existing QPC/FNPL probe theorems have their original generators; these
are not silently identified with currentKD.

No homogeneous D requirement replaces geometric W5. A single extended
C_fin[S_ext] would determine action AND insertion conversion by differentiation,
with regulator/breaking carriers transported together. This increment neither
proves that complete applicability nor chooses a scheme or finite baseline.
Global QAP/measure/equivalence, E5/A5 and physical viability remain open.
