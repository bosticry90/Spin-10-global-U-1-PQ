from pathlib import Path
import ast
O=Path(__file__).resolve().parent
s=(O/'execute_validation.py').read_text(encoding='utf-8')
s=s.replace("['DERIVATION.md','RESULT.md','validation_receipt.json']","['DERIVATION.md','RESULT.md',('validation_receipt_v2.json'if folder=='canonical_so10_mixed_probe_auxiliary_ward'else'validation_receipt.json')]")
s=s.replace("['RESULT.md','FINAL_RECORD.md','validate.py','execute_validation.py']","['RESULT.md','FINAL_RECORD.md','validate.py','execute_validation.py','CONTINUATION_FINAL_V2.md','build_validation_v2.py','execute_validation_v2.py']")
s=s.replace("    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())","    if(O/(n+'.source.txt')).exists():assert(O/(n+'.source.txt')).read_bytes()==(O/n).read_bytes()\n    else:\n        with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())")
ast.parse(s)
with(O/'execute_validation_v2.py').open('x',encoding='utf-8',newline='\n')as f:f.write(s)
