from pathlib import Path
import ast
O=Path(__file__).resolve().parent
def write(n,s):
    with(O/n).open('x',encoding='utf-8',newline='\n')as f:f.write(s)
s=(O/'compute.py').read_text(encoding='utf-8');old='Q((-clock)**(k+1)-(-2*clock)**(k+1),math.factorial(k+1))';new='Q((-clock)**(k+1)-(-2*clock)**(k+1),clock*math.factorial(k+1))';assert s.count(old)==1
s=s.replace(old,new).replace("'preparation.json'","'preparation_v2.json'").replace("'complete_profile_and_clock_evidence.json.gz'","'complete_profile_and_clock_evidence_v2.json.gz'").replace("'result.json'","'result_v2.json'");ast.parse(s);write('compute_v2.py',s)
s=(O/'execute.py').read_text(encoding='utf-8');start=s.index('C.mkdir(exist_ok=False)');stop=s.index("for n in['RECORD.md'",start)
s=s[:start]+"assert C.is_dir()\n"+s[stop:]
s=s.replace("['RECORD.md','PROOF.md','compute.py','execute.py']","['CONTINUATION_V2.md','build_v2.py','compute_v2.py','execute_v2.py']").replace("'preparation.json'","'preparation_v2.json'").replace("O/'compute.py'","O/'compute_v2.py'").replace("'capture.json'","'capture_v2.json'")
ast.parse(s);write('execute_v2.py',s)
