from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Q
import gzip,json,math,os,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/heat-clock-applicability-v1-2026-11-08')
def read(q):return json.loads(q.read_bytes())
def load(q):return json.loads(gzip.decompress(q.read_bytes()))
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def main():
    tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,v in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==v,n
    z=load(B/'canonical_so10_regulator_free_inverse_g1_recovery_v1/native_inverse.json.gz');assert z==load(B/'canonical_so10_regulator_free_inverse_g1_recovery_v1/replay_inverse.json.gz')
    assert z['active_M_profiles']==dict(E='exp(-t*q_squared)',f='(1-exp(-q_squared/delta_squared))**2')and z['other_sector_profiles_not_selected']
    t,u,q2,delta,eps=s.symbols('t_old t_new q_squared delta epsilon',positive=True)
    chi=1-s.exp(-q2/eps**2);f=1-s.exp(-q2/delta**2)
    old=chi**2*s.exp(-2*t*q2);new=f**2*s.exp(-u*q2);assert s.simplify(new.subs({u:2*t,delta:eps})-old)==0
    inds=set(range(48,180))|set(range(520,553))|set(range(565,598))|set(range(610,643));assert len(inds)==231
    rows={};counts={}
    for key in['Preference','Pphysical','Greference','G_F','full_regulator','heat_product','IR_product','reference_defect','reference_product']:
        allrows=z[key];assert not any((i in inds)!=(j in inds)for i,j,c in allrows)
        rows[key]=[row for row in allrows if row[0]in inds and row[1]in inds];counts[key]=len(rows[key])
    assert rows['Preference']==rows['Pphysical']and not rows['reference_defect']and not rows['reference_product']
    assert counts['Greference']==858 and counts['G_F']==858 and counts['Preference']==891
    # Every selected matrix entry has the SAME exact profile; all zero entries
    # are checked by key-set equality with the complete qualified reference.
    exprlocals={'E_profile':s.Symbol('E_profile',nonzero=True,real=True),'f_profile':s.Symbol('f_profile',nonzero=True,real=True)}
    G={(i,j):s.sympify(c)for i,j,c in rows['Greference']};GF={(i,j):s.sympify(c,locals=exprlocals)for i,j,c in rows['G_F']};assert G.keys()==GF.keys()
    for ij,v in G.items():assert s.cancel(GF[ij]-exprlocals['E_profile']*exprlocals['f_profile']*v)==0,ij
    E,ff=exprlocals['E_profile'],exprlocals['f_profile']
    hp={(i,j):s.sympify(c,locals=exprlocals)for i,j,c in rows['heat_product']};ip={(i,j):s.sympify(c,locals=exprlocals)for i,j,c in rows['IR_product']}
    assert set(hp)==set(ip)=={(i,i)for i in inds}
    assert all(s.expand(hp[i,i]+ip[i,i]-(1-ff*E))==0 for i in inds)
    a=s.symbols('a',positive=True);I=2*s.expint(1,2*a)-s.expint(1,a)+(s.exp(-a)-s.exp(-2*a))/a
    native_new=s.expand(s.series(I,a,0,1).removeO()+s.log(a));native_old=s.expand(s.series(I.subs(a,2*a),a,0,1).removeO()+s.log(a));assert s.simplify(native_new-native_old-s.log(2))==0
    # Independent coefficientwise E1 expansion: constant -gamma-log(c*a),
    # plus rational Taylor coefficients, without SymPy expint/series.
    def peer(clock):
        out=[Q(0)for k in range(7)];gamma=Q(0);loga=Q(0);log2=Q(0)
        for weight,c in[(2,2*clock),(-1,clock)]:
            gamma-=weight;loga-=weight;log2-=weight*(int(math.log2(c)))
            for k in range(1,7):out[k]+=Q(weight*(-1)**(k+1)*c**k,k*math.factorial(k))
        for k in range(7):out[k]+=Q((-clock)**(k+1)-(-2*clock)**(k+1),math.factorial(k+1))
        return dict(rational_coefficients=[[v.numerator,v.denominator]for v in out],gamma=gamma.numerator,log_a=loga.numerator,log2=log2.numerator)
    pnew=peer(1);pold=peer(2);assert pnew['rational_coefficients'][0]==pold['rational_coefficients'][0]==[1,1]and pnew['gamma']==pold['gamma']==-1 and pnew['log_a']==pold['log_a']==-1 and pnew['log2']-pold['log2']==1
    for clock,peerdata in[(1,pnew),(2,pold)]:
        expansion=s.expand(s.series(I.subs(a,clock*a),a,0,6).removeO()+s.EulerGamma+s.log(a)-peerdata['log2']*s.log(2))
        assert expansion==sum(s.Rational(*peerdata['rational_coefficients'][k])*a**k for k in range(6))
    aa,bb,ll,cc,c1,c2=s.symbols('A B L C c1 c2');full=(aa/a**2+bb/a+ll*s.log(a)+cc)*(1+c1*a+c2*a*a)
    finite=s.expand(full).coeff(a,0).subs(s.log(a),0);assert s.expand(finite-(cc+c1*bb+c2*aa))==0
    j,k=s.symbols('j k',positive=True);assert s.simplify(2**j*s.gamma(j)/(2*(2*k)**j)-s.gamma(j)/(2*k**j))==0
    controls=dict(wrong_clock_sensitive=s.simplify(new.subs({u:t,delta:eps})-old)!=0,one_sided_IR_sensitive=s.simplify(chi*s.exp(-2*t*q2)-old)!=0,heat_only_root_sensitive=s.expand(1-ff*E-ff*(1-E))!=0,dropped_power_convolution_sensitive=s.expand(finite-(cc+c1*bb))!=0,forgot_heatjet_rescaling_sensitive=s.simplify(s.gamma(j)/(2*(2*k)**j)-s.gamma(j)/(2*k**j))!=0,forgot_first_dimensionjet_sensitive=True)
    dd=s.symbols('D');evanescent=(dd-4)*s.Symbol('sphere_factor_D');assert evanescent.subs(dd,4)==0 and s.diff(evanescent,dd).subs(dd,4)!=0
    assert all(controls.values())
    report=dict(selected_M_coordinate_ids=sorted(inds),complete_selected_matrix_entries=rows,complete_matrix_entry_counts=counts,profile_old=str(old),profile_new=str(new),clock_substitution='t_new=2*t_old; delta=epsilon',native_bubble_new=str(native_new),native_bubble_old=str(native_old),new_minus_old_normalized_bubble='log(2)',Fraction_bubble_new=pnew,Fraction_bubble_old=pold,finite_asymptotic_rule='C_new=C_old-L_log_t*log(2)',full_power_prefactor_constant=str(finite),controls=controls,actual_other_sector_profiles_NOT_selected=True,old_IR_limit_proof='QUALIFIED_OWNER_REUSED_NOT_RERUN',old_reference_transport='V791_QUALIFIED_OWNER_REUSED_NOT_RERUN',arbitrary_same_vertex_ordered_words='EXACT_EDGE_IDENTITY_PROOF_NO_COMMUTATION_PAST_VERTICES',firstDjet_full_parent_contact_QAP_and_restoration_NOT_established=True)
    blob=gzip.compress((json.dumps(report,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(blob)>8*1024**2:
        with(C/'COMPLETE_OVERFLOW_NOTPASS.json.gz').open('xb')as f:f.write(blob)
        raise AssertionError('COMPLETE_OVERFLOW_PRESERVED_NOTPASS')
    with(O/'complete_profile_and_clock_evidence.json.gz').open('xb')as f:f.write(blob)
    assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=16*1024**2
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='SELECTED_M_POSITIVE_COVARIANCE_MATCHES_AFTER_CLOCK_CONVERSION_WITH_NONZERO_FINITE_SHIFT',selected_coordinates=231,reference_Green_entries=858,selected_inverse_entries=891,full_bubble_clock_shift='log(2)/(16*pi**2)',controls=controls,packet_sha256=digest(O/'complete_profile_and_clock_evidence.json.gz'),elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
