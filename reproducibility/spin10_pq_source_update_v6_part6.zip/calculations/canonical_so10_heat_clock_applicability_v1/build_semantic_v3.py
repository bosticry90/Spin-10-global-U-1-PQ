from pathlib import Path
import ast
O=Path(__file__).resolve().parent;R=O.parents[1]
def write(n,s):
    with(O/n).open('x',encoding='utf-8',newline='\n')as f:f.write(s)
for n,q in[('README_before_semantic_V3.bytes',R/'README.md'),('campaign_before_semantic_V3.bytes',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md'),('handoff_before_semantic_V3.bytes',R/'docs/RESEARCH_EXECUTION_HANDOFF_V847.md')]:
    with(O/n).open('xb')as f:f.write(q.read_bytes())
s=(O/'PROOF.md').read_text(encoding='utf-8')
s=s.replace('16pi² I_new(a)=2E1(2a)-E1(a)+(exp(-a)-exp(-2a))/a,','16pi² I_old(a)=J(a)=2E1(2a)-E1(a)+(exp(-a)-exp(-2a))/a,').replace('a=t_new p_E²,','a=t_old p_E²; I_new(t_new)=J(t_new*p_E²/2)/(16pi²),').replace('FP I_new*16pi²=1-gamma_E-2log2-log p_E².','FP I_new*16pi²=1-gamma_E-log2-log p_E².').replace('I_old(t_old)=I_new(2t_old), so the new-minus-old finite coefficient is','The exact Schwinger domain alpha,beta>=lambda yields\n2 integral_(1/2)^1 E1(lambda*p²*v)dv=J(lambda*p²/2). Hence\nI_old(t_old)=I_new(2t_old), so the new-minus-old finite coefficient is')
s+='\nV3 corrects the shared V2 absolute-clock interpretation. The old internal\nPASS receipt is preserved with that applicability withheld; see\nSEMANTIC_CORRECTION_V3.md. Old finite_heat_transgression is unchanged.\n'
write('PROOF_V3.md',s)
s=(O/'RESULT.md').read_text(encoding='utf-8');s=s.replace('# V847 — heat profiles match after a finite clock conversion','# V847 — corrected actual heat-clock interface')
s+='\nSubsequent semantic review found that V2 labelled the old J(a) bubble with\nthe new clock. Its internal final PASS did not detect that shared premise.\nV3 derives alpha,beta>=lambda directly: actual I_new=J(t_new*p²/2),\nI_old=J(t_old*p²). The new absolute constant is1-gamma_E-log2-logp²; the\nrelative+log2/(16pi²) shift stands. V3 uses a new producer and separate\nvalidation, preserving V2 and its internal receipt without scientific\npromotion. A prior final preparer also failed before worker launch on the\nactual suffixed MPA receipt; its tool-transcribed traceback and correction\nare preserved. See [corrected proof](PROOF_V3.md) and\n[semantic correction](SEMANTIC_CORRECTION_V3.md).\n'
write('RESULT_V3.md',s)
s=(O/'validate.py').read_text(encoding='utf-8').replace("'preparation_validation.json'","'preparation_validation_v3.json'").replace("'complete_profile_and_clock_evidence_v2.json.gz'","'complete_profile_and_clock_evidence_v3.json.gz'").replace("read(O/'result_v2.json')['packet_sha256']","read(O/'result_v3.json')['packet_sha256']")
start=s.index("    for clock,label in[(1,'Fraction_bubble_new')")
end=s.index("    r,t,d=s.symbols",start)
block='''    for edge_clock,label in[(1,'Fraction_bubble_new'),(2,'Fraction_bubble_old')]:
        rat=[[1,1]]
        for k in range(1,7):
            value=F(2*(-1)**(k+1)*edge_clock**k,k*math.factorial(k))*F(1-F(1,2**(k+1)),k+1)
            rat.append([value.numerator,value.denominator])
        assert dict(rational_coefficients=rat,gamma=-1,log_a=-1,log2=-edge_clock)==ev[label]
    aa,vv=s.symbols('a v',positive=True)
    primitive=vv*s.expint(1,aa*vv)-s.exp(-aa*vv)/aa
    assert s.simplify(s.diff(primitive,vv)-s.expint(1,aa*vv))==0
    actual=2*(primitive.subs(vv,1)-primitive.subs(vv,s.Rational(1,2)))
    J=lambda x:2*s.expint(1,2*x)-s.expint(1,x)+(s.exp(-x)-s.exp(-2*x))/x
    assert s.simplify(actual-J(aa/2))==0
    newconst=1-s.EulerGamma-s.log(2);oldconst=1-s.EulerGamma-2*s.log(2)
    assert s.simplify(newconst-oldconst-s.log(2))==0
    assert s.simplify(s.series(actual,aa,0,1).removeO()+s.log(aa)-newconst)==0
    assert newconst!=oldconst
    assert ev['Fraction_bubble_new']['log2']-ev['Fraction_bubble_old']['log2']==1
    assert 2*F(*ev['Fraction_bubble_old']['rational_coefficients'][0])!=F(*ev['Fraction_bubble_old']['rational_coefficients'][0])
    for pn in['preparation_v3.json']:
        pp=read(O/pn);assert pp==read(C/pn)
        for n,hh in pp['sha256'].items():assert (digest(O/'README_before_semantic_V3.bytes')if n=='README.md'else digest(R/n))==hh,(pn,n)
    cap=read(O/'capture_v3.json');assert cap==read(C/'capture_v3.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
    assert read(O/'result_v3.json')['elapsed_after_imports']<60
    oldreceipt=read(O/'validation_receipt.json');assert oldreceipt['execution_state']=='COMPLETED'
    assert digest(O/'README_before_semantic_V3.bytes')==oldreceipt['files_excluding_pending_receipt_capture']['README.md']
    assert digest(O/'campaign_before_semantic_V3.bytes')==oldreceipt['files_excluding_pending_receipt_capture']['docs/COMMON_RESTORATION_CAMPAIGN_V1.md']
    assert digest(O/'handoff_before_semantic_V3.bytes')==oldreceipt['files_excluding_pending_receipt_capture']['docs/RESEARCH_EXECUTION_HANDOFF_V847.md']
'''
s=s[:start]+block+s[end:]
s=s.replace("len(ev['controls'])==6","len(ev['controls'])==7").replace("'e4_capture.json'","'e4_capture_v3.json'").replace("'validation_receipt.json',receipt","'validation_receipt_v3.json',receipt").replace("all_six_controls_sensitive=True","all_seven_controls_sensitive=True,V2_internal_PASS_semantic_scope_corrected=True").replace("evidence_validation='PASS_SELECTED_M_POSITIVE_HEAT_CLOCK_INTERFACE_AND_FINITE_NORMALIZATION_SHIFT'","evidence_validation='PASS_ACTUAL_SCHWINGER_HEAT_CLOCK_INTERFACE_AND_CORRECTED_FINITE_BASELINES'")
s=s.replace("(O/'RESULT.md',(O/'RESULT.md').read_text(encoding='utf-8'))","(O/'RESULT_V3.md',(O/'RESULT_V3.md').read_text(encoding='utf-8'))")
ast.parse(s);write('validate_v3.py',s)
