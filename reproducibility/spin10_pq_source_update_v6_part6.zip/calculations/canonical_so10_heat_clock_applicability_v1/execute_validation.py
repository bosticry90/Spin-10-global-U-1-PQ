from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/heat-clock-applicability-v1-2026-11-08')
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
names=set(json.loads((O/'preparation.json').read_bytes())['sha256'])|set(json.loads((O/'preparation_v2.json').read_bytes())['sha256'])|{'README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V847.md'}
for folder in ['canonical_so10_dimensional_counterterm_applicability','canonical_so10_mixed_probe_auxiliary_ward']:
    for n in ['DERIVATION.md','RESULT.md','validation_receipt.json']:names.add('calculations/'+folder+'/'+n)
for n in['RESULT.md','FINAL_RECORD.md','validate.py','execute_validation.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()};prep=dict(base_HEAD='8ef9051e7a3398207be4ebfe0698343ae90f3648',sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation_validation.json',prep);dump(C/'preparation_validation.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'validate.py')]);dump(O/'capture_validation.json',cap);dump(C/'capture_validation.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
