from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/heat-clock-applicability-v1-2026-11-08');phase=sys.argv[1];assert phase in['compute','validate']
def digest(q):return sha256(q.read_bytes()).hexdigest()
def dump(q,z):
    with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='8ef9051e7a3398207be4ebfe0698343ae90f3648'
names=set(json.loads((O/'preparation_validation.json').read_bytes())['sha256'])
for q in list(O.iterdir()):
    if q.is_file()and q.suffix in['.py','.md']:
        if q.suffix=='.py':ast.parse(q.read_text(encoding='utf-8'))
        copy=O/(q.name+'.source.txt')
        if copy.exists():assert copy.read_bytes()==q.read_bytes()
        else:
            with copy.open('xb')as f:f.write(q.read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()}
pn='preparation_v3.json'if phase=='compute'else'preparation_validation_v3.json';cn='capture_v3.json'if phase=='compute'else'capture_validation_v3.json';worker='compute_v3.py'if phase=='compute'else'validate_v3.py'
prep=dict(base_HEAD='8ef9051e7a3398207be4ebfe0698343ae90f3648',sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/pn,prep);dump(C/pn,prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/worker)]);dump(O/cn,cap);dump(C/cn,cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
