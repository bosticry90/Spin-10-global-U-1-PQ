# V900 pre-execution contract

Audit two local compensation candidates for the V898/V899 selected ghost
transition. Work in the unprobed V879 parent at first loop, with the V871
source-first stationary functional and fixed V868 compact master insertion.
Bind the actual V275 two-route scalar and ghost tensors, V879 two-route
literal source data, and the original VEV. Require exact all-color YY
contraction and VEV tests, then the constant switch jet source projection
for colors 12 and 17. Analyze the complete scalar translation including
its stationary companion. A no-go for a leading g4 correction may only
extend beyond degree two if the absence of constant Eulers in the
unprobed zero-jet g0 parent is authenticated. Keep an amended compact
insertion or lower coupling companions separate. No new normalization,
amplitude, causal limit, or protected promotion.

Native 120 s, final 180 s including E4 cap 120 s, sampled private 8 GiB,
350 MiB launch commit floor, 8 MiB artifact, 32 MiB packet. Require exact
native and replay agreement, an execution receipt, and staged byte review.
