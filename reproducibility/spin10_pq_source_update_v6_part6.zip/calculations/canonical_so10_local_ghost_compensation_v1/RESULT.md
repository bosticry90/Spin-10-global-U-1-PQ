# Local ghost compensation V900

The actual scalar tensors obey YY_Phi=12 E_Phi E_Phi^T and
YY_Sigma=17 E_Sigma E_Sigma^T. Contraction of Y with the original
scalar VEV is minus the corresponding Gram matrix. This identifies
a local scalar translation whose ghost component has the required
opposite coefficient. With its complete action variation included,
its one-loop connected change is only the ordinary scalar-source
term minus the translation paired with j_x. The two-ghost connected
transition is unchanged by this route.

For a local correction starting at g4, holding the compact master
insertion fixed requires the homogeneous linearized master equation
at that order. The constant-jet Lambda_i C_i and J_a_i C_i rows for
colors 12 and 17 have determinant s^2 at an intermediate switch
value s. The tempting J_Lambda_i C_i companion cancels the first
row only by producing the second. The two V879 source inventories
exclude other routes into those rows. The original source and
physical action and reference have zero constant tree Eulers on
this slice, so higher-valence monomials cannot change the test.
The two required diagonal coefficients cannot both vanish for
distinct positive squared reference masses at one common kappa.

This excludes the tested leading local correction with the fixed
insertion, and identifies why the complete translation is ineffective.
An amended compact insertion, lower-coupling companions, other
normalizations and the full causal weak limit are separate questions.
The exact tests share the action, conventions and symbolic system.
