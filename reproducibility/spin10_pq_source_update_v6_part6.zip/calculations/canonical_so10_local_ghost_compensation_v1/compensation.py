"""Exact scalar and constant-jet source controls for the V900 proof."""

from collections import Counter, defaultdict
import gzip
from itertools import product
import json
import sys

import sympy as sp

from execute import PK, ROOT, run_worker


COLORS = range(45)
BLOCKS = {"Phi": (0, 54, 12), "Sigma": (54, 306, 17)}


def read(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == ".gz" else raw)


def packet(name):
    return ROOT / "calculations" / f"canonical_so10_{name}"


def scalar_checks(role):
    data = read(packet("ghost_mass_g4_pole") / f"{role}_v2_result.json")
    frame = read(PK / "frozen_a10_physical_reconciliation" / f"full_{role}.json")
    vacuum = {x: sp.sympify(value) for x, _, value in frame["vacuum"]["VEV"]["entries"]}
    es = defaultdict(dict)
    ys = defaultdict(dict)
    for a, x, value in data["physical_E"]:
        es[x][a] = sp.sympify(value)
    for x, a, c, value in data["physical_Y_aC_density"]:
        ys[x][a, c] = sp.sympify(value)
    assert set(es) | set(ys) <= set(range(306))

    checks = {}
    for block, (first, stop, factor) in BLOCKS.items():
        gram, yy, translated = (defaultdict(lambda: sp.S.Zero) for _ in range(3))
        for x in range(first, stop):
            for (a, left), (c, right) in product(es[x].items(), repeat=2):
                gram[a, c] += left * right
            by_left = defaultdict(list)
            for (a, c), value in ys[x].items():
                by_left[a].append((c, value))
                translated[a, c] += vacuum.get(x, 0) * value
            for (a, k), left in ys[x].items():
                for c, right in by_left[k]:
                    yy[a, c] += 2 * left * right
        old = {(a, c): sp.sympify(value)
                for a, c, value in data["physical_scalar_sector_family_poles"][block]["YY"]}
        nonzero = 0
        for key in product(COLORS, repeat=2):
            assert sp.expand(yy[key] - old.get(key, 0)) == 0, (block, key, "owner")
            assert sp.expand(yy[key] - factor * gram[key]) == 0, (block, key, "Gram")
            assert sp.expand(translated[key] + gram[key]) == 0, (block, key, "VEV")
            nonzero += bool(sp.expand(yy[key]))
        for b, i in product(COLORS, (12, 17)):
            bridge = sum(es[x].get(b, 0) * ys[x].get((i, i), 0) for x in range(first, stop))
            assert sp.expand(bridge) == 0, (block, b, i, "simple Ja bridge")
        assert nonzero == {"Phi": 24, "Sigma": 57}[block]
        checks[block] = {"positions": 2025, "nonzero": nonzero, "factor": factor,
                         "simple_Ja_bridge_zero_tests": 90,
                         "YY_12_12": str(sp.expand(yy[12, 12])),
                         "YY_17_17": str(sp.expand(yy[17, 17]))}
    assert checks["Phi"]["YY_17_17"] == "300"
    assert checks["Sigma"]["YY_12_12"] == "51/2"
    assert checks["Sigma"]["YY_17_17"] == "51/20"
    return checks


def source_checks(role, coefficients):
    gf = read(packet("unprobed_compact_all_coupling_v1") / f"{role}_full_current.json.gz")
    raw = gf["current"]["complete_S_GF_source"]
    words = [(g, word, value) for g, word, value in raw if all(i < 1286 for i, _ in word)]
    assert min(len(word) for _, word, _ in words) == 2
    g0 = [(word, value) for g, word, value in words if g == 0]
    bins = Counter((len(word), sum(i >= 643 for i, _ in word)) for word, _ in g0)
    assert bins == {(2, 0): 405, (2, 1): 225, (3, 0): 600}
    potential = read(packet("physical_current_input_recovery_g1_v1") / coefficients)
    arities = Counter(a for term in potential["potential_scope"]
                       for a, _, _, _ in term["all_arities"])
    assert arities == {2: 4, 3: 3, 4: 22}
    zero_jet = {tuple(i for i, _ in word): value for word, value in g0
                if all(not jets for _, jets in word)}

    # Reverse the two Euler routes. The companion is the BV dual of the
    # removed action letter. This enumerates linear and quadratic inputs.
    def support(target):
        routes = set()
        for word in zero_jet:
            for offset, carrier in enumerate(word):
                dual = carrier + 643 if carrier < 643 else carrier - 643
                remaining = list(word[:offset] + word[offset + 1:])
                remainder = list(target)
                for letter in remaining:
                    if letter not in remainder:
                        break
                    remainder.remove(letter)
                else:
                    routes.add(tuple(sorted([dual, *remainder])))
        return routes

    for i in (12, 17):
        lam, ghost, anti = 508 + i, 553 + i, 598 + i
        ja, jl = anti + 643, lam + 643
        assert zero_jet[lam, ja] == [[[0, 0, 16], -1, 1]]
        assert zero_jet[lam, lam] == [[[1, 0, 0], 1, 2]]
        assert support((lam, ghost)) == {(ghost, anti), (ghost, jl)}
        assert support((ja, ghost)) == {(ghost, jl)}
    return {"g0_bins_quadratic_ordinary_source_cubic": [405, 225, 600],
            "physical_potential_arities": [4, 3, 22],
            "projected_source_support": {"12": [2, 1], "17": [2, 1]},
            "total_gf_minimum_valence": 2}


def controls():
    s, w, m, n = sp.symbols("s w m n")
    matrix = sp.Matrix([[sp.I*s, w], [0, -sp.I*s]])
    assert sp.expand(matrix.det()) == s**2
    # Deliberately omit the Ja,C row. The apparent companion is then
    # accepted by the first row, but its true second row is nonzero.
    assert matrix * sp.Matrix([w, -sp.I*s]) == sp.Matrix([0, -s**2])

    x, mass, bilinear, shift, source = sp.symbols("x mass bilinear shift source")
    full = shift * (mass*x + bilinear)
    root = -(bilinear + source)/mass
    assert sp.expand(full.subs(x, root)) == -shift*source
    assert sp.expand((shift*bilinear).subs(x, root)) != 0

    sigma, lp, ls = sp.symbols("sigma L_Phi L_Sigma")
    h = sigma**2*(1-sigma)
    assert sp.expand(sigma*sigma*(1-sigma) - h) == 0
    m12, m17 = 51*ls/2, 300*lp + 51*ls/20
    assert sp.expand(m17 - sp.Rational(2017, 170)*m12) == 300*(lp-ls)
    return {"fixed_insertion_determinant": "s**2",
            "omitted_source_row_false_solution": "-s**2",
            "complete_stationary_shift": "-u*j_x",
            "reference_invariant_combination": "300*(L_Phi - L_Sigma)"}


def check(phase):
    if phase == "native":
        roles = "primary", "native", "native_v2_coefficients.json.gz"
    else:
        roles = "replay", "replay", "replay_v4_coefficients.json.gz"
    return {"scalar": scalar_checks(roles[0]), "source": source_checks(*roles[1:]),
            "controls": controls()}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
