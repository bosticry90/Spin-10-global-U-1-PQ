# Local compensation and the fixed compact insertion

## The scalar translation route

Strip the common one-loop units as in V898. Use the actual V275 real
physical-frame E and Y, where the ghost ordering is a before C. For each
scalar block s, evaluate the following full 45 by 45 matrices, including
every zero:

    G_s[a,c] = sum_x E[a,x] E[c,x]
    YY_s[a,c] = 2 sum_(x,k) Y[x,a,k] Y[x,k,c]
    Y_s[v_s][a,c] = sum_x v_s[x] Y[x,a,c].

The last expression is minus G_s. The first two satisfy YY_Phi=12 G_Phi
and YY_Sigma=17 G_Sigma. Check the coefficient identities by direct
contraction, against the exact inherited pole tables and the two recovered
VEV records. The covariance uses the real Cartesian scalar pairing.
For an explanation of the integer weights use Y[x,a,c]=(rho_c E_a)_x on
the broken columns and E_a=rho_a v. Unbroken E_a is zero. With real
skew generators and the normalized adjoint Casimir 8, the double
commutator gives sum_k rho_k rho_c rho_k=(4-C_s)rho_c. Hence
YY/2=(C_s-4)G on the paired indices. The executable check uses actual
tensors and does not assume the Casimir relation.

For h=sigma^2(1-sigma), set the infinitesimal scalar translation to
u=g^2 xi sigma(1-sigma)(12 L_Phi v_Phi+17 L_Sigma v_Sigma), with the common
loop factor understood. The switched ghost vertex alone gives the
negative of the desired h a^t m C correction. The complete infinitesimal
action change is N=int u . EL_x^L P. This includes the scalar, auxiliary
and source companions of the original parent. At first loop its connected
effect is N(phi0) by V871. On the tree stationary root EL_x^L P=-j_x,
so N(phi0)=-int u . j_x. The effect vanishes on the connected ghost
source slice, including after both ghost derivatives. This argument
does not require a standalone change-of-variables theorem for an
interacting measure. A finite coefficient involving L_s must still
be evaluated in the fixed reference scheme. The complete action
translation would carry its transformed compact master insertion.
An isolated term that merely resembles one component of N does not
inherit the stationary cancellation.

## A fixed-insertion necessary condition

Fix B[P]=int sum_i (-1)^p_i EL_Ji^L P EL_zi^L P. If the compact master
insertion is held fixed, a new loop correction Delta at leading g4 must
satisfy its linearized unprobed equation Q_0 Delta=0 as an integrated
identity. Test the zero-jet projection on a patch with sigma=s, 0<s<1,
and background A, marks, and ordinary sources zero. Such a patch can be
prescribed on a compact switch. The zero-jet projection kills total
divergences of translation-covariant local densities. It also kills the
Euler images from derivative terms, since every derivative lands on a
field, source, or switch jet. This projection never uses a constant
switch on all of spacetime.

For i=12,17, write the quadratic input coefficients m_i a_i C_i and
n_i J_Lambda_i C_i. The actual degree-zero current-chart terms include
w_i Lambda_i^2/2 and -i s Lambda_i J_a_i. The LEFT rule and p_a=1 give
F_a=+i s Lambda_i, and the Lambda Euler has w_i Lambda_i-i s J_a_i.
The output coefficients of Lambda_i C_i and J_a_i C_i are respectively

    i s m_i + w_i n_i,       -i s n_i.

They force n_i=m_i=0 for every width. The source calculation tests
the two possible quadratic routes by differentiating the actual words.
All other derivative-free source terms in the projected g0 GF sector
are the cubic Lambda C a terms. A linear input J_a can hit this cubic
through its a Euler, but its complete support contains no diagonal
Lambda_i C_i rows. The V787 potential AST census has four quadratic, three cubic and
22 quartic terms in the original unshifted mean. Its kinetic ASTs and
the flat V869 reference start at degree two. Both V879 GF/source charts
start at degree two as well. Thus the parent has no constant field or
source Euler, and a correction of degree three or greater cannot feed
the degree-two test. Source-free physical terms cannot provide either
target carrier after a single Euler, and their gauge kinetic terms at
g0 have derivatives. This is a tree statement, unrelated to the values
of quantum tadpoles. The scope is the 643-field unprobed parent.

For unequal positive squared reference masses the two V898 required
diagonal weights cannot both vanish with one kappa. Thus the projected
leading-g4 ghost compensation cannot preserve the fixed compact
insertion in the tested class. This test does not exclude changes
that start at lower coupling, an amended compact breaking insertion,
or a common causal finite map with a different transported source
prescription. Such a map must handle the new local insertion and all
its linked derivatives. The independently switched causal cut problem
also remains distinct.
