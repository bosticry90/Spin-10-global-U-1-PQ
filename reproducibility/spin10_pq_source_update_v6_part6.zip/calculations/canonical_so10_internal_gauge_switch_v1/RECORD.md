# V896 pre-execution contract

Test the actual rank-two auxiliary entry and determine which
internal paths it can reopen. Keep the V879 joined chart and
literal sourcefree coefficient list, the V894 switch Hessians,
the V791 free inverse, and the V895 Euclidean radial class.
Require a width-independent nonzero exact two-switch entry,
an energy inverse at bounded real widths including zero, and
the actual one-port and two-port graph budget at color 12,
one loop, g^4 and two explicit xi factors. Keep scalar
mass-difference degree, A and retained sources zero.

Bind both literal and inverse packets. Check the lower-grade
L pair and M scalar dressing as negative controls on a general
auxiliary zero. Exclude new paths in the selected sector only
by the actual coefficient and valence constraints. State the
operator form bound separately from loop-kernel estimates.
No Lorentzian weak limit, inverse width normalization or
physical promotion follows from these checks.

Native limit 120 s, final 180 s including E4 cap of 120 s,
8 GiB sampled private, 350 MiB launch commit floor, 8 MiB
artifact, 32 MiB packet. Freeze proof, code and actual input
bytes. Require replay and exact staged bytes.
