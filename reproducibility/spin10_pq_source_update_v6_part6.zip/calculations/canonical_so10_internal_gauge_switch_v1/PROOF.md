# Two gauge switches and the actual internal ghost census

Use the V894 switched Maxwell and mixed auxiliary Hessians and
the V791 free reference in the joined Euclidean field chart.
Keep width symbolic for the finite-order algebra. For the
operator estimate let both real widths range in a fixed bounded
set. The wide radial switch class is that of V895. Scalar
mass-difference degree, A and retained sources are zero. The
color-12 graph census below is at g^4 and two explicit xi powers.
Propagator widths are distinguished from those explicit vertex
powers throughout.

## Nonzero two-switch auxiliary inverse

At incoming momentum k, outgoing u and intermediate v write
r1=u−v and r2=v−k. Denote P_T(v)=I−vv^T/v². The exact
G(u)Q(u,v)G(v)Q(v,k)G(k) auxiliary entry is

    −v² u^T P_T(v) k / (4 u² k²)
      = [(u·v)(v·k)−v²(u·k)]/(4u²k²).

Indeed use the rank-one mixed row
(v/v²−u/u²)^T/2, with zero auxiliary-auxiliary entry.
Only Q_BB(v,k)(−k/k²) contributes. The first part
of the row annihilates this vector because the Maxwell
double longitudinal contraction is zero. Direct substitution
gives the formula. The positive sign of the second term in
the inverse Neumann series is included. The width and the
intermediate denominator have canceled.

The wedge product form is
−(u wedge v)·(k wedge v)/(4 u² k²). It gives
the bound |r1||r2|/(4|u||k|), of degree zero under
joint soft scaling. For equal external u=k, the kernel is
−[r²u²−(r·u)²]/(4u⁴), r=v−u. Neither ordering of
the opposite switch transfers cancels it. For a real radial
chi, the integrated diagonal in measure d⁴v/(2 pi)^4 is
−3 integral |grad chi|²/(16 u²). This follows by angular
averaging and Parseval. More generally the integral is the
negative of a squared-norm kernel. The two factors are
|v| P_T(v)u hat chi(u−v)/(2u²) and the conjugate factor
with k in place of u. Thus smooth wavepackets near nonzero u
detect the nonzero term. Common positive scalar profiles
insert positive exterior factors and a positive intermediate
weight, preserving the sign. The diagonal slice is a
kernel diagnostic, with no inference of a loop amplitude.

## All-count gauge form and its auxiliary block

For a profile sigma use the energy space
dot H¹(B) direct sum L²(Lambda), with norm squared
||grad B||²+||Lambda||². After the |D| isometry on B
the free inverse has transverse identity and a longitudinal
two by two block [[w,−1],[1,0]]. Its norm is at most
1+|w|. Define a=|| |x| grad sigma ||_infty.
The switched Maxwell density differs by
−(grad sigma)_mu B_nu F_mu,nu/2, and the mixed density
differs by −i (grad sigma)_mu Lambda B_mu/2. Hardy in
four dimensions gives ||B/|x|||₂≤||grad B||₂. Since
||F||₂≤sqrt(2)||grad B||₂, polarization of the two
densities bounds the gauge switch form by
(sqrt(2)+1/2) a in the energy norm. For V895's radial
log profile a≤||b'||_infty/ell, unchanged by dilation.
Choose ell large enough that this bound times the free
inverse norm is below one for the whole width set.
The full Euclidean form inverse is then the norm-convergent
Neumann series, including at width zero.

The auxiliary block has a sharper bound. Write the full
gauge form as [[A,−L*],[L,w]] where
L=i(div−grad sigma dot/2) and A is the switched Maxwell
operator. On gradients L is onto L² with bounded gradient
right inverse R_sigma. For this, on dot H² the free map
i Delta is an isometry up to phase, and the switch part
has norm at most a/2 by Hardy on grad u. Use Neumann for
a<2. Decompose B=R_sigma s+T_sigma t with s=LB,
t transverse and T_sigma t=t−R_sigma L t. The
map is a bounded isomorphism in the energy norm, and the
gradient correction of t is O(a). On two gradients the
Maxwell form vanishes exactly since F is zero. The
transverse block A_T of A on T_sigma t is coercive
for small a, by its free principal form and the Hardy
bound on Q_BB. The cross block E from s to t is O(a)
since the free Maxwell form vanishes against a gradient.
Eliminating t leaves [[−C,−I],[I,w]], with
C=E* A_T^-1 E positive semidefinite and O(a²).
For sufficiently broad switches on the bounded width set
the exact auxiliary block is

    G_LambdaLambda=−C(I−w C)^-1.

Thus it is nonpositive as an L² form and O(a²), and the
bound holds without division by a width. This form argument
establishes an inverse on the stated spaces. Local and
global estimates for the kernels in loop products are a
separate step. The free scalar with positive mass squared
and switch potential (Delta sigma)/2 has its own coercive
inverse for the same broad radial class by the V895 Hardy
bound. The ghost inverse was controlled in V895.

## Which actual diagrams can use the new entry

Use one loop, two ordinary ghost leaves and color-diagonal
quadratic switching. Such switches are already on free
edges and cost no g or explicit xi. The V879 sourcefree
census has just one positive-g quadratic M=x Lambda
at (g degree, explicit xi degree)=(1,1). The cubic
possibilities with odd ports are L=Lambda C a at (0,1),
F=B C a at (1,0), and Y=x C a at (2,1). The quartic
possibilities are D=B B C a at (2,0) and four-ghost
terms at (1,1) or (2,1). The pure bosonic kinetic vertices
and scalar potential have no odd ports.

A proper one-loop two-port core has sum of valence minus
two equal to two. A quartic with both exterior ghosts
must satisfy the coupling budget with bivalent M. The
only candidate at (4,2) is D with two M, with no
literal color-12 diagonal D row. Two cubics with an
external ghost at each can only be F F plus two M,
F Y plus one M, or Y Y. Any L combination needs
extra explicit xi to reach g^4. A cubic bearing both
exterior ghosts in the selected color must be Y by the
literal rows, with a Sigma scalar port. An additional
two-cubic proper core with both external ports at that
one vertex would require an internal one-port subgraph
at the other vertex and a single bridge. It belongs
to the rooted feedback census.

For the surviving proper paths the bosonic connection
between F and M uses B,Lambda and the scalar endpoints
are connected by scalar inverses. Replacing a free gauge
edge with its switched sum changes its kernel but cannot
substitute Lambda,Lambda for a B endpoint. The diagonal
two-ghost source tree also has exactly one cubic and is
Y with its Sigma scalar root. The remaining one-port
core and bridge budget is (2,1). It allows either Y
with its ghost trace, or one M and one g-linear bosonic
or ghost cubic. With M inside the kinetic Bxx loop the
root is the same scalar as in V883. If M is on the
root and the loop opens a B or Lambda port, the actual
cubic traces vanish. For Bxx the scalar trace is skew.
The BBB trace contracts an antisymmetric color factor
against a diagonal pair. The F trace has no diagonal
C,a row. The BB Lambda rows are B_H B_M Lambda_M.
Output Lambda_M needs a crossed B pair. Output B_M
needs a crossed mixed pair. Output B_H cannot connect
to the M root in the M block. Color-diagonal free
switching preserves all those restrictions, including
the new Lambda,Lambda block. No other root meets the
literal coupling and valence budget. The existing
proper and feedback classes therefore exhaust this
selected sector after internal quadratic switching.

There are new paths elsewhere. At g^0 and explicit
xi^2, two L cubics can use the two-switch auxiliary
entry with an ordinary ghost edge. The actual joined
color-12 contractions have 56 matched auxiliary and
internal ghost pairs and nonzero summed product 8
with explicit xi² stripped, before ordered loop signs
and integration. A second control uses the actual M
entry with x386 and Lambda520, of coefficient
+i sqrt(6) g xi/8. Two such vertices and the new
auxiliary entry give a nonzero scalar dressing kernel.
Putting that dressing on a Y Y scalar edge consumes
g^6 xi^4. These are supported kernels, with the loop
normalizations for the other degrees still open.

The result removes new path classes as a source of
compensation in the selected g^4 explicit-xi² sector.
The existing internal kernels can still change under
switching. To decide their contribution requires uniform
estimates on their renormalized loop products, beyond
the form bounds here. Preserve the V895 exterior sum,
V883 regulator-rate control and the polynomial coupling
ring. The exact tests share the action, software and
AI authorship.
