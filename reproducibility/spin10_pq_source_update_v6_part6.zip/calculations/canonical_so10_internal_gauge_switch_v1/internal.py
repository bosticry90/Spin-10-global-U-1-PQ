"""Actual two-switch auxiliary algebra and sourcefree graph census."""

from collections import Counter
import gzip
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def load(owner, role, suffix):
    path = ROOT/"calculations"/("canonical_so10_"+owner)/(role+suffix)
    with gzip.open(path,"rt",encoding="utf-8") as stream:
        return json.load(stream)


def auxiliary(role):
    width = sp.Symbol("eta_H")
    q = sp.Matrix(sp.symbols("q0:4"))
    slots = [0,1,2,3,508]
    packet = load("regulator_free_inverse_g1_recovery_v1",role,"_inverse.json.gz")
    raw = {(i,j):sp.sympify(value) for i,j,value in packet["Greference"] if i in slots and j in slots}

    def free(k):
        p = k.dot(k)
        D = sp.eye(4)/p+(width-1)*k*k.T/p**2
        return D.row_join(-k/p).col_join((k.T/p).row_join(sp.zeros(1,1)))

    def Q(u,v):
        r = u-v
        A = (-r.dot(r)*sp.eye(4)-v*r.T+r*u.T)/2
        return A.row_join(r/2).col_join((r.T/2).row_join(sp.zeros(1,1)))

    def expected(u,v,k):
        return (u.dot(v)*v.dot(k)-v.dot(v)*u.dot(k))/(4*u.dot(u)*k.dot(k))

    def probe(u,v,k):
        exact = free(u)*Q(u,v)*free(v)*Q(v,k)*free(k)
        got = sp.expand(exact[4,4])
        if role == "native":
            rhs = expected(u,v,k)
        else:
            wedge = [(u[i]*v[j]-u[j]*v[i])*(k[i]*v[j]-k[j]*v[i])
                     for i in range(4) for j in range(i+1,4)]
            rhs = -sum(wedge)/(4*u.dot(u)*k.dot(k))
        assert got == rhs == expected(u,v,k)
        assert width not in got.free_symbols
        return got

    e1,e2,e3,e4 = map(sp.Matrix,([1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]))
    v = e3+e1
    u = e3+2*e1+e2
    for mom in (u,v,e3,e1+e2):
        observed = sp.Matrix(5,5,lambda i,j:raw.get((slots[i],slots[j]),sp.S.Zero))
        assert (observed.subs(dict(zip(q,mom)),simultaneous=True)-free(mom)).applyfunc(sp.expand) == sp.zeros(5)
    assert sp.expand((free(u)*Q(u,v)*free(v))[4,4]) == 0
    assert probe(u,v,e3) == sp.Rational(1,24)
    assert probe(u,e3+e1+e2,e3) == sp.Rational(1,24)
    assert probe(e1,e1+e2,e1) == probe(e1,e1-e2,e1) == -sp.Rational(1,4)
    assert probe(e1+2*e4,e2+e4,e3+e4) == probe(e3+e4,e2+e4,e1+2*e4)
    return {"one_switch_LambdaLambda":0,"two_ordered_independent_transfers":"1/24",
            "two_opposite_transfer_order_sum":"-1/2","width_independent":True,
            "radial_diagonal_factor":"-3/(16*u^2)"}


def sourcefree(role):
    rows = load("unprobed_compact_all_coupling_v1",role,"_full_current.json.gz")["current"]["complete_S_GF_source"]
    counts = Counter()
    L = {}
    M = None
    diag = Counter()
    diag_Y = 0

    def field(i):
        if i < 180:
            return "B"
        if i < 508:
            return "x"
        if i < 553:
            return "L"
        if i < 598:
            return "C"
        if i < 643:
            return "a"
        return "external"

    for grade,word,cells in rows:
        ids = [i for i,_ in word]
        types = tuple(field(i) for i in ids)
        if "external" in types:
            continue
        for (xi,eta,mask),num,den in cells:
            key = (grade,xi,eta,types)
            counts[key] += 1
            if 565 in ids and 610 in ids:
                diag[key] += 1
            if types == ("B","B","L"):
                assert ids[0]<48<=ids[1]<180 and ids[2]>=520
            if types == ("B","C","a"):
                assert ids[1]+45 != ids[2]
            if types == ("x","C","a") and 565 in ids and 610 in ids:
                assert 234 <= ids[0] < 486
                diag_Y += 1
            if types == ("L","C","a"):
                radical = sp.sqrt(sp.prod(p for bit,p in enumerate((2,3,5,7)) if mask&(1<<bit)))
                phase = sp.I if mask&16 else 1
                assert grade == 0 and xi == 1 and eta == 0 and not any(j for _,j in word)
                label = (ids[0]-508,ids[1]-553,ids[2]-598)
                assert label not in L
                L[label] = sp.Rational(num,den)*radical*phase
            if word == [[386,[]],[520,[]]]:
                assert grade == 1
                M = cells
    expected = {(0,0,0,("B","L")):180,(0,0,0,("C","a")):180,
                (0,0,1,("L","L")):12,(0,1,0,("L","L")):33,
                (0,1,0,("L","C","a")):600,(1,0,0,("B","B","L")):1336,
                (1,0,0,("B","C","a")):10704,(1,1,0,("C","C","a","a")):3096,
                (1,1,0,("x","L")):296,(2,0,0,("B","B","C","a")):53016,
                (2,1,0,("C","C","a","a")):1672,(2,1,0,("x","C","a")):6268}
    assert counts == expected
    assert diag[(2,0,0,("B","B","C","a"))] == 0 and diag_Y == 16
    cl = {(l,a):v for (l,c,a),v in L.items() if c == 12}
    al = {(l,c):v for (l,c,a),v in L.items() if a == 12}
    assert set(cl) == set(al) and len(cl) == 56
    assert sp.simplify(sum(cl[k]*al[k] for k in cl)) == 8
    assert M == [[[1,0,19],1,8]]
    return {"literal_L_rows":600,"lower_grade_L_pair_count":56,
            "lower_grade_L_raw_color_product":8,"Sigma_Y_external_rows":16,
            "diagonal_D_rows":0,"new_xx_M_squared_factor":"-3/32"}


def budget():
    types = {"L":(0,1),"F":(1,0),"Y":(2,1),"D":(2,0),"R1":(1,1),"R2":(2,1)}
    candidates = [((a,b),n) for i,a in enumerate(("L","F","Y")) for b in ("L","F","Y")[i:]
                  for n in range(5) if (types[a][0]+types[b][0]+n,types[a][1]+types[b][1]+n)==(4,2)]
    quartics = [(a,n) for a in ("D","R1","R2") for n in range(5)
                if (types[a][0]+n,types[a][1]+n)==(4,2)]
    assert candidates == [(("F","F"),2),(("F","Y"),1),(("Y","Y"),0)]
    assert quartics == [("D",2)]
    w,c,j = sp.symbols("w c j")
    schur = sp.Matrix([[-c,-1],[1,w]])
    assert sp.cancel((schur.inv()*sp.Matrix([0,j]))[1]+c*j/(1-w*c)) == 0
    assert schur.subs(w,0).inv()[1,1] == -c
    return {"allowed_proper_cubic_pairs":[[list(a),n] for a,n in candidates],
            "quartic_candidate":[["D",2]],
            "full_auxiliary_Schur":"-C*(I-w*C)^-1",
            "inverse_width_needed":False}


def checks(role):
    return {"auxiliary":auxiliary(role),"literal":sourcefree(role),"budget":budget()}


if __name__ == "__main__":
    run_worker(checks,sys.argv[1])
