# V896 — Two-switch auxiliary entry and the internal graph census

The actual LambdaLambda inverse is zero at one gauge switch
and nonzero at two. The two-switch formula is width independent
and has no intermediate momentum denominator. At equal external
momenta its radial diagonal is negative and nonzero. Both switch
orderings contribute. The exact integrated form is a negative
squared norm, so the kernel is detected by smooth wavepackets.

On the wide radial Euclidean profiles the full gauge form has
a convergent Neumann inverse for widths in any fixed bounded
real set, including zero. A gradient/transverse decomposition
gives the exact nonpositive auxiliary block
−C(I−w C)^−1 with C positive and quadratic in the switch
gradient bound. This requires no inverse width. A form inverse
does not establish the products of its kernels in loops.

The actual one-port and two-port census finds no added topology
for color 12 at one loop, g^4 and two explicit xi powers.
FMY, YY, FFMM and the massive Sigma feedback remain. The
diagonal D term is absent in the literal chart. The new inverse
does enable a lower-grade ghost loop through two L cubics and a
higher-grade scalar dressing through two M vertices. The
literal controls check 56 matched auxiliary and ghost pairs
in the lower-grade loop and the actual i sqrt(6)/8 M entry.

Require final replay and capture. The checks share model inputs,
software and AI authorship. Whether the existing internal
kernels compensate the exterior transition term requires a
separate estimate. Full causal equivalence and E5/A5 remain open.
