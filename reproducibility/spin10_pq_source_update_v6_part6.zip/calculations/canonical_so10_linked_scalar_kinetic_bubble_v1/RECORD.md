# V951 pre-execution contract

Test the linked ordinary scalar quadratic and cubic
responses of the V949 BB–scalar two-edge kernel.
Freeze the physical kinetic vertices, bosonic
one-loop orientation and transverse numerator. Use
the same normalized kernel weight for both responses
within each sector. Compare the independent cubic
and quadratic color factors with their combined
Slavnov expression in all three ordinary scalar
blocks.

Derive the full color identity analytically and
check nontrivial, singlet and light generator controls
from both literal routes. Distinguish color equality
from actual mass-dependent kernel values and compact
profiles. No finite weight or physical normalization
is adopted. Native 120 s, final 180 s including E4
cap 120 s, 8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority change.
