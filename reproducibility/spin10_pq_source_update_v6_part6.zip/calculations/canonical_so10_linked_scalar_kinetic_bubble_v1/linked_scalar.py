"""Test linked ordinary scalar cubic and quadratic color factors."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)


def check(phase):
    _, entries, _, f, _, _ = source.owner.inputs(phase)
    sectors = (range(12),range(12,45))
    casimir = []
    for sector in sectors:
        A = {j:defaultdict(lambda:sp.S.Zero) for j in range(45)}
        for j in range(45):
            for a in sector:
                for k,x in f[a,j]:
                    for i,y in f[a,k]:
                        A[j][i] -= x*y
        casimir.append({j:source.owner.clean(v) for j,v in A.items()})
    assert all(source.add(casimir[0][j],casimir[1][j]) == {j:8} for j in range(45))

    blocks = ((0,54,sp.Integer(10)),(54,306,sp.Rational(25,2)),(306,326,sp.Rational(9,2)))
    values = []
    for lo,hi,C in blocks:
        n = hi-lo
        R = {a:sp.SparseMatrix(n,n,{(i-lo,j-lo):z for (i,j),z in data.items()
                                   if lo<=i<hi and lo<=j<hi}) for a,data in entries.items()}
        zero = sp.SparseMatrix(n,n,{})
        A = [-sum((R[a]**2 for a in sector),zero).applyfunc(sp.expand) for sector in sectors]
        assert A[0]+A[1] == C*sp.eye(n)
        for b in (1,12,13):
            linked = []
            cubics = []
            for sector, wave, K in zip(sectors,A,casimir):
                cubic = zero.copy()
                for a in sector:
                    product = R[a]*R[b]+R[b]*R[a]
                    cubic += product*R[a]+R[a]*product
                cubic = cubic.applyfunc(sp.expand)
                Z = -4*wave
                value = (cubic-(Z*R[b]+R[b]*Z)/2).applyfunc(sp.expand)
                expected = sum((z*R[a] for a,z in K[b].items()),zero).applyfunc(sp.expand)
                assert value == expected
                linked.append(value)
                cubics.append(cubic)
            assert R[b] != zero
            assert linked[0]+linked[1] == 8*R[b]
            assert cubics[0]+cubics[1] == (8-4*C)*R[b]
        values.append([str(8-4*C),str(-4*C),"8"])
    assert values == [["-32","-40","8"],["-42","-50","8"],["-10","-18","8"]]
    return {"block_cubic_quadratic_linked_factors":values,
            "basis_colors_checked":[1,12,13],
            "ordinary_sector_formula":"W_S rho(K_S b)",
            "equal_scalar_weights_at_color_level":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
