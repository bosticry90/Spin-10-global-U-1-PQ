# V951 result — the scalar quadratic changes the shared-weight test

Including the scalar two-point response of the same
gauge–scalar bubble makes the linked scalar Slavnov
coefficient independent of the scalar representation
Casimir. In each internal gauge sector it equals
W_S rho(K_S b). Summing equal H/M weights gives
8 W rho_b for Phi, Sigma and ordinary phi.

The separate cubic and quadratic coefficients are
(-32,-40), (-42,-50) and (-10,-18), respectively, in
their common stripped kernel units. The difference
is eight in all three blocks. Both frozen routes
check the exact generator matrices on three
distinguishing external colors per block. The
operator identity follows by the full double
commutator calculation.

The V949 restriction remains valid for a fixed
scalar quadratic. It no longer imposes distinct
weights on the linked color equation. Actual
finite B–scalar weights can depend on the scalar
reference mass, and the mixed scalar contact retains
a finite mass-dependent remainder. Neither equality
of these weights nor a compact common map has been
established. No numerical normalization is adopted.
Both routes share the model, software and authorship.
