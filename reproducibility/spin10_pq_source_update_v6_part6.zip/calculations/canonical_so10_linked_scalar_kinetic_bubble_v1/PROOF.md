# Linked scalar kinetic bubble and the common color coefficient

The same ordinary gauge–scalar two-edge kernel acts
on the seagull-cubic pair of V948 and on two physical
Bxx cubics. Keep their common stripped weight W_S
for internal gauge sector S. At a transverse BB
port the internal scalar derivative in the cubic
transfers to the exterior scalar with the same
sign as its direct derivative. The mixed Hessian
row is therefore 2 partial x^t rho_a in stripped
units. The seagull mixed Hessian with exterior B
color b is -x^t{rho_a,rho_b}, from the physical
quadratic gauge coupling.

At two bosonic vertices the log coefficient is
-1/4 for an ordered quadratic trace. The two
gauge/scalar block orders give -1/2. With two
cubic rows this yields the scalar wavefunction
matrix Z_S=-4 W_S A_S, where
A_S=-sum_(a in S) rho_a^2, using the ordinary
kinetic normalization (partial x)^t Z_S partial x/2.
For the cross seagull-cubic term both vertex orders
give the extra factor two. The skew scalar part
is 2 W_S R_S(b) in the V948 notation.

Keep the scalar driver fixed. Its variation of
the wavefunction term supplies the opposite
skew generator {Z_S,rho_b}/2 in the selected
derivative-ghost projection. Consequently

    2 W_S R_S(b) - {Z_S,rho_b}/2
       = -W_S sum_(a in S) [rho_a,[rho_a,rho_b]]
       = W_S rho(K_S b),

where K_S=-sum_(a in S) ad_a^2. The first equality
is a direct expansion of the three matrix
products; the second uses the joined representation.
It applies to every b. The executable checks both
side matrices with the exact generators on selected
light, broken-singlet and broken-nonsinglet controls
in each active scalar block.

The H and M adjoint sums give K_G=8 I. At equal
kernel weights the linked scalar coefficient is
therefore 8 W rho_b in all three blocks. Their
separate cubic and quadratic factors differ:
Phi (-32,-40), Sigma (-42,-50), and ordinary phi
(-10,-18). The difference is eight in each.
The species-weight restriction of V949 held the
ordinary scalar quadratic fixed. This linked
calculation removes that color restriction when
the quadratic from the same kernel is retained.

The actual scalar propagators have different
reference masses. Common color coefficients do
not imply common absolute finite values. The
mixed scalar collapse, relative sign to the gauge
source, heat-profile lengths, mass insertion
transport and compact switch powers remain
separate tests. Both routes share the action,
conventions, software and authorship.
