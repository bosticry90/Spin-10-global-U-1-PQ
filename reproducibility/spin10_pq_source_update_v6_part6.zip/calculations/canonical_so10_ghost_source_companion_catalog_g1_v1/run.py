from pathlib import Path
from hashlib import sha256
import ast,gc,gzip,importlib.util,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/ghost-source-companion-catalog-g1-v1-2026-11-07')
role=sys.argv[1];assert role in ['native','replay'];assert not (O/(role+'_capture.json')).exists()
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(p,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 assert len(blob)<10*1024**2
 with p.open('xb') as h:h.write(blob)
if not (O/'preparation.json').exists():
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='17c5d3f2721531c04a1587b1f500c7f637cbf559'
 names=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V807.md']
 for folder,files in [('canonical_so10_regulator_vertices_g1_recovery_v1',['validation_receipt.json','PROOF.md','roots.py','native_root_assemblies.json.gz','replay_root_assemblies.json.gz']),('canonical_so10_new_physical_returning_inventory_g1_recovery_v1',['validation_receipt.json','inventory.py','native_GF_common.json.gz','replay_GF_common.json.gz']),('canonical_so10_full_current_inventory_g1_recovery_v1',['validation_receipt.json']+[r+'_ordinary_'+state+'.json.gz' for r in ['native','replay'] for state in ['S1','U1_0','U1_1']]),('canonical_so10_physical_current_input_recovery_g1_v1',['validation_receipt.json']+[prefix+'ordinary_'+owner+'.json.gz' for prefix in ['native_v2_','replay_v4_'] for owner in ['gauge','scalar']]),('canonical_so10_gaussian_current_reduction_g1_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_regulator_free_inverse_g1_recovery_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_g1_consistency_companion_carriers_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_known_consistency_images_g1_v1',['validation_receipt.json','PROOF.md'])]:names+=['calculations/'+folder+'/'+n for n in files]
 for n in ['RECORD.md','catalog.py','run.py']:
  if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
  with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
 sp=importlib.util.spec_from_file_location('new_catalog_preparer_imports',O/'catalog.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
 for mod in list(sys.modules.values())+[m.m,m.m.v,m.v,m.w,m.J,m.w.A]:
  p=getattr(mod,'__file__',None)
  if p:
   pp=Path(p).resolve()
   if pp.is_relative_to(R) and not pp.is_relative_to(O):names.append(pp.relative_to(R).as_posix())
 for n in sorted(set(names)):assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
 for rr,prefix in [('native','native_v2_'),('replay','replay_v4_')]:
  raw=load(O.parent/'canonical_so10_regulator_vertices_g1_recovery_v1'/(rr+'_root_assemblies.json.gz'))['assemblies']
  roots=[{k:z[k] for k in ['state','family','g','u','raw_root','free_proof']} for z in raw];del raw;gc.collect()
  gf=load(O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(rr+'_GF_common.json.gz'))
  ordinary=[dict(owner='GF_original',g=0,u=0,quadratic_Taylor_half=gf['original_ordinary'])]+[dict(owner='GF_probe'+str(pr),g=0,u=1,quadratic_Taylor_half=gf['probe_ordinary'][pr]) for pr in [0,1]];del gf;gc.collect()
  for state,owner,u in [('S1','GF_original',0),('U1_0','GF_probe0',1),('U1_1','GF_probe1',1)]:ordinary.append(dict(owner=owner,g=1,u=u,quadratic_Taylor_half=load(O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1'/(rr+'_ordinary_'+state+'.json.gz'))['quadratic_Taylor_half']))
  for owner in ['gauge','scalar']:ordinary.append(dict(owner='physical_'+owner,g=1,u=0,quadratic_Taylor_half=load(O.parent/'canonical_so10_physical_current_input_recovery_g1_v1'/(prefix+'ordinary_'+owner+'.json.gz'))['quadratic_Taylor_half']))
  save(O/(rr+'_inputs.json.gz'),dict(roots=roots,ordinary=ordinary,classical_operands_only=True,old_current_or_returning_catalog_not_copied=True));del roots,ordinary;gc.collect()
 dump(O/'preparation.json',dict(base_HEAD=head,sha256={**{n:digest(R/n) for n in sorted(set(names))},**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
 C.mkdir(parents=True,exist_ok=False)
 with (C/'old_git_tree.txt').open('xb') as h:h.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'catalog.py'),role]);dump(O/(role+'_capture.json'),cap);dump(C/(role+'_capture.json'),cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
