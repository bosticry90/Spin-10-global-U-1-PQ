from pathlib import Path
from hashlib import sha256
import ast,json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/ghost-source-companion-catalog-g1-v1-2026-11-07')
mode=sys.argv[1];assert mode in ['source_grade','replay'];name='source_grade' if mode=='source_grade' else 'replay_master_v2';assert not (O/(name+'_capture.json')).exists()
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
if not (O/'master_v2_preparation.json').exists():
 for pn in ['preparation.json','master_preparation.json']:
  for n,h in json.loads((O/pn).read_bytes())['sha256'].items():assert digest(R/n)==h,n
 failed=json.loads((O/'native_master_capture.json').read_bytes());assert failed['exit_code']==124 and not failed['calculation_completed'] and failed['post_run_observations_qualified']
 for n in ['MASTER_CONTINUATION_V2.md','master_v2.py','source_grade.py','run_master_continuation.py']:
  if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
  with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
 dump(O/'master_v2_preparation.json',dict(sha256={p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cmd=[sys.executable,'-B',str(O/('source_grade.py' if mode=='source_grade' else 'master_v2.py'))]
if mode=='replay':
 r=json.loads((O/'source_grade_result.json').read_bytes());assert r['execution_state']=='COMPLETED' and r['M_gu1_normal_terms']==0
 cmd.append('replay')
cap=capture(cmd);dump(O/(name+'_capture.json'),cap);dump(C/(name+'_capture.json'),cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
