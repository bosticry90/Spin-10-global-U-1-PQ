from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/ghost-source-companion-catalog-g1-v1-2026-11-07')
role=sys.argv[1];assert role in ['native','replay'];assert not (O/(role+'_master_capture.json')).exists()
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
if not (O/'master_preparation.json').exists():
 for n,h in json.loads((O/'preparation.json').read_bytes())['sha256'].items():assert digest(R/n)==h,n
 for rr in ['native','replay']:
  cap=json.loads((O/(rr+'_capture.json')).read_bytes());assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
 pairs=[]
 for ch in ['aCC','JBCC','JLambdaCC']:
  a=O/('native_'+ch+'_catalog.json.gz');b=O/('replay_'+ch+'_catalog.json.gz');assert a.read_bytes()==b.read_bytes();pairs.append(dict(channel=ch,native=a.name,replay=b.name,sha256=digest(a)))
 pairfile=O/'catalog_pairs_frozen.json';pairdata=dict(pairs=pairs,scientific_acceptance='NOT_PERFORMED')
 if pairfile.exists():assert json.loads(pairfile.read_bytes())==pairdata
 else:dump(pairfile,pairdata)
 names=['calculations/canonical_so10_proper_slavnov_actual_operators_g1_v1/'+n for n in ['native_inputs.json.gz','replay_inputs.json.gz','validation_receipt.json','PROOF.md','collect_result.json']]
 owning=json.loads((R/'calculations/canonical_so10_proper_slavnov_actual_operators_g1_v1/collect_result.json').read_bytes())
 witness=[r for r in owning['artifacts'] if '_source_physical_' in r['file']]
 assert len(witness)==6
 for row in witness:
  p=R/'calculations/canonical_so10_proper_slavnov_actual_operators_g1_v1'/row['file'];assert digest(p)==row['sha256'] and row['case_calculation_completed_and_reconstruction_checked'];names.append(p.relative_to(R).as_posix())
 names+=['calculations/canonical_so10_physical_current_input_recovery_g1_v1/physical_v4.py','calculations/canonical_so10_proper_slavnov_source_chain_g1_v1/validation_receipt.json','calculations/canonical_so10_proper_slavnov_source_chain_g1_v1/PROOF.md','calculations/canonical_so10_same_parent_slavnov_g1_recovery_v1/validation_receipt.json','calculations/canonical_so10_chiral_probe_support/DERIVATION.md']
 for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
 for n in ['MASTER_RECORD.md','MASTER_PREPARATION_CORRECTION_V2.md','master.py','run_master.py','run_master_v2.py']:
  if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
  with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
 dump(O/'master_preparation.json',dict(sha256={**{n:digest(R/n) for n in names},**{p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'master.py'),role]);dump(O/(role+'_master_capture.json'),cap);dump(C/(role+'_master_capture.json'),cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
