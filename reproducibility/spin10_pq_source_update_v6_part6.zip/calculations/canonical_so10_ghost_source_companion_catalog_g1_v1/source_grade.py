from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('source_grade_master_algebra',O/'master.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
J=m.J;w=m.w;read=m.read;load=m.load;digest=m.digest
JB=lambda ww:sum(643<=n<823 for n,js in ww)

def save(name,z):
 blob=m.gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 assert len(blob)<=10*1024**2
 with (O/name).open('xb') as h:h.write(blob)
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))

def main():
 tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'master_v2_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 ordinary_audits=[];old=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';states=[]
 for role in ['native','replay']:
  inputs=load(O/(role+'_inputs.json.gz'));rows=[]
  for block in inputs['ordinary']:
   raw=block['quadratic_Taylor_half'];ids=[i for i,(ww,c) in enumerate(raw) if any(643<=n<823 for n,js in ww)]
   if ids:assert block['g']==1,'SOURCE_JB_ORDINARY_WITHOUT_POSITIVE_GRADE'
   rows.append(dict(owner=block['owner'],g=block['g'],u=block['u'],raw_terms=len(raw),raw_math_sha256=m.mh(J.decode(raw)),all_JB_raw_indices=ids))
  ordinary_audits.append(dict(route=role,blocks=rows));packet=load(old/(role+'_inputs.json.gz'));states.append({k:{n:J.decode(p) for n,p in z} for k,z in packet['states'].items()})
 assert states[0]==states[1]
 branches=[('Fu1_1','E0'),('Fu0_1','E1'),('F1','Eu0_1'),('F0','Eu1_1')];journal=[];B={};all_zero_partners=True
 for left,right in branches:
  for n in range(643):
   P=states[0][left][n];Q=states[0][right][n];lp={ww:c for ww,c in P.items() if JB(ww)};rp={ww:c for ww,c in Q.items() if JB(ww)}
   if (lp or rp) and P and Q:all_zero_partners=False
   row=dict(left=left,right=right,field=n,left_terms=len(P),right_terms=len(Q),left_JB_terms=len(lp),right_JB_terms=len(rp),left_math_sha256=m.mh(P),right_math_sha256=m.mh(Q),zero_partner=not P or not Q)
   if not lp and not rp:row['disposition']='NEITHER_OPERAND_HAS_FIXED_JB'
   elif not P or not Q:row['disposition']='JB_OPERAND_HAS_COMPLETE_ZERO_PARTNER'
   else:
    raw=J.mul(P,Q);selected={ww:c for ww,c in raw.items() if JB(ww)==1};J.add(B,selected);row.update(disposition='ACTUAL_SOURCE_PRODUCT',full_product=J.encode(raw),selected_one_JB=J.encode(selected))
   journal.append(row)
 B=J.clean(B);eligible,ej=m.eligible(B,2);T=w.scale(m.v.tangent(m.v.tangent(eligible)),J.constant(F(1,2)));selected,pj=m.project(T,2,True);currents,normal,pivots=m.normal_form(selected)
 a=save('source_grade_tables.json.gz',dict(schema='JBCC_GRADE_SOURCE_COMPLETION_V2',ordinary_audits=ordinary_audits,all_four_branch_643_port_dispositions=journal,actual_M_gu1_source_JB_classical_density=J.encode(B),T2_eligibility=ej,full_T2_half_eligible=J.encode(T),T2_projection=pj,selected_T2_master=J.encode(selected),currents=[J.encode(p) for p in currents],normal=J.encode(normal),exact_reconstruction=True,all_JB_bearing_pairs_have_complete_zero_partners=all_zero_partners,source_free_g1_kernels_cannot_reach_JBCC_by_actual_ordinary_grade=True))
 out=dict(schema='JBCC_ACTUAL_SOURCE_GRADE_AUDIT_V2',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',all2572_branch_port_dispositions=True,ordinary_JB_vertices_all_g1=True,all_JB_bearing_pairs_have_complete_zero_partners=all_zero_partners,M_gu1_JB_density_terms=len(B),M_gu1_selected_T2_terms=len(selected),M_gu1_normal_terms=len(normal),full_source_free_M_gu1_kernel_not_calculated=True,complete_target_support_not_global_kernel_claim=True,artifact=a,elapsed_after_imports=time.perf_counter()-tick)
 with (O/'source_grade_result.json').open('x',encoding='utf-8',newline='\n') as h:json.dump(out,h,sort_keys=True);h.write('\n')
 print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
