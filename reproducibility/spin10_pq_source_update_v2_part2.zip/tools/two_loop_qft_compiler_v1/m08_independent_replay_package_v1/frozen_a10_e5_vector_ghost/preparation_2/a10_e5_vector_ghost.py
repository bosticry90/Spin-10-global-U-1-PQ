"""Actual complete g^3 vector-pair/ghost tensor; no measured completion input."""
from collections import Counter,defaultdict
from a10_e5_vector_ghost_control import HERE,ROOT,OUT,BASE,read,s,g,xi,ETA,alphabet,register,canonical,rows
from a10_e5_gauge_source_partner import vertices as input_vertices
from a10_e5_auxiliary_vector import quartic_vertices
from a10_e5_derivative_gauge import replay_quartic
from a10_e5_nonminimal_source import IDS,H,M,cm,decode_typed,ANTI,zero,act,adjoints,linear
import a10_e5_quartic_algebra as ex
import a10_e5_vector_ghost_algebra as a

num=ex.coefficient


def collect(P,Q):
    for word,z in Q.items():P[word]=P.get(word,0)+z


def full_alphabet():
    w=alphabet();fields={**{f'Bp{i}_{mu}':(1,0,0) for i in IDS for mu in range(4)},
        **{f'Lp{i}':(2,0,0) for i in IDS},**{f'{pre}{i}':(1,1 if pre=='Cp' else -1,1) for pre in ['Cp','ap'] for i in IDS}}
    w.fields=fields;w.grades=fields;w.pairs=[];w.external={};w.p={n:z[2] for n,z in fields.items()}
    for h in H:
        for mu in range(4):register(w,f'Ap{h}_{mu}',(1,0,0))
    return w


def restore(P,w,scalar=False):
    out={}
    for mu in ([0] if scalar else range(4)):
        for word,z in P.items():
            collect(out,w.scale(w.mul(*(w.var(n+f'_{mu}' if n.startswith(('Bp','Ap')) else n,tuple(mu for k in jets)) for n,jets in word)),z*(1 if scalar else ETA[mu])))
    return canonical(out)


def tree(route,stage):
    old,oldw,V,maps,f,inventory=input_vertices(route,stage);S,GB,UB,GA,UA,X=V
    W,quartinv=quartic_vertices(route,old,oldw,maps,stage)
    # quartic_vertices already owns physical temporal labels; normalize them
    # before all4 restoration, rather than aligning canonical raw labels first.
    W0={}
    for word,z in W.items():collect(W0,oldw.scale(oldw.mul(*(oldw.var(n[:-2] if n.startswith(('Bp','Ap')) and n.endswith('_0') else n,j) for n,j in word)),z))
    raw=decode_typed(read(HERE/f'frozen_a10_e2_transport/{route}.json')['gauge_fixing_density']);Q={};R={};inv=Counter()
    for word,z in raw.items():
        ns=[n for n,j in word];poly=s.Poly(z,g,xi)
        for deg,value in poly.terms():
            if value:inv[str((len(word),deg,tuple(sorted('x' if n.startswith('x_') else n.rstrip('0123456789_') for n in ns)),sum(len(j) for n,j in word)))]+=1
        if len(word)==4:
            q=poly.coeff_monomial(g*xi);r=poly.coeff_monomial(g**2*xi)
            if q:Q[word]=q
            if r:R[word]=r
    assert len(Q)==648 and len(R)==418 and all(len(word)<=4 for word in raw),'FULL_GF_VERTEX_INVENTORY'
    pull=old.replace;Q=canonical(pull(Q,maps[-1]));R=canonical(pull(R,maps[-1]));w=full_alphabet()
    if route=='replay':
        expectedQ=replay_quartic(old,[F[12:,12:] for F in f[12:]])
        zero(old.add(Q,old.scale(expectedQ,-1)),'OWN_PHYSICAL10_QUARTET_BEFORE_LOOP');Q=expectedQ
    polys=[restore(oldw.add(GB,UB,GA,UA),w),restore(X,w,True),restore(Q,w,True),restore(canonical(W0),w),restore(R,w,True)]
    assert all(w.grade(P,(4,0,0)) for P in polys),'VG_FULL_VERTEX_TYPES'
    action=read(HERE/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json');ym=next(P for P in action['local_terms'] if P['term_id']=='gauge')
    assert ym['sector']=='GAUGE_KINETIC' and ym['density']['metric']=='diag(1,-1,-1,-1)' and 'f_plane' in str(ym) and '-1/4' in str(ym)
    return old,w,polys,maps,f,{'GF_inventory':dict(sorted(inv.items())),'tree_input_and_IBP_current':inventory,'full_quartic_inventory':quartinv,'physical_YM_AST':ym,
        'all_proper_g3_families':['XFFF_box','QFF_triangle','XFD_triangle','XFR_triangle','QD_bubble','QR_bubble'],
        'full_four_leg_counting_n3_plus_2n4_equals4':True,'two_quantum_incidences_per_proper_vertex':True,
        'no_higher_GF_or_physical_YM_vertex':True,'no_source_external_amplitude':True,'scalar_fermion_no_xi_or_ghost_quantum_edge_at_this_g_degree':True,
        'positive_dimensional_insertions_excluded_only_from_dimension_zero_UV':True,'no_prediction_zero_or_Ward_tensor_selects_graphs':True,
        'tensor_class_only_eta_and_one_k_no_epsilon_or_other_vector':True,'Lorentz_reduction_is_structural_not_sampling':True}


def reference(w,omit_transverse=False):
    names=list(w.fields);pos={n:i for i,n in enumerate(names)};G={};one=num(1)
    for i in IDS:
        width=ex.widthH if i<12 else ex.widthM
        for mu,nu in __import__('itertools').product(range(4),repeat=2):
            z=(0 if omit_transverse else -ETA[mu]*int(mu==nu))+(1-width)*int(mu==nu==0)
            if z:G[pos[f'Bp{i}_{mu}'],pos[f'Bp{i}_{nu}']]={(0,0):num(z)}
        b,l,c,d=[pos[n] for n in [f'Bp{i}_0',f'Lp{i}',f'Cp{i}',f'ap{i}']]
        G[b,l]={(0,0):num(s.I)};G[l,b]={(0,0):num(-s.I)};G[c,d]={(0,0):one};G[d,c]={(0,0):-one}
    return G,[w.p[n] for n in names]


def ym_literal(w,f,rho):
    names=list(w.fields);pos={n:i for i,n in enumerate(names)};Y={};Z={};background_zero=[]
    entries=[(i,b,j,num(z)) for b,F in enumerate(f) for (i,j),z in F.todok().items()]
    for mu in range(4):
        for nu in range(4):
            K={};bg={}
            for i,b,j,z in entries:
                if mu==rho:
                    key=(i,pos[f'Bp{j}_{nu}']);K[key]=a.add(K.get(key,{}),{(1,0,90+b):z})
                if nu==rho:
                    key=(i,pos[f'Bp{b}_{mu}']);K[key]=a.add(K.get(key,{}),{(1,0,90+j):z})
                if mu==nu==rho:bg[i]=a.add(bg.get(i,{}),{(2,0,*sorted([90+b,90+j])):z})
            K={key:P for key,P in K.items() if P};assert not any(bg.values()),'CONSTANT_SINGLE_AXIS_BACKGROUND_CURVATURE_BOSE_ZERO';background_zero.append(not any(bg.values()))
            if mu==nu:assert not K
            weight=num(-s.Rational(1,2)*ETA[mu]*ETA[nu]);by_a=defaultdict(list)
            for (i,j),P in K.items():by_a[i].append((j,P))
            for i in IDS:
                deriv=[(pos[f'Bp{i}_{nu}'],mu,1),(pos[f'Bp{i}_{mu}'],nu,-1)]
                for q,jet,sgn in deriv:
                    if jet!=0:continue
                    for j,P in by_a.get(i,[]):
                        Y[q,j]=a.add(Y.get((q,j),{}),a.scale(P,weight*num(-s.I*sgn)))
                        Y[j,q]=a.add(Y.get((j,q),{}),a.scale(P,weight*num(s.I*sgn)))
            KT={(j,i):P for (i,j),P in K.items()};Z=a.msum(Z,a.mscale(a.mm(KT,K),weight))
    return {key:P for key,P in Y.items() if P},Z,{'all16_internal_fieldstrength_pairs_evaluated':True,'constant_background_curvature_zero_after_Bose_sum':all(background_zero),
        'YM_quartic_Gram_not_omitted':True,'YM_source_is_literal_minus_quarter_F_squared':True}


def ym_physical(w,f,rho):
    pos={n:i for i,n in enumerate(w.fields)}
    # Multiple external colors can occupy one adjoint cell; collect, do not overwrite.
    A={}
    for b,F in enumerate(f):
        for (i,j),z in F.todok().items():A[i,j]=a.add(A.get((i,j),{}),{(1,0,90+b):num(z)})
    AA=a.mm(A,A);Y={};Z={}
    for (i,j),P in A.items():
        if rho==0:
            for sigma in range(1,4):Y[pos[f'Bp{i}_{sigma}'],pos[f'Bp{j}_{sigma}']]=a.scale(P,num(2*s.I*ETA[sigma]))
        else:
            for mu,nu in [(rho,0),(0,rho)]:Y[pos[f'Bp{i}_{mu}'],pos[f'Bp{j}_{nu}']]=a.scale(P,num(-s.I*ETA[rho]))
    for sigma in range(4):
        if sigma!=rho:
            for (i,j),P in AA.items():Z[pos[f'Bp{i}_{sigma}'],pos[f'Bp{j}_{sigma}']]=a.scale(P,num(ETA[rho]*ETA[sigma]))
    return Y,Z


def axis_vertices(w,V,f,rho,route,stage):
    names=list(w.fields);ext={f'Cp{i}':i for i in IDS};ext.update({f'ap{i}':45+i for i in IDS});ext.update({f'Bp{i}_{rho}':90+i for i in IDS});ext.update({f'Ap{h}_{rho}':135+h for h in H})
    matrices=[stage(f'axis{rho}_full315_Hessian_'+n,lambda P=P,degree=degree:a.hessian(P,w,names,ext,[num(int(mu==0)) for mu in range(4)],num,degree))
        for n,P,degree in zip(['F','X','Q','Dghost','R'],V,[(1,0),(0,1),(1,1),(2,0),(2,1)])]
    Y,Z,proof=stage(f'axis{rho}_literal_YM_cubic_and_quartic_Gram',lambda:ym_literal(w,f,rho));Yr,Zr=stage(f'axis{rho}_physical_adjoint_YM_operators',lambda:ym_physical(w,f,rho))
    assert not a.msum(Y,a.mscale(Yr,-1)) and not a.msum(Z,a.mscale(Zr,-1)),'OWN_YM_FULL_OPERATOR_CROSSCHECK_BEFORE_LOOP'
    if route=='replay':Y,Z=Yr,Zr
    matrices[0]=a.msum(matrices[0],Y);matrices[3]=a.msum(matrices[3],Z)
    return matrices,proof


def schur_families(V,G,p,stage):
    even=[i for i,z in enumerate(p) if not z];odd=[i for i,z in enumerate(p) if z];F,X,Q,D,R=V
    def b(A,rows_,cols_):return a.block(A,rows_,cols_)
    Ge=b(G,even,even);Go=b(G,odd,odd);Ep=a.mm(Ge,b(F,even,even));Ep2=stage('Gaussian_complete_two_cubic_even_inverse_pipe',lambda:a.mm(Ep,Ep));Dp=a.mm(Ge,b(D,even,even))
    O=a.mm(Go,b(F,odd,odd));W=a.mm(Go,b(D,odd,odd));Pq=a.mm(Go,b(Q,odd,odd))
    lg,lx,ld=[a.mm(Go,b(A,odd,even)) for A in [F,X,D]];rg,rx,rd=[a.mm(Ge,b(A,even,odd)) for A in [F,X,D]]
    pipe=lambda L,E,T:a.mm(a.mm(L,E),T)
    U1=a.mscale(a.msum(a.mm(lg,rx),a.mm(lx,rg)),-1)
    U2F=a.msum(pipe(lg,Ep,rx),pipe(lx,Ep,rg));U2D=a.mscale(a.msum(a.mm(ld,rx),a.mm(lx,rd)),-1)
    U3FF=a.mscale(a.msum(pipe(lg,Ep2,rx),pipe(lx,Ep2,rg)),-1)
    U3D=a.msum(pipe(ld,Ep,rx),pipe(lx,Ep,rd),pipe(lg,Dp,rx),pipe(lx,Dp,rg))
    tr=lambda *As:a.closed(As);I=num(s.I);out={}
    out['XFFF_box']=stage('Gaussian_box_all_even_inverse_and_odd_log_splits',lambda:a.add(a.scale(a.trace(U3FF),-I*num(s.Rational(1,2))),a.scale(a.add(tr(O,U2F),tr(U2F,O)),I*num(s.Rational(1,4))),a.scale(a.add(tr(O,O,U1),tr(O,U1,O),tr(U1,O,O)),-I*num(s.Rational(1,6)))))
    out['QFF_triangle']=stage('Gaussian_QFF_three_odd_log_splits',lambda:a.scale(a.add(tr(O,O,Pq),tr(O,Pq,O),tr(Pq,O,O)),-I*num(s.Rational(1,6))))
    out['XFD_triangle']=stage('Gaussian_XFD_complete_mixed_and_quartic_pipes',lambda:a.add(a.scale(a.trace(U3D),-I*num(s.Rational(1,2))),a.scale(a.add(tr(O,U2D),tr(U2D,O),tr(W,U1),tr(U1,W)),I*num(s.Rational(1,4)))))
    out['QD_bubble']=stage('Gaussian_QD_both_odd_log_splits',lambda:a.scale(a.add(tr(W,Pq),tr(Pq,W)),I*num(s.Rational(1,4))))
    # R's surviving no-jet Hessian coefficients already contain one a and C;
    # any X bridge adds another odd external leg. QR has no vector leg.
    for (i,j),P in R.items():assert p[i] and p[j] and all(len(word)==4 and word[2]<45 and 45<=word[3]<90 for word in P)
    out['XFR_triangle']=stage('Gaussian_full_R_X_external_degree_zero',lambda:a.add(tr(a.mm(Go,b(R,odd,odd)),U1)))
    out['QR_bubble']=stage('Gaussian_full_Q_R_no_vector_degree_zero',lambda:tr(Pq,a.mm(Go,b(R,odd,odd))))
    E=a.mm(Ge,a.msum(b(F,even,even),b(D,even,even)));power=E;evenlog={}
    for n in range(1,5):
        if n>1:power=a.mm(power,E)
        evenlog=a.add(evenlog,a.scale(a.trace(power),num(s.I*s.Rational((-1)**(n+1),2*n))))
    assert not a.selected(evenlog),'VG_UNREPORTED_EVEN_DETERMINANT'
    return {n:a.selected(P) for n,P in out.items()},{'complete_even_log_selected_zero_evaluated':True,'even_inverse_and_odd_log_orders':4,'all_g3_xi_splits_and_R_degree_zeros':True}


def schur_unit_controls(stage):
    from a10_e5_vector_ghost_control import model,EXT,FAMILIES,inverse,axis
    ctl=read(OUT/'controls.json');checks=[]
    for family in FAMILIES:
        for rho in [0,1]:
            w,Ps,degrees=model(family,rho,rho);names=list(w.fields);p=[w.p[n] for n in names];V=[{} for i in range(5)]
            for P,degree in zip(Ps,degrees):
                role=1 if degree==(0,1) else 2 if degree==(1,1) else 3 if degree==(2,0) else 0
                V[role]=a.msum(V[role],a.hessian(P,w,names,EXT,[num(int(mu==0)) for mu in range(4)],num,degree))
            G={}
            for i,x in enumerate(names):
                for j,y in enumerate(names):
                    z=inverse(x,y)
                    if z:
                        value=s.sympify(str(axis(z).as_expr()),locals={'width_X':ex.widthM,'width_Y':ex.widthH})
                        if value:G[i,j]={(0,0):num(value)}
            fam,details=schur_families(V,G,p,lambda n,f:f());actual=ex.D.to_sympy(a.add(*fam.values()).get((3,1,0,45,90,91),ex.D.zero))
            expected=s.sympify(ctl['axis_kernels'][family][0 if rho==0 else 5][2],locals={'width_X':ex.widthM,'width_Y':ex.widthH})
            assert s.expand(actual-expected)==0,('VG_GAUSSIAN_SCHUR_VS_ROUTED_WICK_UNIT',family,rho,actual,expected);checks.append([family,rho,str(actual)])
    return {'all14_primitive_graphs_both_axes_checked':checks,'independent_routed_Wick_and_full_Born_kernels_agree_with_Schur':True}


def formal_rows(P):
    return [[key[1],key[2],key[3]-45,key[4]-90 if key[4]<135 else key[4]-135,key[5]-90 if key[5]<135 else key[5]-135,
        'BB' if key[5]<135 else 'AB' if key[4]<135 else 'AA',str(ex.D.to_sympy(z))] for key,z in sorted(P.items())]


def build(route,stage):
    import sys
    from pathlib import Path
    sys.path.insert(0,str(ROOT/'tools'));from research_session_preflight import authenticate_bytes
    auth=stage('authenticate47_ancestor_chains_BYTES_ONLY',lambda:authenticate_bytes(ROOT,(HERE/'frozen_a10_e5_auxiliary_vector/bindings.json').relative_to(ROOT).as_posix()));assert auth['manifests_visited']==47
    def blind(event,args):
        if event=='open' and args and isinstance(args[0],(str,bytes)):
            path=Path(args[0].decode() if isinstance(args[0],bytes) else args[0])
            if any(n.startswith('frozen_a10_e5_') and n!='frozen_a10_e5_vector_ghost' for n in path.parts) and path.name.endswith('.json'):raise PermissionError('VG_ACTUAL_PRIOR_POLE_OR_COMPLETION_READ_DENIED')
            if path.parent==OUT and path.name in ['primary.json','replay.json','comparison.json']:raise PermissionError('VG_ACTUAL_PEER_READ_DENIED')
    sys.addaudithook(blind);ctl=read(OUT/'controls.json');assert ctl['status']=='CALCULATED_FULL16_VECTOR_GHOST_BORN_WICK_AND_AXIS_CONTROLS_AGREE'
    unit=stage('Gaussian_Schur_all_primitive_graphs_vs_frozen_full16_Born_Wick_controls',lambda:schur_unit_controls(stage))
    old,w,V,maps,f,inventory=tree(route,stage);axis={};program={};G,p=reference(w)
    for rho in [0,1]:
        mats,proof=axis_vertices(w,V,f,rho,route,stage)
        if route=='primary':poles=a.born(mats,G,p,num,stage);details={'Born_word_counts':[4,3,6,6,2,2]}
        else:poles,details=schur_families(mats,G,p,stage)
        axis[rho]=poles;program[str(rho)]={**details,**proof,'Hessian_nonempty_cells':[len(M) for M in mats],'full315_coordinates':True,'reference_nonempty_evaluated_axis_cells':len(G)}
    poles={n:a.scale(a.add(axis[0][n],a.scale(axis[1][n],-3)),num(s.I/2)) for n in axis[0]}
    total=a.add(*poles.values());formal={n:formal_rows(P) for n,P in poles.items()};source,anti,Cinv,Cphys,EM,EH,sub=maps;density={}
    eta=s.Symbol('eta_H',real=True)
    for row in formal_rows(total):
        power,c,ant,b,d,tag,text=row;z=s.expand(s.sympify(text,locals={str(ex.widthM):ex.widthM,str(ex.widthH):ex.widthH}).subs({ex.widthM:xi,ex.widthH:eta},simultaneous=True)*xi**power*g**3)
        for mu in range(4):
            for i in IDS:register(old,f'Bp{i}_{mu}',(1,0,0))
            for h in H:register(old,f'Ap{h}_{mu}',(1,0,0))
            ns=[f'Bp{b}_{mu}',f'Bp{d}_{mu}'] if tag=='BB' else [f'Bp{b}_{mu}',f'Ap{d}_{mu}'] if tag=='AB' else [f'Ap{b}_{mu}',f'Ap{d}_{mu}']
            collect(density,old.scale(old.mul(old.var(f'Cp{c}'),old.var(f'ap{ant}'),*(old.var(n) for n in ns)),ETA[mu]*z))
    density=canonical(density);assert old.grade(density,(4,0,0)) and all(s.Poly(z,g).monoms()==[(3,)] for z in density.values())
    assert all(not z.has(s.Float) and s.simplify(z-s.conjugate(z))==0 for z in density.values()),'VG_PHYSICAL_COEFFICIENT_REALITY'
    back={}
    for i in IDS:
        back[f'ap{i}']=old.add(*(old.scale(old.var(ANTI[j]),source.T[i,j]) for j in IDS if source.T[i,j]));back[f'Cp{i}']=old.add(*(old.scale(old.var(f'C{j}'),Cphys[i,j]) for j in IDS if Cphys[i,j]))
        for mu in range(4):back[f'Bp{i}_{mu}']=old.add(*(old.scale(old.var(f'B{j}_{mu}'),Cphys[i,j]) for j in IDS if Cphys[i,j]))
    for h in H:
        for mu in range(4):back[f'Ap{h}_{mu}']=old.add(*(old.scale(old.var(f'A{k}_{mu}'),Cphys[h,k]) for k in H if Cphys[h,k]))
    pull=old.replace;raw=canonical(pull(density,back));zero(old.add(pull(raw,sub),old.scale(density,-1)),'FULL_VECTOR_GHOST_CANONICAL_REAL_ROUNDTRIP')
    E=s.Matrix.hstack(EH,EM);parent=adjoints();checks=[]
    for h in H:
        T=cm(-E.T*linear(EH[:,h],parent)*E);images={f'{pre}{i}':old.add(*(old.scale(old.var(f'{pre}{j}'),T[i,j]) for j in IDS if T[i,j])) for pre in ['ap','Cp'] for i in IDS}
        for i in IDS:
            for mu in range(4):images[f'Bp{i}_{mu}']=old.add(*(old.scale(old.var(f'Bp{j}_{mu}'),T[i,j]) for j in IDS if T[i,j]))
        for i in H:
            for mu in range(4):images[f'Ap{i}_{mu}']=old.add(*(old.scale(old.var(f'Ap{j}_{mu}'),T[i,j]) for j in H if T[i,j]))
        zero(act(density,old,images,route,0),'ALL12_ACTUAL_VECTOR_GHOST_RIGID_H_'+str(h));checks.append(h)
    return {'schema':'E5_VECTOR_GHOST_ACTUAL_V1','route':route,'status':'CALCULATED_COMPLETE_SELECTED_VECTOR_GHOST_G3_POLE_ONLY',
        'axis_family_kernels':{str(rho):{n:formal_rows(P) for n,P in fam.items()} for rho,fam in axis.items()},'formal_family_poles':formal,'formal_actual_pole':formal_rows(total),
        'canonical_full_g_cubed_density':rows(raw),'physical_full_g_cubed_density':rows(density),'inventory':inventory,'program':program,
        'domain':{'BB_symmetric_slots':32987250,'AB_slots':17496000,'AA_symmetric_slots':2381400,'total_symmetric_slots':52864650,'all45_anti_and_ghost':True,'all45_B_12_A_and4_Lorentz':True,'identical_even_vectors_allowed':True},
        'all12_rigid_H_identities':checks,'Gaussian_unit_controls':unit,'exact_zero_channels_proved_from_complete_tensors':True,'formal_widths_no_degree_cutoff':True,'real_width_binding':{'reference_width_M':'xi','reference_width_H':'eta_H'},
        'candidate_peer_or_required_Ward_tensor_read_after_byte_authentication':False,'finite_IR_whole_scaleless_inferred':False,'full_E5_or_quantum_A5':False,'whole_goal_complete':False,'authority':'34/39_UNCHANGED',
        'shared_dependencies':['action and representation data','some exact arithmetic and external algebra','Python/SymPy','analyst']}
