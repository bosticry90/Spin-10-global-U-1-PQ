"""Four-vector-index Born/Wick controls for the zero-jet rank-two residue."""
from itertools import permutations,product
from a10_e5_gauge_source_partner_control import R,K,t,wx,wy,II,c,average
from a10_e5_auxiliary_vertex import HERE,ROOT,read,s,g,xi,ETA,alphabet,register,canonical,rows
import a10_e5_vector_ghost_algebra as a

OUT=HERE/'frozen_a10_e5_vector_ghost'
BASE='8a07e12f61350e1c6f488d0c52d7d23c676e156c'
EXT={'Ce':0,'aE':45,'Be1':90,'Be2':91}
FAMILIES=['box_GG','box_GU','box_GY','box_UU','box_UY','box_YY','triangle_QGG',
    'triangle_XGDoo','triangle_XUDeo','triangle_XYDeo','triangle_XGDee0','triangle_XGDee1','triangle_XGDee2','bubble_QDoo']


def inverse(x,y,epsilon=1,omit_transverse=False,omit_mixed=False,omit_reverse_odd=False):
    if x.startswith('B') and y.startswith('B') and x[1]==y[1]:
        mu,nu=int(x[2]),int(y[2]);width=wy if x[1]=='Y' else wx
        return (R.zero if omit_transverse else -c(ETA[mu]*int(mu==nu))*t)+(1-width)*K[mu]*K[nu]*t**2
    if x.startswith('B') and y=='L'+x[1]:return R.zero if omit_mixed else II*epsilon*K[int(x[2])]*t
    if y.startswith('B') and x=='L'+y[1]:return R.zero if omit_mixed else -II*epsilon*K[int(y[2])]*t
    if x.startswith('C') and y=='a'+x[1:]:return t
    if x.startswith('a') and y=='C'+x[1:]:return R.zero if omit_reverse_odd else -t
    return R.zero


def model(family,mu,nu):
    w=alphabet();w.fields={**{f'B{z}{rho}':(1,0,0) for z in ['X','Y','Z'] for rho in range(4)},
        **{f'L{z}':(2,0,0) for z in ['X','Y','Z']},**{f'{pre}{i}':(1,1 if pre=='C' else -1,1) for pre in ['C','a'] for i in range(3)}}
    w.grades=w.fields;w.pairs=[];w.external={};w.p={n:z[2] for n,z in w.fields.items()}
    for n,gr in [('Ce',(1,1,1)),('aE',(1,-1,1)),('Be1',(1,0,0)),('Be2',(1,0,0))]:register(w,n,gr)
    v=w.var;X=w.mul(v('LX'),v('a0'),v('Ce'))
    def oddG(spec,j):return w.add(*(w.scale(w.mul(v('aE'),v(f'B{spec}{rho}'),w.D(v(f'C{j}'),rho)),ETA[rho]) for rho in range(4)))
    def GG(i,j,Be,rho):return w.scale(w.mul(w.D(v(f'a{i}'),rho),v(Be),v(f'C{j}')),ETA[rho])
    def U(x,y,Be,rho):return w.scale(w.mul(v(f'L{y}'),v(f'B{x}{rho}'),v(Be)),ETA[rho])
    def Y(x,y,Be,rho):
        fields=[[v(Be) if n==rho else {} for n in range(4)],[v(f'B{y}{n}') for n in range(4)],[v(f'B{x}{n}') for n in range(4)]];out={}
        for order in permutations(range(3)):
            i,j,k=order;sign=(-1)**sum(b>d for h,b in enumerate(order) for d in order[h+1:])
            for r,q in product(range(4),repeat=2):out=w.add(out,w.scale(w.mul(w.D(fields[i][q],r),fields[j][r],fields[k][q]),-sign*ETA[r]*ETA[q]))
        return canonical(out)
    if family=='box_GG':Ps=[X,oddG('X',2),GG(1,0,'Be1',mu),GG(2,1,'Be2',nu)]
    elif family=='box_GU':Ps=[X,oddG('Y',1),GG(1,0,'Be1',mu),U('X','Y','Be2',nu)]
    elif family=='box_GY':Ps=[X,oddG('Y',1),GG(1,0,'Be1',mu),Y('X','Y','Be2',nu)]
    elif family=='box_UU':Ps=[X,oddG('Z',0),U('X','Y','Be1',mu),U('Y','Z','Be2',nu)]
    elif family=='box_UY':Ps=[X,oddG('Z',0),U('X','Y','Be1',mu),Y('Y','Z','Be2',nu)]
    elif family=='box_YY':Ps=[X,oddG('Z',0),Y('X','Y','Be1',mu),Y('Y','Z','Be2',nu)]
    elif family=='triangle_QGG':Ps=[w.mul(v('aE'),v('Ce'),v('a0'),v('C2')),GG(1,0,'Be1',mu),GG(2,1,'Be2',nu)]
    elif family=='triangle_XGDoo':Ps=[X,oddG('X',1),w.scale(w.mul(v('a1'),v('C0'),v('Be1'),v('Be2')),ETA[mu]*int(mu==nu))]
    elif family in ['triangle_XUDeo','triangle_XYDeo']:
        Ps=[X,U('X','Y','Be1',mu) if family=='triangle_XUDeo' else Y('X','Y','Be1',mu),w.scale(w.mul(v('aE'),v(f'BY{nu}'),v('Be2'),v('C0')),ETA[nu])]
    elif family.startswith('triangle_XGDee'):
        n=int(family[-1])
        D=w.add(*(w.scale(w.mul(v(f'BX{rho}'),v(f'BY{rho}'),v('Be1'),v('Be2')),ETA[mu]*ETA[rho]*int(mu==nu)) for rho in range(4))) if n==0 else w.scale(w.mul(v(f'BX{mu if n==1 else nu}'),v(f'BY{nu if n==1 else mu}'),v('Be1'),v('Be2')),ETA[mu]*ETA[nu])
        Ps=[X,oddG('Y',0),D]
    else:
        assert family=='bubble_QDoo';Ps=[w.mul(v('aE'),v('Ce'),v('a0'),v('C1')),w.scale(w.mul(v('a1'),v('C0'),v('Be1'),v('Be2')),ETA[mu]*int(mu==nu))]
    assert all(w.grade(P,(4,0,0)) for P in Ps),'VG_UNIT_TYPES'
    degrees=[(0,1) if i==0 and not family.startswith(('triangle_Q','bubble_Q')) else (1,1) if i==0 else (2,0) if len(Ps)==2 or (len(Ps)==3 and i==2 and not family.startswith('triangle_Q')) else (1,0) for i in range(len(Ps))]
    return w,Ps,degrees


def born(family,mu,nu,**opts):
    w,Ps,degrees=model(family,mu,nu);names=list(w.fields);p=[w.p[n] for n in names]
    G={(i,j):{(0,0):z} for i,x in enumerate(names) for j,y in enumerate(names) if (z:=inverse(x,y,**opts))}
    V=[a.hessian(P,w,names,EXT,K,c,degree) for P,degree in zip(Ps,degrees)]
    n=len(V);out=a.add(*(a.closed([a.mm(G,Q) for Q in order],p) for order in permutations(V)))
    return out.get((3,1,0,45,90,91),R.zero)*II*c(s.Rational((-1)**(n+1),2*n))


def pairings(legs):
    if not legs:yield [];return
    x=legs[0]
    for i,y in enumerate(legs[1:],1):
        if x[0]==y[0] or not inverse(x[1],y[1]):continue
        sign=(-1)**(x[3]*sum(z[3] for z in legs[1:i]))
        for rest in pairings(legs[1:i]+legs[i+1:]):yield [(x,y,sign)]+rest


def wick(family,mu,nu):
    w,Ps,degrees=model(family,mu,nu);orders=[]
    for ordered in permutations(Ps):
        out=R.zero
        for terms in product(*(list(P.items()) for P in ordered)):
            full=[];legs=[];external=[];value=R.one
            for vertex,(word,z) in enumerate(terms):
                value*=c(z)
                for pos,(name,jets) in enumerate(word):
                    token=(vertex,name,jets,w.p[name],pos);full.append(token)
                    if name in EXT:
                        external.append(EXT[name])
                        if jets:value=R.zero
                    else:legs.append(token)
            if not value:continue
            assert sorted(external)==[0,45,90,91] and all(sum(x[0]==v for x in legs)==2 for v in range(len(Ps)))
            crossing=(-1)**sum(x[3]*y[3] for i,x in enumerate(full) if x[1] not in EXT for y in full[i+1:] if y[1] in EXT)
            sorting=(-1)**sum(x>y and x<90 and y<90 for i,x in enumerate(external) for y in external[i+1:])
            for pairs in pairings(legs):
                edges={v:set() for v in range(len(Ps))}
                for x,y,sgn in pairs:edges[x[0]].add(y[0]);edges[y[0]].add(x[0])
                seen={0};pending=[0]
                while pending:
                    for v in edges[pending.pop()]-seen:seen.add(v);pending.append(v)
                if len(seen)!=len(Ps):continue # Connected log excludes disconnected products.
                routes=[]
                for eps in product([-1,1],repeat=len(pairs)-1):
                    es=(1,*eps)
                    if all(sum(e*(int(x[0]==v)-int(y[0]==v)) for e,(x,y,sgn) in zip(es,pairs))==0 for v in range(len(Ps))):routes.append(es)
                assert len(routes)==1,'VG_UNIQUE_CONNECTED_CYCLE'
                term=value*crossing*sorting
                for e,(x,y,sgn) in zip(routes[0],pairs):
                    term*=sgn*II*inverse(x[1],y[1],e)
                    for rho in x[2]:term*=II*e*K[rho]
                    for rho in y[2]:term*=-II*e*K[rho]
                out+=-II*(II**len(Ps))*term
        orders.append(out)
    assert all(P==orders[0] for P in orders),'VG_ALL_WICK_VERTEX_ORDERS'
    return orders[0]


def axis(P):return c(P.as_expr().subs({**{q.as_expr():int(i==0) for i,q in enumerate(K)},t.as_expr():1},simultaneous=True))


def double_longitudinal_YM():
    counts=[]
    for mu in range(4):
        w,Ps,degrees=model('box_GY',0,mu);names=list(w.fields)
        V=a.hessian(Ps[-1],w,names,EXT,K,c,(1,0));assert V;counts.append(len(V))
        for left,right in [('X','Y'),('Y','X')]:
            z=R.zero
            for i,j in product(range(4),repeat=2):z+=K[i]*K[j]*V.get((names.index(f'B{left}{i}'),names.index(f'B{right}{j}')),{}).get((1,0,91),R.zero)
            assert not z,'VG_FULL4_YM_DOUBLE_LONGITUDINAL_ENDPOINT'
    return {'all4_external_directions_both_endpoint_orders':True,'nonzero_YM_Hessian_cells':counts,'kernel_zero_from_full_contraction':True}


def controls(stage):
    proof=stage('full4_YM_double_longitudinal_zero_with_nonzero_Hessian',double_longitudinal_YM)
    values={};kernels={};axis_failure={};transverse_failure={};offdiag=False
    for family in FAMILIES:
        poles=[];raw=[]
        for mu,nu in product(range(4),repeat=2):
            A=stage(f'Born_{family}_{mu}_{nu}',lambda:born(family,mu,nu));B=stage(f'Wick_{family}_{mu}_{nu}',lambda:wick(family,mu,nu))
            assert A==B,'VG_UNIT_BORN_WICK_KERNEL_MISMATCH'
            av,bv=2*II*average(A,-4,'primary'),2*II*average(B,-4,'replay');assert av==bv
            if mu!=nu and A:offdiag=True
            poles.append([mu,nu,str(s.simplify(av.as_expr()))]);raw.append([mu,nu,str(s.simplify(axis(A).as_expr()))])
        parallel=s.sympify(raw[0][2]);spatial=s.sympify(raw[5][2]);reconstructed=s.simplify(2*s.I*(parallel-3*spatial)/4)
        assert all(s.simplify(s.sympify(z)-ETA[mu]*reconstructed)==0 if mu==nu else z=='0' for mu,nu,z in poles),'VG_AXIS_RANK_TWO_RECONSTRUCTION'
        if s.simplify(2*s.I*parallel-reconstructed)!=0:axis_failure[family]=str(s.simplify(2*s.I*parallel-reconstructed))
        wrong=2*II*average(born(family,0,0,omit_transverse=True),-4,'primary');full=s.sympify(poles[0][2])
        if s.simplify(wrong.as_expr()-full)!=0:transverse_failure[family]=str(s.simplify(wrong.as_expr()-full))
        values[family]=poles;kernels[family]=raw
    assert axis_failure and transverse_failure and offdiag,'VG_NONDISCRIMINATING_LORENTZ_CONTROLS'
    zero_classes=[name for name,P in values.items() if not any(z!='0' for mu,nu,z in P)]
    assert all(name in ['box_GY','box_UY'] for name in zero_classes),'VG_UNIT_GRAPH_KERNEL_UNEXPECTED_ZERO'
    return {'schema':'E5_VECTOR_GHOST_CONTROLS_V1','status':'CALCULATED_FULL16_VECTOR_GHOST_BORN_WICK_AND_AXIS_CONTROLS_AGREE',
        'unit_poles':values,'axis_kernels':kernels,'K00_only_nonzero_discrepancies':axis_failure,'transverse_omission_nonzero_discrepancies':transverse_failure,
        'all16_pairs_each_primitive_graph':True,'all_Wick_vertex_orders_and_connected_pairings':True,'full_four_internal_vector_directions':True,
        'evaluated_zero_primitive_classes':zero_classes,'double_longitudinal_YM_proof':proof,
        'nonzero_offdiagonal_kernel_zero_angular_residue':offdiag,'Gaussian_sphere_moments_agree':True,
        'rank_two_metric_and_one_momentum_tensor_class':'A*eta+B*k*k/k^2; no epsilon or other vector','heat_profiles':[8,6,4],
        'UV_domain':'k_E^2>R_UV^2>0','whole_scaleless_finite_IR_inferred':False,'candidate_or_measured_Ward_read':False,'whole_goal_complete':False}
