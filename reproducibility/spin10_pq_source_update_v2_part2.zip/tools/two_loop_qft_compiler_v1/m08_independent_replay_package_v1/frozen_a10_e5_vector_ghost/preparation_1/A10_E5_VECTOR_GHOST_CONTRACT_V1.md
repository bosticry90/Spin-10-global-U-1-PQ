# Actual g10^3 vector-pair/antighost/ghost investigation, VG V1

Prospective freeze at 8a07e12f61350e1c6f488d0c52d7d23c676e156c, before new
amplitude computation. Previous goal turn PROGRESS: AV actual poles close the
selected measured mixing Ward condition. Four known Ward target signatures
remain open. Whole Spin(10)xglobalU(1)PQ investigation remains active/incomplete.
project_state.json v113/34of39 is sole authority; no foundation or fitting change.

VG1 calculates the dimension-zero no-jet one-loop coefficient at explicit g10^3
for two commuting vector legs, one Grassmann-odd antighost and one odd ghost.
Both odd fields have dimension1, ghost numbers-1/+1. B/A_H even dimension1/gh0;
Lambda is an integrated EVEN dimension2/gh0 auxiliary, not BV J_Lambda. Density
is (4,0,even). Retain all45 antighost,45 ghost,45B and12A_H directions, all4
Lorentz components and all equal-vector Bose diagonals. Complete symmetric
domain: BB32,987,250, A_HB17,496,000, A_HA_H2,381,400; total52,864,650 slots.
No predicted zero, Ward tensor or failed candidate selects computed channels.

Immutable inputs:47 ancestor chains, complete literal GF/BV/physical action,
real normalized physical10 representations and separate primal/evaluation-dual
charts, full principal inverse, widths independent formal real polynomials.
Actual routes deny all prior E5 pole/candidate/required completion and peer reads
after ancestor BYTE authentication. Tree vertices, physical action/representation
records and owned elementary controls are allowed. Authentication does not
execute or scientifically accept historical calculations.

First recover and record the full literal coupling/field/jet vertex inventory.
Proper four-leg one-loop counting is n3+2*n4=4, with at least two integrated
incidences at each vertex. Let F be all g cubics (derivative ghost, auxiliary/
gauge and physical YM); X the xi auxiliary/ghost cubic; Q the g*xi four-ghost
quartic; D all g^2 quartics (BB/AB/AA ghost and physical YM); R the g^2*xi
curvature quartet. Screen ALL compatible words: XFFF boxes (four Xi positions),
QFF triangles (three Q positions), XFD triangles (six words), XFR triangles
(six words), QD bubbles (both words), QR bubbles (both words). Scalar/fermion/
mass/orbit alternatives and all higher vertices require explicit incidence,
coupling, principal-edge or positive-coefficient-dimension exclusions. If an
additional eligible class appears, include it or STOP before loop extraction.
Pure quantum scalar/fermion/YM loops cannot alone supply external ghosts at
g10^3; sources are absent only from this source-free selected amplitude. No
elimination of auxiliaries or false projected-M Jacobi is allowed.

Primary: literal graded Fourier Hessians and complete Born words with full
315 gauge/auxiliary/ghost coordinates, both odd orientations, mixed and full
transverse/longitudinal BB inverse. Recover physical YM cubic AND quartic from
the literal F=dB+g[B,B] action and its own actual normalized f table. Replay:
independent physical10 vertex reconstruction, own literal crosschecks before
loops, Gaussian even-field integration/odd Schur log or routed Wick. Include
quartic mixed even/odd blocks and all allowed external-leg assignments. Preserve
nonzero intermediates of any cancelled family; record independently established
zero classes and full AA/AB inventory. No old quartet longitudinal shortcut.

Lorentz reduction is an explicit structural proof, not a sampling approximation.
At zero external jets every colored rank-two integrand uses only eta and one
loop momentum k; the action/reference have no epsilon tensor or other vector.
After all contracted indices, its UV degree-4 kernel is A*eta_munu+B*k_mu*k_nu/k^2,
times (k^2)^-2. For k=(1,0,0,0) its parallel component is A+B and each spatial
diagonal is -A; all offdiagonals vanish there. Exact angular averaging gives
eta_munu*(A+B/4). Thus temporal pole=(K00-3*K11)/4, all spatial poles its negative
and offdiagonal poles zero. Retain all4 internal vector directions and transverse
BB pieces in BOTH axis calculations. Prove absence of additional tensors from
the full action/inverse inventory; compare the full16 elementary Born/routed-
Gaussian kernels and Gaussian/sphere angular moments against this reconstruction.
If a kernel violates this tensor class, STOP rather than extending the reduction
silently. Include negative controls for using K00 alone and omitting transverse.

A common fixed external axis rho has constant background curvature [B_rho,B_rho]=0
by full Bose symmetry, while internal transverse directions remain nonzero.
The primary quadratic YM expansion must retain every derivative/fieldstrength
cross term and quartic Gram term before this evaluated background identity.
The independent replay uses physical adjoint operator formulas and must agree
before the loop. Repeated even-vector words survive homogeneous multiplication.
Projection to one a, one C and two vector legs, and explicit g degree<=3, is
legitimate because discarded degrees cannot return under products. No component,
width or arithmetic-degree cutoff is allowed; resource limits mean INCOMPLETE.

UV is extracted on k_E^2>R_UV^2>0, homogeneous degree-4, heat profiles8/6/4 for
box/triangle/bubble, multiplier2I in32pi^2 units. Keep exact roots/I and formal
widths until the complete paired tensors; bind widthM=xi,widthH=real eta_H only
afterwards. Restore explicit g10^3 and every vertex xi power. Require full paired
family/total/zero tensor equality, all4 Lorentz/Bose factors, reality, full
canonical/physical roundtrip and all12 rigidH identities. Positive-dimensional
logs, power terms, momentum remainders, finite/IR/full-scaleless amplitudes are
separate obligations; no inverse-mass cancellation is inferred.

VG2 only AFTER all actual tensors agree: enlarge the current measured divergent
functional with these poles and evaluate the g10^3 B/a/C local-parameter Ward
subsystem over all45B/a/C,12parameters and all16 Lorentz pairs. Use separate
prefix and jet-gradient actions, full IBP currents and all12 parameter Eulers
without EOM. Check all enlarged known Ward targets, including any new A_H/a/C
component. A nonzero result owns its real signed Euler witness; preserve it and
STOP before fitting a candidate/image or calculating dependent higher sources.
Keep Gamma_unknown,Delta_b/s,contacts/insertions,measure/regulator/IR unbound.
Zero qualifies only the selected MEASURED condition, not full restoration.

Preserve GS selected Slavnov and GP/AV Ward scopes by actual support checks,
all1286 source columns and qualified deferred physical-Euler support proof;
do not set full physical Euler programs to zero. Preserve g10^3 quartet FAIL.
No candidate adjustment/adoption, source activation or authority promotion.
Negative controls: odd orientation/mixed/transverse omissions, wrong coupling,
wrong odd parity/evaluation-dual chart, Bose-diagonal nil error, missing graph,
false Lorentz-axis sampling, altered zero/background vertex, omitted parameter
jets/current or binding unknown complements to zero. Require nonzero exact
discrepancies or explicit type rejection, rather than weakening assertions.

Preserve exact attempts, source/preparation/start fingerprints and full stdout,
including FAILED/INCOMPLETE classifications. Validation requires four fresh
own-byte controls/primary/replay/comparison, meaningful science/process/governance
and delegatede5 checks,47 protected chains, new/protected/state/metadata invariance.
Custodyexit2/sevenrefs neverPASS; old expensive loops/images authenticate only.
Validate then compare raw index/worktree bytes before localcommit. No reset,
evidence editing, unrelated termination, physical fitting, HB1/C5/C1_GS/catalog
or finite matching, remote push/publication/outreach. Solo/shared action,
representations, some arithmetic/reference tools, Python/SymPy and analyst
disclosed. FullE5/W1-W7/A1-A5/equivalence/anomalies/IR and scalarPQ/fermionYukawa/
pheno remain open; whole goal not complete. Dependent JaBB/JaAB and JLBC/JLAC
actual loops require their next prospective contracts after this test.
