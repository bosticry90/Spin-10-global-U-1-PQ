"""Exact degree-graded external algebra; Bose vectors and odd a/C remain distinct."""
from collections import defaultdict
from functools import reduce


def odd(i):return i<90


def product(P,Q):
    out={}
    for a,u in P.items():
        for b,v in Q.items():
            gd,xd=a[0]+b[0],a[1]+b[1];word=a[2:]+b[2:]
            if gd>3 or sum(i<45 for i in word)>1 or sum(45<=i<90 for i in word)>1 or sum(i>=90 for i in word)>2:continue
            odds=[i for i in word if odd(i)]
            if len(set(odds))!=len(odds):continue
            sign=(-1)**sum(i>j for k,i in enumerate(odds) for j in odds[k+1:]);key=(gd,xd,*sorted(word))
            out[key]=out.get(key,0)+sign*u*v
            if not out[key]:del out[key]
    return out


def add(*Ps):
    out={}
    for P in Ps:
        for key,z in P.items():
            out[key]=out.get(key,0)+z
            if not out[key]:del out[key]
    return out


def scale(P,z):return {key:v*z for key,v in P.items() if v*z}


def mm(A,B):
    right=defaultdict(list);out={}
    for (k,j),P in B.items():right[k].append((j,P))
    for (i,k),P in A.items():
        for j,Q in right.get(k,[]):
            V=product(P,Q)
            if V:out[i,j]=add(out.get((i,j),{}),V)
    return {key:P for key,P in out.items() if P}


def msum(*As):
    out={}
    for A in As:
        for key,P in A.items():out[key]=add(out.get(key,{}),P)
    return {key:P for key,P in out.items() if P}


def mscale(A,z):return {key:scale(P,z) for key,P in A.items() if scale(P,z)}


def block(A,rs,cs):
    r={v:i for i,v in enumerate(rs)};c={v:i for i,v in enumerate(cs)}
    return {(r[i],c[j]):P for (i,j),P in A.items() if i in r and j in c}


def trace(A,p=None):return add(*(scale(P,(-1)**p[i] if p else 1) for (i,j),P in A.items() if i==j))


def closed(As,p=None):
    if p is not None:
        for A in As:
            for (i,j),P in A.items():assert all(sum(odd(k) for k in word[2:])%2==(p[i]+p[j])%2 for word in P),'VG_OPERATOR_PARITY'
    if len(As)==4:left=mm(As[0],As[1]);right=mm(As[2],As[3])
    else:left=reduce(mm,As[:-1]);right=As[-1]
    out={}
    for (i,k),P in left.items():
        if (k,i) in right:out=add(out,scale(product(P,right[k,i]),(-1)**p[i] if p else 1))
    return out


def selected(P):return {key:z for key,z in P.items() if key[0]==3 and len(key)==6 and key[2]<45 and 45<=key[3]<90 and 90<=key[4]<=key[5]}


def hessian(P,w,names,ext,k,num,degree):
    from a10_e2_transport_common import partials
    pos={n:i for i,n in enumerate(names)};out={}
    for (i,alpha),first in partials(P,w,set(names)).items():
        for (j,beta),Q in partials(first,w,set(names)).items():
            factor=num((-1)**(w.p[j]*(w.p[i]+1)))
            for mu in alpha:factor*=num(-__import__('sympy').I)*k[mu]
            for mu in beta:factor*=num(__import__('sympy').I)*k[mu]
            if not factor:continue
            for word,z in Q.items():
                if any(jets or n not in ext for n,jets in word):continue
                ids=[ext[n] for n,jets in word];odds=[a for a in ids if odd(a)];sgn=(-1)**sum(a>b for h,a in enumerate(odds) for b in odds[h+1:])
                key=(*degree,*sorted(ids));value=num(z)*factor*sgn
                if product({key:value},{(0,0):num(1)}):
                    cell=out.setdefault((pos[i],pos[j]),{});cell[key]=cell.get(key,0)+value
                    if not cell[key]:del cell[key]
    return {key:P for key,P in out.items() if P}


def born(V,G,p,num,stage):
    from itertools import permutations
    F,X,Q,D,R=V;a,b,c,d,r=[mm(G,Z) for Z in V]
    T=lambda *Z:closed(Z,p);I=num(__import__('sympy').I)
    out={}
    out['XFFF_box']=stage('all4_XFFF_complete_Born_words',lambda:scale(add(*(T(*([a]*i+[b]+[a]*(3-i))) for i in range(4))),-I*num(__import__('sympy').Rational(1,8))))
    out['QFF_triangle']=stage('all3_QFF_complete_Born_words',lambda:scale(add(T(a,a,c),T(a,c,a),T(c,a,a)),I*num(__import__('sympy').Rational(1,6))))
    for name,Z in [('XFD_triangle',d),('XFR_triangle',r)]:out[name]=stage('all6_'+name,lambda Z=Z:scale(add(*(T(*z) for z in permutations([a,b,Z]))),I*num(__import__('sympy').Rational(1,6))))
    for name,Z in [('QD_bubble',d),('QR_bubble',r)]:out[name]=stage('both_'+name,lambda Z=Z:scale(add(T(c,Z),T(Z,c)),-I*num(__import__('sympy').Rational(1,4))))
    return {n:selected(P) for n,P in out.items()}


def schur(V,G,p,num,stage):
    import sympy as s
    even=[i for i,z in enumerate(p) if not z];odd_=[i for i,z in enumerate(p) if z]
    Ge=block(G,even,even);Go=block(G,odd_,odd_);allV=msum(*V)
    EE=block(allV,even,even);EO=block(allV,even,odd_);OE=block(allV,odd_,even);OO=block(allV,odd_,odd_)
    inv=Ge;term=Ge
    for n in range(1,4):term=mscale(mm(mm(term,EE),Ge),-1);inv=msum(inv,term)
    U=stage('Gaussian_complete_even_inverse_and_odd_Schur_operator',lambda:msum(mm(Go,OO),mscale(mm(mm(mm(Go,OE),inv),EO),-1)))
    result={};power=U
    for n in range(1,5):
        if n>1:power=mm(power,U)
        result=add(result,scale(trace(power),num(-s.I/2)*num(s.Rational((-1)**(n+1),n))))
    # Even determinant is evaluated separately; it is not dropped by prediction.
    E=mm(Ge,EE);power=E;ev={}
    for n in range(1,5):
        if n>1:power=mm(power,E)
        ev=add(ev,scale(trace(power),num(s.I/2)*num(s.Rational((-1)**(n+1),n))))
    return selected(add(result,ev)),{'selected_even_log_terms':len(selected(ev)),'even_inverse_orders':4,'odd_log_orders':4,'all_complete_even_odd_Hessian_blocks_retained':True}
