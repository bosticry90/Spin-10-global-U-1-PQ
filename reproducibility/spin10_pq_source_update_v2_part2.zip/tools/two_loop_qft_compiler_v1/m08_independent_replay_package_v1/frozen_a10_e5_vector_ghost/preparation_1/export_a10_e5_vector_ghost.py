"""Exclusive source-gauge preparations and full attempt records."""
import json,os,subprocess,sys
from hashlib import sha256
from a10_e5_vector_ghost_control import HERE,ROOT,OUT,BASE

FILES=('a10_e5_vector_ghost_algebra.py','A10_E5_VECTOR_GHOST_CONTRACT_V1.md','a10_e5_vector_ghost_control.py','run_a10_e5_vector_ghost.py','export_a10_e5_vector_ghost.py')


def dump(path,value):
    with path.open('xb') as f:f.write(json.dumps(value,sort_keys=True,separators=(',',':')).encode()+b'\n')


def next_id(pattern):return max([int(p.stem.split('_')[-1]) for p in OUT.glob(pattern) if p.stem.split('_')[-1].isdigit()]+[0])+1


def prepare():
    OUT.mkdir(exist_ok=True);target=OUT/f'preparation_{next_id("preparation_*")}';target.mkdir()
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
    names=list(FILES)+[n for n in ['a10_e5_vector_ghost.py','a10_e5_vector_ghost_comparison.py'] if (HERE/n).exists()]
    for n in names:
        with (target/n).open('xb') as f:f.write((HERE/n).read_bytes())
    manifest=HERE/'frozen_a10_e5_auxiliary_vector/bindings.json'
    actual={n:sha256((OUT/(n+'.json')).read_bytes()).hexdigest() for n in ['primary','replay'] if (OUT/(n+'.json')).exists()}
    dump(target/'preparation.json',{'schema':'E5_VECTOR_GHOST_PREPARATION_V1','base_commit':BASE,
        'execution_bytes':{(HERE/n).relative_to(ROOT).as_posix():sha256((HERE/n).read_bytes()).hexdigest() for n in names},
        'input_manifest':manifest.relative_to(ROOT).as_posix(),'input_manifest_sha256':sha256(manifest.read_bytes()).hexdigest(),
        'state_sha256':sha256((ROOT/'project_state.json').read_bytes()).hexdigest(),
        'controls_sha256':sha256((OUT/'controls.json').read_bytes()).hexdigest() if (OUT/'controls.json').exists() else None,
        'completed_actual_sha256':actual if len(actual)==2 else {},'scientific_acceptance':'NOT_PERFORMED'})
    print('PREPARED '+target.name)


def main():
    route=sys.argv[1];assert route in ['prepare','controls','primary','replay','comparison']
    if route=='prepare':prepare();return
    assert not (OUT/(route+'.json')).exists(),'NO_OVERWRITE'
    prep=max(OUT.glob('preparation_*'),key=lambda p:int(p.name.split('_')[-1]))
    command=[sys.executable,'-B',str(HERE/'run_a10_e5_vector_ghost.py'),route,prep.name]
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(ROOT/'tools/pole_blind_validation_guard'))
    p=subprocess.Popen(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8')
    lines=[];result=metrics=start=None
    for line in p.stdout:
        lines.append(line)
        if line.startswith('RESULT '):result=json.loads(line[7:])
        else:
            print(line,end='',flush=True)
            if line.startswith('EXECUTION '):start=json.loads(line[10:])
            if line.startswith('METRICS '):metrics=json.loads(line[8:])
    code=p.wait();dump(OUT/f'{route}_attempt_{next_id(route+"_attempt_*")}.json',{'route':route,'command':command,'preparation':prep.name,
        'exit_code':code,'execution_state':'COMPLETED' if code==0 else 'FAILED','calculation_completed':code==0,'fingerprint':start,
        'stdout_and_stderr':''.join(lines),'scientific_acceptance':'NOT_PERFORMED','counted_as_validation_PASS':False})
    assert code==0 and result is not None and metrics is not None and not metrics['write_attempts']
    dump(OUT/(route+'.json'),result);dump(OUT/(route+'_metrics.json'),metrics);print('EXPORTED '+route)


if __name__=='__main__':main()
