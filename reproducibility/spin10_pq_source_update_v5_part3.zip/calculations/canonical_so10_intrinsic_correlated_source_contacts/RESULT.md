# A complete correlated contact and explicit remaining source-root obligations

PROGRESS from8e9b743934cf9bd4583946df62d026ad529c41c6,V628. This increment
measures the complete marginal rho JL JL C relative contact and two required
unprobed marginal roots. It also inventories the actual B1 C0 dependencies
of all three remaining source projections, rather than guessing their inputs.
The new coefficients are derived from the original action and regulated
one-loop construction. No unknown coefficient is fitted to a Ward target.

The contact is NONZERO:1114 full coefficient positions for probe1. The
associated ordinary auxiliary/source root is also nonzero. Their measured
contributions do not yet establish the complete remaining source identity.
Three quantum kernels needed for the rho JL Cx relation remain unmeasured.
Their actual operation matrices are now specified, not set to zero.

## Domain and authority ceiling

Original unshifted SMA/CSW/EDS,A0,constant first u/rho,externaljets0,
both probes,all45 gauge/source/ghost directions and328 real scalars,
symbolic g10/xi/eta_H. Source variation has one intrinsic coefficient degree1;
the new quadratic-source contact and marginal roots have intrinsic degree0.
Use the inherited nonexceptional Euclidean LOCAL RELATIVE DIM-minus-strict-
heat comparison. No physical scaleless p0 integral,massive vacuum limit,
absolute product prescription or physical finite scheme is adopted.
chi4 stays symbolic,distinct from b0,kappa and infrared freedom.

This is NOT full finite Slavnov restoration,QAP,quantum measure/global phase,
anomaly or physical unification. project_state.json is unchanged:state113,
authority34/39,E5/A5 OPEN. Flavor/HB1C5 remain blocked; protected scalar-
control/gauge-matching/benchmark failures and other physical obligations
remain in their qualified scopes. No foundation,benchmark or scheme change.

## ICR1: complete actual remaining B1 C0 root support

Every G/QG monomial and source degree0/1/2 was examined before target
restriction. Complementary subtraction vs independent local-root reverse
enumeration agrees,including retained routes,exclusions and exact graded
operation coefficients. These are classical operation routes,not quantum
amplitudes or independent invariant counterterms.

| Target projection | Probe0 root families/routes | Probe1 root families/routes |
| --- | --- | --- |
| rho JL Cx | 2 /24 | 6 /1554 |
| u Ja Cx | 2 /36 | 7 /6835 |
| u JL CCx | 0 /0 | 5 /12528 |

For rho JL Cx the actual six C0 root types are intrinsic C JL x,C a x,Ja x
and marginal C JL Ja,C JL Lambda,C Jx x. Ordinary,one-source and two-source
roots all occur. Source-dependent field flows cannot be omitted. The other
targets' complete types and actual references are retained in roots tables.
No allowed type is required to occur in both probes. Derivative and retained
polynomial-degree exclusions remain explicit,not a general-background theorem.

Euclidean source phases and left/right parity conversion follow the actual
graded cotangent rule,including odd rho placed before all sources and even u.
No desired ISD H/T/F coefficient was a native input.

## ICR2-3: complete ordered contact kernel,including four-edge terms

Frozen density is (rho/2) JL_s JL_r C_h T_srh with T_srh=-T_rsh.
All JL/C factors and rho are odd. For s<r the coefficient is T_srh,with no
additional half. Equal-source coefficients vanish by the exterior algebra.

Full proper-Hessian support has22 letters and22/56 ordered words for
probes0/1. Directed cycles vs multisets/permutations agree. The inventory
has4 two-edge,42 three-edge and32 four-edge words across both probes.
Source-only and one-port terms are preserved before their loop exclusions.
Maximum4 follows the target grades; it is not an arbitrary truncation.

The complete kernel uses direct rho-JL U/T vertices,original JL W/Z,
source-free rho current Jrho and ordinary external-ghost current J0.
The currents are left antighost Euler currents: mixed density order is
a rho Jrho b and a C_h J0_h b. The source parity matters. The independently
derived ghost potential contains rho j_s(U_s-Jrho G W_s) and
j_s C_h(Z_sh+J0_h G W_s).

The coefficient of rho j1 j2 C_h is

 C2=Tr(U1 Z2-U2 Z1),
 C3=Tr(U1 J0GW2-U2 J0GW1-JrhoGW1 Z2+JrhoGW2 Z1
       +J0GT1GW2-J0GT2GW1),
 C4=Tr(-JrhoGW1 J0GW2+JrhoGW2 J0GW1).

Literal paired-mode quarter-STrlog and boson-elimination/ghost determinant
agree in12 D3/4/5,first/last-axis and equal-source fixtures,including q±.
Generic heat coefficients are C2=-16,C3=33-64i,C4=28. Source exchange,
direct/Z/current/T omissions,auxiliary-current omission and incorrect T-half
controls are sensitive. Source-only/one-port omission is correctly insensitive.
The exact four-odd-variable algebra retains all exchange signs.

W auxiliary endpoints and momentum vertices exclude a closed Lorentz
spectator,so the fixed dimensional jet is0. Cartesian checks corroborate
that analytic support argument. Positive Frullani length4/6/8 comparisons
give the relative family

 chi4(C2+C3+C4)+log(3/2) C3+log2 C4.

The four-edge term has a distinct heat length and cannot be discarded on
generic grounds. No model coefficient was used to derive these kernels.

## ICR4-5: model contact and its actual source-Euler image

Primary45-component sparse paths vs replay full90 vector/auxiliary matrix
products agree on every coefficient and zero complement. Imported inputs
are actual action-derived vertices and currents from separately qualified
raw/canonical transports,not an expected contact tensor.

| Probe | C2 | C3_UJ0 | C3_JrhoZ | C3_T | C4 | Pole sum |
| --- | --- | --- | --- | --- | --- | --- |
| 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1 | 832 | 0 | 0 | 282 | 0 | 1114 |

Counts are full antisymmetric tensor positions; each tensor/probe has91125
possible positions,including equal-source zeros. C4 vanishes AFTER actual
contraction. It is not declared universally absent. Likewise the ordinary
auxiliary current is retained in every formula,but its isolated contribution
to this particular C3_T is zero. Model omission controls for these zero
contributions are insensitive; the generic tests are sensitive. No stronger
model sensitivity is claimed.

The actual contact passes all12 residual-H covariance operations,using
canonical beta,qC and the actual raw unbroken parameter chart. Both source
slots and the ghost slot participate. This is a nonzero tensor covariance
check,not merely an absent-polynomial test.

Source-free qJL=N0_Lx x lowers the contact to

 H_lower[r,h,i]=sum_s T_rsh N0_si.

A nonzero literal graded fixture fixes its sign and half. Direct index sums
vs flattened matrix products agree on all664200 positions per tensor/probe.
The actual N0 has296 nonzero entries. Probe1 lowered C2/C3/C4 counts are
6240/2496/0; chi4 image has8736 positions. Probe0 is zero. These are measured
contributions to the scalar source relation,not a completed identity.

## ICR6: two required marginal quantum roots now measured

The complete unprobed auxiliary Hessians are Lambda BB and Lambda aC,
derived previously from the actual gauge-fixing action. With ordinary T0/U0
and original JL W/Z,the marginal Lambda JL C root has

 Y2_arh=Tr(U0_a Z_rh),
 Y3_arh=Tr(U0_a J0_h G W_r+J0_h G T0_a G W_r).

Its density has no antisymmetric-source half: Lambda is an even ordinary
field,JL/C odd. This is a linear specialization of the generic correlated
kernel,checked by six additional literal Gaussian/Schur fixtures before
qualification. For Ja JL C use T0=0 and U0=A_original_source; Ja Lambda
is one-port,not a second boson Hessian.

| Root | C2 | C3_U | C3_T | Pole sum |
| --- | --- | --- | --- | --- |
| Lambda JL C | 776 | 0 | 282 | 1058 |
| Ja JL C | 0 | 0 | 0 | 0 |

Both methods agree across all91125 positions per root/heat and their zeros.
The zero Ja root was calculated,not supplied from a desired cancellation.
Relative roots retain chi4(Y2+Y3)+log(3/2)Y3 without fixing finite constants.

## ICR7: known terms integrated; three kernels remain

The actual G operation qLambda|rho x=rho E_ai x_i acts on the measured
Lambda JL C root. Its contribution is B_known[r,h,i]=sum_a Y_arh E_ai.
A nonzero graded fixture and independent index/matrix contractions verify
the sign and coefficient. The measured zero Ja JL C and earlier qualified
zero Ja x roots also remain in the dependency account.

For probe1 the following is the known partial sum H_hom+H_lower+B_known:

| Formal basis | B_known nonzero | Known partial H nonzero |
| --- | --- | --- |
| chi4 | 7424 | 11160 |
| log2 | 2496 | 12808 |
| log3 | 2496 | 8968 |
| log5 | 0 | 12432 |

All probe0 known terms vanish. This partial sum is NOT an anomaly or a
quantum failure: three actual required C0 kernels are still unmeasured.
They are intrinsic C JL x,intrinsic C a x and marginal C Jx x. Their
operation matrices have12/12/0 positions in probe0 and33/33/296 in probe1,
respectively. These matrices are fixed by G; their quantum kernel values
were not solved from the partial remainder.

The previous rho Ja x cancellation remains qualified in its separate scope.
The u Ja JL C and u JL JL CC marginal contact families are still unmeasured.
Full ISD T/F and complete H restoration remain unqualified. The new rho
contact is the third of the five identified quadratic-source TYPES covered;
that is not a percentage of quantum consistency or of E5 completion.

## Verification, failure record and AI-capability assessment

Original ICR1 primary/replay completed,but their exact comparison FAILED.
The replay used Python (-1)**negative_integer,which became a Float and
contaminated rational coefficients. It also prefiltered root dimensions
before recording derivative exclusions. Primary remained exact. Preserve
all original sources/copies/inputs/preparations/tables/captures and failed
verifier/controller. V2 reran only replay,reduced the parity exponent modulo2
before exponentiation and retained the same exclusions. No tolerance was
introduced. Full exact comparison then passed. The old failed comparison
has no qualification receipt and old Float tables are not scientific operands.

Demonstrated capabilities: complete type/loop inventories,exact graded
Gaussian/Schur comparison,nonzero covariant source contact,unfitted ordinary
quantum roots and explicit dependency reduction. Demonstrated weakness:
an avoidable exact-arithmetic/coefficient-serialization error and mismatched
diagnostic staging. Agreement still shares the action,coordinates,data,
helpers,libraries and AI authorship. It is computational corroboration,
not independent scientists,proof-assistant proof,experimental evidence or
validation of the model's physical premises.

Completed primary/replay seconds afterimports: root6.7984/8.1588 original,
corrected replay6.5166;support .9843/1.0464;kernel .8971/.7985;
contact33.1770/6.6314;marginal roots27.5861/6.4986. Lowering28.2583,
partial integration14.2524. Reviewer bounds180s,native300s,8GiB sampled,
350MiB launch floor,32MiB whole packet. Largest pre-final-review observed
private sample397180928B,not continuous peak. No exhaustion or truncated
capture. Exact sources,copies and inputs frozen before each computation.

E4 native0,steps[0,0,0,0,0,2],terminalCOMPLETED;authentication of existing
evidence,not a full fresh scientific replay. Historical custody remains
exit2/seven NOTPASS. All37620 old blobs and stateSHA
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8
are preserved. No branch/worktree,agent,remote push,publication,outreach,
foundation adoption,protected activation or state promotion.

## Next smallest authorized action

Construct the complete common unprobed kernel inventory for the three
remaining H roots. Start with marginal C Jx x: its scalar source and mixed
gauge-scalar operator may permit a compact Lie-representation reduction
before a large component expansion. Then measure the intrinsic C JL x/C a x
pair with every ordinary/source/auxiliary companion. Test actual operator
support and regulator heat factors,not an assumed zero or fitted identity.
The two remaining u quadratic-source contacts and general ordinary BBx
triangle remain separate subsequent obligations. Goal ACTIVE/INCOMPLETE.

This written result is frozen before the separate final interpretation and
custody review. No local commit or receipt substitutes for director scientific
acceptance or changes the sole machine-readable authority.
