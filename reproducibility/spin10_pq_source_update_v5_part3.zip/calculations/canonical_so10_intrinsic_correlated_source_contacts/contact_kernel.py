from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from fractions import Fraction as F
import ast,json,gzip,sys,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'contact_kernel_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
src=Path(read(O/'contact_kernel_inputs.json')['exact_helper_source']).read_text();tree=ast.parse(src);fn=['gc','add','scale','mm','ma','ms','const','tr','rat','fracadd','encode'];helpers=['ca','cm','cs','cz'];nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in fn or isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id in helpers for t in n.targets)];assert len(nodes)==len(fn)+len(helpers);ns={'s':s,'F':F,'defaultdict':defaultdict};exec(compile('\n\n'.join(ast.get_source_segment(src,n)for n in nodes),'<ICR3_bound_exact_helper_definitions_only>','exec'),ns)
def exterior(a,b):
 out={}
 for(m,e),v in a.items():
  for(n,f),w in b.items():
   if m&n:continue
   assert m<16 and n<16;sg=(-1)**sum(((m>>i)&1)*(n&((1<<i)-1)).bit_count()for i in range(4));k=m|n,e+f;out[k]=ns['ca'](out.get(k,(0,0)),ns['cs'](ns['cm'](v,w),sg))
 return{k:v for k,v in out.items()if ns['cz'](v)}
ns['mul']=exterior;gc,add,mm,const,tr,rat,fracadd,encode=[ns[k]for k in ['gc','add','mm','const','tr','rat','fracadd','encode']]
def data(D,axis,q,same=False,exchange=False,omit_aux=False):
 nb=2*D+2;K=s.zeros(nb);JR=s.zeros(2,nb);J0=s.zeros(2,nb);W=[];TT=[]
 jrb=s.I*s.Matrix([[1,2],[-1,3]]);jrl=s.Matrix([[2,1],[4,-1]]);j0b=s.I*s.Matrix([[2,-1],[3,2]]);j0l=s.zeros(2)if omit_aux else s.Matrix([[1,3],[-2,2]])
 for a,w in enumerate([2,3]):
  for mu in range(D):K[a*D+mu,a*D+mu]=0 if mu==axis else 1
  K[a*D+axis,2*D+a]=q;K[2*D+a,a*D+axis]=-q;K[2*D+a,2*D+a]=w
  for c in range(2):JR[c,a*D+axis]=q*jrb[c,a];JR[c,2*D+a]=jrl[c,a];J0[c,a*D+axis]=q*j0b[c,a];J0[c,2*D+a]=j0l[c,a]
 us=[s.I*s.Matrix([[1,-1],[2,3]]),s.I*s.Matrix([[2,1],[-1,2]])];zs=[s.I*s.Matrix([[2,1],[-3,2]]),s.I*s.Matrix([[1,4],[-2,3]])];ws=[s.Matrix([[1,-1],[2,1]]),s.Matrix([[-1,2],[3,1]])];ts=[s.Matrix([[2,1],[1,-1]]),s.Matrix([[1,-2],[-2,3]])]
 if same:us[1]=us[0];zs[1]=zs[0];ws[1]=ws[0];ts[1]=ts[0]
 if exchange:us=us[::-1];zs=zs[::-1];ws=ws[::-1];ts=ts[::-1]
 for wr,tt in zip(ws,ts):
  ww=s.zeros(nb,2);t=s.zeros(nb)
  for a in range(2):
   for c in range(2):
    ww[2*D+a,c]=wr[a,c]
    for mu in range(D):t[a*D+mu,c*D+mu]=tt[a,c]
  W.append(ww);TT.append(t)
 return K,JR,J0,W,TT,us,zs
def born(D,axis,same=False,exchange=False,omit_aux=False,omitU=False,omitZ=False,omitJR=False,omitJ0=False,omitT=False,wrongT=False,omit_classical=False):
 nb=2*D+2;ng=2;per=nb+4;dim=2*per;ext=[dim+i for i in range(4)];par=([0]*nb+[1]*4)*2;qfield=lambda mode,i:mode*per+i
 def hessian(terms):
  out={}
  def derivative(w,i):
   for at,v in enumerate(w):
    if v==i:yield w[:at]+w[at+1:],(-1)**(par[i]*sum(par[z]if z<dim else 1 for z in w[:at]))
  for co,w in terms:
   for i in set(v for v in w if v<dim):
    for ww,sg in derivative(w,i):
     for j in set(v for v in ww if v<dim):
      for zz,tg in derivative(ww,j):
       assert all(v>=dim for v in zz)
       if len(set(zz))!=len(zz):continue
       sign=sg*tg*(-1)**(par[j]*(par[i]+1)+sum(a>b for k,a in enumerate(zz)for b in zz[k+1:]));mask=sum(1<<(v-dim)for v in zz);out[i,j]=add(out.get((i,j),{}),{(mask,0):ns['cs'](co,sign)})
  return out
 K,*_=data(D,axis,1,same,exchange,omit_aux);free=[(gc(z),(qfield(1,i),qfield(0,j)))for(i,j),z in s.SparseMatrix(K).todok().items()];pert=[]
 for mode in [0,1]:
  other=1-mode;q=1 if mode==0 else-1;K,JR,J0,W,TT,U,Z=data(D,axis,q,same,exchange,omit_aux)
  for a in range(ng):free.append(((1,0),(qfield(other,nb+ng+a),qfield(mode,nb+a))))
  for source in range(2):
   if not omitU:
    for(a,c),z in s.SparseMatrix(U[source]).todok().items():pert.append((gc(z),(ext[0],ext[1+source],qfield(other,nb+ng+a),qfield(mode,nb+c))))
   if not omitZ:
    for(a,c),z in s.SparseMatrix(Z[source]).todok().items():pert.append((gc(z),(ext[1+source],ext[3],qfield(other,nb+ng+a),qfield(mode,nb+c))))
   for(j,c),z in s.SparseMatrix(W[source]).todok().items():pert.append((gc(z),(ext[1+source],qfield(mode,nb+c),qfield(other,j))))
   # The half sum of the two paired boson modes is this single ordered pair.
   if mode==0 and not omitT:
    for(i,j),z in s.SparseMatrix(TT[source]).todok().items():pert.append((gc(z*(2 if wrongT else 1)),(ext[0],ext[1+source],qfield(1,i),qfield(0,j))))
  for EE,M,omit in [(ext[0],JR,omitJR),(ext[3],J0,omitJ0)]:
   if not omit:
    for(a,j),z in s.SparseMatrix(M).todok().items():pert.append((gc(z),(qfield(other,nb+ng+a),EE,qfield(mode,j))))
 if not omit_classical:pert.extend([((3,0),tuple(ext)),((5,0),(ext[1],ext[3],qfield(0,2*D)))])
 H0=hessian(free);V=hessian(pert);K=s.SparseMatrix(dim,dim,{(i,j):s.Integer(v[0])+s.I*v[1]for(i,j),z in H0.items()for(mask,e),v in z.items()});G=const(K.inv(),1);M=mm(G,V);power=const(s.eye(dim));out={m:(F(0),F(0))for m in [2,3,4]}
 for n in range(1,5):
  power=mm(power,M);tt=tr(power,par)
  if n>=2:out[n]=rat(ns['cs'](tt.get((15,n),(0,0)),(-1)**(n+1)),4*n)
 return out
def schur(D,axis,same=False,exchange=False,omit_aux=False):
 out={m:(F(0),F(0))for m in [2,3,4]}
 for q in [1,-1]:
  K,JR,J0,W,T,U,Z=data(D,axis,q,same,exchange,omit_aux);G=K.inv();P=[JR*G*ws for ws in W];R=[J0*G*ws for ws in W];z={2:s.trace(U[0]*Z[1]-U[1]*Z[0]),3:s.trace(U[0]*R[1]-U[1]*R[0]-P[0]*Z[1]+P[1]*Z[0]+J0*G*T[0]*G*W[1]-J0*G*T[1]*G*W[0]),4:s.trace(-P[0]*R[1]+P[1]*R[0])}
  for m,v in z.items():out[m]=fracadd(out[m],rat(gc(s.expand(v)),2))
 return out
fixtures=[];first=None
for D in [3,4,5]:
 for axis in [0,D-1]:
  for same in [False,True]:
   a=born(D,axis,same)if role=='primary'else schur(D,axis,same);b=schur(D,axis,same)if role=='primary'else born(D,axis,same);assert a==b,(D,axis,same,a,b)
   if same:assert all(v==(0,0)for v in a.values())
   elif first is None:first=a
   else:assert a==first
   fixtures.append({'D':D,'axis':axis,'same_source_direction':same,'heat_coefficients':encode(a)})
assert all(v!=(0,0)for v in first.values());ex=born(3,0,exchange=True);assert all(ex[k]==tuple(-z for z in v)for k,v in first.items())
controls={}
for label,kwargs in [('omit_direct',{'omitU':True}),('omit_Z',{'omitZ':True}),('omit_rho_current',{'omitJR':True}),('omit_ordinary_current',{'omitJ0':True}),('omit_auxiliary_current',{'omit_aux':True}),('omit_T',{'omitT':True}),('wrong_T_half',{'wrongT':True})]:controls[label]=born(3,0,**kwargs)!=first
controls['source_exchange_changes_sign']=ex!=first;controls['collapse_box_m4_to_m3_loses_finite_log']=first[4]!=(0,0);controls['source_only_one_port_omission_insensitive']=born(3,0,omit_classical=True)==first;assert all(controls.values())
mp.mp.dps=70;errors=[]
for length,value in [(6,mp.log(mp.mpf(3)/2)),(8,mp.log(2))]:
 err=abs(mp.quad(lambda x:(mp.exp(-4*x)-mp.exp(-length*x))/x,[0,1,mp.inf])-value);assert err<mp.mpf('1e-65');errors.append(str(err))
out={'schema':'ICR3_COMPLETE_CORRELATED_SOURCE_GAUSSIAN_KERNEL','role':role,'fixtures':fixtures,'generic_heat_coefficients':encode(first),'controls':controls,'exact_four_odd_external_algebra':True,'Frullani_errors':errors,'all_source_only_one_port_terms_retained_before_Hessian':True,'fixed_dimensional_term':'0_by_longitudinal_W_endpoint_support','relative':'chi4(C2+C3+C4)+log(3/2)C3+log2 C4','density':'rho/2 JL_s JL_r C_h T_srh;T antisymmetric','model_quantum_inputs_used':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('contact_kernel_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'fixtures':len(fixtures),'generic_heat_coefficients':encode(first),'controls':controls},sort_keys=True),flush=True);timer.cancel()
