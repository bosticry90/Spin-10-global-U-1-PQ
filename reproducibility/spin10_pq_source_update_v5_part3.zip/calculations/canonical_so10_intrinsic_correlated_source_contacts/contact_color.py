from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'contact_color_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('contact_color_'+('replay'if role=='primary'else'primary')):raise PermissionError('ICR4_PEER_DENIED')
  if p.parent.name=='canonical_so10_intrinsic_full_source_descent'and p.name.startswith('variation'):raise PermissionError('ICR4_DESIRED_SOURCE_IMAGE_DENIED')
sys.addaudithook(guard)
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.expand(s.sympify(z,locals=loc))
cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v)for i,j,v in z['entries']});tab=lambda z:{tuple(q[:-1]):parse(q[-1])for q in z};clean=lambda z:{k:s.expand(v)for k,v in z.items()if s.expand(v)!=0};enc=lambda z:[[*k,str(v)]for k,v in sorted(clean(z).items())]
d=load(O/('contact_color_'+role+'_inputs.json.gz'));bb=tab(d['W']);W=[s.SparseMatrix(45,45,{(a,c):v for(rr,a,c),v in bb.items()if rr==r})for r in range(45)];Z0=tab(d['Z0']);G=dec(d['G0']);J0=list(map(dec,d['J0']));assert not cl(G[45:,45:]).todok();assert not cl(G[:45,45:]+s.eye(45)).todok()and not cl(G[45:,:45]-s.eye(45)).todok();width=G[:45,:45];assert all(i==j for i,j in width.todok());WG=[s.SparseMatrix(90,45,{(45+a,c):v for(a,c),v in M.todok().items()})for M in W]
def multiply(X,Y):
 if role=='replay':return cl(X*Y)
 by=defaultdict(list);out=defaultdict(lambda:0)
 for(k,j),v in Y.todok().items():by[k].append((j,v))
 for(i,k),v in X.todok().items():
  for j,z in by[k]:out[i,j]+=v*z
 return cl(s.SparseMatrix(X.rows,Y.cols,dict(out)))
def traces(X,Y):
 if role=='replay':
  n=X[0].rows;m=X[0].cols;xx=s.SparseMatrix(45,n*m,{(r,a*m+c):v for r,M in enumerate(X)for(a,c),v in M.todok().items()});yy=s.SparseMatrix(n*m,45,{(a*m+c,r):v for r,M in enumerate(Y)for(c,a),v in M.todok().items()});return cl(xx*yy)
 out={}
 for r,MM in enumerate(X):
  for t,NN in enumerate(Y):
   dd=NN.todok();v=s.expand(sum((v*dd.get((c,a),0)for(a,c),v in MM.todok().items()),s.Integer(0)))
   if v:out[r,t]=v
 return s.SparseMatrix(45,45,out)
GW=[multiply(G,M)for M in WG];results=[];keys=['C2','C3_UJ0','C3_JrhoZ','C3_T','C4','C3','pole']
for probe,p in enumerate(d['rho']):
 Ttab=tab(p['T']);Utab=tab(p['U']);T=[s.SparseMatrix(45,45,{(a,b):v for(rr,a,b),v in Ttab.items()if rr==r})for r in range(45)];U=[s.SparseMatrix(45,45,{(a,c):v for(rr,a,c),v in Utab.items()if rr==r})for r in range(45)];JR=dec(p['Jrho']);P=[multiply(JR,gg)for gg in GW]if role=='replay'else[cl(-multiply(JR[:,:45],ww))for ww in W];out={k:{}for k in keys};ctrl=[]
 for h in range(45):
  Z=[s.SparseMatrix(45,45,{(a,c):v for(rr,hh,a,c),v in Z0.items()if rr==r and hh==h})for r in range(45)]
  if role=='primary':
   R=[cl(-multiply(J0[h][:,:45],ww))for ww in W];K=cl(multiply(J0[h][:,:45],width)+J0[h][:,45:]);WK=[multiply(ww,K)for ww in W];tpart=cl(-traces(T,WK))
  else:
   R=[multiply(J0[h],gg)for gg in GW];JJ=multiply(J0[h],G);Q=[multiply(gg,JJ)for gg in GW];TT=[s.SparseMatrix(90,90,{(a,b):v for(a,b),v in mm.todok().items()})for mm in T];tpart=traces(TT,Q)
  antisym=lambda M:cl(M-M.T);C2=antisym(traces(U,Z));C3a=antisym(traces(U,R));C3b=antisym(cl(-traces(P,Z)));C3t=antisym(tpart);C4=antisym(cl(-traces(P,R)));C3=cl(C3a+C3b+C3t);pole=cl(C2+C3+C4)
  for k,M in zip(keys,[C2,C3a,C3b,C3t,C4,C3,pole]):
   assert not cl(M+M.T).todok()and all(M[i,i]==0 for i in range(45))
   for(r,t),v in M.todok().items():out[k][r,t,h]=v
  ctrl.append({'h':h,'omit_T_changes_positions':len(C3t.todok()),'omit_rho_current_changes_positions':len(cl(C3b+C4).todok()),'omit_box_loses_log2_positions':len(C4.todok()),'omit_direct_changes_positions':len(C2.todok())})
 results.append({'probe':probe,'heat_and_group_tensors':{k:enc(z)for k,z in out.items()},'relative':{'chi4':enc(out['pole']),'log3_over2':enc(out['C3']),'log2':enc(out['C4']),'fixed':[]},'controls':ctrl});print('STAGE ICR4',role,probe,{k:len(z)for k,z in out.items()},flush=True)
out={'schema':'ICR4_COMPLETE_RHO_JL_JL_C_MODEL_RELATIVE_CONTACT','role':role,'results':results,'all_positions_per_tensor_probe':45**3,'density':'rho/2 JL_s JL_r C_h T_srh;T antisymmetric','common_normalization':'hbar/(16pi^2)','all_equal_source_and_zero_complement_retained':True,'QAP_E5_A5_or_global_source_identity_inferred':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('contact_color_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'probe_heat_group_positions':[[len(z['heat_and_group_tensors'][k])for k in keys]for z in results]},sort_keys=True),flush=True);timer.cancel()
