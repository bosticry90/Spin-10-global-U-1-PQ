from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'partial_H_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.expand(s.sympify(z,locals=loc))
cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);tab=lambda z:{tuple(q[:-1]):parse(q[-1])for q in z};clean=lambda z:{k:s.expand(v)for k,v in z.items()if s.expand(v)!=0};enc=lambda z:[[*k,str(v)]for k,v in sorted(clean(z).items())]
def plus(terms):
 z=defaultdict(lambda:0)
 for dd,f in terms:
  for k,v in dd.items():z[k]+=f*v
 return clean(z)
# Q on Lambda JL C: only qLambda=rho*x contributes the desired type.
# Moving x across the two odd factors has no sign: 3*5=+15.
rho,JL,C,x,L=0,1,2,3,4;ww=(rho,x,JL,C);sg=(-1)**sum(a in[0,1,2]and b in[0,1,2]and a>b for j,a in enumerate(ww)for b in ww[j+1:]);assert sg==1 and 3*5*sg==15
data=load(O/'roots_primary_inputs.json.gz')['audit'];names=data['names'];geo=data['geometry'];base=geo['names'];sources={base[J]:base[f]for f,J,h,k in geo['field_source_h_k']};aux=[('b'if i<12 else'L')+str(i)for i in range(45)];ants=[('bar'if i<12 else'ub')+str(i)for i in range(45)];xs=[f'x_{sec}_{i}'for sec,n in [('Phi',54),('Sigma',252),('phi',20),('S',2)]for i in range(n)];ai={n:i for i,n in enumerate(aux)};bi={n:i for i,n in enumerate(ants)};xi0={n:i for i,n in enumerate(xs)};jli={n:ai[f]for n,f in sources.items()if f in ai};jai={n:bi[f]for n,f in sources.items()if f in bi};jxi={n:xi0[f]for n,f in sources.items()if f in xi0};rr=load(O/'roots_primary_tables.json.gz')['results'][0]['probes'];root=load(O/'auxiliary_roots_primary_tables.json.gz')['results'];assert root[0]['root']=='Lambda_JL_C'and root[1]['root']=='Ja_JL_C'and not root[1]['heat_and_group_tensors']['pole'];Y2=tab(root[0]['heat_and_group_tensors']['C2']);Y3=tab(root[0]['heat_and_group_tensors']['C3']);Y={'chi4':plus([(Y2,1),(Y3,1)]),'log2':plus([(Y3,-1)]),'log3':Y3,'log5':{}};low=load(O/'lowering_tables.json.gz');out=[]
for probe,pr in enumerate(rr):
 E=defaultdict(lambda:0);pending={key:defaultdict(lambda:0)for key in ['C_JL_x','C_a_x','C_Jx_x']};zeros=defaultdict(int)
 for r in pr['routes']:
  ty=r['root'];output=r['flow_output'];rem=r['flow_remaining_word'];v=parse(r['operation_coefficient'])
  if ty==['C','JL','L']:
   assert output in ai and len(rem)==1 and rem[0][0]in xi0;E[ai[output],xi0[rem[0][0]]]+=v
  elif ty==['C','JL','Ja']:zeros['Ja_JL_C_measured_zero']+=1
  elif ty==['Ja','x']:zeros['Ja_x_qualified_zero']+=1
  else:
   assert len(rem)==1 and rem[0][0]in jli;src=jli[rem[0][0]]
   if ty==['C','JL','x']:assert output in jli;pending['C_JL_x'][jli[output],src]+=v
   elif ty==['C','a','x']:assert output in bi;pending['C_a_x'][bi[output],src]+=v
   elif ty==['C','Jx','x']:assert output in jxi;pending['C_Jx_x'][jxi[output],src]+=v
   else:raise AssertionError(('unaccounted_H_root',ty))
 E=clean(E);EE=s.SparseMatrix(45,328,E);per=[]
 for basis,yy in Y.items():
  direct=defaultdict(lambda:0)
  for(a,r,h),v in yy.items():
   for(aa,i),z in E.items():
    if aa==a:direct[r,h,i]+=v*z
  direct=clean(direct);YY=s.SparseMatrix(45,45*45,{(a,r*45+h):v for(a,r,h),v in yy.items()});mat=cl(EE.T*YY);matrix={(rh//45,rh%45,i):v for(i,rh),v in mat.todok().items()};assert matrix==direct
  old=next(z for z in low['results'][probe]['formal_basis']if z['basis']==basis);before=tab(old['homogeneous_H_plus_contact_lowering']);knownsum=plus([(before,1),(direct,1)]);per.append({'basis':basis,'measured_marginal_BrhoC0':enc(direct),'known_partial_H':enc(knownsum),'all_three_pending_root_kernels_not_zeroed':True})
 out.append({'probe':probe,'qLambda_rho_x_E':enc(E),'zero_root_routes':dict(zeros),'pending_operation_matrices':{k:enc(v)for k,v in pending.items()},'formal_basis':per});print('STAGE ICR7',probe,[(p['basis'],len(p['measured_marginal_BrhoC0']),len(p['known_partial_H']))for p in per],flush=True)
z={'schema':'ICR7_KNOWN_H_CONVERSION_TERMS_AND_PENDING_ROOT_OPERATORS','results':out,'literal_sign_fixture_and_both_contractions_pass':True,'all_positions_per_probe_basis':664200,'actual_unmeasured_roots':['intrinsic C JL x','intrinsic C a x','marginal C Jx x'],'unmeasured_inputs_not_solved_from_partial_remainder':True,'full_H_identity_anomaly_QAP_E5_A5':False};raw=(json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'partial_H_tables.json.gz').open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'probe_basis_known_B_and_remainder_positions':[[[q['basis'],len(q['measured_marginal_BrhoC0']),len(q['known_partial_H'])]for q in p['formal_basis']]for p in out],'pending_operation_matrix_positions':[{k:len(v)for k,v in p['pending_operation_matrices'].items()}for p in out],'no_complete_H_restoration_or_anomaly_inferred':True},sort_keys=True),flush=True);timer.cancel()
