from pathlib import Path
from hashlib import sha256
import json,gzip,time
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter()
for p,h in read(O/'contact_support_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('contact_support_'+r+'_tables.json.gz'))for r in ['primary','replay']]
for z in [a,b]:z.pop('role')
assert a==b
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'directed_walks_vs_multisets_permutations_all_words_and_zeros_agree':True,'letters':len(a['letters']),'word_counts':[len(q['ordered_words'])for q in a['results']],'families':[q['families']for q in a['results']],'typed_support_not_model_measurement':True},sort_keys=True),flush=True)
