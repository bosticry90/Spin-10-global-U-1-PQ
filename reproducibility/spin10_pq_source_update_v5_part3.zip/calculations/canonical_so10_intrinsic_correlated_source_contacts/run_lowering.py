from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-correlated-source-contacts-v1-2026-10-25');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'contact_color_validation_preparation.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 for n in ['contact_color_validation_preparation.json','contact_color_validation_receipt.json','contact_color_verify_capture.json']:p=O/n;b[str(p)]=H(p)
 D=O.parent/'canonical_so10_intrinsic_full_source_descent';E=O.parent/'canonical_so10_intrinsic_auxiliary_ghost_source';ip={'maps':str(D/'map_primary_tables.json.gz'),'frame':str(D/'map_primary_inputs.json.gz'),'Euler':str(E/'vertex_primary_inputs.json.gz'),'late_H':{k:str(D/('variation_v3_'+k+'_primary_tables.json.gz'))for k in ['chi4','log2','log3','log5']}};dump(O/'lowering_inputs.json',ip)
 for p in [Path(ip[k])for k in ['maps','frame','Euler']]+[Path(v)for v in ip['late_H'].values()]+[O/'lowering_inputs.json']:b[str(p)]=H(p)
 for n in ['LOWERING_RECORD.md','lowering.py','run_lowering.py']:
  p=O/n;cp=O/(n+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(cp)]=H(cp)
 dump(O/'lowering_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
 z=capture([sys.executable,'-B',str(O/'lowering.py')]);dump(O/'lowering_capture.json',z);dump(C/'lowering_full_capture.json',z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
 rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<180;dump(O/'lowering_validation_receipt.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2;print(json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'lowering_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
