from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'lowering_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.expand(s.sympify(z,locals=loc))
cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v)for i,j,v in z['entries']});tab=lambda z:{tuple(q[:-1]):parse(q[-1])for q in z};clean=lambda z:{k:s.expand(v)for k,v in z.items()if s.expand(v)!=0};enc=lambda z:[[*k,str(v)]for k,v in sorted(clean(z).items())]
# A nonzero literal odd-polynomial fixture verifies the density half/sign.
odd={0,1,2,3};word=(0,1,2,3);flows={1:{(4,):7},2:{(4,):11}};got=defaultdict(lambda:0)
for at,a in enumerate(word):
 for w,v in flows.get(a,{}).items():
  ww=word[:at]+w+word[at+1:];sg=(-1)**(sum(z in odd for z in word[:at])+sum(a in odd and b in odd and a>b for j,a in enumerate(ww)for b in ww[j+1:]));got[tuple(sorted(ww))]+=3*sg*v
assert dict(got)=={(0,2,3,4):-21,(0,1,3,4):33}
ip=read(O/'lowering_inputs.json');m=load(Path(ip['maps']));f=load(Path(ip['frame']));xs=f['xs'];frame=f['frame'];aux=[('b'if i<12 else'L')+str(i)for i in range(45)];cs=['C'+str(i)for i in range(45)];ants=[('bar'if i<12 else'ub')+str(i)for i in range(45)];phys=[f'B{i}_{mu}'for i in range(45)for mu in range(4)]+xs+aux+cs+ants;ri={n:i for i,n in enumerate(frame['field_order'])};pi={n:i for i,n in enumerate(phys)};FC=dec(frame['physical_to_raw_kernel']).extract([pi[n]for n in cs],[ri[n]for n in cs]);beta=tab(m['beta_C_L']);qc=tab(m['qC_CC']);BH=[];CH=[]
for h in range(12):
 b=defaultdict(lambda:0);c=defaultdict(lambda:0)
 for(r,a,t),v in beta.items():b[r,t]+=FC[a,h]*v
 for(r,a,z),v in qc.items():c[r,z]+=FC[a,h]*v;c[r,a]-=FC[z,h]*v
 BH.append(cl(s.SparseMatrix(45,45,dict(b))));CH.append(cl(s.SparseMatrix(45,45,dict(c))))
e=load(Path(ip['Euler']));N=dec(e['endings']['N0'])[45:,:];assert len(N.todok())==296;nb=defaultdict(list)
for(r,i),v in N.todok().items():nb[r].append((i,v))
color=load(O/'contact_color_primary_tables.json.gz');results=[];covcounts=[];auxcontrols=[]
for pr in color['results']:
 heat={k:tab(pr['heat_and_group_tensors'][k])for k in ['C2','C3','C4']};images={}
 for k,T in heat.items():
  cov=[]
  for B,C in zip(BH,CH):
   bo=defaultdict(list);co=defaultdict(list);z=defaultdict(lambda:0)
   for(r,t),v in B.todok().items():bo[t].append((r,-v))
   for(h,j),v in C.todok().items():co[h].append((j,v))
   for(r,t,h),v in T.items():
    for a,c in bo[r]:z[a,t,h]+=c*v
    for b,c in bo[t]:z[r,b,h]+=c*v
    for j,c in co[h]:z[r,t,j]+=c*v
   cov.append(len(clean(z)))
  assert not any(cov),('contact_H_covariance_failed',pr['probe'],k,cov);covcounts.append({'probe':pr['probe'],'heat':k,'remainders':cov})
  out=defaultdict(lambda:0)
  for(r,t,h),v in T.items():
   for i,n in nb[t]:out[r,h,i]+=v*n
  out=clean(out);flat=s.SparseMatrix(45*45,45,{(r*45+h,t):v for(r,t,h),v in T.items()});MM=cl(flat*N);replay={(rh//45,rh%45,i):v for(rh,i),v in MM.todok().items()};assert out==replay;images[k]=out
  print('STAGE ICR5',pr['probe'],k,'lowered',len(out),'cov',cov,flush=True)
 def plus(terms):
  o=defaultdict(lambda:0)
  for z,factor in terms:
   for k,v in z.items():o[k]+=factor*v
  return clean(o)
 bases={'chi4':plus([(images[k],1)for k in ['C2','C3','C4']]),'log2':plus([(images['C3'],-1),(images['C4'],1)]),'log3':images['C3'],'log5':{}};partial=[]
 for basis,lower in bases.items():
  old=load(Path(ip['late_H'][basis]))['results'][pr['probe']]['formal_basis'][0]['nonminimal']['H'];old={(r,ww[0],i):parse(v)for r,ww,i,v in old};remainder=plus([(old,1),(lower,1)]);partial.append({'basis':basis,'contact_lowering':enc(lower),'homogeneous_H_plus_contact_lowering':enc(remainder),'homogeneous_H_nonzero':len(old),'missing_Brho_C0_not_assigned_zero':True})
 results.append({'probe':pr['probe'],'heat_lowered_tensors':{k:enc(z)for k,z in images.items()},'formal_basis':partial})
 # Actual omitted auxiliary-current contribution, separate from fixed tables.
 native=load(O/('contact_color_primary_inputs.json.gz'));w=tab(native['W']);W=[s.SparseMatrix(45,45,{(a,c):v for(rr,a,c),v in w.items()if rr==r})for r in range(45)];tt=tab(native['rho'][pr['probe']]['T']);TT=[s.SparseMatrix(45,45,{(a,b):v for(rr,a,b),v in tt.items()if rr==r})for r in range(45)];J=list(map(dec,native['J0']));ctrl={}
 for h in range(45):
  Y=[cl(M*J[h][:,45:])for M in W];vals={}
  for r,M in enumerate(TT):
   dd=M.todok()
   for t,Z in enumerate(Y):
    zz=Z.todok();v=s.expand(-sum((v*zz.get((b,a),0)for(a,b),v in dd.items()),s.Integer(0)))
    if v:vals[r,t]=v
  mat=s.SparseMatrix(45,45,vals);mat=cl(mat-mat.T)
  for(r,t),v in mat.todok().items():ctrl[r,t,h]=v
 auxcontrols.append({'probe':pr['probe'],'omit_actual_J0_L_changes_C3_positions':len(ctrl),'auxiliary_current_contribution':enc(ctrl)})
out={'schema':'ICR5_CORRELATED_CONTACT_ACTUAL_EULER_IMAGE','results':results,'all_source_scalar_positions_per_tensor_probe':45*45*328,'covariance':covcounts,'auxiliary_current_controls':auxcontrols,'nonzero_literal_graded_density_fixture_pass':True,'B1C0_missing_quantum_roots_not_fitted':True,'full_quantum_identity_QAP_E5_A5':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'lowering_tables.json.gz').open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'heat_lowered_positions':[{k:len(v)for k,v in q['heat_lowered_tensors'].items()}for q in results],'partial_H_positions':[[[z['basis'],len(z['contact_lowering']),len(z['homogeneous_H_plus_contact_lowering'])]for z in q['formal_basis']]for q in results],'omit_J0_L_changed_positions':[z['omit_actual_J0_L_changes_C3_positions']for z in auxcontrols],'H_covariance_all12_and_lowering_two_methods_pass':True,'no_full_restoration_or_anomaly_inferred':True},sort_keys=True),flush=True);timer.cancel()
