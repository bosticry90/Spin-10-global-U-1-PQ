# ICR1 exact-type and exclusion-record correction

Primary and replay completed within bounds; original exact verifier FAILED.
Preserve both original natives,inputs,preparations,tables,full captures,
verifier source/capture and controllerfailure. No original qualification
receipt exists. This was not a quantum identity failure.

Two diagnosed causes:
1. Replay's Python (-1)**negative_odd exponent made -1.0 and contaminated
   rational coefficients with Float. Primary remained exact. V2 reduces the
   exponent modulo2 BEFORE exponentiation; no tolerance or rounding is used.
2. Replay's independently enumerated root space prefiltered dimensions,
   whereas primary retained out-of-domain derivative candidates in its
   exclusion evidence. V2 enumerates those candidates too, then applies the
   SAME explicit jet/intrinsic exclusions at the same stage. Actual retained
   type/route counts did not differ. No physical coefficient is discarded.

Resume only the replay under a newly frozen source/preparation, then compare
with the unchanged original primary. All exact route/phase/zero/diagnostic
comparisons remain required. Native300s/review180s,8GiB sampled,350MiB floor,
32MiB packet unchanged. No historical rebinding or retroactive PASS.
