from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,gzip,ast,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'final_review_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
copies=0;bindings=0;captures=0;peak=0
for p in O.glob('*.source.txt'):assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes();copies+=1
for p in O.glob('*preparation*.json'):
 for f,h in read(p).get('input_sha256',{}).items():assert H(Path(f))==h,(p,f);bindings+=1
for p in O.glob('*capture.json'):
 z=read(p);assert z['post_run_observations_qualified']and z['launch']['memory']['available_pagefile']>=350*1024**2;peak=max(peak,max(v['private_bytes']for v in z['all_resource_samples']));assert peak<=8*1024**3;captures+=1
 if p.name=='roots_verify_capture.json':assert z['exit_code']==1 and z['execution_state']=='FAILED'and not z['calculation_completed']
 else:assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']
assert read(O/'roots_controller_failure.json')['execution_state']=='FAILED'and not(O/'roots_validation_receipt.json').exists();assert not(O/'roots_controller_failure_v2.json').exists();assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.expand(s.sympify(z,locals=loc))
tab=lambda z:{tuple(q[:-1]):parse(q[-1])for q in z};cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v)for i,j,v in z['entries']});clean=lambda z:{k:s.expand(v)for k,v in z.items()if s.expand(v)!=0}
def plus(terms):
 out=defaultdict(lambda:0)
 for dd,f in terms:
  for k,v in dd.items():out[k]+=f*v
 return clean(out)
roots=load(O/'roots_v2_replay_tables.json.gz');checked=0
for pr in roots['results']:
 for q in pr['probes']:
  for r in q['routes']:assert not parse(r['operation_coefficient']).atoms(s.Float);checked+=1
primary=load(O/'roots_primary_tables.json.gz');aa=dict(primary);bb=dict(roots);aa.pop('role');bb.pop('role');assert aa==bb
# Finite exterior algebra checked independently of matrix-cycle formulas.
src=(O/'contact_kernel.py').read_text();tree=ast.parse(src);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='exterior');sc={'ns':{'ca':lambda a,b:(a[0]+b[0],a[1]+b[1]),'cm':lambda a,b:(a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]),'cs':lambda a,n:(a[0]*n,a[1]*n),'cz':lambda a:a!=(0,0)}};exec(compile(ast.get_source_segment(src,node),'<ICR8_four_odd_multiplication>','exec'),sc)
for a in range(16):
 for b in range(16):
  w=[i for i in range(4)if a&(1<<i)]+[i for i in range(4)if b&(1<<i)];expected={}if len(set(w))!=len(w)else{(a|b,0):((-1)**sum(x>y for j,x in enumerate(w)for y in w[j+1:]),0)};assert sc['exterior']({(a,0):(1,0)},{(b,0):(1,0)})==expected
ip=read(O/'final_review_inputs.json');N=dec(load(Path(ip['N_replay']))['N0_linear_ending']);assert len(N.todok())==296;NB=defaultdict(list)
for(a,i),v in N.todok().items():NB[a].append((i,v))
color=load(O/'contact_color_replay_tables.json.gz');low=load(O/'lowering_tables.json.gz');root=load(O/'auxiliary_roots_replay_tables.json.gz')['results'];Y2=tab(root[0]['heat_and_group_tensors']['C2']);Y3=tab(root[0]['heat_and_group_tensors']['C3']);assert not root[1]['heat_and_group_tensors']['pole'];Y={'chi4':plus([(Y2,1),(Y3,1)]),'log2':plus([(Y3,-1)]),'log3':Y3,'log5':{}};partial=load(O/'partial_H_tables.json.gz');data=load(O/'roots_replay_inputs.json.gz')['audit'];names=data['names'];geo=data['geometry'];base=geo['names'];sources={base[J]:base[f]for f,J,h,k in geo['field_source_h_k']};aux=[('b'if i<12 else'L')+str(i)for i in range(45)];xs=[f'x_{sec}_{i}'for sec,n in [('Phi',54),('Sigma',252),('phi',20),('S',2)]for i in range(n)];ai={n:i for i,n in enumerate(aux)};xid={n:i for i,n in enumerate(xs)};counts=[];new_three_edge=[];comparisons=0
for probe,pr in enumerate(color['results']):
 image={}
 for heat in ['C2','C3','C4']:
  z=defaultdict(lambda:0)
  for r,t,h,v in pr['heat_and_group_tensors'][heat]:
   for i,n in NB[t]:z[r,h,i]+=parse(v)*n
  image[heat]=clean(z);assert image[heat]==tab(low['results'][probe]['heat_lowered_tensors'][heat]);comparisons+=45*45*328
 images={'chi4':plus([(image[k],1)for k in image]),'log2':plus([(image['C3'],-1),(image['C4'],1)]),'log3':image['C3'],'log5':{}}
 E=defaultdict(lambda:0)
 for rr in roots['results'][0]['probes'][probe]['routes']:
  if rr['root']==['C','JL','L']:
   assert len(rr['flow_remaining_word'])==1;E[ai[rr['flow_output']],xid[rr['flow_remaining_word'][0][0]]]+=parse(rr['operation_coefficient'])
 E=clean(E);ey=defaultdict(list)
 for(a,i),v in E.items():ey[a].append((i,v))
 per=[]
 for basis,yy in Y.items():
  B=defaultdict(lambda:0)
  for(a,r,h),v in yy.items():
   for i,z in ey[a]:B[r,h,i]+=v*z
  B=clean(B);qq=next(z for z in partial['results'][probe]['formal_basis']if z['basis']==basis);assert B==tab(qq['measured_marginal_BrhoC0']);old=load(Path(ip['old_H_replay'][basis]))['results'][probe]['formal_basis'][0]['nonminimal']['H'];hh={(r,ww[0],i):parse(v)for r,ww,i,v in old};assert all(len(ww)==1 for r,ww,i,v in old);all_known=plus([(hh,1),(images[basis],1),(B,1)]);assert all_known==tab(qq['known_partial_H']);comparisons+=2*45*45*328;per.append([basis,len(B),len(all_known)])
  if basis=='log3':new_three_edge.append(len(plus([(image['C3'],1),(B,1)])))
 counts.append(per)
cov=low['covariance'];assert len(cov)==6 and all(not any(z['remainders'])for z in cov);assert [q['omit_actual_J0_L_changes_C3_positions']for q in low['auxiliary_current_controls']]==[0,0]
assert partial['actual_unmeasured_roots']==['intrinsic C JL x','intrinsic C a x','marginal C Jx x']and not partial['full_H_identity_anomaly_QAP_E5_A5'];assert [{k:len(v)for k,v in q['pending_operation_matrices'].items()}for q in partial['results']]==[{'C_JL_x':12,'C_a_x':12,'C_Jx_x':0},{'C_JL_x':33,'C_a_x':33,'C_Jx_x':296}]
c=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-correlated-source-contacts-v1-2026-10-25');e=read(c/'e4_full_capture.json');events=[json.loads(l)for l in e['stdout_and_stderr'].splitlines()];assert e['native_exit']==0 and[z['exit_code']for z in events if z['event']=='step_finished']==[0,0,0,0,0,2]and events[-1]['execution_state']=='COMPLETED';assert H(O.parents[1]/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'all_preparation_bindings_checked':bindings,'frozen_source_copies_equal':copies,'pre_review_full_captures':captures,'largest_pre_review_private_sample':peak,'corrected_exact_operation_coefficients_checked':checked,'all_256_four_odd_basis_products_pass':True,'replay_contact_N0_roots_and_old_H_independent_integration_pass':True,'full_positions_compared_by_sparse_zero_completion':comparisons,'probe_basis_B_and_partial_H_positions':counts,'new_three_edge_contact_lowering_plus_marginal_companion_nonzero':new_three_edge,'all12_H_covariance_qualified_in_nonzero_classes':True,'actual_auxiliary_current_omission_control_insensitive_disclosed':True,'three_pending_H_kernels_not_fitted':True,'original_failed_comparison_preserved_no_qualification_receipt':True,'E4_declared_exits_and_unchanged_state_pass':True,'full_QAP_E5_A5_or_physical_promotion':False},sort_keys=True),flush=True);timer.cancel()
