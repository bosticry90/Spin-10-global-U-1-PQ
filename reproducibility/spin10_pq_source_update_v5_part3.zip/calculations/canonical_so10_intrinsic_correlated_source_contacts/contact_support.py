from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from itertools import combinations,permutations
import json,gzip,sys,time,threading,os
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'contact_support_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
d=load(O/('contact_support_'+role+'_inputs.json.gz'));a=d['audit'];names=a['names'];geo=a['geometry'];base=geo['names'];fields={names.index(base[f]):base[f]for f,J,h,k in geo['field_source_h_k']};sources={names.index(base[J]):base[f]for f,J,h,k in geo['field_source_h_k']};aux={('b'if i<12 else'L')+str(i)for i in range(45)};ants={('bar'if i<12 else'ub')+str(i)for i in range(45)}
def kind(n):
 if n in ants:return'a'
 if n in aux:return'L'
 if n.startswith('B'):return'B'
 if n.startswith('C'):return'C'
 if n.startswith('x_'):return'x'
 return None
dims={'B':1,'L':2,'C':1,'a':1,'x':1};catalog=defaultdict(list);excluded=Counter();ports0=[];sourceinventory=[]
def ports(origin,n,rho,jl,ww,ref):
 if n!=0:excluded['other_intrinsic_grade']+=1;return
 if jl>2:excluded['too_many_target_sources']+=1;return
 if len(ww)<2:
  excluded['zero_quantum_ports'if not ww else'one_quantum_port']+=1;ports0.append({'origin':origin,'rho_JL':[rho,jl],'reference':ref,'quantum_fields':ww});return
 pairs=((i,j)for i in range(len(ww))for j in range(len(ww))if i!=j)if role=='primary'else(pair for ij in combinations(range(len(ww)),2)for pair in[ij,ij[::-1]])
 for i,j in pairs:
  ext=[v for k,v in enumerate(ww)if k not in[i,j]]
  if any(k!='C'or jets for k,jets in ext)or len(ext)>1:excluded['unused_mean_field_or_external_jet']+=1;continue
  if not rho and not jl and not ext:excluded['resummed_zero_grade_free_edge']+=1;continue
  L,R=ww[i],ww[j];key=(origin,rho,jl,len(ext),L[0],R[0],L[1],R[1]);catalog[key].append([*ref,i,j])
for probe,p in enumerate(a['physical_G']):
 hist=Counter()
 for idx,(gp,w,ci)in enumerate(p['monomials']):
  js=[(n,I)for n,I in w if n in sources];hist[len(js)]+=1
  if any(sources[n]not in aux for n,I in js):excluded['other_source_role']+=1;continue
  if any(n not in fields and n not in sources for n,I in w):excluded['background_or_control_at_A0']+=1;continue
  if any(I for n,I in js):excluded['external_source_jet']+=1;continue
  ww=[(kind(names[n]),len(I))for n,I in w if n in fields];assert all(k in dims for k,j in ww);ports('rhoG'+str(probe),3-len(js)-sum(dims[k]+j for k,j in ww),1,len(js),ww,[idx])
 sourceinventory.append(dict(hist))
for out,rows in d['qLambda'].items():
 assert out in aux
 for idx,row in enumerate(rows):
  ww=[]
  for v in row['word']:
   n,sep,jets=v.partition('__');k=kind(n);assert k in dims;ww.append((k,len(jets)))
  ports('JqLambda',3-sum(dims[k]+j for k,j in ww),0,1,ww,[out,idx])
for idx,row in enumerate(d['GF']):
 ww=[]
 for v in row['word']:
  n,sep,jets=v.partition('__');k=kind(n)
  if k is None:excluded['GF_background_at_A0']+=1;break
  ww.append((k,len(jets)))
 else:ports('GF',4-sum(dims[k]+j for k,j in ww),0,0,ww,[idx])
letters=[]
for key,refs in sorted(catalog.items()):
 origin,rho,jl,c,left,right,j1,j2=key;letters.append({'id':len(letters),'origin':origin,'grade':[rho,jl,c],'H_ports':[left,right],'internal_jet_orders':[j1,j2],'member_references':sorted(refs,key=str)})
G={('B','B'),('B','L'),('L','B'),('C','a'),('a','C'),('x','x')};kinds=sorted(dims);target=(1,2,1);sub=lambda x,y:tuple(a-b for a,b in zip(x,y));sat=lambda x:all(a>=0 for a in x);results=[]
for probe in range(2):
 active=[z['id']for z in letters if sat(sub(target,z['grade']))and(not z['origin'].startswith('rhoG')or z['origin'].endswith(str(probe)))];opts={i:[(v,letters[i]['H_ports'][1])for v in kinds if(v,letters[i]['H_ports'][0])in G]for i in active};found=set()
 if role=='primary':
  edges=defaultdict(list)
  for i in active:
   for r,c in opts[i]:edges[r].append((i,c))
  def walk(start,at,left,w,path):
   if not any(left):
    if at==start:found.add((tuple(w),tuple(path)))
    return
   for i,to in edges[at]:
    rem=sub(left,letters[i]['grade'])
    if sat(rem):walk(start,to,rem,w+[i],path+[to])
  for start in kinds:walk(start,start,target,[],[start])
 else:
  multis=[]
  def choose(lo,left,w):
   if not any(left):multis.append(tuple(w));return
   for at in range(lo,len(active)):
    i=active[at];rem=sub(left,letters[i]['grade'])
    if sat(rem):choose(at,rem,w+[i])
  choose(0,target,[])
  for ms in multis:
   for w in set(permutations(ms)):
    def attach(at,path):
     if at==len(w):
      if path[-1]==path[0]:found.add((w,tuple(path)))
      return
     for r,c in opts[w[at]]:
      if not path or path[-1]==r:attach(at+1,(path or[r])+[c])
    attach(0,[])
 words=[];families=Counter()
 for w,path in sorted(found):
  assert len(w)<=4
  for j in range(len(w)):assert(w[j:]+w[:j],path[j:-1]+path[:j]+(path[j],))in found
  words.append({'letters':list(w),'Green_path':list(path),'STr_sign':(-1)**int(path[0]in ['a','C']),'ordered_log_weight':[(-1)**(len(w)+1),2*len(w)]});families[len(w),tuple(sorted(letters[i]['origin']for i in w))]+=1
 results.append({'probe':probe,'ordered_words':words,'families':[{'length':n,'origins':list(orig),'words':v}for(n,orig),v in sorted(families.items())]});print('STAGE ICR2',role,probe,'words',len(words),'families',len(families),flush=True)
out={'schema':'ICR2_COMPLETE_RHO_JL_JL_C_TYPED_SUPPORT','role':role,'letters':letters,'results':results,'excluded':dict(excluded),'zero_or_one_port_classical_terms':ports0,'full_G_source_inventory_before_filtering':sourceinventory,'no_physical_interaction_can_supply_unused_target_source_or_ghost':True,'typed_inventory_not_quantum_coefficients':True};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('contact_support_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'letters':len(letters),'word_counts':[len(q['ordered_words'])for q in results],'families':[q['families']for q in results]},sort_keys=True),flush=True);timer.cancel()
