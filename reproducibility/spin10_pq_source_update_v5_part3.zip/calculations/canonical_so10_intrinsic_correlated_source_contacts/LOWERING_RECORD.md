# ICR5: actual correlated-contact Euler image and covariance

Prospective after ICR4 coefficient qualification. Full probe0 contact0.
Probe1 C2 has832 positions,C3_T282,C3=282,pole1114; other triangle groups
and C4 vanish after actual contraction. Keep their generic/typed evidence,
not an assumption that the four-edge family universally vanishes.

Check residual-H covariance from actual canonical nonminimal beta,qC and
raw-to-canonical unbroken ghost parameter chart. In ordinary even-parameter
notation deltaJL=-JL beta_H and deltaC=QC_H C,where QC_H is derived by
polarizing the actual qC polynomial. Compute all three tensor-slot actions,
not a source-free projection. If a sign convention is ambiguous, retain the
remainder and rederive the operation; do not pick a favorable sign.

Before numerical application derive source-free Euler lowering with a
nonzero literal graded fixture. For density rho/2 JL_s JL_r C_h T_srh,
qJL|J0=N0_Lx x gives H_lower[r,h,i]=sum_s T_rsh N0_si in rho JL_r C_h x_i.
qC and homogeneous qJL preserve source degree and are not this lowering.
Apply the actual296-position N0. Primary index contraction vs flattened
matrix contraction must match all664200 positions per probe/heat,including
zeros. Keep C2,C3,C4 and chi4/log2/log3/log5 separate. Only after computing
the image compare with old ISD homogeneous H; retain any partial remainder.
B_rho C0 roots are not fully measured,so a nonzero partial sum is neither
an anomaly nor a completed quantum identity. Do not fit those missing roots.

Also quantify omission of the actual ordinary auxiliary current in C3_T
without changing the published contact. Zero-model controls are reported
as insensitive where applicable. Reviewer180s/8GiB sampled/350MiB floor/
32MiB packet,all sources/inputs frozen before calculation. No new science
authority or absolute finite-product normalization is inferred.
