from pathlib import Path
from hashlib import sha256
import json,gzip,time
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter()
for p,h in read(O/'roots_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('roots_'+r+'_tables.json.gz'))for r in ['primary','replay']]
for z in [a,b]:z.pop('role')
assert a==b
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'complementary_subtraction_vs_full_local_root_reverse_enumeration_agree':True,'left_vs_right_graded_source_operation_all_coefficients_agree':True,'target_family_counts':[[r['target'],[len(p['root_families'])for p in r['probes']],[len(p['routes'])for p in r['probes']]]for r in a['results']],'actual_roots_not_zeroed_or_fitted':True,'QAP_E5_A5_or_physical_promotion':False},sort_keys=True),flush=True)
