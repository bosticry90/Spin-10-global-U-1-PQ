from pathlib import Path
from hashlib import sha256
import ast,json,gzip,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-correlated-source-contacts-v1-2026-10-25');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'roots_validation_preparation_v2.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 for n in ['roots_validation_preparation_v2.json','roots_validation_receipt_v2.json','roots_v2_verify_capture.json']:p=O/n;b[str(p)]=H(p)
 for role in ['primary','replay']:
  ip=O.parent/'canonical_so10_intrinsic_quadratic_source_contacts'/('support_'+role+'_inputs.json.gz');gp=O.parent/'canonical_so10_intrinsic_kinetic_support'/('support_'+role+'_inputs.json.gz')
  for p in [ip,gp]:b[str(p)]=H(p)
  z=load(ip);z={'audit':z['audit'],'qLambda':z['qLambda'],'GF':load(gp)['GF']};p=O/('contact_support_'+role+'_inputs.json.gz')
  with p.open('xb')as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
  b[str(p)]=H(p)
 for n in ['CONTACT_RECORD.md','contact_support.py','verify_contact_support.py','run_contact_support.py']:
  p=O/n;cp=O/(n+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(cp)]=H(cp)
 dump(O/'contact_support_preparation.json',{'input_sha256':b,'seconds_after_imports':300,'scientific_acceptance':'NOT_PERFORMED'})
 for role in ['primary','replay','verify']:
  if role=='verify':
   for n in ['contact_support_preparation.json']+[f'contact_support_{r}_{t}.json'+('.gz'if t=='tables'else'')for r in ['primary','replay']for t in ['tables','capture','result']]:p=O/n;b[str(p)]=H(p)
   dump(O/'contact_support_validation_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
  cmd=[sys.executable,'-B',str(O/('verify_contact_support.py'if role=='verify'else'contact_support.py'))]+([]if role=='verify'else[role]);z=capture(cmd);dump(O/('contact_support_'+role+'_capture.json'),z);dump(C/('contact_support_'+role+'_full_capture.json'),z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<(180 if role=='verify'else 300);dump(O/('contact_support_validation_receipt.json'if role=='verify'else'contact_support_'+role+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2;print('COMPLETED_ICR2',role,json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'contact_support_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
