# ICR2-4: marginal rho JL JL C contact

Prospective after ICR1V2 qualified. Freeze density
 Ccontact=(rho/2)sum_sr,h JL_s JL_r C_h T_srh, T_srh=-T_rsh.
All three displayed sources/ghost are odd,rho odd before them. With
s<r the coefficient is exactly T_srh; no extra half. Equal source
directions vanish. The target is intrinsic0 before its Euler lowering.

Inventory every actual proper Hessian word in full rho G,original JL CL/
JL CCa source maps and the ordinary gauge-fixing action. Preserve source-
only/one-port terms and all source degrees before target restrictions.
Ordinary fields not equal to the ONE allowed external C are excluded only
after quantum ports are selected. Actual physical vertices cannot supply
this source/ghost target without unused mean fields; free quadratic edges
are resummed in G0. Use directed paths vs multiset/permutation cycles.
Exact maximum4 letters follows target grade rho1,JL2,C1,not a truncation.

Derive a complete paired-mode Gaussian and independently a Schur ghost
determinant with ordinary external-ghost mixed current J0_h,source-free
rho current Jrho,direct rho-JL U/T and original JL source W/Z. Keep the
auxiliary component of J0_h; it may enter the T insertion even when the
direct W path uses the vector component only. Do not omit possible4-edge
terms or collapse heat lengths. Test D3/4/5,q±,source exchange/equal-source,
noncommuting matrices and sensitive omission controls before model data.

Then measure all45x45x45 coefficients (including all equal-source and zero
positions) in each distinct heat class and both probes by independent sparse
paths/trace contractions. Antisymmetrization is done only after the ordered
amplitudes are derived; no target Ward identity supplies their values.
Actual classical source coefficients and loop coefficients stay distinct.

Domain/bounds/authority as RECORD: natives300s,review180s afterimports,
8GiB sampled private,350MiB launch floor,32MiB complete packet. Sources,
copies and actual inputs bound before each calculation. No unqualified
source-root value,absolute finite normalization or physical-scheme change.
