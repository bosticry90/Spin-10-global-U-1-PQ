from pathlib import Path
from hashlib import sha256
import ast,json,gzip,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-correlated-source-contacts-v1-2026-10-25');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'lowering_preparation.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 for n in ['lowering_preparation.json','lowering_tables.json.gz','lowering_capture.json','lowering_validation_receipt.json']:p=O/n;b[str(p)]=H(p)
 IQC=O.parent/'canonical_so10_intrinsic_quadratic_source_contacts'
 for role in ['primary','replay']:
  p=IQC/('auxiliary_'+role+'_tables.json.gz');q=IQC/('color_'+role+'_tables.json.gz');z=load(O/('contact_color_'+role+'_inputs.json.gz'));b[str(p)]=H(p);b[str(q)]=H(q);dd=load(p);z={k:z[k]for k in ['W','Z0','G0','J0']};z.update({'T0':dd['T0_Lambda_BB'],'U0':dd['U0_Lambda_aC'],'A':load(q)['A_original_Ja_aC']});p=O/('auxiliary_roots_'+role+'_inputs.json.gz')
  with p.open('xb')as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
  b[str(p)]=H(p)
 for n in ['AUXILIARY_ROOT_RECORD.md','auxiliary_roots.py','verify_auxiliary_roots.py','run_auxiliary_roots.py']:
  p=O/n;cp=O/(n+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(cp)]=H(cp)
 dump(O/'auxiliary_roots_preparation.json',{'input_sha256':b,'seconds_after_imports':300,'scientific_acceptance':'NOT_PERFORMED'})
 for role in ['primary','replay','verify']:
  if role=='verify':
   for n in ['auxiliary_roots_preparation.json']+[f'auxiliary_roots_{r}_{t}.json'+('.gz'if t=='tables'else'')for r in ['primary','replay']for t in ['tables','capture','result']]:p=O/n;b[str(p)]=H(p)
   dump(O/'auxiliary_roots_validation_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
  cmd=[sys.executable,'-B',str(O/('verify_auxiliary_roots.py'if role=='verify'else'auxiliary_roots.py'))]+([]if role=='verify'else[role]);z=capture(cmd);dump(O/('auxiliary_roots_'+role+'_capture.json'),z);dump(C/('auxiliary_roots_'+role+'_full_capture.json'),z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<(180 if role=='verify'else 300);dump(O/('auxiliary_roots_validation_receipt.json'if role=='verify'else'auxiliary_roots_'+role+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2;print('COMPLETED_ICR6',role,json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'auxiliary_roots_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
