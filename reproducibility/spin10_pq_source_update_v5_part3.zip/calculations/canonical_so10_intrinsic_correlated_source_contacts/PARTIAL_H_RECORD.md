# ICR7: integrate measured marginal roots, retain the three unknown kernels

Prospective after ICR6. Unprobed Lambda JL C has C2/C3/pole776/282/1058
positions; Ja JL C is measured zero. The earlier Ja x root is qualified
zero. Use actual ICR1 B_rho routes to compute these contributions to H,
not values fitted from H_hom. No complete H quantum identity is claimed.

For C0=Lambda_a JL_r C_h Y_arh, qLambda|rho x=rho E_ai x_i gives
B_known[r,h,i]=sum_a Y_arh E_ai. Verify that sign with a nonzero literal
graded fixture; index sums vs flattened E^T Y must agree. SourceJa JL C
and Ja x contributions are zero by their independently qualified roots,
not by this integration. Keep all four formal log/chi4 bases separate.

Only after computing B_known add it to the already computed contact Euler
image and old homogeneous ISD H. Store the exact partial remainder; do not
call a zero complete while unknown kernels remain. Enumerate the remaining
actual linear operations on the intrinsic C JL x,C a x and marginal C Jx x
roots directly from the support tables. Freeze their matrices,source/field
slots,coefficients and intrinsic grades. All other actual routes must have
a measured or structurally qualified input,or remain explicitly unknown.

Reviewer180s,8GiB sampled,350MiB floor,32MiB whole packet. No new regulator
limit,absolute scheme,full QAP/anomaly or E5/A5 promotion. The pending
ordinary/source kernels are independently calculable objects,not equations
to solve for a favorable cancellation.
