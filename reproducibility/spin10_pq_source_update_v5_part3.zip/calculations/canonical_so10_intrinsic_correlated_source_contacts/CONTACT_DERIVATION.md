# ICR3 proposed complete correlated-source kernel

Freeze before generic/model computation. J currents are LEFT antighost Euler
currents of the actual Euclidean density, so mixed terms have order
a rho Jrho b and a c J0 b, not rho a Jrho b. W source terms are j_s C W_s b;
direct ghost terms rho j_s a U_s C and j_s c a Z_s C; bosonic terms
(rho/2)j_s b T_s b. Here c is the external ghost and j_s odd JL sources.
T_s symmetric, W has only auxiliary rows. b=(all vector components,Lambda).

With G=K^-1 the effective ghost potentials linear in these external grades
are rho j_s (U_s-Jrho G W_s) and j_s c (Z_s+J0 G W_s). The plus in the
second expression comes from exchanging c and j_s. Expansion of the boson
inverse adds the rho j1 j2 c ghost term
-J0 G T1 G W2+J0 G T2 G W1. The boson determinant cannot consume c.

Using -Trlog(1+X), coefficient of rho j1 j2 c decomposes by number of
positive-heat propagator edges:

C2=Tr(U1 Z2-U2 Z1)
C3=Tr(U1 J0GW2-U2 J0GW1-JrhoGW1 Z2+JrhoGW2 Z1
      +J0GT1GW2-J0GT2GW1)
C4=Tr(-JrhoGW1 J0GW2+JrhoGW2 J0GW1).

This is a PROPOSED analytic expression until the literal paired-mode
quarter-STrlog independently agrees. Source labels1/2 are exchanged to
test antisymmetry; identical source directions must give zero. The density
half cancels antisymmetric-pair double counting, not another loop half.

W auxiliary endpoints force adjacent boson propagators longitudinal, and
T_BB delta_mu_nu passes that momentum to the other endpoint. There is no
closed vector spectator. Thus analytic D-jet0 is predicted; test Cartesian
D3/4/5 and first/last axes but do not use interpolation as that proof.

At q²=1, G_BB=w,G_BL=-q,G_LB=q,G_LL=0. Let P_s=Jrho G W_s,
R_sh=J0_h G W_s. The T term is -Tr((J0_B w+J0_L)T_s W_r) before
source antisymmetrization. The auxiliary current J0_L is essential here.

The retained local relative conversion is
chi4(C2+C3+C4)+log(3/2)C3+log2 C4, fixed Djet0.
Each heat class is computed before this addition. Generic noncommuting
data,paired q±,source exchange/equal-source,ordinary auxiliary-current and
box omission controls are required. Frullani length4/6/8 differences are
checked independently. No model Ward coefficient is an operand.
