from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import ast,json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'auxiliary_roots_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('auxiliary_roots_'+r+'_tables.json.gz'))for r in ['primary','replay']]
for z in [a,b]:z.pop('role')
assert a==b
# Execute only bound helper/function definitions, never historical entrypoints.
helper=Path(read(O/'contact_kernel_inputs.json')['exact_helper_source']).read_text();tt=ast.parse(helper);fn=['gc','add','scale','mm','ma','ms','const','tr','rat','fracadd','encode'];aa=['ca','cm','cs','cz'];nodes=[n for n in tt.body if isinstance(n,ast.FunctionDef)and n.name in fn or isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id in aa for t in n.targets)];sc={'s':s,'F':F,'defaultdict':defaultdict};exec(compile('\n\n'.join(ast.get_source_segment(helper,n)for n in nodes),'<ICR6_exact_definitions>','exec'),sc);sc['ns']=sc
src=(O/'contact_kernel.py').read_text();tt=ast.parse(src);nodes=[n for n in tt.body if isinstance(n,ast.FunctionDef)and n.name in ['exterior','data','born','schur']];exec(compile('\n\n'.join(ast.get_source_segment(src,n)for n in nodes),'<ICR6_linear_specialization_definitions>','exec'),sc);sc['mul']=sc['exterior'];original=sc['data']
def specialize(D,axis,q,*args):
 K,JR,J0,W,T,U,Z=original(D,axis,q,*args);return K,s.zeros(*JR.shape),J0,[s.zeros(*W[0].shape),W[1]],[T[0],s.zeros(*T[1].shape)],[U[0],s.zeros(2)],[s.zeros(2),Z[1]]
sc['data']=specialize;fixtures=[]
for D in [3,4,5]:
 for axis in [0,D-1]:
  x=sc['born'](D,axis);y=sc['schur'](D,axis);assert x==y and x[4]==(0,0)and x[2]!=(0,0)and x[3]!=(0,0);fixtures.append(sc['encode'](x))
assert all(z==fixtures[0]for z in fixtures)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'all_91125_positions_per_root_heat_and_zeros_agree':True,'full_90_auxiliary_vs_45_component_model_methods_pass':True,'six_linear_specialization_Gaussian_Schur_fixtures_pass':True,'generic_specialized_heat_coefficients':fixtures[0],'root_heat_group_positions':[{k:len(v)for k,v in z['heat_and_group_tensors'].items()}for z in a['results']],'unmeasured_other_roots_not_fitted':True,'QAP_E5_A5_promotion':False},sort_keys=True),flush=True);timer.cancel()
