# ICR4: actual full correlated rho JL JL C coefficient tensor

Prospective after ICR3 Gaussian/Schur qualification: generic C2=-16,
C3=33-64i,C4=28,12 Cartesian/source-direction fixtures,all frozen controls.
All typed22 letters/78 words are represented,including32 four-edge words.

Use actual action-derived IAS T/U,ISD or IAS W,IAG Z0 and EDS J0/Jrho/G0
for each method/probe,never ISD H/T/F or a desired quantum target. Extract
only classical coefficient tables into native bundles. These imported
vertices were already derived by distinct raw/physical/source transports.

Primary uses45-component closed longitudinal indices and explicit sparse
path sums. Replay uses the full90x90 longitudinal-vector/auxiliary inverse,
noncommuting products and batched trace contractions; no collapsed auxiliary
current. For each external ghost h retain C2,C3_UJ0,C3_JrhoZ,C3_T,C4 and
their sums separately, all45x45 source pairs. Test antisymmetry and equal-
source zeros before relative-heat assembly. Do not suppress a group merely
because another cancels it. Keep chi4,log(3/2),log2 independent.

Compare complete tensors and zero complement,all91125 positions/heat/probe.
Source-only classical coefficients are not loop outputs. Actual zero tensors
cannot supply a sensitive phase/heat control; generic ICR3 controls carry
that burden. Any inherited source/background/reality limitation is explicit.
Same action/domain,300s natives/180s review,8GiB sampled,350MiB floor,32MiB
whole packet and unchanged scientific ceiling. Complete remaining B1 C0
quantum roots are still not assigned values by this new contact measurement.
