from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'auxiliary_roots_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.expand(s.sympify(z,locals=loc))
cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v)for i,j,v in z['entries']});tab=lambda z:{tuple(q[:-1]):parse(q[-1])for q in z};clean=lambda z:{k:s.expand(v)for k,v in z.items()if s.expand(v)!=0};enc=lambda z:[[*k,str(v)]for k,v in sorted(clean(z).items())]
d=load(O/('auxiliary_roots_'+role+'_inputs.json.gz'));w=tab(d['W']);W=[s.SparseMatrix(45,45,{(a,c):v for(rr,a,c),v in w.items()if rr==r})for r in range(45)];Z0=tab(d['Z0']);G=dec(d['G0']);J=list(map(dec,d['J0']));WG=[s.SparseMatrix(90,45,{(45+a,c):v for(a,c),v in M.todok().items()})for M in W];GW=[cl(G*M)for M in WG];width=G[:45,:45]
def traces(X,Y):
 if role=='replay':
  n=X[0].rows;m=X[0].cols;xx=s.SparseMatrix(45,n*m,{(r,a*m+c):v for r,M in enumerate(X)for(a,c),v in M.todok().items()});yy=s.SparseMatrix(n*m,45,{(a*m+c,r):v for r,M in enumerate(Y)for(c,a),v in M.todok().items()});return cl(xx*yy)
 out={}
 for r,M in enumerate(X):
  for t,N in enumerate(Y):
   dd=N.todok();v=s.expand(sum((v*dd.get((c,a),0)for(a,c),v in M.todok().items()),s.Integer(0)))
   if v:out[r,t]=v
 return s.SparseMatrix(45,45,out)
results=[]
for label,tk,uk in [('Lambda_JL_C','T0','U0'),('Ja_JL_C',None,'A')]:
 U=list(map(dec,d[uk]));T=list(map(dec,d[tk]))if tk else[s.SparseMatrix(45,45,{})for i in range(45)];out={k:{}for k in ['C2','C3_U','C3_T','C3','pole']}
 for h in range(45):
  Z=[s.SparseMatrix(45,45,{(a,c):v for(rr,hh,a,c),v in Z0.items()if rr==r and hh==h})for r in range(45)]
  if role=='primary':
   R=[cl(-J[h][:,:45]*ww)for ww in W];K=cl(J[h][:,:45]*width+J[h][:,45:]);tpart=cl(-traces(T,[cl(ww*K)for ww in W]))
  else:
   R=[cl(J[h]*gg)for gg in GW];Q=[cl(gg*J[h]*G)for gg in GW];TT=[s.SparseMatrix(90,90,{(a,b):v for(a,b),v in M.todok().items()})for M in T];tpart=traces(TT,Q)
  C2=traces(U,Z);C3u=traces(U,R);C3=cl(C3u+tpart);P=cl(C2+C3)
  for key,M in zip(out,[C2,C3u,tpart,C3,P]):
   for(a,r),v in M.todok().items():out[key][a,r,h]=v
 results.append({'root':label,'heat_and_group_tensors':{k:enc(z)for k,z in out.items()},'relative':{'chi4':enc(out['pole']),'log3_over2':enc(out['C3']),'fixed':[]}});print('STAGE ICR6',role,label,{k:len(v)for k,v in out.items()},flush=True)
out={'schema':'ICR6_TWO_ACTUAL_MARGINAL_AUXILIARY_SOURCE_ROOTS','role':role,'results':results,'all_positions_per_root_heat':91125,'same_source_half_or_antisymmetry_not_applied':True,'full_BrhoC0_QAP_E5_A5':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('auxiliary_roots_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'root_heat_group_positions':[{k:len(v)for k,v in z['heat_and_group_tensors'].items()}for z in results]},sort_keys=True),flush=True);timer.cancel()
