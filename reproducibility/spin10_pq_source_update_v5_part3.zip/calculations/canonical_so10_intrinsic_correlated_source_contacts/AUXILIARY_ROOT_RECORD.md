# ICR6: two marginal unprobed roots required by the actual H inventory

Prospective after the correlated contact/Euler calculation. The H projection
has six actual C0 root types. Two are marginal C JL Lambda and C JL Ja;
these should be measured before assigning the remaining B_rho C0 terms.

Ordinary auxiliary background Lambda_a has action-derived BB Hessian T0_a
and ghost potential U0_a from the qualified IQC action pullbacks. SourceJa
has ghost potential A_a and no boson Hessian (Ja Lambda is one-port).
The original JL sources retain W_r and Z_rh,ordinary ghost current J0_h.
The complete local kernels for even external e and odd JL/ghost are
 C2_arh=Tr(Ue_a Z_rh),
 C3_arh=Tr(Ue_a J0_h G W_r+J0_h G Te_a G W_r).
Te=T0,Ue=U0 for Lambda;Te=0,Ue=A for Ja. No source antisymmetrization
or density half applies to Lambda JL C or Ja JL C.

This is a linear specialization of ICR3: rho*j1 becomes the one even
background e,JR=W1=Z1=U2=T2=0. Test that specialization in the literal
paired Gaussian and Schur formula before claiming transfer. First power
in an even background has the same coefficient as first power in rho*j1;
this does not identify their physical meanings or normalization freedoms.

Only actual classical T0/U0/A/W/Z/J0/G enter the two native measurements.
Primary45-index component traces vs replay90 auxiliary matrix products;
both full91125 positions per heat/root,including zeros. Retain C3_U and
C3_T separately,chi4(C2+C3)+log(3/2)C3. No measured ISD target operand,
free finite constant choice or physical-scheme change. Native300s/review180s,
8GiB sampled,350MiB floor,32MiB complete packet. Preserve failures.

Full intrinsic C JL x,C a x and marginal C Jx x quantum roots and the full
B_rho C0 coefficient remain separate. The new contact image plus homogeneous
H is nonzero; no obstruction inference is justified while those inputs are
unmeasured. No QAP/E5/A5 or scientific authority promotion.
