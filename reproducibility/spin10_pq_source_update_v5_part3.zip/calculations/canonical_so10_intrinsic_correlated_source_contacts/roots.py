from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from itertools import combinations_with_replacement
from functools import lru_cache
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'roots_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('roots_'+('replay'if role=='primary'else'primary')):raise PermissionError('ICR1_PEER_DENIED')
  if p.parent.name=='canonical_so10_intrinsic_full_source_descent'and p.name.startswith('variation'):raise PermissionError('ICR1_DESIRED_SOURCE_IMAGE_DENIED')
sys.addaudithook(guard)
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.expand(s.sympify(z,locals=loc))
d=load(O/('roots_'+role+'_inputs.json.gz'));a=d['audit'];names=a['names'];geo=a['geometry'];base=geo['names'];par=dict(zip(base,geo['parities']));sources={names.index(base[J]):base[f]for f,J,h,k in geo['field_source_h_k']};fields={names.index(base[f]):base[f]for f,J,h,k in geo['field_source_h_k']};conj={};typ={}
def kind(n):
 if n.startswith(('bar','ub')):return'a'
 if n.startswith(('b','L')):return'L'
 if n.startswith('B'):return'B'
 if n.startswith('C'):return'C'
 if n.startswith('x_'):return'x'
 return'P'
for f,J,h,k in geo['field_source_h_k']:
 fi=names.index(base[f]);ji=names.index(base[J]);conj[fi]=ji;conj[ji]=fi;typ[fi]=kind(base[f]);typ[ji]='J'+typ[fi]
dim={'B':2,'x':2,'L':4,'C':2,'a':2,'P':3,'JB':4,'Jx':4,'JL':2,'JC':4,'Ja':4,'JP':3};gh={'B':0,'x':0,'L':0,'C':1,'a':-1,'P':0,'JB':-1,'Jx':-1,'JL':-1,'JC':-2,'Ja':0,'JP':-1};pa={'B':0,'x':0,'L':0,'C':1,'a':1,'P':1,'JB':1,'Jx':1,'JL':1,'JC':0,'Ja':0,'JP':0}
def co(p,ci,gp):
 z=0
 for xp,ep,mask,num,den in p['coefficients'][ci]:
  v=s.Rational(num,den)*xi**xp*eta**ep
  for j,q in enumerate([2,3,5,7]):
   if mask&(1<<j):v*=s.sqrt(q)
  if mask&16:v*=s.I
  z+=v
 return s.expand(z*g**gp)
targets=[('H_rho_JL_Cx','physical_G',1,['JL','C','x'],6),('T_u_Ja_Cx','physical_QG',0,['Ja','C','x'],8),('F_u_JL_CCx','physical_QG',0,['JL','C','C','x'],8)];results=[]
for label,family,probepar,targetword,fdim in targets:
 target=Counter(targetword);reverse=defaultdict(set)
 if role=='replay':
  # Enumerate all possible local root words independently of actual G,
  # then remove a cotangent slot and ask what actual G remainder is needed.
  for n in range(1,len(targetword)+2):
   for ww in combinations_with_replacement(sorted(dim),n):
    dd=sum(dim[t]for t in ww)
    if dd not in [6,8]or sum(gh[t]for t in ww)!=0 or sum(pa[t]for t in ww)%2:continue
    cc=Counter(ww)
    for t in cc:
     rest=cc.copy();rest[t]-=1
     if rest-target:continue
     need=tuple(sorted((target-rest).elements()));reverse[need,t].add(ww)
 allprobes=[]
 for probe,p in enumerate(a[family]):
  routes=[];excluded=[];inventory=Counter()
  for idx,(gp,w,ci)in enumerate(p['monomials']):
   inventory[sum(n in sources for n,I in w)]+=1
   for at,(n,I)in enumerate(w):
    if n not in conj:continue
    rem=w[:at]+w[at+1:];ct=Counter(typ.get(nn,'other')for nn,J in rem)
    if role=='primary':
     if ct-target:continue
     root=tuple(sorted(list((target-ct).elements())+[typ[conj[n]]]))
    else:
     cand=reverse.get((tuple(sorted(ct.elements())),typ[conj[n]]),set())
     if not cand:continue
     assert len(cand)==1;root=next(iter(cand))
    if any(J for nn,J in w):excluded.append({'monomial':idx,'derivative_position':at,'reason':'external_jet_outside_projection','root':root});continue
    nd=fdim-sum(dim[typ[nn]]for nn,J in w);nr=8-sum(dim[t]for t in root);assert nd+nr==2
    if nd<0 or nr<0 or nd>2 or nr>2:excluded.append({'monomial':idx,'derivative_position':at,'reason':'outside_retained_intrinsic_degree','root':root,'G_intrinsic_halfunits':nd,'C0_intrinsic_halfunits':nr});continue
    assert sum(gh[t]for t in root)==0 and sum(pa[t]for t in root)%2==0
    assert all(typ[nn]in ['JL','Ja','a','x','Jx','L','C','JC']for nn,J in w),('unhandled_surviving_Wick_role',label,probe,idx,w)
    pvar=par[names[n]];sg=(-1)**(pvar*sum(par[names[nn]]for nn,J in(w[:at]if role=='primary'else w[at+1:])))
    if role=='replay':sg*=(-1)**(pvar*((1 if family=='physical_G'else 0)-pvar))
    phase=-(-s.I)**sum(typ[nn]in ['JL','L']for nn,J in w)*(-1)**sum(typ[nn]=='Jx'for nn,J in w);pf=par[names[conj[n]]]if n in sources else pvar;v=s.expand(phase*sg*(-1)**(pf+probepar*pvar)*co(p,ci,gp))
    routes.append({'monomial':idx,'derivative_position':at,'generator_source_degree':sum(nn in sources for nn,J in w),'root':root,'generator_intrinsic_halfunits':nd,'root_intrinsic_halfunits':nr,'flow_output':names[conj[n]],'flow_remaining_word':[[names[nn],J]for nn,J in rem],'operation_coefficient':str(v),'generator_word':w})
  roots=Counter((tuple(q['root']),q['root_intrinsic_halfunits'])for q in routes);allprobes.append({'probe':probe,'full_source_inventory':dict(inventory),'routes':routes,'exclusions':excluded,'root_families':[{'word':w,'intrinsic_halfunits':n,'operation_routes':v}for(w,n),v in sorted(roots.items())]});print('STAGE ICR1',role,label,probe,'routes',len(routes),'families',len(roots),flush=True)
 results.append({'target':label,'generator':family,'probe_parity':probepar,'probes':allprobes})
out={'schema':'ICR1_COMPLETE_ACTUAL_REMAINING_SOURCE_ROOT_SUPPORT','role':role,'results':results,'types_not_quantum_amplitudes':True,'all_actual_generator_sources_kept_before_target_filtering':True,'native_quantum_or_desired_source_image_used':False,'complete_QAP_E5_A5_inferred':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('roots_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'target_family_counts':[[r['target'],[len(p['root_families'])for p in r['probes']],[len(p['routes'])for p in r['probes']]]for r in results],'scientific_authority_changed':False},sort_keys=True),flush=True);timer.cancel()
