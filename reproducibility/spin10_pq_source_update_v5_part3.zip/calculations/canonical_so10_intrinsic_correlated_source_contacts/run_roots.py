from pathlib import Path
from hashlib import sha256
import ast,json,gzip,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-correlated-source-contacts-v1-2026-10-25');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 A=O.parent/'canonical_so10_intrinsic_quadratic_source_contacts';b={}
 for n in ['AGENTS.md','CHARTER.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V628.md']:p=R/n;b[str(p)]=H(p)
 for n in ['final_review_validation_receipt.json','source_flow_validation_receipt_v3.json','RECORD.md','SOURCE_FLOW_CONTINUATION_V3.md']:p=A/n;b[str(p)]=H(p)
 for role in ['primary','replay']:
  p=A/('color_'+role+'_inputs.json.gz');b[str(p)]=H(p);z={'audit':load(p)['audit']};p=O/('roots_'+role+'_inputs.json.gz')
  with p.open('xb')as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
  b[str(p)]=H(p)
 for n in ['RECORD.md','roots.py','verify_roots.py','run_roots.py']:
  p=O/n;cp=O/(n+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(cp)]=H(cp)
 dump(O/'roots_preparation.json',{'input_sha256':b,'seconds_after_imports':300,'scientific_acceptance':'NOT_PERFORMED'})
 for role in ['primary','replay','verify']:
  if role=='verify':
   for n in ['roots_preparation.json']+[f'roots_{r}_{t}.json'+('.gz'if t=='tables'else'')for r in ['primary','replay']for t in ['tables','capture','result']]:p=O/n;b[str(p)]=H(p)
   dump(O/'roots_validation_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
  cmd=[sys.executable,'-B',str(O/('verify_roots.py'if role=='verify'else'roots.py'))]+([]if role=='verify'else[role]);z=capture(cmd);dump(O/('roots_'+role+'_capture.json'),z);dump(C/('roots_'+role+'_full_capture.json'),z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<(180 if role=='verify'else 300);dump(O/('roots_validation_receipt.json'if role=='verify'else'roots_'+role+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2;print('COMPLETED_ICR1',role,json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'roots_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
