from pathlib import Path
from hashlib import sha256
import json,gzip,time
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter()
for p,h in read(O/'contact_kernel_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('contact_kernel_'+r+'_tables.json.gz'))for r in ['primary','replay']]
for z in [a,b]:z.pop('role')
assert a==b and all(a['controls'].values())and len(a['fixtures'])==12
# All typed words belong to the retained Schur vertex classes. Four-edge
# words cannot be dropped from this inventory or folded into triangles.
d=load(O/'contact_support_primary_tables.json.gz');letters=d['letters'];families={}
for pr in d['results']:
 for w in pr['ordered_words']:
  assert len(w['letters'])in [2,3,4]
  for i in w['letters']:assert letters[i]['origin']in ['GF','JqLambda','rhoG0','rhoG1']
  families[len(w['letters'])]=families.get(len(w['letters']),0)+1
assert set(families)=={2,3,4}
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'paired_Gaussian_vs_ordered_Schur_ghost_determinant_pass':True,'all_12_fixtures_and_sensitive_controls_pass':True,'generic_heat_coefficients':a['generic_heat_coefficients'],'full_typed_word_counts_by_heat':families,'no_model_quantum_input_or_QAP_promotion':True},sort_keys=True),flush=True)
