from pathlib import Path
from hashlib import sha256
import json,gzip,time
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter()
for p,h in read(O/'contact_color_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('contact_color_'+r+'_tables.json.gz'))for r in ['primary','replay']]
for z in [a,b]:z.pop('role')
assert a==b and a['all_positions_per_tensor_probe']==91125 and not a['QAP_E5_A5_or_global_source_identity_inferred']
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'closed_45_index_paths_vs_full_90_auxiliary_matrix_products_all_tensors_and_zeros_agree':True,'all_positions_per_tensor_probe':91125,'probe_heat_group_positions':[{k:len(v)for k,v in z['heat_and_group_tensors'].items()}for z in a['results']],'antisymmetric_source_and_equal_source_zero_pass':True,'QAP_E5_A5_or_global_restoration':False},sort_keys=True),flush=True)
