# IAS6: the actual u-Ja-x companion operator

Freeze after IAS5's complete paired source calculation. Probe0 source kernel
is zero; probe1 has320 pole/chi4 and304 log(3/2) positions. This is not yet
a common full scalar/source correction. The next smallest necessary source
companion is u-Ja-x, one of IFC's five admissible source patterns.

Use the actual complete classical QG and original antighost field maps.
First check whether the original Ja action is exactly linear in integrated
fields. If so its fluctuation Hessian is zero, and first-probe proper Ja
dependence comes only from the direct u-QG source Hessian. If not, preserve
the extra terms and leave the proposed complete reduction incomplete.

Independently extract the actual single-Ja,A0 two-port BB and aC Hessians
from QG. Ja is even and its inherited Euclidean source phase is1; the
action Wick minus and B0 phases still apply. Compare the FULL tensors to
the completed rho-JLambda source Hessians only after this extraction.
The earlier qualified IGH identity QG_Ja=-2 G_JLambda is a comparator,
not an instruction to assign the answer. With JLambda phase -i the
corresponding Euclidean Hessian ratio would be -2i. Retain an actual
disagreement rather than fitting it away.

If the two complete admitted Hessians have that ratio, all unprobed
propagators, intrinsic inverse placements and ordered heats are identical
for these two source carriers. Linearity of the authenticated trace then
establishes C_(uJa x)=-2i C_(rhoJLambda x), without a redundant component
loop integration. This is structural reuse, not a new blind quantum test.
The selected paired density is (rho JLambda-2i u Ja)Lx. It is not declared
a full Q-exact functional: ghost-source, ordinary Euler and regulator
descendants remain to be measured or justified by applicable identities.

Keep L's symbolic chi4 and finite heat logarithm. No finite scheme chosen,
no coefficient determined from BBx, no all-counterterm/HB1C5 activation.
Both classical packets/left-right source routes, all coefficients/zeros,
source derivatives before restriction and all discarded unused fields must
be accounted for. One180s reviewer,8GiB sampled,350MiB floor,32MiB packet.
Freeze actual hashes/copies first; preserve any failed source/capture.
State113/34of39,E5/A5 OPEN,custodyexit2sevenNOTPASS unchanged. Full QAP,
source reality, measure/phase, physical limits and unification remain open.
