# IAS2+: actual intrinsic rho-JLambda-x finite conversion

Freeze October25,2026 at8949132844c3f6ad757441743f82cb5be392419a.
Previous goal turn PROGRESS: completed mixed bubble and restricted scalar-only
exclusion. A fresh app read now reports ACTIVE; the previous paused observation
remains historical evidence. Clean main, no matching research worker. No agents,
new branch/worktree, remote action, flavor/HB1C5 or scientific promotion.

Question: what does the actual proper one-loop rho-JLambda-x kernel measure
at first intrinsic GF/reference coefficient-dimension1, and can its measured
conversion support a correlated source/auxiliary completion? The ordinary
BBx witness is not an operand or fitting target. A sole scalar Euler shift
has been excluded in its universal-identity scope; this does not exclude the
larger admissible local family. The old ATS Cartesian JLambda-h-x zero does
not automatically apply to this actual rho-G insertion.

Domain: original unshifted SMA/CSW/EDS,A0,constant first odd rho,one auxiliary
BV source JLambda,one ordinary scalar x,zero external jets,all45 auxiliary
sources/328 scalars,both probes,symbolic g10,xi,eta_H. rho precedes JLambda
in the final coefficient. JLambda is odd, dimension1; rho has dimension1,
ghost1; G has dimension3,ghost-1. Sources are external, not integrated.
Common nonexceptional Euclidean local DIM-minus-strict-heat comparison.
Physical cubic/mass classes are distinct from the intrinsic GF coefficient;
no physical p0/scaleless integral, massive-vacuum limit or scheme adoption.

First derive the COMPLETE typed proper-loop carrier from actual physical G,
GF density, scalar/gauge Hessian programs and actual qLambda field maps.
The unprobed zero-grade reference is resummed. Represent its first intrinsic
perturbation by the actual Lx/xL vertex, not a guessed diagonal mass. Keep BB,
BL,LB,xx,Ca,aC Green types and zero LL; include every actual quadratic
source-rhoG vertex and source-free rhoG/source-qLambda companion. Internal
derivative placements and original raw/canonical charts remain explicit.
Ordinary unused fields must match external x/J exactly. In a proper one-loop
graph all vertices have two integrated ports; unmatched one-port source
vertices and unused ghost fields cannot be retained as proper Hessian loops.

Primary directed closed walks versus independently saturated grade multisets
and permutations must agree on every word/path, not only counts. Target
grade(n,rho,J,x)=(1,1,1,1); every non-resummed letter consumes positive grade,
so length<=4 is mathematical, not a resource truncation. All cyclic words
remain explicit with ordered-log weights and STr parity. Typed support alone
does not measure nonzero amplitudes, signs or finite normalization.

Then freeze separate bounded vertex/kernel/contraction records as needed.
Derive source phases and Grassmann Hessian signs using literal exterior
Gaussian versus a second contraction/elimination route before multiplying
actual tensors. Transport the actual source cotangent with the inverse
field charts; raw GF, canonical G and qLambda cannot be mixed by slot labels.
Keep each ordered heat length and analytic Lorentz D before finite extraction.
Do not assign a source coefficient from a desired Euler or Ward cancellation.
Retain chi4,b0,kappa as distinct symbolic normalization freedoms.

Expected evidence: complete carrier, actual vertices, genuinely distinct
coefficient computations including zeros, sensitive sign/port/heat controls,
and exact finite local result or a documented obstruction/underdefinition.
Unexpected action types, missing chart/phase, unmatched quantum input or
resource exhaustion make the affected increment incomplete, not PASS.
The final ordinary/source comparison must read completed quantum outputs
only after independent validation. No arbitrary fitted auxiliary matrix.

Per new sequential native support/vertex/color worker300s after imports;
reviewer/verifier180s.8GiB sampled private,350MiB available-pagefile launch
floor,32MiB whole packet. Freeze inputs/sources/copies before each computation.
Preserve every failed/unfinished source, capture and manifest; version routine
repairs prospectively without editing old evidence or weakening gates.

Authority ceiling: this relative proper source carrier and its tested local
conversion, not complete counterterm classification, HB1/C5, full chiral QAP,
measure/phase, source reality, quantum equivalence, E5/A5 or physicalGUT.
State113/34of39 and custodyexit2/sevenNOTPASS unchanged. Shared action/data,
charts/helpers/compiler/libraries and AI author limit independence. The
existing literature/qualified one-loop trace framework is a premise, not
independent confirmation of this model or its physical assumptions.
