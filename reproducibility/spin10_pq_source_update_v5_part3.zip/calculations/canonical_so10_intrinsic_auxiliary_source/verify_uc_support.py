from pathlib import Path
from hashlib import sha256
import gzip,json,time
O=Path(__file__).resolve().parent;tick=time.perf_counter();read=lambda p:json.loads(p.read_bytes())
for p,h in read(O/'uc_support_validation_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
a,b=[json.loads(gzip.decompress((O/('uc_support_'+r+'_tables.json.gz')).read_bytes()))for r in['primary','replay']]
for k in['letters','excluded','targets','fermion_cycle_cannot_consume_JLambda_grade','typed_words_not_nonzero_quantum_amplitudes','source_Grassmann_and_heat_signs_not_measured_by_this_inventory']:assert a[k]==b[k],k
out={'elapsed_after_imports':time.perf_counter()-tick,'complete_directed_walks_vs_grade_multisets_and_permutations_agree':True,'letters':len(a['letters']),'target_word_counts':[len(q['ordered_words'])for q in a['targets']],'families':[q['families']for q in a['targets']],'actual_finite_kernel_or_QAP_E5_A5_qualified':False}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
