from pathlib import Path
from hashlib import sha256
import gzip,ast,json,subprocess,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-auxiliary-source-v1-2026-10-25');P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(P));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 C.mkdir(exist_ok=False);base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert base=='8949132844c3f6ad757441743f82cb5be392419a';assert subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()=='main'
 dump(C/'start.json',{'HEAD':base,'previous_goal_turn':'PROGRESS','app_goal_observed':'active','scientific_acceptance':'NOT_PERFORMED'})
 with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r',base],cwd=R))
 b={}
 def bind(p):
  raw=p.read_bytes();assert raw==subprocess.check_output(['git','show',base+':'+p.relative_to(R).as_posix()],cwd=R);b[str(p)]=H(p)
 for name in['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V624.md','docs/RESEARCH_EXECUTION_HANDOFF_V623.md']:bind(R/name)
 assert H(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 for p in[Path(__file__).resolve(),O/'RECORD.md',O/'support.py',O/'verify_support.py']:
  if p.suffix=='.py':ast.parse(p.read_bytes())
  cp=O/(p.name+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  b[str(p)]=H(p);b[str(cp)]=H(cp)
 for role in['primary','replay']:
  ip=O.parent/'canonical_so10_intrinsic_kinetic_support'/('support_'+role+'_inputs.json.gz');sp=O.parent/'canonical_so10_cutoff_source_ward_operator'/(role+'_inputs.json.gz')
  for p in[ip,sp]:bind(p)
  d=load(ip);fm=load(sp)['field_maps'];aux={('b'if i<12 else'L')+str(i)for i in range(45)}
  z={'audit':{k:d['audit'][k]for k in['names','geometry','physical_G']},'GF':d['GF'],'physical_graphs':d['physical_graphs'],'qLambda':{n:fm[n]for n in sorted(aux)}}
  p=O/('support_'+role+'_inputs.json.gz')
  with p.open('xb')as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
  b[str(p)]=H(p)
 for folder,files in{'canonical_so10_intrinsic_B_Bx_bubble':['auxiliary_inventory_receipt.json','RESULT.md'],'canonical_so10_intrinsic_finite_conversion_module':['RESULT.md','RECORD.md'],'canonical_so10_auxiliary_tangent_source_kernel':['RESULT.md','validation_receipt_v2.json'],'canonical_so10_intrinsic_kinetic_support':['support_validation_receipt.json','vertex_validation_receipt_v4.json']}.items():
  for n in files:bind(O.parent/folder/n)
 bind(P/'export_a10_e5_antighost_vector.py')
 dump(O/'support_preparation.json',{'input_sha256':b,'seconds_after_imports':300,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':32*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
 for role in['primary','replay','verify']:
  if role=='verify':
   for n in['support_preparation.json']+[f'support_{r}_{t}.json'+('.gz'if t=='tables'else'')for r in['primary','replay']for t in['tables','capture','result']]:p=O/n;b[str(p)]=H(p)
   dump(O/'support_validation_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
  cmd=[sys.executable,'-B',str(O/('verify_support.py'if role=='verify'else'support.py'))]+([]if role=='verify'else[role]);z=capture(cmd)
  dump(O/('support_'+role+'_capture.json'),z);dump(C/('support_'+role+'_full_capture.json'),z)
  assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<(180 if role=='verify'else 300)
  dump(O/('support_validation_receipt.json'if role=='verify'else'support_'+role+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2
  print('COMPLETED_IAS2',role,json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'support_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
