from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-auxiliary-source-v1-2026-10-25');P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(P));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'color_validation_preparation.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 for n in['color_validation_preparation.json','color_validation_receipt.json','color_verify_capture.json']:p=O/n;b[str(p)]=H(p)
 inp={}
 for role in['primary','replay']:
  p=O.parent/'canonical_so10_intrinsic_kinetic_support'/('support_'+role+'_inputs.json.gz');b[str(p)]=H(p);inp[role]=str(p)
 p=O.parent/'canonical_so10_intrinsic_kinetic_support/replay_vertex_inputs.json.gz';b[str(p)]=H(p);inp['antighost_maps']=str(p);dump(O/'companion_inputs.json',inp);p=O/'companion_inputs.json';b[str(p)]=H(p)
 for n in['COMPANION_RECORD.md','companion.py','run_companion.py']:
  p=O/n;cp=O/(n+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(cp)]=H(cp)
 dump(O/'companion_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
 z=capture([sys.executable,'-B',str(O/'companion.py')]);dump(O/'companion_capture.json',z);dump(C/'companion_full_capture.json',z)
 assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
 rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<180;dump(O/'companion_receipt.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2
 print('COMPLETED_IAS6 '+json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'companion_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
