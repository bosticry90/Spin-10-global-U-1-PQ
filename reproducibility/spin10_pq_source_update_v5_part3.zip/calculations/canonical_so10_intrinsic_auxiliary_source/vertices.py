from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
from itertools import product
import gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
role=sys.argv[1];assert role in['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'vertex_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('vertex_'+('replay'if role=='primary'else'primary')):raise PermissionError('IAS3_PEER_DENIED')
sys.addaudithook(guard)
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(v):return s.expand(s.sympify(v,locals=loc))
cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);dec=lambda M:s.SparseMatrix(*M['shape'],{(i,j):parse(z)for i,j,z in M['entries']});clean=lambda z:{k:s.expand(v)for k,v in z.items()if s.expand(v)!=0};enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(z)]for(i,j),z in sorted(cl(M).todok().items())]};tab=lambda z:{tuple(q[:-1]):parse(q[-1])for q in z};encode=lambda z:[[ *k,str(v)]for k,v in sorted(clean(z).items())]
d=load(O/('vertex_'+role+'_inputs.json.gz'));a=d['audit'];names=a['names'];geo=a['geometry'];base=geo['names'];par={n:p for n,p in zip(base,geo['parities'])};sources={names.index(base[J]):base[f]for f,J,h,k in geo['field_source_h_k']};aux=[('b'if i<12 else'L')+str(i)for i in range(45)];ai={n:i for i,n in enumerate(aux)}
def kind(n):
 if n.startswith(('bar','ub')):return'a'
 if n.startswith(('b','L')):return'L'
 if n.startswith('B'):return'B'
 if n.startswith('C'):return'C'
 if n.startswith('x_'):return'x'
 return None
def ix(n):
 if n.startswith('bar'):return int(n[3:])
 if n.startswith('ub'):return int(n[2:])
 if n.startswith('B'):return int(n[1:].split('_')[0]),int(n.split('_')[1])
 return int(n[1:])
def coeff(p,ci,gp):
 z=0
 for xp,ep,mask,num,den in p['coefficients'][ci]:
  v=s.Rational(num,den)*xi**xp*eta**ep
  for j,q in enumerate([2,3,5,7]):
   if mask&(1<<j):v*=s.sqrt(q)
  if mask&16:v*=s.I
  z+=v
 return s.expand(g**gp*z)
rho=[];lorentz=0
for probe,p in enumerate(a['physical_G']):
 BB=defaultdict(lambda:0);AC=defaultdict(lambda:0);density={}
 for gp,w,ci in p['monomials']:
  js=[(j,n,I)for j,(n,I)in enumerate(w)if n in sources]
  if len(js)!=1:continue
  at,n,I=js[0]
  if sources[n]not in ai or I:continue
  rest=[(names[nn],JJ)for j,(nn,JJ)in enumerate(w)if j!=at];ks=[kind(nn)for nn,JJ in rest]
  if len(rest)!=2 or any(JJ for nn,JJ in rest)or sorted(ks,key=str)not in[['B','B'],['C','a']]:continue
  if role=='primary':sg=(-1)**sum(par[names[nn]]for nn,JJ in w[:at])
  else:sg=(-1)**sum(par[names[nn]]for nn,JJ in w[at+1:]) # odd G, odd source: right-to-left conversion +1
  z=sg*coeff(p,ci,gp);r=ai[sources[n]]
  if ks==['B','B']:
   (b,mu),(c,nu)=[ix(nn)for nn,JJ in rest];phase=s.I**int(mu==0)*s.I**int(nu==0);v=s.I*phase*z
   if role=='primary':
    BB[r,b,mu,c,nu]+=v;BB[r,c,nu,b,mu]+=v
   else:
    # Coefficient of an actual quadratic polynomial: diagonal derivative2,
    # distinct-coordinate cross derivatives1 in both ordered slots.
    if(b,mu)==(c,nu):BB[r,b,mu,c,nu]+=2*v
    else:BB[r,b,mu,c,nu]+=v;BB[r,c,nu,b,mu]+=v
  else:
   aa=next(ix(nn)for nn,JJ in rest if kind(nn)=='a');cc=next(ix(nn)for nn,JJ in rest if kind(nn)=='C')
   AC[r,aa,cc]+=s.I*z*(-1 if ks[0]=='C'else 1)
 BB=clean(BB);AC=clean(AC);T={}
 for(r,b,mu,c,nu),z in BB.items():
  assert mu==nu
  assert BB.get((r,c,nu,b,mu),0)==z
  if mu==3:T[r,b,c]=z
 for mu in range(4):assert {(r,b,c):z for(r,b,m,c,n),z in BB.items()if m==mu and n==mu}==T
 lorentz+=45*180*180
 rho.append({'probe':probe,'BB_Hessian_T':encode(T),'aC_density_U':encode(AC),'all_four_Lorentz_blocks_equal_and_offdiagonal_zero':True})
 print('STAGE_IAS3_G_SOURCE',role,probe,len(T),len(AC),flush=True)
# Exact raw field/source chart, no slot-based identification.
frame=d['frame'];order=frame['field_order'];xs=[f'x_{sec}_{i}'for sec,n in[('Phi',54),('Sigma',252),('phi',20),('S',2)]for i in range(n)];phys=[f'B{i}_{mu}'for i in range(45)for mu in range(4)]+xs+aux+['C'+str(i)for i in range(45)]+[('bar'if i<12 else'ub')+str(i)for i in range(45)];ri={n:i for i,n in enumerate(order)};pi={n:i for i,n in enumerate(phys)};TI=dec(frame['physical_to_raw_inverse']);TF=dec(frame['physical_to_raw_kernel'])
def block(ns):return TI.extract([ri[n]for n in ns],[pi[n]for n in ns]),TF.extract([pi[n]for n in ns],[ri[n]for n in ns])
TL,FL=block(aux);TC,FC=block(['C'+str(i)for i in range(45)]);TA,FA=block([('bar'if i<12 else'ub')+str(i)for i in range(45)])
for A,F in[(TL,FL),(TC,FC),(TA,FA)]:assert not cl(A*F-s.eye(45)).todok()and not cl(F*A-s.eye(45)).todok()
assert not cl(FC*dec(frame['raw_ghost_Green'])*FA.T-s.eye(45)).todok()
raw=defaultdict(lambda:0);cubic=0
for outname,rows in d['qLambda'].items():
 for row in rows:
  w=row['word']
  if len(w)==3:cubic+=1;continue
  assert len(w)==2 and sorted(kind(n)for n in w)==['C','L']
  c=next(ix(n)for n in w if kind(n)=='C');b=next(ai[n]for n in w if kind(n)=='L');raw[ai[outname],b,c]+=parse(row['coefficient'])
raw=clean(raw);beta=defaultdict(lambda:0)
if role=='primary':
 byF=defaultdict(list);byL=defaultdict(list);byC=defaultdict(list)
 for(r,k),z in FL.todok().items():byF[k].append((r,z))
 for(k,b),z in TL.todok().items():byL[k].append((b,z))
 for(k,c),z in TC.todok().items():byC[k].append((c,z))
 for(rr,aa,cc),z in raw.items():
  for(r,v),(b,w),(c,u)in product(byF[rr],byL[aa],byC[cc]):beta[r,b,c]+=v*z*w*u
else:
 rawm=[s.SparseMatrix(45,45,{(r,b):z for(r,b,c0),z in raw.items()if c0==c})for c in range(45)]
 for c in range(45):
  M=cl(FL*sum((TC[k,c]*rawm[k]for k in range(45)if TC[k,c]),s.zeros(45))*TL)
  for(r,b),z in M.todok().items():beta[r,b,c]=z
beta=clean(beta);B=s.SparseMatrix(2025,45,{(r*45+b,c):z for(r,b,c),z in beta.items()});S0=tab(d['S0']);S0mat=s.SparseMatrix(45,45*328,{(a,c*328+i):z for(a,c,i),z in S0.items()});N=dec(d['endings']['N0'])[45:,:];products=[]
def multiply(A,M):
 if role=='replay':return cl(A*M)
 by=defaultdict(list);out=defaultdict(lambda:0)
 for(k,j),z in M.todok().items():by[k].append((j,z))
 for(i,k),v in A.todok().items():
  for j,z in by[k]:out[i,j]+=v*z
 return cl(s.SparseMatrix(A.rows,M.cols,dict(out)))
for probe,q in enumerate(d['endings']['rho']):
 S=dec(q['direct']);JB=dec(q['J'])[:,:45];NN=cl(JB*N);Zs=[multiply(B,M)for M in[S,NN,S0mat]]
 shifted=s.SparseMatrix(45,328,{((a+1)%45,i):z for(a,i),z in S.todok().items()});bad=multiply(B,shifted)
 products.append({'probe':probe,'beta_Srho':enc(Zs[0]),'beta_JB_N':enc(Zs[1]),'beta_S0':enc(Zs[2]),'cyclic_ghost_row_shuffle_changed_positions':len(cl(bad-Zs[0]).todok()),'source_companions_zero_before_scalar_and_momentum_contraction':all(not M.todok()for M in Zs)})
 print('STAGE_IAS3_PORTS',role,probe,[len(M.todok())for M in Zs],flush=True)
out={'schema':'IAS3_ACTUAL_SOURCE_VERTICES_AND_PORTS','role':role,'rho_source_vertices':rho,'beta_JLambda_C_Lambda':encode(beta),'raw_linear_qLambda_rows':len(raw),'raw_cubic_qLambda_rows':cubic,'Lorentz_source_positions_block_checked':lorentz,'ghost_metric_I_verified_not_assumed':True,'port_products':products,'quantum_finite_coefficients_measured':False}
rawbytes=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(rawbytes,mtime=0)
with(O/('vertex_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(rawbytes).hexdigest(),'source_vertex_nonzero':[[len(q['BB_Hessian_T']),len(q['aC_density_U'])]for q in rho],'beta_nonzero':len(beta),'port_products_nonzero':[[len(q[k]['entries'])for k in['beta_Srho','beta_JB_N','beta_S0']]for q in products]},sort_keys=True),flush=True);timer.cancel()
