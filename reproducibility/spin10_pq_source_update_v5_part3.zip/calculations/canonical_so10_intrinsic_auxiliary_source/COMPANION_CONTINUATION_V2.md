# IAS6 V2: complete the actual nonlinear antighost-source carrier

V1 FAILED its scientific linearity premise. The actual map contains, e.g.,
q(ub13)=-sqrt(2)*i*g10*C1*ub13/2 plus other terms. Its original source,
source copy, preparation, complete native capture and controller failure
remain unchanged. No V1 receipt exists. This is an invalid proposed
reduction, not a parser failure or a PASS. The intended u-Ja-x question
and every original physical input/resource/acceptance obligation remain.

The corrected complete carrier includes the original Ja-aC Hessian A_r,
as well as the direct u-QG Ja BB/aC vertices. Project the actual original
antighost field maps: retain linear Lambda rows as Hessian0, all aC rows,
and stop on unexpected types. Differentiate before source restriction.
Transport raw a/ghost fields and the ANTIghost source cotangent with their
actual inverse blocks. Do not substitute the Lambda-source chart.

First audit the full source-free QG aC quadratic polynomial. If it is zero
as previously qualified, the original source ghost loop has only one
admitted first-probe scalar partner, the actual Su aC*x vertex. Ghost
propagators have no intrinsic grade1 reference deformation. All other
source-free u vertices contain unused ordinary fields or bosonic ports
that cannot join this all-ghost cycle. This proves the complete new class
is the two-edge bubble Tr(A_r Su_i), in addition to the direct kernels.
If the principal check fails, retain the extra class and stop incomplete.

Compute Tr(A Su) by explicit paths with direct raw substitution versus
source-column congruence and sparse matrix products, using each role's
independent action packet. Preserve all14760 source/scalar positions/zeros.
Use the already qualified even-source paired ghost-Hessian sign +Tr,
with no extra half. Keep m2 heat length4. A cyclic ghost-row shift is a
control; insensitive zero cases must be reported honestly.

The direct QG Ja Hessians are still independently extracted first and
tested against the actual -2i ratio to rho-JLambda. Only after that check
may trace linearity reuse the completed direct rho kernel. Add the newly
measured original-source bubble to its chi4 basis. No component is assigned
to make a relative Ward identity pass. Record whether the full ratio
survives; a nonzero extra term is an allowed scientific outcome.

One180s reviewer using both completed classical routes and distinct sparse
contractions,8GiB sampled,350MiB floor,32MiB packet. No resource expansion.
Freeze V2 sources/copies/actual inputs separately. Preserve the original
failed linearity test and classify the completed V2 family separately.
No broad source closure, Q-exactness, QAP/E5 or physical viability claim.
