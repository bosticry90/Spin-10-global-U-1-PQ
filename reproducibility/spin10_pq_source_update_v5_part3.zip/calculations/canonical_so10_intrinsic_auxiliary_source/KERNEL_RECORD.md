# IAS4: the two surviving universal source kernels

Freeze after IAS3 completes. The actual beta*S_rho,beta*Jrho_B*N and
beta*S0 port products are zero for both probes. IAS2's source-qLambda
companions therefore vanish before scalar or momentum contractions, even
with their distinct ordered heats. Their signs/heat lengths cannot be tested
by this zero; do not claim such sensitivity. The shifted-ghost control is
nonzero448positions for probe1 and insensitive for probe0.

Only direct rho-JLambda-BB and rho-JLambda-aC source Hessians remain.
Use T_r,ab as the true symmetric BB Hessian (density onehalf rho J T BB),
and U_r,ac as the aC density in rho J a C order. The physical scalar ending
has HX_Ba,x=-i q R_a, HX_x,Ba=+i q R_a. First-reference Green has
GN_Ba,x=+q n_a/Q^2,GN_x,Ba=-n_a q/Q^2. G0_BB=(delta+(w_a-1)qq/Q)/Q.
n is the actual complex N0_Lx coefficient, not an arbitrarily real version.

Derive -halfTr(G0 T GN HX+GN T G0 HX) using full Lorentz matrices and
separately closed indices. Check CartesianD3/4/5 and the expected absence
of a closed spectator: both paths end on q, so no analytic D jet remains.
The source ghost bubble is -halfSTr(G HU G HS), with G_Ca=+I,G_aC=-I;
check against direct -Trlog of the ghost determinant. No extra half or i
may be chosen after this comparison.

Both kernels are homogeneous Q^-2 after their numerator contraction.
The ghost bubble has two positive-heat edges (m2,length4); the BB/N bubble
has three (m3,length6), irrespective of cycle rotation. Thus, within the
qualified local relative radial prescription,
 C_DIM-heat=chi4(F2+F3)+log(3/2)F3, fixed D-jet0.
chi4 remains symbolic, not b0/kappa. Verify the radial difference by an
independent positive Frullani integral. No massless physical p0 integral
is assigned zero. Subleading integrable terms are outside this leading
local conversion and cancel between the compared prescriptions by the
inherited nonexceptional-domain premise; no full finite-p theorem is added.

Two300s kernel natives,verifier180s,8GiB sampled,350MiB floor,32MiB packet.
Freeze inputs/sources/copies before execution, retain all failures. Only
after qualification contract actual T/U/N/R/S0 independently by two routes.
No ordinary BBx or desired auxiliary/shear coefficient is an operand.
Scientific authority/state and all unqualified quantum/physical obligations
remain unchanged. Shared framework and AI author limit independence.
