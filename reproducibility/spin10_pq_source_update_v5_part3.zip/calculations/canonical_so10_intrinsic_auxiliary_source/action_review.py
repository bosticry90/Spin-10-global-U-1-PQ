from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import gzip,json,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'action_review_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta};vals={g:s.Integer(2),xi:s.Rational(3,2),eta:s.Rational(5,4)}
@lru_cache(None)
def parse(v):return s.expand(s.sympify(v,locals=loc).subs(vals))
cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v)for i,j,v in z['entries']});tab=lambda q:{tuple(z[:-1]):parse(z[-1])for z in q}
d=load(O/'color_primary_inputs.json.gz');v=load(O/'vertex_primary_tables.json.gz');q=load(O/'color_primary_tables.json.gz');R=list(map(dec,d['R']));N=dec(d['N']);last=s.SparseMatrix(45*328,328,{(a*328+j,i):z for a,M in enumerate(R)for(j,i),z in M.todok().items()});S0=tab(d['S0']);SM=s.SparseMatrix(2025,328,{(a*45+c,i):z for(a,c,i),z in S0.items()});I=s.eye(45);Z=s.zeros(45);HH=lambda M:Z.row_join(-M.T).col_join(M.row_join(Z));GG=HH(I).inv();assert GG[:45,45:]==I and GG[45:,:45]==-I
checks=0;oneNchanges=0;ghostsignchanges=0;witness=[]
for probe in[0,1]:
 T=tab(v['rho_source_vertices'][probe]['BB_Hessian_T']);U=tab(v['rho_source_vertices'][probe]['aC_density_U']);expectedG=dec(q['results'][probe]['F2_ghost']);expectedV=dec(q['results'][probe]['F3_vector'])
 for r in[0,12,13,33]:
  Um=s.SparseMatrix(45,45,{(a,c):z for(rr,a,c),z in U.items()if rr==r});PP=cl(GG*HH(Um)*GG);row={}
  for a in range(45):
   for c in range(45):
    z=s.expand((PP[c,45+a]-PP[45+a,c])/2)
    if z:row[0,a*45+c]=z
  Fg=cl(s.SparseMatrix(1,2025,row)*SM);assert not cl(Fg-expectedG[r,:]).todok();ghostsignchanges+=len(Fg.todok())
  for D in[3,4,5]:
   size=45*(D+1)+328;off=45*(D+1)
   for axis in[0,D-1]:
    G={};NN={};TT={}
    for a in range(45):
     b=a*D;ll=45*D+a;w=vals[eta]if a<12 else vals[xi]
     for mu in range(D):G[b+mu,b+mu]=w if mu==axis else 1
     G[b+axis,ll]=-1;G[ll,b+axis]=1
    for i in range(328):G[off+i,off+i]=1
    for(a,j),z in N.todok().items():NN[a*D+axis,off+j]=z;NN[off+j,a*D+axis]=-z
    for(rr,a,b),z in T.items():
     if rr==r:
      for mu in range(D):TT[a*D+mu,b*D+mu]=z
    GM=s.SparseMatrix(size,size,G);NM=s.SparseMatrix(size,size,NN);TM=s.SparseMatrix(size,size,TT);P1=GM*TM*NM;P2=NM*TM*GM
    def end(P):
     rr=defaultdict(lambda:0)
     for(i,j),z in P.todok().items():
      if i<45*D and i%D==axis and j>=off:rr[0,(i//D)*328+j-off]+=z
      if j<45*D and j%D==axis and i>=off:rr[0,(j//D)*328+i-off]-=z
     return cl((-s.I/2)*s.SparseMatrix(1,45*328,dict(rr))*last)
    Fv=cl(end(P1)+end(P2));assert not cl(Fv-expectedV[r,:]).todok(),(probe,r,D,axis)
    oneNchanges+=len(end(P2).todok());checks+=2*328
  witness.append({'probe':probe,'source':r,'ghost_nonzero':len(Fg.todok()),'vector_nonzero':len(expectedV[r,:].todok())})
out={'elapsed_after_imports':time.perf_counter()-tick,'full_Cartesian_gaussian_scalar_components_including_zeros':checks,'all_D3_D4_D5_both_momentum_orientations_match':True,'diagnostic_parameters_only':{'g10':'2','xi':'3/2','eta_H':'5/4'},'omit_one_inverse_placement_changed_comparisons':oneNchanges,'reverse_ghost_sign_changed_witness_positions':ghostsignchanges,'witnesses':witness,'full_Euler_QAP_E5_A5_authority':False}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
