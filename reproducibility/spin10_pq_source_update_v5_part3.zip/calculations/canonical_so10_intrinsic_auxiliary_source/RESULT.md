# Two complete intrinsic source carriers and the next nonlinear companion

October25,2026; base8949132844c3f6ad757441743f82cb5be392419a.
PROGRESS; scientific/director acceptance NOT_PERFORMED. State113/34of39,
E5/A5 OPEN,custodyexit2/sevenNOTPASS unchanged. The app goal was freshly
observed ACTIVE at recovery; the prior paused observation remains historical.

## Result and its implication

The actual proper one-loop rho-JLambda-x local finite conversion is now
calculated for all45 auxiliary sources/328 scalar directions,both probes,
with symbolic parameters. In hbar/(16pi^2) units, rho before JLambda,

    L = chi4 (F2+F3) + log(3/2) F3,
    F2_r,i = sum_ac U_r,ac S0_ca,i,
    F3_r,i = -i sum_abj w_a T_r,ab n_b,j R_a,ji.

T is the actual symmetric BB SOURCE HESSIAN, U is the aC source DENSITY,
n=N0_Lx is the original complex reference coefficient, and w_a is eta_H
or xi in its actual sector. No extra half or stripped Fourier phase.
The two source contributions carry different heat lengths and, in this
model, different coupling orders. They are not fitted to cancel each other.

Probe0 is identically zero. Probe1 has320 nonzero F2 positions,304 F3
positions, and320 positions in F2+F3. Thus the coefficient of symbolic
chi4 has320 positions and the finite log(3/2) carrier has304. The fixed
dimensional-jet contribution is zero. The nonzero F2+F3 is the unheated
local coefficient/baseline direction; it is not a demonstrated unremovable
physical ultraviolet divergence. chi4 remains unselected, distinct from
b0,kappa and other normalization questions.

For example, F2[12,206]=i sqrt(6) g10^2 xi^2/2 and
F3[13,136]=-2i sqrt(15) eta_H g10^3 xi/25. These are source coefficients
in the specified contour, not observed particles, masses or interactions.
No additional gauge-coupling factor was inserted to equate their orders.

The related complete u-Ja-x carrier obeys

    C_(uJa x) = -2i L.

That result required a correction to an attempted reduction. The original
antighost source is nonlinear and supplies an additional ghost bubble.
That bubble was independently contracted and found zero, so the ratio
survives for a qualified reason. It does not survive by assuming the source
action is linear. Both the failed premise and the corrected proof remain.

The measured selected paired density is

    sum_ri (rho JLambda_r - 2i u Ja_r) L_r,i x_i.

This is a relative quantum-source pair, not a complete Q-exact correction,
simultaneous renormalization prescription or restored Slavnov identity.
The u-JLambda-C-x carrier is still unmeasured. Its complete interaction
inventory has now been established as the next required calculation.

In particular the new probe0 source pair is zero. It does not supply a
nonzero source coefficient explaining away the earlier selected nonzero
probe0 BBx conversion. The restricted sole-scalar-translation exclusion
remains. Broader ordinary/source finite conversions remain open; no full
obstruction or Spin(10) refutation follows from these results.

## Domain and inputs

Original unshifted SMA/CSW/EDS,A0,constant first probe,one intrinsic GF/
reference coefficient of dimension1,zero external jets. All45 sources and
328 scalars,both probes,actual dual charts and symbolic g10,xi,eta_H.
Sources are differentiated before restriction and are not integrated.
This is the inherited common nonexceptional Euclidean local relative
DIM-minus-strict-heat construction. It is not a physical scaleless p=0
trace,full finite-p amplitude,physical vacuum or translated mass scheme.
Physical cubic/mass and higher-reference terms remain separate classes.

Actual G/QG density packets, raw source field maps, GF densities, reference
matrices, scalar kinetic R and classical S0/Su ghost-scalar vertices are
the operands. The known ordinary BBx remainder is not a computational
input to either source measurement. Earlier quantum source coefficients
are reused only after the direct-source operator relation is proved.

## IAS2/IAS3: complete proper source support and actual vertices

Directed closed walks and independent grade-multiset/permutation enumeration
agree on every ordered word/Green path:30 for probe0,70 for probe1,from25
typed letters. Target(n,rho,J,x)=(1,1,1,1) implies maximum length4 because
every non-resummed letter consumes positive grade. This is not a resource
cutoff. All cyclic rotations,source/internal ports and derivative placements
remain explicit. A count is support, not a nonzero quantum amplitude.

The source-free rho-G currents and original JLambda source action are
retained alongside direct rho-G source vertices. The original qLambda
contains180 raw CL rows and836 CCa rows. For THIS rho-JLambda-x target
the CCa source would leave an unused external ghost, so it has no proper
Hessian cycle. This exclusion does not apply to an external-C target.

Actual canonical source differentiation before restriction, all four
vector axes and off-diagonal Lorentz zeros give direct rho-JLambda source
Hessians/densities:

| Probe | BB Hessian T | aC density U |
| --- | ---: | ---: |
| 0 | 0 | 0 |
| 1 | 668 | 600 |

Left source derivatives versus right derivatives with the actual parity
conversion agree. The repeated-B derivative factor is retained. With
L_E=-L_M, B0_M=i B0_E,Lambda_M=-i Lambda_E and
JLambda_M=-i JLambda_E, the source G rows have the stated +i factor
before vector Wick phases. The original JLambda-CL source has net phase+1.
These are inherited conventions checked in the admitted action, not a
new physical source-reality or absolute phase theorem.

The original qLambda tensor beta_(r,a,c) is transported by the inverse
Lambda-source map, Lambda field map and separate ghost map. Direct raw
substitution versus one-ghost-column matrix congruence agree on334
nonzero canonical entries and all implicit zeros. The physical ghost
metric equals I only after its actual raw Green/chart calculation.

Every original-source companion factors through one of

    beta_flat S_rho,
    beta_flat (Jrho_B N0_Lx),
    beta_flat S0_flat.

All three COMPLETE products are zero for BOTH probes by explicit paths
and sparse matrix products. Their free source/auxiliary/scalar/ghost
indices remain before contraction with any scalar generator or momentum.
Thus their separately ordered heat contributions are zero within this
proper family. The old ATS zero was not imported. A cyclic ghost-row
shuffle changes448 positions for probe1; probe0 is insensitive. Phases
and heat lengths of these model-zero families cannot be inferred from
that zero alone.

## IAS4/IAS5: two nonzero kernels, full coefficients and finite extraction

The direct source BB bubble is

    -halfTr(G0 T GN HX + GN T G0 HX),
    GN_Ba,x=+q n_a/Q^2, GN_x,Ba=-n_a q/Q^2,
    HX_Ba,x=-i q R_a, HX_x,Ba=+i q R_a.

Full Lorentz matrices and independent closed-index contraction give the
stated F3. All paths end on q,so no closed Lorentz spectator or D jet
remains. CartesianD3/D4/D5 checks agree. The ghost bubble has
G_Ca=+I,G_aC=-I; its paired graded Hessian gives +Tr(U S0), agreeing
with the ghost determinant. There is no extra ghost/scalar half.

The ghost bubble has heat m2,length4; the reference-inverse BB bubble
has m3,length6. Their common radial extraction gives chi4(F2+F3) and
log(3/2)F3. Independent positive Frullani quadrature agrees at70-digit
precision (error below10^-65). No individual scaleless integral is set0.
The comparison of lower-symbol integrable remainders uses the inherited
nonexceptional-domain premise; this calculation does not prove a new
general finite-p or joint-regulator-limit theorem.

Actual model primary contractions use explicit ordered color paths and
the kinetic-action R matrices. Replay uses sparse products and reconstructs
R from the RAW scalar Qx source action with its actual ghost/scalar charts.
The entire R reconstruction agrees, SHA256
d6af5e8d4e0e3304504310767b32b98a82e3965d18f93daa6a8802a245bea1d8.
All147,600 F2/F3/finite-basis positions including zeros agree. The actual
constant-H covariance check beta_H L-L R_H is zero in all twelve raw
unbroken directions after the inverse ghost-frame transport. This is not
a complete varying-background or physical-source reality result.

Probe1 omission controls change320 chi4 positions when the ghost family
is omitted,304 when the vector family is omitted,304 finite logarithmic
positions if heat m3 is replaced by m2,and304 vector positions when all
widths are replaced by xi. Probe0 controls are honestly insensitive.

## IAS6: an invalid reduction caught, then the actual companion completed

The first companion native FAILED at its proposed linear-source gate:
the original map includes

    q(ub13) ... -sqrt(2)i g10 C1 ub13/2.

There are45 raw linear Lambda rows AND180 nonlinear Ca rows, yielding334
canonical ghost-source density positions. The failed source,copy,preparation,
full native capture and controller failure remain unchanged. It has no
validation receipt and is not PASS. This was a false scientific simplifying
premise,not a parser error. The initially proposed complete reduction was
therefore invalid,regardless of its eventual numerical conclusion.

V2 freezes the corrected actual carrier. It transports the antighost-source
cotangent with its OWN inverse field map,not the Lambda-source map. The
source-free QG ghost principal quadratic is checked zero from the complete
polynomial. The nonlinear original Ja source therefore adds the two-edge
bubble Tr(A_r Su_i). Direct raw substitution/ordered paths versus source
congruence/sparse products agree across all45x328 output slots,including
zeros. This bubble is zero for BOTH probes; a cyclic row shuffle changes
240 positions for probe1 and0 for probe0.

Meanwhile the direct QG-Ja BB/aC Hessians are independently extracted
from the actual QG packet before comparison. They agree with -2i times
the rho-JLambda Hessians on the entire admitted tensor,including all
Lorentz blocks and zeros. The inherited raw IGH identity QG_Ja=-2G_JLambda
is corroborated with its correct Euclidean source phases. Because all
unprobed propagators/reference insertions/ordered heats are then the same,
trace linearity supplies the direct quantum ratio. Adding the measured
zero original-source bubble establishes the FULL selected u-Ja-x ratio.

This uses an actual operator identity plus a new explicit contraction.
It is not another blind loop prediction or an independent full integration.
The valid ratio does not retroactively validate the original false premise.

## IAS7/IAS8: further checks and the next complete missing carrier

A full Cartesian Gaussian review uses sources0,12,13,33,all328 scalar
outputs,both probes,D3/4/5,two momentum orientations at exact diagnostic
g10=2,xi=3/2,eta_H=5/4. All31,488 scalar comparisons including zeros
agree with the completed symbolic tensors. Omitting one inverse placement
changes108 comparisons; reversing the ghost sign changes34 witness
positions. Source vertices and conventions remain shared. The diagnostic
is not adopted as a physical benchmark or extrapolated to the full tensor.

The next source pattern is u-JLambda-C-x. Its COMPLETE typed inventory,
using actual QG,GF,original qLambda and physical kinetic Hessians,now
agrees between directed walks and grade-multiset/permutation enumeration:
45 letters,448 words for probe0,726 for probe1. Target grade(1,1,1,1,1)
gives exact length bound5. All rotations and internal/external derivative
positions are retained. These are not448/726 independent integrations.

The original CCa auxiliary-source vertex now has one external C and two
internal ports. It MUST be retained; the previous no-external-ghost
exclusion cannot be transferred. Actual direct source-QG CCa,source CL
with old/probe currents,U/N0/Nr,Su/S0 and the positive-reference BBx
vertex also remain in their admitted words. No finite coefficient for
this carrier has yet been measured. The next action is to reduce these
words to compact ordered matrix families,then derive their signs/heats
and calculate coefficients before testing the common source conversion.
The general BBx triangle tensor remains outstanding and must still be
completed before a general ordinary kinetic/source theorem.

## Resource use, preservation and reference intake

All prospective300s/180s worker limits,8GiB sampled private cap,350MiB
available-pagefile launch floor and32MiB packet cap held. Largest native
sample234,741,760bytes; samples are not continuous process peaks.
After-import primary/replay/verifier seconds:
IAS2 4.6604517/2.2266109/.1074502;
IAS3 1.2243315/1.6930186/.0677081;
IAS4 .4988779/.3030892/.0487743;
IAS5 4.8358309/16.3174260/.0955129;
IAS6V2 19.9246178; IAS7 7.3997246;
IAS8 6.8759160/8.5599051/.4746534.

`python -B tools/research_check.py e4` completed native0,step exits
[0,0,0,0,0,2],custodysevenNOTPASS. This authenticates the sealed bounded
E4 evidence/authority contracts; it is not fresh replay of every historical
scientific calculation. The failed V1 is preserved separately from the
successful V2. No physical input, tolerance, gate or resource was weakened.
Full captures and before/index/after preservation seals are external under
intrinsic-auxiliary-source-v1-2026-10-25. Local main only,no push.

The two supplied October25 assessments were read as reference analysis,
not authority. The newer report correctly preserves the scalar-only
exclusion,requires the independent auxiliary/source kernel before a
comparison,and keeps the full BBx tensor open. Those requirements guided
this calculation. Its operational-pause discussion is historical: a fresh
app read confirmed ACTIVE at this recovery; no goal-mutating tool was used.

One qualification to the older assessment: its log(8/3) mass/source
discussion must remain historical and sign-dependent. The current IRR
result explicitly corrects the earlier FIM2 ordinary sewing interpretation;
IFC uses that corrected sign. The old expression is not current Gamma
evidence. A negative result about a proposed completion and a superseded
interpretation must not be conflated. This work uses the corrected inputs
and does not revalidate every historical claim in either assessment.

The demonstrated AI capabilities include complete source-type enumeration,
actual cotangent transport,independent kinetic/source R reconstruction,
graded determinant normalization and preservation of a false reduction.
The retained failure also shows that a plausible simplification can give
the eventual correct answer for an invalid reason. The additional actual
contraction was needed. Shared action,data,charts,helpers,compiler,libraries,
source conventions and AI authorship remain limits; no outside scientist,
proof-assistant or empirical validation is claimed.

Full source reality,chiral products/QAP,measure/global phase,nonlinear
contacts,varying probes/backgrounds,massive causal/constant-vacuum limits,
the failed physical benchmark,large scalar warning and gauge matching
remain separate. Flavor remains paused and HB1/C5 blocked. The investigation
and app goal remain ACTIVE/INCOMPLETE; nothing here promotes E5/A5 or
establishes physical Grand Unification.
