# IAS3: actual Euclidean source vertices and companion ports

Freeze after IAS2's two enumerations agree on30/70 words. First derive the
actual rho-JLambda-BB and rho-JLambda-aC vertices and original JLambda-C-Lambda
source tensor, without reading any ordinary BBx coefficient. G's canonical
source density and raw qLambda use different charts; retain that distinction.

Convention inherited from EDS/FIS/IGH: L_E=-L_M after B0_M=i B0_E,
Lambda_M=-i Lambda_E, JLambda_M=-i JLambda_E, derivative0_M=i derivative0_E.
rho is the independent formal Euclidean source, placed BEFORE JLambda.
Thus a derivative-free G source row has coefficient +i times its source-first
Minkowski coefficient, before the B0 phases. The ordinary source qLambda
C-Lambda vertex has net phase +1, since the two -i phases cancel action minus.
Verify all four vector axes, off-diagonal Lorentz zeros, external-source
odd ordering and repeated-B Hessian factors from the literal density.

Primary: left source differentiation and ordered two-port assignments,
raw field/source substitution for qLambda. Replay: right source derivative
with the odd-generator conversion and ghost-matrix/Hessian construction,
qLambda tensor congruence one ghost column at a time. Source cotangent uses
the inverse Lambda field map; ghosts use their own actual map. Verify the
free ghost metric and all inverse blocks before using an identity metric.

Use the authenticated CLASSICAL EDS rho J/direct S,N0 and classical S0
ghost-scalar density from the action, not an already measured quantum
rho-JLambda-x coefficient. At zero external jets, the original-source
companions factor through the following ghost-port products, before any
scalar R contraction or momentum integration:
 beta_flat*S_rho, beta_flat*(Jrho_B*N0_Lx), beta_flat*S0_flat.
beta_flat[(r,a),c] is the canonical source tensor. S0_flat[c,(b,i)] is its
actual antighost-row/ghost-column/scalar tensor. A zero product excludes
only the corresponding complete proper family. Do not import ATS's zero.
If a product is nonzero, keep it as a missing coefficient/kernel dependency.
The unused rho aLambda letters have no IAS2 closed words; no phase inference
is made from their absence. Retain the full source BB/Ca direct terms.

Compare all vertex coefficients/zeros and all three port products by
explicit sparse paths versus matrix products. A fixed cyclic ghost-row
shuffle is a negative control; disclose any insensitive case. No assertion
that the desired quantum answer or port product must be zero. Keep all
g10/xi/eta_H powers and Fourier phases. Failure is missing/unequal vertices,
invalid chart/metric, insufficient domain or bounded incomplete execution.

Two sequential300s natives,verifier180s,8GiB sampled,350MiB launch floor,
32MiB packet. Freeze sources/copies/inputs first; preserve all failures.
Scope is classical source-Hessian and actual port contraction, not finite
quantum normalization, full QAP/source reality/measure/E5 or physical GUT.
State113/34of39/custodyexit2sevenNOTPASS unchanged. Shared data,charts,
libraries, qualified conventions and AI author limit independence.
