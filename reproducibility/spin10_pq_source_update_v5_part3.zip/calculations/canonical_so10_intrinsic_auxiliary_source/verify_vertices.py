from pathlib import Path
from hashlib import sha256
import gzip,json,time
O=Path(__file__).resolve().parent;tick=time.perf_counter();read=lambda p:json.loads(p.read_bytes())
for p,h in read(O/'vertex_validation_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
a,b=[json.loads(gzip.decompress((O/('vertex_'+r+'_tables.json.gz')).read_bytes()))for r in['primary','replay']]
for k in['rho_source_vertices','beta_JLambda_C_Lambda','raw_linear_qLambda_rows','raw_cubic_qLambda_rows','Lorentz_source_positions_block_checked','ghost_metric_I_verified_not_assumed','port_products','quantum_finite_coefficients_measured']:assert a[k]==b[k],k
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'literal_source_left_vs_right_and_independent_qLambda_transport_agree':True,'all_three_port_products_and_zeros_agree':True,'source_vertex_nonzero':[[len(q['BB_Hessian_T']),len(q['aC_density_U'])]for q in a['rho_source_vertices']],'source_companions_zero':[q['source_companions_zero_before_scalar_and_momentum_contraction']for q in a['port_products']],'shuffle_control_changed_positions':[q['cyclic_ghost_row_shuffle_changed_positions']for q in a['port_products']],'full_finite_QAP_E5_A5_authority':False},sort_keys=True),flush=True)
