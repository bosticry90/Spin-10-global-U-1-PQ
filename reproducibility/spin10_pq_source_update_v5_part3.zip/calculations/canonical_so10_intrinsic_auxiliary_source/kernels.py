from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,gzip,sys,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());role=sys.argv[1];assert role in['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'kernel_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
wa,wb,na,nb,ra,rb,ta,tb,tab=s.symbols('wa wb na nb ra rb Taa Tbb Tab');rr=[ra,rb];nn=[na,nb];ww=[wa,wb];TT=s.Matrix([[ta,tab],[tab,tb]])
def trace(A,B):
 if role=='primary':return s.trace(A*B)
 aa=s.SparseMatrix(A).todok();bb=s.SparseMatrix(B).todok();return sum(v*bb.get((j,i),0)for(i,j),v in aa.items())
vals=[]
for D in[3,4,5]:
 size=2*D+3;x=size-1;G=s.zeros(size);N=s.zeros(size);T=s.zeros(size);X=s.zeros(size)
 for a in range(2):
  b=a*D;L=2*D+a
  for mu in range(D):G[b+mu,b+mu]=ww[a]if mu==0 else 1
  G[b,L]=-1;G[L,b]=1;N[b,x]=nn[a];N[x,b]=-nn[a];X[b,x]=-s.I*rr[a];X[x,b]=s.I*rr[a]
  for c in range(2):
   for mu in range(D):T[b+mu,c*D+mu]=TT[a,c]
 G[x,x]=1
 if role=='primary':F=s.expand(-(trace(G*T,N*X)+trace(N*T,G*X))/2)
 else:
  F=s.expand(-s.I*sum(ww[a]*TT[a,b]*nn[b]*rr[a]for a in range(2)for b in range(2)))
  direct=s.expand(-(trace(G*T,N*X)+trace(N*T,G*X))/2);assert s.expand(F-direct)==0
 vals.append(F)
assert all(s.expand(v-vals[0])==0 for v in vals)
assert s.expand(vals[0]+s.I*sum(ww[a]*TT[a,b]*nn[b]*rr[a]for a in range(2)for b in range(2)))==0
u=s.Matrix(2,2,s.symbols('u0:4'));v=s.Matrix(2,2,s.symbols('v0:4'));Z=s.zeros(2);HH=lambda A:Z.row_join(-A.T).col_join(A.row_join(Z));GG=HH(s.eye(2)).inv()
# Every internal field in this subspace is odd: STr=-Tr.
ghost=s.expand(s.trace(GG*HH(u)*GG*HH(v))/2);assert s.expand(ghost-s.trace(u*v))==0
mp.mp.dps=70;fr=mp.quad(lambda x:(mp.exp(-4*x)-mp.exp(-6*x))/x,[0,1,mp.inf]);assert abs(fr-mp.log(mp.mpf(3)/2))<mp.mpf('1e-65')
out={'schema':'IAS4_SURVIVING_SOURCE_KERNELS','role':role,'vector_F3':str(vals[0]),'ghost_F2':'Tr(U S0)','vector_heat_m':3,'ghost_heat_m':2,'analytic_D_independent_from_endpoint_support':True,'full_Cartesian_D_checked':[3,4,5],'dimensional_fixed_term':'0','relative_heat_log':'log(3/2)','Frullani_error':str(abs(fr-mp.log(mp.mpf(3)/2))),'no_model_color_coefficient_used':True}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('kernel_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'vector_F3':str(vals[0])},sort_keys=True),flush=True);timer.cancel()
