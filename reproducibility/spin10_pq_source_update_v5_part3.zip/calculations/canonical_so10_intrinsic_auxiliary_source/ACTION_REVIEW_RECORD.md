# IAS7: full Cartesian Gaussian review of the source coefficient

Freeze after IAS5 and IAS6V2 completed. Reconstruct the complete ordinary
bosonic free/reference matrices and paired90-dimensional ghost Gaussian
for sources0,12,13,33, all328 scalar outputs, both probes, CartesianD3/4/5,
two loop-momentum orientations. Exact diagnostic g2,xi3/2,eta_H5/4 only;
these are verification inputs, not a physical benchmark.

Compute the full -halfTr(G0 T GN HX+GN T G0 HX) by sparse matrix
products ending on the complete original scalar R, and compute the ghost
bubble with the paired graded Hessian, not a guessed scalar multiplicity.
Compare only afterward with the completed symbolic source tensors. Source
vertices and conventions are shared; this tests Lorentz, Gaussian, matrix
ordering, normalizations and actual colors, not independent physics premises.
Count complete scalar vectors including zeros. Dropping one intrinsic
inverse placement and reversing the ghost sign must be reported as controls.

One180s reviewer,8GiB sampled,350MiB floor,32MiB packet. Freeze completed
input hashes and new sources/copies first, preserve all failures. No new
quantum component or source/QAP/E5 authority is inferred from selected
diagnostic checks. The complete symbolic tensors are supported by IAS5's
distinct paths/sparse routes, not by witness extrapolation.
