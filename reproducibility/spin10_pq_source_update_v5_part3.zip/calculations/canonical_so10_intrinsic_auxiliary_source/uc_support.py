from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from itertools import combinations,permutations
import gzip,json,sys,os,time,threading
O=Path(__file__).resolve().parent
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'uc_support_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('uc_support_'+('replay'if role=='primary'else'primary')):raise PermissionError('IAS8_PEER_DENIED')
sys.addaudithook(guard)
d=load(O/('uc_support_'+role+'_inputs.json.gz'));a=d['audit'];names=a['names'];geo=a['geometry'];base=geo['names'];pairs=geo['field_source_h_k'];fields={names.index(base[f]):base[f]for f,J,h,k in pairs};sources={names.index(base[J]):base[f]for f,J,h,k in pairs};aux={('b'if i<12 else'L')+str(i)for i in range(45)};jl={i for i,f in sources.items()if f in aux};assert len(jl)==45
dims={'B':1,'x':1,'L':2,'C':1,'a':1};odd={'a','C'}
def kind(n):
 if n.startswith(('bar','ub')):return'a'
 if n.startswith(('b','L')):return'L'
 if n.startswith('B'):return'B'
 if n.startswith('x_'):return'x'
 if n.startswith('C'):return'C'
 return None
catalog=defaultdict(list);excluded=Counter()
def add(origin,n,u,J,ports,external,ref):
 if n not in [0,1]:excluded['other_coefficient_dimension']+=1;return
 if any(k not in['x','C']or jets for k,jets in external):excluded['other_external_field_or_jet']+=1;return
 if sum(k=='x'for k,j in external)>1 or sum(k=='C'for k,j in external)>1:excluded['higher_scalar_degree']+=1;return
 if not n and not u and not J and not external:excluded['resummed_zero_grade_reference']+=1;return
 key=(origin,n,u,J,sum(k=='x'for k,j in external),sum(k=='C'for k,j in external),ports[0][0],ports[1][0],ports[0][1],ports[1][1]);catalog[key].append(ref)
def ports(word,origin,n,u,J,ref):
 seq=((i,j)for i in range(len(word))for j in range(len(word))if i!=j)if role=='primary'else(pair for ij in combinations(range(len(word)),2)for pair in[ij,ij[::-1]])
 for i,j in seq:add(origin,n,u,J,[word[i],word[j]],[v for k,v in enumerate(word)if k not in[i,j]],[*ref,i,j])
# rho G: preserve sources outside the integrated Hessian.
for probe,p in enumerate(a['physical_QG']):
 for idx,(gp,word,ci)in enumerate(p['monomials']):
  Js=[n for n,I in word if n in sources]
  if any(n not in fields and n not in jl for n,I in word)or len(Js)>1:
   excluded['G_background_or_other_source']+=1;continue
  if any(I for n,I in word if n in jl):excluded['G_derivative_on_external_source']+=1;continue
  ww=[(kind(names[n]),len(I))for n,I in word if n in fields];assert all(k for k,j in ww)
  n=4-len(Js)-sum(dims[k]+j for k,j in ww)
  ports(ww,'uQG'+str(probe),n,1,int(bool(Js)),[idx])
# Ordinary GF includes the intrinsic resummed perturbation Lx, and the ghost-scalar vertex.
for idx,row in enumerate(d['GF']):
 ww=[]
 for v in row['word']:
  name,sep,jets=v.partition('__');k=kind(name)
  if k is None:break
  ww.append((k,len(jets)))
 else:ports(ww,'GF',4-sum(dims[k]+j for k,j in ww),0,0,[idx])
# Actual source field maps: cubic CCa is filtered only after its unused field is inspected.
for outname,rows in d['qLambda'].items():
 assert outname in aux
 for idx,row in enumerate(rows):
  ww=[]
  for v in row['word']:
   name,sep,jets=v.partition('__');k=kind(name);assert k
   ww.append((k,len(jets)))
  ports(ww,'JqLambda',3-sum(dims[k]+j for k,j in ww),0,1,[outname,idx])
for term in d['physical_graphs']:
 for idx,(parameters,nodes,coefficient)in enumerate(term['index_jet_graph_coefficients']):
  internal={};external=[]
  for node,name,indices,jets in nodes:
   if node!='Field':continue
   if name.startswith('h_'):internal['h']=(kind(name[2:]),len(jets))
   elif name.startswith('k_'):internal['k']=(kind(name[2:]),len(jets))
   else:external.append((kind(name),len(jets)))
  assert set(internal)=={'h','k'}and all(k for k,j in list(internal.values())+external)
  add(term['term_id'],0,0,0,[internal['h'],internal['k']],external,[idx])
letters=[]
for idx,k in enumerate(sorted(catalog)):
 origin,n,u,J,x,c,left,right,jl0,jr0=k
 letters.append({'id':idx,'origin':origin,'grade':[n,u,J,x,c],'H_ports':[left,right],'internal_jet_orders':[jl0,jr0],'member_references':sorted(catalog[k],key=str),'coefficient_chart':'canonical'if origin.startswith('uQG')else'raw'if origin in['GF','JqLambda']else'physical_Hessian_program'})
G={('B','B'),('B','L'),('L','B'),('x','x'),('C','a'),('a','C')};types=sorted(dims);target=(1,1,1,1,1)
sub=lambda a,b:tuple(x-y for x,y in zip(a,b));sat=lambda a:all(x>=0 for x in a)
allwords=[]
for probe in[0,1]:
 active=[L['id']for L in letters if sat(sub(target,L['grade']))and(not L['origin'].startswith('uQG')or L['origin']=='uQG'+str(probe))]
 opts={i:[(r,letters[i]['H_ports'][1])for r in types if(r,letters[i]['H_ports'][0])in G]for i in active};found=set()
 if role=='primary':
  edges={t:[]for t in types}
  for i in active:
   for r,c in opts[i]:edges[r].append((i,c))
  def walk(start,at,left,w,states):
   if not any(left):
    if at==start:found.add((tuple(w),tuple(states)))
    return
   for i,to in edges[at]:
    rem=sub(left,letters[i]['grade'])
    if sat(rem):walk(start,to,rem,w+[i],states+[to])
  for t in types:walk(t,t,target,[],[t])
 else:
  multis=[]
  def choose(lo,left,w):
   if not any(left):multis.append(tuple(w));return
   for pos in range(lo,len(active)):
    i=active[pos];rem=sub(left,letters[i]['grade'])
    if sat(rem):choose(pos,rem,w+[i])
  choose(0,target,[])
  for ms in multis:
   for w in set(permutations(ms)):
    def attach(at,states):
     if at==len(w):
      if states[-1]==states[0]:found.add((w,tuple(states)))
      return
     for r,c in opts[w[at]]:
      if states and states[-1]!=r:continue
      attach(at+1,(states or[r])+[c])
    attach(0,[])
 words=[]
 for w,st in sorted(found):
  assert len(w)<=5
  for j in range(len(w)):assert(w[j:]+w[:j],st[j:-1]+st[:j]+(st[j],))in found
  words.append({'letters':list(w),'Green_path':list(st),'STr_sign':(-1)**int(st[0]in odd),'ordered_log_weight':[(-1)**(len(w)+1),2*len(w)]})
 summaries=Counter((len(w['letters']),tuple(sorted(letters[i]['origin']for i in w['letters'])))for w in words)
 allwords.append({'probe':probe,'ordered_words':words,'families':[{'length':m,'origins':list(f),'words':n}for(m,f),n in sorted(summaries.items())]})
out={'schema':'IAS8_COMPLETE_TYPED_U_JLAMBDA_C_X_ENVELOPE','role':role,'letters':letters,'excluded':dict(excluded),'targets':allwords,'fermion_cycle_cannot_consume_JLambda_grade':True,'typed_words_not_nonzero_quantum_amplitudes':True,'source_Grassmann_and_heat_signs_not_measured_by_this_inventory':True}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('uc_support_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'letters':len(letters),'target_word_counts':[len(q['ordered_words'])for q in allwords],'families':[q['families']for q in allwords]},sort_keys=True),flush=True);timer.cancel()
