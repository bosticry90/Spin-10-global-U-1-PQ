from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'color_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('color_'+('replay'if role=='primary'else'primary')):raise PermissionError('IAS5_PEER_DENIED')
  if p.parent.name in['canonical_so10_intrinsic_B_Bx_bubble','canonical_so10_intrinsic_finite_conversion_module']:raise PermissionError('IAS5_ORDINARY_TARGET_DENIED')
sys.addaudithook(guard)
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(v):return s.expand(s.sympify(v,locals=loc))
cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v)for i,j,v in z['entries']});enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(v)]for(i,j),v in sorted(cl(M).todok().items())]};tab=lambda q:{tuple(z[:-1]):parse(z[-1])for z in q};clean=lambda z:{k:s.expand(v)for k,v in z.items()if s.expand(v)!=0}
d=load(O/('color_'+role+'_inputs.json.gz'));v=load(O/('vertex_'+role+'_tables.json.gz'));N=dec(d['N']);S0=tab(d['S0']);beta=tab(v['beta_JLambda_C_Lambda']);frame=d['frame'];xs=[f'x_{sec}_{i}'for sec,n in[('Phi',54),('Sigma',252),('phi',20),('S',2)]for i in range(n)];aux=[('b'if i<12 else'L')+str(i)for i in range(45)];phys=[f'B{i}_{mu}'for i in range(45)for mu in range(4)]+xs+aux+['C'+str(i)for i in range(45)]+[('bar'if i<12 else'ub')+str(i)for i in range(45)];ri={n:i for i,n in enumerate(frame['field_order'])};pi={n:i for i,n in enumerate(phys)};TI=dec(frame['physical_to_raw_inverse']);TF=dec(frame['physical_to_raw_kernel'])
def block(ns):return TI.extract([ri[n]for n in ns],[pi[n]for n in ns]),TF.extract([pi[n]for n in ns],[ri[n]for n in ns])
TC,FC=block(['C'+str(i)for i in range(45)]);Tx,Fx=block(xs)
if role=='primary':R=list(map(dec,d['R']))
else:
 xid={n:i for i,n in enumerate(xs)};raw=[s.SparseMatrix(328,328,{})for c in range(45)]
 for outname,rows in d['source_Qx'].items():
  for row in rows:
   w=row['word'];assert len(w)==2 and all('__'not in n for n in w);c=int(next(n[1:]for n in w if n.startswith('C')));j=xid[next(n for n in w if n.startswith('x_'))];raw[c][xid[outname],j]+=parse(row['coefficient'])
 R=[cl(Fx*sum((TC[k,c]*raw[k]for k in range(45)if TC[k,c]),s.zeros(328))*Tx)for c in range(45)]
assert all(not cl(M+M.T).todok()for M in R)
Rraw=(json.dumps(list(map(enc,R)),sort_keys=True,separators=(',',':'))+'\n').encode();Rhash=sha256(Rraw).hexdigest();print('STAGE_IAS5_R',role,Rhash,flush=True)
last=s.SparseMatrix(45*328,328,{(a*328+j,i):z for a,M in enumerate(R)for(j,i),z in M.todok().items()});Nby=defaultdict(list)
for(b,j),z in N.todok().items():Nby[b].append((j,z))
Rby=[defaultdict(list)for a in range(45)]
for a,M in enumerate(R):
 for(j,i),z in M.todok().items():Rby[a][j].append((i,z))
Sby=defaultdict(list)
for(a,c,i),z in S0.items():Sby[a,c].append((i,z))
Smat=s.SparseMatrix(2025,328,{(a*45+c,i):z for(a,c,i),z in S0.items()});results=[]
for probe,q in enumerate(v['rho_source_vertices']):
 T=tab(q['BB_Hessian_T']);U=tab(q['aC_density_U']);G=defaultdict(lambda:0);V=defaultdict(lambda:0);bad=defaultdict(lambda:0)
 if role=='primary':
  for(r,a,c),z in U.items():
   for i,w in Sby[c,a]:G[r,i]+=z*w
  for(r,a,b),z in T.items():
   wa=eta if a<12 else xi
   for j,n in Nby[b]:
    for i,w in Rby[a][j]:V[r,i]+=-s.I*wa*z*n*w;bad[r,i]+=-s.I*xi*z*n*w
  A=cl(s.SparseMatrix(45,328,dict(G)));B=cl(s.SparseMatrix(45,328,dict(V)));wrong=cl(s.SparseMatrix(45,328,dict(bad)))
 else:
  UM=s.SparseMatrix(45,2025,{(r,c*45+a):z for(r,a,c),z in U.items()});A=cl(UM*Smat);K=defaultdict(lambda:0);Kbad=defaultdict(lambda:0)
  for(r,a,b),z in T.items():
   for j,n in Nby[b]:K[r,a*328+j]+=(eta if a<12 else xi)*z*n;Kbad[r,a*328+j]+=xi*z*n
  B=cl(-s.I*s.SparseMatrix(45,45*328,dict(K))*last);wrong=cl(-s.I*s.SparseMatrix(45,45*328,dict(Kbad))*last)
 P=cl(A+B);bases={'chi4':P,'log3_over2':B,'fixed':s.SparseMatrix(45,328,{})};cov=[]
 for h in range(12):
  BH=s.SparseMatrix(45,45,{})
  for(r,a,c),z in beta.items():
   if FC[c,h]:BH[r,a]+=FC[c,h]*z
  RH=cl(sum((FC[c,h]*R[c]for c in range(45)if FC[c,h]),s.zeros(328)))
  cov.append([len(cl(BH*M-M*RH).todok())for M in[P,B]])
 controls={'omit_direct_ghost_changes_chi4':len(A.todok()),'omit_direct_vector_changes_chi4':len(B.todok()),'wrong_m3_as_m2_loses_log3_over2':len(B.todok()),'replace_all_widths_by_xi_changes_vector_positions':len(cl(B-wrong).todok())}
 results.append({'probe':probe,'F2_ghost':enc(A),'F3_vector':enc(B),'DIM_minus_heat_basis':{k:enc(M)for k,M in bases.items()},'H_covariance_remainder_counts':cov,'controls':controls})
 print('STAGE_IAS5_COLOR',role,probe,len(A.todok()),len(B.todok()),len(P.todok()),cov,flush=True)
out={'schema':'IAS5_COMPLETE_INTRINSIC_RHO_JLAMBDA_X_CONVERSION','role':role,'R_kinetic_or_source_reconstruction_sha256':Rhash,'results':results,'full_positions_per_matrix':45*328,'common_normalization':'hbar/(16pi^2); rho before JLambda; no extra half','chi4_unselected_not_b0_or_kappa':True,'full_Euler_QAP_E5_A5_authority':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('color_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'R_sha256':Rhash,'F2_F3_pole_positions':[[len(q[k]['entries'])for k in['F2_ghost','F3_vector']]+[len(q['DIM_minus_heat_basis']['chi4']['entries'])]for q in results]},sort_keys=True),flush=True);timer.cancel()
