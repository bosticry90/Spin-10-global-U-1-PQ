from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
import gzip,json,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'companion_preparation_v2.json')['input_sha256'].items():assert H(Path(p))==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta};parse=lambda v:s.expand(s.sympify(v,locals=loc));clean=lambda z:{k:s.expand(v)for k,v in z.items()if s.expand(v)!=0};tab=lambda q:{tuple(z[:-1]):parse(z[-1])for z in q};encode=lambda z:[[*k,str(v)]for k,v in sorted(clean(z).items())]
ip=read(O/'companion_inputs_v2.json');anti=load(Path(ip['antighost_maps']))['master_antighost_maps'];assert len(anti)==45
def kind(n):
 if n.startswith(('bar','ub')):return'a'
 if n.startswith(('b','L')):return'L'
 if n.startswith('B'):return'B'
 if n.startswith('C'):return'C'
 if n.startswith('x_'):return'x'
 if n.startswith('A'):return'A'
 return None
def ix(n):
 if n.startswith('bar'):return int(n[3:])
 if n.startswith('ub'):return int(n[2:])
 if n.startswith('B'):return int(n[1:].split('_')[0]),int(n.split('_')[1])
 return int(n[1:])
def co(p,ci,gp):
 z=0
 for xp,ep,mask,num,den in p['coefficients'][ci]:
  v=s.Rational(num,den)*xi**xp*eta**ep
  for j,q in enumerate([2,3,5,7]):
   if mask&(1<<j):v*=s.sqrt(q)
  if mask&16:v*=s.I
  z+=v
 return s.expand(z*g**gp)
allroles=[]
for role in['primary','replay']:
 a=load(Path(ip[role]))['audit'];names=a['names'];geo=a['geometry'];base=geo['names'];sources={names.index(base[J]):base[f]for f,J,h,k in geo['field_source_h_k']};rho=load(O/('vertex_'+role+'_tables.json.gz'))['rho_source_vertices'];result=[]
 for probe,p in enumerate(a['physical_QG']):
  BB=defaultdict(lambda:0);AC=defaultdict(lambda:0);patterns=Counter()
  for gp,w,ci in p['monomials']:
   js=[(at,n,I)for at,(n,I)in enumerate(w)if n in sources]
   if len(js)!=1:continue
   at,n,I=js[0]
   if kind(sources[n])!='a':continue
   assert not I
   rest=[(names[nn],J)for j,(nn,J)in enumerate(w)if j!=at]
   if any(kind(nn)=='A'or nn.startswith('J')for nn,J in rest):continue
   patterns[tuple(sorted(((kind(nn),len(J))for nn,J in rest),key=str))]+=1
   if len(rest)!=2 or any(J for nn,J in rest):continue
   ks=[kind(nn)for nn,J in rest];z=-co(p,ci,gp);r=ix(sources[n])
   if ks==['B','B']:
    (b,mu),(c,nu)=[ix(nn)for nn,J in rest];z*=s.I**int(mu==0)*s.I**int(nu==0);BB[r,b,mu,c,nu]+=z;BB[r,c,nu,b,mu]+=z
   elif sorted(ks,key=str)==['C','a']:
    aa=next(ix(nn)for nn,J in rest if kind(nn)=='a');cc=next(ix(nn)for nn,J in rest if kind(nn)=='C');AC[r,aa,cc]+=z*(-1 if ks[0]=='C'else 1)
   else:raise AssertionError(('UNEXPECTED_TWO_PORT_Ja',probe,rest))
  BB=clean(BB);AC=clean(AC);T={(r,b,c):z for(r,b,mu,c,nu),z in BB.items()if mu==nu==3}
  assert all(mu==nu for r,b,mu,c,nu in BB)
  for mu in range(4):assert {(r,b,c):z for(r,b,m,c,n),z in BB.items()if m==n==mu}==T
  for got,old in[(T,tab(rho[probe]['BB_Hessian_T'])),(AC,tab(rho[probe]['aC_density_U']))]:
   assert not clean({k:got.get(k,0)+2*s.I*old.get(k,0)for k in set(got)|set(old)})
  result.append({'probe':probe,'uJa_BB_Hessian':encode(T),'uJa_aC_density':encode(AC),'single_source_A0_patterns':[[str(k),v]for k,v in sorted(patterns.items(),key=lambda q:str(q[0]))],'actual_Euclidean_ratio':'-2*I','original_source_ghost_bubble_required':True})
 # Original antighost source: its nonlinear ghost Hessian is an additional loop owner.
 frame=load(O/('vertex_'+role+'_inputs.json.gz'))['frame'];xs=[f'x_{sec}_{i}'for sec,n in[('Phi',54),('Sigma',252),('phi',20),('S',2)]for i in range(n)];aux=[('b'if i<12 else'L')+str(i)for i in range(45)];ants=[('bar'if i<12 else'ub')+str(i)for i in range(45)];ghosts=['C'+str(i)for i in range(45)];phys=[f'B{i}_{mu}'for i in range(45)for mu in range(4)]+xs+aux+ghosts+ants;ri={n:i for i,n in enumerate(frame['field_order'])};pi={n:i for i,n in enumerate(phys)}
 cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v)for i,j,v in z['entries']});enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(v)]for(i,j),v in sorted(cl(M).todok().items())]}
 TI=dec(frame['physical_to_raw_inverse']);TF=dec(frame['physical_to_raw_kernel']);Ta=TI.extract([ri[n]for n in ants],[pi[n]for n in ants]);Fa=TF.extract([pi[n]for n in ants],[ri[n]for n in ants]);Tc=TI.extract([ri[n]for n in ghosts],[pi[n]for n in ghosts]);assert not cl(Fa*Ta-s.eye(45)).todok()
 maps=load(Path(ip['raw_maps_'+role]));maps=maps['field_maps']if role=='primary'else maps['master_antighost_maps'];rawA=defaultdict(lambda:0);linear=0;nonlinear=0
 for n in ants:
  for row in maps[n]:
   w=row['word'];assert all('__'not in v for v in w)
   if len(w)==1:assert kind(w[0])=='L';linear+=1;continue
   assert len(w)==2 and sorted(kind(v)for v in w)==['C','a'],(n,row)
   aa=next(ix(v)for v in w if kind(v)=='a');cc=next(ix(v)for v in w if kind(v)=='C');rawA[ix(n),aa,cc]+=-parse(row['coefficient'])*(-1 if kind(w[0])=='C'else 1);nonlinear+=1
 rawA=clean(rawA);A=defaultdict(lambda:0)
 if role=='primary':
  byF=defaultdict(list);byA=defaultdict(list);byC=defaultdict(list)
  for(r,k),z in Fa.todok().items():byF[k].append((r,z))
  for(k,b),z in Ta.todok().items():byA[k].append((b,z))
  for(k,c),z in Tc.todok().items():byC[k].append((c,z))
  for(rr,aa,cc),z in rawA.items():
   for r,v in byF[rr]:
    for b,w in byA[aa]:
     for c,u in byC[cc]:A[r,b,c]+=v*z*w*u
 else:
  rm=[s.SparseMatrix(45,45,{(r,b):z for(r,b,c0),z in rawA.items()if c0==c})for c in range(45)]
  for c in range(45):
   M=cl(Fa*sum((Tc[k,c]*rm[k]for k in range(45)if Tc[k,c]),s.zeros(45))*Ta)
   for(r,b),z in M.todok().items():A[r,b,c]=z
 A=clean(A);Su=load(Path(ip['ghost_'+role]))['probes'];quantum=load(O/('color_'+role+'_tables.json.gz'))['results']
 for probe,p in enumerate(a['physical_QG']):
  principal=defaultdict(lambda:0)
  for gp,w,ci in p['monomials']:
   if len(w)!=2 or any(n in sources for n,I in w):continue
   if sorted((kind(names[n])for n,I in w),key=str)==['C','a']:
    principal[tuple((names[n],tuple(I))for n,I in w)]+=co(p,ci,gp)
  assert not clean(principal),'NONZERO_u_GHOST_PRINCIPAL_REQUIRES_ANOTHER_CLASS'
  SS=tab(Su[probe]['Su']);extra=defaultdict(lambda:0);wrong=defaultdict(lambda:0);by=defaultdict(list)
  for(c,b,i),z in SS.items():by[c,b].append((i,z))
  if role=='primary':
   for(r,b,c),z in A.items():
    for i,w in by[c,b]:extra[r,i]+=z*w
    for i,w in by[(c+1)%45,b]:wrong[r,i]+=z*w
   X=cl(s.SparseMatrix(45,328,dict(extra)));W=cl(s.SparseMatrix(45,328,dict(wrong)))
  else:
   AM=s.SparseMatrix(45,2025,{(r,c*45+b):z for(r,b,c),z in A.items()});SM=s.SparseMatrix(2025,328,{(c*45+b,i):z for(c,b,i),z in SS.items()});WM=s.SparseMatrix(2025,328,{(((c-1)%45)*45+b,i):z for(c,b,i),z in SS.items()});X=cl(AM*SM);W=cl(AM*WM)
  baseQ=quantum[probe]['DIM_minus_heat_basis'];outC={}
  for key,M in baseQ.items():outC[key]=enc(cl(-2*s.I*dec(M)+(X if key=='chi4'else s.zeros(45,328))))
  result[probe].update({'original_Ja_aC_Euclidean_density':encode(A),'raw_qa_linear_rows':linear,'raw_qa_nonlinear_rows':nonlinear,'additional_two_edge_F2':enc(X),'full_uJa_DIM_minus_heat_basis':outC,'full_direct_plus_original_source_family_complete':True,'complete_conversion_ratio_holds':not X.todok(),'cyclic_row_shuffle_changed_positions':len(cl(W-X).todok()),'actual_u_ghost_principal_zero':True})
 allroles.append(result)
assert allroles[0]==allroles[1]
out={'schema':'IAS6_V2_COMPLETE_NONLINEAR_ANTIGHOST_SOURCE_COMPANION','results':allroles[0],'original_Ja_nonlinear_Hessian_retained':True,'full_direct_source_Hessian_ratio_verified':True,'trace_linearity_only_for_direct_part_extra_source_bubble_measured':True,'new_blind_loop_integration_claimed':False,'complete_Q_exact_or_QAP_E5_A5_authority':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'companion_v2_tables.json.gz').open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'uJa_BB_aC_nonzero':[[len(q['uJa_BB_Hessian']),len(q['uJa_aC_density'])]for q in allroles[0]],'extra_source_F2_nonzero':[len(q['additional_two_edge_F2']['entries'])for q in allroles[0]],'complete_selected_ratio_holds':[q['complete_conversion_ratio_holds']for q in allroles[0]]},sort_keys=True),flush=True);timer.cancel()
