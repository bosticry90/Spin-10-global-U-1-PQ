from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
import gzip,json,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'companion_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta};parse=lambda v:s.expand(s.sympify(v,locals=loc));clean=lambda z:{k:s.expand(v)for k,v in z.items()if s.expand(v)!=0};tab=lambda q:{tuple(z[:-1]):parse(z[-1])for z in q};encode=lambda z:[[*k,str(v)]for k,v in sorted(clean(z).items())]
ip=read(O/'companion_inputs.json');anti=load(Path(ip['antighost_maps']))['master_antighost_maps'];assert len(anti)==45
for n,rows in anti.items():
 for row in rows:assert len(row['word'])==1 and row['word'][0].startswith(('b','L'))and'__'not in row['word'][0],(n,row)
def kind(n):
 if n.startswith(('bar','ub')):return'a'
 if n.startswith(('b','L')):return'L'
 if n.startswith('B'):return'B'
 if n.startswith('C'):return'C'
 if n.startswith('x_'):return'x'
 if n.startswith('A'):return'A'
 return None
def ix(n):
 if n.startswith('bar'):return int(n[3:])
 if n.startswith('ub'):return int(n[2:])
 if n.startswith('B'):return int(n[1:].split('_')[0]),int(n.split('_')[1])
 return int(n[1:])
def co(p,ci,gp):
 z=0
 for xp,ep,mask,num,den in p['coefficients'][ci]:
  v=s.Rational(num,den)*xi**xp*eta**ep
  for j,q in enumerate([2,3,5,7]):
   if mask&(1<<j):v*=s.sqrt(q)
  if mask&16:v*=s.I
  z+=v
 return s.expand(z*g**gp)
allroles=[]
for role in['primary','replay']:
 a=load(Path(ip[role]))['audit'];names=a['names'];geo=a['geometry'];base=geo['names'];sources={names.index(base[J]):base[f]for f,J,h,k in geo['field_source_h_k']};rho=load(O/('vertex_'+role+'_tables.json.gz'))['rho_source_vertices'];result=[]
 for probe,p in enumerate(a['physical_QG']):
  BB=defaultdict(lambda:0);AC=defaultdict(lambda:0);patterns=Counter()
  for gp,w,ci in p['monomials']:
   js=[(at,n,I)for at,(n,I)in enumerate(w)if n in sources]
   if len(js)!=1:continue
   at,n,I=js[0]
   if kind(sources[n])!='a':continue
   assert not I
   rest=[(names[nn],J)for j,(nn,J)in enumerate(w)if j!=at]
   if any(kind(nn)=='A'or nn.startswith('J')for nn,J in rest):continue
   patterns[tuple(sorted(((kind(nn),len(J))for nn,J in rest),key=str))]+=1
   if len(rest)!=2 or any(J for nn,J in rest):continue
   ks=[kind(nn)for nn,J in rest];z=-co(p,ci,gp);r=ix(sources[n])
   if ks==['B','B']:
    (b,mu),(c,nu)=[ix(nn)for nn,J in rest];z*=s.I**int(mu==0)*s.I**int(nu==0);BB[r,b,mu,c,nu]+=z;BB[r,c,nu,b,mu]+=z
   elif sorted(ks,key=str)==['C','a']:
    aa=next(ix(nn)for nn,J in rest if kind(nn)=='a');cc=next(ix(nn)for nn,J in rest if kind(nn)=='C');AC[r,aa,cc]+=z*(-1 if ks[0]=='C'else 1)
   else:raise AssertionError(('UNEXPECTED_TWO_PORT_Ja',probe,rest))
  BB=clean(BB);AC=clean(AC);T={(r,b,c):z for(r,b,mu,c,nu),z in BB.items()if mu==nu==3}
  assert all(mu==nu for r,b,mu,c,nu in BB)
  for mu in range(4):assert {(r,b,c):z for(r,b,m,c,n),z in BB.items()if m==n==mu}==T
  for got,old in[(T,tab(rho[probe]['BB_Hessian_T'])),(AC,tab(rho[probe]['aC_density_U']))]:
   assert not clean({k:got.get(k,0)+2*s.I*old.get(k,0)for k in set(got)|set(old)})
  result.append({'probe':probe,'uJa_BB_Hessian':encode(T),'uJa_aC_density':encode(AC),'single_source_A0_patterns':[[str(k),v]for k,v in sorted(patterns.items(),key=lambda q:str(q[0]))],'actual_Euclidean_ratio':'-2*I','source_direct_trace_family_complete':True})
 allroles.append(result)
assert allroles[0]==allroles[1]
out={'schema':'IAS6_ACTUAL_ANTIGHOST_SOURCE_COMPANION','results':allroles[0],'original_Ja_action_linear_Hessian_zero':True,'full_direct_source_Hessian_ratio_verified':True,'trace_linearity_gives_complete_same_heat_conversion_ratio':True,'new_blind_loop_integration_claimed':False,'complete_Q_exact_or_QAP_E5_A5_authority':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'companion_tables.json.gz').open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'uJa_BB_aC_nonzero':[[len(q['uJa_BB_Hessian']),len(q['uJa_aC_density'])]for q in allroles[0]],'complete_selected_conversion_ratio':'-2*I'},sort_keys=True),flush=True);timer.cancel()
