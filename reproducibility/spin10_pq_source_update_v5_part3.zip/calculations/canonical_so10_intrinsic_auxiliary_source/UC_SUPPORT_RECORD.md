# IAS8: next complete source carrier, u-JLambda-C-x

Freeze after the actual rho-JLambda-x and u-Ja-x proper families complete.
The latter required an ORIGINAL nonlinear antighost-source ghost bubble,
which was measured zero; its direct ratio -2i survives for that qualified
reason, not V1's false linearity premise. Do not transfer either zero into
this next carrier. The original qLambda C-C-a source now has one external
ghost and TWO internal ports and is indispensable.

Question: determine the complete action-derived proper one-loop family for
the remaining IFC source pattern u JLambda C x at first intrinsic coefficient
dimension1. This is needed to assemble all five selected source carriers;
the new rho result or its formal source variation does not assign it.

Original unshifted SMA/CSW/EDS,A0,constant first u,one odd JLambda,one odd
external C,one scalar x,zero external jets,all45 source/ghost and328 scalar
directions,both probes. Retain classical physical QG and original qLambda
CL/CCa, full GF density and physical kinetic Hessian programs. Sources are
external; choose exactly two integrated ports at every proper-loop vertex.
Retain both choices of the external C in a CCa row, with their actual
ordered member references for later graded differentiation. No ghost sign
or nonzero amplitude is inferred from the support count.

Every non-resummed letter consumes a positive grade in(n,u,J,x,C).
The target(1,1,1,1,1) therefore has exact length bound5, not a numerical
truncation. Zero-grade reference is resummed; retain intrinsic N0 and
probe Nr/U vertices. Include principal ghost/scalar candidates from actual
QG before their verified zero. External derivatives give higher jets and
are excluded only from this zero-jet local carrier, not the full amplitude.
Retain all derivative placements on integrated ports, raw/canonical chart
identities, matrix order, Green orientation, cyclic rotations and STr parity.
No source quadratic is deleted because a related source family vanished.

Primary directed closed walks versus independently saturated grade
multisets/permutations must agree on all words/paths and all origin/port
references. Fermion cycles cannot contain JLambda: none of the actual
source-qLambda vertices has a fermion Hessian port. This remains a support
result and supplies no chiral-measure theorem or finite coefficient.

Two300s natives,verifier180s,8GiB sampled,350MiB floor,32MiB whole packet.
Freeze actual source copies/input hashes before execution. Preserve failures,
record exhaustion as incomplete, never silently truncate words. No parameter,
scheme, benchmark, action, authority or blocked-stage change. Source
normalization, all ordinary BBx triangles, full QAP/products/measure and
E5/A5 remain separate obligations. Next derive the actual few operator
families and select competent structural reductions before tensor expansion.
