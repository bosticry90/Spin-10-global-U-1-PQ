# IAS5: complete model-specific source coefficient and finite conversion

Freeze after IAS3/4 qualification. Contract ALL45 sources/328 scalars,
both probes, with symbolic actual parameters and phases:
 F2_r,i=sum_ac U_r,ac S0_ca,i,
 F3_r,i=-i sum_abj w_a T_r,ab n_b,j R_a,ji,
 w_a=eta_H for a<12,xi otherwise, n=N0_Lx.
T is the true BB Hessian, U the aC density. No extra half. IAS3's three
zero port products dispose of every JqLambda companion in IAS2; these
zeros do not set the two direct source families to zero.

Primary explicit ordered paths using the qualified actual kinetic R.
Replay sparse matrix products with R reconstructed afresh from the raw
scalar source action Qx and the actual scalar/ghost charts. Compare full
R hashes as well as every coefficient and zero of F2/F3/finite bases.
No known ordinary BBx/desired counterterm or rho-JLambda quantum result
may be read by either native. Only classical projections and qualified
universal/source-port evidence are operands.

The local conversion is chi4*(F2+F3)+log(3/2)*F3, no fixed D-jet.
Keep chi4 symbolic and report the actual pole sum, not an imposed zero.
Check constant H covariance using the raw twelve unbroken ghost directions
transported with the actual inverse ghost frame, and beta*L-L*R_H.
Record nonzero covariance remainders as limitations; do not fit them away.
No complete local-H background or physical-source reality theorem follows
from this constant transformation test.

Controls: omit ghost/direct vector, change the m3 heat length to m2,
replace all longitudinal widths by xi. Report insensitive cases honestly.
Gate requires paired exact whole tensors including zeros and classical
R reconstruction agreement; a nonzero finite result is permitted. If the
model coefficient vanishes, qualify only this actual proper source channel.
Only after validation compare to existing ordinary/source conversions.

Two300s natives,verifier180s,8GiB sampled,350MiB floor,32MiB whole packet.
Freeze actual inputs/code/copies before computation, preserve all failures.
Same original intrinsic local Euclidean domain, no scheme, physical input,
benchmark, finite baseline or scientific authority change. Full source
mixing/QAP/measure/chiral/physical limits and E5/A5 remain unqualified.
