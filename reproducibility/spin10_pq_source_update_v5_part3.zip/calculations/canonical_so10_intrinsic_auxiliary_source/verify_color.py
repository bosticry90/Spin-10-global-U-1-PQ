from pathlib import Path
from hashlib import sha256
import gzip,json,time
O=Path(__file__).resolve().parent;tick=time.perf_counter();read=lambda p:json.loads(p.read_bytes())
for p,h in read(O/'color_validation_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
a,b=[json.loads(gzip.decompress((O/('color_'+r+'_tables.json.gz')).read_bytes()))for r in['primary','replay']]
for k in a:
 if k!='role':assert a[k]==b[k],k
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'actual_kinetic_vs_source_R_reconstruction_agree':True,'explicit_paths_vs_sparse_products_full_coefficients_and_zeros_agree':True,'full_matrix_positions_compared':2*45*328*5,'nonzero_F2_F3_pole':[[len(q[k]['entries'])for k in['F2_ghost','F3_vector']]+[len(q['DIM_minus_heat_basis']['chi4']['entries'])]for q in a['results']],'H_covariance_all_zero':all(not n for q in a['results']for r in q['H_covariance_remainder_counts']for n in r),'full_Euler_QAP_E5_A5_authority':False},sort_keys=True),flush=True)
