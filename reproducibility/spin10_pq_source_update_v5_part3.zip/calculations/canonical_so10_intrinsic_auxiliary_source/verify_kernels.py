from pathlib import Path
from hashlib import sha256
import gzip,json,time
O=Path(__file__).resolve().parent;tick=time.perf_counter();read=lambda p:json.loads(p.read_bytes())
for p,h in read(O/'kernel_validation_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
a,b=[json.loads(gzip.decompress((O/('kernel_'+r+'_tables.json.gz')).read_bytes()))for r in['primary','replay']]
for k in a:
 if k!='role':assert a[k]==b[k],k
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'full_Lorentz_trace_vs_closed_indices_and_ghost_determinant_agree':True,'D_jet_zero_supported_not_assumed':True,'two_and_three_heat_lengths_and_Frullani_checked':True,'model_coefficient_or_QAP_E5_A5_authority':False},sort_keys=True),flush=True)
