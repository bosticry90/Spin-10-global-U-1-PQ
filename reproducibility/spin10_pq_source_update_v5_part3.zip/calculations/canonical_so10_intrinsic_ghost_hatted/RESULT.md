# Complete intrinsic hatted local limit and the actual QG tangent

October25,2026. PROGRESS,basee5a946c28795a8850699e780a5d939c92ea18604.
The selected u-C-PP hatted insertion now has a complete leading-local
support reduction and a uniform zero limit. The next ordered regulator
calculation also has a newly authenticated QG source-tangent input. The
full u-C-PP quantum Ward group and its counterterm remain unqualified.
State113/authority34of39 are unchanged,E5/A5 open,custodyexit2/sevenNOTPASS.

## Hatted insertion: complete support without deleting sterile propagation

Original unshifted action,constant first even u,A0,one ordinary external
ghost,two physical external fermions,external hats0,intrinsic coefficient-
dimension1. All scalar/ghost colors and generic Yukawas remain. This is
the leading-local Euclidean UV coefficient,not a full finite-p amplitude,
translated mass,physical vacuum or new subtraction prescription.

Directed walks and independent degree-saturated multiset/permutation
enumeration agree on420 ordered typed cycles. Physical external hats
remove140 only after enumeration. The280 retained cycles divide into:

| Insertion external port | Three vertices | Four vertices | Five vertices |
| --- | ---: | ---: | ---: |
| C |0|64|80|
| P |12|64|60|

These are ordered support words,not particles or independent integrals.
The sixth-order target is empty;the external/grade saturation excludes
all higher orders. Every retained word contains exactly one mixed PS/SP
propagator and an internal hatted derivative. The sterile field is not
discarded. The fixed-reference LL propagator is0,but its u response is
retained through the full actual Gr=-G0 U G0.

Actual coefficient checks establish both G0 Nr+Gr N0=0 in the B row
and the complete four ghost/scalar ending sum0,for both probes and all
colors/zeros. The check also finds the L-row mixed sum0;the proof needs
only the B projection. The retained positive-heat polynomials reduce to

    external C: E^4(1-E) times the actual mixed response,
    external P: E^3(1-E)P0-E^4(1-E)P2.

This preserves the finite heat differences rather than replacing the
insertion by its unfiltered zero. The qualified split inverse gives
the dimensional angular moments

    A1=-epsilon/(2-epsilon),
    A2=-2epsilon/[(2-epsilon)(3-epsilon)].

Both multiply positive combined radial differences with lengths3->4
or4->5. Gaussian radial integration and positive heat-length integration
agree in six finite cases;30 stored numerical comparisons meet1e-30.
Their50-digit stored values coincide;this is not exact certification
of numerical integration. Exact moment/antiderivative identities are
separate checks. Three joint paths also satisfy the analytic bounds.

The combined1-E improves the common IR degree4 to2. With0<=epsilon<=1/4,
0<c<=1 and fixed positive subtraction scale,the radial functions are
bounded independently of c,epsilon,while both angular moments are O(epsilon).
Keeping N c^epsilon proves the complete selected leading-local insertion
tends uniformly to0 under joint regulator removal. The finite-epsilon
universal kernels are nonzero;no full nonzero model coefficient tensor or
absolute phase is claimed evaluated. Dropping the hat-rank factor gives
a nonzero epsilon0 answer and is a sensitive control.

The nonexceptional-momentum interpretation uses the explicit finite-word
local-jet remainder and the inherited CSW/EDS/IHI domain premises in
PROOF.md. It is not an unrestricted constant-vacuum,nonlocal,causal or
renormalized product theorem.

## Full QG source derivatives and a useful exact reduction

All source derivatives were taken before source restriction. The left
and converted right derivatives agree,including derivative placements.
The raw source inventories distinguish G's rho transformation from QG's
u transformation. At A0 the unbroken QG source has60 linear candidates.
The broken QG source has461 linear and600 one-C candidates. Its4680
higher-field candidates and3410 derivatives leaving another source are
classified rather than silently erased. Counts refer to actual derivative
events;they are not independent counterterms.

A subsequent bounded calculation retains the full source-degree1 ordinary
polynomials,including background terms,B-B terms and C-a terms. It checks
the raw identity

    (QG)_Ja=-2 G_JLambda

at660 and2397 complete polynomial keys for the unbroken/broken probes.
Two source-derivative routes agree. Reversing the sign changes all3057
of those keys. Independent raw maps are saved before testing the identity.

In the existing Wick/evaluation-dual chart,the four-axis linear matrices
therefore obey

    R_u a=-2i X_G Lambda.

Every axis is checked over45x418 entries,including zeros,for each probe.
For example,the unbroken Euclidean map has

    R_u a=-2i div B+i eta_H Lambda,

with the derivative adjoints retained. The broken map also contains its
actual scalar row;its coefficient is fixed from QG,not a Ward remainder.
The600 nonlinear C-a terms remain in the stored full polynomial identity.

QG's auxiliary source additionally has3344 C-C-a terms for the broken
probe. Their first field tangent vanishes on the one-C mean ideal. Their
second source/field derivatives need not vanish;no connected product or
source-Euler term is declared zero from this first-tangent fact. This
boundary matters when the full Ward identity is assembled.

## Evidence, failures and resource limits

IGH1 preparation,primary,replay and verification completed on their first
frozen versions. IGH2's first controller stopped at ast.parse:two conditional
branches lacked whitespace (else45/else90). No tangent worker or mathematical
comparison ran. Original sources,partial preparation and full controller
traceback remain. TANGENT_CONTINUATION_V2 corrects the lexical tokens and
uses a new bound manifest;no physical input,identity gate or limit changed.
The V2 tangent calculation completed and the expected comparison passed.

| Stage | Seconds after imports | Samples | Maximum sampled private bytes |
| --- | ---: | ---: | ---: |
| Primary |2.2163482|2|142311424|
| Replay |2.2569088|2|142188544|
| Verifier |0.3251630|1|393216|
| Tangent V2 |3.6253901|3|157470720|

Samples are not continuous peaks. The short verifier has only a startup
sample. Worker caps300s,verifier/tangent120s,8GiBsampledprivate,
350MiBlaunchfloor and16MiBpacket held;no resource exhaustion or expansion.
Thirteen source copies;manifest bindings48/56/73. Receipt SHA256:

- IGH1:265b3b6eac5698f67145135fabac7b78ac1eab92f1cdd133564b820354c5f4f2.
- IGH2:2928843ff4cfdcb75d9922c51c01eae2e1be082364a622eb8d2dd52c58b36640.

External complete captures/readiness/preservation seals are retained under
intrinsic-ghost-hatted-v1-2026-10-25. E4 returned native0 with step exits
[0,0,0,0,0,2]. It authenticates existing evidence,not a new independent
physics replay;custody remains sevenNOTPASS. No
historical inputs,receipts,project_state or protected decisions are changed.

The capability result is a complete type reduction plus a uniform analytic
limit and a full source-polynomial identity. It demonstrates why an old
rho tangent cannot simply be reused as a u tangent. The syntax error is
a workflow failure,not a failed physical hypothesis. Shared action,source
charts,split-Clifford premises,software and AI author limit independence.
No external scientific validation or proof-assistant certificate is claimed.

## Continue with the actual ordered regulator coefficient

The regulator is fixed. Its first-u derivative contains both terms

    [STr(-Gt Vu Gt Rt M0+Gt Rt Mu)]_(C PP),

where Vu=(QG)'' and Mu is the actual QG tangent. Retain matrix order,
the antighost row of Mu,and M0's full allowed non-Abelian/source columns.
Do not substitute G's auxiliary row without the demonstrated row/phase
transport. The known ordinary and ISG1 scalar-source Euler coefficients
are late comparators,not values assigned to this unmeasured root.

The hatted leading-local zero removes one selected dependency;it neither
removes the regulator root nor turns ISG1's partial translation primitive
into a common renormalized prescription. Complete source/Euler support,
source-Hessian contacts,regulator joint limits in the grouped identity,
varying probes,translated masses,full IR/products,source reality,measure/
global phase,QAP/E5/A5,causal/physical limits and physical unification
remain open. The whole investigation remains ACTIVE/INCOMPLETE.
