# IGH2 preparation syntax correction

The first controller failed its ast.parse prelaunch check. Two conditional
expression branches lacked whitespace (else45/else90). No tangent worker
was launched and no mathematical comparison executed. Original tangent.py,
run_tangent.py,partially prepared record copy and complete controller
traceback remain unchanged. The failed preparation is not a failed physics
test or a completed calculation.

V2 corrects those two lexical tokens and points at its new manifest. Its
controller authenticates/preserves old sources/failure and freezes new
source copies before execution. The mathematical question,expected
identity,scope,resource limits and failure gates are unchanged. No
automatic retry under the old frozen attempt is claimed authorized.
