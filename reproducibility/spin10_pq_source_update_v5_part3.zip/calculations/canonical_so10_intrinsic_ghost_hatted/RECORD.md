# IGH1: actual u-source support and the intrinsic u-C-PP hatted local limit

Freeze before computation,October25,2026,basee5a946c28795a8850699e780a5d939c92ea18604.
Question: which full QG source gradients must the next intrinsic u-C-PP
Ward calculation retain,and does its independently defined Ihat insertion
have a surviving leading-local coefficient? ISG1 supplies measured source
inputs but cannot assign this insertion or the regulator root. This is the
least-cost structural test before another large coefficient expansion.

Original unshifted SMA/CSW/EDS action,A0,constant first even u,one ordinary
external C,two physical external P,external hats0,first intrinsic GF/reference
coefficient-dimension1. All328 scalars,45 ghost colors,both probes,general
Yukawas and the full P/S inverse remain. Local Euclidean UV jet,with compact
nonexceptional physical external momenta for its relative interpretation;
not a constant physical vacuum,translated mass or full finite-p calculation.

Audit the COMPLETE physical QG source polynomial before source restriction.
Primary left source derivatives and replay right derivatives converted by
the actual parity must agree. Preserve source derivative placements and
all surviving linear/one-C tangent candidates;source-degree>=2 terms are
deferred only after differentiation leaves another source. Inventory
background and higher-field terms explicitly. G's rho tangent is not QG's
u tangent. Do not assign the next root from known ordinary/source data.

Ihat has the actual E_C,E_P,E_S ports from SMA's mixed kinetic variation.
A bridgeless one-loop graph has two internal ports at every vertex. Thus
its insertion carries either external C/internal P,S or external P/internal
C,S. Enumerate the complete typed cycles,including the physical-external
hat terms BEFORE excluding them. Keep BB,BL,LB,xx,Ca,aC,PP,PS,SP,SS and the
actual zero LL free block. Include U_BB/BL/LL,N0_Lx,Nr_Bx/Lx,J0_aB/aL,
Ju_aB/aL,Su_ax and both matter endpoints. No favorable color selection.
Primary directed walks and replay degree-saturated multisets/permutations
must agree,including the empty sixth-order target. Each surviving cycle
must contain exactly one mixed PS edge and one hat derivative. Unexpected
types or unmatched actual action terms make this reduction incomplete.

Check actual B-projected Gr*N0+G0*Nr=0 and the full four-ending sum0,not
an inferred quantum cancellation. Then derive the positive heat families
and dimensional angular moments in PROOF.md. Compare radial differences
by direct Gaussian radial integration versus positive heat-length
integration. Keep combined IR-integrable kernels and Nc^epsilon. Exact
moment identities and uniform bounds,not a pointwise epsilon factor alone,
are required for a zero leading-local limit. No finite nonzero color
tensor,absolute phase or full root is claimed measured by this test.

Two sequential workers300s afterimports,verifier120s,8GiB sampled private,
350MiB launch floor,16MiB packet. Freeze inputs/code/copies/proof first;
preserve all failures/unfinished outputs. No resource growth or truncation.
Qualify bounded zero,nonzero,incomplete or underdefinition as evidence
allows. The support audit is not itself the regulator-root calculation.

State113/34of39,E5A5open,custodyexit2/sevenNOTPASS unchanged. No agents,
branch/worktree,push,outreach,publication,foundation/scheme/benchmark
adoption,flavor/HB1C5 activation or protected promotion. Shared action,
coordinates,Clifford conventions,software and AI author limit independence.
Reuse qualified split-inverse/master/support premises explicitly;no claim
of external validation or proof-assistant certification. After this test,
continue the actual ordered QG-tangent root and complete correlated Ward
group rather than installing a new normalization to force cancellation.
