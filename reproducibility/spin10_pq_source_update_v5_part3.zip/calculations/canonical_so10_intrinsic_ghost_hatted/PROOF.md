# Prospective support and uniform leading-local hatted limit

This proof requires the actual IGH1 native/verification receipts. It reuses
SMA's qualified split inverse and CSW's one-variation Hessian identity,
not a four-matrix surrogate or a vanishing full chiral defect. Ihat is
probe independent by the actual source-support theorem.

For a connected bridgeless unicyclic graph,each vertex has exactly two
internal ports. A vertex with three would require a one-port vertex and
a bridge. Ihat's cubic P,S,C density therefore has exactly one external
port. The three E_C/E_P/E_S derivative origins remain until physical
external hats are imposed. Two types survive:

1. External C at Ihat: two matter endpoints,one gauge and one scalar,
   one PP and one PS/SP edge,and the u-dependent mixed B-x response.
2. External P at Ihat: one scalar matter endpoint,one PS/SP edge,one
   ghost edge,and the complete external-C ghost-to-scalar u ending.

Other ordinary cubics with no admitted external label have three internal
ports. Scalar potentials cannot enter this saturated dimension-one class;
the complete MDS/EDS interaction-support certificate is an inherited
premise. Marginal u ghost/scalar principal changes were audited absent
by ISG1;repeat the actual check here rather than silently assuming it.

Let E be the leading local heat factor on each free edge and G0 the
longitudinal B/L inverse. Gr=-G0 U G0. For type1 the mixed response is

    -E^2 G0 Nr-E^3 Gr N0 = E^2(1-E) Gr N0

in its B row,only after the actual projected equality G0 Nr+Gr N0=0.
The two fermion heats multiply it to E^4(1-E). For type2 the three
ghost/scalar/mixed-fermion heats leave

    E^3[P0+E(P1+P3)+E^2 P2]
      = E^3(1-E)P0-E^4(1-E)P2,

after checking P0+P1+P2+P3=0 for every actual color/scalar entry. No
individual critically singular bare term is integrated separately.

In the qualified split Clifford inverse,PP has barred numerator and PS
has hatted numerator,each over Q=k_D^2. External hats0 make Ihat supply
another internal hat. In type2 this gives hatQ/Q;in type1 the unique
barred longitudinal gauge numerator and PP edge give barQ*hatQ/Q^2.
There is no closed spin trace or additional independent loop direction.
The dimensional Gaussian moment and separate sphere-contraction identities
in d=4-2e give

    A1=<hatQ/Q>=-e/(2-e),
    A2=<barQ hatQ/Q^2>=-2e/[(2-e)(3-e)].

These are analytic tensor moments,not negative fractions of physical
dimensions. General noncommuting color/Yukawa matrices multiply the
finite word family. A zero limit does not require assuming their signs
or computing a finite nonzero coefficient table.

After extracting1/(16pi^2),the combined positive radial difference is

    J_ab(e)=int_0^infinity x^(-1-e)(exp(-a*x)-exp(-b*x))dx/Gamma(2-e)
           =int_a^b l^(e-1)dl/(1-e)
           =(b^e-a^e)/[e(1-e)],

with J_ab(0)=log(b/a). Actual lengths are3,4 and4,5. The factor1-E
improves the common IR degree4 to2. For0<=e<=1/4,0<c<=1,

    0<J_ab(e)<=b^(1/4)log(b/a)/(3/4),
    |A1|<=4e/7, |A2|<=32e/77,
    N c^e<=max(1,(exp(gamma_E)*mu_R^2)^(1/4)),

for any fixed positive subtraction scale. Hence every leading-local
coefficient tends uniformly to0 under joint c,e->0. Individual finite-e
kernels need not vanish. Omitting the hat-rank factor gives a nonzero
epsilon0 result and is a sensitive negative control. Dropping1-E exposes
the critical IR node and invalidates this positive-integral argument.

For nonexceptional external momenta,the relative UV jet has the inherited
finite-word remainder degree k^-5. Positive heat shifts give O(sqrt(c));
barred external momenta do not remove the paired internal hat moment.
At finite loop momentum the distinct shifted nodes have soft degree<=3;
any merged critical local node must retain its own combined1-E. These
are the CSW/EDS/IHI local-test-field premises,not a new unrestricted
zero-momentum trace theorem. We qualify the complete leading-local
hatted coefficient and its bound;no full finite-p source product or
absolute insertion phase is reconstructed here.

The new QG source audit defines what must be used in the subsequent
ordered regulator root. Its normalization and coefficient are not set
from the source-Euler or ordinary results. A hatted zero does not make
the nonzero unmeasured regulator response dispensable. Full QAP,measure,
global phase,source reality,causal/physical limits,E5/A5 and physical
unification remain independent obligations.
