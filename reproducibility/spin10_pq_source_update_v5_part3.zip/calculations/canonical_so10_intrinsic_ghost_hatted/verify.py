from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/(r+'_tables.json.gz')) for r in ['primary','replay']]
for key in ['source_audits','actual_QG_principal_combined_checks','ending_checks','raw_typed_cycles','physical_typed_cycles','external_hat_cycles','physical_cycle_counts']:assert a[key]==b[key],key
assert len(a['source_audits'])==4 and a['physical_typed_cycles'] and a['external_hat_cycles'];assert all(len(w)<=5 for w in a['raw_typed_cycles'])
e=s.symbols('e',real=True);d=4-2*e;hat=-2*e;bar=4
# Sphere contraction and Gaussian differentiation give the same tensor ranks.
assert s.cancel(hat/d+e/(2-e))==0 and s.cancel(bar*hat/(d*(d+2))+2*e/((2-e)*(3-e)))==0
aa,bb=s.symbols('a b',positive=True);J=(bb**e-aa**e)/(e*(1-e));assert s.simplify(s.limit(J,e,0)-s.log(bb/aa))==0
assert s.simplify(s.diff(J,bb)-bb**(e-1)/(1-e))==0
mp.mp.dps=60;worst=mp.mpf(0);ncomp=0
for ra,rb in zip(a['radials'],b['radials']):
 for k in ['e','a','b']:assert ra[k]==rb[k]
 for k in ['J','A1J','A2J','bound_J','wrong_drop_hat_rank_epsilon0']:
  x,y=mp.mpf(ra[k]),mp.mpf(rb[k]);err=abs(x-y)/(1+abs(x)+abs(y));assert err<mp.mpf('1e-30');worst=max(worst,err);ncomp+=1
 if ra['e']=='0':assert mp.mpf(ra['A1J'])==mp.mpf(ra['A2J'])==0 and mp.mpf(ra['wrong_drop_hat_rank_epsilon0'])!=0
 else:assert mp.mpf(ra['A1J'])<0 and mp.mpf(ra['A2J'])<0
for ra,rb in zip(a['paths'],b['paths']):
 assert ra==rb and abs(mp.mpf(ra['rank1_kernel']))<=mp.mpf(ra['uniform_bound_rank1']) and abs(mp.mpf(ra['rank2_kernel']))<=mp.mpf(ra['uniform_bound_rank2'])
aud=[]
for z in a['source_audits']:
 aud.append({k:v for k,v in z.items() if k!='tangent_candidates'})
out={'schema':'IGH1_VALIDATION','elapsed_after_imports':time.perf_counter()-tick,'source_left_and_right_derivative_routes_agree':True,'source_audit_summaries':aud,'actual_ending_checks':a['ending_checks'],'walk_and_saturated_multiset_cycle_routes_agree':True,'raw_typed_cycles':len(a['raw_typed_cycles']),'physical_typed_cycles':len(a['physical_typed_cycles']),'external_hat_cycles_projected_after_enumeration':len(a['external_hat_cycles']),'physical_cycle_counts':a['physical_cycle_counts'],'sixth_order_target_empty':True,'Gaussian_radial_and_positive_length_routes_agree':True,'numeric_comparisons':ncomp,'maximum_scaled_discrepancy':mp.nstr(worst,40),'joint_paths':len(a['paths']),'split_rank_moments_checked_exactly':True,'wrong_omit_hat_rank_epsilon0_sensitive':2,'complete_leading_local_hatted_joint_limit':'ZERO','full_QG_tangent_root_full_Ward_QAP_E5_A5_or_authority':False}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
