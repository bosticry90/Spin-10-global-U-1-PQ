# IGH2: normalize the actual QG tangent before its ordered loop

Freeze after IGH1 completed/before this bounded computation. The actual
source audit finds QG source rows a and Lambda,not the rho-G row pattern.
For the broken probe it retains600 one-C a-a source-gradient candidates.
Question: can the full QG antighost source gradient be reduced to the
already authenticated G auxiliary source gradient,with its actual sign?
This is a classical source/Hessian reduction,not a root coefficient.

Read full physical G/QG,including background/quadratic-field/source terms.
Differentiate first,restrict remaining sources afterward. Compare complete
source-degree1 polynomial maps for each45 antighost/auxiliary row,including
source derivative positions and all ordinary field words. Primary left
and replay converted right derivatives are distinct. Test the prospective
raw identity (QG)_Ja=-2 G_JLambda;retain disagreement rather than fitting
its factor. The raw identity,if verified,means R_u a=-2i X_G Lambda in
the existing Wick/evaluation-dual conventions. Do not substitute a rho
tangent without transporting its row and odd variation.

Derive all four-axis Euclidean linear matrices with the actual source
phase and derivative adjoints. Compare raw extraction with the reduction
only after both raw polynomial maps are stored. Retain the full nonlinear
C-a maps and B-B/background terms in the polynomial identity. Actual
QG Lambda gradients may have C-C-a;they have zero first field tangent on
the one-C mean ideal,not zero full source Hessian or connected product.
No source Euler term,full Ward or measure is declared zero from that fact.

One sequential review120s afterimports,8GiBsampledprivate,350MiBlaunchfloor,
16MiBpacket shared with IGH1. Authenticate completed inputs/receipts and
freeze new code/copy first. Full polynomial identity,raw-factor/sign control,
independent source derivative comparison and exact four-axis substitution
are the gates. No counterterm,benchmark,scheme,authority,flavor/HB1C5 or
external action. Shared action/charts/software/AI-author limits remain.
After this reduction,calculate the full ordered u-C-PP regulator response
with both propagator and QG-tangent variations;do not infer its value
from the measured source/ordinary left side or the hatted zero.
