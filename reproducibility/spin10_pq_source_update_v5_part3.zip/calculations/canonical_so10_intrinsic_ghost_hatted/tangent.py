from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
import gzip,json,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'tangent_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True)
def kind(n):
 if n.startswith(('bar','ub')):return'a'
 if n.startswith(('L','b')):return'L'
 if n.startswith('B'):return'B'
 if n.startswith('C'):return'C'
 if n.startswith('x_'):return'x'
 if n.startswith('A'):return'A'
 raise AssertionError(n)
def index(n):
 if kind(n)=='a':return int(n[3:] if n.startswith('bar') else n[2:])
 if kind(n)=='L':return int(n[1:])
 if kind(n)=='B':return int(n[1:].split('_')[0])
 if kind(n)=='C':return int(n[1:])
 raise AssertionError(n)
def encode(M):return {'shape':list(M.shape),'entries':[[i,j,str(v)] for(i,j),v in sorted(M.todok().items()) if v]}
results=[]
for role in ['primary','replay']:
 d=load(O/(role+'_inputs.json.gz'));a=d['audit'];names=a['names'];par=a['parities'];base=a['geometry']['names'];sf={names.index(base[J]):base[i] for i,J,h,k in a['geometry']['field_source_h_k']};xs=[f'x_{ss}_{i}' for ss,nn in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(nn)];out=[]
 def coefficient(p,ci,gp):
  z=0
  for xp,ep,mask,nn,den in p['coefficients'][ci]:
   v=s.Rational(nn,den)*xi**xp*eta**ep
   for ii,prime in enumerate([2,3,5,7]):
    if mask&(1<<ii):v*=s.sqrt(prime)
   if mask&16:v*=s.I
   z+=v
  return s.expand(z*g**gp)
 for probe in range(2):
  maps=[];Lother=[]
  for fam in ['physical_G','physical_QG']:
   p=a[fam][probe];pp=1 if fam=='physical_G' else 0;vals=defaultdict(lambda:0)
   for gp,word,ci in p['monomials']:
    src=[(ii,nn,I) for ii,(nn,I) in enumerate(word) if nn in sf]
    if len(src)!=1:continue # derivative leaves a source,explicitly retained by IGH1
    ii,nn,I=src[0];row=sf[nn];remaining=tuple((names[v],tuple(J)) for jj,(v,J) in enumerate(word) if jj!=ii)
    sg=(-1)**(par[nn]*sum(par[v] for v,J in word[:ii])) if role=='primary' else(-1)**(par[nn]*sum(par[v] for v,J in word[ii+1:])+par[nn]*(pp+1))
    co=s.expand(sg*coefficient(p,ci,gp));rtype=kind(row)
    if (fam=='physical_G' and rtype=='L')or(fam=='physical_QG' and rtype=='a'):vals[(index(row),tuple(I),remaining)]+=co
    if fam=='physical_QG' and rtype=='L':Lother.append((row,remaining,str(co)))
   maps.append({k:s.expand(v) for k,v in vals.items() if s.expand(v)!=0})
  G,Q=maps;polys=[]
  for label,M in [('G_auxiliary',G),('QG_antighost',Q)]:
   polys.append({'label':label,'terms':[[r,list(I),[[n,list(J)] for n,J in w],str(v)] for(r,I,w),v in sorted(M.items())]})
  # Preserve before the comparison;wrong +2 orientation is independently tested.
  raw={'role':role,'probe':probe,'maps':polys}
  with(O/(f'tangent_{role}_{probe}_precheck.json')).open('xb') as f:f.write((json.dumps(raw,sort_keys=True)+'\n').encode())
  keys=set(G)|set(Q);res={k:s.expand(Q.get(k,0)+2*G.get(k,0)) for k in keys};assert not any(res.values());wrong=sum(s.expand(Q.get(k,0)-2*G.get(k,0))!=0 for k in keys);assert wrong>0
  assert all(len(w)==3 and sorted(kind(n) for n,J in w)==['C','C','a'] and all(not J for n,J in w) for row,w,v in Lother)
  four=[]
  for mu in range(4):
   Rg=s.zeros(45,418);Rq=s.zeros(45,418)
   for M,outM,sourcephase in [(G,Rg,-s.I),(Q,Rq,1)]:
    for(r,I,w),co in M.items():
     if len(w)!=1:continue
     nn,J=w[0];kk=kind(nn)
     if kk=='A':continue
     assert kk in ['B','L','x']
     if kk=='B' and not nn.endswith('_'+str(mu)):continue
     if any(j!=mu for j in I+J):continue
     phase=(-s.I if kk=='L' else s.I if kk=='B' and mu==0 else 1)*s.I**(sum(j==0 for j in I+J))
     z=co*sourcephase*phase*(-s.I)**len(I)*s.I**len(J);col=index(nn) if kk=='B' else45+index(nn) if kk=='L' else90+xs.index(nn);outM[r,col]+=z
   Rg=Rg.applyfunc(s.expand);Rq=Rq.applyfunc(s.expand);assert not(Rq+2*s.I*Rg).applyfunc(s.expand).todok()
   four.append({'mu':mu,'QG_antighost_linear':encode(Rq),'G_auxiliary_linear':encode(Rg),'complete_positions':45*418})
  nonlinear=sum(len(w)==2 and sorted(kind(n) for n,J in w)==['C','a'] for r,I,w in Q)
  out.append({'probe':probe,'raw_polynomial_keys_compared':len(keys),'raw_identity_QG_Ja_equals_minus2_G_JLambda':True,'wrong_plus2_orientation_nonzero':wrong,'nonlinear_Ca_terms_retained':nonlinear,'QG_auxiliary_CCa_terms':len(Lother),'QG_auxiliary_first_tangent_on_one_C_ideal_zero_only':True,'four_axes':four,'full_raw_polynomials':polys})
 results.append(out)
assert results[0]==results[1]
z={'schema':'IGH2_ACTUAL_QG_TANGENT','elapsed_after_imports':time.perf_counter()-tick,'left_and_right_full_polynomial_routes_agree':True,'results':results[0],'raw_identity':'QG_Ja=-2 G_JLambda','Wick_linear_identity':'R_u_a=-2i X_G_Lambda','QG_source_derivatives_taken_before_restriction':True,'full_quantum_root_or_Ward_QAP_authority':False};print('RESULT '+json.dumps(z,sort_keys=True),flush=True);timer.cancel()
