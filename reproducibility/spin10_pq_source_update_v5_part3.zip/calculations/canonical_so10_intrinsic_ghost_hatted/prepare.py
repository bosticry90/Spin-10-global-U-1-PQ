from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,ast
O=Path(__file__).resolve().parent;R=O.parents[1];read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();b={}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='e5a946c28795a8850699e780a5d939c92ea18604'
I=O.parent/'canonical_so10_intrinsic_hatted_insertion';S=O.parent/'canonical_so10_intrinsic_scalar_source_ghost';D=O.parent/'canonical_so10_probe_mass_dimension_one';im=read(I/'preparation_v2.json')['input_sha256'];sm=read(S/'preparation.json')['input_sha256']
for role in ['primary','replay']:
 ip=I/(role+'_v2_inputs.json.gz');sp=S/(role+'_inputs.json.gz');dp=D/('ending_'+role+'_inputs.json.gz')
 for p,m in [(ip,im),(sp,sm),(dp,sm)]:assert H(p)==m[str(p)];b[str(p)]=H(p)
 ii,ss,dd=map(load,[ip,sp,dp]);d={'hat_vertices':ii['hat_vertices'],'SMA':ii['SMA'],'endings':ss['endings'],'audit':{k:dd[k] for k in ['names','parities','geometry','physical_G','physical_QG']}}
 dst=O/(role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 b[str(dst)]=H(dst)
for folder,ns in [('canonical_so10_intrinsic_hatted_insertion',['RECORD.md','PROOF.md','LOCAL_GROUP_PROOF.md','validation_receipt.json','gaussian_validation_receipt.json']),('canonical_so10_intrinsic_scalar_source_ghost',['RECORD.md','DERIVATION.md','validation_receipt.json','review_receipt.json','shift_receipt.json']),('canonical_so10_probe_mass_dimension_one',['RECORD.md','ENDING_RECORD.md','ending_validation_receipt.json','symbol_receipt.json']),('canonical_so10_cutoff_source_ward_operator',['DERIVATION.md','validation_receipt.json']),('canonical_so10_chiral_probe_support',['DERIVATION.md','validation_receipt.json']),('canonical_so10_sterile_matter_action',['ACTION_V1.md','validation_receipt.json'])]:
 for name in ns:p=O.parent/folder/name;b[str(p)]=H(p)
for name in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V613.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:
 p=R/name;b[str(p)]=H(p)
for name in ['RECORD.md','PROOF.md','prepare.py','native.py','verify.py','run.py']:
 p=O/name
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(name+'.source.txt'))]=H(p)
with(O/'preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'worker_seconds_after_imports':300,'verifier_seconds_after_imports':120,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_IGH1',len(b),flush=True)
