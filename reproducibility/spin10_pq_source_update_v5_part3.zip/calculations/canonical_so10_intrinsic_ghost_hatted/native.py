from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import Counter
from itertools import combinations_with_replacement,permutations,product
import json,gzip,sys,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('replay' if role=='primary' else'primary'):raise PermissionError('IGH1_PEER_DENIED')
sys.addaudithook(guard);d=load(O/(role+'_inputs.json.gz'));g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.sympify(z,locals=loc)
dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v) for i,j,v in z['entries']});cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand)

# Full source gradients BEFORE restriction,using different derivative directions.
a=d['audit'];names=a['names'];par=a['parities'];base=a['geometry']['names'];sf={names.index(base[J]):base[i] for i,J,h,k in a['geometry']['field_source_h_k']};fields={names.index(base[i]) for i,J,h,k in a['geometry']['field_source_h_k']}
def kind(n):
 if n.startswith(('bar','ub')):return'a'
 if n.startswith(('L','b')):return'L'
 if n.startswith('B'):return'B'
 if n.startswith('C'):return'C'
 if n.startswith('x_'):return'x'
 if n.startswith('A'):return'A'
 return'other'
def coefficient(p,ci,gp):
 z=0
 for xp,ep,mask,nn,den in p['coefficients'][ci]:
  v=s.Rational(nn,den)*xi**xp*eta**ep
  for ii,prime in enumerate([2,3,5,7]):
   if mask&(1<<ii):v*=s.sqrt(prime)
  if mask&16:v*=s.I
  z+=v
 return s.expand(z*g**gp)
audits=[]
for fam in ['physical_G','physical_QG']:
 for probe,p in enumerate(a[fam]):
  pp=1 if fam=='physical_G' else 0;terms=[];counts=Counter();patterns=Counter();rowtypes=set()
  for gp,word,ci in p['monomials']:
   src=[(ii,nn,I) for ii,(nn,I) in enumerate(word) if nn in sf]
   if not src:continue
   for ii,nn,I in src:
    before=sum(par[v] for v,J in word[:ii]);after=sum(par[v] for v,J in word[ii+1:]);sg=(-1)**(par[nn]*before) if role=='primary' else(-1)**(par[nn]*after+par[nn]*(pp+1));co=s.expand(sg*coefficient(p,ci,gp));remaining=[(names[v],list(J)) for jj,(v,J) in enumerate(word) if jj!=ii];counts['full_source_derivatives']+=1
    if len(src)>1:counts['remaining_source_after_derivative']+=1;continue
    ks=[kind(z) for z,J in remaining];rowtypes.add(kind(sf[nn]));patterns[(kind(sf[nn]),tuple(sorted(ks)))]+=1
    # Save actual derivative placement;this is not yet a Wick/tangent normalization.
    if 'A' in ks:counts['background_columns_deferred_after_derivative']+=1;continue
    if len(ks)==1:category='linear'
    elif len(ks)==2 and 'C' in ks:category='one_C_tangent_candidate'
    else:counts['higher_field_or_other_deferred_after_derivative']+=1;continue
    counts[category]+=1;terms.append({'source':names[nn],'row':sf[nn],'source_derivatives':list(I),'remaining_word':remaining,'left_source_derivative_coefficient':str(co),'category':category})
  audits.append({'family':fam,'probe':probe,'counts':dict(sorted(counts.items())),'row_types':sorted(rowtypes),'patterns':[[rr,list(ks),nn] for(rr,ks),nn in sorted(patterns.items())],'tangent_candidates':sorted(terms,key=lambda z:json.dumps(z,sort_keys=True))})
print('STAGE IGH1 '+role+' complete G and QG source-gradient inventories',flush=True)

# Actual marginal QG principal ghost/scalar changes must be zero.
principal_counts=0
for p in a['physical_QG']:
 for mu in range(4):
  ghost={};scalar={}
  for gp,word,ci in p['monomials']:
   if len(word)!=2 or not all(nn in fields for nn,J in word):continue
   kk=[kind(names[nn]) for nn,J in word]
   if sorted(kk) not in [['C','a'],['x','x']] or sum(len(J) for nn,J in word)!=2 or not all(all(j==mu for j in J) for nn,J in word):continue
   co=coefficient(p,ci,gp)
   if sorted(kk)==['C','a']:
    ia=kk.index('a');ic=1-ia;na,I=word[ia];nc,J=word[ic];key=(names[na],names[nc]);ghost[key]=ghost.get(key,0)+(-1)**ia*co*(-s.I)**len(I)*s.I**len(J)
   else:
    for ia,ic in [(0,1),(1,0)]:
     na,I=word[ia];nc,J=word[ic];key=(names[na],names[nc]);scalar[key]=scalar.get(key,0)+co*(-s.I)**len(I)*s.I**len(J)
  principal_counts+=len(ghost)+len(scalar);assert all(s.expand(v)==0 for v in list(ghost.values())+list(scalar.values()))
ed=d['endings'];G=dec(ed['G0']);N=dec(ed['N0']);ending_checks=[]
for probe,rows in enumerate(ed['mixed']):
 Gr=dec(ed['probe_quadratics'][probe]['Gr']);Nr=dec(ed['probe_quadratics'][probe]['Nr']);U=dec(ed['probe_quadratics'][probe]['U']);assert not cl(Gr+G*U*G).todok();mixed=cl(Gr*N+G*Nr);assert not mixed[:45,:].todok()
 for z in rows:assert not cl(sum((dec(v) for v in z['pieces']),s.zeros(45,328))).todok()
 ending_checks.append({'probe':probe,'full_mixed_L_row_nonzero':len(mixed[45:,:].todok()),'B_projected_identity_positions':45*328,'four_ending_identity_positions':45*45*328})

# Typed insertion words. This deliberately includes external-hat origins.
assert len(d['hat_vertices'])==3 and d['SMA']['physical_antifield_copies']==1 and d['SMA']['auxiliary_BRST_transform']=='0'
for v in d['hat_vertices']:
 assert sorted(p for p,J in v['ports'])==['P','S','c'] and sum(J=='h' for p,J in v['ports'])==1
edges={'B':['B','L'],'L':['B'],'x':['x'],'C':['a'],'a':['C'],'P':['P','S'],'S':['P','S']};families={}
def vf(n,a,b,deg,external_hat=False):
 families[n]=[(a,b,n,tuple(deg),external_hat)]
 if a!=b:families[n].append((b,a,n,tuple(deg),external_hat))
vf('gP','B','P',[1,0,0,0,0]);vf('yP','x','P',[1,0,0,0,0]);vf('N0','L','x',[0,0,0,1,0])
for aa,bb in [('B','B'),('B','L'),('L','L')]:vf('U_'+aa+bb,aa,bb,[0,0,1,0,0])
for bb in ['B','L']:
 vf('Nr_'+bb+'x',bb,'x',[0,0,1,1,0]);vf('J0_a'+bb,'a',bb,[0,1,0,0,0]);vf('Ju_a'+bb,'a',bb,[0,1,1,0,0])
vf('Su_ax','a','x',[0,1,1,1,0])
for origin in ['E_C','E_P','E_S']:
 vf('I_C_'+origin,'P','S',[0,1,0,0,1],origin=='E_C');vf('I_P_'+origin,'C','S',[1,0,0,0,1],origin=='E_P')
vv=sum(families.values(),[]);target=(2,1,1,1,1);cycles=[]
def pack(vs):return tuple((vs[(ii-1)%len(vs)][1],aa,aa,bb,nn,eh) for ii,(aa,bb,nn,dd,eh) in enumerate(vs))
if role=='primary':
 for size in range(1,7):
  for start in edges:
   paths=[(start,(0,0,0,0,0),())]
   for step in range(size):
    nxt=[]
    for cur,deg,word in paths:
     for mid in edges[cur]:
      for aa,bb,nn,dd,eh in vv:
       new=tuple(deg[ii]+dd[ii] for ii in range(5))
       if aa==mid and all(new[ii]<=target[ii] for ii in range(5)):nxt.append((bb,new,word+((cur,mid,aa,bb,nn,eh),)))
    paths=nxt
   cycles.extend(word for cur,dd,word in paths if cur==start and dd==target)
else:
 labels=sorted(families);dg={n:families[n][0][3] for n in labels}
 for size in range(1,7):
  for bag in combinations_with_replacement(labels,size):
   if tuple(sum(dg[n][ii] for n in bag) for ii in range(5))!=target:continue
   for ordering in set(permutations(bag)):
    for vs in product(*(families[n] for n in ordering)):
     if all(vs[ii][0] in edges[vs[(ii-1)%size][1]] for ii in range(size)):cycles.append(pack(vs))
cycles=sorted(cycles);assert cycles and len(cycles)==len(set(cycles));physical=[];projected=[];cycle_counts=Counter()
for word in cycles:
 ns=[z[4] for z in word];ins=next(n for n in ns if n.startswith('I_'));family=ins[:3];assert len(word)<=5 and sum({z[0],z[1]}=={'P','S'} for z in word)==1
 if family=='I_C':assert ns.count('gP')==ns.count('yP')==1 and not any(n.startswith(('J0','Ju','Su')) for n in ns)
 else:assert family=='I_P' and ns.count('yP')==1 and 'gP' not in ns and sum(n.startswith(('J0','Ju','Su')) for n in ns)==1
 if any(z[5] for z in word):projected.append(word)
 else:physical.append(word);cycle_counts[(family,len(word))]+=1
assert physical and projected
print('STAGE IGH1 '+role+' complete typed cycles '+str(len(cycles)),flush=True)

# Independent Gaussian-radial versus positive heat-length integration.
mp.mp.dps=60;fmt=lambda z:mp.nstr(z,50);radials=[]
for ee in ['0','0.1','0.2']:
 e=mp.mpf(ee)
 for aa,bb in [(3,4),(4,5)]:
  if role=='primary':J=mp.quad(lambda x:x**(-1-e)*(mp.exp(-aa*x)-mp.exp(-bb*x)),[0,1,mp.inf])/mp.gamma(2-e)
  else:J=mp.quad(lambda ll:ll**(e-1),[aa,bb])/(1-e)
  expected=(bb**e-aa**e)/(e*(1-e)) if e else mp.log(mp.mpf(bb)/aa);assert abs(J-expected)/(1+abs(J))<mp.mpf('1e-30');A1=-e/(2-e);A2=-2*e/((2-e)*(3-e));bound=bb**mp.mpf('.25')*mp.log(mp.mpf(bb)/aa)/mp.mpf('.75');assert 0<J<=bound
  radials.append({'e':ee,'a':aa,'b':bb,'J':fmt(J),'A1J':fmt(A1*J),'A2J':fmt(A2*J),'bound_J':fmt(bound),'wrong_drop_hat_rank_epsilon0':fmt(mp.log(mp.mpf(bb)/aa))})
paths=[];mu2=mp.mpf('1.5')
for ee in ['0.1','0.05','0.025']:
 e=mp.mpf(ee);c=mp.exp(-1/e);N=mp.exp(mp.euler*e)*mu2**e;norm=N*c**e;J=(5**e-4**e)/(e*(1-e));A1=-e/(2-e);A2=-2*e/((2-e)*(3-e));M=max(mp.mpf(1),(mp.exp(mp.euler)*mu2)**mp.mpf('.25'));B=5**mp.mpf('.25')*mp.log(mp.mpf(5)/4)/mp.mpf('.75');assert abs(norm*A1*J)<=M*mp.mpf(4)/7*e*B and abs(norm*A2*J)<=M*mp.mpf(32)/77*e*B
 paths.append({'e':ee,'c':fmt(c),'N_c_pow_e':fmt(norm),'rank1_kernel':fmt(norm*A1*J),'rank2_kernel':fmt(norm*A2*J),'uniform_bound_rank1':fmt(M*mp.mpf(4)/7*e*B),'uniform_bound_rank2':fmt(M*mp.mpf(32)/77*e*B)})
out={'schema':'IGH1_INTRINSIC_GHOST_HATTED_LOCAL','role':role,'source_audits':audits,'source_derivative_normalizations_are_raw_before_Wick':True,'actual_QG_principal_combined_checks':principal_counts,'ending_checks':ending_checks,'raw_typed_cycles':cycles,'physical_typed_cycles':physical,'external_hat_cycles':projected,'physical_cycle_counts':[[fam,size,nn] for(fam,size),nn in sorted(cycle_counts.items())],'radials':radials,'paths':paths,'complete_leading_local_hatted_limit':'UNIFORM_ZERO','full_finite_color_coefficient_or_phase_measured':False,'ordered_QG_root_or_full_uCPP_Ward_computed':False,'full_QAP_E5_A5_or_authority':False}
blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(gzip.decompress(blob)).hexdigest()},sort_keys=True),flush=True);timer.cancel()
