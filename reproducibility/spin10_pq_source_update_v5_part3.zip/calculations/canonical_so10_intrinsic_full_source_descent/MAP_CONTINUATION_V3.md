# ISD1 replay-only continuation V3

Primary map native completed and its exact nilpotence checks passed.
The next replay was NOT LAUNCHED: the unchanged helper rejected available
commit below350MiB. Preserve V2 controller traceback and completed primary
source/input/captures/output; no native replay failure or overall PASS.
The helper did not serialize that rejected memory observation,so do not
invent its historical numeric value. Fresh observations are recorded.
No unrelated process termination or resource-floor reduction is permitted.

Resume only the unexecuted replay and late verifier when the same launch
floor is met. Reauthenticate original map_preparation.json and all bound
source bytes; do not rebind or rewrite that preparation. Same300/180s,
8GiB/350MiB/64MiB. No repeated primary calculation.

The original unexecuted verifier compares JSON literally. Primary emits
only nonzero field rows,whereas replay explicitly emits135 rows including
empty zeros. V2 verifier completes BOTH representations to the full135
declared field coordinates before exact comparison. This preserves and
checks the zero complement; it does not drop any coefficient. Original
verifier remains frozen and unexecuted,not mislabeled as a failed run or
PASS. No native map/condition/input is changed by this schema correction.
