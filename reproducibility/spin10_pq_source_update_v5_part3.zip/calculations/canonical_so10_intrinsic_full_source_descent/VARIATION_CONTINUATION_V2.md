# Exact-arithmetic continuation after bounded symbolic exhaustion

Original ISD2 primary exited124 at its prospective300-second timer. It
completed only the zero probe's stage observations,not the complete
calculation,and produced no tables/result/validation receipt. Its exact
source/copy,preparation,complete capture and controller failure remain.
Classify this as RESOURCE_EXHAUSTED/INCOMPLETE,not a mathematical failure
or PASS. No replay ran and no existing native process remains.

V2 retains identical source maps,measured coefficients,complete domains,
two contraction/Leibniz methods,second-variation conditions and300/180s
caps. Replace repeated SymPy coefficient simplification ONLY by an exact
normal form over Q[g10,xi,eta_H,sqrt2,sqrt3,sqrt5,sqrt7,i]. Python integers
and Fraction rationals are unbounded; no fixed-width overflow assumption.
Each input coefficient must roundtrip to its original SymPy expression.
All1024 radical/imaginary basis products are checked against SymPy.
Radical products use common-prime factors and XOR; i*i=-1. No coefficient,
tolerance,physical input or acceptance obligation changes. Convert back
to canonical SymPy strings only for complete serialized output.

Freeze a new preparation binding the original failed evidence and new
arithmetic/source copies before computation. Native outputs use v2 names;
do not overwrite old evidence or relabel old execution. Same8GiB sampled,
350MiB launch floor and64MiB packet; no resource allowance expansion.
