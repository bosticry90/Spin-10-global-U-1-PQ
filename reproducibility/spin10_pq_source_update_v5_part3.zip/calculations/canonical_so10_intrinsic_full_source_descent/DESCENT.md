# Complete first-source image of the measured first-probe functional

Let qa=alpha Lambda+B_c C_c a and qLambda=beta_c C_c Lambda+
D_(cd) C_c C_d a,with c<d on D. No constant alpha is assumed; ISD1
derives it. Let qC_k=sum_(c<d) A[k,c,d] C_c C_d and qx=C_c R_c x.
The source action and graded Euler rule in DERIVATION.md give

 qJL_l=JL_r beta[r,c,l] C_c-Ja_r alpha[r,l],
 qJa_a=JL_r D[r,c,d,a] C_c C_d-Ja_r B[r,c,a] C_c,
 qJx_i=Jx_j R_c[j,i] C_c.

These are SOURCE-HOMOGENEOUS terms; actual source-free Euler terms remain.
Write the measured coefficient of u Ja x as A0=-2i L (A0 here is a
coefficient matrix,not a new background reference). For each separate
formal finite carrier,define

 P=alpha L+A0,
 H_c=N_c-beta_c L+L R_c,
 T_c=-B_c A0+A0 R_c-alpha N_c,
 F_cd=beta_c N_d-beta_d N_c+N_c R_d-N_d R_c
        -sum_k A[k,c,d] N_k+D_cd A0.

Then the complete nonminimal source image is

 (q+d)Csrc |_nonminimal sources
   =rho Ja P x+rho JL C_c H_c x
      +u Ja C_c T_c x+u JL C_c C_d F_cd x.

The existing Jx part retains the IFC image rho Jx Hx+u Jx CC Fx;
different source families cannot be equated solely by matching counts.
Use actual tensor contractions and graded ordering to verify all six
image families. Keep chi4 and log2/log3/log5 separate and symbolic.

The ordinary source-free Euler image is the actual operator expression

 rho[-E_x V-E_Lambda Lx]
   +u[E_x C U-E_a A0 x+E_Lambda C Nx],

where E_phi=leftEuler_phi S0_E. In particular E_a is odd and its order
is retained. This is an operator formula,not an expanded complete ordinary
loop coefficient or permission to replace E by0. The known ordinary mass
conversion and other ordinary terms have their own variations.

Classical source/cotangent nilpotence implies second-variation relations.
Two explicit tests,without assuming P=0,are

 T_c+B_c P-P R_c+alpha H_c=0,
 F_cd-(nabla H)_cd-D_cd P=0,

where nabla acts on an auxiliary-valued scalar map as beta left minus
scalar R right,with the actual QC bracket. These express the rho source
part of (q+d)^2 Csrc=0. A direct polynomial second variation must retain
all other source components before claiming the full projected zero.
Neither these consistency conditions nor a nonzero first image is an
independent quantum-root measurement.

For a REGULATED quantum identity,do not omit lower-probe contributions.
At first probe degree the full variation of a relative functional can
also contain B1 C0,where B1 is the original probe-dependent source/field
operation and C0 is its zeroth-probe relative conversion. The existing
IFC applicability result disposes of its own Jx projection; it does not
automatically dispose of every JL/Ja projection. Establish the actual
zero/support/needed coefficient of such terms and the tangent/hatted
insertions before identifying the newly computed image with a complete
quantum regulator root. This is a dependency to audit,not a new arbitrary
finite normalization to choose.
