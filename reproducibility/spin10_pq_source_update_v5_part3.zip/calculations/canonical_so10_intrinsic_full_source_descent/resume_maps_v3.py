from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-full-source-descent-v1-2026-10-25');P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(P));from export_a10_e5_antighost_vector import capture
from export_a10_e5_vector_ghost_closed_controls_v3 import memory
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'map_preparation.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 for n in ['map_preparation.json','map_primary_capture.json','map_primary_result.json','map_primary_tables.json.gz','map_controller_failure_v2.json']:p=O/n;b[str(p)]=H(p)
 for n in ['MAP_CONTINUATION_V3.md','map_controller_failure_v2.json','verify_maps_v2.py','resume_maps_v3.py']:
  p=O/n;cp=O/(n+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(cp)]=H(cp)
 dump(O/'map_continuation_preparation_v3.json',{'input_sha256':b,'primary_replayed':False,'seconds_after_imports':300,'scientific_acceptance':'NOT_PERFORMED','fresh_memory':memory()})
 for role in ['replay','verify']:
  if role=='verify':
   for n in ['map_continuation_preparation_v3.json','map_replay_tables.json.gz','map_replay_capture.json','map_replay_result.json']:p=O/n;b[str(p)]=H(p)
   dump(O/'map_validation_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
  cmd=[sys.executable,'-B',str(O/('verify_maps_v2.py'if role=='verify'else'maps.py'))]+([]if role=='verify'else[role]);z=capture(cmd);dump(O/('map_'+role+'_capture.json'),z);dump(C/('map_'+role+'_full_capture.json'),z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<(180 if role=='verify'else 300);dump(O/('map_validation_receipt.json'if role=='verify'else'map_'+role+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<64*1024**2;print('COMPLETED_ISD1_V3',role,json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'map_continuation_failure_v3.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
