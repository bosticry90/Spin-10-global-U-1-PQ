# Measured source descent, and the source-product obligation it exposes

October 25, 2026. Base `ec4d46c67866816c1296981e5e6b857509a46555`.
PROGRESS under live AGENTS.md. Director scientific acceptance remains
NOT_PERFORMED. State113, authority34/39, E5/A5 OPEN and custody exit2/
seven NOTPASS are unchanged. This packet does not install a counterterm
or adopt a physical scheme, benchmark or normalization.

The homogeneous source variation of all five measured first-intrinsic
source patterns has now been calculated and checked. It is nonzero for
probe1 and satisfies its tested classical consistency relations. Probe0
is zero within this module. The unchanged scalar-source projection agrees
with the earlier IFC result.

The applicability audit establishes an equally important limit: this
homogeneous one-source image is not the complete one-source projection
of the full quantum identity. Source Euler derivatives can lower source
degree while introducing the intrinsic reference coefficient. Marginal
two-source terms and the original probe operation on the zeroth-probe
conversion must therefore be calculated or excluded before interpreting
the new image as a complete regulator root.

## Actual source operation, including its phases

ISD1 derives the nonminimal/C field maps from the actual raw action maps,
separate physical field/source charts and Wick phases. Primary transports
field tensors; replay transports the source density and differentiates
it. Left source/Euler derivatives precede restriction.

The source action obeys

    Sigma_source,E=sum_phi (-1)^p_phi J_phi R_phi,E,
    q phi_E=R_phi,E,
    q J_phi,E=(-1)^p_phi leftEuler_phi Sigma_E.

This follows from the actual CSW bracket, Sigma_E=-Sigma_M, and the
graded source phases. In particular JLambda_M=-i JLambda_E,
Ja_M=Ja_E,Jx_M=-Jx_E and JC_M=JC_E. Do not apply the same ungraded
cotangent phase to all fields.

In the actual canonical chart, the resulting nonminimal maps are

    q a=i Lambda+B_c C_c a,
    q Lambda=beta_c C_c Lambda+D_cd C_c C_d a,
    q JL_l=JL_r beta[r,c,l] C_c-i Ja_l,
    q Ja_a=JL_r D[r,c,d,a] C_c C_d-Ja_r B[r,c,a] C_c.

Here c<d in D, and B=beta as actual tensors. The field map i Lambda
must not be inferred from the separately measured -2i quantum-source
ratio. The raw unbroken/broken normalizations and physical charts matter.

There are45 alpha,334 beta,334 B,3344 D and837 QC positions. Completing
both output representations to all135 field coordinates resolves their
122-versus135 explicit-row serialization difference without deleting any
coefficient. The original literal-JSON verifier remains frozen and
unexecuted; V2 checks every declared zero as well as nonzero entries.
Both derivations agree on the source action,field maps and90 nonminimal
source maps. Actual field and cotangent nilpotence are checked in this
classical module. Full chiral nilpotence is not claimed: Ihat curvature
remains relevant outside it.

Late cross-checks reproduce the earlier IAS/IAG source vertices: beta in
the source CL order,the derivative of D giving all6688 Z0 CCa positions,
and the original Ja ghost-source density. These comparisons test the
source chart and phase rather than fitting the new descent.

## Complete homogeneous first-source image

The measured functional is

    Csrc=rho Jx V+u Jx C U+rho JL Lx+u Ja Mx+u JL C Nx,
    M=-2i L.

All coefficients come from the qualified IFC/IAS/IAG measurements. Keep
chi4/log2/log3/log5 separate. No value of chi4,b0 or kappa is selected.
In this packet q_hom means the source-preserving cotangent block; source-
free Euler terms are retained as separate operator obligations below.
With d u=rho, the complete image has six source families:

    (q_hom+d)Csrc
       =rho Ja P x+rho JL C H x+u Ja C T x+u JL CC F x
          +rho Jx Hx+u Jx CC Fx.

In terms of the measured matrices and actual generators,

    P=alpha L+M,
    H_c=N_c-beta_c L+L R_c,
    T_c=-B_c M+M R_c-alpha N_c,
    F_cd=beta_c N_d-beta_d N_c+N_c R_d-N_d R_c
           -sum_k QC[k,c,d] N_k+D_cd M,
    Hx=U-R V,  Fx=d_CE U.

Alpha=iI, so P=-i L is nonzero where L is nonzero. For example the
chi4 coefficient of rho Ja_12 x_206 is sqrt(6) g10^2 xi^2/2.
This is an algebraic component of the specified relative conversion's
homogeneous variation, not an anomaly or a new physical observable.

All entries are zero for probe0. Probe1 nonzero counts are:

| Formal carrier | P | H | T | F | Hx | Fx |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| chi4 |320|11128|11128|160380|0|0|
| log2 |304|12808|12808|199636|320|2452|
| log3 |304|8968|8968|85744|320|2452|
| log5 |0|12432|12432|197092|0|0|

These are formal coefficient positions. They are not independent loop
measurements,counterterms,particles or an E5 completion percentage. Each
probe/formal basis has16,295,040 positions in its full typed domain,
including zeros. Primary component/cochain contractions and replay's
literal graded polynomial Leibniz rule agree on the entire six-family
image. Replay also reconstructs scalar R from the raw Qx source action;
the complete R hash remains
`d6af5e8d4e0e3304504310767b32b98a82e3965d18f93daa6a8802a245bea1d8`.
The scalar-source Hx/Fx agrees exactly with qualified IFC after the new
calculation. That comparison is not used as a native expected operand.

Explicit rho-source consistency checks retain P rather than setting it0:

    T_c+B_c P-P R_c+alpha H_c=0,
    F_cd-(nabla H)_cd-D_cd P=0,  d_CE Hx-Fx=0.

The full projected second variation follows from the square-of-an-odd-
derivation lemma,verified generator nilpotence and the qualified compatible
R/QC representation. This is not a newly expanded full triple-ghost
tensor calculation or an independent quantum-root replay. In the chi4
component, omitting uJa changes320 P positions,omitting N changes7424 H,
reversing the beta source orientation changes2768 H,and forcing the
unjustified alpha=2i changes320 P. Zero-probe controls remain insensitive.

The source-free Euler image of this same Csrc is retained as an operator:

    rho[-E_x V-E_Lambda Lx]
      +u[E_x C U-E_a Mx+E_Lambda C Nx],

where E_phi=leftEuler_phi S0_E and E_a is odd. It is not set to0 or
reported as a complete expanded ordinary kinetic/potential/mass result.

## Why the homogeneous image is not yet the full quantum source identity

ISD3 enumerates the dim4,ghost0,parity/Lorentz TYPE envelope at the
relevant source degree. It does not construct invariant tensors,ranks,
admissible renormalization coefficients or protected HB1/C5 cochains.
There are no source-quadratic counterterms at intrinsic degree1 in this
envelope. At intrinsic degree0 there are three u patterns and two rho
patterns:

    u Ja Ja,  u Ja JL C,  u JL JL CC,
    rho Ja JL,  rho JL JL C.

The analogous zeroth-probe envelope contains the same three patterns as
the u sector without u. Fermionic sources and derivatives do not add
two-source types at these dimensions. This type support does not prove
that a quantum coefficient is nonzero or permissible under every symmetry.
It identifies terms that must be computed or excluded,not assigned0.

The actual intrinsic Euler blocks have296 N0_Lx and6268 S0 positions:

    E_Lambda|intrinsic1=N0_Lx x,
    E_a|intrinsic1=S0 C x.

They produce seven type routes from the five marginal source-quadratic
patterns into P,H,T,F's one-source patterns. Thus the full one-source
projection is not closed at fixed intrinsic grade. Knowing every
one-source coefficient at grade1 does not justify dropping grade0
two-source quantum contacts when applying the full source operation.

There is a second obligation, B1 C0: the original first-probe operation
acting on the zeroth-probe conversion. The actual G/QG inventory is:

| Classical packet | Source-free | One source | Two sources |
| --- | ---: | ---: | ---: |
| G,probe0 |660|672|12|
| G,probe1 |2097|2430|33|
| QG,probe0 |10300|660|12|
| QG,probe1 |81339|5741|1705|

All105661 actual monomials are included. Ordered-source scanning agrees
with an independent symbol-multiplicity histogram. All1762 source-degree2
references are preserved. These are CLASSICAL generator positions,not
new quantum-contact coefficients. Actual quadratic sources mean the
probe operation's field block can itself depend on a source. Consequently
B1 C0 may receive ordinary,one-source and two-source C0 contributions:
source degree s in G/QG requires C0 degree 2-s for a final single source.

The previously qualified IFC restriction protects its own Jx projection;
it does not prove a zero for every nonminimal projection. Likewise,
q0's source-independent elementary field maps do not prove that the
probe-dependent B1 field maps are source independent. No favorable
zeroth-probe conversion or contact normalization has been selected here.

The scientifically correct next decomposition therefore retains the
measured homogeneous image, source-lowering Euler action on marginal
source-quadratic first-probe contacts,and the actual B1 C0 projection.
Their numerical cancellation or incompatibility is not established by
this packet. Omitting either missing class could produce a false
restoration claim or a false anomaly diagnosis.

## Preserved failures, resources and computational capability

All runs bind immutable inputs and source copies. The record includes:

- Original map preparation FAILED before a worker on a guessed versioned
  CSW receipt filename. V2 binds the actual unversioned receipt.
- Two subsequent replay attempts were NOT LAUNCHED by the unchanged
  350MiB commit-memory gate. Their tracebacks and prospective records
  remain. The rejected helper did not serialize its historical memory
  value; none is invented. A bounded V4 observer waited for three stable
  conservative memory observations,then resumed only the unexecuted
  replay. The completed primary was not repeated.
- The original full SymPy descent and V2 exact-arithmetic whole-basis
  descent both exhausted their300s timers,exit124. Neither produced
  tables,result or scientific validation receipt. Partial stage counts
  are preserved as unfinished observations,not accepted coefficients.
- V3 partitions independent formal bases and removes the redundant
  component calculation inside the literal replay. Eight complete jobs
  cover the original domain; all four bases are required for acceptance.
  Prospective allowance was300s/job,maximum2400s native total,with a
  180s streaming verifier. No old execution was retroactively authorized.
- Original filtration audit FAILED on a QG-only input schema lacking G.
  V2 binds the complete authenticated carrier and verifies both G and QG
  arrays against their original separate operands. Same scientific data,
  enumeration and resource bounds. Original source/capture/traceback stay.

Exact arithmetic uses unbounded Python integers/Fraction rationals over
Q[g10,xi,eta_H,sqrt2,sqrt3,sqrt5,sqrt7,i]. Every input coefficient roundtrips
to SymPy, and all1024 radical/imaginary basis products are checked. No
fixed-width overflow assumption, floating tolerance or coefficient fit.
Canonical SymPy strings are restored for complete serialization.

Completed after-import runtimes,seconds:

| Work | Primary | Replay |
| --- | ---: | ---: |
| Source/cotangent maps |33.1212|30.3063|
| chi4 descent |96.1339|41.1359|
| log2 descent |70.4206|54.3682|
| log3 descent |29.8020|20.9258|
| log5 descent |59.4814|48.3397|

Map verifier0.1046s,full descent verifier11.5867s,filtration V2 audit1.8162s.
Completed jobs satisfy300/180s bounds,8GiB sampled-private and350MiB
launch floor. Largest sampled allocation,including verification,875307008
bytes; samples do not establish continuous peaks. Packet remains below
64MiB. All failed/unfinished executions remain explicitly non-PASS.

The useful AI-capability result is completing a large exact source
descent through a different polynomial representation and independently
ordered Leibniz replay,then identifying a source-filtration dependency
before claiming a quantum identity. Filename/schema mistakes,two timed
exhaustions and launch-resource interruptions are genuine limitations.
Shared action,charts,qualified data/helpers,Python/SymPy and AI authorship
remain; no outside scientist,proof assistant or experiment validated the
scientific premises.

`python -B tools/research_check.py e4` completed with native0,step exits
`[0,0,0,0,0,2]`,terminal COMPLETED. It authenticates existing bounded
evidence and authority/structure/read-only/custody checks,not a fresh
replay of all prior science. Custody remains exit2/seven NOTPASS. Full
external captures,resource observations and preservation/index/commit
seals are under `intrinsic-full-source-descent-v1-2026-10-25`.

Receipt SHA256:

- Maps: `a173d2d371e178d59e91a8b460b5ae4c76aa72242e961753931bc94f02d6fcde`.
- Descent V3: `ab9a6e8d9da6452f79e08471da2b8b1377e5d1da32f904785d36fbbf5dab1fb6`.
- Filtration V2: `5761ee66d2d6da5968a9dd0ea2c2d7a8ef47a35a8619743f45ffd79fd2a5bb1a`.

Full coefficient tables are split by formal basis/method with hashes in
the descent receipt; partial timeout outputs are not used as operands.
Filtration packed/raw SHA256:
`448cdf2d9854121d2db11a0610f9b7d264c7c5ca8a47cda5ca6590eda10ac61e` /
`0a28fe5dc88e80e845c3dc79809352bed3995053f4e81e8652295ccdb0ed7025`.

## Next smallest scientific action and continuing limits

Start with the complete marginal rho Ja JL contact family and its
correlated u Ja Ja family. Their typed proper-loop inventory must retain
the original Ja ghost-source vertex,direct G/QG source vertices and the
source-free rho-G inverse-path companion with its distinct heat length.
Derive paired-Gaussian signs/multiplicity before contracting the actual
45x45 source matrices. A classical source-quadratic generator is not the
corresponding one-loop contact coefficient. Calculate that coefficient
independently,then its source-lowering Euler image; do not infer it from
the desired cancellation of P,H,T or F.

Use the same audit to bound B1 C0 and remaining source-quadratic families.
The general BBx triangle remains unmeasured and required for a full
ordinary kinetic claim; the old selected counterexample cannot replace
it. The sole constant-scalar-translation exclusion remains in scope.
Absolute product normalization,full QAP/chiral measure/phase,source
reality,varying backgrounds/probes and massive causal/physical limits
remain separate. The failed physical benchmark,large singlet warning,
gauge matching,flavor pause and HB1/C5 boundary remain protected.
Research stays ACTIVE/INCOMPLETE with authority34/39 and E5/A5 OPEN.
