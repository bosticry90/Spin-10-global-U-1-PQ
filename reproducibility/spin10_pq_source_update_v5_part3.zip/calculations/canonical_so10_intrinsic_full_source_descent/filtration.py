from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from itertools import combinations_with_replacement
import json,gzip,time,threading,os
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'filtration_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
ip=read(O/'filtration_inputs.json');d=load(Path(ip['audit']))['audit'];names=d['names'];geo=d['geometry'];base=geo['names'];sources={names.index(base[J]):base[f]for f,J,h,k in geo['field_source_h_k']};source_names={names[n]for n in sources}
types={'B':(2,0,0,1),'x':(2,0,0,0),'C':(2,1,1,0),'a':(2,-1,1,0),'L':(4,0,0,0),'P':(3,0,1,2),'JB':(4,-1,1,1),'Jx':(4,-1,1,0),'JC':(4,-2,0,0),'Ja':(4,0,0,0),'JL':(2,-1,1,0),'KP':(3,-1,0,2),'derivative':(2,0,0,1)}
envelope=[]
for probe,pd,pg,pp in [('none',0,0,0),('u',0,0,0),('rho',2,1,1)]:
 for intrinsic in [0,1]:
  patterns=[]
  for count in range(2,5):
   for ww in combinations_with_replacement(types,count):
    if sum(t.startswith('J')or t=='KP'for t in ww)!=2:continue
    if pd+2*intrinsic+sum(types[t][0]for t in ww)!=8:continue
    if pg+sum(types[t][1]for t in ww)!=0 or(pp+sum(types[t][2]for t in ww))%2:continue
    if sum(types[t][3]for t in ww)!=0:continue
    patterns.append(sorted(ww))
  envelope.append({'probe':probe,'intrinsic_grade':intrinsic,'two_source_Lorentz_scalar_types':sorted(patterns)})
want0=sorted([['Ja','Ja'],['C','JL','Ja'],['C','C','JL','JL']]);wantR=sorted([['JL','Ja'],['C','JL','JL']])
for z in envelope:
 assert z['two_source_Lorentz_scalar_types']==([]if z['intrinsic_grade']else wantR if z['probe']=='rho'else want0),z
inventories=[];refs=[]
for family in ['physical_G','physical_QG']:
 for probe,p in enumerate(d[family]):
  counts=Counter();independent=Counter();allref=[];by_source_pattern=Counter()
  for idx,(gp,w,ci)in enumerate(p['monomials']):
   src=[(n,I)for n,I in w if n in sources];counts[len(src)]+=1
   if len(src)>=2:allref.append({'monomial':idx,'g10_power':gp,'word':w,'coefficient_index':ci,'source_degree':len(src)})
   by_source_pattern[tuple(sorted(sources[n]for n,I in src))]+=1
  # Independent histogram counts symbol multiplicities rather than selecting
  # source occurrences in the ordered word.
  for gp,w,ci in p['monomials']:
   hist=Counter(names[n]for n,I in w);independent[sum(v for n,v in hist.items()if n in source_names)]+=1
  assert counts==independent
  inventories.append({'family':family,'probe':probe,'total_monomials':len(p['monomials']),'source_degree_counts':dict(counts),'possible_C0_source_degrees_for_final_J1':sorted(set(2-k for k in counts if k<=2)),'degree_ge2_references':len(allref)});refs.append({'family':family,'probe':probe,'references':allref});print('STAGE ISD3_SOURCE',family,probe,dict(counts),flush=True)
v=load(Path(ip['vertices']));N=v['endings']['N0'];S=v['S0'];nL=[q for q in N['entries']if q[0]>=45];assert not any(q[0]<45 for q in N['entries']);assert nL and S
routes=[{'C1_type':['u','Ja','Ja'],'Euler':'E_a_intrinsic1','target':['u','Ja','C','x']},{'C1_type':['u','Ja','JL','C'],'Euler':'E_Lambda_intrinsic1','target':['u','Ja','C','x']},{'C1_type':['u','Ja','JL','C'],'Euler':'E_a_intrinsic1','target':['u','JL','C','C','x']},{'C1_type':['u','JL','JL','C','C'],'Euler':'E_Lambda_intrinsic1','target':['u','JL','C','C','x']},{'C1_type':['rho','Ja','JL'],'Euler':'E_Lambda_intrinsic1','target':['rho','Ja','x']},{'C1_type':['rho','Ja','JL'],'Euler':'E_a_intrinsic1','target':['rho','JL','C','x']},{'C1_type':['rho','JL','JL','C'],'Euler':'E_Lambda_intrinsic1','target':['rho','JL','C','x']}]
out={'schema':'ISD3_SOURCE_FILTRATION_APPLICABILITY_OBLIGATION','type_envelope':envelope,'actual_G_QG_source_inventory':inventories,'actual_source_ge2_monomial_references':refs,'actual_classical_intrinsic_Euler_blocks':{'E_Lambda_linear_x_positions':len(nL),'E_a_Cx_positions':len(S)},'source_lowering_type_routes':routes,'single_source_homogeneous_descent_not_a_full_quantum_identity':True,'missing_C1_quadratic_source_and_B1C0_terms_not_assigned_zero':True,'type_support_not_nonzero_quantum_amplitude':True,'HB1_C5_or_QAP_E5_A5_authority':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'filtration_tables.json.gz').open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'two_source_type_counts':[len(z['two_source_Lorentz_scalar_types'])for z in envelope],'actual_source_inventory':inventories,'intrinsic_Euler_positions':[len(nL),len(S)],'source_lowering_type_routes':len(routes),'new_quantum_coefficients_measured':False,'scientific_authority_changed':False},sort_keys=True),flush=True);timer.cancel()
