from pathlib import Path
from hashlib import sha256
import json,gzip,ast,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-full-source-descent-v1-2026-10-25');P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(P));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b={};A=O.parent/'canonical_so10_intrinsic_auxiliary_ghost_source';I=O.parent/'canonical_so10_intrinsic_finite_conversion_module';S=O.parent/'canonical_so10_cutoff_source_ward_operator'
 for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V626.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:p=R/n;b[str(p)]=H(p)
 for p in [S/'DERIVATION.md',S/'validation_receipt_v3.json',A/'assembly_receipt.json',A/'vertex_validation_receipt.json',A/'color_validation_receipt.json']:b[str(p)]=H(p)
 for role in ['primary','replay']:
  ap=A/('vertex_'+role+'_inputs.json.gz');ip=I/(role+'_inputs.json.gz');sp=S/'primary_inputs.json.gz';rp=O.parent/'canonical_so10_intrinsic_kinetic_support/replay_vertex_inputs.json.gz'
  for p in [ap,ip,sp,rp]:b[str(p)]=H(p)
  aa=load(ap);ii=load(ip);names=[('b'if k<12 else'L')+str(k)for k in range(45)]+[('bar'if k<12 else'ub')+str(k)for k in range(45)]+['C'+str(k)for k in range(45)]
  if role=='primary':ss=load(sp);fm={n:ss['field_maps'][n]for n in names}
  else:fm={**aa['qLambda'],**load(rp)['master_antighost_maps'],**ii['source_QC']}
  assert set(fm)==set(names)
  z={'field_maps':fm,'frame':aa['frame'],'xs':ii['xs']};p=O/('map_'+role+'_inputs.json.gz')
  with p.open('xb')as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
  b[str(p)]=H(p)
 for n in ['RECORD.md','DERIVATION.md','maps.py','verify_maps.py','run_maps.py']:
  p=O/n;cp=O/(n+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(cp)]=H(cp)
 dump(O/'map_preparation.json',{'input_sha256':b,'seconds_after_imports':300,'scientific_acceptance':'NOT_PERFORMED'})
 for role in ['primary','replay','verify']:
  if role=='verify':
   for n in ['map_preparation.json']+[f'map_{r}_{t}.json'+('.gz'if t=='tables'else'')for r in ['primary','replay']for t in ['tables','result','capture']]:p=O/n;b[str(p)]=H(p)
   dump(O/'map_validation_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
  cmd=[sys.executable,'-B',str(O/('verify_maps.py'if role=='verify'else'maps.py'))]+([]if role=='verify'else[role]);z=capture(cmd);dump(O/('map_'+role+'_capture.json'),z);dump(C/('map_'+role+'_full_capture.json'),z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<(180 if role=='verify'else 300);dump(O/('map_validation_receipt.json'if role=='verify'else'map_'+role+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<64*1024**2;print('COMPLETED_ISD1',role,json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'map_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
