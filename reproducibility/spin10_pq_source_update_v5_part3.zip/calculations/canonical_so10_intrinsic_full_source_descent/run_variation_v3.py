from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-full-source-descent-v1-2026-10-25');P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(P));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'variation_preparation_v2.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 for n in ['variation_preparation_v2.json','variation_v2_primary_capture.json','variation_controller_failure_v2.json']:p=O/n;b[str(p)]=H(p)
 for n in ['VARIATION_CONTINUATION_V3.md','variation_controller_failure_v2.json','variation_v3.py','verify_variation_v3.py','run_variation_v3.py']:
  p=O/n;cp=O/(n+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(cp)]=H(cp)
 dump(O/'variation_preparation_v3.json',{'input_sha256':b,'seconds_after_imports_each_job':300,'jobs':8,'maximum_total_native_seconds':2400,'scientific_acceptance':'NOT_PERFORMED','original_executions':'V1_V2_RESOURCE_EXHAUSTED_INCOMPLETE_EXIT124_NO_RECEIPTS'})
 completed=[]
 for basis in ['chi4','log2','log3','log5']:
  for role in ['primary','replay']:
   z=capture([sys.executable,'-B',str(O/'variation_v3.py'),role,basis]);name='variation_v3_'+basis+'_'+role;dump(O/(name+'_capture.json'),z);dump(C/(name+'_full_capture.json'),z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
   rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<300;dump(O/(name+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<64*1024**2;completed.append(name);print('COMPLETED_ISD2_V3',name,json.dumps(rr[0],sort_keys=True),flush=True)
 for n in ['variation_preparation_v3.json']+[name+'_'+t+'.json'+('.gz'if t=='tables'else'')for name in completed for t in ['tables','capture','result']]:p=O/n;b[str(p)]=H(p)
 dump(O/'variation_validation_preparation_v3.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
 z=capture([sys.executable,'-B',str(O/'verify_variation_v3.py')]);dump(O/'variation_v3_verify_capture.json',z);dump(C/'variation_v3_verify_full_capture.json',z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
 rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<180;dump(O/'variation_validation_receipt_v3.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<64*1024**2;print('COMPLETED_ISD2_V3_VERIFICATION',json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'variation_controller_failure_v3.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
