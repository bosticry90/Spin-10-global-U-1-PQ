# Filtration input-carrier correction

Original native FAILED on KeyError physical_G: its bound IAS8 uc_support
input is the authenticated QG-only projection,not the full G/QG carrier.
No source inventory result or receipt was produced. Preserve source/copy,
preparation/full capture/controller traceback unchanged.

V2 binds the actual complete IKS support_primary_inputs.json.gz and checks
its G array against the authenticated IAS vertex input and its QG array
against the already bound IAS8 input. This is an input-schema adapter
correction with explicit exact equality of the scientific operands,not
changed action coefficients. Same enumeration,scientific tests and180s/
8GiB/350MiB/64MiB bounds. All outputs/preparation use new v2 names.
