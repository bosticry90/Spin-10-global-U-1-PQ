from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent
H=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
role=sys.argv[1];basis_select=sys.argv[2];assert basis_select in ['chi4','log2','log3','log5']
assert role in ['primary','replay']
tick=time.perf_counter()
timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'variation_preparation_v3.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('variation_v3_'+basis_select+'_'+('replay'if role=='primary'else'primary')):raise PermissionError('ISD2_PEER_DENIED')
  if p.parent.name=='canonical_so10_intrinsic_finite_conversion_module'and p.name.endswith('tables.json.gz'):raise PermissionError('ISD2_EXPECTED_IFC_IMAGE_DENIED')
sys.addaudithook(guard)
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.expand(s.sympify(z,locals=loc))
cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand)
dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v)for i,j,v in z['entries']})
tab=lambda z:{tuple(q[:-1]):parseC(q[-1])for q in z}
from coefficient_ring import coefficient,verify_basis_products,I as CI
assert verify_basis_products()==1024
parseC=lambda z:coefficient(parse(z))
def clean(z):return {k:v for k,v in z.items()if v!=0}
def plus(*terms):
 out=defaultdict(lambda:0)
 for z,f in terms:
  for k,v in z.items():out[k]+=f*v
 return clean(out)
d=load(O/('variation_'+role+'_inputs.json.gz'));m=d['maps'];assembly=d['assembly'];alpha=tab(m['alpha_L']);beta=tab(m['beta_C_L']);BB=tab(m['B_C_a']);DD=tab(m['D_CC_a']);qc=tab(m['qC_CC'])
if role=='primary':R=list(map(dec,d['R']))
else:
 frame=d['frame'];xs=d['xs'];aux=[('b'if i<12 else'L')+str(i)for i in range(45)];cs=['C'+str(i)for i in range(45)];ants=[('bar'if i<12 else'ub')+str(i)for i in range(45)];phys=[f'B{i}_{mu}'for i in range(45)for mu in range(4)]+xs+aux+cs+ants;ri={n:i for i,n in enumerate(frame['field_order'])};pi={n:i for i,n in enumerate(phys)};TI=dec(frame['physical_to_raw_inverse']);TF=dec(frame['physical_to_raw_kernel'])
 def block(ns):return TI.extract([ri[n]for n in ns],[pi[n]for n in ns]),TF.extract([pi[n]for n in ns],[ri[n]for n in ns])
 TC,FC=block(cs);Tx,Fx=block(xs);xid={n:i for i,n in enumerate(xs)};raw=[s.SparseMatrix(328,328,{})for c in range(45)]
 for out,rows in d['source_Qx'].items():
  for row in rows:
   c=int(next(n[1:]for n in row['word']if n.startswith('C')));j=xid[next(n for n in row['word']if n.startswith('x_'))];raw[c][xid[out],j]+=parse(row['coefficient'])
 R=[cl(Fx*sum((TC[k,c]*raw[k]for k in range(45)if TC[k,c]),s.zeros(328))*Tx)for c in range(45)]
assert all(not cl(M+M.T).todok()for M in R)
Rhash=sha256((json.dumps([{'shape':list(M.shape),'entries':[[int(i),int(j),str(v)]for(i,j),v in sorted(M.todok().items())]}for M in R],sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest()
Rout=defaultdict(list);Rin=defaultdict(list)
for c,M in enumerate(R):
 for(i,j),v in M.todok().items():v=coefficient(v);Rout[i].append((c,j,v));Rin[j].append((c,i,v))
bout=defaultdict(list);binp=defaultdict(list);aout=defaultdict(list);binB=defaultdict(list);dinp=defaultdict(list);qcout=defaultdict(list)
for(r,c,a),v in beta.items():binp[a].append((r,c,v));bout[r].append((c,a,v))
for(r,a),v in alpha.items():aout[a].append((r,v))
for(r,c,a),v in BB.items():binB[a].append((r,c,v))
for(r,c,k,a),v in DD.items():dinp[a].append((r,c,k,v))
for(k,c,b),v in qc.items():qcout[k].append((c,b,v))
def ghostcanon(ww):
 if len(set(ww))!=len(ww):return (),0
 return tuple(sorted(ww)),(-1)**sum(a>b for j,a in enumerate(ww)for b in ww[j+1:])
def auxdiff(Z):
 out=defaultdict(lambda:0)
 for(r,ww,j),v in Z.items():
  for rr,c,b in binp[r]:
   pair,sg=ghostcanon((c,)+ww)
   if sg:out[rr,pair,j]+=sg*b*v
  for c,i,b in Rout[j]:
   pair,sg=ghostcanon((c,)+ww)
   if sg:out[r,pair,i]-=sg*b*v
  for at,c in enumerate(ww):
   for a,b,t in qcout[c]:
    pair,sg=ghostcanon(ww[:at]+(a,b)+ww[at+1:])
    if sg:out[r,pair,j]-=(-1)**at*sg*t*v
 return clean(out)
def scalardiff(Z):
 out=defaultdict(lambda:0)
 for(i,ww),v in Z.items():
  for c,j,b in Rin[i]:
   pair,sg=ghostcanon((c,)+ww)
   if sg:out[j,pair]+=sg*b*v
  for at,c in enumerate(ww):
   for a,b,t in qcout[c]:
    pair,sg=ghostcanon(ww[:at]+(a,b)+ww[at+1:])
    if sg:out[i,pair]-=(-1)**at*sg*t*v
 return clean(out)
def left(K,Z):
 by=defaultdict(list);out=defaultdict(lambda:0)
 for(r,a),v in K.items():by[a].append((r,v))
 for(a,ww,i),v in Z.items():
  for r,b in by[a]:out[r,ww,i]+=b*v
 return clean(out)
def da(Z):
 out=defaultdict(lambda:0)
 for(a,ww,i),v in Z.items():
  assert not ww
  for r,c,k,b in dinp[a]:out[r,(c,k),i]+=b*v
 return clean(out)
def ba(Z):
 out=defaultdict(lambda:0)
 for(a,ww,i),v in Z.items():
  for r,c,b in binB[a]:
   pair,sg=ghostcanon((c,)+ww)
   if sg:out[r,pair,i]+=sg*b*v
 return clean(out)
def rightR(Z):
 out=defaultdict(lambda:0)
 for(r,ww,j),v in Z.items():
  for c,i,b in Rout[j]:
   pair,sg=ghostcanon((c,)+ww)
   if sg:out[r,pair,i]+=sg*b*v
 return clean(out)
# Literal polynomial variables (tag,index),in rho/u/source/C/x order.
rank={'rho':0,'u':1,'JL':2,'Ja':3,'Jx':4,'C':5,'x':6}
par=lambda v:int(v[0]in ['rho','JL','Jx','C'])
key=lambda v:(rank[v[0]],v[1])
def canon(ww):
 if len(set(v for v in ww if par(v)))!=sum(par(v)for v in ww):return (),0
 return tuple(sorted(ww,key=key)),(-1)**sum(par(a)*par(b)*(key(a)>key(b))for j,a in enumerate(ww)for b in ww[j+1:])
def pterm(out,ww,v):
 w,sg=canon(ww)
 if sg:out[w]+=sg*v
def nmvar(k):
 if k<45:return ('JL',k)
 if k<90:return ('Ja',k-45)
 assert 135<=k<180,k
 return ('C',k-135)
flow={('u',0):{(('rho',0),):1}}
for k,rows in m['source_maps']:
 flow[nmvar(k)]={tuple(nmvar(v)for v in w):parseC(co)for w,co in rows}
for k,rows in m['field_maps']:
 if 135<=k<180:flow[('C',k-135)]={tuple(nmvar(v)for v in w):parseC(co)for w,co in rows}
for i in range(328):
 f=defaultdict(lambda:0);j=defaultdict(lambda:0)
 for c,out,v in Rin[i]:j[(('Jx',out),('C',c))]+=v
 for c,inp,v in Rout[i]:f[(('C',c),('x',inp))]+=v
 flow['Jx',i]=dict(j);flow['x',i]=dict(f)
def vary(Z):
 out=defaultdict(lambda:0)
 for w,v in Z.items():
  for at,f in enumerate(w):
   sg=(-1)**sum(par(t)for t in w[:at])
   for ww,b in flow.get(f,{}).items():pterm(out,w[:at]+ww+w[at+1:],sg*v*b)
 return clean(out)
def poly(families):
 out=defaultdict(lambda:0)
 for name,z in families.items():
  if name in ['P','H','T','F']:
   for(r,ww,i),v in z.items():
    probe='rho'if name in ['P','H']else'u';src='Ja'if name in ['P','T']else'JL';pterm(out,((probe,0),(src,r))+tuple(('C',a)for a in ww)+(('x',i),),v)
  else:
   for(i,ww),v in z.items():pterm(out,((('rho'if name=='Hx'else'u'),0),('Jx',i))+tuple(('C',a)for a in ww),v)
 return clean(out)
def sourcepoly(V,U,L,A,N):
 out=defaultdict(lambda:0)
 for i,v in V.items():pterm(out,(('rho',0),('Jx',i)),v)
 for(i,c),v in U.items():pterm(out,(('u',0),('Jx',i),('C',c)),v)
 for(r,i),v in L.items():pterm(out,(('rho',0),('JL',r),('x',i)),v)
 for(r,i),v in A.items():pterm(out,(('u',0),('Ja',r),('x',i)),v)
 for(r,c,i),v in N.items():pterm(out,(('u',0),('JL',r),('C',c),('x',i)),v)
 return clean(out)
def encodefam(z):
 return [[r,list(ww),i,str(v)]for(r,ww,i),v in sorted(z.items())]
def encodescalar(z):return [[i,list(ww),str(v)]for(i,ww),v in sorted(z.items())]
results=[]
for pr in assembly['outputs']:
 per=[]
 for basis,z in pr['formal_basis'].items():
  if basis!=basis_select:continue
  V={i:parseC(v)for i,v in z['rho_Jx']};U=tab(z['u_Jx_C']);L=tab(z['rho_JLambda_x']);A=tab(z['u_Ja_x']);N=tab(z['u_JLambda_C_x']);LV={(r,(),i):v for(r,i),v in L.items()};AV={(r,(),i):v for(r,i),v in A.items()};NV={(r,(c,),i):v for(r,c,i),v in N.items()};VV={(i,()):v for i,v in V.items()};UV={(i,(c,)):v for(i,c),v in U.items()}
  if role=='primary':
   P=plus((left(alpha,LV),1),(AV,1));HH=plus((NV,1),(auxdiff(LV),-1));T=plus((ba(AV),-1),(rightR(AV),1),(left(alpha,NV),-1));FF=plus((auxdiff(NV),1),(da(AV),1));Hx=plus((UV,1),(scalardiff(VV),-1));Fx=scalardiff(UV);fam={'P':P,'H':HH,'T':T,'F':FF,'Hx':Hx,'Fx':Fx};first=poly(fam)
   test1=plus((T,1),(ba(P),1),(rightR(P),-1),(left(alpha,HH),1));test2=plus((FF,1),(auxdiff(HH),-1),(da(P),-1));testx=plus((scalardiff(Hx),1),(Fx,-1));assert not test1 and not test2 and not testx,('rho_second_variation_failed',pr['probe'],basis)
  else:
   first=vary(sourcepoly(V,U,L,A,N));fam={k:{}for k in ['P','H','T','F','Hx','Fx']}
   for word,v in first.items():
    probes=[a for a in word if a[0]in ['rho','u']];sources=[a for a in word if a[0]in ['JL','Ja','Jx']];cc=tuple(a[1]for a in word if a[0]=='C');xx=[a[1]for a in word if a[0]=='x'];assert len(probes)==len(sources)==1 and len(word)==2+len(cc)+len(xx),word
    probe=probes[0][0];source,r=sources[0]
    if source=='Jx':
     assert not xx and ((probe=='rho'and len(cc)==1)or(probe=='u'and len(cc)==2));name='Hx'if probe=='rho'else'Fx';fam[name][r,cc]=v
    else:
     assert len(xx)==1
     name={('rho','Ja',0):'P',('rho','JL',1):'H',('u','Ja',1):'T',('u','JL',2):'F'}[probe,source,len(cc)];fam[name][r,cc,xx[0]]=v
   P,HH,T,FF,Hx,Fx=[fam[k]for k in ['P','H','T','F','Hx','Fx']]
  # No changes to actual quantum inputs: controls compare omitted terms.
  controls={'omit_uJa_changes_P':len(AV),'omit_N_changes_H':len(NV),'reverse_beta_source_orientation_changes_H':len(plus((auxdiff(LV),1),(rightR(LV),1))),'force_alpha_2i_changes_P':len(plus((left(alpha,LV),1),(LV,-2*CI)))}
  per.append({'basis':basis,'nonminimal':{k:encodefam(fam[k])for k in ['P','H','T','F']},'scalar_sources':{'Hx':encodescalar(Hx),'Fx':encodescalar(Fx)},'all_polynomial_coefficients':[[[[a,b]for a,b in w],str(v)]for w,v in sorted(first.items())],'rho_second_variation_zero_by_component_check_or_generator_proof':True,'rho_second_variation_explicitly_checked':role=='primary','controls':controls});print('STAGE_ISD2',role,pr['probe'],basis,{k:len(v)for k,v in fam.items()},flush=True)
 results.append({'probe':pr['probe'],'formal_basis':per})
out={'schema':'ISD2_COMPLETE_HOMOGENEOUS_FIRST_SOURCE_VARIATION','role':role,'results':results,'R_sha256':Rhash,'positions_per_probe_basis':16295040,'six_source_image_families':True,'full_second_variation_basis':'odd_derivation_square_and_verified_generator_nilpotence;explicit_rho_checks','new_full_triple_ghost_tensor_replay':False,'ordinary_Euler_or_B1C0_root_not_inferred':True,'exact_ring_basis_products_checked':1024,'unbounded_integer_Fraction_arithmetic':True,'full_QAP_E5_A5_authority':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('variation_v3_'+basis_select+'_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'R_sha256':Rhash,'source_image_counts':[[[q['basis'],{**{k:len(v)for k,v in q['nonminimal'].items()},**{k:len(v)for k,v in q['scalar_sources'].items()}}]for q in pr['formal_basis']]for pr in results]},sort_keys=True),flush=True);timer.cancel()
