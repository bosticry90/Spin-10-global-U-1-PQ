from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'variation_validation_preparation_v3.json')['input_sha256'].items():assert H(Path(p))==h,p
ip=read(O/'variation_late_inputs.json');old=load(Path(ip['IFC']))['outputs'];m=load(O/'map_primary_tables.json.gz');bv=load(Path(ip['IAG_vertices']));bb=load(Path(ip['IAG_vertex_inputs']))['beta'];anti=load(Path(ip['IAS_anti']))['results'][0]['original_Ja_aC_Euclidean_density']
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.expand(s.sympify(z,locals=loc))
tab=lambda z:{tuple(q[:-1]):parse(q[-1])for q in z}
assert {(r,a,c):v for(r,c,a),v in tab(m['beta_C_L']).items()}==tab(bb)
Z={}
for(r,c,k,aa),v in tab(m['D_CC_a']).items():Z[r,c,aa,k]=-v;Z[r,k,aa,c]=v
assert Z==tab(bv['Z0_JC_aC'])
assert {(r,a,c):v for(r,c,a),v in tab(m['B_C_a']).items()}==tab(anti)
counts={};hashes={};rh=None
for basis in ['chi4','log2','log3','log5']:
 a,b=[load(O/('variation_v3_'+basis+'_'+r+'_tables.json.gz'))for r in ['primary','replay']]
 for z in [a,b]:
  rr=z.pop('role');assert z['positions_per_probe_basis']==16295040 and z['exact_ring_basis_products_checked']==1024 and not z['full_QAP_E5_A5_authority'];assert len(z['results'])==2
  for pr in z['results']:
   assert len(pr['formal_basis'])==1 and pr['formal_basis'][0]['basis']==basis;assert pr['formal_basis'][0].pop('rho_second_variation_explicitly_checked')==(rr=='primary')
 assert a==b,('complete_methods_disagree',basis)
 if rh is None:rh=a['R_sha256']
 assert rh==a['R_sha256'];counts[basis]=[]
 for pr in a['results']:
  q=pr['formal_basis'][0];p={'log2':'2','log3':'3'}.get(basis)
  if p:
   assert q['scalar_sources']['Hx']==old[pr['probe']]['prime_logs'][p]['H']['entries']
   assert q['scalar_sources']['Fx']==old[pr['probe']]['prime_logs'][p]['F']['entries']
  else:assert not q['scalar_sources']['Hx']and not q['scalar_sources']['Fx']
  assert q['rho_second_variation_zero_by_component_check_or_generator_proof']
  counts[basis].append({**{k:len(v)for k,v in q['nonminimal'].items()},**{k:len(v)for k,v in q['scalar_sources'].items()}})
 for r in ['primary','replay']:p=O/('variation_v3_'+basis+'_'+r+'_tables.json.gz');hashes[p.name]=H(p)
 print('STAGE ISD2_V3_VERIFIED',basis,counts[basis],flush=True)
 del a,b
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'component_vs_literal_Leibniz_all_four_bases_all_six_images_all_coefficients_and_zeros_agree':True,'unchanged_Jx_projection_matches_qualified_IFC':True,'actual_cotangent_vertices_match_IAS_IAG_quantum_source_inputs':True,'positions_per_probe_basis':16295040,'source_image_counts':counts,'R_sha256':rh,'complete_table_sha256':hashes,'new_full_triple_ghost_expansion':False,'QAP_E5_A5_authority':False},sort_keys=True),flush=True);timer.cancel()
