# ISD2 full first-source variation

Prospective continuation only after ISD1 replay and exact validation.
Compute (q0+d) Csrc for all five IAG6 measured source carriers,both probes,
formal chi4/log2/log3/log5,using the actual ISD1 source maps and actual R.
The six complete image families and equations are in DESCENT.md. Count
the full typed zero complement:16,295,040 positions per probe/formal basis.
This is the actual homogeneous-source variation of the specified Csrc,
not a direct new quantum loop/root or full renormalized identity.

Primary: component tensor/cochain formulas for P,H,T,F and scalar Hx/Fx.
Replay: literal odd polynomial Leibniz rule with rho/u/source/ghost/scalar
ordering and actual qJ,qC,qx,d u=rho. Independent sparse contractions
must agree on every coefficient and zero,with all parameter powers kept.
Compare the unchanged Jx projection with qualified IFC only AFTER the
new calculation. No expected source image is a native operand.

Check the explicit rho-source second-variation identities including P,
not assuming it vanishes. Full projected second variation follows from
the verified source/nonminimal generator nilpotence and the qualified
compatible R/QC Lie representation by the odd-derivation square lemma.
Do not call this a newly expanded full triple-ghost tensor replay. Verify
that the actual QC chart agrees with the source action used for R.

Controls: omit measured uJa,omit new N,reverse source-cotangent beta
orientation,and force an unjustified universal alpha=2i. Report changed
positions and any insensitive projection. A nonzero first image is kept.
No choice of chi4/b0/kappa,fit to old BBx,action installation or promotion.

Sequential natives300s after imports,verifier180s,8GiB sampled private,
350MiB available-pagefile floor,64MiB packet. Freeze sources/copies/input
hashes first; preserve all failed or exhausted executions. Broader root
applicability including B1 C0,ordinary Euler descendants,full general BBx
triangle and quantum/physical requirements remain separate dependencies.
