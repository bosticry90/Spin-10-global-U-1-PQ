from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'final_review_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.expand(s.sympify(z,locals=loc))
tab=lambda z:{tuple(q[:-1]):parse(q[-1])for q in z}
m=load(O/'map_primary_tables.json.gz');assert tab(m['alpha_L'])=={(i,i):s.I for i in range(45)};assert tab(m['B_C_a'])==tab(m['beta_C_L'])
ip=read(O/'final_review_inputs.json');a=load(Path(ip['assembly']))['outputs'];v=read(O/'variation_validation_receipt_v3.json');checked=0
for basis in ['chi4','log2','log3','log5']:
 for role in ['primary','replay']:
  p=O/('variation_v3_'+basis+'_'+role+'_tables.json.gz');assert H(p)==v['complete_table_sha256'][p.name];d=load(p)
  for pr in d['results']:
   q=pr['formal_basis'][0];P={(r,i):parse(co)for r,ww,i,co in q['nonminimal']['P']};assert all(not ww for r,ww,i,co in q['nonminimal']['P']);L=tab(a[pr['probe']]['formal_basis'][basis]['rho_JLambda_x']);assert P=={k:s.expand(-s.I*z)for k,z in L.items()};checked+=45*328
  del d
for name in ['variation_primary_capture.json','variation_v2_primary_capture.json']:
 z=read(O/name);assert z['exit_code']==124 and not z['calculation_completed'];stem=name[:-len('_capture.json')];assert not(O/(stem+'_result.json')).exists()and not(O/(stem+'_tables.json.gz')).exists()
f=read(O/'filtration_receipt_v2.json');assert f['two_source_type_counts']==[3,0,3,0,2,0];assert sum(z['total_monomials']for z in f['actual_source_inventory'])==105661;assert sum(z['degree_ge2_references']for z in f['actual_source_inventory'])==1762
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'actual_alpha_iI_and_B_beta_all_entries':True,'P_equals_minus_i_L_all_probes_bases_and_zeros':True,'P_positions_compared':checked,'timed_out_originals_not_relabelled_or_used_as_completed_outputs':True,'actual_classical_source_degree_two_positions':1762,'five_missing_source_quadratic_type_obligations_not_quantum_coefficients':True,'no_full_quantum_identity_or_E5_A5_inferred':True},sort_keys=True),flush=True);timer.cancel()
