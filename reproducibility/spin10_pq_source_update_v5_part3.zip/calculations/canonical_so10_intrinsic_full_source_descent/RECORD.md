# ISD1+: actual source descent of the complete measured intrinsic functional

Prospective October25,2026,base ec4d46c67866816c1296981e5e6b857509a46555.
Previous goal turn PROGRESS. Fresh preflight clean main,no matching workers,
goal ACTIVE. State113/34of39,E5/A5 OPEN,custodyexit2/seven NOTPASS unchanged.
No agents,branch/worktree,push/publication/outreach,foundational/scheme/
benchmark adoption,flavor/HB1C5 activation,protected promotion or state edit.
Current AGENTS and charter/solo-review/epistemic policies apply.

Question: what is the ACTUAL homogeneous single-source symmetry variation
of the five measured source carriers,including their auxiliary/antighost
correlations? A nonzero variation is an allowed result. It must not be
set to zero or fitted away: a relative regulator conversion may have an
inhomogeneous regulator/root response. Its quantum interpretation requires
an applicable actual source-Hessian identity,not merely a nilpotence test.

Original unshifted SMA/CSW/EDS,A0,constant first u/rho,one intrinsic
coefficient of dimension1,zero external jets,both probes,all45 ghosts,
45 auxiliary/antighost directions and328 scalars,symbolicg10/xi/eta_H.
Retain formal chi4/log2/log3/log5; chi4 is not b0,kappa or an IR contact.
The finite quantum inputs are the already qualified IAG/IAS/IFC maps,
not new coefficients defined by a desired Ward target. This is their
relative nonexceptional Euclidean local domain,not a physical massive
vacuum or unrestricted constant-field/zero-momentum limit.

First derive the nonminimal field and cotangent maps from actual raw
qLambda/qa/QC/Qx plus their actual coordinate frames. Differentiate before
restriction. Check source action,Grassmann order and Wick pullback in
DERIVATION.md. Compare component tensor transport with source-density
congruence/literal exterior transport; do not assume the auxiliary and
antighost maps or source indices coincide. Nilpotence on this classical
nonminimal sector is a check,not nilpotence of the full chiral operation.

Then freeze the complete projected first-source variation. Retain source
Euler terms from both Lambda/a and their correlated source terms. Source-
free Euler descendants are recorded as actual operator expressions and
remain distinct from an expanded ordinary kinetic/potential/mass theorem.
Ordinary source-free counterterms cannot generate a source here because
the actual elementary field maps are source independent. Conversely the
source-free part of qJ can generate ordinary terms and must not be declared
zero globally. Any such ordinary coefficient not calculated stays open.

Primary component/cochain contractions versus literal graded polynomial
Leibniz/adjoint differentiation. Compare every admitted coefficient and
zero complement; retain actual nonzero images. Check second variations
only in their demonstrated classical source module. Use sensitive source-
orientation,omitted-companion and ghost-sign controls where meaningful,
reporting insensitive cases honestly. A formal consistency identity is
not an independently replayed quantum-root integral.

Sequential actual map/variation workers300s after imports,verifiers/audits
180s,8GiB sampled-private,350MiB available-pagefile launch floor,64MiB
complete packet. Freeze source copies and actual input hashes before each
computation. Preserve exact failed/unfinished sources,captures/manifests;
no silent resource increase,truncation,input or tolerance change.

Authority ceiling: actual projected source maps/descent and justified
bounded regulator interpretation only. No HB1/C5 or full counterterm
classification,full QAP/products/chiral measure/phase,physical source
reality,scheme adoption,E5/A5 or physical GUT. General BBx triangle and
broader physical obligations remain. Shared action,charts/data,qualified
helpers,libraries and AI author limit independence; no external scientist,
formal-proof or physical validation is inferred from agreement.
