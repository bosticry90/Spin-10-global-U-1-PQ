from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
from itertools import product
import gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'map_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('map_'+('replay'if role=='primary'else'primary')):raise PermissionError('ISD1_PEER_DENIED')
sys.addaudithook(guard)
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.expand(s.sympify(z,locals=loc))
cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v)for i,j,v in z['entries']});clean=lambda z:{k:s.expand(v)for k,v in z.items()if s.expand(v)!=0};enc=lambda z:[[list(k),str(v)]for k,v in sorted(clean(z).items())]
# Variables: JL0:45 odd,Ja45:90 even,JC90:135 even,
# C135:180 odd,a180:225 odd,Lambda225:270 even.
par=lambda i:int(i<45 or 135<=i<225)
def canon(w):
 if len(set(i for i in w if par(i)))!=sum(par(i)for i in w):return (),0
 sg=(-1)**sum(par(a)*par(b)*(a>b)for j,a in enumerate(w)for b in w[j+1:]);return tuple(sorted(w)),sg
def addto(out,w,v):
 ww,sg=canon(w)
 if sg:out[ww]+=sg*v
def diff(z,idx):
 out=defaultdict(lambda:0)
 for w,v in z.items():
  for j,a in enumerate(w):
   if a==idx:out[w[:j]+w[j+1:]]+=(-1)**(par(idx)*sum(par(k)for k in w[:j]))*v
 return clean(out)
def vary(z,Q):
 out=defaultdict(lambda:0)
 for w,v in z.items():
  for j,a in enumerate(w):
   sg=(-1)**sum(par(k)for k in w[:j])
   for ww,c in Q.get(a,{}).items():addto(out,w[:j]+ww+w[j+1:],sg*v*c)
 return clean(out)
d=load(O/('map_'+role+'_inputs.json.gz'));frame=d['frame'];xs=d['xs'];aux=[('b'if i<12 else'L')+str(i)for i in range(45)];ants=[('bar'if i<12 else'ub')+str(i)for i in range(45)];cs=['C'+str(i)for i in range(45)];phys=[f'B{i}_{mu}'for i in range(45)for mu in range(4)]+xs+aux+cs+ants;ri={n:i for i,n in enumerate(frame['field_order'])};pi={n:i for i,n in enumerate(phys)};TI=dec(frame['physical_to_raw_inverse']);TF=dec(frame['physical_to_raw_kernel'])
def block(ns):
 T=TI.extract([ri[n]for n in ns],[pi[n]for n in ns]);F=TF.extract([pi[n]for n in ns],[ri[n]for n in ns]);assert not cl(T*F-s.eye(len(ns))).todok();return T,F
TL,FL=block(aux);TA,FA=block(ants);TC,FC=block(cs);by={};source={};outfield={};outphase={};field_maps=d['field_maps']
for names,T,F,off,p,phase in [(aux,TL,FL,225,0,-s.I),(ants,TA,FA,180,1,1),(cs,TC,FC,135,1,1)]:
 for k,n in enumerate(names):
  by[n]=[(off+j,z*phase)for(kk,j),z in T.todok().items()if kk==k];source[n]=[(off-225+r if off==225 else 45+r if off==180 else 90+r,(-1)**(p+1)*v/phase)for(r,kk),v in F.todok().items()if kk==k];outfield[n]=[(off+r,v/phase)for(r,kk),v in F.todok().items()if kk==k];outphase[n]=p
# Primary transports field outputs/components. Replay transports the actual
# source density,then recovers q fields by graded source differentiation.
Q={};Sigma=defaultdict(lambda:0)
if role=='primary':
 for n,rows in field_maps.items():
  for row in rows:
   assert all(w in by for w in row['word']),(n,row)
   for factors in product(*(by[w]for w in row['word'])):
    ww=tuple(k for k,v in factors);co=parse(row['coefficient'])*s.prod(v for k,v in factors)
    for out,v in outfield[n]:
     if out not in Q:Q[out]=defaultdict(lambda:0)
     addto(Q[out],ww,co*v)
 Q={k:clean(v)for k,v in Q.items()}
 for out,z in Q.items():
  sg=(-1)**par(out)
  # C output135->JC90, a180->Ja45, L225->JL0.
  src=out-225 if out>=225 else out-45 if out<180 else out-135
  for w,v in z.items():addto(Sigma,(src,)+w,sg*v)
else:
 for n,rows in field_maps.items():
  for row in rows:
   assert all(w in by for w in row['word']),(n,row)
   for ss,sc in source[n]:
    # Sigma_E=-Sigma_M; source has its own graded inverse chart.
    partial={(ss,):-sc*parse(row['coefficient'])}
    for w in row['word']:
     nn=defaultdict(lambda:0)
     for ww,v in partial.items():
      for j,t in by[w]:addto(nn,ww+(j,),v*t)
     partial=clean(nn)
    for ww,v in partial.items():Sigma[ww]+=v
 Sigma=clean(Sigma)
 for out in range(135,270):
  src=out-225 if out>=225 else out-45 if out<180 else out-135;Q[out]={w:(-1)**par(out)*v for w,v in diff(Sigma,src).items()}
Sigma=clean(Sigma);Q={k:clean(v)for k,v in Q.items()}
assert all(sum(par(i)for i in w)%2==(par(out)+1)%2 for out,z in Q.items()for w in z)
beta={};D={};alpha={};B={};qc={}
for out,z in Q.items():
 for w,v in z.items():
  if out>=225:
   if len(w)==2:assert 135<=w[0]<180 and 225<=w[1]<270;beta[out-225,w[0]-135,w[1]-225]=v
   else:assert len(w)==3 and 135<=w[0]<w[1]<180 and 180<=w[2]<225;D[out-225,w[0]-135,w[1]-135,w[2]-180]=v
  elif out>=180:
   if len(w)==1:assert 225<=w[0]<270;alpha[out-180,w[0]-225]=v
   else:assert len(w)==2 and 135<=w[0]<180 and 180<=w[1]<225;B[out-180,w[0]-135,w[1]-180]=v
  else:assert len(w)==2 and 135<=w[0]<w[1]<180;qc[out-135,w[0]-135,w[1]-135]=v
# Actual source-homogeneous flow. The primary uses explicit tensor adjoints;
# replay uses left Euler derivatives of the transported source action.
JQ={k:defaultdict(lambda:0)for k in range(90)}
if role=='primary':
 for(r,c,a),v in beta.items():addto(JQ[a],(r,135+c),v)
 for(r,a),v in alpha.items():addto(JQ[a],(45+r,),-v)
 for(r,c,k,a),v in D.items():addto(JQ[45+a],(r,135+c,135+k),v)
 for(r,c,a),v in B.items():addto(JQ[45+a],(45+r,135+c),-v)
else:
 for k in range(45):JQ[k]=diff(Sigma,225+k);JQ[45+k]={w:-v for w,v in diff(Sigma,180+k).items()}
JQ={k:clean(v)for k,v in JQ.items()}
# Test the actual field maps; classical chiral curvature is outside this
# nonminimal/C module. Test cotangent identities without pretending qJ=0.
nonmin_res={};source_res={};whole={**Q,**JQ}
for k,z in Q.items():
 r=vary(z,Q)
 if r:nonmin_res[k]=enc(r)
for k,z in JQ.items():
 r=vary(z,whole)
 if r:source_res[k]=enc(r)
assert not nonmin_res,('nonminimal_nilpotence_failed',list(nonmin_res.items())[:1]);assert not source_res,('cotangent_nilpotence_failed',list(source_res.items())[:1])
def et(z):return [[*k,str(v)]for k,v in sorted(z.items())]
out={'schema':'ISD1_ACTUAL_WICK_NONMINIMAL_AND_COTANGENT_MAPS','role':role,'field_maps':[[k,enc(z)]for k,z in sorted(Q.items())],'source_maps':[[k,enc(z)]for k,z in sorted(JQ.items())],'Sigma_source_nonminimal_C':enc(Sigma),'beta_C_L':et(beta),'D_CC_a':et(D),'alpha_L':et(alpha),'B_C_a':et(B),'qC_CC':et(qc),'field_nilpotence_remainders':nonmin_res,'cotangent_nilpotence_remainders':source_res,'source_free_Euler_not_included_not_set_zero':True,'physical_source_reality_or_QAP_E5_A5_claim':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('map_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'alpha_beta_D_B_qC_nonzero':[len(alpha),len(beta),len(D),len(B),len(qc)],'nonminimal_and_cotangent_nilpotence':True},sort_keys=True),flush=True);timer.cancel()
