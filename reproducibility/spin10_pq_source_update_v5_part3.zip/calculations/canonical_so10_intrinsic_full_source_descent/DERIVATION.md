# Cotangent operation and Wick transport before source projection

Use the actual CSW bracket and Sigma_M=S0_M+sum J_M R_M. It gives
q phi_M=R_M and q J_M=leftEuler_phi_M Sigma_M. This is the linearized
Slavnov/cotangent operation,not a replacement of an elementary external
source convention by qJ=0. Probe doublet: d u=rho,d rho=0.

In the physical coordinate frame,let phi_M=T_phi phi_E for the Wick
phase alone after ordinary linear chart transport. For x,C,a these Wick
phases are1; for Lambda they are-i. For vector time components use+i,
though they do not enter the source-homogeneous zero-jet maps here.
The common action convention is Sigma_E=-Sigma_M. Matching the actual
source density gives J_M=(-1)^(p_phi+1) T_phi^-1 J_E,so JLambda_M=-i
JLambda_E,Ja_M=Ja_E,Jx_M=-Jx_E and JC_M=JC_E. Source pairing is graded;
do not impose the same ungraded cotangent phase on every field.

With R_E=T_phi^-1 R_M(T phi_E),the source action is

 Sigma_source,E=sum (-1)^p_phi J_E R_E.

Transport of q gives q phi_E=R_E and
q J_E=(-1)^p_phi leftEuler_phi_E Sigma_E. This follows directly by
chain rule,not a new physical convention. Check the Lambda/antighost
vertices against the already qualified IAS/IAG densities, and scalar/
ghost generators against the actual IFC source action. Use actual field
and inverse source charts before applying the displayed scalar phases.

Separate source degree only after differentiation. The homogeneous
single-source flow is obtained from Sigma_source,E. The omitted source-
free contribution is qJ_E|J0=(-1)^p Euler_phi S0_E and is an ordinary
Euler descendant,not zero. The source operation's homogeneous block acts
on the existing source functional with no contribution from ordinary
source-free counterterms because the actual R_E has no sources.

Write the measured source functional in source-first order as

 Csrc=rho Jx V+u Jx C U+rho JLambda Lx-2i u Ja Lx
       +u JLambda C Nx.

The compact -2i ratio is measured,not an assumed cotangent identity.
Check actual q a's Lambda-linear map before using any cancellation.
For example,only IF q a=2i Lambda+B(C)a and q Lambda=B(C)Lambda+
D(CC)a in the actual chart,one obtains
q JLambda=JLambda B(C)-2i Ja and the corresponding Ja flow by left
differentiating Sigma_source,E. Actual transported tensors,including
cubic CCa,determine whether these equalities hold. A failure cannot be
repaired by altering a measured coefficient.

Nilpotence and first/second source variations here refer to the classical
nonminimal/cotangent module. The full chiral master relation has Ihat
curvature;do not promote these checks to full QAP or quantum equivalence.
The complete ordinary Euler image and its loop/regulator counterpart need
their own actual action/domain tests. Keep nonzero relative source images.
