# ISD3 source filtration and lower-probe applicability audit

Prospective180-second audit after the ISD2 jobs terminate. No new quantum
coefficient is assigned. Question: is the homogeneous one-source image
alone a complete source projection of the full regulated first-probe
identity? Explicitly test the source-degree/intrinsic-grade dependency.

Source Euler terms lower source degree. Even if first-intrinsic-degree
counterterms have only the five measured one-source types,the full source
projection can receive q0 acting on marginal source-quadratic C1,via the
actual intrinsic Euler blocks E_Lambda=N0_Lx*x and E_a=S0*C*x. Enumerate
the local dim4/ghost0/parity/Lorentz TYPE envelope,not an invariant basis
or protected HB1/C5 construction. Keep zeroth/first probe and intrinsic
grades separately. Do not assume these allowed types have nonzero quantum
coefficients,but do not silently assign them zero.

At first probe degree also retain B1 C0. Actual source degree s in the
original G/QG changes required C0 degree by j0=2-s for a final single
source. Scan EVERY actual G/QG monomial by source IDs,independently check
via source-name histogram,and retain actual source-quadratic references.
Do not restrict sources/backgrounds before computing source degree.
Higher source degree,if present,is recorded,not silently discarded.
Derive the actual possible J2->J1 routes using N0/S0. Existing IFC Jx
projection restrictions do not automatically cover the nonminimal sector.

Record complete typed patterns,actual source-degree inventories and
qualified classical nonzero Euler carriers. These prove a missing
applicability obligation,not a numerical cancellation,anomaly or physical
inconsistency. A term is required to be computed or excluded; type support
alone does not prove its loop coefficient is nonzero. Next choose the
smallest complete missing quantum family by this dependency audit.

Same8GiB sampled/350MiB launch floor/64MiB packet. Sources,copies and
actual input hashes frozen before execution; preserve failures. Shared
action/data/helpers/library/AI author; no authority or scheme adoption.
