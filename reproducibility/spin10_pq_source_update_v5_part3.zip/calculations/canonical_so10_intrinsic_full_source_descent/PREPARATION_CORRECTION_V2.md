# ISD1 preparation V2

Original controller FAILED before preparation or native execution on the
guessed validation_receipt_v3.json. The actual CSW receipt, inspected with
rg --files,is validation_receipt.json. Preserve original source/copy and
complete controller traceback. V2 changes this binding and failure custody
only; no source/action/input/scientific condition or resource change.
