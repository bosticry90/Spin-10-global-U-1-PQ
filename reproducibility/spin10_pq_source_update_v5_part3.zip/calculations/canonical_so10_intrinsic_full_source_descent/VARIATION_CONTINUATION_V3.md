# Complete per-basis continuation after a second bounded exhaustion

V2 primary exited124 at300s after reporting probe0 zeros and nonzero
chi4/log2 stage counts. It produced NO tables/result/validation receipt.
Preserve its sources/copies/preparation/full capture/controller failure;
the partial stage observations are not accepted coefficients. No replay
ran. This is RESOURCE_EXHAUSTED/INCOMPLETE,not a mathematical verdict.

Reassessment: the exact source image has160380/199636 F positions in
those two formal components. Computing all four in one worker,plus a
redundant component calculation inside the literal replay,is unnecessary
engineering coupling. Separate the four independent formal bases chi4,
log2,log3,log5. Each job still covers both probes,all six image families
and every coefficient/zero. Primary uses component equations and explicit
rho consistency checks; replay uses literal polynomial Leibniz and classifies
ALL resulting words into the same six complete families. The late verifier
compares their completed full outputs; replay need not repeat the primary
algorithm first. Generator nilpotence remains the same qualified proof of
the full projected second variation; no new triple-ghost replay is claimed.

Prospective resource boundary: eight SEQUENTIAL native jobs,one per
basis/method,300s after imports EACH (maximum2400s total native time),
one180s streaming verifier,unchanged8GiB sampled-private/350MiB floor and
64MiB whole packet. This explicit bounded continuation changes work-unit
partition and removes duplicate algorithm execution; it does not reduce
scientific acceptance,alter inputs/tolerances or hide an increased total
possible native allowance. No more than one native runs at once.
No overall qualification until ALL four independent bases pass. Partial
tables remain provisional if any job fails or exhausts its bound.

Use unchanged exact arithmetic with1024 primitive products and input
roundtrips. No reading of prior stage counts or expected images as native
operands. Preserve original receipts/failed evidence unchanged. This is
delegated ordinary scientific execution,not a physical scheme or authority
decision. Reassess rather than repeatedly launching full failed jobs.
