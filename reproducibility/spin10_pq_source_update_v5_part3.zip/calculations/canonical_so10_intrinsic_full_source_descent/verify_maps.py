from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'map_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[json.loads(gzip.decompress((O/('map_'+r+'_tables.json.gz')).read_bytes()))for r in ['primary','replay']]
for z in [a,b]:z.pop('role');assert not z['field_nilpotence_remainders']and not z['cotangent_nilpotence_remainders']
assert a==b
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'field_tensor_vs_source_density_cotangent_maps_all_coefficients_and_zeros_agree':True,'alpha_beta_D_B_qC_nonzero':[len(a[k])for k in ['alpha_L','beta_C_L','D_CC_a','B_C_a','qC_CC']],'actual_nonminimal_and_cotangent_nilpotence_checked':True,'full_chiral_QAP_E5_A5_claim':False},sort_keys=True),flush=True);timer.cancel()
