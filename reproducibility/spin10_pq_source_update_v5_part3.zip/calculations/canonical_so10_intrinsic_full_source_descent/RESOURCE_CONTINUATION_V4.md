# Replay continuation after repeated not-launched resource rejection

V3 also ended before a replay spawn because the unchanged350MiB floor
was not met at the helper's actual fresh launch observation. Preserve
that complete traceback and its prospective preparation/source copies.
Neither attempt is a failed replay calculation or a scientific PASS.

V4 reauthenticates the same completed primary and unchanged native/source
inputs. No primary rerun or native source modification. To avoid launch
churn on a fluctuating host,observe memory at most21 times,30s apart;
require3 successive observations at least768MiB available commit and
256MiB available physical memory before attempting the original helper.
These are conservative operational cushions,not a weakened350MiB
contract floor or enlarged8GiB/300s native resource cap. Append every
observation to a new resource log. If the cushion never holds,classify
the dependent replay INCONCLUSIVE/NOT_LAUNCHED; no science receipt.
Any launch-race rejection is preserved and stops this controller.
Do not terminate unrelated processes or infer a worker is live from intent.

Use the already frozen verify_maps_v2.py for semantic zero completion
when both natives have completed. Its135-coordinate exact comparison
and all original scientific tests remain. No new physical assumption,
finite coefficient,tolerance or scientific promotion is introduced.
