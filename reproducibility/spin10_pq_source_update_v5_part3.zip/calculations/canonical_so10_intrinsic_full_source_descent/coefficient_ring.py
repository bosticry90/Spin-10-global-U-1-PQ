from fractions import Fraction
from functools import lru_cache
import sympy as s

g,xi,eta=s.symbols('g10 xi eta_H',real=True)
primes=(2,3,5,7)
roots=tuple(s.sqrt(s.prod(primes[k]for k in range(4)if m&(1<<k)))*(s.I if m&16 else 1)for m in range(32))
root_ids={r:m for m,r in enumerate(roots)}

class Coeff:
 __slots__=('terms',)
 def __init__(self,terms=()):self.terms=tuple((k,v)for k,v in sorted(terms)if v)
 def __bool__(self):return bool(self.terms)
 def __hash__(self):return hash(self.terms)
 def __eq__(self,other):
  if isinstance(other,int):return self==constant(other)
  return isinstance(other,Coeff)and self.terms==other.terms
 def __add__(self,other):
  if isinstance(other,int):other=constant(other)
  if not other:return self
  if not self:return other
  out=dict(self.terms)
  for k,v in other.terms:out[k]=out.get(k,Fraction(0))+v
  return Coeff(out.items())
 __radd__=__add__
 def __neg__(self):return Coeff((k,-v)for k,v in self.terms)
 def __sub__(self,other):return self+(-other)
 def __rsub__(self,other):return (-self)+other
 def __mul__(self,other):
  if isinstance(other,int):return Coeff((k,v*other)for k,v in self.terms)
  if not self or not other:return ZERO
  out={}
  for (a,b,c,m),v in self.terms:
   for (aa,bb,cc,n),w in other.terms:
    f=(-1 if m&n&16 else 1)
    for k,p in enumerate(primes):
     if m&n&(1<<k):f*=p
    key=(a+aa,b+bb,c+cc,m^n);out[key]=out.get(key,Fraction(0))+f*v*w
  return Coeff(out.items())
 __rmul__=__mul__
 def __str__(self):return string(self.terms)

@lru_cache(None)
def constant(n):return Coeff([((0,0,0,0),Fraction(n))])
ZERO=Coeff()
I=Coeff([((0,0,0,16),Fraction(1))])

@lru_cache(None)
def expression(terms):
 return s.expand(sum((s.Rational(v.numerator,v.denominator)*g**a*xi**b*eta**c*roots[m]for(a,b,c,m),v in terms),s.Integer(0)))

@lru_cache(None)
def string(terms):return str(expression(terms))

@lru_cache(None)
def coefficient(expr):
 expr=s.expand(expr)
 out={}
 for powers,v in s.Poly(expr,g,xi,eta).terms():
  assert all(isinstance(n,int)and n>=0 for n in powers)
  for term in s.Add.make_args(s.expand(v)):
   q,r=term.as_coeff_Mul();assert q.is_Rational and r in root_ids,(expr,term,q,r)
   key=tuple(powers)+(root_ids[r],);out[key]=out.get(key,Fraction(0))+Fraction(int(q.p),int(q.q))
 z=Coeff(out.items());assert s.expand(expression(z.terms)-expr)==0
 return z

def verify_basis_products():
 for a in range(32):
  for b in range(32):
   x=Coeff([((0,0,0,a),Fraction(1))]);y=Coeff([((0,0,0,b),Fraction(1))]);assert s.expand(expression((x*y).terms)-roots[a]*roots[b])==0,(a,b)
 return 1024
