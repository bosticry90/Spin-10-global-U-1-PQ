from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-full-source-descent-v1-2026-10-25');P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(P));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'filtration_preparation.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 for n in ['filtration_preparation.json','filtration_capture.json','variation_validation_preparation_v3.json','variation_validation_receipt_v3.json','variation_v3_verify_capture.json']:p=O/n;b[str(p)]=H(p)
 A=O.parent/'canonical_so10_intrinsic_auxiliary_source';G=O.parent/'canonical_so10_intrinsic_auxiliary_ghost_source';ip={'audit':str(O.parent/'canonical_so10_intrinsic_kinetic_support/support_primary_inputs.json.gz'),'G_operand':str(A/'vertex_primary_inputs.json.gz'),'QG_operand':str(A/'uc_support_primary_inputs.json.gz'),'vertices':str(G/'vertex_primary_inputs.json.gz')}
 for p in ip.values():b[p]=H(Path(p))
 dump(O/'filtration_inputs_v2.json',ip);b[str(O/'filtration_inputs_v2.json')]=H(O/'filtration_inputs_v2.json')
 for n in ['FILTRATION_CORRECTION_V2.md','filtration_controller_failure.json','filtration_v2.py','run_filtration_v2.py']:
  p=O/n;cp=O/(n+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(cp)]=H(cp)
 dump(O/'filtration_preparation_v2.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
 z=capture([sys.executable,'-B',str(O/'filtration_v2.py')]);dump(O/'filtration_v2_capture.json',z);dump(C/'filtration_v2_full_capture.json',z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
 rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<180;dump(O/'filtration_receipt_v2.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<64*1024**2;print('COMPLETED_ISD3',json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'filtration_controller_failure_v2.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
