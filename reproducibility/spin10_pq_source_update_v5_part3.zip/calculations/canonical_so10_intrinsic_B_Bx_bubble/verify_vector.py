from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import gzip,json,time
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter()
for p,h in read(O/'vector_validation_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
a,b=[load(O/('vector_'+r+'_tables.json.gz'))for r in ['primary','replay']];assert{k:v for k,v in a.items()if k!='role'}=={k:v for k,v in b.items()if k!='role'};assert a['signed_int64_bound']<2**63;rows=a['coefficient_integer_entries'];assert len(rows)==len({tuple(q[:-1])for q in rows});d={tuple(q[:-1]):q[-1]for q in rows};families=defaultdict(set)
for k,v in d.items():assert d.get(k[:6]+(k[7],k[6])+k[8:],0)==v;families[k[0],k[1]].add(k[6:9])
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'unbounded_paths_vs_certified_sparse_integer_products_agree':True,'all_polynomial_radical_coefficients_and_zero_complements_agree':True,'signed_int64_bound':a['signed_int64_bound'],'coefficient_rows':len(rows),'family_nonzero_positions':[[*k,len(v)]for k,v in sorted(families.items())],'other_BBx_triangle_and_E5_not_qualified':True},sort_keys=True),flush=True)
