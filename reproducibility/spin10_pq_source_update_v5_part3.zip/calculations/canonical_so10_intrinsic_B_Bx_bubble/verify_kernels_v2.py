from pathlib import Path
from hashlib import sha256
import gzip,json,time,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter()
for p,h in read(O/'kernel_v2_validation_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
a,b=[load(O/('kernel_v2_'+r+'_tables.json.gz'))for r in ['primary','replay']];assert{k:v for k,v in a.items()if k!='role'}=={k:v for k,v in b.items()if k!='role'};assert len(a['cases'])==12;D,wa=s.symbols('D wa');source=next(q for q in a['cases']if q['category']=='source')['rows'];assert len(source)==1 and source[0]['m']==2;v=s.sympify(source[0]['coefficients']['D_Ka']);assert s.simplify(v+1+(wa-1)/D)==0
for q in a['cases']:
 for row in q['rows']:
  for v in row['coefficients'].values():assert s.Poly(s.cancel(s.sympify(v)*D),D).degree()<=1
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'all12_matrix_trace_vs_closed_index_kernels_agree':True,'source_mixed_vector_trace_matches_Ddimensional_formula':True,'cases':a['cases'],'actual_color_or_QAP_E5':False},sort_keys=True),flush=True)
