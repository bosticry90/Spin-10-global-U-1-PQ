# IAG2: exact word coverage and discriminating kernel controls

Freeze after IAG1's literal paired Gaussian/Schur routes agree at every
heat power. Its chosen numeric CCa source trace happens to cancel at m2;
omitting that source is therefore INSENSITIVE in that first witness.
Changing the input U_LL is also insensitive there. Preserve both results;
neither validates those omissions in the actual model.

Review every actual448/726 IAS8 word. Root only at its unique J vertex,
preserving orientation,Green path and all original rotations. Classify
direct ghost-source bubbles,linear-source bosonic-background variations,
and linear-source ghost-background variations. Retain every member/port
reference. No coefficient is inferred by dividing an unsigned word count.
The graded Gaussian,not this inventory,sets signs and multiplicities.

Add a focused nonzero source-Gaussian witness with beta/W=0,
Z0=i diag(1,0),Zu=0 and all other original numeric kernels unchanged.
Its direct m2 coefficient must be2i=Tr(Su Z0); literal Hessian and Schur
routes must agree. This is a universal mathematical control,not a changed
physical benchmark or fitted quantum contribution. Reversing external
source order or omitting CCa is then detectable. Also test omission of
the derivative U_BB block separately,reporting the actual sensitivity.

One180s reviewer,8GiB sampled,350MiB floor,64MiB packet. Read only explicit
bound kernel definitions,never execute their entry point. Freeze actual
input/source hashes/copies before launch,preserve every failure. Complete
coverage and conventions only;model source coefficients remain unmeasured.
