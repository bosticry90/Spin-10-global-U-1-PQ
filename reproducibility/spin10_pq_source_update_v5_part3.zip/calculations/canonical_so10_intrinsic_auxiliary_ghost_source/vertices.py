from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
from itertools import product
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'vertex_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('vertex_'+('replay'if role=='primary'else'primary')):raise PermissionError('IAG3_PEER_DENIED')
sys.addaudithook(guard)
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(v):return s.expand(s.sympify(v,locals=loc))
cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);dec=lambda M:s.SparseMatrix(*M['shape'],{(i,j):parse(z)for i,j,z in M['entries']});clean=lambda z:{k:s.expand(v)for k,v in z.items()if s.expand(v)!=0};tab=lambda q:{tuple(z[:-1]):parse(z[-1])for z in q};encode=lambda z:[[*k,str(v)]for k,v in sorted(clean(z).items())];enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(v)]for(i,j),v in sorted(cl(M).todok().items())]}
d=load(O/('vertex_'+role+'_inputs.json.gz'));frame=d['frame'];xs=[f'x_{sec}_{i}'for sec,n in[('Phi',54),('Sigma',252),('phi',20),('S',2)]for i in range(n)];aux=[('b'if i<12 else'L')+str(i)for i in range(45)];ants=[('bar'if i<12 else'ub')+str(i)for i in range(45)];ghosts=['C'+str(i)for i in range(45)];phys=[f'B{i}_{mu}'for i in range(45)for mu in range(4)]+xs+aux+ghosts+ants;ri={n:i for i,n in enumerate(frame['field_order'])};pi={n:i for i,n in enumerate(phys)};TI=dec(frame['physical_to_raw_inverse']);TF=dec(frame['physical_to_raw_kernel'])
def block(ns):return TI.extract([ri[n]for n in ns],[pi[n]for n in ns]),TF.extract([pi[n]for n in ns],[ri[n]for n in ns])
TL,FL=block(aux);TC,FC=block(ghosts);TA,FA=block(ants)
for A,F in[(TL,FL),(TC,FC),(TA,FA)]:assert not cl(A*F-s.eye(45)).todok()
assert not cl(FC*dec(frame['raw_ghost_Green'])*FA.T-s.eye(45)).todok()
byF=defaultdict(list);byC=defaultdict(list);byA=defaultdict(list)
for(r,k),z in FL.todok().items():byF[k].append((r,z))
for(k,c),z in TC.todok().items():byC[k].append((c,z))
for(k,a),z in TA.todok().items():byA[k].append((a,z))
ix=lambda n:int(n[3:]if n.startswith('bar')else n[2:]if n.startswith('ub')else n[1:])
def raw_odd(w):
 assert len(w)==3 and sum(n.startswith('C')for n in w)==2 and sum(n in ants for n in w)==1 and all('__'not in n for n in w)
 return[(('C'if n.startswith('C')else'a'),ix(n))for n in w]
Z0=defaultdict(lambda:0);cubic=0
if role=='primary':
 for outname,rows in d['qLambda'].items():
  for row in rows:
   if len(row['word'])==2:continue
   w=raw_odd(row['word']);cubic+=1;z=parse(row['coefficient'])
   for at,(kind,h0)in enumerate(w):
    if kind!='C':continue
    rest=w[:at]+w[at+1:];aa=next(a for k,a in rest if k=='a');cc=next(c for k,c in rest if k=='C');sg=(-1)**at*(-1 if rest[0][0]=='C'else 1)
    for(r,f),(h,c1),(a,a1),(c,c2)in product(byF[ix(outname)],byC[h0],byA[aa],byC[cc]):Z0[r,h,a,c]+=s.I*sg*z*f*c1*a1*c2
else:
 # Transport the cubic exterior polynomial BEFORE selecting an external ghost.
 pol=defaultdict(lambda:0)
 for outname,rows in d['qLambda'].items():
  for row in rows:
   if len(row['word'])==2:continue
   w=raw_odd(row['word']);cubic+=1;z=parse(row['coefficient']);cs=[c for k,c in w if k=='C'];aa=next(a for k,a in w if k=='a');move=(-1)**sum(k=='C'for k,c in w[w.index(('a',aa))+1:])
   for(r,f),(b,c1),(c,c2),(a,a1)in product(byF[ix(outname)],byC[cs[0]],byC[cs[1]],byA[aa]):
    if b==c:continue
    lo,hi=sorted([b,c]);pol[r,lo,hi,a]+=move*(1 if b<c else-1)*z*f*c1*c2*a1
 for(r,b,c,a),z in clean(pol).items():Z0[r,b,a,c]+=-s.I*z;Z0[r,c,a,b]+=s.I*z
Z0=clean(Z0);print('STAGE_IAG3_Z0',role,len(Z0),flush=True)
a=d['audit'];names=a['names'];geo=a['geometry'];base=geo['names'];par=dict(zip(base,geo['parities']));sources={names.index(base[J]):base[f]for f,J,h,k in geo['field_source_h_k']};ai={n:i for i,n in enumerate(aux)}
def co(p,ci,gp):
 z=0
 for xp,ep,mask,num,den in p['coefficients'][ci]:
  v=s.Rational(num,den)*xi**xp*eta**ep
  for j,q in enumerate([2,3,5,7]):
   if mask&(1<<j):v*=s.sqrt(q)
  if mask&16:v*=s.I
  z+=v
 return s.expand(z*g**gp)
ZU=[]
for probe,p in enumerate(a['physical_QG']):
 zz=defaultdict(lambda:0)
 for gp,w,ci in p['monomials']:
  js=[(at,n,I)for at,(n,I)in enumerate(w)if n in sources]
  if len(js)!=1:continue
  at,n,I=js[0]
  if sources[n]not in ai:continue
  assert not I
  rest=[(names[nn],J)for j,(nn,J)in enumerate(w)if j!=at]
  if any(nn.startswith(('A','J'))for nn,J in rest):continue
  assert all(not J for nn,J in rest);ww=raw_odd([nn for nn,J in rest]);r=ai[sources[n]]
  sg=(-1)**sum(par[names[nn]]for nn,J in(w[:at]if role=='primary'else w[at+1:]))
  if role=='replay':sg*=-1 # right source derivative of even QG
  z=sg*co(p,ci,gp)
  for k,(kind,h)in enumerate(ww):
   if kind!='C':continue
   rem=ww[:k]+ww[k+1:];aa=next(a for v,a in rem if v=='a');cc=next(c for v,c in rem if v=='C');sgg=(-1)**(k if role=='primary'else len(ww)-k-1);sgg*=(-1 if rem[0][0]=='C'else 1);zz[r,h,aa,cc]+=s.I*sgg*z
 ZU.append(clean(zz));print('STAGE_IAG3_Zu',role,probe,len(ZU[-1]),flush=True)
# Full projected classical endings. These are not quantum source coefficients.
beta=tab(d['beta']);B=s.SparseMatrix(2025,45,{(r*45+a,c):z for(r,a,c),z in beta.items()});eds=d['endings'];G0=dec(eds['G0']);N0=dec(eds['N0']);S0=tab(d['S0']);old=[dec(M)for M in eds['J0']]
def flat(mats):
 out={}
 for h,M in enumerate(mats):
  for(c,j),z in M.todok().items():out[c,h*328+j]=z
 return s.SparseMatrix(45,45*328,out)
def project(M):
 if role=='replay':return cl(B*M)
 by=defaultdict(list);out=defaultdict(lambda:0)
 for(c,j),z in M.todok().items():by[c].append((j,z))
 for(r,c),z in B.todok().items():
  for j,w in by[c]:out[r,j]+=z*w
 return cl(s.SparseMatrix(2025,M.cols,dict(out)))
oldS=[s.SparseMatrix(45,328,{(a,i):z for(a,c,i),z in S0.items()if c==h})for h in range(45)];NH=[cl(-M*G0*N0)for M in old];proj0=project(flat(oldS));projN=project(flat(NH));products=[]
for probe,rows in enumerate(eds['mixed']):
 pieces=[[dec(z['pieces'][j])for z in rows]for j in range(4)]
 for h in range(45):assert not cl(sum((pieces[j][h]for j in range(4)),s.zeros(45,328))).todok()
 pp=[project(flat(ms))for ms in pieces]
 products.append({'probe':probe,'projected_P':[enc(M)for M in pp],'all_four_unfiltered_endings_sum_zero':True});print('STAGE_IAG3_PROJECTED',role,probe,[len(M.todok())for M in pp],flush=True)
out={'schema':'IAG3_ACTUAL_CUBIC_SOURCE_AND_PORTS','role':role,'Z0_JC_aC':encode(Z0),'Zu_JC_aC':[encode(z)for z in ZU],'raw_cubic_qLambda_rows':cubic,'beta_S0':enc(proj0),'beta_old_inverse_ending':enc(projN),'projected_endings':products,'ghost_metric_I_verified':True,'quantum_target_measured':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('vertex_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'Z0_Zu_nonzero':[len(Z0)]+[len(z)for z in ZU],'beta_S0_N_nonzero':[len(proj0.todok()),len(projN.todok())],'projected_P_nonzero':[[len(M['entries'])for M in q['projected_P']]for q in products]},sort_keys=True),flush=True);timer.cancel()
