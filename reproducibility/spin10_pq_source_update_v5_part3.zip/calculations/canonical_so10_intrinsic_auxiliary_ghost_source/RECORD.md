# IAG1+: complete intrinsic u-JLambda-C-x finite conversion

Freeze October25,2026 atd36d47f5af4c003f6415380a9e4d456fcf593680.
Previous goal turn PROGRESS: complete rho-JLambda-x/u-Ja-x carriers and
actual remaining-source inventory. Fresh preflight cleanmain/no matching
research workers,appgoalACTIVE. State113/34of39,E5/A5 OPEN,custodyexit2/
sevenNOTPASS unchanged. Live AGENTS. No agents,branch/worktree,push,
publication/outreach,foundations/scheme/benchmark adoption,flavor/HB1C5
activation or protected promotion. Preserve all previous evidence.

Question: independently measure the last selected intrinsic source pattern,
u JLambda_r C_h x_i, before testing a common finite source conversion.
This is the actual missing companion of IAS/IFC,not a coefficient selected
to cancel the ordinary BBx witness. Both a nonzero finite map and a
structural zero are permitted outcomes. An invalid operator/phase/domain
or exhausted resources leaves the affected claim incomplete.

Original unshifted SMA/CSW/EDS,A0,constant first even u,one odd auxiliary
source JLambda,one ordinary external ghost C,one scalar x,zero external
jets,one intrinsic GF/reference coefficient of dimension1,all45 sources,
45 external/internal ghosts,328 scalars,both probes,symbolic g10/xi/eta_H.
Final source order u JLambda C x. This is the inherited local relative
DIM-minus-fixed-heat calculation on common nonexceptional Euclidean
momenta,not a scaleless physical constant-field trace or full finite-p
massive amplitude. Physical cubic/mass,nonlinear multi-products and higher
reference/probe classes are distinct,not set to zero globally.

The already qualified IAS8 inventory has45letters,448/726ordered words.
First authenticate it and prove every word belongs to the compact
graded-Gaussian reduction in DERIVATION.md,including direct original/probe
JLambda-CCa,linear source JLambda-CL,old/probe currents,Su/S0,U/N0/Nr,
physical kinetic scalar current and positive-reference probe BBx D.
The original CCa source now has an external ghost and two integrated
ports; the earlier unused-ghost exclusion MUST NOT be imported.

Derive signs/halves with a literal paired-momentum graded Hessian and
independent boson elimination/ghost determinant. Retain noncommuting
matrix order and each positive-heat edge. Use exact truncated grades
(n,u,x,J,C), not a numerical Born cutoff: the target consumes each grade
once and the proven bound is5. Verify wrong source ordering/omissions
where sensitive. Prove longitudinal endpoint reduction and absence of a
closed Lorentz spectator before declaring a zero D jet.

Then freeze actual source-cubic vertices,using raw qLambda codomain and
ghost/antighost field charts versus independent tensor transport. Probe
QG source derivatives precede restriction,with actual Grassmann parities
and Euclidean source phase JLambda_M=-i JLambda_E. No guessed extra i,
half,coupling or source map. Reuse qualified CLASSICAL EDS endings and
actual R/N/D/S0/Su only in their demonstrated ports/orders. Quantum IAS/
IFC coefficients and the desired Ward/Euler image are not native operands.

Primary explicit exact sparse paths versus a distinct sparse-matrix
contraction must compare all45x45x328 positions including zero complements
at each heat length/finite basis. Keep all polynomial parameter powers.
Any integer replay needs certified bounds before fixed-width arithmetic.
If SymPy is sufficient,use exact arbitrary precision without introducing
that optimization. Local finite extraction retains chi4 and all prime-log
lengths separately; do not choose a favorable baseline or force a pole sum.
Only after independent validation compare the new map with the existing
four selected source carriers and assess the next required identity.

Sequential native kernel/vertex/color increments300s after imports each;
verifier/review180s.8GiB sampled private,350MiB available-pagefile launch
floor,64MiB complete packet (larger45x external-ghost carrier justifies
this prospective storage ceiling). Freeze actual input hashes and source
copies before each computation. Preserve failed/unfinished versions,
captures and manifests. No silent resource expansion,truncation,physical
input/tolerance change or incomplete-to-PASS relabeling.

Authority ceiling: the complete admitted proper source kernel/relative
finite conversion and tested source implications only. No full invariant
counterterm classification/HB1C5,complete renormalized prescription,QAP,
chiral measure/phase,physical source reality or E5/A5/physicalGUT.
General BBx triangle coefficients and broader physical obligations remain.
Shared action,data,charts,helpers,software and AI author limit independence;
agreement cannot validate a shared physical premise. Director education
remains voluntary/nonblocking. Continue the most informative justified
next step after each bounded result,without fitting an unknown correction.
