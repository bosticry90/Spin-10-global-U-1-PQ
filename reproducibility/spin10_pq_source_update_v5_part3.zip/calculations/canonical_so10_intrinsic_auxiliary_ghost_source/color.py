from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'color_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('color_'+('replay'if role=='primary'else'primary')):raise PermissionError('IAG4_PEER_DENIED')
  if p.parent.name in ['canonical_so10_intrinsic_finite_conversion_module','canonical_so10_intrinsic_auxiliary_source']and p.name.startswith('color_'):raise PermissionError('IAG4_OLD_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard)
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.expand(s.sympify(z,locals=loc))
cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v)for i,j,v in z['entries']});tab=lambda z:{tuple(q[:-1]):parse(q[-1])for q in z};clean=lambda z:{k:s.expand(v)for k,v in z.items()if s.expand(v)!=0};enc=lambda z:[[*k,str(v)]for k,v in sorted(clean(z).items())]
d=load(O/('color_'+role+'_inputs.json.gz'));v=load(O/('vertex_'+role+'_tables.json.gz'));e=d['endings'];beta=tab(d['beta']);S0=tab(d['S0']);G0=dec(e['G0']);N0=dec(e['N0']);J0=list(map(dec,e['J0']));Z0=tab(v['Z0_JC_aC']);Zu=list(map(tab,v['Zu_JC_aC']));nn=328
assert not N0[:45,:].todok();assert not cl(N0.T*G0[:,45:]).todok()
if role=='primary':R=list(map(dec,d['R']))
else:
 frame=d['frame'];xs=[f'x_{sec}_{i}'for sec,n in [('Phi',54),('Sigma',252),('phi',20),('S',2)]for i in range(n)];aux=[('b'if i<12 else'L')+str(i)for i in range(45)];phys=[f'B{i}_{mu}'for i in range(45)for mu in range(4)]+xs+aux+['C'+str(i)for i in range(45)]+[('bar'if i<12 else'ub')+str(i)for i in range(45)];ri={n:i for i,n in enumerate(frame['field_order'])};pi={n:i for i,n in enumerate(phys)};TI=dec(frame['physical_to_raw_inverse']);TF=dec(frame['physical_to_raw_kernel'])
 def block(ns):return TI.extract([ri[n]for n in ns],[pi[n]for n in ns]),TF.extract([pi[n]for n in ns],[ri[n]for n in ns])
 TC,FC=block(['C'+str(i)for i in range(45)]);Tx,Fx=block(xs);xid={n:i for i,n in enumerate(xs)};raw=[s.SparseMatrix(nn,nn,{})for h in range(45)]
 for outname,rows in d['source_Qx'].items():
  for row in rows:
   w=row['word'];assert len(w)==2 and all('__'not in n for n in w);c=int(next(n[1:]for n in w if n.startswith('C')));j=xid[next(n for n in w if n.startswith('x_'))];raw[c][xid[outname],j]+=parse(row['coefficient'])
 R=[cl(Fx*sum((TC[k,c]*raw[k]for k in range(45)if TC[k,c]),s.zeros(nn))*Tx)for c in range(45)]
assert all(not cl(M+M.T).todok()for M in R)
Rhash=sha256((json.dumps([{'shape':list(M.shape),'entries':[[int(i),int(j),str(z)]for(i,j),z in sorted(M.todok().items())]}for M in R],sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest()
print('STAGE_IAG4_R',role,Rhash,flush=True)
B=s.SparseMatrix(2025,45,{(r*45+a,c):z for(r,a,c),z in beta.items()})
def proj(mats):
 M=s.SparseMatrix(45,45*mats[0].cols,{(c,h*mats[0].cols+j):z for h,M in enumerate(mats)for(c,j),z in M.todok().items()})
 if role=='replay':return cl(B*M)
 by=defaultdict(list);out=defaultdict(lambda:0)
 for(c,j),z in M.todok().items():by[c].append((j,z))
 for(r,c),z in B.todok().items():
  for j,w in by[c]:out[r,j]+=z*w
 return cl(s.SparseMatrix(2025,M.cols,dict(out)))
def unpack(P,width):return {(r//45,r%45,hj//width,hj%width):z for(r,hj),z in P.todok().items()}
Rby=[defaultdict(list)for b in range(45)]
for b,M in enumerate(R):
 for(j,i),z in M.todok().items():Rby[b][j].append((i,z))
def T(P,W):
 pp=unpack(P,nn);wb=defaultdict(list)
 for(b,a),z in W.todok().items():wb[a].append((b,z))
 if role=='primary':
  out=defaultdict(lambda:0)
  for(r,a,h,j),z in pp.items():
   for b,w in wb[a]:
    for i,q in Rby[b][j]:out[r,h,i]+=z*w*q
  return clean(out)
 left=s.SparseMatrix(2025,45*nn,{(r*45+h,a*nn+j):z for(r,a,h,j),z in pp.items()});rr=defaultdict(lambda:0)
 for a,rows in wb.items():
  for b,w in rows:
   for(j,i),z in R[b].todok().items():rr[a*nn+j,i]+=w*z
 out=cl(left*s.SparseMatrix(45*nn,nn,dict(rr)));return {(rh//45,rh%45,i):z for(rh,i),z in out.todok().items()}
AA=[cl(M*G0)[:,:45]for M in J0];PA=proj(AA);pA=unpack(PA,45)
def Q(K):
 kb=defaultdict(list)
 for(j,a),z in K.todok().items():kb[a].append((j,z))
 if role=='primary':
  out=defaultdict(lambda:0)
  for(r,a,h,b),z in pA.items():
   for j,w in kb[a]:
    for i,q in Rby[b][j]:out[r,h,i]+=z*w*q
  return clean(out)
 right={}
 for b in range(45):
  V=cl(K.T*R[b])
  for(a,i),z in V.todok().items():right[b*45+a,i]=z
 left=s.SparseMatrix(2025,2025,{(r*45+h,b*45+a):z for(r,a,h,b),z in pA.items()});out=cl(left*s.SparseMatrix(2025,nn,right));return {(rh//45,rh%45,i):z for(rh,i),z in out.todok().items()}
def DD(D,W):
 if role=='primary':
  ds=defaultdict(list);ww=defaultdict(list);out=defaultdict(lambda:0)
  for(b,c,i),z in D.items():ds[b,c].append((i,z))
  for(c,a),z in W.todok().items():ww[a].append((c,z))
  for(r,a,h,b),z in pA.items():
   for c,w in ww[a]:
    for i,t in ds[b,c]:out[r,h,i]+=z*w*t
  return clean(out)
 right={}
 for i in range(nn):
  V=cl(s.SparseMatrix(45,45,{(b,c):z for(b,c,j),z in D.items()if j==i})*W)
  for(b,a),z in V.todok().items():right[b*45+a,i]=z
 left=s.SparseMatrix(2025,2025,{(r*45+h,b*45+a):z for(r,a,h,b),z in pA.items()});out=cl(left*s.SparseMatrix(2025,nn,right));return {(rh//45,rh%45,i):z for(rh,i),z in out.todok().items()}
def direct(Z,S):
 if role=='primary':
  ss=defaultdict(list);out=defaultdict(lambda:0)
  for(a,c,i),z in S.items():ss[a,c].append((i,z))
  for(r,h,a,c),z in Z.items():
   for i,w in ss[c,a]:out[r,h,i]+=z*w
  return clean(out)
 L=s.SparseMatrix(2025,2025,{(r*45+h,c*45+a):z for(r,h,a,c),z in Z.items()});T=s.SparseMatrix(2025,nn,{(a*45+c,i):z for(a,c,i),z in S.items()});out=cl(L*T);return {(rh//45,rh%45,i):z for(rh,i),z in out.todok().items()}
def plus(*terms):
 out=defaultdict(lambda:0)
 for z,f in terms:
  for k,v in z.items():out[k]+=f*v
 return clean(out)
oldS=[s.SparseMatrix(45,nn,{(a,i):z for(a,c,i),z in S0.items()if c==h})for h in range(45)];PS=proj(oldS);PN=proj([cl(-M*G0*N0)for M in J0]);assert PS==dec(v['beta_S0'])and PN==dec(v['beta_old_inverse_ending'])
def ghost(S,J):
 # beta is contracted with the antighost row of S_i,not its external-C port.
 PP=cl(B*s.SparseMatrix(45,45*nn,{(c,b*nn+i):z for(c,b,i),z in S.items()}));assert not PP.todok(),'unanticipated nonzero ghost-background port requires full continuation'
 return {}
results=[];W0=G0[:45,45:]
for probe,rows in enumerate(e['mixed']):
 Gr=dec(e['probe_quadratics'][probe]['Gr']);Nr=dec(e['probe_quadratics'][probe]['Nr']);Ju=[dec(z['Ju'])for z in rows];pieces=[[dec(z['pieces'][j])for z in rows]for j in range(4)];PP=[proj(ms)for ms in pieces]
 assert all(PP[j]==dec(v['projected_endings'][probe]['projected_P'][j])for j in range(4));assert not cl(sum(PP,s.zeros(*PP[0].shape))).todok()
 Su={(a,h,i):z for h,M in enumerate(pieces[0])for(a,i),z in M.todok().items()};W1=Gr[:45,45:];lower=cl((-Nr[:45,:].T).row_join(Nr[45:,:].T));K2=cl(-lower*G0[:,45:]);K3=cl(-N0.T*Gr[:,45:]);D=tab(d['D'][probe]['entries'])
 groups={'m2_Zu_S0':direct(Zu[probe],S0),'m2_Z0_Su':direct(Z0,Su),'m3_Su':T(PP[0],W0),'m3_D':DD(D,W0),'m4_P1P3':T(cl(PP[1]+PP[3]),W0),'m4_S0':T(PS,W1),'m4_K2':Q(K2),'m5_P2':T(PP[2],W0),'m5_Nh':T(PN,W1),'m5_K3':Q(K3),'m3_ghost_Su':ghost(Su,[cl(M*G0)[:,45:]for M in J0]),'m3_ghost_Ju':ghost(S0,[cl(M*G0)[:,45:]for M in Ju]),'m4_ghost_Gr':ghost(S0,[cl(M*Gr)[:,45:]for M in J0])}
 F={2:plus((groups['m2_Zu_S0'],1),(groups['m2_Z0_Su'],1)),3:plus((groups['m3_Su'],s.I),(groups['m3_D'],1)),4:plus((groups['m4_P1P3'],s.I),(groups['m4_S0'],s.I),(groups['m4_K2'],-s.I)),5:plus((groups['m5_P2'],s.I),(groups['m5_Nh'],s.I),(groups['m5_K3'],-s.I))};pole=plus(*[(z,1)for z in F.values()]);counts={str(m):len(z)for m,z in F.items()}
 controls={'omit_direct_CC_source_changes_F2':len(F[2]),'omit_D_changes_F3':len(groups['m3_D']),'reverse_JC_order_changes_pole':len(pole),'collapse_m4_to_m3_loses_log2':len(F[4]),'collapse_m5_to_m3_loses_log5_over2':len(F[5])}
 results.append({'probe':probe,'groups_unphased':{k:enc(z)for k,z in groups.items()},'F_m':{str(m):enc(z)for m,z in F.items()},'DIM_minus_heat_basis':{'chi4':enc(pole),'log3_over2':enc(F[3]),'log2':enc(F[4]),'log5_over2':enc(F[5]),'fixed':[]},'controls':controls});print('STAGE_IAG4_COLOR',role,probe,counts,'pole',len(pole),'groups',{k:len(z)for k,z in groups.items()},flush=True)
out={'schema':'IAG4_COMPLETE_INTRINSIC_U_JLAMBDA_C_X_CONVERSION','role':role,'R_sha256':Rhash,'results':results,'full_positions_per_tensor':45*45*328,'common_normalization':'hbar/(16pi^2); u JLambda C x; no extra half','K1_zero_checked':True,'zero_ghost_background_ports_checked':True,'fixed_D_jet_zero_by_longitudinal_support':True,'chi4_unselected_not_b0_kappa':True,'QAP_E5_A5_authority':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('color_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'R_sha256':Rhash,'F2_F3_F4_F5_pole_positions':[[len(q['F_m'][str(m)])for m in range(2,6)]+[len(q['DIM_minus_heat_basis']['chi4'])]for q in results]},sort_keys=True),flush=True);timer.cancel()
