from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'assembly_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.expand(s.sympify(z,locals=loc))
cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v)for i,j,v in z['entries']});tab=lambda z:{tuple(q[:-1]):parse(q[-1])for q in z};clean=lambda z:{k:s.expand(v)for k,v in z.items()if s.expand(v)!=0};enc=lambda z:[[*k,str(v)]for k,v in sorted(clean(z).items())]
ip=read(O/'assembly_inputs.json');new=load(Path(ip['new']))['results'];old=load(Path(ip['old']))['results'];ifc=load(Path(ip['IFC']))['outputs'];vd=load(Path(ip['vertex_inputs']));d=load(Path(ip['IFC_inputs']));rd=load(Path(ip['R']));beta=tab(vd['beta']);R=list(map(dec,rd['R']));xs=d['xs'];aux=[('b'if i<12 else'L')+str(i)for i in range(45)];cs=['C'+str(i)for i in range(45)];ants=[('bar'if i<12 else'ub')+str(i)for i in range(45)];phys=[f'B{i}_{mu}'for i in range(45)for mu in range(4)]+xs+aux+cs+ants;frame=d['frame'];ri={n:i for i,n in enumerate(frame['field_order'])};pi={n:i for i,n in enumerate(phys)};TI=dec(frame['physical_to_raw_inverse']);TF=dec(frame['physical_to_raw_kernel']);TC=TI.extract([ri[n]for n in cs],[pi[n]for n in cs]);FC=TF.extract([pi[n]for n in cs],[ri[n]for n in cs]);assert not cl(FC*TC-s.eye(45)).todok()
Ar=[s.SparseMatrix(45,45,{})for h in range(45)]
for name,rows in d['source_QC'].items():
 for row in rows:
  a,b=[int(n[1:])for n in row['word']];v=parse(row['coefficient']);Ar[a][int(name[1:]),b]+=v;Ar[b][int(name[1:]),a]-=v
ops=[]
for h in range(12):
 BH=s.SparseMatrix(45,45,{})
 for(r,a,c),z in beta.items():
  if FC[c,h]:BH[r,a]+=FC[c,h]*z
 GH=cl(FC*Ar[h]*TC);RH=cl(sum((FC[c,h]*R[c]for c in range(45)if FC[c,h]),s.zeros(328)));op=defaultdict(lambda:0)
 for(r,a),z in BH.todok().items():
  for c in range(45):op[r*45+c,a*45+c]+=z
 for(k,c),z in GH.todok().items():
  for r in range(45):op[r*45+c,r*45+k]-=z
 ops.append((cl(s.SparseMatrix(2025,2025,dict(op))),RH))
def plus(*terms):
 out=defaultdict(lambda:0)
 for z,f in terms:
  for k,v in z.items():out[k]+=f*v
 return clean(out)
outputs=[];cov=[]
for probe in range(2):
 F={m:tab(new[probe]['F_m'][str(m)])for m in range(2,6)};NP=tab(new[probe]['DIM_minus_heat_basis']['chi4']);assert NP==plus(*[(F[m],1)for m in range(2,6)])
 Ns={'chi4':NP,'log2':plus((F[3],-1),(F[4],1),(F[5],-1)),'log3':F[3],'log5':F[5]}
 oldP=dec(old[probe]['DIM_minus_heat_basis']['chi4']);oldB=dec(old[probe]['F3_vector']);L={'chi4':{(r,i):v for(r,i),v in oldP.todok().items()},'log2':{(r,i):-v for(r,i),v in oldB.todok().items()},'log3':{(r,i):v for(r,i),v in oldB.todok().items()},'log5':{}}
 basis={}
 for name in ['chi4','log2','log3','log5']:
  prime={'log2':'2','log3':'3'}.get(name);z=ifc[probe]['prime_logs'][prime]if prime else None;V=dec(z['V'])if z else s.SparseMatrix(328,1,{});U=dec(z['U'])if z else s.SparseMatrix(328,45,{})
  basis[name]={'rho_Jx':[[int(i),str(v)]for(i,j),v in sorted(V.todok().items())],'u_Jx_C':[[int(i),int(c),str(v)]for(i,c),v in sorted(U.todok().items())],'rho_JLambda_x':enc(L[name]),'u_Ja_x':enc({k:-2*s.I*v for k,v in L[name].items()}),'u_JLambda_C_x':enc(Ns[name])}
 cc=[]
 for m in range(2,6):
  M=s.SparseMatrix(2025,328,{(r*45+h,i):z for(r,h,i),z in F[m].items()});res=[len(cl(K*M-M*RH).todok())for K,RH in ops];cc.append(res);assert not any(res),('constant_H_covariance_failed',probe,m,res)
 cov.append(cc);outputs.append({'probe':probe,'formal_basis':basis,'source_patterns':5,'ordinary_general_BBx_not_included':True});print('STAGE_IAG6',probe,'covariance_remainders',cc,'carrier_counts',{name:{k:len(v)for k,v in z.items()}for name,z in basis.items()},flush=True)
out={'schema':'IAG6_COMPLETE_FIVE_MEASURED_SOURCE_CARRIERS','outputs':outputs,'constant_H_new_tensor_remainders_by_probe_heat_generator':cov,'chi4_symbolic_not_b0_kappa':True,'complete_q_variation_or_quantum_root_not_inferred':True,'physical_or_scientific_authority_changed':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'assembly_tables.json.gz').open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'source_patterns':5,'constant_H_covariance_all_12_directions_all_heat_lengths_and_zeros':True,'full_QAP_E5_A5_authority':False},sort_keys=True),flush=True);timer.cancel()
