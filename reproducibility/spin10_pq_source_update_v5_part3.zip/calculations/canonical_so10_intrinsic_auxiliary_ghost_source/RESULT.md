# The fifth intrinsic source pattern is measured and the source functional assembled

October 25, 2026. Base `d36d47f5af4c003f6415380a9e4d456fcf593680`.
Bounded progress under live AGENTS.md; director scientific acceptance is
NOT_PERFORMED. State 113, authority 34/39, E5/A5 OPEN and historical
custody exit 2/seven NOTPASS remain unchanged.

The previously unmeasured `u JLambda C x` contribution is now calculated
over all 45 auxiliary sources, 45 external ghosts and 328 real scalar
coordinates, for both probes and symbolic `g10,xi,eta_H`. Two exact
contraction routes agree at each heat length, including every implicit
zero. Together with the earlier IFC/IAS measurements, this supplies all
five Lorentz-scalar source patterns in the declared intrinsic domain.

This is a measured local RELATIVE conversion, not a completed symmetry
restoration, renormalized prescription or physical normalization. It is
not installed in the action, and no baseline has been chosen.

## Domain and complete result

Retain the original unshifted SMA/CSW/EDS reference, A0, constant first
probe, one intrinsic GF/reference coefficient of dimension one, and zero
external jets. The comparison is DIM-minus-strict-heat on the inherited
common nonexceptional Euclidean local domain. It is not a physical
scaleless zero-momentum integral or a new massive/vacuum prescription.
Physical cubic/mass insertions, higher grades and nonlinear multiple
products are separate obligations.

In common `hbar/(16 pi^2)` units, write the measured coefficient as

    C_(u JLambda C x) = chi4 (F2+F3+F4+F5)
                       +log(3/2) F3+log2 F4+log(5/2) F5.

Each `Fm` is the coefficient of `exp(-2 m t Q)/Q^2`, with the ordered
source convention `u JLambda_r C_h x_i`. The fixed dimensional-jet term
is zero by longitudinal support, not an interpolated numerical guess.

| Probe | F2 | F3 | F4 | F5 | Sum/baseline direction |
| --- | ---: | ---: | ---: | ---: | ---: |
| 0 | 0 | 0 | 0 | 0 | 0 |
| 1 | 9,936 | 2,496 | 12,432 | 12,432 | 7,424 |

Counts are nonzero coefficient positions, not independent particles,
experiments, counterterms or a percentage of E5. Each tensor has 664,200
positions, including its zero complement. Coupling powers remain separate.

For example, at `(r,h,i)=(13,0,137)`, let
`A=i sqrt(6) eta_H g10^4 xi/16`. The measured heat coefficients are
`(F2,F3,F4,F5)=(0,-A,+A,-A)`, so the conversion there is

    -A [chi4+log(15/8)].

This is a formal local source coefficient. Its imaginary coordinate
value is not an assertion about physical source reality. Keep `chi4`
symbolic and distinct from `b0`, `kappa` and infrared contact freedoms.
The nonzero summed coefficient is not by itself an anomaly verdict or
evidence that a preferred baseline should be selected.

## The complete ordered calculation

IAG1 eliminates the ordinary bosons and then evaluates the ghost
determinant. For the actual source order its compact operator is

    Gamma_(J C) = -Tr[Gghost (Z+M Gboson W)].

An independent literal paired-momentum graded Hessian and Born expansion
give the same sign, normalization and heat coefficients. Two generic
noncommuting colors test both momentum orientations. The exact
squarefree grades `(n,u,x,J,C)` bound the Born length by five; this is
not an uncontrolled truncation of an infinite series.

IAG2 roots every admitted word at its unique source and checks the
complete earlier typed inventory: 448 words/94 rooted orientations for
probe 0 and 726/170 for probe 1. Linear-source bosonic-background paths,
linear-source ghost-background paths and direct cubic-source ghost
bubbles exhaust it. All cyclic rotations and port orientations remain
in the evidence. The complete density/Green types have 45 letters.

The original `JLambda CCa` vertex must remain: one ghost is external and
two quantum ports remain. Its absence from the earlier no-external-ghost
calculation does not permit its omission here. IAG3 obtains the original
source tensor with 6,688 entries, and probe-source tensors with 0/6,688.
Selecting the external ghost before coordinate transport agrees with
transporting the cubic exterior polynomial before differentiation. The
two possible external ghosts, their signs, the inverse auxiliary-source
chart and the distinct ghost/antighost charts are retained. Probe source
derivatives precede restriction; left/right source derivatives agree.

The actual source phases are inherited: `JLambda_M=-i JLambda_E`,
`Lambda_M=-i Lambda_E`, `B0_M=i B0_E`, `L_E=-L_M`. The original CL source
has net phase +1; the original CCa source carries its derived +i. No
extra half, coupling or source phase is inferred from a desired result.

The classical projected port checks are also informative. `beta*S0` is
zero, while `beta*(-J0 G0 N0)` has 48,512 entries. For the four ordered
mixed scalar endings, the projected counts are `[0,0,0,0]` and
`[0,0,48512,48512]`. Their sum vanishes classically, but their different
heat factors forbid discarding them as a single regulated zero.

IAG4 contracts these actual vertices, ordered endings, scalar generators,
inverse-reference perturbations and the positive-reference BBx source.
Primary uses explicit sparse paths; replay regroups sparse matrix
products and freshly reconstructs all scalar generators from the raw Qx
source action. Both reconstruct the same complete R tensor, SHA256
`d6af5e8d4e0e3304504310767b32b98a82e3965d18f93daa6a8802a245bea1d8`.
They agree on every unphased group, heat tensor, finite basis and zero.
The ghost-background products are checked zero in their actual ports.

The source's Lambda endpoint forces the adjoining vector to be
longitudinal. Scalar currents and reference insertions keep that same
momentum direction, including the open BBx path. No closed Lorentz
spectator remains. IAG5 separately checks the block formula, including
both scalar-current endpoints and minus-q lower-reference transpose,
against the literal Gaussian and the full squarefree inverse.

Sensitive broken-probe controls: omitting the direct cubic source changes
9,936 F2 positions; omitting BBx D changes 2,496 F3 positions; collapsing
heat lengths loses 12,432 positions in each tested finite-log direction.
The generic initial F2 and U_LL omission controls were insensitive and
remain labeled as such. An additional direct ghost-only test has F2=2i
and detects the source sign/omission; omitting U_BB changes two generic
heat coefficients. Omitting the right scalar-current endpoint changes
two heat coefficients. Probe 0's zero controls are not claimed sensitive.

## Five measured source patterns, with a new covariance check

IAG6 assembles the measured functional in the independent formal carriers
`chi4,log2,log3,log5`:

    rho Jx V + u Jx C U
      + rho JLambda L x -2i u Ja L x +u JLambda C N x.

`V,U` are the qualified IFC measurements, `L` is the qualified IAS
measurement and `N` is the new result. These are the five source patterns
enumerated in the existing dimension/ghost/Lorentz domain, not a complete
invariant counterterm classification. The earlier mass contribution
remains qualified in its own scope; this packet does not recalculate it.

All five carriers are zero for probe 0 in this domain. For probe 1 the
new N coefficient has 7,424 chi4, 12,432 log2, 2,496 log3 and 12,432 log5
positions. The old L has 320 chi4 and 304 positions in each log2/log3
carrier. Their measured `-2i` Ja companion is retained; no coefficient
has been fitted to the ordinary BBx result or a desired cancellation.

The actual residual-H action is reconstructed from raw QC, source beta
and scalar R with their proper charts. For all 12 constant unbroken
directions, every new heat tensor satisfies

    BH N_h -sum_k N_k GH[k,h]-N_h RH = 0.

This tests all coordinates and zeros before formal-log addition. It is
constant-H covariance, not a theorem for varying backgrounds, full
source reality or complete Slavnov closure. The combined functional's
actual source variation and regulator/root interpretation are the next
scientific questions, not conclusions inferred from this assembly.

## Verification, failure preservation and capability evidence

Native/verification runtimes after imports in seconds:

| Increment | Primary | Replay | Verifier/audit |
| --- | ---: | ---: | ---: |
| Graded Gaussian | 0.2562 | 0.2955 | 0.0263 |
| Coverage/controls | — | — | 0.3316 |
| Source vertices/ports | 43.3344 | 30.9693 | 0.5479 |
| Complete color contraction | 60.8812 | 62.3967 | 0.3187 |
| Block-formula review | — | — | 0.3298 |
| Five-carrier assembly/covariance | — | — | 66.2386 |

Every completed worker met its prospective 300/180-second limit, 8GiB
sampled-private cap and 350MiB available-pagefile launch floor. Largest
sampled native private allocation was 239,702,016 bytes; sampling does
not measure a continuous peak. The complete packet is below its 64MiB
ceiling. Full captures, sources/copies and immutable input preparations
are retained, including the original insensitive tests.

The first assembly controller FAILED before preparation or a native
launch because it used the nonexistent `companion_receipt_v2.json`.
The actual receipt is `companion_v2_receipt.json`. Original controller,
source copy, traceback and failure record remain unchanged. V2 fixes
only that path and binds the preserved failure. The failed preparation
has no scientific PASS receipt. No input, tolerance, scientific condition
or resource allowance was weakened.

This sequence demonstrates useful compression from complete graph words
to ordered matrix families and exact sparse calculations, with sensitive
sign/endpoint/heat controls. It also records a routine dependency-filename
failure. Both belong in the AI-capability assessment. The methods share
the action, charts, reference/domain premises, qualified data/helpers,
Python/SymPy and AI author. Agreement cannot validate those shared
physical assumptions. No outside scientist, proof assistant or experiment
has validated this result.

`python -B tools/research_check.py e4` completed with native exit 0 and
step exits `[0,0,0,0,0,2]`. This authenticates existing bounded evidence
and runs authority/structure/read-only/custody checks. It is not fresh
replay of all historical science. Custody remains exit 2/seven unresolved
references, never global PASS. Complete captures and byte/index/commit
seals are external under `intrinsic-auxiliary-ghost-source-v1-2026-10-25`.

Receipt SHA256:

- Kernel: `ed64c7e26753281387f653a98948b96c7b260c729bf541596861e8a480d45bea`.
- Coverage: `0c830e863e42b0b0372c9817611bfefbfc22ae5538572f825011140f05ceaf1a`.
- Vertices: `ca07f5fdc0bb3bddd13236ae5b9cd7a5f057b0d393ee929f00c407f7d97dd0bf`.
- Color: `66b90713fbbf93e9dd1feda63b36c08b276eb8e1cc900e47e30e313adf389aae`.
- Formula: `3b76d2d76ebbc55df08de08535b87274896063f163d6b1d54e7a47fd590826fe`.
- Assembly: `b751d028e547cbbaac6c663bc3da9049ccbe9936329abafb78b899bdc1d805ea`.

Color primary packed/raw SHA256:
`d38bf31f018e5d3a689710382069ff7a5315ba4a0b33fe260c4d40c991d1c5f3` /
`324b2e6fea268a48e88d74270489436c7de6f7808bc684df3598f8393f057419`.
Assembly packed/raw:
`ad4209f9c8360c95d5b4e018d88f40cfa01fb0ce8a13451184e0704216303596` /
`e462acd38b4ec935bd229b1bcebf788016f7152d859ce743d88f37d4aa72fdf3`.

## Reference use, limits and next action

The two supplied October25 assessments remain reference interpretations,
not scientific ledgers. Their emphasis on independently measured auxiliary
companions and a common construction guided this increment. The sole
constant-scalar-translation exclusion remains valid in its tested scope.
Nothing here rescues that restricted candidate or transfers its selected
ordinary counterexample to all colors/parameters. The corrected IRR mass
sign remains current; the old FIM log(8/3) discussion stays historical.

Next derive the actual source variation of this complete five-pattern
relative functional, retaining auxiliary Euler terms and differentiating
sources before restriction. Determine its explicit regulator/insertion
counterpart through a justified computation or applicable qualified
identity. Do not impose Q-closure on a conversion with an inhomogeneous
regulator response, or fit an auxiliary coefficient to cancel an old
ordinary witness. The full general BBx triangle is still unmeasured and
must be completed before asserting a full ordinary/source kinetic result.

Absolute contact normalization, nonlinear products, full chiral QAP and
measure/phase, physical source involution, varying probes/backgrounds and
massive Lorentzian/causal/constant-vacuum limits remain open. The failed
physical benchmark, scalar quantum-control warning and gauge matching
remain independent. Flavor stays paused, HB1/C5 blocked, E5/A5 OPEN and
authority 34/39. No foundation/scheme/benchmark adoption, protected-stage
activation/promotion, branch/worktree, push/publication/outreach or state
edit occurred. The investigation remains ACTIVE/INCOMPLETE.
