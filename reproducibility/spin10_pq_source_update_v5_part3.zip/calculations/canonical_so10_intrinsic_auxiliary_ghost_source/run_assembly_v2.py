from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-auxiliary-ghost-source-v1-2026-10-25');P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(P));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'formula_review_preparation.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 for n in ['formula_review_preparation.json','formula_review_receipt.json','formula_review_capture.json']:p=O/n;b[str(p)]=H(p)
 I=O.parent/'canonical_so10_intrinsic_finite_conversion_module';A=O.parent/'canonical_so10_intrinsic_auxiliary_source'
 ip={'new':str(O/'color_primary_tables.json.gz'),'old':str(A/'color_primary_tables.json.gz'),'IFC':str(I/'primary_tables.json.gz'),'IFC_inputs':str(I/'primary_inputs.json.gz'),'vertex_inputs':str(O/'vertex_primary_inputs.json.gz'),'R':str(O/'color_primary_inputs.json.gz')}
 for name in ['companion_v2_receipt.json','color_validation_receipt.json']:p=A/name;b[str(p)]=H(p)
 for name in ['validation_receipt.json']:p=I/name;b[str(p)]=H(p)
 for p in ip.values():b[p]=H(Path(p))
 dump(O/'assembly_inputs.json',ip);b[str(O/'assembly_inputs.json')]=H(O/'assembly_inputs.json')
 for n in ['ASSEMBLY_RECORD.md','ASSEMBLY_CORRECTION_V2.md','run_assembly.py','assembly_controller_failure.json','assemble.py','run_assembly_v2.py']:
  p=O/n;cp=O/(n+'.source.txt')
  if not cp.exists():
   with cp.open('xb')as f:f.write(p.read_bytes())
  assert cp.read_bytes()==p.read_bytes()
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(cp)]=H(cp)
 dump(O/'assembly_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
 z=capture([sys.executable,'-B',str(O/'assemble.py')]);dump(O/'assembly_capture.json',z);dump(C/'assembly_full_capture.json',z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
 rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<180;dump(O/'assembly_receipt.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<64*1024**2;print('COMPLETED_IAG6',json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'assembly_controller_failure_v2.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
