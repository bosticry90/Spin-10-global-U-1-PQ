# IAG4 actual full source-ghost-scalar contraction

Prospective continuation of IAG1-3, October25,2026. Bind the completed
graded Gaussian, complete448/726-word coverage and actual source/port
receipts before native computation. No old quantum conversion/desired
Ward image is an operand. All45 auxiliary sources,45 external ghosts,
328 scalars,both probes,symbolic parameters,original conventions.

Let W0=G0[B,Lambda],W1=Gr[B,Lambda],A_h=(J0_h G0)[:,B].
The actual N0 has only Lambda rows. Check K1=-N0.T G0[:,Lambda]=0.
With the minus-q derivative transpose on the B rows, put
K2=-[-Nr_B.T,Nr_L.T] G0[:,Lambda],K3=-N0.T Gr[:,Lambda].
Use IAG3 P0=Su,P1=-JuG0N0,P2=-J0GrN0,P3=-J0G0Nr,
Nh=-J0G0N0. Define ordered tensors

 T(P,W)[r,h,i]=sum beta[r,a,c] P_h[c,j] W[b,a] R_b[j,i],
 Q(A,K)[r,h,i]=sum beta[r,a,c] A_h[c,b] K[j,a] R_b[j,i],
 D(A,D,W)[r,h,i]=sum beta[r,a,c] A_h[c,b] D[b,d,i] W[d,a].

The compact trace gives
 F2=Tr(Zu S0_i+Z0 Su_i),
 F3=i T(P0,W0)+D(A,D,W0)+ghost-background-three,
 F4=i T(P1+P3,W0)+i T(S0_h,W1)-i Q(A,K2)
       +ghost-background-four,
 F5=i T(P2,W0)+i T(Nh,W1)-i Q(A,K3).
Ghost-background-three is beta times
Su_i J0_hG0+S0_i Ju_hG0; four is beta S0_i J0_hGr.
Keep the original source CCa direct bubble. The measured IAG3 zero
ports may prove some complete contractions zero; retain their checked
zero complement and do not transfer them to different ports.

Primary explicit ordered sparse paths; replay regrouped exact sparse
matrix contractions and R freshly transported from original raw Qx
source action,as previously qualified. Both reconstruct all contributions
and compare every664200 coefficient positions per heat tensor/probe,
including zeros. No fixed-width arithmetic. Shared action/charts/D and
software/AI author remain explicit. This is not external validation.

Retain chi4 sum Fm,log(3/2)F3,log2 F4,log(5/2)F5 and zero D jet.
No setting chi4,b0,kappa; no coupling-order merging or fitted remainder.
Controls: omit direct CCa,omit D,reverse source order,collapse heat
lengths. An insensitive zero control is reported,not called sensitive.

Freeze native/verification sources/copies and actual input hashes before
execution. Each native300s after imports,verifier180s,8GiB sampled private,
350MiB launch pagefile floor,64MiB whole packet. Exact failure/incomplete
captures preserved. Authority ceiling only complete admitted local proper
relative kernel; no complete joint products,QAP,E5/A5,physical source
reality,scheme/benchmark/foundation adoption or protected activation.
