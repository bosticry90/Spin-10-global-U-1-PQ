# IAG5 ordered block formula review

Prospective180-second exact audit of the IAG4 block decomposition against
IAG1's literal paired Gaussian and full squarefree Born inverse. Reuse only
bound generic definitions through AST selection,not executing the kernel
entrypoint or using the model's measured coefficients as operands.
Two noncommuting colors,both q orientations,all four heat lengths. Retain
both HX endpoints,minus-q Nr lower rows,source W and both direct ghost
terms. Check K1=0 only through the actual free-block structure. The omitted
right-HX-endpoint control must be tested,with observed sensitivity reported.
Shared generic vertices and exact library/AI authorship are disclosed.
This validates the block reduction,not independent physical premises or
the complete quantum theory. Same8GiB/350MiB/64MiB resource boundaries.
