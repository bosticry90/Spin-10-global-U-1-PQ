from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from fractions import Fraction as F
import ast,gzip,json,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'review_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
src=(O/'kernel.py').read_text();tree=ast.parse(src);fn=['gc','add','scale','mul','mm','ma','ms','const','tr','rat','fracadd','encode','tensors','schur','hessian','born'];helpers=['ca','cm','cs','cz'];nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in fn or isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id in helpers for t in n.targets)];assert len(nodes)==len(fn)+len(helpers)
ns={'s':s,'F':F,'defaultdict':defaultdict,'nb':5,'ng':2,'per':9,'dim':18,'extJ':18,'extC':19,'par':([0]*5+[1]*4)*2,'qfield':lambda mode,i:mode*9+i}
exec(compile('\n\n'.join(ast.get_source_segment(src,n)for n in nodes),'<IAG2_bound_kernel_definitions_only>','exec'),ns)
orig=ns['tensors'];baseline=ns['schur']()
def direct(q,omitD=False,omitULL=False):
 v=list(orig(q,omitD,omitULL));v[12]=s.zeros(5,2);v[13]=s.I*s.diag(1,0);v[14]=s.zeros(2);return tuple(v)
ns['tensors']=direct;aa=ns['born']();bb=ns['schur']();assert aa==bb;assert aa[2]==(F(0),F(2));assert all(v==(0,0)for m,v in aa.items()if m!=2)
omitted=ns['schur'](omitZ=True);assert aa[2]!=omitted[2]
def wrongU(q,omitD=False,omitULL=False):
 v=list(orig(q,omitD,omitULL));v[1][:2,:2]=s.zeros(2);return tuple(v)
ns['tensors']=wrongU;wrong=ns['schur']();changed=sum(baseline[m]!=wrong[m]for m in baseline)
ip=read(O/'review_inputs.json');actual=load(Path(ip['support']));L=actual['letters'];covered=[];allroots=[]
for target in actual['targets']:
 roots=defaultdict(list);words=target['ordered_words']
 for wi,w in enumerate(words):
  ww=w['letters'];st=w['Green_path'];js=[j for j,i in enumerate(ww)if L[i]['grade'][2]];assert len(js)==1;j=js[0];rw=tuple(ww[j:]+ww[:j]);rs=tuple(st[j:-1]+st[:j]+[st[j]]);roots[rw,rs].append(wi)
 summary=Counter();records=[]
 for(rw,rs),indices in sorted(roots.items()):
  assert len(indices)==len(rw)
  jj=L[rw[0]];ports=set(jj['H_ports']);others=[L[i]for i in rw[1:]]
  if ports=={'C','a'}:
   assert jj['grade'][4]==1 and len(rw)==2 and all(t in['a','C']for t in rs)
   assert others[0]['grade'][3]==1 and set(others[0]['H_ports'])=={'C','a'};label='direct_CC_source_ghost_bubble'
  else:
   assert ports=={'C','L'} and jj['origin']=='JqLambda';cx=[t for t in others if t['grade'][4]];xx=[t for t in others if t['grade'][3]];assert len(cx)==len(xx)==1
   assert 'a'in cx[0]['H_ports']and any(t in['B','L','x']for t in cx[0]['H_ports'])
   xp=set(xx[0]['H_ports'])
   if xp=={'a','C'}:label='linear_source_ghost_background'
   else:assert xp in[{'B','x'},{'B'}];label='linear_source_bosonic_background'
   for t in others:
    if t is cx[0]or t is xx[0]:continue
    assert t['grade'][3:]==[0,0]and any(t['grade'][:2])and set(t['H_ports'])in[{'L','x'},{'B','x'},{'B'},{'B','L'},{'L'}]
  summary[label]+=len(indices);records.append({'letters':list(rw),'Green_path':list(rs),'original_word_indices':indices,'class':label})
 assert sum(summary.values())==len(words)
 covered.append({'probe':target['probe'],'all_words':len(words),'J_rooted_orientations':len(roots),'class_word_counts':dict(summary)});allroots.append({'probe':target['probe'],'roots':records})
out={'schema':'IAG2_COMPLETE_TYPED_COVERAGE_AND_KERNEL_CONTROLS','coverage':covered,'rooted_words':allroots,'ghost_only_nonzero_heat_coefficients':ns['encode'](aa),'omit_ghost_source_detected':True,'reverse_external_source_order_detected':True,'omit_U_BB_changes_heat_coefficients':changed,'original_m2_and_U_LL_controls_insensitive_retained':True,'model_source_coefficients_not_measured':True};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'review_tables.json.gz').open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'coverage':covered,'direct_ghost_control':'2*I','omit_U_BB_changes_heat_coefficients':changed},sort_keys=True),flush=True);timer.cancel()
