from pathlib import Path
from hashlib import sha256
import json,gzip,time
O=Path(__file__).resolve().parent;tick=time.perf_counter();read=lambda p:json.loads(p.read_bytes())
for p,h in read(O/'vertex_validation_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
a,b=[json.loads(gzip.decompress((O/('vertex_'+r+'_tables.json.gz')).read_bytes()))for r in['primary','replay']]
for k in a:
 if k!='role':assert a[k]==b[k],k
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'differentiate_then_transport_vs_exterior_transport_then_differentiate_agree':True,'left_right_probe_source_and_ghost_derivatives_agree':True,'projected_classical_endings_all_coefficients_and_zeros_agree':True,'Z0_Zu_nonzero':[len(a['Z0_JC_aC'])]+[len(z)for z in a['Zu_JC_aC']],'beta_S0_N_nonzero':[len(a['beta_S0']['entries']),len(a['beta_old_inverse_ending']['entries'])],'projected_P_nonzero':[[len(M['entries'])for M in q['projected_P']]for q in a['projected_endings']],'model_quantum_or_QAP_E5_A5_authority':False},sort_keys=True),flush=True)
