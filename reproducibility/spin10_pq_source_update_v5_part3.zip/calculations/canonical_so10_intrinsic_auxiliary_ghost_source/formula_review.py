from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import ast,json,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'formula_review_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
src=(O/'kernel.py').read_text();tree=ast.parse(src);fn=['gc','add','scale','mul','mm','ma','ms','const','tr','rat','fracadd','encode','tensors','schur','hessian','born'];helpers=['ca','cm','cs','cz'];nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in fn or isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id in helpers for t in n.targets)];assert len(nodes)==len(fn)+len(helpers)
ns={'s':s,'F':F,'defaultdict':defaultdict,'nb':5,'ng':2,'per':9,'dim':18,'extJ':18,'extC':19,'par':([0]*5+[1]*4)*2,'qfield':lambda mode,i:mode*9+i}
exec(compile('\n\n'.join(ast.get_source_segment(src,n)for n in nodes),'<IAG5_bound_generic_definitions_only>','exec'),ns)
out={m:s.Integer(0)for m in range(2,6)};bad={m:s.Integer(0)for m in range(2,6)}
for q in [1,-1]:
 K,U,N,Nr,X,D,J,Ju,S,Su,Gs,Gsu,W,Z,Zu=ns['tensors'](q);G=K[:4,:4].inv();Gr=-G*U[:4,:4]*G;WL=W[2:4,:];W0=G[:2,2:4]*WL;W1=Gr[:2,2:4]*WL;A=(J[:,:4]*G)[:,:2];nn=N[:4,4:];nr=Nr[:4,4:];Nlo=N[4:,:4];Nrlo=Nr[4:,:4];K1=-Nlo*G[:,2:4]*WL;assert K1==s.zeros(1,2)
 K2=-Nrlo*G[:,2:4]*WL;K3=-Nlo*Gr[:,2:4]*WL;P0=Su[:,4:];Sx=S[:,4:];P1=-Ju[:,:4]*G*nn;P2=-J[:,:4]*Gr*nn;P3=-J[:,:4]*G*nr;Nh=-J[:,:4]*G*nn;XL=X[4:,:2];XR=X[:2,4:]
 R2=s.trace(Zu*Gs+Z*Gsu)
 R3=s.trace(P0*XL*W0+A*D[:2,:2]*W0+Gsu*J[:,:4]*G[:,2:4]*WL+Gs*Ju[:,:4]*G[:,2:4]*WL)
 R4=s.trace((P1+P3)*XL*W0+Sx*XL*W1+A*XR*K2+Gs*J[:,:4]*Gr[:,2:4]*WL)
 R5=s.trace(P2*XL*W0+Nh*XL*W1+A*XR*K3)
 for m,z in [(2,R2),(3,R3),(4,R4),(5,R5)]:out[m]+=s.expand(z)/2;bad[m]+=s.expand(z-(s.trace(A*XR*K2)if m==4 else s.trace(A*XR*K3)if m==5 else 0))/2
convert=lambda z:{m:ns['rat'](ns['gc'](s.expand(v)))for m,v in z.items()}
actual=convert(out);gaussian=ns['born']();ordered=ns['schur']();assert actual==gaussian==ordered,(actual,gaussian,ordered);wrong=convert(bad);changed=sum(actual[m]!=wrong[m]for m in actual);assert changed>0
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'block_formula_equals_literal_paired_Gaussian_and_ordered_Born_inverse':True,'heat_coefficients':ns['encode'](actual),'omit_right_HX_endpoint_changed_heat_coefficients':changed,'K1_zero_proved_in_free_block':True,'actual_model_or_QAP_claim':False},sort_keys=True),flush=True);timer.cancel()
