# IAG6 five measured source carriers and constant-H check

Prospective bounded integration,after IAG4/5 qualification. Reuse measured
IFC rho-Jx/u-Jx-C,IAS rho-JLambda-x/u-Ja-x and new IAG4 u-JLambda-C-x.
No new free coefficient or baseline,ordinary action installation,finite
root inference or complete Q-closure claim. Preserve five source patterns
and their charts/order. Convert only formal logs to independent log2,log3,
log5 and symbolic chi4. They are algebraic carriers,not fitted numbers.

Check the new full45x45x328 tensor at every separate heat length under
the12 actual constant unbroken directions. Derive the ghost adjoint matrix
from the raw QC source action and its actual ghost chart. Use original
QLambda beta for the source codomain and actual kinetic scalar R. For N_h
the tested identity is BH N_h -sum_k N_k GH[k,h]-N_h RH=0.
This is constant-H covariance,not varying-background covariance,source
reality,full Slavnov closure or independently calculated quantum roots.
Any nonzero remainder is retained and blocks this proposed covariance
claim;it does not justify changing coefficients to achieve cancellation.

One exact integration/audit180s after imports,8GiB sampled private,
350MiB launch-floor,64MiB packet. Freeze immutable sources/input hashes
before execution. Shared action/charts/library/AI authorship remain.
After this,derive the actual source variation of the combined functional
before comparing to a complete quantum-root identity. General BBx triangle
remains unmeasured and cannot be substituted by the old selected witness.
