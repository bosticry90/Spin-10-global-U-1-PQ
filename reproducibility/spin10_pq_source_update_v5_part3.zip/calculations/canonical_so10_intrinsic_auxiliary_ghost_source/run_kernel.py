from pathlib import Path
from hashlib import sha256
import json,ast,subprocess,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-auxiliary-ghost-source-v1-2026-10-25');P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';sys.path.insert(0,str(P));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 C.mkdir(exist_ok=False);base=subprocess.check_output(['git','rev-parse','HEAD'],text=True,cwd=R).strip();assert base=='d36d47f5af4c003f6415380a9e4d456fcf593680';assert subprocess.check_output(['git','branch','--show-current'],text=True,cwd=R).strip()=='main'
 dump(C/'start.json',{'HEAD':base,'previous_goal_turn':'PROGRESS','app_goal_observed':'active','scientific_acceptance':'NOT_PERFORMED'})
 with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r',base],cwd=R))
 b={}
 def bind(p):
  assert p.read_bytes()==subprocess.check_output(['git','show',base+':'+p.relative_to(R).as_posix()],cwd=R);b[str(p)]=H(p)
 for n in['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V625.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']:bind(R/n)
 assert H(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 for folder,files in{'canonical_so10_intrinsic_auxiliary_source':['UC_SUPPORT_RECORD.md','uc_support_validation_receipt.json','uc_support_primary_tables.json.gz','uc_support_replay_tables.json.gz'],'canonical_so10_intrinsic_scalar_source_ghost':['DERIVATION.md','validation_receipt.json'],'canonical_so10_probe_mass_dimension_one':['SYMBOL_RECORD.md','symbol_receipt.json','ending_validation_receipt.json']}.items():
  for n in files:bind(O.parent/folder/n)
 bind(P/'export_a10_e5_antighost_vector.py')
 for n in['RECORD.md','DERIVATION.md','kernel.py','verify_kernel.py','run_kernel.py']:
  p=O/n;cp=O/(n+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(cp)]=H(cp)
 dump(O/'kernel_preparation.json',{'input_sha256':b,'seconds_after_imports':300,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':64*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
 for role in['primary','replay','verify']:
  if role=='verify':
   for n in['kernel_preparation.json']+[f'kernel_{r}_{t}.json'+('.gz'if t=='tables'else'')for r in['primary','replay']for t in['tables','capture','result']]:p=O/n;b[str(p)]=H(p)
   dump(O/'kernel_validation_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
  cmd=[sys.executable,'-B',str(O/('verify_kernel.py'if role=='verify'else'kernel.py'))]+([]if role=='verify'else[role]);z=capture(cmd);dump(O/('kernel_'+role+'_capture.json'),z);dump(C/('kernel_'+role+'_full_capture.json'),z)
  assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(q['private_bytes']for q in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<(180 if role=='verify'else 300);dump(O/('kernel_validation_receipt.json'if role=='verify'else'kernel_'+role+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<64*1024**2
  print('COMPLETED_IAG1',role,json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'kernel_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
