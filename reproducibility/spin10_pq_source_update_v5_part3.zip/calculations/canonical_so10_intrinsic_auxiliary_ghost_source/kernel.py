from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from fractions import Fraction as F
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());role=sys.argv[1];assert role in['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'kernel_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
# Exact Gaussian integers; external J,C anticommute, u/n/x grades commute.
ca=lambda a,b:(a[0]+b[0],a[1]+b[1]);cm=lambda a,b:(a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]);cs=lambda a,n:(n*a[0],n*a[1]);cz=lambda a:a!=(0,0)
def gc(z):
 a,b=s.expand(z).as_real_imag();assert a.is_Integer and b.is_Integer,(a,b);return int(a),int(b)
def add(*aa):
 out={}
 for a in aa:
  for k,v in a.items():out[k]=ca(out.get(k,(0,0)),v)
 return{k:v for k,v in out.items()if cz(v)}
def scale(a,n):return{k:cs(v,n)for k,v in a.items()if n}
def mul(a,b):
 out={}
 for(m,e),v in a.items():
  for(n,f),w in b.items():
   if m&n:continue
   sg=-1 if(m&2 and n&1)else 1;k=m|n,e+f;out[k]=ca(out.get(k,(0,0)),cs(cm(v,w),sg))
 return{k:v for k,v in out.items()if cz(v)}
def mm(a,b):
 by=defaultdict(list);out={}
 for(j,k),v in b.items():by[j].append((k,v))
 for(i,j),v in a.items():
  for k,w in by[j]:out[i,k]=add(out.get((i,k),{}),mul(v,w))
 return{k:v for k,v in out.items()if v}
def ma(*aa):
 out={}
 for a in aa:
  for k,v in a.items():out[k]=add(out.get(k,{}),v)
 return{k:v for k,v in out.items()if v}
def ms(a,n):return{k:scale(v,n)for k,v in a.items()if n}
def const(M,e=0,mask=0):return{(i,j):{(mask,e):gc(z)}for(i,j),z in s.SparseMatrix(M).todok().items()}
def tr(M,par=None):return add(*(scale(v,(-1)**par[i]if par else 1)for(i,j),v in M.items()if i==j))
def rat(v,n=1):return F(v[0],n),F(v[1],n)
def fracadd(a,b):return a[0]+b[0],a[1]+b[1]
def encode(z):return {str(k):[str(v[0]),str(v[1])]for k,v in sorted(z.items())if v!=(0,0)}

nb=5;ng=2;per=nb+2*ng;dim=2*per;extJ=dim;extC=dim+1
par=[0]*nb+[1]*(2*ng);par*=2
qfield=lambda mode,i:mode*per+i
def tensors(q,omitD=False,omitULL=False):
 K=s.zeros(nb);U=s.zeros(nb);N=s.zeros(nb);Nr=s.zeros(nb);X=s.zeros(nb);D=s.zeros(nb)
 w=[2,3];A=s.Matrix([[1,2],[2,-1]]);B=s.Matrix([[1,-1],[2,1]]);L=s.Matrix([[2,1],[1,-2]])
 for a in range(2):
  K[a,2+a]=q;K[2+a,a]=-q;K[2+a,2+a]=w[a]
  for b in range(2):U[a,b]=A[a,b];U[a,2+b]=q*B[a,b];U[2+b,a]=-q*B[a,b];U[2+a,2+b]=0 if omitULL else L[a,b]
  N[2+a,4]=N[4,2+a]=s.I*(a+1)
  Nr[a,4]=q*s.I*[2,-1][a];Nr[4,a]=-Nr[a,4];Nr[2+a,4]=Nr[4,2+a]=[2,1][a]
  X[a,4]=-s.I*q*[1,-2][a];X[4,a]=-X[a,4]
  for b in range(2):D[a,b]=0 if omitD else[[1,3],[3,-1]][a][b]
 K[4,4]=1
 J=s.Matrix([[s.I*q,2*s.I*q,1,-1,0],[-3*s.I*q,s.I*q,2,1,0]])
 Ju=s.Matrix([[2*s.I*q,-s.I*q,0,2,0],[s.I*q,3*s.I*q,-1,1,0]])
 S=s.zeros(ng,nb);Su=s.zeros(ng,nb);S[0,4]=1;S[1,4]=2;Su[0,4]=3;Su[1,4]=-1
 Gs=s.Matrix([[1,2],[-1,3]]);Gsu=s.Matrix([[2,-1],[3,1]])
 W=s.zeros(nb,ng);W[2,0]=1;W[2,1]=2;W[3,0]=-1;W[3,1]=3
 Z=s.I*s.Matrix([[1,-1],[2,3]]);Zu=s.I*s.Matrix([[2,1],[-2,1]])
 return K,U,N,Nr,X,D,J,Ju,S,Su,Gs,Gsu,W,Z,Zu

def schur(omitD=False,omitULL=False,omitZ=False):
 result={m:(F(0),F(0))for m in range(2,6)}
 for q in[1,-1]:
  K,U,N,Nr,X,D,J,Ju,S,Su,Gs,Gsu,W,Z,Zu=tensors(q,omitD,omitULL)
  if omitZ:Z=s.zeros(ng);Zu=s.zeros(ng)
  G=const(K.inv(),1);V=ma(const(U,mask=4),const(N,mask=8),const(Nr,mask=12),const(X,mask=16),const(D,mask=28));A=mm(V,G);power=const(s.eye(nb));GB=G
  for k in range(1,4):power=mm(power,A);GB=ma(GB,ms(mm(G,power),(-1)**k))
  GG=ma(const(s.eye(ng),1),ms(const(Gs,2,24),-1),ms(const(Gsu,2,28),-1));M=ma(const(J),const(Ju,mask=4),const(S,mask=8),const(Su,mask=12));ZZ=ma(const(Z),const(Zu,mask=4));inside=ma(ZZ,mm(mm(M,GB),const(W)));raw=tr(mm(GG,inside))
  for m in range(2,6):result[m]=fracadd(result[m],rat(raw.get((28,m),(0,0)),-2))
 return result

def hessian(terms):
 out={}
 def deriv(word,i):
  for at,v in enumerate(word):
   if v==i:
    sg=(-1)**(par[i]*sum((par[w]if w<dim else 1)for w in word[:at]));yield word[:at]+word[at+1:],sg
 for mask,co,word in terms:
  integrated=set(v for v in word if v<dim)
  for i in integrated:
   for w,sg in deriv(word,i):
    for j in set(v for v in w if v<dim):
     for z,tg in deriv(w,j):
      assert all(v>=dim for v in z);m=mask;sign=sg*tg*(-1)**(par[j]*(par[i]+1));seen=[]
      for v in z:
       bit=1 if v==extJ else 2
       if bit in seen:sign=0
       if bit==1 and 2 in seen:sign*=-1
       seen.append(bit);m|=bit
      if sign:out[i,j]=add(out.get((i,j),{}),{(m,0):cs(co,sign)})
 return out

def born():
 free=[];pert=[]
 K,*rest=tensors(1)
 for(i,j),z in s.SparseMatrix(K).todok().items():free.append((0,gc(z),(qfield(1,i),qfield(0,j))))
 for mode in[0,1]:
  other=1-mode;q=1 if mode==0 else-1
  K,U,N,Nr,X,D,J,Ju,S,Su,Gs,Gsu,W,Z,Zu=tensors(q)
  for a in range(ng):free.append((0,(1,0),(qfield(other,nb+ng+a),qfield(mode,nb+a))))
  # onehalf sum_modes b_-q V(q) b_q, represented once by minus/plus.
  if mode==0:
   for mask,M in[(4,U),(8,N),(12,Nr),(16,X),(28,D)]:
    for(i,j),z in s.SparseMatrix(M).todok().items():pert.append((mask,gc(z),(qfield(1,i),qfield(0,j))))
  for mask,M in[(0,J),(4,Ju),(8,S),(12,Su)]:
   for(a,j),z in s.SparseMatrix(M).todok().items():pert.append((mask,gc(z),(qfield(other,nb+ng+a),extC,qfield(mode,j))))
  for(i,c),z in s.SparseMatrix(W).todok().items():pert.append((0,gc(z),(extJ,qfield(mode,nb+c),qfield(other,i))))
  for mask,M in[(0,Z),(4,Zu)]:
   for(a,c),z in s.SparseMatrix(M).todok().items():pert.append((mask,gc(z),(extJ,extC,qfield(other,nb+ng+a),qfield(mode,nb+c))))
  for mask,M in[(24,Gs),(28,Gsu)]:
   for(a,c),z in s.SparseMatrix(M).todok().items():pert.append((mask,gc(z),(qfield(other,nb+ng+a),qfield(mode,nb+c))))
 H0=hessian(free);V=hessian(pert);K=s.SparseMatrix(dim,dim,{(i,j):s.Integer(v[0])+s.I*v[1]for(i,j),r in H0.items()for(mask,e),v in r.items()});G=const(K.inv());assert s.expand(s.det(K))!=0
 M=mm(G,V);power=const(s.eye(dim));result={m:(F(0),F(0))for m in range(2,6)}
 for k in range(1,6):
  power=mm(power,M);v=tr(power,par).get((31,0),(0,0))
  if k>=2:result[k]=rat(cs(v,(-1)**(k+1)),4*k)
 return result

# The primary Gaussian is not defined by a target cancellation.
native=born()if role=='primary'else schur();other=schur()if role=='primary'else born();assert native==other,(encode(native),encode(other))
assert any(v!=(0,0)for v in native.values())
controls={name:sum(native[m]!=bad[m]for m in native)for name,bad in[('omit_direct_CC_source',schur(omitZ=True)),('omit_BBx_source_D',schur(omitD=True)),('omit_auxiliary_U_LL',schur(omitULL=True))]}
out={'schema':'IAG1_COMPLETE_PAIRED_GAUSSIAN_SCHUR_KERNEL','role':role,'heat_coefficients':encode(native),'paired_mode_normalization':'onequarter_STrlog_full_plusminus_Gaussian','Schur_operator':'minus_Tr_Gghost_(Z_plus_M_Gboson_W)','two_color_noncommuting_kernels':True,'all_target_grades_exact_no_Born_truncation':True,'controls_changed_heat_coefficients':controls,'longitudinal_no_closed_vector_spectator':True,'actual_model_coefficient_measured':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('kernel_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'heat_coefficients':encode(native),'controls':controls},sort_keys=True),flush=True);timer.cancel()
