from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'color_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[json.loads(gzip.decompress((O/('color_'+r+'_tables.json.gz')).read_bytes()))for r in ['primary','replay']]
for z in [a,b]:z.pop('role');assert z['full_positions_per_tensor']==664200;assert z['K1_zero_checked']and z['zero_ghost_background_ports_checked'];assert not z['QAP_E5_A5_authority']
assert a==b
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'all_groups_heat_lengths_finite_bases_and_zeros_agree':True,'full_positions_per_tensor':664200,'F2_F3_F4_F5_pole_positions':[[len(q['F_m'][str(m)])for m in range(2,6)]+[len(q['DIM_minus_heat_basis']['chi4'])]for q in a['results']],'R_sha256':a['R_sha256'],'QAP_E5_A5_authority':False},sort_keys=True),flush=True);timer.cancel()
