# Assembly preparation V2

Original run_assembly.py FAILED before preparation/native launch because
it guessed companion_receipt_v2.json; actual immutable receipt is
companion_v2_receipt.json. Preserve original source/copy/controller failure
and complete traceback. V2 changes only this binding and custody of the
failed files; same source,scientific conditions and resource caps. No
native scientific failure or PASS is inferred from the original preparation.
