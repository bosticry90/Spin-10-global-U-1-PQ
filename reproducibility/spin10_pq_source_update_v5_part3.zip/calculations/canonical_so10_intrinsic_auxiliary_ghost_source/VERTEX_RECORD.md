# IAG3: actual cubic auxiliary-source vertices and projected endings

Freeze after IAG1/2. Derive Z0_(r,h)[a,c] and Zu_(r,h)[a,c] as density
coefficients in JLambda_r C_external,h a_quantum,a C_quantum,c order.
Both choices of the external C in each actual CCa row are retained with
their own Grassmann signs. Euclidean action minus/source phase gives+i
on a derivative-free single-JLambda source row. No scalar half is added.

Original Z0 uses the actual raw qLambda CCa map,INVERSE Lambda-source
chart,two separate ghost field maps and antighost field map. Primary
differentiates/selects the external ghost before transport. Replay first
transports the odd cubic polynomial and then differentiates. Probe Zu
comes from the COMPLETE actual QG density: left source/ghost derivatives
versus right derivatives with actual parity conversion,before restriction.
Retain unexpected source/derivative types as an incomplete reduction,
not silently discard them. Original source CL beta is separately reused
from its qualified actual transport,not replaced by a coordinate projector.

Reauthenticate classical EDS P0/P1/P2/P3,U/N0/Nr,J0/Ju,S0/Su and their
actual zero sum. Compute complete projected port products beta_flat times
S0_flat,Su_flat and each actual ending Pj_flat. Primary explicit paths
versus sparse matrix multiplication,all source/auxiliary/ghost/scalar
indices retained including zeros. A zero projection may remove only its
specified full family; different heat lengths stay distinct. No assumed
transferred zero from the earlier rho or Ja calculation.

These results select the cheapest full color contraction;they do not
measure the target quantum kernel or pick a counterterm. Compare all
vertex coefficients/zeros with actual parameter powers,not a diagnostic
gauge coupling. Two300s natives,verifier180s,8GiB sampled,350MiB floor,
64MiB whole packet. Freeze actual inputs/sources/copies first;preserve
failures. Same authority ceiling/state/blocked stages and shared-premise
limitations as RECORD. No actual ordinary/IFC/IAS quantum target operands.
