from pathlib import Path
from hashlib import sha256
import gzip,json,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'kernel_validation_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
a,b=[load(O/('kernel_'+r+'_tables.json.gz'))for r in ['primary','replay']];assert{k:v for k,v in a.items()if k!='role'}=={k:v for k,v in b.items()if k!='role'};assert len(a['cases'])==23
counts=[];degrees=[]
for c in a['cases']:
 for row in c['rows']:
  assert row['m']in[2,3,4]
  for key,v in row['coefficients'].items():
   z=s.sympify(v);assert not(z.free_symbols-{s.Symbol(n)for n in ['wa','wb','pa','pb','D']});assert s.Poly(s.together(z*s.Symbol('D')),s.symbols('wa wb pa pb'))is not None
 counts.append({'category':c['category'],'basis':c['basis'],'m':[q['m']for q in c['rows']],'nonzero_coefficients':sum(v!='0'for q in c['rows']for v in q['coefficients'].values())})
out={'schema':'IBK2_ANGULAR_LORENTZ_KERNEL_VALIDATION','elapsed_after_imports':time.perf_counter()-tick,'manual_Green_jets_matrix_trace_vs_rational_derivatives_closed_index_sums_agree':True,'all_kernel_cases':len(a['cases']),'Dminus2_closed_vector_spectators_kept':True,'cases':counts,'actual_color_or_DIM_coefficients_or_QAP_E5_A5_authority':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
