from pathlib import Path
from hashlib import sha256
import gzip,json,time,threading,os
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'vertex_validation_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
a,b=[load(O/('vertex_'+r+'_tables.json.gz'))for r in ['primary','replay']];assert{k:v for k,v in a.items()if k!='role'}=={k:v for k,v in b.items()if k!='role'}
assert a['full_QG_jet_vs_Bose_reconstruction']and a['full_four_Lorentz_and_qp_coefficients_checked']and a['scalar_current_firstjet_density_and_covariant_Laplacian_signs_agree'];assert not a['actual_bosonic_quantum_coefficients_calculated']
counts=[]
for v in a['probe_BBB']:counts.append({wh:{k:len(rows)for k,rows in v[wh].items()}for wh in ['q','p']})
out={'schema':'IBK1_CLASSICAL_FIRSTJET_VERTEX_VALIDATION','elapsed_after_imports':time.perf_counter()-tick,'literal_full_QG_vs_Bose_constant_leg_reconstruction_agree':True,'all_four_Lorentz_coefficients_and_implicit_zeros_checked':True,'YM_from_adopted_F_cross_term_separate_from_GF':True,'scalar_polarization_and_covariant_Laplacian_agree':True,'actual_quadratic_Nr_and_unfiltered_inverse_checks':a['actual_mixed_quadratic_identities'],'probe_BBB_counts':counts,'auxiliary_BBL_counts':[len(v)for v in a['auxiliary_BBL']],'controls':a['controls'],'bosonic_quantum_coefficient_or_QAP_E5_A5_authority':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
