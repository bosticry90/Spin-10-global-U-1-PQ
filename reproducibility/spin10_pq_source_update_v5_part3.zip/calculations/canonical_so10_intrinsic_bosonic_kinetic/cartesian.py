from pathlib import Path
from hashlib import sha256
from itertools import product
from collections import defaultdict
import gzip,json,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'cartesian_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
kernel=load(O/'kernel_primary_tables.json.gz');t=s.Symbol('t');subs0={s.Symbol(k):v for k,v in {'wa':s.Rational(2,3),'wb':s.Rational(5,7),'na':2,'nb':3,'ra':5,'rb':7,'z':11,'h':13,'n0':2,'n1':3,'r0':5,'r1':7}.items()};tested=0;controls=defaultdict(int)
def direct(N,mode,cat,basis,which,control=None):
 sc=cat=='scalar';C=1 if sc else 2;nx=2 if sc else 1;dim=C*(N+1)+nx;bi=lambda a:list(range(a*N,(a+1)*N));li=lambda a:C*N+a;xx=list(range(C*(N+1),dim));q=s.eye(N)[:,0];e=s.eye(N)[:,0 if mode=='parallel'else 1];v=q+t*e;Q=(v.T*v)[0];probe=[int(which==0),int(which==1)];W=[s.Rational(2,3),s.Rational(5,7)];ns=[s.Matrix([2,3])]if sc else[s.Matrix([2]),s.Matrix([3])];rs=[s.Matrix([5,7])]if sc else[s.Matrix([5]),s.Matrix([7])];AA={}
 for key in [(0,0,1),(0,1,2),(1,0,2),(1,1,2),(1,1,3)]:
  G=s.zeros(dim)
  for a in range(C):
   w,P,nn=W[a],probe[a],ns[a]
   if key==(0,0,1):BB=s.eye(N)/Q+(w-1)*v*v.T/Q**2;BL=-v/Q;LB=v/Q;LL=0
   elif key==(0,1,2):BB=w*w*P*v*v.T/(2*Q**2);BL=-w*P*v/Q;LB=w*P*v/Q;LL=0 if control=='omit_LL'else-2*P
   else:BB=s.zeros(N);BL=s.zeros(N,1);LB=s.zeros(N,1);LL=0
   for i,j in product(range(N),repeat=2):G[bi(a)[i],bi(a)[j]]=BB[i,j]
   for i in range(N):G[bi(a)[i],li(a)]=BL[i];G[li(a),bi(a)[i]]=LB[i]
   G[li(a),li(a)]=LL
   if key[0]:
    fac=1 if key==(1,0,2)else-w*P if key==(1,1,2)else w*P;lfac=0 if key==(1,0,2)else-2*P if key==(1,1,2)else 2*P
    if key==(1,1,3)and control=='omit_LL':lfac=0
    for j,xj in enumerate(xx):
     for i in range(N):G[bi(a)[i],xj]=fac*nn[j]*v[i]/Q**2;G[xj,bi(a)[i]]=(1 if control=='reverse_endpoint'else-1)*fac*nn[j]*v[i]/Q**2
     G[li(a),xj]=lfac*nn[j]/Q;G[xj,li(a)]=lfac*nn[j]/Q
  if key==(0,0,1):
   for xj in xx:G[xj,xj]=1/Q
  AA[key]=(G.subs(t,0),G.diff(t).subs(t,0))
 B=s.zeros(dim);dB=s.zeros(dim);X=s.zeros(dim);dX=s.zeros(dim)
 if cat in ['vector','probe_vector','DX']:
  if basis in ['A','B','C','D','H']:
   M=q.dot(e)*s.eye(N)if basis=='A'else q*e.T if basis=='B'else e*q.T if basis=='C'else s.zeros(N);dM=s.eye(N)if basis=='D'else e*e.T if basis=='H'else s.zeros(N)
   for i,j in product(range(N),repeat=2):B[bi(0)[i],bi(1)[j]]=M[i,j];dB[bi(0)[i],bi(1)[j]]=dM[i,j]
  elif basis=='LB':
   for j in range(N):B[li(0),bi(1)[j]]=e[j]
  else:
   for i in range(N):B[bi(0)[i],li(1)]=e[i]
 elif sc:
  R=s.Matrix([[0,13],[-13,0]])
  for i,j in product(range(2),repeat=2):B[xx[i],xx[j]]=2*s.I*q.dot(e)*R[i,j];dB[xx[i],xx[j]]=s.I*R[i,j]
 else:
  for i in range(N):B[bi(0)[i],xx[0]]=11*e[i];B[xx[0],bi(0)[i]]=11*e[i]
 if cat=='DX':
  for i in range(N):X[bi(1)[i],bi(0)[i]]=11
 else:
  for a in range(C):
   for j,xj in enumerate(xx):
    for i in range(N):X[bi(a)[i],xj]=-s.I*q[i]*rs[a][j];X[xj,bi(a)[i]]=s.I*q[i]*rs[a][j];dX[bi(a)[i],xj]=s.I*e[i]*rs[a][j];dX[xj,bi(a)[i]]=2*s.I*e[i]*rs[a][j]
 if control=='omit_vertex_jets':dB=s.zeros(dim);dX=s.zeros(dim)
 bg=(0,1)if cat=='probe_vector'else(1,1)if cat=='DB'else(0,0);xg=(1,1)if cat=='DX'else(0,0);out=defaultdict(lambda:0)
 for ka,kb in product(AA,repeat=2):
  if tuple(ka[i]+kb[i]+bg[i]+xg[i]for i in range(2))!=(1,1):continue
  G,dG=AA[ka];J,dJ=AA[kb];out[ka[2]+kb[2]]-=s.trace(G*dB*J*X+G*B*dJ*X+G*B*J*dX)/2
 return dict(out)
for case in kernel['cases']:
 for N,mode,which in product([3,4,5],['parallel','transverse'],[0,1]):
  vals=direct(N,mode,case['category'],case['basis'],which);sub={**subs0,s.Symbol('D'):N,s.Symbol('pa'):int(which==0),s.Symbol('pb'):int(which==1)}
  for row in case['rows']:assert s.simplify(vals.get(row['m'],0)-s.sympify(row[mode]).subs(sub))==0,(case,N,mode,which,row['m']);tested+=1
 for control in ['omit_LL','reverse_endpoint','omit_vertex_jets']:
  base=direct(4,'transverse',case['category'],case['basis'],0);bad=direct(4,'transverse',case['category'],case['basis'],0,control);controls[control]+=sum(s.simplify(base.get(k,0)-bad.get(k,0))!=0 for k in set(base)|set(bad))
assert all(controls.values())
out={'schema':'IBK2_FULL_CARTESIAN_WITNESS_REVIEW','elapsed_after_imports':time.perf_counter()-tick,'all_D3_D4_D5_parallel_transverse_and_probe_choices_agree':True,'exact_component_coefficient_checks':tested,'sensitive_control_cases':dict(controls),'finite_D_witnesses_not_used_as_analytic_interpolation':True,'model_color_DIM_or_QAP_E5_A5_authority':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
