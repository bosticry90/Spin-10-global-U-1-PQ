The first heat primary completed, but replay failed its radial-factor
assertion before output. Its wrapper incorrectly divided the positive radial
integral by two a second time. With Q=q^2, the measure is Q dQ/(16pi^2);
the degree-3 zero-p symbol times q.p leaves dQ, and
 -4t mR integral_0^infty dQ exp(-2mtQ) = -2mR/m.
Equivalently integral dTau [-4mR exp(-2mTau)] = -2mR/m.
The extra /2 is removed in heat_kernels_v2.py. Preserve first primary output,
failed replay capture, frozen sources and v2 controller failure unchanged.
New separately named paired kernel outputs and manifests repeat this cheap
stage under the same two300s/180s,8GiB,350MiB,24MiB limits; no resource
expansion or changed mathematical acceptance. Dependents require the new
paired verifier. This is a replay wrapper error, not evidence of a physics
obstruction. No failed run is counted as PASS.
