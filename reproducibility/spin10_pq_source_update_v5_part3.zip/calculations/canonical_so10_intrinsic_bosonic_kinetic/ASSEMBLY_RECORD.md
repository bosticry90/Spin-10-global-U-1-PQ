# IBK4: late ghost assembly and current-dependency check

Freeze after both complete bosonic color natives and verifier passed. No
native saw a ghost quantum coefficient or expected translation. Now bind
the existing IKG1 actual ghost result/receipt and add it exactly once.
Do not fit any coefficient or require the ordinary UV functional to vanish.

Before assembly, freshly derive the probe aCB current from the full actual
canonical QG density. Retain left-Grassmann signs, Wick phases, all derivative
placements and four Lorentz components. Compare its V=Ua-UB,AC=Ua-UC to
the qualified classical tensors used by IKG1. This targeted check is warranted
by the different coupling orders of source ghost and bosonic contributions;
do not equate orders or silently repair an inherited mismatch. If it fails,
preserve the exact remainder and stop dependent ghost assembly.

After that gate, assemble bosonic F_m(D) and ghost angular F2(D)=TV-TA+2TA/D.
Check the D4 ghost limit against its complete nonexceptional bubble F.
Keep the pole/angular sum, epsilon numerator jet, relative HEAT-minus-SINGLE
prime-log2/log3 tensors and both ghost/boson owners separate. No DIM finite
baseline is selected. A nonzero ordinary coefficient is not itself a Slavnov
breaking or anomaly; its full source/Ward variation has not been evaluated.

Compare assembly through independent coordinate sums and sparse matrix
addition, including all45x328 zeros and each analytic-D coefficient. Preserve
coupling powers. Test duplicate/omitted ghost owner and swapped log6/log8.
Do not transfer the earlier potential coefficient to kinetic fields.

One180s review,8GiB sampled private,350MiB launchfloor,24MiB packet. Bind
actual historical source/receipt bytes and freeze new sources/copies first.
Keep any failed check or underdefinition explicit. No counterterm scheme,
full QAP/measure/phase/source-reality/E5/A5/physical viability promotion.
