from pathlib import Path
from hashlib import sha256
import gzip,ast,json,sys,subprocess,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-bosonic-kinetic-v1-2026-10-25');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));b={}
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
def bind(p):
 assert p.read_bytes()==subprocess.check_output(['git','show','HEAD:'+p.relative_to(R).as_posix()],cwd=R);b[str(p)]=H(p)
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()=='e24d9b9d083f6ea0f1ee82601f3faec0819a2bdc'
 ap=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json';bind(ap);action=read(ap)['local_terms'][:5];assert action[0]['term_id']=='gauge'
 for role in ['primary','replay']:
  V=O.parent/'canonical_so10_probe_ghost_vector_vertices';p=V/(role+'_v2_tables.json.gz');lp=V/('loop_'+role+'_inputs.json.gz');np=O.parent/'canonical_so10_finite_intrinsic_mixed_response'/(role+'_inputs.json.gz');rp=O.parent/'canonical_so10_intrinsic_scalar_potential_response'/(role+'_v2_inputs.json.gz');dp=O.parent/'canonical_so10_intrinsic_kinetic_support'/(role+'_vertex_v4_tables.json.gz')
  for f in [p,lp,np,rp,dp]:bind(f)
  data={'vertices':load(p)['vertices'],'physical_f':load(lp)['physical_f'],'quadratic':load(np),'R':load(rp)['R'],'D':[v['physical_Euclidean_BB_Hessian_D']for v in load(dp)['results']],'physical_kinetic_AST':action}
  if role=='primary':
   ip=O.parent/'canonical_so10_intrinsic_ghost_hatted/primary_inputs.json.gz';bind(ip);aa=load(ip)['audit'];data['audit']={k:aa[k]for k in ['names','physical_QG']}
  dst=O/('vertex_'+role+'_inputs.json.gz')
  with dst.open('xb')as f:f.write(gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
  b[str(dst)]=H(dst)
 for folder,ns in [('canonical_so10_probe_ghost_vector_vertices',['RECORD.md','validation_receipt_v2.json']),('canonical_so10_rho_vector_support',['validation_receipt_v3.json']),('canonical_so10_probe_auxiliary_resolvent',['DERIVATION.md','validation_receipt_v2.json','compression_receipt.json']),('canonical_so10_intrinsic_scalar_potential_response',['validation_receipt_v4.json']),('canonical_so10_intrinsic_kinetic_support',['vertex_validation_receipt_v4.json','support_validation_receipt.json']),('canonical_so10_intrinsic_kinetic_firstjet',['DERIVATION.md','validation_receipt_v2.json','review_receipt.json'])]:
  for n in ns:bind(O.parent/folder/n)
 for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V620.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:bind(R/n)
 for n in ['RECORD.md','vertices.py','verify_vertices.py','run_vertices.py']:
  p=O/n
  with(O/(n+'.source.txt')).open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(p)
 dump(O/'vertex_preparation.json',{'input_sha256':b,'worker_seconds_after_imports':300,'verifier_seconds_after_imports':180,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':24*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
 for role in ['primary','replay','verify']:
  if role=='verify':
   for n in ['vertex_preparation.json']+['vertex_'+r+'_'+z+'.json'+('.gz'if z=='tables'else'')for r in ['primary','replay']for z in ['tables','result','capture']]:p=O/n;b[str(p)]=H(p)
   dump(O/'vertex_validation_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
  cmd=[sys.executable,'-B',str(O/('verify_vertices.py'if role=='verify'else'vertices.py'))]+([]if role=='verify'else[role]);z=capture(cmd);dump(O/('vertex_'+role+'_capture.json'),z);dump(C/('vertex_'+role+'_full_capture.json'),z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified']and z['launch']['memory']['available_pagefile']>=350*1024**2 and max(x['private_bytes']for x in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(x[7:])for x in z['stdout_and_stderr'].splitlines()if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<(180 if role=='verify'else 300);dump(O/('vertex_validation_receipt.json'if role=='verify'else'vertex_'+role+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<24*1024**2;print('COMPLETED_IBK1_VERTEX',role,rr[0]['elapsed_after_imports'],flush=True)
except BaseException:
 dump(O/'vertex_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
