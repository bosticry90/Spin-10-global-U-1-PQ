# IBK3: complete actual bosonic Bx angular coefficient and heat comparison

Freeze after IBK1/2 and Cartesian review pass. Compute all remaining bosonic
Bx bubbles, not one projection. Full45 external/internal vectors,328 scalars,
both probes and symbolic g10/xi/eta_H remain. Use actual n=N0_L, R_a,
complete YM/probe q/p tensors, old/probe BB-Lambda tensors and both D
placements. No ghost quantum tensor, source-vector/counterterm or expected
translation is a native input. Retain each family and heat length separately.

For gauge/aux kernels keep n_a^T R_b and n_b^T R_a distinct. For the scalar
current use n_a^T R_c R_a, not its reversed product. D externalx contracts
T_(a,b,c) D_(b,a,i); D externalB contracts D_(a,c,i) R_a(i,j). The 1/2
and Fourier phases are already in the verified kernels. Divide the final
Gamma coefficient by i once to report F in i*p.B*x convention.

Keep analytic D as exact Laurent powers -1,0,1. Evaluate at D4 only for
the HEAT-minus-SINGLE map, with coefficients -log4,-log6,-log8 for m2,3,4.
Store independent prime-log2/log3 matrices, full unheated UV angular sum
and its epsilon numerator jet. No prescribed zero is imposed on that sum.
The epsilon jet is not by itself the full DIM finite conversion. Keep
higher-reference physical cubic/mass inputs outside their qualified class.

Primary contracts explicit color/component paths with cached ordered nR
rows. Replay forms complete sparse trace matrices over ordered color-pair
and scalar spaces, with separate ordered scalar matrix products. Compare
all45x328 coefficients and zero complements for every family,m,D power.
Controls omit auxiliary families, either D placement, replace all heat
lengths by m2 and reverse the scalar generator order; report insensitive
controls as such. Do not change an unknown coefficient to obtain agreement.

Only after both natives and verifier complete may a late review assemble
the authenticated ghost result exactly once. That review must retain
unheated poles, finite heat differences, D jets and independent unresolved
DIM normalization/physical-domain obligations separately. No partial
counterterm or full-Euler shift is installed on a favorable result.

Two sequential300s natives,180s verifier,8GiB sampled private,350MiB launch
floor,24MiB total packet. Freeze inputs/sources/copies before computation.
Preserve every failed or unfinished version, no truncation or gate weakening.
This qualifies only the complete reference-linear Bx angular/relative-heat
calculation; no automatic full DIM/QAP/measure/phase/source-reality/E5/A5
or physical unification claim. Authority34of39 and protected state unchanged.
