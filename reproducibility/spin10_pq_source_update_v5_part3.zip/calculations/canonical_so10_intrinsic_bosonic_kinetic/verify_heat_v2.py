from pathlib import Path
from hashlib import sha256
import gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;stage=sys.argv[1];assert stage in ['heat_kernel_v2','heat_color'];read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/(stage+'_validation_preparation.json'))['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
a,b=[load(O/(stage+'_'+r+'_tables.json.gz'))for r in ['primary','replay']];assert{k:v for k,v in a.items()if k!='role'}=={k:v for k,v in b.items()if k!='role'};positions=0
if stage=='heat_kernel_v2':
 assert len(a['cases'])==23 and a['routing_identity_checked']and a['omitting_heat_or_Djet_breaks_routing_in_nonzero_components']>0
 for q in a['cases']:
  for row in q['rows']:
   for v in row['coefficients'].values():
    z=s.sympify(v);assert z.free_symbols<={s.Symbol(n)for n in ['wa','wb','pa','pb','D']};assert s.Poly(s.cancel(z*s.Symbol('D')),s.Symbol('D'))is not None;positions+=1
else:
 assert len(a['results'])==2
 for z in a['results']:
  assert len(z['families'])==33 and len(z['H_m_D_coefficients'])==9
  for q in z['families']:
   M=q['H'];assert M['shape']==[45,328];assert len({(i,j)for i,j,v in M['entries']})==len(M['entries']);positions+=45*328
out={'schema':'IBK5_PAIRED_HEAT_VALIDATION','stage':stage,'elapsed_after_imports':time.perf_counter()-tick,'all_coefficients_and_zero_complements_agree':True,'positions_checked':positions,'scientific_promotion_or_full_QAP':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
