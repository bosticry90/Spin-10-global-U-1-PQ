from pathlib import Path
from hashlib import sha256
import gzip,json,time,threading,os
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'color_validation_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
a,b=[load(O/('color_'+r+'_tables.json.gz'))for r in ['primary','replay']];assert{k:v for k,v in a.items()if k!='role'}=={k:v for k,v in b.items()if k!='role'};summary=[];slots=0
def check(M):
 assert M['shape']==[45,328]and len({tuple(z[:-1])for z in M['entries']})==len(M['entries'])and all(0<=i<45 and 0<=j<328 and v!='0'for i,j,v in M['entries'])
for z in a['results']:
 assert len(z['families'])==33 and len(z['total_F_m_D_coefficients'])==9
 for q in z['families']+z['total_F_m_D_coefficients']:check(q['F'])
 for q in list(z['F_m_at_D4'].values())+list(z['heat_minus_single_prime_logs'].values())+[z['unheated_UV_angular_F_at_D4'],z['epsilon_numerator_jet_not_full_DIM_finite']]:check(q)
 slots+=len(z['families'])*45*328
 summary.append({'probe':z['probe'],'F_m_D4_nonzero':[len(z['F_m_at_D4'][str(m)]['entries'])for m in[2,3,4]],'unheated_UV_angular_F_D4_nonzero':len(z['unheated_UV_angular_F_at_D4']['entries']),'prime_log2_log3_nonzero':[len(z['heat_minus_single_prime_logs'][str(p)]['entries'])for p in[2,3]],'epsilon_numerator_jet_nonzero':len(z['epsilon_numerator_jet_not_full_DIM_finite']['entries']),'controls':z['controls']})
assert not a['source_ghost_quantum_counterterm_or_expected_translation_read']and not a['full_QAP_source_reality_E5_A5_authority']
out={'schema':'IBK3_COMPLETE_BOSONIC_BX_COLOR_VALIDATION','elapsed_after_imports':time.perf_counter()-tick,'explicit_color_paths_vs_ordered_sparse_trace_matrix_routes_agree':True,'complete_family_m_D_coefficient_positions_including_zeros':slots,'both_probes_all45_vectors_all328_scalars':True,'results':summary,'relative_scope':a['relative_scope'],'full_DIM_QAP_source_reality_E5_A5_authority':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
