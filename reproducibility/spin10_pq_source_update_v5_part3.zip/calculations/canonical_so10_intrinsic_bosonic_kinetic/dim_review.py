from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'dim_review_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta};parse=lambda z:s.sympify(z,locals=loc);cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v)for i,j,v in z['entries']});enc=lambda M:{'shape':list(M.shape),'entries':[[i,j,str(s.expand(v))]for(i,j),v in sorted(cl(M).todok().items())if s.expand(v)!=0]}
inp=read(O/'assembly_inputs.json');ghost=load(Path(inp['ghost_tables']));full=load(O/'complete_Bx_relative_heat.json.gz');heat=load(O/'heat_color_primary_tables.json.gz');results=[];summaries=[]
D=s.Symbol('D',positive=True);sd=2*s.pi**(D/2)/s.gamma(D/2)/(2*s.pi)**D;sigma=s.simplify(s.diff(s.log(sd),D).subs(D,4));assert s.simplify(s.EulerGamma+s.log(4)-2*sigma-1-s.log(16*s.pi))==0
for a,h,q in zip(full['results'],heat['results'],ghost['results']):
 probe=a['probe'];assert probe==h['probe']==q['probe'];F={m:dec(a['F_m_at_D4'][str(m)])for m in [2,3,4]};J=dec(a['epsilon_numerator_jet_not_complete_DIM_finite']);HB={m:dec(h['H_m_at_D4'][str(m)])for m in[2,3,4]};TA=dec(q['UV_angular_AC_tensor']);GF=dec(q['full_nonexceptional_bubble_coefficient_F']);GH=TA/4;GJ=TA/4;assert not cl(GJ-GH).todok();H=cl(sum(HB.values(),s.zeros(45,328))+GH);P=cl(sum(F.values(),s.zeros(45,328)));fixed=cl(J-H);log2=cl(-F[3]+F[4]);log3=F[3];basis={'chi4':P,'log2':log2,'log3':log3,'fixed':fixed}
 # Disjoint coordinate assembly through the original D-coefficient owner lists.
 FD={(z['m'],z['D_power']):dec(z['F']).todok()for z in a['complete_F_m_D_coefficients']};HD={(z['m'],z['D_power']):dec(z['H']).todok()for z in h['H_m_D_coefficients']};universe={(i,j)for i in range(45)for j in range(328)};refs={k:{}for k in basis}
 for ij in sorted(universe):
  fm={m:s.expand(sum(s.Rational(4)**p*FD[m,p].get(ij,0)for p in[-1,0,1]))for m in[2,3,4]};jv=sum(FD[m,-1].get(ij,0)/8-2*FD[m,1].get(ij,0)for m in[2,3,4]);hv=sum(s.Rational(4)**p*HD[m,p].get(ij,0)for m in[2,3,4]for p in[-1,0,1])+GH[ij];vals={'chi4':sum(fm.values()),'log2':-fm[3]+fm[4],'log3':fm[3],'fixed':jv-hv}
  for k,v in vals.items():
   v=s.expand(v)
   if v:refs[k][ij]=v
 for k,M in basis.items():assert enc(M)==enc(s.SparseMatrix(45,328,refs[k]));assert all(s.Poly(z,g,xi,eta)is not None for z in M.todok().values())
 # Independent relative-comparator identity: all heat-length logs collapse
 # to -log4*P when DIM-heat is followed by heat-single.
 hl={int(k):dec(v)for k,v in a['complete_heat_minus_single_prime_logs'].items()};assert not cl(log3+hl[3]).todok();assert not cl(log2+hl[2]+2*P).todok()
 controls={'drop_heat_positive_jet_changes_positions':len(H.todok()),'drop_D_numerator_jet_changes_positions':len(J.todok()),'wrong_heat_length_log_changes_positions':len(cl(F[3]-F[4]).todok()),'omit_ghost_changes_chi4_positions':len(GF.todok())}
 witnesses=[]
 for ij in[(12,206),(13,136)]:witnesses.append({'B':ij[0],'x':ij[1],**{k:str(s.expand(M[ij]))for k,M in basis.items()},'J':str(J[ij]),'strict_heat_H':str(H[ij])})
 results.append({'probe':probe,'DIM_minus_strict_heat_basis':{k:enc(M)for k,M in basis.items()},'bosonic_heat_H_m':{str(m):enc(M)for m,M in HB.items()},'ghost_heat_H2':enc(GH),'complete_strict_heat_H':enc(H),'complete_dimension_numerator_J':enc(J),'controls':controls,'witnesses':witnesses})
 summaries.append({'probe':probe,'basis_nonzero':{k:len(M.todok())for k,M in basis.items()},'boson_H_nonzero_by_m':[len(HB[m].todok())for m in[2,3,4]],'ghost_H_nonzero':len(GH.todok()),'complete_H_nonzero':len(H.todok()),'controls':controls,'witnesses':witnesses})
out={'schema':'IBK5_COMPLETE_SELECTED_BX_DIM_MINUS_STRICT_HEAT','results':results,'unit':'u * intrinsic_reference_grade * i p.B x /(16pi^2); chi4+log2+log3+fixed basis','complete_45_by328_zero_complements_checked_each_probe':True,'matrix_vs_coordinate_assembly_agree':True,'DIM_heat_single_composition_checked':True,'ghost_full_nonexceptional_DIM_minus_heat_equals_chi4_F':True,'chi4_symbolic_not_physically_selected':True,'b0_kappa_not_identified':True,'BBx_fullEuler_QAP_E5_A5_authority':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'complete_Bx_DIM_minus_heat.json.gz').open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'complete_selected_Bx_finite_conversion':True,'summary':summaries,'promote_E5_A5':False},sort_keys=True),flush=True);timer.cancel()
