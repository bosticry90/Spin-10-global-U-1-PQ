# IBK2 independent full-Cartesian witness review

Freeze after IBK2 kernel P/R/verifier completion. Independently instantiate
the complete vector/auxiliary/scalar matrices in Cartesian Lorentz D3,4,5
and differentiate rational Green symbols at q+p. Compare every23 kernel
case, both parallel/transverse orientations, both probe color selections,
every heat length and all zeros against the two-plane plus D-2 result.
This is a witness for the structural spectator proof, not interpolation
used to infer analytic D. Exact diagnostic widths2/3 and5/7, n=(2,3),
r=(5,7),D-vertex11 and scalar-current13 are not physical parameter points.

Controls drop Gu_LL including its derived mixed-inverse Lambda-x term,
reverse only the N endpoint sign and remove external
vertex derivatives. Check sensitive differences, retaining insensitive
cases honestly. The qualified actual source and momentum conventions
remain fixed; do not fit a model coefficient. One180s review,8GiB sampled
private,350MiB launchfloor,24MiB whole packet. Freeze sources/copies and
receipt bindings first; preserve failures. No quantum color/DIM result
or promotion follows from Cartesian fixture agreement alone.
