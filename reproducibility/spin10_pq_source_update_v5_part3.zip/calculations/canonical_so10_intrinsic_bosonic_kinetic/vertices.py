from pathlib import Path
from hashlib import sha256
from itertools import permutations,product
from collections import defaultdict
from functools import lru_cache
import gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'vertex_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('vertex_'+('replay'if role=='primary'else'primary')):raise PermissionError('IBK1_VERTEX_PEER_DENIED')
  if p.parent.name in ['canonical_so10_intrinsic_kinetic_firstjet','canonical_so10_finite_intrinsic_scalar_source','canonical_so10_intrinsic_finite_conversion_module']:raise PermissionError('IBK1_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard);d=load(O/('vertex_'+role+'_inputs.json.gz'));g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.sympify(z,locals=loc)
def coef(p,ci,gp):
 out=0
 for xp,ep,mask,n,den in p['coefficients'][ci]:
  v=s.Rational(n,den)*xi**xp*eta**ep
  for j,prime in enumerate([2,3,5,7]):
   if mask&(1<<j):v*=s.sqrt(prime)
  if mask&16:v*=s.I
  out+=v
 return s.expand(g**gp*out)
def scalar(p):
 out=0
 for gp,w,ci in p['monomials']:assert not w;out+=coef(p,ci,gp)
 return s.expand(out)
clean=lambda z:{k:s.expand(v)for k,v in z.items()if s.expand(v)!=0};tab=lambda z:{tuple(row[:-1]):scalar(row[-1])for row in z};enc=lambda z:[[ *k,str(v)]for k,v in sorted(clean(z).items())];dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v)for i,j,v in z['entries']});cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand)
P=[{key:tab(v['BBB'][key])for key in ['A','B','C']}for v in d['vertices']];qjets=[];pjets=[];controls=[]
if role=='primary':
 names=d['audit']['names'];bb={names.index(f'B{i}_{mu}'):(i,mu)for i in range(45)for mu in range(4)}
 for probe,p in enumerate(d['audit']['physical_QG']):
  out=[defaultdict(lambda:0),defaultdict(lambda:0)]
  for gp,w,ci in p['monomials']:
   if len(w)!=3 or any(n not in bb for n,I in w):continue
   assert sum(len(I)for n,I in w)==1
   fac=-coef(p,ci,gp)*s.I**(sum(bb[n][1]==0 for n,I in w)+sum(I.count(0)for n,I in w))
   for first,second,ext in permutations(range(3)):
    a,alpha=bb[w[first][0]];b,beta=bb[w[second][0]];c,gamma=bb[w[ext][0]];at=next(i for i,(n,I)in enumerate(w)if I);nu=w[at][1][0];sgq=-1 if at==first else 1 if at==second else 0;sgp=1 if at==second else-1 if at==ext else 0
    for oo,sg in zip(out,[sgq,sgp]):
     if sg:oo[a,b,c,alpha,beta,gamma,nu]+=s.I*sg*fac
  out=list(map(clean,out));maps=[]
  for oo in out:
   m={key:{}for key in ['A','B','C']};colors={k[:3]for k in oo}
   witnesses=[(1,1,0,0),(0,1,1,0),(1,0,1,0)]
   for key in colors:
    for name,axes in zip(['A','B','C'],witnesses):
     value=oo.get((*key,*axes),0)
     if value:m[name][key]=value
   expected={}
   for key in colors:
    for al,be,ga,nu in product(range(4),repeat=4):
     v=m['A'].get(key,0)*int(al==be and ga==nu)+m['B'].get(key,0)*int(al==nu and be==ga)+m['C'].get(key,0)*int(be==nu and al==ga)
     if v:expected[(*key,al,be,ga,nu)]=s.expand(v)
   assert oo==expected,('FULL_QP_BBB_LORENTZ_BASIS',probe,len(oo),len(expected))
   maps.append(m)
  qj,pj=maps
  # In p maps A=p_gamma delta_ab, B=p_alpha delta_bc, C=p_beta delta_ac.
  assert all(qj[k]=={t:s.expand(-v)for t,v in P[probe+1][k].items()}for k in ['A','B','C'])
  predicted={'A':{(a,b,c):v for(b,c,a),v in P[probe+1]['C'].items()},'B':{(a,b,c):v for(b,c,a),v in P[probe+1]['A'].items()},'C':{(a,b,c):v for(b,c,a),v in P[probe+1]['B'].items()}}
  assert pj==predicted,('BOSE_FULL_EXTERNAL_MOMENTUM',probe)
  qjets.append(qj);pjets.append(pj);controls.append({'wrong_old_internal_q_orientation_changes_positions':sum(len(z)for z in qj.values()),'omit_external_momentum_terms_changes_positions':sum(len(z)for z in pj.values())})
else:
 assert'audit'not in d
 for probe in range(2):
  qj={k:{t:s.expand(-v)for t,v in P[probe+1][k].items()}for k in ['A','B','C']};pj={'A':{(a,b,c):v for(b,c,a),v in P[probe+1]['C'].items()},'B':{(a,b,c):v for(b,c,a),v in P[probe+1]['A'].items()},'C':{(a,b,c):v for(b,c,a),v in P[probe+1]['B'].items()}};qjets.append(qj);pjets.append(pj);controls.append({'wrong_old_internal_q_orientation_changes_positions':sum(len(z)for z in qj.values()),'omit_external_momentum_terms_changes_positions':sum(len(z)for z in pj.values())})
# Adopted F sign/Wick, not the gauge-fixing BBB tables, determines YM.
f=tab(d['physical_f']);assert all(f.get((b,a,c),0)==-v and f.get((a,c,b),0)==-v for(a,b,c),v in f.items());perm6=list(permutations(range(3)));par=lambda p:(-1)**sum(p[i]>p[j]for i in range(3)for j in range(i+1,3))
def cubic(alpha,beta,gamma,nu,which):
 axes=[alpha,beta,gamma];weights=[-1,1,0]if which=='q'else[0,1,-1];out=0
 for der,b,c in perm6:
  if axes[der]==axes[c]and axes[b]==nu:out+=s.I*g*par((der,b,c))*weights[der]
 return s.expand(out)
if role=='primary':
 yq={k:cubic(*v,'q')for k,v in zip(['A','B','C'],[(1,1,0,0),(0,1,1,0),(1,0,1,0)])};yp={k:cubic(*v,'p')for k,v in zip(['A','B','C'],[(1,1,0,0),(0,1,1,0),(1,0,1,0)])}
else:yq={'A':2*s.I*g,'B':-s.I*g,'C':-s.I*g};yp={'A':s.I*g,'B':-2*s.I*g,'C':s.I*g}
assert yq=={'A':2*s.I*g,'B':-s.I*g,'C':-s.I*g}and yp=={'A':s.I*g,'B':-2*s.I*g,'C':s.I*g}
for al,be,ga,nu in product(range(4),repeat=4):
 for wh,M in [('q',yq),('p',yp)]:assert cubic(al,be,ga,nu,wh)==M['A']*int(al==be and ga==nu)+M['B']*int(al==nu and be==ga)+M['C']*int(be==nu and al==ga)
YMq={k:{t:s.expand(v*c)for t,c in f.items()}for k,v in yq.items()};YMp={k:{t:s.expand(v*c)for t,c in f.items()}for k,v in yp.items()};aux=[tab(v['auxiliary'])for v in d['vertices']];assert all(M.get((l,c,b),0)==v for M in aux for(l,b,c),v in M.items())
N=dec(d['quadratic']['N0']);assert not N[:45,:].todok();n=N[45:,:];quadratic=[]
for probe,z in enumerate(d['quadratic']['probe_quadratics']):
 Nr=dec(z['Nr']);p=s.diag(*[int((a<12)==(probe==0))for a in range(45)]);W=s.diag(*([eta]*12+[xi]*33));assert not cl(Nr[:45,:]-2*p*n).todok()and not cl(Nr[45:,:]-W*p*n).todok();G=dec(d['quadratic']['G0']);Gr=dec(z['Gr']);assert not cl(-G*Nr-Gr*N).todok();quadratic.append({'Nr_B_equals_2P_N0L':True,'Nr_L_equals_wP_N0L':True,'complete_unfiltered_mixed_inverse_zero':True})
# Scalar signs: literal polarization versus ordered covariant Laplacian.
q,p,r=s.symbols('q p r');R=s.Matrix([[0,r],[-r,0]]);h=s.Matrix(s.symbols('h0:2'));k=s.Matrix(s.symbols('k0:2'));phi=s.Matrix(s.symbols('x0:2'));LBB=s.expand((-(-s.I*q*h).dot(R*k)-(s.I*(q+p)*k).dot(R*h)));expected=s.expand((h.T*(s.I*(2*q+p)*R)*k)[0]);assert s.expand(LBB-expected)==0
LBx=s.expand(-(s.I*q*k).dot(R*phi)-(s.I*p*phi).dot(R*k));LxB=s.expand(-(-s.I*(q+p)*h).dot(R*phi)-(s.I*p*phi).dot(R*h));assert s.expand(LBx-(-s.I*(q-p)*(R*phi)).dot(k))==0 and s.expand(LxB-(s.I*(q+2*p)*(R*phi)).dot(h))==0
out={'schema':'IBK1_FULL_BOSONIC_FIRSTJET_VERTICES','role':role,'YM':{'q':{k:enc(v)for k,v in YMq.items()},'p':{k:enc(v)for k,v in YMp.items()}},'probe_BBB':[{'q':{k:enc(v)for k,v in qj.items()},'p':{k:enc(v)for k,v in pj.items()}}for qj,pj in zip(qjets,pjets)],'auxiliary_BBL':[enc(v)for v in aux],'full_QG_jet_vs_Bose_reconstruction':True,'full_four_Lorentz_and_qp_coefficients_checked':True,'scalar_current_firstjet_density_and_covariant_Laplacian_signs_agree':True,'actual_mixed_quadratic_identities':quadratic,'controls':controls,'actual_bosonic_quantum_coefficients_calculated':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('vertex_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True);timer.cancel()
