from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'assembly_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta};parse=lambda z:s.sympify(z,locals=loc);clean=lambda z:{k:s.expand(v)for k,v in z.items()if s.expand(v)!=0};dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v)for i,j,v in z['entries']});enc=lambda M:{'shape':list(M.shape),'entries':[[i,j,str(s.expand(v))]for(i,j),v in sorted(s.SparseMatrix(M).todok().items())if s.expand(v)!=0]}
def coef(p,ci,gp):
 z=0
 for xp,ep,mask,n,den in p['coefficients'][ci]:
  v=s.Rational(n,den)*xi**xp*eta**ep
  for j,prime in enumerate([2,3,5,7]):
   if mask&(1<<j):v*=s.sqrt(prime)
  if mask&16:v*=s.I
  z+=v
 return s.expand(g**gp*z)
def scalar(p):return s.expand(sum(coef(p,ci,gp)for gp,w,ci in p['monomials']))
aud=load(O/'vertex_primary_inputs.json.gz')['audit'];names=aud['names'];anti={names.index(('bar'if i<12 else'ub')+str(i)):i for i in range(45)};ghost={names.index('C'+str(i)):i for i in range(45)};bb={names.index(f'B{i}_{mu}'):(i,mu)for i in range(45)for mu in range(4)};old=load(Path(read(O/'assembly_inputs.json')['classical_vertex_tables']))['vertices'];current_checks=[]
for probe,p in enumerate(aud['physical_QG']):
 T=[defaultdict(lambda:0)for _ in range(4)]
 for gp,w,ci in p['monomials']:
  if len(w)!=3:continue
  ai=[j for j,(n,I)in enumerate(w)if n in anti];ci0=[j for j,(n,I)in enumerate(w)if n in ghost];bi=[j for j,(n,I)in enumerate(w)if n in bb]
  if len(ai)!=1 or len(ci0)!=1 or len(bi)!=1:continue
  assert sum(len(I)for n,I in w)==1;aa,cc,ib=ai[0],ci0[0],bi[0];b,mu=bb[w[ib][0]];at=next(j for j,(n,I)in enumerate(w)if I);assert w[at][1]==[mu];which='a'if at==aa else'B'if at==ib else'C';sg=-1 if cc<aa else 1;phase=-s.I**(int(mu==0)+int(mu==0));T[mu][which,b,anti[w[aa][0]],ghost[w[cc][0]]]+=sg*phase*coef(p,ci,gp)
 T=list(map(clean,T));assert all(t==T[0]for t in T)
 V={};AC={};keys={k[1:]for k in T[0]}
 for k in keys:
  v0=s.expand(T[0].get(('a',*k),0)-T[0].get(('B',*k),0));v1=s.expand(T[0].get(('a',*k),0)-T[0].get(('C',*k),0))
  if v0:V[k]=v0
  if v1:AC[k]=v1
 expectedV={tuple(z[:3]):scalar(z[3])for z in old[probe+1]['current']['V']};expectedAC={tuple(z[:3]):scalar(z[3])for z in old[probe+1]['current']['AC']};dv=clean({k:V.get(k,0)-expectedV.get(k,0)for k in set(V)|set(expectedV)});da=clean({k:AC.get(k,0)-expectedAC.get(k,0)for k in set(AC)|set(expectedAC)})
 pre={'probe':probe,'actualV':[[*k,str(v)]for k,v in sorted(V.items())],'actualAC':[[*k,str(v)]for k,v in sorted(AC.items())],'V_residual':[[*k,str(v)]for k,v in sorted(dv.items())],'AC_residual':[[*k,str(v)]for k,v in sorted(da.items())]}
 with(O/(f'current_dependency_probe{probe}_precheck.json')).open('xb')as f:f.write((json.dumps(pre,sort_keys=True)+'\n').encode())
 assert not dv and not da,('INHERITED_GHOST_CURRENT_DEPENDENCY',probe,len(dv),len(da));current_checks.append({'probe':probe,'actual_V_positions':len(V),'actual_AC_positions':len(AC),'four_Lorentz_components_and_all_ghost_color_zeros_checked':True})
inp=read(O/'assembly_inputs.json');bos=load(O/'color_primary_tables.json.gz');gh=load(Path(inp['ghost_tables']));results=[]
for bz,gz in zip(bos['results'],gh['results']):
 probe=bz['probe'];assert probe==gz['probe'];TV=dec(gz['UV_angular_V_tensor']);TA=dec(gz['UV_angular_AC_tensor']);GF=dec(gz['full_nonexceptional_bubble_coefficient_F']);assert not(TV-TA/2-GF).applyfunc(s.expand).todok();base={(q['m'],q['D_power']):dec(q['F'])for q in bz['total_F_m_D_coefficients']};combined=dict(base);combined[2,-1]=base[2,-1]+2*TA;combined[2,0]=base[2,0]+TV-TA
 # Independent coordinate addition of the same once-owned ghost tensor.
 for(m,p),M in combined.items():
  gg=2*TA if(m,p)==(2,-1)else TV-TA if(m,p)==(2,0)else s.zeros(45,328);left=base[m,p].todok();right=gg.todok();coords=clean({k:left.get(k,0)+right.get(k,0)for k in set(left)|set(right)});assert enc(M)==enc(s.SparseMatrix(45,328,coords))
 F4={m:sum((combined[m,p]*s.Rational(4)**p for p in[-1,0,1]),s.zeros(45,328)).applyfunc(s.expand)for m in[2,3,4]};pole=sum(F4.values(),s.zeros(45,328)).applyfunc(s.expand);epsjet=sum((combined[m,-1]/8-2*combined[m,1]for m in[2,3,4]),s.zeros(45,328)).applyfunc(s.expand);logs={2:(-2*F4[2]-F4[3]-3*F4[4]).applyfunc(s.expand),3:(-F4[3]).applyfunc(s.expand)};degree=defaultdict(int)
 for M in F4.values():
  for value in M.todok().values():
   for powers,co in s.Poly(value,g,xi,eta).terms():degree[','.join(map(str,powers))]+=1
 controls={'omit_or_duplicate_ghost_changes_D4_positions':len(GF.todok()),'swap_log6_log8_changes_prime_log_positions':sum(len(M.todok())for M in[(F4[3]-F4[4]).applyfunc(s.expand),(-F4[3]+F4[4]).applyfunc(s.expand)])}
 results.append({'probe':probe,'complete_F_m_D_coefficients':[{'m':m,'D_power':p,'F':enc(M)}for(m,p),M in sorted(combined.items())],'F_m_at_D4':{str(m):enc(M)for m,M in F4.items()},'complete_unheated_angular_UV_F_at_D4':enc(pole),'epsilon_numerator_jet_not_complete_DIM_finite':enc(epsjet),'complete_heat_minus_single_prime_logs':{str(p):enc(M)for p,M in logs.items()},'retained_g10_xi_eta_monomial_position_counts':dict(degree),'controls':controls})
out={'schema':'IBK4_COMPLETE_BX_BOSON_GHOST_RELATIVE_HEAT_ASSEMBLY','elapsed_after_imports':time.perf_counter()-tick,'actual_probe_ghost_current_dependency_checks':current_checks,'each_ghost_owner_added_exactly_once':True,'matrix_vs_coordinate_assembly_all_positions_agree':True,'results':results,'complete_ordinary_Bx_relative_HEAT_minus_SINGLE':True,'DIM_minus_HEAT_or_Slavnov_restoration_QAP_E5_A5_authority':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'complete_Bx_relative_heat.json.gz').open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':out['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'F4_nonzero':[[len(z['F_m_at_D4'][str(m)]['entries'])for m in[2,3,4]]for z in results],'UV_angular_total_nonzero':[len(z['complete_unheated_angular_UV_F_at_D4']['entries'])for z in results],'prime_log_nonzero':[[len(z['complete_heat_minus_single_prime_logs'][str(p)]['entries'])for p in[2,3]]for z in results],'full_DIM_or_E5_A5_authority':False},sort_keys=True),flush=True);timer.cancel()
