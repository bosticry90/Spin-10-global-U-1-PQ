from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-bosonic-kinetic-v1-2026-10-25');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'cartesian_preparation.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 assert read(O/'cartesian_receipt.json')['all_D3_D4_D5_parallel_transverse_and_probe_choices_agree']
 for n in ['cartesian_preparation.json','cartesian_receipt.json','cartesian_capture.json']:p=O/n;b[str(p)]=H(p)
 for n in ['COLOR_RECORD.md','color.py','verify_color.py','run_color.py']:
  p=O/n
  with(O/(n+'.source.txt')).open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(p)
 dump(O/'color_preparation.json',{'input_sha256':b,'worker_seconds_after_imports':300,'verifier_seconds_after_imports':180,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':24*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
 for role in ['primary','replay','verify']:
  if role=='verify':
   for n in ['color_preparation.json']+['color_'+r+'_'+z+'.json'+('.gz'if z=='tables'else'')for r in ['primary','replay']for z in ['tables','result','capture']]:p=O/n;b[str(p)]=H(p)
   dump(O/'color_validation_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
  cmd=[sys.executable,'-B',str(O/('verify_color.py'if role=='verify'else'color.py'))]+([]if role=='verify'else[role]);z=capture(cmd);dump(O/('color_'+role+'_capture.json'),z);dump(C/('color_'+role+'_full_capture.json'),z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified']and z['launch']['memory']['available_pagefile']>=350*1024**2 and max(x['private_bytes']for x in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(x[7:])for x in z['stdout_and_stderr'].splitlines()if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<(180 if role=='verify'else 300);dump(O/('color_validation_receipt.json'if role=='verify'else'color_'+role+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<24*1024**2;print('COMPLETED_IBK3_COLOR',role,rr[0]['elapsed_after_imports'],flush=True)
except BaseException:
 dump(O/'color_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
