from pathlib import Path
from hashlib import sha256
import ast,json,sys,subprocess,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-bosonic-kinetic-v1-2026-10-25');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'color_validation_preparation.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 for n in ['color_validation_preparation.json','color_validation_receipt.json','color_verify_capture.json']:p=O/n;b[str(p)]=H(p)
 G=O.parent/'canonical_so10_intrinsic_kinetic_firstjet';V=O.parent/'canonical_so10_probe_ghost_vector_vertices';gt=G/'ghost_primary_tables.json.gz';ct=V/'primary_v2_tables.json.gz'
 for p in [gt,G/'ghost_validation_receipt.json',G/'GHOST_DERIVATION.md',ct,V/'validation_receipt_v2.json']:
  assert p.read_bytes()==subprocess.check_output(['git','show','HEAD:'+p.relative_to(R).as_posix()],cwd=R);b[str(p)]=H(p)
 assert read(G/'ghost_validation_receipt.json')['literal_density_vs_Euler_then_congruence_and_color_vs_matrix_trace_routes_agree']
 dump(O/'assembly_inputs.json',{'ghost_tables':str(gt),'classical_vertex_tables':str(ct),'scientific_acceptance':'NOT_PERFORMED'});b[str(O/'assembly_inputs.json')]=H(O/'assembly_inputs.json')
 for n in ['ASSEMBLY_RECORD.md','assembly.py','run_assembly.py']:
  p=O/n
  with(O/(n+'.source.txt')).open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
  b[str(p)]=H(p);b[str(O/(n+'.source.txt'))]=H(p)
 dump(O/'assembly_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
 z=capture([sys.executable,'-B',str(O/'assembly.py')]);dump(O/'assembly_capture.json',z);dump(C/'assembly_full_capture.json',z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified']and z['launch']['memory']['available_pagefile']>=350*1024**2 and max(x['private_bytes']for x in z['all_resource_samples'])<=8*1024**3
 rr=[json.loads(x[7:])for x in z['stdout_and_stderr'].splitlines()if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<180;dump(O/'assembly_receipt.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<24*1024**2;print('COMPLETED_IBK4_ASSEMBLY',rr[0]['elapsed_after_imports'],flush=True)
except BaseException:
 dump(O/'assembly_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
