from pathlib import Path
from hashlib import sha256
from itertools import product
from collections import defaultdict
import gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'kernel_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
wa,wb,pa,pb,na,nb,ra,rb,z,h,n0,n1,r0,r1,D,t=s.symbols('wa wb pa pb na nb ra rb z h n0 n1 r0 r1 D t');I=s.I;n=s.Matrix([1,0]);zero=lambda m:s.zeros(m);expand=lambda v:s.expand(v);tidy=lambda v:s.factor(s.cancel(v));F=s.Rational
def arcs(mode,scalar=False):
 colors=1 if scalar else 2;ns=[s.Matrix([n0,n1])]if scalar else[s.Matrix([na]),s.Matrix([nb])];scalars=2 if scalar else 1;dim=3*colors+scalars;Bix=lambda a:[2*a,2*a+1];Lix=lambda a:2*colors+a;Xix=list(range(3*colors,dim));weights=[wa,wb];probes=[pa,pb];e=s.Matrix([1,0]if mode=='parallel'else[0,1]);v=n+t*e;Q=(v.T*v)[0]
 out={};graded=[(0,0,1),(0,1,2),(1,0,2),(1,1,2),(1,1,3)]
 for key in graded:
  A=s.zeros(dim);dA=s.zeros(dim)
  for a in range(colors):
   w,p,N=weights[a],probes[a],ns[a];bi=Bix(a);li=Lix(a)
   if key==(0,0,1):BB=s.eye(2)/Q+(w-1)*v*v.T/Q**2;BL=-v/Q;LB=v/Q;LL=0
   elif key==(0,1,2):BB=w*w*p*v*v.T/(2*Q**2);BL=-w*p*v/Q;LB=w*p*v/Q;LL=-2*p
   else:BB=s.zeros(2);BL=s.zeros(2,1);LB=s.zeros(2,1);LL=0
   for i in range(2):
    for j in range(2):A[bi[i],bi[j]]=BB[i,j]
    A[bi[i],li]=BL[i];A[li,bi[i]]=LB[i]
   A[li,li]=LL
   if key[0]:
    fac=1 if key==(1,0,2)else-w*p if key==(1,1,2)else w*p;lfac=0 if key==(1,0,2)else-2*p if key==(1,1,2)else 2*p
    for j,xj in enumerate(Xix):
     for i in range(2):A[bi[i],xj]=fac*N[j]*v[i]/Q**2;A[xj,bi[i]]=-fac*N[j]*v[i]/Q**2
     A[li,xj]=lfac*N[j]/Q;A[xj,li]=lfac*N[j]/Q
  if key==(0,0,1):
   for xj in Xix:A[xj,xj]=1/Q
  if role=='replay':base=A.subs(t,0);der=A.diff(t).subs(t,0)
  else:
   base=A.subs(t,0);der=s.zeros(dim);parallel=int(mode=='parallel')
   for a in range(colors):
    w,p,N=weights[a],probes[a],ns[a];bi=Bix(a);li=Lix(a)
    if key==(0,0,1):bb=-2*base.extract(bi,bi)if parallel else(w-1)*(e*n.T+n*e.T);bl=n if parallel else-e;lb=-n if parallel else e
    elif key==(0,1,2):bb=-2*base.extract(bi,bi)if parallel else w*w*p*(e*n.T+n*e.T)/2;bl=w*p*n if parallel else-w*p*e;lb=-w*p*n if parallel else w*p*e
    else:bb=s.zeros(2);bl=s.zeros(2,1);lb=s.zeros(2,1)
    for i in range(2):
     for j in range(2):der[bi[i],bi[j]]=bb[i,j]
     der[bi[i],li]=bl[i];der[li,bi[i]]=lb[i]
    if key[0]:
     fac=1 if key==(1,0,2)else-w*p if key==(1,1,2)else w*p;lfac=0 if key==(1,0,2)else-2*p if key==(1,1,2)else 2*p
     for j,xj in enumerate(Xix):
      for i in range(2):der[bi[i],xj]=fac*N[j]*(-3*n[i]if parallel else e[i]);der[xj,bi[i]]=-der[bi[i],xj]
      der[li,xj]=-2*lfac*N[j]if parallel else 0;der[xj,li]=der[li,xj]
   if key==(0,0,1)and parallel:
    for xj in Xix:der[xj,xj]=-2
  out[key]=(base,der)
 return out,e,Bix,Lix,Xix,dim
def trace4(A,B,C,X):
 if role=='primary':return s.trace(A*B*C*X)
 aa={(i,j):v for(i,j),v in s.SparseMatrix(A).todok().items()};bb=defaultdict(list);cc=defaultdict(list);xx={}
 for(j,k),v in s.SparseMatrix(B).todok().items():bb[j].append((k,v))
 for(k,l),v in s.SparseMatrix(C).todok().items():cc[k].append((l,v))
 for(l,i),v in s.SparseMatrix(X).todok().items():xx[l,i]=v
 return sum((av*bv*cv*xx.get((l,i),0)for(i,j),av in aa.items()for k,bv in bb[j]for l,cv in cc[k]),s.S.Zero)
def calculate(mode,category,basis):
 scalar=category=='scalar';A,e,Bix,Lix,Xix,dim=arcs(mode,scalar);HB=s.zeros(dim);dHB=s.zeros(dim);HX=s.zeros(dim);dHX=s.zeros(dim);q=n;colors=1 if scalar else 2
 if category in ['vector','probe_vector','DX']:
  a,b=Bix(0),Bix(1)
  if basis in ['A','B','C','D','H']:
   M=(q.dot(e)*s.eye(2)if basis=='A'else q*e.T if basis=='B'else e*q.T if basis=='C'else s.zeros(2));dM=s.eye(2)if basis=='D'else e*e.T if basis=='H'else s.zeros(2)
   for i,j in product(range(2),repeat=2):HB[a[i],b[j]]=M[i,j];dHB[a[i],b[j]]=dM[i,j]
  elif basis=='LB':
   for j in range(2):HB[Lix(0),b[j]]=e[j]
  elif basis=='BL':
   for i in range(2):HB[a[i],Lix(1)]=e[i]
  else:raise AssertionError(basis)
 if category=='scalar':
  C=s.Matrix([[0,h],[-h,0]])
  for i,j in product(range(2),repeat=2):HB[Xix[i],Xix[j]]=2*I*q.dot(e)*C[i,j];dHB[Xix[i],Xix[j]]=I*C[i,j]
 if category=='DB':
  for i in range(2):HB[Bix(0)[i],Xix[0]]=z*e[i];HB[Xix[0],Bix(0)[i]]=z*e[i]
 if category=='DX':
  for i in range(2):HX[Bix(1)[i],Bix(0)[i]]=z
 else:
  rr=[s.Matrix([r0,r1])]if scalar else[s.Matrix([ra]),s.Matrix([rb])]
  for a in range(colors):
   for j,xj in enumerate(Xix):
    for i in range(2):HX[Bix(a)[i],xj]=-I*q[i]*rr[a][j];HX[xj,Bix(a)[i]]=I*q[i]*rr[a][j];dHX[Bix(a)[i],xj]=I*e[i]*rr[a][j];dHX[xj,Bix(a)[i]]=2*I*e[i]*rr[a][j]
 gradeB=(0,1)if category=='probe_vector'else(1,1)if category=='DB'else(0,0);gradeX=(1,1)if category=='DX'else(0,0);out=defaultdict(lambda:0)
 for ka,kb in product(A,repeat=2):
  if tuple(ka[i]+kb[i]+gradeB[i]+gradeX[i]for i in range(2))!=(1,1):continue
  G,dG=A[ka];J,dJ=A[kb];m=ka[2]+kb[2];value=-(trace4(G,dHB,J,HX)+trace4(G,HB,dJ,HX)+trace4(G,HB,J,dHX))/2;out[m]+=value
 # D-2 spectator directions only in closed vector DX case.
 spectator={}
 if category=='DX'and basis in ['A','D']:
  spectator[2]=-z*((1 if basis=='D'else 0)-2*(1 if basis=='A'and mode=='parallel'else 0))/2
 for m in out:out[m]=s.expand(out[m]+(D-2)*spectator.get(m,0))
 return dict(out)
cases=[]
for category in ['vector','probe_vector','scalar','DX','DB']:
 for basis in (['A','B','C','D','H','LB','BL']if category in ['vector','probe_vector','DX']else['one']):
  P=calculate('parallel',category,basis);T=calculate('transverse',category,basis);rows=[]
  for m in sorted(set(P)|set(T)):
   value=tidy((P.get(m,0)+(D-1)*T.get(m,0))/D)
   if category in ['vector','probe_vector']:
    ab=tidy(s.expand(value).coeff(na,1).coeff(rb,1));ba=tidy(s.expand(value).coeff(nb,1).coeff(ra,1));assert s.expand(value-ab*na*rb-ba*nb*ra)==0;parts={'na_Rb':ab,'nb_Ra':ba}
   elif category=='scalar':
    c=tidy(s.expand(value).coeff(n0,1).coeff(r1,1).coeff(h,1));assert s.expand(value-c*h*(n0*r1-n1*r0))==0;parts={'n_Rc_Ra':c}
   elif category=='DX':c=tidy(value/z);assert s.expand(value-c*z)==0;parts={'D_ab':c}
   else:c=tidy(s.expand(value).coeff(z,1).coeff(ra,1));assert s.expand(value-c*z*ra)==0;parts={'D_ac_Ra':c}
   rows.append({'m':m,'coefficients':{k:str(v)for k,v in parts.items()},'parallel':str(s.factor(P.get(m,0))),'transverse':str(s.factor(T.get(m,0)))})
  cases.append({'category':category,'basis':basis,'rows':rows})
  print('STAGE_IBK2',role,category,basis,flush=True)
out={'schema':'IBK2_COMPLETE_BOSONIC_ANGULAR_FIRSTJET_KERNELS','role':role,'cases':cases,'normalization':'minus_onehalf_trace_G_HB_G_HX; unstripped_Fourier_coefficient','sphere_rule':'(parallel+(D-1)*transverse)/D','Dminus2_spectator_vector_trace_retained':True,'actual_color_coefficients_or_DIM_matching_calculated':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('kernel_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'cases':len(cases)},sort_keys=True),flush=True);timer.cancel()
