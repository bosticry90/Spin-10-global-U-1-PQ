from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-bosonic-kinetic-v1-2026-10-25');stage=sys.argv[1];assert stage in ['heat_kernel','heat_color'];sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 prior='assembly'if stage=='heat_kernel'else'heat_kernel';b=dict(read(O/(prior+'_preparation.json'))['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 names=['DIM_RECORD.md','kernels.py','color.py','heat_kernels.py','verify_heat.py','run_heat.py','run_heat_v2.py','DIM_PRELAUNCH_REPAIR.md']
 if stage=='heat_color':names+=['heat_color.py','heat_kernel_preparation.json','heat_kernel_validation_preparation.json','heat_kernel_validation_receipt.json']+['heat_kernel_'+r+'_'+z+'.json'+('.gz'if z=='tables'else'')for r in ['primary','replay']for z in ['tables','result','capture']]
 else:names+=['assembly_preparation.json','assembly_receipt.json','assembly_capture.json','complete_Bx_relative_heat.json.gz']
 for n in names:
  p=O/n;b[str(p)]=H(p)
  if p.suffix in ['.py','.md']:
   cp=O/(n+'.source.txt')
   if not cp.exists():
    with cp.open('xb')as f:f.write(p.read_bytes())
   assert cp.read_bytes()==p.read_bytes();b[str(cp)]=H(cp)
  if p.suffix=='.py':ast.parse(p.read_bytes())
 bs=R/'calculations/canonical_so10_bosonic_source_onejet_finite'
 for n in ['DERIVATION.md','RESULT.md','primary_v2.py','validation_receipt.json']:
  p=bs/n;b[str(p)]=H(p)
 dump(O/(stage+'_preparation.json'),{'input_sha256':b,'worker_seconds_after_imports':300,'verifier_seconds_after_imports':180,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':24*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
 for role in ['primary','replay','verify']:
  if role=='verify':
   for n in [stage+'_preparation.json']+[stage+'_'+r+'_'+z+'.json'+('.gz'if z=='tables'else'')for r in ['primary','replay']for z in ['tables','result','capture']]:p=O/n;b[str(p)]=H(p)
   dump(O/(stage+'_validation_preparation.json'),{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
  cmd=[sys.executable,'-B',str(O/('verify_heat.py'if role=='verify'else'heat_kernels.py'if stage=='heat_kernel'else'heat_color.py')),stage if role=='verify'else role];z=capture(cmd);dump(O/(stage+'_'+role+'_capture.json'),z);dump(C/(stage+'_'+role+'_full_capture.json'),z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified']and z['launch']['memory']['available_pagefile']>=350*1024**2 and max(x['private_bytes']for x in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(x[7:])for x in z['stdout_and_stderr'].splitlines()if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<(180 if role=='verify'else 300);dump(O/(stage+'_validation_receipt.json'if role=='verify'else stage+'_'+role+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<24*1024**2;print('COMPLETED_IBK5',stage,role,rr[0]['elapsed_after_imports'],flush=True)
except BaseException:
 dump(O/(stage+'_v2_controller_failure.json'),{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
