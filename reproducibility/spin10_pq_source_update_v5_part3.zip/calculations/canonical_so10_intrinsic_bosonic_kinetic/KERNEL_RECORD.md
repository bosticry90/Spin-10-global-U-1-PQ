# IBK2: complete bosonic angular first-jet kernels before color contraction

Freeze after IBK1 vertex P/R/verifier terminal completion. Reuse its full
q/p vertex, not the old constant-external-momentum table without orientation
correction. Question: compute every bosonic bubble's angular first-jet
coefficient at each strict-heat edge length, retaining analytic Lorentz D.

Use q=n unit and external B polarization along p=e. A first-jet scalar
has form A(n.e)^2+B(1-(n.e)^2); its D-sphere average is
[A_parallel+(D-1)A_transverse]/D. Compute the q/e two-plane exactly and
retain D-2 spectator vector directions. Only the D_ab scalar vertex with
two vector lines has a closed spectator trace; mixed scalar endpoints
force other Lorentz indices into the q/e plane. This structural proof,
not finite-D interpolation, supplies the D dependence. Check against full
Cartesian D3/4/5 witnesses where meaningful, without selecting physical inputs.

State types are B_a,B_b,Lambda_a,Lambda_b,x. Free Green retains transverse
BB, longitudinal width w, BL=-n,LB=+n and scalar1. Actual compact probe
response per color: Gu_BB=w²P nn/2,Gu_BL=-wP n,Gu_LB=wP n,Gu_LL=-2P.
Gn_Bx=n_a n_mu,Gn_xB=-n_a n_mu. Mixed nu direct E² block has
Bx=-wP n_a n_mu,xB=+wP n_a n_mu,Lx=xL=-2P n_a; the E³ block is its
negative. Restore q powers according to their homogeneous degrees before
momentum differentiation. These follow from actual IBK1 quadratic identities
and the inherited full-symbol longitudinal U proof, not fitted loop data.

Calculate all first-jet terms from minusonehalf Tr(Gbar HB Gbar HX), at
nu order, distinguishing: (1) marginal gauge/aux HB, (2) probe gauge/aux
HB, (3) physical scalar-current HBxx, (4) new D with externalx/internalBB,
(5) same D with externalB/internalBx. Keep each E^m separately. Color
structures n_a^T R_b x and n_b^T R_a x remain distinct; do not commute
generators or merge unequal widths. Scalar HBxx yields n_a^T R_c R_a x.

Primary uses matrix product-rule traces and explicit Green first jets.
Replay differentiates the full rational Green at q+p, then sums closed
indices. Verify complete coefficient polynomials, not a favorable scalar
example. Check actual scalar-current momentum signs from IBK1 and both
new D placements. Controls remove Gu_LL, transpose only one mixed endpoint,
omit external vertex momentum derivatives, and average widths; a zero
control must be classified insensitive rather than claimed discriminating.

Two sequential300s workers,180s verifier,8GiB sampled private,350MiB launch
floor,24MiB packet as prospectively frozen in RECORD. Freeze sources/copies,
input receipts and actual parameters first. Preserve all failed versions.
This stage computes complete Lorentz kernels, not yet the model color
coefficients or full DIM-minus-heat/QAP/E5/A5. No quantum comparator is read.
