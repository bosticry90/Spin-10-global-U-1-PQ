# The complete selected Bx finite conversion is measured

October25,2026; base e24d9b9d. Bounded derivation/calculation qualified in
the declared formal Euclidean domain; director acceptance NOT_PERFORMED.
State113/authority34of39 and E5/A5 OPEN remain unchanged. No physical
benchmark, scheme, scalar shift or counterterm is installed.

## Result and scope

The ordinary one-loop coefficient with one intrinsic GF reference grade,
constant firstu, external B(-p),x(+p), and one external momentum jet has now
been calculated for both probes, all45 vector/auxiliary and328 scalar
coordinates. The previous IKG ghost result is included exactly once after
the independently measured bosonic result. This closes the selected Bx
coefficient class, not its full Slavnov variation or the complete Euler
conversion. Original unshifted SMA/CSW/EDS,A0,symbolic g10,xi,eta_H remain.

Let F_m(D) denote the full angular coefficient with heat length2m. Let H_m
be the strict positive heat-factor derivative finite term at D4, and
J=-2 partial_D sum_m F_m(D)|4. In units u*i p.B*x/(16pi^2), at the declared
intrinsic grade, the complete selected conversion is

    C_DIM-heat = chi4 P + log(3/2) F3(4) + log2 F4(4) + J-H,
    P=F2(4)+F3(4)+F4(4), H=sum_m H_m(4).

The existing qualified BSF1 raw-DIM/heat rule is applied, not a newly chosen
physical subtraction scheme. chi4=1+log(16pi)-n_log remains symbolic.
It is not identified with kappa or b0, and is not fitted to a cancellation.
The local relative comparison retains the inherited common nonexceptional
UV-jet/IR completion; no isolated scaleless p0 physical trace is integrated.

Probe0 vanishes in every retained family. Probe1 has320 nonzero positions
in each of the chi4,log2,log3 and fixed bases. These are algebraic coordinate
positions, not independent interactions or particles. Complete zero
complements are retained in complete_Bx_DIM_minus_heat.json.gz.

For B12,x206, a simple witness is

    2sqrt6 g10^2 xi^2 chi4
    +(29sqrt6/16)g10^3 xi^2 log(3/4)
    +(17sqrt6/192)g10^3 xi^2.

The fixed finite term is nonzero. Keeping only pole/log coefficients would
miss it. The g10^2 ghost and g10^3 bosonic terms are kept separately: a fresh
literal QG current check confirms the inherited probe ghost current has a
different coupling degree from its BBB current. No coupling is inserted
to make them agree. This ordinary-functional result is not an anomaly test.

## Action inputs and independent checks

IBK1 reconstructs the complete classical three-vector first jet. The old
constant-leg tables use integrated momenta +q,-q; the current h(-q),k(q+p)
routing instead requires -P_ab;c(q)+P_bc;a(p), with Lorentz permutations.
Direct full QG density and Bose/table reconstruction agree at every Lorentz
component. Probe1 qB/qC,pA/pC each have668 positions, pB and qA zero.
Omitting external vertex derivatives or reversing the internal q orientation
changes1336 tensor positions. Probe0 zero is insensitive to these controls.

The physical YM cubic is derived separately from the adopted curvature/Wick
action. Its q coefficients are (2i,-i,-i)g f and p coefficients (i,-2i,i)g f.
The scalar current and mixed Hessians follow the actual covariant kinetic
density. The two actual probe mixed identities Nr_B=2Pn and Nr_L=wPn are
freshly checked with -G0 Nr-Gr N0=0, including all zero entries. Full old
and probe auxiliary BB-Lambda tensors and both source-derived D placements
are retained. Raw GF and already canonical QG are never transported alike.

IBK2 derives23 Lorentz kernel cases. Matrix Green jets/traces agree with
rational derivatives and closed-index sums. Analytic D-2 spectator traces
are retained; this is not replacement by a two-dimensional theory. A separate
full Cartesian D3,D4,D5 review agrees on372 exact coefficients, with sensitive
auxiliary, endpoint and omitted-vertex-jet controls. The auxiliary omission
control also removes its derived inverse endpoint; omitting only one of them
would not be a consistent diagnostic.

IBK3 contracts the complete actual model: explicit color paths versus sparse
flattened ordered trace products. All974160 family/m/D-power positions agree,
including zeros. Families retain YM, old auxiliary, probe BBB/auxiliary,
scalar current n_a^T R_c R_a, D with externalx, and D with externalB.
The ordered scalar product cannot be reversed. Probe1 controls change608
prime-log positions without auxiliary terms,304 without either D placement,
296 m3 positions when scalar matrices are reversed, and640 prime-log
positions when heat lengths are collapsed. Probe0 controls are insensitive.

Bosonic F_m(4) have304/320/320 nonzero positions for m2/3/4; their sum has304.
IBK4 adds the previously qualified full ghost bubble once. A fresh literal
QG aCB projection checks its inherited V=Ua-UB and AC=Ua-UC currents in all
four Lorentz components. Probe1 V has600 positions, AC0; probe0 both0.
The complete F_m(4) then have320/320/320 positions and P has320.
The complete HEAT-minus-SINGLE prime-log tensors, also retained, have320
positions each. They are not confused with DIM-minus-heat.

## Finite heat and dimension terms

IBK5 independently calculates the positive heat term. For each ordered
bubble, differentiate the actual right-edge heat factors. The radial factor
is -2mR/m. Direct edge counting versus literal exponential differentiation
and positive radial integration agree over23 cases; replay performs71 radial
checks. Both matrix and closed-index traces are retained. The full color
contractions are repeated by the two existing distinct algorithms, with
all974160 family coefficients/zeros agreeing.

Bosonic H_m have0/320/320 nonzero positions. The late ghost heat term H2=TA/4
equals its dimension numerator jet Jghost=TA/4, as checked against the earlier
full nonexceptional reflected bubble. Consequently its conversion is chi4 F,
without adding Taylor finite pieces twice. The complete J and H each have320
positions, and their difference still has320. Dropping either loses320.

The degree-3 routing identity F_lambda(D)=F(D)+lambda(D-4)K(D), together with
H_lambda=H-2lambda K(4), makes -H-2F'_4 invariant. It is checked for all kernel
components;33 nonzero K components make the separately omitted-jet controls
sensitive. This applies within the inherited UV-jet/common-IR construction;
it does not erase a momentum-space IR delta distribution. As another exact
check, composing DIM-heat with heat-single cancels log3 and leaves -log4 P
in the log2 basis. Matrix versus disjoint coordinate final assembly agrees
on every45x328 position for both probes and all four finite bases.

## Failures, reproducibility and interpretation

All frozen source copies, manifests, complete captures, tensors and receipts
are retained. The initial heat controller requested an incorrectly versioned
old receipt filename and stopped before native launch. Its v2 controller then
ran a complete primary, but replay failed: a radial wrapper had an extra /2.
The later separately named v2 kernels remove that extra measure factor and
pass the original exact gates. A generated v3 controller also stopped before
launch on a duplicated stage label; v4 corrects it. All failed sources and
captures/classifications remain; none is called PASS. No inputs, mathematical
acceptance condition or resource limit changed. This is an implementation
failure history, not a sequence of failed physical hypotheses.

IBK1 P/R/V5.0070139/1.4626474/.0352109s; IBK2
1.7777117/2.1698488/.2027615s; Cartesian7.2208587s; IBK3
14.4652830/24.8292259/.0482031s; assembly7.3452490s; IBK5 kernels
2.1208707/3.2279770/.2132171s; heat colors3.5897671/19.0884625/.0643116s;
final review9.8940458s, all after imports. All300/180s,8GiB sampled-private,
350MiB launchfloor and24MiB packet limits held. Largest sampled native private
allocation207814656B; short-run sampling is not a continuous peak measurement.
The final external seal records exact packet bytes, source copies and hashes.

Receipt hashes and E4 authentication disposition are in V621 and the external
seal. E4 authenticates historical qualified work, not a fresh scientific replay;
historical custody remains exit2/seven NOTPASS. Protected state is unchanged.

Shared action, field charts, symbolic compiler, Python/SymPy and AI authorship
limit independence. Different algorithms and structural controls corroborate
the computation; they cannot validate shared physical assumptions, establish
external scientific replication or supply experimental evidence for Spin10.
No proof assistant, external scientist or physical matching was used.

The supplied assessment and five quantum references were already reviewed
in the IKS result/V619. Their limited methodological classification is
retained; their historical suggested fermionic companion is superseded by
later completed work. No new foundation, formal gate or monitoring automation
is adopted from them. The time-qubit preprint itself claims validation using
earlier interferometry; it still supplies no backward laboratory time result.

## Continued scientific dependency

The next smallest complete missing class is zero-jet u BBx. IBB1 has now
reduced all23497 typed words to54 ordered skeletons in bubbles/triangles,
with no actual BBx model coefficient yet extracted. Use that reduction to
derive the full Lorentz-D kernels and action-derived quartic B seagulls,
probe BB vertices, scalar mixed Bx and ghost seagulls before contraction.
Keep inverse UN orders and heat lengths through m5. Then test the common
Euler construction only with all required independently measured classes.

Full source reality, chiral products/QAP/measure/phase, varying probes and
backgrounds, massive/causal/constant-vacuum limits, failed physical benchmark,
large scalar warning, gauge matching, flavor pause and HB1/C5 remain separate
obligations. The whole investigation remains ACTIVE/INCOMPLETE.
