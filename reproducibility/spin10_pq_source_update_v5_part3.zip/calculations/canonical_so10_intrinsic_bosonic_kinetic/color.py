from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'color_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('color_'+('replay'if role=='primary'else'primary')):raise PermissionError('IBK3_PEER_DENIED')
  if p.parent.name in ['canonical_so10_intrinsic_kinetic_firstjet','canonical_so10_finite_intrinsic_scalar_source','canonical_so10_intrinsic_finite_conversion_module']:raise PermissionError('IBK3_QUANTUM_COMPARATOR_DENIED')
sys.addaudithook(guard);data=load(O/('vertex_'+role+'_inputs.json.gz'));v=load(O/('vertex_'+role+'_tables.json.gz'));kk=load(O/('kernel_'+role+'_tables.json.gz'));g,xi,eta=s.symbols('g10 xi eta_H',real=True);D,wa,wb,pa,pb=s.symbols('D wa wb pa pb');loc={'g10':g,'xi':xi,'eta_H':eta,'D':D,'wa':wa,'wb':wb,'pa':pa,'pb':pb};Z=s.S.Zero
@lru_cache(None)
def parse(z):return s.sympify(z,locals=loc)
def clean(d):
 e={k:s.expand(z)for k,z in d.items()};return{k:z for k,z in e.items()if z!=0}
dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v)for i,j,v in z['entries']});cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);tab=lambda rows:{tuple(z[:-1]):parse(z[-1])for z in rows};enc=lambda z:{'shape':[45,328],'entries':[[i,j,str(v)]for(i,j),v in sorted(clean(z).items())]};n=dec(data['quadratic']['N0'])[45:,:];R=list(map(dec,data['R']));assert len(R)==45 and all(not cl(M+M.T).todok()for M in R);ns=defaultdict(list);rs=[]
for(a,i),z in n.todok().items():ns[a].append((i,z))
for M in R:
 rows=defaultdict(list)
 for(i,j),z in M.todok().items():rows[i].append((j,z))
 rs.append(rows)
@lru_cache(None)
def NR(a,b):
 out=defaultdict(lambda:Z)
 for i,x in ns[a]:
  for j,y in rs[b][i]:out[j]+=x*y
 return clean(out)
if role=='replay':
 nrflat={}
 for b in range(45):
  M=cl(n*R[b])
  for(a,i),z in M.todok().items():nrflat[a*45+b,i]=z
 NRmatrix=s.SparseMatrix(2025,328,nrflat)
kernel={(c['category'],c['basis']):c['rows']for c in kk['cases']}
@lru_cache(None)
def coeff(expr,sa,sb,probe):
 z=s.expand((parse(expr)/s.I).subs({wa:eta if sa==0 else xi,wb:eta if sb==0 else xi,pa:int(sa==probe),pb:int(sb==probe)})*D);P=s.Poly(z,D);out=[]
 for(k,),c in P.terms():
  assert k in[0,1,2]
  if c:out.append((k-1,s.expand(c)))
 return tuple(out)
def basis(t):
 q={k:tab(t['q'][k])for k in ['A','B','C']};p={k:tab(t['p'][k])for k in ['A','B','C']};q['D']=p['A'];q['H']=clean({k:p['B'].get(k,0)+p['C'].get(k,0)for k in set(p['B'])|set(p['C'])});return q
def aux(rows):
 a=tab(rows);return{'LB':a,'BL':{(b,a,c):v for(a,b,c),v in a.items()}}
YM=basis(v['YM']);AUX0=aux(v['auxiliary_BBL'][0]);summaries=[];results=[]
for probe in range(2):
 DC=tab(data['D'][probe]['entries']);Drows=defaultdict(list)
 for(a,b,i),z in DC.items():Drows[a,b].append((i,z))
 if role=='replay':Dmatrix=s.SparseMatrix(2025,328,{(a*45+b,i):z for(a,b,i),z in DC.items()})
 group=defaultdict(lambda:defaultdict(lambda:Z));effs=[]
 for name,ms in [('YM_mixed_arcs',[3,4]),('old_aux_mixed_arcs',[3,4]),('probe_BBB',[3]),('probe_aux',[3]),('scalar_current',[3,4]),('D_external_x_YM',[2]),('D_external_x_old_aux',[2]),('D_external_B',[2])]:
  for m in ms:
   for power in[-1,0,1]:group[name,m,power]
 def tensor_group(name,category,tensors):
  eff=defaultdict(lambda:Z)
  for bb,T in tensors.items():
   for row in kernel[category,bb]:
    m=row['m']
    for tag,expression in row['coefficients'].items():
     for(a,b,c),z in T.items():
      for power,k in coeff(expression,int(a>=12),int(b>=12),probe):eff[m,power,tag,a,b,c]+=k*z
  eff=clean(eff);effs.append((name,eff))
  if role=='primary':
   for(m,power,tag,a,b,c),z in eff.items():
    if tag=='na_Rb':row=NR(a,b).items()
    elif tag=='nb_Ra':row=NR(b,a).items()
    else:row=Drows[b,a]
    for i,y in row:group[name,m,power][c,i]+=z*y
  else:
   by=defaultdict(lambda:defaultdict(lambda:Z))
   for(m,power,tag,a,b,c),z in eff.items():
    pair=a*45+b if tag=='na_Rb'else b*45+a;by[m,power][c,pair]+=z
   for(m,power),T in by.items():
    MM=cl(s.SparseMatrix(45,2025,clean(T))*(Dmatrix if category=='DX'else NRmatrix));group[name,m,power].update(MM.todok())
 tensor_group('YM_mixed_arcs','vector',YM);tensor_group('old_aux_mixed_arcs','vector',AUX0);tensor_group('probe_BBB','probe_vector',basis(v['probe_BBB'][probe]));tensor_group('probe_aux','probe_vector',aux(v['auxiliary_BBL'][probe+1]));tensor_group('D_external_x_YM','DX',YM);tensor_group('D_external_x_old_aux','DX',AUX0)
 # Scalar current: n_a^T R_c R_a, order retained.
 reversed_scalar=defaultdict(lambda:defaultdict(lambda:Z))
 for row in kernel['scalar','one']:
  m=row['m'];expression=row['coefficients']['n_Rc_Ra']
  for c in range(45):
   if role=='replay':MC=cl(n*R[c])
   for a in range(45):
    terms=coeff(expression,int(a>=12),0,probe)
    if not terms:continue
    raw=defaultdict(lambda:Z);wrong=defaultdict(lambda:Z)
    if role=='primary':
     for i,z in NR(a,c).items():
      for j,y in rs[a][i]:raw[j]+=z*y
     for i,z in NR(a,a).items():
      for j,y in rs[c][i]:wrong[j]+=z*y
    else:
     raw=(cl(MC.extract([a],list(range(328)))*R[a])).todok();raw={j:z for(i,j),z in raw.items()};wrong=cl(cl(n.extract([a],list(range(328)))*R[a])*R[c]).todok();wrong={j:z for(i,j),z in wrong.items()}
    raw=clean(raw);wrong=clean(wrong)
    for power,k in terms:
     for j,z in raw.items():group['scalar_current',m,power][c,j]+=k*z
     for j,z in wrong.items():reversed_scalar[m,power][c,j]+=k*z
 # New D externalB mixed scalar/vector Hessian.
 for row in kernel['DB','one']:
  m=row['m'];expression=row['coefficients']['D_ac_Ra']
  for a in range(45):
   terms=coeff(expression,int(a>=12),0,probe)
   if role=='primary':
    out=defaultdict(lambda:Z)
    for c in range(45):
     for i,z in Drows[a,c]:
      for j,y in rs[a][i]:out[c,j]+=z*y
    out=clean(out)
   else:out=cl(s.SparseMatrix(45,328,{(c,i):z for(aa,c,i),z in DC.items()if aa==a})*R[a]).todok()
   for power,k in terms:
    for ij,z in out.items():group['D_external_B',m,power][ij]+=k*z
 group={k:clean(z)for k,z in group.items()};total={(m,power):clean({ij:sum(z.get(ij,0)for(name,mm,pp),z in group.items()if(mm,pp)==(m,power))for ij in set().union(*(set(z)for(name,mm,pp),z in group.items()if(mm,pp)==(m,power)))})for m in[2,3,4]for power in[-1,0,1]}
 def eval4(z):
  out=defaultdict(lambda:Z)
  for power,M in z.items():
   for ij,v0 in M.items():out[ij]+=s.Rational(1,4)*v0 if power==-1 else 4*v0 if power==1 else v0
  return clean(out)
 F4={m:eval4({p:total[m,p]for p in[-1,0,1]})for m in[2,3,4]};allij=set().union(*(set(z)for z in F4.values()));pole=clean({ij:sum(F4[m].get(ij,0)for m in[2,3,4])for ij in allij});logs={2:clean({ij:-2*F4[2].get(ij,0)-F4[3].get(ij,0)-3*F4[4].get(ij,0)for ij in allij}),3:clean({ij:-F4[3].get(ij,0)for ij in allij})};epsjet=clean({ij:sum(total[m,-1].get(ij,0)/8-2*total[m,1].get(ij,0)for m in[2,3,4])for ij in set().union(*(set(z)for z in total.values()))})
 for M in group.values():assert all(s.Poly(z,g,xi,eta)is not None for z in M.values())
 def selected(names):return{m:eval4({p:clean({ij:sum(z.get(ij,0)for(name,mm,pp),z in group.items()if name in names and(mm,pp)==(m,p))for ij in set().union(*(set(z)for(name,mm,pp),z in group.items()if name in names and(mm,pp)==(m,p)))})for p in[-1,0,1]})for m in[2,3,4]}
 controls={}
 for label,names0 in [('omit_auxiliary',{'old_aux_mixed_arcs','probe_aux','D_external_x_old_aux'}),('omit_D_external_x',{'D_external_x_YM','D_external_x_old_aux'}),('omit_D_external_B',{'D_external_B'})]:
  ms=selected(names0);ss=set().union(*(set(z)for z in ms.values()));delta2=clean({ij:-2*ms[2].get(ij,0)-ms[3].get(ij,0)-3*ms[4].get(ij,0)for ij in ss});delta3=clean({ij:-ms[3].get(ij,0)for ij in ss});controls[label+'_changes_prime_log_positions']=len(delta2)+len(delta3)
 wrong3=eval4({p:clean(reversed_scalar[3,p])for p in[-1,0,1]});right3=eval4({p:group.get(('scalar_current',3,p),{})for p in[-1,0,1]});controls['reverse_scalar_Rc_Ra_changes_m3_positions']=len(clean({ij:wrong3.get(ij,0)-right3.get(ij,0)for ij in set(wrong3)|set(right3)}));controls['treat_all_heat_lengths_as_m2_changes_prime_log_positions']=len(clean({ij:logs[2].get(ij,0)+2*pole.get(ij,0)for ij in set(logs[2])|set(pole)}))+len(logs[3]);controls['drop_Lorentz_D_jet_loses_positions']=len(epsjet)
 result={'probe':probe,'families':[{'name':name,'m':m,'D_power':p,'F':enc(z)}for(name,m,p),z in sorted(group.items())],'total_F_m_D_coefficients':[{'m':m,'D_power':p,'F':enc(z)}for(m,p),z in sorted(total.items())],'F_m_at_D4':{str(m):enc(z)for m,z in F4.items()},'unheated_UV_angular_F_at_D4':enc(pole),'epsilon_numerator_jet_not_full_DIM_finite':enc(epsjet),'heat_minus_single_prime_logs':{str(p):enc(z)for p,z in logs.items()},'controls':controls};results.append(result);print('STAGE_IBK3_ACTUAL_COLOR',role,probe,[len(F4[m])for m in[2,3,4]],len(pole),flush=True)
out={'schema':'IBK3_COMPLETE_BOSONIC_BX_ANGULAR_AND_HEAT_COEFFICIENT','role':role,'results':results,'all45_by328_positions_and_zero_complements_retained':True,'source_ghost_quantum_counterterm_or_expected_translation_read':False,'relative_scope':'HEAT_MINUS_SINGLE_WITH_ANALYTIC_D_ANGULAR_JET_NOT_FULL_DIM_CONVERSION','full_QAP_source_reality_E5_A5_authority':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('color_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True);timer.cancel()
