The first heat controller stopped before manifest creation or native launch:
it requested validation_receipt_v2.json from the old BSF packet, whose
qualified receipt is actually named validation_receipt.json. Preserve
run_heat.py, its frozen source copy and heat_kernel_controller_failure.json.
This is a prelaunch dependency-name error, not a failed mathematical test.
The separate run_heat_v2.py corrects only that binding and its own controller
identity/failure filename. Same methods, scope, limits and expected evidence.
