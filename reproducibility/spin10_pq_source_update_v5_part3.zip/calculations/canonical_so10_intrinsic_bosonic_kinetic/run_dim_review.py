from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-bosonic-kinetic-v1-2026-10-25');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 b=dict(read(O/'heat_color_validation_preparation.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 for n in ['heat_color_validation_preparation.json','heat_color_validation_receipt.json','heat_color_verify_capture.json','dim_review.py','run_dim_review.py']:
  p=O/n;b[str(p)]=H(p)
  if p.suffix=='.py':
   ast.parse(p.read_bytes());cp=O/(n+'.source.txt')
   with cp.open('xb')as f:f.write(p.read_bytes())
   b[str(cp)]=H(cp)
 dump(O/'dim_review_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':24*1024**2,'scientific_acceptance':'NOT_PERFORMED'})
 z=capture([sys.executable,'-B',str(O/'dim_review.py')]);dump(O/'dim_review_capture.json',z);dump(C/'dim_review_full_capture.json',z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified']and z['launch']['memory']['available_pagefile']>=350*1024**2 and max(x['private_bytes']for x in z['all_resource_samples'])<=8*1024**3
 rr=[json.loads(x[7:])for x in z['stdout_and_stderr'].splitlines()if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<180;dump(O/'dim_review_receipt.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<24*1024**2;print('COMPLETED_IBK5_DIM_REVIEW '+json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'dim_review_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
