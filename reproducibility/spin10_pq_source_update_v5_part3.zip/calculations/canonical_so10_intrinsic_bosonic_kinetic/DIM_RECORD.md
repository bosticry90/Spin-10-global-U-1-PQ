# IBK5: complete formal DIM-minus-strict-heat Bx conversion

Freeze after IBK3/4 and literal current dependency checks completed. The
qualified BSF1 first-jet matching rule applies to the same fixed scalar
heat, raw DIM normalization, compact-nonexceptional UV jet and common IR
completion. Bind its actual derivation/receipts before applying it. No
physical finite baseline or scheme is selected.

If F_m(D) is the measured unheated angular coefficient at heat length2m,
and H_m is the strict heat positive-jet finite coefficient at D4, then

 C_DIM-heat = chi4 sum_m F_m(4)
           +log(3/2)F3(4)+log2 F4(4)
           -2 d_D sum_m F_m(D)|4 -sum_m H_m.

Here chi4=gamma_E+log4-n_log-2sigma is the ALREADY retained normalization,
sigma=d_D log(area(S^(D-1))/(2pi)^D)|4. Keep chi4 free; do not identify
it with b0,kappa,or choose it to remove a coefficient. The m2 scalar
bubble calibrates the common constant. Nonlocal/common low symbols cancel
in this local relative comparison under the inherited domain. This is
not permission to evaluate isolated scaleless or p0 physical traces.

Compute H_m independently, not infer it from the desired finite conversion.
For each ordered bubble in the IKJ routing its first heat derivative is
-4t*mR*(q.p) times the zero-p symbol. The radial finite factor is
-2mR/m. Retain every heat length, auxiliary endpoint and source vertex.
Primary uses exact resolvent arc heat count; replay differentiates the
literal heat exponential then integrates its positive radial factor.
Both independently contract finite matrices/closed indices. Reuse only
the explicitly bound qualified propagator/vertex builder functions by
AST selection into this new worker; never edit or run the old frozen
worker entry point. All changes to its trace operation are explicit here.

For arbitrary routing shift lambda the degree-3 symbol satisfies
F_lambda(D)=F(D)+lambda(D-4)K(D),
H_lambda=H-2lambda K(4), hence -H-2F'_4 is routing invariant. Check this
operator identity and sensitive omitted-jet controls; do not erase IR
delta contacts. The hatted/chiral measure sector is not included.

Contract the complete actual bosonic H_m by the two already qualified
color algorithms, using a new frozen worker and heat-kernel packet.
Only after both workers/verification pass, add the ghost H2=TA/4 exactly
once. The ghost dimension numerator jet also TA/4; check its full
nonexceptional relative coefficient is chi4*Fghost, not add Taylor pieces
again to its already reflected full-p bubble. This is a late consistency
test of a measured contribution, not its definition.

Final output: all45x328 coefficient matrices for both probes, separating
chi4,log2,log3 and the fixed finite part; preserve pole,angular-D,heat-jet
and family owners. No expected scalar translation/source Ward coefficient
is a native input. No vanishing condition is imposed on the ordinary
functional. This completes only the reference-linear firstu Bx class;
zero-jetBBx, varying probes/backgrounds, source reality and full QAP/E5
remain separate. No counterterm is installed or scientific authority raised.

New bounded stages: two300s heat-kernel workers, two300s heat-color workers,
180s verifiers/final review. Same8GiB sampled private,350MiB launchfloor,
24MiB complete packet as original prospective record. Freeze each dependent
stage's input/source/copy hashes before computation; preserve all failures.
Shared functions/action/software/AI authorship limit independence. Keep
protected state/authority34of39, main and all historical evidence unchanged.
