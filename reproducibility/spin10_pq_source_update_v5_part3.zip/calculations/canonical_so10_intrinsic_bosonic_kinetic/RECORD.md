# IBK1: full bosonic first-jet inputs and Lorentz kernels

Freeze before computation, October25,2026; base
e24d9b9d083f6ea0f1ee82601f3faec0819a2bdc. Previous goal turn PROGRESS.
Question: what complete bosonic Bx coefficient follows from the actual
action/probe vertices and IKJ ordered first-jet reduction? Complete the
missing class rather than infer it from the measured ghost coefficient.

Domain: original unshifted SMA/CSW/EDS, A0, constant firstu, exactly one
intrinsic GF-reference coefficient, external B(-p),x(+p) and first jet.
All45 gauge/auxiliary directions,328 scalars,both probes, symbolic g10,
xi,eta_H and actual coordinate charts stay. Physical cubic/mass and
higher-reference grades remain separate. No scheme/benchmark adoption.
Full kinetic conversion, source reality, QAP/measure/phase and E5/A5
are not accepted by this record. State113/authority34of39 unchanged.

Before color contraction, reconstruct complete three-vector momentum
dependence. The inherited BBB tables use first integrated momentum+q,
second-q and constant externalB. The new Hessian uses h(-q),k(q+p),B(-p).
For the local one-derivative cubic Bose functional, its full vertex is
minus P_ab;c(q) plus P_bc;a(p), with Lorentz slots permuted. Establish
this from literal QG density versus the inherited table/Bose reconstruction,
including the external-derivative terms. Preserve field Wick phases and
the actual first/second orientation. No favorable sign is inferred from
a Ward target. Add the actual physical YM cubic separately; GF alone
contains no pure YM vertex. Its sign follows the adopted F and Wick AST.

Use the full auxiliary BB-Lambda tensors, scalar current R=-g rho in its
qualified actual frame, new IKS D_ab,i, and actual N0/U/Nu/Gr. Confirm
Nr_B=2P N0_L, Nr_L=wP N0_L and all zeros before using the compact mixed
Green. Keep both endpoint adjoints. The full-symbol longitudinal-only
U proof and scalar metric/sign proof are qualified shared inputs.

Derive universal Lorentz kernels using the full n/u resolvent, keeping
each E^m heat length. Use a two-plane spanned by q and externalp; retain
the D-2 spectator trace exactly. This is an analytic Lorentz reduction,
not a two-dimensional replacement theory. All scalar/vector and reverse
mixed ports remain. Compare primary matrix traces with replay independent
closed-index sums/full Cartesian witnesses. Preserve noncommuting color
slots and both placements of D. No averaged width/charge is permitted.

Derive scalar kinetic kernels from onehalf(Dx)^T(Dx), D=partial-RB:
H_B,xx=i(2q+p).B R_c;
H_x,Bx=-i(q-p)R_a x, H_x,xB=+i(q+2p)R_a x.
Independently polarize the density to check these signs, external jets
and the real-boson half. H_Bnu,Bx=D_ac,i B_c; H_xnu,BB=D_ab,i delta.

The smallest complete class is all bosonic Bx bubbles. Seagull firstjet0
is qualified IKJ reuse. Ghost16-word tensor is reused exactly once ONLY
after the bosonic computation, as a late comparator/assembly input. Do
not give either native the ghost quantum coefficient, FIS source vector,
IFC/ISP counterterm or expected translation. Keep the complete Lorentz-D
angular/pole data and separate HEAT-minus-SINGLE from DIM-minus-heat.

Before a dependent color stage freeze its actual inputs/sources separately.
Use all actual action-derived color contractions and their zero complements.
Potential outcomes: complete bosonic coefficient, exact remainder, or
well-defined incomplete result/resource exhaustion. A selected coefficient
or compatible identity cannot substitute for complete declared coverage.

Two sequential workers300s after imports per bounded input/kernel stage,
verifier180s,8GiB sampled private,350MiB available-pagefile launchfloor,
24MiB total packet. This prospective24MiB ceiling accommodates complete
classical tensors/kernels and later color tables; no existing allowance is
altered. No dense328^3 tensor expansion is needed. Observe actual usage.
Keep failed/unfinished sources,captures and manifests exact; no silent
retry, truncation, physical input change or scientific requirement weakening.

Shared action/frames/compiler/Python/SymPy/AI author limit independence.
No agents, branch/worktree, push/publication/outreach, flavor/HB1C5
activation or scientific promotion. Preserve main and project_state.json.
