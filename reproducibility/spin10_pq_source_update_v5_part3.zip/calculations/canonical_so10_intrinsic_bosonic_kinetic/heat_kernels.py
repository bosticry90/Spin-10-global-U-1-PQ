from pathlib import Path
from hashlib import sha256
from itertools import product
from collections import defaultdict
import ast,gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h0 in read(O/'heat_kernel_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h0,p
wa,wb,pa,pb,na,nb,ra,rb,z,h,n0,n1,r0,r1,D,t=s.symbols('wa wb pa pb na nb ra rb z h n0 n1 r0 r1 D t');I=s.I;n=s.Matrix([1,0]);zero=lambda m:s.zeros(m);expand=lambda v:s.expand(v);tidy=lambda v:s.factor(s.cancel(v));F=s.Rational
# Only bound helper definitions are loaded; the old worker entry point is not run.
src=(O/'kernels.py').read_text();tree=ast.parse(src);chosen=[q for q in tree.body if isinstance(q,ast.FunctionDef)and q.name in ['arcs','trace4','calculate']];assert len(chosen)==3
pieces=[]
for q in chosen:
 text=ast.get_source_segment(src,q)
 if q.name=='calculate':
  old='value=-(trace4(G,dHB,J,HX)+trace4(G,HB,dJ,HX)+trace4(G,HB,J,dHX))/2';new='value=-trace4(G,HB,J,HX)/2*heat_factor(kb[2],m,mode)';assert text.count(old)==1;text=text.replace(old,new)
  old="spectator[2]=-z*((1 if basis=='D'else 0)-2*(1 if basis=='A'and mode=='parallel'else 0))/2";new="spectator[2]=(-z/2*heat_factor(1,2,mode) if basis=='A'and mode=='parallel'else 0)";assert text.count(old)==1;text=text.replace(old,new)
 pieces.append(text)
exec(compile('\n\n'.join(pieces),'<IBK5_bound_base_vertex_and_trace_helpers>','exec'))
kind='H';radial_checks=[]
def heat_factor(mr,m,mode):
 if mode!='parallel':return s.S.Zero
 if kind=='K':return s.S.One
 if role=='primary':return -s.Rational(2*mr,m)
 tau=s.Symbol('tau',positive=True);p=s.Symbol('p',real=True)
 jet=s.diff(s.exp(-2*tau*((m-mr)+mr*(1+p)**2)),p).subs(p,0)
 # Critical radial measure dQ/Q cancels the positive Q factor in the jet.
 value=s.integrate(jet/tau,(tau,0,s.oo))/2
 assert value==-s.Rational(2*mr,m);radial_checks.append([mr,m,str(value)]);return value
cases=[];routing_cases=[];routing_sensitive=0
ordinary=json.loads(gzip.decompress((O/('kernel_'+role+'_tables.json.gz')).read_bytes()));ordinary={(q['category'],q['basis']):q for q in ordinary['cases']}
for category in ['vector','probe_vector','scalar','DX','DB']:
 for basis in (['A','B','C','D','H','LB','BL']if category in ['vector','probe_vector','DX']else['one']):
  packed={}
  for kind in ['H','K']:
   P=calculate('parallel',category,basis);T=calculate('transverse',category,basis);rows=[]
   for m in sorted(set(P)|set(T)):
    value=tidy((P.get(m,0)+(D-1)*T.get(m,0))/D)
    if category in ['vector','probe_vector']:
     ab=tidy(s.expand(value).coeff(na,1).coeff(rb,1));ba=tidy(s.expand(value).coeff(nb,1).coeff(ra,1));assert s.expand(value-ab*na*rb-ba*nb*ra)==0;parts={'na_Rb':ab,'nb_Ra':ba}
    elif category=='scalar':
     c=tidy(s.expand(value).coeff(n0,1).coeff(r1,1).coeff(h,1));assert s.expand(value-c*h*(n0*r1-n1*r0))==0;parts={'n_Rc_Ra':c}
    elif category=='DX':c=tidy(value/z);assert s.expand(value-c*z)==0;parts={'D_ab':c}
    else:c=tidy(s.expand(value).coeff(z,1).coeff(ra,1));assert s.expand(value-c*z*ra)==0;parts={'D_ac_Ra':c}
    rows.append({'m':m,'coefficients':{k:str(v)for k,v in parts.items()},'parallel':str(s.factor(P.get(m,0))),'transverse':str(s.factor(T.get(m,0)))})
   packed[kind]=rows
  cases.append({'category':category,'basis':basis,'rows':packed['H']});routing_cases.append({'category':category,'basis':basis,'rows':packed['K']})
  # Degree -3 change-of-variable identity, checked before any actual color sum.
  lam=s.Symbol('lambda',real=True);orig={q['m']:q for q in ordinary[category,basis]['rows']};ks={q['m']:q for q in packed['K']}
  for row in packed['H']:
   m=row['m']
   for tag,v in row['coefficients'].items():
    HH=s.sympify(v);KK=s.sympify(ks[m]['coefficients'][tag]);FF=s.sympify(orig[m]['coefficients'][tag]);shiftedF=FF+lam*(D-4)*KK;shiftedH=HH.subs(D,4)-2*lam*KK.subs(D,4)
    assert tidy((-shiftedH-2*s.diff(shiftedF,D).subs(D,4))-(-HH.subs(D,4)-2*s.diff(FF,D).subs(D,4)))==0
    routing_sensitive+=int(KK.subs(D,4)!=0)
  print('STAGE_IBK5_HEAT_KERNEL',role,category,basis,flush=True)
out={'schema':'IBK5_STRICT_POSITIVE_HEAT_FIRSTJET_KERNELS','role':role,'cases':cases,'routing_K_cases':routing_cases,'routing_identity_checked':True,'omitting_heat_or_Djet_breaks_routing_in_nonzero_components':routing_sensitive,'normalization':'minus_onehalf_trace; unstripped_Fourier; positive_radial_heat_derivative','ordinary_derivative_terms_excluded_from_H':True,'Dminus2_DX_A_spectators_kept':True};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('heat_kernel_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'cases':len(cases),'literal_exponential_radial_checks':len(radial_checks),'routing_sensitive_components':routing_sensitive},sort_keys=True),flush=True);timer.cancel()
