# Prospective ordered bosonic reduction,requiring actual IRS1 receipts

Use b=(B_long,Lambda,x),the C/a ghost pair,and physical/sterile P/S.
All allowed matter vertices act on P. In the strict4D member the sterile
free block decouples only after the qualified full inverse/support check.
At this local grading an intrinsic or affine tangent forces the gauge
leg longitudinal. The original diagonal C maps preserve its Lorentz
index. No transverse gauge interaction is dropped from a surviving word.

Let A=Hb+Rb,F=Hf+Rf and B=H_bf,C=H_fb. Both B,C are odd external-P
matrices. Write J=H_ab=Cexternal*j and H_ba=-J^T. With only a ghost
current and no C_quantum vertex,the free Gaa=0 makes the ghost correction
to the bosonic Schur matrix vanish. Fermions give

    S=A-B F^-1 C,
    Gbb^(PP)=Gb B Gf C Gb,
    Gff^(PP)=Gf C Gb B Gf,
    GCb=-GCa J Gbb,
    GbC=-Gbb J^T GCa^T.

Matrix order and odd-entry trace exchanges are essential. Keep paired
momenta;K(-k)=K(k)^T,not a separately conjugated Euclidean kernel.
For k>0,after bringing epsilon*Cexternal to the left,the proposed
non-PC bosonic root is

    (1-E) Tr_b[Pi Z], Pi=H_bf Gf H_fb,
    Z=Gb W Gb,
    W=K0 Db/E-K0 mBC Gca0 j(k)-j(-k)^T(maL+u mu(k)).

Here Rb=(1-E)K0/E,mBC=i*k on the B row,maL=i on the Lambda column,
mu is the actual QG antighost tangent. Db is the full bosonic diagonal
C tangent. All signs in this prospective formula are tested against
the literal super-Gaussian,not calibrated against a Ward remainder.
The other momentum partner is constructed separately with k->-k.

Expand Gb by intrinsic n and probe u. With A0=diag(G0,I),and the actual
off-diagonal K_n,K_un and U in their418-dimensional blocks,

    G00=E A0,
    Gu=-E^2 A0 U A0,
    Gn=-E^2 A0 K_n A0,
    Gun=-E^2 A0 K_un A0
         +E^3(A0 U A0 K_n A0+A0 K_n A0 U A0).

The lower mixed block uses Nr(-k)^T. Never replace it with Nr(k)^T.
j=j00+n j01+u j10+un j11;its scalar baseline component is S0,its
probe scalar component Su. mu=mu00+n mu01. Form every coefficient of
Z at u*n,including insertions on BOTH sides and in W. Replay uses the
resolvent coefficient recurrence rather than this expanded formula.

The physical Nambu matrices A_B=C4[-ig gamma_long(PL T-PR T^T)] and
A_x=C4 PL m produce,with Gf(k)=-i gamma_long C4^-1,

    Pi_Bx=-P^T A_B Gf A_x^T P,
    Pi_xB=-P^T A_x Gf A_B^T P.

After antisymmetrizing the external spinors and retaining paired momenta,
the proposed normalized color factor is g L(T,m)/2 multiplying
Z(k)_xB-Z(-k)_xB-Z(k)_Bx+Z(-k)_Bx. This is tested with actual noncommuting
two-color matrices. In the model,proper gauge/ghost frames agree only
after their actual check. Then g L(T,m)=i B R transfers the bosonic
mass coefficient without a component charge average. The extra free
fermion heat E is retained in addition to1-E outside Z.

The physical fermion diagonal tangent is a separate calculation. Its
two spin/color endpoint factors are proposed equal rather than opposite:
both are -ig^2 L(Tc T,m)/2. The paired mixed boson inverse obeys
Gb(-k)=Gb(k)^T,so their sum cancels in the zero-ordinary-jet mass
projection. This is a proposed selected local zero,NOT a zero full
fermion determinant or chiral defect. Test it directly before using it.

The final model polynomials must have positive heat powers,endpoint
zeros and the declared finite-word support. Integrate only combined
IR-integrable expressions and retain all logarithmic periods. Strict
heat locality follows the existing nonexceptional CSW/EDS relative
remainder argument;no constant-vacuum/nonlocal/absolute-phase theorem.
Full Ward/source/contact/joint-regulator/QAP/E5/A5 claims remain separate.
