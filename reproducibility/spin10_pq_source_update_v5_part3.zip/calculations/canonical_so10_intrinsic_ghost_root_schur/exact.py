"""IRS1 bounded exact algebra, adapted from authenticated IHI/IRR arithmetic."""
from fractions import Fraction as F
import sympy as s
n,u,g,y,w,jb,jl,sb,jbu,jlu,su,db,dl,r,E=s.symbols('n u g y w jb jl sb jbu jlu su db dl r E',real=True);PARAM=(n,u,g,y,w,jb,jl,sb,jbu,jlu,su,db,dl,r,E)
Z=(F(0),F(0));ONE=(F(1),F(0));TARGET=(15,)
def cadd(a,b):return(a[0]+b[0],a[1]+b[1])
def cneg(a):return(-a[0],-a[1])
def cmul(a,b):return(a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def cfrom(z):
 a,b=s.expand(z).as_real_imag();assert a.is_Rational and b.is_Rational,(z,a,b);return(F(int(a.p),int(a.q)),F(int(b.p),int(b.q)))
def put(A,k,v):
 if v==Z:return
 v=cadd(A.get(k,Z),v)
 if v==Z:A.pop(k,None)
 else:A[k]=v
def allowed(mask):return any(mask&~t==0 for t in TARGET)
SG={(a,b):(0 if a&b else(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(5) if a&(1<<i))) for a in range(32) for b in range(32)}
def plus(A,B):
 out=dict(A)
 for k,v in B.items():put(out,k,v)
 return out
def neg(A):return{k:cneg(v) for k,v in A.items()}
def scale(A,z):
 q=cfrom(z);return{k:cmul(v,q) for k,v in A.items() if cmul(v,q)!=Z}
def times(A,B):
 out={}
 for a,x in A.items():
  for b,z in B.items():
   sg=SG[a[0],b[0]]
   if not sg:continue
   mask=a[0]|b[0]
   if not allowed(mask) or a[1]+b[1]>1 or a[2]+b[2]>1:continue
   k=(mask,)+tuple(a[i]+b[i] for i in range(1,len(PARAM)+1));v=cmul(x,z);put(out,k,v if sg==1 else cneg(v))
 return out
def poly(z,mask=0):
 out={}
 if not allowed(mask):return out
 for term in s.Add.make_args(s.expand(z)):
  pw=term.as_powers_dict();ex=tuple(int(pw.get(t,0)) for t in PARAM)
  assert all(pw.get(t,0)==e for t,e in zip(PARAM,ex)) and all(e>=0 for e in ex[:-1]),(term,ex)
  if ex[0]>1 or ex[1]>1:continue
  co=s.cancel(term/s.prod(t**e for t,e in zip(PARAM,ex)));put(out,(mask,)+ex,cfrom(co))
 return out
def expr(A,mask,ndeg=1,udeg=0):
 out=0
 for k,(a,b) in A.items():
  if k[0]==mask and k[1]==ndeg and k[2]==udeg:
   out+=(s.Rational(a.numerator,a.denominator)+s.I*s.Rational(b.numerator,b.denominator))*s.prod(t**e for t,e in zip(PARAM,k[1:]))
 return s.expand(out)
def eye(N):return{(i,i):poly(1) for i in range(N)}
def madd(A,B):
 out={k:dict(v) for k,v in A.items()}
 for k,v in B.items():
  z=plus(out.get(k,{}),v)
  if z:out[k]=z
  else:out.pop(k,None)
 return out
def mneg(A):return{k:neg(v) for k,v in A.items()}
def mscale(A,z):return{k:v for k,x in A.items() if(v:=scale(x,z))}
def mm(A,B):
 rows={}
 for(k,j),v in B.items():rows.setdefault(k,[]).append((j,v))
 out={}
 for(i,k),v in A.items():
  for j,z in rows.get(k,[]):
   q=times(v,z)
   if q:
    a=plus(out.get((i,j),{}),q)
    if a:out[i,j]=a
    else:out.pop((i,j),None)
 return out
def tr(A,parity):
 out={}
 for(i,j),v in A.items():
  if i==j:out=plus(out,scale(v,(-1)**parity[i]))
 return out
def block(A,ii,jj):
 ir={v:i for i,v in enumerate(ii)};jr={v:j for j,v in enumerate(jj)}
 return{(ir[i],jr[j]):v for(i,j),v in A.items() if i in ir and j in jr}
def join(AA,BB,CC,DD,Nb):
 out=dict(AA);out.update({(i,j+Nb):v for(i,j),v in BB.items()});out.update({(i+Nb,j):v for(i,j),v in CC.items()});out.update({(i+Nb,j+Nb):v for(i,j),v in DD.items()});return out
def from_sym(M):return{(i,j):poly(v) for i in range(M.rows) for j in range(M.cols) if(v:=M[i,j])!=0}
def scalar_matrix(z,N):return{(i,i):poly(z) for i in range(N)}
def check_graded_pairing(A,par):
 for i in range(len(par)):
  for j in range(len(par)):
   left=scale(A.get((j,i),{}),(-1)**(par[i]*(par[i]+par[j])));right=scale(A.get((i,j),{}),(-1)**par[j]);assert left==right,(i,j,left,right)

# Literal action polynomials use all quantum Grassmann variables; commuting
# quantum bosons remain symbolic until Hessian differentiation.
def ap(A,B):
 out=dict(A)
 for k,v in B.items():
  z=s.expand(out.get(k,0)+v)
  if z:out[k]=z
  else:out.pop(k,None)
 return out
def am(A,B):
 out={}
 for a,x in A.items():
  for b,z in B.items():
   if a&b:continue
   sg=(-1)**sum((b&((1<<i)-1)).bit_count() for i in range(max(a.bit_length(),1)) if a&(1<<i));k=a|b;v=s.expand(out.get(k,0)+sg*x*z)
   if v:out[k]=v
   else:out.pop(k,None)
 return out
def ax(A,z):return{k:s.expand(v*z) for k,v in A.items() if s.expand(v*z)!=0}
def ader(A,variable,right=False):
 if isinstance(variable,s.Symbol):return{k:v for k,z in A.items() if(v:=s.diff(z,variable))!=0}
 bit=1<<variable;out={}
 for mask,z in A.items():
  if mask&bit:
   cnt=(mask>>(variable+1)).bit_count() if right else(mask&(bit-1)).bit_count();out[mask^bit]=(-1)**cnt*z
 return out
def projected(A,bosons):
 out={}
 for mask,v in A.items():
  if mask>>5:continue
  z=s.expand(v.subs({t:0 for t in bosons}))
  if z:out=plus(out,poly(z,mask))
 return out
