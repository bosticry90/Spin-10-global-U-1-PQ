# IRS5: grouped dimensional/heat local limit after the full strict-heat match

Freeze after IRS4V2 MATCH_SELECTED_LOCAL_WARD,before this review. The
76-word root and independently known source/ordinary coefficients now
match in the strict4D heat member. Determine whether the grouped leading
local Ward difference has a uniform joint epsilon/heat-removal limit.
Do not claim a finite-epsilon identity merely from that four-dimensional
match. Reuse actual IGH hatted-insertion bounds instead of dropping it.

Same complete first-u,C-PP,intrinsic-grade1,unshifted,A0,physical external
ideal and compact nonexceptional Euclidean domain. Work inside the already
qualified explicit formal D-dimensional principal-symbol continuation
(SMA/EDS/IHI). No new physical dimensions,spinor multiplicity,scheme,
benchmark,subtraction baseline or foundational assumption is adopted.

Inspect ALL76 directed words. Each non-PC word must have one physical PP
free edge and one barred gauge endpoint;each PC word has no fermion free
edge. The intrinsic/current/affine structure forces the gauge leg
longitudinal. There is no closed spinor or independent vector-index trace.
Prove from the qualified split inverse/Clifford algebra that the former
open-word coefficient is alpha=barQ/Q times its strict4D value;the latter
is alpha-independent after the full G0 K0 cancellation. Keep internal
hatted denominators and actual chirality algebra. FF's zero has the same
alpha factor,so does not become a new finite-epsilon group.

Thus angular integration gives f=4/(4-2e)=2/(2-e) on the non-PC group
and ordinary mass term;source Euler and PC have no f. Verify with actual
polynomial matrices that the difference is (1-f)E*S,where S is the
independently measured SIGNED scalar-source Euler polynomial. This is a
post-calculation identity,not an assigned regulator coefficient. Compare
the full fixed power2..6 carrier and all zero complements. Retain Nc^e.

For0<=e<=1/4,c<=1,the actual source kernels have positive heat-length
differences3->4 and4->5. Their finite radial bounds and |1-f|<=4e/7
give an O(e) bound uniform in c. Add the independently qualified IGH
complete leading-local insertion O(e) and the inherited finite-word
nonexceptional remainder/local-source convergence. This yields a grouped
joint zero,not pointwise uniqueness of individual Nc^e limits or a new
absolute finite normalization. Prove the bound before numerical path tests.

One180s review,8GiBsampledprivate/350MiBfloor/16MiBpacket. Freeze proof,
code/copies and completed result/continuation bindings first. Preserve
failure. Finite-epsilon full insertion coefficient,unrestricted products,
measure/phase,causal/constant-vacuum limits,QAP/E5/A5 and physical viability
remain open. Same unchanged scientific authority and reserved boundaries.
