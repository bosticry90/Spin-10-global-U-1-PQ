import sympy as s
from exact import *

def build(side,pair,role):
 pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];gam=[s.kronecker_product(pa[1],a) for a in pa]+[s.kronecker_product(pa[0],s.eye(2))];chi=s.prod(gam);PL=(s.eye(4)+chi)/2;PR=s.eye(4)-PL;C4=gam[1]*gam[3];C=s.kronecker_product(C4,s.eye(2));T=s.Matrix([[1,2],[3,-1]]);Tc=s.Matrix([[2,1],[-1,0]]);Y=s.Matrix([[2,1],[1,3]]);assert T*Tc!=Tc*T and T*Y!=Y*T and Tc*Y!=Y*Tc
 Qg=s.kronecker_product(PL,T)-s.kronecker_product(PR,T.T);Qc=s.kronecker_product(PL,Tc)-s.kronecker_product(PR,Tc.T);Vx1=y*s.kronecker_product(s.eye(4),Y);Vx2=s.I*y*s.kronecker_product(chi,Y);Vb=-s.I*g*s.kronecker_product(gam[3],s.eye(2))*Qg;L=PL if side=='left' else PR;basis=L.columnspace();ei=s.eye(2)[:,pair[0]];ej=s.eye(2)[:,pair[1]];a=s.kronecker_product(basis[0],ei);b=s.kronecker_product(basis[1],ej);ext=[ap(ax({4:1},a[i]),ax({8:1},b[i])) for i in range(8)];eps={1:1};cext={2:1};bos=list(s.symbols('Bplus Lplus X1plus X2plus Bminus Lminus X1minus X2minus'));names=list(map(str,bos))+['Cplus','Cminus','aplus','aminus']+[f'{q}{sg}{i}' for q in ['P','S'] for sg in ['plus','minus'] for i in range(8)];NN=44;par=[0]*8+[1]*36;variables=bos+list(range(5,41));fields=[{0:v} for v in bos]+[{1<<j:1} for j in range(5,41)];ix={n:i for i,n in enumerate(names)};fv=lambda n:fields[ix[n]]
 def term(seq,co=1):
  out={0:s.sympify(co)}
  for v in seq:out=am(out,v)
  return out
 def bil(ll,K,rr):
  out={}
  for i in range(len(ll)):
   for j in range(len(rr)):
    if K[i,j]:out=ap(out,term([ll[i],rr[j]],K[i,j]))
  return out
 K=s.Matrix([[0,1],[-1,w]]);U=s.Matrix([[-2,w],[-w,w*w/2]]);S0=bil([fv('Bminus'),fv('Lminus')],K,[fv('Bplus'),fv('Lplus')]);VV=ax(bil([fv('Bminus'),fv('Lminus')],U,[fv('Bplus'),fv('Lplus')]),u)
 for label in ['X1','X2']:S0=ap(S0,term([fv(label+'minus'),fv(label+'plus')]))
 S0=ap(S0,ap(term([fv('aminus'),fv('Cplus')]),term([fv('aplus'),fv('Cminus')])))
 for label in ['P','S']:S0=ap(S0,bil([fv(label+'minus'+str(i)) for i in range(8)],s.I*C*s.kronecker_product(gam[3],s.eye(2)),[fv(label+'plus'+str(i)) for i in range(8)]))
 for sig in ['plus','minus']:
  other='minus' if sig=='plus' else'plus';sg=1 if sig=='plus' else-1;VV=ap(VV,term([fv('L'+other),fv('X2'+sig)],s.I*n));VV=ap(VV,term([fv('B'+other),fv('X2'+sig)],2*s.I*sg*u*n));VV=ap(VV,term([fv('L'+other),fv('X2'+sig)],s.I*u*w*n))
  current=ap(ap(ax(fv('B'+sig),sg*(jb+u*jbu)),ax(fv('L'+sig),jl+u*jlu)),ax(fv('X2'+sig),n*(sb+u*su)));VV=ap(VV,term([fv('a'+other),cext,current]))
  for label,V in [('B',Vb),('X1',Vx1),('X2',Vx2)]:VV=ap(VV,term([fv(label+other),bil(ext,C*V,[fv('P'+sig+str(i)) for i in range(8)])]))
 def hess(A):
  out={}
  for i in range(NN):
   first=ader(A,variables[i],right=role=='replay')
   if not first:continue
   for j in range(NN):
    val=projected(ader(first,variables[j],right=role=='replay'),bos);val=scale(val,(-1)**par[i] if role=='replay' else(-1)**(par[j]*(par[i]+1)))
    if val:out[i,j]=val
  return out
 HH=hess(ap(S0,VV));H0=hess(S0);check_graded_pairing(HH,par);K0=s.SparseMatrix(NN,NN,lambda i,j:expr(H0.get((i,j),{}),0,0,0));G0=from_sym(K0.inv());assert mm(H0,G0)==mm(G0,H0)==eye(NN);groups={n:{} for n in ['BC','aL','PC','BB','LL','xx','FF','MuB','MuL','Mux']}
 def tangent(label,row,A):
  for j in range(NN):
   val=projected(ader(A,variables[j],right=True),bos)
   if val:groups[label][row,j]=val
 for sig in ['plus','minus']:
  sg=1 if sig=='plus' else-1;tangent('BC',ix['B'+sig],term([eps,fv('C'+sig)],s.I*sg));tangent('aL',ix['a'+sig],term([eps,fv('L'+sig)],s.I));tangent('BB',ix['B'+sig],term([eps,cext,fv('B'+sig)],db));tangent('LL',ix['L'+sig],term([eps,cext,fv('L'+sig)],dl));tangent('xx',ix['X1'+sig],term([eps,cext,fv('X2'+sig)],r));tangent('xx',ix['X2'+sig],term([eps,cext,fv('X1'+sig)],-r));tangent('MuB',ix['a'+sig],term([eps,fv('B'+sig)],-2*s.I*sg*u));tangent('MuL',ix['a'+sig],term([eps,fv('L'+sig)],s.I*w*u));tangent('Mux',ix['a'+sig],term([eps,fv('X2'+sig)],-2*n*u))
  for i in range(8):
   pp={};ee={}
   for j in range(8):pp=ap(pp,ax(fv('P'+sig+str(j)),Qc[i,j]));ee=ap(ee,ax(ext[j],Qc[i,j]))
   tangent('FF',ix['P'+sig+str(i)],term([eps,cext,pp],s.I*g));tangent('PC',ix['P'+sig+str(i)],term([eps,fv('C'+sig),ee],s.I*g))
 mt=s.zeros(2);mt[pair[0],pair[1]]=1;mt[pair[1],pair[0]]=1;kap=s.expand(bil(ext,s.kronecker_product(C4*L/2,mt),ext).get(12,0));assert kap!=0
 return HH,H0,G0,groups,par,kap

def predicted():
 groups={name:{} for name in ['BC','aL','BB','LL','xx','MuB','MuL','Mux']}
 for k in [1,-1]:
  K=s.diag(s.Matrix([[0,k],[-k,w]]),s.eye(2));A0=K.inv();Kn=s.zeros(4);Kn[1,3]=Kn[3,1]=s.I*n;U=s.zeros(4);U[:2,:2]=s.Matrix([[-2,k*w],[-k*w,w*w/2]]);Nr=s.zeros(4);Nr[0,3]=2*s.I*k*n;Nr[3,0]=-2*s.I*k*n;Nr[1,3]=Nr[3,1]=s.I*w*n;Gb=E*A0-E**2*A0*Kn*A0-u*E**2*A0*U*A0-u*E**2*A0*Nr*A0+u*E**3*A0*(U*A0*Kn+Kn*A0*U)*A0;j=s.Matrix([[k*(jb+u*jbu),jl+u*jlu,0,n*(sb+u*su)]]);jm=s.Matrix([[-k*(jb+u*jbu),jl+u*jlu,0,n*(sb+u*su)]]);bc=s.Matrix([s.I*k,0,0,0]);al=s.Matrix([[0,s.I,0,0]]);muB=s.Matrix([[-2*s.I*k*u,0,0,0]]);muL=s.Matrix([[0,s.I*w*u,0,0]]);mux=s.Matrix([[0,0,0,-2*n*u]]);Db=s.diag(db,0,0,0);Dl=s.diag(0,dl,0,0);Dx=s.zeros(4);Dx[2,3]=r;Dx[3,2]=-r;Ws={'BC':-K*bc*j,'aL':-jm.T*al,'BB':K*Db/E,'LL':K*Dl/E,'xx':K*Dx/E,'MuB':-jm.T*muB,'MuL':-jm.T*muL,'Mux':-jm.T*mux}
  for name,W in Ws.items():
   Z=Gb*W*Gb;groups[name][k]=[s.expand(Z[2+ii,0]-Z[0,2+ii]).coeff(n,1).coeff(u,1) for ii in range(2)]
 return {name:[s.expand(vals[1][ii]-vals[-1][ii]) for ii in range(2)] for name,vals in groups.items()}
