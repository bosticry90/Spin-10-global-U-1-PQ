from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'model_validation_preparation_v2.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('model_'+r+'_tables.json.gz')) for r in ['primary','replay']];zero_carriers=0;union_carriers=0
assert len(a['models'])==len(b['models'])==2
for am,bm in zip(a['models'],b['models']):
 for key in am:
  if key!='groups':assert am[key]==bm[key],key
 assert set(am['groups'])==set(bm['groups'])
 for name in am['groups']:
  assert set(am['groups'][name])==set(bm['groups'][name])
  for label,aa in am['groups'][name].items():
   bb=bm['groups'][name][label];assert set(aa)==set(bb)=={'heat','finite_prime_logs'}
   for part in aa:
    for carrier in set(aa[part])|set(bb[part]):
     av=aa[part].get(carrier,{'shape':[256,45],'entries':[]});bv=bb[part].get(carrier,{'shape':[256,45],'entries':[]});union_carriers+=1
     for M in [av,bv]:
      assert M['shape']==[256,45] and len({(i,j) for i,j,v in M['entries']})==len(M['entries'])
      assert all(0<=i<256 and 0<=j<45 and v!='0' for i,j,v in M['entries'])
     assert av==bv,(am['probe'],name,label,part,carrier)
     if carrier not in aa[part] or carrier not in bb[part]:assert not av['entries'] and not bv['entries'];zero_carriers+=1
assert zero_carriers==8
summaries=[];hashes=0
for m in a['models']:
 assert len(m['cross_block_checks'])==45*8;hashes+=len(m['cross_block_checks']);groups={}
 for group,maps in m['groups'].items():
  groups[group]={label:{'heat_nonzero':{ee:len(M['entries']) for ee,M in q['heat'].items()},'finite_prime_nonzero':{pp:len(M['entries']) for pp,M in q['finite_prime_logs'].items()}} for label,q in maps.items()}
 summaries.append({'probe':m['probe'],'group_counts':groups,'total_non_PC_heat_counts':{label:{ee:len(M['entries']) for ee,M in q.items()} for label,q in m['total_non_PC_heat'].items()},'wrong_lower_Nr_transpose_changes_positions':m['wrong_lower_Nr_transpose_changes_positions']})
out={'schema':'IRS2_MODEL_VALIDATION_V2','explicit_zero_carriers_compared_to_omitted_zeros':zero_carriers,'union_typed_carriers_checked':union_carriers,'elapsed_after_imports':time.perf_counter()-tick,'explicit_graded_inverse_vs_resolvent_recurrence_agree':True,'scalar_covariance_vs_direct_noncommuting_fermion_color_sewing_agree':True,'full_cross_block_kernel_hashes_compared':hashes,'full_cross_block_positions_per_power':328*45,'all_scalar_source_and_mass_polynomial_zero_complements_compared':True,'formal_anti_programs_calculated_separately':True,'models':summaries,'full_PC_assembly_Ward_contact_QAP_authority':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
