# Prospective grouped limit,requiring the IRS5 receipt

Every non-PC word has one PP Green edge and one physical gauge vertex.
The former is -i bar_slash/Q in the qualified FULL split inverse. The
barred gauge vertex contracts the intrinsic longitudinal momentum. Their
only open scalar spin structure is barQ/Q=alpha. No sterile endpoint
exists in these words;the independent hatted insertion has not been
discarded. Color/source matrices do not change this unique Lorentz rank.
The finite strict-heat noncommuting normalization fixes its coefficient.
Every PC word has no free fermion edge after G0 K0=1 and therefore no
alpha. This is the same declared full-D symbol continuation used by EDS2
and IHI2,not an extrapolation of a4x4 gamma5 representation.

Gaussian/angular contraction in d=4-2e gives <alpha>=2/(2-e)=f.
No closed vector or spinor trace contributes an additional d factor:
the intrinsic mixing/probe response or affine divergence forces each
gauge contraction onto k_mu,while diagonal-C maps preserve the Lorentz
index. FF's strict kernel cancels between paired momenta before any
angle integration;its common alpha leaves that zero intact.

Write the actually measured strict local polynomials as O (ordinary
fermion variation),S (signed scalar-source Euler),N (non-PC root),P
(PC root). They obey N+P=O+S and P=(1-E)S by the completed calculations.
The continued leading polynomials therefore give

    f O+S-(f N+P)=(1-f) E S.

This formula predicts a generally NONZERO finite-epsilon leading
difference. It is not declared equal to the independently inserted Ihat
at finite e here. That insertion already has its own uniform zero bound.

In common1/(16pi^2) units the radial functions for E*S are combinations
of Nc^e J34(e) and Nc^e J45(e),

    Jab(e)=(b^e-a^e)/[e(1-e)], Jab(0)=log(b/a).

Their combined IR singularity improves4->2. For0<=e<=1/4,c<=1,

    Jab(e)<=b^(1/4)log(b/a)/(3/4),
    Nc^e<=max(1,[exp(gamma_E)mu_R^2]^(1/4)),
    |1-f|<=4e/7.

For any fixed finite polynomial model coefficients,this bounds the
matrix norm of the leading difference by a constant times e,uniform
in c. IGH1 gives the complete actual Ihat coefficient a separate O(e)
uniform bound. The same finite-word compact-momentum majorants and
UV-jet remainder give O(sqrt(c)) uniformly on this e interval. The
UV-convergent Ja/K local relative terms remain vanishing under the same
one-variation domain assumptions. Thus the complete selected grouped
local Ward difference tends to0 under ANY joint c,e->0 in this domain.

The individual terms can retain path-dependent Nc^e limits. None is
removed or normalized by this group result. The proof does not construct
finite-epsilon insertion equality,absolute contact/measure/phase,QAP,
arbitrary multiple products or physical massive/Lorentzian limits. Shared
formal reference/action/domain premises and AI-authored analytic estimates
remain explicit;numeric path checks do not certify the analytic proof.
