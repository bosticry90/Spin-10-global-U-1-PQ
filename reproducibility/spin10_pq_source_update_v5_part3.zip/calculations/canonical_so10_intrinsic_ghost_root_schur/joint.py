from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'joint_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
data=load(O/'model_primary_inputs.json.gz');words=data['operator']['ordered_root_words'];counts={'PC_no_fermion_edge':0,'non_PC_one_PP_and_gauge_edge':0}
for name,ww in words:
 f=sum(z[0]==z[1]=='P' for z in ww);gp=sum(z[4]=='gP' for z in ww)
 if name=='M_PC':assert f==gp==0;counts['PC_no_fermion_edge']+=1
 else:assert f==gp==1;counts['non_PC_one_PP_and_gauge_edge']+=1
assert counts=={'PC_no_fermion_edge':8,'non_PC_one_PP_and_gauge_edge':68}
e=s.symbols('epsilon',real=True);f=2/(2-e);assert s.cancel(4/(4-2*e)-f)==0 and s.simplify((1-f)+e/(2-e))==0
# Unique open barred pair from the qualified PP inverse and gauge endpoint.
bq,hq=s.symbols('barQ hatQ',positive=True);alpha=bq/(bq+hq);assert s.simplify((bq+hq)*alpha-bq)==0
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta};D=lambda q:s.SparseMatrix(*q['shape'],{(i,j):s.sympify(v,locals=loc) for i,j,v in q['entries']});Z=lambda:s.SparseMatrix(256,45,{});cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);poly=lambda q:{int(k):D(v) for k,v in q.items()};model=load(O/'model_primary_tables.json.gz')['models'];pc=load(O.parent/'canonical_so10_intrinsic_ghost_root/pc_primary_tables.json.gz');assembly=read(O/'assembly_receipt_v2.json');positions=0
for probe,m in enumerate(model):
 for label in ['B10','B126']:
  for anti in [False,True]:
   key=label+('_anti' if anti else'');q=pc['models'][probe]['root_PC_mass_periods'][label];A=D(q['formal_conjugate_log9over8' if anti else'log9over8']);B=D(q['formal_conjugate_log16over15' if anti else'log16over15']);S={2:A,3:cl(-A+B),4:-B};P={2:A,3:cl(-2*A+B),4:cl(A-2*B),5:B};N=poly(m['total_non_PC_heat'][key]);L=poly(assembly['results'][probe]['maps'][key]['known_left_heat']);assert all(2<=k<=6 for k in set(P)|set(N)|set(L)|set(S))
   for power in range(2,7):
    # Avoid denominators in exact component comparisons.
    residual=cl(2*(L.get(power,Z())-S.get(power,Z())-N.get(power,Z()))+(2-e)*(S.get(power,Z())-P.get(power,Z()))+e*S.get(power-1,Z()));assert not residual.todok();positions+=256*45
mp.mp.dps=60;fmt=lambda x:mp.nstr(x,50);rows=[];mu2=mp.mpf('1.5');M=max(mp.mpf(1),(mp.exp(mp.euler)*mu2)**mp.mpf('.25'));B34=4**mp.mpf('.25')*mp.log(mp.mpf(4)/3)/mp.mpf('.75');B45=5**mp.mpf('.25')*mp.log(mp.mpf(5)/4)/mp.mpf('.75')
for ee in ['0.1','0.05','0.025']:
 ep=mp.mpf(ee)
 for path in ['fixed_power','exp_minus1overe','exp_minus1overe2']:
  c=ep**2 if path=='fixed_power' else mp.exp(-1/ep) if path=='exp_minus1overe' else mp.exp(-1/ep**2);Norm=mp.exp(mp.euler*ep)*mu2**ep*c**ep;J34=(4**ep-3**ep)/(ep*(1-ep));J45=(5**ep-4**ep)/(ep*(1-ep));value=abs(1-2/(2-ep))*Norm*(J34+J45);bound=mp.mpf(4)*ep*M*(B34+B45)/7;assert value<=bound
  rows.append({'epsilon':ee,'path':path,'heat_c':fmt(c),'Nc_pow_e':fmt(Norm),'unit_matrix_coefficient_bound_kernel':fmt(value),'uniform_O_e_bound':fmt(bound)})
out={'schema':'IRS5_GROUPED_INTRINSIC_GHOST_WARD_JOINT_LIMIT','elapsed_after_imports':time.perf_counter()-tick,'full_root_word_rank_classification':counts,'fixed_heat_powers2_to6_positions_including_zeros':positions,'continued_leading_difference_equals_one_minus_f_E_source_exact':True,'joint_paths':rows,'analytic_uniform_leading_difference_bound':'O_epsilon_UNIFORM_IN_c','independent_actual_hatted_bound_reused':'IGH1_COMPLETE_LEADING_LOCAL_O_epsilon','nonexceptional_finite_word_remainder_premise':'INHERITED_CSW_EDS_IHI_UNIFORM_LOCAL_JET','complete_selected_joint_local_Ward_limit':'ZERO','finite_epsilon_Ihat_equality_or_full_QAP_E5_A5_authority':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
