# IRS3: complete source/Euler support for the selected local comparison

Freeze before examining/comparing the model root outputs. This audit is
independent of their values. It reads committed classical AST/master/source
records only and owns euler_* outputs;execute after the live model controller
has finished,not as a competing model computation. No Ward residual supplies
a missing source coefficient.

Same unshifted,constant-first-u,intrinsic-grade1 local C-PP class. Prove
which classical field/source Euler products can supply its relative
DIM-minus-fixed-heat coefficient. Retain source differentiation before J0
and compact nonexceptional Euclidean external momenta. This is not a zero
statement for entire nonlocal products or arbitrary finite contact choices.

At this mean ideal qP acts on the ordinary u-PP mass coefficient. The affine
qB term involves an external ghost derivative and an intrinsically UV-
convergent u-B-PP coefficient;its local relative conversion vanishes. Other
ordinary field variations are0 by actual field degree. QG's source rows
are a/Lambda only and have no nonzero ordinary value on C/P means.

Classical E_x has its Yukawa PP term,so Gamma_(u Jx C) is required.
Classical E_B has PP current,but Gamma_(u JB C) at intrinsic grade1 has
exactly one unmatched scalar port:source JB-BC has none,each allowed
positive coefficient vertex has one,and scalar free edges pair ports.
This excludes the COMPLETE one-loop1PI source class,not just one color.
Positive ordinary cubics without external labels have three internal
ports and cannot evade this bridgeless one-loop parity argument.

Ja-PP and K_P-C-P insertion coefficients have local dimensions6 and5
including this positive coefficient,respectively. Their superficial UV
degrees are-2 and-1,so their relative heat removal is0 on the inherited
compact nonexceptional domain. Multiplying classical fixed-momentum
Euler factors does not change that convergence. The products themselves
need not vanish. No classical constant fermion mass is present in this
unshifted SMA action;translating scalars would change this conclusion.

E_Lambda and E_C have no PP/nonzero-source-free C/P mean component;
sterile source is absent and its physical projected Euler is0. Check the
full34-term physical AST contains no linear field monomial,so no scalar
or vector tadpole Euler at the origin creates an extra branch. Constants
are harmless to Euler derivatives. QG has no matter dependence by the
qualified source bracket support. The tangent/Jacobian trace has no PP:
original bosonic maps contain no matter and the matter diagonal derivative
removes its single P. No global measure or unrelated Jacobian zero follows.

Use a full AST degree expansion and a distinct recursive minimum-degree
check. Derive source dimensions from dim(J_phi)=3-dim(phi). Check the
source-JB type envelope independently by directed walks and saturated
cycles with every allowed intrinsic/probe insertion. Verify it is empty;
do not claim an anomalous remainder if it is not. Bind actual source
support/SMA/trace-domain receipts,not a newly assumed nilpotent chiral Q.

One120s audit,8GiBsampled/350MiBlaunchfloor/16MiBpacket. Freeze code/copy
and manifest first;preserve failure. Applicability is the actual local
reference regulator construction,not a completed renormalized connected-
product/contact prescription,QAP/E5/A5 or physical theory. Same protected
authority/foundation/benchmark/scheme/flavor/HB1C5/external-action boundaries.
