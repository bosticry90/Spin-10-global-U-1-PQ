# IRS2: full-model evaluation after the ordered normalization qualified

Freeze after IRS1 normalization receipt,before this model computation.
The six paired/color/chirality Gaussian cases and48 bosonic subgroup
comparisons passed;the physical-fermion diagonal local mass group is0.
Now evaluate all remaining non-PC groups of the original76-word root.

Use the authenticated IGR classical packets only. Construct418-dimensional
boson matrices from actual K0/G0,N0,U,Nr and all45 external-ghost currents
J0/S0/Ju/Su. Use actual M0 bosonic diagonal-C matrices,BC/aLambda units,
the actual QG antighost row Mu and k/-k reflection. The lower Nr block
uses Nr(-k)^T;dropping this sign is an invalid Hessian orientation.

Primary uses explicit n,u inverse coefficients and the nine expanded
products for Z_un. Replay uses the graded resolvent recurrence and full
coefficient convolution. Compare canonical hashes/counts of the complete
cross-block kernels and every scalar-source vector,not only final masses.
At model sewing,primary contracts actual scalar R_a and B;replay directly
uses actual16x16 T_a and weighted Yukawa matrices without commuting them.
Check RB=RC in its actual bound chart before applying B R=-ig L(T)B.
The formal anti-Yukawa program is calculated separately,not inferred by
conjugating a ghost coordinate. No complete source-involution claim.

Retain every heat coefficient and implicit zero for all45 ghosts,both
probes,B10/B126 and their formal anti programs. Integrate combined heat
polynomials by cumulative heat-length differences versus direct prime-log
decomposition. Keep log2/log3/log5 as a common exact period basis;do not
remove log5 to agree with a known Ward sum. Preserve any higher period.
Check endpoint0/1,polynomial coupling dependence and source/frame controls.
Report whether S0 cancels in the total or is merely nonzero in individual
groups. A zero omission control must be labelled insensitive honestly.

The completed PC quantum coefficient and ISG/FIM Ward inputs are denied
during these native model workers,apart from prior byte authentication.
Only a subsequent bound comparison may combine them. A mismatch remains
a mismatch;neither a Ward coefficient nor a finite baseline is fitted.

Two sequential model workers600s afterimports,verifier180s,8GiBsampled
private/350MiBlaunchfloor/16MiBwholepacket. Freeze this record,new code/
copies and manifests first. Preserve all failures/incomplete runs;no
silent cap expansion,truncation or reclassification. Same strict-heat
local intrinsic domain/authority ceiling as IRS1;full joint-regulator,
source/Euler/contact/measure/phase/QAP/E5/A5/physical unification remain
open. No foundational,benchmark,scheme,flavor/HB1C5 or authority change.
