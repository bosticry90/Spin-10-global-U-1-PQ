from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,ast
O=Path(__file__).resolve().parent;R=O.parents[1];I=O.parent/'canonical_so10_intrinsic_ghost_root';read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();b=dict(read(O/'normalization_validation_preparation.json')['input_sha256']);v=read(O/'normalization_validation_receipt.json');assert v['left_Hessian_Neumann_and_right_Hessian_Schur_routes_agree'] and v['bosonic_group_coefficients_checked']==48
for n0 in ['normalization_validation_preparation.json','normalization_validation_receipt.json','normalize_verify_capture.json']:p=O/n0;b[str(p)]=H(p)
for role in ['primary','replay']:
 ip=I/(role+'_inputs.json.gz');tp=I/(role+'_tables.json.gz');assert H(ip)==b[str(ip)] and H(tp)==b[str(tp)];d={'classical':load(ip),'operator':load(tp)};dst=O/('model_'+role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 b[str(dst)]=H(dst)
for n0 in ['MODEL_RECORD.md','model.py','verify_model.py','prepare_model.py','run_model.py']:
 p=O/n0
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n0+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n0+'.source.txt'))]=H(p)
with(O/'model_preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'model_seconds_after_imports':600,'verifier_seconds_after_imports':180,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_IRS2_MODEL',len(b),flush=True)
