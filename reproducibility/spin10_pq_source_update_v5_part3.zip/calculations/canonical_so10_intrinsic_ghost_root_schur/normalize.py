from pathlib import Path
from hashlib import sha256
import json,gzip,sys,time,threading,os,sympy as s
from exact import *
from fixture import build,predicted
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('normalize_'+('replay' if role=='primary' else'primary')):raise PermissionError('IRS1_PEER_DENIED')
  if p.parent.name in ['canonical_so10_intrinsic_scalar_source_ghost','canonical_so10_finite_intrinsic_mixed_response','canonical_so10_intrinsic_ghost_root'] and ('tables' in p.name or 'receipt' in p.name):raise PermissionError('IRS1_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard);pred=predicted();T=s.Matrix([[1,2],[3,-1]]);Y=s.Matrix([[2,1],[1,3]]);cases=[]
for side in ['left','right']:
 for pair in [(0,0),(0,1),(1,1)]:
  HH,H0,G0,Ms,par,kap=build(side,pair,role);NN=len(par);V=madd(HH,mneg(H0));EG=mm(scalar_matrix(E,NN),G0);RR=mm(H0,scalar_matrix(1/E-1,NN));roots={k:{} for k in Ms};Gfull={}
  if role=='primary':
   A=mm(EG,V);pw=eye(NN)
   for order in range(6):
    Gfull=madd(Gfull,mscale(mm(pw,EG),(-1)**order))
    for label,M in Ms.items():roots[label]=plus(roots[label],scale(tr(mm(mm(pw,scalar_matrix(1-E,NN)),M),par),(-1)**order))
    pw=mm(pw,A)
   assert not pw
  else:
   bb=list(range(8));ff=list(range(8,NN));AA=block(HH,bb,bb);A0=block(H0,bb,bb);BB=block(HH,bb,ff);CC=block(HH,ff,bb);assert block(HH,ff,ff)==block(H0,ff,ff);Dinv=mm(scalar_matrix(E,NN-8),block(G0,ff,ff));Af=mm(scalar_matrix(E,8),block(G0,bb,bb));Sp=madd(madd(AA,mneg(A0)),mneg(mm(mm(BB,Dinv),CC)));assert not any(key[0]&2 for val in Sp.values() for key in val);X=mm(Af,Sp);pw=eye(8);Sinv={}
   for order in range(6):Sinv=madd(Sinv,mscale(mm(pw,Af),(-1)**order));pw=mm(pw,X)
   assert not pw
   bf=mneg(mm(mm(Sinv,BB),Dinv));fb=mneg(mm(mm(Dinv,CC),Sinv));ffp=madd(Dinv,mm(mm(mm(mm(Dinv,CC),Sinv),BB),Dinv));Gfull=join(Sinv,bf,fb,ffp,8)
   for label,M in Ms.items():roots[label]=tr(mm(mm(Gfull,RR),M),par)
  assert mm(madd(mm(H0,scalar_matrix(1/E,NN)),V),Gfull)==eye(NN)
  actual={label:s.expand(expr(z,15,1,1)/(2*kap)).coeff(n,1).coeff(u,1) for label,z in roots.items()};expected={}
  for label,zpair in pred.items():
   ma1=y*Y;ma2=(s.I if side=='left' else-s.I)*y*Y;sg=1 if side=='left' else-1;L1=T.T*ma1+ma1*T if side=='left' else T*ma1+ma1*T.T;L2=T.T*ma2+ma2*T if side=='left' else T*ma2+ma2*T.T;expected[label]=s.expand(sg*g*E*(1-E)*(L1[pair[0],pair[1]]*zpair[0]+L2[pair[0],pair[1]]*zpair[1])/2)
  q={'side':side,'pair':list(pair),'mass_normalizer':str(kap),'actual':{k:str(v) for k,v in actual.items()},'predicted_schur_bosonic':{k:str(v) for k,v in expected.items()},'fermion_diagonal_predicted':'0'}
  with(O/(f'normalize_{role}_{side}_{pair[0]}_{pair[1]}_precheck.json')).open('xb') as f:f.write((json.dumps(q,sort_keys=True)+'\n').encode())
  for label,z0 in expected.items():assert s.expand(actual[label]-z0)==0,(side,pair,label,actual[label],z0)
  assert actual['FF']==0,(side,pair,actual['FF']);cases.append(q);print('STAGE IRS1 '+role+' '+side+' '+str(pair)+' ordered Schur normalization',flush=True)
out={'schema':'IRS1_ORDERED_SCHUR_NORMALIZATION','role':role,'cases':cases,'noncommuting_color_matrices_retained':True,'source_ghost_Schur_correction_zero_by_actual_block_support':True,'full_Ward_or_model_quantum_coefficients_used':False};blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/('normalize_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(gzip.decompress(blob)).hexdigest()},sort_keys=True),flush=True);timer.cancel()
