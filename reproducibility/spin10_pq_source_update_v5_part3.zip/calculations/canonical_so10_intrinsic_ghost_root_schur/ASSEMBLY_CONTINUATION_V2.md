# IRS4 continuation after the standalone S0-cancellation candidate failed

The first assembly worker stopped before any model Ward comparison. Its
assertion presumed the standalone baseline S0 parameter cancels in the
complete normalized root. Exact normalization polynomials refute that:
five color/chirality cases have a nonzero sum;one case is insensitive.
The six full raw coefficient lists are preserved in
assembly_S0_diagnostic.json,with the original failed sources,capture and
controller traceback. No model output or normalization result is changed.

The frozen assembly question was to TEST whether S0 cancels;zero was not
scientific authority or a prerequisite to the source/ordinary Ward test.
Its cancellation candidate is now REJECTED. V2 records that negative
result and evaluates the actual S0 contribution rather than removing it.
This changes no coefficient in the two completed model calculations:
both already included all six S0 words. Every heat/prime-log coefficient
and the exact Ward-comparison requirements are unchanged.

From the actual universal coefficient sum,for a current with scalar
mass m_i,the S0 group has heat

    -B sum_a[P_r,a w_a R_a S0_(c,a,:)^T] E^3(1-E).

Here w_a=G0_BB(a,a),P_r,a=-U_BB(a,a)/2. The direct open-color equivalent
is +ig sum_a P w L(T_a,m_a) for the holo program and its separately
derived -ig Lbar anti program. Compare these routes with the actual
current. The extension uses verified color-diagonal principal/probe
blocks;it is not a fitted Ward remainder. Store its actual omission
effect and label insensitive cases honestly.

One180s V2 assembly,8GiBsampledprivate/350MiBfloor/16MiBpacket. Bind
completed model/source evidence,first failure and diagnostic,freeze new
code/copies before running. No expensive model rerun,input change,
scientific-promotion or resource expansion. If the subsequent actual
Ward comparison has a remainder,preserve it;do not tune S0,Mu,PC or
any contact baseline to make it vanish.
