# IRS2 typed zero-carrier comparison continuation

Both frozen model workers completed. The original verifier failed its
literal JSON-object equality test. Actual cross-block hashes,scalar
vectors,total heat polynomials and every shared coefficient agree.
The primary cumulative integration creates eight extra log7 carriers
with shape256x45 and NO nonzero entries,where its final cumulative
coefficient is0. Replay direct-log integration has no log7 key.

The first failed verifier,controller traceback,sources,outputs and full
captures remain immutable. No mathematical model worker is rerun or
output edited. V2 compares the complete UNION of typed coefficient
carriers,with the omitted entry interpreted as its already declared
zero matrix. It checks shape,entry uniqueness/range and every shared
entry exactly;any omitted NONZERO coefficient fails. Every extra carrier
must actually be zero. Matrix kernels/scalar vectors and other metadata
remain exact comparisons. This corrects serialization equality,not
physics,calculation inputs or scientific acceptance criteria.

One180s verifier,8GiBsampled/350MiBlaunchfloor/16MiBpacket,same limits.
Authenticate completed model outputs and first failure,freeze new sources
and manifest before execution. Preserve any new failure. This comparison
does not itself add the PC subgroup,test a Ward cancellation or promote
QAP/E5/A5/physical authority.
