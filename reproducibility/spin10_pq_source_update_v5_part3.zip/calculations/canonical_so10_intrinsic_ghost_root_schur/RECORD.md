# IRS1: evaluate the remaining intrinsic regulator groups by ordered Schur reduction

Freeze before computation,October25,2026,base439f128128ea4e679c4e3b9be9cd052428d8a8d3.
Question: what are the actual coefficients of the68 IGR root words other
than the completed P<-C subgroup? Complete these groups rather than infer
them from a required Ward remainder. Reuse IGR's complete76-word/input
certificate. S0,Mu and the non-Abelian diagonal tangents must remain.

Original unshifted SMA/CSW/EDS,A0,constant first u,ordinary C/physical PP,
ordinary external jet0,intrinsic coefficient-dimension1. Fixed-reference
strict4D heat member BEFORE heat removal. This is not a new BMHV scheme,
translated mass,physical vacuum or full massive/finite-p construction.
Keep actual45/328 field charts,generic family Yukawas and actual scalar
source covariance. No commuting or averaged-charge color replacement.

First prove the finite ordered block reduction in SCHUR_PROOF.md and
test it with literal left-Hessian Neumann traces and independent right-
Hessian Schur inversion. Keep paired momenta,both physical chiralities,
two NONCOMMUTING fermion color matrices and a noncommuting scalar/mass
matrix. Use independent current/diagonal-field parameters so an accidentally
physical cancellation cannot conceal a matrix-order/sign error. Store
each group's raw coefficients before testing the reduction. No desired
Ward coefficient is an input. Preserve all mismatches as failed evidence.

The proposed reduction has a bosonic weighted pair kernel and a separate
fermion-diagonal group. Test the latter's zero directly rather than delete
it. Baseline ghost currents touch only the antighost port;the free a-a
inverse is0,so their bosonic Schur correction is0,but the directed tangent
responses are not. Preserve k/-k adjoints,original Rt placement and all
intrinsic/probe inverse terms. A gauge/scalar charged spinor contraction
is transferred through the ACTUAL qualified B R=-ig L(T)B identity only
after its open-word/color normalization is established. This is not a
four-matrix model of dimensional gamma5;the target is the declared strict
heat member,with the complete positive-heat support checked first.

Only after both normalization routes qualify,evaluate the actual weighted
boson matrices. Primary expands graded coefficients before the ordered
products;replay differentiates the exact block inverse or equivalent
resolvent recurrence. Compare complete polynomial coefficients/zeros,
both momentum signs,all45 external ghosts,both probes and both Yukawa
maps/formal conjugates. Preserve source/auxiliary current order. Actual
finite root coefficients are outputs,not fitted contacts or baselines.

Two normalization workers600s each,verifier180s;subsequent model workers
600s each,model verifier180s;8GiBsampledprivate/350MiBlaunchfloor/16MiBpacket.
This is a new bounded continuation,not an expansion of any old run limit.
Freeze code/inputs/copies/expected evidence before each dependent stage.
Preserve exact failures/unfinished runs;no silent retries or truncation.

Late comparison may add IGR's authenticated PC coefficient and compare
with the independently measured ordinary/source terms. A disagreement is
not automatically an anomaly;full source-Euler support and prescription
applicability still require their own proofs. No complete QAP,measure/
global phase,source reality,causal/physical limit,E5/A5 or unification
promotion. State113/34of39,custodyexit2sevenNOTPASS unchanged. No agents,
branch/worktree,push/outreach/publication,foundation/scheme/benchmark,
flavor/HB1C5 activation or protected acceptance. Shared action,charts,
Clifford/source conventions,software and AI author limit independence.
