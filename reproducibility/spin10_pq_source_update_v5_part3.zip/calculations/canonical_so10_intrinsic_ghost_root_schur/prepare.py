from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,ast
O=Path(__file__).resolve().parent;R=O.parents[1];read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();b={};assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='439f128128ea4e679c4e3b9be9cd052428d8a8d3'
for folder,ns in [('canonical_so10_intrinsic_ghost_root',['RECORD.md','OPERATOR.md','PC_RECORD.md','PC_PROOF.md','validation_receipt.json','pc_validation_receipt.json','primary_inputs.json.gz','replay_inputs.json.gz','primary_tables.json.gz','replay_tables.json.gz']),('canonical_so10_intrinsic_ghost_hatted',['TANGENT_RECORD.md','tangent_receipt_v2.json','PROOF.md','validation_receipt.json']),('canonical_so10_intrinsic_hatted_insertion',['exact.py','split_gaussian.py','gaussian_validation_receipt.json']),('canonical_so10_cutoff_source_ward_operator',['DERIVATION.md','validation_receipt.json'])]:
 for n0 in ns:
  p=O.parent/folder/n0;assert p.read_bytes()==subprocess.check_output(['git','show','HEAD:'+p.relative_to(R).as_posix()],cwd=R);b[str(p)]=H(p)
for n0 in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V615.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:
 p=R/n0;b[str(p)]=H(p)
for n0 in ['RECORD.md','SCHUR_PROOF.md','exact.py','fixture.py','normalize.py','verify_normalize.py','prepare.py','run_normalize.py']:
 p=O/n0
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(n0+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(n0+'.source.txt'))]=H(p)
with(O/'preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'normalizer_seconds_after_imports':600,'verifier_seconds_after_imports':180,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_IRS1',len(b),flush=True)
