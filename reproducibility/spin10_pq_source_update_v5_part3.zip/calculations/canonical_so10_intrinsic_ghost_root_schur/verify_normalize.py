from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'normalization_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('normalize_'+r+'_tables.json.gz')) for r in ['primary','replay']];assert a['cases']==b['cases'] and len(a['cases'])==6;ng=0
for z in a['cases']:
 assert z['actual']['FF']=='0'
 for label,val in z['predicted_schur_bosonic'].items():assert s.expand(s.sympify(z['actual'][label])-s.sympify(val))==0;ng+=1
out={'schema':'IRS1_NORMALIZATION_VALIDATION','elapsed_after_imports':time.perf_counter()-tick,'left_Hessian_Neumann_and_right_Hessian_Schur_routes_agree':True,'paired_momentum_and_noncommuting_color_cases':6,'bosonic_group_coefficients_checked':ng,'diagonal_physical_fermion_local_mass_group_zero':True,'ghost_bosonic_Schur_correction_zero_only_in_declared_mean_ideal':True,'actual_model_root_or_Ward_QAP_authority_qualified':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
