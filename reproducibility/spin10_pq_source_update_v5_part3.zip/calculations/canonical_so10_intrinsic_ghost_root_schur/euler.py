from pathlib import Path
from hashlib import sha256
from itertools import combinations_with_replacement,permutations,product
import json,gzip,time,threading,os
O=Path(__file__).resolve().parent;R=O.parents[1];read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'euler_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
d=load(O.parent/'canonical_so10_probe_mass_dimension_one/primary_inputs.json.gz');terms=d['physical_AST']['local_terms'];assert len(terms)==34
def degree_set(n):
 t=n['node']
 if t=='Field':return {1}
 if t in ['Parameter','ExactScalar','StructureConstant','RepresentationGenerator','KroneckerMetric','FrozenBackground','LorentzWeight']:return {0}
 if t=='PartialDerivative':return degree_set(n['argument'])
 if t=='LocalActionTerm':return degree_set(n['density'])
 if t in ['LorentzContraction','GroupContraction']:return degree_set(n.get('expression',n.get('argument')))
 if t=='Add':return set().union(*(degree_set(q) for q in n['terms']))
 if t=='OrderedProduct':
  out={0}
  for q in n['factors']:out={a+b for a in out for b in degree_set(q)}
  return out
 raise AssertionError(t)
def minimum(n):
 t=n['node']
 if t=='Field':return 1
 if t in ['Parameter','ExactScalar','StructureConstant','RepresentationGenerator','KroneckerMetric','FrozenBackground','LorentzWeight']:return 0
 if t=='PartialDerivative':return minimum(n['argument'])
 if t=='LocalActionTerm':return minimum(n['density'])
 if t in ['LorentzContraction','GroupContraction']:return minimum(n.get('expression',n.get('argument')))
 if t=='Add':return min(map(minimum,n['terms']))
 if t=='OrderedProduct':return sum(map(minimum,n['factors']))
 raise AssertionError(t)
degrees=[sorted(degree_set(t)) for t in terms];assert all(1 not in q for q in degrees) and [min(q) for q in degrees]==[minimum(t) for t in terms]
edges={'B':['B','L'],'L':['B'],'x':['x'],'C':['a'],'a':['C']};V={}
def put(n,a,b,degree):V[n]=list({(a,b,n,degree),(b,a,n,degree)})
put('J0B','a','B',(1,0,0));put('J0L','a','L',(1,0,0));put('S0','a','x',(1,0,1));put('N0','L','x',(0,0,1));put('UBB','B','B',(0,1,0));put('UBL','B','L',(0,1,0));put('ULL','L','L',(0,1,0));put('NrB','B','x',(0,1,1));put('NrL','L','x',(0,1,1));put('JuB','a','B',(1,1,0));put('JuL','a','L',(1,1,0));put('Su','a','x',(1,1,1));target=(1,1,1);vv=sum(V.values(),[]);dfs=[];sat=[]
for sa,sb in [('B','C'),('C','B')]:
 for size in range(5):
  paths=[(sb,(0,0,0),())]
  for step in range(size):
   nxt=[]
   for cur,dd,word in paths:
    for mid in edges[cur]:
     for aa,bb,nn,gr in vv:
      new=tuple(dd[i]+gr[i] for i in range(3))
      if aa==mid and all(new[i]<=target[i] for i in range(3)):nxt.append((bb,new,word+(nn,)))
   paths=nxt
  dfs.extend(ww for cur,dd,ww in paths if sa in edges[cur] and dd==target)
  for bag in combinations_with_replacement(sorted(V),size):
   if tuple(sum(V[n][0][3][i] for n in bag) for i in range(3))!=target:continue
   for ordering in set(permutations(bag)):
    for vs in product(*(V[n] for n in ordering)):
     cur=sb
     for aa,bb,nn,gr in vs:
      if aa not in edges[cur]:break
      cur=bb
     else:
      if sa in edges[cur]:sat.append(ordering)
assert not dfs and not sat
# Ghost/source dimensions are action dimensions under q of dimension1.
dim={'B':1,'x':1,'a':1,'C':1,'L':2,'P':1.5,'S':1.5};J={n:3-v for n,v in dim.items()};source_dimensions={'u_Ja_PP_intrinsic1':J['a']+2*dim['P']+1,'u_K_C_P_intrinsic1':J['P']+dim['C']+dim['P']+1,'u_JB_C_intrinsic1':J['B']+dim['C']+1,'u_Jx_C_intrinsic1':J['x']+dim['C']+1};assert source_dimensions=={'u_Ja_PP_intrinsic1':6,'u_K_C_P_intrinsic1':5.0,'u_JB_C_intrinsic1':4,'u_Jx_C_intrinsic1':4}
out={'schema':'IRS3_LOCAL_EULER_SUPPORT','elapsed_after_imports':time.perf_counter()-tick,'all34_AST_degree_sets':degrees,'AST_degree_set_and_minimum_routes_agree':True,'no_linear_physical_field_monomial':True,'source_dimensions':source_dimensions,'JB_source_complete_typed_cycles':0,'directed_and_saturated_JB_exclusions_agree':True,'Ja_K_source_coefficients_UV_convergent_relative_local_limit_only':True,'only_selected_scalar_source_and_ordinary_mass_relative_coefficients_required':True,'unrestricted_nonlocal_products_contacts_measure_QAP_authority':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
