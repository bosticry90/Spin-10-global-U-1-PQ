from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import gzip,json,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'model_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('model_'+('replay' if role=='primary' else'primary')):raise PermissionError('IRS2_PEER_DENIED')
  if p.parent.name in ['canonical_so10_intrinsic_scalar_source_ghost','canonical_so10_finite_intrinsic_mixed_response','canonical_so10_intrinsic_ghost_root'] and ('tables' in p.name or 'receipt' in p.name):raise PermissionError('IRS2_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard);d=load(O/('model_'+role+'_inputs.json.gz'));op=d['operator'];d=d['classical'];g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta};ZERO=lambda m,n:s.SparseMatrix(m,n,{})
@lru_cache(None)
def parse(z):return s.sympify(z,locals=loc)
dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v) for i,j,v in z['entries']});cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(v)] for(i,j),v in sorted(cl(M).todok().items()) if v]}
def bmat(A,B,C,D):return s.SparseMatrix.vstack(s.SparseMatrix.hstack(A,B),s.SparseMatrix.hstack(C,D))
def padd(A,B):
 out=dict(A)
 for k,M in B.items():out[k]=cl(out.get(k,ZERO(*M.shape))+M)
 return{k:M for k,M in out.items() if M.todok()}
def pmul(A,B):
 out={}
 for p,M in A.items():
  for q,N in B.items():out[p+q]=cl(out.get(p+q,ZERO(M.rows,N.cols))+M*N)
 return{k:M for k,M in out.items() if M.todok()}
pn=lambda A:{k:-M for k,M in A.items()};ep=lambda A:{k+1:M for k,M in A.items()}
ed=d['endings'];K90=dec(ed['K0']);G90=dec(ed['G0']);N=dec(ed['N0']);I=s.eye(328);K=bmat(K90,ZERO(90,328),ZERO(328,90),I);R0=bmat(G90,ZERO(90,328),ZERO(328,90),I);Kn=bmat(ZERO(90,90),N,N.T,ZERO(328,328));S=s.diag(*([-1]*45+[1]*373));Gca=s.eye(45);bc0=s.SparseMatrix.vstack(dec(op['M0_BC_affine_four_axes'][3]),ZERO(373,45));al0=s.SparseMatrix.hstack(ZERO(45,45),dec(op['M0_aLambda_affine']),ZERO(45,328));Rscalar=list(map(dec,op['M0_diagonal_C']['x']));Bdict=d['matter_classical'];RB=dec(Bdict['RB']);RC=dec(Bdict['RC']);assert not cl(RB-RC).todok();TT=list(map(dec,Bdict['Tminus']));Tg=[cl(sum((RB[a,c]*TT[a] for a in range(45) if RB[a,c]),ZERO(16,16))) for c in range(45)];B={label:dec(Bdict[label]) for label in ['B10','B126']}
# Actual scalar frame is identity here;do not infer it from the gauge chart.
ref=d['frame'];order=ref['field_order'];phys=[f'B{i}_{mu}' for i in range(45) for mu in range(4)]+d['xs']+[('b' if i<12 else'L')+str(i) for i in range(45)]+['C'+str(i) for i in range(45)]+[('bar' if i<12 else'ub')+str(i) for i in range(45)];ri={n:i for i,n in enumerate(order)};pi={n:i for i,n in enumerate(phys)};TI=dec(ref['physical_to_raw_inverse']);TF=dec(ref['physical_to_raw_kernel']);Tx=TI.extract([ri[n] for n in d['xs']],[pi[n] for n in d['xs']]);Fx=TF.extract([pi[n] for n in d['xs']],[ri[n] for n in d['xs']]);cn=['C'+str(i) for i in range(45)];an=[('bar' if i<12 else'ub')+str(i) for i in range(45)];Fc=TF.extract([pi[n] for n in cn],[ri[n] for n in cn]);Fa=TF.extract([pi[n] for n in an],[ri[n] for n in an]);Gca=cl(Fc*dec(ref['raw_ghost_Green'])*Fa.T);assert not cl(Tx-s.eye(328)).todok() and not cl(Fx*Fx.T-s.eye(328)).todok() and not cl(Gca-s.eye(45)).todok();massmaps={label:cl(B[label]*Tx) for label in B};massmaps.update({label+'_anti':cl(B[label].conjugate()*Tx) for label in B});labels=list(massmaps);groups=['BC','aL','BB','LL','xx','MuB','MuL','Mux'];diag=[{k:dec(op['M0_diagonal_C'][k][c]) for k in ['B3','L','x']} for c in range(45)];J00=[s.SparseMatrix.hstack(dec(z),ZERO(45,328)) for z in ed['J0']];J01=[s.SparseMatrix.hstack(ZERO(45,90),dec(z)) for z in op['S0_physical_current']];outmodels=[]
def vectors_from_H(Hmat):return cl(sum((Rscalar[a]*Hmat[:,a] for a in range(45) if any(Hmat[:,a])),ZERO(328,1)))
def mass_from_H(Hmat,V):
 if role=='primary':return {label:cl(s.I*BB*V/2) for label,BB in massmaps.items()}
 out={}
 for label,BB in massmaps.items():
  weighted=cl(BB*Hmat);total=ZERO(16,16)
  for a in range(45):
   if not any(weighted[:,a]):continue
   mm=s.SparseMatrix(16,16,lambda i,j:weighted[i*16+j,a]);ta=Tg[a]
   total+=-(ta*mm+mm*ta.T) if label.endswith('_anti') else ta.T*mm+mm*ta
  out[label]=cl(g*s.SparseMatrix(256,1,lambda i,j:total[i//16,i%16])/2)
 return out
for probe in range(2):
 U90=dec(ed['probe_quadratics'][probe]['U']);Nr=dec(ed['probe_quadratics'][probe]['Nr']);U=bmat(U90,ZERO(90,328),ZERO(328,90),ZERO(328,328));Nrminus=s.diag(*([-1]*45+[1]*45))*Nr;Kun=bmat(ZERO(90,90),Nr,Nrminus.T,ZERO(328,328));assert not cl(S*K*S-K.T).todok() and not cl(S*Kn*S-Kn.T).todok() and not cl(S*U*S-U.T).todok() and not cl(S*Kun*S-Kun.T).todok();wrong_lower_nr_positions=len(cl(Nr.T-Nrminus.T).todok());mu=dec(d['actual_Mu']['results'][probe]['four_axes'][3]['QG_antighost_linear']);muB=s.SparseMatrix.hstack(mu[:,:45],ZERO(45,373));muL=s.SparseMatrix.hstack(ZERO(45,45),mu[:,45:90],ZERO(45,328));mux=s.SparseMatrix.hstack(ZERO(45,90),mu[:,90:]);Gsign={}
 for sign in [1,-1]:
  RR=R0 if sign==1 else cl(S*R0*S);NN=Kn if sign==1 else cl(S*Kn*S);UU=U if sign==1 else cl(S*U*S);NU=Kun if sign==1 else cl(S*Kun*S)
  if role=='primary':GG={(0,0):{1:RR},(1,0):{2:cl(-RR*NN*RR)},(0,1):{2:cl(-RR*UU*RR)},(1,1):{2:cl(-RR*NU*RR),3:cl(RR*UU*RR*NN*RR+RR*NN*RR*UU*RR)}}
  else:
   GG={(0,0):{1:RR}};Gbase={1:RR}
   for nu in [(1,0),(0,1),(1,1)]:
    val={}
    for grade,VV in [((1,0),NN),((0,1),UU),((1,1),NU)]:
     rem=(nu[0]-grade[0],nu[1]-grade[1])
     if rem in GG:val=padd(val,pmul({0:VV},GG[rem]))
    GG[nu]=pn(pmul(Gbase,val))
  Gsign[sign]=GG
 outputs={gn:{label:{} for label in labels} for gn in groups};sv={gn:{} for gn in groups};hashes=[]
 for c in range(45):
  J10=s.SparseMatrix.hstack(dec(ed['mixed'][probe][c]['Ju']),ZERO(45,328));J11=s.SparseMatrix.hstack(ZERO(45,90),dec(ed['mixed'][probe][c]['pieces'][0]));jgrade={(0,0):J00[c],(1,0):J01[c],(0,1):J10,(1,1):J11};DB=bmat(s.diag(diag[c]['B3'],ZERO(45,45)),ZERO(90,328),ZERO(328,90),ZERO(328,328));DL=bmat(s.diag(ZERO(45,45),diag[c]['L']),ZERO(90,328),ZERO(328,90),ZERO(328,328));DX=bmat(ZERO(90,90),ZERO(90,328),ZERO(328,90),diag[c]['x']);Zsign={}
  for sign in [1,-1]:
   KK=K if sign==1 else cl(S*K*S);bc=bc0 if sign==1 else -bc0;muBs=muB if sign==1 else cl(muB*S);muLs=muL if sign==1 else cl(muL*S);muxs=mux if sign==1 else cl(mux*S);js={gr:(J if sign==1 else cl(J*S)) for gr,J in jgrade.items()};jms={gr:(cl(J*S) if sign==1 else J) for gr,J in jgrade.items()};Ws={'BC':{gr:{0:cl(-KK*bc*Gca*J)} for gr,J in js.items()},'aL':{gr:{0:cl(-J.T*al0)} for gr,J in jms.items()},'BB':{(0,0):{-1:cl(KK*DB)}},'LL':{(0,0):{-1:cl(KK*DL)}},'xx':{(0,0):{-1:cl(KK*DX)}},'MuB':{(0,1):{0:cl(-jms[(0,0)].T*muBs)},(1,1):{0:cl(-jms[(1,0)].T*muBs)}},'MuL':{(0,1):{0:cl(-jms[(0,0)].T*muLs)},(1,1):{0:cl(-jms[(1,0)].T*muLs)}},'Mux':{(1,1):{0:cl(-jms[(0,0)].T*muxs)}}};ZZ={};GG=Gsign[sign]
   for name,WW in Ws.items():
    poly={}
    if role=='primary':
     terms=[((0,0),(1,1),(0,0)),((0,1),(1,0),(0,0)),((0,0),(1,0),(0,1)),((1,0),(0,1),(0,0)),((0,0),(0,1),(1,0)),((1,1),(0,0),(0,0)),((0,0),(0,0),(1,1)),((0,1),(0,0),(1,0)),((1,0),(0,0),(0,1))]
    else:terms=[(a,b0,e0) for a in GG for b0 in WW for e0 in GG if tuple(a[i]+b0[i]+e0[i] for i in range(2))==(1,1)]
    for aa,bb,ee in terms:
     if bb not in WW:continue
     poly=padd(poly,pmul(pmul(GG[aa],WW[bb]),GG[ee]))
    ZZ[name]={e0:cl(M[90:,:45]-M[:45,90:].T) for e0,M in poly.items()};ZZ[name]={e0:M for e0,M in ZZ[name].items() if M.todok()}
   Zsign[sign]=ZZ
  for name in groups:
   HH=padd(Zsign[1][name],pn(Zsign[-1][name]));hs={str(e0):enc(M) for e0,M in sorted(HH.items())};hashes.append({'ghost':c,'group':name,'cross_blocks_sha256':sha256(json.dumps(hs,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'cross_block_nonzero_positions':sum(len(M.todok()) for M in HH.values())})
   for ee,Hmat in HH.items():
    V=vectors_from_H(Hmat)
    if ee not in sv[name]:sv[name][ee]=ZERO(328,45)
    sv[name][ee][:,c]=V;MM=mass_from_H(Hmat,V)
    for label,m in MM.items():
     for power,factor in [(ee+1,1),(ee+2,-1)]:
      if power not in outputs[name][label]:outputs[name][label][power]=ZERO(256,45)
      outputs[name][label][power][:,c]+=factor*m
  if c%9==8:print('STAGE IRS2 '+role+' probe '+str(probe)+' ghosts '+str(c+1),flush=True)
 packed={};total={label:{} for label in labels}
 for name in groups:
  packed[name]={}
  for label,poly in outputs[name].items():
   poly={ee:cl(M) for ee,M in poly.items() if cl(M).todok()};assert all(ee>0 for ee in poly) and not cl(sum(poly.values(),ZERO(256,45))).todok();total[label]=padd(total[label],poly);finite={p:ZERO(256,45) for p in [2,3,5]}
   if role=='primary':
    carry=ZERO(256,45)
    for ee in range(1,max(poly,default=0)+1):
     carry=cl(carry+poly.get(ee,ZERO(256,45)))
     for pp,nn in s.factorint(ee+1).items():finite[int(pp)]=cl(finite.get(int(pp),ZERO(256,45))+int(nn)*carry)
     for pp,nn in s.factorint(ee).items():finite[int(pp)]=cl(finite.get(int(pp),ZERO(256,45))-int(nn)*carry)
    assert not carry.todok()
   else:
    for ee,M in poly.items():
     for pp,nn in s.factorint(ee).items():finite[int(pp)]=cl(finite.get(int(pp),ZERO(256,45))-int(nn)*M)
   packed[name][label]={'heat':{str(ee):enc(M) for ee,M in sorted(poly.items())},'finite_prime_logs':{str(pp):enc(M) for pp,M in sorted(finite.items())}}
 outmodels.append({'probe':probe,'groups':packed,'scalar_vectors':{name:{str(ee):enc(M) for ee,M in sorted(poly.items()) if M.todok()} for name,poly in sv.items()},'cross_block_checks':hashes,'total_non_PC_heat':{label:{str(ee):enc(M) for ee,M in sorted(poly.items()) if M.todok()} for label,poly in total.items()},'wrong_lower_Nr_transpose_changes_positions':wrong_lower_nr_positions})
blob=gzip.compress((json.dumps({'schema':'IRS2_FULL_MODEL_NON_PC_ROOT','role':role,'models':outmodels,'formal_anti_program_calculated_separately':True,'old_PC_and_Ward_quantum_targets_denied':True,'full_Ward_QAP_or_authority':False},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/('model_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(gzip.decompress(blob)).hexdigest()},sort_keys=True),flush=True);timer.cancel()
