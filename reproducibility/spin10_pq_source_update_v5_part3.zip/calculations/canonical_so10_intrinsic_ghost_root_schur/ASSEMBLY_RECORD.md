# IRS4: late exact assembly and source/ordinary Ward comparison

Freeze only after IRS2's typed full-model comparison and IRS3 source
support completed. Model outputs remain immutable. This is the first
stage allowed to read IGR's PC quantum tensor and old ISG/FIS ordinary/
source quantum values. Do not change any regulator coefficient after
seeing this comparison.

Combine the measured non-PC heat polynomial with the qualified PC heat
polynomial reconstructed from its measured log9/8/log16/15 coefficient
matrices. Independently derive the known Ward-left heat polynomial from
FIS's measured T,ISG's measured W0/W2,the actual scalar mass maps and
both actual fermion transformations. Recheck the inherited holo image
and calculate the anti program directly rather than assuming ghost
coordinate conjugation. Generic family Yukawas remain symbolic.

Compare every heat coefficient and its zero complement,all45 ghosts,
both probes,both mass maps and anti programs. Independently integrate
the heat polynomial into exact prime-log carriers and compare with the
known log3/2/log4/3 pair. Preserve any residual and classify it as a
measured mismatch,not automatically an anomaly. A zero qualifies only
this strict-heat leading-local constant-probe intrinsic Ward group.
Joint BMHV removal,full finite-p/contact/measure/QAP/E5/A5 and physical
unification are not supplied by this comparison.

Also extract the independent baseline S0 parameter from IRS1's normalized
Gaussian polynomials. Test whether its complete group sum cancels while
individual groups are nonzero. The extension to the model uses the
actual color-diagonal free/probe B/L blocks and arbitrary scalar/current
matrix entries;verify that support. If it cancels,omitting S0 is an
INSENSITIVE total-only control here,not permission to omit its groups.
Report the actual sensitivity of removing Mu or the PC subgroup.

One180s comparison,8GiBsampledprivate/350MiBfloor/16MiBpacket. Freeze
code/copies,completed-output and inherited-input bindings before running.
No input fit,baseline selection,changed scheme/benchmark/foundation,
flavor/HB1C5 activation,publication/push or scientific authority promotion.
Preserve all earlier failed comparison evidence. Shared premises,
software and AI authorship remain explicit limitations.
