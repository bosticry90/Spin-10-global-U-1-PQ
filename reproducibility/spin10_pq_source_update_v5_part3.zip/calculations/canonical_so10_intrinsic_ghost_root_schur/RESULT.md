# Complete intrinsic ghost root and selected local Ward comparison

October 25, 2026. IRS1--IRS5, base
`439f128128ea4e679c4e3b9be9cd052428d8a8d3`. Bounded computational and
analytic result; no director acceptance or scientific-state promotion.

The remaining 68 ordered root words have now been calculated. Adding the
previously measured eight P<-C words gives an exact match to the independently
measured ordinary/source side of the selected strict-heat local Ward relation.
The complete selected difference also tends to zero in the joint heat and
dimensional limit under the explicitly inherited Euclidean local-jet premises.
This closes this local intrinsic ghost/fermion comparison. It does not close
the chiral QAP, the complete renormalized theory or E5/A5.

## Question, domain and scientific relevance

IGR/V615 supplied the original-action inputs and the complete 76-word family,
but had measured only its eight P<-C words. Inferring the other words from a
desired Ward remainder would not test the quantum construction. IRS measures
them first, using ordered Schur reduction, then performs a late comparison.

The domain is the original unshifted SMA/CSW/EDS reference construction, zero
ordinary external jet, constant first probe u, one ordinary ghost C, two
physical external fermions PP and intrinsic coefficient-dimension one. Both
probes, all 45 ghost directions, all 328 scalar directions, the 10 and 126
Yukawa maps, general family coefficients and separate formal anti programs
are retained. The strict member is four-dimensional heat regularization
before heat removal. IRS5 uses the already specified full split-dimensional
principal-symbol continuation; it does not introduce a new gamma5 scheme.

The local relative coefficients are defined on compact nonexceptional
Euclidean momenta and inherited Schwartz-test-field/one-variation assumptions.
They are not the entire nonlocal kernels, translated massive propagators,
constant-vacuum amplitudes or arbitrary finite composite-product prescriptions.

## Calculation and checks

IRS1 proves and tests an ordered bosonic Schur reduction. The independent
left-Hessian Neumann trace and right-Hessian Schur inverse agree in six
paired-momentum, noncommuting-color/chirality cases, including 48 bosonic
group coefficients. Independent symbolic currents prevent an accidentally
physical cancellation from fixing the normalization. The separate physical
fermion-diagonal group is zero in this local projection. The ghost current
touches only the antighost port, so its bosonic Schur correction is zero here
by the free a-a inverse; its directed root contributions remain essential.
See `SCHUR_PROOF.md` and `normalization_validation_receipt.json`.

IRS2 transfers the qualified ordered formula to the actual 418-dimensional
boson blocks and full scalar/ghost data. The primary route expands the graded
inverse coefficients explicitly; replay uses a resolvent recurrence. They
compare 720 complete cross-block kernel hashes, scalar-source coefficients,
heat and finite-log coefficients, and typed zero complements. Scalar-source
covariance sewing agrees with direct noncommuting fermion-matrix sewing.
The lower mixed block uses Nr(-k)^T, whose incorrect replacement changes
296 positions for the sensitive broken probe. The other probe is insensitive
to that particular control and is labeled accordingly. See
`model_validation_receipt_v2.json`.

The full ghost/scalar baseline S0 and the actual QG tangent Mu are included.
The model workers read classical inputs and normalization evidence, without
reading the earlier ordinary/source quantum coefficient targets. The old
P<-C result and ordinary/source side are read only by the late assembly.
No contact baseline, unknown quantum term or physical input is adjusted.

IRS3 establishes the other source/Euler support before the comparison. The
scalar-source Euler term is required. The intrinsic u-JB-C class is absent by
an unmatched scalar port in the complete one-loop support. Ja-PP and K_P-C-P
have superficial UV degrees -2 and -1, respectively; their local relative
heat-removal contributions vanish under the inherited domain assumptions.
This is not a zero assertion about their entire connected products. The
34-term physical AST has no linear field term. The selected tangent/Jacobian
trace has no PP coefficient, which is not a general measure theorem. See
`EULER_RECORD.md` and `euler_receipt.json`.

## Result of the complete strict-heat comparison

Let E denote the positive heat factor, B the appropriate Yukawa map, W0 and
W2 the authenticated scalar-source vectors, and V the independently measured
ordinary fermion variation. In the report's common loop normalization,

    source S(E) = -B W0 E^2(1-E) + B W2 E^3(1-E),
    ordinary O(E) = 2 V E^3(1-E),
    PC P(E) = -B W0 E^2(1-E)^2 + B W2 E^3(1-E)^2.

The newly measured non-PC result N satisfies, coefficient by coefficient,

    N(E) + P(E) = O(E) + S(E).

The full residual is zero for both probes, both Yukawa maps and their
separately derived anti programs. The strict comparison covered 69,120
positions in the union of active heat carriers, including their matrix zero
complements. That is not a fixed count of every possible heat power; IRS5
separately checked 460,800 positions across the fixed E^2 through E^6 domain.

The complete unbroken and 10-map roots vanish. In the broken 126 map and its
anti program, each surviving E^2, E^3 and E^4 matrix has 65 nonzero positions;
the finite log2 and log3 carriers each have 65. The log5 terms in separate
root groups cancel in the measured sum. They were not assigned zero.

The baseline current does NOT cancel on its own. Its full model contribution
is

    -B V_S0 E^3(1-E),
    V_S0,c = sum_a P_r,a w_a R_a S0_(c,a,:)^T.

The color-diagonal extension and direct color route agree. Omitting it changes
130 broken-probe heat positions in each 126 program. Omitting PC changes
260, and omitting Mu changes 195 in that probe (and 128 in the other probe).
Some other omission controls are insensitive and are recorded as zero rather
than counted as successful error detection. The complete baseline and tangent
must accompany the source and ordinary terms. See
`assembly_receipt_v2.json` and `assembly_v2_precheck.json`.

## Joint regulator limit and its boundary

IRS5 classifies the complete 76-word family: the eight PC words have no free
fermion edge; each of the other 68 has exactly one physical PP free edge and
one barred gauge endpoint. Longitudinal contraction leaves the unique open
factor alpha=barQ/Q. There is no additional closed spin/vector trace. Under
the declared full-D continuation its angular average is f=2/(2-epsilon).
The independent hatted insertion has its own previously qualified bound and
has not been discarded.

The exact continued leading-polynomial difference is

    f O + S - (f N + P) = (1-f) E S.

It is generally nonzero at finite epsilon. The actual fixed-carrier identity
was checked across 460,800 positions including zeros. Radial integration of
E S produces Nc^epsilon J34 and Nc^epsilon J45, where

    Jab = (b^epsilon-a^epsilon)/(epsilon(1-epsilon)).

For 0<=epsilon<=1/4 and 0<c<=1, the explicit bounds in `JOINT_PROOF.md` make
this difference O(epsilon) uniformly in c. The complete independently
calculated IGH hatted leading insertion is also O(epsilon) uniformly in c.
The CSW/EDS/IHI finite-word nonexceptional remainder premise gives the
remaining O(sqrt(c)) term uniformly on the stated interval. Thus the complete
selected grouped local difference tends to zero for any joint c,epsilon->0
within that domain. Nine numerical path diagnostics illustrate the analytic
bound; they do not prove it or adopt a physical subtraction scale.

Individual terms may retain path-dependent Nc^epsilon limits. This result
does not prove finite-epsilon insertion equality, identify absolute contact
baselines, normalize all products or establish a physical regulator limit.
The analytic domain premises are inherited and explicit, not newly proved
by the finite coefficient verifier. See `joint_receipt.json`.

## Preserved failures and execution

The first IRS2 verifier failed literal serialized-object equality. The two
completed model outputs differed by eight explicit zero log7 carrier matrices
versus omitted typed zeros. The V2 verifier compares the union of carriers,
their shapes and all coefficients; all nonzero coefficients and kernels agree.
Both original outputs, the failed verifier/source/capture and controller
failure remain unchanged. No model computation was rerun for this correction.

The first IRS4 assembly asserted that the standalone S0 group cancels. It
failed BEFORE any Ward comparison. Five of the six universal cases refute
that cancellation; the sixth is insensitive. V2 preserves this negative
finding and evaluates its actual contribution. Both model calculations had
already retained S0. Their outputs and the Ward acceptance condition were
unchanged. This is rejection of an intermediate cancellation candidate, not
reclassification of a failed Ward test as PASS.

| Run | Seconds after imports | Resource samples | Largest sampled private bytes |
| --- | ---: | ---: | ---: |
| Normalization primary / replay | 10.439314 / 7.470742 | 7 / 5 | 52,461,568 / 52,428,800 |
| Normalization verifier | 0.213934 | 1 | 397,312 |
| Model primary / replay | 223.098176 / 332.605698 | 112 / 167 | 134,160,384 / 134,963,200 |
| Model verifier V2 | 0.077573 | 1 | 925,696 |
| Source/Euler support | 0.391933 | 1 | 2,605,056 |
| Assembly V2 | 63.295369 | 33 | 123,920,384 |
| Joint-limit check | 1.203535 | 2 | 115,871,744 |

Workers remained inside frozen 600-second normalization/model limits and
120/180-second audit limits, 8-GiB sampled private memory, 350-MiB available
pagefile launch floor and 16-MiB packet ceiling. Samples are not continuous
peak measurements; the shortest verifier samples mainly cover startup. There
are 29 immutable source copies. External full captures, readiness and byte
seals are in `intrinsic-ghost-root-schur-v1-2026-10-25` under the local research
control directory. E4 returned native 0 and step exits [0,0,0,0,0,2]; the last
exit authenticates seven unresolved custody references and is NOTPASS.
E4 authentication does not freshly replay all inherited physics calculations.

## Reference intake, independence and next scientific dependency

The director's attached October 24 comprehensive assessment is useful context:
constructed corrections must be distinguished from subsequently tested quantum
companions, and agreeing implementations can share a wrong frame. It predates
the completed IHI/ISG/IGH/IGR/IRS sequence; its then-pending local comparisons
must be updated through their receipts rather than treated as current blockers.
The accompanying time-qubit, defect, Kondo, BIC and network discussion remains
methodological/future-recovery context. No external experimental claim is
independently verified by this calculation and none changes this action or
authority. No monitoring automation or external action was initiated.

These routes share the physical action, scalar/ghost charts, source and Clifford
conventions, libraries and AI authorship. Literal Gaussian normalization,
distinct inverse expansions, direct color/covariance sewing and omission
controls provide computational corroboration. They are not independent
scientists, a proof-assistant certificate or experimental validation of the
Spin(10) premise.

Next, relate the now-complete intrinsic local group to an admissible common
finite source/ordinary normalization, retaining the nonclosed scalar-source
part. ISG's full source conversion is still not any constant scalar translation;
the present Ward match does not turn its partial primitive into a full
counterterm. Examine the complete mixed source/mass action of the existing
candidate before adding coefficients or translating the physical benchmark.
Finite-epsilon insertion equality should be computed only if needed by that
construction; the grouped limit no longer requires assuming it. Broader
ordinary-field/derivative, multiple-insertion, measure/phase, causal and massive
physical requirements remain separate.

State113 and scientific authority 34/39 remain unchanged. E5/A5 stays OPEN.
The historical failed physical benchmark, scalar quantum-control warning,
gauge-matching limitations, flavor pause and HB1/C5 boundary are preserved.
No new physical benchmark, foundational scheme, publication, push or other
reserved action is adopted. The overarching investigation remains active and
incomplete.
