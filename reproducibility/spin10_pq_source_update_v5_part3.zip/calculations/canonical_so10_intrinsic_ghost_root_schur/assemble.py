from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'assembly_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta};Z=lambda m,n:s.SparseMatrix(m,n,{})
@lru_cache(None)
def parse(q):return s.sympify(q,locals=loc)
dec=lambda q:s.SparseMatrix(*q['shape'],{(i,j):parse(v) for i,j,v in q['entries']});cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(v)] for(i,j),v in sorted(cl(M).todok().items()) if v]}
def padd(A,B):
 out=dict(A)
 for ee,M in B.items():out[ee]=cl(out.get(ee,Z(*M.shape))+M)
 return {ee:M for ee,M in out.items() if M.todok()}
def pn(A):return{ee:-M for ee,M in A.items()}
def decode_poly(q):return{int(ee):dec(M) for ee,M in q.items() if M['entries']}
def integrate(A):
 out={pp:Z(256,45) for pp in [2,3,5]}
 for ee,M in A.items():
  for pp,nn in s.factorint(ee).items():out[int(pp)]=cl(out.get(int(pp),Z(256,45))-int(nn)*M)
 return out
d=load(O/'model_primary_inputs.json.gz')['classical'];op=load(O/'model_primary_inputs.json.gz')['operator'];model=load(O/'model_primary_tables.json.gz')['models'];pc=load(O.parent/'canonical_so10_intrinsic_ghost_root/pc_primary_tables.json.gz');IS=O.parent/'canonical_so10_intrinsic_scalar_source_ghost';src=load(IS/'primary_tables.json.gz');known=read(IS/'yukawa_image_receipt.json');F=load(O.parent/'canonical_so10_finite_intrinsic_scalar_source/primary_v2_tables.json.gz');Bdata=d['matter_classical'];B={label:dec(Bdata[label]) for label in ['B10','B126']};TT=list(map(dec,Bdata['Tminus']));RC=dec(Bdata['RC']);TC=[cl(sum((RC[a,c]*TT[a] for a in range(45) if RC[a,c]),Z(16,16))) for c in range(45)];normal=load(O/'normalize_primary_tables.json.gz');sb=s.Symbol('sb',real=True);s0=[]
for q in normal['cases']:
 co={k:s.expand(s.sympify(v,locals={str(z):z for z in s.symbols('g y w jb jl sb jbu jlu su db dl r E',real=True)})).coeff(sb,1) for k,v in q['actual'].items()};nz={k:str(v) for k,v in co.items() if v!=0};total=s.expand(sum(co.values()));s0.append({'side':q['side'],'pair':q['pair'],'nonzero_individual_S0_groups':nz,'complete_S0_sum':str(total)})
assert all(q['complete_S0_sum']=='0' and q['nonzero_individual_S0_groups'] for q in s0)
for probe in range(2):
 for name in ['G0']:
  assert all(i%45==j%45 for i,j,v in d['endings'][name]['entries'])
 assert all(i%45==j%45 for i,j,v in d['endings']['probe_quadratics'][probe]['U']['entries'])
muSupport=True
for probe in range(2):
 M=dec(d['actual_Mu']['results'][probe]['four_axes'][3]['QG_antighost_linear']);assert all(i==j%45 for(i,j),v in M[:,:90].todok().items())
results=[];comparisons=0;residual_total=0
for probe,m in enumerate(model):
 W0=dec(src['outputs'][probe]['W0']);W2=dec(src['outputs'][probe]['W2']);T=dec(F['source_vectors'][probe]);tables={}
 for label in ['B10','B126']:
  for anti in [False,True]:
   key=label+('_anti' if anti else'');BB=B[label].conjugate() if anti else B[label];Mv=cl(BB*T);mass=s.SparseMatrix(16,16,lambda i,j:Mv[i*16+j,0]);variation=Z(256,45)
   for c in range(45):
    mm=cl(-s.I*g*(TC[c]*mass+mass*TC[c].T) if anti else s.I*g*(TC[c].T*mass+mass*TC[c]));variation[:,c]=s.SparseMatrix(256,1,lambda i,j:mm[i//16,i%16])
   A=cl(-BB*W0);B43=cl(BB*W2+2*variation)
   if not anti:
    q=known['results'][probe]['Yukawa_images'][label];assert not cl(A-dec(q['known_heat_Ward_left_log3over2_from_scalar_source'])).todok() and not cl(B43-dec(q['known_heat_Ward_left_log4over3_from_ordinary_and_source'])).todok()
   p=pc['models'][probe]['root_PC_mass_periods'][label];ap=dec(p['formal_conjugate_log9over8' if anti else'log9over8']);bp=dec(p['formal_conjugate_log16over15' if anti else'log16over15']);assert not cl(ap-A).todok() and not cl(bp-BB*W2).todok();PC={2:ap,3:cl(-2*ap+bp),4:cl(ap-2*bp),5:bp};NC=decode_poly(m['total_non_PC_heat'][key]);root=padd(NC,PC);left={2:A,3:cl(-A+B43),4:-B43};left={ee:M for ee,M in left.items() if M.todok()};diff=padd(root,pn(left));positions=sum(len(M.todok()) for M in diff.values());residual_total+=positions;comparisons+=len(set(root)|set(left))*256*45;finite=integrate(root);fleft={2:cl(-A+2*B43),3:cl(A-B43),5:Z(256,45)};fd={pp:cl(finite.get(pp,Z(256,45))-fleft.get(pp,Z(256,45))) for pp in set(finite)|set(fleft)};assert all(not M.todok() for M in fd.values()) if positions==0 else True
   mu={}
   for gn in ['MuB','MuL','Mux']:mu=padd(mu,decode_poly(m['groups'][gn][key]['heat']))
   omitmu=padd(padd(root,pn(mu)),pn(left));omitpc=padd(NC,pn(left));tables[key]={'root_heat':{str(ee):enc(M) for ee,M in sorted(root.items())},'known_left_heat':{str(ee):enc(M) for ee,M in sorted(left.items())},'heat_residual':{str(ee):enc(M) for ee,M in sorted(diff.items())},'finite_root_prime_logs':{str(pp):enc(M) for pp,M in sorted(finite.items())},'finite_known_left_prime_logs':{str(pp):enc(M) for pp,M in sorted(fleft.items())},'finite_residual_nonzero_positions':sum(len(M.todok()) for M in fd.values()),'omitted_Mu_heat_residual_positions':sum(len(M.todok()) for M in omitmu.values()),'omitted_PC_heat_residual_positions':sum(len(M.todok()) for M in omitpc.values())}
 results.append({'probe':probe,'maps':tables})
out={'schema':'IRS4_COMPLETE_STRICT_HEAT_INTRINSIC_WARD','elapsed_after_imports':time.perf_counter()-tick,'complete_S0_parameter_cancellation_with_nonzero_groups':s0,'model_S0_color_diagonal_extension_checked':True,'all_heat_positions_including_zero_complements_compared':comparisons,'total_heat_residual_positions':residual_total,'results':results,'outcome':'MATCH_SELECTED_LOCAL_WARD' if residual_total==0 else'MEASURED_MISMATCH','joint_BMHV_QAP_measure_or_E5_A5_authority':False}
with(O/'assembly_precheck.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True)+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
