# Prospective intrinsic local Ward group, with both regulators retained

The following identities require IHI2 native/verification receipts. They
are not inputs to gaussian.py,which computes from the action and preserves
precheck values before testing its Ward relation. Retain IHI1/ISE1 and
IRR1 scopes and the corrected FIM2 momentum routing.

## Finite split normalization and dimensional continuation

For a local loop momentum let alpha=barQ/Q and A=g n w y. Restore the
overall Q^-2 and common1/(16pi²). The degree-bounded candidate polynomials
to test from the actual split Gaussian are

    Gamma_uPP/A = 2alpha E³(1-E),
    y Gamma_rhoJx/A = E²(1-E),
    root_deltaG/A = -E²(1-E)²,
    root_deltaM/A = alpha E³(1-E),
    insertion_Ihat/A = -(1-alpha)E³(1-E).

The insertion is computed by varying the actual PS mixed kinetic term
with epsilon qP. No value is assigned from the difference of the other
four expressions. Paired momenta and the actual mass normalizer remain.
The finite16-component split Clifford witness fixes open-word signs and
coefficients; it is not a model for dimension4-2epsilon or a new physical
spinor count. The primary and replay use different graded Hessians and
inverse/log routes on three fixed rational momentum fixtures/both chiralities.

Why these fixtures suffice for the normalized open-word coefficients:
the eight actual root words contain either one physical fermion numerator
or none. The first six therefore carry exactly one barQ/Q from the barred
gauge vertex and physical inverse; the two original P<-C words carry no
fermion edge or barred Lorentz sum. The insertion has one mixed PS numerator
and one hat derivative,so its only scalar Lorentz structure is hatQ/Q.
There are no closed spinor traces or additional k directions at this local
jet. All coefficients are thus affine in alpha; two distinct nonzero hat
ratios determine them and the strict4D fixture is a separate control.

Dimensional angular integration gives

    <alpha>=4/(4-2e)=f=2/(2-e),
    <1-alpha>=-2e/(4-2e)=1-f.

The second expression is an analytically continued tensor moment,not a
negative fraction of physical momentum. Define

    d23(e)=(3^e-2^e)/[e(1-e)],
    d34(e)=(4^e-3^e)/[e(1-e)],

with their continuous logarithmic limits at0. Actual radial Frullani
integration with d=4-2e yields the following leading local coefficients
in Nc^e M_r units,M_r=B*T_r,keeping the general family Yukawas:

    ordinary     2f d34,
    source Euler d23,
    root         (f+1)d34-d23,
    Ihat         (f-1)d34.

The last also follows independently from IHI1's Gaussian rank moment:
insertion=-M_r H and H_leading=-e Nc^e d34/(2-e). The complete leading
Ward difference ordinary-source-root-Ihat is identically0 for e in[0,1/4],
before taking any relative limit. The individual Nc^e factors must stay.

## Nonexceptional-momentum remainder and the grouped limit

Work on compact sets of Euclidean external p with p² bounded above and
away from0. This is not an unrestricted zero-vacuum or Lorentzian theorem.
The qualified FIS/FIM integral bounds control source/ordinary remainders
by constants times Nc^e cq and Nc^e sqrt(cq). ISE1 bounds the additional
physical K_P Euler term by a constant c(1+|log c|). The vector-source
grade1 component is structurally absent. The insertion and its leading
jet are each bounded by a constant e from IHI1. Tangent/Jacobian trace
at rhoPP has no P² by the actual source-map field degree; no claim about
other Jacobian components follows.

For the regulator root retain its complete positive-heat words. Six have
one shifted physical fermion node of degree1 and Q-node degree3. On a
bounded k region their root factor1-E gives a locally integrable uniform
majorant and vanishing contribution. The two P<-C words have a critical
merged ghost/scalar Q-node independent of p; their own1-E at that SAME
node improves it to degree2. They are explicitly local,not discarded.

On |k|>2|p| the rational kernel minus its homogeneous local jet is
O(|p|/|k|^5),with derivative/adjoint placements retained. For d=4-2e,
the radial absolute remainder is bounded by a constant times

    |p| int_1^infinity r^(-2-2e) min(c r²,1)exp(-a c r²)dr
       <= C |p| sqrt(c),  0<=e<=1/4.

Below r=1/sqrt(c),use1/(1-2e)<=2; above it rescale sqrt(c)r. Shifting
heat factors at R instead of Q gives the same bound after a heat derivative.
The finite-word compact-k bounds extend uniformly to e in[0,1/4]; numerator
rank factors and the external matrix coefficients are bounded analytic
functions there. This proves a uniform local-jet comparison rather than
assuming a four-dimensional estimate implies dimensional continuation.

Consequently the complete selected local Ward difference tends to0 under
any joint c,e->0 in the stated nonexceptional Euclidean domain. This is a
grouped result: each ordinary/source/root term can retain a path-dependent
Nc^e limit. The result does not identify finite freedoms b0/kappa,construct
an absolute finite renormalization,or turn the sole FIS canonical lift into
a complete chiral restoration counterterm.

## Limits on the claim

This is a first-probe,first-intrinsic-grade local Ward result. Varying
probes,other external fields,translated masses,the full massive inverse,
multiple insertions,unrestricted distributional limits,source reality,
global phase/measure,QAP,E5/A5 and physical unification remain separate.
The analytic support/locality argument uses shared qualified action and
regulator premises and the same AI author; no external scientific or
proof-assistant validation is claimed.
