# Historical schema adapter, before any quantum worker

The original preparation failed after writing its primary input: it assumed
the SMA replay packet had the primary's auxiliary_BRST_transform and
kinetic_requires_IBP_transpose keys. Their absence is a schema difference,
not a mathematical failure. Original prepare/run/native sources,partial
input,complete preparation capture and controller failure remain unchanged.
No worker ran and no original preparation manifest or scientific receipt
was produced.

V2 reads the common SMA definition from the authenticated CPS input. That
definition was explicitly extracted from the qualified SMA action by the
historical CPS preparation. It is not a guessed default. Role-specific
SMA coefficients and sole-antifield count are still authenticated. New
inputs use distinct v2 names; native_v2 selects those inputs and the new
preparation manifest. All original/current sources get immutable copies
before execution. Methods,physics,tolerances,resource limits and authority
ceiling are unchanged. Scientific calculation starts only after this
versioned preparation succeeds.
