# Intrinsic hatted insertion and a complete selected local Ward group

October25,2026. PROGRESS, basec943d70aacce0db62e192a836384c9fccd0e8b7c.
Two results are now checked. The complete selected first-intrinsic-grade
hatted insertion has a uniform zero joint-regulator limit. Its normalization
and the finite-epsilon ordered regulator root also satisfy the complete
selected intrinsic local Ward relation when the ordinary and source terms
are retained together. No contact baseline was fitted to obtain this result.

This is a formal Euclidean,constant-first-probe,physical-external,local
rhoPP result in the declared unshifted reference family. It is not full
renormalized chiral restoration,QAP,measure/phase,E5/A5 or physical unification.
State113/scientific authority34of39 stay unchanged. Historical custody
remains exit2 with seven unresolved references. Goal ACTIVE/INCOMPLETE.

## The hatted contribution is retained, then integrated

The actual insertion has E_C,E_P,E_S cubic ports C,P,S. Complete ordered
cycle enumeration and a distinct degree-saturated cycle construction agree
on42 candidate cycles. Fourteen have a hat derivative on the external P
and vanish only after physical projection. The other28 contain an internal
hat derivative and exactly one mixed P/S edge. They cannot be discarded
by setting external hats to0. One Yukawa endpoint closes the single
intrinsic scalar port; the complete rho ending is direct a-x or a-B/L
with N0-L-x. No ordinary gauge endpoint closes that grade1 scalar port.

The formal full SMA inverse is checked by direct Clifford multiplication
and Schur elimination. Its mixed block is -i hat_slash(r)/r_D²,not0.
The insertion's hat derivative and this numerator pair to hatk²; the
dimensionally continued Gaussian moment is -epsilon/T. Raw and compact
insertions retain their qualified total derivative before this projection.
All45 ghost and328 scalar ending coefficients recheck Srho=J G0 N0.

In common1/(16pi²) units the surviving scalar integral is

    H=N int E_Q²(1-E_Q)E_R hatk²/(Q²R)=-e K,
    Q=k_D²,R=(k-p)_D²,q=p_E²>0,c=2t,e=epsilon,
    N=exp(gamma_E e)*(mu_R²)^e.

Direct combined Gaussian parameters and positive heat-length integration
agree. The latter is

    K=N c int_2^3 d lambda int_0^1 du int_L^infinity
       T^(-2+e) exp[-q u(1-u)T]dT,
    L=c max(lambda/u,1/(1-u)).

K is positive. The actual finite hatted kernel is nonzero for e>0.
The proof bounds it before taking any limit:

    K<=N c^e(4^e-3^e)/[e(1-e)(2-e)],
    |H|<=4eN/3, 0<c<=1,0<=e<=1/4.

The continuous rank-divided bound at e=0 is log(4/3)/2. There is no
compensating1/e pole. Thus H tends to0 uniformly under joint c,e->0.
This is stronger than merely observing a formal factor e. Individual
uncombined heat paths would not supply this legitimate bound.

## Actual normalization is obtained from the action

A subsequent bounded calculation extends the literal graded Gaussian to
the full physical/sterile kinetic blocks. The16-component split-Clifford
witness is an algebra check,not a replacement for dimensional integration
or a change in physical spinor/family counts. It uses three fixed rational
bar/hat momentum fixtures and both chiralities. Left-Hessian Neumann
traces and right-Hessian Schur inversion agree on all78 formula comparisons.

The insertion Hessian is obtained by varying the ACTUAL P/S mixed kinetic
action with epsilon qP. It is never assigned the residual needed to make
a Ward identity vanish. Values are saved before the comparison. With
alpha=barQ/Q,A=g n w y,the normalized local heat polynomials are

    ordinary/A = 2alpha E³(1-E),
    source/A = E²(1-E),
    root_deltaG/A = -E²(1-E)²,
    root_deltaM/A = alpha E³(1-E),
    insertion/A = -(1-alpha)E³(1-E).

The finite Gaussian Ward difference ordinary-source-root-insertion is
exactly0 at each E and every declared fixture. The strict4D insertion
vanishes as a control; the nonzero-hat fixtures fix its normalization.

Only afterward,the actual Spin(10) matrices are contracted. Direct sparse
summation and per-color accumulation independently give

    C_Ihat=+i g10 sum_ai Srho_ai(T_a^T m_i+m_i T_a)=-M_r,
    M_r=B*T_r,

and the conjugate is separately signed/derived. The full comparison
covers2048 positions for both probes,both scalar maps,both chiralities
and all zeros. Only the broken126 neutral mass-function direction is
nonzero,two positions counting the two chiralities:

    M_1=5sqrt(30)g10²xi²/8 P_N.

Thus the normalized selected insertion is -M_r H with arbitrary symmetric
family Y126 and the conjugate. The10 and unbroken directions are0. This
is a formal kernel coefficient,not an observable neutrino mass prediction.
The universal IHI1 run did not itself claim this color transfer; the later
model review supplies it. No global Pfaffian phase is constructed.

## The complete selected local group now reconciles

Dimensional angular averaging gives f=2/(2-e) for the barred fraction and
1-f for the hatted fraction. Retain the individual heat factors Nc^e and
define d23=(3^e-2^e)/[e(1-e)],d34=(4^e-3^e)/[e(1-e)]. The independently
normalized leading coefficients in common Nc^e M_r units are

| Contribution | Leading coefficient |
| --- | --- |
| Ordinary uPP | 2f d34 |
| Scalar source/Euler | d23 |
| Complete ordered regulator root | (f+1)d34-d23 |
| Hatted insertion | (f-1)d34 |

Their Ward difference is identically0 for every e in the declared interval,
before either regulator is removed. LOCAL_GROUP_PROOF gives uniform
nonexceptional-momentum remainder bounds. It uses the actual finite word
envelope,keeps the critical merged P<-C ghost/scalar node's own1-E,and
derives an O(sqrt(c)) dimensional radial remainder on compact momentum
sets bounded away from exceptional points. It also retains ISE1's uniform
physical source-Euler zero and the structurally excluded vector-source
grade1 term. The tangent trace has no rhoPP by actual field degree.

The grouped local Ward difference therefore tends to0 under the declared
joint limits. The individual ordinary,source and root terms do NOT acquire
unique unrestricted joint limits: Nc^e can still approach exp(-a) along
cq=exp(-a/e). Their leading coefficients cancel as a group. In the strict4D
member the root remains M_r log(32/27),consistent with IRR1.

This accounts for the previously observed scoped ordinary/source mismatch
through the actual cutoff identity. It does not make the sole FIS canonical
lift a complete restoration counterterm,choose b0 or kappa,or prove a full
renormalized contact prescription. The earlier FIM2 Gamma routing correction
stands; none of its old bytes or historical claims is silently rewritten.

## Verification and preserved preparation failure

The original preparer stopped before any worker because it expected metadata
keys shared by SMA's primary and replay schemas. V2 uses the authenticated
common action definition already extracted by CPS; no defaults were supplied.
The old partial input,prepare/run sources,complete capture and controller
failure remain. All successful sources and copies are frozen separately.
There was no subsequent scientific worker or verifier failure in this packet.

IHI1 P/R/verifier took53.4040801/44.8539283/.3370917s after imports.
Their28/23/1 samples reached50,761,728/50,532,352/393,216B. IHI2 P/R/verifier
took9.1849680/8.4945531/.7000297s,their6/5/1 samples reached55,701,504/
55,930,880/397,312B. Model review took12.5607154s,seven samples,max56,160,256B.
These are sampled observations,not continuous peaks. IHI1 workers240s,
IHI2 workers300s,verifiers/review120s,8GiBsampled/350MiBfloor/8MiB held.

Nine finite integral cases and three joint paths gave63 comparisons at
60digits/50stored/1e-30 gate. Stored maximum discrepancy0 is numerical
corroboration,not exact integration. Wrong heat endpoint changes six
positive-e cases and is insensitive at the three e=0 cases; wrong hat-rank
factor changes all nine. Omitting the insertion changes the finite-e group,
while its e=0 control is correctly insensitive. Exact algebra and support
checks are recorded separately from quadrature. Bindings51/59/77/96/110;
20 source copies. Receipt SHA256 values:

- Integral validation:07b99a07f63c820944ae17efeba2ccd54ae13cc2c6d6af8c479136cf59aa379a.
- Split Gaussian:8074f5089b7b93edfd527635e7494ecc23a7db7fa3d480046eafc3ff049b463a.
- Model/group review:2b1561a4ef5ad174b36d620a7f3d9f5ac94ff01048c894723a784ed721a3c490.

Delegated E4 native0,steps[0,0,0,0,0,2],custodysevenNOTPASS. Full captures,
readiness and preservation seals are also retained under external
intrinsic-hatted-insertion-v1-2026-10-25. Historical tracked bytes and
project_state.json remain protected. No push or publication.

## Significance and next work

The advance is a complete grouped calculation in one actual intrinsic
sector,not merely another isolated zero. Structural support and uniform
integral estimates avoid expanding an unnecessary large coefficient table.
The normalization test derives a new insertion from the action before
comparison with the earlier ordinary/source results. Shared action,charts,
Clifford postulates,regulator,helpers,libraries and AI author still limit
independence. The analytic locality/limit proof is not proof-assistant
certification or external scientific validation.

Next address the correlated intrinsic source/gauge companions,especially
the u-Jx-C source map and u-C-PP relation,using their actual complete
ordered support. Determine whether the relative finite conversion admits
one admissible correlated renormalized definition. A completed rhoPP
regulated identity does not prove that result. Varying probes,other field
structures,translated masses,full massive IR,products,source reality,
global phase/measure,causal and physical domains,QAP,E5/A5 and physical
unification remain open. No retuning of physical parameters is justified.
