from pathlib import Path
from hashlib import sha256
import json,gzip,ast,subprocess
O=Path(__file__).resolve().parent;R=O.parents[1];read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='c943d70aacce0db62e192a836384c9fccd0e8b7c';b={};C=O.parent/'canonical_so10_chiral_probe_support';I=O.parent/'canonical_so10_intrinsic_regulator_root_v2';S=O.parent/'canonical_so10_sterile_matter_action';cm=read(C/'preparation.json')['input_sha256'];im=read(I/'review_preparation.json')['input_sha256'];sm=read(S/'validation_preparation.json')['input_sha256']
for role in ['primary','replay']:
 cp=C/(role+'_inputs.json.gz');ip=I/(role+'_inputs.json.gz');sp=S/(role+'_tables.json.gz');assert H(cp)==cm[str(cp)] and H(ip)==im[str(ip)] and H(sp)==sm[str(sp)];cs=load(cp);ed=load(ip)['ending'];sd=load(sp);data={k:ed[k] for k in ['G0','N0','rho']};data['hat_vertices']=cs['hat_vertices'];data['SMA']={k:sd[k] for k in ['physical_antifield_copies','auxiliary_BRST_transform','kinetic_requires_IBP_transpose','coefficients']};dst=O/(role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 for p in [cp,ip,sp,dst]:b[str(p)]=H(p)
for folder,ns in [('canonical_so10_sterile_matter_action',['ACTION_V1.md','validation_receipt.json']),('canonical_so10_chiral_probe_support',['DERIVATION.md','validation_receipt.json']),('canonical_so10_cutoff_source_ward_operator',['DERIVATION.md','validation_receipt.json']),('canonical_so10_intrinsic_source_euler_limits',['RESULT.md','CORRECTION_V2.md','validation_receipt_v2.json']),('canonical_so10_intrinsic_regulator_root_v2',['RESULT.md','validation_receipt.json','review_receipt.json'])]:
 for name in ns:p=O.parent/folder/name;b[str(p)]=H(p)
for name in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V611.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:p=R/name;b[str(p)]=H(p)
for name in ['RECORD.md','PROOF.md','native.py','prepare.py','verify.py','run.py']:
 p=O/name
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(name+'.source.txt'))]=H(p)
with(O/'preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'worker_seconds_after_imports':240,'verifier_seconds_after_imports':120,'packet_cap':8*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_IHI1',len(b),flush=True)
