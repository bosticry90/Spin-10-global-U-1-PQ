from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'model_review_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta};dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):s.sympify(v,locals=loc) for i,j,v in z['entries']});cl=lambda M:s.SparseMatrix(M).applyfunc(s.simplify);enc=lambda M:{'shape':list(M.shape),'entries':[[int(i),int(j),str(v)] for(i,j),v in sorted(cl(M).todok().items()) if v]};runs=[]
for role in ['primary','replay']:
 d=load(O/('model_'+role+'_inputs.json.gz'));TP=list(map(dec,d['Tminus']));RB=dec(d['RB']);T=[cl(sum((RB[a,b]*TP[a] for a in range(45) if RB[a,b]),s.zeros(16))) for b in range(45)];assert all(not cl(z-z.H).todok() for z in T);groups=[]
 for sr in d['rho_direct']:
  S=dec(sr);out={}
  for name in ['B10','B126']:
   B=dec(d[name]);cols={i:s.Matrix(16,16,lambda a,b:B[a*16+b,i]) for i in sorted({i for a,i in S.todok()})};LL=s.zeros(16);RR=s.zeros(16)
   if role=='primary':
    for(a,i),v in S.todok().items():LL+=s.I*g*v*(T[a].T*cols[i]+cols[i]*T[a]);RR-=s.I*g*v*(T[a]*cols[i].H+cols[i].H*T[a].T)
   else:
    for a in range(45):
     m=sum((S[a,i]*cols[i] for i in cols if S[a,i]),s.zeros(16));mc=sum((S[a,i]*cols[i].H for i in cols if S[a,i]),s.zeros(16));LL+=s.I*g*(T[a].T*m+m*T[a]);RR-=s.I*g*(T[a]*mc+mc*T[a].T)
   LL,RR=cl(LL),cl(RR);assert not cl(LL-LL.T).todok() and not cl(RR-LL.H).todok();out[name]={'left':enc(LL),'right':enc(RR)}
  groups.append(out)
 runs.append(groups)
assert runs[0]==runs[1]
with(O/'model_color_precheck.json').open('xb') as f:f.write((json.dumps({'Ihat_coefficients_multiplying_H':runs[0],'prior_FIS_mass_target_not_yet_read':True},sort_keys=True)+'\n').encode())
F=read(O.parent/'canonical_so10_finite_intrinsic_scalar_source/lift_receipt.json');positions=0;nonzero=0
for r,gg in enumerate(runs[0]):
 for name,ss in gg.items():
  M=dec(F['mass_directions'][r][name])
  for side,z in ss.items():
   target=M if side=='left' else M.H;assert not cl(dec(z)+target).todok();positions+=256;nonzero+=len(dec(z).todok())
assert positions==2048 and nonzero==2
e=s.symbols('epsilon',real=True);f=2/(2-e);d23=(3**e-2**e)/(e*(1-e));d34=(4**e-3**e)/(e*(1-e));R=(f+1)*d34-d23;I=(f-1)*d34;assert s.simplify(2*f*d34-d23-R-I)==0
assert s.simplify((2*f*d34-d23-R).subs(e,s.Rational(1,5)))!=0 and s.limit(2*f*d34-d23-R,e,0)==0
assert s.simplify(s.limit(2*f*d34-d23-(d34-d23)-I,e,0)-s.log(s.Rational(4,3)))==0
out={'schema':'IHI2_ACTUAL_COLOR_AND_GROUP_REVIEW','elapsed_after_imports':time.perf_counter()-tick,'independent_ordered_color_sums_agree':True,'Ihat_coefficients_multiplying_H':runs[0],'full_positions_including_zeros':positions,'nonzero_positions_both_chiralities':nonzero,'actual_Ihat_coefficient_equals_minus_FIS_M':True,'precheck_written_before_FIS_target_read':True,'finite_epsilon_group_residual':'0','omit_hat_at_positive_epsilon_sensitive':True,'omit_hat_at_epsilon0_insensitive':True,'omit_tangent_root_at_epsilon0_sensitive':True,'complete_selected_local_group_joint_limit':'0_UNDER_LOCAL_GROUP_PROOF_DOMAIN_PREMISES','unrestricted_renormalized_QAP_measure_phase_E5_A5_or_authority_changed':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
