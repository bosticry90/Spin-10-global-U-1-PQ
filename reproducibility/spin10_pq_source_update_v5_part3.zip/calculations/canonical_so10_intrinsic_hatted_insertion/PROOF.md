# Intrinsic hatted insertion: support, internal hats and a uniform bound

Qualification requires actual native and validation receipts. This is a
one-loop,constant-rho,unshifted,intrinsic-grade1,physical-external theorem.
Sources are differentiated before their zero restriction. No assertion
about a complete massive/chiral measure or unrestricted products follows.

## Complete insertion support

The actual SMA Ihat has three cubic terms with origins E_C,E_P,E_S and
fields C,P,S. In a bridgeless unicyclic one-loop graph every vertex has
internal degree2. Therefore the Ihat cubic must have an external leg.
The target rhoPP has no external C or S,so that leg is P. All E_P terms
have a hat derivative on that physical external leg and vanish only after
polarization. Retain E_C and E_S with internal C,S. The second P lies at
a Yukawa vertex: one intrinsic scalar port from rho-a-x or N0-L-x must
be closed. A gauge-P endpoint cannot do so at degree1. The rho-a-B/L
alternative needs precisely one N0. Other internal cubics have degree3
and cannot occur in a bridgeless cycle with these external labels.
No PPxx quartic exists in the actual linear scalar mass function.

All ordinary matter vertices act on P. Consequently exactly one mixed
P/S edge connects the insertion's S to the Yukawa P. This is not zero.
There are at most four vertices,including the insertion. The independent
cycle enumeration retains both derivative origins and both orientations;
an external-hat origin is counted before physical projection.

## Split inverse and actual numerator

Let b=bar_slash(r),h=hat_slash(r),B=bar_r²,H=hat_r². The qualified
SMA free operator is i[[b,h],[h,b]]. With {b,h}=0,b²=B,h²=H,its square
before the i is (B+H)I. Thus its inverse is

    -i/(B+H) [[b,h],[h,b]].

Schur elimination gives the same off-diagonal -i h/(B+H). This keeps
the full D-dimensional denominator. Chiral projectors commute with h,
and there is no bar numerator on that mixed edge. Each surviving open
spinor word therefore contains exactly two hats: the insertion derivative
and this numerator. Physical external hats imply hat(k-p)=hat k; their
contraction gives hatk² times finite ordered color/mass matrices. This
uses the split algebra,not a 4x4 anticommuting-gamma5 representation.

The actual raw SMA insertion equals
(ig/2)[(dhat C)barS hgamma A P+C barS hgamma A dhat P
-C barP Atilde hgamma dhat S]. Its compact form is
ig[(dhat C)barS hgamma A P+C barS hgamma A dhat P].
Their difference is the inherited -(ig/2)dhat[C barS hgamma A P].
After the specified charge-conjugation/Grassmann transpose,this says the
raw momentum factor is (h_C+h_P-h_S)/2,compact h_C+h_P; the difference
is -(h_C+h_P+h_S)/2. Momentum conservation and h_P=0 give identical
surviving h_C. No boundary contact is discarded at arbitrary insertions;
this use is confined to the present constant-rho physical target.

All coefficients are polynomial action/source constants. There is no
counterterm1/epsilon multiplier in this raw one-loop insertion. Overall
phase and the finite color tensor need not be fitted or expanded to prove
a zero of each universal kernel. The complete finite coefficient matrix
is not claimed measured here. Any genuine1/epsilon multiplier outside
this declared construction would require a separate analysis.

## Ordered scalar/ghost ending

The actual qualified EDS/FIS ending has Srho=J G0 N0 on all45 ghost and
328 scalar columns. Direct and mixed paths enter with opposite signs.
At constant rho the ghost and scalar momenta coincide. Each orientation
therefore carries E_Q²(1-E_Q)E_R,with the extra heat on the mixed inverse
path. The common hatted scalar integral in1/(16pi²) units is

    H=N int E_Q²(1-E_Q)E_R hatk²/(Q²R),
    Q=k_D²,R=(k-p)_D²,q=p_E²>0,c=2t,
    N=exp(gamma_E e)*(mu_R²)^e,e=epsilon.

The unfiltered complete ending is0 before integration. Individual
separated paths are not legitimate replacements for this heat difference.

## Gaussian route

Set A=a+lambda c,B=b+c,T=A+B,u=A/T,Delta=q u(1-u),
z_lambda=Delta c max(lambda/u,1/(1-u)). In d=4-2e,each hat Gaussian
component has moment1/(2T),and their dimension is d_hat=-2e. Since p_hat=0,
the complete hatted numerator has moment -e/T. This is analytic dimensional
continuation; no positive-dimensional interpretation of a negative rank.

Define H=-e K. Direct combined Q^-2R^-1 Schwinger parameters give

    K=N int_0^1 du [u Delta^(-e)(Gamma(e,z2)-Gamma(e,z3))
       -c Delta^(1-e)(2Gamma(e-1,z2)-3Gamma(e-1,z3))].

Use E1 at e=0 for Gamma(0,z); retain the combined expression to avoid
spurious endpoint divergences. K is a rank-divided kernel,not H itself.

## Positive heat-length route and uniform limit

E_Q²(1-E_Q)=Q int_(2c)^(3c) dh exp(-hQ) cancels one Q. Gaussian integration
then gives the distinct positive representation

    K=N c int_2^3 d lambda int_0^1 du int_L^infinity
       T^(-2+e) exp[-Delta T] dT,
    L=c max(lambda/u,1/(1-u)).

At fixed u the lambda antiderivative is
F(l)=l Gamma(e-1,a l)-Gamma(e,a l)/a,a=cq(1-u).
For lambda below lambda0=u/(1-u),the lower limit is constant. Thus the
middle branch is (lambda0-2)Gamma(e-1,cqu)+F(3)-F(lambda0),not the reversed
interval from the preserved first ISE1 replay. This branch is independently
checked by differentiation and continuity at u=2/3 and3/4.

Dropping exp[-Delta T] bounds K by its homogeneous zero-jet integral:

    0<K<=N c^e D(e),
    D(e)=(4^e-3^e)/[e(1-e)(2-e)],D(0)=log(4/3)/2.

This is an integral upper bound,not adoption of a q=0 physical trace.
To derive it integrate T,then split u at lambda/(lambda+1):
int_0^1 max(lambda/u,1/(1-u))^(e-1)du
=(lambda+1)^(e-1)/(2-e). The lambda integral gives the displayed D.
The same positive formula yields D(e)<=1/(1-e)<=4/3 on0<=e<=1/4,
since max(lambda/u,1/(1-u))>=1. Consequently,for0<c<=1,

    |H|=e K<=4 e N/3.

N is bounded at fixed positive scale. Therefore H->0 uniformly as e->0
with any c->0,including all correlated paths. At e=0 exactly H=0 even
though K>0. For each fixed e>0,its additional c^e factor also tends to0.
The finite regulated hatted kernel is nonzero for e>0 and has been retained
through integration. No1/e pole compensates the rank suppression.

This qualifies the complete selected insertion's zero limit. It does
not automatically extend IRR1's strict4D root to finite e,remove the
source-only lift remainder,construct a renormalized contact prescription,
or qualify full QAP/E5/A5,phase/measure,translated masses or physical limits.
