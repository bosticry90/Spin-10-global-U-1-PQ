from pathlib import Path
from hashlib import sha256
import json,gzip,sys,time,threading,os,sympy as s
from exact import *
from split_gaussian import build
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'gaussian_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('gaussian_'+('replay' if role=='primary' else'primary')):raise PermissionError('IHI2_PEER_DENIED')
  if p.parent.name in ['canonical_so10_finite_intrinsic_scalar_source','canonical_so10_finite_intrinsic_mixed_response','canonical_so10_intrinsic_regulator_root_v2'] and p.name.endswith(('tables.json.gz','receipt.json','precheck.json')):raise PermissionError('IHI2_OLD_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard);rows=[]
for kb,kh,kt in [(3,4,5),(4,3,5),(1,0,1)]:
 for side in ['left','right']:
  HH,H0,G0,HI,M0,Mr,par,kap,ix=build(kb,kh,kt,side,role);NN=len(par);VV=madd(HH,mneg(H0));EG=mm(scalar_matrix(E,NN),G0);RR=mm(H0,scalar_matrix(1/E-1,NN));log={};Gfull={};root0={};rootr={}
  if role=='primary':
   pw=eye(NN);V=mm(EG,VV)
   for m in range(6):
    Gfull=madd(Gfull,mscale(mm(pw,EG),(-1)**m))
    if m:log=plus(log,scale(tr(pw,par),s.Rational((-1)**(m+1),2*m)))
    root0=plus(root0,scale(tr(mm(mm(pw,scalar_matrix(1-E,NN)),M0),par),(-1)**m));rootr=plus(rootr,scale(tr(mm(mm(pw,scalar_matrix(1-E,NN)),Mr),par),(-1)**m))
    if m==5:assert expr(tr(pw,par),12,1,1)==0 and expr(tr(mm(mm(pw,scalar_matrix(1-E,NN)),madd(M0,Mr)),par),15,1,0)==0
    pw=mm(pw,V)
   assert not pw
  else:
   bs=list(range(8));fs=list(range(8,NN));AA=block(HH,bs,bs);AA0=block(H0,bs,bs);BB=block(HH,bs,fs);CC=block(HH,fs,bs);assert block(HH,fs,fs)==block(H0,fs,fs);Dinv=mm(scalar_matrix(E,NN-8),block(G0,fs,fs));Af=mm(scalar_matrix(E,8),block(G0,bs,bs));Sp=madd(madd(AA,mneg(AA0)),mneg(mm(mm(BB,Dinv),CC)));X=mm(Af,Sp);pw=eye(8);Sinv={}
   for m in range(6):
    Sinv=madd(Sinv,mscale(mm(pw,Af),(-1)**m))
    if m:log=plus(log,scale(tr(pw,[0]*8),s.Rational((-1)**(m+1),2*m)))
    pw=mm(pw,X)
   assert not pw
   bf=mneg(mm(mm(Sinv,BB),Dinv));fb=mneg(mm(mm(Dinv,CC),Sinv));ff=madd(Dinv,mm(mm(mm(mm(Dinv,CC),Sinv),BB),Dinv));Gfull=join(Sinv,bf,fb,ff,8);root0=tr(mm(mm(Gfull,RR),M0),par);rootr=tr(mm(mm(Gfull,RR),Mr),par)
  assert mm(madd(mm(H0,scalar_matrix(1/E,NN)),VV),Gfull)==eye(NN)
  Q=kt**2;norm=2*kap;mass=s.simplify(expr(log,12,1,1).coeff(u,1)/norm);source=s.simplify(expr(log,18,1,0)/2);r0=s.simplify(expr(root0,15,1,0)/norm);rr=s.simplify(expr(rootr,15,1,0)/norm);hat=s.simplify(expr(scale(tr(mm(Gfull,HI),par),s.Rational(1,2)),15,1,0)/norm);pc={k:v for k,v in M0.items() if not(12<=k[0]<44 and k[1] in [8,9])};rootnopc=s.simplify(expr(tr(mm(mm(Gfull,RR),madd(pc,Mr)),par),15,1,0)/norm);res=s.simplify(mass-y*source-r0-rr-hat)
  row={'bar':kb,'hat':kh,'total':kt,'side':side,'mass':str(mass),'source':str(source),'root_deltaG':str(r0),'root_deltaM':str(rr),'insertion_Ihat_from_varied_PS_kinetic':str(hat),'root_without_original_PC':str(rootnopc),'Ward_residual':str(res),'mass_pair_normalizer':str(kap)}
  with(O/(f'gaussian_{role}_{kb}_{kh}_{side}_precheck.json')).open('xb') as f:f.write((json.dumps(row,sort_keys=True)+'\n').encode())
  assert res==0,row
  rows.append(row);print('STAGE IHI2 '+role+' '+str((kb,kh,side))+' complete',flush=True)
blob=gzip.compress((json.dumps({'schema':'IHI2_NORMALIZED_SPLIT_GAUSSIAN','role':role,'cases':rows,'hatted_insertion_derived_from_actual_PS_kinetic_variation':True,'old_quantum_tables_denied':True,'physical_spin_dimension_or_scheme_changed':False},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/('gaussian_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(gzip.decompress(blob)).hexdigest()},sort_keys=True),flush=True);timer.cancel()
