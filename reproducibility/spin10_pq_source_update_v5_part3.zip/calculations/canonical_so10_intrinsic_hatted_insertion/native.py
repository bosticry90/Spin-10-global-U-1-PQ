from pathlib import Path
from hashlib import sha256
from collections import Counter
from itertools import permutations,product
import json,gzip,sys,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));Hh=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(240,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'preparation.json')['input_sha256'].items():assert Hh(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('replay' if role=='primary' else'primary'):raise PermissionError('IHI1_PEER_DENIED')
sys.addaudithook(guard);d=load(O/(role+'_inputs.json.gz'));g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta};dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):s.sympify(v,locals=loc) for i,j,v in z['entries']});cl=lambda M:s.SparseMatrix(M).applyfunc(s.simplify)
G=dec(d['G0']);N=dec(d['N0']);assert len(d['hat_vertices'])==3 and {v['origin'] for v in d['hat_vertices']}=={'E_C','E_P','E_S'}
for z in d['rho']:assert not cl(dec(z['direct'])-dec(z['J'])*G*N).todok()
assert d['SMA']['physical_antifield_copies']==1 and d['SMA']['auxiliary_BRST_transform']=='0'
for v in d['hat_vertices']:
 assert sorted(p for p,j in v['ports'])==['P','S','c'] and v['g_degree']==1 and v['Y_degree']==v['mass_dimension']==0
 assert sum(j=='h' for p,j in v['ports'])==1
 assert next(p for p,j in v['ports'] if j=='h')=={'E_C':'c','E_P':'P','E_S':'S'}[v['origin']]

# Formal split Clifford algebra, not a 4x4 model of dimensional gamma5.
Bv,Hv=s.symbols('barQ hatQ',positive=True);zero={};one={(0,0,0):s.S.One};bb={(1,0,0):s.S.One};hh={(0,1,0):s.S.One};chi={(0,0,1):s.S.One}
def add(A,B):
 z=dict(A)
 for k,v in B.items():z[k]=s.cancel(z.get(k,0)+v)
 return{k:v for k,v in z.items() if v!=0}
def scale(A,z):return{k:s.cancel(v*z) for k,v in A.items() if s.cancel(v*z)!=0}
def mul(A,B):
 out={}
 for(i,j,c),v in A.items():
  for(k,l,t),w in B.items():
   key=((i+k)%2,(j+l)%2,(c+t)%2);coef=(-1)**((j+c)*k)*Bv**((i+k)//2)*Hv**((j+l)//2)*v*w;out[key]=s.cancel(out.get(key,0)+coef)
 return{k:v for k,v in out.items() if v!=0}
def mm(A,B):return[[add(mul(A[i][0],B[0][j]),mul(A[i][1],B[1][j])) for j in range(2)] for i in range(2)]
assert mul(chi,hh)==mul(hh,chi) and add(mul(chi,bb),mul(bb,chi))==zero and add(mul(bb,hh),mul(hh,bb))==zero
D=[[bb,hh],[hh,bb]];expected=[[scale(bb,-s.I/(Bv+Hv)),scale(hh,-s.I/(Bv+Hv))],[scale(hh,-s.I/(Bv+Hv)),scale(bb,-s.I/(Bv+Hv))]]
if role=='primary':inv=expected
else:
 # Invert the noncommuting block through its Schur complement.
 ai=scale(bb,1/Bv);Sc=add(bb,scale(mul(mul(hh,ai),hh),-1));assert Sc==scale(bb,(Bv+Hv)/Bv);si=scale(bb,1/(Bv+Hv));bf=scale(mul(mul(ai,hh),si),-1);fb=scale(mul(mul(si,hh),ai),-1);aa=add(ai,mul(mul(mul(mul(ai,hh),si),hh),ai));inv=[[scale(aa,-s.I),scale(bf,-s.I)],[scale(fb,-s.I),scale(si,-s.I)]]
 # Anticommutation gives ai*h*si=-h/Q, so the reconstructed bf=+h/Q.
 assert all(inv[i][j]==expected[i][j] for i in range(2) for j in range(2))
assert mm([[scale(x,s.I) for x in row] for row in D],inv)==[[one,zero],[zero,one]]
assert mm(inv,[[scale(x,s.I) for x in row] for row in D])==[[one,zero],[zero,one]] and mul(hh,hh)==scale(one,Hv)
hc,hp,hs=s.symbols('hat_c hat_P hat_S');raw=(hc+hp-hs)/2;compact=hc+hp;assert s.expand(raw-compact+(hc+hp+hs)/2)==0 and s.simplify((raw-compact).subs(hs,-hc-hp))==0

# Full ordered cycle envelope; replay uses degree-saturated vertex sets.
edges={'B':['B','L'],'L':['B'],'x':['x'],'C':['a'],'a':['C'],'P':['P','S'],'S':['P','S']};families={}
def vf(a,b,name,pp,rho,nn,ee,exthat=False):families[name]=[(a,b,name,pp,rho,nn,ee,exthat),(b,a,name,pp,rho,nn,ee,exthat)]
vf('B','P','gP',1,0,0,0);vf('x','P','yP',1,0,0,0);vf('a','B','rho_aB',0,1,0,0);vf('a','L','rho_aL',0,1,0,0);vf('a','x','rho_ax',0,1,1,0);vf('L','x','N0',0,0,1,0)
for v in d['hat_vertices']:vf('C','S',v['origin'],1,0,0,1,v['origin']=='E_P')
vv=sum(families.values(),[]);target=(2,1,1,1);cycles=[]
def pack(word):return tuple((cur,mid,a,b,name,exthat) for cur,mid,a,b,name,exthat in word)
if role=='primary':
 for size in range(1,6):
  for start in edges:
   paths=[(start,(0,0,0,0),())]
   for step in range(size):
    nxt=[]
    for cur,deg,word in paths:
     for mid in edges[cur]:
      for a,b,name,pp,rh,nn,ee,exthat in vv:
       dd=tuple(deg[i]+(pp,rh,nn,ee)[i] for i in range(4))
       if a==mid and all(dd[i]<=target[i] for i in range(4)):nxt.append((b,dd,word+((cur,mid,a,b,name,exthat),)))
    paths=nxt
   cycles.extend(pack(word) for cur,dd,word in paths if cur==start and dd==target)
else:
 for origin in ['E_C','E_P','E_S']:
  for matter in ['gP','yP']:
   bases=[(origin,matter,'rho_ax'),(origin,matter,'rho_aB','N0'),(origin,matter,'rho_aL','N0')]
   for base in bases:
    for order in permutations(base):
     for vertices in product(*(families[name] for name in order)):
      if all(vertices[(i-1)%len(vertices)][1] in edges and vertices[i][0] in edges[vertices[(i-1)%len(vertices)][1]] for i in range(len(vertices))):
       cycles.append(pack(tuple((vertices[(i-1)%len(vertices)][1],a,a,b,name,eh) for i,(a,b,name,pp,rh,nn,ee,eh) in enumerate(vertices))))
cycles=sorted(cycles);assert cycles and len(set(cycles))==len(cycles);survive=[];rejected=[]
for word in cycles:
 names=[z[4] for z in word];assert 'yP' in names and 'gP' not in names and len(word)<=4
 mix=sum({z[0],z[1]}=={'P','S'} for z in word);assert mix==1
 if any(z[5] for z in word):rejected.append(word)
 else:survive.append(word)
assert {next(z[4] for z in ww if z[4].startswith('E_')) for ww in survive}=={'E_C','E_S'} and rejected
print('STAGE IHI1 '+role+' complete split inverse and physical insertion support',flush=True)

# Direct Gaussian and positive heat-length scalar kernels.
mp.mp.dps=60;fmt=lambda x:mp.nstr(x,50)
def calc(e,z,q,mu,wrong=False):
 c=z/q;Norm=mp.exp(mp.euler*e)*mu**e;hi=mp.mpf(4 if wrong else 3);cuts=[0,mp.mpf(2)/3,hi/(hi+1),1]
 def GG(a,x):return mp.e1(x) if not a else mp.gammainc(a,x,mp.inf)
 def direct(u):
  Delta=q*u*(1-u);z2=Delta*c*max(2/u,1/(1-u));zh=Delta*c*max(hi/u,1/(1-u));return u*Delta**(-e)*(GG(e,z2)-GG(e,zh))-c*Delta**(1-e)*(2*GG(e-1,z2)-hi*GG(e-1,zh))
 def length(u):
  Delta=q*u*(1-u);a=z*(1-u);l0=u/(1-u)
  def F(l):return l*GG(e-1,a*l)-GG(e,a*l)/a
  if l0<=2:ans=F(hi)-F(2)
  elif l0>=hi:ans=(hi-2)*GG(e-1,z*u)
  else:ans=(l0-2)*GG(e-1,z*u)+F(hi)-F(l0)
  return c*Delta**(1-e)*ans
 K=Norm*mp.quad(direct if role=='primary' else length,cuts);D=(4**e-3**e)/(e*(1-e)*(2-e)) if e else mp.log(mp.mpf(4)/3)/2;leading=Norm*c**e*D;return K,-e*K,leading,mp.mpf(4)*e*Norm/3
rows=[]
for ee in ['0','0.1','0.2']:
 for zz,qq in [('0.01','0.5'),('0.2','2'),('1.5','5')]:
  e,z,q=map(mp.mpf,[ee,zz,qq]);K,H,lead,bound=calc(e,z,q,mp.mpf('1.5'));badK,badH,_,_=calc(e,z,q,mp.mpf('1.5'),True);assert 0<K<=lead and abs(H)<=bound and abs(badK-K)>mp.mpf('1e-40');rows.append({'epsilon':ee,'cq':zz,'q':qq,'rank_divided_K':fmt(K),'actual_hatted_H':fmt(H),'leading_bound_for_K':fmt(lead),'uniform_bound_for_abs_H':fmt(bound),'wrong_heat_endpoint_H':fmt(badH),'wrong_omit_rank_factor':fmt(K)})
 print('STAGE IHI1 '+role+' epsilon '+ee+' complete',flush=True)
paths=[]
for ee in ['0.1','0.05','0.025']:
 e=mp.mpf(ee);z=mp.exp(-1/e);K,H,lead,bound=calc(e,z,mp.mpf(2),mp.mpf('1.5'));assert 0<K<=lead and abs(H)<=bound;paths.append({'epsilon':ee,'a':'1','cq':fmt(z),'rank_divided_K':fmt(K),'actual_hatted_H':fmt(H),'uniform_bound_for_abs_H':fmt(bound),'joint_limit':'0'})
out={'schema':'IHI1_INTRINSIC_HATTED_INSERTION','role':role,'raw_typed_cycles':cycles,'physical_typed_cycles':survive,'external_hat_cycles_projected_only_after_enumeration':rejected,'formal_split_inverse_and_Schur_identity':True,'raw_compact_boundary_checked_before_physical_projection':True,'full_actual_ending_identity':True,'kernel_factor':'-epsilon','rows':rows,'paths':paths,'uniform_joint_limit':'0','full_nonzero_finite_color_tensor_or_absolute_phase_calculated':False,'complete_Ward_joint_root_QAP_measure_or_authority':False};blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(gzip.decompress(blob)).hexdigest()},sort_keys=True),flush=True);timer.cancel()
