# IHI2: normalized split Gaussian and intrinsic local Ward group

Freeze after successful IHI1 P/R/V,before this new computation. Question:
do actual split charged/sterile action coefficients normalize Ihat and
the finite-epsilon regulator root consistently,without assigning either
from a required remainder? This directly follows the qualified IHI1 zero
limit but asks a stronger normalization question. No input is taken from
the old FIM2 sign/remainder or an assumed cancellation.

Reuse the IRR1 literal graded action/exact exterior helper as an authenticated
classical construction,not its quantum tables. Extend the paired Gaussian
to the full SMA P/S split using the qualified16-component Clifford witness,
with independent bar and hat directions,one physical Nambu field and its
free sterile partner. This finite algebra witness fixes coefficients only;
it does not replace dimensional continuation,change physical spinor size,
add families or adopt a six-dimensional physical theory.

Before execution fix three rational momentum fixtures: bar3/hat4,total5;
bar4/hat3,total5;bar1/hat0,total1. Both chiralities. Keep all reference
k-scaling,N0,Nr,U,rho factors and the physical barred gauge vertex. The
hatted insertion Hessian is obtained by varying the ACTUAL P/S mixed
kinetic action with epsilon qP,not by choosing a source term to cancel a
known answer. Actual full inverse and pairing identities are gates.

Primary left-Hessian Neumann traces; replay right-Hessian Schur inverse.
Compute Gamma_uPP,Gamma_rhoJx,ordered root deltaG and deltaM,original
P<-C omission,and onehalf STr(Gt epsilonIhat'') independently. Preserve
precheck values before testing the finite Ward relation. Full source Euler
kinetic term vanishes only at this local external zero jet; nonexceptional
source-Euler limits are separately ISE1,not inferred from that zero jet.

Use the complete IRR1 eight-word envelope to classify which root terms
carry barQ/Q and which do not. Each open word has at most one physical
fermion numerator; the coefficient is affine in that ratio. Two distinct
nonzero hat ratios plus strict4D control test the unique degree-bounded
formula. Analytic dimensional angular averaging remains4/(4-2e) for bars
and-2e/(4-2e) for hats. Keep c^e and exact radial difference functions.
Any disagreement is a normalization failure to diagnose,not an anomaly
or permission to change action,conventions or a finite counterterm.

After native comparison,derive the complete leading local Ward relation
symbolically in epsilon and preserve all individual nonunique limits.
Prove the grouped remainder bound on compact nonexceptional Euclidean
momenta; do not import the grade0 whole-group theorem automatically.
Finite color transfer uses the existing unique symmetric mass-function
direction M=B*T with generic family Yukawas. No full nonlocal finite-p
amplitude,unrestricted probes,renormalized QAP,measure,phase,E5/A5 or
physical-unification promotion.

Two sequential workers300s afterimports,verifier/review120s,8GiBsampled,
350MiBfloor,8MiBpacket. Freeze own sources/copies and references before
execution. Shared exact helper,action,Clifford,Wick charts,software,AI
author disclosed. Preserve every failed or incomplete normalization run.
