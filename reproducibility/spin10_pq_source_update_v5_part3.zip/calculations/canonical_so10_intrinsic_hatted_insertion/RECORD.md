# IHI1: complete first-intrinsic-grade hatted insertion limit

Freeze before computation,October25,2026,basec943d70aacce0db62e192a836384c9fccd0e8b7c,
35959oldblobs. Question: does the actual one-loop Ihat'' insertion at
rhoPP leave a finite first-intrinsic-grade contribution? IRR1/ISE1 do
not answer it. Least-cost competent test: complete typed insertion cycles,
actual ending identity, full split P/S inverse and a uniform integral bound.

Original unshifted SMA/CSW/EDS,constant firstprobe,A0,physical external P,
external hats0,nonexceptional Euclidean q>0. Intrinsic coefficient-dimension
one GF/reference terms only. No scalar translation,full massive inverse,
new benchmark,scheme,flavor or foundation. Keep actual E_C/E_P/E_S ports,
source differentiation before restriction and the existing raw/compact
boundary current. External-hat E_P is excluded only after polarization.
The graded one-loop insertion is onehalf STr(Gt Ihat''); Ihat is probe
independent by the actual source-support theorem. This is not Q_full^2=0.

Enumerate all bridgeless one-loop typed cycles at rhoPP,intrinsic grade1.
One Ihat vertex has external P and internal C,S. One Yukawa vertex has
external P and internal x,P. The rho ending is direct a-x or a-B/L plus
N0-L-x. Gauge-P alternatives and additional unlabelled internal cubics
must be excluded structurally,not by a favorable color fit. At most four
vertices occur. Every surviving word has exactly one mixed P/S edge and
one insertion hat derivative. Internal hats may pair; do not declare an
odd-hat or physical-external zero. Retain actual nonminimal/scalar inputs.

Reuse qualified SMA split Clifford/charge-conjugation postulates, and
check the free inverse formally in b,h,chi with b²=barQ,h²=hatQ,
{b,h}=0,{b,chi}=0,[h,chi]=0. No four-matrix BMHV surrogate. Compare
direct multiplication with Schur elimination. The raw and compact Ihat
agree at physical external hats by the retained total derivative. Open
spinor words contain paired hats and no closed gamma5 trace. All model
color/Yukawa/transpose prefactors are finite polynomial matrices; this
increment proves a uniform zero for each universal kernel,not a full
finite nonzero Spin(10) coefficient tensor or its absolute phase.

Ending identity Srho=J G0 N0 must give the same ordered heat difference
as an actual inverse block,independent of any Ward target. The universal
scalar integral is H=N int E_Q²(1-E_Q)E_R hatk²/(Q²R),Qk²,R(k-p)².
Derive the -epsilon/T Gaussian moment and compare direct combined
Schwinger parameters with positive heat-length integration. Never split
critically singular pieces. Check nine finite cases and three joint
paths,60digits/50stored,1e-30 scaled gate. Wrong heat endpoint and wrong
hat-rank factor controls; report epsilon0 insensitivity where applicable.

Expected outcome: qualified uniform zero of this complete selected
insertion; nonzero finite limit; underdefinition; failed/incomplete run.
A claimed zero requires a uniform bound including epsilon->0,not merely
pointwise -epsilon. Keep the whole Ward,finite root epsilon continuation,
renormalized contact/measure/QAP/phase and translated mass obligations open.

Two sequential workers240s afterimports,verifier120s,8GiBsampled,
350MiBlaunchfloor,8MiBpacket. Freeze inputs,code/copies,proof before work.
Preserve failures and no silent retry/cap growth. State113/34of39,E5A5open,
custodyexit2sevenNOTPASS. Noagents/branches/worktrees/push/outreach/
publication/foundation/scheme/benchmark/flavor/HB1C5/promotion. Shared
action,charts,Clifford postulates,software and AI author limit independence.
