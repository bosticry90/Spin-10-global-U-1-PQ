# Physical-tangent root: actual vertex contraction and positive heat

Requires successful IGR2 normalization and model receipts. In the complete
ordered positive-heat root,select only M_(P,C). The trace starts on a
quantum ghost,passes a ghost/scalar current and a Yukawa endpoint,then
ends in M_(P,C). G0 K0 on the last fermion leg cancels in the displayed
Gt Rt order,leaving1-E. A swapped Rt Gt order is a different expression.
No fermion numerator or closed spin trace remains. The full mixed P/S
inverse identity is an inherited exact premise before this simplification.

The literal action/Hessian and independent Schur calculation determine
the source order and the open mass bilinear sign,not the desired Ward
sum. The qualified classical Yukawa relation B R_a=-ig L(T_C,a) B
then converts the two symmetric physical fermion endpoints into the
actual source representation. This is an algebraic vertex identity,not
an assignment of an unmeasured quantum insertion from known breakings.

Define Wj_c=sum_a R_a Gx Pj_c^T Gca^T with actual metrics and source
charts. Independently calculate these coefficients from classical data.
Use the full EDS equality W0+W1+W2=0 only after it is checked. The
normalized candidate heat polynomial to test from the actual Gaussian is

    -(1-E) B[E^2 W0+E^3 W1+E^4 W2]
      = -B W0 E^2(1-E)^2+B W2 E^3(1-E)^2.

This subgroup has exactly the8 directed IGR1 words. Mu has no matter
source row. The baseline S0 diagram does not fit these8 words even
though it fits other parts of the complete root. Ordinary width/mass
parameters and every auxiliary Gr_LL path remain in Wj.

In common hbar/(16pi^2) units,positive radial integration gives

    int E^a(1-E)^2 dQ/Q=log[(a+1)^2/(a(a+2))].

It is IR integrable after combination;do not integrate separated critical
terms. Thus this tested heat-member coefficient would be

    -B W0 log(9/8)+B W2 log(16/15).

The log5 period in the second term is not set to0 by the older source
periods. Other root groups must actually be measured before any sum or
cancellation claim. The local-jet argument is the finite-word CSW/EDS
nonexceptional Euclidean relative estimate. No full finite-p kernel,
constant-vacuum trace or new IR contact condition is supplied here.
