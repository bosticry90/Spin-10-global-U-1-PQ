# IGR1: complete intrinsic ordered regulator family and classical inputs

Freeze before computation,October25,2026,base25751c3bb2f6190515babb0927b25dc30b012504.
Question: what COMPLETE finite ordered trace family must be evaluated for
the first-intrinsic-grade u-C-PP root? IGH fixes the hatted local limit
and QG tangent,but does not measure this root. In particular,the baseline
GF a-C-x current could participate with the u bosonic inverse response;
it was unnecessary for ISG's source-only loop. Audit it before sewing.

Original unshifted SMA/CSW/EDS action,A0,constant first even u,one ordinary
external C,two physical P,ordinary external jet0,intrinsic coefficient-
dimension1. Actual328 scalars/45 colors and generic Yukawas;fixed reference
and heat per free edge. No translated mass,full massive inverse,physical
benchmark,scheme or finite normalization adopted. Construct the local
operator INPUT/family,not a measured finite root or restored Ward identity.

Extract the baseline positive a-C-x density from the FULL raw GF,with
left/right antighost derivatives,actual scalar/ghost/antighost frames and
Euclidean action sign. Primary transports literal legs first;replay forms
raw tensors then transports. Audit dimension-one quadratic ghost/scalar
principal candidates too. Compare all entries/zeros. A nonzero current
does not imply a nonzero final quantum diagram. Preserve zero outcomes.

Construct the full original first field tangent on the one-C physical
mean ideal from all643 actual master maps. Derive raw right derivatives
versus converted left derivatives,then transport field/ghost slots. Retain
all four B components,the scalar,auxiliary,ghost and antighost diagonal
C matrices and the affine B<-partial C,a<-Lambda entries. Classify all
other terms only after differentiation. Matter has the actual SMA P<-C P
and diagonal P-C terms;no sterile transformation. Reuse qualified original
Clifford/kinetic action and finite source conventions,not a commuting
one-charge approximation. Bind actual Tminus/B10/B126 for later sewing.

Use Vu=QG'' and Mu=the actual QG tangent. Retain both
STr(-Gt Vu Gt Rt M0) and STr(Gt Rt Mu),or their equivalent positive-heat
Neumann words. Enumerate directed tangents as a DISTINGUISHED final factor;
do not symmetrize a noncommuting word or add a logarithm's1/n. Ordinary
vertices include N0_Lx,J0_aB/aL,S0_ax,gP,yP;probe vertices include
U_BB/BL/LL,Nr_Bx/Lx,Ju_aB/aL,Su_ax. No unlabeled marginal cubic with
three internal ports enters a bridgeless one-loop cycle. Positive physical
quadratic completeness is inherited from MDS's actual AST audit.

M0 includes affine B<-C,a<-L,P<-C(P external),and diagonal B,L,x,P,a,C
with one external C. Mu includes a<-B/L,positive a<-x and C-dependent
a<-a. The actual QG Lambda C-C-a first tangent has no one-C mean term;
this is not a connected/source-Hessian zero. Compare directed walks with
independent degree-saturated vertex multisets/permutations through order6;
prove the external/grade bound on higher orders. Record the exact words,
their heat factors/sign(-1)^n,connectedness and which omission controls
are sensitive. Counts are support evidence,not measured quantum tensors.

Possible outcomes: complete operator input/family;additional actual type
requiring continuation;actual missing current;structural zero;incomplete
or failed preparation/calculation. Unexpected tangent types,unmatched
principal changes,frame/derivative disagreement or truncated word domain
stop the affected claim. No target value or desired Ward cancellation is
used. Next evaluate this family with its actual Lorentz/Grassmann/color
contractions;only then compare known ISG and ordinary finite coefficients.

Two sequential workers300s afterimports,verifier120s,8GiBsampledprivate,
350MiBlaunchfloor,16MiBpacket. Freeze inputs/code/copies/proof first;
preserve failures and all captures. No cap expansion,truncation or silent
retry. State113/34of39,E5A5open,custodyexit2sevenNOTPASS. No agents,
branches/worktrees,push/outreach/publication,foundational/scheme/benchmark
adoption,flavor/HB1C5 activation or protected promotion. Shared action,
charts,software and AI author limit independence. Keep goal ACTIVE.
