# IGR2: independently evaluate the complete P<-C root subgroup

Freeze after IGR1 actual receipts/before computation. The complete root
has76 directed words;exactly8 end in the original physical P<-C tangent.
None of those8 contains baseline S0;this follows the complete typed
envelope,not an assumption that S0 vanishes. Evaluate this indispensable
subgroup now,retaining the other68 words for the full root calculation.

Same original unshifted constant-first-u intrinsic-dimension1 local C-PP
domain. Fixed-heat strict4D member BEFORE heat removal. Full split inverse
is retained until G0 K0=1 in Gt Rt;then no fermion free edge remains in
this subgroup. This cancellation,not deletion of the sterile field or
a4x4 BMHV surrogate,permits the physical four-spinor normalization witness.

Derive the universal coefficient from a literal paired-momentum graded
Gaussian with scalar x,ghost C/a,one physical Nambu P and free sterile S.
The ordinary current is z*a*C_external*x,the Yukawa endpoint is i*y*x*chi,
the source is2g*Jx*C_quantum*x,and qP=ig*C_quantum*chi*P_external.
The source is Jx before C_external. Preserve actual onehalf supertrace-log,
both momentum partners,source signs and the mass-pair normalizer.
Primary left-Hessian Neumann root and replay right-Hessian Schur inverse
must agree. Save actual root/source values before testing the derived
source-tangent relation;the Ward remainder is not an input. This is an
algebra normalization fixture,not a replacement physical U1 model.

Sew actual EDS paths/actual scalar and ghost metrics through the full45
scalar representation from IGR1 and B10/B126. Primary contracts physical
source generators;replay pulls endings back to raw master scalar maps.
Keep noncommuting color order,all328 scalars/both probes/zeros and generic
symmetric family Yukawas. Do not read ISG quantum tables or its known
Ward remainder during either calculation. The actual classical Yukawa
source bridge is a qualified premise,not an average-charge approximation.

Output full heat-period coefficient matrices and independently integrate
the combined positive-heat polynomial. Derive Gaussian radial differences
versus a positive heat-length representation/quadrature. Wrong root order
or missing tangent/path must be a sensitive control where applicable;
otherwise report insensitivity honestly. Finite-p/repeated insertion,
joint BMHV limits,all other root words,full Ward/common counterterm/QAP,
measure/phase/E5/A5/physical unification remain unqualified.

Two sequential workers300s afterimports,verifier120s,8GiBsampledprivate,
350MiBlaunchfloor,16MiBpacket shared with IGR1. Freeze code/copies/new
manifest first;preserve exact failures and full captures. No physics,
normalization baseline,resource expansion or authority change. After this
subgroup,continue the rest of the actual root with baseline S0 and direct
Mu contributions. Do not infer their coefficients from the required sum.
