from pathlib import Path
from hashlib import sha256
import json,gzip,sys,ast,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/intrinsic-ghost-root-v1-2026-10-25');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
def dump(p,z):
 with p.open('xb') as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
stage='preparation'
try:
 b=dict(json.loads((O/'validation_preparation.json').read_bytes())['input_sha256'])
 for n in ['validation_preparation.json','validation_receipt.json','verify_capture.json']:
  p=O/n;b[str(p)]=sha256(p.read_bytes()).hexdigest()
 for n in ['PC_RECORD.md','PC_PROOF.md','pc.py','pc_verify.py','run_pc.py']:
  p=O/n
  if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
  with(O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
  b[str(p)]=sha256(p.read_bytes()).hexdigest();b[str(O/(n+'.source.txt'))]=b[str(p)]
 dump(O/'pc_preparation.json',{'input_sha256':b,'worker_seconds_after_imports':300,'verifier_seconds_after_imports':120,'scientific_acceptance':'NOT_PERFORMED'})
 for role in ['primary','replay','verify']:
  stage=role
  if role=='verify':
   v=dict(b)
   for n in ['pc_preparation.json','pc_primary_result.json','pc_primary_capture.json','pc_primary_tables.json.gz','pc_replay_result.json','pc_replay_capture.json','pc_replay_tables.json.gz']:p=O/n;v[str(p)]=sha256(p.read_bytes()).hexdigest()
   dump(O/'pc_validation_preparation.json',{'input_sha256':v})
  z=capture([sys.executable,'-B',str(O/('pc_verify.py' if role=='verify' else'pc.py'))]+([] if role=='verify' else[role]));dump(O/('pc_'+role+'_capture.json'),z);dump(C/('pc_'+role+'_full_capture.json'),z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(x['private_bytes'] for x in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(x[7:]) for x in z['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<(120 if role=='verify' else 300)
  if role!='verify':
   blob=(O/('pc_'+role+'_tables.json.gz')).read_bytes();assert sha256(blob).hexdigest()==rr[0]['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==rr[0]['raw_sha256']
  dump(O/('pc_validation_receipt.json' if role=='verify' else'pc_'+role+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<16*1024**2;print('COMPLETED_IGR2',role,rr[0]['elapsed_after_imports'],flush=True)
except BaseException:
 dump(O/'pc_controller_failure.json',{'execution_state':'FAILED','stage':stage,'traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
