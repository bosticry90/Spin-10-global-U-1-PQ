from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,gzip,time,threading,os
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/(r+'_tables.json.gz')) for r in ['primary','replay']]
for k in a:
 if k!='role':assert a[k]==b[k],k
assert len(a['S0_physical_current'])==45 and a['dimension1_quadratic_ghost_scalar_events']==0 and a['sixth_order_target_empty'] and a['sterile_endpoint_exclusion_after_full_inverse_support'] and not a['finite_quantum_root_tensor_or_Ward_QAP_authority_measured']
words=a['ordered_root_words'];assert len({json.dumps(w,sort_keys=True) for w in words})==len(words);assert a['S0_word_count']>0 and a['Mu_word_count']>0 and a['omit_PC_word_count']<len(words)
noamp=['M_aa_C','M_CC_C','Mu_aa_C'];assert not any(mn in noamp for mn,ww in words)
types=Counter(mn for mn,ww in words);powers=Counter(len(ww) for mn,ww in words)
fullpos=45*45*328;diagpos=sum(45*Ms[0]['shape'][0]**2 for Ms in a['M0_diagonal_C'].values());nonzeros={k:sum(len(M['entries']) for M in Ms) for k,Ms in a['M0_diagonal_C'].items()}
out={'schema':'IGR1_VALIDATION','elapsed_after_imports':time.perf_counter()-tick,'literal_frame_first_and_raw_tensor_transport_routes_agree':True,'right_and_converted_left_master_derivatives_agree':True,'S0_raw_density_rows':a['raw_baseline_ghost_scalar_rows'],'S0_complete_positions_including_zeros':fullpos,'S0_nonzero_positions':a['S0_nonzero_positions'],'S0_raw_frame_control_difference_positions':a['S0_raw_frame_control_difference_positions'],'M0_full_diagonal_C_positions_including_zeros':diagpos,'M0_nonzero_positions':nonzeros,'affine_BC_four_axes_and_aLambda_units_passed':True,'master_tangent_events':a['raw_master_tangent_events'],'master_deferred_after_differentiation':a['master_deferred_after_differentiation'],'walk_and_saturated_multiset_directed_root_words_agree':True,'root_words':len(words),'root_words_by_tangent':dict(sorted(types.items())),'root_words_by_length':dict(sorted(powers.items())),'root_words_with_baseline_S0':a['S0_word_count'],'root_words_with_direct_Mu':a['Mu_word_count'],'root_words_lost_by_omitting_PC':len(words)-a['omit_PC_word_count'],'diagonal_ghost_tangents_structurally_absent_from_this_matter_projection':noamp,'order6_empty_and_higher_grade_bound':True,'finite_quantum_root_tensor_Ward_QAP_or_authority_qualified':False}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
