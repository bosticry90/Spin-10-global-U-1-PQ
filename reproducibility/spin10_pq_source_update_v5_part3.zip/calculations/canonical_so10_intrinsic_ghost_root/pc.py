from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json,gzip,sys,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'pc_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and (p.name.startswith('pc_'+('replay' if role=='primary' else'primary')) or p.name.startswith('replay' if role=='primary' else'primary')):raise PermissionError('IGR2_PEER_DENIED')
  if p.parent.name in ['canonical_so10_intrinsic_scalar_source_ghost','canonical_so10_finite_intrinsic_mixed_response'] and ('tables' in p.name or 'receipt' in p.name):raise PermissionError('IGR2_OLD_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard);g,y,z,E=s.symbols('g y z E',real=True)
def ap(A,B):
 out=dict(A)
 for k,v in B.items():out[k]=s.expand(out.get(k,0)+v)
 return{k:v for k,v in out.items() if v!=0}
def ax(A,z):return{k:s.expand(v*z) for k,v in A.items() if s.expand(v*z)!=0}
def am(A,B):
 out={}
 for aa,v in A.items():
  for bb,w in B.items():
   if aa&bb:continue
   sg=(-1)**sum((bb&((1<<i)-1)).bit_count() for i in range(aa.bit_length()) if aa&(1<<i));kk=aa|bb;out[kk]=s.expand(out.get(kk,0)+sg*v*w)
 return{k:v for k,v in out.items() if v!=0}
def term(seq,co=1):
 out={0:s.sympify(co)}
 for v in seq:out=am(out,v)
 return out
def der(A,var,right=False):
 if isinstance(var,s.Symbol):return{k:v for k,co in A.items() if(v:=s.diff(co,var))!=0}
 return{k^(1<<var):(-1)**((k>>(var+1)).bit_count() if right else(k&((1<<var)-1)).bit_count())*v for k,v in A.items() if k&(1<<var)}
def proj(A,bos):
 return{k:s.expand(v.subs({b:0 for b in bos})) for k,v in A.items() if k<32 and any(k&~t==0 for t in [12,15,18]) and s.expand(v.subs({b:0 for b in bos}))!=0}
def mm(A,B):
 rows={};out={}
 for(k,j),v in B.items():rows.setdefault(k,[]).append((j,v))
 for(i,k),v in A.items():
  for j,w in rows.get(k,[]):
   vv={a:q for a,q in am(v,w).items() if any(a&~t==0 for t in [12,15,18])};vv=ap(out.get((i,j),{}),vv)
   if vv:out[i,j]=vv
   else:out.pop((i,j),None)
 return out
def ma(A,B):
 out=dict(A)
 for k,v in B.items():
  vv=ap(out.get(k,{}),v)
  if vv:out[k]=vv
  else:out.pop(k,None)
 return out
neg=lambda A:{k:ax(v,-1) for k,v in A.items()};ms=lambda A,t:{k:ax(v,t) for k,v in A.items()};eye=lambda N:{(i,i):{0:s.S.One} for i in range(N)};sca=lambda N,t:{(i,i):{0:t} for i in range(N)}
def tr(A,par):
 out={}
 for(i,j),v in A.items():
  if i==j:out=ap(out,ax(v,(-1)**par[i]))
 return out
def block(A,ii,jj):
 ir={v:i for i,v in enumerate(ii)};jr={v:j for j,v in enumerate(jj)};return{(ir[i],jr[j]):v for(i,j),v in A.items() if i in ir and j in jr}
def join(A,B,C,D,nb):
 out=dict(A);out.update({(i,j+nb):v for(i,j),v in B.items()});out.update({(i+nb,j):v for(i,j),v in C.items()});out.update({(i+nb,j+nb):v for(i,j),v in D.items()});return out
norms=[]
for side in ['left','right']:
 pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)];gam=[s.kronecker_product(pa[1],v) for v in pa]+[s.kronecker_product(pa[0],s.eye(2))];chi=s.prod(gam);PL=(s.eye(4)+chi)/2;PR=s.eye(4)-PL;C=gam[1]*gam[3];L=PL if side=='left' else PR;basis=L.columnspace();ext=[ap(ax({4:1},basis[0][i]),ax({8:1},basis[1][i])) for i in range(4)];eps={1:1};cext={2:1};Jx={16:1};bos=list(s.symbols('xplus xminus'));names=['xplus','xminus','Cplus','Cminus','aplus','aminus']+[f'{q}{sg}{i}' for q in ['P','S'] for sg in ['plus','minus'] for i in range(4)];NN=22;par=[0,0]+[1]*20;variables=bos+list(range(5,25));fields=[{0:b} for b in bos]+[{1<<j:1} for j in range(5,25)];ix={n:i for i,n in enumerate(names)};fv=lambda n:fields[ix[n]]
 def bil(ll,K,rr):
  out={}
  for i in range(len(ll)):
   for j in range(len(rr)):
    if K[i,j]:out=ap(out,term([ll[i],rr[j]],K[i,j]))
  return out
 S0=term([fv('xminus'),fv('xplus')]);S0=ap(S0,ap(term([fv('aminus'),fv('Cplus')]),term([fv('aplus'),fv('Cminus')])));V={}
 for label in ['P','S']:S0=ap(S0,bil([fv(label+'minus'+str(i)) for i in range(4)],s.I*C*gam[3],[fv(label+'plus'+str(i)) for i in range(4)]))
 for sig in ['plus','minus']:
  other='minus' if sig=='plus' else'plus';V=ap(V,term([fv('a'+other),cext,fv('x'+sig)],z));V=ap(V,term([Jx,fv('C'+sig),fv('x'+other)],2*g));V=ap(V,term([fv('x'+other),bil(ext,s.I*y*C*chi,[fv('P'+sig+str(i)) for i in range(4)])]))
 def hess(A):
  out={}
  for i in range(NN):
   first=der(A,variables[i],right=role=='replay')
   for j in range(NN):
    vv=proj(ax(der(first,variables[j],right=role=='replay'),(-1)**par[i] if role=='replay' else(-1)**(par[j]*(par[i]+1))),bos)
    if vv:out[i,j]=vv
  return out
 H0=hess(S0);HH=hess(ap(S0,V));VV=ma(HH,neg(H0));K=s.Matrix(NN,NN,lambda i,j:H0.get((i,j),{}).get(0,0));Gi=K.inv();G0={(i,j):{0:v} for i in range(NN) for j in range(NN) if(v:=Gi[i,j])!=0};assert mm(H0,G0)==mm(G0,H0)==eye(NN);M={}
 for sig in ['plus','minus']:
  for i in range(4):
   cc={}
   for j in range(4):cc=ap(cc,ax(ext[j],chi[i,j]))
   delta=term([eps,fv('C'+sig),cc],s.I*g)
   for j in range(NN):
    val=proj(der(delta,variables[j],right=True),bos)
    if val:M[ix['P'+sig+str(i)],j]=val
 EG=ms(G0,E);RR=ms(H0,1/E-1);log={};root={};Gfull={}
 if role=='primary':
  A=mm(EG,VV);pw=eye(NN)
  for n in range(5):
   Gfull=ma(Gfull,ms(mm(pw,EG),(-1)**n))
   if n:log=ap(log,ax(tr(pw,par),s.Rational((-1)**(n+1),2*n)))
   root=ap(root,ax(tr(mm(ms(pw,1-E),M),par),(-1)**n));pw=mm(pw,A)
  assert not pw
 else:
  bb=list(range(2));ff=list(range(2,NN));Dinv=ms(block(G0,ff,ff),E);Af=ms(block(G0,bb,bb),E);BB=block(HH,bb,ff);CC=block(HH,ff,bb);assert block(HH,ff,ff)==block(H0,ff,ff);Sp=neg(mm(mm(BB,Dinv),CC));X=mm(Af,Sp);pw=eye(2);Sinv={}
  for n in range(5):
   Sinv=ma(Sinv,ms(mm(pw,Af),(-1)**n))
   if n:log=ap(log,ax(tr(pw,[0,0]),s.Rational((-1)**(n+1),2*n)))
   pw=mm(pw,X)
  assert not pw
  bf=neg(mm(mm(Sinv,BB),Dinv));fb=neg(mm(mm(Dinv,CC),Sinv));ffp=ma(Dinv,mm(mm(mm(mm(Dinv,CC),Sinv),BB),Dinv));Gfull=join(Sinv,bf,fb,ffp,2);assert mm(ma(ms(H0,1/E),VV),Gfull)==eye(NN);root=tr(mm(mm(Gfull,RR),M),par)
 kap=s.expand(bil(ext,C*L/2,ext).get(12,0));assert kap!=0;rv=s.simplify(root.get(15,0)/(2*kap));sv=s.simplify(-log.get(18,0)/2) # Jx BEFORE Cexternal,opposite canonical bit order
 wrong=s.simplify(tr(mm(mm(RR,Gfull),M),par).get(15,0)/(2*kap));row={'side':side,'root_PC':str(rv),'source_Jx_before_C':str(sv),'mass_pair_normalizer':str(kap),'wrong_Rt_Gt_order':str(wrong)}
 with(O/(f'pc_{role}_{side}_precheck.json')).open('xb') as f:f.write((json.dumps(row,sort_keys=True)+'\n').encode())
 assert s.expand(rv-(1-E)*y*sv)==0 and s.expand(rv+2*g*y*z*E**2*(1-E))==0;norms.append(row)
print('STAGE IGR2 '+role+' literal Gaussian normalization',flush=True)

# Model contraction from classical endings and field maps,not ISG quantum tables.
d=load(O/(role+'_inputs.json.gz'));op=load(O/(role+'_tables.json.gz'));assert sum(mn=='M_PC' for mn,ww in op['ordered_root_words'])==8 and not any(mn=='M_PC' and any(v[4]=='S0_ax' for v in ww) for mn,ww in op['ordered_root_words']);g10,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g10,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(t):return s.sympify(t,locals=loc)
dec=lambda q:s.SparseMatrix(*q['shape'],{(i,j):parse(v) for i,j,v in q['entries']});cl=lambda A:s.SparseMatrix(A).applyfunc(s.expand);enc=lambda A:{'shape':list(A.shape),'entries':[[i,j,str(v)] for(i,j),v in sorted(cl(A).todok().items()) if v]};ref=d['frame'];xs=d['xs'];order=ref['field_order'];phys=[f'B{i}_{mu}' for i in range(45) for mu in range(4)]+xs+[('b' if i<12 else'L')+str(i) for i in range(45)]+['C'+str(i) for i in range(45)]+[('bar' if i<12 else'ub')+str(i) for i in range(45)];ri={n:i for i,n in enumerate(order)};pi={n:i for i,n in enumerate(phys)};TI=dec(ref['physical_to_raw_inverse']);TF=dec(ref['physical_to_raw_kernel'])
def blk(ns):return TI.extract([ri[n] for n in ns],[pi[n] for n in ns]),TF.extract([pi[n] for n in ns],[ri[n] for n in ns])
Tx,Fx=blk(xs);Tc,Fc=blk(['C'+str(i) for i in range(45)]);Ta,Fa=blk([('bar' if i<12 else'ub')+str(i) for i in range(45)]);Gx=cl(Fx*Fx.T);Gca=cl(Fc*dec(ref['raw_ghost_Green'])*Fa.T);Rphys=list(map(dec,op['M0_diagonal_C']['x']));rawrows=[]
for ii,name in enumerate(xs):
 for row in d['master_maps'][name]:
  ww=row['word'];assert len(ww)==2 and all('__' not in n for n in ww);cn=next(n for n in ww if n.startswith('C'));xn=next(n for n in ww if n.startswith('x_'));rawrows.append((ii,int(cn[1:]),xs.index(xn),parse(row['coefficient'])))
def contract(endings):
 out=s.zeros(328,45)
 for c,zz in enumerate(endings):
  S=dec(zz) if isinstance(zz,dict) else zz
  if not S.todok():continue
  if role=='primary':
   pull=cl(Gx*S.T*Gca.T);out[:,c]=cl(sum((Rphys[a]*pull[:,a] for a in range(45) if any(pull[:,a])),s.zeros(328,1)))
  else:
   pull=cl(Tx*Gx*S.T*Gca.T*Tc.T);col=s.zeros(328,1)
   for ii,a,jj,co in rawrows:
    if pull[jj,a]:col[ii]+=co*pull[jj,a]
   out[:,c]=cl(Fx*cl(col))
 return cl(out)
model=[]
for probe,rows in enumerate(d['endings']['mixed']):
 W0=contract([q['pieces'][0] for q in rows]);W1=contract([cl(dec(q['pieces'][1])+dec(q['pieces'][3])) for q in rows]);W2=contract([q['pieces'][2] for q in rows]);assert not cl(W0+W1+W2).todok();images={}
 for label in ['B10','B126']:
  B=cl(dec(d['matter_classical'][label])*Tx);V0=cl(B*W0);V2=cl(B*W2);assert all(s.simplify(s.im(v))==0 for W in [W0,W2] for v in W.todok().values());images[label]={'log9over8':enc(-V0),'log16over15':enc(V2),'formal_conjugate_log9over8':enc(-V0.conjugate()),'formal_conjugate_log16over15':enc(V2.conjugate())}
 model.append({'probe':probe,'classical_W0':enc(W0),'classical_W2':enc(W2),'root_PC_mass_periods':images});print('STAGE IGR2 '+role+' full model probe '+str(probe),flush=True)
mp.mp.dps=60;radials=[]
for aa in [2,3]:
 if role=='primary':value=mp.quad(lambda q:mp.exp(-aa*q)*(-mp.expm1(-q))**2/q,[0,1,mp.inf])
 else:value=mp.quad(lambda ll:1/ll-1/(ll+1),[aa,aa+1])
 exact=mp.log(mp.mpf((aa+1)**2)/(aa*(aa+2)));assert abs(value-exact)<mp.mpf('1e-30');radials.append({'a':aa,'value':mp.nstr(value,50),'exact':mp.nstr(exact,50)})
out={'schema':'IGR2_PC_SUBGROUP','role':role,'literal_normalizations':norms,'models':model,'radials':radials,'old_quantum_targets_denied':True,'other_root_groups_or_full_Ward_QAP_authority':False};blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/('pc_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(gzip.decompress(blob)).hexdigest()},sort_keys=True),flush=True);timer.cancel()
