# Actual intrinsic regulator input and a measured physical-tangent subgroup

October25,2026. PROGRESS,base25751c3bb2f6190515babb0927b25dc30b012504.
The full first-intrinsic-grade u-C-PP regulator root is reduced to76
directed ordered trace words with its actual classical inputs. One
complete subgroup,ending in the physical P<-C tangent,is now calculated
and is nonzero. The other groups and complete Ward sum remain unmeasured.
State113/authority34of39,E5/A5open,custodyexit2/sevenNOTPASS are unchanged.

## A baseline current must be retained in the full root

The complete raw GF contains6688 derivative-free a-C-x density rows.
Transporting actual scalar,ghost and antighost legs gives6268 nonzero
physical current positions in the45x45x328 domain (664200 positions
including zeros). Literal frame-first and raw-tensor-first derivations
agree. Omitting the frame transport changes12391 positions. The selected
dimension-one quadratic ghost/scalar principal candidates are absent.

This baseline S0 current did not contribute to ISG's source-only u loop.
It CAN occur with the u-dependent bosonic response and two fermion
endpoints in the full regulator root. Six directed words contain it.
Their actual amplitudes are not yet evaluated;nonzero vertex data do
not prove a nonzero final diagram. It must not be dropped without that
calculation or an actual complete structural cancellation.

## Complete original tangent and positive-heat root family

All643 original master field maps are differentiated before applying
the one-C,physical-mean ideal. Right quantum-field derivatives and
converted left derivatives agree after full frame transport. This
checks5479155 diagonal-C matrix positions including zeros. The four
affine B<-partialC matrices and a<-Lambda are the required+i units
in the existing unit-momentum Euclidean chart. The full-D split inverse
and matter transformation are inherited SMA premises,not replaced here.

The836 higher-field terms are deferred only after the first derivative;
the higher source-Hessian/contact terms remain separate. The new Mu
still comes from actual QG,with its antighost row and the already checked
R_u a=-2i X_G Lambda relation. G's rho auxiliary row is not reused
without that transport.

With the fixed regulator,the exact first-u root is

    [STr(-Gt Vu Gt Rt M0+Gt Rt Mu)]_(C PP), Vu=QG''.

The equivalent positive-heat words are

    sum_n(-1)^n STr[(E G0 V)^n(1-E)M].

No inverse heat remains in the target. Matrix order,derivative adjoints
and the distinguished tangent are retained;there is no logarithm's1/n.
Directed walks and independent degree-saturated multisets/permutations
agree on all76 words:

| Final tangent | Words |
| --- | ---: |
| Original B<-C |16|
| Original a<-Lambda |16|
| Original P<-C |8|
| C-dependent B diagonal |8|
| C-dependent Lambda diagonal |4|
| C-dependent scalar diagonal |8|
| C-dependent physical fermion diagonal |8|
| Probe a<-B |4|
| Probe a<-Lambda |2|
| Probe a<-x |2|

Word lengths2/3/4/5 have1/22/39/14 entries. Order6 is empty and the
external/grade bound excludes all higher orders. Diagonal ghost and
antighost tangents have no connected matter loop in this projection.
Sterile endpoints are absent from these positive-heat root words only
after the full inverse support and G0 K0 cancellation;internal hatted
denominators and dimensional continuation are not erased generally.

These counts describe an exact calculation family,not measured values,
particles or a completion percentage. In particular,the remaining68
words cannot be assigned the difference required by the Ward identity.

## Independently measured physical-tangent subgroup

The P<-C subgroup contains8 complete directed words. None contains S0.
Mu has no matter/source row. Its actual ordered Gt Rt form cancels the
last fermion G0 K0 and leaves1-E. No fermion free numerator remains in
this subgroup;the cancellation is performed before any four-spinor
normalization. This is not a four-dimensional model of BMHV gamma5.

A literal paired-momentum left-Hessian Neumann calculation and a
right-Hessian block-Schur/Berezin calculation independently fix the
open mass/source normalization for both chiralities. For a generic
current z*a*Cexternal*x,the actual normalized values are

    source,order Jx before C: -2g z E^2,
    physical-tangent root:   -2g y z E^2(1-E).

The onehalf supertrace-log,paired momentum factor and actual mass-pair
normalizer are explicit. Exact values are saved before testing their
relation. Swapping Rt/Gt gives0,which fails this nonzero target for
both chiralities. It is a sensitive matrix-order control.

Full Spin(10) sewing then uses actual scalar representations,metrics,
Yukawa maps and the ordered EDS paths. The physical-generator route and
raw-master-source pullback route agree on59040 classical source-map
positions and184320 period/conjugate positions including zeros. No ISG
quantum target or Ward remainder is read by these workers. Generic
symmetric family Yukawas and the formal conjugate program are retained;
no numeric flavor choice or extra family factor is introduced.

Let Wj denote these newly contracted actual EDS current paths and B the
proper Yukawa map. After checking W0+W1+W2=0,the measured leading heat
polynomial is

    -B W0 E^2(1-E)^2+B W2 E^3(1-E)^2.

Combined radial integration gives,in common hbar/(16pi^2) units,

    ROOT_PC = -B W0 log(9/8)+B W2 log(16/15).

Positive radial Gaussian integration and a separate heat-length integral
agree;the antiderivative proves the displayed logarithms exactly. The
two finite numerical comparisons use60digits/50stored and meet1e-30;
stored discrepancies0 are not claims of exact numerical integration.
The combined squared1-E factors retain IR integrability of the local jet.
The stated strict-heat member precedes heat removal;the complete joint
BMHV limit of the whole root is not established here.

The unbroken probe and10 Yukawa image vanish. The broken126 image has65
nonzero holomorphic positions in EACH period,with its formal conjugate
stored separately. These are period coefficients,not independent
physical observables. At flattened mass row63/ghost43,the coefficient is

    sqrt(30)xi^2[17g10^2 log(9/8)/50
                +(g10^3/5-17g10^2/50)log(16/15)].

The log5 dependence is retained;it cannot be silently identified with
the older source periods. The other actual regulator groups must be
calculated before testing the full sum. A formal conjugate program does
not by itself prove the full Lorentzian source-involution theorem.

## Verification,resources and interpretation

All preparers/workers/verifiers completed on their first frozen versions.
No failed or unfinished scientific run occurs in this packet. Earlier
predecessor failures remain unchanged. Before freezing,ordinary source
editing included a lexical whitespace correction;no failed worker or
diagnostic replay is fabricated for that unexecuted draft.

| Stage | Seconds after imports | Samples | Maximum sampled private bytes |
| --- | ---: | ---: | ---: |
| Input/family primary |9.8548273|6|123191296|
| Input/family replay |8.2136846|5|120684544|
| Input/family verifier |0.0480761|1|397312|
| Physical-tangent primary |8.4153086|5|120307712|
| Physical-tangent replay |13.0717349|8|121827328|
| Physical-tangent verifier |0.2574273|1|393216|

Samples are not continuous peaks;both short verifiers have startup-only
samples. Worker caps300s,verifiers120s,8GiBsampledprivate/350MiBlaunchfloor/
16MiBpacket held. Eleven source copies;bindings45/53/66/73. Receipt SHA256:

- IGR1:3d87296328bc9b756308d3f165f343713b6f0ac71e053bc02fac4b601f4d35cd.
- IGR2:314a9ee6508763ff0d3e07b61405c31ee37de5d213217eabce6ce49a7d6f8e96.

Full captures/readiness/preservation seals are retained externally under
intrinsic-ghost-root-v1-2026-10-25. E4 returned native0 and step exits
[0,0,0,0,0,2]. It authenticates existing evidence,not fresh independent
physics. Historical custody remains sevenNOTPASS.
All prior tracked files and scientific authority are preserved.

This demonstrates actual missing-input detection,complete ordered-family
reduction and a nonzero regulator coefficient with a sensitive order
control. Shared action,source/Clifford conventions,data,software and AI
author limit independence. No external validation,experimental inference
or proof-assistant certification is claimed.

## Continue the remaining complete regulator groups

Evaluate the other68 words using the actual baseline S0,non-Abelian
diagonal tangents and direct Mu rows. A boson/fermion Schur reduction is
the least expensive next candidate method;the ghost current touches the
antighost port and its free a-a inverse is0,which may simplify the
source-free inverse before the one directed tangent is inserted. Prove
that reduction and all signs before transferring coefficients.

The known ordinary mass variation,ISG scalar-source Euler contribution
and IGH leading-local hatted zero are late comparisons. Full source/Euler
support,regulator/contact consistency,common finite prescription,QAP,
measure/global phase,source reality,causal/constant-vacuum physical
limits,E5/A5 and physical unification remain open. No counterterm or
finite baseline has been installed. Goal ACTIVE/INCOMPLETE.
