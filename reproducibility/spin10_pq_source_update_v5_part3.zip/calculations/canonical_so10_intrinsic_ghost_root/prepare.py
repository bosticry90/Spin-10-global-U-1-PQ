from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess,ast
O=Path(__file__).resolve().parent;R=O.parents[1];read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();b={};assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='25751c3bb2f6190515babb0927b25dc30b012504'
S=O.parent/'canonical_so10_intrinsic_scalar_source_ghost';I=O.parent/'canonical_so10_intrinsic_ghost_hatted';sm=read(S/'preparation.json')['input_sha256'];im=read(I/'preparation.json')['input_sha256'];pp=R/'tools/portable_dh_v1/inputs.json.gz';assert H(pp)==sm[str(pp)];pd=load(pp);b[str(pp)]=H(pp)
mu=I/'tangent_receipt_v2.json';bc=S/'yukawa_bridge_inputs.json.gz'
for p in [mu,bc]:assert p.read_bytes()==subprocess.check_output(['git','show','HEAD:'+p.relative_to(R).as_posix()],cwd=R);b[str(p)]=H(p)
for role in ['primary','replay']:
 sp=S/(role+'_inputs.json.gz');assert H(sp)==im[str(sp)];d=load(sp);out={k:d[k] for k in ['xs','frame','endings']};out['raw_GF']=pd['gauge_fixing_density'];out['master_maps']=pd['master_field_maps'];out['actual_Mu']=read(mu);out['matter_classical']=load(bc);dst=O/(role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 b[str(sp)]=H(sp);b[str(dst)]=H(dst)
for folder,ns in [('canonical_so10_intrinsic_ghost_hatted',['RECORD.md','PROOF.md','TANGENT_RECORD.md','validation_receipt.json','tangent_receipt_v2.json']),('canonical_so10_intrinsic_scalar_source_ghost',['RECORD.md','DERIVATION.md','validation_receipt.json','yukawa_bridge_receipt.json']),('canonical_so10_probe_mass_dimension_one',['RECORD.md','ENDING_RECORD.md','RESULT.md','validation_receipt.json','ending_validation_receipt.json','symbol_receipt.json']),('canonical_so10_cutoff_source_ward_operator',['DERIVATION.md','validation_receipt.json']),('canonical_so10_sterile_matter_action',['ACTION_V1.md','validation_receipt.json'])]:
 for name in ns:p=O.parent/folder/name;b[str(p)]=H(p)
for name in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V614.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']:
 p=R/name;b[str(p)]=H(p)
for name in ['RECORD.md','OPERATOR.md','prepare.py','native.py','verify.py','run.py']:
 p=O/name
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with(O/(name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 b[str(p)]=H(p);b[str(O/(name+'.source.txt'))]=H(p)
with(O/'preparation.json').open('xb') as f:f.write((json.dumps({'input_sha256':b,'worker_seconds_after_imports':300,'verifier_seconds_after_imports':120,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print('PREPARED_IGR1',len(b),flush=True)
