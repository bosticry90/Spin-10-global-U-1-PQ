from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from itertools import product,combinations_with_replacement,permutations
from functools import lru_cache
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay']
for p,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open' and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('replay' if role=='primary' else'primary'):raise PermissionError('IGR1_PEER_DENIED')
  if p.parent.name in ['canonical_so10_intrinsic_scalar_source_ghost','canonical_so10_finite_intrinsic_mixed_response'] and ('tables' in p.name or 'receipt' in p.name):raise PermissionError('IGR1_KNOWN_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard);d=load(O/(role+'_inputs.json.gz'));g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def parse(z):return s.sympify(z,locals=loc)
dec=lambda z:s.SparseMatrix(*z['shape'],{(i,j):parse(v) for i,j,v in z['entries']});cl=lambda M:s.SparseMatrix(M).applyfunc(s.expand);enc=lambda M:{'shape':list(M.shape),'entries':[[i,j,str(v)] for(i,j),v in sorted(cl(M).todok().items()) if v]}
xs=d['xs'];xid={n:i for i,n in enumerate(xs)};phys=[f'B{i}_{mu}' for i in range(45) for mu in range(4)]+xs+[('b' if i<12 else'L')+str(i) for i in range(45)]+['C'+str(i) for i in range(45)]+[('bar' if i<12 else'ub')+str(i) for i in range(45)];ref=d['frame'];order=ref['field_order'];ri={n:i for i,n in enumerate(order)};pi={n:i for i,n in enumerate(phys)};TI=dec(ref['physical_to_raw_inverse']);TF=dec(ref['physical_to_raw_kernel'])
def inf(n):
 if n.startswith('x_'):return'x',xid[n],None
 for pre,kk in [('bar','a'),('ub','a'),('L','L'),('b','L'),('C','C')]:
  if n.startswith(pre):return kk,int(n[len(pre):]),None
 if n.startswith('B'):
  aa,mu=n[1:].split('_');return'B',int(aa),int(mu)
 if n.startswith('A'):return'A',0,None
 raise AssertionError(n)
bases={'x':xs,'L':[('b' if i<12 else'L')+str(i) for i in range(45)],'a':[('bar' if i<12 else'ub')+str(i) for i in range(45)],'C':['C'+str(i) for i in range(45)]}
for mu in range(4):bases['B'+str(mu)]=[f'B{i}_{mu}' for i in range(45)]
T={k:TI.extract([ri[n] for n in ns],[pi[n] for n in ns]) for k,ns in bases.items()};F={k:TF.extract([pi[n] for n in ns],[ri[n] for n in ns]) for k,ns in bases.items()}
for k in T:assert not cl(F[k]*T[k]-s.eye(len(bases[k]))).todok() and not cl(T[k]*F[k]-s.eye(len(bases[k]))).todok()
def legcols(M):
 out=defaultdict(list)
 for(i,j),v in M.todok().items():out[i].append((j,v))
 return out
Tc,Ta,Tx=T['C'],T['a'],T['x'];clegs,alegs,xlegs=map(legcols,[Tc,Ta,Tx]);Sraw=[s.SparseMatrix(45,328,{}) for c in range(45)];Sphys=[s.SparseMatrix(45,328,{}) for c in range(45)];rawrows=0;positive_quadratic_events=[]
for row in d['raw_GF']:
 ww=[]
 for token in row['word']:
  nn,sep,I=token.partition('__');ww.append((nn,tuple(map(int,I))))
 if not all(n in ri for n,I in ww):continue
 kk=[inf(n)[0] for n,I in ww]
 if len(ww)==2 and sorted(kk) in [['C','a'],['x','x']] and sum(len(I) for n,I in ww)==1:positive_quadratic_events.append(row)
 if len(ww)!=3 or sorted(kk)!=['C','a','x'] or any(I for n,I in ww):continue
 ia=kk.index('a');ic=kk.index('C');ix=kk.index('x');aa=inf(ww[ia][0])[1];cc=inf(ww[ic][0])[1];xx=inf(ww[ix][0])[1];co=-parse(row['coefficient']);sg=(-1)**sum(k in ['a','C'] for k in kk[:ia]) if role=='primary' else(-1)**(sum(k in ['a','C'] for k in kk[ia+1:])+1);co=s.expand(sg*co);Sraw[cc][aa,xx]+=co;rawrows+=1
 if role=='primary':
  for(ap,av),(cp,cv),(xp,xv) in product(alegs[aa],clegs[cc],xlegs[xx]):Sphys[cp][ap,xp]+=co*av*cv*xv
if role=='replay':
 for c in range(45):Sphys[c]=cl(Ta.T*sum((Tc[b,c]*Sraw[b] for b in range(45) if Tc[b,c]),s.SparseMatrix(45,328,{}))*Tx)
Sphys=list(map(cl,Sphys));assert not positive_quadratic_events
rawframe_difference=sum(len(cl(Sraw[c]-Sphys[c]).todok()) for c in range(45));s0counts=[len(M.todok()) for M in Sphys]
print('STAGE IGR1 '+role+' full baseline a-C-x current '+str(sum(s0counts)),flush=True)

# Complete M0 field tangent at one external C,source0,other means0.
rawD={k:[s.SparseMatrix(len(ns),len(ns),{}) for c in range(45)] for k,ns in bases.items()};D={k:[s.SparseMatrix(len(ns),len(ns),{}) for c in range(45)] for k,ns in bases.items()};rawBC=[s.zeros(45) for mu in range(4)];rawaL=s.zeros(45);deferred=Counter();raw_events=0;legsT={k:legcols(M) for k,M in T.items()};legsF={k:legcols(M.T) for k,M in F.items()}
def mput(k,cc,ii,jj,co):
 global raw_events
 rawD[k][cc][ii,jj]+=co;raw_events+=1
 if role=='primary':
  for(op,ov),(cp,cv),(qp,qv) in product(legsF[k][ii],clegs[cc],legsT[k][jj]):D[k][cp][op,qp]+=co*ov*cv*qv
for name,rows in d['master_maps'].items():
 rk,ii,mu=inf(name);key='B'+str(mu) if rk=='B' else rk;pr=int(rk in ['C','a']);pq=1-pr
 for row in rows:
  ww=[]
  for token in row['word']:
   nn,sep,I=token.partition('__');ww.append((nn,tuple(map(int,I))))
  co=parse(row['coefficient']);ks=[inf(nn)[0] for nn,I in ww]
  if len(ww)==1:
   nn,I=ww[0];qk,jj,jmu=inf(nn)
   if rk=='B' and qk=='C' and I==(mu,):rawBC[mu][ii,jj]+=co
   elif rk=='a' and qk=='L' and not I:rawaL[ii,jj]+=co
   else:raise AssertionError(('UNMATCHED_AFFINE_TANGENT',name,row))
   continue
  if any(k=='A' for k in ks):deferred['background_terms_after_differentiation']+=1;continue
  if len(ww)!=2:
   assert len(ww)>=3;deferred['higher_field_terms_first_tangent_excluded_after_differentiation']+=1;continue
  matched=0
  for at,(nn,I) in enumerate(ww):
   qk,jj,jmu=inf(nn);other=ww[1-at];ok,cc,cmu=inf(other[0])
   if ok!='C' or qk!=rk:continue
   assert not I and not other[1] and (rk!='B' or jmu==mu)
   before=sum(inf(z)[0] in ['C','a'] for z,J in ww[:at]);after=sum(inf(z)[0] in ['C','a'] for z,J in ww[at+1:]);pquant=int(qk in ['C','a']);sg=(-1)**(pquant*after) if role=='primary' else(-1)**(pquant*before+pquant*(pq+1));mput(key,cc,ii,jj,s.expand(sg*co));matched+=1
  assert matched,('UNMATCHED_ONE_C_TANGENT',name,row)
if role=='replay':
 for k in bases:
  for c in range(45):D[k][c]=cl(F[k]*sum((Tc[b,c]*rawD[k][b] for b in range(45) if Tc[b,c]),s.SparseMatrix(len(bases[k]),len(bases[k]),{}))*T[k])
D={k:list(map(cl,Ms)) for k,Ms in D.items()};aff=[]
for mu in range(4):
 M=cl(F['B'+str(mu)]*rawBC[mu]*Tc*s.I);assert not cl(M-s.I*s.eye(45)).todok();aff.append(enc(M))
 assert all(not cl(D['B'+str(mu)][c]-D['B0'][c]).todok() for c in range(45))
aL=cl(F['a']*rawaL*T['L']*(-s.I));assert not cl(aL-s.I*s.eye(45)).todok()
print('STAGE IGR1 '+role+' complete original one-C tangent matrices',flush=True)

# Ordered root words have one directed,distinguished final tangent.
edges={'B':['B','L'],'L':['B'],'x':['x'],'C':['a'],'a':['C'],'P':['P','S'],'S':['P','S']};V={};M={};target=(2,1,1,1)
def vf(name,aa,bb,deg):
 V[name]=[(aa,bb,name,tuple(deg))]
 if aa!=bb:V[name].append((bb,aa,name,tuple(deg)))
vf('gP','B','P',[1,0,0,0]);vf('yP','x','P',[1,0,0,0]);vf('N0','L','x',[0,0,0,1]);vf('J0_aB','a','B',[0,1,0,0]);vf('J0_aL','a','L',[0,1,0,0]);vf('S0_ax','a','x',[0,1,0,1])
for aa,bb in [('B','B'),('B','L'),('L','L')]:vf('U_'+aa+bb,aa,bb,[0,0,1,0])
for bb in ['B','L']:
 vf('Nr_'+bb+'x',bb,'x',[0,0,1,1]);vf('Ju_a'+bb,'a',bb,[0,1,1,0])
vf('Su_ax','a','x',[0,1,1,1])
M.update({'M_BC':('B','C',(0,0,0,0)),'M_aL':('a','L',(0,0,0,0)),'M_PC':('P','C',(1,0,0,0))})
for aa in ['B','L','x','P','a','C']:M['M_'+aa+aa+'_C']=(aa,aa,(0,1,0,0))
for bb in ['B','L']:M['Mu_a'+bb]=('a',bb,(0,0,1,0))
M['Mu_ax']=('a','x',(0,0,1,1));M['Mu_aa_C']=('a','a',(0,1,1,0));vv=sum(V.values(),[]);words=[]
if role=='primary':
 for mn,(mr,mc,md) in M.items():
  for size in range(7):
   paths=[(mc,md,())]
   for step in range(size):
    nxt=[]
    for cur,deg,ww in paths:
     for mid in edges[cur]:
      for aa,bb,nn,dd in vv:
       nd=tuple(deg[ii]+dd[ii] for ii in range(4))
       if mid==aa and all(nd[ii]<=target[ii] for ii in range(4)):nxt.append((bb,nd,ww+((cur,mid,aa,bb,nn),)))
    paths=nxt
   words.extend((mn,ww) for cur,dd,ww in paths if cur==mr and dd==target)
else:
 labels=sorted(V);dg={nn:V[nn][0][3] for nn in labels}
 for mn,(mr,mc,md) in M.items():
  for size in range(7):
   for bag in combinations_with_replacement(labels,size):
    if tuple(md[ii]+sum(dg[nn][ii] for nn in bag) for ii in range(4))!=target:continue
    for ordering in set(permutations(bag)):
     for vertices in product(*(V[nn] for nn in ordering)):
      cur=mc;ww=[]
      for aa,bb,nn,dd in vertices:
       if aa not in edges[cur]:break
       ww.append((cur,aa,aa,bb,nn));cur=bb
      else:
       if cur==mr:words.append((mn,tuple(ww)))
words=sorted(words);assert words and len(words)==len(set(words)) and all(len(ww)<=5 and not any('S' in v[:4] for v in ww) for mn,ww in words);by=Counter((mn,len(ww)) for mn,ww in words);s0=[w for w in words if any(v[4]=='S0_ax' for v in w[1])];direct=[w for w in words if w[0].startswith('Mu_')];noPC=[w for w in words if w[0]!='M_PC']
assert s0 and direct and len(noPC)<len(words)
out={'schema':'IGR1_INTRINSIC_ROOT_OPERATOR_INPUT','role':role,'raw_baseline_ghost_scalar_rows':rawrows,'S0_physical_current':[enc(v) for v in Sphys],'S0_nonzero_positions':sum(s0counts),'S0_raw_frame_control_difference_positions':rawframe_difference,'dimension1_quadratic_ghost_scalar_events':len(positive_quadratic_events),'M0_diagonal_C':{k:[enc(v) for v in Ms] for k,Ms in D.items()},'M0_BC_affine_four_axes':aff,'M0_aLambda_affine':enc(aL),'raw_master_tangent_events':raw_events,'master_deferred_after_differentiation':dict(deferred),'ordered_root_words':words,'word_counts':[[mn,nn,ct] for(mn,nn),ct in sorted(by.items())],'S0_word_count':len(s0),'Mu_word_count':len(direct),'omit_PC_word_count':len(noPC),'sixth_order_target_empty':True,'sterile_endpoint_exclusion_after_full_inverse_support':True,'source_gradient_and_ending_Mu_inputs_retained':True,'finite_quantum_root_tensor_or_Ward_QAP_authority_measured':False}
blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(gzip.decompress(blob)).hexdigest()},sort_keys=True),flush=True);timer.cancel()
