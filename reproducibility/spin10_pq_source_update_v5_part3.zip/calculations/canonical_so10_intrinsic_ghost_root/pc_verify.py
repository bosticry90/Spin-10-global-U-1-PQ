from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os,sympy as s,mpmath as mp
O=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'pc_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('pc_'+r+'_tables.json.gz')) for r in ['primary','replay']]
for k in ['literal_normalizations','models']:assert a[k]==b[k],k
assert len(a['literal_normalizations'])==2 and len(a['models'])==2
g,y,z,E=s.symbols('g y z E',real=True);normal=[]
for q in a['literal_normalizations']:
 rv=s.sympify(q['root_PC'],locals={'g':g,'y':y,'z':z,'E':E});sv=s.sympify(q['source_Jx_before_C'],locals={'g':g,'y':y,'z':z,'E':E});wrong=s.sympify(q['wrong_Rt_Gt_order'],locals={'g':g,'y':y,'z':z,'E':E});assert s.expand(rv-(1-E)*y*sv)==0;normal.append({'side':q['side'],'root_PC':str(rv),'source_Jx_before_C':str(sv),'swapped_order_sensitive':s.expand(wrong-rv)!=0,'wrong_Rt_Gt_order':str(wrong)})
mp.mp.dps=60;worst=mp.mpf(0)
for ra,rb in zip(a['radials'],b['radials']):
 assert ra['a']==rb['a']
 for k in ['value','exact']:
  x,y=mp.mpf(ra[k]),mp.mpf(rb[k]);er=abs(x-y)/(1+abs(x)+abs(y));assert er<mp.mpf('1e-30');worst=max(worst,er)
aa=s.symbols('a',positive=True);t=s.symbols('t',positive=True);F=s.log(t)-s.log(t+1);assert s.simplify(s.diff(F,t)-(1/t-1/(t+1)))==0
assert s.simplify(F.subs(t,aa+1)-F.subs(t,aa)-s.log((aa+1)**2/(aa*(aa+2))))==0
counts=[];witness=[]
for q in a['models']:
 cq={'probe':q['probe'],'W0_nonzero':len(q['classical_W0']['entries']),'W2_nonzero':len(q['classical_W2']['entries']),'period_counts':{}}
 for label,periods in q['root_PC_mass_periods'].items():
  cq['period_counts'][label]={k:len(v['entries']) for k,v in periods.items()}
  if q['probe']==0 or label=='B10':assert all(not v['entries'] for v in periods.values())
  else:
   assert all(len(v['entries'])==65 for v in periods.values());witness.append({'period':'log9over8','value':periods['log9over8']['entries'][0]});witness.append({'period':'log16over15','value':periods['log16over15']['entries'][0]})
 counts.append(cq)
out={'schema':'IGR2_PC_VALIDATION','elapsed_after_imports':time.perf_counter()-tick,'left_Hessian_Neumann_and_right_Hessian_Schur_normalizations_agree':True,'normalization_cases':normal,'source_order':'Jx_BEFORE_C','physical_and_raw_source_contraction_routes_agree':True,'full_classical_source_positions_including_zeros':2*2*328*45,'full_model_period_positions_including_zeros':2*2*4*256*45,'model_counts':counts,'witnesses':witness,'radial_formulas_agree':True,'maximum_scaled_radial_discrepancy':mp.nstr(worst,40),'exact_integrated_heat_periods':['log(9/8)','log(16/15)'],'source_input_was_not_a_quantum_fit':True,'full_root_Ward_contact_QAP_or_authority':False}
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
