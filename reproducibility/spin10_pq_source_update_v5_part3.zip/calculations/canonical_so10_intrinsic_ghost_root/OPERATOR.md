# Complete positive-heat operator to be evaluated

This construction requires actual IGR1 receipts. The fixed inverse is
Gt=(1+E G0 V)^-1 E G0,Rt=K0(E^-1-1),at A0 with fixed probe-independent
reference. V=V0+u Vu includes one dimension-one insertion when that grade
is selected. M=M0+u Mu follows the actual source operation,not G's rho row.

The root coefficient is exactly

    [STr(-Gt Vu Gt Rt M0+Gt Rt Mu)]_(C PP),

at u=0. Equivalently it is the u-C-PP coefficient of

    sum_n (-1)^n STr[(E G0 V)^n (1-E) M].

Each E stays on its own free edge before taking the leading homogeneous
jet. The n factors occur in their displayed order. A tangent distinguishes
the trace word,so there is no1/n,averaged charge or commutation rule.
An inverse heat is algebraic scaffolding only;final words have positive
heat powers and1-E. This does not evaluate their finite coefficients.

The degree tuple is (external P,external C,probe u,intrinsic dimension1).
Every interaction/tangent consumes at least one of these grades. Only
N0 can consume solely the last grade,and only U solely the third. Two
P endpoints,one ghost and the two grades need at most five interactions
with a constant tangent. A tangent carrying C or P reduces this to four;
Mu's explicit u reduces the ordinary interaction count further. Check
order6 empty and the degree bound,not an arbitrary numerical cutoff.

The source-only four-ending identity does not justify removing baseline
S0=a-C-x from THIS root. For example,with S0 supplying the intrinsic
coefficient,the other end of a two-fermion/gauge-scalar chain can meet
the u-modified BB inverse and an affine tangent. Its actual coefficient
may vanish;derive S0 first and preserve the complete word group until
that determination. Conversely,higher scalar-potential cubics with no
admitted external labels have three internal ports and are outside this
bridgeless one-loop support,not zero physical interactions in general.

M0 on the chosen mean ideal has only affine B<-partialC,a<-Lambda,
P<-C(P external) and diagonal C-dependent B,Lambda,x,P,a,C blocks.
This must be checked from all actual field maps. Mu's a<-B/Lambda/x
block and nonlinear C-a block follow the full QG source audit. Its
Lambda C-C-a terms have no FIRST tangent on this one-C ideal;second
derivatives and later source-Euler/contact products remain separate.

The baseline raw GF current is transported with the full inverse field
map before Wick rotation. For its derivative-free a-C-x part,no field
has a time Wick phase. The Euclidean action contributes its existing
global minus;the antighost left derivative fixes the C ordering. In
matrix notation Sphys_c=Ta^T sum_b Tc[b,c] Sraw_b Tx. The scalar frame
must not be inferred from a gauge-vector dual chart.

For M0,the right quantum-field derivative of epsilon qphi gives the
actual coefficient on the right of the quantum variation. Replay uses
left derivatives and the parity conversion before frame transport.
Affine derivative momenta/adjoints and the evaluation-dual source
convention remain explicit. Physical P/sterile rules are SMA inputs;
bosonic tangent matrices cannot stand in for fermion spin/color factors.

This result constructs a finite complete ordered calculation problem.
It is not the numerical/analytic answer for its noncommuting traces.
Source Euler products,the known ISG mass image,the local ordinary mass
variation and IGH's zero are eventual comparisons,never assigned missing
root coefficients. Full common normalization,QAP,E5/A5,phase/measure,
source reality,causal/physical limits and physical unification stay open.
