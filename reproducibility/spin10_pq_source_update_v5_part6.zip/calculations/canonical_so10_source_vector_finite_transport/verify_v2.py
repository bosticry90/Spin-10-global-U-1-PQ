"""SVT1 full structure transfer,round trips and actual matter current duals."""
from data_v2 import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
aliases=read(CAL/'canonical_so10_gauge_source_g2_color/primary_result.json')['width_substitution'];assert aliases=={'reference_width_M':'xi','reference_width_H':'eta_H'}
P=packed(HERE/'primary_v2_tables.json.gz');R=packed(HERE/'replay_v2_tables.json.gz');d=packed(HERE/'primary_inputs.json.gz')
for k in ['L','Li','Qold','Qold_inverse','E','H_old','H_new','Aold_from_Anew','source_tensor','finite_tensors','matter_current_coefficients']:assert P[k]==R[k],k
L=dec(P['L']);Li=dec(P['Li']);eh=dec(P['H_old']);HF=dec(P['H_new']);am=dec(P['Aold_from_Anew']);qo=dec(P['Qold']);qi=dec(P['Qold_inverse']);I=ident(45)
for a,b in [(L,Li),(Li,L),(trans(L),L),(qo,qi),(qi,qo)]:zero(minus(mul(a,b),I))
zero(minus(L,dec(P['E'])));assert all(conj(z)==z for z in L.d.values())
zero(minus(mul(eh,trans(eh)),mul(HF,trans(HF))));zero(minus(mul(eh,am),HF));zero(minus(mul(am,trans(am)),ident(12)))
PHold=Mat(45,45,{(i,i):ONE for i in range(12)});zero(minus(mul(mul(L,PHold),Li),mul(HF,trans(HF))))
Wold=plus(scale(PHold,Q('eta_H')),scale(minus(I,PHold),Q('xi')));zero(minus(mul(mul(L,Wold),Li),dec(d['new']['W'])))
source=decoded_tensor(P['source_tensor']);actual={(i,b,c):Q(z) for b,i,c,z in d['new']['source_tensor']};lie={(e,a,b):Q(z) for a,b,e,z in d['plane_f']}
assert source==actual==lie
oldsource={}
for b,m in enumerate(d['source_S']):
 for (i,c),z in dec({'shape':[45,45],'entries':m}).d.items():oldsource[i,b,c]=z
controls={}
for name,bm,cm in [('omit_ghost_inverse',Li,I),('omit_vector_inverse',I,Li)]:
 bad=path_transport(oldsource,L,bm,cm);keys=set(bad)|set(source);changed=sum(sub(bad.get(k,Z),source.get(k,Z))!=Z for k in keys);controls[name]=changed;assert changed>0
T=list(map(dec,d['Y']['Tminus']))
def tr(m):return canon({k:v for k,v in []}) if False else sumq([m.d.get((i,i),Z) for i in range(m.r)])
def sumq(vals):
 z=Z
 for v in vals:z=add(z,v)
 return z
oldT=[]
for b in range(45):
 t=Mat(16,16)
 for (i,j),z in L.d.items():
  if j==b:t=plus(t,scale(T[i],z))
 oldT.append(t)
for a in range(45):
 for b in range(45):assert tr(mul(oldT[a],oldT[b]))==(Q(2) if a==b else Z)
counts={};current_counts={};roundtrip_positions=0
for part,ks in P['finite_tensors'].items():
 counts[part]={};current_counts[part]={}
 for kind,rows0 in ks.items():
  n=45 if kind=='B' else 12;v=decoded_tensor(rows0);orig=tensor(d['finite_coefficients'][part],kind);back=matrix_transport(v,Li,L if kind=='B' else trans(am),L);assert back==orig
  counts[part][kind]=len(v);roundtrip_positions+=45*n*45
  for z in v.values():assert conj(z)==z
  ims=P['matter_current_coefficients'][part][kind];left={(b,c):dec(m) for b,c,m in ims['left']};right={(b,c):dec(m) for b,c,m in ims['right']};assert set(left)==set(right)
  for key,m in left.items():zero(minus(m,trans(star(m))));zero(plus(right[key],trans(m)))
  current_counts[part][kind]={'left':sum(len(m.d) for m in left.values()),'right':sum(len(m.d) for m in right.values())}
assert roundtrip_positions==346275
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
for x in [P,R]:assert not any(x[k] for k in ['physical_scheme_adopted','quantum_coefficient_fitted','lower_auxiliary_family_computed','coupled_cancellation_claimed','new_loop_integrals'])
print('RESULT '+json.dumps({'status':'QUALIFIED_FINITE_SOURCE_VECTOR_STRUCTURE_TRANSPORT','elapsed_after_imports':time.perf_counter()-start,'finite_color_roundtrip_positions':roundtrip_positions,'source_and_bracket_positions':45**3,'spinor_trace_positions':45**2,'source_primal_dual_inverse_and_H_width_remainders':0,'source_bracket_matches_independently_extracted_BSF_and_GTT':True,'new_color_nonzero_counts':counts,'matter_current_nonzero_counts':current_counts,'negative_controls':controls,'all_finite_tensor_and_current_zero_complements_compared':True,'background12_embedding_retained':True,'lower_auxiliary_family_computed':False,'coupled_cancellation_claimed':False,'quantum_coefficient_fitted':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'full_QAP_measure_phase_massiveC1_E5A5_unification_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_v2_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_v2_tables.json.gz')},sort_keys=True),flush=True)
