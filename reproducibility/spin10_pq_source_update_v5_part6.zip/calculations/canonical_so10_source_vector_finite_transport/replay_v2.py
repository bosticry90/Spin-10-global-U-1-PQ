"""SVT1 explicit raw-C3 pullback then actual GTT source/primal pushforward."""
from data_v2 import *
start=begin('replay');d=packed(HERE/'replay_inputs.json.gz');E,eh,em,old,oi,new,ni,L,Li,HF,am=frames(d);T=list(map(dec,d['Y']['Tminus']));U=[scale(trans(t),Q(-1)) for t in T];out={};images={};raw_summaries={}
for part,table in d['finite_coefficients'].items():
 out[part]={};images[part]={};raw_summaries[part]={}
 for kind,n in [('B',45),('A',12)]:
  # Aold labels are retained during raw source/ghost transport,then mixed
  # through the separately verified actual12-dimensional background map.
  mid=path_transport(tensor(table,kind),oi,old if kind=='B' else ident(12),old)
  raw=packed_tensor(mid);raw_summaries[part][kind]={'positions_nonzero':len(mid),'sha256':sha256(json.dumps(raw,separators=(',',':')).encode()).hexdigest()}
  v=path_transport(mid,new,ni if kind=='B' else am,ni);out[part][kind]=packed_tensor(v);images[part][kind]={side:current(v,ts,n) for side,ts in [('left',T),('right',U)]}
source={}
for b,mat in enumerate(d['source_S']):
 for (i,c),z in dec({'shape':[45,45],'entries':mat}).d.items():source[i,b,c]=z
sf=path_transport(path_transport(source,oi,old,old),new,ni,ni)
finish('replay_v2',{'method':'explicit_raw_C3_tensor_path_pullback_then_GTT_dual_and_primal_push','L':enc(L),'Li':enc(Li),'Qold':enc(old),'Qold_inverse':enc(oi),'E':enc(E),'H_old':enc(eh),'H_new':enc(HF),'Aold_from_Anew':enc(am),'source_tensor':packed_tensor(sf),'finite_tensors':out,'matter_current_coefficients':images,'raw_intermediate_tensor_materialized':True,'complete_raw_intermediate_hashes':raw_summaries},start)
