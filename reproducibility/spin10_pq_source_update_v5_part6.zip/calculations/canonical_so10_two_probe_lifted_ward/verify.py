from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
for p,h in json.loads((O/'validation_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
P=json.loads((O/'primary_tables.json').read_bytes());Z=json.loads((O/'replay_tables.json').read_bytes())
for k in ['actual_module_facts','q0_scalar_coordinates','mixed_log_coefficients','mixed_coefficient_variations','nonzero_tails']:assert P[k]==Z[k],k
inp=json.loads(gzip.decompress((O/'primary_inputs.json.gz').read_bytes()));geo=inp['geometry'];names=geo['names'];ix={n:i for i,n in enumerate(names)};pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};Jof={i:J for i,J,h,k in pairs};src=set(Jof.values());L={ix[('b' if i<12 else 'L')+str(i)] for i in range(45)};a={ix[('bar' if i<12 else 'ub')+str(i)] for i in range(45)};C={ix['C'+str(i)] for i in range(45)};JA={Jof[n] for n in a};JL={Jof[n] for n in L};chi=C|JA|JL;dim={n:2 if n in L else 1 for n in fields};gh={n:1 if n in C else -1 if n in a else 0 for n in fields}
for n,J in Jof.items():dim[J]=3-dim[n];gh[J]=-1-gh[n]
assert len(chi)==135 and set(inp['q0_columns'])=={names[n] for n in chi}
for p in list(inp['q0_columns'].values())+inp['seed_parts']:assert all(n in chi and not j for g,w,c in p['monomials'] for n,j in w)
actual=[]
for typ,pp,cap,ghost in [('G',inp['physical_G'],-1,-1),('QG',inp['physical_QG'],0,0)]:
 for r,p in enumerate(pp):
  hist=Counter();maxdim=0;rank=0;nJA=0
  for g,w,c in p['monomials']:
   assert g>=0 and sum(gh[n] for n,j in w)==ghost and all(n not in src or n in JA|JL for n,j in w)
   assert all(x>=0 and h>=0 for x,h,m,num,den in p['coefficients'][c]);maxdim=max(maxdim,sum(dim[n]+len(j) for n,j in w));rank=max(rank,sum(len(j)+int(names[n].startswith('B')) for n,j in w));nJA+=any(n in JA for n,j in w)
   for at,(n,I) in enumerate(w):
    for m,J in w[:at]:
     if n in fields and m in fields:hist[len(I)+len(J)+dim[n]+dim[m]-4]+=1
  assert max(hist)<=cap;actual.append({'type':typ,'generator':r,'density_positions':p['positions'],'max_word_dimension_without_positive_coefficient_dimensions':maxdim,'max_Lorentz_slots':rank,'Hessian_pair_order_histogram':{str(k):v for k,v in sorted(hist.items())},'Ja_source_words':nJA})
assert actual==P['actual_module_facts']
X=s.Matrix([[1,2],[3,-1]]);A=s.Matrix([[2,1],[0,1]]);B=s.Matrix([[0,3],[-2,1]]);Y=s.Matrix([[2,0],[1,-1]]);DA=s.Matrix([[1,-1],[2,0]]);DB=s.Matrix([[0,2],[1,1]]);z,t,u,v=s.symbols('z t u v');H=s.eye(2)+z*(X+t*Y)+u*(A+t*DA)+v*(B+t*DB)
det=s.factor(H.det());d0=det.subs({u:0,v:0});fa=s.diff(det,u).subs({u:0,v:0});fb=s.diff(det,v).subs({u:0,v:0});fab=s.diff(det,u,v).subs({u:0,v:0});exact=s.factor((fab/d0-fa*fb/d0**2)/2);full=exact.subs(t,0);dfull=s.diff(exact,t).subs(t,0)
cc=s.series(full,z,0,7).removeO().expand();dc=s.series(dfull,z,0,7).removeO().expand();assert [str(cc.coeff(z,m)) for m in range(7)]==P['mixed_log_coefficients'];assert [str(dc.coeff(z,m)) for m in range(7)]==P['mixed_coefficient_variations']
for N in [2,3,4]:
 tail=s.factor(full-sum(cc.coeff(z,m)*z**m for m in range(N+1)));dt=s.factor(dfull-sum(dc.coeff(z,m)*z**m for m in range(N+1)));d=P['nonzero_tails'][str(N)];assert s.factor(tail-s.sympify(d['full_tail']))==0 and s.factor(dt-s.sympify(d['full_tail_variation']))==0
 assert tail.subs(z,s.Rational(1,10))!=0 and dt.subs(z,s.Rational(1,10))!=0
assert P['mixed_log_coefficients']!=P['commuted_wrong_coefficients'] and P['mixed_coefficient_variations']!=P['omitted_inverse_variation_coefficients']
# Fixed weighted-order envelope, including the worst u/u product.
for a0,b0 in [(1,1),(0,1),(0,0)]:assert -a0-b0-5<-4
print('RESULT '+json.dumps({'schema':'TWO_PROBE_LIFT_APPLICABILITY_VALIDATION_V1','actual_scalar_q0_coordinates':135,'actual_module_facts':actual,'independent_logdet_second_derivative_matches_ordered_products':True,'independent_full_variation_including_inverse_legs_matches':True,'nonzero_ordered_tail_and_variation_controls':True,'common_four_unmarked_word_subtraction_leaves_order_below_minus4':True,'full_nonlocal_amplitudes_numerically_evaluated':False,'analytic_proof_requires_separate_review_not_machine_certified':True,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick},sort_keys=True),flush=True);watch.cancel()
