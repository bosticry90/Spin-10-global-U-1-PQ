# Next required dependency: the actual hatted chiral insertion in this probe family

The bosonic fixed-lift two-probe/one-variation construction is now supplied.
Do not keep expanding its local carriers merely because selected heat
coefficients remain nonzero: the full converted functional, not the raw
heat action alone, is the bounded theorem.

The next informative question is how the same construction couples to the
ACTUAL existing SMA/chiral hatted kinetic breaking and fermionic sources.
Use the complete-matter/source and CSW contracts and receipts, not a generic
claim that Spin10 is anomaly free or a four-dimensional gamma shortcut.

1. Derive the augmented classical defect from the full actual action.
   Determine whether it remains I_hat or obtains probe companions. Check
   the actual (I_hat,G_r), (I_hat,QG_r) and source supports. Nonminimal
   independence can exclude a term only after that independence is proved.

2. If the master-Hessian chain and common domain apply, its quantum term
   has the ordered form onehalf*T_kappa[G_ext (I_hat,ext)'']. Retain its
   full Nambu/chiral and evanescent lift, source Eulers and mixed Hessians.
   A vanishing specialization of I_hat at D4 does not set its first-D-jet
   contact to zero. The actual hatted construction controls the calculation.

3. Distinguish a structural zero at zero fermion means AND fermionic
   sources from the unrestricted fermionic identity. At that locus,
   decoupled Hessian blocks may make the fermion trace independent of the
   nonminimal probes. This is a useful support test, not a full measure,
   phase or external-fermion theorem. Do not discard off-diagonal blocks
   before differentiating the corresponding physical sources.

4. Select the smallest complete nontrivial fermion/source carrier only
   after the support and regulator-domain audit. Derive its quantum input
   independently, then test the full augmented relation. Preserve a
   nonzero breaking, prescription gap or domain failure before proposing
   any normalization; no coefficient may be fitted to the desired zero.

This is a next-target note, not a frozen run contract or a completed new
calculation. It does not authorize paused flavor fitting, a fermion mass
benchmark, HB1/C5 activation, a physical scheme or any promotion. Massive
fermion C1 matching and physical viability remain separate obligations.
