from pathlib import Path
import ast
O=Path(__file__).resolve().parent
for src,dst in [('native.py','native_v2.py'),('verify.py','verify_v2.py')]:
 p=(O/src).read_text(encoding='utf-8');line='for n,J in Jof.items():dim[J]=3-dim[n];gh[J]=-1-gh[n]';assert p.count(line)==1
 extra="\nAA={n for n,name in enumerate(names) if name.startswith('A') and name[1:].split('_')[0].isdigit() and len(name.split('_'))==2 and name.split('_')[1] in ['0','1','2','3']}\nassert len(AA)==48 and not AA&fields\nfor n in AA:dim[n]=1;gh[n]=0\n"
 p=p.replace(line,line+extra).replace("names[n].startswith('B')","names[n].startswith(('A','B'))")
 if src=='native.py':p=p.replace("O/'preparation.json'","O/'preparation_v2.json'").replace("role+'_tables.json'","role+'_v2_tables.json'").replace('TWO_PROBE_LIFT_APPLICABILITY_NATIVE_V1','TWO_PROBE_LIFT_APPLICABILITY_NATIVE_V2')
 else:p=p.replace("O/'validation_preparation.json'","O/'validation_preparation_v2.json'").replace("O/'primary_tables.json'","O/'primary_v2_tables.json'").replace("O/'replay_tables.json'","O/'replay_v2_tables.json'").replace('TWO_PROBE_LIFT_APPLICABILITY_VALIDATION_V1','TWO_PROBE_LIFT_APPLICABILITY_VALIDATION_V2')
 ast.parse(p)
 with (O/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(p)
print('GENERATED_V2_EXISTING48_BACKGROUND_TYPES')
