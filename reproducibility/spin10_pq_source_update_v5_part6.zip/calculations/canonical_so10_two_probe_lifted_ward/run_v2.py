from pathlib import Path
from hashlib import sha256
import json,subprocess,sys,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/two-probe-lifted-ward-v1-2026-10-24')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
stage='preparation_v2'
try:
 b=dict(json.loads((O/'preparation.json').read_bytes())['input_sha256']);typed=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/a10_e1_fermion_common.py';b[str(typed)]=sha256(typed.read_bytes()).hexdigest()
 for n in ['CORRECTION_V2.md','generate_v2.py','native_v2.py','verify_v2.py','run_v2.py']:
  p=O/n
  with (O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 for p in O.iterdir():
  if p.is_file():b[str(p)]=sha256(p.read_bytes()).hexdigest()
 nb={str(p):b[str(p)] for p in [R/'AGENTS.md',R/'project_state.json',O/'native_v2.py',O/'primary_inputs.json.gz',O/'replay_inputs.json.gz',typed]}
 dump(O/'preparation_v2.json',{'input_sha256':dict(sorted(b.items())),'native_input_sha256':nb,'original_failure_preserved':True,'limits':{'seconds_after_imports':120,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_bytes':4*1024**2}})
 for role in ['primary','replay','verify']:
  stage=role+'_v2'
  if role=='verify':
   bb=dict(b)
   for p in O.iterdir():
    if p.is_file():bb[str(p)]=sha256(p.read_bytes()).hexdigest()
   dump(O/'validation_preparation_v2.json',{'input_sha256':dict(sorted(bb.items()))})
  cmd=[sys.executable,'-B',str(O/('verify_v2.py' if role=='verify' else 'native_v2.py'))]+([] if role=='verify' else [role]);c=capture(cmd);dump(O/(role+'_v2_capture.json'),c);dump(C/(role+'_v2_full_capture.json'),c);print(c['stdout_and_stderr'],flush=True)
  assert c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
  assert c['launch']['memory']['available_pagefile']>=350*1024**2 and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3
  rr=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<120
  if role!='verify':assert sha256((O/(role+'_v2_tables.json')).read_bytes()).hexdigest()==rr[0]['table_sha256']
  dump(O/('validation_receipt_v2.json' if role=='verify' else role+'_v2_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<4*1024**2
except BaseException:
 dump(O/'controller_failure_v2.json',{'stage':stage,'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
