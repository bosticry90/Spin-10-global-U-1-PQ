# Recover the existing external-background type, without changing the model

The first native failed with KeyError0 before any fixture or scientific
result was emitted. Its type map covered643 integrated fields and their
sources, but the complete transported densities also contain48 external
A_h,mu coordinates. Index0 is A0_0. All original sources, frozen hashes,
inputs, capture and controller failure remain unchanged; no V1 receipt exists.

The existing a10_e1_fermion_common.py alphabet() registers all12*4 A entries
with grade(1,0,0): engineering dimension1, ghost number0, parity0. Their
free Lorentz index also counts toward the tensor-rank bound. They are
external, are not integrated in the Hessian, and are fixed by this Slavnov
operation. No new field, type choice, scheme or physical input is adopted.

V2 adds exactly those48 typed external coordinates, rejects any still
untyped coordinate, and includes their Lorentz slots. It uses new source,
manifest and output filenames. Both calculation routes and the separate
verifier rerun the full original checks, using unchanged extracted inputs.
The120second/8GiB/350MiB/4MiB caps and every scientific assertion stay.
