# A common formal two-probe construction, retaining the nonlocal products

TPW1's corrected native calculations, independent determinant derivative
check and separate analytic proof review completed. Within the inherited
fixed-metric-lift Euclidean bosonic/test-field domain, the existing finite
functional extends through quadratic probe degree and satisfies

    [(S_ext,Gamma1,kappa,ext)+d Gamma1,kappa,ext]_(probe degree<=2)=0.

This is a bounded formal one-loop Slavnov result. It is not full QAP,
chiral measure consistency, physical equivalence or E5/A5. Authority
remains34/39 and no physical renormalization scheme is adopted.

## What is newly constructed

Use the same linear classical action with the actual independent
Mlight/Mheavy probes, the same fixed reference determinant and the same
previously defined T_kappa map. Define the WHOLE augmented one-loop log
with that map before differentiating probes or sources. Its two-probe
derivatives are the ordered full-inverse connected products, including
their local extensions and nonlocal finite remainders.

The proof uses the full source-Hessian congruence and the old lifted Stokes
identity, after establishing their applicability to this new quotient.
The actual seed algebra is scalar/isotropic and closes under Q0 without
a Lorentz trace count. The same metric-natural source shift transports it.
The new action modifies only scalar nonminimal field rows; DSP's source/
first-D-jet compatibility and rank argument continue to apply. The joint
trace domain retains two independent probe transfers and just ONE Slavnov
tangent. Coincident-label endpoint terms use the complete paired identity.

Consequently, the complete congruence trace is a differential trace plus
its prescribed commutator defects. The same T_kappa gives their zero
without choosing an unknown finite coefficient. Raw heat responses remain
nonzero; their explicit action-derived finite conversion is retained.
The preceding PHR/PCW/PSR component results agree with this distinction.
Those selected cancellations are checks of the construction, not its proof.

## U is constrained, not discarded or fully tabulated

An exact noncommuting resolvent identity separates finite low words from
a common remainder containing at least five unmarked interaction factors.
Even a u/u pair then has weighted order below-4. Its UV integral and first
coefficient variation converge. The already qualified symbol subtraction,
radial/IR construction retains the lower-word nonlocal remainders too.
Thus the new functional includes the entire operator-valued U and the
Ward theorem constrains its variation together with the local terms.

This does NOT numerically evaluate every nonlocal Spin10 amplitude, assert
an analytic sum of the whole Born series, or authorize constant-probe or
exceptional momentum pullbacks. The high-word tail is not relabelled as
the entire U. PROOF.md and PROOF_REVIEW.md distinguish these assertions.

## Actual applicability checks

All135 actual Q0 coordinate images and both actual seeds stay inside the
scalar C/Ja/JL algebra without a vector slot or ordinary jet. Full
transported densities, rather than only the previous local projections,
were checked:

| Object | Coupling-resolved density positions | Maximum Hessian weighted order | Maximum Lorentz slots |
| --- | ---: | ---: | ---: |
| G_light |1344 |-1 |2 |
| G_heavy |4560 |-1 |2 |
| QG_light |10972 |0 |4 |
| QG_heavy |88785 |0 |4 |

All BV-source occurrences are Ja/JL. The audit includes all48 external
background A coordinates with their existing dimension1/gh0/even type;
they are not integrated fields.

Finite noncommuting matrix controls compare ordered log words, rooted
inverse products and a direct log-determinant second derivative. They
retain a nonzero finite pair tail and its nonzero derivative. Commuting
factors incorrectly or omitting inverse-variation legs changes the result.
These are algebra controls, not Spin10 loop coefficients. Graded Gaussian
signs and analytic domains rely on their explicitly bound earlier proofs;
the new ungraded fixture does not pretend to re-prove them.

## Execution and preserved failure

V1 failed before emitting any result because its type map omitted the48
external A entries, causing KeyError0 at A0_0. The failed source, inputs,
capture and controller failure are preserved. V2 imports their already
declared grades from the existing type definition and counts their Lorentz
slots. It changes no field content, numerical input, scientific comparison
or resource limit. No V1 receipt exists.

V2 natives took2.435/2.769 seconds after imports; separate verification
took1.622 seconds. Maximum sampled private allocation was136,986,624 bytes,
not a true peak. The120-second/8-GiB/350-MiB/4-MiB limits held. Native
checks do not mechanically certify the analytic theorem; its step-by-step
review is a separate artifact.

Validation receipt V2 SHA256:
3edd2a4002815a4084814cb2b62c7828b52b6d760a3471c467277689e2636725.

## Remaining frontier

This closes the formal bosonic two-probe/one-Slavnov construction under
the declared fixed-lift assumptions. The appropriate next question is
its compatibility with the actual chiral/SMA hatted breaking insertion
and fermionic source sector. First determine the actual probe/support
and domain requirements; do not infer their vanishing from this bosonic
result or reopen paused flavor fitting.

Independent H-basicness, full mixing/normalization, global/measure and
physical limits, massive-fermion matching, full E5/A5 and physical viability
remain open. Kappa is free; b0 and IR constants are not fixed or identified.
Historical custody remains exit2 with seven unresolved references NOTPASS.
Shared action, analytic premises, software and AI authorship limit the
independence of these results. There is no external scientific confirmation.
