from pathlib import Path
from hashlib import sha256
from collections import Counter
from itertools import combinations
import json,gzip,sys,time,threading,os,sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
role=sys.argv[1];assert role in ['primary','replay'];prep=json.loads((O/'preparation_v2.json').read_bytes())
for p,h in prep['native_input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
inp=json.loads(gzip.decompress((O/(role+'_inputs.json.gz')).read_bytes()));geo=inp['geometry'];names=geo['names'];par=geo['parities'];ix={n:i for i,n in enumerate(names)};pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};Jof={i:J for i,J,h,k in pairs};sources=set(Jof.values())
L=[ix[('b' if i<12 else 'L')+str(i)] for i in range(45)];a=[ix[('bar' if i<12 else 'ub')+str(i)] for i in range(45)];C=[ix['C'+str(i)] for i in range(45)];Ja=[Jof[n] for n in a];JL=[Jof[n] for n in L];chi=set(C+Ja+JL);dim={n:2 if n in L else 1 for n in fields};gh={n:1 if n in C else -1 if n in a else 0 for n in fields}
for n,J in Jof.items():dim[J]=3-dim[n];gh[J]=-1-gh[n]
AA={n for n,name in enumerate(names) if name.startswith('A') and name[1:].split('_')[0].isdigit() and len(name.split('_'))==2 and name.split('_')[1] in ['0','1','2','3']}
assert len(AA)==48 and not AA&fields
for n in AA:dim[n]=1;gh[n]=0

assert set(inp['q0_columns'])=={names[n] for n in chi}
for p in list(inp['q0_columns'].values())+inp['seed_parts']:
 assert all(n in chi and not j for g,w,c in p['monomials'] for n,j in w)
assert not any(Jof.get(n) in chi for n in chi) and not any(n in fields and Jof[n] in chi for n in chi)
facts=[]
for typ,polys,cap,ghost in [('G',inp['physical_G'],-1,-1),('QG',inp['physical_QG'],0,0)]:
 for r,p in enumerate(polys):
  hist=Counter();rankmax=0;maxdim=0;Ja_source_words=0
  for g,w,c in p['monomials']:
   ww=[(n,tuple(j)) for n,j in w];assert g>=0 and sum(gh[n] for n,j in ww)==ghost
   assert all(n not in sources or n in set(Ja+JL) for n,j in ww)
   assert all(x>=0 and h>=0 for x,h,m,num,den in p['coefficients'][c])
   maxdim=max(maxdim,sum(dim[n]+len(j) for n,j in ww));assert maxdim<=3 if typ=='G' else maxdim<=4
   rankmax=max(rankmax,sum(len(j)+int(names[n].startswith(('A','B'))) for n,j in ww))
   Ja_source_words+=any(n in Ja for n,j in ww)
   tokens=[(n,j) for n,j in ww if n in fields]
   if role=='primary':
    for (n,I),(m,J) in combinations(tokens,2):hist[len(I)+len(J)+dim[n]+dim[m]-4]+=1
   else:
    cc=Counter(tokens);tt=sorted(cc)
    for at,(n,I) in enumerate(tt):
     for m,J in tt[at:]:
      count=cc[n,I]*(cc[n,I]-1)//2 if (n,I)==(m,J) else cc[n,I]*cc[m,J]
      if count:hist[len(I)+len(J)+dim[n]+dim[m]-4]+=count
  assert hist and max(hist)<=cap and rankmax<=3+(typ=='QG')
  facts.append({'type':typ,'generator':r,'density_positions':p['positions'],'max_word_dimension_without_positive_coefficient_dimensions':maxdim,'max_Lorentz_slots':rankmax,'Hessian_pair_order_histogram':dict(sorted(hist.items())),'Ja_source_words':Ja_source_words})
print('STAGE '+role+' actual_scalar_isotropic_lift_and_full_probe_operator_order_audit',flush=True)
X=s.Matrix([[1,2],[3,-1]]);A=s.Matrix([[2,1],[0,1]]);B=s.Matrix([[0,3],[-2,1]]);Y=s.Matrix([[2,0],[1,-1]]);DA=s.Matrix([[1,-1],[2,0]]);DB=s.Matrix([[0,2],[1,1]])
coeff=[];dcoeff=[];commuted=[];dropped=[]
for m in range(7):
 n=m+2;v=0;dv=0
 if role=='primary':
  for aa in range(n):
   for bb in range(n):
    if aa==bb:continue
    word=[A if k==aa else B if k==bb else X for k in range(n)];ders=[DA if k==aa else DB if k==bb else Y for k in range(n)];prod=s.eye(2)
    for z in word:prod=prod*z
    v+=s.trace(prod)*s.Rational((-1)**(n+1),2*n)
    for at in range(n):
     prod=s.eye(2)
     for k,z in enumerate(word):prod=prod*(ders[k] if k==at else z)
     dv+=s.trace(prod)*s.Rational((-1)**(n+1),2*n)
 else:
  dp=lambda k:sum((X**i*Y*X**(k-i-1) for i in range(k)),s.zeros(2))
  for i in range(m+1):
   j=m-i;v+=-s.Rational((-1)**m,2)*s.trace(X**i*A*X**j*B)
   dv+=-s.Rational((-1)**m,2)*s.trace(dp(i)*A*X**j*B+X**i*DA*X**j*B+X**i*A*dp(j)*B+X**i*A*X**j*DB)
 coeff.append(str(v));dcoeff.append(str(dv));commuted.append(str(-s.Rational((-1)**m*(m+1),2)*s.trace(X**m*A*B)));dropped.append(str(-s.Rational((-1)**m,2)*sum((s.trace(X**i*DA*X**(m-i)*B+X**i*A*X**(m-i)*DB) for i in range(m+1)),s.Integer(0))))
z,ds=s.symbols('z ds');RR=(s.eye(2)+z*X).inv();full=-s.trace(RR*A*RR*B)/2;dR=-RR*(z*Y)*RR;dfull=-s.trace(dR*A*RR*B+RR*DA*RR*B+RR*A*dR*B+RR*A*RR*DB)/2
tail={}
for N in [2,3,4]:
 low=sum((s.Rational(coeff[m])*z**m for m in range(N+1)),s.Integer(0));dlow=sum((s.Rational(dcoeff[m])*z**m for m in range(N+1)),s.Integer(0));t=s.factor(full-low);dt=s.factor(dfull-dlow);assert t!=0 and dt!=0
 rem=sum(((-z*X)**i*A*(-z*X)**(N-i+1)*RR for i in range(N+1)),s.zeros(2))+(-z*X)**(N+1)*RR*A*RR
 finite=sum(((-z*X)**i*A*(-z*X)**j for i in range(N+1) for j in range(N-i+1)),s.zeros(2));assert (RR*A*RR-finite-rem).applyfunc(s.factor)==s.zeros(2)
 assert s.factor(-s.trace(rem*B)/2-t)==0
 tail[str(N)]={'full_tail':str(t),'full_tail_variation':str(dt),'tail_at_z_1_10':str(t.subs(z,s.Rational(1,10))),'variation_at_z_1_10':str(dt.subs(z,s.Rational(1,10)))}
assert coeff!=commuted and dcoeff!=dropped
out={'schema':'TWO_PROBE_LIFT_APPLICABILITY_NATIVE_V2','role':role,'actual_module_facts':facts,'q0_scalar_coordinates':len(chi),'no_probe_physical_vector_source_rows':True,'mixed_log_coefficients':coeff,'mixed_coefficient_variations':dcoeff,'commuted_wrong_coefficients':commuted,'omitted_inverse_variation_coefficients':dropped,'nonzero_tails':tail,'graded_Gaussian_and_analytic_domains_reused_not_reproved_by_fixture':True,'full_nonlocal_Spin10_coefficients_evaluated':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode()
with (O/(role+'_v2_tables.json')).open('xb') as f:f.write(raw)
print('RESULT '+json.dumps({'role':role,'table_sha256':sha256(raw).hexdigest(),'elapsed_after_imports':out['elapsed_after_imports'],'q0_coordinates':len(chi),'full_nonlocal_Spin10_coefficients_evaluated':False},sort_keys=True),flush=True);watch.cancel()
