from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,ast
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;M=O.parent/'canonical_so10_mixed_probe_auxiliary_ward';S=O.parent/'canonical_so10_second_probe_master';P=O.parent/'canonical_so10_source_probe_contact_complete';W=O.parent/'canonical_so10_probe_source_relative_ward'
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert base=='5c0698fa9aaf3e327b203203bbf44ee20b4b683a'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R).strip() and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R).strip()
assert json.loads((W/'validation_receipt.json').read_bytes())['selected_dimensional_comparison_zero']
files=[R/n for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/SOLO_REVIEW_POLICY_V1.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V588.md','tools/portable_dh_v1/inputs.json.gz','tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']]+[W/'validation_receipt.json']
deps={'canonical_so10_dimensional_stokes_primitive':['DERIVATION.md','RESULT.md','validation_receipt.json'],'canonical_so10_general_identity_trace_extension':['DERIVATION.md','RESULT.md','validation_receipt.json'],'canonical_so10_ordered_shear_finite_part':['DERIVATION.md','RESULT.md','validation_receipt.json'],'canonical_so10_joint_born_ir_trace_domain':['DERIVATION_V2.md','RESULT.md','validation_receipt.json'],'canonical_so10_cutoff_source_ward_operator':['DERIVATION.md','RESULT.md','validation_receipt.json'],'canonical_so10_sourcequadratic_primitive_probe':['DERIVATION.md','TRACE_DOMAIN_NOTE.md','RESULT.md','validation_receipt.json'],'canonical_so10_second_probe_master':['DERIVATION.md','RESULT.md','validation_receipt_v2.json'],'canonical_so10_mixed_probe_auxiliary_ward':['DERIVATION.md','validation_receipt_v2.json']}
for folder,nn in deps.items():files.extend(O.parent/folder/n for n in nn)
geo=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()))['geometry']
for role in ['primary','replay']:
 mp=M/(role+'_tables.json.gz');sp=S/(role+'_v2_tables.json.gz');pp=P/('primary_v2_tables.json.gz' if role=='primary' else 'replay_v3_tables.json.gz');files.extend([mp,sp,pp]);m=json.loads(gzip.decompress(mp.read_bytes()));s=json.loads(gzip.decompress(sp.read_bytes()));p=json.loads(gzip.decompress(pp.read_bytes()))
 z={'geometry':geo,'q0_columns':s['q0_columns'],'seed_parts':p['seed_parts'][:2],'physical_G':m['physical_G'],'physical_QG':m['physical_QG'],'extraction':'CLASSICAL_MODULE_DATA_ONLY_NO_QUANTUM_WARD_TARGET'};dst=O/(role+'_inputs.json.gz')
 with dst.open('xb') as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 files.append(dst)
for n in ['RECORD.md','PROOF.md','native.py','verify.py','prepare.py','run.py']:
 p=O/n;files.append(p)
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'))
 with (O/(n+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
files.extend(O.glob('*.source.txt'));b={str(p):H(p) for p in sorted(set(files))};nb={str(p):b[str(p)] for p in [R/'AGENTS.md',R/'project_state.json',O/'native.py',O/'primary_inputs.json.gz',O/'replay_inputs.json.gz']}
dump(O/'preparation.json',{'base':base,'input_sha256':b,'native_input_sha256':nb,'limits':{'seconds_after_imports':120,'sampled_private_bytes':8*1024**3,'launch_floor':350*1024**2,'packet_bytes':4*1024**2},'scientific_acceptance':'NOT_PERFORMED'})
print('PREPARED_TPW1',len(b))
