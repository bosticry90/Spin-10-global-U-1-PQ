from pathlib import Path
from hashlib import sha256
import ast,gzip,json,subprocess
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-F-fourth-support-v1-2026-10-26')
H=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
base=read(O/'inputs.json')['base_HEAD']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==base
assert subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()=='main'
subprocess.run(['git','diff','--quiet','HEAD'],cwd=R,check=True)
tree=subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);assert tree==(C/'old_git_tree.txt').read_bytes()
state=H(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
bindings={}
for file in sorted(O.glob('*preparation*.json')):
    for path,h in read(file)['input_sha256'].items():
        assert H(Path(path))==h,(file.name,path)
        if path in bindings:assert bindings[path]==h
        bindings[path]=h
for file in O.glob('*.source.txt'):assert (O/file.name.removesuffix('.source.txt')).read_bytes()==file.read_bytes(),file
for file in O.glob('*.py'):ast.parse(file.read_bytes())
assert not list(O.glob('*controller_failure*.json'))
completed=['primary_capture.json','replay_capture.json','inventory_capture.json','fixtures_capture.json','primary_selected_capture.json','replay_selected_capture.json','refined_capture.json','source_d_fixture_capture.json','primary_source_d_capture.json','replay_source_d_capture.json','review_capture.json']
maxmem=0
for file in completed:
    z=read(O/file);assert z['exit_code']==0 and z['calculation_completed'] and z['execution_state']=='COMPLETED' and z['post_run_observations_qualified']
    assert z['launch']['creation_after_observation'] and z['launch']['memory']['available_pagefile']>=350*1024**2
    for sample in z['all_resource_samples']:
        assert sample['private_bytes']<8*1024**3;maxmem=max(maxmem,sample['private_bytes'])
for file in ['fixtures_result.json','source_d_fixture_result.json']:assert read(O/file)['elapsed_after_imports']<300
for file in ['primary_operators.json.gz','replay_operators.json.gz','primary_selected.json.gz','replay_selected.json.gz','primary_source_d.json.gz','replay_source_d.json.gz']:assert load(O/file)['elapsed_after_imports']<300
for file in ['inventory_result.json.gz','refined_result.json.gz']:assert load(O/file)['elapsed_after_imports']<180
v=read(O/'review_result.json');assert v['elapsed_after_imports']<180 and v['all_label_tables_equal'] and v['all_source_CJ_arrays_equal']
assert v['probe0_C4_structurally_zero'] and v['inactive_C4_source_labels']==list(range(13)) and v['GF_CC_M0_CC_Mu_C_target_loops_structurally_absent']
assert len(v['independent_boolean_support'])==12 and all(z['GF_CC_M0_CC_Mu_C_markers_absent'] for z in v['independent_boolean_support'])
assert v['remaining_probe1_candidate_words_union']==57 and v['original_matrix_coefficients_compared']==49004
assert all(z['whole_V_M_and_zero_complements_equal'] for z in v['original_builder_matrix_comparisons'])
assert not v['full_C4_tensor_or_F_log5_claim'] and not v['known_quantum_remainder_operand']
a=load(O/'primary_operators.json.gz');b=load(O/'replay_operators.json.gz');assert a['tables']==b['tables'] and sum(len(z) for z in a['tables'].values())==207440
assert a['guard_denials']==b['guard_denials']==2 and b['metadata']['all_given_GF_Euler_columns_recovered'] and b['metadata']['reconstructed_GF_density_terms']==75953
sa=load(O/'primary_selected.json.gz');sb=load(O/'replay_selected.json.gz');assert sa['results']==sb['results'] and len(sa['results'])==14
pa=load(O/'primary_source_d.json.gz');pb=load(O/'replay_source_d.json.gz');assert pa['results']==pb['results'] and pa['source_kernel']==pb['source_kernel']
assert pa['guard_denials']==pb['guard_denials']==3 and pa['source_kernel_nonzeros']==pb['source_kernel_nonzeros']==6688 and pa['source_kernel_pairs']==pb['source_kernel_pairs']==1024
assert [z['nonzero_counts']['total'] for z in pa['results']]==[0,85112] and all(z['domain_positions']==14612400 for z in pa['results'])
assert all(z['matches_independent_omission'] for z in v['source_CJ_late_calibrations'])
ref=load(O/'refined_result.json.gz');wordset={(z['root'],tuple(z['word'])) for c in ref['cases'] if c['probe']==1 for z in c['words']}
sourcewords={(root,word) for root,word in wordset if any(name.startswith('VS|CJ') for name in word)}
assert len(wordset)==57 and len(sourcewords)==6 and len(wordset-sourcewords)==51
e=read(O/'e4_capture.json');events=[json.loads(line) for line in e['stdout'].splitlines() if line.startswith('{')];exits=[z['exit_code'] for z in events if z.get('event')=='step_finished']
assert e['exit_code']==0 and exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED'
size=sum(p.stat().st_size for p in O.iterdir() if p.is_file());assert size<32*1024**2
files={str(p.relative_to(R)).replace('\\','/'):H(p) for p in O.iterdir() if p.is_file()}
handoff=R/'docs/RESEARCH_EXECUTION_HANDOFF_V650.md';files[str(handoff.relative_to(R)).replace('\\','/')]=H(handoff)
out={'schema':'UFS_FINAL_REVIEW_VALIDATION_V1','base_HEAD':base,
     'evidence_validation':'PASS_COMPLETE_C4_OPERATOR_DOMAIN_STRUCTURAL_ZERO_SECTORS_AND_COMPLETE_SOURCE_CJ_FAMILY',
     'scientific_acceptance':'NOT_PERFORMED','authority':'34/39; E5/A5 OPEN','custody':'EXIT_2_SEVEN_UNRESOLVED','state_unchanged':True,
     'scope':'Complete retained nonlinear C4 differential operators; probe0 and source0..12 zeros; target-loop exclusions; complete source-CJ tensor. Five merged families remain.',
     'full_C4_or_F_log5_complete':False,'full_investigation_complete':False,'all_label_operator_entries':207440,'source_CJ_domain_per_probe':14612400,'source_CJ_nonzeros':[0,85112],
     'authenticated_input_and_source_bindings':len(bindings),'preserved_old_mode_blob_entries':len(tree.splitlines()),'successful_captures':completed,'failed_or_unfinished_new_runs':[],
     'maximum_successful_private_sample_bytes':maxmem,'sample_is_continuous_peak':False,'packet_bytes_before_seal':size,'e4_step_exits':exits,
     'limitations':['shared action/reference/charts/ring/curated data/helpers/software/AI author','GF primitive is a representative with matching Euler columns, not historical density byte reproduction','selected original-builder matrices plus all-label two-route tables, not every full loop trace','other five merged C4 families and remaining finite bases not computed','no full common trace/product/contact limit, measure/QAP or physical viability claim'],
     'new_files_sha256':files}
dump(O/'final_review_validation_receipt.json',out);dump(C/'final_review_validation_receipt.json',out)
print(json.dumps({k:v for k,v in out.items() if k not in ['new_files_sha256','limitations','successful_captures']},sort_keys=True))
