from pathlib import Path
from hashlib import sha256
import json,gzip,sys,time,threading,os
from support import *
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'canonical_so10_u_F_maximal_cutoff'))
from graded import pmul,lifted,constant,ZERO,identity,multiply,scale
O=Path(__file__).resolve().parent;tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,h in json.loads((O/'fixtures_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==h,path
inventory=json.loads(gzip.decompress((O/'inventory_result.json.gz').read_bytes()))
OFF={'B':(0,2),'L':(2,2),'s':(4,3),'C':(7,2),'a':(9,2)};DIM=11;NB=7
def full(vertices,roots,info,odds=ODD):
    X={}
    for name,M in vertices.items():
        mask=info['vertices'][name]['mask']
        for ij,v in M.items():X.setdefault(ij,{})[mask]=X.get(ij,{}).get(mask,ZERO)+v
    power={(i,i):{0:constant(1)} for i in range(DIM)}
    for n in range(4):power=pmul(power,X,odds)
    out=ZERO
    for name,M in roots.items():
        z=pmul(power,lifted(M,info['roots'][name]['mask']),odds)
        out+=sum((poly.get(TARGET,ZERO)*(-1 if i>=NB else 1) for (i,j),poly in z.items() if i==j),ZERO)
    return out
def word_value(word,vertices,roots,info):
    labels=word['word']+[word['root']];M=vertices[labels[0]]
    for name in labels[1:]:M=multiply(M,vertices[name] if name in vertices else roots[name])
    masks=[(info['vertices'][name] if name in vertices else info['roots'][name])['mask'] for name in labels]
    return exterior_sign(masks)*sum((v*(-1 if i>=NB else 1) for (i,j),v in M.items() if i==j),ZERO)
results=[]
for info in inventory['probes']:
    for seed in [1,2,5]:
        matrices={}
        for no,(name,item) in enumerate(sorted({**info['vertices'],**info['roots']}.items())):
            M={}
            for row,col in item['edges']:
                ro,nr=OFF[row];co,nc=OFF[col]
                for i in range(nr):
                    for j in range(nc):M[ro+i,co+j]=constant(seed*(no+1)+(i+1)**2*(j+2)+(j+1)**2-2*i*j)
            matrices[name]=M
        vertices={name:matrices[name] for name in info['vertices']};roots={name:matrices[name] for name in info['roots']}
        direct=full(vertices,roots,info);values=[word_value(word,vertices,roots,info) for word in info['words']]
        assert direct==sum(values,ZERO)
        exchanged={}
        for name,item in {**info['vertices'],**info['roots']}.items():
            if item['slot'] in [1,2]:exchanged[name]=matrices[name.rsplit('@',1)[0]+'@'+str(3-item['slot'])]
            else:exchanged[name]=scale(matrices[name],constant(-1)) if item['slot']==12 else matrices[name]
        swapped=full({name:exchanged[name] for name in vertices},{name:exchanged[name] for name in roots},info);assert direct==-swapped
        controls={'commuting_exterior':direct-full(vertices,roots,info,0),'ghost_exchange_without_sign':direct-swapped}
        for title,tablename,pat in [('omit_GF_CC','VGF','CC'),('omit_source_CJ','VS','CJ')]:
            kept={name:M for name,M in vertices.items() if not(info['vertices'][name]['name']==tablename and info['vertices'][name]['pattern']==pat)}
            controls[title]=direct-full(kept,roots,info)
        results.append({'probe':info['probe'],'seed':seed,'full_fourth_power':str(direct),'word_sum':str(sum(values,ZERO)),'ordered_word_values':[str(v) for v in values],
                        'controls':{k:{'difference':str(v),'sensitive':bool(v)} for k,v in controls.items()}})
        print('STAGE fourth_fixture '+str((info['probe'],seed)),flush=True)
for name in results[0]['controls']:assert any(z['controls'][name]['sensitive'] for z in results),name
out={'schema':'UFS3A_COMPLETE_FOURTH_WORD_FIXTURES','results':results,'physical_parameter_points':False,'quantum_target_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'fixtures_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({k:v for k,v in out.items() if k!='results'},sort_keys=True),flush=True);timer.cancel()
