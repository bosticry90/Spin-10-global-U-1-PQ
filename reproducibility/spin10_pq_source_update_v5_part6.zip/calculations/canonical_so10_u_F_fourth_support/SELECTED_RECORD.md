# UFS3B actual fourth-edge coefficients and sensitive family controls

Use completed ALL-label tables and complete UFS2 word inventory,without
an old coefficient operand. Primary uses Euler-derived tables,axis3,q+1,
unrooted X^4; replay uses polarization/reconstructed-GF tables,axis2,q-1,
rooted powers. Independently evaluate each supported ordered word with
literal exterior order and supertrace and require equality with X^4.

Fixed(r,h,k,scalar) contexts,not chosen from a quantum target:
(13,0,12,136),(13,12,13,207),(13,13,14,137),
(20,13,20,169),(44,13,44,134),(13,0,13,206),(13,0,3,187).
Both probes. Save all individual word values,zero counts,root classes,
and total. This is a formula/calibration test,not a complete tensor.

Whole-family omissions:GF_CC,source-CJ,H_u,M_u,GF_nC,GF_nx,M0_CC.
Compute their changes by BOTH removed-word sums and independently
recomputed reduced fourth powers. Report sensitivity per case; never
turn a zero control into evidence for global absence. Both-broken
ghosts are included because old unbroken C0 witness was insensitive.
Any mismatch remains,without fitting a sign or physical input.

Native300s,8GiB/350MiB/32MiB limits unchanged. Sources and completed
input table bytes frozen before launch; target/peer access guards. No
authority change or old full quantum-remainder operand. Full C4 requires
a compact complete contraction,not extrapolation from these contexts.
