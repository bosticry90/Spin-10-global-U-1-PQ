# UFS2B H/broken quantum support before dropping any family

Selected coefficients confirm nonzero nonlinear source-CJ contributions
at both-broken ghosts; GF_CC and M0_CC controls remain insensitive.
Do NOT infer a global zero from that. Refine the COMPLETE all-label
tables by H/broken quantum and external ghost/source types, preserving
B,L,C,a sectors and scalar s. The actual free G preserves color type.

For each probe, external source type and ordered HH/HB/BB ghost pair,
enumerate all exact grade words and closed refined sector paths. Restrict
each single-ghost class to its assigned ghost-slot type; CC classes must
match both types. Scalar/field indices remain unrestricted supersets.
Pathless words are then provably absent by actual full support,without
coefficient cancellation or a quantum target. Surviving words remain
candidates; do not call them independent/nonzero physical amplitudes.

Record ALL actual source labels carrying J in eligible tables. If no
source-bearing operator exists for a label, its C4 coefficient is a
structural zero in this domain. A source or probe zero theorem requires
all refined classes/path possibilities checked,not selected witnesses.
Compare reduced sums in prior actual cases after any exclusion. Resource
review180s/8GiB/350MiB/32MiB and authority/scope ceilings unchanged.
