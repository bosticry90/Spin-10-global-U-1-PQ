# UFS1-4: complete nonlinear fourth-edge operator domain

Prospective at fc20c4a3. Previous goal turn PROGRESS: complete maximal
F5=0 by typed identity. Fresh preflight clean main/no matching workers.
Goal ACTIVE/incomplete. Current AGENTS governs; project_state remains
state113,authority34/39,E5/A5 OPEN,custodyexit2/seven unresolved.

Question: recover every eligible C4 vertex/tangent before deriving the
full45x990x328 coefficient tensor. A small guessed family list or selected
successful witness is insufficient. Since C5_F=0 is now qualified in the
declared domain, the actual F log5 cutoff is C4_F.

UFS1: derive complete all-label differential operator tables from actual
GF Euler columns, source density, QG and original scalar current. Retain
all four Lorentz components, momentum monomials, physical source/ghost/
scalar labels and exact coefficients. External jets0 only AFTER source/
field differentiation. Eligible V0 has positive external grade<=2; H_u
has u plus external grade<=1; M0 has positive grade<=2; M_u has u plus
external grade<=1. Fields/sources allowed externally: one JL,one scalar,
up to two distinct ghosts,nu-degree0/1. Whole original-free Mf/Hu groups
are excluded only by the owning UMH pairing theorem. No M_u deletion.

Primary uses GF Euler derivatives and graded transpose completion, ordered
left/right Hessians and right field tangents, left source Euler for QG.
Replay reconstructs GF density by the Lambda/a homotopy, checks its full
Euler columns back, then uses literal two-mode polarization. Source Euler
replay uses the corresponding minus-right convention. Recover scalar
current from its derivative density as a second route. Compare exact
FULL tables including zeros; same action/ring/data/helper authorship is
disclosed, not external scientific validation.

GF homotopy is a candidate derivation, not assumed: sum phi_i E_i/(d+1)
for i in Lambda/a,where d is the remaining Lambda/a degree. Verify every
given Euler column from the reconstructed density. Missing terms or a
boundary issue is a failure/limitation to preserve, not a favorable new
action choice. No source-free restriction before source differentiation.

UFS2: enumerate all actual grade partitions and quantum-sector closed
walks of(u,nu,JL,C1,C2,x) at four edges plus root. Distinct odd ghosts
and odd JL retain their ordering. Include all actual merged vertices
and nonlinear roots, especially both-broken GF-aaCC and source-D.
Whole-support physical potential/fermion/source2 exclusions may be reused
only within their inherited proof scopes. Quantum contact Euler terms
on conversion remain required. This is an inventory, not measured C4.

UFS3: derive the compact scalar/color expression from complete support;
test noncommuting graded fixtures and sensitive original508-coordinate
coefficients, including both-broken ghosts. Preserve any mismatch.
UFS4: full coefficient extraction/late comparison only after domain and
formula verification. No old quantum remainder is a native operand,
no fitting,normalization/parameter change,protected stage or promotion.

Fixed original unshifted SMA/CSW/EDS,A0,constant u,intrinsic1,symbolic
g10/xi/eta_H,common hbar/(16pi^2),nonexceptional Euclidean LOCAL RELATIVE
formal positive-heat UV symbol. Common continuum trace/product/contact
limits,other finite bases,measure/QAP,E5/A5,physical viability remain open.
b0,kappa,chi4,IR freedoms remain distinct/unfixed. No agents,branch/worktree,
remote action,publication,outreach or foundational/physical scheme adoption.

Native300s/review180s after imports,8GiB sampled private,350MiB launch
available-pagefile floor,32MiB packet. Freeze all sources/input hashes
before calculation. Preserve exact failed and unfinished runs; exhaustion
is incomplete, never truncated PASS. Owned-child full captures and final
source/old-tree custody required. Standard E4 once before local commit.
