from pathlib import Path
from hashlib import sha256
import json,gzip,sys,time,threading,os
from matrices import *
O=Path(__file__).resolve().parent;R=O.parents[1];role=sys.argv[1];assert role in ['primary','replay']
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,hsh in json.loads((O/'selected_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==hsh,path
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
        if p.parent.resolve()==O and p.name.startswith(peer+'_selected'):raise PermissionError('UFS_SELECTED_PEER_DENIED')
        if p.parent.name in ['canonical_so10_u_pair_contact_model','canonical_so10_intrinsic_auxiliary_ghost_source']:raise PermissionError('UFS_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard)
denied=0
for p in [O/(('replay' if role=='primary' else 'primary')+'_selected.json.gz'),R/'calculations/canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz']:
    try:p.read_bytes()
    except PermissionError:denied+=1
assert denied==2
loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()))
tables=loadz(O/(role+'_operators.json.gz'))['tables'];inventory=loadz(O/'inventory_result.json.gz');data=load(role)
axis=3 if role=='primary' else 2;q=1 if role=='primary' else -1;G=propagator(data,q);results=[]
for r,h,k,ix in [(13,0,12,136),(13,12,13,207),(13,13,14,137),(20,13,20,169),(44,13,44,134),(13,0,13,206),(13,0,3,187)]:
    for info in inventory['probes']:
        V,roots=selected_parts(tables,info,r,h,k,ix,axis,q);vertices={name:multiply(G,M) for name,M in V.items()};X=combine(vertices,info['vertices'])
        power=full_coefficient(X,roots,info,role)
        words=[word_coefficient(word,vertices,roots,info) for word in info['words']]
        by_root={name:sum((v for word,v in zip(info['words'],words) if word['root']==name),ZERO) for name in roots}
        assert power==by_root,(r,h,k,ix,info['probe'],{a:str(b) for a,b in power.items()},{a:str(b) for a,b in by_root.items()})
        total=sum(power.values(),ZERO);controls={}
        for title in ['GF_CC','source_CJ','Hu','Mu','GF_nC','GF_nx','M0_CC']:
            def removed(name):
                item=info['vertices'].get(name,info['roots'].get(name));nm=item['name'];pat=item['pattern']
                return (title=='GF_CC' and nm=='VGF' and pat=='CC') or (title=='source_CJ' and nm=='VS' and pat=='CJ') or (title=='Hu' and nm.startswith('HU')) or (title=='Mu' and nm.startswith('MU')) or (title=='GF_nC' and nm=='VGF' and pat=='nC') or (title=='GF_nx' and nm=='VGF' and pat=='nx') or (title=='M0_CC' and nm=='M0' and pat=='CC')
            vv={name:M for name,M in vertices.items() if not removed(name)};rr={name:M for name,M in roots.items() if not removed(name)}
            XX=combine(vv,info['vertices']);actual=total-sum(full_coefficient(XX,rr,info,role).values(),ZERO)
            expected=sum((v for word,v in zip(info['words'],words) if any(removed(name) for name in word['word']+[word['root']])),ZERO)
            assert actual==expected
            controls[title]={'difference':str(actual),'sensitive':bool(actual)}
        out={'source':r,'ghosts':[h,k],'scalar':ix,'probe':info['probe'],'C4':str(total),'root_groups':{name:str(v) for name,v in power.items()},
             'ordered_word_values':[str(v) for v in words],'controls':controls}
        results.append(out);print('STAGE selected_C4 '+json.dumps({key:out[key] for key in ['source','ghosts','scalar','probe','C4']},sort_keys=True),flush=True)
out={'schema':'UFS3B_ACTUAL_COMPLETE_FOURTH_OPERATOR_CALIBRATIONS','role':role,'axis':axis,'q':q,'results':results,'guard_denials':denied,'full_C4_tensor_claim':False,'known_quantum_remainder_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/(role+'_selected.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({key:v for key,v in out.items() if key!='results'},sort_keys=True),flush=True);timer.cancel()
