from collections import defaultdict
from fractions import Fraction
from support import *
from operators import load,co,dec,Coeff,ZERO,I,constant
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'canonical_so10_u_F_maximal_cutoff'))
from graded import pmul,lifted,multiply,plus,scale,identity,times
NB=418;DIM=508
def field(i,axis):
    if i<180:return i//4 if i%4==axis else None
    if i<508:return 90+i-180
    if i<553:return 45+i-508
    if i<598:return 418+i-553
    return 463+i-598
def add_poly(M,ij,mask,v):
    if v:
        z=M.setdefault(ij,{});z[mask]=z.get(mask,ZERO)+v
def combine(parts,info):
    out={}
    for name,M in parts.items():
        for ij,v in M.items():add_poly(out,ij,info[name]['mask'],v)
    return {ij:{m:v for m,v in p.items() if v} for ij,p in out.items() if any(p.values())}
def selected_parts(tables,info,r,h,k,ix,axis,q):
    mapping={1151+r:JJ,553+h:CC1,553+k:CC2,180+ix:XX}
    V={name:{} for name in info['vertices']};M={name:{} for name in info['roots']}
    used=set(item['name'] for item in list(info['vertices'].values())+list(info['roots'].values()))
    for name in used:
        for i,j,w,nd,power,terms in tables[name]:
            a,b=field(i,axis),field(j,axis)
            if a is None or b is None or any(p for mu,p in enumerate(power) if mu!=axis):continue
            if any(z not in mapping for z in w):continue
            bits=[mapping[z] for z in w]
            sg=exterior_sign(bits);v=Coeff([(tuple(key),Fraction(n,d)) for key,n,d in terms])*(sg*q**sum(power))
            pat=pattern(w,nd);ghost=CC1|CC2 if CC1 in bits and CC2 in bits else CC1 if CC1 in bits else CC2 if CC2 in bits else 0
            slot=12 if ghost==CC1|CC2 else 1 if ghost==CC1 else 2 if ghost==CC2 else 0
            key=label(name,pat,slot);part=M if name.startswith('M') else V
            assert key in part,(name,pat,slot)
            part[key][a,b]=part[key].get((a,b),ZERO)+v
    V={name:{ij:v for ij,v in mat.items() if v} for name,mat in V.items()};M={name:{ij:v for ij,v in mat.items() if v} for name,mat in M.items()}
    return V,M
def propagator(data,q):
    G={}
    for (i,j),v in dec(data['G0']).items():G[i,j]=v*q if i<45<=j or j<45<=i else v
    for i in range(328):G[90+i,90+i]=constant(1)
    for i in range(45):G[418+i,463+i]=constant(1);G[463+i,418+i]=constant(-1)
    return G
def full_coefficient(X,roots,info,role):
    values={}
    if role=='primary':
        P={(i,i):{0:constant(1)} for i in range(DIM)}
        for n in range(4):P=pmul(P,X)
        for name,M in roots.items():
            z=pmul(P,lifted(M,info['roots'][name]['mask']))
            values[name]=sum((poly.get(TARGET,ZERO)*(-1 if i>=NB else 1) for (i,j),poly in z.items() if i==j),ZERO)
    else:
        for name,M in roots.items():
            z=lifted(M,info['roots'][name]['mask'])
            for n in range(4):z=pmul(z,X)
            values[name]=sum((poly.get(TARGET,ZERO)*(-1 if i>=NB else 1) for (i,j),poly in z.items() if i==j),ZERO)
    return values
def word_coefficient(word,vertices,roots,info):
    labels=word['word']+[word['root']];mats=[vertices[name] for name in word['word']]+[roots[word['root']]]
    if not all(mats):return ZERO
    M=mats[0]
    for mat in mats[1:]:
        M=multiply(M,mat)
        if not M:return ZERO
    masks=[(info['vertices'][name] if name in info['vertices'] else info['roots'][name])['mask'] for name in labels]
    return exterior_sign(masks)*sum((v*(-1 if i>=NB else 1) for (i,j),v in M.items() if i==j),ZERO)
