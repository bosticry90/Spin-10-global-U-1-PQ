# UFS4D complete nonlinear source-CJ contribution

UFS2B proves no probe0 C4 color paths, no paths through GF_CC or M0_CC
in this TARGET, and source labels0..12 absent. This is a restricted loop
exclusion,not deletion of the classical interactions or tensor D. Source-
CJ remains with three ordered terms per ghost placement and is sensitive
at the new both-broken witness. Complete this indispensable C4 family.

Let D[r,a,h,k] be the coefficient of M0_CC (h<k), extended antisymmetrically
in ghost labels. Its direct loop contribution is excluded, but its source
descendant has effective even ghost-diagonal kernel

 K_(r,h)[c,a]=-D[r,a,h,c].

Independently recover K from the GLOBAL VS_CJ entry H_(C_c,a_a) with
external canonical C_h JLambda_r. Reordering to JLambda_r C_h and the
G_(a,C) sign cancel, so that global coefficient is exactly K. Verify all
entries,not a chosen sign. No source or quantum coefficient is fitted.

The combined coefficient JLambda*C_h is even. Substitute it for the even
Ja coefficient in the qualified arbitrary-K T4 three-product identity.
The embedding of exterior algebras gives, for h<k,

 F4_sourceCJ[r,h,k,i]=T4[K_(r,h),ghost k,i]
                         -T4[K_(r,k),ghost h,i].

The minus is from J*C_k*C_h=-J*C_h*C_k. This is only the source-CJ
subfamily; all other C4 classes remain. Test the embedding with full
graded fourth powers and noncommuting matrices BEFORE full extraction.
Require sensitive wrong-antisymmetry/source-transpose/odd-sign controls.

Then compute every45x990x328 coefficient of this family,both probes.
Primary precontracts N R_a and recovers K from field-flow D; replay
contracts weights into N first,associates color products differently and
recovers K from source-density Hessian. N/J from their own complete GF
operator tables,R from actual scalar flow; free H/Mu probe formula checked
against actual tables. Keep separate three T4 rooted products and their
antisymmetrized sum,including all implicit zeros. Native does not read
selected coefficients,peer or old quantum remainder. No whole-C4 claim.

After both arrays agree,compare against prior independently computed
whole-family omission differences in every selected context. Preserve
all mismatches. Same native300s/review180s,8GiB/350MiB/32MiB and authority
limits. Do not expand resources silently. All source,contact,QAP,physical
and normalization limitations of UFS remain unchanged.
