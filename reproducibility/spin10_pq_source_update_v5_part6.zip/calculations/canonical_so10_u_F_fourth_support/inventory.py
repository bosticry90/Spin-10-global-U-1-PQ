from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import json,gzip,time,threading,os
from operators import *
from support import *
O=Path(__file__).resolve().parent;tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,h in json.loads((O/'inventory_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==h,path
loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()))
a=loadz(O/'primary_operators.json.gz');b=loadz(O/'replay_operators.json.gz')
assert a['tables']==b['tables'] and a['summaries']==b['summaries']
assert a['guard_denials']==b['guard_denials']==2 and b['metadata']['all_given_GF_Euler_columns_recovered']
assert len(a['tables'])==8 and a['input_GF_columns']==b['input_GF_columns']
counts={}
for name,rows in a['tables'].items():
    keys=set()
    for i,j,w,nd,power,terms in rows:
        key=(i,j,tuple(w),nd,tuple(power));assert key not in keys;keys.add(key)
        assert 0<=i<643 and 0<=j<643 and len(power)==4 and all(isinstance(z,int) and z>=0 for z in power)
        low=0 if name.startswith(('HU','MU')) else 1;high=1 if name.startswith(('HU','MU')) else 2
        assert allowed(tuple((k,()) for k in w),nd,low,high)==tuple(w)
        assert terms and Coeff([(tuple(k),Fraction(n,d)) for k,n,d in terms])
    counts[name]=len(keys)
probes=[]
for probe in range(2):
    vertices,roots=make_classes(a['tables'],probe);result=enumerate_words(vertices,roots)
    by_root=Counter(z['root'] for z in result['words']);by_merged=Counter()
    for z in result['words']:
        combined=[z['root']]+z['word']
        merged=[name for name in combined if (roots.get(name) or vertices[name])['mask'].bit_count()-(1 if name in roots else 0)==2]
        assert len(merged)==1,(combined,merged)
        by_merged[merged[0]]+=1
    probes.append({'probe':probe,'vertices':vertices,'roots':roots,**result,'words_by_root':dict(sorted(by_root.items())),'words_by_merged_grade':dict(sorted(by_merged.items()))})
    print('STAGE inventory '+json.dumps({k:v for k,v in probes[-1].items() if k not in ['vertices','roots','words']},sort_keys=True),flush=True)
quartic=[];sourceD=[]
for i,j,w,nd,power,terms in a['tables']['VGF']:
    if pattern(w,nd)=='CC':
        assert i>=598 and j>=598 and len(w)==2 and all(k>=565 for k in w)
        quartic.append(tuple(w))
for i,j,w,nd,power,terms in a['tables']['VS']:
    if pattern(w,nd)=='CJ':
        ghosts=[k for k in w if 553<=k<598];assert len(ghosts)==1 and ghosts[0]>=565
        sourceD.append(tuple(w))
out={'schema':'UFS2_COMPLETE_F_C4_SUPPORT','full_primary_replay_tables_equal':True,'entry_counts':counts,'reconstructed_GF_density_terms':b['metadata']['reconstructed_GF_density_terms'],
     'probes':probes,'GF_CC_both_broken_external_ghost_pairs':len(set(quartic)),'VS_CJ_broken_external_ghost_source_pairs':len(set(sourceD)),
     'nonzero_independent_color_coefficient_claim':False,'full_C4_tensor_claim':False,'quantum_target_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/'inventory_result.json.gz').open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({k:v for k,v in out.items() if k!='probes'},sort_keys=True),flush=True);timer.cancel()
