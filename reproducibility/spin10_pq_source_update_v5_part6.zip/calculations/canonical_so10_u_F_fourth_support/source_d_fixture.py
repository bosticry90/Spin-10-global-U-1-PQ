from pathlib import Path
from hashlib import sha256
import ast,json,sys,time,threading,os
from matrices import *
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'canonical_so10_u_T_cutoff_tensor'))
from algebra import color_weights
O=Path(__file__).resolve().parent;R=O.parents[1]
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,h in json.loads((O/'source_d_fixture_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==h,path
tree=ast.parse((R/'calculations/canonical_so10_u_T_cutoff_tensor/fixtures.py').read_bytes());loop=next(n for n in tree.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='seed')
embednode=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='embed')
setup=[]
for node in loop.body:
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='X' for t in node.targets):break
    setup.append(node)
results=[]
for seed in [2,5]:
    ns=dict(globals());ns['seed']=seed;ns['transpose']=lambda M:{(j,i):v for (i,j),v in M.items()}
    exec(compile(ast.Module(body=[embednode]+setup,type_ignores=[]),'UFS_SOURCE_EVEN_EMBED_SETUP','exec'),ns)
    embed=ns['embed'];N=ns['N'];Rx=ns['R'];G=ns['G'];K1=ns['K'];K2=ns['gen'](2,2,33);JB2=ns['gen'](2,2,29);JL2=ns['gen'](2,2,31)
    transpose=ns['transpose'];VC2={};embed(VC2,transpose(JB2),0,9);embed(VC2,scale(transpose(JL2),constant(-1)),2,9);embed(VC2,JB2,9,0);embed(VC2,JL2,9,2)
    vertices=[(NN,multiply(G,ns['Vn'])),(XX,multiply(G,ns['Vx'])),(UU,multiply(G,ns['VH'])),(CC1,multiply(G,ns['VC'])),(CC2,multiply(G,VC2))]
    for mask,K in [(JJ|CC1,K1),(JJ|CC2,K2)]:
        X={};embed(X,transpose(K),7,7);embed(X,K,9,9);vertices.append((mask,X))
    roots=[(EPS|UU,ns['MU']),(EPS|XX,ns['MX']),(EPS|CC1,ns['MC']),(EPS|CC2,ns['MC'])]
    def full(odds):
        X={}
        for mask,M in vertices:
            for ij,v in M.items():add_poly(X,ij,mask,v)
        P={(i,i):{0:constant(1)} for i in range(11)}
        for n in range(4):P=pmul(P,X,odds)
        value=ZERO
        for mask,M in roots:
            z=pmul(P,lifted(M,mask),odds)
            value+=sum((p.get(TARGET,ZERO)*(-1 if i>=7 else 1) for (i,j),p in z.items() if i==j),ZERO)
        return value
    NR=multiply(N,transpose(Rx));inner=lambda W:sum((times(v,NR.get(ij,ZERO)) for ij,v in W.items()),ZERO)
    f=lambda K,JB,JL:sum((inner(W) for W in color_weights(ns['Om'],JB,JL,K,ns['UB'],ns['UL'],ns['H'],2).values()),ZERO)
    first=f(K1,JB2,JL2);second=f(K2,ns['JB'],ns['JL']);direct=full(ODD);assert direct==first-second
    bad=f(transpose(K1),JB2,JL2)-f(transpose(K2),ns['JB'],ns['JL'])
    controls={'wrong_ghost_antisymmetry':direct-(first+second),'wrong_source_transpose':direct-bad,'commuting_odd_coefficients':direct-full(0),'omit_second_source_placement':second}
    assert all(controls.values())
    results.append({'seed':seed,'full_F_fourth_power':str(direct),'T4_first_source_placement':str(first),'T4_second_source_placement':str(second),'controls':{k:str(v) for k,v in controls.items()}})
out={'schema':'UFS4D_SOURCE_ODD_PAIR_TO_EVEN_KERNEL','results':results,'physical_parameter_points':False,'quantum_target_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'source_d_fixture_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
