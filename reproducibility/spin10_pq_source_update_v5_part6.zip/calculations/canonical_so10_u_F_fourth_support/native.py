from pathlib import Path
from hashlib import sha256
import json,gzip,sys,time,threading,os
from operators import *
O=Path(__file__).resolve().parent;R=O.parents[1];role=sys.argv[1];assert role in ['primary','replay']
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,h in json.loads((O/'preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==h,path
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        q=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
        if q.parent.resolve()==O and (q.name.startswith(peer+'_') or q.name.startswith('review_')):raise PermissionError('UFS_PEER_DENIED')
        if q.parent.name in ['canonical_so10_u_pair_contact_model','canonical_so10_intrinsic_auxiliary_ghost_source']:raise PermissionError('UFS_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard)
denied=0
for q in [O/(('replay' if role=='primary' else 'primary')+'_operators.json.gz'),R/'calculations/canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz']:
    try:q.read_bytes()
    except PermissionError:denied+=1
assert denied==2
data=load(role);GF={i:decode(rows) for i,rows in data['GF_gradient']};Q=list(map(decode,data['QG']));flows={i:decode(rows) for i,rows in data['field_flows']};RR=list(map(dec,data['R']))
tables={};meta={}
if role=='primary':tables['VGF']=gf_hessian(GF,role)
else:
    raw=gf_primitive(GF);meta['reconstructed_GF_density_terms']=len(raw);meta['all_given_GF_Euler_columns_recovered']=True
    tables['VGF']=hessian(raw,role,1,2)
print('STAGE VGF '+role+' '+str(len(tables['VGF'])),flush=True)
tables['VS']=hessian(source_density(data),role,1,2)
tables['VX']=scalar_current(RR,role)
tables['M0']=tangent(flows,role,1,2)
for probe in range(2):
    tables['HU'+str(probe)]=hessian(Q[probe],role,0,1)
    QU=source_flows(Q[probe],role);tables['MU'+str(probe)]=tangent(QU,role,0,1)
    print('STAGE probe '+role+' '+str(probe)+' HU '+str(len(tables['HU'+str(probe)]))+' MU '+str(len(tables['MU'+str(probe)])),flush=True)
summaries={name:summary(T) for name,T in tables.items()}
out={'schema':'UFS1_COMPLETE_ALL_LABEL_OPERATOR_TABLES','role':role,'tables':{name:encode(T) for name,T in tables.items()},'summaries':summaries,'metadata':meta,'input_GF_columns':len(GF),'guard_denials':denied,'quantum_target_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2,'PACKET_EXHAUSTED_INCOMPLETE'
with (O/(role+'_operators.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({k:v for k,v in out.items() if k!='tables'},sort_keys=True),flush=True);timer.cancel()
