# UFS4D implementation domain and exact zero complements

The source-D parity embedding passed noncommuting full-power tests.
For complete extraction, verify from actual tables K=P_B K P_B and
N=P_B N. Check the actual free Hu/Mu tables against the already qualified
P_H/P_B formula. These yield sourceD probe0 zero for EACH of the three
T4 products: K U_B=K(U_B Omega+U_L)=0,while the third weight has its
N-row index in H and hence N annihilates it. This is a full support/
matrix identity,not omission by selected zero. Record the empty complete
probe0 maps,including every implicit zero.

K is absent for external ghostH/source0..12. For the other ghostH,
J_B is H/H and J_L=0,so every probeB sourceD T4 contraction vanishes.
Compute only nonempty K and distinct external ghost pairs in broken
directions,with antisymmetrization; these proven zero complements are
part of the FULL45x990x328 declared domain. INTERNAL scalar-generator
index a remains all45 directions. No contraction is dropped for smallness.

Native300s after imports per role,8GiB/350MiB/32MiB unchanged. Distinct
primary/replay association and K recovery as SOURCE_D_RECORD. Retain
all source kernels,three family maps,sum,and coverage,without quantum
target/calibration/peer access. Exhaustion remains incomplete,not PASS.
