from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import defaultdict,Counter
import ast,json,gzip,sys,time,threading,os
from matrices import *
import operators as OP
from operators import decode,dimension,parity,degree,JP
O=Path(__file__).resolve().parent;R=O.parents[1];tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()))
for path,h in read(O/'review_preparation.json')['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==h,path
a=loadz(O/'primary_operators.json.gz');b=loadz(O/'replay_operators.json.gz');assert a['tables']==b['tables']
sa=loadz(O/'primary_selected.json.gz');sb=loadz(O/'replay_selected.json.gz');assert sa['results']==sb['results'] and sa['guard_denials']==sb['guard_denials']==2
pa=loadz(O/'primary_source_d.json.gz');pb=loadz(O/'replay_source_d.json.gz');assert pa['results']==pb['results'] and pa['source_kernel']==pb['source_kernel'] and pa['guard_denials']==pb['guard_denials']==3
ref=loadz(O/'refined_result.json.gz');inv=loadz(O/'inventory_result.json.gz')
assert ref['active_source_labels']==list(range(13,45)) and ref['inactive_source_labels']==list(range(13))
assert all(not z['words'] for z in ref['cases'] if z['probe']==0)
assert ref['GF_CC_supported_words']==ref['M0_CC_supported_words']==0
def fine(i):
    if i<180:return 'B'+('H' if i//4<12 else 'b')
    if i<508:return 's'
    start,s=(508,'L') if i<553 else (553,'C') if i<598 else (598,'a')
    return s+('H' if i-start<12 else 'b')
def fold(sec):return ['s'] if sec=='s' else [sec,'L'+sec[1]] if sec[0]=='B' else ['B'+sec[1]] if sec[0]=='L' else ['a'+sec[1]] if sec[0]=='C' else ['C'+sec[1]]
# Independent boolean polynomial matrix closure. Track family markers
# without any coefficient cancellation; a zero is a strict support zero.
def boolmul(A,B):
    rows=defaultdict(list);out=defaultdict(set)
    for (i,j),polys in B.items():rows[i].append((j,polys))
    for (i,k),polys in A.items():
        for j,other in rows[k]:
            for m,f in polys:
                for n,g in other:
                    if not m&n:out[i,j].add((m|n,f|g))
    return dict(out)
boolean=[]
for case in ref['cases']:
    probe=case['probe'];st=case['source_type'];ght=case['ghost_types'];V=defaultdict(set);M=defaultdict(set)
    for name in ['VGF','VS','VX','HU'+str(probe),'M0','MU'+str(probe)]:
        root=name.startswith('M');hasu=name.startswith(('HU','MU'))
        for i,j,w,nd,power,terms in a['tables'][name]:
            src=[z-1151 for z in w if 1151<=z<1196];gh=[z-553 for z in w if 553<=z<598]
            if src and ('H' if src[0]<12 else 'b')!=st:continue
            masks=[]
            if len(gh)==2:
                if ['H' if h<12 else 'b' for h in gh]!=ght:continue
                masks=[CC1|CC2]
            elif len(gh)==1:masks=[CC1 if slot==0 else CC2 for slot,t in enumerate(ght) if t==('H' if gh[0]<12 else 'b')]
            else:masks=[0]
            pat=pattern(w,nd);flag=1 if name=='VGF' and pat=='CC' else 2 if name=='M0' and pat=='CC' else 4 if name.startswith('MU') and pat=='C' else 0
            base=(EPS if root else 0)|(UU if hasu else 0)|(NN if nd else 0)|(JJ if src else 0)|(XX if any(180<=z<508 for z in w) else 0)
            for mask in masks:
                for row in [fine(i)] if root else fold(fine(i)):(M if root else V)[row,fine(j)].add((base|mask,flag))
    sectors=['BH','Bb','LH','Lb','s','CH','Cb','aH','ab'];P={(s,s):{(0,0)} for s in sectors}
    for n in range(4):P=boolmul(P,V)
    Q=boolmul(P,M);flags=set(f for (i,j),z in Q.items() if i==j for mask,f in z if mask==TARGET)
    assert bool(flags)==bool(case['words'])
    assert not any(f&7 for f in flags),case
    boolean.append({'probe':probe,'source_type':st,'ghost_types':ght,'possible_target_trace':bool(flags),'GF_CC_M0_CC_Mu_C_markers_absent':True})
print('STAGE independent_boolean_support_verified',flush=True)

def decode_tensor(rows):
    out={}
    for r,h,k,i,terms in rows:
        key=(r,h,k,i);assert key not in out and 0<=r<45 and 0<=h<k<45 and 0<=i<328
        out[key]=Coeff([(tuple(p),Fraction(n,d)) for p,n,d in terms]);assert out[key]
    return out
source_maps=[];source_coverage=[]
for entry in pa['results']:
    total=decode_tensor(entry['total']);fams={name:decode_tensor(rows) for name,rows in entry['families'].items()};summed={}
    for M in fams.values():
        for key,v in M.items():summed[key]=summed.get(key,ZERO)+v
    assert {k:v for k,v in summed.items() if v}==total
    assert len(total)==entry['nonzero_counts']['total'] and entry['domain_positions']==14612400 and entry['zero_complement']==14612400-len(total)
    # Validate the complete implicit zero domain,including source/ghost
    # restrictions,without claiming component extraction of other families.
    assert all(r>=13 and h>=12 for r,h,k,i in total)
    checked=0
    for r in range(45):
        for h in range(45):
            for k in range(h+1,45):checked+=328
    assert checked==14612400
    source_maps.append(total);source_coverage.append({'probe':entry['probe'],'positions':checked,'nonzero':len(total),'zero':checked-len(total),'family_counts':{name:len(M) for name,M in fams.items()}})
late=[]
for entry in sa['results']:
    key=(entry['source'],*entry['ghosts'],entry['scalar']);derived=source_maps[entry['probe']].get(key,ZERO);expected=co(entry['controls']['source_CJ']['difference'])
    assert derived==expected,(key,entry['probe'],str(derived),str(expected))
    late.append({'source':entry['source'],'ghosts':entry['ghosts'],'scalar':entry['scalar'],'probe':entry['probe'],'whole_source_CJ':str(derived),'matches_independent_omission':True})

# Old direct action builder,only pure functions under the NEW execution.
ntree=ast.parse((R/'calculations/canonical_so10_u_maximal_heat_cutoff/native.py').read_bytes())
gnames={'field','ext','wave','marked_hessian','gf_hessian','tangent','right_euler_sources','convert'}
gtree=ast.parse((R/'calculations/canonical_so10_u_maximal_heat_cutoff/general_v2.py').read_bytes())
class GhostLabels(ast.NodeTransformer):
    def visit_Compare(self,node):
        self.generic_visit(node)
        if len(node.ops)==1 and isinstance(node.ops[0],ast.Eq) and isinstance(node.left,ast.Name) and node.left.id in ['i','k'] and isinstance(node.comparators[0],ast.Constant) and node.comparators[0].value in [553,565]:
            which='C_LABEL' if node.comparators[0].value==553 else 'D_LABEL';node.comparators[0]=ast.BinOp(left=ast.Constant(value=553),op=ast.Add(),right=ast.Name(id=which,ctx=ast.Load()))
        return node
nodes=[n for n in ntree.body if isinstance(n,ast.FunctionDef) and n.name in ['padd','pmul','mm','add','tr']]
for n in gtree.body:
    if isinstance(n,ast.FunctionDef) and n.name in gnames:
        if n.name in ['ext','marked_hessian','tangent']:n=GhostLabels().visit(n);ast.fix_missing_locations(n)
        nodes.append(n)
data=load('primary');Q=list(map(decode,data['QG']));GF={i:decode(rows) for i,rows in data['GF_gradient']};flows={i:decode(rows) for i,rows in data['field_flows']};RR=list(map(dec,data['R']))
comparisons=[];entry_total=0
for role,axis,q in [('primary',3,1),('replay',2,-1)]:
    ns={'defaultdict':defaultdict,'Counter':Counter,'ZERO':ZERO,'I':I,'constant':constant,'times':times,'JP':JP,'parity':parity,'dimension':dimension,'degree':degree,
        'role':role,'AXIS':axis,'CASE':'F','GF':GF,'Q':Q,'flows':flows,'NB':418,'NC':418,'NA':463,'DIM':508,'EPS':EPS,'UU':UU,'JJ':JJ,'CC1':CC1,'CC2':CC2,'NN':NN,'XX':XX,'TARGET':TARGET,'ODD':ODD}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'UFS_REFERENCE_PURE_OPERATOR_BUILDERS','exec'),ns)
    Sigma={}
    for word,c in data['source_action']:JP.put(Sigma,tuple((ns['convert'](i),()) for i in word),co(c))
    Sigma=JP.clean(Sigma);QU=[]
    for poly in Q:
        E=JP.euler(poly,set(range(643,1286))) if role=='primary' else ns['right_euler_sources'](poly)
        QU.append({src-643:{w:v*((-1)**parity(src-643) if role=='primary' else -1) for w,v in pol.items()} for src,pol in E.items()})
    for r,h,k,ix in [(13,0,12,136),(13,13,14,137),(12,13,14,136)]:
        ns.update(SRC=1151+r,IX=ix,C_LABEL=h,D_LABEL=k)
        for probe in range(2):
            info=inv['probes'][probe];vv,rr=selected_parts(a['tables'] if role=='primary' else b['tables'],info,r,h,k,ix,axis,q)
            newV=combine(vv,info['vertices']);newM=combine(rr,info['roots'])
            VGF=ns['gf_hessian'](q);VS=ns['marked_hessian'](Sigma,q);HU=ns['marked_hessian'](Q[probe],q,UU,1);VX={}
            for aa,Ra in enumerate(RR):
                for (j,i),v in Ra.items():
                    if i==ix:ns['add'](VX,aa,90+j,XX,-q*times(I,v));ns['add'](VX,90+j,aa,XX,q*times(I,v))
            M0,g0=ns['tangent'](flows,q,0,2);MU,gu=ns['tangent'](QU[probe],q,UU,1)
            def merged(parts,cap):
                out={}
                for part in parts:
                    for ij,poly in part.items():
                        for mask,v in poly.items():
                            if mask.bit_count()<=cap:ns['add'](out,*ij,mask,v)
                return {ij:{mask:v for mask,v in poly.items() if v} for ij,poly in out.items() if any(poly.values())}
            oldV=merged([VGF,VS,VX,HU],2);oldM=merged([M0,MU],3)
            assert oldV==newV and oldM==newM,(role,r,h,k,ix,probe)
            n=sum(len(z) for z in oldV.values())+sum(len(z) for z in oldM.values());entry_total+=n
            comparisons.append({'role':role,'axis':axis,'q':q,'source':r,'ghosts':[h,k],'scalar':ix,'probe':probe,'matrix_coefficient_entries':n,'whole_V_M_and_zero_complements_equal':True})
        print('STAGE original_operator_matrices '+str((role,r,h,k,ix)),flush=True)
out={'schema':'UFS_BOUNDED_DOMAIN_AND_SOURCE_FAMILY_REVIEW','all_label_tables_equal':True,'GF_recovered_Euler_columns':b['input_GF_columns'],'GF_primitive_density_terms':b['metadata']['reconstructed_GF_density_terms'],
     'independent_boolean_support':boolean,'probe0_C4_structurally_zero':True,'inactive_C4_source_labels':ref['inactive_source_labels'],
     'GF_CC_M0_CC_Mu_C_target_loops_structurally_absent':True,'remaining_probe1_candidate_words_union':len({(z['root'],tuple(z['word'])) for c in ref['cases'] if c['probe']==1 for z in c['words']}),
     'source_CJ_coverage':source_coverage,'source_kernel_arrays_equal':True,'source_CJ_late_calibrations':late,'original_builder_matrix_comparisons':comparisons,'original_matrix_coefficients_compared':entry_total,
     'all_source_CJ_arrays_equal':True,'full_C4_tensor_or_F_log5_claim':False,'known_quantum_remainder_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({k:v for k,v in out.items() if k not in ['independent_boolean_support','source_CJ_late_calibrations','original_builder_matrix_comparisons']},sort_keys=True),flush=True);timer.cancel()
