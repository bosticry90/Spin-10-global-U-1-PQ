# Next bounded objective: all five remaining C4 merged families

Proposal,not executed coefficient evidence. UFS completed source-CJ,
proved probe0 zero and source0..12 zeros,excluded GF_CC/M0_CC/Mu_C
TARGET loops by full support,and reduced probe1 to57 ordered words.
Six source-CJ words are already owned by the measured family;51 distinct
candidate words remain in their union. Candidate words are not independent
nonzero amplitudes or separately required integrals.

Use the existing immutable all-label operator tables as action inputs.
Freeze a new record before calculation. Recover:

- N from GF_n,Lambda-scalar;
- F_h from GF_nC,antighost-scalar,and the SAME FP scalar tensor in
  GF_nx,antighost-ghost; verify their full mixed-derivative relationship;
- S from M_u,n and ALL corresponding H_u,n B/scalar,Lambda/scalar
  blocks,without assuming S=N or prematurely projecting its colors;
- the M_u,C tensor underlying H_u,C,even though its direct root loop
  is excluded. That tensor is not globally disposable.

Derive and check exact action-based relations,not coefficients fitted to
a quantum target. Each remaining trace has either one scalar segment
or the explicit scalar index in GF_nx. Cut it while preserving original
supertrace/exterior signs. Retain ordered scalar generators on that
segment,including M0_C scalar roots; do not commute them. This should
give compact contractions of N,F_h,S,R_a and finite color/source matrices.
GF_nx can instead be contracted as its explicit ghost-mass scalar tensor.

Check all five families together against noncommuting fixtures and
sensitive whole-operator coefficients,especially both-broken ghosts and
the unmeasured HH candidate class. A selected HH zero is not a theorem.
Reuse the measured source-CJ array exactly once for final assembly.
Then calculate the entire residual C4 tensor by distinct associations;
only after native agreement open the full relative-conversion table.
Keep all remainders and missing domain premises. No fitting,protected
activation,normalization/parameter change or scientific promotion.

Inherited C5_F=0 removes the fifth-edge dependency. It does not prove
the remaining finite bases or continuum product/trace/measure/QAP/physical
limits. Keep those obligations and b0,kappa,chi4,IR freedoms separate.
