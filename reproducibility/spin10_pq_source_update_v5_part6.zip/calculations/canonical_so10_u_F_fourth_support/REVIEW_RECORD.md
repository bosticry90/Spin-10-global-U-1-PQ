# UFS final bounded review

Review180s after imports,8GiB/350MiB/32MiB unchanged. Authenticate all
input/source bytes before calculation. Compare primary/replay complete
operator tables,all selected coefficients/word values/omission changes,
and both whole source-CJ arrays and independently recovered source kernels.
Validate unique field/source/ghost/scalar indices and exact ring entries,
family sums and zero complements in the full family domain.

Independently confirm refined support exclusions by boolean tagged
matrix powers on all H/broken sectors,not the ordered-word DFS. Track
GF_CC,M0_CC and Mu_C markers; report the actual target-specific result.
Source labels absent from every eligible J-bearing operator are complete
structural source zeros. Probe0 zero requires no possible refined trace
path in any external source/ghost type. Surviving probe1 HH words remain
unmeasured until a real coefficient/identity proof; do not extrapolate
the selected HH zero.

Compare new selected whole operator matrices against the original
general_v2 direct builder,extracted as frozen pure functions under this
new record (no old driver,manifest rebinding or historical execution).
Keep only the mathematically required C4 grade caps; source Euler before
restriction. Compare all matrices and zero complements at axes3/2 and
opposite signs in original and replay conventions,for old nonzero,
new both-broken and inactive-source contexts. This is targeted reference
calibration; all-label verification comes from the complete tables.

After complete source-CJ arrays agree,compare that family against prior
independently calculated omission differences in every selected context.
No full old quantum remainder is read. Whole C4/F log5 remains incomplete.
All authority,provenance,shared-error and physical/QAP limits retained.
