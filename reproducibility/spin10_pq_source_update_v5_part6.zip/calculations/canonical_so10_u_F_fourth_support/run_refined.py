from pathlib import Path
from hashlib import sha256
import ast,json,gzip,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-F-fourth-support-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings={str(R/p):h for p,h in json.loads((O/'inputs.json').read_bytes())['input_sha256'].items()}
    for path,h in bindings.items():assert H(Path(path))==h,path
    for name in ['RECORD.md','REFINED_RECORD.md','operators.py','support.py','refined.py','run_refined.py','primary_operators.json.gz','inventory_result.json.gz','primary_selected.json.gz']:
        path=O/name
        if path.suffix=='.py':ast.parse(path.read_bytes())
        if path.suffix!='.gz':
            cp=O/(name+'.source.txt')
            if cp.exists():assert cp.read_bytes()==path.read_bytes()
            else:
                with cp.open('xb') as f:f.write(path.read_bytes())
        bindings[str(path)]=H(path)
    dump(O/'refined_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    z=capture([sys.executable,'-B',str(O/'refined.py')])
    dump(O/'refined_capture.json',z);dump(C/'refined_full_capture.json',z)
    assert z['exit_code']==0 and z['calculation_completed'] and z['post_run_observations_qualified']
    assert json.loads(gzip.decompress((O/'refined_result.json.gz').read_bytes()))['elapsed_after_imports']<180
    assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<32*1024**2
    print('COMPLETED UFS2B',flush=True)
except BaseException:
    dump(O/'refined_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False})
    raise
