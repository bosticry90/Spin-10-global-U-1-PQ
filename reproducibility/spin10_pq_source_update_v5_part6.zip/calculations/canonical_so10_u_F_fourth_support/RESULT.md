# Nonlinear C4 reduced; complete source-CJ family measured

UFS1-4D recovers the complete retained C4 operator domain and proves
several whole-domain structural zeros. It also completes one indispensable
nonlinear source family. See [proof](PROOF.md), [review](review_result.json),
[full source-family arrays](primary_source_d.json.gz) and frozen captures.
Full probe1 C4 and the full F log5 identity remain incomplete.

The two derivation routes agree on all207440 indexed differential
operator coefficients,including all four Lorentz components and implicit
zeros. Replay reconstructs a75953-term GF density representative and
recovers all90 supplied Euler columns exactly; it does not claim to
reproduce the historical raw density bytes. The complete retained
Hessian agrees with the independent Euler-column route.

Coarse support leaves60/122 words for probes0/1. Actual H/broken support
and an independent boolean matrix-power check prove:

- Entire probe0 C4 is zero.
- Complete source rows0..12 are zero.
- GF_CC,M0_CC and M_u,C cannot contribute to this target at four edges.

These are restricted loop exclusions,not deletion of the underlying
classical interactions or a zero theorem for other amplitudes. The
source-CJ descendant of the nonzero D tensor remains essential.

Probe1 retains57 distinct candidate words across HH/HB/BB ghost classes.
The odd-source/ghost coefficient maps to the verified arbitrary-K T4
kernel with a derived antisymmetrization. Two different scalar contractions
and independent classical kernel recoveries calculate the ENTIRE source-CJ
family:85112 nonzero positions and14527288 zeros in probe1;probe0 is
zero throughout. All three rooted maps and complete zero complements
agree,and the family matches14 prior independent omission checks.

## Focused result-to-claim assessment

**Evidence and supported claim.** Complete action derivatives,GF
reconstruction,full grade/sector enumeration,independent color support,
noncommuting fixtures,original-builder whole-matrix checks,and complete
source-family arrays support the stated C4 domain/zero sectors and the
complete source-CJ contribution. The new both-broken coefficient is
nonzero; it supplies a control the old C0 witness could not supply.
Inherited free-root,longitudinal and physical-port exclusions were
authenticated and reused,not re-proved as a global quantum construction.

**Inference gaps and alternatives.** Five merged families remain:
GF_nC,GF_nx,H_u,n,H_u,C,M_u,n. Their candidate support is known; full
coefficients are not. A selected HH zero does not prove that class
vanishes. Root omissions overlap merged families and are not additive
physical contributions. Complete F log5 still requires the remaining
sum and a whole-domain conversion comparison. Other finite bases,
renormalized products,common limits,measure/QAP and physical viability
remain open. A nonzero intermediate family is not an anomaly verdict.

**Significance and authority.** The problem has become a complete
finite operator calculation with exact zero sectors and one measured
nonlinear family. AI capability demonstrated is recovering the actual
action domain,recognizing insensitive controls,proving the appropriate
scope of exclusions,and reusing a qualified kernel with new parity
bookkeeping. Counts are algebraic positions,not particles,experiments
or completion percentages. Shared action,reference,charts,ring,curated
data,helpers/software and AI author limit independence; no external or
experimental validation is claimed. Scientific authority remains34/39,
state113,E5/A5 OPEN; custody exit2/seven unresolved.

**Next discriminating action.** Factor the remaining scalar blocks
from the actual complete tables and compile ALL five remaining merged
families into compact color/scalar contractions. Verify full block
relations and noncommuting formulas before whole-tensor extraction.
Preserve the measured source-CJ array for exact-once assembly. Do not
repeat qualified F5/source-family calculations or expand millions of
full508-coordinate traces. A residual or missing premise is evidence
to preserve,not a reason to fit a favorable normalization.

## Verification limits

Six generic support fixtures,two odd-source embedding fixtures and14
actual coefficient contexts compare complete ordered sums with full
graded powers. Sensitive source,quartic and exterior controls in the
generic domain are distinguished from actual target-specific structural
zeros. Original action-builder comparisons cover49004 nonzero matrix
coefficients and their zero complements at independent axes/signs; that
is targeted reference calibration alongside the all-label derivations.

No old full quantum target was used or read. Resource observations,
project audits,all sources and preparations remain in captures and the
final validation receipt. Native completion and evidence validation
are distinct from scientific acceptance or custody PASS. No protected
stage,foundation,benchmark,normalization scheme or authority changed.
