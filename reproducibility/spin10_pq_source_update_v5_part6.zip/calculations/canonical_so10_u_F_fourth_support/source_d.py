from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from fractions import Fraction
import json,gzip,sys,time,threading,os
from matrices import *
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'canonical_so10_u_T_cutoff_tensor'))
from algebra import color_weights,transpose
O=Path(__file__).resolve().parent;R=O.parents[1];role=sys.argv[1];assert role in ['primary','replay']
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,hsh in json.loads((O/'source_d_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==hsh,path
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        q=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
        if q.parent.resolve()==O and (q.name.startswith(peer+'_') or '_selected' in q.name):raise PermissionError('UFS_SOURCE_D_PEER_OR_CALIBRATION_DENIED')
        if q.parent.name in ['canonical_so10_u_pair_contact_model','canonical_so10_intrinsic_auxiliary_ghost_source']:raise PermissionError('UFS_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard)
denied=0
for q in [O/(('replay' if role=='primary' else 'primary')+'_source_d.json.gz'),O/'primary_selected.json.gz',R/'calculations/canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz']:
    try:q.read_bytes()
    except PermissionError:denied+=1
assert denied==3
rows=json.loads(gzip.decompress((O/(role+'_operators.json.gz')).read_bytes()))['tables'];data=load(role)
def coefficient(terms):return Coeff([(tuple(k),Fraction(n,d)) for k,n,d in terms])
N={};J=[({}, {}) for h in range(45)];Ks={}
for i,j,w,nd,power,terms in rows['VGF']:
    if 508<=i<553 and 180<=j<508 and not w and nd==1 and not any(power):N[i-508,j-180]=coefficient(terms)
    if 598<=i<643 and len(w)==1 and 553<=w[0]<598 and nd==0:
        h=w[0]-553
        if j<180 and j%4==3 and power==[0,0,0,1]:J[h][0][i-598,j//4]=coefficient(terms)
        elif 508<=j<553 and not any(power):J[h][1][i-598,j-508]=coefficient(terms)
assert N and all(b>=12 for b,j in N)
if role=='primary':
    for i,j,w,nd,power,terms in rows['M0']:
        if 508<=i<553 and 598<=j<643 and len(w)==2 and all(553<=z<598 for z in w) and nd==0 and not any(power):
            r,a=i-508,j-598;h,k=[z-553 for z in w];v=coefficient(terms)
            assert h<k
            for ext,c,sign in [(h,k,-1),(k,h,1)]:
                M=Ks.setdefault((r,ext),{});M[c,a]=M.get((c,a),ZERO)+sign*v
else:
    for i,j,w,nd,power,terms in rows['VS']:
        if 553<=i<598 and 598<=j<643 and len(w)==2 and 553<=w[0]<598 and 1151<=w[1]<1196 and nd==0 and not any(power):
            r,h=w[1]-1151,w[0]-553;M=Ks.setdefault((r,h),{});M[i-553,j-598]=M.get((i-553,j-598),ZERO)+coefficient(terms)
Ks={key:{ij:v for ij,v in M.items() if v} for key,M in Ks.items()};Ks={key:M for key,M in Ks.items() if M}
assert all(r>=13 and h>=12 and all(c>=12 and a>=12 for c,a in M) for (r,h),M in Ks.items())
RR=list(map(dec,data['R']));RF=[{} for _ in range(45)]
for i,j,w,nd,power,terms in rows['M0']:
    if 180<=i<508 and 180<=j<508 and len(w)==1 and 553<=w[0]<598 and nd==0 and not any(power):RF[w[0]-553][i-180,j-180]=coefficient(terms)
assert RR==RF and all(M==scale(transpose(M),constant(-1)) for M in RR)
Om={(i,i):co('eta_H' if i<12 else 'xi') for i in range(45)}
def embed(M,B,ro,cc):
    for (i,j),v in B.items():M[ro+i,cc+j]=v
free=[]
for probe in range(2):
    P={(i,i):constant(1) for i in range(45) if (i<12)==(probe==0)}
    H={};embed(H,scale(P,constant(-2)),0,0);embed(H,multiply(Om,P),0,45);embed(H,scale(multiply(Om,P),constant(-1)),45,0);embed(H,scale(multiply(multiply(Om,Om),P),constant('1/2')),45,45)
    UB=scale(P,-2*I);UL=scale(multiply(Om,P),I)
    actualH={};actualUB={};actualUL={}
    for i,j,w,nd,power,terms in rows['HU'+str(probe)]:
        if w or nd or any(p for mu,p in enumerate(power) if mu!=3):continue
        a,b=field(i,3),field(j,3)
        if a is not None and b is not None:assert a<90 and b<90;actualH[a,b]=coefficient(terms)
    for i,j,w,nd,power,terms in rows['MU'+str(probe)]:
        if w or nd or any(p for mu,p in enumerate(power) if mu!=3):continue
        b=field(j,3)
        if b is None:continue
        assert 598<=i<643 and b<90
        (actualUB if b<45 else actualUL)[i-598,b if b<45 else b-45]=coefficient(terms)
    assert actualH==H and actualUB==UB and actualUL==UL
    free.append((H,UB,UL))
# Verify the other-ghost H zero complement before using it.
assert all(not J[h][1] and all(i<12 and j<12 for i,j in J[h][0]) for h in range(12))
names=['direct_1','direct_2','Hu_Mx'];families={name:{} for name in names};H,UB,UL=free[1]
if role=='primary':
    NR=[]
    for Ra in RR:
        rrows=defaultdict(list)
        for (b,i),v in multiply(N,Ra).items():rrows[b].append((i,v))
        NR.append(rrows)
else:
    nrows=defaultdict(list);rrows=[]
    for (b,j),v in N.items():nrows[b].append((j,v))
    for Ra in RR:
        rs=defaultdict(list)
        for (j,i),v in Ra.items():rs[j].append((i,v))
        rrows.append(rs)
previous=-1
for (r,h),K in sorted(Ks.items()):
    if r!=previous:
        if previous>=0:print('STAGE sourceD '+role+' source '+str(previous)+' seconds '+str(round(time.perf_counter()-tick,2)),flush=True)
        previous=r
    for k in range(12,45):
        if k==h:continue
        weights=color_weights(Om,J[k][0],J[k][1],K,UB,UL,H,45,'left' if role=='primary' else 'right')
        sign=1 if h<k else -1;gh=(min(h,k),max(h,k))
        for name,W in weights.items():
            vec={}
            if role=='primary':
                for (b,a),v in W.items():
                    for ix,c in NR[a].get(b,[]):vec[ix]=vec.get(ix,ZERO)+times(v,c)
            else:
                wn={}
                for (b,a),v in W.items():
                    for j,c in nrows.get(b,[]):wn[a,j]=wn.get((a,j),ZERO)+times(v,c)
                for (a,j),v in wn.items():
                    if v:
                        for ix,c in rrows[a].get(j,[]):vec[ix]=vec.get(ix,ZERO)+times(v,c)
            for ix,v in vec.items():
                if v:
                    key=(r,*gh,ix);families[name][key]=families[name].get(key,ZERO)+sign*v
families={name:{key:v for key,v in M.items() if v} for name,M in families.items()};total={}
for M in families.values():
    for key,v in M.items():total[key]=total.get(key,ZERO)+v
total={key:v for key,v in total.items() if v}
encode=lambda M:[[r,h,k,i,[[list(key),v.numerator,v.denominator] for key,v in c.terms]] for (r,h,k,i),c in sorted(M.items())]
kencode=[[r,h,c,a,[[list(key),v.numerator,v.denominator] for key,v in value.terms]] for (r,h),M in sorted(Ks.items()) for (c,a),value in sorted(M.items())]
results=[{'probe':0,'domain_positions':14612400,'total':[],'families':{name:[] for name in names},'nonzero_counts':{**{name:0 for name in names},'total':0},'zero_complement':14612400,'zero_method':'Complete refined support and K=P_BKP_B,N=P_BN,free probeH T4 identity.'},
         {'probe':1,'domain_positions':14612400,'total':encode(total),'families':{name:encode(M) for name,M in families.items()},'nonzero_counts':{**{name:len(M) for name,M in families.items()},'total':len(total)},'zero_complement':14612400-len(total),'zero_method':'Complete sparse contraction plus proved external H/source0..12 zero complement.'}]
out={'schema':'UFS4D_COMPLETE_SOURCE_CJ_F4_FAMILY','role':role,'source_kernel':kencode,'source_kernel_nonzeros':len(kencode),'source_kernel_pairs':len(Ks),'results':results,'guard_denials':denied,'quantum_target_or_selected_operand':False,'whole_C4_claim':False,'elapsed_after_imports':time.perf_counter()-tick}
blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/(role+'_source_d.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({key:v for key,v in out.items() if key not in ['results','source_kernel']},sort_keys=True)+' COUNTS '+json.dumps(results[1]['nonzero_counts'],sort_keys=True),flush=True);timer.cancel()
