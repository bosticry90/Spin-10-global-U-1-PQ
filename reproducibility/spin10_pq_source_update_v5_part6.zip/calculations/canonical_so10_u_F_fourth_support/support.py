from itertools import permutations
from collections import Counter,defaultdict
from operators import sector,pattern
EPS=1;UU=2;JJ=4;CC1=8;CC2=16;NN=32;XX=64;TARGET=127;ODD=29
FOLD={'B':['B','L'],'L':['B'],'s':['s'],'C':['a'],'a':['C']}
def label(name,pat,slot):return name+'|'+pat+('@'+str(slot) if slot else '')
def make_classes(tables,probe):
    groups={}
    selected=['VGF','VS','VX','HU'+str(probe),'M0','MU'+str(probe)]
    for name in selected:
        root=name.startswith('M');u=name.startswith('HU') or name.startswith('MU')
        for i,j,w,nd,power,terms in tables[name]:
            pat=pattern(w,nd);key=(name,pat)
            groups.setdefault(key,set()).add((sector(i),sector(j)))
    vertices={};roots={}
    for (name,pat),edges in sorted(groups.items()):
        isroot=name.startswith('M');hasu=name.startswith('HU') or name.startswith('MU')
        countC=pat.count('C');slots=[1,2] if countC==1 else [12] if countC==2 else [0]
        for slot in slots:
            mask=(EPS if isroot else 0)|(UU if hasu else 0)|(NN if 'n' in pat else 0)|(XX if 'x' in pat else 0)|(JJ if 'J' in pat else 0)|(CC1|CC2 if countC==2 else CC1 if slot==1 else CC2 if slot==2 else 0)
            folded=set(edges) if isroot else {(row,col) for a,col in edges for row in FOLD[a]}
            item={'name':name,'pattern':pat,'slot':slot,'mask':mask,'edges':[list(p) for p in sorted(folded)]}
            (roots if isroot else vertices)[label(name,pat,slot)]=item
    return vertices,roots
def closed_paths(word,root,vertices,roots):
    labels=list(word)+[root];ops=[vertices[k] for k in word]+[roots[root]];out=[]
    def walk(at,current,path,start):
        if at==5:
            if current==start:out.append(path)
            return
        for row,col in ops[at]['edges']:
            if row==current:walk(at+1,col,path+[col],start)
    for start in ['B','L','s','C','a']:walk(0,start,[start],start)
    return out
def enumerate_words(vertices,roots):
    words=[];pathless=0;allwords=0
    for root,r in roots.items():
        def grow(chosen,mask):
            nonlocal allwords,pathless
            if len(chosen)==4:
                if mask==TARGET:
                    allwords+=1;paths=closed_paths(chosen,root,vertices,roots)
                    if paths:words.append({'root':root,'word':chosen,'paths':paths})
                    else:pathless+=1
                return
            needed=(TARGET^mask).bit_count();left=4-len(chosen)
            if needed<left or needed>2*left:return
            for name,item in vertices.items():
                if not mask&item['mask']:grow(chosen+[name],mask|item['mask'])
        grow([],r['mask'])
    return {'words':words,'all_grade_words':allwords,'sector_zero_words':pathless,'supported_words':len(words),'closed_paths':sum(len(z['paths']) for z in words)}
def exterior_sign(masks):
    seq=[i for mask in masks for i in range(7) if mask&ODD&(1<<i)]
    return (-1)**sum(a>b for j,a in enumerate(seq) for b in seq[j+1:])
