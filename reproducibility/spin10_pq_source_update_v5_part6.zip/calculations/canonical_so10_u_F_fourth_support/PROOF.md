# Nonlinear C4 domain, complete zero sectors and source-CJ family

UFS1-4D. Fixed original unshifted SMA/CSW/EDS,A0,constant u,intrinsic1,
external jets0 only AFTER source/field differentiation,symbolic
g10/xi/eta_H,common hbar/(16pi^2),nonexceptional Euclidean LOCAL RELATIVE
formal positive-heat UV symbol. This is not a new physical prescription,
continuum product theorem or E5 promotion.

## Complete retained differential operator domain

The target has six positive grades(u,nu,JL,C1,C2,x). After UMH's complete
original-free-root cancellation, every remaining vertex/root has positive
grade. Four vertices plus one root therefore contain EXACTLY one
grade-two object; all others have grade one. With the source-u response
marked, the necessary caps are V0 grade1..2,H_u=u plus grade0..1,M0
grade1..2,M_u=u plus grade0..1. The action-derived tables retain all45
source/ghost labels,328 scalars,180 vector coordinates and all momentum
monomials before projection to a longitudinal frame.

Primary uses the actual GF Lambda/a Euler columns plus the graded
transpose completion, ordered left/right Hessians and right field
tangents. Replay reconstructs a GF density representative by

    GF = sum_(i in Lambda,a) phi_i E_i / (d_i+1),

where d_i counts remaining Lambda/a occurrences, including their jets.
Its75953 density terms reproduce ALL90 given Euler columns exactly.
The representative is not asserted byte-identical to the historical
raw density; homogeneous reconstruction can retain integration-by-parts
representatives. No arbitrary purely physical-field term is added:
the owning gauge-fixing action vanishes at Lambda=a=0. The relevant
complete retained Hessian agrees with the direct Euler-column route.
This is recovery of the existing GF operator, not adoption of a new action.

Replay then uses literal two-mode polarization; source derivatives use
minus-right Euler instead of the primary parity-weighted left Euler.
Sources are differentiated before restriction. The scalar current is
derived again from B_a x_i (R_a)[i,j] partial x_j rather than only
inserting the known current kernel. Exact full tables agree:

| Operator table | Nonzero indexed coefficients |
|---|---:|
| GF Hessian | 44208 |
| Source Hessian | 14044 |
| Scalar current Hessian | 100480 |
| Original field tangent | 37502 |
| H_u probe0 / probe1 | 300 / 9785 |
| M_u probe0 / probe1 | 60 / 1061 |
| Total | 207440 |

Keys include ordinary input/output field coordinates, external role/color
labels,nu degree and four-component momentum exponents. These are
algebraic positions,not independent physical tests. All implicit zeros
and all four Lorentz components are covered by exact table agreement.

The inherited unshifted potential/fermion support exclusions remain in
their qualified scopes: the physical nu*x scalar-potential Hessian is
disconnected from the required source/ghost cycle once both grades are
consumed; isolated fermion blocks cannot join it. Classical QG source2
has too many retained source/positive grades. These statements do NOT
remove quantum source2 contact Euler terms from a later conversion test.

## Grade and quantum-sector reductions

Complete mask enumeration gives432/672 grade-complete words for
probes0/1. B,L,s,C,a sector composition leaves60/122 words,105/197
closed paths. Generic noncommuting fixtures compare the full tagged
fourth power against every retained ordered trace,with literal exterior
order eps,u,JL,C1,C2,nu,x and odd eps,JL,C1,C2. Ghost exchange,including
the sign on two-ghost coefficients,passes; source/quartic omissions and
commuting-exterior controls are sensitive. Surviving words are candidate
support,not independent nonzero amplitudes.

Every nontrivial vector chain is longitudinally pinned by a vector-to-
scalar/ghost vertex or H_u,BB proportional to p_mu p_nu. Original M_C,BB
preserves Lorentz indices. A trace carrying JL cannot remain an isolated
transverse vector cycle. The all-component tables and inherited UMH
support therefore justify longitudinal evaluation without an unmeasured
Lorentz spectator factor. Independent selected checks use axis3,q+1
and axis2,q-1. This does not supply a new full continuum trace limit.

Refine the complete tables by H/broken quantum colors in B,L,C,a,
keeping scalar s unrestricted. The actual G preserves this color type.
Enumerate sourceH/broken and ghostHH,HB,BB classes separately so a ghost
slot cannot silently change type. A second implementation uses boolean
tagged matrix powers with NO coefficient cancellation. Both agree:

- No probe0 target path exists for ANY source or ghost class. Therefore
  the entire probe0 C4 tensor is zero.
- No eligible source-bearing operator contains source labels0..12.
  Those complete source rows are zero in either probe.
- GF_CC,M0_CC and M_u,C have no closed target path at four edges.
  Their action tensors are not deleted. This is a target-specific
  structural zero,earned from full internal/external support.

For example, the actual GF_CC Hessian has both quantum antighosts
broken. Its X block maps a_broken to C_broken,whereas the single-grade
JL vertex uses C_H or a_H at its ghost endpoint. The two broad candidate
words cannot close those colors. A selected external ghost zero alone
would not establish this exclusion.

Probe1,source broken still has16 HH,26 HB,54 BB supported words
(16,29,86 paths),57 distinct words in their union. HH has not been
declared zero merely because a selected HH coefficient vanished.

## Sensitive actual fourth-edge calculations

Seven fixed contexts,both probes,compare unrooted X^4 with rooted
powers and each ordered-word trace. Whole-family omissions are checked
both by removed-word sums and independently recomputed fourth powers.
Every word and per-context sensitive/insensitive control is preserved.

The new both-broken case r13,C13,C14,x137 has

 C4 = -i sqrt15 eta_H g10^5 xi/20
        +133 i sqrt15 g10^5 xi^2/500

in probe1. Its source-CJ contribution is -i sqrt15 eta_H g10^5 xi/20
and is NONZERO. The old C0,C12 scalar136 witness reproduces
3i sqrt15 eta_H g10^5 xi/80 but cannot test the source-CJ class.
Omission differences for H_u/M_u overlap other classes and must not
be added as if they were disjoint graph contributions.

Review also compares entire new selected V/M matrices with frozen
pure functions from the original general_v2 builder,under this NEW
execution record. Across original/replay source conventions,axes3/2,
opposite signs,old nonzero,new both-broken and inactive-source contexts,
49004 nonzero matrix coefficients and all zero complements agree.
No old driver or historical manifest was rerun/rebound. The all-label
coverage comes from the complete tables,not these selected calibrations.

## Complete nonlinear source-CJ family

Let D[r,a,h,k] be the original M0_CC field-tangent coefficient,extended
antisymmetrically in ghost labels. Although its direct M0_CC loop is
excluded above,its source descendant remains. For the source-C_h
placement,define

                K_(r,h)[c,a] = -D[r,a,h,c].

Independently,the GLOBAL source-Hessian entry H_(C_c,a_a) with canonical
external C_h JL_r equals K_(r,h). The minus from reordering C_h JL_r to
JL_r C_h and the G_(a,C) minus cancel. This gives the same6688 kernel
entries from field flow and source Hessian,including their zero support.

The even coefficient JL*C_h can replace the even Ja coefficient in
UTC's arbitrary-K T4 three-product identity. The parity-preserving
exterior-algebra embedding gives,for h<k,

 sourceCJ[r,h,k,i] = T4[K_(r,h),ghost k,i]
                        - T4[K_(r,k),ghost h,i].

The second minus is JL*C_k*C_h=-JL*C_h*C_k,not an assigned cancellation
sign. Full graded fourth powers with arbitrary noncommuting kernels
verify the embedding and sensitive wrong-antisymmetry,source-transpose,
commuting-odd and missing-placement controls.

The arbitrary-K T4 color formula is reused with its original matrix
ordering. N,J come from each route's complete GF tables; R matches
the full scalar field tangent; actual free H_u/M_u match the qualified
P_H/P_B formula. Primary forms N R_a first; replay contracts weights
into N first and uses a different color association. Primary recovers K
from D,while replay recovers it from the source density. Native access
to peer,selected coefficient and old quantum target is denied and tested.
Internal scalar-generator index a remains ALL45 directions.

K=P_B K P_B,N=P_B N and the free probe shape give a complete probe0
zero for each of the three products. Source0..12 and other-ghostH
zero complements are likewise checked before sparse extraction. Thus
the full45x990x328 family domain is computed without silently omitting
scalar directions or unmeasured small coefficients. Arrays agree exactly:

| Probe | Domain | Nonzero family sum | Zero complement |
|---|---:|---:|---:|
| 0 | 14612400 | 0 | 14612400 |
| 1 | 14612400 | 85112 | 14527288 |

Probe1's three overlapping rooted-product maps have82888,73264,73264
nonzero positions. Their sum and complete zero complement agree. Only
after native completion does review compare the family against all14
independently measured selected source-omission differences; all agree.
No full old quantum remainder has been opened in this increment.

## Remaining whole-system obligation

After the exact support exclusions,the unique grade-two object gives
an exact-once decomposition of probe1 C4 into six merged families:

 GF_nC + GF_nx + H_u,n + H_u,C + M_u,n + source-CJ.

The source-CJ family is complete here. The other five still require a
complete contracted tensor/identity. They must be kept together with
their correlated source and scalar structures; no current selected
cancellation proves the whole F identity. Since UFM established C5_F=0,
the remaining full F log5 cutoff is C4_F. A later full relative-conversion
comparison must retain the quantum contact Euler terms and use the
owning conversion PLUS cutoff convention.

Common continuum trace/product/contact limits,other finite bases,
measure/QAP,E5/A5 and physical viability remain open. b0,kappa,chi4,
IR freedoms stay distinct/unfixed. Shared action,charts,reference,ring,
curated inputs,helpers and AI authorship remain shared-error limits;
no external scientist,proof assistant or empirical validation is claimed.
