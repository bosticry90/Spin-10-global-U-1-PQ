"""All-label differential operator recovery in the frozen reference."""
from pathlib import Path
from collections import defaultdict,Counter
from functools import lru_cache
from fractions import Fraction
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'canonical_so10_u_T_cutoff_tensor'))
from actual import load,co,dec
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'canonical_so10_full_jet_source_master_bridge'))
import jets as JP
from jets import decode,dimension,parity,degree,Coeff,ZERO,I,constant
times=JP.times
NFIELD=643
def allowed(word,nd,low,high):
    if nd not in [0,1]:return None
    counts=Counter();ids=[]
    for i,js in word:
        if js:return None
        tag='x' if 180<=i<508 else 'C' if 553<=i<598 else 'J' if 1151<=i<1196 else None
        if tag is None:return None
        counts[tag]+=1;ids.append(i)
    if counts['x']>1 or counts['J']>1 or counts['C']>2:return None
    grade=nd+len(word)
    if not low<=grade<=high:return None
    return tuple(ids)
@lru_cache(None)
def fourier(ji,jj):
    v=constant(1)
    for mu in ji:v=times(v,-I)
    for mu in jj:v=times(v,I)
    return v,tuple((ji+jj).count(mu) for mu in range(4))
def put(T,key,v):
    if v:T[key]=T.get(key,ZERO)+v
def clean(T):return {k:v for k,v in T.items() if v}
def literal_sign(word,positions):
    labels=[]
    for at,(i,js) in enumerate(word):
        label=positions.get(at,i)
        labels.append((label,parity(i)))
    return (-1)**sum(a>b and pa and pb for j,(a,pa) in enumerate(labels) for b,pb in labels[j+1:])
def hessian(poly,role,low,high):
    out={}
    for word,value in poly.items():
        nd=degree(word,4)
        if nd not in [0,1]:continue
        for a,(i,ji) in enumerate(word):
            if i>=NFIELD:continue
            rest=word[:a]+word[a+1:]
            for at,(j,jj) in enumerate(rest):
                if j>=NFIELD:continue
                ext=allowed(rest[:at]+rest[at+1:],nd,low,high)
                if ext is None:continue
                b=at+int(at>=a)
                if role=='primary':sg=(-1)**(parity(i)*sum(parity(k) for k,js in word[:a])+parity(j)*sum(parity(k) for k,js in rest[at+1:]))
                else:
                    sg=literal_sign(word,{a:2000+i,b:4000+j})
                    sg*=(-1)**(parity(i)*(parity(i)+parity(j)))
                phase,power=fourier(ji,jj);put(out,(i,j,ext,nd,power),times(value,phase)*sg)
    return clean(out)
def gf_hessian(gradient,role):
    out={}
    for i,poly in gradient.items():
        for word,value in poly.items():
            nd=degree(word,4-dimension(i))
            for at,(j,jj) in enumerate(word):
                if j>=NFIELD:continue
                ext=allowed(word[:at]+word[at+1:],nd,1,2)
                if ext is None:continue
                sg=(-1)**(parity(j)*sum(parity(k) for k,js in word[at+1:])) if role=='primary' else literal_sign(word,{at:2000+j})
                phase,power=fourier((),jj);put(out,(i,j,ext,nd,power),times(value,phase)*sg)
    out=clean(out);complete=dict(out)
    for (i,j,ext,nd,power),v in out.items():
        trans=v*((-1)**(parity(i)+parity(j)+parity(i)*parity(j)+sum(power)))
        key=(j,i,ext,nd,power)
        if key in out:assert out[key]==trans,('GF_TRANSPOSE',i,j,ext,nd,power)
        else:complete[key]=trans
    return clean(complete)
def gf_primitive(gradient):
    out={}
    for i,poly in gradient.items():
        assert 508<=i<553 or 598<=i<643,i
        for word,value in poly.items():
            degree_aux=sum(508<=k<553 or 598<=k<643 for k,js in word)
            JP.put(out,((i,()),)+word,times(value,constant(Fraction(1,degree_aux+1))))
    out=JP.clean(out)
    rebuilt=JP.euler(out,set(gradient));assert rebuilt==gradient,'GF_HOMOTOPY_EULER_MISMATCH'
    return out
def right_sources(poly):
    partial={}
    for word,value in poly.items():
        for at,t in enumerate(word):
            if t[0]<NFIELD:continue
            rest=word[:at]+word[at+1:]
            sg=(-1)**(parity(t[0])*sum(parity(k) for k,js in word[at+1:]))
            part=partial.setdefault(t,{});part[rest]=part.get(rest,ZERO)+value*sg
    out={}
    for (i,js),p in partial.items():JP.add(out.setdefault(i,{}),JP.Ds(JP.clean(p),js),(-1)**len(js))
    return {i:JP.clean(z) for i,z in out.items() if JP.clean(z)}
def source_flows(Q,role):
    E=JP.euler(Q,set(range(NFIELD,2*NFIELD))) if role=='primary' else right_sources(Q)
    return {src-NFIELD:{w:v*((-1)**parity(src-NFIELD) if role=='primary' else -1) for w,v in poly.items()} for src,poly in E.items()}
def tangent(flows,role,low,high):
    out={}
    for i,poly in flows.items():
        for word,value in poly.items():
            nd=degree(word,dimension(i)+1)
            for at,(j,jj) in enumerate(word):
                if j>=NFIELD:continue
                ext=allowed(word[:at]+word[at+1:],nd,low,high)
                if ext is None:continue
                sg=(-1)**(parity(j)*sum(parity(k) for k,js in word[at+1:])) if role=='primary' else literal_sign(word,{at:2000+j})
                phase,power=fourier((),jj);put(out,(i,j,ext,nd,power),times(value,phase)*sg)
    return clean(out)
def source_density(data):
    def convert(i):return 1151+i if i<45 else 1241+i-45 if i<90 else 1196+i-90 if i<135 else 553+i-135 if i<180 else 598+i-180 if i<225 else 508+i-225
    out={}
    for word,value in data['source_action']:JP.put(out,tuple((convert(i),()) for i in word),co(value))
    return JP.clean(out)
def scalar_current(RR,role):
    if role=='primary':
        out={}
        for a,R in enumerate(RR):
            for (j,ix),v in R.items():
                for mu in range(4):
                    power=tuple(int(z==mu) for z in range(4));ext=(180+ix,)
                    put(out,(4*a+mu,180+j,ext,0,power),-times(I,v));put(out,(180+j,4*a+mu,ext,0,power),times(I,v))
        return clean(out)
    density={}
    for a,R in enumerate(RR):
        for (i,j),v in R.items():
            for mu in range(4):JP.put(density,((4*a+mu,()),(180+i,()),(180+j,(mu,))),v)
    return hessian(JP.clean(density),'replay',1,2)
def sector(i):return 'B' if i<180 else 's' if i<508 else 'L' if i<553 else 'C' if i<598 else 'a'
def pattern(ext,nd):return ('n' if nd else '')+''.join('x' if i<508 else 'C' if i<598 else 'J' for i in ext)
def summary(T):
    counts=Counter()
    for i,j,w,nd,p in T:counts[pattern(w,nd)+'|'+sector(i)+sector(j)+'|p'+str(sum(p))]+=1
    return dict(sorted(counts.items()))
def encode(T):return [[i,j,list(w),nd,list(p),[[list(k),v.numerator,v.denominator] for k,v in c.terms]] for (i,j,w,nd,p),c in sorted(T.items())]
