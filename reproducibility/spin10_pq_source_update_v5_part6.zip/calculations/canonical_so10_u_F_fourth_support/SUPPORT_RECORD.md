# UFS2 complete grade/sector inventory

UFS1 primary/replay full tables agree by inspection; formal review will
compare them and exact indices/zero complements. Replay GF primitive is
a representative with75953 density terms and exactly recovers every
given Euler column. It is not asserted byte-identical to the historical
raw density. Retained full Hessian agreement supplies the relevant check.

Build all actual operator classes by table name and external role pattern,
including momentum degree and every Lorentz component. Fold Hessian row
sectors through full free G support, retaining B,L separately. Enumerate
every ordered four-vertex word plus allowed root whose disjoint masks
cover(eps,u,JL,C1,C2,nu,x). Keep distinct ghost slot assignments; a CC
class already carries its canonical h<k coefficient, with no new factor2.
Then enumerate every closed quantum-sector path, preserving ordered
operator identities. This is complete candidate support, not proof of
independent/nonzero color coefficients for every word.

Verify all first/second-ghost classes derive from the actual full tables.
Record the exact external H/broken support of GF_CC and VS_CJ instead of
inferring it from the old C0,C12 witness. Classify all pathless candidates
as structural sector zeros only within this declared operator domain.
Primary/replay array agreement is mandatory before dependent reduction.
Review180s,8GiB/350MiB/32MiB; no quantum target or authority change.
