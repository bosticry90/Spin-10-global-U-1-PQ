from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
import json,gzip,time,threading,os
from support import *
from operators import sector,pattern
O=Path(__file__).resolve().parent;tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,h in json.loads((O/'refined_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==h,path
loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()))
data=loadz(O/'primary_operators.json.gz');old=loadz(O/'inventory_result.json.gz')
def fine(i):
    sec=sector(i)
    if sec=='s':return sec
    index=i//4 if sec=='B' else i-508 if sec=='L' else i-553 if sec=='C' else i-598
    return sec+('H' if index<12 else 'b')
def fg(sec):
    if sec=='s':return ['s']
    if sec[0]=='B':return [sec,'L'+sec[1]]
    if sec[0]=='L':return ['B'+sec[1]]
    if sec[0]=='C':return ['a'+sec[1]]
    return ['C'+sec[1]]
source_labels=set();refined_edges=defaultdict(set)
for name,rows in data['tables'].items():
    for i,j,w,nd,power,terms in rows:
        source=[z-1151 for z in w if 1151<=z<1196];ghosts=[z-553 for z in w if 553<=z<598]
        source_labels.update(source)
        key=(name,pattern(w,nd),'H' if source and source[0]<12 else 'b' if source else '',tuple('H' if h<12 else 'b' for h in ghosts))
        refined_edges[key].add((fine(i),fine(j)))
cases=[]
for broad in old['probes']:
    for source_type in ['H','b']:
        for types in [('H','H'),('H','b'),('b','b')]:
            V={};M={}
            for root,items in [(False,broad['vertices']),(True,broad['roots'])]:
                for name,item in items.items():
                    count=item['pattern'].count('C');desired=types if count==2 else (types[item['slot']-1],) if count==1 else ()
                    src=source_type if 'J' in item['pattern'] else ''
                    edges=refined_edges.get((item['name'],item['pattern'],src,desired),set())
                    if not edges:continue
                    folded=edges if root else {(g,col) for row,col in edges for g in fg(row)}
                    (M if root else V)[name]={**item,'edges':[list(p) for p in sorted(folded)]}
            def paths(word,root):
                ops=[V[k] for k in word]+[M[root]];out=[]
                def walk(at,current,path,start):
                    if at==5:
                        if current==start:out.append(path)
                        return
                    for row,col in ops[at]['edges']:
                        if row==current:walk(at+1,col,path+[col],start)
                for start in ['BH','Bb','LH','Lb','s','CH','Cb','aH','ab']:walk(0,start,[start],start)
                return out
            candidates=[];bymerged=Counter()
            for word in broad['words']:
                if word['root'] not in M or any(k not in V for k in word['word']):continue
                routes=paths(word['word'],word['root'])
                if not routes:continue
                candidates.append({'root':word['root'],'word':word['word'],'paths':routes})
                for name in word['word']+[word['root']]:
                    it=M.get(name,V.get(name));grade=it['mask'].bit_count()-int(name in M)
                    if grade==2:bymerged[name]+=1
            case={'probe':broad['probe'],'source_type':source_type,'ghost_types':list(types),'vertices':V,'roots':M,'words':candidates,'supported_words':len(candidates),'closed_paths':sum(len(z['paths']) for z in candidates),'words_by_merged_grade':dict(sorted(bymerged.items()))}
            cases.append(case);print('STAGE refined '+json.dumps({k:v for k,v in case.items() if k not in ['vertices','roots','words']},sort_keys=True),flush=True)
selected=loadz(O/'primary_selected.json.gz');reduction_checks=[]
for entry in selected['results']:
    broad=old['probes'][entry['probe']];ty=['H' if h<12 else 'b' for h in entry['ghosts']];src='H' if entry['source']<12 else 'b'
    case=next(z for z in cases if z['probe']==entry['probe'] and z['source_type']==src and z['ghost_types']==ty)
    keep={(z['root'],tuple(z['word'])) for z in case['words']};dropped=[]
    for word,v in zip(broad['words'],entry['ordered_word_values']):
        if (word['root'],tuple(word['word'])) not in keep:
            assert v=='0',(entry['source'],entry['ghosts'],entry['scalar'],entry['probe'],word,v)
            dropped.append(word)
    reduction_checks.append({'source':entry['source'],'ghosts':entry['ghosts'],'scalar':entry['scalar'],'probe':entry['probe'],'excluded_selected_word_values_checked_zero':len(dropped)})
GFCC=sum('VGF|CC@12' in z['word'] for case in cases for z in case['words']);MCC=sum(z['root']=='M0|CC@12' for case in cases for z in case['words'])
out={'schema':'UFS2B_ALL_COLOR_TYPE_SUPPORT','active_source_labels':sorted(source_labels),'inactive_source_labels':[r for r in range(45) if r not in source_labels],
     'cases':cases,'GF_CC_supported_words':GFCC,'M0_CC_supported_words':MCC,'selected_reduction_checks':reduction_checks,
     'full_C4_tensor_coefficient_claim':False,'quantum_target_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/'refined_result.json.gz').open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({k:v for k,v in out.items() if k not in ['cases','selected_reduction_checks']},sort_keys=True),flush=True);timer.cancel()
