# UFS3A noncommuting fourth-edge support fixtures

UFS2 complete candidate support has60/122 ordered terms (105/197 sector
paths) for probes0/1,from432/672 grade-complete words. Pathless words are
structural sector zeros; surviving words need not have independent or
nonzero physical coefficients. All full primary/replay operator tables
agree, including all4 Lorentz components and implicit zeros.

Test each probe with three deterministic noncommuting block fixtures,
quantum dimensions B2,L2,s3,C2,a2. Assign independent integer coefficient
matrices to each actual class/ghost-slot support, retaining the parity of
every source/ghost coefficient. Compare full fourth power of the tagged
matrix sum against every reduced ordered-word trace with literal exterior
signs and original supertrace. No cyclic rearrangement assumption.

Check ghost exchange,including a minus on each two-ghost coefficient;
require sensitive commuting-exterior,quartic-ghost omission and nonlinear-
source omission controls. Save whole per-word outputs and insensitive
cases. Fixtures are algebra diagnostics, not physical parameter points.
Same native300s/8GiB/350MiB/32MiB and authority limits. No quantum target.
