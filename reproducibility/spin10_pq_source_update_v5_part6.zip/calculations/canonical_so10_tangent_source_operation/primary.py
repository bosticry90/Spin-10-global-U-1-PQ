from data import *
t=begin('primary');names=sorted(TYPES);census={};rejected=Counter()
def recurse(start,remaining,word):
 yield word
 for i in range(start,len(names)):
  n=names[i]
  if TYPES[n][0]<=remaining:yield from recurse(i,remaining-TYPES[n][0],word+[n])
for hc,dim,gh,par,label in [(1,4,0,0,'parent_h1'),(2,4,0,0,'parent_h2'),(2,5,1,1,'image_h2')]:
 rows=[]
 for cd in range(dim+1):
  for w in recurse(0,max(0,2*dim-4*hc-2*cd),[]):
   if admissible(w,hc,cd,dim,gh,par):rows.append([signature(w),cd])
 census[label]=sorted(rows)
d=packed(CAL/'canonical_so10_cutoff_source_ward_operator/primary_inputs.json.gz');maps=d['field_maps'];anti_names=[f'bar{a}' if a<12 else f'ub{a}' for a in range(45)];ai={n:i for i,n in enumerate(anti_names)};g=s.Symbol('g10');N=defaultdict(lambda:s.S.Zero)
for r,name in enumerate(anti_names):
 for row in maps[name]:
  w=row['word']
  if len(w)!=2:continue
  ci=next(i for i,n in enumerate(w) if n.startswith('C'));a=ai[w[1-ci]];c=int(w[ci][1:]);N[r,a,c]+=co((-1 if ci else 1)*s.sympify(row['coefficient'])/g)
N=clean(N);p=read(PK/'frozen_a10_physical_reconciliation/full_primary.json');Q=dec(p['C3_plane_to_parent']);FM=dec(read(PK/'frozen_a10_e1_fermion/primary.json')['charts']['blocks']['heavy_dual']['field_embedding']);old=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/primary_tables.json.gz');CG=dec(old['raw_Gca']);U=dec(old['raw_aux_map']);HP=dec(packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz')['H_new']);PM=s.eye(45)-HP*HP.T
port=defaultdict(lambda:s.S.Zero)
for (a,d0,c),v in N.items():
 for b in range(33):
  if CG[c,12+b]:port[a,d0,b]+=v*CG[c,12+b]
port=clean(port);assert not port
O=s.SparseMatrix(45,328,{});DM=[s.SparseMatrix(45,328,{}) for c in range(45)];index={f'x_{sec}_{i}':k for k,(sec,i) in enumerate((sec,i) for sec,n in SECTORS for i in range(n))};lam={f'b{a}' if a<12 else f'L{a}':a for a in range(45)};gfcounts=Counter()
for row in d['GF']:
 w=row['word']
 if any('__' in n for n in w):continue
 if len(w)==2 and sum(n in lam for n in w)==1 and sum(n in index for n in w)==1:
  a=lam[next(n for n in w if n in lam)];j=index[next(n for n in w if n in index)];O[a,j]+=co(s.sympify(row['coefficient'])/(g*s.Symbol('xi')));gfcounts['LX']+=1
 if len(w)==3 and sum(n in ai for n in w)==1 and sum(n in index for n in w)==1 and sum(n.startswith('C') for n in w)==1:
  apos=next(i for i,n in enumerate(w) if n in ai);cpos=next(i for i,n in enumerate(w) if n.startswith('C'));a=ai[w[apos]];c=int(w[cpos][1:]);j=index[next(n for n in w if n in index)];DM[c][a,j]+=co((-1 if cpos<apos else 1)*s.sympify(row['coefficient'])/(g*g*s.Symbol('xi')));gfcounts['aCX']+=1
out=[];off=0;v=dec(p['vacuum']['VEV']);vf=packed(CAL/'canonical_so10_tangent_antighost_scalar_vertex/vacuum_primary_v3_tables.json.gz');bb=dec(vf['extra_bubble']);euler_count=0
for sec,n in SECTORS:
 R=list(map(dec,p['representation_matrices'][sec]));RR=[tidy(sum((Q[b,c]*R[b] for b in range(45) if Q[b,c]),ZERO(n))) for c in range(45)];TT=[ZERO(n) for _ in range(12)]+[tidy(sum((FM[b,a]*R[b] for b in range(45) if FM[b,a]),ZERO(n))) for a in range(33)];GT=[tidy(sum((CG[c,a]*TT[a] for a in range(12,45) if CG[c,a]),ZERO(n))) for c in range(45)]
 Kraw=tidy(-sum((RR[c]*GT[c] for c in range(45)),ZERO(n)));rawM=[tidy(TT[a].T*Kraw) for a in range(45)];M=[tidy(sum((U[a,e]*rawM[a] for a in range(45) if U[a,e]),ZERO(n))) for e in range(45)];Re=[tidy(sum((U[a,e]*TT[a] for a in range(45) if U[a,e]),ZERO(n))) for e in range(45)]
 expectedO=s.SparseMatrix.vstack(*[(ta*v[off:off+n,0]).T for ta in TT]);zero(O[:,off:off+n]-expectedO)
 for c in range(45):
  nc=s.SparseMatrix(45,45,{(a,r):z for (a,r,cc),z in N.items() if cc==c});zero(DM[c][:,off:off+n]-nc.T*expectedO+expectedO*RR[c])
 for e in range(45):zero(bb[e,off:off+n]-v[off:off+n,0].T*M[e]);zero(Re[e]-sum((PM[b,e]*R[b] for b in range(45) if PM[b,e]),ZERO(n)))
 euler_count+=sum(len(m.todok()) for m in Re)
 out.append({'sector':sec,'source_generator':list(map(enc,Re)),'bubble_matrix':list(map(enc,M)),'K_from_raw':enc(Kraw),'bubble_hh':[[e,*ij,str(-z)] for e,m in enumerate(M) for ij,z in sorted(anti_sparse(m).items())]});off+=n;print('STAGE GENERIC_RAW_GF',sec,flush=True)
# Direct left exterior derivatives of a canonical monomial; even x positions
# do not contribute an odd crossing. h=0,a=1,J=2 are distinct odd labels.
def left(word,label):
 pos=word.index(label);odd_before=sum(z in ['h','a','J'] for z in word[:pos]);return (-1)**odd_before,word[:pos]+word[pos+1:]
fixtures={'E_x':left(['h','a','x'],'x'),'E_a':left(['h','a','x'],'a'),'J_derivative':left(['J','h'],'J')}
assert fixtures['E_x'][0]==1 and fixtures['E_a'][0]==-1 and fixtures['J_derivative'][0]==1
finish('primary',{'method':'recursive_types_literal_odd_Euler_and_generic_raw_GF_contraction','census':census,'color':out,'raw_anti_rows':len(N),'raw_anti_heavy_port_positions':45*45*33,'raw_anti_heavy_port_nonzero':len(port),'actual_GF_rows':dict(gfcounts),'actual_GF_reconstruction_positions':45*45*328,'new_source_Euler_generators_nonzero_each':euler_count,'Euler_sign_fixtures':fixtures,'other_bosonic_source_columns_zero':270,'new_matter_source_columns_zero_by_types':True,'h_JL_w_structural_zero_inherited':True},t)
