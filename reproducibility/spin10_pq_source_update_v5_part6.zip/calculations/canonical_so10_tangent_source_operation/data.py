from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from functools import lru_cache
import gzip,json,os,sys,time,threading,itertools
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
SECTORS=[('Phi',54),('Sigma',252),('phi',20),('S',2)];ZERO=lambda n:s.SparseMatrix(n,n,{})
@lru_cache(maxsize=131072)
def co(z):return s.simplify(s.sympify(z))
def tidy(m):return s.SparseMatrix(m).applyfunc(co)
def dec(m):return s.SparseMatrix(*m['shape'],{(i,j):co(z) for i,j,z in m['entries']})
def enc(m):return {'shape':list(m.shape),'entries':[[int(i),int(j),str(v)] for (i,j),v in sorted(tidy(m).todok().items())]}
def zero(m):assert not tidy(m).todok()
def clean(d):return {k:co(v) for k,v in d.items() if co(v)}
def begin(role):
 t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def guard(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and p.name.startswith(peer):raise PermissionError('TSO1_PEER_DENIED')
 sys.addaudithook(guard);return t
def finish(role,d,t):
 d.update({'elapsed_after_imports':time.perf_counter()-t,'full_quantum_h_family_qualified':False,'authority':'34/39','scientific_acceptance':'NOT_PERFORMED'})
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'elapsed_after_imports':d['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True)
# Doubled engineering dimension, ghost number, parity, vector and spinor rank.
TYPES={'B':(2,0,0,1,0),'X':(2,0,0,0,0),'C':(2,1,1,0,0),'a':(2,-1,1,0,0),'L':(4,0,0,0,0),'JB':(4,-1,1,1,0),'Jx':(4,-1,1,0,0),'JC':(4,-2,0,0,0),'Ja':(4,0,0,0,0),'JL':(2,-1,1,0,0),'F':(3,0,1,0,1),'KF':(3,-1,0,0,1),'A':(2,0,0,1,0),'z':(2,0,0,0,0),'d':(2,0,0,1,0)}
def admissible(word,hcount,coefficient_dimension,target_dimension,ghost,parity):
 vals=[TYPES[n] for n in word]
 return 4*hcount+sum(v[0] for v in vals)+2*coefficient_dimension==2*target_dimension and hcount+sum(v[1] for v in vals)==ghost and (hcount+sum(v[2] for v in vals))%2==parity and sum(v[3] for v in vals)%2==0 and sum(v[4] for v in vals)%2==0
def signature(word):return '*'.join(sorted(word))
def anti(m):return {(i,j):co(m[j,i]-m[i,j]) for i in range(m.rows) for j in range(i+1,m.cols) if co(m[j,i]-m[i,j])}
def anti_sparse(m):
 out=defaultdict(lambda:s.S.Zero)
 for (k,a),v in m.todok().items():
  if k!=a:out[min(k,a),max(k,a)]+=v*(1 if a<k else -1)
 return clean(out)
def rowencode(d):return [[*k,str(v)] for k,v in sorted(clean(d).items())]
def anticount(m):return len(anti_sparse(m))
