# TSO1 V2: assemble the h-local comparison and match the single-variation domain

V1 primary/replay/gate completed with 24,761 individually nonzero hh*a
coefficients canceling, 42,426 generic affine bubble entries, 13,538 entries
in each new source Euler family. V1 does not itself establish a quantum
trace domain. Authenticate its actual receipt before this continuation.

The next smallest question is whether all seven admitted h-parent carriers
are accounted for by the existing measured proper one-loop inputs, and
whether adding these declared spurions violates the OLD bosonic common
interaction/first-variation trace hypotheses. Do not repeat qualified loops.
Construct the full zero-matter local relative h cochain by two assemblies,
and match the extra vertices/substitutions against the actual support proof.
This is not a full chiral, multiple-insertion or physical-scheme theorem.

In units 1/(16pi2), with w=v0+z and unshifted x, the proposed measured member
is

 C_h = g2*xi*chi4*Jx.T*K*h
     +chi6*h_A*a_e*x_k*(-g3*xi*etaH*OH-g3*xi2*OM+g2*xi2*X)[e,k,A]
     +g3*xi2*chi4*h_A*a_e*w_k*MB[e,k,A],
 chi6=chi4+log(3/2).

The additional GF mixed triangle is retained before using its full operator
zero OM. JL*h*x is zero by the generic ghost port; JL*h*w also has zero
extra proper words because LL=0. Coefficientdimension1 is exhausted in the
ACTUAL proper local one-loop input by GF's linear w insertions: a one-loop
proper graph is a cycle, every vertex has two quantum ports. A source
cubic or an h vertex with one quantum port cannot create another proper
cycle by attaching a tadpole/one-point branch. A new physical/reference
mass insertion costs dimension2 and cannot occur at coefficientdimension1
without inverse parameters. This does not set homogeneous invariant mass/
JL counterterm freedoms to zero; it constructs one measured representative.

At this local dimension no derivative/vector carrier or h-containing matter
parent exists; h2 has no parent either. This carrier completeness follows
from V1's full type census, not from a finite walk cutoff. Actual h vertices
and their GF-w companions are exactly the previously qualified TAV/VTS/ATS
families. Retain x=v evaluation as an evaluation, not an additional parent.

V2 tests background covariance of the new primitive directly using actual
anti field rules and rhoH, verifies both source Euler signs remain in the
full operation, compares each assembly including zero complements, and
checks the complete extra triangle operator against OM before using zero.
Duplicate JxKh, omit bubble, wrong heat length and reversed source sign
are sensitive controls. No target coefficient is chosen from a Ward image.

## One-variation analytic applicability, with inherited premises explicit

Bind canonical_so10_joint_born_ir_trace_domain DERIVATION_V2/receipt, CSW
DERIVATION and the old metric Stokes proof. Hold the actual free reference,
heat generator, projectors, scalar positive reference masses, Wick branch,
common n_log, inverse/source defects, Gamma_ref[A] and UVFP-before-IR order.
At fixed external order z,h are independent Schwartz labels (odd h means
coefficientwise Grassmann tests). z=h0 reproduces the old interaction.

The ONLY additions are labeled h:(a,X), labeled z:(L,X), labeled z:(a,C,X),
and the cotangent substitutions E_h,x~h*a, E_h,a~h*x, Dz=z->h. None removes
a test label to a numeric constant. The new h source Hessian entry has no
derivatives or propagator; it adds a vertex, not a new free Green edge.
The new z interactions are the same constant w vertices with an extra label.
All field R_i and the integrated tangent M=dR are unchanged; consequently
the only field-independent tangent is still B<-partial C and a<-L. New
source products are combined using the FULL source-Hessian congruence,
not treated as separately trace-class inverse insertions.

Thus the constant-chain graph is unchanged: only L-X mass bridge plus
massive X selfcycles, with G_LL=0. Its ordinary dressed soft degrees remain
BB2,BL/LB1,BX/XB1,XX0,Ca/aC2. One constant tangent merges at degree3;
all labeled vertices split into independent node momenta as in the bound
joint-variable submersion proof. The new field/source substitutions are
linear sums of external momenta and preserve that submersion. No plane-wave,
constant-z or constant-h diagonal limit is taken. The h2 LOCAL cochain
test does not create an independent second tangent/domain theorem.

The old smooth-free-edge trace approximants and bounded rooted covariant
IR-profile differences apply with these extra polynomial vertices: no new
soft denominator, differentiated cutoff or free-edge symbol is introduced.
At fixed external order the same joint L1 majorants and hard-shell r^-5
remainder give the same unique limit and UVFP-before-IR order. Retain all
finite-epsilon G_epsilon H defects and distributional IR delta terms before
combining the full varied identity. Positive heat/Duhamel orders are unchanged.

For UV locality the same nonnegative dimension bounds give a finite Born
sum at each coefficient; the new h vertex has dimension2 coefficient and
z vertices dimension1, so cannot create an unbounded dimension-zero constant
cycle. The full source-Hessian congruence now includes D_h H and E_h R''.
The source/jet operation commutes with the local metric first dimension jet
by V1's rank/metric argument. h,z transform in the physical scalar carrier;
the actual primitive's H covariance is tested. With the inherited real
structure this is the same formal metric-natural bosonic local comparison
constructor, now on the explicitly stated spurion family.

These are matched hypotheses and an analytic extension argument, supported
by two finite automaton controls. The controls do not prove infinite-order
analytic estimates by enumeration. A second independent tangent DOES give
critical degree4 and must be detected as outside scope. A fictitious LL
Green creates a positive-pole constant cycle and must also be detected.

## Integration ceiling and next question

The constructed member supplies the h-dependent part of the bosonic local
heat/dimensional comparison on this ONE-variation domain. It replaces the
new JxKh owner in VHR V5: do not add it twice. VHR's mass addition and proper
JxCv owner remain separate; its six physical fermion projections are reused,
not re-proved by this purely metric argument. No general chiral extension
or complete h-dependent matter breaking is inferred. Parent h-sector has
no closed proper one-loop fermion cycle by type/one-loop-cycle support;
its matter descendants still require the inherited chiral insertion checks.

The construction does not prove the old master premise anew, close HB1/C5,
normalize every allowed homogeneous direction or nonlinear insertion,
identify b0/kappa/chi4, adopt a scheme, or qualify full QAP/measure/global
phase/Lorentzian/physical-vacuum/C1/E5A5/GUT. Next address the explicitly
unconstructed nonlinear/multiple-source product domain, or another
indispensable dependency, rather than label this one-loop result complete.

New sequential primary/replay/gate only, 600s each afterimports/8GiB sampled/
350MiB floor/16MiB total packet; freeze copies and all new input bytes first.
Do not rerun or modify V1. Original base33893 blobs preserved; same authority.
