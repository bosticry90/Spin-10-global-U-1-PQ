# A common local h-dependent comparison is constructed in the declared bosonic domain

The two bounded increments completed, with two distinct calculation routes
and a separate gate for each. The first derives the actual new source
operation and passes a nontrivial local compatibility test. The second
assembles the measured h-dependent local comparison and matches its extra
vertices to the inherited single-variation trace-domain proof.

This strengthens the formal Euclidean bosonic construction. It does not
establish a complete nonlinear quantum prescription, full chiral restoration,
QAP, measure, global phase, E5/A5 or physical viability. Scientific authority
remains state113/34of39; no scientific/director acceptance was performed.

## Actual source operation and an independently tested cancellation

With unshifted x, w=v0+z and the explicitly provisional local Schwartz
spurions qz=h,qh=0, the Euclidean tangent density is

    S_h=g*xi*h_A*a_e*R_e[j,A]*x_j,  R_e=(PM rho)_e.

Its actual left Euler columns are

    E_h,x_j=+g*xi*h_A*a_e*R_e[j,A],
    E_h,a_e=-g*xi*h_A*R_e[j,A]*x_j.

The second sign is required by the left odd derivative through h. The
inherited cotangent bracket gives bJ_i=leftEuler_i for either field parity;
there is no additional odd-field sign and no change to the elementary
external-source convention qJ=0. The full local operation is

    b_ext=b0+integral h_A*delta_zA+E_h,x*left_delta_Jx+E_h,a*left_delta_Ja.

Each Euler tensor has 13,538 nonzero entries in its 4,841,280 potential
scalar/antighost/tangent positions. The other 270 bosonic source columns
have no new h contribution; the new matter-source Euler contribution is
zero by the actual primitive's field content. These statements do not
discard old physical/source Euler terms.

The direct raw-field contraction, including the actual nonlinear antighost
rule, gives a generic-w ordinary bubble matrix MB_e. A separate normalized
plane calculation uses the already independently measured source kernel K.
They agree as full matrices:

    MB_e=R_e.T*K,  C_J=g^2*xi*chi4*Jx.T*K*h/(16pi^2).

The raw antighost heavy-ghost port vanishes before scalar contractions,
across 66,825 slots; it was retained before applying that zero. The declared
generic-w gauge-fixing extension reproduces all 664,200 actual frozen
scalar-GF positions, including the 6,688 aCX and 432 auxiliary-X rows.
The generic bubble has 42,426 nonzero coefficients; its frozen-v evaluation
has the previously measured 448. It was not defined from that evaluation.

In canonical h_A*h_B*a_e order, A<B, define
Anti(M)[A,B]=M[A,B]-M[B,A]. The parameter variation of the bubble contributes
Anti(MB); the new source-Euler variation of C_J contributes
-Anti(R_e.T*K). Both tensors have 24,761 nonzero positions; their sum is
zero. The full 2,413,260-position hh*a domain is covered: 1,496,160
within-sector positions and 917,100 cross-sector zeros fixed by the actual
sector-preserving maps. No coefficient was fitted to make this sum vanish.

The allowed hh*JL breaking pattern is also retained. Its actual coefficient
is zero by the generic heavy-ghost-port and LL-zero proper-support argument.
This does not eliminate admissible homogeneous JL*h*w finite freedoms.
Nor does this LOCAL hh test define two-insertion quantum products.

## Complete parent patterns and measured representative

Independent recursive and multiset enumerations give seven local h-parent
patterns of dimension4, ghost0 and even parity:

    coefficientdimension0: h*a*x, h*a*z, h*JL*x, h*JL*z, h*Jx;
    coefficientdimension1: h*a, h*JL.

All fields/sources, derivative slots, background-vector slots and matter
types were included in the census. A lone Lorentz index or spinor, incorrect
ghost number/parity or excessive dimension excludes the other patterns.
There is no h2 parent at dimension4; its dimension5 ghost-one images hh*a
and hh*JL remain possible and were not dropped. Seven patterns do not mean
seven independent invariant counterterms: representation multiplicities,
ranks and homogeneous finite freedoms are not fixed by this census.

Using the measured TAV/VTS/VTF tensors, in 1/(16pi^2) units the member is

    C_h = g^2*xi*chi4*Jx.T*K*h
        + chi6*h_A*a_e*x_k*
            [-g^3*xi*eta_H*OH-g^3*xi^2*OM+g^2*xi^2*X][e,k,A]
        + g^3*xi^2*chi4*h_A*a_e*w_k*MB[e,k,A],
    chi6=chi4+log(3/2).

The direct additional GF mixed-triangle operator is independently computed
in raw and plane coordinates before comparison with OM. Its complete
operator, not just its v evaluation, is zero. The nonzero blocks are:

| Block | Nonzero coefficients |
| --- | ---: |
| OH | 36,320 |
| OM | 0 |
| X | 17,658 |
| Generic affine MB | 42,426 |
| Source K | 1,342 |
| Affine frozen-v evaluation | 448 |

The frozen-v evaluation is not an additional parent. The actual proper
one-loop support and coefficient dimension exhaust the measured mass/v
member, as explained in CONTINUATION_V2. A proper one-loop graph is a cycle;
one-port branches cannot supply another proper primitive. An extra mass
insertion of dimension2 cannot enter a dimension1 coefficient without a
forbidden inverse parameter. This establishes the measured representative,
not the absence of other invariant finite normalization directions.

The h-containing parents have no external derivative/vector slot. Their
critical scalar/longitudinal contractions have no numeric Lorentz trace
or residual first angular dimension jet. The common measure contribution
is already included in chi4/chi6 by the authenticated loop calculations.
An external heat-momentum jet would carry a forbidden derivative in this
local parent module; it is not silently discarded from a larger amplitude.

## The single-variation domain and its limit

CONTINUATION_V2 supplies the applicability argument, using the actual
joint-domain DERIVATION_V2 and the metric Stokes constructor as inherited
premises. z,h add labeled h:(a,X), z:(auxiliary,X), z:(a,C,X) vertices and
source substitutions Jx->h*a, Ja->h*x, z->h. They add no free Green entry
and never replace a test label by a numerical constant. All field rules
and their integrated field tangent remain unchanged.

Two methods independently reconstruct the 225 field-independent tangent
entries, including 180 gauge/derivative-ghost entries. Max-plus closure and
an independent simple-path/simple-cycle calculation recover the same
constant-chain bounds. Ordinary dressed soft poles are at most2; a single
tangent reaches3 and remains locally L1 in four joint momentum dimensions.
A second independent tangent reaches the critical degree4. A fictitious
LL Green creates a positive-pole cycle and is detected as an invalid control.

The old free-edge smoothing proof, labeled joint-momentum submersion,
rooted covariant-profile bounds and UVFP-before-IR order therefore apply
to these polynomial insertions in the specified one-variation test-field
domain. This is an analytic extension argument under those premises; the
finite graph controls are not a replacement for the all-order support and
dominated-convergence argument. Inverse/source defects, ordered heat factors,
the reference determinant and the distributional IR delta are retained.
No constant-z/h, plane-wave or physical-vacuum diagonal is taken.

The primitive's H-covariance and K commutators are checked using actual
raw source rules versus transported plane rules, over 36,886,848 positions,
with zero residual. The new source-Euler and parameter operations contain
no closed numeric metric trace. V1's rank argument supplies commutation
with the first metric dimension jet. Twice polarizing the extended master
family retains both D_h H and E_h*R'' in the source-Hessian congruence.
The classical master statement is authenticated reuse, not a new HB1/C5
qualification.

These results construct the h part of the formal bosonic local heat/
dimensional comparison in this domain. The zero-matter projection remains
stable under the new substitutions; the matter-dependent Euler descendants
are not proved by extending a purely metric argument to chiral fermions.
The separately qualified six physical fermion projections retain their
existing chiral/insertion checks. No general chiral theorem is asserted.

## Ownership, controls and scientific interpretation

The source JxKh block REPLACES the new source owner in VHR V5. It is not
added to it a second time. The proper JxCv block already in C_bStokes and
VHR's separate physical mass addition remain their existing owners. This
is exact-once assembly of a formal comparison, not adoption of a physical
counterterm scheme. chi4, b0, kappa and homogeneous invariant freedoms stay
symbolic and distinct.

V1 controls omitting either side, reversing the source sign or using heat6
for the bubble change 24,761 image positions. V2's omitted affine bubble
and wrong affine heat length change 42,426 parent positions; a duplicated
or sign-reversed source kernel changes1,342. Omitting the shifted rule
qeta=qx-h leaves6,784 OH and8,829 X image positions. OM is zero and that
particular control is explicitly insensitive. These controls do not test
unrelated physical assumptions or guarantee every possible implementation
error is detected.

This is internal mathematical/computational corroboration using raw action
data, an independently measured source kernel, distinct type/Grassmann/
coordinate/graph calculations and explicit negative controls. Both methods
share action and reference premises, maps, SymPy/Python and AI authorship.
No outside scientist, proof assistant or experiment validated the physics.

## Receipts, execution and preservation

V1 receipt SHA256:
1d845840ed222701a765d03af4ed71a0815587208862733e16e22d75e3e3b80e.
Artifact packed/raw:
2fd76fa3606ae895fdf7a2c312764b2377377947c71cf0e0c32d9a0beddc5315 /
ec09f2851f606ac3c3d4db282b6595ebbf94746b3686b781c7e7d83f41c33a16.

V2 receipt SHA256:
63dc86af3f5b62ad1a5b05f8d26b4cf181170f99384df68dcc5a13d39e225a18.
Artifact packed/raw:
6a8bf8d83493f3cc91a3fd0235ec291e2b582791413d5f54392ce7c2dc38ed03 /
d8f8252d4bddb23d6910f3854611ba0232582814ce76507fecb3978e5da0f60f.

All six scientific workers/gates completed native0. V1 after-import times
18.7363875/11.5863734/5.7762623s; memory samples11/7/4, sampled maxima
140705792/96747520/92696576B. V2 times12.1418978/31.6422780/4.0659631s;
samples7/17/3, sampled maxima100208640/167403520/90587136B. These are
sampled observations, not continuous peaks. The frozen600s/8GiBsampled/
350MiBfloor/16MiB limits were unexhausted. Preparations/validation bind
63/71 and95/103 inputs;15 exact source copies and complete captures remain.
The packet before this report was2,303,157B. No frozen scientific worker,
verifier or controller failed. Prelaunch read-only path/schema lookups did
fail; the paths were inspected and corrected before freezing. The prospective
Anti definition and odd ordering were made explicit before computation.

The director's supplied assessment was reviewed and bound as original
attachment bytes. Its emphasis on actual action input, complete source
operation, independent quantum coefficients, different heat lengths and
exact-once ownership is incorporated. Its secondhand reports are not an
authority source; actual committed receipts were used. No external empirical
or foundational claim was adopted from it.

Current delegated E4 finished expected exits0/0/0/0/0/2. Custody remains
exit2/seven NOTPASS, not an overall scientific PASS. External before/index/
after seals preserve all33,893 old Git blobs, the state hash and every old
failed run. Check the postcommit seal for final HEAD and clean status.

The full objective remains active and incomplete. The next useful bounded
step is the ACTUAL ordered two-source/tangent product domain: determine
which critical degree4 terms survive the graded action-derived sum, whether
the prescribed IR finite part defines them, and which contact conditions
remain unspecified. Do not infer this from q^2=0, erase an IR delta, fit a
contact constant or claim that the local hh cancellation constructs the
products. Full QAP/measure/phase, causal/Lorentzian/physical-vacuum limits,
massive fermionic C1 and physical viability remain separate obligations.
Historical failed benchmark/large scalar correction, blocked flavor/HB1/C5,
quartet failure and all prior negative routes remain in their proper scopes.
