from pathlib import Path
from hashlib import sha256
import json,ast
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';digest=lambda p:sha256(p.read_bytes()).hexdigest();b=dict(json.loads((HERE/'preparation.json').read_bytes())['input_sha256'])
for p,h in b.items():assert digest(Path(p))==h,p
assert json.loads((HERE/'validation_receipt.json').read_bytes())['status']=='QUALIFIED_SELECTED_LOCAL_TANGENT_SOURCE_OPERATION_AND_HH_COMPATIBILITY'
for p in HERE.iterdir():
 if p.is_file():b[str(p)]=digest(p)
for folder,names in {'canonical_so10_joint_born_ir_trace_domain':['DERIVATION_V2.md','validation_receipt.json'],'canonical_so10_dimensional_stokes_primitive':['validation_receipt.json'],'canonical_so10_vacuum_heat_root_completion':['color_primary_v3_tables.json.gz','color_replay_v4_tables.json.gz','DOMAIN_REVIEW_V3.md','joint_receipt_v5.json']}.items():
 for n in names:p=CAL/folder/n;b[str(p)]=digest(p)
for n in ['CONTINUATION_V2.md','data_v2.py','primary_v2.py','replay_v2.py','verify_v2.py','prepare_v2.py','run_v2.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw)
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 b[str(HERE/(n+'.source.txt'))]=digest(HERE/(n+'.source.txt'))
with (HERE/'preparation_v2.json').open('xb') as f:f.write((json.dumps({'schema':'TSO1_V2_PREPARATION','input_sha256':dict(sorted(b.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('TSO1_V2_FROZEN',len(b),'bindings',flush=True)
