from data import *
G={('B','B'):2,('B','L'):1,('L','B'):1,('X','X'):0,('C','a'):2,('a','C'):2};V={('X','X'):0,('X','L'):0,('L','X'):0};T={('B','C'):-1,('C','B'):-1,('a','L'):0,('L','a'):0};NODES=['B','L','X','C','a']
def plus(*ds):
 out={}
 for d in ds:
  for k,v in d.items():out[k]=max(v,out.get(k,-1000))
 return out
def times(a,b):
 out={}
 for (i,k),v in a.items():
  for (kk,j),w in b.items():
   if k==kk:out[i,j]=max(v+w,out.get((i,j),-1000))
 return out
def begin2(role):
 t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def guard(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and p.name.startswith(peer):raise PermissionError('TSO1_V2_PEER_DENIED')
 sys.addaudithook(guard);return t
def finish2(role,d,t):
 d.update({'elapsed_after_imports':time.perf_counter()-t,'full_QAP_E5A5_qualified':False,'authority':'34/39','scientific_acceptance':'NOT_PERFORMED'})
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_v2_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'elapsed_after_imports':d['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True)
def linear_tangent(maps):
 rows=[]
 for out,rs in maps.items():
  for r in rs:
   if len(r['word'])!=1:continue
   n=r['word'][0];z=co(r['coefficient']);assert not z.free_symbols
   if out.startswith('B'):assert n.startswith('C') and '__' in n
   else:assert out.startswith(('bar','ub')) and n.startswith(('b','L')) and '__' not in n
   rows.append([out,n,str(z)])
 return sorted(rows)
def encgraph(g):return [[i,j,w] for (i,j),w in sorted(g.items())]
def maprows(mats):return list(map(enc,mats))
