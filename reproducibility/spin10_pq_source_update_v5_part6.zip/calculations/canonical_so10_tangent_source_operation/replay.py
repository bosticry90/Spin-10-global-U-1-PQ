from data import *
t=begin('replay');names=list(TYPES);census={}
for hc,dim,gh,par,label in [(1,4,0,0,'parent_h1'),(2,4,0,0,'parent_h2'),(2,5,1,1,'image_h2')]:
 rows=[]
 for size in range(2*dim//min(v[0] for v in TYPES.values())+1):
  for w in itertools.combinations_with_replacement(names,size):
   weight=4*hc+sum(TYPES[k][0] for k in w);cd2=2*dim-weight
   if cd2>=0 and cd2%2==0 and admissible(w,hc,cd2//2,dim,gh,par):rows.append([signature(w),cd2//2])
 census[label]=sorted(rows)
p=read(PK/'frozen_a10_physical_reconciliation/full_replay.json');H=dec(packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz')['H_new']);PM=s.eye(45)-H*H.T;zero(PM*PM-PM);Kfull=dec(packed(CAL/'canonical_so10_vacuum_tangent_source_kernel/replay_tables.json.gz')['kernel_unit']);tav=packed(CAL/'canonical_so10_tangent_antighost_scalar_vertex/replay_v2_tables.json.gz');out=[];off=0;shift={};control=0
# Exterior multiplication by insertion into ordered odd labels. Labels are
# h_A=(0,A), a_e=(1,e), J_j=(2,j); repeated odd labels vanish.
def wedge(word):
 if len(set(word))!=len(word):return None,0
 inv=sum(word[i]>word[j] for i in range(len(word)) for j in range(i+1,len(word)));return tuple(sorted(word)),(-1)**inv
for sec,n in SECTORS:
 R=list(map(dec,p['representation_matrices'][sec]));Re=[tidy(sum((PM[b,e]*R[b] for b in range(45) if PM[b,e]),ZERO(n))) for e in range(45)];K=Kfull[off:off+n,off:off+n];Kcalc=tidy(-sum((R[c]*Re[c] for c in range(45)),ZERO(n)));zero(K-Kcalc);zero(K-K.T)
 M=[tidy(r.T*K) for r in Re];source=defaultdict(lambda:s.S.Zero)
 krow=defaultdict(list)
 for (j,b),z in K.todok().items():krow[j].append((b,z))
 for e,r in enumerate(Re):
  for (j,a),z in r.todok().items():
   for b,y in krow[j]:
    w,phase=wedge([(0,a),(1,e),(0,b)])
    if phase:source[e,w[0][1],w[1][1]]+=phase*z*y
 source=clean(source);shiftsec={}
 for key in ['ordinary_H','ordinary_M','auxiliary']:
  images={};images_eta={}
  for e,entry in enumerate(tav['color'][len(out)][key]):
   mat=dec(entry)
   for (k,a),z in mat.todok().items():
    # D_h acting on h_A*a_e*w_k, and qeta=-h_k, respectively.
    w,phase=wedge([(0,a),(1,e),(0,k)])
    if phase:images[e,w[0][1],w[1][1]]=images.get((e,w[0][1],w[1][1]),0)+phase*z;images_eta[e,w[0][1],w[1][1]]=images_eta.get((e,w[0][1],w[1][1]),0)-phase*z
  images=clean(images);images_eta=clean(images_eta);assert not clean({k:images.get(k,0)+images_eta.get(k,0) for k in set(images)|set(images_eta)});shiftsec[key]=len(images)
 out.append({'sector':sec,'source_generator':list(map(enc,Re)),'bubble_matrix':list(map(enc,M)),'K_from_source':enc(K),'source_hh':rowencode(source),'shifted_triangle_images_nonzero':shiftsec});off+=n;print('STAGE SOURCE_EXTERIOR',sec,flush=True)
# Right/left conversion in the inherited even BV bracket: the extra (-1)^p
# and source parity cancel, so (Sigma,J_i)=left_Euler_i for BOTH parities.
source_bracket_factors={str(p):(-1)**p*(-1)**p for p in [0,1]};assert source_bracket_factors=={'0':1,'1':1}
finish('replay',{'method':'multiset_enumeration_measured_source_K_plane_projector_and_exterior_products','census':census,'color':out,'source_bracket_factors':source_bracket_factors,'measured_K_nonzero':len(Kfull.todok()),'h_JL_w_structural_zero_inherited':True},t)
