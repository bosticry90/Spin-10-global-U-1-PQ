from data_v2 import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_v2_tables.json.gz');R=packed(HERE/'replay_v2_tables.json.gz')
keys=['primitive_covariance_positions','primitive_covariance_residual','constant_tangent_rows','constant_chain_edges','one_tangent_max_degree','two_tangent_max_degree','fictitious_LL_positive_cycle_control','new_labeled_vertex_ports','new_source_substitutions','new_free_edges','finite_heat_lengths']
for k in keys:assert P[k]==R[k],k
assert P['primitive_covariance_residual']==0 and len(P['constant_tangent_rows'])==225 and sum('__' in n for _,n,_ in P['constant_tangent_rows'])==180
assert P['one_tangent_max_degree']==3 and P['two_tangent_max_degree']==4 and not P['new_free_edges'] and P['fictitious_LL_positive_cycle_control']
old=read(HERE/'validation_receipt.json');assert old['summed_hh_antighost_nonzero']==0 and not old['new_quantum_trace_or_multiple_insertion_domain_proved']
domain=read(CAL/'canonical_so10_joint_born_ir_trace_domain/validation_receipt.json');assert domain['complete_Q_varying_one_loop_interaction_joint_trace_domain_in_scope']
ats=packed(CAL/'canonical_so10_auxiliary_tangent_source_kernel/annihilator_v2_tables.json.gz');assert ats['raw_port_nonzero']==ats['plane_port_nonzero']==0
vac=packed(CAL/'canonical_so10_tangent_antighost_scalar_vertex/vacuum_primary_v3_tables.json.gz');fullv=dec(vac['extra_bubble']);off=0;counts=Counter();local=[];slots=Counter()
for pb,rb,(sec,n) in zip(P['color'],R['color'],SECTORS):
 assert pb['sector']==rb['sector']==sec
 pp=pb['coefficient_blocks'];rr=rb['coefficient_blocks']
 assert set(pp)==set(rr)
 for key in pp:
  if isinstance(pp[key],list):
   assert len(pp[key])==len(rr[key])==45
   for a,b in zip(pp[key],rr[key]):zero(dec(a)-dec(b));counts[key]+=len(dec(a).todok());slots[key]+=n*n
  else:zero(dec(pp[key])-dec(rr[key]));counts[key]+=len(dec(pp[key]).todok());slots[key]+=len(dec(pp[key]))
 for m,om in zip(pp['extra_triangle'],pp['ordinary_M']):zero(dec(m)-dec(om))
 zero(dec(pp['affine_v'])-fullv[:,off:off+n]);off+=n
 local.append({'sector':sec,'coefficient_blocks':pp})
assert counts['ordinary_H']==36320 and counts['ordinary_M']==0 and counts['auxiliary']==17658 and counts['affine_w']==42426 and counts['source_Jx']==1342 and counts['affine_v']==448 and counts['extra_triangle']==0
# The same seven carrier types are exhausted by the proper-cycle and UV
# coefficient-dimension argument in CONTINUATION_V2. These are not ranks.
assert len(old['admitted_parent_patterns'])==7
controls={'duplicate_Jx_K_h':counts['source_Jx'],'reverse_Jx_sign':counts['source_Jx'],'omit_affine_bubble':counts['affine_w'],'wrong_affine_heat6':counts['affine_w'],'omit_shifted_minus_h_H':old['omitted_shifted_minus_h_changed_positions']['ordinary_H'],'omit_shifted_minus_h_X':old['omitted_shifted_minus_h_changed_positions']['auxiliary']};assert all(v>0 for v in controls.values())
out={'status':'QUALIFIED_COMMON_ZERO_MATTER_H_LOCAL_COMPARISON_WITH_MATCHED_SINGLE_VARIATION_DOMAIN','elapsed_after_imports':time.perf_counter()-t,'coefficient_nonzero_counts':dict(counts),'within_sector_positions_compared':dict(slots),'primitive_H_covariance_positions':P['primitive_covariance_positions'],'primitive_H_covariance_residual':0,'constant_tangent_entries_unchanged':225,'one_tangent_IR_degree':3,'two_tangent_critical_IR_degree_control':4,'fictitious_LL_cycle_detected':True,'new_free_edges':0,'all_new_substitutions_preserve_test_labels':True,'generic_extra_triangle_operator_nonzero':0,'finite_heat_lengths':P['finite_heat_lengths'],'full_allowed_parent_patterns':7,'homogeneous_finite_freedoms_fixed':False,'new_Jx_kernel_ownership':'REPLACES_VHR_V5_NEW_JH_OWNER_NOT_AN_ADDITIONAL_COPY','proper_JxCv_owner':'EXISTING_C_BSTOKES_UNCHANGED','six_selected_physical_fermion_projections':'AUTHENTICATED_REUSE_NOT_REPROVED_BY_METRIC_ARGUMENT','analytic_proof':'CONTINUATION_V2.md; inherited joint-domain and metric-Stokes assumptions explicitly matched','quantum_scope':'FORMAL_EUCLIDEAN_BOSONIC_LOCAL_COMPARISON_AND_SINGLE_VARIATION_TEST_FIELDS','controls_changed_positions':controls,'multiple_insertion_QAP_measure_globalphase_Lorentzian_physicalvacuum_qualified':False,'full_chiral_extension_proved':False,'full_QAP_E5A5_qualified':False,'authority':'34/39','scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps({'scope':out,'cochain':local,'coupling_heat_tags':{'source_Jx':'+g10^2*xi*chi4','ordinary_H':'-g10^3*xi*eta_H*chi6','ordinary_M':'-g10^3*xi^2*chi6','auxiliary':'+g10^2*xi^2*chi6','affine_w':'+g10^3*xi^2*chi4','extra_triangle':'-g10^3*xi^2*chi6; evaluated zero only AFTER direct operator contraction'},'coordinates':'unshifted_x,w=v0+z; affine_v evaluation is not another parent','chi6':'chi4+log(3/2)','b0_kappa_chi4':'distinct free quantities; none fixed'},sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'common_h_local_comparison_v2.json.gz').open('xb') as f:f.write(blob)
out.update({'artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest()});print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
