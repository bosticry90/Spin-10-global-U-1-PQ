# TSO1: the source columns and what local compatibility can establish

All formulas are in unshifted physical scalar x. Write the real Euclidean
tangent density as S_h=g*xi*h_A*a_e*R_e,jA*x_j, where R_e=(PM rho)_e
is the actual heavy-projected scalar generator. The inherited BV bracket
gives (Sigma,phi_i)=R_i and (Sigma,J_i)=leftEuler_i(Sigma). Therefore

 E_h,x_j=+g*xi*h_A*a_e*R_e,jA,
 E_h,a_e=-g*xi*h_A*R_e,jA*x_j.

The second minus is a LEFT odd derivative through the preceding h. There
are no new Euler contributions to B,C,Lambda or matter sources. In
b_ext=b0+D_h+E_h,i*left_partial_Ji, D_h=integral h_A delta/dz_A is a
functional parameter variation including its jet chain rule. The elementary
external-source rule qJ=0 has not been changed: b_ext is the cotangent
Slavnov operation as in CSW. For eta=x-w, qeta=qx-h must be retained.

The actual orbit primitive is linear in w at fixed x, with commuting
source-free canonical generators Pi_A. The declared extension has
partial_w Sigma=(Sigma,Pi), while (Sigma,h Pi)=-h(Sigma,Pi).
Its source-free connection self-bracket and curvature arezero. Thus the
extended master relation follows under the inherited master premise.
R_i are unchanged and independent ofw,h in unshifted coordinates. Twice
polarizing this identity gives the same full source-Hessian congruence as
CSW, with D_hH and E_h,i*R_i'' now included. Dropping the latter leaves
the nonlinear R''E_h remainder. I_hat is unchanged by the extension.
This is a classical differential identity, not a new continuum trace theorem.

To bind the connection to actual action data for arbitraryw, use the exact
heavy dual T_s and the actual source matrices. If O_a(w)=T_a*w in raw
antighost coordinates, the scalar GF coefficient is

 DM[d,c](w)=sum_a Nanti[a,d,c]*O_a(w).T-O_d(w).T*Rraw_c.

This explicitly chosen linear extension reproduces the historical scalar
and auxiliary GF coefficients atw=v0. It is not a claim that a flat action
uniquely selects it. The nonlinear antighost term is retained before its
heavy ghost port is checkedzero. Its bubble gives a bilinear matrix M_e
in C_B=g3*xi2*chi4*h_A*a_e*w_k*M_e[k,A]/(16pi2).
Direct raw contraction is compared with the independent plane result

 M_e=R_e.T*K,  K=the independently measured VTS/VTF source kernel.

The corresponding source term is C_J=g2*xi*chi4*Jx_j*K_jB*h_B/(16pi2).
No quantum coefficient is selected from this expected comparison. Both
come from already measured loops, including their different orientations.

Define Anti(M)[A,B]=M[A,B]-M[B,A] for A<B. At h degree2, D_h C_B
has coefficient Anti(M_e), while E_h,x*partial_Jx C_J
has coefficient -Anti(R_e.T*K), in canonical h_A*h_B*a_e order,A<B.
Their sum tests the actual local compatibility condition. The same common
chi4 is required; replacing only the bubble bychi6=chi4+log(3/2) would
leave log(3/2)*Anti(M_e). This is a sensitive local test when that matrix
is nonzero. It does not set chi4 to a chosen value. SourceJa is needed for
the complete differential even though this particular C_h has no Ja term.

The h*a*x triangles have no explicitw. In shifted coordinates they acquire
a parameter derivative through x=eta+w, which cancels against the -h in
qeta. Test this with the full measured OH,OM,X tensors before specializing
to v0; the vanishing evaluated OHv0 does not authorize dropping its generic
shifted-coordinate image.

Parent census uses hdim2/gh1, field/source dimensions as inJMF and an
independent scalar zdim1/gh0. Coefficientdegree0 allows h*a*x,h*a*z,
h*JL*x,h*JL*z,h*Jx; coefficientdegree1 allows h*a,h*JL. These are field
patterns, not independent invariant tensors. Representation, localH,
physical reality and parameter restrictions may reduce their spaces. All
mass/v-compatible homogeneous directions remain allowed until actual
conditions determine them. Matter-containing h parents exceed dimension
or fail ghost/parity/Lorentz conditions. Derivative/vector source candidates
have an unmatched Lorentz index. No h2 parent has dimension4/gh0, but its
ghost-one breaking images hh*a AND hh*JL ofdimension5 are allowed. The
actual JL*h*w coefficient is zero by the generic heavy ghost-port/LL
support proof, so its present hh*JL image is zero; this does not fix an
admissible homogeneous JL*h*w normalization freedom.

Every admitted h parent is a Lorentz scalar with no vector/jet slot. Its
Q image has Lorentz rank<=2 from physical scalar/source Euler terms, with
indices ending on fields or jets. The two new source columns and D_h have
no metric trace or dimension-dependent coefficient. Therefore the extended
local operation commutes with physical metric projection and the firstDjet
on this specified module. Boundary currents from functional variation are
retained. This does not establish the common IR/trace domain, multiple
insertions, a QAP or source equivalence; those hypotheses remain to be
matched before the old metric finite-part theorem can be extended.
