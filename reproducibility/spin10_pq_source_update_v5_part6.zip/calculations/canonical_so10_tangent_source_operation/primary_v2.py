from data_v2 import *
t=begin2('primary');old=packed(HERE/'primary_tables.json.gz');tav=packed(CAL/'canonical_so10_tangent_antighost_scalar_vertex/primary_v2_tables.json.gz');phy=read(PK/'frozen_a10_physical_reconciliation/full_primary.json');H=dec(packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz')['H_new']);Nrows=packed(CAL/'canonical_so10_vacuum_heat_root_completion/color_primary_v3_tables.json.gz')['Nanti'];NN=[s.SparseMatrix(45,45,{}) for _ in range(12)];GTT=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/primary_tables.json.gz');CG=dec(GTT['raw_Gca']);U=dec(GTT['raw_aux_map']);FM=dec(read(PK/'frozen_a10_e1_fermion/primary.json')['charts']['blocks']['heavy_dual']['field_embedding']);FC={tuple(r[:3]):co(r[3]) for r in tav['raw_Fc']}
for e,d,c,z in Nrows:
 for a in range(12):
  if H[c,a]:NN[a][e,d]+=co(z)*H[c,a]
NN=list(map(tidy,NN));out=[];covslots=0;off=0;v=dec(phy['vacuum']['VEV']);wrongsource=0
for b,tab,(sec,n) in zip(old['color'],tav['color'],SECTORS):
 R=list(map(dec,phy['representation_matrices'][sec]));RH=[tidy(sum((H[c,a]*R[c] for c in range(45) if H[c,a]),ZERO(n))) for a in range(12)];Re=list(map(dec,b['source_generator']));K=dec(b['K_from_raw']);M=list(map(dec,b['bubble_matrix']))
 for a,rh in enumerate(RH):
  zero(rh*K-K*rh)
  for d,r in enumerate(Re):zero(rh*r-r*rh+sum((NN[a][e,d]*Re[e] for e in range(45) if NN[a][e,d]),ZERO(n)))
 covslots+=12*46*n*n
 # Candidate assembled in the unshifted variables, separate exact coupling
 # tags and heat lengths; mass and generic z coefficient are separate owners.
 TT=[tidy(sum((FM[c,a]*R[c] for c in range(45) if FM[c,a]),ZERO(n))) for a in range(33)];GT=[tidy(sum((CG[c,12+a]*TT[a] for a in range(33) if CG[c,12+a]),ZERO(n))) for c in range(45)];traw=[ZERO(n) for a in range(45)];cache={}
 for (r,a,c),zz in FC.items():
  if (r,c) not in cache:cache[r,c]=GT[r].T*GT[c]
  traw[a]+=zz*cache[r,c]
 triangle=[tidy(sum((U[a,e]*traw[a] for a in range(45) if U[a,e]),ZERO(n))) for e in range(45)]
 coef={key:tab[key] for key in ['ordinary_H','ordinary_M','auxiliary']};coef['affine_w']=b['bubble_matrix'];coef['source_Jx']=b['K_from_raw'];coef['affine_v']=enc(s.SparseMatrix.vstack(*[v[off:off+n,0].T*m for m in M]));coef['extra_triangle']=maprows(triangle)
 out.append({'sector':sec,'coefficient_blocks':coef});off+=n;print('STAGE COMMON_LOCAL_PARENT',sec,flush=True)
def closure(gg):
 a=times(gg,V);star=plus(a,{(i,i):0 for i in NODES})
 for k in NODES:
  for i in NODES:
   for j in NODES:
    if (i,k) in star and (k,j) in star:star[i,j]=max(star.get((i,j),-1000),star[i,k]+star[k,j])
 return times(star,gg),any(star.get((i,i),0)>0 for i in NODES)
dressed,bad=closure(G);assert not bad;one=times(times(dressed,T),dressed);two=times(times(one,T),dressed);assert closure(plus(G,{('L','L'):2}))[1]
maps=packed(CAL/'canonical_so10_cutoff_source_ward_operator/primary_inputs.json.gz')['field_maps'];linear=linear_tangent(maps);assert len(linear)==225
finish2('primary',{'method':'unshifted_exact_typed_cochain_assembly_actual_plane_primitive_covariance_and_maxplus_closure','color':out,'primitive_covariance_positions':covslots,'primitive_covariance_residual':0,'constant_tangent_rows':linear,'constant_chain_edges':encgraph(dressed),'one_tangent_max_degree':max(one.values()),'two_tangent_max_degree':max(two.values()),'fictitious_LL_positive_cycle_control':True,'new_labeled_vertex_ports':[['h','a','X'],['z','L','X'],['z','a','C','X']],'new_source_substitutions':[['Jx','h','a'],['Ja','h','X'],['z','h']],'new_free_edges':[],'finite_heat_lengths':{'source_Jx':4,'affine_w':4,'ordinary_H':6,'ordinary_M':6,'auxiliary':6}},t)
