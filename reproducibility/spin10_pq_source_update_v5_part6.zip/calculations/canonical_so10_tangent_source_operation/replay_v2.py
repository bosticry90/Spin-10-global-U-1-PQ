from data_v2 import *
t=begin2('replay');old=packed(HERE/'replay_tables.json.gz');tav=packed(CAL/'canonical_so10_tangent_antighost_scalar_vertex/replay_v2_tables.json.gz');phy=read(PK/'frozen_a10_physical_reconciliation/full_replay.json');H=dec(packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz')['H_new']);Q=dec(phy['C3_plane_to_parent']);Qi=Q.inv();U=dec(packed(CAL/'canonical_so10_ghost_triangle_field_insertion/replay_tables.json.gz')['raw_aux_map']);Ui=U.inv();maps=packed(CAL/'canonical_so10_cutoff_source_ward_operator/replay_inputs.json.gz')['field_maps'];an=[f'bar{a}' if a<12 else f'ub{a}' for a in range(45)];ai={n:i for i,n in enumerate(an)};Ns=[s.SparseMatrix(45,45,{}) for _ in range(45)];g=s.Symbol('g10')
for r,name in enumerate(an):
 for row in maps[name]:
  w=row['word']
  if len(w)!=2:continue
  ci=next(i for i,n in enumerate(w) if n.startswith('C'));c=int(w[ci][1:]);a=ai[w[1-ci]];Ns[c][r,a]+=co((-1 if ci else 1)*s.sympify(row['coefficient'])/g)
NH=[]
for a in range(12):
 rawghost=Qi*H[:,a];NH.append(tidy(Ui*sum((rawghost[c]*Ns[c] for c in range(45) if rawghost[c]),s.SparseMatrix(45,45,{}))*U))
out=[];off=0;v=dec(phy['vacuum']['VEV']);covslots=0
for b,tab,(sec,n) in zip(old['color'],tav['color'],SECTORS):
 Re=list(map(dec,b['source_generator']));R=list(map(dec,phy['representation_matrices'][sec]));RH=[tidy(sum((H[c,a]*R[c] for c in range(45) if H[c,a]),ZERO(n))) for a in range(12)];K=dec(b['K_from_source']);M=list(map(dec,b['bubble_matrix']))
 for a,rh in enumerate(RH):
  zero(rh.T*K+K*rh)
  # Three direct tensor-slot substitutions, rather than a commutator shortcut.
  for d,r in enumerate(Re):zero(-rh.T*r-r*rh+sum((NH[a][e,d]*Re[e] for e in range(45) if NH[a][e,d]),ZERO(n)))
 covslots+=12*46*n*n
 # Assemble in eta coordinates then pull x=eta+w back: the triangle's w
 # evaluation is the SAME parent, not an additional affine bubble.
 gt=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/replay_tables.json.gz');pj={k:{tuple(r[:3]):co(r[3]) for r in gt['plane_jets'][k]} for k in ['c','B']};fc=clean({k:pj['c'].get(k,0)-pj['B'].get(k,0) for k in set(pj['c'])|set(pj['B'])});tri=[ZERO(n) for e in range(45)];cache={}
 for (r,e,c),zz in fc.items():
  if (r,c) not in cache:cache[r,c]=Re[r].T*Re[c]
  tri[e]+=zz*cache[r,c]
 coef={key:maprows(list(map(dec,tab[key]))) for key in ['ordinary_H','ordinary_M','auxiliary']};coef['affine_w']=maprows(M);coef['source_Jx']=enc(K);coef['affine_v']=enc(s.SparseMatrix(45,n,{(e,j):co(sum(v[off+k,0]*M[e][k,j] for k in range(n) if v[off+k,0])) for e in range(45) for j in range(n)}));coef['extra_triangle']=maprows(list(map(tidy,tri)))
 out.append({'sector':sec,'coefficient_blocks':coef});off+=n;print('STAGE SHIFTED_LOCAL_PARENT',sec,flush=True)
# Simple-path closure plus all simple-cycle inspection. Removing a nonpositive
# cycle never increases a maximum path weight, so no arbitrary depth cutoff.
def pathclosure(gg):
 a=times(gg,V);star={(i,i):0 for i in NODES};positive=False
 for start in NODES:
  def walk(at,seen,weight):
   nonlocal positive
   for (i,j),w in a.items():
    if i!=at:continue
    if j==start:
     if weight+w>0:positive=True
    if j not in seen:
     star[start,j]=max(star.get((start,j),-1000),weight+w);walk(j,seen|{j},weight+w)
  walk(start,{start},0)
 return times(star,gg),positive
dressed,bad=pathclosure(G);assert not bad;one=times(times(dressed,T),dressed);two=times(times(one,T),dressed);assert pathclosure(plus(G,{('L','L'):2}))[1]
finish2('replay',{'method':'shifted_coordinate_pullback_raw_source_covariance_and_simple_path_cycle_analysis','color':out,'primitive_covariance_positions':covslots,'primitive_covariance_residual':0,'constant_tangent_rows':linear_tangent(maps),'constant_chain_edges':encgraph(dressed),'one_tangent_max_degree':max(one.values()),'two_tangent_max_degree':max(two.values()),'fictitious_LL_positive_cycle_control':True,'new_labeled_vertex_ports':[['h','a','X'],['z','L','X'],['z','a','C','X']],'new_source_substitutions':[['Jx','h','a'],['Ja','h','X'],['z','h']],'new_free_edges':[],'finite_heat_lengths':{'source_Jx':4,'affine_w':4,'ordinary_H':6,'ordinary_M':6,'auxiliary':6}},t)
