# TSO1: actual extended source operation and local tangent compatibility

PreviousgoalturnPROGRESS. Base604be9c28b64572479fda1bc4137dff4ff274e9d,
main33893olderblobs, whole goalACTIVE/incomplete. State113/34of39 unchanged.
Recover currentAGENTS/preflight/V580/actualTAVpostseal before execution.

Question: do the actual tangent source operation and independently measured
ordinary/source finite tensors support a common admitted local h-dependent
cochain? First construct its complete parent-pattern module, derive the new
source Euler columns from the actual primitive, and test the local hh*a image.
This is a necessary compatibility test, not full quantum restoration/QAP.
The director's supplied assessment be726499-7d6f-415e-963e-bfcd786bf32c is
reference intake, not an authority ledger. Its priority and exact-once/sign/
heat-length cautions agree with this test. Bind its original attachment
bytes and use actual committed receipts for VHR/TAV rather than relying
on its secondhand reported validation. No external factual claim from it
is adopted or used as a new scientific premise.
It addresses a missing prerequisite for applying the old metric finite-part
constructor; another unmotivated component expansion would not resolve it.

Use the existing provisional unshifted x,v/z,h extension. Explicitly allow
local Schwartz spurions z_A,h_A, qz=h,qh=0, w=v0+z, holding K0/projectors/
physical action parameters fixed. Only the GF orbit is extended by the same
heavy-dual primitive. No historical uniqueness or physical adoption is
claimed. At z=h0 all old bytes/inputs are recovered. Retain z jets under
functional parameter variation; a constant-parameter shortcut is not enough.

Domain: local polynomial parent density dimension4/ghost0, even parity,
exactly one h; nonnegative parameter dimensions, integer mass/v coefficients,
all ordinary bosonic fields/sources and SMA matter/source types. Lorentz-
invariant contractions; no preferred vector, inverse parameter or explicit
spacetime coordinate. Include z as a distinct scalar spurion. Enumerate
coefficientdimension0 and1 patterns without identifying them with independent
representation counterterms or their ranks. Do not declare a mass coefficient
absent merely because only v occurs in the measured quantum input.

Primary: doubled-dimension recursive census; actual raw heavy-dual/CG/scalar
maps and antighost rules, generic-w GF reconstruction, direct ordered exterior
Euler/source and parameter variations. Replay: independent multiset-generating
census, normalized heavy projector and old independently measured sourceK,
analytic operator identity and separate exterior differentiation. Authenticate
the old TAV/VTS/VTF quantum coefficients before comparing them. No coefficient
is solved from a cancellation. All zero complements and sensitive controls
are retained; exact nonzero remainders are permitted outcomes.

Construct b_ext=b0+integral h delta_z+E_h,x delta_Jx+E_h,a delta_Ja using the
inherited left source/Euler convention. All other new source columns vanish.
Keep the elementary qJ=0 distinct from the cotangent operation. Derive the
full source-Hessian congruence from the extended master-family identity,
with R''E_h and the parameter variation retained. The inherited classical
master premise is authenticated reuse, not a new HB1/C5 qualification.

Independently test the generic-w ordinary vacuum bubble B_e(w) against the
measured Jx*K*h coefficient and the exact source Euler signs. Extract the
entire local hh*a coefficient, not a selected mass projection. Also retain
the allowed hh*JL image and its actual structural-zero qualification; do
not infer that all homogeneous JL*h*w counterterms vanish. A zero image
does not construct double-insertion quantum products or their trace domain.
Wrong source sign, omitted h delta_z, heat6 vsheat4, and omitted -h in
qeta=qx-h are controls; report any actual insensitivity. Maintain chi4,b0,
kappa and all invariant finite freedoms; choose none.

Prove the extended local differential commutes with the first metric dimension
jet in this module using actual scalar source columns and Lorentz ranks.
This is an algebraic prerequisite. Full h-dependent first-variation trace/
connected-product applicability remains a separate analytic question until
its hypotheses are matched. Do not infer a complete renormalized family
from the module census, local curvature or a formal doublet homotopy.

Sequential nativeprimary,replay,gate;600s afterimports/8GiB sampled private/
350MiB availablecommit floor/16MiB packet. Poleblind Python-B, immutable
source copies/input bindings, exclusive outputs and complete failure captures.
Preserve unfinished/failed runs; no requirement/resource weakening. Validate
before local commit; external before/index/after seals preserve33893oldblobs.
CurrentE4custodyexit2/sevenNOTPASS. No agents/branches/worktrees/push/outreach,
flavorresume/HB1C5, scheme/benchmark/state or scientific authority change.

Possible results: admitted compatible local cochain, exact incompatibility,
underdefined source/domain premise, or resource incomplete. TrackA narrows
actual quantum-construction prerequisites; TrackB tests distinct exact
methods and shared-error limits without another benchmark platform. Same
action/maps/reference/software/AI author remain shared; no external physical
or proof-assistant confirmation. TrackCvoluntary/nonblocking. Full products,
QAP, measure/globalphase, causal/Lorentzian/physicalvacuum/massiveC1/E5A5/GUT
remain unqualified. Record limitations and the most informative next action.
