from data import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');assert P['census']==R['census']
assert P['census']=={'parent_h1':[['JL',1],['JL*X',0],['JL*z',0],['Jx',0],['X*a',0],['a',1],['a*z',0]],'parent_h2':[],'image_h2':[['JL',0],['a',0]]}
assert P['raw_anti_rows']==180 and P['raw_anti_heavy_port_nonzero']==0 and P['raw_anti_heavy_port_positions']==66825
assert P['actual_GF_rows']=={'LX':432,'aCX':6688} and P['actual_GF_reconstruction_positions']==664200
assert P['Euler_sign_fixtures']['E_x'][0]==1 and P['Euler_sign_fixtures']['E_a'][0]==-1 and R['source_bracket_factors']=={'0':1,'1':1}
assert P['other_bosonic_source_columns_zero']==270 and P['h_JL_w_structural_zero_inherited'] and R['h_JL_w_structural_zero_inherited']
ats=read(CAL/'canonical_so10_auxiliary_tangent_source_kernel/validation_receipt_v2.json');assert ats['zero_before_momentum_integration']
vf=read(CAL/'canonical_so10_tangent_antighost_scalar_vertex/vacuum_receipt_v3.json');assert vf['JL_h_v_qualified_zero_in_scope'] and vf['bubble_heat_length']==4
sourcef=read(CAL/'canonical_so10_vacuum_tangent_source_finite/validation_receipt.json');assert sourcef['relative_action_addition_sign']==1 and sourcef['common_chi4_matches_existing_bosonic_finite_part']
euler=0;bnz=0;gnz=0;curve=0;controls=Counter();shifts=Counter();groupcounts={};maps=[]
for (sec,n),pb,rb in zip(SECTORS,P['color'],R['color']):
 assert pb['sector']==rb['sector']==sec;zero(dec(pb['K_from_raw'])-dec(rb['K_from_source']));pk=dec(pb['K_from_raw']);km=s.SparseMatrix(n,n,{})
 for key in ['source_generator','bubble_matrix']:
  assert len(pb[key])==len(rb[key])==45
  for a,b in zip(pb[key],rb[key]):zero(dec(a)-dec(b))
 bg={tuple(row[:3]):co(row[3]) for row in pb['bubble_hh']};sg={tuple(row[:3]):co(row[3]) for row in rb['source_hh']};res=clean({k:bg.get(k,0)+sg.get(k,0) for k in set(bg)|set(sg)})
 # The failure condition is equality of the complete image; nonzero quantum
 # inputs are not adjusted. Retain both individual full tensors in artifact.
 assert not res
 bnz+=len(bg);controls['omit_parameter_variation']+=len(sg);controls['omit_source_Euler']+=len(bg);controls['reverse_source_sign']+=len(clean({k:bg.get(k,0)-sg.get(k,0) for k in set(bg)|set(sg)}));controls['wrong_bubble_heat6']+=len(bg)
 for k,val in rb['shifted_triangle_images_nonzero'].items():shifts[k]+=val
 euler+=sum(len(dec(m).todok()) for m in pb['source_generator']);gnz+=sum(len(dec(m).todok()) for m in pb['bubble_matrix'])
 for e,m in enumerate(pb['bubble_matrix']):
  mm=dec(m);expected={(e,i,j):-z for (i,j),z in anti_sparse(mm).items()};actual={k:v for k,v in bg.items() if k[0]==e};assert expected==actual
  for z in mm.todok().values():assert co(s.conjugate(z)-z)==0
 groupcounts[sec]={'generic_bubble_nonzero':sum(len(dec(m).todok()) for m in pb['bubble_matrix']),'individual_hh_image_nonzero':len(bg),'summed_hh_image_nonzero':len(res),'shifted_triangle_images_nonzero':rb['shifted_triangle_images_nonzero']}
 maps.append({'sector':sec,'source_generator':pb['source_generator'],'generic_bubble':pb['bubble_matrix'],'source_K':rb['K_from_source'],'bubble_hh':pb['bubble_hh'],'source_hh':rb['source_hh'],'sum_hh':[]})
assert euler==P['new_source_Euler_generators_nonzero_each'] and bnz>0
assert all(controls[k]>0 for k in ['omit_parameter_variation','omit_source_Euler','reverse_source_sign','wrong_bubble_heat6'])
assert shifts['ordinary_H']>0 and shifts['auxiliary']>0
within=45*sum(n*(n-1)//2 for _,n in SECTORS);full=45*328*327//2
# Both h2 breaking carrier patterns are retained. JL's actual coefficient
# remains zero by the raw port annihilator, for arbitrary w, and LL=0;
# this is not a statement about freely added homogeneous JL*h*w terms.
out={'status':'QUALIFIED_SELECTED_LOCAL_TANGENT_SOURCE_OPERATION_AND_HH_COMPATIBILITY','elapsed_after_imports':time.perf_counter()-t,'admitted_parent_patterns':P['census']['parent_h1'],'admitted_hh_breaking_patterns':P['census']['image_h2'],'generic_bubble_nonzero_positions':gnz,'new_source_Euler_nonzero_positions_each':euler,'new_source_Euler_potential_positions_each':45*328**2,'unaffected_bosonic_source_columns':270,'hh_antighost_positions_full':full,'hh_antighost_positions_within_sectors':within,'hh_antighost_cross_sector_zeros_by_types':full-within,'individual_hh_bubble_and_source_nonzero_each':bnz,'summed_hh_antighost_nonzero':0,'actual_hh_JL_nonzero':0,'hh_JL_positions_full':full,'generic_w_connection_matches_frozen_GF_positions':664200,'controls_changed_positions':dict(controls),'omitted_shifted_minus_h_changed_positions':dict(shifts),'group_counts':groupcounts,'bubble_and_Jx_kernel_common_heat_length':4,'chi4_fixed':False,'b0_kappa_identified':False,'source_kernel_owned_once':True,'classical_master_premise_reused':True,'local_metric_first_dimension_jet_commutation_derived':True,'new_quantum_trace_or_multiple_insertion_domain_proved':False,'full_common_h_finite_quantum_family_qualified':False,'full_QAP_E5A5_qualified':False,'authority':'34/39','scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps({'scope':out,'local_maps':maps,'census':P['census'],'source_Euler_signs':{'E_x':1,'E_a':-1},'source_operation':'b0 + integral h delta_z + E_h,x left_delta_Jx + E_h,a left_delta_Ja','metric_commutation':'local algebraic prerequisite only; see DERIVATION'},sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_local_tangent_source_operation.json.gz').open('xb') as f:f.write(blob)
out.update({'artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest()});print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
