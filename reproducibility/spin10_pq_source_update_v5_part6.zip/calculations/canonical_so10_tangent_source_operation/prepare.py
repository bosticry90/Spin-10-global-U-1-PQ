from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/tangent-source-operation-v1-2026-10-24');BASE='604be9c28b64572479fda1bc4137dff4ff274e9d'
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip();bind={}
def add(p,h=None):
 p=p.resolve();v=sha256(p.read_bytes()).hexdigest()
 if h is not None:assert v==h,p
 bind[str(p)]=v
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V580.md']:add(ROOT/n)
add(ROOT/'project_state.json','d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8')
add(Path('C:/Users/psboy/.codex/attachments/be726499-7d6f-415e-963e-bfcd786bf32c/Pasted text.txt'))
add(Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/tangent-antighost-scalar-vertex-v1-2026-10-24/postcommit_seal.json'))
for role in ['primary','replay']:
 for n in ['frozen_a10_physical_reconciliation/full_'+role+'.json','frozen_a10_e1_fermion/'+role+'.json']:add(PK/n)
 for folder,n in [('canonical_so10_ghost_triangle_field_insertion',role+'_tables.json.gz'),('canonical_so10_yukawa_carrier_transport',role+'_tables.json.gz'),('canonical_so10_vacuum_tangent_source_kernel',role+'_tables.json.gz'),('canonical_so10_cutoff_source_ward_operator',role+'_inputs.json.gz'),('canonical_so10_tangent_antighost_scalar_vertex',role+'_v2_tables.json.gz'),('canonical_so10_tangent_antighost_scalar_vertex','vacuum_'+role+'_v3_tables.json.gz')]:add(CAL/folder/n)
for folder,names in {'canonical_so10_tangent_antighost_scalar_vertex':['RECORD.md','DERIVATION.md','CONTINUATION_V2.md','VACUUM_CONTINUATION_V3.md','RESULT.md','validation_receipt_v2.json','vacuum_receipt_v3.json','validation_preparation_v3.json'],'canonical_so10_vacuum_tangent_source_kernel':['DERIVATION.md','RESULT.md','validation_receipt.json'],'canonical_so10_vacuum_tangent_source_finite':['DERIVATION.md','validation_receipt.json'],'canonical_so10_auxiliary_tangent_source_kernel':['validation_receipt_v2.json','annihilator_v2_tables.json.gz','RESULT.md'],'canonical_so10_cutoff_source_ward_operator':['DERIVATION.md','validation_receipt.json'],'canonical_so10_dimensional_stokes_primitive':['DERIVATION.md','RESULT.md'],'canonical_so10_vacuum_heat_root_completion':['JOINT_EXTENSION_V5.md','joint_receipt_v5.json']}.items():
 for n in names:add(CAL/folder/n)
add(CAL/'canonical_so10_tangent_antighost_scalar_vertex/validation_receipt_v2.json','7b2936a6113ccd9edcdd66fa3bd5a7d70a6810683fa42d72159d64dd57b63a21');add(CAL/'canonical_so10_tangent_antighost_scalar_vertex/vacuum_receipt_v3.json','bba7a271ceaa92158f887241bc36e1b65dfdf517ff18e3e7a7a66ebd55394cd7')
add(PK/'export_a10_e5_antighost_vector.py')
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw)
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==33893
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
with (HERE/'preparation.json').open('xb') as f:f.write((json.dumps({'schema':'TSO1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(bind.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('TSO1_FROZEN',len(bind),'bindings',flush=True)
