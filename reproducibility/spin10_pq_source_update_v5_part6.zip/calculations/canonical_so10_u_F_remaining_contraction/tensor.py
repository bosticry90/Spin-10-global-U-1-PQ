from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os,sys
from reduced import *
O=Path(__file__).resolve().parent;U=O.parent/'canonical_so10_u_F_fourth_support';role=sys.argv[1];assert role in ['primary','replay']
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for pp,hsh in json.loads((O/'tensor_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(pp).read_bytes()).hexdigest()==hsh,pp
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        pp=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
        if pp.parent.name in ['canonical_so10_u_pair_contact_model','canonical_so10_intrinsic_auxiliary_ghost_source'] or pp.name.endswith(('_selected.json.gz','_source_d.json.gz')) or pp.parent.resolve()==O and pp.name.startswith(peer+'_tensor'):raise PermissionError('UFR_TENSOR_QUANTUM_TARGET_PEER_DENIED')
sys.addaudithook(guard)
denied=0
for pp in [U/'primary_selected.json.gz',U/'primary_source_d.json.gz',O.parent/'canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz',O/(('replay' if role=='primary' else 'primary')+'_tensor.json.gz')]:
    try:pp.read_bytes()
    except PermissionError:denied+=1
assert denied==4
loadz=lambda pp:json.loads(gzip.decompress(pp.read_bytes()))
p=recover(role);rows=json.loads((O/'typed_result.json').read_bytes())['rows'];ev=evaluator(p,rows,role);contract=tensor_contractor(p,role)
info,words=remaining_words(loadz(U/'inventory_result.json.gz'),loadz(U/'refined_result.json.gz'))
cal=json.loads((O/(role+'_action.json')).read_bytes());weight_checks=[]
for z in cal['rows']:
    r=z['source'];h,k=z['ghosts'];W=ev(r)(h,k);direct=cut_weights(p,h,k,r,info,words)
    direct={fam:{pref:{ij:v for ij,v in M.items() if ij[0]>=12} for pref,M in by.items()} for fam,by in direct.items()}
    direct={fam:{pref:M for pref,M in by.items() if M} for fam,by in direct.items()}
    assert W==direct,('TYPED_WEIGHT_FULL_ARRAY',r,h,k)
    for fam,by in W.items():
        v=contract(by,h,k).get((z['scalar'],),ZERO)
        assert str(v)==z['families'][fam],('FAMILY_CALIBRATION',r,h,k,fam,str(v),z['families'][fam])
    weight_checks.append({'source':r,'ghosts':[h,k],'family_weights_and_zero_complements_equal':True})
print('STAGE actual_typed_weights_verified',flush=True)
fams={fam:{} for fam in FAMILIES};total={};pairs=0
for r in range(13,45):
    atsource=ev(r)
    for h in range(45):
        for k in range(h+1,45):
            W=atsource(h,k);summed={}
            for fam,by in W.items():
                M=contract(by,h,k)
                for (i,),v in M.items():fams[fam][r,h,k,i]=v;put(summed,(i,),v)
            for (i,),v in clean(summed).items():total[r,h,k,i]=v
            pairs+=1
    print('STAGE complete_residual_source '+str(r)+' '+str(len(total)),flush=True)
def encode(M):return [[*ij,[[list(key),v.numerator,v.denominator] for key,v in c.terms]] for ij,c in sorted(M.items())]
domain=45*990*328
assert all(r>=13 and k>=12 for r,h,k,i in total)
out={'schema':'UFR3_COMPLETE_FIVE_FAMILY_C4_TENSOR','role':role,'families':{fam:encode(M) for fam,M in fams.items()},'total':encode(total),'domain_per_probe':domain,
     'probe0_zero_by_authenticated_support':True,'probe1_inactive_sources_zero_by_support':list(range(13)),'HH_zero_by_complete_noncommuting_weights':True,
     'probe1_nonzero_counts':{**{fam:len(M) for fam,M in fams.items()},'total':len(total)},'probe1_zero_complements':{**{fam:domain-len(M) for fam,M in fams.items()},'total':domain-len(total)},
     'computed_source_ghost_pairs':pairs,'actual_weight_calibrations':weight_checks,'internal_scalar_generator_colors':45,'sourceCJ_recomputed':False,'known_quantum_target_operand':False,'guard_denials':denied,'elapsed_after_imports':time.perf_counter()-tick}
blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
assert sum(pp.stat().st_size for pp in O.iterdir() if pp.is_file())+len(blob)<32*1024**2
with (O/(role+'_tensor.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({key:v for key,v in out.items() if key not in ['families','total','actual_weight_calibrations']},sort_keys=True),flush=True);timer.cancel()
