from pathlib import Path
from fractions import Fraction
from collections import defaultdict
import json,gzip,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'canonical_so10_u_F_fourth_support'))
from matrices import *
from operators import load,co,dec
from algebra import transpose
O=Path(__file__).resolve().parent;R=O.parents[1]
def cf(terms):return Coeff([(tuple(k),Fraction(n,d)) for k,n,d in terms])
def put(M,key,v):
    if v:M[key]=M.get(key,ZERO)+v
def clean(M):return {key:v for key,v in M.items() if v}
def split(i):
    return ('B',i) if i<45 else ('L',i-45) if i<90 else ('s',i-90) if i<418 else ('C',i-418) if i<463 else ('a',i-463)
def reduce_tables(role):
    raw=json.loads(gzip.decompress((R/'calculations/canonical_so10_u_F_fourth_support'/(role+'_operators.json.gz')).read_bytes()))
    out={}
    for name,rows in raw['tables'].items():
        table={}
        for i,j,w,nd,power,terms in rows:
            a,b=field(i,3),field(j,3)
            if a is None or b is None or any(p for mu,p in enumerate(power) if mu!=3):continue
            key=(a,b,tuple(w),nd);put(table,key,cf(terms))
        out[name]=clean(table)
    return out
def recover(role):
    tables=reduce_tables(role);data=load(role);RR=list(map(dec,data['R']));N={};F=[{} for _ in range(45)];J=[({}, {}) for _ in range(45)]
    for (i,j,w,nd),v in tables['VGF'].items():
        si,a=split(i);sj,b=split(j)
        if not w and nd==1 and (si,sj)==('L','s'):N[a,b]=v
        if len(w)==1 and 553<=w[0]<598:
            h=w[0]-553
            if nd==1 and (si,sj)==('a','s'):F[h][a,b]=v
            elif nd==0 and si=='a' and sj in ['B','L']:J[h][0 if sj=='B' else 1][a,b]=v
    FP={};otherFP={}
    for (i,j,w,nd),v in tables['VGF'].items():
        si,a=split(i);sj,b=split(j)
        if nd==1 and len(w)==1 and 180<=w[0]<508:
            if (si,sj)==('a','C'):FP[a,b,w[0]-180]=v
            elif (si,sj)==('C','a'):otherFP[b,a,w[0]-180]=-v
    expectedFP={(a,h,i):v for h,M in enumerate(F) for (a,i),v in M.items()}
    assert FP==expectedFP and otherFP==expectedFP,'GF_NC_NX_MIXED_DERIVATIVE_MISMATCH'
    MC=[{k:{} for k in ['B','L','C','a','s']} for _ in range(45)];beta=[{} for _ in range(45)]
    for (i,j,w,nd),v in tables['M0'].items():
        si,a=split(i);sj,b=split(j)
        if len(w)==1 and 553<=w[0]<598 and nd==0:
            assert si==sj,(si,sj)
            MC[w[0]-553][si][a,b]=v
    assert [M['s'] for M in MC]==RR and all(M==scale(transpose(M),constant(-1)) for M in RR)
    for (i,j,w,nd),v in tables['VS'].items():
        si,a=split(i);sj,b=split(j)
        if nd==0 and len(w)==1 and 1151<=w[0]<1196 and (si,sj)==('C','L'):beta[w[0]-1151][a,b]=-v
    S={};K=[{} for _ in range(45)];freeU={}
    for (i,j,w,nd),v in tables['MU1'].items():
        si,a=split(i);sj,b=split(j)
        if not w and nd==1 and (si,sj)==('a','s'):S[a,b]=v
        elif nd==0 and len(w)==1 and 553<=w[0]<598:
            assert (si,sj)==('a','a');K[w[0]-553][a,b]=v
        elif not w and not nd:freeU[(si,sj,a,b)]=v
    HN={k:{} for k in ['Bs','Ls','sB','sL']};HC=[{k:{} for k in ['Ba','La','aB','aL']} for h in range(45)];freeH={}
    for (i,j,w,nd),v in tables['HU1'].items():
        si,a=split(i);sj,b=split(j)
        if not w and nd==1:
            assert si+sj in HN
            HN[si+sj][a,b]=v
        elif nd==0 and len(w)==1 and 553<=w[0]<598:
            assert si+sj in HC[w[0]-553]
            HC[w[0]-553][si+sj][a,b]=v
        elif not w and not nd:freeH[si,sj,a,b]=v
    assert HN['sB']==scale(transpose(HN['Bs']),constant(-1)) and HN['sL']==transpose(HN['Ls'])
    assert all(z['Ba']==transpose(z['aB']) and z['La']==scale(transpose(z['aL']),constant(-1)) for z in HC)
    return {'N':N,'F':F,'S':S,'K':K,'HN':HN,'HC':HC,'J':J,'MC':MC,'beta':beta,'R':RR,'tables':tables,'freeH':freeH,'freeU':freeU,'FP':FP,'Om':{(i,i):co('eta_H' if i<12 else 'xi') for i in range(45)}}
