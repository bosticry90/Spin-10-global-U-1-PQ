from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,gzip,time,threading,os,sys
from cut import *
from matrices import pmul,lifted
O=Path(__file__).resolve().parent;U=O.parent/'canonical_so10_u_F_fourth_support'
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,hsh in json.loads((O/'cut_preparation_v2.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==hsh,path

def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        pp=Path(os.fsdecode(args[0]))
        if pp.parent.name in ['canonical_so10_u_pair_contact_model','canonical_so10_intrinsic_auxiliary_ghost_source'] or pp.name.endswith('_selected.json.gz'):raise PermissionError('UFR_NATIVE_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard)
denied=0
for path in [U/'primary_selected.json.gz',O.parent/'canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz']:
    try:path.read_bytes()
    except PermissionError:denied+=1
assert denied==2
loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()))
info,canonical_words=remaining_words(loadz(U/'inventory_result.json.gz'),loadz(U/'refined_result.json.gz'))
words=[]
for word in info['words']:
    items=[info['vertices'][label] for label in word['word']]+[info['roots'][word['root']]]
    it=next(z for z in items if z['mask'].bit_count()-int(z['name'].startswith('M'))==2)
    fam=('GF_' if it['name']=='VGF' else 'Hu_' if it['name']=='HU1' else 'Mu_')+it['pattern']
    if fam in FAMILIES:words.append({**word,'family':fam})

def fixture(seed):
    n=3;ns=4;nh=1
    generic=lambda m,l,salt:{(i,j):constant(((i+1)*(j+3)+salt+seed)%7-3) for i in range(m) for j in range(l) if ((i+1)*(j+3)+salt+seed)%7-3}
    R=[]
    for a in range(n):
        G=generic(ns,ns,a+4);R.append(plus(G,scale(transpose(G),constant(-1))))
    N={(a,j):v for (a,j),v in generic(n,ns,17).items() if a>=nh};Om={(0,0):co('eta_H'),(1,1):co('xi'),(2,2):co('xi')}
    MC=[];J=[];K=[]
    for a in range(n):
        G=generic(n,n,a+1);A=plus(G,scale(transpose(G),constant(-1)))
        A={ij:v for ij,v in A.items() if (ij[0]<nh)==(ij[1]<nh)} if a<nh else {ij:v for ij,v in A.items() if not(ij[0]<nh and ij[1]<nh)}
        L={ij:v for ij,v in A.items() if ij[0]>=nh and ij[1]>=nh} if a<nh else {}
        MC.append({'B':scale(A,co('g10')),'C':scale(A,co('g10')),'L':scale(L,co('g10')),'a':scale(L,co('g10')),'s':R[a]})
        JB=scale({ij:v for ij,v in A.items() if ij[0]<nh and ij[1]<nh} if a<nh else A,-I*co('g10'))
        JL={} if a<nh else scale({ij:v for ij,v in A.items() if ij[0]>=nh and ij[1]>=nh},I*co('xi'))
        J.append((JB,JL));K.append(scale(JL,2*I))
    beta={(i,j):v for (i,j),v in generic(n,n,13).items() if i<nh and j>=nh}
    return {'N':N,'R':R,'Om':Om,'MC':MC,'J':J,'K':K,'beta':[beta]},n,ns,nh

def raw_parts(p,n,ns,nh,h,k,ix):
    dims={'B':n,'L':n,'s':ns,'C':n,'a':n};offset={};at=0
    for sec in ['B','L','s','C','a']:offset[sec]=at;at+=dims[sec]
    maps=color_blocks(p,h,k,0,n,nh);N=p['N'];RR=p['R'];Omg=p['Om'];gs={1:h,2:k}
    RX={(a,j):v for a,R in enumerate(RR) for (j,i),v in R.items() if i==ix}
    maps['VX|x']={('B','s'):scale(multiply(Omg,RX),-I),('L','s'):scale(RX,-I),('s','B'):scale(transpose(RX),I)}
    maps['M0|x']={('s','C'):transpose(RX)}
    maps['VGF|n']={('B','s'):scale(N,constant(-1)),('s','L'):transpose(N)}
    maps['HU1|n']={('B','s'):multiply(Omg,N),('L','s'):scale(N,constant(2)),('s','B'):scale(transpose(N),constant(-2)),('s','L'):multiply(transpose(N),Omg)}
    maps['MU1|n']={('a','s'):scale(N,2*I)}
    F=[]
    for ghost in range(n):F.append({} if ghost<nh else scale(multiply(N,RR[ghost]),I))
    M={(a,c):v for c,Fc in enumerate(F) for (a,j),v in Fc.items() if j==ix}
    maps['VGF|nx']={('C','C'):M,('a','a'):transpose(M)}
    for slot,g in gs.items():
        maps['VGF|nC@'+str(slot)]={('C','s'):F[g],('s','a'):scale(transpose(F[g]),constant(-1))}
        maps['M0|C@'+str(slot)]['s','s']=RR[g]
    out={}
    for label,parts in maps.items():
        z={}
        for (row,col),M in parts.items():
            for (i,j),v in M.items():put(z,(offset[row]+i,offset[col]+j),v)
        out[label]=clean(z)
    return out,offset['C'],at

rows=[];path_comparisons=0;word_comparisons=0;sensitive=Counter()
for seed in [0,3]:
    p,n,ns,nh=fixture(seed)
    for h,k in [(0,1),(1,0),(1,2),(2,1),(0,0)]:
        weights,terms=cut_weights(p,h,k,0,info,words,n,nh,True)
        for ix in range(ns):
            raw,nb,dim=raw_parts(p,n,ns,nh,h,k,ix);word_values=[];cache={}
            for wi,word in enumerate(words):
                labels=word['word']+[word['root']];M=identity(dim)
                for label in labels:M=multiply(M,raw.get(label,{}))
                masks=[(info['vertices'].get(label) or info['roots'][label])['mask'] for label in labels]
                exact=exterior_sign(masks)*sum((v*(-1 if i>=nb else 1) for (i,j),v in M.items() if i==j),ZERO)
                value=sum((component_contract(p,{t['prefix']:t['W']},h,k,ix,'primary',cache) for t in terms if t['word']==wi),ZERO)
                assert value==exact,('FIXTURE_WORD',seed,h,k,ix,wi,str(value),str(exact))
                word_comparisons+=1;word_values.append(exact)
            byfam={fam:component_contract(p,z,h,k,ix,'primary',cache) for fam,z in weights.items()}
            replay={fam:component_contract(p,z,h,k,ix,'replay') for fam,z in weights.items()}
            assert byfam==replay and sum(byfam.values(),ZERO)==sum(word_values,ZERO)
            # Direct full tagged powers are independent of the word/cut enumeration.
            V={};roots={}
            for label,M in raw.items():
                it=info['vertices'].get(label,info['roots'].get(label))
                if not it:continue
                dest=roots if label in info['roots'] else V
                for ij,v in M.items():
                    z=dest.setdefault(ij,{}) if dest is V else None
                    if dest is V:z[it['mask']]=z.get(it['mask'],ZERO)+v
                if dest is roots:roots[label]=M
            X={ij:{mask:v for mask,v in poly.items() if v} for ij,poly in V.items() if any(poly.values())}
            power={(i,i):{0:constant(1)} for i in range(dim)}
            for a in range(4):power=pmul(power,X)
            full=ZERO;bad_no_super=ZERO
            for label,M in roots.items():
                z=pmul(power,lifted(M,info['roots'][label]['mask']))
                full+=sum((poly.get(TARGET,ZERO)*(-1 if i>=nb else 1) for (i,j),poly in z.items() if i==j),ZERO)
                bad_no_super+=sum((poly.get(TARGET,ZERO) for (i,j),poly in z.items() if i==j),ZERO)
            assert full==sum(word_values,ZERO),('FULL_FIXTURE_POWER',seed,h,k,ix,str(full),str(sum(word_values,ZERO)))
            sensitive['omitted_supertrace_sign']+=full!=bad_no_super
            for fam,v in byfam.items():sensitive['omitted_'+fam]+=bool(v)
            rows.append({'seed':seed,'ghosts':[h,k],'scalar':ix,'nonzero':bool(full),'family_nonzeros':{f:bool(v) for f,v in byfam.items()}})
        path_comparisons+=len(terms)*ns
    print('STAGE rectangular_fixture '+str(seed),flush=True)
assert sensitive['omitted_supertrace_sign'] and all(sensitive['omitted_'+fam] for fam in FAMILIES)
out={'schema':'UFR2_RECTANGULAR_SCALAR_CUT_FIXTURES','canonical_ordered_words':len(canonical_words),'coarse_ordered_words':len(words),'fixture_contexts':len(rows),'word_comparisons':word_comparisons,'path_terms_evaluated':path_comparisons,'sourceCJ_recomputed':False,'independent_tagged_fourth_power':True,'distinct_associations_equal':True,'sensitive_controls':dict(sensitive),'rows':rows,'guard_denials':denied,'whole_actual_tensor_claim':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'cut_fixture_result_v2.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({k:v for k,v in out.items() if k!='rows'},sort_keys=True),flush=True);timer.cancel()
