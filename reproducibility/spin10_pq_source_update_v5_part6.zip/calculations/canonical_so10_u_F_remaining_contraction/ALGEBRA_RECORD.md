# UFR1B scalar/ghost algebra closure from actual tree inputs

UFR1 gives S=2iN,Hn_Bs=-iS,Hn_Ls=-i Omega S/2;
HC_aB=iK,HC_aL=-i K Omega/2;F_h=i(N R_h+D_h^t N).
These identities were checked on every actual entry,not fitted to a
quantum remainder. The other transpose blocks and GF_nC/GF_nx mixed
derivatives also agree. Use them only after whole-tree validation.

Now test all K_h against actual J_Lambda,h,retaining every unmatched
entry and ratio class. Test F_H=0 and the corresponding unbroken
intertwining N R_h=-D_h^t N. Test the FULL actual representation identity
[R_h,R_k]=sum_c A_h[c,k] R_c,where A_h is the vector tangent,for all
ordered h,k (including diagonals). The sign is predicted by the fixed
right-field/ghost convention,not chosen from a loop cancellation.

These polynomial identities may reduce triple scalar-generator chains
without commuting them or dividing by g10. A failure means the proposed
relation is not available; preserve it rather than replacing it with a
favorable sign. Native300s,8GiB/350MiB/32MiB unchanged. No quantum target
or authority/physical scheme change.
