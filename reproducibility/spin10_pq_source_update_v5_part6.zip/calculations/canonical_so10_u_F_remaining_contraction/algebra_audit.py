from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import Counter
import json,gzip,time,threading,os
import sympy as s
from recover import *
from coefficient_ring import expression
O=Path(__file__).resolve().parent;tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,hsh in json.loads((O/'algebra_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==hsh,path
p=recover('primary');ratios=Counter();unmatched=[]
@lru_cache(None)
def ratio(a,b):return str(s.cancel(expression(a.terms)/expression(b.terms)))
for h in range(45):
    K,JL=p['K'][h],p['J'][h][1]
    for key in K.keys()|JL.keys():
        a,b=K.get(key,ZERO),JL.get(key,ZERO)
        if b:ratios[ratio(a,b)]+=1
        elif a:unmatched.append([h,*key,str(a)])
Hchecks=[]
for h in range(12):
    nr=multiply(p['N'],p['R'][h]);dn=multiply(transpose(p['MC'][h]['a']),p['N'])
    assert not p['F'][h] and not plus(nr,dn)
    Hchecks.append({'ghost':h,'NR_nonzeros':len(nr),'intertwining_verified':True})
for h in range(12,45):assert p['F'][h]==scale(multiply(p['N'],p['R'][h]),I)
commutator_rows=[];checked=0
for h in range(45):
    AH=p['MC'][h]['B']
    for k in range(45):
        direct=plus(multiply(p['R'][h],p['R'][k]),scale(multiply(p['R'][k],p['R'][h]),constant(-1)))
        expected={}
        for (c,kk),v in AH.items():
            if kk!=k:continue
            for ij,w in p['R'][c].items():expected[ij]=expected.get(ij,ZERO)+times(v,w)
        expected=clean(expected)
        assert direct==expected,('SCALAR_COMMUTATOR',h,k)
        commutator_rows.append([h,k,len(direct)]);checked+=1
    if h%9==8:print('STAGE scalar_Lie_row '+str(h),flush=True)
out={'schema':'UFR1B_COMPLETE_TREE_ALGEBRA','K_vs_JL_ratios':dict(ratios),'K_entries_without_JL':unmatched,'unbroken_intertwining':Hchecks,
     'F_broken_equals_iNR':True,'commutators_checked':checked,'commutator_nonzero_entry_counts':commutator_rows,
     'known_quantum_remainder_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'algebra_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({key:v for key,v in out.items() if key not in ['commutator_nonzero_entry_counts','unbroken_intertwining']},sort_keys=True),flush=True);timer.cancel()
