# UFR4 review and late interpretation, prospective

Only after both complete tensors finish, compare all five family arrays,
their sum and complete zero domains. Authenticate all prior preparations,
failed source copies, classical/type audits, fixture and action checks.
Verify Hu_n+Mu_n at the array level without deleting either family.
Omission controls must retain their actual sensitive/insensitive scopes.

Then read the separately qualified UFS source-CJ arrays, authenticate
their receipt, and assemble exactly once with the five-family total.
Only after that agreement may review read UPM's full log5 F conversion
array. Compute conversion PLUS complete C4 cutoff for both probes,
retaining every remainder. Do not assert cancellation in the worker or
derive a missing coefficient from the target. Inherited complete C5_F=0
makes C4 the log5 cutoff within the original formal heat conventions.

This tests the full finite coefficient domain for this ONE prime-log
basis, not every finite basis, a common continuum trace/product limit,
full contact/QAP/measure construction or physical viability. Keep b0,
kappa,chi4 and IR freedoms distinct and unfixed. Project authority is
unchanged, regardless of whether the late sum vanishes. Review180s,
sampled8GiB,350MiB launchfloor,32MiB packet; exact failures preserved.
