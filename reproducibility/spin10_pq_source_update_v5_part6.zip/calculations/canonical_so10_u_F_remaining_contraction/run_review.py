from pathlib import Path
from hashlib import sha256
import ast,json,gzip,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-F-remaining-contraction-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings={}
    for prep in O.glob('*preparation*.json'):
        for pp,h in json.loads(prep.read_bytes())['input_sha256'].items():
            assert H(Path(pp))==h,pp
            if pp in bindings:assert bindings[pp]==h
            bindings[pp]=h
    for role in ['primary','replay']:
        z=json.loads((O/(role+'_tensor_capture.json')).read_bytes())
        assert z['exit_code']==0 and z['calculation_completed'] and z['post_run_observations_qualified']
    a=json.loads(gzip.decompress((O/'primary_tensor.json.gz').read_bytes()));b=json.loads(gzip.decompress((O/'replay_tensor.json.gz').read_bytes()))
    assert a['families']==b['families'] and a['total']==b['total']
    for name in ['review.py','run_review.py','REVIEW_RECORD.md']:
        pp=O/name
        if pp.suffix=='.py':ast.parse(pp.read_bytes())
        with (O/(name+'.source.txt')).open('xb') as f:f.write(pp.read_bytes())
    for pp in O.iterdir():
        if pp.is_file():bindings[str(pp)]=H(pp)
    for rel in ['calculations/canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz','calculations/canonical_so10_u_pair_contact_model/lowering_validation_receipt.json','calculations/canonical_so10_u_F_maximal_cutoff/final_review_validation_receipt.json']:
        pp=R/rel;bindings[str(pp)]=H(pp)
    dump(O/'review_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    z=capture([sys.executable,'-B',str(O/'review.py')]);dump(O/'review_capture.json',z);dump(C/'review_full_capture.json',z)
    assert z['exit_code']==0 and z['calculation_completed'] and z['post_run_observations_qualified']
    assert json.loads((O/'review_result.json').read_bytes())['elapsed_after_imports']<180
    print('COMPLETED UFR4 review',flush=True)
except BaseException:
    dump(O/'review_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False})
    raise
