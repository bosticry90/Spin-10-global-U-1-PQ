# Preserved UFR2 fixture-domain failure and bounded continuation

cut_capture.json records a failed FULL_FIXTURE_POWER comparison for
seed0, ghost slots (broken,H), scalar0. Every individual compiled word
comparison before it passed. The proposed fixture used the 51-word union
proved only for canonical h<k: HH,HB,BB. Reversing an HB pair requires
the BH candidate words too. Their omission invalidated that fixture's
claim of complete full-power coverage; it is not a model refutation.

Keep the failed sources, preparation and complete capture unchanged.
V2 tests the larger coarse inventory for all five merged families,
including both HB and BH slot assignments. It continues to compare
individual uncut words, both scalar associations and the full tagged
power. The actual canonical-domain formula still uses the qualified
51-word reduction. No mathematical requirement or physical input changes.
Same prospective resource and authority ceilings; new exclusive files.
