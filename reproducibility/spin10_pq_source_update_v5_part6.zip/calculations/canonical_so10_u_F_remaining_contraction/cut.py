"""Complete scalar cuts of the remaining C4 words; no result files read."""
from recover import *
from support import exterior_sign

FAMILIES=('GF_nC','GF_nx','Hu_n','Hu_C','Mu_n')

def remaining_words(inventory,refined):
    info=inventory['probes'][1]
    keep={(z['root'],tuple(z['word'])) for c in refined['cases'] if c['probe']==1 for z in c['words']}
    out=[]
    for z in info['words']:
        if (z['root'],tuple(z['word'])) not in keep:continue
        items=[info['vertices'][k] for k in z['word']]+[info['roots'][z['root']]]
        merged=[it for it in items if it['mask'].bit_count()-int(it['name'].startswith('M'))==2]
        assert len(merged)==1
        it=merged[0]
        fam='sourceCJ' if it['name']=='VS' else ('GF_' if it['name']=='VGF' else 'Hu_' if it['name']=='HU1' else 'Mu_')+it['pattern']
        if fam=='sourceCJ':continue
        assert fam in FAMILIES,fam
        out.append({**z,'family':fam})
    assert len(out)==51
    return info,out

def color_blocks(p,h,k,r,n=45,nh=12):
    E=identity(n);P={(a,a):constant(1) for a in range(nh,n)};Om=p['Om'];beta=p['beta'][r]
    z={};Js=[]
    for slot,ghost in [(1,h),(2,k)]:
        JB,JL=p['J'][ghost];K=p['K'][ghost];MC=p['MC'][ghost]
        z['VGF|C@'+str(slot)]={('B','a'):plus(multiply(Om,transpose(JB)),transpose(JL)),('L','a'):transpose(JB),('C','B'):JB,('C','L'):JL}
        z['HU1|C@'+str(slot)]={('B','a'):scale(multiply(Om,transpose(K)),I*constant(Fraction(1,2))),('L','a'):scale(transpose(K),I),('C','B'):scale(K,I),('C','L'):scale(multiply(K,Om),-I*constant(Fraction(1,2)))}
        z['M0|C@'+str(slot)]={(a,a):MC[a] for a in ['B','L','C','a']}
    z['VS|J']={('B','C'):scale(transpose(beta),constant(-1)),('a','L'):beta}
    z['HU1|']={('B','B'):scale(multiply(Om,P),constant(-1)),('B','L'):scale(multiply(multiply(Om,Om),P),constant(Fraction(1,2))),('L','B'):scale(P,constant(-2)),('L','L'):multiply(Om,P)}
    z['MU1|']={('a','B'):scale(P,-2*I),('a','L'):scale(multiply(Om,P),I)}
    return z

def cut_weights(p,h,k,r,info,words,n=45,nh=12,details=False):
    E=identity(n);P={(a,a):constant(1) for a in range(nh,n)};Om=p['Om'];blocks=color_blocks(p,h,k,r,n,nh)
    totals={fam:{} for fam in FAMILIES};terms=[];ghost={1:h,2:k}
    def item(label):return info['vertices'].get(label,info['roots'].get(label))
    def endpoint(label,row,col):
        it=item(label);name,pat=it['name'],it['pattern'];pref=()
        if name=='VX':return (scale(E,I) if row=='s' else scale(Om,-I) if row=='B' else scale(E,-I)),pref
        if name=='M0' and pat=='x':return E,pref
        if name=='VGF' and pat=='n':return (scale(E,constant(-1)) if row=='B' else E),pref
        if name=='VGF' and pat=='nC':
            g=ghost[it['slot']]
            if g<nh:return {},()
            return scale(E,I if col=='s' else -I),(it['slot'],)
        if name=='HU1' and pat=='n':
            return (Om if (row,col) in [('B','s'),('s','L')] else scale(E,constant(2) if row=='L' else constant(-2))),pref
        if name=='MU1' and pat=='n':return scale(E,2*I),pref
        raise AssertionError(('UNKNOWN_ENDPOINT',label,row,col))
    for word_index,z in enumerate(words):
        labels=z['word']+[z['root']];items=list(map(item,labels));sg_ext=exterior_sign([it['mask'] for it in items]);fam=z['family']
        for path_index,path in enumerate(z['paths']):
            sg=sg_ext*(-1 if path[0] in ['C','a'] else 1)
            mass=[at for at,it in enumerate(items) if it['name']=='VGF' and it['pattern']=='nx']
            if mass:
                assert len(mass)==1 and 's' not in path
                at=mass[0];M=E
                for j in [(at+i)%5 for i in range(1,5)]:M=multiply(M,blocks.get(labels[j],{}).get((path[j],path[j+1]),{}))
                assert path[at]==path[at+1] and path[at] in ['C','a']
                W=transpose(M) if path[at]=='C' else M
                W=scale(multiply(W,P),I*sg);pref=()
            else:
                starts=[a for a in range(5) if path[a]=='s' and path[a+1]!='s'];ends=[a for a in range(5) if path[a]!='s' and path[a+1]=='s']
                assert len(starts)==len(ends)==1,(labels,path)
                first,last=starts[0],ends[0];B,pref1=endpoint(labels[first],path[first],path[first+1]);A,pref2=endpoint(labels[last],path[last],path[last+1])
                scalar=[];j=(last+1)%5
                while j!=first:
                    assert path[j]==path[j+1]=='s' and items[j]['name']=='M0' and items[j]['pattern']=='C'
                    scalar.append(items[j]['slot']);j=(j+1)%5
                assert len(scalar)<=1
                M=B;j=(first+1)%5
                while j!=last:
                    M=multiply(M,blocks.get(labels[j],{}).get((path[j],path[j+1]),{}));j=(j+1)%5
                M=multiply(M,A)
                if 'x' in items[first]['pattern']:
                    assert not pref1;W=transpose(M);pref=pref2+tuple(scalar)
                else:
                    assert 'x' in items[last]['pattern'] and not pref2
                    W=M;pref=pref1+tuple(scalar);sg*=(-1)**len(scalar)
                W=scale(W,constant(sg))
            old=totals[fam].get(pref,{})
            totals[fam][pref]=plus(old,W)
            if details:terms.append({'word':word_index,'path':path_index,'prefix':pref,'W':W})
    totals={fam:{pref:M for pref,M in by.items() if M} for fam,by in totals.items()}
    return (totals,terms) if details else totals

def scalar_contract(N,RR,weights,h,k,role='primary'):
    out={};gs={1:h,2:k}
    for pref,W in weights.items():
        if role=='primary':
            B=N
            for slot in pref:B=multiply(B,RR[gs[slot]])
            products={a:multiply(B,RR[a]) for a in {a for b,a in W}}
            for (b,a),v in W.items():
                for (bb,i),w in products[a].items():
                    if b==bb:put(out,(i,),times(v,w))
        else:
            # Contract color rows into N first, then apply the ordered scalar chain.
            for a in {a for b,a in W}:
                B=multiply({(0,b):v for (b,aa),v in W.items() if aa==a},N)
                for slot in pref:B=multiply(B,RR[gs[slot]])
                B=multiply(B,RR[a])
                for (zero,i),v in B.items():put(out,(i,),v)
    return clean(out)

def component_contract(p,weights,h,k,ix,role='primary',cache=None):
    cache={} if cache is None else cache;gs={1:h,2:k};answer=ZERO
    for pref,W in weights.items():
        if role=='primary':
            if pref not in cache:
                B=p['N']
                for slot in pref:B=multiply(B,p['R'][gs[slot]])
                cache[pref]=B
            B=cache[pref]
            columns=cache.setdefault('columns',{})
            for (b,a),v in W.items():
                key=(pref,b,a,ix)
                if key not in columns:
                    columns[key]=sum((times(w,p['R'][a].get((j,ix),ZERO)) for (bb,j),w in B.items() if bb==b),ZERO)
                answer+=times(v,columns[key])
        else:
            for a in {a for b,a in W}:
                B=multiply({(0,b):v for (b,aa),v in W.items() if aa==a},p['N'])
                for slot in pref:B=multiply(B,p['R'][gs[slot]])
                answer+=sum((times(w,p['R'][a].get((j,ix),ZERO)) for (zero,j),w in B.items()),ZERO)
    return answer
