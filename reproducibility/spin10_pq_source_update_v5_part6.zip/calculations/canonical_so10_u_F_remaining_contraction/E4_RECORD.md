# Final bounded checkpoint audits

Run the delegated `python -B tools/research_check.py e4` exactly once,
without --fresh, after completed UFR review and before local commit.
Freeze its command/source/authority hashes in the external runner before
launch. Capture complete stdout/stderr and actual native exit. Expected
step exits0,0,0,0,0,2 and terminalCOMPLETED authenticate the existing
sealed checkpoint and current authority/structure/read-only/custody
checks. Custodyexit2/seven unresolved is not PASS. It is not a new
global scientific replay or acceptance. Runner bound300s; preserve any
failure/incomplete capture and do not automatically rerun.
