# UFR2: complete scalar-cut compiler, before execution

Use the authenticated UFR1/UFR1B classical identities, including K=2i JL,
F_H=0, F_b=i N R_b, and all 2025 ordered Lie commutators. These are
input identities, not fitted quantum coefficients. Compile every broad
sector path of the 51-word union left by UFS's complete refined support.
The six source-CJ words remain owned by UFS and are not recomputed here.

Every remaining path has either one connected scalar segment or the
GF_nx explicit scalar mass index. Cut that segment as an ordinary indexed
trace, retaining the ORIGINAL starting-sector supertrace sign and literal
exterior order. Do not invoke graded cyclicity to change either sign.
An M0_C scalar root remains an ordered generator (transposed on the
opposite orientation); do not commute it through another generator.

The result is a color weight W[b,a] times (N R_prefix R_a)[b,i], with
zero, one or two prefix generators. Internal a ranges over all45 unless
the explicit GF_nx/F_b support proves its broken projection. Source and
ghost labels, five disjoint merged families and zero paths remain explicit.

Test all compiled paths against uncut indexed matrix products on small
noncommuting rectangular fixtures, with both ghost-slot orders and all
scalar components. Then test actual action coefficients against newly
constructed original operator words/full tagged powers at both momentum
axes/signs. These tests must precede whole-tensor extraction. A failed
fixture or action comparison is preserved; no target fitting or promotion.
No claim of full tensor extraction from these tests alone.

Native300s/review180s after imports, sampled8GiB,350MiB launchfloor,
32MiB packet. Freeze sources and bindings before each owned worker.
Same authority ceiling and limits as RECORD; known quantum target and
peer outputs remain excluded from native work. This is a compact formula
and verification step, not a continuum/QAP/physical consistency theorem.
