# Next bounded reduction: lower-edge finite cutoff support

Proposal,not executed lower-edge coefficient evidence. Full F5 is zero;
full F C4 and exact-once source-CJ now close the log5 conversion-plus-
cutoff test. The analogous T log5 test was qualified earlier. Reuse
those owning arrays and proofs, rather than repeat them for confidence.

The next least expensive competent step is a fresh support/degree
classification for the lower-edge original T/F cutoff, then its exact
finite-basis map. UMH's local positive-heat radial difference is
log((n+1)/n) in the common normalization. Derive the relevant lower-n
combinations from the actual prescribed expression and free endpoints;
do not assume that a higher-order result already fixes chi4/log2/log3.

The crucial new issue is admissible operator grade, not integral precision.
At four vertices plus root the six positive target grades forced one
grade-two object. Fewer vertices can admit higher-grade Hessian/tangent
pieces and source2 roots previously excluded ONLY at maximal heat order.
Return to original full action/source Euler derivatives before setting
sources to zero. The UFS grade1/2 tables are not a complete lower-order
operator domain merely because they suffice for C4.

Freeze the new domain, source/ghost/scalar/derivative types, immutable
inputs and resource limits. Enumerate complete retained classes and
structural zeroes with independent tagged-power/Boolean checks. First
seek a common ordered contraction with scalar/color cuts, retaining
all mixed auxiliary/ghost blocks and source-Euler-before-restriction.
Only then compute the smallest complete required finite basis, with
independent associations and late full conversion comparison.

No unknown contact or normalization is chosen to close a remainder.
No transfer to changed parameters, scheme, vacuum or physical domain.
If a source/root/operator assumption is missing, preserve underdefinition.
No large old primitive catalogue or protected HB1/C5 activation follows
from the present trace-edge labels. E5/A5,continuum/QAP/measure and
physical viability remain separate; authority and all freedoms unchanged.
