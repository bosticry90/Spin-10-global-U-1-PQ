# Complete F log(5) conversion-plus-cutoff cancellation in the fixed reference

The five remaining nonlinear C4 families are now computed across the
complete declared coefficient domain by two contraction orders. After
adding the separately qualified source-CJ family exactly once, the full
log(5) cutoff cancels the earlier conversion tensor in both probes.
This is a bounded formal-symbol result, not full finite restoration,
QAP,E5/A5 or physical validation.

[Proof](PROOF.md), [complete review](review_result.json),
[exact complete cutoff](complete_cutoff.json.gz),
[all late remainders](late_remainders.json.gz). The final validation
receipt separately records provenance, execution and evidence validation;
scientific acceptance remains reserved to the director.

## Calculation and verified coverage

Original unshifted SMA/CSW/EDS,A0,constant u,intrinsic1,external jets0
AFTER differentiation,symbolic g10/xi/eta_H,common hbar/(16pi^2),
nonexceptional Euclidean LOCAL RELATIVE positive-heat UV symbol.
No action, benchmark, subtraction scheme or normalization was changed.

The action blocks satisfy S=2iN,K=2iJ_L and
F_h=i(N R_h+MC_a,h^T N) on every entry and zero complement.
For broken h this is iNR_h; for unbroken h,F_h=0 by its complete
intertwining identity. All2025 scalar-generator commutators agree.
These are classical input identities, not fitted quantum coefficients.

The scalar-cut compiler covers all51 remaining canonical ordered words.
Its rectangular noncommuting fixtures cover the larger110-word coarse
domain,4400 word comparisons,7200 path evaluations and40 full tagged
powers. Every family-omission and missing-supertrace-sign control is
sensitive in declared fixture contexts. Ten actual action contexts per
route compare all51 words and complete tagged powers at axis3/q+ versus
axis2/q-. Their evaluated typed color-weight arrays also agree in full,
including zero complements. These calibrations supplement the full
classical type audit and symbolic reduction; they do not replace it.

Free noncommuting H/broken block reduction proves the complete HH class
zero, family by family. HB has two total formal weight words; BB has ten.
All two-generator scalar prefixes cancel in the color reduction. This
is a structural proof, not extrapolation from a few zero components.
Internal scalar-generator color still ranges over all45.

Primary precontracts N R_prefix R_a. Replay contracts W into N first,
then applies the ordered scalar generators, and reassociates the color
products in the opposite direction. Both traverse all31680 active-source/
ghost pairs; inactive sources0..12 and probe0 have inherited complete
support proofs. Full arrays, their sums and every implicit zero agree.

| Probe1 residual family | Nonzero positions | Zero complement |
| --- | ---: | ---: |
| GF_nC | 227,800 | 14,384,600 |
| GF_nx | 201,368 | 14,411,032 |
| Hu_C | 136,660 | 14,475,740 |
| Hu_n | 216,672 | 14,395,728 |
| Mu_n | 216,672 | 14,395,728 |
| Five-family sum | 201,920 | 14,410,480 |

Hu_n and Mu_n cancel as entire arrays; both remain stored. Family counts
overlap and are not independent amplitudes, particles, experiments or
completion percentages. The nonzero families supply sensitive full-array
omission controls; omission of both opposite families together would be
insensitive and is not credited as a detector.

## Exact-once assembly and late comparison

Only after complete native agreement does review reuse UFS's authenticated
85,112-position source-CJ tensor. It is added ONCE to the five-family sum.
Inherited complete C5_F=0 then identifies C4 as the complete log(5)
cutoff within the original heat conventions.

| Probe | Domain positions | Conversion nonzero | Complete cutoff nonzero | Conversion PLUS cutoff nonzero |
| --- | ---: | ---: | ---: | ---: |
| 0 | 14,612,400 | 0 | 0 | 0 |
| 1 | 14,612,400 | 197,652 | 197,652 | 0 |

Native guards deny the old target, prior selected values, source-CJ output
and peer tensors, with four positive denial controls per native. The old
conversion table is first opened for interpretation after full agreement
and exact-once source assembly. No missing coefficient or finite constant
was solved from the desired cancellation. Complete cutoff and remainder
files retain the result, including empty remainder arrays explicitly.

## Focused result-to-claim assessment

**Evidence and supported claim.** The complete remaining nonlinear C4
tensor is derived from action-based blocks and agrees by distinct
associations. With the inherited source-CJ and C5 proofs, it closes the
full F log(5) conversion-plus-cutoff test in the stated formal reference.
All classical identities, zero sectors, native tables and late comparison
have owning evidence. UFS/F5/source-CJ are authenticated reuse; current
block audits, contractions and review are new execution.

**Missing bridge and alternatives.** This is one prime-log coefficient,
not a complete renormalized identity. chi4/log(2)/log(3), common continuum
trace/variation/product/contact limits, measure,QAP,chiral/global phase,
source reality,causal/massive and physical limits remain separate. A
relative local cancellation can hold while any of these bridges fails.
b0,kappa,chi4 and infrared freedoms remain distinct and unfixed. Lower
edge orders may admit higher-grade vertices/source2 roots excluded only
at maximal order; the current operator truncation cannot be transferred
to them without a fresh support proof.

**Significance and authority.** The evidence removes the full F log(5)
coefficient gap rather than adding another selected witness. It
demonstrates compact exact noncommuting reduction and complete tensor
reproduction, with preserved failures. Shared action,reference,charts,
curated data,ring,formula,software and AI author limit independence.
No proof assistant, external scientist or empirical validation is claimed.
Authority stays34/39,state113,E5/A5 OPEN; custody remains exit2/seven
unresolved. Investigation completion and physical viability remain open.

**Next discriminating action.** Derive the lower-edge support and heat
basis map from the actual original cutoff construction, including source2
roots and higher-grade Hessians where they can now contribute. Use that
to select a complete next finite coefficient class before extracting
another large array. Reuse the qualified F5,C4 and source-CJ evidence;
do not recalculate it or fit remaining contact freedoms. See
[next bounded reduction](NEXT_REDUCTION.md).

## Preserved failures, resources and checks omitted

The first tree controller failed before worker launch because Python3.10
rejects a bare starred tuple subscript. Original sources and traceback
remain unchanged; V2 parenthesizes the keys. The first fixture failed
after reversing HB to BH while still using a word list qualified only
for canonical HH/HB/BB. Its complete capture and source are preserved.
V2 expands fixture coverage to all110 coarse words, retaining reverse
orders and the same full-power requirements. Neither original failure
is relabeled PASS or treated as a physical-model refutation.

Native tensor coefficient stages took83.7785/185.4537s after imports;
review34.3637s. The actual worker timer also covers serialization.
Maximum successful sampled private allocation is2,601,013,248B, not
a continuous peak. Frozen native300s/review180s,8GiB sampled,350MiB
launchfloor and32MiB packet limits were observed. Exact owned PID/
creation records, complete stdout and all samples are preserved.

No global old calculation replay, continuum proof, full finite-basis
assessment or physical fit was performed. E4's bounded authentication/
authority/structure/custody audits are recorded separately before local
commit; expected custodyexit2 is never called PASS. No protected
activation,promotion,branch/worktree,remote push,publication or outreach.
