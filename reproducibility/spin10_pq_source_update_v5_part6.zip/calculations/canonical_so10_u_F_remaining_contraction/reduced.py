"""Evaluation of authenticated noncommuting weights in actual color matrices."""
from cut import *
from functools import lru_cache

def actual_state(p):
    Ts=[]
    for h in range(45):
        A=p['MC'][h]['B'];assert all(k[0]>=1 for c in A.values() for k,v in c.terms)
        T={ij:Coeff([(tuple([key[0]-1,*key[1:]]),v) for key,v in c.terms]) for ij,c in A.items()}
        Ts.append({'HH_skew':{ij:v for ij,v in T.items() if ij[0]<12 and ij[1]<12},'BB_skew':{ij:v for ij,v in T.items() if ij[0]>=12 and ij[1]>=12},'HB':{ij:v for ij,v in T.items() if ij[0]<12<=ij[1]}})
    return Ts

def evaluator(p,rows,role='primary'):
    Ts=actual_state(p);typed={tuple(z['ghost_types']):z for z in rows}
    def for_source(r):
        @lru_cache(None)
        def atom(name,at):
            h,block=name;M=p['beta'][r] if h==-1 else Ts[h][block]
            return transpose(M) if at else M
        @lru_cache(None)
        def product(word):
            if not word:return identity(45)
            if len(word)==1:return atom(*word[0])
            if role=='primary':return multiply(product(word[:-1]),atom(*word[-1]))
            return multiply(atom(*word[0]),product(word[1:]))
        def weights(h,k):
            ty=('H' if h<12 else 'B','H' if k<12 else 'B');row=typed[ty];answer={}
            for fam,by in row['families'].items():
                dest={}
                for pref,encoded in by:
                    W={}
                    for blockrow,blockcol,terms in encoded:
                        for word,coeff in terms:
                            key=tuple(((-1,'beta') if name=='beta' else (h if name.startswith('T1') else k,name[2:]),at) for name,at in word)
                            c=cf(coeff)
                            for ij,v in product(key).items():put(W,ij,times(c,v))
                    W=clean(W)
                    if W:dest[tuple(pref)]=W
                answer[fam]=dest
            return answer
        return weights
    return for_source

def tensor_contractor(p,role):
    cache={}
    if role=='primary':
        def image(weights,h,k):
            out={}
            for pref,W in weights.items():
                actual=tuple(h if slot==1 else k for slot in pref)
                if actual not in cache:
                    B=p['N']
                    for g in actual:B=multiply(B,p['R'][g])
                    rows=[]
                    for Ra in p['R']:
                        z=defaultdict(list)
                        for (b,i),v in multiply(B,Ra).items():z[b].append((i,v))
                        rows.append(z)
                    cache[actual]=rows
                for (b,a),v in W.items():
                    for i,w in cache[actual][a].get(b,[]):put(out,(i,),times(v,w))
            return clean(out)
    else:
        nrows=defaultdict(list)
        for (b,j),v in p['N'].items():nrows[b].append((j,v))
        def image(weights,h,k):
            out={}
            for pref,W in weights.items():
                wn={}
                for (b,a),v in W.items():
                    for j,w in nrows.get(b,[]):put(wn,(a,j),times(v,w))
                wn=clean(wn)
                for slot in pref:wn=multiply(wn,p['R'][h if slot==1 else k])
                arows=defaultdict(dict)
                for (a,j),v in wn.items():arows[a][0,j]=v
                for a,row in arows.items():
                    for (_,i),v in multiply(row,p['R'][a]).items():put(out,(i,),v)
            return clean(out)
    return image
