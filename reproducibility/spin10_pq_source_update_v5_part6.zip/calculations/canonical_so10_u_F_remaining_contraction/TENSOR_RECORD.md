# UFR3 whole residual tensor, prospective

UFR2B reduced all51 ordered canonical words using free noncommuting
rectangular color types and an all45-generator actual input audit.
All five HH weights vanish exactly. HB has two total weight words;
BB has ten, with only zero/one scalar prefix after exact cancellation.
Hu_n and Mu_n have opposite formal weights, retained as distinct families.
These are structural algebra results, not selected numerical extrapolation.

First compare evaluated typed color weights, family by family, to the
uncut compiler on the ten actual calibration contexts. Then compute all
five complete tensors in the 45*990*328 domain, with source0..12 and HH
zeroes established by their separate complete support/type proofs. Run
each native association separately, excluding peer, selected and old
quantum target reads. Primary precontracts N R_h R_a; replay contracts
the color weights into N first and retains ordered scalar generators.
Keep internal a all45. No finite constants or parameters are fitted.

Store each disjoint family, their total and exact zero complements.
Compare complete primary/replay arrays only after both finish. Then,
under a separate review, add the authenticated UFS source-CJ array ONCE
and open the old conversion array only for the final comparison. No
whole cancellation is assumed or encoded as an expected tensor value.

Native300s/review180s after imports,8GiB sampled,350MiB launchfloor,
32MiB packet. Resource exhaustion remains incomplete. Same formal
Euclidean local relative UV domain, scientific ceiling and independent
normalization freedoms as RECORD. This does not close full finite
restoration, continuum product/trace/QAP/measure or physical viability.
