from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os,sys
from recover import *
O=Path(__file__).resolve().parent;U=O.parent/'canonical_so10_u_F_fourth_support';R=O.parents[1]
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()))
for pp,hsh in read(O/'review_preparation.json')['input_sha256'].items():assert sha256(Path(pp).read_bytes()).hexdigest()==hsh,pp
a=loadz(O/'primary_tensor.json.gz');b=loadz(O/'replay_tensor.json.gz')
assert a['families']==b['families'] and a['total']==b['total'] and a['guard_denials']==b['guard_denials']==4
assert a['computed_source_ghost_pairs']==b['computed_source_ghost_pairs']==32*990
assert a['domain_per_probe']==b['domain_per_probe']==45*990*328
assert a['HH_zero_by_complete_noncommuting_weights'] and b['HH_zero_by_complete_noncommuting_weights']
assert read(O/'primary_action.json')['rows']==read(O/'replay_action.json')['rows']
fixture=read(O/'cut_fixture_result_v2.json');assert fixture['canonical_ordered_words']==51 and fixture['coarse_ordered_words']==110 and fixture['word_comparisons']==4400
assert all(fixture['sensitive_controls'].values()) and fixture['independent_tagged_fourth_power']
typed=read(O/'typed_result.json');assert len(typed['actual_classical_color_audit'])==45
assert all(z['typed_relations_verified'] for z in typed['actual_classical_color_audit'])
assert typed['rows'][0]['ghost_types']==['H','H'] and typed['rows'][0]['weight_zero'] and all(not z for z in typed['rows'][0]['families'].values())
assert [z['total_formal_word_count'] for z in typed['rows']]==[0,2,10]
alg=read(O/'algebra_result.json');assert alg['commutators_checked']==2025 and alg['F_broken_equals_iNR']
assert alg['K_vs_JL_ratios']=={'2*I':600} and not alg['K_entries_without_JL']

def decode(rows):
    out={}
    for r,h,k,i,terms in rows:
        key=(r,h,k,i);assert key not in out and 0<=r<45 and 0<=h<k<45 and 0<=i<328
        out[key]=cf(terms);assert out[key]
    return out
def enc(M):return [[*key,[[list(z),v.numerator,v.denominator] for z,v in c.terms]] for key,c in sorted(M.items())]
domain=45*990*328;fams={fam:decode(rows) for fam,rows in a['families'].items()};total=decode(a['total']);summed={}
for fam,M in fams.items():
    assert all(r>=13 and k>=12 for r,h,k,i in M)
    assert len(M)==a['probe1_nonzero_counts'][fam] and domain-len(M)==a['probe1_zero_complements'][fam]
    for key,v in M.items():put(summed,key,v)
assert clean(summed)==total
assert fams['Hu_n']==scale(fams['Mu_n'],constant(-1))
assert len(total)==a['probe1_nonzero_counts']['total'] and domain-len(total)==a['probe1_zero_complements']['total']
print('STAGE full_five_family_arrays_equal',flush=True)

# Reuse, not replay, of the separately qualified source-CJ family.
u=loadz(U/'primary_source_d.json.gz');v=loadz(U/'replay_source_d.json.gz');assert u['results']==v['results']
receipt=read(U/'final_review_validation_receipt.json')
for name in ['primary_source_d.json.gz','replay_source_d.json.gz']:
    rel='calculations/canonical_so10_u_F_fourth_support/'+name
    assert sha256((U/name).read_bytes()).hexdigest()==receipt['new_files_sha256'][rel]
source=[decode(z['total']) for z in u['results']];assert not source[0] and len(source[1])==85112
combined=plus(total,source[1]);complete=[{},combined]
assert set(fams)=={'GF_nC','GF_nx','Hu_n','Hu_C','Mu_n'}
coverage=[]
for probe,M in enumerate(complete):
    visited=sum(328 for r in range(45) for h in range(45) for k in range(h+1,45));assert visited==domain
    coverage.append({'probe':probe,'positions':visited,'complete_cutoff_nonzeros':len(M),'complete_zero_complement':visited-len(M)})
print('STAGE complete_C4_exact_once_assembled',flush=True)

# Late target read occurs only after native equality and exact-once assembly.
old=loadz(R/'calculations/canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz')
late=[];remainders=[]
for probe in range(2):
    row=next(z for z in old['results'][probe]['partial_relations'] if z['basis']=='log5')
    conv={tuple(z[:-1]):co(z[-1]) for z in row['homogeneous_plus_Euler_partial']['F']}
    assert len(conv)==len(row['homogeneous_plus_Euler_partial']['F']) and all(0<=r<45 and 0<=h<k<45 and 0<=i<328 for r,h,k,i in conv)
    rem=plus(complete[probe],conv)
    late.append({'probe':probe,'domain_positions':domain,'conversion_nonzeros':len(conv),'complete_cutoff_nonzeros':len(complete[probe]),'sum_nonzeros':len(rem),'conversion_PLUS_cutoff_zero':not rem})
    remainders.append({'probe':probe,'remainders':enc(rem)})
with (O/'late_remainders.json.gz').open('xb') as f:f.write(gzip.compress((json.dumps(remainders,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
with (O/'complete_cutoff.json.gz').open('xb') as f:f.write(gzip.compress((json.dumps([{'probe':q,'total':enc(M)} for q,M in enumerate(complete)],sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
out={'schema':'UFR4_COMPLETE_F_LOG5_REVIEW','native_families_and_total_equal':True,'probe1_family_nonzero_counts':{fam:len(M) for fam,M in fams.items()},'probe1_five_family_total_nonzeros':len(total),
     'Hu_n_plus_Mu_n_zero_whole_arrays':True,'complete_HH_C4_structural_zero':True,'complete_probe0_and_inactive_source_zeros_inherited':True,'sourceCJ_reused_exactly_once':True,'sourceCJ_nonzeros':[0,len(source[1])],
     'coverage':coverage,'late_comparison':late,'omitted_family_sensitive_positions':{**{fam:len(M) for fam,M in fams.items()},'sourceCJ':len(source[1])},
     'full_F_log5_cutoff_complete_with_inherited_C5_zero':True,'known_quantum_remainder_native_operand':False,'other_finite_bases_continuum_QAP_or_physical_claim':False,'elapsed_after_imports':time.perf_counter()-tick}
assert sum(pp.stat().st_size for pp in O.iterdir() if pp.is_file())<32*1024**2
with (O/'review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
