from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,gzip,time,threading,os,sys
from cut import *
from matrices import propagator,selected_parts,word_coefficient,full_coefficient,combine
O=Path(__file__).resolve().parent;U=O.parent/'canonical_so10_u_F_fourth_support';role=sys.argv[1];assert role in ['primary','replay']
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,hsh in json.loads((O/'action_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==hsh,path
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        pp=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
        if pp.parent.name in ['canonical_so10_u_pair_contact_model','canonical_so10_intrinsic_auxiliary_ghost_source'] or pp.name.endswith('_selected.json.gz') or pp.parent.resolve()==O and pp.name.startswith(peer+'_action'):raise PermissionError('UFR_ACTION_TARGET_PEER_DENIED')
sys.addaudithook(guard)
denied=0
for path in [U/'primary_selected.json.gz',O.parent/'canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz',O/(('replay' if role=='primary' else 'primary')+'_action.json')]:
    try:path.read_bytes()
    except PermissionError:denied+=1
assert denied==3
loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()))
info,words=remaining_words(loadz(U/'inventory_result.json.gz'),loadz(U/'refined_result.json.gz'))
p=recover(role);tables=loadz(U/(role+'_operators.json.gz'))['tables'];data=load(role)
axis=3 if role=='primary' else 2;q=1 if role=='primary' else -1;G=propagator(data,q);rows=[];sensitive=Counter()
contexts=[(13,0,12,136),(13,12,13,207),(13,13,14,137),(20,13,20,169),(44,13,44,134),(13,0,13,206),(13,0,3,187),(14,2,22,132),(25,17,30,210),(40,4,9,300)]
for r,h,k,ix in contexts:
    weights,terms=cut_weights(p,h,k,r,info,words,details=True);cache={}
    V,roots=selected_parts(tables,info,r,h,k,ix,axis,q);vertices={name:multiply(G,M) for name,M in V.items()}
    perword=[]
    for wi,word in enumerate(words):
        original=word_coefficient(word,vertices,roots,info)
        compact=sum((component_contract(p,{t['prefix']:t['W']},h,k,ix,role,cache) for t in terms if t['word']==wi),ZERO)
        assert original==compact,('ACTION_WORD',role,r,h,k,ix,wi,str(original),str(compact))
        perword.append(str(original))
    byfam={fam:component_contract(p,z,h,k,ix,role,cache) for fam,z in weights.items()}
    without_CJ={name:M for name,M in vertices.items() if info['vertices'][name]['pattern']!='CJ'}
    full=sum(full_coefficient(combine(without_CJ,info['vertices']),roots,info,role).values(),ZERO)
    assert full==sum(byfam.values(),ZERO),('ACTION_FULL',role,r,h,k,ix,str(full),{a:str(b) for a,b in byfam.items()})
    for fam,v in byfam.items():sensitive['omitted_'+fam]+=bool(v)
    rows.append({'source':r,'ghosts':[h,k],'scalar':ix,'families':{a:str(b) for a,b in byfam.items()},'ordered_words':perword,'residual_C4':str(full)})
    print('STAGE actual_cut '+json.dumps({key:rows[-1][key] for key in ['source','ghosts','scalar','residual_C4']},sort_keys=True),flush=True)
out={'schema':'UFR2_FULL_ACTION_SCALAR_CUT_CALIBRATIONS','role':role,'axis':axis,'q':q,'rows':rows,'words_per_context':len(words),'all_uncut_words_and_full_powers_equal':True,'sensitive_controls':dict(sensitive),'guard_denials':denied,'whole_actual_tensor_claim':False,'sourceCJ_recomputed':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/(role+'_action.json')).open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({k:v for k,v in out.items() if k!='rows'},sort_keys=True),flush=True);timer.cancel()
