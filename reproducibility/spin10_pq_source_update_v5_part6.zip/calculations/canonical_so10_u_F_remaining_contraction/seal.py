from pathlib import Path
from hashlib import sha256
import ast,gzip,json,subprocess
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-F-remaining-contraction-v1-2026-10-26')
H=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
base=read(O/'inputs.json')['base_HEAD']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==base
assert subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()=='main'
subprocess.run(['git','diff','--quiet','HEAD'],cwd=R,check=True)
tree=subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);assert tree==(C/'old_git_tree.txt').read_bytes()
assert H(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
bindings={}
for file in sorted(O.glob('*preparation*.json')):
    for pp,h in read(file)['input_sha256'].items():
        assert H(Path(pp))==h,(file.name,pp)
        if pp in bindings:assert bindings[pp]==h
        bindings[pp]=h
for file in O.glob('*.source.txt'):assert (O/file.name.removesuffix('.source.txt')).read_bytes()==file.read_bytes(),file
for file in O.glob('*.py'):
    if file.name=='tree_audit.py':
        try:ast.parse(file.read_bytes())
        except SyntaxError:pass
        else:raise AssertionError('PRESERVED_PRELAUNCH_FAILURE_NO_LONGER_REPRODUCED')
    else:ast.parse(file.read_bytes())
assert {p.name for p in O.glob('*controller_failure*.json')}=={'tree_controller_failure.json','cut_controller_failure.json'}
assert 'SyntaxError' in read(O/'tree_controller_failure.json')['traceback']
failed=read(O/'cut_capture.json');assert failed['exit_code']==1 and not failed['calculation_completed'] and 'FULL_FIXTURE_POWER' in failed['stdout_and_stderr']
assert not (O/'cut_fixture_result.json').exists() and not (O/'tree_result.json.gz').exists()
completed=['tree_capture_v2.json','algebra_capture.json','cut_capture_v2.json','primary_action_capture.json','replay_action_capture.json','typed_capture.json','primary_tensor_capture.json','replay_tensor_capture.json','review_capture.json']
maximum=0
for name in completed:
    z=read(O/name);assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified']
    assert z['launch']['creation_after_observation'] and z['launch']['memory']['available_pagefile']>=350*1024**2
    for sample in z['all_resource_samples']:
        assert sample['private_bytes']<8*1024**3;maximum=max(maximum,sample['private_bytes'])
for name in ['algebra_result.json','cut_fixture_result_v2.json','typed_result.json','primary_action.json','replay_action.json']:assert read(O/name)['elapsed_after_imports']<300
assert load(O/'tree_result_v2.json.gz')['elapsed_after_imports']<300
for role in ['primary','replay']:
    report=[json.loads(line[7:]) for line in read(O/(role+'_tensor_capture.json'))['stdout_and_stderr'].splitlines() if line.startswith('RESULT ')]
    assert len(report)==1 and report[0]['guard_denials']==4 and report[0]['elapsed_after_imports']<300
# Whole array agreement is the completed review's mathematical result.
# Their unchanged bytes are authenticated above; this seal is not a replay.
v=read(O/'review_result.json');assert v['elapsed_after_imports']<180 and v['native_families_and_total_equal']
assert v['sourceCJ_reused_exactly_once'] and v['full_F_log5_cutoff_complete_with_inherited_C5_zero']
assert not v['known_quantum_remainder_native_operand'] and not v['other_finite_bases_continuum_QAP_or_physical_claim']
e=read(O/'e4_capture.json');events=[json.loads(line) for line in e['stdout'].splitlines() if line.startswith('{')]
exits=[z['exit_code'] for z in events if z.get('event')=='step_finished']
assert e['exit_code']==0 and exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED'
size=sum(p.stat().st_size for p in O.iterdir() if p.is_file());assert size<32*1024**2
files={str(p.relative_to(R)).replace('\\','/'):H(p) for p in O.iterdir() if p.is_file()}
handoff=R/'docs/RESEARCH_EXECUTION_HANDOFF_V651.md';files[str(handoff.relative_to(R)).replace('\\','/')]=H(handoff)
out={'schema':'UFR_FINAL_REVIEW_VALIDATION_V1','base_HEAD':base,'evidence_validation':'PASS_COMPLETE_RESIDUAL_C4_TENSOR_AND_LATE_FULL_F_LOG5_COMPARISON',
     'scientific_acceptance':'NOT_PERFORMED','authority':'34/39; E5/A5 OPEN','custody':'EXIT_2_SEVEN_UNRESOLVED','state_unchanged':True,'full_investigation_complete':False,
     'scope':'Original formal Euclidean local relative positive-heat UV symbol; all five residual C4 families, exact-once sourceCJ assembly and late full log5 comparison.',
     'authenticated_input_source_and_result_bindings':len(bindings),'preserved_old_mode_blob_entries':len(tree.splitlines()),'successful_captures':completed,
     'failed_runs_preserved':[{'controller':'tree_controller_failure.json','classification':'FAILED_PRELAUNCH_PYTHON310_SYNTAX_NO_WORKER'},{'capture':'cut_capture.json','classification':'FAILED_MISSCOPED_REVERSED_HB_FIXTURE_NO_MODEL_VERDICT'}],
     'maximum_successful_private_sample_bytes':maximum,'sample_is_continuous_peak':False,'packet_bytes_before_seal':size,'e4_step_exits':exits,
     'probe1_family_nonzero_counts':v['probe1_family_nonzero_counts'],'coverage':v['coverage'],'late_comparison':v['late_comparison'],
     'limitations':['shared action/reference/charts/ring/curated data/helpers/formula/software/AI author','whole tensor routes differ in association, not independent physical premises','other finite bases and common continuum trace/product/contact limits unresolved','no full measure/QAP, E5/A5 or physical viability claim'],
     'new_files_sha256':files}
dump(O/'final_review_validation_receipt.json',out);dump(C/'final_review_validation_receipt.json',out)
print(json.dumps({k:v for k,v in out.items() if k not in ['new_files_sha256','limitations','successful_captures']},sort_keys=True))
