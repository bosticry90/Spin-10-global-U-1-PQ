from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-F-remaining-contraction-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings={str(R/p):h for p,h in json.loads((O/'inputs.json').read_bytes())['input_sha256'].items()}
    for pp,h in bindings.items():assert H(Path(pp))==h,pp
    for name in ['.gitattributes','inputs.json','RECORD.md','recover.py','cut.py','TYPED_RECORD.md','typed_cut.py','run_typed.py','algebra_result.json','primary_action.json','replay_action.json']:
        path=O/name
        if path.suffix=='.py':ast.parse(path.read_bytes())
        cp=O/(name+'.source.txt')
        if cp.exists():assert cp.read_bytes()==path.read_bytes()
        else:
            with cp.open('xb') as f:f.write(path.read_bytes())
        bindings[str(path)]=H(path)
    for name in ['noncommuting_v3.py','typed_identity.py']:
        path=O.parent/'canonical_so10_u_F_maximal_cutoff'/name;bindings[str(path)]=H(path)
    dump(O/'typed_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    z=capture([sys.executable,'-B',str(O/'typed_cut.py')])
    dump(O/'typed_capture.json',z);dump(C/'typed_full_capture.json',z)
    assert z['exit_code']==0 and z['calculation_completed'] and z['post_run_observations_qualified']
    assert json.loads((O/'typed_result.json').read_bytes())['elapsed_after_imports']<300
    print('COMPLETED UFR2 fixtures',flush=True)
except BaseException:
    dump(O/'typed_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False})
    raise
