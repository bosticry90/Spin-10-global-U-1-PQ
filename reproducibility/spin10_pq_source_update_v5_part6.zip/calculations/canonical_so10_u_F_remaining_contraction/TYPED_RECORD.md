# UFR2B typed noncommuting reduction, prospective

The full cut formula passed 4400 uncut fixture-word comparisons, 40
tagged-power contexts, and ten actual action contexts in each axis/sign
and association. Before a whole tensor, simplify its color weights in a
free noncommuting block ring. Reuse UFM's skew-transpose algebra only as
a software primitive, authenticate it, and recheck actual classical color
type relations on every entry here. No inference from selected zeroes.

H/broken are rectangular block TYPES, not 1x1 commuting replacements.
Omega=diag(eta_H,xi), N has only broken rows, beta maps broken to H.
T_h is skew; H ghosts are block diagonal, broken ghosts have zero HH
block. Use the actual MC/J relations and K=2i JL. Keep each source
matrix and ordered scalar prefix. The AST arithmetic backend changes
only ring operations and the external-ghost type predicate; it does not
change enumeration, trace signs, ordering or endpoint coefficients.

Output all five families, prefix words, zero complements and formal
noncommuting coefficients for HH,HB,BB. A zero weight is a structural
identity only after the complete classical type audit. Nonzero weights
still require actual model contraction; this is not a full C4 tensor.
No commuting scalar-generator simplification or target-based fitting.
Same limits, authority ceiling and native blinding as RECORD.
