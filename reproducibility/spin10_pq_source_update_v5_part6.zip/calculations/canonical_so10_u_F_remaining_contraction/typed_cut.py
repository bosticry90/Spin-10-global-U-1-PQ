from pathlib import Path
from hashlib import sha256
import ast,json,gzip,sys,time,threading,os
from recover import recover,cf
from cut import remaining_words,FAMILIES
import recover as REC
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'canonical_so10_u_F_maximal_cutoff'))
from typed_identity import NC,Z,scalar,var,Tmat,co,ZERO,I,constant,multiply,plus,scale,transpose,identity
O=Path(__file__).resolve().parent;U=O.parent/'canonical_so10_u_F_fourth_support'
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for pp,hsh in json.loads((O/'typed_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(pp).read_bytes()).hexdigest()==hsh,pp
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        pp=Path(os.fsdecode(args[0]))
        if pp.parent.name in ['canonical_so10_u_pair_contact_model','canonical_so10_intrinsic_auxiliary_ghost_source'] or pp.name.endswith('_selected.json.gz'):raise PermissionError('UFR_TYPED_TARGET_DENIED')
sys.addaudithook(guard)
loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()))
info,words=remaining_words(loadz(U/'inventory_result.json.gz'),loadz(U/'refined_result.json.gz'))

# Full actual color-type audit, before applying the formal block reduction.
p=recover('primary');typ=[]
for h in range(45):
    A=p['MC'][h]['B'];assert A==REC.scale(REC.transpose(A),constant(-1))
    assert all((i<12)==(j<12) for i,j in A) if h<12 else all(not(i<12 and j<12) for i,j in A)
    T={ij:REC.Coeff([(tuple([key[0]-1,*key[1:]]),v) for key,v in c.terms]) for ij,c in A.items()}
    assert all(key[0]>=1 for c in A.values() for key,v in c.terms)
    BBT={ij:v for ij,v in T.items() if ij[0]>=12 and ij[1]>=12}
    HH={ij:v for ij,v in T.items() if ij[0]<12 and ij[1]<12}
    L=REC.scale(BBT,co('g10')) if h<12 else {}
    JB=REC.scale(HH if h<12 else T,-I*co('g10'))
    JL={} if h<12 else REC.scale(BBT,I*co('xi'))
    assert p['MC'][h]['C']==A and p['MC'][h]['L']==p['MC'][h]['a']==L
    assert p['J'][h]==(JB,JL) and p['K'][h]==REC.scale(JL,2*I)
    typ.append({'ghost':h,'A_entries':len(A),'typed_relations_verified':True})
assert all(b>=12 for b,i in p['N']) and all(c<12 and a>=12 for M in p['beta'] for c,a in M)

class TypedPredicate(ast.NodeTransformer):
    def visit_Compare(self,node):
        self.generic_visit(node)
        if isinstance(node.left,ast.Name) and node.left.id=='g' and len(node.ops)==1 and isinstance(node.ops[0],ast.Lt) and isinstance(node.comparators[0],ast.Name) and node.comparators[0].id=='nh':
            return ast.UnaryOp(op=ast.Not(),operand=ast.Call(func=ast.Name(id='isbroken',ctx=ast.Load()),args=[ast.Name(id='g',ctx=ast.Load())],keywords=[]))
        return node
tree=ast.parse((O/'cut.py').read_bytes());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['color_blocks','cut_weights']]
nodes=[ast.fix_missing_locations(TypedPredicate().visit(n)) for n in nodes]
from support import exterior_sign
ns=dict(globals());ns.update(constant=lambda n:scalar(constant(n)),I=scalar(I),Fraction=REC.Fraction,exterior_sign=exterior_sign)
exec(compile(ast.Module(body=nodes,type_ignores=[]),'UFR_TYPED_UNCHANGED_CUT_COMPILER','exec'),ns)

def state(kinds):
    Om={(0,0):scalar(co('eta_H')),(1,1):scalar(co('xi'))};MC=[];J=[];K=[]
    for slot,kind in enumerate(kinds,1):
        T=Tmat('T'+str(slot),kind);A=scale(T,co('g10'));BB={(1,1):T[1,1]}
        L=scale(BB,co('g10')) if kind=='H' else {}
        JB=scale({(0,0):T[0,0]} if kind=='H' else T,-I*co('g10'))
        JL={} if kind=='H' else scale(BB,I*co('xi'))
        MC.append({'B':A,'L':L,'C':A,'a':L});J.append((JB,JL));K.append(scale(JL,2*I))
    return {'Om':Om,'MC':MC,'J':J,'K':K,'beta':[{(0,1):var('beta')}]}

def encode(M):
    return [[i,j,[[[[name,at] for name,at in w],[[list(key),v.numerator,v.denominator] for key,v in c.terms]] for w,c in sorted(z.terms.items())]] for (i,j),z in sorted(M.items())]
rows=[]
for kinds in [('H','H'),('H','B'),('B','B')]:
    ns['isbroken']=lambda g:kinds[g]=='B'
    W=ns['cut_weights'](state(kinds),0,1,0,info,words,2,1)
    # N and every N R_prefix have zero H rows, so row-project the weights.
    W={fam:{pref:{ij:v for ij,v in M.items() if ij[0]==1} for pref,M in z.items()} for fam,z in W.items()}
    W={fam:{pref:M for pref,M in z.items() if M} for fam,z in W.items()}
    total={}
    for z in W.values():
        for pref,M in z.items():total[pref]=plus(total.get(pref,{}),M)
    total={pref:M for pref,M in total.items() if M}
    row={'ghost_types':list(kinds),'families':{fam:[[list(pref),encode(M)] for pref,M in z.items()] for fam,z in W.items()},'total':[[list(pref),encode(M)] for pref,M in total.items()],
         'family_formal_word_counts':{fam:sum(len(v.terms) for M in z.values() for v in M.values()) for fam,z in W.items()},'total_formal_word_count':sum(len(v.terms) for M in total.values() for v in M.values()),'weight_zero':not total}
    rows.append(row);print('STAGE typed_cut '+json.dumps({k:v for k,v in row.items() if k not in ['families','total']},sort_keys=True),flush=True)
out={'schema':'UFR2B_TYPED_NONCOMMUTING_CUT_REDUCTION','actual_classical_color_audit':typ,'rows':rows,'noncommuting_rectangular_types':True,'whole_actual_C4_tensor_claim':False,'quantum_target_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'typed_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({k:v for k,v in out.items() if k not in ['rows','actual_classical_color_audit']},sort_keys=True),flush=True);timer.cancel()
