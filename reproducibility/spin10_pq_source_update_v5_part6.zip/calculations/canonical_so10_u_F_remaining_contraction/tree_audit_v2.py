from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import Counter
import json,gzip,time,threading,os
import sympy as s
from recover import *
from coefficient_ring import expression
O=Path(__file__).resolve().parent;tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,h in json.loads((O/'tree_preparation_v2.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==h,path
@lru_cache(None)
def ratio(a,b):return str(s.cancel(expression(a.terms)/expression(b.terms)))
def compare(A,B):
    counts=Counter();unmatched=[]
    for key in sorted(A.keys()|B.keys()):
        av,bv=A.get(key,ZERO),B.get(key,ZERO)
        if bv:counts[ratio(av,bv)]+=1
        elif av:unmatched.append([*key,str(av)])
    return {'left_nonzeros':len(A),'right_nonzeros':len(B),'ratios':dict(counts),'left_entries_without_right':unmatched,'uniform_nonzero_proportionality':not unmatched and len(counts)==1 and '0' not in counts}
p=recover('primary');r=recover('replay')
assert p==r,'ALL_TREE_BLOCK_RECOVERIES_DISAGREE'
relations={'S_vs_N':compare(p['S'],p['N']),'HN_Bs_vs_S':compare(p['HN']['Bs'],p['S']),'HN_Ls_vs_OmS':compare(p['HN']['Ls'],multiply(p['Om'],p['S']))}
allF={};NR={};covminus={};covplus={};HCab={};K={};HCal={};KO={}
for h in range(45):
    nr=multiply(p['N'],p['R'][h]);dn=multiply(transpose(p['MC'][h]['a']),p['N'])
    for name,M in [('F',p['F'][h]),('NR',nr),('minus',plus(nr,scale(dn,constant(-1)))),('plus',plus(nr,dn))]:
        target=allF if name=='F' else NR if name=='NR' else covminus if name=='minus' else covplus
        for key,v in M.items():target[(h,*key)]=v
    for key,v in p['HC'][h]['aB'].items():HCab[(h,*key)]=v
    for key,v in p['K'][h].items():K[(h,*key)]=v
    for key,v in p['HC'][h]['aL'].items():HCal[(h,*key)]=v
    for key,v in multiply(p['K'][h],p['Om']).items():KO[(h,*key)]=v
relations.update({'F_vs_NR':compare(allF,NR),'F_vs_NR_minus_DtN':compare(allF,covminus),'F_vs_NR_plus_DtN':compare(allF,covplus),'HC_aB_vs_K':compare(HCab,K),'HC_aL_vs_KOm':compare(HCal,KO)})
encode=lambda M:[[list(key),[[list(k),v.numerator,v.denominator] for k,v in c.terms]] for key,c in sorted(M.items())]
blocks={'N':encode(p['N']),'S':encode(p['S']),'HN':{key:encode(v) for key,v in p['HN'].items()},'HC':[{key:encode(v) for key,v in M.items()} for M in p['HC']],'K':[encode(M) for M in p['K']],'F':[encode(M) for M in p['F']]}
out={'schema':'UFR1_COMPLETE_SCALAR_BLOCK_AUDIT','primary_replay_all_blocks_equal':True,'GF_nC_GF_nx_mixed_derivatives_equal':True,'HN_HC_transpose_relations_verified':True,
     'relations':relations,'blocks':blocks,'N_rows_H':sum(i<12 for i,j in p['N']),'S_rows_H':sum(i<12 for i,j in p['S']),'scalar_index_domain':328,
     'ratios_are_classical_input_diagnostics_not_quantum_fits':True,'known_quantum_remainder_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
blob=gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
assert sum(q.stat().st_size for q in O.iterdir() if q.is_file())+len(blob)<32*1024**2
with (O/'tree_result_v2.json.gz').open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({key:v for key,v in out.items() if key not in ['blocks','relations']},sort_keys=True)+' RELATIONS '+json.dumps(relations,sort_keys=True),flush=True);timer.cancel()
