from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-F-remaining-contraction-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings={str(R/p):h for p,h in json.loads((O/'inputs.json').read_bytes())['input_sha256'].items()}
    for pp,h in bindings.items():assert H(Path(pp))==h,pp
    for name in ['.gitattributes','inputs.json','RECORD.md','recover.py','cut.py','reduced.py','TENSOR_RECORD.md','tensor.py','run_tensor.py','algebra_result.json','primary_action.json','replay_action.json','typed_result.json']:
        path=O/name
        if path.suffix=='.py':ast.parse(path.read_bytes())
        cp=O/(name+'.source.txt')
        if cp.exists():assert cp.read_bytes()==path.read_bytes()
        else:
            with cp.open('xb') as f:f.write(path.read_bytes())
        bindings[str(path)]=H(path)
    dump(O/'tensor_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    for role in ['primary','replay']:
        z=capture([sys.executable,'-B',str(O/'tensor.py'),role])
        dump(O/(role+'_tensor_capture.json'),z);dump(C/(role+'_tensor_full_capture.json'),z)
        assert z['exit_code']==0 and z['calculation_completed'] and z['post_run_observations_qualified']
        assert json.loads(__import__('gzip').decompress((O/(role+'_tensor.json.gz')).read_bytes()))['elapsed_after_imports']<300
    a=json.loads(__import__('gzip').decompress((O/'primary_tensor.json.gz').read_bytes()));b=json.loads(__import__('gzip').decompress((O/'replay_tensor.json.gz').read_bytes()))
    assert a['families']==b['families'] and a['total']==b['total']
    print('COMPLETED UFR2 actual action',flush=True)
except BaseException:
    dump(O/'tensor_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False})
    raise
