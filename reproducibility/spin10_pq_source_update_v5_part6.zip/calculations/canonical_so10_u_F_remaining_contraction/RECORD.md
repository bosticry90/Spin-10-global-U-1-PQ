# UFR1-4: all five remaining nonlinear C4 families

Prospective at d444dec4; previous goal turn PROGRESS (full C4 operator
domain/zero sectors and complete source-CJ family). Fresh preflight clean
main/no matching workers; handoffV650 and actual receipt read. Goal ACTIVE,
incomplete. Current AGENTS governs; project_state sole scientific authority
state113,34/39,E5/A5 OPEN,custodyexit2/seven unresolved unchanged.

Question: derive a complete compact contraction of GF_nC,GF_nx,Hu_n,Hu_C,
Mu_n,not merely more selected successful coefficients. Reuse qualified
source-CJ exactly once. Whole C4 then supplies the remaining F log5
cutoff because complete F5=0 is already proved. Actual hypotheses and
all source/field conventions remain fixed.

UFR1: recover N,F_h,S,Hu_n and Hu_C blocks from both complete all-label
operator tables. Verify the GF_nC/GF_nx mixed-derivative relation on every
entry. Compare tree-level blocks to one another only as algebraic input
identities,never fitting a quantum remainder. Do not assume S=N or discard
Mu_C's tensor because its direct loop is excluded. Preserve every ordered
scalar generator and all H/broken colors until justified by full support.

UFR2: compile all51 remaining candidate words into scalar/color
contractions. For one scalar segment,retain the original starting-sector
supertrace sign,literal exterior order and possible scalar M0_C insertion.
The GF_nx mass vertex instead exposes its scalar index in F_h. Include all
five merged families,odd JL and distinct ghosts. Test noncommuting
rectangular fixtures and original full powers before tensor extraction.

UFR3: compute the complete residual tensor in the declared finite domain
by distinct contractions,including complete zero complements. Keep each
merged family and exact-once sum. Native blinding excludes selected or
old quantum target coefficients and peer outputs. If the complete method
cannot fit the prospective resource bound,preserve incomplete evidence
and derive a more competent reduction rather than silently extending
resources or truncating outputs.

UFR4: after whole native agreement,assemble the authenticated source-CJ
array exactly once and compare conversion PLUS cutoff on the ENTIRE
F log5 domain. Preserve every nonzero remainder. No sign or unknown
contact is fitted to cancel it. A mismatch,an underdefined premise or
a complete cancellation is meaningful within its actual scope; none by
itself qualifies full finite restoration,QAP,E5/A5 or physical viability.

Fixed original unshifted SMA/CSW/EDS,A0,constant u,intrinsic1,external
jets0 after differentiation,symbolic g10/xi/eta_H,common hbar/(16pi^2),
nonexceptional Euclidean LOCAL RELATIVE positive-heat UV symbol. Inherit
the qualified all-label domain,source/probe zeros,Lorentz support,free-root
and positive-heat radial results with explicit dependencies. Other finite
bases,common continuum trace/product/contact limits,measure/QAP,physical
domains and viability remain open. b0,kappa,chi4,IR freedoms distinct.

Native300s/review180s after imports,8GiB sampled private,350MiB launch
available-pagefile floor,32MiB packet. Freeze sources and inputs before
each bounded computation; owned-child full captures,resource samples and
exact failed/unfinished sources retained. No agents,branch/worktree,
protected activation,promotion,foundational/benchmark/scheme adoption,
remote action,publication or outreach. Shared action,reference,charts,
ring,curated inputs,helpers/software and AI author limit independence.
Apply the focused result-to-claim assessment in the existing result record.
