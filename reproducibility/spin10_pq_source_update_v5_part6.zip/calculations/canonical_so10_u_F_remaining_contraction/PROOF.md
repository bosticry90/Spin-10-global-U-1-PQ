# Complete residual C4 contraction in the original reference

This proof concerns the original unshifted SMA/CSW/EDS,A0, constant-u,
intrinsic1, external-jets0-after-differentiation formal Euclidean local
relative symbol. It does not assert a continuum operator-product or
physical limit. See RECORD and the final validation receipt for execution
and acceptance distinctions. All coefficient arithmetic is exact in the
retained polynomial/radical ring; no coupling is inverted to solve a
quantum equation. Extracting the known factor g10 from a classical
adjoint generator is a coefficient reindexing checked on every monomial.

## Action identities

N is the bare GF_n Lambda/scalar block. Full primary/replay tables give
S=2iN, Hu_n(B,s)=2N, Hu_n(Lambda,s)=Omega N, with the verified mixed
transpose signs. N has no unbroken rows. For every ghost h,

    F_h = i (N R_h + MC_a,h^T N).

For unbroken h, F_h=0 and N R_h=-MC_a,h^T N. For broken h,
MC_a,h=0, so F_h=i N R_h. GF_nx contains exactly this same F tensor,
with its opposite mixed Hessian transpose verified entry by entry.
The Mu_C tensor K_h=2i J_L,h controls Hu_C even though Mu_C cannot
itself close the target loop. No underlying interaction is deleted.

All2025 pairs obey [R_h,R_k]=sum_c MC_B,h[c,k] R_c. These identities
are action-input checks, not fits to any quantum remainder. See
tree_result_v2.json.gz and algebra_result.json for complete coefficients
and zero complements. The simple global F=iNR diagnostic fails for
unbroken h and is preserved rather than used outside its valid scope.

## Indexed scalar cut

The qualified support leaves 51 candidate words in five disjoint merged
families, plus six separately owned source-CJ words. Each residual path
contains one scalar segment, or the explicit scalar index of GF_nx.
For each original ordered path, retain its original starting-sector
supertrace sign and the exterior sign of EPS,JL,C1,C2. Rotating an
ordinary component trace to display the scalar segment does not license
altering either original sign.

With a scalar row at the x endpoint, the cut has color weight
(B_x P_color A_n)^T and scalar product N R_prefix R_root R_a.
With a scalar row at the nu endpoint, it has weight B_n P_color A_x
and scalar product N R_prefix R_root^T R_a. Thus a scalar M0_C root
contributes its ordered generator, with a minus on the latter orientation
because R_root is skew. The endpoint constants in cut.py come from
the audited original Hessian and free mixed propagator, not cyclic
supertrace assumptions. GF_nC supplies its F_b=iNR_b prefix only for
a broken external ghost; F_H=0 is an independently verified input.

For GF_nx, cutting the diagonal C/C or a/a mass block gives i P^T
or i P_color respectively, followed by a BROKEN column projection
because F_H=0. No such projection is applied to the internal generator
index of other paths. The final expression is always

    sum_(b,a) W_prefix[b,a] (N R_prefix R_a)[b,i],

where internal a ranges over all45 unless the explicit F support proves
otherwise. The compiler keeps each of the five families separately.

V2 fixtures check the larger110-word coarse inventory, not only the
canonical51-word union: 4400 word comparisons,7200 path evaluations,
40 full tagged powers and two scalar/color associations. This includes
reversed HB/BH slot assignments. The failed first fixture remains
explicitly classified in CUT_V2_RECORD. Ten actual action contexts per
route compare every canonical word and the full tagged power with
source-CJ removed, at axis3/q+ and axis2/q-.

## Free noncommuting color reduction

H and B are rectangular block types of dimensions12 and33, not scalar
substitutions. beta:H<-B. Write T_h=MC_B,h/g10 as the authenticated
polynomial factorization, A_h=T_h[H,B], B_h=T_h[B,B], H_h=T_h[H,H].
The complete type audit verifies skewness, MC_C=MC_B, the actual
unbroken/broken MC_L/MC_a restrictions, J_B,J_L and K=2iJ_L.

Substitute these relations in the unchanged cut compiler over a FREE
noncommuting word ring. Weight rows of type H may be removed because
N and N R_prefix have no H rows. Every HH family weight is exactly
zero. HB retains two total formal words; BB retains ten. Hu_n and
Mu_n are opposite by the formal algebra, but both arrays remain stored.
No scalar generators are commuted to achieve this reduction. All
two-generator prefixes cancel in this color reduction.

For HB (h unbroken,k broken), the only total weights are

    W_(k)[B,H] = 2 g10 eta_H beta^T H_h,
    W_()[B,B]  = 2 g10^2 eta_H beta^T H_h A_k.

For BB, the prefix weights are

    W_(k) = 2 g10 xi (A_h^T beta + beta^T A_h),
    W_(h) =-2 g10 xi (A_k^T beta + beta^T A_k).

The base weight is

    2 g10 xi (-B_h A_k^T beta + B_k A_h^T beta
                -beta^T A_h B_k + beta^T A_k B_h)
    +2 g10^2 xi ((A_h^T beta+beta^T A_h) B_k
                  -(A_k^T beta+beta^T A_k) B_h).

typed_result.json contains the full five-family noncommuting polynomials,
not just these summed formulas. Evaluated weights agree with every
entry and implicit zero of the unreduced actual cut on all ten contexts.

## Complete coefficient computation and interpretation

Primary associates N R_prefix R_a first; replay contracts W into N
first and then applies the ordered scalar generators. Their color-word
products also use opposite association. Each traverses all32 active
source labels and990 canonical ghost pairs, with328 scalar outputs;
inactive source rows, probe0 and HH have separate complete structural
proofs. Complete arrays and zero complements are compared after both
workers finish. Source-CJ is then reused exactly once from its qualified
UFS array. Only afterwards is the old full log5 conversion read and
added, preserving all remainders. Actual results are in review_result.json.

Inherited complete C5_F=0 identifies this C4 as the remaining full log5
cutoff within the fixed heat conventions. Agreement here cannot qualify
other finite bases, a common continuum trace/product/contact limit,
measure,QAP,chiral/global phase,source reality,causal/massive physical
limits or physical viability. Shared action,curated data,charts,ring,
software/formula and AI authorship limit independence. No external
scientist, proof assistant or experimental validation is asserted.
