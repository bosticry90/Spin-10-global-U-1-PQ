# UFR2 action verification, prospective

Authenticate UFR2's completed V2 fixture result; it covers all five
families on the larger coarse inventory, including reversed HB/BH slots.
Now recover actual primary/replay action blocks independently and compare
the canonical 51-word cut formula with uncut global operator products and
the full tagged fourth power with source-CJ omitted. Source-CJ stays owned
by UFS; this subtraction is a domain isolation, not recomputation of it.

Use ten explicit source/ghost/scalar contexts listed in cut_action.py,
including the earlier sensitive witnesses and further HH/HB/BB contexts.
The two actual routes use axis3/q+ versus axis2/q-, with scalar weights
associated before versus after color contraction. Retain per-word checks,
all five merged-family values and their zeroes. Do not read prior selected
quantum values or the old conversion target. These are finite calibrations
of a complete derived formula, not the whole actual tensor calculation.
Limits and authority ceiling unchanged; freeze before launching workers.
