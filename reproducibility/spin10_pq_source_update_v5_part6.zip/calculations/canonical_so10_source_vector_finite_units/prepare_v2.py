"""SVF1 exact common-denominator continuation; failed evidence stays immutable."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/source-vector-finite-units-v1-2026-10-23')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='37cd8455b933f505d28659c5f3ca0fd168192cad'
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
bind=dict(read(HERE/'preparation.json')['input_sha256'])
for p,h in bind.items():assert digest(Path(p))==h,p
def add(p):p=p.resolve();bind[str(p)]=digest(p)
cap=read(HERE/'primary_capture.json');assert cap['execution_state']=='FAILED' and cap['exit_code']==4294967295 and not cap['calculation_completed'] and cap['post_run_observations_qualified']
assert not (HERE/'primary_tables.json.gz').exists() and not (HERE/'replay_capture.json').exists()
classification={'execution_state':'CANCELED','scientific_disposition':'INCOMPLETE_ENGINEERING_REASSESSMENT','native_capture_state':cap['execution_state'],'native_exit':cap['exit_code'],'owned_process_id':16232,'verified_command_tail':'canonical_so10_source_vector_finite_units/primary.py','termination':'Stop-Process after exact own command-line verification','resource_limit_exhausted':False,'last_sample_seconds':cap['all_resource_samples'][-1]['seconds'],'result_or_table_emitted':False,'failure_relabelled_PASS':False,'source_correction':'clear exact common Q denominator before polynomial expansion','mathematical_requirements_changed':False,'scientific_acceptance':'NOT_PERFORMED'}
with (HERE/'cancellation_classification.json').open('xb') as f:f.write((json.dumps(classification,sort_keys=True,indent=2)+'\n').encode())
for n in ['CANCELLATION_V1.md','data_v2.py','primary_v2.py','replay_v2.py','verify_v2.py','prepare_v2.py','run_v2.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':compile(raw,str(p),'exec')
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
for n in ['primary_capture.json','controller_failure.json','preparation_capture.json','preparation.json','cancellation_classification.json']:add(HERE/n)
with (CONTROL/'prelaunch_v2_preflight.json').open('xb') as out,(CONTROL/'prelaunch_v2_preflight_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_session_preflight.py')],cwd=ROOT,stdout=out,stderr=err)
assert r.returncode==0 and not read(CONTROL/'prelaunch_v2_preflight.json')['active_A10_M08_python_processes']
for n in ['prelaunch_v2_preflight.json','prelaunch_v2_preflight_stderr.txt']:add(CONTROL/n)
with (HERE/'preparation_v2.json').open('xb') as f:f.write((json.dumps({'schema':'SVF1_V2_PREPARATION','input_sha256':dict(sorted(bind.items())),'seconds_each':600,'private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'original_primary_classification':'CANCELED_INCOMPLETE','scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('SVF1_V2_FROZEN',len(bind),'bindings',flush=True)
