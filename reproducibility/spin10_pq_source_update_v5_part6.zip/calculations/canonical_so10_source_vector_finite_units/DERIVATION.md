# SVF1: dimension-free tensor reduction and actual finite integrals

Use the qualified unit source/external ordering Je Be Ce. Historical kernels
are Minkowski polynomials in k_mu,t=1/Q, widths WX/WY. With their inherited
Wick normalization a covariant unit is

 kernel_(nu,mu)=-i[A delta_(nu,mu)t^2+B eta_(mu,mu) k_nu k_mu t^3].

Check this pointwise at every Lorentz pair before reading the old pole.
The normalized Euclidean critical tensor is A delta/q^4+B q_nu q_mu/q^6,
in common1/(16pi^2) units. Thus u_D=A+B/D, not a four-dimensional average
silently reused under a dimension derivative.

Why this lift is the actual metric-natural lift: write
P_W=I+(W-1)kk^T/Q. Then P_W k=W k. The bubble is -P_W; FF_a and FU_source
reduce to -WX kk^T/Q; FF_c has the opposite sign; FU_ghost is +P_W.
These are identities in any dimension and involve no closed identity trace.
External Be/Ce derivatives vanish at this zeroth external Taylor order.
For the full cubic-vector vertex at momenta(0,k,-k), its contraction with
the ghost-side k is kk^T-QI. This is transverse. Hence multiplication by
the source-side P_WY leaves it unchanged, and the complete YM tensor is
WX(I-kk^T/Q). This retains every cubic-vertex permutation and explains WY
cancellation without setting a width or D=4. Its sign/normalization is
compared with the independently qualified full Wick/Born kernel, not assumed
from a desired amplitude. No contraction creates a free numerical trace D.

For an n-edge logarithmic word, the actual scalar heat is exp(-2nt Q).
At this zero-jet, dimension-zero target the kernel is already critical;
there are no external-momentum heat jets or positive-dimensional insertions.
Set c=2n. Relative to BSF's common chi4, chi_c=chi4+log(c/4). Keeping the
same measure jet sigma, the primitive unit is

 chi_c*u_4 -2*(partial_D u_D)|4
       =chi4*(A+B/4)+log(c/4)*(A+B/4)+B/8.

This is a relative local conversion coefficient, not a physical finite-part
choice. Gamma_ref has no source; it cancels in this relative projection only.
No independent baseline is introduced or equated with b0/kappa.

Independent actual-integral proof uses a common positive auxiliary IR mass
m solely for this relative UV comparison. Complete the two tensors as
delta/(q^2+m^2)^2 and q_mu q_nu/(q^2+m^2)^3. The difference from the
original critical homogeneous kernel is UV-integrable and the same on both
sides, so it cancels in the regulator difference. This does not replace a
physical mass, choose a zero-momentum massless amplitude, or prove a general
IR limit. Take UV finite part before this common IR comparison.

In16pi^2 units, z=c t m^2, the exact Schwinger heat integral is

 I2_heat=(1+z) exp(z) E1(z)-1,
 FP I2_heat=-gamma_E-log(c m^2)-1+n_log.

Raw dimensional I2=Gamma(epsilon)*(4pi/m^2)^epsilon has finite part
-gamma_E+log(4pi/m^2). Their difference is
1+log(4pi*c)-n_log=chi_c, consistent with the inherited measure derivative.

The tensor heat integral is delta*(I2_heat-m^2 I3_heat)/4, and
lim_(t->0) m^2 I3_heat=1/2 by an absolutely convergent Schwinger integral.
In D=4-2epsilon, integration by parts/Gamma recurrence gives the dimensional
tensor integral exactly delta*I2_dim/4. Therefore its finite difference is
delta*(chi_c/4+1/8). This independently recovers B/8. The1/8 would be lost
by prematurely replacing D with4 in the angular coefficient.

The bubble uses c4, every triangle c6. Omitting log(3/2) changes nonzero
triangle units even where a leading UV test still passes. FF_a+FF_c+FF_Be
continues to cancel because its members share n3 and the same finite map.
The lower auxiliary family, actual color contractions and coupled Ward
identity are later tasks, never inferred from these unit computations.
