"""SVF1 pointwise Born-kernel tensor extraction and natural dimension jet."""
from data import *
start=begin('primary');packet=packed(HERE/'kernel_inputs_primary.json.gz');out={};checks={};unitUV={};evaluated={K[i]:s.Integer(i+1) for i in range(4)};q0=Q.subs(evaluated)
for name in FAMILIES:
 rows=packet['kernels'][name];r={(nu,mu):parse(z).subs(t,1/Q) for nu,mu,z in rows}
 # Unique A,B from a generic nonnull vector; verify the FULL polynomial next.
 b=tidy((s.I*r[0,1]*Q**3/(ETA[1]*K[0]*K[1])).subs(evaluated));a=tidy((s.I*r[0,0]*Q**2-b*K[0]**2/Q).subs(evaluated))
 checks[name]=check_kernel(rows,a,b);n=2 if name=='D' else 3;out[name]=units(a,b,n)
 assert not a.has(WY) and not b.has(WY)
 # Angular recurrence with the normalized D-sphere moment, prior to D4.
 angular=s.combsimp(s.gamma(D/2)*s.gamma(s.Rational(3,2))/(s.gamma(D/2+1)*s.gamma(s.Rational(1,2))));zer(angular-1/D)
 zer(a+b*angular-parse(out[name]['u_D']))
 unitUV[name]=str(tidy((a+b/D).subs(D,4)))
for key in ['A','B','u_D','u4','fixed','chi4_coefficient','log3over2_coefficient']:
 zer(sum(parse(out[n][key]) for n in ['FF:a','FF:c','FF:Be']))
assert all(parse(out[n]['fixed'])==0 and parse(out[n]['u_D'])==0 for n in ['FF:Be','FF:Ce'])
sigma=s.diff(s.log(2*s.pi**(D/2)/s.gamma(D/2)/(2*s.pi)**D),D).subs(D,4);nl=s.Symbol('n_log');chi4=s.EulerGamma+s.log(4)-nl-2*sigma;zer(s.expand_log(chi4-(1+s.log(16*s.pi)-nl),force=True))
finish('primary',{'method':'full_Born_pointwise_covariant_kernel_extraction_and_D_sphere_jet','unit_coefficients':out,'pointwise_kernel_positions':checks,'UV16_units':unitUV,'chi4_definition':'1+log(16*pi)-n_log','dimension_free_lift_proof':'DERIVATION.md projector and transverse cubic identities, no numeric trace','all_current_sum_remainder':0,'external_derivative_remainders':0,'new_loop_gaussians_recomputed':False},start)
