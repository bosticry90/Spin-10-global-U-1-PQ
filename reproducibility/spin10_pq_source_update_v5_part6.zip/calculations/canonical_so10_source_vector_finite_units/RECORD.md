# SVF1: finite units for the ordinary gauge-source/vector family

Base37cd8455b933f505d28659c5f3ca0fd168192cad/main32089 oldblobs. Whole
investigation ACTIVE, state113/34of39 unchanged. BSF extracted JBpartialC;
CLO restored its common-log coupled partner. The remaining fixed finite
completion cannot be tested globally using only that one-jet projection.
Actual JB B C coefficients are the next required vector-source carrier.

Reuse the completed action-derived ordinaryg3 unit vertices, Born and Wick
kernels in canonical_so10_gauge_source_g3_units, not its old UV pole as a
finite answer. These cover S*D,S*Fg*Fv,S*F*U and S*F*G3, with eight derivative/
mixed-orientation variants and all16 Lorentz pairs. No costly group expansion
or repeated qualified Gaussian calculation is needed. First extract their
finite dimensional-Stokes/ordered-heat units before contracting Spin10 colors.

Target is Je(d2,gh-1)*Be(d1,gh0)*Ce(d1,gh1), zero ordinary jets, even total,
dimension4. All source order, inverse orientations, vertex multiplicities and
normalized Wick branch are inherited exactly. Both widths WX/WY remain
symbolic; no physical width/coupling/mass is chosen. This ordinaryg3 domain
does not include the distinct lower auxiliary g2*xi family or background
completion. Local extraction is mass-independent at zero positive coefficient
dimension; it is not a whole massless/scaleless finite amplitude.

Each metric-natural unintegrated kernel reduces pointwise to an O(D) tensor
A*delta/Q^2+B*k*k/Q^3. Before lifting, check ALL128 historical kernels against
this tensor, modulo only Q=k.eta.k and t=1/Q. The dimension-free propagation/
cubic identities in DERIVATION prove no omitted closed numeric Lorentz trace.
Do not infer a lift solely from a four-dimensional pole or rank witness.

Primary extracts A,B from the full Born kernels and differentiates the exact
D-angular unit A+B/D with the same sphere measure and actual heat length2n.
Replay uses the independent Wick kernels, dimension-free vector contraction
and actual common-IR Schwinger heat/Gamma dimensional integrals. Compare
the complete finite constants, including the triangle/bubble log(3/2) and
first dimension jet. Actual color coefficients, fermionic quantum breaking
and any desired canonical counterterm target are withheld from workers.

Require exact peer agreement for all kernels/zeros, old UV normalization
after computation, FF current sum, external derivative zeros, full ordinary
width dependence, heat-length and dimension-jet negative controls. Keep the
ordinary n2/n3 Born factors fixed. No coefficient is fitted to a Ward identity.
If the natural lift or relative IR argument fails, retain that limitation;
if a route/gate fails, preserve all sources/captures, stop and version fixes.

Freeze eight sources/copies and immutable inputs before sequential P/R/gate.
Each600s after imports,8GiB sampled private,350MiB available-commit launch
floor,16MiB packet. Reuse current-goal-turn completed BSF E4 honestly and
take a fresh byte preflight. No resource expansion, truncation or agents.

Ceiling: relative local finite unit kernels for this specified bosonic
operator lift and heat prescription, not actual Spin10 tensor assembly,
full coupled/chiral restoration, QAP/products/measure/phase, physical scheme,
massiveC1,E5/A5 or unification. All historical exclusions, two scalar warnings,
quartetFAIL, flavor pause, HB1/C5 blocks, custody2/seven NOTPASS and distinct
free normalizations remain. Preserve main/state/oldbytes; no branch/worktree,
publication/outreach/push. Shared vertices/regulator/software/AI authorship
are not independent scientists. The result should support the actual next
source-vector coefficient calculation, not another broad review framework.
