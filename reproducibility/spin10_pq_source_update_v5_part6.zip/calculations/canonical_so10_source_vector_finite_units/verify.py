"""SVF1 exact all-kernel finite units, dimensional lift and sensitive controls."""
from data import *
start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');control=packed(HERE/'validation_control_inputs.json.gz')
for key in ['unit_coefficients','pointwise_kernel_positions','UV16_units','chi4_definition','all_current_sum_remainder','external_derivative_remainders','new_loop_gaussians_recomputed']:assert P[key]==R[key],key
assert sum(P['pointwise_kernel_positions'].values())==128 and all(v==16 for v in P['pointwise_kernel_positions'].values())
controls={};full_positions=0
for name in FAMILIES:
 d=P['unit_coefficients'][name];a=parse(d['A']);b=parse(d['B']);v=parse(d['u4']);f=parse(d['fixed']);lc=parse(d['log3over2_coefficient']);edges=2 if name=='D' else 3
 zer(parse(d['u_D'])-(a+b/D));zer(v-a-b/4);zer(f-b/8)
 assert d['edges']==edges and d['heat_length']==2*edges
 zer(lc-(v if edges==3 else 0));assert not any(parse(d[k]).has(WY) for k in ['A','B','u_D','fixed'])
 for role in ['primary','replay']:
  packet=packed(HERE/('kernel_inputs_'+role+'.json.gz'));assert check_kernel(packet['kernels'][name],a,b)==16
  for nu,mu,old in control[role][name]:zer(parse(old)/2-v*int(nu==mu));full_positions+=1
 controls[name]={'omit_dimension_jet_difference':str(-f),'wrong_bubble_heat_for_triangle_difference':str(-lc),'nonzero_fixed_jet':bool(f!=0),'nonzero_triangle_log':bool(lc!=0)}
for k in ['A','B','u_D','u4','fixed','chi4_coefficient','log3over2_coefficient']:zer(sum(parse(P['unit_coefficients'][n][k]) for n in ['FF:a','FF:c','FF:Be']))
for n in ['FF:Be','FF:Ce']:assert all(parse(P['unit_coefficients'][n][k])==0 for k in ['A','B','u_D','u4','fixed','chi4_coefficient','log3over2_coefficient'])
assert R['tensor_extra_finite']=='1/8' and R['mass_I3_convergent_unit']=='1/2' and R['dimensional_tensor_to_I2_ratio']=='1/4'
assert all(controls[n]['nonzero_fixed_jet'] for n in ['D','FF:a','FF:c','FU:source_mixed','FU:ghost_mixed','YM'])
assert all(controls[n]['nonzero_triangle_log'] for n in ['FF:a','FF:c','FU:source_mixed','FU:ghost_mixed','YM'])
# A unit-width-only fixed-jet test is insensitive in the bubble and FUghost.
assert parse(P['unit_coefficients']['D']['fixed']).subs(WX,1)==0 and parse(P['unit_coefficients']['FU:ghost_mixed']['fixed']).subs(WX,1)==0
assert parse(P['unit_coefficients']['YM']['fixed']).subs(WX,1)!=0
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
for d in [P,R]:assert d['authority']=='34/39' and not any(d[k] for k in ['actual_Spin10_color_coefficients_computed','physical_scheme_adopted','quantum_coefficient_fitted','new_physical_mass_or_width_selected','full_coupled_restoration_claimed','new_loop_gaussians_recomputed'])
print('RESULT '+json.dumps({'status':'QUALIFIED_ORDINARY_SOURCE_VECTOR_FINITE_UNITS','elapsed_after_imports':time.perf_counter()-start,'unit_variants':8,'pointwise_positions_per_route':128,'old_UV_positions_compared':full_positions,'all_complete_kernels_and_zero_complements_match':True,'metric_natural_D_lift_dimension_free_proof':'DERIVATION.md','common_chi4_symbolic':True,'triangle_heat_shift':'log(3/2)','finite_units':P['unit_coefficients'],'negative_controls':controls,'external_derivative_zeros':True,'FF_current_sum_remainder':0,'actual_Spin10_color_coefficients_computed':False,'quantum_coefficient_fitted':False,'physical_scheme_adopted':False,'scientific_authority_changed':False,'full_coupled_restoration_QAP_measure_phase_massiveC1_E5A5_unification_qualified':False,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','primary_tables_sha256':digest(HERE/'primary_tables.json.gz'),'replay_tables_sha256':digest(HERE/'replay_tables.json.gz')},sort_keys=True),flush=True)
