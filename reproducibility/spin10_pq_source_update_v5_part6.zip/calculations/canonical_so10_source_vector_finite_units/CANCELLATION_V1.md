# SVF1 original primary: canceled for engineering reassessment

The first primary is unfinished, with no completed scientific result/table.
Code review identifies unnecessary rational expansion: check_kernel substitutes
t=1/Q, multiplies Q^4 and expands before clearing the nested denominators.
That expands high-degree common factors instead of the required homogeneous
polynomial. Stop only the exact owned primary process after verifying its
command line. Preserve its full capture/controller failure and native exit;
classify it CANCELED_ENGINEERING_REASSESSMENT, not a mathematical refutation,
resource-cap exhaustion or PASS. No completed calculation is repeated.

The proposed V2 will first view the residual as a polynomial in t, then
multiply each coefficient by the exact common power Q^(M-degree_t). This is
identically Q^M times the same rational residual on Q!=0. All128 positions,
the full natural-tensor identity, coefficients, lift, inputs, finite integral
derivations, gate and original resource caps stay unchanged. Freeze V2 sources
and this failure record before executing it. Do not overwrite old sources.
