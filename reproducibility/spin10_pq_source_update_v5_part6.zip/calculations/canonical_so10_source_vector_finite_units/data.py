"""SVF1 exact action-only kernel IO and complete finite-unit serialization."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import gzip,json,os,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
K=s.symbols('k0:4',real=True);t=s.Symbol('t');WX,WY=s.symbols('width_X width_Y');D=s.Symbol('D');Q=sum((1 if i==0 else -1)*v*v for i,v in enumerate(K));ETA=[1,-1,-1,-1]
FAMILIES=['D','FF:a','FF:c','FF:Be','FF:Ce','FU:source_mixed','FU:ghost_mixed','YM']
def tidy(x):return s.factor(s.cancel(s.expand(x)))
def parse(z):return s.sympify(z,locals={**{str(k):k for k in K},'t':t,'width_X':WX,'width_Y':WY})
def zer(x):assert tidy(x)==0,x
def begin(role):
 start=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
 assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and (p.name.startswith(peer) or p.name=='validation_control_inputs.json.gz'):raise PermissionError('SVF1_PEER_OR_POLE_DENIED')
   if p.parent.name=='canonical_so10_gauge_source_g3_units' and p.name.endswith('_result.json'):raise PermissionError('SVF1_OLD_POLE_DENIED')
 sys.addaudithook(audit);return start
def check_kernel(raw,a,b):
 checked=0
 for nu,mu,z in raw:
  target=-s.I*(a*int(nu==mu)*t**2+b*ETA[mu]*K[nu]*K[mu]*t**3)
  zer(s.expand((parse(z)-target).subs(t,1/Q)*Q**4));checked+=1
 return checked
def units(a,b,n):
 u=tidy(a+b/D);v=tidy(u.subs(D,4));return {'A':str(tidy(a)),'B':str(tidy(b)),'edges':n,'heat_length':2*n,'u_D':str(u),'u4':str(v),'chi4_coefficient':str(v),'log3over2_coefficient':str(v if n==3 else 0),'fixed':str(tidy(-2*s.diff(u,D).subs(D,4)))}
def finish(role,d,start):
 d.update({'role':role,'elapsed_after_imports':time.perf_counter()-start,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','actual_Spin10_color_coefficients_computed':False,'physical_scheme_adopted':False,'quantum_coefficient_fitted':False,'new_physical_mass_or_width_selected':False,'full_coupled_restoration_claimed':False})
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'role':role,'elapsed_after_imports':d['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob),'raw_bytes':len(raw)},sort_keys=True),flush=True)
