"""SVF1 dimension-free vector contractions and actual Schwinger/Gamma FPs."""
from data import *
start=begin('replay');packet=packed(HERE/'kernel_inputs_replay.json.gz');out={};checks={};dimension_checks={}
for nspace in [2,3,5]:
 k=s.Matrix(range(1,nspace+1));q=(k.T*k)[0];O=k*k.T/q;I=s.eye(nspace);PX=I+(WX-1)*O;PY=I+(WY-1)*O
 zer((PX*k-WX*k).norm()**2);zer((PY*(O-I)-(O-I)).norm()**2)
 # Full cubic tensor at incoming momenta(0,k,-k), contracted at both ends.
 YM=s.zeros(nspace)
 for nu in range(nspace):
  for mu in range(nspace):
   YM[nu,mu]=tidy(-sum(PY[nu,a]*WX*k[b]*(2*k[mu]*int(a==b)-k[a]*int(mu==b)-k[b]*int(mu==a)) for a in range(nspace) for b in range(nspace))/q)
 zer(sum((YM-WX*(I-O)).applyfunc(s.expand)))
 mats={'D':-PX,'FF:a':-WX*O,'FF:c':WX*O,'FF:Be':s.zeros(nspace),'FF:Ce':s.zeros(nspace),'FU:source_mixed':-WX*O,'FU:ghost_mixed':PX,'YM':YM}
 for name,m in mats.items():
  b=tidy(m[0,1]/O[0,1]);a=tidy(m[0,0]-b*O[0,0]);assert all(tidy(z)==0 for z in m-a*I-b*O)
  u=units(a,b,2 if name=='D' else 3)
  if nspace==2:out[name]=u
  else:assert u==out[name]
 dimension_checks[str(nspace)]=nspace**2*len(mats)
for name in FAMILIES:checks[name]=check_kernel(packet['kernels'][name],parse(out[name]['A']),parse(out[name]['B']))
z=s.Symbol('z',positive=True);eps=s.Symbol('epsilon',positive=True);c,m2=s.symbols('c m2',positive=True);nl=s.Symbol('n_log')
Iheat=(1+z)*s.exp(z)*s.expint(1,z)-1
heat_series=s.expand(s.series(Iheat,z,0,1).removeO());zer(heat_series+s.log(z)+s.EulerGamma+1)
# Gamma recurrence from the actual Gaussian radial numerator, not an angular guess.
ratio=s.combsimp(s.gamma(D/2+1)/(2*D*s.gamma(D/2)));zer(ratio-s.Rational(1,4))
I_dim=s.gamma(eps)*s.exp(eps*s.log(4*s.pi/m2));dimFP=s.expand(s.series(I_dim,eps,0,1).removeO()-1/eps)
heatFP=heat_series.subs(z,c*m2)+nl;difference=s.expand_log(dimFP-heatFP,force=True);zer(difference-(1+s.log(4*s.pi*c)-nl))
u=s.Symbol('u',positive=True);convergent=s.integrate(u/(1+u)**3,(u,0,s.oo));assert convergent==s.Rational(1,2)
tensor_difference=difference/4+convergent/4
for name,d in out.items():
 a=parse(d['A']);b=parse(d['B']);actual=s.expand(a*difference+b*tensor_difference);expected=(a+b/4)*difference+b/8;zer(actual-expected)
 zer(parse(d['fixed'])-b/8)
finish('replay',{'method':'independent_Wick_tensor_projectors_full_cubic_and_actual_IR_completed_integrals','unit_coefficients':out,'pointwise_kernel_positions':checks,'UV16_units':{n:d['u4'] for n,d in out.items()},'chi4_definition':'1+log(16*pi)-n_log','dimension_checks':dimension_checks,'heat_I2_finite':str(heatFP),'dimensional_I2_finite':str(dimFP),'finite_difference':str(difference),'mass_I3_convergent_unit':str(convergent),'dimensional_tensor_to_I2_ratio':str(ratio),'tensor_extra_finite':'1/8','all_current_sum_remainder':0,'external_derivative_remainders':0,'new_loop_gaussians_recomputed':False},start)
