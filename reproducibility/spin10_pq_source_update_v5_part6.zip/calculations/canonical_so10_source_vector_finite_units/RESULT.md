# SVF1: finite ordinary source/vector units are now calculated

Corrected primary/replay and separate gate completed native0. Receipt
validation_receipt_v2.json SHA256:
153afb0f1ea65ebbdb7048f5a4b1d30f96ed408e2f50cde15e34e1bd3f3cc130.
Status QUALIFIED_ORDINARY_SOURCE_VECTOR_FINITE_UNITS; scientific/director
acceptance NOT_PERFORMED, state113/34of39 unchanged.

All128 unintegrated Lorentz positions per route agree with the full natural
tensor A delta/Q^2+B kk/Q^3, including off-diagonal kernels before averaging.
The normalized angular unit is u_D=A+B/D. The dimension-free projector and
transverse cubic identities prove that no closed numeric Lorentz trace is
hidden by the four-coordinate comparison. This is the fixed bosonic metric
lift, not an automatic extension to gamma5 or arbitrary four-dimensional
algebras. Both old UV normalizations agree after converting32pi^2 to16pi^2
units, across256 comparison positions including their zeros.

The complete local primitive unit is

 chi4*u4 + log(c/4)*u4 + fixed, c=2n.

| Unit family | u4 | fixed | c |
| --- | --- | --- | --- |
| S*D | -(WX+3)/4 | (1-WX)/8 | 4 |
| FF_a | -WX/4 | -WX/8 | 6 |
| FF_c | WX/4 | WX/8 | 6 |
| external Be derivative | 0 | 0 | 6 |
| external Ce derivative | 0 | 0 | 6 |
| FU_source | -WX/4 | -WX/8 | 6 |
| FU_ghost | (WX+3)/4 | (WX-1)/8 | 6 |
| full cubic vector | 3WX/4 | -WX/8 | 6 |

All couplings, model color tensors and actual action differentiation
multiplicities remain outside these unit entries. WX follows the ordinary
vector line as in the qualified unit convention; WY cancels by an actual
transverse contraction. Neither width is physically chosen. External
derivative zeros are evaluated at this zero-jet Taylor coefficient, not
deleted from the action. The complete FF current sum remains0 for the pole,
dimension jet, finite fixed constant and heat-length term separately.

The first method extracts the invariant tensor from complete Born kernels
and uses the D-sphere moment and measure derivative. The second checks the
independent Wick kernels with dimension-free vector contractions, including
every cubic term, and derives the finite difference from actual common-IR
Schwinger heat and dimensional Gamma integrals. Its nonzero tensor extra
constant is1/8. A positive auxiliary mass completes the relative calculation;
the UV-integrable difference cancels on both sides. No physical massless
zero-momentum amplitude or physical IR limit is inferred.

The bubble heat length is4; triangles have length6. Replacing every length
by4 would erase nonzero log(3/2) terms in all five nonzero triangle units,
while leaving the old pole unchanged. Omitting the first dimension jet
changes all six nonzero families. A unit-width-only fixed-jet control is
insensitive for S*D and FU_ghost, but the cubic-vector jet remains nonzero.
Those limitations are explicitly tested, not concealed by a generic PASS.

This supplies finite unit kernels, not model-specific Spin10 coefficients,
a new measured Slavnov breaking or a completed coupled restoration. The
next actual color calculation must apply the finite weights to every
action-derived family before comparison with any desired completion.
chi4 remains the common inherited normalization coordinate, unfixed and
distinct from b0 and the invariant freedoms.

## Execution and preserved engineering cancellation

The original primary was stopped after engineering review of unnecessary
rational expansion; no scientific result/table existed. The exact owned
process was verified before termination. Its106 resource samples end at
210.6409617s and have maximum60284928 private bytes. The capture's native
exit4294967295/FAILED and controller failure remain intact; the separate
classification is CANCELED/INCOMPLETE_ENGINEERING_REASSESSMENT. This is not
600s-cap exhaustion, scientific refutation or PASS. Original replay/gate
never launched, and no completed computation was repeated.

V2 changes only exact denominator clearing. It forms the residual as a
polynomial in t and multiplies each coefficient by Q^(M-degree_t) before
expansion: identically Q^M times the original rational residual on Q!=0.
It retains every coefficient, all128 comparisons, the natural-lift proof,
finite integral route, controls and original resource limits. P2/R2/gate
completed in1.4177110/1.6724827/1.5072317s after imports, each native0.
Their two-sample private maxima50556928/50257920/49463296 bytes are sparse
observations, not peaks. Same600s/8GiB sampled/350MiB floor/16MiB packet.
Fifteen source copies and739/760/768 binding manifests preserve the sequence.
Current-goal-turn BSF E4 reused honestly; fresh byte preflights. Historical
custody remains exit2/seven NOTPASS. No historical bytes or state changed.

Track B: actual integral/tensor methods corroborate finite dimension and
heat constants; a bad symbolic evaluation order wasted an unfinished run.
The correction demonstrates exact structural simplification, not reduced
scientific scope. Shared action vertices, inherited loop normalization,
regulator assumptions, SymPy and AI authorship remain common-error risks.
This is internal corroboration, not independent physical validation.

Next smallest action: assemble the six actual ordinaryg3 color families
from existing action-derived input operators with these finite weights.
Retain pole/chi4, triangle-log and fixed pieces separately, then transport
the complete source-dual tensor into the same coordinates as BSF/BME.
Only afterward compare the higher-field matter-Euler contribution with
admissible coupled counterterm images. The lower auxiliary g2*xi source/
vector family is a separate required scope, not covered by this result.

Full coupled/chiral restoration, QAP/products/measure/phase, physical
normalization, massiveC1,E5/A5 and unification remain unqualified. Both
adverse scalar points, quartetFAIL, flavor pause, HB1/C5 blocks, custody
and distinct free constants remain. No physical input, accepted benchmark,
branch/worktree, outreach/publication or push changed.
