"""HWB1 independent cycle inventory and full source/parent comparison."""
from data import *
from itertools import product
t=begin('replay');words=[]
# Enumerate ordered G,V pairs and close the complete cycle without primary's
# directed DFS. Every allowed vertex carries h or P, so n<=3 is dimensional.
pairs=[(a,b,gt+'/'+vt,degree) for a,k,gt in G for kk,b,vt,degree in V if k==kk]
for out,inn,root,degree in M:
 for n in [2,3]:
  for seq in product(pairs,repeat=n):
   if seq[0][0]!=inn or seq[-1][1]!=out or any(seq[j][1]!=seq[j+1][0] for j in range(n-1)):continue
   dd=tuple(degree[j]+sum(z[3][j] for z in seq) for j in range(2))
   if dd==(1,2):words.append({'root':root,'n':n,'path':[z[2] for z in seq],'sign':(-1)**n,'heat_lengths':[2*n,2*n+2]})
words.sort(key=lambda z:z['root']);assert len(words)==3
ref=read(PK/'frozen_a10_e5_full_hessian/replay.json')['retained_reference'];idx={n:i for i,n in enumerate(ref['field_order'])};green=dec(ref['reference_Green_raw_C3']);p=s.symbols('p0_ref0:4');anti=[f'bar{a}' if a<12 else f'ub{a}' for a in range(45)];lam=[f'b{a}' if a<12 else f'L{a}' for a in range(45)]
CG=s.SparseMatrix(45,45,lambda a,b:green[idx[f'C{a}'],idx[anti[b]]]);AC=s.SparseMatrix(45,45,lambda a,b:green[idx[anti[a]],idx[f'C{b}']]);zero(AC+CG.T)
for mu in range(4):zero(s.SparseMatrix(45,45,lambda a,b:green[idx[lam[a]],idx[f'B{b}_{mu}']])+s.I*p[mu]*CG.T)
eps=s.Symbol('epsilon',positive=True);rad2=s.simplify(s.limit(s.gamma(eps)*(4**(-eps)-6**(-eps)),eps,0));rad3=s.simplify(s.limit(s.gamma(eps)*(6**(-eps)-8**(-eps)),eps,0))
fmu=packed(CAL/'canonical_so10_fermion_mass_uv/replay_tables.json.gz');u=list(map(s.sympify,fmu['angular_units']));D=next(iter(u[4].free_symbols));assert s.simplify(u[4]-u[5])==0
# The combined left/right color orbit is i B K. This coefficient is extracted
# before any symmetry comparison, from actual FMU Wick/angular kernels.
aux=s.simplify(s.I*u[4]);pole=s.simplify(aux.subs(D,4));fixed=s.simplify(-2*s.diff(aux,D).subs(D,4))
yhc=packed(CAL/'canonical_so10_yukawa_vertex_heat_comparison/replay_v3_tables.json.gz');assert yhc['heat_length']==6 and yhc['pureY3']['critical_tensor_pointwise_zero']
v=packed(CAL/'canonical_so10_vacuum_tangent_source_finite/selected_vacuum_source_relative_member.json.gz');assert v['relative_action_addition_sign']==1
hr=read(CAL/'canonical_so10_vacuum_tangent_insertion_routing/validation_receipt.json');assert hr['status']=='QUALIFIED_ROUTING_RECONCILED_SELECTED_DIMENSIONAL_hPP_INSERTION'
chi,ell=s.symbols('chi4 ell');parent=pole*(chi+ell)+fixed+chi
dim=s.Rational(-1,2);heat=s.expand(dim-parent);assert not heat.has(chi)
# Exact nonlinear extended polarization fixture: explicit external z derivative
# commutes with field Hessians; source Hessians retain R''Euler.
x=s.symbols('x0:3');z=s.Symbol('z');S=(x[0]+z)**4/4+x[0]*x[1]*x[2]+(x[1]+z)**3/3+x[2]**2/2
R=s.Matrix([x[0]**3+x[1]*x[2]-1,x[0]*x[1]+z*x[2],x[1]**2+z]);H=s.hessian(S,x);Euler=s.Matrix([s.diff(S,a) for a in x]);J=R.jacobian(x);I=s.diff(S,z)+(R.T*Euler)[0]
field=H.applyfunc(lambda a:s.diff(a,z)+sum(R[j]*s.diff(a,x[j]) for j in range(3)))
conn=sum((Euler[j]*s.hessian(R[j],x) for j in range(3)),s.zeros(3));zero(field+conn-s.hessian(I,x)+J.T*H+H*J)
source_omit=sum(s.expand(a)!=0 for a in conn);external_omit=sum(s.expand(a)!=0 for a in H.diff(z));assert source_omit and external_omit
finish('replay',{'method':'independent_closed_cycles_transpose_free_Ward_Gamma_and_extended_parent_comparison','words':words,'raw_transpose_Ward_positions':8100,'ghost_transpose_positions':2025,'radial_n2':str(s.expand_log(rad2,force=True)),'radial_n3':str(s.expand_log(rad3,force=True)),'auxiliary_pole_unit':str(pole),'auxiliary_fixed_unit':str(fixed),'b_ext_Crel_BK_unit':str(parent),'Rdim_BK_unit':str(dim),'Rheat_BK_unit':str(heat),'source_omission_changed_Hessian_positions':source_omit,'external_derivative_omission_positions':external_omit,'source_Hessian_and_domain_proof':'DERIVATION sections1-4','all_tangent_color_reduction':'INHERITED_YCT_VTS_NOT_REPLAYED'},t)
