"""HWB1 actual free Ward blocks and direct paired-mode ordered supertraces."""
from data import *
from itertools import combinations,permutations
t=begin('primary');d=packed(CAL/'canonical_so10_cutoff_source_ward_operator/primary_inputs.json.gz');constants=[]
for name,rows in d['field_maps'].items():
 for row in rows:
  if len(row['word'])==1:constants.append((name,row['word'][0],row['coefficient']))
assert len(constants)==225
for out,inn,c in constants:
 if out.startswith('B'):assert '__' in inn and inn.startswith('C') and c=='1'
 else:assert out.startswith(('bar','ub')) and inn.startswith(('b','L')) and c=='-1'
edges=[(a,b,gt+'/'+vt,degree) for a,k,gt in G for kk,b,vt,degree in V if k==kk];words=[]
for out,inn,root,deg in M:
 def walk(node,path,dd):
  if node==out and dd==(1,2):words.append({'root':root,'n':len(path),'path':path,'sign':(-1)**len(path),'heat_lengths':[2*len(path),2*len(path)+2]})
  if len(path)==3:return
  for a,b,tag,e in edges:
   nd=tuple(x+y for x,y in zip(dd,e))
   if a==node and nd[0]<=1 and nd[1]<=2:walk(b,path+[tag],nd)
 walk(inn,[],deg)
words.sort(key=lambda x:x['root']);assert len(words)==3
# Authenticate the raw reference Ward block, not a chosen unit ghost metric.
ref=read(PK/'frozen_a10_e5_full_hessian/primary.json')['retained_reference'];idx={n:i for i,n in enumerate(ref['field_order'])};green=dec(ref['reference_Green_raw_C3']);p=s.symbols('p0_ref0:4');P=p[0]**2-sum(x*x for x in p[1:]);anti=[f'bar{a}' if a<12 else f'ub{a}' for a in range(45)];lam=[f'b{a}' if a<12 else f'L{a}' for a in range(45)]
CG=s.SparseMatrix(45,45,lambda a,b:green[idx[f'C{a}'],idx[anti[b]]])
for mu in range(4):zero(s.SparseMatrix(45,45,lambda a,b:green[idx[f'B{a}_{mu}'],idx[lam[b]]])-s.I*p[mu]*CG)
print('STAGE ACTUAL_REFERENCE_WARD_BLOCK_AND_THREE_WORDS',flush=True)
pa=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
gam=[s.kronecker_product(pa[1],z) for z in pa]+[s.kronecker_product(pa[0],s.eye(2))];C4=gam[1]*gam[3];PL=s.diag(1,1,0,0);PR=s.eye(4)-PL
zero(C4.T+C4)
for g in gam:zero((C4*g).T-C4*g)
Tcases=[s.Matrix([[1,1+s.I],[1-s.I,-2]]),s.Matrix([[2,-s.I],[s.I,-1]])]
Ycases=[s.Matrix([[1+s.I,2-s.I],[2-s.I,-1+2*s.I]]),s.Matrix([[2,-1+s.I],[-1+s.I,3-s.I]])]
fixtures=[];control={'ordinary_trace':0,'wrong_matter_root_order':0,'omit_auxiliary_root':0,'wrong_auxiliary_tangent_sign':0};nzroot3=0
for case,(T,Y) in enumerate(zip(Tcases,Ycases)):
 cc=s.kronecker_product(C4,s.eye(2));gg=s.kronecker_product(gam[0],s.eye(2));A=s.kronecker_product(PL,T)-s.kronecker_product(PR,T.T);tau=s.kronecker_product(PL,Y)+s.kronecker_product(PR,s.conjugate(Y));F=cc*tau;FB=cc*(-s.I*gg*A);ff=-s.I*gg*cc.inv()
 target=cc*(s.kronecker_product(PL,-s.I*(T.T*Y+Y*T))+s.kronecker_product(PR,s.I*(T*s.conjugate(Y)+s.conjugate(Y)*T.T)))
 zero(target+target.T);n=13;par=[0,0,0]+[1]*10;par=par*2;at=lambda mode,i:mode*n+i
 Gm={}
 for mode,q in enumerate([-1,1]):
  other=1-mode
  for a,b,z in [(0,0,3),(0,1,-q),(1,0,q),(2,2,1),(3,4,1),(4,3,-1)]:Gm[at(mode,a),at(other,b)]=ex(0,z)
  for i,j,z in ((i,j,q*ff[i,j]) for i in range(8) for j in range(8) if ff[i,j]):Gm[at(mode,5+i),at(other,5+j)]=ex(0,z)
 for a,b in combinations(range(8),2):
  # External algebra order epsilon,h,P_a,P_b, with no floating arithmetic.
  pe=[{} for _ in range(8)];pe[a]=ex(4,1);pe[b]=ex(8,1)
  def lin(mat,i):return add(*(mul(ex(0,mat[i,j]),pe[j]) for j in range(8) if mat[i,j]))
  vh={};vy={};vg={};mp={};mb={};ml={}
  for mode,q in enumerate([-1,1]):
   other=1-mode;vh[at(mode,2),at(other,4)]=ex(2,1);vh[at(mode,4),at(other,2)]=ex(2,-1)
   for i in range(8):
    fy=lin(F,i);fg=lin(FB,i)
    if fy:vy[at(mode,2),at(other,5+i)]=scale(fy,-1);vy[at(mode,5+i),at(other,2)]=fy
    if fg:vg[at(mode,0),at(other,5+i)]=scale(fg,-1);vg[at(mode,5+i),at(other,0)]=fg
    pp=mul(ex(1,-s.I),lin(A,i))
    if pp:mp[at(mode,5+i),at(mode,3)]=pp
   mb[at(mode,0),at(mode,3)]=ex(1,s.I*q);ml[at(mode,4),at(mode,1)]=ex(1,s.I)
  XX=[mm(Gm,z) for z in [vh,vy,vg]]
  two=ma(*(mm(mm(XX[i],XX[j]),mp) for i,j in [(0,1),(1,0)]))
  three={}
  for i,j,k in permutations(range(3)):three=ma(three,mm(mm(XX[i],XX[j]),XX[k]))
  wb=ms(mm(three,mb),-1);wl=ms(mm(three,ml),-1)
  c2=halfco(trace(two,par));cb=halfco(trace(wb,par));cl=halfco(trace(wl,par));want=gc(target[a,b])
  assert c2==want,(case,a,b,c2,want);assert ca(cb,cl)==(0,0)
  nzroot3+=int(cb!=(0,0));control['ordinary_trace']+=int(halfco(trace(two,par,True))!=want);control['wrong_matter_root_order']+=int((-c2[0],-c2[1])!=want);control['omit_auxiliary_root']+=int(cb!=(0,0));control['wrong_auxiliary_tangent_sign']+=int(ca(cb,(-cl[0],-cl[1]))!=(0,0))
  fixtures.append({'case':case,'pair':[a,b],'n2':list(c2),'n3_gauge':list(cb),'n3_auxiliary':list(cl)})
assert all(control.values())
aa=s.Symbol('a',positive=True);rad2=s.integrate(1/aa,(aa,4,6));rad3=s.integrate(1/aa,(aa,6,8))
finish('primary',{'method':'actual_raw_free_Ward_blocks_paired_mode_integer_Grassmann_supertrace_and_Frullani','words':words,'constant_tangent_positions':225,'raw_free_Ward_positions':8100,'fixtures':fixtures,'fixture_external_pairs':len(fixtures),'n3_individually_nonzero_pairs':nzroot3,'controls_changed_pairs':control,'radial_n2':str(s.expand_log(rad2,force=True)),'radial_n3':str(s.expand_log(rad3,force=True)),'heat_BK_coefficient':'log(3/2)','all_tangent_color_reduction':'INHERITED_YCT_VTS_NOT_REPLAYED','source_Hessian_and_domain_proof':'DERIVATION sections1-4'},t)
