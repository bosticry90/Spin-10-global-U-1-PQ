from data import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_tables.json.gz');R=packed(HERE/'replay_tables.json.gz');assert P['method']!=R['method'] and P['words']==R['words']
assert len(P['words'])==3 and sorted(w['n'] for w in P['words'])==[2,3,3]
assert {w['root'] for w in P['words']}=={'M_FC','M_BC','M_aL'}
assert P['raw_free_Ward_positions']==R['raw_transpose_Ward_positions']==8100 and R['ghost_transpose_positions']==2025
assert P['fixture_external_pairs']==56 and P['n3_individually_nonzero_pairs']>0 and all(P['controls_changed_pairs'].values())
for row in P['fixtures']:
 assert row['n3_gauge'][0]+row['n3_auxiliary'][0]==row['n3_gauge'][1]+row['n3_auxiliary'][1]==0
assert s.simplify(s.sympify(P['radial_n2'])-s.sympify(R['radial_n2']))==0
assert s.simplify(s.sympify(P['radial_n3'])-s.sympify(R['radial_n3']))==0
ell,chi=s.symbols('ell chi4');direct=s.sympify(P['heat_BK_coefficient']);pred=s.sympify(R['Rheat_BK_unit']).subs(ell,s.log(s.Rational(3,2)))
assert s.simplify(direct-pred)==0 and s.simplify(s.sympify(R['b_ext_Crel_BK_unit'])+ell+s.Rational(1,2))==0
assert R['auxiliary_pole_unit']=='-1' and R['auxiliary_fixed_unit']=='-1/2' and R['source_omission_changed_Hessian_positions']>0 and R['external_derivative_omission_positions']>0
# Literal finite angular parent units agree before any finite-part or source
# comparison. The kinetic counterpart includes its actual covariance i.
fmu=packed(CAL/'canonical_so10_fermion_mass_uv/primary_tables.json.gz');u=list(map(s.sympify,fmu['angular_units']));d=next(iter(u[0].free_symbols));yy=packed(CAL/'canonical_so10_yukawa_vertex_heat_comparison/primary_tables.json.gz')['angular'];D=s.Symbol('D')
for n,z in [('exchange_F',u[0]),('exchange_L',u[1]),('scalar_left',s.I*u[2]),('scalar_right',s.I*u[3])]:assert s.simplify(z.subs(d,D)-s.sympify(yy[n]['uD']))==0
# These are dimensions/support of the complete selected source projection,
# not a proposed counterterm basis for every source identity.
dimensions={'KP_hP':s.Rational(3,2)+2+s.Rational(3,2),'Ja_PP':2+3,'JL_hPP':1+2+3,'JB_h':2+2,'Jx_h':2+2}
assert dimensions['KP_hP']>4 and dimensions['Ja_PP']>4 and dimensions['JL_hPP']>4 and dimensions['JB_h']==dimensions['Jx_h']==4
assert s.simplify((-chi-ell-s.Rational(1,2))+chi-(-ell-s.Rational(1,2)))==0
assert s.simplify(-s.Rational(1,2)-direct-(-s.log(s.Rational(3,2))-s.Rational(1,2)))==0
controls={'source_omitted_leaves_chi4':True,'wrong_heat4_omits_nonzero_log':True,'extra_open_half_changes_nonzero_tensor':True,'one_constant_root_omission_nonzero':True,'external_h_derivative_omission_nonzero':True}
# Bind and inspect full inherited color kernel and both general-family maps;
# assembling their4352 coefficients is HPR reuse, not another model replay.
hr=read(CAL/'canonical_so10_vacuum_tangent_insertion_routing/validation_receipt.json');assert hr['total_holomorphic_nonzero_positions']==4352
vts=read(CAL/'canonical_so10_vacuum_tangent_source_kernel/validation_receipt.json');assert vts['full_scalar_positions_compared']==107584
recipe={'schema':'HWB1_SELECTED_FULL_TANGENT_FIRST_VARIATION_HEAT_WARD_BRIDGE','overall_factor':'g10^2*xi*Y_R/(16*pi^2)',
 'source_domain':'PROVISIONAL_VTS_ONE_EUCLIDEAN_SCHWARTZ_VARIATION_PHYSICAL_ZERO_JET_hPP',
 'inherited_color_tensor':'B_R*(Cs_I-Cs_H)','Rheat_unit':'log(3/2)','Rdim_unit':'-1/2','b_ext_Crel_unit':'-log(3/2)-1/2',
 'ordered_words':P['words'],'proof':'DERIVATION.md','color_replay':'INHERITED_YCT_VTS_HPR_NOT_NEW_335872_POSITION_RUN',
 'physical_scheme_adopted':False,'restoring_counterterm_constructed':False,'full_massive_QAP_or_E5A5_qualified':False,'scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps(recipe,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_tangent_heat_ward_bridge.json.gz').open('xb') as f:f.write(blob)
result={'status':'QUALIFIED_SELECTED_FULL_TANGENT_HEAT_WARD_BRIDGE','ordered_words':3,'n2_words':1,'n3_words':2,'n3_sum_zero':True,'direct_rooted_heat_coefficient':'log(3/2)*B_R*K_scalar',
 'complete_selected_parent_variation':'-(log(3/2)+1/2)*B_R*K_scalar','dimensional_insertion':'-(1/2)*B_R*K_scalar','comparison_remainder':0,
 'new_exact_trace_fixture_pairs':56,'actual_raw_Ward_positions_checked':16200,'ghost_transpose_positions_checked':2025,
 'all_tangent_directions':328,'carriers':2,'inherited_holo_nonzero_positions':4352,'new_45_generator_or_full_tensor_replay':False,
 'negative_controls':{**P['controls_changed_pairs'],**controls},'conditional_inherited_master_and_YCT_premises':True,'first_variation_domain_only':True,
 'restoring_counterterm_constructed':False,'full_massive_QAP_measure_phase_or_E5A5_qualified':False,'physical_scheme_adopted':False,'authority':'34/39','scientific_acceptance':'NOT_PERFORMED',
 'artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest(),'elapsed_after_imports':time.perf_counter()-t}
print('RESULT '+json.dumps(result,sort_keys=True),flush=True)
