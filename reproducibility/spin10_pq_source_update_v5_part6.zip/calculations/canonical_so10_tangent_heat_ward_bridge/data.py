"""HWB1 immutable IO and exact Gaussian-integer exterior matrices."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,gzip,os,sys,time,threading
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dec(m):return s.SparseMatrix(*m['shape'],{(i,j):s.sympify(z) for i,j,z in m['entries']})
def zero(m):assert not s.SparseMatrix(m).applyfunc(s.simplify).todok()
def begin(role):
 t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()
 assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def audit(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and p.name.startswith(peer):raise PermissionError('HWB1_PEER_DENIED')
   if role=='primary' and p.parent.name in ['canonical_so10_fermion_mass_finite_comparison','canonical_so10_vacuum_tangent_insertion_routing']:raise PermissionError('HWB1_COMPARISON_TARGET_DENIED')
 sys.addaudithook(audit);return t
def finish(role,d,t):
 d.update({'elapsed_after_imports':time.perf_counter()-t,'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','physical_scheme_adopted':False,'full_massive_QAP_measure_phase_or_E5A5_qualified':False})
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'elapsed_after_imports':d['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True)
def ca(a,b):return (a[0]+b[0],a[1]+b[1])
def cm(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def gc(z):
 z=s.expand(z);a,b=z.as_real_imag();assert a.is_Integer and b.is_Integer;return (int(a),int(b))
def ex(mask,z):
 v=gc(z);return {mask:v} if v!=(0,0) else {}
def add(*aa):
 out={}
 for a in aa:
  for k,v in a.items():out[k]=ca(out.get(k,(0,0)),v)
 return {k:v for k,v in out.items() if v!=(0,0)}
def scale(a,n):return {k:(n*v[0],n*v[1]) for k,v in a.items() if n}
def mul(a,b):
 out={}
 for x,v in a.items():
  for y,w in b.items():
   if x&y:continue
   sign=(-1)**sum((y&((1<<i)-1)).bit_count() for i in range(4) if x>>i&1);z=cm(v,w);out[x|y]=ca(out.get(x|y,(0,0)),(sign*z[0],sign*z[1]))
 return {k:v for k,v in out.items() if v!=(0,0)}
def mm(a,b):
 byrow=defaultdict(list)
 for (j,k),v in b.items():byrow[j].append((k,v))
 out={}
 for (i,j),v in a.items():
  for k,w in byrow.get(j,[]):out[i,k]=add(out.get((i,k),{}),mul(v,w))
 return {k:v for k,v in out.items() if v}
def ma(*aa):
 out={}
 for a in aa:
  for k,v in a.items():out[k]=add(out.get(k,{}),v)
 return {k:v for k,v in out.items() if v}
def ms(a,n):return {k:scale(v,n) for k,v in a.items() if n}
def trace(a,par,ordinary=False):return add(*(scale(v,1 if ordinary else (-1)**par[i]) for (i,j),v in a.items() if i==j))
def halfco(a):
 z=a.get(15,(0,0));assert z[0]%2==z[1]%2==0;return (z[0]//2,z[1]//2)
G=[('B','B','BB'),('B','L','BL'),('L','B','LB'),('C','a','Ca'),('a','C','aC'),('F','F','FF'),('X','X','XX')]
V=[('a','X','h_aX',(1,0)),('X','a','h_Xa',(1,0)),('X','F','Y_XF',(0,1)),('F','X','Y_FX',(0,1)),('B','F','g_BF',(0,1)),('F','B','g_FB',(0,1))]
M=[('F','C','M_FC',(0,1)),('B','C','M_BC',(0,0)),('a','L','M_aL',(0,0))]
