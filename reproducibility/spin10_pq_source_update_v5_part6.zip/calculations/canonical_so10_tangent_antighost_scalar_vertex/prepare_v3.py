from pathlib import Path
from hashlib import sha256
import json,ast,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='b16acf055762b179bc0a3838b07e1f01517525c0';assert json.loads((HERE/'validation_receipt_v2.json').read_bytes())['status']=='QUALIFIED_SELECTED_PROPER_TANGENT_ANTIGHOST_SCALAR_RELATIVE_VERTEX'
b=dict(json.loads((HERE/'validation_preparation_v2.json').read_bytes())['input_sha256'])
for p,h in b.items():assert digest(Path(p))==h,p
for p in HERE.iterdir():
 if p.is_file():b[str(p)]=digest(p)
for p in [CAL/'canonical_so10_cutoff_source_ward_operator/replay_inputs.json.gz',CAL/'canonical_so10_auxiliary_tangent_source_kernel/annihilator_v2_tables.json.gz',CAL/'canonical_so10_auxiliary_tangent_source_kernel/annihilator_v2.py',CAL/'canonical_so10_auxiliary_tangent_source_kernel/CONTINUATION_V2.md']:b[str(p)]=digest(p)
for n in ['VACUUM_CONTINUATION_V3.md','vacuum_data_v3.py','vacuum_primary_v3.py','vacuum_replay_v3.py','vacuum_verify_v3.py','prepare_v3.py','run_v3.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw)
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 b[str(HERE/(n+'.source.txt'))]=digest(HERE/(n+'.source.txt'))
with (HERE/'preparation_v3.json').open('xb') as f:f.write((json.dumps({'schema':'TAV1_V3_PREPARATION','input_sha256':dict(sorted(b.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('TAV1_V3_FROZEN',len(b),'bindings',flush=True)
