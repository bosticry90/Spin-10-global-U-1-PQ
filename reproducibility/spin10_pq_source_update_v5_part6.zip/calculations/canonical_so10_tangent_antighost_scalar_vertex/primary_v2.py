from data_v2 import *
t=begin('primary');gf=packed(CAL/'canonical_so10_cutoff_source_ward_operator/primary_inputs.json.gz')['GF'];jets,H,counts,audit=gf_literal(gf);FC=clean({k:jets['c'].get(k,0)-jets['B'].get(k,0) for k in set(jets['c'])|set(jets['B'])});FCbad={k:-z for k,z in jets['B'].items()}
p=read(PK/'frozen_a10_physical_reconciliation/full_primary.json');Q=dec(p['C3_plane_to_parent']);Qi=Q.inv();FM=dec(read(PK/'frozen_a10_e1_fermion/primary.json')['charts']['blocks']['heavy_dual']['field_embedding']);U=dec(packed(CAL/'canonical_so10_ghost_triangle_field_insertion/primary_tables.json.gz')['raw_aux_map'])
ref=read(PK/'frozen_a10_e5_full_hessian/primary.json')['retained_reference'];fi={n:i for i,n in enumerate(ref['field_order'])};green=dec(ref['reference_Green_raw_C3']);pm=s.symbols('p0_ref0:4');P=pm[0]**2-sum(z*z for z in pm[1:]);anti=[f'bar{a}' if a<12 else f'ub{a}' for a in range(45)];lam=[f'b{a}' if a<12 else f'L{a}' for a in range(45)]
CG=s.SparseMatrix(45,45,lambda c,a:co(P*green[fi[f'C{c}'],fi[anti[a]]]))
for mu in range(4):zero(s.SparseMatrix(45,45,lambda a,b:green[fi[lam[a]],fi[f'B{b}_{mu}']])+s.I*pm[mu]*CG.T/P)
bb={(mu,nu):s.SparseMatrix(45,45,lambda a,b:green[fi[f'B{a}_{mu}'],fi[f'B{b}_{nu}']]) for mu in range(4) for nu in range(4)}
Wraw=tidy(-bb[0,0].subs({pm[0]:1,pm[1]:0,pm[2]:0,pm[3]:0}));HP=dec(packed(CAL/'canonical_so10_yukawa_carrier_transport/primary_tables.json.gz')['H_new']);PH=HP*HP.T;PM=s.eye(45)-PH;zero(Wraw-Qi*(WH*PH+WM*PM)*Qi.T)
for nu in range(4):zero(sum(([1,-1,-1,-1][mu]*pm[mu]*bb[mu,nu] for mu in range(4)),ZERO(45))+Wraw*pm[nu]/P)
Wtabs=[tidy(Wraw.diff(WH)),tidy(Wraw.diff(WM))];zero(Wraw-WH*Wtabs[0]-WM*Wtabs[1]);print('STAGE ACTUAL_LONGITUDINAL_GREEN',flush=True)
wordsets={}
for family in ['ordinary','auxiliary']:
 edges=[(a,b,gt+'/'+vt,d) for a,k,gt in G for kk,b,vt,d in vertices(family) if k==kk];words=[]
 for start in sorted(set(a for a,b,tag in G)):
  def walk(node,mask,path):
   if mask==7:
    if node==start:words.append({'start':start,'path':path})
    return
   for a,b,tag,d in edges:
    if a==node and not mask&d:walk(b,mask|d,path+[tag])
  walk(start,0,[])
 wordsets[family]=canonical(words)
wick=[]
for order in itertools.permutations(range(3)):
 w=[]
 for i in order:w+=([0,3] if i==0 else [1,2] if i==1 else [])
 wick.append((-1)**sum(w[i]>w[j] for i in range(4) for j in range(i+1,4)))
unit=s.Rational(sum(wick),6);phases=[co(unit*s.I*s.I),co(unit*s.I*(-1)*s.I)];assert phases==[-1,1]
allblocks=[];omitjet=0;reverse=0
for sec,n in SECTORS:
 R=list(map(dec,p['representation_matrices'][sec]));RR=[tidy(sum((Q[d,b]*R[d] for d in range(45) if Q[d,b]),ZERO(n))) for b in range(45)];TT=[tidy(sum((FM[d,a]*R[d] for d in range(45) if FM[d,a]),ZERO(n))) for a in range(33)];GT=[tidy(sum((CG[c,12+a]*TT[a] for a in range(33) if CG[c,12+a]),ZERO(n))) for c in range(45)]
 for z in R+TT:zero(z+z.T)
 WR=[[tidy(sum((w[r,b]*RR[b] for b in range(45) if w[r,b]),ZERO(n))) for r in range(45)] for w in Wtabs];AR=[tidy(sum((CG[b,r]*RR[b] for b in range(45) if CG[b,r]),ZERO(n))) for r in range(45)]
 def contract(tab,cur,rev=False):
  raw=[ZERO(n) for _ in range(45)];cache={}
  for (r,a,c),z in tab.items():
   if (r,c) not in cache:cache[r,c]=GT[c].T*cur[r] if rev else cur[r].T*GT[c]
   raw[a]+=z*cache[r,c]
  return [tidy(sum((U[a,e]*raw[a] for a in range(45) if U[a,e]),ZERO(n))) for e in range(45)]
 mats=[contract(FC,w) for w in WR]+[contract(H,AR)];bad=[contract(FCbad,w) for w in WR];rev=[contract(FC,w,True) for w in WR]+[contract(H,AR,True)]
 omitjet+=sum(len(tidy(m-b).todok()) for ms,bs in zip(mats[:2],bad) for m,b in zip(ms,bs));reverse+=sum(len(tidy(m-b).todok()) for ms,bs in zip(mats,rev) for m,b in zip(ms,bs))
 allblocks.append({'sector':sec,'ordinary_H':list(map(enc,mats[0])),'ordinary_M':list(map(enc,mats[1])),'auxiliary':list(map(enc,mats[2]))});print('STAGE RAW_COLOR',sec,flush=True)
z=s.symbols('z',positive=True);lim=s.limit((1+z)*s.exp(z)*s.expint(1,z)-1+s.log(z),z,0,dir='+');assert lim==-s.EulerGamma-1;nlog=s.Symbol('n_log');chi6=co((-s.EulerGamma+s.log(4*s.pi))-(-s.EulerGamma-s.log(6)-1+nlog))
finish('primary',{'method':'literal_GF_all_jets_actual_raw_longitudinal_Green_and_heavy_dual_contraction','words':wordsets,'proper_graphs':{f:pairings(f) for f in wordsets},'GF_counts':counts,'GF_field_jet_inventory':audit,'raw_Fc':rows(FC),'raw_H':rows(H),'color':allblocks,'wick_signs':wick,'universal_phases':list(map(str,phases)),'dimension_angular_unit':'1','dimension_angular_derivative':'0','heat_edges':3,'heat_length':6,'chi6':str(chi6),'raw_Green_longitudinal_slots':45**2*4,'controls':{'omit_ghost_derivative_changed_positions':omitjet,'reverse_color_changed_positions':reverse},'affine_v_evaluation_qualified':False,'common_h_family_qualified':False},t)
