# TAV1 V3: complete the selected affine-vacuum companion

V2 actual raw and plane calculations/gate completed. Ordinary_H36320NZ,
ordinary_M0,auxiliary17658NZ; all9,021,240block positions agree, plus
5,502,600crossblock zeros bytypes. Universal phases-1/+1,chi6 retained.
No common h-family is thereby proved. Do not select finite normalizations.

Next question: what is the COMPLETE proper coefficient h*antighost*v at
the same frozen vacuum, expanded about the fixed Cartesian K0, without
resumming v/GF terms? Evaluation of TAV1 x=v is only one contribution.
Also include the explicit positive-dimension GF vertices from the actual
action: a*C*X(v) and Lambda*X(v). Total coefficient dimension1 permits
exactly one such vertex; ordinary kinetic B*X(v) is the evaluated TAV term.
Scalar/fermion/gauge mass insertions have degree2; unlabelled cubic vertices
with3quantum legs cannot enter a proper one-loop graph. A one-port h vertex
is a bridge. No new physical masses or affine prescription are selected.

GF aCX(v), with the externalantighost, joins the h*a*X vertex in a two-edge
ghost/scalar bubble. GF LambdaX(v) plus ordinary external-antighost BC gives
a three-edge triangle; the corresponding auxiliary LC orientation requires
a vanishing LambdaLambda free edge. Derive full ordered supports by the
two existing algorithms, retaining the actual ghost/dual phases. Do not
assign the extra trianglezero merely because the earlier ordinary_M tensor
waszero. The JL*h*v coefficient has evaluated ATS support (already measured
zero) plus the new LambdaX family; audit its new support independently.

Let Oraw[b,j]=GF coefficient Lambda_b*X_j/(g*xi), and DM[a,c,j] be the
Lorentzian antighost-first scalar GF coefficient/(g2*xi). Check directly
from actual action, not from a desired Ward relation:

 DM[d,c,:] = sum_a Nanti[a,d,c]*Oraw[a,:] - Oraw[d,:]*Rraw_c.

The qantighost nonlinear term MUST be retained before projection. Its ghost
port may vanish after the actual heavy ghost pairing; test it instead of
omitting it. At the base point Oraw equals the qualified heavy dual orbit.
Euclidean DM=-DM_L, while LambdaX has phase+i, from the fixed contours.

Prospective extra bubble kernel, with the original Lorentzian DM unit:
 Braw_d,A=sum_csj DM[d,c,j]*CG[c,s]*T_s,jA.
The ordered second cumulant in h,a_external order has universal phase+1
relativeDM_L. Its heatlength4 finite map is chi4, not chi6. Independent
plane calculation tests B_e=K_M*Oplane_e, K_M=-sum_c rho_c*(PM rho)_c,
after proving the Nanti port zero. No loop tensor is defined by this formula
without comparison to the actual literal coefficient.

Prospective extra triangle kernel is
 Traw_d,A=sum_rcb Fc[r,d,c]*CG[r,b]*(GT_c.T*Oraw_b)_A.
Its universal phase is-1, heatlength6. Independently compare with
sum_rc Fc_plane[r,e,c]*(PM rho)_c.T*Oplane_r. The identity to
ordinary_M[e].T*v is a check of the measured input, not a fitted zero.

The complete evaluated coefficient is, in16pi2 units,
 -g3xi eta_H chi6*OH.T*v -g3xi2 chi6*OM.T*v
 +g2xi2 chi6*X.T*v +g3xi2*(chi4*B-chi6*T).
Preserve all terms and derive all zeros. JL h v new positive-v support
plus its old ATS ghost-port zero is tested separately, not from a demanded
Slavnov cancellation. Symbolic chi4,b0,kappa and all other freedoms remain.

Scope is fixed point/firstvariation/local relative Euclidean family, not
all vacua or a full h-renormalized source identity. Actual scalar numerator
and positive-reference IR bounds apply before local UV projection. Both
extra groups have the same overall critical degree4 as their zero-jet grade;
no missing power/heat Taylor term shares that grade. Absolutely integrable
lower-symbol remainders cancel only in the relative construction. No
critical distribution/contact or reference determinant is discarded.

Freeze new proof/calculation sources and completed V2 evidence before native
execution. Same600s/8GiBsampled/350MiB/16MiB bounds and full controls. No
completed V2 work is rerun. Preserve mismatches, failed sources and captures;
V2qualification is not retrospectively expanded. Scientific authority34/39,
all protected scopes/stages and state113 unchanged. Next after this result:
the complete h-linear parent/source module and applicability of a common
renormalization constructor, not automatic assignment of new contact terms.
