from data_v2 import *
t=begin('replay');old=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/replay_tables.json.gz');raw={j:{tuple(r[:3]):co(r[3]) for r in old['raw_jets'][j]} for j in ['a','B','c']};FC=clean({k:raw['c'].get(k,0)-raw['B'].get(k,0) for k in set(raw['c'])|set(raw['B'])});HR={tuple(r[:3]):co(r[3]) for r in old['raw_H']};pj={j:{tuple(r[:3]):co(r[3]) for r in old['plane_jets'][j]} for j in raw};Fc=clean({k:pj['c'].get(k,0)-pj['B'].get(k,0) for k in set(pj['c'])|set(pj['B'])});H={tuple(r[:3]):co(r[3]) for r in old['plane_H']}
p=read(PK/'frozen_a10_physical_reconciliation/full_replay.json');HP=dec(packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz')['H_new']);PH=HP*HP.T;PM=s.eye(45)-PH;wordsets={}
for family in ['ordinary','auxiliary']:
 words=[];verts=vertices(family)
 for perm in itertools.permutations([1,2,4]):
  for vs in itertools.product(*[[v for v in verts if v[3]==i] for i in perm]):
   for gs in itertools.product(G,repeat=3):
    if all(gs[i][1]==vs[i][0] and vs[i][1]==gs[(i+1)%3][0] for i in range(3)):words.append({'start':gs[0][0],'path':[gs[i][2]+'/'+vs[i][2] for i in range(3)]})
 wordsets[family]=canonical(words)
allblocks=[];wrongfull=0;wrongwidth=0
for sec,n in SECTORS:
 R=list(map(dec,p['representation_matrices'][sec]));GT=[tidy(sum((PM[d,c]*R[d] for d in range(45) if PM[d,c]),ZERO(n))) for c in range(45)];WR=[[tidy(sum((w[r,b]*R[b] for b in range(45) if w[r,b]),ZERO(n))) for r in range(45)] for w in [PH,PM]]
 def contract(tab,cur,gt):
  out=[ZERO(n) for _ in range(45)];cache={}
  for (r,a,c),z in tab.items():
   if (r,c) not in cache:cache[r,c]=cur[r].T*gt[c]
   out[a]+=z*cache[r,c]
  return list(map(tidy,out))
 mats=[contract(Fc,w,GT) for w in WR]+[contract(H,R,GT)];bad=[contract(Fc,w,R) for w in WR]+[contract(H,R,R)];ident=contract(Fc,R,GT)
 wrongfull+=sum(len(tidy(a-b).todok()) for aa,bb in zip(mats,bad) for a,b in zip(aa,bb));wrongwidth+=sum(len(tidy(WH*a+WM*b-c).todok()) for a,b,c in zip(mats[0],mats[1],ident))
 allblocks.append({'sector':sec,'ordinary_H':list(map(enc,mats[0])),'ordinary_M':list(map(enc,mats[1])),'auxiliary':list(map(enc,mats[2]))});print('STAGE PLANE_COLOR',sec,flush=True)
# Literal paired-mode exact exterior Gaussian; no model tensor used for phases.
spec=importlib.util.spec_from_file_location('tav_exact',CAL/'canonical_so10_tangent_heat_ward_bridge/data.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e);at=lambda m,i:5*m+i;par=[0,0,0,1,1]*2;gaussian=[]
for width in [2,3]:
 for family in ['ordinary','auxiliary']:
  gm={};vh={};va={};vx={}
  for mode,q in enumerate([-1,1]):
   other=1-mode
   for a,b,z in [(0,0,width),(0,1,-q),(1,0,q),(2,2,1),(3,4,1),(4,3,-1)]:gm[at(mode,a),at(other,b)]=e.ex(0,z)
   vh[at(mode,2),at(other,4)]=e.ex(1,1);vh[at(mode,4),at(other,2)]=e.ex(1,-1);vx[at(mode,0),at(other,2)]=e.ex(0,s.I*q);vx[at(mode,2),at(other,0)]=e.ex(0,-s.I*q)
   if family=='ordinary':va[at(mode,0),at(other,3)]=e.ex(2,-s.I*q);va[at(mode,3),at(other,0)]=e.ex(2,-s.I*q)
   else:va[at(mode,1),at(other,3)]=e.ex(2,s.I);va[at(mode,3),at(other,1)]=e.ex(2,-s.I)
  val={};bad={}
  for vs in itertools.permutations([vh,va,vx]):
   mat=e.mm(e.mm(e.mm(gm,vs[0]),e.mm(gm,vs[1])),e.mm(gm,vs[2]));val=e.add(val,e.trace(mat,par));bad=e.add(bad,e.trace(mat,par,True))
  sym=lambda z:s.Rational(z[0])+s.I*s.Rational(z[1]);phase=co(sym(val.get(3,(0,0)))/12);ordinary=co(sym(bad.get(3,(0,0)))/12);gaussian.append({'family':family,'width':width,'phase':str(phase),'ordinary_trace':str(ordinary)})
# Relative radial difference, independent of the auxiliary-mass expansion.
alpha=s.symbols('alpha',positive=True);der=s.integrate(-s.exp(-alpha*s.Symbol('u',positive=True)),(s.Symbol('u',positive=True),0,s.oo));assert co(der+1/alpha)==0
ell=s.integrate(1/alpha,(alpha,4,6));assert co(ell-s.log(s.Rational(3,2)))==0;nlog=s.Symbol('n_log');chi6=co(1+s.log(16*s.pi)-nlog+ell)
observed=[{co(s.sympify(v['phase'])/(v['width'] if family=='ordinary' else 1)) for v in gaussian if v['family']==family} for family in ['ordinary','auxiliary']];assert all(len(v)==1 for v in observed)
finish('replay',{'method':'authenticated_independent_GTT_plane_jets_heavy_projector_and_paired_exterior_Gaussian','words':wordsets,'proper_graphs':{f:pairings(f) for f in wordsets},'raw_Fc':rows(FC),'raw_H':rows(HR),'color':allblocks,'gaussian':gaussian,'universal_phases':[str(next(iter(v))) for v in observed],'dimension_angular_unit':'1','dimension_angular_derivative':'0','heat_edges':3,'heat_length':6,'chi6':str(chi6),'controls':{'full_projector_changed_positions':wrongfull,'unit_width_changed_positions':wrongwidth},'affine_v_evaluation_qualified':False,'common_h_family_qualified':False},t)
