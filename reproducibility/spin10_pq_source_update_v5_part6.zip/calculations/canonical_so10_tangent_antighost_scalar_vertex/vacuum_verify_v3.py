from vacuum_data_v3 import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation_v3.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'vacuum_primary_v3_tables.json.gz');R=packed(HERE/'vacuum_replay_v3_tables.json.gz')
for key in ['words','bubble_phase','triangle_phase','bubble_heat_length','triangle_heat_length','JL_h_v_new_words','JL_h_v_evaluation_zero_inherited','fixed_vacuum_only']:assert P[key]==R[key],key
assert P['bubble_phase']=='1' and P['triangle_phase']=='-1' and P['bubble_heat_length']==4 and P['triangle_heat_length']==6 and P['nonlinear_antighost_bubble_port_nonzero']==0
assert P['raw_GF_scalar_reconstruction_positions']==664200 and P['GF_rows']=={'LambdaX':432,'aCX':6688}
counts={}
for key in ['extra_bubble','extra_triangle']:
 a,b=dec(P[key]),dec(R[key]);assert a.shape==b.shape==(45,328);zero(a-b);counts[key]=len(a.todok())
for key in ['ordinary_H','ordinary_M','auxiliary']:
 a,b=dec(P['evaluation'][key]),dec(R['evaluation'][key]);zero(a-b);counts[key]=len(a.todok())
# Direct triangle independently agrees with the transpose/evaluation of the
# previously measured complete ordinary_M class; not assigned from it.
zero(dec(P['extra_triangle'])-dec(P['evaluation']['ordinary_M']))
ell=s.log(s.Rational(3,2));chi=s.Symbol('chi4');GH=s.Symbol('g10');xi=s.Symbol('xi');eta=s.Symbol('eta_H');full=tidy(-(chi+ell)*GH**3*xi*eta*dec(P['evaluation']['ordinary_H'])-(chi+ell)*GH**3*xi**2*dec(P['evaluation']['ordinary_M'])+(chi+ell)*GH**2*xi**2*dec(P['evaluation']['auxiliary'])+GH**3*xi**2*(chi*dec(P['extra_bubble'])-(chi+ell)*dec(P['extra_triangle'])))
for z in full.todok().values():assert co(s.conjugate(z).subs({s.conjugate(chi):chi,s.conjugate(GH):GH,s.conjugate(xi):xi,s.conjugate(eta):eta})-z)==0
out={'status':'QUALIFIED_COMPLETE_SELECTED_AFFINE_TANGENT_GHOST_VACUUM_RELATIVE_MEMBER','elapsed_after_imports':time.perf_counter()-t,'support_counts':{k:len(v) for k,v in P['words'].items()},'coefficient_positions_each_group':14760,'direct_groups_compared':5,'coefficient_counts':counts,'complete_member_nonzero_positions':len(full.todok()),'full_GF_scalar_reconstruction_positions':664200,'nonlinear_antighost_orbit_term_retained_then_projected_zero':True,'bubble_heat_length':4,'triangle_heat_length':6,'wrong_common_heat_length_changed_positions':counts['extra_bubble'],'JL_h_v_qualified_zero_in_scope':True,'fixed_reference_vacuum_only':True,'same_counterterm_constants_retained':True,'physical_scheme_adopted':False,'common_full_h_QAP_family_qualified':False,'full_E5A5_qualified':False,'authority':'34/39','scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps({'coefficient_in_16pi2_units':enc(full),'groups':{k:P[k] for k in ['extra_bubble','extra_triangle','evaluation']},'proper_support':P['words'],'scope':out},sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_affine_tangent_vacuum_v3.json.gz').open('xb') as f:f.write(blob)
out.update({'artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest()});print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
