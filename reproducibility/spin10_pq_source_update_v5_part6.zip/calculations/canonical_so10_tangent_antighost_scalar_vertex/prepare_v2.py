from pathlib import Path
from hashlib import sha256
import json,ast,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='b16acf055762b179bc0a3838b07e1f01517525c0'
b=dict(json.loads((HERE/'preparation.json').read_bytes())['input_sha256'])
for p,h in b.items():assert digest(Path(p))==h,p
assert json.loads((HERE/'controller_failure.json').read_bytes())['last_role']=='primary'
assert json.loads((HERE/'primary_capture.json').read_bytes())['exit_code']==1
assert not any((HERE/n).exists() for n in ['primary_tables.json.gz','replay_capture.json','verify_capture.json','validation_receipt.json','validation_preparation.json'])
old="elif ks==['C','C','a','a'] and jets==0:tag='quartic_ghost_three_quantum_ports_or_bridge'";new="elif ks in [['C','C','a','a'],['B','B','C','a']] and jets==0:tag='quartic_no_scalar_three_quantum_ports_or_bridge'"
expected=(HERE/'data.py').read_text(encoding='utf-8').replace(old,new).replace("HERE/'preparation.json'","HERE/'preparation_v2.json'").replace("role+'_tables.json.gz'","role+'_v2_tables.json.gz'");assert expected==(HERE/'data_v2.py').read_text(encoding='utf-8')
for role in ['primary','replay']:assert (HERE/(role+'_v2.py')).read_text(encoding='utf-8')==(HERE/(role+'.py')).read_text(encoding='utf-8').replace('from data import *','from data_v2 import *')
for p in HERE.iterdir():
 if p.is_file():b[str(p)]=digest(p)
for n in ['CONTINUATION_V2.md','data_v2.py','primary_v2.py','replay_v2.py','verify_v2.py','prepare_v2.py','run_v2.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw)
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 b[str(HERE/(n+'.source.txt'))]=digest(HERE/(n+'.source.txt'))
with (HERE/'preparation_v2.json').open('xb') as f:f.write((json.dumps({'schema':'TAV1_V2_PREPARATION','input_sha256':dict(sorted(b.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('TAV1_V2_FROZEN',len(b),'bindings',flush=True)
