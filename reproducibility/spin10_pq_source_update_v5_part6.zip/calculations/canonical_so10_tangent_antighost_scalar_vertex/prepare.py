from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/tangent-antighost-scalar-vertex-v1-2026-10-24');BASE='b16acf055762b179bc0a3838b07e1f01517525c0'
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip();bind={}
def add(p,h=None):
 p=p.resolve();v=sha256(p.read_bytes()).hexdigest()
 if h is not None:assert v==h,p
 bind[str(p)]=v
for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V579.md']:add(ROOT/n)
add(ROOT/'project_state.json','d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8')
for role in ['primary','replay']:
 for n in ['frozen_a10_physical_reconciliation/full_'+role+'.json','frozen_a10_e1_fermion/'+role+'.json','frozen_a10_e5_full_hessian/'+role+'.json']:add(PK/n)
 for folder,n in [('canonical_so10_ghost_triangle_field_insertion',role+'_tables.json.gz'),('canonical_so10_yukawa_carrier_transport',role+'_tables.json.gz')]:add(CAL/folder/n)
add(CAL/'canonical_so10_cutoff_source_ward_operator/primary_inputs.json.gz')
for folder,names in {'canonical_so10_tangent_heat_ward_bridge':['data.py','DERIVATION.md','validation_receipt.json'],'canonical_so10_vacuum_tangent_source_kernel':['DERIVATION.md','validation_receipt.json'],'canonical_so10_vacuum_tangent_source_finite':['DERIVATION.md','validation_receipt.json'],'canonical_so10_auxiliary_tangent_source_kernel':['validation_receipt_v2.json','RESULT.md'],'canonical_so10_ghost_triangle_field_insertion':['DERIVATION.md','validation_receipt.json'],'canonical_so10_bosonic_source_onejet_finite':['DERIVATION.md','validation_receipt.json']}.items():
 for n in names:add(CAL/folder/n)
add(CAL/'canonical_so10_auxiliary_tangent_source_kernel/validation_receipt_v2.json','0fcc29e0d58407506d15c62910b4a65cca296cdc253c1eac9c92ca453a5f632f');add(PK/'export_a10_e5_antighost_vector.py')
for n in ['RECORD.md','DERIVATION.md','data.py','primary.py','replay.py','verify.py','prepare.py','run.py']:
 p=HERE/n;raw=p.read_bytes();assert b'\r' not in raw
 if p.suffix=='.py':ast.parse(raw)
 with (HERE/(n+'.source.txt')).open('xb') as f:f.write(raw)
 add(p);add(HERE/(n+'.source.txt'))
CONTROL.mkdir(parents=True,exist_ok=False);tree=git('ls-tree','-r',BASE);assert len(tree.splitlines())==33819
with (CONTROL/'old_git_tree.txt').open('xb') as f:f.write(tree)
with (HERE/'preparation.json').open('xb') as f:f.write((json.dumps({'schema':'TAV1_PREPARATION','base_commit':BASE,'input_sha256':dict(sorted(bind.items())),'seconds_each':600,'sampled_private_cap':8*1024**3,'launch_floor':350*1024**2,'packet_cap':16*1024**2,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True,indent=2)+'\n').encode())
print('TAV1_FROZEN',len(bind),'bindings',flush=True)
