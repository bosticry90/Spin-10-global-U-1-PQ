# TAV1 V2: classify the actual quartic vector/ghost interaction

Original preparation47bindings succeeded. Primarynative1 stopped in the
complete GF audit at the actual marginal BB*C*antighost quartic. No Green,
color, Gaussian or finite calculation completed; no replay/verifier ran;
no original output table/validation manifest/receipt/artifact exists. Preserve
original source copies, complete capture and controller_failure.json.

The original explicit whitelist recognized quartic a*a*C*C but missed
BB*a*C. This is an audit implementation error, not absence of the interaction
from the action. For a single externalantighost and no externalB, both these
quartics have three internal quantum ports. The proper one-loop degree proof
excludes them only after this is established. If the tangent supplies the
externalx it has one quantum port, and the connected graph contains a bridge.
Otherwise all vertices have degree>=2 and a degree3 quartic would raise the
loop count. A quartic containing scalarX could instead supply externalx too;
it is NOT covered by this exclusion and must still stop the audit if present.

V2 adds only the explicit BB*a*C source-target disposition alongside aaCC.
All other unclassified source-field patterns still fail. No action vertex,
source/Grassmann phase, Green kernel, parameter, expected evidence, equality,
resource bound or authority ceiling changes. Primary/replay/gate run with
new filenames/manifests/source copies. The new exact helper is generated from
the immutable original with this one whitelist extension and versioned IO;
primary/replay/gate mathematical bodies are unchanged. Full controls and
coverage remain required. No failure is relabeledPASS.

This low-cost pre-coefficient failure justifies correcting/restarting the
unfinished primary. There is no expensive qualified work to repeat. Same
600s/8GiB sampled/350MiB/16MiB bounds and original scientific domain. A new
unexpected pattern or mismatch remains a failed/incomplete bounded result.
