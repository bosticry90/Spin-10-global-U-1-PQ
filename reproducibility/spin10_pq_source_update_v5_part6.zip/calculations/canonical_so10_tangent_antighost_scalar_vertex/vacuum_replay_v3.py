from vacuum_data_v3 import *
t=begin3('replay');p=read(PK/'frozen_a10_physical_reconciliation/full_replay.json');v=dec(p['vacuum']['VEV']);HH=dec(packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz')['H_new']);PM=s.eye(45)-HH*HH.T;old=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/replay_tables.json.gz');jets={j:{tuple(r[:3]):co(r[3]) for r in old['plane_jets'][j]} for j in ['B','c']};FC=clean({k:jets['c'].get(k,0)-jets['B'].get(k,0) for k in set(jets['c'])|set(jets['B'])});bub=s.SparseMatrix(45,328,{});tri=s.SparseMatrix(45,328,{});off=0
for sec,n in SECTORS:
 R=list(map(dec,p['representation_matrices'][sec]));GT=[tidy(sum((PM[b,c]*R[b] for b in range(45) if PM[b,c]),ZERO(n))) for c in range(45)];K=tidy(-sum((R[c]*GT[c] for c in range(45)),ZERO(n)));zero(K-K.T);Os=s.SparseMatrix.vstack(*[(r*v[off:off+n,0]).T for r in GT]);bub[:,off:off+n]=tidy(Os*K);tm=s.SparseMatrix(45,n,{})
 for (r,a,c),z in FC.items():tm[a,:]+=z*Os[r,:]*GT[c]
 tri[:,off:off+n]=tidy(tm);off+=n
# Explicit paired-mode second/third logarithm coefficients.
spec=importlib.util.spec_from_file_location('tav_vac_exact',CAL/'canonical_so10_tangent_heat_ward_bridge/data.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e);at=lambda m,i:5*m+i;par=[0,0,0,1,1]*2;phases={}
for family in ['bubble','triangle']:
 gm={};vh={};va={};vvv={}
 for mode,q in enumerate([-1,1]):
  other=1-mode
  for a,b,z in [(0,0,3),(0,1,-q),(1,0,q),(2,2,1),(3,4,1),(4,3,-1)]:gm[at(mode,a),at(other,b)]=e.ex(0,z)
  vh[at(mode,2),at(other,4)]=e.ex(1,1);vh[at(mode,4),at(other,2)]=e.ex(1,-1)
  if family=='bubble':va[at(mode,2),at(other,3)]=e.ex(2,-1);va[at(mode,3),at(other,2)]=e.ex(2,1)
  else:
   va[at(mode,0),at(other,3)]=e.ex(2,-s.I*q);va[at(mode,3),at(other,0)]=e.ex(2,-s.I*q);vvv[at(mode,1),at(other,2)]=e.ex(0,s.I);vvv[at(mode,2),at(other,1)]=e.ex(0,s.I)
 val={};vsall=[vh,va] if family=='bubble' else [vh,va,vvv]
 for vs in itertools.permutations(vsall):
  mat=e.mm(gm,vs[0])
  for vert in vs[1:]:mat=e.mm(mat,e.mm(gm,vert))
  val=e.add(val,e.trace(mat,par))
 z=val.get(3,(0,0));phase=co((s.Rational(z[0])+s.I*s.Rational(z[1]))*s.Rational(-1,8) if family=='bubble' else (s.Rational(z[0])+s.I*s.Rational(z[1]))/12);phases[family]=str(phase)
words=walks3('permutation');assert not words['JL_new'];proof=packed(CAL/'canonical_so10_auxiliary_tangent_source_kernel/annihilator_v2_tables.json.gz');assert proof['plane_port_nonzero']==0
finish3('replay',{'method':'plane_Casimir_orbit_operator_and_independent_paired_mode_Gaussian','words':words,'extra_bubble':enc(bub),'extra_triangle':enc(tri),'evaluation':evaluate_tables('replay',v),'bubble_phase':phases['bubble'],'triangle_phase':phases['triangle'],'bubble_heat_length':4,'triangle_heat_length':6,'JL_h_v_new_words':0,'JL_h_v_evaluation_zero_inherited':True,'fixed_vacuum_only':True},t)
