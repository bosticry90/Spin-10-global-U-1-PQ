# The ordinary tangent vertex and its full selected vacuum companion are measured

The proper one-loop h*antighost*x local relative vertex is now calculated in
all declared scalar/ghost directions. Its vacuum companion includes two extra
gauge-fixing contributions; evaluating x=v alone would miss a nonzero finite
term. These are actual action-derived quantum inputs for the provisional
v/z/h construction. They do not establish a complete h-dependent source or
renormalization prescription. Scientific authority remains34/39.

## The dimension-zero ordinary vertex

Two triangle families occur, each with6 ordered trace words and one
unoriented proper graph. Ordinary ghost/vector/scalar propagation gives
phase-1; ghost/mixed-auxiliary/scalar propagation gives phase+1. The ordered
third cumulant and a separate literal +/- momentum exterior Gaussian agree.
The actual raw longitudinal Green matrix was checked in8100 Lorentz/color
slots before using its width dependence. Both inverse orientations remain.

In units1/(16pi2), the complete selected relative density is

 h_A*a_e*x_k*(chi4+log(3/2))
 *[-g3*xi*eta_H*OH[e,k,A]-g3*xi2*OM[e,k,A]+g2*xi2*X[e,k,A]].

The ordinary and auxiliary coupling orders are different. They have not been
combined by selecting a value ofg or a gauge width.

| Exact coefficient tensor | Nonzero positions |
| --- | ---: |
| OH, ordinary unbroken-vector width | 36,320 |
| OM, ordinary heavy-vector width | 0 |
| X, auxiliary family | 17,658 |

Raw literal-GF/Green/heavy-dual and independent plane-jet/projector methods
agree in9,021,240 within-sector coefficient positions. Another5,502,600 cross-
sector positions are zero by the actual scalar/primitive block types. Thus
the full typed three-class scope is14,523,840 positions; these are algebraic
positions, not independent experiments. The53978 nonzero coefficients pass
the physical-plane real-structure test. No scalar sector was discarded.

The actual all-GF audit retains5640 derivative ghost-vector rows,276 auxiliary
rows,6688 positive-dimension scalar rows,3576 background rows,188 kinetic/
one-port rows and15086 quartic rows in the external-antighost dispositions.
Background, coefficient dimension and proper-graph exclusions are distinct.
In particular, BB*a*C is in the action. With one externalantighost and no
externalB, it has three quantum ports; a one-port tangent would create a
bridge. It is not an omitted one-loop proper integral.

The current and GF momentum vectors contract the longitudinal numerator in
D dimensions before angular averaging, giving no first angular dimension
jet. Three positive heat edges give length6 and
chi6=chi4+log(3/2)=1+log(24pi)-n_log. Positive auxiliary-IR radial expansion
and an independent relative/nonexceptional heat comparison agree. No physical
scheme, common finite constant or scaleless integral is chosen.

Omitting the ghost derivative changes36320 positions; reversing the scalar
matrix order changes31226; replacing the width matrix byI changes36320;
omitting/flipping the auxiliary family changes17658. Wrong heatlength4
changes53978. Ordinary trace changes all4 universal Gaussian fixtures.
Replacing the heavy ghost projector byI changes0 actual positions here and
is INSENSITIVE, unlike the corresponding ATS1 control. This is disclosed;
the raw/plane equality and other sensitive controls are not replaced by it.

## The vacuum companion has a genuinely different finite term

At the same frozen vacuum, include the literal extra GF a*C*X(v) and
Lambda*X(v) vertices. The scalar GF coefficient reconstructs exactly as

 DM[d,c,:]=sum_a Nanti[a,d,c]*Oraw[a,:]-Oraw[d,:]*Rraw_c.

All664200 raw positions are checked. The nonlinear antighost orbit term is
retained before its heavy-ghost projection is provedzero. The actual counts
are6688 scalar-GF rows and432 auxiliary-scalar rows. The orbit matches the
original heavy-dual primitive, not a guessed primal embedding.

The extra scalar-GF bubble has4 ordered words, two edges and heatlength4.
Its universal phase is+1 relative to the original Lorentzian scalar-GF
coefficient, after the common Wick sign. The extra mixed triangle has6
words, three edges/length6 and phase-1. Independent paired Gaussian checks
and literal/raw versus plane-operator contractions agree. No uncomputed
contribution was assignedzero from the desired identity.

| Vacuum group | Nonzero positions |
| --- | ---: |
| OH evaluated atv | 0 |
| OM evaluated atv | 0 |
| X evaluated atv | 448 |
| Extra scalar-GF bubble B | 448 |
| Extra mixed triangle T | 0 |

Each group has14760 positions. The complete relative vacuum density is

 h_A*a_e/(16pi2) * xi2
 *[g2*(chi4+log(3/2))*Xv[e,A]+g3*chi4*B[e,A]].

It has448 nonzero positions for generic symbolic parameters. The independent
operator calculation gives B_e=K_M*Oplane_e, with K_M the heavy scalar Casimir.
The extra triangle also directly equals the independently measured OM
transpose/evaluation and iszero. The unbroken-vector evaluated term vanishes
at this vacuum; that is not a zero theorem for OH away from it.

Using one common length6 for both extra groups would shift448 coefficients
bylog(3/2)*B. Thus the zero OM result for h*a*x cannot be transferred into a
zero g3*xi2 vacuum contribution. No cancellation is assumed between different
coupling orders. No inverse coupling or favorable parameter point is used.

The selected JL*h*v contribution is alsozero within this local family:
its evaluated ATS1 ghost port was already provedzero, and the additional
LambdaX family has no allowed free LambdaLambda trace path. The independent
support enumerators find0 new words. This does not forbid homogeneous finite
JL mixing or define arbitrary connected products.

## Qualification, preserved failure and resources

The first primary failed before coefficient calculation because its explicit
GF whitelist missed BB*a*C. No original primary table, replay, verifier,
validation manifest or receipt was produced. Original source copies, complete
native1 capture and controller failure are preserved. CONTINUATION_V2 adds
that specific no-scalar quartic to the proper-graph classification, with
all other unknown patterns still failing. No phase, input, equality, domain,
resource limit or scientific requirement changed. V2P/R/gate completed0.
V3 reuses the qualified V2 tables and independently calculates the extra
vacuum groups; it does not rerun the completed V2 contractions.

Receipt SHA256:

- validation_receipt_v2.json:
  7b2936a6113ccd9edcdd66fa3bd5a7d70a6810683fa42d72159d64dd57b63a21.
- vacuum_receipt_v3.json:
  bba7a271ceaa92158f887241bc36e1b65dfdf517ff18e3e7a7a66ebd55394cd7.

V2 artifact packed/raw SHA256:
66b3cf4f300d0786b29b0bc7e3e3a0463dce7e71732f142b71ba590412add9c3 /
2d38fae1d4666b6ab13a04d02e861778daccf09d7569546a33a8bc830c4d1984.
V3 artifact packed/raw:
53b053a7be253b0c01241e181dc034cbf8f58bce3e5af46feb09596e9bed9cf1 /
ff8dbd78dce5587beb3e7b68dd8922fe732edb1a8551b776774e8fe2da8d9e48.

V2P/R/gate times37.377713/39.152775/2.324644s; samples20/21/2 and maxima
139186176/120254464/72290304B. V3P/R/gate times10.238576/6.911233/.802853s;
samples6/4/2, maxima115449856/68239360/53297152B. Failed original primary
has3samples,max72126464B and no completed RESULT. These are sampled
observations, NOT peaks. All600s/8GiBsampled/350MiB/16MiB bounds held.
22 exact source copies; preparations47/65/95 and validation73/103bindings.
Pre-report packet866515B. No V2/V3 failure is hidden or relabeled.

Current E4 checks completed with exits0/0/0/0/0/2; custody remains
exit2/sevenNOTPASS. External before/index/after seals in tangent-antighost-
scalar-vertex-v1-2026-10-24 must preserve33819oldblobs and inspect the final
commit. State113/34of39, all old failures/physical exclusions and blocked
stages are unchanged. No remote action authorized.

## What this establishes next

This qualifies selected one-loop proper local relative coefficients for the
explicit provisional v/z/h extension, all physical scalar/ghost directions
and the stated vacuum. Fixed reference, nonexceptional Euclidean transfers,
actual numerator IR bounds and common edge smoothing precede local UV
extraction. The positive auxiliary IR is a comparator; integrable remainders
cancel only in the relative map. No global phase, measure, multiple-product,
constant physical vacuum, causal/Lorentzian or full E5/A5 theorem follows.

TrackA now has the actual ordinary h vertices needed beside Jx*h and ATS1's
JL*h*x/v zeros. TrackB demonstrates full-action coverage, raw/plane methods,
distinct Gaussian/radial derivations and a caught classification error. All
share action, data, software and AI authorship; no outside scientific or
proof-assistant confirmation is claimed. TrackC is voluntary/nonblocking.

The next priority is whether these coefficients belong to a common admitted
h-dependent ordinary/source finite construction. Establish the complete local
parent module, retain positive-dimension homogeneous possibilities, derive the
actual extended source-Euler/Hessian operation and match the first-variation
trace domain before extending the old metric Stokes constructor. In particular,
retain h*Pi contributions to source Eulers and the h*d_z term; selected matter
success does not prove that identity. Do not infer multiple-insertion products
or a full QAP by a formal doublet shortcut. Keep chi4,b0,kappa distinct.
The whole Spin(10)xPQ investigation remainsACTIVE/incomplete.
