from vacuum_data_v3 import *
t=begin3('primary');d=packed(CAL/'canonical_so10_cutoff_source_ward_operator/primary_inputs.json.gz');N=anti_rules(d['field_maps']);g=s.Symbol('g10');O=s.SparseMatrix(45,328,{});D=[s.SparseMatrix(45,328,{}) for _ in range(45)];names={f'x_{sec}_{i}':k for k,(sec,i) in enumerate((sec,i) for sec,n in SECTORS for i in range(n))};lam={f'b{a}' if a<12 else f'L{a}':a for a in range(45)};anti={f'bar{a}' if a<12 else f'ub{a}':a for a in range(45)};counts=Counter()
for row in d['GF']:
 w=row['word']
 if any('__' in z for z in w):continue
 if len(w)==2 and sum(n in lam for n in w)==1 and sum(n in names for n in w)==1:
  a=lam[next(n for n in w if n in lam)];j=names[next(n for n in w if n in names)];z=co(s.sympify(row['coefficient'])/(g*WM));assert not z.free_symbols;O[a,j]+=z;counts['LambdaX']+=1
 if len(w)==3 and sum(n in anti for n in w)==1 and sum(n in names for n in w)==1 and sum(n.startswith('C') for n in w)==1:
  ai=next(i for i,n in enumerate(w) if n in anti);ci=next(i for i,n in enumerate(w) if n.startswith('C'));a=anti[w[ai]];c=int(w[ci][1:]);j=names[next(n for n in w if n in names)];z=co((-1 if ci<ai else 1)*s.sympify(row['coefficient'])/(g*g*WM));assert not z.free_symbols;D[c][a,j]+=z;counts['aCX']+=1
p=read(PK/'frozen_a10_physical_reconciliation/full_primary.json');v=dec(p['vacuum']['VEV']);Q=dec(p['C3_plane_to_parent']);old=packed(CAL/'canonical_so10_ghost_triangle_field_insertion/primary_tables.json.gz');CG=dec(old['raw_Gca']);U=dec(old['raw_aux_map']);FM=dec(read(PK/'frozen_a10_e1_fermion/primary.json')['charts']['blocks']['heavy_dual']['field_embedding']);FC={tuple(r[:3]):co(r[3]) for r in packed(HERE/'primary_v2_tables.json.gz')['raw_Fc']};bub=s.SparseMatrix(45,328,{});tri=s.SparseMatrix(45,328,{});nport=s.SparseMatrix(45,328,{});off=0
for sec,n in SECTORS:
 R=list(map(dec,p['representation_matrices'][sec]));RR=[tidy(sum((Q[b,c]*R[b] for b in range(45) if Q[b,c]),ZERO(n))) for c in range(45)];TT=[tidy(sum((FM[b,a]*R[b] for b in range(45) if FM[b,a]),ZERO(n))) for a in range(33)];GT=[tidy(sum((CG[c,12+a]*TT[a] for a in range(33) if CG[c,12+a]),ZERO(n))) for c in range(45)];Os=O[:,off:off+n];expected=s.SparseMatrix(45,n,{})
 for a in range(33):expected[12+a,:]=(TT[a]*v[off:off+n,0]).T
 zero(Os-expected);rawB=s.SparseMatrix(45,n,{});rawN=s.SparseMatrix(45,n,{})
 for c in range(45):
  nc=s.SparseMatrix(45,45,{(r,a):z for (r,a,c0),z in N.items() if c==c0});nn=nc.T*Os;expectedD=nn-Os*RR[c];zero(D[c][:,off:off+n]-expectedD);rawB+=D[c][:,off:off+n]*GT[c];rawN+=nn*GT[c]
 zero(rawN);weighted=CG*Os;rawT=s.SparseMatrix(45,n,{})
 for (r,a,c),z in FC.items():rawT[a,:]+=z*weighted[r,:]*GT[c]
 bub[:,off:off+n]=tidy(U.T*rawB);tri[:,off:off+n]=tidy(U.T*rawT);nport[:,off:off+n]=tidy(U.T*rawN);off+=n
zero(nport);words=walks3('walk');ats=read(CAL/'canonical_so10_auxiliary_tangent_source_kernel/validation_receipt_v2.json');assert ats['zero_before_momentum_integration'] and not words['JL_new']
finish3('primary',{'method':'actual_full_GF_coefficients_nonlinear_antighost_rule_and_raw_Green_contraction','GF_rows':dict(counts),'raw_GF_scalar_reconstruction_positions':45*45*328,'nonlinear_antighost_rows':len(N),'nonlinear_antighost_bubble_port_nonzero':len(nport.todok()),'words':words,'extra_bubble':enc(bub),'extra_triangle':enc(tri),'evaluation':evaluate_tables('primary',v),'bubble_phase':'1','triangle_phase':'-1','bubble_heat_length':4,'triangle_heat_length':6,'JL_h_v_new_words':len(words['JL_new']),'JL_h_v_evaluation_zero_inherited':True,'fixed_vacuum_only':True},t)
