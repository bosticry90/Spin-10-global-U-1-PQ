from data_v2 import *
def begin3(role):
 t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation_v3.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def guard(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='vacuum_replay_v3' if role=='primary' else 'vacuum_primary_v3'
   if p.parent.resolve()==HERE and p.name.startswith(peer):raise PermissionError('TAV1_VACUUM_PEER_DENIED')
 sys.addaudithook(guard);return t
def finish3(role,d,t):
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/('vacuum_'+role+'_v3_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-t,'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest()},sort_keys=True),flush=True)
def vv(family):
 base=[('X','a','h_Xa',1),('a','X','h_aX',1)]
 if family=='bubble':return base+[('X','C','av_XC',6),('C','X','av_CX',6)]
 extra=[('L','X','v_LX',4),('X','L','v_XL',4)]
 return base+extra+([('B','C','a_BC',2),('C','B','a_CB',2)] if family=='triangle' else [('L','C','J_LC',2),('C','L','J_CL',2)])
def walks3(algorithm):
 out={}
 for family in ['bubble','triangle','JL_new']:
  verts=vv(family);words=[]
  if algorithm=='walk':
   edges=[(a,b,gt+'/'+vt,d) for a,k,gt in G for kk,b,vt,d in verts if k==kk]
   for start in sorted(set(a for a,b,z in G)):
    def rec(node,mask,path):
     if mask==7:
      if node==start:words.append({'start':start,'path':path})
      return
     for a,b,tag,d in edges:
      if node==a and not mask&d:rec(b,mask|d,path+[tag])
    rec(start,0,[])
  else:
   labels=[1,6] if family=='bubble' else [1,2,4]
   for perm in itertools.permutations(labels):
    for vs in itertools.product(*[[v for v in verts if v[3]==i] for i in perm]):
     for gs in itertools.product(G,repeat=len(vs)):
      if all(gs[i][1]==vs[i][0] and vs[i][1]==gs[(i+1)%len(vs)][0] for i in range(len(vs))):words.append({'start':gs[0][0],'path':[gs[i][2]+'/'+vs[i][2] for i in range(len(vs))]})
  out[family]=canonical(words)
 return out
def anti_rules(maps):
 names=[f'bar{a}' if a<12 else f'ub{a}' for a in range(45)];ai={n:i for i,n in enumerate(names)};N=defaultdict(lambda:s.S.Zero);g=s.Symbol('g10')
 for r,name in enumerate(names):
  for row in maps[name]:
   w=row['word']
   if len(w)!=2:continue
   ci=next(i for i,n in enumerate(w) if n.startswith('C'));a=ai[w[1-ci]];c=int(w[ci][1:]);z=co((-1 if ci else 1)*s.sympify(row['coefficient'])/g);assert not z.free_symbols;N[r,a,c]+=z
 return clean(N)
def evaluate_tables(role,v):
 d=packed(HERE/(role+'_v2_tables.json.gz'));off=0;out={k:s.SparseMatrix(45,328,{}) for k in ['ordinary_H','ordinary_M','auxiliary']}
 for b,(sec,n) in zip(d['color'],SECTORS):
  assert b['sector']==sec
  for key in out:
   for e,m in enumerate(b[key]):out[key][e,off:off+n]=(v[off:off+n,0].T*dec(m))
  off+=n
 return {k:enc(m) for k,m in out.items()}
