from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from functools import lru_cache
import gzip,json,os,sys,time,threading,itertools,importlib.util
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations';PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());packed=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
WH,WM=s.symbols('eta_H xi');SECTORS=[('Phi',54),('Sigma',252),('phi',20),('S',2)];ZERO=lambda n:s.SparseMatrix(n,n,{})
@lru_cache(maxsize=131072)
def co(z):return s.simplify(s.sympify(z))
def tidy(m):return s.SparseMatrix(m).applyfunc(co)
def dec(m):return s.SparseMatrix(*m['shape'],{(i,j):co(z) for i,j,z in m['entries']})
def enc(m):return {'shape':list(m.shape),'entries':[[int(i),int(j),str(v)] for (i,j),v in sorted(tidy(m).todok().items())]}
def zero(m):assert not tidy(m).todok()
def clean(d):return {k:co(v) for k,v in d.items() if co(v)}
def rows(d):return [[*k,str(z)] for k,z in sorted(clean(d).items())]
def begin(role):
 t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
 for p,h in read(HERE/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
 def guard(event,args):
  if event=='open' and args and isinstance(args[0],(str,bytes)):
   p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
   if p.parent.resolve()==HERE and p.name.startswith(peer):raise PermissionError('TAV1_PEER_DENIED')
   if p.parent.name=='canonical_so10_vacuum_heat_root_completion' and p.suffix=='.gz':raise PermissionError('TAV1_PREVIOUS_QUANTUM_TARGET_DENIED')
 sys.addaudithook(guard);return t
def finish(role,d,t):
 d.update({'elapsed_after_imports':time.perf_counter()-t,'authority':'34/39','scientific_acceptance':'NOT_PERFORMED','physical_scheme_adopted':False,'full_h_source_QAP_E5A5_qualified':False})
 raw=(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
 with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
 print('RESULT '+json.dumps({'elapsed_after_imports':d['elapsed_after_imports'],'packed_sha256':sha256(blob).hexdigest(),'tables_sha256':sha256(raw).hexdigest(),'packed_bytes':len(blob)},sort_keys=True),flush=True)
G=[('B','B','BB'),('B','L','BL'),('L','B','LB'),('C','a','Ca'),('a','C','aC'),('X','X','XX'),('F','F','FF')]
V0=[('X','a','h_Xa',1),('a','X','h_aX',1),('B','X','x_BX',4),('X','B','x_XB',4)]
def vertices(kind):return V0+([('B','C','a_BC',2),('C','B','a_CB',2)] if kind=='ordinary' else [('L','C','a_LC',2),('C','L','a_CL',2)])
def canonical(words):return sorted(words,key=lambda x:(x['start'],x['path']))
def pairings(kind):
 legs=[('h','a'),('h','X'),('a','C'),('a','B' if kind=='ordinary' else 'L'),('x','B'),('x','X')];out=[]
 def connected(edges):
  seen={'h'}
  for _ in range(3):seen|={v for a,b in edges for u,v in [(a,b),(b,a)] if u in seen}
  return len(seen)==3
 def rec(rem,pairs):
  if not rem:
   ed=[(legs[a][0],legs[b][0]) for a,b in pairs]
   if connected(ed) and all(connected(ed[:i]+ed[i+1:]) for i in range(3)):out.append(sorted([[*legs[a],*legs[b]] for a,b in pairs]))
   return
  a,*tail=rem
  for b in tail:
   if any((x,y)==(legs[a][1],legs[b][1]) for x,y,_ in G):rec([v for v in tail if v!=b],pairs+[(a,b)])
 rec(list(range(6)),[]);return sorted(out)
def gf_literal(density):
 g=s.Symbol('g10');raw={j:[defaultdict(lambda:s.S.Zero) for _ in range(4)] for j in ['a','B','c']};H=defaultdict(lambda:s.S.Zero);counts=Counter();audit=Counter()
 def kind(n):
  n=n.split('__')[0]
  if n.startswith(('bar','ub')):return 'a'
  if n.startswith('C'):return 'C'
  if n.startswith('B'):return 'B'
  if n.startswith('A'):return 'A'
  if n.startswith('x_'):return 'X'
  if n[0] in ['b','L'] and n[1:].isdigit():return 'L'
  raise AssertionError(('unknown_GF_field',n))
 for row in density:
  w=row['word'];base=[n.split('__')[0] for n in w];ks=sorted(kind(n) for n in w);jets=sum('__' in n for n in w);audit[','.join(ks)+';jets'+str(jets)]+=1
  if len(w)!=3 or ks not in [['B','C','a'],['C','L','a']]:continue
  ai=next(i for i,n in enumerate(base) if kind(n)=='a');ci=next(i for i,n in enumerate(base) if kind(n)=='C');a=int(base[ai][3:] if base[ai].startswith('bar') else base[ai][2:]);c=int(base[ci][1:]);odd=-1 if ci<ai else 1
  if 'B' in ks:
   bi=next(i for i,n in enumerate(base) if kind(n)=='B');r,nu=map(int,base[bi][1:].split('_'));ji=[i for i,n in enumerate(w) if '__' in n];assert len(ji)==1;pos=ji[0];mu=int(w[pos].split('__')[1]);assert mu==nu;tag='a' if pos==ai else 'c' if pos==ci else 'B';z=co(odd*[1,-1,-1,-1][mu]*s.sympify(row['coefficient'])/g);assert not z.free_symbols;raw[tag][mu][r,a,c]+=z;counts[tag]+=1
  else:
   li=next(i for i,n in enumerate(base) if kind(n)=='L');r=int(base[li][1:]);assert jets==0;z=co(odd*s.sympify(row['coefficient'])/WM);assert not z.free_symbols;H[r,a,c]+=z;counts['H']+=1
 for tag in raw:
  raw[tag]=list(map(clean,raw[tag]));assert all(v==raw[tag][0] for v in raw[tag]);raw[tag]=raw[tag][0]
 # Complete GF Hessian audit for the single external-antighost target.
 classification=Counter();dims={'a':1,'C':1,'B':1,'A':1,'X':1,'L':2}
 for row in density:
  w=row['word'];ks=sorted(kind(n) for n in w)
  if 'a' not in ks:continue
  jets=sum(len(n.split('__',1)[1].split('_')) if '__' in n else 0 for n in w);dim=sum(dims[k] for k in ks)+jets
  if 'A' in ks:tag='background_A0'
  elif dim<4:tag='positive_dimension_coefficient_UV_subleading'
  elif ks==['B','C','a'] and jets==1:tag='ordinary_target_vertex'
  elif ks==['C','L','a'] and jets==0:tag='auxiliary_target_vertex'
  elif ks==['C','a'] and jets==2:tag='kinetic_or_external_one_port'
  elif ks==['C','C','a','a'] and jets==0:tag='quartic_ghost_three_quantum_ports_or_bridge'
  else:raise AssertionError(('UNCLASSIFIED_GF_SOURCE_TARGET',ks,jets,dim))
  classification[tag]+=1
 return raw,clean(H),dict(counts),{'all_field_jet_counts':dict(audit),'external_antighost_dispositions':dict(classification)}
