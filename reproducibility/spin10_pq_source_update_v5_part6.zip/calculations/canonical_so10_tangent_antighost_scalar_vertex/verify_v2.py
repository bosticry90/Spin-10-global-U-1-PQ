from data_v2 import *
t=time.perf_counter();timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start();assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
for p,h in read(HERE/'validation_preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
P=packed(HERE/'primary_v2_tables.json.gz');R=packed(HERE/'replay_v2_tables.json.gz')
for key in ['words','proper_graphs','raw_Fc','raw_H','universal_phases','dimension_angular_unit','dimension_angular_derivative','heat_edges','heat_length','affine_v_evaluation_qualified','common_h_family_qualified']:assert P[key]==R[key],key
assert P['universal_phases']==['-1','1'] and P['heat_length']==6 and co(s.sympify(P['chi6'])-s.sympify(R['chi6']))==0
assert all(P['words'][family] and P['proper_graphs'][family] for family in ['ordinary','auxiliary'])
dispositions=P['GF_field_jet_inventory']['external_antighost_dispositions'];assert dispositions['ordinary_target_vertex']>0 and dispositions['auxiliary_target_vertex']>0
assert len(P['color'])==len(R['color'])==4;positions=0;nonzero=Counter();sectorcounts={};reality=0
for pb,rb,(sec,n) in zip(P['color'],R['color'],SECTORS):
 assert pb['sector']==rb['sector']==sec;sectorcounts[sec]={}
 for kind in ['ordinary_H','ordinary_M','auxiliary']:
  assert len(pb[kind])==len(rb[kind])==45;count=0
  for pa,ra in zip(pb[kind],rb[kind]):
   a,b=dec(pa),dec(ra);assert a.shape==b.shape==(n,n);zero(a-b);positions+=n*n;count+=len(a.todok())
   for z in a.todok().values():assert co(s.conjugate(z)-z)==0;reality+=1
  sectorcounts[sec][kind]=count;nonzero[kind]+=count
assert positions==3*45*sum(n*n for _,n in SECTORS)
gaussian_sensitive=sum(v['phase']!=v['ordinary_trace'] for v in R['gaussian'])
controls={**P['controls'],**R['controls'],'ordinary_trace_changed_universal_fixtures':gaussian_sensitive,'auxiliary_omission_changed_positions':nonzero['auxiliary'],'mixed_sign_changed_positions':nonzero['auxiliary'],'wrong_heat_length_model_changed_positions':sum(nonzero.values())}
out={'status':'QUALIFIED_SELECTED_PROPER_TANGENT_ANTIGHOST_SCALAR_RELATIVE_VERTEX','elapsed_after_imports':time.perf_counter()-t,'ordered_words':{k:len(v) for k,v in P['words'].items()},'proper_graphs':{k:len(v) for k,v in P['proper_graphs'].items()},'block_diagonal_positions_compared':positions,'offblock_zeros_by_scalar_types':3*45*328**2-positions,'full_typed_position_scope':3*45*328**2,'nonzero_by_class':dict(nonzero),'nonzero_by_sector':sectorcounts,'reality_nonzero_coefficients_checked':reality,'universal_phases':P['universal_phases'],'chi6':P['chi6'],'heat_length':6,'no_dimensional_angular_jet':True,'raw_Green_longitudinal_slots_checked':P['raw_Green_longitudinal_slots'],'controls':controls,'affine_v_evaluation_qualified':False,'common_full_h_family_qualified':False,'full_QAP_measure_phase_E5A5_qualified':False,'physical_scheme_adopted':False,'authority':'34/39','scientific_acceptance':'NOT_PERFORMED'}
raw=(json.dumps({'coefficient':'(chi4+log(3/2))/(16*pi^2)*h_A*a_e*x_k*(-g^3*xi*eta_H*OH[e,k,A]-g^3*xi^2*OM[e,k,A]+g^2*xi^2*X[e,k,A])','color':P['color'],'proper_support':P['words'],'scope':out},sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (HERE/'selected_tangent_antighost_scalar_vertex_v2.json.gz').open('xb') as f:f.write(blob)
out.update({'artifact_sha256':sha256(blob).hexdigest(),'artifact_raw_sha256':sha256(raw).hexdigest()})
print('RESULT '+json.dumps(out,sort_keys=True),flush=True)
