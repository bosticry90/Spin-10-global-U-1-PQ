# TAV1 prospective action, signs and finite-map derivation

Use VTS tangent +g*xi*h_A*a_s*T_s,jA*X_j in Euclidean action, where
T_s=sum_b FM[b,s]*rho_b for33heavy raw antighosts. Scalar kinetic current
at zero external x jets is -g*B_b*(partialX)_j*rho_b,jk*x_k. The raw GF
ordinary density is in antighost-first a*B*C order with coefficientsUA,UB,UC
for derivatives ofa,B,C respectively. Define Fc=UC-UB. This external-antighost
problem usesFc; it is not GTT's external-C V=UA-UB. Derive every odd reorder
from the literal action. Auxiliary density is xi*H[r,d,c]*Lambda_r*a_d*C_c,
whose Euclidean contour gives+i*xi*H. No additionalg is inserted.

At h vertex1 choose a_internal momentum-k andX momentum+k; at GFvertex2
choose C+k andB/ Lambda-k; at currentvertex3 choose vector+k andX-k.
GF ordinary gives+i*k*Fc, current gives+i*k*rho, so their product is-1
times the longitudinal vector numerator. Auxiliary gives+i*H, the ordered
mixed inverse G_LB(-k)=-k/Q, and current+i*k, so their product is+1.
The odd word(h,a_internal)(a_external,C_internal) reorders to
(h,a_external,C_internal,a_internal) with sign+1. Third cumulant+1/6 sums
six even-vertex permutations. Check the prospective ordinary-1, auxiliary+1
units by an independent paired-mode Gaussian before using model tensors.

For the paired Hessian convention row momentumq,column-q: ordinary GF has
V_BC=V_CB=-i*q*a_external*Fc; auxiliary has V_LC=+i*a_external*H,
V_CL=-i*a_external*H. Tangent V_Xa=+h,V_aX=-h. Current V_BX=+iq*rho,
V_XB=-iq*rho. Free Ca=+1/Q,aC=-1/Q,BL=-q/Q,LB=+q/Q and
BB=(I+(W-I)qq/Q)/Q. Use both momentum modes; Gaussianhalf/logthird/
full-shell modeaverage are all retained. No finite or quantum target fixes
a vertex phase.

CG is the actual raw ghost residue. Q maps raw gauge/ghost fields to plane;
U maps normalized auxiliary/antighost fields to raw. The actual longitudinal
Euclidean BB residue is Wraw=Q^-1*W*Q^-T, W=eta_H*PH+xi*PM. Derive it
from the raw643 inverse and verify its Lorentz contraction; do not guess it
from pole matching. Raw BL/LB identities give the CG and CG.T mixed residues.
Define Rraw_b=sum_a Q[a,b]*rho_a, GT_c=sum_s CG[c,s]*T_s (heavysonly).
The prospective real scalar kernels, with indicesexternalxk,tangentA, are

 Oraw_d = sum_rbc Fc[r,d,c]*Wraw[r,b]*Rraw_b.T*GT_c,
 Xraw_d = sum_rbc H[r,d,c]*CG[b,r]*Rraw_b.T*GT_c.

Transport externalantighost by U.T, not the U^-1 source map of ATS1. The
loop coefficient is -g3*xi*O +g2*xi2*X in h*antighost*x order. Separate O
into eta_H andxi contributions before comparison. The independently normalized
plane form uses Fc andH from all literal derivative placements, R_b=rho_b,
GT_c=sum_d PM[d,c]*rho_d, and W=eta_H*PH+xi*PM. PM is actualrank33 and
is not the last33 physical coordinate slots. Keep ordinary transpose as
required by the real kinetic bilinear, not a complex-chart Hermitian guess.

Every target-compatible proper one-loop vertex has internal degree2: E=V,
and an internaldegree1 vertex is a bridge. Tangent must leave h external
and a,X internal. An ordinary ghost or auxiliary ghost vertex leaves the
single externalantighost and two internal fields. Scalar current leaves
externalx and internalB,X. Quarticghost or cubic-source cases with a one-port
tangent are1PR, not omitted quantum integrals. Physical scalar XX orFF
Hessians with externalx do not close these paths. Positive-dimension
unlabelled vertices change the local grade and are UV-subleading; they are
not declared absent from finite physical amplitudes. Derive the complete
walk list from the audited action types rather than assuming these candidates.

For the zero-jet critical coefficient both ordinary derivative vectors are
internalq; q_mu*BB_mu,nu*q_nu/Q gives W without D-dependent angular trace.
The mixed/current pair similarly contractsQ. Thus no4/D jet arises. Terms
with external-antighost derivatives are retained until this zero-jet
projection; external heat Taylor terms cannot contribute the same grade.
Each candidate has3heat edges and factorexp(-6tQ), giving the universal
relative factor chi6=chi4+log(3/2)=1+log(24pi)-n_log, as independently
derived by positive auxiliary-IR radial expansion and relative Frullani
difference/nonexceptional two-edge comparison. Any lower-symbol absolutely
integrable remainder drops out of the RELATIVE heat/comparator difference,
not the full physical amplitude. No finite parameter is fixed.

Domain check must use actual numerators: with positive scalar reference,
Ca andBB each have softdegree2 but the ordinary current/GF momenta supply
two powers at their coincident soft origin, leaving degree2, not an
independent forced critical4 pole. At nonexceptional transfers the massless
origins separate. Mixed LB degree1 pluscurrent derivative has the analogous
bound. Common independent Schwartz transfers and edge smoothing precede
the local UV extraction; the auxiliary IR comparator is not a prescription
to erase a momentum-space delta or take a physical constant-vacuum trace.
Only this first-variation selected local family is covered, not arbitrary
nonlinear products or the complete h-dependent action/source identity.
