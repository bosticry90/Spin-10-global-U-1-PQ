# Complete lower-edge cutoff tensors; the remaining comparison is partial

The complete C2 and C3 coefficients are now measured for both retained
source targets. Two scalar/color contraction orders agree, including
every implicit zero. Together with the authenticated complete C4 and
C1=C5=0 premises, they supply the full log2/log3 cutoff coefficients in
this formal domain. Their sums with the old PARTIAL conversion table
are nonzero. All remainders are preserved; no coefficient was fitted.

The focused dependency review identifies why those sums cannot yet be
called a failed full Ward identity: the old conversion comparator still
omits B_u C0, the actual probe operation on the unprobed conversion.
Its previously established heat bound excludes log5, but does not
exclude log2 or log3. The complete log5 cancellations remain intact.

This is PROGRESS in the original unshifted SMA/CSW/EDS,A0, constant-u,
intrinsic-degree1, external-jets0 AFTER differentiation, nonexceptional
Euclidean LOCAL RELATIVE positive-heat UV-symbol construction. Parameters
g10,xi,eta_H remain symbolic, with common hbar/(16pi^2). State113,
authority34/39, E5/A5 OPEN and custodyexit2/seven unresolved are unchanged.
Director scientific acceptance NOT_PERFORMED. Goal ACTIVE/incomplete.

## Evidence and coverage

[Derivation](PROOF.md), [whole review](review_result.json),
[cutoff tensors](finite_cutoffs.json.gz), [exact remainders](late_remainders.json.gz),
[dependency review](claim_review_result.json). Full source-row tensors
and their disjoint unique-u groups are retained separately for each
native route; the compressed final files are not merely count summaries.

| Probe1 coefficient | Nonzero | Zero complement | Complete domain |
| --- | ---: | ---: | ---: |
| T C2 | 10,780 | 653,420 | 664,200 |
| T C3 | 10,584 | 653,616 | 664,200 |
| F C2 | 147,812 | 14,464,588 | 14,612,400 |
| F C3 | 183,484 | 14,428,916 | 14,612,400 |

Probe0 is zero by the authenticated complete support premises. Source
ingress is recovered from actual action entries: T12..44, F13..44.
T12 contributes324 positions in each order and cannot be dropped from
earlier selected zeros. The full F C3 has5,752 nonzero HH positions;
the previously proved HH C4 zero does not extend to C3. These are exact
coefficient positions, not independent integrals, particles, experiments
or percentages of E5 completion.

Every one of286,804 raw entries is checked against a four-component
Lorentz polynomial reconstruction. Complete eligible paths justify the
longitudinal reduction; unit-axis agreement alone is not that proof.
All328 scalar directions and45 internal colors remain. Unique-u groups
retain higher-grade Hu/Mu, source-Ja versus source-JL parity, and the
quadratic-source Mu root differentiated BEFORE source restriction.

The compiler covers all63 candidate words and their103 sector paths.
Noncommuting tagged fixtures provide126 word contexts/504 scalar-component
comparisons. Controls change224 exterior,376 starting-supertrace,
4 scalar-root-transpose,32 source2 and216 higher-grade fixture components.
Actual action checks compare507 uncut words per route and56 full-power
contexts overall, in different axes/q orientations and exterior bases.
They verify the full engineering-degree identities and scalar-current
factorizations before tensor contraction. The full-power contexts do
not use the compiler's reduced word list as their oracle. They supplement,
rather than replace, complete tensor/zero-complement agreement.

The complete source13 pilot is reused once. Ten disjoint remaining-row
jobs finish with opposite scalar/color association and no native access
to the old quantum target or peer outputs. Whole review checks every
row, group sum, source ownership, calibration and zero complement before
opening the old conversion for the first mathematical comparison.

## Exact-once finite assembly and its disposition

The qualified finite heat pairs give Cn log((n+1)/n). With C1=0 and the
separately qualified complete T5/F5 zero,

    cutoff_log3 = C2-C3,
    cutoff_log2 = -C2+2C3-2C4.

T C4 comes from UTC; F C4 comes from UFR including its source-CJ term
already ONCE. It is not added a second time. Existing receipts authenticate
these operands; their contractions are reused, not freshly rerun here.

| Probe1 comparison | Old partial conversion nonzero | Complete cutoff nonzero | Sum nonzero |
| --- | ---: | ---: | ---: |
| T log3 | 6,472 | 10,632 | 10,632 |
| T log2 | 12,808 | 13,280 | 10,784 |
| F log3 | 45,176 | 124,064 | 121,600 |
| F log2 | 206,164 | 215,148 | 127,184 |

All corresponding probe0 sums are zero. Cancellation of the probe1
partial comparisons is FALSE. Successful tensor validation and execution
do not turn that diagnostic into PASS. Conversely, that nonzero diagnostic
is not a full-theory failure. Its complete missing terms were not calculated.

Whole-array omission controls are recorded with actual sensitivity.
Source2 contributes142,868 positions to each F prime direction and is
absent from T. Higher-grade directions contribute4,928 T and186,304/
187,288 F positions for log3/log2. Controls overlap; changed counts do
not count independent errors. Wrong C3 signs and omitted groups retain
their exact nonzero remainders, not an expectation that every count differs.

## Focused result-to-claim assessment

**Supported claim.** The complete lower-edge cutoff tensors and the
specified late PARTIAL comparisons are derived and checked in the exact
fixed formal reference. This closes a missing calculation, not a missing
quantum-construction theorem. ULC classical inputs/support, UTC/UFR C4
and UPM conversion are authenticated dependencies; current contractions,
full-domain comparison and dependency review are new executions.

**Missing bridge and alternatives.** UPM's owning LOWERING_RECORD and
verify_lower.py explicitly retain B_u C0 as missing in every formal basis.
For a full functional Gamma0+u Gamma_u+rho Gamma_rho, the first-u variation
contains q0 Gamma_u+X_(QG) Gamma0. Homogeneous source variation and
source-lowering Euler terms of the probed conversion do not include
the second summand. Neither does independently completing the cutoff
silently supply it. UOR's ten-root upper heat bounds permit native log2/
log3 and exclude explicit log5. This is a support statement, not a value
or proof that these missing terms cancel any present remainder.

The owning UWB finite identity also retains (Ihat+A)'', the tangent trace,
ordered cutoff, regulator variation and reference response. FJB's actual
qG identity and CPS's conjugate-port exclusions do not license discarding
every internal hatted insertion or taking arbitrary continuum trace limits.
No such insertion is assigned minus a remainder here. The full identity
must determine its applicable terms and signs. A missing ordinary quantum
input, an applicability/normalization gap or an implementation error can
only be distinguished by that complete comparison. No anomaly or no-
counterterm theorem follows from the present partial sum.

**Significance and authority.** A now-complete cutoff calculation separates
an actual nonzero comparison from the stronger restoration question. The
result-to-claim assessment redirected the next test to an explicitly omitted
operand rather than treating internal agreement as full quantum consistency.
Shared action, source charts, curated inputs, exact ring, libraries, formula
and AI author limit independence. No external scientist, proof-assistant
certificate or empirical validation is supplied. This demonstrates bounded
symbolic reduction/verification and dependency reasoning, not physical truth.

**Next discriminating action.** Reuse the actual UOR operation, then reduce
the unprobed C0 THREE-edge coefficient needed for log3. In the inherited
native carrier chi4+log(m/2), only m=3 supplies log3 for m<=4. The JaJa
root has ceiling2 and is excluded from this next log3 task; the other
nine root types remain candidates, not nine required nonzero integrals.
Establish their actual support and reuse authenticated coefficients with
matching types/conventions before measuring missing ones. Derive the
operation and its source signs before comparing with late_remainders;
never fit it to that file. This is cheaper and more discriminating than
another complete prime-log or vector-quartic expansion. Then reassess
the complete defect-inclusive identity and common finite-part domain.

No chi4, b0, kappa or infrared normalization was fixed or identified.
Continuum products/contact normalization, QAP/measure, source reality,
global phase, causal/massive/physical limits and physical viability remain
outside this bounded coefficient result. Flavor/HB1/C5 stay protected.

## Execution, preservation and omitted checks

All native calculation stages in this packet completed on their first
frozen versions; no failed/unfinished calculation is silently relabeled.
Read-only filename/wildcard lookups were corrected during review; they
made no scientific or historical-byte change. Pre-existing failures in
owning historical packets remain untouched. No input, scheme or sign was
changed to remove the nonzero comparisons.

After-import seconds: Lorentz16.0450, fixtures1.8950, actual29.1180/27.9432,
pilot22.6719/14.7627, remaining ten jobs869.7201 aggregate against1800,
maximum worker147.4832 against300, whole review108.3266 against180,
claim review2.7836 against180. Maximum successful private SAMPLE before
final sealing2,351,124,480B, not a continuous peak. Private8GiB sampled,
350MiB launch floor and32MiB total packet apply throughout. Exact sources,
preparations, complete stdout/stderr, PID/creation and samples are retained.

The final receipt separately records E4 and preservation checks. E4 runs
once without --fresh; its expected terminalCOMPLETED and exits
[0,0,0,0,0,2] authenticate existing evidence/current bounded audits,
not fresh global replay or custodyPASS. Deliberately omitted: fresh
replay of qualified C4/F5/UOR/UPM physics, new B_u C0 amplitudes, chi4,
complete renormalized Ward/QAP construction and physical matching.
No protected evidence edit, state change, branch/worktree, remote push,
publication or outreach. Full investigation remains ACTIVE/incomplete.
