# UCT2 actual operator calibration, prospective

All63 canonical words passed arbitrary rectangular per-word tagged
matrix products and both scalar associations,504 scalar-component
comparisons. Now verify actual factorization of all VX/M0_x scalar
vertices and all45 scalar M0_C roots before using R_a in the cut.

For every full raw operator entry,verify engineering homogeneity from
actual field/source dimensions and momentum powers. G_AB has degree
d_A+d_B-4; vertex degrees telescope with the tangent's extra+1. Both
targets have external engineering dimension5 (Ja2 versus JL1 plus
an extra C1), so every retained trace has degree-4. Positive-heat n>=1
radial differences are therefore the same bounded local logarithmic
integrals. This is not a full amplitude/continuum-limit theorem.

Test T and F at n2,n3,including HH higher-grade channels,in both
axis3/q+ and axis2/q- routes. Compare every uncut ordered word to its
cut expression. Independently reconstruct full tagged powers directly
from ALL raw projected tables,in a PHYSICAL external-word basis:
EPS,C1,C2,JL rather than EPS,JL,C1,C2. No internal source/ghost sign
conversion is needed in that direct basis; moving JL past both F
ghosts has even parity. For T,Ja is even. The alternate basis does not
reuse class selectors or reduced word enumeration as its oracle.

Compare full powers and omissions of source2 Mu/higher-grade terms to
the disjoint unique-u groups. Log sensitive and insensitive contexts;
do not force a detector where the actual coefficient is zero. Native
guards deny old quantum targets and peer calibration outputs. These
are calibrations,not complete coefficient tensors. Native300s,8GiB
sampled,350MiB launchfloor,32MiB packet; sources and inputs frozen first.
