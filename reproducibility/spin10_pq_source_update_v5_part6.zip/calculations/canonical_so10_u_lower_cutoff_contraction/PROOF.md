# Indexed lower-edge contraction and positive-heat finite coefficients

Original unshifted SMA/CSW/EDS,A0,constant u,intrinsic1,external jets0
AFTER differentiation,symbolic g10/xi/eta_H,common hbar/(16pi^2),
nonexceptional Euclidean LOCAL RELATIVE positive-heat UV symbol.
This derivation is not a continuum product/measure/QAP or physical-limit
theorem. Execution and evidence validation are separate from director
scientific acceptance. Actual final outcomes belong to review_result.json.

## Complete Lorentz shapes and local radial homogeneity

UCT1 checks every one of the286804 retained action entries,grouped by
all source/field labels,intrinsic degree and momentum monomial. Raw
vector/vector kernels are exactly A delta_mu,nu+B delta_mu,nu p^2
+C p_mu p_nu; vector/nonvector kernels are D p_mu; nonvector kernels
are E+F p^2. The proposed coefficients are recovered from specified
independent components,then EVERY monomial and zero complement is
reconstructed and compared. The proof is polynomial,not axis sampling.

The fixed free reference Green operator is covariant and preserves the
longitudinal vector line; its actual longitudinal and auxiliary/ghost/
scalar components are authenticated from G0. All scalar/vector and
ghost/vector connectors have the checked p_mu form. Every eligible
closed path has a nonvector connector; no vector-only cycle occurs.
Thus each vector arc is pinned to the longitudinal line and remains
there through every intervening Y kernel/G. No separate transverse
spectator or hidden D-dimensional trace survives. Unit-axis evaluation
retains the complete local scalar trace. Independent axis3/q+ and
axis2/q- routes are used,without replacing this polynomial proof by
their numerical agreement.

Every raw Hessian entry obeys

    nu_degree+external_dimensions+momentum_degree = 4-d_i-d_j,

and every tangent obeys the same left side=d_i+1-d_j. Sources have
dimension3-d_field. Free G_AB has degree d_A+d_B-4. Vertex/tangent
degrees therefore telescope around a trace. Both targets have external
dimension5: nu1+x1+Ja2+C1 or nu1+x1+JL1+two C1. Each retained
integrand has degree1-5=-4. C0/C1 support zeroes and maximal T/F edge
bounds are separately qualified ULC premises.

For n>=1 the actual LOCAL positive-heat difference is E^n-E^(n+1),
E=exp(-2tp^2). Its quadratic zero at p=0 and exponential UV decay
make the homogeneous coefficient integrable. The integral is
log((n+1)/n)/(16pi^2). This is a formal local symbol extension,not
a proof that a UV expansion uniformly controls the full infrared
amplitude or a common continuum trace/product limit.

## Exact finite-dimensional indexed cuts

ULC supplies all canonical T2/T3/F2/F3 words4/11/18/30. Their complete
coarse sector paths number7/14/26/56. Every path has either one explicit
nx scalar-mass index or one connected scalar segment. No eligible
interaction,source2 root or HH C3 channel is dropped. Physical potential
and isolated fermion envelopes are excluded by ULC's independent
all-order support proof in this exact unshifted target scope.

Write the original product as n vertices followed by its tangent root.
Retain (-1)^n,the original starting-sector supertrace sign,and the
literal exterior order of EPS,source and ghost slots. Displaying an
ordinary indexed trace with a different starting factor does NOT
change either original sign. No graded cyclicity shortcut is used.

For an nx mass factor M_i:A<-B,rotate only the ordinary component
trace to display M_i followed by the ordered complementary color
chain P:B<-A. Its contribution is

    sum_(a,b) M_i[a,b] P[b,a].

The full scalar-indexed tensor is retained in its actual quantum sector
pair; Hu_nx includes vector/auxiliary as well as ghost blocks. It is
not replaced by the GF ghost mass solely because both carry nx.

For a connected scalar segment,cut at its scalar-to-color endpoint.
If x is first,its block is R_x^T B_x and the nu endpoint is E_nu.
The component trace gives W=(B_x P)^T and scalar image

    sum_(b,a) W[b,a] (E_nu S R_a)[b,i].

Here S is the possible ordered scalar M0_C root,otherwise identity.
If nu is first,transpose its actual raw block into E_nu. The weight
is W=P A_x and its image instead contains E_nu S^T R_a. Thus the
root's transpose and position are preserved. No scalar generators
are commuted. Internal a ranges over all45; all328 scalar outputs
are retained.

At unit q the actual factorizations,checked on every scalar/current
coefficient and all45 roots before use,are

    VX_(B,s)=-i q Omega R_x, VX_(L,s)=-i R_x,
    VX_(s,B)=i q R_x^T, M0_x=(s,C):R_x^T,
    M0_C|(s,s)=R_C.

The q-independent L,s factor includes BOTH the vertex q and mixed-G q.
Keeping q signs separately prevents a false factor change in replay.
All other endpoint/mass/source matrices come directly from the full
authenticated action tables. No proportionality or cancellation is
fitted to a desired quantum remainder.

## Source origins,parity and verification routes

Each word has exactly one u operator. Disjoint stored groups record its
original QG source degree and higher/lower external grade. In particular
Mu_source2=CJL comes from source Euler BEFORE field restriction of the
actual quadratic-source QG. Its6688 classical entries were independently
verified in ULC; their count is not an identification with another
kernel. The new root occurs once per owned word,not as an extra term
added after a complete tensor. Ja is even,JL odd.

Rectangular noncommuting fixtures compare every candidate word to its
full tagged matrix product,all scalar components and both scalar
associations. Controls change exterior commutation,starting supertrace,
scalar-root transpose,source2 ownership and higher-grade content.
Their actual sensitivity is recorded,not assumed in every channel.

Actual calibrations compare every uncut word with the indexed cut and
also reconstruct full powers from ALL raw projected tables in a
different exterior basis: EPS,C1,C2,JL rather than EPS,JL,C1,C2.
Physical sorted field words require no internal JL/ghost permutation
in the first basis. Moving JL through BOTH F ghosts has even parity;
for T the Ja source is even. This independently checks class mapping
and source signs. Source2 and higher-grade omissions are tested by
recomputed complete powers. The reduced word list is not its own oracle.

Primary precontracts E_nu S R_a; replay contracts W into E_nu first,
then applies S/R_a. Complementary color products use opposite association.
Mass fibers are contracted with the complete complementary color matrix
in opposite index traversal; their underlying action derivatives also
come from ULC's Euler versus literal-polarization routes. Shared inputs,
formula and software are disclosed; this is not external physical
validation or a proof-assistant formalization.

## Whole finite-domain construction and late comparison

Complete source13 rows are calculated first by both routes as a cost/
memory pilot,and then reused exactly once. Source ingress is derived
from every eligible actual source-bearing operator pattern. T requires
labels12..44,F13..44; earlier selected zeroes do not exclude T12.
The remaining jobs have disjoint immutable source lists,per-worker and
aggregate frozen budgets. Each active source traverses every45/990
canonical ghost choice and all328 scalar coefficients. Zero rows/probe0
use the owning complete support premises,not an empty-output inference.
Full arrays,disjoint group sums and implicit zero complements must agree
before interpretation.

The coefficient convention is

    C_n=(-1)^n STr[(GV)^n M_u
       +sum_j(GV)^j G H_u(GV)^(n-1-j)M0].

With qualified C1=0,T5/F5=0 and existing COMPLETE C4 arrays,

    [log3]cutoff=C2-C3,
    [log2]cutoff=-C2+2C3-2C4.

Review authenticates C4 ownership and uses it once with the prescribed
factor; UFR's C4 already includes source-CJ. It must not be added again.
Only after whole native agreement is the old conversion opened and
added. Every remainder is preserved; vanishing is not built into the
worker or review's calculation acceptance condition. chi4,b0,kappa and
IR freedoms remain distinct/unfixed. Positive prime-log agreement does
not prove the full finite identity,renormalized products,QAP,measure,
source reality,causal/massive limits or physical viability.
