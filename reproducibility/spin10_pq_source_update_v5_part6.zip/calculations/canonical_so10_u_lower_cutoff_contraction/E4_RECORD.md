# Final bounded checkpoint audits, prospective

After UCT1-5 have completed, run exactly once
`python -B tools/research_check.py e4`, without --fresh, before local
commit. Freeze command/tool/live policy/state bytes before launch and
retain full stdout/stderr, native exit and owned-process resource capture.
Expected native0, terminalCOMPLETED and step exits[0,0,0,0,0,2].
Custodyexit2/seven unresolved remains NOTPASS. These audits authenticate
existing sealed evidence; they are not a fresh global scientific replay,
a full Ward test or scientific promotion. Same8GiB sampled private,
350MiB launch floor,32MiB packet;300s effort ceiling. If incomplete or
failed, preserve it and reassess rather than silently retrying.
