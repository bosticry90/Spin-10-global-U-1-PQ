# UCT2 complete indexed scalar/color cuts, prospective

UCT1 matched all286804 Lorentz-polynomial entries to explicit invariant
forms (vector/vector delta and q_mu q_nu,vector/nonvector q_mu,scalar
1 and q^2). This is a complete coefficient identity,not axis sampling.
Every eligible path has a nonvector connector; invariant Y blocks and
the actual free G preserve its pinned longitudinal direction. No pure
transverse closed spectator survives the target. Thus the unit-axis
representation is licensed for these paths; it is not a physical limit.

The canonical unions have T2/T3/F2/F3 paths7/14/26/56. They all have
one explicit nx mass vertex OR one connected scalar segment. Compile
each full ordered path with ORIGINAL supertrace starting sector and
exterior EPS/source/ghost sign and (-1)^n. Never invoke graded cyclicity
to change either sign when displaying an ordinary indexed trace cut.

Mass paths: cut the scalar-indexed matrix,retain its two quantum sectors
and contract the ordered complementary color matrix into all328 scalar
coefficients. Segment paths: retain the actual nu-endpoint block,possible
ordered scalar M0_C root (transpose on reverse orientation),and R_a
at the x-endpoint. Internal a all45. Verify VX/M0_x factorization and
all45 scalar M0_C blocks against actual R before using them.

Keep disjoint groups by unique u-operator source origin and higher-grade
flag; source2 Mu remains owned once. Do not identify equal-sized kernels
or assume proportional endpoint blocks without full classical evidence.
Test arbitrary noncommuting rectangular per-word matrices/all scalar
components and actual full tagged powers at independent axes/q signs,
including source2,higher-grade and HH C3. Use the full operator domain
for power checks,not the reduced word list as its own oracle.

Native300s/review180s,8GiB sampled,350MiB launchfloor,32MiB packet.
Freeze sources/operands before launch. Whole arrays need a later explicit
execution/resource record after method competence is checked. No quantum
target reads,normalization fitting,continuum/QAP or authority promotion.
