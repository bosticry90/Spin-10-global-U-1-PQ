# UCT4 whole-domain validation and late finite interpretation, prospective

Run ONLY after all ten UCT3B jobs and both pilots finish and their peer
rows agree. Authenticate every source row,disjoint source ownership,
unique keys,group sums and complete zero complements. Recompute active
source presence from actual operator patterns; retain T12. Verify all
completed capture/resource/budget dispositions. No native old conversion
operand. Preserve failure/incompleteness separately from byte custody.

Assemble complete T2,T3,F2,F3 across all45 sources,45/990 ghost choices
and328 scalars,with owning structural-zero premises for inactive rows
and probe0. Validate the selected fresh calibrations only after whole
agreement. Keep disjoint unique-u groups and source2/higher-grade
contributions. HH F3 can be nonzero; do not impose the unrelated HH C4
zero. Candidate support is not used as a coefficient value.

Then read the old full log3 conversion and evaluate conversion PLUS
C2-C3. Preserve all remainders,without asserting zero as an acceptance
condition. Authenticate qualified COMPLETE C4 arrays from UTC/UFR,
including UFR's source-CJ already owned ONCE. For log2 use
-C2+2C3-2C4 (C1=0,inherited C5=0),not a new source-CJ addition.
Compare its conversion only after the same full native agreement.

Record incorrect C3-sign and source2/higher-grade omission controls with
their actual sensitive/insensitive scope. These controls can overlap;
their counts are not independent amplitudes or physical evidence.
Do not determine chi4,b0,kappa or infrared baselines from prime logs.
No continuum product/trace/contact/measure/QAP,source-reality,causal/
massive/physical or E5/A5 promotion follows. Review180s,8GiB sampled,
350MiB launchfloor,32MiB packet. Freeze final inputs/sources before run.
