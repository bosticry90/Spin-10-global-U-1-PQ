# UCT6 final evidence validation and preservation, prospective

After UCT1-5 and the one delegated E4 have completed, authenticate every
preparation binding and frozen source copy, all completed capture statuses,
resource/effort limits, exact finite-diagnostic dispositions and the
focused dependency review. This is evidence validation/authentication,
not a repeat of the full contractions or scientific acceptance.

Require E4 native0, step exits[0,0,0,0,0,2], terminalCOMPLETED, no --fresh,
and seven unresolved custody references. Keep custodyNOTPASS separate.
Keep the four probe1 partial cancellation diagnostics NONZERO; their
complete Ward identity is NOT_TESTED. B_u C0 remains missing, not fitted.

Verify state hash, base HEAD/main, untouched tracked bytes and the exact
old mode/blob tree against the external start snapshot. Freeze current
RESULT/handoff before review. Seal every added file after its full capture,
excluding only the seal's own self-hash. Then stage these new files only,
check whitespace and verify raw staged blob hashes and all old index
mode/blob entries before a local main commit. No remote push or promotion.

Review180s, private8GiB sampled,350MiB launchfloor,32MiB packet. Preserve
all failures or incompleteness. project_state remains sole authority;
state113/34of39,E5/A5 OPEN,custodyexit2/seven unresolved unchanged.
