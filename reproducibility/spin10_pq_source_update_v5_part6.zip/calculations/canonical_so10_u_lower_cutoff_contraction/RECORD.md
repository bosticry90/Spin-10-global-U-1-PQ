# UCT1-4: complete lower-edge contractions and finite log3 test

Prospective at4959e454c2798650824d71adeca737fba30e1ae2. Fresh
preflight clean main/no matching workers,current AGENTS/highestV652
and actual ULC receipts read. Previous goal turn PROGRESS (complete
lower operator domain/source2 support). Goal ACTIVE/incomplete.
project_state sole scientific authority,state113,34/39,E5/A5 OPEN,
custodyexit2/seven unresolved unchanged.

Question: calculate the actual complete C2/C3 tensors and their log3
combination,not merely selected examples or another operator catalogue.
Use ULC's complete T2/T3/F2/F3 word unions4/11/18/30 and full286804-
entry action domain. Keep source2 Mu roots,higher-grade HH channels,
source-Ja even versus JL odd signs and source-Euler-before-restriction.
No old quantum remainder is a native operand. No unknown coefficient,
contact freedom or physical parameter is fitted to obtain cancellation.

UCT1: verify full four-component Lorentz polynomial shapes on every
retained entry,not only axis samples. Recover scalar/color blocks from
the actual tables,with source origin and all zero complements. First
prove eligibility of a longitudinal representation from complete closed
paths and covariant connector/Y-block forms; otherwise preserve the
missing tensor structure and revise the method. New raw blocks include
Hu_nx,Hu_nC,Hu_Ja,Hu_CJL and Mu_CJL. Any simplification must be an
exact complete classical identity,not a quantum fit.

UCT2: compile every ordered path as either an explicit scalar-mass-index
contraction or a cut of the connected scalar segment. Keep original
starting-sector supertrace sign,literal external/epsilon order,(-1)^n,
all source/ghost labels,all45 internal colors and328 scalars. Retain
ordered scalar roots/transposes. A different surviving path structure
is not dropped: derive it or classify the calculation incomplete.
Verify rectangular noncommuting fixtures and fresh original operator
powers at independent momentum orientations,with source2/high-grade
omissions and HH C3. No full tensor claim from calibrations alone.

UCT3: after a competent reduced formula exists,freeze its exact resource
and input/source bindings before complete coefficient execution. Use
distinct scalar/color associations,full arrays and zero complements;
do not silently extend a failed run or truncate evidence. Keep C2 and
C3 and required families separately. Native target/peer output blinding.

UCT4: only after complete native agreement compare full conversion PLUS
(C2-C3),inherited C5=0,under the original log3 convention. Preserve every
remainder. Reuse qualified C4 exactly once if a later log2 assembly is
justified. chi4,b0,kappa and IR freedoms remain distinct/unfixed.

Original unshifted SMA/CSW/EDS,A0,constant u,intrinsic1,external jets0
AFTER differentiation,symbolic g10/xi/eta_H,common hbar/(16pi^2),
nonexceptional Euclidean LOCAL RELATIVE formal positive-heat UV domain.
Inherited full free-M_f identity and potential/fermion support exclusions
retain their owning scope; they do not qualify continuum product/trace,
contact/measure/QAP,chiral/global phase,source reality,causal/massive
physical limits or viability. No foundation,benchmark,scheme,promotion,
flavor/HB1/C5 activation,agent,branch/worktree,remote action/publication.

Initial derivation workers native300s/review180s after imports,8GiB
sampled private,350MiB launch available-pagefile floor,32MiB packet.
Whole tensor workers/resources must be fixed after method verification,
before launch; these initial limits do not grant unlimited component
expansion. Preserve sources,preparations,owned PID/creation,complete
stdout and resource samples,including failed/unfinished executions.
Apply focused result-to-claim assessment in existing RESULT. Shared
action/reference/charts/curated data/ring/helpers/formula/software/AI
author limit independence; no external or empirical validation claimed.
