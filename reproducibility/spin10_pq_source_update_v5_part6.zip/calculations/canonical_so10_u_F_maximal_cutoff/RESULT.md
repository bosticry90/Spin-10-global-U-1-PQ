# Complete maximal F5 contribution is zero

UFM1-4B establishes C5_F=0 for all45 source labels,990 ghost pairs and328
scalar components in BOTH probes within the fixed original formal local
positive-heat reference. See [proof](PROOF.md), [complete applicability
review](review_result.json), [expanded free-word proof](expanded_typed_proof.json.gz)
and immutable preparations/captures. This is not the complete F identity.

All480 ordered terms are retained. Complete sector enumeration reduces
them to104 possible paths. Their scalar/color compression yields an
exact noncommuting identity after actual action/GF block relations are
applied. Every one of the45 model ghost blocks,334 source beta entries,
two free probe matrices and scalar antisymmetries meets those assumptions.
The identity holds before scalar contraction and for arbitrary compatible
source matrices, covering14,612,400 coefficient positions per probe.

Individual root contributions are nonzero. Two scalar associations
calculate the entire r13 row,324720 positions per probe, with every
rooted map retained. Positive-root cases agree with original508-coordinate
powers. Ten unequal-block finite tests reproduce the full480-word result
and provide sensitive omission, phase, ghost-tangent and exterior controls.
The abstract type notation does not replace higher-dimensional matrices
with commuting scalar entries.

## Focused result-to-claim assessment

**Evidence to claim.** The complete path formula, free noncommuting
polynomial cancellation, exhaustive action applicability and independently
organized full-matrix checks support COMPLETE F5 cancellation in the
nonexceptional Euclidean LOCAL RELATIVE formal UV symbol domain. The
source13 row suggested the identity; it is not the basis for extrapolation.
UMH's complete operator, grade, longitudinal and radial results are
authenticated inherited premises, not fresh continuum reproofs.

**Missing bridge and alternatives.** Full F log5 still requires C4_F,
now without an unresolved C5 subtraction. The original source2 quantum
contact Euler contributions must remain in a later conversion comparison.
Other finite bases, common trace/variation/product/contact limits,
measure/QAP and physical viability remain unproved. No renormalized
restoration or anomaly conclusion follows from this local zero. b0,
kappa,chi4 and infrared freedoms stay distinct and unfixed. The theorem
does not supply all individual-family component tables at other sources.

**Significance and authority.** A selected zero has become a complete
operator-class zero, avoiding millions of redundant component calculations.
Demonstrated AI capability includes discovering the cancellation level,
testing an initially insufficient abstract assumption set, recovering
actual classical structure and then proving a stronger bounded identity.
Shared action,reference,charts,ring,helpers,compiler and AI author remain
shared-error limits; no external or experimental validation is claimed.
Authority remains34/39,state113,E5/A5 OPEN,custodyexit2/seven unresolved.

**Next discriminating action.** Classify and reduce the complete fourth-
edge nonlinear operator by actual action/source support, retaining
both-broken GF-aaCC/source-D,M_u,intrinsic and M_CC. Freeze its complete
domain and derive a contraction formula before large component extraction.
Then calculate C4_F independently and compare full conversion+cutoff
under the owning relative convention. Repeating F5 selected zeros is
unnecessary; reuse the complete proof and preserve its assumptions.

## Preserved failures and limitations

The first symbolic adapter FAILED before a result because times was
unbound; V2 FAILED because LETTERS was unbound. Exact sources,
preparations and captures remain FAILED. V3 supplied the frozen bindings
and checked compiler free names before running. The successful generic
free-word test then left120/302 base words: the initial assumptions were
insufficient. This legitimate negative result remains, alongside the
subsequent stronger typed theorem. No scientific condition or physical
input was weakened to obtain it. The two setup failures are workflow
weaknesses, distinct from either mathematical result.

Original integer fixtures, selected scalar zeros and their insensitive
controls remain explicit. Later positive-root checks were selected only
from new action-derived data, without a quantum target. Completed worker
resource observations and the project audit are recorded in captures and
the final validation receipt; custody exit2 is not PASS. Scientific
acceptance remains distinct from evidence validation.
