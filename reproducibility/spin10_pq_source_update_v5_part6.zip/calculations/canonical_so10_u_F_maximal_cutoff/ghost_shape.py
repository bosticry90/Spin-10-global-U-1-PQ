from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,time,threading,os
import sympy as s
from model import *
O=Path(__file__).resolve().parent;tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,h in json.loads((O/'ghost_shape_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==h,path
d,p=make('primary');results=[]
for h,mc in enumerate(p['MC']):
    A={(i,j):v for (i,j),v in mc['Y'].items() if i<45 and j<45}
    L={(i-45,j-45):v for (i,j),v in mc['Y'].items() if i>=45 and j>=45}
    mats={'A':A,'L':L,'C':mc['C'],'a':mc['a'],'JB':p['J'][h][0],'JL':p['J'][h][1]}
    audits={}
    for name,M in mats.items():
        parts={}
        for rr in range(2):
            for cc in range(2):
                label=('H' if rr==0 else 'B')+('H' if cc==0 else 'B')
                AA={k:v for k,v in A.items() if int(k[0]>=12)==rr and int(k[1]>=12)==cc};MM={k:v for k,v in M.items() if int(k[0]>=12)==rr and int(k[1]>=12)==cc}
                ratios=Counter();unmatched=[]
                for key in sorted(AA.keys()|MM.keys()):
                    av=AA.get(key,ZERO);mv=MM.get(key,ZERO)
                    if av:ratios[str(s.cancel(s.sympify(str(mv))/s.sympify(str(av))))]+=1
                    elif mv:unmatched.append([*key,str(mv)])
                parts[label]={'A_nonzeros':len(AA),'M_nonzeros':len(MM),'ratios':dict(ratios),'entries_without_A':unmatched}
        audits[name]=parts
    results.append({'ghost':h,'external_type':'H' if h<12 else 'B','blocks':audits})
out={'schema':'UFM3D_ALL_GHOST_BLOCKS_CLASSICAL_AUDIT','results':results,'quantum_target_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'ghost_shape_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({'ghosts':45,'elapsed_after_imports':out['elapsed_after_imports']},sort_keys=True),flush=True);timer.cancel()
