# UFM3C symbolic adapter continuation V3

Original adapter lacked times; V2 supplied it but FAILED before a symbolic
result because LETTERS was also absent. Preserve both exact failed sources,
preparations and full captures. V3 supplies the same frozen root-class map
and statically checks every compiler free-name binding before execution.
This corrects adapter setup only. Compiler, ring arithmetic, mathematical
assumptions, full evidence requirements and300s/8GiB/32MiB bounds unchanged.
Reassess this narrow adapter instead of repeatedly treating runtime setup
failures as scientific findings. No failed execution is called PASS.
