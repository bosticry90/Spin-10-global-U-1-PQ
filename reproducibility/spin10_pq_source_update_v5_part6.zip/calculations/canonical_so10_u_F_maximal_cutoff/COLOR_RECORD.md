# UFM2 color compression before any full tensor extraction

UFM1 reduced480 words to104 sector-compatible words:16 M_u,8 M_x,
40 each M_C1/M_C2. This is not a structural zero; all four generic
root families are nonzero. No actual quantum target has been read.

Derive each closed sector path as a color contraction through the unique
scalar segment. X_n and X_x (or M_x) give n/r endpoints. Scalar propagation
is identity except a possible scalar M_C root. Therefore each coefficient
is a sum of weights times N R_a, N S_h R_a or N S_h^t R_a, with S_h the
actual scalar tangent. Keep transpose/direct classes separate in generic
fixtures, then use actual R_h antisymmetry only after verification.
No commuting matrices or cyclic supertrace assumptions: retain the
original starting-sector supertrace sign and literal exterior order
when cyclically writing the numeric component trace.

Check these color weights against the complete480-word graded fixtures,
then actual508-coordinate operators for fixed selected triples:
(r,h,k,i)=(13,0,12,136),(13,12,13,207),(13,13,14,207),
(20,13,20,169),(44,13,44,134),both probes and momentum signs.
Broken-ghost zeros, if obtained, are not called sensitive controls.
Record entire color weights in calibration evidence so a selected scalar
zero cannot hide unmeasured scalar components. No old full F operand.

Primary stored beta versus replay source-density beta must agree; J/N
recoveries and scalar flows reuse UTC with disclosed shared helpers.
All fixed UFM resource/scope/authority limits apply. Freeze this record,
compiler and calibration source before launch. Full-tensor feasibility
will be decided from these results and color support, not from a desired
cancellation. C4 nonlinear terms remain a separate missing dependency.
