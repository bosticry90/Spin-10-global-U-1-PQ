# UFM3B first complete source row and module cancellation diagnostic

Selected all-scalar images are zero in total while their rooted families
are nonzero. No full-domain zero follows. Compute the complete source
r13 F5 row for BOTH probes, all990 ordered ghost pairs h<k and all328
scalar components, preserving four family maps, full sum and implicit
zeros. This is a feasibility/calibration step towards the full tensor,
not a replacement definition of completion. Native300s after imports,
8GiB sampled private,32MiB packet; stop as incomplete on exhaustion.

Before expanding scalar contractions, report for the frozen five triples
whether summed effective color weights vanish, and whether weighting
into N before final R kills the expression. A nonzero color weight with
a zero scalar image is distinguished from a zero operator. No desired
value is imposed on the row. Native root coefficients remain action-
derived and quantum-target blind. Full independent replay and all45
source rows remain required before a full F5 tensor claim.

Use the qualified scalar compression; an implementation-level prefix
cache may reuse identical immutable matrices but must not change signs,
assumptions or products. If needed, compare that cache with the existing
uncached generic formula before source-row use. All original UFM scope,
source/contact, authority and preservation limits remain in force.
