from pathlib import Path
from functools import lru_cache
from itertools import permutations
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'canonical_so10_u_T_cutoff_tensor'))
from algebra import *
EPS=1;UU=2;JJ=4;C1=8;C2=16;NN=32;XX=64;TARGET=127;ODD=EPS|JJ|C1|C2
EDGES={'n':{('Y','s'),('s','Y')},'x':{('Y','s'),('s','Y')},'J':{('Y','C'),('a','Y')},'C1':{('Y','a'),('C','Y')},'C2':{('Y','a'),('C','Y')},'u':{('Y','Y')}}
ROOTS={'Mu':{('a','Y')},'Mx':{('s','C')},'MC1':{(k,k) for k in ['Y','s','C','a']},'MC2':{(k,k) for k in ['Y','s','C','a']}}
LETTERS={'Mu':('n','x','J','C1','C2'),'Mx':('n','u','J','C1','C2'),'MC1':('n','x','u','J','C2'),'MC2':('n','x','u','J','C1')}
MASK={'n':NN,'x':XX,'J':JJ,'C1':C1,'C2':C2,'u':UU,'Mu':EPS|UU,'Mx':EPS|XX,'MC1':EPS|C1,'MC2':EPS|C2}
def sector_words():
    out={}
    for name,letters in LETTERS.items():
        good=[]
        for word in permutations(letters):
            prod=ROOTS[name]
            for letter in word[::-1]:prod={(a,d) for a,b in EDGES[letter] for c,d in prod if b==c}
            if any(a==b for a,b in prod):good.append(word)
        out[name]=good
    return out
@lru_cache(None)
def sign(a,b,odds=ODD):return (-1)**sum((b&odds&((1<<i)-1)).bit_count() for i in range(7) if a&odds&(1<<i))
def pmul(A,B,odds=ODD):
    out={};rows={}
    for (i,j),poly in B.items():rows.setdefault(i,[]).append((j,poly))
    for (i,k),p in A.items():
        for j,q in rows.get(k,[]):
            z=out.setdefault((i,j),{})
            for a,v in p.items():
                for b,w in q.items():
                    if not a&b:z[a|b]=z.get(a|b,ZERO)+times(v,w)*sign(a,b,odds)
    return {ij:{m:v for m,v in z.items() if v} for ij,z in out.items() if any(z.values())}
def lifted(M,mask):return {ij:{mask:v} for ij,v in M.items()}
def embed(out,M,ro,co):
    for (i,j),v in M.items():out[i+ro,j+co]=v
def poly_chain(operators,dim,nb,odds=ODD):
    M={(i,i):{0:constant(1)} for i in range(dim)}
    for op in operators:M=pmul(M,op,odds)
    return sum((v.get(TARGET,ZERO)*(-1 if i>=nb else 1) for (i,j),v in M.items() if i==j),ZERO)
def literal_exterior_sign(masks):
    seq=[i for mask in masks for i in range(7) if mask&ODD&(1<<i)]
    return (-1)**sum(i>j for at,i in enumerate(seq) for j in seq[at+1:])
def compact_chain(matrices,labels,nb):
    p=matrices[0]
    for q in matrices[1:]:p=multiply(p,q)
    return literal_exterior_sign([MASK[k] for k in labels])*sum((v*(-1 if i>=nb else 1) for (i,j),v in p.items() if i==j),ZERO)
