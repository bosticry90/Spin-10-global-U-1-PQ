from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import defaultdict
import ast,json,gzip,sys,time,threading,os
from color import *
from actual import load,primitives,co,dec,parity
O=Path(__file__).resolve().parent;R=O.parents[1]
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in json.loads((O/'calibration_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        p=Path(os.fsdecode(args[0]))
        if p.parent.name in ['canonical_so10_u_pair_contact_model','canonical_so10_intrinsic_auxiliary_ghost_source']:raise PermissionError('UFM_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard)

# Generic fixtures: reconstruct only their frozen setup, not prior outputs.
tree=ast.parse((O/'fixtures.py').read_bytes());loop=next(n for n in tree.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='seed')
setup=[]
for node in loop.body:
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PX' for t in node.targets):break
    setup.append(node)
generic=[]
for seed in [1,2,5]:
    ns=dict(globals());ns['seed']=seed
    exec(compile(ast.Module(body=setup,type_ignores=[]),'UFM_FROZEN_SETUP','exec'),ns)
    split=lambda M:{'Y':{(i,j):v for (i,j),v in M.items() if i<4 and j<4},'s':{(i-4,j-4):v for (i,j),v in M.items() if 4<=i<7 and 4<=j<7},'C':{(i-7,j-7):v for (i,j),v in M.items() if 7<=i<9 and 7<=j<9},'a':{(i-9,j-9):v for (i,j),v in M.items() if i>=9 and j>=9}}
    mc1,mc2=map(split,ns['MC'])
    W=weights(ns['Om'],ns['beta'],(ns['JB1'],ns['JL1']),(ns['JB2'],ns['JL2']),ns['UB'],ns['UL'],ns['H'],mc1,mc2,2)
    vals=contract(W,ns['N'],ns['RR'],mc1['s'],mc2['s'])
    expected=next(z['root_families'] for z in json.loads((O/'fixtures_result.json').read_bytes())['fixtures'] if z['seed']==seed)
    assert {k:str(v) for k,v in vals.items()}==expected
    generic.append({'seed':seed,'roots':{k:str(v) for k,v in vals.items()}})

d=load('primary');p=primitives(d,'primary');sourceBeta={}
for w,v in d['source_action']:
    if len(w)==3 and 0<=w[0]<45 and 135<=w[1]<180 and 225<=w[2]<270:sourceBeta[w[0],w[1]-135,w[2]-225]=co(v)
assert sourceBeta=={tuple(row[:-1]):co(row[-1]) for row in d['beta']}
tree=ast.parse((R/'calculations/canonical_so10_u_maximal_heat_cutoff/native.py').read_bytes())
names={'field','qpow','sign','padd','pmul','mm','add','tr','m0groups','matrices'}
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
matnode=next(n for n in nodes if n.name=='matrices')
matnode.body[:3]=ast.parse('r=R_LABEL\nix=X_LABEL\ncs=[(C_LABEL,CC1),(D_LABEL,CC2)]').body;ast.fix_missing_locations(matnode)
ns={'defaultdict':defaultdict,'lru_cache':lru_cache,'ZERO':ZERO,'constant':constant,'times':times,'I':I,'parity':parity,
    'flows':p['flows'],'RR':p['R'],'N':p['N0'],'J0':p['J0'],'B':p['B'],'beta':sourceBeta,'free':p['free'],'d':d,'dec':dec,
    'NB':418,'NC':418,'NA':463,'DIM':508,'EPS':1,'UU':2,'JJ':4,'CC1':8,'CC2':16,'NN':32,'XX':64,'TARGET':127,'ODD':29}
exec(compile(ast.Module(body=nodes,type_ignores=[]),'UFM_ORIGINAL_MATRIX_ROUTE','exec'),ns)
def mc_at(h):
    out={'Y':{},'s':{},'C':{},'a':{}}
    for i,poly in p['flows'].items():
        row=ns['field'](i)
        if row is None:continue
        for w,c in poly.items():
            for at,(j,jets) in enumerate(w):
                col=ns['field'](j);rest=w[:at]+w[at+1:]
                if col is None or any(mu!=3 for mu in jets) or rest!=((553+h,()),):continue
                v=c*((-1)**(parity(j)*sum(parity(k) for k,js in w[at+1:])))
                for mu in jets:v=times(v,I)
                if row<90 and col<90:sector='Y';rr,cc=row,col
                elif 90<=row<418 and 90<=col<418:sector='s';rr,cc=row-90,col-90
                elif 418<=row<463 and 418<=col<463:sector='C';rr,cc=row-418,col-418
                elif row>=463 and col>=463:sector='a';rr,cc=row-463,col-463
                else:raise AssertionError(('MC_OFF_DIAGONAL',row,col))
                out[sector][rr,cc]=out[sector].get((rr,cc),ZERO)+v
    out={k:clean(v) for k,v in out.items()};assert out['s']==p['R'][h]
    return out
MC=[mc_at(h) for h in range(45)];actual=[]
encode=lambda M:[[i,j,[[list(k),v.numerator,v.denominator] for k,v in c.terms]] for (i,j),c in sorted(M.items())]
for r,h,k,ix in [(13,0,12,136),(13,12,13,207),(13,13,14,207),(20,13,20,169),(44,13,44,134)]:
    beta={key[1:]:v for key,v in sourceBeta.items() if key[0]==r}
    for probe in range(2):
        H,UB,UL=p['u'][probe];W=weights(p['Om'],beta,p['J'][h],p['J'][k],UB,UL,H,MC[h],MC[k],45)
        Rx={(a,j):v for a,mat in enumerate(p['R']) for (j,i),v in mat.items() if i==ix}
        compact=contract(W,p['N'],Rx,MC[h]['s'],MC[k]['s']);oriented=[]
        for q in [1,-1]:
            ns.update(R_LABEL=r,C_LABEL=h,D_LABEL=k,X_LABEL=ix)
            G,V,groups=ns['matrices']('F',probe,q);X=ns['mm'](G,V)
            power={(i,i):{0:constant(1)} for i in range(508)}
            for n in range(5):power=ns['mm'](power,X)
            vals={'Mu':-ns['tr'](ns['mm'](power,groups['Mu_free'])),'Mx':-ns['tr'](ns['mm'](power,groups['Mx']))}
            for name,label in [('MC1',h),('MC2',k)]:vals[name]=-ns['tr'](ns['mm'](power,groups['MC_'+str(label)]))-ns['tr'](ns['mm'](power,groups['MC_scalar_'+str(label)]))
            assert vals==compact,(r,h,k,ix,probe,q,{a:str(b) for a,b in vals.items()},{a:str(b) for a,b in compact.items()})
            oriented.append({name:str(v) for name,v in vals.items()})
        assert oriented[0]==oriented[1]
        actual.append({'r':r,'h':h,'k':k,'ix':ix,'probe':probe,'root_families':oriented[0],'total':str(sum(compact.values(),ZERO)),'color_weights':{root:{kind:encode(M) for kind,M in part.items()} for root,part in W.items()}})
        print('STAGE actual '+str((r,h,k,ix,probe)),flush=True)
out={'schema':'UFM2_SCALAR_COLOR_COMPRESSION','generic_fixtures':generic,'actual_calibrations':actual,'whole_scalar_flow_and_beta_checks':True,'quantum_remainder_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'calibration_result.json.gz').open('xb') as f:f.write(gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
print('RESULT '+json.dumps({k:v for k,v in out.items() if k not in ['generic_fixtures','actual_calibrations']},sort_keys=True),flush=True);timer.cancel()
