from pathlib import Path
from itertools import permutations
from hashlib import sha256
import json,time,threading,os
from graded import *
O=Path(__file__).resolve().parent;tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in json.loads((O/'fixtures_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
words=sector_words();assert sum(len(list(permutations(ls))) for ls in LETTERS.values())==480
results=[]
for seed in [1,2,5]:
    def gen(m,n,t):return {(i,j):constant(seed*(t+1)+(i+1)**2*(j+2)+(j+1)**2-2*i*j) for i in range(m) for j in range(n)}
    Om={(0,0):constant(seed+2),(1,1):constant(seed+4),(0,1):constant(1),(1,0):constant(1)}
    N=gen(2,3,1);RR=gen(2,3,3);beta=gen(2,2,5);JB1=gen(2,2,7);JL1=gen(2,2,9);JB2=gen(2,2,11);JL2=gen(2,2,13);UB=gen(2,2,15);UL=gen(2,2,17)
    H={};A=plus(gen(2,2,19),transpose(gen(2,2,19)));B=gen(2,2,21);D=plus(gen(2,2,23),transpose(gen(2,2,23)))
    embed(H,A,0,0);embed(H,B,0,2);embed(H,scale(transpose(B),constant(-1)),2,0);embed(H,D,2,2)
    G={};embed(G,Om,0,0);embed(G,scale(identity(2),constant(-1)),0,2);embed(G,identity(2),2,0);embed(G,identity(3),4,4);embed(G,identity(2),7,9);embed(G,scale(identity(2),constant(-1)),9,7)
    Vn={};embed(Vn,N,2,4);embed(Vn,transpose(N),4,2)
    Vx={};embed(Vx,scale(RR,-I),0,4);embed(Vx,scale(transpose(RR),I),4,0)
    VJ={};embed(VJ,scale(beta,constant(-1)),7,2);embed(VJ,transpose(beta),2,7)
    VC=[]
    for JB,JL in [(JB1,JL1),(JB2,JL2)]:
        v={};embed(v,transpose(JB),0,9);embed(v,scale(transpose(JL),constant(-1)),2,9);embed(v,JB,9,0);embed(v,JL,9,2);VC.append(v)
    VH={};embed(VH,H,0,0)
    MU={};embed(MU,UB,9,0);embed(MU,UL,9,2)
    MX={};embed(MX,transpose(RR),4,7)
    MC=[]
    for t in [25,33]:
        m={};embed(m,gen(4,4,t),0,0);embed(m,gen(3,3,t+2),4,4);embed(m,gen(2,2,t+4),7,7);embed(m,gen(2,2,t+6),9,9);MC.append(m)
    X={name:multiply(G,v) for name,v in [('n',Vn),('x',Vx),('J',VJ),('C1',VC[0]),('C2',VC[1]),('u',VH)]}
    matrices={**X,'Mu':MU,'Mx':MX,'MC1':MC[0],'MC2':MC[1]}
    PX={k:lifted(v,MASK[k]) for k,v in matrices.items()}
    full={};reduced={};commuting=ZERO
    for root,letters in LETTERS.items():
        # Original480 words, each with exterior coefficients and supertrace.
        full[root]=-sum((poly_chain([PX[a] for a in word]+[PX[root]],11,7) for word in permutations(letters)),ZERO)
        reduced[root]=-sum((compact_chain([matrices[a] for a in word]+[matrices[root]],list(word)+[root],7) for word in words[root]),ZERO)
        commuting-=sum((poly_chain([PX[a] for a in word]+[PX[root]],11,7,0) for word in permutations(letters)),ZERO)
    assert full==reduced
    total=sum(full.values(),ZERO)
    exchanged=dict(matrices);exchanged['C1'],exchanged['C2']=matrices['C2'],matrices['C1'];exchanged['MC1'],exchanged['MC2']=matrices['MC2'],matrices['MC1']
    swapped=-sum((compact_chain([exchanged[a] for a in word]+[exchanged[root]],list(word)+[root],7) for root in LETTERS for word in words[root]),ZERO)
    assert total==-swapped
    badVJ={};embed(badVJ,scale(beta,constant(-1)),7,2);embed(badVJ,scale(transpose(beta),constant(-1)),2,7)
    badmat=dict(matrices);badmat['J']=multiply(G,badVJ)
    bad=-sum((compact_chain([badmat[a] for a in word]+[badmat[root]],list(word)+[root],7) for root in LETTERS for word in words[root]),ZERO)
    controls={'ghost_exchange_without_antisymmetry':total-swapped,'commuting_exterior':total-commuting,'wrong_JL_orientation':total-bad,**{'omit_'+k:v for k,v in full.items()}}
    results.append({'seed':seed,'root_families':{k:str(v) for k,v in full.items()},'total':str(total),'controls':{k:{'difference':str(v),'sensitive':bool(v)} for k,v in controls.items()}})
    print('STAGE fixture '+str(seed),flush=True)
assert all(any(row['controls'][name]['sensitive'] for row in results) for name in ['ghost_exchange_without_antisymmetry','commuting_exterior','wrong_JL_orientation'])
out={'schema':'UFM1_COMPLETE_F5_SECTOR_REDUCTION','sector_words':words,'word_counts':{k:len(v) for k,v in words.items()},'fixtures':results,'integer_fixture_is_physical_point':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'fixtures_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
