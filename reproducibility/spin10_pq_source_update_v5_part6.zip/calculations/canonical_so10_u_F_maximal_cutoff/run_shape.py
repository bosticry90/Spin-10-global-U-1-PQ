from pathlib import Path
from hashlib import sha256
import ast,json,gzip,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-F-maximal-cutoff-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings={str(R/p):h for p,h in json.loads((O/'inputs.json').read_bytes())['input_sha256'].items()}
    for p,h in bindings.items():assert H(Path(p))==h,p
    for name in ['.gitattributes','inputs.json','RECORD.md','COLOR_RECORD.md','SHAPE_RECORD.md','graded.py','color.py','model.py','shape.py','run_shape.py','survey_result.json']:
        p=O/name
        if p.suffix=='.py':ast.parse(p.read_bytes())
        cp=O/(name+'.source.txt')
        if cp.exists():assert cp.read_bytes()==p.read_bytes()
        else:
            with cp.open('xb') as f:f.write(p.read_bytes())
        bindings[str(p)]=H(p)
    dump(O/'shape_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    z=capture([sys.executable,'-B',str(O/'shape.py')])
    dump(O/'shape_capture.json',z);dump(C/'shape_full_capture.json',z)
    assert z['exit_code']==0 and z['calculation_completed'] and z['post_run_observations_qualified']
    assert json.loads((O/'shape_result.json').read_bytes())['elapsed_after_imports']<300
    assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<32*1024**2
    print('COMPLETED UFM_SHAPE',flush=True)
except BaseException:
    dump(O/'shape_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False})
    raise
