# Classical block-shape audit for a possible complete F5 identity

UFM3B complete r13 row has zero total effective color weights at all990
ghost pairs in BOTH probes, while family tensors are nonzero. The zero
therefore precedes N,R contractions. This suggests a smaller operator
identity but does not yet prove it for other sources.

Reconstruct and retain ALL free H_u and M_u color entries and their
Y-block supports from actual QG. Record complete beta index-type and
ghost tangent block supports from the action, with no quantum remainder.
These are classical input audits to derive a symbolic identity; no
unknown quantum coefficient is solved or fit. Any claimed symbolic
assumption must subsequently be checked against every actual block.
Use native300s,8GiB/350MiB/32MiB and unchanged UFM authority/scope bounds.
