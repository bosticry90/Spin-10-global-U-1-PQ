from graded import *
from functools import lru_cache
KINDS=('base','S1','ST1','S2','ST2')
def closed_paths(labels):
    out=[]
    def rec(at,current,seq,start):
        if at==len(labels):
            if current==start:out.append(seq)
            return
        edges=ROOTS[labels[at]] if labels[at] in ROOTS else EDGES[labels[at]]
        for row,col in sorted(edges):
            if row==current:rec(at+1,col,seq+[col],start)
    for start in ['Y','s','C','a']:rec(0,start,[start],start)
    return out
@lru_cache(None)
def templates():
    out=[]
    for root,words in sector_words().items():
        for word in words:
            labels=word+(root,)
            for sectors in closed_paths(labels):
                # The scalar row immediately before a non-scalar column.
                cuts=[i for i in range(6) if sectors[i]=='s' and sectors[i+1]!='s']
                assert len(cuts)==1,(labels,sectors)
                cut=cuts[0];end=(cut+1)%6;middle=[]
                while sectors[(end+1)%6]!='s':
                    middle.append((labels[end],sectors[end],sectors[end+1]));end=(end+1)%6
                start_label=labels[cut];end_label=labels[end]
                assert (start_label in ['x','Mx'] and end_label=='n') or (start_label=='n' and end_label=='x')
                scalar=[];at=(end+1)%6
                while at!=cut:
                    assert sectors[at]==sectors[at+1]=='s'
                    scalar.append(labels[at]);at=(at+1)%6
                assert len(scalar)<=1
                kind='base'
                if scalar:
                    assert scalar[0] in ['MC1','MC2']
                    kind=('ST' if start_label=='n' else 'S')+scalar[0][-1]
                factor=-literal_exterior_sign([MASK[k] for k in labels])*(-1 if sectors[0] in ['C','a'] else 1)
                out.append((root,kind,start_label,end_label,tuple(middle),factor))
    return out
def blocks(Om,beta,J1,J2,UB,UL,H,MC1,MC2,n):
    Gy=dict(Om)
    for i in range(n):Gy[i,n+i]=constant(-1);Gy[n+i,i]=constant(1)
    An={(i,j):-v for (i,j),v in identity(n).items()}
    Bn={(i,n+j):v for (i,j),v in identity(n).items()}
    Ax={};Bx={(i,j):times(I,v) for (i,j),v in identity(n).items()}
    embed(Ax,scale(Om,-I),0,0);embed(Ax,scale(identity(n),-I),n,0)
    JYC={};JaY={};embed(JYC,scale(transpose(beta),constant(-1)),0,0);embed(JaY,beta,0,n)
    values={('u','Y','Y'):multiply(Gy,H),('J','Y','C'):JYC,('J','a','Y'):JaY}
    for name,(JB,JL),mc in [('C1',J1,MC1),('C2',J2,MC2)]:
        Y_a={};embed(Y_a,plus(multiply(Om,transpose(JB)),transpose(JL)),0,0);embed(Y_a,transpose(JB),n,0)
        C_Y={};embed(C_Y,JB,0,0);embed(C_Y,JL,0,n)
        values[name,'Y','a']=Y_a;values[name,'C','Y']=C_Y
        for sector in ['Y','C','a']:values['M'+name,sector,sector]=mc[sector]
    U={};embed(U,UB,0,0);embed(U,UL,0,n);values['Mu','a','Y']=U
    return values,{'n':Bn,'x':Bx,'Mx':identity(n)},{'n':An,'x':Ax}
def weights(Om,beta,J1,J2,UB,UL,H,MC1,MC2,n):
    values,left,right=blocks(Om,beta,J1,J2,UB,UL,H,MC1,MC2,n)
    out={root:{kind:{} for kind in KINDS} for root in LETTERS}
    for root,kind,first,last,middle,factor in templates():
        mat=left[first]
        for key in middle:
            mat=multiply(mat,values[key])
            if not mat:break
        mat=multiply(mat,right[last])
        if first!='n':mat=transpose(mat)
        out[root][kind]=plus(out[root][kind],scale(mat,constant(factor)))
    return out
def contract(W,N,Rx,S1,S2):
    NR={'base':multiply(N,transpose(Rx)),
        'S1':multiply(multiply(N,S1),transpose(Rx)),
        'ST1':multiply(multiply(N,transpose(S1)),transpose(Rx)),
        'S2':multiply(multiply(N,S2),transpose(Rx)),
        'ST2':multiply(multiply(N,transpose(S2)),transpose(Rx))}
    return {root:sum((times(v,NR[kind].get(ij,ZERO)) for kind,M in part.items() for ij,v in M.items()),ZERO) for root,part in W.items()}
