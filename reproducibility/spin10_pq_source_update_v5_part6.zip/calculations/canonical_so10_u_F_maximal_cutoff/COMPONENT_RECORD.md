# UFM3A complete scalar images and feasibility survey

UFM2's five fixed triples agree with original508 matrices at their
selected scalar indices, but every scalar witness was zero. Their
nonzero color weights do not establish a zero or nonzero full tensor.

For ALL328 scalar components at each of those same five(r,h,k) triples,
compute every rooted family by two scalar associations: precontract
N R_a / N R_h R_a versus weight into N first, then R_h and R_a.
The latter distinguishes an intermediate cancellation from a missing
scalar component. Retain all nonzero entries, exact zeros and timings;
choose any further nonzero actual508 calibration only from NEW results.
No old quantum target or desired coefficient is an operand.

Also report actual sparse classical block supports, not a runtime-based
scientific verdict. Use actual R_h antisymmetry to combine S_h^t with
-S_h only after full scalar-flow checks. This survey does not substitute
for the full45x990x328 tensor. Its purpose is to select the least costly
competent complete contraction under the fixed300s/8GiB/32MiB bounds.
Resource exhaustion is incomplete, not zero. Same authority/scope limits.
