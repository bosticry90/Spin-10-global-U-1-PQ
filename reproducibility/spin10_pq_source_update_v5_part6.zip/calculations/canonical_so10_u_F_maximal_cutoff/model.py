from pathlib import Path
from collections import defaultdict
import ast
from color import *
from actual import load,primitives,co,dec,parity
O=Path(__file__).resolve().parent;R=O.parents[1]
def make(role):
    d=load(role);p=primitives(d,role)
    beta={tuple(z[:-1]):co(z[-1]) for z in d['beta']}
    if role=='replay':
        beta={}
        for w,v in d['source_action']:
            if len(w)==3 and 0<=w[0]<45 and 135<=w[1]<180 and 225<=w[2]<270:beta[w[0],w[1]-135,w[2]-225]=co(v)
        assert beta=={tuple(z[:-1]):co(z[-1]) for z in d['beta']}
    p['beta']=[{(c,a):v for (rr,c,a),v in beta.items() if rr==r} for r in range(45)]
    def field(i):
        if i<180:return i//4 if i%4==3 else None
        if i<508:return 90+i-180
        if i<553:return 45+i-508
        if i<598:return 418+i-553
        return 463+i-598
    MC=[{k:{} for k in ['Y','s','C','a']} for _ in range(45)]
    for i,poly in p['flows'].items():
        row=field(i)
        if row is None:continue
        for w,c in poly.items():
            for at,(j,jets) in enumerate(w):
                col=field(j);rest=w[:at]+w[at+1:]
                if col is None or any(mu!=3 for mu in jets) or len(rest)!=1 or rest[0][1] or not 553<=rest[0][0]<598:continue
                h=rest[0][0]-553;v=c*((-1)**(parity(j)*sum(parity(k) for k,js in w[at+1:])))
                for mu in jets:v=times(v,I)
                if row<90 and col<90:sector='Y';rr,cc=row,col
                elif 90<=row<418 and 90<=col<418:sector='s';rr,cc=row-90,col-90
                elif 418<=row<463 and 418<=col<463:sector='C';rr,cc=row-418,col-418
                elif row>=463 and col>=463:sector='a';rr,cc=row-463,col-463
                else:raise AssertionError(('MC_OFF_DIAGONAL',row,col))
                tab=MC[h][sector];tab[rr,cc]=tab.get((rr,cc),ZERO)+v
    p['MC']=[{k:clean(v) for k,v in part.items()} for part in MC]
    assert all(part['s']==p['R'][h] for h,part in enumerate(p['MC']))
    return d,p
def effective(part):
    return {'base':part['base'],'S1':plus(part['S1'],scale(part['ST1'],constant(-1))),'S2':plus(part['S2'],scale(part['ST2'],constant(-1)))}
def scalar_image(part,p,h,k,method,cache):
    part=effective(part);out={}
    for kind,W in part.items():
        if not W:continue
        nh=None if kind=='base' else h if kind=='S1' else k
        if method=='primary':
            if nh not in cache:
                N=p['N'] if nh is None else multiply(p['N'],p['R'][nh])
                rows=[]
                for Ra in p['R']:
                    z=defaultdict(list)
                    for (b,i),v in multiply(N,Ra).items():z[b].append((i,v))
                    rows.append(z)
                cache[nh]=rows
            for (b,a),v in W.items():
                for i,c in cache[nh][a].get(b,[]):out[i]=out.get(i,ZERO)+times(v,c)
        else:
            wn={};nrows=cache.get('N_rows')
            if nrows is None:
                nrows=defaultdict(list)
                for (b,j),v in p['N'].items():nrows[b].append((j,v))
                cache['N_rows']=nrows
            for (b,a),v in W.items():
                for j,c in nrows.get(b,[]):wn[a,j]=wn.get((a,j),ZERO)+times(v,c)
            if nh is not None:wn=multiply(clean(wn),p['R'][nh])
            arows=defaultdict(dict)
            for (a,j),v in wn.items():
                if v:arows[a][0,j]=v
            for a,row in arows.items():
                for (_,i),v in multiply(row,p['R'][a]).items():out[i]=out.get(i,ZERO)+v
    return clean(out)
