# UFM4B full applicability and proof review

Review180s after imports, same8GiB/350MiB/32MiB limits. Validate ALL
actual blocks for both stored and reconstructed classical data against
the typed identity: free H/M_u,G,all45 vector/ghost tangents and GF J
vertices,source beta support,scalar antisymmetry. Extract T_h as the
coefficient of degree1 g in A_h; never introduce negative coupling powers.
No fitting of a quantum breaking or favorable parameter point.

Export all expanded typed root polynomials (not only native word counts)
and zero residuals. Check rectangular word types and transpose algebra,
all eight probe/ghost-type cases, and sensitive finite controls. Compare
entire r13 family tensors and zero complements between scalar routes.
Select nonzero original508 calibrations only from newly computed rooted
families, including actual cancellations hidden by total zero. Check both
momentum signs and save each family. No old quantum target is needed.

If all applicability checks pass, qualify complete F5=0 for every
45x990x328 coefficient in both probes by the dimension-independent
identity, rather than extrapolating source13. Do not claim complete
individual-family tensor extraction for other sources. C4 nonlinear
calculation remains necessary for full F log5 (now C4 if F5=0). Full
continuum/finite-contact/QAP/E5/physical obligations remain unchanged.
