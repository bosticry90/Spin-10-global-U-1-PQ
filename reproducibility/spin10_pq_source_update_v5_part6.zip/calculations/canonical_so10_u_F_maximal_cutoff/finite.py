from pathlib import Path
from hashlib import sha256
import json,time,threading,os
from model import *
O=Path(__file__).resolve().parent;tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,h in json.loads((O/'finite_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==h,path
N=5;S=4;NB=14;NC0=14;NA0=19;DIM=24
def gen(m,n,t,seed):return {(i,j):constant(seed*(t+1)+(i+1)**2*(j+2)+(j+1)**2-2*i*j) for i in range(m) for j in range(n)}
def skew(n,t,seed):return plus(gen(n,n,t,seed),scale(transpose(gen(n,n,t,seed)),constant(-1)))
def gauge(label,kind,seed):
    T={}
    if kind=='H':embed(T,skew(2,label,seed),0,0)
    else:
        HB=gen(2,3,label,seed);embed(T,HB,0,2);embed(T,scale(transpose(HB),constant(-1)),2,0)
    embed(T,skew(3,label+2,seed),2,2)
    A=scale(T,co('g10'));BB={(i,j):v for (i,j),v in T.items() if i>=2 and j>=2}
    L=scale(BB,co('g10')) if kind=='H' else {}
    Y={};embed(Y,A,0,0);embed(Y,L,5,5)
    JB=scale({(i,j):v for (i,j),v in T.items() if i<2 and j<2} if kind=='H' else T,-I*co('g10'))
    JL={} if kind=='H' else scale(BB,I*co('xi'))
    return T,(JB,JL),{'Y':Y,'C':A,'a':L}
def full_sum(X,roots,odds=ODD):
    power={(i,i):{0:constant(1)} for i in range(DIM)}
    for n in range(5):power=pmul(power,X,odds)
    result={}
    for name,M in roots.items():
        z=pmul(power,lifted(M,MASK[name]),odds)
        result[name]=-sum((poly.get(TARGET,ZERO)*(-1 if i>=NB else 1) for (i,j),poly in z.items() if i==j),ZERO)
    return result
results=[]
cases=[(2,p,a,b) for p in range(2) for a in ['H','B'] for b in ['H','B']]+[(5,p,'B','B') for p in range(2)]
for seed,probe,ht,kt in cases:
    Om={(i,i):co('eta_H' if i<2 else 'xi') for i in range(N)}
    P={(i,i):constant(1) for i in range(N) if (i<2)==(probe==0)}
    H={};embed(H,scale(P,constant(-2)),0,0);embed(H,multiply(Om,P),0,5);embed(H,scale(multiply(Om,P),constant(-1)),5,0);embed(H,scale(multiply(multiply(Om,Om),P),constant('1/2')),5,5)
    UB=scale(P,-2*I);UL=scale(multiply(Om,P),I);beta={};embed(beta,gen(2,3,2,seed),0,2)
    nmat=gen(5,4,4,seed);rx=gen(5,4,6,seed)
    _,J1,MC1=gauge(8,ht,seed);_,J2,MC2=gauge(12,kt,seed)
    MC1['s']=skew(4,16,seed);MC2['s']=skew(4,18,seed)
    G={};embed(G,Om,0,0);embed(G,scale(identity(5),constant(-1)),0,5);embed(G,identity(5),5,0);embed(G,identity(4),10,10);embed(G,identity(5),14,19);embed(G,scale(identity(5),constant(-1)),19,14)
    Vn={};embed(Vn,nmat,5,10);embed(Vn,transpose(nmat),10,5)
    Vx={};embed(Vx,scale(rx,-I),0,10);embed(Vx,scale(transpose(rx),I),10,0)
    VJ={};embed(VJ,scale(beta,constant(-1)),14,5);embed(VJ,transpose(beta),5,14)
    VCs=[]
    for JB,JL in [J1,J2]:
        V={};embed(V,transpose(JB),0,19);embed(V,scale(transpose(JL),constant(-1)),5,19);embed(V,JB,19,0);embed(V,JL,19,5);VCs.append(V)
    VH={};embed(VH,H,0,0)
    MU={};embed(MU,UB,19,0);embed(MU,UL,19,5)
    MX={};embed(MX,transpose(rx),10,14)
    MC=[]
    for part in [MC1,MC2]:
        M={};embed(M,part['Y'],0,0);embed(M,part['s'],10,10);embed(M,part['C'],14,14);embed(M,part['a'],19,19);MC.append(M)
    matrix={name:multiply(G,V) for name,V in [('n',Vn),('x',Vx),('J',VJ),('C1',VCs[0]),('C2',VCs[1]),('u',VH)]}
    X={}
    for name,M in matrix.items():
        for ij,v in M.items():X.setdefault(ij,{})[MASK[name]]=v
    roots={'Mu':MU,'Mx':MX,'MC1':MC[0],'MC2':MC[1]}
    values=full_sum(X,roots)
    W=weights(Om,beta,J1,J2,UB,UL,H,MC1,MC2,5)
    compact=contract(W,nmat,rx,MC1['s'],MC2['s']);assert values==compact
    total=sum(values.values(),ZERO);assert not total
    wrongVJ=dict(VJ)
    for ij in wrongVJ:
        if ij[0]<NB:wrongVJ[ij]=-wrongVJ[ij]
    wrongJ=multiply(G,wrongVJ);badX={ij:{mask:v for mask,v in poly.items() if mask!=JJ} for ij,poly in X.items()}
    for ij,v in wrongJ.items():badX.setdefault(ij,{})[JJ]=v
    badsource=sum(full_sum(badX,roots).values(),ZERO)
    badexterior=sum(full_sum(X,roots,0).values(),ZERO)
    badroots={name:dict(M) for name,M in roots.items()}
    for name in ['MC1','MC2']:
        for ij in badroots[name]:
            if 14<=ij[0]<19 and 14<=ij[1]<19:badroots[name][ij]=-badroots[name][ij]
    badghost=sum(full_sum(X,badroots).values(),ZERO)
    controls={'omit_Mu':values['Mu'],'omit_Hu':sum((v for k,v in values.items() if k!='Mu'),ZERO),'wrong_JL_orientation':-badsource,'commuting_exterior':-badexterior,'wrong_C_tangent_sign':-badghost}
    results.append({'seed':seed,'probe':probe,'ghost_types':[ht,kt],'root_families':{k:str(v) for k,v in values.items()},'total':str(total),'controls':{k:{'difference':str(v),'sensitive':bool(v)} for k,v in controls.items()}})
    print('STAGE typed_finite '+str((seed,probe,ht,kt)),flush=True)
for name in results[0]['controls']:assert any(z['controls'][name]['sensitive'] for z in results),name
out={'schema':'UFM4A_TYPED_FINITE_FULL_MATRIX_CONFIRMATION','results':results,'all480_words_by_unrooted_powers':True,'color_dimensions':[2,3],'scalar_dimension':4,'physical_parameter_points':False,'quantum_target_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'finite_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({k:v for k,v in out.items() if k!='results'},sort_keys=True),flush=True);timer.cancel()
