from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import defaultdict
import json,sys,time,threading,os
from model import co
from color import templates,KINDS,LETTERS
from algebra import Coeff,ZERO,I,constant
O=Path(__file__).resolve().parent
class NC:
    def __init__(self,terms=None):self.terms={w:c for w,c in (terms or {}).items() if c}
    def __bool__(self):return bool(self.terms)
    def __add__(self,other):
        if isinstance(other,int):other=scalar(constant(other))
        z=dict(self.terms)
        for w,c in other.terms.items():z[w]=z.get(w,ZERO)+c
        return NC(z)
    __radd__=__add__
    def __neg__(self):return NC({w:-c for w,c in self.terms.items()})
    def __sub__(self,other):return self+(-other)
    def __mul__(self,other):
        if isinstance(other,int):other=scalar(constant(other))
        z={}
        for w,c in self.terms.items():
            for ww,v in other.terms.items():z[w+ww]=z.get(w+ww,ZERO)+c*v
        return NC(z)
    __rmul__=__mul__
    def T(self):return NC({tuple((name,1-at) for name,at in w[::-1]):c for w,c in self.terms.items()})
Z=NC();one=None
def scalar(c):return NC({():c})
def var(name):return NC({((name,0),):constant(1)})
def clean(M):return {ij:v for ij,v in M.items() if v}
def plus(*ms):
    out={}
    for M in ms:
        for ij,v in M.items():out[ij]=out.get(ij,Z)+v
    return clean(out)
def scale(M,c):
    if isinstance(c,Coeff):c=scalar(c)
    return clean({ij:v*c for ij,v in M.items()})
def transpose(M):return {(j,i):v.T() for (i,j),v in M.items()}
def multiply(A,B):
    rows=defaultdict(list);out={}
    for (i,j),v in B.items():rows[i].append((j,v))
    for (i,k),v in A.items():
        for j,w in rows[k]:out[i,j]=out.get((i,j),Z)+v*w
    return clean(out)
def identity(n):return {(i,i):scalar(constant(1)) for i in range(n)}
def embed(out,M,ro,co):
    for (i,j),v in M.items():out[i+ro,j+co]=v
def generic(name):return {(i,j):var(name+'_'+str(i)+str(j)) for i in range(2) for j in range(2)}
def symbolic(probe):
    Om={(0,0):scalar(co('eta_H')),(1,1):scalar(co('xi'))};P={(probe,probe):scalar(constant(1))}
    beta={(0,1):var('beta')};J1=(generic('J1B'),generic('J1L'));J2=(generic('J2B'),generic('J2L'))
    UB=scale(P,-2*I);UL=scale(multiply(Om,P),I);H={}
    embed(H,scale(P,constant(-2)),0,0);embed(H,multiply(Om,P),0,2);embed(H,scale(multiply(Om,P),constant(-1)),2,0);embed(H,scale(multiply(multiply(Om,Om),P),constant(Fraction(1,2))),2,2)
    MC=[]
    for name in ['MC1','MC2']:
        Y={};embed(Y,generic(name+'B'),0,0);embed(Y,generic(name+'L'),2,2)
        MC.append({'Y':Y,'C':generic(name+'C'),'a':generic(name+'a')})
    # Execute the frozen algebraic compiler against a free noncommuting
    # matrix ring. No finite-size scalar substitution is made.
    import ast
    tree=ast.parse((O/'color.py').read_bytes());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['blocks','weights']]
    ns=dict(globals());ns['times']=lambda a,b:a*b;ns['constant']=lambda n:scalar(constant(n));ns['I']=scalar(I);ns['templates']=templates
    required=set()
    import builtins
    for node in nodes:
        assigned={a.arg for a in node.args.args}|{n.id for n in ast.walk(node) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Store)}
        required|={n.id for n in ast.walk(node) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Load)}-assigned
    required-={n.name for n in nodes}
    assert all(name in ns or hasattr(builtins,name) for name in required),sorted(name for name in required if name not in ns and not hasattr(builtins,name))
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'UFM_FREE_WORD_COLOR_COMPILER','exec'),ns)
    return ns['weights'](Om,beta,J1,J2,UB,UL,H,MC[0],MC[1],2)
def encode(M):return [[i,j,[[[[name,at] for name,at in w],str(c)] for w,c in sorted(v.terms.items())]] for (i,j),v in sorted(M.items())]
if __name__=='__main__':
    tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
    for path,h in json.loads((O/'symbolic_preparation_v3.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==h,path
    results=[]
    for probe in range(2):
        W=symbolic(probe);total={kind:plus(*(root[kind] for root in W.values())) for kind in KINDS}
        eff={'base':total['base'],'S1':plus(total['S1'],scale(total['ST1'],constant(-1))),'S2':plus(total['S2'],scale(total['ST2'],constant(-1)))}
        results.append({'probe':probe,'root_word_counts':{root:{kind:sum(len(v.terms) for v in M.values()) for kind,M in part.items()} for root,part in W.items()},'total_effective_weights':{kind:encode(M) for kind,M in eff.items()},'total_word_counts':{kind:sum(len(v.terms) for v in M.values()) for kind,M in eff.items()},'stated_assumptions_suffice_for_zero':not any(eff.values())})
        print('STAGE free_word '+json.dumps({k:v for k,v in results[-1].items() if k!='total_effective_weights'},sort_keys=True),flush=True)
    out={'schema':'UFM3C_NONCOMMUTING_TYPE_IDENTITY_TEST','results':results,'not_an_actual_model_refutation_if_nonzero':True,'quantum_target_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
    with (O/'symbolic_result_v3.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
    print('RESULT '+json.dumps({k:v for k,v in out.items() if k!='results'},sort_keys=True),flush=True);timer.cancel()
