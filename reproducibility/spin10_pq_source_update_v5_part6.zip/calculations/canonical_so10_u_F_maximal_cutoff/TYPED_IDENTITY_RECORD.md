# UFM3E dimension-independent identity with actual ghost-block relations

UFM3D identified complete classical relations, independently of quantum
results. Write each actual vector tangent A_h=g10 T_h; A_h is exactly
degree1 in g10, so T_h is its coefficient polynomial, NOT an inverse-
coupling insertion or counterterm. All T_h are to be checked skew and
respect [H,H] subset H. H/broken are color types, not1D subspaces.

For an unbroken external ghost h:
 M_C,B=g T_h, M_C,C=g T_h,
 M_C,L=M_C,a=g P_B T_h P_B,
 J_B=-i g P_H T_h P_H, J_L=0.
For broken h:
 M_C,B=M_C,C=g T_h, M_C,L=M_C,a=0,
 J_B=-i g T_h, J_L=i xi P_B T_h P_B.

Keep arbitrary rectangular beta:H<-broken, generic noncommuting skew
T_h with the stated blocks, actual free H_u/M_u forms and central eta/xi.
Test BOTH probes and all four ghost-type pairs. Retain expanded free
words, root families and complete residuals; a nonzero residual means
these assumptions are insufficient, not actual-model refutation.

If and only if the total free-word polynomial is zero AND every actual
block obeys these relations, it proves complete F5 cancellation for all
source/scalar labels. This is stronger than selected numerical zero or
row extrapolation. Require sensitive nonzero individual-family controls,
typed finite-matrix independent confirmation and all-model input audit
in subsequent review before qualification. The nonlinear C4 and hence
full F log5 identity remain open. No quantum target, fitted coefficient,
physical scheme/benchmark or authority change. Same resource limits.
