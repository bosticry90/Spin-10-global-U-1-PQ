# UFM3D complete classical ghost-block identification

The free-word test with only free H/M_u shape and beta support is
NONZERO (120/302 base words); S/ST weight types cancel already. This
does not refute the actual row zero. Additional action-derived ghost
block restrictions, if used in a proof, must be identified independently.

Partition ALL actual J_B,J_L,M_C blocks into H/broken row/column types.
Compare their entrywise proportionality with the vector adjoint block,
retaining every unequal/missing entry and exact ratio class. These are
classical tree-action identities; do not infer them from quantum zero,
change a matrix or fit an unknown loop coefficient. Report insufficiency
where a single ratio does not apply. No constant is a physical fit.
All UFM limits unchanged. This audit can supply only actually verified
assumptions for a subsequent complete noncommuting identity test.
