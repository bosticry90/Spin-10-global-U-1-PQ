from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from fractions import Fraction
import ast,json,gzip,sys,time,threading,os
from model import *
import typed_identity as TI
O=Path(__file__).resolve().parent;R=O.parents[1]
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda q:json.loads(q.read_bytes())
loadz=lambda q:json.loads(gzip.decompress(q.read_bytes()))
for path,h in read(O/'review_preparation.json')['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==h,path
d,p=make('primary');dr,pr=make('replay')
for key in ['beta','MC','J','N','R','u','G']:assert p[key]==pr[key],key
audits=[]
for h,MC in enumerate(p['MC']):
    A={(i,j):v for (i,j),v in MC['Y'].items() if i<45 and j<45}
    assert all(all(a==1 and b==c==0 for (a,b,c,m),v in z.terms) for z in A.values())
    T={ij:Coeff([((a-1,b,c,m),v) for (a,b,c,m),v in z.terms]) for ij,z in A.items()}
    assert scale(T,co('g10'))==A and T==scale(transpose(T),constant(-1))
    if h<12:assert all((i<12)==(j<12) for i,j in A)
    else:assert all(i>=12 or j>=12 for i,j in A)
    TB={(i,j):v for (i,j),v in T.items() if i>=12 and j>=12}
    L=scale(TB,co('g10')) if h<12 else {}
    Y=dict(A)
    for (i,j),v in L.items():Y[45+i,45+j]=v
    assert MC['Y']==Y and MC['C']==A and MC['a']==L and MC['s']==p['R'][h]
    JB=scale({ij:v for ij,v in A.items() if ij[0]<12 and ij[1]<12} if h<12 else A,-I)
    JL={} if h<12 else scale(TB,I*co('xi'))
    assert p['J'][h]==(JB,JL)
    audits.append({'ghost':h,'type':'H' if h<12 else 'B','vector_tangent_nonzeros':len(A),'JB_nonzeros':len(JB),'JL_nonzeros':len(JL),'all_assumptions_verified':True})
for probe,(H,UB,UL) in enumerate(p['u']):
    P={(i,i):constant(1) for i in range(45) if (i<12)==(probe==0)}
    HH={};embed(HH,scale(P,constant(-2)),0,0);embed(HH,multiply(p['Om'],P),0,45);embed(HH,scale(multiply(p['Om'],P),constant(-1)),45,0);embed(HH,scale(multiply(multiply(p['Om'],p['Om']),P),constant('1/2')),45,45)
    assert H==HH and UB==scale(P,-2*I) and UL==scale(multiply(p['Om'],P),I)
assert all(all(c<12 and a>=12 for c,a in mat) for mat in p['beta'])
beta_count=sum(len(mat) for mat in p['beta'])
assert all(mat==scale(transpose(mat),constant(-1)) for mat in p['R'])

# Exact rectangular free-word proof; the variable names carry arbitrary
# internal H/broken matrix dimensions, not scalar commuting substitutes.
def vartype(name,at):
    base=(0,1) if name=='beta' or name.endswith('HB') else (0,0) if 'HH_skew' in name else (1,1) if 'BB_skew' in name else None
    assert base is not None,name
    return base[::-1] if at else base
proof=[];checked_words=0;nonzero_root_cases=0
for probe in range(2):
    for ht in ['H','B']:
        for kt in ['H','B']:
            W=TI.evaluate(probe,ht,kt)
            for part in W.values():
                for M in part.values():
                    for (i,j),value in M.items():
                        for word,c in value.terms.items():
                            assert word
                            types=[vartype(name,at) for name,at in word]
                            assert types[0][0]==i and types[-1][1]==j and all(a[1]==b[0] for a,b in zip(types,types[1:]));checked_words+=1
                            # Transpose is an involution, including skew signs.
                            atom=TI.NC({word:c});assert atom.T().T().terms==atom.terms
            totals={kind:TI.plus(*(part[kind] for part in W.values())) for kind in TI.KINDS}
            eff={'base':totals['base'],'S1':TI.plus(totals['S1'],TI.scale(totals['ST1'],constant(-1))),'S2':TI.plus(totals['S2'],TI.scale(totals['ST2'],constant(-1)))}
            assert not any(eff.values())
            roots={}
            for root,part in W.items():
                effective_root={'base':part['base'],'S1':TI.plus(part['S1'],TI.scale(part['ST1'],constant(-1))),'S2':TI.plus(part['S2'],TI.scale(part['ST2'],constant(-1)))}
                if any(effective_root.values()):nonzero_root_cases+=1
                roots[root]={kind:TI.encode(M) for kind,M in part.items()}
            proof.append({'probe':probe,'ghost_types':[ht,kt],'root_polynomials':roots,'effective_residual':{kind:TI.encode(M) for kind,M in eff.items()}})
assert nonzero_root_cases
with (O/'expanded_typed_proof.json.gz').open('xb') as f:f.write(gzip.compress((json.dumps(proof,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
a,b=TI.var('A'),TI.var('B');assert (a*b).T().terms==(b.T()*a.T()).terms and (a*b).terms!=(b*a).terms
finite=read(O/'finite_result.json');assert len(finite['results'])==10
for name in finite['results'][0]['controls']:assert any(z['controls'][name]['sensitive'] for z in finite['results'])
assert all(z['total']=='0' for z in finite['results'])
primary=loadz(O/'primary_row13.json.gz');replay=loadz(O/'replay_row13.json.gz');assert primary['results']==replay['results']
def decode_rows(rows):
    out={}
    for h,k,ix,terms in rows:
        assert 0<=h<k<45 and 0<=ix<328 and (h,k,ix) not in out
        out[h,k,ix]=Coeff([(tuple(key),Fraction(n,d)) for key,n,d in terms]);assert out[h,k,ix]
    return out
selected=[];row_counts=[]
for entry in primary['results']:
    assert entry['source']==13 and entry['domain_positions']==324720 and not entry['total']
    families={root:decode_rows(rows) for root,rows in entry['root_families'].items()}
    total={}
    for root,tab in families.items():
        assert len(tab)==entry['nonzero_counts'][root]
        for key,v in tab.items():total[key]=total.get(key,ZERO)+v
        if tab:selected.append((entry['probe'],*next(iter(sorted(tab))),root))
    assert not any(total.values())
    assert entry['module_diagnostic']=={'pairs':990,'summed_effective_all_zero':990,'weighted_N_zero':990}
    row_counts.append({'probe':entry['probe'],'positions':324720,'root_nonzeros':{root:len(tab) for root,tab in families.items()},'total_nonzeros':0})
print('STAGE entire_model_and_symbolic_applicability_verified',flush=True)

# Actual positive-root calibrations selected from the new full row.
tree=ast.parse((R/'calculations/canonical_so10_u_maximal_heat_cutoff/native.py').read_bytes());names={'field','qpow','sign','padd','pmul','mm','add','tr','m0groups','matrices'}
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
matnode=next(n for n in nodes if n.name=='matrices');matnode.body[:3]=ast.parse('r=13\nix=X_LABEL\ncs=[(C_LABEL,CC1),(D_LABEL,CC2)]').body;ast.fix_missing_locations(matnode)
beta={tuple(z[:-1]):co(z[-1]) for z in d['beta']}
ns={'defaultdict':defaultdict,'lru_cache':lru_cache,'ZERO':ZERO,'constant':constant,'times':times,'I':I,'parity':parity,
    'flows':p['flows'],'RR':p['R'],'N':p['N0'],'J0':p['J0'],'B':p['B'],'beta':beta,'free':p['free'],'d':d,'dec':dec,
    'NB':418,'NC':418,'NA':463,'DIM':508,'EPS':1,'UU':2,'JJ':4,'CC1':8,'CC2':16,'NN':32,'XX':64,'TARGET':127,'ODD':29}
exec(compile(ast.Module(body=nodes,type_ignores=[]),'UFM_ACTUAL_POSITIVE_ROOT_ROUTE','exec'),ns)
unique=sorted({(probe,h,k,ix) for probe,h,k,ix,root in selected});calibrations=[]
for probe,h,k,ix in unique:
    original=[]
    for q in [1,-1]:
        ns.update(C_LABEL=h,D_LABEL=k,X_LABEL=ix)
        G,V,groups=ns['matrices']('F',probe,q);X=ns['mm'](G,V);power={(i,i):{0:constant(1)} for i in range(508)}
        for n in range(5):power=ns['mm'](power,X)
        vals={'Mu':-ns['tr'](ns['mm'](power,groups['Mu_free'])),'Mx':-ns['tr'](ns['mm'](power,groups['Mx']))}
        for root,label in [('MC1',h),('MC2',k)]:vals[root]=-ns['tr'](ns['mm'](power,groups['MC_'+str(label)]))-ns['tr'](ns['mm'](power,groups['MC_scalar_'+str(label)]))
        expected={root:decode_rows(primary['results'][probe]['root_families'][root]).get((h,k,ix),ZERO) for root in LETTERS}
        assert vals==expected and not sum(vals.values(),ZERO) and any(vals.values())
        original.append({'q':q,'roots':{root:str(v) for root,v in vals.items()}})
    assert original[0]['roots']==original[1]['roots']
    calibrations.append({'probe':probe,'source':13,'ghosts':[h,k],'scalar':ix,'original508':original})
    print('STAGE positive_root '+str((probe,h,k,ix)),flush=True)
out={'schema':'UFM4B_FULL_F5_IDENTITY_APPLICABILITY','all45_ghost_block_audits':audits,'source_beta_entries_checked':beta_count,'free_probe_blocks_checked':2,
     'primary_reconstructed_classical_data_equal':True,'noncommuting_word_type_checks':checked_words,'nonzero_symbolic_root_cases':nonzero_root_cases,'symbolic_cases':8,'finite_cases':10,
     'entire_F5_zero_by_dimension_independent_identity':True,'coefficient_domain_per_probe':45*990*328,'probes':2,'source13_complete_root_counts':row_counts,'actual_positive_root_calibrations':calibrations,
     'known_quantum_remainder_operand':False,'full_F_log5_C4_or_QAP_claim':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({k:v for k,v in out.items() if k not in ['all45_ghost_block_audits','actual_positive_root_calibrations']},sort_keys=True),flush=True);timer.cancel()
