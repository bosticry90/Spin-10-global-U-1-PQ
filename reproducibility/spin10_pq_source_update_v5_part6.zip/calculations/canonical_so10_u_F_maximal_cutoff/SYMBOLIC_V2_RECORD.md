# UFM3C symbolic adapter continuation V2

Original free-word test FAILED before any symbolic result: the compiler
adapter did not supply its times multiplication helper (NameError).
Original source, preparation and full capture remain FAILED. V2 binds
times(a,b)=a*b in the free-word ring, without changing the compiler,
assumptions, expected evidence, tests, resource bounds or physical inputs.
No original failure is relabelled PASS.
