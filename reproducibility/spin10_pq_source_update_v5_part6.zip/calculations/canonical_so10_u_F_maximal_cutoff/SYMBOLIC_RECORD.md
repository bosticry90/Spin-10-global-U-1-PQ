# UFM3C noncommuting block identity test

The actual free blocks have a common action-derived form for P=P_H or
P_broken, with [P,Omega]=0:

 H=[[-2P,Omega P],[-Omega P,Omega^2 P/2]],
 M_u[a,Y]=[-2iP,i Omega P].

All source beta_r have only (ghost H,auxiliary broken) entries, and all
M_C,Y have diagonal B/B and Lambda/Lambda blocks. Test whether these
already suffice to annihilate the complete F5 color weights; do not
assume the answer. Model the color decomposition H+broken with arbitrary
rectangular noncommuting symbols in J_B,J_L,ghost tangents and beta.
Keep transpose as a genuine word-reversing anti-involution. Omega has
the actual central eta_H/xi widths in the two color types. Retain every
expanded word and root family, with a finite exact coefficient ring.

A zero reduced free-word polynomial is a dimension-independent identity
under its stated assumptions. A nonzero polynomial identifies additional
relations that would be needed; it does not refute actual model cancellation.
Any further relation must be derived/tested against the actual action,
not chosen to cancel a quantum target. Probe every ghost class without
assuming their matrices commute. Both probes, all effective scalar weight
types; full native/replay tensor claim remains open until proof applies.
Native300s,8GiB/350MiB/32MiB bounds unchanged; no authority change.
