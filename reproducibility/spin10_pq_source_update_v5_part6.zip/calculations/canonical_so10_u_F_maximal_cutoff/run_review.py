from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-F-maximal-cutoff-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings={str(R/p):h for p,h in json.loads((O/'inputs.json').read_bytes())['input_sha256'].items()}
    for path,h in bindings.items():assert H(Path(path))==h,path
    for name in ['RECORD.md','REVIEW_RECORD.md','graded.py','color.py','model.py','noncommuting_v3.py','typed_identity.py','review.py','run_review.py','fixtures_result.json','calibration_result.json.gz','survey_result.json','shape_result.json','ghost_shape_result.json','symbolic_result_v3.json','typed_result.json','finite_result.json','primary_row13.json.gz','replay_row13.json.gz']:
        path=O/name
        if path.suffix=='.py':ast.parse(path.read_bytes())
        if path.suffix!='.gz':
            cp=O/(name+'.source.txt')
            if cp.exists():assert cp.read_bytes()==path.read_bytes()
            else:
                with cp.open('xb') as f:f.write(path.read_bytes())
        bindings[str(path)]=H(path)
    dump(O/'review_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    z=capture([sys.executable,'-B',str(O/'review.py')])
    dump(O/'review_capture.json',z);dump(C/'review_full_capture.json',z)
    assert z['exit_code']==0 and z['calculation_completed'] and z['post_run_observations_qualified']
    assert json.loads((O/'review_result.json').read_bytes())['elapsed_after_imports']<180
    assert sum(path.stat().st_size for path in O.iterdir() if path.is_file())<32*1024**2
    print('COMPLETED UFM4B',flush=True)
except BaseException:
    dump(O/'review_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False})
    raise
