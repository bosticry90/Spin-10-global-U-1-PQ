# Next bounded calculation: nonlinear fourth-edge F operator

Proposal only; not executed C4 evidence. UFM has removed C5 as an open
dependency by a complete typed proof, retaining all nonzero root families.
The actual remaining log5 cutoff is C4_F in the same fixed reference.

Start from the authenticated general_v2 builder, which already includes
full GF Euler columns, source density, QG and scalar current. Replace
selected labels with complete role support, not a loop over14,612,400
full508 matrices. Each four-edge term has exactly one additional positive
grade compared with the maximal single-grade vertices/root. Enumerate
all root/vertex grade partitions of (u,nu,JL,C1,C2,x), then actual quantum
sector paths. Include merged vertices V_nx,V_nC,V_CC,V_JC; free and
intrinsic H_u/M_u; original nonlinear M_CC; and any further action-derived
eligible pattern. An abstract guessed list is not a complete inventory.

Recover actual complete patterns by source/field derivatives BEFORE
restriction. Use the qualified GF/source transpose and source-Euler
sign conventions. Keep distinct ghosts and odd JL. Check both-broken
sectors where GF-aaCC and source-D are nonzero. Preserve whole-support
exclusions (classical QG source2, disconnected physical potential/fermion
ports) only within their actual inherited proof scopes. Quantum source2
contact Euler contributions on conversion are still required.

The least expensive competent first test is a complete typed support
inventory with closed sector/grade walks, followed by noncommuting
fixtures and sensitive actual coefficients. If that yields a compact
formula, compute the whole C4 tensor by distinct contractions, including
all zero complements, before opening the old relative-conversion table.
Retain all remainders if comparison fails. No fitted contacts, favorable
parameter changes, protected activation or new authority is permitted.
