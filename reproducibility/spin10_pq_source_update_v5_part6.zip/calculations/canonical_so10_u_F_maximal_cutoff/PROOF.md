# Complete maximal F5 cancellation in the formal local reference family

UFM1-4B. Fixed original unshifted SMA/CSW/EDS,A0,constant u,intrinsic1,
external jets0 AFTER source/field differentiation,symbolic g10/xi/eta_H,
common hbar/(16pi^2),nonexceptional Euclidean LOCAL RELATIVE positive-heat
UV symbol. No new counterterm, normalization, physical benchmark or
scientific authority is adopted.

## Complete five-edge operator

Inherit UMH's actual-action support and grade theorem for

 C_n^u=(-1)^n STr[(G V)^n M_u
       +sum_j (G V)^j G H_u (G V)^(n-1-j) M0].

The complete original free M_f root and its differentiated H_u group
cancel by the reference-pairing identity. That cancellation does NOT
remove the non-reference-preserving M_u root. At maximal F order,
target=(u,nu,JLambda,C1,C2,x), with all external ghost labels distinct,
there are four120-permutation root families: M_u,M_x,M_C1,M_C2. All
nonlinear vertices consume another positive grade and belong at four
or fewer edges. Classical QG source2 is excluded at these grades by the
owning full-support theorem; quantum contact Euler terms are NOT erased.

Let Y=(B_long45,Lambda45),s328,C45,a45. X_n and X_x exchange Y/s;
X_JLambda maps C->Y and Y->a; X_C maps a->Y and Y->C; X_u preserves Y;
M_u maps Y->a; M_x maps C->s; M_C is sector diagonal. Complete path
enumeration leaves16,8,40,40 ordered words respectively,104 in total.
All480 are evaluated independently in unrooted graded-power checks.

Each numeric closed path has one scalar segment between N and R_x.
If an M_C scalar block lies on it, this contributes N S_h R_a or
N S_h^t R_a; otherwise it contributes N R_a. The compiler cuts the
numeric component trace at that segment, retaining the ORIGINAL
starting-sector supertrace sign and the literal exterior sign in order
eps,u,JL,C1,C2,nu,x. eps,JL,C1,C2 are odd. No cyclic supertrace rule or
commuting-operator shortcut is invoked. Opposite scalar orientations
and transpose classes are retained separately before using S_h^t=-S_h.

The exact color coefficients are generated in color.py from all closed
sector paths. Three arbitrary noncommuting fixtures verify equality
with the original480-word graded expression, including ghost exchange,
source orientation, exterior signs and separate nonzero root families.

## Actual block relations needed for the identity

The initial free-word test assumed only the free probe shape and beta
support. It left120/302 base words; these assumptions were insufficient.
It did not refute actual cancellation. The additional relations below
were subsequently recovered from the actual CLASSICAL action/GF data,
not selected from a quantum target or inferred from a zero witness.

Write P_H+P_B=1 and Omega=eta_H P_H+xi P_B. Both probes have

 H_u=[[-2P,Omega P],[-Omega P,Omega^2 P/2]],
 M_u[a,Y]=[-2iP,i Omega P],       P=P_H or P_B.

The source tensor beta_r has only (ghost H,auxiliary broken) entries:
beta_r:P_B->P_H. All334 nonzero actual entries obey this type.

For each external ghost h, let A_h be the actual vector tangent. Every
entry is exactly degree1 in g10: A_h=g10 T_h, with T_h^t=-T_h. Here T_h
is the coefficient polynomial in g10, including its value at g10=0.
There is no inverse-coupling insertion or counterterm. If h is unbroken,
T_h is block diagonal in H/broken; if broken, its H/H block is zero.

For unbroken h, the actual remaining matrices obey

 M_C,B=M_C,C=g10 T_h,
 M_C,Lambda=M_C,a=g10 P_B T_h P_B,
 J_B=-i g10 P_H T_h P_H,       J_Lambda=0.

For broken h they obey

 M_C,B=M_C,C=g10 T_h,
 M_C,Lambda=M_C,a=0,
 J_B=-i g10 T_h,              J_Lambda=i xi P_B T_h P_B.

These are exact relations in the existing reference, including the
apparently different g powers in J_Lambda. They are not altered to
improve quantum matching. Both stored data and separately reconstructed
GF/source data agree. Review checks every actual entry and zero in all45
ghost blocks, both free probe matrices, all source beta types and all45
scalar-generator antisymmetries. It does not rely on selected ratios or
the earlier r13 row as proof of these relations.

## Dimension-independent cancellation

Use a free noncommuting polynomial ring for arbitrary rectangular
beta:P_B->P_H and arbitrary skew T1,T2 respecting the stated ghost
types. H and broken are arbitrary vector-space dimensions. The2x2
matrix notation denotes TYPES, not1D numerical substitutions. Each
letter retains its order; transpose reverses words and normalizes a
declared skew letter with a minus sign. eta_H,xi,g10 are central exact
polynomial coefficients with nonnegative powers.

Substitution of the action relations into the COMPLETE104-path color
expression reduces all effective base,S1,S2 weights to the empty
polynomial for both probes and each pair H/H,H/B,B/H,B/B. All eight
cases and expanded root polynomials are preserved in
expanded_typed_proof.json.gz. Review checks148 nonzero rooted words for
rectangular type consistency and transpose involution. Twenty-seven
root/type/probe cases have nonzero effective polynomials before summing;
the theorem does not discard those contributions.

Since beta is an arbitrary rectangular matrix, the identity holds for
EVERY source r, including its zero rows. Since the weights vanish before
N,R contractions, it holds for EVERY scalar component and all allowed
scalar data. Antisymmetry extends the result from distinct ordered ghosts
to the usual h<k domain, with the equal-ghost component zero.

Changing longitudinal momentum sign is a similarity transformation with
T=diag(-1 on B_long,+1 elsewhere). G,V_n,V_x,V_J,V_C,H_u and all roots
at -q are T times their +q matrix times T: mixed B/L propagators and
each B/non-B derivative vertex change sign, diagonal B/B blocks do not.
T is even and T^2=1, so every original ordered supertrace is unchanged.
The inherited all-Lorentz/longitudinal support identifies this with the
full retained local symbol, not merely one sampled axis.

Consequently, in this declared formal local domain,

                C5_F[r,h,k,i]=0

for all45 source labels,990 ghost pairs and328 scalars, in both probes.
This is a14,612,400-position zero theorem per probe, not an extracted
table of every individual rooted contribution or independent experiment.

## Independent implementation checks and actual positive roots

Full graded powers at H-dimension2,broken3,scalar4 use unequal,
noncommuting rectangular blocks and retain all480 words. Ten cases
cover both probes, all ghost-type pairs and a second B/B seed. All four
root families agree with compact contractions. Omitted M_u,H_u groups,
reversed source orientation, commuting exterior coefficients and a
wrong C-ghost tangent sign each have sensitive cases. Per-case
insensitivity remains visible. These are algebra diagnostics, not
physical parameter choices.

Both scalar associations also compute the ENTIRE r13 row,324720
positions per probe, with all four family maps and zero complements.
Their individual nonzero counts are

| Probe | M_u | M_x | M_C1 | M_C2 | Total |
|---|---:|---:|---:|---:|---:|
| 0 | 2280 | 0 | 1040 | 1328 | 0 |
| 1 | 5136 | 6224 | 6440 | 6560 | 0 |

Selected initial scalar witnesses were all zero and hence did not test
these families sensitively. New positive-root cases selected from the
completed row agree with the original508-coordinate ordered powers for
both momentum signs. For example, at r13,ghosts(0,13),scalar206,probe0,
M_u=-i sqrt6 eta_H g10^5 xi/64 and M_C2 is its positive opposite. Probe1
has M_u=+i sqrt6 eta_H g10^5 xi/32 and M_x its negative opposite.
These nonzero contributions must remain in the calculation.

The full-domain claim follows from the typed identity plus exhaustive
action applicability checks; it is not extrapolated from this row.

## Scientific consequence and limits

UMH's actual positive-heat radial coefficient gives

 [log5]cutoff_F=C4_F-C5_F=C4_F.

The five-edge dependency is now resolved, with its required terms
included and cancelled. The nonlinear fourth-edge tensor remains to
be calculated, especially both-broken GF-aaCC/source-D and intrinsic
source/auxiliary branches. No old quantum remainder was read as an
operand or needed for this proof. No complete F log5 comparison has
been performed here. Other finite bases, common continuum trace/product/
contact limits, measure/QAP, E5/A5 and physical viability remain open.

Shared action,charts,reference,exact ring,source/free-symbol helpers,
compiler and AI authorship limit independence. This is internal analytic
and computational evidence, not an external scientist, proof-assistant
certificate, empirical confirmation or validation of shared premises.
