# UFM1-4: complete maximal F cutoff, with nonlinear frontier retained

Prospective at a9e628a0. Previous goal turn PROGRESS (complete T log5).
Clean main/no matching workers; state113,authority34/39,E5/A5 OPEN,
custodyexit2/seven unresolved unchanged. Current AGENTS governs.

Question: reduce the ENTIRE480-word F5 operator with correct odd JL,
distinct C1<C2 and eps; derive a usable color/tensor expression and
calculate its complete45x(45 choose2)x328 coefficient domain, both probes.
Selected F5=0 cannot answer this whole-domain question. The full log5
coefficient still requires C4_F-C5_F; do not promote F5 alone to F log5.

UFM1: complete sector-walk enumeration of four120-permutation root
classes M_u,M_x,M_C1,M_C2. X_JL exchanges Y and ghosts. Derive compact
block products retaining actual exterior order eps,u,JL,C1,C2,n,x.
Check against480 full graded words on noncommuting fixtures and distinct
ghost matrices. Include sensitive ghost-exchange, commuting-exterior,
source-orientation and omitted-family controls where mathematically
nonzero; record insensitive controls honestly. No integer fixture is a
physical parameter point.

UFM2: actual model calibrations by original508-coordinate matrices,
including both-broken ghosts. Recover beta from action, N/J from GF
Euler columns, scalar generators from actual flows and full QG free
u symbols before external restriction. Two scalar contraction routes
must agree, with zero complements and antisymmetric ghost ordering.
Use original all-Lorentz support and positive-heat proofs as inherited,
not a fresh full trace/contact theorem. Native quantum-target blindness.

UFM3: compute the full F5 tensor if compact contraction is competent
within resource limits. Preserve separate rooted families and all
nonzero outputs, never silently truncate a tensor. A structural zero
requires a full-domain argument, not repeated selected witnesses.
If a tested reduction is insufficient, preserve that finding and derive
the next reduction rather than fitting the result. Any new continuation
freezes its own sources before computation.

UFM4: compare complete independent outputs before dependent checks or
late quantum interpretation. F log5 may be assessed only if C4 is also
legitimately constructed. Classify actual nonlinear C4 dependencies;
both-broken GF-aaCC/source-D,M_u,intrinsic,M_CC stay included unless a
whole-support proof excludes them in a stated subfamily. Classical
source2 cutoff exclusion does not erase quantum contact Euler terms.

Fixed original unshifted SMA/CSW/EDS,A0,constant u,intrinsic1,external
jets0 AFTER full differentiation,symbolic parameters,common hbar/(16pi^2),
nonexceptional Euclidean LOCAL RELATIVE formal positive-heat symbol.
No fitted unknown, changed regulator/subtraction/benchmark, protected
stage, authority promotion, flavor/HB1/C5 activation, agent organization,
branch/worktree, remote action, publication or outreach. b0,kappa,chi4
and IR freedoms remain distinct/unfixed. Full quantum/physical obligations
remain unqualified. Shared action,charts,reference,ring,helpers,software
and AI author limit independence.

Native300s/review180s after imports,8GiB sampled private,350MiB launch
available-pagefile floor,32MiB packet. Freeze inputs,source copies and
preparations before execution; owned-child captures,complete failures
and unfinished outputs retained. Observe actual usage; exhaustion is
incomplete. Standard E4 audit once before local commit, custody2 not PASS.
