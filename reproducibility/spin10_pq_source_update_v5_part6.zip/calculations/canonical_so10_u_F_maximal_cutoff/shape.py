from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,time,threading,os
from model import *
O=Path(__file__).resolve().parent;tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,h in json.loads((O/'shape_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==h,path
d,p=make('primary')
encoded=lambda M:[[i,j,str(v)] for (i,j),v in sorted(M.items())]
free=[]
for probe,(H,UB,UL) in enumerate(p['u']):
    blocks={}
    for row,rr in [('B',0),('L',45)]:
        for col,cc in [('B',0),('L',45)]:blocks[row+col]={(i-rr,j-cc):v for (i,j),v in H.items() if rr<=i<rr+45 and cc<=j<cc+45}
    free.append({'probe':probe,'H':{k:encoded(v) for k,v in blocks.items()},'UB':encoded(UB),'UL':encoded(UL)})
beta_types=Counter();representative={}
for r,M in enumerate(p['beta']):
    for (c,a),v in M.items():
        key=','.join('H' if i<12 else 'broken' for i in [r,c,a]);beta_types[key]+=1
        representative.setdefault(key,[r,c,a,str(v)])
mc_types=[]
for h,mc in enumerate(p['MC']):
    blocks={row+col:sum(rr<=i<rr+45 and cc<=j<cc+45 for i,j in mc['Y']) for row,rr in [('B',0),('L',45)] for col,cc in [('B',0),('L',45)]}
    mc_types.append({'h':h,'Y':blocks,'C':len(mc['C']),'a':len(mc['a']),'JB':len(p['J'][h][0]),'JL':len(p['J'][h][1])})
out={'schema':'UFM_CLASSICAL_FREE_BLOCK_AUDIT','free':free,'beta_type_counts':dict(beta_types),'beta_type_representatives':representative,'ghost_block_support':mc_types,'quantum_remainder_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'shape_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
