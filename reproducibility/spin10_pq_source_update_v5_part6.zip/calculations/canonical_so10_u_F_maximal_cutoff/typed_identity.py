from noncommuting_v3 import *
from graded import LETTERS
O=Path(__file__).resolve().parent
def skew_transpose(self):
    out={}
    for word,value in self.terms.items():
        new=[]
        for name,at in word[::-1]:
            at=1-at
            if name.endswith('_skew'):
                if at:value=-value
                at=0
            new.append((name,at))
        key=tuple(new);out[key]=out.get(key,ZERO)+value
    return NC(out)
NC.T=skew_transpose
def Tmat(label,kind):
    if kind=='H':return {(0,0):var(label+'HH_skew'),(1,1):var(label+'BB_skew')}
    HB=var(label+'HB')
    return {(0,1):HB,(1,0):-HB.T(),(1,1):var(label+'BB_skew')}
def state(probe,hkind,kkind):
    Om={(0,0):scalar(co('eta_H')),(1,1):scalar(co('xi'))};P={(probe,probe):scalar(constant(1))}
    beta={(0,1):var('beta')};H={}
    embed(H,scale(P,constant(-2)),0,0);embed(H,multiply(Om,P),0,2);embed(H,scale(multiply(Om,P),constant(-1)),2,0);embed(H,scale(multiply(multiply(Om,Om),P),constant(Fraction(1,2))),2,2)
    UB=scale(P,-2*I);UL=scale(multiply(Om,P),I);JS=[];MC=[]
    for name,kind in [('T1',hkind),('T2',kkind)]:
        T=Tmat(name,kind);A=scale(T,co('g10'));BB={(1,1):T[1,1]}
        L=scale(BB,co('g10')) if kind=='H' else {};Y={};embed(Y,A,0,0);embed(Y,L,2,2)
        MC.append({'Y':Y,'C':A,'a':L})
        JB=scale({(0,0):T[0,0]} if kind=='H' else T,-I*co('g10'))
        JL={} if kind=='H' else scale(BB,I*co('xi'))
        JS.append((JB,JL))
    return Om,beta,JS,UB,UL,H,MC
def evaluate(probe,hkind,kkind):
    Om,beta,JS,UB,UL,H,MC=state(probe,hkind,kkind)
    import ast,builtins
    tree=ast.parse((O/'color.py').read_bytes());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['blocks','weights']]
    ns=dict(globals());ns['constant']=lambda n:scalar(constant(n));ns['I']=scalar(I);ns['times']=lambda a,b:a*b;ns['templates']=templates
    required=set()
    for node in nodes:
        assigned={a.arg for a in node.args.args}|{n.id for n in ast.walk(node) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Store)}
        required|={n.id for n in ast.walk(node) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Load)}-assigned
    required-={n.name for n in nodes}
    assert all(name in ns or hasattr(builtins,name) for name in required)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'UFM_TYPED_FREE_WORD_COMPILER','exec'),ns)
    return ns['weights'](Om,beta,JS[0],JS[1],UB,UL,H,MC[0],MC[1],2)
if __name__=='__main__':
    tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
    for path,h in json.loads((O/'typed_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==h,path
    results=[]
    for probe in range(2):
        for hkind in ['H','B']:
            for kkind in ['H','B']:
                W=evaluate(probe,hkind,kkind);total={kind:plus(*(part[kind] for part in W.values())) for kind in KINDS}
                eff={'base':total['base'],'S1':plus(total['S1'],scale(total['ST1'],constant(-1))),'S2':plus(total['S2'],scale(total['ST2'],constant(-1)))}
                roots={root:{kind:sum(len(v.terms) for v in M.values()) for kind,M in part.items()} for root,part in W.items()}
                row={'probe':probe,'ghost_types':[hkind,kkind],'root_word_counts':roots,'total_effective_weights':{kind:encode(M) for kind,M in eff.items()},'total_word_counts':{kind:sum(len(v.terms) for v in M.values()) for kind,M in eff.items()},'identity_zero':not any(eff.values())}
                results.append(row);print('STAGE typed '+json.dumps({k:v for k,v in row.items() if k!='total_effective_weights'},sort_keys=True),flush=True)
    out={'schema':'UFM3E_TYPED_NONCOMMUTING_F5_IDENTITY','results':results,'all_zero':all(z['identity_zero'] for z in results),'actual_model_audit_and_finite_confirmation_still_required':True,'quantum_target_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
    with (O/'typed_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
    print('RESULT '+json.dumps({k:v for k,v in out.items() if k!='results'},sort_keys=True),flush=True);timer.cancel()
