from pathlib import Path
from hashlib import sha256
import ast,gzip,json,subprocess
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-F-maximal-cutoff-v1-2026-10-26')
H=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
base=read(O/'inputs.json')['base_HEAD']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==base
assert subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()=='main'
subprocess.run(['git','diff','--quiet','HEAD'],cwd=R,check=True)
tree=subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);assert tree==(C/'old_git_tree.txt').read_bytes()
assert H(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
bindings={}
for file in sorted(O.glob('*preparation*.json')):
    for path,h in read(file)['input_sha256'].items():
        assert H(Path(path))==h,(file.name,path)
        if path in bindings:assert bindings[path]==h
        bindings[path]=h
for file in O.glob('*.source.txt'):assert (O/file.name.removesuffix('.source.txt')).read_bytes()==file.read_bytes(),file
for file in O.glob('*.py'):ast.parse(file.read_bytes())
completed=['fixtures_capture.json','calibration_capture.json','survey_capture.json','primary_row_capture.json','replay_row_capture.json','shape_capture.json','ghost_shape_capture.json','symbolic_capture_v3.json','typed_capture.json','finite_capture.json','review_capture.json']
maxmem=0
for file in completed:
    z=read(O/file)
    assert z['exit_code']==0 and z['calculation_completed'] and z['execution_state']=='COMPLETED' and z['post_run_observations_qualified']
    assert z['launch']['creation_after_observation'] and z['launch']['memory']['available_pagefile']>=350*1024**2
    for sample in z['all_resource_samples']:
        assert sample['private_bytes']<8*1024**3;maxmem=max(maxmem,sample['private_bytes'])
for file,helper in [('symbolic_capture.json','times'),('symbolic_capture_v2.json','LETTERS')]:
    z=read(O/file);assert z['exit_code']==1 and not z['calculation_completed'] and z['execution_state']=='FAILED'
    assert 'NameError' in z['stdout_and_stderr'] and helper in z['stdout_and_stderr']
for file in ['symbolic_controller_failure.json','symbolic_controller_failure_v2.json']:assert read(O/file)['failure_relabelled_PASS'] is False
for file in ['fixtures_result.json','survey_result.json','shape_result.json','ghost_shape_result.json','symbolic_result_v3.json','typed_result.json','finite_result.json']:assert read(O/file)['elapsed_after_imports']<300
for file in ['calibration_result.json.gz','primary_row13.json.gz','replay_row13.json.gz']:assert load(O/file)['elapsed_after_imports']<300
assert load(O/'primary_row13.json.gz')['results']==load(O/'replay_row13.json.gz')['results']
initial=read(O/'symbolic_result_v3.json');assert [z['total_word_counts']['base'] for z in initial['results']]==[120,302] and not any(z['stated_assumptions_suffice_for_zero'] for z in initial['results'])
typed=read(O/'typed_result.json');assert typed['all_zero'] and len(typed['results'])==8
expanded=load(O/'expanded_typed_proof.json.gz');assert len(expanded)==8 and all(not any(z['effective_residual'].values()) for z in expanded)
v=read(O/'review_result.json');assert v['elapsed_after_imports']<180 and v['entire_F5_zero_by_dimension_independent_identity']
assert v['coefficient_domain_per_probe']==14612400 and v['probes']==2 and len(v['all45_ghost_block_audits'])==45 and all(z['all_assumptions_verified'] for z in v['all45_ghost_block_audits'])
assert v['source_beta_entries_checked']==334 and v['noncommuting_word_type_checks']==148 and v['symbolic_cases']==8 and v['finite_cases']==10
assert not v['full_F_log5_C4_or_QAP_claim'] and not v['known_quantum_remainder_operand']
finite=read(O/'finite_result.json');assert all(z['total']=='0' for z in finite['results'])
for name in finite['results'][0]['controls']:assert any(z['controls'][name]['sensitive'] for z in finite['results'])
e=read(O/'e4_capture.json');events=[json.loads(line) for line in e['stdout'].splitlines() if line.startswith('{')];exits=[z['exit_code'] for z in events if z.get('event')=='step_finished']
assert e['exit_code']==0 and exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED'
files={str(p.relative_to(R)).replace('\\','/'):H(p) for p in O.iterdir() if p.is_file()}
handoff=R/'docs/RESEARCH_EXECUTION_HANDOFF_V649.md';files[str(handoff.relative_to(R)).replace('\\','/')]=H(handoff)
size=sum(p.stat().st_size for p in O.iterdir() if p.is_file());assert size<32*1024**2
out={'schema':'UFM_FINAL_REVIEW_VALIDATION_V1','base_HEAD':base,
     'evidence_validation':'PASS_COMPLETE_FORMAL_LOCAL_F5_ZERO_BY_TYPED_IDENTITY_WITH_EXHAUSTIVE_ACTION_APPLICABILITY',
     'scientific_acceptance':'NOT_PERFORMED','authority':'34/39; E5/A5 OPEN','custody':'EXIT_2_SEVEN_UNRESOLVED','state_unchanged':True,
     'scope':'Entire maximal five-edge F coefficient zero, both probes; full F log5 still requires nonlinear C4.',
     'coefficient_domain_per_probe':14612400,'full_F_log5_complete':False,'full_investigation_complete':False,
     'authenticated_input_and_source_bindings':len(bindings),'preserved_old_mode_blob_entries':len(tree.splitlines()),
     'successful_captures':completed,'failed_symbolic_adapters_preserved':['symbolic_capture.json (times)','symbolic_capture_v2.json (LETTERS)'],
     'initial_weaker_abstract_hypothesis':'INSUFFICIENT; residual120/302 base words preserved, not actual-model refutation',
     'maximum_successful_private_sample_bytes':maxmem,'sample_is_continuous_peak':False,'packet_bytes_before_seal':size,
     'e4_step_exits':exits,'limitations':['shared action/reference/charts/ring/free-symbol helper/compiler/software/AI author','full-domain zero from noncommuting block identity, not component extraction of every individual family','nonlinear C4 and other finite bases not calculated','no full common trace/product/contact limit, measure/QAP or physical viability claim'],
     'new_files_sha256':files}
dump(O/'final_review_validation_receipt.json',out);dump(C/'final_review_validation_receipt.json',out)
print(json.dumps({k:v for k,v in out.items() if k not in ['new_files_sha256','limitations','successful_captures']},sort_keys=True))
