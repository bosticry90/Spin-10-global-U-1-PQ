from pathlib import Path
from hashlib import sha256
import json,gzip,time,threading,os
from model import *
O=Path(__file__).resolve().parent;tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,hsh in json.loads((O/'survey_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==hsh,path
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        q=Path(os.fsdecode(args[0]))
        if q.parent.name in ['canonical_so10_u_pair_contact_model','canonical_so10_intrinsic_auxiliary_ghost_source']:raise PermissionError('UFM_QUANTUM_TARGET_DENIED')
import sys
sys.addaudithook(guard)
d,p=make('primary');old=json.loads(gzip.decompress((O/'calibration_result.json.gz').read_bytes()));primary_cache={};replay_cache={};results=[]
for entry in old['actual_calibrations']:
    r,h,k,probe=(entry[key] for key in ['r','h','k','probe'])
    H,UB,UL=p['u'][probe];W=weights(p['Om'],p['beta'][r],p['J'][h],p['J'][k],UB,UL,H,p['MC'][h],p['MC'][k],45)
    full={}
    for root,part in W.items():
        a=scalar_image(part,p,h,k,'primary',primary_cache);b=scalar_image(part,p,h,k,'replay',replay_cache);assert a==b
        full[root]=a
    total={}
    for tab in full.values():
        for i,v in tab.items():total[i]=total.get(i,ZERO)+v
    total=clean(total)
    out={'r':r,'h':h,'k':k,'probe':probe,'domain':328,'roots':{root:[[i,str(v)] for i,v in sorted(tab.items())] for root,tab in full.items()},'total':[[i,str(v)] for i,v in sorted(total.items())]}
    results.append(out)
    print('STAGE scalar_image '+str((r,h,k,probe))+' '+str({root:len(tab) for root,tab in full.items()})+' total '+str(len(total)),flush=True)
out={'schema':'UFM3A_COMPLETE_SELECTED_SCALAR_IMAGES','results':results,'primary_reassociated_scalar_images_equal':True,'whole_F5_tensor_claim':False,'quantum_target_operand':False,'classical_support':{'N':len(p['N']),'R':[len(z) for z in p['R']],'beta':[len(z) for z in p['beta']],'MC':[{k:len(v) for k,v in z.items()} for z in p['MC']]},'elapsed_after_imports':time.perf_counter()-tick}
with (O/'survey_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({k:v for k,v in out.items() if k not in ['results','classical_support']},sort_keys=True),flush=True);timer.cancel()
