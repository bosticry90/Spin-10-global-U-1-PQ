from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from fractions import Fraction
import json,gzip,sys,time,threading,os
from model import *
O=Path(__file__).resolve().parent;role=sys.argv[1];r=int(sys.argv[2]);assert role in ['primary','replay'] and r==13
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,hsh in json.loads((O/'row_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==hsh,path
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        q=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
        if q.parent.resolve()==O and q.name.startswith(peer+'_row'):raise PermissionError('UFM_PEER_DENIED')
        if q.parent.name in ['canonical_so10_u_pair_contact_model','canonical_so10_intrinsic_auxiliary_ghost_source']:raise PermissionError('UFM_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard)
d,p=make(role);cache={};results=[]
for probe in range(2):
    H,UB,UL=p['u'][probe];full={root:{} for root in LETTERS};module_stats={'pairs':0,'summed_effective_all_zero':0,'weighted_N_zero':0}
    for h in range(45):
        for k in range(h+1,45):
            W=weights(p['Om'],p['beta'][r],p['J'][h],p['J'][k],UB,UL,H,p['MC'][h],p['MC'][k],45)
            effs={root:effective(part) for root,part in W.items()}
            totalW={kind:plus(*(part[kind] for part in effs.values())) for kind in ['base','S1','S2']}
            module_stats['pairs']+=1;module_stats['summed_effective_all_zero']+=int(not any(totalW.values()))
            WN={}
            for kind,M in totalW.items():
                z=multiply(transpose(M),p['N'])
                if kind!='base':z=multiply(z,p['R'][h if kind=='S1' else k])
                WN=plus(WN,z)
            module_stats['weighted_N_zero']+=int(not WN)
            for root,part in W.items():
                vec=scalar_image(part,p,h,k,role,cache)
                for ix,v in vec.items():full[root][h,k,ix]=v
        if h%5==4:print('STAGE row '+role+' '+str(probe)+' h '+str(h)+' seconds '+str(round(time.perf_counter()-tick,2)),flush=True)
    total={}
    for table in full.values():
        for key,v in table.items():total[key]=total.get(key,ZERO)+v
    total=clean(total)
    encode=lambda M:[[h,k,ix,[[list(key),v.numerator,v.denominator] for key,v in c.terms]] for (h,k,ix),c in sorted(M.items())]
    results.append({'probe':probe,'source':r,'domain_positions':990*328,'nonzero_counts':{**{root:len(tab) for root,tab in full.items()},'total':len(total)},'root_families':{root:encode(tab) for root,tab in full.items()},'total':encode(total),'module_diagnostic':module_stats})
    print('STAGE row_counts '+json.dumps(results[-1]['nonzero_counts'],sort_keys=True)+' module '+json.dumps(module_stats,sort_keys=True),flush=True)
out={'schema':'UFM3B_COMPLETE_F5_SOURCE_ROW','role':role,'source':r,'results':results,'full45_source_tensor_claim':False,'quantum_target_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/(role+'_row13.json.gz')).open('xb') as f:f.write(gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
print('RESULT '+json.dumps({k:v for k,v in out.items() if k!='results'},sort_keys=True),flush=True);timer.cancel()
