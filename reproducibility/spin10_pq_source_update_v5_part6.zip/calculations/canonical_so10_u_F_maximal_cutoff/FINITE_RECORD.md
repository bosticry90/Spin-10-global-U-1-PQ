# UFM4A independent typed finite confirmation

The complete typed noncommuting color polynomial now vanishes for both
probes and all four ghost-type pairs. Before qualification, independently
evaluate original graded matrix powers at color H-dimension2/broken3,
scalar4 (unequal noncommuting rectangular blocks), using deterministic
generic skew T_h, arbitrary beta:H<-broken,N,R_x and skew scalar tangents.
Use actual symbolic g10/eta_H/xi. Test all eight probe/type cases with
seed2, plus both probes B/B with seed5. These are algebra diagnostics,
not physical parameter points. No quantum target operand.

Full powers of the sum of six tagged operators include all480 ordered
words and their exterior coefficients without cyclic trace rearrangement.
Compare all four root families with compact color contractions; totals
must vanish under the lemma. Require at least one sensitive case for
omitted M_u, omitted H_u insertion groups, reversed JL source orientation,
commuting exterior coefficients and wrong C-ghost tangent sign. Preserve
per-case insensitive controls. Retain full results and limits300s after
imports,8GiB/350MiB/32MiB; incomplete is not PASS. No authority change.
