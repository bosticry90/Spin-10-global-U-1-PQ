from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-T-cutoff-tensor-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings={str(R/p):h for p,h in json.loads((O/'inputs.json').read_bytes())['input_sha256'].items()}
    for p,h in bindings.items():assert H(Path(p))==h,p
    for name in ['.gitattributes','inputs.json','RECORD.md','algebra.py','fixtures.py','run_fixtures.py']:
        p=O/name
        if p.suffix=='.py':ast.parse(p.read_bytes())
        with (O/(name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
        bindings[str(p)]=H(p)
    dump(O/'fixtures_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED','question':'UTC1 three-product block/color reduction; all 72 words'})
    result=capture([sys.executable,'-B',str(O/'fixtures.py')])
    dump(O/'fixtures_capture.json',result);dump(C/'fixtures_full_capture.json',result)
    assert result['exit_code']==0 and result['calculation_completed'] and result['post_run_observations_qualified'],result
    assert json.loads((O/'fixtures_result.json').read_bytes())['elapsed_after_imports']<300
    assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<32*1024**2
    print('COMPLETED UTC1',flush=True)
except BaseException:
    dump(O/'fixtures_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False})
    raise
