from pathlib import Path
from functools import lru_cache
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'canonical_so10_intrinsic_full_source_descent'))
from coefficient_ring import Coeff,ZERO,I,constant
@lru_cache(200000)
def times(a,b):return a*b
def clean(M):return {ij:v for ij,v in M.items() if v}
def plus(*matrices):
    out={}
    for M in matrices:
        for ij,v in M.items():out[ij]=out.get(ij,ZERO)+v
    return clean(out)
def scale(M,c):return {ij:times(v,c) for ij,v in M.items() if times(v,c)}
def transpose(M):return {(j,i):v for (i,j),v in M.items()}
def multiply(A,B):
    rows={};out={}
    for (i,j),v in B.items():rows.setdefault(i,[]).append((j,v))
    for (i,k),v in A.items():
        for j,w in rows.get(k,[]):out[i,j]=out.get((i,j),ZERO)+times(v,w)
    return clean(out)
def identity(n):return {(i,i):constant(1) for i in range(n)}
def trace(M):return sum((v for (i,j),v in M.items() if i==j),ZERO)
def color_weights(Om,JB,JL,K,UB,UL,H,n,association='left'):
    # All entries are even coefficients; the exterior/supertrace signs have
    # been explicitly extracted and are tested against the graded products.
    G={}
    for (i,j),v in Om.items():G[i,j]=v
    for i in range(n):G[i,n+i]=constant(-1);G[n+i,i]=constant(1)
    D=multiply(multiply(G,H),G)
    DBL={(i,j-n):v for (i,j),v in D.items() if i<n and j>=n}
    DLL={(i-n,j-n):v for (i,j),v in D.items() if i>=n and j>=n}
    L=plus(multiply(Om,transpose(JB)),transpose(JL))
    W=plus(multiply(UB,Om),UL)
    Z=plus(multiply(JB,DBL),multiply(JL,DLL))
    if association=='left':
        A=multiply(multiply(L,K),UB);B=multiply(multiply(transpose(JB),K),W)
    else:
        A=multiply(L,multiply(K,UB));B=multiply(transpose(JB),multiply(K,W))
    C=multiply(transpose(K),Z)
    return {'direct_1':scale(transpose(A),I),'direct_2':scale(B,I),'Hu_Mx':transpose(C)}
