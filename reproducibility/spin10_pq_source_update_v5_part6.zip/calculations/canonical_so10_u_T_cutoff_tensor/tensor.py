from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,gzip,sys,time,threading,os
from actual import *
O=Path(__file__).resolve().parent;role=sys.argv[1];assert role in ['primary','replay']
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,h in json.loads((O/'tensor_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==h,path
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
        if p.parent.resolve()==O and (p.name.startswith(peer+'_') or p.name.startswith('review_')):raise PermissionError('UTC_NATIVE_PEER_DENIED')
        if p.parent.name in ['canonical_so10_u_pair_contact_model','canonical_so10_intrinsic_auxiliary_ghost_source']:raise PermissionError('UTC_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard)
denied=0
for path in [O/(('replay' if role=='primary' else 'primary')+'_tensor.json.gz'),R/'calculations/canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz']:
    try:path.read_bytes()
    except PermissionError:denied+=1
assert denied==2
d=load(role);p=primitives(d,role)
names=['direct_1','direct_2','Hu_Mx'];results=[]
if role=='primary':
    NR=[multiply(p['N'],mat) for mat in p['R']]
    nrrows=[]
    for mat in NR:
        rows=defaultdict(list)
        for (b,ix),v in mat.items():rows[b].append((ix,v))
        nrrows.append(rows)
else:
    nrows=defaultdict(list);rrows=[]
    for (b,j),v in p['N'].items():nrows[b].append((j,v))
    for mat in p['R']:
        rows=defaultdict(list)
        for (j,ix),v in mat.items():rows[j].append((ix,v))
        rrows.append(rows)
for probe in range(2):
    H,UB,UL=p['u'][probe];families={name:{} for name in names}
    for r in range(45):
        for h in range(45):
            JB,JL=p['J'][h]
            weights=color_weights(p['Om'],JB,JL,p['K'][r],UB,UL,H,45,'left' if role=='primary' else 'right')
            for name,W in weights.items():
                vec={}
                if role=='primary':
                    for (b,a),v in W.items():
                        for ix,w in nrrows[a].get(b,[]):vec[ix]=vec.get(ix,ZERO)+times(v,w)
                else:
                    # Independently associate color contraction into N BEFORE
                    # the scalar generator; never read precontracted N R.
                    wn={}
                    for (b,a),v in W.items():
                        for j,w in nrows.get(b,[]):wn[a,j]=wn.get((a,j),ZERO)+times(v,w)
                    for (a,j),v in wn.items():
                        if not v:continue
                        for ix,w in rrows[a].get(j,[]):vec[ix]=vec.get(ix,ZERO)+times(v,w)
                for ix,v in vec.items():
                    if v:families[name][r,h,ix]=v
        if r%9==8:print('STAGE tensor '+role+' '+str(probe)+' source '+str(r),flush=True)
    total={}
    for mat in families.values():
        for key,v in mat.items():total[key]=total.get(key,ZERO)+v
    total={k:v for k,v in total.items() if v}
    encode=lambda mat:[[r,h,ix,[[list(k),q.numerator,q.denominator] for k,q in v.terms]] for (r,h,ix),v in sorted(mat.items())]
    counts={name:len(mat) for name,mat in families.items()}
    results.append({'probe':probe,'domain_positions':45*45*328,'total':encode(total),'families':{name:encode(mat) for name,mat in families.items()},'nonzero_counts':dict(counts,total=len(total)),'zero_complement':45*45*328-len(total)})
    print('STAGE counts '+json.dumps(results[-1]['nonzero_counts'],sort_keys=True),flush=True)
out={'schema':'UTC3_COMPLETE_DIRECT_T_LOG5','role':role,'results':results,'algorithm_guard_denials':denied,'quantum_target_operand':False,'domain':'T log5 cutoff C4; all 45x45x328 coefficients and implicit zeros','elapsed_after_imports':time.perf_counter()-tick}
with (O/(role+'_tensor.json.gz')).open('xb') as f:f.write(gzip.compress((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
print('RESULT '+json.dumps({k:v for k,v in out.items() if k!='results'},sort_keys=True),flush=True);timer.cancel()
