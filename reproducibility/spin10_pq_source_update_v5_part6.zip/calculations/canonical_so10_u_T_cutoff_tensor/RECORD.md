# UTC1-4: complete T log5 regulator tensor

Prospective atd2c65280; previous goal turn PROGRESS, clean main/no matching
workers. Use existing evidence to test the proposed block reduction before
full computation. The full45x45x328 T tensor is the question, not another
selected successful example. No scientific-authority or scheme change.

UTC1: enumerate every sector walk in72 ordered T4 words. Compare full
graded traces with the proposed three products using noncommuting finite
fixtures. Derive/verify the color expression, including the M_x/H_u
family. Controls must distinguish omitted reverse n/x order, omitted
M_x, incorrect exterior signs, source transpose and H_u ordering where
sensitive. Diagnostic integer matrices are not physical parameter choices.

UTC2: reconstruct actual free H_u/M_u from QG. Check the reference's
45-color block form. Recover native B/source tensors and J0/N0 from the
actual source/GF action for the second route. Include broken external
ghosts where J0's Lambda column can activate a previously untested family.
Compare compact products to original full508-coordinate ordered traces
before tensor interpretation. Use all symbolic parameters,not fitted values.

UTC3: primary precontracts N R_a and then contracts color weights; replay
pushes color weights into N first and then applies R_a,with separately
recovered classical source/GF data and differently associated color
products. Produce every coefficient and the complete zero complement in
45x45x328 for BOTH probes. Preserve separate direct and H_u/M_x families.
Native datasets contain no old full T remainder. Only later review may
read it after independent outputs agree. No zero or coefficient is fitted.

UTC4: compare complete tensors/families,source phases,ordered signs and
coverage. Late comparison uses conversion PLUS cutoff in the owning
LOCAL RELATIVE convention. A mismatch is preserved; no sign is repaired
solely to make it cancel. Explicitly retain both-broken-ghost F sectors,
other finite bases,full common trace/product/contact limits,measure/QAP
and physical viability as separate obligations. A full T log5 identity
does not qualify E5/A5 or a new physical renormalization prescription.

Fixed original unshifted SMA/CSW/EDS,A0,constant u,intrinsic1,external jets0
after differentiation; common hbar/(16pi^2),nonexceptional Euclidean LOCAL
RELATIVE formal UV symbol. Positive-heat radial and longitudinal support
theorems are inherited from UMH,not new full trace-limit proofs. Native300s,
review180s afterimports,8GiB sampled private,350MiB launchfloor,32MiB packet.
Freeze sources and inputs before execution. Preserve failed/unfinished
work exactly. No agents,branch/worktree,remote action,publication,protected
activation or foundational/benchmark/normalization adoption. Shared action,
reference,charts,exact ring,software and AI author limit independence.
