from pathlib import Path
from hashlib import sha256
from itertools import permutations
import json,sys,time,threading,os
from actual import *
O=Path(__file__).resolve().parent;tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for path,h in json.loads((O/'calibration_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==h,path
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        p=Path(os.fsdecode(args[0]))
        if p.parent.name in ['canonical_so10_u_pair_contact_model','canonical_so10_intrinsic_auxiliary_ghost_source']:raise PermissionError('UTC_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard)
d=load('primary');p=primitives(d,'primary');ns=original_matrix_namespace(d,p);results=[]
# Frozen selected labels include unbroken/broken ghost cases and distinct
# scalar components. No quantum target selects these calibrations.
for r,h,ix in [(13,0,137),(13,12,137),(13,13,136),(20,25,70),(44,44,327)]:
    for probe in range(2):
        H,UB,UL=p['u'][probe];JB,JL=p['J'][h]
        weights=color_weights(p['Om'],JB,JL,p['K'][r],UB,UL,H,45)
        NR={a:multiply(p['N'],{(j,0):v for (j,i),v in mat.items() if i==ix}) for a,mat in enumerate(p['R'])}
        inner=lambda W:sum((times(v,NR[a].get((b,0),ZERO)) for (b,a),v in W.items()),ZERO)
        compact={name:inner(W) for name,W in weights.items()};orient=[]
        for q in [1,-1]:
            ns.update(R_LABEL=r,C_LABEL=h,X_LABEL=ix)
            G,V,groups=ns['matrices']('T',probe,q);X=ns['mm'](G,V)
            power={(i,i):{0:constant(1)} for i in range(508)}
            for n in range(4):power=ns['mm'](power,X)
            direct=ns['tr'](ns['mm'](power,groups['Mu_free']));hx=ns['tr'](ns['mm'](power,groups['Mx']))
            others={name:ns['tr'](ns['mm'](power,M)) for name,M in groups.items() if name not in ['Mu_free','Mx']}
            assert not any(others.values()),{k:str(v) for k,v in others.items()}
            assert direct==compact['direct_1']+compact['direct_2'] and hx==compact['Hu_Mx'],(r,h,ix,probe,q,str(direct),str(hx),{k:str(v) for k,v in compact.items()})
            orient.append({'direct':str(direct),'Hu_Mx':str(hx)})
        assert orient[0]==orient[1]
        results.append({'r':r,'h':h,'ix':ix,'probe':probe,'compact_families':{k:str(v) for k,v in compact.items()},'full_508_orientations':orient})
        print('STAGE calibration '+str((r,h,ix,probe)),flush=True)
out={'schema':'UTC2_ACTUAL_508_CALIBRATIONS','results':results,'quantum_target_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'calibration_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
