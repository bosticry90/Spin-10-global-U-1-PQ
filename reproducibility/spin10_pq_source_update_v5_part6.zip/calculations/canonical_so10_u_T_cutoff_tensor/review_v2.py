from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import ast,json,gzip,sys,time,threading,os
from actual import *
O=Path(__file__).resolve().parent;tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes())
loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()))
for path,h in read(O/'review_preparation_v2.json')['input_sha256'].items():assert sha256(Path(path).read_bytes()).hexdigest()==h,path
p=loadz(O/'primary_tensor.json.gz');q=loadz(O/'replay_tensor.json.gz')
assert p['results']==q['results'] and p['algorithm_guard_denials']==q['algorithm_guard_denials']==2
assert not p['quantum_target_operand'] and not q['quantum_target_operand']
def decode_tensor(rows):
    out={}
    for r,h,ix,terms in rows:
        assert 0<=r<45 and 0<=h<45 and 0<=ix<328 and (r,h,ix) not in out
        assert terms and all(len(k)==4 and all(isinstance(t,int) and t>=0 for t in k[:3]) and 0<=k[3]<32 and isinstance(n,int) and isinstance(d,int) and d>0 for k,n,d in terms)
        out[r,h,ix]=Coeff([(tuple(k),Fraction(n,d)) for k,n,d in terms]);assert out[r,h,ix]
    return out
totals=[];families=[];coverage=[]
for entry in p['results']:
    total=decode_tensor(entry['total']);fam={k:decode_tensor(v) for k,v in entry['families'].items()}
    assert set(fam)=={'direct_1','direct_2','Hu_Mx'}
    summed={}
    for tab in fam.values():
        for k,v in tab.items():summed[k]=summed.get(k,ZERO)+v
    assert {k:v for k,v in summed.items() if v}==total
    # Sparse maps define every omitted coefficient to be zero. Traverse the
    # entire domain explicitly; no sampling or unexplained missing entries.
    nonzero=zero=0
    for r in range(45):
        for h in range(45):
            for ix in range(328):
                v=total.get((r,h,ix),ZERO)
                if v:nonzero+=1
                else:zero+=1
    assert nonzero==entry['nonzero_counts']['total'] and zero==entry['zero_complement'] and zero+nonzero==664200
    coverage.append({'probe':entry['probe'],'positions':664200,'nonzero':nonzero,'zero':zero,'family_nonzeros':{k:len(v) for k,v in fam.items()}})
    totals.append(total);families.append(fam)
print('STAGE complete_tensor_agreement '+json.dumps(coverage,sort_keys=True),flush=True)

# Further ordering control on the frozen noncommuting setup. Extract only
# setup statements before X is built; no fixture output is overwritten.
tree=ast.parse((O/'fixtures.py').read_bytes());loop=next(n for n in tree.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='seed')
setup=[]
for node in loop.body:
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='X' for t in node.targets):break
    setup.append(node)
ns=dict(globals());ns['seed']=2
embed_node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='embed')
exec(compile(ast.Module(body=[embed_node],type_ignores=[]),'UTC_FROZEN_EMBED','exec'),ns)
exec(compile(ast.Module(body=setup,type_ignores=[]),'UTC_FROZEN_GENERIC_SETUP','exec'),ns)
GY={ij:v for ij,v in ns['G'].items() if ij[0]<4 and ij[1]<4}
wrong=multiply(ns['H'],multiply(GY,GY))
DBL={(i,j-2):v for (i,j),v in wrong.items() if i<2 and j>=2}
DLL={(i-2,j-2):v for (i,j),v in wrong.items() if i>=2 and j>=2}
badZ=plus(multiply(ns['JB'],DBL),multiply(ns['JL'],DLL));badW=transpose(multiply(transpose(ns['K']),badZ))
rightW=color_weights(ns['Om'],ns['JB'],ns['JL'],ns['K'],ns['UB'],ns['UL'],ns['H'],2)['Hu_Mx']
NR=multiply(ns['N'],transpose(ns['R']))
inner=lambda W:sum((times(v,NR.get(ij,ZERO)) for ij,v in W.items()),ZERO)
ordering_control=inner(rightW)-inner(badW);assert ordering_control

d=load('primary');act=primitives(d,'primary');nsp=original_matrix_namespace(d,act)
newHx=families[1]['Hu_Mx'];labels=[]
for lower in [13,20,44]:
    key=next(k for k in sorted(newHx) if k[0]>=lower)
    if key not in labels:labels.append(key)
assert len(labels)==3 and all(h>=12 for r,h,ix in labels)
calibrations=[]
for r,h,ix in labels:
    values=[]
    for orientation in [1,-1]:
        nsp.update(R_LABEL=r,C_LABEL=h,X_LABEL=ix,ODD=9)
        G,V,groups=nsp['matrices']('T',1,orientation);X=nsp['mm'](G,V)
        power={(i,i):{0:constant(1)} for i in range(508)}
        for n in range(4):power=nsp['mm'](power,X)
        direct=nsp['tr'](nsp['mm'](power,groups['Mu_free']));hx=nsp['tr'](nsp['mm'](power,groups['Mx']))
        rest={name:nsp['tr'](nsp['mm'](power,M)) for name,M in groups.items() if name not in ['Mu_free','Mx']}
        assert not any(rest.values())
        assert hx==newHx[r,h,ix] and direct==families[1]['direct_1'].get((r,h,ix),ZERO)+families[1]['direct_2'].get((r,h,ix),ZERO)
        assert direct+hx==totals[1].get((r,h,ix),ZERO)
        values.append({'q':orientation,'direct':str(direct),'Hu_Mx':str(hx),'total':str(direct+hx)})
    H,UB,UL=act['u'][1];JB,JL=act['J'][h]
    bad=color_weights(act['Om'],JB,JL,transpose(act['K'][r]),UB,UL,H,45)
    NRix={a:multiply(act['N'],{(j,0):v for (j,i),v in mat.items() if i==ix}) for a,mat in enumerate(act['R'])}
    bad_total=sum((times(v,NRix[a].get((b,0),ZERO)) for W in bad.values() for (b,a),v in W.items()),ZERO)
    source_control=totals[1].get((r,h,ix),ZERO)-bad_total;assert source_control
    nsp['ODD']=0
    power={(i,i):{0:constant(1)} for i in range(508)}
    for n in range(4):power=nsp['mm'](power,X)
    bad_total=sum((nsp['tr'](nsp['mm'](power,M)) for M in groups.values()),ZERO)
    sign_control=totals[1].get((r,h,ix),ZERO)-bad_total;assert sign_control
    calibrations.append({'labels':[r,h,ix],'full508':values,'sensitive_controls':{'omit_Hu_Mx':str(hx),'wrong_source_transpose_difference':str(source_control),'commuting_exterior_difference':str(sign_control)}})
    print('STAGE sensitive_full508 '+str((r,h,ix)),flush=True)

# Late quantum interpretation starts HERE, after independent whole arrays
# and sensitive original-matrix calibrations. Never a native operand.
old=loadz(R/'calculations/canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz')
late=[];remainders=[]
for probe in range(2):
    row=next(z for z in old['results'][probe]['partial_relations'] if z['basis']=='log5')
    conv={tuple(z[:-1]):co(z[-1]) for z in row['homogeneous_plus_Euler_partial']['T']}
    assert len(conv)==len(row['homogeneous_plus_Euler_partial']['T'])
    rem={};tested=0
    for r in range(45):
        for h in range(45):
            for ix in range(328):
                key=(r,h,ix);v=totals[probe].get(key,ZERO)+conv.get(key,ZERO);tested+=1
                if v:rem[key]=v
    assert all(0<=r<45 and 0<=h<45 and 0<=ix<328 for r,h,ix in conv)
    late.append({'probe':probe,'positions_checked':tested,'conversion_nonzeros':len(conv),'cutoff_nonzeros':len(totals[probe]),'sum_nonzeros':len(rem),'conversion_plus_cutoff_zero':not rem})
    remainders.append({'probe':probe,'remainders':[[*k,str(v)] for k,v in sorted(rem.items())]})
with (O/'late_remainders_v2.json.gz').open('xb') as f:f.write(gzip.compress((json.dumps(remainders,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
out={'schema':'UTC4_COMPLETE_T_REVIEW','native_arrays_equal':True,'coverage':coverage,'generic_wrong_Hu_ordering_control_difference':str(ordering_control),'sensitive_actual_calibrations':calibrations,'late_conversion_comparison':late,'known_quantum_remainder_native_operand':False,'full_F_other_bases_or_continuum_QAP_claim':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'review_result_v2.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
