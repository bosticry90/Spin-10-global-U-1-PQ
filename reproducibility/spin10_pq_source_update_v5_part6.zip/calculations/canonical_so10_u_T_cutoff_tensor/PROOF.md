# Complete T log5 local cutoff tensor

UTC1-4, fixed original unshifted SMA/CSW/EDS, A0, constant u,
intrinsic1. External jets are set to zero only after source/field
differentiation. Symbolic g10, xi, eta_H; common hbar/(16pi^2).
The domain is the nonexceptional Euclidean LOCAL RELATIVE formal UV
symbol. UMH supplies the complete local operator, grade bounds, original
free-root cancellation, Lorentz-longitudinal support and positive-heat
radial integral. Those are authenticated inherited results, not new
full continuum trace or connected-product theorems.

## Sector reduction and signs

Use Y=(B_long45,Lambda45), s328, C45,a45. Each matrix below retains its
original external coefficient. T4 has three root classes, each with
24 permutations, hence72 words:

- M_u with X_n,X_x,X_C,X_J;
- M_x with X_n,X_u,X_C,X_J;
- M_C with X_n,X_x,X_u,X_J.

Complete sector-walk composition leaves only

    STr[(X_n X_x + X_x X_n) X_C X_J M_u]
      + STr[X_J X_C X_u X_n M_x].

This is a support identity for arbitrary entries in these blocks. The
enumeration checks every permutation, not a numerical zero threshold.
The diagonal M_C root cannot connect the source ghost block with the
scalar/vector blocks. Original free M_f endpoints cancel by the UMH
reference-pairing identity, including its H_u derivative; that identity
does NOT discard the non-reference-preserving M_u root. Classical QG
source2, potential and fermion exclusions are the owning UMH support/
grade results. Quantum source2 contact Euler terms remain in the old
conversion expression and are retained in the late comparison.

The exterior order is eps,u,Ja,C,n,x, with eps and C odd. All three
surviving words put C before eps and therefore supply an exterior minus.
The M_x word also has an odd quantum trace and gets a second minus.
The two M_u words close through even Y/scalar coordinates. No ordinary-
trace replacement or implicit sign adjustment has been made.

## Color formula by explicit block multiplication

At positive unit longitudinal momentum, the actual bound free matrix is

    G_Y = [[Omega,-1],[1,0]],
    Omega = diag(eta_H on12 unbroken, xi on33 broken).

Let N be the45x328 Lambda-scalar vertex. For fixed scalar index i let
R[a,j]=(R_a)[j,i], with g10 included in the actual generators. J_B,J_L
are the original ghost vertex columns. K[c,a]=B[r,c,a] is the actual
Ja-source tensor. Write M_u[a,Y]=[U_B,U_L], and H_u on Y as H. Then

    X_n[Y,s]=[-N;0],       X_n[s,Y]=[0,N^t],
    X_x[Y,s]=[-i Omega R;-i R],  X_x[s,Y]=[i R^t,0],
    X_C[Y,a]=[L;J_B^t],    X_C[C,Y]=[J_B,J_L],
    X_J[C,C]=K^t,          X_J[a,a]=K,
    M_x[s,C]=R^t,
    L=Omega J_B^t+J_L^t,   W=U_B Omega+U_L,
    D=G_Y H G_Y,           Z=J_B D[B,L]+J_L D[L,L].

Multiplying the three surviving words and applying both exterior and
supertrace signs gives weight matrices (row b, column a)

    C1 = i (L K U_B)^t,
    C2 = i J_B^t K W,
    C3 = (K^t Z)^t.

Thus the complete tensor is

    cutoff_T[r,h,i] = sum_(b,a) (C1+C2+C3)[b,a] (N R_a)[b,i].

No matrices are commuted. The source transpose and H placement follow
from explicit index contractions. Three noncommuting graded fixtures
compare the original72-word trace with the three words and then this
formula, with nonzero omission, exterior-sign and source-transpose
controls. Review adds a nonzero wrong-H-order control. Fixture success
checks the implementation; the block multiplication gives the identity.

## Action data, complete computation and actual calibrations

The original all-Lorentz QG free-symbol differentiation is reused with
its full tensor-shape assertions. This shared helper is NOT claimed to
be an independent derivation. All R_a are checked against actual scalar
field flows, including antisymmetry and zero complements. The reference
G_Y form is checked exactly. Replay reconstructs N,J from the actual GF
Euler columns and K from the source density before comparison with the
stored classical operators. None is obtained from a desired quantum
cancellation.

Primary forms all N R_a first and contracts color weights. Replay first
contracts weights into N and then applies R_a, associating color matrix
products differently. They produce separate C1,C2,C3 tensors and their
sum for all45x45x328 positions in each probe. Their complete sparse maps
agree exactly; review validates unique bounded indices and ring entries
and explicitly traverses the entire domain, treating omitted entries as
zero. This is exact polynomial arithmetic, not interpolation or sampling.

Initial five selected actual508-coordinate cases (two probes and both
momentum signs) agree; their broken-ghost cases were zero, so they were
insensitive to omission of H_u/M_x. Review selects three NEW nonzero
H_u/M_x entries, using only completed native data, at (r,h,i):
(13,13,207),(20,13,169),(44,13,134). Original508-coordinate rooted
matrix powers agree family by family for both signs. Every selected
H_u-omission, source-transpose and commuting-exterior control changes
the actual result. This is targeted full-matrix calibration plus a
complete block-domain proof, not664200 full508-coordinate replays.

## Positive heat and late interpretation

T has no surviving five-edge free-root sum. Its four-edge local kernel
has E^4-E^5, E=exp(-2t p^2). The inherited longitudinal homogeneity and
radial integral give log(5/4)=log5-2log2. The present coefficient is
therefore the entire explicit log5 cutoff_T=C4_T. It says nothing by
itself about the other finite basis coefficients.

Only after both complete arrays and sensitive actual checks agree does
review open the authenticated UPM log5 relative-conversion tensor.
The owning RSH relation is CONVERSION PLUS CUTOFF. It is not equality
of relative conversion with a bare heat effective action. Review tests
all positions, retaining full quantum source2 contact Euler inputs in
the conversion, and writes all nonzero remainders without truncation.

Both probes have zero remainder throughout. Probe0 is zero throughout;
probe1 has12432 nonzero cutoff entries and651768 zeros. Its C1,C2,C3
maps have12128,9632,9632 nonzeros respectively; these counts overlap and
are not independent physical observables or progress percentages.

This qualifies the complete T log5 cancellation in this formal local
reference domain. Full F (especially both-broken-ghost nonlinear
branches), chi4/log2/log3, common continuum trace/product/contact limits,
measure, QAP, E5/A5 and physical viability remain separate obligations.
