"""Bound classical operators only. No quantum remainder is an operand."""
from pathlib import Path
from functools import lru_cache
from collections import defaultdict
import ast,gzip,json,sys
import sympy as s
from algebra import *
from coefficient_ring import coefficient,g,xi,eta
O=Path(__file__).resolve().parent;R=O.parents[1]
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'))
from jets import decode,degree,parity
@lru_cache(None)
def co(v):return coefficient(s.sympify(v,locals={'g10':g,'xi':xi,'eta_H':eta}))
def dec(z):return {(i,j):co(v) for i,j,v in z['entries']}
def load(role):
    return json.loads(gzip.decompress((R/'calculations/canonical_so10_u_maximal_heat_cutoff'/(role+'_inputs.json.gz')).read_bytes()))
def primitives(d,role):
    Q=list(map(decode,d['QG']));RR=list(map(dec,d['R']))
    flows={i:decode(z) for i,z in d['field_flows']}
    # Reconstruct the scalar flow, including the zero complement.
    RF=[{} for _ in range(45)]
    for out,poly in flows.items():
        if not 180<=out<508:continue
        for w,c in poly.items():
            if len(w)==2 and not any(js for i,js in w):
                xs=[i for i,js in w if 180<=i<508];cs=[i for i,js in w if 553<=i<598]
                if len(xs)==len(cs)==1:RF[cs[0]-553][out-180,xs[0]-180]=c
    assert RF==RR
    assert all(mat==scale(transpose(mat),constant(-1)) for mat in RR)
    G=dec(d['G0']);Om={(i,j):v for (i,j),v in G.items() if i<45 and j<45}
    expected=dict(Om)
    for i in range(45):expected[i,45+i]=constant(-1);expected[45+i,i]=constant(1)
    assert G==expected and Om=={(i,i):co('eta_H' if i<12 else 'xi') for i in range(45)}
    N0=dec(d['N0']);J0=list(map(dec,d['J0']));BB={tuple(row[:-1]):co(row[-1]) for row in d['B']}
    if role=='replay':
        gradient={i:decode(z) for i,z in d['GF_gradient']};N0={};J0=[{} for _ in range(45)]
        for out,poly in gradient.items():
            if 508<=out<553:
                for w,c in poly.items():
                    if len(w)==1 and 180<=w[0][0]<508 and not w[0][1]:N0[45+out-508,w[0][0]-180]=c
            if 598<=out<643:
                for w,c in poly.items():
                    if len(w)!=2:continue
                    for at,(i,js) in enumerate(w):
                        if not 553<=i<598 or js:continue
                        inn,jj=w[1-at]
                        b=inn//4 if inn<180 and inn%4==3 else 45+inn-508 if 508<=inn<553 else None
                        if b is None or any(mu!=3 for mu in jj):continue
                        value=c
                        for mu in jj:value=times(value,I)
                        key=(out-598,b);J0[i-553][key]=J0[i-553].get(key,ZERO)+value
        N0=clean(N0);J0=list(map(clean,J0));BB={}
        for w,value in d['source_action']:
            if len(w)==3 and 45<=w[0]<90 and 135<=w[1]<180 and 180<=w[2]<225:BB[w[0]-45,w[1]-135,w[2]-180]=-co(value)
        assert N0==dec(d['N0']) and J0==list(map(dec,d['J0']))
        assert BB=={tuple(row[:-1]):co(row[-1]) for row in d['B']}
    assert all(45<=b<90 for b,j in N0)
    N={(b-45,j):v for (b,j),v in N0.items()}
    Js=[({(a,b):v for (a,b),v in mat.items() if b<45},{(a,b-45):v for (a,b),v in mat.items() if b>=45}) for mat in J0]
    Ks=[{(c,a):v for (rr,c,a),v in BB.items() if rr==r} for r in range(45)]
    # Reuse the qualified all-Lorentz free-symbol derivative, with its full
    # shape assertions. This shared helper is disclosed, not another proof.
    tree=ast.parse((R/'calculations/canonical_so10_u_maximal_heat_cutoff/native.py').read_bytes())
    free_node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='full_free')
    ns={'Q':Q,'degree':degree,'ZERO':ZERO,'I':I,'times':times}
    exec(compile(ast.Module(body=[free_node],type_ignores=[]),'UTC_BOUND_FREE_SYMBOL','exec'),ns)
    free=[ns['full_free'](probe) for probe in range(2)]
    def yf(i):return i//4 if i<180 and i%4==3 else 45+i-508 if 508<=i<553 else None
    us=[]
    for H,MU in free:
        h={};ub={};ul={}
        for (i,j,p),v in H.items():
            a,b=yf(i),yf(j)
            if a is not None and b is not None and all(not z for mu,z in enumerate(p) if mu!=3):h[a,b]=v
        for (i,j,p),v in MU.items():
            b=yf(j)
            if b is not None and all(not z for mu,z in enumerate(p) if mu!=3):
                assert 598<=i<643
                if b<45:ub[i-598,b]=v
                else:ul[i-598,b-45]=v
        us.append((h,ub,ul))
    return {'Q':Q,'flows':flows,'R':RR,'N':N,'J':Js,'K':Ks,'Om':Om,'free':free,'u':us,'G':G,'N0':N0,'J0':J0,'B':BB}

def original_matrix_namespace(d,p):
    """Original 508-coordinate route, with only selected external labels varied."""
    tree=ast.parse((R/'calculations/canonical_so10_u_maximal_heat_cutoff/native.py').read_bytes())
    names={'field','qpow','sign','padd','pmul','mm','add','tr','m0groups','matrices'}
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    node=next(n for n in nodes if n.name=='matrices')
    # Explicitly replace three label assignments, never the matrix rules.
    node.body[:3]=ast.parse('r=R_LABEL\nix=X_LABEL\ncs=[(C_LABEL,CC1)]').body
    ast.fix_missing_locations(node)
    ns={'defaultdict':defaultdict,'lru_cache':lru_cache,'ZERO':ZERO,'constant':constant,'times':times,'I':I,
        'parity':parity,'flows':p['flows'],'RR':p['R'],'N':p['N0'],'J0':p['J0'],'B':p['B'],
        'free':p['free'],'d':d,'dec':dec,'NB':418,'NC':418,'NA':463,'DIM':508,
        'EPS':1,'UU':2,'JJ':4,'CC1':8,'CC2':0,'NN':16,'XX':32,'TARGET':63,'ODD':9}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'UTC_ORIGINAL_MATRIX_ROUTE','exec'),ns)
    return ns
