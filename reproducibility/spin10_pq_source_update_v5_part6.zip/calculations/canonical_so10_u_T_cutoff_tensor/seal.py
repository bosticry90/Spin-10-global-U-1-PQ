from pathlib import Path
from hashlib import sha256
import ast,gzip,json,subprocess
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-T-cutoff-tensor-v1-2026-10-26')
H=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
base=read(O/'inputs.json')['base_HEAD']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==base
assert subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()=='main'
subprocess.run(['git','diff','--quiet','HEAD'],cwd=R,check=True)
tree=subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)
assert tree==(C/'old_git_tree.txt').read_bytes()
assert H(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
bindings={}
for file in sorted(O.glob('*preparation*.json')):
    for path,h in read(file)['input_sha256'].items():
        assert H(Path(path))==h,(file.name,path)
        if path in bindings:assert bindings[path]==h
        bindings[path]=h
for file in O.glob('*.source.txt'):
    original=O/file.name.removesuffix('.source.txt');assert original.read_bytes()==file.read_bytes(),file
for file in O.glob('*.py'):ast.parse(file.read_bytes())
successful=['fixtures_capture.json','calibration_capture.json','primary_capture.json','replay_capture.json','review_capture_v2.json']
maxmem=0
for file in successful:
    z=read(O/file)
    assert z['exit_code']==0 and z['calculation_completed'] and z['execution_state']=='COMPLETED' and z['post_run_observations_qualified']
    assert z['launch']['creation_after_observation'] and z['launch']['memory']['available_pagefile']>=350*1024**2
    for sample in z['all_resource_samples']:
        assert sample['private_bytes']<8*1024**3;maxmem=max(maxmem,sample['private_bytes'])
failed=read(O/'review_capture.json')
assert failed['exit_code']==1 and not failed['calculation_completed'] and failed['execution_state']=='FAILED'
assert 'NameError' in failed['stdout_and_stderr'] and 'embed' in failed['stdout_and_stderr']
assert read(O/'review_controller_failure.json')['failure_relabelled_PASS'] is False
for name,limit in [('fixtures_result.json',300),('calibration_result.json',300),('review_result_v2.json',180)]:assert read(O/name)['elapsed_after_imports']<limit
p=load(O/'primary_tensor.json.gz');r=load(O/'replay_tensor.json.gz')
assert p['results']==r['results'] and p['elapsed_after_imports']<300 and r['elapsed_after_imports']<300
assert p['algorithm_guard_denials']==r['algorithm_guard_denials']==2
v=read(O/'review_result_v2.json')
assert v['native_arrays_equal'] and all(z['positions_checked']==664200 and z['conversion_plus_cutoff_zero'] and z['sum_nonzeros']==0 for z in v['late_conversion_comparison'])
assert len(v['sensitive_actual_calibrations'])==3
assert load(O/'late_remainders_v2.json.gz')==[{'probe':0,'remainders':[]},{'probe':1,'remainders':[]}]
e=read(O/'e4_capture.json');events=[json.loads(line) for line in e['stdout'].splitlines() if line.startswith('{')]
exits=[z['exit_code'] for z in events if z.get('event')=='step_finished']
assert e['exit_code']==0 and exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED'
files={str(p.relative_to(R)).replace('\\','/'):H(p) for p in O.iterdir() if p.is_file()}
handoff=R/'docs/RESEARCH_EXECUTION_HANDOFF_V648.md';files[str(handoff.relative_to(R)).replace('\\','/')]=H(handoff)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<32*1024**2
out={'schema':'UTC_FINAL_REVIEW_VALIDATION_V1','base_HEAD':base,'evidence_validation':'PASS_COMPLETED_BOUNDED_T_LOG5_SCOPES_WITH_PRESERVED_REVIEW_SETUP_FAILURE',
     'scope':'Complete formal local T log5 regulator tensor and late conversion PLUS cutoff identity; both probes, complete domains.',
     'scientific_acceptance':'NOT_PERFORMED','authority':'34/39; E5/A5 OPEN','custody':'EXIT_2_SEVEN_UNRESOLVED','state_unchanged':True,
     'authenticated_input_and_source_bindings':len(bindings),'preserved_old_mode_blob_entries':len(tree.splitlines()),'successful_captures':successful,
     'failed_review_preserved':'review.py/review_capture.json: missing embed helper; FAILED, not PASS','e4_step_exits':exits,
     'maximum_successful_private_sample_bytes':maxmem,'sample_is_continuous_peak':False,'full_investigation_complete':False,
     'limitations':['shared action/reference/charts/ring/free-symbol helper/software/AI author','targeted original508-coordinate checks plus complete block-domain formula, not every original matrix trace','full F and other finite bases not computed','no full common trace/product/contact limit, measure/QAP or physical viability claim'],
     'new_files_sha256':files}
dump(O/'final_review_validation_receipt.json',out);dump(C/'final_review_validation_receipt.json',out)
print(json.dumps({k:v for k,v in out.items() if k not in ['new_files_sha256','limitations']},sort_keys=True))
