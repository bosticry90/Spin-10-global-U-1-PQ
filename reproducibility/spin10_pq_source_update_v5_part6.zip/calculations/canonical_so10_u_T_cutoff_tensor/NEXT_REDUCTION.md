# Next bounded question: full F log5

Proposal only; not a qualified F tensor or a new execution allowance.
Reuse UMH's complete source/field operators and UTC's sector technique.
The full F coefficient is C4_F-C5_F; selected C5_F=0 does not imply
the full five-edge tensor vanishes.

At five edges the four root classes are M_u, M_x, M_C1, M_C2, each with
120 permutations. The source is JL (odd), not Ja. Its X_J block is
off-diagonal between Y and ghost sectors. Retain all four exterior odd
symbols eps,JL,C1,C2, with C1<C2. Enumerate all480 sector words before
trusting a manually simplified formula. Derive exact color traces,
then noncommuting graded fixtures and actual nonzero broken-ghost
calibrations. The two ghosts are distinct; do not merge them or turn
antisymmetry into an unproved factor of two.

Four-edge terms also contain nonlinear action/source vertices and
M_u,intrinsic, M_CC and source derivatives. Whole-support exclusions
may be reused only in their proven scopes. GF-aaCC/source-D have
both-broken-ghost support and were invisible to the old C0,C12 witness.
Source2 classical cutoff terms are excluded by grade/source count;
quantum source2 contact Euler inputs in conversion are required.

Freeze a new bounded record before computation, retaining old native
data blindness and current resource limits. Prefer tensor contractions
and support reductions to a14,612,400-entry full-matrix loop. A complete
F comparison or an exact mismatch is informative; convenient fitted
normalizations, changed parameter points and discarded contacts are not.
All other finite bases and continuum/QAP/physical questions remain open.
