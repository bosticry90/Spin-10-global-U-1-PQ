from pathlib import Path
from itertools import permutations
from functools import lru_cache
import json,time,threading,os
from algebra import *
O=Path(__file__).resolve().parent;tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
eps=1;u=2;J=4;C=8;nu=16;x=32;target=63;odd=eps|C
@lru_cache(None)
def sign(a,b,odds):return (-1)**sum((b&odds&((1<<i)-1)).bit_count() for i in range(6) if a&odds&(1<<i))
def pmul(A,B,odds=odd):
    out={};rows={}
    for (i,j),poly in B.items():rows.setdefault(i,[]).append((j,poly))
    for (i,k),p in A.items():
        for j,q in rows.get(k,[]):
            z=out.setdefault((i,j),{})
            for a,v in p.items():
                for b,w in q.items():
                    if not a&b:z[a|b]=z.get(a|b,ZERO)+times(v,w)*sign(a,b,odds)
    return {ij:{m:v for m,v in z.items() if v} for ij,z in out.items() if any(z.values())}
def ptrace(A):return sum((poly.get(target,ZERO)*(-1 if i>=7 else 1) for (i,j),poly in A.items() if i==j),ZERO)
def chain(ops,odds=odd):
    M={(i,i):{0:constant(1)} for i in range(11)}
    for op in ops:M=pmul(M,op,odds)
    return ptrace(M)
def lifted(M,mask):return {ij:{mask:v} for ij,v in M.items()}
def embed(out,M,ro,co):
    for (i,j),v in M.items():out[i+ro,j+co]=v

# Independent support-only walks, before numerical fixture coefficients.
edges={'n':{('Y','s'),('s','Y')},'x':{('Y','s'),('s','Y')},'J':{('C','C'),('a','a')},'C':{('Y','a'),('C','Y')},'u':{('Y','Y')}}
roots={'Mu':{('a','Y')},'Mx':{('s','C')},'MC':{(q,q) for q in ['Y','s','C','a']}}
walks={}
for name,letters in [('Mu',('n','x','C','J')),('Mx',('n','u','C','J')),('MC',('n','x','u','J'))]:
    good=[]
    for word in permutations(letters):
        prod=roots[name]
        for letter in word[::-1]:prod={(a,d) for a,b in edges[letter] for c,d in prod if b==c}
        if any(a==b for a,b in prod):good.append(word)
    walks[name]=good
assert set(walks['Mu'])=={('n','x','C','J'),('x','n','C','J')}
assert walks['Mx']==[('J','C','u','n')] and not walks['MC']

results=[]
for seed in [1,2,5]:
    def gen(m,n,t):return {(i,j):constant(seed*(t+1)+(i+1)**2*(j+2)+(j+1)**2-2*i*j) for i in range(m) for j in range(n)}
    Om={(0,0):constant(seed+2),(1,1):constant(seed+4),(0,1):constant(1),(1,0):constant(1)}
    N=gen(2,3,1);R=gen(2,3,3);K=gen(2,2,5);JB=gen(2,2,7);JL=gen(2,2,9);UB=gen(2,2,11);UL=gen(2,2,13)
    A=plus(gen(2,2,15),transpose(gen(2,2,15)));B=gen(2,2,17);D=plus(gen(2,2,19),transpose(gen(2,2,19)));H={}
    embed(H,A,0,0);embed(H,B,0,2);embed(H,scale(transpose(B),constant(-1)),2,0);embed(H,D,2,2)
    G={};embed(G,Om,0,0);embed(G,scale(identity(2),constant(-1)),0,2);embed(G,identity(2),2,0);embed(G,identity(3),4,4);embed(G,identity(2),7,9);embed(G,scale(identity(2),constant(-1)),9,7)
    Vn={};embed(Vn,N,2,4);embed(Vn,transpose(N),4,2)
    Vx={};embed(Vx,scale(R,-I),0,4);embed(Vx,scale(transpose(R),I),4,0)
    VJ={};embed(VJ,scale(K,constant(-1)),7,9);embed(VJ,transpose(K),9,7)
    VC={};embed(VC,transpose(JB),0,9);embed(VC,scale(transpose(JL),constant(-1)),2,9);embed(VC,JB,9,0);embed(VC,JL,9,2)
    VH={};embed(VH,H,0,0)
    MU={};embed(MU,UB,9,0);embed(MU,UL,9,2)
    MX={};embed(MX,transpose(R),4,7)
    MC={};embed(MC,gen(4,4,21),0,0);embed(MC,gen(3,3,23),4,4);embed(MC,gen(2,2,25),7,7);embed(MC,gen(2,2,27),9,9)
    X={name:lifted(multiply(G,V),mask) for name,V,mask in [('n',Vn,nu),('x',Vx,x),('J',VJ,J),('C',VC,C),('u',VH,u)]}
    MUs=lifted(MU,eps|u);MXs=lifted(MX,eps|x);MCs=lifted(MC,eps|C)
    full={};wrong=ZERO
    for name,letters,root in [('Mu',('n','x','C','J'),MUs),('Mx',('n','u','C','J'),MXs),('MC',('n','x','u','J'),MCs)]:
        full[name]=sum((chain([X[a] for a in word]+[root]) for word in permutations(letters)),ZERO)
        wrong+=sum((chain([X[a] for a in word]+[root],0) for word in permutations(letters)),ZERO)
    direct=chain([X['n'],X['x'],X['C'],X['J'],MUs])+chain([X['x'],X['n'],X['C'],X['J'],MUs])
    hx=chain([X['J'],X['C'],X['u'],X['n'],MXs])
    assert full=={'Mu':direct,'Mx':hx,'MC':ZERO}
    weights=color_weights(Om,JB,JL,K,UB,UL,H,2);NR=multiply(N,transpose(R))
    inner=lambda W:sum((times(v,NR.get(ij,ZERO)) for ij,v in W.items()),ZERO)
    assert inner(weights['direct_1'])+inner(weights['direct_2'])==direct
    assert inner(weights['Hu_Mx'])==hx
    badK=color_weights(Om,JB,JL,transpose(K),UB,UL,H,2)
    controls={'omit_reverse_nx':chain([X['x'],X['n'],X['C'],X['J'],MUs]),'omit_Hu_Mx':hx,'commute_odd_coefficients':direct+hx-wrong,'wrong_source_transpose':direct+hx-sum((inner(W) for W in badK.values()),ZERO)}
    assert all(controls.values()),{k:str(v) for k,v in controls.items()}
    results.append({'seed':seed,'full72_terms':str(direct+hx),'direct_family':str(direct),'Hu_Mx_family':str(hx),'controls_changed_coefficients':{k:str(v) for k,v in controls.items()}})
out={'schema':'UTC1_COMPLETE_BLOCK_AND_COLOR_REDUCTION','sector_words':walks,'fixtures':results,'physical_parameter_points':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'fixtures_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
