# UTC4 complete-domain review and sensitive actual calibrations

Freeze after UTC1/2/3 outputs; no quantum target has been an operand.
Compare the two new exact arrays, all family arrays, and their implicit
zero complements in both 664200-position domains. Validate unique keys,
ring types and family sums. Review ceiling180s after imports, all other
UTC resource and authority ceilings unchanged.

Initial UTC2 broken-ghost calibrations were zero and did not test a
nonzero H_u/M_x coefficient. Select new sensitive calibration labels from
the first nonzero NEW H_u/M_x entries at source labels at least13,20,44.
This selection uses neither the old quantum remainder nor a fitted value.
Recompute full original508-coordinate C4 with both longitudinal signs.
Require family-level agreement and sensitive H_u-omission, source-transpose
and exterior-sign controls. Explicitly distinguish this targeted coverage
from replaying every full508-coordinate tensor entry.

For noncommuting integer fixtures, check a misplaced H_u ordering as a
further sensitive control, not a physical parameter selection. Authenticate
and extract only the frozen fixture definitions/setup; no old driver runs.

Only after new array agreement and actual sensitive comparisons, open the
authenticated old UPM full T log5 relative-conversion table. Compute its
sum with the new cutoff at EVERY position; save every nonzero remainder,
not just witnesses. A nonzero remainder is a scientific mismatch to report,
not grounds to change the regulator sign or fit coefficients. Full F,
other finite bases and common trace/product/QAP/physical limits stay open.
