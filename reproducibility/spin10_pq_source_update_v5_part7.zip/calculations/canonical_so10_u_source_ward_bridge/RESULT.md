# UWB1/2: a defect-inclusive Ward identity and an actual classical prerequisite

The general finite source/Hessian identity remains valid with quadratic
sources when the classical master defect is retained. For the actual
constant-field nonminimal/scalar module, the first rho and u master
coefficients vanish through intrinsic degree1 for both probes. This
qualifies a classical prerequisite in that module. It does not evaluate
the missing regulated cutoff response or cancel the quantum log5 remainder.

## Evidence and exact scope

UWB1 freshly compares even directional replacement and finite Taylor
coefficient extraction for three exact Grassmann polynomial fixtures.
Each has18 action terms,34 polarized Hessian terms and258 identity terms.
All identities agree. Omission controls give298 changed terms for the
master defect,234 for source flow,64 for source2 in the operation and15
for d=rho*d/du. These are diagnostic algebra fixtures, not model amplitudes.
The finite Gaussian pairing/trace step is inherited explicitly from CSW;
its old fixtures were not freshly rerun or silently promoted to a new
continuum domain.

UWB2 uses the actual raw gauge-fixing density, qualified nonminimal source
action/maps, scalar R matrices and original G/QG polynomials. It retains
x328,C45,a45,Lambda45,Ja45,JL45 at A=B=all jets0. Jx/JC appear in source
differentiation bookkeeping; actual G/QG depend on exactly90 nonminimal
sources, so their physical scalar/ghost Euler columns are not assumed zero.
The physical action has no a/Lambda dependence. The review checks all643
original field-map outputs, including3724 vector-rule rows, and the
nonnegative intrinsic grading of all35944 retained operation terms.
This justifies the declared stable projection, not an arbitrary deletion
of fields or sources from the theory.

Primary transports the raw GF density before taking Euler derivatives;
replay differentiates raw GF first and transports the resulting covectors.
Primary uses qualified field/cotangent maps; replay reconstructs the
operation from right derivatives of the actual Euclidean source action.
The two methods agree on every coefficient, including implicit zeros.
Both retain8388 of33092 raw GF rows,34489 GF-gradient terms and35944
operation terms (29380 intrinsic0,6564 intrinsic1).

| Retained polynomial/result | Probe0 | Probe1 |
| --- | ---: | ---: |
| G_E terms |48|1624|
| QG_E terms |36|17063|
| QG_E-q0G_E nonzero terms |0|0|
| q0QG_E nonzero terms |0|0|
| Positive-source u field-response terms |12|3377|

The GF variation is also zero in this projection. Probe1's QG terms
include1705 quadratic-source terms; source degree was not truncated.
The full input partition preserves9522 positive-jet and60236 outside-
module probe1 QG rows and1072 rows outside intrinsic0/1; it does not
assign those excluded sectors zero as full-theory coefficients.

The positive-source u diagonal trace vanishes by a second support argument:
every response lacks its own output field, so every diagonal derivative
vanishes separately. Nonzero off-diagonal tangents remain. This formal
component is not the full quantum measure or an equivalence theorem.

## Focused result-to-claim assessment

**Supported inference.** Finite source2 polarization is sound with its
master defect retained. Actual first-probe master defects are zero in the
stable zero-jet intrinsic0/1 module. A generic source2 failure in that
module cannot be invoked to explain the retained quantum remainder.

**Missing bridge and alternatives.** The regulated one-loop Hessian
requires internal quantum momenta and derivatives, and additional field
sectors. This module does not settle that premise. A missing nonlinear
source tangent, insertion/contact response, a domain defect or a legitimate
finite-normalization issue remains possible. None is fitted to the desired
remainder. chi4,b0,kappa and infrared freedoms stay separate and symbolic.

**Significance and AI limits.** The work identified and checked a premise
rather than assuming an older source-linear proof applied. Distinct
transport/derivative routes and sensitive generic controls test concrete
implementation errors. They share the action, charts, exact ring, software
and AI author; no external validation, proof-assistant formalization or
empirical connection is claimed. Counts do not quantify E5 completion.

**Next discriminating action.** Extend the actual first-probe master check
only as far as needed for the T/F cutoff: retain the two quantum fluctuation
legs and their arbitrary loop momentum before external zero-jet projection.
Derive the required u tangent/Hessian response from the original action,
with source degrees0/1/2 and the fixed reference. Use the resulting ordered
positive-heat operator, not minus the known remainder, to choose the next
finite coefficient calculation. The existing principal free bridge and
the present nonlinear constant-field result are complementary prerequisites;
neither alone supplies the complete momentum-dependent identity.

## Verification, authority and preservation

Native after-import times:0.8742s UWB1,181.2367s primary,154.6596s replay;
review1.5009s. All completed within their frozen300/180s bounds. Largest
sampled private allocation392626176B (not a continuously measured peak).
Packet800868B before reports. Inputs and source copies were frozen before
execution, and complete captures remain. No failed native run occurred.
Read-only filename lookup errors are preserved in the external control note.

The delegated E4 and final byte-custody checks are recorded separately in
their actual capture and final receipt; they do not freshly replay global
scientific calculations. State113,authority34/39,E5/A5 OPEN and historical
custody exit2/seven unresolved references remain unchanged. No foundation,
benchmark,scheme,protected stage,remote action or publication was adopted.
