from pathlib import Path
from fractions import Fraction
from hashlib import sha256
import json, time, threading, os
from algebra import Algebra

O = Path(__file__).resolve().parent
tick = time.perf_counter()
timer = threading.Timer(300, lambda: os._exit(124))
timer.daemon = True
timer.start()
odd = {2, 3, 4, 5, 9, 12, 13, 16, 17}
a = Algebra(lambda i: int(i in odd))
pairs = list(zip(range(4), range(4, 8)))
U = {i: {(10 + i,): 1} for i in range(4)}
V = {i: {(14 + i,): 1} for i in range(4)}


def D(poly, flow):
    return a.vary(poly, flow, odd=False)


def d(poly):
    return a.mul({(9,): 1}, a.diff(poly, 8))


def shifted_derivatives(poly):
    # Independent finite Taylor coefficient route: no directional derivative.
    subs = {i: {(i,): 1, (10 + i, 18): 1, (14 + i, 19): 1} for i in range(4)}
    shifted = a.shift(poly, subs)
    out = {}
    for key, powers in [('U', (1, 0)), ('V', (0, 1)), ('UV', (1, 1))]:
        out[key] = {tuple(i for i in w if i not in (18, 19)): v
                    for w, v in shifted.items() if (w.count(18), w.count(19)) == powers}
    return out


results = []
for seed in (2, 3, 5):
    # Deliberately NOT a master action: the defect must survive.
    words = [(0, 0), (1, 1), (2, 3), (4, 2, 0, 0), (5, 3, 1),
             (7, 1), (6, 2, 3), (7, 7, 0), (7, 4, 2, 1), (4, 5, 2, 3),
             (8, 7, 7), (8, 7, 5, 2, 0, 1), (8, 4, 5, 2, 3, 0), (8, 0, 0),
             (9, 3, 1), (9, 7, 5, 0), (9, 4, 0, 1), (8, 8, 0, 1)]
    sigma = {}
    for n, word in enumerate(words):
        a.put(sigma, word, Fraction((n + 1) * seed + (n % 3), n % 4 + 1))
    sigma = a.clean(sigma)
    assert all(sum(a.parity(i) for i in w) % 2 == 0 for w in sigma)
    DU, DV = D(sigma, U), D(sigma, V)
    H = D(DU, V)
    total = a.add(a.scale(a.bracket(sigma, sigma, pairs), Fraction(1, 2)), d(sigma))
    lhs = a.add(a.bracket(sigma, H, pairs), d(H))
    rhs = a.add(D(D(total, U), V), a.scale(a.bracket(DU, DV, pairs), -1))
    assert lhs == rhs
    shift = shifted_derivatives(sigma)
    assert (DU, DV, H) == (shift['U'], shift['V'], shift['UV'])
    total_shift = shifted_derivatives(total)['UV']
    assert lhs == a.add(total_shift, a.scale(a.bracket(shift['U'], shift['V'], pairs), -1))
    # Controls retain the full Hessian/input while omitting an operation.
    no_defect = a.add(D(D(d(sigma), U), V), a.scale(a.bracket(DU, DV, pairs), -1))
    field_only = {i: a.scale(a.diff(sigma, j), (-1) ** a.parity(i)) for i, j in pairs}
    no_source = a.add(a.vary(H, field_only), d(H))
    source2_removed = {w: v for w, v in sigma.items() if sum(4 <= i < 8 for i in w) < 2}
    no_source2 = a.add(a.bracket(source2_removed, H, pairs), d(H))
    no_d = a.bracket(sigma, H, pairs)
    controls = {name: len(a.add(lhs, a.scale(value, -1)))
                for name, value in [('omit_master_defect', no_defect), ('omit_source_flow', no_source),
                                    ('omit_source2_in_operation', no_source2), ('omit_d', no_d)]}
    assert all(controls.values()), controls
    results.append({'seed': seed, 'sigma_terms': len(sigma), 'H_terms': len(H),
                    'defect_terms': len(total), 'identity_terms': len(lhs),
                    'sensitive_controls_mismatches': controls})
out = {'schema': 'UWB1_DEFECT_INCLUSIVE_FINITE_POLARIZATION', 'fixtures': results,
       'methods': ['even directional replacement', 'finite Taylor extraction'],
       'quantum_or_model_qualification': False, 'elapsed_after_imports': time.perf_counter() - tick}
raw = (json.dumps(out, sort_keys=True, separators=(',', ':')) + '\n').encode()
with (O / 'polarization_result.json').open('xb') as stream:
    stream.write(raw)
print('RESULT ' + json.dumps(out, sort_keys=True), flush=True)
timer.cancel()
