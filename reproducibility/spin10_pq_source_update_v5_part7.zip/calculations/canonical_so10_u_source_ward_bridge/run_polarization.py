from pathlib import Path
from hashlib import sha256
import ast, json, sys, traceback
O=Path(__file__).resolve().parent
R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-source-ward-bridge-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings={str(R/p):h for p,h in json.loads((O/'inputs.json').read_bytes())['input_sha256'].items()}
    for p,h in bindings.items():assert H(Path(p))==h,p
    for name in ['.gitattributes','inputs.json','RECORD.md','DERIVATION.md','algebra.py','polarization.py','run_polarization.py']:
        p=O/name
        if p.suffix=='.py':ast.parse(p.read_bytes())
        (O/(name+'.source.txt')).write_bytes(p.read_bytes())
        bindings[str(p)]=H(p)
    dump(O/'polarization_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    result=capture([sys.executable,'-B',str(O/'polarization.py')])
    dump(O/'polarization_capture.json',result);dump(C/'polarization_full_capture.json',result)
    assert result['exit_code']==0 and result['execution_state']=='COMPLETED'
    assert result['calculation_completed'] and result['post_run_observations_qualified']
    assert result['launch']['memory']['available_pagefile']>=350*1024**2
    assert max(v['private_bytes'] for v in result['all_resource_samples'])<=8*1024**3
    evidence=json.loads((O/'polarization_result.json').read_bytes())
    assert evidence['elapsed_after_imports']<300
except BaseException:
    dump(O/'polarization_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False})
    raise
