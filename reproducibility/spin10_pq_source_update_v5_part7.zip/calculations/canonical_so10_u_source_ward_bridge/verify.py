from pathlib import Path
from hashlib import sha256
from collections import Counter
import gzip,json,os,threading,time
O=Path(__file__).resolve().parent;R=O.parents[1]
tick=time.perf_counter(); timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
for p,h in read(O/'review_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
p,q=(load(O/('module_'+role+'_tables.json.gz')) for role in ['primary','replay'])
assert p==q,'Complete coefficient/zero-complement comparison failed'
results=[read(O/('module_'+role+'_result.json')) for role in ['primary','replay']]
assert results[0]['raw_sha256']==results[1]['raw_sha256']
for role,result in zip(['primary','replay'],results):
    raw=gzip.decompress((O/('module_'+role+'_tables.json.gz')).read_bytes())
    assert sha256(raw).hexdigest()==result['raw_sha256']
    assert sha256((O/('module_'+role+'_tables.json.gz')).read_bytes()).hexdigest()==result['packed_sha256']
    assert result['elapsed_after_imports']<300
    capture=read(O/('module_'+role+'_capture.json'))
    assert capture['exit_code']==0 and capture['calculation_completed'] and capture['post_run_observations_qualified']
assert len(p['probes'])==2
assert not p['qGF']
for probe in p['probes']:
    assert not probe['rho_defect'] and not probe['u_defect']
    # Independent diagonal-support proof: every positive-source u field
    # response lacks its own output field, so each diagonal derivative
    # vanishes separately. Off-diagonal tangents are not discarded.
    assert all(out not in word for out,rows in probe['source_dependent_qu'] for word,co in rows)

par=lambda i:int(328<=i<418 or 463<=i<791 or 881<=i<926)
dim=lambda i:1 if i<418 or 881<=i else 2
intrinsic_counts=Counter()
for out,rows in p['operation']:
    for word,coeff in rows:
        assert sum(par(i) for i in word)%2==(par(out)+1)%2
        nd=dim(out)+1-sum(dim(i) for i in word)
        assert nd in [0,1],(out,word,nd)
        intrinsic_counts[nd]+=1

# Check actual ideal stability from the original full raw field maps.
# Derivatives of products contain a positive jet, hence vanish in the
# zero-jet ideal. Every omitted B rule must retain A/B or a positive jet.
base=load(R/'calculations/canonical_so10_cutoff_source_ward_operator/primary_inputs.json.gz')
data=load(R/'calculations/canonical_so10_remaining_u_contact_vertices/vertices_primary_inputs.json.gz')
xs=set(data['xs']); cs={'C'+str(i) for i in range(45)}
aux={('b' if i<12 else 'L')+str(i) for i in range(45)}
ants={('bar' if i<12 else 'ub')+str(i) for i in range(45)}
kept=xs|cs|aux|ants
bs={f'B{i}_{mu}' for i in range(45) for mu in range(4)}
As={f'A{i}_{mu}' for i in range(12) for mu in range(4)}
vector_rows=0; retained_rows=0
for out,rows in base['field_maps'].items():
    if out in bs:
        for row in rows:
            assert any(n in bs or n in As or '__' in n for n in row['word']),(out,row)
            vector_rows+=1
    elif out in kept:
        for row in rows:
            # Raw scalar and nonminimal rules close without a dropped field.
            assert all(n in kept or n in As or n in bs or '__' in n for n in row['word'])
            if all(n in kept for n in row['word']):retained_rows+=1
    else:raise AssertionError(('unknown_field_map_output',out))
assert len(base['field_maps'])==643
geo=data['audit']['geometry'];names=data['audit']['names'];oldnames=geo['names']
sourcepairs={oldnames[J]:oldnames[f] for f,J,h,k in geo['field_source_h_k']}
usedsources=set()
for packet in data['audit']['physical_G']+data['audit']['physical_QG']:
    for gp,tokens,ci in packet['monomials']:
        usedsources.update(names[i] for i,jets in tokens if names[i] in sourcepairs)
assert len(usedsources)==90
assert all(sourcepairs[n] in aux|ants for n in usedsources)

fixture=read(O/'polarization_result.json')
assert len(fixture['fixtures'])==3
assert all(all(row['sensitive_controls_mismatches'].values()) for row in fixture['fixtures'])
assert sha256((R/'project_state.json').read_bytes()).hexdigest()=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
out={'schema':'UWB1_2_BOUNDED_REVIEW','full_native_tables_equal':True,
     'GF_variation_zero_in_module':True,'rho_u_master_coefficients_zero_in_module':True,
     'actual_vector_ideal_support_rows':vector_rows,'retained_raw_field_flow_rows':retained_rows,
     'all_full_field_maps_checked':643,'used_nonminimal_source_names':90,
     'operation_intrinsic_degree_counts':dict(intrinsic_counts),
     'generic_controls':fixture['fixtures'][0]['sensitive_controls_mismatches'],
     'scope':'Constant-field, zero-jet, intrinsic0/1, nonminimal/scalar projection; finite polynomial identity. Full momentum Hessian and quantum trace domains not established.',
     'scientific_acceptance':'NOT_PERFORMED','elapsed_after_imports':time.perf_counter()-tick}
with (O/'review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
