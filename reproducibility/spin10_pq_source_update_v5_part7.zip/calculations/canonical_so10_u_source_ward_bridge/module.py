"""Actual zero-jet module test. Nonzero defects are evidence, not failures."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from functools import lru_cache
from collections import Counter
import gzip, json, os, sys, threading, time
from algebra import Algebra

O=Path(__file__).resolve().parent; R=O.parents[1]
role=sys.argv[1]; assert role in ['primary','replay']
sys.path.insert(0,str(R/'calculations/canonical_so10_intrinsic_full_source_descent'))
from coefficient_ring import Coeff, constant, ZERO, I, coefficient, g, xi, eta
import sympy as s
tick=time.perf_counter(); timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
for p,h in json.loads((O/'module_preparation.json').read_bytes())['input_sha256'].items():
    assert sha256(Path(p).read_bytes()).hexdigest()==h,p

def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        p=Path(os.fsdecode(args[0])); peer='replay' if role=='primary' else 'primary'
        if p.parent.resolve()==O and p.name.startswith('module_'+peer):raise PermissionError('UWB2_PEER_DENIED')
        if p.parent.name=='canonical_so10_u_pair_contact_model':raise PermissionError('UWB2_QUANTUM_REMAINDER_DENIED')
sys.addaudithook(guard)

# x0:328,C328:373,a373:418,L418:463,Jx463:791,JC791:836,Ja836:881,JL881:926.
par=lambda i:int(328<=i<418 or 463<=i<791 or 881<=i<926)
dim=lambda i: 1 if i<418 or 881<=i else 2
a=Algebra(par,ZERO)
@lru_cache(None)
def parse(value):return coefficient(s.sympify(value,locals={'g10':g,'xi':xi,'eta_H':eta}))
data=load(R/('calculations/canonical_so10_remaining_u_contact_vertices/vertices_'+role+'_inputs.json.gz'))
maps=load(R/('calculations/canonical_so10_intrinsic_full_source_descent/map_'+role+'_tables.json.gz'))
operands=load(R/('calculations/canonical_so10_unprobed_source_root_module/operands_'+role+'_tables.json.gz'))
xs=data['xs']; C=['C'+str(i) for i in range(45)]
ants=[('bar' if i<12 else 'ub')+str(i) for i in range(45)]
Ls=[('b' if i<12 else 'L')+str(i) for i in range(45)]
fields=xs+C+ants+Ls; findex={n:i for i,n in enumerate(fields)}
source=lambda i:463+i if i<328 else 791+i-328 if i<373 else 836+i-373 if i<418 else 881+i-418
pairs=[(i,source(i)) for i in range(463)]
phase=lambda i:-I if 418<=i<463 or 881<=i<926 else constant(-1) if 463<=i<791 else constant(1)

def convert(i):
    return 881+i if i<45 else 836+i-45 if i<90 else 791+i-90 if i<135 else 328+i-135 if i<180 else 373+i-180 if i<225 else 418+i-225
def decode(rows):
    out={}
    for w,v in rows:a.put(out,tuple(convert(i) for i in w),parse(v))
    return a.clean(out)

fieldflow={convert(i):decode(z) for i,z in maps['field_maps']}
sourceflow={convert(i):decode(z) for i,z in maps['source_maps']}
sigma=decode(maps['Sigma_source_nonminimal_C'])
for c,mat in enumerate(operands['R']):
    for i,j,v in mat['entries']:
        value=parse(v)
        fieldflow.setdefault(i,{})
        a.put(fieldflow[i],(328+c,j),value)
        a.put(sigma,(source(i),328+c,j),value)
fieldflow={k:a.clean(z) for k,z in fieldflow.items()}
sigma=a.clean(sigma)
assert all(sum(par(i) for i in w)%2==0 for w in sigma)
print('STAGE maps '+str(time.perf_counter()-tick),flush=True)

# The original raw-to-physical field chart; no retransformation of G/QG.
rawnames=data['frame']['field_order']
phys=[f'B{i}_{mu}' for i in range(45) for mu in range(4)]+xs+Ls+C+ants
trans={}
for r,c,v in data['frame']['physical_to_raw_inverse']['entries']:
    rn,pn=rawnames[r],phys[c]
    if rn in findex:
        assert pn in findex,(rn,pn)
        assert (findex[rn]<328)==(findex[pn]<328)
        assert par(findex[rn])==par(findex[pn]) and dim(findex[rn])==dim(findex[pn])
        trans.setdefault(rn,{})[(findex[pn],)]=parse(v)
gf={}; gradient={}; gf_partition=Counter()
for row in data['GF']:
    word=row['word']; value=parse(row['coefficient'])
    if any(n not in findex for n in word):
        gf_partition['outside_constant_module']+=1; continue
    degree=4-sum(dim(findex[n]) for n in word)
    if degree not in [0,1]:gf_partition['intrinsic_outside_0_1']+=1;continue
    gf_partition['retained_raw_density']+=1
    scalar=-value
    for n in word:scalar=scalar*phase(findex[n])
    if role=='primary':
        term={():scalar}
        for n in word:term=a.mul(term,trans[n])
        gf=a.add(gf,term)
    else:
        # Differentiate raw density first. Removed-port Wick phase remains.
        for j,n in enumerate(word):
            port=findex[n]
            sg=(-1)**(par(port)*sum(par(findex[t]) for t in word[:j]))
            term={():scalar*sg}
            for k,t in enumerate(word):
                if k!=j:term=a.mul(term,trans[t])
            for (out,),v in trans[n].items():
                gradient[out]=a.add(gradient.get(out,{}),a.scale(term,v))
if role=='primary':
    # One pass over the transported density, not 90 full scans.
    for word,value in gf.items():
        for j,port in enumerate(word):
            sg=(-1)**(par(port)*sum(par(t) for t in word[:j]))
            z=gradient.setdefault(port,{})
            w=word[:j]+word[j+1:];z[w]=z.get(w,ZERO)+sg*value
gradient={k:a.clean(z) for k,z in gradient.items() if a.clean(z)}
print('STAGE GF '+str(time.perf_counter()-tick),flush=True)

if role=='primary':
    flows={**fieldflow,**sourceflow}
else:
    # Recover all relevant operation columns from Sigma, using right-to-left
    # conversion rather than the primary qualified cotangent tensor maps.
    flows={}
    for field,src in pairs:
        if field>=373:flows[src]=a.diff(sigma,field,True)
    # Even Sigma's right_source=(-1)^(p+1) left_source,
    # qfield=(-1)^p left_source => overall minus right_source.
    for field,src in pairs:flows[field]=a.scale(a.diff(sigma,src,True),-1)
for field,z in gradient.items():
    if field<373:continue
    src=source(field)
    flows[src]=a.add(flows.get(src,{}),a.scale(z,(-1)**par(field)))
flows={k:a.clean(z) for k,z in flows.items() if a.clean(z)}
assert all(sum(par(i) for i in w)%2==(par(k)+1)%2 for k,z in flows.items() for w in z)

audit=data['audit']; names=audit['names']; geo=audit['geometry']; base=geo['names']
lookup={n:findex[n] for n in fields}
for f,J,h,k in geo['field_source_h_k']:
    if base[f] in findex:lookup[base[J]]=source(findex[base[f]])
assert len(lookup)==926
source_names={names[i] for packet in audit['physical_G']+audit['physical_QG']
              for gp,tokens,ci in packet['monomials'] for i,jets in tokens if names[i].startswith('J')}
assert source_names<=set(lookup),sorted(source_names-set(lookup))

def readpoly(packet,totaldim):
    out={}; inventory=Counter()
    for gp,tokens,ci in packet['monomials']:
        if any(jets for i,jets in tokens):inventory['nonzero_jet']+=1;continue
        if any(names[i] not in lookup for i,jets in tokens):inventory['outside_constant_module']+=1;continue
        word=tuple(lookup[names[i]] for i,jets in tokens)
        nd=totaldim-sum(dim(i) for i in word)
        if nd not in [0,1]:inventory['intrinsic_outside_0_1']+=1;continue
        value=Coeff([((gp,xp,ep,mask),Fraction(num,den)) for xp,ep,mask,num,den in packet['coefficients'][ci]])
        value=-value
        for i in word:value=value*phase(i)
        a.put(out,word,value); inventory['retained_raw']+=1
    return a.clean(out),dict(inventory)

def project(poly,totaldim):
    return {w:v for w,v in poly.items() if totaldim-sum(dim(i) for i in w) in [0,1]}
def variation(poly,totaldim):
    # Stable intrinsic-degree projection before allocating the larger sum.
    out={}
    for word,value in poly.items():
        prefix=0
        for j,port in enumerate(word):
            rem=word[:j]+word[j+1:]; dr=sum(dim(i) for i in rem)
            sign=(-1)**prefix
            for w,v in flows.get(port,{}).items():
                if totaldim-dr-sum(dim(i) for i in w) in [0,1]:a.put(out,word[:j]+w+word[j+1:],sign*value*v)
            prefix+=par(port)
    return a.clean(out)
def enc(poly):return [[list(w),[[list(k),v.numerator,v.denominator] for k,v in value.terms]] for w,value in sorted(poly.items())]
def stats(poly,totaldim):
    counts=Counter((totaldim-sum(dim(i) for i in w),sum(i>=463 for i in w)) for w in poly)
    return {'nonzero':len(poly),'intrinsic_source_degree':[[list(k),v] for k,v in sorted(counts.items())],
            'witness':enc(dict(list(sorted(poly.items()))[:1]))}

qgf={}
for field,z in gradient.items():qgf=a.add(qgf,a.mul(fieldflow.get(field,{}),z))
qgf=project(qgf,5)
results=[]; tables={'qGF':enc(qgf),'gradient':[[k,enc(z)] for k,z in sorted(gradient.items())],
                    'operation':[[k,enc(z)] for k,z in sorted(flows.items())], 'probes':[]}
for probe in [0,1]:
    G,gi=readpoly(audit['physical_G'][probe],3)
    QG,qi=readpoly(audit['physical_QG'][probe],4)
    print('STAGE probe '+str(probe)+' inputs '+str((len(G),len(QG))),flush=True)
    qG=variation(G,4)
    rho_defect=a.add(QG,a.scale(qG,-1))
    print('STAGE probe '+str(probe)+' rho '+str(len(rho_defect)),flush=True)
    qQG=variation(QG,5)
    print('STAGE probe '+str(probe)+' u '+str(len(qQG)),flush=True)
    # Source2 diagonal superdivergence: epsilon-left tangent's supertrace
    # reduces to sum left_derivative_phi(q_u phi). Test complete diagonal.
    qu={}
    for field,src in pairs:
        z=a.scale(a.diff(QG,src),(-1)**par(field))
        z={w:v for w,v in z.items() if any(i>=463 for i in w)}
        if z:qu[field]=z
    divergence={}
    for field,z in qu.items():divergence=a.add(divergence,a.diff(z,field))
    assert not divergence
    tables['probes'].append({'G':enc(G),'QG':enc(QG),'rho_defect':enc(rho_defect),'u_defect':enc(qQG),
                             'source_dependent_qu':[[k,enc(z)] for k,z in sorted(qu.items())]})
    results.append({'probe':probe,'G_inventory':gi,'QG_inventory':qi,'G':stats(G,3),'QG':stats(QG,4),
                    'rho_defect_QG_minus_qG':stats(rho_defect,4),'u_defect_qQG':stats(qQG,5),
                    'source_dependent_field_flow_terms':sum(len(z) for z in qu.values()),
                    'source_dependent_formal_diagonal_trace_zero':True})
raw=(json.dumps(tables,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with (O/('module_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
out={'schema':'UWB2_ACTUAL_CONSTANT_MODULE','role':role,'probes':results,'GF_partition':dict(gf_partition),
     'qGF':stats(qgf,5),
     'gradient_terms':sum(len(z) for z in gradient.values()),'operation_terms':sum(len(z) for z in flows.values()),
     'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),
     'elapsed_after_imports':time.perf_counter()-tick,'full_momentum_master_or_quantum_claim':False}
with (O/('module_'+role+'_result.json')).open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
