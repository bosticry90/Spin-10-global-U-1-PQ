# UWB1/2: source-nonlinear Ward prerequisite

Prospective, base e182fc5a. Apply the focused result-to-claim assessment in
the existing result/review; this is not a second scientific ledger.
Question: does the regulated u calculation possess the full source/master
premise needed to interpret its cutoff trace? First derive a finite
defect-inclusive identity; then test an actual stable classical module.
This is less expensive than expanding another quantum tensor and can
expose a missing premise before it is used to explain the log5 remainder.

Inputs and ceilings are frozen in inputs.json. Current policy applies to
new work; the historical policy hashes remain historical. No quantum T/F
remainder is an operand. Ordinary source and field signs, the actual Wick
chart, original action and reference remain fixed. No finite freedom is
chosen, no source master defect is assumed zero, no blocked stage activated.

UWB1 is finite exact algebra. Fields x,z even and c,a odd have sources
of opposite parity; u even and rho odd with d=rho*d/du. Two independent
even directions preserve each field's parity. Arbitrary even source2
polynomials need NOT solve the master equation. Compare direct even
directional replacement with a finite Taylor expansion in two independent
even amplitudes. Check the polarization identity in DERIVATION.md and
require sensitive controls for missing master defect, source flow, source2
in the operation, and d. Three integer seeds are diagnostic fixtures, not
physical parameters. No amplitude truncation occurs before extraction.

UWB2 will test the actual constant-field nonminimal/scalar module, intrinsic
degrees0/1, all source degrees. Keep x,C,a,Lambda,Ja,JL; Jx,JC are source
bookkeeping differentiated before restriction. Compare density-first GF
chart transport/Euler with raw Euler-first covector transport. Compare
transported qualified field/source maps with derivatives of the actual
nonminimal source action. Report q0G-QG, q0QG and q0GF even if nonzero;
agreement of two nonzero defects is evidence of a defect, not PASS of
nilpotence. The physical action is independent of a,Lambda and therefore
does not enter these two Euler columns; it is not removed from the theory.
Module stability and intrinsic grading must be checked before a projection
is used as evidence. Arbitrary internal jets/momenta are outside this test.

Bounds: native300s, review180s after imports; 8GiB sampled private memory,
350MiB available-pagefile launch floor,32MiB packet. Capture full outputs
and failures. Freeze source copies and hashes before each new execution.
No agents or dependent parallel calculations. Shared exact ring, action,
charts, software and AI authorship limit independence. Authentication of
inherited inputs is not a fresh replay of their scientific calculations.

Acceptance: finite source2 identity plus explicitly scoped model-premise
test. A model defect is a legitimate bounded outcome. Incomplete UWB2
does not become an accepted model identity because UWB1 passed. Neither
result supplies continuum products, cyclic finite-part traces, quantum
measure/QAP, a complete T/F cancellation or E5/A5. Determine the smallest
additional derivative/momentum premise before any selected cutoff integral.
