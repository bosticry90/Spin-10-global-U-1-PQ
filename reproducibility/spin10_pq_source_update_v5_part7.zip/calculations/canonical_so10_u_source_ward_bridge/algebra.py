"""Finite supercommutative polynomials. No distributions or loop limits."""
from collections import defaultdict


class Algebra:
    def __init__(self, parity, zero=0):
        self.parity = parity
        self.zero = zero

    def canon(self, word):
        odd = [i for i in word if self.parity(i)]
        if len(odd) != len(set(odd)):
            return (), 0
        sign = (-1) ** sum(a > b for j, a in enumerate(odd) for b in odd[j + 1:])
        return tuple(sorted(word)), sign

    def put(self, out, word, value):
        word, sign = self.canon(word)
        if sign and value:
            out[word] = out.get(word, self.zero) + sign * value

    def clean(self, poly):
        return {w: v for w, v in poly.items() if v}

    def add(self, *polys):
        out = {}
        for poly in polys:
            for w, v in poly.items():
                out[w] = out.get(w, self.zero) + v
        return self.clean(out)

    def scale(self, poly, number):
        return {w: v * number for w, v in poly.items() if v * number}

    def mul(self, left, right):
        out = {}
        for w, v in left.items():
            for ww, vv in right.items():
                self.put(out, w + ww, v * vv)
        return self.clean(out)

    def diff(self, poly, index, right=False):
        out = {}
        for word, value in poly.items():
            for j, a in enumerate(word):
                if a == index:
                    side = word[j + 1:] if right else word[:j]
                    sign = (-1) ** (self.parity(index) * sum(self.parity(k) for k in side))
                    w = word[:j] + word[j + 1:]
                    out[w] = out.get(w, self.zero) + sign * value
        return self.clean(out)

    def bracket(self, left, right, pairs):
        out = {}
        for field, source in pairs:
            a = self.mul(self.diff(left, field, True), self.diff(right, source))
            b = self.mul(self.diff(left, source, True), self.diff(right, field))
            out = self.add(out, a, self.scale(b, -1))
        return out

    def vary(self, poly, flows, odd=True):
        out = {}
        for word, value in poly.items():
            prefix = 0
            for j, a in enumerate(word):
                sign = (-1) ** prefix if odd else 1
                for w, v in flows.get(a, {}).items():
                    self.put(out, word[:j] + w + word[j + 1:], sign * value * v)
                prefix += self.parity(a)
        return self.clean(out)

    def shift(self, poly, substitutions):
        out = {}
        for word, value in poly.items():
            term = {(): value}
            for a in word:
                term = self.mul(term, substitutions.get(a, {(a,): 1}))
            out = self.add(out, term)
        return out
