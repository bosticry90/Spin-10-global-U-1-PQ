# UWB1/2 review scope

Before review execution, freeze completed native captures and tables,
the review sources and the original CSW full raw-map input. Compare all
native coefficients and zeros, not only counts or digests. Establish the
constant-field restriction's actual support from all643 field-map outputs
and verify all used G/QG sources belong to the two retained nonminimal
families. Intrinsic grades0/1 form a quotient because no operation column
has negative intrinsic degree. Derivatives of excluded positive jets remain
in that ideal; B rules retain B,A or a positive jet; A is fixed.

Source projection is performed after differentiation. The scalar and
ghost sources are bookkeeping; G/QG do not depend on them. Their missing
Euler columns therefore cannot be smuggled in as an assumed zero. The
physical action has no a or Lambda dependence, hence the retained Ja/JL
Euler columns come from the actual gauge-fixing and source terms.

Review the diagonal trace independently by support: every actual positive-
source u field response lacks its own output field. Its left diagonal
derivative therefore vanishes term by term, while off-diagonal source-
dependent tangents remain. This is a formal trace component, not a measure
or quantum-equivalence theorem. Preserve all measured field responses.

UWB1 control sensitivity is finite-fixture evidence. The actual model
comparison uses distinct raw Euler/density transport and source tensor/
action derivative routes, sharing the input action, ring and AI author.
It is not external scientific validation or proof-assistant formalization.
No complete internal-momentum master identity or continuum trace-domain
extension is inferred. Review180s/8GiB/350MiB/32MiB, same frozen resource
and preservation requirements. Scientific authority remains unchanged.
