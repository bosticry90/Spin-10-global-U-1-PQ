# Defect-inclusive finite source identity

Use the actual Euclidean source chart. For a field of parity p_i the
conjugate source has parity p_i+1, and

 (F,G)_E=sum_i(F right_phi_i G left_Ji-F right_Ji G left_phi_i).

There is no extra (-1)^p_i outside this Euclidean bracket. The historical
Minkowski bracket and source chart are different presentations. For even
Sigma this gives qphi_i=(-1)^p_i Sigma_left_Ji and
qJ_i=(-1)^p_i Sigma_left_phi_i, as in the qualified ISD source transport.
With d=rho*d/du define B=(Sigma,.)_E+d and

 I_total=1/2(Sigma,Sigma)_E+dSigma=I_hat+A.

A is a retained classical master defect, not an assumed zero. Sources
can occur quadratically or more; their degree does not alter the next
finite algebra identity. Let U,V be independent even field variations
at fixed sources. Their components have the respective field parity.
Since their derivatives commute with the bracket and d,

 B(D_V D_U Sigma)=D_V D_U I_total-(D_U Sigma,D_V Sigma)_E.

The cross bracket is the polarized pair Msharp H+H M with full
source-dependent field tangent M. This gives

 B H=(I_hat+A)''-Msharp H-H M.

It is not valid to replace I_total by I_hat before A=0 is established
in the required domain. Field-only variation likewise omits necessary
source Euler terms. A source derivative precedes setting sources to zero.

At finite mode/Grassmann order, the qualified CSW Gaussian transpose
proof applies to an arbitrary even graded Hessian, not only a
source-linear action. For G_t=(H+R_t)^-1, Gamma1,t=1/2 STr log(H+R_t)
minus the prescribed reference, retain the general identity

 B Gamma1,t=1/2 STr[G_t(I_hat+A)'']-STr M
            +STr(G_t R_t M)+1/2 STr(G_t B R_t)-B Gamma_ref.

The factors are ordered G_t R_t M. The actual reference is fixed at A0
with fixed width parameters, hence its direct variation is zero there.
No co-varied regulator or new subtraction prescription is adopted. This
is finite Gaussian algebra; continuum finite parts require their own
common-domain and trace-defect hypotheses. UWB1 freshly verifies only
the preceding polynomial polarization; CSW's finite Gaussian pairing
proof is explicitly inherited rather than represented as a fresh replay.

For the even probe u with Sigma=Sigma0+rho G+u QG, set rho=0 only after
the indicated operation. Its cutoff coefficient is

 [u]STr(G_t R_t M)=STr(G_0t R_t M_u-G_0t H_u G_0t R_t M_0).

At A0, E central, this has positive-heat root coefficients

 C_n^u=(-1)^n STr[(G0 V0)^n M_u
       +sum_(j=0)^(n-1) (G0 V0)^j G0 H_u (G0 V0)^(n-1-j) M0]

multiplied by E^n-E^(n+1). Order is retained. u is even: no rho-prefix
sign can be copied into this expression. All source degrees of QG must
remain before differentiation. This expression is a calculation target,
not a measurement of its Spin(10) coefficients or an assertion that it
cancels the previously retained formal log5 terms.

For the actual module test, G_E=-Wick(G_M), QG_E=-Wick(QG_M).
The first-probe master coefficients are QG_E-q0G_E at rho and q0QG_E
at u. Report both with all source degrees. Zero in a stable constant-field
module would only qualify that projection, not the full internal-momentum
Hessian required by the loop insertion.
