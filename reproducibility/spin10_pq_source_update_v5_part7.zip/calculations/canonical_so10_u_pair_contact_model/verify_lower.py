from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import gzip
import json
import os
import sys
import threading
import time
import sympy as s

O = Path(__file__).resolve().parent
R = O.parents[1]
tick = time.perf_counter()
timer = threading.Timer(180, lambda: os._exit(124))
timer.daemon = True
timer.start()
read = lambda p: json.loads(p.read_bytes())
load = lambda p: json.loads(gzip.decompress(p.read_bytes()))
for path, digest in read(O / 'lowering_review_preparation.json')['input_sha256'].items():
    assert sha256(Path(path).read_bytes()).hexdigest() == digest, path
sys.path.insert(0, str(R / 'calculations/canonical_so10_intrinsic_full_source_descent'))
from coefficient_ring import coefficient
g, xi, eta = s.symbols('g10 xi eta_H', real=True)


@lru_cache(None)
def co(value):
    return coefficient(s.expand(s.sympify(value, locals={'g10': g, 'xi': xi, 'eta_H': eta})))


def plus(*terms):
    result = defaultdict(lambda: 0)
    for values, factor in terms:
        for key, value in values.items():
            result[key] += factor * value
    return {key: value for key, value in result.items() if value}


tab = lambda rows: {tuple(row[:-1]): co(row[-1]) for row in rows}
encode = lambda values: [[*key, str(value)] for key, value in sorted(values.items())]
primary, replay = [load(O / ('lower_' + role + '_tables.json.gz')) for role in ['primary', 'replay']]
assert primary['N_S_entries'] == replay['N_S_entries'] == [296, 6268]
assert primary['nonzero_literal_sign_fixtures'] and replay['nonzero_literal_sign_fixtures']
assert primary['qualified_u_Ja_Ja_contact_zero_authenticated'] and replay['qualified_u_Ja_Ja_contact_zero_authenticated']
all_bases = []
summary = []
for probe in range(2):
    p, r = primary['results'][probe], replay['results'][probe]
    heat = {}
    for edge in ['2', '3', '4', '5']:
        heat[edge] = {name: tab(rows) for name, rows in p['heat_images'][edge].items()}
        assert heat[edge] == {name: tab(rows) for name, rows in r['heat_images'][edge].items()}
        assert heat[edge]['F'] == plus((heat[edge]['KS_F'], 1), (heat[edge]['TN_F'], 1))
        assert all(0 <= a < 45 and 0 <= h < 45 and 0 <= i < 328 for a, h, i in heat[edge]['KN_T'])
        for name in ['KS_F', 'TN_F', 'F']:
            assert all(0 <= source < 45 and 0 <= c < d < 45 and 0 <= i < 328 for source, c, d, i in heat[edge][name])
    relative = {}
    for basis, weights in [('chi4', {'2': 1, '3': 1, '4': 1, '5': 1}),
                           ('log2', {'3': -1, '4': 1, '5': -1}), ('log3', {'3': 1}), ('log5', {'5': 1})]:
        image = {target: plus(*[(heat[edge][name], weight) for edge, weight in weights.items()])
                 for target, name in [('T', 'KN_T'), ('F', 'F')]}
        assert image == {target: tab(rows) for target, rows in p['relative_images'][basis].items()}
        assert image == {target: tab(rows) for target, rows in r['relative_images'][basis].items()}
        relative[basis] = image
    # Late comparison occurs only after complete agreement of the measured images.
    partial = []
    for basis, image in relative.items():
        old_path = R / ('calculations/canonical_so10_intrinsic_full_source_descent/variation_v3_' + basis + '_primary_tables.json.gz')
        old = load(old_path)['results'][probe]['formal_basis'][0]['nonminimal']
        ordinary = {'T': {(source, word[0], i): co(value) for source, word, i, value in old['T']},
                    'F': {(source, word[0], word[1], i): co(value) for source, word, i, value in old['F']}}
        combined = {target: plus((ordinary[target], 1), (image[target], 1)) for target in ['T', 'F']}
        partial.append({'basis': basis, 'homogeneous_counts': {target: len(value) for target, value in ordinary.items()},
                        'Euler_counts': {target: len(value) for target, value in image.items()},
                        'partial_counts': {target: len(value) for target, value in combined.items()},
                        'homogeneous_plus_Euler_partial': {target: encode(value) for target, value in combined.items()},
                        'Bu_C0_and_applicability_missing_not_zero': True})
        print('STAGE UPM4', probe, basis, 'partial', {target: len(value) for target, value in combined.items()}, flush=True)
    all_bases.append({'probe': probe, 'partial_relations': partial})
    summary.append({'probe': probe, 'heat_images': {edge: {name: len(value) for name, value in groups.items()} for edge, groups in heat.items()},
                    'relative_and_partial_counts': [{key: value for key, value in row.items() if key != 'homogeneous_plus_Euler_partial'} for row in partial]})
for role in ['primary', 'replay']:
    record = read(O / ('lower_' + role + '_result.json'))
    raw = (O / ('lower_' + role + '_tables.json.gz')).read_bytes()
    assert sha256(raw).hexdigest() == record['packed_sha256']
    assert sha256(gzip.decompress(raw)).hexdigest() == record['raw_sha256']
sources = list(O.glob('*.source.txt'))
for source in sources:
    assert source.read_bytes() == source.with_name(source.name[:-11]).read_bytes(), source
for name in ['pair_primary', 'pair_replay', 'review', 'lower_primary', 'lower_replay']:
    cap = read(O / (name + '_capture.json'))
    assert cap['execution_state'] == 'COMPLETED' and cap['exit_code'] == 0
    assert cap['calculation_completed'] and cap['post_run_observations_qualified']
    assert cap['launch']['memory']['available_pagefile'] >= 350 * 1024 ** 2
    assert max(row['private_bytes'] for row in cap['all_resource_samples']) <= 8 * 1024 ** 3
out = {'schema': 'UPM4_PARTIAL_T_F_AFTER_COMPLETE_U_CONTACT_EULER_IMAGE', 'results': all_bases,
       'complete_full_quantum_T_F_restoration_or_anomaly': False}
raw = (json.dumps(out, sort_keys=True, separators=(',', ':')) + '\n').encode()
blob = gzip.compress(raw, mtime=0)
with (O / 'partial_TF_tables.json.gz').open('xb') as stream:
    stream.write(blob)
result = {'elapsed_after_imports': time.perf_counter() - tick,
          'full_component_vs_literal_Leibniz_images_and_zero_complements_agree': True,
          'N_S_and_zero_Q_authenticated': True, 'source_copies_equal': len(sources),
          'summaries': summary, 'partial_packed_sha256': sha256(blob).hexdigest(),
          'partial_raw_sha256': sha256(raw).hexdigest(),
          'complete_T_F_QAP_or_E5_claim': False, 'missing_Bu_C0_not_assigned_zero': True}
with (O / 'lowering_validation_receipt.json').open('xb') as stream:
    stream.write((json.dumps(result, sort_keys=True, separators=(',', ':')) + '\n').encode())
print('RESULT ' + json.dumps({key: value for key, value in result.items() if key != 'summaries'}, sort_keys=True), flush=True)
timer.cancel()
