# UPM5: final custody, execution and claim review

Prospective after UPM4. Authenticate all input preparations and source
copies, completed native/review captures, result packed/raw hashes,
literal Hessian controls, complete Euler-image comparison and preserved
partial T/F output. Confirm all declared resource limits and unchanged
project_state bytes. The external final reviewer records the exact script
and complete output; it does not repeat qualified tensor calculations.

Run the existing delegated E4 authentication once, expected native0 and
step exits[0,0,0,0,0,2]. Custody stays exit2/seven unresolved, never PASS.
This is the declared bounded audit scope, not fresh global scientific
replay or scientific acceptance of the current new tensor.

Assess the resulting claim at its proper level: all five identified
marginal contact types are now measured, and the full u quadratic-source
Euler image is available in the declared intrinsic projections. Actual
B_u C0/application roots are not included in the partial T/F sum. No
completed T/F identity, anomaly, full QAP, physical model validation or
authority promotion follows. Record next the actual source-filtration
inventory of those missing roots using G/QG, before measuring only the
indispensable unprobed coefficients. No fit to the partial remainder.

No old source, input, receipt, failed run, contract or hash is changed.
Keep final review under180s apart from the separate bounded E4 command,
8GiB sampled private,350MiB launch floor,32MiBpacket. Preserve any failure
and version its correction. No branch/worktree, push, publication,
outreach, protected-stage activation or foundational adoption.
