# UPM2: complete comparison and original-Hessian review

Prospective after both UPM1 natives completed, before review execution.
Compare all six exact group tensors, all heat/relative bases and their
implicit zero complements on the980100 canonical positions per probe.
Check sorted-pair bounds and separate antisymmetric ordered extension,
including its zero diagonals. No Ward remainder is a comparator.

Select the lexicographic minimum/maximum of each nonzero heat tensor and
the fixed quadruple(12,13,14,15), removing duplicates. These selections
are verification witnesses, not independent observations. For each probe,
derive a literal180-coordinate Hessian from the original source/current
terms plus raw actual ordinary GF and u vertices, without calling the
six-group reduction. Retain five logarithm orders, both q orientations,
external Grassmann word ordering and the u first-order coefficient.
Compare every heat degree with the corresponding complete native tensor.

At q+, also remove the aa block, CC block, source-W block and u quadratic
block separately. Record each changed heat. Credit only sensitive
controls; a model zero or insensitive projection is not a detector.
Source/ghost pair exchanges must reverse the literal result. The generic
pair-diagonal normalization is inherited, with an actual diagonal check
where performed. Do not infer full quantum identity closure from this.

Review180s afterimports/8GiB sampled/350MiB launch floor/32MiBpacket.
Sources/copies and all output/hash inputs frozen before review. Preserve
any failed attempt with a new version for a correction. Source hypotheses,
ring, charts and AI authorship remain shared. No external validation,
new action, normalization choice or scientific promotion.
