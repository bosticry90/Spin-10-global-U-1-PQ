from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import gzip
import json
import os
import sys
import threading
import time
import sympy as s

O = Path(__file__).resolve().parent
R = O.parents[1]
role = sys.argv[1]
assert role in ['primary', 'replay']
tick = time.perf_counter()
timer = threading.Timer(300, lambda: os._exit(124))
timer.daemon = True
timer.start()
read = lambda p: json.loads(p.read_bytes())
load = lambda p: json.loads(gzip.decompress(p.read_bytes()))
for path, digest in read(O / 'preparation.json')['input_sha256'].items():
    assert sha256(Path(path).read_bytes()).hexdigest() == digest, path


def guard(event, args):
    if event == 'open' and args and isinstance(args[0], (str, bytes)):
        p = Path(os.fsdecode(args[0]))
        peer = 'replay' if role == 'primary' else 'primary'
        if p.parent.resolve() == O and p.name.startswith('pair_' + peer):
            raise PermissionError('UPM1_PEER_OUTPUT_DENIED')
        if p.parent.name in ['canonical_so10_intrinsic_full_source_descent', 'canonical_so10_intrinsic_correlated_source_contacts'] and p.name.startswith(('variation', 'partial_H', 'lowering', 'contact_color')):
            raise PermissionError('UPM1_QUANTUM_TARGET_DENIED')


sys.addaudithook(guard)
sys.path.insert(0, str(R / 'calculations/canonical_so10_intrinsic_full_source_descent'))
from coefficient_ring import coefficient, constant
g, xi, eta = s.symbols('g10 xi eta_H', real=True)


@lru_cache(None)
def co(value):
    return coefficient(s.expand(s.sympify(value, locals={'g10': g, 'xi': xi, 'eta_H': eta})))


def clean(values):
    return {key: value for key, value in values.items() if value}


def plus(*terms):
    result = defaultdict(lambda: 0)
    for values, factor in terms:
        for key, value in values.items():
            result[key] += factor * value
    return clean(result)


def pmul(first, second):
    result = defaultdict(lambda: 0)
    for ext, value in first.items():
        for other, coefficient in second.items():
            word = ext + other
            assert len(word) <= 2
            if len(set(word)) < len(word):
                continue
            sign = -1 if len(word) == 2 and word[0] > word[1] else 1
            result[tuple(sorted(word))] += sign * value * coefficient
    return clean(result)


def mm(first, second):
    rows = defaultdict(list)
    for (i, j), value in second.items():
        rows[i].append((j, value))
    result = {}
    for (i, k), value in first.items():
        for j, other in rows[k]:
            result[i, j] = plus((result.get((i, j), {}), 1), (pmul(value, other), 1))
    return clean(result)


def matrix_add(*terms):
    result = {}
    for values, factor in terms:
        for key, value in values.items():
            result[key] = plus((result.get(key, {}), 1), (value, factor))
    return clean(result)


def insert(matrix, i, j, ext, value):
    if value:
        assert tuple(sorted(ext)) == ext and len(set(ext)) == len(ext)
        matrix[i, j] = plus((matrix.get((i, j), {}), 1), ({ext: value}, 1))


def decoded(matrix, q=1):
    return {(i, j): {(): co(value) * (q if (i < 45 <= j or j < 45 <= i) else 1)}
            for i, j, value in matrix['entries']}


def boson(i):
    if i < 180:
        return i // 4 if i % 4 == 3 else None
    return 45 + i - 180 if i < 225 else None


def fermion(i):
    return i - 225 if 225 <= i < 315 else None


def external(i):
    if 315 <= i < 360:
        return i - 315
    if 225 <= i < 270:
        return 45 + i - 225
    return None


def u_blocks(rows):
    ku, bu, cu, fu = {}, {}, {}, {}
    for i, j, ext, value in rows:
        mapped = [external(n) for n in ext]
        if any(n is None for n in mapped):
            continue
        e = tuple(mapped)
        b, d, a, c = boson(i), boson(j), fermion(i), fermion(j)
        value = co(value)
        if not e and b is not None and d is not None:
            insert(ku, b, d, e, value)
        elif len(e) == 1 and b is not None and c is not None:
            insert(bu, b, c, e, value)
        elif len(e) == 1 and a is not None and d is not None:
            insert(cu, a, d, e, value)
        elif len(e) == 2 and a is not None and c is not None:
            insert(fu, a, c, e, value)
    return ku, bu, cu, fu


def q_check(positive, negative):
    for first, second, left_boson, right_boson in zip(positive, negative,
            [True, True, False, False], [True, False, True, False]):
        expected = {}
        for (i, j), poly in first.items():
            sign = (-1 if left_boson and i < 45 else 1) * (-1 if right_boson and j < 45 else 1)
            expected[i, j] = {ext: sign * value for ext, value in poly.items()}
        assert expected == second, 'UPM1_FULL_Q_SIGN_EQUIVALENCE_FAILED'


def gleft(matrix):
    if role == 'primary':
        return {(i - 45 if i >= 45 else i + 45, j):
                {ext: (1 if i >= 45 else -1) * value for ext, value in poly.items()}
                for (i, j), poly in matrix.items()}
    gf = {}
    for c in range(45):
        insert(gf, c, 45 + c, (), constant(1))
        insert(gf, 45 + c, c, (), constant(-1))
    return mm(gf, matrix)


def projection(first, second):
    word = first + second
    if len(set(word)) != 4 or sum(n < 45 for n in word) != 2:
        return None
    if role == 'primary':
        sign = (-1) ** sum(i > j for i in first for j in second)
        ordered = sorted(word)
        return tuple(ordered[:2] + [n - 45 for n in ordered[2:]]), sign
    if first[1] < 45:
        return (first[0], first[1], second[0] - 45, second[1] - 45), 1
    if first[0] >= 45:
        return (second[0], second[1], first[0] - 45, first[1] - 45), 1
    r, h, ss, k = first[0], first[1] - 45, second[0], second[1] - 45
    sign = -(1 if r < ss else -1) * (1 if h < k else -1)
    return (min(r, ss), max(r, ss), min(h, k), max(h, k)), sign


def contract(first, second):
    if role == 'replay':
        first, second = second, first
    result = defaultdict(lambda: 0)
    for (i, j), poly in first.items():
        partner = second.get((j, i), {})
        for ext, value in poly.items():
            for other, coefficient in partner.items():
                mapped = projection(ext, other)
                if mapped is not None:
                    key, sign = mapped
                    result[key] += sign * value * coefficient
    half = constant('1/2')
    return {key: half * value for key, value in result.items() if value}


d = load(O / ('model_' + role + '_inputs.json.gz'))
G = decoded(d['G0'])
b0, c0, f0 = {}, {}, {}
for h, matrix in enumerate(d['J0']):
    for a, b, value in matrix['entries']:
        value = co(value)
        insert(c0, 45 + a, b, (45 + h,), value)
        insert(b0, b, 45 + a, (45 + h,), value if b < 45 else -value)
for r, b, c, value in d['W']:
    value = co(value)
    insert(b0, b, c, (r,), value)
    insert(c0, c, b, (r,), -value)
for r, h, a, c, value in d['Z0']:
    value = co(value)
    insert(f0, 45 + a, c, (r, 45 + h), value)
    insert(f0, c, 45 + a, (r, 45 + h), -value)
for i, j, ext, value in d['ordinary_pair']:
    insert(f0, fermion(i), fermion(j), tuple(external(n) for n in ext), co(value))
A = gleft(f0)
if role == 'primary':
    cG = mm(c0, G)
    B = matrix_add((gleft(mm(cG, b0)), -1))
else:
    gb = mm(G, b0)
    gc = gleft(c0)
    B = matrix_add((mm(gc, gb), -1))
results = []
for probe in range(2):
    positive = u_blocks(d['u_plus'][probe])
    negative = u_blocks(d['u_minus'][probe])
    q_check(positive, negative)
    Ku, bu, cu, fu = positive
    C = gleft(fu)
    if role == 'primary':
        D = matrix_add((gleft(mm(mm(cu, G), b0)), -1), (gleft(mm(cG, bu)), -1))
        H = gleft(mm(mm(mm(cG, Ku), G), b0))
    else:
        D = matrix_add((mm(gleft(cu), gb), -1), (mm(gc, mm(G, bu)), -1))
        H = mm(mm(gc, G), mm(Ku, gb))
    print('STAGE UPM1', role, probe, 'effective_entries',
          [sum(len(poly) for poly in matrix.values()) for matrix in [A, B, C, D, H]], flush=True)
    groups = {name: contract(left, right) for name, left, right in
              [('AC', A, C), ('AD', A, D), ('BC', B, C), ('AH', A, H), ('BD', B, D), ('BH', B, H)]}
    heat = {2: groups['AC'], 3: plus((groups['AD'], 1), (groups['BC'], 1)),
            4: plus((groups['AH'], 1), (groups['BD'], 1)), 5: groups['BH']}
    pole = plus(*[(value, 1) for value in heat.values()])
    relative = {'chi4': pole, 'log2': plus((heat[4], 1), (heat[3], -1), (heat[5], -1)),
                'log3': heat[3], 'log5': heat[5], 'fixed': {}}
    for values in list(groups.values()) + list(heat.values()) + list(relative.values()):
        assert all(0 <= r < ss < 45 and 0 <= h < k < 45 for r, ss, h, k in values)
    powers = sorted({key[:3] for values in heat.values() for value in values.values() for key, number in value.terms})
    encode = lambda values: [[*key, str(value)] for key, value in sorted(values.items())]
    results.append({'probe': probe, 'groups': {name: encode(value) for name, value in groups.items()},
                    'heat': {str(edge): encode(value) for edge, value in heat.items()},
                    'relative': {name: encode(value) for name, value in relative.items()},
                    'parameter_powers': powers, 'all_u_blocks_q_sign_equivalent': True})
    print('STAGE UPM1', role, probe, 'heat_pole', [len(heat[m]) for m in [2, 3, 4, 5]] + [len(pole)], flush=True)
out = {'schema': 'UPM1_COMPLETE_U_JL_JL_CC_MODEL_CONTACT', 'role': role, 'results': results,
       'canonical_positions_per_tensor': 980100, 'ordered_positions_per_tensor': 4100625,
       'density': '(u/4) JL_r JL_s C_h C_k T_rshk; sorted pair coefficient is T',
       'normalization': 'hbar/(16pi^2)', 'whole_source_identity_QAP_E5_or_physical_promotion': False}
raw = (json.dumps(out, sort_keys=True, separators=(',', ':')) + '\n').encode()
blob = gzip.compress(raw, mtime=0)
with (O / ('pair_' + role + '_tables.json.gz')).open('xb') as stream:
    stream.write(blob)
print('RESULT ' + json.dumps({'elapsed_after_imports': time.perf_counter() - tick,
      'packed_sha256': sha256(blob).hexdigest(), 'raw_sha256': sha256(raw).hexdigest(),
      'heat_pole_counts': [[len(row['heat'][str(m)]) for m in [2, 3, 4, 5]] + [len(row['relative']['chi4'])] for row in results],
      'group_counts': [{name: len(value) for name, value in row['groups'].items()} for row in results],
      'T_F_QAP_E5_or_physical_promotion': False}, sort_keys=True), flush=True)
timer.cancel()
