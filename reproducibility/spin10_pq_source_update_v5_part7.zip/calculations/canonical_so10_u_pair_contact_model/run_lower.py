from pathlib import Path
from hashlib import sha256
import ast
import json
import sys
import traceback

O = Path(__file__).resolve().parent
R = O.parents[1]
C = Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-pair-contact-model-v1-2026-10-26')
sys.path.insert(0, str(R / 'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H = lambda p: sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_bytes())


def dump(path, value):
    with path.open('xb') as stream:
        stream.write((json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode())


try:
    assert read(O / 'validation_receipt.json')['complete_groups_heat_relative_and_zero_complements_agree']
    bindings = dict(read(O / 'review_preparation.json')['input_sha256'])
    for path, digest in bindings.items():
        assert H(Path(path)) == digest, path
    for role in ['primary', 'replay']:
        for stem in ['calculations/canonical_so10_intrinsic_auxiliary_ghost_source/vertex_' + role + '_inputs.json.gz',
                     'calculations/canonical_so10_intrinsic_quadratic_source_contacts/color_' + role + '_tables.json.gz',
                     'calculations/canonical_so10_remaining_u_contact_vertices/k_model_' + role + '_tables.json.gz']:
            bindings[str(R / stem)] = H(R / stem)
    for name in ['LOWERING_RECORD.md', 'lower.py', 'run_lower.py']:
        path = O / name
        if path.suffix == '.py':
            ast.parse(path.read_bytes())
        with (O / (name + '.source.txt')).open('xb') as stream:
            stream.write(path.read_bytes())
    for path in O.iterdir():
        if path.is_file():
            bindings[str(path)] = H(path)
    dump(O / 'lowering_preparation.json', {'input_sha256': bindings, 'scientific_acceptance': 'NOT_PERFORMED'})
    for role in ['primary', 'replay']:
        result = capture([sys.executable, '-B', str(O / 'lower.py'), role])
        dump(O / ('lower_' + role + '_capture.json'), result)
        dump(C / ('lower_' + role + '_full_capture.json'), result)
        assert result['exit_code'] == 0 and result['execution_state'] == 'COMPLETED'
        assert result['calculation_completed'] and result['post_run_observations_qualified']
        assert result['launch']['memory']['available_pagefile'] >= 350 * 1024 ** 2
        assert max(row['private_bytes'] for row in result['all_resource_samples']) <= 8 * 1024 ** 3
        rows = [json.loads(line[7:]) for line in result['stdout_and_stderr'].splitlines() if line.startswith('RESULT ')]
        assert len(rows) == 1 and rows[0]['elapsed_after_imports'] < 300
        dump(O / ('lower_' + role + '_result.json'), rows[0])
        assert sum(p.stat().st_size for p in O.iterdir() if p.is_file()) < 32 * 1024 ** 2
        print('COMPLETED UPM3', role, json.dumps(rows[0], sort_keys=True), flush=True)
except BaseException:
    dump(O / 'lowering_controller_failure.json', {'execution_state': 'FAILED', 'traceback': traceback.format_exc(), 'failure_relabelled_PASS': False})
    raise
