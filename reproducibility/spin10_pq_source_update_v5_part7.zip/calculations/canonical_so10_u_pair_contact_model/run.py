from pathlib import Path
from hashlib import sha256
import ast
import gzip
import json
import sys
import traceback

O = Path(__file__).resolve().parent
R = O.parents[1]
C = Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-pair-contact-model-v1-2026-10-26')
sys.path.insert(0, str(R / 'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H = lambda p: sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_bytes())
load = lambda p: json.loads(gzip.decompress(p.read_bytes()))


def dump(path, value):
    with path.open('xb') as stream:
        stream.write((json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode())


try:
    inputs = read(O / 'inputs.json')
    bindings = {str(R / p): value for p, value in inputs['input_sha256'].items()}
    for path, digest in bindings.items():
        assert H(Path(path)) == digest, path
    assert read(R / 'calculations/canonical_so10_u_pair_contact_reduction/validation_receipt.json')['all_12_prior_paired_Hessian_and_Schur_fixtures_exact']
    parent = R / 'calculations/canonical_so10_remaining_u_contact_vertices'
    for role in ['primary', 'replay']:
        classical = load(parent / ('k_model_' + role + '_inputs.json.gz'))
        vertices = load(parent / ('vertices_' + role + '_tables.json.gz'))
        plus = next(row['groups'] for row in vertices['Fourier_unit_axes'] if row['axis'] == 3 and row['q'] == 1)
        minus = next(row['groups'] for row in vertices['Fourier_unit_axes'] if row['axis'] == 3 and row['q'] == -1)
        data = {key: classical[key] for key in ['G0', 'J0', 'W', 'Z0']}
        data.update({'ordinary_pair': plus['GFquartic'], 'u_plus': [plus['u0'], plus['u1']],
                     'u_minus': [minus['u0'], minus['u1']]})
        assert plus['GFquartic'] == minus['GFquartic']
        path = O / ('model_' + role + '_inputs.json.gz')
        with path.open('xb') as stream:
            stream.write(gzip.compress((json.dumps(data, sort_keys=True, separators=(',', ':')) + '\n').encode(), mtime=0))
        bindings[str(path)] = H(path)
    for name in ['RECORD.md', 'model.py', 'run.py', 'inputs.json', '.gitattributes']:
        path = O / name
        if path.suffix == '.py':
            ast.parse(path.read_bytes())
        with (O / (name + '.source.txt')).open('xb') as stream:
            stream.write(path.read_bytes())
        bindings[str(path)] = H(path)
    dump(O / 'preparation.json', {'input_sha256': bindings, 'scientific_acceptance': 'NOT_PERFORMED'})
    for role in ['primary', 'replay']:
        result = capture([sys.executable, '-B', str(O / 'model.py'), role])
        dump(O / ('pair_' + role + '_capture.json'), result)
        dump(C / ('pair_' + role + '_full_capture.json'), result)
        assert result['exit_code'] == 0 and result['execution_state'] == 'COMPLETED'
        assert result['calculation_completed'] and result['post_run_observations_qualified']
        assert result['launch']['memory']['available_pagefile'] >= 350 * 1024 ** 2
        assert max(row['private_bytes'] for row in result['all_resource_samples']) <= 8 * 1024 ** 3
        rows = [json.loads(line[7:]) for line in result['stdout_and_stderr'].splitlines() if line.startswith('RESULT ')]
        assert len(rows) == 1 and rows[0]['elapsed_after_imports'] < 300
        dump(O / ('pair_' + role + '_result.json'), rows[0])
        assert sum(p.stat().st_size for p in O.iterdir() if p.is_file()) < 32 * 1024 ** 2
        print('COMPLETED UPM1', role, json.dumps(rows[0], sort_keys=True), flush=True)
except BaseException:
    dump(O / 'controller_failure.json', {'execution_state': 'FAILED', 'traceback': traceback.format_exc(), 'failure_relabelled_PASS': False})
    raise
