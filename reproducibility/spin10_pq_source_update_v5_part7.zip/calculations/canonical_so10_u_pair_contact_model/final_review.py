from pathlib import Path
from hashlib import sha256
import gzip
import json
import time

O = Path(__file__).resolve().parent
C = Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-pair-contact-model-v1-2026-10-26')
read = lambda path: json.loads(path.read_bytes())
tick = time.perf_counter()
prep = read(O / 'final_preparation.json')
for path, digest in prep['input_sha256'].items():
    assert sha256(Path(path).read_bytes()).hexdigest() == digest, path
bindings = 0
for name in ['preparation', 'review_preparation', 'lowering_preparation', 'lowering_review_preparation']:
    for path, digest in read(O / (name + '.json'))['input_sha256'].items():
        assert sha256(Path(path).read_bytes()).hexdigest() == digest, path
        bindings += 1
sources = list(O.glob('*.source.txt'))
for source in sources:
    assert source.read_bytes() == source.with_name(source.name[:-11]).read_bytes(), source
peak = 0
for stem in ['pair_primary', 'pair_replay', 'review', 'lower_primary', 'lower_replay', 'lowering_review']:
    capture = read(O / (stem + '_capture.json'))
    assert capture['exit_code'] == 0 and capture['execution_state'] == 'COMPLETED'
    assert capture['calculation_completed'] and capture['post_run_observations_qualified']
    assert capture['launch']['memory']['available_pagefile'] >= 350 * 1024 ** 2
    peak = max(peak, max(row['private_bytes'] for row in capture['all_resource_samples']))
    assert (O / (stem + '_capture.json')).read_bytes() == (C / (stem + '_full_capture.json')).read_bytes()
assert peak <= 8 * 1024 ** 3
for stem in ['pair_primary', 'pair_replay', 'lower_primary', 'lower_replay']:
    result = read(O / (stem + '_result.json'))
    raw = (O / (stem + '_tables.json.gz')).read_bytes()
    assert sha256(raw).hexdigest() == result['packed_sha256']
    assert sha256(gzip.decompress(raw)).hexdigest() == result['raw_sha256']
image = read(O / 'lowering_validation_receipt.json')
raw = (O / 'partial_TF_tables.json.gz').read_bytes()
assert sha256(raw).hexdigest() == image['partial_packed_sha256']
assert sha256(gzip.decompress(raw)).hexdigest() == image['partial_raw_sha256']
assert image['full_component_vs_literal_Leibniz_images_and_zero_complements_agree']
assert image['missing_Bu_C0_not_assigned_zero'] and not image['complete_T_F_QAP_or_E5_claim']
contact = read(O / 'validation_receipt.json')
assert contact['complete_groups_heat_relative_and_zero_complements_agree']
assert len(contact['literal180_both_q']) == 10 and len(contact['literal_pair_exchange']) == 4
sensitive = {name: sorted({edge for row in contact['literal_omission_controls'] if row['probe'] == 1 and row['control'] == name for edge in row['changed_heat']}) for name in ['aa', 'CC', 'W', 'Ku']}
assert sensitive == {'aa': [2], 'CC': [2, 3], 'W': [5], 'Ku': [5]}
e4 = read(C / 'e4_full_capture.json')
events = [json.loads(line) for line in e4['stdout'].splitlines() if line.startswith('{')]
steps = [row['exit_code'] for row in events if row.get('event') == 'step_finished']
assert e4['exit_code'] == 0 and steps == [0, 0, 0, 0, 0, 2]
assert [row for row in events if row.get('event') == 'terminal'][0]['execution_state'] == 'COMPLETED'
assert sum(path.stat().st_size for path in O.iterdir() if path.is_file()) < 32 * 1024 ** 2
result = {'elapsed_after_imports': time.perf_counter() - tick, 'preparation_bindings_authenticated': bindings,
          'source_copies_equal': len(sources), 'six_completed_native_review_captures': True,
          'largest_sampled_private_bytes': peak, 'literal_sensitive_controls': sensitive,
          'E4_step_exits': steps, 'historical_custody': 'EXIT2_SEVEN_UNRESOLVED_NOTPASS',
          'all_five_contact_types_measured_within_declared_inventory': True,
          'u_contact_Euler_image_compared_with_literal_Leibniz': True,
          'partial_T_F_missing_Bu_C0_preserved': True,
          'whole_quantum_identity_QAP_E5_or_physical_promotion': False}
with (O / 'final_review_validation_receipt.json').open('xb') as stream:
    stream.write((json.dumps(result, sort_keys=True, separators=(',', ':')) + '\n').encode())
print('RESULT ' + json.dumps(result, sort_keys=True), flush=True)
