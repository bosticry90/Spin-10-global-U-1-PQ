# UPM3: complete u quadratic-source Euler image

Prospective after UPM2 qualified. The last two contact tensors now exist;
calculate their actual intrinsic source-free Euler images. This closes a
missing assembly input rather than asserting T/F restoration. The third
u contact, (u/2)Ja Q Ja, is already qualified zero in IQC, including Q's
even-source Hessian normalization. Authenticate its complete zero table.

Use the actual qualified classical arrays N_ri=(E_Lambda)_ri and
S_sci=(E_a)_sci from the IAG vertex inputs:296 and6268 nonzeros.
The Wick/cotangent derivation gives qJL|J0=Nx and qJa|J0=-SCx.
The source-lowering operation differentiates before restriction. qC,qx
and d(u)=rho retain two sources and are outside this single-source image.

For K_srh in uJa_s JL_r C_h and canonical T_rshk in uJL_rJL_sC_hC_k,
r<s,h<k, the required images are

 T_from_KN[s,h,i] = sum_r K_srh N_ri,
 F_from_KS[r,c,d,i] = sum_s(S_sci K_srd - S_sdi K_src), c<d,
 F_from_TN[s,h,k,i] += T_rshk N_ri,
 F_from_TN[r,h,k,i] -= T_rshk N_si.

Thus full u-contact Euler T is KN (the qualified Q contribution is zero),
and F is KS+TN. Canonical T has664200 positions; canonical F has14612400.
The ordered F array follows by ghost-pair antisymmetry, not an extra half.
A nonzero literal graded fixture must fix the signs before model use.

Primary component sums versus replay literal ordered-word odd Leibniz
derivation must agree on all three image groups,heat2..5,formal relative
bases and zero complements,using independently qualified role inputs.
Keep intrinsic x coordinate transport already bound by IAG/ICR; do not
reapply a raw chart. No native may read a desired ISD T/F output.

Only after both images agree may review compare their sum with the old
ISD homogeneous T/F in each chi4/log2/log3/log5 basis. Any resulting sum
remains PARTIAL: actual B_u C0 and applicability obligations have not been
proved absent or included. Preserve its nonzero coefficients. Do not fit
or set missing roots to zero,choose finite normalization or call a partial
remainder an anomaly. A zero partial sum also would not prove full closure.

Native300s/role,review180s,8GiB sampled,350MiB launch floor,32MiBpacket.
Freeze source copies and inputs before computation; preserve failures.
Distinct coefficient routes share action,charts,ring/software and AI
authorship. No new physical action,scheme,authority or protected-stage
activation. Next use actual G/QG source filtration to identify the needed
unprobed u-operation roots before any full relative T/F conclusion.
