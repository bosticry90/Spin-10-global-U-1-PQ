# UPM1: complete model source-pair contact

Prospective at b1d81a7d after the UPR six-group reduction qualified.
Question: what is the complete actual `u JL JL CC` proper-loop coefficient,
and can independent contractions corroborate it before source lowering?
The missing model input is an explicit dependency of subsequent T/F work.
Existing support and generic kernels cannot determine its coefficients.
Use existing exact arithmetic and sparse matrices; minimum new surface
is this bounded calculation and its review, not a new research platform.

Types:90 boson coordinates (45 pinned B,45 Lambda),90 doubled ghosts
(45 C,45 a),45 odd JL directions and45 odd external C directions.
Canonical source pairs r<s and ghost pairs h<k have980100 positions;
the ordered45^4 tensor is recovered by separate antisymmetry, with zero
diagonals. The coefficient of the sorted exterior word equals T in
`(u/4) JL_r JL_s C_h C_k T_rshk`; no additional half beyond UPR.

Keep original SMA/CSW/EDS,A0,zero external jets,marginal intrinsic0,
both constant probes,symbolic g10/xi/eta_H and the nonexceptional
Euclidean LOCAL RELATIVE domain. Retain all original aa/CC/source pair
blocks. No model zero, finite constant or desired Ward remainder is an
input. Source-only/one-port classical terms remain outside proper loops
in their existing records, not deleted from the action.

Inputs are the two actual UCV Fourier tables, qualified classical RSH
G0/J0/W/Z0 projections and existing vertex/Gaussian/reduction receipts.
Curate each role separately, retaining both q signs. For the complete
u blocks verify the q reversal by Tb=diag(-1 on B,+1 on Lambda):
Ku(-)=Tb Ku(+) Tb, Bu(-)=Tb Bu(+), Cu(-)=Cu(+) Tb, Fu(-)=Fu(+).
The inherited base G/J/W/Z have the same transformation, so every
effective ghost factor is q-even. If this full input check fails, no
single-q full contraction is authorized. Selected literal logs retain
both q orientations regardless.

Primary forms A/B/C/D/H by left-associated sparse paths and contracts
their six trace groups with literal exterior inversion signs. Replay
uses the independently derived classical input, different matrix
associations, explicit Gf multiplication, reversed trace association
and typed JJ/CC/JC antisymmetrization. Compare complete groups, heat2..5,
pole and implicit zero complement. Methods still share the qualified
reduction, action, input assumptions, coefficient ring, Python/SymPy and
AI authorship; this is not independent physical validation.

Heat2=AC,heat3=AD+BC,heat4=AH+BD,heat5=BH. With the already qualified
zero dimensional jet, the normalized radial difference is
integral_0^infinity (exp(-2s)-exp(-ms))/s ds=log(m/2), as its derivative
is1/m and value at m=2 is zero. Thus relative bases are chi4=sum heat,
log2=heat4-heat3-heat5,log3=heat3,log5=heat5,fixed=0. This is the same
formal local-relative prescription, not a physical scaleless integral
or a choice of chi4,b0,kappa or infrared normalization.

Freeze sources/copies/inputs before execution. Native300s afterimports,
review180s,8GiB sampled private,350MiB launch available-pagefile floor,
32MiB packet. Exhaustion is incomplete. Preserve failed sources and
captures; a correction gets a new version rather than weaker tests.
No agents or parallel dependent execution. Native roles cannot read peer
outputs or quantum target/remainder files. Late review compares complete
tensors, checks radial bases/pair normalization and selected literal
180-coordinate Hessian logarithms, both probes and both q, with relevant
block omissions. Insensitive controls are reported as such.

Accept only the measured contact within this domain. Nonzero and zero
model components are both scientifically permissible. A disagreement
stops use in identities until resolved; underdefinition is not an anomaly.
No full T/F,QAP,measure,causal,physical or E5/A5 promotion. After this input
is verified, derive actual source/Euler lowering and assess the complete
fixed-source identities. Retain all historical failures and scientific
authority; no foundation/scheme/benchmark or protected-stage change.
