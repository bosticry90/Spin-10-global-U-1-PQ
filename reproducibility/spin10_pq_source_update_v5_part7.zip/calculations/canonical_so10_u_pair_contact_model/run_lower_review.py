from pathlib import Path
from hashlib import sha256
import ast
import json
import sys
import traceback

O = Path(__file__).resolve().parent
R = O.parents[1]
C = Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-pair-contact-model-v1-2026-10-26')
sys.path.insert(0, str(R / 'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H = lambda p: sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_bytes())


def dump(path, value):
    with path.open('xb') as stream:
        stream.write((json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode())


try:
    bindings = dict(read(O / 'lowering_preparation.json')['input_sha256'])
    for path, digest in bindings.items():
        assert H(Path(path)) == digest, path
    old = R / 'calculations/canonical_so10_intrinsic_full_source_descent'
    for basis in ['chi4', 'log2', 'log3', 'log5']:
        path = old / ('variation_v3_' + basis + '_primary_tables.json.gz')
        bindings[str(path)] = H(path)
    for name in ['DERIVATION.md', 'DESCENT.md', 'variation_validation_receipt_v3.json']:
        path = old / name
        bindings[str(path)] = H(path)
    for name in ['LOWERING_REVIEW_RECORD.md', 'verify_lower.py', 'run_lower_review.py']:
        path = O / name
        if path.suffix == '.py':
            ast.parse(path.read_bytes())
        with (O / (name + '.source.txt')).open('xb') as stream:
            stream.write(path.read_bytes())
    for path in O.iterdir():
        if path.is_file():
            bindings[str(path)] = H(path)
    dump(O / 'lowering_review_preparation.json', {'input_sha256': bindings, 'scientific_acceptance': 'NOT_PERFORMED'})
    result = capture([sys.executable, '-B', str(O / 'verify_lower.py')])
    dump(O / 'lowering_review_capture.json', result)
    dump(C / 'lowering_review_full_capture.json', result)
    assert result['exit_code'] == 0 and result['execution_state'] == 'COMPLETED'
    assert result['calculation_completed'] and result['post_run_observations_qualified']
    assert result['launch']['memory']['available_pagefile'] >= 350 * 1024 ** 2
    assert max(row['private_bytes'] for row in result['all_resource_samples']) <= 8 * 1024 ** 3
    rows = [json.loads(line[7:]) for line in result['stdout_and_stderr'].splitlines() if line.startswith('RESULT ')]
    assert len(rows) == 1 and rows[0]['elapsed_after_imports'] < 180
    assert sum(p.stat().st_size for p in O.iterdir() if p.is_file()) < 32 * 1024 ** 2
    print('COMPLETED UPM4', json.dumps(rows[0], sort_keys=True), flush=True)
except BaseException:
    dump(O / 'lowering_review_controller_failure.json', {'execution_state': 'FAILED', 'traceback': traceback.format_exc(), 'failure_relabelled_PASS': False})
    raise
