# The last marginal source-pair contact is measured and its Euler image computed

PROGRESS. The actual `u JL JL CC` contact is now calculated, with all
five heat-edge orders retained. Together with the previously qualified
four types, this supplies the five identified marginal quadratic-source
contact types in the declared inventory. This is not a percentage of
E5, a full source identity or physical validation.

The source-free Euler image of all three u-contact types is also now
computed. Adding it to the earlier homogeneous T/F image leaves nonzero
PARTIAL remainders. Actual B_u C0 and its applicability requirements have
not been included or set to zero. Neither an anomaly nor closure follows.
Authority34/39,state113,E5/A5 OPEN remain unchanged.

## Actual model contact

Use the original unshifted SMA/CSW/EDS,A0,constant probes,intrinsic0,
zero external jets and symbolic g10/xi/eta_H. This is the nonexceptional
Euclidean LOCAL RELATIVE construction, not a physical scaleless p=0
integral, absolute product or massive causal amplitude. Common units
are hbar/(16pi^2). Canonical pairs r<s,h<k have980100 positions per tensor;
separate pair antisymmetry recovers the full45^4 array and its diagonal
zeros. The coefficient of the sorted word is T for density

    (u/4) JL_r JL_s C_h C_k T_rshk.

The qualified six-group formula is contracted with actual ordinary and
u vertices, including both anomalous ghost blocks. Primary sparse paths
and replay reassociated matrices/typed pair antisymmetrization agree on
every group, heat tensor, formal basis and implicit zero complement.
The actual q-sign transformation is verified on every retained u block;
it proves the full contraction is q-even. Literal checks retain both q.

| Probe1 tensor | Nonzero canonical positions | Zero complement |
| --- | ---: | ---: |
| Heat2, AC | 5,956 | 974,144 |
| Heat3, BC | 2,440 | 977,660 |
| Heat4 | 0 | 980,100 |
| Heat5, BH | 6,060 | 974,040 |
| Pole/baseline sum | 2,766 | 977,334 |

All probe0 groups vanish after contraction. In probe1 AD,AH,BD are zero;
they were calculated, not removed from generic support. The fifth-edge
term is nonzero in this actual model, not only in generic fixtures.
For example,

    Heat2[13,14,13,14] = -113 g10^4 xi/25,
    Heat5[13,14,3,4] = 3 eta_H g10^4/2.

The union of parameter powers is g10^3 xi,g10^4 eta_H,g10^4 xi.
The relative contact is

    chi4*(Heat2+Heat3+Heat4+Heat5)
      +log(3/2)*Heat3+log2*Heat4+log(5/2)*Heat5.

In prime bases, log2=Heat4-Heat3-Heat5,log3=Heat3,log5=Heat5.
No chi4,b0,kappa or infrared normalization is chosen or identified with
another constant. The fixed dimensional term stays zero under the
inherited complete pinned-support proof.

Ten literal180-coordinate Hessian-log checks agree at the prescribed
extreme/fixed witnesses in both probes and both momentum orientations.
They supplement, rather than replace, the complete reduced-tensor replay.
Four actual pair-exchange tests verify the normalization/sign. In probe1,
aa omission changes heat2,CC omission heat2/3,W omission heat5,and Ku
omission heat5. Probe0 controls are insensitive and are not credited as
detectors. [UPM2 receipt](validation_receipt.json).

## Actual source-free Euler lowering

The action-derived qJL=Nx and qJa=-SCx are applied after differentiation,
using296 N entries and6268 S entries. Nonzero literal graded fixtures fix
the signs. Primary component contractions and replay ordered-word odd
Leibniz derivation agree on all three contributions:

    T_Euler = KN,
    F_Euler = KS+TN.

Here KN comes from uJaJL C under qJL; KS is its qJa image; TN comes
from the new uJLJLCC contact under qJL. The previously measured uJaJa
Hessian Q is authenticated zero, so its contribution remains zero.
[Exact formulas and scope](LOWERING_RECORD.md).

| Probe1 heat | KN into T | KS into F | TN into F | Combined F |
| --- | ---: | ---: | ---: | ---: |
| 2 | 5,344 | 80,380 | 70,864 | 119,644 |
| 3 | 2,496 | 54,200 | 37,888 | 92,088 |
| 4 | 0 | 0 | 0 | 0 |
| 5 | 0 | 0 | 75,056 | 75,056 |

Every probe0 image is zero. The complete canonical domains have664200 T
and14612400 F positions per tensor/probe. Formal bases and their zero
complements agree. d(u), homogeneous source/field transformations and
other Euler degrees are not silently folded into this source-lowering
projection; they have different source degrees or retained obligations.

## Late partial T/F comparison

Only after the measured Euler images agree does review read the qualified
ISD homogeneous source image. The complete coefficient sums are preserved
in partial_TF_tables.json.gz. Counts below refer to the resulting PARTIAL
sum, not the full quantum identity:

| Probe1 basis | Homogeneous plus Euler: T | Homogeneous plus Euler: F |
| --- | ---: | ---: |
| chi4 | 9,256 | 65,664 |
| log2 | 12,808 | 206,164 |
| log3 | 6,472 | 45,176 |
| log5 | 12,432 | 197,652 |

Probe0 partial sums are zero. B_u C0 still requires its actual source-
filtration/quantum-root assessment. No unknown contribution was solved
from these remainders. [UPM4 receipt](lowering_validation_receipt.json).

## Focused result-to-claim assessment

**Supported result.** A previously missing model-specific quantum contact
and the complete u quadratic-source Euler images are now available in
their declared formal domain. Independent contraction orders and a
literal graded derivation corroborate implementation, including a
necessary nonzero fifth-edge term.

**Remaining inference.** The homogeneous source image plus Euler lowering
is not the full variation. Its nonzero remainder can still contain the
missing B_u C0 contribution. It therefore proves neither a quantum anomaly
nor failure of the model. Complete contact-type coverage is not full
renormalized product construction, QAP, source reality, measure/global
phase control, causal physical applicability or E5/A5 qualification.

**Capability and shared limits.** Structural grading and complete q-sign
transport avoid a blind component logarithm and redundant full q replay.
Different pair/sign and Leibniz implementations detect relevant algebraic
errors. They retain shared action, qualified input projections, coordinate
charts, coefficient ring, Python/SymPy and AI authorship. No independent
scientists, proof assistant or experimental evidence validate the shared
physical assumptions. No new native or scientific-check failure occurred
in this increment; an earlier read-only wildcard lookup was corrected.

**Next discriminating action.** Use the actual complete G/QG source-degree
inventory to enumerate the unprobed kernels required by B_u C0 in the T/F
projection. Reuse already qualified kernels and structural exclusions;
derive only indispensable missing coefficients. Then assess the complete
selected relative identities, retaining any remainder. This tests the
missing mathematical bridge rather than fitting it to the partial sum.

## Resources, validation and authority

After-import seconds: contact26.6795/26.4382, literal review4.1724,
lowering26.0078/29.1380, lowering review47.3297. All six native/review
captures are COMPLETED/native0. Fourteen source copies and preparation
bindings23/41/56/76 are retained. Largest sampled private allocation was
1,200,603,136B, not a continuous peak. Packet12,706,006B before this
report. Frozen300s native/180s review,8GiB sampled,350MiB launch floor
and32MiBpacket limits were respected.

The delegated E4 authentication completed once in28.0s,native0,step exits
[0,0,0,0,0,2]. This is sealed-scope authentication and bounded audits,
not fresh global scientific replay or custody PASS. Historical custody
remains exit2/seven unresolved references. Final metadata/input/resource
review and Git byte-preservation checks accompany the local commit.
No old artifact, hash, failed run or acceptance condition is changed.

State SHA256 remains
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8.
No action installation, foundation/scheme/physical benchmark adoption,
flavor/HB1/C5 activation, protected promotion, branch/worktree, external
message, publication or remote push. The broader investigation remains
ACTIVE and incomplete. This report is frozen before final review.
