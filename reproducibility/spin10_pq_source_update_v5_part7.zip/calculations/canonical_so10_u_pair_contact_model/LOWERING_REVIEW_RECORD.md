# UPM4: source image comparison and late partial T/F assessment

Prospective before review. Compare both complete UPM3 images, each group
and heat, all four relative bases and zero complements. Recompute relative
combinations from heat images. Check actual N/S counts, preserved nonzero
graded sign fixtures and the authenticated zero uJaJa contribution.

Only after that comparison read authenticated ISD homogeneous T/F in each
basis. Preserve the complete coefficient sum with the new u-contact Euler
image as a PARTIAL relation. Independently measured B_u C0 and a complete
applicability assessment remain missing. Do not infer their value from
this partial remainder, even if a projection happens to vanish.

Freeze the complete new packet and selected old ISD tables/receipts for
review. Check captured runtime/resource states and all source copies,
including prior native/review stages. Review180s afterimports,8GiB sampled,
350MiB launch floor,32MiBpacket. No native is repeated; no fresh global
scientific validation or scientific promotion is implied.
