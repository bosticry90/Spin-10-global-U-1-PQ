from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import gzip
import json
import os
import sys
import threading
import time
import sympy as s

O = Path(__file__).resolve().parent
R = O.parents[1]
tick = time.perf_counter()
timer = threading.Timer(180, lambda: os._exit(124))
timer.daemon = True
timer.start()
read = lambda p: json.loads(p.read_bytes())
load = lambda p: json.loads(gzip.decompress(p.read_bytes()))
for path, digest in read(O / 'review_preparation.json')['input_sha256'].items():
    assert sha256(Path(path).read_bytes()).hexdigest() == digest, path
sys.path.insert(0, str(R / 'calculations/canonical_so10_intrinsic_full_source_descent'))
from coefficient_ring import coefficient, constant
g, xi, eta = s.symbols('g10 xi eta_H', real=True)


@lru_cache(None)
def co(value):
    return coefficient(s.expand(s.sympify(value, locals={'g10': g, 'xi': xi, 'eta_H': eta})))


def clean(values):
    return {key: value for key, value in values.items() if value}


def plus(*terms):
    result = defaultdict(lambda: 0)
    for values, factor in terms:
        for key, value in values.items():
            result[key] += factor * value
    return clean(result)


def pmul(first, second):
    result = defaultdict(lambda: 0)
    for mask, value in first.items():
        for other, coefficient in second.items():
            if mask & other:
                continue
            sign = (-1) ** sum(i > j for i in range(1, 5) for j in range(1, 5)
                              if mask & (1 << i) and other & (1 << j))
            result[mask | other] += sign * value * coefficient
    return clean(result)


def mm(first, second):
    rows = defaultdict(list)
    result = {}
    for (i, j), value in second.items():
        rows[i].append((j, value))
    for (i, k), value in first.items():
        for j, other in rows[k]:
            result[i, j] = plus((result.get((i, j), {}), 1), (pmul(value, other), 1))
    return clean(result)


def insert(matrix, i, j, mask, value):
    if value:
        matrix[i, j] = plus((matrix.get((i, j), {}), 1), ({mask: value}, 1))


def index(i):
    if i < 180:
        return i // 4 if i % 4 == 3 else None
    if i < 225:
        return 45 + i - 180
    return 90 + i - 225 if i < 315 else None


d = load(O / 'model_primary_inputs.json.gz')
actual = load(R / 'calculations/canonical_so10_remaining_u_contact_vertices/vertices_primary_tables.json.gz')
G0 = {(i, j): co(v) for i, j, v in d['G0']['entries']}
J = [{(a, b): co(v) for a, b, v in row['entries']} for row in d['J0']]
W = {(r, b, c): co(v) for r, b, c, v in d['W']}
Z = {(r, h, a, c): co(v) for r, h, a, c, v in d['Z0']}


def pieces(probe, r, ss, h, k, q):
    GG, VV = {}, {}
    for (i, j), value in G0.items():
        factor = q if (i < 45 <= j or j < 45 <= i) else 1
        insert(GG, i, j, 0, factor * value)
    for c in range(45):
        insert(GG, 90 + c, 135 + c, 0, constant(1))
        insert(GG, 135 + c, 90 + c, 0, constant(-1))
    for source, bit in [(r, 2), (ss, 4)]:
        for (rr, b, c), value in W.items():
            if rr == source:
                insert(VV, b, 90 + c, bit, value)
                insert(VV, 90 + c, b, bit, -value)
    for ghost, bit in [(h, 8), (k, 16)]:
        for (a, b), value in J[ghost].items():
            value = q * value if b < 45 else value
            insert(VV, 135 + a, b, bit, value)
            insert(VV, b, 135 + a, bit, value if b < 45 else -value)
    for source, sb in [(r, 2), (ss, 4)]:
        for ghost, cb in [(h, 8), (k, 16)]:
            for (rr, hh, a, c), value in Z.items():
                if rr == source and hh == ghost:
                    insert(VV, 135 + a, 90 + c, sb | cb, value)
                    insert(VV, 90 + c, 135 + a, sb | cb, -value)
    external = {315 + r: 2, 315 + ss: 4, 225 + h: 8, 225 + k: 16}
    groups = next(row['groups'] for row in actual['Fourier_unit_axes'] if row['axis'] == 3 and row['q'] == q)
    for u, rows in [(False, groups['GFquartic']), (True, groups['u' + str(probe)])]:
        for i, j, ext, value in rows:
            if any(n not in external for n in ext):
                continue
            bits = [external[n] for n in ext]
            if len(set(bits)) != len(bits):
                continue
            ii, jj = index(i), index(j)
            if ii is None or jj is None:
                continue
            sign = (-1) ** sum(bits[a] > bits[b] for a in range(len(bits)) for b in range(a + 1, len(bits)))
            insert(VV, ii, jj, int(u) | sum(bits), sign * co(value))
    return GG, VV


def logarithm(GG, VV):
    operator = mm(GG, VV)
    power = {(i, i): {0: constant(1)} for i in range(180)}
    result = {}
    for edge in range(1, 6):
        power = mm(power, operator)
        total = sum(((-1) ** int(i >= 90) * poly.get(31, 0)
                     for (i, j), poly in power.items() if i == j), 0)
        result[edge] = co(str(s.Rational((-1) ** (edge + 1), 2 * edge))) * total
    return result


tab = lambda rows: {tuple(row[:-1]): co(row[-1]) for row in rows}
primary, replay = [load(O / ('pair_' + role + '_tables.json.gz')) for role in ['primary', 'replay']]
summaries, checks, controls, exchange = [], [], [], []
for probe in range(2):
    first, second = primary['results'][probe], replay['results'][probe]
    groups = {name: tab(rows) for name, rows in first['groups'].items()}
    assert groups == {name: tab(rows) for name, rows in second['groups'].items()}
    heat = {int(edge): tab(rows) for edge, rows in first['heat'].items()}
    assert heat == {int(edge): tab(rows) for edge, rows in second['heat'].items()}
    assert heat[2] == groups['AC']
    assert heat[3] == plus((groups['AD'], 1), (groups['BC'], 1))
    assert heat[4] == plus((groups['AH'], 1), (groups['BD'], 1))
    assert heat[5] == groups['BH']
    pole = plus(*[(value, 1) for value in heat.values()])
    relative = {'chi4': pole, 'log2': plus((heat[4], 1), (heat[3], -1), (heat[5], -1)),
                'log3': heat[3], 'log5': heat[5], 'fixed': {}}
    assert relative == {name: tab(rows) for name, rows in first['relative'].items()}
    assert relative == {name: tab(rows) for name, rows in second['relative'].items()}
    assert first['parameter_powers'] == second['parameter_powers']
    assert first['all_u_blocks_q_sign_equivalent'] and second['all_u_blocks_q_sign_equivalent']
    for values in list(groups.values()) + list(heat.values()) + list(relative.values()):
        assert all(0 <= r < ss < 45 and 0 <= h < k < 45 for r, ss, h, k in values)
    samples = {(12, 13, 14, 15)}
    for values in heat.values():
        if values:
            samples.update([min(values), max(values)])
    assert len(samples) <= 9
    for r, ss, h, k in sorted(samples):
        for q in [1, -1]:
            GG, VV = pieces(probe, r, ss, h, k, q)
            measured = logarithm(GG, VV)
            assert not measured[1]
            assert all(measured[edge] == heat[edge].get((r, ss, h, k), 0) for edge in [2, 3, 4, 5]), (probe, r, ss, h, k, q, {e: str(v) for e, v in measured.items()})
            checks.append([probe, r, ss, h, k, q, {str(e): str(v) for e, v in measured.items()}])
            if q == 1:
                for control in ['aa', 'CC', 'W', 'Ku']:
                    changed = {}
                    for (i, j), poly in VV.items():
                        copy = {}
                        for mask, value in poly.items():
                            remove = (control == 'aa' and i >= 135 and j >= 135)
                            remove |= (control == 'CC' and 90 <= i < 135 and 90 <= j < 135)
                            remove |= (control == 'W' and mask in [2, 4] and (i < 90 <= j or j < 90 <= i))
                            remove |= (control == 'Ku' and mask == 1 and i < 90 and j < 90)
                            if not remove:
                                copy[mask] = value
                        if copy:
                            changed[i, j] = copy
                    different = logarithm(GG, changed)
                    controls.append({'probe': probe, 'sample': [r, ss, h, k], 'control': control,
                                     'changed_heat': [e for e in range(1, 6) if different[e] != measured[e]]})
    witness = next((sample for sample in sorted(samples) if any(value.get(sample, 0) for value in heat.values())), min(samples))
    r, ss, h, k = witness
    baseline = {e: heat[e].get(witness, 0) for e in [2, 3, 4, 5]}
    for label, args in [('exchangeJL', (ss, r, h, k)), ('exchangeC', (r, ss, k, h))]:
        GG, VV = pieces(probe, *args, 1)
        measured = logarithm(GG, VV)
        assert all(measured[e] == -baseline[e] for e in [2, 3, 4, 5])
        exchange.append([probe, label, list(witness), {str(e): str(measured[e]) for e in [2, 3, 4, 5]}])
    summaries.append({'probe': probe, 'heat_nonzero_zero': [[e, len(heat[e]), 980100 - len(heat[e])] for e in [2, 3, 4, 5]],
                      'pole_nonzero_zero': [len(pole), 980100 - len(pole)],
                      'parameter_powers': first['parameter_powers']})
for role in ['primary', 'replay']:
    record = read(O / ('pair_' + role + '_result.json'))
    raw = (O / ('pair_' + role + '_tables.json.gz')).read_bytes()
    assert sha256(raw).hexdigest() == record['packed_sha256']
    assert sha256(gzip.decompress(raw)).hexdigest() == record['raw_sha256']
result = {'elapsed_after_imports': time.perf_counter() - tick,
          'complete_groups_heat_relative_and_zero_complements_agree': True,
          'full_classical_q_equivalence_both_roles': True,
          'canonical_positions_per_tensor': 980100, 'ordered_positions_per_tensor': 4100625,
          'summaries': summaries, 'literal180_both_q': checks,
          'literal_omission_controls': controls, 'literal_pair_exchange': exchange,
          'source_Euler_lowering_T_F_QAP_or_E5_claim': False}
with (O / 'validation_receipt.json').open('xb') as stream:
    stream.write((json.dumps(result, sort_keys=True, separators=(',', ':')) + '\n').encode())
print('RESULT ' + json.dumps(result, sort_keys=True), flush=True)
timer.cancel()
