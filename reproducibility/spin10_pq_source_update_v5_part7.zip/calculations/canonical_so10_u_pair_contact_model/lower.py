from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import gzip
import json
import os
import sys
import threading
import time
import sympy as s

O = Path(__file__).resolve().parent
R = O.parents[1]
role = sys.argv[1]
assert role in ['primary', 'replay']
tick = time.perf_counter()
timer = threading.Timer(300, lambda: os._exit(124))
timer.daemon = True
timer.start()
read = lambda p: json.loads(p.read_bytes())
load = lambda p: json.loads(gzip.decompress(p.read_bytes()))
for path, digest in read(O / 'lowering_preparation.json')['input_sha256'].items():
    assert sha256(Path(path).read_bytes()).hexdigest() == digest, path


def guard(event, args):
    if event == 'open' and args and isinstance(args[0], (str, bytes)):
        path = Path(os.fsdecode(args[0]))
        if path.parent.name == 'canonical_so10_intrinsic_full_source_descent' and path.name.startswith('variation'):
            raise PermissionError('UPM3_DESIRED_SOURCE_IMAGE_DENIED')
        peer = 'replay' if role == 'primary' else 'primary'
        if path.parent.resolve() == O and path.name.startswith('lower_' + peer):
            raise PermissionError('UPM3_PEER_OUTPUT_DENIED')


sys.addaudithook(guard)
sys.path.insert(0, str(R / 'calculations/canonical_so10_intrinsic_full_source_descent'))
from coefficient_ring import coefficient
g, xi, eta = s.symbols('g10 xi eta_H', real=True)


@lru_cache(None)
def co(value):
    return coefficient(s.expand(s.sympify(value, locals={'g10': g, 'xi': xi, 'eta_H': eta})))


def clean(values):
    return {key: value for key, value in values.items() if value}


def plus(*terms):
    result = defaultdict(lambda: 0)
    for values, factor in terms:
        for key, value in values.items():
            result[key] += factor * value
    return clean(result)


def derive(word, flows):
    result = defaultdict(lambda: 0)
    odd = lambda token: token[0] in [2, 3]
    for at, source in enumerate(word):
        if source not in flows:
            continue
        prefix = sum(odd(token) for token in word[:at])
        for replacement, value in flows[source]:
            new = word[:at] + replacement + word[at + 1:]
            odds = [token for token in new if odd(token)]
            if len(set(odds)) < len(odds):
                continue
            inversion = sum(a > b for j, a in enumerate(odds) for b in odds[j + 1:])
            result[tuple(sorted(new))] += (-1) ** (prefix + inversion) * value
    return clean(result)


# Nonzero fixture, independently ordered before numerical model use.
fixture_flows = {(1, 0): [(((3, 0), (4, 0)), -13)],
                 (2, 0): [(((4, 0),), 7)], (2, 1): [(((4, 0),), 11)]}
fixture_K = derive(((0, 0), (1, 0), (2, 0), (3, 1)), fixture_flows)
assert fixture_K == {((0, 0), (2, 0), (3, 0), (3, 1), (4, 0)): 13,
                     ((0, 0), (1, 0), (3, 1), (4, 0)): 7}
fixture_T = derive(((0, 0), (2, 0), (2, 1), (3, 0), (3, 1)), fixture_flows)
assert fixture_T == {((0, 0), (2, 1), (3, 0), (3, 1), (4, 0)): 7,
                     ((0, 0), (2, 0), (3, 0), (3, 1), (4, 0)): -11}

euler = load(R / ('calculations/canonical_so10_intrinsic_auxiliary_ghost_source/vertex_' + role + '_inputs.json.gz'))
N = defaultdict(list)
S = defaultdict(list)
for r, i, value in euler['endings']['N0']['entries']:
    assert r >= 45
    N[r - 45].append((i, co(value)))
for a, c, i, value in euler['S0']:
    S[a].append((c, i, co(value)))
assert sum(map(len, N.values())) == 296 and sum(map(len, S.values())) == 6268
iqc = load(R / ('calculations/canonical_so10_intrinsic_quadratic_source_contacts/color_' + role + '_tables.json.gz'))
assert all(not row['Q2_even_Hessian']['entries'] for row in iqc['results'])
k_all = load(R / ('calculations/canonical_so10_remaining_u_contact_vertices/k_model_' + role + '_tables.json.gz'))
t_all = load(O / ('pair_' + role + '_tables.json.gz'))
flows = {}
for r, terms in N.items():
    flows[2, r] = [(((4, i),), value) for i, value in terms]
for a, terms in S.items():
    flows[1, a] = [(((3, c), (4, i)), -value) for c, i, value in terms]
results = []
encode = lambda values: [[*key, str(value)] for key, value in sorted(values.items())]
for probe in range(2):
    images = {}
    for edge in [2, 3, 4, 5]:
        K = {tuple(row[:-1]): co(row[-1]) for row in k_all['results'][probe]['heat'].get(str(edge), [])}
        T = {tuple(row[:-1]): co(row[-1]) for row in t_all['results'][probe]['heat'][str(edge)]}
        KN, KS, TN = [defaultdict(lambda: 0) for index in range(3)]
        if role == 'primary':
            for (a, r, h), value in K.items():
                for i, other in N[r]:
                    KN[a, h, i] += value * other
                for c, i, other in S[a]:
                    if c < h:
                        KS[r, c, h, i] += value * other
                    elif c > h:
                        KS[r, h, c, i] -= value * other
            for (r, ss, h, k), value in T.items():
                for i, other in N[r]:
                    TN[ss, h, k, i] += value * other
                for i, other in N[ss]:
                    TN[r, h, k, i] -= value * other
        else:
            for target, tensor in [('K', K), ('T', T)]:
                for key, value in tensor.items():
                    if target == 'K':
                        a, r, h = key
                        word = ((0, 0), (1, a), (2, r), (3, h))
                    else:
                        r, ss, h, k = key
                        word = ((0, 0), (2, r), (2, ss), (3, h), (3, k))
                    for monomial, other in derive(word, flows).items():
                        categories = tuple(token[0] for token in monomial)
                        if categories == (0, 1, 3, 4):
                            KN[tuple(token[1] for token in monomial[1:])] += value * other
                        else:
                            assert categories == (0, 2, 3, 3, 4)
                            destination = KS if target == 'K' else TN
                            destination[tuple(token[1] for token in monomial[1:])] += value * other
        KN, KS, TN = map(clean, [KN, KS, TN])
        images[edge] = {'KN_T': KN, 'KS_F': KS, 'TN_F': TN, 'F': plus((KS, 1), (TN, 1))}
        print('STAGE UPM3', role, probe, edge, {name: len(value) for name, value in images[edge].items()}, flush=True)
    relative = {}
    for basis, weights in [('chi4', {2: 1, 3: 1, 4: 1, 5: 1}),
                           ('log2', {3: -1, 4: 1, 5: -1}), ('log3', {3: 1}), ('log5', {5: 1})]:
        relative[basis] = {target: plus(*[(images[edge][name], factor) for edge, factor in weights.items()])
                           for target, name in [('T', 'KN_T'), ('F', 'F')]}
    results.append({'probe': probe, 'heat_images': {str(edge): {name: encode(value) for name, value in groups.items()} for edge, groups in images.items()},
                    'relative_images': {basis: {target: encode(value) for target, value in groups.items()} for basis, groups in relative.items()}})
out = {'schema': 'UPM3_COMPLETE_U_CONTACT_EULER_IMAGE', 'role': role, 'results': results,
       'canonical_T_F_positions': [664200, 14612400], 'N_S_entries': [296, 6268],
       'nonzero_literal_sign_fixtures': True, 'qualified_u_Ja_Ja_contact_zero_authenticated': True,
       'full_source_identity_or_missing_Bu_C0_set_zero': False}
raw = (json.dumps(out, sort_keys=True, separators=(',', ':')) + '\n').encode()
blob = gzip.compress(raw, mtime=0)
with (O / ('lower_' + role + '_tables.json.gz')).open('xb') as stream:
    stream.write(blob)
print('RESULT ' + json.dumps({'elapsed_after_imports': time.perf_counter() - tick,
      'packed_sha256': sha256(blob).hexdigest(), 'raw_sha256': sha256(raw).hexdigest(),
      'relative_counts': [{basis: {target: len(value) for target, value in groups.items()} for basis, groups in row['relative_images'].items()} for row in results],
      'full_quantum_identity_or_anomaly_claim': False}, sort_keys=True), flush=True)
timer.cancel()
