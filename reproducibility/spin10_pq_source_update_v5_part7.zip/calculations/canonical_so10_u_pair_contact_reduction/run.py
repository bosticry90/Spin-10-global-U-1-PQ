from pathlib import Path
from hashlib import sha256
import ast
import json
import sys
import traceback

O = Path(__file__).resolve().parent
R = O.parents[1]
C = Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-pair-contact-reduction-v1-2026-10-26')
sys.path.insert(0, str(R / 'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture


def dump(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


def H(path):
    return sha256(path.read_bytes()).hexdigest()


def execute(name, script, limit):
    result = capture([sys.executable, '-B', str(O / script)])
    dump(O / (name + '_capture.json'), result)
    dump(C / (name + '_full_capture.json'), result)
    assert result['exit_code'] == 0 and result['execution_state'] == 'COMPLETED'
    assert result['calculation_completed'] and result['post_run_observations_qualified']
    assert result['launch']['memory']['available_pagefile'] >= 350 * 1024 ** 2
    assert max(row['private_bytes'] for row in result['all_resource_samples']) <= 8 * 1024 ** 3
    rows = [json.loads(line[7:]) for line in result['stdout_and_stderr'].splitlines() if line.startswith('RESULT ')]
    assert len(rows) == 1 and rows[0]['elapsed_after_imports'] < limit
    dump(O / (name + '_result.json'), rows[0])
    assert sum(path.stat().st_size for path in O.iterdir() if path.is_file()) < 32 * 1024 ** 2
    print('COMPLETED', name, json.dumps(rows[0], sort_keys=True), flush=True)


try:
    inputs = json.loads((O / 'inputs.json').read_bytes())
    for path, digest in inputs['input_sha256'].items():
        assert H(R / path) == digest, path
    sources = {}
    for name in ['RECORD.md', 'reduce.py', 'verify.py', 'run.py', 'inputs.json']:
        path = O / name
        if path.suffix == '.py':
            ast.parse(path.read_bytes())
        with (O / (name + '.source.txt')).open('xb') as stream:
            stream.write(path.read_bytes())
        sources[str(path)] = H(path)
    dump(O / 'preparation.json', {'source_sha256': sources, 'scientific_acceptance': 'NOT_PERFORMED'})
    execute('native', 'reduce.py', 300)
    review = {str(R / path): digest for path, digest in inputs['input_sha256'].items()}
    review.update({str(path): H(path) for path in O.iterdir() if path.is_file()})
    dump(O / 'review_preparation.json', {'input_sha256': review, 'scientific_acceptance': 'NOT_PERFORMED'})
    execute('review', 'verify.py', 180)
except BaseException:
    dump(O / 'controller_failure.json', {'execution_state': 'FAILED', 'traceback': traceback.format_exc(), 'failure_relabelled_PASS': False})
    raise
