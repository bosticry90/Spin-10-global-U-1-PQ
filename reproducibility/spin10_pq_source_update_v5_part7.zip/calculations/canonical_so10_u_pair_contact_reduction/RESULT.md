# The remaining source-pair contact has a six-group ordered reduction

PROGRESS. The full doubled-ghost target `u JL JL CC` reduces to six
ordered trace groups, with heat degrees 2,3,3,4,4,5. A new exact exterior
algebra calculation agrees with the previously qualified full paired
Hessian and Schur fixtures. The actual Spin(10) coefficient tensor is
still unmeasured. Scientific authority remains unchanged.

## Result and evidence

The prospective [record](RECORD.md) gives the finite degree argument.
With source Ja absent, the bosonic block has no JL/C dependence. The
linear-u Schur terms S0 and Su each have JL/C exterior degree two.
Consequently the complete degree-four term of the negative ghost
half-Trlog is

    [JL1 JL2 C1 C2] (1/2) Tr[(Gf S0)(Gf Su)],

with the inherited q=+/- average. The bosonic determinant has no target
term. Higher ghost-log orders have excessive exterior degree; this
does not drop heat edges inside either Schur factor. The inverse's Ku
insertion retains two bosonic edges and gives a fifth-edge contribution.
All anomalous aa/CC and normal source blocks remain in the formula.

The [new calculation](reduce.py) uses a fresh SymPy-valued exterior
algebra. It reuses only the authenticated pure fixture data() generator
from the old source; it never decodes earlier quantum output. The
[review](verify.py) subsequently compares all five heat coefficients
against both archived full calculation routes on all12 fixtures, with
D3/4/5, first/last axes and two seeds. The six component groups sum to
the prior full results. This is not an independent per-group replay of
each same-heat component.

For the first fixture seed, the groups are

| Group | Heat degree | Generic coefficient |
| --- | ---: | --- |
| AC | 2 | 7i |
| AD | 3 | -1 |
| BC | 3 | -6+41i |
| AH | 4 | -51+6i |
| BD | 4 | 12 |
| BH | 5 | -339-13i |

The fifth-edge coefficient at the second seed is -404-23i. These are
generic fixture values, not physical Spin(10) coefficients. No model
coefficient was fitted to a desired identity.

All22 archived T control-sensitivity profiles agree. This count includes
width variation and insensitive Ja-related controls as well as omissions;
it is not22 independent nonzero detections. The required aa/CC/W/Ku
omissions are sensitive for both seeds. The eight source/ghost pair
exchange and diagonal tests pass: exchange reverses T; equal directions
give zero. The [validation receipt](validation_receipt.json) records the
bounded comparison, not model measurement or source-identity closure.

## Focused result-to-claim assessment

**Supported claim.** The qualified marginal proper-loop support permits
the stated finite grading reduction, corroborated coefficient by
coefficient on the declared generic fixtures. It provides a compact
route to the missing model tensor and retains the fifth-edge term that
a four-edge truncation would lose.

**Inference limits.** Generic agreement does not determine actual color
contractions, their zeros or their parameter dependence. The actual
model's anomalous blocks, coordinate phases and separately antisymmetric
JL/C pairs must still enter that calculation. Model source/Euler lowering
and full T/F relations then remain to be assembled. No inference to QAP,
measure, causal products, physical consistency or empirical agreement is
earned here. The argument is finite algebra, not a new continuum trace
domain theorem.

**AI capability and shared risks.** The new reduction turns a longer
graded logarithm into a bilinear expression before large component work.
Archived calculations supply a different full-Hessian/Schur reference,
and sensitive omissions test known block and heat-edge failure modes.
Methods still share the Gaussian premise, fixture data, source conventions,
Python/SymPy and AI authorship. Agreement cannot validate those shared
physical premises or substitute for independent scientists. No proof
assistant or external reviewer is claimed.

**Next decision.** Contract the six groups with the actual authenticated
UCV/RSH vertices, retaining both probes, all heat degrees and pair
antisymmetry. A model zero and a model nonzero term are both permissible;
neither decides the full source identities alone. Any mismatch with a
selected literal model calculation should stop use of that contraction
until its cause is resolved. This is cheaper and more discriminating
than expanding a full 45^4 Hessian logarithm immediately.

## Execution, custody and remaining work

Native4.9222s and review0.2680s after imports, both COMPLETED/native0.
Five source copies and25 review bindings were authenticated. Largest
sampled private allocation was51,081,216B, not a continuous peak. Packet
was51,423B before this report. Bounds300s/180s,8GiB sampled private,
350MiB available-pagefile launch floor and32MiB packet were respected.
No failed or unfinished native run occurred in this increment.

The existing E4 authentication was completed earlier in this session
with native0/steps[0,0,0,0,0,2]. It is reused, not rerun for this reduction,
and does not scientifically verify the new formula. New native/review
receipts supply the bounded formula evidence. Historical custody remains
exit2 with seven unresolved references, not PASS. No global scientific,
physical or experimental replay was performed.

Old source functions, receipts, contracts and hashes were not modified
or rebound. Current live policy and the exact old fixture source are
bound for this new work; the old driver is not executed. Failure and
historical evidence retain their prior scopes. State113, authority34/39,
E5/A5 OPEN, all normalization freedoms and all protected stages remain
unchanged. No scheme, foundation or benchmark adoption, remote action,
publication or outreach. This result is frozen before final preservation
checks and local commit.
