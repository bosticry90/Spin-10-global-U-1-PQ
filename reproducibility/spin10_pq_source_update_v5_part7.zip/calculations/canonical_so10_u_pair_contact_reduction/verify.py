from pathlib import Path
from hashlib import sha256
import gzip
import json
import os
import threading
import time
import sympy as s

O = Path(__file__).resolve().parent
R = O.parents[1]
tick = time.perf_counter()
timer = threading.Timer(180, lambda: os._exit(124))
timer.daemon = True
timer.start()
prep = json.loads((O / 'review_preparation.json').read_bytes())
for path, digest in prep['input_sha256'].items():
    assert sha256(Path(path).read_bytes()).hexdigest() == digest, path
new = json.loads(gzip.decompress((O / 'reduction_tables.json.gz').read_bytes()))
old_path = R / 'calculations/canonical_so10_remaining_u_contact_vertices'
old = [json.loads(gzip.decompress((old_path / ('gaussian_' + role + '_tables.json.gz')).read_bytes()))
       for role in ['primary', 'replay']]
assert old[0]['fixtures'] == old[1]['fixtures']
assert old[0]['controls'] == old[1]['controls']
lookup = {(row['seed'], row['D'], row['axis']): row for row in new['fixtures']}
assert len(lookup) == 12
for expected in old[0]['fixtures']:
    actual = lookup[expected['seed'], expected['D'], expected['axis']]
    for edge in range(1, 6):
        assert s.expand(s.sympify(actual['heat'][str(edge)]) - s.sympify(expected['heat']['T'][str(edge)])) == 0
    groups = {name: s.sympify(value) for name, value in actual['groups'].items()}
    assert s.expand(groups['AC'] - s.sympify(actual['heat']['2'])) == 0
    assert s.expand(groups['AD'] + groups['BC'] - s.sympify(actual['heat']['3'])) == 0
    assert s.expand(groups['AH'] + groups['BD'] - s.sympify(actual['heat']['4'])) == 0
    assert s.expand(groups['BH'] - s.sympify(actual['heat']['5'])) == 0
    assert s.sympify(actual['heat']['5']) != 0
controls = {(row['seed'], row['control']): row for row in new['controls']}
assert len(controls) == 30
for expected in old[0]['controls']:
    actual = controls[expected['seed'], expected['control']]
    baseline = lookup[expected['seed'], 3, 0]
    changed = [edge for edge in range(1, 6) if s.expand(s.sympify(actual['heat'][str(edge)]) - s.sympify(baseline['heat'][str(edge)])) != 0]
    assert changed == expected['changed_heat']['T'], (expected, changed)
for seed in [0, 1]:
    baseline = lookup[seed, 3, 0]
    for label in ['exchangeJL', 'exchangeC']:
        assert all(s.expand(s.sympify(controls[seed, label]['heat'][str(edge)]) + s.sympify(baseline['heat'][str(edge)])) == 0 for edge in range(1, 6))
    for label in ['sameJL', 'sameC']:
        assert all(s.sympify(value) == 0 for value in controls[seed, label]['heat'].values())
    for label in ['omitAA', 'omitCC', 'omitBaseW', 'omitUQuadratic']:
        assert any(s.expand(s.sympify(controls[seed, label]['heat'][str(edge)]) - s.sympify(baseline['heat'][str(edge)])) != 0 for edge in range(1, 6)), label
result = {'elapsed_after_imports': time.perf_counter() - tick,
          'all_12_prior_paired_Hessian_and_Schur_fixtures_exact': True,
          'all_22_T_omission_sensitivities_match_prior_checks': True,
          'all_8_pair_exchange_and_diagonal_checks': True,
          'all_6_ordered_groups_and_5_heat_degrees_retained': True,
          'fifth_edge_nonzero_both_seeds': True,
          'actual_model_contact_coefficients_measured': False,
          'T_F_QAP_or_authority_promotion': False}
with (O / 'validation_receipt.json').open('x', encoding='utf-8') as stream:
    json.dump(result, stream, sort_keys=True)
    stream.write('\n')
print('RESULT ' + json.dumps(result, sort_keys=True), flush=True)
timer.cancel()
