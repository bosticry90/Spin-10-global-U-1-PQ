# Subsequent raw-byte staging correction

After native/review qualification and the frozen result, the first index
seal failed on inputs.json: root Git text attributes had converted CRLF
to LF while staging the new files. The raw working files and all their
recorded hashes remained unchanged. This was a packaging failure, not a
failed mathematical native or permission to replace old hashes.

The exact differing raw/staged input bytes, failed index tree and failure
disposition are preserved in the external UPR control directory as
index_failure_1.json and failed_index_inputs_1.*. The original successful
pre-index inventory remains before_index_seal.json. No original packet
source, preparation, capture, receipt or result was edited.

A packet-local .gitattributes now uses the same byte-preserving rule as
the existing UCV and UCS packets: `* -text -eol whitespace=cr-at-eol`.
The frozen raw files are restaged and every staged byte is compared with
its original reviewed raw byte before committing. A new versioned index
seal records that correction. Native scientific calculations are reused,
not repeated or relabeled. This correction changes no scientific claim,
acceptance condition, physical input or authority.
