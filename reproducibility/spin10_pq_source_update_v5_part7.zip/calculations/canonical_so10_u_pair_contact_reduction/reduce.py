from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import ast
import gzip
import json
import os
import threading
import time
import sympy as s

O = Path(__file__).resolve().parent
R = O.parents[1]
tick = time.perf_counter()
timer = threading.Timer(300, lambda: os._exit(124))
timer.daemon = True
timer.start()
inputs = json.loads((O / 'inputs.json').read_bytes())
prepared = json.loads((O / 'preparation.json').read_bytes())
for path, digest in prepared['source_sha256'].items():
    assert sha256(Path(path).read_bytes()).hexdigest() == digest, path
source_path = 'calculations/canonical_so10_remaining_u_contact_vertices/gaussian.py'
raw = (R / source_path).read_bytes()
assert sha256(raw).hexdigest() == inputs['input_sha256'][source_path]
tree = ast.parse(raw)
nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'data']
assert len(nodes) == 1
scope = {'s': s}
exec(compile(ast.Module(body=nodes, type_ignores=[]), source_path, 'exec'), scope)
data = scope['data']


def clean(values):
    result = {}
    for key, value in values.items():
        value = s.expand(value)
        if value != 0:
            result[key] = value
    return result


def poly_add(first, second, factor=1):
    result = dict(first)
    for key, value in second.items():
        result[key] = result.get(key, s.S.Zero) + factor * value
    return clean(result)


def poly_mul(first, second):
    result = defaultdict(lambda: s.S.Zero)
    for (mask, edge), value in first.items():
        for (other, length), coefficient in second.items():
            if mask & other or edge + length > 5:
                continue
            crossing = sum(i > j for i in range(2, 6) for j in range(2, 6)
                           if mask & (1 << i) and other & (1 << j))
            result[mask | other, edge + length] += (-1) ** crossing * value * coefficient
    return clean(result)


def matrix_add(first, second, factor=1):
    result = dict(first)
    for key, value in second.items():
        result[key] = poly_add(result.get(key, {}), value, factor)
    return {key: value for key, value in result.items() if value}


def mm(first, second):
    rows = defaultdict(list)
    for (i, j), value in second.items():
        rows[i].append((j, value))
    result = {}
    for (i, k), value in first.items():
        for j, other in rows[k]:
            result[i, j] = poly_add(result.get((i, j), {}), poly_mul(value, other))
    return {key: value for key, value in result.items() if value}


def const(matrix, edge):
    return {ij: {(0, edge): value} for ij, value in s.SparseMatrix(matrix).todok().items()}


def trace(matrix):
    result = {}
    for (i, j), value in matrix.items():
        if i == j:
            result = poly_add(result, value)
    return result


def insert(matrix, i, j, mask, value):
    if value != 0:
        assert mask.bit_count() in [1, 2]
        matrix[i, j] = poly_add(matrix.get((i, j), {}), {(mask, 0): value})


def reduced(D, axis, seed, control=None):
    groups = {name: s.S.Zero for name in ['AC', 'AD', 'BC', 'AH', 'BD', 'BH']}
    for q in [1, -1]:
        K, Ku, Y, M, Mu, W, Ja, uJa, Z, Zu, P, Pu, Q = data(D, axis, q, seed, control)
        nb = K.rows
        f0, fu, b0, bu, c0, cu = {}, {}, {}, {}, {}, {}
        for r in range(2):
            for h in range(2):
                mask = (1 << (2 + r)) | (1 << (4 + h))
                for container, values in [(f0, Z[r][h]), (fu, Zu[r][h])]:
                    for (a, c), value in s.SparseMatrix(values).todok().items():
                        insert(container, 2 + a, c, mask, value)
                        insert(container, c, 2 + a, mask, -value)
        for container, mask, values, offset in [(f0, 48, P, 2), (fu, 48, Pu, 2), (fu, 12, Q, 0)]:
            for (a, b), value in s.SparseMatrix(values).todok().items():
                insert(container, offset + a, offset + b, mask, value)
        for h in range(2):
            mask = 1 << (4 + h)
            for bb, cc, values in [(b0, c0, M[h]), (bu, cu, Mu[h])]:
                for (a, b), value in s.SparseMatrix(values).todok().items():
                    insert(cc, 2 + a, b, mask, value)
                    insert(bb, b, 2 + a, mask, value if b < 2 * D else -value)
        for r in range(2):
            for (b, c), value in s.SparseMatrix(W[r]).todok().items():
                insert(b0, b, c, 1 << (2 + r), value)
                insert(c0, c, b, 1 << (2 + r), -value)
        gf_matrix = s.zeros(4)
        for a in range(2):
            gf_matrix[a, 2 + a], gf_matrix[2 + a, a] = -1, 1
        gb, gf = const(K.inv(), 1), const(gf_matrix.inv(), 1)
        # The complete effective vertices all have exterior degree two.
        A = mm(gf, f0)
        B = mm(gf, mm(mm(c0, gb), b0))
        B = matrix_add({}, B, -1)
        C = mm(gf, fu)
        change = matrix_add(mm(mm(cu, gb), b0), mm(mm(c0, gb), bu))
        DD = matrix_add({}, mm(gf, change), -1)
        H = mm(mm(mm(mm(mm(gf, c0), gb), const(Ku, 0)), gb), b0)
        for matrix in [A, B, C, DD, H]:
            assert all(mask.bit_count() == 2 for poly in matrix.values() for mask, edge in poly)
        for name, first, second, edge in [('AC', A, C, 2), ('AD', A, DD, 3),
                ('BC', B, C, 3), ('AH', A, H, 4), ('BD', B, DD, 4), ('BH', B, H, 5)]:
            value = trace(mm(first, second))
            assert all(mask == 60 and length == edge for mask, length in value)
            # half ghost-log derivative times half paired-momentum average.
            groups[name] += s.Rational(1, 4) * value.get((60, edge), 0)
    groups = {name: s.expand(value) for name, value in groups.items()}
    heat = {1: s.S.Zero, 2: groups['AC'], 3: groups['AD'] + groups['BC'],
            4: groups['AH'] + groups['BD'], 5: groups['BH']}
    return {'groups': {name: str(value) for name, value in groups.items()},
            'heat': {str(edge): str(s.expand(value)) for edge, value in heat.items()}}


fixtures = []
controls = []
for seed in [0, 1]:
    for D in [3, 4, 5]:
        for axis in [0, D - 1]:
            fixtures.append({'seed': seed, 'D': D, 'axis': axis, **reduced(D, axis, seed)})
    for control in ['omitAA', 'omitCC', 'omitUQuadratic', 'omitUJaBB', 'omitUCurrent',
            'omitUJaGhost', 'omitUJLZ', 'omitBaseZ', 'omitBaseJa', 'omitBaseW', 'widthChange',
            'exchangeJL', 'exchangeC', 'sameJL', 'sameC']:
        controls.append({'seed': seed, 'control': control, **reduced(3, 0, seed, control)})
output = {'schema': 'UPR1_FULL_PAIR_BILINEAR_REDUCTION', 'sympy': s.__version__,
          'fixtures': fixtures, 'controls': controls,
          'actual_model_coefficients_measured': False, 'old_quantum_outputs_native_operands': False}
raw = (json.dumps(output, sort_keys=True, separators=(',', ':')) + '\n').encode()
blob = gzip.compress(raw, mtime=0)
with (O / 'reduction_tables.json.gz').open('xb') as stream:
    stream.write(blob)
print('RESULT ' + json.dumps({'elapsed_after_imports': time.perf_counter() - tick,
      'packed_sha256': sha256(blob).hexdigest(), 'raw_sha256': sha256(raw).hexdigest(),
      'fixtures': len(fixtures), 'controls': len(controls),
      'actual_model_coefficients_measured': False}), flush=True)
timer.cancel()
