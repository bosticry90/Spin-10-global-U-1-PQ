# UPR1: grade-reduced full source-pair contact

Prospective after V641. Question: can the full doubled-ghost construction
for `u JL JL CC` be reduced before the actual model contraction? This
serves the existing missing-contact dependency, without measuring it or
closing a Ward identity. Existing scalar-trace K formulas cannot supply
this target because anomalous aa/CC blocks are present.

Keep original action, charts, field/source parities and phases, constant
probes, zero external jets and intrinsic degree, symbolic parameters and
the nonexceptional Euclidean LOCAL RELATIVE scope. The scalar and Ja
degrees exclude their vertices here. u is commuting, retained to first
order; JL1,JL2,C1,C2 are exterior variables in that order. No normalization
constant is fixed. The actual vertex/all-D qualifications are inherited.

## Proposed complete reduction and its proof obligation

Write E on every free inverse edge. In the absence of Ja, the bosonic
block is K/E + u Ku and has no JL/C dependence. Let B0,Bu be boson-to-ghost
blocks, C0,Cu their ghost-to-boson counterparts, and F0,Fu the ghost-ghost
vertices, with u stripped from the latter coefficients. Do not replace
the full doubled ghost space by an ordinary ghost determinant.

Every B/C entry has JL/C exterior degree one, and every F entry has
degree two. This includes ordinary/u aa|CC, u CC|JLJL and normal JL C
blocks. G=E K^-1 and Gf=E Kf^-1. Modulo u^2 the Schur terms are

 S0 = F0 - C0 G B0,
 Su = Fu - Cu G B0 - C0 G Bu + C0 G Ku G B0.

Both have exterior degree two. The bosonic half-Trlog has exterior degree
zero. In the ghost negative half-Trlog, the term linear in Su has degree
two and the terms with two or more S0 factors have degree at least six.
The degree-four target is therefore precisely

 T = [JL1 JL2 C1 C2] (1/2) Tr[(Gf S0)(Gf Su)],

averaged over q=+/-1 in the inherited paired-mode convention. Cyclic
rotation used here has no exterior sign: both S0 and Su are even. This
is a finite grade argument, not an infinite trace rearrangement theorem.

Set A=Gf F0, B=-Gf C0 G B0, C=Gf Fu,
D=-Gf(Cu G B0+C0 G Bu), and H=Gf C0 G Ku G B0.
The six ordered groups are AC, AD, BC, AH, BD, BH, at heat degrees
2,3,3,4,4,5 respectively. Preserve all six. In particular BH retains
both bosonic inverse edges around Ku and gives a possible fifth edge.
There is no transfer of a zero from the different u Ja JL C target.

## Smallest competent test and boundaries

New exact SymPy exterior algebra evaluates these six groups on the same
12 D3/4/5, first/last-axis, two-seed noncommuting fixtures. Only the pure
data() generator is extracted from the authenticated old source; old
calculation drivers and their historical preparation checks are not run
or rebound. This is new work under current policy, not a historical replay.
Archived quantum outputs are prohibited native operands. The reviewer
then compares every heat coefficient with both previously qualified
paired-Hessian and full Schur outputs, and compares T sensitivities for
all omission controls. Pair exchanges must reverse T; equal directions
must give zero. All required aa/CC/W/Ku controls must be sensitive.

New polynomial/matrix code and coefficient representation differ from
the old coefficient-ring implementation. Fixture data, Gaussian premise,
source conventions, SymPy/Python and AI authorship remain shared. No
independent scientist or physical validation is claimed.

Freeze source copies and hashes before native/review. Native300s after
imports, review180s, 8GiB sampled private, 350MiB available-pagefile launch
floor, 32MiB packet. Any disagreement or missing group fails the candidate
reduction; exhaustion is incomplete. Preserve failed sources/captures and
version a correction rather than weakening the comparison.

Acceptance ceiling: a complete finite grade reduction corroborated on the
declared generic fixtures, not actual Spin(10) coefficients. A qualified
reduction permits the next model contraction; a discrepancy requires its
repair first. Current state/authority and all protected stages remain
unchanged. No full T/F, QAP, measure, causal or empirical claim.
