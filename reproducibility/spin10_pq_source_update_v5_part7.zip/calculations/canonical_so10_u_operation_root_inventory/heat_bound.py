from pathlib import Path
from hashlib import sha256
from collections import Counter, defaultdict
from itertools import combinations
import gzip
import json
import os
import re
import threading
import time

O = Path(__file__).resolve().parent
R = O.parents[1]
tick = time.perf_counter()
timer = threading.Timer(180, lambda: os._exit(124))
timer.daemon = True
timer.start()
read = lambda path: json.loads(path.read_bytes())
load = lambda path: json.loads(gzip.decompress(path.read_bytes()))
for path, digest in read(O / 'heat_preparation.json')['input_sha256'].items():
    assert sha256(Path(path).read_bytes()).hexdigest() == digest, path
assert read(O / 'validation_receipt.json')['all_routes_partitions_coefficients_and_aggregates_agree']
roots = load(O / 'root_primary_tables.json.gz')
root_patterns = sorted({(tuple(pattern), degree) for probe in roots['results']
                        for data in probe['targets'].values() for pattern, degree, output, rem, value in data['aggregate_flows']})
assert len(root_patterns) == 10
bounds = [[list(pattern), degree, len(pattern) + degree] for pattern, degree in root_patterns]
assert max(bound for pattern, degree, bound in bounds) == 4
new_roots = [('C', 'Ja', 'a'), ('C', 'C', 'JL', 'a'), ('C', 'C', 'JL', 'JL')]
dim = {'B': 1, 'x': 1, 'L': 2, 'C': 1, 'a': 1, 'JB': 2, 'Jx': 2, 'JL': 1, 'JC': 2, 'Ja': 2}
reports = []
for role in ['primary', 'replay']:
    d = load(R / ('calculations/canonical_so10_remaining_u_contact_vertices/vertices_' + role + '_inputs.json.gz'))
    xs = d['xs']
    aux = [('b' if i < 12 else 'L') + str(i) for i in range(45)]
    ants = [('bar' if i < 12 else 'ub') + str(i) for i in range(45)]
    ghosts = ['C' + str(i) for i in range(45)]
    vectors = [f'B{i}_{mu}' for i in range(45) for mu in range(4)]
    kinds = {name: kind for names, kind in [(xs, 'x'), (aux, 'L'), (ants, 'a'), (ghosts, 'C'), (vectors, 'B')] for name in names}
    physical = vectors + xs + aux + ghosts + ants
    frame = d['frame']
    for i, j, value in frame['physical_to_raw_inverse']['entries']:
        assert kinds[frame['field_order'][i]] == kinds[physical[j]]
    audit = d['audit']
    base = audit['geometry']['names']
    paired = {base[n] for f, J, h, k in audit['geometry']['field_source_h_k'] for n in [f, J]}
    backgrounds = sorted({audit['names'][n] for packet in audit['physical_QG'] for gp, word, ci in packet['monomials'] for n, jets in word if audit['names'][n] not in paired})
    assert all(re.fullmatch(r'A\d+_[0-3]', name) for name in backgrounds)
    source_map = load(R / ('calculations/canonical_so10_intrinsic_full_source_descent/map_' + role + '_tables.json.gz'))
    original = []
    for reference, row in enumerate(d['GF']):
        word = []
        for token in row['word']:
            name, sep, jets = token.partition('__')
            if name not in kinds:
                break
            word.append((kinds[name], jets, True))
        else:
            original.append(('GF', reference, word))
    for reference, (word, value) in enumerate(source_map['Sigma_source_nonminimal_C']):
        decoded = []
        for i in word:
            kind = 'JL' if i < 45 else 'Ja' if i < 90 else 'JC' if i < 135 else 'C' if i < 180 else 'a' if i < 225 else 'L'
            decoded.append((kind, '', i >= 135))
        original.append(('original_source', reference, decoded))
    envelope = defaultdict(list)
    free = Counter()
    free_refs = []
    excluded_one_port = []
    for family, reference, word in original:
        if 4 - sum(dim[kind] + len(jets) for kind, jets, field in word) != 0:
            continue
        port_positions = [at for at, token in enumerate(word) if token[2]]
        if len(port_positions) < 2:
            if any(token[0] in ['Ja', 'JL'] for token in word):
                excluded_one_port.append([family, reference, [token[0] for token in word]])
            continue
        if role == 'primary':
            choices = [(a, b) for a in port_positions for b in port_positions if a != b]
        else:
            choices = []
            for external in combinations(range(len(word)), len(word) - 2):
                quantum = [at for at in range(len(word)) if at not in external]
                if all(at in port_positions for at in quantum):
                    choices.extend([tuple(quantum), tuple(quantum[::-1])])
        for a, b in choices:
            rem = [token for at, token in enumerate(word) if at not in [a, b]]
            if any(jets for kind, jets, field in rem):
                continue
            types = Counter(kind for kind, jets, field in rem)
            eligible = [pattern for pattern in new_roots if not (types - Counter(pattern))]
            if not eligible:
                continue
            grade = len(rem)
            if grade == 0:
                assert len(word) == 2 and family == 'GF'
                signature = tuple(sorted((word[a][0], word[b][0])))
                derivative_order = len(word[a][1]) + len(word[b][1])
                assert (signature, derivative_order) in [(('B', 'L'), 1), (('L', 'L'), 0), (('C', 'a'), 2)]
                free[signature, derivative_order] += 1
                free_refs.append([family, reference, a, b])
                continue
            assert grade in [1, 2]
            for pattern in eligible:
                envelope[pattern].append([family, reference, a, b, grade,
                                          [word[a][0], len(word[a][1])], [word[b][0], len(word[b][1])],
                                          [kind for kind, jets, field in rem]])
    report = {'role': role, 'all_GF_density_rows': len(d['GF']),
              'all_original_nonminimal_source_density_rows': len(source_map['Sigma_source_nonminimal_C']),
              'background_symbols_explicitly_A0': backgrounds,
              'field_chart_preserves_types_and_positive_grade': True,
              'resummed_reference_port_classes': [[list(kind), jets, count] for (kind, jets), count in sorted(free.items())],
              'zero_grade_reference_refs': sorted(free_refs), 'source_one_port_exclusions': sorted(excluded_one_port),
              'positive_letter_envelope': [[list(pattern), sorted(rows)] for pattern, rows in sorted(envelope.items())]}
    reports.append(report)
first = {key: value for key, value in reports[0].items() if key != 'role'}
second = {key: value for key, value in reports[1].items() if key != 'role'}
assert first == second
# Existing qualified support covers both intrinsic roots and the measured
# two/three-edge root families. No quantum target is read before this proof.
old = read(R / 'calculations/canonical_so10_unprobed_source_root_module/heat_support_validation_receipt.json')
assert old['each_remaining_unprobed_native_root_maximum_heat'] == 4
source_coefficients_are_algebraic = all(isinstance(value, str) and 'log' not in value
                                      for probe in roots['results'] for target in probe['targets'].values()
                                      for pattern, degree, output, rem, value in target['aggregate_flows'])
assert source_coefficients_are_algebraic
# Late read of the qualified partial quantum coefficients, not native operands.
partial_path = R / 'calculations/canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz'
partial = load(partial_path)
protected = []
for probe in partial['results']:
    row = next(row for row in probe['partial_relations'] if row['basis'] == 'log5')
    coefficients = row['homogeneous_plus_Euler_partial']
    witnesses = {target: values[0] if values else None for target, values in coefficients.items()}
    if probe['probe'] == 1:
        assert all(values for values in coefficients.values())
    protected.append({'probe': probe['probe'], 'explicit_log5_nonzero': {target: len(values) for target, values in coefficients.items()},
                      'witnesses': witnesses, 'coefficient_tables': coefficients,
                      'native_Bu_C0_explicit_log5': {'T': 0, 'F': 0},
                      'whole_regulated_identity_not_inferred': True})
out = {'schema': 'UOR3_COMPLETE_NATIVE_HEAT_BOUND_AND_PROTECTED_T_F_LOG5',
       'all_actual_root_types_and_grade_bounds': bounds, 'new_marginal_support_applicability': reports,
       'all_QG_operation_coefficients_algebraic': True, 'protected_formal_coefficients': protected,
       'not_transcendence_anomaly_no_counterterm_or_E5_theorem': True}
raw = (json.dumps(out, sort_keys=True, separators=(',', ':')) + '\n').encode()
blob = gzip.compress(raw, mtime=0)
with (O / 'heat_bound_tables.json.gz').open('xb') as stream:
    stream.write(blob)
result = {'elapsed_after_imports': time.perf_counter() - tick,
          'packed_sha256': sha256(blob).hexdigest(), 'raw_sha256': sha256(raw).hexdigest(),
          'all_ten_native_root_heat_bounds_at_most_four': True,
          'actual_GF_source_ports_two_enumerations_agree': True,
          'new_marginal_classes': [list(pattern) for pattern in new_roots],
          'protected_explicit_log5_counts': [row['explicit_log5_nonzero'] for row in protected],
          'not_full_quantum_restoration_or_anomaly': True}
with (O / 'heat_bound_validation_receipt.json').open('xb') as stream:
    stream.write((json.dumps(result, sort_keys=True, separators=(',', ':')) + '\n').encode())
print('RESULT ' + json.dumps(result, sort_keys=True), flush=True)
timer.cancel()
