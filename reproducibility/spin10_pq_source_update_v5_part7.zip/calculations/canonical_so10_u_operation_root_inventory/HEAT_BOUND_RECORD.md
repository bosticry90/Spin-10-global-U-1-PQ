# UOR3: complete native heat ceiling and explicit formal log5 consequence

Prospective after UOR2. Ten actual root types survive in B_u C0. Before
launching their missing component calculations, test whether any can
alter the formal log5 component of the retained T/F partial relation.
This can redirect work without evaluating a large unnecessary tensor.

For each unprobed root, use positive grade = number of external field/
source occurrences plus intrinsic coefficient degree. The fully resummed
original free G0 has grade0. Every remaining Hessian vertex must consume
positive grade. Hence a contributing proper Born word has at most that
many heat edges. The two intrinsic native roots already have qualified
complete four-edge support; the other known roots have two/three-edge
kernels. Reuse their domain/reference qualifications, not their measured
values as fitted quantum inputs.

Check applicability in the three newly reached marginal classes:
Ja a C,JL a C C,and JL JL C C. Inspect every raw GF density row and the
actual original nonminimal source density. Enumerate all possible ordered
quantum-port pairs versus external-first complement choices. The catalogue
is an overinclusive support envelope: no cancellation or nonzero amplitude
is inferred from its entries. All non-reference eligible letters must
carry1 or2 external grades. Zero-grade two-port GF terms must be among
the already resummed reference classes; source Ja Lambda is one-port and
cannot be treated as a proper loop. Raw field-chart transport must preserve
field types and therefore these grades. Scalar/fermion/potential physical
vertices have no nonminimal source/ghost means and cannot add a gradezero
interaction to this envelope: their zero-field quadratic reference is
resummed, while external B/x/fermion means vanish for these marginal
targets. In the intrinsic root classes use the previously qualified full
support, including physical/potential/fermion supersets.

Verify every excluded non-dynamic QG symbol is an actual background A
component. Since it is not a differentiated field/source pair, it remains
in the word and vanishes at A0. No generic unknown-role exclusion is
silently interpreted as a physical zero.

For all ten roots the maximum grade is4. Under the inherited local
DIM-minus-heat rule, m edges give chi4+log(m/2) and algebraic dimensional
terms. m<=4 cannot introduce explicit log5. Actual QG operation coefficients
are polynomial/algebraic and do not introduce a logarithm. Therefore the
explicit log5 vector in B_u C0 is zero in the retained formal basis.

Only AFTER the support/grade proof is completed read the authenticated UPM
partial T/F log5 tensors. Their exact explicit-log5 coefficients then
remain unchanged by all native B_u C0 roots. Preserve the coefficient
tables/hashes and a nonzero witness in each family, rather than compare
counts alone. No quantum root is assigned a value from that remainder.

This does not prove transcendental independence after choosing chi4,
absence of a counterterm, a physical anomaly or failure of Spin(10).
It identifies a missing regulated/source/product or legitimate finite
normalization contribution for a full identity. Such a contribution must
be derived from the actual construction, not fitted. No normalization,
scheme, foundation, H-basic/C5 activation or scientific promotion.

One180s review afterimports,8GiB sampled,350MiB launch floor,32MiBpacket.
Freeze source copies and input bindings first; preserve failure. The
existing native matrices are reused, not recalculated. Shared action,
source conventions, reference, software and AI authorship remain limits.
