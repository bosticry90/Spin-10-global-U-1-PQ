from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import Counter, defaultdict
from functools import lru_cache
import gzip
import json
import os
import sys
import threading
import time
import sympy as s

O = Path(__file__).resolve().parent
R = O.parents[1]
tick = time.perf_counter()
timer = threading.Timer(180, lambda: os._exit(124))
timer.daemon = True
timer.start()
read = lambda path: json.loads(path.read_bytes())
load = lambda path: json.loads(gzip.decompress(path.read_bytes()))
for path, digest in read(O / 'review_preparation.json')['input_sha256'].items():
    assert sha256(Path(path).read_bytes()).hexdigest() == digest, path
sys.path.insert(0, str(R / 'calculations/canonical_so10_intrinsic_full_source_descent'))
from coefficient_ring import coefficient, Coeff, constant, I
g, xi, eta = s.symbols('g10 xi eta_H', real=True)


@lru_cache(None)
def co(value):
    return coefficient(s.expand(s.sympify(value, locals={'g10': g, 'xi': xi, 'eta_H': eta})))


primary, replay = [load(O / ('root_' + role + '_tables.json.gz')) for role in ['primary', 'replay']]
assert primary['results'] == replay['results']
assert primary['root_candidate_catalog'] == replay['root_candidate_catalog']
assert primary['field_source_pairs'] == replay['field_source_pairs'] == 643
raw = load(R / 'calculations/canonical_so10_remaining_u_contact_vertices/vertices_primary_inputs.json.gz')
audit = raw['audit']
names, geo = audit['names'], audit['geometry']
base = geo['names']
name_id = {name: index for index, name in enumerate(names)}
xs = set(raw['xs'])
aux = {('b' if i < 12 else 'L') + str(i) for i in range(45)}
ants = {('bar' if i < 12 else 'ub') + str(i) for i in range(45)}
types, parity, field_parity, phases, conjugate, sources = {}, {}, {}, {}, {}, set()
for f, J, h, k in geo['field_source_h_k']:
    field, source = base[f], base[J]
    kind = 'x' if field in xs else 'L' if field in aux else 'a' if field in ants else 'B' if field.startswith('B') else 'C'
    fi, ji = name_id[field], name_id[source]
    types[fi], types[ji] = kind, 'J' + kind
    parity[fi], parity[ji] = geo['parities'][f], geo['parities'][J]
    field_parity[fi] = field_parity[ji] = parity[fi]
    conjugate[fi], conjugate[ji] = ji, fi
    sources.add(ji)
    field_phase = -I if kind == 'L' else I if kind == 'B' and field.endswith('_0') else constant(1)
    inverse_phase = field_phase if field_phase * field_phase == 1 else -field_phase
    assert field_phase * inverse_phase == 1
    source_phase = ((-1) ** (parity[fi] + 1)) * inverse_phase
    assert field_phase * source_phase == (-1) ** (parity[fi] + 1)
    phases[fi], phases[ji] = field_phase, source_phase


def canonical(word):
    odds = [n for n in word if parity[n]]
    if len(odds) != len(set(odds)):
        return (), 0
    sign = (-1) ** sum(a > b for at, a in enumerate(odds) for b in odds[at + 1:])
    return tuple(sorted(word)), sign


def raw_coefficient(packet, gp, ci):
    return Coeff([((gp, xp, ep, mask), Fraction(num, den)) for xp, ep, mask, num, den in packet['coefficients'][ci]])


# Literal even-QG fixture: Sigma=i Ja JL C, with Ja even and JL/C odd.
Ja, JL, C = 0, 1, 2
fixture_parity = {Ja: 0, JL: 1, C: 1}
word = (Ja, JL, C)
left, right = {}, {}
for at, port in enumerate(word):
    prefix = sum(fixture_parity[n] for n in word[:at])
    suffix = sum(fixture_parity[n] for n in word[at + 1:])
    left[port] = I * ((-1) ** (fixture_parity[port] * prefix))
    right[port] = I * ((-1) ** (fixture_parity[port] * suffix))
assert left == {Ja: I, JL: I, C: -I}
assert right == {Ja: I, JL: -I, C: I}
assert -left[Ja] == -I and left[JL] == I and -left[C] == I
assert sum((-constant(1) for at in [0, 1]), 0) * (-1) == 2

dim = {'B': 1, 'x': 1, 'L': 2, 'C': 1, 'a': 1, 'JB': 2, 'Jx': 2, 'JL': 1, 'JC': 2, 'Ja': 2}
gh = {'B': 0, 'x': 0, 'L': 0, 'C': 1, 'a': -1, 'JB': -1, 'Jx': -1, 'JL': -1, 'JC': -2, 'Ja': 0}
targets = {'T': Counter(['Ja', 'C', 'x']), 'F': Counter(['JL', 'C', 'C', 'x'])}
reports = []
for probe, packet in enumerate(audit['physical_QG']):
    result = primary['results'][probe]
    assert len(result['monomial_partition']) == len(packet['monomials'])
    assert [row[0] for row in result['monomial_partition']] == list(range(len(packet['monomials'])))
    inventory = Counter(sum(n in sources for n, jets in word) for gp, word, ci in packet['monomials'])
    assert {str(key): value for key, value in inventory.items()} == result['full_QG_source_inventory']
    selected = {row['monomial'] for target in result['targets'].values() for row in target['routes']}
    density = defaultdict(lambda: 0)
    for index in selected:
        gp, tokens, ci = packet['monomials'][index]
        assert all(not jets for n, jets in tokens)
        word = tuple(n for n, jets in tokens)
        normalized, sign = canonical(word)
        value = -raw_coefficient(packet, gp, ci) * sign
        for n in word:
            value = value * phases[n]
        density[normalized] += value
    groups = {target: defaultdict(lambda: 0) for target in targets}
    for word, value in density.items():
        if not value:
            continue
        degree_qg = 4 - sum(dim[types[n]] for n in word)
        for at, port in enumerate(word):
            rem, sign = canonical(word[:at] + word[at + 1:])
            exponent = parity[port] * sum(parity[n] for n in word[:at]) + field_parity[port]
            flow = value * sign * ((-1) ** exponent)
            remainder = Counter(types[n] for n in rem)
            for target, target_count in targets.items():
                if remainder - target_count:
                    continue
                pattern = tuple(sorted(list((target_count - remainder).elements()) + [types[conjugate[port]]]))
                degree = 4 - sum(dim[key] for key in pattern)
                if degree < 0 or sum(key in ['B', 'JB'] for key in pattern) % 2:
                    continue
                assert degree + degree_qg == 1 and sum(gh[key] for key in pattern) == 0
                groups[target][pattern, degree, names[conjugate[port]], tuple(names[n] for n in rem)] += flow
    target_reports = {}
    for target, data in result['targets'].items():
        expected = {(tuple(pattern), degree, output, tuple(rem)): co(value) for pattern, degree, output, rem, value in data['aggregate_flows']}
        actual = {key: value for key, value in groups[target].items() if value}
        assert actual == expected, (probe, target)
        controls = {'missing_even_QG_right_conversion': sum(row['missing_even_QG_right_conversion_changes_sign'] for row in data['routes']),
                    'omitting_source_Wick_phases': sum(row['omitting_source_Wick_phases_changes_coefficient'] for row in data['routes']),
                    'omit_QG_source_degree_routes': dict(Counter(row['QG_source_degree'] for row in data['routes']))}
        roots = sorted({tuple(pattern) for pattern, degree, output, rem, value in data['aggregate_flows']})
        assert all(sum(key in ['B', 'JB'] for key in pattern) % 2 == 0 for pattern in roots)
        target_reports[target] = {'routes': len(data['routes']), 'nonzero_aggregate_flows': len(expected),
                                  'zero_after_aggregation': data['zero_after_aggregation'],
                                  'root_summaries': data['nonzero_flows_by_root'], 'controls': controls,
                                  'excluded_vector_routes': len(data['excluded_unpaired_vector_routes'])}
    reports.append({'probe': probe, 'all_QG_monomials': len(packet['monomials']), 'source_inventory': dict(inventory),
                    'partition_dispositions': dict(Counter(row[1] for row in result['monomial_partition'])),
                    'targets': target_reports})
for role in ['primary', 'replay']:
    record = read(O / ('root_' + role + '_result.json'))
    raw = (O / ('root_' + role + '_tables.json.gz')).read_bytes()
    assert sha256(raw).hexdigest() == record['packed_sha256']
    assert sha256(gzip.decompress(raw)).hexdigest() == record['raw_sha256']
out = {'elapsed_after_imports': time.perf_counter() - tick,
       'all_routes_partitions_coefficients_and_aggregates_agree': True,
       'density_first_Wick_then_left_derivative_all_surviving_monomials_agree': True,
       'all643_cotangent_Wick_pairs_and_nonzero_sign_multiplicity_fixtures': True,
       'reports': reports, 'quantum_root_values_full_T_F_or_E5_claim': False}
with (O / 'validation_receipt.json').open('xb') as stream:
    stream.write((json.dumps(out, sort_keys=True, separators=(',', ':')) + '\n').encode())
print('RESULT ' + json.dumps({key: value for key, value in out.items() if key != 'reports'}, sort_keys=True), flush=True)
timer.cancel()
