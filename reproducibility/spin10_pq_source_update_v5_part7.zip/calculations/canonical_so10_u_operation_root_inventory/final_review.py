from pathlib import Path
from hashlib import sha256
import gzip
import json
import time

O = Path(__file__).resolve().parent
R = O.parents[1]
C = Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-operation-root-inventory-v1-2026-10-26')
read = lambda path: json.loads(path.read_bytes())
load = lambda path: json.loads(gzip.decompress(path.read_bytes()))
tick = time.perf_counter()
for path, digest in read(O / 'final_preparation.json')['input_sha256'].items():
    assert sha256(Path(path).read_bytes()).hexdigest() == digest, path
bindings = 0
for name in ['preparation', 'review_preparation', 'heat_preparation']:
    for path, digest in read(O / (name + '.json'))['input_sha256'].items():
        assert sha256(Path(path).read_bytes()).hexdigest() == digest, path
        bindings += 1
sources = list(O.glob('*.source.txt'))
for path in sources:
    assert path.read_bytes() == path.with_name(path.name[:-11]).read_bytes(), path
peak = 0
for name in ['root_primary', 'root_replay', 'review', 'heat']:
    capture = read(O / (name + '_capture.json'))
    assert capture['exit_code'] == 0 and capture['execution_state'] == 'COMPLETED'
    assert capture['calculation_completed'] and capture['post_run_observations_qualified']
    assert capture['launch']['memory']['available_pagefile'] >= 350 * 1024 ** 2
    peak = max(peak, max(row['private_bytes'] for row in capture['all_resource_samples']))
    assert (O / (name + '_capture.json')).read_bytes() == (C / (name + '_full_capture.json')).read_bytes()
assert peak <= 8 * 1024 ** 3
for role in ['primary', 'replay']:
    result = read(O / ('root_' + role + '_result.json'))
    raw = (O / ('root_' + role + '_tables.json.gz')).read_bytes()
    assert sha256(raw).hexdigest() == result['packed_sha256']
    assert sha256(gzip.decompress(raw)).hexdigest() == result['raw_sha256']
primary, replay = [load(O / ('root_' + role + '_tables.json.gz')) for role in ['primary', 'replay']]
assert primary['results'] == replay['results']
assert read(O / 'validation_receipt.json')['density_first_Wick_then_left_derivative_all_surviving_monomials_agree']
heat_record = read(O / 'heat_bound_validation_receipt.json')
raw = (O / 'heat_bound_tables.json.gz').read_bytes()
assert sha256(raw).hexdigest() == heat_record['packed_sha256']
assert sha256(gzip.decompress(raw)).hexdigest() == heat_record['raw_sha256']
heat = json.loads(gzip.decompress(raw))
bounds = heat['all_actual_root_types_and_grade_bounds']
assert len(bounds) == 10 and all(bound == len(pattern) + degree <= 4 for pattern, degree, bound in bounds)
first, second = heat['new_marginal_support_applicability']
assert {key: value for key, value in first.items() if key != 'role'} == {key: value for key, value in second.items() if key != 'role'}
assert first['all_GF_density_rows'] == 33092 and first['all_original_nonminimal_source_density_rows'] == 4894
assert all(row[4] in [1, 2] for pattern, rows in first['positive_letter_envelope'] for row in rows)
old = load(R / 'calculations/canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz')
for index, protected in enumerate(heat['protected_formal_coefficients']):
    coefficients = next(row['homogeneous_plus_Euler_partial'] for row in old['results'][index]['partial_relations'] if row['basis'] == 'log5')
    assert protected['coefficient_tables'] == coefficients
    assert protected['native_Bu_C0_explicit_log5'] == {'T': 0, 'F': 0}
e4 = read(C / 'e4_full_capture.json')
events = [json.loads(line) for line in e4['stdout'].splitlines() if line.startswith('{')]
steps = [row['exit_code'] for row in events if row.get('event') == 'step_finished']
assert e4['exit_code'] == 0 and steps == [0, 0, 0, 0, 0, 2]
assert [row for row in events if row.get('event') == 'terminal'][0]['execution_state'] == 'COMPLETED'
assert sum(path.stat().st_size for path in O.iterdir() if path.is_file()) < 32 * 1024 ** 2
result = {'elapsed_after_imports': time.perf_counter() - tick,
          'preparation_bindings_authenticated': bindings, 'source_copies_equal': len(sources),
          'four_completed_captures_authenticated': True, 'largest_sampled_private_bytes': peak,
          'all_QG_route_and_density_first_coefficients_checked': True,
          'complete_ten_root_native_heat_bound_authenticated': True,
          'protected_log5_vectors_equal_actual_prior_partial_coefficients': True,
          'protected_counts': heat_record['protected_explicit_log5_counts'],
          'E4_step_exits': steps, 'custody': 'EXIT2_SEVEN_UNRESOLVED_NOTPASS',
          'anomaly_no_counterterm_full_QAP_or_E5_claim': False}
with (O / 'final_review_validation_receipt.json').open('xb') as stream:
    stream.write((json.dumps(result, sort_keys=True, separators=(',', ':')) + '\n').encode())
print('RESULT ' + json.dumps(result, sort_keys=True), flush=True)
