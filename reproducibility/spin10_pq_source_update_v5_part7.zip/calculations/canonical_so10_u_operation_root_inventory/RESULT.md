# Native unprobed roots cannot remove the retained explicit log5 T/F component

PROGRESS. The actual B_u C0 root inventory is complete in the declared
projection. Ten root types survive. Their native heat ceiling is at most
four, so none can alter the explicit log5 coefficient in the retained
formal basis. Completing those native inputs alone cannot make that
formal group vanish. This is a bounded restriction, not an anomaly,
no-counterterm theorem or completed quantum identity.

The next priority is the actual regulated u Ward/source response and its
applicability, rather than more native tensors as an attempted log5
cancellation. No missing quantum value was fitted to the partial remainder.
State113,authority34/39,E5/A5 OPEN remain unchanged.

## Complete actual operation inventory

Same original SMA/CSW/EDS,A0,constant probes,zero external jets and
nonexceptional Euclidean LOCAL RELATIVE construction. C0 is unprobed;
the two probes enter its original u operation, not a changed physical
benchmark. All parameters remain symbolic and normalization freedoms
distinct/unfixed. The targets are uJa Cx and uJL CCx at intrinsic1.

Both complete physical_QG arrays are scanned, with all643 field/source
pairs and every source degree retained:

| Probe | QG source0 | Source1 | Source2 | All monomials |
| --- | ---: | ---: | ---: | ---: |
| 0 | 10,300 | 660 | 12 | 10,972 |
| 1 | 81,339 | 5,741 | 1,705 | 88,785 |

Primary target subtraction/left differentiation and replay independent
root-pattern enumeration/right differentiation agree on every reference,
coefficient, exclusion and aggregate. The latter corrects right-to-left
derivatives of EVEN QG; copying the rho/odd-G formula would be incorrect.
A third route forms the Euclidean canonical density first, derives source
Wick phases from the cotangent pairing, then left-differentiates all
surviving monomials. Its full aggregates agree as well. Nonzero fixtures
and repeated even-source multiplicities are checked. [UOR2 receipt](validation_receipt.json).

The root catalogue has46 preliminary dimension/ghost/parity patterns,
not46 independent operators or needed quantum calculations. Actual
nonzero operation flows reach the following ten types:

| C0 root type | Intrinsic degree | T flows,probe1 | F flows,probe1 | Maximum heat |
| --- | ---: | ---: | ---: | ---: |
| JL JL C C | 0 | 0 | 296 | 4 |
| JL a C C | 0 | 0 | 296 | 4 |
| Ja JL C | 0 | 296 | 5,248 | 3 |
| JL C x | 1 | 33 | 0 | 4 |
| Ja a C | 0 | 296 | 0 | 3 |
| Jx C x | 0 | 296 | 0 | 3 |
| a C x | 1 | 33 | 0 | 4 |
| Ja Ja | 0 | 5,248 | 0 | 2 |
| Ja x | 1 | 600 | 3,344 | 3 |
| Lambda x | 1 | 0 | 3,344 | 3 |

Probe0 reaches only JL Cx and aCx in T,12 flows each; no F route survives.
Raw derivative occurrences are36/0 for probe0 T/F and6835/12528 for
probe1. Combining repeated occurrences gives24/0 and6802/12528 flows,
respectively. These are classical operation coefficients, not nonzero
loop amplitudes. Root values require exact reuse or measurement decisions;
the inventory does not supply them.

Every excluded non-dynamic QG symbol is verified to be a background A
component. It cannot be removed by the physical field/source derivative
and vanishes at A0. Positive external jets and out-of-domain intrinsic
degrees retain explicit references. No unexplained unknown field was
discarded as zero. No unpaired-vector candidate survived.

Controls quantify the known operation errors: in probe1 the missing
even-QG derivative conversion affects5848 T and11936 F route coefficients;
omitting source Wick phases affects6688 F routes. Source-phase omission
is insensitive for T and probe0,as recorded. Removing source-degree0/1/2
loses5544/1225/66 T routes and5544/3640/3344 F routes in probe1. Those
are support/operation controls,not quantum-amplitude detectors.

## Heat ceiling and its applicability

The independent positive grade is external-field/source count plus
intrinsic degree. Free G0 is already fully resummed. Each remaining
interaction consumes positive grade, so a complete proper Born word has
at most the root's total grade. No source is a fluctuation propagator.

Previously qualified full support covers the intrinsic roots, including
physical/potential/fermion supersets. For the three newly reached marginal
classes Ja aC,JL aCC,JLJLCC, the proof additionally inspects all33092 GF
density rows and4894 actual original nonminimal source-density rows.
Quantum-port-first and external-complement-first enumerations agree on
their overinclusive envelopes of50460/72456/24928 oriented port entries.
Every retained non-reference letter has grade1 or2. This is an upper
support envelope, not a count of nonzero Hessian coefficients or diagrams.

Zero-grade GF two-port classes are precisely the resummed reference
B-Lambda,ghost-antighost and Lambda-Lambda entries,with derivative
orders1/2/0. Their376/376/52 oriented references remain recorded. All45
source Ja-Lambda one-port terms are retained as exclusions from proper
loops. The actual field chart preserves field types and hence this
grading. Physical vertices introduce no additional gradezero interaction
for these nonminimal marginal targets; their zero-field quadratic part
is resummed and other physical means vanish in the projection.
[Prospective proof and limitations](HEAT_BOUND_RECORD.md).

The inherited normalized m-edge relative rule is chi4+log(m/2),with
algebraic dimensional terms. With m<=4, only explicit log2/log3 can occur.
The independently derived QG operation coefficients are algebraic,so
they introduce no logarithm. Consequently B_u C0 has no explicit log5
vector in this fixed formal representation,whatever the still unknown
native coefficients within this family turn out to be.

## Late protected-coefficient comparison

Only after the support/grade proof does the calculation read the qualified
UPM homogeneous-plus-Euler partial tensors. All their explicit-log5
coefficients are preserved in heat_bound_tables.json.gz,not merely counts:

| Probe | T nonzero positions | F nonzero positions |
| --- | ---: | ---: |
| 0 | 0 | 0 |
| 1 | 12,432 | 197,652 |

Nonzero exact witnesses are

    T[13,0,137] = -sqrt6 eta_H g10^4 xi/16,
    F[13,0,12,136] = -3i sqrt15 eta_H g10^5 xi/80.

Common hbar/(16pi²) is understood. These coordinates are not physical
parameter choices or a source-reality assertion. [UOR3 receipt](heat_bound_validation_receipt.json).

## Focused result-to-claim assessment

**Supported claim.** Completing native B_u C0 roots cannot remove these
explicit-log5 coefficient vectors in the retained chi4/log2/log3/log5
basis. This excludes a native-only route to formal cancellation and
redirects effort toward the missing regulated construction.

**Unresolved bridge.** A complete quantum identity also needs regulator,
reference,source-product,measure and applicability terms where required.
An admissible finite normalization may be another issue to construct
explicitly. No such term is supplied by this proof. It does not establish
transcendental independence after selecting chi4,no possible counterterm,
an anomaly, failure of Spin(10), or full QAP. A valid correction, a precise
underdefinition or an actual incompatibility are all possible outcomes.
The other native chi4/log2/log3 coefficients remain unknown where not
already measured; the heat ceiling does not calculate them.

**Capability and shared risks.** Exact operation enumeration and grading
avoid tensor expansions that could not settle the identified log5 gap.
Different complement and differentiation orders expose source/Wick errors.
The action,reference,field charts,coefficient ring,software and AI author
remain shared; no independent scientist,proof assistant or experiment
validates their physical premises. The result is conditional on that
declared formal quantum family,not external physical confirmation.

**Next discriminating action.** Derive the finite regulated u source/Ward
operator from the actual augmented action with QG at source degrees0/1/2,
the original G companion and the fixed reference. Keep mixed Hessians,
source dependence of field flows,Jacobian/reference response and heat
ordering. Establish its finite operator identity/applicability before
extracting a model log5 term. Never infer it as minus the retained vector.

## Execution and preservation

After-import seconds:inventory7.7362/5.4781,review3.2269,heat proof10.4177.
All four captures COMPLETED/native0,no failed native. Largest pre-final
sampled private allocation499879936B,not a continuous peak. Packet3088572B
before this report. Limits300s native/180s review,8GiB sampled private,
350MiB launch floor,32MiBpacket respected. Read-only filename/wildcard
lookups were corrected; no scientific input or requirement changed.

E4 completed once,native0,steps[0,0,0,0,0,2],28.0940s. It authenticates
sealed evidence/declared bounded audits,not fresh global scientific
replay or custody PASS. Historical custody remains exit2/seven unresolved.
Final input/source/resource review and exact Git byte checks accompany
local commit. Old calculations,contracts,receipts,failed runs and hashes
remain intact. This result is frozen before final review.

project_state SHA256 remains
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8.
No foundation,scheme,normalization or physical benchmark adoption,
flavor/HB1/C5 activation,scientific promotion,branch/worktree,publication,
outreach or remote action. The full investigation remains ACTIVE/incomplete.
