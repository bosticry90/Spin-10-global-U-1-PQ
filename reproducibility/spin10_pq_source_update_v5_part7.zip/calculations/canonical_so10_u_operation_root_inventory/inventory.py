from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import Counter, defaultdict
from itertools import combinations_with_replacement
import gzip
import json
import os
import sys
import threading
import time

O = Path(__file__).resolve().parent
R = O.parents[1]
role = sys.argv[1]
assert role in ['primary', 'replay']
tick = time.perf_counter()
timer = threading.Timer(300, lambda: os._exit(124))
timer.daemon = True
timer.start()
read = lambda path: json.loads(path.read_bytes())
load = lambda path: json.loads(gzip.decompress(path.read_bytes()))
for path, digest in read(O / 'preparation.json')['input_sha256'].items():
    assert sha256(Path(path).read_bytes()).hexdigest() == digest, path


def guard(event, args):
    if event == 'open' and args and isinstance(args[0], (str, bytes)):
        path = Path(os.fsdecode(args[0]))
        peer = 'replay' if role == 'primary' else 'primary'
        if path.parent.resolve() == O and path.name.startswith('root_' + peer):
            raise PermissionError('UOR1_PEER_OUTPUT_DENIED')
        if path.parent.name == 'canonical_so10_u_pair_contact_model' or (path.parent.name == 'canonical_so10_intrinsic_full_source_descent' and path.name.startswith('variation')):
            raise PermissionError('UOR1_QUANTUM_REMAINDER_DENIED')


sys.addaudithook(guard)
sys.path.insert(0, str(R / 'calculations/canonical_so10_intrinsic_full_source_descent'))
from coefficient_ring import Coeff, constant, I

dim = {'B': 1, 'x': 1, 'L': 2, 'C': 1, 'a': 1,
       'JB': 2, 'Jx': 2, 'JL': 1, 'JC': 2, 'Ja': 2}
ghost = {'B': 0, 'x': 0, 'L': 0, 'C': 1, 'a': -1,
         'JB': -1, 'Jx': -1, 'JL': -1, 'JC': -2, 'Ja': 0}
parity = {'B': 0, 'x': 0, 'L': 0, 'C': 1, 'a': 1,
          'JB': 1, 'Jx': 1, 'JL': 1, 'JC': 0, 'Ja': 0}
conj_type = {key: 'J' + key for key in ['B', 'x', 'L', 'C', 'a']}
conj_type.update({value: key for key, value in list(conj_type.items())})
targets = {'T': ('C', 'Ja', 'x'), 'F': ('C', 'C', 'JL', 'x')}
catalog = []
for length in range(1, 5):
    for pattern in combinations_with_replacement(sorted(dim), length):
        degree = 4 - sum(dim[key] for key in pattern)
        if degree not in [0, 1] or sum(ghost[key] for key in pattern) != 0 or sum(parity[key] for key in pattern) % 2:
            continue
        if sum(key.startswith('J') for key in pattern) > 2:
            continue
        catalog.append((pattern, degree))
lookups = {}
for target, target_word in targets.items():
    table = defaultdict(list)
    target_count = Counter(target_word)
    for pattern, degree in catalog:
        for port in set(pattern):
            rest = Counter(pattern)
            rest.subtract([port])
            rest = +rest
            if rest - target_count:
                continue
            needed = tuple(sorted((target_count - rest).elements()))
            table[conj_type[port], needed].append((pattern, degree))
    assert all(len(value) == 1 for value in table.values())
    lookups[target] = table

d = load(R / ('calculations/canonical_so10_remaining_u_contact_vertices/vertices_' + role + '_inputs.json.gz'))
audit = d['audit']
names = audit['names']
geometry = audit['geometry']
base = geometry['names']
ni = {name: index for index, name in enumerate(names)}
xs = set(d['xs'])
aux = {('b' if index < 12 else 'L') + str(index) for index in range(45)}
ants = {('bar' if index < 12 else 'ub') + str(index) for index in range(45)}
cs = {'C' + str(index) for index in range(45)}
bs = {f'B{index}_{mu}' for index in range(45) for mu in range(4)}
types, conjugate, pp, field_parity, phases, source_ids = {}, {}, {}, {}, {}, set()
for f, J, h, k in geometry['field_source_h_k']:
    name, source = base[f], base[J]
    kind = 'x' if name in xs else 'L' if name in aux else 'a' if name in ants else 'C' if name in cs else 'B' if name in bs else None
    assert kind is not None, name
    fi, ji = ni[name], ni[source]
    types[fi], types[ji] = kind, 'J' + kind
    conjugate[fi], conjugate[ji] = ji, fi
    pp[fi], pp[ji] = geometry['parities'][f], geometry['parities'][J]
    assert pp[fi] == parity[kind] and pp[ji] == parity['J' + kind]
    field_parity[fi] = field_parity[ji] = pp[fi]
    source_ids.add(ji)
    phase_field = -I if kind == 'L' else I if kind == 'B' and name.endswith('_0') else constant(1)
    phase_source = -I if kind == 'L' else I if kind == 'B' and name.endswith('_0') else constant(-1) if kind in ['B', 'x'] else constant(1)
    assert phase_field * phase_source == (-1) ** (pp[fi] + 1)
    phases[fi], phases[ji] = phase_field, phase_source
assert len(source_ids) == 643


def canonical(word):
    odd = [n for n in word if pp[n]]
    if len(odd) != len(set(odd)):
        return (), 0
    sign = (-1) ** sum(a > b for at, a in enumerate(odd) for b in odd[at + 1:])
    return tuple(sorted(word)), sign


def raw_coefficient(packet, gp, ci):
    return Coeff([((gp, xp, ep, mask), Fraction(num, den))
                  for xp, ep, mask, num, den in packet['coefficients'][ci]])


def route_value(packet, gp, ci, word, at):
    port = word[at]
    phase = constant(-1)
    no_sources = constant(-1)
    for n in word:
        phase = phase * phases[n]
        if n not in source_ids:
            no_sources = no_sources * phases[n]
    prefix = word[:at] if role == 'primary' else word[at + 1:]
    power = pp[port] * sum(pp[n] for n in prefix) + field_parity[port]
    if role == 'replay':
        power += pp[port]
    rem, sign = canonical(word[:at] + word[at + 1:])
    coefficient = raw_coefficient(packet, gp, ci)
    value = coefficient * phase * ((-1) ** power) * sign
    without_source_phase = coefficient * no_sources * ((-1) ** power) * sign
    return rem, value, without_source_phase


results = []
for probe, packet in enumerate(audit['physical_QG']):
    source_inventory = Counter()
    partition = []
    found = {target: [] for target in targets}
    aggregates = {target: defaultdict(lambda: 0) for target in targets}
    excluded_vectors = {target: [] for target in targets}
    for reference, (gp, tokens, ci) in enumerate(packet['monomials']):
        source_degree = sum(n in source_ids for n, jets in tokens)
        source_inventory[source_degree] += 1
        if any(n not in types for n, jets in tokens):
            partition.append([reference, 'outside_dynamic_A0_domain', source_degree, None])
            continue
        if any(jets for n, jets in tokens):
            partition.append([reference, 'nonzero_external_jet', source_degree, None])
            continue
        word = tuple(n for n, jets in tokens)
        assert sum(ghost[types[n]] for n in word) == 0
        assert sum(pp[n] for n in word) % 2 == 0
        intrinsic = 4 - sum(dim[types[n]] for n in word)
        if intrinsic not in [0, 1]:
            partition.append([reference, 'outside_complementary_nonnegative_intrinsic_domain', source_degree, intrinsic])
            continue
        matches = 0
        for at, port in enumerate(word):
            rem = word[:at] + word[at + 1:]
            rem_types = tuple(sorted(types[n] for n in rem))
            for target, target_word in targets.items():
                if role == 'primary':
                    rem_count, target_count = Counter(rem_types), Counter(target_word)
                    if rem_count - target_count:
                        continue
                    pattern = tuple(sorted(list((target_count - rem_count).elements()) + [types[conjugate[port]]]))
                    degree = 4 - sum(dim[key] for key in pattern)
                    if degree < 0:
                        continue
                else:
                    possible = lookups[target].get((types[port], rem_types), [])
                    if not possible:
                        continue
                    pattern, degree = possible[0]
                assert intrinsic + degree == 1
                assert sum(ghost[key] for key in pattern) == 0 and sum(parity[key] for key in pattern) % 2 == 0
                assert sum(key.startswith('J') for key in pattern) == 2 - source_degree
                assert dim[types[port]] + dim[types[conjugate[port]]] == 3
                canonical_rem, value, wrong_phase = route_value(packet, gp, ci, word, at)
                record = {'monomial': reference, 'derivative_position': at,
                          'QG_source_degree': source_degree, 'QG_intrinsic_degree': intrinsic,
                          'C0_root_type': list(pattern), 'C0_intrinsic_degree': degree,
                          'removed_symbol': names[port], 'flow_output': names[conjugate[port]],
                          'flow_remaining_symbols': [names[n] for n in canonical_rem],
                          'flow_coefficient': str(value), 'QG_word': tokens,
                          'missing_even_QG_right_conversion_changes_sign': bool(value) and bool(pp[port]),
                          'omitting_source_Wick_phases_changes_coefficient': value != wrong_phase}
                if sum(key in ['B', 'JB'] for key in pattern) % 2:
                    record['reason'] = 'unpaired_vector_port_not_a_zerojet_Lorentz_scalar'
                    excluded_vectors[target].append(record)
                    continue
                found[target].append(record)
                aggregates[target][pattern, degree, conjugate[port], canonical_rem] += value
                matches += 1
        partition.append([reference, 'retained_derivative_routes' if matches else 'no_admissible_target_complement', source_degree, intrinsic])
    targets_out = {}
    for target in targets:
        nonzero = {key: value for key, value in aggregates[target].items() if value}
        rows = [[list(pattern), degree, names[output], [names[n] for n in rem], str(value)]
                for (pattern, degree, output, rem), value in sorted(nonzero.items())]
        counts = Counter((tuple(row[0]), row[1]) for row in rows)
        targets_out[target] = {'routes': found[target], 'aggregate_flows': rows,
                               'excluded_unpaired_vector_routes': excluded_vectors[target],
                               'nonzero_flows_by_root': [[list(pattern), degree, count] for (pattern, degree), count in sorted(counts.items())],
                               'zero_after_aggregation': len(aggregates[target]) - len(nonzero)}
    results.append({'probe': probe, 'all_QG_monomials': len(packet['monomials']),
                    'full_QG_source_inventory': dict(source_inventory), 'monomial_partition': partition,
                    'targets': targets_out})
    print('STAGE UOR1', role, probe,
          {target: {'routes': len(data['routes']), 'flows': len(data['aggregate_flows']), 'roots': data['nonzero_flows_by_root']} for target, data in targets_out.items()}, flush=True)
out = {'schema': 'UOR1_ACTUAL_U_QG_COMPLEMENTARY_C0_ROOTS', 'role': role,
       'field_source_pairs': 643, 'root_candidate_catalog': [[list(pattern), degree] for pattern, degree in catalog],
       'results': results, 'quantum_coefficients_measured_or_fitted': False,
       'full_T_F_QAP_E5_or_physical_promotion': False}
raw = (json.dumps(out, sort_keys=True, separators=(',', ':')) + '\n').encode()
blob = gzip.compress(raw, mtime=0)
with (O / ('root_' + role + '_tables.json.gz')).open('xb') as stream:
    stream.write(blob)
print('RESULT ' + json.dumps({'elapsed_after_imports': time.perf_counter() - tick,
      'packed_sha256': sha256(blob).hexdigest(), 'raw_sha256': sha256(raw).hexdigest(),
      'candidate_root_patterns': len(catalog), 'QG_source_inventories': [row['full_QG_source_inventory'] for row in results],
      'root_summaries': [{target: data['nonzero_flows_by_root'] for target, data in row['targets'].items()} for row in results],
      'quantum_coefficients_or_identity_claim': False}, sort_keys=True), flush=True)
timer.cancel()
