# UOR2: complete route comparison and density-first Wick/cotangent review

Prospective after both UOR1 natives completed. Compare every monomial
partition, derivative reference, root type/degree, flow coefficient,
aggregate and explicit exclusion. Both full QG source inventories must
remain visible; no source-degree class is inferred absent from its loops.

Derive all643 source Wick phases from the field phase and the cotangent
pairing equation, independently of the native source-phase cases. Form
the Euclidean canonical density first on every surviving original QG
monomial, then left-differentiate and group its q flows. Compare the full
nonzero aggregates with the two native derivative-first routes. Test an
even QG Ja JL C fixture and a repeated-even-source Ja^2 fixture, including
the right-to-left sign. No rho prefix is inserted into this u operation.

Check every surviving root has ghost0,even parity,nonnegative intrinsic
degree,correct source degree and zero unpaired Lorentz indices. Confirm
all positive external-jet and background/control exclusions retain their
references. Controls distinguish support/operation sensitivities from
unknown quantum-root values. Record exact source-degree omission effects,
actual odd-derivative orientation sensitivity and source-phase sensitivity.

One180s review,8GiB sampled,350MiB launch floor,32MiBpacket. Freeze code,
input hashes/source copies before execution. Existing partial T/F outputs
remain prohibited operands. A mismatch blocks interpretation of this
candidate until corrected in a new version; preserve failures. No loop
measurement, full identity, anomaly, physical or scientific-authority claim.
