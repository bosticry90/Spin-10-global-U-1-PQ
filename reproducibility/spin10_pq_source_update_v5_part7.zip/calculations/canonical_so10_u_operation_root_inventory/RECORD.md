# UOR1: actual B_u C0 complementary-root inventory

Prospective at e3ec530d after all five marginal contact types and the full
u-contact Euler image were qualified. The retained T/F partial sums still
omit B_u C0. Determine its required input types from the actual QG, not
from a desired remainder. This is the next scientific dependency; no
new loop integral or broad counterterm-space construction is needed first.

Use all physical_QG monomials for both probes and all643 field/source
pairs, including source degrees0/1/2. Fixed original SMA/CSW/EDS,A0,
constant u,zero external jets and nonexceptional Euclidean LOCAL RELATIVE
scope. x has328,C/a/L have45 directions; actual raw-to-canonical action
transport is inherited. Do not apply that chart again. No flavor/HB1/C5
activation, new physical scheme, benchmark or normalization selection.

The targets, with the u factor suppressed, are Ja C x and JL C C x.
Each has explicit dimension4,ghost1,odd parity and intrinsic degree1
in a dimension5 Slavnov image. QG and local polynomial C0 each have
dimension4,ghost0,even parity. A conjugate field/source pair has dimension3.
For a QG monomial M differentiated at v, its remaining word must fit
inside the target. The complementary C0 root is the target remainder
plus the conjugate of v. The intrinsic degrees obey nd(QG)+nd(C0)=1.
Retain only nonnegative polynomial degrees; no inverse mass/coupling
or undeclared normalization is admitted. This does not assert completeness
of an H-basic/C5 counterterm construction or unlock that stage.

All positive external jets stay outside the declared constant/zero-jet
projection by locality and derivative counting. Background/control words
outside the dynamic A0 domain are inventoried. Every original monomial
gets a disposition, and every surviving derivative position retains its
exact original reference and coefficient. Nonnegative-dimension root
patterns with a single unpaired vector cannot be Lorentz scalars in this
domain; retain those exclusions explicitly rather than discard a term.

Primary: direct target-complement subtraction and left differentiation.
Replay: enumerate local even ghost0 root patterns of dimension3/4 from
the actual field/source alphabet, then match their independently formed
complements to right derivatives of the actual QG. QG is EVEN, so its
left derivative equals (-1)^p_v times its right derivative. Preserve
repeated even-source multiplicities and actual anticommuting order.

Sigma_u,E=-u QG_M after Wick transport. qphi=(-1)^p_phi leftEuler_J Sigma,
qJ=(-1)^p_phi leftEuler_phi Sigma. There is no rho-prefix crossing in this
u calculation. Field Wick phases: Lambda=-i,B_time=+i,others1. Source
phases satisfy T_phi*T_J=(-1)^(p_phi+1), including JL=-i,Ja=JC=1,
Jx=-1,JB_space=-1,JB_time=+i. Verify every pair and nonzero graded fixtures.
Compare complete coefficients, route references, exclusions and aggregate
flows. Native roles cannot read peer outputs or quantum source remainders.

Controls should expose omission of the even-QG right-to-left sign,
omission of source Wick phases, and removal of actual source-degree
classes where routes exist. Count only actual sensitivities; a supported
classical route is not a nonzero quantum root. Aggregate identical flows
before deciding whether a root can contribute.

Native300s/role,review180s afterimports,8GiB sampled private,350MiB launch
available-pagefile floor,32MiBpacket. Freeze inputs/source copies before
execution. Preserve failed and incomplete attempts; no scientific tests
or resource bounds are weakened. No agents or dependent parallel work.

Acceptance is a complete bounded operation/support result. Root values
remain inherited or unmeasured until their exact action/reference/domain
match is established. Review existing measurements after the inventory;
reuse valid results or structural zeros and select only indispensable
missing calculations. No fit to partial T/F, anomaly, full restoration,
QAP/measure, physical viability or E5/A5 promotion. Shared action, chart,
software, coefficient ring and AI authorship limit independence.
