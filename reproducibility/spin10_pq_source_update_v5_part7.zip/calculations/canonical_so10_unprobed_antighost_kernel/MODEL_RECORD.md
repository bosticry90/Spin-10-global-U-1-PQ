# AAK3: full model coefficient,prospective after AAK2

AAK1/2 qualified complete six-family formula and allD pinning. Use actual
ACV Fourier vertices,not the rejected W/Za compact proposals. Curate J,W,
Wn,S,N,Z,Y separately from primary/replay native tables. Reuse qualified R
and reference G0;all scalar/ghost metrics identity. All45x45x328 positions
per heat/root tensor and implicit zeros. Preserve symbolic parameters.

Primary index contractions and replay sparse matrix reassociations must
agree completely after both run. Retain F2;F3 ghost-mass,Mn,Wn,Y groups;
F4 both N/X orderings separately. Do not impose a zero pole or a desired
finite kernel. The relative basis is chi4=sumF,log2=F4-F3,log3=F3,
log5=0,fixed=0 by qualified radial rule and allD proof. Keep parameter
degrees and zero complements. Common normalization hbar/(16pi^2).

Old Ward/cutoff/partial outputs and peer coefficients denied as operands.
Native300s,8GiB sampled private,350MiB available-pagefile floor,32MiBpacket.
Freeze all inputs/sources/copies/hash before execution. Failure/exhaustion
means unqualified/incomplete;preserve exact run. A separate review will
compare literal selected508-coordinate actual Hessian logs and sensitive
model omissions where present. Source integration is a later increment.

Original domain and authority ceiling in RECORD.md unchanged. Full
renormalized products,QAP/measure/master and physical claims remain open.
