# The selected intrinsic source relation closes without fitting

PROGRESS. The last ordinary intrinsic aCx kernel is measured and checked.
Its action-derived source image cancels the entire retained partial
rho JL Cx relation in each formal finite basis,for both declared probes.
No quantum coefficient was inferred from a desired remainder,and no chi4,
b0,kappa or infrared normalization was selected.

This is the selected Euclidean local-relative coefficient relation. It
is not the full nonlinear Ward/master identity,renormalized-product/QAP
construction,chiral measure theorem or E5/A5 completion. Scientific
authority remains34/39,state113,E5/A5 OPEN,custodyexit2/seven NOTPASS.
Goal ACTIVE/INCOMPLETE. No foundation,scheme or physical benchmark changed.

## The complete ordinary kernel

AAK1 compares literal paired-mode quarter-STrlog with bosonic Schur
elimination and the ghost determinant. All12 noncommuting two-color/
two-scalar fixtures agree in dimensions3/4/5 and both axis choices. The
sign and single-mode half-STrlog normalization are fixed before model
quantum data or Ward remainders are read. Omitting Y,Wn,either W component,
reference width or the reverse N/X order is sensitive in generic controls.

AAK2 covers all466 actual profiles in six families,including18 Y*N*X
seagulls. Its metric-port proof checks1056 longitudinal pins across750
pinned vector components and324 metric links. Every metric-connected
component has a pin. Actual GF tables check24080 vector/jet entries and
103608 Y Lorentz entries. No free D trace remains;fixed dimensional jet0
is structural,not interpolation of the finite-dimensional fixtures.

The model calculation uses actual ACV J,W,Wn,Z,Y tensors. The rejected
compact W/Z proposals from the previous checkpoint are not operands.
Qualified R and reference G0 are reused. Primary direct index contractions
and replay sparse matrix reassociations agree on every retained group,
coupling/root coefficient and implicit zero.

| Heat group | Nonzero | Implicit zero |
| --- | ---: | ---: |
| F2 | 10,584 | 653,616 |
| F3 | 10,632 | 653,568 |
| F4 | 10,584 | 653,616 |
| Pole,sumF | 10,488 | 653,712 |

These are positions in tensors with45x45x328=664200 entries,not independent
experiments or particles. The seven constituent group counts are10584
(Z*S),10584(S*M*G*W),10424(Mn*G*X*G*W),10296(M*G*X*G*Wn),10240(Y*N*X),
10584(first F4 ordering),0(second F4 ordering). The latter is an actual
complete model contraction zero;its generic counterpart is nonzero.
Both orderings were retained and tested before that result was known.

The formal finite coefficient is

    F=chi4*(F2+F3+F4)+log2*(F4-F3)+log3*F3,

with no log5 or fixed dimensional term in this symbol. Nonzero parameter
powers areg10^3 xi^2,g10^4 xi eta_H,g10^4 xi^2. They remain symbolic.
The common normalization is hbar/(16pi^2),with no extra half.

Selected literal508-coordinate Hessian logarithms corroborate all heat
groups at five triples,bothq. The old(13,0,137) witness is zero in this
kernel and does not establish a whole-tensor zero. Model Y/Z/Wn/Mn/W/
width controls detect omissions where the selected contractions are
nonzero;insensitive cases are retained as such. In particular Y affects
F3 at(13,12,137). Literal samples supplement the full reduced-tensor
comparison;they are not full508 replay of every coefficient.

## Actual source transport,then late assembly

The complete projected antighost flow derived from actual G is

    q_rho a = rho P*(i JL-width*a/2),

with P the12-direction unbroken projector for probe0 or33-direction
broken projector for probe1. Width iseta_H orxi,respectively. Both Wick/
source-pair derivations agree. Individual source phases and literal left
derivatives fix the sign before the old operation matrix is read. The
source part B=iP agrees with old C_a_x after the stated transpose. The
ordinary scaling part is preserved;it has no JL and cannot enter the
selected rho JL Cx coefficient. No conjugate C/x source is present in
the actual retained generator,so those rho variations add no source image.

Direct index contraction versus matrix unfolding agrees on the image of
every kernel basis. Only afterward is the authenticated V636 partial
relation read and the last measured image added once:

| Probe1 basis | Previous partial | Last image | Remainder |
| --- | ---: | ---: | ---: |
| chi4 | 10,488 | 10,488 | 0 |
| log2 | 10,784 | 10,784 | 0 |
| log3 | 10,632 | 10,632 | 0 |
| log5 | 0 | 0 | 0 |

The equality is coefficientwise with the full implicit-zero complement,
not equality of counts alone. All probe0 images/partial terms are zero.
All previously missing ordinary kernels in this selected relation are now
measured. Earlier regulator/source terms remain indispensable;the native
kernel supplies no log5 and does not replace the previously derived heat
cutoff contribution. No arbitrary contact value or negative residual was
used as an input. Complete image/zero remainder tables are preserved.

## Two failed checks are preserved

Original AAK4 literal checker FAILED at its first sample because its ACV
orientation list omitted intrinsic H_(a,x)|C. ACV's J class covered only
a--B/L currents. The actual density n*a*C*x*S gives the missing +S and
reverse-S orientations by literal left derivatives. V2 restores that
known vertex,adds its omission control and passes;no model native or
coefficient was changed. The original checker/source/copy/preparation,
complete capture and controller failure remain;no original receipt.

Original AAK5 FAILED its restricted source inventory:actual G contains
Ja*a as well as JL*Ja. V2 derives both flow terms and excludes the first
from this specific source projection by its source degree. It retains
the full operator instead of silently dropping the term. No source sign
or quantum coefficient was adjusted. The failed original inventory and
capture remain,no original integration output/receipt exists.

Universal primary/replay2.5561/1.1444s,review3.4688s;model35.6662/30.2514s,
modelreviewV2 23.2773s,integrationV2 8.4940s afterimports. Bounds300s
native/180s review,8GiB sampled private,350MiB available-pagefile floor,
32MiB packet unchanged. Complete native captures and immutable source
copies/inputs are retained. E4 executes once this turn with native0,
steps[0,0,0,0,0,2],COMPLETED in29.3648s. That authenticates sealed evidence
and declared audits,not a fresh whole scientific replay or custody PASS.

The demonstrated capability is a complete action-derived loop reduction,
independent contraction,source-flow derivation and late unfitted assembly.
The checker omission and prematurely restricted flow inventory are real
workflow weaknesses. Methods share action/charts,classical data,R,
coefficient software,Python/SymPy and AI authorship. Agreement is internal
mathematical corroboration,not independent scientists,experimental evidence
or validation of the model's physical premises. No proof assistant used.

## Remaining scientific work

Original unshifted SMA/CSW/EDS,A0,intrinsicdegree1,externaljets0 and
symbolic parameters remain. This is a nonexceptional Euclidean LOCAL
RELATIVE symbol,not physical scalelessp0,absolute products or massive/
causal vacuum amplitudes. Constant freedoms remain distinct and unfixed.

The two u quadratic-source contacts u Ja JL C and u JL JL CC remain
unmeasured in the existing five-type inventory. Their joint action-derived
support/ordered-kernel reduction is a justified next bounded question.
Full T/F,general ordinary BBx,nonlinear/intrinsic master applicability,
renormalized products,chiral QAP/measure/global phase,physical source
reality and massive/causal limits remain open,as does physical viability.
No flavor/HB1/C5 activation,protected promotion or remote action follows.

This RESULT is frozen before the separate final assembly/interpretation
review. A failed final review must preserve it,not retrospectively alter
the evidence. project_state.json remains sole machine scientific authority.
