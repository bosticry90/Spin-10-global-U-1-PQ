from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'universal_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
u,v=[load(O/('universal_'+role+'_tables.json.gz'))for role in['primary','replay']];assert u['fixtures']==v['fixtures']and len(u['fixtures'])==12
for z in[u,v]:
 assert z['both_W_components_Wn_and_bosonic_seagull_retained']and not z['actual_model_quantum_or_Ward_operand']and len(z['controls'])==24
 assert all(c['changed_heat_coefficients']for c in z['controls'])
for role in['primary','replay']:
 rr=read(O/('universal_'+role+'_result.json'));p=O/('universal_'+role+'_tables.json.gz');assert H(p)==rr['packed_sha256']and sha256(gzip.decompress(p.read_bytes())).hexdigest()==rr['raw_sha256']
ip=read(O/'universal_validation_inputs.json');sup=[load(Path(ip[k]))for k in['support_primary','support_replay']];assert sup[0]['letters']==sup[1]['letters'];a,b=[next(q for q in z['results']if q['target']=='a_Cx')for z in sup];assert a==b and len(a['ordered_words'])==466 and not a['abstract_superfamily_word_occurrences'];families=Counter();pins=metric_edges=components=0
for q in a['ordered_words']:
 letters=[sup[0]['letters'][i]for i in q['letters']];types=[];nodes=set();edges=[];marks=set();n=len(letters)
 for at,z in enumerate(letters):
  gr=z['grade'];left,right=z['H_ports'];before=q['Green_path'][at];assert right==q['Green_path'][at+1]
  if gr==[0,0,1,1,0]:typ='Y'if left==right=='B'else'Z'
  elif gr==[0,0,1,0,0]:typ='W'
  elif gr==[0,0,0,1,0]:typ='M'
  elif gr==[1,0,1,0,0]:typ='Wn'
  elif gr==[1,0,0,1,0]:typ='Mn'
  elif gr==[1,0,0,0,1]:typ='S'
  elif gr==[1,0,0,0,0]:typ='N'
  elif gr==[0,0,0,0,1]:typ='X'
  else:raise AssertionError(('unclassified_profile',z['id']))
  types.append(typ)
  for side,k in[(0,left),(1,right)]:
   if k=='B':nodes.add((at,side))
  if left==right=='B':assert typ=='Y'and not any(z['internal_jet_orders']);edges.append(((at,0),(at,1)))
  elif'B'in[left,right]:
   assert typ in['W','M','X']and sum(z['internal_jet_orders'])==1;marks.add((at,0 if left=='B'else 1))
  if before==left=='B':edges.append((((at-1)%n,1),(at,0)))
  elif(before=='B')!=(left=='B'):
   assert {before,left}=={'B','L'};marks.add(((at-1)%n,1)if before=='B'else(at,0))
 key=','.join(sorted(types));families[key]+=1;assert marks<=nodes
 adjacency={p:set()for p in nodes}
 for x,y in edges:assert x in nodes and y in nodes;adjacency[x].add(y);adjacency[y].add(x)
 seen=set()
 for start in nodes:
  if start in seen:continue
  frontier=[start];comp=set()
  while frontier:
   p=frontier.pop()
   if p in comp:continue
   comp.add(p);frontier.extend(adjacency[p]-comp)
  assert comp&marks,('unfixed_Lorentz_trace',q,comp);seen|=comp;components+=1
 pins+=len(marks);metric_edges+=len(edges)
expected={'S,Z':4,'M,S,W':48,'M,Wn,X':54,'Mn,W,X':54,'N,X,Y':18,'M,N,W,X':288};assert dict(families)==expected
d=load(Path(ip['actual_vertices']));counts=Counter();Y={}
for group in['J','W','KBB']:
 for i,ji,j,jj,ext,value in d['Hessian_groups'][group]:
  if group=='KBB':
   assert i<180 and j<180 and i%4==j%4 and not ji+jj;key=(i//4,j//4,tuple(ext));Y.setdefault(key,{})[i%4]=value
  else:
   bos=i if i<553 else j;mu=bos%4
   if bos<180:assert ji+jj==str(mu);counts['derivative_vector_entries']+=1
   else:assert not ji+jj
for key,values in Y.items():assert set(values)=={0,1,2,3}and len(set(values.values()))==1
cl=load(Path(ip['classical']));assert all(a>=45 for a,j,v in cl['endings']['N0']['entries']);assert not any(a>=45 and b>=45 for a,b,v in cl['endings']['G0']['entries'])
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'all12_literal_Gaussian_Schur_fixtures_agree':True,'complete466_profile_families':dict(families),'allD_longitudinal_pins':pins,'metric_edges':metric_edges,'pinned_vector_components':components,'actual_vector_jet_entries_checked':counts['derivative_vector_entries'],'actual_Lorentz_Y_components_checked':len(Y)*4,'fixed_Djet0_structural':True,'actual_model_quantum_kernel_measured':False,'full_QAP_E5_or_physical_promotion':False},sort_keys=True),flush=True);timer.cancel()
