# AAK1+: complete ordinary intrinsic antighost kernel

Prospective at6732222e996dab375037208fd9f8a592a431afde,V637. Fresh read-only
preflight clean main,no matching workers;previous goal turn PROGRESS.
Goal ACTIVE/INCOMPLETE. Live AGENTS,charter,epistemic ladder,solo review
and local conventions apply. State113,authority34/39,E5/A5 OPEN,custody
exit2/seven NOTPASS. No branch/worktree,agents,remote action,publication,
scheme/foundation/benchmark adoption,flavor/HB1/C5 activation or promotion.

Question:what is the complete intrinsic aCx ordinary kernel needed by the
selected finite source relation? ACV has now derived all actual vertices,
including nonzero KBB and Za. Its466 profiles form six families. Two
compact W/Za proposals failed:use actual action-derived tables instead.
Do not supply any coefficient from a negative Ward remainder.

Same original unshifted SMA/CSW/EDS,A0,intrinsicdegree1,zero external jets,
all45 antighosts/ghosts,328 real scalars,symbolicg10/xi/eta_H. Euclidean
nonexceptional LOCAL RELATIVE symbol,commonhbar/(16pi^2),not physical
scalelessp0,absolute products,massive/causal vacuum or new physical scheme.
chi4,b0,kappa,IR freedoms remain distinct and unfixed.

First qualify the complete ordered determinant formula independently of
actual model quantum coefficients. M/Mn are the external-ghost ordinary/
intrinsic scalar currents,W/Wn the external-antighost ordinary/scalar
currents,Z the direct aC ghost vertex,Y the aCBB bosonic Hessian,N the
intrinsic mixed Hessian,X the scalar kinetic derivative Hessian,S the
intrinsic ghost mass. Proposed ordered heat coefficients:

 F2=Tr(Z S),
 F3=Tr(S M G W)+Tr(Mn G X G W)+Tr(M G X G Wn)
      +1/2 Tr(G Y G N G X+G Y G X G N),
 F4=-Tr(M G N G X G W+M G X G N G W).

These are proposals until literal paired Gaussian quarter-STrlog versus
bosonic Schur/ghost determinant agree. Preserve noncommuting order and
external odd ordera,C. Test both W vector/auxiliary components,Wn,Za,Y,
both N/X orderings,reference width and reverse derivative endpoints in
generic two-color/two-scalar fixtures. Record true insensitivity where
present. D3/4/5 fixtures corroborate;prove dimensional dependence through
actual support/pinning before full model computation. A finite Gaussian
normalization check cannot by itself establish continuum QAP/products.

Then freeze a model increment,curating J,W,Wn,Za,Y from the qualified ACV
native tables and N,S,R/reference from authenticated classical data. Use
distinct tensor associations,retain every heat/root group and implicit
zero. Selected literal full Hessian logs must corroborate the reduction;
no partial Ward/cutoff output may be a kernel operand. A source-image/
late-partial integration requires its own prospective record afterward.

Sequential300s native/180s review afterimports,8GiB sampled private,
350MiB available-pagefile launch floor,32MiB retained packet. Freeze
sources,copies,inputs/hashes before computation. Failed normalization,
support,operator comparison or exhaustion leaves scope unqualified.
Preserve exact failures;routine correction only in new version. Never
change an input/sign to produce a desired quantum cancellation.

The full nonlinear/intrinsic master,continuum trace/products,chiral QAP,
measure/global phase,source reality,physical domains and other outstanding
obligations remain separate/open. Shared action,charts,exact ring,
Python/SymPy,frontend/software and AI authorship limit independence.
No independent scientist or proof assistant is claimed.
