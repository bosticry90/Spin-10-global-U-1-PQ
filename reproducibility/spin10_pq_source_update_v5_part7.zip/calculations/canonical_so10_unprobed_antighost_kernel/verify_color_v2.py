from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'color_validation_preparation_v2.json')['input_sha256'].items():assert H(Path(p))==h,p
cp=Path(read(O/'ring_inputs.json')['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient,constant,I as CI
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
def clean(D):return{k:v for k,v in D.items()if v}
def plus(*args):
 out=defaultdict(lambda:0)
 for D,f in args:
  for k,v in D.items():out[k]+=f*v
 return clean(out)
tab=lambda rows:{tuple(q[:-1]):co(q[-1])for q in rows};primary,replay=[load(O/('color_'+role+'_tables.json.gz'))for role in['primary','replay']];groups={k:tab(v)for k,v in primary['groups'].items()};assert groups=={k:tab(v)for k,v in replay['groups'].items()};F={int(k):tab(v)for k,v in primary['F_m'].items()};assert F=={int(k):tab(v)for k,v in replay['F_m'].items()}
assert F[2]==groups['Z_S']and F[3]==plus(*[(groups[k],1)for k in['S_M_G_W','Mn_G_X_G_W','M_G_X_G_Wn','Y_N_X']])and F[4]==plus((groups['M_G_N_G_X_G_W'],1),(groups['M_G_X_G_N_G_W'],1));pole=plus(*[(D,1)for D in F.values()]);basis={'chi4':pole,'log2':plus((F[4],1),(F[3],-1)),'log3':F[3],'log5':{},'fixed':{}}
assert basis=={k:tab(v)for k,v in primary['relative_prime_basis'].items()}=={k:tab(v)for k,v in replay['relative_prime_basis'].items()}
for D in list(groups.values())+list(F.values())+list(basis.values()):assert all(0<=r<45 and 0<=h<45 and 0<=i<328 for r,h,i in D)
for role in['primary','replay']:
 rr=read(O/('color_'+role+'_result.json'));p=O/('color_'+role+'_tables.json.gz');assert H(p)==rr['packed_sha256']and sha256(gzip.decompress(p.read_bytes())).hexdigest()==rr['raw_sha256']and rr['elapsed_after_imports']<300
assert primary['parameter_monomial_powers']==replay['parameter_monomial_powers'];ip=read(O/'color_validation_inputs.json');actual=load(Path(ip['actual_vertices']));cl=load(O/'color_primary_inputs.json.gz');R=[{(i,j):co(v)for i,j,v in A['entries']}for A in cl['R']];Gbase={(i,j):co(v)for i,j,v in cl['G0']['entries']}
def add(A,i,j,mask,v):
 if v:A[i,j]=plus((A.get((i,j),{}),1),({mask:v},1))
def index(i):
 if i<180:return i//4 if i%4==3 else None
 if i<508:return 90+i-180
 if i<553:return 45+i-508
 if i<598:return 418+i-553
 return 463+i-598
# Independently derive the missing orientation from literal n*a*C*x*S.
# a and C are odd; x is even. This uses no quantum coefficient.
pp={'a':1,'C':1,'x':0};density=('a','C','x')
def derivative(w,n):
 return[(w[:at]+w[at+1:],(-1)**(pp[n]*sum(pp[z]for z in w[:at])))for at,z in enumerate(w)if z==n]
def coefficient_orientation(first,second):
 out=0
 for w,sg in derivative(density,first):
  for rest,tg in derivative(w,second):
   assert rest==('C',);out+=sg*tg*(-1)**(pp[second]*(pp[first]+1))
 return out
assert coefficient_orientation('a','x')==1 and coefficient_orientation('x','a')==-1
def pieces(r,h,ix,q):
 GG={};VV={}
 for(i,j),v in Gbase.items():add(GG,i,j,0,q*v if(i<45<=j or j<45<=i)else v)
 for j in range(328):add(GG,90+j,90+j,0,constant(1))
 for j in range(45):add(GG,418+j,463+j,0,constant(1));add(GG,463+j,418+j,0,constant(-1))
 src=next(z['groups']for z in actual['Fourier_unit_axes']if z['axis']==3 and z['q']==q)
 for name,rows in src.items():
  if name not in['N','S','J','W','Wn','Za','KBB']:continue
  for a,b,ext,value in rows:
   mask=None
   if name=='N'and not ext:mask=16
   elif name=='S'and ext==[180+ix]:mask=48
   elif name=='J'and ext==[553+h]:mask=8
   elif name=='W'and ext==[598+r]:mask=4
   elif name=='Wn'and ext==[598+r]:mask=20
   elif name in['Za','KBB']and ext==[598+r,553+h]:mask=12
   if mask is None:continue
   i,j=index(a),index(b)
   if i is not None and j is not None:add(VV,i,j,mask,co(value))
 for a,c,j,value in cl['S']:
  if c==h:add(VV,463+a,90+j,24,co(value));add(VV,90+j,463+a,24,-co(value))
 for b,RR in enumerate(R):
  for(j,i),v in RR.items():
   if i==ix:add(VV,b,90+j,32,-CI*q*v);add(VV,90+j,b,32,CI*q*v)
 return GG,VV
@lru_cache(None)
def sign(a,b):return(-1)**sum(i>j for i in[2,3]for j in[2,3]if a&(1<<i)and b&(1<<j))
def pmul(A,B):
 out=defaultdict(lambda:0)
 for a,v in A.items():
  for b,w in B.items():
   if not a&b:out[a|b]+=sign(a,b)*v*w
 return clean(out)
def mm(A,B):
 by=defaultdict(list);out={}
 for(i,j),v in B.items():by[i].append((j,v))
 for(i,k),v in A.items():
  for j,w in by[k]:out[i,j]=plus((out.get((i,j),{}),1),(pmul(v,w),1))
 return clean(out)
def logarithm(G,V):
 M=mm(G,V);power={(i,i):{0:constant(1)}for i in range(508)};out={}
 for m in range(1,5):
  power=mm(power,M);trace=sum(((-1)**int(i>=418)*D.get(60,0)for(i,j),D in power.items()if i==j),0);out[m]=co(str(s.Rational((-1)**(m+1),2*m)))*trace
 return out
samples={(13,0,137)}
for D in[F[2],F[3],F[4],groups['Y_N_X']]:
 if D:samples.add(min(D))
if F[4]:samples.add(max(F[4]))
assert len(samples)<=6;checks=[];controls=[];detected={'Y':False,'Z':False}
for r,h,ix in sorted(samples):
 for q in[1,-1]:
  G,V=pieces(r,h,ix,q);got=logarithm(G,V);assert not got[1]and all(got[m]==F[m].get((r,h,ix),0)for m in[2,3,4]),('literal508_mismatch',r,h,ix,q,{m:str(v)for m,v in got.items()});checks.append([r,h,ix,q,{str(m):str(got[m])for m in[2,3,4]}])
  if q==1:
   for ctrl in['Y','Z','WB','WL','Wn','Mn','width']:
    GG=G;VV={ij:dict(D)for ij,D in V.items()}
    if ctrl=='width':GG={ij:D for ij,D in G.items()if not(ij[0]<45 and ij[1]<45)}
    else:
     for(ii,jj),D in VV.items():
      if ctrl=='Y'and ii<90 and jj<90:D.pop(12,None)
      elif ctrl=='Z'and ii>=418 and jj>=418:D.pop(12,None)
      elif ctrl=='Wn':D.pop(20,None)
      elif ctrl=='Mn':D.pop(24,None)
      elif ctrl=='WB'and(ii<45 and 418<=jj<463 or jj<45 and 418<=ii<463):D.pop(4,None)
      elif ctrl=='WL'and(45<=ii<90 and 418<=jj<463 or 45<=jj<90 and 418<=ii<463):D.pop(4,None)
     VV={ij:D for ij,D in VV.items()if D}
    bad=logarithm(GG,VV);changed=[m for m in[1,2,3,4]if got[m]!=bad[m]]
    if ctrl in detected:detected[ctrl]|=bool(changed)
    controls.append({'sample':[r,h,ix],'control':ctrl,'changed_heat_groups':changed})
 print('STAGE AAK4 literal',r,h,ix,flush=True)
for key,group in[('Y','Y_N_X'),('Z','Z_S')]:
 if any(groups[group].get(k,0)for k in samples):assert detected[key],('missing_model_control_sensitivity',key)
counts={str(m):{'nonzero':len(D),'zero':664200-len(D)}for m,D in F.items()};out={'elapsed_after_imports':time.perf_counter()-tick,'complete_group_heat_pole_prime_and_implicit_zero_agreement':True,'heat_counts':counts,'pole_nonzero':len(pole),'parameter_monomial_powers':primary['parameter_monomial_powers'],'literal_selected508_logs_both_q':checks,'model_controls':controls,'sensitive_Y_Z_when_sampled':detected,'missing_intrinsic_current_orientation_derived_from_actual_density':True,'original_incomplete_literal_checker_failure_preserved':True,'old_Ward_cutoff_not_operand':True,'full_QAP_E5_or_anomaly_verdict':False};print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
