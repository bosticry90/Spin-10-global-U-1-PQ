# Complete ordered reduction and dimensional support

All claims concern finite ordered Gaussian coefficients in the declared
unshifted Euclidean local relative symbol. They do not establish a
continuum nonlinear master relation or chiral QAP/measure theorem.

Let a,C be the external odd variables in that order. Bosonic elimination
and the ghost determinant yield a bosonic half-Trlog and a ghost minus-
Trlog. The bosonic block is K+nN+xX+aC Y. The ghost block is

 D_eff=D0+nx S+aC[Z+(M+nMn)(K+nN+xX)^-1(W+nWn)].

Only the target coefficient of n a C x is retained. Terms quadratic in
either external odd variable or n are outside that projection. Expanding
the inverse gives the proposed F2,F3,F4 in RECORD.md. The positive aC
mixed term follows from moving the external odd variables past the
quantum antighost in the Gaussian cross contraction,not from a Ward target.
The bosonic third-order logarithm has6 permutations;cyclic trace reduces
them to1/2 Tr(GYGN GX+GYGX GN). It is absent from the source-only formula.

Each ordered edge retains its positive heat factor. An N insertion is
between regulated propagators;do not cancel its free inverse without its
heat edge. Single-mode weights are(-1)^(m+1)/(2m). Quarter-STrlog of the
literal full paired Hessian equals the q-pair average. AAK1 checks these
normalizations by literal graded derivatives against Schur elimination
on arbitrary noncommuting two-color/two-scalar fixtures with all W roles,
Wn,Z and Y retained. No actual model quantum coefficient is an input.

The complete466-profile catalogue partitions into S*Za,J*S*W,J*Wn*X,
Mn*W*X,Y*N*X,J*N*W*X. The prospective reviewer must check every member,
not merely these six aggregate labels. Abstract potential/fermion target
cycles are empty in the qualified catalogue.

For a vector-current or scalar-kinetic vector leg,the actual internal
derivative supplies p_mu along that leg. Mixed B/L propagators also supply
p_mu. A B/B propagator is a sum of a metric and a longitudinal projector;
its metric transports a pin and its longitudinal part supplies one. The
only derivative-free vector Hessian is Y with two vector legs and a
Lorentz metric between them. In Y*N*X,one connection reaches N through a
mixed B/L propagator and the other reaches the derivative X. Thus this
metric cannot generate an unpinned Lorentz trace.

More generally join metric-connected vector ports in each catalogue word
and mark pins from mixed propagators and derivative endpoints. Every
connected vector-port component must contain a pin;the reviewer checks
this complete condition. Actual GF tables must have matching vector/jet
Lorentz labels and Y must be diagonal with the same coefficient on all
four components. No free metric loop remains. Therefore scalar momentum
powers cancel their reference propagator factors leaving p^-4,with no
free D factor or higher angular moment. The fixed dimensional jet is0
structurally in this target,not inferred by D3/4/5 interpolation.

Unlike the auxiliary-source case,G_BB and both W components now remain.
NGW need not vanish. The reference widths and auxiliary current cannot
be omitted. The universal controls explicitly test those differences.
The retained radial finite factor is chi4+log(m/2) for m heat edges,
using the already qualified relative radial convention without selecting
chi4. Complete model tensors still have to be measured and checked.
