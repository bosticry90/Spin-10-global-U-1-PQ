# AAK5: action-derived antighost source transport and final selected sum

Prospective after AAK4 V2 passed. Derive q_rho a from actual source-
quadratic G before any old operation or partial quantum relation is read.
Established Euclidean source pairing is sum(-1)^p J R;thus q_phi equals
(-1)^p times the left source derivative of Sigma. For
Sigma_rho=rho JL_r H_rj Ja_j,the odd-a variation is
q_rho a_j=-rho JL_r H_rj. Check this sign on the literal ordered density
rho JL Ja and on variation of a C x. Individual Wick phases are
J_Lambda=-i,J_a=1 and G_E=-Wick(G_M),so H=i times the raw source2 tensor.
The replay uses the source-pair Hamiltonian sign/global phase directly.

Inspect every Ja-bearing G term and every conjugate C/x source. Require
the retained Ja terms to be exactly the actual quadratic JL Ja domain;
additional relevant structures require explicit continuation,not omission.
Compute source transport B=-H,then image B times the measured aCx kernel,
via direct indices versus matrix unfolding on every relative basis.

Only afterward compare B^T with old C_a_x and read V636's partial sum.
Add this last independently measured ordinary image exactly once. Retain
each basis/complete coefficient/implicit zero;do not require cancellation.
No native root is assigned a negative residual and no chi4/b0/kappa/IR
constant is fixed. Zero would qualify only this selected local-relative
coefficient relation;it would not establish the full nonlinear source
master,QAP,renormalized products,measure or E5/A5.

180s review/native,8GiB sampled,350MiB available-pagefile floor,32MiBpacket.
Freeze sources/copies/actual inputs and late comparators. Preserve any
operation mismatch/failure without sign fitting. Authority unchanged.
