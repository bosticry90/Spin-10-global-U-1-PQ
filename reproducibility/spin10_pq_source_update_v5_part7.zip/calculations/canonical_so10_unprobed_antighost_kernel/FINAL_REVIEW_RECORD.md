# AAK6 final independent assembly and custody review

Prospective after source integration. Authenticate every frozen input,
source copy,capture/resource and expected failure. Recheck complete model
group/heat/prime equality and source-image sums,including implicit zeros.
Reconstruct B and T from actual G by generic literal source derivatives
of rho*G_E with source pairing(-1)^p,not the compact formulas alone.
Check both operations and the target-grade exclusion. Recompute every
late partial plus last image;zero is a result to verify,not a fitted input.
Check wrong source-image sign leaves a nonzero probe1 remainder.

Authenticate universal support/allD/literal model reviews,E4 native/step
exits and state hash. Preserve both failed checks and absent original
receipts;do not weaken their requirements. No whole QAP/master/E5 claim.
180s,8GiB sampled,350MiBfloor,32MiBpacket. Full captures/sourcecopy first.
