from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from fractions import Fraction
from collections import defaultdict
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'integration_preparation_v2.json')['input_sha256'].items():assert H(Path(p))==h,p
assert read(O/'color_validation_receipt_v2.json')['complete_group_heat_pole_prime_and_implicit_zero_agreement'];cp=Path(read(O/'ring_inputs.json')['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient,Coeff,constant,I as CI
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
tab=lambda rows:{tuple(q[:-1]):co(q[-1])for q in rows};enc=lambda D:[[*k,str(v)]for k,v in sorted(D.items())];clean=lambda D:{k:v for k,v in D.items()if v}
def mm(A,B):
 by=defaultdict(list);out=defaultdict(lambda:0)
 for(i,j),v in B.items():by[i].append((j,v))
 for(i,k),v in A.items():
  for j,w in by[k]:out[i,j]+=v*w
 return clean(out)
# rho and JL odd;Ja even;a and C odd;x even. The source pairing for a
# carries(-1)^p=-1. No sign below is obtained from the quantum sum.
par={0:1,1:1,2:0,3:1,4:1,5:0}
def left(w,i):return[(w[:at]+w[at+1:],(-1)**(par[i]*sum(par[n]for n in w[:at])))for at,n in enumerate(w)if n==i]
assert left((0,1,2),2)==[((0,1),1)]and left((0,1,2),1)==[((0,2),-1)]and left((3,4,5),3)==[((4,5),1)]
audits=[load(O/('integration_'+role+'_inputs.json.gz'))['audit']for role in['primary','replay']];ops=[];scales=[]
for role,audit in zip(['primary','replay'],audits):
 names=audit['names'];geo=audit['geometry'];base=geo['names'];sources={names.index(base[J]):base[f]for f,J,h,k in geo['field_source_h_k']};aux=[('b'if i<12 else'L')+str(i)for i in range(45)];ants=[('bar'if i<12 else'ub')+str(i)for i in range(45)];assert {sources[n]for p in audit['physical_G']for gp,w,ci in p['monomials']for n,I in w if n in sources}<=set(aux+ants);per=[];perT=[]
 for probe,p in enumerate(audit['physical_G']):
  B=defaultdict(lambda:0);T=defaultdict(lambda:0);Ja_terms=0
  for gp,w,ci in p['monomials']:
   ant_sources=[(at,n)for at,(n,I)in enumerate(w)if n in sources and sources[n]in ants]
   if not ant_sources:continue
   assert len(w)==2 and len(ant_sources)==1 and not any(I for n,I in w),'unclassified_antighost_source_flow'
   at,ja=ant_sources[0];other=w[1-at][0];v=Coeff([((gp,xp,ep,m),Fraction(num,den))for xp,ep,m,num,den in p['coefficients'][ci]])
   if other in sources:
    assert sources[other]in aux,'unsupported_second_source_in_antighost_flow'
    if role=='primary':GE=-v*(-CI)*constant(1);value=-GE
    else:value=-CI*v
    B[aux.index(sources[other]),ants.index(sources[ja])]+=value
   else:
    assert names[other]in ants,'unsupported_ordinary_antighost_flow'
    if role=='primary':GE=-v*constant(1)*constant(1);value=-GE
    else:value=v
    T[ants.index(sources[ja]),ants.index(names[other])]+=value
   Ja_terms+=1
  per.append(clean(B));perT.append(clean(T));assert Ja_terms==len(clean(B))+len(clean(T))
 ops.append(per);scales.append(perT)
assert ops[0]==ops[1]and scales[0]==scales[1];kernels=[load(O/('color_'+role+'_tables.json.gz'))for role in['primary','replay']];images=[]
for probe,B in enumerate(ops[0]):
 per=[]
 for basis,rows in kernels[0]['relative_prime_basis'].items():
  F=tab(rows);assert F==tab(kernels[1]['relative_prime_basis'][basis]);direct=defaultdict(lambda:0);by=defaultdict(list)
  for(r,j),v in B.items():by[j].append((r,v))
  for(j,h,i),v in F.items():
   for r,w in by[j]:direct[r,h,i]+=w*v
  direct=clean(direct);flat={(j,h*328+i):v for(j,h,i),v in F.items()};matrix={(r,hi//328,hi%328):v for(r,hi),v in mm(B,flat).items()};assert direct==matrix;per.append({'basis':basis,'image':enc(direct),'image_nonzero':len(direct)})
 images.append(per)
# Source operation and independently measured image are now complete.
# The old operation and quantum partial sum are late comparisons only.
ip=read(O/'integration_inputs.json');oldops=read(Path(ip['old_pending_operations']))
for probe,B in enumerate(ops[0]):assert{(j,r):v for(r,j),v in B.items()}==tab(oldops['results'][probe]['C_a_x']),('old_C_a_x_disagrees',probe)
prior=load(Path(ip['late_partial']));results=[]
for probe,im in enumerate(images):
 per=[]
 for pp in prior['results'][probe]['formal_basis']:
  basis=pp['basis'];old=tab(pp['remaining_partial']);new=tab(next(z['image']for z in im if z['basis']==basis));keys=set(old)|set(new);total=clean({k:old.get(k,0)+new.get(k,0)for k in keys});per.append({'basis':basis,'prior_nonzero':len(old),'last_measured_image_nonzero':len(new),'remaining_nonzero':len(total),'remaining':enc(total),'positions_checked':664200})
 results.append({'probe':probe,'B_antighost_flow':enc(ops[0][probe]),'T_ordinary_antighost_scaling':enc(scales[0][probe]),'T_excluded_from_JL_projection_by_zero_source_degree':True,'measured_kernel_image':im,'formal_basis':per,'unmeasured_native_roots_in_selected_set':[]})
out={'schema':'AAK5_LAST_NATIVE_SOURCE_IMAGE_AND_SELECTED_RELATIVE_RELATION','results':results,'full_B_and_T_operation_derived_before_old_comparison':True,'original_restricted_source_inventory_failure_preserved':True,'all_native_roots_in_selected_set_measured':True,'no_fitted_kernel_or_normalization':True,'full_Ward_master_QAP_E5_or_physical_promotion':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'integration_tables_v2.json.gz').open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'source_operation_counts':[len(B)for B in ops[0]],'ordinary_scaling_counts':[len(T)for T in scales[0]],'ordinary_scaling':[enc(T)for T in scales[0]],'source_operations':[enc(B)for B in ops[0]],'basis_counts':[[[p['basis'],p['prior_nonzero'],p['last_measured_image_nonzero'],p['remaining_nonzero']]for p in z['formal_basis']]for z in results],'all_selected_native_roots_measured':True,'full_Ward_master_QAP_E5_or_physical_promotion':False},sort_keys=True),flush=True);timer.cancel()
