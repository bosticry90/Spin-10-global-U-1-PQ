# AAK5 V2: classify the full actual antighost flow before projection

Original AAK5 FAILED the prospective source-inventory assertion. Actual G
also contains Ja_j a_k besides JL_r Ja_j. Preserve the original source,
copy,preparation,complete capture and controller failure;no original
integration receipt/output exists. This is a failed restricted assumption,
not a quantum coefficient failure or permission to omit the extra term.

Extend the bounded derivation to compute BOTH terms. With G_E=-Wick(G_M),
Ja,a phases1,the raw Ja*a coefficientv gives q_rho a=+rho v*a. The raw
JL*Ja coefficientw gives q_rho a=-i rho w*JL. Primary transports each
source/field separately;replay derives these global Hamiltonian phases.
Keep the full field-scaling tensor T and source tensor B. Require every
Ja-bearing term to be classified into these actual two classes and no
conjugate C/x source. Unsupported additional terms still fail.

For the selected rho JL Cx projection,T*a has zero source degree and
cannot contribute to JL. This is a target-grade exclusion,not setting T=0
or asserting that the full Ward variation equals its source piece.
Compute the B image independently,then compare B^T to old C_a_x and
assemble the previously qualified partial relation exactly once. No sign
or quantum coefficient is changed from the first derivation's conventions.
Both operators and the exclusion must be independently checked before
claiming a selected relation. Same180s/8GiB/350MiB/32MiB boundaries.
