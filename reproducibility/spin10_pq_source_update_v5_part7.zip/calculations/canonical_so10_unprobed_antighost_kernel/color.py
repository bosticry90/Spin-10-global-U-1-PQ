from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'color_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('color_'+('replay'if role=='primary'else'primary')):raise PermissionError('AAK3_PEER_DENIED')
  if p.parent.name in['canonical_so10_intrinsic_source_cutoff_remaining','canonical_so10_intrinsic_correlated_source_contacts','canonical_so10_unprobed_auxiliary_source_kernel']:raise PermissionError('AAK3_WARD_CUTOFF_TARGET_DENIED')
sys.addaudithook(guard);cp=Path(read(O/'ring_inputs.json')['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient,constant,I as CI,verify_basis_products
assert verify_basis_products()==1024;g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
def clean(D):return{k:v for k,v in D.items()if v}
def tab(rows):return{tuple(q[:-1]):co(q[-1])for q in rows}
def dec(z):return{(i,j):co(v)for i,j,v in z['entries']}
def mm(A,B):
 by=defaultdict(list);out=defaultdict(lambda:0)
 for(i,j),v in B.items():by[i].append((j,v))
 for(i,k),v in A.items():
  for j,w in by[k]:out[i,j]+=v*w
 return clean(out)
def tr(A):return{(j,i):v for(i,j),v in A.items()}
def plus(*args):
 out=defaultdict(lambda:0)
 for D,f in args:
  for k,v in D.items():out[k]+=f*v
 return clean(out)
d=load(O/('color_'+role+'_inputs.json.gz'));J=tab(d['J']);W=tab(d['W']);Wn=tab(d['Wn']);N=tab(d['N']);S=tab(d['S']);Z=tab(d['Z']);Y=tab(d['Y']);R=list(map(dec,d['R']));G=dec(d['G0']);assert all(b>=45 for b,j in N);assert not any(i>=45 and j>=45 for i,j in G)
JM=[{}for _ in range(45)];WM=[{}for _ in range(45)];WN=[{}for _ in range(45)];MN=[{}for _ in range(45)]
for(h,a,b),v in J.items():JM[h][a,b]=v
for(r,c,b),v in W.items():WM[r][b,c]=v
for(r,c,j),v in Wn.items():WN[r][j,c]=v
for(a,h,j),v in S.items():MN[h][a,j]=v
U=[mm(A,G)for A in JM];V=[mm(G,A)for A in WM];UN=[mm(A,N)for A in U];NV=[mm(tr(N),A)for A in V]
groups={k:defaultdict(lambda:0)for k in['Z_S','S_M_G_W','Mn_G_X_G_W','M_G_X_G_Wn','Y_N_X','M_G_N_G_X_G_W','M_G_X_G_N_G_W']};sp=defaultdict(list)
for(a,c,i),v in S.items():sp[a,c].append((i,v))
if role=='primary':
 for(r,h,a,c),v in Z.items():
  for i,w in sp[c,a]:groups['Z_S'][r,h,i]+=v*w
 ur=defaultdict(list);wr=defaultdict(list);rr=defaultdict(list);vr=defaultdict(list);wnr=defaultdict(list);nvr=defaultdict(list)
 for h,A in enumerate(U):
  for(a,b),v in A.items():ur[a].append((h,b,v))
 for(r,c,b),v in W.items():wr[b,c].append((r,v))
 for b,A in enumerate(R):
  for(j,i),v in A.items():rr[j].append((b,i,v))
 for r,A in enumerate(V):
  for(b,a),v in A.items():
   if b<45:vr[b,a].append((r,v))
 for(r,a,j),v in Wn.items():wnr[j,a].append((r,v))
 for r,A in enumerate(NV):
  for(j,a),v in A.items():nvr[j,a].append((r,v))
 for(a,c,i),v in S.items():
  for h,b,w in ur[c]:
   for r,z in wr[b,a]:groups['S_M_G_W'][r,h,i]+=v*w*z
 for(a,h,j),v in S.items():
  for b,i,w in rr[j]:
   for r,z in vr[b,a]:groups['Mn_G_X_G_W'][r,h,i]+=CI*v*w*z
 for h,A in enumerate(U):
  for(a,b),v in A.items():
   if b>=45:continue
   for(j,i),w in R[b].items():
    for r,z in wnr[j,a]:groups['M_G_X_G_Wn'][r,h,i]+=-CI*v*w*z
    for r,z in nvr[j,a]:groups['M_G_X_G_N_G_W'][r,h,i]+=CI*v*w*z
 for h,A in enumerate(UN):
  for(a,j),v in A.items():
   for b,i,w in rr[j]:
    for r,z in vr[b,a]:groups['M_G_N_G_X_G_W'][r,h,i]+=-CI*v*w*z
 nl=defaultdict(list)
 for(b,j),v in N.items():nl[b-45].append((j,v))
 rby=[defaultdict(list)for _ in range(45)]
 for b,A in enumerate(R):
  for(j,i),v in A.items():rby[b][j].append((i,v))
 for(r,h,b,dd),v in Y.items():
  width=G.get((b,b),0)
  if not width:continue
  for j,w in nl[dd]:
   for i,z in rby[b][j]:groups['Y_N_X'][r,h,i]+=-CI*v*width*w*z
else:
 left={(r*45+h,c*45+a):v for(r,h,a,c),v in Z.items()};right={(a*45+c,i):v for(a,c,i),v in S.items()};groups['Z_S']={(rh//45,rh%45,i):v for(rh,i),v in mm(left,right).items()}
 for r in range(45):
  for h in range(45):
   for(c,a),v in mm(U[h],WM[r]).items():
    for i,w in sp[a,c]:groups['S_M_G_W'][r,h,i]+=v*w
 vr=defaultdict(list);ub=defaultdict(list)
 for r,A in enumerate(V):
  for(b,a),v in A.items():
   if b<45:vr[b,a].append((r,v))
 for h,A in enumerate(U):
  for(a,b),v in A.items():
   if b<45:ub[b,a].append((h,v))
 for h in range(45):
  for b,RR in enumerate(R):
   for(a,i),v in mm(MN[h],RR).items():
    for r,w in vr[b,a]:groups['Mn_G_X_G_W'][r,h,i]+=CI*v*w
   for(a,i),v in mm(UN[h],RR).items():
    for r,w in vr[b,a]:groups['M_G_N_G_X_G_W'][r,h,i]+=-CI*v*w
 for r in range(45):
  for b,RR in enumerate(R):
   for(i,a),v in mm(tr(RR),WN[r]).items():
    for h,w in ub[b,a]:groups['M_G_X_G_Wn'][r,h,i]+=-CI*v*w
   for(i,a),v in mm(tr(RR),NV[r]).items():
    for h,w in ub[b,a]:groups['M_G_X_G_N_G_W'][r,h,i]+=CI*v*w
 nL={(b-45,j):v for(b,j),v in N.items()};yy=defaultdict(list)
 for(r,h,b,dd),v in Y.items():yy[b,dd].append((r,h,v))
 for b,RR in enumerate(R):
  for(dd,i),v in mm(nL,RR).items():
   for r,h,w in yy[b,dd]:groups['Y_N_X'][r,h,i]+=-CI*G.get((b,b),0)*v*w
groups={k:clean(v)for k,v in groups.items()};F={2:groups['Z_S'],3:plus(*[(groups[k],1)for k in['S_M_G_W','Mn_G_X_G_W','M_G_X_G_Wn','Y_N_X']]),4:plus(*[(groups[k],1)for k in['M_G_N_G_X_G_W','M_G_X_G_N_G_W']])};pole=plus(*[(D,1)for D in F.values()]);basis={'chi4':pole,'log2':plus((F[4],1),(F[3],-1)),'log3':F[3],'log5':{},'fixed':{}}
for D in list(groups.values())+list(F.values())+list(basis.values()):assert all(0<=r<45 and 0<=h<45 and 0<=i<328 for r,h,i in D)
enc=lambda D:[[*k,str(v)]for k,v in sorted(D.items())];powers=sorted({key[:3]for D in F.values()for v in D.values()for key,q in v.terms});out={'schema':'AAK3_COMPLETE_INTRINSIC_ACX_LOCAL_RELATIVE_KERNEL','role':role,'groups':{k:enc(v)for k,v in groups.items()},'F_m':{str(m):enc(v)for m,v in F.items()},'relative_prime_basis':{k:enc(v)for k,v in basis.items()},'full_positions_per_tensor':664200,'parameter_monomial_powers':powers,'normalization':'hbar/(16pi^2); a_r C_h x_i; no extra half','fixed_Djet0_by_qualified_actual_support':True,'unknown_quantum_Ward_or_cutoff_not_operand':True,'full_QAP_E5_or_physical_promotion':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('color_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'F2_F3_F4_pole_nonzero':[len(F[m])for m in[2,3,4]]+[len(pole)],'group_nonzero':{k:len(v)for k,v in groups.items()},'parameter_monomial_powers':powers,'full_QAP_E5_or_physical_promotion':False},sort_keys=True),flush=True);timer.cancel()
