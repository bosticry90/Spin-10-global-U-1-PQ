from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from fractions import Fraction
from collections import defaultdict
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;R=O.parents[1];control_root=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-antighost-kernel-v1-2026-10-26');H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();bindings=copies=peak=0
for p in O.glob('*preparation*.json'):
 for f,h in read(p)['input_sha256'].items():assert H(Path(f))==h,(p,f);bindings+=1
for p in O.glob('*.source.txt'):assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes();copies+=1
caps={p.name:read(p)for p in O.glob('*capture.json')};expected_failed={'color_verify_capture.json','integration_capture.json'};assert len(caps)==9 and expected_failed<=set(caps)
for name,z in caps.items():
 assert z['post_run_observations_qualified']and z['launch']['memory']['available_pagefile']>=350*1024**2 and not z['failed_or_incomplete_counted_as_PASS'];peak=max(peak,max(q['private_bytes']for q in z['all_resource_samples']));assert peak<=8*1024**3
 if name in expected_failed:assert z['exit_code']==1 and z['execution_state']=='FAILED'and not z['calculation_completed']
 else:assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']
for p in['color_validation_receipt.json','integration_receipt.json','integration_tables.json.gz']:assert not(O/p).exists()
assert read(O/'universal_validation_receipt.json')['fixed_Djet0_structural'];cv=read(O/'color_validation_receipt_v2.json');assert cv['complete_group_heat_pole_prime_and_implicit_zero_agreement']and cv['missing_intrinsic_current_orientation_derived_from_actual_density']and all(cv['sensitive_Y_Z_when_sampled'].values())
cp=Path(read(O/'ring_inputs.json')['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient,Coeff,constant,I as CI
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
tab=lambda rows:{tuple(q[:-1]):co(q[-1])for q in rows};clean=lambda D:{k:v for k,v in D.items()if v}
def plus(*args):
 out=defaultdict(lambda:0)
 for D,f in args:
  for k,v in D.items():out[k]+=f*v
 return clean(out)
native_primary,native_replay=[load(O/('color_'+role+'_tables.json.gz'))for role in['primary','replay']];groups={k:tab(v)for k,v in native_primary['groups'].items()};assert groups=={k:tab(v)for k,v in native_replay['groups'].items()};heat={int(m):tab(rows)for m,rows in native_primary['F_m'].items()};assert heat=={int(m):tab(rows)for m,rows in native_replay['F_m'].items()};pole=plus(*[(D,1)for D in heat.values()]);basis={'chi4':pole,'log2':plus((heat[4],1),(heat[3],-1)),'log3':heat[3],'log5':{},'fixed':{}};assert basis=={k:tab(v)for k,v in native_primary['relative_prime_basis'].items()}=={k:tab(v)for k,v in native_replay['relative_prime_basis'].items()}
assert heat[2]==groups['Z_S']and heat[3]==plus(*[(groups[k],1)for k in['S_M_G_W','Mn_G_X_G_W','M_G_X_G_Wn','Y_N_X']])and heat[4]==plus((groups['M_G_N_G_X_G_W'],1),(groups['M_G_X_G_N_G_W'],1))
integration=load(O/'integration_tables_v2.json.gz');prior=load(Path(read(O/'integration_inputs.json')['late_partial']));source_checks=[]
audit=load(O/'integration_primary_inputs.json.gz')['audit'];names=audit['names'];geo=audit['geometry'];base=geo['names'];sources={names.index(base[J]):base[f]for f,J,h,k in geo['field_source_h_k']};fieldpar={n:p for n,p in zip(base,geo['parities'])};aux=[('b'if i<12 else'L')+str(i)for i in range(45)];ants=[('bar'if i<12 else'ub')+str(i)for i in range(45)]
def pp(n):return 1 if n==-1 else 1-fieldpar[sources[n]]if n in sources else fieldpar[names[n]]
def phasefield(f):return-CI if f in aux else constant(1)
def phase(n):
 if n not in sources:return phasefield(names[n])
 f=sources[n];z=phasefield(f);inv=-z if z==CI or z==-CI else z;return((-1)**(fieldpar[f]+1))*inv
for probe,pG in enumerate(audit['physical_G']):
 B=defaultdict(lambda:0);T=defaultdict(lambda:0)
 for gp,w,ci in pG['monomials']:
  targets=[n for n,I in w if n in sources and sources[n]in ants]
  if not targets:continue
  assert len(targets)==1 and len(w)==2 and not any(I for n,I in w);ja=targets[0];j=ants.index(sources[ja]);coef=-Coeff([((gp,xp,ep,m),Fraction(num,den))for xp,ep,m,num,den in pG['coefficients'][ci]])
  for n,I in w:coef=coef*phase(n)
  word=(-1,)+tuple(n for n,I in w)
  for at,n in enumerate(word):
   if n!=ja:continue
   # Generic left source derivative of Sigma=rho*G_E,then(-1)^p_a.
   sg=(-1)**(fieldpar[sources[ja]]+pp(ja)*sum(pp(nn)for nn in word[:at]));rest=word[:at]+word[at+1:];assert rest[0]==-1 and len(rest)==2;other=rest[1];v=sg*coef
   if other in sources:assert sources[other]in aux;B[aux.index(sources[other]),j]+=v
   else:assert names[other]in ants;T[j,ants.index(names[other])]+=v
 B=clean(B);T=clean(T);pr=integration['results'][probe];assert B==tab(pr['B_antighost_flow'])and T==tab(pr['T_ordinary_antighost_scaling']);active=range(12)if probe==0 else range(12,45);assert B=={(j,j):CI for j in active}and T=={(j,j):co('-eta_H/2'if probe==0 else'-xi/2')for j in active};assert pr['T_excluded_from_JL_projection_by_zero_source_degree']and not pr['unmeasured_native_roots_in_selected_set'];ops=defaultdict(list)
 for(r,j),v in B.items():ops[j].append((r,v))
 per=[]
 for basisname,F in basis.items():
  image=defaultdict(lambda:0)
  for(j,h,i),v in F.items():
   for r,w in ops[j]:image[r,h,i]+=w*v
  image=clean(image);assert image==tab(next(z['image']for z in pr['measured_kernel_image']if z['basis']==basisname))
  if basisname=='fixed':assert not image;continue
  old=tab(next(z['remaining_partial']for z in prior['results'][probe]['formal_basis']if z['basis']==basisname));total=plus((old,1),(image,1));stored=tab(next(z['remaining']for z in pr['formal_basis']if z['basis']==basisname));assert total==stored=={};wrong=plus((old,1),(image,-1))
  if probe==1 and basisname in['chi4','log2','log3']:assert wrong
  per.append([basisname,len(old),len(image),len(total),len(wrong)])
 source_checks.append({'probe':probe,'literal_B_T_source_operations_agree':True,'basis_counts_with_wrong_sign_control':per})
for stem in['universal_primary','universal_replay','color_primary','color_replay']:
 rr=read(O/(stem+'_result.json'));p=O/(stem+'_tables.json.gz');assert H(p)==rr['packed_sha256']and sha256(gzip.decompress(p.read_bytes())).hexdigest()==rr['raw_sha256']
rr=read(O/'integration_receipt_v2.json');p=O/'integration_tables_v2.json.gz';assert H(p)==rr['packed_sha256']and sha256(gzip.decompress(p.read_bytes())).hexdigest()==rr['raw_sha256'];e=read(control_root/'e4_full_capture.json');events=[json.loads(q)for q in e['stdout_and_stderr'].splitlines()];ex=[q['exit_code']for q in events if q['event']=='step_finished'];assert e['native_exit']==0 and ex==[0,0,0,0,0,2]and events[-1]['execution_state']=='COMPLETED';assert H(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'preparation_bindings_authenticated':bindings,'source_copies_equal':copies,'pre_review_captures':len(caps),'largest_pre_review_private_sample':peak,'complete_model_heat_pole_counts':[len(heat[m])for m in[2,3,4]]+[len(pole)],'universal_allD_and_literal_model_reviews_authenticated':True,'generic_literal_BV_source_flow_and_full_selected_sums_recomputed':source_checks,'both_original_failed_checks_preserved_not_PASS':True,'all_selected_native_roots_measured':True,'selected_rho_JL_Cx_relation_zero_in_each_formal_basis':True,'E4_step_exits':ex,'custody':'EXIT2_SEVEN_NOTPASS','full_Ward_master_QAP_E5_or_physical_promotion':False},sort_keys=True),flush=True);timer.cancel()
