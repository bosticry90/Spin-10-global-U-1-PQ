# AAK4: model qualification,prospective

Require complete primary/replay equality for all seven contraction groups,
F2/3/4,pole,relative-prime bases and implicit zeros at664200 positions per
tensor. Reconstruct sums independently;do not require a favorable zero.
Retain all coupling degrees and root groups. Authenticate input curation
and native captures. No partial Ward/cutoff target operand.

Corroborate by literal508-coordinate graded-log powers using the full
actual ACV Fourier Hessians,not the reduced W/Za proposals. Use bothq,
oldwitness(13,0,137),minima of nonzero F2/F3/F4/Y groups and maximumF4,
at most6 triples. N,S,W,Wn,J,Z,Y use actual quantum Hessian orientations;
X uses separately qualified scalar R. Qualified allD pinning permits the
longitudinal block. Compare complete selected heat coefficients. At q+,
test Y/Z/Wn omissions,W vector/auxiliary omissions and reference-width
omission. Record insensitive cases rather than crediting them as error
detection. Require detection of nonzero Y/Z groups where sampled.

Review180s,8GiB sampled,350MiBpagefilefloor,32MiBpacket. If either actual
symbol or complete required vertices are absent,do not relabel mismatch
as anomaly. Preserve failures/new version for routine fixes. State and
scientific ceiling unchanged. Literal samples supplement full reduced
tensor replay;they are not full508 replay of every coefficient.
