# AAK4 V2: restore the missing intrinsic current in literal checker

Original AAK4 FAILED at first literal sample(12,12,50). Its complete
reduced-tensor comparisons passed,then literalF3 omitted a known vertex.
The ACV table contains H_(a,C)|x,H_(x,C)|a,but ACV's J class covers only
H_(a,B/L)|C. It does not contain intrinsic H_(a,x)|C. The literal builder
mistakenly treated that table as including the latter orientation.

No model quantum coefficient is changed. The actual already qualified
scalar ghost Hessian is S[a,c,j],so the corresponding density is
n a_a C_c x_j S[a,c,j]. Left derivatives and the established Hessian sign
give H_(a_a,x_j)|C_c=+n C_c S[a,c,j] and
H_(x_j,a_a)|C_c=-n C_c S[a,c,j]. Derive/check these signs on a literal
three-field Grassmann density before inserting them into the checker.
Use ACV-curated S,not a native quantum F3 or desired Ward remainder.

V2 adds precisely this missing mask24 intrinsic current and a corresponding
omission control. Every original equality,normalization,sample,resource
limit and other control remains. Freeze new source/preparation;preserve
original source/copy,preparation,capture/controller and absent original
receipt. No costly model native repeats. If V2 still disagrees,it fails;
do not fit signs or remove the literal test. Same180s/8GiB/350MiB/32MiB.
