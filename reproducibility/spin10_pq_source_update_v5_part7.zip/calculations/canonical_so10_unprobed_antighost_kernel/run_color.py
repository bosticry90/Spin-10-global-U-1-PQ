from pathlib import Path
from hashlib import sha256
import ast,json,gzip,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-antighost-kernel-v1-2026-10-26');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 assert read(O/'universal_validation_receipt.json')['fixed_Djet0_structural'];b=dict(read(O/'universal_validation_preparation.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 for role in['primary','replay']:
  p=O.parent/'canonical_so10_unprobed_antighost_vertices'/('vertices_'+role+'_tables.json.gz');b[str(p)]=H(p);acv=load(p);F=next(z['groups']for z in acv['Fourier_unit_axes']if z['axis']==3 and z['q']==1);z={k:[]for k in['J','W','Wn','N','S','Z','Y']}
  for i,j,ext,v in F['J']:
   if i>=598 and(j<180 and j%4==3 or 508<=j<553):z['J'].append([ext[0]-553,i-598,j//4 if j<180 else j-508+45,v])
  for i,j,ext,v in F['W']:
   if 553<=j<598 and(i<180 and i%4==3 or 508<=i<553):z['W'].append([ext[0]-598,j-553,i//4 if i<180 else i-508+45,v])
  for i,j,ext,v in F['Wn']:
   if 180<=i<508 and 553<=j<598:z['Wn'].append([ext[0]-598,j-553,i-180,v])
  for i,j,ext,v in F['N']:
   if 508<=i<553 and 180<=j<508:z['N'].append([i-508+45,j-180,v])
  for i,j,ext,v in F['S']:
   if i>=598 and 553<=j<598:z['S'].append([i-598,j-553,ext[0]-180,v])
  for i,j,ext,v in F['Za']:
   if i>=598 and 553<=j<598:z['Z'].append([ext[0]-598,ext[1]-553,i-598,j-553,v])
  for i,j,ext,v in F['KBB']:
   if i%4==3 and j%4==3:z['Y'].append([ext[0]-598,ext[1]-553,i//4,j//4,v])
  p=O.parent/'canonical_so10_intrinsic_source_cutoff_defect'/('kernel_v2_'+role+'_inputs.json.gz');b[str(p)]=H(p);cl=load(p);z['R']=cl['R'];z['G0']=cl['endings']['G0'];p=O/('color_'+role+'_inputs.json.gz')
  with p.open('xb')as f:f.write(gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
 for n in['MODEL_RECORD.md','color.py','run_color.py']:
  p=O/n
  with(O/(n+'.source.txt')).open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
 for p in O.iterdir():
  if p.is_file():b[str(p)]=H(p)
 dump(O/'color_preparation.json',{'input_sha256':b,'seconds_after_imports':300,'scientific_acceptance':'NOT_PERFORMED'})
 for role in['primary','replay']:
  z=capture([sys.executable,'-B',str(O/'color.py'),role]);dump(O/('color_'+role+'_capture.json'),z);dump(C/('color_'+role+'_full_capture.json'),z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
  rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<300;dump(O/('color_'+role+'_result.json'),rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2;print('COMPLETED_AAK3',role,json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'color_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
