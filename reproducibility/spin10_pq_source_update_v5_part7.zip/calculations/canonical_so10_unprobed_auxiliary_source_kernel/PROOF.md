# Auxiliary-source Schur reduction and Lorentz support

All statements concern the declared unshifted A0 local relative symbol and
finite ordered Gaussian coefficients. They do not supply continuum product,
nonlinear master,measure or QAP applicability for the full chiral theory.

The actual auxiliary source has quantum vertex J C W with W supported in
Lambda rows. The ordinary ghost current is a C M0 b;its intrinsic scalar
ending is n a C Mn b. The direct source ghost vertex is J C a Z C_quantum,
and the scalar ghost mass is n x a S C_quantum. Eliminating the bosonic
quadratic block produces the ghost potential

    D_eff=D0+n x S+J C[Z+(M0+n Mn)(K0+n N+x X)^-1 W].

The plus sign of the mixed term follows by moving J C past the quantum
antighost in the bosonic cross contraction. The ghost integral gives
minus Trlog. Expanding the inverse in its retained positive grades gives

 F2=Tr(Z S),
 F3=Tr(S M0 G W)+Tr(Mn G X G W),
 F4=-Tr(M0 G N G X G W+M0 G X G N G W).

Every heat edge is retained. An intrinsic N insertion is between two
regulated propagators and is not an unregulated free cancellation.
Bosonic determinant terms have no auxiliary source and cannot contribute
to this target. The direct ordered logarithm has(-1)^(m+1)/(2m) weights
per q mode. The full paired Hessian has twice the fields,so onequarter
STrlog equals the paired average of the single-mode half-STrlog. UAK1
checks these signs/weights directly from literal graded derivatives.

At p²=1 the longitudinal reference has G_BB=width,G_BL=-q,G_LB=q,
G_LL=0,G_xx=identity. GW lies only in B_long,so NGW=0 exactly. The second
F4 ordering therefore vanishes as a complete port group. Neither a
reference G_BB width nor the Lambda component of M0 enters any surviving
trace. This follows from source support and G_LL=0,not a chosen width.
The separately studied scalar-source W_x class does not have this
property;its nonzero auxiliary-current control is retained as a comparator.

The actual82-profile catalogue is classified exhaustively by the four
grade families JC*nx,J*C*nx,J*nC*x,J*C*n*x. Abstract scalar-potential and
fermion supersets have zero target cycles in the qualified inventory.
Every vector port is a mixed B/L propagator or is adjacent to an ordinary
ghost-current/physical scalar derivative carrying that vector's momentum.
There is no closed unpinned vector spectator. No G_BB link is used in
these complete target paths. Thus longitudinal reduction is exact at
every dimension D,not inferred by interpolation of D3/4/5 tests.

Restoring p,each vector/scalar or current/mixed pair contracts to p² with
its actual inverse reference powers. All retained traces have total
radial degree p^-4. No free Lorentz-index trace or d-dependent angular
contraction remains. The fixed dimensional jet is therefore zero in this
specified symbol. The relative m-edge finite factor is chi4+log(m/2),
using the qualified radial convention without selecting chi4.

Write B_h=J0_h[:,B],N_L=N0[Lambda,:],R_b the actual scalar generator and
W_r[b,c]=beta[r,c,b]. Then the complete coordinate expressions are

 F2[r,h,i]=sum_(a,c) Z0[r,h,a,c] S0[c,a,i],
 F3[r,h,i]=-sum_(a,c,b) S0[a,c,i] B_h[c,b] beta[r,a,b]
             -i sum_(a,j,b) S0[a,h,j] R_b[j,i] beta[r,a,b],
 F4[r,h,i]=-i sum_(a,b,d,j) B_h[a,b] N_L[b,j] R_d[j,i] beta[r,a,d].

These signs follow from HX_(B,x)=-i q R,HX_(x,B)=+i q R and G_BL=-q,
not a comparison with an unknown source kernel or the Ward remainder.
The forthcoming model calculation must use the actual qualified charts,
metrics,source phases and all indices in these formulas.
