# UAK2: ordered kernel,actual support and normalization comparator

Prospective after UAK1 primary/replay completed. Authenticate their exact
fixtures and controls,then compare all heat coefficients. Check the
source-location distinction:auxiliary-current/GBB-width omissions are
insensitive for W_Lambda,but auxiliary-current omission is sensitive for
the W_x scalar-source comparator. Only now read the old qualified USR2
generic scalar-source result and compare its normalization with the value
independently calculated in UAK1. No new model quantum coefficient is read.

Classify all82 actual JL Cx raw profiles into the complete Schur grade
families. Check all mixed/vector momentum endpoints,no G_BB edge or closed
vector spectator,and source quantum support(C,L)/(L,C). All old catalogue
member references remain bound in their original bytes,not a truncated
diagnostic display. Authenticate actual N0 Lambda-only support and free
G_LL=0 from qualified classical data. Bind PROOF.md and actual receipts.
The full-dimensional pinning and half/log-weight arguments are accepted
only in this retained symbol domain.180s/8GiB sampled/350MiB floor/32MiB.
