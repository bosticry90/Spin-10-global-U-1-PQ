# UAK1+: actual intrinsic auxiliary-source JL Cx kernel

Prospective ata897e472784a67a45d0cb0fef4d6dc36f5aab9df,V635. Previous
goal turn PROGRESS;fresh preflight clean main,no matching workers,ACTIVE
goal. State113,authority34/39,E5/A5 OPEN,custodyexit2/seven NOTPASS.
Live AGENTS/charter/solo review/epistemic ladder apply. No agents,branch/
worktree,remote actions,publication,outreach,foundation/scheme/benchmark
adoption,flavor/HB1/C5 activation,protected promotion or state edit.

Question:what is the first of the two missing actual ordinary source
kernels needed for the finite rho JL Cx relation? Measure the unprobed
intrinsic JL Cx kernel from the actual action,not from a negative partial
remainder. The82-profile USR6 catalogue(4/30/48 heat2/3/4) supplies complete
support and abstract potential/fermion exclusions. No quantum coefficient
for this kernel has yet been supplied to the proposed calculation.

Original unshifted SMA/CSW/EDS,A0,zero external jets,intrinsicdegree1,
all45 auxiliary sources,45 ghosts,328 scalars,symbolicg10/xi/eta_H. Same
Euclidean nonexceptional LOCAL RELATIVE symbol,commonhbar/(16pi^2),not
physical scalelessp0,massive/causal vacuum,absolute products or adopted
scheme. chi4,b0,kappa,IR freedom remain distinct and unselected.

First qualify the ordered kernel and global normalization on literal
paired-mode graded Gaussian fixtures,independent of model coefficients.
Onequarter STrlog of the complete two-mode Hessian equals the paired-q
average of onehalf STrlog. The m-th ordered weight is(-1)^(m+1)/(2m)
in a single mode. Use direct graded Hessian/log expansion versus bosonic
Schur elimination and the ordinary ghost determinant. Do not choose
signs or an extra half from comparison with the desired Ward remainder.

Write N for the intrinsic Lambda–scalar Hessian,X for physical scalar
kinetic HX,M0 for ordinary antighost–ghost current,Mn for its intrinsic
scalar endpoint,W for the actual source vertex supported only in Lambda,
Z for the direct JC ghost vertex,and S for the intrinsic scalar ghost
mass. The proposed heat-resolved kernel is

 F2=Tr(Z S),
 F3=Tr(S M0 G W)+Tr(Mn G X G W),
 F4=-Tr(M0 G N G X G W+M0 G X G N G W).

This remains a proposal until literal Gaussian and normalization checks
pass. Every order is retained before a structural zero is proved. W's
Lambda support and G_LL=0 suggest only the vector current contributes;
J_L omission and reference G_BB-width changes should be insensitive for
this kernel. That is different from the earlier JxCx kernel,where scalar
source support makes both vector/auxiliary current matter. Test this
support distinction,do not transfer results between those sectors.

Every vector segment must be proved longitudinally pinned using the actual
82 profiles and source support. No closed vector spectator is permitted
by that proposed reduction. Qualify fixed dimensional jet0 structurally,
not solely by checking D3/4/5 examples. Otherwise retain the required
dimensional finite terms. Radial relative rule is chi4+log(m/2) for m
positive-heat edges;verify with existing qualified radial evidence or
independent integrals. Preserve source Wick/parity signs and q endpoints.

After that prerequisite,reconstruct actual beta,Z0,S0,N0,J0,R from bound
qualified classical data. Measure all source/ghost/scalar positions using
distinct scalar/color contraction associations. Include implicit zeros,
root/heat groups and symbolic couplings. Use literal selected508-coordinate
logarithms as additional controls and source/endpoint/order omissions where
sensitive. Keep expected insensitive controls explicitly classified.

Shared action,charts,frontend helpers,coefficient software,Python/SymPy and
AI authorship remain limits. Old cutoff/partial-H outputs cannot be native
operands. A source-operation comparison is permitted only afterward under
a separate record. The second aCx kernel,full nonlinear source/master,
continuum QAP/products/measure and physical-domain questions remain open.

Sequential300s native/180s review afterimports,8GiB sampled private,
350MiB available-pagefile launch floor,32MiB retained packet. Freeze
sources,copies,input hashes before computation. Failed support,normalization,
unexpected operators or exhaustion leaves affected scope unqualified;
preserve exact failures without fitting or silent limit expansion.
