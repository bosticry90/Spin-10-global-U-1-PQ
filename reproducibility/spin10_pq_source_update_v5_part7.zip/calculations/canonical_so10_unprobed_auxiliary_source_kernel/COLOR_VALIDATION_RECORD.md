# UAK4: whole model tensor and literal normalization

Prospective after both UAK3 natives completed. Compare F2/F3/F4,pole,all
relative-prime tensors and the two separate F3 contractions at every
declared position and implicit zero. The observed F3=0 and pole=0 require
actual exact comparison,not an expectation inferred from the desired Ward
identity. Check all unbroken-source and scalar-singlet columns in each
heat group,not only in the already zero pole. No physical inference follows.

Use the original full508-coordinate graded Hessian at deterministic
triples(old witness plus lexicographic endpoints of nonzero groups),both
q orientations. Compute the single-mode half-STrlog with the UAK2-qualified
weights,compare each heat coefficient and the separate F3 grade families.
Check direct source and intrinsic N omissions sensitively;the generic
proof predicts actual auxiliary-current and G_BB-width omissions insensitive
in this source class. Keep actual zero-current controls distinct from
UAK1 generic controls,where the independent S/Mn pieces are nonzero.

Authenticate complete inputs,copies,hashes,captures/resources and support
receipt. Shared action,scalar R derivation,charts,frontend/ring and AI
authorship remain limits. No old partial-H/cutoff quantum table is read.
180s afterimports,8GiB sampled,350MiB floor,32MiB packet. Failures preserve
all sources/outputs and receive no qualification receipt. No QAP/E5 promotion.
