from pathlib import Path
from hashlib import sha256
import ast,json,gzip,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1];C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-auxiliary-source-kernel-v1-2026-10-26');sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('xb')as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
 assert read(O/'color_validation_receipt.json')['full_heat_coefficients_and_implicit_zeros_agree'];b=dict(read(O/'color_validation_preparation.json')['input_sha256'])
 for p,h in b.items():assert H(Path(p))==h,p
 for role in['primary','replay']:
  p=O.parent/'canonical_so10_intrinsic_source_cutoff_defect'/('kernel_v2_'+role+'_inputs.json.gz');b[str(p)]=H(p);a=load(p)['audit'];d={'audit':{k:v for k,v in a.items()if k in['geometry','names','physical_G']}};p=O/('integration_'+role+'_inputs.json.gz')
  with p.open('xb')as f:f.write(gzip.compress((json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
  b[str(p)]=H(p)
 old=O.parent/'canonical_so10_intrinsic_correlated_source_contacts/partial_H_tables.json.gz';b[str(old)]=H(old);z=load(old);dump(O/'old_pending_operations.json',{'results':[q['pending_operation_matrices']for q in z['results']]});ip={'old_pending_operations':str(O/'old_pending_operations.json'),'late_partial_H_plus_cutoff':str(O.parent/'canonical_so10_intrinsic_source_cutoff_remaining/partial_tables.json.gz')};dump(O/'integration_inputs.json',ip)
 for p in[Path(v)for v in ip.values()]+[O/'integration_inputs.json',O.parent/'canonical_so10_intrinsic_source_cutoff_remaining/final_review_validation_receipt_v2.json']:b[str(p)]=H(p)
 for n in['INTEGRATION_RECORD.md','integrate.py','run_integration.py']:
  p=O/n;cp=O/(n+'.source.txt')
  with cp.open('xb')as f:f.write(p.read_bytes())
  if p.suffix=='.py':ast.parse(p.read_bytes())
 for p in O.iterdir():
  if p.is_file():b[str(p)]=H(p)
 dump(O/'integration_preparation.json',{'input_sha256':b,'seconds_after_imports':180,'scientific_acceptance':'NOT_PERFORMED'})
 z=capture([sys.executable,'-B',str(O/'integrate.py')]);dump(O/'integration_capture.json',z);dump(C/'integration_full_capture.json',z);assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes']for v in z['all_resource_samples'])<=8*1024**3
 rr=[json.loads(q[7:])for q in z['stdout_and_stderr'].splitlines()if q.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<180;dump(O/'integration_receipt.json',rr[0]);assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2;print(json.dumps(rr[0],sort_keys=True),flush=True)
except BaseException:
 dump(O/'integration_controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
