from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;R=O.parents[1];control_root=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-auxiliary-source-kernel-v1-2026-10-26');H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();bindings=copies=peak=0
for p in O.glob('*preparation*.json'):
 for f,h in read(p)['input_sha256'].items():assert H(Path(f))==h,(p,f);bindings+=1
for p in O.glob('*.source.txt'):assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes();copies+=1
caps={p.name:read(p)for p in O.glob('*capture.json')};assert set(caps)=={'universal_primary_capture.json','universal_replay_capture.json','universal_verify_capture.json','color_primary_capture.json','color_replay_capture.json','color_verify_capture.json','integration_capture.json','integration_v2_capture.json'}
for name,z in caps.items():
 assert z['post_run_observations_qualified']and z['launch']['memory']['available_pagefile']>=350*1024**2 and not z['failed_or_incomplete_counted_as_PASS'];peak=max(peak,max(q['private_bytes']for q in z['all_resource_samples']));assert peak<=8*1024**3
 if name=='integration_capture.json':assert z['exit_code']==1 and z['execution_state']=='FAILED'and not z['calculation_completed']
 else:assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']
assert read(O/'integration_controller_failure.json')['execution_state']=='FAILED'and not(O/'integration_receipt.json').exists()and not(O/'integration_tables.json.gz').exists();assert not(O/'integration_controller_failure_v2.json').exists();uv=read(O/'universal_validation_receipt.json');assert uv['all82_actual_profiles_covered_by_four_Schur_grade_families']and uv['old_scalar_source_normalization_comparator_agrees']and uv['fixed_D_jet_zero_structural_not_interpolated'];cv=read(O/'color_validation_receipt.json');assert cv['F2_plus_F4_pole_exact_zero']and cv['F3_mass_and_scalar_current_each_exact_zero']and cv['full_heat_coefficients_and_implicit_zeros_agree']and all(cv['sensitive_source_and_N_omissions'].values())
cp=Path(read(O/'ring_inputs.json')['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
tab=lambda rows:{tuple(q[:-1]):co(q[-1])for q in rows};a,b=[load(O/('color_'+role+'_tables.json.gz'))for role in['primary','replay']];heat={m:tab(a['F_m'][str(m)])for m in[2,3,4]};assert all(D==tab(b['F_m'][str(m)])for m,D in heat.items());assert heat[2]=={k:-v for k,v in heat[4].items()}and not heat[3];assert all(0<=r<45 and 0<=h<45 and 0<=i<328 for D in heat.values()for r,h,i in D);assert all(not(r<12 or i>=326)for D in heat.values()for r,h,i in D)
for name in['chi4','log2','log3','log5','fixed']:assert tab(a['relative_prime_basis'][name])==tab(b['relative_prime_basis'][name])==(heat[4]if name=='log2'else{})
assert a['parameter_monomial_powers']==b['parameter_monomial_powers']==[[4,1,0]];images=load(O/'integration_tables_v2.json.gz');ip=read(O/'integration_inputs.json');pending=read(Path(ip['old_pending_operations']));prior=load(Path(ip['late_partial_H_plus_cutoff']));summary=[]
for probe,pr in enumerate(images['results']):
 A=tab(pr['source_flow_A']);assert {(j,r):v for(r,j),v in A.items()}==tab(pending['results'][probe]['C_JL_x']);expected={(i,i):co('eta_H/2'if probe==0 else'xi/2')for i in(range(12)if probe==0 else range(12,45))};assert A==expected;ops=defaultdict(list)
 for(r,j),v in A.items():ops[j].append((r,v))
 im={}
 for basis,rows in a['relative_prime_basis'].items():
  F=tab(rows);D=defaultdict(lambda:0)
  for(j,h,i),v in F.items():
   for r,w in ops[j]:D[r,h,i]+=w*v
  D={k:v for k,v in D.items()if v};actual=tab(next(z['image']for z in pr['measured_kernel_image']if z['basis']==basis));assert D==actual;im[basis]=D
 per=[]
 for old in prior['results'][probe]['formal_basis']:
  basis=old['basis'];P0=tab(old['partial_sum']);D=im[basis];keys=set(P0)|set(D);total={k:P0.get(k,0)+D.get(k,0)for k in keys};total={k:v for k,v in total.items()if v};current=next(z for z in pr['formal_basis']if z['basis']==basis);assert total==tab(current['remaining_partial']);per.append([basis,len(P0),len(D),len(total)])
 assert pr['remaining_unmeasured_native_root']=='intrinsic aCx';summary.append({'probe':probe,'source_operation_nonzero':len(A),'partial_counts':per})
for stem in['universal_primary','universal_replay','color_primary','color_replay']:
 rr=read(O/(stem+'_result.json'));p=O/(stem+'_tables.json.gz');assert H(p)==rr['packed_sha256']and sha256(gzip.decompress(p.read_bytes())).hexdigest()==rr['raw_sha256']and rr['elapsed_after_imports']<300
rr=read(O/'integration_receipt_v2.json');p=O/'integration_tables_v2.json.gz';assert H(p)==rr['packed_sha256']and sha256(gzip.decompress(p.read_bytes())).hexdigest()==rr['raw_sha256']and rr['elapsed_after_imports']<180;e=read(control_root/'e4_full_capture.json');events=[json.loads(q)for q in e['stdout_and_stderr'].splitlines()];ex=[q['exit_code']for q in events if q['event']=='step_finished'];assert e['native_exit']==0 and ex==[0,0,0,0,0,2]and events[-1]['execution_state']=='COMPLETED';assert H(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';diag=read(control_root/'preliminary_readonly_diagnostics.json');assert not diag['oversized_catalogue_display']['scientific_calculation_or_acceptance'];assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<32*1024**2
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'preparation_bindings_authenticated':bindings,'source_copies_equal':copies,'pre_review_captures':len(caps),'largest_pre_review_private_sample':peak,'complete_model_F2_F3_F4_pole_counts':[len(heat[m])for m in[2,3,4]]+[0],'universal_support_and_actual_literal_normalization_authenticated':True,'source_image_and_partial_sum_recomputed':summary,'original_integration_NameError_preserved_not_PASS':True,'remaining_native_kernel':'intrinsic aCx','E4_native_exit':e['native_exit'],'E4_step_exits':ex,'custody':'EXIT2_SEVEN_NOTPASS','full_QAP_Ward_E5_or_physical_promotion':False},sort_keys=True),flush=True);timer.cancel()
