from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from itertools import permutations
import ast,json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'color_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
cp=Path(read(O/'ring_inputs.json')['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient,constant
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
tab=lambda rows:{tuple(q[:-1]):co(q[-1])for q in rows};a,b=[load(O/('color_'+role+'_tables.json.gz'))for role in['primary','replay']];assert a['full_positions_per_tensor']==b['full_positions_per_tensor']==664200;F={};zero_checks=[]
for m in['2','3','4']:
 F[int(m)]=tab(a['F_m'][m]);assert F[int(m)]==tab(b['F_m'][m]);D=F[int(m)];assert all(0<=r<45 and 0<=h<45 and 0<=i<328 for r,h,i in D);zero_checks.append({'heat':int(m),'nonzero':len(D),'zero':664200-len(D),'unbroken_source_nonzero':sum(r<12 for r,h,i in D),'scalar_singlet_nonzero':sum(i>=326 for r,h,i in D)})
for key in['ghost_mass','scalar_current']:assert tab(a['F3_groups'][key])==tab(b['F3_groups'][key])=={}
keys=set().union(*(set(D)for D in F.values()));assert all(F[2].get(k,0)+F[4].get(k,0)==0 for k in keys)and not F[3];assert all(not q['unbroken_source_nonzero']and not q['scalar_singlet_nonzero']for q in zero_checks);assert a['parameter_monomial_powers']==b['parameter_monomial_powers']==[[4,1,0]]
for name in['chi4','log2','log3','log5','fixed']:
 D=tab(a['relative_prime_basis'][name]);assert D==tab(b['relative_prime_basis'][name]);assert D==(F[4]if name=='log2'else{}),name
for role in['primary','replay']:
 rr=read(O/('color_'+role+'_result.json'));p=O/('color_'+role+'_tables.json.gz');assert H(p)==rr['packed_sha256']and sha256(gzip.decompress(p.read_bytes())).hexdigest()==rr['raw_sha256']and rr['elapsed_after_imports']<300
ip=read(O/'color_validation_inputs.json');p=Path(ip['RSH_classical_helper']);src=p.read_text();tree=ast.parse(src);cut=next(n.lineno for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='results'for t in n.targets));prefix='\n'.join(src.splitlines()[:cut-1]).replace('sys.addaudithook(guard)','assert True # authenticated independent normalization review');assert prefix.count('r=13;h=0;ix=137')==1
def model(r,h,i):
 ns={'__file__':str(p),'__name__':'UAK4_LITERAL_LOG'};sv=sys.argv;sys.argv=[str(p),'primary'];exec(compile(prefix.replace('r=13;h=0;ix=137',f'r={r};h={h};ix={i}'),str(p),'exec'),ns);sys.argv=sv;ns['timer'].cancel();ns['target']=60;return ns
def logarithm(ns,G,V):
 X=ns['mm'](G,V);power={(i,i):{0:constant(1)}for i in range(508)};out={}
 for m in range(1,5):power=ns['mm'](power,X);out[m]=co(str(s.Rational((-1)**(m+1),2*m)))*ns['tr'](power)
 return out
samples={(13,0,137)}
for D in F.values():
 if D:samples.update([min(D),max(D)])
assert len(samples)<=5;checks=[];controls=[];detected={'drop_direct_JC':False,'drop_N':False}
for r,h,i in sorted(samples):
 ns=model(r,h,i)
 for q in[1,-1]:
  G,V,roots=ns['pieces'](0,q);V={ij:{mask:v for mask,v in D.items()if not(mask&~60)}for ij,D in V.items()};V={ij:D for ij,D in V.items()if D};got=logarithm(ns,G,V);assert not got[1]and all(got[m]==F[m].get((r,h,i),0)for m in[2,3,4]),(r,h,i,q);checks.append([r,h,i,q,{str(m):str(got[m])for m in[2,3,4]}]);single={mask:ns['mm'](G,{ij:{mask:D[mask]}for ij,D in V.items()if mask in D})for mask in[4,8,16,24,32,48]}
  for group,seq in[('ghost_mass',[4,8,48]),('scalar_current',[4,24,32])]:
   z=constant(0)
   for ww in permutations(seq):
    M={(j,j):{0:constant(1)}for j in range(508)}
    for mask in ww:M=ns['mm'](M,single[mask])
    z+=co('1/6')*ns['tr'](M)
   assert z==0,('literal_F3_group_not_zero',group,r,h,i,q)
  if q==1:
   for ctrl in['drop_direct_JC','drop_N','drop_aux_current','drop_BB_width','drop_Mn']:
    GG={ij:dict(D)for ij,D in G.items()};VV={ij:dict(D)for ij,D in V.items()}
    if ctrl in['drop_direct_JC','drop_N','drop_Mn']:
     mask={'drop_direct_JC':12,'drop_N':16,'drop_Mn':24}[ctrl];VV={ij:{k:v for k,v in D.items()if k!=mask}for ij,D in VV.items()};VV={ij:D for ij,D in VV.items()if D}
    elif ctrl=='drop_aux_current':
     for(ii,jj),D in VV.items():
      if(45<=ii<90 and jj>=463)or(ii>=463 and 45<=jj<90):D.pop(8,None)
     VV={ij:D for ij,D in VV.items()if D}
    else:GG={ij:D for ij,D in GG.items()if not(ij[0]<45 and ij[1]<45)}
    bad=logarithm(ns,GG,VV);changed=[m for m in[1,2,3,4]if bad[m]!=got[m]]
    if ctrl in['drop_aux_current','drop_BB_width','drop_Mn']:assert not changed
    else:detected[ctrl]|=bool(changed)
    controls.append({'sample':[r,h,i],'control':ctrl,'changed_heat_groups':changed})
 print('STAGE UAK4 literal',r,h,i,flush=True)
assert all(detected.values())
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'full_heat_coefficients_and_implicit_zeros_agree':True,'heat_group_counts_and_zero_rows':zero_checks,'F3_mass_and_scalar_current_each_exact_zero':True,'F2_plus_F4_pole_exact_zero':True,'relative_kernel_is_measured_F4_times_log2':True,'literal_selected508_logarithms_and_both_q':checks,'model_controls':controls,'sensitive_source_and_N_omissions':detected,'old_Ward_remainder_not_read':True,'full_QAP_E5_or_physical_promotion':False},sort_keys=True),flush=True);timer.cancel()
