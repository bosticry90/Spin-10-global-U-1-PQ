from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from fractions import Fraction
from collections import defaultdict
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'integration_preparation_v2.json')['input_sha256'].items():assert H(Path(p))==h,p
assert read(O/'color_validation_receipt.json')['relative_kernel_is_measured_F4_times_log2'];cp=Path(read(O/'ring_inputs.json')['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient,Coeff,constant,I as CI
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
tab=lambda rows:{tuple(q[:-1]):co(q[-1])for q in rows};clean=lambda D:{k:v for k,v in D.items()if v};enc=lambda D:[[*k,str(v)]for k,v in sorted(D.items())]
def mm(A,B):
 by=defaultdict(list);out=defaultdict(lambda:0)
 for(i,j),v in B.items():by[i].append((j,v))
 for(i,k),v in A.items():
  for j,w in by[k]:out[i,j]+=v*w
 return clean(out)
# Literal source/field-order fixture:rho,J,C odd;Lambda,x even.
par={0:1,1:1,2:1,3:0,4:0};word=(0,1,3)
left=lambda w,i:[(w[:at]+w[at+1:],(-1)**(par[i]*sum(par[n]for n in w[:at])))for at,n in enumerate(w)if n==i]
assert left(word,1)==[((0,3),-1)]and left(word,3)==[((0,1),1)]
kernelword=(1,2,4);assert left(kernelword,1)==[((2,4),1)]
Audits=[load(O/('integration_'+role+'_inputs.json.gz'))['audit']for role in['primary','replay']];kernel=[load(O/('color_'+role+'_tables.json.gz'))for role in['primary','replay']];operations=[];images=[]
for role,audit in zip(['primary','replay'],Audits):
 names=audit['names'];geo=audit['geometry'];base=geo['names'];sources={names.index(base[J]):base[f]for f,J,h,k in geo['field_source_h_k']};fields={names.index(base[f]):base[f]for f,J,h,k in geo['field_source_h_k']};aux=[('b'if i<12 else'L')+str(i)for i in range(45)];ants=[('bar'if i<12 else'ub')+str(i)for i in range(45)];sourcefields={sources[n]for p in audit['physical_G']for gp,w,ci in p['monomials']for n,I in w if n in sources};assert sourcefields<=set(aux+ants),'additional_C_or_x_source_flow_requires_continuation';per=[]
 for probe,p in enumerate(audit['physical_G']):
  A=defaultdict(lambda:0)
  for gp,w,ci in p['monomials']:
   if len(w)!=2 or any(I for n,I in w):continue
   ss=[(at,n)for at,(n,I)in enumerate(w)if n in sources]
   if len(ss)!=1:continue
   at,n=ss[0];f=sources[n];other=w[1-at][0]
   if f not in aux or other not in fields or names[other]not in aux:continue
   v=Coeff([((gp,xp,ep,m),Fraction(num,den))for xp,ep,m,num,den in p['coefficients'][ci]])
   if role=='primary':GE=-v*(-CI)*(-CI);z=GE # even-Lambda Euler derivative
   else:field_tangent=-v;z=-field_tangent # global G_E phase is -(-i)^2=+1
   A[aux.index(f),aux.index(names[other])]+=z
  per.append(clean(A))
 operations.append(per)
assert operations[0]==operations[1]
for probe,A in enumerate(operations[0]):
 per=[]
 for basis,rows in kernel[0]['relative_prime_basis'].items():
  F=tab(rows);assert F==tab(kernel[1]['relative_prime_basis'][basis]);direct=defaultdict(lambda:0);by=defaultdict(list)
  for(r,j),v in A.items():by[j].append((r,v))
  for(j,h,i),v in F.items():
   for r,w in by[j]:direct[r,h,i]+=w*v
  direct=clean(direct);flat={(j,h*328+i):v for(j,h,i),v in F.items()};matrix={(r,hi//328,hi%328):v for(r,hi),v in mm(A,flat).items()};assert direct==matrix;per.append({'basis':basis,'image':enc(direct),'nonzero':len(direct)})
 images.append({'probe':probe,'A_source_flow':enc(A),'A_nonzero':len(A),'measured_kernel_image':per})
# The operator and its image have now been calculated. Old operation
# coefficients and partial H are late comparators only.
ip=read(O/'integration_inputs.json');pending=read(Path(ip['old_pending_operations']))
for probe,A in enumerate(operations[0]):expected=tab(pending['results'][probe]['C_JL_x']);assert {(j,r):v for(r,j),v in A.items()}==expected,('old_pending_source_operation_disagrees',probe)
prior=load(Path(ip['late_partial_H_plus_cutoff']));results=[]
for probe,im in enumerate(images):
 per=[]
 for pp in prior['results'][probe]['formal_basis']:
  basis=pp['basis'];old=tab(pp['partial_sum']);new=tab(next(q['image']for q in im['measured_kernel_image']if q['basis']==basis));keys=set(old)|set(new);total={k:old.get(k,0)+new.get(k,0)for k in keys};total=clean(total);per.append({'basis':basis,'prior_partial_nonzero':len(old),'new_auxiliary_source_image_nonzero':len(new),'remaining_partial_nonzero':len(total),'remaining_partial':enc(total),'positions_checked':664200})
 results.append({'probe':probe,'source_flow_A':im['A_source_flow'],'measured_kernel_image':im['measured_kernel_image'],'formal_basis':per,'remaining_unmeasured_native_root':'intrinsic aCx'})
out={'schema':'UAK5_ACTUAL_SOURCE_FLOW_AND_ONE_REMAINING_NATIVE_KERNEL','results':results,'source_flow_reconstructed_before_old_operation_comparison':True,'both_image_contraction_methods_agree':True,'no_unknown_aCx_or_normalization_fitted':True,'whole_Ward_QAP_E5_or_anomaly_verdict':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/'integration_tables_v2.json.gz').open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'source_operation_counts':[len(A)for A in operations[0]],'source_images_by_probe':[[[q['basis'],q['nonzero']]for q in z['measured_kernel_image']]for z in images],'late_partial_counts':[[[q['basis'],q['prior_partial_nonzero'],q['new_auxiliary_source_image_nonzero'],q['remaining_partial_nonzero']]for q in z['formal_basis']]for z in results],'remaining_native_root':'intrinsic aCx','full_QAP_E5_or_anomaly_verdict':False},sort_keys=True),flush=True);timer.cancel()
