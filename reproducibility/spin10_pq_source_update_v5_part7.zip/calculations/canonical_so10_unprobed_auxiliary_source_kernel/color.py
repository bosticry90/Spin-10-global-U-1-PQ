from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'color_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
cp=Path(read(O/'ring_inputs.json')['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient,constant,I as CI,verify_basis_products
assert verify_basis_products()==1024
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('color_'+('replay'if role=='primary'else'primary')):raise PermissionError('UAK3_PEER_DENIED')
  if p.parent.name in['canonical_so10_intrinsic_source_cutoff_remaining','canonical_so10_intrinsic_source_cutoff_color','canonical_so10_intrinsic_correlated_source_contacts']:raise PermissionError('UAK3_DESIRED_WARD_OR_CUTOFF_TARGET_DENIED')
  if p.parent.name=='canonical_so10_unprobed_source_root_module'and p.name.endswith('tables.json.gz'):raise PermissionError('UAK3_OLD_QUANTUM_ROOT_NOT_OPERAND')
sys.addaudithook(guard);g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
def dec(z):return {(i,j):co(v)for i,j,v in z['entries']}
def tab(z):return {tuple(q[:-1]):co(q[-1])for q in z}
def clean(D):return {k:v for k,v in D.items()if v}
def mm(A,B):
 by=defaultdict(list);out=defaultdict(lambda:0)
 for(i,j),v in B.items():by[i].append((j,v))
 for(i,k),v in A.items():
  for j,w in by[k]:out[i,j]+=v*w
 return clean(out)
def transpose(A):return {(j,i):v for(i,j),v in A.items()}
def plus(*terms):
 out=defaultdict(lambda:0)
 for D,f in terms:
  for k,v in D.items():out[k]+=f*v
 return clean(out)
d=load(O/('color_'+role+'_inputs.json.gz'));R=list(map(dec,d['R']));S=tab(d['S0']);Z=tab(d['Z0']);beta=tab(d['beta']);E=d['endings'];G=dec(E['G0']);Nfull=dec(E['N0']);assert all(a>=45 for a,j in Nfull);N={(a-45,j):v for(a,j),v in Nfull.items()};JB=[]
for q in E['J0']:JB.append({(a,b):v for(a,b),v in dec(q).items()if b<45})
assert {(i,j):v for(i,j),v in G.items()if i<45<=j}=={(i,45+i):constant(-1)for i in range(45)}and {(i,j):v for(i,j),v in G.items()if j<45<=i}=={(45+i,i):constant(1)for i in range(45)}and not any(v for(i,j),v in G.items()if i>=45 and j>=45)
for A in R:
 for(i,j),v in A.items():assert v+A.get((j,i),0)==0
F2=defaultdict(lambda:0);F3mass=defaultdict(lambda:0);F3direct=defaultdict(lambda:0);F4=defaultdict(lambda:0)
if role=='primary':
 spair=defaultdict(list);jrow=defaultdict(list);bb=defaultdict(list);rrow=defaultdict(list);ny=defaultdict(list)
 for(a,c,i),v in S.items():spair[a,c].append((i,v))
 for h,A in enumerate(JB):
  for(a,b),v in A.items():jrow[a].append((h,b,v))
 for(r,a,b),v in beta.items():bb[a,b].append((r,v))
 for b,A in enumerate(R):
  for(j,i),v in A.items():rrow[j].append((b,i,v))
 for(r,h,a,c),v in Z.items():
  for i,w in spair[c,a]:F2[r,h,i]+=v*w
 for(a,c,i),v in S.items():
  for h,b,w in jrow[c]:
   for r,z in bb[a,b]:F3mass[r,h,i]+=-v*w*z
 for(a,h,j),v in S.items():
  for b,i,w in rrow[j]:
   for r,z in bb[a,b]:F3direct[r,h,i]+=-CI*v*w*z
 Y=defaultdict(lambda:0)
 for(b,j),v in N.items():
  for dd,i,w in rrow[j]:Y[b,dd,i]+=v*w
 Y=clean(Y)
 for(b,dd,i),v in Y.items():ny[b].append((dd,i,v))
 for h,A in enumerate(JB):
  for(a,b),v in A.items():
   for dd,i,w in ny[b]:
    for r,z in bb[a,dd]:F4[r,h,i]+=-CI*v*w*z
else:
 left={(r*45+h,c*45+a):v for(r,h,a,c),v in Z.items()};right={(a*45+c,i):v for(a,c,i),v in S.items()};F2={(rh//45,rh%45,i):v for(rh,i),v in mm(left,right).items()};W=[{}for r in range(45)]
 for(r,c,b),v in beta.items():W[r][b,c]=v
 leftM={};left4={};Y={}
 for dd,A in enumerate(R):
  for(b,i),v in mm(N,A).items():Y[b*45+dd,i]=v
 for r,WW in enumerate(W):
  for h,A in enumerate(JB):
   for(c,a),v in mm(A,WW).items():leftM[r*45+h,a*45+c]=-v
   for(b,dd),v in mm(transpose(A),transpose(WW)).items():left4[r*45+h,b*45+dd]=-CI*v
 F3mass={(rh//45,rh%45,i):v for(rh,i),v in mm(leftM,right).items()};F4={(rh//45,rh%45,i):v for(rh,i),v in mm(left4,Y).items()};weighted=defaultdict(lambda:0)
 for(r,a,b),v in beta.items():
  for(j,i),w in R[b].items():weighted[r,a,j,i]+=v*w
 by=defaultdict(list)
 for(r,a,j,i),v in clean(weighted).items():by[a,j].append((r,i,v))
 for(a,h,j),v in S.items():
  for r,i,w in by[a,j]:F3direct[r,h,i]+=-CI*v*w
F={2:clean(F2),3:plus((clean(F3mass),1),(clean(F3direct),1)),4:clean(F4)};pole=plus(*[(D,1)for D in F.values()]);basis={'chi4':pole,'log2':plus((F[3],-1),(F[4],1)),'log3':F[3],'log5':{},'fixed':{}}
for D in list(F.values())+list(basis.values()):assert all(0<=r<45 and 0<=h<45 and 0<=i<328 for r,h,i in D)
enc=lambda D:[[*k,str(v)]for k,v in sorted(D.items())];powers=sorted({key[:3]for D in F.values()for v in D.values()for key,q in v.terms});out={'schema':'UAK3_COMPLETE_UNPROBED_INTRINSIC_JLAMBDA_C_X_KERNEL','role':role,'F_m':{str(m):enc(D)for m,D in F.items()},'F3_groups':{'ghost_mass':enc(clean(F3mass)),'scalar_current':enc(clean(F3direct))},'relative_prime_basis':{name:enc(D)for name,D in basis.items()},'full_positions_per_tensor':664200,'parameter_monomial_powers':powers,'paired_q_average_reduced_by_qualified_Lambda_source_theorem':True,'fixed_Djet0_by_actual_support':True,'common_normalization':'hbar/(16pi^2); JL_r C_h x_i; no extra half','unknown_Ward_or_cutoff_not_operand':True,'full_quantum_QAP_E5_or_physical_promotion':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('color_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'F2_F3_F4_pole_nonzero':[len(F[m])for m in[2,3,4]]+[len(pole)],'F3_mass_direct_nonzero':[len(clean(F3mass)),len(clean(F3direct))],'parameter_monomial_powers':powers,'unbroken_aux_source_rows_nonzero':sum(r<12 for r,h,i in pole),'scalar_singlet_columns_nonzero':sum(i>=326 for r,h,i in pole),'full_QAP_E5_promoted':False},sort_keys=True),flush=True);timer.cancel()
