from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,gzip,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'universal_validation_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
a,b=[load(O/('universal_'+role+'_tables.json.gz'))for role in['primary','replay']];assert a['fixtures']==b['fixtures']and len(a['fixtures'])==12 and a['scalar_source_normalization_comparator']==b['scalar_source_normalization_comparator'];assert all(z['scalar_source_auxiliary_current_omission_sensitive']and z['auxiliary_source_auxiliary_current_and_GBB_width_insensitive']and not z['actual_model_or_Ward_remainder_operand']for z in[a,b])
for z in[a,b]:
 for c in z['controls']:
  if c['control']in['aux_current','width_change']:assert not c['changed_heat_coefficients']
  else:assert c['changed_heat_coefficients']
ip=read(O/'universal_validation_inputs.json');old=load(Path(ip['old_scalar_generic']));expected={str(m):s.Integer(0)for m in[1,2,3,4]}
for m,(re,im)in old['generic_heat_coefficients'].items():expected[m]=s.sympify(re)+s.I*s.sympify(im)
assert all(s.expand(s.sympify(v)-expected[m])==0 for m,v in a['scalar_source_normalization_comparator'].items());sup=[load(Path(ip[k]))for k in['support_primary','support_replay']];assert sup[0]['letters']==sup[1]['letters'];s0=next(q for q in sup[0]['results']if q['target']=='JL_Cx');s1=next(q for q in sup[1]['results']if q['target']=='JL_Cx');assert s0==s1 and len(s0['ordered_words'])==82 and not s0['abstract_superfamily_word_occurrences'];families=Counter();pins=0
for w in s0['ordered_words']:
 letters=[sup[0]['letters'][i]for i in w['letters']];grades=tuple(sorted(tuple(v['grade'])for v in letters));families[grades]+=1;assert len(letters)==len(w['Green_path'])-1
 for at,v in enumerate(letters):
  left,right=v['H_ports'];before=w['Green_path'][at];assert not(before=='B'and left=='B'),'unanticipated_GBB_link_requires_width_D_continuation'
  if(before=='B')!=(left=='B'):assert {before,left}=={'B','L'};pins+=1
  if(left=='B')!=(right=='B'):assert {left,right}in[{'B','a'},{'B','x'}]and sum(v['internal_jet_orders'])==1;pins+=1
  if v['grade'][1]and not v['grade'][3]:assert v['H_ports']in[['C','L'],['L','C']]
 assert not all(x=='B'for x in w['Green_path'])
allowed={tuple(sorted(v))for v in[[(0,1,0,1,0),(1,0,0,0,1)],[(0,1,0,0,0),(0,0,0,1,0),(1,0,0,0,1)],[(0,1,0,0,0),(1,0,0,1,0),(0,0,0,0,1)],[(0,1,0,0,0),(0,0,0,1,0),(1,0,0,0,0),(0,0,0,0,1)]]};assert set(families)==allowed
d=load(Path(ip['classical']));N=d['endings']['N0'];assert all(i>=45 for i,j,v in N['entries']);G={(i,j):s.sympify(v)for i,j,v in d['endings']['G0']['entries']};assert all(not v for(i,j),v in G.items()if i>=45 and j>=45);assert all(0<=r<45 and 0<=c<45 and 0<=L<45 for r,c,L,v in d['maps']['beta_C_L'])
for role in['primary','replay']:
 r=read(O/('universal_'+role+'_result.json'));p=O/('universal_'+role+'_tables.json.gz');assert H(p)==r['packed_sha256']and sha256(gzip.decompress(p.read_bytes())).hexdigest()==r['raw_sha256']
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'all12_paired_Gaussian_and_Schur_fixtures_agree':True,'old_scalar_source_normalization_comparator_agrees':True,'all82_actual_profiles_covered_by_four_Schur_grade_families':True,'actual_longitudinal_pin_occurrences':pins,'source_Lambda_support_no_GBB_or_aux_current_in_this_kernel':True,'fixed_D_jet_zero_structural_not_interpolated':True,'source_location_insensitive_and_sensitive_controls_distinguished':True,'actual_model_kernel_measured':False,'full_QAP_E5_or_physical_promotion':False},sort_keys=True),flush=True);timer.cancel()
