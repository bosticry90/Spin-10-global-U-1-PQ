# UAK5: actual cotangent source operation and late partial comparison

Prospective after UAK4. Reconstruct the projected rho-source flow on JL
from actual G BEFORE reading any old pending operation coefficient or
partial H. In the established Euclidean convention Sigma_rho=rho*G_E,
G_E=-G_M with individual Wick/source phases. For G_E=JL_r A_rj Lambda_j,
the literal odd-source derivative gives q_rho Lambda=-rho A Lambda,
while the even Lambda Euler derivative gives q_rho JL_j=rho JL_r A_rj.
This is the actual cotangent relation,not elementary qJ=0. Check the signs
with a literal Grassmann/source-order fixture. Inspect that G has no
source conjugate to C/x in the retained domain,so their rho flows cannot
add a term to this particular kernel's image.

The measured source functional is JL_j C_h x_i F_jhi. Its projected image
is sum_j A_rj F_jhi. Derive A by Wick/field Euler versus the negative
field-tangent transpose relation. Contract measured primary/replay kernel
bases using direct indices versus sparse matrix unfolding. The source/
kernel conventions are fixed by UAK1-4;no sign may be chosen from closure.

Only after calculating A and its quantum image compare A^T with the old
ICR7 C_JL_x operation matrix (output-source index first). Then add the
measured image exactly once to the RFF knownpartialH+cutoff table. Retain
all coefficients and zeros. No unknown aCx coefficient is assigned the
negative residual. A discrepancy in old operation orientation or schema
must be preserved and investigated,not repaired by flipping a sign to
obtain agreement. Neither zero nor nonzero partial sum proves a full Ward
identity,anomaly,QAP or physical viability. The aCx native kernel remains.

180s afterimports,8GiB sampled,350MiB launch floor,32MiB packet unchanged.
Freeze all actual inputs/receipts/sources/copies before computation.
