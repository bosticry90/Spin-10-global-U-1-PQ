# The unprobed intrinsic auxiliary-source kernel is measured

PROGRESS. The complete intrinsic JL Cx ordinary kernel is calculated in
the declared local relative construction. Its ultraviolet pole cancels,
but it has a nonzero finite log2 coefficient. The action-derived source
operation transports that measured coefficient into the partial relation.
One ordinary kernel,the intrinsic aCx class,remains unmeasured there.

Goal ACTIVE/INCOMPLETE. State113,authority34/39,E5/A5 OPEN unchanged;
custodyexit2/seven NOTPASS. No new physical benchmark,scheme,normalization,
foundation or protected promotion. project_state remains sole authority.

## Complete heat-resolved result

Every group is compared at45 auxiliary sources x45 ghosts x328 real
scalars=664200 positions,including implicit zeros.

| Heat edges | Nonzero positions | Role |
| --- | ---: | --- |
| 2 | 9632 | Direct source/ghost-mass contraction |
| 3 | 0 | Both constituent contractions independently zero |
| 4 | 9632 | Mixed intrinsic/scalar bosonic contraction |
| Sum,ultraviolet pole | 0 | F2+F4=0 coefficientwise |

The relative coefficient is therefore

    Gamma1[JL Cx] = hbar/(16pi^2) * F4 log2,

within the declared symbol,with no extra half and no chosen chi4.
At(13,13,207),

    F2=+11 i sqrt15 g10^4 xi/200,
    F4=-11 i sqrt15 g10^4 xi/200.

The old witness(13,0,137) is zero in this kernel. It could not have
established the full zero or finite coefficient. The two nonzero groups
have654568 implicit zeros apiece. All coefficients are proportional to
g10^4 xi;no eta_H or reference G_BB width dependence survives. Every heat
group has zero rows for the12 unbroken auxiliary sources and zero scalar
singlet columns. These are actual complete coefficient checks,not absent
table entries or claims about a changed spectrum.

## Why the calculation is complete within scope

The existing82-profile catalogue divides into four Schur families. The
source vertex W is supported in Lambda. Eliminating bosons and expanding
the ghost determinant gives

 F2=Tr(Z S),
 F3=Tr(S M0 G W)+Tr(Mn G X G W),
 F4=-Tr(M0 G N G X G W+M0 G X G N G W).

See PROOF.md for definitions,coordinate sums and the source signs. A
complete profile check finds252 longitudinal-pin occurrences,no G_BB link
and no closed unpinned vector spectator. GW is in B_long,so NGW=0 and
the second F4 ordering is zero by actual port support. Dimensional jet0
follows structurally;D3/4/5 tests are corroboration,not its proof.

Both paired-mode Gaussian and Schur determinant calculations agree in12
noncommuting two-color fixtures. They fix the sign and single-mode
half-STrlog/paired-mode quarter-STrlog normalization before any Spin(10)
coefficient or partial Ward remainder is read. The independently calculated
scalar-source comparator56+21i matches the old qualified USR2 normalization.
The source-location distinction is tested:auxiliary-current and width
omissions are insensitive for W_Lambda,but auxiliary-current omission is
sensitive for W_x. The earlier scalar-source result cannot be simplified
by importing this auxiliary-source reduction.

The model primary directly contracts indices. Replay uses sparse matrix
unfolding,different scalar/color association and source-weighted scalar
generators. All heat groups,the pole,finite-prime bases and implicit zeros
agree. The two F3 components are independently zero before their sum.
Actual aligned R and source/ghost/classical data are reused qualified
inputs;they are not freshly reconstructed representation data here.

Selected literal508-coordinate logarithms check the three triples
(13,0,137),(13,13,207),(44,44,262),both q orientations,all heat groups
and both F3 grade families. Omitting direct JC source changes F2;omitting
intrinsic N changes F4 at the nonzero triples. Auxiliary-current,width and
Mn omissions remain insensitive in these model projections,as recorded.
The generic Mn test is sensitive;its model contraction vanishes instead.
No insensitive test is credited as error detection.

## Action-derived source transport

The primitive contains G_E=JL_r A_rj Lambda_j. With the established
Sigma_rho=rho G_E convention,literal derivatives give

    q_rho Lambda=-rho A Lambda,
    q_rho JL_j=rho JL_r A_rj.

The opposite signs follow from the odd source and even field derivatives.
The actual source inventory has no conjugate C/x source in the retained
domain,so those rho variations add no term to this kernel's image.
A is derived before the old operation matrix is read,and its transpose
agrees with the earlier C_JL_x matrix at every45x45 position.

Probe0 has12 diagonal eta_H/2 entries;probe1 has33 diagonal xi/2 entries.
Direct contraction versus matrix unfolding gives

    image[r,h,i] = sum_j A[r,j] F[j,h,i].

Probe0 image is zero. Probe1 adds9632 log2 coefficients and no chi4,
log3,log5 or fixed contribution. For example,the image at(13,13,207)
is-11 i sqrt15 g10^4 xi^2/400 times log2 in the common normalization.
No source operation was inferred from a desired cancellation.

Only after deriving this image was the RFF knownpartialH+cutoff table
read. Its log2 coefficients change;the number of nonzero positions remains
10784. The current partial counts are chi4=10488,log2=10784,log3=10632,
log5=0 for probe1,and zero throughout probe0. Equal counts before/after
the new image do not mean equal polynomials. The full updated coefficients
are retained in integration_tables_v2.json.gz.

The intrinsic aCx kernel is still unmeasured. Its negative required
remainder is not supplied as a coefficient or a fitted counterterm.
Neither this partial sum nor the zero pole of JL Cx is a complete source
Ward restoration,anomaly test,renormalized product or QAP theorem.

## Failure,verification and capability limits

All universal/model natives and their independent qualifications passed.
Original UAK5 integration exited1 before forming A:an undefined f in the
source-inventory comprehension should have been sources[n]. Its original
source,copy,preparation,complete capture and controller failure remain.
No original integration receipt/output exists. V2 corrects only that
lookup,retains every mathematical condition and input,and passes the source
operation and partial comparison without a sign adjustment.

Initial read-only inspection requested an optional absent derivation path
and printed an oversized catalogue with member-reference arrays;the tool
display was truncated. The immutable complete catalogue remained intact,
was then inspected compactly and was consumed in full by the frozen82-profile
review. Those diagnostic limitations are recorded externally and are not
qualification evidence or a substitute for complete native captures.

Primary/replay universal1.3531/.7074s afterimports,universal review.7273s;
model3.6330/3.2792s,model review6.2200s,integration V2 4.3669s. Largest
sampled private allocation320512000B before final review;not continuous
peak measurement. Bounds300s native/180s review,8GiB sampled private,
350MiB available-pagefile launch floor,32MiB retained unchanged. Packet
about1MB before report/final review. Source copies,hashes,resources and
full captures are retained. Exclusive output creation protects the run.

This demonstrates using source support to reduce an entire loop family,
fixing determinant normalization independently and separating model-specific
zeros from generic sensitive controls. It also exposes another avoidable
implementation error. Methods still share the action,charts,classical
inputs,R derivation,exact ring,parts of the frontend,Python/SymPy and AI
authorship. Agreement is internal mathematical corroboration,not independent
physical validation or experimental confirmation. No proof assistant used.

## Next actual quantum input

Calculate the intrinsic aCx kernel from the actual GF and kinetic Hessian.
Its466 raw profiles(4/174/288 two/three/four-edge) are a finite support
inventory,not466 independent required integrals. First derive the actual
constant-external-antighost quantum vertices and an ordered determinant/
Schur expression. Some derivative terms may cancel at zero external jets,
but nonminimal aC transformations and quartic ghosts must be retained.
Do not assume ordinary Faddeev–Popov integration-by-parts simplifications
remove the complete current in this nonlinear construction. Prove any
collective reduction with the actual action before omitting a family.

Then independently measure/replay the full tensor,derive its rhoJL source
image from actual source-quadratic G,and integrate exactly once. Compare
with the retained partial relation only afterward. A failure or residual
must be classified as missing input,prescription/domain gap or a properly
scoped obstruction;do not fit chi4. Other ucontacts,T/F,generalBBx,full
nonlinear/intrinsic augmented-source master applicability,continuum trace/
products,chiral QAP/measure/global phase,source reality,massive/causal limits
and physical viability remain open. No flavor/HB1/C5 activation.

All results retain original unshifted SMA/CSW/EDS,A0,intrinsicdegree1,
zero external jets and symbolic parameters in the Euclidean nonexceptional
LOCAL RELATIVE symbol. They are not physical scalelessp0,massive-vacuum
amplitudes,absolute products or a new scheme. chi4,b0,kappa and IR freedom
remain distinct and unfixed. No publication,remote push or protected
scientific promotion is authorized by this bounded result.
