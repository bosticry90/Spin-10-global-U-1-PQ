# UAK1: literal Gaussian before model contraction

Prospective. Two vector colors,two auxiliary fields,two scalars,two ghost
pairs per q mode. Use noncommuting complex/rational currents,source W at
Lambda,arbitrary independent scalar ghost mass and scalar-current endpoint,
intrinsic mixed N and physical derivative X. These are finite algebra
fixtures,not new physical parameter points. Retain both q modes and
literal ordered odd sources/ghosts before differentiating the Hessian.

Compare full onequarter-STrlog with Schur traces at every heat2/3/4
coefficient. Check D3/4/5 and first/last momentum axis. Verify the full
auxiliary-current and G_BB-width omission invariances,provided W truly
has only Lambda support. Test source Z,mass S,source W,N,Mn,vector current,
one HX endpoint and noncommuting order where sensitive;report zeros too.
No old unknown kernel or partial-H value is read. Both derivations share
fixture data and exact ring;do not call them independent physical evidence.
300s native/180s review,8GiB sampled,350MiB floor,32MiB packet unchanged.
