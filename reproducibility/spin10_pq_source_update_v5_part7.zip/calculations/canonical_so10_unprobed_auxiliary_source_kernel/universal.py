from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());role=sys.argv[1];assert role in['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'universal_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
cp=Path(read(O/'ring_inputs.json')['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient,constant,expression,verify_basis_products
assert verify_basis_products()==1024
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z)))
def tidy(D):return {k:v for k,v in D.items()if v}
def plus(A,B):
 out=dict(A)
 for k,v in B.items():out[k]=out.get(k,0)+v
 return tidy(out)
def mul(A,B):
 out=defaultdict(lambda:0)
 for a,v in A.items():
  for b,w in B.items():
   if not a&b:out[a|b]+=(-1)**sum(i>j for i in[2,3]for j in[2,3]if a&(1<<i)and b&(1<<j))*v*w
 return tidy(out)
def mm(A,B):
 by=defaultdict(list);out={}
 for(i,j),v in B.items():by[i].append((j,v))
 for(i,k),v in A.items():
  for j,w in by[k]:
   z=mul(v,w)
   if z:out[i,j]=plus(out.get((i,j),{}),z)
 return {ij:v for ij,v in out.items()if v}
def tensors(D,axis,q,seed=0,omit=None,source='Lambda'):
 nb=2*D+4;K=s.zeros(nb);N=s.zeros(nb);X=s.zeros(nb);M=s.zeros(2,nb);Mn=s.zeros(2,nb);W=s.zeros(nb,2)
 JB=s.I*s.Matrix([[1+seed,2-seed],[-1+2*seed,3+seed]]);JL=s.Matrix([[2,1],[4,-1]]);NP=s.I*s.Matrix([[1,3],[2,-2-seed]]);XP=s.Matrix([[1,-2],[3+seed,1]]);WW=s.Matrix([[2,-1],[1,3+seed]]);SS=s.Matrix([[1,-3+seed],[2,4]]);SN=s.Matrix([[-1,2],[3,1+seed]]);ZZ=s.Matrix([[3,2],[-2,1+seed]])
 widths=[5,7]if omit=='width_change'else[2,3]
 for a,w in enumerate(widths):
  for mu in range(D):K[a*D+mu,a*D+mu]=0 if mu==axis else 1
  L=2*D+a;B=a*D+axis;K[B,L]=q;K[L,B]=-q;K[L,L]=w
  for c in range(2):M[c,B]=0 if omit=='vector_current'else q*JB[c,a];M[c,L]=0 if omit=='aux_current'else JL[c,a]
  for j in range(2):
   xx=2*D+2+j;N[L,xx]=N[xx,L]=0 if omit=='N'else NP[a,j];X[B,xx]=-s.I*q*XP[a,j];X[xx,B]=s.I*q*XP[a,j]
 for j in range(2):
  xx=2*D+2+j;K[xx,xx]=1
  for c in range(2):Mn[c,xx]=0 if omit=='Mn'else SN[c,j]
 for b in range(2):
  row=2*D+b if source=='Lambda'else 2*D+2+b
  for c in range(2):W[row,c]=0 if omit=='W'else WW[b,c]
 if omit=='S':SS=s.zeros(2)
 if omit=='Z':ZZ=s.zeros(2)
 return K,N,X,M,Mn,W,SS,ZZ,JB,NP,XP,WW,SN
def born(D,axis,seed=0,omit=None,source='Lambda',target=60):
 nb=2*D+4;per=nb+4;dim=2*per;par=([0]*nb+[1]*4)*2;extJ=dim;extC=dim+1;ef=lambda mode,i:mode*per+i;terms0=[];terms=[]
 K,*_=tensors(D,axis,1,seed,omit,source)
 for(i,j),v in s.SparseMatrix(K).todok().items():terms0.append((0,co(str(v)),(ef(1,i),ef(0,j))))
 for mode in[0,1]:
  other=1-mode;q=1 if mode==0 else-1;K,N,X,M,Mn,W,S,Z,*_=tensors(D,axis,q,seed,omit,source)
  for c in range(2):terms0.append((0,constant(1),(ef(other,nb+2+c),ef(mode,nb+c))))
  if mode==0:
   for mask,A in[(16,N),(32,X)]:
    for(i,j),v in s.SparseMatrix(A).todok().items():
     if omit=='X_reverse_density'and mask==32 and i>=2*D+2:continue
     terms.append((mask,co(str(v)),(ef(1,i),ef(0,j))))
  for mask,A in[(0,M),(16,Mn)]:
   for(a,j),v in s.SparseMatrix(A).todok().items():terms.append((mask,co(str(v)),(ef(other,nb+2+a),extC,ef(mode,j))))
  for(i,c),v in s.SparseMatrix(W).todok().items():terms.append((0,co(str(v)),(extJ,ef(mode,nb+c),ef(other,i))))
  for(a,c),v in s.SparseMatrix(S).todok().items():terms.append((48,co(str(v)),(ef(other,nb+2+a),ef(mode,nb+c))))
  for(a,c),v in s.SparseMatrix(Z).todok().items():terms.append((0,co(str(v)),(extJ,extC,ef(other,nb+2+a),ef(mode,nb+c))))
 def hessian(tt):
  out={}
  def pp(i):return par[i]if i<dim else 1
  def deriv(w,i):
   for at,n in enumerate(w):
    if n==i:yield w[:at]+w[at+1:],(-1)**(pp(i)*sum(pp(k)for k in w[:at]))
  for mask,v,w in tt:
   for i in set(n for n in w if n<dim):
    for ww,sg in deriv(w,i):
     for j in set(n for n in ww if n<dim):
      for zz,tg in deriv(ww,j):
       assert all(n>=dim for n in zz);bits=[4 if n==extJ else 8 for n in zz]
       if len(set(bits))!=len(bits):continue
       mmask=mask|sum(bits);sign=sg*tg*(-1)**(par[j]*(par[i]+1)+sum(a>b for at,a in enumerate(bits)for b in bits[at+1:]));out[i,j]=plus(out.get((i,j),{}),{mmask:sign*v})
  return out
 H0=hessian(terms0);V=hessian(terms);K=s.SparseMatrix(dim,dim,{ij:expression(D[0].terms)for ij,D in H0.items()});assert all(set(D)=={0}for D in H0.values());G={(i,j):{0:co(str(v))}for(i,j),v in s.SparseMatrix(K.inv()).todok().items()};A=mm(G,V);power={(i,i):{0:constant(1)}for i in range(dim)};out={}
 for m in range(1,5):
  power=mm(power,A);tr=sum(((-1)**par[i]*D.get(target,0)for(i,j),D in power.items()if i==j),0);out[m]=co(str(s.Rational((-1)**(m+1),4*m)))*tr
 return out
def schur(D,axis,seed=0,omit=None,closed=False):
 out={m:s.Integer(0)for m in[1,2,3,4]};reverse=[]
 for q in[1,-1]:
  K,N,X,M,Mn,W,S,Z,JB,NP,XP,WW,SN=tensors(D,axis,q,seed,omit)
  if closed:
   if omit=='vector_current':JB=s.zeros(2)
   if omit=='N':NP=s.zeros(2)
   if omit=='W':WW=s.zeros(2)
   if omit=='Mn':SN=s.zeros(2)
   vals={1:0,2:s.trace(Z*S),3:-s.trace(S*JB*WW)-s.I*s.trace(SN*XP.T*WW),4:-s.I*s.trace(JB*NP*XP.T*WW)};rev=0
  else:
   G=K.inv();rev=s.trace(M*G*X*G*N*G*W);vals={1:0,2:s.trace(Z*S),3:s.trace(S*M*G*W)+s.trace(Mn*G*X*G*W),4:-s.trace(M*G*N*G*X*G*W)-rev}
  for m,v in vals.items():out[m]+=s.expand(v)/2
  reverse.append(str(s.expand(rev)))
 assert reverse==['0','0'];return {m:co(str(s.expand(v)))for m,v in out.items()}
def enc(D):return {str(k):str(v)for k,v in D.items()}
fixtures=[]
for seed in[0,1]:
 for D in[3,4,5]:
  for axis in[0,D-1]:
   v=born(D,axis,seed)if role=='primary'else schur(D,axis,seed);assert not v[1]and all(v[m]for m in[2,3,4]);fixtures.append({'seed':seed,'D':D,'axis':axis,'heat_coefficients':enc(v)})
 for q in fixtures[-6:]:assert q['heat_coefficients']==fixtures[-1]['heat_coefficients']
 print('STAGE UAK1',role,seed,fixtures[-1]['heat_coefficients'],flush=True)
controls=[]
for seed in[0,1]:
 base=born(3,0,seed)if role=='primary'else schur(3,0,seed)
 for omit in['Z','S','Mn','N','W','vector_current','aux_current','width_change']:
  bad=born(3,0,seed,omit=omit)if role=='primary'else schur(3,0,seed,omit=omit);changed=[m for m in[1,2,3,4]if base[m]!=bad[m]]
  if omit in['aux_current','width_change']:assert not changed
  else:assert changed
  controls.append({'seed':seed,'control':omit,'changed_heat_coefficients':changed})
 if role=='primary':bad=born(3,0,seed,omit='X_reverse_density');assert bad!=base;controls.append({'seed':seed,'control':'omit_literal_reverse_X_density_endpoint','changed_heat_coefficients':[m for m in base if base[m]!=bad[m]]})
 else:
  assert schur(3,0,seed)==schur(3,0,seed,closed=True)
  K,N,X,M,Mn,W,S,Z,JB,NP,XP,WW,SN=tensors(3,0,1,seed);wrong=-s.I*s.trace(JB*XP.T*NP*WW);assert co(str(s.expand(wrong)))!=base[4];controls.append({'seed':seed,'control':'wrong_noncommuting_N_X_order','changed_heat_coefficients':[4]})
# Normalization comparator for the previously qualified scalar-source class.
# It is calculated here first;old reference values are read only by review.
if role=='primary':scalar=born(3,0,0,source='scalar',target=44);scalar_bad=born(3,0,0,omit='aux_current',source='scalar',target=44)
else:
 scalar={m:constant(0)for m in[1,2,3,4]};scalar_bad=dict(scalar)
 for omit,target0 in[(None,scalar),('aux_current',scalar_bad)]:
  z=0
  for q in[1,-1]:
   K,N,X,M,Mn,W,*_=tensors(3,0,q,0,omit,source='scalar');G=K.inv();z+=s.trace(M*G*X*G*W)/2
  target0[3]=co(str(s.expand(z)))
assert scalar!=scalar_bad and scalar[1]==scalar[2]==scalar[4]==0
out={'schema':'UAK1_PAIRED_GAUSSIAN_VS_ORDERED_SCHUR_AUXILIARY_SOURCE','role':role,'fixtures':fixtures,'controls':controls,'scalar_source_normalization_comparator':enc(scalar),'scalar_source_auxiliary_current_omission_sensitive':scalar!=scalar_bad,'auxiliary_source_auxiliary_current_and_GBB_width_insensitive':True,'actual_model_or_Ward_remainder_operand':False};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
with(O/('universal_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),'fixtures':len(fixtures),'heat_coefficients_by_seed':[fixtures[j]['heat_coefficients']for j in[0,6]],'scalar_source_comparator':enc(scalar),'universal_kernel_not_model_quantum_coefficient':True},sort_keys=True),flush=True);timer.cancel()
