# UAK3: model coefficients after universal/support qualification

Prospective after UAK2 receipt. Use actual qualified N0,J0,S0,Z0,beta and
aligned scalar R from RSH primary/replay classical containers. Authenticate
free G_BL=-identity,G_LB=identity,G_LL=0 and scalar antisymmetry/shape;
do not silently select a new reference. W has Lambda support only.

Measure F2,F3,F4 in PROOF.md at all45x45x328 positions. Primary direct
index contractions versus replay sparse matrix unfoldings and different
scalar/color association. Retain F3 mass and scalar-current pieces
separately,and all m-edge groups. No old partial-H/cutoff/desired source
relation is a native operand. Fixed dimensional jet0 and paired-q average
are analytically reduced only under UAK2's qualified source/pin premises.

Full relative basis is chi4*(F2+F3+F4)+log2*(-F3+F4)+log3*F3.
This is not a choice of chi4 or absolute finite normalization. Check
independent model coefficients and implicit zeros,literal selected508
graded log traces and reference/source/order controls before integrating
with any source operation. Model-specific zeros do not replace the generic
negative controls. Shared action,charts,R/classical-input derivations,
frontend software,exact ring and AI authorship remain limits.

300s/native,180s/review,8GiB sampled private,350MiB launch floor,32MiB
packet unchanged. No source/Ward/QAP/E5 or physical promotion. Preserve
failed and unfinished runs without relabeling,overwriting or fitting.
