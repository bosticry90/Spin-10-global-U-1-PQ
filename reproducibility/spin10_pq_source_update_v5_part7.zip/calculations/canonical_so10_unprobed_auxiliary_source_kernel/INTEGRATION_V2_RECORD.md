# UAK5 V2: source-name comprehension repair

Original integration native exited1 at an undefined variable f in the
source-inventory set comprehension,before deriving A or reading the old
operation coefficients. The intended set is sources[n] for each retained
source n. Preserve original source/copy/preparation,capture/controller;
no original integration receipt or output exists.

V2 changes that comprehension to its declared actual-source-name lookup,
uses separate output/preparation/receipt names,and reuses the immutable
prepared inputs. No sign,normalization,source convention,physics premise
or acceptance condition is changed. Any subsequent mathematical mismatch
still fails rather than being adjusted to a desired cancellation.
180s/8GiB sampled/350MiB floor/32MiB unchanged. No QAP/E5 promotion.
