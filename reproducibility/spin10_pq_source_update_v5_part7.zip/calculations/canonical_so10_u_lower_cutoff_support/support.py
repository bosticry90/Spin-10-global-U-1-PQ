from collections import defaultdict,Counter
from domain import OP,ext_pattern
EPS=1;UU=2;JJ=4;C1=8;C2=16;NN=32;XX=64
FOLD={'B':['B','L'],'L':['B'],'s':['s'],'C':['a'],'a':['C'],'f':['f']}

def source(i):return ('JL',i-1151) if 1151<=i<1196 else ('Ja',i-1241) if 1241<=i<1286 else None
def fine(i):
    sec=OP.sector(i)
    if sec=='s':return sec
    color=i//4 if sec=='B' else i-508 if sec=='L' else i-553 if sec=='C' else i-598
    return sec+('H' if color<12 else 'b')
def folded(sec):return [a+sec[1:] for a in FOLD[sec[0]]] if sec not in ['s','f'] else [sec]

def classes(tables,case,probe,source_type=None,ghost_types=None):
    V={};M={};expected_source='Ja' if case=='T' else 'JL';refined=source_type is not None
    for name,rows in tables.items():
        if name.startswith(('HU','MU')) and int(name[2])!=probe:continue
        root=name.startswith('M');u=name.startswith(('HU','MU'));origin=int(name[-1]) if u else None
        for i,j,w,nd,power,terms in rows:
            src=[source(z) for z in w if source(z)];gh=[z-553 for z in w if 553<=z<598]
            if src and src[0][0]!=expected_source:continue
            if case=='T' and len(gh)>1:continue
            if refined and src and ('H' if src[0][1]<12 else 'b')!=source_type:continue
            if len(gh)==2:
                if refined and tuple('H' if h<12 else 'b' for h in gh)!=ghost_types:continue
                slots=[12]
            elif len(gh)==1:slots=[slot+1 for slot,t in enumerate(ghost_types) if t==('H' if gh[0]<12 else 'b')] if refined else ([1] if case=='T' else [1,2])
            else:slots=[0]
            pat=ext_pattern(w,nd)
            for slot in slots:
                mask=(EPS if root else 0)|(UU if u else 0)|(NN if nd else 0)|(XX if any(180<=z<508 for z in w) else 0)|(JJ if src else 0)|(C1|C2 if slot==12 else C1 if slot==1 else C2 if slot==2 else 0)
                label=name+'|'+pat+('@'+str(slot) if slot else '')
                row,col=(fine(i),fine(j)) if refined else (OP.sector(i),OP.sector(j))
                edges={(row,col)} if root else {(a,col) for a in (folded(row) if refined else FOLD[row])}
                grade=nd+len(w)+int(u)
                flag=(4 if name.startswith('MU') and origin==2 else 0)|(8 if nd+len(w)>(1 if u else 2) else 0)
                table=M if root else V
                item=table.setdefault(label,{'name':name,'pattern':pat,'slot':slot,'mask':mask,'grade':grade,'source_origin':origin,'flag':flag,'edges':set()})
                assert item['mask']==mask and item['grade']==grade
                item['edges'].update(edges)
    for label,mask,edges,flag in [('VPOT|nx',NN|XX,{('s','s')},1),('VFERMION|x',XX,{('f','f')},2)]:
        V[label]={'name':label.split('|')[0],'pattern':label.split('|')[1],'slot':0,'mask':mask,'grade':mask.bit_count(),'source_origin':None,'flag':flag,'edges':edges}
    for table in [V,M]:
        for item in table.values():item['edges']=[list(p) for p in sorted(item['edges'])]
    return V,M

def paths(labels,V,M):
    ops=[V[k] for k in labels[:-1]]+[M[labels[-1]]];out=[]
    sectors=sorted({s for it in ops for pair in it['edges'] for s in pair})
    def walk(at,current,path,start):
        if at==len(ops):
            if current==start:out.append(path)
            return
        for row,col in ops[at]['edges']:
            if row==current:walk(at+1,col,path+[col],start)
    for start in sectors:walk(0,start,[start],start)
    return out

def enumerate_order(V,M,case,n):
    target=EPS|UU|JJ|C1|NN|XX|(C2 if case=='F' else 0);words=[];grade_words=0;maxg=max(it['grade'] for it in V.values())
    for root,r in M.items():
        def grow(word,mask,flag):
            nonlocal grade_words
            if len(word)==n:
                if mask!=target:return
                grade_words+=1;routes=paths(word+[root],V,M)
                if routes:words.append({'root':root,'word':word,'paths':routes,'flag':flag})
                return
            needed=(target^mask).bit_count();left=n-len(word)
            if needed<left or needed>maxg*left:return
            for label,it in V.items():
                if not(mask&it['mask']) and not(it['mask']&~target):grow(word+[label],mask|it['mask'],flag|it['flag'])
        if not r['mask']&~target:grow([],r['mask'],r['flag'])
    flags=Counter(z['flag'] for z in words)
    return {'order':n,'all_grade_words':grade_words,'supported_words':len(words),'closed_paths':sum(len(z['paths']) for z in words),'word_flag_counts':{str(k):v for k,v in sorted(flags.items())},'words':words}

def boolean_orders(V,M,case,maxn):
    target=EPS|UU|JJ|C1|NN|XX|(C2 if case=='F' else 0)
    def assemble(table):
        z=defaultdict(set)
        for it in table.values():
            if it['mask']&~target:continue
            for edge in it['edges']:z[tuple(edge)].add((it['mask'],it['flag']))
        return dict(z)
    def mul(A,B):
        rows=defaultdict(list);out=defaultdict(set)
        for (i,j),p in B.items():rows[i].append((j,p))
        for (i,k),p in A.items():
            for j,q in rows.get(k,[]):
                for a,fa in p:
                    for b,fb in q:
                        if not a&b:out[i,j].add((a|b,fa|fb))
        return dict(out)
    X=assemble(V);Y=assemble(M);sectors={s for i,j in list(X)+list(Y) for s in [i,j]}
    P={(s,s):{(0,0)} for s in sectors};out=[]
    for n in range(maxn+1):
        Z=mul(P,Y);flags=sorted({f for (i,j),p in Z.items() if i==j for mask,f in p if mask==target})
        out.append({'order':n,'target_flags':flags,'possible_target':bool(flags)})
        P=mul(P,X)
    return out
