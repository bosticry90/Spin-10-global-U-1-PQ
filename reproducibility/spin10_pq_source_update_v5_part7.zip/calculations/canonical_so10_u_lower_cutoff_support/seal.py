from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-lower-cutoff-support-v1-2026-10-26')
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
base=read(O/'inputs.json')['base_HEAD']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==base
assert subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()=='main'
subprocess.run(['git','diff','--quiet','HEAD'],cwd=R,check=True)
tree=subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);assert tree==(C/'old_git_tree.txt').read_bytes()
assert H(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
bindings={}
for file in sorted(O.glob('*preparation*.json')):
    for pp,h in read(file)['input_sha256'].items():
        assert H(Path(pp))==h,(file.name,pp)
        if pp in bindings:assert bindings[pp]==h
        bindings[pp]=h
for file in O.glob('*.source.txt'):assert (O/file.name.removesuffix('.source.txt')).read_bytes()==file.read_bytes(),file
for file in O.glob('*.py'):ast.parse(file.read_bytes())
failnames={'inventory_controller_failure.json','review_controller_failure.json','review_controller_failure_v2.json'}
assert {p.name for p in O.glob('*controller_failure*.json')}==failnames
assert 'FileExistsError' in read(O/'inventory_controller_failure.json')['traceback']
assert not (O/'inventory_capture.json').exists()
for name,marker in [('review_capture.json','ImportError'),('review_capture_v2.json','AssertionError')]:
    z=read(O/name);assert z['exit_code']==1 and not z['calculation_completed'] and marker in z['stdout_and_stderr']
assert not (O/'review_result.json').exists() and not (O/'review_result_v2.json').exists()
completed=['primary_capture.json','replay_capture.json','inventory_capture_v2.json','review_capture_v3.json'];maximum=0;reports={}
for name in completed:
    z=read(O/name);assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified']
    assert z['launch']['creation_after_observation'] and z['launch']['memory']['available_pagefile']>=350*1024**2
    for sample in z['all_resource_samples']:
        assert sample['private_bytes']<8*1024**3;maximum=max(maximum,sample['private_bytes'])
    rows=[json.loads(line[7:]) for line in z['stdout_and_stderr'].splitlines() if line.startswith('RESULT ')]
    assert len(rows)==1;reports[name]=rows[0]
    assert rows[0]['elapsed_after_imports']<(300 if name.startswith(('primary','replay')) else 180)
v=read(O/'review_result_v3.json')
assert v['new_all_label_entries']==286804 and v['native_arrays_and_zero_complements_equal'] and v['C0_C1_support_zero']
assert v['physical_potential_and_isolated_fermion_envelopes_excluded_all_orders'] and v['probe0_support_zero_through_fourth_order'] and v['unbroken_source_support_zero_all_orders']
assert v['probe0_F5_candidate_words_not_support_zero']==6 and not v['lower_coefficient_tensors_measured'] and not v['full_finite_restoration_continuum_or_QAP_claim']
assert v['source2_independent_direct_checks'][1]['Mu_entries']==6688 and sum(z['entries'] for z in v['old_restricted_projection'])==207440
assert len(v['fixtures'])==32 and all(v['fixture_sensitive_context_counts'].values())
e=read(O/'e4_capture.json');events=[json.loads(line) for line in e['stdout'].splitlines() if line.startswith('{')]
exits=[z['exit_code'] for z in events if z.get('event')=='step_finished']
assert e['exit_code']==0 and exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED'
size=sum(p.stat().st_size for p in O.iterdir() if p.is_file());assert size<32*1024**2
files={str(p.relative_to(R)).replace('\\','/'):H(p) for p in O.iterdir() if p.is_file()}
handoff=R/'docs/RESEARCH_EXECUTION_HANDOFF_V652.md';files[str(handoff.relative_to(R)).replace('\\','/')]=H(handoff)
out={'schema':'ULC_FINAL_REVIEW_VALIDATION_V1','base_HEAD':base,'evidence_validation':'PASS_COMPLETE_RETAINED_LOWER_OPERATOR_SUPPORT_AND_FINITE_BASIS_MAP','scientific_acceptance':'NOT_PERFORMED',
     'authority':'34/39; E5/A5 OPEN','custody':'EXIT_2_SEVEN_UNRESOLVED','state_unchanged':True,'full_investigation_complete':False,'lower_coefficient_tensors_measured':False,
     'scope':'Original formal Euclidean local relative positive-heat UV symbol; full target-compatible operator/sector domain, source2 tangent and prime-log map, not loop tensors.',
     'new_all_label_operator_entries':286804,'old_projection_entries':207440,'source2_Mu_nonzeros':[0,6688],'lower_candidate_unions':v['lower_candidate_unions'],
     'authenticated_input_source_bindings':len(bindings),'preserved_old_mode_blob_entries':len(tree.splitlines()),'successful_captures':completed,
     'failed_runs_preserved':[{'controller':'inventory_controller_failure.json','classification':'FAILED_PRELAUNCH_EXISTING_IDENTICAL_SOURCE_COPY'},{'capture':'review_capture.json','classification':'FAILED_IMPORT_HISTORICAL_MODULE_SHADOWING'},{'capture':'review_capture_v2.json','classification':'FAILED_OVERBROAD_PROBE0_F5_SUPPORT_CLAIM_REJECTED'}],
     'maximum_successful_private_sample_bytes':maximum,'sample_is_continuous_peak':False,'packet_bytes_before_seal':size,'e4_step_exits':exits,
     'limitations':['shared action/reference/charts/curated data/ring/helpers/software/formula/AI author','support candidates are not measured nonzero amplitudes','QG/GF premises inherited, not physical validation','lower-loop coefficient tensors and chi4/contact baselines unmeasured','no common continuum product/trace, measure/QAP, E5/A5 or physical viability claim'],
     'new_files_sha256':files}
dump(O/'final_review_validation_receipt.json',out);dump(C/'final_review_validation_receipt.json',out)
print(json.dumps({k:v for k,v in out.items() if k not in ['new_files_sha256','limitations','successful_captures']},sort_keys=True))
