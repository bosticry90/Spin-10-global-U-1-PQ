from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
import json,gzip,time,threading,os,sys
from domain import *
from support import EPS,UU,JJ,C1,C2,NN,XX
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'canonical_so10_u_F_maximal_cutoff'))
from graded import pmul,lifted,multiply,identity,scale,times
O=Path(__file__).resolve().parent;R=O.parents[1];tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda pp:json.loads(pp.read_bytes());loadz=lambda pp:json.loads(gzip.decompress(pp.read_bytes()))
for pp,h in read(O/'review_preparation.json')['input_sha256'].items():assert sha256(Path(pp).read_bytes()).hexdigest()==h,pp
a=loadz(O/'primary_operators.json.gz');b=loadz(O/'replay_operators.json.gz');assert a['tables']==b['tables'] and a['summaries']==b['summaries']
assert a['guard_denials']==b['guard_denials']==3 and b['metadata']['all_given_GF_Euler_columns_recovered']
def coeff(terms):return Coeff([(tuple(k),__import__('fractions').Fraction(n,d)) for k,n,d in terms])
def decode_table(rows):return {(i,j,tuple(w),nd,tuple(p)):coeff(cs) for i,j,w,nd,p,cs in rows}
tables={name:decode_table(rows) for name,rows in a['tables'].items()};old=loadz(R/'calculations/canonical_so10_u_F_fourth_support/primary_operators.json.gz');comparisons=[]
for name,rows in old['tables'].items():
    if name.startswith(('HU','MU')):
        M={}
        for src in range(3):
            for key,v in tables[name+'_'+str(src)].items():M[key]=M.get(key,ZERO)+v
        low,high=0,1
    else:M=tables[name];low,high=1,2
    projected={key:v for key,v in M.items() if v and not any(1241<=z<1286 for z in key[2]) and low<=key[3]+len(key[2])<=high}
    assert projected==decode_table(rows),('OLD_DOMAIN_PROJECTION',name)
    comparisons.append({'table':name,'entries':len(projected),'whole_old_domain_and_zero_complement_equal':True})
assert sum(z['entries'] for z in comparisons)==207440
print('STAGE complete_old_domain_projection_verified',flush=True)

# Independent two-token deletion of QG source2. No Euler/tangent helper.
data=load('primary');direct_checks=[]
for probe,poly in enumerate(map(decode,data['QG'])):
    direct={};source2={w:v for w,v in poly.items() if sum(i>=643 for i,js in w)==2}
    for w,v in source2.items():
        assert not any(js for i,js in w)
        for si,(src,sj) in enumerate(w):
            if src<643:continue
            out=src-643;rest=w[:si]+w[si+1:]
            left=(-1)**(JP.parity(src)*sum(JP.parity(i) for i,js in w[:si])+JP.parity(out))
            for fi,(field,fj) in enumerate(rest):
                if field>=643:continue
                ext=tuple(i for at,(i,js) in enumerate(rest) if at!=fi)
                right=(-1)**(JP.parity(field)*sum(JP.parity(i) for i,js in rest[fi+1:]))
                key=(out,field,ext,degree(w,4),(0,0,0,0))
                direct[key]=direct.get(key,ZERO)+v*left*right
    direct={k:v for k,v in direct.items() if v}
    assert direct==tables['MU'+str(probe)+'_2'],('SOURCE2_DIRECT_TWO_DELETE',probe)
    assert not tables['HU'+str(probe)+'_2']
    direct_checks.append({'probe':probe,'source2_density_terms':len(source2),'Mu_entries':len(direct),'direct_two_delete_and_full_zero_complement_equal':True})
print('STAGE independent_source2_tangent_verified',flush=True)

inv=loadz(O/'inventory_result.json.gz');assert inv['all_label_tables_equal'] and not inv['potential_required_by_support'] and not inv['fermion_required_by_support']
assert inv['source2_root_candidates_present'] and inv['new_higher_grade_candidates_present']
refined=[z for z in inv['cases'] if z['source_type'] is not None];assert len(refined)==20
for c in inv['cases']:
    for z,y in zip(c['orders'],c['independent_boolean']):
        assert z['order']==y['order'] and set(map(int,z['word_flag_counts']))==set(y['target_flags'])
        assert all(not (w['flag']&3) for w in z['words'])
        assert z['closed_paths']==sum(len(w['paths']) for w in z['words'])
        if z['order']<=1 or c['source_type'] is not None and (c['probe']==0 or c['source_type']=='H'):assert not z['words']
lower=[]
for case in ['T','F']:
    for n in [2,3]:
        contexts=[z for z in refined if z['case']==case and z['probe']==1]
        words={(w['root'],tuple(w['word'])) for c in contexts for w in c['orders'][n]['words']}
        source2={(w['root'],tuple(w['word'])) for c in contexts for w in c['orders'][n]['words'] if w['flag']&4}
        lower.append({'case':case,'order':n,'canonical_candidate_word_union':len(words),'source2_root_candidate_words':len(source2)})

# Independent numeric ring fixtures. Coefficients are arbitrary, not model fits.
offset={'B':(0,2),'L':(2,2),'s':(4,3),'C':(7,2),'a':(9,2),'f':(11,2)};dim=13;nb=7
def literalsign(masks,odd):
    seq=[i for mask in masks for i in range(7) if mask&odd&(1<<i)]
    return (-1)**sum(x>y for at,x in enumerate(seq) for y in seq[at+1:])
def full(V,roots,c,n,odd,removed=0):
    X={}
    for name,M in V.items():
        it=c['vertices'][name]
        if it['flag']&removed:continue
        for ij,v in M.items():X.setdefault(ij,{})[it['mask']]=X.get(ij,{}).get(it['mask'],ZERO)+v
    P={(i,i):{0:constant(1)} for i in range(dim)}
    for at in range(n):P=pmul(P,X,odd)
    target=EPS|UU|JJ|C1|NN|XX|(C2 if c['case']=='F' else 0);value=ZERO
    for name,M in roots.items():
        it=c['roots'][name]
        if it['flag']&removed:continue
        Q=pmul(P,lifted(M,it['mask']),odd)
        value+=sum((poly.get(target,ZERO)*(-1 if i>=nb else 1) for (i,j),poly in Q.items() if i==j),ZERO)
    return value
fixtures=[];controls=Counter()
for c in inv['cases']:
    if c['source_type'] is not None:continue
    odd=EPS|C1|(JJ|C2 if c['case']=='F' else 0)
    for seed in [1,4]:
        mats={}
        for labelno,(name,it) in enumerate(sorted({**c['vertices'],**c['roots']}.items())):
            M={}
            for row,col in it['edges']:
                ro,nr=offset[row];co,nc=offset[col]
                for i in range(nr):
                    for j in range(nc):M[ro+i,co+j]=constant(seed*(labelno+2)+(i+1)**2*(j+2)-(j+1)*(i+3))
            mats[name]=M
        V={name:mats[name] for name in c['vertices']};roots={name:mats[name] for name in c['roots']}
        for n in range(4):
            direct=full(V,roots,c,n,odd);values=[]
            for w in c['orders'][n]['words']:
                labels=w['word']+[w['root']];M=identity(dim)
                for label in labels:M=multiply(M,mats[label])
                masks=[(c['vertices'].get(label) or c['roots'][label])['mask'] for label in labels]
                values.append(literalsign(masks,odd)*sum((v*(-1 if i>=nb else 1) for (i,j),v in M.items() if i==j),ZERO))
            assert direct==sum(values,ZERO),('FIXTURE_TAGGED_POWER',c['case'],c['probe'],seed,n)
            errors={'commuting_exterior':direct-full(V,roots,c,n,0),'omitted_higher_grade':direct-full(V,roots,c,n,odd,8),'omitted_source2_Mu':direct-full(V,roots,c,n,odd,4)}
            for key,v in errors.items():controls[key]+=bool(v)
            fixtures.append({'case':c['case'],'probe':c['probe'],'seed':seed,'order':n,'words':len(values),'direct':str(direct),'word_sum':str(sum(values,ZERO)),'controls':{key:{'difference':str(v),'sensitive':bool(v)} for key,v in errors.items()}})
assert all(controls.values())
out={'schema':'ULC3_DOMAIN_SUPPORT_REVIEW','new_all_label_entries':sum(len(z) for z in a['tables'].values()),'native_arrays_and_zero_complements_equal':True,'old_restricted_projection':comparisons,'source2_independent_direct_checks':direct_checks,
     'physical_potential_and_isolated_fermion_envelopes_excluded_all_orders':True,'C0_C1_support_zero':True,'complete_probe0_and_unbroken_source_support_zero':True,
     'lower_candidate_unions':lower,'fixtures':fixtures,'fixture_sensitive_context_counts':dict(controls),'positive_heat_prime_log_map':inv['positive_heat_prime_log_map'],
     'lower_coefficient_tensors_measured':False,'full_finite_restoration_continuum_or_QAP_claim':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({key:v for key,v in out.items() if key not in ['fixtures','old_restricted_projection']},sort_keys=True),flush=True);timer.cancel()
