# UBC5 delegated E4 authentication, prospective

Run python -B tools/research_check.py e4 ONCE,no--fresh. Expectednative0,
sixsteps[0,0,0,0,0,2],terminalCOMPLETED,custodyexit2/sevenNOTPASS. Preserve
complete output/events and investigate any mismatch. Evidence authentication
and bounded audits are not full scientific replay or director acceptance.
300sobservedcommand,8GiBsampled,350MiBlaunchfloor,32MiBpacket. Do not
terminate unrelated processes or truncate evidence. Final review must
retain three failed scientific-harness attempts as FAILED,never PASS.
