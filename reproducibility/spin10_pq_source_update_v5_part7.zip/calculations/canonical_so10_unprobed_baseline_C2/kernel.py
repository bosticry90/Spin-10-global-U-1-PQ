from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import Counter,defaultdict
import gzip,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(R/'calculations/canonical_so10_unprobed_marginal_C3'))
from cubic_core import *
from blocks import co,dec
O=Path(__file__).resolve().parent;role=sys.argv[1];assert role in ['primary','replay']
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest()
for pp,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(pp))==h,pp
peer='replay' if role=='primary' else 'primary'
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        pp=Path(os.fsdecode(args[0]))
        if pp.parent.resolve()==O and (pp.name.startswith('kernel_'+peer) or pp.name.startswith('review')):raise PermissionError('UBC_PEER_DENIED')
        if pp.parent.name in ['canonical_so10_u_pair_contact_model','canonical_so10_u_lower_cutoff_contraction'] or 'comparison' in pp.name or pp.name=='partial_after_known.json.gz':raise PermissionError('UBC_TARGET_DENIED')
sys.addaudithook(guard);denials=0
for pp in [O/('kernel_'+peer+'_tables.json.gz'),O/'review_result.json',R/'calculations/canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz']:
    try:pp.read_bytes()
    except PermissionError:denials+=1
assert denials==3

# Finite exterior fixtures test the quadratic cyclic reduction,not the
# inherited Gaussian normalization or continuum regulator applicability.
fixtures=[];controls=Counter()
for case in ['JLaCC','JLJLCC']:
    for seed in [1,2,3]:
        V={}
        for i in range(4):
            for j in range(4):
                if (i>=2)!=(j>=2):continue
                for a in range(4):
                    for b in range(a+1,4):
                        if case=='JLJLCC' and (a,b)==(2,3):continue
                        V[i,j,(a,b)]=Fraction((3*seed+5*i+2*j+7*a+11*b)%13-6)
        full=Fraction();root=Fraction();ordinary=Fraction();commuting=Fraction()
        for (i,j,w),v in V.items():
            for (k,l,u),x in V.items():
                if j!=k or l!=i or set(w)&set(u):continue
                word,sg=merge(w+u);assert word==(0,1,2,3)
                full+=-v*x*sg*((-1)**int(i>=2))/4
                ordinary+=-v*x*sg/4;commuting+=-v*x*((-1)**int(i>=2))/4
                if (3 in w if case=='JLaCC' else 2 in w):root+=-v*x*sg*((-1)**int(i>=2))/2
        assert full==root
        controls['ordinary_trace']+=ordinary!=full;controls['commuting_exterior']+=commuting!=full;controls['missing_cyclic_factor2']+=root/2!=full
        fixtures.append({'case':case,'seed':seed,'full':str(full),'rooted':str(root)})
assert all(controls.values()),controls

z,T=get(role);V2={k:v for k,v in T.items() if len(k[2])==2};by=defaultdict(list)
for (i,j,w),v in V2.items():by[i,j].append((w,v))
groups={case:defaultdict(dict) for case in ['JLaCC','JLJLCC']};paths=Counter();sectors=Counter()
for (i,j,w),v in V2.items():
    for u,x in by[j,i]:
        word,sg=merge(w+u)
        if not sg:continue
        case=target(word)
        if case is None:continue
        assert i>=NB and j>=NB,('UNPROVED_NON_GHOST_PATH',i,j,w,u)
        name,key,owner=owning_key(word);assert name==case
        paths[case]+=1;sectors[case,sector(i),sector(j)]+=1
        if role=='replay':
            jls=[a for a in word if 1151<=a<1196]
            if (jls[0] not in w):continue
            weight=Fraction(-1,2)
        else:weight=Fraction(-1,4)
        fam='|'.join(sorted([family(i,j,w),family(j,i,u)]))
        put(groups[case][fam],key,(v*x)*constant(weight*owner*sg*((-1)**int(i>=NB))))
results=[]
for case in ['JLaCC','JLJLCC']:
    gs={k:clean(v) for k,v in groups[case].items()};total={}
    for M in gs.values():
        for k,v in M.items():put(total,k,v)
    total=clean(total);domain=45*45*990 if case=='JLaCC' else 990*990
    results.append({'case':case,'domain_positions':domain,'total':encode(total),'nonzero':len(total),'zero_complement':domain-len(total),
      'groups':{k:encode(v) for k,v in gs.items()},'group_nonzero_counts':{k:len(v) for k,v in gs.items()},'ordered_pair_paths':paths[case]})

# Complete even Ja ghost-mass specialization: no inverse derivative,
# scalar/vector Ja vertex or omitted source half is introduced.
d=loadz(R/('calculations/canonical_so10_unprobed_antighost_kernel/color_'+role+'_inputs.json.gz'))
q=loadz(R/('calculations/canonical_so10_intrinsic_quadratic_source_contacts/color_'+role+'_tables.json.gz'))
aligned=loadz(R/('calculations/canonical_so10_intrinsic_correlated_source_contacts/auxiliary_roots_'+role+'_inputs.json.gz'))
A=list(map(dec,q['A_original_Ja_aC']));assert A==list(map(dec,aligned['A']))
Z={tuple(v[:-1]):co(v[-1]) for v in d['Z']};K={}
if role=='primary':
    idx=defaultdict(list)
    for s,M in enumerate(A):
        for (c,a),v in M.items():idx[a,c].append((s,v))
    for (r,h,a,c),v in Z.items():
        for s,x in idx[a,c]:put(K,(s,r,h),v*x)
else:
    zm=defaultdict(dict)
    for (r,h,a,c),v in Z.items():zm[r,h][a,c]=v
    for (r,h),M in zm.items():
        for s,N in enumerate(A):
            value=ZERO
            for (c,a),v in N.items():value=value+v*M.get((a,c),ZERO)
            put(K,(s,r,h),value)
K=clean(K);results.append({'case':'JaaC','domain_positions':45**3,'total':encode(K),'nonzero':len(K),'zero_complement':45**3-len(K),
 'groups':{'Tr_A_Z':encode(K)},'group_nonzero_counts':{'Tr_A_Z':len(K)}})
out={'schema':'UBC1_COMPLETE_REMAINING_NATIVE_C2','role':role,'results':results,'quadratic_fixtures':fixtures,'sensitive_controls':dict(controls),
 'all_actual_marginal_C2_paths_are_ghost_only':True,'actual_path_sectors':[[list(k),v] for k,v in sorted(sectors.items())],
 'Ja_mass_input_equal_separately_qualified_ICR':True,'Gaussian_normalization_inherited':True,'guard_denials':denials,'old_baseline_remainder_read':False,
 'full_Ward_QAP_or_E5_claim':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/('kernel_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'packed_sha256':H(O/('kernel_'+role+'_tables.json.gz')),'raw_sha256':sha256(raw).hexdigest(),
 'counts':[{k:v for k,v in z.items() if k not in ['total','groups']} for z in results],'elapsed_after_imports':time.perf_counter()-tick},sort_keys=True),flush=True);timer.cancel()
