# UBC2: full C2 tensor and fresh-action review, prospective

Require completed native roles first. Authenticate packed hashes,compare
all three whole tensors,groups and implicit zeros;check full position
domains and actual ghost-only two-edge support. Fixtures must retain
ordinary-supertrace,exterior and cyclic-factor sensitivity with all
insensitive cases explicit. Reused Gaussian premise is not reproved here.

Independently reconstruct the FULL GF density from its90 Euler columns
and use actual original source action,then full643-field fluctuation
Hessians BEFORE target restriction. Compute the unrooted -1/4STr of
the square in all four vector components at selected nonzero and fixed
zero contexts,bothaxis/q. Ja is EVEN while JL/a/C are ODD;use actual
parities,not a four-odd helper for the Ja channel. This test must not use
the A/Z or rooted-pair formula. Retain source/GF vertices and all allowed
first/second external grades. Do not read old baseline/comparison data.

At most4 deterministic nonzero+2 fixed zero contexts pertype,36checks.
If a full tensor is zero,report only the available fixed zero checks and
generic sensitivity separately. No baseline cancellation is an acceptance
condition. Scope is complete declared C2 inputs,not finite restoration.
180safterimports,8GiBsampled,350MiBlaunchfloor,32MiBpacket;freeze all
sources/inputs beforelaunch,preserve failures and completecaptures.
