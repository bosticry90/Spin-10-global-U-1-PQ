# UBC3 parsing continuation V2, prospective

The first native transport stopped with TypeError before any output tensor:
ICR heat_and_group_tensors.C2 is a LIST of coefficient rows,not an object
with entries. The authentic measured zero remains the empty list. The
original source/copy,preparation,complete FAILED capture and controller
failure remain immutable and unqualified. post_run_observations_qualified
does not relabel the failed scientific calculation PASS.

Change only that selector to read the list and assert its list type/zero.
Use new V2 preparation/source/output/capture names and bind all V1 bytes.
Every scientific input,whole tensor requirement,graded source operation,
scope,authority ceiling and300s/role,600saggregate,8GiBsampled,350MiBfloor,
32MiBpacket limits remain. This is one justified routine schema correction,
not permission to invent a missing coefficient or rerun old loops. Later
review must check the exact source diff and both completed V2 roles.
