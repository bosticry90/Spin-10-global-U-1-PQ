from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-baseline-c2-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
    with p.open('xb') as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings=dict(read(O/'baseline_review_preparation.json')['input_sha256'])
    for pp,h in bindings.items():assert H(Path(pp))==h,pp
    assert read(O/'transport_execution_result_v3.json')['aggregate_after_imports_seconds']<=600
    for folder,names in [('canonical_so10_u_pair_contact_model',['partial_TF_tables.json.gz','lowering_validation_receipt.json']),
      ('canonical_so10_u_lower_cutoff_contraction',['PROOF.md','final_review_validation_receipt.json']),
      ('canonical_so10_unprobed_source_root_module',['support_primary_tables.json.gz','support_replay_tables.json.gz','support_primary_result.json','support_replay_result.json','support_validation_receipt.json'])]:
        for name in names:
            pp=R/'calculations'/folder/name;bindings[str(pp)]=H(pp)
    for name in ['BASELINE_REVIEW_CONTINUATION_V2.md','baseline_review_v2.py','run_baseline_review_v2.py']:
        pp=O/name
        if pp.suffix=='.py':ast.parse(pp.read_bytes())
        assert all(line==line.rstrip(b' \t') for line in pp.read_bytes().splitlines()),name
        with (O/(name+'.source.txt')).open('xb') as f:f.write(pp.read_bytes())
    for pp in O.iterdir():
        if pp.is_file():bindings[str(pp)]=H(pp)
    dump(O/'baseline_review_preparation_v2.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    z=capture([sys.executable,'-B',str(O/'baseline_review_v2.py')]);dump(O/'baseline_review_capture_v2.json',z);dump(C/'baseline_review_full_capture_v2.json',z)
    assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified']
    assert read(O/'baseline_review_result_v2.json')['elapsed_after_imports']<180
    print('COMPLETED UBC4 whole native and late baseline qualification',flush=True)
except BaseException:
    dump(O/'baseline_review_controller_failure_v2.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
