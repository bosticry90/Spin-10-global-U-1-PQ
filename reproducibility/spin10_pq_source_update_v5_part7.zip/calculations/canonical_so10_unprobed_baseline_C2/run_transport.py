from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-baseline-c2-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
    with p.open('xb') as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings=dict(read(O/'review_preparation.json')['input_sha256'])
    for pp,h in bindings.items():assert H(Path(pp))==h,pp
    assert read(O/'review_result.json')['whole_tensors_groups_and_implicit_zeros_equal']
    specs=[('canonical_so10_unprobed_antighost_kernel','color',['color_validation_receipt_v2.json']),
      ('canonical_so10_unprobed_auxiliary_source_kernel','color',['color_validation_receipt.json']),
      ('canonical_so10_intrinsic_quadratic_source_contacts','auxiliary',['auxiliary_validation_receipt.json','source_flow_validation_receipt_v3.json','source_flow_tables_v3.json.gz','RESULT.md']),
      ('canonical_so10_intrinsic_correlated_source_contacts','auxiliary_roots',['auxiliary_roots_validation_receipt.json']),
      ('canonical_so10_u_operation_root_inventory','root',['validation_receipt.json']),
      ('canonical_so10_unprobed_log2_completion','transport',['final_review_validation_receipt.json']),
      ('canonical_so10_unprobed_source_root_module',None,['RESULT.md','RECORD.md','color_validation_receipt.json'])]
    for folder,prefix,names in specs:
        if prefix:
            names=names+[prefix+'_'+role+'_'+suffix for role in ['primary','replay'] for suffix in ['tables.json.gz','result.json']]
        for name in names:
            pp=R/'calculations'/folder/name;bindings[str(pp)]=H(pp)
    for name in ['BASELINE_RECORD.md','transport.py','run_transport.py']:
        pp=O/name
        if pp.suffix=='.py':ast.parse(pp.read_bytes())
        assert all(line==line.rstrip(b' \t') for line in pp.read_bytes().splitlines()),name
        with (O/(name+'.source.txt')).open('xb') as f:f.write(pp.read_bytes())
    for pp in O.iterdir():
        if pp.is_file():bindings[str(pp)]=H(pp)
    dump(O/'transport_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED','aggregate_budget_seconds':600})
    used=0
    for role in ['primary','replay']:
        z=capture([sys.executable,'-B',str(O/'transport.py'),role]);dump(O/('transport_'+role+'_capture.json'),z);dump(C/('transport_'+role+'_full_capture.json'),z)
        assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified']
        result=[json.loads(v[7:]) for v in z['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(result)==1 and result[0]['elapsed_after_imports']<300
        used+=result[0]['elapsed_after_imports'];assert used<=600
        dump(O/('transport_'+role+'_result.json'),result[0]);print('COMPLETED UBC3 '+role,flush=True)
    dump(O/'transport_execution_result.json',{'aggregate_after_imports_seconds':used,'budget_seconds':600,'scientific_acceptance':'NOT_PERFORMED'})
except BaseException:
    dump(O/'transport_controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
