from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import gzip,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(R/'calculations/canonical_so10_unprobed_log2_completion'))
from quartic_core import coeff,ZERO,put,clean,encode
from blocks import co
O=Path(__file__).resolve().parent
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest()
for pp,h in read(O/'baseline_review_preparation_v2.json')['input_sha256'].items():assert H(Path(pp))==h,pp
def unpack(rows):
    M={tuple(z[:-1]):coeff(z[-1]) for z in rows};assert len(M)==len(rows) and all(M.values());return M
def add(A,B,weight=1):
    M=dict(A)
    for k,v in B.items():put(M,k,v*weight)
    return clean(M)

# Exact science-worker correction audit: one historical list selector and
# versioned aliases only; original failed source/captures remain immutable.
s1=(O/'transport.py').read_text();s2=(O/'transport_v2.py').read_text();s3=(O/'transport_v3.py').read_text()
s1=s1.replace("['heat_and_group_tensors']['C2']['entries'];assert not rows;native['JaJLC']={}","['heat_and_group_tensors']['C2'];assert isinstance(rows,list) and not rows;native['JaJLC']={}")
s1=s1.replace("O/'transport_preparation.json'","O/'transport_preparation_v3.json'").replace("'transport_'+peer","'transport_v3_'+peer").replace("O/('transport_'+role","O/('transport_v3_'+role")
s2=s2.replace("P=R/'calculations/canonical_so10_unprobed_log2_completion';pp=P/('transport_v2_'+role+'_tables.json.gz')","P=R/'calculations/canonical_so10_unprobed_log2_completion';pp=P/('transport_'+role+'_tables.json.gz')")
s2=s2.replace("O/'transport_preparation_v2.json'","O/'transport_preparation_v3.json'").replace("'transport_v2_'+peer","'transport_v3_'+peer").replace("O/('transport_v2_'+role","O/('transport_v3_'+role")
assert s1==s2==s3
for name,diagnostic in [('transport_primary_capture.json','TypeError: list indices'),('transport_v2_primary_capture.json','FileNotFoundError')]:
    z=read(O/name);assert z['execution_state']=='FAILED' and z['exit_code']!=0 and not z['calculation_completed'] and diagnostic in z['stdout_and_stderr']

ab=[]
for role in ['primary','replay']:
    pp=O/('transport_v3_'+role+'_tables.json.gz');assert H(pp)==read(O/('transport_v3_'+role+'_result.json'))['packed_sha256'];ab.append(loadz(pp))
assert ab[0]['results']==ab[1]['results'] and ab[0]['native_C2_roots']==ab[1]['native_C2_roots']
assert all(z['all_ten_roots_retained'] and z['guard_denials']==3 and not z['old_desired_baseline_read'] and not z['chi4_b0_kappa_IR_fixed'] for z in ab)
assert len(ab[0]['native_C2_roots'])==10
for case,rows in ab[0]['native_C2_roots'].items():assert len(unpack(rows))==ab[0]['native_C2_nonzero'][case]
P=R/'calculations/canonical_so10_unprobed_source_root_module';supports=[]
for role in ['primary','replay']:
    pp=P/('support_'+role+'_tables.json.gz');assert H(pp)==read(P/('support_'+role+'_result.json'))['packed_sha256'];z=loadz(pp)
    assert len(z['ordered_words'])==54 and all(len(w['letters'])==3 for w in z['ordered_words']);supports.append({k:v for k,v in z.items() if k!='role'})
assert supports[0]==supports[1] and read(P/'support_validation_receipt.json')['complete_directed_cycles_vs_multisets_permutations_pass']
P=R/'calculations/canonical_so10_intrinsic_quadratic_source_contacts'
assert H(P/'source_flow_tables_v3.json.gz')==read(P/'source_flow_validation_receipt_v3.json')['packed_sha256']

images={};groups={};heats={};coverage=[]
for z in ab[0]['results']:
    key=(z['probe'],z['target']);G={name:unpack(rows) for name,rows in z['C2_groups'].items()};c2={}
    for name,M in G.items():
        assert len(M)==z['C2_group_nonzero_counts'][name];c2=add(c2,M)
    c3=unpack(z['C3_image']);c4=unpack(z['C4_image']);base=add(add(c2,c3),c4)
    assert c2==unpack(z['C2_image']) and base==unpack(z['chi4_image'])
    assert [len(c2),len(c3),len(c4),len(base)]==[z['C2_nonzero'],z['C3_nonzero'],z['C4_nonzero'],z['chi4_nonzero']]
    assert len(base)+z['chi4_zero_complement']==z['domain_positions']==(45*45 if z['target']=='T' else 45*990)*328
    for M in [c2,c3,c4,base]+list(G.values()):
        if z['target']=='T':assert all(0<=a<45 and 0<=h<45 and 0<=i<328 for a,h,i in M)
        else:assert all(0<=a<45 and 0<=h<k<45 and 0<=i<328 for a,h,k,i in M)
    images[key]=base;groups[key]=G;heats[key]=[c2,c3,c4]
    coverage.append({k:v for k,v in z.items() if k not in ['C2_groups','C2_image','C3_image','C4_image','chi4_image']})
assert set(images)=={(p,t) for p in range(2) for t in ['T','F']}
u=loadz(R/'calculations/canonical_so10_u_operation_root_inventory/root_primary_tables.json.gz')
actual={(tuple(p),nu) for row in u['results'] for ops in row['targets'].values() for p,nu,count in ops['nonzero_flows_by_root']}
assert len(actual)==10 and len(ab[0]['native_C2_roots'])==10
proof=read(R/'calculations/canonical_so10_unprobed_log2_completion/method_result.json')
assert actual=={(tuple(z['types']),z['intrinsic_degree']) for z in proof['native_root_dimension_proof']}
assert all(z['native_C1']=='EXCLUDED_BY_POLYNOMIAL_DIMENSION' for z in proof['native_root_dimension_proof'])

# The complete cutoff finite symbol is a heat difference,with prime logs
# and no chi4. Authenticate its owning analytic proof;no continuum limit
# or new radial integration is inferred from this reuse.
P=R/'calculations/canonical_so10_u_lower_cutoff_contraction';pp=P/'PROOF.md';rel=str(pp.relative_to(R)).replace('\\','/')
assert H(pp)==read(P/'final_review_validation_receipt.json')['new_files_sha256'][rel]
assert 'log((n+1)/n)/(16pi^2)' in pp.read_text()

# First numerical decoding of the prior baseline AFTER whole native
# agreement,all root/zero premises and the cutoff carrier check above.
P=R/'calculations/canonical_so10_u_pair_contact_model';pp=P/'partial_TF_tables.json.gz'
assert H(pp)==read(P/'lowering_validation_receipt.json')['partial_packed_sha256'];old=loadz(pp)
late=[];saved=[]
for probe in range(2):
    row=next(z for z in old['results'] if z['probe']==probe);part=next(z for z in row['partial_relations'] if z['basis']=='chi4')
    assert part['Bu_C0_and_applicability_missing_not_zero']
    for target in ['T','F']:
        key=(probe,target);rows=part['homogeneous_plus_Euler_partial'][target];assert all(isinstance(row[-1],str) for row in rows)
        prev={tuple(row[:-1]):co(row[-1]) for row in rows};assert len(prev)==len(rows) and all(prev.values());combined=add(prev,images[key])
        late.append({'probe':probe,'target':target,'basis':'chi4','previous_partial_nonzero':len(prev),'actual_native_image_nonzero':len(images[key]),
          'complete_declared_sum_nonzero':len(combined),'complete_declared_sum_zero':not combined,'omit_heat_sum_nonzero':{str(j+2):len(add(combined,M,-1)) for j,M in enumerate(heats[key])},
          'omit_C2_group_sum_nonzero':{name:len(add(combined,M,-1)) for name,M in groups[key].items()},'chi4_selected':False,'full_Ward_or_QAP_claim':False})
        saved.append({'probe':probe,'target':target,'basis':'chi4','sum':encode(combined)})
payload={'schema':'UBC4_COMPLETE_DECLARED_T_F_BASELINE_COMPARISON','results':late,'tensors':saved,'cancellation_required_for_execution_PASS':False,'full_Ward_claim':False}
blob=gzip.compress((json.dumps(payload,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/'baseline_complete_comparison_v2.json.gz').open('xb') as f:f.write(blob)
out={'schema':'UBC4_COMPLETE_NATIVE_BASELINE_REVIEW','whole_native_C2_roots_images_and_zero_complements_equal':True,'coverage':coverage,
 'all_ten_root_dependencies_and_cutoff_no_chi4_premise_accounted_for':True,'late_baseline_comparisons':late,'baseline_constant_remains_symbolic':True,
 'USR_C2_absence_by_qualified_complete_54_three_edge_words':True,'both_failed_transport_versions_preserved_not_PASS':True,'worker_diff_only_schema_selector_and_aliases':True,
 'packed_comparison_sha256':sha256(blob).hexdigest(),'scientific_disposition':'COMPLETE_DECLARED_BASELINE_ZERO' if all(z['complete_declared_sum_zero'] for z in late) else 'COMPLETE_DECLARED_BASELINE_NONZERO',
 'full_Ward_QAP_or_scientific_promotion':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'baseline_review_result_v2.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
