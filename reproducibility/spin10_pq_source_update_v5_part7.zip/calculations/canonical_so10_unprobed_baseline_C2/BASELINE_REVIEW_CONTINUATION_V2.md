# UBC4 historical coefficient decoder correction, prospective

The first baseline review passed native tensor equality,all reuse/zero
premises,ten-root coverage and cutoff carrier checks,then failed decoding
the OLD UPM chi4 partial. That older table stores coefficients as exact
expression strings;the newer native tensors store rational-root term
triples. The late old rows must use the existing exact co(string) parser,
not coeff(term_triples). Both schemas are legitimate and unchanged.

Preserve the original FAILED review source/copy,preparation,complete
capture and controller failure. No complete baseline disposition was
produced. V2 adds an explicit string-row decoder ONLY for the old table,
with schema/duplicate/nonzero checks. Native inputs/decoders,equations,
zero/nonzero acceptance,scope,authority and all resource limits stay fixed.
Keep new review/output/preparation/capture aliases. Before launch inspect
the actual old row schema and source diff;never change any old value.
One180s review,8GiBsampled,350MiBfloor,32MiBpacket. Repeated historical
schema errors are workflow failures to report,not scientific failures or
permission to weaken provenance. No new native quantum loop is needed.
