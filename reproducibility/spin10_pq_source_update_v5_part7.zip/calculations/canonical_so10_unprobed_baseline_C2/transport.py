from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
import gzip,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(R/'calculations/canonical_so10_unprobed_log2_completion'))
from quartic_core import coeff,ZERO,constant,put,clean,encode
from blocks import co
O=Path(__file__).resolve().parent;role=sys.argv[1];assert role in ['primary','replay']
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest()
for pp,h in read(O/'transport_preparation.json')['input_sha256'].items():assert H(Path(pp))==h,pp
peer='replay' if role=='primary' else 'primary'
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        pp=Path(os.fsdecode(args[0]))
        if pp.parent.resolve()==O and (pp.name.startswith('transport_'+peer) or pp.name.startswith('baseline_review')):raise PermissionError('UBC_TRANSPORT_PEER_DENIED')
        if pp.parent.name in ['canonical_so10_u_pair_contact_model','canonical_so10_u_lower_cutoff_contraction']:raise PermissionError('UBC_BASELINE_TARGET_DENIED')
sys.addaudithook(guard);denials=0
for pp in [O/('transport_'+peer+'_tables.json.gz'),O/'baseline_review_result.json',R/'calculations/canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz']:
    try:pp.read_bytes()
    except PermissionError:denials+=1
assert denials==3 and read(O/'review_result.json')['whole_tensors_groups_and_implicit_zeros_equal']
def unpack(rows):
    M={tuple(z[:-1]):coeff(z[-1]) for z in rows};assert len(M)==len(rows) and all(M.values());return M
def old(folder,prefix):
    P=R/'calculations'/folder;pp=P/(prefix+'_'+role+'_tables.json.gz');assert H(pp)==read(P/(prefix+'_'+role+'_result.json'))['packed_sha256'];return loadz(pp)
native={z['case']:unpack(z['total']) for z in old('canonical_so10_unprobed_baseline_C2','kernel')['results']}
for case,folder in [('naCx','canonical_so10_unprobed_antighost_kernel'),('nJLCx','canonical_so10_unprobed_auxiliary_source_kernel')]:
    rows=old(folder,'color')['F_m']['2'];native[case]={tuple(z[:-1]):co(z[-1]) for z in rows};assert len(native[case])==len(rows)
native['nLx']={tuple(z[:-1]):co(z[-1]) for z in old('canonical_so10_intrinsic_quadratic_source_contacts','auxiliary')['Lambda_x']['F2_ghost']['entries']}
icr=old('canonical_so10_intrinsic_correlated_source_contacts','auxiliary_roots')
rows=next(z for z in icr['results'] if z['root']=='Ja_JL_C')['heat_and_group_tensors']['C2']['entries'];assert not rows;native['JaJLC']={}
P=R/'calculations/canonical_so10_intrinsic_quadratic_source_contacts'
assert read(P/'source_flow_validation_receipt_v3.json')['source_roots_Jax_JaJa_structural_zero']
sf=loadz(P/'source_flow_tables_v3.json.gz');assert sf['Ja_x_root_zero_by_original_A_and_PH_S0'] and sf['Ja_Ja_root_zero_by_A_M_from_H_square']
native['nJax']={};native['JaJa']={};native['JxCx']={}
assert read(R/'calculations/canonical_so10_unprobed_source_root_module/color_validation_receipt.json')['all_4841280_positions_and_zero_complement_compared']
assert read(R/'calculations/canonical_so10_unprobed_auxiliary_source_kernel/color_validation_receipt.json')['full_heat_coefficients_and_implicit_zeros_agree']
assert read(R/'calculations/canonical_so10_intrinsic_correlated_source_contacts/auxiliary_roots_validation_receipt.json')['all_91125_positions_per_root_heat_and_zeros_agree']

P=R/'calculations/canonical_so10_unprobed_log2_completion';pp=P/('transport_'+role+'_tables.json.gz');rel=str(pp.relative_to(R)).replace('\\','/')
assert H(pp)==read(P/'final_review_validation_receipt.json')['new_files_sha256'][rel];prior=loadz(pp)
u=old('canonical_so10_u_operation_root_inventory','root');names=loadz(R/('calculations/canonical_so10_u_maximal_heat_cutoff/'+role+'_inputs.json.gz'))['field_order']
ids={n:i for i,n in enumerate(names)};ids.update({'J'+n:643+i for i,n in enumerate(names)})
parity=lambda i:int(553<=i<643) if i<643 else 1-int(553<=i-643<643)
def canonical(word):
    odd=[i for i in word if parity(i)]
    if len(odd)!=len(set(odd)):return (),0
    return tuple(sorted(word)),(-1)**sum(a>b for at,a in enumerate(odd) for b in odd[at+1:])
def density(case,key):
    if case=='naCx':a,h,i=key;return (598+a,553+h,180+i)
    if case=='nJLCx':r,h,i=key;return (1151+r,553+h,180+i)
    if case=='nLx':a,i=key;return (508+a,180+i)
    if case=='JaaC':s,r,h=key;return (1241+s,598+r,553+h)
    r,s,h,k=key;return (1151+r,598+s,553+h,553+k) if case=='JLaCC' else (1151+r,1151+s,553+h,553+k)
def key_of(word,target):
    xx=[i-180 for i in word if 180<=i<508];cc=[i-553 for i in word if 553<=i<598];low=1241 if target=='T' else 1151;jj=[i-low for i in word if low<=i<low+45]
    assert len(xx)==len(jj)==1 and len(cc)==(1 if target=='T' else 2) and len(word)==(3 if target=='T' else 4)
    if target=='F':assert cc[0]<cc[1]
    return (jj[0],*cc,xx[0])
patterns={'naCx':(('C','a','x'),1),'nJLCx':(('C','JL','x'),1),'nLx':(('L','x'),1),'JaaC':(('C','Ja','a'),0),
 'JLaCC':(('C','C','JL','a'),0),'JLJLCC':(('C','C','JL','JL'),0),'JaJLC':(('C','JL','Ja'),0),'nJax':(('Ja','x'),1),'JaJa':(('Ja','Ja'),0),'JxCx':(('C','Jx','x'),0)}
assert set(native)==set(patterns)
results=[]
for probe,record in enumerate(u['results']):
    for target in ['T','F']:
        groups={};counts={};provenance={};ops=record['targets'][target]
        for case,(pat,nu) in patterns.items():
            flows=defaultdict(list)
            for pattern,nd,out,rem,value in ops['aggregate_flows']:
                if tuple(pattern)==pat and nd==nu:flows[ids[out]].append((tuple(ids[n] for n in rem),co(value)))
            counts[case]=sum(map(len,flows.values()));provenance[case]=dict(Counter(z['QG_source_degree'] for z in ops['routes'] if tuple(z['C0_root_type'])==pat and z['C0_intrinsic_degree']==nu))
            image={}
            for key,v in (native[case].items() if role=='primary' else reversed(list(native[case].items()))):
                word=density(case,key);sg0=1
                if role=='replay':word,sg0=canonical(word)
                for at,out in enumerate(word):
                    prefix=(-1)**sum(parity(i) for i in word[:at])
                    for rem,f in flows.get(out,[]):
                        new,sg=canonical(word[:at]+rem+word[at+1:])
                        if sg:put(image,key_of(new,target),(v*f)*(prefix*sg0*sg))
            groups[case]=clean(image)
        c2={}
        for M in groups.values():
            for k,v in M.items():put(c2,k,v)
        c2=clean(c2);row=next(z for z in prior['results'] if z['probe']==probe and z['target']==target)
        c3=unpack(row['C3_image']);c4=unpack(row['C4_image']);baseline=dict(c2)
        for M in [c3,c4]:
            for k,v in M.items():put(baseline,k,v)
        baseline=clean(baseline);domain=(45*45 if target=='T' else 45*990)*328
        results.append({'probe':probe,'target':target,'domain_positions':domain,'C2_groups':{k:encode(v) for k,v in groups.items()},'C2_group_nonzero_counts':{k:len(v) for k,v in groups.items()},
          'C2_image':encode(c2),'C3_image':encode(c3),'C4_image':encode(c4),'chi4_image':encode(baseline),'C2_nonzero':len(c2),'C3_nonzero':len(c3),'C4_nonzero':len(c4),
          'chi4_nonzero':len(baseline),'chi4_zero_complement':domain-len(baseline),'actual_aggregate_flow_counts':counts,'QG_source_degree_provenance':provenance})
out={'schema':'UBC3_COMPLETE_NATIVE_UNWEIGHTED_U_IMAGE','role':role,'native_C2_roots':{k:encode(v) for k,v in native.items()},'native_C2_nonzero':{k:len(v) for k,v in native.items()},'results':results,
 'zero_premises':['ICR measured JaJLC C2','IQC PH*S0 and A=PM*A*PH: Ja*x/JaJa','USR complete C3-only JxCx'],
 'guard_denials':denials,'all_ten_roots_retained':True,'old_desired_baseline_read':False,'chi4_b0_kappa_IR_fixed':False,'full_Ward_QAP_or_E5_claim':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/('transport_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'packed_sha256':H(O/('transport_'+role+'_tables.json.gz')),'raw_sha256':sha256(raw).hexdigest(),'counts':[{k:v for k,v in z.items() if k not in ['C2_groups','C2_image','C3_image','C4_image','chi4_image']} for z in results],
 'elapsed_after_imports':time.perf_counter()-tick},sort_keys=True),flush=True);timer.cancel()
