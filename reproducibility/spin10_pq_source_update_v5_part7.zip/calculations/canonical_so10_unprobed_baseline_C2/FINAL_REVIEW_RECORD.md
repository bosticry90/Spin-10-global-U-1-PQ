# UBC5 final evidence and preservation review, prospective

Authenticate every frozen preparation/source copy and successful/FAILED
capture. Expect EXACTLY three preserved FAILED harness workers with their
actual TypeError,FileNotFoundError and old-expression-decoder ValueError;
require none countedPASS. Successful C2,review,V3transport,V2baseline and
E4 captures must have native0,completed calculation,owned process creation
and valid resource observations. Check per-worker/aggregate limits and
actual scientific dispositions. A failed capture's qualified post-run
observation does not upgrade its scientific status.

Authenticate the successful baseline qualification and symbolicchi4
disposition. Authenticate prior ULD log2 result/receipt;do not rerun old
science. E4 exactlyonce/no--fresh,expected exits[0,0,0,0,0,2],custodyseven
NOTPASS. Check all existing tracked bytes/Git tree/main/state unchanged.
Seal new UBC bytes and handoffV657 exceptsealself. Beforelocalcommit,
require original staged whitespacecheck0,exact raw-staged hashes and
preserved oldmode/blob entries. No protectedpromotion/external action.

180safterimports,8GiBsampled,350MiBlaunchfloor,32MiBpacket. Preserve any
unexpected failure without weakening these criteria. Actual receipt owns
qualification;this record or a hash alone does not accept science.
