from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-baseline-c2-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
    with p.open('xb') as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    C.mkdir(parents=True,exist_ok=True)
    tree=subprocess.run(['git','ls-tree','-r','--full-tree','HEAD'],cwd=R,stdout=subprocess.PIPE,check=True).stdout
    with (C/'old_git_tree.txt').open('xb') as f:f.write(tree)
    P=R/'calculations/canonical_so10_unprobed_log2_completion'
    bindings=dict(read(P/'final_preparation.json')['input_sha256'])
    for pp,h in bindings.items():assert H(Path(pp))==h,pp
    for folder,names in [('canonical_so10_unprobed_log2_completion',['final_review_validation_receipt.json']),
      ('canonical_so10_intrinsic_correlated_source_contacts',['auxiliary_roots_primary_inputs.json.gz','auxiliary_roots_replay_inputs.json.gz','auxiliary_roots_validation_receipt.json']),
      ('canonical_so10_intrinsic_quadratic_source_contacts',['color_primary_tables.json.gz','color_replay_tables.json.gz','color_validation_receipt.json']),
      ('canonical_so10_unprobed_antighost_kernel',['color_primary_inputs.json.gz','color_replay_inputs.json.gz','color_validation_receipt_v2.json'])]:
        for name in names:
            pp=R/'calculations'/folder/name;bindings[str(pp)]=H(pp)
    for pp in [R/'AGENTS.md',R/'CHARTER.md',R/'docs/LOCAL_RESEARCH_CONVENTIONS_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V656.md',R/'project_state.json']:
        bindings[str(pp)]=H(pp)
    for name in ['.gitattributes','RECORD.md','kernel.py','run.py']:
        pp=O/name
        if pp.suffix=='.py':ast.parse(pp.read_bytes())
        assert all(line==line.rstrip(b' \t') for line in pp.read_bytes().splitlines()),name
        with (O/(name+'.source.txt')).open('xb') as f:f.write(pp.read_bytes())
        bindings[str(pp)]=H(pp);bindings[str(O/(name+'.source.txt'))]=H(pp)
    dump(O/'preparation.json',{'input_sha256':bindings,'base_HEAD':'64614f33c64d5a3c204cd5d6f5b5a05dbd9d0c8e','aggregate_native_budget_after_imports':600,'scientific_acceptance':'NOT_PERFORMED'})
    used=0
    for role in ['primary','replay']:
        z=capture([sys.executable,'-B',str(O/'kernel.py'),role]);dump(O/('kernel_'+role+'_capture.json'),z);dump(C/('kernel_'+role+'_full_capture.json'),z)
        assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified']
        result=[json.loads(v[7:]) for v in z['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(result)==1 and result[0]['elapsed_after_imports']<300
        used+=result[0]['elapsed_after_imports'];assert used<=600
        dump(O/('kernel_'+role+'_result.json'),result[0]);print('COMPLETED UBC1 '+role,flush=True)
    dump(O/'execution_result.json',{'aggregate_after_imports_seconds':used,'budget_seconds':600,'scientific_acceptance':'NOT_PERFORMED'})
except BaseException:
    dump(O/'controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
