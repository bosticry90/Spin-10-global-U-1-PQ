from pathlib import Path
from hashlib import sha256
import ast,json,os,subprocess,threading,time
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-baseline-c2-v1-2026-10-26')
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
bindings={};preps=[]
for prep in sorted(O.glob('*preparation*.json')):
    preps.append(prep.name)
    for pp,h in read(prep)['input_sha256'].items():
        assert H(Path(pp))==h,(prep.name,pp)
        if pp in bindings:assert bindings[pp]==h
        bindings[pp]=h
copies=list(O.glob('*.source.txt'))
for pp in copies:assert pp.read_bytes()==pp.with_name(pp.name[:-11]).read_bytes(),pp
for pp in O.glob('*.py'):ast.parse(pp.read_bytes())
for pp in O.iterdir():
    if pp.suffix in ['.py','.md','.txt']:assert all(line==line.rstrip(b' \t') for line in pp.read_bytes().splitlines()),pp
failures={'transport_primary_capture.json':'TypeError: list indices','transport_v2_primary_capture.json':'FileNotFoundError','baseline_review_capture.json':'ValueError: not enough values to unpack'}
complete=[];failed=[];largest=0
for pp in sorted(O.glob('*capture*.json')):
    z=read(pp)
    assert not z['failed_or_incomplete_counted_as_PASS'] and z['launch']['creation_after_observation']
    assert z['launch']['memory']['available_pagefile']>=350*1024**2
    assert z['all_resource_samples'] and all(0<v['private_bytes']<=8*1024**3 and 'query_error' not in v for v in z['all_resource_samples'])
    if pp.name in failures:
        assert z['execution_state']=='FAILED' and z['exit_code']!=0 and not z['calculation_completed'] and failures[pp.name] in z['stdout_and_stderr'];failed.append(pp.name)
    else:
        assert z['execution_state']=='COMPLETED' and z['exit_code']==0 and z['calculation_completed'] and z['post_run_observations_qualified'],pp
        largest=max(largest,max(v['private_bytes'] for v in z['all_resource_samples']));complete.append(pp.name)
assert set(failed)==set(failures) and len(complete)==7
assert not (O/'baseline_review_result.json').exists() and not (O/'transport_primary_tables.json.gz').exists() and not (O/'transport_v2_primary_tables.json.gz').exists()
assert set(pp.name for pp in O.glob('*controller_failure*.json'))=={'transport_controller_failure.json','transport_controller_failure_v2.json','baseline_review_controller_failure.json'}
for name in ['kernel_primary_result','kernel_replay_result','transport_v3_primary_result','transport_v3_replay_result']:assert read(O/(name+'.json'))['elapsed_after_imports']<300
for name in ['review_result','baseline_review_result_v2']:assert read(O/(name+'.json'))['elapsed_after_imports']<180
for name in ['execution_result','transport_execution_result_v3']:
    z=read(O/(name+'.json'));assert z['aggregate_after_imports_seconds']<=z['budget_seconds']==600
k=read(O/'review_result.json');b=read(O/'baseline_review_result_v2.json')
assert k['whole_tensors_groups_and_implicit_zeros_equal'] and len(k['fresh_uncut_checks'])==28
assert b['whole_native_C2_roots_images_and_zero_complements_equal'] and b['all_ten_root_dependencies_and_cutoff_no_chi4_premise_accounted_for']
assert b['both_failed_transport_versions_preserved_not_PASS'] and b['worker_diff_only_schema_selector_and_aliases'] and b['baseline_constant_remains_symbolic']
assert b['scientific_disposition'] in ['COMPLETE_DECLARED_BASELINE_ZERO','COMPLETE_DECLARED_BASELINE_NONZERO']
if b['scientific_disposition']=='COMPLETE_DECLARED_BASELINE_ZERO':assert all(z['complete_declared_sum_zero'] and not z['complete_declared_sum_nonzero'] and not z['chi4_selected'] for z in b['late_baseline_comparisons'])
P=R/'calculations/canonical_so10_unprobed_log2_completion';old=read(P/'final_review_validation_receipt.json')
pp=P/'final_review_result.json';rel=str(pp.relative_to(R)).replace('\\','/');assert H(pp)==old['new_files_sha256'][rel] and read(pp)['declared_log2_disposition']=='COMPLETE_DECLARED_LOG2_ZERO'
events=read(O/'e4_events.json');steps=[z for z in events if z['event']=='step_finished']
assert [z['exit_code'] for z in steps]==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested']
assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout'] and read(O/'e4_capture.json')['elapsed_seconds']<300
git=lambda *args:subprocess.run(['git',*args],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()=='64614f33c64d5a3c204cd5d6f5b5a05dbd9d0c8e' and git('branch','--show-current').decode().strip()=='main'
assert git('ls-tree','-r','--full-tree','HEAD')==(C/'old_git_tree.txt').read_bytes();git('diff','--quiet','HEAD','--')
state=H(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
size=sum(p.stat().st_size for p in O.rglob('*') if p.is_file());assert size<32*1024**2
out={'schema':'UBC5_FINAL_BOUNDED_EVIDENCE_REVIEW','preparation_bindings_authenticated':len(bindings),'preparations':preps,'source_copies_equal':len(copies),
 'completed_captures_authenticated':complete,'failed_captures_preserved_not_PASS':failed,'largest_successful_sampled_private_bytes':largest,
 'packet_bytes_before_final_capture_and_seal':size,'bounded_evidence_validation':'PASS_WITHIN_FROZEN_SCOPE','baseline_disposition':b['scientific_disposition'],
 'chi4_symbolic':True,'prior_log2_zero_authenticated':True,'full_Ward_QAP_or_E5_claim':False,'E4_step_exits':[z['exit_code'] for z in steps],
 'custody':'EXIT2_SEVEN_UNRESOLVED_NOTPASS','old_tracked_tree_and_state_unchanged':True,'state_sha256':state,'scientific_acceptance':'NOT_PERFORMED','elapsed_after_imports':time.perf_counter()-tick}
with (O/'final_review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
