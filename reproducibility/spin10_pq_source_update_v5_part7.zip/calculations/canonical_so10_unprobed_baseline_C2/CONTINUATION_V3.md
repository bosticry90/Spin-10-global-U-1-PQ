# UBC3 path correction V3, prospective

V2 correctly decoded the old ICR list and passed that check. Its mechanical
versioned-output rename also changed the path to the PRIOR ULD transport
table,which is named transport_primary/replay,not transport_v2. This
FileNotFoundError occurred before any new image tensor or late baseline
read. Preserve the complete V2 source/copy/preparation/FAILED capture and
controller failure;neither V1 nor V2 is a scientific PASS.

V3 restores only the existing ULD input basename at its explicitly owning
P path. New output/preparation/capture aliases become V3. Check the exact
semantic diff and existing prior input paths before launch;the original
ULD owning seal must still authenticate them. No schema,physics,coefficient,
normalization,acceptance requirement or scope changes. One bounded V3
pair under the SAME300s/role,600saggregate,8GiBsampled,350MiBfloor,
32MiBpacket limits. Repeated operational failures require this reassessment,
not a silent retry or relaxation. All old/new failures remain classified.
