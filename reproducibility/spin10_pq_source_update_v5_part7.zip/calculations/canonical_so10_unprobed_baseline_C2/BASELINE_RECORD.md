# UBC3-4: complete unweighted native image and late baseline test, prospective

UBC2 now qualifies the three complete marginal C2 tensors and28 fresh
full-action checks. Reuse old AAK/UAK heat2,IQC Lambda-x F2,ICR JaJLC
measured zero and IQC JaJa/Ja-x block zeros;USR complete JxCx is C3-only.
Retain explicit zero-premise ownership rather than inventing a coefficient.
Authenticate each old packed native hash,owning qualification flag and
input binding. Both native routes must collate ALL ten C2 root tensors,
including old coefficients and implicit zeros,so their whole comparison
also checks exact reuse without redoing old loop integrations.

Use actual UOR u flows,source differentiation before restriction and
all source-degree provenance. Primary owning-density odd prefixes vs
replay full canonical literal Leibniz,including EVEN Ja. C1 exclusion
and complete prior C3/C4 images reuse ULD's exact sealed tensors.
Native chi4 image is C2_image+C3_image+C4_image. No desired remainder,
unknown coefficient or value of chi4 is an operand. Guard old targets
and peer outputs. Two sequential300s jobs,aggregate600s afterimports.

Only AFTER whole native agreement and ten-root coverage may review decode
the original UPM homogeneous+Euler PARTIAL chi4 relation. UCT's complete
ordered cutoff is E^n-E^(n+1),n>=1,so its homogeneous finite coefficient
is log((n+1)/n)/(16pi^2),with no chi4. This carrier premise is inherited
from qualified UCT PROOF section radial homogeneity,not a claim about a
full continuum/IR amplitude. Add the native image ONCE to that chi4
partial;do not readd old C3/4 or source-lowering groups. Save every sum,
zero or nonzero,without fitting a baseline. Test missing C2,C3,C4 images
and each nonzero C2 group as controls,report true insensitivity explicitly.

Review180s,8GiBsampled,350MiBlaunchfloor,totalpacket32MiB. Freeze sources,
copies,inputs,captures before execution;preserve failures. Cancellation is
an outcome,not an execution acceptance condition. Ceiling is the complete
declared unweighted formal coefficient relation. Algebraic dimensional
terms,common continuum operation/products/reference/measure/source-reality/
globalphase/QAP/causal/physical applicability remain separate;no old38-class
theorem is imported as an automatic augmented-u proof. chi4,b0,kappa,IR
remain distinct and unselected. No scientific promotion or changed physics.
