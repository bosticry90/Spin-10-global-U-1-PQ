from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import defaultdict
import ast,gzip,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(R/'calculations/canonical_so10_unprobed_marginal_C3'))
from blocks import OP,co,decode,gf_primitive,Coeff,ZERO,constant,put,clean
O=Path(__file__).resolve().parent
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest()
for pp,h in read(O/'review_preparation.json')['input_sha256'].items():assert H(Path(pp))==h,pp
def unpack(rows):
    M={tuple(z[:-1]):Coeff([(tuple(k),Fraction(n,d)) for k,n,d in z[-1]]) for z in rows};assert len(M)==len(rows) and all(M.values());return M
ab=[]
for role in ['primary','replay']:
    pp=O/('kernel_'+role+'_tables.json.gz');assert H(pp)==read(O/('kernel_'+role+'_result.json'))['packed_sha256'];ab.append(loadz(pp))
assert ab[0]['results']==ab[1]['results'] and ab[0]['actual_path_sectors']==ab[1]['actual_path_sectors']
kernels={};counts=[]
for z in ab[0]['results']:
    M=unpack(z['total']);total={}
    for name,rows in z['groups'].items():
        G=unpack(rows);assert len(G)==z['group_nonzero_counts'][name]
        for k,v in G.items():put(total,k,v)
    assert clean(total)==M and len(M)==z['nonzero'] and len(M)+z['zero_complement']==z['domain_positions']
    assert z['domain_positions']==(45**3 if z['case']=='JaaC' else 45*45*990 if z['case']=='JLaCC' else 990**2)
    kernels[z['case']]=M;counts.append({k:v for k,v in z.items() if k not in ['total','groups']})
assert all(z['all_actual_marginal_C2_paths_are_ghost_only'] and z['Ja_mass_input_equal_separately_qualified_ICR'] and z['guard_denials']==3 and not z['old_baseline_remainder_read'] for z in ab)
assert all(ab[0]['sensitive_controls'].values())
d=loadz(R/'calculations/canonical_so10_u_maximal_heat_cutoff/primary_inputs.json.gz')
density=gf_primitive({i:decode(z) for i,z in d['GF_gradient']})
tree=ast.parse((R/'calculations/canonical_so10_u_F_fourth_support/operators.py').read_bytes())
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['hessian','source_density']]
def literal(raw,axis,q,selected,oddmask):
    V={};goal=sum(selected.values())
    for (i,j,w,nd,p),v in raw.items():
        if any(n for mu,n in enumerate(p) if mu!=axis):continue
        bits=[selected[k] for k in w];odds=[v for v in bits if v&oddmask]
        mask=sum(bits);sg=(-1)**sum(a>b for at,a in enumerate(odds) for b in odds[at+1:]);v=v*(sg*q**sum(p))
        if i<180:
            color,mu=divmod(i,4);fold=[(i,co('eta_H' if color<12 else 'xi') if mu==axis else constant(1))]
            if mu==axis:fold.append((508+color,constant(q)))
        elif i<508:fold=[(i,constant(1))]
        elif i<553:fold=[(4*(i-508)+axis,constant(-q))]
        elif i<598:fold=[(i+45,constant(-1))]
        else:fold=[(i-45,constant(1))]
        for r,f in fold:put(V,(r,j,mask),v*f)
    V=clean(V);by=defaultdict(list)
    for (i,j,m),v in V.items():by[i].append((j,m,v))
    value=ZERO
    for (i,j,m),v in V.items():
        for k,m2,w in by[j]:
            if i!=k or m&m2 or m|m2!=goal:continue
            sg=(-1)**sum(((m&oddmask)>>a&1)*((m2&oddmask)&((1<<a)-1)).bit_count() for a in range(4))
            value=value+(v*w)*(sg*((-1)**int(i>=553)))
    return value*constant(Fraction(-1,4))
contexts=[]
for case,M in kernels.items():
    keys=sorted(M)
    if keys:contexts.extend((case,keys[min(len(keys)-1,j*len(keys)//4)]) for j in range(4))
    contexts.extend([('JaaC',(0,0,0)),('JaaC',(12,12,12))] if case=='JaaC' else [('JLaCC',(0,0,0,1)),('JLaCC',(12,12,12,13))] if case=='JLaCC' else [('JLJLCC',(0,1,0,1)),('JLJLCC',(12,13,12,13))])
fresh=[]
for case,key in contexts:
    if case=='JaaC':s,r,h=key;selected={1241+s:1,598+r:2,553+h:4};oddmask=6
    else:
        r,s,h,k=key;selected={1151+r:1,(598+s if case=='JLaCC' else 1151+s):2,553+h:4,553+k:8};oddmask=15
    assert len(selected)==(3 if case=='JaaC' else 4)
    def allow(word,nd,low,high):
        if nd!=0 or not low<=len(word)<=high or any(js or i not in selected for i,js in word):return None
        ids=tuple(i for i,js in word)
        return ids if len(ids)==len(set(ids)) else None
    ns=dict(vars(OP));ns['allowed']=allow
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'UBC_FRESH_ORIGINAL_COMPLETE_HESSIANS','exec'),ns)
    raw=ns['hessian'](density,'primary',1,2)
    for kk,v in ns['hessian'](ns['source_density'](d),'primary',1,2).items():put(raw,kk,v)
    raw=clean(raw)
    for axis,q in [(3,1),(2,-1)]:
        value=literal(raw,axis,q,selected,oddmask);expected=kernels[case].get(key,ZERO)
        assert value==expected,(case,key,axis,q,str(value),str(expected))
        fresh.append({'case':case,'indices':list(key),'axis':axis,'q':q,'value':str(value),'full_action_quadratic_trace_equal':True})
        print('STAGE UBC2 '+json.dumps(fresh[-1],sort_keys=True),flush=True)
out={'schema':'UBC2_COMPLETE_C2_TENSORS_AND_FRESH_ACTION_REVIEW','whole_tensors_groups_and_implicit_zeros_equal':True,'counts':counts,'fresh_uncut_checks':fresh,
 'Ja_even_vs_other_odd_parities_retained':True,'old_baseline_or_full_QAP_claim':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({k:v for k,v in out.items() if k!='fresh_uncut_checks'},sort_keys=True),flush=True);timer.cancel()
