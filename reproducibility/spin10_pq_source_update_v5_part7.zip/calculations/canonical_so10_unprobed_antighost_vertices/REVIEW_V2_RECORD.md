# ACV2 V2: report-variable correction

Original review FAILED at final report construction:the loaded primary
table variable a was overwritten by a classical J0 antighost loop index.
It reached every full coefficient,Fourier,rotation,graded-orientation,
classical comparator,free-inverse and466-profile assertion first. That is
not a completed qualification;no original receipt/output exists. Preserve
original sources,copies,preparation,complete capture and controller failure.

Rename only the loaded native table variables to native_primary and
native_replay in verify_v2.py. No scientific input,formula,assertion,
normalization or limit changes. Reuse the native coefficient tables;
do not repeat those calculations. New review inputs bind the entire failed
review and original preparation. Same180s/8GiB/350MiB/32MiB limits. A new
receipt is allowed only on complete success. Scientific authority unchanged.
