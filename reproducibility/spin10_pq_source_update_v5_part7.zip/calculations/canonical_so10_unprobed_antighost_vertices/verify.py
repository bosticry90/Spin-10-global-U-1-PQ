from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict,Counter
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'review_preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
cp=Path(read(O/'inputs.json')['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient,constant,I as CI
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
def clean(D):return{k:v for k,v in D.items()if v}
def diff(A,B):return{k:A.get(k,0)-B.get(k,0)for k in set(A)|set(B)if A.get(k,0)!=B.get(k,0)}
def htab(rows):return{(i,ji,j,jj,tuple(ext)):co(v)for i,ji,j,jj,ext,v in rows}
def ftab(rows):return{(i,j,tuple(ext)):co(v)for i,j,ext,v in rows}
def kind(i):return'B'if i<180 else'x'if i<508 else'L'if i<553 else'C'if i<598 else'a'
def par(i):return int(i>=553)
a,b=[load(O/('vertices_'+role+'_tables.json.gz'))for role in['primary','replay']];assert a['field_order']==b['field_order'];TT={k:htab(v)for k,v in a['Hessian_groups'].items()};assert TT=={k:htab(v)for k,v in b['Hessian_groups'].items()}
for role in['primary','replay']:
 rr=read(O/('vertices_'+role+'_result.json'));p=O/('vertices_'+role+'_tables.json.gz');assert H(p)==rr['packed_sha256']and sha256(gzip.decompress(p.read_bytes())).hexdigest()==rr['raw_sha256']and rr['elapsed_after_imports']<300
for k,T in TT.items():
 for(i,ji,j,jj,ext),v in T.items():assert T.get((j,jj,i,ji,ext),0)==((-1)**(par(i)+par(j)+par(i)*par(j)))*v,('raw_reverse_orientation',k,i,j)
FF={};rotated=None
for z,zz in zip(a['Fourier_unit_axes'],b['Fourier_unit_axes']):
 assert(z['axis'],z['q'])==(zz['axis'],zz['q']);axis=z['axis'];q=z['q'];G={k:ftab(v)for k,v in z['groups'].items()};assert G=={k:ftab(v)for k,v in zz['groups'].items()}
 for k,T in TT.items():
  D=defaultdict(lambda:0)
  for(i,ji,j,jj,ext),v in T.items():
   if any(int(mu)!=axis for mu in ji+jj):continue
   phase=co(str((-s.I*q)**len(ji)*(s.I*q)**len(jj)));D[i,j,ext]+=phase*v
  assert clean(D)==G[k],('Fourier',axis,q,k)
 def rotate(i):
  if i>=180:return i
  mu=i%4;return i-mu+(3 if mu==axis else axis if mu==3 else mu)
 normalized={k:{(rotate(i),rotate(j),tuple(rotate(n)for n in ext)):v for(i,j,ext),v in D.items()}for k,D in G.items()}
 if q==1:
  if rotated is None:rotated=normalized
  else:assert rotated==normalized,('Euclidean_rotation',axis)
 FF[axis,q]=G
for axis in range(4):
 for k,D in FF[axis,1].items():
  R=FF[axis,-1][k]
  for(i,j,ext),v in D.items():assert R.get((j,i,ext),0)==((-1)**(par(i)+par(j)+par(i)*par(j)))*v
f=FF[3,1];cl=load(O/'review_classical_inputs.json.gz');dec=lambda z:{(i,j):co(v)for i,j,v in z['entries']};tab=lambda z:{tuple(q[:-1]):co(q[-1])for q in z}
J={};W={};N={};S={};Wn={};Z={};K={}
for(i,j,ext),v in f['J'].items():
 if i>=598 and(j<180 and j%4==3 or 508<=j<553):J[ext[0]-553,i-598,j//4 if j<180 else j-508+45]=v
for(i,j,ext),v in f['W'].items():
 if(j>=553 and j<598)and(i<180 and i%4==3 or 508<=i<553):W[ext[0]-598,j-553,i//4 if i<180 else i-508+45]=v
for(i,j,ext),v in f['N'].items():
 if 508<=i<553 and 180<=j<508:N[i-508,j-180]=v
for(i,j,ext),v in f['S'].items():
 if i>=598 and 553<=j<598:S[i-598,j-553,ext[0]-180]=v
for(i,j,ext),v in f['Wn'].items():
 if 180<=i<508 and 553<=j<598:Wn[ext[0]-598,j-553,i-180]=v
for(i,j,ext),v in f['Za'].items():
 if i>=598 and 553<=j<598:Z[ext[0]-598,ext[1]-553,i-598,j-553]=v
for(i,j,ext),v in f['KBB'].items():
 if i%4==3 and j%4==3:K[ext[0]-598,ext[1]-553,i//4,j//4]=v
oldJ={(h,a,j):v for h,M in enumerate(cl['J0'])for(a,j),v in dec(M).items()};oldN={(a-45,j):v for(a,j),v in dec(cl['N0']).items()};oldS=tab(cl['S0']);comparators={'J0':len(diff(J,oldJ)),'N0':len(diff(N,oldN)),'S0':len(diff(S,oldS))};assert not any(comparators.values()),('qualified_classical_chart_or_phase_mismatch',comparators)
free={};BL={}
for(i,j,ext),v in f['free_ghost'].items():
 if i>=598 and 553<=j<598:free[i-598,j-553]=v
for(i,j,ext),v in f['free_BL'].items():
 if i<180 and i%4==3 and 508<=j<553:BL[i//4,j-508]=v
assert free=={(i,i):constant(1)for i in range(45)}and BL=={(i,i):constant(1)for i in range(45)}
beta=tab(cl['beta']);width={i:v for(i,j),v in dec(cl['G0']).items()if i==j and i<45};Z0=tab(cl['Z0']);Wp={};Zp=defaultdict(lambda:0)
for(r,c,b),v in beta.items():Wp[r,c,b]=CI*v
for(h,a,j),v in oldJ.items():
 if j>=45:Wp[a,h,j]=v
for(r,h,A,c),v in Z0.items():
 Zp[r,h,A,c]+=CI*co('1/2')*width.get(r,0)*v
 Zp[A,h,r,c]+=-CI*co('1/2')*width.get(A,0)*v
hypotheses={'W_from_beta_and_Jaux':diff(W,Wp),'Wn_from_S0':diff(Wn,oldS),'Za_from_width_Z0':diff(Z,clean(Zp))}
cat=load(Path(read(O/'review_inputs.json')['catalog']));letters=cat['letters'];ww=next(q['ordered_words']for q in cat['results']if q['target']=='a_Cx');partition=Counter();seagull=[]
for n,q in enumerate(ww):
 keys=[]
 for ii in q['letters']:
  z=letters[ii];gr=z['grade'];ports=set(z['H_ports'])
  if gr==[0,0,1,1,0]and ports=={'B'}:keys.append('KBB')
  elif gr==[0,0,1,1,0]:keys.append('Za')
  elif gr==[0,0,1,0,0]:keys.append('W')
  elif gr==[0,0,0,1,0]:keys.append('J')
  elif gr==[1,0,1,0,0]:keys.append('Wn')
  elif gr==[1,0,0,1,0]:keys.append('Mn')
  elif gr==[1,0,0,0,1]:keys.append('S')
  elif gr==[1,0,0,0,0]:keys.append('N')
  elif gr==[0,0,0,0,1]:keys.append('X')
  else:raise AssertionError(('unclassified_actual_profile',n,z['id']))
 partition[','.join(sorted(keys))]+=1
 if 'KBB'in keys:seagull.append(n)
assert len(ww)==466 and sum(partition.values())==466 and K and Z and seagull
out={'schema':'ACV2_CLASSICAL_ANTIGHOST_VERTEX_QUALIFICATION','complete_Hessian_and_all8_Fourier_tables_agree':True,'all_four_Euclidean_axes_and_reverse_graded_orientations':True,'J0_N0_S0_classical_comparator_difference_positions':comparators,'free_ghost_and_BL_inverse_normalization_identity':True,'B_C_a_beta_C_L_identical_positions':a['nonminimal_map_positions'],'reduced_vertex_counts':{k:len(D)for k,D in[('J',J),('W',W),('Wn',Wn),('N',N),('S',S),('Za',Z),('KBB',K)]},'candidate_formula_difference_positions':{k:len(D)for k,D in hypotheses.items()},'candidate_formula_residuals':{k:[[*q,str(v)]for q,v in sorted(D.items())]for k,D in hypotheses.items()},'all466_profile_partition':dict(partition),'seagull_containing_profile_indices':seagull,'controls':{'drop_actual_seagull_changes_reduced_vertex_positions':len(K),'drop_actual_quartic_ghost_changes_reduced_vertex_positions':len(Z),'reverse_odd_orientation_without_sign_changes_full_positions':sum(par(i)or par(j)for T in TT.values()for i,ji,j,jj,ext in T),'omit_auxiliary_Wick_phase_changes_N_positions':len(N)},'quantum_aCx_or_QAP_or_Ward_restoration':False,'elapsed_after_imports':time.perf_counter()-tick};raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode()
with(O/'validation_tables.json.gz').open('xb')as f:f.write(gzip.compress(raw,mtime=0))
brief={k:v for k,v in out.items()if k not in['candidate_formula_residuals','seagull_containing_profile_indices']};brief['seagull_containing_profiles']=len(seagull);brief['packed_sha256']=H(O/'validation_tables.json.gz');brief['raw_sha256']=sha256(raw).hexdigest();print('RESULT '+json.dumps(brief,sort_keys=True),flush=True);timer.cancel()
