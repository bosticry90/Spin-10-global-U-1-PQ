# ACV1: action-derived ordinary antighost vertices

Prospective at a476cbca93b17b5d37aa5d7ef48899ce5458e12e,V636. Goal ACTIVE.
Live AGENTS,CHARTER,epistemic ladder,solo review and local conventions apply.
State113,authority34/39,E5/A5 OPEN,custodyexit2/seven NOTPASS unchanged.
No agents,branch/worktree,remote action,publication,physical input/scheme/
foundation adoption,flavor/HB1/C5 activation or protected promotion.

The remaining ordinary intrinsic aCx kernel has466 support profiles.
Before computing it,derive its actual quantum vertices from fullGF at A0,
with constant external antighost/ghost/scalar fields and intrinsicdegree1.
The catalogue already contains an aCBB Hessian not present in the first
tentative Schur formula. Determine its actual coefficient rather than
assuming that current or seagull vanishes. This is a classical prerequisite,
not a new quantum kernel or a cancellation inferred from a Ward remainder.

Same original unshifted SMA/CSW/EDS,Euclidean action S_E=-Wick(S_M),
auxiliary phase-i,B0 phase+i,each temporal derivative phase+i. All45 colors,
328 real scalars,symbolicg10/xi/eta_H. Actual inverse chart maps raw fields
to their physical expansions. Keep all four Lorentz components and jet
positions before Fourier selection. Internal row has momentum-q,column+q;
external jets are zero. No physical scalelessp0 or changed reference scheme.

Primary transports the raw density and then performs literal left graded
derivatives with the established Hessian sign. Replay differentiates raw
positions first,computes the Grassmann sign by crossing counts,then
transports the Hessian and residual mean fields. Compare full sparse
coefficient tables and implicit zeros after both outputs are completed.
Use canonical external order a then C for the even aC seagull/contact.

Extract ordinary ghost current J,constant-antighost W,scalar endpoint Wn,
intrinsic ghost mass S,mixed N,quartic-ghost aC contact Z,and aCBB seagull.
Also extract the free ghost inverse and vector/auxiliary normalization.
Finite Fourier tensors evaluated at q=+/-unit axes are classically
determined coefficients;they are not loop integrals. First compare raw
Lorentz-density/Hessian tables and then all orientations/implicit zeros.
After native derivation compare J,S,N with their separately qualified
classical inputs and audit B_C_a=beta_C_L without assumed index reversal.
Candidate compact W/Z formulas are hypotheses,not acceptance premises.

Expected outcomes: verified complete classical vertex list;identified
additional nonzero terms requiring a corrected loop formula;or explicit
chart/sign/domain mismatch. A nonzero seagull is not an anomaly. Failed
comparison must not be fitted to a quantum remainder. Deny earlier partial
Ward/cutoff tables and all model quantum coefficient outputs as operands.
Do not supply missing aCx from its negative remainder or choose chi4.

Sequential300s native/180s review afterimports,8GiB sampled private,
350MiB available-pagefile launch floor,32MiB retained packet. Freeze exact
inputs,sources,copies and hashes before running. Timer/resource exhaustion
is incomplete,not PASS. Preserve failures;new version for routine fixes.
Sensitive controls should omit an actual nonzero quartic ghost/seagull,
reverse an odd Hessian orientation,and omit a Euclidean auxiliary phase.
Record insensitive projections honestly. Shared action,charts,ring/runtime,
software and AI authorship limit independence;no physical validation.

Full aCx coefficient,source image,nonlinear master/QAP/products/measure,
causal/vacuum physical domains and all prior unresolved obligations remain
open. chi4,b0,kappa,IR freedoms distinct and unfixed. Next choose the
smallest complete ordered Gaussian/Schur reduction using these vertices.
