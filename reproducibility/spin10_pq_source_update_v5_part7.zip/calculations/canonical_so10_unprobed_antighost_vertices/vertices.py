from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict,Counter
from itertools import product
import json,gzip,sys,time,threading,os,sympy as s
O=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));role=sys.argv[1];assert role in['primary','replay'];tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'preparation.json')['input_sha256'].items():assert H(Path(p))==h,p
def guard(event,args):
 if event=='open'and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0]))
  if p.parent.resolve()==O and p.name.startswith('vertices_'+('replay'if role=='primary'else'primary')):raise PermissionError('ACV_PEER_DENIED')
  if p.parent.name in['canonical_so10_intrinsic_source_cutoff_remaining','canonical_so10_unprobed_auxiliary_source_kernel','canonical_so10_intrinsic_correlated_source_contacts']:raise PermissionError('ACV_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard);ip=read(O/'inputs.json');cp=Path(ip['coefficient_ring']);sys.path.insert(0,str(cp.parent));from coefficient_ring import coefficient,constant,I as CI,verify_basis_products
assert verify_basis_products()==1024
g,xi,eta=s.symbols('g10 xi eta_H',real=True);loc={'g10':g,'xi':xi,'eta_H':eta}
@lru_cache(None)
def co(z):return coefficient(s.expand(s.sympify(z,locals=loc)))
d=load(O/('vertices_'+role+'_inputs.json.gz'));xs=d['xs'];aux=[('b'if i<12 else'L')+str(i)for i in range(45)];cs=['C'+str(i)for i in range(45)];ants=[('bar'if i<12 else'ub')+str(i)for i in range(45)];phys=[f'B{i}_{mu}'for i in range(45)for mu in range(4)]+xs+aux+cs+ants;pi={n:i for i,n in enumerate(phys)};rawnames=d['frame']['field_order'];ri={n:i for i,n in enumerate(rawnames)}
def kind(i):return'B'if i<180 else'x'if i<508 else'L'if i<553 else'C'if i<598 else'a'
def parity(i):return int(i>=553)
by=defaultdict(list)
for i,j,z in d['frame']['physical_to_raw_inverse']['entries']:by[i].append((j,co(z)))
assert all(kind(j)==kind(pi[n])for n in phys for j,v in by[ri[n]])
@lru_cache(None)
def canonical(w,external=False):
 key=lambda t:({'a':0,'C':1}.get(kind(t[0]),2),t)if external else(t[0],t[1])
 odd=[t for t in w if parity(t[0])]
 if len(set(odd))!=len(odd):return (),0
 sg=(-1)**sum(key(a)>key(b)for at,a in enumerate(odd)for b in odd[at+1:]);return tuple(sorted(w,key=key)),sg
def cls(w,i,j):
 if any(jets for n,jets in w):return None
 kk=sorted(kind(n)for n,jets in w);ij=(kind(i),kind(j))
 if not kk:
  if set(ij)=={'a','C'}:return'free_ghost'
  if set(ij)=={'B','L'}:return'free_BL'
  if ij==('L','L'):return'free_LL'
  if set(ij)=={'L','x'}:return'N'
 if kk==['C']and set(ij)in[{'a','B'},{'a','L'}]:return'J'
 if kk==['a']and set(ij)in[{'B','C'},{'L','C'}]:return'W'
 if kk==['a']and set(ij)=={'x','C'}:return'Wn'
 if kk==['x']and set(ij)=={'a','C'}:return'S'
 if kk==['C','a']and set(ij)=={'a','C'}:return'Za'
 if kk==['C','a']and ij==('B','B'):return'KBB'
 return None
def wick(w):
 z=constant(-1)
 for i,jets in w:
  if kind(i)=='L':z=z*(-CI)
  if kind(i)=='B'and i%4==0:z=z*CI
  for a in jets:
   if a=='0':z=z*CI
 return z
def clean(D):return{k:v for k,v in D.items()if v}
raw=[];discard=Counter()
for row in d['GF']:
 w=[]
 for token in row['word']:
  n,sep,jets=token.partition('__')
  if n not in pi:discard['background_or_other']+=1;break
  w.append((pi[n],jets))
 else:raw.append((tuple(w),co(row['coefficient'])))
def choices(w):return[[(j,jets,z)for j,z in by[ri[phys[i]]]]for i,jets in w]
tables=defaultdict(lambda:defaultdict(lambda:0));raw_class_count=Counter();physical_density_count=None
if role=='primary':
 density=defaultdict(lambda:0)
 for w,v in raw:
  phase=wick(w)
  for chosen in product(*choices(w)):
   ww=tuple((j,jets)for j,jets,z in chosen);cw,sg=canonical(ww)
   if sg:
    fac=v*phase*sg
    for j,jets,z in chosen:fac=fac*z
    density[cw]+=fac
 density=clean(density);physical_density_count=len(density)
 for w,v in density.items():
  for at,(i,ji)in enumerate(w):
   sg=(-1)**(parity(i)*sum(parity(n)for n,jets in w[:at]));ww=w[:at]+w[at+1:]
   for pos,(j,jj)in enumerate(ww):
    zz=ww[:pos]+ww[pos+1:];group=cls(zz,i,j)
    if group is None:continue
    ext,esg=canonical(zz,True);tg=(-1)**(parity(j)*sum(parity(n)for n,jets in ww[:pos])+parity(j)*(parity(i)+1))
    tables[group][i,ji,j,jj,tuple(n for n,jets in ext)]+=v*sg*tg*esg
else:
 rawH=defaultdict(lambda:defaultdict(lambda:0))
 for w,v in raw:
  for at,(i,ji)in enumerate(w):
   for pos,(j,jj)in enumerate(w):
    if at==pos:continue
    zz=tuple(t for k,t in enumerate(w)if k not in[at,pos]);group=cls(zz,i,j)
    if group is None:continue
    crossings=parity(i)*sum(parity(n)for n,jets in w[:at])+parity(j)*(sum(parity(n)for n,jets in w[:pos])-parity(i)*int(at<pos))+parity(j)*(parity(i)+1)
    rawH[group][i,ji,j,jj,zz]+=v*((-1)**crossings)*wick(w)
 for group,DD in rawH.items():
  raw_class_count[group]=len(clean(DD))
  for(i,ji,j,jj,zz),v in clean(DD).items():
   slots=((i,ji),(j,jj))+zz
   for chosen in product(*choices(slots)):
    (a,ja,va),(b,jb,vb),*rest=chosen;cw,sg=canonical(tuple((c,jc)for c,jc,vc in rest),True)
    if sg:
     fac=v*va*vb*sg
     for c,jc,vc in rest:fac=fac*vc
     tables[group][a,ja,b,jb,tuple(c for c,jc in cw)]+=fac
tables={k:clean(v)for k,v in tables.items()};assert set(tables)=={'free_ghost','free_BL','free_LL','N','J','W','Wn','S','Za','KBB'}
def fourier(axis,q):
 out={}
 for group,D in tables.items():
  T=defaultdict(lambda:0)
  for(i,ji,j,jj,ext),v in D.items():
   if any(int(a)!=axis for a in ji+jj):continue
   z=v
   for a in ji:z=z*(-CI*q)
   for a in jj:z=z*(CI*q)
   T[i,j,ext]+=z
  out[group]=clean(T)
 return out
enc=lambda D:[[i,ji,j,jj,list(ext),str(v)]for(i,ji,j,jj,ext),v in sorted(D.items())]
fenc=lambda D:[[i,j,list(ext),str(v)]for(i,j,ext),v in sorted(D.items())]
F=[{'axis':axis,'q':q,'groups':{k:fenc(D)for k,D in fourier(axis,q).items()}}for axis in range(4)for q in[1,-1]]
B={tuple(r[:-1]):co(r[-1])for r in d['maps']['B_C_a']};beta={tuple(r[:-1]):co(r[-1])for r in d['maps']['beta_C_L']};assert B==beta
out={'schema':'ACV1_ACTION_DERIVED_CLASSICAL_ANTIGHOST_HESSIAN_VERTICES','role':role,'field_order':phys,'Hessian_groups':{k:enc(v)for k,v in tables.items()},'Fourier_unit_axes':F,'B_C_a_equals_beta_C_L':True,'nonminimal_map_positions':len(B),'raw_GF_rows_at_A0':len(raw),'raw_Hessian_counts':dict(raw_class_count),'physical_density_count':physical_density_count,'unknown_quantum_aCx_or_Ward_not_operand':True,'new_quantum_coefficient_or_QAP_claim':False};rawbytes=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(rawbytes,mtime=0)
with(O/('vertices_'+role+'_tables.json.gz')).open('xb')as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(rawbytes).hexdigest(),'Hessian_group_nonzero':{k:len(v)for k,v in tables.items()},'B_equals_beta_positions':len(B),'aCBB_seagull_actual_nonzero':bool(tables['KBB']),'quantum_kernel_measured':False},sort_keys=True),flush=True);timer.cancel()
