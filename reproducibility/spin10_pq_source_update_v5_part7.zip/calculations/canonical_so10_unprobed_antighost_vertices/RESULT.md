# The last ordinary kernel needs six interaction families

PROGRESS. The actual gauge-fixing action supplies a complete classical
vertex list for the unmeasured intrinsic antighost--ghost--scalar kernel.
Its466 ordered profiles partition into six families. Eighteen involve
a nonzero antighost--ghost--two-vector Hessian that the first tentative
loop formula omitted. Two proposed compact vertex identities also fail.
The action-derived tables,not those proposals,are the next loop inputs.

This is a classical prerequisite. No new aCx loop coefficient,source Ward
restoration,QAP,anomaly or physical viability claim is made. Goal remains
ACTIVE/INCOMPLETE. State113,authority34/39,E5/A5 OPEN,custodyexit2/seven
NOTPASS unchanged. No scheme,foundation,benchmark or normalization adopted.

## Complete action-derived inputs

Primary transports the full raw density into physical Euclidean fields
before left graded differentiation. Replay differentiates raw positions
first,computes crossing signs and then transports the Hessian and residual
mean fields. Both retain every Lorentz component and internal jet position.
Their complete coefficient tables agree,including implicit zeros.
Independent Fourier evaluation agrees at both signed unit momenta on all
four axes. Euclidean rotations and reverse graded Hessian signs pass.

The free ghost and vector--auxiliary normalizations are identities. The
actual J0,N0,S0 tensors agree exactly with separately qualified classical
inputs. The full B_C_a and beta_C_L maps agree at334 nonzero positions;
there is no assumed index reversal. Reuse of those aligned charts and
classical inputs is explicit,not a new representation reconstruction.

Reduced longitudinal vertex counts are:

| Vertex | Nonzero positions |
| --- | ---: |
| Ordinary ghost current J | 1,940 |
| Constant-antighost current W | 934 |
| Intrinsic scalar endpoint Wn | 6,268 |
| Mixed auxiliary--scalar N | 296 |
| Intrinsic scalar ghost mass S | 6,268 |
| Quartic ghost contact Za | 13,248 |
| Antighost--ghost--two-vector KBB | 25,902 |

The full Lorentz/jet KBB table contains103608 entries. These are algebraic
representations,not numbers of physical particles or independent tests.
All full tables and implicit-zero domains are preserved. Negative-control
counts concern classical tensors:omitting KBB or Za changes25902/13248
reduced positions,incorrect odd reversal affects78408 full positions,
and omitting the auxiliary Wick phase changes296 N positions. These are
algebraic omission/orientation diagnostics,not trial quantum amplitudes.

## Failed proposals are distinct from the verified action

The tentative W-from-beta-and-auxiliary-current formula differs at668
positions. The tentative Za-from-width-and-Z0 formula differs at12384.
Their exact residual tensors are retained in validation_tables_v2.json.gz.
Wn=S0 passes. None of the failed compact formulas is adopted,sign-fitted
to the partial Ward relation or used as a quantum coefficient.

The same review establishes the six-family partition:

| Vertex content | Ordered profiles |
| --- | ---: |
| S,Za | 4 |
| J,S,W | 48 |
| J,Wn,X | 54 |
| Mn,W,X | 54 |
| KBB,N,X | 18 |
| J,N,W,X | 288 |
| Total | 466 |

X is the scalar kinetic derivative Hessian. Mn is the external-ghost
intrinsic scalar endpoint. Each profile retains its original port and
derivative structure in the authenticated USR catalogue. This partition
does not assert that every allowed contraction is nonzero after color
summation or establish its loop normalization.

## Verification failure and limits

Both native routes completed:126.7340s and225.1504s afterimports. Original
review FAILED only when constructing its final report:the variable a for
the loaded primary table had been overwritten by a J0 index. All earlier
assertions had executed,but that run has no qualification receipt/output.
Original source,copy,preparation,complete capture and controller failure
remain unchanged. V2 only renames the loaded table variables,retains every
input and scientific assertion,and completes in62.6468s. No native vertex
calculation was repeated. This repeats a preventable report-variable
failure pattern;it is a workflow weakness,not a physics discrepancy.

Bounds remain300s native/180s review,8GiB sampled private,350MiB available-
pagefile launch floor,32MiB packet. Complete process/resource captures and
immutable preparations are retained. Shared action,charts,exact ring,
Python/SymPy,software and AI authorship limit independence. No proof
assistant,external scientist or independent physical validation is claimed.

## Next actual calculation

Derive and verify the complete ordered Gaussian/Schur loop formula from
these vertices. Retain W's vector and auxiliary components,Wn,Za and the
KBB bosonic determinant contribution. Neither NGW=0 nor the source-only
auxiliary-current simplification from JL Cx transfers automatically to W.
The two failed compact formulas cannot be used as replacements for the
actual tensors. Establish longitudinal pins or retain dimensional finite
terms before measuring full model coefficients.

Then measure/replay aCx independently of the partial Ward remainder,
derive its rhoJL source image from the actual source-quadratic generator,
and assemble exactly once. Do not assign aCx from the negative remainder
or fit chi4. The prior JL Cx kernel is already measured in a476cbca;its
transport leaves a nonzero partial relation and this one ordinary kernel
unmeasured. That remains the current scientific status.

Original unshifted SMA/CSW/EDS,A0,intrinsicdegree1,zero external jets and
symbolicg10/xi/eta_H remain. The subsequent loop target is the same
Euclidean nonexceptional LOCAL RELATIVE symbol,not physical scalelessp0,
absolute products or a massive/causal vacuum amplitude. chi4,b0,kappa,IR
freedoms stay distinct/unfixed. Full nonlinear master applicability,
continuum products,chiral QAP/measure/global phase,source reality,
physical domains and other outstanding obligations remain open. No flavor,
HB1/C5 activation,remote action,publication or protected promotion.
