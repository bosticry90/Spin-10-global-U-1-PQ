# ACV2: classical vertex qualification

Prospective before reading completed native tables. Authenticate frozen
sources,inputs and complete captures. Require both distinct transport/
derivative orders to agree coefficientwise,including all Lorentz/jet
entries and implicit zeros. Independently Fourier-evaluate the raw jet
tables at all8 signed unit axes and check rotational covariance after
field-index transport. Check graded reverse Hessian orientations.

Read the qualified J0,S0,N0 classical comparator only after both native
derivations. Require equality in their exact conventions before crediting
the old operands as usable with these vertices. Check free ghost and BL
normalization explicitly. Compare tentative compact W/Wn/Za formulas as
hypotheses:record any nonzero residual and its exact tensor,without fitting
a sign or declaring the hypothesis qualified. Actual density coefficients
take precedence. Verify nonzero aCBB and quartic ghost terms with sensitive
omission controls,plus odd orientation and auxiliary-phase errors.

Build a complete profile partition for all466 actual ordered words using
the qualified USR catalogue. Identify every seagull-containing profile;
do not discard it from a tentative Schur formula. This partition is a
support/vertex result,not its quantum contraction or evidence of anomaly.

Review180s afterimports,8GiB sampled private,350MiB available-pagefile
launch floor,32MiB packet. Preserve failures/unfinished captures. No old
partial Ward or cutoff remainder operand,no fitted chi4 or aCx kernel.
Scientific authority stays34/39,E5/A5 OPEN,custodyexit2/seven NOTPASS.
Shared data/action/charts/software/AI authorship remain explicit limits.
