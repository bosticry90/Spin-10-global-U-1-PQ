from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
from itertools import permutations
import json,gzip,sys,time,threading,os,ast
import sympy as s
O=Path(__file__).resolve().parent;R=O.parents[1]
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'))
from jets import decode,Coeff,ZERO,I,times,constant
from coefficient_ring import coefficient,g,xi,eta
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
read=lambda p:json.loads(p.read_bytes())
for p,h in read(O/'review_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
@lru_cache(None)
def co(z):return coefficient(s.sympify(z,locals={'g10':g,'xi':xi,'eta_H':eta}))
p,r=(read(O/(role+'_result.json')) for role in ['primary','replay'])
assert len(p['results'])==len(r['results'])==4
for a,b in zip(p['results'],r['results']):assert {k:v for k,v in a.items() if k!='ordinary_trace_control_coefficient'}==b
data=load(O/'primary_inputs.json.gz');gradient={i:decode(z) for i,z in data['GF_gradient']}
N={};J=[{} for _ in range(45)]
for out,poly in gradient.items():
    if 508<=out<553:
        for w,c in poly.items():
            if len(w)==1 and 180<=w[0][0]<508 and not w[0][1]:N[45+out-508,w[0][0]-180]=c
    if 598<=out<643:
        for w,c in poly.items():
            if len(w)!=2:continue
            for at,(i,js) in enumerate(w):
                if not(553<=i<598) or js:continue
                inn,jj=w[1-at]
                b=inn//4 if inn<180 and inn%4==3 else 45+inn-508 if 508<=inn<553 else None
                if b is None or any(mu!=3 for mu in jj):continue
                value=c
                for mu in jj:value=times(value,I)
                key=(out-598,b);J[i-553][key]=J[i-553].get(key,ZERO)+value
N={k:v for k,v in N.items() if v};J=[{k:v for k,v in j.items() if v} for j in J]
expectedN={(i,j):co(v) for i,j,v in data['N0']['entries']};expectedJ=[{(i,j):co(v) for i,j,v in j['entries']} for j in data['J0']]
n_difference={k:N.get(k,ZERO)-expectedN.get(k,ZERO) for k in N.keys()|expectedN.keys()};n_difference={k:v for k,v in n_difference.items() if v}
j_difference=[]
for h in range(45):
    z={k:J[h].get(k,ZERO)-expectedJ[h].get(k,ZERO) for k in J[h].keys()|expectedJ[h].keys()};j_difference.append({k:v for k,v in z.items() if v})
sourceB={};sourceBeta={}
for w,value in data['source_action']:
    c=co(value)
    if len(w)==3 and 45<=w[0]<90 and 135<=w[1]<180 and 180<=w[2]<225:sourceB[w[0]-45,w[1]-135,w[2]-180]=-c
    if len(w)==3 and 0<=w[0]<45 and 135<=w[1]<180 and 225<=w[2]<270:sourceBeta[w[0],w[1]-135,w[2]-225]=c
expectedB={tuple(row[:-1]):co(row[-1]) for row in data['B']};expectedBeta={tuple(row[:-1]):co(row[-1]) for row in data['beta']}
source_ok=sourceB==expectedB and sourceBeta==expectedBeta

# Verify the actual sign helper against literal sorted Grassmann words.
tree=ast.parse((O/'native.py').read_bytes());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='sign')
ns={'lru_cache':lru_cache};exec(compile(ast.Module(body=[node],type_ignores=[]),'UMH_SIGN','exec'),ns)
products=0
for bits,odd in [(6,1|8),(7,1|4|8|16)]:
    for a in range(1<<bits):
        for b in range(1<<bits):
            if a&b:continue
            aa=[i for i in range(bits) if a&odd&(1<<i)];bb=[i for i in range(bits) if b&odd&(1<<i)]
            sign=(-1)**sum(x>y for x in aa for y in bb)
            assert ns['sign'](a,b,odd)==sign;products+=1

word_counts={'T4':sum(len(list(permutations(z))) for z in [('n','J','C','x'),('u','n','J','x'),('u','n','J','C')]),
             'F5':4*len(list(permutations(('n','J','C1','C2','x')))),
             'T5_free_root':len(list(permutations(('u','n','J','C','x')))),
             'F6_free_root':len(list(permutations(('u','n','J','C1','C2','x'))))}
assert word_counts=={'T4':72,'F5':480,'T5_free_root':120,'F6_free_root':720}
print('STAGE operand_audit '+json.dumps({'N_difference':len(n_difference),'J_differences':sum(len(z) for z in j_difference),'source_tensors_equal':source_ok}),flush=True)

# Preserve operand audit before any optional late quantum interpretation.
operand_ok=not n_difference and not any(j_difference) and source_ok
late=[]
if operand_ok:
    old=load(R/'calculations/canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz')
    for probe in range(2):
        row=next(q for q in old['results'][probe]['partial_relations'] if q['basis']=='log5')
        T={tuple(v[:-1]):co(v[-1]) for v in row['homogeneous_plus_Euler_partial']['T']}
        conversion=T.get((13,0,137),ZERO);cutoff=co(next(q['coefficient'] for q in p['results'] if q['case']=='T' and q['probe']==probe))
        late.append({'probe':probe,'relative_T_log5':str(conversion),'direct_cutoff_T_log5':str(cutoff),'sum':str(conversion+cutoff),'cancellation':not(conversion+cutoff)})
result={'schema':'UMH2_ACTION_OPERAND_AND_LATE_REVIEW','native_full_group_comparison':True,'operand_audit_passed':operand_ok,
        'N_actual_vs_operand_changed_entries':len(n_difference),'J_actual_vs_operand_changed_entries':sum(len(z) for z in j_difference),
        'source_action_B_beta_match':source_ok,'nonoverlapping_squarefree_products_checked':products,'formal_ordered_word_counts':word_counts,'late_T_comparison':late,
        'ordinary_trace_control_insensitive':all(co(q.get('ordinary_trace_control_coefficient',q['coefficient']))==co(q['coefficient']) for q in p['results']),
        'F5_not_full_F_log5':True,'full_Ward_QAP_or_continuum_trace_claim':False,'elapsed_after_imports':time.perf_counter()-tick,
        'N_difference_witness':[[*k,str(v)] for k,v in list(sorted(n_difference.items()))[:3]],
        'J_difference_witness':[[h,*k,str(v)] for h,z in enumerate(j_difference) for k,v in list(sorted(z.items()))[:1]][:3]}
with (O/'review_result.json').open('xb') as f:f.write((json.dumps(result,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(result,sort_keys=True),flush=True);timer.cancel()
