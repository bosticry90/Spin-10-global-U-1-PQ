# Complete local u cutoff expression at the retained log5 targets

Use the finite source-Hessian construction qualified in UWB/FJB:

 C_n^u=(-1)^n STr[(G0 V0)^n M_u
       +sum_j (G0 V0)^j G0 H_u (G0 V0)^(n-1-j) M0].

The original complete free tangent M_f preserves the fixed Gaussian
pairing. Differentiating SMP's arbitrary-even-Hessian identity removes
the ENTIRE H_u insertion sum with M_f, at each coefficient/order. This
does not license deletion of M_u. The remaining targets have positive
grades T=(u,n,Ja,C,x), total5, and F=(u,n,JL,C,C,x), total6. Each nonfree
V0 consumes positive grade; H_u/M_u each consume u. Thus T has at most4
edges and F at most5 after the complete free-root cancellation.

The maximal families use free M_u or free H_u with M_C/M_x. T4 has72
ordered words. F5 has480 with the two ghosts kept distinct. Original
free-root normalization groups at T5/F6 have120/720 words. All actual
permutations and external signs are retained by the graded matrix ring.

## Fourth-edge terms beyond the maximal F family

At F4 the extra grade permits V_nx,V_nC from intrinsic ghost/scalar
couplings, V_CC from quartic ghosts, V_JC from the nonlinear source
action, intrinsic/ghost/source-dependent M_u and H_u, and M_CC from the
original nonlinear auxiliary rule. The general builder includes these
before coefficient extraction. It uses the full qualified GF Euler
columns, actual source action and QG, not a desired Ward remainder.

For H_u, primary takes an ordered left field derivative then a right
field derivative, retaining Fourier factors (-iq)^I(iq)^J. Replay
polarizes the full density into opposite modes and converts the literal
exterior word into the Gaussian row pairing. For M_u, primary uses
(-1)^p Euler_J QG and replay uses -rightEuler_J QG, then independent
right-derivative versus literal single-mode coefficient extraction.
Sources are differentiated before restriction. Both full source Euler
maps agree; the resulting selected Hessian/tangent matrices agree at
all four independent axes, including zeros. The new non-free vector
entries are linear p_mu; the free BB block's full p_mu p_nu shape was
checked before choosing an axis.

The unshifted physical scalar-current vertex is fixed independently by
q x=R_C x and D_mu x=partial_mu x-B_mu R x. Its Hessian is -iq R in the
B-to-scalar direction and +iq R in reverse. Other physical seagulls
have forbidden external B or too many x/n grades. A scalar-potential
V_nx is scalar-scalar and consumes BOTH n,x. It then has no remaining
scalar-to-ghost/source transition in an allowed four-edge cycle:
M_x or V_x would duplicate x, and M_u,n/H_u,n or V_n would duplicate n.
All other remaining ports are non-scalar. Fermion V_x is an isolated
ff component and cannot join the required ghost/source cycle. These
are support exclusions under the original unshifted reference, not
statements about massive or shifted-vacuum amplitudes.

## Actual source2 cutoff exclusion, and its strict scope

The FULL source2 QG scan gives only JaJa (12/33 terms for probes0/1)
and JLJLCC (1672 terms for probe1), with no jets. JaJa has no field
tangent/Hessian. JLJLCC's field Hessian retains two sources, whereas
the targets have one. After source differentiation and one field
derivative its tangent coefficient contains JL*C. With u this consumes
at least3 grades; four further positive V grades would require at least7,
beyond either target. Thus CLASSICAL source2 cutoff roots cannot enter
the retained log5 coefficients. This is a support/grade theorem, not
inference from a zero witness. It does NOT remove quantum source2
contact Euler images on the conversion side or settle their renormalized
definition. Those already measured terms remain in the late comparison.

The complete GF-aaCC and source-D support scans also show their relevant
ghost pairs are both broken directions. The selected F ghost0 is
unbroken; its omission controls for these blocks are therefore
insensitive. Neither block is globally zero in the full F problem.

## Formal-symbol domain versus the unproved full trace limit

Each allowed cycle must visit the nonminimal ghost/source sector.
Vector/nonvector transitions have p_mu pins; the free H_u,BB block is
p_mu p_nu. Diagonal roots preserve that longitudinal subspace. There
is no separate transverse closed vector loop carrying this target.
No hidden Lorentz spectator or dimensional finite jet is inferred away
by sampling. Actual operator matrices agree for all four axes, and
the complete selected traces agree on independent axes and q signs.

Engineering homogeneity gives a p^-4 leading local coefficient. Keep
the actual positive-heat difference E^n-E^(n+1), E=exp(-2t p^2). It
supplies a p^2 zero at the origin and UV exponential decay. Therefore
the LOCAL coefficient integral exists and equals

 integral d^4p/(2pi)^4 (E^n-E^(n+1))/p^4
       =log((n+1)/n)/(16pi^2).

This reuses RSH's already qualified radial calculation for n4/5. It
defines a bounded formal cutoff symbol; it is not a proof of the full
nonexceptional amplitude, common continuum variation/trace limit,
connected-product subtraction, quantum measure or QAP.

Hence [log5]cutoff_T=C4_T and [log5]cutoff_F=C4_F-C5_F. The selected
C5_F is measured zero AFTER inclusion, not assumed zero globally.
The owning relative-conversion convention compares conversion+cutoff
with zero. It does not equate a relative conversion with the bare heat
effective action. All late comparisons follow that fixed convention.
