from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/u-maximal-heat-cutoff-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings={str(R/p):h for p,h in json.loads((O/'inputs.json').read_bytes())['input_sha256'].items()}
    for p,h in bindings.items():assert H(Path(p))==h,p
    for name in ['.gitattributes','inputs.json','RECORD.md','native.py','run.py','primary_inputs.json.gz','replay_inputs.json.gz']:
        p=O/name
        if p.suffix=='.py':ast.parse(p.read_bytes())
        if p.suffix!='.gz':
            with (O/(name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
        bindings[str(p)]=H(p)
    for path in ['calculations/canonical_so10_intrinsic_source_cutoff_defect/final_review_validation_receipt.json','calculations/canonical_so10_intrinsic_source_cutoff_defect/support_validation_receipt.json','calculations/canonical_so10_unprobed_source_root_module/heat_support_validation_receipt.json']:
        bindings[str(R/path)]=H(R/path)
    dump(O/'preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    for role in ['primary','replay']:
        result=capture([sys.executable,'-B',str(O/'native.py'),role])
        dump(O/(role+'_capture.json'),result);dump(C/(role+'_full_capture.json'),result)
        assert result['exit_code']==0 and result['calculation_completed'] and result['post_run_observations_qualified']
        assert json.loads((O/(role+'_result.json')).read_bytes())['elapsed_after_imports']<300
        assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<32*1024**2
        print('COMPLETED UMH1 '+role,flush=True)
except BaseException:
    dump(O/'controller_failure.json',{'execution_state':'FAILED','traceback':traceback.format_exc(),'failure_relabelled_PASS':False})
    raise
