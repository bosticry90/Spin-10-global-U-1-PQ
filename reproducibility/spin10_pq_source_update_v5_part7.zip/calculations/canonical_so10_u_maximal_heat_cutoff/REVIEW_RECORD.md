# UMH2: action-operand audit and late relative-conversion comparison

Prospective after both UMH1 natives completed. Compare all common output
fields/root groups and zero checks,not only the final selected value.
Check input G0/N0/J0/R bindings against their qualified receipts. Freshly
derive N0 and ALL45 J0 from FJB's full GF Euler columns. Independently
extract Ja C a and JL C Lambda from the qualified source action and
compare their B/beta tensors. Recover the scalar-current sign from
D_mu x=partial_mu x-B_mu R x. A shared operand/sign error is a failed
scientific applicability check even if the two traces agree.

Verify even-u/even-Ja versus odd-JL/ghost ordering by literal exterior
word sorting for every squarefree product. Count formal permutations for
complete maximal-edge families. Confirm original free-root sum zero,
while classifying actual selected endpoint omissions,ordinary trace and
scalar rotations as sensitive or insensitive according to their values.
Do not call every omission a detected error.

Only after native agreement and this operand audit, read authenticated
UPM partial T/F log5. The owning RSH convention compares the RELATIVE
conversion plus cutoff coefficient with zero; it does not identify the
relative conversion with the unrenormalized heat effective action.
Record both signs and their sum explicitly. Do not fit a coefficient.
F C5 is not a complete F log5 coefficient and must not be added to that
remainder as if C4_F were known.

The full first/multiple-variation/contact trace limit stays separate from
the finite positive-heat local symbol defined here. Radial integration
reuses the already qualified n4/n5 heat-pair formula; no new high-precision
integral or physical p0 amplitude is claimed. Review180s/8GiB/350MiB/
32MiB. Freeze sources and additional receipt/late-input hashes first.
