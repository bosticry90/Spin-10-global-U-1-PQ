# Two selected log5 remainders are accounted for by direct regulator calculations

Both retained witness channels now have independently calculated u cutoff
coefficients that cancel their previously measured relative-conversion
log5 terms. No coefficient or finite normalization was fitted. This is
selected formal-symbol evidence, not a complete tensor, full finite Ward
identity or E5/A5 theorem.

In common hbar/(16pi^2) units, with symbolic parameters:

| Channel, probe1 | Relative conversion | Direct cutoff | Sum |
| --- | --- | --- | --- |
| T:Ja13 C0 x137 | -sqrt(6) eta_H g10^4 xi/16 | +sqrt(6) eta_H g10^4 xi/16 |0|
| F:JL13 C0 C12 x136 | -3i sqrt(15) eta_H g10^5 xi/80 | +3i sqrt(15) eta_H g10^5 xi/80 |0|

Probe0 is zero on both sides in both channels. T's cutoff is C4; F's is
C4-C5, with selected C5 measured zero. That zero is not a global F5
theorem. chi4/log2/log3 and the rest of each tensor are not settled here.
The imaginary coordinate coefficient is not a physical source-reality result.

## What was calculated and checked

UMH1 constructs complete maximal-heat families from the actual classical
QG,original Hessians and field tangents:72 T4 words and480 F5 words with
separate ghost labels. It retains120/720 original-free-root words at
T5/F6 as normalization checks. The two original free endpoints cancel
only together. At the nonzero T witness they contribute equal and
opposite sqrt(6) eta_H g10^4 xi/16 at edge5. The actual u free root supplies
the nonzero edge4 term. Original scalar rotation groups are zero as
expected; ordinary-trace omission is INSENSITIVE at these maximal witnesses.

UMH2 freshly reconstructs ALL45 original ghost vertices J0 and the
intrinsic N0 from FJB's full GF Euler columns:zero changed entries.
It independently checks the source B/beta tensors against the source
action and verifies2916 nonoverlapping exterior products with the correct
even-u/even-Ja versus odd-JL/ghost ordering. Radial n4/5 integration is
authenticated/reused, not a new high-precision integral calculation.

UMH3 then includes all extra fourth-edge terms, with full source
variation before restriction. Primary uses left source Euler and ordered
quantum derivatives; replay uses minus right-source Euler and literal
two-mode polarization. They use different axes and both q orientations.
Unrooted powers and tangent-rooted propagation agree on every selected
coefficient,root group and omission control. UMH4 also compares the FULL
selected classical operator matrices and their zero complement at all four
axes, plus the complete left/right source Euler maps:80 matrix checks,
50256 nonzero entry comparisons. Counts measure coverage, not physical truth.

The F witness demonstrates why individual contributions remain:

| Fourth-edge root family | Contribution, in i sqrt(15) eta_H g10^5 xi units |
| --- | ---: |
| Original ghost-dependent tangent with H_u | -1/40 |
| Free u tangent | +3/80 |
| Intrinsic u scalar tangent | +1/40 |
| Total | +3/80 |

Omitting all H_u changes this coefficient by -1/40; omitting all M_u
changes it by +1/16 in those units. The source2,quartic-ghost and source-D
omissions are insensitive in this witness and are not called detected errors.

The full source2 QG scan gives only JaJa and JLJLCC. After the actual
source/field derivatives, their source support or positive grade excludes
them from these fourth/fifth-edge cutoff coefficients globally within
the retained quotient. Quantum source2 CONTACT Euler images remain on
the conversion side and were included. The full GF/source-D support
scan explains the other insensitive controls:their relevant ghost pairs
are both broken, while the selected F ghost0 is unbroken. Those blocks
must remain for other F coefficients.

## Focused result-to-claim assessment

**Supported inference.** The two selected prime-logarithm remainders have
an explicit regulator explanation from action-derived ordered loops.
FJB's non-preserving u tangent supplies an indispensable term. This
strengthens the mathematical bridge; a nonzero intermediate conversion
is not an anomaly verdict.

**Missing bridge and alternatives.** The full T/F color tensors,other
finite basis coefficients and full quantum identity are unproved. The
positive-heat local radial domain is defined here, but the complete
common trace-limit/variation/product and contact-normalization framework
is not established by a local coefficient calculation. Both-broken-ghost
F sectors still need coefficient verification. Unknown terms are not set
zero. Normalization and infrared freedoms remain distinct and unfixed.

**Significance and AI limits.** Direct ordered calculation,independent
source/Hessian methods,actual action-operand matching and explicit
insensitive controls test different errors. They share the action,
coordinate charts,exact ring,sparse helpers and AI author; no external
scientist,proof assistant or empirical validation is claimed. This is
new selected computational evidence,not independent confirmation of the
Spin(10) physical hypothesis.

**Next discriminating action.** Reduce the complete T4 operator by its
boson/scalar/ghost blocks, verify that reduction with noncommuting
fixtures and sensitive broken-ghost cases, then calculate the full T
log5 tensor efficiently. Keep F4/F5 and both-broken-ghost branches as
explicit remaining obligations. A compact proposal is in NEXT_REDUCTION.md;
it is not yet an executed or qualified result. Do not restart the large
primitive catalogue or fit a normalization to obtain a preferred answer.

## Failures, validation and authority

Original UMH3 worker FAILED during custody authentication because its
inherited access guard rejected a byte hash; no new loop coefficient was
produced. The V2 controller FAILED before launch on an existing immutable
source-copy filename. Both sources,failures and full captures remain.
The V3 controller authenticated existing identical copies and launched
the unchanged V2 mathematics with hook installation after custody hashes.
Both native denial controls passed. Neither old attempt is relabelled PASS.

Completed afterimport seconds:UMH1 primary3.8861,replay4.5618;UMH2
review2.0829;UMH3 V2 primary16.6441,replay17.4694;UMH4 review26.3924.
Largest successful sample868241408B,not continuous peak; packet2113952B
before reports. Frozen300/180s,8GiB sampled,350MiB launchfloor,32MiB held.
All original contracts,failed runs and evidence remain. E4 and final
byte-custody outcomes are recorded in their actual captures/receipt.

State113,authority34/39,E5/A5 OPEN,custody exit2/seven unresolved remain.
No foundation,benchmark,scheme,protected stage or remote/publication action
changed. The original physical benchmark exclusions and other viability
problems remain. Full investigation is active and incomplete.
