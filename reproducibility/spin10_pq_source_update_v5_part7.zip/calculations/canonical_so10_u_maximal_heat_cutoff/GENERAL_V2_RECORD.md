# UMH3 V2: authenticate bytes before installing algorithm access guards

The original worker exited1 while hashing its frozen continuation manifest.
The inherited helper installed a guard that rejects peer/target scientific
access; that guard also rejected the continuation's custody-only byte hash.
No new ordered trace coefficient was produced, and replay was not launched.
The original sources,preparation,full native capture and controller failure
remain FAILED unchanged. This is an initialization-order error,not a
failed physical identity or a successful original execution.

V2 loads the same frozen helper with its hook installation deferred until
ALL custody hashes are checked, then installs both original and continuation
guards before the algorithm. Native tests that peer-output and quantum-
remainder file opens are blocked before any bytes are returned. The class
builders,graded algebra,physical data,source projection,coefficient targets,
scientific acceptance and300/180s/8GiB/350MiB/32MiB limits are unchanged.
New output names preserve the original failed capture. Live standing
delegation authorizes this routine harness correction; it does not relabel
the old run or supply missing scientific evidence.
