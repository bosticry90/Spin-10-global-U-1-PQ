# UMH3 V3 controller: authenticate an existing identical source copy

The V2 controller failed before launch because GENERAL_RECORD.md already
had its immutable source copy from the original attempt. Its exclusive
copy operation rejected the filename; no V2 native was started and no
preparation or coefficient was produced. Preserve that controller and
general_controller_failure_v2.json. The V2 native source is unchanged.

After these two setup failures, the controller now authenticates an
existing source copy against its exact current bytes and creates only
missing copies exclusively. A mismatch still fails. This prevents an
overwrite while allowing intentional reuse of the unchanged original
record. V3 binds both failed controller sources/failures and the V2 native
before its FIRST launch. Output and preparation names for that still-
unlaunched native remain V2. No scientific condition,physical input,
source formula,blinding hook or resource limit changes. This is a bounded
controller correction under the standing delegation,not a successful
original execution or a scientific retry fitted to a desired outcome.
