# UMH1: complete maximal-heat u families, selected coefficients

Prospective at4627af43. Fixed original SMA/CSW/EDS,A0,constant u and
intrinsic1; targets Ja13 C0 x137 (T) and JL13 C0 C12 x136 (F).
Question: derive actual C4_T and C5_F without using a Ward remainder.
The latter is only a component of the full F coefficient C4_F-C5_F.

After the original complete-free-root H_u cancellation (SMP/FJB), the
maximal-edge words contain only the free source-free M_u, original
M_C/M_x and free ordinary H_u. Every other root consumes at least one
extra positive grade. All remaining vertices consume one grade each:
V_n,V_J,V_C,V_x. Derive this from full source/field differentiation before
the target restriction. Source2 in QG is retained in the preceding full
classical construction; it cannot supply the grade-one roots here.
The one-grade sourceJa vertex is Ja C a; sourceJL is JL C Lambda.
JL CCa has higher external grade, as do intrinsic scalar-potential
cubics and scalar seagulls at this target. Fermion one-grade V_x is
ff-only and cannot join the forced ghost/source cycle; no mixed quantum
fermion vertex has an allowed external field. Exclusions are structural,
not small-amplitude or absent-table assumptions.

T4:24 words each with M_u free, H_u/M_C or H_u/M_x:72 ordered words.
F5:the same coefficient extraction with two separately ordered ghosts;
retain both C roots and all permutations, never identify the ghosts.
Use the common polynomial trace formula to retain multiplicities/signs.
Keep the complete M_f endpoint group as a zero normalization check at
T5/F6; do not assume either endpoint zero separately. Scalar rotation
groups may be zero by the qualified Gaussian pairing proof and must be
reported as insensitive omissions when zero.

Classical operands: FJB's full actual QG and field maps; ISD source
action/B/beta; original RSH G0,N0,J0,R. No old quantum coefficients.
Derive H_u and M_u from the actual QG with Euclidean source signs.
Check all four-component Lorentz shapes BEFORE selecting q3: H_u BB
is longitudinal p_mu p_nu, B-Lambda is p_mu, Lambda-Lambda constant;
M_u a<-B is p_mu, a<-Lambda constant. Every scalar-current/ghost-vector
port is longitudinal; diagonal roots preserve it. A single cycle cannot
contain an isolated transverse spectator while also visiting the forced
ghost/source/intrinsic-scalar ports. Thus no hidden D-dimensional
spectator or angular coefficient is silently dropped.

Primary:unrooted graded sparse matrix powers. Replay:advance rooted
ordered words from each tangent block. Include both q orientations,
graded trace and even u/Ja versus odd JL/ghost distinctions. The
paired-q normalization and common hbar/(16pi^2) remain as qualified in
CSW/RSH. Matrix order is G0 V with the tangent at the trace root.

For these complete homogeneous LOCAL cutoff symbols, each retained
integrand is p^-4 times E^m-E^(m+1). The heat difference vanishes as
p^2 at the origin and decays at infinity, so the radial integral exists
and equals log((m+1)/m)/(16pi^2). This proves a bounded formal-symbol
domain, not the full nonexceptional amplitude or a common continuum
first/multiple-variation/contact theorem. Keep that distinction explicit.

Only after both natives finish may a separate review inspect the prior
T witness as a normalization comparison. Do not fit coefficients or
reinterpret F5 alone as the full F result. Preserve disagreement.
Native300/review180s,8GiB sampled/350MiB launchfloor/32MiB packet.
Freeze source copies/input hashes; preserve failures. No authority,
reference,physical scheme,normalization or blocked-stage change.
