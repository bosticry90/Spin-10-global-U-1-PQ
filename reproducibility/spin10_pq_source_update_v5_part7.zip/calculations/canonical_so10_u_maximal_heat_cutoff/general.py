from pathlib import Path
import ast,sys,json,gzip,time,threading,os
from collections import defaultdict,Counter
O=Path(__file__).resolve().parent;R=O.parents[1];role=sys.argv[1];assert role in ['primary','replay']
# Reuse frozen finite matrix helpers, not an old execution or its outputs.
src=(O/'native.py').read_text();tree=ast.parse(src);cut=next(n.lineno for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='results' for t in n.targets))
exec(compile('\n'.join(src.splitlines()[:cut-1]),str(O/'native.py'),'exec'),globals())
import jets as JP
for p,h in json.loads((O/'general_preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
def newguard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
        if p.parent.resolve()==O and (p.name in ['primary_result.json','replay_result.json','review_result.json'] or p.name.startswith('general_'+peer)):raise PermissionError('UMH3_CALIBRATION_OR_PEER_DENIED')
sys.addaudithook(newguard)
AXIS=3 if role=='primary' else 2
def field(i):
    if i<180:return i//4 if i%4==AXIS else None
    if i<508:return 90+i-180
    if i<553:return 45+i-508
    if i<598:return NC+i-553
    return NA+i-598
def convert(i):return 643+508+i if i<45 else 643+598+i-45 if i<90 else 643+553+i-90 if i<135 else 553+i-135 if i<180 else 598+i-180 if i<225 else 508+i-225
Sigma={}
for w,c in d['source_action']:JP.put(Sigma,tuple((convert(i),()) for i in w),co(c))
Sigma=JP.clean(Sigma);GF={i:decode(z) for i,z in d['GF_gradient']}
def right_euler_sources(poly):
    partial={}
    for word,value in poly.items():
        for j,t in enumerate(word):
            if t[0]<643:continue
            z=partial.setdefault(t,{})
            w=word[:j]+word[j+1:];sg=(-1)**(parity(t[0])*sum(parity(i) for i,js in word[j+1:]))
            z[w]=z.get(w,ZERO)+sg*value
    out={}
    for (i,js),poly0 in partial.items():JP.add(out.setdefault(i,{}),JP.Ds(JP.clean(poly0),js),(-1)**len(js))
    return {i:JP.clean(z) for i,z in out.items() if JP.clean(z)}
QU=[]
for poly in Q:
    E=JP.euler(poly,set(range(643,1286))) if role=='primary' else right_euler_sources(poly)
    QU.append({src-643:{w:v*((-1)**parity(src-643) if role=='primary' else -1) for w,v in p.items()} for src,p in E.items()})

def ext(word,nd):
    if nd not in [0,1]:return None
    bits=[]
    for i,js in word:
        if js:return None
        b=JJ if i==SRC else XX if i==180+IX else CC1 if i==553 else CC2 if CASE=='F' and i==565 else None
        if b is None:return None
        bits.append(b)
    if len(bits)!=len(set(bits)):return None
    sg=(-1)**sum(bool(a&ODD) and bool(b&ODD) and a>b for j,a in enumerate(bits) for b in bits[j+1:])
    return (sum(bits)|(NN if nd else 0)),sg
def wave(js,q,reverse=False):
    if any(mu!=AXIS for mu in js):return ZERO
    v=constant(1)
    for mu in js:v=times(v,(-q if reverse else q)*I)
    return v
def marked_hessian(poly,q,umask=0,maxrest=None):
    H={}
    for word,value in poly.items():
        nd=degree(word,4)
        if nd not in [0,1]:continue
        for a,(i,ji) in enumerate(word):
            if i>=643:continue
            row=field(i)
            if row is None:continue
            for b,(j,jj) in enumerate(word):
                if b==a or j>=643:continue
                col=field(j)
                if col is None:continue
                rest=word[:a]+word[a+1:];pos=b-int(b>a)
                er=ext(rest[:pos]+rest[pos+1:],nd)
                if er is None:continue
                mask,es=er
                if maxrest is not None and mask.bit_count()>maxrest:continue
                if not mask and not umask:continue
                phase=times(wave(ji,q,True),wave(jj,q))
                if not phase:continue
                if role=='primary':
                    sg=(-1)**(parity(i)*sum(parity(k) for k,js in word[:a])+parity(j)*sum(parity(k) for k,js in rest[pos+1:]))
                    v=times(value,phase)*(sg*es)
                else:
                    # Finite two-mode polarization with the coefficient left,
                    # then convert back to the Gaussian row pairing.
                    labels=[]
                    for t,(k,js) in enumerate(word):
                        if t==a:labels.append((1000+i,parity(i)))
                        elif t==b:labels.append((2000+j,parity(j)))
                        else:
                            bit=JJ if k==SRC else XX if k==180+IX else CC1 if k==553 else CC2
                            labels.append((bit,int(bool(bit&ODD))))
                    sg=(-1)**sum(pa*pb*(ka>kb) for t,(ka,pa) in enumerate(labels) for kb,pb in labels[t+1:])
                    sg*=(-1)**(parity(i)*(parity(i)+parity(j)))
                    v=times(value,phase)*sg
                add(H,row,col,mask|umask,v)
    return H
def gf_hessian(q):
    direct={}
    for i,poly in GF.items():
        row=field(i)
        for word,value in poly.items():
            nd=degree(word,4-dimension(i))
            for at,(j,jj) in enumerate(word):
                if j>=643:continue
                col=field(j)
                if col is None:continue
                er=ext(word[:at]+word[at+1:],nd)
                if er is None:continue
                mask,sg=er
                if not mask:continue
                sg*=(-1)**(parity(j)*sum(parity(k) for k,js in word[at+1:]))
                v=times(value,wave(jj,q))*sg
                # Store a momentum-degree flag for the adjoint reflection.
                key=(row,col,mask,len(jj)%2);direct[key]=direct.get(key,ZERO)+v
    direct={k:v for k,v in direct.items() if v};all_entries=dict(direct)
    for (i,j,mask,k),v in direct.items():
        pi,pj=int(i>=NB),int(j>=NB)
        trans=v*((-1)**(pi+pj+pi*pj+k));key=(j,i,mask,k)
        if key in direct:assert direct[key]==trans,('GF_pairing_transpose',i,j,mask)
        else:all_entries[key]=trans
    H={}
    for (i,j,mask,k),v in all_entries.items():add(H,i,j,mask,v)
    return H
def tangent(F,q,probe_mask=0,maxrest=2):
    out={};groups={}
    for i,poly in F.items():
        row=field(i)
        if row is None:continue
        for word,value in poly.items():
            nd=degree(word,dimension(i)+1)
            for at,(j,jj) in enumerate(word):
                if j>=643:continue
                col=field(j)
                if col is None:continue
                rest=word[:at]+word[at+1:];er=ext(rest,nd)
                if er is None:continue
                mask,es=er
                if mask.bit_count()>maxrest:continue
                if not probe_mask and not mask:continue # whole original Mf group
                if role=='primary':sg=(-1)**(parity(j)*sum(parity(k) for k,js in word[at+1:]))*es
                else:
                    labels=[]
                    for t,(k,js) in enumerate(word):
                        if t==at:labels.append((1000+j,parity(j)))
                        else:
                            bit=JJ if k==SRC else XX if k==180+IX else CC1 if k==553 else CC2
                            labels.append((bit,int(bool(bit&ODD))))
                    sg=(-1)**sum(pa*pb*(ka>kb) for t,(ka,pa) in enumerate(labels) for kb,pb in labels[t+1:])
                v=times(value,wave(jj,q))*sg
                name=('Mu_' if probe_mask else 'M0_')+str(mask)
                add(groups.setdefault(name,{}),row,col,EPS|probe_mask|mask,v)
                add(out,row,col,EPS|probe_mask|mask,v)
    return out,groups
results=[]
for CASE in ['T','F']:
    EPS=1;UU=2;JJ=4;CC1=8;CC2=16 if CASE=='F' else 0;NN=32 if CASE=='F' else 16;XX=64 if CASE=='F' else 32
    TARGET=127 if CASE=='F' else 63;ODD=EPS|CC1 if CASE=='T' else EPS|JJ|CC1|CC2
    SRC=643+(598 if CASE=='T' else 508)+13;IX=137 if CASE=='T' else 136
    for probe in range(2):
        oriented=[]
        for q in [1,-1]:
            G={}
            for (i,j),v in dec(d['G0']).items():add(G,i,j,0,v*q if i<45<=j or j<45<=i else v)
            for i in range(328):add(G,90+i,90+i,0,constant(1))
            for i in range(45):add(G,NC+i,NA+i,0,constant(1));add(G,NA+i,NC+i,0,constant(-1))
            VGF=gf_hessian(q);VS=marked_hessian(Sigma,q);HU=marked_hessian(Q[probe],q,UU,1)
            VX={}
            for a,mat in enumerate(RR):
                for (j,i),v in mat.items():
                    if i==IX:add(VX,a,90+j,XX,-q*times(I,v));add(VX,90+j,a,XX,q*times(I,v))
            V={}
            for part in [VGF,VS,VX,HU]:
                for ij,poly in part.items():V[ij]=padd(V.get(ij,{}),poly)
            M0,g0=tangent(flows,q,0,2);MU,gu=tangent(QU[probe],q,UU,1);groups={**g0,**gu}
            totalM={}
            for group in groups.values():
                for ij,poly in group.items():totalM[ij]=padd(totalM.get(ij,{}),poly)
            X=mm(G,V)
            if role=='primary':
                power={(i,i):{0:constant(1)} for i in range(DIM)}
                for n in range(4):power=mm(power,X)
                vals={name:tr(mm(power,M)) for name,M in groups.items()}
            else:
                vals={}
                for name,M in groups.items():
                    power=M
                    for n in range(4):power=mm(power,X)
                    vals[name]=tr(power)
            value=sum(vals.values(),ZERO)
            controls={}
            # Whole-group omission values, never silently called sensitive.
            for name in ['source2','GFaaCC','sourceD','Hu','Mu']:
                VV={};MM={}
                for ij,poly in V.items():
                    for mask,v in poly.items():
                        remove=(name=='GFaaCC' and ij[0]>=NA and ij[1]>=NA and mask==(CC1|CC2)) or (name=='sourceD' and mask&JJ and mask&(CC1|CC2) and not mask&UU) or (name=='Hu' and mask&UU)
                        if not remove:add(VV,*ij,mask,v)
                for group,M in groups.items():
                    remove=(name=='Mu' and group.startswith('Mu_')) or (name=='source2' and group=='Mu_'+str(JJ))
                    if not remove:
                        for ij,poly in M.items():
                            for mask,v in poly.items():add(MM,*ij,mask,v)
                PP=mm(G,VV);power=MM
                for n in range(4):power=mm(power,PP)
                controls[name]=value-tr(power)
            oriented.append((value,vals,controls))
            print('STAGE GENERAL '+CASE+' '+str(probe)+' '+str(q)+' '+str(value),flush=True)
        assert oriented[0][0]==oriented[1][0]
        average=lambda a,b:times(co('1/2'),a+b)
        results.append({'case':CASE,'probe':probe,'axis':AXIS,'C4':str(oriented[0][0]),'root_groups':{name:str(average(oriented[0][1].get(name,ZERO),oriented[1][1].get(name,ZERO))) for name in oriented[0][1].keys()|oriented[1][1].keys()},'omission_changes':{name:str(average(oriented[0][2][name],oriented[1][2][name])) for name in oriented[0][2]},'q_orientations_agree':True})
out={'schema':'UMH3_GENERAL_FOURTH_EDGE_SELECTED_CUTOFF','role':role,'results':results,'known_quantum_remainder_or_UMH1_result_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/('general_'+role+'_result.json')).open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
