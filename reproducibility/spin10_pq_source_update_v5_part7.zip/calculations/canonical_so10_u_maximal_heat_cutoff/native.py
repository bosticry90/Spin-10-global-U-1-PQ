from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from functools import lru_cache
import gzip,json,sys,time,threading,os
import sympy as s
O=Path(__file__).resolve().parent;R=O.parents[1];role=sys.argv[1];assert role in ['primary','replay']
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'))
from jets import decode,dimension,parity,degree,times,Coeff,ZERO,I,constant
from coefficient_ring import coefficient,g,xi,eta
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in json.loads((O/'preparation.json').read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        p=Path(os.fsdecode(args[0]));peer='replay' if role=='primary' else 'primary'
        if p.parent.resolve()==O and (p.name.startswith(peer+'_') or p.name.startswith('review_')):raise PermissionError('UMH_NATIVE_PEER_DENIED')
        if p.parent.name in ['canonical_so10_u_pair_contact_model','canonical_so10_intrinsic_auxiliary_ghost_source']:raise PermissionError('UMH_QUANTUM_TARGET_DENIED')
sys.addaudithook(guard)
d=json.loads(gzip.decompress((O/(role+'_inputs.json.gz')).read_bytes()))
@lru_cache(None)
def co(v):return coefficient(s.sympify(v,locals={'g10':g,'xi':xi,'eta_H':eta}))
def dec(z):return {(i,j):co(v) for i,j,v in z['entries']}
Q=list(map(decode,d['QG']));flows={i:decode(z) for i,z in d['field_flows']};RR=list(map(dec,d['R']));N=dec(d['N0']);J0=list(map(dec,d['J0']));B={tuple(r[:-1]):co(r[-1]) for r in d['B']};beta={tuple(r[:-1]):co(r[-1]) for r in d['beta']}

def full_free(probe):
    H={};MU={}
    for word,c in Q[probe].items():
        if len(word)!=2 or degree(word,4)!=0:continue
        sources=[j for j,(i,js) in enumerate(word) if i>=643]
        if not sources:
            assert all(i<180 or 508<=i<553 for i,js in word),word
            for at in range(2):
                (i,ji),(j,jj)=word[at],word[1-at]
                pp=tuple((ji+jj).count(mu) for mu in range(4));v=c
                for mu in ji:v=times(v,-I)
                for mu in jj:v=times(v,I)
                H[i,j,pp]=H.get((i,j,pp),ZERO)+v
        elif len(sources)==1:
            at=sources[0];(src,js),(inn,ij)=word[at],word[1-at]
            assert 643+598<=src<1286 and not js and inn<643,(src,word)
            v=-c
            for mu in ij:v=times(v,I)
            pp=tuple(ij.count(mu) for mu in range(4));MU[src-643,inn,pp]=MU.get((src-643,inn,pp),ZERO)+v
    H={k:v for k,v in H.items() if v};MU={k:v for k,v in MU.items() if v}
    # Check full Lorentz shapes prior to the longitudinal projection.
    colorBB={};colorBL={};colorMB={}
    for (i,j,p),v in H.items():
        if i<180 and j<180:
            a,mu=divmod(i,4);b,nu=divmod(j,4);expected=tuple(int(z==mu)+int(z==nu) for z in range(4));assert p==expected
            if (a,b) in colorBB:assert colorBB[a,b]==v
            colorBB[a,b]=v
        elif i<180 and 508<=j<553:
            a,mu=divmod(i,4);expected=tuple(int(z==mu) for z in range(4));assert p==expected
            if (a,j-508) in colorBL:assert colorBL[a,j-508]==v
            colorBL[a,j-508]=v
        elif i>=508 and j<180:pass
        else:assert p==(0,0,0,0)
    for (i,j,p),v in H.items():assert H.get((j,i,p),ZERO)==v*((-1)**sum(p))
    for (i,j,p),v in MU.items():
        if j<180:
            a,mu=divmod(j,4);assert p==tuple(int(z==mu) for z in range(4))
            if (i,a) in colorMB:assert colorMB[i,a]==v
            colorMB[i,a]=v
        else:assert 508<=j<553 and p==(0,0,0,0)
    for (a,b),v in colorBB.items():
        assert all(H.get((4*a+mu,4*b+nu,tuple(int(z==mu)+int(z==nu) for z in range(4))),ZERO)==v for mu in range(4) for nu in range(4))
    for (a,b),v in colorBL.items():assert all(H.get((4*a+mu,508+b,tuple(int(z==mu) for z in range(4))),ZERO)==v for mu in range(4))
    for (i,a),v in colorMB.items():assert all(MU.get((i,4*a+mu,tuple(int(z==mu) for z in range(4))),ZERO)==v for mu in range(4))
    return H,MU
free=list(map(full_free,range(2)))
NB=418;NC=418;NA=463;DIM=508
def field(i):
    if i<180:return i//4 if i%4==3 else None
    if i<508:return 90+i-180
    if i<553:return 45+i-508
    if i<598:return NC+i-553
    return NA+i-598
def qpow(q,p):return constant(q**sum(p)) if all(not n for mu,n in enumerate(p) if mu!=3) else ZERO
@lru_cache(None)
def sign(a,b,odd):return (-1)**sum((b&odd&((1<<i)-1)).bit_count() for i in range(7) if a&odd&(1<<i))
def padd(a,b):
    out=dict(a)
    for k,v in b.items():out[k]=out.get(k,ZERO)+v
    return {k:v for k,v in out.items() if v}
def pmul(a,b):
    out={}
    for m,v in a.items():
        for n,w in b.items():
            if not m&n:out[m|n]=out.get(m|n,ZERO)+times(v,w)*sign(m,n,ODD)
    return {k:v for k,v in out.items() if v}
def mm(A,Bb):
    by=defaultdict(list);out={}
    for (i,j),v in Bb.items():by[i].append((j,v))
    for (i,k),v in A.items():
        for j,w in by[k]:
            z=pmul(v,w)
            if z:out[i,j]=padd(out.get((i,j),{}),z)
    return {ij:p for ij,p in out.items() if p}
def add(A,i,j,mask,v):
    if v:A[i,j]=padd(A.get((i,j),{}),{mask:v})
def tr(A,ordinary=False):return sum((p.get(TARGET,ZERO)*(1 if ordinary else (-1)**int(i>=NB)) for (i,j),p in A.items() if i==j),ZERO)

def m0groups(case,q,ix,cs):
    groups={'Mf_BC':{},'Mf_aL':{},'Mx':{}}
    for h,mask in cs:groups['MC_'+str(h)]={};groups['MC_scalar_'+str(h)]={}
    for out,poly in flows.items():
        row=field(out)
        if row is None:continue
        for word,c in poly.items():
            for at,(inn,jets) in enumerate(word):
                col=field(inn)
                if col is None or any(mu!=3 for mu in jets):continue
                rem=word[:at]+word[at+1:]
                v=c*((-1)**(parity(inn)*sum(parity(i) for i,js in word[at+1:])))
                for mu in jets:v=times(v,q*I)
                if not rem:
                    name='Mf_BC' if out<180 and 553<=inn<598 else 'Mf_aL' if 598<=out<643 and 508<=inn<553 else None
                    assert name is not None,(out,inn)
                    add(groups[name],row,col,EPS,v)
                elif len(rem)==1 and not rem[0][1]:
                    ext=rem[0][0]
                    if ext==180+ix:add(groups['Mx'],row,col,EPS|XX,v)
                    for h,mask in cs:
                        if ext==553+h:
                            name='MC_scalar_'+str(h) if 180<=out<508 and 180<=inn<508 else 'MC_'+str(h)
                            add(groups[name],row,col,EPS|mask,v)
    return groups

def matrices(case,probe,q):
    r=13;ix=137 if case=='T' else 136;cs=[(0,CC1)] if case=='T' else [(0,CC1),(12,CC2)]
    V={};G={}
    for (i,j),v in dec(d['G0']).items():add(G,i,j,0,v*q if i<45<=j or j<45<=i else v)
    for i in range(328):add(G,90+i,90+i,0,constant(1))
    for i in range(45):add(G,NC+i,NA+i,0,constant(1));add(G,NA+i,NC+i,0,constant(-1))
    for (b,j),v in N.items():add(V,b,90+j,NN,v);add(V,90+j,b,NN,v)
    for a,mat in enumerate(RR):
        for (j,i),v in mat.items():
            if i==ix:add(V,a,90+j,XX,-q*times(I,v));add(V,90+j,a,XX,q*times(I,v))
    for h,mask in cs:
        for (a,b),v in J0[h].items():
            v=v*q if b<45 else v;add(V,NA+a,b,mask,v);add(V,b,NA+a,mask,v if b<45 else -v)
    if case=='T':
        for (rr,c,a),v in B.items():
            if rr==r:add(V,NA+a,NC+c,JJ,v);add(V,NC+c,NA+a,JJ,-v)
    else:
        for (rr,c,a),v in beta.items():
            if rr==r:add(V,NC+c,45+a,JJ,-v);add(V,45+a,NC+c,JJ,v)
    H,MU=free[probe]
    for (i,j,p),v in H.items():
        a,b=field(i),field(j)
        if a is not None and b is not None:add(V,a,b,UU,times(v,qpow(q,p)))
    groups=m0groups(case,q,ix,cs);groups['Mu_free']={}
    for (i,j,p),v in MU.items():
        a,b=field(i),field(j)
        if a is not None and b is not None:add(groups['Mu_free'],a,b,EPS|UU,times(v,qpow(q,p)))
    return G,V,groups

results=[]
for case in ['T','F']:
    EPS=1;UU=2;JJ=4;CC1=8;CC2=16 if case=='F' else 0;NN=32 if case=='F' else 16;XX=64 if case=='F' else 32
    TARGET=127 if case=='F' else 63;ODD=EPS|CC1 if case=='T' else EPS|JJ|CC1|CC2;MAX=4 if case=='T' else 5
    for probe in range(2):
        orient=[]
        for q in [1,-1]:
            G,V,groups=matrices(case,probe,q);X=mm(G,V);values={k:{MAX:ZERO,MAX+1:ZERO} for k in groups};badordinary={}
            if role=='primary':
                power={(i,i):{0:constant(1)} for i in range(DIM)}
                for n in range(1,MAX+2):
                    power=mm(power,X)
                    if n>=MAX:
                        for name,M in groups.items():values[name][n]=tr(mm(power,M))*((-1)**n)
                        badordinary[n]=sum((tr(mm(power,M),True)*((-1)**n) for M in groups.values()),ZERO)
            else:
                for name,M in groups.items():
                    power=M
                    for n in range(1,MAX+2):
                        power=mm(power,X)
                        if n>=MAX:values[name][n]=tr(power)*((-1)**n)
                    print('STAGE root '+case+' '+str(probe)+' '+str(q)+' '+name,flush=True)
                badordinary={}
            total={n:sum((v[n] for v in values.values()),ZERO) for n in [MAX,MAX+1]}
            assert total[MAX+1]==0,('complete_free_root_not_zero',case,probe,q,str(total[MAX+1]))
            for name in values:
                if name.startswith('MC_scalar'):assert not values[name][MAX] and not values[name][MAX+1]
            orient.append({'groups':values,'total':total,'ordinary_trace':badordinary})
        assert orient[0]['total']==orient[1]['total']
        average_groups={name:{str(n):str(times(co('1/2'),orient[0]['groups'][name][n]+orient[1]['groups'][name][n])) for n in [MAX,MAX+1]} for name in groups}
        output={'case':case,'probe':probe,'maximal_edges':MAX,'indices':{'source':13,'ghosts':[0] if case=='T' else [0,12],'scalar':137 if case=='T' else 136},'coefficient':str(orient[0]['total'][MAX]),'free_root_next_edge_coefficient':str(orient[0]['total'][MAX+1]),'groups':average_groups,'q_orientations_agree':True,'full_F_log5_claim':False}
        if role=='primary':output['ordinary_trace_control_coefficient']=str(times(co('1/2'),orient[0]['ordinary_trace'][MAX]+orient[1]['ordinary_trace'][MAX]))
        results.append(output);print('STAGE coefficient '+json.dumps(output,sort_keys=True),flush=True)
out={'schema':'UMH1_MAXIMAL_HEAT_SELECTED_DIRECT_U_COEFFICIENTS','role':role,'results':results,'four_component_longitudinal_shapes_verified':True,'known_quantum_remainder_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/(role+'_result.json')).open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
