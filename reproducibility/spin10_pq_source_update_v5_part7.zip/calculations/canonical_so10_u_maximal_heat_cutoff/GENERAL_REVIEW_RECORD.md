# UMH4: compare complete selected operators and late T/F logarithms

Prospective after corrected UMH3 natives complete. Preserve the original
worker initialization failure and V2 controller copy failure separately.
Compare V2 native coefficients,all root groups and omission controls;
axes2/3 and both q orientations are part of the evidence.

Fresh review reconstructs the two native CLASSICAL operator builders,
without their trace loops. Native output access guards are not installed
in this authenticated late reviewer; their original denials are checked
from full native captures. Do not execute the native blinding-test opens
without hooks. Compare full left/right source Euler maps, not only the
loop result. Compare the GF/source/u Hessian and M0/Mu matrices including
their zero complement at all four independent axes. New non-free vector
entries are first-degree p_mu; free H_u,BB already has a checked full
p_mu p_nu shape. Axis comparison therefore covers those linear shapes,
not a numerical interpolation of a higher-rank Lorentz tensor.

Inventory all source2 QG monomials and the minimum external grade after
source/field differentiation. If the actual patterns exclude source2 at
fourth/fifth cutoff order, state that scope precisely. Quantum source2
contact Euler images remain required on the conversion side. Likewise
scan full original quartic-ghost and source-D support before interpreting
insensitive selected controls; do not infer a global zero from a witness.

Only after matrix/operator comparison read UPM's old partial T/F log5.
Compute the full SELECTED cutoff as C4_T and C4_F-C5_F, and preserve the
exact conversion-plus-cutoff sum. No full tensor or full trace/product
limit is established by a selected cancellation. Review180s/8GiB/
350MiB/32MiB; freeze sources and completed inputs/captures before execution.
