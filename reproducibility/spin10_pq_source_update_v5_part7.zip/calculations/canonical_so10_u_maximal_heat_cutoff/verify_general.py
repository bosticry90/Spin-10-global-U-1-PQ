from pathlib import Path
from hashlib import sha256
from collections import Counter
import ast,json,gzip,sys,time,threading,os
O=Path(__file__).resolve().parent;R=O.parents[1]
reviewtick=time.perf_counter();reviewtimer=threading.Timer(180,lambda:os._exit(124));reviewtimer.daemon=True;reviewtimer.start()
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
for p,h in read(O/'general_review_preparation.json')['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
outputs=[read(O/('general_v2_'+role+'_result.json')) for role in ['primary','replay']]
for p,q in zip(outputs[0]['results'],outputs[1]['results']):assert {k:v for k,v in p.items() if k!='axis'}=={k:v for k,v in q.items() if k!='axis'}
source=(O/'general_v2.py').read_text();tree=ast.parse(source);cut=next(n.lineno for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='results' for t in n.targets));header='\n'.join(source.splitlines()[:cut-1])
header=header.replace('sys.addaudithook(guard);sys.addaudithook(newguard)','assert True # authenticated late reviewer; no native hooks')
a=header.index('denied=0');b=header.index("print('STAGE guard_controls '+str(denied),flush=True)")+len("print('STAGE guard_controls '+str(denied),flush=True)")
header=header[:a]+'denied=2 # authenticate actual native denial captures separately'+header[b:]
namespaces=[]
for role in ['primary','replay']:
    ns={'__file__':str(O/'general_v2.py'),'__name__':'UMH4_CLASSICAL_BUILDER_REVIEW'};previous=sys.argv;sys.argv=[str(O/'general_v2.py'),role]
    exec(compile(header,str(O/'general_v2.py'),'exec'),ns);sys.argv=previous;ns['timer'].cancel();namespaces.append(ns)
    cap=read(O/('general_v2_'+role+'_capture.json'));assert 'STAGE guard_controls 2' in cap['stdout_and_stderr'] and cap['exit_code']==0
p,q=namespaces;assert p['QU']==q['QU']
canon=lambda M:{ij:{m:v for m,v in poly.items() if v} for ij,poly in M.items() if any(poly.values())}
matrix_checks=0;quantum_entries=0
for CASE in ['T','F']:
    for probe in range(2):
        baseline=None
        for axis in range(4):
            bundles=[]
            for ns in namespaces:
                ns.update(CASE=CASE,AXIS=axis,EPS=1,UU=2,JJ=4,CC1=8,CC2=16 if CASE=='F' else 0,NN=32 if CASE=='F' else 16,XX=64 if CASE=='F' else 32,TARGET=127 if CASE=='F' else 63,ODD=1|8 if CASE=='T' else 1|4|8|16,SRC=643+(598 if CASE=='T' else 508)+13,IX=137 if CASE=='T' else 136)
                VGF=canon(ns['gf_hessian'](1));VS=canon(ns['marked_hessian'](ns['Sigma'],1));HU=canon(ns['marked_hessian'](ns['Q'][probe],1,2,1))
                M0,g0=ns['tangent'](ns['flows'],1,0,2);MU,gu=ns['tangent'](ns['QU'][probe],1,2,1)
                bundles.append([VGF,VS,HU,canon(M0),canon(MU)])
            assert bundles[0]==bundles[1],('classical_operator_method_mismatch',CASE,probe,axis)
            if baseline is not None:assert bundles[0]==baseline,('independent_axis_operator_mismatch',CASE,probe,axis)
            baseline=bundles[0];matrix_checks+=5;quantum_entries+=sum(len(M) for M in baseline)
        print('STAGE operator_matrices '+CASE+' '+str(probe),flush=True)

# Global source2 support, after the actual first source variation.
source2=[]
for probe,Q in enumerate(p['Q']):
    counts=Counter()
    for word,c in Q.items():
        if sum(i>=643 for i,js in word)!=2:continue
        pattern=[]
        for i,js in word:
            pattern.append('Ja' if 643+598<=i<1286 else 'JL' if 643+508<=i<643+553 else 'C' if 553<=i<598 else 'other')
        counts[tuple(sorted(pattern)),sum(len(js) for i,js in word)]+=1
    source2.append({'probe':probe,'patterns':[[list(pattern),jets,count] for (pattern,jets),count in sorted(counts.items())]})
    assert all(pattern in [('Ja','Ja'),('C','C','JL','JL')] and jets==0 for pattern,jets in counts)

quartic_pairs=[]
for out,poly in p['GF'].items():
    if out<598:continue
    for word,c in poly.items():
        ghosts=[i-553 for i,js in word if 553<=i<598]
        if len(word)==3 and len(ghosts)==2 and any(598<=i<643 for i,js in word):quartic_pairs.append(ghosts)
sourceD_pairs=[]
for word,c in p['Sigma'].items():
    if len(word)==4 and any(643+508<=i<643+553 for i,js in word) and any(598<=i<643 for i,js in word):
        ghosts=[i-553 for i,js in word if 553<=i<598]
        if len(ghosts)==2:sourceD_pairs.append(ghosts)

# Late coefficient comparison, after complete operator reconstruction.
old=load(R/'calculations/canonical_so10_u_pair_contact_model/partial_TF_tables.json.gz');maximum=read(O/'primary_result.json');late=[]
co=p['co'];ZERO=p['ZERO']
for probe in range(2):
    relation=next(r for r in old['results'][probe]['partial_relations'] if r['basis']=='log5')
    for case in ['T','F']:
        indices=(13,0,137) if case=='T' else (13,0,12,136)
        conversion={tuple(r[:-1]):co(r[-1]) for r in relation['homogeneous_plus_Euler_partial'][case]}.get(indices,ZERO)
        C4=co(next(r['C4'] for r in outputs[0]['results'] if r['case']==case and r['probe']==probe))
        maximal=co(next(r['coefficient'] for r in maximum['results'] if r['case']==case and r['probe']==probe))
        if case=='T':assert C4==maximal;cutoff=C4
        else:cutoff=C4-maximal
        late.append({'case':case,'probe':probe,'indices':list(indices),'relative_conversion_log5':str(conversion),'C4':str(C4),'C5':str(maximal) if case=='F' else '0 (complete free-root group)','cutoff_log5':str(cutoff),'sum':str(conversion+cutoff),'selected_cancellation':not(conversion+cutoff)})
result={'schema':'UMH4_COMPLETE_SELECTED_OPERATOR_REVIEW','all_root_groups_and_omission_results_equal':True,'source_Euler_left_vs_right_complete_maps_equal':True,'full_selected_matrices_and_implicit_zeros_equal':True,'four_axis_matrix_checks':matrix_checks,'nonzero_matrix_entry_comparisons':quantum_entries,'source2_classification':source2,'source2_cutoff_log5_excluded_by_grade_and_source_support':True,'quartic_ghost_pairs_contain_unbroken_ghost':any(any(i<12 for i in pair) for pair in quartic_pairs),'sourceD_pairs_contain_unbroken_ghost':any(any(i<12 for i in pair) for pair in sourceD_pairs),'late_comparison':late,'full_tensor_or_contact_QAP_claim':False,'elapsed_after_imports':time.perf_counter()-reviewtick}
with (O/'general_review_result.json').open('xb') as f:f.write((json.dumps(result,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(result,sort_keys=True),flush=True);reviewtimer.cancel()
