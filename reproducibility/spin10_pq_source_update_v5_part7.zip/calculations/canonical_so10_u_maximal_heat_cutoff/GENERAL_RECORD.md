# UMH3: complete selected fourth-edge u cutoff, including nonlinear sources

Prospective after UMH1/2. The maximal-edge T witness cancels its relative
conversion; selected F5 is zero but F4 remains missing. Calculate the
complete C4 at the SAME frozen T/F witnesses, without importing either
old quantum remainder or UMH1 coefficient as a native operand.

Keep full source differentiation first. Derive q_u=(-1)^p Euler_J QG,
including source2; then right-differentiate fields for epsilon-left M_u.
Primary left-source Euler versus replay minus-right-source Euler must
agree. Build H_u from the actual QG before ordinary/source projection.
Primary ordered left/right quantum derivatives versus replay two-mode
polarization must agree in the resulting loop coefficient. Retain the
ordinary original M_C,M_x and M_CC roots. Remove ONLY the COMPLETE
original-free-root H_u sum by SMP/FJB's arbitrary-Hessian identity.

At F4 the one extra positive grade permits original V_nx,V_nC,V_CC and
V_JC, M_u intrinsic/source/ghost-dependent roots, and H_u intrinsic,
ghost or source vertices. Obtain GF entries from FJB's full Euler columns;
source entries from the actual ISD source density. No source2 omission.
The physical one-grade scalar-current vertex is fixed by R and the kinetic
covariance law. Potential V_nx is scalar-scalar: it consumes both n,x and
then has no scalar-to-ghost/source transition available in a four-edge
target cycle. M_x or M_u,n and H_u,n would duplicate x or n respectively;
all other remaining ports are non-scalar. It is a disconnected-cycle
exclusion, not a guessed numerical zero. A fermion V_x is likewise an
isolated ff component; no allowed source/tangent port joins it. Other
potential/physical seagulls have higher grade or a forbidden external B.

Every remaining vector transition has one vector index and hence its
actual p_mu pin. The sole two-vector H_u,0 is already verified p_mu p_nu.
Diagonal original C roots preserve that subspace. A target cycle must
visit the ghost/source sector, so cannot have an isolated transverse
vector loop. Primary uses axis3; replay uses axis2 after this support
argument, with both q orientations. No closed dimension spectator or
Djet is dropped on numerical evidence alone.

Use complete ordered graded powers for primary and tangent-rooted products
for replay. Build C4_T as an independent nonzero calibration of the new
general Hessian assembly; only review compares it with UMH1. Compute
C4_F and combine later with authenticated C5_F. Preserve disagreement.
Omission controls remove whole declared source2,GF-aaCC,source-D,H_u or
M_u groups, and report actual sensitivity/insensitivity. Their agreement
does not supply full trace-limit/contact/QAP applicability.

Same native300/review180s afterimports,8GiB sampled,350MiB launchfloor,
32MiB packet. Freeze all sources and added dependencies before execution.
No changed action/reference/normalization or scientific authority.
