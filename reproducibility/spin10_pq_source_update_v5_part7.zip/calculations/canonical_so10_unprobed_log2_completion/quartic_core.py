from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction
import gzip,json,sys
R=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(R/'calculations/canonical_so10_unprobed_marginal_C3'))
from cubic_core import coeff,ZERO,constant,NB,merge,target,owning_key,external_type,put,clean,encode,sector
O=Path(__file__).resolve().parent
def linear(role):
    P=R/'calculations/canonical_so10_unprobed_marginal_C3'
    z=json.loads(gzip.decompress((P/(role+'_blocks.json.gz')).read_bytes()))
    T={(i,j,tuple(w)):coeff(c) for i,j,w,c in z['reduced'] if len(w)==1}
    assert all(not 90<=i<418 and not 90<=j<418 for i,j,w in T)
    assert all((int(i>=NB)+int(j>=NB))%2==1 for i,j,w in T)
    return T
def compatible(word):
    c=Counter(external_type(i) for i in word)
    return c['C']<=2 and c['a']<=1 and c['JL']<=2 and not(c['a'] and c['JL']>1)
def rooted_paths(T):
    rows=defaultdict(list);edges=defaultdict(list)
    for (i,j,w),v in T.items():rows[i].append((j,w[0],v));edges[i,j].append((w[0],v))
    for (i,j,ww),v in T.items():
        r=ww[0]
        if external_type(r)!='JL':continue
        for k,a,x in rows[j]:
            if a==r or not compatible((r,a)):continue
            for l,b,y in rows[k]:
                if b in [r,a] or not compatible((r,a,b)):continue
                for c,z in edges[l,i]:
                    word,sg=merge((r,a,b,c))
                    if not sg:continue
                    case=target(word)
                    if case is None:continue
                    yield case,i,j,k,l,r,a,b,c,word,sg,v,x,y,z
def pair_product(T,association='forward'):
    rows=defaultdict(list)
    for (i,j,w),v in T.items():rows[i].append((j,w[0],v))
    out={};work=0
    for (i,k,ww),v in (T.items() if association=='forward' else reversed(list(T.items()))):
        a=ww[0]
        for j,b,w in rows[k]:
            pair,sg=merge((a,b))
            if not sg or not compatible(pair):continue
            put(out,(i,j,pair),(v*w)*sg);work+=1
    return clean(out),work
