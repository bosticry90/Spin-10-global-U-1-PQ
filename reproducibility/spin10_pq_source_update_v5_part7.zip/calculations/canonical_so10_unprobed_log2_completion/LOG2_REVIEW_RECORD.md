# ULD4b: complete image comparison and late log2 test, prospective

Native ULD4 outputs must complete first. Authenticate their packed hashes,
compare all C3/C4/root/log2 coefficients and implicit zeros, and independently
reassemble the log2 image. Check the actual UOR root inventory against the
ULD1 dimension proof and the four C4 heat bounds. Reuse qualified C3 zeros
and their owning receipts; no new integration is claimed for old loops.

Only AFTER these checks read UCT late_remainders basis log2, authenticated
against its original final review receipt. That partial relation already
owns the prior conversion and COMPLETE ordered cutoff contribution. It
does not own B_u C0. Add the complete ULD4 image ONCE; do not separately
readd a known nLx/C3 or intrinsic C4 contribution. Preserve the exact full
sum whether zero or nonzero. Cancellation is a scientific outcome,not an
execution acceptance condition. Record all full-domain counts and zeros.

Controls: omit each C4 group separately,reverse just the JL-prefix C4
image,duplicate the two-JL C4 image,and reverse the whole C3 sign. Report
the actual resulting remainders and sensitivity; empty probe0 controls
cannot validate nonzero-source signs. Do not call an omitted model-zero
group sensitive. The finite nonzero sign/root fixtures remain separate.

Review180s after imports,8GiB sampled,350MiB launch floor,32MiB packet.
Freeze sources/inputs before execution,complete capture and exclusive
outputs; preserve failure/incompleteness. No altered physics or baseline.
Even zero full log2 does not prove the full finite Ward/master relation:
chi4/pole/algebraic dimensional terms and continuum product/variation/
measure/source-reality/global-phase/QAP/causal/physical applicability are
separate. The RESULT must state the supported claim and the cheapest test
of the next missing bridge,using existing methodology and authority.
