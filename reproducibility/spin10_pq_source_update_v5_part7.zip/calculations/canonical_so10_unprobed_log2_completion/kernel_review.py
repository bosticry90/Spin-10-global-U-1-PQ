from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import defaultdict
import ast,gzip,json,os,threading,time
from quartic_core import *
from blocks import OP,co,decode,gf_primitive
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest()
for pp,h in read(O/'kernel_review_preparation.json')['input_sha256'].items():assert H(Path(pp))==h,pp
def unpack(rows):
    out={tuple(z[:-1]):coeff(z[-1]) for z in rows};assert len(out)==len(rows) and all(out.values());return out
ab=[]
for role in ['primary','replay']:
    pp=O/('kernel4_'+role+'_tables.json.gz');assert H(pp)==read(O/('kernel4_'+role+'_result.json'))['packed_sha256'];ab.append(loadz(pp))
assert ab[0]['results']==ab[1]['results'];kernels={};counts=[]
for z in ab[0]['results']:
    M=unpack(z['total']);assert len(M)==z['nonzero'] and len(M)+z['zero_complement']==z['domain_positions']
    kernels[z['case']]=M;counts.append({k:v for k,v in z.items() if k!='total'})
assert all(z['guard_denials']==3 for z in ab)

# Disclosed pure uncut helper reuse,with the new operator length/weight.
oldsrc=R/'calculations/canonical_so10_unprobed_marginal_C3/kernel_review.py'
node=next(n for n in ast.parse(oldsrc.read_bytes()).body if isinstance(n,ast.FunctionDef) and n.name=='literal')
loops=weights=0
for n in ast.walk(node):
    if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='n' and isinstance(n.iter,ast.Call) and isinstance(n.iter.func,ast.Name) and n.iter.func.id=='range':
        assert len(n.iter.args)==1 and isinstance(n.iter.args[0],ast.Constant) and n.iter.args[0].value==3
        n.iter.args[0]=ast.Constant(4);loops+=1
    if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='Fraction' and len(n.args)==2 and all(isinstance(v,ast.Constant) for v in n.args) and [v.value for v in n.args]==[1,6]:
        n.args=[ast.Constant(-1),ast.Constant(8)];weights+=1
assert loops==weights==1
ast.fix_missing_locations(node)
ns={'defaultdict':defaultdict,'put':put,'clean':clean,'ZERO':ZERO,'constant':constant,'Fraction':Fraction,'co':co,'external_type':external_type}
exec(compile(ast.Module(body=[node],type_ignores=[]),'ULD_FRESH_FULL_UNCUT_FOUR_EDGE','exec'),ns);literal=ns['literal']
d=loadz(R/'calculations/canonical_so10_u_maximal_heat_cutoff/primary_inputs.json.gz')
gradient={i:decode(z) for i,z in d['GF_gradient']};density=gf_primitive(gradient)
oldop=ast.parse((R/'calculations/canonical_so10_u_F_fourth_support/operators.py').read_bytes())
nodes=[n for n in oldop.body if isinstance(n,ast.FunctionDef) and n.name in ['hessian','source_density']]
contexts=[]
for case,M in kernels.items():
    keys=sorted(M)
    if keys:contexts.extend((case,keys[min(len(keys)-1,j*len(keys)//4)]) for j in range(4))
    contexts.extend([('JLaCC',(0,0,0,1)),('JLaCC',(12,12,12,13))] if case=='JLaCC' else [('JLJLCC',(0,1,0,1)),('JLJLCC',(12,13,12,13))])
fresh=[]
for case,key in contexts:
    r,s,h,k=key
    selected={1151+r:1,(598+s if case=='JLaCC' else 1151+s):2,553+h:4,553+k:8};assert len(selected)==4
    def allow(word,nd,low,high):
        if nd!=0 or not low<=len(word)<=high or any(js or i not in selected for i,js in word):return None
        ids=tuple(i for i,js in word)
        return ids if len(ids)==len(set(ids)) else None
    hns=dict(vars(OP));hns['allowed']=allow
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'ULD_FRESH_ORIGINAL_DENSITY_HESSIAN','exec'),hns)
    raw=hns['hessian'](density,'primary',1,2)
    for kk,v in hns['hessian'](hns['source_density'](d),'primary',1,2).items():put(raw,kk,v)
    raw=clean(raw)
    for axis,q in [(3,1),(2,-1)]:
        value=literal(raw,axis,q,selected);expected=kernels[case].get(key,ZERO);assert value==expected,(case,key,axis,q,str(value),str(expected))
        fresh.append({'case':case,'indices':list(key),'axis':axis,'q':q,'coefficient':str(value),'literal_full_power_equal':True})
        print('STAGE ULD3 fresh uncut '+json.dumps(fresh[-1],sort_keys=True),flush=True)

reused=[]
for folder,label,receiptname,flag in [
 ('canonical_so10_unprobed_antighost_kernel','naCx','color_validation_receipt_v2.json','complete_group_heat_pole_prime_and_implicit_zero_agreement'),
 ('canonical_so10_unprobed_auxiliary_source_kernel','nJLCx','color_validation_receipt.json','full_heat_coefficients_and_implicit_zeros_agree')]:
    P=R/'calculations'/folder;assert read(P/receiptname)[flag];pair=[]
    for role in ['primary','replay']:
        pp=P/('color_'+role+'_tables.json.gz');assert H(pp)==read(P/('color_'+role+'_result.json'))['packed_sha256']
        z=loadz(pp);pair.append({tuple(v[:-1]):co(v[-1]) for v in z['F_m']['4']})
    assert pair[0]==pair[1] and all(0<=r<45 and 0<=h<45 and 0<=i<328 for r,h,i in pair[0])
    reused.append({'target':label,'native_heat':4,'domain':664200,'nonzero':len(pair[0]),'zero_complement':664200-len(pair[0]),'old_loop_freshly_replayed':False})
out={'schema':'ULD3_COMPLETE_C4_REVIEW_FRESH_UNCUT_AND_REUSE','whole_native_coefficients_and_implicit_zeros_equal':True,'counts':counts,
 'fresh_uncut_checks':fresh,'pure_uncut_helper_transform_counts':{'loop_length':loops,'Gaussian_weight':weights},
 'reused_intrinsic_C4':reused,'old_remainder_or_full_QAP_claim':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'kernel_review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({k:v for k,v in out.items() if k!='fresh_uncut_checks'},sort_keys=True),flush=True);timer.cancel()
