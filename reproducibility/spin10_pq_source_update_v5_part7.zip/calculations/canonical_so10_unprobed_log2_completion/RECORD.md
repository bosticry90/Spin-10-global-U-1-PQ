# ULD1-4: complete remaining log2 input, prospective

Base1c01161a62619675f742ede29da0069cd237e79c. Fresh preflight clean
main/no matching workers,current AGENTS/highestV655,actual UMC/ULS/UOR
receipts and UMC frozen-whitespace addendum read. Previous turn PROGRESS:
complete marginal C3 and declared F log3 closure. Goal ACTIVE/incomplete.
project_state sole authority,state113/34of39,E5/A5 OPEN,custodyexit2/
seven unresolved unchanged. Preserve all old evidence,including warnings.

Question: supply the remaining actual unprobed C0 input to the T/F log2
comparison,not infer it from the target. Native m-edge carrier is
chi4+log(m/2),m<=4,so log2=-C1-C3+C4. FIRST establish native one-edge
absence; this is not the separate cutoff C1 zero. Reuse authenticated
complete C3 images and measured intrinsic aCx/JLCx C4. The remaining
marginal JL a CC and JL JL CC four-edge terms must be calculated or
excluded in their own complete domain; C3 zeros do not transfer to C4.

Original unshifted SMA/CSW/EDS,A0,constant u in the operation,intrinsic0
marginal C0 kernels,intrinsic1 final T/F,external jets0 AFTER source/field
differentiation,symbolic g10/xi/eta_H,common hbar/(16pi^2),nonexceptional
Euclidean LOCAL RELATIVE DIM-minus-strict-heat UV symbol. No new physical
benchmark,reference,subtraction scheme,finite baseline or source phase.

ULD1: verify every actual UOR root has total engineering dimension4,
nonnegative intrinsic degree and polynomial local vertices. Each
fluctuation field has positive dimension>=1. A single classical Hessian
vertex carrying a complete dimension4 external target would require
internal momentum degree=-d_i-d_j<0. The original action contains no
inverse derivative vertex;free G0 is the fixed homogeneous unshifted
source-independent reference,not a mass-dependent resummation. This
excludes a native one-edge term in this scope. Do not extend it to a
shifted/massive amplitude or infer absence from an empty output.

At four edges the marginal target's external grade4 forces FOUR linear
vertices A1=G0 V1;no V2 or gradezero proper interaction fits. Reuse UMC's
fully reconstructed/qualified Lorentz and source-complete linear blocks,
not new truncation of an Euler column. Their vector ports are pinned;
no free D trace. Keep scalar/fermion/potential exclusions in owning scope.
The exact coefficient is -1/8 STr(A1^4). A2=A1^2 gives an independent
pair association. A source-rooted direct trace has multiplicity4/n_JL:
weight -1/(2 n_JL),n_JL=1 for JLaCC and2 for JJCC. Derive and test this
normalization with finite noncommuting graded exterior fixtures before
any model value. Preserve all odd signs and original starting supertrace.

ULD2: count actual complete four-edge coloured paths and freeze whole
jobs/resources after method/cost evidence. Primary uses every JL-rooted
path with the above multiplicity;replay precontracts A1^2 then traces
its square with -1/8. Separate canonical densities JL_r a_s C_h C_k,
h<k,and JL_r JL_s C_h C_k,r<s,h<k. No additional source/ghost half.
All45 labels,full tensors and implicit zeros,opposite operator routes/
axis/q. Native old-remainder and peer guards. A model zero must retain
complete support and cannot be borrowed from C3.

ULD3/4: qualify whole coefficients and fresh full-action uncut checks.
Apply all actual UOR QG/u operations,source degrees0/1/2 BEFORE
restriction,by component versus literal graded derivation. Reuse the
already qualified C3 images and intrinsic C4 with exact type/hash/
normalization ownership. Only after complete independent agreement may
the resulting log2 image be added ONCE to UCT's authenticated partial
log2 comparison. Preserve zero/nonzero results without fitting any input.

Initial method/native300s,review180s after imports,private8GiB sampled,
launch available-pagefile350MiB,total packet32MiB. Whole coefficient
budgets must be frozen after actual cost evidence,before launch. No
unlimited expansion,retry or truncation. Two sequential roles,no agents.
Freeze exact input/source bytes,exclusive outputs,owned PID/creation,
complete stdout and resource samples. Preserve failures/incompleteness.
E4 once without --fresh before eventual local commit;custodyexit2 is
NOTPASS. No old evidence/state change,promotion,protected activation,
foundation adoption,branch/worktree,remote push,publication or outreach.

Focused result-to-claim assessment in existing RESULT. Counts/precision
are not physical truth or completion%. Shared action/reference/charts,
curated inputs,Gaussian premises,helpers/software and AI author limit
independence;no external scientist,proof assistant or empirical validation.
chi4,b0,kappa,IR freedoms distinct/unfixed. Full defect-inclusive Ward/
master,common finitepart/products/contact/measure,QAP,source reality,
global phase,causal/massive/physical limits and viability remain open.
