# ULD3: whole C4 qualification,fresh checks and exact reuse, prospective

After both complete jobs finish,authenticate every native C4 coefficient,
canonical density sign and full zero complement. No C3 zero may be used
as a C4 value. Compare all2004750 JLaCC and980100 JJCC positions.

Freshly reconstruct full original-action GF/source Hessians with all
quantum/internal-jet ports,using the verified full GF density. Four
deterministic nonzero contexts where available plus two fixed contexts
PER kernel,axis3/q+ andaxis2/q-,are checked by literal FULL four-component
-1/8STr(GV)^4. Use all admissible linear/quadratic Hessians so nilpotent
target extraction itself excludes higher external grade. Explicitly
reuse the old pure literal uncut operator helper with loop length4 and
weight-1/8,not the new rooted/pair formula. This is a disclosed software
reuse,not an independent scientist or physical validation.

Authenticate AAK/UAK complete intrinsic aCx/JLCx C4 tables against old
native packed hashes and qualification receipts. Compare every old
coefficient/root term and implicit zero between their two methods.
Owning orders a Cx and JL Cx,common hbar/(16pi^2),original reference,
no extra half. Old loops are reused,not freshly replayed. Old rho/G
source images are not reused as u/QG operations.

Review180s,8GiB sampled,350MiB launchfloor,32MiB packet. No old desired
log2 remainder is read. A failed check preserves all sources/captures
and blocks only its affected qualification;do not change a sign or
normalization to make it pass. All authority/domain limits unchanged.
