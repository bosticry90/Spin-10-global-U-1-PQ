# ULD5: delegated E4 authentication, prospective

Execute python -B tools/research_check.py e4 exactly once before eventual
local commit;no --fresh. Preserve complete native capture and all JSON
events. Expected native0,six exits[0,0,0,0,0,2],terminalCOMPLETED,seven
unresolved historical references. Custodyexit2 is NOTPASS. Changed count
or any unexpected exit requires assessment. No full scientific replay or
authority promotion is inferred. Existing scientific acceptance is separate.

300s observed command budget,8GiB sampled owned-process private memory,
350MiB launch available-pagefile floor,32MiB packet. Do not terminate
unrelated processes or truncate checks. Final review authenticates actual
results and this frozen preparation. Preserve failure/incompleteness.
