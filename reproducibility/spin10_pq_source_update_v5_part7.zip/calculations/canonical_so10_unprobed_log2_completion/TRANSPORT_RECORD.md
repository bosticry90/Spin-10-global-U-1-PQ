# ULD4: actual complete log2 image, prospective

Proceed only after ULD3 complete C4 tensor/zero-complement comparison and
24 fresh full-action four-component checks. No old desired remainder is
an input to either native transport. Keep the original RECORD domain,
normalization, authority ceiling and all ten UOR root bounds.

Reuse the independently qualified complete C3 images: ULS known transport
and JaaC triangle plus UMC marginal transport. These are actual images,
not the negative of an observed comparison. At C4 only intrinsic aCx and
JLCx and marginal JLaCC/JLJLCC can reach four edges under the authenticated
root bounds. The first two use the authenticated prior measured F_m[4]
tensors; the second two use ULD2/3. C1 is excluded by ULD1 dimension proof.
Thus the native log2 image is -image(C3)+image(C4), with no C2 weight.

Primary: differentiate the owning density at each coordinate with the odd
Leibniz prefix. Replay: first canonicalize the complete physical-coordinate
density, apply the literal odd derivation, then canonicalize again. Use
actual UOR u flows for each probe/target with source differentiation before
restriction; retain source-degree provenance. No rho/G replacement and no
extra source/ghost half. Include nonzero fixtures for the JL prefix, both
JJ source positions and the two intrinsic first-position operations.

Both routes use their own qualified input tensors and images. Authenticate
prior ownership receipts and packed hashes. Guard peer/old target reads.
Retain C3, C4, complete log2 and all four C4 groups, including zeros, over
full T/F position domains. A nonzero result is permissible evidence; it is
not a failed execution. No coefficient fitting or baseline selection.

Two sequential native jobs,300s each after imports,aggregate600s,private
8GiB sampled,launch available-pagefile350MiB,packet32MiB. Preserve complete
sources/copies/preparation,owned process capture and failures. A later
180s review may read the authenticated UCT partial log2 only AFTER native
agreement,then add the complete new image ONCE. Freeze that review before
launch. Full finite Ward/master,common products/QAP/measure/source reality/
causal or physical claims remain unqualified. chi4,b0,kappa,IR stay distinct.
