from pathlib import Path
from hashlib import sha256
import gzip,json,os,threading,time
from quartic_core import *

tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest()
for pp,h in read(O/'log2_review_preparation.json')['input_sha256'].items():assert H(Path(pp))==h,pp

def unpack(rows):
    out={tuple(z[:-1]):coeff(z[-1]) for z in rows};assert len(out)==len(rows) and all(out.values());return out

def add(A,B,weight=1):
    M=dict(A)
    for k,v in B.items():put(M,k,v*weight)
    return clean(M)

ab=[]
for role in ['primary','replay']:
    pp=O/('transport_'+role+'_tables.json.gz');assert H(pp)==read(O/('transport_'+role+'_result.json'))['packed_sha256'];ab.append(loadz(pp))
assert ab[0]['results']==ab[1]['results']
assert all(z['guard_denials']==4 and z['nonzero_graded_sign_fixtures']==5 and not z['old_desired_remainder_read'] for z in ab)
images={};coverage=[];groups_by={};C3={}
for z in ab[0]['results']:
    key=(z['probe'],z['target']);assert key not in images
    groups={name:unpack(rows) for name,rows in z['C4_groups'].items()};c4={}
    for name,M in groups.items():
        assert len(M)==z['C4_group_nonzero_counts'][name];c4=add(c4,M)
    c3=unpack(z['C3_image']);log2=add(c4,c3,-1)
    assert c4==unpack(z['C4_image']) and log2==unpack(z['log2_image'])
    assert [len(c3),len(c4),len(log2)]==[z['C3_nonzero'],z['C4_nonzero'],z['log2_nonzero']]
    domain=(45*45 if z['target']=='T' else 45*990)*328
    assert domain==z['domain_positions']==len(log2)+z['log2_zero_complement']
    for M in [c3,c4,log2]+list(groups.values()):
        if z['target']=='T':assert all(0<=a<45 and 0<=h<45 and 0<=i<328 for a,h,i in M)
        else:assert all(0<=a<45 and 0<=h<k<45 and 0<=i<328 for a,h,k,i in M)
    images[key]=log2;groups_by[key]=groups;C3[key]=c3
    coverage.append({k:v for k,v in z.items() if k not in ['C4_groups','C3_image','C4_image','log2_image']})
assert set(images)=={(p,t) for p in range(2) for t in ['T','F']}

u=loadz(R/'calculations/canonical_so10_u_operation_root_inventory/root_primary_tables.json.gz')
m=read(O/'method_result.json');proof={(tuple(z['types']),z['intrinsic_degree']):z for z in m['native_root_dimension_proof']}
actual={(tuple(p),nu) for row in u['results'] for ops in row['targets'].values() for p,nu,count in ops['nonzero_flows_by_root']}
assert actual==set(proof) and len(actual)==10
assert all(z['native_C1']=='EXCLUDED_BY_POLYNOMIAL_DIMENSION' and z['required_one_Hessian_momentum_degree_upper_bound']<0 and z['total_engineering_dimension']==4 for z in proof.values())
c4={(p,nu) for p,nu in actual if len(p)+nu>=4}
assert c4=={(('C','C','JL','JL'),0),(('C','C','JL','a'),0),(('C','JL','x'),1),(('C','a','x'),1)}
assert all(len(p)+nu<=4 for p,nu in actual)
assert m['native_log2_weights_by_heat']=={'1':-1,'2':0,'3':-1,'4':1}
reuse=read(R/'calculations/canonical_so10_unprobed_log3_support/review_result.json')
assert reuse['old_actual_qualified_tensors_authenticated_and_compared']
for target in ['JaJLC','nJax']:assert next(z for z in reuse['six_roots_reused_or_support_zero'] if z['target']==target)['nonzero']==0

# The old numerical comparison is first decoded only after whole native
# equality, independent reassembly and complete root coverage above.
P=R/'calculations/canonical_so10_u_lower_cutoff_contraction';pp=P/'late_remainders.json.gz'
rel=str(pp.relative_to(R)).replace('\\','/');assert H(pp)==read(P/'final_review_validation_receipt.json')['new_files_sha256'][rel]
old=loadz(pp);late=[];saved=[]
for probe in range(2):
    for target in ['T','F']:
        key=(probe,target);z=next(row for row in old if row['basis']=='log2' and row['probe']==probe and row['case']==target)
        previous=unpack(z['remainders']);combined=add(previous,images[key]);groups=groups_by[key]
        omission={name:len(add(combined,M,-1)) for name,M in groups.items()}
        wrong_prefix=add(combined,groups['JLaCC'],-2);duplicate_JJ=add(combined,groups['JLJLCC']);wrong_C3=add(combined,C3[key],2)
        late.append({'probe':probe,'target':target,'basis':'log2','domain_positions':(45*45 if target=='T' else 45*990)*328,
          'previous_partial_nonzero':len(previous),'complete_native_image_nonzero':len(images[key]),'complete_declared_sum_nonzero':len(combined),
          'complete_declared_sum_zero':not combined,'omit_C4_group_sum_nonzero':omission,'reverse_JLa_C4_odd_prefix_sum_nonzero':len(wrong_prefix),
          'duplicate_two_JL_C4_sum_nonzero':len(duplicate_JJ),'reverse_C3_sign_sum_nonzero':len(wrong_C3),'native_image_owned_once':True,
          'full_Ward_QAP_or_physical_claim':False})
        saved.append({'probe':probe,'target':target,'basis':'log2','sum':encode(combined)})
payload={'schema':'ULD4_COMPLETE_DECLARED_T_F_LOG2_COMPARISON','results':late,'tensors':saved,'cancellation_required_for_execution_PASS':False,'full_Ward_claim':False}
blob=gzip.compress((json.dumps(payload,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/'log2_complete_comparison.json.gz').open('xb') as f:f.write(blob)
out={'schema':'ULD4_COMPLETE_ACTUAL_IMAGE_AND_LOG2_REVIEW','complete_images_and_zero_complements_equal':True,'coverage':coverage,
 'all_ten_actual_UOR_roots_and_four_C4_candidates_accounted_for':True,'late_complete_declared_log2_comparisons':late,
 'packed_comparison_sha256':sha256(blob).hexdigest(),'scientific_disposition':'COMPLETE_DECLARED_LOG2_ZERO' if all(z['complete_declared_sum_zero'] for z in late) else 'COMPLETE_DECLARED_LOG2_NONZERO',
 'no_new_full_Ward_QAP_or_scientific_promotion':True,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'log2_review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
