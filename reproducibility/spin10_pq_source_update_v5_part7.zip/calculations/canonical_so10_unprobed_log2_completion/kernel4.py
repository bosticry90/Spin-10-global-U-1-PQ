from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from fractions import Fraction
import gzip,json,os,sys,threading,time
from quartic_core import *
from cubic_core import complementary_types
role=sys.argv[1];assert role in ['primary','replay']
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes())
for pp,h in read(O/'whole_preparation.json')['input_sha256'].items():assert sha256(Path(pp).read_bytes()).hexdigest()==h,pp
peer='replay' if role=='primary' else 'primary'
def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        pp=Path(os.fsdecode(args[0]))
        if pp.parent.resolve()==O and (pp.name.startswith('kernel4_'+peer) or pp.name.startswith('kernel_review')):raise PermissionError('ULD_PEER_DENIED')
        if pp.parent.name in ['canonical_so10_u_lower_cutoff_contraction','canonical_so10_u_pair_contact_model'] or pp.parent.name=='canonical_so10_unprobed_log3_support' and pp.name.startswith(('partial_','transport_review')):raise PermissionError('ULD_OLD_TARGET_DENIED')
sys.addaudithook(guard);denials=0
for pp in [O/('kernel4_'+peer+'_tables.json.gz'),R/'calculations/canonical_so10_unprobed_log3_support/partial_after_known.json.gz',R/'calculations/canonical_so10_u_lower_cutoff_contraction/late_remainders.json.gz']:
    try:pp.read_bytes()
    except PermissionError:denials+=1
assert denials==3
T=linear(role);M={'JLaCC':{},'JLJLCC':{}};work=Counter();pairwork=0;pairentries=0
if role=='primary':
    for case,i,j,k,l,r,a,b,c,word,sg,v,x,y,z in rooted_paths(T):
        nsource=sum(external_type(k)=='JL' for k in word)
        name,key,owner=owning_key(word);assert name==case
        put(M[case],key,(v*x*y*z)*constant(Fraction(-owner*sg*((-1)**int(i>=NB)),2*nsource)))
        work[case]+=1
    expected=next(z for z in read(O/'method_result.json')['four_edge_cost'] if z['role']==role)['rooted_colored_paths']
    assert dict(work)==expected
else:
    Q,pairwork=pair_product(T,'reverse');pairentries=len(Q);by=defaultdict(list)
    for (i,j,w),v in Q.items():by[i,j,tuple(sorted(external_type(k) for k in w))].append((w,v))
    for (i,j,w),v in Q.items():
        possible={tuple(sorted(p)) for p in complementary_types(w)}
        for tags in possible:
            for u,x in by[j,i,tags]:
                word,sg=merge(w+u)
                if not sg:continue
                case=target(word)
                if case is None:continue
                name,key,owner=owning_key(word);assert name==case
                put(M[case],key,(v*x)*constant(Fraction(-owner*sg*((-1)**int(i>=NB)),8)))
M={case:clean(v) for case,v in M.items()};results=[]
for case,values in M.items():
    domain=45*45*990 if case=='JLaCC' else 990*990
    for r,s,h,k in values:
        assert 0<=r<45 and 0<=s<45 and 0<=h<k<45
        if case=='JLJLCC':assert r<s
    results.append({'case':case,'domain_positions':domain,'total':encode(values),'nonzero':len(values),'zero_complement':domain-len(values)})
out={'schema':'ULD2_COMPLETE_MARGINAL_FOUR_EDGE_KERNELS','role':role,'results':results,'guard_denials':denials,
 'primary_rooted_path_counts':dict(work),'replay_pair_products':pairwork,'replay_nonzero_tagged_pair_entries':pairentries,
 'normalization':'hbar/(16pi^2); -1/8STr(A1^4); no extra density half','old_remainder_or_full_QAP_claim':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/('kernel4_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),
 'counts':[{k:v for k,v in z.items() if k!='total'} for z in results],'guard_denials':denials},sort_keys=True),flush=True);timer.cancel()
