from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import Counter,defaultdict
import gzip,json,os,threading,time
from quartic_core import *
from blocks import OP
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()))
for pp,h in read(O/'preparation.json')['input_sha256'].items():assert sha256(Path(pp).read_bytes()).hexdigest()==h,pp
u=loadz(R/'calculations/canonical_so10_u_operation_root_inventory/heat_bound_tables.json.gz')
dims={'C':1,'a':1,'x':1,'L':2,'Ja':2,'JL':1,'Jx':2}
quantum_dimensions=[OP.dimension(i) for i in range(643)]
minimum_quantum_dimension=min(quantum_dimensions);assert minimum_quantum_dimension>=1
roots=[]
for pat,nu,maxedges in u['all_actual_root_types_and_grade_bounds']:
    total=nu+sum(dims[k] for k in pat);assert total==4 and nu>=0 and maxedges<=4
    roots.append({'types':pat,'intrinsic_degree':nu,'total_engineering_dimension':total,'required_one_Hessian_momentum_degree_upper_bound':-2*minimum_quantum_dimension,'native_C1':'EXCLUDED_BY_POLYNOMIAL_DIMENSION'})
assert len(roots)==10
# Native heat map is separate from the ordered cutoff heat-pair map.
def valuation2(m):
    n=0
    while m%2==0:n+=1;m//=2
    return n
weights={str(m):valuation2(m)-1 for m in range(1,5)}
assert weights=={'1':-1,'2':0,'3':-1,'4':1}

def mul(A,B,commuting=False):
    out=defaultdict(Fraction)
    for (i,j,w),v in A.items():
        for (k,l,z),x in B.items():
            if j!=k or set(w)&set(z):continue
            sg=1 if commuting else (-1)**sum(a>b for a in w for b in z)
            out[i,l,tuple(sorted(w+z))]+=v*x*sg
    return {k:v for k,v in out.items() if v}
def tr(A,ordinary=False):return sum((v*(1 if ordinary else (-1)**int(i>=2)) for (i,j,w),v in A.items() if i==j and w==(0,1,2,3)),Fraction())
fixtures=[];controls=Counter()
for seed in [1,2,3]:
    V={}
    for i in range(4):
        for j in range(4):
            if (i>=2)==(j>=2):continue
            for a in range(4):V[i,j,(a,)]=Fraction((seed+2*i+3*j+5*a)%11-5)
    P=mul(V,V);P3=mul(P,V);full=-tr(mul(P3,V))/8;paired=-tr(mul(P,P))/8;assert full==paired
    rooted=[]
    for source_labels in [{0},{0,1}]:
        L={k:v for k,v in V.items() if k[2][0] in source_labels}
        z=-tr(mul(L,P3))/Fraction(2*len(source_labels));assert z==full
        rooted.append(str(z))
    ordinary=-tr(mul(P,P),True)/8;controls['ordinary_trace']+=ordinary!=full
    C=mul(V,V,True);wrong=-tr(mul(C,C,True))/8;controls['commuting_exterior']+=wrong!=full
    bad=-tr(mul({k:v for k,v in V.items() if k[2][0] in [0,1]},P3))/2;controls['omit_double_source_root_divisor']+=bad!=full
    fixtures.append({'seed':seed,'full':str(full),'paired':str(paired),'single_and_double_source_rooted':rooted})
assert any(Fraction(z['full']) for z in fixtures) and all(controls.values()),(fixtures,controls)
counts=[]
for role in ['primary','replay']:
    T=linear(role);start=time.perf_counter();C=Counter();types=Counter()
    for case,i,j,k,l,r,a,b,c,word,sg,v,x,y,z in rooted_paths(T):
        assert all(sector(q) in ['B','L','C','a'] for q in [i,j,k,l])
        C[case]+=1;types[case,tuple(external_type(q) for q in [r,a,b,c])]+=1
        # Rooted cycles retain every original external and supertrace sign.
        seq=(r,a,b,c);path=(i,j,k,l)
        signs=[((-1)**int(path[n]>=NB))*merge(seq[n:]+seq[:n])[1] for n in range(4)]
        assert len(set(signs))==1
    counts.append({'role':role,'linear_entries':len(T),'rooted_colored_paths':dict(C),'rooted_type_orders':[[case,list(order),n] for (case,order),n in sorted(types.items())],'seconds':time.perf_counter()-start})
assert counts[0]['rooted_colored_paths']==counts[1]['rooted_colored_paths']
out={'schema':'ULD1_NATIVE_ONE_EDGE_EXCLUSION_AND_QUARTIC_METHOD','native_root_dimension_proof':roots,'native_log2_weights_by_heat':weights,
 'different_cutoff_C1_zero_not_used':True,'fixed_unshifted_homogeneous_reference_required':True,'finite_graded_fixtures':fixtures,'sensitive_controls':dict(controls),
 'four_edge_cost':counts,'Gaussian_normalization_inherited':True,'quantum_coefficient_or_old_remainder_operand':False,'elapsed_after_imports':time.perf_counter()-tick}
with (O/'method_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
