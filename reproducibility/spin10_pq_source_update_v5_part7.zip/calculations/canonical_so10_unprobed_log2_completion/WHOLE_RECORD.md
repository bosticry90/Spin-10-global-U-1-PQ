# ULD2: complete marginal C4 tensors, prospective

ULD1 qualified native C1 absence and finite graded four-edge normalization.
Complete actual rooted paths agree in both old action-derivative routes:
JL a CC266648,JL JL CC259468,from7490 linear operator entries. Only
rooted type orders JL,C,a,C and JL,C,JL,C survive actual colour support.
The JJ C3 zero clearly does NOT exclude these fourth-edge paths. No
quantum coefficient has been inferred from this support count.

Freeze TWO sequential complete native jobs,300s/role after imports,
aggregate600s,private8GiB sampled,launch available-pagefile350MiB,
total packet32MiB. Actual full path counting took13.43/13.29s. Whole
coefficient/implicit-zero evidence must be complete;no truncation or
partial success on resource exhaustion. Preserve failures/incompleteness.

Primary sums each actual JL-rooted four-edge path,original starting
supertrace and exterior sign,weight -1/(2 n_JL). Replay independently
precontracts the entire tagged A1^2 then evaluates -1/8 STr[(A1^2)^2].
Use opposite qualified operator derivative routes and axis3/q+ versus
axis2/q-. All7490 actual linear entries retained;no repeated old
operator reconstruction or arbitrary width/auxiliary-current simplification.

Canonical densities JL_r a_s C_h C_k,h<k and JL_r JL_s C_h C_k,
r<s,h<k; source JL,a,C all odd. Convert physical sorted words with
MINUS/PLUS respectively,no extra source/ghost half. Domains2004750
and980100. Preserve complete native tensors and zero complements.
After agreement,use fresh full-action uncut -1/8STr(GV)^4 checks before
actual UOR transport and any late log2 comparison. Peer/target guards.
Scientific authority/domain/normalization limits in RECORD unchanged.
