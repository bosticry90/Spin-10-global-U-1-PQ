from pathlib import Path
from hashlib import sha256
import ast,gzip,json,os,subprocess,threading,time
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-log2-completion-v1-2026-10-26')
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
bindings={};preps=[]
for prep in sorted(O.glob('*preparation*.json')):
    preps.append(prep.name)
    for pp,h in read(prep)['input_sha256'].items():
        assert H(Path(pp))==h,(prep.name,pp)
        if pp in bindings:assert bindings[pp]==h
        bindings[pp]=h
copies=list(O.glob('*.source.txt'))
for pp in copies:assert pp.read_bytes()==pp.with_name(pp.name[:-11]).read_bytes(),pp
for pp in O.glob('*.py'):ast.parse(pp.read_bytes())
for pp in O.iterdir():
    if pp.suffix in ['.py','.md','.txt']:assert all(line==line.rstrip(b' \t') for line in pp.read_bytes().splitlines()),pp
complete=[];largest=0
for pp in sorted(O.glob('*_capture.json')):
    z=read(pp)
    assert z['execution_state']=='COMPLETED' and z['exit_code']==0 and z['calculation_completed'] and z['post_run_observations_qualified'],pp
    assert not z['failed_or_incomplete_counted_as_PASS'] and z['launch']['creation_after_observation']
    assert z['launch']['memory']['available_pagefile']>=350*1024**2
    assert z['all_resource_samples'] and all(0<v['private_bytes']<=8*1024**3 and 'query_error' not in v for v in z['all_resource_samples'])
    largest=max(largest,max(v['private_bytes'] for v in z['all_resource_samples']));complete.append(pp.name)
assert len(complete)==8 and not list(O.glob('*controller_failure*.json'))
for name in ['method_result','kernel4_primary_result','kernel4_replay_result','transport_primary_result','transport_replay_result']:
    assert read(O/(name+'.json'))['elapsed_after_imports']<300
for name in ['kernel_review_result','log2_review_result']:assert read(O/(name+'.json'))['elapsed_after_imports']<180
w=read(O/'whole_execution_result.json');assert w['aggregate_after_imports_seconds']<=w['aggregate_budget_seconds']==600
w=read(O/'transport_execution_result.json');assert w['aggregate_after_imports_seconds']<=w['budget_seconds']==600
m=read(O/'method_result.json');k=read(O/'kernel_review_result.json');t=read(O/'log2_review_result.json')
assert len(m['native_root_dimension_proof'])==10 and m['sensitive_controls']=={'commuting_exterior':2,'omit_double_source_root_divisor':2,'ordinary_trace':2}
assert k['whole_native_coefficients_and_implicit_zeros_equal'] and len(k['fresh_uncut_checks'])==24 and len(k['reused_intrinsic_C4'])==2
assert t['complete_images_and_zero_complements_equal'] and t['all_ten_actual_UOR_roots_and_four_C4_candidates_accounted_for']
assert t['scientific_disposition'] in ['COMPLETE_DECLARED_LOG2_ZERO','COMPLETE_DECLARED_LOG2_NONZERO']
assert t['no_new_full_Ward_QAP_or_scientific_promotion']
if t['scientific_disposition']=='COMPLETE_DECLARED_LOG2_ZERO':
    assert all(z['complete_declared_sum_zero'] and not z['complete_declared_sum_nonzero'] for z in t['late_complete_declared_log2_comparisons'])
for z in t['late_complete_declared_log2_comparisons']:
    if z['probe']==1:
        assert z['reverse_C3_sign_sum_nonzero']>0
        if z['target']=='F':assert z['reverse_JLa_C4_odd_prefix_sum_nonzero']>0 and z['duplicate_two_JL_C4_sum_nonzero']>0
oldlogs=[]
for folder,name in [('canonical_so10_unprobed_log3_support','T_log3_complete_comparison_v2.json.gz'),('canonical_so10_unprobed_marginal_C3','F_log3_complete_comparison.json.gz')]:
    P=R/'calculations'/folder;pp=P/name;rel=str(pp.relative_to(R)).replace('\\','/')
    assert H(pp)==read(P/'final_review_validation_receipt.json')['new_files_sha256'][rel]
    z=json.loads(gzip.decompress(pp.read_bytes()));assert all(not row['sum'] for row in z['tensors']);oldlogs.append({'file':rel,'sha256':H(pp),'old_loop_freshly_replayed':False})
events=read(O/'e4_events.json');steps=[z for z in events if z['event']=='step_finished']
assert [z['exit_code'] for z in steps]==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested']
assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout'] and read(O/'e4_capture.json')['elapsed_seconds']<300
git=lambda *args:subprocess.run(['git',*args],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()=='1c01161a62619675f742ede29da0069cd237e79c'
assert git('branch','--show-current').decode().strip()=='main'
assert git('ls-tree','-r','--full-tree','HEAD')==(C/'old_git_tree.txt').read_bytes()
git('diff','--quiet','HEAD','--')
state=H(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
size=sum(p.stat().st_size for p in O.rglob('*') if p.is_file());assert size<32*1024**2
out={'schema':'ULD5_FINAL_BOUNDED_EVIDENCE_REVIEW','preparation_bindings_authenticated':len(bindings),'preparations':preps,'source_copies_equal':len(copies),
 'completed_captures_authenticated':complete,'largest_successful_sampled_private_bytes':largest,'packet_bytes_before_final_capture_and_seal':size,
 'bounded_evidence_validation':'PASS_WITHIN_FROZEN_SCOPE','declared_log2_disposition':t['scientific_disposition'],'prior_log3_authentication':oldlogs,
 'full_Ward_QAP_or_E5_claim':False,'native_C2_and_baseline_not_supplied_by_prime_logs':True,'E4_step_exits':[z['exit_code'] for z in steps],
 'custody':'EXIT2_SEVEN_UNRESOLVED_NOTPASS','old_tracked_tree_and_state_unchanged':True,'state_sha256':state,'scientific_acceptance':'NOT_PERFORMED','elapsed_after_imports':time.perf_counter()-tick}
with (O/'final_review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
