from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-log2-completion-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
    with p.open('xb') as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings=dict(read(O/'whole_preparation.json')['input_sha256'])
    for pp,h in bindings.items():assert H(Path(pp))==h,pp
    rels=['calculations/canonical_so10_unprobed_marginal_C3/kernel_review.py',
      'calculations/canonical_so10_u_maximal_heat_cutoff/primary_inputs.json.gz']
    for folder,receipt in [('canonical_so10_unprobed_antighost_kernel','color_validation_receipt_v2.json'),('canonical_so10_unprobed_auxiliary_source_kernel','color_validation_receipt.json')]:
        rels.append('calculations/'+folder+'/'+receipt)
        for role in ['primary','replay']:
            rels.extend(['calculations/'+folder+'/color_'+role+'_tables.json.gz','calculations/'+folder+'/color_'+role+'_result.json'])
    for rel in rels:
        pp=R/rel;bindings[str(pp)]=H(pp)
    for name in ['KERNEL_REVIEW_RECORD.md','kernel_review.py','run_kernel_review.py']:
        pp=O/name
        if pp.suffix=='.py':ast.parse(pp.read_bytes())
        assert all(line==line.rstrip(b' \t') for line in pp.read_bytes().splitlines()),name
        with (O/(name+'.source.txt')).open('xb') as f:f.write(pp.read_bytes())
    for pp in O.iterdir():
        if pp.is_file():bindings[str(pp)]=H(pp)
    dump(O/'kernel_review_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    z=capture([sys.executable,'-B',str(O/'kernel_review.py')]);dump(O/'kernel_review_capture.json',z);dump(C/'kernel_review_full_capture.json',z)
    assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified']
    assert read(O/'kernel_review_result.json')['elapsed_after_imports']<180
    print('COMPLETED ULD3 whole C4 qualification',flush=True)
except BaseException:
    dump(O/'kernel_review_controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
