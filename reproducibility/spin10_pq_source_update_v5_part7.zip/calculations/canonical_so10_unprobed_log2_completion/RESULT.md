# Complete declared T/F log2 relations close without fitting

The remaining marginal four-edge unprobed kernels are measured. Their
actual graded u images,combined with the authenticated complete C3 and
intrinsic C4 inputs,cancel the previously retained log2 remainders in
BOTH declared T/F channels and BOTH probes. No source sign,coupling,
unknown quantum coefficient or finite baseline was chosen from a remainder.

This is PROGRESS in the original fixed-reference formal coefficient
problem. It is not full finite Ward restoration,QAP,E5/A5 or empirical
validation. project_state remains sole authority,state113/34of39,E5/A5
OPEN,custodyexit2/seven unresolved NOTPASS. Goal ACTIVE/incomplete;
director scientific acceptance NOT_PERFORMED.

## Scope and evidence

Original unshifted SMA/CSW/EDS,A0,constant u,intrinsic0/1 C0 roots from
the actual UOR inventory,final intrinsic1 T/F,external jets0 AFTER source
and field differentiation,symbolic g10/xi/eta_H,common hbar/(16pi^2).
The domain is the nonexceptional Euclidean LOCAL RELATIVE
DIM-minus-strict-positive-heat UV symbol. No shifted/massive reference,
physical scaleless p=0 amplitude or changed subtraction scheme is used.

[Prospective record](RECORD.md),[method](method_result.json),
[C4 qualification](kernel_review_result.json),
[actual-image and late comparison](log2_review_result.json),
[exact final tensors](log2_complete_comparison.json.gz).
Preparations freeze sources and input hashes; complete captures own
execution/resource states. Authenticated old quantum inputs are reused,
not claimed as freshly replayed loops.

## One-edge exclusion and the complete four-edge calculation

Every one of the ten actual C0 root types has total engineering dimension4.
All fluctuation fields have positive dimension at least1. A single local
classical Hessian carrying the full external target would require negative
polynomial momentum degree at most-2. The actual action has no such
inverse-derivative vertex. With the fixed homogeneous,source-independent,
unshifted free reference this excludes the native C1 term. This is a new
native exclusion,not an import of the DIFFERENT ordered-cutoff C1 zero.
It does not apply automatically after a massive resummation.

The native m-edge carrier is chi4+log(m/2). The root heat ceiling is4,so

    native log2 = -C1-C3+C4 = -C3+C4.

For the two marginal grade4 roots,C4 is -1/8 STr(A1^4),with four linear
vertices. Reuse the qualified FULL source/GF Hessians and Lorentz port
reconstruction from UMC;their7490 linear reduced entries retain every
required port. No new Euler-column-only truncation is used.

Primary traces every JL-rooted coloured path. Its weight is-1/(2 n_JL),
with n_JL=1 or2. Replay independently precontracts A1^2 and traces its
square with-1/8. Noncommuting exterior fixtures derive/test the cyclic
multiplicity before model coefficients are calculated. Ordinary-trace,
commuting-exterior and omitted double-source-root-divisor controls each
detect two of three fixtures;the zero fixture is explicitly insensitive.

| Actual C4 class | Closed JL-rooted paths | Domain | Nonzero | Zero complement |
| --- | ---: | ---: | ---: | ---: |
| JLaCC |266648|2004750|16582|1988168|
| JLJLCC |259468|980100|5470|974630|

Both full tensors and implicit zeros agree. Owning densities are
JL_r a_s C_h C_k,h<k,and JL_r JL_s C_h C_k,r<s,h<k,without another
source/ghost half. Unlike the earlier C3 result,the two-JL C4 tensor is
NONZERO. A C3 structural zero was not transferred to a new edge order.
Examples are K_JLa[13,12,12,13]=16i g10^3 xi/25 and
K_JJ[13,14,13,14]=9g10^4/25 in the stated normalization.

Twenty-four new literal full-action four-component checks agree:four
nonzero plus two fixed zero contexts for each class,both momentum/axis
orientations. They use the unrooted full fourth power,not either reduced
contraction. Its pure uncut helper is inherited with two explicit AST
changes,loop length3->4 and Gaussian factor1/6->-1/8. It shares classical
inputs and infrastructure;these checks do not independently establish
the physical action or the continuum regulator construction.

## Actual u operation and late comparison

The C4 T inputs are the previously qualified intrinsic aCx and JLCx
tensors,10584 and9632 nonzero positions over664200 each. Their complete
old coefficient tables,implicit zeros and qualification flags are
authenticated/compared;the loops are not freshly run. C3 uses ULS known
transport plus its JaaC triangle and UMC marginal transport. Those are
actual measured images,not negatives inferred from a cancellation.

All actual UOR flows and source-degree0/1/2 provenance are retained before
restriction. Primary differentiates each owning density with its odd
prefix;replay first canonicalizes the full density,then applies literal
graded Leibniz differentiation. Five nonzero fixtures test the JL prefix,
both two-JL source positions and the two intrinsic source derivatives.
Native guards reject peer and old-comparison reads. Full C3,C4,all C4
groups and log2 images agree before the old remainder is decoded.

| Probe1 image | T nonzero | F nonzero |
| --- | ---: | ---: |
| Complete C3 |10632|121600|
| C4 from intrinsic aCx |10584|0|
| C4 from intrinsic JLCx |9632|0|
| C4 from JLaCC |0|119896|
| C4 from JLJLCC |0|64816|
| Complete C4 sum |10584|127048|
| Complete -C3+C4 |10784|127184|

Every probe0 image is zero after actual contraction,including its nonempty
T operation flows. The T/F full domains per probe are664200/14612400.
Counts overlap and are algebraic positions,not independent integrals,
particles,experiments or an investigation-completion percentage.

Only after whole native agreement and ten-root/four-C4-candidate coverage
does review read UCT's authenticated previous comparison. That table owns
the prior partial conversion PLUS the COMPLETE ordered-cutoff input and
does not own B_u C0. The new image is added ONCE:

| Probe1 log2 relation | Previous partial | New actual image | Final nonzero |
| --- | ---: | ---: | ---: |
| T |10784|10784|0|
| F |127184|127184|0|

These are coefficientwise equalities,including all implicit zeros,not
equality of counts. Probe0 sums are also zero. Cancellation was not an
execution acceptance requirement;any nonzero full sum would be preserved.

On probe1 T,omitting the two intrinsic C4 groups leaves10584/9632
positions;reversing the C3 sign leaves10632. On probe1 F,omitting JLaCC
or JLJLCC leaves119896/64816;reversing the JLa prefix leaves119896;
duplicating the two-JL root leaves64816;reversing C3 leaves121600.
Probe0 and out-of-channel group controls remain insensitive. These are
specific error detectors,not evidence for errors they cannot test.

## Focused result-to-claim assessment

**Evidence to supported claim.** Complete action-derived tensors,two
contraction associations,24 uncut checks,independent graded source
derivations and late full-domain comparison support the complete declared
T/F log2 identities in this fixed formal domain. Earlier qualified log3
and log5 coefficient relations are retained. Together they remove the
explicit-prime-log gaps;they do not calculate the remaining carriers.

**Missing bridge and alternatives.** chi4 multiplies the unweighted native
sum C2+C3+C4,whereas these logarithmic tests only constrain weighted
combinations. Native C2 is invisible to log2/log3 and has NOT been supplied
by this packet. Algebraic dimensional terms and the common continuum
product/variation/reference/measure/source-reality/global-phase/QAP and
causal/physical applicability also remain separate. A formal cancellation
cannot substitute for any of those constructions. chi4,b0,kappa and IR
freedoms stay distinct and unselected. A later nonzero remainder must be
assessed with its complete required terms before any anomaly verdict.

**Significance and shared limits.** The calculation resolves a complete
missing logarithmic class and demonstrates why the previously zero
two-JL C3 class must be recomputed at C4. It corroborates structural
reduction,graded signs and exact-once source accounting. Action,reference,
charts,coefficient ring,Gaussian premises,curated inputs,helpers,software
and AI authorship remain shared. No outside scientist,proof assistant,
new external literature validation or empirical test is claimed. The
methodology links verification to interpretation without an additional
ledger,score,approval gate or scientific promotion.

**Next discriminating action.** Reuse the existing native C2 and pole
records first;identify the smallest missing complete C2/root block needed
for the unweighted baseline coefficient. The marginal C4 calculation does
not supply it. Existing AAK/UAK heat2,IQC intrinsic/auxiliary and USR
source-root records are candidate reused inputs,subject to exact matching.
The earlier38-class theorem concerns the authenticated retained-source
local-pole functional and qR+Rq;its own RECORD explicitly defers source-
lowering/source-free obligations. It cannot automatically certify this
augmented u operation. Match the actual operator,source filtration and
input coefficients before importing that premise. If no such implication
applies,derive the missing C2 block from the actual action,then evaluate
the unweighted relation without setting chi4. Keep the quantum applicability
bridge explicit throughout;do not restart a broad coefficient catalogue.

## Execution, preservation and authority

After-import seconds:method29.9917,C4primary34.2711/replay52.6890
(aggregate86.9601<600),kernelreview15.6163,transport24.8115/25.5317
(aggregate50.3432<600),late review23.4041. All seven scientific captures
completed/native0 on their frozen first versions. Largest pre-final
sampled private allocation1369088000B is not a continuous peak. Limits
native300s/review180s,8GiB sampled,350MiBlaunchfloor,32MiBpacket apply.
Complete stdout,PID/creation/resource observations and source copies are
retained. Recovery authenticated the completed kernel review instead of
rerunning it when its original tool output was unavailable.

E4 is requested exactly once,without --fresh;actual events and final
receipt own completion. Expected native0,six steps[0,0,0,0,0,2],terminal
COMPLETED,custodyexit2/seven NOTPASS. This is sealed-byte authentication
and bounded audits,not fresh whole-project replay. Final review authenticates
all preparations,sources,captures,old tree and state before local commit.
No earlier source,receipt,failure or whitespace warning is changed.

State SHA256 remains
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8.
No foundation,benchmark,scheme or normalization adoption;no protected
flavor/HB1/C5 activation,promotion,agents,branch/worktree,remote push,
publication or outreach. Broader scalar/gauge/failed-benchmark physical
questions remain in their qualified historical scopes. This report is
frozen before the final evidence review.
