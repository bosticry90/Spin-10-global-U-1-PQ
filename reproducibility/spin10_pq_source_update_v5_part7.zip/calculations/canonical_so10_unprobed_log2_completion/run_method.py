from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys,traceback
O=Path(__file__).resolve().parent;R=O.parents[1]
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/unprobed-log2-completion-v1-2026-10-26')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def dump(p,z):
    with p.open('xb') as f:f.write((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    C.mkdir(exist_ok=False)
    head=subprocess.run(['git','rev-parse','HEAD'],stdout=subprocess.PIPE,check=True).stdout.decode().strip();assert head=='1c01161a62619675f742ede29da0069cd237e79c'
    with (C/'old_git_tree.txt').open('xb') as f:f.write(subprocess.run(['git','ls-tree','-r','--full-tree','HEAD'],stdout=subprocess.PIPE,check=True).stdout)
    rels=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V655.md',
      'calculations/canonical_so10_unprobed_marginal_C3/final_review_validation_receipt.json','calculations/canonical_so10_unprobed_marginal_C3/commit_review_seal.json',
      'calculations/canonical_so10_unprobed_marginal_C3/COMMIT_REVIEW_ADDENDUM.md','calculations/canonical_so10_unprobed_marginal_C3/cubic_core.py',
      'calculations/canonical_so10_unprobed_marginal_C3/blocks.py','calculations/canonical_so10_u_F_fourth_support/operators.py',
      'calculations/canonical_so10_u_T_cutoff_tensor/actual.py','calculations/canonical_so10_u_T_cutoff_tensor/algebra.py',
      'calculations/canonical_so10_full_jet_source_master_bridge/jets.py','calculations/canonical_so10_intrinsic_full_source_descent/coefficient_ring.py',
      'calculations/canonical_so10_u_operation_root_inventory/heat_bound_tables.json.gz','calculations/canonical_so10_u_operation_root_inventory/heat_bound_validation_receipt.json',
      'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']
    for role in ['primary','replay']:rels.append('calculations/canonical_so10_unprobed_marginal_C3/'+role+'_blocks.json.gz')
    for name in ['.gitattributes','RECORD.md','quartic_core.py','method.py','run_method.py']:
        pp=O/name
        if pp.suffix=='.py':ast.parse(pp.read_bytes())
        assert all(line==line.rstrip(b' \t') for line in pp.read_bytes().splitlines()),('NEW_SOURCE_TRAILING_SPACE',name)
        with (O/(name+'.source.txt')).open('xb') as f:f.write(pp.read_bytes())
    files=[R/v for v in rels]+list(O.iterdir());bindings={str(p):H(p) for p in files if p.is_file()}
    prep={'schema':'ULD1_PREPARATION','base_HEAD':head,'input_sha256':bindings,'previous_goal_turn':'PROGRESS; complete remaining C3 and F log3 closure',
      'native_seconds_after_imports':300,'review_seconds_after_imports':180,'private_sample_bytes':8*1024**3,'launch_available_pagefile_floor':350*1024**2,'packet_byte_limit':32*1024**2,'scientific_acceptance':'NOT_PERFORMED'}
    dump(O/'preparation.json',prep);dump(C/'start.json',prep)
    z=capture([sys.executable,'-B',str(O/'method.py')]);dump(O/'method_capture.json',z);dump(C/'method_full_capture.json',z)
    assert z['exit_code']==0 and z['execution_state']=='COMPLETED' and z['calculation_completed'] and z['post_run_observations_qualified']
    result=read(O/'method_result.json');assert result['elapsed_after_imports']<180
    print('COMPLETED ULD1 '+json.dumps(result['four_edge_cost'],sort_keys=True),flush=True)
except BaseException:
    dump(O/'method_controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
