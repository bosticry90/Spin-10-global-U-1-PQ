# ULD5: final bounded evidence qualification, prospective

Authenticate all preparation bindings and exact source copies,Python ASTs,
complete execution captures,owned process creation/resource samples and
the frozen per-worker/aggregate budgets. Require complete method,C4 and
actual-image/zero-complement checks plus declared late log2 disposition.
The final qualification reports that disposition without replacing it
with an expected cancellation. Earlier T/F log3 results are authenticated
against their owning receipts,not scientifically rerun.

E4 must have executed ONCE without --fresh,native0,six expected exits
[0,0,0,0,0,2],terminalCOMPLETED,custodyseven NOTPASS. Preserve its exact
events. Check old Git tree,tracked workspace,branch and state hash;new
files only in ULD plus handoffV656. Seal every new byte except the seal
itself before staging. Require unmodified whitespace check and raw staged
SHA equality;preserve old mode/blob entries before local main commit.

180s review after imports,8GiB sampled,350MiB launch floor,32MiB packet.
Report omitted tests/shared physical assumptions and no protected scientific
promotion. No outside validation,full QAP/E5 or physical-theory claim.
