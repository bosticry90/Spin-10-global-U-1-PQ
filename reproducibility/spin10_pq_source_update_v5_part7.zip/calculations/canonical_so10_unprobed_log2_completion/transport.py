from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
import gzip,json,os,sys,threading,time
from quartic_core import *
from blocks import co

role=sys.argv[1];assert role in ['primary','replay']
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());loadz=lambda p:json.loads(gzip.decompress(p.read_bytes()));H=lambda p:sha256(p.read_bytes()).hexdigest()
for pp,h in read(O/'transport_preparation.json')['input_sha256'].items():assert H(Path(pp))==h,pp
peer='replay' if role=='primary' else 'primary'

def guard(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        pp=Path(os.fsdecode(args[0]))
        if pp.parent.resolve()==O and (pp.name.startswith('transport_'+peer) or pp.name.startswith('log2_review')):raise PermissionError('ULD_NATIVE_PEER_DENIED')
        if pp.parent.name in ['canonical_so10_u_lower_cutoff_contraction','canonical_so10_u_pair_contact_model']:raise PermissionError('ULD_OLD_TARGET_DENIED')
        if pp.name in ['partial_after_known.json.gz','T_log3_complete_comparison_v2.json.gz','F_log3_complete_comparison.json.gz']:raise PermissionError('ULD_OLD_COMPARISON_DENIED')
sys.addaudithook(guard);denials=0
for pp in [O/('transport_'+peer+'_tables.json.gz'),O/'log2_review_result.json',R/'calculations/canonical_so10_u_lower_cutoff_contraction/late_remainders.json.gz',R/'calculations/canonical_so10_unprobed_log3_support/partial_after_known.json.gz']:
    try:pp.read_bytes()
    except PermissionError:denials+=1
assert denials==4
assert read(O/'kernel_review_result.json')['whole_native_coefficients_and_implicit_zeros_equal']

def unpack(rows):
    out={tuple(z[:-1]):coeff(z[-1]) for z in rows};assert len(out)==len(rows) and all(out.values());return out

def owned(folder,name):
    P=R/'calculations'/folder;rel=str((P/name).relative_to(R)).replace('\\','/')
    assert H(P/name)==read(P/'final_review_validation_receipt.json')['new_files_sha256'][rel]
    return loadz(P/name)

known=owned('canonical_so10_unprobed_log3_support','transport_'+role+'_tables.json.gz')
triangle=owned('canonical_so10_unprobed_log3_support','triangle_'+role+'_tables.json.gz')
marginal=owned('canonical_so10_unprobed_marginal_C3','transport_'+role+'_tables.json.gz')
C3={}
for z in known['results']+marginal['results']:
    key=(z['probe'],z['target']);M=C3.setdefault(key,{})
    for k,v in unpack(z['total']).items():put(M,k,v)
for z in triangle['images']:
    M=C3.setdefault((z['probe'],z['target']),{})
    for k,v in unpack(z['image']).items():put(M,k,v)
C3={k:clean(v) for k,v in C3.items()}

native={}
for case,folder in [('naCx','canonical_so10_unprobed_antighost_kernel'),('nJLCx','canonical_so10_unprobed_auxiliary_source_kernel')]:
    P=R/'calculations'/folder;pp=P/('color_'+role+'_tables.json.gz')
    assert H(pp)==read(P/('color_'+role+'_result.json'))['packed_sha256']
    rows=loadz(pp)['F_m']['4'];native[case]={tuple(z[:-1]):co(z[-1]) for z in rows}
    assert len(native[case])==len(rows)
pp=O/('kernel4_'+role+'_tables.json.gz');assert H(pp)==read(O/('kernel4_'+role+'_result.json'))['packed_sha256']
for z in loadz(pp)['results']:native[z['case']]=unpack(z['total'])

P=R/'calculations/canonical_so10_u_operation_root_inventory';pp=P/('root_'+role+'_tables.json.gz')
assert H(pp)==read(P/('root_'+role+'_result.json'))['packed_sha256'];u=loadz(pp)
d=loadz(R/('calculations/canonical_so10_u_maximal_heat_cutoff/'+role+'_inputs.json.gz'));names=d['field_order'];assert len(names)==len(set(names))==643
ids={n:i for i,n in enumerate(names)};ids.update({'J'+n:643+i for i,n in enumerate(names)})
parity=lambda i:int(553<=i<643) if i<643 else 1-int(553<=i-643<643)

def canonical(word):
    odd=[i for i in word if parity(i)]
    if len(odd)!=len(set(odd)):return (),0
    return tuple(sorted(word)),(-1)**sum(a>b for at,a in enumerate(odd) for b in odd[at+1:])

def density(case,key):
    if case=='naCx':a,h,i=key;return (598+a,553+h,180+i)
    if case=='nJLCx':r,h,i=key;return (1151+r,553+h,180+i)
    r,s,h,k=key
    return (1151+r,598+s,553+h,553+k) if case=='JLaCC' else (1151+r,1151+s,553+h,553+k)

def key_of(word,target):
    xs=[i-180 for i in word if 180<=i<508];cc=[i-553 for i in word if 553<=i<598]
    low=1241 if target=='T' else 1151;src=[i-low for i in word if low<=i<low+45]
    assert len(xs)==len(src)==1 and len(cc)==(1 if target=='T' else 2) and len(word)==(3 if target=='T' else 4)
    assert all(0<=i<45 for i in cc+src) and 0<=xs[0]<328
    if target=='F':assert cc[0]<cc[1]
    return (src[0],*cc,xs[0])

fixtures=[((1151,598,553,554),598,(180,),-1),((1151,1152,553,554),1151,(180,),1),((1151,1152,553,554),1152,(180,),-1),((598,553,180),598,(1241,),1),((1151,553,180),1151,(1241,),1)]
for original,out,rem,expected in fixtures:
    at=original.index(out);target0,s0=canonical(original[:at]+rem+original[at+1:]);left=(-1)**sum(parity(i) for i in original[:at])*s0
    w,sg=canonical(original);at=w.index(out);target1,s1=canonical(w[:at]+rem+w[at+1:]);right=sg*((-1)**sum(parity(i) for i in w[:at]))*s1
    assert target0==target1 and left==right==expected

patterns={'naCx':(('C','a','x'),1),'nJLCx':(('C','JL','x'),1),'JLaCC':(('C','C','JL','a'),0),'JLJLCC':(('C','C','JL','JL'),0)}
results=[]
for probe,record in enumerate(u['results']):
    for target in ['T','F']:
        groups={};flow_counts={};source_degrees={};ops=record['targets'][target]
        for case,(pattern,nu) in patterns.items():
            flows=defaultdict(list)
            for pat,nd,out,rem,value in ops['aggregate_flows']:
                if tuple(pat)!=pattern or nd!=nu:continue
                assert out in ids and all(n in ids for n in rem)
                flows[ids[out]].append((tuple(ids[n] for n in rem),co(value)))
            flow_counts[case]=sum(map(len,flows.values()))
            source_degrees[case]=dict(Counter(row['QG_source_degree'] for row in ops['routes'] if tuple(row['C0_root_type'])==pattern and row['C0_intrinsic_degree']==nu))
            image={}
            for key,v in (native[case].items() if role=='primary' else reversed(list(native[case].items()))):
                original=density(case,key)
                if role=='primary':
                    for at,out in enumerate(original):
                        prefix=(-1)**sum(parity(i) for i in original[:at])
                        for rem,f in flows.get(out,[]):
                            word,sg=canonical(original[:at]+rem+original[at+1:])
                            if sg:put(image,key_of(word,target),(v*f)*(prefix*sg))
                else:
                    word,sg0=canonical(original)
                    for at,out in enumerate(word):
                        prefix=(-1)**sum(parity(i) for i in word[:at])
                        for rem,f in flows.get(out,[]):
                            new,sg=canonical(word[:at]+rem+word[at+1:])
                            if sg:put(image,key_of(new,target),(v*f)*(sg0*prefix*sg))
            groups[case]=clean(image)
        c4={}
        for M in groups.values():
            for k,v in M.items():put(c4,k,v)
        c4=clean(c4);c3=C3.get((probe,target),{});log2={k:-v for k,v in c3.items()}
        for k,v in c4.items():put(log2,k,v)
        log2=clean(log2);domain=(45*45 if target=='T' else 45*990)*328
        results.append({'probe':probe,'target':target,'domain_positions':domain,'C4_groups':{k:encode(v) for k,v in groups.items()},
          'C4_group_nonzero_counts':{k:len(v) for k,v in groups.items()},'C3_image':encode(c3),'C4_image':encode(c4),'log2_image':encode(log2),
          'C3_nonzero':len(c3),'C4_nonzero':len(c4),'log2_nonzero':len(log2),'log2_zero_complement':domain-len(log2),
          'actual_aggregate_flow_counts':flow_counts,'original_QG_source_degree_route_counts':source_degrees})
out={'schema':'ULD4_COMPLETE_NATIVE_LOG2_U_IMAGE','role':role,'results':results,'nonzero_graded_sign_fixtures':len(fixtures),'guard_denials':denials,
  'C1_zero_by_dimension_proof':True,'old_C3_and_intrinsic_C4_loops_reused_not_freshly_replayed':True,'old_desired_remainder_read':False,'full_Ward_QAP_or_E5_claim':False}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<32*1024**2
with (O/('transport_'+role+'_tables.json.gz')).open('xb') as f:f.write(blob)
print('RESULT '+json.dumps({'elapsed_after_imports':time.perf_counter()-tick,'packed_sha256':sha256(blob).hexdigest(),'raw_sha256':sha256(raw).hexdigest(),
  'counts':[{k:v for k,v in z.items() if k not in ['C4_groups','C3_image','C4_image','log2_image']} for z in results],'guard_denials':denials},sort_keys=True),flush=True);timer.cancel()
