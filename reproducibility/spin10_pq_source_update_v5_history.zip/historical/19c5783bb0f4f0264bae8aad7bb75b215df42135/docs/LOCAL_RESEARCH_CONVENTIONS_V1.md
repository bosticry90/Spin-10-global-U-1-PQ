# Local research conventions

Use `python -B tools/research_check.py e4` to authenticate the sealed E4
checkpoint and run the existing authority, structure, read-only and custody
audits. The command sets the established pole-blind environment. `e5` selects
the separately sealed E5 record once available. No argument grants scientific
authorization. `--fresh` explicitly delegates new byte-identical replay to the
existing auditor; it is deliberately not the default.

The JSON-line events record exact commands, exits, diagnostic output, elapsed
time, selected scope and recorded scientific disposition. Terminal execution
states are COMPLETED, FAILED, BLOCKED, CANCELED or INCONCLUSIVE. COMPLETED means
the declared checks returned their expected exits. It does not mean a
scientific gate passed, director acceptance, global validation or custody PASS.
Custody must still return exit 2 with seven unresolved references. A changed
count requires review rather than automatic acceptance.

An optional `--budget-seconds` stops before the next atomic step. It does not
truncate an ongoing calculation, alter obligations or turn expiration into a
mathematical verdict. Canceled/incomplete execution has no validation receipt;
verify process inventory before retrying, especially if nested replay workers
were interrupted. The entry point never terminates unrelated processes.

Recovery uses current Git/process state and authenticated sealed manifests
and receipts. Reusing an earlier completed result is authentication, not fresh
replay. There is no automatic partial-cache resume, checkpoint database or
second status ledger. Unfinished symbolic output remains unfinished. Preserve
it and rerun only the necessary bounded route under its existing contract.

For a significant investigation, use the existing versioned contract/result/
review/evidence convention. Add these fields where they are not already clear:
question and claim identifiers; exact types/domain and assumptions; qualified
dependencies; distinct methods; negative controls; local commands/runtime and
hashes; effort boundary; meaningful completion and first-failure criteria;
possible dispositions; explicit limitations and next decision. This checklist
does not create another mandatory template or acceptance framework.

Reduce engineering scope at an effort boundary; never reduce a proof contract.
Valid scientific outcomes include a qualified bounded result, refutation,
known-model equivalence, underdefinition and bounded inconclusiveness.
Execution, reproduction, derivation validity, physical interpretation and
experimental agreement remain separate under the existing epistemic ladder.

Retain independent mathematical routes even when they look redundant. Frozen
helpers, records and catalogs are not refactoring targets. The sole authority
is `project_state.json`; the human director owns consequential acceptance and
direction. Solo review uses literature and independently derived checks with
shared software/inputs/analyst disclosed, without recruiting people.
