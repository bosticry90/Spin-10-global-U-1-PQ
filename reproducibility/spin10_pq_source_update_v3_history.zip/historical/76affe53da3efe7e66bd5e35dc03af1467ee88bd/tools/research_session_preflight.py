"""Read-only recovery snapshot; byte authentication is not scientific acceptance."""
from hashlib import sha256
import argparse
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
E3_MANIFEST = "tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e3_symmetry/bindings.json"
BINDING_KEYS = ("byte_sha256", "inherited_manifest_sha256", "evidence_byte_sha256",
                "implementation_byte_sha256", "scientific_input_byte_sha256", "historical_input_sha256")


def inside(root, name):
    path = (root / name).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("REFERENCE_OUTSIDE_REPOSITORY: " + name)
    return path


def authenticate_bytes(root, manifest):
    """Recursively check declared bytes without inferring a scientific verdict."""
    seen, files, historical_states = set(), {}, {}

    def visit(name):
        if name in seen:
            return
        seen.add(name)
        data = json.loads(inside(root, name).read_bytes())
        if not any(data.get(key) for key in BINDING_KEYS):
            raise ValueError("UNSUPPORTED_OR_EMPTY_MANIFEST: " + name)
        for key in BINDING_KEYS:
            for relative, expected in data.get(key, {}).items():
                actual = sha256(inside(root, relative).read_bytes()).hexdigest()
                if actual != expected:
                    raise ValueError("BOUND_BYTE_CHANGED: " + relative)
                if relative in files and files[relative] != expected:
                    raise ValueError("CONFLICTING_BINDING: " + relative)
                files[relative] = expected
        for relative in data.get("inherited_manifest_sha256", {}):
            visit(relative)
        if "state_sha256" in data:
            actual = sha256(inside(root, "project_state.json").read_bytes()).hexdigest()
            if name == manifest and actual != data["state_sha256"]:
                raise ValueError("STATE_DIFFERS_FROM_BOUND_SNAPSHOT: " + name)
            historical_states[name] = data["state_sha256"]

    visit(manifest)
    return {"status": "AUTHENTICATED_DECLARED_BYTES_ONLY",
            "manifests_visited": len(seen), "file_bindings_checked": len(files),
            "historical_state_snapshots": historical_states,
            "scientific_calculations_rerun": False, "scientific_acceptance_inferred": False}


def active_processes():
    script = ("Get-CimInstance Win32_Process | Where-Object { "
              "$_.Name -eq 'python.exe' -and ($_.CommandLine -like '*a10_*' "
              "-or $_.CommandLine -like '*m08_*') } | "
              "Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress")
    result = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
                            capture_output=True, text=True, timeout=20)
    if result.returncode:
        raise RuntimeError("PROCESS_INVENTORY_UNAVAILABLE: " + result.stderr.strip())
    value = json.loads(result.stdout) if result.stdout.strip() else []
    return value if isinstance(value, list) else [value]


def snapshot(root=ROOT, manifest=E3_MANIFEST):
    state_path = inside(root, "project_state.json")
    state = json.loads(state_path.read_bytes())
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
    changes = subprocess.check_output(["git", "status", "--porcelain=v1"], cwd=root, text=True)
    return {"schema": "TOE_RESEARCH_SESSION_PREFLIGHT_V1", "git_HEAD": head,
            "working_tree_entries": changes.splitlines(),
            "state_sha256": sha256(state_path.read_bytes()).hexdigest(),
            "state_version": state.get("state_version"),
            "authoritative_research": state.get("research"),
            "authority_source": "project_state.json", "manifest": manifest,
            "byte_authentication": authenticate_bytes(root, manifest),
            "active_A10_M08_python_processes": active_processes(),
            "scientific_acceptance": "NOT_PERFORMED", "files_written": 0,
            "limitations": ["process inventory covers matching Python command lines only",
                            "declared byte bindings are not a whole-workspace audit",
                            "no historical custody adjudication or mathematical replay"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", default=E3_MANIFEST,
                        help="repository-relative sealed manifest; never interpreted as authorization")
    args = parser.parse_args()
    print(json.dumps(snapshot(manifest=args.manifest), sort_keys=True, separators=(",", ":")))


if __name__ == "__main__":
    main()
