"""Check independent core momenta and strict two-exit soft majorants."""

import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def incidence():
    # (loop root, ordinary exit 1, ordinary exit 2) -> three loop nodes.
    route = sp.Matrix([[1,0,0],[1,-1,0],[1,-1,-1]])
    assert abs(route.det())==1
    transfers = sp.Matrix([[1,-1,0],[0,1,-1],[-1,0,1]])*route
    assert transfers==sp.Matrix([[0,1,0],[0,0,1],[0,-1,-1]])
    affine_slice = sp.Matrix.hstack(*transfers[2,:].nullspace())
    assert (transfers[:2,:]*affine_slice).rank()==1
    # A-on-core feedback uses k,p,k-p and independent x,x-k.
    feedback = sp.Matrix([[1,0,0],[1,-1,0],[0,1,0],[0,0,1],[0,1,-1]])
    assert feedback.rank()==3
    assert feedback[2,:]-feedback[3,:]-feedback[4,:]==sp.zeros(1,3)


def moments():
    r,y,R = sp.symbols("r y R",positive=True)
    near = sp.integrate(r/y**2,(r,0,y))
    far = sp.integrate(1/r,(r,y,R))
    assert near==sp.S.Half and far==sp.log(R)-sp.log(y)
    angle = sp.Symbol("theta",real=True)
    for k in range(1,7):
        n = sp.integrate(sp.sin(angle)*sp.sin(k*angle),(angle,0,sp.pi))
        assert n==(sp.pi/2 if k==1 else 0)
    weight = sp.S.Half-sp.log(r)
    triangle = sp.integrate(r*weight**2,(r,0,1))
    bubble_pair = sp.integrate(r**3*weight**2,(r,0,1))
    assert (triangle,bubble_pair)==(sp.Rational(5,8),sp.Rational(5,32))
    assert sp.integrate(r*weight,(r,0,1))==sp.Rational(1,2)
    return [str(triangle),str(bubble_pair)]


def paired_half():
    P,Q,T,s = sp.symbols("P Q T s",positive=True)
    dd = (sp.exp(-T*Q)-sp.exp(-T*P))/(P-Q)
    integrand = sp.exp(-s*P-(T-s)*Q)
    primitive = -integrand/(P-Q)
    assert sp.simplify(sp.diff(primitive,s)-integrand)==0
    assert sp.simplify(primitive.subs(s,T)-primitive.subs(s,0)-dd)==0
    coincident = sp.integrate(integrand.subs(P,Q),(s,0,T))
    assert coincident==T*sp.exp(-T*Q)
    assert sp.simplify(sp.limit(dd,P,Q)-coincident)==0
    assert sp.limit(dd,T,sp.oo)==0
    assert sp.integrate(sp.exp(-s*P),(s,0,sp.oo))==1/P
    assert sp.integrate(sp.exp(-s*Q),(s,0,sp.oo))==1/Q


def check(phase):
    base = ROOT/"calculations"
    owner = base/"canonical_so10_uncut_background_bridge_boundary_v1/validation_receipt.json"
    receipt = json.loads(owner.read_bytes())
    assert receipt["evidence_validation"]=="PASS_BOUNDED_UNCUT_BACKGROUND_BRIDGE_BOUNDARY"
    assert receipt["checks"]["unlabelled_soft_exit_rank"]==1
    incidence()
    soft = moments()
    paired_half()
    return {"triangle_and_feedback_radial_bounds":soft,
            "rank_two_exits_with_independent_background":True,
            "rank_one_on_restricted_background_transfer":True,
            "rooted_IR_half_dominance_verified":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
