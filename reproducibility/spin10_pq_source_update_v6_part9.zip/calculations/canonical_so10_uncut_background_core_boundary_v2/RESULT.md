# V995 result

Putting the independent background label on the
loop frees the two exterior transfers. The
ordinary triangle is bounded by two inverse-square
convolutions and one remaining inverse-square
node. Each convolution costs at most a logarithm,
and the joint bound is integrable. The actual
two-vertex, tadpole and ordinary one-port feedback
geometries obey the same or weaker bounds.

The rooted divided-difference estimate makes
the bridge and core IR majorants uniform. After
matched UV subtraction the selected direct
Euclidean coefficient converges for simultaneous
inner and outer IR removal without a rate
condition in this placement. Restricting the A
transfer first restores the rank-one tie.

The first worker encountered a symbolic
coincident-node integral error. Its packet and
capture are preserved. V2 checks the distinct
primitive and the coincident time integral
separately, with the continuous limit verified.

This is an ordinary unmarked first-A core result.
Real-time boundaries and weak limits remain open.
