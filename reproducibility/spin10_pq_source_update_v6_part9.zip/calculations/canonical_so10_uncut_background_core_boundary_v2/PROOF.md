# Direct uncut ordinary two-exit limit with background on the core

Keep the actual unshifted 643-field
one-loop parent and one independently
smeared external A transfer. Put the
background on the loop, and keep two
ordinary j_B exits. This is the
unmarked placement complementary to
V994. The pure reference has no
ordinary exit. The common converted
UV subtraction uses the same V991
regulated forest on every term.

Collapse the V880 constant chains
before assigning soft powers. Its
actual constant scalar mass and
auxiliary-scalar chains preserve
orders at most two, and the ordinary
mixed inverse is no worse than
order one. The external first A
derivative is a labelled insertion,
not a constant merged source tangent.
When it differentiates a heat half,
use the V983 endpoint-root bound.
Its other endpoint is a distinct
loop node and costs at most order
two. A direct Born inverse derivative
also splits the node at its A
transfer. All polynomial numerators
can be bounded on the local ball.
Thus it suffices to assign order
two to each actual free node and
ordinary exit. No new constant
massless vector insertion is admitted.

For the maximal case, put A and
the two ordinary exterior field
labels on three distinct cycle
vertices. Call the adjacent loop
momenta x,y,z, and the exits
p=x-y and q=y-z, with A transfer
z-x. These are independent
variables with the loop root.
The integer change from (x,p,q)
to (x,y,z) has determinant of
absolute value one. A bound
which keeps no numerator gain is

    |x|^-2 |y|^-2 |z|^-2
                      |x-y|^-2 |y-z|^-2.

On a bounded ball integrate x and
z at fixed y. The elementary
four-dimensional convolution of
two order-two factors is bounded
by C (1+|log |y||). For y in
a ball of radius R, its full
angular average on the x ball
of radius R is exactly
(1/2+log(R/|y|)) times the
sphere normalization. One can
also split at |x|=2|y| and
bound the near and far terms.
The remaining integral is
bounded by a constant times
integral r (1+|log r|)^2 dr.
This is finite. The bound
includes simultaneous approach
to the overlapping soft nodes
and the two exit poles.

If A shares a vertex with one
of the B labels, the two loop
nodes x,y have one exit equal
to x-y. The other exterior
momentum is free under the A
label. The local bound reduces
to one convolution and a
separate order-two integral.
If both B labels share a vertex,
the other vertex carries A
and fixes k=p+q=x-y up to
orientation. At fixed k,
the loop and the two exits
each give one order-two
convolution. The result is
integrable in k with log²
growth. A one-vertex term
has independent loop and
exit variables and simpler
integrable powers.

There is also the ordinary
one-port feedback geometry
at this label count. The
loop has the A label and one
exit k. The tree with that
exit and two ordinary
sources has one cubic
vertex after the constant
chains. An upper bound
uses loop nodes x,x-k and
tree lines k,p,k-p. At
fixed k the x and p
convolutions cost log²
and the central bridge
costs at most |k|^-2.
This is the same finite
radial integral as above.
If the loop has one
vertex the bound is
weaker. No zero-momentum
unlabelled one-port
argument is used.

The paired profiles are
bounded on the ordinary
lines. In a differentiated
Duhamel factor the rooted
bound is uniform in the
IR time, and it tends
to the unheated variation
at distinct nonzero
momenta. Thus the local
joint majorants give
dominated convergence for
inner and outer IR scales
going to zero. The proof
does not need a bound
on their ratio. On the
hard shell with bounded
external transfers the
V983 ordered subtraction
and r^-5 remainder are
uniform, and the IR
exponentials leave no
UV coefficient. The
matched forest removes
all spurious positive
bridge jets before this
limit. The result concerns
the fixed finite
coefficients in the
bounded external region.

The background label is
essential to this argument.
Removing its transfer
coordinate before the
limit identifies q=-p.
The two exits then have
rank one and the order-four
critical weight reappears.
V994 required a grouped
soft gain for a related
tied placement. The present
strict bound is for A on
the core with independent
transfer, not a proof
at the restricted transfer.

This closes the selected
ordinary Euclidean
A-on-core placement and
its ordinary one-port
feedback. It leaves
local marked/source
tangents, real-time
boundaries and global
adiabatic limits to
separate comparisons.
Both routes share the
model and symbolic
implementation.
