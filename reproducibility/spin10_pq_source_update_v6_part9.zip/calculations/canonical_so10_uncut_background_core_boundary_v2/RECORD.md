# V995 pre-execution contract

Freeze V994, V991, V983 and V880/V881
constant-chain and soft-rank evidence.
Place one independent A label on the
one-loop core for two ordinary B exits
in the direct uncut 643-field word
domain. Keep the matched UV forest and
the admitted finite ordinary mass chains.
Derive joint Euclidean soft bounds for
triangle, seagull/bubble and ordinary
one-port feedback placements. Require
a strict majorant at the joint tip and
a control for collapsing the A label.
No marked, Lorentzian or weak limit
extension inferred.

Native 120 s, final 180 s including E4
cap 120 s, 8 GiB sampled private,
350 MiB launch floor, 8 MiB artifact
and 32 MiB packet. No authority change.

## Version 2 continuation

The first worker stopped in the symbolic
time-integral guard. The returned Piecewise
expression gave the correct distinct-node
branch but an incorrect T at coincident
nodes. Preserve the exact first packet and
capture. Check the distinct-node primitive
by differentiation and endpoints. Check
the coincident integrand separately against
the continuous limit T exp(-T Q).
The scientific bound and resource limits
are unchanged.
