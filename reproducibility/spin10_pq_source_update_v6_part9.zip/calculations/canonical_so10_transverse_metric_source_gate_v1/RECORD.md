# V938 pre-execution contract

Test the V937 light gauge-source target as part of a
homogeneous local gauge/ghost deformation at fixed
linear gauge and transverse Maxwell normalization.
Freeze the compact spin(10) bracket, H action, V937
stripped target and the declared source projections.

Combine gauge square, ghost Jacobi and constant-ghost
invariance of the transverse quadratic form. Replay
the compact color data and metric witness with a
symmetric-map sensitivity control and a changed-metric
witness. Keep independent quantum right-hand sides and
transported linear normalization outside the exclusion.
No physical metric is adopted.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.
No authority change.
