"""Replay the compact-algebra witness for the transverse metric gate."""

from collections import defaultdict
import importlib.util
from itertools import product
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)


def check(phase):
    _, _, _, f, K, _ = source.owner.inputs(phase)
    colors = range(45)
    f_lookup = {pair: dict(values) for pair, values in f.items()}
    for (a, b), entries in f_lookup.items():
        for c, z in entries.items():
            assert f_lookup.get((b, a), {}).get(c, 0) == -z
            assert f_lookup.get((b, c), {}).get(a, 0) == z
            if max(a, b) < 12:
                assert c < 12
    gram = defaultdict(lambda: sp.S.Zero)
    for entries in f.values():
        for (a, u), (b, v) in product(entries, repeat=2):
            gram[a, b] += u*v
    assert source.owner.clean(gram) == {(a, a): 8 for a in colors}

    h, b, c = 1, 30, 23
    assert not f[b, c]
    assert f[h, b] == [(20, sp.Rational(1, 2))]
    assert K[c][20] == K[20][c] == -sp.Rational(1, 5)
    assert all(K[a].get(b, 0) == K[b].get(a, 0) for a, b in product(colors, repeat=2))
    for i in range(12):
        ad = {j: dict(f[i, j]) for j in colors}
        assert all(source.on_colors(K, ad[j]) == source.on_colors(ad, K[j]) for j in colors)

    def delta(color_map, a, b):
        out = source.bracket(f, color_map[a], {b: 1})
        out = source.add(out, source.bracket(f, {a: 1}, color_map[b]))
        return source.add(out, source.on_colors(color_map, dict(f[a, b])), -1)

    assert delta(K, b, c).get(h, 0) == -sp.Rational(1, 5)
    assert delta(K, h, c).get(b, 0) == 0
    ad = {j: dict(f[h, j]) for j in colors}
    assert not delta(ad, b, c) and not delta(ad, h, c)

    prior = ROOT / "calculations/canonical_so10_light_ghost_source_color_span_v1/result.json"
    target = sp.Rational(json.loads(prior.read_bytes())["checks"]["commuting_target"])
    trial = {j: source.owner.clean({i: -z/2 for i, z in column.items()}) for j, column in K.items()}
    metric = {j: source.owner.clean({i: 2*z for i, z in column.items()}) for j, column in trial.items()}
    assert delta(trial, b, c).get(h, 0) == target == sp.Rational(1, 10)
    assert metric[c][20] == 2*target
    assert source.seagull.dot(dict(f[h, b]), metric[c]) == target
    return {"metric_invariance_and_killing_gram": "8 I on 45",
            "commuting_pair": [b, c], "output": h, "fixed_metric_prediction": "0",
            "normalized_target": str(target), "metric_entry_required": str(metric[c][20]),
            "symmetric_control_defect": "-1/5"}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
