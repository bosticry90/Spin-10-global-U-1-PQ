# Fixed transverse gauge form and the commuting bracket witness

Consider a local antifield-linear correction to the gauge
and ghost drivers at the selected first deformation order.
Take the unit-switch A=0 parent, the fixed coefficient of
partial C in q_B and homogeneous projected equations.
The drivers in the pure gauge and ghost slice are

    q_B = partial C + g([B,C]+t D(B,C)),
    q_C = -g([C,C]+t W(C,C))/2,

with the common coupling grade suppressed in t. These
terms exhaust the vector ghost-one and scalar ghost-two
forms with the admitted dimensions in the selected fields.

The independent (partial C=b,C=c) gauge-square coefficient
requires D=W. Ghost square makes W an adjoint 2-cocycle on
the compact spin(10) algebra. The Second Whitehead Lemma
gives

    W(b,c) = [K b,c]+[b,K c]-K[b,c].

This uses the lemma only for the finite real semisimple
gauge algebra and its adjoint module. See Zusmanovich,
arXiv:0704.3864, introduction for the classical statement.
The executable checks cyclic metric invariance and the
negative Killing Gram 8 I in the joined frame. H
covariance of W permits averaging K over the compact
closure of H, preserving its coboundary and making K
commute with ad_h.

Write the transverse color metric as I+t M with M real
symmetric. At constant ghost C=c, set the other fields
and sources to zero and test arbitrary transverse B in
the two-derivative quadratic projection. Variation of
an ordinary cubic by the free partial C drops. The
gauge-fixing divergence has no transverse linear term.
The original color action on B is -ad_c and the new
one is -[ad_c,K]-ad_(Kc). Taking the transpose in the
metric variation gives

    [ad_c, M-(K+K^t)] = 0 for every c.

A symmetric operator commuting with the adjoint has
invariant eigenspaces. Since so(10) is simple, this
operator is a scalar. For the commuting pair b=e30,
c=e23 and h=e1, H equivariance and metric invariance
give

    <h,W(b,c)> = <[h,b],(K+K^t)c>
                 = <[h,b], M c> = M[20,23]/2.

The fixed metric forces zero. The required row is 1/10
in the V937 stripped orientation, so a closed
completion carrying that row needs M[20,23]=1/5 in
the same units. Reversing the common target convention
reverses both coefficients. The trial K=-K_H/2 and M=2K
reproduces the single witness. It does not identify a
complete gauge action or an independently prescribed
Maxwell normalization.

The conclusion concerns the local homogeneous problem
at fixed lower derivative driver. A change P in that
driver shifts the target by subtracting [B,P C] after
a ghost-coordinate normalization. Independent quantum
right-hand sides can also change the projected equations.
Neither has been assigned a value here. Both data routes
share the model, conventions, software and authorship.
