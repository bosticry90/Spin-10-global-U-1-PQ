"""Test the Sigma projections of the fixed-free canonical replacement."""

from collections import defaultdict
from functools import lru_cache
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


OWNER = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
SPEC = importlib.util.spec_from_file_location("nonlinear_source_owner", OWNER)
source = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(source)
seagull = source.seagull
clean = source.owner.clean


def conjugate(vector):
    return clean({i: sp.conjugate(z) for i, z in vector.items()})


def real(vector):
    return clean({i: sp.re(z) for i, z in vector.items()})


def scale(factor, vector):
    return clean({i: factor*z for i, z in vector.items()})


def check(phase):
    v_all, _, rho, f, K, ghosts = source.owner.inputs(phase)
    vacuum = {i: z for i, z in v_all.items() if 54 <= i < 306}
    p = {13: 1, 14: sp.I}
    q = scale(1/sp.sqrt(2), {17: 1, 18: sp.I, 21: sp.I, 22: -1})
    k = scale(1/sp.sqrt(2), {37: 1, 38: sp.I, 41: sp.I, 42: -1})
    eigenvalues = (sp.Rational(8, 5), sp.Rational(21, 10), sp.Rational(21, 10))

    def act(color, vector):
        return source.owner.act(rho, color, vector)

    orbit = {i: seagull.apply(rho[i], vacuum) for i in range(45)}
    assert all(seagull.dot(vacuum, vector) == 0 for vector in orbit.values())
    for j, value in zip((p, q, k), eigenvalues):
        Ej = act(j, vacuum)
        assert source.on_colors(K, j) == scale(value, j)
        assert seagull.dot(conjugate(Ej), Ej) == sp.Rational(3, 5)
        gram = clean({i: seagull.dot(vector, Ej) for i, vector in orbit.items()})
        assert gram == scale(sp.Rational(3, 10), j)

    @lru_cache(None)
    def hessian(a, b):
        return source.add(seagull.apply(rho[a], orbit[b]), seagull.apply(rho[b], orbit[a]))

    def casimir(vector):
        out = defaultdict(lambda: sp.S.Zero)
        for h in range(12):
            seagull.axpy(out, -1, seagull.apply(rho[h], seagull.apply(rho[h], vector)))
        return clean(out)

    def literal(j, c):
        raw = defaultdict(lambda: sp.S.Zero)
        used = 0
        for a, b, ji, ci, z in ghosts:
            if ji in j and ci in c:
                seagull.axpy(raw, -z*j[ji]*c[ci], hessian(a, b))
                used += 1
        Ej, Ec = act(j, vacuum), act(c, vacuum)
        independent = source.add(casimir(act(j, Ec)), act(j, casimir(Ec)), -1)
        independent = source.add(independent, act(c, casimir(Ej)), -1)
        assert clean(raw) == independent and used
        return independent, used

    swaps = []
    for j in (p, q):
        Ej, Ek = act(j, vacuum), act(k, vacuum)
        X = act(k, Ej)
        dual = conjugate(X)
        assert X == act(j, Ek) and not source.bracket(f, j, k)
        assert seagull.dot(dual, X) == sp.Rational(6, 5)
        assert all(seagull.dot(dual, vector) == 0 for vector in orbit.values())
        assert act(k, dual) == scale(-2, conjugate(Ej))
        assert act(j, dual) == scale(-2, conjugate(Ek))
        swapped = []
        for left, right, E in ((j, k, Ej), (k, j, Ek)):
            ghost_dual = clean({a: seagull.dot(dual, seagull.apply(rho[a], E)) for a in range(45)})
            assert ghost_dual == scale(sp.Rational(3, 5), conjugate(right))
            target, count = literal(left, right)
            z = seagull.dot(dual, target)
            assert z == -sp.Rational(54, 25)
            swapped.append({"projection": str(z), "literal_rows": count})
        swaps.append(swapped)

    radial = []
    for j, target in ((p, sp.Rational(48, 25)), (q, sp.Rational(63, 25))):
        cj, Ej = conjugate(j), act(j, vacuum)
        assert real(act(cj, Ej)) == scale(-1, vacuum)
        assert not real(source.bracket(f, j, cj))
        ghost_dual = clean({a: seagull.dot(vacuum, seagull.apply(rho[a], Ej)) for a in range(45)})
        assert ghost_dual == scale(-sp.Rational(3, 10), j)
        row, count = literal(j, cj)
        z = sp.re(seagull.dot(vacuum, row))
        assert z == target
        radial.append({"projection": str(z), "literal_rows": count})

    eps, tp, tq, tk, dp, dq, dk = sp.symbols("eps t_p t_q t_k d_p d_q d_k")
    equations = (2*(tp-tk)+sp.Rational(3, 5)*(dk-dp),
                 2*(tq-tk)+sp.Rational(3, 5)*(dk-dq),
                 -(tq-tp)-sp.Rational(3, 10)*(dq-dp)-sp.Rational(3, 5)*eps)
    solution, = sp.solve(equations, (tq, tk, dq), dict=True)
    assert sp.expand(solution[dq]-dp) == -eps
    skew, = sp.solve(tuple(e.subs({dp: 0, dq: 0, dk: 0}) for e in equations),
                    (tq, tk, eps), dict=True)
    assert skew == {tq: tp, tk: tp, eps: 0}
    return {"swaps": swaps, "radial": radial, "radial_difference": "3/5",
            "general_symmetric_ghost_difference": "-epsilon_Sigma",
            "fixed_free_requires_epsilon_Sigma_zero": True}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
