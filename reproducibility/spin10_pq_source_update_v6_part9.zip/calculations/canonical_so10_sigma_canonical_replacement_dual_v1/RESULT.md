# V935 result — exact Sigma certificate for the fixed-free replacement

The Sigma block independently excludes the V932 canonical
replacement whenever its logarithmic weight is nonzero.
Two pairs of swapped coefficients and two radial coefficients
remove the permitted scalar, antighost and auxiliary changes.
For a general real ghost map the remaining condition is
d_q-d_p=-epsilon_Sigma. A skew ghost map gives zero on both
diagonals.

The complete six scalar coefficient vectors agree between
the signed V879 Hessian contraction and the Casimir formula,
in native and replay routes. The radial difference is 3/5
in stripped units. The complex probes represent linear
combinations of real coefficient rows.

Together with V932's Phi certificate, this excludes the
tested fixed-free canonical replacement at every common
subtraction scale for the distinct positive reference masses.
The previous special case of a vanishing Phi weight is closed
in this class. Transporting the free normalization or
introducing independent ordinary companions remains a
different problem. The calculation does not exclude general
canonical or noncanonical quantum constructions. The two
routes share the action, symbolic software and AI authorship.

The next test is the contact or field/source product that
could supply the linked derivative-ghost response identified
in V933, with the bare scalar support excluded by V934.
