# The Sigma dual for canonical replacement at the Phi-zero scale

Keep the canonical maps and homogeneous free normalization
of V932. Write E_j=rho_j v for the Sigma vacuum and Z(j,c)
for the stripped signed V929 ghost coefficient vector. The
possible replacement has the form

    epsilon_Sigma Z(j,c) = A^t rho_c E_j + rho_c T_j
                    + rho_(Kc) E_j + W([j,c]) + E^t D(j,c).

A is an arbitrary real block-preserving linear scalar map.
T absorbs the scalar-linear gauge fermion and antighost
changes. W and D are the two auxiliary shifts. K is one
real common ghost map and the V932 free conditions force
it to be skew. Overall signs of A,T,W,D can be absorbed in
their arbitrary real coefficients.

Use the complex linear probes

    p=e13+i e14,
    q=(e17+i e18+i e21-e22)/sqrt(2),
    k=(e37+i e38+i e41-e42)/sqrt(2).

Their K_H eigenvalues are 8/5, 21/10 and 21/10. Each is a
G_Sigma eigenvector with eigenvalue 3/10. The probes are
linear combinations of the original real equations.

For j=p,q put X=rho_k E_j. The joined matrices give
X=rho_j E_k, [j,k]=0, X perpendicular to the orbit,
rho_k conj(X)=-2 conj(E_j) and rho_j conj(X)=-2 conj(E_k).
The ghost functional at ordered (j,k) is

    conj(X)^t rho_d E_j = (3/5) conj(k)^t d,

with the analogous swapped functional. Each actual Z
contraction with conj(X) is -54/25. Taking the real
difference of the two equations cancels A,W,D and leaves

    2(t_j-t_k)+(3/5)(d_k-d_j)=0,

where t_j=Re conj(E_j)^t T_j and d_j=Re conj(j)^t K j.
The two swap differences give t_q-t_p=(3/10)(d_q-d_p).

Now pair (q,conj q) and (p,conj p) with v, take real parts
and subtract. The real part of rho_conj(j) E_j is -v in
both rows, so the A terms cancel. The W terms are purely
imaginary and the D terms lie in the orbit. The T difference
is -(t_q-t_p). The ghost difference is -(3/10)(d_q-d_p) by
the Gram eigenvalue. The actual Z radial values are 63/25
and 48/25. Hence

    -(3/5)(d_q-d_p) = (3/5) epsilon_Sigma.

For general K this gives d_q-d_p=-epsilon_Sigma. For real
skew K both d values vanish. Thus Sigma requires its weight
to vanish. V932 already forces the Phi weight to vanish in
the same class. The two distinct positive reference masses
exclude simultaneous vanishing at any common subtraction scale.

The executable derives the six full target vectors from
the signed two-B Hessian of V879 and independently from
[A_H,rho_j]E_c-rho_c A_HE_j, using V929's Casimir convention.
Both routes share the model, conventions, symbolic software
and AI authorship. If the free normalization is transported
and K need not be skew, the Sigma equation remains a necessary
constraint and the exclusion no longer follows by this argument.
