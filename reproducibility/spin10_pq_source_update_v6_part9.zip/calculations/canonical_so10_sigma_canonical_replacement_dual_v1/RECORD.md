# V935 pre-execution contract

Test the isolated Phi-zero scale left by V932 for the same
fixed-free canonical replacement. Freeze the Sigma orbit,
the V879 signed ghost coefficient, the V929 conventions,
the three complex linear probes in the proof, and the
common real ghost map. The probes extend real polynomial
coefficient tests by linearity.

Compare two pairs of swapped rows and two radial rows from
the literal BBaC Hessian to the Casimir construction in both
routes. Check the annihilators of the permitted scalar,
gauge-fermion, auxiliary and antighost changes. Keep a
general ghost map before imposing the V932 skew condition.
Fail on any missing or mismatched vector, sign, annihilator
or replay. Combine with the Phi witness and distinct masses
only within the same fixed-free class. No authority change.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.
