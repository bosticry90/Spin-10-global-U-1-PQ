# The uncut marked primitive as an auxiliary translation

Use the raw Minkowski source-first chart of V876 and the ordered LEFT
mark of V877. Let S be the uncut V879/V880 parent at u=0, with A fixed.
The odd local components ε_I are indexed by the 33 broken colors.
Ordinary Λ_I is even and J_Λ,I is odd. The actual width on these
colors is w=ξ. The ε-normal form of K has all epsilon derivatives
integrated by parts, with the full local current from V848 retained
for any switched comparison.

## Complete actual coefficient identity

Let R_{ji}(C)=E_Λ,i E_JΛ,j S. The only S terms that contain both a
broken Λ and a J_Λ are the cubic-source terms J_Λ Λ C_H.
Consequently R is linear in ordinary unbroken ghost fields. The
actual epsilon-normal comparison gives the integrated identity

    K = −∫ ε_i E_Λ,i S + ∫ ε_i [w Λ_i/2 + J_Λ,j R_{ji}(C)].

Every Λ occurrence is unjetted, so its Euler derivative is ordinary
slot differentiation. The V848 g0 and g1 raw parent tensors supply
all Λ terms. The full V879 packets have no additional A-dependent
broken Λ row and no g2 broken Λ row. The physical AST is Λ-free.
Restore the 334 source cells explicitly when comparing with K.
The width-square derivative is duplicated at its two equal Λ slots.
Its half yields the coefficient w/2. The tensor lift has no added
evanescent terms, so the comparison is valid in its metric constructor.

As a sensitive control, the actual K has an undifferentiated
ε_12 C_12 a_13 row. Its ghost legs can feed a hard two-port on a tree
branch with neither of the two dependent core exits improved. Merely
counting the independent ε test as a label on that other branch would
leave the hard cycle unlabelled. The reduction below keeps this row
and groups it with the other action derivatives.

## Grouped formal connected response

Write h_i=ρ ε_i, an even nilpotent direction. The first term of ρK
is precisely the linear coefficient of S(Λ−h). Under the formal
field substitution Λ=Λ'+h, the source-first ordinary coupling gives
+∫j_Λ h. The half-width and remainder terms are already proportional
to ρ, so their shift correction vanishes. They are linear in ordinary
fields and can be added to their corresponding ordinary source
directions, with ε and J kept in their original order. Thus on the
grouped stationary common functional the exact marked expression is

    I_K^W = ∫ ε_i (j_Λ,i + w φ_Λ,i/2)
            + ∫ ε_i J_Λ,j R_{ji}(φ_C).

Here φ is the mean from W, with the source-first signs. The formula
can be obtained coefficientwise without assuming an infinite-dimensional
measure. The shifted ordinary Hessian at fixed mean is the original
Hessian evaluated at Λ−h. The linear source addition has zero ordinary
Hessian. All one-loop maps depending on that Hessian and the fixed
reference, including the converted trace and the ordinary initial b,
therefore translate at fixed mean. The reference determinant is
independent of Λ. The stationary mean of the deformed parent at fixed
j is the original mean at the shifted ordinary sources, plus h.
Thus at one loop the direct derivative from −ε E_Λ S is
−D_{ε∂Λ} F, and the translation of the rooted mean is +D_{ε∂Λ} F.
They cancel. The source derivative remaining from the linear part
gives the φ_Λ and φ_C terms with their loop corrections. The tree
term j_Λ retains its positive sign. This is an identity for the
grouped converted target where the stationary common map exists.
An independently regulated free edge does not satisfy the off-shell
inverse contact exactly. The identity does not remove that finite
regulator defect or assert an absolute connected limit for arbitrary
sources.

## Mixed master and the retained source contact

Let F_i=E_Ji S and use the unsigned raw master density Σ F_i E_i S.
The affine Λ translation is source independent, so the master
operator commutes with it. B[S] is zero as an uncut integrated
functional, including its ordinary current. Its translated part
therefore contributes zero to [ρ]B[S+ρK]. With J=0 after taking
LEFT derivatives the remaining mixed root is

    M|_{J=0} = ∫ ε_i [ (w/2) F_Λ,i + R_{ji}(C) E_Λ,j S ]|_{J=0}.

The sign of the second term comes from passing E_JΛ through the
odd ε before applying the mixed-master minus sign. The first comes
from passing F_Λ through ε. The formula keeps the remainder even
though K's explicit J term vanishes on restriction. In the connected
source equation the LEFT J_Λ derivative of the explicit remainder
is −ε_i R_{ji}(φ_C), giving −ε_i j_Λ,j R_{ji}(φ_C) on the marked
source side. Matching this term in the regulated mixed map is the
specific shear contact still to be checked. The field change is
triangular from C_H to Λ_M and leaves the formal supertrace of its
linear generator zero. That algebra alone does not justify a
regulated coincident product.

For ε_12, both the actual R column and the actual F_Λ,12 driver
vanish identically in the full V879 action. Its uncut M is therefore
zero before setting J=0. In this color the K source remainder is
absent and the connected reduction retains the half-width auxiliary
mean. If the uncut connected source master is available, its ordinary
j_Λ derivative gives the corresponding mixed equation for the width
term. This result does not replace the compact varying-switch test
of V877, where the translation of S and that of the switched action
have different current terms.
