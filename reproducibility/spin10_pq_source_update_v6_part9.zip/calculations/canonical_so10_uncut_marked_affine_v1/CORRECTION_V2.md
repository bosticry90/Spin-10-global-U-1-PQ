# V885 V2 exact mark-port witness correction

V1 checked the complete coefficient equality before stopping on an
incorrect illustrative ghost-pair key. The frozen proof's witness
ε_12 C_12 a_13 is replaced by the literal ε_12 C_13 a_14 row in both
V848 raw and epsilon-normal tables. Its coordinate word is 566,
612, 1286 and its coefficient cell is −1/5 at key [0,1,0,5].
The corrected pair gives the same hard-exit test, with the unmarked
ghost core attached to C_13 and the other mark branch attached to
the ordinary C_14 source. The full exact identity, source-sign and
stationarity requirements and all limits are unchanged. Preserve
the first proof, worker and FAILED capture.
