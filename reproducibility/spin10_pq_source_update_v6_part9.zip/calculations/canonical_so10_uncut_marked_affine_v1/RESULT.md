# V885 — Exact auxiliary translation and retained marked source term

The 2,430 epsilon-normal coefficients of the actual uncut marked
primitive agree exactly with the negative auxiliary Euler derivative,
the half-width auxiliary term, and the 334 explicit retained-source
cells. The full V879 current confirms there are no additional broken
auxiliary incidences from background or g2 terms. Both g0 parent
representatives give the same result.

In the grouped formal connected map the affine translation cancels
between the direct and rooted one-loop terms. At J=0 the marked
response reduces to ∫ ε(j_Λ+w φ_Λ/2). Before imposing J=0, the
explicit term ∫ ε J_Λ R(φ_C) remains. Its LEFT source derivative has
negative sign on the connected source side. A separate finite
stationary fixture checks nonzero direct and rooted coefficients.

In color 12 the source remainder column and the auxiliary source
driver both vanish. Its uncut mixed master root is zero even before
source restriction. For the other colors the remaining source contact
is a triangular ghost-to-auxiliary shear. This packet fixes its
operator and sign. The common regulated shear comparison remains open.

V1 preserved a failed check on an illustrative ghost-pair key. V2
uses the actual C13/a14 pair of ε12 and keeps the exact coefficient
and stationary tests. The separate V2 final receipt is required.
The inputs, symbolic conventions and AI authorship are shared
dependencies. The result is for the uncut grouped map and preserves
the separate switched result. Full causal/QAP and E5/A5 remain open.
