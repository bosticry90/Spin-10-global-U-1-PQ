"""Verify the selected proper metric and regulator comparison."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


def owner():
    path = ROOT / "calculations/canonical_so10_scalar_source_transport_v2/source_transport.py"
    spec = importlib.util.spec_from_file_location("scalar_transport_owner",path)
    source = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(source)
    return source


def unpack(cells,source):
    assert all(p[:2]==[0,0] for p,_,_ in cells)
    return source.seagull.unpack([([0,*p],n,d) for p,n,d in cells])


def literal(phase,source,f):
    path = ROOT / f"calculations/canonical_so10_unprobed_compact_all_coupling_v1/{phase}_full_current.json.gz"
    rows = source.seagull.read(path)["current"]["complete_S_GF_source"]
    J,L,F,V,derivatives = {},{},defaultdict(lambda:sp.S.Zero),{},{}
    for grade,word,cells in rows:
        ids = [i for i,_ in word]
        if ids[0]>=180 or ids[0]%4!=2:
            continue
        jets = [d for _,d in word]
        if grade==1 and len(ids)==3:
            u,i,j = ids[0]//4,ids[1],ids[2]
            if 553<=i<598 and 643<=j<823 and (j-643)%4==2:
                assert jets==[[],[],[]]
                J[(j-643)//4,u,i-553] = unpack(cells,source)
            if i<180 and i%4==2 and 508<=j<553:
                assert jets==[[],[],[]]
                L[u,i//4,j-508] = L[i//4,u,j-508] = unpack(cells,source)
            if 553<=i<598 and 598<=j<643:
                c,k = i-553,j-598
                z = unpack(cells,source)
                derivatives[u,c,k,tuple(bool(d) for d in jets)] = z
                F[k,u,c] += z*(int(bool(jets[2]))-int(bool(jets[0])))
        if grade==2 and len(ids)==4 and ids[1]<180 and ids[1]%4==2 and ids[2]==570 and 610<=ids[3]<643:
            assert jets==[[],[],[],[]]
            u,b,k = ids[0]//4,ids[1]//4,ids[3]-598
            V[u,b,k] = V[b,u,k] = unpack(cells,source)*(1+int(u==b))
    assert len(J)==1674 and all(z==-f[a,u,i] for (a,u,i),z in J.items())
    assert len(L)==668 and all(z==sp.I*f[k,min(a,b),max(a,b)] for (a,b,k),z in L.items())
    for a in (20,23,44):
        for k in range(45):
            for c in range(45):
                z = f.get((k,a,c),0)
                actual = [derivatives.get((a,c,k,t),0)
                          for t in ((True,False,False),(False,True,False),(False,False,True))]
                assert actual==([-z,-z,-z] if c<12 else [0,0,-z])
    bubble,triangle = [],[]
    for a,b in ((44,23),(23,44)):
        bubble.append([sp.expand(sum(z*V.get((u,b,k),0) for (aa,u,k),z in J.items()
                                     if aa==a and k>=12 and (u<12)==light)) for light in (True,False)])
        triangle.append(sp.expand(sum(z*L.get((b,v,u),0)*F[i,u,17]
                                      for (aa,v,i),z in J.items() if aa==a and v<12<=i
                                      for u in range(12,45))/sp.I))
    assert bubble==[[0,0],[sp.Rational(1,10),sp.Rational(1,10)]]
    assert triangle[0]==-triangle[1] and abs(triangle[0])==sp.Rational(1,10)
    return bubble,triangle


def color(f):
    ad = {a:sp.SparseMatrix(45,45,{(i,j):z for (i,h,j),z in f.items() if h==a}) for a in range(45)}
    H = sp.diag(*([1]*12+[0]*33),cls=sp.SparseMatrix)
    I = sp.eye(45,cls=sp.SparseMatrix)
    M = I-H
    S = -sum((ad[h]*ad[h] for h in range(12)),sp.SparseMatrix(45,45,{})).applyfunc(sp.expand)
    assert S[20,23]==-sp.Rational(1,5)
    assert sp.expand((ad[17]*S-S*ad[17])[44,23])==-S[20,23]/2
    for P in (H,M,I):
        assert (ad[17]*P-P*ad[17])[44,23]==0
    C = lambda P,R: -sp.expand(sp.trace(P*ad[20]*R*ad[23]))
    assert [C(P,R) for P,R in ((H,H),(H,M),(M,H),(M,M))]==[0,S[20,23],S[20,23],-2*S[20,23]]
    a,b,c = 44,23,17
    U,V,D = ad[a]*M,ad[b]*M,ad[c]
    g1 = sp.expand(sp.trace(D*(U*V+V*U)))
    g2 = sp.expand(sp.trace(D*(ad[a]*V+ad[b]*U)))
    assert g1==g2==-sp.Rational(1,10)
    symmetric = M*(ad[a]*H*ad[b]+ad[b]*H*ad[a])*M
    assert symmetric.T==symmetric
    get = lambda i,j,k:f.get((i,j,k),0)
    def mixed(a,b,route):
        if route==1:
            return sp.expand(sum(z*get(v,h,a)*get(u,h,b) for (u,v,d),z in f.items()
                                 if d==c and min(u,v)>=12 for h in range(12)))
        return sp.expand(sum(z*get(u,i,b)*get(j,u,c) for (i,d,j),z in f.items()
                             if d==a and i<12<=j for u in range(12,45)))
    values = [(mixed(a,b,k),mixed(b,a,k)) for k in (1,2)]
    assert all(u==-v for u,v in values)
    return [[str(u),str(v)] for u,v in values],str(g1)


def oriented_yang_mills(phase,source,f):
    root = ROOT / "calculations"
    choice = "native_v2" if phase=="native" else "replay_v4"
    path = root / "canonical_so10_physical_current_input_recovery_g1_v1" / f"{choice}_action.json.gz"
    rows = source.seagull.read(path)["S1_gauge"]
    p,q = sp.Matrix([0,2,0,0]),sp.Matrix([1,2,3,0])
    k = q+p
    Q = q.dot(q)
    T = sp.eye(4)-q*q.T/Q
    u,h,b = 19,0,23
    momenta = {u:-k,h:q,b:p}
    total = sp.S.Zero
    count = 0
    for word,cells in rows:
        axes = {i//4:(i%4,d) for i,d in word}
        if set(axes)!={u,h,b} or axes[b][0]!=2:
            continue
        assert all(v[:3]==[1,0,0] for v,_,_ in cells)
        coeff = source.seagull.unpack([([0,*v[1:]],n,d) for v,n,d in cells])
        (color,[mu]), = [(c,d) for c,(_,d) in axes.items() if d]
        total += coeff*momenta[color][mu]*k[axes[u][0]]*T[axes[h][0],2]
        count += 1
    assert count==18
    assert sp.expand(total/f[u,h,b])==(p.dot(p)-Q)*T[2,2]==-sp.Rational(25,7)
    path = root / "canonical_so10_regulator_free_inverse_g1_recovery_v1" / f"{phase}_inverse.json.gz"
    rows = source.seagull.read(path)["Greference"]
    qvar = sp.symbols("q0:4")
    Qvar = sum(x*x for x in qvar)
    for mu in range(4):
        B,L = 4*u+mu,508+u
        z = {(a,b):sp.sympify(v) for a,b,v in rows if (a,b) in ((B,L),(L,B))}
        assert z[B,L]==-qvar[mu]/Qvar and z[L,B]==qvar[mu]/Qvar


def finite():
    Q,P,a,b = sp.symbols("Q P a b",positive=True)
    c = a+b
    low = sp.integrate((sp.Rational(3,4)+Q/(12*P))/P,(Q,0,P))
    high = sp.integrate(P/(12*Q**2),(Q,P,sp.oo))
    assert low==sp.Rational(19,24) and high==sp.Rational(1,12)
    assert low+high==sp.Rational(7,8)
    # A(p)-A(0): expand the completed-square Schwinger representation.
    v,t = sp.symbols("v t",positive=True)
    c0 = sp.Symbol("c_0",positive=True)
    direct = sp.integrate((-t*a*P+t**2*a*a*P/v)/v**2,(v,t*c0,sp.oo)).subs(c0,c)
    jets = P*(-a/c+a*a/(2*c*c))
    assert sp.simplify(direct-jets)==0
    A = sp.simplify(jets.subs(b,a)/(16*sp.pi**2))
    I = sp.Symbol("I_T")
    Pi = -sp.Rational(2,5)*(P*I-A)
    proper = sp.simplify(-I/5-Pi/(2*P))
    explicit = -A/(5*P)
    assert proper==explicit==3/(640*sp.pi**2)
    assert -I/5!=proper and sp.simplify(A)!=0
    return str(proper)


def check(phase):
    source = owner()
    _,_,_,bracket,_,_ = source.inputs(phase)
    f = {(i,a,b):z for (a,b),pairs in bracket.items() for i,z in pairs}
    D,T = literal(phase,source,f)
    oriented_yang_mills(phase,source,f)
    mixed,ghost = color(f)
    return {"literal_source_bubble":[[str(x) for x in row] for row in D],
            "literal_source_triangle":[str(x) for x in T],
            "mixed_regulator_exchange_pairs":mixed,
            "both_ghost_regulator_traces":ghost,
            "ordered_YM_mixed_orientation":"-25/7",
            "hard_T22_finite_constant":"7/8",
            "common_profile_metric_and_regulator_remainder":finite()}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
