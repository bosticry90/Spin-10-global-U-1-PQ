# V986 result

At zero background, unit switch and common gauge
quartet profiles, the actual transverse metric
entry (20,23) contributes a nonzero ordinary
logarithm. The source companion on C17 with
B44 and B23 cancels that logarithm exactly.
After subtracting the p-independent part,
the finite common-profile coefficient is
`3/(640*pi**2)` in stripped units.

The regulator calculation gives the same
coefficient from the B²Ca quartic with its
ordered collapsed regulator line. The
two ghost cubic families have opposite
signs and nonzero equal color traces.
The mixed cubic families cancel under
exterior exchange. The actual mixed
Yang-Mills vertex uses the momentum on
the correct side of the B-Lambda inverse.

The first worker failed a BB Lambda
table assertion because the two even
slots share one canonical bracket order.
The failed packet is preserved. V2
checks both slot assignments and the
paired finite term in both exports.
The result is confined to this selected
common-profile transverse equation.
It does not select a normalization
or establish connected equivalence.
