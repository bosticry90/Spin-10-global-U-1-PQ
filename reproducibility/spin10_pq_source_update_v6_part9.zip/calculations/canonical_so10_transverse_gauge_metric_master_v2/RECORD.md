# V986 pre-execution contract

Freeze V985, V941 metric, V944/V945 source
colors, and the actual V788/V879/V791 tables.
Use unit switch, zero background, width and
intrinsic grades, common paired gauge-quartet
profiles, and the transverse 20,23 metric.
Use B44(p), B23(-p) and C17(0) for the
proper master witness. Compute the projected
metric and source cancellation and derive
the independent quartic regulator root and
prove the cubic root cancellations. Require a nonzero finite residue and
an independent hard-angular integral. Keep
the common-profile and constant-C scope.
No finite normalization is selected.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority change.

## Version 2 continuation

The first worker stopped in the BB Lambda table
guard. The even B slots are stored with their
light/broken order fixed and copied symmetrically
for the two orientations. Check each copied row
against that same canonical bracket order.
Preserve the first worker and capture. No graph,
sign convention, numerical target or resource
limit changes.
