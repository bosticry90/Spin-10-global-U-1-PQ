# Off-diagonal transverse metric and its first regulator root

Use the V941 ordinary metric row (20,23) at
unit switch and zero background. Set eta_H,
xi and physical intrinsic degree to zero.
Use common H and M paired profiles on the
gauge quartet. Project both external fields
to axis e2 and their momentum p to axis e1.
Write Q=q², K=(q+p)², P=p²>0 and
T=T(q), the transverse projector. A constant
ghost C17 tests the row on external B44
and B23. The selected constant transfer is
evaluated after the indicated projector and
cancellation of any mixed inverse numerator.
The remaining two distinct shifted poles
are locally integrable. This is a restricted
unit-switch coefficient.

Write C_H=-sum_h ad_h². The actual row
C_H(20,23)=-1/5. The H/M and M/H pure
gauge loop colors equal C_H. The M/M
color is -2 C_H and H/H gives zero. All
ordinary profiles match, so the pure BBB
terms cancel at the same Lorentz kernel.
Invariant scalar or fermion loops have
diagonal trace in gauge color. Tadpoles
do not contribute to the selected p²
coefficient. Two BB Lambda vertices in
this row leave light B and broken Lambda
internal at each vertex. There is neither
a Lambda-Lambda line nor a light-B to
broken-Lambda free line.

In the ghost cycle the mixed H/M case
has the equal three literal derivative
coefficients. Their sum at unit switch
is zero by momentum conservation. The
returning M/M case gives
C_MM times the kernel q_2²/(Q K), where
C_MM=-2 C_H. The two derivative vertices
supply i², the skew color trace supplies
a minus, and the ghost log expansion
supplies a plus. Here q_2=(q+p)_2.

The BBB and BB Lambda cross term has
ordinary H and mixed M internal. For
mixed k=q+p, use the ordered B-Lambda
line at -k (numerator +k) and the BB Lambda coefficient
+i f_(u h a). Contract the complete
polarized BBB Lorentz tensor at momenta
(-k,q,p) with (+k)_alpha T(q)_(beta,2).
After stripping i f_(u h b) its three
terms reduce to (P-Q) T_22(q). The first
and third longitudinal-transfer pieces
cancel. The negative second log term
and the two factors of i give a plus.
The two external placements give
2 C_H (P-Q) T_22/(Q K). Together with
the M/M ghost this is

    Pi_20,23 = 2 C_H [P I_T - A],
    I_T=integral F(q) F(q+p) T_22/(Q K),
    A=integral F(q) F(q+p)/K.

In particular A retains both heat factors
after the collapse. The pure one-line
tadpole would give a different result.

The scalar products in [ad_17,Pi]_(44,23)
reduce to -Pi_20,23/2. In the source
response, the V940 J_B B C with B²Ca
tensor in the two orderings is (0,0) and
(1/10,1/10) in H/M order. The source-first
log and ghost signs give the negative
of their sum. The two mixed triangles
have opposite literal colors and identical
common-profile weights, so they cancel
after the exterior exchange. The purely
ordinary B triangle has an internal
transverse B contracted by its ghost
derivative at zero C momentum. The
mean auxiliary and antighost companions
are absent in this transverse, two-M
slice. Thus the scalar-normalized
source plus commutator is

    -I_T/5 - Pi_20,23/(2P) = -A/(5P).

The source and ordinary nonlocal logs
cancel. For independent heat lengths
a,b on q,q+p and c=a+b, the finite part
of A is P(-a/c+a²/(2c²))/(16 pi²).
Shift to k=q+p and expand the Gaussian
through its first and second heat jets.
The second jet is needed. At a=b the
projected finite remainder is 3/(640 pi²).
An independent I_T angular check expands
1/K against four-dimensional Gegenbauer
polynomials. Averaging T_22 at fixed
angle gives 3/4+U_2/12. The result is
[3/4+min(Q,P)/(12 max(Q,P))]/max(Q,P)
before the radial integral. The intervals
below and above P yield finite constants
19/24 and 1/12 beside the common 3/4 log.
This independently fixes the nonzero
ordinary logarithm that cancels.

One separate regulator topology uses
the B-mean derivative of F_B with
respect to C, paired with the literal
B²Ca Hessian. Its root color is the
same C-first j as in the source bubble.
The normalized insertion and crossing
signs give the positive D tensor.
Collapse the paired R against the root
free line, yielding (1-F(q+p)).
After the two exterior assignments the
result is

    (1/5) integral F(q)(1-F(q+p))/Q.

Subtract the p=0 value before isolating
the p² coefficient. The first term is a
momentum-independent tadpole. In the
second term change q to -q-p. This leaves
-[A(p)-A(0)]/(5P), with the same finite
part as -A/(5P), exactly the observed proper
residue. This verifies an actual nonzero cutoff carrier.

For completeness of this projected RHS, use
the one-loop normalized covariance F'_i G R
with all source derivatives ordered. The free
linear operation gives zero by the matched
quadratic quartet. A constant exterior broken
ghost gives no q_Lambda or q_a degree-one
rotation. The invariant scalar regulator
commutes with its constant generator. A
derivative of F_B with respect to B has a
mixed R port only, since at common profiles
the two Maxwell-BB placements cancel. The
remaining cubic graph families are the
C-mean F_C derivative, the B-mean F_B
derivative with two ordinary ghost vertices,
and the two mixed types.

Write D=ad_17 and A_j=ad_j P_M on the full
ghost color frame. For exterior broken B_j
the input C_H part of its ordinary B C a
vertex is the unit total derivative. In the
C-mean F_C root the signed color is
-tr D(A_a A_b+A_b A_a). For the B-mean
F_B root paired with two ghost cubics it
is +tr D(ad_a A_b+ad_b A_a). Orient the
C and a contractions before applying the
two derivative factors; the signs include
the exterior ghost crossing. After reversing
the loop routing, both use
q_2² F(q) F(k)(1-F(q))/(Q K). The difference
inside the traces reduces to the trace of
D against the symmetric matrix
P_M(ad_a P_H ad_b+ad_b P_H ad_a)P_M.
It vanishes. Both actual signed operands
are nonzero for a=44,b=23.

For the mixed C-mean F_B derivative,
the BB Lambda and BBB color is
sum f_(u v 17) f_(v h a) f_(u h b),
with u,v broken and h light. Exchanging
the exterior B fields and u,v reverses
the sign while leaving its momentum kernel
unchanged under p reversal. For the
mixed B-mean F_B derivative the BB Lambda
and ghost cubic color is
sum f_(i a j) f_(u i b) f_(j u 17).
Exchange j,u and the exterior fields.
Again the sign reverses and the kernel
agrees. Two BB Lambda slots cannot close
their field types. The all-ordinary BBB
attachment to the ghost derivative has
its momentum killed by the transverse
projector. An exterior-C quartic root is
momentum independent because both B
means enter the same vertex.

The surviving p² RHS is the quartic
root above. This qualifies the projected
modified identity at common profiles.
It does not establish an unequal-profile
or enlarged compact/causal construction.
Both routes share the action and software.
