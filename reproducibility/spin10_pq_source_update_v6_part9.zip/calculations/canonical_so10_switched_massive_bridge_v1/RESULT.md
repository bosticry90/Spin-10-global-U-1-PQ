# Exact causal massive feedback bridge V908

The switched positive-mass bridge has a uniform soft expansion
with an exact inverse remainder. For lambda=1/R, the leading
difference from the bare bridge is minus lambda squared times
V f_lambda/M². The fixed derivative remainder is O(lambda^4)
on compact sets. The original converted one-port loop supplies
a compact source with a controlled rescaled limit.

The leading bridge term is supported on the switch-potential
region away from the source origin and pairs with the bounded
exact exterior product. The higher-order terms vanish even under
the rough weighted two-root bound. Consequently the massive
feedback bridge does not change the V907 limiting profile
difference, with all switches on that bridge and on the exterior
ghosts summed.

This uses the original one-port loop and its UV forest. Quadratic
switches inside the proper and one-port loops remain open. Exact
replay checks the finite expansion, commutator and scaling margins
with the same action, normalization and software.
