"""Exact expansion, derivative and feedback controls for V908."""

import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def bridge_route(phase):
    l,M,Q = sp.symbols("lambda M Q", positive=True)
    P,V = sp.symbols("P V", commutative=False)
    if phase == "native":
        response=-sum(l**(2*n)*Q**n/M**(n+1) for n in range(3))
    else:
        response=sp.series(1/(l*l*Q-M),l,0,6).removeO()
    assert sp.expand((l*l*Q-M)*response-1+l**6*Q**3/M**3) == 0
    diff=sp.expand(response.subs(Q,P+V)-response.subs(Q,P))
    assert sp.expand(diff.coeff(l,2)+V/M**2) == 0
    assert sp.expand(diff.coeff(l,4)+(P*V+V*P+V**2)/M**3) == 0
    n=sp.symbols("N",integer=True,positive=True)
    assert sp.expand(2*n-2).subs(n,3) == 4
    return {"bridge_local_change":"-lambda**2*V*f/M**2",
            "fixed_derivative_remainder":"O(lambda**4)",
            "weighted_inverse_loss":"lambda**-2"}


def derivative_and_pairing():
    x=sp.symbols("x")
    V=sp.Function("V")(x)
    f=sp.Function("f")(x)
    l=sp.symbols("lambda",positive=True)
    assert sp.expand(sp.diff(l*l*V*f,x)-l*l*V*sp.diff(f,x)) == l*l*f*sp.diff(V,x)
    assert l**-2*l**2 == 1
    assert l**3*l**-2 == l
    assert l**4*l**-2 == l**2
    assert l**2*l**-2 == 1
    return {"commutator_cancels_weighted_inverse_loss":True,
            "source_replacement_pairing_margin":1,
            "approximation_error_pairing_margin":2,
            "without_away_origin_leading_control_margin":0}


def check(phase):
    here=ROOT/"calculations"
    prev=json.loads((here/"canonical_so10_exact_outer_ghost_group_v1/result.json").read_bytes())["checks"]
    assert prev["feedback"]["reference_combination"] == "300*log(M_Sigma/M_Phi)"
    assert prev["feedback"]["weighted_feedback_blocks"] == ["500","15/4"]
    mass=json.loads((here/"canonical_so10_lorentzian_gauge_preconditioner_v1/result.json").read_bytes())["checks"]
    assert mass["inverse"]["massive_bound"] == "same Newton domination"
    return {"bridge":bridge_route(phase),"sewing":derivative_and_pairing(),
            "reference_combination":prev["feedback"]["reference_combination"]}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
