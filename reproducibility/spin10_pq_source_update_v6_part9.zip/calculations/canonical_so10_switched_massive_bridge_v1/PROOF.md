# Exact switched massive feedback bridge

Use the V907 selected connected ghost group with the original
kinetic one-port loop and the converted zero one-edge Y tadpole.
Retain no internal quadratic insertions inside those loops. Here
sum every quadratic switch on the massive bridge to Y. The
exterior ghost inverse is exact as in V907. The same real compact
profiles and sequential Feynman prescription are used, with the
V905 strict simple-pole contraction. Work at one fixed positive
squared scalar reference mass M at a time.

## Local source and normalization

The finite converted one-port is paired with its own ordinary
switches before the bridge is applied. The tree sewing in COS1
retains the same normalized one-port core and original forest on
each bridge word. The V897 boundary instruction for a switch only
on the bridge likewise keeps the whole regulated bridge when
subtracting the tadpole. In this causal comparison the converted
core is kept and the continuum bridge is evaluated on its compact
one-port source. No new bridge-dependent tadpole normalization
is used. If the kinetic derivative is on the rooted scalar port,
move it to that switched source by the ordinary Euler adjoint
before applying the bridge. This keeps the switch-jet terms.

With lambda=1/R, write the resulting physical source as
f_lambda(lambda x). Its support in rescaled variables is in a
fixed compact set, since the external scalar slot is at an
ordinary switched vertex. For the original one-mass one-port
loop the converted kernel is analytic at small independent
transfers by V907. Therefore

    f_lambda = f_0 + O(lambda)

in each fixed C^k norm, with a common compact support. The
zero-transfer term has the inherited local feedback constant
and ordinary switches. To see the estimate, Fourier scale all
ordinary transfers. On small physical transfers the analytic
Taylor remainder is bounded by C lambda sum |ell_i|. A
rescaled position derivative costs a polynomial in the ell_i.
The original tempered converted kernel and rapid switch tails
control the complementary bands to arbitrarily high power.
Explicit physical derivatives transferred to the source bring
a factor lambda. These arguments also give all fixed weighted
L² derivative norms needed below. The Lorentzian massive shell
in the bridge has not been replaced by a pointwise bound.

## Exact large-scale expansion on the bridge

In rescaled coordinates put P=−Box, V=Box chi/2 and Q=P+V.
The inverse for the bridge acts on f_lambda through

    H_lambda = lambda² Q − M,
    u_lambda = (H_lambda+i0)^−1 f_lambda.

By V905 its weighted inverse is lambda^-2 times the same
simple-pole inverse at squared mass M/lambda² with potential V.
The scalar Feynman Hardy bound is uniform in that mass, so

    ||rho^-1 H_lambda^-1 g||_2
          <= C lambda^-2 ||rho g||_2.

The bound follows at positive absorption in the rescaled
variables and passes strongly to the sequential boundary.
No joint absorption and R rate is required.

For any finite N use the compact approximate response

    u_lambda^(N) =
      − sum_(n=0)^(N−1) lambda^(2n) M^(−n−1) Q^n f_lambda.

Then H_lambda u_lambda^(N) =
f_lambda−lambda^(2N) M^-N Q^N f_lambda. At the Feynman
boundary the approximate response can be subtracted using
the exact two-sided inverse on compact smooth functions.
This identity also follows by applying the inverse at
positive absorption to the compact response and sending the
extra absorption term to zero at each fixed lambda.
The weighted error is O(lambda^(2N−2)).
The same error bound holds for each fixed derivative in
the same weight. Indeed differentiation commutes with the
free inverse, while [partial,H_lambda]=lambda² partial V.
For higher derivatives the product rule yields compact
lower-derivative sources. Their weighted source norms obey

    ||rho (partial^beta V) v||_2
         <= ||rho² partial^beta V||_inf ||rho^-1 v||_2.

The lambda² of these sources cancels the inverse loss.
Induction from the weighted inverse yields the stated
bound at every fixed order. Differentiation is justified
first at finite absorption by local wave resolvent gain
and compact smooth coefficients, then by the weighted
identity and strong boundary. In particular on each fixed
compact set, ordinary Sobolev embedding gives the same
error in C^k after taking finitely many derivatives.

Use N=3 for both switched and bare inverses, with the
same source. The constant and bare kinetic terms cancel,
and their difference on fixed compact sets is

    u_lambda^V−u_lambda^0
        = −lambda² V f_lambda/M² + O_C^k(lambda⁴).

This resolves the full bridge sum rather than truncating
its Born expansion. The first new coefficient is supported
on the switch-potential support, away from the source
origin. Every derivative of the remainder has the stated
bound. In physical coordinates a bridge derivative gains
one further power of lambda. In the actual feedback such
a derivative can instead be included in the source as
above.

## Pairing with both exact ghost roots

After changing variables at Y the two physical ghost roots
contribute the two lambda² factors and the four-volume
cancels them. Thus the bridge difference is paired with
the rescaled exact ghost product and the ordinary switched
Y vertex. Its leading coefficient is lambda² times the
fixed compact test −chi V f_0/M². This test is away from
the origin. The V902 same-branch product limit and the
Schwartz extension in V907 give a bounded pairing.
The residual from replacing f_lambda by f_0 is O(lambda³)
on a fixed compact set. For this and the O(lambda⁴)
remainder one can use just the V901 weighted L² estimate.
Each rescaled ordinary source j^[R] has weighted norm
R ||rho j||₂, so the two exact roots against a bounded
compact rescaled coefficient cost at most O(lambda^-2).
Both residuals then vanish. This avoids applying a
point-root product at the origin to an arbitrary moving
coefficient. The limit of the switched bridge correction
is zero in the actual feedback.

The V907 profile difference therefore persists with all
quadratic switches on the massive feedback bridge and
all exterior ghost switches. The same two-color
normalization-independent combination is used. This result
does not sum any quadratic switches inside the proper
or one-port loops. Those terms and the unit-profile gauge
Feynman kernel still require separate evidence.
