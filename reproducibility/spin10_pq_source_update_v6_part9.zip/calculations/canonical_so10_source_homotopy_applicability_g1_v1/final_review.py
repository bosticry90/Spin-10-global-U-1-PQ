from pathlib import Path
from hashlib import sha256
import gc,gzip,importlib.util,json,os,re,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/source-homotopy-applicability-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(240,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in['preparation.json','final_preparation.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 cap=read(O/'capture.json');res=read(O/'result.json');assert cap==read(C/'capture.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and res['elapsed_after_imports']<300;assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and cap['all_resource_samples']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);assert res['all2572_g0_action_interfaces_equal']and res['all19290_branch_ports_sourcefree_covered']and res['all12_union_divergences_exact']
 sp=importlib.util.spec_from_file_location('source_homotopy_final_helpers',O/'audit.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a);J=a.J;interfaces=[];verified_factors=verified_ports=0;artifact_names=[]
 for role in['native','replay']:
  packet=load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));current={k:dict(v)for k,v in packet['states'].items()};g0=load(O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_GF_common.json.gz'));g1=load(O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1'/(role+'_new_states.json.gz'));owners={'F0':dict(g0['F0']),'E0':dict(g0['E0']),**{k:dict(v)for k,v in g1.items()}}
  for pr in[0,1]:owners['Fu0_'+str(pr)]=dict(g0['probes'][pr]['source_first_Fu']);owners['Eu0_'+str(pr)]=dict(g0['probes'][pr]['full_Eu'])
  assert set(current)==set(owners)and len(current)==12
  for name in sorted(current):
   assert set(current[name])==set(owners[name])==set(range(643))
   for n in range(643):assert current[name][n]==owners[name][n],(role,name,n,'COMMON_ACTION_OWNER_INTERFACE');interfaces.append([role,name,n,sha256(json.dumps(current[name][n],sort_keys=True).encode()).hexdigest(),True])
  z=load(O/(role+'_full_sourcefree_support.json.gz'));assert len(z['all7716_factor_columns'])==7716 and len(z['all9645_port_branch_decisions'])==9645 and z['max_possible_GF_product_scalar_count']==1
  seen=set()
  for row in z['all7716_factor_columns']:
   name,n=row['state'],row['field'];assert(name,n)not in seen;seen.add((name,n));P=J.decode(current[name][n]);sf={w:c for w,c in P.items()if all(i<643 for i,js in w)};words=sorted(sf);assert row['full_sourceful_math_sha256']==a.f.phash(P)and row['source_free_math_sha256']==a.f.phash(sf)and row['source_free_words']==len(words);indices=set()
   for p,ids in row['all_profile_word_indices']:
    for at in ids:assert at not in indices and 0<=at<len(words)and tuple(p)==a.profile(words[at]);indices.add(at)
    if p[1]:assert p[1]==1 and a.GRADES[name]==1
   assert indices==set(range(len(words)));verified_factors+=1
  actual={(row['case'],row['left'],row['right'],row['field'])for row in z['all9645_port_branch_decisions']};wanted={(label,l,r,n)for label,g,branches in a.CASES for l,r in branches for n in range(643)};assert actual==wanted and len(actual)==9645
  for row in z['all9645_port_branch_decisions']:
   for lp,rp,p,selected,A,B in row['all_factor_profile_pair_decisions']:assert p==[x+y for x,y in zip(lp,rp)]and p[1]<=1 and (not selected or A or B)
   verified_ports+=1
  for row in z['complete_count_jet_intrinsic_type_envelope']:
   b,x,l,ab,c=row['field_counts'];assert c==ab+1 and row['bare_dimension']==b+x+2*l+2*ab+1 and row['bare_dimension']+row['ordinary_jets']+row['intrinsic']==5 and row['ordinary_jets']>=0 and row['intrinsic']in[0,1]
  assert sorted(z['all_type_profiles_outside_old_union'])==sorted([[0,3,0,0,1],[0,4,0,0,1],[1,3,0,0,1],[0,2,1,0,1]])
  gi=load(O/(role+'_g0_action_Euler.json.gz'));assert len(gi['all1286_action_interfaces'])==1286 and all(t['equal']and t['actual_hash']==t['expected_hash']for t in gi['all1286_action_interfaces'])and not gi['complete_nonzero_differences'];un=load(O/(role+'_union_divergences.json.gz'));assert len(un['all_six_cases'])==6 and all(not t['complete_divergence_residual']for t in un['all_six_cases']);assert load(O/(role+'_signed_fixtures.json.gz'))==a.fixtures(role)
  for key in['integrability','support','union_witness','fixtures']:
   art=next(t for t in res['routes']if t['route']==role)[key];assert digest(O/art['file'])==art['sha256']and(O/art['file']).stat().st_size==art['bytes']
  del current,owners,g0,g1,packet,z,P,sf,words;gc.collect()
 for p in sorted(O.glob('native_*.json.gz')):assert p.read_bytes()==p.with_name(p.name.replace('native_','replay_',1)).read_bytes();artifact_names.append(p.name)
 assert len(interfaces)==verified_factors==15432 and verified_ports==19290 and len(artifact_names)==4
 owner_preps=['canonical_so10_aCC_operator_reduction_g1_v1/master_preparation.json','canonical_so10_BBC_master_applicability_g1_v1/preparation.json','canonical_so10_BBC_master_applicability_g1_v1/physical_preparation_v2.json'];parent_matches=[]
 for owner in owner_preps:
  bindings=read(O.parent/owner)['sha256']
  for role in['native','replay']:
   name='calculations/canonical_so10_proper_slavnov_actual_operators_g1_v1/'+role+'_inputs.json.gz';assert bindings[name]==digest(R/name);parent_matches.append([owner,name,bindings[name]])
 physical=read(O.parent/'canonical_so10_BBC_master_applicability_g1_v1/physical_bridge_result_v2.json');assert physical['all_physical_source_packet_operands_match_qualified_Noether']and physical['all3858_own_jet_columns_zero_before_restriction'];field=read(O.parent/'canonical_so10_full_source_field_square_g1_v1/validation_receipt.json');assert field['all3858_field_columns_zero_in_both_routes'];cps=(O.parent/'canonical_so10_chiral_probe_support/DERIVATION.md').read_text(encoding='utf-8');assert 'has no a/Lambda or Ja/JL dependence'in cps and 'does not prove a source'in cps
 art=a.save('final_constructing_owner_interfaces',dict(all15432_common_action_owner_columns=interfaces,exact_A_B_physical_input_packet_bindings=parent_matches,common_action_NOT_inferred_from_field_maps_only=True,qualified_physical_Noether_and_own_jet_reused=True,source_derivatives_preserve_CPS_ideal_by_written_proof=True));print('STAGE constructing_owners_factor_support_journals_fixtures_and_physical_interfaces_verified',flush=True)
 history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);raw=(R/'README.md').read_bytes();assert raw.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792';assert(C/'README_before.md').read_bytes()==subprocess.check_output(['git','show','HEAD:README.md'],cwd=R);links=[]
 for path,body in[(R/'README.md',raw[:-len(history)].decode('utf-8')),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V830.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V830.md').read_text(encoding='utf-8'))]:
  for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',body):
   if target.startswith(('https:','http:','#','mailto:')):continue
   resolved=(path.parent/target.split('#')[0]).resolve();assert resolved.is_relative_to(R)and resolved.exists(),(path,target);links.append([path.relative_to(R).as_posix(),target])
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120);ec=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert p.returncode==0
 events=[json.loads(x)for x in p.stdout.splitlines()if x.strip()];exits=[x['exit_code']for x in events if x['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and events[-1]['execution_state']=='COMPLETED'and next(x for x in events if x['event']=='step_finished'and x['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 tree=(C/'old_git_tree.txt').read_bytes();assert tree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R).decode().splitlines()==['README.md'];state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';files=[p for p in O.iterdir()if p.is_file()]+[R/'README.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V830.md'];size=sum(p.stat().st_size for p in files);assert size<=64*1024**2 and all(p.stat().st_size<=10*1024**2 for p in files)
 out=dict(schema='SELECTED_SOURCE_HOMOTOPY_AND_FINITE_PROPER_APPLICABILITY_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_SELECTED_BOSONIC_SOURCE_HOMOTOPY_AND_FIRST_U_FINITE_PROPER_APPLICABILITY',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,all2572_g0_action_interfaces_equal=True,all15432_constructing_owner_F_E_columns_equal=True,all15432_factor_classifications_verified=True,all19290_port_branch_journals_verified=True,all12_union_divergences_exact=True,all4_complete_route_artifacts_equal=artifact_names,fixture_routes_freshly_recomputed=True,actual_scalar_grade_excludes_Lambda_x2_C=True,owner_interface_artifact=art,source_homotopy_and_signed_Jacobi='WRITTEN_GENERAL_PROOF_WITH_ACTUAL_COMMON_ACTION_PREMISES',physical_Noether_CPS_Jacobian_and_V801='QUALIFIED_OWNERS_REUSED_WITH_EXACT_INPUT_BINDINGS_AND_DECLARED_SCOPE',finite_first_u_scope='g<=1_intrinsic01_B_Lambda_C_a_JB_JLambda_JC_Ja_jets_PS_K_and_scalar_means_sources_zero_after_allowed_derivatives',finite_proper_relation='QGamma1=-C_Q=C_R_NO_UNKNOWN_AMPLITUDE_ASSIGNED',Ihat_source_curvature_and_unprobed_proper_zeros_NOT_removed=True,no_complete_module_HB1_C5_activation_restoration_E5A5_or_goal_claim=True,shared_action_chart_ring_helpers_AI_limit_independence=True,primary_seconds=res['elapsed_after_imports'],largest_primary_sampled_private_bytes=max(x['private_bytes']for x in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries=len(tree.splitlines()),README_historical_suffix_sha256=sha256(history).hexdigest(),checked_local_links=links,files_excluding_pending_receipt_final_capture={p.relative_to(R).as_posix():digest(p)for p in files},packet_bytes_excluding_pending_receipt_final_capture=size,final_review_seconds=time.perf_counter()-tick)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k]for k in['execution_state','evidence_validation','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
