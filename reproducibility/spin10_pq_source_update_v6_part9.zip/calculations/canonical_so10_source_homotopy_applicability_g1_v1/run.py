from pathlib import Path
from types import ModuleType
from hashlib import sha256
import ast,importlib.util,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/source-homotopy-applicability-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
assert not(O/'preparation.json').exists();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='5e54dbe401d41db199f70300b47bbe68a57e50ca'and not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R)
names=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V829.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md']
for folder,files in[('canonical_so10_full_source_field_square_g1_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_restoration_probe_interface_audit_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_proper_slavnov_actual_operators_g1_v1',['validation_receipt.json','native_inputs.json.gz','replay_inputs.json.gz']),('canonical_so10_new_physical_returning_inventory_g1_recovery_v1',['validation_receipt.json','inventory.py','native_route_density.json.gz','replay_route_density.json.gz']),('canonical_so10_full_current_inventory_g1_recovery_v1',['validation_receipt.json','algebra_review_result.json','algebra_review.py','factory.py','native_route_densities.json.gz','replay_route_densities.json.gz']),('canonical_so10_BBC_master_applicability_g1_v1',['validation_receipt.json','PROOF.md','physical_preparation_v2.json','physical_bridge_result_v2.json']+['master_scope_'+label+'.json.gz'for label in['original_g0','original_g1','probe0_g0','probe0_g1','probe1_g0','probe1_g1']]),('canonical_so10_aCC_operator_reduction_g1_v1',['validation_receipt.json','PROOF.md','master_Taylor_commutation.json.gz','master_original_g0.json.gz','master_original_g1.json.gz','master_probe0_g0.json.gz','master_v2_probe0_g1.json.gz','master_v2_probe1_g0.json.gz','master_v3_density.json.gz','master_v4_sector_2.json.gz','master_v4_sector_3.json.gz','master_v5_sector_4.json.gz']),('canonical_so10_physical_current_input_recovery_g1_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_chiral_probe_support',['validation_receipt.json','DERIVATION.md']),('canonical_so10_proper_slavnov_source_chain_g1_v1',['validation_receipt.json','PROOF.md'])]:names+=['calculations/'+folder+'/'+n for n in files]
sp=importlib.util.spec_from_file_location('source_homotopy_preparer',O/'audit.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);todo=[m];seen=set()
while todo:
 mod=todo.pop()
 if id(mod)in seen:continue
 seen.add(id(mod));p=getattr(mod,'__file__',None)
 if not p:continue
 p=Path(p).resolve()
 if not p.is_relative_to(R):continue
 if not p.is_relative_to(O):names.append(p.relative_to(R).as_posix())
 todo.extend(v for v in vars(mod).values()if isinstance(v,ModuleType))
for n in sorted(set(names)):assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in['RECORD.md','audit.py','run.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as h:h.write((O/n).read_bytes())
C.mkdir(parents=True,exist_ok=False)
with(C/'old_git_tree.txt').open('xb')as h:h.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
dump(O/'preparation.json',dict(base_HEAD=head,sha256={**{n:digest(R/n)for n in sorted(set(names))},**{p.relative_to(R).as_posix():digest(p)for p in O.iterdir()if p.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'audit.py')]);dump(O/'capture.json',cap);dump(C/'capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
