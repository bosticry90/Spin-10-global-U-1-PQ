# Source homotopy and the selected bosonic proper identity

This proof is conditional on the completed input audit and final validation
receipt. SHA-GF-1 concerns the current 643-coordinate bosonic GF/source
functional through g1, first-u H/M, intrinsic 0/1, in the original constant
Euclidean A0 coefficient ring. SHA-FIN-1 applies it to the existing finite
formal Gaussian prescription on a specified mean/source plane. Neither is
a full quantum restoration, a continuum QAP or E5/A5 acceptance.

## Common action and the actual Hamiltonian signs

Let z_i have parity p_i, J_i parity p_i+1, s_i=(-1)^p_i, and let S_GF be
the same even local action for both maps. All derivatives below are LEFT
variational derivatives, with ordinary total derivatives integrated by parts.
Use exactly

    E_i = EL_z_i S_GF,  F_i = s_i EL_J_i S_GF,
    Q z_i = F_i,       Q J_i = s_i E_i,
    B_GF = sum_i F_i E_i.

V829 calculated the field squares with these source operations before any
source restriction. The new S0 audit checks all 643 field and 643 source
Euler interfaces of each native/replay original_GF density. For g1 and both
probe grades, the qualified full-current construction and V828 source-first
qG comparison supply the common-action premise. Final validation must
also compare every current F/E column with its actual constructing owner;
a matching field map alone would not establish this premise.

These signs are not silently identified with an older weighted chart.
The fixed involution Jtilde_i=s_i J_i gives
Qz_i=EL_Jtilde_i S_tilde and QJtilde_i=EL_z_i S_tilde. Transport the
canonical odd variational bracket under this involution. Its graded Jacobi
identity, equivalently differentiating the two Euler maps using graded
symmetry of the second variation, gives in the ORIGINAL chart

    Q² z_i = -EL_J_i B_GF,    Q² J_i = EL_z_i B_GF.

Ordinary integration by parts supplies the jet version; Q is evolutionary
and commutes with every ordinary total derivative. Both even and odd pair
fixtures check these signs, including nonzero squares on both members of
the odd pair. The wrong odd-source sign has a retained nonzero residual.
Fixtures do not prove the general Jacobi identity. The argument uses its
constant nondegenerate variational antibracket and the actual common action,
not an assumed master equation or recovered-action/E2 conjugacy.

V829 therefore gives EL_J_i B_GF=0 for every i in the declared quotient.
Nonnegative g, u and intrinsic grades ensure that higher omitted terms
cannot feed these coefficients. No inverse physical parameter, equation of
motion, source-degree cutoff or altered action is introduced.

## Source-scaling variational homotopy

Scale ALL source jets by t. The even source-counting identity and successive
ordinary integrations by parts give

    b(z,J)-b(z,0)
      = integral_0^1 dt sum_i J_i [EL_J_i b](z,tJ)  modulo D_mu j^mu.

Here EL acts before the argument is scaled. If applied instead to the already
scaled polynomial b(z,tJ), the formula has an additional factor 1/t. The
boundary currents are local polynomials: each positive source degree merely
introduces its positive-integer reciprocal, which belongs to the original
rational coefficient ring. D is even, so integrations by parts introduce
no unexplained odd-source sign. LEFT differentiation and the source placed
on the left retain the graded signs. The fixtures test source degrees one,
two and three, a derivative-bearing source, and the nonzero wrong-t result.

Consequently B_GF[J] equals B_GF[0] modulo an ordinary divergence in the
declared quotient. This is source independence, not an assumption that the
source-free remainder vanishes. Setting J=0 here means every source jet.

## Exhaustive source-free GF coverage

Write field counts b,x,l,a,c for gauge, scalar, auxiliary, antighost and
ghost factors. Ghost number one implies c=a+1. Bare dimension is
b+x+2l+2a+1. For each type the audit explicitly enumerates derivative count
5-intrinsic-bare_dimension, for intrinsic zero or one when nonnegative.

The qualified aCC envelope A and BBC envelope B cover respectively

    b+x+l+max(a-1,0)+max(c-2,0) <= 2,
    max(b-2,0)+x+l+a+max(c-1,0) <= 2.

Field count is at least two. The only bare types outside their union are
x³C, x⁴C, Bx³C and Lambda x²C. In particular Lambda x²C cannot be discarded
merely by zero scalar means: both scalar factors could become quantum.

Every actual source-free scalar-bearing GF factor in the selected packet
has exactly one scalar and costs g1. In each of the 9,645 branch/port
products the selected total grade is at most one. Thus every actual product
has scalar count at most one, before any cancellation. The audit retains
all factor profile indices and every product-profile disposition, including
empty partners and outside-intrinsic-two terms. It proves coverage of the
whole selected source-free GF product, not just a few examples. No V827
current-specific root exclusion, guessed scalar zero or fitted coefficient
is used. Every nonempty factor has arity at least one, so actual products
cannot have arity zero or one. More generally any hypothetical linear-C
term at this dimension would have ordinary derivatives and be a divergence;
its T² would also vanish.

Reuse the complete qualified A and B density/current witnesses with their
exact current input bytes. Combine them without double counting:

    P_union = P_A + (1-P_A_selector) P_B,
    j_union = j_A + (1-P_A_selector) j_B.

Field-count selectors commute with D. The density uses total dimension five
and the current dimension four, preserving the same intrinsic selection.
Fresh native and literal derivatives reconstruct all six union identities.
The old failed master workers remain failed/incomplete; their later qualified
witnesses, rather than those failed executions, are reused. No full product
expansion is repeated. Therefore B_GF[0], and by homotopy B_GF[J], is an
ordinary divergence through the declared grades: SHA-GF-1.

## Physical, hatted and proper scope

The physical part is separate from GF. Keep the complete qualified V788
gauge/scalar pre-Taylor Noether divergences and V825's complete actual
operand interface proof. The unprobed physical insertion can acquire u
through the covariance even when all physical probe field flows vanish;
those divergences cannot be replaced by the latter zeros. Unknown physical
E1_x is bypassed by actual F0_x=Fu_x=0, never assigned zero.

Retain the existing unshifted zero-scalar-mean/intrinsic-0/1 potential
restriction. A contributing pure potential gradient times F1_x~Cx leaves
at least three scalar factors in that prescription; T² leaves a scalar mean.
Positive-degree inverse expansions cannot remove that mean. Scalar-field
derivatives could remove it and are not part of this extension.

The admissible external operations here are B, Lambda, C, a, their ordinary
jets, J_B (643..822), J_Lambda (1151..1195), J_C (1196..1240), J_a
(1241..1285), and u. Take these derivatives BEFORE setting P=S=K=0,
scalar means and scalar sources zero. Every operation preserves the CPS
ideal. The qualified SMA [matter action](../canonical_so10_sterile_matter_action/ACTION_V1.md)
has the single matter-source term K_P qP and no bosonic-J matter dependence,
including no J_B or J_C dependence. Its fermion block at that ideal and
the surviving Ihat'' block have no u. Bosonic GF source differentiation
introduces no matter source. Hence the
first-u coefficient of onehalf STr(G Ihat'') vanishes on this plane after
the permitted operations. Ihat itself and its source-sensitive counterexample
remain; no fermion/matter-source or scalar-field derivative is admitted.
An unrestricted source-curvature or full hatted-master zero does not follow.

Even field Taylor and D commute on the jet generators and therefore on
their algebra. Gaussian contraction on the existing translation-invariant
test domain respects the resulting complete divergence. Reuse the qualified
all-source bosonic 3,858-column own-jet Jacobian zero. The matter flows
are probe independent, so their Jacobian has no first-u coefficient; no
global chiral Jacobian zero is asserted. Reuse V801's finite nonlinear-source chain,

    I_B1 = Q Gamma1 + C_Q,    C_Q + C_R = Jac.

The bosonic insertion just proved is a divergence; the physical insertion
uses its full Noether proof and the stated potential restriction. The
first-u hatted trace and Jacobian vanish in this scope. Thus SHA-FIN-1 is

    Q Gamma1 = -C_Q = C_R

through first-u, g<=1 and intrinsic 0/1 in the original fixed-regulator
formal Euclidean Gaussian prescription for the listed external operations.
Keep the whole paired regulator mean subtraction. This does not supply any
unknown C_R amplitude, justify detached inverse-heat/IR maps, interchange
UV/IR limits or prove an unprobed proper zero. Such reference calculations
still require their own independent action-derived inputs and limits.

The standard variational-antibracket and local-functional background is
reviewed by [Gomis, Paris and Samuel](https://arxiv.org/abs/hep-th/9412228)
and [Barnich, Brandt and Henneaux](https://arxiv.org/abs/hep-th/0002245).
Our inference above is the model-specific applicability argument; no general
anomaly-removal or complete counterterm-classification theorem is imported.

Common restoration still requires a complete admitted correlated correction
module and all indispensable quantum inputs, with V823's marked g2 image
and V824's restricted exclusions retained. HB1/C5 remain blocked. Shared
action, chart, ring, software and AI authorship limit independence. No
physical benchmark, E5/A5, quantum measure/phase/QAP/products/equivalence,
physical viability or full investigation completion is established here.
