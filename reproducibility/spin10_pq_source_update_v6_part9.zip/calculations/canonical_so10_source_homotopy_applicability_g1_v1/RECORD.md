# Source-homotopy applicability audit

SHA-1 continues V829 / 5e54dbe401d41db199f70300b47bbe68a57e50ca on main
in D:/Codex-Projects/ToE-Next. Fresh preflight is clean with no matching live
Python workers. State 113 / authority 34/39 remains unchanged. The full goal
is active under AGENTS.md; flavor is paused and HB1/C5 are blocked. No
foundational adoption, protected promotion, new branch/worktree or external
action is included. Root alone writes and runs; agents give read-only reviews.

Question: do the current common-action and source-free support premises
permit applying source-scaling Euler homotopy to the selected bosonic master
insertion through g1, first-u H/M and intrinsic 0/1? Possible outcomes are
exact interface/support matches, a preserved counterexample, or incomplete
execution. No missing loop coefficient or correction is chosen to fit an
identity. This is an ordinary local-functional applicability audit, not a
blocked HB1/C5 basis or cohomology construction.

Before computation freeze exact inputs and sources. Reuse V829 field-square
evidence, V828 full probe Euler interfaces, the actual common-action g1
construction/review and full physical Noether identities. Newly check all
643 field and 643 source Euler columns of each stored g0 original_GF action.
Native uses the existing Euler implementation; replay uses literal prefix
LEFT partials, separately implemented total derivatives and odd sorting.

Journal all source-free factors and all 9,645 branch/port products for both
routes. Source restriction removes every source jet only AFTER all Euler
operations. Verify every scalar-bearing GF factor has exactly one scalar
and coupling grade one. This implies scalar degree at most one in every
g<=1 product. Enumerate the whole ghost-one dimension-five type envelope;
preserve the Lambda x² C exception rather than using V827's current-specific
cut. Verify the actual products cannot have that profile. Check factor
ghost number, parity, intrinsic degree, nonempty arity and exact grade.

Reconstruct all six A-union-B ordinary divergence witnesses from qualified
aCC and BBC owners by J_A + (1-P_A)J_B, using dimension-four current versus
dimension-five density selectors. Native differentiates with the existing
jet derivative; replay uses literal even jet differentiation. Preserve all
hashes, residuals and reconstruction decisions. This is reuse of qualified
products, not another full master expansion. Check current action signs
with two small even/odd canonical-pair fixtures, a wrong odd-source sign
control, and source-scaling/jet homotopy fixtures with a wrong-t control.
Fixtures check conventions; the general inference still requires the written
Jacobi/homotopy proof and actual integrability premises.

The analytical inference has a limited ceiling: source independence modulo
ordinary divergence of the selected bosonic half-master, plus the selected
source-free GF divergence proof. Hatted curvature is retained. A broader
first-u finite proper/current application additionally needs the qualified
full physical Noether/potential scope, own-jet Jacobian, CPS stable ideal
after permitted external operations, and V801 whole regulator mean subtraction.
No unprobed proper zero, continuum QAP, full E2 conjugacy, complete admitted
counterterm module, common restoration, E5/A5 or physical viability follows.

One sequential job runs both routes: 300 seconds after imports, 8 GiB
sampled private memory, 350 MiB launch commit floor, 64 MiB packet and
10 MiB individual artifact. Save a complete overflow on D: controls and
stop incomplete rather than truncate or expand resources. Controls live at
D:/Codex-Research/ToE-Next/research-control-records/source-homotopy-applicability-g1-v1-2026-11-07.
Full captures are saved repo and D: before judging. Preserve every failed
or unfinished execution. Validate the completed evidence before local commit;
freeze any final validation as a separate continuation. Shared action,
conventions, ring, helpers and AI authorship limit independence.
