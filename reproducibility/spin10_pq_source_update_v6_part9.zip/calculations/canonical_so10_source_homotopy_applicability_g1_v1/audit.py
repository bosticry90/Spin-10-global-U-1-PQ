from pathlib import Path
from collections import Counter
from fractions import Fraction as Fr
from hashlib import sha256
import gc,gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/source-homotopy-applicability-g1-v1-2026-11-07')
def module(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
f=module('source_homotopy_square_algebra',O.parent/'canonical_so10_full_source_field_square_g1_v1/squares.py');m=module('source_homotopy_master_owners',O.parent/'canonical_so10_BBC_master_applicability_g1_v1/master_scope.py');J=f.J;one=J.constant(1)
read=f.read;load=f.load;digest=f.digest
CASES=[('original_g0',0,[('F0','E0')]),('original_g1',1,[('F1','E0'),('F0','E1')])]
for pr in[0,1]:CASES += [('probe'+str(pr)+'_g0',0,[('Fu0_'+str(pr),'E0'),('F0','Eu0_'+str(pr))]),('probe'+str(pr)+'_g1',1,[('Fu1_'+str(pr),'E0'),('Fu0_'+str(pr),'E1'),('F1','Eu0_'+str(pr)),('F0','Eu1_'+str(pr))])]
GRADES={fn:g for fn,en,g in f.STATES.values()};GRADES.update({en:g for fn,en,g in f.STATES.values()})
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 name+='.json.gz';blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 if len(blob)>10*1024**2:
  with(C/(name+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as h:h.write(blob)
  raise AssertionError('COMPLETE_OVERFLOW_PRESERVED_NOTPASS')
 with(O/name).open('xb')as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=64*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def scale(P,v):return{w:J.times(c,J.constant(v))for w,c in P.items()if c}
def plus(*ps):
 out={}
 for P in ps:J.add(out,P)
 return J.clean(out)
def atom(n,js=()):return{((n,js),):one}
def literal_euler(P,ids):
 partial={}
 for w,c in P.items():
  for at,(n,js)in enumerate(w):
   if n in ids:
    v=c*((-1)**(f.parity(n)*sum(f.parity(i)for i,jj in w[:at])));d=partial.setdefault((n,js),{});f.literal_put(d,w[:at]+w[at+1:],v)
 out={}
 for(n,js),p in partial.items():
  for mu in js:p=f.literal_D(p,mu)
  J.add(out.setdefault(n,{}),p,(-1)**len(js))
 return{n:J.clean(p)for n,p in out.items()if J.clean(p)}
def profile(w):
 return(sum(n<180 for n,js in w),sum(180<=n<508 for n,js in w),sum(508<=n<553 for n,js in w),sum(598<=n<643 for n,js in w),sum(553<=n<598 for n,js in w),len(w),sum(J.dimension(n)+len(js)for n,js in w))
def envelope(p,totaldim=5):
 b,x,l,a,c,n,d=p;return(n>=2 and b+x+l+max(a-1,0)+max(c-2,0)<=2 and totaldim-d in[0,1],n>=2 and max(b-2,0)+x+l+a+max(c-1,0)<=2 and totaldim-d in[0,1])
def fixtures(role):
 euler=J.euler if role=='native'else literal_euler;mul=J.mul if role=='native'else m.literal_mul;D=J.D if role=='native'else f.literal_D
 def act(P,ops):
  out={}
  for w,c in P.items():
   prefix=0
   for at,(n,js)in enumerate(w):
    im=ops.get(n,{})
    for mu in js:im=D(im,mu)
    for v,d in im.items():f.literal_put(out,w[:at]+v+w[at+1:],J.times(c,d)*((-1)**prefix))
    prefix+=f.parity(n)
  return J.clean(out)
 rows=[]
 for label,fields,S in[('two_even_fields',[0,4],plus(scale(mul(atom(0),atom(0)),Fr(1,2)),scale(mul(atom(4),atom(4)),Fr(1,2)),mul(atom(643),atom(647)))),('odd_field_with_inert_odd_coefficients',[553],plus(scale(mul(atom(1196),atom(1196)),Fr(1,2)),mul(mul(atom(553),atom(598)),atom(1196)),mul(atom(553),atom(599))))]:
  ee=euler(S,set(fields+[643+n for n in fields]));ops={};B={}
  for n in fields:ops[n]=scale(ee.get(643+n,{}),(-1)**f.parity(n));ops[643+n]=scale(ee.get(n,{}),(-1)**f.parity(n));J.add(B,mul(ops[n],ee.get(n,{})))
  B=J.clean(B);be=euler(B,set(fields+[643+n for n in fields]));checks=[]
  for n in fields:
   a=act(ops[n],ops);b=act(ops[643+n],ops);assert not plus(a,be.get(643+n,{}))and not plus(b,scale(be.get(n,{}),-1));checks.append(dict(field=n,field_square=J.encode(a),source_square=J.encode(b),source_Euler_B=J.encode(be.get(643+n,{})),field_Euler_B=J.encode(be.get(n,{}))))
  wrong=dict(ops)
  for n in fields:
   if f.parity(n):wrong[643+n]=scale(wrong[643+n],-1)
  bad=[plus(act(wrong[n],wrong),be.get(643+n,{}))for n in fields];sensitive=any(bad)
  if label.startswith('odd'):assert sensitive
  rows.append(dict(fixture=label,action=J.encode(S),half_master=J.encode(B),signed_Jacobi_checks=checks,wrong_odd_field_source_sign_residuals=[J.encode(p)for p in bad],wrong_control_sensitive=sensitive))
 source=atom(1241);H=atom(553);power={():one};scaling=[]
 for k in[1,2,3]:
  power=mul(power,source);b=mul(power,H);el=euler(b,{1241}).get(1241,{});correct=scale(mul(source,el),Fr(1,k));wrong=scale(mul(source,el),Fr(1,k+1));assert correct==b and wrong!=b;scaling.append(dict(source_degree=k,density=J.encode(b),correct_homotopy=J.encode(correct),missing_inverse_t_residual=J.encode(plus(b,scale(wrong,-1)))))
 b=mul(atom(1241,(0,)),H);el=euler(b,{1241}).get(1241,{});boundary=D(mul(source,H),0);res=plus(b,scale(mul(source,el),-1),scale(boundary,-1));assert not res
 return dict(signed_Jacobi_fixtures=rows,source_scaling_fixtures=scaling,jet_homotopy=dict(density=J.encode(b),Euler=J.encode(el),boundary=J.encode(boundary),remainder=J.encode(res)),fixtures_do_not_replace_general_proof=True)
def route(role):
 euler=J.euler if role=='native'else literal_euler;D=J.D if role=='native'else f.literal_D
 packet=load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));raw={k:dict(v)for k,v in packet['states'].items()};states={k:{n:J.decode(p)for n,p in v.items()}for k,v in raw.items()}
 S0=J.decode(load(O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_route_density.json.gz'))['original_GF']);ee=euler(S0,set(range(1286)));checks=[];fail=[]
 for n in range(643):
  for kind,actual,wanted in[('F0',scale(ee.get(643+n,{}),(-1)**f.parity(n)),states['F0'][n]),('E0',ee.get(n,{}),states['E0'][n])]:
   delta=plus(actual,scale(wanted,-1));checks.append(dict(kind=kind,field=n,actual_hash=f.phash(actual),expected_hash=f.phash(wanted),equal=not delta))
   if delta:fail.append(dict(kind=kind,field=n,complete_difference=J.encode(delta)))
 integrability=save(role+'_g0_action_Euler',dict(all1286_action_interfaces=checks,complete_nonzero_differences=fail));print('STAGE '+role+' g0_action_interfaces='+str(len(checks))+' differences='+str(len(fail)),flush=True)
 factors=[];groups={};scalar_counts=Counter()
 for name,table in states.items():
  for n,P in table.items():
   src0={w:c for w,c in P.items()if all(i<643 for i,js in w)};G={};g=GRADES[name];isF=name.startswith('F');dim=J.dimension(n)+1 if isF else 4-J.dimension(n);gh=f.ghost(n)+1 if isF else-f.ghost(n);pa=(f.parity(n)+1)%2 if isF else f.parity(n)
   for at,(w,c)in enumerate(sorted(src0.items())):
    p=profile(w);assert p[5]>0 and all(k[0]==g for k,v in c.terms);assert dim-p[6]in[0,1]and sum(f.ghost(i)for i,js in w)==gh and sum(f.parity(i)for i,js in w)%2==pa
    if p[1]:assert p[1]==1 and g==1;scalar_counts[name]+=1
    G.setdefault(p,[]).append(at)
   groups[name,n]=G;factors.append(dict(state=name,field=n,full_sourceful_math_sha256=f.phash(P),source_free_math_sha256=f.phash(src0),source_free_words=len(src0),all_profile_word_indices=[[list(p),ids]for p,ids in sorted(G.items())]))
 ports=[];maxscalar=0
 for label,g,branches in CASES:
  for left,right in branches:
   assert GRADES[left]+GRADES[right]==g
   for n in range(643):
    decisions=[]
    for lp in sorted(groups[left,n]):
     for rp in sorted(groups[right,n]):
      p=tuple(a+b for a,b in zip(lp,rp));b,x,l,a,c,arity,d=p;assert c==a+1 and 5-d in[0,1,2];maxscalar=max(maxscalar,x);assert x<=1
      A,B=envelope(p);selected=5-d in[0,1];assert not selected or A or B;decisions.append([list(lp),list(rp),list(p),selected,A,B])
    ports.append(dict(case=label,left=left,right=right,field=n,all_factor_profile_pair_decisions=decisions))
 assert len(ports)==9645
 missing=set();type_audit=[]
 for b in range(5):
  for x in range(5):
   for l in range(3):
    for a in range(3):
     c=a+1;d=b+x+2*l+2*a+1;n=b+x+l+a+c
     if d>5 or n<2:continue
     for intrinsic in[0,1]:
      jets=5-intrinsic-d
      if jets<0:continue
      A,B=envelope((b,x,l,a,c,n,d+jets));type_audit.append(dict(field_counts=[b,x,l,a,c],bare_dimension=d,ordinary_jets=jets,intrinsic=intrinsic,in_A=A,in_B=B))
      if not(A or B):missing.add((b,x,l,a,c))
 missing=[list(p)for p in sorted(missing)];assert sorted(missing)==sorted([[0,3,0,0,1],[0,4,0,0,1],[1,3,0,0,1],[0,2,1,0,1]])
 support=save(role+'_full_sourcefree_support',dict(all7716_factor_columns=factors,all9645_port_branch_decisions=ports,source_free_scalar_bearing_word_counts=dict(scalar_counts),max_possible_GF_product_scalar_count=maxscalar,complete_count_jet_intrinsic_type_envelope=type_audit,all_type_profiles_outside_old_union=missing,Lambda_x2_C_absent_by_actual_grade_support=True,no_V827_current_specific_cut_used=True));del factors,ports,states,ee;gc.collect()
 cases=[];old=O.parent/'canonical_so10_aCC_operator_reduction_g1_v1';bbc=O.parent/'canonical_so10_BBC_master_applicability_g1_v1'
 for label,g,branches in CASES:
  pa,ja=m.owner_case(old,label);z=load(bbc/('master_scope_'+label+'.json.gz'));pb=J.decode(z['full_BBC_envelope_density']);jb=[J.decode(q)for q in z['full_BBC_envelope_four_currents']];outside=lambda P,dim:{w:c for w,c in P.items()if not envelope(profile(w),dim)[0]};P=plus(pa,outside(pb,5));curr=[plus(a,outside(b,4))for a,b in zip(ja,jb)];div={}
  for mu,q in enumerate(curr):J.add(div,D(q,mu))
  residual=plus(P,scale(J.clean(div),-1));cases.append(dict(case=label,union_density_words=len(P),union_density_hash=f.phash(P),union_current_words=[len(p)for p in curr],union_current_hashes=[f.phash(p)for p in curr],complete_divergence_residual=J.encode(residual),source_owners_reused_not_products_reexpanded=True));print('STAGE '+role+' '+label+' union_divergence_residual='+str(len(residual)),flush=True);del P,curr,div,pa,ja,pb,jb,z;gc.collect()
 witness=save(role+'_union_divergences',dict(all_six_cases=cases,source_free_dimension5_current_dimension4_selectors=True,no_intersection_double_count=True));fixture=save(role+'_signed_fixtures',fixtures(role));return dict(route=role,integrability=integrability,integrability_differences=len(fail),support=support,all9645_ports_covered=True,union_witness=witness,all_six_union_residuals_zero=all(not x['complete_divergence_residual']for x in cases),fixtures=fixture)
def main():
 tick=time.perf_counter();watch=threading.Timer(300,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 assert read(O.parent/'canonical_so10_full_source_field_square_g1_v1/validation_receipt.json')['all3858_field_columns_zero_in_both_routes']
 results=[route(role)for role in['native','replay']];equal=[]
 for p in sorted(O.glob('native_*.json.gz')):
  peer=p.with_name(p.name.replace('native_','replay_',1));assert p.read_bytes()==peer.read_bytes(),p.name;equal.append(p.name)
 assert len(equal)==4
 out=dict(schema='SOURCE_HOMOTOPY_APPLICABILITY_INPUT_AUDIT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',routes=results,all2572_g0_action_interfaces_equal=not any(z['integrability_differences']for z in results),all19290_branch_ports_sourcefree_covered=True,all12_union_divergences_exact=all(z['all_six_union_residuals_zero']for z in results),four_complete_route_artifacts_equal=equal,broader_proper_source_bridge_REQUIRES_written_review=True,no_loop_coefficient_or_restoring_module_constructed=True,no_HB1_C5_activation_E5A5_or_full_master_goal_claim=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
