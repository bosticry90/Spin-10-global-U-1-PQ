from pathlib import Path
from hashlib import sha256
import json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/regulator-vertices-g1-recovery-v1-2026-11-07')
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert not (O/'final_preparation.json').exists()
assert (O/'native_catalog.json.gz').read_bytes()==(O/'replay_catalog.json.gz').read_bytes()
for n in ['FINAL_RECORD.md','final_review.py','run_final.py']:
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V792.md',R/'calculations/canonical_so10_full_jet_source_master_bridge/primary_tables.json.gz']
dump(O/'final_preparation.json',dict(source_sha256={p.relative_to(R).as_posix():digest(p) for p in files},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'final_review.py')]);dump(O/'final_capture.json',cap);dump(C/'final_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
