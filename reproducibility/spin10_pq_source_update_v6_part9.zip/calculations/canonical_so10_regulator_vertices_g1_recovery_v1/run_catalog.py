from pathlib import Path
from hashlib import sha256
import json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/regulator-vertices-g1-recovery-v1-2026-11-07')
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
route=sys.argv[1];assert route in ['native','replay'];assert not (O/(route+'_catalog_capture.json')).exists()
if not (O/'catalog_preparation.json').exists():
 prep=json.loads((O/'root_preparation.json').read_bytes());pairs=[]
 for a in sorted(O.glob('native_*.json.gz')):
  b=O/a.name.replace('native_','replay_',1);assert a.read_bytes()==b.read_bytes();pairs.append(dict(native=a.name,replay=b.name,sha256=digest(a)))
 assert len(pairs)==8
 inputs=dict(prep['input_sha256'])
 for p in O.iterdir():
  if p.is_file() and p.name.startswith(('native_','replay_')):inputs[p.relative_to(R).as_posix()]=digest(p)
 old='calculations/canonical_so10_full_current_inventory_g1_recovery_v1/'
 for name in ['catalogs.py','native_whole_inventory.json.gz','replay_whole_inventory.json.gz']:
  inputs[old+name]=digest(R/(old+name))
 inputs['calculations/canonical_so10_new_physical_returning_inventory_g1_recovery_v1/inventory.py']=digest(R/'calculations/canonical_so10_new_physical_returning_inventory_g1_recovery_v1/inventory.py')
 for n in ['CATALOG_RECORD.md','catalog.py','run_catalog.py']:
  with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
 dump(O/'catalog_preparation.json',dict(base_HEAD=prep['base_HEAD'],input_sha256=inputs,source_sha256={n:digest(O/n) for n in ['CATALOG_RECORD.md','catalog.py','run_catalog.py']},paired_root_math=pairs))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'catalog.py'),route]);dump(O/(route+'_catalog_capture.json'),cap);dump(C/(route+'_catalog_capture.json'),cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
