from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import gc,gzip,importlib.util,json,os,sys,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
ROLE=sys.argv[1] if __name__=='__main__' else 'native'
spec=importlib.util.spec_from_file_location('actual_regulator_root_tools',O.parent/'canonical_so10_physical_current_input_recovery_g1_v1'/('physical_v2.py' if ROLE=='native' else 'physical_v4.py'));v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
w=v.w;J=w.J;A=w.A;one=J.constant(1);ZERO_MON=(0,)*12
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
TARGETS={'vector':(1,1,1,0),'source':(0,1,1,1)}
NAMES=['F0','F1','Fu0_0','Fu0_1','Fu1_0','Fu1_1']
def clean(P):return {key:c for key,c in P.items() if c}
def add(out,P,sign=1):
 for key,c in P.items():out[key]=out.get(key,J.ZERO)+c*sign
def put(out,word,mon,c):
 word,sign=J.canonical(tuple(word))
 if sign and c:
  key=word,tuple(mon);out[key]=out.get(key,J.ZERO)+c*sign
def encode(P):return [[[[n,list(js)] for n,js in word],list(mon),w.enc(c)] for (word,mon),c in sorted(clean(P).items())]
def decode(rows):return {(tuple((n,tuple(js)) for n,js in word),tuple(mon)):A.decode_coeff(c) for word,mon,c in rows}
def mhash(raw):return sha256((json.dumps(raw,sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest()
def save(name,data):
 blob=gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/(ROLE+'_'+name+'.json.gz')).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=128*1024**2,'COMPLETE_PACKET_LIMIT'
 return dict(file=ROLE+'_'+name+'.json.gz',sha256=sha256(blob).hexdigest(),bytes=len(blob))
def classify(word,target):
 counts=[0]*4;copies=[0,0]
 for n,js in word:
  if 1319<=n<1962:copies[0]+=1
  elif 1962<=n<2605:copies[1]+=1
  else:
   if n<180:slot=0
   elif 508<=n<553:slot=1
   elif 553<=n<598:slot=2
   elif 1241<=n<1286:slot=3
   else:return 'FORBIDDEN_MEAN'
   counts[slot]+=1
 if copies!=[1,1]:return 'NOT_ONE_OF_EACH_QUANTUM_HALFEDGE'
 if any(a>b for a,b in zip(counts,target)):return 'EXTERNAL_PROFILE_EXCEEDED'
 return None
def project(P,channel):
 kept=[];rejected=defaultdict(list);out={}
 for at,((word,mon),c) in enumerate(sorted(P.items())):
  reason=classify(word,TARGETS[channel])
  if reason:rejected[reason].append(at)
  else:kept.append(at);out[word,mon]=c
 return out,dict(kept_raw_indices=kept,rejected=[dict(reason=k,raw_indices=ids) for k,ids in sorted(rejected.items())])
def diagonal(P):
 out={}
 for (word,mon),c in P.items():put(out,[(n-1962+1319 if 1962<=n<2605 else n,js) for n,js in word],mon,c)
 return clean(out)
def free_exchange(P):
 free={key:c for key,c in P.items() if all(1319<=n<2605 for n,js in key[0])};out={}
 for (word,mon),c in free.items():
  assert len(word)==2 and all(not js for n,js in word)
  reduced=tuple(mon[i]+mon[4+i] for i in range(4))+(0,)*4+mon[8:]
  put(out,word,reduced,J.times(c,J.constant(F(1,2)*(-1)**sum(mon[4:8]))))
  swapped=[(n+643 if n<1962 else n-643,js) for n,js in word]
  put(out,swapped,reduced,J.times(c,J.constant(F(1,2)*(-1)**sum(mon[:4]))))
 return free,clean(out)
def reference_rows(packet,family):
 q=s.symbols('q0:4',real=True);ll=s.symbols('l0:4',real=True);masses=[s.Symbol('Mref_'+sec+'_squared',positive=True) for sec in ['Phi','Sigma','phi','S']]
 loc={str(z):z for z in [*q,A.xi,A.eta,*masses]};rows=defaultdict(list)
 for i,j,z in packet[family]:
  P=s.Poly(s.sympify(z,locals=loc).subs(dict(zip(q,ll))),*ll,*masses)
  for powers,c in P.terms():rows[i].append((j,tuple(powers),A.co(str(c))))
 return rows
def unit(P,n,matrix):
 out={};wrong={}
 for word,c in P.items():
  qt=[(at,i,js) for at,(i,js) in enumerate(word) if 1319<=i<1962];assert len(qt)==1
  at,i,js=qt[0];kp=tuple(js.count(mu) for mu in range(4));phase=[one,J.I,-one,-J.I][len(js)%4]
  baseword=word[:at]+((i,()),)+word[at+1:]
  for j,lp,coef in matrix.get(n,[]):
   z=J.times(J.times(c,coef),phase);mon=kp+lp
   put(out,baseword+((1962+j,()),),mon,z)
   if J.parity(n) and J.parity(i):put(wrong,baseword+((1962+j,()),),mon,z*-2)
 return clean(out),clean(wrong)
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 prep=read(O/'root_preparation.json')
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 for n,h in prep['source_sha256'].items():assert digest(O/n)==h,n
 assert read(O/'fixture_result.json')['execution_state']=='COMPLETED'
 peer=str((O/('replay_' if ROLE=='native' else 'native_')).resolve())
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):assert not str(Path(os.fsdecode(args[0])).resolve()).startswith(peer),'PEER_REGULATOR_ROOT_READ_DENIED'
 sys.addaudithook(guard)
 full=O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1';old=O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'
 if ROLE=='native':
  data=load(full/'native_raw_T1_factors.json.gz');factors={name:data[name] for name in NAMES};del data;gc.collect()
 else:
  common=load(old/'replay_GF_common.json.gz');states=load(full/'replay_new_states.json.gz');maps={'F0':common['F0'],'F1':states['F1']}
  for pr in [0,1]:maps['Fu0_'+str(pr)]=common['probes'][pr]['source_first_Fu'];maps['Fu1_'+str(pr)]=states['Fu1_'+str(pr)]
  factors={}
  for name in NAMES:
   rows=[]
   for n,raw in maps[name]:
    P=J.decode(raw);out={};jets=sorted({(i,js) for word in P for i,js in word if i<643})
    for i,js in jets:
     part=w.scale(J.leftjet(P,(i,js)),J.constant((-1)**(J.parity(i)*J.parity(n))))
     for word,c in part.items():J.put(out,word+((1319+i,js),),c)
    rows.append([n,J.encode(J.clean(out))])
   factors[name]=rows
  del common,states,maps;gc.collect()
 assert all([n for n,p in factors[name]]==list(range(643)) for name in NAMES)
 tf=save('raw_T1_F',factors)
 packet=load(O.parent/'canonical_so10_regulator_free_inverse_g1_recovery_v1'/(ROLE+'_inverse.json.gz'))
 matrices={'preference':reference_rows(packet,'Preference'),'reference':reference_rows(packet,'reference_defect')}
 operands={family:{n:mhash([[j,list(mon),w.enc(c)] for j,mon,c in row]) for n,row in matrix.items()} for family,matrix in matrices.items()}
 del packet;gc.collect();assemblies=[];unit_artifacts=[]
 for name in NAMES:
  g=int(name in ['F1','Fu1_0','Fu1_1']);u=int(name.startswith('Fu'));aggregate={family:{} for family in matrices};wrong={family:{} for family in matrices};units=[];zeros=[];first_reference={}
  for n,raw in factors[name]:
   if not raw:zeros.append([n,'ZERO_FULL_T1_F']);continue
   P=J.decode(raw);row=dict(field=n,full_T1_F_sha256=mhash(raw),full_T1_F_words=len(raw),families={})
   for family,matrix in matrices.items():
    product,bad=unit(P,n,matrix);add(aggregate[family],product);add(wrong[family],bad)
    row['families'][family]=dict(matrix_row_sha256=operands[family].get(n,mhash([])),raw_product=encode(product))
    if family=='reference':
     for channel in TARGETS:
      chosen,_=project(product,channel);identified=diagonal(chosen)
      if identified and channel not in first_reference:first_reference[channel]=dict(omitted_field=n,identified_difference=encode({k:-c for k,c in identified.items()}))
   units.append(row)
  assert len(units)+len(zeros)==643 and len({z['field'] for z in units}|{n for n,label in zeros})==643
  unit_artifacts.append(save('units_'+name,dict(state=name,all643_fields=True,units=units,zero_units=zeros)))
  for family,P in aggregate.items():
   P=clean(P);bad=clean(wrong[family]);assert all(key[0]==g for c in P.values() for key,z in c.terms)
   free,normal=free_exchange(P);projections={}
   for channel in TARGETS:
    selected,journal=project(P,channel);selected_bad,_=project(bad,channel);reduced=dict(selected);localref=None
    if not normal:
     for key in free:reduced.pop(key,None)
    if family=='reference':
     localref=diagonal(selected)
     assert all(not any(mon[:8]) for word,mon in selected),'REFERENCE_ROOT_HAS_UNEXPECTED_MOMENTUM'
     if not localref:reduced={}
    projections[channel]=dict(**journal,selected=encode(selected),integrated=encode(reduced),reference_diagonal=encode(localref) if localref is not None else None,wrong_F_coefficient_normal_order_difference=encode(selected_bad),omit_first_reference_unit_control=first_reference.get(channel) if family=='reference' else None)
   assemblies.append(dict(state=name,family=family,g=g,u=u,raw_root=encode(P),raw_monomials=len(P),free_proof=dict(raw_free=encode(free),graded_exchange_at_l_minus_k=encode(normal),whole_free_zero=not bool(normal),profiles_even_and_common_on_matching_gauge_ghost_blocks=True),projections=projections))
  print('STAGE '+ROLE+' complete all643 actual regulator root units '+name,flush=True)
  del aggregate,wrong,units,zeros;gc.collect()
 roots=save('root_assemblies',dict(assemblies=assemblies,quantum_F_offset=1319,quantum_R_offset=1962,momentum_monomial_order=['k0','k1','k2','k3','l0','l1','l2','l3','Mref_Phi_squared','Mref_Sigma_squared','Mref_phi_squared','Mref_S_squared'],source_first=True,profile_multipliers=dict(preference_heat='E_l**-1-1',preference_IR='(f_l**-1-1)/E_l',reference='1'),two_halfedge_modes_never_identified_before_qualified_proof=True))
 summary=[dict(state=z['state'],family=z['family'],raw_monomials=z['raw_monomials'],free_monomials=len(z['free_proof']['raw_free']),free_exchange_monomials=len(z['free_proof']['graded_exchange_at_l_minus_k']),channels={ch:dict(selected=len(p['selected']),integrated=len(p['integrated']),wrong_F_normal_order=len(p['wrong_F_coefficient_normal_order_difference']),reference_diagonal=len(p['reference_diagonal']) if p['reference_diagonal'] is not None else None) for ch,p in z['projections'].items()}) for z in assemblies]
 result=dict(schema='ACTUAL_POLARIZED_REGULATOR_ROOTS_G1_RECOVERY_V1',route=ROLE,full_raw_T1_F=tf,units=unit_artifacts,roots=roots,summary=summary,elapsed_after_imports=time.perf_counter()-tick,scientific_acceptance='NOT_PERFORMED',loop_amplitude_or_E5_claim=False)
 with (O/(ROLE+'_root_result.json')).open('x',encoding='utf-8',newline='\n') as h:json.dump(result,h,sort_keys=True);h.write('\n')
 print('RESULT '+json.dumps({k:result[k] for k in ['route','summary','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
