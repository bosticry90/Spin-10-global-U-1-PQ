from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/regulator-vertices-g1-recovery-v1-2026-11-07')
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert not (O/'fixture_preparation.json').exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='1da9640c96673ec4c3d1b7aaf0b1218fb020b024'
names=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/LOCAL_STORAGE_LAYOUT_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V791.md','calculations/canonical_so10_gaussian_current_reduction_g1_v1/fixture.py','calculations/canonical_so10_gaussian_current_reduction_g1_v1/fixture_result.json','calculations/canonical_so10_gaussian_current_reduction_g1_v1/validation_receipt.json','calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1/validation_receipt.json']
for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n]),n
for n in ['RECORD.md','graded_fixture.py','run_fixture.py']:
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'fixture_preparation.json',dict(base_HEAD=head,input_sha256={n:digest(R/n) for n in names},source_sha256={n:digest(O/n) for n in ['RECORD.md','graded_fixture.py','run_fixture.py']},scientific_acceptance='NOT_PERFORMED'))
C.mkdir(parents=True,exist_ok=False)
with (C/'old_git_tree.txt').open('xb') as h:h.write(subprocess.check_output(['git','ls-tree','-r','HEAD']))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'graded_fixture.py')]);dump(O/'fixture_capture.json',cap);dump(C/'fixture_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
