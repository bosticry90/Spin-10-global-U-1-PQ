from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/regulator-vertices-g1-recovery-v1-2026-11-07')
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
route=sys.argv[1];assert route in ['native','replay'];assert not (O/(route+'_root_capture.json')).exists()
if not (O/'root_preparation.json').exists():
 prep=json.loads((O/'fixture_preparation.json').read_bytes());assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==prep['base_HEAD']
 f=json.loads((O/'fixture_result.json').read_bytes());assert f['execution_state']=='COMPLETED' and all(f['wrong_whole_mixed_gu_sensitive'].values())
 names=list(prep['input_sha256'])+['calculations/canonical_so10_absolute_marked_quantum_g0_recovery_v1/quantum.py','calculations/canonical_so10_original_Ja_ghost_bubble/algebra.py','calculations/canonical_so10_full_jet_source_master_bridge/jets.py','calculations/canonical_so10_intrinsic_full_source_descent/coefficient_ring.py','calculations/canonical_so10_physical_current_input_recovery_g1_v1/physical_v2.py','calculations/canonical_so10_physical_current_input_recovery_g1_v1/physical_v4.py','calculations/canonical_so10_full_current_inventory_g1_recovery_v1/validation_receipt.json','calculations/canonical_so10_full_current_inventory_g1_recovery_v1/native_raw_T1_factors.json.gz']
 for role in ['native','replay']:
  names += ['calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1/'+role+'_inverse.json.gz','calculations/canonical_so10_full_current_inventory_g1_recovery_v1/'+role+'_new_states.json.gz','calculations/canonical_so10_new_physical_returning_inventory_g1_recovery_v1/'+role+'_GF_common.json.gz']
 for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n]),n
 inputs={n:digest(R/n) for n in sorted(set(names))}
 for n in ['fixture_preparation.json','fixture_result.json','fixture_capture.json']:inputs[(O/n).relative_to(R).as_posix()]=digest(O/n)
 for n in ['roots.py','run_roots.py']:
  with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
 dump(O/'root_preparation.json',dict(base_HEAD=prep['base_HEAD'],input_sha256=inputs,source_sha256={n:digest(O/n) for n in ['RECORD.md','roots.py','run_roots.py']},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'roots.py'),route]);dump(O/(route+'_root_capture.json'),cap);dump(C/(route+'_root_capture.json'),cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
