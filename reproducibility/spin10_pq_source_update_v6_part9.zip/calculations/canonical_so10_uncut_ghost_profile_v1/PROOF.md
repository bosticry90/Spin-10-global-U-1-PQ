# Testing the all-edge profile at the uncut connected ghost transfer

Use the V880 unprobed parent. Test the direct uncut extension with
χ_ε(P_E)² on every free edge, χ_ε=1−exp(−P_E/ε²). The older flat UV
edge clock is exp(−2t P_E). The V847 selected proper applicability
does not transfer a forced-zero connected pullback. Compare κ values
after the common UV conversion and regulated forest subtraction of
COS1/V871. Keep all other inputs fixed. The proper family F_R includes
the heat term and its finite local conversion. The causal b terms
pair in the V867 dictionary.

At A=J_BV=0, ordinary j appears only linearly. The constant Λx and
scalar mass chains of V880 do not alter the free ghost legs. V275 gives
the complete intrinsic g⁴ ξ² zero-jet aC pole. Its 12 diagonal is 75/2
in pole units, entirely from Sigma with DMM/FMY/YY contributions 0,
12, 51/2. Adding a derivative at the same explicit ξ and field degree
exceeds dimension four. Constant scalar mass corrections lower the UV
order. Only their degree-zero component is needed. The V880 converted
κ difference is a local critical-symbol multiple, giving A_κ a₁₂C₁₂,
where A_κ is proportional to (κ₂−κ₁)g⁴ ξ²(75/2) with a fixed nonzero
common factor. It is the difference of the total corrected coefficient.

At second order in j, the connected W₁ has a two-port proper term
sewn to the two linear trees and a one-port proper term sewn to the
quadratic tree. Local conversion terms obey the same census. A constant
has no j derivatives. Translation invariance places a delta at zero
bridge momentum on each one-port. Every possible first free edge with
the all-edge cutoff vanishes there at positive ε. Indeed χ² vanishes to
fourth order in momentum, the ordinary massless pole order is at most
two, and the massive reference scalar inverse is bounded. The smooth
regulated edge times the delta is zero. This covers every one-port
feedback, regardless of field or the number of subsequent edges.

The free physical odd action is a P C, with K_(C,a)=[[0,−P],[P,0]].
The source-first left stationary equations give a=−G j_C and C=+G j_a
for G=1/P. Consequently the ordered j_C(−p)j_a(p) coefficient of the
local difference is −A_κ G_ε², up to the common Wick convention. Choose
independent odd generators with even Schwartz tests whose product is
exp(−p_E²/ν²), ν>0. After the UV limit the pairing is

    16π² I_ε = ∫₀∞ exp(−s/ν²)(1−exp(−s/ε²))⁴ ds/s
             = −Σ_j (−1)^j binom(4,j) log(ν⁻²+j ε⁻²)
             = log(ν²/ε²)+4 log 3−8 log 2+O(ε²/ν²).

Subtract one exponential under the integral, using sum_j c_j=0, to
obtain the exact logarithm difference. This gives the same log as TCI1.
The κ difference has no unknown nonlocal proper term. If both raw
limits existed, their difference would exist on these tests. The
nonzero logarithm contradicts that implication, excluding realization
of the full symbolic family without differentiating through a limit.
An isolated κ, a new contact at p=0, and a direct Feynman boundary are
separate questions.

## Zero-transfer constants with the massive root retained

The longitudinal DMM numerator in V274 is p^μη_μν p^ν=P. In FMY the
F vertex supplies the contracted momentum, p·n=P, and YY has one
ordered ghost inverse. At zero transfer and scalar mass-difference
degree zero every word in V275 thus replaces its UV factor P⁻² by
1/[P(P−M_s)], with the same signs and weights. The Euclidean radial
integrand is 1/[q²(q²+M_s)], with D dependence only in the sphere factor.
Compare after conversion with the different true UV clocks retained.

In units of 1/(16π²), the converted factor is
L(M)=log(μ²/M)+κ−γ_E−2 log 2. The hard radial integral is
log((R²+M)/M). Its finite part is log(μ²/M) and the relative sphere
dimension jet is −(log 4π+1−γ_E)/2. Insert the V853 residue offset.
Independently, a massive–massless Feynman parameter gives
Γ(e)(4π)^e(μ²/M)^e/(1−e) at D=4−2e. Its finite part with the same
offset yields L(M). In V275 units the proper color-12 constant is
(75/2)L(M_Sigma) and the color-17 constant is
500 L(M_Phi)+(15/4)L(M_Sigma). For distinct reference masses these
two converted constants cannot both vanish by varying κ alone. This
test does not imply uniformity in p and the inner and outer cutoffs.

For the kinetic tadpole use V788's +g∂x·Bρx and the actual mixing
+g ξ Λ E x, E_a=ρ_a v. The opposite Fourier signs of its two Hessians
pair with G_BΛ=ip/P and G_ΛB=−ipᵀ/P. In each order of the two
vertices the two starting field types give +2g² ξ v_sᵀ C_s x_s times
the massive inverse. The raw proper log weight for each order is
−i/4. The massive radial tadpole obeys
1/(q²+M)=1/q²−M/[q²(q²+M)]. The massless one-edge converted term is
zero. The Wick and trace signs give the kinetic tadpole
+2M_s C_s v_s L(M_s) in the two-port units, with its own g² ξ.
A retained massive root gives −K_x(0)⁻¹=+1/M_s. The actual
g² ξ x a Y C cubic then feeds back 2C_s Y[v_s,a,c] L(M_s).

Direct scalar algebra gives C_Phi=10 and C_Sigma=25/2 on the active
blocks. On every ordered color cell, Y_s[v_s]=−E_s E_sᵀ and the V275
sum Z_s=2C_s E_s E_sᵀ. S and phi supports are zero. Thus a retained
massive bridge supplies the opposite selected constant, including its
κ dependence. This comparison is between converted contributions at
zero transfer. A uniform regulator estimate, full alternative forest,
and the common Lorentzian/QAP construction remain open.
