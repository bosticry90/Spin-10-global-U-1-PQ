# V882 pre-execution contract

Test whether the old flat IR profile on every free edge extends to the
direct uncut absolute connected functional. Set A and all BV sources to
zero. Use two ordered independent ordinary odd test sources in physical
color 12. Work at one loop, g⁴ ξ², zero scalar mass-difference degree,
with positive inherited reference masses. Compare two distinct values of
symbolic κ under the same UV conversion. Adopt no κ, mass, vacuum or profile.

Require both V275 exact routes, source-first signs, the translation-
invariant root census and an independent exact Gaussian pairing. Include
all potential one-port feedback. For a separate massive-root control, test
the actual orbit, cubic and converted radial constant in both routes.
This control does not decide uniform regulated convergence.

Bind AGENTS, state, V881, V880, V871, V867, V847, FCR1, V274/V275,
TCI1 and the original scalar representation inputs. Freeze contract,
proof and worker before launch. Require exact replay, separate E4 and
historical custody classification and exact staged bytes. Limits: 120 s
native and 180 s final, E4 ≤120 s, 8 GiB sampled worker private bytes,
350 MiB minimum available commit, 8 MiB per artifact, 32 MiB packet.
Preserve failed and incomplete checks. Ceiling: disposition of the raw
all-edge symbolic family and the selected massive-root control.
