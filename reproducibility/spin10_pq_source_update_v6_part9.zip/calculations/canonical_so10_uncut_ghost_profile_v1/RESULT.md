# V882 — A raw profile exclusion and a massive-root control

The older flat profile on every free edge cannot realize the entire
symbolic κ family of the direct uncut absolute connected functional.
Comparing two κ values isolates the measured V275 local ghost residue
75/2 for color 12. Its two source branches share one soft momentum.
Their Gaussian pairing grows as log(ν²/ε²)/(16π²). The cutoff makes
every possible one-port root zero at forced transfer, so no tadpole
feedback can cancel the difference in this prescription. The result
uses the full corrected proper coefficient and no fitted subtraction.

An exact separate control retains the massive root at zero. The two
routes compare 8,100 ordered sector/color cells from the actual orbit,
kinetic and ghost inputs. The kinetic tadpole then supplies the opposite
converted ghost constant through the cubic density, with the same
radial factor. In the all-edge test the separately converted color-12
and color-17 proper constants cannot both vanish for distinct reference
masses under one κ. Uniformity in the outer and inner IR regulators
has not been proved for the finite amplitudes. This packet excludes a
specific raw symbolic-family realization and locates a mechanism for
an alternative. It leaves the isolated-κ limits, common connected
Feynman domain and complete Ward/QAP applicability open.

The comparisons share the frozen action, reference conventions,
symbolic software and AI authorship. V275 pole integrations were
authenticated and reused. The new calculation checks the finite radial
reduction and root algebra. The separate final replay and E4 receipt
are required. No κ or physical parameter is adopted.
