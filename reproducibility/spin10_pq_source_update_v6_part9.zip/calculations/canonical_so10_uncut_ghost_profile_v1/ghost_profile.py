"""Exact source order, critical pairing and actual scalar feedback controls."""

from collections import defaultdict
from functools import lru_cache
import sys

import sympy as sp

from execute import PK, ROOT, read, run_worker

sys.path.insert(0, str(PK))
from source_convention_control import Exterior


CALC = ROOT / "calculations"
SECTORS = {"Phi": (0, 54), "Sigma": (54, 306), "phi": (306, 326), "S": (326, 328)}


@lru_cache(None)
def scalar(cell):
    return sp.sympify(cell)


def add(out, key, value):
    out[key] += value


def apply(rows, vector):
    out = defaultdict(lambda: sp.S.Zero)
    for i, j, value in rows:
        if j in vector:
            add(out, i, scalar(value) * vector[j])
    return {i: value for i, value in out.items() if value != 0}


def actual_algebra(role):
    route = "primary" if role == "native" else "replay"
    pole = read(CALC / "canonical_so10_ghost_mass_g4_pole" / f"{route}_v2_result.json")
    physical = read(PK / f"frozen_a10_physical_reconciliation/full_{route}.json")
    v = {i: scalar(value) for i, _, value in physical["vacuum"]["VEV"]["entries"]}
    result = {}
    for sector, (start, end) in SECTORS.items():
        part = {i - start: value for i, value in v.items() if start <= i < end}
        matrices = physical["representation_matrices"][sector]
        assert len(matrices) == 45 and all(m["shape"] == [end - start] * 2 for m in matrices)
        acted = defaultdict(lambda: sp.S.Zero)
        for matrix in matrices:
            rows = matrix["entries"]
            r_v = apply(rows, part)
            for i, value in apply(rows, r_v).items():
                add(acted, i, -value)
        casimir = {"Phi": sp.Integer(10), "Sigma": sp.Rational(25, 2), "phi": 0, "S": 0}[sector]
        assert all(sp.expand(acted[i] - casimir * part.get(i, 0)) == 0 for i in range(end - start))

        by_scalar = defaultdict(list)
        for a, x, value in pole["physical_E"]:
            if start <= x < end:
                by_scalar[x].append((a, scalar(value)))
        gram = defaultdict(lambda: sp.S.Zero)
        for rows in by_scalar.values():
            for a, left in rows:
                for c, right in rows:
                    add(gram, (a, c), left * right)
        ghost = defaultdict(lambda: sp.S.Zero)
        for x, a, c, value in pole["physical_Y_aC_density"]:
            if x - start in part:
                add(ghost, (a, c), part[x - start] * scalar(value))
        families = pole["physical_scalar_sector_family_poles"][sector]
        tables = [{(a, c): scalar(value) for a, c, value in families[label]}
                  for label in ("DMM", "FMY", "YY")]
        for a in range(45):
            for c in range(45):
                key = (a, c)
                measured = sum(table.get(key, 0) for table in tables)
                assert sp.expand(ghost[key] + gram[key]) == 0, (sector, key)
                assert sp.expand(measured - 2 * casimir * gram[key]) == 0, (sector, key)
        result[sector] = {"casimir_on_active_vector": str(casimir),
                          "nonzero_gram_cells": sum(value != 0 for value in gram.values()),
                          "all_compared_cells": 45**2,
                          "row12_families": [str(table.get((12, 12), 0)) for table in tables],
                          "row17_families": [str(table.get((17, 17), 0)) for table in tables]}
    assert result["Sigma"]["row12_families"] == ["0", "12", "51/2"]
    assert result["Phi"]["row17_families"] == ["115", "85", "300"]
    assert result["Sigma"]["row17_families"] == ["63/100", "57/100", "51/20"]
    assert [result[k]["nonzero_gram_cells"] for k in SECTORS] == [24, 57, 0, 0]
    return result


def profile_and_source():
    e = Exterior()
    a, C, jC, ja = [e.variable(k, 1) for k in ("a", "C", "jC", "ja")]
    P, A = sp.symbols("P A", nonzero=True)
    action = e.add(e.scale(e.mul(a, C), P), e.mul(jC, C), e.mul(ja, a))
    assert e.partial(action, "C") == e.add(e.scale(a, -P), e.scale(jC, -1))
    assert e.partial(action, "a") == e.add(e.scale(C, P), e.scale(ja, -1))
    response = e.scale(e.mul(e.scale(jC, -1 / P), e.scale(ja, 1 / P)), A)
    assert response == e.scale(e.mul(jC, ja), -A / P**2)

    q, eps, M, h = sp.symbols("q eps M h", positive=True)
    profile = (1 - sp.exp(-q**2 / eps**2))**2
    assert all(sp.limit(profile * edge, q, 0) == 0
               for edge in (1 / q**2, 1 / q, 1 / (q**2 + M)))
    assert (1 / (q**2 + M)).subs(q, 0) == 1 / M
    coeffs = [(-1)**j * sp.binomial(4, j) for j in range(5)]
    assert sum(coeffs) == 0
    pairing = -sum(c * sp.log(h + j) for j, c in enumerate(coeffs))
    finite = sp.simplify(sp.limit(pairing + sp.log(h), h, 0, dir="+"))
    assert sp.simplify(finite - (4 * sp.log(3) - 8 * sp.log(2))) == 0
    return {"ghost_ordered_sign": -1, "all_edge_root_values": [0, 0, 0],
            "massive_root_if_retained": "1/M", "gaussian_log_factor_before_16pi_squared": 1,
            "gaussian_finite_part": "4*log(3)-8*log(2)"}


def radial_controls():
    M, mu2, e = sp.symbols("M mu2 e", positive=True)
    kappa = sp.Symbol("kappa", real=True)
    s, L = sp.symbols("s L", positive=True)
    bubble = sp.integrate(1 / (s + M), (s, 0, L))
    tadpole = sp.integrate(s / (s + M), (s, 0, L))
    assert sp.simplify(tadpole - (L - M * bubble)) == 0
    hard = sp.limit(bubble - sp.log(L / mu2), L, sp.oo)
    d_sphere = -(sp.log(4 * sp.pi) + 1 - sp.EulerGamma) / 2
    offset = kappa - 1 - sp.log(16 * sp.pi)
    via_hard = hard - 2 * d_sphere + offset
    via_parameter = sp.limit(sp.gamma(e) * (4 * sp.pi * mu2 / M)**e / (1 - e) - 1 / e, e, 0) + offset
    finite = sp.log(mu2 / M) + kappa - sp.EulerGamma - 2 * sp.log(2)
    assert sp.simplify(via_hard - finite) == sp.simplify(via_parameter - finite) == 0
    M_phi, M_sigma = sp.symbols("M_Phi M_Sigma", positive=True)
    proper12 = sp.Rational(75, 2) * finite.subs(M, M_sigma)
    proper17 = 500 * finite.subs(M, M_phi) + sp.Rational(15, 4) * finite.subs(M, M_sigma)
    root = sp.solve(proper12, kappa)[0]
    assert sp.simplify(proper17.subs(kappa, root) - 500 * sp.log(M_sigma / M_phi)) == 0
    return {"common_converted_radial": "log(mu2/M)+kappa-EulerGamma-2*log(2)",
            "row12_proper_normalization_slope": "75/2", "row12_massive_feedback_slope": "-75/2",
            "row17_when_row12_constant_vanishes": "500*log(M_Sigma/M_Phi)"}


def checks(role):
    return {"actual_scalar_algebra": actual_algebra(role), "source_profile": profile_and_source(),
            "radial": radial_controls()}


if __name__ == "__main__":
    run_worker(checks, sys.argv[1])
