from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/same-parent-slavnov-g1-recovery-v1-2026-11-07')
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert not (O/'pairing_preparation_v3.json').exists()
bindings=json.loads((O/'pairing_preparation.json').read_bytes())['sha256']
for n,h in bindings.items():assert digest(R/n)==h,n
extra=['calculations/canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz','calculations/canonical_so10_full_jet_source_master_bridge/native.py','calculations/canonical_so10_intrinsic_full_source_descent/RESULT.md']
for n in extra:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R);bindings[n]=digest(R/n)
for n in ['PAIRING_CORRECTION_V3.md','pairing_v3.py','run_pairing_v3.py']:
 if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
 bindings[(O/n).relative_to(R).as_posix()]=digest(O/n)
dump(O/'pairing_preparation_v3.json',dict(base_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),sha256=bindings,scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'pairing_v3.py')]);dump(O/'pairing_capture_v3.json',cap);dump(C/'pairing_capture_v3.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
