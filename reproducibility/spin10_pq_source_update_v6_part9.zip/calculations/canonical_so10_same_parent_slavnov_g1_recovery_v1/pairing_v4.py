from pathlib import Path
from hashlib import sha256
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('same_parent_pairing_tools',O.parent/'canonical_so10_physical_current_input_recovery_g1_v1/physical_v2.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
J=v.J;w=v.w
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def mh(p):return sha256((json.dumps(J.encode(p),sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest()
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in json.loads((O/'pairing_preparation_v4.json').read_bytes())['sha256'].items():assert sha256((R/n).read_bytes()).hexdigest()==h,n
 results=[];residuals=[];completed=[];actions=load(O.parent/'canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz')
 for route,role in [('native','primary'),('replay','replay')]:
  src=dict(load(O.parent/'canonical_so10_full_jet_source_master_bridge'/(role+'_tables.json.gz'))['operation'])
  common=load(O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(route+'_GF_common.json.gz'))
  states=load(O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1'/(route+'_new_states.json.gz'))
  table=[];unsigned_odd_source=0;route_completed=[]
  for grade in [0,1]:
   fs=dict(common['F0'] if grade==0 else states['F1']);es=dict(common['E0'] if grade==0 else states['E1']);density=J.decode(actions[0 if route=='native' else 1]['original'][grade]['density']);gf={word:cc for word,cc in density.items() if all(nn<643 for nn,js in word)};grad=J.euler(gf,set(range(643)));sourcepart={word:cc for word,cc in density.items() if any(nn>=643 for nn,js in word)};hamiltonian={}
   for fi in range(643):
    flow=v.grade(J.decode(src.get(fi,[])),grade)
    for word,cc in flow.items():J.put(hamiltonian,((643+fi,()),)+word,cc*((-1)**J.parity(fi)))
   hamiltonian=J.clean(hamiltonian);assert hamiltonian==sourcepart,('FULL_SOURCE_HAMILTONIAN_DENSITY',route,grade,len(hamiltonian),len(sourcepart));hom=J.euler(hamiltonian,set(range(643)));newmaps=[]
   for n in range(643):
    f=J.decode(fs[n]);e=J.decode(es[n]);qf=v.grade(J.decode(src.get(n,[])),grade);qj=v.grade(J.decode(src.get(643+n,[])),grade)
    oldqj=qj;qj=w.scale(w.plus(grad.get(n,{}),hom.get(n,{})),J.constant((-1)**J.parity(n)));addition=w.plus(qj,w.scale(oldqj,J.constant(-1)));expectj=w.scale(e,J.constant((-1)**J.parity(n)));newmaps.append([n,J.encode(qf),J.encode(qj)] )
    # F maps are already the actual source-first action field maps.
    rf=w.plus(qf,w.scale(f,J.constant(-1)));rj=w.plus(qj,w.scale(expectj,J.constant(-1)))
    if rf or rj:residuals.append(dict(route=route,grade=grade,field=n,field_residual=J.encode(rf),source_residual=J.encode(rj)))
    if J.parity(n) and qj!=e:unsigned_odd_source+=1
    table.append(dict(grade=grade,field=n,parity=J.parity(n),field_terms=len(qf),source_terms=len(qj),actual_field_math_sha256=mh(qf),expected_field_math_sha256=mh(f),actual_source_math_sha256=mh(qj),expected_source_math_sha256=mh(expectj),field_equal=not rf,source_equal=not rj,old_source_math_sha256=mh(oldqj),old_to_complete_source_difference_math_sha256=mh(addition),old_to_complete_source_difference_terms=len(addition)))
   route_completed.append(dict(grade=grade,all643_field_and_source_maps=newmaps))
  completed.append(dict(route=route,grades=route_completed))
  results.append(dict(route=route,ports=table,unsigned_source_sign_changed_odd_ports=unsigned_odd_source))
 data=dict(schema='ACTUAL_FULL_SOURCE_PAIRING_AUDIT_V4',all_maps=results,completed_GF_source_operations=completed,residuals=residuals,physical_Euler_values_not_computed_or_zeroed=True)
 blob=gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/'pairing_audit_v4.json.gz').open('xb') as h:h.write(blob)
 assert not residuals,('ACTUAL_PHYSICAL_CHART_PAIRING_MISMATCH',len(residuals),residuals[:1])
 assert all(r['unsigned_source_sign_changed_odd_ports']>0 for r in results)
 out=dict(schema='ACTUAL_FULL_SOURCE_PAIRING_RESULT_V4',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',routes=[r['route'] for r in results],exact_port_grade_comparisons=2*2*643*2,all_field_and_source_maps_equal=True,GF_source_completion_only_physical_Euler_companions_separate=True,source_pairing='QJ_z=(-1)^p_z*Euler_left_z_S',field_pairing='F_z=(-1)^p_z*Euler_left_Jz_S',unsigned_source_sign_changed_odd_ports={r['route']:r['unsigned_source_sign_changed_odd_ports'] for r in results},audit_sha256=sha256(blob).hexdigest(),elapsed_after_imports=time.perf_counter()-tick,not_QGamma_amplitude=True)
 with (O/'pairing_result_v4.json').open('x',encoding='utf-8',newline='\n') as h:json.dump(out,h,sort_keys=True);h.write('\n')
 print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
