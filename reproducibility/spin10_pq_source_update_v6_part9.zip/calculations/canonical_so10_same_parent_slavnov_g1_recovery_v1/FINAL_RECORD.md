# Source operand final review

Final180s,8GiBsampled/350MiBfloor/32MiBcompletepacket. Freeze all current
sources/definition/result/handoffV800. Authenticate V1,V3,V4preparations,
allsourcecopies and originalinput bytes. Check completeV4newmaps against
the actual V788/V789 field/Euler maps,5144equalityslots including0;
completeoperations equal across inheritedroutes, oldmaps not rewritten.
Verify wrongunsignedoddsource180 perroute, GFscope only/no physicalEuler
zeroing. V1/V3 full residualtables/captures remainFAILED; V2 exactsyntax
preparation failure is a returnedtoolobservation, no V2worker/preparation/
result manufactured. Distinguish2failedworkers+1failedpreparation.
V4 sourceHamiltoniandensityassertion frozen/executedbeforederivatives;
no quantum target ornormalization operand. Failedworker exactafterimport
times notserialized; disclose rather than infer frommemorysamples.
E4once/no-freshDcontext0,0,0,0,0,2/sevenunresolvedNOTPASS fullcapture
savedbeforeassertions. Preserveoldtree/state, stagedrawmode/blobchecks
beforelocalcommit. NextfreezeproperQGamma/source/hat/meancomparison;
no amplitude orscientificacceptance/E5/A5 claimfromthisoperandcompletion.
