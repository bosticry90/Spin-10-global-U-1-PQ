# Restore omitted GF source Euler ports, without changing pairing signs

V1 FAILED: all field maps and all Lambda/antighost source ports agree,
but1552 source comparisons differ (bothroutes: atg0 B180/C45;atg1
B180/scalar326/C45). Exact V1audit/source/preparation/capture retained.
No new convention is inferred from this failure.

The actual FJB native.py lines76-94 explicitly differentiates GF only
at Lambda/antighost ports, then adds those gradients to source flows.
This sufficed for its generator G, which uses only those source ports.
The remaining source maps are homogeneous cotangent terms. Thus V1's
claim that FJBoperation already supplied fullGF QJ was false. V1 is not
PASS, and its source maps are not altered or relabeled complete.

V2 constructs the missing GF source contributions from the qualified
MWP fullsourceful GFaction at bothgrades0/1, removes BVsource terms
only to isolate the actual GFdensity, then LEFT Euler differentiates it
at all643ports. Add (-1)^p GFgradient ONLY at ports not already supplied
byFJB (allports outsideLambda/antighost), retaining every fullsource
homogeneous term. Compare the resulting COMPLETE GF/source operation
to the independently owned V788/V789 fullsourcefieldEulers at ALL643
ports, same5144field/source/grade/route equality requirements and wrong
unsigned odd-source control. No sign, input or acceptance requirement
changes. Save old/new map hashes and complete new field/source maps.

This is a justified new omitted-port derivation, not a repeat of the
failed incomplete-input test. Actual sourceLEFT pairing is separately
stated in qualified ISD1 RESULT, consistent with the tested proposal.
The actual physical508 Euler companions remain separate retained input
programs; a GFcompletion is not called a full physical QJ evaluation.
No new QGamma, loop coefficient, normalization or contact target operand.

NewV2 worker120s afterimports, same8GiBsampled/350MiBfloor/32MiBcomplete
pairingpacket. Freeze originalaction bytes, FJB builder source, ISD1
convention source and V2sources beforeexecution. OriginalV1immutable.
Failure/incomplete remainsnotPASS. Final scientificstatusunchanged.
