# Verified source convention and the next same-parent equation

The new computation establishes the complete source operation for
S=Sigma_GF+Sigma_source, throughg1/intrinsic01 atA0. It is not a fresh
evaluation of all physical Euler companions or of Gamma1.

In the actual Euclidean physical chart, with LEFT Euler derivatives,

    Sigma_source=sum_z (-1)^p_z J_z F_z,
    F_z=(-1)^p_z Euler_Jz Sigma,
    QJ_z=(-1)^p_z Euler_z Sigma.

V4 constructs Sigma_source from all643 actual transported FJB field
maps and checks EXACT density equality with the source part of MWP,
bothg0/g1 and both inherited transport routes, before differentiating.
It derives GF and homogeneous source gradients separately and adds them.
The completed maps equal the full V788/V789 action Eulers at ALL643
ports, both grades, including every zero. There are5144 field/source
comparisons across the two routes. Replacing the odd-source sign changes
180 port/grade maps per route. The physical action adds its retained
(-1)^p Euler_z S_phys source companion in the same pairing; it has not
been setzero or densely evaluated here.

The earlier FJB operation is not an all-source ledger. Its builder adds
GFgradients only to Ja/JLambda, as needed by its own G. It also omits
the newly transported B/scalar field flows' complete JB/Jx/JC cotangent
partners. Its own qG result uses only Ja/JLambda and is unchanged. New
V1 incorrectly assumed all source Euler columns were already present;
V3 completed missing GF but exposed missing homogeneous partners. Both
failed captures and full residual tables remain. V2 failed syntax
preflight before launch; V4 uses the full Hamiltonian construction.
No old table, receipt, action, convention or physical input was edited.

For a future proper one-loop calculation define operators explicitly,
rather than claiming an unidentified historical VDI label has been
recovered. The following are PROPOSED equation/types to derive and test:

    Q Gamma1 = sum_z [F_z Euler_z Gamma1
                      +(-1)^p_z E_z Euler_Jz Gamma1],
    D_source = sum_z (-1)^p_z E_z Euler_Jz Gamma1,
    D_reg = sum_z (-1)^p_z (R phi)_z Euler_Jz Gamma1.

Here E is the FULL classical field Euler, including physical source
companions; R is the actual fixed regulated inverse minus physicalfree
inverse fromV791. D_source andD_reg are distinct defined terms, not
arbitrary contact coefficients. The older VDI executable/formula is
unavailable; no equality to its reported numerical tensor is presumed.
The explicitly recorded g0 marked D_epsilon derivative is yet another
operator and must not be substituted for either of these.

Build Gamma1 and its source derivatives from the SAME full sourceful
quadratic action and fixed regulator asV799, with the inherited proper
normalization/reference determinant retained. The model's source-quadratic
u terms must survive source differentiation. An independent finite graded
Gaussian should verify the proper/source chain and mean-product subtraction
before any loop reference. Useful candidate finite identities to DERIVE,
not accepted new amplitudes, are the second-variation product rule for
B=sum F E and the regulated source correction (V_R,Gamma1)=D_reg.

Do not assume B=0 in the full chiral model. Qualified CPS retains the
hatted defect: (S_full,ext,S_full,ext)/2+dS_full,ext=Ihat. At physical
fermion means/sources0 its fermion block is probe-independent; first-u
insertion support can then be assessed explicitly. Setting source0
BEFORE differentiation is not licensed by that restricted block fact.
The pure bosonic643-field calculation and full physical hatted problem
have distinct stated premises. Keep any internal hatted insertion until
actual support excludes it in this selected coefficient.

Retain full finite mean/source products. R contains E^-1 and f^-1;
these cannot be separately applied to arbitrary Schwartz means as if
tempered. In V782 the external-mean product is nonzero and cancels
only with its same-functional subtraction. The g1 calculation must
derive that cancellation or its retained defect, with UV-first/IR order,
not delete a D/source term or use the known covariance as a fitted target.

The next execution record must freeze these actual operands, projected
source/field classes, all profile and normalization freedoms, negative
controls and resource bounds. Proper QGamma/source outputs should be
derived without the V797 hard-response table as an operand, then compared
late to the already frozen current. The complete common marked/unmarked
normalization/reality construction, QAP,measure/equivalence,E5/A5 and
physical viability remain open. No foundational adoption is made here.
