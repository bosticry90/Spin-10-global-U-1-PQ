# Complete the cotangent operation from its full source Hamiltonian

V3 FAILED1192 source comparisons, all field maps still agree. Missing
inhomogeneousGF ports are now supplied, exposing a second distinct input
limit: FJB's newly transported B/scalar field flows did not add all their
JB/Jx/JC cotangent partners to its operation table. Atg0 only45JC ports
differ; atg1 B180/scalar326/C45 differ perroute. Lambda/antighost source
ports remain equal. Preserve complete V3 audit/maps/residuals/capture.

Stop piecemeal additions. Derive the ENTIRE source-homogeneous operation
from the actual complete field Hamiltonian, using the already qualified
physical-chart source action convention (ISD1):
 S_source=sum_z(-1)^p_z J_z F_z,
 QJ_hom,z=(-1)^p_z LEFT Euler_z S_source.
Here F_z are the actual independently transported FJB field maps, ALL643,
bothg0/g1, before mean restriction. Compare S_source to the SOURCEPART
of the actual MWP action at each grade before differentiation. Separately
retain actual GFdensity and derive all643 GFgradients. Add these two
DERIVED complete pieces, then compare every source map to V788/V789
fullfieldEulers with the same(-1)^p sign. Keep oldFJBoperation/differences
as historical inputs, not an allegedly full cotangent source operation.

This method is canonical Hamiltonian completion with an independent
density check, not adding residuals, choosing signs from a quantum
target, changing the action, or weakening any of5144port tests. Full
old/new source hashes/added counts saved. Physical508Euler companions
remain separate, not evaluated or declared0. QGamma amplitude uncomputed.
KnownoldFJB G usesJa/JLambda only, so these findings do not invalidate
its own qualified qG result or rewrite old receipts. They correct THIS
audit's overbroad assumption about the old operation table's other ports.

Reassessment: two scientifically incomplete source-table attempts have
identified missingGF and missinghomogeneous partners. The unified
source-Hamiltonian reconstruction is the least expensive complete test;
do not launch another patch based on matching residual coefficients.
V4same120s afterimports,8GiBsampled/350MiBfloor/32MiBcompletepacket.
Allpreviousfailedsources/captures kept, scientificrequirements fixed.
