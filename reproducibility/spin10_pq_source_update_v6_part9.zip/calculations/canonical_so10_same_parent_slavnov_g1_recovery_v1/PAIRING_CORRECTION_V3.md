# Syntax preflight correction

V2 preparation FAILED during actualPython3.10 ast.parse: a generated
route_completed.append line had5leading spaces instead of3. No V2worker
or scientific computation launched and no V2manifest/result/capture is
manufactured. Exactfailedsources and complete returnedtooloutput are
preserved in pairing_v2_preparation_failure.json, explicitly identified
as a tool observation rather than a monitored worker capture.

V3 corrects that line's indentation only. It retains V2's justified GF
source-port completion, all5144tests, signs/inputs/bounds and V1failure.
Syntaxparse beforefreeze remains mandatory. Same120s/8GiBsampled/
350MiBfloor/32MiBcompletepairingpacket; no physical or scientific change.
