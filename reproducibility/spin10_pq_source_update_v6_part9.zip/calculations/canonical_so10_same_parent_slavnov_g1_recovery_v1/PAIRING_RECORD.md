# Actual full-source Hamiltonian pairing audit

Base0fa30739/main,V799. Definitionphase question: what signs connect the
actual physical-chart BV field/source operations to the LEFT Euler
derivatives of the sourceful GF action, throughg1,intrinsic01? Do not
guess the source-flow sign from the simplified equation in another chart.

Prospective exact tests, BOTH qualified FJB transport routes, all643field
and643source ports, atg0/g1 before mean restriction:
 F_z=(-1)^p_z Euler_Jz S,
 QJ_z=(-1)^p_z Euler_z S.
The second displayed relation is a proposal to verify against the actual
FJB operation, not an adopted convention change. E0/F0 from qualified
V788 GFcommon; E1/F1 from independently action-differentiated V789states.
FJBsourceoperation includes GF/source homogeneous columns; the separate
physical508 Euler programs are NOT computed or setzero. Its convention,
once verified, applies to the actual physical Euler companion through the
same BV pairing. Probe source-quadratic terms stay in later construction.

If the displayed full-map identity fails, preserve exact residual ports
and scope; derive the discrepancy from original pair transport and never
fit a sign to the quantum current. Compare exactpolynomials at allports,
including0. Record nonzero odd-port unsigned source control; no control
is assumed sensitive if actualdata0. Bind input bytes/currentpolicy,
sourcecopies parsedPython3.10 beforeexecution. Single120s afterimports,
8GiBsampled/350MiBfloor/32MiBpairingpacket includingallfuturefailedversions.
Both inheritance routes share coefficient/Euler software and action;
notindependentscientists. No QGamma/D coefficient, loop integration,
normalization/baseline or scientificpromotion. Other same-parent operands
remainuncomputed until this foundational convention is settled.
