from pathlib import Path
from hashlib import sha256
from collections import Counter
import gzip,importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/same-parent-slavnov-g1-recovery-v1-2026-11-07')
sp=importlib.util.spec_from_file_location('pairing_final_physical_tools',O.parent/'canonical_so10_physical_current_input_recovery_g1_v1/physical_v2.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
J=v.J;w=v.w
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for name in ['final_preparation.json','pairing_preparation.json','pairing_preparation_v3.json','pairing_preparation_v4.json']:
  for n,h in read(O/name)['sha256'].items():assert digest(R/n)==h,(name,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 failures={}
 for version,count in [('',1552),('_v3',1192)]:
  cap=read(O/('pairing_capture'+version+'.json'));audit=load(O/('pairing_audit'+version+'.json.gz'))
  assert cap['exit_code']==1 and not cap['calculation_completed'] and 'ACTUAL_PHYSICAL_CHART_PAIRING_MISMATCH' in cap['stdout_and_stderr'] and len(audit['residuals'])==count
  assert all(not z['field_residual'] and z['source_residual'] for z in audit['residuals'])
  failures['V1' if not version else 'V3']=dict(source_residual_ports=count,execution_state='FAILED',exact_after_import_seconds_not_serialized=True)
 prepfailed=read(O/'pairing_v2_preparation_failure.json');assert prepfailed['exit_code']==1 and not prepfailed['worker_launched'] and 'IndentationError' in prepfailed['stdout_and_stderr']
 assert all(not (O/n).exists() for n in ['pairing_preparation_v2.json','pairing_capture_v2.json','pairing_result_v2.json','pairing_audit_v2.json.gz'])
 result=read(O/'pairing_result_v4.json');audit=load(O/'pairing_audit_v4.json.gz');assert not audit['residuals'] and digest(O/'pairing_audit_v4.json.gz')==result['audit_sha256']
 assert audit['physical_Euler_values_not_computed_or_zeroed'] and audit['completed_GF_source_operations'][0]['grades']==audit['completed_GF_source_operations'][1]['grades']
 checked=0;wrong={};added={}
 for table,complete in zip(audit['all_maps'],audit['completed_GF_source_operations']):
  role=table['route'];assert role==complete['route'];ports={(p['grade'],p['field']):p for p in table['ports']};assert len(ports)==2*643
  common=load(O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_GF_common.json.gz'));states=load(O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1'/(role+'_new_states.json.gz'))
  wc=0;ac=0
  for item in complete['grades']:
   g=item['grade'];assert g in [0,1] and [n for n,f,s in item['all643_field_and_source_maps']]==list(range(643))
   fs=dict(common['F0'] if g==0 else states['F1']);es=dict(common['E0'] if g==0 else states['E1'])
   for n,f,s in item['all643_field_and_source_maps']:
    assert f==fs[n] and s==J.encode(w.scale(J.decode(es[n]),J.constant((-1)**J.parity(n))))
    port=ports[g,n];assert port['field_equal'] and port['source_equal'] and port['actual_field_math_sha256']==port['expected_field_math_sha256'] and port['actual_source_math_sha256']==port['expected_source_math_sha256']
    wc+=bool(J.parity(n) and port['source_terms']);ac+=bool(port['old_to_complete_source_difference_terms']);checked+=2
  assert wc==table['unsigned_source_sign_changed_odd_ports']==180;wrong[role]=wc;added[role]=ac
 assert checked==result['exact_port_grade_comparisons']==5144
 assert result['field_pairing']=='F_z=(-1)^p_z*Euler_left_Jz_S' and result['source_pairing']=='QJ_z=(-1)^p_z*Euler_left_z_S'
 cap=read(O/'pairing_capture_v4.json');assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and result['elapsed_after_imports']<120
 resources={}
 for n in ['pairing_capture.json','pairing_capture_v3.json','pairing_capture_v4.json']:
  cap=read(O/n);assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and cap['post_run_observations_qualified'] and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples'])
  resources[n]=dict(largest_private_sample=max(x['private_bytes'] for x in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True,exact_after_import_seconds=result['elapsed_after_imports'] if n=='pairing_capture_v4.json' else 'NOT_SERIALIZED_FAILED')
 print('STAGE all5144completedfieldsourceports,fullHamiltoniancompletion,180oddcontrols,failurespreservedverified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
 cap=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',cap);dump(C/'e4_capture.json',cap);assert p.returncode==0
 ev=[json.loads(z) for z in p.stdout.splitlines() if z.strip()];exits=[z['exit_code'] for z in ev if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and ev[-1]['execution_state']=='COMPLETED'
 assert next(z for z in ev if z['event']=='step_finished' and z['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 old=(C/'old_git_tree.txt').read_bytes();assert old==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True)
 state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V800.md'];size=sum(p.stat().st_size for p in files);assert size<32*1024**2
 out=dict(schema='SAME_PARENT_GF_SOURCE_OPERAND_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_COMPLETE_GF_SOURCE_HAMILTONIAN_OPERATION_NOT_QGAMMA',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'pairing_preparation_v4.json')['base_HEAD'],state_sha256=state,exact_field_source_grade_comparisons=checked,complete_source_operations_routes_equal=True,source_pairing=result['source_pairing'],unsigned_odd_source_control_changed_ports=wrong,old_to_complete_source_changed_port_grades=added,physical_Euler_companions_separate_not_evaluated=True,failed_workers=failures,failed_preparation='V2_PYTHON310_INDENTATION_PREFLIGHT_NO_WORKER',failures_this_increment=3,resources=resources,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(old.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,QGamma_D_amplitude_computed=False,same_parent_proper_Slavnov_comparison_pending=True,full_QAP_E5_viability_goal_completion_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','evidence_validation','E4_step_exits','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
