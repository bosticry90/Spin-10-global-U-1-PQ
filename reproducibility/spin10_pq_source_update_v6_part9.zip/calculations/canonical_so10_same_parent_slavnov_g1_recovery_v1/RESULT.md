# Complete GF/source Hamiltonian operand recovered

The actual full-source pairing is now checked throughg1/intrinsic01:
F_z=(-1)^p_z LEFT Euler_Jz S and QJ_z=(-1)^p_z LEFT Euler_z S.
The completed GF+source operation agrees at all5144 field/source/grade/
route comparisons, including zeros. The canonical source Hamiltonian
constructed from all643 field maps matches the actual source density
BEFORE differentiation. Both inherited transport routes give the same
complete operations. Physical508Euler companions remain separate input
programs, not evaluated or setzero here.

This is a prerequisite for the next proper Slavnov comparison, not a
QGamma amplitude or a normalization choice. Exact old/new full maps,
per-port hashes and residuals are in the pairing audit artifacts. See
[definitions and next test](DEFINITIONS_AND_NEXT_TEST.md).

The first audit failed because the old FJB operation supplied GF Euler
terms only for Ja/JLambda. The first attempted completion also exposed
missing B/scalar cotangent partners in its other sources. The old
operation's own G uses only Ja/JLambda and remains qualified in that
scope. A unified full Hamiltonian reconstruction replaces this new
audit's incomplete-input assumption, with the same5144requirements.
V1 andV3 failed scientific/input audits and their exact captures/maps
are retained. V2 had an indentation error caught before worker launch;
its exact source and full returned-tool observation are retained as a
preparation failure. Nothing is relabeled PASS or retroactively edited.

Completed V4 took35.151087s under120s,8GiBsampled/350MiBfloor/32MiB
packet. Unsigned odd-source variation changes180 port/grade maps in
each route, so the sign test is sensitive. Final receipt owns source,
input, fullmap, failure, resource/state/oldtree and E4once checks. Custody
remains exit2/seven unresolved NOTPASS; state113/34of39,E5/A5open unchanged.

Scientific value: the next loop calculation can use complete source
operands and precise D_source/D_reg definitions instead of an incomplete
table or a guessed historical label. TrackB records two scope-assumption
failures and a caught syntax error, followed by explicit Hamiltonian
completion. Shared action/ring/Euler software and AI author limit
independence; no independent scientist/proof-kernel/empirical validation.

Next derive the actual proper Gamma1 source/mean comparison with fixed
regulator, retained hatted insertion/support and all same-functional
subtractions. Compare late to V799's frozen current; never fit a contact
or assume a classical/source-zero result supplies a quantum insertion.
Common normalization/reality,QAP,measure/equivalence,E5/A5 and full
Spin(10)xU(1)PQ investigation remain incomplete and active.
