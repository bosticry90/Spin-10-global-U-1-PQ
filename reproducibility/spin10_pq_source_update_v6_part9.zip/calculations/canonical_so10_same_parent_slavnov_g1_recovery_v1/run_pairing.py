from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/same-parent-slavnov-g1-recovery-v1-2026-11-07')
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert not (O/'pairing_preparation.json').exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='0fa30739bfeb45ae8f9e2fd72551853e1b4653d4'
names=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V799.md','calculations/canonical_so10_vector_expanded_regulator_reconciliation_g1_v1/validation_receipt.json','calculations/canonical_so10_physical_current_input_recovery_g1_v1/physical_v2.py']
for role in ['primary','replay']:names+=['calculations/canonical_so10_full_jet_source_master_bridge/'+role+'_tables.json.gz']
for role in ['native','replay']:names+=['calculations/canonical_so10_new_physical_returning_inventory_g1_recovery_v1/'+role+'_GF_common.json.gz','calculations/canonical_so10_full_current_inventory_g1_recovery_v1/'+role+'_new_states.json.gz']
for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in ['READING_RECORD.md','PAIRING_RECORD.md','pairing.py','run_pairing.py']:
 if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'pairing_preparation.json',dict(base_HEAD=head,sha256={p.relative_to(R).as_posix():digest(p) for p in [R/n for n in names]+[O/n for n in ['READING_RECORD.md','PAIRING_RECORD.md','pairing.py','run_pairing.py']]},scientific_acceptance='NOT_PERFORMED'))
C.mkdir(parents=True,exist_ok=False)
with (C/'old_git_tree.txt').open('xb') as h:h.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'pairing.py')]);dump(O/'pairing_capture.json',cap);dump(C/'pairing_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
