# V976 · Relative profile functional

The fixed-order flat compact heat comparison now
has one relative correction to the old common
analytic chart. It retains the logarithmic clock
term and the positive heat transfer jets. Applying
it before taking the source or left master derivative
gives the corresponding corrections from the same
parent.

The actual V974 longitudinal contact is recovered,
including its fixed-total-length control. Both
exports verify 1,170 free quartet rows and 668
cross-sector spatial gauge-source rows. The latter
show why the profile factors must stay on their
own edges.

The result is for the inherited unprobed proper
Euclidean word domain with unchanged IR profiles.
The explicit profile-dependent regulator insertion,
background, marked and exceptional products still
have separate domain obligations.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
