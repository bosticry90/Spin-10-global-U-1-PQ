"""Implement the finite flat relative heat-transfer symbol rule."""

import gzip
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def moments(unheated,edges,r):
    clock = sp.sympify(sum(a for a,_,_ in edges))
    linear = 2*sum(a*d for a,d,_ in edges)
    constant = sum(a*p2 for a,_,p2 in edges)
    symbol = sum(value*r**power for power,value in unheated.items())
    heat = r*linear+constant
    moments = {j:sp.expand(symbol*(-heat)**j/sp.factorial(j)).coeff(r,2*j-4)
               for j in range(max(0,max(unheated)+4)+1)}
    return clock,moments


def relative(unheated,edges,old,r):
    clock,new = moments(unheated,edges,r)
    common,reference = moments(unheated,old,r)
    value = -new[0]*sp.log(clock/common)/2
    for j in range(1,len(new)):
        value += sp.gamma(j)*(new[j]/clock**j-reference[j]/common**j)/2
    return value


def controls():
    r,a,b,n,d,P,p,h = sp.symbols("r a b n d P p h",positive=True)
    old = [(2,-d/2,P/4),(2,d/2,P/4)]
    edges = [(a,-d/2,P/4),(b,d/2,P/4)]
    source = {-3:n,-4:-h*p/4}
    clock,rows = moments(source,edges,r)
    assert clock == a+b
    assert sp.expand(rows[1]-n*d*(a-b)) == 0
    result = relative(source,edges,old,r).subs(n*d,p/4)
    target = p*(h*sp.log((a+b)/4)+(a-b)/(a+b))/8
    assert sp.simplify(result-target) == 0
    assert result.subs({h:0,a:1,b:3}) == -p/16
    assert result.subs({h:0,a:3,b:1}) == p/16

    # The positive constant transfer jet and the square of the linear
    # transfer both contribute for a power-divergent unheated symbol.
    _,power = moments({-2:1},[(a,d,P)],r)
    assert power[1] == -a*P and power[2] == 2*a**2*d**2

    beta,primitive = sp.symbols("beta primitive")
    with_beta = {-3:n+beta*primitive*n,-4:-h*p/4}
    whole = relative(with_beta,edges,old,r)
    insertion = relative({-3:primitive*n},edges,old,r)
    assert sp.expand(sp.diff(whole,beta)-insertion) == 0
    assert sp.expand(whole.subs(beta,0)-relative(source,edges,old,r)) == 0


def sector(i):
    if i < 180:
        return i//4 >= 12
    if 508 <= i < 643:
        return (i-508)%45 >= 12
    return None


def actual_ports(phase):
    role = "native" if phase=="native" else "replay"
    base = ROOT / "calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1"
    with gzip.open(base/f"{role}_inverse.json.gz") as stream:
        inverse = json.load(stream)["Greference"]
    quartet_rows = 0
    for i,j,_ in inverse:
        if sector(i) is None and sector(j) is None:
            continue
        assert sector(i) is not None and sector(i) == sector(j)
        quartet_rows += 1
    base = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    with gzip.open(base/f"{role}_full_current.json.gz") as stream:
        action = json.load(stream)["current"]["complete_S_GF_source"]
    noncommuting_source_rows = 0
    for g,word,_ in action:
        if g==1 and len(word)==3:
            i,j,k = [v for v,_ in word]
            if i<180 and i%4==1 and 553<=j<598 and 643<=k<823:
                noncommuting_source_rows += int(sector(i)!=sector(j))
    assert quartet_rows and noncommuting_source_rows
    base = ROOT / "calculations/canonical_so10_longitudinal_heat_transfer_v1"
    receipt = json.loads((base/"validation_receipt.json").read_bytes())
    result = json.loads((base/"result.json").read_bytes())["checks"]
    assert receipt["execution_state"]=="COMPLETED"
    assert result["relative_scaled_coefficient"]=="h*log((a+b)/4)+(a-b)/(a+b)"
    return quartet_rows,noncommuting_source_rows


def check(phase):
    controls()
    quartet,cross = actual_ports(phase)
    return {"actual_free_quartet_rows":quartet,"cross_sector_JB_spatial_rows":cross,
            "V974_positive_transfer_contact_reproduced":True,
            "fixed_total_length_negative_control":True,
            "power_symbol_positive_j1_j2_controls":True,
            "relative_parent_derivative_commutes":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
