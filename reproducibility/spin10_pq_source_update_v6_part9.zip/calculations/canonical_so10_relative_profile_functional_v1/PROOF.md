# One relative heat-profile functional on the compact proper parent

Keep the unprobed flat compact parent P of V879.
For each fixed ordered word in its admitted
Euclidean domain, keep the same free reference,
IR profiles, routing and coefficient matrices.
Only vary the positive flat heat length of the
free gauge/ghost quartet. The profiles are
scalar on each quartet, with independent H and
M. Expand the sector projectors on their own
free lines. They do not commute through the
interaction or source vertices. Hold other
profiles and the flat source-free reference
determinant fixed.

For a path of sector labels, free momenta are
q+p_e and the total length c is the sum of the
edge lengths. After extracting exp(-t c q²)
the transfer heat factor is

    exp[-t (2 q dot sum_e ell_e p_e
                        + sum_e ell_e p_e²)].

In the HMM1 convention let b4 be the common
unheated r^-4 symbol and b_ell[j,4] the
coefficient of r^(2j-4) at transfer order t^j
after removing the leading Gaussian. Relative
to the old lengths ell0 the local difference is

    H_ell-H_ell0 = (1/(8 pi²)) angular average [
        -b4 log(c/c0)/2
        + sum_(j>=1) Gamma(j)/2
            (b_ell[j,4]/c^j-b_ell0[j,4]/c0^j)].

The terms with lower unheated degree that
produce the common analytic reference cancel
in this relative formula. Do not delete the
positive heat orders. For a flat scalar heat
factor, the t^j term has at most j powers of r.
If the unheated Laurent symbol has maximum
degree m, no j>m+4 can enter the displayed
coefficient. The executable uses this bound
rather than a cap on an arbitrary heat series.
A matrix or odd coefficient stays in its
original word and can use the scalar rule
component by component.

For a fixed finite word and profile lengths in
a compact positive interval the hard remainder
estimate is the HMM1 one. The leading clock is
bounded away from zero. At large q relative to
the transfers, the shifted Gaussian gives the
same uniform domination after finitely many
Taylor terms. On the bounded domain the two
regulated kernels approach the same unheated
one. For nonexceptional transfers this follows
from the separated soft-pole estimates. On the
inherited compact jointly admissible labels
use the original V879 one-tangent joint soft
majorant, since the bounded heat multipliers
do not worsen it. This step asserts only that
same domain. It gives no additional inverse-
heat, exceptional, background or marked
product domain.

On the same P, and also on the qualified
parent P+beta B[P] with the left beta of
V849/V879, define the relative correction

    C_ell[Z]=C_ell0[Z]-(H_ell[Z]-H_ell0[Z]).

Then H_ell+C_ell equals the old converted
functional on this domain. Form B[P] before
adding beta. The same source and master
derivatives of the single relative correction
give the corresponding conversion. They act
on the ordered coefficient matrices and jets
with the inherited signs and adjoints. There
is no independent source or master coefficient
to choose. This transports the already admitted
proper analytic comparison; it is not a new
existence proof of a causal or marked product.
In particular, an explicit regulator insertion
depends on the profile and requires its own
transport, and a new coincident multi-insertion
domain is not assumed here.

For the actual V974 centered lower source,
the unheated degree -3 term has angular factor
n_mu. The shifts -p/2,+p/2 make the j=1 term
(a-b)n_mu(n dot p). Its average p_mu/4 gives
the rational contact of V974. The residual
b4 supplies its logarithmic term for a light
exterior ghost. Swapping unequal lengths at
fixed total reverses the positive jet but
leaves the logarithm unchanged. The executable
recovers the same actual ordered contact and
checks the linearity with a separate parent
insertion control. These are checks of the
relative profile rule and its application,
not independent physical validation. The
routes share the HMM1 premises and software.
