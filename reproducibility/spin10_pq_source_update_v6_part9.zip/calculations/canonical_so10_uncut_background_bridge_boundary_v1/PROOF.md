# First-background bridge on the uncut two-exit core

Use the V884 ordinary BB two-port
after the V991 matched UV forest
and the V884 common finite
normalization. Keep the core
itself at A=0. Insert one
background vertex on just one
exit, with its own transfer
label. Let p and -p be the two
inner exit momenta, and q the
post-insertion outer momentum.
The A label has transfer q-p.
The loop core has no external
label at its vertices.

For the soft set consisting of
the two inner exits, the hard
complement has an unlabeled
component containing the loop.
The V881 rank is 2-1=1.
Conservation at that component
still forces p and -p. The
independent outer q momentum
does not split that rank.
Thus two order-two inverse
powers remain critical for
an absolute termwise bound.
For the full bridge placement
p and q are independent
integration coordinates.

A literal failure uses the V881
Phi54 seagull with two B1
legs along e2. Its scalar
trace is -12 and its integrand
has nonzero fixed sign on a
fixed hard loop annulus at
positive reference mass.
On one exit take the actual
light color-0 bridge of V991
from B1 to Lambda2 with
A along e2. Keep the other
exit ordinary B1. On the
center of a transverse angular
patch set p=u e1,q=e1,
with u>0 tending to zero.
Stripping its nonzero phase
and color the mixed bridge is
-(u+1)/(2u²). The other
ordinary exit gives 1/u².
The scaled product u^4
therefore tends to -1/2.
This leading angular value
is continuous and nonzero
on open p-angle and hard-q
patches. The hard annulus
has nonzero volume. Thus
the isolated graph has a
logarithmic absolute p
divergence, even with a
label on the outer bridge.
This tests a termwise
estimate and does not decide
the sum.

For the grouped BB core retain
the V884 cancellations,
including the massive scalar
angular dimension jet, and
use its actual bounds. In
a fixed small ball the
converted kernel U obeys

    |U(p)| <= C |p|² (1+|log |p||),
    |U_e(p)-U(p)| <= C e²,

where e is the paired inner
IR scale. These are the
V884 grouped bounds for
the original ordinary two-port,
with its finite mass
insertions where admitted.
They are not bounds on the
ungrouped seagull or a
changed normalization.

After the UV finite part
the ordinary untouched exit
has the factor chi_o(p²)^2,
chi_o(x)=1-exp(-x/o²) for
outer scale o. For the
differentiated bridge use
the actual first inverse
and two heat-half derivatives.
On any bounded ball the
uniform Euclidean bound is

    |B'_o(p,q)| <= C (|p|+|q|)/(|p|² |q|²).

The BB block of K_1 has
one momentum and its mixed
blocks have degree zero.
A mixed inverse is order
one, so its product has
the same upper bound.
For a Duhamel half at
t=0 the chi divided difference
equals the integral of its
exponential time factor.
Dropping one endpoint
exponential and extending the
remaining time integral gives
both 1/P and 1/Q bounds,
where P=p²,Q=q². In particular
it is bounded by 1/P next
to a G(q) or by 1/Q next
to a G(p). Multiplication
by the degree-one L_1
gives the displayed bridge
bound with both arms.
The fixed-flat first
Born bridge obeys the
same bound.

The product of U with
the two exits is dominated
by

    C (|p|+|q|)(1+|log |p||)
                    /(|p|² |q|²).

It is integrable near the
joint p,q tip in eight
independent coordinates.
Away from the tip the
locally bounded tests
and ordinary pointwise
profile limit apply. This
gives the unheated grouped
bridge limit in the local
Euclidean coefficient
domain, with compact
external tests.

The uniform core error
instead multiplies

    C e² (|p|+|q|) chi_o(P)^2
                       /(|p|^4 |q|²).

The q integral is bounded
uniformly on bounded
balls. In the p radial
integral, split at |p|=o.
Use chi_o(P)<=min(1,P/o²).
For a unit ball the resulting
bound is 1/4+|log o|.
The paired scale e=o
therefore makes the core
error vanish. More generally
e²(1+|log o|) tending to
zero suffices for this
bound. No arbitrary
independent-rate limit
follows from it.

The result establishes the
selected grouped Euclidean
first-A bridge placement
through the uncut critical
two-port. It does not cover
A on the loop core, multiple
tangents or the Lorentzian
and weak adiabatic extensions.
The exact rank, bridge and
radial checks share the
model and symbolic software.
