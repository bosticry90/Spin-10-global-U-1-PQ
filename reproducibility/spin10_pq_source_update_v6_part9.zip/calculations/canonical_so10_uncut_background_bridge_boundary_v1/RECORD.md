# V994 pre-execution contract

Freeze V993, V991, the V881 soft-rank
and Phi54 seagull, and V884 grouped BB
bounds with actual receipts. Insert
one independently labelled background
vertex on just one exit of an uncut
two-port ordinary BB loop. Compare
the actual termwise seagull with the
complete already converted BB group.
Prove or delimit the paired Euclidean
soft limit for this bridge placement,
including uniform regulator errors
when both outer momenta are soft.
Require a nonblind termwise log
divergence and strict grouped bound.
No Lorentzian or global limit inferred.

Native 120 s, final 180 s including E4
cap 120 s, 8 GiB sampled private,
350 MiB launch floor, 8 MiB artifact
and 32 MiB packet. No authority change.
