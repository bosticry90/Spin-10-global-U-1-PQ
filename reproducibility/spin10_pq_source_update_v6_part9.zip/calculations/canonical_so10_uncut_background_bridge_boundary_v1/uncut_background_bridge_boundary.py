"""Check the tied soft rank and grouped first-A bridge estimate."""

import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


def load(name,file):
    path = ROOT/"calculations"/("canonical_so10_"+name)/file
    spec = importlib.util.spec_from_file_location(name,path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def rank():
    # Variables are inner exit 1, inner exit 2 and the exterior edge.
    core_conservation = sp.Matrix([[1,1,0]])
    flows = sp.Matrix.hstack(*core_conservation.nullspace())
    inner = flows[:2,:]
    assert inner.rank()==1 and inner[0,:]==-inner[1,:]
    assert flows[[0,2],:].rank()==2
    # Replacing q by its independent transfer q-p is unimodular.
    A = sp.Matrix([[1,0],[-1,1]])
    assert A.det()==1 and (A*flows[[0,2],:]).rank()==2
    return 1


def actual(phase):
    owner = load("scalar_source_transport_v2","source_transport.py")
    _,entries,_,_,_,_ = owner.inputs(phase)
    R = sp.SparseMatrix(54,54,{(i,j):z for (i,j),z in entries[1].items() if max(i,j)<54})
    assert R.T==-R and sp.expand(sp.trace(R*R))==-12
    bridge = load("covariant_background_forest_v1","covariant_background_forest.py")
    eta,r,K = sp.Symbol("eta_H"),*bridge.connection()
    u = sp.Symbol("u",positive=True)
    e1 = sp.eye(4)[:,1]
    p,q = u*e1,e1
    mixed,gp,gq,L = bridge.born(p,q,eta,r,K)
    assert gp==gq==L==0 and sp.cancel(mixed+(u+1)/(2*u*u))==0
    ordinary = bridge.green(p,eta)[2,2]
    assert ordinary==1/u**2
    leading = sp.limit(u**4*mixed*ordinary,u,0,dir="+")
    assert leading==-sp.S.Half and r!=0
    return str(leading)


def radial():
    r,s,o = sp.symbols("r s o",positive=True)
    inner = sp.integrate(r**3/o**4,(r,0,o))
    outer = sp.integrate(1/r,(r,o,1))
    assert inner==sp.Rational(1,4) and outer==-sp.log(o)
    assert sp.limit(o**2*(inner+outer),o,0,dir="+")==0
    # Joint p,q majorant after the grouped p^2 gain.
    q_part = sp.integrate(s*(r+s),(s,0,1))
    assert q_part==r/2+sp.Rational(1,3)
    grouped = sp.integrate(r*(1-2*sp.log(r))*q_part,(r,0,1))
    assert grouped==sp.Rational(11,18)
    # The termwise lower comparison has a genuine radial logarithm.
    assert sp.limit(sp.integrate(1/r,(r,o,sp.S.Half)),o,0,dir="+")==sp.oo

    P,Q,T = sp.symbols("P Q T",positive=True)
    divided = (sp.exp(-T*Q)-sp.exp(-T*P))/(P-Q)
    assert sp.simplify(sp.limit(divided,P,Q)-T*sp.exp(-T*Q))==0
    assert sp.integrate(sp.exp(-s*P),(s,0,sp.oo))==1/P
    assert sp.integrate(sp.exp(-s*Q),(s,0,sp.oo))==1/Q
    return str(grouped)


def check(phase):
    return {"unlabelled_soft_exit_rank":rank(),"actual_termwise_leading_over_color":actual(phase),
            "grouped_joint_radial_bound":radial(),"paired_error_epsilon_squared_log_vanishes":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
