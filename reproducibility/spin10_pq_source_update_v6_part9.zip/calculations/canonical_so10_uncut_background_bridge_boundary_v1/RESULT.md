# V994 result

The two inner exit momenta of the unlabelled
two-port remain tied even with a labelled
background insertion on one bridge. The
actual Phi54 seagull and mixed bridge give
a nonzero leading coefficient on an open
soft angular patch. The isolated graph
has a logarithmic absolute divergence.

The complete converted ordinary BB group
supplies the two-power soft improvement.
With the first-A bridge and its two
Duhamel halves, the grouped joint p,q
majorant is integrable. The uniform inner
error is bounded by a constant times
epsilon²(1+|log epsilon|) at the paired
outer scale, so the error vanishes.

This qualifies the selected direct uncut
Euclidean placement with A on one bridge.
A on the loop core, the Lorentzian boundary
and the weak adiabatic limit remain
separate. The termwise counterexample
applies to the isolated graph.
