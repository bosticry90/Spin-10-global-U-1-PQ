# Actual selected BV square before aCC amplitude expansion

Continue eaf240cf/main,V811,D: under current AGENTS. Prior turn is progress:
full U0 factorization, actual72-path/two-response representation and six
nonzero finite diagnostics are qualified. Full continuum aCC and common
normalization remain open. State113/34of39,E5/A5 unchanged. No agents,
adoption, activation, branch/worktree, protected promotion or remote action.

Question: does the ACTUAL canonical field/source derivation square to zero
in every coefficient that could multiply a formal effective-action derivative
to reach Lambda1,C2,source0,A0,intrinsic01? Do not assume nilpotency from a
formal BRST name, a proper-identity handoff or agreement of loop coefficients.
This least expensive structural test could justify a later integrability
prediction; it does NOT select an unknown aCC coefficient or replace its
direct loop/limit obligations. This stage reads no known consistency remainder.

Use full authenticated native/replay V802 F/E maps, source derivatives/Eulers
already performed, plus actual physical kinetic E0 and physical E1_B gauge/
scalar maps. Canonical fields are643, sources643; Qphi=F, QJ=(-1)^p E.
Form all6 g/u square coefficients: Q0Q0;Q0Q1+Q1Q0;Q0Qu0+Qu0Q0 and
Q0Qu1+Qu1Q0+Q1Qu0+Qu0Q1 for each H/M probe. All1286 output coordinates
and every branch port receive a disposition. Odd Q^2 is an even derivation;
its action on generators determines it on formal functionals. No global
nilpotency, chiral anomaly/measure phase or continuum QAP is inferred.

Full source operations and ordinary jets precede mean selection. Keep upper
Lambda<=1,C<=2, no other means/sources. Formal Taylor coefficients of Gamma
have no inverse mean fields; a discarded coefficient with an extra forbidden
field cannot later feed this target. For ONE Q action only one input token
is replaced, so its untouched rest must already obey that upper profile.
This necessary selector may be applied before multiplication, while retaining
all original word/position dispositions. D preserves the profile, allowing
the outer FULL source-derived flow to be projected before D. No inner source
term is dropped merely because its original source mean is zero.

Native odd-prefix replacement is compared against the LEFT identity
 QP=sum D_jets(Qn)*LEFTpartial_(n,jets)P, varied flow on LEFT.
Replay uses the independent LEFT operation on safely eligible full words.
Check full primitive types (ghost+1,odd,dimension+1 with intrinsic0/1) and
complete selected square types (ghost+2,even,dimension+2). Save all residuals,
including nonzero/outside-domain ones; do not stipulate zero or weaken a gate.
Controls: omit all outer source flows, and linearize outer Ja flows by
removing their nonlinear Lambda-containing terms. Report actual sensitivity
or blindness at every case/coordinate, never present a blind zero as a check.

Physical support is explicit, not unknown E1_x=0. Actual kinetic E0 is included
in INNER source maps; Q0 on its B terms must cancel Maxwell gradients rather
than be dropped before variation. At the selected plane all outer physical
kinetic E0 and known physical E1_B maps vanish. Unknown physical E1_x is
source-free: Q0 on its g1 B-x kinetic terms leaves a physical scalar mean,
Q0 on potential/scalar terms is zero (Q0x=0); Qu0 physical flows vanish
identically. These are the ONLY outer operations applied to an inner Q1
physical E1_x in these square coefficients, so its contribution is excluded
by action support, not assigned a value. Physical potential E0 is likewise
source-free and varies to zero on this plane: Q0x=Qu0x=Qu1x=0 and F1x has
one scalar mean. A possible outer physical tadpole is intrinsic3 at A0,
outside01; other outer potential gradients retain a scalar mean. Original
unshifted A0 and polynomial physical-parameter domain are binding.
All physical first-u flows vanish; F1 physical x maps are source-free x*C,
verified before the exclusions. The CPS P=S=K ideal is stable under the
listed nonminimal/ghost/source operations; omitted fermion components retain
a fermion mean. This is a selected-plane support argument, not full-Q^2=0.

If all selected squares vanish, only a finite-formal target operator identity
is earned. A later reconstruction from Q Delta=Q^2 Gamma still requires
faithful carrier completeness, proper Gamma definitions and a justified
relation to the common reference/limit prescription. No missing coefficient
is solved from the existing remainder in this stage. Nonzero squares instead
withhold that shortcut and redirect to the actual two-response calculation.

One180s after-import worker,8GiB sampled private/350MiB launch floor,
64MiB complete packet/10MiB artifact. Freeze sources/immutable inputs before
computation, preserve exact failed/unfinished captures, no automatic retry.
Shared action/chart/ring/software/AI author; native/replay agreement cannot
validate shared physical assumptions. Full goal stays ACTIVE.
