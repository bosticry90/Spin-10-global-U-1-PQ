from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
import gc,importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/selected-BV-square-g1-u1-v1-2026-11-07')
sp=importlib.util.spec_from_file_location('verify_actual_selected_BV_square',O/'square_v2.py');s=importlib.util.module_from_spec(sp);sp.loader.exec_module(s)
J=s.J;w=s.w;read=s.read;load=s.load;digest=s.digest
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def group(n):return ('J_'+group(n-643)) if n>=643 else 'B' if n<180 else 'x' if n<508 else 'Lambda' if n<553 else 'C' if n<598 else 'a'
def main():
 tick=time.perf_counter();watch=threading.Timer(360,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in ['preparation.json','preparation_v2.json','final_preparation.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 fail=read(O/'square_capture.json');cap=read(O/'square_v2_capture.json');res=read(O/'square_v2_result.json')
 assert fail['exit_code']==1 and not fail['calculation_completed'] and fail['post_run_observations_qualified'] and 'NameError' in fail['stdout_and_stderr'] and 'STAGE' not in fail['stdout_and_stderr']
 assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and res['execution_state']=='COMPLETED' and res['elapsed_after_imports']<180
 for c in [fail,cap]:assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and all(0<v['private_bytes']<=8*1024**3 for v in c['all_resource_samples'])
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';pn=load(base/'native_inputs.json.gz');pr=load(base/'replay_inputs.json.gz');assert pn==pr;maps,states,physical=s.full_maps(pn);peer,_,_=s.full_maps(pr);assert maps==peer;del pn,pr;gc.collect()
 flow=load(O/res['flow_projections']['file']);assert digest(O/res['flow_projections']['file'])==res['flow_projections']['sha256'];rows=[];projected={};groups={};typecounts={}
 for label,d in maps.items():
  new={};counts=Counter();g=Counter()
  for n in range(1286):
   P=d[n];kept=[];rejected=defaultdict(list)
   for at,(ww,c) in enumerate(sorted(P.items())):
    assert all(i<1286 for i,js in ww);assert sum(s.ghost(i) for i,js in ww)==s.ghost(n)+1 and sum(J.parity(i) for i,js in ww)%2==(J.parity(n)+1)%2
    degree=1+J.dimension(n)-sum(J.dimension(i)+len(js) for i,js in ww);assert degree in [0,1];counts[degree]+=1;reason=s.reason(ww)
    if reason:rejected[reason].append(at)
    else:kept.append(at)
   new[n]=s.project(P)
   if new[n]:g[group(n)]+=1
   rows.append(dict(operator=label,coordinate=n,full_math_sha256=sha256(json.dumps(J.encode(P),sort_keys=True).encode()).hexdigest(),kept_original_indices=kept,rejected=[dict(reason=k,original_indices=v) for k,v in sorted(rejected.items())],selected=J.encode(new[n])))
  projected[label]=new;typecounts[label]={str(k):v for k,v in counts.items()};groups[label]=dict(g)
 assert rows==flow['all_primitive_maps'] and typecounts=={k:{str(i):n for i,n in v.items()} for k,v in flow['primitive_type_counts'].items()};del rows,flow;gc.collect()
 for label in ['Fu0_0','Fu0_1','Fu1_0','Fu1_1']:assert all(not states[label][n] for n in range(508))
 for n in range(180,508):
  assert not states['F0'][n]
  for ww in states['F1'][n]:assert len(ww)==2 and sum(180<=i<508 for i,js in ww)==1 and sum(553<=i<598 for i,js in ww)==1 and all(not js for i,js in ww)
 for label,d in physical.items():
  for n,P in d.items():assert not s.project(P)
 for label in ['Q0','Qu0_0','Qu0_1']:assert all(not any(823<=i<1151 for i,js in ww) for P in maps[label].values() for ww in P)
 assert groups['Q1']=={'Lambda':32,'C':45,'J_x':200} and groups['Qu1_1']=={'J_x':200} and groups['Qu1_0']=={}
 print('STAGE all_full_primitive_types_source_pairings_physical_support_and_projections_verified',flush=True)
 cache={label:{} for label in maps};fresh=[];branchports=0;coordinatecount=0
 for row in res['cases']:
  assert digest(O/row['artifact']['file'])==row['artifact']['sha256'];z=load(O/row['artifact']['file']);coords=z['all1286_coordinate_dispositions'];assert len(coords)==1286;ns=lc=bad=outdomain=0
  for n,saved in enumerate(coords):
   assert saved['coordinate']==n;full={};left={};nosrc={};linear={};journals=[]
   for outer,inner in z['branches']:
    P=maps[inner][n];a,aj=s.compose_prefix(P,projected[outer],cache[outer]);b,bj=s.compose_LEFT(peer[inner][n],projected[outer],cache[outer]);assert a==b;u,uj=s.compose_prefix(P,projected[outer],cache[outer],'no_sources');v,vj=s.compose_prefix(P,projected[outer],cache[outer],'linear_Ja');J.add(full,a);J.add(left,b);J.add(nosrc,u);J.add(linear,v);journals.append(dict(outer=outer,inner=inner,prefix_positions=aj,LEFT=bj,no_sources_positions=uj,linear_Ja_positions=vj));branchports+=1
   full=J.clean(full);left=J.clean(left);nosrc=J.clean(nosrc);linear=J.clean(linear);assert full==left;degrees=Counter()
   for ww,c in full.items():
    assert sum(s.ghost(i) for i,js in ww)==s.ghost(n)+2 and sum(J.parity(i) for i,js in ww)%2==J.parity(n)%2
    d=2+J.dimension(n)-sum(J.dimension(i)+len(js) for i,js in ww);degrees[d]+=1;outdomain+=int(d not in [0,1])
   assert saved==dict(coordinate=n,branches=journals,selected_square=J.encode(full),selected_square_intrinsic_counts={str(k):v for k,v in degrees.items()},no_sources_square=J.encode(nosrc),linear_Ja_square=J.encode(linear))
   bad+=bool(full);ns+=nosrc!=full;lc+=linear!=full;coordinatecount+=1
  assert bad==row['nonzero_selected_coordinates']==0 and outdomain==row['outside01_residual_terms']==0 and ns==row['no_source_control_changed_coordinates'] and lc==row['linear_Ja_control_changed_coordinates']
  fresh.append(dict(case=row['case'],coordinates=1286,branches=len(z['branches']),all_selected_squares_zero=True,no_sources_changed_coordinates=ns,linear_Ja_changed_coordinates=lc));print('STAGE '+json.dumps(fresh[-1],sort_keys=True),flush=True);del z,coords;gc.collect()
 assert coordinatecount==7716 and branchports==19290
 assert [q['no_sources_changed_coordinates'] for q in fresh]==[90,244,84,176,264,444] and [q['linear_Ja_changed_coordinates'] for q in fresh]==[33,32,0,0,231,232]
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120);ec=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert p.returncode==0
 events=[json.loads(v) for v in p.stdout.splitlines() if v.strip()];exits=[v['exit_code'] for v in events if v['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and next(v for v in events if v['event']=='step_finished' and v['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 tree=(C/'old_git_tree.txt').read_bytes();assert tree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True);state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V812.md'];size=sum(p.stat().st_size for p in files);assert size<=64*1024**2 and all(p.stat().st_size<=10*1024**2 for p in files)
 result=dict(schema='ACTUAL_SELECTED_BV_SQUARE_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_FULL_FIELD_SOURCE_SELECTED_SQUARE_WITH_PRESERVED_HARNESS_FAILURE',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,selected_coordinate_squares_freshly_verified=coordinatecount,full_branch_port_compositions_freshly_verified=branchports,cases=fresh,projected_primitive_coordinate_groups=groups,native_LEFT_and_all_full_position_dispositions_equal=True,known_physical_kinetics_varied_before_inner_selection=True,unknown_physical_E1_x_not_assigned_zero=True,physical_support_and_intrinsic01_limitations_in_PROOF=True,failed_workers=1,failed_V1='NAMEERROR_SYS_BEFORE_ALGEBRA_NOTPASS',successful_worker_seconds=res['elapsed_after_imports'],largest_sampled_private_bytes=max(v['private_bytes'] for c in [cap,fail] for v in c['all_resource_samples']),sampled_not_true_or_nested_peak=True,no_aCC_quantum_coefficient_reconstructed=True,no_WZ_reference_limit_source_independence_or_global_Q_square_claim=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(tree.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_QAP_restoration_E5_A5_viability_or_goal_completion_claim=False)
 dump(O/'validation_receipt.json',result);print('RESULT '+json.dumps({k:result[k] for k in ['execution_state','evidence_validation','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
