from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
import gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
def module(n,p):
 sp=importlib.util.spec_from_file_location(n,p);z=importlib.util.module_from_spec(sp);sp.loader.exec_module(z);return z
v=module('selected_BV_prefix',O.parent/'canonical_so10_physical_current_input_recovery_g1_v1/physical_v2.py');vr=module('selected_BV_LEFT',O.parent/'canonical_so10_physical_current_input_recovery_g1_v1/physical_v4.py');J=v.J;w=v.w
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2
 with (O/name).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=64*1024**2
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def ghost(n):
 if n>=643:return -1-ghost(n-643)
 return 1 if 553<=n<598 else -1 if 598<=n<643 else 0
def reason(ww):
 nl=nc=0
 for n,js in ww:
  if 508<=n<553:nl+=1
  elif 553<=n<598:nc+=1
  else:return 'FORBIDDEN_REST_MEAN_OR_SOURCE'
 return 'REST_UPPER_BUDGET_EXCEEDED' if nl>1 or nc>2 else None
def project(P):return {ww:c for ww,c in P.items() if reason(ww) is None}
def full_maps(packet):
 states={k:{n:J.decode(p) for n,p in rows} for k,rows in packet['states'].items()};physical={k:{n:J.decode(p) for n,p in rows} for k,rows in packet['physical'].items()};out={}
 for label,F,E in [('Q0','F0','E0'),('Q1','F1','E1')]+[('Qu0_'+str(pr),'Fu0_'+str(pr),'Eu0_'+str(pr)) for pr in [0,1]]+[('Qu1_'+str(pr),'Fu1_'+str(pr),'Eu1_'+str(pr)) for pr in [0,1]]:
  d={}
  for n in range(643):
   d[n]=states[F][n];e=states[E][n]
   if label=='Q0' and n<508:e=w.plus(e,physical['P_E0'].get(n,{}))
   if label=='Q1' and n<180:e=w.plus(e,physical['P_E1_gauge'].get(n,{}),physical['P_E1_scalar'].get(n,{}))
   d[643+n]=w.scale(e,J.constant((-1)**J.parity(n)))
  out[label]=d
 return out,states,physical
def compose_prefix(P,outer,cache,mode='actual'):
 out={};journal=[]
 for at,(ww,c) in enumerate(sorted(P.items())):
  pref=0
  for pos,(n,js) in enumerate(ww):
   rest=ww[:pos]+ww[pos+1:];why=reason(rest)
   if why:journal.append([at,pos,why]);pref+=J.parity(n);continue
   if mode=='no_sources' and n>=643:journal.append([at,pos,'CONTROL_OUTER_SOURCE_OMITTED']);pref+=J.parity(n);continue
   key=n,js,mode
   if key not in cache:
    flow=outer[n]
    if mode=='linear_Ja' and 1241<=n<1286:flow={word:cc for word,cc in flow.items() if all(not 508<=nn<553 for nn,jj in word)}
    cache[key]=J.Ds(flow,js)
   delta=cache[key]
   if not delta:journal.append([at,pos,'ZERO_PROJECTED_OUTER_FLOW']);pref+=J.parity(n);continue
   term=J.mul(J.mul({ww[:pos]:c*((-1)**pref)},delta),{ww[pos+1:]:J.constant(1)});chosen=project(term);J.add(out,chosen);journal.append([at,pos,'MULTIPLIED_AND_PROJECTED',len(term),len(chosen)]);pref+=J.parity(n)
 return J.clean(out),journal
def compose_LEFT(P,outer,cache):
 eligible={};kept=[];bad=[]
 for at,(ww,c) in enumerate(sorted(P.items())):
  if any(reason(ww[:pos]+ww[pos+1:]) is None for pos in range(len(ww))):eligible[ww]=c;kept.append(at)
  else:bad.append(at)
 tokens=sorted({t for ww in eligible for t in ww});out={};parts=[]
 for n,js in tokens:
  partial=project(J.leftjet(eligible,(n,js)))
  if not partial:parts.append([n,list(js),'ZERO_PROJECTED_LEFT_DERIVATIVE']);continue
  key=n,js,'actual'
  if key not in cache:cache[key]=J.Ds(outer[n],js)
  delta=cache[key]
  if not delta:parts.append([n,list(js),'ZERO_PROJECTED_OUTER_FLOW']);continue
  prod=J.mul(delta,partial);chosen=project(prod);J.add(out,chosen);parts.append([n,list(js),'MULTIPLIED_AND_PROJECTED',len(prod),len(chosen)])
 return J.clean(out),dict(eligible_original_indices=kept,rejected_original_indices=bad,left_partial_dispositions=parts)
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
   p=str(Path(os.fsdecode(args[0])).resolve());assert not any(t in p for t in ['known_consistency_images','consistency_tables.json','hard_response_v2.json']), 'CONSISTENCY_REMAINDER_INPUT_DENIED'
 sys.addaudithook(guard)
 base=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';pn=load(base/'native_inputs.json.gz');pr=load(base/'replay_inputs.json.gz');assert pn==pr
 native,states,physical=full_maps(pn);replay,_,_=full_maps(pr);assert native==replay;projected={};flowrows=[];typecounts={}
 for label,maps in native.items():
  dd={};counts=Counter()
  for n in range(1286):
   P=maps[n];keep=[];reject=defaultdict(list)
   for at,(ww,c) in enumerate(sorted(P.items())):
    assert all(i<1286 for i,js in ww),'UNKNOWN_COORDINATE_TYPE'
    assert sum(ghost(i) for i,js in ww)==ghost(n)+1 and sum(J.parity(i) for i,js in ww)%2==(J.parity(n)+1)%2
    intrinsic=1+J.dimension(n)-sum(J.dimension(i)+len(js) for i,js in ww);assert intrinsic in [0,1],(label,n,intrinsic);counts[intrinsic]+=1;why=reason(ww)
    if why:reject[why].append(at)
    else:keep.append(at)
   dd[n]=project(P);flowrows.append(dict(operator=label,coordinate=n,full_math_sha256=sha256(json.dumps(J.encode(P),sort_keys=True).encode()).hexdigest(),kept_original_indices=keep,rejected=[dict(reason=k,original_indices=z) for k,z in sorted(reject.items())],selected=J.encode(dd[n])))
  projected[label]=dd;typecounts[label]=dict(counts)
 # Physical premises are checked at their actual scope before exclusions.
 for label in ['Fu0_0','Fu0_1','Fu1_0','Fu1_1']:assert all(not states[label][n] for n in range(508))
 for n in range(180,508):
  assert not states['F0'][n]
  for ww in states['F1'][n]:assert len(ww)==2 and sum(180<=i<508 for i,js in ww)==1 and sum(553<=i<598 for i,js in ww)==1 and all(not js for i,js in ww)
 for label,rows in physical.items():
  for n,P in rows.items():assert not project(P)
 for label in ['Q0','Qu0_0','Qu0_1']:
  assert all(not any(823<=i<1151 for i,js in ww) for P in native[label].values() for ww in P),'UNEXPECTED_PHYSICAL_SOURCE_IN_G0_MAP'
 cases=[('original_g0',[('Q0','Q0')]),('original_g1',[('Q0','Q1'),('Q1','Q0')])]
 for prb in [0,1]:cases += [('probe'+str(prb)+'_g0',[('Q0','Qu0_'+str(prb)),('Qu0_'+str(prb),'Q0')]),('probe'+str(prb)+'_g1',[('Q0','Qu1_'+str(prb)),('Qu1_'+str(prb),'Q0'),('Q1','Qu0_'+str(prb)),('Qu0_'+str(prb),'Q1')])]
 cache={label:{} for label in native};allrows=[]
 for case,branches in cases:
  coords=[];nonzero=control_sources=control_Ja=outside=0
  for n in range(1286):
   full={};left={};no_sources={};linear={};journal=[]
   for outer,inner in branches:
    P=native[inner][n];p,pj=compose_prefix(P,projected[outer],cache[outer]);q,qj=compose_LEFT(replay[inner][n],projected[outer],cache[outer]);assert p==q,(case,n,outer,inner);bad,bj=compose_prefix(P,projected[outer],cache[outer],'no_sources');lin,lj=compose_prefix(P,projected[outer],cache[outer],'linear_Ja');J.add(full,p);J.add(left,q);J.add(no_sources,bad);J.add(linear,lin);journal.append(dict(outer=outer,inner=inner,prefix_positions=pj,LEFT=qj,no_sources_positions=bj,linear_Ja_positions=lj))
   full=J.clean(full);left=J.clean(left);no_sources=J.clean(no_sources);linear=J.clean(linear);assert full==left
   dims=Counter()
   for ww,c in full.items():
    assert sum(ghost(i) for i,js in ww)==ghost(n)+2 and sum(J.parity(i) for i,js in ww)%2==J.parity(n)%2
    intrinsic=2+J.dimension(n)-sum(J.dimension(i)+len(js) for i,js in ww);dims[intrinsic]+=1
    if intrinsic not in [0,1]:outside+=1
   if full:nonzero+=1
   if no_sources!=full:control_sources+=1
   if linear!=full:control_Ja+=1
   coords.append(dict(coordinate=n,branches=journal,selected_square=J.encode(full),selected_square_intrinsic_counts=dict(dims),no_sources_square=J.encode(no_sources),linear_Ja_square=J.encode(linear)))
  art=save('square_'+case+'.json.gz',dict(case=case,branches=branches,all1286_coordinate_dispositions=coords,physical_unknown_inner_E1_x_variation_excluded_by_Q0_Qu0_support=True,outer_potential_tadpole_intrinsic3_outside01=True))
  row=dict(case=case,nonzero_selected_coordinates=nonzero,outside01_residual_terms=outside,no_source_control_changed_coordinates=control_sources,linear_Ja_control_changed_coordinates=control_Ja,artifact=art);allrows.append(row);print('STAGE '+json.dumps(row,sort_keys=True),flush=True)
 art=save('full_primitive_flow_projections.json.gz',dict(full_field_source_pairs=1286,primitive_type_counts=typecounts,all_primitive_maps=flowrows,known_physical_kinetics_included_before_inner_variation=True,unknown_full_physical_E1_x_not_zeroed=True))
 result=dict(schema='ACTUAL_SELECTED_BV_SQUARE_G1_U1_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',cases=allrows,flow_projections=art,all_selected_squares_zero=all(not q['nonzero_selected_coordinates'] for q in allrows),all_native_prefix_LEFT_compositions_equal=True,scope='Upper Lambda1 C2, source0 A0 intrinsic01, formal mean-series coefficients; physical support exclusions explicit.',no_missing_aCC_coefficient_reconstructed=True,no_WZ_reference_limit_or_full_nilpotency_adoption=True,elapsed_after_imports=time.perf_counter()-tick)
 dump(O/'square_result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
