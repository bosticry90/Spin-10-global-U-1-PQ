# Final selected BV square validation

One360s after-import worker,8GiB sampled private/350MiB launch floor,
64MiB packet/10MiB artifact. Freeze source/proof/result/handoff before
execution. Authenticate V1 failure and V2 complete capture/resource bounds;
V1 NameError remains FAILED NOTPASS, not a calculation of the square.

Freshly rebuild full native/replay1286 maps, include known physicalkinetic
INNER maps, verify fullprimitive types and every original indexprojection.
Reexecute all19290branch/port compositions with oddprefix and LEFT methods,
compare every saved position/LEFTpartial disposition, complete squared
polynomials and both control polynomials. Check7716coordinatezeros and
actual sensitive/blind countpatterns; preserve physicalsupport ceilings.
No quantumcoefficient or WZ/reference-limit/source-independence claim.

E4 exactlyonce,no--fresh existingDcontext, savefullstdout/stderr before
assertions. Expected0,0,0,0,0,2 with exactlyseven custodyNOTPASS. Verifyold
trackedGitmode/blobs/workingbytes andstateSHA. Receiptvalidatesbounded
evidenceonly; no physicaltruth,promotion,restoration,E5/A5 or goalcompletion.
