# Selected canonical BV square: actual field/source verification

This is a prerequisite audit for the remaining aCC/source-consistency problem,
not a measurement of a missing loop coefficient. V811 owns the actual two
response operators for72 M paths. Before expanding them, this calculation
tests whether the specific classical operator algebra needed for an eventual
integrability identity is valid. No known LambdaCC remainder or unknown aCC
target is an input; the worker denies reads of those result containers.

## Domain and actual operators

Original unshifted Euclidean A0,g0/g1,firstu H/M,intrinsic polynomial degree
0/1; upper means Lambda<=1,C<=2, all other means and BV sources zero. The
full643 field maps and643 canonical source maps come from authenticated native/
replay V802 source-first F/E inputs. Physical kinetic E0 at all508 ports is
included in INNER source maps before variation. Known physical g1 gauge/
scalar E1_B maps are included too. All original source derivatives and Euler
operations were performed before any new mean-plane restriction.

Qphi=F, QJ=(-1)^p E with actual field parity p. In particular QJa=-E_a;
neither its boxC part nor nonlinear Lambda-C part may be discarded. The full
primitive maps pass ghost+1,odd-parity and dimension+1/intrinsic01 checks at
every original word. This test uses continuum differential JETS with ordinary
Leibniz, not V811's finite diagnostic D matrix.

The square coefficients are Q0Q0;Q0Q1+Q1Q0;Q0Qu0+Qu0Q0; and
Q0Qu1+Qu1Q0+Q1Qu0+Qu0Q1, separately at each probe. Every1286 output
coordinate is computed in all6 cases:7716 complete coordinate squares and
19290 branch/coordinate compositions. The output is NOT stipulated zero.

## Safe selection after source operations

Each single Q variation replaces one token. Every untouched token must
already belong to the declared mean profile for its product to survive.
Thus a word with more than one forbidden factor cannot contribute, and
rest Lambda/C counts cannot already exceed1/2. Complete original word and
position dispositions are retained, including those rejected by this exact
necessary condition. Inner source terms are not set zero at their original
mean values: a source can be removed by the Q variation and contribute.

The last outer source-derived flow may be projected before its ordinary jet
derivatives because D preserves field identities/counts. This is different
from commuting a source derivative with mean selection, which is not done.
The entire inner map is retained until the one-token support proof applies.
Native odd prefix replacement is compared against the independent LEFT rule

    QP=sum_(n,jets) D_jets(Qn) LEFTpartial_(n,jets)P,

with varied flow on the LEFT. Actual/LEFT complete results agree before
their case sums. No equation of motion, p2=0, IBP normal or desired sum is
used to erase a residual. Every selected square is POINTWISE zero in the
jet algebra, before any intrinsic residual could be discarded.

## Physical and omitted-component support

Known physical kinetic E0 is varied inside the calculation; its Maxwell
gradients cancel under Q0_B=partial C rather than being removed by their
original B=0 value. All actual physical kinetic E0 and known physical E1_B
maps have zero OUTER projection on the selected mean plane.

Unknown full physical E1_x is not assigned zero. The physical kinetic g1
scalar action has B*x*partial x form; its scalar Euler contains a physical
B and scalar. Q0 may remove the B but leaves that scalar, while Q0x=0.
Physical potential/scalar-only terms vary to zero under Q0. Qu0 has zero
physical field flows on every physical port, so it annihilates the entire
source-free physical E1_x before projection. These are precisely the outer
operations acting on the omitted inner Q1 physical E1_x in the tested
square coefficients. Physical E0 potential terms are also source-free;
Q0x=Qu0x=Qu1x=0 and actual F1x is source-free x*C, so its varied terms
retain a scalar mean. Each statement is scoped to the original unshifted A0.

For an outer potential gradient, all nonconstant pieces retain a scalar
mean. A possible tadpole coefficient has intrinsic3 and is outside the
declared01 polynomial domain; it is not silently set to zero or adopted.
The known GF scalar-source intrinsic1 contributions ARE retained. No inverse
dimensionful physical parameter is admitted to lower an excluded degree.
These are explicit support/degree exclusions, not execution of unavailable
physical E1_x or potential coefficients. Shifted backgrounds, intrinsic2+,
nonpolynomial parameter normalizations and broader physical targets need
their own review.

The CPS P=S=K ideal remains stable under the listed nonminimal/ghost/source
operations; omitted fermion components retain a fermion mean at this plane.
No unrestricted chiral master, anomalous measure, phase, quantum action
principle or global Qfull-square-zero theorem follows from that support.

## Results and sensitive controls

| case | selected nonzero coordinates | omit outer sources: changed | linearize outer Ja: changed |
|---|---:|---:|---:|
|originalg0|0|90|33|
|originalg1|0|244|32|
|H probe g0|0|84|0|
|H probe g1|0|176|0|
|M probe g0|0|264|231|
|M probe g1|0|444|232|

All7716 actual selected coordinate squares vanish. Source omission is
sensitive in every case. The nonlinear-Ja control is blind in the H-probe
cases and sensitive in the others; those blind zeros are not extra evidence.
Full control polynomials, positions and LEFT derivative dispositions are
preserved, not only counts. All known primitive maps have intrinsic0/1;
no residual outside that range is hidden by a final filter.

The nonzero projected primitive coordinate groups are:

| operator | nonzero groups |
|---|---|
|Q0|B180,a45,JB180,JLambda45,Ja45|
|Q1|Lambda32,C45,Jx200|
|Qu0_H|a12,JB48,JLambda12|
|Qu0_M|a33,JB132,JLambda33,Ja33|
|Qu1_H|none|
|Qu1_M|Jx200|

These are computational support counts, not physics parameters or progress
percentages. Notably the scalar-source channel remains in Q1/Qu1. The full
Q0/Qu0 primitive maps are Jx-free, but source independence of the actual
proper Gamma functionals has NOT been proved by that fact alone.

## Mathematical ceiling and next discriminating step

The square of an odd derivation is an even derivation; paired second
functional derivatives cancel in its graded chain rule. A coefficient
vanishing in this upper mean profile cannot feed the target by multiplying
a formal functional derivative with nonnegative mean/source powers. This
explains why the selected generator test is relevant to Q Delta=Q2 Gamma.
It does not by itself establish every hypothesis of that quantum statement.

Before reconstructing any aCC reference from a consistency equation, prove
the required source independence of g0 Gamma/Delta from the actual source
action and fixed regulator; audit carrier completeness by field support
without extending a local Lorentz census to nonlocal kernels; justify the
selected functional identity and its source-test distribution domain; and
show how the common UV/IR reference prescription commutes with the required
operations. A later integrability prediction would be DEPENDENT on those
premises and the already measured inputs, not a new independent loop
measurement. No coefficient is solved from the known remainder here.
The direct two-response color/momentum/limit calculation remains required
as an independent check before claiming source compatibility/restoration.

V1 failed before loading algebra inputs: a missing sys import at the audit
hook. Source/preparation/full capture remain FAILED NOTPASS. New V2 changes
only that import and own filenames, reruns the entire scientific test, and
completes178.638s under its180s bound. Final validation freshly reexecutes
all primitive projections, branches, both algorithms and controls; E4 runs
once with custody exit2/seven unresolved NOTPASS. Sources/captures are
immutable. Shared action/chart/ring/helpers/AI author limit independence.
No empirical test, Lean kernel proof or new benchmark platform is claimed.

State113/34of39,E5/A5 remain unchanged. No normalization, physical benchmark,
foundational assumption, background or protected gate is adopted/promoted.
Common restoration, source products, QAP, measure/reality, equivalence,
physical viability and full investigation completion remain open.
