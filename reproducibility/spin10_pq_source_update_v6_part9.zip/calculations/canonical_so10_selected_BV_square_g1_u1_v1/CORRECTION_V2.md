# Missing audit-hook import correction V2

V1 FAILED exit1 at sys.addaudithook: sys was not imported. This occurred
after frozen-hash checks, before loading the algebra inputs or performing
any composition. Exact source/preparation/capture remain FAILED NOTPASS.

V2 adds only that missing standard-library import and separate preparation/
output filenames. All RECORD types, physical exclusions, full source maps,
native/LEFT derivations, controls and180s/8GiB/350MiB/64MiB/10MiB bounds
are unchanged. No scientific requirement/input is altered. This is a new
bounded harness correction, not retrospective authorization or old PASS.
