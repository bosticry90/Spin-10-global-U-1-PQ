# V960 result — matched reference roots remove the extra scalar switch power

The light-quartet mixed and scalar reference
contributions cancel in pairs. The broken-quartet
differences are exactly the two ordinary mixed
scalar triangle color directions, separately for
light and broken ordinary BB.

On the selected local derivative jet their
matched radial primitive retains the positive
scalar mass and all three profiles. The compact
master subtraction converts each ordinary
s^4 term to s^3 at its own weight. This does not
require equal light and broken weights and
accounts for the scalar plateau mismatch of
the isolated V956 class.

The resulting s^3 coefficient still needs the
unit finite matching equation. Independent
external momenta, nonconstant switch derivatives,
gauge and marked products and actual unmatched
profiles remain open. Both routes share the model,
conventions and software. No coefficients adopted.
