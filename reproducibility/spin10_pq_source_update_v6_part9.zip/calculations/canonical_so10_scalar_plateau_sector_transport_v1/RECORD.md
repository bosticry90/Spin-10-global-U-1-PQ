# V960 pre-execution contract

Compare the complete V959 reference-root pair to the
ordinary V949 mixed scalar triangle on the selected
local degree-two constant-plateau jet. Freeze the
ordered compact master subtraction, the shared
within-quartet mixed/ghost profiles and the common
ordinary BB and scalar profiles for each pair.
Allow different H and M ordinary gauge weights.

Verify the sector color pairing, the common retained
massive radial primitive, and the compact power
identity independently of any unit finite fit.
Do not assert equality of full nonlocal kernels
or choose a finite normalization. Native 120 s,
final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and
32 MiB packet. No authority change.
