# Sectorwise transport of the scalar plateau mixed term

Use the V959 ordered opposite-sign pair of mixed and
scalar reference roots. Re-index W by ordinary BB sector
and mixed quartet, in the same order as R by ordinary BB
and ghost. The light-quartet sectors cancel pairwise:
HH and MH give zero. For the broken quartet the two
differences are

    (R-W)_HM = C_H|M/2 = T_H,
    (R-W)_MM = -4 P_H+C_H|H/2 = T_M.

These are exactly the ordinary V949 mixed scalar
triangle colors for ordinary BB in H and M,
respectively. They have disjoint color support.
Equality of the two sector weights is therefore
not needed for the plateau transport.

Keep the local coefficient with exterior derivatives
on C and the other scalar. In the mixed reference root,
projection of its differentiated Lambda onto the ordinary
BB line leaves the external ghost derivative. The
mixed Bxx endpoint contracts the opposite hard
scalar momentum with its mixed numerator.
At the scalar reference root the internal scalar
and ghost derivatives instead contract opposite
hard momenta. After extracting the exterior jets,
write Q for the common hard squared momentum.
Both roots and the ordinary mixed scalar triangle
leave the same scalar factor Q F_s/(Q+M).
The remaining edges contribute F_B/Q and F_L/Q,
or F_B/Q and F_ghost/Q. When mixed and ghost profiles
match in the paired quartet the full selected
radial primitive is therefore

    F_B F_s F_L / [Q (Q+M)].

The angular projector is common. This preserves
the massive remainder of V955. The calculation
does not identify off-diagonal exterior placements
or nonconstant switch derivative terms.

Let w_H and w_M denote the signed ordinary mixed
triangle weights in the V956 scalar convention.
At each nonzero plateau s, the ordinary mixed
master variation is 2 s^4 w_i rho(T_i b).
With the reference-master sign from V959 and the
ordered compact subtraction
B'_P[N]-N'_P[B[P]], the corresponding normalized
reference term is -2 s^3(1-s) w_i rho(T_i b).
Subtracting it gives 2 s^3 w_i rho(T_i b), separately
for each sector. Thus this matched reference term
removes the extra switch power of the isolated
V956 scalar triangle on the selected jet.

The surviving expression still contains the unit
finite matching equation. The H/M gauge profiles
can give different absolute weights; the scalar
mass and free heat lengths must be retained.
Different ordinary H/M lengths alone give the
relative logarithmic constant of V947 with total
three-edge lengths. Compact exterior switch terms,
the gauge and marked equations and the general
common normalization remain open. Both routes
share model, conventions, software and authorship.
