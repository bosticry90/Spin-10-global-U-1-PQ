"""Check sectorwise scalar plateau transport and retained massive profile."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)


def check(phase):
    _, _, _, f, _, _ = source.owner.inputs(phase)
    C = defaultdict(lambda:sp.S.Zero)
    for h in range(12):
        for b in range(45):
            for k,x in f[h,b]:
                for a,y in f[h,k]:
                    C[a,b] -= x*y
    C = source.owner.clean(C)
    Ch = {(i,j):z for (i,j),z in C.items() if i<12 and j<12}
    Cm = {(i,j):z for (i,j),z in C.items() if i>=12 and j>=12}
    H = {(i,i):sp.S.One for i in range(12)}
    M = {(i,i):sp.S.One for i in range(12,45)}
    I = source.add(H,M)
    h = source.add({},Ch,sp.Rational(1,2))
    m = source.add({},Cm,sp.Rational(1,2))
    W = [h,m,m,source.add(source.add(source.add({},I,4),h,-1),Cm,-1)]
    R = [h,Cm,m,source.add(source.add({},M,4),Cm,-1)]
    delta = [source.add(a,b,-1) for a,b in zip(R,W)]
    TH, TM = m, source.add(h,H,-4)
    assert delta == [{},TH,{},TM]
    assert TH and TM and not (TH.keys() & TM.keys())

    # After external derivatives are extracted, neither of the
    # compensating roots permits dropping the massive remainder.
    Q, mass, FB, FS, FL = sp.symbols("Q M F_B F_s F_L",positive=True)
    scalar = FS/(Q+mass)
    mixed = FL/Q
    ghost = FL/Q
    BB = FB/Q
    mixed_numerator = Q*scalar
    scalar_root_numerator = -(-Q)*scalar
    ordinary_weight = BB*mixed*mixed_numerator
    W_weight = BB*mixed*mixed_numerator
    R_weight = BB*ghost*scalar_root_numerator
    assert sp.cancel(W_weight-R_weight) == 0
    assert sp.cancel(W_weight-ordinary_weight) == 0
    assert sp.diff(ordinary_weight,mass) != 0
    assert sp.cancel((ordinary_weight-BB*mixed).subs(FS,1)) != 0

    s,wH,wM = sp.symbols("s w_H w_M")
    total = source.add(source.add({},TH,wH),TM,wM)
    ordinary = source.add({},total,2*s**4)
    insertion = source.add({},total,-2*s**3*(1-s))
    reduced = source.add(ordinary,insertion,-1)
    assert reduced == source.add({},total,2*s**3)
    assert source.add(ordinary,reduced,-1)
    return {"light_ghost_pairs_cancel":True,"surviving_pair_maps":["C_H|M/2","-4 P_H+C_H|H/2"],
            "matched_selected_radial_primitive":"F_B*F_s*F_L/(Q*(Q+M))",
            "compact_triangle_power_before_after":[4,3],
            "cancellation_allows_distinct_H_M_weights":True,
            "unit_finite_matching_remains_required":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
