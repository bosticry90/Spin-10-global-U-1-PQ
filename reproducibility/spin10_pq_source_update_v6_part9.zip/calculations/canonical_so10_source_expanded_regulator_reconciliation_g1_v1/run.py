from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/source-expanded-regulator-reconciliation-g1-v1-2026-11-07')
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
role=sys.argv[1];assert role in ['native','replay'];assert not (O/(role+'_capture.json')).exists()
if not (O/'preparation.json').exists():
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='ff3bb4db8f6de09da0441643c92f2933149a5c99'
 names=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V797.md','calculations/canonical_so10_gaussian_current_reduction_g1_v1/validation_receipt.json','calculations/canonical_so10_gaussian_current_reduction_g1_v1/native_hessian_euler_rows.json.gz','calculations/canonical_so10_regulator_vertices_g1_recovery_v1/validation_receipt.json','calculations/canonical_so10_regulator_vertices_g1_recovery_v1/roots.py','calculations/canonical_so10_regulator_source_colors_g1_recovery_v1/validation_receipt.json','calculations/canonical_so10_vector_mixed30_g1_recovery_v1/validation_receipt.json','calculations/canonical_so10_full_current_inventory_g1_recovery_v1/validation_receipt.json']
 for a in ['native','replay']:
  names+=['calculations/canonical_so10_full_current_inventory_g1_recovery_v1/'+a+'_units_source_'+c+'.json.gz' for c in ['original','probe0','probe1']]
  names+=['calculations/canonical_so10_full_current_inventory_g1_recovery_v1/'+a+'_raw_T1_factors.json.gz','calculations/canonical_so10_regulator_source_colors_g1_recovery_v1/'+a+'_matrices.json.gz','calculations/canonical_so10_regulator_vertices_g1_recovery_v1/'+a+'_catalog.json.gz','calculations/canonical_so10_regulator_vertices_g1_recovery_v1/'+a+'_root_assemblies.json.gz']
 for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
 for n in ['RECORD.md','compare.py','run.py']:
  if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
  with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
 dump(O/'preparation.json',dict(base_HEAD=head,input_sha256={n:digest(R/n) for n in names},source_sha256={n:digest(O/n) for n in ['RECORD.md','compare.py','run.py']},scientific_acceptance='NOT_PERFORMED'))
 C.mkdir(parents=True,exist_ok=False)
 with (C/'old_git_tree.txt').open('xb') as h:h.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compare.py'),role]);dump(O/(role+'_capture.json'),cap);dump(C/(role+'_capture.json'),cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
