# Expanded source covariance equals the retained regulator expression

The selected V789 expanded source covariance and V793 finite regulator
expression are reconciled in the original unshifted Euclidean A0,
proper one-loop, first constant-u,g1,intrinsic01 domain. This is a finite
Gaussian coefficient identity, followed by reuse of the qualified ordered
reference. It is not a continuum QAP or an E5/A5 acceptance statement.

## Literal coefficient comparison

Source differentiation and full T1 construction have already occurred
before either comparison route restricts the means or quantum ends.
Native reads the saved V789 nonzero unit products, their exact kept-row
indices and complete branch/field dispositions. Replay independently
multiplies the qualified full raw T1F1 and T1E0/Eu0 factors after the safe
nonnegative factor-budget filter. Neither reads the other's new outputs.

On the returning M ghost block, define the actual D_c,A_c,M_b,N_s from
V793. Coefficients D,A have g stripped; it is restored in the comparison.
The quantum coefficients are LEFT of eta:

    T1F1_C_r = g sum D_c[r,i] C_c etaC_i,
    T1F1_a_r = g sum A_c[r,i] C_c etaa_i.

The original field Euler tangents relevant to these ghost ends are

    T1E0_C_r = sum_mu partial_mu^2 etaa_r
                    +sum M_b[r,j] Lambda_b etaa_j,
    T1E0_a_r = -sum_mu partial_mu^2 etaC_r
                    +sum M_b[r,j] Lambda_b etaC_j.

The Ja source companions are respectively N_s Ja_s etaa and N_s Ja_s
etaC, with the actual N_s=-2i Pi_s M_s. These signs follow the LEFT
Euler derivative of a^T(K+Lambda M+u Ja N)C, K=-partial^2. They are
tested against literal products, rather than inferred from the answer.

Both routes match EVERY coefficient of the compact products to the
literal selected F1 ghost current: original 22748 terms (all four kinetic
jet components and Lambda roots), H-probe Ja part zero, M-probe Ja part
17676. The two complete mathematical files, including exact expected
and actual polynomials, agree byte-for-byte. Omitting A changes6628
original and5292 M-probe terms; the H-probe control is blind and recorded.
Both zero and nonzero operator entries are tested through the polynomial
equality. This is new expanded-current evidence, not a factory rerun or
an amplitude inferred from a path count.

## Connecting the literal twelve-word source sector

The complete V789 source catalog has12 labeled M words and no H words.
Its coarse marked classes combine terms from different underlying flows.
They therefore cannot be compared one for one to V792's8 regulator
words. Use the actual flow decomposition before a Gaussian trace.

The qualified V790 operator bridges identify each complete T1E column
with the actual Hessian Euler column; every own-jet diagonal in all six
flow maps is zero. The finite Gaussian integration-by-parts identity
holds separately for each flow coefficient P=T1F:

    <P Hphys> = local_Jacobian - <P R>.

This is applicable to the saved literal V789 products because their
full branch sums and the Hessian bridge have owning receipts. The
whole free2368-term divergences are retained with their explicit
currents and removed only in the existing integrated constant-mark
domain; no individual free factor is set to zero in this argument.

V792's full F0 regulator polynomial has1440 terms before graded exchange.
Its entire integrated root is zero under l=-k, with matching even profiles.
This is a local quadratic root identity BEFORE any ordinary inverse
expansion. Consequently every F0 contribution to the selected source
covariance cancels in the whole Gaussian, including its GFg1 companions.
Those companions can occupy the same coarse marked class as F1 and are
not dropped from a literal product. The qualified zero Jacobian and whole
regulator identity prove the cancellation instead.

The complete bounded V792 source catalog then excludes Fu0,Fu1 and all
non-ghost F1 source contractions, at both probes, without a limit or
coefficient fit. Every surviving source word is original F1, internal M
ghost/antighost, with mean C at the root and the original Lambda mass and
probe Ja mass as the two ordinary insertions. Scalar/physical owners do
not return. This exact support result, used with the separate-flow
Gaussian identity, reduces the FULL source covariance to the F1 ghost
part explicitly compared above. It is not a claim that each of the other
expanded marked words vanishes separately. H probe has no source words
at all, so the necessary-support zero is stronger than a restricted-M
matrix observation.

At this coefficient g is already spent by F1. The original ghost Hessian
is therefore K+Lambda M, and the only u insertion supplying Ja is N Ja.
Other U0 roots without Ja cannot acquire Ja at g0 from an ordinary vertex;
the original Ja-Lambda term is linear in fluctuations. The existing
complete source catalogs verify these coupling and endpoint exclusions.

## Exact ordered inverse identity and finite source expression

Write Hphys=K+L+uN, L=Lambda M, N=Ja N_s,
G=(F^-1 K+L+uN)^-1 and R=(F^-1-1)K. Background multiplications do
not commute with F or R. LEFT normalization gives the expanded F1
ghost current

    +Tr[D C G Hphys]+Tr[A^T C Hphys G].

Since G Hphys=I-GR and Hphys G=I-RG, its Lambda Ja coefficient is
EXACTLY

    -Tr[D C G R]-Tr[A^T C R G].

The coefficient of the identity term has only C and is zero in the
selected Lambda Ja slot. No cyclic move interchanges R with C.
With G0=F K^-1,
G_L=-G0 L G0,G_N=-G0 N G0,
G_LN=G0 L G0 N G0+G0 N G0 L G0, the separate operator identities are

    G_LN K+G_L N+G_N L = -G_LN R,
    K G_LN+L G_N+N G_L = -R G_LN.

Thus the kinetic marked roots and marked mass roots cancel their
appropriate adjacent inverse parts before any integration. Both ordinary
orders and both root placements remain. Transposing the second term
reverses the two skew mass insertions, yielding D+A as in V793.

An exact12-coordinate rational fixture checks both operator identities,
then computes the full expanded current, regulator current and D+A
combination as238i/2025. Fails-to-commute profile/background matrices
are present. D+A^T gives-238i/6075; an actual wrong root ordering gives
238i/6075; omitting marked mass roots gives-238i/675. All are sensitive.
The first test version mistakenly called a LEGAL cyclic rotation a
wrong-order control; the physical identities passed but that control was
blind and the run is preserved FAILED. V2 changes only the mistaken
control, retaining all requirements, inputs and resource bounds.

The resulting finite expression is exactly the V793 source kernel:
with p(C)+k(Ja)+e(Lambda)=0 and its actual color T,

    current_source = T [K_e-K_k],
    K_e=integral (1-F(q)) G_F(q+e)G_F(q-p) d4q/(2pi)^4,
    K_k=integral (1-F(q)) G_F(q+k)G_F(q-p) d4q/(2pi)^4.

The original F=fE and all inverse IR defects remain. These finite
kernels are generically unequal. V793's paired joint Schwartz proof
applies to this identical finite expression, giving reference ZERO in
the original UV-first then IR order. This is now a qualified transfer
through the explicit literal-operator and exact inverse bridges, not a
transfer based on the common1126 color count or a vanishing classical
functional. No changed physical parameters or normalization are chosen.

## Significance and limitations

This closes the selected expanded SOURCE covariance reconciliation. It
does not compare every106 expanded VECTOR word to the46 evaluated
regulator words, nor open a QGamma/D target automatically. That vector
comparison is the next necessary task. Common normalization/reality,
QAP, measure/equivalence and full E5/A5 acceptance remain open.

The full-literal and factor-product routes expose selection/product and
normal-order mistakes; the finite inverse identities and sensitive
controls test the contraction/order bridge. Some Euler/ring software,
action, chart, qualified data and AI author remain shared. The blind
cyclic control illustrates a concrete AI test-design failure. These are
bounded mathematical results, not independent scientists, a formal
proof kernel or empirical evidence. No director education requirement.
