from pathlib import Path
from hashlib import sha256
import json,os,threading,time
import sympy as s
O=Path(__file__).resolve().parent
def main():
 tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in json.loads((O/'analytic_preparation_v2.json').read_bytes())['source_sha256'].items():assert sha256((O/n).read_bytes()).hexdigest()==h,n
 hv=s.Matrix([1,2,3,4]);U=s.eye(4)-2*hv*hv.T/(hv.dot(hv));j=s.Matrix([[0,1],[-1,0]])
 deriv=U*s.diag(j,2*j)*U.T;profile=U*s.diag(s.Rational(1,2),s.Rational(1,2),s.Rational(2,3),s.Rational(2,3))*U.T
 kron=s.kronecker_product;K=kron(s.eye(3),-deriv*deriv);F=kron(s.eye(3),profile);G=F*K.inv();R=(F.inv()-s.eye(12))*K
 eps=lambda c:s.Matrix(3,3,lambda a,b:s.LeviCivita(c,a,b))
 C=kron(s.eye(3),s.diag(-2,1,2,4));L=kron(eps(0),s.diag(2,-1,3,1));N=-2*s.I*kron(eps(1),s.diag(1,3,-2,4));D=kron(eps(2),s.eye(4));A=2*D
 GL=-G*L*G;GN=-G*N*G;GLN=G*L*G*N*G+G*N*G*L*G
 assert GLN*K+GL*N+GN*L==-GLN*R,'RIGHT_DYSON_ORDERED_COEFFICIENT'
 assert K*GLN+L*GN+N*GL==-R*GLN,'LEFT_DYSON_ORDERED_COEFFICIENT'
 direct=s.trace(D*C*(GLN*K+GL*N+GN*L))+s.trace(A.T*C*(K*GLN+L*GN+N*GL))
 regulator=-s.trace(D*C*GLN*R)-s.trace(A.T*C*R*GLN)
 combined=-s.trace((D+A)*C*GLN*R)
 wrongA=-s.trace((D+A.T)*C*GLN*R)
 wrongR=-s.trace(D*C*R*GLN)-s.trace(A.T*C*R*GLN)
 wrongmass=s.trace(D*C*GLN*K)+s.trace(A.T*C*K*GLN)
 assert direct==regulator==combined and direct!=0,('FULL_EXPANDED_SOURCE_DYSON',direct,regulator,combined)
 assert all(z!=direct for z in [wrongA,wrongR,wrongmass]),('CONTROL_BLIND',direct,wrongA,wrongR,wrongmass)
 out=dict(schema='EXPANDED_SOURCE_FINITE_DYSON_RECONCILIATION_V2',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',coordinate_size=12,profile_not_commuted_through_mean=F*C!=C*F,all_two_mass_orders_retained=True,left_and_right_Dyson_operator_coefficients=True,direct_expanded_current=str(direct),regulator_current=str(regulator),combined_D_plus_A=str(combined),wrong_D_plus_AT=str(wrongA),wrong_root_commuted_through_C=str(wrongR),omit_marked_mass_roots=str(wrongmass),elapsed_after_imports=time.perf_counter()-tick,not_physical_parameter_point=True)
 with (O/'analytic_result_v2.json').open('x',encoding='utf-8',newline='\n') as h:json.dump(out,h,sort_keys=True);h.write('\n')
 print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
