from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import Counter
import gc,gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
ROLE=sys.argv[1] if __name__=='__main__' else 'native'
sp=importlib.util.spec_from_file_location('source_compact_inputs',O.parent/'canonical_so10_regulator_vertices_g1_recovery_v1/roots.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
J=v.J;A=v.A;w=v.w
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/(ROLE+'_'+name+'.json.gz')).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=128*1024**2
 return dict(file=ROLE+'_'+name+'.json.gz',sha256=sha256(blob).hexdigest(),bytes=len(blob))
def safe(word):
 q=0;cc=ll=jj=0
 for n,js in word:
  if 1319<=n<1962:q+=1;continue
  if 553<=n<598:cc+=1
  elif 508<=n<553:ll+=1
  elif 1241<=n<1286:jj+=1
  else:return False
 return q==1 and cc<=1 and ll<=1 and jj<=1
def chosen(word,case):
 quantum=[n-1319 for n,js in word if 1319<=n<1962]
 if len(quantum)!=2 or not all(565<=n<598 or 610<=n<643 for n in quantum):return False
 means=[n for n,js in word if n<1319]
 cc=sum(553<=n<598 for n in means);ll=sum(508<=n<553 for n in means);jj=sum(1241<=n<1286 for n in means)
 if cc!=1 or cc+ll+jj!=len(means):return False
 return (ll<=1 and jj==0) if case=='original' else (ll==0 and jj==1)
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 prep=json.loads((O/'preparation.json').read_bytes())
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 for n,h in prep['source_sha256'].items():assert digest(O/n)==h,n
 peer=str((O/('replay_' if ROLE=='native' else 'native_')).resolve())
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):assert not str(Path(os.fsdecode(args[0])).resolve()).startswith(peer),'PEER_SOURCE_COMPARISON_READ_DENIED'
 sys.addaudithook(guard)
 p=O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1'
 mats=load(O.parent/'canonical_so10_regulator_source_colors_g1_recovery_v1'/(ROLE+'_matrices.json.gz'))
 D={c:A.decode_matrix(a) for c,a in mats['D']};AA={c:A.decode_matrix(a) for c,a in mats['A']};M={c:A.decode_matrix(a) for c,a in mats['M']};NN=[{c:A.decode_matrix(a) for c,a in row} for row in mats['N']]
 g=J.Coeff([((1,0,0,0),F(1))]);actuals={};journals=[]
 if ROLE=='replay':
  raw=load(p/'replay_raw_T1_factors.json.gz');factors={k:dict(raw[k]) for k in ['F1','E0','Eu0_0','Eu0_1']};del raw;gc.collect()
 for case,right in [('original','E0'),('probe0','Eu0_0'),('probe1','Eu0_1')]:
  out={};ledger=[]
  if ROLE=='native':
   units=load(p/('native_units_source_'+case+'.json.gz'));assert units['all643_field_columns_per_branch'];counts=Counter()
   for unit in units['units']:
    if unit['left']!='F1':counts['other_flow_units']+=1;continue
    assert unit['right']==right
    kept=set(unit['kept_raw_indices']);chosen_indices=[]
    for at,(word,coef) in enumerate(unit['raw_product']):
     if at not in kept:continue
     ww=tuple((n,tuple(js)) for n,js in word)
     if chosen(ww,case):J.put(out,ww,A.decode_coeff(coef));chosen_indices.append(at)
    ledger.append(dict(field=unit['field'],chosen_raw_indices=chosen_indices,upstream_raw_words=len(unit['raw_product']),upstream_left_hash=unit['left_full_factor_hash'],upstream_right_hash=unit['right_full_factor_hash']))
    counts['F1_nonzero_units']+=1;counts['selected_raw_products']+=len(chosen_indices)
   counts['all_branch_field_dispositions']=len(units['units'])+len(units['zero_units']);assert counts['all_branch_field_dispositions']==643*len(units['branches']);del units;gc.collect()
  else:
   counts=Counter()
   for n in range(643):
    left={word:z for word,z in J.decode(factors['F1'][n]).items() if safe(word)};rr={word:z for word,z in J.decode(factors[right][n]).items() if safe(word)}
    product=J.mul(left,rr);selected=[]
    for at,(word,z) in enumerate(sorted(product.items())):
     if chosen(word,case):J.put(out,word,z);selected.append(at)
    ledger.append(dict(field=n,safe_left_terms=len(left),safe_right_terms=len(rr),product_terms=len(product),chosen_product_indices=selected));counts['selected_raw_products']+=len(selected)
  out=J.clean(out);actuals[case]=out;journals.append(dict(case=case,route=ROLE,counts=dict(counts),ledger=ledger))
 print('STAGE '+ROLE+' literal expanded F1 source kernels selected',flush=True)
 expected={};controls={}
 for case in ['original','probe0','probe1']:
  total={};omitA={}
  for kind,mat,start in [('D',D,553),('A',AA,598)]:
   for r in range(12,45):
    flow={}
    for c in range(45):
     for (rr,i),z in mat[c].items():
      if rr==r and i>=12:J.put(flow,((553+c,()),(1319+start+i,())),J.times(g,z))
    if not flow:continue
    euler={}
    if case=='original':
     for mu in range(4):J.put(euler,((1319+(598 if kind=='D' else 553)+r,(mu,mu)),),J.constant(1 if kind=='D' else -1))
     masses=M;meanbase=508
    else:masses=NN[int(case[-1])];meanbase=1241
    for b in range(45):
     for (rr,j),z in masses[b].items():
      if rr==r and j>=12:J.put(euler,((meanbase+b,()),(1319+(598 if kind=='D' else 553)+j,())),z)
    prod=J.mul(flow,euler);J.add(total,prod)
    if kind=='D':J.add(omitA,prod)
  expected[case]=J.clean(total);controls[case]=len(w.plus(expected[case],w.scale(J.clean(omitA),J.constant(-1))))
  assert actuals[case]==expected[case],('LITERAL_FULL_COLOR_F1_SOURCE_OPERATOR_MISMATCH',case,len(actuals[case]),len(expected[case]),len(w.plus(actuals[case],w.scale(expected[case],J.constant(-1)))))
 assert not actuals['probe0'] and actuals['original'] and actuals['probe1'] and controls['original'] and controls['probe1']
 math=save('source_F1_operators',dict(all_four_kinetic_derivative_components=True,internalM_projection_after_full_input=True,kernels={k:J.encode(z) for k,z in actuals.items()},expected_compact={k:J.encode(z) for k,z in expected.items()},omit_A_changed_terms=controls))
 journal=save('route_journal',journals)
 result=dict(schema='EXPANDED_SOURCE_F1_COMPACT_OPERATOR_COMPARISON_V1',route=ROLE,execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',literal_to_compact_all_coefficients_equal=True,terms={k:len(z) for k,z in actuals.items()},omit_A_changed_terms=controls,math=math,journal=journal,finite_Dyson_and_remaining_flow_reconciliation_pending=True,elapsed_after_imports=time.perf_counter()-tick)
 dump(O/(ROLE+'_result.json'),result);print('RESULT '+json.dumps({k:result[k] for k in ['terms','omit_A_changed_terms','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
