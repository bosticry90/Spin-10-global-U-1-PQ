from pathlib import Path
from hashlib import sha256
import ast,json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/source-expanded-regulator-reconciliation-g1-v1-2026-11-07')
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert not (O/'analytic_preparation.json').exists()
assert (O/'native_source_F1_operators.json.gz').read_bytes()==(O/'replay_source_F1_operators.json.gz').read_bytes()
for n in ['analytic.py','run_analytic.py']:
 ast.parse((O/n).read_bytes().decode('utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'analytic_preparation.json',dict(source_sha256={n:digest(O/n) for n in ['RECORD.md','analytic.py','run_analytic.py']}))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'analytic.py')]);dump(O/'analytic_capture.json',cap);dump(C/'analytic_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
