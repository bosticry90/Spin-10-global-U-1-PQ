# Expanded source-current comparison closed in its declared scope

The full selected V789 source covariance agrees with the finite regulator
expression evaluated in V793. The literal F1 ghost current matches the
compact D/A/M/N construction coefficient by coefficient:22748 original,
zero H-probe Ja and17676 M-probe Ja terms, with all four kinetic jets.
Native saved-product and replay full-factor routes agree byte-for-byte.
The owning argument is in [PROOF.md](PROOF.md).

The other actual flow contributions are handled by the qualified whole
F0 regulator-zero, zero own-jet diagonals and complete nonreturning-source
supports, using the finite Gaussian identity separately for each flow.
This reconciles the12 expanded source words with8 regulator words without
pretending they should match one for one or dropping an individual factor.

An exact noncommuting-profile finite Gaussian gives expanded=regulator=
D+A current238i/2025. Three incorrect controls differ. The first control
version failed because its proposed wrong ordering was a legal cyclic
trace rotation; exact source/capture preserved FAILED. Corrected V2
changes only that control. Native8.279705s/replay14.049090s under180s,
analyticV2 .204283s under60s; final180s,8GiBsampled/350MiBfloor/128MiB.

The full finite source kernel T(K_e-K_k) is retained. Its identical paired
joint Schwartz UV-first/IR reference is zero by the qualified V793 proof.
Finite response and its1126 nonzero ordered-color slots are not zeroed.
This is a new explicit bridge to the expanded covariance, not a new loop
integration or a change to the physical normalization.

Final receipt owns validation,E4once/no-fresh Dcontext, oldtree/state and
resource checks. Custody remains exit2/seven unresolved NOTPASS. No
scientific acceptance; state113/34of39,E5/A5 OPEN unchanged. Shared inputs,
helpers and AI author limit independence; the failed cyclic test is a
demonstrated AI test-design error, not a physical contradiction.

Next reconcile the expanded VECTOR106 with the contracted regulator46,
including the new nonzero local response in V797. No QGamma/D target
access before that bridge. Common normalization/reality,QAP,measure/
equivalence,E5/A5/viability and the full investigation remain open.
