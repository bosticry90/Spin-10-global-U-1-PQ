from pathlib import Path
from hashlib import sha256
import gzip,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/source-expanded-regulator-reconciliation-g1-v1-2026-11-07')
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'final_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 prep=read(O/'preparation.json')
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 for n,h in prep['source_sha256'].items():assert digest(O/n)==h,n
 for name in ['analytic_preparation.json','analytic_preparation_v2.json']:
  for n,h in read(O/name)['source_sha256'].items():assert digest(O/n)==h,n
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 a=O/'native_source_F1_operators.json.gz';b=O/'replay_source_F1_operators.json.gz';assert a.read_bytes()==b.read_bytes();data=load(a)
 assert data['all_four_kinetic_derivative_components'] and data['internalM_projection_after_full_input'] and data['kernels']==data['expected_compact']
 counts={k:len(v) for k,v in data['kernels'].items()};assert counts=={'original':22748,'probe0':0,'probe1':17676}
 assert data['omit_A_changed_terms']=={'original':6628,'probe0':0,'probe1':5292}
 native=read(O/'native_result.json');replay=read(O/'replay_result.json');assert native['terms']==replay['terms']==counts
 for case in load(O/'native_route_journal.json.gz'):assert case['counts']['all_branch_field_dispositions']==(1286 if case['case']=='original' else 2572)
 bridge=read(R/'calculations/canonical_so10_gaussian_current_reduction_g1_v1/validation_receipt.json');assert bridge['all_actual_own_jet_diagonals_identically_zero'] and bridge['bridge_rows_total']==4726 and bridge['evidence_validation'].startswith('PASS')
 vert=R/'calculations/canonical_so10_regulator_vertices_g1_recovery_v1';roots=load(vert/'native_root_assemblies.json.gz')['assemblies'];f0=next(z for z in roots if z['state']=='F0' and z['family']=='preference')
 assert f0['raw_monomials']==1440 and f0['free_proof']['whole_free_zero'] and not f0['free_proof']['graded_exchange_at_l_minus_k'] and all(not z['integrated'] for z in f0['projections'].values())
 catalogs=load(vert/'native_catalog.json.gz');assert catalogs['reference_root_excluded_by_whole_local_operator_zero']
 sources=[z for z in catalogs['catalogs'] if z['channel']=='source'];assert [z['probe'] for z in sources]==[0,1] and [z['root_state_counts'] for z in sources]==[{},dict(R_F1=8)]
 assert sources[1]['active_quantum_types']==['CM','aM'] and len(sources[1]['complete_rooted_oriented_cycles'])==8 and not sources[0]['complete_rooted_oriented_cycles']
 failed=read(O/'analytic_capture.json');assert failed['exit_code']==1 and not failed['calculation_completed'] and 'CONTROL_BLIND' in failed['stdout_and_stderr']
 analytic=read(O/'analytic_result_v2.json');assert analytic['left_and_right_Dyson_operator_coefficients'] and analytic['all_two_mass_orders_retained'] and analytic['profile_not_commuted_through_mean']
 assert analytic['direct_expanded_current']==analytic['regulator_current']==analytic['combined_D_plus_A']=='238*I/2025'
 assert all(analytic[k]!=analytic['direct_expanded_current'] for k in ['wrong_D_plus_AT','wrong_root_commuted_through_C','omit_marked_mass_roots'])
 resources={}
 for cn,rn,limit in [('native_capture.json','native_result.json',180),('replay_capture.json','replay_result.json',180),('analytic_capture_v2.json','analytic_result_v2.json',60)]:
  cap=read(O/cn);res=read(O/rn);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and res['elapsed_after_imports']<limit
  assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples'])
  resources[cn]=dict(seconds_after_imports=res['elapsed_after_imports'],largest_private_sample=max(x['private_bytes'] for x in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True)
 print('STAGE literal40424nonzerofullcolorcoefficients,wholeflowzero/supportbridges,finiteorderedDysonverified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
 cap=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',cap);dump(C/'e4_capture.json',cap);assert p.returncode==0
 ev=[json.loads(z) for z in p.stdout.splitlines() if z.strip()];exits=[z['exit_code'] for z in ev if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and ev[-1]['execution_state']=='COMPLETED'
 assert next(z for z in ev if z['event']=='step_finished' and z['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 old=(C/'old_git_tree.txt').read_bytes();assert old==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True)
 state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V798.md'];size=sum(p.stat().st_size for p in files);assert size<128*1024**2
 out=dict(schema='EXPANDED_SOURCE_REGULATOR_RECONCILIATION_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_LITERAL_SOURCE_OPERATORS_WHOLE_FLOW_BRIDGES_AND_FINITE_DYSON',scientific_acceptance='NOT_PERFORMED',base_HEAD=prep['base_HEAD'],state_sha256=state,paired_math_sha256=digest(a),literal_terms=counts,omit_A_changed_terms=data['omit_A_changed_terms'],full_selected_source12_to_regulator8_bridge=True,whole_F0_root_zero_reused_not_individual_factor_drop=True,finite_source_kernel_retained=True,ordered_UV_first_IR_reference='ZERO_THROUGH_IDENTICAL_V793_FINITE_KERNEL_NOT_NEW_INTEGRATION',finite_Gaussian_direct_equals_regulator=analytic['direct_expanded_current'],failures_this_increment=1,preserved_failure='V1_BLIND_LEGAL_CYCLIC_ROTATION_NEGATIVE_CONTROL_NOT_PASS',resources=resources,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(old.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,expanded_vector106_to_regulator46_comparison_pending=True,QGamma_D_target_accessed=False,full_QAP_E5_viability_goal_completion_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','evidence_validation','E4_step_exits','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
