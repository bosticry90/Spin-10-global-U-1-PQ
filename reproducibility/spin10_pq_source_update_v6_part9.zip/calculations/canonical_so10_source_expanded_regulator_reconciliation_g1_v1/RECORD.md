# Expanded source-current reconciliation

Base ff3bb4db8f6de09da0441643c92f2933149a5c99/main,V797.
Question: does the literal V789 selected source covariance have the finite
ghost-operator representation evaluated in V793, including kinetic and
ordinary mass roots, rather than merely the same returning counts?
Relevance: indispensable before full covariance/QGamma comparison; no
physical adoption or E5/A5 promotion. State113/34of39 remains unchanged.
Current AGENTS and full goal govern; D: repository/controls. No agents,
branch/worktree, flavor/protected activation, publication or remote push.

Scope original unshifted Euclidean A0, one-loop proper Gaussian, first
constant-u,g1,intrinsic01, incoming Ja_s Lambda_b C_c, both probes and all
45 external colors. All four derivative components retained. V789 literal
raw factor/product dispositions, V790 actual Hessian-Euler bridge and
zero own-jet diagonals, V791 inverse, V792 whole F0 regulator-zero and
complete source catalogs, V793 D/A/M/N and finite kernels are qualified
dependencies, authenticated rather than expensive factories rerun.

Least expensive competent test: independently reconstruct every returning
F1 ghost marked polynomial from (native) saved expanded unit products and
(replay) raw full T1 factors. Compare each to a compact construction from
the independently extracted full D_c,A_c and original/probe M_b,N_s.
Include kinetic four-component jets, Lambda mass roots and Ja mass roots;
retain exact zero/kept/rejected dispositions. No old nine-M amplitude or
QGamma/D target operand. Full source derivative precedes all restrictions.

For flow F0 the whole regulator root is an integrated graded-exchange zero
before ordinary insertions (V792); do not delete a single free factor.
Actual Fu0/Fu1 and non-ghost F1 have no returning selected source paths
under the complete existing coupling/type bound. Reuse these exact scopes,
not a source zero transferred to the vector. V790 gives the finite Gaussian
identity separately for each flow coefficient. These facts connect the
new explicit F1 comparison to the full12-word source covariance. The
vector106/46 expanded comparison remains separate and open.

Expected explicit F1 ghost matrix current uses Hphys=K+Lambda M+u Ja N,
G=(F^-1 K+Lambda M+u Ja N)^-1 and R=(F^-1-1)K:
 +Tr[D C G Hphys]+Tr[A^T C Hphys G]
 =-Tr[D C G R]-Tr[A^T C R G] at the Lambda Ja coefficient.
Do not commute R through C. Verify an exact finite coordinate Gaussian
with noncommuting profile/background matrices, both ordinary orders and
both source-root placements. Omitted mass roots and D+A^T are negative
controls. The transposed ordering gives D+A (V793), not D+A^T.

Possible outcomes exact agreement, explicit counterexample, or incomplete
resource-bounded calculation. Preserve all failures and sources, no weakening
or output fitting. Native/replay workers180s after imports each, analytic
60s, final180s; sampled8GiB private/350MiB launch floor,128MiB complete
packet. Freeze sources/inputs before execution and syntax-parse Python3.10.
Complete captures saved before exit assertions. Final E4 once/no-fresh D:
context0,0,0,0,0,2/seven unresolved custodyNOTPASS; old tree/state and raw
staged blob/modes preserved before local commit. No scientific acceptance
or stronger QAP/measure/normalization/reality/equivalence/viability claim.
Shared action/chart/ring/helpers/AI author; no independent scientists.
Education voluntary and nonblocking. Continue full goal after bounded result.
