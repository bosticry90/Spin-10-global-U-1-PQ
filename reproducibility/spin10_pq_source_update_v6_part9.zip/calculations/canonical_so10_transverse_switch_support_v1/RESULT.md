# V975 · Transverse local first-switch support

Both literal exports give six returning source-free
support classes and one source-bearing class. The
grade-zero roots, source-bearing route and swapped
mixed orientation cannot add a hard first-switch
coefficient in the zero-width transverse projection.

With the actual regulator terms retained, the
selected local `g³ J_B CC ∂s` equation imposes no
equality between H and M profiles. Matching within
each quartet is required. This uses the V969,
V972 and V973 zero columns after the support audit.

The external mean subtraction remains in the finite
operator equation. It supplies no local hard term
in this test. Separated kernels, exceptional
transfers, longitudinal widths and the ordinary
and marked causal conditions stay open.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
