"""Audit the typed support of the transverse compact first-switch coefficient."""

from collections import Counter
from itertools import permutations, product
import gzip
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def label(i):
    if i < 180:
        return "B"
    if i < 508:
        return "x"
    if i < 553:
        return "L"
    if i < 598:
        return "C"
    return "a"


def dim(i):
    if i >= 643:
        return 3-dim(i-643)
    return 2 if label(i)=="L" else 1


def census(phase):
    path = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    with gzip.open(path / f"{phase}_full_current.json.gz") as stream:
        action = json.load(stream)["current"]["complete_S_GF_source"]
    counts = Counter()
    for g,word,cells in action:
        if any(i>=1286 for i,_ in word) or not any(p[0]==0 for p,_,_ in cells):
            continue
        if sum(dim(i)+len(d) for i,d in word)!=4:
            continue
        ports = [label(i) for i,_ in word if i<643]
        source = [label(i-643) for i,_ in word if i>=643]
        assert len(source)<=1
        counts[g,source[0] if source else "-", "".join(sorted(ports))] += 1
    assert {k:v for k,v in counts.items() if k[1] not in ("-","x")} == {
        (0,"B","C"):180,(0,"a","L"):45,(1,"B","BC"):6696,
        (1,"C","CC"):837,(1,"L","CL"):334,(1,"a","Ca"):334,
        (2,"L","CCa"):3344}
    assert {k[2] for k in counts if k[:2]==(1,"-")} == {"BBL","BCa"}
    assert {k[2] for k in counts if k[:2]==(2,"-")} == {"BBCa"}
    return counts


def cycle(ports):
    inverse = {frozenset(pair) for pair in ("BB","BL","Ca","xx")}
    return any(all(frozenset((ports[i][side[i]],ports[(i+1)%len(ports)][1-side[(i+1)%len(ports)]]))
                   in inverse for i in range(len(ports)))
               for side in product((0,1),repeat=len(ports)))


def remove_exterior(ports):
    if len(ports)<2 or ports.count("C") < len(ports)-2:
        return None
    return ports.replace("C","",len(ports)-2)


def support(counts):
    fields = {(g,p) for g,j,p in counts if j=="-" and p!="LL"}
    # Pure physical types that can matter at g<=2 without an odd port.
    fields.update({(0,"BB"),(0,"xx"),(0,"xxxx"),(1,"BBB"),(1,"Bxx"),
                   (2,"BBBB"),(2,"BBxx")})
    sources = {(g,j,p) for g,j,p in counts if j!="-"}
    roots = {(g+h,"".join(sorted(p+q.replace(j,"",1))))
             for g,j,p in sources for h,q in fields if j in q and g+h<=2}

    def eligible(ports):
        internal = [remove_exterior(p) for p in ports]
        return (all(x is not None for x in internal)
                and sum(len(x)-2 for x in ports)==2
                and any(cycle([internal[0],*other]) for other in permutations(internal[1:])))

    found = set()
    for g,p in roots:
        if g==2 and eligible(("BC",p)):
            found.add((g,p,()))
        if g==1:
            for h,q in fields:
                if h==1 and eligible(("BC",p,q)):
                    found.add((g,p,(q,)))
        if g==0:
            for h,q in fields:
                if h==2 and eligible(("BC",p,q)):
                    found.add((g,p,(q,)))
                for k,r in fields:
                    if h==k==1 and eligible(("BC",p,q,r)):
                        found.add((g,p,tuple(sorted((q,r)))))
    assert found == {(0,"BC",("BCa","BCa")),(0,"CL",("BCa","BCa")),
                     (1,"BBC",("BCa",)),(1,"BCL",("BCa",)),
                     (1,"CCa",("BCa",)),(2,"BCCa",())}

    sourceful = {(q,r) for g,q in fields for h,r in fields if g==h==1
                 and eligible(("CC",q,r))}
    assert sourceful == {("BCa","BCa")}
    return sorted(found)


def projectors():
    k = sp.Matrix([1,0,0])
    r = sp.Matrix(sp.symbols("r0:3"))
    T = sp.eye(3)-k*k.T
    L = k*k.T
    g = T.row_join(-k).col_join(k.T.row_join(sp.zeros(1)))
    Q = ((r*k.T-k*r.T)/2).row_join(r/2).col_join((r.T/2).row_join(sp.zeros(1)))
    D = (-g*Q*g)[:3,:3]
    assert L*T == T*L == sp.zeros(3)
    assert (k.T*D*k)[0] == 0
    assert k.T*D == r.T*T/2
    assert T*Q[:3,:3]*T == sp.zeros(3)
    assert (D[1,0]).subs(r[1],1) != 0
    assert (-g*Q*g)[3,3] == 0
    assert all(2+d+1-gh>=5 for d,gh in ((2,-1),(1,-1),(2,-2),(2,0),(2,-1)))


def zero_columns():
    evidence = (
        ("auxiliary_regulator_switch_v1","auxiliary_s2_coefficient_with_regulator",0),
        ("regulator_second_switch_profile_v1","modified_direction_cells",[0]*4),
        ("regulator_cubic_switch_profile_v1","modified_columns",[0]*4))
    for suffix,key,target in evidence:
        path = ROOT / ("calculations/canonical_so10_"+suffix)
        result = json.loads((path/"result.json").read_bytes())
        receipt = json.loads((path/"validation_receipt.json").read_bytes())
        assert receipt["execution_state"] == "COMPLETED"
        assert receipt["evidence_validation"].startswith("PASS_BOUNDED_")
        assert result["checks"][key] == target


def check(phase):
    counts = census(phase)
    found = support(counts)
    projectors()
    zero_columns()
    return {"source_free_returning_support":[[g,p,list(q)] for g,p,q in found],
            "sourceful_FF_transverse_hard_zero":True,
            "swapped_mixed_orientation_zero":True,
            "grade_zero_first_switch_no_returning_hard_term":True,
            "external_euler_mean_no_hard_contact":True,
            "selected_transverse_profile_condition":"none within the matched quartets"}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
