# Support of the transverse local first-switch master coefficient

The target is the hard local g³ J_B CC coefficient
with one derivative of the common switch and no
exterior field derivative, in the fixed V879 jet
representative. Use zero background, intrinsic
degree zero and transverse zero-width gauge and
ghost propagators with one profile per quartet.
This coefficient is identified before exceptional
infrared limits. Retain the proper regulator mean
subtraction.

Each vertex of a proper one-loop cycle has two
ordinary internal ports. The retained source
comes from J_B B C or a source-bearing master
root. The grade-zero J_B derivative C vertex
has one ordinary port and cannot return. The
literal q_B depends only on B and C and ends
at grade one. The source-linear proper
variation uses the lower and upper q_B and q_C
corrections. The undifferentiated upper B C
term gives an exterior ghost derivative at
this jet. The lower corrections are V968 and
V970. V971 excludes the actual transverse
local q_C term. A local action term quadratic
in sources with J_B has minimum dimension five,
as in J_B J_a C or J_B J_Lambda CC. It cannot
add a local contribution in this projection.

In a source-bearing J_B master root the
switched square q_s² B equals s(partial s)q_C,
from the derivative in q_B and the uncut
nilpotence. The density uses the source-first
odd sign. At g³ the other two vertices must
each leave an exterior ghost. Their ordinary
BB edge is transverse and kills both F hard
derivatives. The root already uses the only
switch jet, leaving no switched inverse.

For a source-free master root with J_B B C
the typed returning support is:

    root grade   root ports        other ordinary vertices
      0          BC, Lambda C      F and F
      1          BBC, B Lambda C,
                 aCC               F
      2          B a CC            none

Here F is ordinary BCa. This follows by Euler
substitution and the two-port test. Physical
gauge, scalar and fermion vertices cannot
add antighost arms. The degree-two ghost
quartic has one C and one a. Four-ghost
alternatives vanish at zero broken width.
There is no positive-grade bivalent gauge-
ghost vertex at intrinsic zero. At the first
jet only one switched inverse can enter.
The free ghost switch has two derivatives.
The Maxwell switch between two transverse
BB factors vanishes.

The grade-zero compact and regulator roots
cancel at constant switch by the free
matched quartet identity. Their first jet
has at most one Lambda port. At least one
of the two F vertices therefore has an
untouched transverse BB edge and requires
an extra exterior derivative. The grade-two
root is the ordinary V968 term and the
V967/V969 auxiliary pair.

For grade one the pure Maxwell unregulated
root has equal exchanged hard tensors. With
a regulator their difference is retained in
V972/V973. The ordinary ghost root enters
through the reference transfer at F and
its inverse companion. An explicit switch
derivative at the ghost root leaves F with
an extra exterior derivative. The mixed
orientation in V965 has Lambda going to F
and ordinary B to J_B. Its first-derivative
transfers and inverse terms are V965 and
V972/V973. The explicit mixed quadratic
defect is V970. The opposite orientation
sends Lambda to J_B and ordinary B to F.
With a switch derivative at F its hard
product contains P_L P_T=0. With a Dyson
insertion on the ordinary edge the hard
momenta give k^t delta G_BB k=0. Insertion
on the mixed edge leaves F transverse-zero.
A density defect and an inverse together
would cost two switch jets.

The only candidate exterior Euler mean in
the regulator subtraction is E_R,a(C).
Keep it at finite cutoffs. Its proper F_a
response with J_B and one C has negative
hard degree, since F_a has dimension two
and J_B C has dimension three. Its exterior
Euler has two ghost derivatives and the
regulator factor vanishes after removal at
fixed nonexceptional momentum. Thus there
is no independent local hard term in this
test. This does not control a joint inverse-
heat soft limit. The one-loop bare driver
Jacobian has no exterior J_B.

Both exports verify the typed support and
the projector tests. The remaining local
returning first-switch coefficients are
the V969, V972 and V973 zero columns.
The transverse local hard comparison at
this order imposes no equality of H and M
weights. Separated kernels, exceptional
transfers, longitudinal widths, other
coupling and intrinsic grades, and the
ordinary and marked causal normalization
remain outside the result. Both routes
share the action and symbolic software.
