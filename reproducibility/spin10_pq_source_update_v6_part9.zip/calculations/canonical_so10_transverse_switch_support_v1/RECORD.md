# V975 pre-execution contract

Freeze V879 literal currents, V791 free inverse,
V894 switch inverse, and V965–V974 local results.
At A=0, intrinsic zero and zero widths, audit
proper returning support of the g³ J_B CC hard
local coefficient with one common switch derivative.
Include source-bearing and grade-zero roots, both
mixed orientations and external regulator means.
Check typed vertices, cycle support and derivative
exclusions in both exports. Use the V969/V972/V973
zero columns after accounting for support. Keep
absolute separated kernels and soft limits outside.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority change.
