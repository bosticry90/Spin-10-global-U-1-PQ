"""Actual Ward-driver and finite nonlinear insertion controls."""

from collections import Counter, defaultdict
import gzip
import json
import sys

import sympy as sp

from execute import PK, ROOT, read, run_worker

sys.path.insert(0, str(PK))
from source_convention_control import Exterior


CALC = ROOT / "calculations"
BLOCKS = {"Phi": range(54), "Sigma": range(54, 306), "phi": range(306, 326), "S": range(326, 328)}


def actual_drivers(role):
    owner = CALC / "canonical_so10_unprobed_compact_all_coupling_v1"
    path = owner / f"{role}_full_current.json.gz"
    with gzip.open(path, "rt", encoding="utf-8") as stream:
        rows = json.load(stream)["current"]["complete_S_GF_source"]
    counts = Counter()
    affine = Counter()
    low = Counter()
    fixture = {}
    for g, word, cells in rows:
        sources = [(i, jets) for i, jets in word if 643 <= i < 1286]
        if sources:
            assert len(sources) == 1
            output, jets = sources[0]
            i = output - 643
            assert not jets and all(n != i for n, _ in word)
            counts[f"g{g}"] += 1
            ordinary = [(n, js) for n, js in word if n < 643]
            assert ordinary
            if len(word) == 2:
                assert g == 0
                (j, input_jet), = ordinary
                if i < 180:
                    assert 553 <= j < 598 and j - 553 == i // 4 and input_jet == [i % 4]
                    affine["B_from_dC"] += 1
                else:
                    assert i >= 598 and j == i - 90 and not input_jet
                    affine["a_from_Lambda"] += 1
            if i >= 598 and g > 0:
                assert g == 1 and i >= 610 and len(word) == 3
                assert 553 <= ordinary[0][0] < 565 and 610 <= ordinary[1][0] < 643
                assert all(not js for _, js in ordinary)
                low["antighost_HM_bilinear"] += 1
            if word in ([[1, []], [554, []], [652, []]], [[9, []], [554, []], [644, []]]):
                assert g == 1
                fixture[str(i)] = cells
            continue
        if len(word) != 3 or any(n >= 643 for n, _ in word):
            continue
        b, c, a = (n for n, _ in word)
        if b < 180 and c < 180 and 508 <= a < 553:
            assert g == 1 and b < 48 <= c and a >= 520
            low["Lambda_BH_BM"] += 1
        if 508 <= b < 553 and 553 <= c < 598 and 598 <= a < 643:
            assert g == 0 and b >= 520 and c - 553 != a - 598
            low["Lambda_offdiagonal_ghost"] += 1
    assert counts == {"g0": 225, "g1": 20761, "g2": 3344}
    assert affine == {"B_from_dC": 180, "a_from_Lambda": 45}
    assert low == {"antighost_HM_bilinear": 334, "Lambda_BH_BM": 1336, "Lambda_offdiagonal_ghost": 600}
    assert fixture == {"9": [[[0, 0, 5], -1, 4]], "1": [[[0, 0, 5], 1, 4]]}
    return {"source_driver_rows": dict(counts), "own_coordinate_derivative_rows": 0,
            "constant_tangent_rows": dict(affine), "forced_zero_support": dict(low),
            "gauge_tree_driver_pair": fixture}


def scalar_root(role):
    route = "primary" if role == "native" else "replay"
    pole = read(CALC / "canonical_so10_ghost_mass_g4_pole" / f"{route}_v2_result.json")
    physical = read(PK / f"frozen_a10_physical_reconciliation/full_{route}.json")
    v = {i: sp.sympify(value) for i, _, value in physical["vacuum"]["VEV"]["entries"]}
    projections = defaultdict(lambda: sp.S.Zero)
    for a, x, value in pole["physical_E"]:
        block = next(name for name, domain in BLOCKS.items() if x in domain)
        projections[block, a] += sp.sympify(value) * v.get(x, 0)
    assert all(sp.expand(projections[name, a]) == 0 for name in BLOCKS for a in range(45))
    return {"tested_block_orbit_projections": 4 * 45, "radial_orbit_projection": "0"}


def ordered_source_shift():
    e = Exterior()
    beta, F_B, j_a = [e.variable(name, 1) for name in ("beta", "F_B", "j_a")]
    j_B, F_a = [e.variable(name, 0) for name in ("j_B", "F_a")]
    assert e.mul(j_B, beta, F_B) == e.mul(beta, j_B, F_B)
    assert e.mul(j_a, beta, F_a) == e.scale(e.mul(beta, j_a, F_a), -1)
    return {"even_ordinary_source_sign": 1, "odd_ordinary_source_sign": -1}


def nonlinear_fixture():
    x, y = sp.symbols("x y")
    slots = (x, y)
    z = sp.Matrix(slots)
    point = {x: 2, y: 3}
    phi = z.subs(point)
    K0 = sp.diag(2, 3)
    G = sp.eye(2) / 4
    j = sp.Matrix([-17, -16])
    V = x * y + x**2 * y / 2
    U = sp.Matrix([y**2, x**2])
    T = U.jacobian(slots)
    assert sp.trace(T) == 0
    D = sp.eye(2) - G * K0
    K = sp.Matrix([sp.diff(V, field) for field in slots]) + j
    H_V = sp.hessian(V, slots)
    H = K0 + H_V
    E = K0 * z + K
    assert phi == -G * K.subs(point)
    assert E.subs(point) == D.T * K.subs(point)
    G_S = (sp.eye(2) + G * H_V.subs(point)).inv() * G
    grad_F = sp.Matrix([sp.trace(G_S * H.diff(field).subs(point)) / 2 for field in slots])

    def rooted(insertion):
        direct = sp.trace(G_S * sp.hessian(insertion, slots).subs(point)) / 2
        root = -G_S * sp.Matrix([sp.diff(insertion, field) for field in slots]).subs(point)
        return direct, grad_F.dot(root)

    P = U.dot(E)
    Q = (D * U).dot(K)
    assert P.subs(point) == Q.subs(point) != 0
    direct_p, root_p = rooted(P)
    direct_q, root_q = rooted(Q)
    assert direct_p != direct_q and root_p != root_q
    whole = direct_p + root_p
    assert whole == direct_q + root_q and whole != 0
    nonlinear = sum((E[i] * sp.hessian(U[i], slots) for i in range(2)), sp.zeros(2))
    omit = sp.trace(G_S * nonlinear.subs(point)) / 2
    assert omit != 0
    return {"tree_defect": str(P.subs(point)), "P_direct_and_root": [str(direct_p), str(root_p)],
            "Q_direct_and_root": [str(direct_q), str(root_q)], "common_one_loop": str(whole),
            "omitted_second_driver_term": str(omit)}


def gauge_profile_control():
    p_q, p_r, p_k = map(sp.Integer, (1, 4, 9))
    f_q, f_r, f_k = ((1 - sp.Integer(2)**(-p))**2 for p in (p_q, p_r, p_k))
    defect = f_r * (1 - f_q) / p_r - f_q * (1 - f_r) / p_q
    tree = f_r / p_r - f_q / p_q - f_q * f_r * (1 / p_r - 1 / p_q)
    wrong = f_r * (1 - f_r) / p_r - f_q * (1 - f_q) / p_q
    assert defect == tree == sp.Rational(551, 4096)
    assert wrong != defect
    r, eps = sp.symbols("r eps", positive=True)
    integrals = [sp.integrate(sp.exp(-r**2 / eps**2) * r**(3 - n), (r, 0, sp.oo)) for n in (2, 3)]
    assert integrals == [eps**2 / 2, sp.sqrt(sp.pi) * eps / 2]
    return {"tree_bracket_stripped": str(defect), "ghost_factor_times_bracket": str(f_k * defect / p_k),
            "wrong_input_profile_sensitive": True, "gaussian_radial_orders_2_and_3": list(map(str, integrals))}


def checks(role):
    return {"actual_drivers": actual_drivers(role), "scalar_root": scalar_root(role),
            "ordered_source_shift": ordered_source_shift(), "nonlinear_fixture": nonlinear_fixture(),
            "gauge_profile_control": gauge_profile_control()}


if __name__ == "__main__":
    run_worker(checks, sys.argv[1])
