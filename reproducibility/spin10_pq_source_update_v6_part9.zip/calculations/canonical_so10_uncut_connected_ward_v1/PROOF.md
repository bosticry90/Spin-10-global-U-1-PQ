# The constant connected Ward direction in the paired Euclidean forest

Keep the V887 uncut, unprobed, ordinary action S and its same common
conversion. In the raw Minkowski LEFT chart set F_i=E^L_{J_i} S,
s_i=(−1)^(p_i), and use a constant odd bookkeeping strength β on
the left. Then U_i=β F_i is an even field displacement. The parent
is affine in J. The source-first pairing gives

    U(S+jz)=β B[S]+β∑_i s_i j_i F_i,
    B[S]=∑_i ∫ F_i E^L_i S=0.

Here and below E denotes the ordered Euler derivative. The master
zero is the uncut integrated identity in the actual parent. The
ordinary derivative in the source term has the s_i sign. The source
variation in the second term is exactly the independent LEFT J shift
β s_i j_i, including every retained-source coefficient. No source is
set to zero before differentiation in this equation.

## Exact finite defect and its common converted version

Write S=R_0+V, with K_0 the fixed free Hessian. For a finite flat
covariance G_f set D=1−G_f K_0, D^sharp=1−K_0 G_f. The sharp denotes
the ordered variation dual. Wick contraction of (K_0 z)_i into
U_i times the interaction and source exponential yields the output
profile K_0 G_f. Contraction into U_i itself is the diagonal
derivative trace. Moving the odd strength β through the LEFT Euler
and then taking the even supertrace gives the diagonal LEFT sum
∑ E_i F_i with the profile, rather than an added s_i. In the actual
joined coordinates each F_i is independent of its own z_i and jets.
This is checked for every source driver in both current packets.
The flat profile is diagonal in this chart, so the weighted trace
vanishes before the momentum integral. A different off-diagonal
profile would require a separate check.

The exact finite covariance Wick equation is consequently

    I_{B[S]}^f + ∑_i ∫s_i j_i E^L_{J_i}W_f
      = <∑_i (D F)_i E^L_i(V+jz)>_f.

The defect acts on the output momentum of the entire driver, even
when F_i is nonlinear. This derivation uses the free inverse product
and no inverse heat. The finite heat part of D is not small in the
UV and cannot be discarded by this equation.

For the common converted identity work at fixed positive paired
IR cutoff after UV conversion, with G=G_epsilon and D as above.
Denote the signed ordinary source column by j^flat and put
K=E(V)+j^flat, H=K_0+V'' and T=U'. Write
A=(1+G V'')^−1, B=(1+V''G)^−1 and
G_S=A G. These are finite formal expansions in each coefficient.
The tree mean satisfies φ=−G K, and at this mean

    E=E(S)+j^flat=D^sharp K,
    G_S H=1−A D,   H G_S=1−D^sharp B,
    G_S V''=1−A,   V'' G_S=1−B.

Compare the insertion P=U·(E(S)+j^flat) to the bilocal defect
insertion Q=(D U)·K. The dot denotes the same ordered variation
pairing. At the tree mean P=Q. Their Hessians and ordinary rooted
variations are obtained by two differentiations in the same chart.
In H_P the terms are D_U H, T^sharp H, H T and E·H(U). Its rooted
variation is −U+A D U−G_S T^sharp E. In H_Q the terms are D_{D U}H,
T^sharp D^sharp V'', V'' D T and E·H(U). Its rooted variation is
−(1−A)D U−G_S T^sharp E. The last Hessian term is required for
nonlinear F. It uses E at the regulated mean.

At one loop apply the same linear converted trace to each direct
Hessian and add the full rooted derivative of the same proper
functional. The mean derivative in both cases is then the same,
in direction A D U−G_S T^sharp E. The remaining trace in the P
case reduces by cyclicity to −STr(A D T+D^sharp B T^sharp), since
STr(T+T^sharp)=0. In Q it reduces to exactly this expression using
G_S V'' and V'' G_S and the vanishing diagonal trace of D T and
its dual. The identical E·H(U) term stays on both sides. Thus
the normalized finite-IR Ward coefficient equals the insertion
of the single IR defect Q in the rooted calculus.

The cyclic rule here is that of the lifted V880/V886 common
conversion. At fixed positive IR cutoff, replacing a free word
by its IR-smoothed version changes the large-loop symbol by a
rapidly decreasing term on bounded external Fourier transfers.
Ordinary trace rotation applies to that change, with the lifted
Stokes rule on the original symbol. A cycle containing the
bilocal defect is UV integrable. If the defect lies on a tree,
it is an exterior factor of the already normalized cycle.
The full D_t B_t UV subtraction uses the same regulated tree
factors before taking the UV limit. In particular the derivative
of a counterterm insertion is part of the common map derivative.
This argument does not apply a bare finite-covariance identity
to an independently shifted quantum action. The paired initial
b terms are transported on that same parent and cancel.

## Limit of the single IR defect

For the paired profile D is zero on positive massive scalar
edges and equals 1−χ² on each massless free block. It tends to
zero away from zero transfer and is bounded by one and by
2 exp(−p²/epsilon²). In the graph of Q regard D as an edge
between the driver and the Euler vertex. The Euler vertex has
the original V vertex valence, since D replaces the differentiated
leg. Nonlinear drivers have valence at least three after adding
the D edge. Any A, J or j at a vertex is a test label. The linear
∂C or −Lambda driver collapses with its adjacent free edge to
pole at most one, including its D factor. A two-valent E_Lambda V
from the constant Lambda x term collapses through the scalar
chain with at most an order-one Bx pole. The other end of this
constant term is scalar and its D is zero. These rules leave
the ordinary V880 collapse and at most one improved edge.

First peel globally forced-zero bridges. An unlabeled tree side
has no linear vertex on which it can end. If the defect lies
inside an unlabeled one-port loop, its extra ghost number
requires an exposed C. The ordinary ghost bridge on that port
vanishes at zero momentum at positive cutoff. If D itself is
the forced bridge and its driver side has the loop, only an
antighost output has a ghost-neutral driver. The actual F_a is
linear in Lambda plus the g a_M C_H term. The bilinear one-edge
trace is zero by H/M support. The linear part reaches only B
and its vector tadpole is zero. If the Euler side has the loop,
its massless ordinary one-point can only be B or Lambda. The
B component vanishes by rotational covariance. The two Lambda
cubic traces vanish by the H/M vector cross and the absence of
a diagonal ghost pair. Its N x route into the scalar tadpole
is radial in each invariant scalar block by V883/V887. The
actual orbit contraction N v_s is zero in each block and stays
zero under every finite mass insertion. A scalar output at D
would be zero already. These statements include low one-loop
local replacements via the same converted tadpoles. They do
not evaluate an uncut massless propagator at the origin.

For the remaining graphs use the incidence ranks of V881 and
the ordinary forest proof V887. In a cut-cycle equality the
unlabeled hard components are singleton cubics with all three
ports soft. An ordinary one has its derivative or low-weight
gain. A defect vertex of otherwise problematic type has the
improved D incidence. If D is hard the component of that
vertex is no longer a singleton. Thus the strict cut estimate
persists. A hard cycle with at least three exits or with a
retained test label has the ordinary margin. In a two-exit hard
component distinguish the following cases.

- If D is on an exit, its pole gain makes the inequality strict.
  If D is farther outside, cut the same two exit forests and
  group the ordinary BB or aC coefficient as in V887. The
  group has its soft gain, with D on the same exterior trees.
  Its finite error has at most the ordinary outer logs.
- If D lies on a proper cycle with two exits, the core has
  at most two vertices after constant chains are collapsed.
  Its worst local integral is bounded by a Gaussian centered
  on the D momentum times two poles of total order at most
  three. The weighted arithmetic mean bounds their product
  by inverse powers of that total order centered at the two
  nodes. The shifted Gaussian bound gives O(epsilon) or
  better uniformly in bounded transfers. The UV tail is
  rapidly decreasing. The massless outer branches have at
  worst the marginal logs of V887 at the paired scale, so
  this contribution goes to zero.
- A hard one-port sewn to one cubic is already peeled if the
  defect is on its forced bridge or in that one-port loop.
  If the defect is farther outside, use the ordinary grouped
  core and its same regulated exit forests.

All other strict graphs admit the V887 dyadic majorant with
D bounded by one. After peeling, the D transfer has positive
rank, so D tends to zero almost everywhere. Dominated
convergence gives zero, together with the vanishing marginal
terms just controlled. This proves the single constant connected
master identity −∑ s_i j_i E^L_{J_i} W=0 at tree and one loop
on the direct paired Euclidean domain. It uses the grouped
regulator comparison. No separate order-three tangent graph
boundary is required.

## Actual finite-profile countercheck

Take transverse ordinary j_B tests of colors 2 and 0 with the
same spatial polarization, and one ordinary j_a of color 1.
All are in H. The actual joined g1 source driver has magnitude
sqrt(10)/4 in this color order, with the opposite reverse
coefficient. No heavy orbit or physical scalar term contributes
at this tree degree. The linear ∂C term on the ordinary B
source vanishes by transversality. On the two B means the cubic
Yang–Mills Noether identity relates the longitudinal Lambda
response to the nonlinear B driver. The Lambda and linear ∂C
terms in the finite Wick defect cancel since both carry the
same profile at the ghost momentum. The remaining coefficient,
stripping the common nonzero color and continuation factors, is

    f(k)/P_k [f(r)(1−f(q))/P_r−f(q)(1−f(r))/P_q].

Here q,r are the B source transfers and k=−q−r. Equivalently,
evaluate the direct B source variation at the classical means
and use the longitudinal Lambda response to subtract the
product of both B profiles. The two ways agree. For r=2q and
|q|²=epsilon² log 2 the bracket in Euclidean units is
551/(4096 |q|²), strictly nonzero. Independent narrow tests at
this fixed regulator detect it. In the limit the tests are held
fixed. Matched linear free contacts therefore do not imply the
nonlinear Ward identity at finite cutoff.

For context, modified Slavnov–Taylor identities at nonzero
infrared scale also occur in Yang–Mills flow equations. The
comparison here uses the actual project covariance and its
fixed one-loop conversion. [Ellwanger](https://arxiv.org/abs/hep-th/9402077)
