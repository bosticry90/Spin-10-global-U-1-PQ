# V888 pre-execution contract

Test the single constant LEFT Ward direction in the direct unmarked
V887 ordinary forest. Use the uncut V879/V880 643-coordinate parent,
all fixed finite g and scalar mass-difference degrees, independent
smooth compact Fourier tests, fixed positive scalar references and
the same paired massless IR profile. Keep the raw source-first chart
of V876 and u=rho=0. No new profile, subtraction or physical input.

Bind the complete current native and replay drivers, actual reference,
V880 proper master, V886 converted shear and V887 ordinary forest.
Derive the finite regulator Ward defect without inverse heat. Prove
that the identity transports to the fixed-IR common converted
functional, with the nonlinear Hessian and full regulated UV forests.
Audit the diagonal derivative and both forced-zero bridge ends.
Require a nonzero actual matched-profile gauge tree test. Compare
the nonlinear normalized insertion algebra in an exact finite
stationary fixture, retaining its second-driver and rooted terms.
Derive the limit from rank and grouped low-port estimates.

Freeze typed inputs, proof and source before launch. Limits are
120 s native, 180 s final including E4 capped at 120 s, 8 GiB sampled
private bytes, 350 MiB launch commit floor, 8 MiB artifact, 32 MiB
packet. Preserve failures, require distinct exact replay, E4 with
historical custody separate, and exact staged bytes. Ceiling is the
single connected uncut master on this direct paired Euclidean
domain, at tree and one loop. General Lorentzian gluing, compact-to-
uncut equality, local products, geometric W5, W6 and E5/A5 stay open.
