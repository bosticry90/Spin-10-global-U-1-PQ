# V890 final staging continuation

V2 native replay completed. A subsequent precheck found CRLF
in the new correction note and snapshot. V2 final validation
did not run. Its exact native packet and hash inventory are
in preserved_active_v2 under the V2 D control directory.
V3 freezes LF sources and repeats the same scientific tests
with the same limits. Both prior packets retain exact bytes.
