# V890 versioned staging correction

The V1 native and final replay completed. Exact staging stopped
before git add because the Git text filter would normalize the
CRLF-bearing proof and other files, changing validated bytes.
This is a staging failure. The mathematical tests are identical.

The original active packet, source snapshots, captures, receipts
and both navigation states are preserved under the independent
D control directory uncut-connected-geometric-v1-2026-11-08,
with preserved_active_v1/archive_sha256.json. The original
receipt still binds its original bytes. V2 freezes fresh LF
sources, independently replays both routes and repeats E4
with the same budgets and acceptance conditions. Exact staged
byte verification remains mandatory. No V1 byte binding is
substituted or edited.
