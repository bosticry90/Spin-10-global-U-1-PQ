"""Exact controls for the direct paired geometric Ward proof."""

from collections import Counter
from functools import cache
import gzip
import json
import sys

import sympy as sp

from execute import PK, ROOT, run_worker


def packet(owner, name):
    return ROOT / "calculations" / ("canonical_so10_" + owner) / name


def load(path):
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="utf-8") as file:
            return json.load(file)
    return json.loads(path.read_bytes())


def variation_cell(rows, operations, target):
    total = sp.S.Zero
    odd = {"C10", "bar5"}
    ordered_odd = [name for name in target if name in odd]
    target_counts = Counter(target)
    for row in rows:
        word = row["word"]
        for i, name in enumerate(word):
            if name not in operations:
                continue
            other = word[:i] + word[i + 1:]
            remainder = target_counts.copy()
            remainder.subtract(other)
            if any(count < 0 for count in remainder.values()):
                continue
            for variation in operations[name]:
                inserted = variation["word"]
                if Counter(inserted) != +remainder:
                    continue
                output = word[:i] + inserted + word[i + 1:]
                sign = 1 if [name for name in output if name in odd] == ordered_odd else -1
                total += sign * sp.sympify(row["coefficient"]) * sp.sympify(variation["coefficient"])
    return sp.expand(total)


def actual_action(role, chart):
    route = "primary" if role == "native" else "replay"
    e3 = load(PK / "frozen_a10_e3_symmetry" / (route + ".json"))
    bv = load(PK / "frozen_a10_bv_master" / (route + ".json"))
    e2 = (ROOT / "tools/portable_dh_v1/inputs.json.gz" if role == "native" else
          PK / "frozen_a10_e2_transport/replay.json")
    density = load(e2)["gauge_fixing_density"]
    variations = e3["operators"]["Tb_geometric_and_transported"]
    background = {key: value for key, value in variations.items() if key.startswith("A")}
    source = e3["source_transport_corrections"]["quantum"]
    g = sp.Symbol("g10")
    witnesses = (
        (["B0_0", "C10", "bar5", "omega0__0"], -8*g**2),
        (["A10_0", "B0_0", "C10", "bar5", "omega5"], -16*sp.sqrt(2)*sp.I*g**3),
    )
    for word, expected in witnesses:
        assert variation_cell(density, background, word) == expected, word
        assert variation_cell(bv["source_polynomial"], source, word) == expected, word

    owner = "unprobed_compact_all_coupling_v1"
    current = load(packet(owner, role + "_full_current.json.gz"))["current"]
    correction = current["complete_CS"]
    counts = Counter(f"g{degree}" for degree, _, _ in correction)
    assert counts == {"g0": 48, "g1": 1152, "g2": 11264, "g3": 48960}
    for degree, word, _ in correction:
        if degree == 3:
            assert len(word) == 5
            assert sum(1331 <= i < 1379 for i, _ in word) == 1
            assert sum(1319 <= i < 1331 for i, _ in word) == 1
            assert sum(i < 643 for i, _ in word) == 3
    for color in range(12):
        for axis in range(4):
            cell = [0, [[508 + color, []], [1319 + color, [axis, axis]]], [[[0, 0, 16], -1, 1]]]
            assert cell in correction
    assert [2, [[0, []], [554, []], [598, []], [1335, []]], [[[0, 0, 0], 5, 8]]] in current["complete_S_GF_source"]
    assert [1, [[1339, []], [1379, []]], [[[0, 0, 5], 1, 4]]] in chart["all1391_Tb_columns"][1335][1]
    assert [3, [[0, []], [554, []], [598, []], [1319, []], [1339, []]], [[[0, 0, 5], 5, 32]]] in correction
    return {"whole_source_grade_counts": dict(counts), "raw_affine": str(witnesses[0][1]),
            "raw_homogeneous": str(witnesses[1][1]), "joined_homogeneous": str(5*sp.sqrt(10)/32),
            "J_free_g3_rows": counts["g3"]}


def field_columns(chart):
    homogeneous = affine = 0
    parity = chart["joined_parities"]
    for i, column in chart["all1391_Tb_columns"][:643]:
        for degree, word, cells in column:
            if degree == 0:
                assert i < 48 and parity[i] == 0
                assert word == [[1379 + i//4, [i % 4]]] and cells == [[[0, 0, 0], 1, 1]]
                affine += 1
            else:
                assert degree == 1 and len(word) == 2
                (ordinary, jet), (omega, omega_jet) = word
                assert 0 <= ordinary < 643 and 1379 <= omega < 1391
                assert jet == omega_jet == [] and ordinary != i and parity[ordinary] == parity[i]
                homogeneous += 1
    assert (homogeneous, affine) == (7800, 48)
    return {"ordinary_homogeneous_rows": homogeneous, "ordinary_affine_rows": affine,
            "weighted_diagonal_trace": 0}


def affine_control():
    p, j, omega, norm = sp.symbols("p j omega P", nonzero=True, real=True)
    f = sp.Rational(1, 4)
    jv = sp.I*p*j*omega
    mean = -sp.I*f*p*j/norm
    source = mean*(-norm*omega)
    assert source == f*jv and source != -f*jv
    return {"relative_insertion": str(source/jv), "relative_cutoff_defect": str((jv - source)/jv)}


def reference_control():
    ref = load(packet("current_background_reference_bridge_v1", "result_a.json"))["compared"]
    assert ref["all_48_connection_affines"] == [[1331 + i, 1379 + i//4, i % 4] for i in range(48)]
    exact = cache(sp.sympify)
    carriers = [{(i, j): exact(c) for i, j, c in rows if 180 <= i < 234 and 180 <= j < 234}
                for rows in ref["twelve_current_homogeneous_carriers"]]
    for h, first in enumerate(carriers):
        for k, second in enumerate(carriers):
            assert -sum(c*second.get((j, i), 0) for (i, j), c in first.items()) == 12*(h == k)
    u = sp.Symbol("u")
    moment = sp.integrate((1 - 2*u)**2*u*(1 - u), (u, 0, 1))
    assert moment == sp.Rational(1, 30)

    g = sp.diag(sp.Rational(1, 2), sp.Rational(1, 3))
    k0, ka = sp.diag(2, 3), sp.diag(3, 4)
    h = sp.Matrix([[5, 1], [1, 6]])
    dx = g*sp.Matrix([[1, 2], [2, 0]])
    dh = g*sp.diag(2, 1)
    x, y, dy = g*(ka-k0), g*(h-ka), dh-dx
    assert x*y != y*x
    p = sp.eye(2) + x
    pi = p.inv()
    zi = (sp.eye(2) + pi*y).inv()
    ref_piece = sp.trace(pi*dx)
    relative = sp.trace(zi*(pi*dy-pi*dx*pi*y))
    absolute = sp.trace((p+y).inv()*dh)
    assert ref_piece + relative == absolute
    assert relative != absolute and ref_piece + sp.trace(zi*pi*dy) != absolute
    return {"Phi12_trace_Gram_diagonal": 12, "Phi12_shape_slope_times_mass_squared": str(-moment),
            "noncommuting_split_absolute": str(absolute), "noncommuting_split_reference": str(ref_piece),
            "reference_omission_detected": True, "inverse_variation_omission_detected": True}


def checks(role):
    chart = load(packet("joint_common_family_applicability_v1", role + "_complete_full_background_extension.json.gz"))
    return {"field": field_columns(chart), "action": actual_action(role, chart),
            "affine": affine_control(), "reference": reference_control()}


if __name__ == "__main__":
    run_worker(checks, sys.argv[1])
