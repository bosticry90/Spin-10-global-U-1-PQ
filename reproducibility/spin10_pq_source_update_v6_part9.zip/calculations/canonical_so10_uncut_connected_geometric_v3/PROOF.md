# The actual geometric Ward insertion in the direct connected map

Use the uncut unprobed V879/V880 parent S_A and the V887/V888
direct paired Euclidean map at tree and one loop. Let omega
be one independent local even test in H. Write the ordinary
field variation of T_q and T_b as U=Mz+v. The homogeneous
part M is parity preserving and multiplication by the test
in the actual representation. The affine part v_B=partial
omega has only light vector support. The retained-source
variations are the common evaluation dual. T_q fixes A and
T_b additionally differentiates A by the actual T_A rule.

## A single normalized affine defect

Write S_A=R_0+V with K_0 fixed and use the V888 normalized
comparison at positive IR cutoff, after the common UV
conversion and D_t B_t forest subtraction. Use its P and Q
insertions with U=Mz+v. The term E·H(U) is zero here because
the field variation is affine. The actual 7,800 homogeneous
ordinary coefficient rows have no own-coordinate incidence
and preserve parity. Its even supertrace, with or without the
diagonal profile, is therefore zero. The independent 48
affine rows carry the test derivative. The same trace, rooted
and inverse-product algebra of V888 gives

    I^W_{U·E(S_A+jz)} = I^W_{(D U)·E(V+jz)}

at fixed positive paired IR cutoff in the common map. Here
D=1−G K_0, with G the fixed-IR unheated reference. The defect
acts on the complete output momentum. This comparison keeps
the same converted proper variation and rooted correction,
without a bare positive-heat inverse or a fitted contact.

To remove D, attach its independent omega label at the
affine or homogeneous end. If D is forced to zero on a
bridge, the only unlabeled side is the Euler end. Its B and
Lambda tadpoles vanish by the V888 vector, H/M and radial
orbit checks. Odd one-points vanish by ghost number. D_x is
zero on the positive scalar blocks. An unlabeled tree side
has no linear vertex. No uncut massless inverse is evaluated
at zero. All other forced-zero edges use the ordinary V887
grouping and its actual paired profile.

In a hard component containing D and its driver the cycle
is labeled by omega. If a collapsed two-port core contains the
D edge apart from that labeled vertex, the V888 shifted-Gaussian
bound with total pole order at most three gives O(epsilon) or
better, including its ordinary exterior logs. If D is a soft
exit it improves the pole
order to zero, or at most one after the E_Lambda V constant
mass chain. If the hard component is farther from D, its
critical BB/aC group is the same as V887, with identical
exterior forests. The strict cut-cycle estimate persists
because singleton unlabeled cubic vertices have the ordinary
gains. After peeling, the D transfer has positive rank and
its multiplier tends to zero almost everywhere. The strict
dyadic estimates and ordinary paired marginal errors of V887
give zero. This argument uses a smooth compact Fourier test
for omega throughout. It does not replace it by a constant
field or an unsmeared momentum restriction.

## Background, quantum and source variations

Lift the ordinary source by delta j=−j M in source-first
order. Since the transformation is even this cancels the
homogeneous variation of jz and leaves the affine integral
∫jv. External derivatives are derivatives of the same whole
functional, including the mean and the normalization. In
particular at fixed j,

    T_A W = I^W_{T_A S_A}.

The field-change comparison above gives the geometric broken
identity and the background identity

    Ttilde_q W = I^W_{T_q S_A} + ∫jv,
    Ttilde_b W = ∫jv.

For the second equation use the actual integrated T_b S_A=0
with the full local current and no switch. For the first, the
geometric T_q S_A is nonzero. V879 supplies the exact whole
E3 action direction C_source S_A=T_A S_A and
T_q S_A+C_source S_A=T_b S_A as integrated variations. Thus

    Ttilde_q W + I^W_{C_source S_A} = ∫jv.

The insertion here is the derivative in the entire action
direction. The coefficients c_J depend on fields. A product
of c_J on the mean and a separate retained-source derivative
would lose its connected and rooted responses. No such
factorization is used. The g3 homogeneous term survives the
J=0 restriction of the inserted action, because the retained
source derivative was already taken.

At fixed positive IR use the V869 split in the same lifted
cyclic map. Set X=G(K_A−K_0) and Y=G(H_S−K_A). In the common
converted trace, expand

    1+X+Y=(1+X)[1+(1+X)^−1Y].

Include the pure reference trace once. Differentiating the
reference, the relative factor and its reference inverse then
gives the derivative of the absolute trace, since X'+Y'=G H_S'.
The same identity holds at each finite expanded word degree.
Use the true X/Y clock length in the raw UV terms and the
V869 Laurent offset kappa_D=kappa_H−1−log(16 pi) in the
converted split. The common initial local b term varies on
the entire parent. Omitting the reference or holding its
inverse fixed changes the insertion even at finite matrices.

For the background Ward direction, the pure reference operator
satisfies T_A K_A=−M^sharp K_A−K_A M by V869. In the paired
limit the trace of this congruence vanishes by cyclicity and
the diagonal-trace and single-defect checks above. In this
pure reference sector the omega test labels the varying
cycle. The affine reference action variation z·K_A v is
linear, so it is retained by the rooted map even though its
direct Hessian is zero. General A derivatives of the pure
reference trace do contribute. In particular the actual
Phi12 current matrices have negative trace Gram 12 I.
The transverse reference form factor has
F_M'(0)=−∫_0^1(1−2u)^2 u(1−u)du/M=−1/(30 M)
for positive squared mass M, independently of the local
baseline. This tests the distinction between a general
background derivative and its Ward contraction.

## Exact controls and scope

In the raw E3/BV rows, vary the gauge-fixing density in A,
and independently vary the BV source polynomial using the
source correction. Both yield −8 g² on B0_0 C10 bar5 times
the temporal derivative of omega0. Both yield −16 sqrt(2) i g³
on A10_0 B0_0 C10 bar5 omega5. A separate joined witness
multiplies the g² density coefficient 5/8 by the homogeneous
background-column entry sqrt(10)/4. It gives 5 sqrt(10)/32
in the V879 complete insertion, with no remaining J leg.

At g0, the light auxiliary action contains
−Lambda div(B−A) in the raw chart. The inserted direction is
+Lambda Box omega from T_A or C_source and the opposite from
T_q. With incoming momentum p for omega and the source-first
stationary convention, phi_Lambda(−p)=−i f(p) p·j_B(−p)/P.
Multiplying by Box omega gives +f(p) ∫jv in this projection.
The left fixed-A variation of W itself is zero at g0. The
finite-profile discrepancy from the paired identity is
therefore (1−f) ∫jv, nonzero at f=1/4. A narrow fixed test
detects the discrepancy and is held fixed when taking the
paired limit. The continued rows agree with the raw phases.

V874 has nonzero switched currents with independent switch
derivatives. Its compact W5 expression remains a separate
identity. The direct paired proof uses a single independent
geometric parameter and derivatives of a common functional
at fixed finite coupling and scalar mass-difference degrees.
It gives a connected Ward identity at tree and one loop.
The proof uses the inherited paired forest bounds and shared
action and chart. General causal realization, quantum W6 and
E5/A5 are outside this calculation.
