# V890 — Background and geometric Ward identities in the paired connected map

With the actual light-vector affine shift v and the ordinary
evaluation-dual source variation, the connected background identity
is Ttilde_b W=∫jv. The fixed-A geometric identity is
Ttilde_q W+I^W_{C_source S_A}=∫jv. The second term is the derivative
in the whole E3 action direction. Both identities use the same
normalized, uncut paired Euclidean map as V887–V889 at tree and
one loop, at each fixed finite coupling and scalar mass-difference
degree and with a local smooth compact Fourier parameter test.

Two raw action routes recover the nonzero g² derivative and g³
homogeneous E3 terms. The 48,960 g³ rows have no remaining J leg.
All 7,800 homogeneous ordinary rows are off the diagonal.
The exact light mixed tree control gives a finite-cutoff defect
3/4 of the affine term at f=1/4. The reference determinant enters
once. Its general transverse derivative is nonzero, with Phi12
form-factor slope −1/(30 M) for squared mass M. The noncommuting
split fixture detects omission of both the pure reference and
the variation of the reference inverse.

Require the final replay receipt and capture. The calculations
share the action, charts, symbolic software and AI authorship.
No new normalization is fixed. The compact switched Ward
identity has its own currents. General causal realization,
quantum W6 and E5/A5 remain open.

Two staging corrections preserved the original bytes.
See the correction records in this packet.
