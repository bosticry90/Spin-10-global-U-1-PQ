# V890 pre-execution contract

Test the background and geometric connected Ward directions on
the uncut V887/V888 paired Euclidean map. Use the actual unprobed
643-coordinate parent, full fixed A for T_q, independent smooth
compact Fourier tests and one local even omega. Keep all fixed
finite g and scalar mass-difference degrees. Preserve the source
dual, affine ordinary source term, complete E3 whole source
correction and reference determinant. Keep the V874 switched
current separate. No new profile or normalization is adopted.

Bind both V879 current routes, frozen raw E3 and BV action rows,
V865 geometric columns, V869 reference and V887/V888. Reconstruct
the actual g2 derivative and g3 homogeneous source witnesses by
both A and source variation. Check the diagonal trace, actual
affine cutoff response, a split determinant derivative and the
nonzero inherited Phi reference response. Prove the paired limit
using the fixed-IR normalized affine defect and the independent
omega label. Use the whole action insertion and full rooted mean.

Freeze proof, worker and typed inputs before launch. Native 120 s,
final 180 s including E4 capped at 120 s, 8 GiB sampled private
bytes, 350 MiB launch commit floor, 8 MiB artifact, 32 MiB packet.
Preserve failures, require final exact replay, E4 with historical
custody separate, and exact staged bytes. Ceiling is the direct
paired Euclidean connected background and one geometric Ward
insertion at tree and one loop. General Lorentzian products,
compact-to-uncut equivalence, quantum W6 and E5/A5 remain open.
