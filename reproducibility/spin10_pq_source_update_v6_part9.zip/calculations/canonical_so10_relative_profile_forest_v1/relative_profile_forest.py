"""Verify a profile-sensitive forest on an actual ghost power core."""

import importlib.util
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def marked():
    path = ROOT / "calculations/canonical_so10_marked_profile_functional_v3/marked_profile_functional.py"
    spec = importlib.util.spec_from_file_location("marked_literal_owner",path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def actual(phase):
    source = marked().owner()
    directory = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = source.seagull.read(directory/f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    keys = {(4,583,618):[[],[],[0]],(4,573,628):[[],[0],[]]}
    selected = {}
    for grade,word,cells in rows:
        ids = tuple(i for i,_ in word)
        if grade==1 and ids in keys and [d for _,d in word]==keys[ids]:
            assert all(p[:2]==[0,0] for p,_,_ in cells)
            selected[ids] = source.seagull.unpack([([0,*p],n,d) for p,n,d in cells])
    assert selected == {key:-sp.S.Half for key in keys}
    odd = marked().sign(["C30","a20","C20","a30"],["C30","a30","a20","C20"])
    assert -odd*sp.prod(selected.values()) == -sp.Rational(1,4)

    directory = ROOT / "calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1"
    data = source.seagull.read(directory/f"{phase}_inverse.json.gz")["Greference"]
    entries = {(i,j):z for i,j,z in data}
    q = sp.symbols("q0:4")
    Q = sum(k*k for k in q)
    assert sp.cancel(sp.sympify(entries[583,628])-1/Q)==0
    assert sp.cancel(sp.sympify(entries[618,573])+1/Q)==0
    bridge = sp.sympify(entries[4,4])
    eta = sp.Symbol("eta_H")
    assert sp.cancel(bridge-1/Q-(eta-1)*q[0]**2/Q**2)==0
    return bridge,Q,q[0],eta


def forest():
    t,A1,A2,C,B0,B1,B2,H1,H2,p = sp.symbols("t A1 A2 C B0 B1 B2 H1 H2 p")
    D = A1/t+A2/t**2
    old = B0+t*B1+t**2*B2
    new = B0+t*H1+t**2*H2
    def finite(expr):
        regular = sp.cancel(t*t*expr)
        return sp.expand(sp.diff(regular,t,2).subs(t,0)/2)
    full = finite((D+C)*new-D*new)
    wrong = finite((D+C)*new-D*old)
    assert full == C*B0
    assert sp.expand(wrong-full-A1*(H1-B1)-A2*(H2-B2))==0
    assert finite(p*((D+C)*new-D*new))==p*full


def control(bridge,Q,q0,eta):
    t,ell,a,b,s,A1 = sp.symbols("t ell a b s A1",positive=True)
    c = 2*ell
    angular = 1/(64*sp.pi**2*c*t)
    schwinger = sp.integrate(s/(s+c*t)**3,(s,0,sp.oo))/(32*sp.pi**2)
    assert sp.simplify(angular-schwinger)==0 and angular==1/(128*sp.pi**2*ell*t)
    before = sp.diff(sp.exp(-a*t*Q)*bridge,t).subs(t,0)
    after = sp.diff(sp.exp(-b*t*Q)*bridge,t).subs(t,0)
    residue = sp.cancel(A1*(after-before))
    expected = -A1*(b-a)*(1+(eta-1)*q0**2/Q)
    assert sp.cancel(residue-expected)==0
    assert sp.cancel(residue.subs(eta,1)+A1*(b-a))==0
    assert sp.cancel(residue-residue.subs(eta,1))!=0


def check(phase):
    bridge,Q,q0,eta = actual(phase)
    forest()
    control(bridge,Q,q0,eta)
    for name in ("causal_one_loop_sewing","connected_marked_master_v1"):
        path = ROOT / ("calculations/canonical_so10_"+name) / "validation_receipt.json"
        receipt = json.loads(path.read_bytes())
        assert receipt["execution_state"]=="COMPLETED"
    return {"actual_core_signed_raw_color":"-g^2/4",
            "actual_core_radial_power":"1/(128*pi^2*ell_M*t)",
            "stale_bridge_leaves_nonlocal_proper_subdiagonal":True,
            "full_forest_retains_only_unheated_bridge":True,
            "paired_core_total_derivative_commutes":True,
            "admitted_marked_chain_terms_retained":6}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
