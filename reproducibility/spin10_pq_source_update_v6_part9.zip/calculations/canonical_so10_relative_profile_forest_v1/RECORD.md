# V980 pre-execution contract

Freeze COS1 one-loop causal sewing, V877 marked
rooted mean, V976–V979 relative profile results and
V791 literal free inverse. Construct the relative
heat conversion on the existing balanced cycle
kernels and their full forests. Keep the unheated
boundary and old T1 normalization. Test the relative
forest with an actual light vector bridge and
nonzero broken ghost power core in both exports.
Check proper-subdiagonal sensitivity, paired IR
ordering and retained marked chain terms. No new
connected or inverse-heat domain, extra loop order,
or independent Ward normalization adopted.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority change.
