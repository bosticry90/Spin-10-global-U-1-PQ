# Relative heat conversion of the admitted causal forest

Apply the V976–V978 relative difference to each
admitted COS1 balanced contracted core kernel,
with the same unheated boundary and field-independent
profile labels on its contracted slots. The change
is a finite local polynomial in the exterior
transfer jets on the core diagonal. Its scaling
degree is the existing one. Graded relabeling
holds at each finite cutoff by assigning the same
profile to the same typed edge under permutation.
A change of loop coordinates moves the whole
profile and jet polynomial together. The total
derivative on a vertex multiplies by its exterior
transfer, which is independent of the radial
operation. Thus it commutes with the relative
subtraction on these balanced jets. Keep the
whole distributional derivative at the core
and incident bridges.

Use COS1's independent cycle and bridge difference
coordinates. At each profile ell the connected
forest must use

    FP[(C_ell,t-D_ell,t) B_ell,t]
       = C_ell,FP B_0.

Here D_ell,t is the complete divergent core
counterterm and B_ell,t contains every regulated
bridge. The limit and paired IR removal use the
same admitted joint coefficient distributions.
The relative difference of the two forests is

    (C_ell,FP-C_ell0,FP) B_0.

Thus the relative local core map extends to its
proper subdiagonals by the full unheated forest.
Tensor and pullback use the COS1 linear
coordinates. With any core counterterm, its
finite-cutoff attached trees use the same
profile as the graph. Subtracting with the
old forest would miss the ordered sum of
A_ell,j times the changes of its bridge jets.
The relative kernel subtraction preserves
the existing causal sewing with the fixed
unheated off-diagonal boundary. It does not
define a new separated multi-insertion domain.
For a current-chart nonblind control use a
broken ghost power core with exterior light
B0 at both vertices. In the literal V879
current select B0 color 1, C30 partial0 a20
and B0 color 1, partial0 C20 a30. The two
source-free coefficients are -g/2 and -g/2.
The returning ghost pair is Ca and aC, with
opposite covariance signs. At zero core
transfer the signed ordered raw color
carrier is -g²/4 before the common loop
factor. Its hard radial basis is
q0²/Q². The two M edges have total length
2 ell_M and give a nonzero 1/t coefficient
1/(128 pi² ell_M) in that basis.

One exterior B0 can attach a light bridge.
In the current V791 frame its unheated
propagator is

    G00=1/Q+(eta_H-1) q0²/Q².

Hold the M core profile fixed while changing
the light length. Subtracting the old bridge
instead of the new one leaves

    -A1 (ell_H-ell0_H) [1+(eta_H-1) q0²/Q].

The second term is nonpolynomial in bridge
momentum and is supported on a proper
subdiagonal, not the total graph diagonal.
The eta_H=1 slice is blind to that component.
The calculation keeps the actual width
symbolic. This is a tagged forest control,
not a claim about the sum of all core
divergences. A correct full forest subtraction
removes it.

The old T1 initial term b[Z] remains on the
whole parent. The changed free quartet
coincident moments are homogeneous massless
powers at zero transfer, so their finite
parts are zero after the paired IR limit.
Scalar clocks stay fixed, including the
pure reference contribution to b. No second
b subtraction is introduced. On the V877
connected domain the converted tree is the
same unheated tree; the relative one-loop
shift is therefore evaluated graphwise on
the same rooted mean. In the beta-rho slot
retain all six chain terms, with the direct
and ordered covariance from V978 and the
four rooted derivatives in the V877 signs.
The result uses only the already admitted
compact graphwise substitution. It does
not extend the raw regulated Legendre
operation to arbitrary Schwartz means or
remove the explicit regulator term in V979.
Both routes share the action and software.
