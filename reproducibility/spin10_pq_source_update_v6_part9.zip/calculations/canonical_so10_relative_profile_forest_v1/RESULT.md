# V980 · Relative profile forest

The relative finite core correction extends through
the existing one-loop causal forest when the
divergent counterterm uses every bridge at the new
profile. The remaining relative change is the
local core change sewn to the common unheated tree.

Both action exports verify a tagged broken ghost
power core with a light temporal vector bridge.
Reusing the old bridge subtraction leaves the
nonpolynomial width-dependent term
`−A1 Δell_H (eta_H−1) q0²/Q` on a proper subdiagonal.
The full forest subtraction removes it.

The admitted V877 marked connected comparison
retains the same tree mean and all six chain terms.
The conclusion uses the inherited compact
graphwise domain and its old initial normalization.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
