"""Check literal transverse scalar source and regulator mass transport."""

from collections import defaultdict
import gzip
import importlib.util
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def owner():
    path = ROOT / "calculations/canonical_so10_scalar_source_transport_v2/source_transport.py"
    spec = importlib.util.spec_from_file_location("scalar_transport_owner",path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def literal(phase, source):
    _, entries, rho, f, _, _ = source.inputs(phase)
    directory = ROOT / "calculations"
    name = "native_v2" if phase=="native" else "replay_v4"
    physical = directory / "canonical_so10_physical_current_input_recovery_g1_v1"
    action = source.seagull.read(physical / f"{name}_action.json.gz")
    current = source.seagull.read(directory / "canonical_so10_unprobed_compact_all_coupling_v1" /
                                  f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    source_rows, field_rows, ghost_rows = {}, {}, {}
    positive_intrinsic = defaultdict(int)
    for g, word, cells in current:
        ids = [i for i,_ in word]
        if any(180<=i<508 or 823<=i<1151 for i in ids):
            if all(p[0]>0 for p,_,_ in cells):
                assert all(not jets for _,jets in word)
                positive_intrinsic[g,len(word)] += 1
                continue
            assert all(p[0]==0 for p,_,_ in cells)
            assert g==1 and len(word)==3 and all(not jets for _,jets in word)
            x,c,j = ids
            assert 180<=x<508 and 553<=c<598 and 823<=j<1151
            # The stored x C J_x order swaps its two odd factors at source-left.
            source_rows[c-553,j-823,x-180] = -source.seagull.unpack([([0,*p],n,d) for p,n,d in cells])
        if g==1 and len(ids)==3 and 0<=ids[0]<180 and ids[0]%4==2 and ids[1]==565 and 610<=ids[2]<643:
            antighost = ids[2]-598
            assert ids[0]//4>=12 and [d for _,d in word]==[[],[],[2]]
            ghost_rows[antighost,ids[0]//4] = source.seagull.unpack([([0,*p],n,d) for p,n,d in cells])

    assert dict(positive_intrinsic)=={(1,2):296,(2,3):6268}
    expected = {(a,i,j):z for a,R in entries.items() for (i,j),z in R.items()}
    assert len(expected)==12560
    assert source_rows=={k:-z for k,z in expected.items()}
    for word,cells in action["S1_scalar"]:
        (b,db),(i,di),(j,dj) = word
        assert not db and (di,dj) in (([b%4],[]),([],[b%4]))
        deriv,plain = (i,j) if di else (j,i)
        assert all(p[:3]==[1,0,0] for p,_,_ in cells)
        field_rows[b//4,b%4,deriv-180,plain-180] = source.seagull.unpack([([0,*p[1:]],n,d) for p,n,d in cells])
    assert field_rows=={(a,mu,i,j):z for (a,i,j),z in expected.items() for mu in range(4)}
    assert all(not f[h,12] for h in range(12))
    bracket = {(i,v):z for v in range(45) for i,z in f[v,12]}
    assert ghost_rows=={k:-z for k,z in bracket.items()}
    assert len(bracket)==56 and all(min(k)>=12 for k in bracket)
    assert sp.expand(sum(z*z for z in bracket.values()))==8

    compose = defaultdict(lambda:sp.S.Zero)
    for (i,v),z in bracket.items():
        for (row,col),val in entries[v].items():
            for out,m in rho[i].get(row,()):
                compose[out,col] += z*m*val
    assert source.clean(compose)=={ij:4*z for ij,z in entries[12].items()}
    counts = [sum(lo<=i<hi and lo<=j<hi for i,j in entries[12])
              for lo,hi in ((0,54),(54,306),(306,326))]
    assert counts==[98,700,20] and sum(counts)==len(entries[12])
    # The two odd fields in J_x x C exchange when the source is moved left.
    assert sp.expand((-1)*(-sp.I)*(2*sp.I)*(-1)*(-1)*4)==-8
    assert -(-8)==8
    return counts


def inverse(phase):
    path = ROOT / f"calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1/{phase}_inverse.json.gz"
    with gzip.open(path) as stream:
        d = json.load(stream)
    q = sp.symbols("q0:4")
    Q = sum(x*x for x in q)
    E,f = sp.symbols("E_profile f_profile")
    F = E*f
    keys = {(180,180),(234,234),(486,486),(565,610)} | {(520,48+mu) for mu in range(4)}
    rows = {k:{(i,j):sp.sympify(z) for i,j,z in d[k] if (i,j) in keys}
            for k in ("Greference","Pphysical","full_regulator","G_F")}
    for i, label in ((180,"Phi"),(234,"Sigma"),(486,"phi")):
        M = sp.Symbol(f"Mref_{label}_squared")
        assert rows["Greference"][i,i]==1/(Q+M)
        assert rows["Pphysical"][i,i]==Q
        assert sp.cancel(rows["full_regulator"][i,i]-((1/F-1)*(Q+M)+M))==0
        assert rows["G_F"][i,i]==F/(Q+M)
    assert rows["Greference"][565,610]==1/Q and rows["G_F"][565,610]==F/Q
    for mu, k in enumerate(q):
        assert rows["Greference"][520,48+mu]==k/Q
        assert rows["G_F"][520,48+mu]==F*k/Q
    p = sp.Matrix([1,2,0,0])
    v = sp.Matrix([2,-1,1,0])
    n = p+v
    T = sp.eye(4)-n*n.T/n.dot(n)
    assert T*v==-T*p and T*p!=sp.zeros(4,1)


def kernel():
    Q,M,m,F_s,F_g = sp.symbols("Q M m F_s F_g", positive=True)
    J = F_s*F_g/(Q*(Q+M))
    proper = F_s/(Q+M)-F_g/Q+m*J
    mixed = F_s*(1-F_g)/(Q+M)
    R_s = (1/F_s-1)*(Q+M)+M-m
    scalar = -R_s*J
    assert sp.cancel(proper-mixed-scalar)==0
    assert sp.cancel(scalar+F_g*(1-F_s)/Q-(m-M)*J)==0
    assert sp.cancel(proper.subs({F_g:1,F_s:1})-(m-M)/(Q*(Q+M)))==0
    assert sp.cancel((proper-mixed+((1/F_s-1)*(Q+M))*J).subs(m,0))!=0

    Lg,Ls = sp.symbols("ell_g ell_s",positive=True)
    c_Bs,c_Bg,c_3 = Lg+Ls,2*Lg,2*Lg+Ls
    clock = sp.expand_log(sp.log(c_3/c_Bs)-sp.log(c_3/c_Bg),force=True)
    assert sp.simplify(clock-sp.log(c_Bg/c_Bs))==0
    assert sp.simplify(clock.subs(Ls,Lg))==0 and sp.simplify(clock.subs(Ls,2*Lg)-sp.log(sp.Rational(2,3)))==0
    x,u,a,b = sp.symbols("x u a b",positive=True)
    assert sp.integrate(sp.integrate(sp.exp(-u*x),(x,0,sp.oo)),(u,a,b))==sp.log(b)-sp.log(a)


def mass_anchor():
    # Independent angular route, P=M=1. Write a=r^2+P, b=2r sqrt(P).
    # The four-dimensional angular integral is 3*pi/(8*max(r^2,P)^2).
    r,x = sp.symbols("r x",positive=True)
    lower = sp.integrate(r**3/(r**2+1),(r,0,1))
    upper = sp.integrate(1/(r*(r**2+1)),(r,1,sp.oo))
    parametric = sp.integrate(x*(sp.log(1+x)-sp.log(x)),(x,0,1))
    assert sp.simplify(lower-(1-sp.log(2))/2)==0 and upper==sp.log(2)/2
    assert sp.simplify(lower+upper-parametric)==0 and parametric==sp.Rational(1,2)
    return 3*parametric/(32*sp.pi**2)


def check(phase):
    counts = literal(phase,owner())
    inverse(phase)
    kernel()
    anchor = mass_anchor()
    return {"scalar_generator_nonzero_entries":counts,"literal_source_rows":12560,
            "literal_physical_cubic_rows":50240,"ordered_broken_pairs":56,
            "proper_mass_euler_multiplier":8,"full_scalar_and_mixed_roots_match":True,
            "mass_anchor_independent_angular_check":str(anchor),
            "equal_clocks_cancel_cutoff_offset":True,
            "discarding_reference_mass_fails":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
