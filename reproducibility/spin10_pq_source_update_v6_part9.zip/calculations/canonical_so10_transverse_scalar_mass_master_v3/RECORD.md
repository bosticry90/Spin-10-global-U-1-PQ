# V985 pre-execution contract

Freeze V984, V966, the actual V788 and V879
actions, both V791 inverse exports, and the
V951/V952/V959/V960 scalar sector comparisons.
Use the V966 e12, zero-p-p-incoming skew
projection at unit switch with ordinary BB
transverse and zero intrinsic grade. Keep one
invariant physical squared-mass Euler m and
the distinct positive squared reference M.
Derive the missing scalar-source triangle and
compare the two explicit regulator roots,
including the physical-reference defect.
Freeze the heat-clock and mass dependence
before comparing. Reject a match obtained
by fitting m, M or a finite shift.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority change.

## Version 2 continuation

The first worker failed on a guard applied to
the unspecialized V879 table. Preserve its
complete failed packet and launch capture.
The table contains 296 xi-positive x Lambda
rows and 6,268 xi-positive x C a rows.
Count and retain them in the input audit,
then project to the xi^0 coefficient already
specified in the original contract. Check
that no mixed power row evades the guard.
No physical input or acceptance scope changes.

## Version 3 continuation

The second worker failed because the guard
compared stored x C J_x rows directly to
source-left rows. All 12,560 raw rows have
+rho. Moving odd J_x past the ghost gives
the required -rho. Apply that parity in the
parser. The subsequent read-only diagnosis
also exposed a syntactic equal-clock test.
Simplify the exact log expression before
testing zero. Keep both prior failed packets.
The action, prediction and scope are unchanged.
