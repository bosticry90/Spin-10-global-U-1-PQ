# V985 result

The missing literal J_x scalar-source triangle has
color 4 rho_12 before its momentum factor and Wick
signs. It contributes the physical squared-mass
Euler term +8 m P J in the V966 transverse
e12 projection. The mixed and scalar regulator
roots together reproduce the full signed proper
kernel before finite parts.

In stripped units the finite value is

    3/(64 pi²) log(2 ell_M/(ell_M+ell_s)) + (m-M) J.

The reference mass M and the physical quadratic
Euler m are distinct. The mass contrast is carried
by the explicit regulator term. It is nonlocal
and persists when m and M differ. Equal heat
lengths eliminate the separate cutoff offset.
The angular and Feynman-parameter routes both
give J(1,1)=3/(64 pi²).

The first two workers failed on the projection of
xi-positive rows and on the raw-to-source-left
Grassmann sign. Both exact packets are preserved
on D:. The corrected V3 worker counts the excluded
xi-positive rows and verifies the ordered source
sign in both exports. The result is restricted to
the declared unit-switch transverse projection.
It uses the original action and common software.
