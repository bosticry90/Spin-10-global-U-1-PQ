# Transverse e12 scalar-source mass and regulator comparison

Use the V966 projection on exterior x(0), x(p),
C(-p), with P=p²>0. Select unit switch and
eta_H^0, xi^0, intrinsic degree zero in the
ordinary BB propagators and couplings. Keep
one invariant block physical squared-mass
Euler tag m, without a VEV. At m=0 this is
the V966 zero-intrinsic physical scalar mass
with its original distinct reference M>0.
Retain the ordinary reference mass and paired
profiles. There is no change of physical point.

In the action the scalar cubic is
g partial_mu x^t rho(B_mu) x. The original
scalar flow is -g rho(C)x. The literal source
port J_x x C has exactly that coefficient
when the odd J_x is moved to the left.
The scalar-source triangle pairs this port
with ordinary B C a and B x x. Use the
exterior source at momentum zero. The other
x assignment makes the transverse Bxx
endpoint zero. The ordinary gauge momentum
is q+p, while the scalar and ghost have
squared momentum Q=q². Orient the two scalar
ports with the transpose of the skew generator.
All ghost-antighost signs follow the actual
C-first orientation.

With the source left, the factors are -rho_i,
-i p_mu f_(i v 12) from F, and +2i p_mu rho_v
from the transversely projected Bxx. The
internal ghost crosses the exterior C once.
The scalar contraction uses rho_v^t=-rho_v.
There is one pairing of the distinct gauge,
ghost and scalar ports. The n=3 log sign is
positive. The actual color sum over ordered
i,v gives

    sum_(i,v) f_(i v 12) rho_i rho_v = 4 rho_12.

The 56 ordered pairs are all broken and have
squared bracket norm 8. Both exports give this
operator in all three ordinary scalar blocks.
The proper source coefficient is -8 P J
multiplying J_x^t rho_12 x(p), with J the
stripped massive product below. Applying the
mass Euler E_x(0)=m x(0) and reordering the
skew scalar bilinear gives +8 m P J in the
V966 orientation. Its zero-mass limit
disappears from the ordinary proper variation.

At zero intrinsic grade, the literal GF and
source table has only J_x x C with either x
or J_x. The physical kinetic seagull paired
with a purely gauge cubic has symmetric
external scalar color and drops out of the
skew projection. The ordinary three-gauge
triangle has a zero-momentum Bxx endpoint.
The BB Lambda cubic carrying exterior e12
vanishes since e12 commutes with H. The free
J_a column is linear and has zero Hessian.
Its g¹ x-free C_H a_M carrier cannot pair
through a scalar/ghost or scalar/auxiliary
mixed ordinary Hessian in this grading.
The remaining E_B, E_Lambda and E_C mean
fields do not enter this exterior projection.
The g0 regulated master row cancels on the
matched unit quartet. This support test
does not exclude longitudinal H contributions
at nonzero eta_H, physical higher intrinsic
mass matrices, or exterior switch derivatives.

The previously qualified linked seagull and
scalar wave terms carry +8 rho_12 W(P,M).
The lower gauge-source ghost term carries
-8 rho_12 W(P,0) in the corresponding
regulated weight. With the explicit mass
Euler the three terms use the common kernel

    K = p^t T(q+p) p/[P (q+p)²],
    F_B K [F_s/(Q+M)-F_g/Q+m F_s F_g/(Q(Q+M))].

F_B is evaluated at q+p and F_s,F_g at q.
The overall 8 rho_12 and exterior P are
stripped. The positive J integral has
integrand K F_B F_s F_g/[Q(Q+M)].

On the regulator side, the mixed root uses
the actual F_B gauge driver and E_(R,B) with
the differentiated Lambda pairing. V959/V960
fix the opposite root signs. The literal
Lambda-B inverse gives q/Q and the ordinary
transverse BB projection turns q into -p.
With matched mixed and ghost profiles this
root gives K F_B F_s (1-F_g)/(Q+M).
The other root uses F_x=-rho(C)x and the
actual scalar regulator

    R_s=(F_s^-1-1)(Q+M)+(M-m).

The internal ghost crosses exterior C once,
as on the J_x triangle. In the same skew
scalar ordering its effect is
-K F_B F_s F_g R_s/[Q(Q+M)], equal to

    K F_B [-F_g(1-F_s)/Q+(m-M)F_s F_g/(Q(Q+M))].

The zero-momentum x on a transverse scalar
endpoint eliminates the same ordinary
transverse root alternatives. Constant
mass is retained in E_(R,x); dropping it
would discard a genuinely nonlocal
difference. Combining the two roots
reproduces the proper kernel exactly before
finite parts. The comparison uses the full
paired scalar R, not the pure cutoff alone.

For the mass term the paired removal is
dominated at both separated poles and at
infinity. For the independent angular check, align p with
one axis and put a=r²+P, b=2r sqrt(P).
Integration by parts in the polar angle gives
integral sin^4(theta)/(a+b cos(theta))² dtheta
=3 pi/[8 max(r²,P)²]. Split the remaining r
integral at sqrt(P). At P=M=1 its two terms
are (1-log(2))/2 and log(2)/2 in units
3/(32 pi²), agreeing with the V952 Feynman
parameter result and checking a nonzero mass
contrast without cutoff normalization.
The weight is

    J=(W(P,0)-W(P,M))/M > 0,

with the common V952 subtraction. The
mixed and scalar cutoff roots have finite
differences L log(c_3/c_Bs) and
-L log(c_3/c_Bg), respectively, where
L=3/(64 pi²), c_Bs=ell_M+ell_s,
c_Bg=2 ell_M and c_3=2 ell_M+ell_s.
This follows by subtracting the common
hard Q^-1 radial tail and applying the
difference of positive exponential clocks.
Transfer jets of these degree-minus-four
kernels vanish from this finite difference.
At fixed paired IR regulator the terms
with positive large heat times have no
hard subtraction. Their remaining soft
terms are removed in the prescribed order.
The resulting finite difference is

    L log(c_Bg/c_Bs) + (m-M) J.

The cutoff term is mass independent and
vanishes for equal lengths. The remaining
nonlocal mass contrast agrees with the
explicit reference regulator term. This
explains the isolated V966 contrast in the
selected modified equation without using
it as a fitted condition. It leaves the
fixed-total-parent physical mass transport,
general compact backgrounds, the gauge
metric and the enlarged causal domain open.
Both exact routes share the underlying
action and symbolic implementation.
