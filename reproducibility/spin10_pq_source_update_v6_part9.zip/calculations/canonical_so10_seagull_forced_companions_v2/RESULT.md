# V924 result

The V923 unjetted gauge slot also acts on the physical scalar
seagull. It produces the derivative of the full mixed-block
gauge-orbit Gram quartic. In the two frozen vacuum directions
the quartic values are 15000 and 81/20. The V923 weight gives
a nonzero t³ cubic at the selected physical grade.

A connected box with three cubic kinetic vertices and the
scalar–auxiliary mixing produces the same tensor. Its finite
coefficient can cancel the cubic at unit switch, leaving a
nonzero t³(1-t) term. A fixed box coefficient cannot cancel the
cubic at every switch. Independent transfers give a nonzero
balanced symbol even at zero gauge width.

The new T contact and changed gauge weight also modify the
derivative kinetic jet. The two V921 balanced contact directions
still suffice for that ordinary projection. The recalculated
coefficients leave the derivative-free seagull unchanged.
The first verifier compared differently factored polynomials.
Its complete capture is preserved, and v2 checks their exact
expanded difference.

The compact master and common reference/source normalization
remain open. Both runs share physical inputs and arithmetic
software. No scientific authority change.
