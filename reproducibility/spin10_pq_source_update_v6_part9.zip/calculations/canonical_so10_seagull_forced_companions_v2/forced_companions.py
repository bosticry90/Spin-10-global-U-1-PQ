"""Check the ordinary companions forced by the V923 contacts."""

from collections import defaultdict
import importlib.util
from itertools import product
import sys

import sympy as sp

from execute import PK, ROOT, run_worker


OWNER = ROOT/"calculations/canonical_so10_gauge_scalar_seagull_residue_v1/seagull_residue.py"
SPEC = importlib.util.spec_from_file_location("seagull_owner",OWNER)
seagull = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(seagull)


def gram(columns):
    return {(a,b):seagull.dot(left,right) for a,left in columns.items()
            for b,right in columns.items()}


def scalar_gram(columns):
    out = defaultdict(lambda:sp.S.Zero)
    for v in columns.values():
        for (i,x),(j,y) in product(v.items(),repeat=2):
            out[i,j] += x*y
    return {key:sp.expand(value) for key,value in out.items()}


def cubic_checks(phase):
    role = "primary" if phase == "native" else "replay"
    root = ROOT/"calculations/canonical_so10_physical_current_input_recovery_g1_v1"
    data = seagull.read(root/("native_v2_coefficients.json.gz" if phase == "native" else "replay_v4_coefficients.json.gz"))
    frame = seagull.read(PK/"frozen_a10_physical_reconciliation"/f"full_{role}.json")
    vacuum = {x:sp.sympify(v) for x,_,v in frame["vacuum"]["VEV"]["entries"]}
    rho = {}
    for a,rows in data["rho"]:
        columns = defaultdict(list)
        for i,j,cells in rows:
            columns[j].append((i,seagull.unpack(cells)))
        rho[a] = columns
    mixed_mean = dict(vacuum)
    mixed_mean[5] = mixed_mean.get(5,0)+1
    mixed_mean[206] = mixed_mean.get(206,0)-2
    quartic, probes = {}, {}
    for name,(start,stop,_) in seagull.BLOCKS.items():
        v = {i:c for i,c in vacuum.items() if start <= i < stop}
        E = {a:seagull.apply(rho[a],v) for a in seagull.COLORS}
        assert all(not E[a] for a in range(12))
        assert any(E[a] for a in range(12,45))
        G = gram(E) if phase == "native" else scalar_gram(E)
        norm = sp.expand(sum(z*z for z in G.values()))
        assert norm > 0
        quartic[name] = str(norm)

        U_values = []
        for x in (v,mixed_mean):
            X = {a:seagull.apply(rho[a],x) for a in seagull.COLORS}
            G = gram(X)
            H = {(a,b):seagull.dot(E[a],X[b]) for a,b in G}
            U = sp.expand(sum(value*H[key] for key,value in G.items()))
            derivative = sp.expand(2*sum(value*(H[a,b]+H[b,a]) for (a,b),value in G.items()))
            assert derivative == 4*U
            # Compute the box with the other scalar pairing by swapping labels.
            box = sp.expand(sum(value*H[b,a] for (a,b),value in G.items()))
            assert box == U
            U_values.append(str(U))
        assert U_values[0] == quartic[name]
        probes[name] = U_values
    return {"quartic_vacuum":quartic,"cubic_probes_vacuum_mixed":probes}


def box_checks():
    K1,K2,K3,M = range(4)
    edges = [(M,K1),(K2,K3)]
    pairings = [[(M,K1),(K2,K3)],[(M,K2),(K1,K3)],[(M,K3),(K1,K2)]]
    connected = []
    for scalar in pairings:
        reached = {M}
        for _ in range(3):
            for a,b in edges+scalar:
                if a in reached or b in reached:
                    reached.update((a,b))
        connected.append(len(reached)==4)
    assert connected == [False,True,True]
    assert sp.Rational(4*2,2*4) == sp.Rational(6,2*3) == 1
    assert 3+2+2+2+3 == 4*3
    q = sp.eye(4)[:,0]
    k = sp.eye(4)[:,1]
    transverse = sp.eye(4)-k*k.T
    assert (q.T*transverse*q)[0] == 1
    t,a = sp.symbols("t a")
    assert not sp.solve(sp.Poly(-t**3+a*t**4,t).coeffs(),a)
    assert sp.expand(-t**3+t**4+t**3*(1-t)) == 0
    return {"box":{"connected_pairings":sum(connected),"width_zero_independent_momenta":"1",
                   "one_fixed_weight_cancels_all_switches":False,"net_unit_matched":"-t^3(1-t)"}}


def kinetic_checks():
    p,s,A,B = sp.symbols("p s A B")
    weights = {}
    for name,(_,_,C) in seagull.BLOCKS.items():
        beta = 4/(C-2)
        raw = (C-4)*(p+s/2)+4*beta*(2*p+s)+beta*(C-4)*p
        target = C*(p-2*s)
        polynomial = sp.Poly(sp.expand(raw+4*beta*(A*(p+s)+B*s)-target),p,s)
        solution = sp.solve(polynomial.coeffs(),(A,B))
        assert solution[A] == -sp.Rational(3,2)
        assert solution[B] == sp.Rational(1,2)-(5*C-4)/(8*beta)
        assert sp.expand(polynomial.as_expr().subs(solution)) == 0
        assert sp.expand(polynomial.as_expr().subs({A:-1,B:sp.Rational(1,2)-5*C/8})) != 0
        weights[name] = [str(solution[A]),str(solution[B])]

    # Trace the cubic gauge tensor before assigning the derivative.
    D = sp.symbols("D")
    p1,p2,p3 = sp.symbols("p1 p2 p3")
    traced = D*(p1-p2)+(p2-p3)+(p3-p1)
    assert sp.expand(traced-(D-1)*(p1-p2)) == 0
    return {"kinetic_weights":weights,"gauge_spectator_derivative_trace":"0"}


def check(phase):
    return cubic_checks(phase) | box_checks() | kinetic_checks()


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
