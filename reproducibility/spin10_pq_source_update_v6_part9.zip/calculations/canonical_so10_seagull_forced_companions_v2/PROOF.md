# Ordinary companions of the background seagull contact

## The forced cubic

Use the normalized Q and T contact directions of V923 with
their already fixed relative weights. The unjetted BB slot
of Q also accepts the physical scalar seagull, with both B
ports contracted. Let x include all ordinary scalar blocks,
X_a=rho_a x, E_a=rho_a v_s, and G(x)_(ab)=(X_a,X_b).
The color quartic I(x)=tr G(x)² is invariant under the full
joined global action. Define U_s(x)=sum_(a,b) G(x)_(ab)
(X_b,E_a). Then D_(v_s) I=4 U_s. This follows by
differentiating both Gram factors and using their symmetry.
It retains the mixed-block terms of G.

In the positive hard chart the Lorentz trace of the scalar
seagull BB Hessian is D G(x)_(ab), suppressing g².
The trace of the gauge seagull used to normalize Q in V923
was -(D-1) ad_B². Keeping the same contact tensor, the new
coefficient in the normalized Q basis is

    -(D/(D-1)) sum_(a,b) G(x)_(ab) x^t rho_b E_a
      = (D/(D-1)) U_s(x).

There is no extra factor for the two B slots because this
is the Hessian. Thus the V923 choice delta=-1 forces
-4 U_s(x)/3 at D=4, times t³ and the V923 common block
coefficient g⁴ xi (2 C_s-8)L_s/C_s. This is a scalar
cubic without a derivative, not an adjustment of an
independent tree scalar coupling. Its H covariance follows
from invariance of I and the H-fixed v_s. It does not
remove the compact master question under the broken
generators.

Set all scalar means outside s to zero and x=v_s. The
native gauge-color Gram-square contraction gives U_Phi=15000
and U_Sigma=81/20. The replay computes the same invariant
as the scalar-space Gram-square contraction. They also
check the quartic derivative and both scalar pairings on
an actual mixed-block mean. The stripped forced cubic
coefficients are therefore -20000 and -27/5 before
multiplying their independent L_s factors. The distinct
positive reference masses prevent both terms from
vanishing for any common kappa.

The proposed derivative contacts have no nondifferentiated
pure scalar cubic in this projection. The T contact needs
a remaining vector on its final derivative-free kinetic
replacement or a derivative on its scalar spectator.
At the selected physical g⁴ xi grade independent tree
potential and Yukawa coefficients cannot be divided out.
The ordinary three-vertex scalar cubic with one mixing
requires a Bxx and a B²xx vertex. Consuming all their
B ports forces the Q topology. This is a check of the
specified contraction patterns, not a classification
of every possible local tensor.

## A box carrier and its switch limitation

A fourth-order local direction uses M and three Bxx
vertices. Each kinetic vertex consumes its B and one
scalar, leaving one ordinary scalar. Fix the mixed
edge M--K1 and the ordinary BB edge K2--K3.
Of the three pairings of four scalar ports, two give
connected cycles and differ by interchange of K2,K3.
The third gives two separate loops and is excluded.
The opposite cycle traversal has the same even product.
The four placements of M and the two port orientations
combine with the 1/(2*4) trace factor to give the same
unoriented count as the distinct-vertex triangle
(6/(2*3)). In the cyclic convention the overall
trace-log sign changes between three and four vertices.
Absolute finite contact coefficients can instead be
specified in the signed U_s basis.

The two scalar lines pair (X_a,X_b) and (X_b,E_a),
so the whole tensor is U_s(x), with the same mixed-block
sum as above. The three internal derivatives are the
relative B,x derivatives. A total derivative at a
kinetic vertex or a derivative on its spectator does
not contribute to this zero-jet contact. The degree
is 3+2+2+2+3=12 in twelve relative dimensions, allowing
a full-diagonal delta contact. The common-ray numerator
contains the ordinary longitudinal width. At independent
transfers the two scalar momenta paired through that
BB line can be parallel to each other and orthogonal to
the gauge momentum. This gives a nonzero transverse
symbol at width zero. As in V923 an absolute local
coefficient in the balanced jet can be considered
without dividing by width. The complete normalized
gauge and quadratic agreement constraints remain open.

The box has switch degree four. Each of the three
kinetic slots needs an ordinary B,x pair, so no reference
Axx replaces one on this scalar-only projection.
Normalize its finite coefficient to cancel the cubic
at unit switch. It then leaves -t³(1-t) times the same
nonzero cubic coefficient in positive Q units. No one
fixed box weight cancels the t³ term for all switches.
A changed compact master insertion and other finite
directions cannot be inferred from the unit match.

## Recomputed derivative companion

The T kernel takes an undifferentiated mixed B,x Hessian.
At a physical Bxx vertex its matching derivative must
be on the residual scalar. Replacing the seagull mixed
row -x^t{rho_a,rho_B} by the differentiated residual row
therefore gives

    -(partial x)^t sum_a rho_a rho_B E_a
      = (C_s-4) (partial x)^t rho_B v_s

in the T color convention. Its degree-eight delta
contact gives p in the V921 notation with no additional
switch gradient. A reference Axx final vertex would
replace rho_B v_s by rho_A v_s, which vanishes for H.

The unjetted BB slot of Q can see a cubic gauge vertex
only with its derivative on the residual vector.
The Lorentz trace of the cubic tensor is
(D-1)(p1-p2)_mu. Thus its residual derivative and
its total two-port derivative have no trace component.
The linear reference Weyl connection has the same
balanced trace; a derivative of the external A does
not provide a two-B trace with its skew color
coefficient. Q adds no derivative term in this
projection. The other derivative coefficients are
those checked in V921. At linear background degree
their direct reference substitutions have the
orbit coefficient E_A=0 in each block.

Set beta=gamma=4/(C_s-2) as fixed in V923. At equal
switch labels the raw first-jet symbol is

    (C_s-4)(p+s/2) + 4 beta(2p+s) + beta(C_s-4)p,

where s denotes one switch gradient. The canonical
target for w=t²u_s is C_s(p-2s). Use the same two
balanced derivatives of V921, now in the new
beta-scaled gauge units. They add
4 beta [A(p+s)+B s]. The unique projected solution is

    A = -3/2,   B = 1/2 - (5 C_s-4)/(8 beta).

Thus B=-11 for Phi and -2393/128 for Sigma. The old
V921 coefficients fail after the V923 weights change.
These two local contact changes preserve the
nonderivative reference and physical seagull
projections and respect the selected relative versus
total derivative assignment. They do not impose the
other finite-map, master or source constraints.

This resolves the specified ordinary first jet and
identifies the pure scalar companion, including an
actual unit-switch cancellation direction with a
remaining compact term. Native and replay share
physical inputs and arithmetic software. No new
loop integral, physical parameters or authority.
