# V924 pre-execution contract

Compute the forced scalar cubic and one-derivative kinetic terms
of the V923 local contact proposal. Keep the V923 seagull and
potential basis weights. Determine whether the V921 balanced
derivative freedom covers the new kinetic terms without inverse
parameters or zero-jet changes.

For the scalar cubic require the full mixed-block quartic derivative,
exact joined vacuum controls in two contractions, and the actual
three-kinetic-vertex plus scalar–auxiliary box. Check port graph
uniqueness, multiplicity, degree, gauge width zero with independent
transfers, and whether the box can cancel the forced cubic for all
switches or only at unit switch. No new loop integral or claim
that the entire common map has been normalized. Record the compact
remainder and separate the master test from the derivative result.
No authority change.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.

## V2 continuation after native failure

The first run stopped at a structural comparison between t³(t-1)
and -t³(1-t). Compare the expanded polynomial difference to zero
and use the same expansion in the old-contact negative control.
The full failed native packet and capture remain bound in the
original control record. No scientific or effort gate changes.
