# Full scalar translation and common causal normalization

## Compact action completion

Let S=S_A be the full uncut source action, R=R_A the fixed
reference, and P=R+sigma(S-R). Use the V882 physical units, with
the common loop coefficient understood. For scalar block s set

    u_s = g² xi (2 C_s-8) L_s v_s,   w = sigma² u,
    D_w = integral w . E_x,         N = D_w S.

D_w is a field-independent scalar translation with prolonged jets,
and N retains the physical scalar potential, gauge and source
terms. It is local, real in the physical chart and of dimension four.
L_s are fixed-reference logarithms and no inverse physical coupling
or mass is introduced into N. The exact Euler decomposition is

    e = E_x[sigma(S-R)] - sigma E_x(S-R),
    N = D_w P + E,
    E = integral w . [(1-sigma) E_x(S-R) - e].

With ordinary sources j in source-first order, the first-loop
connected correction is N(phi_0), where phi_0 is the original
tree stationary field. Thus D_w P(phi_0)=-integral w.j_x.
This term is zero after restricting to the ordinary ghost source
pair, and is present when testing independent ordinary scalar
sources. The canonical insertion x->x+hbar w supplies the opposite
source contact, derived from the same field substitution.

For the V915 unmarked comparison at A=J=j_x=0, even stationary
fields start at degree two in the two odd sources. The uncut
physical potential has no linear term in the unshifted fields.
Its Euler cubic and higher terms, and terms quadratic in even
fields, have no two-ghost source derivative there. Fermion
ordinary roots vanish. The ordinary scalar quadratic
physical-minus-reference Euler is retained in E, and excluded
from the selected numerical test by its independent positive
mass-difference degree. The scalar–auxiliary linear term gives
zero in direction w since E_s v_s=0. The same orthogonality keeps
the switched radial scalar inverse independent of the
scalar–auxiliary mixing, so the competing gauge–ghost tree cannot
feed the w source. These are ordinary restrictions on the
coefficient after taking its relevant derivatives.

In the Lorentz chart the principal quadratic density difference
is div(x . partial x)/2. Its switched Euler is e=(Box sigma)x/2
on the selected scalar sector. Move the exact symmetric massive
Feynman bridge onto w Box sigma/2 and keep the original sequential
boundary. In rescaled coordinates this is a fixed smooth compact
test with all finite seminorms O(R^-2). The V908 expansion maps
it to O(R^-2) on the support of the remaining Y switch. The V911
exterior pairing costs at most O(1+log R) with the existing
Schwartz tail control. The switch-jet contribution tends to zero.
At mass-difference degree zero the remaining term is

    sigma²(1-sigma) u . (g² xi a Y C)
      = -g⁴ xi² sigma²(1-sigma) a^t m C.

Here m=sum_s L_s YY_s and the V275 identities are checked on the
full ordered color tables. This has the same source-sewing sign
as V915 and cancels its selected profile difference.

For a constant patch sigma=t, in a block with physical squared
mass M+d, the two-source tree response in the mass-only
projection gives the correction factor M/(M+t d) relative to
the zero-mass-difference contact. The denominator is an inherited
tree inverse, understood as a formal series in d around positive
M. The retained d term is consequential. This check supplies no
nonzero-d profile comparison.

## Marked and geometric directions

D_w is canonical for the ordinary-field/retained-source bracket
with the V900 signed Euler convention. It commutes with this
bracket because w is independent of all canonical fields and
sources. Prolonged derivatives include the jets of w. For the
same compact marked parent P_rho=P+rho K_sigma, literal scalar
directions in both the raw and epsilon-normal K contract to
zero with v_s. Thus D_w K_sigma=0. Inserting N at one loop
amends the master insertion by B'_P_rho[N]. On the common marked
family it splits as

    B'_P_rho[N] = D_w B[P_rho] + B'_P_rho[E].

Use its ordered LEFT mark derivative and all stationary-root
derivatives when transporting the connected coefficient. The
replacement is made in the actual local parent before sewing.
At unit switch with positive switch jets set to zero, E=0 and
the master direction is the canonical transport of the uncut
one. This is a statement on the local formal specialization.

The ordinary scalar part of the background and geometric
transformations is homogeneous H action with H-fixed u. Their
affine part is supported on B_H and the retained source
homogeneous action is the evaluation dual. Consequently the
scalar translation commutes with both field transformations and
their jet prolongations. The E3 correction C has no x or J_x
dependence in its own coefficients/directions, and its unmarked
whole action direction CS equals the background variation of S
from V879. The complete unmarked W and CS direction tensors have
no x or J_x ports. Thus D_w(CS)=0 and D_w(T_A S)=0. The integrated
background and geometric equations for the added unmarked
action follow by differentiating those of S. Retain the existing
compact Ward currents and the whole action and source insertions
on differentiation. The marked comparison checks the scalar
translation on K and gives the corresponding differentiated
parent direction. It supplies no new quantum loop or general
renormalized product construction.

## Two tests of identification with a causal finite map

For the full canonical field and source replacement, the unit
specialization sends a linear scalar insertion J_j to
J_j+integral j_x.u. This extra field-independent term depends on
the source and survives normalized connected subtraction at j=0.
For a compact probe along v_s with unit integral it is
g² xi L_s times 720 or 51/5 in Phi or Sigma. At distinct reference
masses these two coefficients cannot both vanish. In the fixed
COS1 causal normalization a linear ordinary vertex cannot be
on a loop core and its tree bridges are inherited. A one-loop
local action map has no additional contact with such a vertex.
This agrees with the linear-field condition in Theorem 8(ii)
of Dütsch and Fredenhagen, arXiv:hep-th/0403213. The full
replacement therefore needs the separate canonical source
transport and cannot itself be that fixed-equation finite map.
This exclusion concerns the unchanged ordinary-field equation.
It does not exclude a separate W6/A5 replacement with all its
obligations established.

There is also an obstruction to obtaining the exact action N
alone from the actual contraction-supported COS1 family. Work on
an arbitrary constant patch sigma=t and compare t² coefficients
with all positive switch jets zero. In a Taylor expansion of a
map on the interaction, T1 is fixed and t² at one loop uses T2.
Higher arity terms have higher t degree. On each block take the
coefficient linear in its independent lambda_s self-quartic.
The actual norm quartic is -lambda_s (x_s.x_s)² in the action.
At x_s=b v_s the t² cubic coefficient of N is

    -4 t² b³ g² xi lambda_s (2 C_s-8)L_s ||v_s||⁴.

The stripped numbers are -172800 L_Phi and -612 L_Sigma/25.
At least one is nonzero for every common kappa at distinct
reference masses. To get a pure scalar cubic with the
quartic input at T2, the other input must have exactly three
field slots and both parallel cycle edges must be scalar.
The actual no-self-edge Wick kernels pair the quartic's scalar
ports only with scalar ports. A gauge–scalar cubic has a gauge
spectator, a Yukawa cubic has insufficient scalar ports, and the
scalar–ghost vertex likewise has only one scalar port. The only
pure scalar cubics have the independent coefficients muPhi,
muPhiPhi and z6. Specialize those to zero without changing the
quartic tag. Polynomial normalization coefficients cannot
remove the independent cubic coupling. Thus the exact action N
is outside this fixed graph-supported realization even with
ordinary sources removed. Contact terms on absent kernels and
a different correlated correction are separate possibilities.

These tests distinguish the action-level existence, the
specified finite-map exclusions and the open common quantum
construction. No new loop integration or physical parameter
value is used. The two executions share the theory, frame,
arithmetic software and analyst, with separate frozen exports.
