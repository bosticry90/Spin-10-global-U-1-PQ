"""Exact frame, source and stationary checks for the completed translation."""

from collections import defaultdict
import gzip
from itertools import product
import json
import sys

import sympy as sp

from execute import PK, ROOT, run_worker


BLOCKS = {"Phi": (0, 54, 12), "Sigma": (54, 306, 17)}
COLORS = range(45)
SCALARS = range(180, 508)


def packet(name):
    return ROOT / "calculations" / f"canonical_so10_{name}"


def read(path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == ".gz" else data)


def add_cells(output, key, cells, scale):
    for grade, num, den in cells:
        output[key, tuple(grade)] += sp.Rational(num, den) * scale


def scalar_variation(rows, vacuum, predicate):
    coefficients = defaultdict(lambda: sp.S.Zero)
    words = 0
    for grade, word, cells in rows:
        if not predicate(word):
            continue
        for i, (slot, jets) in enumerate(word):
            if slot not in SCALARS:
                continue
            words += 1
            block = "Phi" if slot < 234 else "Sigma"
            key = (block, grade, tuple(jets),
                   tuple((k, tuple(js)) for k, js in word[:i] + word[i + 1:]))
            add_cells(coefficients, key, cells, vacuum.get(slot-180, 0))
    assert words
    assert all(sp.expand(value) == 0 for value in coefficients.values())
    return words


def actual_checks(phase):
    role = "primary" if phase == "native" else "replay"
    vacuum = {x: sp.sympify(value) for x, _, value in read(
        PK / "frozen_a10_physical_reconciliation" / f"full_{role}.json")["vacuum"]["VEV"]["entries"]}
    poles = read(packet("ghost_mass_g4_pole") / f"{role}_v2_result.json")
    orbit = {(a, x): sp.sympify(value) for a, x, value in poles["physical_E"]}
    y = {(x, a, c): sp.sympify(value) for x, a, c, value in poles["physical_Y_aC_density"]}
    witnesses, norms = {}, {}
    for name, (start, stop, weight) in BLOCKS.items():
        norm = sum(vacuum.get(x, 0)**2 for x in range(start, stop))
        assert norm > 0
        witnesses[name] = str(-4 * weight * norm**2)
        norms[name] = str(norm)
        for a in COLORS:
            assert sp.expand(sum(orbit.get((a, x), 0)*vacuum.get(x, 0)
                                 for x in range(start, stop))) == 0
        yy = {(a, c): sp.sympify(value)
              for a, c, value in poles["physical_scalar_sector_family_poles"][name]["YY"]}
        for a, c in product(COLORS, repeat=2):
            shift = sum(vacuum.get(x, 0) * y.get((x, a, c), 0)
                        for x in range(start, stop))
            assert sp.expand(weight * shift + yy.get((a, c), 0)) == 0

    file = "native_v2_coefficients.json.gz" if phase == "native" else "replay_v4_coefficients.json.gz"
    potential = read(packet("physical_current_input_recovery_g1_v1") / file)["potential_scope"]
    cubics = sorted(row["term_id"] for row in potential if any(a[0] == 3 for a in row["all_arities"]))
    assert cubics == ["potential_muPhi", "potential_muPhiPhi", "potential_z6"]
    for block in BLOCKS:
        invariant = next(row for row in potential if row["term_id"] == "potential_lambda" + block + "1")
        assert invariant["all_arities"] == [[4, 0, 0, 0]]

    chart = read(packet("unprobed_compact_all_coupling_v1") / f"{phase}_full_current.json.gz")["current"]
    support = {}
    for name in ("complete_W", "complete_CS"):
        rows = chart[name]
        assert not any(slot in SCALARS or slot - 643 in SCALARS
                       for _, word, _ in rows for slot, _ in word)
        support[name] = len(rows)
    support["auxiliary_scalar_words"] = scalar_variation(
        chart["complete_S_GF_source"], vacuum,
        lambda word: any(508 <= slot < 553 for slot, _ in word))

    marks = read(packet("marked_geometric_primitive_transport_v1") /
                 f"{phase}_complete_marked_geometric_transport.json.gz")
    for name in ("complete_K", "complete_K_normal"):
        support[name] = scalar_variation(marks[name], vacuum, lambda word: True)
    return {"potential": {"witness_coefficients": witnesses, "vacuum_norm_squared": norms,
                          "scalar_cubic_parameters": cubics},
            "ward_support": support, "translation_color_positions": 4050}


def stationary_checks():
    t, x, j, u, Y, M, d = sp.symbols("t x j u Y M d")
    S = -(M+d)*x**2/2 + Y*x
    R = -M*x**2/2
    P = R + t*(S-R)
    w = t**2*u
    N = w*sp.diff(S,x)
    root = (j+t*Y)/(M+t*d)
    difference = sp.expand(N-w*sp.diff(P,x)-w*(1-t)*sp.diff(S-R,x))
    assert difference == 0
    response = sp.cancel(N.subs(x,root))
    assert sp.cancel(response.subs(j,0)-t**2*u*(1-t)*M*Y/(M+t*d)) == 0
    assert sp.cancel(response.subs(d,0).subs(j,0)-t**2*(1-t)*u*Y) == 0
    assert sp.cancel(response.subs(t,1)+u*j) == 0
    assert sp.cancel(response.subs(j,0)-response.subs(j,0).subs(d,0)) != 0

    # Independent check of the linear-source shift by explicit substitution.
    ell = sp.symbols("ell")
    translated = (S+j*x).subs(x,x+ell*u)
    fixed_source = S.subs(x,x+ell*u) + j*x
    assert sp.expand(translated-fixed_source) == ell*u*j
    assert sp.cancel(sp.diff(fixed_source,ell).subs({ell:0,x:root.subs(t,1)})+u*j) == 0

    # Euler derivative of sigma ∂(x∂x)/2 after one integration by parts.
    X, X1, s1, s2 = sp.symbols("X X1 s1 s2")
    after_ibp = -s1*X*X1/2
    momentum = sp.diff(after_ibp,X1)
    derivative = sp.diff(momentum,s1)*s2 + sp.diff(momentum,X)*X1
    assert sp.expand(sp.diff(after_ibp,X)-derivative) == s2*X/2
    assert sp.diff(after_ibp,X) != s2*X/2
    return {"constant_patch": {"zero_mass_difference_residual":"0",
                               "relative_contact_factor": "M/(M+t*d)",
                               "switched_kinetic_euler": "(Box sigma)*x/2"},
            "ordinary_source": {"fixed_source_unit_shift": "-u*j_x",
                                "canonical_shift_requires_source_contact": True}}


def check(phase):
    return actual_checks(phase) | stationary_checks()


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
