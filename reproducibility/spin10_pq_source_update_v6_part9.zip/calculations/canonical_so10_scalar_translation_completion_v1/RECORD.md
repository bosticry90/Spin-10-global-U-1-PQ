# V918 pre-execution contract

Test the V917 full scalar-translation completion N = D_w S at
one loop, with S the actual uncut parent, w = sigma² u and the
V916 scalar displacement u in fixed reference units. The question
is whether the amended compact family cancels V915 when all
scalar, source and switch companions are retained, and whether
the same completion is a common causal finite map.

Require the stationary decomposition and retained switch-jet
estimate, the projected constant-patch mass-difference control,
and the common marked/master/geometric transport with independent
ordinary sources. At zero scalar mass-difference degree, retain
V915 colors, profiles, gauge grade and sequential boundaries.
Compare native and replay literal scalar support and marks. Test
the separate linear-source and actual T2 pure-scalar cubic
obstructions. Keep polynomial parameters, reality, the inherited
linear-field equation and actual no-self-edge Wick kernels.
Reject a broader equivalence inference if any test is restricted.
No physical benchmark, full weak limit or protected promotion.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.
