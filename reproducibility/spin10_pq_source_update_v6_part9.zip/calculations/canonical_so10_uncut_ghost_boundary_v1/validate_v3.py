"""Final V883 review with the authenticated STS receipt's own schema."""

import ast
import json
import os
import subprocess
import sys
import threading
import time
from hashlib import sha256
from pathlib import Path

from execute_v2 import BASE, CONTROL, HERE, NAV, PK, ROOT, digest, git, prepare, read, save
from ghost_boundary_v2 import checks


def review(check, prep, started):
    assert not git("diff", "--cached", "--name-only")
    assert git("ls-tree", "-r", "HEAD") == (CONTROL / "old_git_tree.txt").read_bytes()
    for name in ("preparation_native_v2.json", "capture_native_v2.json", "result_v2.json"):
        assert (HERE / name).read_bytes() == (CONTROL / name).read_bytes()
    cap = read(HERE / "capture_native_v2.json")
    assert cap["calculation_completed"] and cap["post_run_observations_qualified"]
    for source in HERE.glob("*.source.txt"):
        assert source.read_bytes() == (HERE / source.name.removesuffix(".source.txt")).read_bytes()
    owners = sorted(n for n in prep["sha256"] if "validation_receipt" in Path(n).name and n.endswith(".json"))
    for name in owners:
        owner = read(ROOT / name)
        if name == "calculations/canonical_so10_scalar_tadpole_sewing/final_review_validation_receipt.json":
            assert owner["evidence_validation"] == "PASS_BOUNDED_SCALAR_TADPOLE_AND_SELECTED_FIVE_TERM_EXTENSION"
            assert owner["E4_step_exits"] == [0, 0, 0, 0, 0, 2]
            assert owner["custody"] == "EXIT2_SEVEN_UNRESOLVED_NOTPASS"
            assert owner["scientific_acceptance"] == "NOT_PERFORMED"
        elif "execution_state" in owner:
            assert owner["execution_state"] == "COMPLETED", name
        else:
            assert owner["status"].startswith("PASS_BOUNDED_"), name
    result = read(HERE / "result_v2.json")
    assert result["execution_state"] == "COMPLETED"
    checks = result["checks"]
    assert checks == check("replay")
    assert checks["raw_support"]["raw_mixed_B_external_H_ghost_exact_divergences"] == 1336
    assert checks["actual_tadpole"]["trace_nonzero_by_blocks"] == [4, 16, 0]
    assert checks["actual_tadpole"]["row12_unpaired_residual_leading_in_epsilon_squared_over_M"] == -7
    assert checks["transferred_kernels"]["FFMM_at_p_squared_equal_M"] == "0"
    assert checks["transferred_kernels"]["massless_log_J_coefficient"] == "1/M"
    print("STAGE independent owner replay and exact profile checks agree", flush=True)

    command = [sys.executable, "-B", "tools/research_check.py", "e4", "--historical-context",
               "D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4"]
    try:
        e4 = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=120)
    except subprocess.TimeoutExpired as err:
        save("e4_timeout_v3.json", {"command": command, "state": "INCOMPLETE_TIMEOUT",
                                 "stdout": (err.stdout or b"").decode("utf-8", errors="replace"),
                                 "stderr": (err.stderr or b"").decode("utf-8", errors="replace")})
        raise
    save("e4_capture_v3.json", {"exit_code": e4.returncode, "stdout": e4.stdout, "stderr": e4.stderr})
    events = [json.loads(line) for line in e4.stdout.splitlines() if line.strip()]
    steps = [event for event in events if event.get("event") == "step_finished"]
    exits = [event["exit_code"] for event in steps]
    assert e4.returncode == 0 and exits == [0, 0, 0, 0, 0, 2]
    custody = next(event for event in steps if event["step"] == "historical_custody")
    assert custody["stdout"].count("RECORDED_DIGEST_UNRESOLVED:") == 7
    hist = git("show", "ef70f255a667b9a81e37b344dc78967ada4ed896:README.md")
    assert sha256(hist).hexdigest() == "4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792"
    assert (ROOT / "README.md").read_bytes().replace(b"\r\n", b"\n").endswith(hist)
    state = digest(ROOT / "project_state.json")
    assert state == "d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8"
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    files = [p for p in HERE.iterdir() if p.is_file()] + [ROOT / name for name in NAV]
    save("validation_receipt_v3.json", {"base_HEAD": BASE, "execution_state": "COMPLETED",
         "evidence_validation": "PASS_SELECTED_GROUPED_PAIRED_GHOST_AND_LOCAL_FEYNMAN_BOUNDARY",
         "scientific_acceptance": "NOT_PERFORMED", "state_sha256": state,
         "E4_step_exits": exits, "historical_custody": "SEVEN_UNRESOLVED_NOTPASS", "owner_receipts": owners,
         "checks": checks,
         "files_excluding_pending_receipt_capture": {p.relative_to(ROOT).as_posix(): digest(p) for p in files},
         "elapsed_after_imports": time.perf_counter() - started})


def main():
    phase = sys.argv[1]
    if phase == "controller":
        for name in ("VALIDATION_V3.md", "validate_v3.py"):
            raw = (HERE / name).read_bytes()
            if name.endswith(".py"):
                ast.parse(raw)
            with (HERE / (name + ".source.txt")).open("xb") as snapshot:
                snapshot.write(raw)
        prepare("validation")
        sys.path.insert(0, str(PK))
        from export_a10_e5_antighost_vector import capture

        report = capture([sys.executable, "-B", str(HERE / "validate_v3.py"), "worker"])
        save("capture_validation_v3.json", report)
        print(report["stdout_and_stderr"], end="")
        assert report["calculation_completed"] and report["post_run_observations_qualified"]
        assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file()) <= 32 * 1024**2
        return
    assert phase == "worker"
    started = time.perf_counter()
    prep = read(HERE / "preparation_validation_v2.json")
    timer = threading.Timer(prep["limits"]["seconds"], lambda: os._exit(124))
    timer.daemon = True
    timer.start()
    assert git("rev-parse", "HEAD").decode().strip() == BASE == prep["base_HEAD"]
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    review(checks, prep, started)
    timer.cancel()


if __name__ == "__main__":
    main()
