# V883 V2 input-representation count correction

V1 stopped at the LambdaBB row-count check. The expected count 720
was taken from the portable raw density, while the worker reads the
V865 joined full-source inputs. Both V865 routes contain 1,336 rows
in this slice. All 1,336 satisfy the original no-jet heavy-auxiliary
and H/M gauge-cross conditions. V2 corrects the expected count to the
one in the bound representation and keeps the complete support test,
analytic scope, other assertions and resource limits. Preserve the
V1 bytes and failed capture.
