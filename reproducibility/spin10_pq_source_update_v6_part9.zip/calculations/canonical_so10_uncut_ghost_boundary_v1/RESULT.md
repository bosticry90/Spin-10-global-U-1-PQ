# V883 — The selected grouped ghost boundary exists with paired regulators

Keeping the massive scalar root and pairing the inner and outer
massless IR regulators gives a local uncut connected limit for the
ordinary two-ghost-source response at one loop, g⁴ ξ², and zero scalar
mass-difference degree. It uses the same symbolic κ and converted
UV prescription. The scalar tadpole cancels the constant proper
response. The full transferred kernel, including external-derivative
FMY and FFMM paths, has size O(p²(1+|log |p||)). The inner cutoff error
is O(ε²), sufficient after sewing the two outer branches. Exact native
and replay inputs test 1,336 raw divergence triplets, the actual
scalar one-port trace, and the independent radial reductions.

Arbitrary independent IR limits fail. At fixed positive inner cutoff,
the color-12 constant retains a definite nonzero remainder, with
leading coefficient −7 ε²/M_Sigma in the stripped radial units.
Removing the outer cutoff first exposes a logarithm. Taking equal
cutoffs removes it. This depends on the finite massless tadpole
artifact, which is kept through sewing.

The grouped analytic coefficient also has a separate local common
Feynman boundary across the massless cone and its tip. The two
propagators and the proper logarithm use one boundary variable. This
is a local existence argument for the converted grouped kernel. A
matched per-edge Lorentzian regulator and equality to the compact
slow-switch functional need separate comparisons.

V1 failed on a row count imported from a different representation.
V2 retained the full condition and used the actual bound V865 count.
The final V3 reviewer binds the older tadpole-owner schema. The
separate receipt and capture are required. Shared action, reference,
software and AI authorship limit independence. This packet adopts
no profile and does not qualify full Ward/QAP or E5/A5.
