"""Actual derivative support, radial reductions and paired cutoff controls."""

from collections import Counter, defaultdict
from functools import lru_cache
import gzip
import json
import sys

import sympy as sp

from execute_v2 import PK, ROOT, read, run_worker


CALC = ROOT / "calculations"


@lru_cache(None)
def coefficient(value):
    return sp.sympify(value)


def literal_support(role):
    owner = CALC / "canonical_so10_joint_common_family_applicability_v1"
    actual = json.loads(gzip.decompress((owner / f"{role}_complete_full_background_extension.json.gz").read_bytes()))
    divergence = defaultdict(dict)
    retained = Counter()
    auxiliary = 0
    for grade, word, cells in actual["complete_S_GF_source"]:
        if grade != 1 or len(word) != 3:
            continue
        (B, jB), (C, jC), (a, ja) = word
        if B < 180 and C < 180 and 508 <= a < 553:
            assert B < 48 <= C and 520 <= a and not (jB or jC or ja)
            auxiliary += 1
        if not (48 <= B < 180 and 553 <= C < 598 and 598 <= a < 643):
            continue
        jets = [jB, jC, ja]
        assert [jet for jet in jets if jet] == [[B % 4]]
        placement = next(i for i, jet in enumerate(jets) if jet)
        if C < 565:
            assert a >= 610 and placement not in divergence[B, C, a]
            divergence[B, C, a][placement] = cells
        else:
            assert placement == 2
            retained["M" if a >= 610 else "H"] += 1
    assert auxiliary == 1336
    assert dict(retained) == {"H": 1336, "M": 2400}
    assert len(divergence) == 1336
    assert all(set(rows) == {0, 1, 2} and rows[0] == rows[1] == rows[2] for rows in divergence.values())
    return {"Lambda_HM_cross_cubics": auxiliary, "mixed_B_active_derivative_on_antighost": dict(retained),
            "raw_mixed_B_external_H_ghost_exact_divergences": len(divergence)}


def actual_tadpole(role):
    route = "primary" if role == "native" else "replay"
    pole = read(CALC / "canonical_so10_ghost_mass_g4_pole" / f"{route}_v2_result.json")
    physical = read(PK / f"frozen_a10_physical_reconciliation/full_{route}.json")
    v = {i: coefficient(c) for i, _, c in physical["vacuum"]["VEV"]["entries"]}
    trace = defaultdict(lambda: sp.S.Zero)
    for x, a, c, value in pole["physical_Y_aC_density"]:
        if a == c:
            trace[x] += coefficient(value)
    for x in range(328):
        casimir = 10 if x < 54 else sp.Rational(25, 2) if x < 306 else 0
        assert sp.expand(trace[x] + casimir * v.get(x, 0)) == 0, x
    nonzero = [sum(trace[x] != 0 for x in range(lo, hi)) for lo, hi in ((0, 54), (54, 306), (306, 328))]
    assert nonzero == [4, 16, 0]
    rows = pole["physical_scalar_sector_family_poles"]["Sigma"]
    d, f, y = (sum(coefficient(v) for a, c, v in rows[k] if (a, c) == (12, 12)) for k in ("DMM", "FMY", "YY"))
    assert (d, f, y) == (0, 12, sp.Rational(51, 2))
    cutoff = sp.Symbol("v", positive=True)
    missing = sp.cancel(((1 - cutoff)**4 - (1 - cutoff)**2) / cutoff)
    residual = (d + f) * sp.integrate(missing, (cutoff, 0, 1))
    assert residual == -7 and (d + f + y) != 0
    return {"actual_trace_compared_scalar_positions": 328, "trace_nonzero_by_blocks": nonzero,
            "row12_no_feedback_constant_in_pole_units": str(d + f + y),
            "row12_unpaired_residual_leading_in_epsilon_squared_over_M": int(residual)}


def transferred_kernels():
    Q, K, z, M, s, u = sp.symbols("Q K z M s u", positive=True)
    pq = (K - Q - z) / 2
    qk = (Q + K - z) / 2
    D = 1 / (Q * (Q + M))
    Y = 1 / (K * (Q + M))
    J = 1 / (Q * K * (Q + M))
    H = (1 - z / K) / (Q**2 * (Q + M))
    assert sp.cancel(qk * J - (Y + D - z * J) / 2) == 0
    assert sp.cancel(pq * J - (D - Y - z * J) / 2) == 0
    assert sp.cancel(pq * qk * J / Q - (D - Y - z * H + 2 * pq / (Q**2 * (Q + M))) / 4) == 0

    yy = sp.integrate((s / z - 1) / (s + M), (s, 0, z))
    yy_param = -sp.integrate(sp.log(1 + u * z / M), (u, 0, 1))
    j = sp.integrate(1 / (z * (s + M)), (s, 0, z)) + sp.integrate(1 / (s * (s + M)), (s, z, sp.oo))
    h = sp.integrate((1 - z / s) / (s * (s + M)), (s, z, sp.oo))
    assert sp.simplify(yy - yy_param) == 0
    assert sp.simplify(j - (1 + sp.log(M / z) - yy) / M) == 0
    assert sp.simplify(h - ((1 + z / M) * sp.log(1 + M / z) - 1) / M) == 0
    ff = sp.simplify((-yy - z * h) / 4)
    assert sp.simplify(ff.subs(z, M)) == 0
    assert sp.simplify(ff.subs(z, 2 * M)) != 0
    assert sp.limit(yy, z, 0, dir="+") == 0
    assert sp.limit(z * j, z, 0, dir="+") == sp.limit(z * h, z, 0, dir="+") == 0
    assert sp.limit(j / sp.log(M / z), z, 0, dir="+") == 1 / M
    return {"both_FMY_placements_retained": True, "FFMM_zero_jet_only": True,
            "FFMM_at_p_squared_equal_M": "0", "FFMM_at_p_squared_equal_2M": str(sp.simplify(ff.subs(z, 2 * M))),
            "massless_log_J_coefficient": "1/M", "grouped_small_transfer": "O(z*(1+abs(log(z))))"}


def checks(role):
    return {"raw_support": literal_support(role), "actual_tadpole": actual_tadpole(role),
            "transferred_kernels": transferred_kernels()}


if __name__ == "__main__":
    run_worker(checks, sys.argv[1])
