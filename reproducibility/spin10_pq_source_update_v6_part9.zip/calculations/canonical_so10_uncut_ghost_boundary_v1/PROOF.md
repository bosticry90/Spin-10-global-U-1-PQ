# Grouped ghost two-source boundary with a retained massive root

Use the V882 coefficients and normalization. This is a prospective
profile test for the uncut one-loop g⁴ ξ² term, at zero scalar mass-
difference degree, zero mean, A=J_BV=0 and two ordinary odd sources.
The trial Euclidean IR regulator leaves positive-reference-mass
scalar edges intact and multiplies every massless free edge by χ²,
χ=1−exp(−q²/ε²). At the UV stage every edge keeps its actual flat heat
clock, including massive bridges. Subtract D_t B_t with the entire
regulated forest at positive t. Use the V882 converted core with
symbolic κ. We prove the IR limit after the UV conversion. No equivalence
to the older raw all-edge profile or global switching limit is assumed.

## Actual proper transfer and the one-port census

V274's surviving DMM, FMY and YY support is literal in the zero-jet
domain, prior to angular integration. Both external odd slots of DMM
lie on D, and its internal
transfer is zero. In FMY the external ghost at F is C, so the derivative
on the antighost is internal. The line joining F to Y through M has
momentum q. The ghost between F and Y has momentum k=q+p, up to
simultaneous reversal. Relative to its own sign at p=0, the F numerator
is q·k, from the mixed longitudinal edge and internal derivative. YY
has one massive and one ghost line. At nonzero p keep the FMY term
with an external antighost derivative and the FFMM paths with an
external antighost derivative. V274's zero-jet exclusions alone do
not remove them. The active F mixed B legs have derivative on a.
Both external C and external a are needed. Thus FFMM necessarily
has one external derivative. Use estimates for these terms independent
of whether their color sums survive.

The scalar factors for fixed M=M_s are, before linear UV conversion,

    D(p)=∫ 1/[q²(q²+M)] dq,
    Y(p)=∫ 1/[k²(q²+M)] dq,
    F(p)=∫ (q·k)/[q² k²(q²+M)] dq.

The integrals include the common measure and the phases from V882.
Their color weights are the independently computed DMM, YY and FMY
tables. Use the same converted operator on the whole rational symbol.
The reductions below do not equate finite raw heat clocks.

For the connected feedback, a one-loop one-port core has sum of
valence minus two equal to one. Thus it contains one cubic and any
allowed constant quadratics. The tree to the two ordinary ghosts also
has one cubic. Both ghost legs reach it directly since no constant
ghost vertex is present. The only branches are ΛaC, BaC, xaC. A B or Λ
root is killed at forced-zero momentum by a massless free edge, even
if the path starts on a scalar and later changes type via M. A pure x
root survives and ends at Y=g² ξ x a Y C. The selected one-port must
then have g² ξ. The only scalar cubic options with that degree and
support are the kinetic Bxx with one M, and Y with a one-edge ghost
trace. Pure scalar potential cubics carry no such g or explicit ξ.
M does not dress an xx propagator since G_ΛΛ=0. The full current
scalar cubic inventory in STS preserves both retained possibilities.
Local converted one-port vertices follow the same graph census, and
the causal b terms cancel in the common V867 conversion.

The Y one-edge massless trace has zero converted continuum value.
Keep its finite-ε residual. The actual kinetic tadpole sews through
the regular massive root with V882's sign. Its finite continuum
contribution is −(DMM+FMY+YY) times the common zero-transfer scalar
factor, separately in each scalar block. Here the color cancellation
uses the two actual identities of V882, so no new contact is fitted.

## Off-transfer reduction including the derivative paths

Write z=p² in Euclidean coordinates. Let J be the integral with
denominator q² k²(q²+M). The internal-derivative FMY factor is
(Y+D−zJ)/2 by 2q·k=q²+k²−z. The external-derivative FMY term,
after stripping its signed color factor, has numerator p·q instead
and gives (D−Y−zJ)/2. Its UV integral converges. The FFMM numerator,
after stripping signs, is (p·q)(q·k) over q⁴ k²(q²+M), from the two
mixed edges and the ordered ghost inverse. It reduces to (D−Y−zH)/4,
where H integrates (1−z/k²)/[q⁴(q²+M)]. In this reduction the remaining
odd integral of p·q/[q⁴(q²+M)] is zero and absolutely convergent. The
IR-sensitive terms must be kept grouped in H. None of the derivative
paths may be declared zero from the zero-jet table.

With 16π² stripped, direct angular integration gives

    Y−D = 1−(1+M/z) log(1+z/M),
    J = log(1+z/M)/z + log(1+M/z)/M,
    H = ((1+z/M) log(1+M/z)−1)/M.

The angular mean of 1/(q+p)² is 1/max(q²,z) in D=4, by the radial
harmonic mean identity. The difference Y−D is the integral of
(s/z−1)/(s+M) from 0 to z, s=q². Splitting the J integral at z gives
the two terms shown. The H integral only runs from z to infinity,
with integrand (1−z/s)/(s(s+M)). Independently combine the two
propagators in Y−D by a Feynman parameter. It equals
−∫₀¹ log(1+u z/M) du. The partial fraction for J is the common
UV-converted massless bubble minus Y, divided by M. This gives
[1+log(M/z)−(Y−D)]/M, in agreement with the angular formula.
All changes of variables in divergent expressions are made on
the common converted difference. The finite shifted difference is
insensitive to translations of a large hard radial cutoff because
its boundary error is O(1/R). All separately divergent pieces in the
algebra have identical UV residue and conversion.

Each grouped continuum scalar factor after subtracting its true
constant is z times A(z)+B(z)log z, with A and B analytic for small
z on the branch continued from z>0. In particular the external-
derivative paths cannot change the canceled constant. The grouped
Euclidean size is O(|p|²(1+|log |p||)) near zero, so sewing the two
massless outer branches is locally integrable.

## Uniform paired cutoff and an unpaired control

In each finite word, 1−∏χ(q_i²)^N_i is bounded by
Σ_i N_i exp(−q_i²/ε²). Each cutoff error is UV integrable, so the UV
clocks and local residues stay fixed. For DMM and YY use the bounded
massive inverse and a shifted Gaussian integral of one inverse square,
O(ε²). For internal-derivative FMY use |q·k|/(q²k²)≤1/(|q||k|).
The arithmetic mean of |q|⁻² and |k|⁻² bounds the latter. Their
Gaussian integrals are maximal at zero shift by the layer-cake
identity for radial decreasing functions.

External-derivative FMY and FFMM are bounded by |p|/(|q||k|²) and
|p|/(|q|²|k|), times the bounded massive inverse. Use |p|≤|q|+|k|
and the same arithmetic mean to bound these by inverse squares.
Thus the full proper error is O(ε²) on the fixed soft ball. The
kinetic tadpole error is O(ε⁴) and the massless ghost tadpole error
is O(ε²).
The massive root is bounded at forced-zero momentum.

Two external regulated branches cost O(1+|log ε_out|) against a
constant error on that ball. Taking ε_out=ε makes the whole error vanish. More generally
ε²|log ε_out|→0 suffices. This proves the paired Euclidean limit.

The unpaired issue has a nonzero actual control. V275 gives
tr Y_s[x]=−C_s v_s·x. The odd Hessian of aY[x]C has supertrace
−2 tr Y_s[x]/P against the free ghost inverse. With the kinetic
tadpole it gives the difference of massive and massless one-edge
radial factors. At finite ε both have one massless χ², from the
BΛ or ghost edge. Use the identity from V882 after each true UV
subtraction. Cutoff differences are UV integrable, so the grouped
zero-transfer feedback has the massive–massless factor with χ²
and weight −Z_s. DMM and FMY instead have χ⁴ there, and YY has χ².
The residual for color 12 with the common factors stripped is exactly

    12 ∫₀∞ [χ(s)^4−χ(s)^2] ds/(s+M_Sigma).

It is negative for all ε>0. With s=ε²u the binomial expansion gives
−7 ε²/M_Sigma+O(ε⁴). The external-derivative paths vanish at zero.
The kernel at fixed positive inner ε is smooth near p=0, so the outer
limit at fixed inner ε diverges by the V882 logarithm. Along a
sequence of inner ε tending to zero, one can take ε_out small enough
at each value to make the same pairing unbounded. Thus arbitrary
independent approaches do not have a common limit. The finite
massless tadpole artifact is retained before the joint pairing.

## Separate local Feynman boundary

The converted one-port B term vanishes by Lorentz covariance. Odd
one-point terms are forbidden by parity and ghost number. The literal
ΛBB cubic joins one H and one M gauge field. Their zero-field covariance
has no cross block. The ΛaC cubic has a scale-free massless one-edge
trace, zero after conversion and IR removal. The nonzero scalar one-port
is blockwise radial along v_s. A mixed root to B is killed by
E_b v_s=⟨ρ_b v_s,v_s⟩=0. The massive feedback uses the same constant.

Continue the grouped converted scalar functions from z>0 to
z=−P−iη, η>0. The two outer propagators use the same z. Near P=0
the products are A(z)/z+B(z)log(z)/z. At nonzero points on the
cone P is a smooth transverse coordinate. The log and half the
squared log are primitives of 1/z and log(z)/z. They have uniform
locally integrable bounds in that coordinate as η tends to zero.
Thus the grouped expression has a boundary there, including the
massless logarithm. The construction takes the boundary of the
analytic product before splitting it into distributions.

At the tip use dyadic shells p=r y. On the unit shell the transverse
bound is uniform in η/r² for shifts up to one. For larger shifts
the same terms are bounded pointwise. The analytic coefficients stay
smooth on shrinking shells. The shell measure contributes r⁴,
the propagator terms r⁻², and the scaled logarithms at most
O(1+|log r|). The summable r²(1+|log r|) bounds give the common
boundary through the tip with scaling degree at most two. This is
the local boundary of the selected converted coefficient. It gives
neither slow-switch equality nor a domain for arbitrary Ward derivatives.
