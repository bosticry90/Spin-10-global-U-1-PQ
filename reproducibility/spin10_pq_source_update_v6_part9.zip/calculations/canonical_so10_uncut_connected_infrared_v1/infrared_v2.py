"""Exact rank, scalar kinetic cancellation, forest and source controls."""

import gzip
import itertools
import json
import sys

import sympy as sp

from execute_v2 import ROOT, read, run_worker


CALC = ROOT / "calculations"


def unzip(path):
    return json.loads(gzip.decompress(path.read_bytes()))


def unlabeled_components(vertices, edges, labels):
    neighbors = {v: set() for v in range(vertices)}
    for a, b in edges:
        neighbors[a].add(b)
        neighbors[b].add(a)
    unseen = set(neighbors)
    count = 0
    while unseen:
        frontier = {unseen.pop()}
        component = set(frontier)
        while frontier:
            fresh = set.union(*(neighbors[v] for v in frontier)) & unseen
            unseen.difference_update(fresh)
            component.update(fresh)
            frontier = fresh
        count += not component.intersection(labels)
    return count


def rank_controls():
    fixtures = {
        "trivalent_tree": (4, [(0, 1), (0, 2), (0, 3)], {1, 2, 3}),
        "one_exit": (2, [(0, 0), (0, 1)], {1}),
        "two_exits": (3, [(0, 0), (0, 1), (0, 2)], {1, 2}),
        "cut_cycle": (6, [(0, 1), (1, 2), (2, 0), (0, 3), (1, 4), (2, 5)], {3, 4, 5}),
        "parallel_cycle": (4, [(0, 1), (0, 1), (0, 2), (1, 3)], {2, 3}),
        "labeled_cycle": (3, [(0, 0), (0, 1), (1, 2)], {0, 2}),
    }
    out = {}
    for name, (vertices, edges, labels) in fixtures.items():
        unlabelled = sorted(set(range(vertices)) - labels)
        incidence = sp.Matrix([[int(v == a) - int(v == b) for a, b in edges] for v in unlabelled])
        basis = sp.Matrix.hstack(*incidence.nullspace())
        assert basis.cols == len(edges) - len(unlabelled)
        ranks = {}
        for size in range(len(edges) + 1):
            for soft in itertools.combinations(range(len(edges)), size):
                hard = [e for i, e in enumerate(edges) if i not in soft]
                r = basis.extract(soft, range(basis.cols)).rank()
                assert r == size - unlabeled_components(vertices, hard, labels)
                ranks[soft] = r
        out[name] = {"tested_subsets": len(ranks), "all_soft_rank": ranks[tuple(range(len(edges)))]}
        if name in {"one_exit", "two_exits"}:
            exits = tuple(range(1, len(edges)))
            rank = ranks[exits]
            margin = 4 * rank - 2 * len(exits)
            assert (rank, margin) == ((0, -2) if name == "one_exit" else (1, 0))
            out[name].update(exit_rank=rank, unit_edge_power_margin=margin)
    return out


def scalar_controls():
    data = read(CALC / "canonical_so10_current_background_reference_bridge_v1/result_a.json")
    generator = data["compared"]["twelve_current_homogeneous_carriers"][0]
    phi = {(i, j): sp.sympify(c) for i, j, c in generator if 180 <= i < 234 and 180 <= j < 234}
    assert all(c == -phi[j, i] for (i, j), c in phi.items())
    trace = sum(c * phi[j, i] for (i, j), c in phi.items())
    assert trace == -12

    D, u, R, M, delta = sp.symbols("D u R M Delta", positive=True)
    s4 = 1 / (8 * sp.pi**2)
    m = M + delta
    seagull = -1 / (2 * (u + m))
    bubble = u / (D * (u + m)**2)
    angular = seagull + bubble
    assert sp.cancel(angular + (D / (u + m) - 2 * u / (u + m)**2) / (2 * D)) == 0
    critical = sp.series(angular, u, sp.oo, 3).removeO().coeff(u, -2).factor()
    alpha4 = critical.subs(D, 4)
    alpha_jet = s4 * sp.diff(critical, D).subs(D, 4)
    hard_surface = -s4 * R**4 / (8 * (R**2 + m))
    hard_radial = sp.integrate(s4 * u * angular.subs(D, 4) / 2, (u, 0, R**2))
    assert sp.cancel(hard_radial - hard_surface) == 0
    tau = sp.limit(hard_surface + s4 * R**2 / 8, R, sp.oo)
    assert alpha4 == 0 and sp.simplify(tau - alpha_jet) == 0
    assert sp.simplify(tau - s4 * m / 8) == 0 and tau.subs(delta, 0) != 0
    for degree in range(3):
        assert sp.cancel(sp.diff(hard_radial - hard_surface, delta, degree)) == 0
        assert sp.simplify(sp.diff(tau - alpha_jet, delta, degree)) == 0

    Q, t, g, c = sp.symbols("Q t g c", positive=True)
    bridge = sp.exp(-c * t * Q) / Q
    bridge_jet = sp.diff(bridge**2, t).subs(t, 0)
    heat_leading = sp.integrate(sp.exp(-2*u), (u, 0, sp.oo)) / (16 * sp.pi**2)
    forest = sp.simplify(-g**2 * trace * heat_leading * bridge_jet.subs(c, 2) / 2)
    assert forest == -3 * g**2 / (4 * sp.pi**2 * Q)
    return {"actual_trace_r_squared": int(trace), "critical_symbol_without_sD": str(critical),
            "hard_finite_part": str(tau), "angular_dimension_jet": str(alpha_jet),
            "converted_constant": "0", "wrong_fixed_dimension_constant": str(tau),
            "forest_clock_one_core_edge_two_bridge_edges": [2, 2, 2],
            "forest_finite_difference": str(forest)}


def source_controls(role):
    metric = CALC / "canonical_so10_augmented_metric_lift_v1"
    raw = unzip(metric / ("tensor_7.json.gz" if role == "native" else "tensor_6.json.gz"))
    raw_rows = raw["input_polynomial_Minkowski"]
    assert [[[508, []], [1241, []]], [[[0, 0, 0, 0], -1, 1]]] in raw_rows
    family = CALC / "canonical_so10_joint_common_family_applicability_v1"
    actual = unzip(family / f"{role}_complete_full_background_extension.json.gz")
    row = [1, [[185, []], [525, []]], [[[1, 0, 16], 5, 1]]]
    assert row in actual["complete_S_GF_source"]
    assert [actual["joined_names"][i] for i in (185, 525)] == ["x_Phi_5", "L17"]
    p, P, M, g, xi = sp.symbols("p P M g xi", real=True)
    K_LB = -sp.I * p
    G_BL = sp.I * p / P
    V = 5 * g * xi
    offshell = (K_LB * G_BL).subs(P, p**2)
    G_Bx = -G_BL * V / (P - M)
    tree_contact = sp.cancel((-K_LB * G_Bx).subs(p**2, P))
    assert offshell == 1 and sp.cancel(tree_contact - V / (P - M)) == 0
    assert tree_contact.subs(P, 0) == -V / M
    return {"raw_Lambda_Ja": -1, "off_shell_source_first_contraction": int(offshell),
            "wrong_source_sign_contraction": int(-offshell), "literal_Euclidean_Lambda17_Phi5": "+5i g xi",
            "mixed_contact_at_tip_after_boundary": str(-V / M), "tip_before_boundary": "0"}


def checks(role):
    return {"rank_controls": rank_controls(), "scalar_controls": scalar_controls(),
            "source_controls": source_controls(role)}


if __name__ == "__main__":
    run_worker(checks, sys.argv[1])
