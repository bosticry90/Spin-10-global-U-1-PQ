"""Freeze and review the V881 evidence in the active D: workspace."""

import ast
import json
import os
import subprocess
import sys
import threading
import time
from hashlib import sha256
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CONTROL = Path("D:/Codex-Research/ToE-Next/research-control-records/uncut-connected-infrared-v1-v3-2026-11-08")
PK = ROOT / "tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1"
BASE = "ba260dc7db2d238dcf6271768c568921933d410a"
NAV = ["README.md", "docs/COMMON_RESTORATION_CAMPAIGN_V1.md", "docs/RESEARCH_EXECUTION_HANDOFF_V881.md"]


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def save(name, data):
    raw = (json.dumps(data, sort_keys=True) + "\n").encode()
    if len(raw) > 8 * 1024**2:
        name += ".COMPLETE_OVERFLOW_NOTPASS"
    for folder in (HERE, CONTROL):
        with (folder / name).open("xb") as f:
            f.write(raw)
    assert len(raw) <= 8 * 1024**2


def prepare(phase):
    assert git("rev-parse", "HEAD").decode().strip() == BASE
    assert not git("diff", "--cached", "--name-only")
    if phase == "native":
        assert not git("diff", "--name-only", "HEAD")
        old_control = CONTROL.with_name("uncut-connected-infrared-v1-2026-11-08")
        for name in ("preparation_native.json", "capture_native.json"):
            assert (HERE / name).read_bytes() == (old_control / name).read_bytes()
        failure = read(HERE / "capture_native.json")
        assert failure["execution_state"] == "FAILED" and failure["exit_code"] == 1
        assert "tree_contact == V / (P - M)" in failure["stdout_and_stderr"]
        for name in ("RECORD.md", "PROOF.md", "infrared.py", "execute.py"):
            assert (HERE / name).read_bytes() == (HERE / (name + ".source.txt")).read_bytes()
        rejected = read(HERE / "controller_failure_v2.json")
        assert rejected["execution_state"] == "FAILED_PREPARATION" and not rejected["worker_started"]
        v2_control = CONTROL.with_name("uncut-connected-infrared-v1-v2-2026-11-08")
        assert (v2_control / "old_git_tree.txt").read_bytes() == (old_control / "old_git_tree.txt").read_bytes()
        CONTROL.mkdir(exist_ok=False)
        with (v2_control / "controller_failure_v2.json").open("xb") as f:
            f.write((HERE / "controller_failure_v2.json").read_bytes())
        with (CONTROL / "old_git_tree.txt").open("xb") as f:
            f.write(git("ls-tree", "-r", "HEAD"))
        snapshots = ("CORRECTION_V2.md", "CORRECTION_V3.md", "infrared_v3.py", "execute_v3.py")
        owners = {
            "augmented_metric_lift_v1": ("PROOF.md", "validation_receipt.json", "tensor_6.json.gz", "tensor_7.json.gz"),
            "joint_common_family_applicability_v1": ("validation_receipt.json", "native_complete_full_background_extension.json.gz", "replay_complete_full_background_extension.json.gz"),
            "uncut_local_common_primitive_v1": ("PROOF.md", "validation_receipt.json"),
            "compact_retained_source_functional_v1": ("PROOF.md", "validation_receipt.json"),
            "current_background_reference_bridge_v1": ("PROOF.md", "result_a.json", "validation_receipt.json"),
            "connected_master_source_chart_v1": ("PROOF.md", "validation_receipt.json"),
            "causal_one_loop_sewing": ("DERIVATION.md", "validation_receipt.json"),
            "joint_born_ir_trace_domain": ("DERIVATION_V2.md", "validation_receipt.json"),
            "mellin_lorentzian_boundary": ("DERIVATION.md", "validation_receipt.json"),
            "dimensional_stokes_primitive": ("DERIVATION.md", "validation_receipt.json"),
            "physical_current_input_recovery_g1_v1": ("PROOF.md", "validation_receipt.json"),
            "free_causal_reference": ("DERIVATION.md", "validation_receipt_v3.json"),
        }
        names = {"AGENTS.md", "CHARTER.md", "project_state.json", "docs/RESEARCH_EXECUTION_HANDOFF_V880.md",
                 "tools/portable_dh_v1/inputs.json.gz", "tools/portable_dh_v1/exact_algebra.py"}
        names.update((PK / name).relative_to(ROOT).as_posix() for name in (
            "A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md", "A10_E2_TRANSPORT_RESULT.md", "A10_E3_SYMMETRY_RESULT.md",
            "export_a10_e5_antighost_vector.py", "source_convention_control.py",
            "frozen_a10_e2_transport/validation_receipt.json", "frozen_a10_e3_symmetry/validation_receipt.json"))
        for owner, paths in owners.items():
            names.update(f"calculations/canonical_so10_{owner}/{path}" for path in paths)
    else:
        assert phase == "validation"
        assert set(git("diff", "--name-only", "HEAD").decode().splitlines()) == set(NAV[:2])
        for name, backup in zip(NAV[:2], ("README_before_final.bytes", "campaign_before_final.bytes")):
            assert (CONTROL / backup).read_bytes().replace(b"\r\n", b"\n") == git("show", "HEAD:" + name)
        first = read(HERE / "preparation_native_v3.json")
        for name, expected in first["sha256"].items():
            assert digest(ROOT / name) == expected, name
        names = set(first["sha256"]) | set(NAV) | {"docs/LOCAL_RESEARCH_CONVENTIONS_V1.md"}
        snapshots = ("RESULT.md",)
    for name in snapshots:
        raw = (HERE / name).read_bytes()
        if name.endswith(".py"):
            ast.parse(raw)
        with (HERE / (name + ".source.txt")).open("xb") as f:
            f.write(raw)
    names.update(path.relative_to(ROOT).as_posix() for path in HERE.iterdir() if path.is_file())
    save(f"preparation_{phase}_v3.json", {
        "base_HEAD": BASE, "sha256": {name: digest(ROOT / name) for name in sorted(names)},
        "scientific_acceptance": "NOT_PERFORMED",
        "limits": {"seconds": 120 if phase == "native" else 180, "e4_seconds": 120,
                   "sampled_private_bytes": 8 * 1024**3, "minimum_available_commit_bytes": 350 * 1024**2,
                   "artifact_bytes": 8 * 1024**2, "packet_bytes": 32 * 1024**2},
    })


def run_worker(check, phase):
    started = time.perf_counter()
    prep = read(HERE / f"preparation_{phase}_v3.json")
    timer = threading.Timer(prep["limits"]["seconds"], lambda: os._exit(124))
    timer.daemon = True
    timer.start()
    assert git("rev-parse", "HEAD").decode().strip() == BASE == prep["base_HEAD"]
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    if phase == "native":
        save("result_v3.json", {"execution_state": "COMPLETED", "checks": check("native")})
        print("STAGE soft ranks, converted scalar kinetic core, source and forest controls checked", flush=True)
    else:
        review(check, prep, started)
    timer.cancel()


def review(check, prep, started):
    assert not git("diff", "--cached", "--name-only")
    assert git("ls-tree", "-r", "HEAD") == (CONTROL / "old_git_tree.txt").read_bytes()
    for name in ("preparation_native_v3.json", "capture_native_v3.json", "result_v3.json"):
        assert (HERE / name).read_bytes() == (CONTROL / name).read_bytes()
    cap = read(HERE / "capture_native_v3.json")
    assert cap["calculation_completed"] and cap["post_run_observations_qualified"]
    for source in HERE.glob("*.source.txt"):
        assert source.read_bytes() == (HERE / source.name.removesuffix(".source.txt")).read_bytes()
    owners = sorted(n for n in prep["sha256"] if "validation_receipt" in Path(n).name and n.endswith(".json"))
    for name in owners:
        owner = read(ROOT / name)
        if "execution_state" in owner:
            assert owner["execution_state"] == "COMPLETED", name
        else:
            assert owner["status"].startswith("PASS_BOUNDED_"), name
    result = read(HERE / "result_v3.json")
    assert result["execution_state"] == "COMPLETED"
    checks = result["checks"]
    assert checks == check("replay")
    ranks = checks["rank_controls"]
    assert sum(row["tested_subsets"] for row in ranks.values()) == 108
    assert ranks["one_exit"]["exit_rank"] == 0 and ranks["two_exits"]["exit_rank"] == 1
    assert checks["scalar_controls"]["converted_constant"] == "0"
    assert checks["scalar_controls"]["forest_finite_difference"] == "-3*g**2/(4*pi**2*Q)"
    assert checks["source_controls"]["off_shell_source_first_contraction"] == 1
    assert checks["source_controls"]["mixed_contact_at_tip_after_boundary"] == "-5*g*xi/M"
    print("STAGE replay raw and Euclidean source rows and exact comparison controls agree", flush=True)

    command = [sys.executable, "-B", "tools/research_check.py", "e4", "--historical-context",
               "D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4"]
    try:
        e4 = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=120)
    except subprocess.TimeoutExpired as err:
        save("e4_timeout_v3.json", {"command": command, "state": "INCOMPLETE_TIMEOUT",
                                 "stdout": (err.stdout or b"").decode("utf-8", errors="replace"),
                                 "stderr": (err.stderr or b"").decode("utf-8", errors="replace")})
        raise
    save("e4_capture_v3.json", {"exit_code": e4.returncode, "stdout": e4.stdout, "stderr": e4.stderr})
    events = [json.loads(line) for line in e4.stdout.splitlines() if line.strip()]
    steps = [event for event in events if event.get("event") == "step_finished"]
    exits = [event["exit_code"] for event in steps]
    assert e4.returncode == 0 and exits == [0, 0, 0, 0, 0, 2]
    custody = next(event for event in steps if event["step"] == "historical_custody")
    assert custody["stdout"].count("RECORDED_DIGEST_UNRESOLVED:") == 7
    hist = git("show", "ef70f255a667b9a81e37b344dc78967ada4ed896:README.md")
    assert sha256(hist).hexdigest() == "4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792"
    assert (ROOT / "README.md").read_bytes().replace(b"\r\n", b"\n").endswith(hist)
    state = digest(ROOT / "project_state.json")
    assert state == "d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8"
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    files = [p for p in HERE.iterdir() if p.is_file()] + [ROOT / name for name in NAV]
    save("validation_receipt_v3.json", {"base_HEAD": BASE, "execution_state": "COMPLETED",
         "evidence_validation": "PASS_UNCUT_SOFT_RANK_AND_SELECTED_SCALAR_KINETIC_CORE",
         "scientific_acceptance": "NOT_PERFORMED", "state_sha256": state,
         "E4_step_exits": exits, "historical_custody": "SEVEN_UNRESOLVED_NOTPASS", "owner_receipts": owners,
         "checks": checks,
         "files_excluding_pending_receipt_capture": {p.relative_to(ROOT).as_posix(): digest(p) for p in files},
         "elapsed_after_imports": time.perf_counter() - started})


def main():
    phase = sys.argv[1]
    prepare(phase)
    sys.path.insert(0, str(PK))
    from export_a10_e5_antighost_vector import capture

    report = capture([sys.executable, "-B", str(HERE / "infrared_v3.py"), phase])
    save(f"capture_{phase}_v3.json", report)
    print(report["stdout_and_stderr"], end="")
    assert report["calculation_completed"] and report["post_run_observations_qualified"]
    assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file()) <= 32 * 1024**2


if __name__ == "__main__":
    main()
