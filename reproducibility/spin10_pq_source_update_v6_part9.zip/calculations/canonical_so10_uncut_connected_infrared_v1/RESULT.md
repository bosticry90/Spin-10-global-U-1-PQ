# V881 — Soft transfer rank and the selected scalar kinetic core

The direct uncut connected forest has dependent soft transfers. For a
soft edge set S its rank is |S| minus the number of unlabeled hard
components. The two independent finite checks agree on all 108 subsets
of the six fixtures. The resulting power bound gives the classical
tree margin after one tangent. An unlabeled hard loop core with one
exit forces zero momentum. Two exits can be critical at rank one.

The actual Phi54 seagull realizes the latter case. Grouping it with the
scalar kinetic bubble cancels the selected converted constant. The
hard finite part and angular dimension jet both equal
(M+Delta)/(64 pi^2). The converted analytic kernel improves by two
soft powers and has a local two-bridge boundary. This is the selected
scalar kinetic group, without a claim of uniform regulated convergence.

The true-clock seagull forest difference is −3g²/(4 pi² p_E²) in the
stripped density. In the raw source-first chart the mixed contact has
off-shell factor +1. The actual Lambda17–Phi5 bridge gives different
values at forced-zero transfer before and after the continuum contact.
The general connected construction still requires grouped one- and
two-port tests and a joint boundary for the remaining domains.

V1's structural expression comparison failed. V2 did not launch its
worker because it tried to recreate an existing snapshot. V3 retains
the original failures, exact analytic condition, and scientific scope.
The separate final replay and E4 receipt are required. The runs reuse
the same action, analytic convention, SymPy and AI authorship. No
scientific acceptance or physical benchmark is changed.
