# V881 V3 controller correction

V2 stopped in preparation before launching a worker. Its controller
tried to create `RECORD.md.source.txt` with exclusive creation, although
V1 had already created that snapshot. Preserve the V2 controller,
worker and error. V3 verifies all four original snapshots and creates
only the new correction and V3 source snapshots. The V2 contact check
is unchanged. No limit or acceptance requirement is reduced.
