# Dependent soft transfers in the direct uncut connected construction

Use the V880 uncut unprobed parent and its same converted prescription,
with V871's tree sewing. The soft rank changes when a vertex has no
independent test transfer. Source- and background-independent vacuum
terms remain in the inherited normalization. A J/A-only vertex with a
test transfer is a label, including when it has no ordinary field.

## Incidence rank and the strict infrared test

Take a finite connected multigraph with at least one labeled vertex.
Work componentwise in four momentum coordinates. If U is the set of
unlabeled vertices, edge momenta lie in the kernel of the oriented
incidence matrix restricted to rows U. Self-loop columns are zero.
External momenta at the labels are fixed by the incidence equations up
to the one overall conservation law. Thus this kernel has dimension
|E|−|U|, including the unique loop coordinate for a one-loop graph.

For a set S of soft edges, retain the hard complement, including its
isolated vertices. Write c0 for its components with no label. The
incidence restricted to hard columns and rows U has rank |U|−c0. Its
left kernel consists of constants on unlabeled hard components, since
the row covectors extend by zero on labeled vertices. Subtract the
dimension of the subspace with S coordinates zero from the full
kernel dimension. The rank on the S coordinates is |S|−c0. This also
covers parallel edges and an uncut self-loop.

On a bounded Euclidean region, a product of absolute edge poles with
nonnegative exponents α_e is locally integrable if each nonempty S
satisfies sum_S α_e < 4 rank(S). To see this, order dyadic pole scales
n_e largest first and greedily choose independent transfer rows in
that order. On the corresponding sector, the volume is bounded by
the product of 2^(−4 n_e) over selected rows. This follows by extending
the selected linear coordinates to the full space and bounding the
remaining coordinates. Each prefix has exactly its rank many selected
rows. Summation by parts on consecutive scale differences then gives
a convergent geometric sum from every strict prefix inequality. Use
this test on a local absolute majorant. Actual numerator vanishing can
improve it. It is not an assertion about analytic continuation of
arbitrary such multivariate majorants.

Collapse the actual constant classical chains of V880. For a tree
of the remaining vertices, each unlabeled hard component has at least
three soft exits: a tree of v unlabeled vertices of degrees at least
three has boundary degree at least 3v−2(v−1). If ℓ hard components
carry labels, the quotient tree has |S|=c0+ℓ−1 edges and
2|S|≥3c0+ℓ. Consequently |S|≥2c0+1. The ordinary pole budget
α_e≤2 has margin at least two, or at least one after a single
V880 tangent raises an edge order by one. These bounds are for the
classical tree. They do not assign degree ≥3 to one-loop local
normalization vertices.

If the hard complement retains the cycle inside an unlabeled component
with d soft exits, the other unlabeled components are trees. The
quotient tree now gives |S|≥2c0+d−2. For d≥3 this gives the same
strict bound. A single exit has identically zero momentum when the
soft subset is that bridge. For two exits the two momenta can be p
and −p with rank one. Two order-two edges are then critical. If the
retained cycle has a label, the exceptional unlabeled component is
absent. If soft edges cut the cycle, the quotient is unicyclic and
degree counting gives |S|≥2c0. Critical subsets there require further
use of field and numerator support. The present proof does not use
this weaker inequality to claim their convergence.

## Actual scalar kinetic two-port

Take A=0, one fixed normalized light gauge color, and the Phi54 block.
The actual skew generator r has tr r²=−12. With M denoting positive
reference mass squared, use m=M+Δ as a formal notation: all statements
are Taylor coefficients in Δ at zero. For the scalar kinetic operator
−(∂−g r B)²+m, the zero-transfer vertices are 2i g r B·q and
−g²r² B². Strip the common Wick factor and g² tr r² from the Euclidean
quadratic density, using log weights +1/2 and −1/4. For the complete
two-vertex kinetic group the angle-averaged zero-transfer integrand is

    f_D(q) = −1/[2(q²+m)] + q²/[D(q²+m)²]
           = −div_q[q/(q²+m)]/(2D).

The seagull alone is nonzero. On a fixed hard Euclidean q annulus it
has a nonzero fixed-sign integrand and two transverse external gauge
bridges give |p|^−4 on an angular patch with nonvanishing source
pairing. Thus even before hard subtraction its absolute p integral
has a logarithmic divergence. This is an actual graph, as distinguished
from a generic estimate that happens to be borderline.

For the group, the large-radius surface term is
−s4 R⁴/[8(R²+m)], where s4=1/(8π²). The hard finite part τ_h is
s4 m/8. Independently expand the two radial integrands to the critical
degree. The dimension-dependent symbol is s_D (1/2−2/D)m. Thus
α_4=0 and α'_4=s4 m/8. In V880's converted normalization the finite
coefficient τ_h−α'_4 plus the inherited multiple of α_4 is exactly
zero. Evaluating the angular symbol at D=4 before differentiating it
would leave a spurious finite mass term. The radial proof holds under
finite Δ derivatives. It does not equate the raw one- and two-vertex
heat clocks.

The same massive kinetic two-point kernel after local subtraction is
analytic in external momentum near zero. For the bubble this follows
by combining its two denominators with x∈[0,1] and using the mass
parameter m+x(1−x)p_E², which stays away from zero for |p_E²|<4M at
Δ=0. The subtractions are local polynomials. At each finite Taylor
order in Δ, the fixed-color tensor is even by Euclidean covariance,
so the converted zero-transfer cancellation makes it O(|p|²).
The product with two massless gauge bridges has a locally integrable
Euclidean tip. For the corresponding boundary of the already converted
analytic kernel, each gauge longitudinal numerator compensates the
extra denominator degree of its dipole. On a dyadic annulus p=r q,
the repeated common Feynman powers on the unit annulus have uniformly
bounded distribution seminorms: the nonzero cone is smooth there and
the one-dimensional boundary is uniform in its nonnegative imaginary
shift. The converted kernel supplies two powers of r. The shell
bound at the tip is then O(r²) for the two bridges, which is summable.
This is a local boundary of a grouped converted kernel. A uniform
limit through all simultaneous inner and outer regulators would need
a separate bound on the prelimit grouped coefficient.

## Regulated forest and source-first controls

For the seagull by itself the actual flat one-edge core clock is 2.
At each transverse external edge the inherited flat clock is also 2.
For Q=p_E²>0, write B_t=e^(−2tQ)/Q. The scalar integral
I_t=∫d⁴q/(2π)⁴ e^(−2tq²)/(q²+M) has 1/t coefficient 1/(32π²),
by rescaling the radius in the radial integral. The selected quadratic
density before the common Wick factor is +6g² I_t. Therefore its
leading divergent coefficient times B_t²−B_0² has a nonzero finite
term −3g²/(4π² Q). This is a forest subtraction diagnostic at nonzero
transfer. The COS1 subtraction must use D_t B_t, with the inherited
regulated forest, rather than D_t B_0. It does not resolve the critical
transfer merely by being a valid forest subtraction away from it.

In the raw Minkowski g0 chart the action has −Λ J_a. The stationary
B field therefore responds to J_a as +G_{BΛ}, while it responds to an
ordinary j_B as −G_{BB}. For the appropriate component K_{ΛB}=−ip
and G_{BΛ}=ip/P, their contraction is +1 off shell. Flipping the source
sign would produce −1. The actual V865 g1 row for Φ5, Λ17 is +5i g ξ
in the Euclidean chart and +5g ξ in the raw chart. With this V, the first
mixed Bx inverse is −G_{BΛ} V G_x, so the source-first tree response
W_{j_B j_x}=+G_{BΛ} V G_x satisfies K_{ΛB}W=+V G_x. In this longitudinal
diagnostic a retained common IR denominator gives
V P/[(P+iε)(P−M+iε)]. Point restriction at zero gives zero for each
positive ε, while the continuum contact has value −V/M at zero. For
the first limit use P/(P+iε)→1 as a distribution and the smooth massive
inverse near zero. This difference occurs on an actual bridge. Whether
its contraction against the complete tadpole vanishes must be proved
from the actual tadpole and local correction, including the massive
route to a two-ended core.
