# V881 V2 harness correction

V1 stopped with exit 1 at the exact source contact assertion. Its
complete launch, worker capture, and source bytes remain preserved.
SymPy returned `-5*g*xi/(M - P)` while the assertion compared its
structure to `5*g*xi/(-M + P)`. Their rational difference is zero.
V2 tests the exact canceled difference and retains the separate value
at zero transfer and the off-shell sign. No scientific test, input,
scope, or resource limit is changed. Use separate V2 paths for the
execution artifacts and preserve the original FAILED classification.
