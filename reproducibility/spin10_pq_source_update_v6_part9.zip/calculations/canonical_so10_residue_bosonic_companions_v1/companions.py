"""Contract the V916 DMM kernel with actual bosonic kinetic vertices."""

from collections import defaultdict
import gzip
from itertools import product
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


COLORS = range(45)


def packet(name):
    return ROOT / "calculations" / f"canonical_so10_{name}"


def unpack(cells):
    result = 0
    for (g, xi, eta, mask), num, den in cells:
        assert (g, xi, eta) == (0, 0, 0)
        value = sp.Rational(num, den)
        for bit, factor in enumerate((sp.sqrt(2), sp.sqrt(3), sp.sqrt(5), sp.sqrt(7), sp.I)):
            if mask & (1 << bit):
                value *= factor
        result += value
    return result


def gram_by_block(poles):
    orbit = defaultdict(list)
    for a, x, value in poles["physical_E"]:
        orbit[x].append((a, sp.sympify(value)))
    for name, start, stop in (("Phi", 0, 54), ("Sigma", 54, 306)):
        gram = defaultdict(lambda: sp.S.Zero)
        for x in range(start, stop):
            for (a, left), (b, right) in product(orbit[x], repeat=2):
                gram[a, b] += left * right
        yield name, {key: sp.expand(value) for key, value in gram.items() if sp.expand(value)}


def adjoint_gram(gram, adjoint):
    result = defaultdict(lambda: sp.S.Zero)
    for (u, v), weight in gram.items():
        for out, left in adjoint[u].items():
            for (a, x), (b, y) in product(left, adjoint[v][out]):
                result[a, b] += weight * x * y
    return {key: sp.expand(value) for key, value in result.items()}


def scalar_trace(gram, scalar):
    value = 0
    for (u, v), weight in gram.items():
        value += weight * sum(x * scalar[v].get(key, 0) for key, x in scalar[u].items())
    return sp.expand(value)


def check(phase):
    role = "primary" if phase == "native" else "replay"
    poles = json.loads((packet("ghost_mass_g4_pole") / f"{role}_v2_result.json").read_bytes())
    name = "native_v2_coefficients.json.gz" if phase == "native" else "replay_v4_coefficients.json.gz"
    d = json.loads(gzip.decompress(
        (packet("physical_current_input_recovery_g1_v1") / name).read_bytes()))
    adjoint = defaultdict(lambda: defaultdict(list))
    for (out, u, a), cells in d["f"]:
        adjoint[u][out].append((a, unpack(cells)))
    scalar = {u: {(out, a): unpack(cells) for out, a, cells in entries if out < 54 and a < 54}
              for u, entries in d["rho"]}

    vector, trace = {}, {}
    for block, gram in gram_by_block(poles):
        K = adjoint_gram(gram, adjoint)
        orbit_trace = sum(gram.get((a, a), 0) for a in COLORS)
        K_trace = sum(K.get((a, a), 0) for a in COLORS)
        assert sp.expand(K_trace - 8 * orbit_trace) == 0
        for a, b in product(COLORS, repeat=2):
            assert K.get((a, b), 0) == K.get((b, a), 0)
        vector[block] = {"rows_0_1": [str(K[i, i]) for i in (0, 1)],
                         "trace": str(K_trace),
                         "nonzero": sum(bool(value) for value in K.values())}
        trace[block] = str(scalar_trace(gram, scalar))
    matrix = sp.Matrix([[sp.sympify(vector[block]["rows_0_1"][i])
                         for block in ("Phi", "Sigma")] for i in (0, 1)])
    assert matrix == sp.Matrix([[105, sp.Rational(9, 10)], [100, sp.Rational(9, 10)]])
    assert matrix.det() == sp.Rational(9, 2)
    assert trace == {"Phi": "7200", "Sigma": "90"}

    # Constant-patch integration by parts carries B to div(B), not to zero.
    # Scalar and ghost changes have different carrier support from this term.
    lp, ls = sp.symbols("L_Phi L_Sigma")
    weights = sp.Matrix([sp.Rational(3, 2) * lp, sp.Rational(17, 8) * ls])
    assert sp.solve(list(matrix * weights), (lp, ls)) == {lp: 0, ls: 0}
    c = sp.symbols("color_weight")
    for dimension in (2, 4, 6):
        # Two mixed propagators produce the angular metric 1/D. In the
        # quartic expansion each of the D-1 transverse slots contributes.
        assert sum(c / dimension for mu in range(dimension) if mu != 0) == c * sp.Rational(dimension-1, dimension)
    return {"vector": vector, "scalar_trace": trace,
            "vector_rank": {"determinant": str(matrix.det()),
                            "vanishing_requires": ["L_Phi=0", "L_Sigma=0"]},
            "four_dimensional_reduced_Lorentz_factor": "3/4"}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
