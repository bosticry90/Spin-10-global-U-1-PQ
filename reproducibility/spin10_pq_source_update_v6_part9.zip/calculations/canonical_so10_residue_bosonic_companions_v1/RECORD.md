# V917 pre-execution contract

Test the fixed contracted-species DMM finite residue in V916 on the
physical B^4 and B^2 x_Phi^2 vertices. Use the same tensor on the two
vector ports at the contracted vertex. Keep both source and ghost
weights fixed by the V916 unit-switch comparison. Test whether a
common kappa at distinct positive reference squared masses can avoid
the induced uncut bosonic terms within this restricted map.

Require exact native/replay joined group arithmetic, a nonzero rank
certificate, and explicit Lorentz contraction and uncut variation.
Only a failure of this fixed-kernel two-residue strategy is within
scope. No other finite local map, field redefinition, quantum
amplitude, observable or authority will be accepted by this test.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.
