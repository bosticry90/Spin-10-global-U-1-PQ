# Bosonic companions of a fixed DMM residue

Grant the projected V916 match using the complete V270 F table.
A causal implementation of that scalar-source projection requires
linked H and M ghost kernels and compact balanced derivatives.
The ghost comparison alone does not determine that H choice.
This test concerns the ordinary DMM bosonic contraction even if
the FMY source completion can be implemented.

Hold the two-vector DMM contraction fixed. Its two g xi Lambda E_s x
vertices give color G_s = E_s E_s^t and its two mixed propagators give
angular tensor eta_mu,nu/D up to a common nonzero residue and phase.
On the actual gauge vertex g²[B_mu,B_nu]²/4 substitute B+h and pair
two h with covariance eta_mu,nu G_s/D. The [h,h] cross term vanishes
by color symmetry. The two squares in [h_mu,B_nu]+[B_mu,h_nu] give
2D and the cross term -2, before the common angular denominator.
After stripping common factors the Lorentz multiplier is (D-1)/D.
The induced quadratic color matrix is

    K_s[b,c] = sum_(a,u,v) G_s[u,v] f[a,u,b] f[a,v,c].

The exact joined group calculation gives two independent rows.
For vector colors 0 and 1 and columns Phi and Sigma they are

    [[105, 9/10],
     [100, 9/10]],

of determinant 9/2. The traces are 4800 and 60, independently
checked as 8 tr(G_s). This effect is at g⁴ xi² and switch degree
three. With the V916 weights 3 L_Phi/2 and 17 L_Sigma/8,
vanishing at unit switch requires both L_s=0. Their difference
is log(M_Sigma/M_Phi), which excludes that outcome for every
common kappa at distinct positive reference squared masses.

The same angular and color contraction on the physical B² x_Phi²
kinetic vertex gives the scalar matrix

    A_(s,Phi) = sum_(u,v) G_s[u,v] rho_Phi[u]^t rho_Phi[v].

The Lorentz contraction of eta/D with the two B ports supplies one.
The exact traces are 7200 and 90 for internal Phi and Sigma. These
are induced local color tensors of the chosen kernel.

The B² variation under linear Q B = partial C contains B^t K partial C.
At unit switch on a patch its integrated image is proportional to
-div(B)^t K C on unrestricted off-shell test fields. The YY and FMY
fixed contractions have odd ports and cannot act on the all-bosonic
quartic. Their measured scalar-source shifts cancel in the granted
projection. Preserving the uncut master insertion therefore needs an
additional correlated source or action term in this construction.
An affine background transformation would require its own companion.

This excludes the restricted map with the same fixed kernel and other
unit-switch action/source terms held fixed. Other correlated
normalizations and amended identities remain open. No loop coefficient
is fitted. The exact native and replay arithmetic share the physical
action, convention and software. In the V900 current chart the
Lambda,C Euler coefficient is i sigma times the signed current-chart
a,C action coefficient. The V916 compensation arithmetic is in
stripped physical units and its Wick push must accompany that rule.
