# V917 result

The fixed DMM contraction in the V916 projected proper alternative
induces a quadratic term from the actual physical gauge quartic.
The Phi and Sigma contributions are linearly independent in two
diagonal color rows, with determinant 9/2 after removing the
common nonzero Lorentz factor. The resulting unit-switch gauge
term survives for every common kappa at distinct positive squared
reference masses. The same contraction induces a Phi scalar
quadratic contribution with separate traces 7200 and 90.

The gauge quadratic term has a nonzero linear master variation
on unrestricted off-shell fields. The restricted two-residue
construction thus needs additional action or source companions
even granting the V916 ghost and scalar-source match. The result
leaves the admissibility of a larger common map open. This is an
exact fixed-kernel contraction test with the same physical inputs
and software in both routes. No new full loop, physical
observable or authority qualification.
