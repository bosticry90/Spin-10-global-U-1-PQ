# Explicit scalar-root bound and its domain controls

For epsilon>0 and p in R4, define
 F_epsilon(p)=integral_R4 exp(-|l|^2/epsilon^2)/|p-l| dl.
The unnormalized measure is used only in this majorant. The Schwinger
identity 1/r=pi^-1/2 integral_0^infinity a^-1/2 exp(-a r^2)da and a
four-dimensional Gaussian integral give

 F_epsilon(p)=pi^(3/2) integral_0^infinity
   a^-1/2 (epsilon^-2+a)^-2
   exp[-epsilon^-2*a*p^2/(epsilon^-2+a)] da.

All terms are positive. Dropping the last exponential gives the exact
maximum bound

              F_epsilon(p)<=pi^(5/2) epsilon^3/2.

It agrees with direct spherical integration at p0. On substituting
a=w^2/epsilon^2, F_epsilon(epsilon P)/epsilon^3 is a bounded positive
function independent of epsilon. Weighted Schwartz factors and the
polynomial numerator of the scalar kinetic vertex do not change the
epsilon^3 upper bound for epsilon<=1 (the regular part has epsilon^4).
This is the explicit global majorant used in PROOF, not an assertion
based on a few finite-width evaluations or a formal scaling label.

For a normalized Gaussian delta_sigma in the dp/(2pi)^4 convention, the
massive scalar root has pairing

 integral_0^infinity u exp(-u)/(m2+sigma^2*u)du <=1/m2,
                    limit_sigma0=1/m2.

This follows by p^2=sigma^2*u and dominated convergence. A massless
replacement gives1/sigma^2, losing the bound uniform in the root-mollifier
width. It is outside the fixed positive-reference theorem. No inference
about all possible massless extension prescriptions is made.

Finally the actual scalar-carrier convolution I(s,t,m2) in PROOF obeys

 I/t^2 -> integral_0^infinity K^3 exp(-sK)/(K+m2)dK >0.

The inequality (1-exp(-tK))/t<=K supplies dominated convergence. Thus an
artificial t^-2 coefficient would leave a finite nonzero answer. The
zero-extension theorem applies to finite A0 tadpoles after the actual
proper UV subtraction and to the bare intrinsic01 exclusions; it cannot
be used to erase a divergent coefficient before its subtraction.
