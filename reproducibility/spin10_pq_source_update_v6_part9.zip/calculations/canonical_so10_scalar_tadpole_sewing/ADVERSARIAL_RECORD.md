# STS3: scalar-root infrared and finite-coefficient controls

Prospective after accepted nativeV2/reviewV3. Earlier failed nativeV1 and
reviewV2 sources/captures remain unchanged. Same domain and resources;
review180s/8GiB sampled,350MiBlaunch,16MiB packet. No physical changes.

Authenticate the old CNS complete adjoint invariant dimension2 and ESM
basis split nY/e12, rather than interpreting a displayed vector as a proof
of a complete invariant space. Independently check the Gaussian/Riesz
convolution giving the epsilon^3 remainder in the scalar-root estimate.
Derive the uniform Schwinger bound and test its scaled profiles. Check
that a normalized massive root-delta pairing is bounded by1/m2 whereas
replacing the reference by a massless scalar loses this bound. This is an
excluded-domain control, not adoption or refutation of a massless scheme.

The existing finite-heat scalar convolution is nonzero. Its limit divided
by t^2 is a nonzero positive moment; an artificial t^-2 tadpole would
therefore evade the finite-A0 proof. Keep that excluded coefficient
class explicit. A scalar covariance test vector is not an adopted fully
admissible A0 normalization. No connected Ward identity is tested here.
