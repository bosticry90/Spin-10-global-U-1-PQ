from pathlib import Path
from hashlib import sha256
import ast,json,sys,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-tadpole-sewing-v1-2026-10-27')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    bindings=dict(read(O/'review_preparation_v3.json')['input_sha256'])
    for p,h in bindings.items():assert digest(Path(p))==h,p
    assert read(O/'review_capture_v3.json')['execution_state']=='COMPLETED'
    p=R/'calculations/canonical_so10_connected_source_sewing/adjoint_result_v2.json'
    seal=R/'calculations/canonical_so10_connected_source_sewing/final_review_validation_receipt.json'
    expected=read(seal)['new_files_sha256'][p.relative_to(R).as_posix()];assert digest(p)==expected
    bindings[str(p)]=expected;bindings[str(seal)]=digest(seal)
    for p in list(O.iterdir()):
        if p.suffix in ['.py','.md'] and not(O/(p.name+'.source.txt')).exists():
            if p.suffix=='.py':ast.parse(p.read_bytes())
            with(O/(p.name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
    for p in O.iterdir():
        if p.is_file():bindings[str(p)]=digest(p)
    dump(O/'adversarial_preparation.json',{'input_sha256':bindings,'scientific_acceptance':'NOT_PERFORMED'})
    cap=capture([sys.executable,'-B',str(O/'adversarial.py')]);dump(O/'adversarial_capture.json',cap);dump(C/'adversarial_full_capture.json',cap)
    assert cap['exit_code']==0 and cap['execution_state']=='COMPLETED' and cap['calculation_completed'] and cap['post_run_observations_qualified']
    print('COMPLETED STS3 scalar-root majorant and excluded-domain controls',flush=True)
except BaseException:
    dump(O/'adversarial_controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
