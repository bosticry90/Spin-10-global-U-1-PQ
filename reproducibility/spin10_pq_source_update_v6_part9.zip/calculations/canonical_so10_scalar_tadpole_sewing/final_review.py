from pathlib import Path
from hashlib import sha256
import ast,json,os,subprocess,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-tadpole-sewing-v1-2026-10-27')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
bindings={};preps=[]
for p in sorted(O.glob('*preparation*.json')):
    preps.append(p.name)
    for name,h in read(p)['input_sha256'].items():
        assert digest(Path(name))==h,(p.name,name)
        if name in bindings:assert bindings[name]==h
        bindings[name]=h
copies=list(O.glob('*.source.txt'))
for p in copies:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes(),p
for p in O.glob('*.py'):ast.parse(p.read_bytes())
for p in O.iterdir():
    if p.suffix in ['.py','.md','.txt']:assert all(z==z.rstrip(b' \t') for z in p.read_bytes().splitlines()),p
accepted={'native_capture_v2.json','review_capture_v3.json','adversarial_capture.json','e4_capture.json'}
failed={'native_capture.json':'assert len(physical[', 'review_capture_v2.json':'defect.todok().values()'}
seen=set();samples={}
for p in O.glob('*capture*.json'):
    seen.add(p.name);cap=read(p)
    assert cap['launch']['creation_after_observation'] and not cap['failed_or_incomplete_counted_as_PASS']
    assert cap['launch']['memory']['available_pagefile']>=350*1024**2
    assert cap['all_resource_samples'] and all('query_error' not in z and 0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
    samples[p.name]=max(z['private_bytes'] for z in cap['all_resource_samples'])
    if p.name in failed:
        assert cap['execution_state']=='FAILED' and cap['exit_code']!=0 and not cap['calculation_completed']
        assert failed[p.name] in cap['stdout_and_stderr']
    else:
        assert p.name in accepted and cap['execution_state']=='COMPLETED' and cap['exit_code']==0
        assert cap['calculation_completed'] and cap['post_run_observations_qualified']
assert seen==accepted|set(failed)
assert {p.name for p in O.glob('*controller_failure*.json')}=={'controller_failure.json','review_controller_failure_v2.json'}
for name in ['native_result.json','validation_receipt.json','validation_receipt_v2.json','review_capture.json']:
    assert not(O/name).exists(),('REJECTED_OR_UNEXECUTED_VERSION_RECEIPT',name)
a=read(O/'native_result_v2.json');b=read(O/'validation_receipt_v3.json');c=read(O/'adversarial_validation_receipt.json')
assert a['elapsed_after_imports']<300 and b['elapsed_after_imports']<180 and c['elapsed_after_imports']<180
assert len(a['all_N_intertwiner_checks'])==24 and all(z['N_R_equals_A_N'] and z['defect_rows']==0 for z in a['all_N_intertwiner_checks'])
assert a['actual_scalar_reference_blocks']==[54,252,20,2] and a['all45_R_preserve_mass_blocks']
assert a['noncovariant_mass_split_and_N_omission_sensitive']
assert len(a['physical_scalar_cubic_classes'])==8 and a['bare_scalar_tadpole_minimum_intrinsic']==1
assert a['actual_e12_auxiliary_and_FBB_roots_zero'] and not a['finite_scalar_tadpole_constants_set_or_fitted']
assert all(z['v_entries']==16 and z['H_invariant'] and z['full_A0_admissibility_not_claimed'] for z in a['scalar_covariant_test_covectors'])
assert b['all12_N_intertwiner_sparse_matrix_checks'] and b['kinetic_Euler_divB_and_two_gradient_terms_retained']
assert b['nonlinear_inverse_chain_rule_checked'] and len(b['finite_heat_radial_Schwinger_closed_form'])==3
assert b['selected_finite_scalar_tadpole_extension']=='ZERO_UV_FIRST_AUDITED_COVARIANT_MASSIVE_ROOT_FREE_EDGE_IR_CLASS'
assert b['selected_five_term_extension_supported'] and not b['connected_Ward_QAP_E5_physical_claim']
assert c['complete_adjoint_invariant_dimension_authenticated']==2 and c['M_invariant_direction']=='e12_only'
assert c['massless_reference_would_lose_uniform_root_bound'] and c['artificial_divergent_tadpole_control_nonzero']
assert 'Focused result-to-claim assessment' in (O/'RESULT.md').read_text()
assert 'vacuous projection' in (O/'RESULT.md').read_text()
assert 'C(t^2+epsilon^3)' in (O/'PROOF.md').read_text()
assert 'pi^(5/2) epsilon^3/2' in (O/'IR_BOUND.md').read_text()
events=read(O/'e4_events.json');steps=[z for z in events if z['event']=='step_finished'];exits=[z['exit_code'] for z in steps]
assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested']
assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
assert read(O/'e4_capture.json')['elapsed_seconds']<300
git=lambda *args:subprocess.run(['git',*args],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()=='2b47137f09b96a707ce07ded7153156eeb5269a3'
assert git('branch','--show-current').decode().strip()=='main'
assert git('ls-tree','-r','--full-tree','HEAD')==(C/'old_git_tree.txt').read_bytes();git('diff','--quiet','HEAD','--')
state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
size=sum(p.stat().st_size for p in O.rglob('*') if p.is_file());assert size<16*1024**2
out={'schema':'STS_FINAL_EVIDENCE_REVIEW','evidence_validation':'PASS_BOUNDED_SCALAR_TADPOLE_AND_SELECTED_FIVE_TERM_EXTENSION',
 'preparations':preps,'input_bindings_authenticated':len(bindings),'source_copies_equal':len(copies),
 'accepted_completed_captures':sorted(accepted),'failed_scientific_captures_preserved':sorted(failed),
 'original_review_V1_never_executed':True,'actual_scalar_reference_and_mixing_covariance_checked':True,
 'finite_scalar_tadpole_zero_extension':'UV_FIRST_AUDITED_MASSIVE_ROOT_FREE_EDGE_CLASS',
 'five_selected_Legendre_terms_have_common_extension':True,'connected_Ward_QAP_E5_physical_claim':False,
 'analytic_proofs_not_formal_assistant_certified':True,'finite_tadpoles_not_fixed':True,
 'E4_step_exits':exits,'custody':'EXIT2_SEVEN_UNRESOLVED_NOTPASS','state_sha256':state,
 'old_tracked_tree_unchanged':True,'largest_accepted_private_sample':max(samples[n] for n in accepted),
 'largest_all_captures_private_sample':max(samples.values()),'memory_samples_not_true_peak':True,
 'packet_bytes_before_final_capture_and_seal':size,'elapsed_after_imports':time.perf_counter()-tick,
 'scientific_acceptance':'NOT_PERFORMED'}
with(O/'final_review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
