from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict,Counter
import gzip,json,os,sys,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'))
import jets as J
from coefficient_ring import coefficient,expression,g,xi,eta
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p
@lru_cache(None)
def co(z):return coefficient(s.sympify(z,locals={'g10':g,'xi':xi,'eta_H':eta}))
def clean(A):return {k:v for k,v in A.items() if v}
def add(A,B,sign=1):
    C=dict(A)
    for k,v in B.items():C[k]=C.get(k,J.ZERO)+sign*v
    return clean(C)
def mul(A,B):
    rows=defaultdict(list);out={}
    for (i,j),v in B.items():rows[i].append((j,v))
    for (i,k),v in A.items():
        for j,w in rows[k]:out[i,j]=out.get((i,j),J.ZERO)+J.times(v,w)
    return clean(out)
def block(i):
    assert 0<=i<328
    return 0 if i<54 else 1 if i<306 else 2 if i<326 else 3

planes=load(R/'calculations/canonical_so10_even_source_mean_response/plane_tables_v2.json.gz')
outrows=[];witnesses=[]
for role in ['primary','replay']:
    um=load(R/f'calculations/canonical_so10_u_maximal_heat_cutoff/{role}_inputs.json.gz')
    fi=load(R/f'calculations/canonical_so10_full_jet_source_master_bridge/{role}_inputs.json.gz')
    row=next(z for z in planes['routes'] if z['role']==role and z['probe']==1)
    EL={r:J.decode(z) for r,z in row['E_Lambda']}
    N={(r,w[0][0]-180):c for r,z in EL.items() for w,c in z.items() if len(w)==1 and 180<=w[0][0]<508}
    expected={(i-45,j):co(v) for i,j,v in um['N0']['entries']}
    assert N==expected and len(N)==296 and all(i>=12 for i,j in N)
    assert not {w:c for w,c in EL[12].items() if len(w)==2 and all(i<180 for i,js in w)}
    flows={r:J.decode(z) for r,z in um['field_flows']}
    H=[]
    for h in range(12):
        A={}
        for r in range(45):
            for w,c in flows[4*r+3].items():
                if len(w)!=2 or (553+h,()) not in w:continue
                other=[(i,js) for i,js in w if i!=553+h]
                if len(other)==1 and other[0][0]<180 and other[0][0]%4==3 and not other[0][1]:A[r,other[0][0]//4]=c
        Rh={(i,j):co(v) for i,j,v in um['R'][h]['entries']}
        assert all(v==-Rh.get((j,i),J.ZERO) for (i,j),v in Rh.items())
        assert all((i<12)==(j<12) for i,j in A)
        residual=add(mul(N,Rh),mul(A,N),-1);assert not residual,('N_NOT_INTERTWINER',h)
        assert all(not A.get((r,12),J.ZERO) for r in range(45))
        H.append(Rh)
        outrows.append({'role':role,'h':h,'N_R_equals_A_N':True,'defect_rows':0,'R_entries':len(Rh),'A_entries':len(A)})
    # Actual scalar reference and fixed chart preserve the four mass blocks.
    ref=read(R/f'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_full_hessian/{role}.json')['retained_reference']
    refs=[(i,j,z) for i,j,z in ref['reference_Hessian_raw_C3']['entries'] if 180<=i<508 or 180<=j<508]
    assert len(refs)==328 and all(i==j and 180<=i<508 for i,j,z in refs)
    for i,j,z in refs:
        token=['Mref_Phi_squared','Mref_Sigma_squared','Mref_phi_squared','Mref_S_squared'][block(i-180)]
        assert token in z and sum(name in z for name in ['Mref_Phi_squared','Mref_Sigma_squared','Mref_phi_squared','Mref_S_squared'])==1
    assert not ref['scalar_reference_masses_are_adopted_physical_parameters']
    for i,j,z in fi['frame']['Q']['entries']:
        if 180<=i<508 or 180<=j<508:assert 180<=i<508 and 180<=j<508 and block(i-180)==block(j-180)
    for rr in um['R']:
        assert all(block(i)==block(j) for i,j,z in rr['entries'])
    # A sensitive noncovariant reference split uses an actual off-diagonal entry.
    Rh=next(A for A in H if any(i!=j for i,j in A))
    bad_i=next(i for i,j in Rh if i!=j)
    assert any(((i==bad_i)-(j==bad_i))*v for (i,j),v in Rh.items())
    # Deleting one noninvariant N entry defeats (1), rather than fitting it.
    badkey=next(k for k in N if k[0]>12);badN=dict(N);del badN[badkey]
    bad_sensitive=False
    for h,Rh in enumerate(H):
        A={}
        for r in range(45):
            for w,c in flows[4*r+3].items():
                if len(w)==2 and (553+h,()) in w:
                    other=[(i,js) for i,js in w if i!=553+h]
                    if len(other)==1 and other[0][0]<180 and other[0][0]%4==3 and not other[0][1]:A[r,other[0][0]//4]=c
        bad_sensitive|=bool(add(mul(badN,Rh),mul(A,badN),-1))
    assert bad_sensitive
    # Actual H-invariant diagnostic scalar covector, not an adopted A0 value.
    w={(j,0):v for (i,j),v in N.items() if i==12}
    R12={(i,j):co(v) for i,j,v in um['R'][12]['entries']}
    chosen=None
    for b in range(4):
        wb={k:v for k,v in w.items() if block(k[0])==b}
        vv=mul(R12,wb)
        if vv:chosen=(b,wb,vv);break
    assert chosen is not None
    b,wb,vv=chosen
    assert all(not mul(Rh,vv) for Rh in H)
    norm=sum((J.times(c,c) for c in vv.values()),J.ZERO);assert norm
    witnesses.append({'role':role,'mass_block':b,'w_entries':len(wb),'v_entries':len(vv),
      'v_coefficients':[[i,str(expression(c.terms))] for (i,j),c in sorted(vv.items())],
      'v_dot_R12_w':str(expression(norm.terms)),'H_invariant':True,'full_A0_admissibility_not_claimed':True})
    # Every actual GF cubic with one scalar is intrinsically1, not a zero entry.
    lookup={name:i for i,name in enumerate(um['field_order'])};gfcounts=Counter()
    for term in fi['GF']:
        toks=[(name.partition('__')[0],name.partition('__')[2]) for name in term['word']]
        if any(name.startswith('A') for name,js in toks):continue
        ids=[lookup[name] for name,js in toks]
        if len(ids)!=3 or sum(180<=i<508 for i in ids)!=1:continue
        degree=4-sum(J.dimension(i)+len(js) for i,(name,js) in zip(ids,toks))
        kinds=tuple(sorted('B' if i<180 else 'x' if i<508 else 'L' if i<553 else 'C' if i<598 else 'a' for i in ids))
        assert degree>=1 and kinds==('C','a','x'),('UNEXPECTED_GF_SCALAR_CUBIC',kinds,degree)
        gfcounts[kinds,degree]+=1
    witnesses[-1]['GF_scalar_cubic_support']=[[list(k),d,n] for (k,d),n in sorted(gfcounts.items())]
    print('STAGE '+role+' actual scalar covariance/support',flush=True)
assert {k:v for k,v in witnesses[0].items() if k!='role'}=={k:v for k,v in witnesses[1].items() if k!='role'}

# Authenticate the already measured full e12 momentum zeros, not just a witness.
kt=load(R/'calculations/canonical_so10_regulated_auxiliary_sewing/kernel_tables.json.gz')
for z in kt['groups']:
    if z['invariant']==1:assert not z['numerator']

def shapes(node):
    typ=node['node']
    if typ=='Field':return {(tuple([node['name']]),0)}
    if typ in ['ExactScalar','Parameter','StructureConstant','RepresentationGenerator','KroneckerMetric','FrozenBackground','LorentzWeight']:return {((),0)}
    if typ=='PartialDerivative':return {(fs,ds+1) for fs,ds in shapes(node['argument'])}
    if typ=='LocalActionTerm':return shapes(node['density'])
    if typ in ['LorentzContraction','GroupContraction']:return shapes(node.get('expression',node.get('argument')))
    if typ=='Add':return set().union(*(shapes(z) for z in node['terms']))
    if typ=='OrderedProduct':
        out={((),0)}
        for z in node['factors']:out={(tuple(sorted(a+b)),d+e) for a,d in out for b,e in shapes(z)}
        return out
    raise AssertionError(typ)
physical=read(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json')
pc=[]
scalar_names={'x_Phi','x_Sigma','x_phi','x_S','Phi','Sigma','SigmaBar','phi','phiBar','S','SBar'}
for n,term in enumerate(physical['local_terms']):
    for fs,ds in shapes(term):
        assert set(fs)<=scalar_names|{'B'},('UNKNOWN_PHYSICAL_FIELD_NAME',fs)
        nx=sum(f in scalar_names for f in fs)
        if len(fs)==3 and nx:
            assert nx in [2,3]
            if nx==2:assert fs.count('B')==1 and ds==1
            if nx==3:assert ds==0
            pc.append({'term_number':n,'fields':list(fs),'derivatives':ds,'intrinsic_degree':4-len(fs)-ds})
assert len(physical['local_terms'])==34 and any(z['intrinsic_degree']==1 for z in pc)

# A single unshifted Yukawa insertion cannot close an ordinary Dirac Gaussian.
D=s.Matrix([[2,1],[3,4]]);Y=s.Matrix([[0,2],[-2,0]]);Yb=s.Matrix([[0,3],[-3,0]])
K=s.zeros(2).row_join(D).col_join((-D.T).row_join(s.zeros(2)))
G=K.inv();Hx=Y.row_join(s.zeros(2)).col_join(s.zeros(2).row_join(Yb))
assert s.trace(G*Hx)==0
anomalous=s.Matrix([[0,1],[-1,0]])
bad=G+anomalous.row_join(s.zeros(2)).col_join(s.zeros(2,4));assert s.trace(bad*Hx)!=0
out={'schema':'STS1_ACTUAL_SCALAR_TADPOLE_SUPPORT_AND_COVARIANCE',
 'all_N_intertwiner_checks':outrows,'scalar_covariant_test_covectors':witnesses,
 'actual_scalar_reference_blocks':[54,252,20,2],'canonical_chart_preserves_reference_mass_blocks':True,
 'all45_R_preserve_mass_blocks':True,'noncovariant_mass_split_and_N_omission_sensitive':True,
 'physical_scalar_cubic_classes':pc,'bare_scalar_tadpole_minimum_intrinsic':1,
 'single_unshifted_Yukawa_loop':'ZERO_OFFDIAGONAL_DIRAC_GREEN_VS_SAME_PAIR_VERTEX',
 'actual_e12_auxiliary_and_FBB_roots_zero':True,'finite_scalar_tadpole_constants_set_or_fitted':False,
 'no_connected_Ward_QAP_E5_or_physical_claim':True,'elapsed_after_imports':time.perf_counter()-tick,
 'scientific_acceptance':'NOT_PERFORMED'}
with(O/'native_result_v2.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({k:v for k,v in out.items() if k not in ['all_N_intertwiner_checks','physical_scalar_cubic_classes']},sort_keys=True),flush=True);timer.cancel()
