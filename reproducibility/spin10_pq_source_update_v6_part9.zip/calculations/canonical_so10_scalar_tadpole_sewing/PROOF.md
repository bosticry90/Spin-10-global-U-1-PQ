# The scalar tadpole requires its own nonlinear response

Prospective until actual support and separate review complete. These are
explicit analytic arguments, not machine-certified theorems inferred from
proof-string tests. All claims are coefficientwise in the unchanged formal
Born family and the domain of RECORD; no infinite resummation is used.

## 1. Covariance of the actual scalar reference and mixing

The actual scalar reference is diagonal with one positive squared mass
per real irreducible block:Phi54,Sigma252,phi20,S2. The fixed canonical
scalar chart preserves these four blocks. Every actual scalar R_h is
skew and stays within its block. Hence the Euclidean scalar reference
and its Green commute with each H generator. The actual constant scalar
mass insertions also preserve H. The same is true of every FINITE old
scalar constant chain and its central A0 heat/free-edge IR profiles.
Write this bounded massive scalar Green as S_t(p), or S_t,epsilon(p).
This statement retains positive REFERENCE masses and does not prove an
infinite-series inverse for a massless physical scalar.

Let N be the actual45x328 coefficient of Lambda^T N x. The ESM scalar
mixing has296 canonical entries and only M rows. Invariance gives

                 N R_h = A_h N, h in H.                       (1)

The A_h are the skew actual vector/auxiliary carriers, not the restricted
qLambda block alone. ESM/CNS already determined the complete invariant
adjoint covectors nY in H and e12 in M. In particular the M invariant
space is exactly span(e12). For any H-covariant finite local A0, its
constant scalar tadpole T_x=d_x A0 at zero fields satisfies R_h T_x=0
in the invariant bilinear pairing. Equation(1), skewness and scalar
reference commutation imply, at every root momentum p,

              T_x^T S_t(p) N^T = c_t(p) e12^T.                (2)

The finite scalar coefficients are not set to zero or solved from a Ward
remainder. Reality/parameter restrictions may reduce the allowed T_x;
the argument covers that subset without asserting its full rank. A
noncovariant scalar mass split need not obey(2) and is excluded, not adopted.

## 2. Actual nonlinear scalar equation through first intrinsic degree

On the even plane the actual first-probe action is the square of
Z=i divB+F_BB+Omega Lambda/2+N x-iJa on its selected sector, through
intrinsic01. This complete equality is owned by CTS/ESM/RAS, including
source terms. The scalar stationary equation at firstu is therefore

 x_u = -S_t(B_0) N^T [ Lambda_u + 2 P_sector Z_0 ],             (3)

where N^T P_H=0. Here S_t(B_0) is the formal scalar Green with the
ordinary covariant-kinetic B vertices inserted, with fixed scalar R_t.
At this order the physical scalar potential has no additional force:
its cubic couplings are intrinsic1 and all contributions require scalar
means absent at u0; quartic terms need additional scalar means. Ordinary
gauge/scalar kinetic terms contain two scalars. There is no unshifted BBx
vertex. The scalar/auxiliary feedback has two N crossings and is intrinsic2.

The zero-u nonlinear scalar response to two Ja sources is zero through
intrinsic1. Its only possible first-N force is N^T Lambda_0,ij. The
Yang--Mills force with two longitudinal source responses is transverse to
its root p and its mixed Lambda root vanishes. The GF BB force has zero
LambdaLambda Green. These are the RAS action-derived statements, not a
claim that the Yang--Mills force itself is zero. Thus x_0,i=x_0,ij=0 in
the present degree/source restriction, also before the heat limit.

Put V=Lambda_u+2P_sector Z_0. Differentiating (3) twice at J0 gives

 x_u,ij(p)=-S_t(p)N^T V_ij(p)
   -S_t(p){V_s,B[B_0,i] x_u,j + V_s,B[B_0,j] x_u,i}.           (4)

Both groups are required. In particular the second term cannot be removed
because x_0=0: the FIRST-U scalar linear response is nonzero. CTS derived

 x_u,j(l)=2i S_t(l)N^T P_sector (1-E_l)^2 h_j(l), E_l=e^-t l^2.

It includes the direct Nx vertex and the constant-chain Green response.
For the unbroken probe it is zero because N has no H rows.

The root projection in (2) annihilates the FIRST term of(4). RAS measured
Lambda_u,ij projected on e12 to be the zero full momentum kernel for both
probes, retaining every source pair and jet. The actual F_BB,12 is zero.
The base Lambda0,ij=0 just established and the regulated Lambda equation
give (Z_0,ij)_12=(1-E_p)(F_BB,ij)_12=0. Hence V_ij,12=0.
This is an exact covariant root cancellation off the singular nodes and
in the audited common coefficient construction; it is not a restriction
of an unconstructed distribution to p0. It holds at all p, so an arbitrary
finite c_t(p) in(2) does not introduce a new root delta ambiguity here.

## 3. The kinetic term is generally nonzero at finite heat

The scalar kinetic Euler operator is a covariant second derivative.
Its linear B vertex has momentum factor (k+2l)_mu B_mu(k), up to its
fixed connection coefficient/phase. With B_0,i=-i k_mu E_k h_i/k^2,
its absolute value is bounded by a fixed matrix factor times

                  E_k (1+2|l|/|k|) |h_i(k)|.                 (5)

The second scalar response group in(4) therefore contains a massive root,
a first scalar Green, and a double heat difference on the OTHER source
momentum l. It is not a source-free tadpole assigned the value zero.

An H-invariant test covector can be constructed from actual matrices:
w=N^T e12, v=R_12 w, restricting to a nonzero common scalar mass block.
Native/review check H-invariance and v^T R_12 w !=0. This is a diagnostic
covector, not a claim that v with this normalization belongs to the full
physical counterterm parameter/reality/PQ class. In the source12/source12
component its finite-heat kinetic response has a nonzero tensor factor
times the Gaussian convolution

 I(s,t,m2)=integral_0^infinity K exp[-(s+2t)K](1-exp[-tK])^2/(K+m2)dK,
                   s,t,m2>0,                                (6)

including the finite positive massive root factor and source placements.
The scalar radial convention is (16pi^2)^-1 I. Two routes evaluate(6):

 I=F(s+2t)-2F(s+3t)+F(s+4t),
 F(a)=1/a-m2 exp(a m2) E1(a m2),

or integrate tau>=0 with weight exp(-m2 tau) against
[(s+2t+tau)^-2-2(s+3t+tau)^-2+(s+4t+tau)^-2].
The integrand in(6) is positive. The finite-heat term cannot be discarded
as identically zero. The test widths are not physical masses/couplings.

## 4. Uniform extension of the finite scalar tadpole term

For arbitrary independent Schwartz directions, use
(1-E_l)^2<=t^2|l|^4. Each retained scalar constant-chain factor is bounded
by a finite polynomial and inverse powers of its positive reference mass.
The root S_t(p) is uniformly bounded for0<t<=1. Apply(5) and convolution
L1/Linfinity bounds: the weighted h_i(k)/|k| factor is integrable in4D,
and the weighted |l|^4 h_j(l) factor is bounded. Thus

              sup_p |T_x^T x_u,ij(p)| <= C(T_x,h_i,h_j)t^2.    (7)

The root-cancelled first group is already zero. Equation(7) controls the
entire external-momentum integral, not a fixed-momentum limit. There is
no unconstrained quantum loop here: T_x is the FINITE A0 tadpole. Pairing
with any normalized smooth root-delta mollifier of bounded L1 norm obeys
the same bound, uniformly in its width. Unlike the auxiliary dipole proof,
no evenness of that mollifier is needed for this regular massive root.

Keep the inherited free-edge IR proof profiles f_epsilon=chi_epsilon^2,
chi=1-exp(-q^2/epsilon^2), on both sides of every retained free Green.
The actual diagrammatic inverse/source defects are not set to zero.
In (3)/(4), the direct finite-edge expansion replaces the vector heat E
by F=f_epsilon E in the effective auxiliary force. The scalar Green is
the equally smoothed finite-chain expansion. It remains bounded and
H-covariant. The e12 root cancellation survives, since all profiles are
central and the RAS zero tensors stay zero.

Use (1-F_l)^2 <= C[t^2|l|^4+exp(-c|l|^2/epsilon^2)]. The extra Gaussian
convolution against1/|p-l| obeys a uniform bound C epsilon^3 in4D by
l=epsilon z and a near/far split; the polynomial momentum factors and
Schwartz seminorms remain finite. The nonsingular part is bounded by
C epsilon^4. Consequently the scalar pairing is bounded by

                          C(t^2+epsilon^3),                  (8)

uniformly in the root-delta width. First take UV finite part at fixed
epsilon, then remove epsilon. This defines the selected finite A0 scalar
tadpole contraction as ZERO. No finite zero-mode constant is selected
within this audited massive-root/free-edge class. The argument does not
permit inserting a t^-2 divergent tadpole into(7): that would leave the
nonzero moment integral K^3 e^-sK/(K+m2)dK. Proper UV subtractions must
still be transported at the same regulated mean as in CTS.

## 5. Bare scalar tadpoles and the complete selected five-term extension

At zero fields a scalar one-loop tadpole is formed from an actual cubic
vertex. Physical34 scalar cubic potentials are intrinsic1. The intrinsic0
scalar/gauge kinetic cubic is Bxx; after one scalar derivative its quantum
ports are Bx. A closing Green needs one N and is intrinsic1. All relevant
GF cubic terms with one scalar are Ca x at intrinsic1. Thus the bosonic/
ghost bare scalar tadpole has no intrinsic0 term. Constant scalar mass
chains do not change these port restrictions. They cannot turn a scalar
into a vector without N. This is a support result before integration.

The SMA Yukawa is linear in x and contains psi psi or barpsi barpsi.
At the unshifted x0 reference the fermion kinetic Gaussian, including
hatted terms, pairs only psi with barpsi. A single Yukawa vertex cannot
close a tadpole. The off-diagonal free Nambu Green times the same-pair
Yukawa Hessian has trace0. No massive physical fermion vacuum is being
substituted here. This is stronger than dropping a spin trace by assumption.

The scalar y_u,ij begins at intrinsic1; y_0,ij=0 through that order.
Therefore the bare scalar tadpole contraction at firstu has intrinsic>=2
and lies outside the retained01 coefficient. This does not say the actual
scalar tadpole is zero at higher degree, shifted vacuum or general mean.
Lorentz-preserving vector tadpoles and odd tadpoles vanish by their usual
zero-mean type restrictions; RAS/ESM own the auxiliary contribution.

Together with CTS's four non-tadpole extensions and RAS's finite auxiliary
zero extension, this supplies the FULL FIVE-TERM even two-Ja one-loop
extension in the selected domain, with all finite normalization jets from
the SAME parent functional. Source exchange is retained. It does not yet
establish the actual connected Ward cancellation: that requires the
transported regulator/source/Slavnov coefficients and any remaining
breaking. It is not a general connected generating functional at nonzero
means, all90 sources, multiple symmetry insertions, physical K products,
global phase/measure, causal/vacuum construction,E5/A5 or physical viability.
