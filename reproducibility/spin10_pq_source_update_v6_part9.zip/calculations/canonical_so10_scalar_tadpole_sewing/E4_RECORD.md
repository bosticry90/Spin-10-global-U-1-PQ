# Delegated E4 validation of the bounded checkpoint

Prospective after nativeV2/reviewV3/adversarial completion. Run
python -B tools/research_check.py e4 ONCE, no--fresh. Expected native0,
steps[0,0,0,0,0,2],terminalCOMPLETED,custody2/seven NOTPASS. Retain full
capture/events. Observe elapsed<300s,8GiB sampled private,350MiB launch
floor. Changed exits/counts/bounds require review, not automatic PASS.
This authenticates bounded evidence and does not promote scientific authority.
