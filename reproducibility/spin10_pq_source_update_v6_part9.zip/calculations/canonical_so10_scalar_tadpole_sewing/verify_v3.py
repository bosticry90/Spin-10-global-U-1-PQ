from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import gzip,json,os,threading,time
import sympy as s
import mpmath as mp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'review_preparation_v3.json')['input_sha256'].items():assert digest(Path(p))==h,p
um=load(R/'calculations/canonical_so10_u_maximal_heat_cutoff/replay_inputs.json.gz')
fj=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/replay_tables.json.gz')
native=read(O/'native_result_v2.json')
# Replay every physical34 monomial with a separate list-distributive walk.
physical=read(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json')
def literal(node):
    kind=node['node']
    if kind=='Field':return [([node['name']],0)]
    if kind=='Add':return [v for item in node['terms'] for v in literal(item)]
    if kind=='OrderedProduct':
        terms=[([],0)]
        for item in node['factors']:terms=[(f+g,d+e) for f,d in terms for g,e in literal(item)]
        return terms
    if kind=='PartialDerivative':return [(f,d+1) for f,d in literal(node['argument'])]
    if kind=='LocalActionTerm':return literal(node['density'])
    if kind in ['LorentzContraction','GroupContraction']:return literal(node.get('expression',node.get('argument')))
    assert kind in ['ExactScalar','Parameter','StructureConstant','RepresentationGenerator','KroneckerMetric','FrozenBackground','LorentzWeight'],kind
    return [([],0)]
classes=set()
for idx,term in enumerate(physical['local_terms']):
    for fields,derivatives in literal(term):
        scalar=[f for f in fields if f!='B']
        assert all(f in ['x_Phi','x_Sigma','x_phi','x_S','Phi','Sigma','SigmaBar','phi','phiBar','S','SBar'] for f in scalar)
        if len(fields)==3 and scalar:
            assert len(scalar) in [2,3]
            if len(scalar)==2:assert fields.count('B')==1 and derivatives==1
            else:assert derivatives==0
            classes.add((idx,tuple(sorted(fields)),derivatives,4-len(fields)-derivatives))
assert classes=={(v['term_number'],tuple(v['fields']),v['derivatives'],v['intrinsic_degree']) for v in native['physical_scalar_cubic_classes']}

# Matrix arithmetic independent of the native coefficient-ring contractions.
parameters=dict(zip(['g10','xi','eta_H'],s.symbols('g10 xi eta_H',real=True)))
@lru_cache(None)
def num(z):return s.sympify(z,locals=parameters)
N=s.SparseMatrix(45,328,{(i-45,j):num(v) for i,j,v in um['N0']['entries']})
RR=[s.SparseMatrix(328,328,{(i,j):num(v) for i,j,v in um['R'][h]['entries']}) for h in range(13)]
# Actual adjoint tensor supplied separately by q_a/qLambda carrier data.
# ESM qualified that this beta agrees with the vector carrier. Its three
# indices are decoded directly below; only the exact convention match is used.
import sys
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'))
import jets as J
from coefficient_ring import expression
assert parameters['g10']==expression((((1,0,0,0),__import__('fractions').Fraction(1)),))
ops={r:J.decode(z) for r,z in fj['operation']}
for h in range(12):
    aa={}
    for r in range(45):
        for w,c in ops[4*r+3].items():
            if len(w)!=2 or (553+h,()) not in w:continue
            other=[(i,js) for i,js in w if i!=553+h]
            if len(other)==1 and other[0][0]<180 and other[0][0]%4==3 and not other[0][1]:aa[r,other[0][0]//4]=expression(c.terms)
    defect=N*RR[h]-s.SparseMatrix(45,45,aa)*N
    assert all(s.simplify(v)==0 for v in defect.todok().values()),h
ww=N.T[:,12];target=native['scalar_covariant_test_covectors'][1];b=target['mass_block']
bounds=[(0,54),(54,306),(306,326),(326,328)];lo,hi=bounds[b]
w=s.Matrix([ww[i] if lo<=i<hi else 0 for i in range(328)]);v=RR[12]*w
assert all(s.simplify(z)==0 for h in range(12) for z in RR[h]*v)
assert s.simplify((v.T*RR[12]*w)[0]-num(target['v_dot_R12_w']))==0
assert (v.T*v)[0]!=0

# Derive the scalar kinetic Euler factor, keeping the derivative on B.
k=s.Matrix(s.symbols('k0:4'));l=s.Matrix(s.symbols('l0:4'));B=s.Matrix(s.symbols('B0:4'))
direct=sum((k[m]+2*l[m])*B[m] for m in range(4))
euler=sum(k[m]*B[m] for m in range(4))+2*sum(B[m]*l[m] for m in range(4))
assert s.expand(direct-euler)==0
at_zero=s.expand(direct.subs(dict(zip(l,-k))).subs(dict(zip(B,k/(k.dot(k))))))
assert s.simplify(at_zero+1)==0
omit_divB=2*l.dot(B)
assert s.simplify((direct-omit_divB).subs(dict(zip(B,k/(k.dot(k))))))==1

# Actual nonlinear response chain rule: inverse equation plus differentiation.
bb,j1,j2,mm,ss,z1,z2,v12=s.symbols('bb j1 j2 m s z1 z2 v12')
# S(B)^-1=ss + m B, V(J)=z1*j1+z2*j2+v12*j1*j2.
X=-(z1*j1+z2*j2+v12*j1*j2)/(ss+mm*(j1+j2))
mixed=s.diff(X,j1,j2).subs({j1:0,j2:0})
assert s.simplify(mixed-(-v12/ss+mm*(z1+z2)/ss**2))==0
assert s.simplify(mixed+v12/ss)!=0

# Finite heat convolution from radial momentum and separate Schwinger edges.
mp.mp.dps=42;rows=[];width=mp.mpf(3);mass=mp.mpf(1)
for ts in ['1','0.1','0.01']:
    tt=mp.mpf(ts)
    direct=mp.quad(lambda K:K*mp.exp(-(width+2*tt)*K)*(-mp.expm1(-tt*K))**2/(K+mass),[0,1,mp.inf])
    sch=mp.quad(lambda tau:mp.exp(-mass*tau)*(1/(width+2*tt+tau)**2-2/(width+3*tt+tau)**2+1/(width+4*tt+tau)**2),[0,1,mp.inf])
    FF=lambda a:1/a-mass*mp.exp(a*mass)*mp.e1(a*mass)
    exact=FF(width+2*tt)-2*FF(width+3*tt)+FF(width+4*tt)
    assert direct>0 and abs(direct-sch)<mp.mpf('1e-37') and abs(direct-exact)<mp.mpf('1e-37')
    rows.append({'t':ts,'radial_I':mp.nstr(direct,38),'Schwinger_difference':mp.nstr(direct-sch,6),'closed_form_difference':mp.nstr(direct-exact,6),'I_over_t2':mp.nstr(direct/tt**2,30)})
limit=mp.quad(lambda K:K**3*mp.exp(-width*K)/(K+mass),[0,1,mp.inf]);assert limit>0
assert abs(mp.mpf(rows[2]['I_over_t2'])-limit)<abs(mp.mpf(rows[1]['I_over_t2'])-limit)
single=mp.quad(lambda K:K*mp.exp(-5*K)*(-mp.expm1(-K))/(K+1),[0,1,mp.inf])
assert abs(single-mp.mpf(rows[0]['radial_I']))>mp.mpf('1e-5')
# IR Gaussian/Riesz scale: measure4 minus a single |.|^-1 kernel =3.
assert 4-1==3 and 4>0
proof=(O/'PROOF.md').read_text()
assert 'C(t^2+epsilon^3)' in proof and 'not a general connected generating functional' in proof
out={'schema':'STS2_INDEPENDENT_MATRIX_KINETIC_AND_SCALAR_EXTENSION_REVIEW',
 'evidence_validation':'PASS_BOUNDED_SCALAR_TADPOLE_ZERO_EXTENSION',
 'all12_N_intertwiner_sparse_matrix_checks':True,'actual_covariant_test_covector_nonzero':True,
 'kinetic_Euler_divB_and_two_gradient_terms_retained':True,'nonlinear_inverse_chain_rule_checked':True,
 'source12_zero_total_momentum_kinetic_factor':'-1_per_placement_up_to_fixed_connection_phase',
 'finite_heat_radial_Schwinger_closed_form':rows,'artificial_t_minus2_tadpole_limit':mp.nstr(limit,38),
 'single_instead_double_heat_difference_sensitive':True,'massive_root_IR_error_power':3,
 'general_Schwartz_bound':'C*(t^2+epsilon^3), uniform in root mollifier width',
 'selected_finite_scalar_tadpole_extension':'ZERO_UV_FIRST_AUDITED_COVARIANT_MASSIVE_ROOT_FREE_EDGE_IR_CLASS',
 'finite_tadpole_constants_set_or_fitted':False,'selected_five_term_extension_supported':True,
 'connected_Ward_QAP_E5_physical_claim':False,'analytic_proof_not_formal_assistant_certified':True,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'validation_receipt_v3.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
