# Scalar field-name classifier correction

NativeV1 FAILED after both full scalar covariance/reference audits, before
writing any native result or extension receipt. Complete source/copy,
capture and controller failure remain unchanged. It required a physical
intrinsic1 scalar cubic, but counted only field names beginning x_. The
actual frozen AST uses x_Phi,x_Sigma,x_phi,x_S for Cartesian kinetic terms
and Phi,Sigma,SigmaBar,phi,phiBar,S,SBar for covariant potential terms.
It therefore omitted the potential cubics from its diagnostic inventory.

NativeV2 uses an explicit complete scalar vocabulary and refuses EVERY
unknown physical field name. It reruns all original checks and the same
original assertion, with unchanged action, reference, limits and scientific
requirements. A distinct reviewV2 independently distributes the original
AST into literal monomial lists, treats every non-B field as a scalar only
after its vocabulary check, and compares the whole cubic inventory.

No native_result.json or validation_receipt.json exists from V1. Original
verify.py/run_review.py were frozen but NEVER EXECUTED; their new versions
bind the accepted nativeV2 result and add the independent literal replay.
This is a parser/classifier correction, not a failed physical support
theorem or permission to drop a field/vertex. All incomplete V1 claims
remain unqualified until completed V2 and review evidence establishes them.
