# Review parameter-type reconciliation

ReviewV2 FAILED at the first N R_h=A_h N matrix equation, before writing
any validation receipt. The complete failed source, frozen copy, capture
and controller failure remain intact. NativeV2 inputs/results are unchanged.

The review read N/R parameter strings using SymPy's default generic
g10,xi,eta_H symbols, while the separately imported exact jet coefficients
use the physically declared REAL symbols with those same names. SymPy
treats different assumptions as different symbolic types. The matrix
comparison therefore contained two distinct g10 objects printed alike.
Coefficient_ring.py explicitly declares all three parameters real.

ReviewV3 creates its OWN real parameter table for the independent matrix
arithmetic and uses it consistently for literal strings and comparison
targets. An explicit type-equality check with the jet-ring image is
required. It retains the same full matrix equalities, complete AST
inventory, kinetic/scalar convolution controls and analytic requirements.
No coefficient, sign, reference or action is changed, and no tolerance is
introduced. V2 remains a failed review; no validation_receipt_v2.json
exists. A V3 receipt is legitimate only after all original checks pass.
