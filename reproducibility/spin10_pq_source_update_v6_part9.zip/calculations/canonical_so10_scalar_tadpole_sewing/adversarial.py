from pathlib import Path
from hashlib import sha256
import json,os,threading,time
import mpmath as mp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'adversarial_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
adj=read(R/'calculations/canonical_so10_connected_source_sewing/adjoint_result_v2.json')
basis=read(R/'calculations/canonical_so10_even_source_mean_response/tadpole_result_v2.json')['invariant_tadpole_basis']
assert adj['adjoint_invariant_dimension']==2 and adj['H_M_blocks_preserved'] and adj['four_Lorentz_routes_equal']
assert [[i for i,v in enumerate(z) if v!='0'] for z in basis]==[[0,5,8],[12]]
mp.mp.dps=42;rows=[];maximum=mp.pi**mp.mpf('2.5')/2
for eps in ['1','0.25','0.1']:
    ee=mp.mpf(eps)
    for P in [0,1,3]:
        value=2*mp.pi**mp.mpf('1.5')*ee**3*mp.quad(lambda w:mp.exp(-w*w*P*P/(1+w*w))/(1+w*w)**2,[0,1,mp.inf])
        assert value>0 and value/ee**3<=maximum+mp.mpf('1e-38')
        if P==0:
            radial=2*mp.pi**2*mp.quad(lambda r:r*r*mp.exp(-r*r/ee**2),[0,ee,mp.inf])
            assert abs(value-radial)<mp.mpf('1e-37')
        rows.append({'epsilon':eps,'scaled_p':P,'F_over_epsilon3':mp.nstr(value/ee**3,36)})
root=[];m2=mp.mpf('1.3')
for sigma in ['1','0.1','0.01']:
    ss=mp.mpf(sigma)
    value=mp.quad(lambda u:u*mp.exp(-u)/(m2+ss**2*u),[0,1,mp.inf])
    assert 0<value<1/m2
    root.append({'sigma':sigma,'massive_pairing':mp.nstr(value,36),'massless_pairing':mp.nstr(1/ss**2,16)})
assert mp.mpf(root[-1]['massive_pairing'])>mp.mpf(root[0]['massive_pairing'])
review=read(O/'validation_receipt_v3.json');assert mp.mpf(review['artificial_t_minus2_tadpole_limit'])>0
out={'schema':'STS3_COVARIANT_ROOT_AND_IR_MAJORANT_ADVERSARIAL_REVIEW',
 'evidence_validation':'PASS_SCALAR_ROOT_BOUNDS_AND_EXCLUDED_DOMAIN_CONTROLS',
 'complete_adjoint_invariant_dimension_authenticated':2,'M_invariant_direction':'e12_only',
 'exact_uniform_Riesz_bound':'pi^(5/2)*epsilon^3/2','scaled_profile_checks':rows,
 'positive_scalar_reference_root_pairings':root,'massless_reference_would_lose_uniform_root_bound':True,
 'artificial_divergent_tadpole_control_nonzero':True,'finite_A0_constants_not_fixed':True,
 'full_connected_Ward_QAP_E5_physical_claim':False,'analytic_majorants_not_formal_assistant_certified':True,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'adversarial_validation_receipt.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
