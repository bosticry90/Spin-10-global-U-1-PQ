from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys,traceback
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-tadpole-sewing-v1-2026-10-27')
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
try:
    assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='2b47137f09b96a707ce07ded7153156eeb5269a3'
    C.mkdir(parents=True,exist_ok=True)
    with(C/'old_git_tree.txt').open('xb') as f:f.write(subprocess.check_output(['git','ls-tree','-r','--full-tree','HEAD']))
    files=[R/n for n in ['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md',
       'docs/SOLO_REVIEW_POLICY_V1.md','docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md',
       'docs/RESEARCH_EXECUTION_HANDOFF_V664.md',
       'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/export_a10_e5_antighost_vector.py']]
    inherited={}
    for folder in ['canonical_so10_connected_two_source_loop_domain','canonical_so10_regulated_auxiliary_sewing','canonical_so10_even_source_mean_response']:
        base=R/'calculations'/folder
        for prep in base.glob('*preparation*.json'):inherited.update(read(prep).get('input_sha256',{}))
        seal=read(base/'final_review_validation_receipt.json')
        inherited.update({str(R/p):h for p,h in seal['new_files_sha256'].items()})
        files.append(base/'final_review_validation_receipt.json')
    witness=R/'calculations/canonical_so10_local_covariant_reference_witness/validation_v2_receipt.json'
    inherited.update(read(witness)['input_sha256']);files.append(witness)
    for folder,names in {
      'canonical_so10_full_jet_source_master_bridge':['jets.py','primary_inputs.json.gz','replay_inputs.json.gz','replay_tables.json.gz'],
      'canonical_so10_intrinsic_full_source_descent':['coefficient_ring.py'],
      'canonical_so10_u_maximal_heat_cutoff':['primary_inputs.json.gz','replay_inputs.json.gz'],
      'canonical_so10_even_source_mean_response':['plane_tables_v2.json.gz','MEAN_RESPONSE_PROOF.md','tadpole_result_v2.json','covariance_validation_receipt.json'],
      'canonical_so10_regulated_auxiliary_sewing':['PROOF.md','PROFILE_AND_BOUND_SCOPE.md','kernel_tables.json.gz','validation_receipt_v2.json'],
      'canonical_so10_connected_two_source_loop_domain':['PROOF.md','RESULT.md','validation_receipt.json'],
      'canonical_so10_local_covariant_reference_witness':['DERIVATION.md']}.items():
        for name in names:
            p=R/'calculations'/folder/name
            assert digest(p)==inherited.get(str(p)),('NO_AUTHENTICATED_OWNER',str(p))
            files.append(p)
    for name in ['frozen_a10_e5_full_hessian/primary.json','frozen_a10_e5_full_hessian/replay.json',
      'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json']:
        p=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'/name
        assert digest(p)==inherited.get(str(p)),('NO_HISTORICAL_REFERENCE_BINDING',str(p));files.append(p)
    # The SMA prose/action interpretation is a declared inherited premise;
    # current Git custody does not itself execute or qualify its equations.
    gitbindings={}
    for name in ['ACTION_V1.md','validation_receipt.json']:
        p=R/'calculations/canonical_so10_sterile_matter_action'/name;rel=p.relative_to(R).as_posix()
        raw=subprocess.check_output(['git','hash-object','--no-filters','--',rel],text=True).strip()
        committed=subprocess.check_output(['git','rev-parse','HEAD:'+rel],text=True).strip();assert raw==committed
        gitbindings[rel]=raw;files.append(p)
    for p in list(O.iterdir()):
        if p.is_file():
            if p.suffix=='.py':ast.parse(p.read_bytes())
            assert all(z==z.rstrip(b' \t') for z in p.read_bytes().splitlines()),p
            with(O/(p.name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
    files.extend(p for p in O.iterdir() if p.is_file())
    dump(O/'preparation.json',{'base_HEAD':'2b47137f09b96a707ce07ded7153156eeb5269a3',
      'input_sha256':{str(p):digest(p) for p in files},'current_checkpoint_SMA_git_blobs':gitbindings,
      'scientific_acceptance':'NOT_PERFORMED'})
    cap=capture([sys.executable,'-B',str(O/'native.py')]);dump(O/'native_capture.json',cap);dump(C/'native_full_capture.json',cap)
    assert cap['exit_code']==0 and cap['execution_state']=='COMPLETED' and cap['calculation_completed'] and cap['post_run_observations_qualified']
    print('COMPLETED STS1 actual scalar reference, intertwiner and tadpole support',flush=True)
except BaseException:
    dump(O/'controller_failure.json',{'execution_state':'FAILED_OR_INCOMPLETE','traceback':traceback.format_exc(),'failure_relabelled_PASS':False});raise
