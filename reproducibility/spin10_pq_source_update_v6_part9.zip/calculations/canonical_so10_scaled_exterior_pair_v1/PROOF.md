# Scaled exterior roots and products beyond the first switch

Keep the literal V901 operator P+V, V=Box chi/2, both +i0 ghost
orientations and the ordered ghost sign. Work at fixed log-profile
width ell after choosing it sufficiently broad. Let j be a smooth
compact ordinary source and J its integral. In the rescaled
coordinates let j^[R](y)=R^4 j(Ry). The absorption parameter there
is eps=eta R². Take eps to zero with R going to infinity, including
the sequential boundary at each fixed R. A fixed nonzero eta in
the original coordinates is outside this statement.

## Linear limit with a localized potential

Fix 1/2<s<1 and write H^a for H^a(R_time;L²(R³_space)).
The V901 weighted operator T_eps=rho^-1 G_eps rho^-1 acts with
norm at most 4 on H^a for every real a and converges strongly
there by its temporal multiplier representation. Multiplication
by B=rho² V has norm at most ||B||inf+||partial_t B||inf on H^-s.
The H^1 estimate follows from the product rule and the triangle
inequality in the paired zeroth and first time derivatives.
Duality gives H^-1 and interpolation gives the intermediate
negative orders.

For z=t²/r² and w=log r/ell, one has
B=(1-z)[(2z-1)b''(w)/(2 ell²)-2z b'(w)/ell].
On the switch support r>=1, |partial_t z|<=2/r and
|partial_t w|<=1/(ell r). The derivative bound is

    ||partial_t B||inf <= 4||b'||inf/ell
                       + (7/2)||b''||inf/ell²
                       + ||b'''||inf/(2 ell³).

Choose ell so that four times the sum of both B bounds is below
one. This is possible for a fixed smooth b. The Neumann inverse
of 1+T_eps B exists with uniform bound on H^-s and converges
strongly as eps tends to zero.

In temporal Fourier variables the translated free point root is

    −e^(−i tau y0) exp(i sqrt(tau²+i eps)|x−y_sp|) /
                      (4 pi |x−y_sp|).

The sign in the harmless translation phase follows the Fourier
convention. With any fixed compact spatial cutoff the root lies
in H^-s since the square in time is dominated by
(1+tau²)^(-s) and the square spatial singularity is |x−y_sp|^-2,
locally integrable. The cut-off translated roots converge strongly
as (eps,y) tends to (0,0). A small spatial ball centered at the
translated pole contributes O(radius) to the squared norm,
uniformly near the limit. Outside that ball use dominated Fourier
convergence. Integrating the translates y/R against the original
compact source proves that d_R=G_eps j^[R] tends locally in this
spatial-cutoff H^-s sense to J d, where d=G_F delta_0.

For u_R=(P+V+i eps)^−1 j^[R] write u_R=d_R+w_R. The exact
weighted correction is

    rho^-1 w_R = −(1+T_eps B)^−1 T_eps (rho V d_R).

The right forcing converges in H^-s because rho V is spatially
compact and has bounded time derivative. The correction therefore
converges in H^-s with its inverse-radius weight. At finite R
and eps the original weighted L² inverse and this inverse agree
by their common Neumann sum on the intersection. This extends
to the finite-R eps boundary. Localizing in space gives the
linear point-root limit as a distribution, without a weighted
L² assumption on the point root.

## One derivative of local temporal regularity per free inverse

Let e_1,e_2 be fixed compact spatial cutoffs. In three space
dimensions Huygens support places the spatial kernel of
sin(t|D|)/|D| on the sphere of radius t. With the cutoffs on both
sides this operator is zero once t exceeds the largest separation
of the supports. Fix L larger than that separation. For
k=sqrt(tau²+i eps) in the upper half plane,

    e_1 G_eps(tau) e_2 =
       − integral_0^L exp(i k t) e_1 sin(t|D|)/|D| e_2 dt.

It follows from the Fourier multiplier formula or the spatial
spherical kernel. It remains valid at the boundary. Integrate by
parts with respect to the wave time t. The sine operator vanishes
at both endpoints, and its derivative is the bounded cosine
operator. Since |exp(i k t)|<=1 and |k|>=|tau|, the norm is
at most L times the cutoff norms divided by |tau| for |tau|>=1.
For |tau|<1 the sine operator has norm at most t. Thus this
localized free inverse is bounded H^a to H^(a+1) uniformly in
eps. It converges strongly in this mapping by the same finite
wave-time integral and Fourier dominated convergence. No such
gain with global inverse-radius weights is asserted.

In the correction equation w_R=−G_eps V(d_R+w_R), the forcing
V(d_R+w_R) converges in H^-s and has fixed compact spatial
support. The estimate gives localized strong H^(1-s) convergence
for w_R. Set w_1,R=−G_eps V d_R and w_2+,R=w_R−w_1,R.
The latter is −G_eps V w_R, and now the forcing converges
in H^(1-s). Thus w_2+,R converges locally in H^(2-s).
Multiplication by V and by fixed smooth test cutoffs is bounded
in these time Sobolev spaces. All constants can depend on the
fixed profile and cutoffs.

## Consequence for the two-root transition

Use two compact ordinary sources and the real compact
h=chi²(1−chi) on the rescaled profile. At finite R split the product
of the two full roots into bare times bare, both bare times the
single-insertion corrections, both bare times the two-or-more
insertion remainders, and the product of the full corrections.
Keep the same Feynman branch and inherited ordered ghost sign
in every term.

For this product classification take the sequential finite-R
Feynman boundary used by V899. The bare product with this h is the V899 exterior test. The
full-correction product converges by local strong L², since
1−s>0. Bare times the two-or-more insertion remainder converges
against h by H^-s,H^s temporal duality with spatial L². Here
2−s>s and all spatial cutoffs are fixed in the rescaled
coordinates. This is bilinear duality. Neither ghost root is
conjugated. The single-insertion terms require a separate
argument, because 1−s<s.

## The same-branch Feynman triangle

For one insertion and two point-source parameters z_a,z_C,
the distribution to push forward in x,y, up to its ordered
constant, is

    h(x) V(y) G_F(x−z_a) G_F(x−y) G_F(y−z_C).

The map from (x,y,z_a,z_C) to the three edge differences is a
submersion. Thus this is a pullback of a tensor product, defined
jointly before evaluation at point-source parameters. The
supports of h and V are compact away from the origin. Use
the wavefront-set pullback and proper pushforward rules as
stated in Brouder, Dang and Hélein, arXiv:1409.7662. Away
from the origin each massless position Feynman kernel has
the same single conormal ray at its null cone, as follows
from (−x²+i0)^−1. The orientation is common to all edges.

A nonzero wavefront covector after integration would require
zero summed covector in x and in y. At z_a=z_C=0, if a
singular edge is missing, a dangling endpoint forces the
adjacent edge covector to vanish. For three noncoincident
singular edges, x, y and x−y are null. Real null vectors
orthogonal in signature (1,3) are proportional, so
x=a l, y=b l for real nonzero a,b and null l. The zero
covector conditions, after a common factor, are

    a lambda_1 + (a−b) lambda_2 = 0,
    b lambda_3 − (a−b) lambda_2 = 0,

with all lambdas nonnegative. If a,b have the same sign,
the sum forces both outer lambdas to vanish, and then the
middle one vanishes since a≠b. If their signs differ, a
and a−b have the same sign, which gives the same conclusion.
At x=y allow even an arbitrary middle covector (xi,−xi).
The sum of the x,y covectors is then a nonnegative multiple
of the same outer conormal at the nonzero point. Its
vanishing forces both outer covectors and then xi to vanish.

This exclusion persists near (z_a,z_C)=(0,0). Otherwise a
sequence of edge covectors with unit total norm and zero
x,y sums would have a convergent subsequence over the fixed
compact support, with a forbidden nonzero limit. It follows
that the pushforward is smooth near the two point-source
parameters. Smearing those parameters with the original
scaled compact sources agrees with the finite-R mixed term.
Indeed the two outer smears give smooth functions and the
remaining middle distribution acts on a compact smooth
test. The approximate-identity limit therefore exists and
is the smooth kernel value at zero multiplied by J_a J_C.
The other insertion orientation interchanges the outer
sources and obeys the same calculation. The bare term can
also be verified by a two-edge pushforward in x, since two
common conormal rays cannot cancel on supp h.

Together with the two Sobolev product bounds this proves the
existence of the complete local exterior two-root limit for
this broad compact profile class. It gives a triangle and
higher-switch pairings in addition to the V899 bare value.
The sum has not been evaluated for the two profiles, so
its noncancellation has not been established. The independently switched inner threshold problem remains.
