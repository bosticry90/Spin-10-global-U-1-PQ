"""Exact carrier, power and endpoint controls for V902."""

import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def derivative_route(phase):
    z, ell, r, d1, d2, d3 = sp.symbols("z ell r d1 d2 d3")
    B = (1-z)*((2*z-1)*d2/(2*ell**2) - 2*z*d1/ell)
    t = sp.symbols("t")
    if phase == "native":
        z_derivative = sp.diff(B, z)
        b_derivative = sp.diff(B, d1)*d2 + sp.diff(B, d2)*d3
    else:
        z_derivative = ((3-4*z)*d2/(2*ell**2) - 2*(1-2*z)*d1/ell)
        b_derivative = (1-z)*((2*z-1)*d3/(2*ell**2) - 2*z*d2/ell)
    actual = z_derivative * 2*t*(1-z)/r**2 + b_derivative*t/(ell*r**2)
    target = (-4*t*(1-z)*(1-2*z)*d1/(ell*r**2)
              + t*(1-z)*(3-6*z)*d2/(ell**2*r**2)
              + t*(1-z)*(2*z-1)*d3/(2*ell**3*r**2))
    assert sp.expand(actual-target) == 0
    assert sp.factor(sp.Rational(1, 4)-z*(1-z)) == (2*z-1)**2/4
    return {"B_time_derivative_bound_weights": ["4/ell", "7/(2*ell**2)", "1/(2*ell**3)"],
            "cone_B_coefficient": "-b'/(2*ell)"}


def power_and_kernel_controls(phase):
    delta, R = sp.symbols("delta R", positive=True)
    if phase == "native":
        s = sp.Rational(1, 2)+delta
    else:
        s = 1-(sp.Rational(1, 2)-delta)
    assert sp.expand(2*s-1) == 2*delta
    assert sp.expand((1-s)-s) == -2*delta
    assert sp.expand((2-s)-s) == 1-2*delta
    assert sp.expand(1-s) == sp.Rational(1, 2)-delta
    rho = sp.symbols("rho", positive=True)
    assert sp.integrate(4*sp.pi*rho**2/rho**2, (rho, 0, delta)) == 4*sp.pi*delta
    x = sp.symbols("x", real=True)
    # The scalar integration-by-parts fixture vanishes at both cutoffs.
    a = x*(1-x)
    assert a.subs(x, 0) == a.subs(x, 1) == 0
    assert sp.integrate(sp.exp(sp.I*x)*a, (x, 0, 1)).expand() == (
        sp.I*sp.integrate(sp.exp(sp.I*x)*sp.diff(a,x), (x, 0, 1))).expand()
    j_scale = R**4
    assert j_scale*R**(-4) == 1
    previous = ROOT / "calculations/canonical_so10_lorentzian_exterior_inverse_v1/result.json"
    prior = json.loads(previous.read_bytes())["checks"]
    assert prior["radial"]["spatial_schur_constant"] == 4
    assert prior["source"]["first_switch_Born_sign"] == -1
    return {"scale_absorption": "eta*R**2", "spatial_pole_square_mass": "4*pi*radius",
            "single_insertion_duality_gap": "-2*delta",
            "two_or_more_duality_gap": "1-2*delta",
            "correction_product_time_margin": "1/2-delta",
            "Huygens_integration_by_parts_fixture": "PASS"}


def triangle_controls():
    # Scalar incidence acts independently on each spacetime coordinate.
    differences = sp.Matrix([[1, 0, -1, 0], [1, -1, 0, 0], [0, 1, 0, -1]])
    assert differences.rank() == 3
    a, b = sp.symbols("a b", real=True)
    balance = sp.Matrix([[a, a-b, 0], [0, b-a, b]])
    assert sp.ones(1, 2)*balance == sp.Matrix([[a, 0, b]])
    assert balance.subs(b, a) == sp.Matrix([[a, 0, 0], [0, 0, a]])
    assert balance.subs({a: 1, b: -1}) == sp.Matrix([[1, 2, 0], [0, -2, -1]])
    # Opposite external ray directions would allow a cancellation.
    assert (sp.Matrix([[1, -1]])*sp.ones(2, 1))[0] == 0
    return {"edge_map_rank_per_coordinate": 3, "proper_pushforward": "no interior cancellation",
            "opposite_branch_cancellation_detected": True}


def check(phase):
    return {"potential": derivative_route(phase),
            "kernel": power_and_kernel_controls(phase), "triangle": triangle_controls()}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
