# V902 pre-execution contract

Derive the linear scaled-source boundary of the V901 ghost
inverse and classify the terms of its two-root product by
exterior switch count. Retain the actual Feynman branch and
eps=eta R². Use H^-s for 1/2<s<1 and the compactly localized
three-spatial-dimensional wave kernel. Require exact derivative,
scaling, Huygens cutoff and Sobolev-order controls and verify the
single-insertion mixed product by same-branch wavefront
pushforward. Require existence of the full exterior product
limit and withhold its noncancellation until separately tested. No change of
normalization, new loop amplitude or protected promotion.

Native 120 s, final 180 s including E4 cap 120 s, sampled private
8 GiB, 350 MiB launch commit floor, 8 MiB artifact, 32 MiB packet.
Require replay, receipt and staged byte validation.
