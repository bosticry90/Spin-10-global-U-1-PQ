# Scaled Lorentzian exterior pair V902

For sufficiently broad real compact log-radial switches, the
linear scaled ghost root converges in a temporal negative
Sobolev topology after localizing the potential. The estimate
keeps the absorption parameter eta R². Compact spatial
localization of the free resolvent gains one time derivative
by the three-dimensional Huygens kernel. The product of two
corrections converges in local L¹. The bare root pairs with the
two-or-more insertion remainder by temporal Sobolev duality.

The remaining single-insertion triangle also has a limit. The
edge-difference map is a submersion. The common Feynman
conormal rays cannot sum to zero at both integrated vertices,
including at their coincidence. The pushforward is smooth in
the two source locations near the origin, and gives the mixed
limit for the actual compact sources. The same method verifies
the bare pairing away from the origin and reproduces the V899
branch. With the Sobolev limits this establishes existence of
the local full exterior two-root limit after the sequential
finite-switch Feynman boundary.

The dressed value has not been compared across profiles.
The independently switched inner kernels, complete causal
comparison and admissible modified normalization remain open.
The analytic argument and exact controls use the same model,
action and prescribed boundary.
