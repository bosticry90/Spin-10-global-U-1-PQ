# V963 · Scalar sector finite matching

The exact unit and first-switch equations have a formal
solution with independent sector weights. They require
`b_M=t_M=−g_MM`, `b_H=−g_HH`, `t_H=−g_HM`, and
`g_HH+g_MM=g_HM+g_MH`.

The light-center equation tests `b_M=t_M` without a
ghost contribution. In the selected positive massive
soft comparison the inherited two- and three-edge heat
lengths give `t_M−b_M=−3 log(3/2)/(64π²)`. A change
of common subtraction or positive reference mass leaves
this difference intact. This excludes the isolated
inherited radial assignment. Other admissible finite
contacts and quantum right-hand sides remain separate.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
