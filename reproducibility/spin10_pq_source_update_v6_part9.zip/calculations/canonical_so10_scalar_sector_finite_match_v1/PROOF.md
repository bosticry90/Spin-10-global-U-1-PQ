# Simultaneous unit and first-switch scalar conditions

Keep the V960 paired mixed-reference transport, the
V962 scalar master root and the fixed scalar driver of
V956. Work in the selected local skew transverse scalar
projection. Let g_HH,g_HM,g_MH,g_MM denote the lower
gauge-source weights in (ordinary B,ghost) order.
Let b_H,b_M be the linked scalar two-edge weights and
t_H,t_M the mixed triangle weights in V951/V956 units.
Define C_h=P_H K_H and C_m=P_M K_H. Then K_H=C_h+C_m
and K_M=8 I-K_H. The weights start independent.

At unit switch the V945 transverse allocation uses the
negative antighost derivative and direct ghost derivative.
The lower map is

    8 g_MM P_M + g_HH C_h + (2 g_HM+g_MH-2 g_MM) C_m.

At first switch only the antighost transfer differentiates
the switch. Its lower map is

    8 g_MM I + (g_HH-g_MM) C_h + (g_HM+g_MH-2 g_MM) C_m.

Add b_H K_H+b_M K_M to both, by V951 and V962.
The V961 mixed first-switch terms cancel within matched
pairs. The unit mixed triangle adds t_H C_m+t_M(-8 P_H+C_h).
Both action exports give rank four in P_H,P_M,C_h,C_m.
The H center and the broken singlet e12 lie in the
kernel of K_H. The center has a nonzero generator in
each of the three active scalar blocks.

Setting both maps to zero gives

    b_M=t_M=-g_MM,
    b_H=-g_HH,
    t_H=-g_HM,
    g_HH+g_MM=g_HM+g_MH.

Equal ghost weights therefore admit a formal solution
with opposite equal scalar weights. Test the inherited
radial assignment separately. At unit switch on the
light central color the lower ghost map and C_h,C_m
vanish. Its coefficient is exactly 8(b_M-t_M), for
all ghost weights. Use the V955 slice with zero transfer
at the mixed scalar endpoint and retain its full numerator.
In the positive massive soft limit the inherited common
normalized radial values of these weights give

    t_M-b_M = -3 log(3/2)/(64 pi^2).

The two- and three-edge lengths are four and six. The
common finite subtraction and positive reference mass
cancel from the difference. With scaled hard momentum
v the relative integrand tends to
(exp(-6v)-exp(-4v))/v. Its integral is -log(3/2).
The exponential difference removes the pole at v=0,
permitting the dominated relative limit. The positive
scalar mass permits the soft limit in this scalar
comparison. No ghost soft normalization enters it.
The equal-length control has zero difference.

Thus the isolated inherited common radial assignment
fails this unit equation although the color system has
a formal solution. This is a restricted incompatibility
for the specified signed, normalized graph directions.
Additional finite contacts, other master right-hand sides,
changes to the causal conversion and the full compact
and marked products remain open. Both replays share
the action, conventions and software.
