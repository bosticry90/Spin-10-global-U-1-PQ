# V963 pre-execution contract

Freeze the V945 separated ghost source rows, V951 linked
two-edge normalization, V955 massive soft difference,
and V960–V962 compact scalar projections. Solve the
unit and first-switch system using independent scalar
and ghost sector weights. Verify color independence
with both action exports. Test the inherited two- and
three-edge heat lengths on the light center at the
positive massive soft reference. Use no massless soft
ghost value. Keep independent contacts, other right-hand
sides, full compact products and physical masses open.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority change.
