"""Solve the scalar sector equations and test their heat-length witness."""

from collections import defaultdict
import importlib.util
import sys

import mpmath as mp
import sympy as sp

from execute import ROOT, run_worker


def color_controls(phase):
    path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
    spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
    source = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(source)
    _, entries, _, f, _, _ = source.owner.inputs(phase)
    casimir = defaultdict(lambda: sp.S.Zero)
    for a in range(12):
        for b in range(45):
            for k, first in f[a,b]:
                for i, second in f[a,k]:
                    casimir[i,b] -= first*second
    casimir = source.owner.clean(casimir)
    assert all((i < 12) == (j < 12) for i,j in casimir)
    C = sp.SparseMatrix(45,45,casimir)
    assert C == C.T and C[:,12] == sp.zeros(45,1)
    P_h = sp.diag(*([1]*12+[0]*33))
    P_m = sp.eye(45)-P_h
    C_h, C_m = P_h*C, P_m*C
    rank = sp.Matrix.hstack(*(part.reshape(2025,1) for part in (P_h,P_m,C_h,C_m))).rank()
    assert rank == 4
    (center,) = C[:12,:12].nullspace()
    center = center/next(v for v in center if v)
    for lo, hi in ((0,54),(54,306),(306,326)):
        rho_center = defaultdict(lambda: sp.S.Zero)
        for a, z in enumerate(center):
            for (i,j), value in entries[a].items():
                if lo <= i < hi and lo <= j < hi:
                    rho_center[i,j] += z*value
        assert source.owner.clean(rho_center)
    return rank


def sector_equations():
    hh, hm, mh, mm, bH, bM, tH, tM = sp.symbols("hh hm mh mm bH bM tH tM")
    unit_lower = sp.Matrix([0, 8*mm, hh, 2*hm+mh-2*mm])
    first_lower = sp.Matrix([8*mm, 8*mm, hh-mm, hm+mh-2*mm])
    bubble = sp.Matrix([8*bM, 8*bM, bH-bM, bH-bM])
    triangle = sp.Matrix([-8*tM, 0, tM, tH])
    unit = unit_lower+bubble+triangle
    first = first_lower+bubble
    expected = {bH:-hh, bM:-mm, tH:-hm, tM:-mm, mh:hh+mm-hm}
    assert sp.solve([*unit, *first], tuple(expected), dict=True) == [expected]
    assert all(sp.expand(v.subs(expected, simultaneous=True)) == 0 for v in [*unit,*first])
    assert unit[0] == 8*(bM-tM)
    assert unit[0].subs({bM:0,tM:1}) == -8


def heat_controls():
    with mp.workdps(48):
        lengths = (4, 6)
        target = -mp.log(mp.mpf(lengths[1])/lengths[0])

        def integrate(short, long, eps_mass):
            def integrand(v):
                if not v:
                    return mp.mpf(0 if eps_mass else short-long)
                return mp.exp(-short*v)*mp.expm1(-(long-short)*v)/(v+eps_mass)
            return mp.quad(integrand, [0, 1, mp.inf])

        assert abs(integrate(*lengths, mp.mpf(0))-target) < mp.mpf("1e-44")
        for mass in (1, 3, 11):
            relative = integrate(*lengths, mass*mp.mpf("1e-12"))
            assert target < relative < 0 and abs(relative-target) < mp.mpf("1e-8")
        assert integrate(4,4,mp.mpf(1)) == 0


def check(phase):
    rank = color_controls(phase)
    sector_equations()
    heat_controls()
    return {"four_color_directions_rank":rank,
            "simultaneous_fit":["b_M=t_M=-g_MM","b_H=-g_HH","t_H=-g_HM",
                                "g_HH+g_MM=g_HM+g_MH"],
            "light_center_required":"b_M=t_M",
            "common_radial_map_difference":"-3*log(3/2)/(64*pi^2)",
            "positive_mass_limit_controls":3}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
