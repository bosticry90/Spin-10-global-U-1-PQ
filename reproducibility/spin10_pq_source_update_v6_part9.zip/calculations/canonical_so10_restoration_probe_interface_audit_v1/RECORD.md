# Recovered probe interfaces and current campaign navigation

Continue05d91071d4166f42531e51a399dd10b41cfdd96a/main,V827 on D:.
User explicitly resumed the goal and requested implementation of the latest
assessment. Previous scientific turn made progress; V827 now has a completed
receipt after fresh5results/11artifacts and16 calibrations. Full goal ACTIVE,
state113/34of39 unchanged. Current AGENTS controls execution; no agents write
files, no new branch/worktree/push/external action/adoption/protected promotion.
Flavor remains paused and HB1/C5 blocked. Education voluntary/nonblocking.

Question RPI-1: do the CURRENT recovered full-source operators and probe
Euler maps equal the operands of the qualified FJB qG=QG construction in
the same Euclidean A0/intrinsic0/1/g<=1 chart? This is a necessary cheap
applicability test before asserting broader proper source identities or
commissioning further loops. Outcomes MATCH, exact MISMATCH, or incomplete
execution are meaningful. No mismatch is fitted away.

Reuse full FJB primary/replay tables and its actual final_review_validation
receipt, recovered native/replay F/E input packet, V801 finite source chain,
V825 full-source own-jet evidence, CPS source/hatted proof, V804 auxiliary
input, and the exact Stage D/E2 classical-master owner receipts/artifacts.
The earlier frozen_a10_bv_master is a failed predecessor, NOT the owner.
Bind it only to check that failure is not silently promoted. No historical
manifest is rebound and no old expensive master calculation is rerun.

Compare all643 recovered F0/F1 field columns with FJB full operation grades.
Compare all90 Ja/JLambda source columns at both grades, with the actual
LEFT source sign (-1)^p E. These are the only source arguments of actual
G/QG; scan BOTH G and QG before using that support. Other source operations
are not declared matched or zero. Separate FJB's unused higher-g words,
retaining their count/hash and original immutable source; the g<=1 quotient
is stable because all operation coefficients have nonnegative g degree.

Compute complete field+source Euler derivatives of each actual FJB qG
throughg1, then compare EVERY Fu0/Fu1/Eu0/Eu1 column in the recovered
packet. Save all row decisions/hashes and every complete nonzero difference,
not merely a matching count. Two known G/QG outputs may share software/
action conventions; equality tests the recovered interface, not independent
physical correctness or a new full q²G replay.

Controls derive full differences after setting sources zero BEFORE the
probe source derivative, and after omitting its odd-field pairing sign.
Preserve all changes and blind columns. No scientific expectation is used
to manufacture an unknown quantum coefficient. A mismatch completes the
audit negatively; it does not trigger an arbitrary correction or retry.

Explicit ceiling: Stage D/E2 provide a qualified inactive full-source
CLASSICAL master theorem. This audit authenticates its CORRECT owners but
does not by itself prove complete recovered-action/E2 conjugacy, nonlinear
source transport, a continuum measure/QAP, or new sourceful proper zeros.
FJB+Jacobi reuse remains conditional on the full parent/chart identification.
Retained hatted curvature is not globally set zero. No complete admitted
correction/cohomology basis or HB1/C5 activation occurs.

The same bounded increment implements minimal current README navigation
and one common-restoration campaign dependency note, as explicitly requested.
Only README's live prefix may change; its ef70f25 historical suffix must
remain BYTE IDENTICAL. All other old tracked mode/blob entries and state
must remain unchanged. Preserve the old live README on D: controls before
editing. Navigation points to existing evidence, never another status ledger.

Primary worker240s after imports/8GiB sampled private/350MiB launch floor,
64MiB packet/10MiB artifact; freeze sources/inputs before execution and save
full captures repo+D before judging success. Failure/exhaustion incomplete,
no truncation or silent expansion. Final review freezes separately: one
fresh complete interface replay, historical-suffix/link checks, E4 once/
no-fresh/fixed D: context, unchanged state/oldtree except authorized README
prefix, then separate staged-byte guard before local commit. Scientific
acceptance remains NOT_PERFORMED. Shared sources/chart/ring/AI author limit
independence; no outside scientist, formal kernel or empirical result.
