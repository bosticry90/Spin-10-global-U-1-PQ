# ToE-Next: research entry point

ToE-Next investigates a Spin(10) x global U(1)PQ gauge-scalar construction
and evaluates AI scientific capability alongside the physics. Its results
are bounded mathematical and computational evidence. A physically viable
Grand Unified Theory, full quantum restoration and a Theory of Everything
have not been established.

## Start here

- [Qualified source-support checkpoint: V827](docs/RESEARCH_EXECUTION_HANDOFF_V827.md)
  has a [completed support/operator validation receipt](calculations/canonical_so10_full_source_response_support_g1_v1/validation_receipt.json)
  at commit `05d91071`. Its historical pause notice was superseded by the
  director's explicit November 7 resumption; it is not a new proper-source
  restoration result.
- [Current checkpoint and execution handoff: V828](docs/RESEARCH_EXECUTION_HANDOFF_V828.md) and
  [common-restoration campaign](docs/COMMON_RESTORATION_CAMPAIGN_V1.md) identify
  the present question, qualified inputs and remaining applicability gaps.
  Read the actual receipts for outcomes; the handoff is frozen before execution.
- [AGENTS.md](AGENTS.md) is the authoritative research-execution policy;
  [project_state.json](project_state.json) is the sole machine-readable
  scientific authority. Formal standing remains **34/39**, state version 113.
- [Charter](CHARTER.md), [local execution conventions](docs/LOCAL_RESEARCH_CONVENTIONS_V1.md)
  and [solo-review policy](docs/SOLO_REVIEW_POLICY_V1.md) define scope and
  interpretation. Routine research is delegated; acceptance and foundational
  adoption remain the director's decisions.

The selected LambdaCC consistency comparison is closed positively, the two
specified fixed-companion completion routes are excluded, and the selected
first-probe proper BBC response is zero. Common restoration and E5/A5 remain
open. Research has resumed; flavor remains paused and HB1/C5 remain blocked.

## Selected scoped evidence and current question

| Question | Qualified result and boundary |
| --- | --- |
| Classical scalar feasibility | One exploratory finite point has positive local masses, a positive heavy-relaxed Higgs quartic, a [complete scalar-contact upper bound below 1/2](calculations/canonical_so10_complete_contact_bound/RESULT.md) and [strict quartic positivity in all 328 real directions](calculations/canonical_so10_finite_full_bfb/RESULT.md). It is not an adopted physical benchmark. |
| Quantum control and matching | The [singlet one-loop squared-mass correction](calculations/canonical_so10_singlet_pole_control/RESULT.md) has magnitude about 140% of its tree value. [Gauge matching](calculations/canonical_so10_direct_gauge_matching/RESULT.md) is unsuccessful within the completed approximation. Controlled physical viability is unresolved. |
| Source-dependent consistency | [All 38 declared one-loop local logarithmic-pole classes](calculations/canonical_so10_nonminimal_source_closure/RESULT.md) are qualified, with their explicit boundary currents. This is not the entire Slavnov identity. |
| Broken-antighost scalar sector | The [complete scalar component](calculations/canonical_so10_scalar_antighost_component/RESULT.md) is nonzero at 727,722 coefficient positions. The [actual-action Hessian bridge](calculations/canonical_so10_scalar_bare_insertion_bridge/RESULT.md) explains its bare insertion interpretation in the explicit UV family; its complete classical identity has 99,256 positions. A nonzero bare insertion is not an anomaly verdict. |
| Current restoration question | Does one admissible correlated correction satisfy the measured source, physical and marked equations together? The [campaign dependency guide](docs/COMMON_RESTORATION_CAMPAIGN_V1.md) prioritizes source/parent applicability and completeness before more loops. Renormalized products, measure, QAP and equivalence remain separate obligations; older coefficient inventories are historical. |
| Remaining limits | Full source-free Slavnov consistency, regulated measure/IR, quantum equivalence and E5/A5 remain unqualified. HB1/C5 remain blocked, flavor paused, finite C1_GS uncalculated, historical quartet failure preserved. Custody remains exit 2 with seven unresolved references. |

Result reports must be read with their actual completed validation receipts,
immutable input scope and preserved failures. Coefficient and catalogue counts
are bookkeeping measures, not experimental evidence or percentages of E5.
Agreement between implementations shares action, conventions, software and
AI authorship; it does not independently validate those physical premises.

## Reproduce one complete bounded result

[The portable Hessian pilot](tools/portable_dh_v1/README.md) includes closed
exact inputs, standard-library-only code and relative hashes. Copy that entire
directory elsewhere and run `python -I -S -B run.py --method slot` and then
`python -I -S -B run.py --method left`. It checks every coefficient of the
99,256-position identity, including implicit zeros, after computing it.
The [integration record](calculations/research_integration_portable_dh/RECORD.md)
freezes the claim and limits. This does not reproduce all upstream physical
proofs, the scalar pole, the full effective action or quantum restoration.

For repository recovery run `python -B tools/research_session_preflight.py`.
For delegated sealed evidence checks use `python -B tools/research_check.py e4`.
The sealed E4 ancestry binds an older README. Prepare its exact historical
execution context once, separately from read-only checks:

```text
python -B tools/research_historical_context.py prepare --manifest tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e4_interaction/bindings.json
```

This copies verified evidence without altering manifests or scientific files.
The read-only check reports the historical and live README hashes separately;
missing or corrupted evidence fails. `--strict-worktree` on preflight instead
requires even the old README binding to match live bytes. No fresh scientific
replay or scientific promotion is implied by successful byte authentication.

## Preserved historical README

Everything below is the unchanged README from commit
`ef70f255a667b9a81e37b344dc78967ada4ed896`, SHA-256
`4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792`.
Its dashboards and next actions describe earlier checkpoints. Use the current
navigation above and sole authority for present status. The original remains
recoverable as exact Git bytes; no historical claim or failed result was erased.

---

# ToE-Next

ToE-Next is a research project seeking the most coherent and complete unification obtainable from established physics, serious existing unification frameworks, surviving project results, and new physics only where evidence or mathematical consistency requires it.

## Current project state

This dashboard is explanatory only. [`project_state.json`](project_state.json)
remains the sole machine-readable scientific authority.

Review follows the owner's [solo-project policy](docs/SOLO_REVIEW_POLICY_V1.md):
no personal outreach or reviewer recruitment; published literature, independent
derivations and explicit limitations remain part of the work. This supersedes
historical specialist-participation requirements in the chronology below.

| Item | Current state |
|---|---|
| Active physics decision | Can the finite centered gauge/scalar two-loop threshold `C1_GS` materially alter the frozen canonical Spin(10) direct gauge mismatch? |
| Authoritative Layer-5 progress | `34/39` — `33 PASS`, `1 BLOCKED`, `0 FAIL` |
| First non-PASS gate | `UVP_M08 = BLOCKED`, attempt 1 |
| Current implementation blocker | `M08_C5_H_BASIC_COCHAIN_QUALIFICATION_PENDING` |
| Immediate next decision | Review the [inactive physical-action candidate and dependency correction](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_PHYSICAL_ACTION_RECONCILIATION_RESULT.md); separately scope executable physical-action and source/gauge-fixing reconciliation. Phase C remains stopped and HB1/C5 remain blocked. |
| Locked | M08 attempt 2 unauthorized; Work Package E unexecuted; Layer 6 unauthorized |
| Physics still unresolved | `finite_C1_GS = null`; direct gauge matching unresolved; BFB unresolved |

The current bounded catalog contains **54,148** statistics-allowed local-operator
directions: 54,033 parity-even and 115 parity-odd. Exact packet IBP removes 2,132
directions from the 359,524 tagged covariant packets, leaving 357,392 before final
statistics. All 431 expansion signatures remain immutable provenance. This is
implementation qualification, not a counterterm count, BRST/cohomology result or
evidence of Spin(10) viability. C5 now uses the qualified weight bound `d-gh<=4`:
the actual frozen images preserve this weight, including dimensionful parameters
and VEV factors. The unchanged catalog selects 1,229 operators for `C^-1` and
29,985 for `C^0`, with 8,302 existing dimension≤4 positive-ghost operators. These
are weight-selected catalog candidates; the H-basic domain is not yet certified,
so they are not fully qualified cochain dimensions. The proposed basicness
condition is a subspace, not an additional quotient; it has not been promoted.
The separately qualified dimension-five positive-ghost extension has 387,117
target directions, including 2,045 parity-odd directions. Together with the
8,302 immutable existing positive-ghost operators, the C5-only union target
catalog has 395,419 directions. These are target-language dimensions, not
H-basic cochain, counterterm or anomaly dimensions. BRST closure, differential
matrices, ranks, cohomology and every later locked stage remain unexecuted.
The historical weight-five witness remains
immutable and is excluded by the corrected selector, not truncated after BRST.
See the [C5 positive-ghost target result](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/T5_TARGET_CATALOG_RESULT.md),
[C5 weight grading result](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/C5_WEIGHT_GRADING_RESULT.md),
[historical C5 grading checkpoint](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/C5_COMPLEX_PREFLIGHT_RESULT.md)
and [JCAT8–JCAT12 result](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/JCAT_PACKET_CATALOG_RESULT.md).
The subsequent [HB0 contract recovery](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/HB0_H_BASIC_CONTRACT_RESULT.md)
stops before cochain construction: the frozen H-basic labels and nilpotence
controls do not supply a complete arbitrary-generator contraction/source-lift
definition. All promoted catalogs and the current sequence blocker remain
unchanged. The missing structural equations require an explicit contract before
HB1 can begin. The [measured performance profile](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/HB0_PERFORMANCE_INTERPRETATION.md)
is diagnostic only; the external
[quantum-chaos benchmark](docs/toe_candidate_gates_v1/QUANTUM_DYNAMICAL_STRUCTURE_BENCHMARK.md)
is a future research specification, not M08 evidence.
The subsequent [HBC structural preflight](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/HBC_H_BASIC_STRUCTURAL_CONTRACT_RESULT.md)
finds an exact source-horizontality obstruction to the normalized minimal
graded polynomial Cartan lift: `iota_0 Sigma_M08` contains the nonzero
coefficient `+(i/sqrt(2))*g10*L_c[4]*c_L[4]` in the frozen H frame. Independent
physical-matrix/odd-shift replay agrees. The candidate contract is not promoted;
the unchanged ST authority is preserved on its historical domain. No HB1,
cochain dimensions or differential matrices are reached. The localized blocker
was `M08_C5_H_BASIC_CANDIDATE_CARTAN_LIFT_EXCLUDES_FROZEN_SIGMA`.
The owner-adjudicated [HBP ambient/basic continuation](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/HBP_H_BASIC_DOMAIN_RESULT.md)
removes Sigma horizontality as a requirement without altering Sigma. It finds
a distinct exact obstruction: the basic cochain `F=integral L_c R_H` has
`[iota_0 B_Sigma F]_(g10 L_c[4] u_H[1] u_H[26])=-2i`. The current reverse source
image and corrected composite contribute with the same sign rather than cancel.
Independent action/component replay agrees. No basic-domain contract is promoted
and HB1 remains unauthorized. The localized blocker is now
`M08_C5_H_BASIC_SOURCE_CARTAN_SIGN_OBSTRUCTION`. The historical ST zero and
Sigma-nonhorizontal negative control remain separate immutable evidence.
The subsequent [STC bounded transport preflight](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/STC_SOURCE_TRANSPORT_RESULT.md)
rules out equivalent invertible transport of that rejected basic domain: the
transported defect is exactly U of the original nonzero defect. Independent
source-action/exterior replay also finds
`[B_Sigma^2 L_c[0]]_(g10^2 L_c[4] c_L[0] c_L[4])=+1` in the ambient source
sector. This prevents a nilpotent full-Weil or curvature-only equivariant
contractible extension that leaves all old images unchanged; it is not a C5
matrix/cohomology calculation or a change to the restricted historical ST
certificate. No transport or acyclic source specification is promoted. The
localized blocker is `M08_C5_EQUIVARIANT_SOURCE_FORMALISM_REQUIRES_REDESIGN`,
bounded to those tested classes, not every possible alternative cochain domain.
The source-free Kalkman comparator passes but does not supply the missing
source hypotheses. All action/image/catalog authorities and `34/39` are unchanged.
The [subsequent source-convention review](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SOURCE_CONVENTION_REVIEW_RESULT.md)
derives coherent conventional and non-Abelian partial-gauge controls. A single
left Hamiltonian bracket supplies the negative, not positive, right derivative
for reverse odd-field source images. Its candidate removes both isolated M08
source residuals in independent exact comparisons. This is not a full M08
replacement, ST/basic-domain certificate or external specialist review; all
17 frozen images and historical failures remain unchanged.
The [full source-convention impact preflight](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SOURCE_CONVENTION_IMPACT_RESULT.md)
materializes all 17 diagnostic candidate expressions, then stops on a distinct
nonminimal/source failure: at `g10=0`, `Q^2 K_Lambda,0=-box(u_H,0)` in the
selected free jet sector. Independent formal-variation/component replay agrees.
The integrated ST expression vanishes in that sector, but the noncanonical
antighost operation is not a derivation of the six-pair bracket. The odd-source
sign correction alone therefore does not earn a full M08 repair. No candidate
replacement is promoted; complete master/Cartan/basic-domain qualification is
not reached. External specialist review of this source organization remains
needed before HB1 or further large construction.
The [free nonminimal BV comparator](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/NONMINIMAL_BV_FREE_RESULT.md)
then derives a complete seven-pair free model in which the antighost source
supplies the missing off-shell cancellation. All fourteen images, the master
equation modulo an explicit total derivative, and 210 ordinary-jet squares pass
in separate implementations. Its canonical gauge-fixing shift is invertible
and intertwines the differential. Deleting the added partner is not an
off-shell invariant restriction. This is a bounded comparator, not a replacement
of the frozen M08 sources/images or a full interacting proof; specialist review
and a separately qualified M08 source architecture are still required.
The [interacting nonminimal BV architecture preflight](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/NONMINIMAL_BV_M08_ARCHITECTURE_RESULT.md)
stops earlier than full source construction: the unchanged scalar/ghost rules
with the certified physical scalar action give
`[Q^2 eta_328[0]]_(g10^2 c_L[0] c_L[4] eta_328[3])=+1`.
Independent physical Phi-tensor replay agrees. This blocks an off-shell
nilpotent full-Weil extension preserving those forward rules; it does not
invalidate the free comparator, replace M08 images, or reject Spin(10).
That historical diagnostic is
`M08_NONMINIMAL_BV_ARCHITECTURE_SCALAR_FORWARD_SQUARE_NOT_CLOSED`;
it remains true of the unchanged rules. The formal sequence blocker and
`34/39` remain unchanged.
The subsequent [scalar–ghost reconciliation](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SCALAR_GHOST_RECONCILIATION_RESULT.md)
derives an inactive negative scalar BRST sign from the frozen positive-sign
covariant derivative and connection rule. It passes all 990 parent
generator-pair scalar checks on 328 coordinates, including mixed and heavy
ghosts, while retaining the historical `+1` witness for unchanged rules.
No source/action replacement is adopted. Complete interacting nonminimal
BV, gauge-fixing, source and H-basic qualification plus specialist review
remain prerequisites; formal authority and scientific state are unchanged.
The [interacting BV control](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/INTERACTING_BV_PREFLIGHT_RESULT.md)
now combines that orientation with complete nonminimal pairs in a four-dimensional
SU(2) adjoint-Higgs model. Both exact routes agree on all 96 minimal/gauge-fixed
columns and pass 288 generator/first-jet squares per route, master identities
modulo reconstructed divergences and canonical gauge fixing with the shifted
vacuum retained. This is an ordinary-gauge comparator, not the M08 partial-gauge
source/domain theorem. The [review packet](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/INTERACTING_BV_M08_REVIEW_PACKET.md)
records the remaining source and semantic obligations; no active definition,
catalog, HB1/C5 permission or physical authority changes.
The [small continuum partial-gauge bridge](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/PARTIAL_GAUGE_BV_BRIDGE_RESULT.md)
then stops at an exact contract mismatch: its unfixed U(1) connection has
`delta^2 A2,mu=-g partial_mu R`, while the preregistered global-only formula
expects zero. Direct component replay agrees. This is not a nonzero full-Weil
`Q^2` result or a rejection of the earlier ordinary control. Local residual
curvature/source semantics must be derived before the bridge can be qualified;
no full M08 or C5 computation is reached.
The subsequent [local residual reconciliation](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/LOCAL_RESIDUAL_CARTAN_RESULT.md)
retains that nonzero connection result and derives its complete local source
action. Both exact routes now pass all 215 Cartan-square and 264 full-Weil
generator/first-jet checks per route, both master equations modulo reconstructed
currents, canonical partial gauge fixing and local functional-domain preservation.
All 88 transformation columns and complete actions agree. Source variation is
performed with an independent local parameter before substituting `-gR`; the
different field-dependent Hamiltonian's chain-rule term is retained as a control,
not removed by an EOM or moment quotient. This qualifies the small abelian-H
control only. Non-Abelian residual-H, the M08 background/source dictionary,
catalog descent and specialist review remain prerequisites; no M08 replacement,
HB1/C5 permission, finite threshold or scientific ledger change follows.
The subsequent [non-Abelian semantic review](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/NONABELIAN_M08_SEMANTIC_RESULT.md)
checks all 66 actual residual-H generator pairs and composite curvature covariance,
and independently reconstructs the physical parent bracket. A canonical light
nonminimal block passes its source/Cartan identities. The review distinguishes
BRST-inert-background quantum transformations from affine background Ward
transformations. A bounded free control shows that light gauge fixing must
transport source actions: the transformed antighost source has
`T_psi K_cbar=-box(omega)`, not the raw zero action. This is an architecture
requirement, not a new physical obstruction or a full M08 theorem. Three
prospective partner types (57 components) are specified but not activated;
source-coordinate maps, domain choice, the complete action and catalog descent
remain unqualified. Specialist review is outstanding. Scientific state,
historical evidence, catalogs, `34/39`, finite threshold and HB1/C5 are unchanged.
The subsequent [source/domain transport candidate](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SOURCE_DOMAIN_TRANSPORT_RESULT.md)
tests a closed actual-H block, its canonical evaluation sources, an external
background and one ordinary derivation. Both routes agree on all 160 stored
columns. The joint quantum-basic/background-Ward domain is preserved before
light fixing and under its canonical transport; the quantum source operations
must be transported, while the Ward action stays unchanged in this control.
Wrong plain-dot pairing, unweighted carrier bracket and raw post-fixing quantum
action remain exact negative controls. No physical kinetic/potential action,
heavy coset, full shifted 328-scalar or catalog descent is qualified by this
test. The old source-component decoder is not inferred from module labels.
The [candidate contract](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SOURCE_DOMAIN_TRANSPORT_CONTRACT_V1.md)
and [specialist questions](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SOURCE_DOMAIN_SPECIALIST_REVIEW_PACKET.md)
remain inactive full-M08 proposals. No external endorsement or new scientific
authority follows; the complete interacting construction is still outstanding.
The subsequent [historical-source decoder preflight](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SOURCE_COMPONENT_DECODER_RESULT.md)
recovers all six literal source couplings and qualifies their bounded physical
coordinate triangles. K_q/L_c require an explicit Gram bridge between evaluation
and self-dual macro coordinates; weighted brackets and conjugation are checked,
not inferred from labels. This permits only a separately scoped interacting
reconstruction proposal. No historical operation is repaired or additional
source activated; full M08/domain/catalog descent and specialist review remain
outstanding, with 34/39, finite C1_GS and HB1/C5 unchanged.
The [interacting reconstruction proposal](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/INTERACTING_M08_RECONSTRUCTION_PROPOSAL_V1.md)
specified the architecture, smallest interacting actual-H test, full source
impact, domain/descent gates and specialist review requirements. At that checkpoint
its status was `SPECIFIED_NOT_EXECUTED`: preparing it did not authorize a test,
activate sources, replace M08 or resume HB1/C5. An owner decision about the bounded
preflight was required before execution; a passing preflight would not automatically
authorize full reconstruction or promotion.
The subsequent owner-authorized [Phase A/B interacting actual-H preflight](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/INTERACTING_ACTUAL_H_PREFLIGHT_RESULT.md)
now qualifies an inactive four-dimensional gauge-kinetic control on the actual
closed block [0,1,4,11]. Both derivations agree on all 480 transformation columns,
actions, divergence currents and domain controls; four fresh completed payloads
are byte-identical. Canonical nonminimal sources, separate local quantum and
background actions, simultaneous gauge-fixing transport and joint-domain
preservation pass together. This does not include the scalar, heavy coset or
composite R_H, or prove counterterm completeness. The historical M08 definitions,
catalogs, 34/39 and finite C1_GS remain unchanged. Phase C requires a separate
decision; full replacement, active sources and HB1/C5 are still unauthorized.
The [review packet](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/INTERACTING_ACTUAL_H_SPECIALIST_REVIEW_PACKET.md)
is prepared, not externally reviewed. Strict historical custody remains exit 2.
The subsequently completed [Phase C scalar-action check](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/PHASE_C_SCALAR_ACTION_RESULT.md)
establishes an exact failure in the literal complete A10 physical action and
stops Phase C. The later [physical-action reconciliation](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_PHYSICAL_ACTION_RECONCILIATION_RESULT.md)
derives a separately named inactive classical candidate with unchanged scalar
representations and potential; two exact routes agree and its factorized
physical Ward identities pass. The old failure remains reproduced. Source and
gauge-fixing reconciliation, executable action qualification and downstream
dependency review remain prerequisites before any promotion or Phase C restart.
The four historical prepared review packets have current solo-project V2
versions linked in the review policy; historical bound bytes remain intact.
The chronology below preserves earlier checkpoint dispositions; the dashboard
and current result identify which implementation prerequisite has since closed.

The normalization/orbit checkpoint has `DISTANCE_TO_C1_GS = DIRECT_PREREQUISITE`,
and the accepted A4/A5 checkpoint records `ONE_GATE_REMOVED`, as
project-management metadata only. The subsequent L1-L6 fail-fast checkpoint records
`NO_CHANGE`: it found a frozen A4 representation defect before A5 execution. The
versioned A4 V2 correction and L6R replay pass. A5 V2 then uniquely restores the total-H
covariant derivative and all previously missing field families. J1-J7 then certify that its
complete-product derivative is the action-derived rule and supersede the historical `p_u`-only
facade. J8-J10 freeze the minimal affected graph set. The bounded R1-R12 recomputation then
regenerates exactly 13 primary and 12 replay active contributions, reuses 11 hash-bound
unaffected heavy contributions, and obtains corrected-action primary/replay agreement with
maximum residual `1.7763568394e-15`. The historical D4 pole is superseded; the corrected
common pole is frozen without projection. P1-A10 then promote the exact source-zero action as
the single M08 functional authority: all nine A5 rules agree between generic and component
lowering, auxiliary elimination is exact, and seven current-action integrand checks pass.
This closes one explicit prerequisite and records `ONE_GATE_REMOVED`. These labels are not scientific authority
or a score.

The subsequent pole-blind source-seed pass constructs the auxiliary-retaining off-shell action,
all six authorized source couplings, and exact `Sigma_M08`. Setting the sources to zero and
eliminating `lambda_L` and `Lambda_H` reproduces the promoted action hash exactly. V1-S8 then
implements indexed/constrained variational lowering with one canonical 328-real scalar target,
recovers all six source transformations, evaluates the classical ST identity to exact zero on
the frozen H-basic domain, and derives `17/17` exact `B_Sigma` images plus the off-shell EOM
ideal. `M08_SOURCE_EXTENDED_ST_SEED_V1` is promoted. The pole-blind C5.0 access gate and
C5.1 contract then pass, but C5.2 stops before raw cochain dimensions: C3 completely certifies
only the two heavy ghost-vector trilinear tensor spaces, while the complete bounded H-invariant/Lorentz-jet catalog for scalar, source, auxiliary, quartic-ghost, seagull, and general derivative sectors is not frozen. The first fatal witness is the missing complete H-invariant bilinear basis for the canonical 328-real scalar module. No pole or projection payload was imported, no cohomology rank was guessed, C6 was not entered, and `DISTANCE_TO_C1_GS = NO_CHANGE`.

The pole-blind CAT0-CAT4 prerequisite now closes that first witness. Exact residual-H/PQ
isotypic decomposition and an independent Weyl-character calculation both give dimension `46`
for the real scalar bilinear invariant space, rather than one kinetic direction. The bounded
quantum-number pass freezes 431 field-content signatures across ghost numbers `-1`, `0`, and
`+1`. CAT5 then stops at a sharper definition-level issue: repeated-field Bose/Fermi symmetry
acts diagonally on the group-invariant tensor and Lorentz/derivative-jet factors. Restricting
either factor first would discard valid mixed Young channels, including the ordinary
Yang--Mills `f_abc` cubic witness. The next gate is therefore a joint permutation-resolved
group/Lorentz-jet catalog, not separate CAT5 and CAT9 symmetry reductions. CAT5-CAT12, raw
cochain dimensions, differential matrices, and cohomology remain unexecuted; no pole or
projection payload was read and `DISTANCE_TO_C1_GS = NO_CHANGE`.

The first joint-catalog continuation froze the canonical product of identical-slot
symmetric groups for all 431 signatures; 165 signatures have a nontrivial stabilizer. An exact
parent-`D5`-weight calculation also supplied a historical ordered-slot multiplicity for every
signature without applying Bose/Fermi statistics prematurely. It reproduced the C3 controls
`49` and `19` and reported scalar dimensions `89`, `1,942`, and `198,060`. The subsequent
INT4 component calculation has now superseded the latter two counts for current catalog
authority because the old route retained an unphysical parent affine-sheet grading.
JCAT2 had stopped before claiming an invariant basis.
Characters certify multiplicities but do not provide the exact factorized component
intertwiners needed to build permutation matrices or apply `B_Sigma`. The existing 29 parent
potential directions could not be substituted for a complete ordered quartic space (historically
counted as 198,060 and now corrected to 205,332). JCAT3-JCAT12 and all
Lorentz/IBP/statistics projections remain unexecuted. The
next bounded prerequisite is therefore the residual-H intertwiner channel materializer; the
joint permutation-resolved group/Lorentz-jet catalog is not yet promoted, no pole payload was
read, and `DISTANCE_TO_C1_GS = NO_CHANGE`.

The bounded INT0-INT2 continuation deduplicates the 431 signatures into 221
role-sensitive ordered products and 74 character-equivalent products. Its exact binary
fusion census requires 271 residual-H carrier labels, 975 H×PQ channels, and 11,705
oriented channel copies. Existing parent-module machinery covers only 35 labels; 236
intermediate carriers still lack exact representation actions and canonical bases. INT3-INT15
therefore remain unexecuted, the intertwiner materializer is not promoted, and
`DISTANCE_TO_C1_GS = NO_CHANGE`.

The bounded REG0-REG13 amendment closes that carrier gap. All 271 demanded
residual-H labels have deterministic exact factorized carriers, including all 236 previously
missing labels, with maximum dimension 135. The project-generator dictionary is exact,
all conjugate pairings are nondegenerate, all 35 legacy parent-module carriers have full-rank
zero-residual adapters, and the frozen 12-dimensional residual adjoint and 33-dimensional
heavy module replay exactly. A separate Julia/Nemo path verifies the serialized matrices'
dimensions, commutators, pairings, and selected characters. All 975 H×PQ channels and
11,705 oriented copies resolve to concrete carrier IDs. The pole-blind audit is clean.

INT3 now constructs 80 reusable exact `SU(3)` channel families containing 81 multiplicity
copies and 14 exact `SU(2)` channels; together they resolve all 11,705 oriented residual-`H`
binary channel copies with zero factor-generator residual. INT4 then finds a promotion-critical
upstream mismatch. A concrete factorized channel count and an independent character replay in
true residual-`H` coordinates agree, while frozen JCAT2 differs for 22 of 431 signatures. The
first witness is `S tensor S tensor H`: `633` versus historical `629`. The old five-component
parent-weight calculation failed to quotient the affine direction `(1,1,1,1,1)`, which every
residual-`H` Cartan generator annihilates. The corrected ordered scalar counts are `89`, `1,984`,
and `205,332`; CAT3's statistics-correct bilinear `46` and C3's `49`/`19` controls remain
unchanged. Historical JCAT2 artifacts are preserved, no intertwiner channel basis is promoted,
INT5-INT15 remain unexecuted, and `DISTANCE_TO_C1_GS = NO_CHANGE`.

The bounded P0-P14 correction now promotes `JCAT2_ORDERED_HPQ_MULTIPLICITIES_V2`.
The exact parent-to-residual projection has rank four and kernel generated by
`(1,1,1,1,1)`. Projected parent characters and a separate carrier-registry character
construction agree exactly for the heavy, adjoint, and scalar modules. All 431 V2
multiplicities agree with the exact INT3 fusion-channel count; the 22 historical mismatches
also pass a third route. The corrected ordered scalar dimensions are `89`, `1,984`, and
`205,332`, and the former `629` witness is now `633` on every route. The dependent demand
remains exactly 271 carriers, 975 H×PQ channels, and 11,705 oriented copies, so the existing
registry and INT3 maps require no extension. Historical JCAT2 files remain immutable and are
superseded only for current ordered-multiplicity authority.

The bounded INT4R-INT7 continuation then passes eight direct full-`H` Kronecker
nullspace replays, including the multiplicity-two `SU(3)` and dimension-135 controls.
INT5/INT6 freeze deterministic finite channel addresses for all 431 corrected products;
the ordered scalar-quartic family contains exactly 205,332 addressable channels without a
dense `328^4` tensor. INT7 constructs exact heavy, adjoint, and canonical-real scalar role
adapters of ranks `33`, `12`, and `328`, and its on-demand factorized component evaluator
passes bounded bilinear/cubic/quartic/heavy/light controls. INT7R stops before promotion:
there is no independent lowering from a structured A3 scalar contraction AST into the new
channel coordinates, so the required scalar cubic/quartic comparison would otherwise be a
self-comparison. INT8-INT15 remain unexecuted, no ordered invariant-channel basis is promoted,
no pole payload was read, and `DISTANCE_TO_C1_GS = NO_CHANGE`.

The [independent A3/channel bridge](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SCALAR_AST_CHANNEL_BRIDGE_RESULT.md)
now freezes ordered occurrence slots and an independent constrained-tensor oracle,
then fails fast on a small `muPhi` block. The primal INT3 embedding remains exact,
and its Gram-derived dual is biorthogonal. But the frozen INT7 convention uses a
transposed primal embedding where the A3 scalar contraction requires an invariant
covector. Two nonzero exact A3 witnesses cannot share one coefficient in that
unique channel. BR3 is only diagonal-tested and BR4 only locally complete; no
complete four-control lowering, BR9/BR10 acceptance, INT7R pass or basis promotion
is claimed. Historical checkpoints remain immutable. INT8 and downstream work
remain unexecuted, and formal authority is unchanged.

The [versioned dual qualification](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SCALAR_DUAL_BRIDGE_V2_RESULT.md)
provides the next bounded checkpoint:
all 94 factor-channel dual blocks pass and both triplet witnesses are repaired,
but full muPhi lowering stops at a sextet scalar role-adapter covariance defect.
INT3 is unchanged; neither V2 nor the bridge is promoted. Four complete BR8
artifacts, BR9/BR10 and INT8-INT15 remain unexecuted. Guarded full validation
stops before a forbidden legacy pole read; no full `--all` PASS is claimed.

The historical [scalar-adapter V2 checkpoint](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SCALAR_ADAPTER_V2_RESULT.md)
certifies all 65 scalar copies across 35 labels, rank 328, reconstruction,
projector completeness, all twelve H generators and PQ covariance. The full
sextet muPhi block now closes. SA13 stops because corrected raw phases and
normalization require a coefficient `-2` times the historical one, while
the original physical A3 components are unchanged. No rescaling is performed
to satisfy the incompatible fixed-coefficient condition. INT7R remains
blocked at that checkpoint; neither the adapter nor the complete bridge was promoted there.

The [versioned SA13 transport contract](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SA13_COORDINATE_TRANSPORT_ACCEPTANCE_V2.md)
accepts exact transport of the full historical tensor rather than unchanged numerical coefficients.
The [independent scalar bridge V3](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SCALAR_BRIDGE_V3_RESULT.md)
then qualifies all four controls: muPhi, z6, lambdaPhi1 and zEta. All 42 frozen A3 component
targets reconstruct exactly; independent raw-index component sampling reproduces the muPhi and
zEta coefficients in separate small fusion blocks. INT7R passes and promotes only the scalar
adapter V2, covector decomposition convention V2, and bounded A3-to-channel lowering V1.
At that checkpoint the complete ordered invariant-channel basis was not promoted, and INT8-INT15
and all downstream work remained unexecuted. `DISTANCE_TO_C1_GS = ONE_GATE_REMOVED` is implementation metadata only;
formal authority remains `34/39`. Guarded full validation is not an unrestricted `--all` PASS.

The historical [INT8 single-address qualification](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/INT8_CONJUGATION_RESULT.md)
stopped at terminal 513 of `INV_S_S_S`: physical conjugation mixes its two `Phi`-octet
cubic addresses by the exact matrix `[[2,-1],[3,-2]]`. This matrix is involutive and
reconstructs the entire bounded tensor block exactly, but violates the requested
single-address-plus-phase contract. No INT3, REG7, scalar V2, A3, or INT7R authority
is changed. INT9-INT15 were not executed; the ordered basis remains unpromoted.

The [versioned INT8 block contract](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/INT8_BLOCK_CONJUGATION_V2_RESULT.md)
accepts exact finite multiplicity-block maps without changing the canonical basis.
All 74 ordered-family descriptors, covering 431 current signatures, have exact
factorized conjugation, pairing/duality/H/PQ compatibility and anti-linear involution.
An independent physical-column Gram/sparse-tensor pivot replay reproduces five blocks,
including the unchanged mixed Phi witness and the largest multiplicity-16 block.
The frozen z6/zEta coefficients satisfy exact monomial/HC transport. INT8 V2 passes;
INT7R remains untouched. At that checkpoint INT9-INT15 were unexecuted. Formal authority stays
34/39, the complete ordered basis is unpromoted, and guarded full validation is not
an unrestricted `--all` PASS.

The subsequent [INT9-INT15 continuation](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/INT9_INT15_RESULT.md)
passes the exact `89=46+43` scalar swap/CAT3 regression, `49/19` C3 mutual span,
all 29 parent coefficient families/34 real directions (300 zero-residual A3 controls),
and 78 tree/source/auxiliary structures (312 zero-residual controls). INT13 stops
on the quartic-ghost light action: literal promoted `B_Sigma(R_H)` gives `-411/4`,
while the original H Ward identity and composite-first constituent action both give zero.
No promoted rule or channel coefficient is changed to conceal that mismatch.
At that historical checkpoint INT14-INT15 were locked and the ordered basis remained
unpromoted; formal authority stayed `34/39`.

The subsequent [composite-R adjudication](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/RH_COMPOSITE_RESULT.md)
independently derives `B_Sigma R_H = -g10 [c_L,R_H]_H`, freezes a separate direct
commutator replay, and identifies the stored opposite sign as a derived-composite
image defect. The action, six source couplings, other 16 images and historical
negative witness remain unchanged. INT13 now closes all eight bounded sectors;
INT14 matches all 431 signatures; Julia/Nemo passes 26 unchanged exact obligations;
INT15 promotes the complete ordered internal channel basis. This is not a C5
counterterm basis or a physical unification verdict. The next blocker is the joint
permutation/Lorentz/derivative/IBP catalog, which was not executed. Formal authority
remains `34/39`, with attempt 2 and Layer 6 unauthorized and `finite_C1_GS=null`.

The [JCAT3 contract preflight](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/JCAT3_CONTRACT_RESULT.md)
binds all 431 signatures, stabilizers, derivative budgets, current internal
addresses and conjugation coverage. It stops before JCAT4 because C5.1 does not
explicitly admit or exclude oriented Lorentz epsilon contractions. An exact
conditional four-vector diagnostic and separate component replay have rank
three with metric pairings and rank four with epsilon included. Neither policy
is adopted; this is not a final operator count or a failure of the promoted
internal basis. The existing IBP and deferred-EOM conventions are preserved.
The full joint catalog and C5 remain unconstructed, with formal authority
unchanged at `34/39`.

The [versioned physical Lorentz continuation](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/JCAT_LORENTZ_V2_RESULT.md)
supersedes that admissibility gap by including both metric and oriented epsilon
in physical dimension four, separately from the dimensional regulator. Exact
local recouplings, physical component replay and internal Young decompositions
pass through JCAT6 for all 431 signatures. JCAT7 stops at the inherited affine
background restriction: a covariant kinetic packet spans three signatures whose
separate variations are `2, 2, -4` and cancel only together. The catalog needs an
explicit candidate-superspace versus cross-signature-covariant-packet disposition.
Conditional ordinary jet/IBP algebra is retained as diagnostics only. No joint
catalog promotion, C5 execution or scientific authority change is claimed.

The [background packet continuation](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/JCAT_BACKGROUND_PACKETS_V2_RESULT.md)
selects covariant packets now, retaining all 431 signatures as expansion
addresses. A bounded nine-coordinate triplet completion gives three covariant
packets and an exact four-dimensional variation kernel. Its extra direction
is identically zero when the two background occurrences realize the same
commuting connection. Physical image spans agree exactly, but the prescribed
raw mutual-span/non-overcounting gate cannot count that zero direction or
silently quotient it. JCAT7 stops at this replay-domain distinction; the full
packet catalog, JCAT8–JCAT12 and C5 remain unqualified and unexecuted.

The [faithful-realization continuation](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/JCAT_REALIZATION_V3_RESULT.md)
resolves that bounded obstruction exactly: nine ordered coordinates realize an
eight-dimensional tagged space, and the four-dimensional raw covariance kernel
has three faithful packet directions after its one zero-realization direction
is removed. All 431 signatures remain traceable. Twenty reusable background
classes certify 1,356 exact null directions in the 369,980-coordinate expansion
space, with largest local block 24 and exact structure descent. Homogeneous
occurrences remain tagged until JCAT11. This qualifies realization and bounded
packets, not the complete global covariance replay: JCAT7 is still unearned,
JCAT8–JCAT12 and C5 remain unexecuted, and formal authority stays `34/39`.

The subsequent [global JCAT7 continuation](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/JCAT_GLOBAL_PACKETS_RESULT.md)
closes all 362 completion classes, including 2,524 active carrier/copy blocks,
with exact primary-versus-faithful-Ward-kernel mutual spans. The promoted tagged
background-covariant packet basis has dimension 359,524: 358,444 parity-even
and 1,080 parity-odd directions. Independent four-dimensional component controls
recover curvature, epsilon curvature, the largest faithful block and the
immutable triplet witnesses. These are pre-IBP/pre-statistics dimensions, not
final counterterm counts. All 431 signatures remain expansion provenance.
Only JCAT7 is promoted; the complete joint catalog, JCAT8–JCAT12 and C5 are
still unexecuted. Formal authority remains `34/39`.

The [foundational test matrices](docs/toe_candidate_gates_v1/FOUNDATIONAL_TEST_MATRICES.md)
extend the separate candidate-assessment library to eleven specification-only
gates. They are research filters, not additions to the 39-row scientific ledger.

The project has an initial dependency scaffold and one model-specific recovery chain with two completed bounded steps. Its first calculation passed: the Babu–Khan non-supersymmetric SO(10) heavy-vector boundary maps through the model's Pati–Salam intermediate symmetry into `Q_qque` and `Q_duql` in standard dimension-six BNV SMEFT, while the right-handed-neutrino term remains separately identified as `Q_qqdN`.

A focused primary-literature audit admitted the next calculation, which also passed. The single Pati-Salam BNV coefficient now has a verified one-loop gauge-leading-log evolution factor and is projected only afterward at `M_I` into the full-flavor SMEFT and SMEFT-plus-`N` boundary. A subsequent source audit corrected the interval sextet's identity from high-scale `H_T` to intermediate-scale `Sigma_1` without changing the beta coefficients or recovery map.

The [downstream admission audit](docs/BABU_KHAN_SMEFT_N_THRESHOLD_AUDIT.md) found complete one-loop BNV SMEFT-plus-`N` running machinery, but the Babu-Khan source does not freeze the numerical fermion fit, singlet-neutrino masses, ordering, or flavor rotations required to use it. The physical `Q_qqdN` threshold carry-forward also requires an explicit dimension-seven disposition. The proposed running-and-threshold seam is therefore not admitted, and no calculation below `M_I` has begun.

A [published-fit provenance audit](docs/BABU_KHAN_FERMION_FIT_PROVENANCE_AUDIT.md) located the numerical point Babu-Khan quoted and a later full-RGE fit. Both are informative comparators but cannot be adopted unchanged under the frozen intermediate-spectrum and scalar-vev assumptions. No fermion benchmark has been selected or reconstructed.

A [fermion-source continuation decision](docs/FERMION_SOURCE_ROUTE_DECISION.md) compared a Babu-Khan-specific refit with switching to a published-fit SO(10) source model. Neither route is admitted for execution yet: the former requires a costed coupled-fit protocol, while the most explicit alternate prints matrices but approximates its Pati-Salam flavor interval. The two passed Babu-Khan gauge-sector boundaries remain intact.

A [proactive Babu-Khan fit-feasibility analysis](docs/BABU_KHAN_FIT_FEASIBILITY.md) derives exact two-matrix and scalar candidate-point checks, then identifies the missing model-specific Pati-Salam flavor-running and one-light-doublet matching kernel. It finds no optimization-free model no-go, but does not admit a fit before that theory kernel is derived and validated; no optimizer was run.

The [admitted flavor-kernel attempt](calculations/bk_ps_flavor_kernel/RESULT.md) checked the actual interval's universal one-loop Yukawa gauge terms and then stopped at a source-level scalar-projector inconsistency: the published `D11` relation lacks a factor `1/r` required by its own zero-mode equations. Independent exact Python and Julia/Nemo checks reproduce the discrepancy. The complete Yukawa RGEs and `M_I` projector are **not** established; this is not a Babu-Khan model rejection, and no fit or below-`M_I` evolution began.

A targeted [light-doublet and scalar-sample reconciliation](calculations/bk_light_doublet_projector_reconciliation/RESULT.md) finds that the first printed scalar point cannot have positive heavy doublet modes with Table 2's stated `sigma` exponent; a separate non-doublet mass is also off by about a factor of ten. A one-power exponent change removes these large contradictions, but the unprinted fine-tuned mass and full-precision inputs prevent validating the original zero mode or deciding whether the authors used the misprinted reduced identity. The printed point requires repair; the flavor kernel remains stopped.

A subsequent [parent-tensor normalization and positivity calculation](calculations/bk_scalar_tensor_recovery/RESULT.md) independently confirms several `54_H`, `10_H`, singlet-`126_H`, and singlet-mixing factors and derives an exact one-light/positive-heavy Schur criterion. It also finds that the source's potential and vacuum potential cannot share one literal `126_H` normalization for their identically named quadratic and quartic coefficients. The full `126_H` doublet/triplet Hessian and published `4 x 4` matrix are therefore neither confirmed nor refuted; no new scalar-point search or fermion fit was started.

The focused [scalar source-convention reconstruction](calculations/bk_scalar_source_convention/RESULT.md) finds a decisive same-symbol obstruction even before the full tensor Hessian: the printed vacuum potential's `lambda0` tadpole coefficient differs by a factor of four from the printed stationarity equation, and its accessible singlet Hessian does not agree with one common convention in the `126_H` diagonal. A single equation-independent translation cannot reconcile the formulas as printed. This is a source-formula conclusion, not a rejection of the field-content model.

A separate [canonical source-derived scalar reconstruction](calculations/canonical_so10_scalar_reconstruction/PARENT_ACTION_V1.md) remains **in the exploratory lane**, distinct from the printed Babu--Khan scalar model. Its complete 34-direction renormalizable invariant action, intended gauge stabilizer, exact tadpoles, and [full 35-block scalar Hessian](calculations/canonical_so10_full_hessian/RESULT.md) have passed their bounded gates. The [Stage 1 scalar benchmark](calculations/canonical_so10_scalar_benchmark/RESULT.md) is a locally positive high-scale stationary point with exactly 33 gauge plus one PQ zero modes. Its first light-Higgs tuning failed the [heavy-relaxed quartic test](calculations/canonical_so10_light_higgs_quartic/RESULT.md), but a [new exact tuning](calculations/canonical_so10_positive_higgs/RESULT.md) has one light complex Higgs doublet, positive remaining scalar masses, and a positive heavy-relaxed tree-level quartic. An initial [structured BFB/runaway probe](calculations/canonical_so10_bfb_probe/RESULT.md) found no negative ray, and a subsequent [orbit-space check](calculations/canonical_so10_bfb_orbit/RESULT.md) certified positivity of the pure self-dual `126_H` quartic and the `54_H+10_H` sector. The complete mixed-field quartic remains `BFB_UNRESOLVED`. A [bounded gauge-matching calculation](calculations/canonical_so10_gauge_matching/RESULT.md) generated the canonical SM scalar/vector ledgers and a coarse one-loop crossing. The subsequent [PS threshold-kernel calculation](calculations/canonical_so10_ps_threshold_kernel/RESULT.md) passed exact representation-projector, symmetry-restoration, vector-index, and whole-spectrum logarithmic checks. A [physical-vacuum matrix-threshold continuation](calculations/canonical_so10_matrix_threshold/RESULT.md) now passes basis-invariant SM-side scalar/vector log checks, but demonstrates that an upper-boundary PS generator does not commute with the frozen vector mass operator. The full non-degenerate two-boundary matching, finite vector/Goldstone/ghost terms, and interval ledger remain unearned: `PS_THRESHOLD_KERNEL_BLOCKED` and `GAUGE_MATCHING_BLOCKED`; no GeV scales were fitted. Global stability, loop-level perturbativity, fermion flavor, scalar-mediated baryon-number violation, and phenomenological GUT viability remain unestablished. No published Babu--Khan scalar benchmark or scalar threshold has been inherited.

The [physical lower-boundary background-field continuation](calculations/canonical_so10_lower_bfm/RESULT.md) verifies the nine `PS/SM` broken vector--Goldstone--ghost quadratic mass pairings in a partial `R_zeta` gauge. That checkpoint did not yet compute a one-loop `F²` term.

A [lower one-loop `F²` continuation](calculations/canonical_so10_lower_f2/RESULT.md) has since derived the finite and logarithmic **massive-vector** coefficient in the frozen partial background-field Feynman gauge, and checked the complete-`16_F` zero projected fermion gauge jump. A delayed-scalar-decoupling candidate also passes an exact lower logarithmic beta-jump checksum, but the required PS-covariant EFT field/operator map and UV/EFT hard-region subtraction remain unearned. The lower boundary is still blocked; the upper one-loop calculation and scale fit remain untouched.

The next calculation is specified in the [canonical PS interval EFT task and pass checklist](docs/CANONICAL_PS_INTERVAL_EFT_TASK.md). It first asks whether the frozen benchmark admits a controlled tree-level PS field/operator split; drafting this gate does not change the blocked one-loop matching status.

The [first execution of that EFT gate](calculations/canonical_so10_ps_interval_eft/RESULT.md) found a same-coefficient stationary PS **saddle** and a provisional 328-real-direction quadratic census. A separate tadpole-tracked epsilon deformation shows how the `126_H` triplet mass can count as soft, but does not yet fix the other light multiplets or a covariant heavy/light split with an error bound. The result is `PS_INTERVAL_EFT_BLOCKED`, not a power-counting no-go; lower one-loop matching remains paused.

The [next multi-spurion task and direct-matching fallback](docs/CANONICAL_PS_MULTISPURION_DECISION.md) separate EFT control from symmetry protection/naturalness. They specify how to test the light PS multiplets and when a direct physical-vacuum `Spin(10) -> SM` gauge match would be considered; neither route is promoted by that task specification.

The [multi-spurion execution](calculations/canonical_so10_ps_multispurion/RESULT.md) derives exact same-coefficient PS intercept matrices for the numerically light `10_H`, `54_H`, `126_H`, and singlet sectors, and a once-only 328-real-direction origin ledger. A declared different-theory family through the frozen physical point gives a numerically bounded candidate 132-real-dimensional upper-heavy scalar block, but the remaining scalar masses and gauge-orbit disposition do not yet establish a clean covariant interval EFT at `sigma/omega=0.1`. Its two-axis result is `power_counting=UNRESOLVED`, `smallness_origin=MIXED`, headline `PS_MULTISPURION_COUNTING_UNRESOLVED`. The PS interval, one-loop boundaries and gauge matching stay blocked; the direct broken-phase route remains only a scoped fallback, and `BFB_UNRESOLVED` persists.

The subsequent [observable-specific PS error budget](calculations/canonical_so10_ps_eft_error_budget/RESULT.md) freezes a ten-percent gauge-discrimination target of `0.2027` in nonuniversal inverse-coupling differences. Known complete broken-phase scalar logarithms have spread `0.126`, but candidate upper-block placement sensitivity reaches `0.235`, the current Schur norm cannot close a matrix-log bound through the light scalar gap, and upper-vector/scalar induced-operator coefficients remain unmatched. The result is `PS_EFT_ERROR_UNRESOLVED`, not a proof that the PS EFT is inaccurate. Neither PS loop matching nor the direct physical-vacuum fallback is admitted.

The focused [upper tree-operator continuation](calculations/canonical_so10_ps_operator_match/RESULT.md) exactly integrates the 24 first-stage vectors, obtaining twelve current--current coefficients `-6/5` and twelve `-300/253` in inverse-`omega^2` units. It also closes the once-only upper Goldstone count: the `54_H` orbit has rank 24, while all 24 generators have `126_H(15,2,2)` projections spanning 12 real directions. The frozen 132-real scalar split still does not yield a controlled finite local expansion for the borderline retained modes (`r=0.704`; leading and next inverse-series tail diagnostics `2.38` and `1.67`), and the complete scalar-source/vector-operator one-loop `F^2` insertions remain uncomputed. The preregistered error sum therefore cannot be closed and remains `PS_EFT_ERROR_UNRESOLVED`; no downstream route is admitted.

A subsequent [gauge-route selection](calculations/canonical_so10_gauge_route_selection/RESULT.md) now admits a bounded direct physical-vacuum `Spin(10) -> SM` matching **feasibility** calculation without rejecting the exact PS route. Across the frozen heavy spectrum the largest mass logarithm is `3.396`; coarse loop-log diagnostics are `0.0072` before and at most about `0.094` after total-index weighting. A representation-weighted scalar-plus-vector one-loop comparator has nonuniversal spread `2.597`, comparable with the coarse `2.03`--`2.97` displacement requiring adjudication. These are feasibility diagnostics, not a match: the all-33-vector common-scheme subtraction, direct beta-jump and matching-scale checks, scale solve, and explicit higher-order uncertainty remain outstanding. `BFB_UNRESOLVED` persists, and no flavor or proton-decay work is admitted.

The admitted [direct physical-vacuum gauge calculation](calculations/canonical_so10_direct_gauge_matching/RESULT.md) now passes its one-loop kernel gate. In one `MSbar` background-field Feynman convention it counts all 290 positive scalar directions and all 33 vector--Goldstone--ghost sets once, rederives the vector finite/log coefficient, and reconstructs the common projected `Spin(10)` beta coefficient `-34/3` in all three SM channels with exact matching-scale cancellation. The measured-coupling equations have no exact common one-loop solution; the best perturbative fit has residual `(0.366,-1.060,0.694)`. Known gauge-only SM two-loop running has nonuniversal size `0.706`, and a separate threshold-order diagnostic is `0.245`, comparable with the one-loop miss. The correct point-level disposition is therefore `DIRECT_GAUGE_MATCHING_UNRESOLVED`, not pass or fail; the fitted scale is not promoted, the exact PS route remains deferred, and `BFB_UNRESOLVED` persists.

The [next-order direct continuation](calculations/canonical_so10_direct_gauge_next_order/RESULT.md) upgrades that comparator to complete two-loop SM gauge evolution with perturbatively consistent top, bottom, tau, and Higgs running. The coupled-running implementation and an independent inverse-coupling replay pass. The known next-order refit reduces the residual to `(0.261,-0.745,0.485)` but still has no common root; refitting over `mu/omega=0.5--2` changes the maximum residual only from `0.742` to `0.749`, and broad weak-boundary variations are negligible. A benchmark verdict remains `DIRECT_GAUGE_MATCHING_UNRESOLVED`, because the model-dependent two-loop heavy decoupling constants are neither calculated nor rigorously bounded and their Yukawa-dependent part is underdefined before the canonical Yukawa matrices are frozen. No diagnostic `g10` or `omega` is promoted; `BFB_UNRESOLVED` and all downstream exclusions remain in force.

The bounded [direct two-loop heavy-threshold gate](calculations/canonical_so10_direct_two_loop_heavy_threshold/RESULT.md) now fixes the RG-controlled part of that missing boundary. It independently derives the Yukawa-independent parent coefficients `b10=-34/3` and `B10=10405/6`, materializes the exact two-loop matching logarithms, and freezes an isometric symbolic Yukawa convention. The two-loop vertex-polynomial flavor dependence is the four-real-coordinate Hermitian Gram matrix of `Y10` and `Y126`; exact massive right-handed-neutrino loops still require a numerical flavor point. The available primary finite two-loop GUT formula cannot be imported because its one-VEV, no-trilinear, no-heavy-fermion, and restricted-degeneracy assumptions all fail for this benchmark. The finite nonuniversal two-loop constants therefore remain uncomputed: `DIRECT_TWO_LOOP_HEAVY_THRESHOLD_BLOCKED` and the benchmark stays `DIRECT_GAUGE_MATCHING_UNRESOLVED`. The passed one-loop kernel, passed two-loop SM running, and `BFB_UNRESOLVED` are unchanged.

The follow-on [gauge/scalar finite-threshold implementation gate](calculations/canonical_so10_direct_two_loop_gauge_scalar_threshold/RESULT.md) now supplies an exact on-demand derivative oracle for all parent scalar monomials through fourth order and preregisters the centered `C1_GS` magnitude/alignment test before a result exists. It reproduces the certified Hessian oracle and independent `zEta`, `z6`, VEV-induced `zK`, and singlet-quartic controls. A complete finite threshold is still not calculable from that input alone: the background/quantum gauge-fixed vector--Goldstone--ghost rules, two-loop diagrams and symmetry factors, one-loop counterterms/tadpoles, tensor reduction, and massive-vacuum master evaluator are not implemented. No `C1_GS`, comparison, or gauge refit is reported. The result is `DIRECT_TWO_LOOP_GAUGE_SCALAR_THRESHOLD_BLOCKED`; `DIRECT_GAUGE_MATCHING_UNRESOLVED` and `BFB_UNRESOLVED` remain unchanged.

The dedicated [`TWO_LOOP_QFT_COMPILER_V1`](tools/two_loop_qft_compiler_v1/RESULT.md) infrastructure program has passed promotion layer 3. Starting from the immutable physical-basis hash `af6354e26e27d47d1de9439b1336361b0a288d68f5e35a21f58ce87010c3b57e`, it reconstructs the full 33-vector/Goldstone/ghost quadratic `R_xi` system and supplies one authoritative partially fixed background-field action with a derived sparse physical-vertex facade. The frozen 12-cell [xi-cancellation matrix](tools/two_loop_qft_compiler_v1/one_loop_xi_cancellation_matrix.json) passes clusterwise at `xi=1/2,1,2`, as do all five aggregate checks: the finite matched coefficient is `T_i[1-21 log(M_V/mu)]`, the beta jump is `-7T_i/2`, the neutral cluster vanishes, and an independent replay has zero symbolic residual. The outcome is `BACKGROUND_FIELD_PHYSICAL_VERTEX_LAYER_PASS`.

The subsequent [layer-4 enumeration gate](tools/two_loop_qft_compiler_v1/LAYER4_RESULT.md) passes with two one-loop and nine two-loop 1PI two-point topologies, an independent half-edge replay, standard scalar symmetry-factor controls, 21 future counterterm slots, and a complete layer-3 one-loop inventory regression. Its 168-signature tensor catalog produces 1,896 canonical gauge/scalar base graphs. Ordered differentiation of the equivariant quartic heavy-ghost interaction resolves four base graphs into eight direct/exchange flow terms, giving 1,900 final records with certified statistics signs. A second recursive enumerator reproduces the complete set and every symmetry denominator, and field-colored controls pass for real `phi4`, cubic scalar theory, scalar QED, Yang--Mills/ghost, and Abelian Higgs. The outcome is `TWO_LOOP_DIAGRAM_GENERATOR_PASS`; it authorized the subsequent layer-5 execution without producing a finite `C1_GS`, gauge refit, or changed physics verdict.

The first [layer-5 counterterm execution](tools/two_loop_qft_compiler_v1/LAYER5_RESULT.md) derives the bare-action counterterm structure for all 29 parent scalar monomial families, assigns non-null structural dispatch expressions to all 21 preregistered insertion slots, freezes one FJ-like tadpole/VEV prescription, and passes an independent bare-action expansion replay. The earned `b10=-34/3` result fixes the parent gauge/background-field counterterms and the background Ward identity exactly. Promotion remains `ONE_LOOP_COUNTERTERM_COMPILER_BLOCKED`, however, because the scalar, quantum-vector, ghost, gauge-parameter, VEV, and tadpole one-loop UV-pole residues have not yet been calculated. Layer 6 is not authorized; no two-loop amplitude or finite `C1_GS` is inferred.

The [layer-5A UV-pole evaluator contract](tools/two_loop_qft_compiler_v1/LAYER5A_UV_POLE_EVALUATOR_TASK.md) was frozen as version 2 before execution. Its machine-readable matrix contains 13 primitive UV-algebra tests, 13 small/control-theory tests, and 13 canonical-model tests. Version 2 adds an explicit rank-eight tensor primitive and requires the independent replay to reconstruct the relevant one-loop diagram inventories independently or use an inventory-independent functional/effective-action completeness proof; the detailed replay design is [frozen separately](tools/two_loop_qft_compiler_v1/INDEPENDENT_UV_REPLAY_DESIGN.md). It fixes a 27-test evaluator-engine gate followed by a 12-test canonical-counterterm gate. The contract requires explicit UV/IR labels, auxiliary-mass cancellation, radiative projection onto all 34 real parent-action directions, and independent recovery rather than import of `b10=-34/3`. Its SHA-256 is `6e256b9f8b2ed0e7243acc96d96daa854410673f59334b126446666d488ffe92`, transparently superseding v1 hash `f4cf741afed95657b8c8c80ff178147189f35c7db42a8fdcea95e8ed3ae3f588`.

The [first-execution ledger](tools/two_loop_qft_compiler_v1/LAYER5A_EXECUTION_ORDER.md) freezes the exact fail-fast sequence `P01--P13`, `C01--C13`, `M01` and a schema-valid transition from the initial `0/39` state to the possible `27/27` engine checkpoint. The plan hash is `54d792571e20239e7b586360fe04557154fc64a5942865896c35d34b89584101`; the result-schema hash is `5999c0a7ff7d2458b0c204a7f8313c0d39a6473aaeff7282ac1f1f1034f699b8`. At freeze time this carried execution-infrastructure authority only, with `UVP_P01` ready and M02--M13 locked.

The first authorized primitive has now [executed](tools/two_loop_qft_compiler_v1/UVP_P01_RESULT.md). `UVP_P01` passes: in the frozen propagator and dimensional-regularization convention, the massive rank-zero tadpole has pole `-m2/(16*pi^2*epsilon_bar)`. A primary large-loop-momentum/auxiliary-mass projection and an independent Wick-rotated Gamma-function calculation agree exactly; the auxiliary mass cancels and the positive-mass integral has no IR pole. Layer-5A progress is `1/27` (`1/39` overall), `UVP_P02` is next, and neither the counterterm compiler nor Layer 6 is promoted.

The [second authorized primitive](tools/two_loop_qft_compiler_v1/UVP_P02_RESULT.md) also passes. The massive rank-zero logarithmic bubble has pole `1/(16*pi^2*epsilon_bar)`, normalized residue `+1`, and exactly zero mass derivative. The primary radial UV projector and independent Gamma-function replay agree with zero residual, so finite mass dependence has not leaked into the logarithmic pole. Layer-5A progress is now `2/27` (`2/39` overall), `UVP_P03` alone is ready, and all counterterm, Layer-6, gauge-matching, BFB, and finite-`C1_GS` dispositions remain unchanged.

The [third primitive](tools/two_loop_qft_compiler_v1/UVP_P03_RESULT.md) passes the first three-way engine consistency check. The directly projected doubled propagator, an independent general-`alpha` Gamma-function calculation, and `-d/d(m2)` of the verified frozen P01 pole all give normalized residue `+1`; every pairwise difference and the explicit Minkowski integrand-sign residual is zero. Progress is `3/27` (`3/39` overall), only `UVP_P04` is ready, and no downstream authority has changed.

The [fourth primitive](tools/two_loop_qft_compiler_v1/UVP_P04_RESULT.md) passes the first Lorentz-tensor gate. For the rank-two Euclidean vacuum integral, exact `delta_mu_nu/d` reduction gives pole coefficient `-m2/2`, and an independent Schwinger/Gaussian-source replay agrees with zero contraction residual. The explicit adversarial branch confirms that replacing `d` by four before resolving pole-times-epsilon terms would miss a finite `-m2/4` contribution in normalized units. Progress is `4/27` (`4/39` overall); only `UVP_P05` is ready and all downstream scientific dispositions remain unchanged.

The [fifth primitive](tools/two_loop_qft_compiler_v1/UVP_P05_RESULT.md) passes the rank-four/rank-six tensor gate. Independent recursive and permutation-orbit generators reproduce exactly 3 and 15 metric pairings, normalized per-pairing residues `1/24` and `1/192`, and all `24+720` permutation symmetries. Every recursive contraction from rank six through rank four and rank two to the scalar moment has zero residual. Progress is `5/27` (`5/39` overall); only `UVP_P06` is ready and downstream authority remains unchanged.

The serial Layer-5 continuation passes the `27/27` evaluator engine and M02-M07, including the complete rank-34 parent-scalar radiative-closure result. M08 remains `BLOCKED` on attempt 1. Its historical D4 adjudication established primary/replay agreement for the old facade, while the [C3/C4 checkpoint](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/C3_C4_RESULT.md) exactly completes the raw H-invariant trilinear problem: invariant-tensor dimensions `49` and `19`, historical `B*f` ranks `5` and `4`, and combined one-derivative IBP quotient rank `136`, all independently replayed with Julia/Nemo. C4 exactly verifies the minimal equivariant algebra (`23,760` Jacobi checks, zero residual), while [C5](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/C5_RESULT.md) freezes the bounded 17-symbol field/source alphabet. The [ST-seed preflight](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/ST_SEED_RESULT.md) earns exact componentwise split-field transformations and a unique composite `R_H` convention. The [action-AST amendment](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/ACTION_AST_RESULT.md) supplies exact constrained ranks `54+252+20+2=328`, all 29 parent-potential contraction ASTs, the normalization `A_cf=g10*A_action`, an exact rank-33 VEV orbit, `M_V^2=g10^2 O^T O`, and exact vector–Goldstone cancellation. The bounded odd-derivation implementation passes L1-L5. A versioned A4 V2 corrects the malformed light covariant contraction and L6R reproduces the complete light action. The heavy reconstruction uniquely selects `D_H(Abar_H+q_L)V_H`; independent component and generic lowerings agree, all previously missing ghost/vector field families occur, and exact auxiliary elimination generates `q_L V_H V_H` with coefficient `-g10/xi`. J1-J7 certify the resulting complete-product rule `g10 f(p_u+p_V)` and supersede the manually entered historical `p_u`-only rule. R1-R12 then recompute only the preregistered affected subset: all corrected poles are local, corrected primary and replay totals agree to `1.7763568394e-15`, and the historical D4 pole is superseded by a frozen corrected-action common pole. No operator-space projection was performed. A5 and A6-A10 now pass, promoting the exact source-zero action hash `36abb0301627acf272a2904da3968781368b1d1d10a7115f7408e1767e20aa2b`. The [pole-blind source-seed continuation](tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/SOURCE_ST_RESULT.md) constructs exact `Sigma_M08`, reproduces that hash after source removal and auxiliary elimination, and now promotes S8: indexed/constrained variations share one canonical 328-real scalar target, the classical ST residual is exactly zero on the H-basic domain, all `17/17` `B_Sigma` images are machine-actionable, and the off-shell EOM convention is frozen. Pole-blind C5/C6, D6, and E remain unexecuted. The authoritative ledger remains `34/39` (33 pass, one blocked, zero fail); M08 attempt 2 and Layer 6 are unauthorized, while `DIRECT_GAUGE_MATCHING_UNRESOLVED`, `BFB_UNRESOLVED`, and `finite_C1_GS=null` remain in force.

A bounded [audit of the explicit 2024 normal-ordering point](calculations/bdfss_2024_point_audit/RESULT.md) independently reconstructs its printed mass matrices and heavy-neutrino spectrum. An [independent parent-`SO(10)` sign derivation](calculations/real_120_sign_audit/RESULT.md) confirms that its unchanged real-`120_H` point violates the required opposite bidoublet conjugation signs. Its Pati-Salam flavor-running approximation and co-frozen threshold ordering remain uncontrolled. This specific point is not admitted as a replacement source; no refit or downstream BNV running began.

The particle-unification route is paused at its model-specific flavor boundary, preserving both passed gauge-sector recovery steps. A separate [gravity source-framework comparison](docs/GRAVITY_SOURCE_FRAMEWORK_COMPARISON.md) retains low-energy GR EFT as the baseline/control but admits no gravity source or active seam; no gravity calculation has begun.

A bounded [joint Standard-Model-plus-gravity EFT reference audit](docs/JOINT_SM_GR_EFT_REFERENCE_AUDIT.md) now records a finite-order common low-energy control surface, its coefficient and assumption ledgers, and the limits of its observable authority. It admits no active cross-domain seam or new calculation.

A [massless-spin-2 assumption-compression audit](docs/MASSLESS_SPIN2_ASSUMPTION_COMPRESSION_AUDIT.md) compares soft-graviton, self-coupling, and geometric-uniqueness derivations against that ledger. It identifies conditional leading-order relations but no demonstrated net ToE assumption compression or new active seam.

A [quasiclassical recovery reference audit](docs/QUASICLASSICAL_RECOVERY_REFERENCE_AUDIT.md) separates decoherence, stable variables, effective classical dynamics, probability calculus, shared records, definite outcomes, and Born weights. Established mechanisms recover several of these conditionally, but no interpretation or active seam is selected.

A [quantum action and propagator recovery benchmark](docs/QUANTUM_ACTION_PROPAGATOR_RECOVERY_BENCHMARK.md) records coherent composition, action-controlled phase, operator/QFT equivalence, stationary-action, and quasiclassical obligations. The 2026 discrete single-photon propagator experiment strengthens this reference target but supplies no new physics, quantum-gravity evidence, ontology selection, or active seam.

The historical [project-wide seam-selection refresh](docs/PROJECT_WIDE_SEAM_REFRESH.md)
admitted no additional calculation from its broad relation-class comparison.
That search disposition does not cancel the separately admitted, currently
active `C1_GS` particle-physics lane described above and in
[Open Seams](docs/OPEN_SEAMS.md). The earlier bounded results and deferred
flavor/reference boundaries retain their authority.

## Scientific posture

- Novelty is not a requirement.
- Provenance and attribution are requirements.
- Established physics is reused under its established identity rather than renamed or rebuilt.
- Hypotheses may be proposed freely, but authority must be earned through claim-scaled evidence.
- AI assists the research process but is never standalone scientific authority.
- Repository size is not a proxy for scientific completeness.

The sole machine-readable project-state authority is [`project_state.json`](project_state.json). Human-readable documents explain that state without creating competing status surfaces.

## Reading order

1. [`README.md`](README.md)
2. [`CHARTER.md`](CHARTER.md)
3. [`project_state.json`](project_state.json)
4. [`docs/SCIENTIFIC_BASELINE.md`](docs/SCIENTIFIC_BASELINE.md)
5. [`docs/ECOSYSTEM_SURVEY.md`](docs/ECOSYSTEM_SURVEY.md)
6. [`docs/DEPENDENCY_SCAFFOLD.md`](docs/DEPENDENCY_SCAFFOLD.md)
7. [`docs/SEAM_SELECTION.md`](docs/SEAM_SELECTION.md)
8. [`docs/SOURCE_THEORY_COMPARISON.md`](docs/SOURCE_THEORY_COMPARISON.md)
9. [`docs/BABU_KHAN_SO10_BNV_MATCHING.md`](docs/BABU_KHAN_SO10_BNV_MATCHING.md)
10. [`calculations/bk_so10_bnv_matching/RESULT.md`](calculations/bk_so10_bnv_matching/RESULT.md)
11. [`docs/BABU_KHAN_PS_RUNNING_AND_MI_MATCHING.md`](docs/BABU_KHAN_PS_RUNNING_AND_MI_MATCHING.md)
12. [`calculations/bk_ps_bnv_running_mi_matching/RESULT.md`](calculations/bk_ps_bnv_running_mi_matching/RESULT.md)
13. [`docs/BABU_KHAN_HT_THRESHOLD_AUDIT.md`](docs/BABU_KHAN_HT_THRESHOLD_AUDIT.md)
14. [`calculations/bk_ht_threshold_audit/RESULT.md`](calculations/bk_ht_threshold_audit/RESULT.md)
15. [`docs/BABU_KHAN_SMEFT_N_THRESHOLD_AUDIT.md`](docs/BABU_KHAN_SMEFT_N_THRESHOLD_AUDIT.md)
16. [`docs/BABU_KHAN_FERMION_FIT_PROVENANCE_AUDIT.md`](docs/BABU_KHAN_FERMION_FIT_PROVENANCE_AUDIT.md)
17. [`docs/FERMION_SOURCE_ROUTE_DECISION.md`](docs/FERMION_SOURCE_ROUTE_DECISION.md)
18. [`docs/BABU_KHAN_FIT_FEASIBILITY.md`](docs/BABU_KHAN_FIT_FEASIBILITY.md)
19. [`calculations/bdfss_2024_point_audit/RESULT.md`](calculations/bdfss_2024_point_audit/RESULT.md)
20. [`docs/GRAVITY_SOURCE_FRAMEWORK_COMPARISON.md`](docs/GRAVITY_SOURCE_FRAMEWORK_COMPARISON.md)
21. [`docs/JOINT_SM_GR_EFT_REFERENCE_AUDIT.md`](docs/JOINT_SM_GR_EFT_REFERENCE_AUDIT.md)
22. [`docs/MASSLESS_SPIN2_ASSUMPTION_COMPRESSION_AUDIT.md`](docs/MASSLESS_SPIN2_ASSUMPTION_COMPRESSION_AUDIT.md)
23. [`docs/QUASICLASSICAL_RECOVERY_REFERENCE_AUDIT.md`](docs/QUASICLASSICAL_RECOVERY_REFERENCE_AUDIT.md)
24. [`docs/QUANTUM_ACTION_PROPAGATOR_RECOVERY_BENCHMARK.md`](docs/QUANTUM_ACTION_PROPAGATOR_RECOVERY_BENCHMARK.md)
24. [`docs/PROJECT_WIDE_SEAM_REFRESH.md`](docs/PROJECT_WIDE_SEAM_REFRESH.md)
25. [`docs/OPEN_SEAMS.md`](docs/OPEN_SEAMS.md)
26. [`docs/PROVENANCE_AND_AUTHORITY.md`](docs/PROVENANCE_AND_AUTHORITY.md)
27. [`docs/LEGACY_HANDOFF.md`](docs/LEGACY_HANDOFF.md)

Repository structure is created only when concrete scientific work requires it. The first earned implementation surface is deliberately narrow:

- [`tools/vpc/`](tools/vpc/) contains a promoted exact-DAG secondary verifier with a frozen applicability boundary and minimal tests;
- [`tools/julia/`](tools/julia/) contains a small locked environment for Nemo and OrdinaryDiffEq plus one readiness smoke test;
- [`tools/readiness/check-c-only.ps1`](tools/readiness/check-c-only.ps1) checks that the active project and its computational stack operate from C: without the legacy custody drive.
- [`calculations/bk_so10_bnv_matching/`](calculations/bk_so10_bnv_matching/) contains the first calculation's compact derivation, coefficient map, and independent exact replays.
- [`calculations/bk_ps_bnv_running_mi_matching/`](calculations/bk_ps_bnv_running_mi_matching/) contains the exact Pati-Salam beta ledger, gauge-running derivation, `M_I` projector, and independent replay.
- [`calculations/bk_ht_threshold_audit/`](calculations/bk_ht_threshold_audit/) contains the exact sextet-attribution correction and symbolic branch comparison.

No model hierarchy, broad calculation framework, dataset, historical scientific tree, environment payload, or bulk generated result is stored here. The machine-level runtimes and package caches remain external to Git.
