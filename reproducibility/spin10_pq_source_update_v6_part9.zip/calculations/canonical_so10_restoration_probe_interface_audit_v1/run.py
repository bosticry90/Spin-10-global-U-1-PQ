from pathlib import Path
from types import ModuleType
from hashlib import sha256
import ast,importlib.util,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/restoration-probe-interface-audit-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='05d91071d4166f42531e51a399dd10b41cfdd96a'
assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);assert(C/'README_before.md').read_bytes()==subprocess.check_output(['git','show','HEAD:README.md'],cwd=R);history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);assert(R/'README.md').read_bytes().endswith(history);assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R).decode().splitlines()==['README.md']
names=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V827.md']
for folder,files in[('canonical_so10_full_jet_source_master_bridge',['PROOF.md','final_review_validation_receipt.json','primary_tables.json.gz','replay_tables.json.gz']),('canonical_so10_proper_slavnov_actual_operators_g1_v1',['validation_receipt.json','native_inputs.json.gz','replay_inputs.json.gz']),('canonical_so10_proper_slavnov_source_chain_g1_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_BBC_master_applicability_g1_v1',['validation_receipt.json']),('canonical_so10_chiral_probe_support',['validation_receipt.json','DERIVATION.md']),('canonical_so10_unmarked_g0_common_kinetic_recovery_v1',['validation_receipt.json','PROOF.md']),('canonical_so10_full_source_response_support_g1_v1',['validation_receipt.json'])]:names+=['calculations/'+folder+'/'+n for n in files]
base='tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/'
for folder,action in[('frozen_a10_bv_integration','M08_CANONICAL_BV_STAGE_D_INACTIVE_V2.json'),('frozen_a10_e2_transport','M08_CANONICAL_BV_GAUGE_FIXED_E2_INACTIVE_V1.json')]:names+=[base+folder+'/'+n for n in['validation_receipt.json','bindings.json','primary.json','replay.json',action]]
names+=[base+'frozen_a10_bv_master/bindings.json',base+'A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md']
sp=importlib.util.spec_from_file_location('probe_interface_preparer',O/'interface.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);todo=[m];seen=set()
while todo:
 mod=todo.pop()
 if id(mod)in seen:continue
 seen.add(id(mod));p=getattr(mod,'__file__',None)
 if not p:continue
 p=Path(p).resolve()
 if not p.is_relative_to(R):continue
 if not p.is_relative_to(O):names.append(p.relative_to(R).as_posix())
 todo.extend(v for v in vars(mod).values()if isinstance(v,ModuleType))
for n in sorted(set(names)):assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in['RECORD.md','interface.py','run.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as h:h.write((O/n).read_bytes())
bindings={**{n:digest(R/n)for n in sorted(set(names))},**{n:digest(R/n)for n in['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md']},**{p.relative_to(R).as_posix():digest(p)for p in O.iterdir()if p.is_file()}};dump(O/'preparation.json',dict(base_HEAD=head,sha256=bindings,README_before_sha256=digest(C/'README_before.md'),historical_README_sha256=sha256(history).hexdigest(),scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'interface.py')]);dump(O/'interface_capture.json',cap);dump(C/'interface_capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
