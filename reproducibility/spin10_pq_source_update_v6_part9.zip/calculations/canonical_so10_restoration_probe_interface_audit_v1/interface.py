from pathlib import Path
from collections import Counter
from fractions import Fraction as Fr
from hashlib import sha256
import gc,gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('restoration_interface_source_algebra',O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/factory.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);J=m.J;A=m.w.A
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()));digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert len(blob)<=10*1024**2,'ARTIFACT_LIMIT_NO_TRUNCATION'
 with(O/name).open('xb')as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=64*1024**2,'PACKET_LIMIT_NO_TRUNCATION'
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def grade(P,g):return J.clean({w:J.Coeff([(k,v)for k,v in c.terms if k[0]==g])for w,c in P.items()})
def scale(P,v):return J.clean({w:J.times(c,J.constant(v))for w,c in P.items()})
def difference(P,Q):
 out=dict(P);J.add(out,Q,-1);return J.clean(out)
def phash(P):return sha256((json.dumps(J.encode(P),sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest()
def main():
 tick=time.perf_counter();watch=threading.Timer(240,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
 b=O.parent/'canonical_so10_full_jet_source_master_bridge';fjb=load(b/'primary_tables.json.gz');assert fjb==load(b/'replay_tables.json.gz');p=O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1';packet=load(p/'native_inputs.json.gz');assert packet==load(p/'replay_inputs.json.gz');assert packet['contains_only_classical_operands']
 states={k:dict(rows)for k,rows in packet['states'].items()};assert all(sorted(v)==list(range(643))for v in states.values());assert len(fjb['field_order'])==643 and fjb['field_order'][:180]==['B'+str(c)+'_'+str(mu)for c in range(45)for mu in range(4)]
 operations={n:J.decode(P)for n,P in fjb['operation']};decisions=[];mismatches=[];controls=[];high=[];source_support=[]
 for n,P in sorted(operations.items()):
  assert all(k[0]>=0 for c in P.values()for k,v in c.terms);hp=J.clean({w:J.Coeff([(k,v)for k,v in c.terms if k[0]>1])for w,c in P.items()});high.append(dict(operation_port=n,full_words=len(P),higher_g_words=len(hp),higher_g_math_sha256=phash(hp),full_operand_retained_at_bound_owner=True))
 def compare(label,n,expected,actual):
  d=difference(expected,actual);row=dict(test=label,port=n,expected_words=len(expected),actual_words=len(actual),expected_math_sha256=phash(expected),actual_math_sha256=phash(actual),equal=not d);decisions.append(row)
  if d:mismatches.append(dict(test=label,port=n,complete_expected=J.encode(expected),complete_actual=J.encode(actual),complete_difference=J.encode(d)))
 for g in[0,1]:
  label='F'+str(g)
  for n in range(643):compare('FJB_operation_'+label,n,grade(operations.get(n,{}),g),J.decode(states[label][n]))
  for n in range(508,553):compare('FJB_JLambda_g'+str(g),643+n,grade(operations.get(643+n,{}),g),J.decode(states['E'+str(g)][n]))
  for n in range(598,643):compare('FJB_Ja_g'+str(g),643+n,grade(operations.get(643+n,{}),g),scale(J.decode(states['E'+str(g)][n]),-1))
 print('STAGE all643_fields_and90_used_source_columns_compared_at_both_grades',flush=True)
 for pr,probe in enumerate(fjb['probes']):
  for name in['G','qG']:
   P=J.decode(probe[name]);assert all(k[0]>=0 for c in P.values()for k,v in c.terms);ports=sorted({n for w in P for n,js in w if n>=643});violations=[n for n in ports if not(1151<=n<1196 or 1241<=n<1286)];source_support.append(dict(probe=pr,operand=name,all_source_ports=ports,forbidden_source_ports=violations,only_Ja_JLambda=not violations));hp=J.clean({w:J.Coeff([(k,v)for k,v in c.terms if k[0]>1])for w,c in P.items()});high.append(dict(probe=pr,operand=name,full_words=len(P),higher_g_words=len(hp),higher_g_math_sha256=phash(hp),full_operand_retained_at_bound_owner=True))
  P=J.decode(probe['qG']);selected=J.clean({w:J.Coeff([(k,v)for k,v in c.terms if k[0]<=1])for w,c in P.items()});assert all(k[0]>=0 for c in P.values()for k,v in c.terms);eulers=J.euler(selected,set(range(1286)))
  sourcefree={w:c for w,c in selected.items()if all(n<643 for n,js in w)};early=J.euler(sourcefree,set(range(643,1286)))
  assert not early,'SOURCE_FREE_INPUT_HAS_NONZERO_SOURCE_EULER'
  for g in[0,1]:
   changed_early=[];changed_sign=[];allcolumns=[]
   for n in range(643):
    E=grade(eulers.get(n,{}),g);rawF=grade(eulers.get(643+n,{}),g);F=scale(rawF,(-1)**J.parity(n));actualE=J.decode(states['Eu'+str(g)+'_'+str(pr)][n]);actualF=J.decode(states['Fu'+str(g)+'_'+str(pr)][n]);compare('probe'+str(pr)+'_E_g'+str(g),n,E,actualE);compare('probe'+str(pr)+'_F_g'+str(g),n,F,actualF)
    ed=difference({},F);sd=difference(rawF,F);allcolumns.append(dict(field=n,early_source_zero_changed=bool(ed),omitted_pairing_sign_changed=bool(sd)))
    if ed:changed_early.append([n,J.encode(ed)])
    if sd:changed_sign.append([n,J.encode(sd)])
   controls.append(dict(probe=pr,g=g,all643_columns=allcolumns,complete_early_source_zero_differences=changed_early,complete_omitted_pairing_sign_differences=changed_sign,early_source_zero_sensitive=bool(changed_early),pairing_sign_sensitive=bool(changed_sign)))
  print('STAGE full_probe'+str(pr)+'_Euler_interfaces_compared',flush=True);del eulers,P,selected,sourcefree;gc.collect()
 assert len(decisions)==6610 and len(controls)==4 and len(source_support)==4
 owners=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1';stage=read(owners/'frozen_a10_bv_integration/validation_receipt.json');transport=read(owners/'frozen_a10_e2_transport/validation_receipt.json');old=read(owners/'frozen_a10_bv_master/bindings.json');assert stage['classical_master_functional_qualified']and transport['E2_transport_qualified']and not old['full_master_action_qualified'];assert all(read(owners/('frozen_a10_e2_transport/'+route+'.json'))['full_master_functional_established']for route in['primary','replay'])
 matched=not mismatches and all(z['only_Ja_JLambda']for z in source_support);art=save('recovered_probe_interface_tables.json.gz',dict(schema='RECOVERED_FULL_SOURCE_PROBE_INTERFACE_TABLES_V1',all6610_comparison_decisions=decisions,complete_nonzero_interface_differences=mismatches,complete_G_QG_source_support=source_support,higher_g_operands_not_silently_discarded=high,all_four_source_controls=controls,correct_base_master_owner='QUALIFIED_INACTIVE_STAGE_D_PLUS_E2',failed_source_only_predecessor_NOT_PROMOTED=True,recovered_full_parent_E2_conjugacy_NOT_ESTABLISHED=True,new_sourceful_proper_quantum_zero_NOT_CLAIMED=True))
 out=dict(schema='RESTORATION_RECOVERED_PROBE_INTERFACE_RESULT_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='MATCH_ALL_DECLARED_PROBE_INTERFACES_PARENT_CONJUGACY_STILL_REQUIRED'if matched else'INTERFACE_MISMATCH_NOTPASS_NO_PROPER_EXTENSION',all6610_declared_interface_comparisons_equal=not mismatches,nonzero_interface_rows=len(mismatches),G_QG_source_support_only_Ja_JLambda=all(z['only_Ja_JLambda']for z in source_support),all_four_early_source_and_pairing_controls_sensitive=all(c['early_source_zero_sensitive']and c['pairing_sign_sensitive']for c in controls),control_changed_counts=[dict(probe=c['probe'],g=c['g'],early=len(c['complete_early_source_zero_differences']),pairing=len(c['complete_omitted_pairing_sign_differences']))for c in controls],qualified_inactive_StageD_E2_master_owners_authenticated=True,failed_predecessor_preserved_NOTPASS=True,current_full_action_parent_E2_conjugacy_NOT_PROVED=True,no_new_proper_zero_or_complete_correction_module_or_HB1_C5_activation=True,no_common_restoration_E5A5_viability_claim=True,artifact=art,elapsed_after_imports=time.perf_counter()-tick);dump(O/'interface_result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel();gc.collect()
if __name__=='__main__':main()
