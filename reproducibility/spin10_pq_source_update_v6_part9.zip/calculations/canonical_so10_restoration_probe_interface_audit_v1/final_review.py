from pathlib import Path
from hashlib import sha256
import gc,gzip,importlib.util,json,os,re,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/restoration-probe-interface-audit-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def load(p):return json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(420,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in['preparation.json','final_preparation.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 cap=read(O/'interface_capture.json');res=read(O/'interface_result.json');assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and res['elapsed_after_imports']<240;assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and cap['all_resource_samples']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples'])
 sp=importlib.util.spec_from_file_location('fresh_restoration_probe_interface',O/'interface.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);artifacts=[];fresh=[]
 def compare_save(name,z):
  blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0);assert blob==(O/name).read_bytes(),name;artifacts.append(name);return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
 def compare_dump(path,z):
  assert path==O/'interface_result.json';assert{k:v for k,v in res.items()if k!='elapsed_after_imports'}=={k:v for k,v in z.items()if k!='elapsed_after_imports'};assert z['elapsed_after_imports']<240;fresh.append(dict(seconds=z['elapsed_after_imports'],all_nonruntime_fields_equal=True))
 m.save=compare_save;m.dump=compare_dump;m.main();del m;gc.collect();assert len(fresh)==len(artifacts)==1
 tables=load(O/res['artifact']['file']);assert len(tables['all6610_comparison_decisions'])==6610 and all(z['equal']for z in tables['all6610_comparison_decisions'])and not tables['complete_nonzero_interface_differences'];assert res['all6610_declared_interface_comparisons_equal']and res['current_full_action_parent_E2_conjugacy_NOT_PROVED'];assert[(z['probe'],z['g'],z['early'],z['pairing'])for z in res['control_changed_counts']]==[(0,0,12,12),(0,1,0,0),(1,0,33,33),(1,1,33,33)]and not res['all_four_early_source_and_pairing_controls_sensitive']
 ownerchecks=[];base=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
 for folder in['frozen_a10_bv_integration','frozen_a10_e2_transport']:
  bindings=read(base/folder/'bindings.json')['byte_sha256']
  for n,h in bindings.items():assert digest(R/n)==h,('CORRECT_MASTER_OWNER_BYTES',n)
  ownerchecks.append(dict(owner=folder,direct_byte_bindings=len(bindings),all_equal=True))
 assert not read(base/'frozen_a10_bv_master/bindings.json')['full_master_action_qualified']
 history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);raw=(R/'README.md').read_bytes();assert raw.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792';assert(C/'README_before.md').read_bytes()==subprocess.check_output(['git','show','HEAD:README.md'],cwd=R)
 incident=(O/'README_incident_snapshot.txt').read_bytes();assert incident==(C/'README_after_inadvertent_frozen_edit.md').read_bytes()and sha256(incident).hexdigest()=='315b81448c7548ab69d7c8a92753bd26a8e7e8aa2090588d61fc8c1e0f797c6d';assert digest(R/'README.md')==read(O/'preparation.json')['sha256']['README.md']
 links=[];documents=[(R/'README.md',raw[:-len(history)].decode('utf-8'))]+[(R/n,(R/n).read_text(encoding='utf-8'))for n in['docs/COMMON_RESTORATION_CAMPAIGN_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V828.md']]
 for path,body in documents:
  for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',body):
   if target.startswith(('https:','http:','#','mailto:')):continue
   resolved=(path.parent/target.split('#')[0]).resolve();assert resolved.is_relative_to(R)and resolved.exists(),(path,target);links.append([path.relative_to(R).as_posix(),target])
 assert 'docs/RESEARCH_EXECUTION_HANDOFF_V287.md'not in raw[:-len(history)].decode('utf-8');print('STAGE full_interface_replay_correct_master_owners_navigation_and_preserved_incident_verified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();pp=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120);ec=dict(command=cmd,exit_code=pp.returncode,seconds=time.perf_counter()-et,stdout=pp.stdout,stderr=pp.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert pp.returncode==0
 events=[json.loads(x)for x in pp.stdout.splitlines()if x.strip()];exits=[e['exit_code']for e in events if e['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and events[-1]['execution_state']=='COMPLETED'and next(e for e in events if e['event']=='step_finished'and e['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 tree=(C/'old_git_tree.txt').read_bytes();assert tree==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R).decode().splitlines()==['README.md'];state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir()if p.is_file()]+[R/n for n in['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V828.md']];size=sum(p.stat().st_size for p in files);assert size<=64*1024**2 and all(p.stat().st_size<=10*1024**2 for p in files)
 out=dict(schema='RESTORATION_PROBE_INTERFACE_AND_NAVIGATION_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_DECLARED_PROBE_INTERFACES_AND_CURRENT_NAVIGATION',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'preparation.json')['base_HEAD'],state_sha256=state,fresh_replay=fresh[0],complete_artifacts_freshly_recomputed=artifacts,all6610_declared_probe_interfaces_match=True,H_g1_controls_BLIND_other_three_cases_sensitive=True,correct_inactive_master_owner_bindings=ownerchecks,failed_source_only_predecessor_NOT_PROMOTED=True,current_full_action_E2_parent_conjugacy_NOT_ESTABLISHED=True,no_new_sourceful_proper_zero_or_complete_correction_module=True,no_HB1_C5_activation_or_common_restoration_E5A5_claim=True,README_historical_suffix_sha256=sha256(history).hexdigest(),README_only_old_file_authorized_live_prefix_edit=True,checked_local_links=links,frozen_context_edit_incident='FULL_EDIT_CAPTURE_PRESERVED_AND_EXACT_BOUND_BYTES_RESTORED_NO_MANIFEST_REBIND',new_campaign_uses_existing_evidence_not_status_ledger=True,shared_action_chart_software_AI_not_external_independence=True,largest_primary_sampled_private_bytes=max(x['private_bytes']for x in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries=len(tree.splitlines()),new_and_authorized_files_excluding_pending_receipt_final_capture={p.relative_to(R).as_posix():digest(p)for p in files},packet_bytes_excluding_pending_receipt_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_goal_completion_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k]for k in['execution_state','evidence_validation','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
