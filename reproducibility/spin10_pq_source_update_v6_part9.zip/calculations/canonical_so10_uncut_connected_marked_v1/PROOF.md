# The full retained-source mixed master with one local mark

Use the uncut unprobed V887/V888 parent S in the raw Minkowski
LEFT chart, transported to the same paired Euclidean tests.
Let η_i be the odd local epsilon components, β and ρ the odd
constant strengths in βρ order, F_i=E^L_{J_i}S, and s_i=(-1)^p_i.
The IR cutoff below is δ, distinct from the marked test. Keep
all ordinary and retained sources independent before derivatives.

## Full mixed root before source restriction

Write R_{ji}(C)=r_{ji,h} C_h for the V885 source tensor, and
A_h=η_i J_Lambda,j r_{ji,h}, an even external coefficient.
V885 gives the full K as the sum of −η_i E_Lambda,i S, the
half-width term, and A_h C_h. The first part generates a
source-independent translation of the even Lambda field.
It commutes with the raw master bracket and transports the
uncut integrated zero B[S]=0. Thus it makes no contribution
to the mixed root M=[ρ]B[S+ρK]. Apply the ordered V877 Euler
formula to the rest. At arbitrary retained J this gives

    M = ∫ η_i R_{ji}(C) E_Lambda,j S
          +∫ η_i w F_Lambda,i/2 −∫ A_h F_C,h.

The LEFT J_Lambda derivative crosses the odd η, giving the
positive field shear in the first term. The width sign follows
by moving the odd F_Lambda past η. The C derivative of A_h C_h
has no sign because A_h is even. Thus it gives the negative
J_C shift in the last term. The width and J_C terms are
variations of retained sources at fixed ordinary fields, with
their own common proper and rooted contributions.

As a raw action control the (j,i,h)=(14,13,0) source remainder
has r=3 sqrt(10)/20 with g stripped. The raw J_C0 C1 C2 cell
has coefficient −sqrt(10)/4 with g stripped and J_C even.
This pair contributes +3/8 to the g² η13 J_Lambda14 C1 C2
coefficient of the explicit J_C shift. It is one contribution
to M and is kept with the field shear. Dropping the explicit
source term would erase it even though A_h vanishes when J=0.

## Paired rooted existence of the two marked field operations

At fixed positive δ, the V888 comparison of P and Q applies
to any even nilpotent ordinary displacement with vanishing
diagonal derivative. Use it first for U_Lambda=−ρ η, then
for U_Lambda=βρ η_i R_{ji}(C). The first derivative matrix is
zero for the translation. The shear derivative has only its
off-diagonal C_H to Lambda_M block. The same converted cyclic
algebra and full regulated UV subtraction apply. No bare
heat defect is discarded by taking a Jacobian alone.

For the translation the IR defect has an independent η label
and no ordinary field on its marked end. It is a linear test
of the output D=1−χ² against the Euler vertex. For the shear
that end has the independent η label and one ordinary C_H
port. D itself has order zero. A bivalent E_Lambda V through
the constant mixing and scalar chain has effective order at
most one, as in V888. The label is retained when the derivative
acts on the η C product. The only possible forced-zero D
bridge is toward an unlabeled Euler side. Its actual Lambda
one-port is zero by the two forbidden cubic traces and the
radial orbit projection from V888. An unlabeled tree side has
no linear vertex. A separately labeled contact to j_Lambda
uses an ordinary weak limit at independent transfer.

Use V887/V888 on the remaining graphs. The ε-labeled end
cannot be a singleton unlabeled cubic at a cut-cycle equality.
The Euler end keeps its V valence, with the improved D port.
If a hard two-port cycle contains the D edge, either it also
contains the labeled end, or the collapsed D edge improves its
bound by the O(δ) estimate of V888. If D is on an exit its
order is lower. Farther outside a hard core it multiplies
the same grouped ordinary BB or aC response. These groups
have the V887 strict gain and their finite errors vanish with
paired scales. The other terms use the strict rank bound
and D→0 almost everywhere. This proves the vanishing of both
field-change defects with one local mark, including the whole
rooted contributions through one loop. Products of the
independent smooth compact Fourier source tests used in the
explicit source shifts preserve that test domain.

## One common marked connected identity

The translation now gives the positive source-first term
η_i j_Lambda,i. The rest of K is linear in ordinary fields at
fixed retained J. With φ_i=E^L_{j_i}W in the common map,

    I_K^W = ∫ η_i j_Lambda,i + ∫ η_i w φ_Lambda,i/2 + ∫ A_h φ_C,h.

The field shear in M gives the negative source-first contact
−∫ j_Lambda,j η_i R_{ji}(φ_C). The two explicit retained-source
shifts give their ordinary derivatives of W. Consequently

    I_M^W = −∫ j_Lambda,j η_i R_{ji}(φ_C)
              +∫ η_i w E^L_{J_Lambda,i} W/2
              −∫ A_h E^L_{J_C,h} W.

Differentiate the V888 identity ∑ s_i j_i E^L_{J_i}W=0 in
the LEFT ordinary source j_l. The derivative has parity p_l.
Its sign from passing j_i and then the retained source Euler
is (-1)^[p_l p_i+p_l(1−p_i)]=s_l. Therefore for every l

    ∑ s_i j_i E^L_{J_i} φ_l = −E^L_{J_l} W.

Applying ∑ s_i j_i E^L_{J_i} to I_K^W gives three terms. The
explicit derivative of A_h crosses the odd η and gives the
negative shear contact. The odd η in the width term gives
an overall minus when moved past both j_i and E^L_{J_i}, so
the differentiated master gives the positive width source
shift. A_h is even, so the implicit derivative of φ_C gives
the negative J_C source shift. The independent η j_Lambda
term has no retained derivative. This gives exactly I_M^W.

In βρ order the uncut B[S] root is zero before expanding the
marked functional. Thus the mixed coefficient of
W[S+ρK+β B[S+ρK]] is precisely I_M^W, with the complete ordinary
mean response in its definition. The equality with the
marked connected source derivative holds in the same paired
Euclidean map at tree and one loop for one mark. The compact
switched calculation of V877 has its own nonzero B[P] and
switched currents. No equality to that map's adiabatic limit
or general geometric Ward identity follows here.
