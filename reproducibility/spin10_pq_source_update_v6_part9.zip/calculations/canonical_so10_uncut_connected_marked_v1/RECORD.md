# V889 pre-execution contract

Test the full one-mark mixed LEFT master on the V887/V888 direct
paired Euclidean domain. Use the actual uncut unprobed parent,
one independent local odd epsilon and the ordered odd strengths
beta and rho, all fixed finite g and scalar mass-difference degrees,
fixed positive scalar reference and smooth compact Fourier tests.
Keep every retained source until after differentiation. Use the
same UV conversion and complete regulated forests.

Bind V877's ordered switched construction, V885's actual marked
decomposition, V886's regulated shear, V887/V888 and the raw V848
current tensors. Derive the full-J mixed root including the J_C
source shift. Verify its exact sign with a distinct graded control
and a nonzero actual raw action component. Reuse the V888 normalized
inverse-defect identity for the marked translation and shear, and
prove their paired limits with the independent mark label and the
actual forced-zero support. Verify the connected source derivative
algebra before restricting J. The comparison is for one mark only.

Freeze typed inputs, proof and worker before launch. Use 120 s
native, 180 s final including E4 capped at 120 s, 8 GiB sampled
private bytes, 350 MiB launch commit floor, 8 MiB per artifact and
32 MiB packet. Preserve failures, require final exact replay and E4
with historical custody separate, and check staged bytes. Ceiling
is the uncut paired Euclidean one-mark mixed master through one
loop. Keep the compact switched-current identity separate. General
Lorentzian gluing, geometric W5, W6 and E5/A5 remain open.
