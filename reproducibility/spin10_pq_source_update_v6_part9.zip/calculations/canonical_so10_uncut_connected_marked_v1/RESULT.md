# V889 — One marked mixed master in the direct paired map

The full retained-source mixed root consists of the auxiliary
shear, the half-width J_Lambda shift, and a J_C shift with its
negative sign. The actual raw action gives a nonzero +3/8
contribution to the last shift in the stated g² component.
The two graded controls keep all three terms and both ordinary
source parities. Restricting retained sources early loses a
term in the full equation.

The marked translation and shear have vanishing paired inverse
defects at tree and one loop in the V887/V888 domain. Their
independent local label and the actual forced-zero one-port
support control the extra rooted graphs. This gives the full
one-mark mixed LEFT identity with the derived connected signs
and with the same common conversion. The result covers fixed
finite coupling and mass-difference degrees on the declared
smooth compact Fourier tests.

Require the final receipt and capture. The checks share the
action, source chart, software and AI authorship. No new profile,
finite contact or physical input is chosen. The compact switched
master has its separate current terms. A direct uncut geometric
Ward identity, general causal products, W6 and full E5/A5 remain
open.
