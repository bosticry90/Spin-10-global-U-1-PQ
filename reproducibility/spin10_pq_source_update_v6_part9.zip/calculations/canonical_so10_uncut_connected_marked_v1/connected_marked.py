"""Actual raw retained shift and two independent LEFT sign controls."""

import gzip
import json
import sys

import sympy as sp

from execute import PK, ROOT, run_worker

sys.path.insert(0, str(PK))
from source_convention_control import Exterior


CALC = ROOT / "calculations"


def load(path):
    with gzip.open(path, "rt", encoding="utf-8") as stream:
        return json.load(stream)


def actual_retained_shift(role):
    R_word = [[521, []], [553, []], [1165, []]]
    C_word = [[554, []], [555, []], [1196, []]]
    owner = CALC / "canonical_so10_augmented_metric_lift_v1"
    raw = load(owner / "tensor_10.json.gz")["input_polynomial_Minkowski"]
    r_raw, = (cells for word, cells in raw if word == R_word)
    c_raw, = (cells for word, cells in raw if word == C_word)
    assert r_raw == [[[1, 0, 0, 5], -3, 20]] and c_raw == [[[1, 0, 0, 5], -1, 4]]

    current = CALC / "canonical_so10_unprobed_compact_all_coupling_v1"
    joined = load(current / f"{role}_full_current.json.gz")["current"]["complete_S_GF_source"]
    r_current, = (cells for grade, word, cells in joined if grade == 1 and word == R_word)
    c_current, = (cells for grade, word, cells in joined if grade == 1 and word == C_word)
    assert r_current == [[[0, 0, 5], -3, 20]] and c_current == [[[0, 0, 5], 1, 4]]
    # Density minus and the two auxiliary Wick phases cancel on R.
    # Density minus remains on the three ghost/source slots of F_C.
    r = -sp.Rational(r_raw[0][1], r_raw[0][2]) * sp.sqrt(10)
    f = sp.Rational(c_raw[0][1], c_raw[0][2]) * sp.sqrt(10)
    assert -r * f == sp.Rational(3, 8)
    return {"raw_R14_13_0_stripped": str(r), "raw_F_C0_C1_C2_stripped": str(f),
            "explicit_JC_shift_contribution": str(-r * f)}


def mixed_root_control():
    e = Exterior()
    eps, JL, C, D, E = [e.variable(name, 1) for name in ("eps", "JL", "C", "D", "E")]
    L, JC, b = [e.variable(name, 0) for name in ("L", "JC", "b")]
    w = sp.Symbol("w")
    S = e.add(e.scale(e.mul(L, L), w / 2), e.mul(b, L), e.mul(JL, C, L), e.mul(JC, D, E))
    A = e.mul(eps, JL)
    mark = e.add(e.scale(e.mul(eps, L), w / 2), e.mul(A, C))
    actual = {}
    for field, source, parity in (("L", "JL", 0), ("C", "JC", 1)):
        a = e.scale(e.mul(e.partial(mark, source), e.partial(S, field)), -(-1)**parity)
        b_term = e.scale(e.mul(e.partial(S, source), e.partial(mark, field)), -1)
        actual = e.add(actual, a, b_term)
    shear = e.mul(eps, C, e.partial(S, "L"))
    width = e.scale(e.mul(eps, e.partial(S, "JL")), w / 2)
    retained = e.scale(e.mul(A, e.partial(S, "JC")), -1)
    assert actual == e.add(shear, width, retained)
    assert retained and e.add(shear, width) != actual
    assert all("JL" in word for word in retained)
    return {"shear_sign": 1, "width_shift_sign": 1, "retained_JC_shift_sign": -1,
            "full_J_omission_sensitive": True}


def connected_source_control():
    e = Exterior()
    eps, JL1, JL2, jC = [e.variable(name, 1) for name in ("eps", "JL1", "JL2", "jC")]
    jL1, jL2, JC = [e.variable(name, 0) for name in ("jL1", "jL2", "JC")]
    w = sp.Symbol("w")

    def master(poly):
        return e.add(e.mul(jL1, e.partial(poly, "JL1")), e.mul(jL2, e.partial(poly, "JL2")),
                     e.scale(e.mul(jC, e.partial(poly, "JC")), -1))

    W = e.add(e.mul(jL1, JC), e.scale(e.mul(jC, JL1), -1))
    phi_L1 = e.partial(W, "jL1")
    phi_C = e.partial(W, "jC")
    assert master(W) == {}
    assert master(phi_L1) == e.scale(e.partial(W, "JL1"), -1)
    assert master(phi_C) == e.scale(e.partial(W, "JC"), -1)
    A = e.mul(eps, JL2)
    I_K = e.add(e.mul(eps, jL1), e.scale(e.mul(eps, phi_L1), w / 2), e.mul(A, phi_C))
    shear = e.scale(e.mul(jL2, eps, phi_C), -1)
    width = e.scale(e.mul(eps, e.partial(W, "JL1")), w / 2)
    retained = e.scale(e.mul(A, e.partial(W, "JC")), -1)
    assert master(I_K) == e.add(shear, width, retained)
    assert shear and width and retained and master(I_K) != e.add(shear, width)
    return {"both_mean_parity_signs_checked": True, "three_distinct_connected_terms_nonzero": True,
            "early_source_restriction_sensitive": True}


def checks(role):
    return {"actual_retained_shift": actual_retained_shift(role), "mixed_root": mixed_root_control(),
            "connected_source_order": connected_source_control()}


if __name__ == "__main__":
    run_worker(checks, sys.argv[1])
