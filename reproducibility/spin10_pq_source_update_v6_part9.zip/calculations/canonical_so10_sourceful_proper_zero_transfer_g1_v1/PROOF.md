# Selected four-profile proper zeros

This inference requires the completed SZT-1 validation receipt. It does not
change V827's historical disposition: that packet qualified raw-current
zeros and explicitly withheld their new proper interpretation at the time.
V830 supplies the later, separately qualified premise.

The scoped relation is Q Gamma1=-C_Q=C_R at first-u, g<=1, intrinsic 0/1,
for external B,Lambda,C,a and J_B,J_Lambda,J_C,J_a jets, with scalar
means/sources and P=S=K zero AFTER allowed external differentiation. Every
profile in SZT-1 belongs to that domain. Keep the actual hatted insertion
and its source-sensitive counterexample; only its first-u trace is removed
by the qualified stable-ideal argument. No scalar-field/matter-source
derivative or unrestricted source-curvature conclusion is introduced.

V792 constructed complete polarized raw regulator roots using all 643 field
ports. Native reused the full T1F tables; replay freshly LEFT-differentiated
the full F maps. Its final review checked equality to those tables and every
regulator product against the qualified V791 Preference/reference_defect
rows before the older named target restrictions. V789 constructs complete
ordinary Taylor halves from the same S1/U1 densities as its F/E maps; V788
supplies g0 GF and physical ordinary owners. V830 matches every current
F/E column to those constructors. The new parsed copy checks authenticate
that V808's 12 raw roots and eight ordinary lists are EXACTLY these complete
operands, and their native/replay bytes agree. No old restricted catalog
or failed worker is substituted for the full qualified operands.

V827's full type transfer includes every reference class, both orientations,
both ordinary-tail/inverse-u mechanisms, all admissible rooted paths and
the qualified scalar/physical-potential graded support boundary. Its false
scalar-free-u premise remains false. Do not use it in this transfer.

For the four M g1u1 profiles, the complete selected rows contain respectively
4,44,2,4 typed paths. All roots belong to classes 79 or 95, whose actual
right-B contractions vanish identically as polynomials in independent loop
momenta and all remaining color/source/mean atoms. A g0 B neighbor or a
Lambda endpoint supplies exactly that longitudinal momentum through the
qualified full free inverse. Both root orientations and the original even
same-line regulator profiles are retained. The zero is established before
color/Grassmann sewing and integration; an overall sign cannot change it.
Wrong k and omitted-component contractions remain nonzero controls.

The complete reference_F1 diagonal is NONZERO globally: 12,560 terms from
25,120 retained raw terms in nine groups. It remains in the census. Its
class IDs 131..139 occur in none of the selected returning rows. The new
audit proves that absence from the complete lists; it does not set the
reference term zero. Both H catalogs are empty for these four profiles.
Original raw catalogs are empty as well, but V830's first-u premise does
not qualify their unprobed proper interpretation.

Therefore the complete selected regulated C_R for each target is zero at
the fixed finite Gaussian prescription. V830 then supplies the eight
first-u response zeros Q Gamma1=0 (four H, four M), not Gamma1=0.
These are four field/source profiles
across two probes, not eight independent physical predictions. The existing
BBC proper zero is a calibration, not a newly counted result.

The same identically zero paired kernel has zero sequential UV-first /
IR-second reference on the inherited common test domain. No nonzero-limit
interchange, detached inverse-heat/IR operator, new general analytic domain
or altered subtraction is claimed. Do not extend this zero argument to
surviving nonzero kernels. The hatted, unprobed potential, global quantum
measure/phase and QAP obligations retain their earlier scopes.

Read-only AI review established that the minimum new work is the exact
operand lineage and selector/reference audit. Root reviewed those arguments;
the reviewers share action, conventions, ring, software and AI authorship.
The result supports targeted reuse and a narrower indispensable-input list,
not experimental validity, a complete correction module, common restoration,
HB1/C5 activation or E5/A5 acceptance. Authority remains 34/39.
