# Four sourceful proper-zero transfers

Continue V830 / e30199e47cd4b5465d3f66f45f3b4700405ef27a on main in
D:/Codex-Projects/ToE-Next. Fresh preflight is clean with no matching workers.
The previous goal turn made progress. Full research is active; AGENTS.md
governs execution and project_state alone governs scientific authority,
state 113 / 34 of 39. Flavor remains paused; HB1/C5 remain blocked. No
foundational adoption, protected promotion, branch/worktree or external action.

Question SZT-1: do the four V827 raw-current zeros now imply selected proper
one-loop response coefficients Q Gamma1=0 using the V830 finite first-u identity? Target profiles are
Ja-aCC, aaCCC, B-Ja-C and BB-Lambda-C, at g1 u1, intrinsic 0/1, original
Euclidean constant A0 prescription, all colors/ordinary external jets before
allowed source/mean restrictions. Keep Ihat, scalar/PSK restrictions, both
UV/IR factors, full reference subtraction and fixed regulator. No unprobed
proper zero, common restoration or full E5/A5 claim is included.

The least expensive competent test reuses qualified mathematical roots and
Hessians, with an explicit operand-copy and selected-profile audit. It does
not redo derivatives, color contractions, integrals or the full transfer
matrix. Possible outcomes: exact binding/selector agreement and scoped zero
transfer; a preserved mismatch; or incomplete execution. Missing amplitudes
are never fitted. Historical source/receipt bytes remain unchanged.

Freeze inputs, sources, PROOF and navigation before execution. Authenticate
the selected scientific bindings through V792 roots, V789/V788 constructors,
V808 operand packets, V827 classification/support/graded cut and V830 proper
applicability. Do not substitute current policy for old bound policy bytes.
This is selected scientific-parent authentication, not a fresh execution of
the historical experiments or whole-manifest custody acceptance.

Compare all 12 copied raw root lists and eight ordinary Hessian lists exactly
against their constructing owners, including the nonzero full F1 reference.
Native/replay operand bytes must agree. Select every matching rooted row in
both completed transfer tables for original, H and M; match complete V827
path dispositions and profile totals. M must have 4,44,2,4 paths, all removed
by the qualified correct-right-momentum zero. H has an empty catalog for
these profiles. The original empty raw catalogs do not qualify unprobed
proper zeros. Reference classes and both inverse-u flags remain in the
complete search; retain nonzero global reference data. Record all selected
rows, sensitive wrong-momentum/omit-component controls, and blind cases.

Root alone writes/runs. Two read-only AI reviews assessed source/hatted scope
and the operator lineage before execution. They share physical assumptions,
software and AI authorship and are not independent scientists. Agreement
does not validate the physical model or a complete correction basis.

One sequential 240-second job after imports performs the new selector/copy
audit and final evidence verification, including one E4 check (no fresh
replay) against the fixed D: context. This avoids a redundant second pass
through large qualified root polynomials. Each new claim has both complete
native/replay selectors and independent summary/disposition comparisons.
Require outer E4 zero, component exits 0,0,0,0,0,2, seven unresolved custody
references NOTPASS. Check old Git tree except authorized live README prefix,
historical README suffix, new links and unchanged state. Freeze 8 GiB sampled
private memory, 350 MiB launch floor, 16 MiB packet / 4 MiB individual file.
Preserve a complete overflow on D: and stop incomplete, never truncate.
Full capture repo and D: before judging; local commit only after validation
and staged raw-byte verification. Nested-process/true peak is not measured.

After qualification, reassess the surviving g1 source dependencies before
new integrations. Keep the known V804 auxiliary results, V823 marked g2
consequences, V824 restricted exclusion and V826 BBC zero. A source-pattern
catalog is not a complete admitted normalization/cohomology module.
