# Four additional first-u proper-zero profiles

The exact operand-copy and native/replay selector audit qualifies Q Gamma1=0
for Ja-aCC,
aaCCC, B-Ja-C and BB-Lambda-C at first-u H/M, g1, intrinsic 0/1, in
PROOF.md's finite Euclidean prescription. M has 4,44,2,4 candidate paths,
all removed before integration; H has empty complete catalogs. The global
F1 reference remains nonzero and has no selected returning row.

Twelve complete raw roots and eight ordinary Hessians match their actual
constructors. No new derivative, color or loop integration was performed.
The later V830 proper premise is applied without changing V827 records.
Unprobed proper zeros and a complete correcting module remain unqualified.

This closes four additional profile inputs across two probes; it is not
eight independent physical predictions or a measure of E5 completion.
Authority stays 34/39, E5/A5 and common restoration remain open, and seven
historical custody references remain unresolved NOTPASS. Shared action,
software and AI authorship limit independence. Next reassess the surviving
g1 source dependencies before further amplitudes.
