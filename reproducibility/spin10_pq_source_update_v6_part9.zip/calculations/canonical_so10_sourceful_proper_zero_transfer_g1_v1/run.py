from pathlib import Path
from hashlib import sha256
import ast,importlib.util,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/sourceful-proper-zero-transfer-g1-v1-2026-11-07');digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as h:json.dump(z,h,sort_keys=True);h.write('\n')
assert not(O/'preparation.json').exists();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='e30199e47cd4b5465d3f66f45f3b4700405ef27a';assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R).decode().splitlines()==['README.md']
sp=importlib.util.spec_from_file_location('sourceful_zero_transfer_preparer',O/'audit.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
for name in m.INPUTS:
 if name not in['README.md','docs/RESEARCH_EXECUTION_HANDOFF_V831.md']:assert(R/name).read_bytes()==subprocess.check_output(['git','show','HEAD:'+name],cwd=R),name
for n in['RECORD.md','PROOF.md','audit.py','run.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as h:h.write((O/n).read_bytes())
assert C.is_dir()and(C/'README_before.md').exists()
with(C/'old_git_tree.txt').open('xb')as h:h.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
dump(O/'preparation.json',dict(base_HEAD=head,sha256={**{n:digest(R/n)for n in m.INPUTS},**{q.relative_to(R).as_posix():digest(q)for q in O.iterdir()if q.is_file()}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'audit.py')]);dump(O/'capture.json',cap);dump(C/'capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
