# V952 pre-execution contract

Compare the massive B–scalar and massless B–ghost
two-edge kernels of the V951 linked kinetic test.
Freeze the V791 free reference blocks, transverse
projector, Euclidean momentum P>0, positive scalar
squared mass M and one common heat/finite subtraction.
Do not choose physical masses.

Derive the full finite momentum projection and its
mass insertion analytically. Check the exact limits
and use independent Feynman-parameter and direct
angular-radial quadratures at fixed exact ratios.
The result concerns the free reference kernels.
Physical-minus-reference transport and other
one-loop contributions remain separate.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB
sampled private, 350 MiB launch floor, 8 MiB artifact and
32 MiB packet. No scientific authority change.
