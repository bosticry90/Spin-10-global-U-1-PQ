# V952 result — scalar and ghost reference weights differ

For nonzero Euclidean external momentum P, the free
transverse two-edge projection has a strictly negative
scalar-minus-ghost difference for every positive scalar
squared reference mass. Its relative bracket in
16 pi^2 units is

    -3[log(1+r)+r-r^2 log(1+1/r)]/4,  r=M/P.

The literal inverse identifies the three massive
ordinary scalar blocks and the massless ghost.
The parameter integral and direct angular-radial
integral agree at five exact mass ratios, including
the mass derivative. The zero-transfer derivative
at positive mass is -3/(64 pi^2 M).

The relative result cancels a common finite shift.
It concerns free reference responses with matched
profiles. An opposite mass insertion is necessary
in a comparison at fixed total parent. That
transport and other contributions remain separate.
Both routes share model, analysis and software.
No masses or finite constants have been chosen.
