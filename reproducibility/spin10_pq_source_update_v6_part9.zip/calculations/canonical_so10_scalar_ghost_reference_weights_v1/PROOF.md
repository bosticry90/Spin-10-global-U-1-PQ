# Massive scalar and massless ghost transverse reference weights

Write P=p^2>0 and M for the scalar squared reference
mass. The V791 reference Green supplies the three
actual scalar denominators k^2+Mref_s_squared and the
massless ordered ghost denominator. In the preserved
transverse convention the common longitudinal external
projection of the two-edge tensor is

    W(P,M)= integral d^4k/(2 pi)^4
       [1-(k dot p)^2/(k^2 P)] / [k^2 ((k+p)^2+M)].

Strip the shared Wick, color and graph factors. Use
the same positive per-edge heat profiles and common
subtraction on both kernels in this comparison. At
fixed P the mass difference is absolutely integrable:
the two possible small-momentum poles are locally
integrable and separated, and subtraction gains two
powers on the UV tail. Bounded heat and IR profiles
therefore disappear from that difference in the stated
limit. Unequal heat lengths have their own relative
constant as in V947.

For an absolute check write alpha=kappa-gamma_E-log c
with total heat length c and the HMM1 logarithmic
subtraction at scale mu. Feynman-parameterize the
scalar denominator against the first edge with weight
y, shift to l=k+y p and put Delta=y(M+(1-y)P).
For the longitudinal numerator correction use
1/(k^4 Q)=2 integral_0^1 (1-y)/(l^2+Delta)^3 dy.
The odd l term drops, and (l dot p)^2/P averages
to l^2/4. The radial integrals in units 16 pi^2
are alpha-1-log(Delta/mu^2) for power two and
1/(2 Delta) for power three. The fixed shift in
the heat arguments gives no finite term beyond
the common total length for this logarithmic
projection. Combining the terms and integrating
the y(1-y) term by parts gives

    16 pi^2 FP W(P,M) =
        3 alpha/4 - (3/2) integral_0^1 x log((M+xP)/mu^2) dx.

In particular the massless reference at P>0 gives
3[alpha-log(P/mu^2)+1/2]/4. With r=M/P the relative
finite bracket is

    16 pi^2 [W(P,M)-W(P,0)] =
        -3[log(1+r)+r-r^2 log(1+1/r)]/4.

It is strictly negative for r>0. Its M derivative
is the convergent insertion on the scalar line,
with a minus sign from differentiating its inverse:

    partial_M W = -3[1-r log(1+1/r)]/(32 pi^2 P).

This equals -3/(64 pi^2 M) as P goes to zero for
M>0. The ghost has no corresponding scalar mass
parameter. These are free reference responses. A
split comparison at fixed total parent must include
the opposite mass vertex, not confuse reference
variation with a change of the physical mass.

The direct numerical route aligns p with the first
axis. With k=s sqrt(P), A=s^2+1+r, B=2s and
T=A+sqrt(A^2-B^2), the angular sin^4 integral is
pi[3-(B/T)^2]/(4T). It follows by expanding sin^4
and the cosine Fourier series of 1/(A+B cos theta).
The code integrates the massive-minus-massless
radial difference and its mass derivative directly
and compares to the separate parameter integral.
Both replay paths share the free model and
numerical library. The finite nonlocal reference
difference is not a failure of the full
split-compensated Slavnov or geometric identities.
