"""Compare the free scalar and ghost transverse two-edge weights."""

import gzip
import json
import sys

import mpmath as mp
import sympy as sp

from execute import ROOT, run_worker


def check(phase):
    folder = ROOT / "calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1"
    inverse = json.loads(gzip.decompress((folder / f"{phase}_inverse.json.gz").read_bytes()))
    G = {(a,b):z for a,b,z in inverse["Greference"]}
    q = sp.symbols("q0:4")
    q2 = sum(z*z for z in q)
    blocks = ((180,234,"Phi"),(234,486,"Sigma"),(486,506,"phi"))
    for lo,hi,species in blocks:
        mass = sp.Symbol(f"Mref_{species}_squared")
        assert all(sp.sympify(G[i,i]) == 1/(q2+mass) for i in range(lo,hi))
    assert sp.sympify(G[553,598]) == 1/q2

    r = sp.Symbol("r",positive=True)
    formula = -sp.Rational(3,4)*(sp.log(1+r)+r-r*r*sp.log(1+1/r))
    slope = -sp.Rational(3,2)*(1-r*sp.log(1+1/r))
    assert sp.simplify(sp.diff(formula,r)-slope) == 0
    assert sp.limit(formula,r,0,dir="+") == 0
    assert sp.limit(r*slope,r,sp.oo) == -sp.Rational(3,4)

    mp.mp.dps = 80
    controls = []
    for num,den in ((1,100),(1,3),(1,1),(5,1),(80,1)):
        R = mp.mpf(num)/den
        expected = -mp.mpf(3)/4*(mp.log1p(R)+R-R*R*mp.log1p(1/R))
        parameter = -mp.mpf(3)/2*mp.quad(lambda x:x*mp.log1p(R/x) if x else 0,[0,1])
        def angular(s,m):
            A = s*s+1+m
            D = mp.sqrt(((s-1)**2+m)*((s+1)**2+m))
            T = A+D
            return (3-(2*s/T)**2)/T
        radial = mp.quad(lambda s:s*(angular(s,R)-angular(s,0)),[0,1,2,10,mp.inf])
        def insertion(s):
            A = s*s+1+R
            D = mp.sqrt(((s-1)**2+R)*((s+1)**2+R))
            return -6*s/(A+D)**2
        d = mp.quad(insertion,[0,1,2,10,mp.inf])
        assert abs(expected-parameter) < mp.mpf("1e-42")
        assert abs(expected-radial) < mp.mpf("1e-42")
        assert abs(d+mp.mpf(3)/2*(1-R*mp.log1p(1/R))) < mp.mpf("1e-42")
        assert expected < 0 and d < 0
        controls.append([num,den])
    return {"ordinary_scalar_reference_blocks":[s for _,_,s in blocks],
            "massless_ghost_reference":True,
            "parameter_and_direct_radial_controls":controls,
            "common_shift_cancels_from_relative_weight":True,
            "positive_mass_slope_strictly_negative":True,
            "zero_transfer_mass_derivative":"-3/(64*pi^2*M)"}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
