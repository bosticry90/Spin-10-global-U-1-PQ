# V880 same-map uncut proper domain and joint local primitive

Start at V879 `cdbb4b9a` on main, D:. Test whether the SAME expanded
fixed-flat heat/converted pair supplies one polynomial primitive for the
unprobed uncut local W3/W4 and modified W5 residuals. Separate the
algebraic switch-jet specialization, an independently defined uncut
finite-word proper family, and any slow-switch limit of compact coefficients.
Use the original unshifted source-retained action and fixed reference,
all g and all finite labeled vertex orders, with u=rho=0. Use one constant
LEFT beta or one local omega in the same scope as V879. Keep full currents,
heat clocks, paired soft terms and the pure reference constant.

Bind the complete actual unlabelled quadratic types and linear tangent,
the uncut constant-chain and Mellin boundary proofs and the V879 transport.
Check the finite support automaton and its extra mass control. Derive an
actual switched g0 Lambda–ghost master Hessian by exact Euler arithmetic
and by the literal current identity. Show it can be nonzero away from
the plateau and vanishes under the local plateau jet map. Include an
actual Phi54 mixed X/Y heat-clock witness with the full reference mass.
The test does not replace the complete local primitive with that subword.

Worker and final review limits are 120 and 180 seconds, 8 GiB sampled
private bytes with a 350 MiB launch floor. Each artifact is at most 8 MiB
and the packet at most 32 MiB. Final E4 keeps its 120-second subprocess
bound, exits [0,0,0,0,0,2] and seven unresolved custody references.
Require both actual raw g0 slice routes and a separate review. Preserve
failures and sources. Qualification can establish a common local
primitive and a separate prospective uncut proper family in the declared
word class. No global switch limit, recovered full heat profile, new
normalization adoption, physical viability, protected E5/A5 promotion or
remote action.
