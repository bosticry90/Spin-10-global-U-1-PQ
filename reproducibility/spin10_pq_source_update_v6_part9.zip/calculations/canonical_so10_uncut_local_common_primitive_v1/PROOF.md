# One uncut polynomial primitive in the same expanded flat prescription

## Local specialization and common signs

Use V879 with u=rho=0, fixed flat K_0 and the unchanged unshifted action
S_A. Let e be the map on the local coefficient ring that sets sigma=1
and every positive sigma jet to zero. It is a differential algebra
map because those assignments commute with total ordinary derivatives.
It also commutes with the ordinary/source Euler operators and the
fixed parameterized background variation. The first dimension jet and
the angular operation act on the independent metric and coefficient
data and commute with this evaluation. V879 gives a finite polynomial
local construction, so this evaluation has no convergence premise.
The reference R_A stays the same in the parent and its conversion.

Let F_R=F_H+C be the common converted coefficient and C=C_fin its
heat-to-converted local difference on the whole compact parent. I_{U,H}
is the direction U of the same proper functional and I_{U,C} the
corresponding local derivative of C. The three compact residuals with
the inherited signs are

    Delta_Q = Q_P F_H − I_{B[P],H} = I_{B[P],C} − Q_P C,
    Delta_b = T_b F_H − I_{T_bP,H} = I_{T_bP,C} − T_b C,
    Delta_q = T_q F_H + I_{CP,H} − I_{G,H}
            = I_{G,C} − T_q C − I_{CP,C},   G=(T_q+C_source)P.

Here C_source is the external source correction from E3 and V879,
written CP or CS_A when applied to the parent. The symbol C without
an action argument denotes the counterterm throughout these equations.
Use the derivative of one map, with the same sign for each insertion.

At e, the parent becomes S_A and B[P] becomes B[S_A], the full E2
master current. Likewise T_b P and G become T_b S_A, the full background
current. These uncut local functionals are divergences. Take the whole
current before its Euler Hessian. This Hessian of a divergence vanishes
for a constant strength, which also annihilates the same-parent local
counterterm derivative in that direction. It would not be legitimate
to delete the direction on the switched parent. The linear b of the
causal conversion also commutes with total derivatives in the fixed
flat contraction, and retains all its switched terms before evaluation.

Put C_U=e(C). The joint local result is

    e(Delta_Q) = −Q_S C_U,
    e(Delta_b) = −T_b C_U,
    e(Delta_q) = −T_q C_U − I_{C_source S_A,C_U}.

Here Q_S is the full uncut source-left operator. The last insertion
does not disappear. The actual nonzero g3 source direction of V879
remains in that slot. The source correction acts on the classical
parent before the insertion, with no assumed affine transformation
of the effective action. C_U has polynomial g degree at most four.
An individual coefficient of Q_S C_U is the sum of Q_j C_{U,m−j},
with j=0,1,2. This is a whole polynomial primitive, with no inverse
g and no separate same-grade primitive assumption. The other Ward
derivatives use the same polynomial with their own inserted arguments.

## Independent definition of the uncut prospective proper coefficient

Use the uncut parent directly in the expanded fixed-flat X/Y construction.
This is a separate definition at fixed finite word order. At vanishing
external labels, the only unmarked interaction Hessian differences
from K_0 are scalar mass differences and the actual 432 g1 scalar–
auxiliary density terms. The g2 GF and source terms have no bilinear
component. The 29 physical potential terms supply no other constant
gauge/ghost port. Retain the scalar mass blocks with arbitrary original
coefficients. Each nonconstant X or other interaction carries an
independent mean, source or A transfer. The only field-independent
tangents are the actual 180 derivative gauge rules and 45 nonminimal
rules. No higher-g tangent has a constant part.

Use the joint Born domain with constant chains collapsed before the
IR boundary. The free B–B pole order is at most two, B–Lambda and its
transpose at most one, massive reference scalar edges at most zero and
ghost edges at most two. The constant vertices are xx and Lambda x
with its transpose. G_LambdaLambda=0 forces any scalar–auxiliary chain
to exit at a B edge and prevents a positive-pole cycle. The closure
adds Bx and xB of pole order one and preserves the original maxima.
The single derivative gauge tangent merges orders two and two with
one momentum numerator. The single nonminimal tangent merges at
most orders two and one. Thus the one-tangent pole is at most three.
One false constant vector mass already produces an order-four edge
and fails this proof. At a finite word the remaining independent
transfers are the same submersion as in the joint Born owner, and the
fixed Mellin/Feynman boundary is used with all matched defects.
No Schwinger inverse or infinite chain is assumed.

This admission does not take sigma to one in a nonlocal integral.
Define the same bare heat and converted traces with the actual flat
expanded word length and the same reference and normalization before
their difference. Each constant chain is already handled in this
direct uncut domain. On the hard local symbols the map e agrees with
putting S_A directly into the finite construction, by its Euler and
polynomial naturality. Therefore C_U is a common local primitive
also for the independently defined uncut prospective proper residuals
in that word class. This statement leaves the global cut-to-uncut
limit and a separate recovered raw profile comparison open.

The flat heat clock is a real distinction from a relative organization.
In the actual Phi54 block take X_1 from the linear reference A
insertion and Y_1 from the linear B−A insertion, with both directions
the same normalized light color. At zero external jets their
numerators are 2i g r(A).p and 2i g r(B−A).p. Retain the common
positive Phi reference mass squared M². The angular critical symbol
of X_1 Y_1 has coefficient 8 g² M² tr(r_A r_{B−A})/D. For the chosen
color that trace is −12. With the two orders and log weight −1/2,
the D=4 critical coefficient is +24 g² M². The actual clock is c=4.
Assigning relative length one changes the normalized logarithmic
finite term by −24 g² M² log 2 in true-minus-wrong order, before the
common prefactor. This selected contribution shows why one cannot
identify distinct raw maps by replacing the ordered flat clock.

## Actual boundary kernel that survives a finite plateau

At raw Minkowski g0 in a light color, the literal mixed term is
−Lambda div B and the ordered reference mixed term is
(B.partial Lambda−Lambda div B)/2. Their difference is
−div(Lambda B)/2. The literal ghost term is −partial C.partial a;
the reference is (C Box a−a Box C)/2. Their difference is
−Box(C a)/2. Thus the selected E_{P,B}|Lambda is
partial Lambda+Lambda partial sigma/2 and the LEFT E_{P,a} is
−Box C+(Box sigma) C/2. Use the actual raw unsigned source columns
F_B=sigma partial C and F_a=−sigma Lambda, as in V876. The
complete Lambda–C projection of B[P], modulo its explicit current
div(sigma Lambda partial C), is

    Lambda [ (sigma/2−1) partial sigma . partial C − sigma (Box sigma) C/2 ].

For sigma=s chi and a compact C that is constant near the Lambda test,
choose chi=1/2+t² there with no spatial jets. The coefficient at s²
is −chi Lambda C on that test. A positive Lambda bump detects a
nonzero coefficient. The Hessian of this quadratic root carries
only switch jets and can occur outside a plateau containing all
external mean and source labels. At the local jet specialization it
vanishes, while dropping the switch terms first would miss the
finite-boundary kernel. This is a selected tree/Hessian witness.
The complete loop contributions and slow-switch behavior do not
follow from its nonzero value.

The arguments use the same qualified classical and finite-word
analytic inputs and independent arithmetic controls. They yield a
prospective unprobed one-loop local result in the specified map. A
general quantum construction, measure, normalized composite products,
quantum equivalence, full A3 and E5/A5 remain open.
