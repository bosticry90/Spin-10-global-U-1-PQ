"""Actual uncut support, switched quadratic Euler and mixed clock controls."""

import gzip
import json
import sys

import sympy as sp

from execute import PK, ROOT, read, run_worker

sys.path.insert(0, str(PK))
sys.path.insert(0, str(ROOT / "tools/portable_dh_v1"))
from exact_algebra import Algebra
from source_convention_control import Exterior


CALC = ROOT / "calculations"


def unzip(path):
    return json.loads(gzip.decompress(path.read_bytes()))


def uncut_types():
    z = unzip(ROOT / "tools/portable_dh_v1/inputs.json.gz")
    geo = z["geometry"]
    a = Algebra(geo["names"], geo["parities"])
    gf = a.rows(z["gauge_fixing_density"])
    assert all(len(w) >= 2 for _, w in gf)
    higher_quadratic = [(g, w) for g, w in gf if g > 0 and len(w) == 2]
    assert len(higher_quadratic) == 432
    for g, w in higher_quadratic:
        names = [a.names[n] for n, _ in w]
        assert g == 1 and not any(j for _, j in w)
        assert sum(name.startswith("L") for name in names) == sum(name.startswith("x_") for name in names) == 1
    constant = []
    for field, rows in z["master_field_maps"].items():
        for (g, word), c in a.rows(rows).items():
            assert word
            if g > 0:
                assert len(word) >= 2
                continue
            (n, jets), = word
            name = a.names[n]
            if field.startswith("B"):
                color, axis = field[1:].split("_")
                assert name == "C" + color and jets == (int(axis),) and c == (((0, 0, 0), 1),)
                constant.append("B")
            else:
                assert not jets and c == (((0, 0, 0), -1),)
                if field.startswith("bar"):
                    assert name == "b" + field[3:]
                else:
                    assert field.startswith("ub") and name == "L" + field[2:]
                constant.append("a")
    assert constant.count("B") == 180 and constant.count("a") == 45 and len(constant) == 225

    free = {("B", "B"): 2, ("B", "L"): 1, ("L", "B"): 1,
            ("x", "x"): 0, ("C", "a"): 2, ("a", "C"): 2}
    vertices = {("x", "x"), ("L", "x"), ("x", "L")}

    def step(edges, types):
        out = dict(edges)
        for (i, j), p in free.items():
            for (k, m), q in edges.items():
                if (j, k) in types:
                    out[i, m] = max(out.get((i, m), -1), p + q)
        return out

    closure = step(step(free, vertices), vertices)
    assert step(closure, vertices) == closure == {**free, ("B", "x"): 1, ("x", "B"): 1}
    pole = {n: max(k for (i, _), k in closure.items() if i == n) for n in ("B", "L", "x", "C", "a")}
    assert pole["B"] + pole["C"] - 1 == pole["a"] + pole["L"] == 3
    wrong = step(free, vertices | {("B", "B")})[("B", "B")]
    assert wrong == 4
    return {"g1_Lambda_scalar_quadratic_rows": len(higher_quadratic), "g2_quadratic_rows": 0,
            "linear_tangent_rows": [180, 45], "closure": [[i, j, k] for (i, j), k in sorted(closure.items())],
            "one_tangent_max_pole": 3, "added_constant_vector_mass_pole": wrong}


def actual_slice(role):
    metric = CALC / "canonical_so10_augmented_metric_lift_v1"
    raw = unzip(metric / ("tensor_7.json.gz" if role == "native" else "tensor_6.json.gz"))["input_polynomial_Minkowski"]
    table = {(tuple((n, tuple(j)) for n, j in w), tuple(k)): (num, den)
             for w, cells in raw for k, num, den in cells}
    eta = [1, -1, -1, -1]
    for mu, s in enumerate(eta):
        assert table[((mu, (mu,)), (508, ())), (0, 0, 0, 0)] == (-s, 1)
        assert table[((553, (mu,)), (643 + mu, ())), (0, 0, 0, 0)] == (-1, 1)
    assert table[((508, ()), (1241, ())), (0, 0, 0, 0)] == (-1, 1)
    current = unzip(CALC / "canonical_so10_joint_common_family_applicability_v1" /
                    f"{role}_complete_full_background_extension.json.gz")
    ghost = {tuple((n, tuple(j)) for n, j in w): (num, den)
             for g, w, cells in current["complete_S_GF_source"] if g == 0 and len(w) == 2
             for k, num, den in cells if k == [0, 0, 0]}
    assert all(ghost[((553, (mu,)), (598, (mu,)))] == (-1, 1) for mu in range(4))
    assert [current["joined_parities"][n] for n in (508, 553, 598, 1241)] == [0, 1, 1, 0]
    return {"raw_mixed_coefficients": [-s for s in eta], "raw_source_B_coefficients": [-1] * 4,
            "raw_source_a_coefficient": -1, "literal_Euclidean_ghost_coefficients": [-1] * 4}


def beta_kernel():
    e = Exterior()
    slots = {f: [e.variable(f + str(j), odd) for j in range(3)]
             for f, odd in (("s", 0), ("L", 0), ("B", 0), ("C", 1), ("a", 1))}
    s, L, B, C, a = [slots[k] for k in ("s", "L", "B", "C", "a")]
    jets = {f + str(j): row[j + 1] for f, row in slots.items() for j in range(2)}

    def diff(P):
        return e.derive(P, jets, parity=0)

    def euler(P, field):
        terms = [e.partial(P, field + str(j)) for j in range(3)]
        return e.add(terms[0], e.scale(diff(terms[1]), -1), diff(diff(terms[2])))

    literal = e.scale(e.add(e.mul(L[0], B[1]), e.mul(C[1], a[1])), -1)
    R = e.scale(e.add(e.mul(B[0], L[1]), e.scale(e.mul(L[0], B[1]), -1),
                      e.mul(C[0], a[2]), e.scale(e.mul(a[0], C[2]), -1)), sp.Rational(1, 2))
    current = e.scale(e.add(diff(e.mul(L[0], B[0])), diff(diff(e.mul(C[0], a[0])))), -sp.Rational(1, 2))
    assert e.add(literal, e.scale(R, -1)) == current
    P = e.add(R, e.mul(s[0], e.add(literal, e.scale(R, -1))))
    EB = euler(P, "B")
    Ea = euler(P, "a")
    assert EB == e.add(L[1], e.scale(e.mul(s[1], L[0]), sp.Rational(1, 2)))
    assert Ea == e.add(e.scale(C[2], -1), e.scale(e.mul(s[2], C[0]), sp.Rational(1, 2)))
    master = e.add(e.mul(s[0], C[1], EB), e.scale(e.mul(s[0], L[0], Ea), -1))
    reduced = e.add(e.scale(e.mul(s[0], s[1], L[0], C[1]), sp.Rational(1, 2)),
                    e.scale(e.mul(s[1], L[0], C[1]), -1),
                    e.scale(e.mul(s[0], s[2], L[0], C[0]), -sp.Rational(1, 2)))
    assert e.add(master, e.scale(diff(e.mul(s[0], L[0], C[1])), -1)) == reduced
    even = e.even_symbols
    plateau = {even["s0"]: 1, even["s1"]: 0, even["s2"]: 0}
    assert not e.clean({w: value.subs(plateau) for w, value in reduced.items()})
    amplitude = sp.Symbol("amplitude")
    bump = {even["s0"]: amplitude / 2, even["s1"]: 0, even["s2"]: 2 * amplitude, even["L0"]: 1}
    actual = sp.expand(reduced[("C0",)].subs(bump)).coeff(amplitude, 2)
    assert actual == -sp.Rational(1, 2)
    return {"ordinary_E_B": e.record(EB), "left_E_a": e.record(Ea), "mod_current_Lambda_C": e.record(reduced),
            "plateau_mod_current": [], "varying_switch_point_coefficient_at_s2": str(actual)}


def clock():
    data = read(CALC / "canonical_so10_current_background_reference_bridge_v1/result_a.json")
    rows = data["compared"]["twelve_current_homogeneous_carriers"][0]
    phi = {(i, j): sp.sympify(c) for i, j, c in rows if 180 <= i < 234 and 180 <= j < 234}
    trace = sp.simplify(sum(c * phi.get((j, i), 0) for (i, j), c in phi.items()))
    assert trace == -12
    p2, M2, g, D = sp.symbols("p2 M2 g D", positive=True)
    inverse_square = (1 + M2 / p2) ** -2
    critical = sp.series(inverse_square, p2, sp.oo, 2).removeO().coeff(1 / p2)
    XY = -4 * g**2 * trace * critical / D
    coefficient = -XY.subs(D, 4)  # both orders with log weight −1/2
    loss = sp.simplify(-coefficient * (sp.log(4) - sp.log(2)))
    assert coefficient == 24 * M2 * g**2 and loss == -24 * M2 * g**2 * sp.log(2)
    return {"trace_actual_light_Phi": str(trace), "mixed_critical_coefficient": str(coefficient),
            "true_flat_clock": 4, "wrong_relative_clock": 2, "true_minus_wrong_log_factor": str(loss)}


def checks(role):
    return {"actual_raw_slice": actual_slice(role), "uncut_types": uncut_types(),
            "switched_beta_kernel": beta_kernel(), "actual_mixed_clock": clock()}


if __name__ == "__main__":
    run_worker(checks, sys.argv[1])
