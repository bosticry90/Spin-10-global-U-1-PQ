"""Verify the uncollapsed mixed scalar triangle on separated supports."""

import importlib.util
import sys

import mpmath as mp
import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)


def check(phase):
    _, entries, _, f, _, _ = source.owner.inputs(phase)
    Casimir = {}
    for h in range(12):
        Casimir = source.add(Casimir, source.bracket(f,{h:1},dict(f[h,1])),-1)
    assert Casimir == {1:3}
    coefficient = sp.Rational(3-8,2)
    pairs = ((0,2),(66,166),(306,310))
    projections = [sp.expand(coefficient*entries[1][pair]) for pair in pairs]
    assert projections == [-sp.Rational(5,4),sp.Rational(5,4),-sp.Rational(5,4)]

    def gauge(r):
        return 3/(8*sp.pi**2*r**2)
    def mixed(r):
        return -sp.I/(2*sp.pi**2*r**3)
    a,b = sp.S.One, sp.Integer(2)
    exchange = sp.simplify(gauge(a)*mixed(b)-gauge(b)*mixed(a))
    assert exchange == 3*sp.I/(128*sp.pi**4)
    assert sp.simplify(gauge(a)*mixed(a)-gauge(a)*mixed(a)) == 0

    p = sp.Matrix(sp.symbols("p0:4"))
    q = sp.Matrix(sp.symbols("q0:4"))
    l = sp.Matrix(sp.symbols("l0:4"))
    M = sp.Symbol("M",positive=True)
    k = -p-q-l
    numerator = (p-q).dot(k)
    rest = q.dot(q)+M-(p.dot(p)+M)+(q-p).dot(l)
    assert sp.expand(numerator-rest) == 0

    mp.mp.dps = 65
    for value in (mp.mpf(1)/4,mp.mpf(1),mp.mpf(4)):
        def D(r,m):
            return mp.sqrt(m)*mp.besselk(1,mp.sqrt(m)*r)/(4*mp.pi**2*r)
        m = mp.sqrt(value)
        # Substitute t=m cosh(u) to remove the endpoint root.
        pp = mp.quad(lambda u:(m*mp.cosh(u))**2*mp.exp(-m*mp.cosh(u))*
                    (m*mp.sinh(u))**2,[0,2,5,12])/(4*mp.pi**2)
        insertion = -mp.quad(lambda u:(m*mp.cosh(u))**2*mp.exp(-m*mp.cosh(u)),
                            [0,2,5,12])/(8*mp.pi**2)
        def pp_bessel(mass):
            return mp.diff(lambda r:D(r,mass),1,2)
        assert abs(pp-pp_bessel(value)) < mp.mpf("1e-45")
        assert abs(insertion-mp.diff(pp_bessel,value)) < mp.mpf("1e-45")
        assert pp > 0 and insertion < 0
    return {"separated_scalar_projections":[str(z) for z in projections],
            "gauge_mixed_exchange":"3*i/(128*pi^4)",
            "separated_triangle_nonzero":True,
            "separated_reference_mass_derivative_nonzero":True,
            "mass_bessel_spectral_checks":3,
            "independent_switch_transfer_retained":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
