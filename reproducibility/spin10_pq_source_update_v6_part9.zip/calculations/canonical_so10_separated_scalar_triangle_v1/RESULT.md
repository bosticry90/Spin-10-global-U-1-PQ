# V954 result — separated uncollapsed scalar triangle

The mixed scalar triangle is nonzero with all three
exterior supports disjoint. The Phi, Sigma and
ordinary phi literal polarizations are nonzero, and
the gauge–mixed exchange is nonzero at the explicit
collinear points. The same separated triangle has
a strictly nonzero scalar reference-mass derivative.

A two-vertex seagull, its scalar mass insertion and
a local contact vanish on those supports. Therefore
the whole triangle or its mass response cannot be
represented by reweighting the two-vertex kernel.
The triangle's own opposite mass insertion is a
different contribution. The numerator identity
retains the independent switch transfer.

The spectral and Bessel derivative routes agree at
three positive squared masses. These are diagnostic
values, not selected physical masses. Both routes
share the model, conventions and numerical software.
