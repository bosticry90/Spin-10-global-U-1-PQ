# Separated mixed scalar triangle and its reference-mass response

At the mixed scalar vertex the incoming mixed momentum
is k=-(p+q+l), where p is the exterior scalar momentum,
q the scalar line and l the vertex switch transfer. Its
derivative contraction obeys

    (p-q).k = (q^2+M)-(p^2+M)+(q-p).l.

The constant after division by q^2+M collapses the
scalar edge. The other terms remain and carry the
actual mass, exterior derivative and switch transfer.
Neither a choice of two-edge coefficient nor a local
contact represents the whole uncollapsed expression.

For an explicit test set the exterior B point z=0
and two scalar points x=a e, y=b e with e a unit
coordinate vector and 0<a<b. Choose independent compact
test functions in small disjoint neighborhoods and
a switch constant on all three. Take B polarization e
and color e1 in the light algebra. The actual color
Casimir is C_H e1=3 e1, so the V949 mixed tensor gives
T e1=-(5/2)e1. In the joined scalar chart the checked
ordered pairs (0,2),(66,166),(306,310) give nonzero
Phi, Sigma and ordinary phi projections of this color
matrix. The two internal B ports for this light
external color are broken.

Away from collisions the mixed and transverse
propagator divergences vanish. Integration by parts
at both exterior scalar vertices transfers each
direct derivative onto the scalar Green, with the
two scalar assignments exchanged in skew color order.
The separated coefficient, up to the common phase
and color factor, contains

    4 partial_(x,mu) partial_(y,nu) D_M(x-y)
      [G^T_(mu,e)(x-z) L_nu(y-z)
       - G^T_(mu,e)(y-z) L_nu(x-z)].

Here L= i partial D_0 in the V791 Euclidean convention.
Only the collinear components remain on this probe.
They are G^T_ee(r e)=3/(8 pi^2 r^2) and
L_e(r e)=-i/(2 pi^2 r^3), by Fourier inversion
of the massless scalar and transverse denominators.
For a=1,b=2 their exchange is 3i/(128 pi^4).
The mixed x,y derivative is -D_M''(b-a), which
cannot vanish for positive M. In fact

    D_M''(r) = integral_(sqrt M)^infinity
                  t^2 exp(-rt) sqrt(t^2-M) dt/(4 pi^2),
    partial_M D_M''(r) = -integral_(sqrt M)^infinity
                  t^2 exp(-rt)/sqrt(t^2-M) dt/(8 pi^2).

The endpoint term vanishes before the first
derivative; its new inverse-root singularity is
integrable. The exact signs are positive and
negative respectively. Independent numerical
controls differentiate the Bessel expression
and compare the regularized spectral integrals.

By continuity the separated coefficient and its mass
response survive smearing in sufficiently small disjoint
test supports. A two-vertex seagull bubble puts B and
one scalar at the same vertex. Both assignments, all
local terms and mass insertions into that bubble vanish
on the disjoint supports. Thus the full mixed scalar
triangle and its reference derivative cannot be
replaced by a reweighted T2 seagull or local contact.
The opposite quadratic insertion into this triangle
itself is a different contribution and still needs its
fixed-parent transport. Both routes share the model,
conventions and numerical software.
