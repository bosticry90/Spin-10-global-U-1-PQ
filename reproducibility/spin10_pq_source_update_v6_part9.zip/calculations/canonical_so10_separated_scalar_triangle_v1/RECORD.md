# V954 pre-execution contract

Test the V949 mixed scalar triangle away from all
exterior collision surfaces. Freeze the light external
color, three literal scalar polarization pairs, compact
switches flat on separated test neighborhoods, free
Euclidean transverse and mixed Greens, and positive
scalar squared reference mass.

Compare the skew ordered triangle with the two-vertex
seagull and local supports. Test a nonzero mass response
on the same separated probe, using direct spectral and
Bessel derivative controls. Keep the independent switch
transfer in the numerator identity. No new physical
masses or finite weights adopted.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor, 8 MiB
artifact and 32 MiB packet. No authority change.
