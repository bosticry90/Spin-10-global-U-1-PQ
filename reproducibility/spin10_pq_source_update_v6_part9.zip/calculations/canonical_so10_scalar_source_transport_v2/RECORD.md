# V929 pre-execution contract

Test the scalar source replacement suggested by V928, with
the actual H-Casimir map K_H on the broken ghost colors.
Use the complete ordinary unmarked unit-switch source
projection, at fixed parameters and zero background. Compare
the actual forced Lambda x C coefficients before and after
the proposed driver for all ordered ghost/auxiliary colors
and scalar coordinates, rather than only x=v_s.

Independently test the off-shell scalar nilpotency condition
with an arbitrary common infinitesimal ghost bracket and
scalar conjugations. Check the common gauge derivative
condition on the scalar kinetic action. Use exact joined
structure and representation matrices with a separate
replay. Distinguish an isolated common normalization value
from a symbolic family. Also test a left-null condition for all
block-diagonal linear scalar sources in this auxiliary projection
and the scalar Casimir conjugation with a doubled gauge-fermion
companion. A failure concerns these ansatzes,
not arbitrary nonlinear source completions. No promotion.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.

## V2 continuation after the left-null sign check

The first native run rejected the sign of the imported left-null
witness. The literal signed matrix and the independent anticommutator
calculation give the opposite signs for both rows. The full failed
source and capture remain in the original packet. V2 fixes the
expected signs, keeps the exact nonzero gate and adds the separate
broken-ghost vector comparison. No effort or authority change.
