"""Check the full scalar-source residual and the common ghost bracket."""

from collections import defaultdict
import importlib.util
from itertools import product
import sys

import sympy as sp

from execute import PK, ROOT, run_worker


OWNER = ROOT/"calculations/canonical_so10_gauge_scalar_seagull_residue_v1/seagull_residue.py"
SPEC = importlib.util.spec_from_file_location("seagull_owner",OWNER)
seagull = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(seagull)
COLORS = range(45)


def empty():
    return defaultdict(lambda:sp.S.Zero)


def clean(z):
    return {i:sp.expand(value) for i,value in z.items() if sp.expand(value)}


def inputs(phase):
    role = "primary" if phase=="native" else "replay"
    root = ROOT/"calculations"
    raw = seagull.read(root/"canonical_so10_physical_current_input_recovery_g1_v1"/
                       ("native_v2_coefficients.json.gz" if phase=="native" else "replay_v4_coefficients.json.gz"))
    frame = seagull.read(PK/"frozen_a10_physical_reconciliation"/f"full_{role}.json")
    v = {i:sp.sympify(z) for i,_,z in frame["vacuum"]["VEV"]["entries"]}
    entries,rho = {},{}
    for a,rows in raw["rho"]:
        rho[a] = defaultdict(list)
        entries[a] = {}
        for i,j,cells in rows:
            z=seagull.unpack(cells)
            rho[a][j].append((i,z))
            entries[a][i,j]=z
    f = defaultdict(list)
    for (c,a,b),cells in raw["f"]:
        f[a,b].append((c,seagull.unpack(cells)))
    KH = defaultdict(empty)
    for h,a in product(range(12),range(12,45)):
        for (j,x),(c,y) in product(f[h,a],repeat=2):
            KH[c][j] += x*y
    K = {a:clean(KH[a]) for a in COLORS}

    rows = seagull.read(root/"canonical_so10_unprobed_compact_all_coupling_v1"/
                       f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    ghost = []
    for g,word,cells in rows:
        if g!=2 or len(word)!=4:
            continue
        a,b,c,j = [i for i,_ in word]
        if b>=180 or not (553<=c<598 and 598<=j<643) or a%4!=1:
            continue
        assert b%4==1 and all(not jets for _,jets in word)
        z=seagull.unpack([([0,*remaining],num,den) for remaining,num,den in cells])
        ghost.append((a//4,b//4,j-598,c-553,z))
    assert len(ghost)==13254
    return v,entries,rho,f,K,ghost


def act(rho,colors,x):
    z=empty()
    for a,value in colors.items():
        seagull.axpy(z,value,seagull.apply(rho[a],x))
    return clean(z)


def ghost_residuals(phase,v_all,rho,f,K,ghost):
    result = {}
    for name,(start,stop,_) in seagull.BLOCKS.items():
        v={i:z for i,z in v_all.items() if start<=i<stop}
        E={a:seagull.apply(rho[a],v) for a in COLORS}
        U={j:act(rho,K[j],v) for j in COLORS}
        # Raw signed Hessian from the C,a current density, with the
        # two possible BB Euler orders, evaluated on arbitrary x.
        port = {(a,b):seagull.apply(rho[b],E[a]) for a,b in product(COLORS,repeat=2)}
        Z = defaultdict(empty)
        for a,b,j,c,z in ghost:
            seagull.axpy(Z[j,c],-z,port[a,b])
            seagull.axpy(Z[j,c],-z,port[b,a])
        def casimir(vector):
            out=empty()
            for h in range(12):
                seagull.axpy(out,-1,seagull.apply(rho[h],seagull.apply(rho[h],vector)))
            return clean(out)

        assert not casimir(v)
        assert all(casimir(E[j])==U[j] for j in COLORS)
        total = 0
        witness = None
        for j,c in product(COLORS,repeat=2):
            R=seagull.apply(rho[c],U[j])
            H=act(rho,K[c],E[j])
            if phase=="native":
                # R and H above are the negatives of the actual x
                # coefficient, by skewness of the represented generators.
                residual=Z[j,c].copy()
                seagull.axpy(residual,1,R)
                seagull.axpy(residual,1,H)
                remainder=clean(residual)
            else:
                keys=Z[j,c].keys() | R.keys() | H.keys()
                remainder=clean({i:Z[j,c].get(i,0)+R.get(i,0)+H.get(i,0) for i in keys})
            assert seagull.dot(v,remainder)==0
            total+=len(remainder)
            if remainder and witness is None:
                i=min(remainder)
                witness=[j,c,i,str(remainder[i])]
        assert total and witness is not None

        # Any scalar-only linear source in this block has its
        # auxiliary row in the column space of the orbit matrix.
        left_null=(13,) if name=="Phi" else (17,22)
        c,i,expected=(17,27,-sp.S.One) if name=="Phi" else (13,172,sp.sqrt(30)/80)
        null_orbit=empty()
        required=empty()
        for j in left_null:
            seagull.axpy(null_orbit,1,E[j])
            seagull.axpy(required,1,Z[j,c])
            seagull.axpy(required,1,seagull.apply(rho[c],U[j]))
        assert not clean(null_orbit)
        assert sp.expand(required[i]-expected)==0
        # Independent sign control from the broken-ghost
        # anticommutator of the light and heavy generators.
        alternative=empty()
        for h,a in product(range(12),range(12,45)):
            coefficient=sum(z for j,z in f[h,a] if j in left_null)
            if not coefficient:
                continue
            seagull.axpy(alternative,coefficient,
                         seagull.apply(rho[h],seagull.apply(rho[a],E[c])))
            seagull.axpy(alternative,coefficient,
                         seagull.apply(rho[a],seagull.apply(rho[h],E[c])))
        assert clean(required)==clean(alternative)

        def canonical_remainder(j,c):
            rem=Z[j,c].copy()
            seagull.axpy(rem,-1,casimir(seagull.apply(rho[c],E[j])))
            seagull.axpy(rem,2,seagull.apply(rho[c],U[j]))
            return clean(rem)

        assert not canonical_remainder(17,17)
        diff=canonical_remainder(17,18)
        ix,target=(0,sp.sqrt(2)) if name=="Phi" else (264,21*sp.sqrt(15)/400)
        assert sp.expand(diff.get(ix,0)-target)==0
        result[name]={"vacuum_projection_zero":True,"nonzero_residuals":total,
                      "first_exact_witness":witness,
                      "linear_source_null_row":[list(left_null),c,i,str(expected)],
                      "canonical_off_diagonal":[17,18,ix,str(target)]}
    return result


def algebra(phase,entries,f,K):
    def bracket(left,right):
        out=empty()
        for a,x in left.items():
            for b,y in right.items():
                for c,z in f[a,b]:
                    out[c]+=x*y*z
        return clean(out)

    def on_colors(v):
        out=empty()
        for a,x in v.items():
            seagull.axpy(out,x,K[a])
        return clean(out)

    # A common infinitesimal bracket would have to absorb this
    # nonzero bilinear delta_K for every faithful scalar block.
    a,b={27:1},{17:1}
    out=empty()
    seagull.axpy(out,1,bracket(K[27],b))
    seagull.axpy(out,1,bracket(a,K[17]))
    seagull.axpy(out,-1,on_colors(bracket(a,b)))
    assert sp.expand(out[1]-sp.Rational(23,10))==0

    ranks={}
    for block,start,stop,index in (("Phi",0,54,12),("Sigma",54,306,70),("phi",306,326,2)):
        for a,b in product(COLORS,repeat=2):
            tr=sum(x*entries[b].get((i,j),0) for (i,j),x in entries[a].items()
                   if start<=i<stop and start<=j<stop)
            assert sp.expand(tr-index*int(a==b))==0
        ranks[block]=45

    ell,P,S=sp.symbols("ell P S")
    solution=sp.solve((P-S-ell,sp.Rational(6,5)*P-sp.Rational(34,25)*S),(P,S))
    assert solution=={P:17*ell/2,S:15*ell/2}
    return {"algebra":{"broken_pair_H1":str(sp.expand(out[1])),
                       "common_bracket_log_ratio":"17/15"},"driver_rank":ranks}


def check(phase):
    v,entries,rho,f,K,ghost=inputs(phase)
    return {"blocks":ghost_residuals(phase,v,rho,f,K,ghost)} | algebra(phase,entries,f,K)


if __name__=="__main__":
    run_worker(check,sys.argv[1])
