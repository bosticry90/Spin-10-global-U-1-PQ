# V929 result

The proposed scalar source cancels the V928 master coefficient
on both vacuum directions. It leaves nonzero ordinary
coefficients on the full scalar blocks. Exact left-null rows
of the orbit matrices also exclude any block-diagonal linear
scalar source alone from repairing the same full auxiliary
projection while the other terms remain fixed.

The off-shell scalar nilpotency test requires a common ghost
bracket proportional to the block source weights. The joined
broken-pair witness is nonzero. A common coefficient would
hold at most at one normalization value for the two active
blocks. Keeping the ordinary phi driver fixed excludes it
even there. The independent ordinary kinetic driver condition
has rank 45 in each nontrivial scalar representation.

A scalar H-Casimir conjugation with a doubled gauge-fermion
variation gives a closed orbit-level comparison. Its actual
ordinary ghost rows disagree off the vacuum, and it carries
kinetic, potential and other source terms. More generally,
fixing the Lambda x term for a linear scalar conjugation
A replaces the broken ghost coefficient by
[A^t,rho_c]E_j-rho_c U_j. The same exact left-null relations
annihilate its first term and give the observed obstruction
when the other ordinary and source partners are held fixed.

The first native run rejected imported left-null signs.
Its capture is preserved. V2 verifies the signed literal
rows and an independent anticommutator calculation.
Native and replay share the physical action and software.
No scientific authority change.
