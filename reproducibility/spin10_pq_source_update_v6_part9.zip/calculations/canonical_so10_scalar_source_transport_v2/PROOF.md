# Full scalar-source and nilpotency test

## Exact ordinary master comparison

Use the raw signed convention and V928 unit-switch patch. Write
E_j=rho_j v_s, U_j=(K_H E)_j, and let Z_(jc)(x) be the linear
ordinary scalar coefficient of the forced ghost term in units
-alpha_s g a_j C_c. K_H is the broken H-Casimir of V928,
extended by zero on the light colors. The proposed source
term is -epsilon_s g J_x.rho_(K_H C)x, where

    epsilon_s=(4/3)g²(2 C_s-8)L_s/C_s,
    alpha_s=g xi epsilon_s.

The source-first driver and the actual scalar–auxiliary
mixing imply that this term supplies -alpha_s g Lambda_j
C_c E_j.rho_(K_H c)x in the master. Thus the full tested
Lambda x C coefficient in common +alpha_s g units is

    Z_(jc)(x) - U_j.rho_c x - E_j.rho_(K_H c)x.

This is a linear functional of arbitrary x in the chosen
block. At x=v_s the three pieces are respectively 2 K_H G,
K_H G and G K_H, with G the scalar orbit Gram matrix.
H equivariance gives K_H G=G K_H. Hence the proposed
source cancels the V928 vacuum-direction witness.

For the full coefficient use all actual g2 BB a C rows
in one spatial component of V879. With row coefficient z
in current C,a order, the two raw Hessian terms give the
vector -z(rho_b E_a+rho_a E_b), using exactly the V928
density, ordering and metric signs. This replaces the
specialized vacuum Gram contraction by the complete
scalar vector. The required gauge-fermion term has vector
-rho_c U_j and the proposed scalar source has vector
-rho_(K_H c) E_j. Compare each of the 2,025 ordered
Lambda,ghost rows on the full scalar block. The nonzero
off-vacuum residuals are recorded in both routes.

There is a stronger linear-source control. For an arbitrary
block-diagonal source J_x.A_c x at this grade its contribution
to the Lambda row is E_j.A_c x, up to the common factor.
A left-null relation among the E_j therefore annihilates
every such contribution, even without skewness of A_c.
For Phi, E_13=0 while the needed coefficient
Z-U.rho_c x in row Lambda13,C17,x27 is -1.
For Sigma, E_17+E_22=0 while the same required sum at
C13,x172 is +sqrt(30)/80. This excludes repair of this
entire ordinary projection by any block-diagonal linear
scalar source alone, with the other terms held fixed.
An independent check of these vectors uses
P_j=sum_(h,a) f_(j h a){rho_h,rho_a}. For broken c the
ordinary ghost variation of the heavy gauge-fermion
cubic gives Z_jc with vector [P_j,rho_c]v_s. Since
P_j v_s=U_j, the required left-null vector is the
corresponding sum of P_j E_c. This reproduces both
literal rows and their signs.
Cross-block or nonminimal source changes are separate.

## Common gauge and ghost drivers

The proposed scalar driver also acts on the ordinary kinetic
action. At A=B=0 the first derivative term is
-g epsilon_s (partial x)^t rho_(K_H partial C)x in the raw
density. Skewness removes the term with both differentiated
scalar slots. A common gauge-driver change L partial C
contributes +g (partial x)^t rho_(L partial C)x from
the Bxx cubic. With the other ordinary derivative terms
fixed this requires rho_s(L C)=epsilon_s rho_s(K_H C)
for arbitrary C in each block. The exact generator trace
Gram matrices in Phi, Sigma and the ordinary phi block
are respectively 12 I, 70 I and 2 I. Thus the equation
has rank 45 on each ghost column and fixes the same
matrix L from every block. Leaving the nontrivial phi
driver fixed forces L=0. The proposed Phi and Sigma
coefficients cannot both be zero at distinct reference
masses.

The off-shell nilpotency comparison is independent of
that ordinary derivative test. Write the infinitesimal
scalar representation as rho_s((I+epsilon_s K_H)C),
and allow an additional scalar conjugation
[A_s,rho_s(C)]. Let b be an arbitrary common first-order
antisymmetric ghost bracket change. Nilpotency of the
antifield-linear scalar and ghost drivers requires

    rho_s(b(X,Y)) = epsilon_s rho_s(delta_K(X,Y)),
    delta_K(X,Y)=[K_H X,Y]+[X,K_H Y]-K_H[X,Y].

The scalar conjugation terms cancel by Jacobi, so they do
not change this condition for the proposed K_H rescaling.
The trace Gram test makes each displayed nontrivial
scalar representation faithful. The exact joined f
contraction gives delta_K(e27,e17)_1=23/10, so the common
bracket condition is nontrivial. Phi and Sigma force the
same epsilon only at L_Phi=(17/15)L_Sigma, namely
L_Phi=(17/2) log(M_Sigma/M_Phi) and
L_Sigma=(15/2) log(M_Sigma/M_Phi). This is at most
one value of the shared normalization constant, not
a common bracket on the symbolic family. If the
ordinary phi representation is kept fixed up to
conjugation, its faithfulness forces b=0 even there.
This excludes this particular off-shell ansatz. It
does not classify open-algebra antifield terms.

## A closed vacuum comparison and its limitation

Let A_s=-sum_(h in H)rho_h² on the scalar space. It is
symmetric, H equivariant, annihilates v_s and maps each
E_j to U_j. Thus the scalar conjugation
[A_s,rho_c] v_s= rho_(K_H c) v_s reproduces the source
orbit change with the original ghost bracket. Its full
canonical implementation uses x_old=(I-epsilon_s A_s)x
and the inverse evaluation dual for J_x. The ordinary
mixing contribution is then -alpha_s Lambda U.x.
Adding twice the gauge-fermion companion gives
+2 alpha_s Lambda U.x and the doubled ghost term.
The full canonical and gauge-fermion variations are
master-closed because they transport the original
action with its sources. On the vacuum direction they
reproduce the two V928 gauge-fixing coefficients.

That agreement is still only a projection. The full
ghost vector for the closed combination in the same
D units would be A_s rho_c E_j - 2 rho_c U_j. The
first term is the scalar conjugation of the actual
linear Y coefficient, whose vector is rho_c E_j.
The forced Z agrees with this expression in the
color-17 diagonal row but fails in row Lambda17,C18.
The actual residual at Phi x0 is sqrt(2) and at
Sigma x264 is 21 sqrt(15)/400. Moreover the closed
construction carries kinetic, potential and other
source terms that are not accounted for by the
fixed Q contact. Adding a closed variation alone
cannot change an existing nonzero master defect.
A full replacement comparison must include the
ordinary and source companions together.

This calculation rules out the tested scalar-only
repair and identifies a viable orbit-level canonical
comparison with an explicit off-vacuum remainder.
It does not rule out all gauge and nonminimal source
normalizations. Native and replay share the action,
joined frame and symbolic software. No parameter or
authority change.
