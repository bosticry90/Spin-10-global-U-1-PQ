# V964 pre-execution contract

Freeze the V963 light-center test and the HMM1, COS1 and
GQAP1 dictionaries. Check whether the existing heat-to-
causal conversion changes either weight in the selected
unit-switch scalar derivative projection. Verify actual
single-vertex kinetic support and the reference mixed
blocks through both exports. Keep the complete bare unit
master insertion before applying the one-vertex map.
Test the relative length term of a possible common
logarithmic core change algebraically. Do not install a
new normalization or assume the general extension.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority change.

V1 stopped at a structural equality between distributed and factored logarithms. Preserve its exact source, capture and preparation in the V1 D control. V2 compares the expanded difference to exact zero under the original conditions. Same limits and no scientific acceptance inferred from the failed run.

V2 also stopped because expand_log leaves log(6) unexpanded. A read-only symbolic diagnostic confirmed this behavior. Preserve the V2 source, capture and preparation in its D control. V3 uses exact simplification against the frozen log ratio. Same limits and acceptance requirements.
