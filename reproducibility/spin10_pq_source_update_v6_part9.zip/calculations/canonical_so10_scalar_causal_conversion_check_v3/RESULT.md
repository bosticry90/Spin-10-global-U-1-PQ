# V964 · Scalar causal conversion check

The existing heat-matched causal prescription retains the
relative `−ell log(3/2)` term. Its one-vertex `beta1`
dictionary cannot change the selected derivative `xx`
or `Bxx` terms. The complete bare unit master insertion
does not supply a one-vertex contact in this projection.

A common change of the selected logarithmic cores by
`ell log(c/4)` removes the relative length term and
preserves the selected compact transport. This is a
candidate for those cores. The general extension,
the broken-singlet scalar/ghost comparison and the
gauge and marked products remain separate.

The first two verifier attempts stopped on symbolic
logarithm form. Their sources and captures remain in
D control. The third version uses the same exact
logarithm condition with a canonical comparison.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
