"""Check the existing tadpole and logarithmic-core conversion on the scalar jet."""

import gzip
import json
from collections import Counter
import sys

import sympy as sp

from execute import ROOT, run_worker


def read_gz(path):
    with gzip.open(path) as stream:
        return json.load(stream)


def support(phase):
    prefix = "native_v2" if phase == "native" else "replay_v4"
    name = "native" if phase == "native" else "replay"
    folder = ROOT / "calculations/canonical_so10_physical_current_input_recovery_g1_v1"
    action = read_gz(folder / f"{prefix}_action.json.gz")
    def is_scalar(j):
        return 180 <= j < 508

    assert set(action) == {"S0_scalar","S1_scalar","S0_gauge","S1_gauge"}
    census = {}
    for key, (arity, scalars, derivatives) in (
        ("S0_scalar",(2,2,2)), ("S1_scalar",(3,2,1)),
        ("S0_gauge",(2,0,2)), ("S1_gauge",(3,0,1)),
    ):
        shapes = Counter()
        for word, _ in action[key]:
            assert all(0 <= index < 508 for index, _ in word)
            shape = len(word), sum(is_scalar(index) for index, _ in word), sum(len(d) for _, d in word)
            shapes[shape] += 1
        assert set(shapes) == {(arity, scalars, derivatives)}
        census[key] = shapes[arity, scalars, derivatives]
    folder = ROOT / "calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1"
    green = read_gz(folder / f"{name}_inverse.json.gz")["Greference"]
    assert all(is_scalar(i) == is_scalar(j) for i, j, _ in green)

    dx, Bx, g = sp.symbols("dx Bx g")
    orders = sp.Poly(sp.expand((dx+g*Bx)**2/2),g)
    assert orders.nth(2) == Bx**2/2 and not orders.nth(2).has(dx)
    return census


def core_map():
    ell, common, s, ds = sp.symbols("ell common s ds")
    b, t = (common-ell*sp.log(c) for c in (4,6))
    assert sp.simplify(t-b+ell*sp.log(sp.Rational(3,2))) == 0
    shifts = [ell*sp.log(sp.Rational(c,4)) for c in (4,6)]
    assert sp.simplify(t+shifts[1]-b-shifts[0]) == 0
    assert shifts[0] == 0 and shifts[1] != 0
    u = s*(1-s)
    ordinary = s**4
    reference = -s**3*(1-s)
    assert sp.expand((ordinary-reference)*shifts[1]-s**3*shifts[1]) == 0
    switch_pair = s**2*sp.diff(u,s)*ds-s*u*ds+s**3*ds
    assert sp.expand(switch_pair*shifts[1]) == 0
    assert sp.simplify((ordinary-reference)*shifts[1]-ordinary*shifts[1]) != 0


def check(phase):
    census = support(phase)
    core_map()
    return {"paired_kinetic_census":census,
            "free_scalar_mixed_block_zero":True,
            "existing_beta1_supports_selected_kinetic_or_cubic":False,
            "required_relative_core_shift":"ell*log(3/2)",
            "matched_core_shift_preserves_selected_compact_transport":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
