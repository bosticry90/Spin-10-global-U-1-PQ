# Existing causal dictionary and the scalar heat-length difference

HMM1 matches a rooted analytic extension to the actual
heat coefficient by adding its local shell difference.
In the leading logarithmic primitive the finite term
dependent on the length c is -ell log c, where ell is
the logarithmic residue with angular and graph factors.
The V963 pair has the same normalized ell and c=4,6.
The matching adds their measured difference. It does not
cancel that difference in the heat-matched COS1 cores.

GQAP1 then relates the heat and T1-normalized functionals
by Gamma_T,1=Gamma_heat,1-beta1(S). Here beta1 is the finite
one-vertex self-contraction, and its GF and source
projections vanish in the qualified CWB1 domain. Its
physical projection needs a separate support check.
At A=0 the scalar kinetic degrees are:

    arity two with two derivatives: free xx,
    arity three with one derivative: Bxx,
    arity four with zero derivatives: BBxx.

This follows from expanding (partial x+g rho_B x)^2/2.
Both V788 exports supply all quadratic and cubic rows.
For beta1, the free row leaves no scalar legs. The cubic
has either no mixed Bx contraction or leaves only B.
The quartic can leave xx only without derivatives. The
physical scalar potential has no derivatives, including
its PQ singlet. The pure vector and fermion terms cannot
leave two scalar legs with derivatives after one
contraction. A Bxx term with a derivative would require
a quintic single vertex, which the physical action does
not have. Thus beta1 changes neither the derivative xx
term nor the derivative Bxx term. The source projection
does not change the gauge or scalar drivers. An
undifferentiated xx term under the retained scalar
driver stays undifferentiated in xxC.

In the uncut unprobed family the full classical master
density is a divergence as in V879. The linear one-vertex
map commutes with integrated total derivatives since the
coincident contraction is translation invariant and
acts on each leg. Hence its action on the full unit
master insertion cannot provide an independent contact
in this comparison. This argument does not set the
switched master insertion to zero. It uses the complete
unit insertion before projecting, avoiding a spurious
tadpole from a selected summand.

Therefore the existing heat-matched COS1 prescription
and its GQAP1 T1 normalization leave the V963 isolated
unit difference. Adding beta1 back to the correction
dictionary restores the same heat expression, as in
GQAP1. Neither operation is a new relative finite
adjustment in this channel.

For a possible alternative log-core normalization, add
ell log(c/4) to every member of the selected core family.
This gives zero on the two-edge graph and ell log(3/2)
on the three-edge graph. The matched ordinary and paired
reference three-edge graphs receive the same change,
which preserves the selected plateau transport and
first-switch cancellation. The change removes the
light-center length difference in this slice. It is a
candidate finite change of the logarithmic extension.
Full HMM1 includes positive-j and power-sensitive terms,
and COS1 includes forests. No general contact map or
admissibility follows from the log primitive alone. The
broken-singlet equation still compares the scalar and
ghost finite values, and the separated nonlocal, gauge
and marked obligations remain. Both input routes share
the model, normalization premises and software.
