"""Check the local scalar potential carrier of the third-order residue."""

from collections import defaultdict
import gzip
import json
import sys

import sympy as sp

from execute import PK, ROOT, run_worker


def packet(name):
    return ROOT / "calculations" / f"canonical_so10_{name}"


def read(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == ".gz" else raw)


def unpack(cells):
    value = 0
    basis = (sp.sqrt(2), sp.sqrt(3), sp.sqrt(5), sp.sqrt(7), sp.I)
    for (g, xi, eta, mask), num, den in cells:
        assert (g, xi, eta) == (0, 0, 0)
        value += sp.Rational(num, den)*sp.prod(b for i,b in enumerate(basis) if mask & (1 << i))
    return value


def casimir_check(phase):
    role = "primary" if phase == "native" else "replay"
    coefficient_file = "native_v2_coefficients.json.gz" if phase == "native" else "replay_v4_coefficients.json.gz"
    data = read(packet("physical_current_input_recovery_g1_v1") / coefficient_file)
    frame = read(PK / "frozen_a10_physical_reconciliation" / f"full_{role}.json")
    vacuum = {x:sp.sympify(v) for x, _, v in frame["vacuum"]["VEV"]["entries"]}
    poles = read(packet("ghost_mass_g4_pole") / f"{role}_v2_result.json")
    orbit = {(k,x):sp.sympify(v) for k,x,v in poles["physical_E"]}
    rho_v, squared = (defaultdict(lambda:sp.S.Zero) for _ in range(2))
    for k, entries in data["rho"]:
        values = {(i,j):unpack(cells) for i,j,cells in entries}
        for (i,j), v in values.items():
            assert sp.expand(v+values.get((j,i),0)) == 0
            rho_v[k,i] += v*vacuum.get(j,0)
            if phase == "native":
                squared[i] += v*orbit.get((k,j),0)
            else:
                squared[j] -= v*orbit.get((k,i),0)
    for k in range(45):
        for i in range(328):
            assert sp.expand(rho_v[k,i]-orbit.get((k,i),0)) == 0
    values = {}
    for block, a, b, c in (("Phi",0,54,sp.Integer(10)),("Sigma",54,306,sp.Rational(25,2))):
        for i in range(a,b):
            assert sp.expand(squared[i]+c*vacuum.get(i,0)) == 0
        values[block] = str(c)
    assert all(sp.expand(squared[i]) == 0 for i in range(306,328))
    degrees = sorted(row["all_arities"][0][0] for row in data["potential_scope"])
    assert degrees == [2]*4+[3]*3+[4]*22
    return {"casimir":values,"potential_terms_by_degree":{"2":4,"3":3,"4":22},
            "orbit_checks":45*328}


def radial_check():
    z,M,N,d = sp.symbols("z M N d")
    # z=1/q². The sign of the stripped Bxx–M coefficient is fixed by
    # V882's +2 M L(M) residue, with the two starting field types kept.
    radial = z/(1+M*z)
    tadpole_log = sp.series(-2*radial,z,0,3).removeO().coeff(z,2)
    inserted_log = sp.series(-2*sp.diff(radial,M)*d,z,0,3).removeO().coeff(z,2)
    mixed_log = sp.series(-2*z**2/((1+M*z)*(1+N*z)),z,0,3).removeO().coeff(z,2)
    assert tadpole_log == 2*M and inserted_log == 2*d and mixed_log == -2
    # The physical variation -d*x²/2 has Hessian -d, not +d.
    assert mixed_log*(-d) == inserted_log
    return {"radial":{"tadpole_log_weight":"2*M","physical_mass_insertion_log_weight":"2*d",
                      "residue_multiplier_of_hessian_form":"-2"}}


def invariant_control():
    x1,x2,y1,y2,v1,v2 = sp.symbols("x1 x2 y1 y2 v1 v2")
    x = sp.Matrix([x1,x2,y1,y2])
    F = (x1*y1+x2*y2)**2
    orbit_x = sp.Matrix([-x2,x1,-y2,y1])
    orbit_v = sp.Matrix([-v2,v1,0,0])
    v = sp.Matrix([v1,v2,0,0])
    hessian = sp.hessian(F,x)
    hessian_value = (orbit_x.T*hessian*orbit_v)[0]
    assert sp.expand(hessian_value - sum(sp.diff(F,k)*direction for k,direction in zip(x,v))) == 0
    omit_other_block = sp.Matrix([-x2,x1,0,0])
    assert sp.expand(((orbit_x-omit_other_block).T*hessian*orbit_v)[0]) != 0
    return {"mixed_orbit_control":"full identity; omitted block gives nonzero residual"}


def patch_control():
    t,u,Y,M,d,j = sp.symbols("t u Y M d j")
    root = (j+t*Y)/(M+t*d)
    corrected = t**2*u*Y - t**2*u*(M+t*d)*root
    expected = t**2*u*Y*(1-t)
    assert sp.cancel(corrected.subs(j,0)-expected) == 0
    assert sp.cancel(corrected-expected+t**2*u*j) == 0
    omitted = corrected+t**3*u*d*root
    assert sp.cancel(omitted.subs(j,0)-expected) != 0
    assert sp.cancel(omitted.subs(d,0).subs(j,0)-expected) == 0
    return {"constant_patch":{"all_mass_difference_coefficient":str(expected),
                              "fixed_linear_source_contact":"-t**2*u*j",
                              "omitting_third_order_mass_term_changes_answer":True}}


def check(phase):
    return casimir_check(phase) | radial_check() | invariant_control() | patch_control()


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
