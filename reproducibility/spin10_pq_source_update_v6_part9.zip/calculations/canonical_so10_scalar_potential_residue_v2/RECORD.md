# V919 pre-execution contract

Test the V918 alternative third-order local graph carrier for the
scalar potential translation. Reuse the actual Bxx vertex, scalar–
auxiliary mixing, free scalar/mixed ports and full invariant
nonderivative potential. Compare direct joined generator contraction
with the skew-adjoint route and the fixed V882 two-port hard residue.
Require the sign and normalization from mass differentiation before
hard subtraction, independent of the desired profile value.

Cover all scalar potential degrees and cross-block orbits structurally
using invariance, with mixed invariant and mass controls. At constant
switch check the combined potential/mass/ghost projection including
the physical-minus-reference degree. Keep actual reference masses
fixed, no inverse physical couplings and no new soft-loop assertion.
Test a scalar-potential component of a possible graph-supported
normalization. Remaining field/source/mark extensions stay open.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.

## V2 continuation after validation failure

The native and replay calculations agreed, but the final verifier
compared expression strings with different factor ordering. The
complete failed packet, native calculation, navigation and final
capture are preserved in the original D: control record and bound
by the SHA inventory. Compare the exact symbolic difference to
zero. The proof, calculation worker and scientific gates remain
identical. Repeat the bounded native and validation runs.
