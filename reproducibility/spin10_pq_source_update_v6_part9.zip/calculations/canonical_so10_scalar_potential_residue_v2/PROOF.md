# Third-order local residue for the scalar potential

## Actual cycle and its hard coefficient

Let F(x) be a nondifferentiated gauge-invariant scalar density
in the physical action, with its action sign. Include the
physical-minus-reference quadratic potential. Use the actual
V882 g partial(x) B rho x vertex and g xi Lambda E_s x_s vertex,
where E_{s,a}=rho_{s,a}v_s. Add the F vertex with two scalar
ports. Its third-order cycle has a B–Lambda edge and two scalar
edges, one in the block s of the mixing and one in the block t
of the kinetic vertex. Thus t need not equal s. In a proper
full-diagonal logarithmic residue the three compact vertex
switches multiply to sigma³.

At the leading large momentum symbol, the mixed propagator
has one momentum over q². The derivative on the internal
scalar in the kinetic vertex supplies the other momentum.
Their contraction has degree zero and is independent of the
vector width. The external-scalar derivative term lowers the
degree and does not enter this residue. The remaining radial
symbol is 1/[(q²+M_s)(q²+M_t)], where M_s,M_t denote squared
reference masses. Its log coefficient is one for every t.
In relative-coordinate counting the scalar edges have degree
two each, the mixed edge degree three, and the differentiated
port costs one, giving logarithmic degree eight on the full
two-relative-coordinate diagonal. No new derivative of the
external switch or residual field can enter its leading local
constant.

Fix the sign and two-start factor by the same kinetic–mixing
pair of V882. The stripped hard radial two-vertex coefficient
is -2/(q²+M_s) multiplying the color contraction. Its log
residue is +2 M_s. Insert the physical mass variation
F=-d x_s²/2 into that scalar line before taking the hard
coefficient. Differentiating the propagator gives the T3
sum with the same two cyclic orientations and yields +2d in
the log coefficient. This is a derivative of the hard residue.
The finite derivative of L(M_s) is not included. The Hessian
of F is -d I, so the T3 multiplier of the action Hessian is
-2. For a general Hessian the only change is the scalar
tensor inserted between the two scalar edges. Off-diagonal
blocks share the same Lorentz and Wick factors. This fixes
the normalization without fitting a ghost amplitude.

## Covariant form of the potential companion

Write rho_a on the full ordinary scalar space and embed v_s
in its block. With the action sign retained, the tensor in
this residue is

    sum_a D²F(x)[rho_a x, rho_a v_s].

Each actual invariant satisfies DF(x)[rho_a x]=0. Differentiate
this identity in the direction rho_a v_s at fixed a. The
Hessian expression is then -DF(x)[sum_a rho_a² v_s].
The joined matrices give sum_a rho_a² v_s=-C_s v_s,
C_Phi=10 and C_Sigma=25/2. The H rows have rho_a v_s=0, so
only the actual mixed propagator colors are needed. Sum the
kinetic scalar block t across every participating field of F.
Keeping only the s block in rho_a x is not justified for a
general mixed invariant. The omitted-block test on a symbolic
mixed invariant detects precisely that truncation.

Consequently the logarithmic T3 residue has the action
coefficient -2 C_s DF(x)[v_s] in the V882 units. A finite
local residue change by -(2 C_s-8)L_s/(2 C_s), with the same
coefficient for every nondifferentiated scalar Hessian carrier
in the cycle, supplies

    sigma³ g² xi (2 C_s-8) L_s DF(x)[v_s] = sigma³ D_(u_s) F.

The numbers in the denominator are numerical Casimirs. No
inverse physical coupling or mass occurs in the local
action. The inherited action invariance establishes the
identity for the complete nondifferentiated scalar potential,
including mixed invariants. The check uses the actual
4 quadratic, 3 cubic and 22 quartic interaction directions
without changing any parameter. This is a single linked
potential projection of a fixed-kernel change. Any other
vertices with the same contracted ports must be included
before qualifying a common causal normalization.

## Consequence for the local mass and ghost projection

On a constant switch patch sigma=t retain the V916 reference
mass tadpole at t² and add the physical-minus-reference mass
translation at t³ from the T3 residue. In one block their sum
is -t² u (M+t d)x. The original two-vertex ghost term is
+t² u Y, where Y denotes the ordered ghost-pair part of the
scalar Euler with its couplings included. The stationary
radial scalar derivative gives x=(j_x+tY)/(M+t d) at the
required source degree. Thus their combined connected change is

    t²(1-t) uY - t² u j_x.

This algebra is exact at every formal d degree on the
constant patch. In matrix form it simply uses the same
mass operator and its inverse, so it needs no commuting
mass matrices. The inverse is a tree inverse around the
fixed positive reference mass, not a local normalization
coefficient. Omitting the third-order mass term reproduces
a nonzero d-dependent error; the V918 full translation at
switch degree two also has a different off-unit coefficient.
At unit switch the potential part equals the canonical
potential translation, while the ordinary-source contact
still requires its separate transport.

This result supplies an actual local graph carrier for
the potential terms missing from the switch-degree-two
candidate. It does not determine the original causal loop
remainder at nonzero d or prove cancellation for a general
mass-dependent weak limit. The kinetic, gauge, source,
marked and background companions of the same fixed kernel
and the common normalization tests remain open. No new
loop integral or parameter adoption. Both executions share
the action, conventions, arithmetic software and analyst.
