# V919 result

The actual kinetic–scalar-auxiliary–potential cycle has a nonzero
logarithmic local residue at switch degree three. A fixed
reference-mass insertion determines its sign and factor from
the V882 kinetic pair. Differentiating the invariant potential
shows that the complete joined color tensor equals the scalar
translation, with the same factor for all potential terms and
all kinetic scalar blocks. The linked finite residue therefore
supplies the potential companion that the V918 T2 map lacked.

In the combined constant-patch correction, the third-order
physical-minus-reference mass term pairs with the second-order
reference tadpole to reconstruct the actual switched quadratic
operator. Its tree inverse cancels in the ghost contact at every
formal mass-difference degree. An ordinary linear-source term
remains and has its separate canonical transport. The previous
two-vertex-only candidate gives a different result away from
zero mass-difference degree.

This qualifies the scalar-potential projection of the new graph
carrier. The full extension to other kinetic and source
operators and the original causal remainder at nonzero mass
difference remain open. Both executions share the physical
input and symbolic conventions. No scientific authority change.

The initial final verifier rejected equivalent expression strings.
The failed packet is preserved. V2 verifies the same expression
by exact polynomial equality.
