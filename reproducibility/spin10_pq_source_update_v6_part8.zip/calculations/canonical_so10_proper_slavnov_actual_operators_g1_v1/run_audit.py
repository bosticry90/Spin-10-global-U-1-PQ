from pathlib import Path
from hashlib import sha256
import ast,json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/proper-slavnov-actual-operators-g1-v1-2026-11-07')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
assert not (O/'audit_preparation.json').exists()
assert (O/'late_capture_v2.json').exists()
for n in ['audit.py','run_audit.py','AUDIT_RECORD.md']:
 if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'audit_preparation.json',dict(sha256={p.relative_to(R).as_posix():digest(p) for p in O.iterdir() if p.is_file()},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'audit.py')]);dump(O/'audit_capture.json',cap);dump(C/'audit_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
