from pathlib import Path
from hashlib import sha256
import ast,gzip,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/proper-slavnov-actual-operators-g1-v1-2026-11-07')
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
role=sys.argv[1];assert role in ['native','replay'];assert not (O/(role+'_capture.json')).exists()
if not (O/'preparation.json').exists():
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='e348c143bc897a6587a83db0f5867b69bf4d137a'
 names=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V801.md','calculations/canonical_so10_proper_slavnov_source_chain_g1_v1/validation_receipt.json','calculations/canonical_so10_same_parent_slavnov_g1_recovery_v1/validation_receipt.json','calculations/canonical_so10_physical_current_input_recovery_g1_v1/physical_v2.py','calculations/canonical_so10_physical_current_input_recovery_g1_v1/physical_v4.py','calculations/canonical_so10_physical_current_input_recovery_g1_v1/validation_receipt_v3.json']
 # Use the actual owning receipt name, resolved before freeze below.
 if not (R/names[-1]).exists():names.pop()
 for rr,prefix in [('native','native_v2_'),('replay','replay_v4_')]:names+=['calculations/canonical_so10_new_physical_returning_inventory_g1_recovery_v1/'+rr+'_GF_common.json.gz','calculations/canonical_so10_full_current_inventory_g1_recovery_v1/'+rr+'_new_states.json.gz','calculations/canonical_so10_physical_current_input_recovery_g1_v1/'+prefix+'euler.json.gz']
 for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
 # This is classical operand copying only. K0/Ku/current members are NOT
 # included, used as coefficients or accessible in scientificworkers.
 for rr,prefix in [('native','native_v2_'),('replay','replay_v4_')]:
  common=load(R/('calculations/canonical_so10_new_physical_returning_inventory_g1_recovery_v1/'+rr+'_GF_common.json.gz'));states={k:common[k] for k in ['F0','E0']}
  for pr in [0,1]:states['Fu0_'+str(pr)]=common['probes'][pr]['source_first_Fu'];states['Eu0_'+str(pr)]=common['probes'][pr]['full_Eu']
  states.update(load(R/('calculations/canonical_so10_full_current_inventory_g1_recovery_v1/'+rr+'_new_states.json.gz')))
  phys=load(R/('calculations/canonical_so10_physical_current_input_recovery_g1_v1/'+prefix+'euler.json.gz'))
  packet=dict(states=states,physical={'P_E0':phys['E0'],'P_E1_gauge':phys['E1_B_gauge'],'P_E1_scalar':phys['E1_B_scalar']},physical_E1_x_not_computed_or_zeroed=True,contains_only_classical_operands=True)
  blob=gzip.compress((json.dumps(packet,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
  with (O/(rr+'_inputs.json.gz')).open('xb') as h:h.write(blob)
 for n in ['RECORD.md','factory.py','run.py']:
  if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
  with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
 dump(O/'preparation.json',dict(base_HEAD=head,input_sha256={n:digest(R/n) for n in names},source_sha256={n:digest(O/n) for n in ['RECORD.md','factory.py','run.py']},operand_sha256={rr:digest(O/(rr+'_inputs.json.gz')) for rr in ['native','replay']},scientific_acceptance='NOT_PERFORMED'))
 C.mkdir(parents=True,exist_ok=False)
 with (C/'old_git_tree.txt').open('xb') as h:h.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'factory.py'),role]);dump(O/(role+'_capture.json'),cap);dump(C/(role+'_capture.json'),cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
