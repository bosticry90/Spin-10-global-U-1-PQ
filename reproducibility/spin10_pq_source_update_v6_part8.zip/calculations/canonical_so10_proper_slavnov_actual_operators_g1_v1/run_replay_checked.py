from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/proper-slavnov-actual-operators-g1-v1-2026-11-07')
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert not (O/'replay_capture.json').exists()
prep=json.loads((O/'preparation.json').read_bytes())
for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
for n,h in prep['source_sha256'].items():assert digest(O/n)==h,n
for role,h in prep['operand_sha256'].items():assert digest(O/(role+'_inputs.json.gz'))==h,role
name='calculations/canonical_so10_physical_current_input_recovery_g1_v1/validation_receipt.json';p=R/name
assert p.read_bytes()==subprocess.check_output(['git','show','HEAD:'+name],cwd=R) and json.loads(p.read_bytes())['evidence_validation'].startswith('PASS')
for n in ['OPERAND_REVIEW.md','run_replay_checked.py']:
 if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
dump(O/'replay_preparation_checked.json',dict(sha256={name:digest(p),**{(O/n).relative_to(R).as_posix():digest(O/n) for n in ['preparation.json','OPERAND_REVIEW.md','run_replay_checked.py','factory.py','native_inputs.json.gz','replay_inputs.json.gz']}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'factory.py'),'replay']);dump(O/'replay_capture.json',cap);dump(C/'replay_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
