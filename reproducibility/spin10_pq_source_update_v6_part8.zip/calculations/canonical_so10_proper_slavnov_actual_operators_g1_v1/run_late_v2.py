from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/proper-slavnov-actual-operators-g1-v1-2026-11-07')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
assert not (O/'late_preparation_v2.json').exists()
names=[]
for folder,prefix,suffix in [('canonical_so10_new_physical_returning_inventory_g1_recovery_v1','','GF_common'),('canonical_so10_full_current_inventory_g1_recovery_v1','','assembled_GF_kernels'),('canonical_so10_physical_current_input_recovery_g1_v1','v','marked_kernels')]:
 folder='calculations/'+folder;names.append(folder+'/validation_receipt.json')
 for role in ['native','replay']:
  n=role+('_v2_' if role=='native' else '_v4_')+suffix if prefix else role+'_'+suffix
  names.append(folder+'/'+n+'.json.gz')
for n in names:
 assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
 if n.endswith('receipt.json'):assert json.loads((R/n).read_bytes())['evidence_validation'].startswith('PASS')
for i in range(0,len(names),3):assert (R/names[i+1]).read_bytes()==(R/names[i+2]).read_bytes()
for n in ['late_compare_v2.py','run_late_v2.py','LATE_CONTINUATION_V2.md']:
 if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
own=[p for p in O.iterdir() if p.is_file()]
dump(O/'late_preparation_v2.json',dict(sha256={**{n:digest(R/n) for n in names},**{p.relative_to(R).as_posix():digest(p) for p in own}},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'late_compare_v2.py')]);dump(O/'late_capture_v2.json',cap);dump(C/'late_capture_v2.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
