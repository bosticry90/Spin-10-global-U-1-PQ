from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/proper-slavnov-actual-operators-g1-v1-2026-11-07')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
assert not (O/'final_preparation.json').exists() and not (O/'e4_capture.json').exists()
for n in ['FINAL_RECORD_V2.md','final_review_v2.py','run_final_v2.py','RESULT.md','PROOF.md']:
 if n.endswith('.py'):ast.parse((O/n).read_bytes().decode('utf-8'))
 with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
names=['calculations/canonical_so10_chiral_probe_support/'+n for n in ['validation_receipt.json','DERIVATION.md','RESULT.md','primary_tables.json.gz','replay_tables.json.gz']]
for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V802.md']+[R/n for n in names]
dump(O/'final_preparation.json',dict(sha256={p.relative_to(R).as_posix():digest(p) for p in files},scientific_acceptance='NOT_PERFORMED'))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'final_review_v2.py')]);dump(O/'final_capture.json',cap);dump(C/'final_capture.json',cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
