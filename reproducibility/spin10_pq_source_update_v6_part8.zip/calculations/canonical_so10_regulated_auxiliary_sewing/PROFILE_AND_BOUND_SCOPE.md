# Scope of the zero extension and its analytic review

The common central profile in PROOF applies to the retained massless
vector/auxiliary edges in this two-source kernel. Scalar/matter tree
contributions are excluded through intrinsic1 by the actual support
audit; the statement is not that every massive/chiral reference edge
of the full theory has the same profile.

The finite-epsilon objects are the already used free-edge coefficient
PROOF approximants. The direct tree expansion uses F=chi^2 E on every
retained free edge and therefore retains its inverse-response/profile
defects. It does not assume G_epsilon H=1-G_epsilon R_t or declare a new
finite-epsilon physical action. At A0 the retained central profiles and
sector projectors commute. Nonconstant background/source-dependent
regulators require their own matching terms and are not qualified here.

The analytic majorant is an explicit argument in PROOF. The scripts
verify model coefficients, momentum identities, integral controls and
assumption-sensitive falsifiers. A string check or a successful execution
is not a machine proof of functional analysis. No formal proof assistant
or independent scientist is being claimed.

An alternative UV estimate uses the exact Duhamel representation

 (1-e^(-t q^2))^2 = t^2 q^4 integral_[0,1]^2 e^(-t(s+r)q^2) ds dr.

The Gaussian factors and fixed weighted Schwartz seminorms dominate the
entire external convolution after one derivative; this gives the same
t^2 estimate. For the IR difference, explicit Gaussian scaling of
epsilon^-1(1+|q|/epsilon)e^(-c q^2/epsilon^2)/|p-q| gives epsilon^2.
Near/far splitting proves the scaled convolution uniformly finite.

Evenness and finite tadpole normalization are substantive hypotheses.
For a derivative-Gaussian source, the actual kernel has a nonzero dipole
coefficient at fixed heat. A shifted, non-even delta mollifier extracts
a term proportional to 1/sigma; that is outside the Lorentz-even class.
A fictitious t^-2 tadpole coefficient could also defeat the t^2 bound.
Neither is silently accepted: actual A_0 is finite, and the bare auxiliary
coefficient is zero. The omitted four Legendre terms may contain different
loop scaling and need independent subtraction/domain proofs.
