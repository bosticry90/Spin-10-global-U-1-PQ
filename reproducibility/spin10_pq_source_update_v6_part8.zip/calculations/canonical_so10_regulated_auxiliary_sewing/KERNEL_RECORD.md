# RAS2: complete projected tree kernel from actual Euler vertices

RAS1 completed8.869987s and whole primary/replay factorization agrees.
For each supported sector the actual free coefficients are
K_D=i,K_Lambda=Omega/2,K_J=-i,
L_D=-Omega/2,L_Lambda=i Omega^2/4,L_J=Omega/2.
Broken K_BB=F_BB,L_BB=i xi F_BB/2; unbroken BB maps vanish.
These are measured identities, not fitted finite normalizations.

Also test the resulting whole vector/source identity
QG|x=0 = sum_sector(F_B +Omega Lambda/2-iJa)^2, including the quartic
vector and source-only terms. If valid it explains the heat-difference
structure through the action, rather than only a selected kernel.

Derive the projected two-Ja auxiliary response from the actual QG and
Lambda F_BB action, using complete independent four-momenta k,l,p=k+l.
Compare Euler/IBP vertices with independent raw density removal using
outgoing -p. Retain source derivative jets and both source placements.
Keep the inverse-u root contribution until its full invariant projection
is checked. Verify the Yang--Mills longitudinal contraction and all
scalar/matter exclusions needed through intrinsic0/1. Source-only JaJa
contacts stay in the action despite zero field derivative here.

Proposed reduction to test, NOT accepted before comparison:
only the broken probe and nY can be nonzero. Let C_ij be the actual
projected B-root Hessian of F_BB; C must be measured, not invented.
The candidate kernel is

 2 E_p C_ij/p^2 * [ (1-E_k)^2 E_l (p.l)/l^2
                         -(1-E_l)^2 E_k (p.k)/k^2 ].

Require full coefficient equality in all8 momentum components and every
ordered source pair, with exact zero complements. Check source exchange,
nonzero finite heat, no scale/coupling choice, and sensitive omission
controls. A failure retains its exact remainder. Do not infer p=0 value
from an off0 formula or discard the pole as a finite-momentum artifact.

Then analyze independent Gaussian Schwartz sources as a controlled
nonzero finite-heat diagnostic and prove the general-source bound needed
for the prescribed UV-first/IR-last limit. Distinguish existing free-edge
IR proof approximants and inverse defects from a new physical Gaussian
regulator. A limit for this finite A_0 term does not supply the rest of
the connected/QAP/measure construction. Native300/review180s,8GiB sampled,
350MiB launch,16MiB packet and all original acceptance conditions unchanged.
