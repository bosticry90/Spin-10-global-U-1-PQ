# Actual finite auxiliary tadpole sewing in the regulated source problem

RAS1--4 derives the actual two-Ja auxiliary response and constructs a
zero extension for its finite A_0 tadpole term in the prescribed UV-first,
free-edge-IR coefficient family. The finite-heat response is generally
NONZERO. Both facts are retained and justified separately.

The two finite tadpole coefficients remain unfixed. The other four
Legendre terms, full connected Ward/QAP, E5/A5 and physical unification
are not qualified. Authority remains state113/34of39.

## Actual result

At base23ba3f70/main the same unshifted SMA/CSW/EDS,A0,constantu,rho0
after operation,both probes,intrinsic0/1,positive scalar REFERENCE masses
and independently Schwartz-smeared sources are retained. The target is
the zero-j even-source two-Ja auxiliary term; it does not replace the
entire90-source or arbitrary-mean connected construction.

The actual K/L maps factor by H/M sectors. In the vector restriction,

    QG=sum_sector Z_r^2,
    Z_r=i div B_r+F_BB,r+Omega_r Lambda_r/2-i Ja_r.

The comparison includes252/34801 complete vector/source density positions,
including quartic vectors and source-only contacts12/33. A separate
full-plane square diagnostic also has zero remainder through intrinsic1.
The actual scalar/matter support is audited before excluding it from this
auxiliary tree response; no BBx term or single scalar crossing can close
the required intrinsic0/1 tree.

The first source mean responses derived from the original source-dependent
quadratic action are

    div B_i=E_q h_i-u Omega E_q(1-E_q)P_sector h_i,
    Lambda_i=2i u E_q(1-E_q)P_sector h_i.

Together with the original vertices, the effective auxiliary insertion
is -2i(1-E_q)^2, not just one heat difference. Source/inverse terms cannot
be dropped independently.

Let C_ij be the measured B-root derivative of F_BB projected on the
inherited invariant covector nY. It has56 antisymmetric nonzero ordered
M-source pairs; e12 has zero matrix. The nY basis is inherited from the
adjoint constraint, not a newly selected physical U(1) coupling convention.
For example C_13,14=2sqrt(3)i g10/5; every coefficient and zero is used.

Only the broken-probe/nY response can be nonzero:

 L_ij,t(p;k,l)=2E_p C_ij/p^2 *
   [(1-E_k)^2 E_l (p.l)/l^2-(1-E_l)^2 E_k (p.k)/k^2], p=k+l.

The other three probe/invariant channels vanish. All2025 ordered source
pairs are checked per channel, with all8 independent momentum components.
The8960 numerator coefficient positions in the nonzero channel agree
between Euler/IBP and direct raw density variation at root momentum -p.
Source exchange is symmetric. The projected inverse-root group is zero
only after its complete contraction. Omission of the actual source terms
or the first auxiliary mean response changes all56 nonzero pairs.

The longitudinal Yang--Mills force itself is nonzero, but its auxiliary
root contraction is exactly zero. Review checks the full trilinear Lorentz
vertex; it does not delete a generic three-vector amplitude.

## Nonzero fixed heat; controlled renormalized limit

For fixed t the response generally has an off0 dipole near total momentum0.
Independent Gaussian Schwartz profiles with widths a,b give

 C_ij(a-b)/(16pi^2) *
 [1/(a+b+t)^2-2/(a+b+2t)^2+1/(a+b+3t)^2]

at p0 after their convolution. At a=1,b=2,t=1 the value normalized by
C_ij/(16pi^2) is -37/3600. This is an external-source diagnostic, not a
chosen physical coupling or a new quantum-loop coefficient. A separate
Schwinger derivation agrees, as do two finite-p integral coordinates.
The fixed-heat even-mollifier path factors0,11/18,1 therefore multiply
an actual nonzero model-kernel value.

That does not establish a renormalized obstruction. The full source
convolution has the uniform bound derived in [PROOF](PROOF.md):

    |selected finite tadpole pairing| <= C(h,h')*(t^2+epsilon^2),

uniformly in the width of a normalized even tadpole mollifier. The key
global inequalities are (1-E_q)^2<=t^2|q|^4 and
|grad(1-E_q)^2|<=4t^2|q|^3. Differentiating on that source factor bounds
the ENTIRE unbounded momentum convolution by fixed Schwartz seminorms.
The IR difference is controlled by a Gaussian/Riesz convolution scaling
as epsilon^2. This is not a fixed-momentum suppression argument.

The unprobed bare auxiliary tadpole is already zero by the authenticated
ESM support theorem. The remaining A_0 tadpole coefficient is finite;
there is no unmeasured auxiliary UV power pole to insert into this estimate.
The prescribed UV finite part first,then IR removal consequently gives
ZERO for this finite auxiliary term, for arbitrary values of tY,t12 in
the allowed background-covariant finite class. No coefficient is set to0,
fitted,or identified with chi4,kappa,b0 or the separate IR normalization.

The existing free-edge proof approximants keep F=chi^2 E on every retained
vector/auxiliary edge. Their inverse/profile defects remain; the derivation
does not assert G_epsilon H=1-G_epsilon R_t. The exact scope and independent
analytic argument are in [PROFILE_AND_BOUND_SCOPE](PROFILE_AND_BOUND_SCOPE.md).
This constructs this auxiliary extension within the audited coefficient
family, not a new finite-epsilon physical action or general contact scheme.

## Focused result-to-claim assessment

**Evidence.** [Sector maps](structure_tables.json.gz), [complete momentum
kernel](kernel_tables.json.gz), [independent raw/limit review](validation_receipt_v2.json)
and [adversarial controls](adversarial_validation_receipt.json) own the new
calculations. ESM's bare zero, the actual action, the old adjoint space and
proper kernels are authenticated/reused, not re-run as new quantum evidence.
The analytic majorant is a supplied explicit proof, not machine-certified
functional analysis; script execution and string checks do not prove it.

**Supported claim.** A previously undefined selected auxiliary finite-tadpole
sewing term now has a common zero extension in the retained UV-first/
free-edge-IR and Lorentz-even approximation class. Its complete nonzero
fixed-heat kernel is measured and preserved. The distinction between those
two statements is essential to the result.

**Necessary limits.** A derivative-Gaussian source has a nonzero fixed-heat
dipole. A shifted,non-even delta mollifier extracts exp(-1)/sigma and breaks
the uniform bound. A fictitious t^-2 tadpole coefficient would also defeat
the t^2 limit. These controls are sensitive but outside the qualified class;
neither is adopted. The physical finite tadpole values remain arbitrary.

**Remaining gap.** The four other Legendre terms contain quantum loops and
their own source/contact variations. External Schwartz estimates here do
not bound an internal UV loop momentum. Complete proper power subtractions,
their transport through the same fixed-regulator mean, actual full-family
matching and joint momentum domains must still be demonstrated. Arbitrary
nonzero mean fields,odd/mixed sources,connected Slavnov variations,global
measure/phase,reality and causal/vacuum limits remain separate.

**Scientific/AI significance.** An actual action-level square identity and
full momentum reduction explain the kernel. A fixed-cutoff nonzero response
is shown compatible with a zero renormalized extension by a uniform bound,
rather than by dropping it. Shared action,data,software,reference assumptions
and AI authorship limit independence. No external scientist,proof assistant
or experiment validates the underlying physical hypothesis here.

**Next action.** Assemble the remaining connected two-source terms from the
qualified proper source derivatives and actual endpoint responses. Begin
with their complete scalar/mixed support and joint singular arrangements,
including the remaining finite-normalization jets. Derive the required
UV subtractions and IR bounds before the selected connected Ward test.
Do not transfer the present external-convolution bound to an unbounded
loop or automatically resume the295 vector coefficient profiles.

## Execution and failures

Structure8.8699870s,kernel4.9973977s,accepted reviewV2 5.9797948s,
adversarial review0.8909135s after imports. Native300s/review180s,8GiB
sampled private,350MiB launch floor,16MiB packet. Complete captures own
sparse memory observations, not continuous peaks.

ReviewV1 completed the whole raw-kernel comparison but FAILED comparing
equivalent symbolic expression trees in the Gaussian inversion. V2 requires
the exact simplified difference to vanish against the unchanged target.
All mathematical requirements,physical inputs and resources remain. Failed
source/copy/capture/controller are preserved; no original validation_receipt
is manufactured. Source/kernel native runs were unchanged.

E4once/no--fresh and final byte review precede local commit. Expected
native0,steps[0,0,0,0,0,2],historical custody2/seven unresolved NOTPASS.
Old files,contracts,receipts,policies and state remain unchanged. No agent,
new branch/worktree,push,outreach,publication,protected activation,physical
scheme/foundation adoption or scientific promotion. Goal ACTIVE/incomplete.
