# RAS1: regulated two-Ja auxiliary response and its finite tadpole sewing

Prospective at23ba3f70987c6b83eed52e652ef36988766f9a90/main. Preflight
clean/no matching workers; current AGENTS/highestV662/actual receipts read.
Previous goal turn PROGRESS: actual even-source action, bare auxiliary
zero and fixed-regulator response. Goal ACTIVE/incomplete; state113/
34of39,E5/A5 OPEN,custody2/seven NOTPASS unchanged. No agents,branch,
remote action,physical adoption,promotion or protected activation.

Question: what is the actual regulated second Ja response of Lambda
projected on nY and e12, and can its finite A_0 tadpole be sewn in the
prescribed UV-finite-part-THEN-IR order? Keep both finite coefficients
unfixed. A nonzero fixed-heat response is not automatically an obstruction;
its behavior under the REQUIRED limit order must be derived.

Same unshifted SMA/CSW/EDS,A0,constantu,rho0 after operation,bothprobes,
intrinsic0/1,independently Schwartz-smeared sources,positive scalar
REFERENCE masses. No physical vacuum,constant-source limit,normalization
choice or new IR profile. The first phase derives all actual vector/
auxiliary/source coefficient maps from ESM action tables, and tests a
collective reduction. If a proposed sector factorization fails, retain
the exact mismatch; never fit a coefficient. Source-only JaJa terms
remain in the action even though their field derivative vanishes.

Use independent routes: actual action/Euler momentum substitution versus
the complete mean-response/operator reduction. Keep all four derivative
directions and independent k,l,p=k+l. Verify any longitudinal Yang--Mills
or scalar/matter exclusion from actual action/support before using it.
Retain fixed-heat source, inverse and tree terms with their order.

Compute the finite-cutoff small-total-momentum kernel; distinguish an
off0 pole, its distributional extension, tadpole evaluation, and the
prescribed continuum limit. A generic delta counterexample does not
establish a model obstruction. Conversely, fixed-momentum heat suppression
cannot be used inside an unbounded integral without a majorant. Use full
Schwartz source labels, actual coupling orders and the bare auxiliary
zero to decide whether any UV power term remains. Retain an exact missing
zero-mode/contact condition if required. No tadpole coefficient set to0.

Target is this actual auxiliary connected contribution, not the complete
five-term connected Ward/QAP, all90-source products, arbitrary classical
means, multiple Slavnov insertions, measure/globalphase,physical vacuum
or viable GUT. Full original goal remains active. Frozen known-model
premises, independent-calculation shared data/software/AI limits and
focused result-to-claim assessment apply.

Native300s/review180s after imports,8GiB sampled private,350MiB available
pagefile launch,16MiB packet. Freeze every source/input before execution,
preserve full failures/incomplete states, versions and captures. Reuse
qualified ESM/CNS/NSP/physical action, no quantum loop replay. E4once/
no--fresh and old/raw Git-byte preservation before any local commit.
