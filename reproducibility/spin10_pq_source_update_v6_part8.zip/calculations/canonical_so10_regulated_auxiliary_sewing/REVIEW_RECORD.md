# RAS3: independent raw momentum vertices and analytic limit review

Before execution, bind the complete model kernels and the proof. Rebuild
the response by raw action-root removal with momentum -p, not JP.euler.
Use the original Lambda F_BB and QG densities from the other role.
Check whole k,l polynomial/ordered source-pair domains and zero complements.
Independently invert the actual longitudinal quadratic reference/source
action and its square deformation to test the first responses used by
both routes. Verify the Yang--Mills longitudinal contraction in all4
indices. Record which omission controls are insensitive in this projection.

Review the general-source UV/IR estimates, not merely Gaussian numerical
agreement. Derive the actual finite-heat Gaussian zero-momentum expression
by separate Schwinger integrals; check exact nonzero, t^2 behavior and
the fixed-heat mollifier path control. Do not call fixed-heat ambiguity
a renormalized obstruction or interchange the prescribed UV/IR order.
The new claim is one finite auxiliary term, not the other connected loops.

Review180s,8GiB sampled,350MiB launch,16MiB packet remain. All action,
coefficient/data/reference and AI-authorship shared limits remain explicit.
