from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import Counter
import gzip,json,os,sys,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'))
import jets as J
from coefficient_ring import expression,coefficient,g,xi,eta
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
data=load(R/'calculations/canonical_so10_even_source_mean_response/plane_tables_v2.json.gz')
tables=[];results=[]
def cols(rows):return {i:J.decode(z) for i,z in rows}
def count(poly):return Counter(tuple(sorted(('B' if i<180 else 'x' if i<508 else 'L' if i<553 else 'Ja' if i>=1241 else 'other') for i,js in w)) for w in poly)
for role in ['primary','replay']:
    for probe in [0,1]:
        row=next(z for z in data['routes'] if z['role']==role and z['probe']==probe)
        E=cols(row['E_Lambda']);K=cols(row['K']);L=cols(row['L'])
        widths={};Fbb={}
        for r,z in E.items():
            widths[r]=z.get(((508+r,()),),J.ZERO)
            Fbb[r]={w:c for w,c in z.items() if len(w)==2 and all(i<180 and not js for i,js in w)}
        free={};quadratic={};families={}
        for name,cc in [('K',K),('L',L)]:
            D={};A={};B={};Q={}
            for r,z in cc.items():
                for w,c in z.items():
                    if len(w)==1:
                        i,js=w[0]
                        if i<180:
                            assert js==(i%4,)
                            key=(r,i//4)
                            if key in D:assert D[key]==c
                            D[key]=c
                        elif 508<=i<553:
                            assert not js;A[r,i-508]=c
                        elif 1241<=i<1286:
                            assert not js;B[r,i-1241]=c
                    elif len(w)==2 and all(i<180 and not js for i,js in w):J.put(Q.setdefault(r,{}),w,c)
            ids=range(12) if probe==0 else range(12,45)
            constants=[]
            for label,mat in [('D',D),('A',A),('J',B)]:
                assert all(r==c and r in ids for r,c in mat),('FREE_MAP_NOT_SECTOR_DIAGONAL',probe,name,label)
                values={mat.get((r,r),J.ZERO) for r in ids};assert len(values)==1
                constants.append(next(iter(values)))
            free[name]={lab:str(c) for lab,c in zip(['D','A','J'],constants)}
            # Derive scalar factor only when all actual coefficients admit it;
            # keep zero tensors explicit and compare every source word.
            factor=None
            for r in range(45):
                if Fbb[r]:
                    for w,v in Fbb[r].items():
                        got=Q.get(r,{}).get(w,J.ZERO)
                        z=s.cancel(expression(got.terms)/expression(v.terms))
                        if factor is None:factor=z
                        assert s.cancel(z-factor)==0,('NONUNIFORM_QUADRATIC_FACTOR',probe,name,r,w)
            factor=s.Integer(0) if factor is None else factor
            factor_co=coefficient(factor)
            for r in range(45):
                expected={w:J.times(factor_co,v) for w,v in Fbb[r].items()};expected=J.clean(expected)
                assert J.clean(Q.get(r,{}))==expected,('WHOLE_QUADRATIC_MAP_MISMATCH',probe,name,r)
            quadratic[name]=str(factor);families[name]=[ [list(k),v] for k,v in sorted(sum((count(z) for z in cc.values()),Counter()).items())]
        basis=read(R/'calculations/canonical_so10_even_source_mean_response/tadpole_result_v2.json')['invariant_tadpole_basis']
        contractions=[]
        for which,vector in enumerate(basis):
            out={}
            for r,z in Fbb.items():
                for w,c in z.items():
                    for at,(i,js) in enumerate(w):
                        color,mu=divmod(i,4)
                        weight=coefficient(s.sympify(vector[color]))
                        # Here r remains auxiliary input; the projected root is
                        # the B leg, not the auxiliary output.
                        other,jets=(w[:at]+w[at+1:])[0]
                        key=(r,other,jets)
                        out[key]=out.get(key,J.ZERO)+J.times(c,weight)
            encoded=[[r,i,list(js),[[list(k),v.numerator,v.denominator] for k,v in c.terms]] for (r,i,js),c in sorted(out.items()) if c]
            contractions.append({'basis':which,'root_B_projection':encoded})
        tables.append({'role':role,'probe':probe,'free':free,'quadratic_factors':quadratic,
          'Fbb':[[r,J.encode(z)] for r,z in Fbb.items()], 'widths':[str(widths[r]) for r in range(45)],
          'root_contractions':contractions,'K_L_full_families':families})
        results.append({'role':role,'probe':probe,'free':free,'quadratic_factors':quadratic,
          'root_B_projected_positions':[len(x['root_B_projection']) for x in contractions],
          'QG_even_intrinsic_counts':[[k,v] for k,v in sorted(Counter(J.degree(w,4) for w in J.decode(row['even_QG'])).items())]})
        print('STAGE '+role+' '+str(probe)+' '+str(time.perf_counter()-tick),flush=True)
for probe in [0,1]:
    a,b=[z for z in tables if z['probe']==probe]
    assert {k:v for k,v in a.items() if k!='role'}=={k:v for k,v in b.items() if k!='role'}
blob=gzip.compress((json.dumps({'schema':'RAS1_ACTUAL_FACTOR_DATA','routes':tables},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
with(O/'structure_tables.json.gz').open('xb') as f:f.write(blob)
out={'schema':'RAS1_ACTUAL_SECTOR_FACTORIZATION','routes':results,'packed_sha256':sha256(blob).hexdigest(),
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED','full_auxiliary_sewing':'NOT_YET_TESTED'}
with(O/'structure_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
