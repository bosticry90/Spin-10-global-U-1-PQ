"""Sparse exact polynomial ring: 4k,4l,E_k,E_l,E_p; model coefficients separate."""
from fractions import Fraction
import jets as J
N=11;ZEROEXP=(0,)*N
def one(c=1):return {ZEROEXP:J.constant(c)} if isinstance(c,int) and c else {ZEROEXP:c} if c else {}
def var(i):
    k=[0]*N;k[i]=1;return {tuple(k):J.constant(1)}
def clean(p):return {k:c for k,c in p.items() if c}
def add(*pp):
    out={}
    for p in pp:
        for k,c in p.items():out[k]=out.get(k,J.ZERO)+c
    return clean(out)
def scale(p,c):return clean({k:J.times(v,c) for k,v in p.items()})
def mul(p,q):
    out={}
    for a,c in p.items():
        for b,d in q.items():
            k=tuple(x+y for x,y in zip(a,b));out[k]=out.get(k,J.ZERO)+J.times(c,d)
    return clean(out)
def product(*pp):
    out=one()
    for p in pp:out=mul(out,p)
    return out
def encode(p):return [[list(k),[[list(a),v.numerator,v.denominator] for a,v in c.terms]] for k,c in sorted(p.items())]
def decode(rows):return {tuple(k):J.Coeff([(tuple(a),Fraction(n,d)) for a,n,d in cc]) for k,cc in rows}
k=[var(i) for i in range(4)];l=[var(4+i) for i in range(4)];p=[add(a,b) for a,b in zip(k,l)]
Ek,El,Ep=[var(i) for i in [8,9,10]]
Ak=add(*(mul(a,a) for a in k));Al=add(*(mul(a,a) for a in l));P=add(*(mul(a,a) for a in p))
pk=add(*(mul(a,b) for a,b in zip(p,k)));pl=add(*(mul(a,b) for a,b in zip(p,l)))
def jet(poly,jets,which):
    for mu in jets:poly=scale(mul(poly,(k if which==0 else l)[mu]),J.I)
    return poly
def field(token,which,mode,probe,widths):
    i,js=token;mom=k if which==0 else l;heat=Ek if which==0 else El
    if i<180:
        color,mu=divmod(i,4);num=scale(mul(mom[mu],heat),-J.I);den=1
        if mode=='u':
            if (color<12)!=(probe==0):return None
            num=scale(product(mom[mu],heat,add(one(),scale(heat,J.constant(-1)))),J.times(J.I,widths[color]))
    elif 508<=i<553:
        if mode!='u' or ((i-508<12)!=(probe==0)):return None
        color=i-508;num=scale(mul(heat,add(one(),scale(heat,J.constant(-1)))),J.I*2);den=0
    elif 1241<=i<1286:
        if mode=='u':return None
        color=i-1241;num=one();den=0
    else:return None
    return color,jet(num,js,which),den
def two(poly,probe,widths,modes):
    # Returns coefficients with common external denominator k^2*l^2 removed.
    out={}
    for word,c in poly.items():
        if len(word)!=2:continue
        for swap in [False,True]:
            first,second=(word[1],word[0]) if swap else word
            for mode1,mode2 in modes:
                a=field(first,0,mode1,probe,widths);b=field(second,1,mode2,probe,widths)
                if a is None or b is None:continue
                i,A,da=a;j,B,db=b
                z=scale(mul(A,B),c)
                if not da:z=mul(z,Ak)
                if not db:z=mul(z,Al)
                out[i,j]=add(out.get((i,j),{}),z)
    return {key:z for key,z in out.items() if z}
def swap(p):
    return {tuple(key[4:8]+key[:4]+(key[9],key[8],key[10])):c for key,c in p.items()}
