from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import Counter
import gzip,json,os,sys,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'))
import jets as J
from coefficient_ring import coefficient,g,xi,eta
import momentum as M
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'kernel_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
data=load(R/'calculations/canonical_so10_even_source_mean_response/plane_tables_v2.json.gz')
structure=load(O/'structure_tables.json.gz')
basis=read(R/'calculations/canonical_so10_even_source_mean_response/tadpole_result_v2.json')['invariant_tadpole_basis']
co=lambda z:coefficient(s.sympify(z,locals={'g10':g,'xi':xi,'eta_H':eta}))
widths=[co(z) for z in structure['routes'][0]['widths']]
allowed=set(range(180))|set(range(508,553))|set(range(1241,1286))
def restrict(z):return {w:c for w,c in z.items() if all(i in allowed for i,js in w)}
def put(z,w,c):J.put(z,w,c)
def merge(out,tab,weight):
    for ij,z in tab.items():out[ij]=M.add(out.get(ij,{}),M.mul(weight,z))
groups=[];summary=[]
for probe in [0,1]:
    row=next(z for z in data['routes'] if z['role']=='primary' and z['probe']==probe)
    E={r:J.decode(z) for r,z in row['E_Lambda']};Q=J.decode(row['even_QG'])
    Qfield=restrict(Q);assert all(J.degree(w,4)==0 for w in Qfield)
    square={}
    for r in (range(12) if probe==0 else range(12,45)):
        Z=restrict(E[r]);J.put(Z,((508+r,()),),-J.times(widths[r],J.Coeff([((0,0,0,0),Fraction(1,2))])))
        J.add(square,J.mul(J.clean(Z),J.clean(Z)))
    assert J.clean(square)==Qfield,('WHOLE_VECTOR_SOURCE_SQUARE_IDENTITY_FAILED',probe)
    cub={w:c for w,c in Qfield.items() if len(w)==3}
    gf={}
    for r,z in E.items():
        for w,c in z.items():
            if len(w)==2 and all(i<180 for i,js in w):put(gf,((508+r,()),)+w,c)
    gf=J.clean(gf);dgf=J.euler(gf,set(range(180)));dq=J.euler(cub,set(range(180)))
    C={}
    roots=next(z['root_contractions'] for z in structure['routes'] if z['role']=='primary' and z['probe']==probe)
    for item in roots:
        which=item['basis'];raw={}
        for r,field,js,terms in item['root_B_projection']:
            assert not js;col,mu=divmod(field,4)
            c=J.Coeff([(tuple(k),Fraction(n,d)) for k,n,d in terms])
            if (r,col) in raw:assert raw[r,col]==c
            raw[r,col]=c
        assert all(raw.get((j,i),J.ZERO)==-c for (i,j),c in raw.items())
        C[which]=raw
    for which,vector in enumerate(basis):
        base_group={};u_group={};source_omission={};inverse_group={}
        for color,weight in enumerate(map(co,vector)):
            if not weight:continue
            for mu in range(4):
                w=M.scale(M.p[mu],-weight)
                merge(base_group,M.two(dgf.get(4*color+mu,{}),probe,widths,[('u','base'),('base','u')]),w)
                merge(u_group,M.two(dq.get(4*color+mu,{}),probe,widths,[('base','base')]),w)
                without_source={word:c for word,c in dq.get(4*color+mu,{}).items() if not any(i>=1241 for i,js in word)}
                merge(source_omission,M.two(without_source,probe,widths,[('base','base')]),w)
            if ((color<12)==(probe==0)):
                force=E.get(color,{})
                quad={w:c for w,c in force.items() if len(w)==2 and all(i<180 for i,js in w)}
                merge(inverse_group,M.two(quad,probe,widths,[('base','base')]),M.scale(M.mul(M.Ep,M.P),weight*2))
        total={}
        for tab in [base_group,u_group,inverse_group]:
            for ij,z in tab.items():total[ij]=M.add(total.get(ij,{}),z)
        total={ij:z for ij,z in total.items() if z}
        assert not any(inverse_group.values()),('INVARIANT_INVERSE_ROOT_NOT_ZERO',probe,which)
        candidate={}
        if probe==1 and which==0:
            h1=M.mul(M.add(M.one(),M.scale(M.Ek,J.constant(-1))),M.add(M.one(),M.scale(M.Ek,J.constant(-1))))
            h2=M.mul(M.add(M.one(),M.scale(M.El,J.constant(-1))),M.add(M.one(),M.scale(M.El,J.constant(-1))))
            common=M.add(M.product(h1,M.El,M.pl,M.Ak),M.scale(M.product(h2,M.Ek,M.pk,M.Al),J.constant(-1)))
            for ij,c in C[which].items():candidate[ij]=M.scale(common,c*2)
        assert total==candidate,('WHOLE_EIGHT_MOMENTUM_KERNEL_MISMATCH',probe,which,len(total),len(candidate))
        for ij,z in total.items():assert M.swap(total.get((ij[1],ij[0]),{}))==z
        bad={ij:M.add(base_group.get(ij,{}),source_omission.get(ij,{}),inverse_group.get(ij,{})) for ij in set(base_group)|set(source_omission)|set(inverse_group)}
        source_control=sum(M.add(z,M.scale(total.get(ij,{}),J.constant(-1)))!={} for ij,z in bad.items())
        base_control=sum(bool(z) for z in base_group.values())
        if total:assert source_control and base_control
        groups.append({'probe':probe,'invariant':which,'numerator':[[list(ij),M.encode(z)] for ij,z in sorted(total.items())],
          'base_auxiliary_response_group':[[list(ij),M.encode(z)] for ij,z in sorted(base_group.items()) if z],
          'actual_U_Euler_group':[[list(ij),M.encode(z)] for ij,z in sorted(u_group.items()) if z],
          'color_matrix':[[list(ij),str(c)] for ij,c in sorted(C[which].items())]})
        summary.append({'probe':probe,'invariant':which,'nonzero_ordered_source_pairs':len(total),
          'ordered_pair_domain':45*45,'omitted_source_group_sensitive_pairs':source_control,
          'omitted_base_auxiliary_response_sensitive_pairs':base_control,'projected_inverse_root_group_zero':True,
          'source_exchange_symmetric':True,'whole_vector_source_square_identity_positions':len(Qfield)})
        print('STAGE actual projected kernel '+str(probe)+' '+str(which)+' '+str(time.perf_counter()-tick),flush=True)
blob=gzip.compress((json.dumps({'schema':'RAS2_COMPLETE_MOMENTUM_KERNEL_DATA','groups':groups},sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())+len(blob)<16*1024**2
with(O/'kernel_tables.json.gz').open('xb') as f:f.write(blob)
out={'schema':'RAS2_ACTUAL_REGULATED_AUXILIARY_KERNEL','summary':summary,'packed_sha256':sha256(blob).hexdigest(),
 'elapsed_after_imports':time.perf_counter()-tick,'tadpole_zero_mode_and_continuum':'NOT_YET_QUALIFIED','scientific_acceptance':'NOT_PERFORMED'}
with(O/'kernel_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
