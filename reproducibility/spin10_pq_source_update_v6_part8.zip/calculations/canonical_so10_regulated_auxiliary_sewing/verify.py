from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import gzip,json,os,sys,threading,time
import sympy as s
import mpmath as mp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'))
import jets as J
from coefficient_ring import coefficient,g,xi,eta
import momentum as M
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'review_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
co=lambda z:coefficient(s.sympify(z,locals={'g10':g,'xi':xi,'eta_H':eta}))
data=load(R/'calculations/canonical_so10_even_source_mean_response/plane_tables_v2.json.gz')
structure=load(O/'structure_tables.json.gz');target=load(O/'kernel_tables.json.gz')
assert digest(O/'kernel_tables.json.gz')==read(O/'kernel_result.json')['packed_sha256']
basis=read(R/'calculations/canonical_so10_even_source_mean_response/tadpole_result_v2.json')['invariant_tadpole_basis']
widths=list(map(co,structure['routes'][0]['widths']))
allowed=set(range(180))|set(range(508,553))|set(range(1241,1286))
def restrict(z):return {w:c for w,c in z.items() if all(i in allowed for i,js in w)}
def merge(out,tab,weight):
    for ij,z in tab.items():out[ij]=M.add(out.get(ij,{}),M.mul(weight,z))
def raw_force(action,root):
    # Direct variation of density: attach outgoing momentum -p to its
    # removed field. No Euler total derivative is used in this route.
    out=[]
    for word,c in action.items():
        if len(word)!=3:continue
        for at,(i,js) in enumerate(word):
            if i!=root:continue
            factor=M.one(c)
            for mu in js:factor=M.scale(M.mul(factor,M.p[mu]),-J.I)
            out.append((word[:at]+word[at+1:],factor))
    return out
checks=[];full_square=[]
for probe in [0,1]:
    row=next(z for z in data['routes'] if z['role']=='replay' and z['probe']==probe)
    E={r:J.decode(z) for r,z in row['E_Lambda']};Q=J.decode(row['even_QG']);qvector=restrict(Q)
    gf={};fbb={}
    for r,z in E.items():
        fbb[r]={w:c for w,c in z.items() if len(w)==2 and all(i<180 for i,js in w)}
        for w,c in fbb[r].items():J.put(gf,((508+r,()),)+w,c)
    gf=J.clean(gf)
    # Record a stronger full-plane square test without assuming scalar
    # cancellation in the proof of the vector kernel.
    sq={}
    for r in (range(12) if probe==0 else range(12,45)):
        z=dict(E[r]);J.put(z,((508+r,()),),-J.times(widths[r],J.Coeff([((0,0,0,0),Fraction(1,2))])))
        J.add(sq,J.mul(J.clean(z),J.clean(z)))
    sq=J.clean({w:c for w,c in sq.items() if J.degree(w,4) in [0,1]})
    diff=dict(Q);J.add(diff,sq,-1);diff=J.clean(diff)
    full_square.append({'probe':probe,'full_intrinsic01_square_remainder_rows':len(diff)})
    # Verify the scalar parity condition used for the intrinsic1 exclusion.
    for w,c in Q.items():
        if J.degree(w,4)==1:assert sum(180<=i<508 for i,js in w)==1
    assert all(J.degree(w,4)==0 for w in qvector)
    for which,vector in enumerate(basis):
        total={};wrong_root={};projected_f={}
        for color,weight in enumerate(map(co,vector)):
            if not weight:continue
            for mu in range(4):
                root=4*color+mu
                for action,modes in [(gf,[('u','base'),('base','u')]),(qvector,[('base','base')])]:
                    for remaining,factor in raw_force(action,root):
                        tab=M.two({remaining:J.constant(1)},probe,widths,modes)
                        merge(total,tab,M.scale(M.mul(factor,M.p[mu]),-weight))
            if ((color<12)==(probe==0)):J.add(projected_f,fbb[color],weight)
        assert not J.clean(projected_f)
        total={ij:z for ij,z in total.items() if z}
        expected=next(z for z in target['groups'] if z['probe']==probe and z['invariant']==which)
        exact={tuple(ij):M.decode(poly) for ij,poly in expected['numerator']}
        assert total==exact,('RAW_DENSITY_MOMENTUM_REPLAY_MISMATCH',probe,which)
        checks.append({'probe':probe,'invariant':which,'all_ordered_pairs':2025,'nonzero_pairs':len(total),
          'raw_density_equals_Euler_full_polynomial':True,'projected_inverse_root_zero_rechecked':True})
        print('STAGE raw density replay '+str(probe)+' '+str(which)+' '+str(time.perf_counter()-tick),flush=True)

# Independent inversion of the actual quadratic action and its source-
# dependent square: checks the propagator first responses used by M.field.
y,la,j,e,om,u=s.symbols('y la j e om u')
S0=s.I*la*y+om*la**2/2-s.I*j*la;U=(s.I*(y-j)+om*la/2)**2
H0=s.hessian(S0,[y,la]);G0=H0.inv();assert G0==s.Matrix([[om,-s.I],[-s.I,0]])
at={y:e,la:0,j:1};response=-e*G0*s.Matrix([s.diff(U,z).subs(at) for z in [y,la]])
assert [s.factor(x) for x in response]==[-e*om*(1-e),2*s.I*e*(1-e)]
Gi=-e**2*G0*s.hessian(U,[y,la])*G0
assert s.simplify(Gi[1,1]+2*e**2)==0
assert s.diff(U,j,2)==-2

# Actual Yang--Mills trilinear Lorentz vertex with two longitudinal legs.
YM=[]
for mu in range(4):
    z={}
    for nu in range(4):
        for rho in range(4):
            vertex={}
            if mu==nu:vertex=M.add(vertex,M.scale(M.k[rho],J.constant(-2)),M.scale(M.l[rho],J.constant(-1)))
            if nu==rho:vertex=M.add(vertex,M.k[mu],M.scale(M.l[mu],J.constant(-1)))
            if rho==mu:vertex=M.add(vertex,M.k[nu],M.scale(M.l[nu],J.constant(2)))
            z=M.add(z,M.product(vertex,M.k[nu],M.l[rho]))
    YM.append(z)
assert not M.add(*(M.mul(M.p[mu],YM[mu]) for mu in range(4)))
assert any(YM),'Cubic force itself must not be declared zero'

# Exact external Gaussian convolution at zero total momentum. Independent
# Schwinger integration of each of the three Gaussian terms.
a,b,t=s.symbols('a b t',positive=True)
gaussian=(a-b)*(1/(a+b+t)**2-2/(a+b+2*t)**2+1/(a+b+3*t)**2)
schwinger=sum(c*((a+n*t)-(b+n*t))/(a+b+(n+1)*t)**2 for n,c in enumerate([1,-2,1]))
assert s.cancel(gaussian-schwinger)==0
assert gaussian.subs({a:1,b:2,t:1})==-s.Rational(37,3600)
assert s.simplify(s.limit(gaussian/t**2,t,0)-6*(a-b)/(a+b)**4)==0
r=s.symbols('r',positive=True);path=1-2/(1+r*r)**2+1/(1+2*r*r)**2
assert [s.limit(path,r,0),path.subs(r,1),s.limit(path,r,s.oo)]==[0,s.Rational(11,18),1]

# Nonzero finite-p source-convolution control in two Schwinger coordinates.
# It corroborates the analytic integral; it is not a new physical input.
mp.mp.dps=45;P2=mp.mpf('0.25');tt=mp.mpf(1);aa=mp.mpf(1);bb=mp.mpf(2)
def sch_int(alpha,d):
    return mp.quad(lambda v:alpha/(alpha+v)**3*mp.exp(-alpha*v/(alpha+v)*P2),[d,mp.inf])
def unit_int(alpha,d):
    return alpha*mp.exp(-alpha*P2)*mp.quad(lambda x:x*mp.exp(alpha**2*P2*x),[0,1/(alpha+d)])
v1=2*mp.exp(-tt*P2)*sum(c*(sch_int(aa+n*tt,bb+tt)-sch_int(bb+n*tt,aa+tt)) for n,c in enumerate([1,-2,1]))
v2=2*mp.exp(-tt*P2)*sum(c*(unit_int(aa+n*tt,bb+tt)-unit_int(bb+n*tt,aa+tt)) for n,c in enumerate([1,-2,1]))
assert abs(v1-v2)<mp.mpf('1e-40') and v1

# The general-source estimates are analytical, not inferred from quadrature:
# (1-e^-s)<=s, |grad A_t|<=4t^2|q|^3; the IR rescaling has degree4-1-1=2.
assert 4-1-1==2
proof=(O/'PROOF.md').read_text()
for phrase in ['||grad F_t||_infinity <= C(h,h\') t^2','C(t^2+epsilon^2)','not merely a generic counterexample',
               'No inverse defect is set to1','The other four Legendre terms contain quantum loops']:
    assert phrase in proof,phrase
assert read(R/'calculations/canonical_so10_even_source_mean_response/tadpole_result_v2.json')['bare_auxiliary_one_loop_trace']=='ZERO_BEFORE_INTEGRATION_ALL_FINITE_OLD_CONSTANT_CHAINS'
out={'schema':'RAS3_RAW_MOMENTUM_AND_AUXILIARY_EXTENSION_REVIEW','execution_state':'COMPLETED',
 'complete_raw_kernel_comparisons':checks,'full_plane_square_diagnostic':full_square,
 'first_mean_responses_independent_gaussian_inversion':True,'YM_longitudinal_projection_zero_not_full_vertex_zero':True,
 'gaussian_normalized_zero_momentum_value':'-37/3600 at a=1,b=2,t=1','gaussian_small_t_degree':2,
 'fixed_heat_mollifier_path_factors':['0','11/18','1'],
 'finite_p_gaussian_normalized_value':mp.nstr(v1,42),'two_Schwinger_coordinate_difference':mp.nstr(v1-v2,8),
 'general_source_auxiliary_tadpole_bound':'C*(t^2+epsilon^2), uniform in normalized even tadpole mollifier width',
 'finite_auxiliary_tadpole_extension':'ZERO_IN_PRESCRIBED_UV_FIRST_FREE_EDGE_IR_COEFFICIENT_FAMILY',
 'finite_tY_t12_set_or_fitted':False,'remaining_four_Legendre_terms_or_full_connected_Ward_QAP_E5_claim':False,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'validation_receipt.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
