from pathlib import Path
from hashlib import sha256
import gzip,json,os,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'adversarial_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
review=read(O/'validation_receipt_v2.json');assert review['execution_state']=='COMPLETED'
data=json.loads(gzip.decompress((O/'kernel_tables.json.gz').read_bytes()))
broken=next(z for z in data['groups'] if z['probe']==1 and z['invariant']==0)
witness=next(c for ij,c in broken['color_matrix'] if ij==[13,14]);g10=s.symbols('g10')
assert s.simplify(s.sympify(witness)-2*s.sqrt(3)*s.I*g10/5)==0
assert len(broken['numerator'])==56
x,u,v=s.symbols('x u v',positive=True)
duhamel=x*x*s.integrate(s.exp(-u*x),(u,0,1))*s.integrate(s.exp(-v*x),(v,0,1))
assert s.simplify(duhamel-(1-s.exp(-x))**2)==0
a,b,t=s.symbols('a b t',positive=True)
J=sum(c/(a+b+(n+1)*t)**2 for n,c in enumerate([1,-2,1]))
assert s.simplify(s.limit(J/t**2,t,0)-6/(a+b)**4)==0
assert J.subs({a:1,b:2,t:1})==s.Rational(37,3600)
# The actual derivative-Gaussian source produces
# Lambda(p) ~ -i C J/(16pi^2) * p0/p^2. A shifted Gaussian delta at
# p=sigma*e0 has pairing coefficient exp(-1)/sigma, obtained by the
# independent Schwinger coordinate z=1/(1+u).
z=s.symbols('z',positive=True)
shift=s.integrate(z*s.exp(z-1),(z,0,1));assert shift==s.exp(-1)
sigma=s.symbols('sigma',positive=True)
assert s.limit(shift/sigma,sigma,0)==s.oo
assert s.limit((a-b)*J/t**2,t,0)!=0
# Explicit uniform near/far bound for the scaled IR convolution:
# ||(1+r)e^-r^2||_infty<=2; integral is pi^2(1+3sqrt(pi)/4).
r=s.symbols('r',positive=True)
mass=2*s.pi**2*s.integrate((1+r)*s.exp(-r*r)*r**3,(r,0,s.oo))
assert s.simplify(mass-s.pi**2*(1+3*s.sqrt(s.pi)/4))==0
near=2*(2*s.pi**2)/3;bound=s.simplify(near+mass)
assert s.simplify(bound-s.pi**2*(s.Rational(7,3)+3*s.sqrt(s.pi)/4))==0
assert 4-1-1==2
out={'schema':'RAS4_ANALYTIC_ASSUMPTION_CONTROLS','execution_state':'COMPLETED',
 'actual_nonzero_color_witness':witness,'double_Duhamel_factor_verified':True,
 'derivative_Gaussian_dipole_coefficient':'-i*C_ij/(16pi^2) * sum_[n=0,1,2](1,-2,1)_n/(a+b+(n+1)t)^2',
 'non_even_shifted_mollifier_leading_factor':'exp(-1)/sigma; fails uniform zero-width bound at fixed t',
 'non_even_mollifier_negative_control_sensitive':True,
 'artificial_divergent_tadpole_t_minus2_control':'nonzero 6*(a-b)/(a+b)^4; excluded because actual A0 is finite and bare coefficient zero',
 'uniform_scaled_IR_convolution_bound':str(bound),'IR_scaling_degree':2,
 'analytic_majorant_is_explicit_human_readable_proof_not_script_certification':True,
 'auxiliary_extension_only_not_remaining_connected_terms':True,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'adversarial_validation_receipt.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
