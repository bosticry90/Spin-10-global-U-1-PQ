# RAS3 V2: compare symbolic Gaussian responses by exact difference

Review V1 completed all raw-density/full-polynomial kernel comparisons
and then failed at a structural expression comparison in the independent
two-variable Gaussian inversion. SymPy factors e-1 while the stated
target uses 1-e with an outside minus sign. The intended test is exact
algebraic equality, not identical expression trees.

V2 subtracts the unchanged target vector from the independently inverted
response, simplifies every component and requires the zero vector.
All original action, source signs, parameter domains, kernel coefficients,
negative controls, analytic conditions and resource bounds remain. This
does not substitute a numerical tolerance or weaken any scientific test.
Original verifier/source/capture/controller remain FAILED; no original
validation_receipt.json exists. Only the V2 receipt can own acceptance.
