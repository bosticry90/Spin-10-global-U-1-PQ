from pathlib import Path
from hashlib import sha256
import ast,gzip,json,os,subprocess,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/regulated-auxiliary-sewing-v1-2026-10-27')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
bindings={};preps=[]
for p in sorted(O.glob('*preparation*.json')):
    preps.append(p.name)
    for name,h in read(p)['input_sha256'].items():
        assert digest(Path(name))==h,(p.name,name)
        if name in bindings:assert bindings[name]==h
        bindings[name]=h
copies=list(O.glob('*.source.txt'))
for p in copies:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes(),p
for p in O.glob('*.py'):ast.parse(p.read_bytes())
for p in O.iterdir():
    if p.suffix in ['.py','.md','.txt']:assert all(z==z.rstrip(b' \t') for z in p.read_bytes().splitlines()),p
failed={'review_capture.json':'assert [s.factor(x) for x in response]'}
accepted={'structure_capture.json','kernel_capture.json','review_capture_v2.json','adversarial_capture.json','e4_capture.json'}
seen=set();samples={}
for p in sorted(O.glob('*capture*.json')):
    cap=read(p);seen.add(p.name)
    assert not cap['failed_or_incomplete_counted_as_PASS'] and cap['launch']['creation_after_observation']
    assert cap['launch']['memory']['available_pagefile']>=350*1024**2
    assert cap['all_resource_samples'] and all('query_error' not in x and 0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples'])
    samples[p.name]=max(x['private_bytes'] for x in cap['all_resource_samples'])
    if p.name in failed:
        assert cap['execution_state']=='FAILED' and cap['exit_code']!=0 and not cap['calculation_completed']
        assert failed[p.name] in cap['stdout_and_stderr']
    else:
        assert p.name in accepted and cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
assert seen==set(failed)|accepted
assert {p.name for p in O.glob('*controller_failure*.json')}=={'review_controller_failure.json'}
assert not(O/'validation_receipt.json').exists()
structure=read(O/'structure_result.json');kernel=read(O/'kernel_result.json');review=read(O/'validation_receipt_v2.json');adv=read(O/'adversarial_validation_receipt.json')
assert structure['elapsed_after_imports']<300 and kernel['elapsed_after_imports']<300
assert review['elapsed_after_imports']<180 and adv['elapsed_after_imports']<180
assert digest(O/'kernel_tables.json.gz')==kernel['packed_sha256']
assert digest(O/'structure_tables.json.gz')==structure['packed_sha256']
assert [x['nonzero_ordered_source_pairs'] for x in kernel['summary']]==[0,0,56,0]
assert all(x['ordered_pair_domain']==2025 and x['source_exchange_symmetric'] for x in kernel['summary'])
assert kernel['summary'][2]['omitted_source_group_sensitive_pairs']==56
assert kernel['summary'][2]['omitted_base_auxiliary_response_sensitive_pairs']==56
assert all(x['raw_density_equals_Euler_full_polynomial'] for x in review['complete_raw_kernel_comparisons'])
assert [x['nonzero_pairs'] for x in review['complete_raw_kernel_comparisons']]==[0,0,56,0]
assert all(x['full_intrinsic01_square_remainder_rows']==0 for x in review['full_plane_square_diagnostic'])
assert review['gaussian_normalized_zero_momentum_value'].startswith('-37/3600') and review['gaussian_small_t_degree']==2
assert review['finite_auxiliary_tadpole_extension']=='ZERO_IN_PRESCRIBED_UV_FIRST_FREE_EDGE_IR_COEFFICIENT_FAMILY'
assert not review['finite_tY_t12_set_or_fitted'] and not review['remaining_four_Legendre_terms_or_full_connected_Ward_QAP_E5_claim']
assert adv['non_even_mollifier_negative_control_sensitive'] and adv['analytic_majorant_is_explicit_human_readable_proof_not_script_certification']
assert adv['auxiliary_extension_only_not_remaining_connected_terms']
assert 'Focused result-to-claim assessment' in (O/'RESULT.md').read_text()
events=read(O/'e4_events.json');steps=[x for x in events if x['event']=='step_finished'];exits=[x['exit_code'] for x in steps]
assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested']
assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout'] and read(O/'e4_capture.json')['elapsed_seconds']<300
git=lambda *args:subprocess.run(['git',*args],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()=='23ba3f70987c6b83eed52e652ef36988766f9a90'
assert git('branch','--show-current').decode().strip()=='main'
assert git('ls-tree','-r','--full-tree','HEAD')==(C/'old_git_tree.txt').read_bytes();git('diff','--quiet','HEAD','--')
state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
size=sum(p.stat().st_size for p in O.rglob('*') if p.is_file());assert size<16*1024**2
out={'schema':'RAS_FINAL_EVIDENCE_REVIEW','evidence_validation':'PASS_BOUNDED_ACTUAL_AUXILIARY_KERNEL_AND_FINITE_TADPOLE_EXTENSION',
 'preparations':preps,'input_bindings_authenticated':len(bindings),'source_copies_equal':len(copies),
 'accepted_completed_captures':sorted(accepted),'failed_captures_preserved':sorted(failed),
 'complete_actual_kernel_and_source_zero_complements_qualified':True,
 'selected_finite_auxiliary_tadpole_extension':'ZERO_UV_FIRST_AUDITED_FREE_EDGE_IR_AND_EVEN_MOLLIFIER_CLASS',
 'tY_t12_unfixed':True,'nonzero_fixed_heat_response_preserved':True,
 'analytic_estimates_explicit_not_formal_assistant_certified':True,
 'remaining_four_connected_terms_QAP_E5_physical_claim':False,
 'E4_step_exits':exits,'custody':'EXIT2_SEVEN_UNRESOLVED_NOTPASS','state_sha256':state,
 'old_tracked_tree_and_state_unchanged':True,'largest_accepted_worker_private_sample':max(samples[p] for p in accepted),
 'largest_all_captures_private_sample':max(samples.values()),'packet_bytes_before_final_capture_and_seal':size,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'final_review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
