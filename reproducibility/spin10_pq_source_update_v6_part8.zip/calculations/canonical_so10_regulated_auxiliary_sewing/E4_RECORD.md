# Delegated E4 preservation check

Run python -B tools/research_check.py e4 once,without --fresh. Expected
native0,steps0,0,0,0,0,2,terminal COMPLETED,custody seven unresolved NOTPASS.
Bind current policy/state and capture all output/resource observations.
No new scientific replay or authority promotion. Bound300s,8GiB sampled,
350MiB available-pagefile launch. Preserve unexpected results explicitly.
