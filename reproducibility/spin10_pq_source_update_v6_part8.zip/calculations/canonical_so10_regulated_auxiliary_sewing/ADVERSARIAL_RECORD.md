# RAS4: assumption-sensitive analytic controls

Use the completed raw/Euler equality and actual nonzero C_13,14. Verify
the double-Duhamel UV factor, the Schwinger zero-momentum control and its
t^2 limit by distinct integral representations. For independent Gaussian
and derivative-Gaussian Schwartz directions derive the actual dipole
coefficient. A shifted delta mollifier must fail the evenness cancellation;
a divergent artificial t^-2 coefficient must fail the finite-normalization
condition. These are negative controls, not permitted physical changes.

Retain the analytic epsilon^2 near/far-convolution proof. Checks do not
constitute a machine-checked analytic theorem. Reuse existing epistemic
ladder and disclose common action/coefficient software/AI authorship.
Review180s,8GiB sampled,350MiB launch,16MiB packet; exact captures and
failure classifications preserved. No new quantum integration.
