# V973 · Regulator profile comparison at the cubic switch power

The grade-one mixed/ghost and Maxwell regulator roots
with one mixed inverse insertion cancel all four
selected V970 weight columns at `s³∂s`. The resulting
rank is zero with separate H and M profiles, matched
within each quartet.

Both action exports reproduce the zero columns.
Omitting the Maxwell or mixed/ghost family leaves
2,340 or 2,262 positions, respectively. The check
keeps the actual auxiliary mask and the relative
two- and three-vertex signs.

This removes the common-weight restriction in this
returning transverse local comparison. It leaves
separated kernels, external regulator mean products,
longitudinal terms and the full master identity open.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
