# V973 pre-execution contract

Freeze V894 mixed inverse, V965 literal grade-one
returning roots, V969 auxiliary regulator response,
V970 three selected cubic-power columns and V972
unequal-profile direct roots. Compare the remaining
grade-one returning regulator roots at the first jet
and s³, including the auxiliary mask. Work in the
zero-width transverse hard local comparison. Derive
the relative signs before the color calculation.
Keep independent H and M profiles, matched within
each quartet. Verify both literal exports, exact
color rank and omitted-root controls. Separated
kernels, external regulator mean terms and other
master products remain outside this test.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority change.
