"""Verify the unequal-profile regulators on the selected cubic switch jet."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


def previous():
    path = ROOT / "calculations/canonical_so10_gauge_first_switch_rank_v1/first_switch_rank.py"
    spec = importlib.util.spec_from_file_location("first_switch_owner",path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def compare(phase):
    prior = previous()
    literal = prior.load_literal()
    owner = literal.load_owner()
    _, _, _, f, _, _ = owner.owner.inputs(phase)
    clean = owner.owner.clean
    J, _, da, db, _, _, _, JL = literal.literal_tables(owner,phase)
    J_ports, mixed_ports = defaultdict(list), defaultdict(list)
    for (a,v,i),j in J.items():
        J_ports[v,i].append((a,j))
    for (v,b),rows in f.items():
        for u,z in rows:
            masked = z-JL.get((v,u,b),0)
            assert sp.expand(masked-int(not (u>=12 and b<12))*z) == 0
            if masked:
                mixed_ports[u].append((v,b,masked))
    lower = [prior.table() for _ in range(4)]
    defect = [prior.table() for _ in range(4)]
    mix_reg = [prior.table() for _ in range(4)]
    max_reg = [prior.table() for _ in range(4)]
    K_HH = prior.table()
    for (i,u,c),z in da.items():
        hard = z-db.get((i,u,c),0)
        for a,j in J_ports[u,i]:
            n = 2*int(u>=12)+int(i>=12)
            lower[n][a,c] -= j*hard
            if n == 0:
                K_HH[a,c] -= j*z
        if not hard:
            continue
        for v,b,l in mixed_ports[u]:
            if b == c:
                continue
            n = sum(k>=12 for k in (v,u,i))
            for a,j in J_ports[v,i]:
                key = a,min(b,c),max(b,c)
                y = (1 if b<c else -1)*j*hard*l
                defect[n][key] += y
                vvi = 2*int(v>=12)+int(i>=12)
                vvu = 2*int(v>=12)+int(u>=12)
                uui = 2*int(u>=12)+int(i>=12)
                mix_reg[vvi][key] += y
                mix_reg[vvu][key] -= y
                max_reg[n][key] += y
                max_reg[uui][key] -= y

    Q = clean(prior.auxiliary(f,clean(K_HH)))
    T = [clean(prior.square(f,clean(K),{})) for K in lower]
    Y = [clean(D) for D in defect]
    proper = [clean(prior.plus((lhs,1),(rhs,-1),(Q,-2 if n==3 else 0)))
              for n,(lhs,rhs) in enumerate(zip(T,Y))]
    assert [len(D) for D in proper] == [423,934,557,708]
    total = [clean(prior.plus((p,1),(g,1),(m,1)))
             for p,g,m in zip(proper,mix_reg,max_reg)]
    assert not clean(prior.plus(*((D,1) for D in total)))
    assert Q[0,13,14] == 19*sp.sqrt(10)/40
    omit_m = [clean(prior.plus((p,1),(g,1))) for p,g in zip(proper,mix_reg)]
    omit_g = [clean(prior.plus((p,1),(m,1))) for p,m in zip(proper,max_reg)]
    controls = [sum(len(x) for x in directions) for directions in (omit_m,omit_g)]
    assert min(controls) > 0
    support = sorted(set().union(*(x.keys() for x in total)))
    matrix = sp.Matrix(len(support),4,lambda row,col:total[col].get(support[row],0))
    basis = matrix.nullspace()
    return {"proper_columns":[len(x) for x in proper],
            "modified_columns":[len(x) for x in total],
            "modified_rank":4-len(basis),
            "modified_nullspace":[[str(z) for z in v] for v in basis],
            "omitted_root_control_cells":controls}


def leg_algebra():
    Fu,Fv,Fi = sp.symbols("Fu Fv Fi",nonzero=True)
    Du,Dv,Di = [1/F-1 for F in (Fu,Fv,Fi)]
    assert sp.expand(Fv**2*Fu*Fi*(Du-Di)) == Fv**2*Fi-Fv**2*Fu
    assert sp.expand(Fv*Fu**2*Fi*(Du-Dv)) == Fv*Fu*Fi-Fu**2*Fi
    q = sp.Matrix([1,0])
    r = sp.Matrix(sp.symbols("r0:2"))
    P = sp.eye(2)-q*q.T
    G = P.row_join(-q).col_join(q.T.row_join(sp.zeros(1)))
    switch = ((r*q.T-q*r.T)/2).row_join(r/2).col_join((r.T/2).row_join(sp.zeros(1)))
    inverse = (-G*switch*G)[:2,:2]
    assert q.T*inverse == r.T*P/2 and inverse*(-q) == P*r/2
    x = sp.Symbol("x")
    log = sp.series(sp.log(1+x)/2,x,0,5).removeO()
    assert log.coeff(x,2)<0 and log.coeff(x,3)>0 and log.coeff(x,4)<0


if __name__ == "__main__":
    leg_algebra()
    run_worker(compare,sys.argv[1])
