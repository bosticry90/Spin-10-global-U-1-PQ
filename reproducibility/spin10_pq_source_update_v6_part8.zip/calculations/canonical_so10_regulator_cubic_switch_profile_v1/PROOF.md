# Unequal-profile returning regulators at the cubic switch power

Use the V970 common n2 normalization, and let
X=f_(a v i)f_(i u c)f_(u v b) with the V965 labels.
Write m_b=m_u h_b and m_c=m_u h_c in the two masks
in this derivation. The symmetric compact mixed
quadratic inserts Q_Lambda,B=r^T/2 on a gauge line.
At width zero a contraction of the endpoint momentum
with the Dyson insertion -G Q G gives r P_T/(2Q)
with the endpoint orientation of V967. An insertion
on a purely mixed or ghost line cannot replace the
ordinary transverse endpoint divergence in this jet.

For the mixed regulator W the derivative on Lambda
has momentum opposite to its ordinary B at zero
exterior ghost transfer. The Dyson term therefore
replaces the V965 exterior derivative by +(partial s)/2
in its oriented raw numerator. Its Euler profile
factor is D_u. The grade-one q_Lambda companion
differentiates the opposite B and gives the opposite
sign with D_v on support m_b. Both u,v are broken
there, hence D_v=D_u. The ordinary F mixed residue
retains the mask 1-m_c.

For the ghost regulator R, the derivative momenta at
the ordinary F antighost and B are opposite. The
Dyson term acts on that B endpoint and brings the
full hard contrast d_B-d_a. Its mask is 1-m_v h_b,
equal to 1-m_b on f support. The q_C Euler factor
is D_i, and its q_a companion gives the opposite
sign with D_u on support m_c. Both i,u are broken
there, hence D_i=D_u. The two numerators before
antisymmetrization and in the raw n3 sign are

    +X (1-m_c)(D_u-m_b D_v)/2,
    -X (1-m_b)(D_i-m_c D_u)/2.

Their sum is X(1-m_b)(1-m_c)(D_u-D_i)/2, with
profile product F_v² F_u F_i. This also shows the
paired reference inverses cancel when the Euler
factors are removed. The Maxwell regulator has
the symmetrized hard tensor Q P_T(D_u-D_v). Its
Dyson insertion is on the u line to F. The hard
contrast provides mask 1-m_c and sign +X/2 in
the raw units. A nonzero difference D_u-D_v
requires unlike sectors, making 1-m_b equal to
one on that support. Its profile product is
F_v F_u² F_i. A Maxwell switch insertion between
two transverse BB factors vanishes by P_T Q_BB P_T
at the first jet. These terms already contain r,
so a cutoff-profile derivative costs a second jet.

Let w_xyz denote the normalized collapsed three-
profile weights, symmetric in the profile factors
for the local hard-symbol comparison. The raw
regulator differences just derived are, in units
s³(partial s)/2,

    +Y_vui (w_vvi-w_vvu)   from mixed and ghost,
    +Y_vui (w_vui-w_uui)   from Maxwell,

where Y_vui=Alt X(1-m_b)(1-m_c). The Dyson minus
was included in the covariance. The n3 log sign
is positive, so dividing the raw answer by the
negative V967 common n2 factor flips these signs.
This agrees with expanding an n4 log with G Q G
and no extra Dyson minus. Subtracting the regulator
in the master equation adds both displayed
differences to V970's residual. In particular,
its coefficient multiplying -Y_vui becomes
w_uui-w_vvi+w_vvu. This sign is tested before
combining the color columns. The local weights
use common subtraction and the ordered relative
comparison, not exceptional all-soft amplitudes.

Both literal routes verify the resulting columns
and missing-root controls. This computation is
restricted to the returning regulator roots and
three V970 directions in the transverse gauge
local projection. It does not determine external
mean products, nonlinear source or longitudinal
terms, absolute separated kernels, ordinary metric,
scalar finite matching or the marked comparison.
The routes share the action and symbolic software.
