# Unequal-profile regulator terms at the second switch power

Use the V965 color labels (v,u,i) and exterior (a,b,c).
In the selected hard local first-switch numerator let
F_j be the common scalar cutoff profile within the
quartet of color j, and D_j=F_j^{-1}-1. H and M may
differ. The V791 free regulator has no reference mass
defect on these legs. Keep its whole heat and IR factors.
The proper regulator insertion is the source-field
Euler contraction with its mean subtraction. This
selected trace has a returning contraction and no
exterior ordinary gauge or antighost mean at that leg.

Write X=f_(a v i)f_(i u c)f_(u v b). The mixed Euler
is on the Lambda_u line. It gives +(1-m_u h_c) X D_u
in the V965 three-vertex source-first sign. The
transverse ordinary gauge line transfers the root
derivative to the switch at the mixed vertex. The
ghost Euler q_C acts on the antighost i, giving
-X D_i. Its q_a companion acts on the ghost u and
contributes +m_u h_c X D_u. This last support has
i,u both broken. The mask cancels after addition.
The switch derivative at the F vertex uses -d_a
with d_B killed by the preserved ordinary transverse
line and d_C carrying only an exterior ghost derivative.
The q_Lambda grade-one derivative on an ordinary B
leg is transverse-zero here. The mixed and ghost sum
therefore has profile factor

    F_v F_u F_i (D_u-D_i)=F_v(F_i-F_u).

For the Maxwell root q_B E_R,B there are two ordinary
gauge slots. Exchanging the Euler and other slot
reverses f_(u v b). Their hard tensor difference is
Q P_T (D_u-D_v). The external ghost at F has its
switch derivative from -d_a. In the same three-vertex
units the signed coefficient is +X, without a mixed
mask. The product profile is

    F_v F_u F_i (D_u-D_v)=(F_v-F_u)F_i.

Both formulas already carry one switch momentum.
Differentiating a surviving profile would have order
two. Each term has the common transverse radial
coefficient; these are local hard-symbol comparisons,
with the inherited nonexceptional removal used for
the relative terms. They do not identify separated
finite momentum kernels.

In the V968 units the stripped two-vertex log has
negative sign, whereas these regulator triangles
have positive sign. Division by the common sign
reverses both regulator insertion terms. Subtracting
the regulator insertion from the master comparison
then adds

    Alt X [ (w_vi-w_vu) + (w_vi-w_ui) ]

to the V968 ordinary columns. The w_xy label the
remaining two scalar profiles. The auxiliary grade-
two s² term has already canceled in V969. V971's
actual local ghost-source coefficient vanishes in
this transverse comparison. The literal cyclic
root inputs and all grouped color columns are
checked separately in both exports.
