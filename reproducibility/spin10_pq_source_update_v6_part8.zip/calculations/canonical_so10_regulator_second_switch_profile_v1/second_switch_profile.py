"""Reconcile the selected second switch power with grade-one regulator roots."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


def previous():
    path = ROOT / "calculations/canonical_so10_gauge_first_switch_rank_v1/first_switch_rank.py"
    spec = importlib.util.spec_from_file_location("switch_rank_owner",path)
    prior = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(prior)
    return prior


def leg_algebra():
    Fu, Fv, Fi = sp.symbols("Fu Fv Fi", nonzero=True)
    Du, Dv, Di = (1/F-1 for F in (Fu,Fv,Fi))
    product = Fu*Fv*Fi
    for mask in (0,1):
        assert sp.expand(product*((1-mask)*Du-Di+mask*Du)-Fv*(Fi-Fu)) == 0
    assert sp.expand(product*(Du-Dv)-(Fv-Fu)*Fi) == 0
    assert sp.expand(product*(Du-Dv)).subs(Fu,Fv) == 0
    assert sp.expand(product*(Du-Di)).subs(Fu,Fi) == 0
    # The two-leg collapse retains the whole 1-F factor.
    e,f = sp.symbols("e f", nonzero=True)
    assert sp.expand(((1/Fu-1)-(1/e-1))*Fu).subs(Fu,e*f).expand() == 1-f


def regulator(prior,f):
    # Sparse joined color bracket; the operator identities fix leg labels.
    at_u = defaultdict(list)
    at_vi = defaultdict(list)
    for (v,b), rows in f.items():
        for u,z in rows:
            at_u[u].append((v,b,z))
    for key, rows in f.items():
        at_vi[key].extend(rows)
    mixed = [prior.table() for _ in range(4)]
    maxwell = [prior.table() for _ in range(4)]
    for (u,c), rows in f.items():
        for i,x in rows:
            # The q_a partner is supported on i,u both broken.
            mask = int(u>=12 and c<12)
            assert not mask or i>=12
            for v,b,y in at_u[u]:
                if b == c:
                    continue
                sector_vi = prior.sectors(v,i)
                sector_vu = prior.sectors(v,u)
                sector_ui = prior.sectors(u,i)
                for a,z in at_vi[v,i]:
                    coefficient = (1 if b<c else -1)*x*y*z
                    cell = a,min(b,c),max(b,c)
                    mixed[sector_vi][cell] += coefficient
                    mixed[sector_vu][cell] -= coefficient
                    maxwell[sector_vi][cell] += coefficient
                    maxwell[sector_ui][cell] -= coefficient
    return mixed,maxwell


def check(phase):
    leg_algebra()
    prior = previous()
    f,clean,ordinary,K,L = prior.compare(phase)
    D = [clean(prior.plus((prior.square(f,k,l),1),(r,-1)))
         for k,l,r in zip(K,L,ordinary)]
    G,M = regulator(prior,f)
    total = [clean(prior.plus((d,1),(g,1),(m,1))) for d,g,m in zip(D,G,M)]
    assert not clean(prior.plus(*((x,1) for x in total)))
    symmetric = [total[0],clean(prior.plus((total[1],1),(total[2],1))),total[3]]
    support = sorted(set().union(*(x.keys() for x in symmetric)))
    matrix = sp.Matrix(len(support),3,lambda row,col:symmetric[col].get(support[row],0))
    basis = matrix.nullspace()
    assert sp.ones(3,1) in basis or matrix*sp.ones(3,1) == sp.zeros(len(support),1)
    omit_m = [clean(prior.plus((d,1),(g,1))) for d,g in zip(D,G)]
    omit_g = [clean(prior.plus((d,1),(m,1))) for d,m in zip(D,M)]
    negative = [len(C[0])+len(C[3])+len(clean(prior.plus((C[1],1),(C[2],1))))
                for C in (omit_m,omit_g)]
    assert min(negative) > 0
    return {"ordinary_nonzero_cells":[len(x) for x in D],
            "mixed_ghost_regulator_cells":[len(clean(x)) for x in G],
            "maxwell_regulator_cells":[len(clean(x)) for x in M],
            "modified_direction_cells":[len(x) for x in total],
            "reciprocal_profile_cells":[len(x) for x in symmetric],
            "reciprocal_profile_rank":3-len(basis),
            "reciprocal_profile_nullspace":[[str(x) for x in v] for v in basis],
            "omitted_root_control_cells":negative}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
