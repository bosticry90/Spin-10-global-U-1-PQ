# V972 pre-execution contract

Freeze the V791 regulator, V965 ordered gauge-source
loop, V968 ordinary sector columns, V969 auxiliary
response and V971 transverse ghost-source support.
At zero background and zero width, test the remaining
grade-one regulated mixed, ghost and Maxwell roots
in the selected local s² first-switch coefficient.
Keep one scalar profile per internal quartet, with H
and M distinct. Derive leg factors at positive cutoffs
before combining local weights. Compare the full color
columns in both exports. The output is the exact rank
and conditions for this defined comparison, including
a negative control for omitting a root. No s³ or full
master closure is asserted by this increment.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority change.
