# V972 · Regulator profile comparison at the second switch power

The mixed/ghost Euler pair and the Maxwell regulator
remove all four of the selected V968 weight columns
at `s²∂s`. The cancellation holds for separate H
and M profiles, matched within each quartet. It
does not require equal finite H/M weights.

Both action exports reproduce the zero columns.
Omitting either regulator family leaves 2,892
positions in the three reciprocal-profile columns.
The V969 auxiliary term is already absent at this
switch power. The remaining `s³∂s` comparison,
separated kernels and other quantum products
are outside this result.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
