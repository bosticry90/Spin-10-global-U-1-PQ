# Proper source and regulator chain verified without zero-breaking assumptions

Two exact Gaussian methods give the same17-term proper action in the
frozen nonlinear/source-quadratic fixture. The complete LEFT field/source
derivatives satisfy

    I_B1=QGamma1+C_Q,
    QGamma1=I_BR1-D_reg-Jacobian.

Classical B, I_B1, Jacobian, D_source, D_reg and QGamma are all nonzero.
The external-mean product equals D_reg from the same functional. All
seven sign/omission/source controls fail, including at mixedgu order.
The derivation and scope are in [PROOF.md](PROOF.md).

This establishes the finite operator interpretation for the next model
calculation. It is not a new Spin(10) amplitude, an assertion that Ihat0,
a continuum QAP or a physical normalization. The actual QGamma source/
mean kernels and their comparison with V799 remain to be calculated.

Worker .053413s under120s,8GiBsampled/350MiBfloor/32MiB packet; no
failed worker. Final receipt owns exact anchors, source/input/resource/
state/oldtree and E4once checks. Custody remains exit2/seven NOTPASS;
state113/34of39,E5/A5 OPEN unchanged. Shared ring/software/AI author
limit independence; no proof-kernel or empirical validation.

Next build meanF*T²E/2 and (T²F/2)*meanE from actual fullsourceful
S0/S1/U0/U1, with physical companions and source-quadratic terms retained.
Apply the paired mean subtraction and hatted support before transferring
ordered references. No current tensor or contact is fitted. Fullcommon
normalization/reality,QAP,measure/equivalence,E5/A5/viability remain open.
