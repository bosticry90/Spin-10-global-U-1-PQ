from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
import json,os,threading,time
O=Path(__file__).resolve().parent
# even b,L,Ja,JC,eta_b,eta_L; odd C,a,JB,JL,eta_C,eta_a.
NE=6;NO=6;ZEROE=(0,)*NE
ONE={(0,0,ZEROE,0):F(1)}
def clean(p):return {k:c for k,c in p.items() if c}
def plus(*polys):
 out={}
 for p in polys:
  for k,c in p.items():out[k]=out.get(k,F(0))+c
 return clean(out)
def scale(p,c):return clean({k:v*c for k,v in p.items()})
def mul(p,q):
 out={}
 for (g,u,ee,mm),a in p.items():
  for (h,v,ff,nn),b in q.items():
   if g+h>1 or u+v>1 or mm&nn:continue
   sign=(-1)**sum((nn&((1<<i)-1)).bit_count() for i in range(NO) if mm&(1<<i))
   key=g+h,u+v,tuple(x+y for x,y in zip(ee,ff)),mm|nn;out[key]=out.get(key,F(0))+sign*a*b
 return clean(out)
def product(*polys):
 out=ONE
 for p in polys:out=mul(out,p)
 return out
def atom(n):
 ee=list(ZEROE);mm=0
 if n<NE:ee[n]=1
 else:mm=1<<(n-NE)
 return {(0,0,tuple(ee),mm):F(1)}
def term(ids=(),c=1,g=0,u=0):
 out={(g,u,ZEROE,0):F(c)}
 return product(out,*(atom(n) for n in ids))
def partial(p,n):
 out={}
 for (g,u,ee,mm),c in p.items():
  if n<NE:
   power=ee[n]
   if not power:continue
   ff=list(ee);ff[n]-=1;key=g,u,tuple(ff),mm;z=power*c
  else:
   bit=1<<(n-NE)
   if not mm&bit:continue
   key=g,u,ee,mm^bit;z=c*(-1)**((mm&(bit-1)).bit_count())
  out[key]=out.get(key,F(0))+z
 return clean(out)
FIELDS=[0,1,6,7];SOURCES=[8,9,3,2];PAR=[0,0,1,1];QUANT=[4,5,10,11]
def tangent(p):return plus(*(mul(atom(q),partial(p,n)) for n,q in zip(FIELDS,QUANT)))
def t2(p):return scale(tangent(tangent(p)),F(1,2))
def setzero(p,ids):
 even=[i for i in ids if i<NE];mask=sum(1<<(i-NE) for i in ids if i>=NE)
 return {k:c for k,c in p.items() if not(k[3]&mask) and not any(k[2][i] for i in even)}
def expminus_nil(p):
 p2=mul(p,p);assert not mul(p2,p),'INCOMPLETE_NIL_EXPONENTIAL'
 return plus(ONE,scale(p,-1),scale(p2,F(1,2)))
def inverse_unit(p):
 r=plus(p,scale(ONE,-1));r2=mul(r,r);assert not mul(r2,r),'INCOMPLETE_NIL_INVERSE'
 return plus(ONE,scale(r,-1),r2)
def log_unit(p):
 r=plus(p,scale(ONE,-1));r2=mul(r,r);assert not mul(r2,r),'INCOMPLETE_NIL_LOG'
 return plus(r,scale(r2,F(-1,2)))
@lru_cache(None)
def moment(n,cov):return F(0) if n%2 else F(1) if n==0 else (n-1)*cov*moment(n-2,cov)
def free_expect(p):
 ghost_weight=plus(ONE,term([10,11],F(3,2)));out={}
 for (g,u,ee,mm),c in mul(p,ghost_weight).items():
  if mm&48!=48:continue
  ff=list(ee);ff[4]=ff[5]=0;key=g,u,tuple(ff),mm^48
  z=c*moment(ee[4],F(1,2))*moment(ee[5],F(1,3))*F(2,3)
  out[key]=out.get(key,F(0))+z
 return clean(out)
def encode(p):return [[g,u,list(ee),mm,c.numerator,c.denominator] for (g,u,ee,mm),c in sorted(p.items())]
def matmul(a,b):return [[plus(*(mul(a[i][k],b[k][j]) for k in range(2))) for j in range(2)] for i in range(2)]
def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in json.loads((O/'preparation.json').read_bytes())['source_sha256'].items():assert sha256((O/n).read_bytes()).hexdigest()==h,n
 S0=plus(term([0,0],F(1,2)),term([1,1]),term([7,6]),term([8,6]),term([2,1],-1))
 Sg=plus(term([0,0,0],F(1,3),g=1),term([0,1,1],F(1,5),g=1),term([7,6,0],F(1,3),g=1),term([8,0,6],g=1),term([9,1,6],2,g=1),term([2,7,6],F(-3,2),g=1),term([2,0,0],F(1,3),g=1),term([3,6,7],F(-2,5),g=1))
 Su=plus(term([2,2,0,0],F(1,2),u=1),term([0,0,1],F(1,2),u=1),term([7,6,0],F(2,3),u=1),term([8,9,0],F(3,7),u=1),term([2,1,1],F(1,5),u=1))
 Sgu=plus(term([2,0,1],F(1,7),g=1,u=1),term([8,7,0],F(2,7),g=1,u=1),term([3,2,7,6],F(1,11),g=1,u=1),term([0,1,7,6],F(1,13),g=1,u=1))
 S=plus(S0,Sg,Su,Sgu);R=plus(term([0,0],F(1,2)),term([1,1],F(1,2)),term([7,6],F(1,2)))
 assert all(mm.bit_count()%2==0 for p in [S,R] for g,u,ee,mm in p)
 Q2=plus(t2(S),t2(R));base=plus(term([4,4]),term([5,5],F(3,2)),term([11,10],F(3,2)));V=plus(Q2,scale(base,-1));assert all(g+u>0 for g,u,ee,mm in V)
 weight=expminus_nil(V);Z=free_expect(weight);Zi=inverse_unit(Z);Gamma=scale(log_unit(Z),-1)
 expect=lambda p:mul(free_expect(mul(p,weight)),Zi)
 # Separate Schur evaluation: exact two-boson inverse/log and one-pair Berezin.
 Amat=[[setzero(partial(partial(Q2,i),j),QUANT) for j in [4,5]] for i in [4,5]]
 A0=[[scale(ONE,2),{}],[{},scale(ONE,3)]];D0=[[scale(ONE,F(1,2)),{}],[{},scale(ONE,F(1,3))]]
 Bmat=[[plus(Amat[i][j],scale(A0[i][j],-1)) for j in range(2)] for i in range(2)];X=matmul(D0,Bmat);X2=matmul(X,X)
 ident=[[ONE,{}],[{},ONE]];inv=matmul([[plus(ident[i][j],scale(X[i][j],-1),X2[i][j]) for j in range(2)] for i in range(2)],D0)
 bosonGamma=scale(plus(*(plus(X[i][i],scale(X2[i][i],F(-1,2))) for i in range(2))),F(1,2))
 lin=[setzero(partial(Q2,i),[4,5]) for i in [4,5]];ghost=plus(setzero(Q2,[4,5]),scale(plus(*(product(lin[i],inv[i][j],lin[j]) for i in range(2) for j in range(2))),F(-1,2)))
 qeff={}
 for (g,u,ee,mm),c in ghost.items():
  assert ee[4]==ee[5]==0 and mm&48==48,'SCHUR_GHOST_DEGREE'
  key=g,u,ee,mm^48;qeff[key]=qeff.get(key,F(0))+c
 qeff=clean(qeff);GammaSchur=plus(bosonGamma,scale(log_unit(scale(qeff,F(-2,3))),-1))
 assert Gamma==GammaSchur,'DIRECT_BEREZIN_VS_SCHUR_PROPER_GAMMA'
 flows=[scale(partial(S,j),(-1)**p) for j,p in zip(SOURCES,PAR)];E=[partial(S,n) for n in FIELDS];Rp=[partial(R,n) for n in FIELDS]
 Qfield=plus(*(mul(f,partial(Gamma,n)) for f,n in zip(flows,FIELDS)));Dsource=plus(*(scale(mul(e,partial(Gamma,j)),(-1)**p) for e,j,p in zip(E,SOURCES,PAR)));Dreg=plus(*(scale(mul(r,partial(Gamma,j)),(-1)**p) for r,j,p in zip(Rp,SOURCES,PAR)));QGamma=plus(Qfield,Dsource)
 for n,e in zip(FIELDS,E):assert partial(Gamma,n)==expect(t2(e)),('PROPER_FIELD_DERIVATIVE',n)
 for j,p,f in zip(SOURCES,PAR,flows):assert partial(Gamma,j)==scale(expect(t2(f)),(-1)**p),('PROPER_SOURCE_DERIVATIVE',j)
 B=plus(*(mul(f,e) for f,e in zip(flows,E)));BR=plus(*(mul(f,plus(e,r)) for f,e,r in zip(flows,E,Rp)))
 IB=expect(t2(B));IBR=expect(t2(BR));CQ=expect(plus(*(mul(tangent(f),tangent(e)) for f,e in zip(flows,E))));CR=expect(plus(*(mul(tangent(f),tangent(r)) for f,r in zip(flows,Rp))));Jac=plus(*(partial(tangent(f),q) for f,q in zip(flows,QUANT)))
 mean_insert=expect(plus(*(mul(t2(f),r) for f,r in zip(flows,Rp))))
 assert IB==plus(QGamma,CQ),'UNREGULATED_BROKEN_PROPER_SOURCE_CHAIN'
 assert IBR==plus(QGamma,CQ,Dreg,CR),'REGULATED_WHOLE_PRODUCT_RULE'
 assert plus(CQ,CR)==Jac,'CURRENT_REGULATOR_AND_JACOBIAN'
 assert QGamma==plus(IBR,scale(Dreg,-1),scale(Jac,-1)),'COMPLETE_REGULATED_PROPER_SLV'
 assert mean_insert==Dreg and Dreg,'SAME_FUNCTIONAL_EXTERNAL_MEAN_TERM'
 assert all([B,IB,Jac,QGamma,Dsource,Dreg])
 sourceids=SOURCES;Qact=lambda p:plus(*(mul(f,partial(p,n)) for f,n in zip(flows,FIELDS)),*(scale(mul(e,partial(p,j)),(-1)**par) for e,j,par in zip(E,SOURCES,PAR)))
 source_degree=lambda ee,mm:ee[2]+ee[3]+(mm&12).bit_count()
 linearGamma={k:c for k,c in Gamma.items() if source_degree(k[2],k[3])<2};quad=plus(Gamma,scale(linearGamma,-1));assert quad
 Qwrongsource=plus(Qfield,*(mul(e,partial(Gamma,j)) for e,j in zip(E,SOURCES)))
 wrong=dict(omit_Dsource=plus(Qfield,scale(IB,-1),CQ),omit_Dreg=plus(QGamma,scale(IBR,-1),Jac),omit_Jacobian=plus(QGamma,scale(IBR,-1),Dreg),wrong_odd_source_pairing=plus(Qwrongsource,scale(QGamma,-1)),premature_source_zero=plus(setzero(Qact(setzero(Gamma,sourceids)),sourceids),scale(setzero(QGamma,sourceids),-1)),omit_source_quadratic_Gamma=plus(Qact(linearGamma),scale(QGamma,-1)),assume_classical_master=plus(QGamma,CQ))
 assert all(wrong.values()),('BLIND_WHOLE_SOURCE_CHAIN_CONTROL',[k for k,z in wrong.items() if not z])
 gu=lambda p:{k:c for k,c in p.items() if k[:2]==(1,1)}
 assert gu(QGamma) and gu(CQ) and gu(Dsource)
 out=dict(schema='PROPER_GRADED_SOURCE_AND_REGULATOR_CHAIN_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',field_source_ids=dict(fields=FIELDS,sources=SOURCES,quantum=QUANT,parities=PAR),action=encode(S),regulator=encode(R),proper_quadratic_action=encode(Q2),partition=encode(Z),Gamma_direct=encode(Gamma),Gamma_Schur=encode(GammaSchur),QGamma=encode(QGamma),QfieldGamma=encode(Qfield),Dsource=encode(Dsource),Dreg=encode(Dreg),classical_breaking=encode(B),I_B1=encode(IB),I_BR1=encode(IBR),C_Q=encode(CQ),C_R=encode(CR),Jacobian=encode(Jac),external_mean_insertion=encode(mean_insert),source_quadratic_Gamma=encode(quad),wrong_residuals={k:encode(z) for k,z in wrong.items()},mixed_gu_controls_sensitive={k:bool(gu(z)) for k,z in wrong.items()},all_exact_operator_relations=True,finite_exponential_inverse_log_exact_by_g_u_ideal=True,not_physical_model_or_parameter_point=True,elapsed_after_imports=time.perf_counter()-tick)
 with (O/'chain_result.json').open('x',encoding='utf-8',newline='\n') as h:json.dump(out,h,sort_keys=True);h.write('\n')
 print('RESULT '+json.dumps(dict(execution_state=out['execution_state'],Gamma_terms=len(Gamma),QGamma_terms=len(QGamma),Dsource_terms=len(Dsource),Dreg_terms=len(Dreg),Jacobian_terms=len(Jac),control_mixed_gu_sensitive=out['mixed_gu_controls_sensitive'],elapsed_after_imports=out['elapsed_after_imports']),sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
