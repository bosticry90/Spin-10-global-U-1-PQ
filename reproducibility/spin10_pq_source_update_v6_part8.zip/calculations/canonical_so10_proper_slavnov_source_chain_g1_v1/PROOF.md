# Proper source chain with classical breaking, Jacobian and fixed-regulator mean term

This result fixes the finite-Gaussian operator interpretation needed for
the next same-parent model calculation. It does not compute a new Spin(10)
amplitude, adopt a normalization or prove a continuum QAP. The action and
all toy coefficients were frozen in RECORD before execution.

## Proper derivative and product identities

Let S(phi,J) be even, with source parity1-p_i and the verified LEFT
pairing F_i=(-1)^p_i S_Ji,QJ_i=(-1)^p_i E_i,E_i=S_i. The action may
be nonlinear in fields AND in sources. Fix a quadratic regulator R with
no mean/source-dependent matrix, and work in a finite normalized graded
Gaussian with H=S''+R and G=H^-1. T is the even field-fluctuation
derivation; sources stay fixed under T. All source derivatives occur
before any source restriction. Keep the reference determinant separately;
its constant has zero derivative in the finite fixture.

Define the proper one-loop determinant Gamma1 by the quadratic fluctuation
action, not by integration of the full interacting action at all loop
orders. Differentiating this normalized determinant gives

    Gamma1_phi_i = <T²E_i/2>,
    Gamma1_Ji = (-1)^p_i <T²F_i/2>.

These are identities for LEFT derivatives, including odd sources. They
can also be obtained by differentiating the finite Gaussian integral.
No positive physical Lambda contour or full nonperturbative measure is
inferred from this finite/formal algebra. The fixture uses positive
ordinary boson variances and one literal Berezin pair.

Write B=sum F_i E_i, which is the half-master breaking in this convention.
Do not assume B=0. Since T is even, its exact product rule is

    T²(F_i E_i)/2
       = (T²F_i/2)E_i + (TF_i)(TE_i) + F_i(T²E_i/2).

F_i has parityp_i+1 and E_i parityp_i; their exchanged mean factors
commute because p_i(p_i+1)=0. Therefore, with the proper insertion
I_B1=<T²B/2> and current C_Q=<sum TF_i TE_i>,

    I_B1 = Q Gamma1 + C_Q,
    Q Gamma1=sum[F_i Gamma1_phi_i+(-1)^p_i E_i Gamma1_Ji].

The source term D_source=sum(-1)^p_i E_i Gamma1_Ji is indispensable.
It is distinct from a marked antighost translation and from the regulated
source correction below. These identities do not supply an unknown model
I_B insertion by assigning it zero.

## Fixed regulator and the whole external-mean product

Let Rphi_i=LEFT derivative of the quadratic regulator density and
BR=sum F_i(E_i+Rphi_i). At one loop its exact product expansion gives

    I_BR1 = Q Gamma1+C_Q+D_reg+C_R,
    D_reg=sum(-1)^p_i Rphi_i Gamma1_Ji,
    C_R=<sum TF_i T(Rphi_i)>.

The term <sum (T²F_i/2) Rphi_i> is EXACTLY D_reg. It is a generally
nonzero mean product, fixed by the same functional and source derivative;
it is not a freely adjustable contact. The normalized Gaussian
integration-by-parts identity, with all LEFT signs retained, is

    C_Q+C_R = Jac,
    Jac=sum partialLEFT_eta_i (TF_i).

Thus the complete finite equation is

    Q Gamma1 = I_BR1-D_reg-Jac.

This proves the candidate chain without any master or zero-Jacobian
premise. In a continuum application the regulator may contain inverse
heat and inverse IR factors. The displayed finite identities do not
make those separate factors tempered maps on arbitrary Schwartz means.
Their paired whole-functional mean subtraction must be retained until
the qualified common domain and ordered limits have been established.

## Exact independent proper determinant constructions

The fixture has even b,L,Ja,JC and odd C,a,JB,JL, with two even and
two odd fluctuation variables. Inert g,u obey g²=u²=0. The quotient is
stable under every tested field/source derivative and Qg=Qu=0. All
quadratic interaction terms carry g or u, so V³=0 exactly. Consequently
exp(-V), its normalized partition inverse and log partition terminate
by the algebra; an arbitrary series cutoff is never imposed.

Primary evaluates the full quadratic Gaussian weight by ordinary boson
moments with covariances1/2,1/3 and literal coefficient extraction of
the internal etaC etaa pair with ghost mass3/2. It computes Gamma1
directly as minus log of the normalized partition. Reference constants
are mean/source independent, not chosen physical baselines.

Replay eliminates the complete2x2 bosonic block with its exact nilpotent
inverse, retaining the odd-background mixed terms. It then evaluates
the one-pair ghost coefficient and its logarithm. The boson half-log
and ghost minus-log give exactly the same17-term proper Gamma1.
These are different integration/normalization methods; the polynomial
ring and the AI author remain shared.

Separate first-order closed forms, from the diagonal free covariance,
provide compact normalization anchors:

    Gamma_g = g[(31/90)b+(7/6)Ja-(4/15)JC],
    Gamma_u = u[Ja²/4+L/4+Ja/15-(4/9)b].

The source-quadratic Ja² contribution is already nonzero at u. A premature
linear-source restriction changes a proper derivative. Direct classical
field/source variation of these anchors gives

    [Q Gamma1]_g = g[-(37/45)C-(4/15)a-(4/15)JB],
    [Q Gamma1]_u = u[-(23/45)C-(1/2)Ja*C].

These hand-derived expressions are separately checked in final review;
they are not inferred from the regulated-current answer. The complete
gu expressions remain in chain_result, including all independent source
and odd-marker coefficients.

All four proper-field and four proper-source derivative identities are
checked coefficient by coefficient before source restriction. The full
nonzero17-term QGamma,16-term D_source,11-term D_reg and6-term Jacobian
satisfy all displayed product and Gaussian identities. B and I_B1 are
also nonzero. The external-mean insertion equals the nonzero D_reg
exactly; it is not deleted before that comparison.

Seven wrong whole expressions have nonzero exact residuals: omit
D_source, omit D_reg, omit the Jacobian, reverse the odd-source pairing,
set sources0 before differentiating, discard source-quadratic terms in
Gamma, or assume the classical master breaking vanishes. EVERY one
is sensitive in the gu coefficient as well. The fixture therefore tests
the terms that could otherwise create a misleading zero comparison.

## Consequence and limits for the model

The chain gives a precise next operator equation for the actual proper
Slavnov comparison and distinguishes D_source from D_reg. It does not
identify either with the missing VDI executable or compute its reported
tensor. The actual physical-chart source signs are the independently
completed V800 operands, not chosen from a desired quantum cancellation.

Next construct the actual proper kernels from S0/S1/U0/U1, including
mean F times T²E/2 and T²F/2 times mean E, all643 field/source complements
before restriction, and the physical Euler companions. Mean source
terms in Fu0, invisible to a fluctuation tangent alone, must remain.
Calibrate the actual inherited Euclidean/physical i/Wick normalization
before transferring numerical Gamma coefficients. The model's hatted
Ihat insertion must be retained or excluded by its actual first-u
support, not by assuming the full chiral master action is flat.

The exact finite chain and toy source controls do not establish its
continuum distribution domain, finite contact extension, real/background
compatible restoring primitive, common normalization, measure or quantum
equivalence. V799's full finite current and its nonzero local response
remain sealed comparators for a LATE actual-operand comparison. No current
tensor, old nine-M number, physical parameter or unknown contact is an
operand in this fixture. State113/34of39,E5/A5 remain unchanged/open.

## Capability and evidence assessment

The new execution demonstrates exact proper-source differentiation,
normalization by two integration methods and detection of seven relevant
failure modes in a non-master/source-quadratic Gaussian. It supplies a
mathematical reference standard, not an AI benchmark platform or an
experimental test. Basic Gaussian/Berezin calculus is inherited mathematics,
not a discovery of new physics. Shared algebra/software/author and the
chosen finite class limit independence and applicability. No outside
scientist or formal proof kernel is claimed.

The worker completed in .0534125s under120s; sampled private allocation
is not a true peak. There was no failed worker in this increment.
Final review owns complete source/input bindings, controls, reference
anchors, resources, unchanged oldtree/state and E4once/no-fresh with
seven historical custody references unresolved NOTPASS. Continue the
actual model calculation; this finite test is not full-goal completion.
