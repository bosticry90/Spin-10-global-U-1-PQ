from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/proper-slavnov-source-chain-g1-v1-2026-11-07')
sp=importlib.util.spec_from_file_location('proper_chain_final',O/'chain.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
decode=lambda rows:{(g,u,tuple(ee),mm):F(a,b) for g,u,ee,mm,a,b in rows}
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'final_preparation.json')['sha256'].items():assert digest(R/n)==h,n
 prep=read(O/'preparation.json')
 for n,h in prep['source_sha256'].items():assert digest(O/n)==h,n
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 z=read(O/'chain_result.json');assert z['all_exact_operator_relations'] and z['finite_exponential_inverse_log_exact_by_g_u_ideal'] and z['not_physical_model_or_parameter_point']
 assert z['Gamma_direct']==z['Gamma_Schur'] and len(z['Gamma_direct'])==17
 pick=lambda p,g,u:{k:c for k,c in p.items() if k[:2]==(g,u)}
 expectedg=m.plus(m.term([0],F(31,90),g=1),m.term([2],F(7,6),g=1),m.term([3],F(-4,15),g=1))
 expectedu=m.plus(m.term([2,2],F(1,4),u=1),m.term([1],F(1,4),u=1),m.term([2],F(1,15),u=1),m.term([0],F(-4,9),u=1))
 expectedQg=m.plus(m.term([6],F(-37,45),g=1),m.term([7],F(-4,15),g=1),m.term([8],F(-4,15),g=1))
 expectedQu=m.plus(m.term([6],F(-23,45),u=1),m.term([2,6],F(-1,2),u=1))
 Gamma=decode(z['Gamma_direct']);Q=decode(z['QGamma']);assert pick(Gamma,1,0)==expectedg and pick(Gamma,0,1)==expectedu and pick(Q,1,0)==expectedQg and pick(Q,0,1)==expectedQu
 CQ,CR,IB,IBR,ds,dr,jac=[decode(z[k]) for k in ['C_Q','C_R','I_B1','I_BR1','Dsource','Dreg','Jacobian']]
 assert IB==m.plus(Q,CQ) and IBR==m.plus(Q,CQ,dr,CR) and m.plus(CQ,CR)==jac and Q==m.plus(IBR,m.scale(dr,-1),m.scale(jac,-1))
 assert z['external_mean_insertion']==z['Dreg'] and all([ds,dr,jac,IB,decode(z['classical_breaking']),decode(z['source_quadratic_Gamma'])])
 assert Q==m.plus(decode(z['QfieldGamma']),ds)
 assert len(z['wrong_residuals'])==7 and all(z['wrong_residuals'].values()) and all(z['mixed_gu_controls_sensitive'].values()) and all(any(row[:2]==[1,1] for row in rows) for rows in z['wrong_residuals'].values())
 cap=read(O/'chain_capture.json');assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and z['elapsed_after_imports']<120
 assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples'])
 print('STAGE directSchurGamma,independentlinearanchors,brokenproperchains,nonzeromeanJacobian,all7gucontrolsverified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
 ec=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert p.returncode==0
 ev=[json.loads(row) for row in p.stdout.splitlines() if row.strip()];exits=[row['exit_code'] for row in ev if row['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and ev[-1]['execution_state']=='COMPLETED'
 assert next(row for row in ev if row['event']=='step_finished' and row['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 old=(C/'old_git_tree.txt').read_bytes();assert old==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True)
 state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V801.md'];size=sum(p.stat().st_size for p in files);assert size<32*1024**2
 out=dict(schema='PROPER_SOURCE_CHAIN_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_BOUNDED_NONMASTER_PROPER_SOURCE_REGULATOR_CHAIN_NOT_MODEL_AMPLITUDE',scientific_acceptance='NOT_PERFORMED',base_HEAD=prep['base_HEAD'],state_sha256=state,direct_Schur_Gamma_equal=True,independent_linear_Gamma_and_Q_anchors=True,nonzero_B_I_B_Jac_Dsource_Dreg_QGamma=True,complete_proper_source_and_regulator_chain=True,external_mean_equals_nonzero_Dreg=True,controls_whole_and_gu_sensitive=7,failures_this_increment=0,worker_seconds_after_imports=z['elapsed_after_imports'],largest_private_sample=max(x['private_bytes'] for x in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(old.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,actual_model_proper_QGamma_source_comparison_pending=True,full_QAP_E5_viability_goal_completion_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','evidence_validation','E4_step_exits','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
