# Proper Slavnov/source chain at fixed regulator

Base7d445abb0523904eb8baf239129db89816526b44/main,V800. Previousgoalturn
PROGRESS; cleanpreflight/no workers/452bindings. Fullobjective read,
currentAGENTS/charter/D:first. State113/34of39,E5/A5open unchanged.
Noagents/branch/worktree/adoption/promotion/protectedactivation/flavor/
remoteaction. Fullgoal is investigation, not only an attachment read.

Question: which exact proper one-loop source/mean equation is to be
compared with V799's finite current, without deleting source-quadratic
terms, curvature, Jacobian or the fixed-regulator external-mean product?
Relevance: V800 completed the actual source pairing; a correct finite
chain is indispensable before proper QGamma/source amplitudes or
common normalization inference. Least-cost competent test is an exact
non-master finite graded Gaussian, followed by actual-operand application.
Not a new benchmark platform or a model parameter choice.

Use the verified physical-chart LEFT pairing F_i=(-1)^p_i S_Ji,
QJ_i=(-1)^p_i E_i,E_i=S_i. Define precisely Dsource=sum(-1)^p E Gamma_J,
Dreg=sum(-1)^p (Rphi) Gamma_J. They are not the unavailable VDI tensor
or markedD_epsilon. Hold regulator/source normalization fixed under mean
and source differentiation. Retain Gamma_reference as a constant in the
fixture (its derivative0), not an adopted physical determinant baseline.

Prospective identities to DERIVE/test, no target coefficients as operands:
 Gamma_i=1/2<T2E_i>, Gamma_Ji=(-1)^p_i/2<T2F_i>;
 I_B1=QGamma1+C_Q, B=sum F_i E_i;
 I_BR1=QGamma1+C_Q+Dreg+C_R, BR=sum F_i(E_i+Rphi_i);
 C_Q+C_R=Jacobian, hence QGamma1=I_BR1-Dreg-Jacobian.
All normalized Gaussian contractions, same action/inverse/odd order.
No B=0 or Jacobian0 premise. No finite inverseheat multiplier on arbitrary
Schwartz means. Any actual continuum use still needs the paired whole
mean subtraction and the qualified UV-first/IR domain.

Fixture algebra: even b,L,Ja,JC,eta_b,eta_L; odd C,a,JB,JL,eta_C,eta_a.
Independent inert even g,u, quotient g^2=u^2=0. It is stable under the
tested field/source derivatives and Qg=Qu=0; no coefficient at firstgu
is lost. Sources have opposite parity to their fields. All left derivatives
precede source restriction. No spacetime/ghostnumber/physical-model claim
is made for toy coefficients; parity and proper-source structure tested.

Freeze S=S0+gSg+uSu+guSgu, exactly:
 S0=b²/2+L²+aC+JB*C-Ja*L;
 Sg=b³/3+bL²/5+aCb/3+JB*bC+2JL*LC
          -(3/2)Ja*aC+(1/3)Ja*b²-(2/5)JC*Ca;
 Su=(1/2)Ja²b²+(1/2)b²L+(2/3)aCb+(3/7)JB*JL*b+(1/5)Ja*L²;
 Sgu=(1/7)Ja*bL+(2/7)JB*ab+(1/11)JC*Ja*aC+(1/13)bL*aC.
Products in that written order, then graded canonicalization. Regulator
R(phi)=b²/2+L²/2+aC/2, constant matrix. Fields b,L,C,a, sourcesJB,JL,JC,Ja.

Primary Gamma1=-log normalizedGaussian(exp(-V2)), exact free boson
moments and literal one-pair Berezin coefficient, V2=T2S/2+R2-Hfree.
All interaction terms have positiveg/u; V2³=0 exactly, so exponential,
partition inverse and logarithm terminate by the algebra, not an arbitrary
cutoff. Replay Gamma by full2x2 boson Schur elimination and exact ghost
coefficient/logarithm; retain every odd-background cross term. Same ring
software is shared; integration/normalization routes are different.

Require nonzero B, I_B1, Jacobian, QGamma, Dsource,Dreg, source-quadratic
Gamma coefficient and at least one firstgu contribution. Controls omit
Dsource, omitDreg/wholemean term, wrongoddsourcepairing, missingJacobian,
earlysource0, and omittedsourcequadraticGamma terms. Each whole control
must be sensitive; disclose blind g/u subcoefficients separately. Exact
coefficient equality, including all zeros, not sampled even/source values.

Single native/comparator120s afterimports,8GiBsampled/350MiBlaunchfloor,
32MiB completepacket; final180s/E4once-no-freshDcontext0,0,0,0,0,2 and
seven custodyNOTPASS. Sources/inputs parsed/copied/hashed before execution.
Failed/incomplete sources/captures immutable, new version for corrections;
no physical input or acceptance weakening. ActualGamma/current targets
not read by fixture. Finalvalidation and rawmode/blob checks before
localcommit. Shared action/chart/ring/software/AIauthor limitations;
no independent scientist/proofkernel/empiricalvalidation. Educationvoluntary.

A passing finite chain licenses only the operator interpretation, not a
model amplitude, Bhat0, QAP or restoration. Next actualS0/S1/U0/U1 source
Hessian/mean calculation plus retained hatted insertion support, then
late comparison to sealed V799. Fullcommonmarked/unmarkednormalization/
reality, measure/equivalence,E5/A5/viability and fullgoal remainOPEN.
