# Actual regulator inverse recovered

Literal free-action Euler derivatives and independent raw-C3 transport
with the recorded Wick phases produce byte-identical complete matrices.
Both inverse directions are verified for all643 coordinates, including
ordered ghost signs and the entire zero freeLambdaLambda block.

The regulator separates into reference,heat and infrared inverse defects.
For the active M block its free product is1-fE, with heat contribution
f(1-E) and IR contribution1-f. The original f=(1-exp(-q²/delta²))² is
retained. Scalar reference masses remain reference parameters and their
328-entry inverse defect is explicit. No new physical mass/profile is chosen.

The [proof](PROOF.md) gives all blocks,decomposition,negative controls and
the inversion-only frame-test limitation; the [receipt](validation_receipt.json)
owns validation/resources. Next construct actual graded regulator vertices,
color/derivative numerators and finite-profile contractions against V789's
frozen current representation. Those amplitudes remain uncomputed here.
State113/34of39,E5/A5 and custody exit2/seven NOTPASS remain unchanged.
