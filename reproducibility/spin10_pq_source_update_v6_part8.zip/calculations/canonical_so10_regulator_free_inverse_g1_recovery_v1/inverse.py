from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import gzip,importlib.util,json,os,sys,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
ROLE=sys.argv[1] if __name__=='__main__' else 'native'
spec=importlib.util.spec_from_file_location('regulator_inverse_tools',O.parent/'canonical_so10_physical_current_input_recovery_g1_v1'/'physical_v2.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
w=v.w;J=w.J;A=w.A
q=s.symbols('q0:4',real=True);q2=sum(z*z for z in q);E,f=s.symbols('E_profile f_profile',nonzero=True,real=True)
xi,eta=A.xi,A.eta;pm=s.symbols('p0_ref0:4',real=True);masses={sec:s.Symbol('Mref_'+sec+'_squared',positive=True) for sec in ['Phi','Sigma','phi','S']}
locals0={str(z):z for z in [*pm,xi,eta,*masses.values()]};locals0['I']=s.I
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
@lru_cache(100000)
def canon(z):return s.cancel(s.expand(z))
def norm(P):return {ij:c for ij,z in P.items() if (c:=canon(z))!=0}
def plus(*ps):
 out={}
 for p in ps:
  for ij,c in p.items():out[ij]=out.get(ij,s.Integer(0))+c
 return norm(out)
def scale(P,c):return norm({ij:z*c for ij,z in P.items()})
def transpose(P):return {(j,i):c for (i,j),c in P.items()}
def mul(P,Q):
 rows={};out={}
 for (i,j),c in Q.items():rows.setdefault(i,[]).append((j,c))
 for (i,k),c in P.items():
  for j,d in rows.get(k,[]):out[i,j]=out.get((i,j),s.Integer(0))+c*d
 return norm(out)
IDENT={(n,n):s.Integer(1) for n in range(643)}
def encoded(P):return [[i,j,str(c)] for (i,j),c in sorted(norm(P).items())]
def save(data):
 blob=gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/(ROLE+'_inverse.json.gz')).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=64*1024**2
 return dict(file=ROLE+'_inverse.json.gz',sha256=sha256(blob).hexdigest(),bytes=len(blob))
def closed_physical():
 P={}
 for r in range(45):
  for mu in range(4):
   for nu in range(4):P[4*r+mu,4*r+nu]=q2*int(mu==nu)-q[mu]*q[nu]
   P[4*r+mu,508+r]=q[mu];P[508+r,4*r+mu]=-q[mu]
  P[508+r,508+r]=eta if r<12 else xi
  P[553+r,598+r]=-q2;P[598+r,553+r]=q2
 for n in range(180,508):P[n,n]=q2
 return norm(P)
def closed_green(fields):
 G={}
 for r in range(45):
  width=eta if r<12 else xi
  for mu in range(4):
   for nu in range(4):G[4*r+mu,4*r+nu]=s.Rational(int(mu==nu),1)/q2+(width-1)*q[mu]*q[nu]/q2**2
   G[4*r+mu,508+r]=-q[mu]/q2;G[508+r,4*r+mu]=q[mu]/q2
  G[553+r,598+r]=1/q2;G[598+r,553+r]=-1/q2
 for n in range(180,508):G[n,n]=1/(q2+masses[fields[n].split('_')[1]])
 return norm(G)
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 prep=read(O/'preparation.json')
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 for n,h in prep['source_sha256'].items():assert digest(O/n)==h,n
 peer=str((O/('replay_' if ROLE=='native' else 'native_')).resolve());corebase=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_full_hessian'
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
   p=str(Path(os.fsdecode(args[0])).resolve());assert not p.startswith(peer),'PEER_FREE_INVERSE_READ_DENIED'
   if ROLE=='native':assert p not in [str((corebase/(role+'.json')).resolve()) for role in ['primary','replay']],'NATIVE_RAW_REFERENCE_TARGET_READ_DENIED'
 sys.addaudithook(guard)
 role='primary' if ROLE=='native' else 'replay';fj=O.parent/'canonical_so10_full_jet_source_master_bridge';fields=load(fj/(role+'_tables.json.gz'))['field_order'];assert len(fields)==643
 refdefect={(n,n):masses[fields[n].split('_')[1]] for n in range(180,508)}
 if ROLE=='native':
  gf=J.decode(load(O.parent/'canonical_so10_mixed_Ward_positive_coupling/action_tables_v2.json.gz')[0]['original'][0]['density'])
  free={word:c for word,c in gf.items() if len(word)==2 and all(n<643 for n,js in word)}
  phys=load(O.parent/'canonical_so10_physical_current_input_recovery_g1_v1/native_v2_action.json.gz')
  free=w.plus(free,J.decode(phys['S0_gauge']),J.decode(phys['S0_scalar']));euler=J.euler(free,set(range(643)));Pphys={}
  for n in range(643):
   for word,c in euler.get(n,{}).items():
    assert len(word)==1;((j,jets),)=word;z=A.expression(c.terms)*s.I**len(jets)
    for mu in jets:z*=q[mu]
    Pphys[n,j]=Pphys.get((n,j),s.Integer(0))+z
  Pphys=norm(Pphys);assert Pphys==closed_physical(),'ACTUAL_FREE_DENSITY_NOT_CLOSED_CANONICAL_INVERSE'
  Pref=plus(Pphys,refdefect);Gref=closed_green(fields)
 else:
  raw=read(corebase/(role+'.json'))['retained_reference'];frame=load(fj/(role+'_inputs.json.gz'))['frame'];assert raw['field_order']==frame['field_order']
  matrices=lambda rows:{(i,j):s.sympify(z,locals=locals0) for i,j,z in rows}
  T=matrices(frame['physical_to_raw_inverse']['entries']);F=matrices(frame['physical_to_raw_kernel']['entries']);assert mul(F,T)==mul(T,F)==IDENT
  HP=mul(mul(transpose(T),matrices(raw['reference_Hessian_raw_C3']['entries'])),T)
  GP=mul(mul(F,matrices(raw['reference_Green_raw_C3']['entries'])),transpose(F))
  rotation=dict(zip(pm,[s.I*q[0],q[1],q[2],q[3]]));phase={n:A.expression(J.phase(n).terms) for n in range(643)}
  Pref=norm({(i,j):-phase[i]*phase[j]*z.subs(rotation) for (i,j),z in HP.items()})
  Gref=norm({(i,j):-z.subs(rotation)/(phase[i]*phase[j]) for (i,j),z in GP.items()})
  Pphys=plus(Pref,scale(refdefect,-1))
 assert mul(Pref,Gref)==mul(Gref,Pref)==IDENT,'FREE_REFERENCE_INVERSE_DIRECTION'
 assert all((i,j) not in Gref for i in range(508,553) for j in range(508,553))
 print('STAGE '+ROLE+' actual physical/reference inverse and643 two-sided directions',flush=True)
 Rref=plus(Pref,scale(Pphys,-1));Rheat=scale(Pref,1/E-1);Rir=scale(Pref,(1/f-1)/E);Rall=plus(scale(Pref,1/(f*E)),scale(Pphys,-1));GF=scale(Gref,f*E)
 assert Rref==refdefect and plus(Rref,Rheat,Rir)==Rall
 assert mul(plus(Pphys,Rall),GF)==mul(GF,plus(Pphys,Rall))==IDENT
 heatproduct=scale(IDENT,f*(1-E));irproduct=scale(IDENT,1-f)
 assert mul(Rheat,GF)==mul(GF,Rheat)==heatproduct and mul(Rir,GF)==mul(GF,Rir)==irproduct
 refproduct=mul(Rref,GF);assert refproduct==mul(GF,Rref)
 assert mul(Rall,GF)==mul(GF,Rall)==plus(scale(IDENT,1-f*E),refproduct)
 print('STAGE '+ROLE+' complete reference/heat/IR inverse defect products',flush=True)
 def relative_phase(P,which,inverse=False):
  def z(n):return -s.I if which=='time' and n<180 and n%4==0 else s.I if which=='auxiliary' and 508<=n<553 else s.Integer(1)
  return norm({(i,j):c/(z(i)*z(j)) if inverse else c*z(i)*z(j) for (i,j),c in P.items()})
 controls={}
 for name in ['time','auxiliary']:
  badP=relative_phase(Pref,name);badG=relative_phase(Gref,name,True);assert mul(badP,badG)==mul(badG,badP)==IDENT
  controls['wrong_'+name+'_phase']=dict(actual_inverse_mismatch=encoded(plus(badP,scale(Pref,-1))),simultaneously_transformed_inverse_check_blind=True)
 badLL=plus(Gref,{(508+r,508+r):1/q2 for r in range(45)})
 badghost={ij:-c if ij[0]>=553 and ij[1]>=553 else c for ij,c in Gref.items()}
 nomix={ij:c for ij,c in Gref.items() if not(ij[0]<180 and 508<=ij[1]<553 or ij[1]<180 and 508<=ij[0]<553)}
 for name,bad in [('free_LL',badLL),('reversed_ghost_order',badghost),('omitted_mixed_B_L',nomix)]:controls[name]=dict(left_inverse_residual=encoded(plus(mul(Pref,bad),scale(IDENT,-1))),right_inverse_residual=encoded(plus(mul(bad,Pref),scale(IDENT,-1))))
 controls['omitted_reference_defect']=dict(left_inverse_residual=encoded(plus(mul(plus(Pphys,Rheat,Rir),GF),scale(IDENT,-1))))
 controls['omitted_IR_defect']=dict(left_inverse_residual=encoded(plus(mul(plus(Pphys,Rref,Rheat),GF),scale(IDENT,-1))))
 assert all(any(val for key,val in row.items() if key!='simultaneously_transformed_inverse_check_blind') for row in controls.values())
 payload=dict(Pphysical=encoded(Pphys),Preference=encoded(Pref),Greference=encoded(Gref),reference_defect=encoded(Rref),heat_defect=encoded(Rheat),IR_defect=encoded(Rir),full_regulator=encoded(Rall),G_F=encoded(GF),heat_product=encoded(heatproduct),IR_product=encoded(irproduct),reference_product=encoded(refproduct),controls=controls,all643_directions_both_verified=True,free_LambdaLambda_zero=True,physical_scalar_masses_adopted=False,active_M_profiles=dict(E='exp(-t*q_squared)',f='(1-exp(-q_squared/delta_squared))**2'),other_sector_profiles_not_selected=True,full_background_Wick_signs_or_amplitudes_not_inferred=True)
 packet=save(payload);counts={name:{k:len(val) for k,val in row.items() if isinstance(val,list)} for name,row in controls.items()}
 result=dict(schema='ACTUAL_FREE_REGULATOR_INVERSE_RECOVERY_V1',route=ROLE,packet=packet,physical_nonzero_entries=len(Pphys),reference_nonzero_entries=len(Pref),Green_nonzero_entries=len(Gref),scalar_reference_defect_entries=len(Rref),free_LambdaLambda_entries=0,inverse_directions=1286,controls=counts,elapsed_after_imports=time.perf_counter()-tick,scientific_acceptance='NOT_PERFORMED')
 with (O/(ROLE+'_result.json')).open('x',encoding='utf-8',newline='\n') as h:json.dump(result,h,sort_keys=True);h.write('\n')
 print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
