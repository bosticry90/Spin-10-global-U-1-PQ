# Actual free inverse and regulator decomposition, prospective V1

Base84439e529d1457aa2ccb0e1d75e4b4fa8520fc04/main,V790; cleanpostcommit
preflight,no workers,452bindings authenticated. State113/34of39,E5/A5open
unchanged. CurrentAGENTS/charter/D:first. Noagents/branch/worktree/adoption/
promotion/protectedactivation/flavor/remoteaction. Historicalbytes unchanged.

Question: which actual quadratic inverse and regulator insertion must be
used in the V790 exact Gaussian reduction, with the retained Wick/frame,
ghost order,zero freeLambdaLambda,reference scalar masses and finiteIR
defect? This is necessary before evaluating actualcolor/profile amplitudes.

Native derives all643 free physical Hessian rows from literal source-free
quadratics of survivingGFg0+physicalkineticS0; Fourier derivatives ip_mu.
Construct a closed inverse and verify it against actual all643 rows.
Retain canonical widths eta_H/xi without inverting them. Add ONLY the
authenticated positive scalar REFERENCE mass squares to form the qualified
reference inverse; they are not adopted physical masses.

Replay starts from actual retainedrawC3 P/G in frozen_a10_e5_full_hessian,
transports by actual F/T from the source-master frame and Wick rotates
pM0=i q0,spatialpi=qi,field B0=i B0E,LambdaM=-i LambdaE,otherfields1,
and densityminus: P_E=-W^T P_M(iq0) W,
G_E=-W^-1 G_M(iq0) W^-T. No ghost label inferred from raw index508;
use actualframe matrices/fieldorder. Verify both643 inverse directions.
Compare COMPLETE native/replay physical/reference inverses only after
separate output construction. A simultaneous wrong frame transform can
preserve inversion; actual action comparison is necessary.

General independent nonzero profile symbols E,f describe the algebraic
insertion. The active M-sector prescription is the already used heat
E=exp(-tq²), f=(1-exp(-q²/delta²))²; do not replace it with a mass profile.
Other sector profile choices are not adopted; scalar sectors do not return
in V789's selected current. Let F=fE,G_F=F Gref. Preserve
 Rall=Pref/F-Pphys
     =(Pref-Pphys)+Pref(E^-1-1)+Pref E^-1(f^-1-1).
Check exactfree inverse,all643 reference/heat/IR decomposition and both
matrix directions. For activeM,reference defect0, hence Rall G_F=1-F,
Rheat G_F=f(1-E),RIR G_F=1-f. These are free inverse products, NOT a
license to ignore graded Wick signs or trace-transpose/order in a full
background. No actual loop tensor, integral,UV/IR limit or new subtraction.

Controls: wrong time/auxiliary phase versusactualP (inversion alone blind
if both transformed); freeLL introduced; reversedorderedghostinverse;
mixedB/L Greenomitted; scalarreference/physicaldefectomitted. Keep full
matrix residuals/counts and any blind cases,not loop sensitivity claims.

Serialnative/replay180s afterimports each,final180s,8GiBsampledprivate,
350MiBlaunchfloor,complete64MiBnewpacket. No qualified physical/current
factory replay. Preserve all failed/incomplete sources,captures and exact
partial outputs. No truncation,hidden expansion or expensiveautomaticretry.
Final checks source/input/pairedallmatrixrows/inverse/decomposition/controls/
actualresources/state/oldtree and E4once/no-fresh verifiedDcontext,
0,0,0,0,0,2/seven unresolved NOTPASS. Localcommit only aftervalidation.

Outcomes: qualifiedfree/regulatorinput, a Wick/frame/inverse defect or
bounded incomplete. Then build actual regulator vertices and graded
contractions against frozenV789covariance before same-parenttargetaccess.
Shareddata/chart/coefficientring/Sympy/AIauthor limit independence.
Nooutside scientist,proofkernel or empiricalclaim. No scientificacceptance,
QAP/measure/E5/A5/physicalviability promotion; educationnonblocking.
