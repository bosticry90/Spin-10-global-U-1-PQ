from pathlib import Path
from hashlib import sha256
import gzip,importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/regulator-free-inverse-g1-recovery-v1-2026-11-07')
spec=importlib.util.spec_from_file_location('free_inverse_review_tools',O/'inverse.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(x,h,sort_keys=True);h.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'final_preparation.json')['source_sha256'].items():assert digest(R/n)==h,n
 prep=read(O/'preparation.json')
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 for n,h in prep['source_sha256'].items():assert digest(O/n)==h,n
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 a,b=read(O/'native_result.json'),read(O/'replay_result.json');assert (O/a['packet']['file']).read_bytes()==(O/b['packet']['file']).read_bytes()
 assert a['packet']['sha256']==b['packet']['sha256']==digest(O/a['packet']['file'])
 assert {k:z for k,z in a.items() if k not in ['route','packet','elapsed_after_imports']}=={k:z for k,z in b.items() if k not in ['route','packet','elapsed_after_imports']}
 data=load(O/a['packet']['file']);loc={str(z):z for z in [*v.q,v.xi,v.eta,v.E,v.f,*v.masses.values()]}
 def decode(name):
  rows=data[name];out={(i,j):v.s.sympify(z,locals=loc) for i,j,z in rows}
  assert len(out)==len(rows) and all(0<=i<643 and 0<=j<643 and c!=0 for (i,j),c in out.items());return out
 P,Q,G=decode('Pphysical'),decode('Preference'),decode('Greference');ref,heat,ir,reg,GF=[decode(n) for n in ['reference_defect','heat_defect','IR_defect','full_regulator','G_F']]
 assert len(P)==len(Q)==1543 and len(G)==1498 and len(ref)==328
 assert {i for i,j in P}=={j for i,j in P}=={i for i,j in Q}=={j for i,j in Q}=={i for i,j in G}=={j for i,j in G}==set(range(643))
 assert v.mul(Q,G)==v.mul(G,Q)==v.IDENT
 assert not any(508<=i<553 and 508<=j<553 for i,j in G)
 fields=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/primary_tables.json.gz')['field_order']
 assert ref=={(n,n):v.masses[fields[n].split('_')[1]] for n in range(180,508)}
 assert v.plus(Q,v.scale(P,-1))==ref and v.plus(ref,heat,ir)==reg
 assert GF==v.scale(G,v.f*v.E)
 assert heat==v.scale(Q,1/v.E-1) and ir==v.scale(Q,(1/v.f-1)/v.E) and reg==v.plus(v.scale(Q,1/(v.f*v.E)),v.scale(P,-1))
 assert v.mul(v.plus(P,reg),GF)==v.mul(GF,v.plus(P,reg))==v.IDENT
 assert v.mul(heat,GF)==v.mul(GF,heat)==decode('heat_product')==v.scale(v.IDENT,v.f*(1-v.E))
 assert v.mul(ir,GF)==v.mul(GF,ir)==decode('IR_product')==v.scale(v.IDENT,1-v.f)
 assert v.mul(ref,GF)==v.mul(GF,ref)==decode('reference_product')
 assert v.mul(reg,GF)==v.mul(GF,reg)==v.plus(v.scale(v.IDENT,1-v.f*v.E),decode('reference_product'))
 expected={'free_LL':{'left_inverse_residual':225,'right_inverse_residual':225},'omitted_IR_defect':{'left_inverse_residual':643},'omitted_mixed_B_L':{'left_inverse_residual':945,'right_inverse_residual':945},'omitted_reference_defect':{'left_inverse_residual':328},'reversed_ghost_order':{'left_inverse_residual':90,'right_inverse_residual':90},'wrong_auxiliary_phase':{'actual_inverse_mismatch':405},'wrong_time_phase':{'actual_inverse_mismatch':405}}
 assert a['controls']==b['controls']==expected
 for name,rows in data['controls'].items():
  for key,value in rows.items():
   if isinstance(value,list):assert len(value)==expected[name][key] and value
  if name.startswith('wrong_'):assert rows['simultaneously_transformed_inverse_check_blind']
 assert data['all643_directions_both_verified'] and data['free_LambdaLambda_zero'] and not data['physical_scalar_masses_adopted']
 assert data['active_M_profiles']=={'E':'exp(-t*q_squared)','f':'(1-exp(-q_squared/delta_squared))**2'} and data['other_sector_profiles_not_selected'] and data['full_background_Wick_signs_or_amplitudes_not_inferred']
 resources={}
 for role,result in [('native',a),('replay',b)]:
  cap=read(O/(role+'_capture.json'));assert cap['exit_code']==0 and cap['calculation_completed'] and cap['execution_state']=='COMPLETED' and cap['post_run_observations_qualified']
  assert result['elapsed_after_imports']<=180 and cap['launch']['memory']['available_pagefile']>=350*1024**2 and all(0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
  resources[role]=dict(seconds_after_imports=result['elapsed_after_imports'],largest_private_sample=max(z['private_bytes'] for z in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True)
 print('STAGE final paired full matrices,two inverse directions,all reference/heat/IR defects verified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
 cap=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',cap);dump(C/'e4_capture.json',cap);assert p.returncode==0
 events=[json.loads(z) for z in p.stdout.splitlines() if z.strip()];exits=[z['exit_code'] for z in events if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED'
 assert next(z for z in events if z['event']=='step_finished' and z['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 old=(C/'old_git_tree.txt').read_bytes();assert old==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True)
 state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V791.md'];size=sum(p.stat().st_size for p in files);assert size<=64*1024**2
 result=dict(schema='REGULATOR_FREE_INVERSE_G1_RECOVERY_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_ACTUAL_FREE_FRAME_WICK_INVERSE_AND_REFERENCE_HEAT_IR_DECOMPOSITION',scientific_acceptance='NOT_PERFORMED',base_HEAD=prep['base_HEAD'],state_sha256=state,paired_math_sha256=a['packet']['sha256'],full_native_replay_math_byte_equal=True,all643_inverse_directions_both_checked=True,physical_inverse_entries=len(P),reference_inverse_entries=len(Q),Green_entries=len(G),free_LambdaLambda_zero_block_entries=2025,scalar_reference_defect_entries=len(ref),profiles_IR_defect_preserved=True,controls=expected,joint_wrong_frame_inverse_control_blind=True,resources=resources,failures_this_increment=0,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(old.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_background_graded_Wick_or_actual_amplitude_QAP_E5_viability_claim=False)
 dump(O/'validation_receipt.json',result);print('RESULT '+json.dumps({k:result[k] for k in ['execution_state','evidence_validation','E4_step_exits','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
