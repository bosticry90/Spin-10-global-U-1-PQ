# Actual free inverse for the recovered current regulator

This qualifies the free inverse entering the V790 Gaussian reduction in
the original Euclidean A0 gauge/scalar domain. Native actual-action Euler
derivatives and replay raw-C3 matrix transport agree on the complete
physical/reference inverse, Green function and reference/heat/IR defects.
It supplies the actual quadratic regulator input. It does not evaluate
the full-background graded Wick contractions or g1 loop amplitudes.

## Two constructions and the actual frame bridge

Native extracts all source-free quadratic terms from actual MWP GFg0,
adds V787's literal physical S0 gauge/scalar kinetic action, derives all
643 field Euler rows, and Fourier replaces each derivative by iq_mu.
It checks all resulting coefficients against the closed canonical block
inverse. Native is denied scientific reads of both raw retained-reference
files after their declared-byte authentication; the raw target does not
construct its physical Hessian. Scalar reference masses are then added
according to the already qualified reference prescription, with canonical
scalar sector names from the actual FJB field order.

Replay starts from the original raw retained reference Hessian/Green in
frozen_a10_e5_full_hessian. With the actual field-frame matrices, it forms
Pcan=T^T Praw T and Gcan=F Graw F^T and checks F T=T F=identity in all643
coordinates. Raw ghosts start at508 while canonical ghosts start at553;
the complete matrices and actual raw field order handle this difference.
No interpretation is copied from an equal raw integer index.

The recorded action Wick convention is pM0=iq0, pMi=qi, B0M=iB0E,
LambdaM=-iLambdaE, other fields unchanged, and overall density minus.
For the diagonal field-phase matrix W, replay consequently uses

    P_E = -W^T Pcan(iq0) W,
    G_E = -W^-1 Gcan(iq0) W^-T.

All other signs and color normalization come from the actual transported
matrices. The native/replay complete packet is byte-identical, SHA
cffaed465f92935970ae2d23d1411e1380ea66ccbfcc269a9ceaccd0a3cc71f8.
Both sides verify the full sparse products against the643-coordinate
identity in BOTH directions, including every implied zero among413449
matrix positions. There is no matrix-element truncation or numerical fit.

## Qualified closed free blocks

Let q²=sum_mu q_mu² and Omega_r=eta_H for r<12, xi for r>=12. For each
color the actual physical free block is

    P_Bmu,Bnu = q² delta_mu,nu - q_mu q_nu,
    P_Bmu,Lambda = q_mu,  P_Lambda,Bnu = -q_nu,
    P_Lambda,Lambda = Omega_r.

Its Green block is

    G_Bmu,Bnu = delta_mu,nu/q² + (Omega_r-1)q_mu q_nu/q^4,
    G_Bmu,Lambda = -q_mu/q²,  G_Lambda,Bnu = q_nu/q²,
    G_Lambda,Lambda = 0.

No width is inverted, so this is a formal nonexceptional-momentum identity
without choosing a new gauge-width value. In the ordered ghost pair,

    P_C,a=-q², P_a,C=q²;   G_C,a=1/q², G_a,C=-1/q².

Both ghost signs belong to the Gaussian ordering. The entire45x45
LambdaLambda Green block has2025 exact zeros. A LambdaLambda action or u
vertex is still permitted; it is not a free Green edge.

The scalar physical kinetic block is q². The qualified reference has
q²+Mref_sector_squared with Green1/(q²+Mref_sector_squared). Its328
diagonal reference mass entries are retained as the difference between
the reference and physical free inverse. These positive reference masses
are not adopted physical mass parameters. The selected V789 g1 current
has no returning scalar quantum sector; no new scalar profile or physical
mass choice is inferred from this check.

There are1543 nonzero physical inverse entries,1543 reference inverse
entries and1498 reference Green entries. These are complete sparse
matrices, not sampled directions. Each row and column of all643 fields
is represented, including every ghost and auxiliary coordinate.

## The full finite-profile inverse defect

Use nonzero commuting symbols E,f and F=fE for this free matrix identity.
The already used active-M profile is E=exp(-tq²) and
f=(1-exp(-q²/delta²))². No mass-profile replacement, different cutoff
or profile choice in a nonreturning scalar sector is adopted here.
With G_F=F Gref the actual added quadratic inverse is

    Rall = Pref/(fE) - Pphysical
         = Rref + Rheat + RIR,
    Rref  = Pref-Pphysical,
    Rheat = Pref*(E^-1-1),
    RIR   = Pref*E^-1*(f^-1-1).

The complete matrices verify (Pphysical+Rall)G_F=G_F(Pphysical+Rall)=I.
Both orders of each free defect product agree and give

    Rheat G_F = f(1-E) I,
    RIR G_F   = (1-f) I,
    Rref G_F  = F*(Pref-Pphysical)Gref,
    Rall G_F  = (1-F)I + Rref G_F.

Rref is zero in the active M gauge/ghost block. Thus its exact free root
factor is1-F, which splits into f(1-E) and1-f. Heat-only replacement
would omit the second piece. If a second marked root supplies1-F, the
omitted product becomes(1-f)(1-F), the same finite-profile inverse defect
retained in V783. This consistency is algebraic; no root limit or integral
is assigned zero at finite delta. Uniform removal bounds, finite constants
and the UV-first/IR limit order are still separate obligations.

These are free matrices with even coefficients. They do not authorize
ordinary trace cyclicity through odd mean/source coefficients in a full
background. The next contraction must retain actual LEFT polynomial
order and the relation between Euler inverse matrices, ordered covariance
and the corresponding graded matrix representation. A simultaneous
transpose or hand-added ghost sign can change an amplitude despite a
correct free inverse. V790's independent finite fixture remains relevant.

## Controls, limits and next calculation

Wrong B0 phase or wrong Lambda phase changes405 actual reference Hessian
entries apiece. Simultaneously transforming both the wrong Hessian and its
Green still gives an inverse, and is explicitly BLIND as an inversion-only
test. Agreement with the independently derived actual action supplies
the missing frame/Wick check.

Adding a free LambdaLambda Green gives225 nonzero residual entries in
each inverse direction. Reversing the ordered ghost Green gives90 each;
omitting the mixed B/Lambda Green gives945 each. Dropping the reference
defect gives328 inverse residuals; dropping the IR defect gives643.
Complete residual matrices remain stored. These controls test the free
operator, not measured g1 amplitude sensitivity or physical truth.

Native37.158811s and replay46.215644s complete under180s each,serial,
8GiBsampled private/350MiB launchfloor/64MiB complete newpacket. Final
validation owns paired full rows,inverse/defect/control/resource/source/
state/oldtree and E4once/no-fresh on the verified D:context,expected
0,0,0,0,0,2 with seven unresolved custody references NOTPASS. No worker
failed this increment; all prior failures and frozen sources are unchanged.

Next construct the actual first-u,g1 regulator vertices from these inverse
kernels and full recovered F maps. Check the graded contraction convention
against literal exterior fixtures, then reduce actual color and derivative
numerators and expand against the already frozen V789 covariance. Keep
reference,heat and IR pieces distinct until their full sum is compared.
Only afterward read the same-parent QGamma/D target. No guessed nine-M
list,contact fit,baseline choice or physical/current-factory replay is needed.

Both calculations share the action architecture,frame,ring,Sympy and AI
author. Their agreement tests implementation/frame errors, not independent
scientific replication. No outside scientist,proof kernel or experiment is
claimed. State113/34of39,E5/A5,common normalization/reality,QAP/measure/
equivalence,physical viability and the full investigation remain open.
