# Actual regulator vertices and graded Wick bridge recovered

All full root polynomials and catalogs agree between native/replay routes.
The graded fixture independently matches all36 literal Wick covariances
and detects five wrong conventions at mixedgu. All643 field columns and
full source terms participate in the actual regulator vertices.

Whole-operator proofs remove the original free F0 root and the local scalar
reference-mass root. Nonzero probe free roots remain. The regulator
representation has46 M-vector and8 M-source labeled candidates; H channels
have none. All8 source candidates reduce to an original F1 ghost root plus
the original Lambda and probe Ja ghost mass vertices. This makes actual
source-color evaluation the next competent calculation.

The counts are candidate paths, not amplitudes or a recovered nine-M list.
The [proof](PROOF.md) states the full convention,polynomials,cancellations,
controls and limitations; the [receipt](validation_receipt.json) owns final
validation and resources. No physical baseline or normalization is adopted.
State113/34of39,E5/A5 and custody exit2/seven NOTPASS remain unchanged.
