from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
import gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
ROLE=sys.argv[1] if __name__=='__main__' else 'native'
spec=importlib.util.spec_from_file_location('qualified_regulator_catalog_algorithms',O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1/catalogs.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
w=v.w;old=v.old
def save(data):
 blob=gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/(ROLE+'_catalog.json.gz')).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=128*1024**2
 return dict(file=ROLE+'_catalog.json.gz',sha256=sha256(blob).hexdigest(),bytes=len(blob))
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 prep=w.read(O/'catalog_preparation.json')
 for n,h in prep['input_sha256'].items():assert w.digest(R/n)==h,n
 for n,h in prep['source_sha256'].items():assert w.digest(O/n)==h,n
 peer=str((O/('replay_' if ROLE=='native' else 'native_')).resolve())
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):assert not str(Path(os.fsdecode(args[0])).resolve()).startswith(peer),'PEER_REGULATOR_CATALOG_READ_DENIED'
 sys.addaudithook(guard)
 roots=w.load(O/(ROLE+'_root_assemblies.json.gz'))['assemblies'];ordinary=w.load(O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1'/(ROLE+'_whole_inventory.json.gz'))['catalogs'];catalogs=[];rootgroups={}
 for ch in ['vector','source']:
  groups=[]
  for row in roots:
   if row['family']=='reference':assert not row['projections'][ch]['integrated'];continue
   raw=row['projections'][ch]['integrated'];by=defaultdict(list)
   for at,(word,mon,cells) in enumerate(raw):
    qq=[];ext=[0]*4;copies=[0,0]
    for n,js in word:
     if 1319<=n<1962:qq.append(old.tag(n-1319));copies[0]+=1
     elif 1962<=n<2605:qq.append(old.tag(n-1962));copies[1]+=1
     else:
      t=old.mean(n);assert t is not None;ext[t]+=1
    assert copies==[1,1] and all(a<=b for a,b in zip(ext,v.TARGETS[ch])) and all(key[0]==row['g'] for key,num,den in cells)
    sig=('R_'+row['state'],'marked',row['g'],row['u'],tuple(qq),tuple(ext));by[sig].append(at)
   groups.append(dict(state=row['state'],raw_integrated_monomials=len(raw),raw_integrated_math_sha256=sha256((json.dumps(raw,sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest(),groups=[dict(signature=[a,b,c,d,list(e),list(f)],raw_monomial_indices=ids) for (a,b,c,d,e,f),ids in sorted(by.items())]))
  rootgroups[ch]=groups
  for probe in [0,1]:
   prev=next(z for z in ordinary if z['channel']==ch and z['probe']==probe)
   sigs={v.signature(c) for c in prev['classes'] if c['kind']=='ordinary'}
   for z in groups:
    if z['state'] in ['Fu0_'+str(1-probe),'Fu1_'+str(1-probe)]:continue
    for group in z['groups']:
     a,b,c,d,e,f=group['signature'];sigs.add((a,b,c,d,tuple(e),tuple(f)))
   classes=[dict(id=i,owner=a,kind=b,g=c,u=d,quantum=list(e),external=list(f)) for i,(a,b,c,d,e,f) in enumerate(sorted(sigs))]
   actual=v.catalog(classes,ch,ROLE);wrong={name:v.catalog(classes,ch,ROLE,mode=mode) for name,mode in [('wrong_HM_mixing','mix_HM'),('wrong_free_LL','LL'),('wrong_unrestricted_edges','unrestricted')]}
   omitted=dict(omit_inverse_U=v.catalog(classes,ch,ROLE,omit='inverse_U'),omit_explicit_u_root=[row for row in actual if classes[row[0]]['u']==0],omit_physical_ordinary=[row for row in actual if not any(classes[i]['owner'].startswith('physical') for i,o in row[2])],omit_original_GF_g1_ordinary=[row for row in actual if not any(classes[i]['owner']=='GF_original' and classes[i]['g']==1 for i,o in row[2])])
   active={q for r,ro,path in actual for i in [r]+[j for j,o in path] for q in classes[i]['quantum']};rootcounts=Counter(classes[row[0]]['owner'] for row in actual)
   catalogs.append(dict(channel=ch,probe=probe,classes=classes,complete_rooted_oriented_cycles=actual,wrong=wrong,omitted=omitted,root_state_counts=dict(sorted(rootcounts.items())),active_quantum_types=sorted(active),proved_total_vertex_bound=6,candidates_not_amplitudes=True))
   print('STAGE '+ROLE+' complete regulator catalog '+ch+' probe'+str(probe)+' cycles'+str(len(actual)),flush=True)
 packet=save(dict(root_groups=rootgroups,catalogs=catalogs,reference_root_excluded_by_whole_local_operator_zero=True,full_ordinary_owners_from_V789=True))
 summary=[dict(channel=z['channel'],probe=z['probe'],cycles=len(z['complete_rooted_oriented_cycles']),root_state_counts=z['root_state_counts'],active_quantum_types=z['active_quantum_types'],max_vertices=max((len(row[2])+1 for row in z['complete_rooted_oriented_cycles']),default=0),wrong={k:len(p) for k,p in z['wrong'].items()},omitted={k:len(p) for k,p in z['omitted'].items()}) for z in catalogs]
 out=dict(schema='ACTUAL_REGULATOR_ROOT_RETURNING_CATALOG_V1',route=ROLE,packet=packet,summary=summary,elapsed_after_imports=time.perf_counter()-tick,scientific_acceptance='NOT_PERFORMED')
 with (O/(ROLE+'_catalog_result.json')).open('x',encoding='utf-8',newline='\n') as h:json.dump(out,h,sort_keys=True);h.write('\n')
 print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
