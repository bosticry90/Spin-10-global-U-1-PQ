# Actual polarized regulator vertices and returning sectors

This completes the next actual-input step after V791. The full regulator
vertices are constructed from all643 source-first field operations, with
two distinct labeled fluctuation legs and exact independent momenta.
Native/replay full polynomials and catalogs agree. The domain remains the
original unshifted Euclidean A0, integrated constant mark, firstu,g1,
intrinsic0/1 gauge/scalar investigation and BLambdaC/LambdaJaC profiles.
No loop integral or physical/scientific acceptance is performed here.

## Graded Gaussian convention is now tested

For a linear polynomial of parityt, write P=sum_i f_i eta_i with each
coefficient f_i on the LEFT. Then

    f_i=(-1)^(p_i(t+p_i)) partialleft_i P.

For P_z=T1F_z and E_z=T1(ELleft_z S), this yields

    Fleft_zi=(-1)^(p_i p_z) partialleft_i P_z,
    Hleft_zj=(-1)^(p_j(p_z+1)) partialleft_j E_z.

The ordinary ordered matrix inverse of Hleft is the ordered Wick
covariance G_ij=<eta_i eta_j>. With odd external coefficients retained,

    <sum P_z E_z> = sum_zij (-1)^(p_i(p_z+p_j))
                       Fleft_zi Hleft_zj G_ij.

The sign moves the H coefficient past eta_i. In the free regulator R,
nonzero entries have p_z=p_j and even coefficients, so this crossing
sign equals1. No extra ghost trace sign is added after coefficient normal
ordering. Source coefficient order remains literal throughout.

The new exact fixture reuses V790's frozen mathematical inputs and saved
full exterior weight. It computes all36 normalized covariances by literal
exterior/even-Gaussian integration and by a separate Fraction matrix
inverse/Born expansion. Both matrix inverse directions agree, and the
complete Born expansion terminates after degrees1,2 at firstg/firstu.
The general and free-regulator contractions reproduce the literal current
and local Jacobian. The regulator/theta equals

    157g/150 + 13u/50 - 16963gu/189000.

All five wrong whole conventions have nonzero gu residuals: raw LEFT F
without coefficient normalization, transposed covariance, omitted odd H
coefficient crossing, extra manual ghost trace sign, and missing second
Born term. Full wrong covariance matrices and residual coefficients are
saved. Fixture input/exterior software is shared; integration and matrix
inverse are distinct algorithms, not independent scientific authors.

## Actual full ordered root polynomials

For each F0,F1,Fu0_H,Fu0_M,Fu1_H,Fu1_M the new output stores complete
643-column T1F tables and every field's raw products with Pref and
Pref-Pphysical from V791. Native reuses the qualified full T1F data.
Replay derives the full LEFT jet Jacobian directly from the field F maps,
then applies the verified coefficient normalization. Neither route reads
its peer's new output. Both include full sources before projection.

The two quantum legs remain etaF_(1319+field), etaR_(1962+field), carrying
independent k,l. Quantum jets on etaF become (ik)^alpha; the other leg
carries Pref(l). Mean jets remain literal. Exact coefficients are sparse
polynomials in k,l and four reference mass squares over the original
algebraic/gauge-parameter ring. Equal odd field labels at different momenta
are never collapsed prematurely. Full unit products and source operand
hashes, zero field dispositions, aggregate polynomials and every kept/
rejected target-profile monomial index remain available.

The regulator is represented as the local reference root plus factorized
Pref numerators with heat multiplier E_l^-1-1 and IR multiplier
(f_l^-1-1)/E_l. These are insertions with their adjacent regulated line,
not a standalone inverse heat acting on arbitrary Schwartz fields.
The original f=(1-exp(-l²/delta²))², all finite profiles and UV-first/IR
order remain unchanged. No scalar-reference or intrinsic shortcut is used
to discard a root before its actual operator/type proof.

All8 complete native/replay root math files are byte-identical. The raw
F1 Pref root has232052 momentum monomials; vector/source selections have
167916/121044. The Fu0_H selections have240, Fu0_M3060, Fu1_H0,
and Fu1_M11872/1184. Counts describe polarized momentum monomials,
not historical density words, component amplitudes or the missing nine-M.

## Two whole-operator cancellations, with nonzero probes retained

The original F0 Pref root has1440 zero-mean monomials. Its explicit
graded halfedge-exchange normal form at l=-k vanishes. The paired field
colors and gauge/ghost blocks match, so their common even profile agrees
on the exchanged legs. This proves an integrated whole-root zero and
removes no individual factor. It is not a nonconstant local-mark claim.

The Fu0_H/M free groups have240/660 monomials with480/1320 nonzero
exchange-normal monomials; Fu1_M has1184 free and2368 nonzero normal
monomials. They are RETAINED. The method does not assume every free
group vanishes or inherit the original current's free cancellation.

After mean restriction the F1 scalar reference-mass root has12560
monomials in either channel. It has no quantum momentum/jet coefficient;
identifying its two copies therefore computes the actual local diagonal
functional. Its WHOLE sum vanishes by the full antisymmetric scalar
generator contraction. All other selected reference roots are zero.
The stored complete diagonal proofs justify removing the reference family.
Omitting the first nonzero scalar field unit gives a nonzero local
remainder, saved as a control. No reference or physical mass is changed.

## Complete returning catalog in the regulator representation

Join integrated actual Pref roots with ALL qualified V789 ordinary
vertices, including physical gauge/scalar g1 and every inverse-U
quadratic. All raw root monomials are assigned a joint pair of quantum
types and a mean-profile class. Native oriented DFS and replay unordered
bags/all orders/halfedges produce byte-identical complete catalogs, SHA
f39228b8e268138bdc0f3059ec36377c07bb223b44118305396bef099c8497e6.
The existing six-total-vertex completeness bound is retained: external
degree3 plus at most two g/u-costly zero-arity ordinary vertices plus
the marked root. No nonreference g0u0 zero-arity ordinary is allowed.

| Channel/probe | Labeled candidates | Root breakdown |
| --- | ---: | --- |
| BLambdaC H | 0 | none |
| BLambdaC M | 46 | F1:26,Fu0_M:18,Fu1_M:2 |
| LambdaJaC H | 0 | none |
| LambdaJaC M | 8 | F1:8 |

Vector paths use at most four vertices; source paths at most three.
All active vector quantum types are BM,LM,CM,antighostM. The source
has ONLY CM/antighostM and an original F1 root carrying the mean C.
Its two ordinary vertices are original g0 GF and probe-M g0 GF: the
Lambda ghost mass and probe Ja ghost mass. No physical ordinary,
original GFg1 ordinary, explicit-u root or inverse-U quadratic returns
in this source representation. This is a complete typed reduction,
not a transferred scalar or source zero in the vector channel.

The46/8 catalogs regroup the V789106/12 covariance candidates through
V790's actual Gaussian identity. They are different labeled necessary-
support representations of the same qualified operator. A lower count
does not prove numerical equality or a nonzero amplitude. Actual color,
derivative/Lorentz and finite-profile comparison remains necessary.

For M vector, omit explicit-u roots leaves26, omit inverse-U quadratics36,
omit original GFg1 ordinary36, omit physical ordinary38. Wrong H/M edges
give150, wrong freeLambdaLambda74, unrestricted5328. For H vector these
wrong graphs give80,0,4416. For M source wrong H/M gives30, wrongLL
is blind at8, unrestricted528; all tested omissions are blind at8.
H source gives4,0,192. Full wrong/omission lists remain stored. Kernel
coefficient-normal-order control changes8032 F1 monomials and2400
Fu0_M monomials in each selected channel; other root states are blind.
These are operator/type controls, not measured integral sensitivity.

## Significance, verification and next discriminating calculation

This executes the step missing from the preceding no-progress turn:
actual polarized regulator vertices, a graded covariance convention
verified against literal integration, and a substantially reduced complete
source sector. It tests recoverable implementation and ordering errors.
It does not validate shared physical assumptions: action,chart,ring,
root multiplication/canonicalizer and AI author remain shared. No outside
scientist,proof kernel or empirical result is claimed.

Fixture0.038012s under60s; roots51.386570/52.762059s under180s;
catalogs11.297501/10.817610s under180s. All serial,8GiBsampled/350MiB
launchfloor/128MiB newpacket. Final receipt owns raw-unit reconstruction,
independent mean/type partitions, whole root proofs, full graphs,
resources/state/oldtree and E4once/no-fresh D:context0,0,0,0,0,2,
seven unresolved custody references NOTPASS. No worker failed here.

Next evaluate the eight source paths' actual ghost-generator/Ja/Lambda
color matrices before the larger vector contraction. Derive both ordered
momentum kernels with full profiles and normalization from the checked
Wick convention; retain each ordering before any color sum or UV/IR limit.
Freeze that covariance output before same-parent QGamma/D target access.
Then reduce the46 vector candidates, preserving all three root states and
the eight physical-ordinary paths. No guessed nine-M restart, contact fit,
finite baseline or normalization adoption. State113/34of39,E5/A5,
common normalization/reality,QAP/measure/equivalence and viability stay open.
