# Regulator-root returning catalog, prospective

Both180srootworkers completed in51.386570/52.762059s; all8pairedmath
files are byte-identical. FullF0Prefroot1440monomials haszero graded
exchange normal form at l=-k and commonevenmatchedprofiles. Positive
probe free roots haveNONZEROnormal forms and are retained. Localreference
mass roots have12560 selectedF1monomials perchannel butwholecopy-diagonal
zero; allotherselectedreference rootszero. Do not transferthesewholezeros
toindividualpieces or nonconstantmarks. No amplitude or scienceacceptance.

Now classify actual integrated Prefroot monomials by jointquantum endpoints
and meanprofile, preservingFstate/g/u and allrawrowindices. Join ALLordinary
classes fromqualifiedV789,includingphysicalg1 andinverseU. Native oriented
DFS and replay unorderedbags/allorders/halfedges must yieldcomplete same
catalog. Reuseexistingprovedsix-total-vertex bound; ordinaryzeroaritymust
costgoru. Derive newcounts without fitting106/12 oroldnine-M. Savefull
wrongHM/freeLL/unrestricted/omissioncatalogs andstate/ownerbreakdowns.
Referencefamily isexcluded ONLYbyalreadycomputedwholelocaloperatorzero.

Eachserialcatalogworker180s afterimports,8GiBsampled/350MiBfloor/existing
128MiBcompletepacket. No loops/physicalfactory rerun,truncation or hidden
retry. Freezeallinputs/sources and comparecompletedoutputs beforedependent
color work. Finalreviewmustverifywholeoperator proofs and partitions.
