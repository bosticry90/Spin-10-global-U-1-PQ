# Actual regulator vertices and graded Wick bridge, prospective V1

Base1da9640c96673ec4c3d1b7aaf0b1218fb020b024/main,V791. Previousgoalturn
NO_PROGRESS: it reread objective/preflight and restated existing commits;
liveHEAD still1da9640c,clean,no workers. This increment must execute new
scientific evidence. Fullobjective read; currentAGENTS/charter/D:first.
State113/34of39,E5/A5open unchanged. Noagents/branch/worktree/adoption/
promotion/protectedactivation/flavor/remoteaction. Oldbytes immutable.

Question: what are the ACTUAL first-u,g1 regulator bilinear vertices from
the full recovered F maps and V791 inverse, with the correct odd ordering?
This supplies the color/derivative contractions needed to reconcile V789's
106vector/12source covariance candidates, without guessing oldnine-M data.

1. First freeze/run a small exact graded bridge. Reuse V790's finite
exterior fixture input assignments and saved full weight, not its current
answer as an operand. Derive LEFT-normal coefficient matrices H,F from
actual polynomials, compute the complete normalized36-entry covariance
by literal integration and independent finite matrix Born inverse, then
compare full/regulator contractions. For a linear polynomial of parityt,
coefficient-to-the-LEFT of eta_j is (-1)^(p_j(t+p_j))*partialleft_j.
Thus Fleft_zi=(-1)^(p_i p_z)*partialleft_i P_z and
Hleft_zj=(-1)^(p_j(p_z+1))*partialleft_j E_z. General contraction includes
moving the H coefficient past eta_i: (-1)^(p_i(p_z+p_j)). Rfree has even
coefficients and p_z=p_j, so this extra sign is1 there. Do not impose an
additional ghost trace factor after these normal forms. Test wrong normal
forms,transposed covariance,odd-coefficient crossing,extra trace sign and
missing second Born term; retain exact residuals and all blind slices.

2. Only after the bridge passes construct actual ordered root numerators
sum_z(T1F_z)(Pref eta)_z and sum_z(T1F_z)((Pref-Pphys)eta)_z for all six
maps F0/F1/Fu0_H/Fu0_M/Fu1_H/Fu1_M,all643fields,full sources beforemean
projection. Native reuses V789 fullrawT1F; replay takes LEFT derivatives
directly from full F with the verified coefficient normal form. Preserve
field/term dispositions,full polynomials and exact projection journals.

Keep two LABELED quantum halfedges: etaF at1319 and etaR at1962. Their
momenta k,l are distinct and quantum jets become (ik)^alpha on etaF and
Pref(l) on etaR. Never identify odd same-field modes prematurely. Mean
C and either quantum copy remain separate. Externalmeanjets stay literal.
Use exact sparse momentum-polynomial coefficients over the existing ring,
including reference mass squares as formal reference factors. Keep entire
reference/Pref numerators; attach Rheat=(E_l^-1-1)Pref and
RIR=E_l^-1(f_l^-1-1)Pref only as factorized insertions with their adjacent
regulated line. No standalone inverse heat acting on arbitrary Schwartz
fields. Preserve original f=(1-exp(-l²/delta²))² and UV-first/IR order.

Targetmeanbudgets vectorBLambdaC=(1,1,1,0),sourceLambdaJaC=(0,1,1,1).
Apply mean restrictions only after full source/jet operations; all rejected
raw factors/products remain available. No intrinsic or scalar-reference
mass shortcut may replace full operator/type evidence. A whole integrated
free root can be removed only with an explicit graded halfedge-exchange
and l=-k proof; keep it if its normal form is nonzero. All nonzero profiles,
source ports,explicit-u/inverseU and physical ordinary owners remain needed.

Resources: serial fixture60s,eachnative/replayroot180s afterimports,
optional dependent completecatalog workers180s each,final180s;
8GiBsampledprivate,350MiBlaunchfloor,complete128MiBnewpacket. Full source/
action/current factories are reused,not rerun. Preserve failed/incomplete
sources/captures; no truncation,hidden expansion or automatic expensive retry.
Freeze any dependent catalog/final sources before their calculation and
compare completed root outputs first. Finalsource/input/pair/partition/
resource/state/oldtree/E4once-no-freshverifiedDcontext expected0,0,0,0,0,2
withseven unresolved custodyNOTPASS. Localcommit onlyaftervalidation.

Authority ceiling: actual regulated-vertex and graded-operator evidence,
not loop integral/UV finiteconstant/fullQAP/measure/E5/A5/physicalviability
or physicalnormalization adoption. Sharedaction/chart/ring/AIauthor limit
independence; fixture reuses frozen numericalinput/exterior software but
matrixinverse and literalWick algorithms differ. Nooutside/proofkernel/
empiricalclaim; director educationvoluntary/nonblocking.
