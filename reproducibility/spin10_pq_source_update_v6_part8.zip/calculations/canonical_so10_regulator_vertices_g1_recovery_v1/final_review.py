from pathlib import Path
from hashlib import sha256
import gc,gzip,importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/regulator-vertices-g1-recovery-v1-2026-11-07')
spec=importlib.util.spec_from_file_location('actual_root_final_tools',O/'roots.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
J=v.J
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def wordkey(row):return row[0],row[1],tuple(tuple(z) for z in row[2])
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 finalprep=read(O/'final_preparation.json')
 for n,h in finalprep['source_sha256'].items():assert digest(R/n)==h,n
 for name in ['fixture_preparation.json','root_preparation.json','catalog_preparation.json']:
  prep=read(O/name)
  for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
  for n,h in prep['source_sha256'].items():assert digest(O/n)==h,n
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 pairs=[]
 for a in sorted(O.glob('native_*.json.gz')):
  b=O/a.name.replace('native_','replay_',1);assert a.read_bytes()==b.read_bytes();pairs.append(dict(native=a.name,replay=b.name,sha256=digest(a)))
 assert len(pairs)==9
 fields=load(R/'calculations/canonical_so10_full_jet_source_master_bridge/primary_tables.json.gz')['field_order']
 def classify(word,target):
  copies=[0,0];ext=[0]*4
  for n,js in word:
   if 1319<=n<1962:copies[0]+=1;continue
   if 1962<=n<2605:copies[1]+=1;continue
   if n<643:
    name=fields[n]
    if name.startswith('B'):slot=0
    elif name.startswith('L') or name.startswith('b') and not name.startswith('bar'):slot=1
    elif name.startswith('C'):slot=2
    else:return 'FORBIDDEN_MEAN'
   elif 643<=n<1286 and fields[n-643].startswith(('bar','ub')):slot=3
   else:return 'FORBIDDEN_MEAN'
   ext[slot]+=1
  if copies!=[1,1]:return 'NOT_ONE_OF_EACH_QUANTUM_HALFEDGE'
  if any(a>b for a,b in zip(ext,target)):return 'EXTERNAL_PROFILE_EXCEEDED'
  return None
 factors=load(O/'native_raw_T1_F.json.gz');roots=load(O/'native_root_assemblies.json.gz')['assemblies'];rootmap={(z['state'],z['family']):z for z in roots}
 original=load(R/'calculations/canonical_so10_full_current_inventory_g1_recovery_v1/native_raw_T1_factors.json.gz')
 assert all(factors[name]==original[name] for name in v.NAMES);del original;gc.collect()
 reference=load(R/'calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1/native_inverse.json.gz');matrices={family:v.reference_rows(reference,name) for family,name in [('preference','Preference'),('reference','reference_defect')]};del reference
 verified_units=raw_products=partitions=0
 for name in v.NAMES:
  data=load(O/('native_units_'+name+'.json.gz'));F=dict(factors[name]);assert list(F)==list(range(643));seen=set();aggregate={family:{} for family in matrices};wrong={family:{} for family in matrices}
  for row in data['units']:
   n=row['field'];assert n not in seen;seen.add(n);raw=F[n];assert raw and row['full_T1_F_sha256']==v.mhash(raw) and row['full_T1_F_words']==len(raw);P=J.decode(raw)
   for family,matrix in matrices.items():
    computed,bad=v.unit(P,n,matrix);saved=v.decode(row['families'][family]['raw_product']);assert computed==saved
    rowhash=v.mhash([[j,list(mon),v.w.enc(c)] for j,mon,c in matrix.get(n,[])])
    assert rowhash==row['families'][family]['matrix_row_sha256'];v.add(aggregate[family],saved);v.add(wrong[family],bad);raw_products+=len(saved)
   verified_units+=1
  for n,label in data['zero_units']:assert n not in seen and label=='ZERO_FULL_T1_F' and not F[n];seen.add(n)
  assert seen==set(range(643))
  for family in matrices:
   row=rootmap[name,family];P=v.clean(aggregate[family]);assert P==v.decode(row['raw_root']);free,normal=v.free_exchange(P)
   assert free==v.decode(row['free_proof']['raw_free']) and normal==v.decode(row['free_proof']['graded_exchange_at_l_minus_k']) and row['free_proof']['whole_free_zero']==(not bool(normal))
   if name=='F0' and family=='preference':
    for word,mon in free:
     bases=[n-1319 if n<1962 else n-1962 for n,js in word]
     colors=[n//4 if n<180 else n-508 if n<553 else n-553 for n in bases]
     assert colors[0]==colors[1] and any(553<=n<598 for n in bases) and any(n<180 or 508<=n<553 for n in bases)
   for ch,target in v.TARGETS.items():
    proj=row['projections'][ch];raw=row['raw_root'];seenrows=bytearray(len(raw));selected={}
    for at in proj['kept_raw_indices']:
     assert not seenrows[at] and classify(raw[at][0],target) is None;seenrows[at]=1;selected.update(v.decode([raw[at]]))
    for group in proj['rejected']:
     for at in group['raw_indices']:assert not seenrows[at] and classify(raw[at][0],target)==group['reason'];seenrows[at]=1
    assert all(seenrows) and selected==v.decode(proj['selected']);partitions+=len(raw)
    reduced=dict(selected)
    if not normal:
     for key in free:reduced.pop(key,None)
    if family=='reference':
     diagonal=v.diagonal(selected);assert diagonal==v.decode(proj['reference_diagonal']) and not diagonal
     assert all(not any(mon[:8]) for word,mon in selected)
     if not diagonal:reduced={}
     control=proj['omit_first_reference_unit_control']
     if control:
      unitrow=next(z for z in data['units'] if z['field']==control['omitted_field']);unitP=v.decode(unitrow['families'][family]['raw_product']);unitP,_=v.project(unitP,ch);unitD=v.diagonal(unitP)
      assert unitD and v.decode(control['identified_difference'])=={key:-c for key,c in unitD.items()}
    assert reduced==v.decode(proj['integrated']);bad,_=v.project(v.clean(wrong[family]),ch);assert bad==v.decode(proj['wrong_F_coefficient_normal_order_difference'])
  del data,aggregate,wrong;gc.collect();print('STAGE final all643 full products,partitions and whole operator proofs '+name,flush=True)
 catalog=load(O/'native_catalog.json.gz');a=read(O/'native_catalog_result.json');b=read(O/'replay_catalog_result.json');assert a['summary']==b['summary']
 def tag(n):
  name=fields[n]
  if name.startswith('B'):return 'B'+('H' if int(name[1:].split('_')[0])<12 else 'M')
  if name.startswith('C'):return 'C'+('H' if int(name[1:])<12 else 'M')
  if name.startswith('bar'):return 'aH'
  if name.startswith('ub'):return 'aM'
  if name.startswith('L'):return 'LM'
  if name.startswith('b'):return 'LH'
  assert name.startswith('x_');return 'x'+name.split('_')[1]
 for ch,groups in catalog['root_groups'].items():
  for group in groups:
   raw=rootmap[group['state'],'preference']['projections'][ch]['integrated'];assert len(raw)==group['raw_integrated_monomials'] and v.mhash(raw)==group['raw_integrated_math_sha256'];seenrows=bytearray(len(raw))
   for z in group['groups']:
    sig=z['signature'];assert sig[:4]==['R_'+group['state'],'marked',rootmap[group['state'],'preference']['g'],rootmap[group['state'],'preference']['u']]
    for at in z['raw_monomial_indices']:
     assert not seenrows[at];seenrows[at]=1;word,mon,cells=raw[at];qq=[];ext=[0]*4
     for n,js in word:
      if 1319<=n<1962:qq.append(tag(n-1319))
      elif 1962<=n<2605:qq.append(tag(n-1962))
      elif n<180:ext[0]+=1
      elif 508<=n<553:ext[1]+=1
      elif 553<=n<598:ext[2]+=1
      else:assert 1241<=n<1286;ext[3]+=1
     assert qq==sig[4] and ext==sig[5]
   assert all(seenrows)
 allowed={(a+sec,b+sec) for sec in ['H','M'] for a,b in [('B','B'),('B','L'),('L','B'),('C','a'),('a','C')]};allowed.update((x,x) for x in ['xPhi','xSigma','xphi','xS'])
 def edge(a,b,mode):
  if mode=='unrestricted':return True
  if mode=='HM' and not(a.startswith('x') or b.startswith('x')):return (a[0],b[0]) in [('B','B'),('B','L'),('L','B'),('C','a'),('a','C')]
  return (a,b) in allowed or mode=='LL' and a==b and a.startswith('L')
 for cat in catalog['catalogs']:
  classes=cat['classes'];actual=cat['complete_rooted_oriented_cycles'];aset=set(map(wordkey,actual));target=v.TARGETS[cat['channel']]
  assert len(aset)==len(actual) and all(any(z['external']) or z['g'] or z['u'] for z in classes if z['kind']=='ordinary')
  def check(row,mode):
   r,o,path=row;ids=[r]+[i for i,orient in path];assert o in [0,1] and classes[r]['kind']=='marked' and len(path)<=5 and all(classes[i]['kind']=='ordinary' and orient in [0,1] for i,orient in path)
   assert sum(classes[i]['g'] for i in ids)==sum(classes[i]['u'] for i in ids)==1 and tuple(sum(classes[i]['external'][j] for i in ids) for j in range(4))==target
   cur=classes[r]['quantum'][1-o];start=classes[r]['quantum'][o]
   for i,orient in path:assert edge(cur,classes[i]['quantum'][orient],mode);cur=classes[i]['quantum'][1-orient]
   assert edge(cur,start,mode)
  for row in actual:check(row,'actual')
  for name,mode in [('wrong_HM_mixing','HM'),('wrong_free_LL','LL'),('wrong_unrestricted_edges','unrestricted')]:
   assert aset<=set(map(wordkey,cat['wrong'][name]))
   for row in cat['wrong'][name]:check(row,mode)
  for name,rows in cat['omitted'].items():
   def keep(row):
    r,o,path=row
    if name=='omit_explicit_u_root':return classes[r]['u']==0
    if name=='omit_physical_ordinary':return not any(classes[i]['owner'].startswith('physical') for i,o in path)
    if name=='omit_original_GF_g1_ordinary':return not any(classes[i]['owner']=='GF_original' and classes[i]['g']==1 for i,o in path)
    assert name=='omit_inverse_U';return not any(classes[i]['u']==1 and not any(classes[i]['external']) for i,o in path)
   assert set(map(wordkey,rows))=={wordkey(row) for row in actual if keep(row)}
  if cat['channel']=='source':
   assert all(classes[r]['owner']=='R_F1' and len(path)==2 for r,o,path in actual)
   for r,o,path in actual:
    assert classes[r]['external']==[0,0,1,0] and all(q in ['CM','aM'] for i in [r]+[j for j,o in path] for q in classes[i]['quantum'])
    assert {classes[i]['owner'] for i,o in path}=={'GF_original','GF_probe1'}
 resources={}
 for name,limit in [('fixture',60),('native_root',180),('replay_root',180),('native_catalog',180),('replay_catalog',180)]:
  cap=read(O/(name+'_capture.json'));res=read(O/(name+'_result.json'));assert cap['exit_code']==0 and cap['calculation_completed'] and cap['execution_state']=='COMPLETED' and cap['post_run_observations_qualified']
  assert res['elapsed_after_imports']<=limit and cap['launch']['memory']['available_pagefile']>=350*1024**2 and all(0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
  resources[name]=dict(seconds_after_imports=res['elapsed_after_imports'],largest_private_sample=max(z['private_bytes'] for z in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True)
 fixture=read(O/'fixture_result.json');assert fixture['complete_covariance_positions']==36 and fixture['matrix_G']==fixture['literal_G'] and all(fixture['wrong_whole_mixed_gu_sensitive'].values())
 print('STAGE final complete regulator catalogs,typed source reduction and resources verified',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
 cap=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',cap);dump(C/'e4_capture.json',cap);assert p.returncode==0
 events=[json.loads(z) for z in p.stdout.splitlines() if z.strip()];exits=[z['exit_code'] for z in events if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED'
 assert next(z for z in events if z['event']=='step_finished' and z['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 old=(C/'old_git_tree.txt').read_bytes();assert old==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True)
 state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V792.md'];size=sum(p.stat().st_size for p in files);assert size<=128*1024**2
 out=dict(schema='REGULATOR_VERTICES_G1_RECOVERY_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_ACTUAL_POLARIZED_REGULATOR_VERTICES_GRADED_WICK_BRIDGE_AND_COMPLETE_RETURNING_CATALOG',scientific_acceptance='NOT_PERFORMED',base_HEAD=read(O/'fixture_preparation.json')['base_HEAD'],state_sha256=state,paired_math=pairs,verified_nonzero_field_units=verified_units,reconstructed_raw_product_monomials=raw_products,independent_mean_partition_monomials=partitions,all643_fields_per_state=True,two_quantum_halfedges_retained=True,reference_mass_root_whole_local_zero=True,original_F0_free_root_whole_integrated_zero=True,positive_probe_free_roots_retained=True,catalog_summary=a['summary'],source_returning_only_original_F1_ghost_root=True,resources=resources,failures_this_increment=0,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(old.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,actual_color_loop_integral_QAP_E5_viability_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','evidence_validation','E4_step_exits','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
