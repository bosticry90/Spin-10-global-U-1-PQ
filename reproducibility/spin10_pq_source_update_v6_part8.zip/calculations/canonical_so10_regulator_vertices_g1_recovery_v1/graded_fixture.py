from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import ast,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
OLD=O.parent/'canonical_so10_gaussian_current_reduction_g1_v1'
spec=importlib.util.spec_from_file_location('frozen_exterior_tools',OLD/'fixture.py');x=importlib.util.module_from_spec(spec);spec.loader.exec_module(x)
add,scale,mul,partial=x.add,x.scale,x.mul,x.partial
ZKEY=(0,0,0,0,0);parity=lambda n:int(n>=2)
def read(p):return json.loads(p.read_bytes())
def decode(rows):return {tuple(k):F(n,d) for k,n,d in rows}
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def madd(*ps):
 out={}
 for p in ps:
  for ij,c in p.items():out[ij]=add(out.get(ij,{}),c)
 return {ij:c for ij,c in out.items() if c}
def mscale(p,c):return {ij:scale(z,c) for ij,z in p.items() if scale(z,c)}
def mmul(p,q):
 out={}
 for (i,k),c in p.items():
  for (kk,j),d in q.items():
   if kk==k:out[i,j]=add(out.get((i,j),{}),mul(c,d))
 return {ij:c for ij,c in out.items() if c}
IDENT={(n,n):x.ONE for n in range(6)}
def normal(rows,t):
 out={}
 for i,P in enumerate(rows):
  for j in range(6):
   c=scale(partial(P,j),(-1)**(parity(j)*(t(i)+parity(j))))
   assert all(nx==ny==0 and not(mask&15) for g,u,nx,ny,mask in c)
   if c:out[i,j]=c
 return out
def inverse0(H):
 a=[[H.get((i,j),{}).get(ZKEY,F(0)) for j in range(6)]+[F(i==j) for j in range(6)] for i in range(6)]
 for c in range(6):
  pivot=next(r for r in range(c,6) if a[r][c]);a[c],a[pivot]=a[pivot],a[c];z=a[c][c];a[c]=[v/z for v in a[c]]
  for r in range(6):
   if r==c:continue
   z=a[r][c];a[r]=[v-z*w for v,w in zip(a[r],a[c])]
 return {(i,j):{ZKEY:a[i][6+j]} for i in range(6) for j in range(6) if a[i][6+j]}
def born(H):
 G0=inverse0(H);H0={ij:{ZKEY:c[ZKEY]} for ij,c in H.items() if c.get(ZKEY)};V=madd(H,mscale(H0,-1));B=mmul(G0,V);power=IDENT;G=G0;degrees=[]
 for n in range(1,9):
  power=mmul(power,B)
  if not power:break
  G=madd(G,mscale(mmul(power,G0),(-1)**n));degrees.append(n)
 assert not power,'INCOMPLETE_MATRIX_BORN_EXPANSION'
 return G,G0,V,degrees
def contract(FM,HM,G,include_crossing=True,transpose_G=False,extra_trace=False):
 out={}
 for (z,i),a in FM.items():
  for (zz,j),b in HM.items():
   if z!=zz:continue
   c=G.get((j,i) if transpose_G else (i,j),{})
   sign=(-1)**(parity(i)*(parity(z)+parity(j))) if include_crossing else 1
   if extra_trace:sign*=(-1)**parity(z)
   out=add(out,scale(mul(mul(a,b),c),sign))
 return out
def em(P):return [[i,j,x.encode(c)] for (i,j),c in sorted(P.items())]
def main():
 tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
 prep=read(O/'fixture_preparation.json')
 for n,h in prep['source_sha256'].items():assert sha256((O/n).read_bytes()).hexdigest()==h,n
 for n,h in prep['input_sha256'].items():assert sha256((R/n).read_bytes()).hexdigest()==h,n
 # Reuse only frozen mathematical input assignments, never oldmain's timer,
 # assertions, exponential evaluation, result/answer construction or writes.
 mainnode=next(n for n in ast.parse((OLD/'fixture.py').read_bytes().decode('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='main')
 allowed={'S0','R','Vg','Vu','Vgu','V','S','P'}
 nodes=[n for n in mainnode.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in allowed]
 assert [n.targets[0].id for n in nodes]==['S0','R','Vg','Vu','Vgu','V','S','P']
 env=dict(x.__dict__);exec(compile(ast.Module(body=nodes,type_ignores=[]),'<bound literal fixture inputs>','exec'),env)
 S,RR,PP=env['S'],env['R'],env['P'];HS=normal([partial(S,n) for n in range(6)],parity);HR=normal([partial(RR,n) for n in range(6)],parity)
 H=madd(HS,HR);FM=normal(PP,lambda n:parity(n)+1);G,G0,V,degrees=born(H)
 assert mmul(H,G)==mmul(G,H)==IDENT
 # Old literal weight/partition are operands. Old current answers are only
 # compared after full matrix construction and new36 Wick covariances.
 old=read(OLD/'fixture_result.json');W=decode(old['whole_weight']);invZ=x.inverse(decode(old['partition']));expect=lambda p:mul(x.integrate(mul(p,W)),invZ)
 literal={(i,j):expect(x.word([i,j])) for i in range(6) for j in range(6)};literal={ij:c for ij,c in literal.items() if c}
 assert G==literal,'NORMAL_ORDERED_MATRIX_VS_LITERAL_WICK'
 C=contract(FM,HS,G);K=contract(FM,HR,G);D=add(*(partial(p,n) for n,p in enumerate(PP)))
 assert C==decode(old['whole_current']) and K==add(decode(old['nonzero_local_trace']),scale(C,-1))
 assert add(C,K,scale(expect(D),-1))=={}
 Hbad={(i,j):partial(partial(add(S,RR),i),j) for i in range(6) for j in range(6)};Hbad={ij:c for ij,c in Hbad.items() if c};Gbad,_,_,_=born(Hbad)
 Fbad={(i,j):partial(p,j) for i,p in enumerate(PP) for j in range(6)};Fbad={ij:c for ij,c in Fbad.items() if c}
 Gshort=madd(G0,mscale(mmul(mmul(G0,V),G0),-1))
 wrong_matrices={'raw_LEFT_Hessian_without_coefficient_normal_order':madd(Gbad,mscale(G,-1)),'omitted_second_Born_term':madd(Gshort,mscale(G,-1))}
 assert all(wrong_matrices.values())
 wrong_whole={'raw_LEFT_F_without_coefficient_normal_order':add(contract(Fbad,HR,G),scale(K,-1)),'transposed_Wick_covariance':add(contract(FM,HR,G,transpose_G=True),scale(K,-1)),'omitted_odd_H_coefficient_crossing':add(contract(FM,HS,G,include_crossing=False),scale(C,-1)),'extra_manual_ghost_trace_sign':add(contract(FM,HR,G,extra_trace=True),scale(K,-1)),'omitted_second_Born_term':add(contract(FM,HR,Gshort),scale(K,-1))}
 assert all(wrong_whole.values()),'WHOLE_CONVENTION_FIXTURE_BLIND'
 out=dict(schema='GRADED_LEFT_NORMAL_MATRIX_WICK_BRIDGE_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',complete_covariance_positions=36,matrix_H=em(H),matrix_F=em(FM),matrix_R=em(HR),matrix_G=em(G),literal_G=em(literal),inverse_directions_both_checked=True,Born_degrees=degrees,current=x.encode(C),regulator=x.encode(K),local_Jacobian=x.encode(expect(D)),wrong_matrices={k:em(p) for k,p in wrong_matrices.items()},wrong_whole_residuals={k:x.encode(p) for k,p in wrong_whole.items()},wrong_whole_mixed_gu_sensitive={k:any(key[:2]==(1,1) for key in p) for k,p in wrong_whole.items()},fixture_inputs_and_literal_exterior_software_shared=True,distinct_literal_integration_and_matrix_inverse_algorithms=True,not_physical_parameter_point=True,elapsed_after_imports=time.perf_counter()-tick)
 dump(O/'fixture_result.json',out);print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','complete_covariance_positions','Born_degrees','regulator','wrong_whole_mixed_gu_sensitive','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
