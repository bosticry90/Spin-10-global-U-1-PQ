# Actual g1 source current: complete colors, finite profiles and paired reference

The selected first-u,g1 Lambda_b Ja_s C_c current covariance is now
calculated from the surviving executable inputs. All2*45^3 source-color
positions are retained. H probe gives zero. M probe has1126 nonzero
ordered-color positions:526 with external C in H,600 with C in M;
Ja and Lambda are in M. Every quantum line is in the M ghost/antighost
block. The full finite-cutoff response is retained and its paired joint
Schwartz UV-first/IR reference is zero in this projection.

This is the original unshifted Euclidean A0,gauge/scalar,one-loop proper
Gaussian,currentC_Q,integrated constant-u,intrinsic0/1 domain. It does
not complete the46 vector candidates, an independent expansion of every
V789 current word, the same-parent QGamma/D comparison or full QAP.

## The complete returning source sector fixes the calculation

V792's complete joint-endpoint catalogs leave eight labeled source paths,
all from the original F1 ghost root carrying the mean C, the original
g0 Lambda ghost mass and the probe-M g0u1 Ja ghost mass. Neither physical
ordinary vertices nor GFg1 ordinary vertices, explicit-u roots or inverse-U
quadratics return here. This excludes them by complete actual support
and coupling budgets, without transferring a source zero to the vector.

Let the coefficients LEFT of the quantum ghosts be

    (T1F1_C)_r = sum_ic (D_c)_(r,i) C_c etaC_i,
    (T1F1_a)_r = sum_ic (A_c)_(r,i) C_c etaa_i,

with overallg stripped only after exact grade checking. Native reads
these full coefficients from the qualified T1F tables; replay takes
LEFT derivatives directly in the actual F1 maps and uses V792's verified
normal-order sign. Complete45x45 matrices are saved before internal-M
restriction. All45 external C colors remain permitted.

M_b is the ghost matrix in the original Lambda_b Euler derivative.
N_s is the ghost matrix in the probe Ja_s Euler derivative. Native takes
the actual full action/source Eulers; replay uses its source-first Fu0_a
with the correct odd-field sign. The full ordinary quadratic vertices
independently match these matrices, including their canonical ghost signs.
They obey measured N_s=-2i Pi_s M_s. M,N,D,A and E=D+A are skew in the
active internal-M block. No skew/zero/count is used to construct an answer.

Final validation reconstructs every actually used polarized ghost root,
including all four l_mu² monomials and all external colors, from D,A
and the qualified ghost inverse. It also matches every corresponding
Lambda/Ja ordinary ghost-mass vertex. Thus no derivative or coefficient
port is omitted by the matrix extraction.

## Opposite root placement must be treated before color combination

From V792's directly checked graded Wick convention, the regulator ghost
contraction is

    -Tr[D C G R] - Tr[A^T C R G].

The second root is on the other side of the mean C. R cannot be commuted
through that multiplication. At this source coefficient there are exactly
two even local insertions N_s,M_b, both skew. Full coordinate/color
operator transposition gives

    -Tr[A^T C R G0 N G0 M G0]
      =-Tr[A C G0 M G0 N G0 R].

The two source insertions reverse order; their two transpose signs cancel.
Only one odd external coefficient C occurs, so it crosses only even
operators. The actual current equals minus this regulator contraction by
the verified V790 identity and zero Jacobian. The combined current colors
are therefore

    T_NM(c,s,b)=Tr[(D_c+A_c) N_s M_b],
    T_MN(c,s,b)=Tr[(D_c+A_c) M_b N_s].

The effective generator is D+A, not D+A^T. Both raw D ordered colors and
raw A^T opposite-root ordered colors are saved. At every position final
validation checks combinedNM=rawD_NM+rawAT_MN and its reversed partner.

An exact nine-dimensional coordinate/color operator fixture uses three
antisymmetric color matrices and nonconstant local coordinate sources,
with a symmetric free inverse/regulator that commutes with the free Green
but not the mean C. It obtains regulator -17397/12100 by both raw root
placements and the correct D+A regrouping. Wrong D+A^T or commuting the
root gives -5799/12100. This catches the actual order-placement issue
without adopting these fixture numbers as a physical parameter point.

The ordinary ghost quadratic Taylor half is aNC. At the selected two
distinct insertions the Born inverse gives both orders with coefficient+1.
Each ordered regulator bilinear has its one ordered covariance; no extra
1/2 or manual ghost-loop sign is added. This matches the literal/matrix
Gaussian normalization and mixed-degree checks already performed in V792.

## Full actual color evidence

Native first contracts N_s M_b or M_b N_s and then the generator.
Replay first contracts the generator with N_s or M_b and then independently
traces with the other matrix. Full matrices and both complete91125-position
tables are byte-identical between routes. Every zero is retained.

H probe has0 nonzero positions. M probe has1126, split526 C_H and600 C_M.
All actual Ja_s and Lambda_b indices are M. The wrong effective transpose
or omission of the A branch changes526 positions. The active quantum-M
restriction therefore must not be mistaken for an all-external-M assertion.

All182250 measured paired leading colors vanish. The skew identity proves
why: transpose and cyclic color trace give

    Tr[E_c N_s M_b] = -Tr[E_c M_b N_s].

This finite color trace is legal because the external odd C is already
factored out and all remaining matrix coefficients are even. It is not an
unjustified cyclic trace through general odd background operators.
The raw ordered tensors are usually nonzero. Reversing both signs remains
blind to the paired zero reference; dropping one ordering leaves1126
nonzero M coefficients multiplying the individual hard control below.

The1126 count agrees with a reported historical source count. Missing
historical coefficient/executable evidence still prevents a row-level
identity with those old calculations. These new matrices,coefficients and
profiles stand on their own; a matching count alone authenticates none of
the missing files or the reported nine-vector-amplitude frontier.

## Actual finite kernels and retained infrared contribution

Take incoming p(C),k(Ja),e(Lambda),p+k+e=0. In
Tr[C G0 N G0 M G0 R] the root has momentumq, the midpointq+e and the
common endpointq-p. The other order has midpointq+k. With

    F(q)=f_delta(q) exp(-tq²),
    f_delta(q)=(1-exp(-q²/delta²))²,
    G_F(q)=F(q)/q²,

the root q² cancels only its adjacent free pole, giving

    K_e = integral (1-F(q)) G_F(q+e) G_F(q-p) d4q/(2pi)^4,
    K_k = integral (1-F(q)) G_F(q+k) G_F(q-p) d4q/(2pi)^4.

Overallhbar,u,g are suppressed in this displayed coefficient. The complete
selected current is T_NM*K_e+T_MN*K_k=T_NM*(K_e-K_k), in the canonical
external C convention. This states the current sign separately from the
opposite regulator contraction sign. No same-parent QGamma/D target is
used to define either color or scalar kernel.

The root splits exactly as1-F=f(1-E)+(1-f). The infrared inverse defect
1-f is retained at finite delta. Heat-only replacement omits it. No
standalone inverse heat is applied to an arbitrary test field. At finite
cutoff the two kernels differ; the color sum cannot set the response zero.

For a conserved generic mathematical fixture t1,p=(1,0,0,0),
k=(0,2,0,0),e=-p-k and f1, two-Schwinger Gaussian quadrature gives

    16pi² K_e = 0.014825845941612388,
    16pi² K_k = 0.005882212171011435,
    16pi² (K_e-K_k) = 0.008943633770600954.

Orders32,64,128,256 agree to better than1e-10. This is a convergence
check, not a certified numerical error bound or a physical benchmark.
The explicit Gaussian formula follows from G_t(r)=integral_t^infinity
exp(-s r²)ds and completing the two-propagator square. The extra root
heat changes the denominator s+r to s+r+t and its exponent numerator
to sr|a-p|²+st|a|²+rt|p|². Removing the root changes both fixture values.

## Paired joint Schwartz reference and limits

For r!=0,0<=G_F(r)<=1/r² and

    |grad G_F(r)| <= (2+6/Euler_e)/|r|³,

uniformly t,delta>0. The three derivative contributions are2 from1/r²,
at most2/Euler_e from the heat derivative, and4/Euler_e from the profile
derivative4r exp(-x)(1-exp(-x))/delta² with x=r²/delta².

Let L=1+|p|+|k|+|e|. On |q|>2L, the midpoint difference is bounded
by constant*L/|q|³ and the endpoint by constant/|q|². Their product
has integrable tail L/|q|^5 in four dimensions. The root is bounded by1.
On |q|<=2L, bound the difference by the sum of its two pole2 kernels.
The root and the two successive node momenta are independent linear
coordinates with determinant of absolute value1; each pole2 is locally
integrable in its four-dimensional node. On an external dyadic shell
L~R, scaling gives at mostR^8 times the Schwartz weight. N>8 supplies
an integrable joint majorant, uniformly t,delta. This handles exceptional
external coincidences as a joint distribution, not a pointwise claim there.

Under the stipulated UV-first then IR reference, the paired integrand
tends to zero almost everywhere and this common majorant applies.
At fixed delta the UV root approaches1-f, which must remain until the
IR limit; then it tends to zero. Dominated convergence gives zero for
the paired joint reference. It does not make the individual finite kernels
equal or remove a hard constant from either one in isolation.

The independent individual hard radial coefficient is

    integral_0^infinity exp(-2x)(1-exp(-x)) dx/x = log(3/2).

Represent the integrand as integral_2^3 exp(-a x)da and integrate to get
log(3/2); the loop factor is1/(16pi²). Independent50-digit quadrature
agrees within1e-40. This is a hard-region control, not an exceptional
physical external-momentum restriction. One omitted ordering exposes its
1126 nonzero colors. Only the complete opposite-color pair has zero
reference in the qualified distributional scope.

## Evidence, significance and continuation

Native63.380637s,replay25.031574s under180s each; analytic fixture
0.176571s under60s. Serial8GiBsampled/350MiBfloor/64MiB newpacket.
Final validation owns full bindings/paired colors/actual root and ordinary
matrix reconstruction/order reversals/profiles/resources/state/oldtree and
E4once/no-fresh D:context0,0,0,0,0,2,seven unresolved custodyNOTPASS.
No worker failed this increment. All original/failed evidence is preserved.

This recovers an actual color-dependent current amplitude and its paired
reference, beyond type counts. Distinct matrix extraction/contraction
associations and the noncommuting operator fixture test implementation
errors. Shared action,chart,ring,software and AI author do not validate
shared physical assumptions or supply independent scientists. No outside
reviewer,proof kernel or empirical test is claimed.

The selected source current imposes no additional finite-reference
constraint in this domain. V782's nonzero marked g0 normalization law
and the full common-normalization problem remain unchanged. Next reconcile
the expanded V789 source-current representation with this frozen output,
then evaluate the46 vector candidates including allthree root states and
eight physical-ordinary paths. Preserve finite profiles and constants;
read same-parent QGamma/D targets only after the covariance reconciliation.
State113/34of39,E5/A5,fullQAP/measure/equivalence,normalization/reality and
physical viability stay open. No physical baseline or counterterm is fit.
