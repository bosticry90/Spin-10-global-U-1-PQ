# Actual source-current colors and paired reference computed

Both calculations agree on all182250 source-color positions. H probe is
zero. M probe has1126 nonzero ordered-color positions:526 C_H and600 C_M,
with Ja,Lambda and all quantum lines in M. Full matrices,raw branch colors,
both orderings and zero positions are retained.

The finite current is T*(K_e-K_k), with distinct ordered kernels and the
original heat/infrared profiles. Each ordered color pair is opposite.
A uniform joint Schwartz bound proves the paired UV-first/IR reference
zero in this selected current projection. Individual kernels have the
nonzero hard control log(3/2)/(16pi²); finite-cutoff response is retained.

The [proof](PROOF.md) derives the correct D+A generator after reversing the
opposite-root branch,actual normalizations,complete colors,kernels,limits
and controls. The [receipt](validation_receipt.json) owns final validation.
The1126 count matches a historical report; missing old coefficients/files
remain unauthenticated. Next reconcile the expanded source covariance,
then calculate the46 vector candidates before same-parent target comparison.
State113/34of39,E5/A5 and custody exit2/seven NOTPASS remain unchanged.
