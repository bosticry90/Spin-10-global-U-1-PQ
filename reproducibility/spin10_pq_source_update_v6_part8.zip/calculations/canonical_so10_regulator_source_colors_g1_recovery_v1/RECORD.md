# Actual g1 source covariance colors and profiles, prospective V1

Basee70f715645d5ddd6bc2ee6d4ea1af9fc5960fe76/main,V792. Cleanpreflight,
no workers,452bindingsauthenticated. Fullgoalread,currentAGENTS/charter/
D:first. State113/34of39,E5/A5open unchanged. Noagents/branch/worktree/
adoption/promotion/protectedactivation/flavor/remoteaction. Frozenoldbytes
andallpriorfailuresunchanged. This isactualsourcecolor/profilework,not
another typed-count milestone or guessednine-M reconstruction.

Domain: originalunshiftedEuclideanA0,one-loopproperGaussian,currentC_Q,
integratedconstant-u,g1,intrinsic01,Lambda_b Ja_s C_c,all45³colors,both
probes,originalE=exp(-tq²),f=(1-exp(-q²/delta²))²,F=fE. V792complete
catalog proves Hnone,M8,onlyoriginalF1ghostroot+g0LambdaM_b+uJaN_s.
Otherphysical/explicitu/inverseU/sourceg1paths do notreturn inTHISsource
representation. No suchzero istransferredtovector.

Extract all45x45 ghostgenerator matrices D_c (F1_C) and A_c (F1_a)
with coefficients LEFT of quantumghost,fromfullsource-firstmaps. Native
readsqualifiedT1F; replaytakesLEFTfieldpartialswithverifiednormal-order
sign. Striponlyoverallg1 afterchecking grade. Extract M_b fromactual
originalLambdaEuler and N_s fromactualprobeJaEuler; replayusesindependent
source-firstFu0_a relation instead. Preservefull45x45 matrices before
restricting internalquantumM,all45externalcolors,and everyzeroslot.

Regulatorghostcontraction has -Tr[D C G R]-Tr[A^T C R G]. The second
term's rootprofile lies ontheoppositeedge; DO NOT commuteRthroughmeanC.
At the selected twoevenmassinsertions N,M, both measuredskew, complete
operatortranspose reverses theirorder andmovesRbackto thecommonroot:
 -Tr[A^T C R G0 N G0 M G0]
 =-Tr[A C G0 M G0 N G0 R].
Thus fullcurrent=-regulator yields E_c=D_c+A_c (NOTD+A^T), and
 T_NM=Tr(E_c N_s M_b),T_MN=Tr(E_c M_b N_s).
Freeze four RAWD/A^Torderedcolors aswell ascombinedE colors; do not use
expectedskew/zero/count asaconstructionconstraint. A finitecoordinate
mode/color matrix check must exercise noncommutingR/meanC and reversed
order beforethis regrouping supports the actual amplitude.

Native contractions: precomputeN_s M_b andM_b N_s,thenindexedtraceE.
Replay: contract E_c N_s orE_c M_b first,thenindependentlytracewiththe
othermatrix. Complete2*45³positions,zeroandnonzero,allraw/combinedcolors
mustagree. Check measured M/N/E skewandactual external/internal support,
notassume it. IfT_NM+T_MNnonzero,retainthelocalhardcontribution; never
force a pairedzero or selectfinitecounterterms torepairit.

Incomingp(C),k(Ja),e(Lambda),p+k+e=0. OrderedcolorNM haskernel
 K_e=integral(1-F_q)G_F(q+e)G_F(q-p)d4q/(2pi)^4,
 reversedMN hasK_k withmidpointq+k. Thesearegenerallydifferent atfinite
cutoff. Eachcommonroot1-F splitsinto heatf(1-E) andIR1-f; keepboth.
Derive actualrelativeweights fromV792normalorderedWickconvention;no
extra1/2 or manualghosttracefactor. PreserveR-insertion/currentoverall
sign,canonicalexternalC order andallg/u factors distinctly.

If actualskew givesT_MN=-T_NM, use uniformgradient bound on G_F toprove
thepairedkernel's jointSchwartzUV-first/IRreference,without assigning
individualkernelsequalorzero. Retaincomplete finiteprofileexpressions,
finiteconstants and defect. A genericconservedmomentum heat-onlymath
fixture(t1,p=(1,0,0,0),k=(0,2,0,0),e=-p-k) checks inequalkernels using
2-SchwingerGaussian quadratureN32,64,128,256(convergence1e-10),notphysical
benchmark. Independenthardradial log(3/2) formula/mpmath50digitcheck
tests the missing-one-order control. No isolatedinverseheat onSchwartz.

Resources: serialnative/replaycolors180s afterimports each,finiteoperator/
profileanalyticfixture60s,final180s;8GiBsampled/350MiBfloor/64MiBcomplete
newpacket. No oldfullfactory/current/physical replay. Preserveeveryfailed/
incompletesource,capture; no hiddenretry/resources/truncation. Finalchecks
fullpairs/matrix/positions/profiles/controls/resources/state/oldtree and
E4once-no-freshverifiedDcontext0,0,0,0,0,2/sevenunresolvedNOTPASS.
Localcommitonlyaftervalidation. No same-parentQGamma/Dtargetinputread;
freezeactualcovariancefirst,thenreconcilefullV789currentrepresentation
beforethatcomparison. Sharedaction/chart/ring/AIauthor,notindependent
scientists; nooutside/proofkernel/empiricalclaim. No QAP/measure/E5/A5/
physicalviability/normalizationadoption. Educationvoluntary/nonblocking.
