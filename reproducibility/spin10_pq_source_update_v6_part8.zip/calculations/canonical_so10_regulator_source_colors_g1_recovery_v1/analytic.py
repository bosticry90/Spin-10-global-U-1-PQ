from pathlib import Path
from hashlib import sha256
import json,os,threading,time
import numpy as np
import sympy as s
import mpmath as mp
O=Path(__file__).resolve().parent
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
 prep=json.loads((O/'analytic_preparation.json').read_bytes())
 for n,h in prep['source_sha256'].items():assert sha256((O/n).read_bytes()).hexdigest()==h,n
 # Exact finite coordinate/color operators: local multiplication is diagonal
 # incoordinate space; the freeinverse/regulator need not commute with it.
 def skew(i,j):
  M=s.zeros(3);M[i,j]=1;M[j,i]=-1;return M
 colorN=skew(0,1);colorM=skew(1,2);colorA=skew(2,0);colorD=2*colorA
 K=s.Matrix([[4,1,0],[1,5,1],[0,1,6]]);C=s.diag(2,-1,3);src=s.diag(1,4,2);lam=s.diag(-1,2,5)
 G=s.kronecker_product(s.eye(3),K.inv());RR=s.kronecker_product(s.eye(3),K*K+K)
 NN=s.kronecker_product(colorN,src);MM=s.kronecker_product(colorM,lam);DD=s.kronecker_product(colorD,C);AA=s.kronecker_product(colorA,C)
 assert NN.T==-NN and MM.T==-MM and G.T==G and RR.T==RR and RR*G==G*RR and RR*DD!=DD*RR
 rawA=[-s.trace(AA.T*RR*G*NN*G*MM*G),-s.trace(AA.T*RR*G*MM*G*NN*G)]
 reversedA=[-s.trace(AA*G*MM*G*NN*G*RR),-s.trace(AA*G*NN*G*MM*G*RR)];assert rawA==reversedA
 rawD=[-s.trace(DD*G*NN*G*MM*G*RR),-s.trace(DD*G*MM*G*NN*G*RR)]
 combined=[-s.trace((DD+AA)*G*NN*G*MM*G*RR),-s.trace((DD+AA)*G*MM*G*NN*G*RR)]
 actual=sum(rawD)+sum(rawA);assert actual==sum(combined) and actual!=0
 wrong=sum(-s.trace((DD+AA.T)*G*X*G*Y*G*RR) for X,Y in [(NN,MM),(MM,NN)])
 wrong_commute=sum(-s.trace(AA.T*G*X*G*Y*G*RR) for X,Y in [(NN,MM),(MM,NN)])+sum(rawD)
 assert wrong!=actual and wrong_commute!=actual
 # 16pi²-normalized finiteheat kernel via twoSchwinger Gaussian integrals.
 p=np.array([1.,0,0,0]);k=np.array([0.,2,0,0]);e=-p-k;pa=-e;pb=-k;t=1.
 def kernel(a,n,root=True):
  points,weights=np.polynomial.legendre.leggauss(n);points=(points+1)/2;weights=weights/2
  ss=t/(1-points[:,None]);rr=t/(1-points[None,:]);jac=t*t/(1-points[:,None])**2/(1-points[None,:])**2
  d2=float(np.dot(a-p,a-p));a2=float(np.dot(a,a));p2=float(np.dot(p,p));total=ss+rr
  base=np.exp(-ss*rr*d2/total)/total**2
  if root:
   withroot=total+t;extra=np.exp(-(ss*rr*d2+ss*t*a2+rr*t*p2)/withroot)/withroot**2;base=base-extra
  return float(np.sum(weights[:,None]*weights[None,:]*jac*base))
 quad=[]
 for n in [32,64,128,256]:
  a,b=kernel(pa,n),kernel(pb,n);quad.append(dict(N=n,K_e_times16pi2=a,K_k_times16pi2=b,difference_times16pi2=a-b))
 assert max(abs(quad[-1][key]-quad[-2][key]) for key in ['K_e_times16pi2','K_k_times16pi2','difference_times16pi2'])<1e-10
 assert abs(quad[-1]['difference_times16pi2'])>1e-8
 wrong_root=[kernel(pa,256,False),kernel(pb,256,False)];assert all(abs(w-q)>1e-8 for w,q in zip(wrong_root,[quad[-1]['K_e_times16pi2'],quad[-1]['K_k_times16pi2']]))
 mp.mp.dps=50;hard=mp.quad(lambda z:mp.exp(-2*z)*(-mp.expm1(-z))/z if z else mp.mpf(1),[0,1,mp.inf]);exact=mp.log(mp.mpf(3)/2);assert abs(hard-exact)<mp.mpf('1e-40')
 out=dict(schema='SOURCE_G1_ORDER_REVERSAL_AND_FINITE_PROFILE_REVIEW_V1',execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',coordinate_operator=dict(raw_A_Rfirst=[str(z) for z in rawA],reversed_A_Rlast=[str(z) for z in reversedA],raw_D=[str(z) for z in rawD],combined_D_plus_A=[str(z) for z in combined],actual_regulator=str(actual),wrong_D_plus_AT=str(wrong),wrong_commuted_root=str(wrong_commute),root_does_not_commute_with_meanC=True),conserved_fixture_momenta=dict(p=p.tolist(),k=k.tolist(),e=e.tolist(),t=t,IR_f_equal_one_only_for_math_fixture=True),Schwinger_quadrature=quad,quadrature_is_convergence_check_not_certified_error_bound=True,wrong_no_root_factor_times16pi2=wrong_root,hard_radial=str(hard),hard_radial_exact='log(3/2)',hard_radial_error=str(abs(hard-exact)),profile_family=dict(F='f_delta(q)*exp(-t*q_squared)',f='(1-exp(-q_squared/delta_squared))**2',K_e='integral (1-F(q))*G_F(q+e)*G_F(q-p) d4q/(2*pi)^4',K_k='integral (1-F(q))*G_F(q+k)*G_F(q-p) d4q/(2*pi)^4',heat_root='f(q)*(1-E(q))',IR_root='1-f(q)'),elapsed_after_imports=time.perf_counter()-tick,physical_parameter_point_or_full_QAP_claim=False)
 dump(O/'analytic_result.json',out);print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','coordinate_operator','Schwinger_quadrature','hard_radial_error','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
