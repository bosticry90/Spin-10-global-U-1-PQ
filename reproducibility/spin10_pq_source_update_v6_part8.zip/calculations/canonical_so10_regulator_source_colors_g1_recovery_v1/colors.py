from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import gzip,importlib.util,json,os,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
ROLE=sys.argv[1] if __name__=='__main__' else 'native'
spec=importlib.util.spec_from_file_location('source_actual_color_tools',O.parent/'canonical_so10_regulator_vertices_g1_recovery_v1/roots.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
w=v.w;J=v.J;A=v.A
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def save(name,data):
 blob=gzip.compress((json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 with (O/(ROLE+'_'+name+'.json.gz')).open('xb') as h:h.write(blob)
 assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=64*1024**2
 return dict(file=ROLE+'_'+name+'.json.gz',sha256=sha256(blob).hexdigest(),bytes=len(blob))
def strip(c):
 assert all(key[0]==1 for key,z in c.terms)
 return J.Coeff([((0,b,e,m),z) for (g,b,e,m),z in c.terms])
def projected(M):return {(i,j):c for (i,j),c in M.items() if i>=12 and j>=12}
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 prep=read(O/'preparation.json')
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 for n,h in prep['source_sha256'].items():assert digest(O/n)==h,n
 peer=str((O/('replay_' if ROLE=='native' else 'native_')).resolve())
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):assert not str(Path(os.fsdecode(args[0])).resolve()).startswith(peer),'PEER_SOURCE_COLORS_READ_DENIED'
 sys.addaudithook(guard)
 vert=O.parent/'canonical_so10_regulator_vertices_g1_recovery_v1';full=O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1';old=O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'
 common=load(old/(ROLE+'_GF_common.json.gz'));Ms={b:w.mass(J.decode(dict(common['E0'])[508+b])) for b in range(45)}
 D={c:{} for c in range(45)};AA={c:{} for c in range(45)}
 if ROLE=='native':
  mapping=dict(load(vert/'native_raw_T1_F.json.gz')['F1'])
  for sector,start,target in [('C',553,D),('a',598,AA)]:
   for r in range(45):
    for word,cc in J.decode(mapping[start+r]).items():
     if len(word)!=2 or any(js for n,js in word):continue
     mean,quant=word
     if 553<=mean[0]<598 and 1319+start<=quant[0]<1319+start+45:
      target[mean[0]-553][r,quant[0]-1319-start]=strip(cc)
 else:
  mapping=dict(load(full/'replay_new_states.json.gz')['F1'])
  for start,target in [(553,D),(598,AA)]:
   for r in range(45):
    P=J.decode(mapping[start+r])
    for i in range(45):
     partial=w.scale(J.leftjet(P,(start+i,())),J.constant(-1))
     for word,cc in partial.items():
      if len(word)==1 and 553<=word[0][0]<598 and not word[0][1]:target[word[0][0]-553][r,i]=strip(cc)
 Ns=[]
 for pr in [0,1]:
  if ROLE=='native':
   U=J.decode(common['probes'][pr]['U']);euler=J.euler(U,set(range(1241,1286)));N={r:w.mass(euler.get(1241+r,{})) for r in range(45)}
  else:
   flows=dict(common['probes'][pr]['source_first_Fu']);N={r:w.mass(w.scale(J.decode(flows[598+r]),J.constant(-1))) for r in range(45)}
  Ns.append(N)
 effective={c:A.add(D[c],AA[c]) for c in range(45)}
 data=save('matrices',dict(D=[[c,A.encode_matrix(D[c])] for c in range(45)],A=[[c,A.encode_matrix(AA[c])] for c in range(45)],effective_D_plus_A=[[c,A.encode_matrix(effective[c])] for c in range(45)],M=[[b,A.encode_matrix(Ms[b])] for b in range(45)],N=[[[r,A.encode_matrix(row[r])] for r in range(45)] for row in Ns],full45internal_before_projection=True,ghost_generator_g1_stripped_after_grade_check=True))
 DD={c:projected(D[c]) for c in range(45)};AB={c:projected(AA[c]) for c in range(45)};EE={c:projected(effective[c]) for c in range(45)}
 M={b:projected(Ms[b]) for b in range(45)};N=[{r:projected(row[r]) for r in range(45)} for row in Ns]
 measured_skew=dict(M=all(A.add(m,A.transpose(m))=={} for m in M.values()),N=all(A.add(m,A.transpose(m))=={} for row in N for m in row.values()),D=all(A.add(m,A.transpose(m))=={} for m in DD.values()),A=all(A.add(m,A.transpose(m))=={} for m in AB.values()),effective=all(A.add(m,A.transpose(m))=={} for m in EE.values()))
 assert measured_skew['M'] and measured_skew['N'],'ACTUAL_EVEN_MASS_INSERTIONS_NOT_SKEW'
 tables=[];counts=[]
 for pr in [0,1]:
  matrices={'D':DD,'A_transpose_raw':{c:A.transpose(AB[c]) for c in range(45)},'effective':EE,'wrong_D_plus_A_transpose':{c:A.add(DD[c],A.transpose(AB[c])) for c in range(45)}}
  if ROLE=='native':
   nm={(s,b):A.mul(N[pr][s],M[b]) for s in range(45) for b in range(45)};mn={(s,b):A.mul(M[b],N[pr][s]) for s in range(45) for b in range(45)}
   def triple(T,c,s,b,reverse):return A.pairtrace(T[c],(mn if reverse else nm)[s,b])
  else:
   leftN={label:{(c,s):A.mul(T[c],N[pr][s]) for c in range(45) for s in range(45)} for label,T in matrices.items()}
   leftM={label:{(c,b):A.mul(T[c],M[b]) for c in range(45) for b in range(45)} for label,T in matrices.items()}
   labels={id(T):label for label,T in matrices.items()}
   def triple(T,c,s,b,reverse):
    label=labels[id(T)]
    return A.pairtrace(leftM[label][c,b],N[pr][s]) if reverse else A.pairtrace(leftN[label][c,s],M[b])
  rows=[];nonzero=paired_nonzero=wrong_transpose_changed=omit_A_changed=0;support=set()
  for c in range(45):
   for src in range(45):
    for b in range(45):
     rawD=[triple(matrices['D'],c,src,b,rev) for rev in [False,True]]
     rawAT=[triple(matrices['A_transpose_raw'],c,src,b,rev) for rev in [False,True]]
     actual=[triple(matrices['effective'],c,src,b,rev) for rev in [False,True]]
     bad=[triple(matrices['wrong_D_plus_A_transpose'],c,src,b,rev) for rev in [False,True]]
     lead=actual[0]+actual[1];nonzero+=bool(actual[0]) or bool(actual[1]);paired_nonzero+=bool(lead)
     wrong_transpose_changed+=bad!=actual;omit_A_changed+=rawD!=actual
     if any(actual):support.add((c<12,src<12,b<12))
     rows.append(dict(C=c,Ja=src,Lambda=b,raw_D_ordered=[w.enc(z) for z in rawD],raw_AT_opposite_root_ordered=[w.enc(z) for z in rawAT],combined_D_plus_A_ordered=[w.enc(z) for z in actual],paired_leading=w.enc(lead),wrong_D_plus_AT_ordered=[w.enc(z) for z in bad]))
  table=save('colors_probe'+str(pr),dict(probe=pr,positions=45**3,all_positions=rows,ordered_kernels=['K_e','K_k'],raw_AT_root_R_on_opposite_edge=True,combined_A_requires_two_mass_operator_transpose_and_order_reversal=True))
  tables.append(table);counts.append(dict(probe=pr,positions=len(rows),nonzero_color_positions=nonzero,paired_leading_nonzero=paired_nonzero,wrong_D_plus_AT_changed_positions=wrong_transpose_changed,omit_A_changed_positions=omit_A_changed,actual_external_H_flags=sorted([list(z) for z in support])))
  print('STAGE '+ROLE+' complete all45cubed actualsource colors probe'+str(pr),flush=True)
 result=dict(schema='ACTUAL_G1_SOURCE_CURRENT_REGULATOR_COLORS_V1',route=ROLE,matrices=data,tables=tables,counts=counts,measured_skew=measured_skew,effective_nonzero_external_colors=[c for c,m in EE.items() if m],elapsed_after_imports=time.perf_counter()-tick,scientific_acceptance='NOT_PERFORMED',finite_kernel_or_QAP_E5_claim=False)
 with (O/(ROLE+'_result.json')).open('x',encoding='utf-8',newline='\n') as h:json.dump(result,h,sort_keys=True);h.write('\n')
 print('RESULT '+json.dumps({k:result[k] for k in ['counts','measured_skew','effective_nonzero_external_colors','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
