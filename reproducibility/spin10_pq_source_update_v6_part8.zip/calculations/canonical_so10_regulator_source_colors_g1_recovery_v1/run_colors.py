from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/regulator-source-colors-g1-recovery-v1-2026-11-07')
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
route=sys.argv[1];assert route in ['native','replay'];assert not (O/(route+'_capture.json')).exists()
if not (O/'preparation.json').exists():
 head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='e70f715645d5ddd6bc2ee6d4ea1af9fc5960fe76'
 names=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/LOCAL_STORAGE_LAYOUT_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V792.md','calculations/canonical_so10_regulator_vertices_g1_recovery_v1/roots.py','calculations/canonical_so10_regulator_vertices_g1_recovery_v1/validation_receipt.json','calculations/canonical_so10_regulator_vertices_g1_recovery_v1/PROOF.md','calculations/canonical_so10_absolute_marked_quantum_g0_recovery_v1/quantum.py','calculations/canonical_so10_original_Ja_ghost_bubble/algebra.py','calculations/canonical_so10_full_jet_source_master_bridge/jets.py','calculations/canonical_so10_intrinsic_full_source_descent/coefficient_ring.py','calculations/canonical_so10_physical_current_input_recovery_g1_v1/physical_v2.py','calculations/canonical_so10_physical_current_input_recovery_g1_v1/physical_v4.py']
 for role in ['native','replay']:
  names += ['calculations/canonical_so10_regulator_vertices_g1_recovery_v1/'+role+'_'+n+'.json.gz' for n in ['raw_T1_F','catalog']]
  names += ['calculations/canonical_so10_full_current_inventory_g1_recovery_v1/'+role+'_new_states.json.gz','calculations/canonical_so10_new_physical_returning_inventory_g1_recovery_v1/'+role+'_GF_common.json.gz']
 for n in names:assert (R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n]),n
 for n in ['RECORD.md','colors.py','run_colors.py']:
  with (O/(n+'.source.txt')).open('xb') as h:h.write((O/n).read_bytes())
 dump(O/'preparation.json',dict(base_HEAD=head,input_sha256={n:digest(R/n) for n in sorted(set(names))},source_sha256={n:digest(O/n) for n in ['RECORD.md','colors.py','run_colors.py']},scientific_acceptance='NOT_PERFORMED'))
 C.mkdir(parents=True,exist_ok=False)
 with (C/'old_git_tree.txt').open('xb') as h:h.write(subprocess.check_output(['git','ls-tree','-r','HEAD']))
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'colors.py'),route]);dump(O/(route+'_capture.json'),cap);dump(C/(route+'_capture.json'),cap)
print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
