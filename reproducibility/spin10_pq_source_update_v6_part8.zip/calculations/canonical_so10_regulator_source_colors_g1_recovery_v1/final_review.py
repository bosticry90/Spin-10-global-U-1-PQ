from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import gzip,importlib.util,json,os,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('D:/Codex-Research/ToE-Next/research-control-records/regulator-source-colors-g1-recovery-v1-2026-11-07')
spec=importlib.util.spec_from_file_location('source_color_final_tools',O/'colors.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
w=v.w;J=v.J;A=v.A
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n') as h:json.dump(z,h,sort_keys=True);h.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'final_preparation.json')['source_sha256'].items():assert digest(R/n)==h,n
 prep=read(O/'preparation.json')
 for n,h in prep['input_sha256'].items():assert digest(R/n)==h,n
 for obj in [prep,read(O/'analytic_preparation.json')]:
  for n,h in obj['source_sha256'].items():assert digest(O/n)==h,n
 for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes(),p.name
 pairs=[]
 for a in sorted(O.glob('native_*.json.gz')):
  b=O/a.name.replace('native_','replay_',1);assert a.read_bytes()==b.read_bytes();pairs.append(dict(native=a.name,replay=b.name,sha256=digest(a)))
 assert len(pairs)==3
 na,re=read(O/'native_result.json'),read(O/'replay_result.json');assert na['counts']==re['counts'] and na['measured_skew']==re['measured_skew'] and all(na['measured_skew'].values())
 data=load(O/'native_matrices.json.gz')
 D={n:A.decode_matrix(rows) for n,rows in data['D']};AA={n:A.decode_matrix(rows) for n,rows in data['A']};E={n:A.decode_matrix(rows) for n,rows in data['effective_D_plus_A']};M={n:A.decode_matrix(rows) for n,rows in data['M']};N=[{n:A.decode_matrix(rows) for n,rows in row} for row in data['N']]
 assert all(list(z)==list(range(45)) for z in [D,AA,E,M,*N])
 assert all(E[c]==A.add(D[c],AA[c]) for c in range(45)) and not any(N[0].values())
 for pr in [0,1]:
  for r in range(45):assert N[pr][r]==w.mat_scale(M[r],-2*J.I) if (r<12 if pr==0 else r>=12) else not N[pr][r]
 DD={c:v.projected(D[c]) for c in range(45)};AB={c:v.projected(AA[c]) for c in range(45)};EE={c:v.projected(E[c]) for c in range(45)}
 # Verify all actualused polarized F1 ghost roots, including every momentum
 # monomial, against extracted D/A matrices. No discarded derivative term.
 vert=R/'calculations/canonical_so10_regulator_vertices_g1_recovery_v1'
 roots=load(vert/'native_root_assemblies.json.gz')['assemblies'];F1=next(z for z in roots if z['state']=='F1' and z['family']=='preference')
 actual={}
 for word,mon,cells in F1['projections']['source']['integrated']:
  if len(word)!=3:continue
  cm,qf,qr=word
  if not(553<=cm[0]<598 and ((1319+565<=qf[0]<1319+598 and 1962+610<=qr[0]<1962+643) or (1319+610<=qf[0]<1319+643 and 1962+565<=qr[0]<1962+598))):continue
  key=tuple((n,tuple(js)) for n,js in word),tuple(mon);actual[key]=v.strip(A.decode_coeff(cells))
 expected={}
 for c in range(45):
  for matrix,startF,startR,sign in [(DD[c],553,598,-1),(AB[c],598,553,1)]:
   for (r,i),z in matrix.items():
    for mu in range(4):
     mon=[0]*12;mon[4+mu]=2;word=((553+c,()),(1319+startF+i,()),(1962+startR+r,()));expected[word,tuple(mon)]=z*sign
 assert actual==expected,'ACTUAL_USED_SOURCE_ROOT_NOT_RECONSTRUCTED'
 # Independently match the ordinaryLambda andJa ghostmass vertices whose
 # complete joint typecatalog supplies the other two source-cycle factors.
 common=load(R/'calculations/canonical_so10_new_physical_returning_inventory_g1_recovery_v1/native_GF_common.json.gz')
 def ordinary_mass(raw,source):
  found={}
  for word,z in J.decode(raw).items():
   if len(word)!=3 or any(js for n,js in word):continue
   first,a,b=word
   if source=='Lambda' and 508<=first[0]<553:label=first[0]-508
   elif source=='Ja' and 1241<=first[0]<1286:label=first[0]-1241
   else:continue
   if 1319+553<=a[0]<1319+598 and 1319+598<=b[0]<1319+643:found[label,a[0]-1319-553,b[0]-1319-598]=-z
  return found
 oldmass=ordinary_mass(common['original_ordinary'],'Lambda');assert oldmass=={(b,c,a):z for b,T in M.items() for (a,c),z in T.items()}
 for pr in [0,1]:
  newmass=ordinary_mass(common['probe_ordinary'][pr],'Ja');assert newmass=={(b,c,a):z for b,T in N[pr].items() for (a,c),z in T.items()}
 assessments=[]
 for pr in [0,1]:
  rows=load(O/('native_colors_probe'+str(pr)+'.json.gz'))['all_positions'];assert len(rows)==45**3
  nonzero=h_c=m_c=changed=0
  for at,row in enumerate(rows):
   c,s,b=row['C'],row['Ja'],row['Lambda'];assert (c,s,b)==(at//2025,(at//45)%45,at%45)
   rawD=list(map(A.decode_coeff,row['raw_D_ordered']));rawAT=list(map(A.decode_coeff,row['raw_AT_opposite_root_ordered']));combined=list(map(A.decode_coeff,row['combined_D_plus_A_ordered']));bad=list(map(A.decode_coeff,row['wrong_D_plus_AT_ordered']))
   assert combined==[rawD[0]+rawAT[1],rawD[1]+rawAT[0]] and bad==[rawD[0]+rawAT[0],rawD[1]+rawAT[1]]
   assert combined[0]+combined[1]==A.decode_coeff(row['paired_leading'])==J.ZERO
   if any(combined):
    nonzero+=1;h_c+=c<12;m_c+=c>=12;assert s>=12 and b>=12
   changed+=bad!=combined
  assert nonzero==na['counts'][pr]['nonzero_color_positions'] and changed==na['counts'][pr]['wrong_D_plus_AT_changed_positions']
  assessments.append(dict(probe=pr,positions=len(rows),nonzero=nonzero,C_H_nonzero=h_c,C_M_nonzero=m_c,paired_hard_coefficient_zero_positions=len(rows),wrong_effective_transpose_changed=changed))
 assert assessments[0]['nonzero']==0 and assessments[1]['nonzero']==1126 and assessments[1]['C_H_nonzero']==526 and assessments[1]['C_M_nonzero']==600
 analytic=read(O/'analytic_result.json');assert analytic['execution_state']=='COMPLETED'
 mode=analytic['coordinate_operator'];assert mode['raw_A_Rfirst']==mode['reversed_A_Rlast'] and mode['actual_regulator']!=mode['wrong_D_plus_AT'] and mode['actual_regulator']!=mode['wrong_commuted_root'] and mode['root_does_not_commute_with_meanC']
 quad=analytic['Schwinger_quadrature'];assert [z['N'] for z in quad]==[32,64,128,256] and abs(quad[-1]['difference_times16pi2'])>1e-8
 assert max(abs(quad[-1][k]-quad[-2][k]) for k in ['K_e_times16pi2','K_k_times16pi2','difference_times16pi2'])<1e-10
 assert analytic['profile_family']['heat_root']=='f(q)*(1-E(q))' and analytic['profile_family']['IR_root']=='1-f(q)'
 assert F(analytic['hard_radial_error'])<F(1,10**40)
 resources={}
 for name,limit in [('native',180),('replay',180),('analytic',60)]:
  cap=read(O/(name+'_capture.json'));res=read(O/(name+'_result.json'));assert cap['exit_code']==0 and cap['calculation_completed'] and cap['execution_state']=='COMPLETED' and cap['post_run_observations_qualified']
  assert res['elapsed_after_imports']<=limit and cap['launch']['memory']['available_pagefile']>=350*1024**2 and all(0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
  resources[name]=dict(seconds_after_imports=res['elapsed_after_imports'],largest_private_sample=max(z['private_bytes'] for z in cap['all_resource_samples']),sampled_not_true_or_nested_peak=True)
 print('STAGE final full182250colors,actualroot/ordinarymatrixbridge,order-reversal and finiteprofile checks',flush=True)
 cmd=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];et=time.perf_counter();p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,encoding='utf-8',timeout=120)
 cap=dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-et,stdout=p.stdout,stderr=p.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',cap);dump(C/'e4_capture.json',cap);assert p.returncode==0
 events=[json.loads(z) for z in p.stdout.splitlines() if z.strip()];exits=[z['exit_code'] for z in events if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED'
 assert next(z for z in events if z['event']=='step_finished' and z['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 old=(C/'old_git_tree.txt').read_bytes();assert old==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);subprocess.run(['git','diff','--exit-code','HEAD','--'],cwd=R,check=True)
 state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 files=[p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V793.md'];size=sum(p.stat().st_size for p in files);assert size<=64*1024**2
 out=dict(schema='REGULATOR_SOURCE_COLORS_G1_RECOVERY_VALIDATION_V1',execution_state='COMPLETED',evidence_validation='PASS_ACTUAL_SOURCE_COLOR_COVARIANCE_AND_PAIRED_FINITE_PROFILE_REFERENCE',scientific_acceptance='NOT_PERFORMED',base_HEAD=prep['base_HEAD'],state_sha256=state,paired_math=pairs,actual_used_polarized_root_monomials_verified=len(actual),actual_ordinary_ghost_mass_matrices_verified=True,assessments=assessments,finite_current='T_NM*(K_e-K_k); K_e_unequal_K_k_generically',joint_Schwartz_UV_first_IR_reference='ZERO_PAIRED_SELECTED_SOURCE_CURRENT_ONLY',individual_hard_radial='log(3/2)/(16*pi^2)',finite_IR_root_defect_preserved=True,historical_1126_count_matches_new_derivation_but_missing_historical_coefficients_not_authenticated=True,resources=resources,failures_this_increment=0,E4_launches=1,E4_step_exits=exits,historical_custody='EXIT2_SEVEN_UNRESOLVED_NOTPASS',old_mode_blob_entries_preserved=len(old.splitlines()),new_files_excluding_pending_receipt_and_final_capture={p.relative_to(R).as_posix():digest(p) for p in files},packet_bytes_excluding_pending_receipt_and_final_capture=size,final_review_seconds=time.perf_counter()-tick,full_V789_expanded_current_comparison_or_QGamma_D_target_or_QAP_E5_viability_claim=False)
 dump(O/'validation_receipt.json',out);print('RESULT '+json.dumps({k:out[k] for k in ['execution_state','evidence_validation','E4_step_exits','historical_custody','final_review_seconds']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
