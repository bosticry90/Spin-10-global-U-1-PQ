"""Independent literal even variations and five-radical width polynomials."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from fractions import Fraction as F
from functools import lru_cache
import importlib.util,json,sys,time,threading,os
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_integration';CONTROL=Path(__file__).resolve().parent
def load(n,p):
 sp=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);return u
old=load('independent_prior_qualified_recipe',ROOT/'calculations/canonical_so10_ghost_mass_g4_integration/integration.py');m=old.m;q=old.q;s=m.s;v=load('independent_radical_rationals',CONTROL.parent/'ghost-mass-g4-pole-v1-2026-10-18/verify.py');read=v.read;digest=v.digest
PARAM={'g3_etaH0_xi2_scalar1':(3,0,2,1),'g4_etaH1_xi1_scalar1':(4,1,1,1),'g4_etaH0_xi2_scalar1':(4,0,2,1),'g4_etaH0_xi0_scalar2':(4,0,0,2)};ANTI=v.ANTI;SQ=v.SQ
def mask_to_consumer(mask):return sum(1<<m.ex.SQUARES.index(value) for bit,value in enumerate(SQ) if mask&(1<<bit))
def mask_from_consumer(mask):return sum(1<<SQ.index(value) for bit,value in enumerate(m.ex.SQUARES) if mask&(1<<bit))
def cadd(A,B):
 d=dict(A)
 for k,z in B:d[k]=d.get(k,F(0))+z
 return tuple((k,z) for k,z in sorted(d.items()) if z)
def cscale(A,n):return tuple((k,z*n) for k,z in A if z*n)
@lru_cache(maxsize=131072)
def cmul(A,B):
 d={}
 for(a,b,ma),x in A:
  for(c,e,mb),y in B:
   value=x*y
   for bit,prime in enumerate(SQ):
    if ma&mb&(1<<bit):value*=prime
   key=a+c,b+e,ma^mb;d[key]=d.get(key,F(0))+value
 return tuple((k,z) for k,z in sorted(d.items()) if z)
def put(P,k,z):
 if z:P[k]=cadd(P.get(k,()),z)
 if k in P and not P[k]:del P[k]
def consumer(z):return m.ex.Coefficient({(a,b,mask_to_consumer(mask)):v for(a,b,mask),v in z})
def from_consumer(z):return tuple(((a,b,mask_from_consumer(mask)),v) for(a,b,mask),v in sorted(z.cells.items(),key=lambda p:(p[0][0],p[0][1],mask_from_consumer(p[0][2]))))
def token(n):
 name,_,jets=n.partition('__');return name,tuple(map(int,jets))
def serialize(t):
 n,j=t;return n+('__'+''.join(map(str,j)) if j else '')
def parity(n):return m.par[m.index[n]]
def canonical(seq):
 odds=[(m.index[t[0]],t[1]) for t in seq if parity(t[0])]
 if len(odds)!=len(set(odds)):return (),0
 return tuple(sorted(seq,key=lambda t:(m.index[t[0]],t[1]))),(-1)**sum(a>b for i,a in enumerate(odds) for b in odds[i+1:])
def product(P,Q):
 out={}
 for(gp,a),x in P.items():
  for(gq,b),y in Q.items():
   key,sg=canonical(a+b)
   if sg:put(out,(gp+gq,key),cscale(cmul(x,y),sg))
 return out
def decoded_hash(P):
 h=sha256();h.update(b'[')
 for i,((gp,word),z) in enumerate(sorted(P.items(),key=lambda p:(p[0][0],tuple((m.index[n],j) for n,j in p[0][1])))):
  if i:h.update(b',')
  cells=[[[a,b,mask_to_consumer(mask)],str(value)] for(a,b,mask),value in sorted(z,key=lambda p:(p[0][0],p[0][1],mask_to_consumer(p[0][2])))];h.update(json.dumps([gp,[[n,list(j)] for n,j in word],cells],separators=(',',':'),ensure_ascii=True).encode())
 h.update(b']');return h.hexdigest()
@lru_cache(None)
def parse(text):
 z=s.sympify(text,locals={'g10':m.g,'xi':m.xi,'eta_H':m.etaH,'reference_width_M':m.xi,'reference_width_H':m.etaH});out={}
 for(gp,xp,hp),co in s.Poly(s.expand(z),m.g,m.xi,m.etaH).terms():
  if co:out[gp]=cadd(out.get(gp,()),tuple(((xp,hp,mask),value) for mask,value in v.number(str(co))))
 return tuple(sorted(out.items()))
def from_rows(rows):
 out={}
 for row in rows:
  word=tuple(token(n) for n in row['word']);key,sg=canonical(word);assert key==word and sg==1
  for gp,z in parse(row['coefficient']):put(out,(gp,key),z)
 return out
def result_rows(rows):
 out={}
 for row in rows:
  parsed=parse(row['coefficient']);assert len(parsed)==1 and parsed[0][0]==0;key,sg=canonical(tuple(token(n) for n in row['word']));assert sg==1;put(out,(row['g'],key),parsed[0][1])
 return out
@lru_cache(maxsize=8192)
def format_coeff(signature):
 expression=0
 for gp,cells in signature:
  for(xp,hp,mask),value in cells:expression+=m.g**gp*m.xi**xp*m.etaH**hp*v.sym(((mask,value),))
 return q.sumtext((str(s.expand(expression)),))
def delta_and_node(data):
 P={};parts=defaultdict(dict)
 for label,rows in data['canonical_parameter_tables'].items():
  gp,hp,xp,degree=PARAM[label]
  for word,cells in rows:
   key=tuple((n,()) for n in word);assert canonical(key)==(key,1);value=tuple(((xp,hp,mask),F(n,d)) for mask,n,d in cells);put(P,(gp,key),value)
 for(gp,key),value in P.items():parts[key][gp]=value
 node={key:format_coeff(tuple(sorted(values.items()))) for key,values in parts.items()};assert len(node)==719730
 return P,node
def ids_word(word):return tuple((m.index[n],j) for n,j in word)
def raw_rows_from_names(P):return [{'word':[serialize(t) for t in key],'coefficient':z} for key,z in sorted(P.items(),key=lambda p:ids_word(p[0]))]
def kind(n):return 'E' if n.startswith('zz_da') else'x' if n.startswith('x_') else'a' if n in ANTI else'C' if n.startswith('C') else'J' if m.index[n] in m.sources else'B' if n.startswith('B') else'A' if n.startswith('A') else'L' if n.startswith('L') or n.startswith('b') else'OTHER'
def degree(word):
 kinds=tuple(sorted(kind(n) for n,j in word));return len(kinds)-2 if kinds in [('C','E','x'),('C','E','x','x')] else 0
def decode_compact(d):
 assert d['schema']=='FINITE_EXACT_COMPONENT_INTERNED_CELLS_V1' and d['alphabet']==m.names and d['basis_squared']==list(m.ex.SQUARES);coefs=[];out={};used=set()
 for rows in d['coefficients']:
  assert rows and len({(a,b,mask) for a,b,mask,n,den in rows})==len(rows);coefs.append(tuple(((a,b,mask_from_consumer(mask)),F(n,den)) for a,b,mask,n,den in sorted(rows,key=lambda r:(r[0],r[1],mask_from_consumer(r[2])))))
 for gp,word,cid in d['monomials']:
  assert type(cid) is int and 0<=cid<len(coefs);assert all(type(n) is int and 0<=n<len(m.names) for n,j in word);key=tuple((m.names[n],tuple(j)) for n,j in word);assert canonical(key)==(key,1) and (gp,key) not in out;out[gp,key]=coefs[cid];used.add(cid)
 assert used==set(range(len(coefs))) and decoded_hash(out)==d['sha256_exact_cells'];return out
def fixture():
 assert mask_to_consumer(8)==16 and mask_to_consumer(16)==8 and mask_from_consumer(16)==8
 for a in range(32):
  x=(((0,0,a),F(1)),);assert from_consumer(consumer(x))==x
  for b in range(32):assert from_consumer(consumer(x)*consumer((((0,0,b),F(1)),)))==cmul(x,(((0,0,b),F(1)),))
 assert canonical((('ub12',()),('C0',()),('x_Phi_0',())))[1]==-1 and canonical((('C0',()),('C0',())))[1]==0
 return True

def main():
 tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(OUT/'preparation_integration_validation_v3.json');assert digest(Path(__file__))==prep['validator_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allowed={str(Path(p).resolve()) for p in prep['read_json']}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('INDEPENDENT_PHASE_A_INTEGRATION_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_JSON',str(p))
 sys.addaudithook(guard);m.setup()
 for i in range(45):n=f'zz_da{i:02}';m.index[n]=len(m.names);m.names.append(n);m.par.append(1);m.external.add(m.index[n])
 assert fixture();a=read(OUT/'primary_integration_v3_result.json');b=read(OUT/'replay_integration_v3_result.json');assert a['schema']==b['schema']=='SCALAR_GHOST_COMPLETE_INTEGRATION_ONLY_V3'
 for key in a.keys()-{'route','updated_known_recipe','stages','elapsed_after_imports','original_completed_native_v2_result_path','original_completed_native_v2_result_sha256','metadata_correction_elapsed_seconds'}:assert a[key]==b[key],key
 assert not a['component_phase_qualified'] and a['component_phase_still_required'];del b
 data=old.auth('canonical_so10_scalar_ghost_canonical','primary_result.json');delta,node=delta_and_node(data);assert decoded_hash(delta)==a['new_delta_sha256_exact_cells'] and len(delta)==a['new_delta_g_word_positions'];assert all(not any(n.startswith('bar') for n,j in word) for gp,word in delta);print('STAGE independent all730610_cells_and_whole_delta_literal_basis_bridge',flush=True)
 tables,previous,path=old.current_tables('primary');before=q.combine(tables);prior={tuple((m.names[n],j) for n,j in key):z for key,z in before.items()};assert len(prior)==155143 and q.hashrows(raw_rows_from_names(prior))==previous['updated_known_sha256']==a['prior_known_sha256'];assert not set(prior)&set(node) and len(node)==a['new_word_positions']==719730
 updated=dict(prior);updated.update(node);assert len(updated)==a['updated_known_terms']==874873 and q.hashrows(raw_rows_from_names(updated))==a['updated_known_sha256'];assert {k:z for k,z in updated.items() if k not in node}==prior
 for value in set(node.values()):assert q.sumtext(tuple(sorted([value,str(-q.num(value))])))=='0' and q.sumtext(tuple(sorted([value,value])))!=value
 assert len(set(node.values()))==a['unique_actual_coefficient_strings'] and {k:z for k,z in prior.items() if any(m.index[n] in m.sources for n,j in k)}=={k:z for k,z in updated.items() if any(m.index[n] in m.sources for n,j in k)};print('STAGE independent entire874873_current_hash_exact_inverse_double_no_overlap',flush=True)
 source={k:z for k,z in prior.items() if any(m.index[n] in m.sources for n,j in k)};S=from_rows(raw_rows_from_names(source));snap=a['dependent_source_and_scalar_snapshot'];assert len(source)==snap['actual_source_raw_words'] and q.hashrows(raw_rows_from_names(source))==snap['actual_source_raw_sha256'];assert len(S)==146663 and decoded_hash(S)==snap['actual_source_sha256_exact_cells']
 primitive=old.auth('canonical_so10_local_source_primitive','primary_v2_result.json');assert S==result_rows(primitive['normalized_source_image']);assert all(sum(m.index[n] in m.sources for n,j in word)==1 and not any(j for n,j in word if m.index[n] in m.sources) for gp,word in S)
 free_rows=[r for r in raw_rows_from_names(prior) if not any(m.index[token(n)[0]] in m.sources for n in r['word'])];free=from_rows(free_rows);assert len(free)==a['sourcefree_prior_positions']==41452 and len(free)+len(delta)==a['sourcefree_updated_positions']==765174 and len(free_rows)==a['prior_sourcefree_raw_word_positions']==34924 and len(updated)-len(source)==a['updated_sourcefree_raw_word_positions']==754654 and len(S)+len(free)+len(delta)==a['updated_total_g_word_positions']==911837;assert a['sourcefree_position_convention']=='g_power_and_canonical_field_word_widths_in_coefficient' and a['superseded_mixed_sourcefree_count']==761182 and a['sourcefree_prior_positions']+a['new_word_positions']!=a['sourcefree_updated_positions'];original=read(Path(a['original_completed_native_v2_result_path']));assert digest(Path(a['original_completed_native_v2_result_path']))==a['original_completed_native_v2_result_sha256']
 for key,value in original.items():
  if key not in ['schema','scientific_disposition','sourcefree_updated_positions']:assert a[key]==value,key
 print('STAGE independent actual_raw_field_and_g_word_count_conventions',flush=True)
 scalar_rows=[r for r in raw_rows_from_names(prior) if tuple(sorted(kind(token(n)[0]) for n in r['word'])) in [('C','a','x'),('C','a','x','x')]];oldscalar=from_rows(scalar_rows);assert oldscalar==decode_compact(snap['prior_complete_ordinary_scalar_projection']) and len(oldscalar)==snap['prior_scalar_projection_positions'] and decoded_hash(oldscalar)==snap['full_prior_scalar_projection_sha256_exact_cells'];print('STAGE independent complete_actual_source_and_old_scalar_snapshot',flush=True)
 cap=read(OUT/'primary_capture.json');assert cap['exit_code']==124 and cap['execution_state']=='FAILED' and cap['post_run_observations_qualified'] and not cap['calculation_completed']
 for role in ['primary','replay']:
  cap=read(OUT/(role+'_integration_v2_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
 assert not any(a['all_seven_quantum_flags_false'].values()) and a['failed_combined_worker_count']==1 and a['this_phase_new_native_failure_count']==0 and a['sourceimage_positions']==146663
 result={'schema':'COMPLETE_SCALAR_GHOST_INTEGRATION_ONLY_INDEPENDENT_VALIDATION_V3','execution_state':'COMPLETED','scientific_disposition':'EXACT_ONCE_COMPLETE_SCALAR_GHOST_INTEGRATION_QUALIFIED_COMPONENT_PENDING','input_sha256':prep['input_sha256'],'all32_1024_basis_products_inverse_conjugation_and_width_bridge_verified':True,'every730610_canonical_parameter_cell_and_delta_word_verified':True,'whole_old_and874873_updated_functional_hashes_verified':True,'no_overlap_exact_inverse_double_and_all_untouched_sources_verified':True,'full146663_actual_source_matches_qualified_reference':True,'complete_prior_scalar_projection_snapshot_verified':True,'no_new_unbroken_antighost_dependence_verified':True,'original_combined_timeout_and_all_failed_evidence_preserved':True,'updated_known_terms':a['updated_known_terms'],'updated_known_sha256':a['updated_known_sha256'],'new_delta_g_word_positions':len(delta),'new_delta_sha256_exact_cells':decoded_hash(delta),'source_projection_sha256_exact_cells':decoded_hash(S),'actual_sourcefree_g_word_count_reconstructed':True,'mixed_raw_and_g_word_diagnostic_rejected':True,'sourcefree_updated_g_word_positions':len(free)+len(delta),'sourcefree_updated_raw_field_words':len(updated)-len(source),'all_corrected_records_preserve_original_coefficients_and_hashes':True,'prior_scalar_projection_positions':len(oldscalar),'failed_original_combined_workers':1,'new_native_phase_failures':0,'independent_phase_failures':0,'fresh_byte_identical_replay_pairs_claimed':0,'component_phase_qualified':False,'component_phase_still_required':True,'independent_insertion_QAP_E5_A5':'UNQUALIFIED','authority_and_physical_inputs_unchanged':True,'shared_limits':'Qualified measured poles/current recipe/action/source/UV premises,canonical coefficient normal-form library and AI author shared. Independent incoming radical arithmetic/literal node/source projection and complete hashes,not scalar component or full quantum restoration','elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
