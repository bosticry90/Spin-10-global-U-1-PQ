from pathlib import Path
from hashlib import sha256
import json,ast,subprocess
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_integration';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='3d62db7bb11af0f66d6078071c3fdbf5aa28ebe3';files={OUT/'preparation_integration_v2.json',OUT/'COUNT_CONVENTION_CORRECTION_V3.md',OUT/'integration_v2.py',OUT/'integration_v3.py',CONTROL/'derive_counts_v3.py',Path(__file__)}
for role in ['primary','replay']:
 p=OUT/(role+'_integration_v2_result.json');d=read(p);cap=OUT/(role+'_integration_v2_capture.json');c=read(cap);assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and cap.read_bytes()==(CONTROL/(role+'_integration_v2_full_capture.json')).read_bytes();prior=Path(d['updated_known_recipe']['previous_recipe_path']);files.update([p,cap,CONTROL/(role+'_integration_v2_full_capture.json'),prior,prior.parent/'validation_receipt.json'])
a=read(OUT/'primary_integration_v2_result.json');b=read(OUT/'replay_integration_v2_result.json')
for key in a.keys()-{'route','updated_known_recipe','stages','elapsed_after_imports'}:assert a[key]==b[key],key
for p in [OUT/'integration_v3.py',CONTROL/'derive_counts_v3.py',Path(__file__)]:
 ast.parse(p.read_text(encoding='utf-8'));copy=Path(str(p)+'.source.txt')
 with copy.open('xb') as f:f.write(p.read_bytes())
 files.add(copy)
d={'schema':'COUNT_CONVENTION_CORRECTION_PREPARATION_V3','base_commit':head,'source_sha256':digest(CONTROL/'derive_counts_v3.py'),'input_sha256':{str(p):digest(p) for p in sorted(files)},'physics_worker_repeated':False,'seconds_limit':30,'independent_integration_validation_still_required':True}
with(OUT/'preparation_count_correction_v3.json').open('xb') as f:f.write(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('METADATA_CORRECTION_FROZEN',len(files))
