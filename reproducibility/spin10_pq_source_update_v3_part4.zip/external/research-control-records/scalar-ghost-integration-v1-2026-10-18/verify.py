"""Independent literal even variations and five-radical width polynomials."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from fractions import Fraction as F
from functools import lru_cache
import importlib.util,json,sys,time,threading,os
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_integration';CONTROL=Path(__file__).resolve().parent
def load(n,p):
 sp=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);return u
old=load('independent_prior_qualified_recipe',ROOT/'calculations/canonical_so10_ghost_mass_g4_integration/integration.py');m=old.m;q=old.q;s=m.s;v=load('independent_radical_rationals',CONTROL.parent/'ghost-mass-g4-pole-v1-2026-10-18/verify.py');read=v.read;digest=v.digest
PARAM={'g3_etaH0_xi2_scalar1':(3,0,2,1),'g4_etaH1_xi1_scalar1':(4,1,1,1),'g4_etaH0_xi2_scalar1':(4,0,2,1),'g4_etaH0_xi0_scalar2':(4,0,0,2)};ANTI=v.ANTI;SQ=v.SQ
def mask_to_consumer(mask):return sum(1<<m.ex.SQUARES.index(value) for bit,value in enumerate(SQ) if mask&(1<<bit))
def mask_from_consumer(mask):return sum(1<<SQ.index(value) for bit,value in enumerate(m.ex.SQUARES) if mask&(1<<bit))
def cadd(A,B):
 d=dict(A)
 for k,z in B:d[k]=d.get(k,F(0))+z
 return tuple((k,z) for k,z in sorted(d.items()) if z)
def cscale(A,n):return tuple((k,z*n) for k,z in A if z*n)
@lru_cache(maxsize=131072)
def cmul(A,B):
 d={}
 for(a,b,ma),x in A:
  for(c,e,mb),y in B:
   value=x*y
   for bit,prime in enumerate(SQ):
    if ma&mb&(1<<bit):value*=prime
   key=a+c,b+e,ma^mb;d[key]=d.get(key,F(0))+value
 return tuple((k,z) for k,z in sorted(d.items()) if z)
def put(P,k,z):
 if z:P[k]=cadd(P.get(k,()),z)
 if k in P and not P[k]:del P[k]
def consumer(z):return m.ex.Coefficient({(a,b,mask_to_consumer(mask)):v for(a,b,mask),v in z})
def from_consumer(z):return tuple(((a,b,mask_from_consumer(mask)),v) for(a,b,mask),v in sorted(z.cells.items(),key=lambda p:(p[0][0],p[0][1],mask_from_consumer(p[0][2]))))
def token(n):
 name,_,jets=n.partition('__');return name,tuple(map(int,jets))
def serialize(t):
 n,j=t;return n+('__'+''.join(map(str,j)) if j else '')
def parity(n):return m.par[m.index[n]]
def canonical(seq):
 odds=[t for t in seq if parity(t[0])]
 if len(odds)!=len(set(odds)):return (),0
 return tuple(sorted(seq,key=lambda t:(m.index[t[0]],t[1]))),(-1)**sum(a>b for i,a in enumerate(odds) for b in odds[i+1:])
def product(P,Q):
 out={}
 for(gp,a),x in P.items():
  for(gq,b),y in Q.items():
   key,sg=canonical(a+b)
   if sg:put(out,(gp+gq,key),cscale(cmul(x,y),sg))
 return out
def decoded_hash(P):
 h=sha256();h.update(b'[')
 for i,((gp,word),z) in enumerate(sorted(P.items(),key=lambda p:(p[0][0],tuple((m.index[n],j) for n,j in p[0][1])))):
  if i:h.update(b',')
  cells=[[[a,b,mask_to_consumer(mask)],str(value)] for(a,b,mask),value in sorted(z,key=lambda p:(p[0][0],p[0][1],mask_to_consumer(p[0][2])))];h.update(json.dumps([gp,[[n,list(j)] for n,j in word],cells],separators=(',',':'),ensure_ascii=True).encode())
 h.update(b']');return h.hexdigest()
@lru_cache(None)
def parse(text):
 z=s.sympify(text,locals={'g10':m.g,'xi':m.xi,'eta_H':m.etaH,'reference_width_M':m.xi,'reference_width_H':m.etaH});out={}
 for(gp,xp,hp),co in s.Poly(s.expand(z),m.g,m.xi,m.etaH).terms():
  if co:out[gp]=cadd(out.get(gp,()),tuple(((xp,hp,mask),value) for mask,value in v.number(str(co))))
 return tuple(sorted(out.items()))
def from_rows(rows):
 out={}
 for row in rows:
  word=tuple(token(n) for n in row['word']);key,sg=canonical(word);assert key==word and sg==1
  for gp,z in parse(row['coefficient']):put(out,(gp,key),z)
 return out
def result_rows(rows):
 out={}
 for row in rows:
  parsed=parse(row['coefficient']);assert len(parsed)==1 and parsed[0][0]==0;key,sg=canonical(tuple(token(n) for n in row['word']));assert sg==1;put(out,(row['g'],key),parsed[0][1])
 return out
@lru_cache(maxsize=8192)
def format_coeff(signature):
 expression=0
 for gp,cells in signature:
  for(xp,hp,mask),value in cells:expression+=m.g**gp*m.xi**xp*m.etaH**hp*v.sym(((mask,value),))
 return q.sumtext((str(s.expand(expression)),))
def delta_and_node(data):
 P={};parts=defaultdict(dict)
 for label,rows in data['canonical_parameter_tables'].items():
  gp,hp,xp,degree=PARAM[label]
  for word,cells in rows:
   key=tuple((n,()) for n in word);assert canonical(key)==(key,1);value=tuple(((xp,hp,mask),F(n,d)) for mask,n,d in cells);put(P,(gp,key),value)
 for(gp,key),value in P.items():parts[key][gp]=value
 node={key:format_coeff(tuple(sorted(values.items()))) for key,values in parts.items()};assert len(node)==719730
 return P,node
def ids_word(word):return tuple((m.index[n],j) for n,j in word)
def raw_rows_from_names(P):return [{'word':[serialize(t) for t in key],'coefficient':z} for key,z in sorted(P.items(),key=lambda p:ids_word(p[0]))]
def kind(n):return 'E' if n.startswith('zz_da') else'x' if n.startswith('x_') else'a' if n in ANTI else'C' if n.startswith('C') else'J' if m.index[n] in m.sources else'B' if n.startswith('B') else'A' if n.startswith('A') else'L' if n.startswith('L') or n.startswith('b') else'OTHER'
def degree(word):
 kinds=tuple(sorted(kind(n) for n,j in word));return len(kinds)-2 if kinds in [('C','E','x'),('C','E','x','x')] else 0
def decode_compact(d):
 assert d['schema']=='FINITE_EXACT_COMPONENT_INTERNED_CELLS_V1' and d['alphabet']==m.names and d['basis_squared']==list(m.ex.SQUARES);coefs=[];out={};used=set()
 for rows in d['coefficients']:
  assert rows and len({(a,b,mask) for a,b,mask,n,den in rows})==len(rows);coefs.append(tuple(((a,b,mask_from_consumer(mask)),F(n,den)) for a,b,mask,n,den in sorted(rows,key=lambda r:(r[0],r[1],mask_from_consumer(r[2])))))
 for gp,word,cid in d['monomials']:
  assert type(cid) is int and 0<=cid<len(coefs);key=tuple((m.names[n],tuple(j)) for n,j in word);assert canonical(key)==(key,1) and (gp,key) not in out;out[gp,key]=coefs[cid];used.add(cid)
 assert used==set(range(len(coefs))) and decoded_hash(out)==d['sha256_exact_cells'];return out
def fixture():
 assert mask_to_consumer(8)==16 and mask_to_consumer(16)==8 and mask_from_consumer(16)==8
 for a in range(32):
  x=(((0,0,a),F(1)),);assert from_consumer(consumer(x))==x
  for b in range(32):assert from_consumer(consumer(x)*consumer((((0,0,b),F(1)),)))==cmul(x,(((0,0,b),F(1)),))
 assert canonical((('ub12',()),('C0',()),('x_Phi_0',())))[1]==-1 and canonical((('C0',()),('C0',())))[1]==0
 return True
def main():
 tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(OUT/'validation_preparation.json');assert digest(Path(__file__))==prep['validator_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allowed={str(Path(p).resolve()) for p in prep['read_json']}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('INDEPENDENT_SCALAR_COMPONENT_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_JSON',str(p))
 sys.addaudithook(guard);m.setup()
 for i in range(45):n=f'zz_da{i:02}';m.index[n]=len(m.names);m.names.append(n);m.par.append(1);m.external.add(m.index[n])
 assert fixture();a=read(OUT/'primary_result.json');b=read(OUT/'replay_result.json');assert a['updated_known_sha256']==b['updated_known_sha256'] and a['complete_scalar_assessment']==b['complete_scalar_assessment'];del b
 data=old.auth('canonical_so10_scalar_ghost_canonical','primary_result.json');delta,node=delta_and_node(data);assert decoded_hash(delta)==a['new_delta_sha256_exact_cells'];print('STAGE independent complete_literal_coefficient_bridge_and_delta',flush=True)
 tables,previous,path=old.current_tables('primary');before_id=q.combine(tables);prior={tuple((m.names[n],j) for n,j in key):z for key,z in before_id.items()};assert len(prior)==155143 and q.hashrows(raw_rows_from_names(prior))==previous['updated_known_sha256']==a['prior_known_sha256'];assert not set(prior)&set(node);updated=dict(prior);updated.update(node);assert len(updated)==a['updated_known_terms']==874873 and q.hashrows(raw_rows_from_names(updated))==a['updated_known_sha256'];assert {k:z for k,z in updated.items() if k not in node}==prior
 for value in set(node.values()):assert q.sumtext(tuple(sorted([value,str(-q.num(value))])))=='0' and q.sumtext(tuple(sorted([value,value])))!=value
 assert {k:z for k,z in prior.items() if any(m.index[n] in m.sources for n,j in k)}=={k:z for k,z in updated.items() if any(m.index[n] in m.sources for n,j in k)};print('STAGE independent entire_old_new_hash_inverse_double_and_sources',flush=True)
 source_rows=[r for r in raw_rows_from_names(prior) if any(m.index[token(n)[0]] in m.sources for n in r['word'])];S=from_rows(source_rows);assert len(S)==146663;primitive=old.auth('canonical_so10_local_source_primitive','primary_v2_result.json');assert S==result_rows(primitive['normalized_source_image']);op=old.auth('canonical_so10_broken_antighost_operator','primary_v2_result.json','validation_v2_receipt.json');kernels={name:result_rows(rows) for name,rows in op['all33_kernel_maps'].items()};assert len(kernels)==479
 O={};old_rows=[r for r in raw_rows_from_names(prior) if tuple(sorted(kind(token(n)[0]) for n in r['word'])) in [('C','a','x'),('C','a','x','x')]];ordinary=from_rows(old_rows)
 for key,value in delta.items():put(ordinary,key,value)
 for(gp,word),value in ordinary.items():
  anti=next(n for n,j in word if n in ANTI);assert not anti.startswith('bar');new=tuple((f'zz_da{int(n[2:]):02}',j) if n==anti else(n,j) for n,j in word);canon,sg=canonical(new);put(O,(gp,canon),cscale(value,sg))
 source={0:{},1:{}};eligible=set();routes=defaultdict(set);ordered=sorted(S,key=lambda key:(key[0],ids_word(key[1])))
 for idx,key in enumerate(ordered):
  gp,word=key;positions=[(i,n,j) for i,(n,j) in enumerate(word) if m.index[n] in m.sources];assert len(positions)==1;pos,J,jets=positions[0];assert not jets;rest=word[:pos]+word[pos+1:];prefix=sum(parity(n) for n,j in word[:pos]);left_sign=(-1)**(parity(J)*prefix)
  for(gv,kw),co in kernels.get(J,{}).items():
   combined,sg=canonical(kw+rest)
   if not sg:continue
   d=degree(combined)
   if not d:continue
   js=sum(len(j) for n,j in combined);assert js<=2-d and gv in [0,1] and sum(parity(n) for n,j in kw)%2==parity(J);assert js==0;eligible.add(idx);routes[gp+gv,gv,d,js].add(idx);put(source[gv],(gp+gv,combined),cscale(cmul(co,S[key]),left_sign*sg))
 expected=dict(O)
 for part in source.values():
  for key,value in part.items():put(expected,key,cscale(value,-1))
 assert all(sum(len(j) for n,j in word)==0 for gp,word in expected),'ACTUAL_ZEROJET_SCALAR_INPUT_PREMISE_FAILED';c=a['complete_scalar_assessment'];assert decode_compact(c['complete_component'])==expected and decoded_hash(O)==c['ordinary_component_sha256_exact_cells'] and decoded_hash(expected)==c['raw_component_sha256_exact_cells'];assert all(not decode_compact(d) for d in c['four_explicit_currents'])
 census=c['complete_predecessor_census'];assert len(eligible)==census['all_eligible_source_positions'] and decoded_hash(S)==census['source_sha256_exact_cells'];assert [{'total_g':gp,'kernel_g':gv,'scalar_degree':d,'jets':js,'source_indices':sorted(ids)} for(gp,gv,d,js),ids in sorted(routes.items())]==census['complete_routes']
 for gv in [0,1]:assert decoded_hash(source[gv])==c['source_component_by_kernel_g'][str(gv)]['sha256_exact_cells']
 actual=Counter((gp,degree(word),sum(len(j) for n,j in word)) for gp,word in expected);assert all(r['nonzero_positions']==sum(v for(gp,d,js),v in actual.items() if gp==r['g'] and d==r['scalar_degree']) for r in c['whole_component_by_g_and_scalar_degree']);assert not any(a['all_seven_quantum_flags_false'].values()) and a['sourceimage_positions']==146663 and not a['independent_new_insertion_loop_or_full_Gamma_variation'];print('STAGE independent complete_current_source_census_and_literal_scalar_component',flush=True)
 result={'schema':'SCALAR_GHOST_INTEGRATION_COMPONENT_INDEPENDENT_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':'EXACT_ONCE_SCALAR_GHOST_INTEGRATION_AND_COMPLETE_SCALAR_COMPONENT_QUALIFIED','input_sha256':prep['input_sha256'],'all32_1024_literal_basis_products_inverse_and_width_bridge_verified':True,'complete_canonical_delta_and_full_current_old_new_hashes_verified':True,'exact_once_inverse_double_all_sources_untouched_and_no_overlap_verified':True,'full_source_image_and_all_kernel_even_parities_verified':True,'entire_actual_source_predecessor_census_reconstructed':True,'all_scalar_component_coefficients_and_zero_complements_verified':True,'all_four_explicit_currents_verified_zero_in_actual_domain':True,'literal_even_replacement_left_source_Euler_and_independent_radical_arithmetic':True,'updated_known_terms':a['updated_known_terms'],'updated_known_sha256':a['updated_known_sha256'],'new_delta_g_word_positions':len(delta),'scalar_component_disposition':c['component_disposition'],'complete_scalar_component_sha256_exact_cells':decoded_hash(expected),'whole_component_by_g_and_scalar_degree':c['whole_component_by_g_and_scalar_degree'],'eligible_actual_source_positions':len(eligible),'native_worker_failures':0,'independent_worker_failures':0,'fresh_byte_identical_replay_pairs_claimed':0,'new_independent_insertion_loop_full_QAP_E5_A5':'NOT_PERFORMED_UNQUALIFIED','authority_and_physical_inputs_unchanged':True,'shared_limits':'Same measured poles/current recipe/source/kernel/action/UV premises,coefficient normal-form library and AI author. Separate incoming radical arithmetic and literal even/source left variations,not full quantum restoration or independent scientific validation','elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
