from pathlib import Path
from hashlib import sha256
import json,sys,time
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_integration';CONTROL=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
from audit_a10_e5_antighost_vector import resource,line_json
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
prep=read(OUT/'preparation_integration_validation_v3.json');assert digest(Path(__file__))==prep['controller_sha256'] and Path(__file__).read_bytes()==Path(str(Path(__file__))+'.source.txt').read_bytes();assert not(OUT/'integration_validation_capture_v3.json').exists()
tick=time.perf_counter();cap=capture([sys.executable,'-B',str(CONTROL/'verify_integration_v3.py')]);cap['parent_wall_seconds']=time.perf_counter()-tick
raw=json.dumps(cap,sort_keys=True,separators=(',',':')).encode()+b'\n'
for p in [OUT/'integration_validation_capture_v3.json',CONTROL/'integration_validation_full_capture_v3.json']:
 with p.open('xb') as f:f.write(raw)
if cap['execution_state']!='COMPLETED':print(cap['stdout_and_stderr'],flush=True)
resource(cap);r=line_json(cap['stdout_and_stderr'],'RESULT ');assert r['execution_state']=='COMPLETED' and 0<r['elapsed_after_imports']<300 and not r['component_phase_qualified'] and r['component_phase_still_required']
with(OUT/'integration_validation_receipt_v3.json').open('xb') as f:f.write(json.dumps(r,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('INTEGRATION_VALIDATED '+digest(OUT/'integration_validation_receipt_v3.json'),flush=True)
