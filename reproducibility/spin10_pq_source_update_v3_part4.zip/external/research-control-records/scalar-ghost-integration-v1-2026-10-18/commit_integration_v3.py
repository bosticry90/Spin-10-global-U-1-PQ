from pathlib import Path
from hashlib import sha256
import json,subprocess
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_integration';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def git(*args,raw=False):
 z=subprocess.check_output(['git',*args],cwd=ROOT);return z if raw else z.decode('utf-8').strip()
base=read(OUT/'preparation_integration_v2.json')['base_commit'];assert git('rev-parse','HEAD')==base=='3d62db7bb11af0f66d6078071c3fdbf5aa28ebe3'
r=read(OUT/'integration_validation_receipt_v3.json');assert r['schema']=='COMPLETE_SCALAR_GHOST_INTEGRATION_ONLY_INDEPENDENT_VALIDATION_V3' and r['execution_state']=='COMPLETED' and r['scientific_disposition']=='EXACT_ONCE_COMPLETE_SCALAR_GHOST_INTEGRATION_QUALIFIED_COMPONENT_PENDING'
for key,value in r.items():
 if type(value) is bool and key!='component_phase_qualified':assert value,key
assert r['component_phase_qualified'] is False and r['component_phase_still_required'] is True and r['failed_original_combined_workers']==1 and r['new_native_phase_failures']==r['independent_phase_failures']==r['fresh_byte_identical_replay_pairs_claimed']==0 and r['independent_insertion_QAP_E5_A5']=='UNQUALIFIED'
assert digest(OUT/'integration_validation_receipt_v3.json')=='99c192cc7fa6cf22b638af35d787ccc50b8db399851fc5d645a33e355eccba44'
maps={}
for name in ['preparation.json','preparation_integration_v2.json','preparation_count_correction_v3.json','count_correction_v3_receipt.json','preparation_integration_validation_v3.json','integration_validation_receipt_v3.json']:
 d=read(OUT/name);maps[name]=len(d['input_sha256'])
 for p,h in d['input_sha256'].items():assert digest(Path(p))==h,(name,p)
assert list(maps.values())==[1849,1861,18,18,1887,1887]
for folder in [OUT,CONTROL]:
 for p in folder.glob('*.source.txt'):assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes(),p
failed=read(OUT/'primary_capture.json');assert failed['execution_state']=='FAILED' and failed['exit_code']==124 and not failed['calculation_completed'] and failed['post_run_observations_qualified'] and not(OUT/'primary_result.json').exists() and not(OUT/'replay_capture.json').exists() and (OUT/'primary_capture.json').read_bytes()==(CONTROL/'primary_full_capture.json').read_bytes()
for role in ['primary','replay']:
 stem=role+'_integration_v2';cap=read(OUT/(stem+'_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and cap['private_allocation_limit_bytes']==8*1024**3
 assert (OUT/(stem+'_capture.json')).read_bytes()==(CONTROL/(stem+'_full_capture.json')).read_bytes() and cap['all_resource_samples'] and all('query_error' not in z and 0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
 original=read(OUT/(stem+'_result.json'));d=read(OUT/(role+'_integration_v3_result.json'));assert 0<original['elapsed_after_imports']<300 and d['original_completed_native_v2_result_sha256']==digest(OUT/(stem+'_result.json'))
 for k,value in original.items():
  if k not in ['schema','scientific_disposition','sourcefree_updated_positions']:assert d[k]==value,k
 assert original['sourcefree_updated_positions']==d['superseded_mixed_sourcefree_count']==761182 and d['sourcefree_updated_positions']==r['sourcefree_updated_g_word_positions']==765174 and d['updated_sourcefree_raw_word_positions']==r['sourcefree_updated_raw_field_words']==754654 and d['prior_sourcefree_raw_word_positions']==34924 and d['updated_total_g_word_positions']==911837
cap=read(OUT/'integration_validation_capture_v3.json');assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and (OUT/'integration_validation_capture_v3.json').read_bytes()==(CONTROL/'integration_validation_full_capture_v3.json').read_bytes();assert all('query_error' not in z and 0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples']) and 0<r['elapsed_after_imports']<300
a=read(OUT/'primary_integration_v3_result.json');b=read(OUT/'replay_integration_v3_result.json')
for key in a.keys()-{'route','updated_known_recipe','stages','elapsed_after_imports','original_completed_native_v2_result_path','original_completed_native_v2_result_sha256','metadata_correction_elapsed_seconds'}:assert a[key]==b[key],key
assert a['updated_known_terms']==r['updated_known_terms']==874873 and a['updated_known_sha256']==r['updated_known_sha256']=='e1e30f1acd769b5d2140613f17d7b75b0f6fdd905f15bb6b009dc2438015fa84' and a['new_delta_g_word_positions']==r['new_delta_g_word_positions']==723722 and a['new_delta_sha256_exact_cells']==r['new_delta_sha256_exact_cells']=='08ceb5b773993034bbd8b0ed256762349a8c9a5809c09514d312c5e07d76442b'
assert a['new_word_positions']==719730 and a['changed_existing_word_positions']==a['removed_existing_word_positions']==0 and a['unique_actual_coefficient_strings']==1210 and all(a['coefficient_basis_adapter_proof'].values()) and not any(a['all_seven_quantum_flags_false'].values()) and not a['component_phase_qualified'] and a['component_phase_still_required']
snap=a['dependent_source_and_scalar_snapshot'];assert snap['actual_source_g_word_positions']==146663 and snap['actual_source_raw_words']==120219 and snap['actual_source_sha256_exact_cells']==r['source_projection_sha256_exact_cells']=='b1171c9963ff4d5fc1c1497ab70d781f1c9ea36e77ce5507563fe70d3af8cc88' and snap['prior_scalar_projection_positions']==r['prior_scalar_projection_positions']==0
metadata=read(OUT/'count_correction_v3_receipt.json');assert metadata['execution_state']=='COMPLETED' and metadata['no_coefficients_or_hashes_changed'] and metadata['no_new_physics_worker_or_replay'] and 0<metadata['seconds']<30
for role in ['primary','replay']:assert metadata['corrected_result_sha256'][role]==digest(OUT/(role+'_integration_v3_result.json'))
for p in ['AGENTS.md','CHARTER.md','README.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md']:assert git('show',base+':'+p,raw=True)==(ROOT/p).read_bytes(),p
paths=sorted([p.relative_to(ROOT).as_posix() for p in OUT.iterdir() if p.is_file()]+['docs/RESEARCH_EXECUTION_HANDOFF_V283.md']);assert set(git('ls-files','--others','--exclude-standard').splitlines())==set(paths) and not git('diff','--name-only') and not git('diff','--cached','--name-only')
for p in [ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V283.md',OUT/'RESULT_INTEGRATION_V4.md']:assert digest(OUT/'integration_validation_receipt_v3.json') in p.read_text(encoding='utf-8')
subprocess.check_call(['git','-c','core.autocrlf=false','-c','core.longpaths=true','add','--',*paths],cwd=ROOT);assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
for p in paths:assert git('show',':'+p,raw=True)==(ROOT/p).read_bytes(),p
subprocess.check_call(['git','diff','--cached','--check'],cwd=ROOT);subprocess.check_call(['git','commit','-m','Integrate complete scalar ghost pole with corrected counts and preserved timeout'],cwd=ROOT)
head=git('rev-parse','HEAD');assert git('rev-parse','HEAD^')==base and set(git('diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines())==set(paths)
for p in paths:assert git('show','HEAD:'+p,raw=True)==git('show',':'+p,raw=True)==(ROOT/p).read_bytes(),p
assert not git('status','--porcelain=v1')
proof={'HEAD':head,'parent':base,'exact_changed_files':paths,'all_HEAD_index_worktree_bytes_equal':True,'working_tree_clean':True,'integration_receipt_sha256':digest(OUT/'integration_validation_receipt_v3.json'),'authority_unchanged':digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8','all_six_current_input_binding_maps':maps,'whole874873_known_functional_and_exact_once_source_preservation_verified':True,'all_raw_and_g_word_count_conventions_reconstructed':True,'original_combined_timeout_and_uncorrected_native_diagnostics_preserved':True,'unexecuted_verifier_drafts_preserved':True,'accepted_recipe':'integration_v3.current_tables(role)','component_phase_qualified':False,'component_phase_still_required':True,'finite369_295_and_all_protected_quantum_flags_unchanged':True,'full_E5_A5':'UNQUALIFIED','no_remote_action':True,'commit_controller_sha256':digest(Path(__file__))};assert proof['authority_unchanged']
with(CONTROL/'post_commit_integration_v3.json').open('xb') as f:f.write(json.dumps(proof,sort_keys=True,separators=(',',':')).encode()+b'\n')
print(json.dumps({'HEAD':head,'files':len(paths),'clean':True,'receipt_sha256':proof['integration_receipt_sha256'],'current_known_words':874873,'component_phase':'PENDING','full_E5_A5':'UNQUALIFIED'}))
