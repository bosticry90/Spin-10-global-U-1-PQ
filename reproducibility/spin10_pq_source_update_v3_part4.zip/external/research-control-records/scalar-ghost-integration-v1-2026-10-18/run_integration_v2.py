from pathlib import Path
from hashlib import sha256
import json,sys,time
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_integration';CONTROL=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
from audit_a10_e5_antighost_vector import resource,line_json
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation_integration_v2.json');assert digest(Path(__file__))==prep['controller_sha256'] and Path(__file__).read_bytes()==Path(str(Path(__file__))+'.source.txt').read_bytes();stem=role+'_integration_v2';assert not(OUT/(stem+'_capture.json')).exists()
tick=time.perf_counter();cap=capture([sys.executable,'-B',str(OUT/'integration_v2.py'),role]);cap['parent_wall_seconds']=time.perf_counter()-tick
raw=json.dumps(cap,sort_keys=True,separators=(',',':')).encode()+b'\n'
for p in [OUT/(stem+'_capture.json'),CONTROL/(stem+'_full_capture.json')]:
 with p.open('xb') as f:f.write(raw)
if cap['execution_state']!='COMPLETED':print(cap['stdout_and_stderr'],flush=True)
resource(cap);r=line_json(cap['stdout_and_stderr'],'RESULT ');assert r['route']==role and 0<r['elapsed_after_imports']<300
with(OUT/(stem+'_result.json')).open('xb') as f:f.write(json.dumps(r,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('EXPORTED '+stem+' '+digest(OUT/(stem+'_result.json')),flush=True)
