from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,ast,symtable,builtins,subprocess,importlib.util,sys,os
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_integration';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='3d62db7bb11af0f66d6078071c3fdbf5aa28ebe3'
parent=ROOT/'calculations/canonical_so10_scalar_ghost_canonical/validation_receipt.json';r=read(parent);assert r['execution_state']=='COMPLETED' and digest(parent)=='899b3d9a3aba1357fed9dd14629b62fc8f9501fc6007051023ea8e9de41b66bc'
files={Path(p) for p in r['input_sha256']}|{parent,OUT/'RECORD.md',ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V282.md',ROOT/'AGENTS.md',ROOT/'CHARTER.md',ROOT/'project_state.json'}
for p,h in r['input_sha256'].items():assert digest(Path(p))==h,p
oldcontrol=CONTROL.parent/'scalar-ghost-canonical-v1-2026-10-18'
files|={oldcontrol/n for n in ['post_commit.json','consumer_basis_review.json','consumer_review.py','integration_support_cost.py','integration_support_cost_plan.json','scalar_component_support_cost.py','scalar_component_support_cost_plan.json']}
assert read(oldcontrol/'integration_support_cost_plan.json')['unique_combined_parameter_signatures']==1210 and read(oldcontrol/'scalar_component_support_cost_plan.json')['eligible_source_positions']==66216
for p in [OUT/'integration.py',CONTROL/'run.py',Path(__file__)]:
 text=p.read_text(encoding='utf-8');ast.parse(text);tree=symtable.symtable(text,str(p),'exec');defs={z.get_name() for z in tree.get_symbols() if z.is_assigned() or z.is_imported() or z.is_namespace()}|set(dir(builtins))|{'__file__','__name__','__package__'};errors=[]
 def scan(t):
  for z in t.get_symbols():
   if z.is_referenced() and z.is_global() and z.get_name() not in defs:errors.append((t.get_name(),z.get_name()))
  for q in t.get_children():scan(q)
 scan(tree);assert not errors,errors
sp=importlib.util.spec_from_file_location('integration_and_scalar_component_type_preflight',OUT/'integration.py');u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);active=None;roles={};types={}
def audit(event,args):
 if event=='open' and active is not None and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0])).resolve()
  if p.suffix=='.json':active.add(p)
sys.addaudithook(audit)
w=u.m.setup();E=u.establish_epsilon(w);shift={u.m.index['ub12']:u.m.elementary(u.m.index['zz_da12'])};P=u.m.decode([{'word':['C0','ub12','x_Phi_0'],'coefficient':'sqrt(7)*I*g10**4*xi**2'}]);assert u.even_action(P,shift,'primary')==u.even_action(P,shift,'replay') and u.even_action(P,shift,'primary')!=u.m.action(P,shift,'primary');C=u.compact(u.even_action(P,shift,'primary'));assert u.uncompact(C)==u.even_action(P,shift,'primary')
bad=json.loads(json.dumps(C));bad['monomials'][0][2]=len(bad['coefficients'])
try:u.uncompact(bad)
except AssertionError:pass
else:raise AssertionError('BAD_COMPACT_INDEX_NOT_REJECTED')
assert u.reverse_cells(u.bridge_cells([[8,2,3],[16,1,7]],2,1))==[[8,2,3],[16,1,7]] and u.phi(8)==16 and u.phi(16)==8
for role in ['primary','replay']:
 active=set();tables,previous,path,data,op,primitive=u.inspect_inputs(role);roles[role]=active|{OUT/'preparation.json'};files|=active;active=None
 assert type(previous['updated_known_terms']) is int and previous['updated_known_terms']==155143 and data['schema']=='COMPLETE_ACTUAL_SCALAR_GHOST_CANONICAL_TRANSPORT_V1' and data['canonical_parameter_counts']==r['canonical_parameter_counts']
 source=primitive['normalized_source_image'];assert len(source)==146663 and all(type(v['g']) is int and 0<=v['g']<=4 and type(v['word']) is list and all(type(n) is str for n in v['word']) for v in source)
 np=0
 for label,rows in data['canonical_parameter_tables'].items():
  assert label in u.PARAM
  for word,cells in rows:
   assert word==sorted(word) and all(n in u.m.index for n in word) and len(word)==u.PARAM[label][3]+2 and not any(n.startswith('bar') for n in word)
   assert all(all(type(z) is int for z in cc) and 0<=cc[0]<32 and cc[1] and cc[2]>0 for cc in cells);np+=1
 assert np==730610
 kernel_rows=0
 for name,rows in op['all33_kernel_maps'].items():
  assert name in u.m.index and u.m.index[name] in u.m.sources
  for row in rows:
   assert type(row['g']) is int and row['g'] in [0,1];key=tuple(u.m.token(n) for n in row['word']);assert sum(n in E for n,j in key)==1 and sum(u.m.par[n] for n,j in key)%2==u.m.par[u.m.index[name]];kernel_rows+=1
 types[role]={'canonical_parameter_positions':np,'normalized_source_positions':len(source),'kernel_channels':len(op['all33_kernel_maps']),'kernel_rows':kernel_rows,'all_kernel_even_derivation_parities_checked':True,'all_actual_metadata_schemas_checked':True,'whole_actual_known_functional_not_recomputed_in_preflight':True}
for mod in list(sys.modules.values()):
 name=getattr(mod,'__file__',None)
 if name:
  p=Path(name).resolve()
  if p.suffix=='.py' and(p.is_relative_to(ROOT) or p.is_relative_to(CONTROL.parent)):files.add(p)
for p in [OUT/'integration.py',CONTROL/'run.py',Path(__file__)]:
 copy=Path(str(p)+'.source.txt')
 with copy.open('xb') as f:f.write(p.read_bytes())
 files.update([p,copy])
d={'schema':'COMPLETE_SCALAR_GHOST_INTEGRATION_PREPARATION_V1','base_commit':head,'source_sha256':digest(OUT/'integration.py'),'controller_sha256':digest(CONTROL/'run.py'),'input_sha256':{str(p):digest(p) for p in sorted(files)},'read_json_by_role':{role:[str(p) for p in sorted(pp)] for role,pp in roles.items()},'preflight_all_packet_source_kernel_types_and_schemas':types,'even_slot_gradient_and_imaginary_sqrt7_fixtures_passed':True,'compact_roundtrip_and_invalid_index_control_passed':True,'metadata_json_type_preflight_passed':True,'all_source_copies_exclusive':True,'limits':{'seconds_after_imports':300,'private_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2}}
with(OUT/'preparation.json').open('xb') as f:f.write(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('FROZEN',len(files),'role_inputs',{k:len(v) for k,v in roles.items()},'kernel_rows',types['primary']['kernel_rows'])
