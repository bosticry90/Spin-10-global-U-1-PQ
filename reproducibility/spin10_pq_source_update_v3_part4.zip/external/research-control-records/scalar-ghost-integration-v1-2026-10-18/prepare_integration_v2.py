from pathlib import Path
from hashlib import sha256
import json,ast,symtable,builtins,subprocess,importlib.util,sys,os
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_integration';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
old=read(OUT/'preparation.json');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head==old['base_commit']=='3d62db7bb11af0f66d6078071c3fdbf5aa28ebe3'
for p,h in old['input_sha256'].items():assert digest(Path(p))==h,p
cap=read(OUT/'primary_capture.json');assert cap['execution_state']=='FAILED' and cap['exit_code']==124 and not cap['calculation_completed'] and cap['post_run_observations_qualified'] and not(OUT/'primary_result.json').exists();assert (OUT/'primary_capture.json').read_bytes()==(CONTROL/'primary_full_capture.json').read_bytes();assert not(OUT/'replay_capture.json').exists()
files={Path(p) for p in old['input_sha256']}|{OUT/'preparation.json',OUT/'primary_capture.json',CONTROL/'primary_full_capture.json',OUT/'RUN_DISPOSITION_V1.md',OUT/'PHASED_CONTINUATION_V2.md',CONTROL/'verify.py'}
for p in [OUT/'integration_v2.py',CONTROL/'run_integration_v2.py',Path(__file__)]:
 text=p.read_text(encoding='utf-8');ast.parse(text);tree=symtable.symtable(text,str(p),'exec');defs={z.get_name() for z in tree.get_symbols() if z.is_assigned() or z.is_imported() or z.is_namespace()}|set(dir(builtins))|{'__file__','__name__','__package__'};errors=[]
 def scan(t):
  for z in t.get_symbols():
   if z.is_referenced() and z.is_global() and z.get_name() not in defs:errors.append((t.get_name(),z.get_name()))
  for q in t.get_children():scan(q)
 scan(tree);assert not errors,errors
sp=importlib.util.spec_from_file_location('phased_integration_source_preflight',OUT/'integration_v2.py');u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);active=None;roles={};types={}
def audit(event,args):
 if event=='open' and active is not None and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0])).resolve()
  if p.suffix=='.json':active.add(p)
sys.addaudithook(audit);w=u.m.setup();u.core.establish_epsilon(w)
for role in ['primary','replay']:
 active=set();tables,previous,path,data,op,primitive=u.core.inspect_inputs(role);roles[role]=active|{OUT/'preparation_integration_v2.json'};files|=active;active=None
 assert data['schema']=='COMPLETE_ACTUAL_SCALAR_GHOST_CANONICAL_TRANSPORT_V1' and sum(data['canonical_parameter_counts'].values())==730610 and previous['updated_known_terms']==155143 and len(primitive['normalized_source_image'])==146663
 assert all(type(row['g']) is int and isinstance(row['word'],list) for row in primitive['normalized_source_image']);types[role]={'canonical_parameter_positions':730610,'current_known_word_count':155143,'source_positions':146663,'old_metadata_schemas_reused_without_boolean_coercion':True}
fixture=u.m.decode([{'word':['C0','ub12','x_Phi_0'],'coefficient':'sqrt(7)*I*g10**4*xi**2'}]);packet=u.core.compact(fixture);assert u.core.uncompact(packet)==fixture;check=u.coefficient_checks('sqrt(7)*I*g10**4*xi**2');assert check[0] and check[1];json.dumps({'types':types,'signature_checks':check})
for mod in list(sys.modules.values()):
 name=getattr(mod,'__file__',None)
 if name:
  p=Path(name).resolve()
  if p.suffix=='.py' and(p.is_relative_to(ROOT) or p.is_relative_to(CONTROL.parent)):files.add(p)
for p in [OUT/'integration_v2.py',CONTROL/'run_integration_v2.py',Path(__file__)]:
 copy=Path(str(p)+'.source.txt')
 with copy.open('xb') as f:f.write(p.read_bytes())
 files.update([p,copy])
d={'schema':'PHASED_SCALAR_INTEGRATION_PREPARATION_V2','base_commit':head,'source_sha256':digest(OUT/'integration_v2.py'),'controller_sha256':digest(CONTROL/'run_integration_v2.py'),'input_sha256':{str(p):digest(p) for p in sorted(files)},'read_json_by_role':{role:[str(p) for p in sorted(pp)] for role,pp in roles.items()},'preserved_failed_combined_worker_count':1,'original_replay_and_verifier_not_executed':True,'original_unexecuted_verifier_draft_sha256':digest(CONTROL/'verify.py'),'phase':'INTEGRATION_ONLY_COMPONENT_STILL_REQUIRED','preflight_actual_schemas':types,'exact_signature_inverse_double_fixture_passed':True,'compact_snapshot_roundtrip_fixture_passed':True,'metadata_json_type_preflight_passed':True,'all_source_copies_exclusive':True,'limits':{'seconds_after_imports':300,'private_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2}}
with(OUT/'preparation_integration_v2.json').open('xb') as f:f.write(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('PHASE_A_FROZEN',len(files),'original_timeout_preserved',True)
