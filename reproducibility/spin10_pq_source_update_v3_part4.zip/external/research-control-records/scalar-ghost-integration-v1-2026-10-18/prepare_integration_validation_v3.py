from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,ast,symtable,builtins,subprocess,importlib.util,sys
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_integration';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
old=read(OUT/'preparation_integration_v2.json');countprep=read(OUT/'preparation_count_correction_v3.json');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head==old['base_commit']=='3d62db7bb11af0f66d6078071c3fdbf5aa28ebe3';files={Path(p) for p in old['input_sha256']}|{Path(p) for p in countprep['input_sha256']};files.update([OUT/'preparation_integration_v2.json',OUT/'preparation_count_correction_v3.json',OUT/'count_correction_v3_receipt.json',OUT/'RESULT_INTEGRATION_V3.md',CONTROL/'verify_integration_v2.py']);allowed={OUT/'preparation_integration_validation_v3.json',OUT/'primary_capture.json'}
for prep in [old,countprep]:
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
corrected=read(OUT/'count_correction_v3_receipt.json');assert corrected['execution_state']=='COMPLETED' and corrected['no_coefficients_or_hashes_changed'] and corrected['no_new_physics_worker_or_replay']
for role in ['primary','replay']:
 v2=OUT/(role+'_integration_v2_result.json');v3=OUT/(role+'_integration_v3_result.json');cap=OUT/(role+'_integration_v2_capture.json');c=read(cap);assert c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified'] and c['exit_code']==0 and cap.read_bytes()==(CONTROL/(role+'_integration_v2_full_capture.json')).read_bytes();d=read(v3);assert digest(v3)==corrected['corrected_result_sha256'][role] and d['original_completed_native_v2_result_sha256']==digest(v2);files.update([v2,v3,cap,CONTROL/(role+'_integration_v2_full_capture.json')]);allowed.update([v2,v3,cap]);allowed.update(Path(p) for p in old['read_json_by_role'][role])
a=read(OUT/'primary_integration_v3_result.json');b=read(OUT/'replay_integration_v3_result.json')
for key in a.keys()-{'route','updated_known_recipe','stages','elapsed_after_imports','original_completed_native_v2_result_path','original_completed_native_v2_result_sha256','metadata_correction_elapsed_seconds'}:assert a[key]==b[key],key
assert a['sourcefree_updated_positions']==765174 and a['updated_sourcefree_raw_word_positions']==754654 and a['updated_total_g_word_positions']==911837 and not a['component_phase_qualified'] and a['component_phase_still_required']
for p in [CONTROL/'verify_integration_v3.py',CONTROL/'run_integration_validation_v3.py',Path(__file__)]:
 text=p.read_text(encoding='utf-8');ast.parse(text);tree=symtable.symtable(text,str(p),'exec');defs={z.get_name() for z in tree.get_symbols() if z.is_assigned() or z.is_imported() or z.is_namespace()}|set(dir(builtins))|{'__file__','__name__','__package__'};errors=[]
 def scan(t):
  for z in t.get_symbols():
   if z.is_referenced() and z.is_global() and z.get_name() not in defs:errors.append((t.get_name(),z.get_name()))
  for child in t.get_children():scan(child)
 scan(tree);assert not errors,errors
sp=importlib.util.spec_from_file_location('independent_integration_v3_preflight',CONTROL/'verify_integration_v3.py');u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);u.m.setup()
for i in range(45):n=f'zz_da{i:02}';u.m.index[n]=len(u.m.names);u.m.names.append(n);u.m.par.append(1);u.m.external.add(u.m.index[n])
assert u.fixture();P={(3,(('C0',()),('x_Phi_0',()),('zz_da12',()))):(((2,0,8),F(1)),)};fixture={'schema':'FINITE_EXACT_COMPONENT_INTERNED_CELLS_V1','alphabet':u.m.names,'basis_squared':list(u.m.ex.SQUARES),'coefficients':[[[2,0,16,1,1]]],'monomials':[[3,[[u.m.index[n],list(j)] for n,j in next(iter(P))[1]],0]],'sha256_exact_cells':u.decoded_hash(P)};assert u.decode_compact(fixture)==P
bad=json.loads(json.dumps(fixture));bad['monomials'][0][1][0][0]=-1
try:u.decode_compact(bad)
except AssertionError:pass
else:raise AssertionError('NEGATIVE_WORD_INDEX_ACCEPTED')
for mod in list(sys.modules.values()):
 name=getattr(mod,'__file__',None)
 if name:
  p=Path(name).resolve()
  if p.suffix=='.py' and(p.is_relative_to(ROOT) or p.is_relative_to(CONTROL.parent)):files.add(p)
for p in [CONTROL/'verify_integration_v3.py',CONTROL/'run_integration_validation_v3.py',Path(__file__)]:
 copy=Path(str(p)+'.source.txt')
 with copy.open('xb') as f:f.write(p.read_bytes())
 files.update([p,copy])
d={'schema':'INTEGRATION_ONLY_INDEPENDENT_VALIDATION_PREPARATION_V3','base_commit':head,'validator_sha256':digest(CONTROL/'verify_integration_v3.py'),'controller_sha256':digest(CONTROL/'run_integration_validation_v3.py'),'input_sha256':{str(p):digest(p) for p in sorted(files)},'read_json':[str(p) for p in sorted(allowed)],'both_native_complete_mathematical_records_equal':True,'corrected_raw_and_g_word_metadata_preserves_all_coefficients':True,'literal_basis_compact_roundtrip_and_malformed_word_index_fixtures_passed':True,'original_timeout_and_unexecuted_drafts_preserved':True,'phase':'INTEGRATION_ONLY_COMPONENT_PENDING','metadata_json_type_preflight_passed':True,'all_source_copies_exclusive':True,'limits':{'seconds_after_imports':300,'private_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2}}
with(OUT/'preparation_integration_validation_v3.json').open('xb') as f:f.write(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('INTEGRATION_VALIDATION_FROZEN',len(files),'count_conventions_explicit',True)
