from pathlib import Path
from hashlib import sha256
import json
import subprocess
import sys

ROOT=Path('C:/Users/psboy/Documents/ToE-Next')
HERE=ROOT/'calculations/canonical_so10_scalar_quadratic_pullback'
CONTROL=Path(__file__).resolve().parent
BASE='712e4cc6b49c6d8101c3a850a199a3c7556628b1'
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)
digest=lambda path:sha256(path.read_bytes()).hexdigest()
files=sorted([p for p in HERE.iterdir() if p.is_file()]+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V390.md'])
receipt=json.loads((HERE/'validation_receipt.json').read_bytes())
assert receipt['execution_state']=='COMPLETED' and receipt['status']=='QUALIFIED_FULL_G2_SCALAR_POTENTIAL_QUADRATIC_PULLBACK'
old=(CONTROL/'old_git_tree.txt').read_bytes()
assert len(old.splitlines())==25004
prep=json.loads((HERE/'validation_preparation.json').read_bytes())
for name,value in prep['input_sha256'].items():
    assert digest(Path(name))==value,name
assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<4*1024**2
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
assert git('branch','--show-current').decode().strip()=='main'
if sys.argv[1]=='before':
    assert git('rev-parse','HEAD').decode().strip()==BASE
    assert git('ls-tree','-r',BASE)==old
    assert not git('diff','--name-only').strip()
    assert not git('diff','--cached','--name-only').strip()
    allowed={p.relative_to(ROOT).as_posix() for p in files}
    actual=set(git('ls-files','--others','--exclude-standard').decode().splitlines())
    assert actual==allowed,(actual-allowed,allowed-actual)
    value={'base_commit':BASE,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},
           'old_blobs_unchanged':25004,'receipt_sha256':digest(HERE/'validation_receipt.json'),
           'new_package_bytes':sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())}
    with (CONTROL/'before_commit_seal.json').open('xb') as out:
        out.write((json.dumps(value,indent=2,sort_keys=True)+'\n').encode())
    print('PRECOMMIT_SEALED',len(files),'new files',value['new_package_bytes'],'bytes')
elif sys.argv[1]=='index':
    value=json.loads((CONTROL/'before_commit_seal.json').read_bytes())
    actual=set(git('diff','--cached','--name-only').decode().splitlines())
    assert actual==set(value['new_raw_sha256'])
    for name,h in value['new_raw_sha256'].items():
        assert sha256(git('show',':'+name)).hexdigest()==h==digest(ROOT/name),name
    git('diff','--cached','--check')
    print('INDEX_ALL_RAW_BYTES_MATCH',len(actual))
else:
    value=json.loads((CONTROL/'before_commit_seal.json').read_bytes())
    head=git('rev-parse','HEAD').decode().strip()
    assert git('rev-parse','HEAD^').decode().strip()==BASE
    oldmap={line.split(b'\t',1)[1]:line.split(b'\t',1)[0] for line in old.splitlines()}
    now={line.split(b'\t',1)[1]:line.split(b'\t',1)[0] for line in git('ls-tree','-r','HEAD').splitlines()}
    assert all(now[name]==h for name,h in oldmap.items())
    for name,h in value['new_raw_sha256'].items():
        assert sha256(git('show','HEAD:'+name)).hexdigest()==h==digest(ROOT/name),name
    assert not git('status','--porcelain').strip()
    record={'commit':head,'old_blobs_unchanged':25004,
            'new_raw_index_HEAD_bytes_match':len(value['new_raw_sha256']),
            'clean':True,'state_unchanged':True,'scientific_authority':'34/39_UNCHANGED',
            'receipt_sha256':value['receipt_sha256']}
    with (CONTROL/'postcommit_seal.json').open('xb') as out:
        out.write((json.dumps(record,indent=2,sort_keys=True)+'\n').encode())
    print(json.dumps(record,sort_keys=True))
