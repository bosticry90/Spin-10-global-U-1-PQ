from pathlib import Path
from hashlib import sha256
import json,ast,subprocess
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_scalar_source_completeness';C=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
base='ed06fb8ff55fef57303fdf61ea5590d3983dd90c'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==base
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R).strip() and not(O/'preparation.json').exists()
previous=R/'calculations/canonical_so10_gauge_head_completeness';receipt=read(previous/'validation_receipt.json')
assert receipt['execution_state']=='COMPLETED';inputs=dict(receipt['input_sha256'])
for raw,h in inputs.items():assert digest(Path(raw))==h,raw
old=read(R/'calculations/canonical_so10_scalar_H_ghost_head/preparation_v2.json')
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
artifacts={role:{k:old['artifacts'][role][k] for k in ['physical','action']} for role in ['primary','replay']}
for role in artifacts:
 artifacts[role]['embedding']={'path':str(P/'frozen_action_ast_a3/A31_embeddings.json')}
 artifacts[role]['shg']={'path':str(R/'calculations/canonical_so10_scalar_H_ghost_head'/(role+'_v2_result.json'))}
 for v in artifacts[role].values():v['sha256']=digest(Path(v['path']));inputs[v['path']]=v['sha256']
files=[previous/'validation_receipt.json',previous/'DERIVATION.md',previous/'RESULT.md',previous/'APPLICABILITY_NOTE.md',
 previous/'NEXT_RESEARCH_QUESTION.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V348.md',
 R/'calculations/canonical_so10_scalar_H_ghost_head/DERIVATION.md',R/'calculations/canonical_so10_scalar_H_ghost_head/validation_receipt.json',
 P/'frozen_action_ast_a3/A34_complex_real_bridges.json',P/'frozen_action_ast_a3/A36_full_328_map.json',P/'frozen_action_ast_a3/A37_scalar_kinetic_ASTs.json',
 C.parent/'gauge-head-completeness-v1-2026-10-19/post_commit.json']
for p in files:inputs[str(p)]=digest(p)
for p in [O/'RECORD.md',O/'DERIVATION.md',O/'scalars.py',C/'prepare.py',C/'run.py']:
 if p.suffix=='.py':ast.parse(p.read_text())
 inputs[str(p)]=digest(p)
 with(O/(p.name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 inputs[str(O/(p.name+'.source.txt'))]=digest(O/(p.name+'.source.txt'))
for raw,h in inputs.items():assert digest(Path(raw))==h,raw
p={'schema':'SCALAR_SOURCE_COMPLETENESS_PREPARATION_V1','base_commit':base,'artifacts':artifacts,'input_sha256':inputs,
 'controller_sha256':digest(C/'run.py'),'native_seconds_after_imports':120,'independent_seconds_after_imports':180,
 'sampled_private_limit_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2,'package_limit_bytes':8*1024**2,
 'scope':'Full328 affine scalar-source reduction and fixed numerical homotopy in the specified affine-extendible class; not all schemes/full E5/A5',
 'scientific_acceptance':'NOT_PERFORMED'}
with(O/'preparation.json').open('xb') as f:f.write((json.dumps(p,indent=2,sort_keys=True)+'\n').encode())
print('FROZEN',len(inputs),p['controller_sha256'])
