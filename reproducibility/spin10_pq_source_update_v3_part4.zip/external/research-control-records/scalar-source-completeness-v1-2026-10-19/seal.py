from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_scalar_source_completeness';C=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
base='ed06fb8ff55fef57303fdf61ea5590d3983dd90c'
assert git('rev-parse','HEAD').decode().strip()==base and git('branch','--show-current').decode().strip()=='main'
r=read(O/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and not r['authority_changed']
assert digest(O/'validation_receipt.json')=='4424cf5e0270e6c50b3cbc1c999931226fd069e5527a43a18ebadb4609f478c5'
for raw,h in r['input_sha256'].items():assert digest(Path(raw))==h,raw
assert not git('diff','--name-only').strip()
with(O/'seal.py.source.txt').open('xb') as f:f.write(Path(__file__).read_bytes())
files=sorted([p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V349.md'])
assert sum(p.stat().st_size for p in files)<8*1024**2
bindings={p.relative_to(R).as_posix():digest(p) for p in files}
with(C/'precommit_bindings.json').open('xb') as f:f.write((json.dumps(bindings,indent=2,sort_keys=True)+'\n').encode())
subprocess.run(['git','add','--',*bindings],cwd=R,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
staged=git('diff','--cached','--name-status').decode().splitlines()
assert all(v.startswith('A\t') for v in staged) and sorted(v.split('\t')[1] for v in staged)==sorted(bindings)
for name,h in bindings.items():assert sha256(git('show',':'+name)).hexdigest()==h,name
subprocess.run(['git','commit','-m','Reduce the complete conditional scalar-source sector with a polynomial homotopy'],cwd=R,check=True)
head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()==base
changed=git('diff','--name-status',base,head).decode().splitlines()
assert all(v.startswith('A\t') for v in changed) and sorted(v.split('\t')[1] for v in changed)==sorted(bindings)
assert not git('status','--porcelain').strip()
for name,h in bindings.items():assert digest(R/name)==h and sha256(git('show','HEAD:'+name)).hexdigest()==h,name
for raw,h in r['input_sha256'].items():assert digest(Path(raw))==h,raw
state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
audit=C.parent/'ordered-shear-insertion-v1-2026-10-18/research_check_e4_capture.json'
assert digest(audit)=='40bbc2d078c522367be0956631b849f64cc3f908ecf6973c4cb4d81c895b7060'
prior=C.parent/'gauge-head-completeness-v1-2026-10-19/post_commit.json'
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
review=[P/'A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md',R/'calculations/canonical_so10_dimensional_stokes_primitive/DERIVATION.md']
out={'schema':'SCALAR_SOURCE_COMPLETENESS_POST_COMMIT_V1','HEAD':head,'parent':base,'branch':'main','clean':True,
 'files':bindings,'receipt_sha256':digest(O/'validation_receipt.json'),'state_sha256':state,'seal_source_sha256':digest(Path(__file__)),
 'all_older_tracked_Git_blobs_unchanged':True,'all251_frozen_validation_inputs_unchanged':True,
 'full328_conditional_scalar_source_reduction_and_fixed_numerical_primitive_program_qualified':True,
 'post_qualification_interpretation_correction_kernel_not_automatically_physically_unobservable_preserved':True,
 'affine_family_applicability_to_original_W6_not_assumed':True,
 'all_scheme_source_cohomology_baseline_two_loop_QAP_A5_E5_or_physical_promotion':False,
 'failed_native_workers':0,'failed_verifier_workers':0,'prelaunch_read_only_navigation_errors':3,
 'historical_custody_exit':2,'unresolved_references':7,'prior_broad_audit_reused_not_rerun':True,
 'prior_broad_audit_capture_sha256':digest(audit),'prior_post_commit_sha256':digest(prior),
 'post_qualification_next_question_review_input_sha256':{str(p):digest(p) for p in review}}
with(C/'post_commit.json').open('xb') as f:f.write((json.dumps(out,indent=2,sort_keys=True)+'\n').encode())
print(json.dumps({'HEAD':head,'new_files':len(files),'new_bytes':sum(p.stat().st_size for p in files),
 'all251_frozen_inputs_unchanged':True,'older_Git_blobs_unchanged':True,'state_unchanged':True,'clean':True},sort_keys=True))
