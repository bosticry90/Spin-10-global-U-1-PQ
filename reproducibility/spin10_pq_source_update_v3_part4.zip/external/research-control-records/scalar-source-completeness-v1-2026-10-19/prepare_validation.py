from pathlib import Path
from hashlib import sha256
import json,ast
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_scalar_source_completeness';C=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
p=read(O/'preparation.json');inputs=dict(p['input_sha256'])
for raw,h in inputs.items():assert digest(Path(raw))==h,raw
a=read(O/'primary_result.json');b=read(O/'replay_result.json');skip={'route','elapsed_after_imports'}
assert {k:v for k,v in a.items() if k not in skip}=={k:v for k,v in b.items() if k not in skip}
for path in [C/'verify.py',C/'prepare_validation.py',C/'run_validation.py',C/'navigation_errors.json']:
 if path.suffix=='.py':ast.parse(path.read_text())
 inputs[str(path)]=digest(path)
 with(O/(path.name+'.source.txt')).open('xb') as f:f.write(path.read_bytes())
for path in O.iterdir():
 if path.is_file():inputs[str(path)]=digest(path)
for raw,h in inputs.items():assert digest(Path(raw))==h,raw
v={'schema':'SCALAR_SOURCE_COMPLETENESS_VALIDATION_PREPARATION_V1','input_sha256':inputs,
 'verifier_sha256':digest(C/'verify.py'),'controller_sha256':digest(C/'run_validation.py'),'scope':p['scope'],
 'shared_limits':'Same action/frame/Schur and analytic premises/software/AI author. New compact proof is not an assembled inverse or full-scheme quantum theorem.'}
with(O/'validation_preparation.json').open('xb') as f:f.write((json.dumps(v,indent=2,sort_keys=True)+'\n').encode())
print('VALIDATION_FROZEN',len(inputs),v['verifier_sha256'])
