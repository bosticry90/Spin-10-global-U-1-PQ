from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json,os,sys,time,threading
import sympy as s
import mpmath as mp
R=Path(r'C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_shear_ir_response'
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from audit_a10_e5_antighost_vector import resource,line_json
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
@lru_cache(None)
def expr(text):return s.expand(s.sympify(text))
def cell(raw):
 return sum(s.Rational(n,d)*s.prod(s.sqrt(p) for bit,p in enumerate([2,3,5,7]) if mask&(1<<bit))*(s.I if mask&16 else 1) for x,h,mask,n,d in raw if x==h==0)

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(O/'validation_preparation.json')
 assert digest(Path(__file__))==prep['source_sha256']
 for raw,h in prep['input_sha256'].items():assert digest(Path(raw))==h,raw
 allowed=set(prep['read_json'])
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('IR_VERIFY_WRITE')
  if p.suffix=='.json':assert str(p) in allowed,('UNDECLARED_IR_VALIDATOR_JSON',str(p))
 sys.addaudithook(guard)
 a=read(O/'primary_result.json');b=read(O/'replay_result.json')
 assert {k:v for k,v in a.items() if k not in ['route','elapsed_after_imports']}=={k:v for k,v in b.items() if k not in ['route','elapsed_after_imports']}
 for role,value in [('primary',a),('replay',b)]:
  cap=read(O/(role+'_capture.json'));resource(cap);assert line_json(cap['stdout_and_stderr'],'RESULT ')==value
 old=read(R/'calculations/canonical_so10_finite_shear_scalar/primary_v2_result.json');info=old['actual_reference_and_projection']
 ops=read(R/'calculations/canonical_so10_scalar_ghost_physical_operators/primary_result.json')
 beta={(i,j):cell(co) for i,j,co in info['beta']};cext={i:cell(co) for i,co in info['external_C12_physical_support']};X={};Xr={};Z={}
 for i,j,k,text in ops['physical_X']:
  if k in cext:X[i,j]=expr(text)*cext[k]
 for i,j,k,text in ops['physical_Xr']:
  if k in cext:Xr[i,j]=expr(text)*cext[k]
 for i,j,k,text in ops['physical_Z']:
  if k==info['physical_scalar_index']:Z[i,j]=expr(text)
 assert all(j>=45 for i,j in X)
 assert all(s.simplify(Xr.get((j,i),0)+co)==0 for (i,j),co in X.items())
 assert all(s.simplify(Z.get((j,i),0)+co)==0 for (i,j),co in Z.items())
 # Direct component contraction after exact odd-pair covariance. Both J
 # factors contribute -1,so their product is +1. No native matrix code.
 one=s.Integer(0);terms=[]
 for (i,ac),bv in beta.items():
  for (lam,janti),xv in X.items():
   if lam!=i:continue
   zv=Z.get((janti-45,45+ac),0)
   if zv:
    term=s.simplify(bv*xv*zv);terms.append(term);one+=term
 one=s.simplify(one)
 assert s.simplify(one-expr(a['left_trace']))==0 and s.simplify(2*one-expr(a['actual_XZ_trace']))==0
 assert s.simplify(2*one+36*s.sqrt(15)/25)==0
 assert expr(a['actual_IR_insertion_color'])==-2*one
 # Independent polynomial expansion of the complete chi product.
 z,ss=s.symbols('z s',nonnegative=True);constants=[];radial_checks=[]
 mp.mp.dps=45
 for entry in a['radial_IR_functions']:
  k=entry['k'];poly=s.Poly(s.expand((1-z)**(2*k)-(1-z)**(3*k)),z)
  expected=[[m,int(poly.coeff_monomial(z**m))] for m in range(1,3*k+1)]
  assert expected==entry['log_coefficients'] and poly.eval(0)==poly.eval(1)==0
  deriv=-sum(mp.mpf(co)/(mp.mpf('.5')+m) for m,co in expected)
  actual_deriv=-mp.quad(lambda u:mp.exp(-u/2)*((-mp.expm1(-u))**(2*k)-(-mp.expm1(-u))**(3*k)),[0,1,mp.inf])
  assert abs(deriv-actual_deriv)<mp.mpf('1e-38')
  zero=mp.quad(lambda u:((-mp.expm1(-u))**(2*k)-(-mp.expm1(-u))**(3*k))/u,[0,1,mp.inf])
  assert abs(zero-mp.mpf(entry['values_at_s_0_half_3'][0]))<mp.mpf('1e-27')
  const=mp.log(mp.mpf(4)/3) if k==1 else 38*mp.log(2)-15*mp.log(3)-6*mp.log(5)
  assert abs(zero-const)<mp.mpf('1e-38');constants.append(const)
  radial_checks.append(mp.nstr(zero,28))
 assert abs(constants[0]-constants[1])>mp.mpf('.08')
 # Direct four-dimensional radial/angular quadrature of the POSITIVE full
 # kernel,independent of the native E1/Schwinger finite-sum methods.
 # q extends0..8,theta0..pi,p=epsilon=1,t=0. Tail<=k exp(-64)/49.
 quad=[]
 for order in [64,80]:
  nodes,weights=mp.gauss_quadrature(order,'legendre')
  angles=[(mp.pi*(nodes[j]+1)/2,weights[j]) for j in range(order)]
  values=[]
  for k in [1,2]:
   total=mp.mpf(0)
   for i in range(order):
    q=4*(nodes[i]+1);qq=q*q;chiq=(-mp.expm1(-qq))**k;outer=q*chiq*(1-chiq)*weights[i]
    inner=mp.mpf(0)
    for theta,ww in angles:
     vv=qq+1+2*q*mp.cos(theta);cv=(-mp.expm1(-vv))**k
     inner+=ww*mp.sin(theta)**2*cv/vv
    total+=outer*inner
   values.append(8*total)
  quad.append(values)
 errors=[]
 for j,k in enumerate([1,2]):
  target=next(row for row in a['nonexceptional_values'] if row['k']==k and row['lambda_p2_over_epsilon2']==1)
  expected=mp.mpf(target['value']);diff=abs(quad[1][j]-quad[0][j]);error=abs(quad[1][j]-expected)
  assert diff<mp.mpf('1e-12') and error<mp.mpf('1e-12'),(k,mp.nstr(diff),mp.nstr(error))
  errors.append({'k':k,'value64':mp.nstr(quad[0][j],27),'value80':mp.nstr(quad[1][j],27),'convergence_difference':mp.nstr(diff,10),'absolute_error':mp.nstr(error,10),'tail_bound':mp.nstr(k*mp.exp(-64)/49,10)})
 # Own Schwinger integral for the remaining finite sum and a one-heat
 # omission control. A second heat factor matters independently of both.
 def B(A,B):
  split=A/(A+B) if B else mp.mpf(1)
  return mp.quad(lambda v:mp.e1(max(A*(1-v),B*v)),[0,split,1] if B else [0,1])
 def D(k,lam,tau,drop_second=False):
  val=mp.mpf(0)
  for m in range(1,2*k+1):
   am=int((-1)**m*(s.binomial(k,m)-s.binomial(2*k,m)))
   for ell in range(k+1):
    bl=int((-1)**ell*s.binomial(k,ell));val+=am*bl*B((m+2*tau)*lam,(ell+(0 if drop_second else 2*tau))*lam)
  return val
 positive=D(1,mp.mpf(4),mp.mpf('.125'));wrong=D(1,mp.mpf(4),mp.mpf('.125'),True)
 assert abs(positive-mp.mpf(a['positive_heat_D1_lambda4_tau1over8']))<mp.mpf('1e-23') and wrong>positive
 # Uniform analytic bound: two small-pole balls and their complement.
 # Each shifted Coulomb Gaussian<=2pi² epsilon² by splitting at epsilon.
 # The result is independent of the anchor and all positive heat<=1.
 pi=s.pi;eps,p=s.symbols('epsilon p',positive=True)
 unnormalized=2*(4/p**2)*(2*pi**2*eps**2)+16*pi**2*eps**4/p**4
 normalized=s.simplify(unnormalized/(2*pi)**4)
 assert s.simplify(normalized-(eps**2/p**2+eps**4/p**4)/pi**2)==0
 assert s.limit(16*(eps**2/p**2+eps**4/p**4),eps,0)==0
 for row in a['nonexceptional_values']:
  val=mp.mpf(row['value']);bound=16*row['k']*(1/mp.mpf(row['lambda_p2_over_epsilon2'])+1/mp.mpf(row['lambda_p2_over_epsilon2'])**2)
  assert 0<val<bound
 # Source differentiation is an operation before the projection.
 JJ,x=s.symbols('J x');primitive=JJ*x;assert s.diff(primitive,JJ).subs(JJ,0)==x and s.diff(primitive.subs(JJ,0),JJ)==0
 assert a['physical_IR_witness_adopted'] is False and a['kappa_and_b0_fixed_or_identified'] is False
 assert a['full_zero_momentum_identity_or_complete_IR_QAP_E5_proved'] is False
 assert all(a['controls'].values())
 result={'schema':'ACTUAL_SHEAR_IR_RESPONSE_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':a['scientific_disposition'],
  'native_results_identical':True,'own_component_color_contraction':str(2*one),'nonzero_component_terms':len(terms),
  'both_tangent_ghost_signs_and_odd_only_exact_pole_class_verified':True,
  'complete_binomial_radial_functions_and_derivatives_verified':True,'radial_constants':radial_checks,
  'independent_four_dimensional_positive_kernel_quadratures':errors,
  'specific_dropped_second_heat_control':{'correct':mp.nstr(positive,26),'omitted_second_heat':mp.nstr(wrong,26)},
  'uniform_soft_pole_bound_and_noncommuting_limits_verified':True,
  'source_projection_and_selected_common_kappa_IR_removal_reviewed':True,
  'analytic_review':{'inverse':'evaluation-dual ordered inverse on core,with explicit extra IR insertion','actual_cohort':'two odd massless propagators,XZ only,no massive UV approximation;corners excluded by actual partners in this projection','nonexceptional_domain':'p² bounded away from zero,uniform in t and anchors','exceptional':'nonzero shape dependence for cohort only,not full identity or anomaly','remaining':'full ordered-family soft-pole census,common product/testfield/Legendre and IR construction still required'},
  'full_IR_measure_QAP_sourcefree_Slavnov_E5_A5_proved':False,
  'new_failed_native_workers':0,'new_failed_verifier_workers':0,
  'checks_not_performed':['full zero-momentum identity and other cohorts','new broad sealed E4/custody replay','physical IR-scheme adoption','Lean/external scientific validation'],
  'shared_limits':'frozen action/operator/frame/support/Wick data and AI authorship shared;own contraction and positive-kernel quadratures provide bounded computational corroboration',
  'authority_Gamma_old_evidence_unchanged':True,'input_sha256':prep['input_sha256'],'elapsed_after_imports':time.perf_counter()-tick}
 print('VALIDATION '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
