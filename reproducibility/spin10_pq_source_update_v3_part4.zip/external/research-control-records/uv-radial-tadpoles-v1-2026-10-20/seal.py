from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
R=Path('C:/Users/psboy/Documents/ToE-Next');D=R/'calculations/canonical_so10_uv_radial_tadpoles';C=Path(__file__).resolve().parent
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
digest=lambda p:sha256(p.read_bytes()).hexdigest()
base='e83c4017a36a1d4683be15333abe4547749ba91a'
files=sorted([p for p in D.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V378.md'])
old=(C/'old_git_tree.txt').read_bytes();assert len(old.splitlines())==24589
prep=json.loads((D/'validation_preparation_v3.json').read_bytes())
for n,h in prep['input_sha256'].items():assert digest(Path(n))==h,n
assert sum(p.stat().st_size for p in D.iterdir() if p.is_file())<4*1024**2
assert digest(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
if sys.argv[1]=='before':
 assert git('rev-parse','HEAD').decode().strip()==base
 assert git('ls-tree','-r',base)==old
 assert not git('diff','--name-only').strip()
 assert not git('diff','--cached','--name-only').strip()
 allowed={str(p.relative_to(R)).replace('\\','/') for p in files}
 actual=set(git('ls-files','--others','--exclude-standard').decode().splitlines())
 assert actual==allowed,(actual-allowed,allowed-actual)
 v={'base_commit':base,'new_raw_sha256':{str(p.relative_to(R)).replace('\\','/'):digest(p) for p in files},
 'old_blobs_unchanged':24589,'receipt_sha256':digest(D/'validation_receipt_v3.json'),'new_package_bytes':sum(p.stat().st_size for p in D.iterdir() if p.is_file())}
 with (C/'before_commit_seal.json').open('xb') as out:out.write((json.dumps(v,indent=2,sort_keys=True)+'\n').encode())
 print('PRECOMMIT_SEALED',len(files),'new files',v['new_package_bytes'],'bytes')
elif sys.argv[1]=='index':
 v=json.loads((C/'before_commit_seal.json').read_bytes())
 actual=set(git('diff','--cached','--name-only').decode().splitlines())
 assert actual==set(v['new_raw_sha256'])
 for n,h in v['new_raw_sha256'].items():
  assert sha256(git('show',':'+n)).hexdigest()==h==digest(R/n),n
 git('diff','--cached','--check');print('INDEX_ALL_RAW_BYTES_MATCH',len(actual))
else:
 v=json.loads((C/'before_commit_seal.json').read_bytes());head=git('rev-parse','HEAD').decode().strip()
 assert git('rev-parse','HEAD^').decode().strip()==base
 oldmap={line.split(b'\t',1)[1]:line.split(b'\t',1)[0] for line in old.splitlines()}
 now={line.split(b'\t',1)[1]:line.split(b'\t',1)[0] for line in git('ls-tree','-r','HEAD').splitlines()}
 assert all(now[n]==h for n,h in oldmap.items())
 for n,h in v['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(R/n),n
 assert not git('status','--porcelain').strip()
 out={'commit':head,'old_blobs_unchanged':24589,'new_raw_index_HEAD_bytes_match':len(v['new_raw_sha256']),
 'clean':True,'state_unchanged':True,'scientific_authority':'34/39_UNCHANGED','receipt_sha256':v['receipt_sha256']}
 with (C/'postcommit_seal.json').open('xb') as f:f.write((json.dumps(out,indent=2,sort_keys=True)+'\n').encode())
 print(json.dumps(out,sort_keys=True))
