from pathlib import Path
from hashlib import sha256
import json,sys
R=Path(r'C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_triangular_heat_transport';C=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
from audit_a10_e5_antighost_vector import resource,line_json
p=json.loads((O/'jacobian_preparation.json').read_bytes());assert sha256(Path(__file__).read_bytes()).hexdigest()==p['controller_sha256']
for role in ['primary','replay']:
 assert not(O/(role+'_jacobian_capture.json')).exists()
 cap=capture([sys.executable,'-B',str(O/'heat_jacobian.py'),role]);raw=json.dumps(cap,sort_keys=True,separators=(',',':')).encode()+b'\n'
 for path in [O/(role+'_jacobian_capture.json'),C/(role+'_jacobian_full_capture.json')]:
  with path.open('xb') as f:f.write(raw)
 if cap['execution_state']!='COMPLETED':print(cap['stdout_and_stderr'],flush=True)
 resource(cap);res=line_json(cap['stdout_and_stderr'],'RESULT ');assert 0<res['elapsed_after_imports']<120
 with (O/(role+'_jacobian_result.json')).open('xb') as f:f.write(json.dumps(res,sort_keys=True,separators=(',',':')).encode()+b'\n')
 print('COMPLETED',role,res['formal_log_Berezinian_heat_diagnostic'],res['elapsed_after_imports'],flush=True)
