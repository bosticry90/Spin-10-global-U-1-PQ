from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
from fractions import Fraction
import gzip,itertools,json,os,sys,time,threading
import sympy as s
R=Path(r'C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_triangular_heat_transport';P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(P));from audit_a10_e5_antighost_vector import resource,line_json
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
g,xi,eta,up=s.symbols('g10 xi eta_H u',real=True)
@lru_cache(maxsize=65536)
def normal(z):return s.expand(z)
@lru_cache(maxsize=16384)
def parsed(text):
 z=s.sympify(text,locals={'g10':g,'xi':xi,'eta_H':eta,'reference_width_M':xi,'reference_width_H':eta});assert not z.has(s.Float)
 return tuple((k[0],co) for k,co in s.Poly(normal(z),g).terms() if co)

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(O/'validation_preparation.json');assert digest(Path(__file__))==prep['source_sha256']
 for name,h in prep['input_sha256'].items():assert digest(Path(name))==h,name
 allowed={str(Path(n).resolve()) for n in prep['read_json']}
 def audit(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('TRIANGULAR_VALIDATOR_WRITE')
  if p.suffix=='.json':assert str(p) in allowed,('UNDECLARED_TRIANGULAR_VALIDATION_JSON',str(p))
 sys.addaudithook(audit);native={r:read(O/(r+'_v2_result.json')) for r in ['primary','replay']}
 for role in native:
  cap=read(O/(role+'_v2_capture.json'));resource(cap);assert line_json(cap['stdout_and_stderr'],'RESULT ')==native[role] and 0<native[role]['elapsed_after_imports']<120
 assert {k:v for k,v in native['primary'].items() if k not in ['route','elapsed_after_imports']}=={k:v for k,v in native['replay'].items() if k not in ['route','elapsed_after_imports']}
 badrun=read(O/'primary_capture.json');assert badrun['execution_state']=='FAILED' and badrun['exit_code']==1 and 'AssertionError' in badrun['stdout_and_stderr']
 a=native['primary'];data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));names=data['geometry']['names'];index={n:i for i,n in enumerate(names)};par=dict(enumerate(data['geometry']['parities']));par.update({-1:0,-2:1,-3:0});pairs=[(n,J) for n,J,h,k in data['geometry']['field_source_h_k']];fields={n for n,J in pairs};sources={J for n,J in pairs};coords=fields|sources;partner={n:J for n,J in pairs}|{J:n for n,J in pairs};Jof=dict(pairs)
 def tok(text):
  n,_,j=text.partition('__');assert n in index and all(q in '0123' for q in j);return index[n],tuple(map(int,j))
 def canon(w):
  odd=[v for v in w if par[v[0]]]
  if len(odd)!=len(set(odd)):return (),0
  return tuple(sorted(w)),(-1)**sum(v>q for k,v in enumerate(odd) for q in odd[k+1:])
 def collect(terms):return {k:z for k,vals in terms.items() if (z:=normal(s.Add(*vals)))!=0}
 def add(*polys):
  terms=defaultdict(list)
  for poly in polys:
   for key,z in poly.items():terms[key].append(z)
  return collect(terms)
 def scaled(poly,z):return {k:v for k,co in poly.items() if (v:=normal(co*z))!=0}
 def mul(A,B,probe=None):
  out=defaultdict(list)
  for(gp,w),z in A.items():
   for(gq,v),co in B.items():
    word,sgn=canon(w+v)
    if sgn and (probe is None or sum(n==probe for n,j in word)<=1):out[gp+gq,word].append(sgn*z*co)
  return collect(out)
 def rows(terms):
  out=defaultdict(list)
  for term in terms:
   w=tuple(map(tok,term['word']));assert canon(w)==(w,1)
   for gp,z in parsed(term['coefficient']):out[gp,w].append(z)
  return collect(out)
 def unpack(terms):
  out={}
  for term in terms:
   w=tuple(map(tok,term['word']));assert canon(w)==(w,1)
   z=normal(sum(s.Rational(n,d)*xi**x*eta**h*s.prod(s.sqrt(q) for bit,q in enumerate([2,3,5,7]) if mask&(1<<bit))*(s.I if mask&16 else 1) for x,h,mask,n,d in term['coefficient_cells']));key=term['g'],w;assert key not in out and z;out[key]=z
  return out
 def equal(A,B,label):
  delta=add(A,scaled(B,-1));assert not delta,(label,next(iter(delta.items())) if delta else None)
 def gradient(poly):
  # Independent Grassmann jet-probe derivative:replace one slot by a probe
  # of the SAME parity,canonicalize it to the left,then strip it.
  out=defaultdict(lambda:defaultdict(list))
  for(gp,w),co in poly.items():
   for k,(n,j) in enumerate(w):
    assert not j;probe=-2 if par[n] else -3;v,sgn=canon(w[:k]+((probe,()),)+w[k+1:]);assert sgn and v[0]==(probe,())
    out[n][gp,v[1:]].append(sgn*co)
  return {n:collect(Q) for n,Q in out.items()}
 def variation(poly,images):
  out=defaultdict(list);unchanged=defaultdict(list)
  for(gp,w),co in poly.items():
   value={(gp,()):co}
   for n,j in w:
    factor={(0,((n,j),)):s.S.One}
    if images.get(n):assert not j;factor=add(factor,mul({(0,((-1,()),)):s.S.One},images[n]))
    value=mul(value,factor,-1)
   for(gq,v),z in value.items():
    if v and v[0]==(-1,()):out[gq,v[1:]].append(z)
    else:unchanged[gq,v].append(z)
  equal(collect(unchanged),poly,'unshifted_probe');return collect(out)
 old=read(R/'calculations/canonical_so10_correlated_contact_lift/primary_result.json');K=unpack(old['complete_K']);E=gradient(K);XF={n:scaled(E.get(J,{}),-(-1)**par[n]) for n,J in pairs};XJ={J:scaled(E.get(n,{}),(-1)**par[n]) for n,J in pairs};X={n:Q for n,Q in (XF|XJ).items() if Q};assert len(X)==57
 for n,J in pairs:
  equal(XF[n],unpack(old['all643_nonzero_field_flows'].get(names[n],[])),'actual_field_flow');equal(XJ[J],unpack(old['all643_nonzero_source_flows'].get(names[J],[])),'actual_source_flow')
 deps={n for Q in X.values() for gp,w in Q for n,j in w};assert not deps&set(X) and not {partner[n] for n in deps}&deps
 assert all(not variation(Q,X) for Q in X.values())
 # Direct finite-coordinate pullback bracket,not the worker's first-order
 # correction matrix. Explicit full support proves all omitted pair zeros.
 F={n:add({(0,((n,()),)):s.S.One},scaled(X.get(n,{}),up)) for n in coords};DF={n:gradient(Q) for n,Q in F.items()};byn=defaultdict(set)
 for i,grad in DF.items():
  for n,Q in grad.items():
   if Q:byn[n].add(i)
 candidates=set()
 for n,J in pairs:candidates.update(itertools.product(byn[n],byn[J]));candidates.update(itertools.product(byn[J],byn[n]))
 for i,j in candidates:
  terms=[]
  for n,Q in DF[i].items():
   if n in fields:
    if Jof[n] in DF[j]:terms.append(scaled(mul(Q,DF[j][Jof[n]]),(-1)**(par[n]*par[i])))
   elif partner[n] in DF[j]:terms.append(scaled(mul(Q,DF[j][partner[n]]),(-1)**(par[n]*par[i])))
  # Source gradient n=J has parity p_z+1,exactly the second bracket sign.
  got=add(*terms);want={(0,()):s.Integer((-1)**par[i])} if partner[i]==j else {};equal(got,want,'finite_canonical_pair')
 assert len(coords)==1286 and a['all_pair_domain']==1286**2 and len(candidates)<1286**2
 oddfields={n for n in fields if par[n]};evenfields=fields-oddfields;assert len(evenfields)==553 and len(oddfields)==90
 shifted={n for n,Q in XF.items() if Q};assert len(shifted)==20
 for n in shifted:assert all(j in oddfields for gp,w in XF[n] for j,jets in w) and all(n not in gradient(XF[n]) for n in evenfields)
 anti=index['ub12'];e3=read(P/'frozen_a10_e3_symmetry/primary.json')['operators']['Tb_geometric_and_transported'];H={n:rows(e3[names[n]]) for n in fields};assert not H[anti]
 for n in fields:equal(variation(XF[n],H),variation(H[n],XF),'all643_H_intertwiner_column')
 jac={r:read(O/(r+'_jacobian_result.json')) for r in ['primary','replay']}
 for role in jac:
  cap=read(O/(role+'_jacobian_capture.json'));resource(cap);assert line_json(cap['stdout_and_stderr'],'RESULT ')==jac[role] and 0<jac[role]['elapsed_after_imports']<120
 assert {k:v for k,v in jac['primary'].items() if k not in ['route','elapsed_after_imports']}=={k:v for k,v in jac['replay'].items() if k not in ['route','elapsed_after_imports']}
 counts={'even_to_even':0,'odd_to_odd':0};nrows=0
 for n,Q in H.items():
  for gp,w in Q:
   actual=[v for v,j in w if v in fields]
   if actual:assert len(actual)==1 and par[n]==par[actual[0]];counts['even_to_even' if par[n]==0 else 'odd_to_odd']+=1
   assert all(par[v]==0 for v,j in w if v not in fields);nrows+=1
 assert counts==jac['primary']['parity_preserving_linear_rows'] and nrows==jac['primary']['H_field_rows_checked']
 tangent={(n,v):Q for n in shifted for v,Q in gradient(XF[n]).items()};assert len(tangent)==40 and all(par[n]==0 and par[v]==1 for n,v in tangent)
 recorded={(index[n],index[v]):unpack(Q) for n,v,Q in jac['primary']['whole_field_tangent']};assert set(tangent)==set(recorded)
 for key in tangent:equal(tangent[key],recorded[key],'full_actual_heat_Jacobian_tangent')
 assert jac['primary']['formal_log_Berezinian_heat_diagnostic']==0 and jac['primary']['sources_integrated'] is False and jac['primary']['global_measure_QAP_A5_or_renormalized_contacts_proved'] is False
 print('STAGE independent_finite1286_coordinate_bracket_pullback_and_H_intertwiner',flush=True)
 refrecord=read(P/'frozen_a10_e5_full_hessian/primary.json');ref=refrecord['retained_reference'];raw=ref['field_order'];Kentries=ref['reference_Hessian_raw_C3']['entries'];relevant=[{'shifted_field':raw[i],'partner':raw[j],'reference_kernel':co} for i,j,co in Kentries if index[raw[i]] in shifted];assert relevant==a['actual_relevant_reference_kernel_rows'] and len(relevant)==100
 auxfields={n for n in fields if names[n].startswith('L') or (names[n].startswith('b') and not names[n].startswith('bar'))};assert len(auxfields)==45
 auxquad=defaultdict(list)
 for i,j,text in Kentries:
  fi,fj=index[raw[i]],index[raw[j]]
  if fi not in auxfields or fj not in auxfields:continue
  w,sgn=canon(((fi,()),(fj,())))
  for gp,z in parsed(text):auxquad[gp,w].append(sgn*z/2)
 aux=variation(collect(auxquad),XF);equal(aux,unpack(a['actual_auxiliary_regulator_response']),'both_quadratic_Hessian_legs_regulator_response');assert len(aux)==20
 witnesskey=2,tuple(map(tok,['C44','L44','ub12']));assert normal(aux[witnesskey]-16*s.sqrt(2)*s.I*xi**2/25)==0
 # Independent Laplacian product-rule sign and derivative/endpoint check.
 aa,bb,d=s.symbols('aa bb d',real=True);t,z=s.symbols('t z',positive=True);A=aa+bb+2*d;B=aa+bb;D=s.exp(-t*A)-s.exp(-t*B);kernel=s.exp(-(t-z)*A-z*B)
 assert s.simplify(s.diff(kernel,z)-2*d*kernel)==0 and s.simplify(s.diff(D,t)+A*D+2*d*s.exp(-B*t))==0 and D.subs(t,0)==0
 assert D.subs(d,0)==0 and s.simplify(s.limit(D/t,t,0,dir='+')+2*d)==0
 diag=s.simplify(D.subs({aa:1,bb:1,d:1,t:s.log(2)}));assert diag==-s.Rational(3,16)
 uv=s.simplify(D.subs({aa:1/t,bb:1/t,d:1/t}));assert s.simplify(uv-(s.exp(-4)-s.exp(-2)))==0 and uv!=0
 exemplar=next(iter(XF[index['L13']].values()));assert normal(exemplar*diag+12*s.sqrt(2)*s.I*xi/25)==0
 FF=s.Matrix([[1,1,0],[0,1,2],[0,0,1]]);KK=s.Matrix([[4,1,0],[1,3,1],[0,1,2]]);GT=FF*KK.inv()*FF.T;KT=FF.T.inv()*KK*FF.inv();assert GT*KT==KT*GT==s.eye(3) and GT*(FF.inv()*KK*FF.T.inv())!=s.eye(3)
 assert s.simplify((s.exp(2*t)-1).subs(t,s.log(2)))==3
 print('STAGE independent_actual100_kernel_rows20_auxiliary_responses_and_heat_defect',flush=True)
 # Reuse qualified source maps as measured inputs,not a new source-Euler replay.
 Qsrc={index[n]:unpack(Q) for n,Q in old['actual_consumed_Qsource_maps'].items() if n in [names[Jof[i]] for i in shifted]};RF={index[n]:rows(Q) for n,Q in data['master_field_maps'].items()};I_source=add(*(mul(XJ[J],RF[n]) for n,J in pairs));I_field=add(*(mul(XF[n],Qsrc[Jof[n]]) for n in shifted));C=unpack(old['complete_C_QK']);equal(add(C,I_source,I_field),{},'whole_classical_Ward_sign');assert len(I_source)==a['whole_classical_source_product_positions'] and len(I_field)==a['whole_classical_field_action_positions']
 # Field-only Jacobian has B odd,C=0,A=D=I. A nonzero diagonal mutation is
 # a countermodel,not a proposed change of the actual physical inputs.
 U=s.symbols('U');Ab=s.eye(2);Db=s.eye(2);Bb=s.Matrix([[s.Symbol('odd1'),s.Symbol('odd2')],[0,0]]);Cb=s.zeros(2);assert (Ab-Bb*Db.inv()*Cb).det()/Db.det()==1 and s.diag(1+U,1).det()!=1
 assert all(not gradient(Q).get(n,{}) for n,Q in X.items());assert a['controls']['whole_field_source_diagonal_trace_control_insensitive']
 hb,cov,pc,pa,beta,reg=s.symbols('hbar cov pc pa beta reg');pair=pc*pa+hb*cov;j=s.Matrix(s.symbols('jB jL'));K0=s.Matrix([[5,2],[2,3]]);m=(reg*K0).inv()*j;actual=s.simplify(beta*pair*(reg*K0*m-j)[1]);omitted=s.simplify(beta*pair*(K0*m-j)[1]);ins=s.simplify(beta*pair*((reg-1)*K0*m)[1]);assert actual==0 and omitted!=0 and s.simplify(omitted+ins)==0
 mean=s.expand((hb*U)*beta*pair);assert mean.coeff(hb,1)==U*beta*pc*pa and mean.coeff(hb,2)==U*beta*cov
 assert all(a['controls'].values())
 spec=(P/'A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md').read_text(encoding='utf-8');assert 'not an implemented quantum prescription' in spec and 'loop mixing matrices are not calculated' in spec and 'Only j is Legendre transformed' in spec
 assert refrecord['finite_cutoff_loop_program']['Green_program']=='G_Lambda=F_Lambda G_ref F_Lambda^ST; fixed evaluation pairing, exact graded transpose'
 result={'schema':'TRIANGULAR_HEAT_TRANSPORT_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':'SPECIAL_CLASSICAL_SHEAR_IS_EXACT_BUT_FIXED_HEAT_QUANTUM_TRANSPORT_NEEDS_REGULATOR_AND_CONNECTED_INSERTIONS','all1286_finite_coordinate_canonical_pullback_verified':True,'canonical_full_pair_domain':1286**2,'complete_possible_nonzero_pair_support_evaluated':len(candidates),'all_other_pair_zeros_structurally_proved':True,'all643_local_H_flow_intertwiners_verified':True,'finite_mode_field_Berezinian_one_only_algebraic_control':True,'actual40_field_tangent_entries_even_output_odd_input':True,'actual_H_carriers_preserve_parity_all643_columns':True,'formal_prescribed_field_heat_Jacobian_trace_zero_without_cyclicity_or_heat_limit':True,'historical_finite_mode_path_integral_or_global_measure_NOT_inferred':True,'full20_actual_heat_defect_checked':True,'nonzero_flat_factor_at_tq2_log2':'-3/16','actual_L13_C44_a12_heat_witness':'-12*sqrt(2)*I*g10^2*xi/25','whole100_reference_kernel_rows_verified':True,'actual_auxiliary_regulator_response_positions':len(aux),'auxiliary_response_sha256':a['actual_auxiliary_response_sha256'],'nonzero_auxiliary_response_base_witness':'16*sqrt(2)*I*g10^2*xi^2*C44*L44*ub12/25 times (exp(2tq2)-1)','fixed_momentum_Ot_is_not_uniform_in_loop_UV':True,'inverse_dual_heat_order_verified':True,'complete_classical_Ward_sign_verified':True,'whole_source_product_positions':len(I_source),'whole_field_action_positions':len(I_field),'regulated_Ward_insertion_claim_conditional_on_defined_Gaussian_IBP_boundary_products':True,'inverse_heat_regulator_insertion_not_covered_automatically_by_ordinary_positive_heat_Born_theorem':True,'loop_order_connected_mean_change_starts_hbar2_for_hbar_order_map_fixed_regulator':True,'finite_contacts_QAP_A5_IR_measure_E5_A5_remain_unproved':True,'original_structural_equality_failure_preserved':True,'whole_trace_and_nu0_controls_insensitive_reported':True,'no_loop_Gamma_scheme_authority_or_physical_input_change':True,'state_sha256':digest(R/'project_state.json'),'shared_limits':'Same qualified data,source/master conventions,reference/formal-domain and analytic assumptions,software and AI author;SymPy probe/pullback checks,not expert/experiment/Lean','input_sha256':prep['input_sha256'],'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
