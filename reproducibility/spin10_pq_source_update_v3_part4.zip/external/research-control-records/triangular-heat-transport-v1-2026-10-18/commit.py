from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path.cwd();O=R/'calculations/canonical_so10_triangular_heat_transport';C=Path(r'C:/Users/psboy/.codex/research-control-records/ToE-Next/triangular-heat-transport-v1-2026-10-18');base='34e6ac55f7d2be7edfbe2a0dc628f085a99efd88'
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==base and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
paths=sorted([q.relative_to(R).as_posix() for q in O.iterdir() if q.is_file()]+['docs/RESEARCH_EXECUTION_HANDOFF_V291.md']);assert sorted(git('ls-files','--others','--exclude-standard').decode().splitlines())==paths
assert max((R/q).stat().st_size for q in paths)<5*1024**2 and sum((R/q).stat().st_size for q in paths)<10*1024**2
v=json.loads((O/'validation_receipt.json').read_bytes());assert v['execution_state']=='COMPLETED'
for q,h in v['input_sha256'].items():assert sha256(Path(q).read_bytes()).hexdigest()==h,q
raws={q:sha256((R/q).read_bytes()).hexdigest() for q in paths}
subprocess.run(['git','-c','core.autocrlf=false','add','--',*paths],cwd=R,check=True);assert git('diff','--cached','--name-only').decode().splitlines()==paths
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
for q,h in raws.items():assert sha256(git('show',':'+q)).hexdigest()==h,q
subprocess.run(['git','commit','-m','Verify special auxiliary Jacobian and required heat-product transport'],cwd=R,check=True)
head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()==base;assert sorted(git('diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines())==paths
for q,h in raws.items():assert sha256(git('show','HEAD:'+q)).hexdigest()==h==sha256((R/q).read_bytes()).hexdigest(),q
assert not git('status','--porcelain');assert sha256((R/'project_state.json').read_bytes()).hexdigest()=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
prior=C.parent/'correlated-contact-lift-v1-2026-10-18/post_commit.json';p=json.loads(prior.read_bytes());assert p['HEAD']==base
proof={'schema':'TRIANGULAR_HEAT_TRANSPORT_POST_COMMIT_V1','base':base,'HEAD':head,'branch':'main','all_old_tracked_paths_unchanged':True,'changed_paths_sha256':raws,'worktree_clean':True,'receipt_sha256':sha256((O/'validation_receipt.json').read_bytes()).hexdigest(),'final_preflight_sha256':sha256((C/'final_preflight.json').read_bytes()).hexdigest(),'prior_post_commit_sha256':sha256(prior.read_bytes()).hexdigest(),'sealed_E4_and_custody_audits':'REUSED_NOT_RERUN;no prior tracked bytes changed','prior_broad_audit_capture_sha256':p['prior_broad_audit_capture_sha256'],'custody':'EXIT2_SEVEN_UNRESOLVED_NOT_PASS','authority':'V113_34OF39_UNCHANGED','scientific_scope':'SPECIAL_EXACT_CANONICAL_SHEAR_FORMAL_ZERO_HEAT_JACOBIAN_NONZERO_HEAT_PRODUCT_CORRECTIONS_NOT_COMPLETE_RENORMALIZED_QAP'}
with (C/'post_commit.json').open('xb') as f:f.write(json.dumps(proof,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('POST_COMMIT_VERIFIED',head,len(paths),sum((R/q).stat().st_size for q in paths))
