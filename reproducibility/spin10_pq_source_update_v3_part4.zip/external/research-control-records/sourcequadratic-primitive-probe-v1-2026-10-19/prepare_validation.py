from pathlib import Path
from hashlib import sha256
import json,ast
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_sourcequadratic_primitive_probe';C=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
prep=read(O/'preparation_v5.json')
for raw,h in prep['input_sha256'].items():assert digest(Path(raw))==h,raw
assert digest(O/'probe_v5.py')==prep['source_sha256']
a=read(O/'primary_v5_result.json');b=read(O/'replay_v5_result.json');assert {k:v for k,v in a.items() if k not in ['route','elapsed_after_imports']}=={k:v for k,v in b.items() if k not in ['route','elapsed_after_imports']}
for role in ['primary','replay']:
 x=read(O/(role+'_v5_capture.json'));assert x['execution_state']=='COMPLETED' and x['exit_code']==0 and x['calculation_completed']
for p in [C/'verify.py',O/'verify.py']:ast.parse(p.read_text());assert digest(p)==digest(O/'verify.py.source.txt')
for p in [Path(__file__),C/'run_validation.py']:
 p.write_bytes((chr(10).join(z.rstrip() for z in p.read_text().splitlines()).rstrip()+chr(10)).encode())
 with p.with_name(p.name+'.source.txt').open('xb') as f:f.write(p.read_bytes())
 with(O/(p.name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
inputs={Path(raw) for raw in prep['input_sha256']};inputs.update(p for p in O.iterdir() if p.is_file());inputs.update([C/'verify.py',C/'run_validation.py',Path(__file__),C/'build_verifier.py',R/'calculations/canonical_so10_physical_counterterm_span/verify.py'])
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<8*2**20
v={'schema':'SOURCEQUADRATIC_PRIMITIVE_VALIDATION_PREPARATION_V1','input_sha256':{str(p):digest(p) for p in sorted(inputs)},'verifier_sha256':digest(C/'verify.py'),'controller_sha256':digest(C/'run_validation.py'),'scope':prep['scope'],'failed_native_workers_preserved':4,'failed_verifier_workers':0}
with(O/'validation_preparation.json').open('xb') as f:f.write((json.dumps(v,sort_keys=True,indent=2)+chr(10)).encode())
print('VALIDATION_FROZEN',len(inputs),v['verifier_sha256'])
