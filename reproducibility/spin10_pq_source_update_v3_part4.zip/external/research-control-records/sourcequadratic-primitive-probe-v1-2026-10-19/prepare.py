from pathlib import Path
from hashlib import sha256
import json,ast,subprocess
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_sourcequadratic_primitive_probe';C=Path(__file__).resolve().parent;P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
base='f527745dbae9235c7474fd307c69a566dc695236';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==base
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R)
for p in [O/'probe.py',O/'RECORD.md',O/'DERIVATION.md',Path(__file__),C/'run.py']:
 p.write_bytes((chr(10).join(z.rstrip() for z in p.read_text().splitlines()).rstrip()+chr(10)).encode())
 with p.with_name(p.name+'.source.txt').open('xb') as f:f.write(p.read_bytes())
for p in [O/'probe.py',Path(__file__),C/'run.py']:ast.parse(p.read_text())
for n in ['prepare.py','run.py']:
 with(O/(n+'.source.txt')).open('xb') as f:f.write((C/n).read_bytes())
prior=C.parent/'physical-counterterm-span-v1-2026-10-19';q=read(prior/'next_original_E5_A5_reconciliation_question.json')
inputs=[Path(__file__),C/'run.py',O/'RECORD.md',O/'DERIVATION.md',prior/'next_original_E5_A5_reconciliation_question.json']
for raw,h in q['input_sha256'].items():assert digest(Path(raw))==h,raw;inputs.append(Path(raw))
for rel in ['tools/portable_dh_v1/inputs.json.gz','tools/portable_dh_v1/exact_algebra.py','docs/SOLO_REVIEW_POLICY_V1.md']:inputs.append(R/rel)
arts={r:{} for r in ['primary','replay']};allowed={r:[str(O/'preparation.json')] for r in arts}
for label,folder in [('e1','frozen_a10_e1_fermion'),('e2','frozen_a10_e2_transport'),('e3','frozen_a10_e3_symmetry'),('regularity','frozen_a10_e5_regularity'),('retract','frozen_a10_e5_nonminimal_retract')]:
 d=P/folder;rc=d/'validation_receipt.json';v=read(rc);inputs.append(rc)
 if label in ['e1','e2','e3']:
  bp=d/'bindings.json';bv=read(bp)['byte_sha256'];inputs.append(bp);assert bv[rc.relative_to(R).as_posix()]==digest(rc)
 else:bv=v['new_sha256']
 for role in arts:
  fp=d/(role+'.json');assert bv[fp.relative_to(R).as_posix()]==digest(fp);inputs.append(fp);allowed[role].append(str(fp));arts[role][label]={'path':str(fp),'sha256':digest(fp),'receipt':str(rc),'receipt_sha256':digest(rc)}
for dirname in ['canonical_so10_dimensional_stokes_primitive','canonical_so10_joint_born_ir_trace_domain','canonical_so10_ordered_multiheat_uv_log','canonical_so10_sourcefree_primitive_probe','canonical_so10_original_ghost_rescaling','canonical_so10_physical_counterterm_span']:
 d=R/'calculations'/dirname;rc=d/'validation_receipt.json';v=read(rc);assert v['execution_state']=='COMPLETED';inputs.append(rc)
 for n in ['RESULT.md','DERIVATION.md','DERIVATION_V2.md','PROBE_DERIVATION.md']:
  if(d/n).exists():inputs.append(d/n)
v={'schema':'SOURCEQUADRATIC_PRIMITIVE_PROBE_PREPARATION_V1','base':base,'source_sha256':digest(O/'probe.py'),'controller_sha256':digest(C/'run.py'),'input_sha256':{str(p):digest(p) for p in sorted(set(inputs))},'artifacts':arts,'read_json_by_role':allowed,'limits':{'native_after_imports_seconds':120,'verifier_after_imports_seconds':180,'sampled_private_bytes':8*2**30,'package_bytes':8*2**20},'scope':'Complete two-source carrier first-probe replacement in the fixed formal Euclidean one-loop construction;not one-source or universal E5/A5.'}
with(O/'preparation.json').open('xb') as f:f.write((json.dumps(v,sort_keys=True,indent=2)+chr(10)).encode())
print('FROZEN',len(v['input_sha256']),v['source_sha256'])
