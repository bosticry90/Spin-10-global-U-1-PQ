from pathlib import Path
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_unit_translation_slavnov';C=Path(__file__).resolve().parent
old=(O/'unit.py').read_text();find="get('irs')['complete_one_translation_IR_residue_Q_closed_in_retained_domain']";assert old.count(find)==1
new=old.replace(find,"get('irs')['complete_one_translation_IR_residue_Q_closed_in_retained_Euclidean_finite_Born_domain']").replace("O/'preparation.json'","O/'preparation_v2.json'")
with(O/'unit_v2.py').open('x',encoding='utf-8',newline='\n') as f:f.write(new)
old=(C/'run.py').read_text();new=old.replace("O/'preparation.json'","O/'preparation_v2.json'").replace("O/'unit.py'","O/'unit_v2.py'").replace('_capture.json','_v2_capture.json').replace('_result.json','_v2_result.json')
with(C/'run_v2.py').open('x',encoding='utf-8',newline='\n') as f:f.write(new)
