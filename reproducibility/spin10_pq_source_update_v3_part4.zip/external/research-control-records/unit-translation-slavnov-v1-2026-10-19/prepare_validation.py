from pathlib import Path
from hashlib import sha256
import ast,json
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_unit_translation_slavnov';C=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();p=read(O/'preparation_v3.json');inputs=dict(p['input_sha256'])
for role in ['primary','replay']:
 cap=read(O/(role+'_v3_capture.json'));assert cap['execution_state']=='COMPLETED' and not cap['failed_or_incomplete_counted_as_PASS']
 assert read(O/(role+'_v3_result.json'))['elapsed_after_imports']<120
for path in [O/'preparation_v3.json',O/'primary_v3_capture.json',O/'replay_v3_capture.json',O/'primary_v3_result.json',O/'replay_v3_result.json',O/'VERIFICATION_PLAN.md',C/'verify.py',C/'prepare_validation.py',C/'run_validation.py']:
 if path.suffix=='.py':ast.parse(path.read_text())
 inputs[str(path)]=digest(path)
for path in [C/'verify.py',C/'prepare_validation.py',C/'run_validation.py']:
 dest=O/(path.name+'.source.txt')
 with dest.open('xb') as f:f.write(path.read_bytes())
 inputs[str(dest)]=digest(dest)
for raw,h in inputs.items():assert digest(Path(raw))==h,raw
v={'schema':'UNIT_TRANSLATION_SLAVNOV_VALIDATION_PREPARATION_V1','input_sha256':inputs,'verifier_sha256':digest(C/'verify.py'),'controller_sha256':digest(C/'run_validation.py'),
 'independent_seconds_after_imports':180,'sampled_private_limit_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2,'package_limit_bytes':8*1024**2,
 'preserved_native_failed_executions':2,'preserved_verifier_failed_executions':0,'read_only_navigation_errors':1,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'validation_preparation.json').open('xb') as f:f.write((json.dumps(v,indent=2,sort_keys=True)+'\n').encode())
print('VALIDATION_FROZEN',len(inputs),v['verifier_sha256'])
