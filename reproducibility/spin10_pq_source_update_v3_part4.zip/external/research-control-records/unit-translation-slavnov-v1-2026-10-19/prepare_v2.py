from pathlib import Path
from hashlib import sha256
import ast,json
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_unit_translation_slavnov';C=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();p=read(O/'preparation.json');inputs=dict(p['input_sha256'])
assert read(O/'primary_capture.json')['execution_state']=='FAILED' and not(O/'replay_capture.json').exists()
for path in [O/'preparation.json',O/'primary_capture.json',C/'primary_full_capture.json',O/'CONTINUATION_V2.md',O/'unit_v2.py',C/'build_v2.py',C/'prepare_v2.py',C/'run_v2.py']:
 if path.suffix=='.py':ast.parse(path.read_text())
 inputs[str(path)]=digest(path)
for path in [O/'unit_v2.py',C/'build_v2.py',C/'prepare_v2.py',C/'run_v2.py']:
 dest=O/(path.name+'.source.txt')
 with dest.open('xb') as f:f.write(path.read_bytes())
 inputs[str(dest)]=digest(dest)
for raw,h in inputs.items():assert digest(Path(raw))==h,raw
p.update(schema='UNIT_TRANSLATION_SLAVNOV_PREPARATION_V2',input_sha256=inputs,controller_sha256=digest(C/'run_v2.py'),preserved_failed_native_executions=1)
with(O/'preparation_v2.json').open('xb') as f:f.write((json.dumps(p,indent=2,sort_keys=True)+'\n').encode())
print('V2_FROZEN',len(inputs),p['controller_sha256'])
