from pathlib import Path
from hashlib import sha256
import json,os,subprocess,sys
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_unit_translation_slavnov';C=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
from audit_a10_e5_antighost_vector import resource,line_json
p=json.loads((O/'preparation_v2.json').read_bytes());assert sha256(Path(__file__).read_bytes()).hexdigest()==p['controller_sha256']
assert all(not(O/(r+t)).exists() for r in ['primary','replay'] for t in ['_v2_capture.json','_v2_result.json'])
for role in ['primary','replay']:
 query="@(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.ProcessId -ne "+str(os.getpid())+" -and ($_.CommandLine -like '*canonical_so10_unit_translation_slavnov*' -or $_.CommandLine -like '*unit-translation-slavnov-v1-2026-10-19*') } | Select-Object ProcessId,CommandLine) | ConvertTo-Json -Compress"
 assert not subprocess.check_output(['pwsh','-NoProfile','-Command',query]).strip(),'LIVE_WORK_POLL_HANDLE'
 cap=capture([sys.executable,'-B',str(O/'unit_v2.py'),role]);raw=(json.dumps(cap,sort_keys=True,separators=(',',':'))+'\n').encode()
 for dest in [O/(role+'_v2_capture.json'),C/(role+'_full_v2_capture.json')]:
  with dest.open('xb') as f:f.write(raw)
 if cap['execution_state']!='COMPLETED':print(cap['stdout_and_stderr'],flush=True)
 resource(cap);v=line_json(cap['stdout_and_stderr'],'RESULT ');assert 0<v['elapsed_after_imports']<120
 with(O/(role+'_v2_result.json')).open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
 print('COMPLETED',role,v['elapsed_after_imports'],flush=True)
