from pathlib import Path
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_unit_translation_slavnov';C=Path(__file__).resolve().parent
old=(C/'verify.py').read_text();find="tauphys=s.SparseMatrix(643,1,{(i,0):ex(v) for i,v in get('transport')['actual_tau_physical']});assert tauphys.nnz()==20";assert old.count(find)==1
new=old.replace(find,"physpos={f'x_{sec}_{j}':180+offset+j for sec,n,offset in [('Phi',54,0),('Sigma',252,54),('phi',20,306),('S',2,326)] for j in range(n)}\ntauphys=s.SparseMatrix(643,1,{(physpos[name],0):ex(v) for name,v in get('transport')['actual_tau_physical']});assert tauphys.nnz()==20")
new=new.replace("O/'validation_preparation.json'","O/'validation_preparation_v2.json'").replace("'failed_verifier_workers':0","'failed_verifier_workers':1")
with(C/'verify_v2.py').open('x',encoding='utf-8',newline='\n') as f:f.write(new)
new=(C/'run_validation.py').read_text().replace('validation_preparation.json','validation_preparation_v2.json').replace('validation_receipt.json','validation_receipt_v2.json').replace('validation_capture.json','validation_v2_capture.json').replace('validation_full_capture.json','validation_full_v2_capture.json').replace("'verify.py'","'verify_v2.py'")
with(C/'run_validation_v2.py').open('x',encoding='utf-8',newline='\n') as f:f.write(new)
