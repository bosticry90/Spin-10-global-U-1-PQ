from pathlib import Path
from hashlib import sha256
import ast,json
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_unit_translation_slavnov';C=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();p=read(O/'validation_preparation.json');inputs=dict(p['input_sha256'])
assert read(O/'validation_capture.json')['execution_state']=='FAILED' and not(O/'validation_receipt.json').exists()
for path in [O/'validation_preparation.json',O/'validation_capture.json',C/'validation_full_capture.json',O/'VERIFIER_CONTINUATION_V2.md',C/'verify_v2.py',C/'build_validation_v2.py',C/'prepare_validation_v2.py',C/'run_validation_v2.py']:
 if path.suffix=='.py':ast.parse(path.read_text())
 inputs[str(path)]=digest(path)
for path in [C/'verify_v2.py',C/'build_validation_v2.py',C/'prepare_validation_v2.py',C/'run_validation_v2.py']:
 dest=O/(path.name+'.source.txt')
 with dest.open('xb') as f:f.write(path.read_bytes())
 inputs[str(dest)]=digest(dest)
for raw,h in inputs.items():assert digest(Path(raw))==h,raw
p.update(schema='UNIT_TRANSLATION_SLAVNOV_VALIDATION_PREPARATION_V2',input_sha256=inputs,verifier_sha256=digest(C/'verify_v2.py'),controller_sha256=digest(C/'run_validation_v2.py'),preserved_verifier_failed_executions=1)
with(O/'validation_preparation_v2.json').open('xb') as f:f.write((json.dumps(p,indent=2,sort_keys=True)+'\n').encode())
print('VALIDATION_V2_FROZEN',len(inputs),p['verifier_sha256'])
