from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_unit_translation_slavnov';C=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();base='9d3f2307ac9cd7db3cbfc61df9b4ea84c4b745d8'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==base and not subprocess.check_output(['git','diff','--name-only'],cwd=R).strip()
old=read(R/'calculations/canonical_so10_ir_residue_slavnov/validation_receipt.json');assert old['execution_state']=='COMPLETED';inputs=dict(old['input_sha256']);artifacts={}
for role in ['primary','replay']:
 paths={k:Path(v['path']) for k,v in read(R/'calculations/canonical_so10_critical_root_first_variation/preparation.json')['artifacts'][role].items() if k in ['core','original','paired']}
 paths.update({'transport':R/f'calculations/canonical_so10_general_first_order_transport/{role}_v3_result.json','firstQ':R/f'calculations/canonical_so10_critical_root_first_variation/{role}_result.json',
 'local':R/f'calculations/canonical_so10_onesource_primitive_probe/{role}_v3_result.json','irs':R/'calculations/canonical_so10_ir_residue_slavnov/validation_receipt.json',
 'ccm':R/f'calculations/canonical_so10_covariant_critical_root_matching/{role}_result.json'})
 artifacts[role]={k:{'path':str(path),'sha256':digest(path)} for k,path in paths.items()}
 for v in artifacts[role].values():inputs[v['path']]=v['sha256']
for path in [R/'calculations/canonical_so10_ir_residue_slavnov/validation_receipt.json',R/'calculations/canonical_so10_ir_residue_slavnov/RESULT.md',R/'calculations/canonical_so10_ir_residue_slavnov/DERIVATION.md',
 R/'calculations/canonical_so10_onesource_primitive_probe/DERIVATION.md',R/'calculations/canonical_so10_onesource_primitive_probe/validation_receipt.json',R/'calculations/canonical_so10_sourcequadratic_primitive_probe/TRACE_DOMAIN_NOTE.md',
 R/'calculations/canonical_so10_paired_translation_response/DERIVATION.md',R/'calculations/canonical_so10_critical_root_first_variation/DERIVATION.md',R/'calculations/canonical_so10_covariant_critical_root_matching/DERIVATION.md',
 R/'docs/RESEARCH_EXECUTION_HANDOFF_V353.md',C.parent/'ir-residue-slavnov-v1-2026-10-19/post_commit.json']:
 inputs[str(path)]=digest(path)
for path in [O/'RECORD.md',O/'DERIVATION.md',O/'unit.py',C/'prepare.py',C/'run.py']:
 if path.suffix=='.py':ast.parse(path.read_text())
 inputs[str(path)]=digest(path);dest=O/(path.name+'.source.txt')
 with dest.open('xb') as f:f.write(path.read_bytes())
 inputs[str(dest)]=digest(dest)
for raw,h in inputs.items():assert digest(Path(raw))==h,raw
p={'schema':'UNIT_TRANSLATION_SLAVNOV_PREPARATION_V1','base_commit':base,'artifacts':artifacts,'input_sha256':inputs,'controller_sha256':digest(C/'run.py'),
 'native_seconds_after_imports':120,'independent_seconds_after_imports':180,'sampled_private_limit_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2,'package_limit_bytes':8*1024**2,
 'scope':'Actual finite one-tau insertion Ward law by adiabatic/root matching, not original all-W6 affinity/even-cocycle adequacy or full QAP/A5/E5','read_only_navigation_errors':1,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'preparation.json').open('xb') as f:f.write((json.dumps(p,indent=2,sort_keys=True)+'\n').encode())
print('FROZEN',len(inputs),p['controller_sha256'])
