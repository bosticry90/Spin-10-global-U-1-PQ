from pathlib import Path
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_unit_translation_slavnov';C=Path(__file__).resolve().parent
old=(O/'unit_v2.py').read_text();assert old.count("assert s.expand_log(unit-ad-cd,force=True)==0")==1
new=old.replace("assert s.expand_log(unit-ad-cd,force=True)==0","assert s.simplify(s.expand_log(unit-ad-cd,force=True))==0")
new=new.replace("assert s.expand_log(cd-(d-1-s.EulerGamma),force=True)==s.log(4)","assert s.simplify(s.expand_log(cd-(d-1-s.EulerGamma)-s.log(4),force=True))==0").replace("O/'preparation_v2.json'","O/'preparation_v3.json'")
with(O/'unit_v3.py').open('x',encoding='utf-8',newline='\n') as f:f.write(new)
new=(C/'run_v2.py').read_text().replace('preparation_v2.json','preparation_v3.json').replace('unit_v2.py','unit_v3.py').replace('_v2_capture.json','_v3_capture.json').replace('_v2_result.json','_v3_result.json')
with(C/'run_v3.py').open('x',encoding='utf-8',newline='\n') as f:f.write(new)
