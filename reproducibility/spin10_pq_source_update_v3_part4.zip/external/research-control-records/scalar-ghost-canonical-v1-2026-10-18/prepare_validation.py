from pathlib import Path
from hashlib import sha256
from math import gcd
import json,ast,symtable,builtins,subprocess,importlib.util,sys
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_canonical';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
prep=read(OUT/'preparation.json');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head==prep['base_commit']=='f4086e6de82f9c09b995e26285ed061715febf11';files={Path(p) for p in prep['input_sha256']}|{OUT/'preparation.json',OUT/'RESULT_V1.md'};allowed={OUT/'validation_preparation.json'}
for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
for role in ['primary','replay']:
 cap=OUT/(role+'_capture.json');result=OUT/(role+'_result.json');c=read(cap);assert c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified'] and c['exit_code']==0 and cap.read_bytes()==(CONTROL/(role+'_full_capture.json')).read_bytes();r=read(result);assert r['schema']=='COMPLETE_ACTUAL_SCALAR_GHOST_CANONICAL_TRANSPORT_V1' and r['route']==role and 0<r['elapsed_after_imports']<300;files.update([cap,result,CONTROL/(role+'_full_capture.json')]);allowed.update([cap,result]);allowed.update(Path(p) for p in prep['read_json_by_role'][role])
a=read(OUT/'primary_result.json');b=read(OUT/'replay_result.json')
for key in a.keys()-{'route','elapsed_after_imports','transport_metadata'}:assert a[key]==b[key],key
assert a['complete_unfiltered_forward_contributions']==4175624 and all(a['full_field_map_and_reality_proof'].values()) and a['all_parameter_packets_complete_inverse_and_implicit_zeros_recovered'] and type(a['all_canonical_coefficients_in_old_four_root_subring']) is bool
for rows in a['canonical_parameter_tables'].values():
 for word,cells in rows:
  assert word==sorted(word) and len(word) in (3,4) and all(type(n) is str for n in word) and cells and len({m for m,n,d in cells})==len(cells)
  for m,n,d in cells:assert all(type(q) is int for q in [m,n,d]) and 0<=m<32 and n and d>0 and gcd(n,d)==1
for p in [CONTROL/'verify.py',CONTROL/'run_validation.py',Path(__file__)]:
 text=p.read_text(encoding='utf-8');ast.parse(text);tree=symtable.symtable(text,str(p),'exec');defs={z.get_name() for z in tree.get_symbols() if z.is_assigned() or z.is_imported() or z.is_namespace()}|set(dir(builtins))|{'__file__','__name__','__package__'};errors=[]
 def scan(t):
  for z in t.get_symbols():
   if z.is_referenced() and z.is_global() and z.get_name() not in defs:errors.append((t.get_name(),z.get_name()))
  for q in t.get_children():scan(q)
 scan(tree);assert not errors,errors
sp=importlib.util.spec_from_file_location('independent_canonical_scalar_types',CONTROL/'verify.py');u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);assert u.fixture();json.dumps(u.encoded(u.coeff([[0,3,2],[8,-1,5],[16,2,7]])));assert u.canonical_word(0,12,('x_Phi_0','x_Phi_0'))==('C0','ub12','x_Phi_0','x_Phi_0')
for mod in list(sys.modules.values()):
 name=getattr(mod,'__file__',None)
 if name:
  p=Path(name).resolve()
  if p.suffix=='.py' and(p.is_relative_to(ROOT) or p.is_relative_to(CONTROL.parent)):files.add(p)
for p in [CONTROL/'verify.py',CONTROL/'run_validation.py',Path(__file__)]:
 copy=Path(str(p)+'.source.txt')
 with copy.open('xb') as f:f.write(p.read_bytes())
 files.update([p,copy])
d={'schema':'CANONICAL_SCALAR_GHOST_VALIDATION_PREPARATION_V1','base_commit':head,'validator_sha256':digest(CONTROL/'verify.py'),'controller_sha256':digest(CONTROL/'run_validation.py'),'input_sha256':{str(p):digest(p) for p in sorted(files)},'read_json':[str(p) for p in sorted(allowed)],'both_full_native_mathematical_payloads_equal':True,'all_canonical_word_radical_types_checked':True,'complex_reality_inverse_and_Bose_fixtures_passed':True,'old_four_root_readiness_is_diagnostic_not_acceptance_boolean':True,'metadata_json_type_preflight_passed':True,'undefined_global_static_preflight_errors':[],'all_source_copies_exclusive':True,'completed_native_workers':2,'failed_native_workers':0,'limits':{'seconds_after_imports':300,'private_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2}}
with(OUT/'validation_preparation.json').open('xb') as f:f.write(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('VALIDATION_FROZEN',len(files),'canonical_positions',sum(a['canonical_parameter_counts'].values()))
