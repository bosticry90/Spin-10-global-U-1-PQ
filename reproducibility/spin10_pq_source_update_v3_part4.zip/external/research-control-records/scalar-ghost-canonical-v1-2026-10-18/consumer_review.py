"""Read-only source/receipt inspection for the dependent consumer;no new proof."""
from pathlib import Path
from hashlib import sha256
import json,ast
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
p=ROOT/'calculations/canonical_so10_scalar_source_g3_color';r=read(p/'validation_receipt.json');source=p/'scalar_exact.py';primary=p/'primary_v2_result.json';assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(source)]==digest(source) and r['input_sha256'][str(primary)]==digest(primary)
d=read(primary);assert d['local_exact_field_control']=={'exact_basis_products':1024,'radical_basis':32,'scalar_sqrt7_and_width_polynomial_checks':True}
squares=next(ast.literal_eval(n.value) for n in ast.parse(source.read_text(encoding='utf-8')).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SQUARES' for t in n.targets));assert squares==(2,3,5,7,-1)
m=ROOT/'calculations/canonical_so10_simultaneous_source_slavnov/assessment_v3.py';assert "canonical_so10_scalar_source_g3_color/scalar_exact.py" in m.read_text(encoding='utf-8')
out={'classification':'READ_ONLY_ACTUAL_CONSUMER_SOURCE_AND_QUALIFIED_RECEIPT_REVIEW_NOT_NEW_ADAPTER_PROOF','actual_current_consumer':str(m),'actual_current_consumer_sha256':digest(m),'qualified_coefficient_source':str(source),'qualified_coefficient_source_sha256':digest(source),'qualified_source_receipt_sha256':digest(p/'validation_receipt.json'),'qualified_source_primary_sha256':digest(primary),'inherited_exact_basis_control':d['local_exact_field_control'],'incoming_basis_squared':[2,3,5,-1,7],'consumer_basis_squared':list(squares),'proposed_mask_map':'(mask&7)|((mask&8)<<1)|((mask&16)>>1)','proposed_width_cells':'(xi_power,eta_H_power,relabeled_mask)','requires_new_arithmetic_engine':False,'adapter_isomorphism_or_actual_integration_newly_qualified':False,'next_required_check':'All32 basis values/1024 products,conjugation,width powers and full coefficient packet bijection before exact-once integration'}
with(CONTROL/'consumer_basis_review.json').open('xb') as f:f.write(json.dumps(out,sort_keys=True,separators=(',',':')).encode()+b'\n')
print(json.dumps({'actual_current_consumer':str(m),'already_qualified_five_root_source':True,'different_I_sqrt7_bit_order':True,'new_adapter_proof':False}))
