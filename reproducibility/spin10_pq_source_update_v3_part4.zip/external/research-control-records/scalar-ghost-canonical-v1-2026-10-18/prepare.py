from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from math import gcd
import json,ast,symtable,builtins,subprocess,importlib.util,sys
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_canonical';CONTROL=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='f4086e6de82f9c09b995e26285ed061715febf11'
parent=ROOT/'calculations/canonical_so10_scalar_ghost_actual_pole/validation_receipt.json';r=read(parent);assert r['schema']=='ACTUAL_SCALAR_GHOST_POLE_INDEPENDENT_VALIDATION_V1' and r['execution_state']=='COMPLETED' and digest(parent)=='a1e1fd90e9a98158c7eed46f5c9b8f7c23cdb385cd08fee588ccb3d52871d47f'
files={Path(p) for p in r['input_sha256']}|{parent,OUT/'RECORD.md',ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V281.md',ROOT/'AGENTS.md',ROOT/'CHARTER.md',ROOT/'project_state.json'}
for p,h in r['input_sha256'].items():assert digest(Path(p))==h,p
oldcontrol=CONTROL.parent/'scalar-ghost-actual-pole-v1-2026-10-18';files|={oldcontrol/'post_commit.json',oldcontrol/'canonical_support_cost_plan.json',oldcontrol/'canonical_support_cost.py',ROOT/'calculations/canonical_so10_scalar_ghost_actual_pole/RESULT_V2.md'}
assert read(oldcontrol/'post_commit.json')['HEAD']==head and read(oldcontrol/'canonical_support_cost_plan.json')['total_unfiltered_field_map_contributions']==4175624
roles={};probes=[]
for role in ['primary','replay']:
 roles[role]={OUT/'preparation.json',parent}
 p=parent.parent/(role+'_result.json');assert r['input_sha256'][str(p)]==digest(p);roles[role].add(p);files.add(p);probes.append({'path':str(p),'receipt_sha256':digest(parent),'sha256':digest(p)})
 p=PKG/'frozen_a10_e5_full_hessian'/(role+'.json');b=p.parent/'bindings.json';assert read(b)['byte_sha256'][p.relative_to(ROOT).as_posix()]==digest(p);roles[role].update([p,b]);files.update([p,b])
for p in [OUT/'transport.py',CONTROL/'run.py',Path(__file__)]:
 text=p.read_text(encoding='utf-8');ast.parse(text);tree=symtable.symtable(text,str(p),'exec');defs={z.get_name() for z in tree.get_symbols() if z.is_assigned() or z.is_imported() or z.is_namespace()}|set(dir(builtins))|{'__file__','__name__','__package__'};errors=[]
 def scan(t):
  for z in t.get_symbols():
   if z.is_referenced() and z.is_global() and z.get_name() not in defs:errors.append((t.get_name(),z.get_name()))
  for q in t.get_children():scan(q)
 scan(tree);assert not errors,errors
sp=importlib.util.spec_from_file_location('canonical_scalar_pole_type_preflight',OUT/'transport.py');u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);assert u.fixtures();types={};packets=dict(r['coalesced_physical_linear_tables']);packets['g4_etaH0_xi0_scalar2']=read(parent.parent/'primary_result.json')['group_physical_poles']['g4_xi0_pair'];assert set(packets)==set(u.PARAM)
for role in ['primary','replay']:
 ref=read(PKG/'frozen_a10_e5_full_hessian'/(role+'.json'))['retained_reference'];names=ref['field_order'];assert len(names)==len(set(names))==643 and set(names)==set(u.algebra().fields);T=defaultdict(list)
 for key in ['physical_to_raw_kernel','physical_to_raw_inverse']:
  for i,j,z in ref[key]['entries']:
   assert type(i) is type(j) is int and 0<=i<643 and 0<=j<643;v=u.number(z);assert v and all(type(m) is int and 0<=m<32 for m,f in v)
   if key=='physical_to_raw_kernel':T[i].append((j,z))
 for x in range(328):assert len(T[180+x])==1 and names[T[180+x][0][0]].startswith('x_') and T[180+x][0][1]=='1'
 costs={};ncells=0
 for label,rows in packets.items():
  for c,a,ss,h,w,z in rows:
   assert all(type(q) is int for q in [c,a,h,w,*ss]) and 0<=c<45<=a<90 and h==w==0 and ss==sorted(ss) and len(ss)==u.PARAM[label][3] and all(0<=x<328 for x in ss)
   assert z and len({m for m,n,d in z})==len(z) and z==sorted(z)
   for m,n,d in z:assert all(type(q) is int for q in [m,n,d]) and 0<=m<32 and not m&8 and n and d>0 and gcd(n,d)==1
   ncells+=len(z)
  costs[label]=sum(len(T[553+c])*len(T[553+a]) for c,a,ss,h,w,z in rows)
 assert sum(costs.values())==4175624
 types[role]={'complete_field_directions':643,'all_scalar_unit_rows':328,'full_physical_positions':sum(map(len,packets.values())),'exact_radical_cells_checked':ncells,'field_map_sizes':{key:len(ref[key]['entries']) for key in ['physical_to_raw_kernel','physical_to_raw_inverse']},'unfiltered_forward_contributions':costs,'no_actual_transport_or_reality_matrix_computed_in_preflight':True}
json.dumps({'types':types,'fixtures':u.fixtures(),'packed_numeric':u.cells(((0,3),(8,-2)),5),'parameter_powers':u.PARAM})
for mod in list(sys.modules.values()):
 name=getattr(mod,'__file__',None)
 if name:
  p=Path(name).resolve()
  if p.suffix=='.py' and(p.is_relative_to(ROOT) or p.is_relative_to(CONTROL.parent)):files.add(p)
for p in [OUT/'transport.py',CONTROL/'run.py',Path(__file__)]:
 copy=Path(str(p)+'.source.txt')
 with copy.open('xb') as f:f.write(p.read_bytes())
 files.update([p,copy])
d={'schema':'CANONICAL_SCALAR_GHOST_TRANSPORT_PREPARATION_V1','base_commit':head,'source_sha256':digest(OUT/'transport.py'),'controller_sha256':digest(CONTROL/'run.py'),'input_sha256':{str(p):digest(p) for p in sorted(files)},'read_json_by_role':{role:[str(p) for p in sorted(pp)] for role,pp in roles.items()},'qualified_input_probes':probes,'preflight_full_packet_map_and_radical_types':types,'odd_even_and_Bose_fixtures_passed':True,'metadata_json_type_preflight_passed':True,'all_source_copies_exclusive':True,'limits':{'seconds_after_imports':300,'private_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2}}
with(OUT/'preparation.json').open('xb') as f:f.write(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('FROZEN',len(files),'type_positions',types['primary']['full_physical_positions'],'cells',types['primary']['exact_radical_cells_checked'])
