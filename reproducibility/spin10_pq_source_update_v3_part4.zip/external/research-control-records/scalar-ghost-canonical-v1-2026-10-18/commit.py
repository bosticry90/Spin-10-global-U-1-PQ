from pathlib import Path
from hashlib import sha256
import json,subprocess
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_canonical';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def git(*args,raw=False):
 z=subprocess.check_output(['git',*args],cwd=ROOT);return z if raw else z.decode('utf-8').strip()
base=read(OUT/'preparation.json')['base_commit'];assert git('rev-parse','HEAD')==base=='f4086e6de82f9c09b995e26285ed061715febf11'
r=read(OUT/'validation_receipt.json');assert r['schema']=='CANONICAL_SCALAR_GHOST_COMPLETE_INDEPENDENT_VALIDATION_V1' and r['execution_state']=='COMPLETED' and r['scientific_disposition']=='COMPLETE_CANONICAL_SCALAR_GHOST_TRANSPORT_WITH_REALITY_NOT_INTEGRATION'
for key,value in r.items():
 if type(value) is bool and key!='old_four_root_consumer_ready':assert value,key
assert r['old_four_root_consumer_ready'] is False and r['native_worker_failures']==r['independent_worker_failures']==r['fresh_byte_identical_replay_pairs_claimed']==0 and r['new_integration_or_full_E5_A5']=='NOT_PERFORMED_UNQUALIFIED'
assert digest(OUT/'validation_receipt.json')=='899b3d9a3aba1357fed9dd14629b62fc8f9501fc6007051023ea8e9de41b66bc'
maps={}
for name in ['preparation.json','validation_preparation.json','validation_receipt.json']:
 d=read(OUT/name);maps[name]=len(d['input_sha256'])
 for p,h in d['input_sha256'].items():assert digest(Path(p))==h,(name,p)
assert list(maps.values())==[1819,1833,1833]
for folder in [OUT,CONTROL]:
 for p in folder.glob('*.source.txt'):assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes(),p
for short in ['primary','replay','validation']:
 cap=read(OUT/(short+'_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and cap['private_allocation_limit_bytes']==8*1024**3
 assert (OUT/(short+'_capture.json')).read_bytes()==(CONTROL/(short+'_full_capture.json')).read_bytes() and cap['all_resource_samples'] and all('query_error' not in z and 0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
 assert 0<read(OUT/('validation_receipt.json' if short=='validation' else short+'_result.json'))['elapsed_after_imports']<300
a=read(OUT/'primary_result.json');b=read(OUT/'replay_result.json');assert a['schema']==b['schema']=='COMPLETE_ACTUAL_SCALAR_GHOST_CANONICAL_TRANSPORT_V1'
for key in a.keys()-{'route','elapsed_after_imports','transport_metadata'}:assert a[key]==b[key],key
assert a['canonical_parameter_hashes']==r['canonical_parameter_hashes'] and a['canonical_parameter_counts']==r['canonical_parameter_counts']=={'g3_etaH0_xi2_scalar1':5480,'g4_etaH0_xi0_scalar2':711338,'g4_etaH0_xi2_scalar1':6904,'g4_etaH1_xi1_scalar1':6888}
assert a['canonical_complex_parameter_positions']==r['canonical_complex_parameter_positions']=={'g3_etaH0_xi2_scalar1':2720,'g4_etaH0_xi0_scalar2':342908,'g4_etaH0_xi2_scalar1':3336,'g4_etaH1_xi1_scalar1':3336}
assert a['canonical_sqrt7_parameter_positions']==r['canonical_sqrt7_parameter_positions']=={'g3_etaH0_xi2_scalar1':24,'g4_etaH0_xi0_scalar2':3632,'g4_etaH0_xi2_scalar1':72,'g4_etaH1_xi1_scalar1':72}
assert a['all_canonical_coefficients_in_old_four_root_subring'] is False and all(a['full_field_map_and_reality_proof'].values()) and not any(a['all_seven_quantum_flags_false'].values()) and a['current_known_terms']==155143 and a['current_known_sha256']=='fe6bd8e800d8e04f9d0358ce94c081d70e94af0ffd37830bb50c02fdbb0c0241' and a['sourcefree_positions']==41452 and a['sourceimage_positions']==146663 and not a['new_loop_canonical_integration_or_Slavnov_identity'] and not a['full_QAP_IR_measure_products_contacts_equivalence_E5_A5']
review=read(CONTROL/'consumer_basis_review.json');assert not review['requires_new_arithmetic_engine'] and not review['adapter_isomorphism_or_actual_integration_newly_qualified'] and review['consumer_basis_squared']==[2,3,5,7,-1] and review['incoming_basis_squared']==[2,3,5,-1,7]
for k,h in [('actual_current_consumer','actual_current_consumer_sha256'),('qualified_coefficient_source','qualified_coefficient_source_sha256')]:assert digest(Path(review[k]))==review[h]
old=ROOT/'calculations/canonical_so10_scalar_source_g3_color';oldr=read(old/'validation_receipt.json');assert oldr['execution_state']=='COMPLETED' and digest(old/'validation_receipt.json')==review['qualified_source_receipt_sha256']=='78d1c0641b0b205d73729eaaaa23bebefe76ce54f719196ea70e02af40a76874'
for p in [old/'scalar_exact.py',old/'primary_v2_result.json']:assert oldr['input_sha256'][str(p)]==digest(p)
assert read(old/'primary_v2_result.json')['local_exact_field_control']==review['inherited_exact_basis_control']=={'exact_basis_products':1024,'radical_basis':32,'scalar_sqrt7_and_width_polynomial_checks':True}
for p in ['AGENTS.md','CHARTER.md','README.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md']:assert git('show',base+':'+p,raw=True)==(ROOT/p).read_bytes(),p
paths=sorted([p.relative_to(ROOT).as_posix() for p in OUT.iterdir() if p.is_file()]+['docs/RESEARCH_EXECUTION_HANDOFF_V282.md']);assert set(git('ls-files','--others','--exclude-standard').splitlines())==set(paths) and not git('diff','--name-only') and not git('diff','--cached','--name-only')
for p in [ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V282.md',OUT/'RESULT_V2.md']:assert digest(OUT/'validation_receipt.json') in p.read_text(encoding='utf-8')
subprocess.check_call(['git','-c','core.autocrlf=false','-c','core.longpaths=true','add','--',*paths],cwd=ROOT);assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
for p in paths:assert git('show',':'+p,raw=True)==(ROOT/p).read_bytes(),p
subprocess.check_call(['git','diff','--cached','--check'],cwd=ROOT);subprocess.check_call(['git','commit','-m','Qualify full canonical scalar ghost transport with inverse and reality proof'],cwd=ROOT)
head=git('rev-parse','HEAD');assert git('rev-parse','HEAD^')==base and set(git('diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines())==set(paths)
for p in paths:assert git('show','HEAD:'+p,raw=True)==git('show',':'+p,raw=True)==(ROOT/p).read_bytes(),p
assert not git('status','--porcelain=v1')
proof={'HEAD':head,'parent':base,'exact_changed_files':paths,'all_HEAD_index_worktree_bytes_equal':True,'working_tree_clean':True,'receipt_sha256':digest(OUT/'validation_receipt.json'),'authority_unchanged':digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8','all_three_current_input_binding_maps':maps,'all730610_canonical_parameter_positions_and_inverse_reality_verified':True,'old_subring_diagnostic_false_not_misclassified_as_failure':True,'actual_current_five_root_consumer_source_review_sha256':digest(CONTROL/'consumer_basis_review.json'),'consumer_review_source_sha256':digest(CONTROL/'consumer_review.py'),'new_adapter_isomorphism_or_integration_qualified':False,'current_functional_and369_295_scope_counts_unchanged':True,'full_E5_A5':'UNQUALIFIED','no_remote_action':True,'commit_controller_sha256':digest(Path(__file__))};assert proof['authority_unchanged']
with(CONTROL/'post_commit.json').open('xb') as f:f.write(json.dumps(proof,sort_keys=True,separators=(',',':')).encode()+b'\n')
print(json.dumps({'HEAD':head,'files':len(paths),'clean':True,'receipt_sha256':proof['receipt_sha256'],'full_E5_A5':'UNQUALIFIED','next_existing_consumer_basis_adapter_required':True}))
