"""Independent exact rational block congruences and actual full-field reality."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import importlib.util,json,sys,time,threading,os
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_canonical';CONTROL=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
def load(n,p):
 sp=importlib.util.spec_from_file_location(n,p);q=importlib.util.module_from_spec(sp);sp.loader.exec_module(q);return q
v=load('independent_canonical_pole_rational_arithmetic',CONTROL.parent/'ghost-mass-g4-pole-v1-2026-10-18/verify.py');read=v.read;digest=v.digest
PARAM={'g3_etaH0_xi2_scalar1':(3,0,2,1),'g4_etaH1_xi1_scalar1':(4,1,1,1),'g4_etaH0_xi2_scalar1':(4,0,2,1),'g4_etaH0_xi0_scalar2':(4,0,0,2)};ANTI=v.ANTI
def coeff(cells):return tuple((m,F(n,d)) for m,n,d in cells)
def encoded(z):return [[m,x.numerator,x.denominator] for m,x in z]
def conjugate(A):return {key:v.conj(z) for key,z in A.items()}
def reality(ref):
 names=ref['field_order'];T={(i,j):v.number(z) for i,j,z in ref['physical_to_raw_kernel']['entries']};I={(i,j):v.number(z) for i,j,z in ref['physical_to_raw_inverse']['entries']};identity={(i,i):v.O for i in range(643)};assert v.mm(T,I)==v.mm(I,T)==identity;R=v.mm(conjugate(I),T);assert v.mm(R,conjugate(R))==identity and v.mm(conjugate(T),R)==T
 assert T!=v.tr(I);return {'complete643_actual_R_involution_and_conjugate_T_R_identity':True,'field_not_source_dual_chart_domains_differ':True}
def fixture():
 T={(0,0):v.O,(0,1):v.II,(1,0):v.O,(1,1):v.neg(v.II)};I={(0,0):v.scale(v.O,F(1,2)),(0,1):v.scale(v.O,F(1,2)),(1,0):v.scale(v.II,F(-1,2)),(1,1):v.scale(v.II,F(1,2))};P={(0,0):v.scale(v.O,2),(0,1):v.O,(1,0):v.scale(v.O,3)};R=v.mm(conjugate(I),T);N=v.mm(v.tr(T),v.mm(P,T));assert v.mm(v.tr(R),v.mm(conjugate(N),R))==N and v.mm(v.tr(I),v.mm(N,I))==P
 assert v.mm(v.tr(R),v.mm(N,R))!=N
 # Explicit scalar polynomial polarization and fixed odd ordering.
 assert (2+3)**2==2**2+2*2*3+3**2 and v.mul(v.II,v.II)==v.neg(v.O)
 def sign(word):
  odd=[n for n in word if n.startswith('C') or n in ANTI]
  return 0 if len(odd)!=len(set(odd)) else(-1)**sum(x>y for i,x in enumerate(odd) for y in odd[i+1:])
 assert sign(('ub12','C0','x_Phi_0'))==-1 and sign(('C0','C0'))==0 and sign(('C0','x_Phi_0','ub12'))==1
 return True
def canonical_word(c,a,ss):
 word=(f'C{c}',ANTI[a],*ss);assert word==tuple(sorted(word)) and len(ss) in (1,2);return word
def compare_and_hash(P,expected):
 assert len(P)==len(expected);h=sha256();h.update(b'[')
 for i,(word,row) in enumerate(zip(sorted(P),expected)):
  assert list(word)==row[0] and P[word]==coeff(row[1])
  if i:h.update(b',')
  h.update(json.dumps([list(word),encoded(P[word])],separators=(',',':')).encode())
 h.update(b']');return h.hexdigest()
def main():
 tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(OUT/'validation_preparation.json');assert digest(Path(__file__))==prep['validator_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allowed={str(Path(p).resolve()) for p in prep['read_json']}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('INDEPENDENT_CANONICAL_SCALAR_TRANSPORT_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_JSON',str(p))
 sys.addaudithook(guard);assert fixture();ref=v.sealed('frozen_a10_e5_full_hessian','primary')['retained_reference'];other=v.sealed('frozen_a10_e5_full_hessian','replay')['retained_reference'];assert all(ref[k]==other[k] for k in ['field_order','physical_to_raw_kernel','physical_to_raw_inverse']);del other;proof=reality(ref);scalar,IL,IA,IC,TL,TA,TC=v.frame(ref);invscalar={x:n for n,x in scalar.items()};assert len(scalar)==len(invscalar)==328
 a=read(OUT/'primary_result.json');b=read(OUT/'replay_result.json');assert a['canonical_parameter_tables']==b['canonical_parameter_tables'] and a['canonical_parameter_hashes']==b['canonical_parameter_hashes'];del b
 parent=ROOT/'calculations/canonical_so10_scalar_ghost_actual_pole';r=read(parent/'validation_receipt.json');assert r['execution_state']=='COMPLETED';q=read(parent/'primary_result.json');other=read(parent/'replay_result.json');assert q['group_physical_poles']['g4_xi0_pair']==other['group_physical_poles']['g4_xi0_pair'];del other;packets=dict(r['coalesced_physical_linear_tables']);packets['g4_etaH0_xi0_scalar2']=q['group_physical_poles']['g4_xi0_pair'];assert set(packets)==set(PARAM);del q
 hashes={};counts={};complexes={};sevens={};perform=[];negative={}
 for label,rows in packets.items():
  start=time.perf_counter();blocks=defaultdict(dict)
  for c,aa,ss,h,w,z in rows:
   value=coeff(z);assert v.conj(value)==value and h==w==0 and len(ss)==PARAM[label][3];blocks[tuple(ss)][c,aa-45]=value
  N={};seen=set()
  for ss,P in blocks.items():
   rawss=tuple(sorted(invscalar[x] for x in ss));assert rawss not in seen;seen.add(rawss);image=v.mm(v.tr(TC),v.mm(P,TA));inverse=v.mm(v.tr(IC),v.mm(image,IA));assert inverse==P
   for(c,aa),z in image.items():word=canonical_word(c,aa,rawss);assert word not in N;N[word]=z
  hh=compare_and_hash(N,a['canonical_parameter_tables'][label]);assert hh==a['canonical_parameter_hashes'][label];hashes[label]=hh;counts[label]=len(N);complexes[label]=sum(v.conj(z)!=z for z in N.values());sevens[label]=sum(any(m&16 for m,z in value) for value in N.values());assert complexes[label]==a['canonical_complex_parameter_positions'][label] and sevens[label]==a['canonical_sqrt7_parameter_positions'][label]
  word=next(iter(N));z=N[word];rc=int(word[0][1:]);ra=ANTI.index(word[1]);delta={(rc,ra):z};assert v.mm(v.tr(IC),v.mm(delta,IA));imag=next((w for w,value in N.items() if v.conj(value)!=value),None);cross=next((w for w in N if len(w)==4 and w[2]!=w[3]),None)
  if imag:
   value=tuple((m,z) for m,z in N[imag] if m&8);assert v.mm(v.tr(IC),v.mm({(int(imag[0][1:]),ANTI.index(imag[1])):value},IA))
  if cross:assert v.mm(v.tr(IC),v.mm({(int(cross[0][1:]),ANTI.index(cross[1])):N[cross]},IA))
  negative[label]={'one_nonzero_omission_sign_and_odd_reversal_change_inverse':True,'discard_imaginary_component_sensitive':imag is not None,'extra_scalar_cross_factor_sensitive':cross is not None};perform.append({'label':label,'seconds':time.perf_counter()-start});print('STAGE independent '+label+' '+str(len(N)),flush=True);del blocks,N
 assert counts==a['canonical_parameter_counts'] and not any(a['all_seven_quantum_flags_false'].values()) and not a['new_loop_canonical_integration_or_Slavnov_identity'] and a['complete_unfiltered_forward_contributions']==4175624 and a['current_known_terms']==155143 and a['sourceimage_positions']==146663
 assert a['all_canonical_coefficients_in_old_four_root_subring']==(not any(sevens.values())) and all(a['full_field_map_and_reality_proof'].values()) and a['all_parameter_packets_complete_inverse_and_implicit_zeros_recovered'] and a['physical_coefficients_real_in_fixed_odd_order'] and a['canonical_word_map_bijective_in_actual_alphabet'] and a['whole_polynomial_reality_by_conjugate_T_R_identity_and_pullback_composition']
 for role in ['primary','replay']:
  cap=read(OUT/(role+'_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['calculation_completed'] and cap['post_run_observations_qualified'] and cap['exit_code']==0
 result={'schema':'CANONICAL_SCALAR_GHOST_COMPLETE_INDEPENDENT_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':'COMPLETE_CANONICAL_SCALAR_GHOST_TRANSPORT_WITH_REALITY_NOT_INTEGRATION','input_sha256':prep['input_sha256'],'full_independent_rational_block_congruences_and_inverse_zero_domains':True,'both_native_full_canonical_tables_and_word_bijections_verified':True,'actual_full643_inverse_R_and_conjugate_T_R_identities_verified':True,'whole_density_reality_by_actual_matrix_identities_and_real_physical_packets':True,'typed_scalar_unit_permutation_and_Bose_powers_verified':True,'both_role_actual_reference_arrays_and_qualified_physical_packets_equal':True,'canonical_parameter_counts':counts,'canonical_parameter_hashes':hashes,'canonical_complex_parameter_positions':complexes,'canonical_sqrt7_parameter_positions':sevens,'old_four_root_consumer_ready':not any(sevens.values()),'consumer_requirement':'Use a separately qualified conservative five-radical consumer if sqrt7 persists;do not truncate or patch sealed four-root code','controls':negative,'independent_packet_performance':perform,'native_worker_failures':0,'independent_worker_failures':0,'fresh_byte_identical_replay_pairs_claimed':0,'new_integration_or_full_E5_A5':'NOT_PERFORMED_UNQUALIFIED','current_functional_and_protected_authority_unchanged':True,'shared_limits':'Measured poles/action/actual reference and canonical parity conventions/prior UV premises,software and AI author shared;separate rational block arithmetic/full inverse and structural reality,not independent physical validation','elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
