"""Index/signature-only integration sizing;no coefficients added or accepted."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import importlib.util,json,time,threading,os,subprocess
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
p=ROOT/'calculations/canonical_so10_ghost_mass_g4_integration/integration.py';s=importlib.util.spec_from_file_location('qualified_current_recipe_index_planning',p);q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
timer=threading.Timer(30,lambda:os._exit(124));timer.daemon=True;timer.start();tick=time.perf_counter();post=read(CONTROL/'post_commit.json');assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==post['HEAD']=='3d62db7bb11af0f66d6078071c3fdbf5aa28ebe3'
folder=ROOT/'calculations/canonical_so10_scalar_ghost_canonical';receipt=read(folder/'validation_receipt.json');assert receipt['execution_state']=='COMPLETED' and digest(folder/'validation_receipt.json')==post['receipt_sha256']=='899b3d9a3aba1357fed9dd14629b62fc8f9501fc6007051023ea8e9de41b66bc';source=folder/'primary_result.json';assert receipt['input_sha256'][str(source)]==digest(source);data=read(source)
patterns={};words=defaultdict(list)
for label,rows in data['canonical_parameter_tables'].items():
 for word,cells in rows:
  pattern=(label,tuple(tuple(v) for v in cells));number=patterns.setdefault(pattern,len(patterns));words[tuple(word)].append(number)
signatures={tuple(sorted(v)) for v in words.values()};tables,previous,recipepath=q.current_tables('primary');oldkeys={tuple(r['word']) for t in tables for r in t};overlap=set(words)&oldkeys
out={'classification':'INDEX_SIGNATURE_ONLY_INTEGRATION_PLANNING_NOT_SCIENTIFIC_EVIDENCE_OR_ALLOWANCE','base_commit':post['HEAD'],'canonical_receipt_sha256':digest(folder/'validation_receipt.json'),'native_packet_sha256':digest(source),'current_recipe_source_sha256':digest(p),'current_recipe_record_path':str(recipepath),'current_recipe_record_sha256':digest(recipepath),'canonical_parameter_positions':sum(map(len,data['canonical_parameter_tables'].values())),'new_distinct_field_word_keys':len(words),'unique_single_parameter_radical_patterns':len(patterns),'unique_combined_parameter_signatures':len(signatures),'existing_recipe_word_union_upper_bound':len(oldkeys),'new_words_also_in_old_recipe_union':len(overlap),'combined_word_union_upper_bound':len(set(words)|oldkeys),'no_coefficient_values_added_or_integration_qualified':True,'old_union_is_not_scientifically_accepted_nonzero_support':True,'seconds':time.perf_counter()-tick}
with(CONTROL/'integration_support_cost_plan.json').open('xb') as f:f.write(json.dumps(out,sort_keys=True,separators=(',',':')).encode()+b'\n')
print(json.dumps(out,sort_keys=True));timer.cancel()
