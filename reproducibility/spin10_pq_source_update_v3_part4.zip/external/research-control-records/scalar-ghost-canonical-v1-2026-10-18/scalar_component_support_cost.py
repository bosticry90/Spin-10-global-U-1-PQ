"""Type/index-only scalar antighost predecessor census for next bounded contract."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
import json,time,threading,os
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
timer=threading.Timer(30,lambda:os._exit(124));timer.daemon=True;timer.start();tick=time.perf_counter()
def auth(folder,name,receipt):
 p=ROOT/'calculations'/folder/name;r=read(p.parent/receipt);assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p),p,p.parent/receipt
op,opfile,opreceipt=auth('canonical_so10_broken_antighost_operator','primary_v2_result.json','validation_v2_receipt.json');src,srcfile,srcreceipt=auth('canonical_so10_local_source_primitive','primary_v2_result.json','validation_receipt.json');rows=src['normalized_source_image'];assert len(rows)==146663
def token(s):
 n,_,jets=s.partition('__');return n,len(jets)
def kind(n):return 'E' if n.startswith('zz_da') else'x' if n.startswith('x_') else'a' if n.startswith('ub') or n.startswith('bar') else'C' if n.startswith('C') else'B' if n.startswith('B') else'A' if n.startswith('A') else'L' if n.startswith('L') or n.startswith('b') else'OTHER'
spec=defaultdict(Counter)
for name,K in op['all33_kernel_maps'].items():
 for r in K:
  fields=[token(n) for n in r['word']];assert r['g'] in [0,1];spec[name][r['g'],tuple(sorted(kind(n) for n,j in fields)),sum(j for n,j in fields)]+=1
indices=set();channels=set();routes=Counter();jets=Counter();position_paths=0
for i,r in enumerate(rows):
 w=[token(n) for n in r['word']];source=[(n,j) for n,j in w if n.startswith('J')];assert len(source)==1;J,j=source[0];rest=tuple(sorted(kind(n) for n,j in w if n!=J));njet=sum(j for n,j in w)
 for(gk,types,kjet),multiplicity in spec.get(J,{}).items():
  both=tuple(sorted(rest+types))
  if both not in [('C','E','x'),('C','E','x','x')]:continue
  degree=len(both)-2
  if njet+kjet>2-degree:continue
  indices.add(i);channels.add(J);routes[r['g']+gk,gk,degree]+=1;jets[njet+kjet]+=1;position_paths+=multiplicity
out={'classification':'TYPE_INDEX_ONLY_COMPONENT_PLANNING_NOT_NEW_POLE_OR_CONSISTENCY_PROOF','base_commit':read(CONTROL/'post_commit.json')['HEAD'],'qualified_source_record_sha256':digest(srcfile),'qualified_source_receipt_sha256':digest(srcreceipt),'qualified_operator_record_sha256':digest(opfile),'qualified_operator_receipt_sha256':digest(opreceipt),'all_source_positions':len(rows),'eligible_source_positions':len(indices),'active_source_channels':len(channels),'type_level_routes_by_totalg_kernelg_scalardegree':[[*k,v] for k,v in sorted(routes.items())],'unfiltered_kernel_source_position_pair_ceiling':position_paths,'eligible_total_jet_counts':dict(jets),'no_coefficient_values_multiplied_or_component_accepted':True,'seconds':time.perf_counter()-tick}
with(CONTROL/'scalar_component_support_cost_plan.json').open('xb') as f:f.write(json.dumps(out,sort_keys=True,separators=(',',':')).encode()+b'\n')
print(json.dumps(out,sort_keys=True));timer.cancel()
