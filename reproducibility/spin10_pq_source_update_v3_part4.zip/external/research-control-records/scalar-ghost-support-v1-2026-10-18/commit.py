from pathlib import Path
from hashlib import sha256
import json,subprocess
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_support';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def git(*args,raw=False):
 z=subprocess.check_output(['git',*args],cwd=ROOT);return z if raw else z.decode('utf-8').strip()
base=read(OUT/'preparation.json')['base_commit'];assert git('rev-parse','HEAD')==base=='3d6a34daad972654e81eec3dd307f25a1e51dd62'
r=read(OUT/'validation_receipt.json');assert r['schema']=='SCALAR_GHOST_SUPPORT_INDEPENDENT_VALIDATION_V1' and r['execution_state']=='COMPLETED' and r['scientific_disposition']=='ALL112_SCALAR_SUPPORT_PARTITION_AND_CURRENT664_LEDGER_QUALIFIED_WITHIN_FROZEN_ENVELOPE'
for k,z in r.items():
 if type(z) is bool:assert z,k
assert r['native_worker_failures']==r['independent_worker_failures']==r['fresh_byte_identical_replay_pairs_claimed']==0 and r['new_loop_full_QAP_E5_A5']=='NOT_PERFORMED_UNQUALIFIED' and len(r['structural_zero_indices'])==34 and len(r['permitted_unreconciled_indices'])==78 and r['complete_scope_count']==291 and r['unreconciled_scope_count']==373 and r['remaining_positive_dimension_profiles']==22 and r['current_known_terms']==155143
assert digest(OUT/'validation_receipt.json')=='aa522234f4b8d38574143dd349320e4c207a8e560dabbf4a38e56b48da2d4b33'
for name in ['preparation.json','validation_preparation.json','validation_receipt.json']:
 for p,h in read(OUT/name)['input_sha256'].items():assert digest(Path(p))==h,(name,p)
for folder in [OUT,CONTROL]:
 for p in folder.glob('*.source.txt'):assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes(),p
for role in ['primary','replay','validation']:
 cap=read(OUT/(role+'_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and cap['private_allocation_limit_bytes']==8*1024**3
 assert(OUT/(role+'_capture.json')).read_bytes()==(CONTROL/(role+'_full_capture.json')).read_bytes() and cap['all_resource_samples'] and all('query_error' not in z and 0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
 result=read(OUT/('validation_receipt.json' if role=='validation' else role+'_result.json'));assert 0<result['elapsed_after_imports']<120
d=read(OUT/'primary_result.json');assert d['structural_zero_indices']==r['structural_zero_indices'] and d['permitted_unreconciled_indices']==r['permitted_unreconciled_indices'] and d['coupling_order_summary']==r['coupling_order_summary'] and not d['insensitive_controls'] and all(d['controls'].values()) and not any(d['all_seven_quantum_flags_false'].values())
assert not d['new_loop_or_color_pole_or_insertion_integral'] and not d['new_full_functional_materialization_or_variation'] and not d['full_QAP_IR_measure_products_contacts_equivalence_sourcefree_Slavnov_E5_A5_proved'] and sum(not q['complete_scope_match'] and q['unbroken_aggregate_only_if_family_unreconciled'] for q in d['all664_updated_scope_rows'])==27
for p in ['AGENTS.md','CHARTER.md','README.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md']:assert git('show',base+':'+p,raw=True)==(ROOT/p).read_bytes(),p
paths=sorted([p.relative_to(ROOT).as_posix() for p in OUT.iterdir() if p.is_file()]+['docs/RESEARCH_EXECUTION_HANDOFF_V277.md']);assert set(git('ls-files','--others','--exclude-standard').splitlines())==set(paths) and not git('diff','--name-only') and not git('diff','--cached','--name-only')
assert digest(OUT/'validation_receipt.json') in(ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V277.md').read_text(encoding='utf-8')
subprocess.check_call(['git','-c','core.autocrlf=false','-c','core.longpaths=true','add','--',*paths],cwd=ROOT);assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
for p in paths:assert git('show',':'+p,raw=True)==(ROOT/p).read_bytes(),p
subprocess.check_call(['git','diff','--cached','--check'],cwd=ROOT);subprocess.check_call(['git','commit','-m','Qualify complete scalar ghost support screen and updated finite coverage'],cwd=ROOT)
head=git('rev-parse','HEAD');assert git('rev-parse','HEAD^')==base and set(git('diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines())==set(paths)
for p in paths:assert git('show','HEAD:'+p,raw=True)==git('show',':'+p,raw=True)==(ROOT/p).read_bytes(),p
assert not git('status','--porcelain=v1')
proof={'HEAD':head,'parent':base,'exact_changed_files':paths,'all_HEAD_index_worktree_bytes_equal':True,'working_tree_clean':True,'receipt_sha256':digest(OUT/'validation_receipt.json'),'authority_unchanged':digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8','all_three_current_input_bindings_match':True,'all112_relaxed_and_refined_profiles_verified':True,'new_structural_zeros':34,'permitted_unknowns':78,'complete664_scopes':291,'unreconciled_scopes':373,'current_functional_unchanged':True,'full_E5_A5':'UNQUALIFIED','no_remote_action':True,'commit_controller_sha256':digest(Path(__file__))};assert proof['authority_unchanged']
with(CONTROL/'post_commit.json').open('xb') as f:f.write(json.dumps(proof,sort_keys=True,separators=(',',':')).encode()+b'\n')
print(json.dumps({'HEAD':head,'files':len(paths),'clean':True,'receipt_sha256':proof['receipt_sha256'],'full_E5_A5':'UNQUALIFIED'}))
