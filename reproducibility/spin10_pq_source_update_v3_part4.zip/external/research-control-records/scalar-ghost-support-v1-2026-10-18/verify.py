from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
from itertools import permutations
from functools import lru_cache
import json,sys,os,time,threading,subprocess
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_support';CONTROL=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from audit_a10_e5_antighost_vector import resource,line_json
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def freeze(z):return tuple(map(freeze,z)) if isinstance(z,list) else z
def auth(folder,name):
 p=ROOT/'calculations'/folder/name;r=read(p.parent/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p)
def suffix_reachable(profile,vertices,edges):
 target=freeze(profile['external_ports']);limit=Counter(target);wanted=frozenset(profile['BB_width_roles']);opt={}
 for tag,vertex in vertices.items():
  z=set()
  for ports in vertex['ports']:
   for left in range(len(ports)):
    for right in range(len(ports)):
     if left==right:continue
     A,B=freeze(ports[left]),freeze(ports[right]);ext=tuple(sorted(freeze(x) for i,x in enumerate(ports) if i not in [left,right]))
     if A[0][0]=='A' or B[0][0]=='A' or Counter(ext)-limit:continue
     z.add((A,B,ext))
  opt[tag]=tuple(z)
 def prop(B,A):return(2 if B[0][0]=='L' else 1)+(2 if A[0][0]=='L' else 1)-4
 def width(B,A):return frozenset([B[0]]) if B[0]==A[0] and B[0][0]=='B' else frozenset()
 for seq in set(permutations(profile['vertex_family'])):
  if any(not opt[t] for t in seq):continue
  for first,last,external in opt[seq[0]]:
   rem=Counter(target)-Counter(external);remaining=tuple(sorted(rem.elements()))
   @lru_cache(None)
   def backwards(k,next_left,remaining,used,degree):
    if k==0:return not remaining and(last[0],next_left[0]) in edges and used|width(last,next_left)==wanted and degree+first[1]+last[1]+prop(last,next_left)+4==0
    for a,b,e in opt[seq[k]]:
     if(b[0],next_left[0]) not in edges or Counter(e)-Counter(remaining):continue
     widths=used|width(b,next_left)
     if not widths<=wanted:continue
     rem=tuple(sorted((Counter(remaining)-Counter(e)).elements()))
     if backwards(k-1,a,rem,widths,degree+a[1]+b[1]+prop(b,next_left)):return True
    return False
   if backwards(len(seq)-1,first,remaining,frozenset(),0):return True
 return False
def check_witness(p,w,V,E):
 assert sorted(t for t,a,b,x in w)==p['vertex_family'];external=[];widths=set();uv=4
 for k,(tag,a,b,x) in enumerate(w):
  a,b,x=freeze(a),freeze(b),freeze(x);assert tuple(sorted((a,b)+x)) in {tuple(sorted(map(freeze,whole))) for whole in V[tag]['ports']};external.extend(x);nexta=freeze(w[(k+1)%len(w)][1]);assert(b[0],nexta[0]) in E;uv+=a[1]+b[1]+(2 if b[0][0]=='L' else 1)+(2 if nexta[0][0]=='L' else 1)-4
  if b[0]==nexta[0] and b[0][0]=='B':widths.add(b[0])
 assert sorted(external)==list(map(freeze,p['external_ports'])) and sorted(widths)==p['BB_width_roles'] and uv==0
def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(OUT/'validation_preparation.json')
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 assert digest(Path(__file__))==prep['validator_sha256'] and subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==prep['base_commit'];allowed={str(Path(p).resolve()) for p in prep['input_sha256']}|{str((OUT/'validation_preparation.json').resolve())}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('SCALAR_GHOST_VERIFIER_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_JSON',str(p))
 sys.addaudithook(guard);results={};perf={}
 for role in ['primary','replay']:
  cap=read(OUT/(role+'_capture.json'));resource(cap);d=read(OUT/(role+'_result.json'));assert d==line_json(cap['stdout_and_stderr'],'RESULT ') and(OUT/(role+'_capture.json')).read_bytes()==(CONTROL/(role+'_full_capture.json')).read_bytes();results[role]=d;perf[role]={'seconds':d['elapsed_after_imports'],'private_bytes':max(a['private_bytes'] for a in cap['all_resource_samples'])}
 for key in set(results['primary'])-{'route','elapsed_after_imports','profiles'}:assert results['primary'][key]==results['replay'][key],key
 d=results['primary'];inv=auth('canonical_so10_sourcefree_cycle_inventory','primary_v2_result.json');prior=auth('canonical_so10_ghost_mass_g4_reduction','primary_v2_result.json');quart=auth('canonical_so10_fourghost_g4_reduction','primary_v3_result.json');pole=auth('canonical_so10_ghost_mass_g4_pole','primary_v2_result.json');current=auth('canonical_so10_ghost_mass_g4_integration','primary_result.json');ledger={r['index']:dict(r) for r in prior['all664_updated_scope_rows']};actual={i:r for i,r in enumerate(inv['all_profiles']) if any(n.startswith('a') for n,j in r['external_ports'])};assert set(actual)==set(ledger) and len(ledger)==664
 for i,r in actual.items():assert ledger[i]['descriptor']=={k:v for k,v in r.items() if k!='witness'}
 assert len(pole['new_actual_g4_ghost_mass_node'])==33 and current['updated_known_terms']==d['current_known_terms']==155143 and current['updated_known_sha256']==d['current_known_sha256']=='fe6bd8e800d8e04f9d0358ce94c081d70e94af0ffd37830bb50c02fdbb0c0241'
 for i in [2024,2026,2027]:assert not ledger[i]['complete_scope_match'];ledger[i]['complete_scope_match']='V275_COMPLETE_INTRINSIC_MASS_COHORT';ledger[i]['interpretation']='MEASURED_THREE_FAMILY_COHORT_NOT_INDIVIDUAL_NONZERO';ledger[i]['unbroken_aggregate_only_if_family_unreconciled']=False
 chosen={i:r for i,r in actual.items() if not ledger[i]['complete_scope_match'] and ledger[i]['types'] in [['C','a','x'],['C','a','x','x']]};assert len(chosen)==112 and sum(ledger[i]['coefficient_dimension']==1 for i in chosen)==32
 orbit=defaultdict(set)
 for tag,rows in prior['all_literal_orbit_rows_stripped_only_g_and_explicit_xi'].items():
  for r in rows:
   word=[]
   for name in r['word']:
    if name.startswith('x_'):word.append(('X_'+name.split('_')[1],0))
    else:
     prefix='a' if name.startswith('ub') else name[0];index=int(name[2:] if prefix=='a' else name[1:]);word.append((prefix+('H' if index<12 else 'M'),0))
   orbit[tag].add(tuple(sorted(word)))
 refine={'D':quart['actual_exported_port_sets']['D'],'F':quart['actual_exported_port_sets']['F'],'O_LX':sorted(orbit['M']),'O_aCX':sorted(orbit['Y'])};assert freeze(refine['O_LX'])==freeze(d['refined_port_sets']['O_LX']) and freeze(refine['O_aCX'])==freeze(d['refined_port_sets']['O_aCX']) and refine['D']==d['refined_port_sets']['D'] and refine['F']==d['refined_port_sets']['F'];V=inv['actual_sourcefree_vertices'];R={t:{**r,'ports':refine.get(r['base'],r['ports'])} for t,r in V.items()};E={tuple(e) for e in inv['actual_reference_edges']};noscalar={e for e in E if not any(n.startswith('X_') for n in e)};zeros=[];live=[];scalar_sensitive=False
 print('STAGE independent_all112_backward_suffix_reachability_and_native_witnesses',flush=True)
 for i,p in sorted(chosen.items()):
  assert not p['scalar_reference_mass_expansions'] and p['total_external_jets']==0 and suffix_reachable(p,V,E),('RELAXED',i);okay=suffix_reachable(p,R,E);plain=suffix_reachable(p,R,noscalar);scalar_sensitive|=okay!=plain;(live if okay else zeros).append(i)
  for role,a in results.items():
   z=next(r for r in a['profiles'] if r['index']==i);assert z['descriptor']=={k:v for k,v in p.items() if k!='witness'} and z['actual_port_supported']==okay and z['supported_without_scalar_reference_edges']==plain
   if okay:check_witness(p,z['actual_port_witness'],R,E)
   else:assert z['actual_port_witness'] is None
 assert zeros==d['structural_zero_indices'] and live==d['permitted_unreconciled_indices'] and len(zeros)==34 and len(live)==78
 for i in zeros:ledger[i]['complete_scope_match']='THIS_COMPLETE_REFINED_ENVELOPE_NO_PATH';ledger[i]['interpretation']='INDIVIDUAL_STRUCTURAL_ZERO_IN_CONSERVATIVE_PORT_ENVELOPE';ledger[i]['unbroken_aggregate_only_if_family_unreconciled']=False
 assert [ledger[i] for i in sorted(ledger)]==d['all664_updated_scope_rows'];summary=[{'g':g,'total':sum(r['g']==g for r in ledger.values()),'complete_scopes':sum(r['g']==g and bool(r['complete_scope_match']) for r in ledger.values()),'unreconciled':sum(r['g']==g and not r['complete_scope_match'] for r in ledger.values())} for g in range(1,5)];assert summary==d['coupling_order_summary'];groups=defaultdict(list)
 for r in ledger.values():
  if not r['complete_scope_match']:assert r['jets']==0;groups[tuple(r['types']),r['g'],r['coefficient_dimension']].append(r['index'])
 classes=[{'types':list(ty),'g':g,'coefficient_dimension':cd,'indices':sorted(ids)} for(ty,g,cd),ids in sorted(groups.items())];assert classes==d['remaining_classes'];controls={'restore_relaxed_ports_restores_some_excluded_profiles':bool(zeros),'omit32_dimensionful_profiles_loses_coverage':sum(ledger[i]['coefficient_dimension']==1 for i in chosen)==32,'remove_scalar_edges_changes_live_support':scalar_sensitive,'promote_unbroken_aggregate_would_false_close_individual_scopes':any(not r['complete_scope_match'] and r['unbroken_aggregate_only_if_family_unreconciled'] for r in ledger.values())};assert controls==d['controls'] and all(controls.values()) and not d['insensitive_controls'] and not d['new_loop_or_color_pole_or_insertion_integral'] and not d['new_full_functional_materialization_or_variation'] and not d['full_QAP_IR_measure_products_contacts_equivalence_sourcefree_Slavnov_E5_A5_proved'] and not any(d['all_seven_quantum_flags_false'].values())
 result={'schema':'SCALAR_GHOST_SUPPORT_INDEPENDENT_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':'ALL112_SCALAR_SUPPORT_PARTITION_AND_CURRENT664_LEDGER_QUALIFIED_WITHIN_FROZEN_ENVELOPE','all112_relaxed_refined_and_scalar_edge_controls_independently_checked':True,'all_native_live_witnesses_and_no_path_complements_checked':True,'all664_descriptors_mass_cohort_and_no_false_collective_promotion_checked':True,'all_coeff_dim_jets_width_roles_and_ordered_reference_edges_checked':True,'all_current_frozen_input_hashes_and_sources_unchanged':True,'structural_zero_indices':zeros,'permitted_unreconciled_indices':live,'coupling_order_summary':summary,'complete_scope_count':sum(bool(r['complete_scope_match']) for r in ledger.values()),'unreconciled_scope_count':sum(not r['complete_scope_match'] for r in ledger.values()),'remaining_positive_dimension_profiles':sum(not r['complete_scope_match'] and r['coefficient_dimension']>0 for r in ledger.values()),'current_known_terms':155143,'current_known_sha256':d['current_known_sha256'],'native_worker_failures':0,'independent_worker_failures':0,'fresh_byte_identical_replay_pairs_claimed':0,'new_loop_full_QAP_E5_A5':'NOT_PERFORMED_UNQUALIFIED','performance':perf,'input_sha256':prep['input_sha256'],'shared_limits':'Shared catalogue and qualified ports;DF and orbit refined,other vertices remain conservative inherited envelope. Backward transfer reachability differs from native prefix methods;not actual live coefficients or external scientific validation','elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
