from pathlib import Path
from hashlib import sha256
import json,sys,ast,importlib.util,symtable,builtins
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_support';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
p=read(OUT/'preparation.json');files={Path(f) for f in p['input_sha256']}|{OUT/'preparation.json',OUT/'RESULT.md'}
for f,h in p['input_sha256'].items():assert digest(Path(f))==h,f
for role in['primary','replay']:
 for f in[OUT/(role+'_result.json'),OUT/(role+'_capture.json'),CONTROL/(role+'_full_capture.json')]:files.add(f)
 cap=read(OUT/(role+'_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and(OUT/(role+'_capture.json')).read_bytes()==(CONTROL/(role+'_full_capture.json')).read_bytes()
for f in[CONTROL/'verify.py',CONTROL/'run_validation.py',Path(__file__)]:
 ast.parse(f.read_text(encoding='utf-8'));copy=Path(str(f)+'.source.txt')
 with copy.open('xb') as stream:stream.write(f.read_bytes())
 files.update([f,copy])
tree=symtable.symtable((CONTROL/'verify.py').read_text(encoding='utf-8'),'verify.py','exec');defined={z.get_name() for z in tree.get_symbols() if z.is_assigned() or z.is_imported() or z.is_namespace()}|set(dir(builtins))|{'__file__','__name__','__package__'};errors=[]
def scan(t):
 for z in t.get_symbols():
  if z.is_referenced() and z.is_global() and z.get_name() not in defined:errors.append([t.get_name(),t.get_lineno(),z.get_name()])
 for child in t.get_children():scan(child)
scan(tree);assert not errors,errors
z=importlib.util.spec_from_file_location('independent_scalar_ghost_support_imports',CONTROL/'verify.py');u=importlib.util.module_from_spec(z);z.loader.exec_module(u)
for mod in list(sys.modules.values()):
 fn=getattr(mod,'__file__',None)
 if fn:
  f=Path(fn).resolve()
  if f.suffix=='.py' and(f.is_relative_to(ROOT) or f.is_relative_to(CONTROL.parent)):files.add(f)
d={'schema':'SCALAR_GHOST_SUPPORT_VALIDATION_PREPARATION_V1','base_commit':p['base_commit'],'validator_sha256':digest(CONTROL/'verify.py'),'controller_sha256':digest(CONTROL/'run_validation.py'),'input_sha256':{str(f):digest(f) for f in sorted(files)},'limits':p['limits'],'undefined_global_static_preflight_errors':errors,'all_source_copies_exclusive':True,'completed_native_workers':2,'failed_native_workers':0}
with(OUT/'validation_preparation.json').open('xb') as f:f.write(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('FROZEN independent',len(files))
