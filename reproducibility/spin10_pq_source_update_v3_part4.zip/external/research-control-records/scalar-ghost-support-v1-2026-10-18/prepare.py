from pathlib import Path
from hashlib import sha256
import json,ast,symtable,builtins,subprocess
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_support';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='3d6a34daad972654e81eec3dd307f25a1e51dd62'
parent=ROOT/'calculations/canonical_so10_ghost_mass_g4_integration/validation_receipt.json';r=read(parent);assert r['execution_state']=='COMPLETED' and digest(parent)=='32f22574beda4023e2583342027bae903c4d2b3c9e6f59baeb9e7626acd1ef43'
files={Path(p) for p in r['input_sha256']}|{parent,OUT/'RECORD.md',ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V276.md'}
for p,h in r['input_sha256'].items():assert digest(Path(p))==h,p
paths={};probes=[]
for role in ['primary','replay']:
 paths[role]={OUT/'preparation.json'}
 for folder,name in [('canonical_so10_ghost_mass_g4_reduction',role+'_v2_result.json'),('canonical_so10_sourcefree_cycle_inventory',role+'_v2_result.json'),('canonical_so10_fourghost_g4_reduction',role+'_v3_result.json'),('canonical_so10_ghost_mass_g4_pole',role+'_v2_result.json'),('canonical_so10_ghost_mass_g4_integration',role+'_result.json')]:
  p=ROOT/'calculations'/folder/name;rr=p.parent/'validation_receipt.json';rc=read(rr);assert rc['execution_state']=='COMPLETED' and rc['input_sha256'][str(p)]==digest(p);data=read(p);paths[role].update([p,rr]);files.update([p,rr]);probes.append({'path':str(p),'receipt':str(rr),'sha256':digest(p)})
  if folder=='canonical_so10_fourghost_g4_reduction':assert set(data['actual_exported_port_sets'])>={'D','F'}
  if folder=='canonical_so10_ghost_mass_g4_reduction':assert len(data['all664_updated_scope_rows'])==664 and sum(not a['complete_scope_match'] and a['types'] in [['C','a','x'],['C','a','x','x']] for a in data['all664_updated_scope_rows'])==112
for p in [OUT/'support.py',CONTROL/'run.py',Path(__file__)]:
 text=p.read_text(encoding='utf-8');ast.parse(text);st=symtable.symtable(text,str(p),'exec');defs={x.get_name() for x in st.get_symbols() if x.is_assigned() or x.is_imported() or x.is_namespace()}|set(dir(builtins))|{'__file__','__name__','__package__'};bad=[]
 def scan(t):
  for x in t.get_symbols():
   if x.is_referenced() and x.is_global() and x.get_name() not in defs:bad.append((t.get_name(),x.get_name()))
  for q in t.get_children():scan(q)
 scan(st);assert not bad,bad
 copy=Path(str(p)+'.source.txt')
 with copy.open('xb') as f:f.write(p.read_bytes())
 files.update([p,copy])
d={'schema':'SCALAR_GHOST_SUPPORT_PREPARATION_V1','base_commit':head,'source_sha256':digest(OUT/'support.py'),'controller_sha256':digest(CONTROL/'run.py'),'input_sha256':{str(p):digest(p) for p in sorted(files)},'read_json_by_role':{role:[str(p) for p in sorted(pp)] for role,pp in paths.items()},'qualified_input_probes':probes,'limits':{'seconds_after_imports':120,'private_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2},'all_source_copies_exclusive':True,'actual_role_receipt_and_structure_preflight_complete':True}
with(OUT/'preparation.json').open('xb') as f:f.write(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('FROZEN',len(files),'probes',len(probes))
