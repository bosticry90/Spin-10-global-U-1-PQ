from pathlib import Path
from hashlib import sha256
import json,ast,subprocess
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_scalar_H_ghost_head';C=Path(__file__).resolve().parent;P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();base='99340e0a82218f8476952008c1f591fcbb7d38fc'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==base and not subprocess.check_output(['git','diff','--name-only'],cwd=R)
for p in [O/'test.py',O/'RECORD.md',O/'DERIVATION.md',Path(__file__),C/'run.py']:
 p.write_bytes((chr(10).join(z.rstrip() for z in p.read_text().splitlines()).rstrip()+chr(10)).encode())
 with p.with_name(p.name+'.source.txt').open('xb') as f:f.write(p.read_bytes())
for p in [O/'test.py',Path(__file__),C/'run.py']:ast.parse(p.read_text())
assert "prep=read(O/'preparation.json')" in (O/'test.py').read_text()
for name in ['prepare.py','run.py']:
 with(O/(name+'.source.txt')).open('xb') as f:f.write((C/name).read_bytes())
prior=C.parent/'coupling-background-noether-v1-2026-10-19';question=prior/'next_scalar_H_ghost_head_question.json';q=read(question);inputs=[question,prior/'post_commit.json',Path(__file__),C/'run.py',O/'RECORD.md',O/'DERIVATION.md']
for raw,h in q['input_sha256'].items():assert digest(Path(raw))==h,raw;inputs.append(Path(raw))
for rel in ['CHARTER.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','tools/portable_dh_v1/inputs.json.gz','tools/portable_dh_v1/exact_algebra.py']:inputs.append(R/rel)
arts={r:{} for r in ['primary','replay']};allowed={r:[str(O/'preparation.json')] for r in arts}
for label,folder in [('physical','frozen_a10_physical_reconciliation'),('e3','frozen_a10_e3_symmetry'),('ref','frozen_a10_e5_full_hessian')]:
 d=P/folder;rc=d/'validation_receipt.json';rv=read(rc);inputs.append(rc)
 if label=='ref':bv=rv['new_sha256']
 else:
  bp=d/'bindings.json';inputs.append(bp);bv=read(bp)['byte_sha256'];assert bv[rc.relative_to(R).as_posix()]==digest(rc)
 for role in arts:
  fp=d/(('full_' if label=='physical' else '')+role+'.json');assert bv[fp.relative_to(R).as_posix()]==digest(fp);inputs.append(fp);allowed[role].append(str(fp));arts[role][label]={'path':str(fp),'sha256':digest(fp),'receipt':str(rc),'receipt_sha256':digest(rc)}
for label,name,leaf in [('cbn','canonical_so10_coupling_background_noether','_v2_result.json'),('pqn','canonical_so10_pq_normalization_span','_result.json')]:
 d=R/'calculations'/name;rc=d/'validation_receipt.json';rv=read(rc);assert rv['execution_state']=='COMPLETED';inputs.append(rc)
 for role in arts:
  fp=d/(role+leaf);assert rv['input_sha256'][str(fp)]==digest(fp);inputs.append(fp);allowed[role].append(str(fp));arts[role][label]={'path':str(fp),'sha256':digest(fp),'receipt':str(rc),'receipt_sha256':digest(rc)}
fp=P/'frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json';inputs.append(fp)
for role in arts:allowed[role].append(str(fp));arts[role]['action']={'path':str(fp),'sha256':digest(fp)}
for name in ['canonical_so10_onesource_primitive_probe','canonical_so10_sourcequadratic_primitive_probe','canonical_so10_pq_normalization_span','canonical_so10_coupling_background_noether']:
 d=R/'calculations'/name
 for n in ['RESULT.md','DERIVATION.md','SCOPE_SUPPLEMENT.md','validation_receipt.json']:
  if(d/n).exists():inputs.append(d/n)
v={'schema':'SCALAR_H_GHOST_HEAD_PREPARATION_V1','base':base,'source_sha256':digest(O/'test.py'),'controller_sha256':digest(C/'run.py'),'input_sha256':{str(p):digest(p) for p in sorted(set(inputs))},'artifacts':arts,'read_json_by_role':allowed,'limits':{'native_after_imports_seconds':120,'verifier_after_imports_seconds':180,'sampled_private_bytes':8*2**30,'package_bytes':8*2**20},'scope':'Necessary leading H-ghost affine scalar-head constraint in fixed polynomial W6 target;actual compact module and full invariant projection,not E5/A5 or positive-g basic lifting.'}
with(O/'preparation.json').open('xb') as f:f.write((json.dumps(v,sort_keys=True,indent=2)+chr(10)).encode())
print('FROZEN',len(v['input_sha256']),v['source_sha256'])
