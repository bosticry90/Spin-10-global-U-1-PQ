"""Independent homogeneous-coordinate and compact projection validation SHG1."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations,combinations_with_replacement,product
import json,gzip,sys,os,time,threading
import sympy as s
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_scalar_H_ghost_head'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
vp=read(O/'validation_preparation.json')
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h,raw
def guard(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('SHG_VERIFY_WRITE')
sys.addaudithook(guard);prep=read(O/'preparation_v2.json');a=read(O/'primary_v2_result.json');b=read(O/'replay_v2_result.json')
assert {k:v for k,v in a.items() if k not in ['route','elapsed_after_imports']}=={k:v for k,v in b.items() if k not in ['route','elapsed_after_imports']}
for role in ['primary','replay']:
 cap=read(O/(role+'_v2_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0
 for v in prep['artifacts'][role].values():
  assert digest(Path(v['path']))==v['sha256']
  if 'receipt' in v:assert digest(Path(v['receipt']))==v['receipt_sha256']
get=lambda label:read(Path(prep['artifacts']['replay'][label]['path']))
def mat(p):return s.MutableSparseMatrix(*p['shape'],{(i,j):s.sympify(z) for i,j,z in p['entries']})
def nz(m):return {k:s.expand(v) for k,v in m.todok().items() if s.expand(v)!=0}
def clean(m):return not nz(m)
def decode(p,shape):
 out={}
 for *ij,cells in p['entries']:
  z=0
  for x,h,mask,num,den in cells:
   assert x==h==0
   w=s.Rational(num,den)
   for bit,prime in enumerate([2,3,5,7,-1]):
    if mask&(1<<bit):w*=s.sqrt(prime)
   z+=w
  out[tuple(ij)]=s.expand(z)
 return s.MutableSparseMatrix(*shape,out)
phys=get('physical');dims=a['scalar_dimensions'];rho={sec:[mat(p) for p in phys['representation_matrices'][sec]] for sec in dims}
print('STAGE verifier actual_sparse_module_and_projection',flush=True)
for sec,n in dims.items():
 assert len(rho[sec])==45
 for m in rho[sec]:assert clean(m+m.T) and all(not v.has(s.I) for v in m.values())
basis=[]
for row in a['invariant_affine_basis']:
 sec=row['sector'];n=dims[sec];B=decode(row['basis'],(n,n if row['kind']=='linear' else 1));norm=s.Rational(row['norm_squared'])
 assert s.trace(B.T*B)==norm
 for M in rho[sec]:
  assert clean(M*B-B*M) if row['kind']=='linear' else clean(M*B)
  if row['kind']=='linear':assert s.trace(B.T*M)==0
 basis.append((row,B,norm))
for i,(r,B,n) in enumerate(basis):
 for j,(rr,C,nn) in enumerate(basis):
  if r['sector']==rr['sector'] and r['kind']==rr['kind']:assert s.trace(B.T*C)==(n if i==j else 0)
def P(sec,kind,M):
 out=s.zeros(*M.shape)
 for r,B,n in basis:
  if r['sector']==sec and r['kind']==kind:out+=B*s.trace(B.T*M)/n
 return out
for r,B,n in basis:assert P(r['sector'],r['kind'],B)==B
for tau in [s.Matrix([1,0]),s.Matrix([0,1])]:
 assert P('S','translation',tau)==tau and tau!=s.zeros(2,1)
 assert s.zeros(2,1)!=P('S','translation',tau) # an omitted translation projector fails
phase=s.Matrix([[0,-1],[1,0]]);assert P('S','linear',phase)==phase and all(not m for m in [nz(q) for q in rho['S']])
old=get('pqn');assert old['actual_representation_endomorphism_real_dimensions']==[1,2,4,4]
# Different bracket certificate:choose the last available third index.
pairs=list(combinations(range(10),2));ix={p:i for i,p in enumerate(pairs)};root=1/s.sqrt(2)
def plane(i,j):return s.MutableSparseMatrix(10,10,{(i,j):root,(j,i):-root})
newcert=[]
for c,(i,j) in enumerate(pairs):
 k=next(z for z in reversed(range(10)) if z not in [i,j]);aa=ix[tuple(sorted([i,k]))];bb=ix[tuple(sorted([k,j]))];sg=(1 if i<k else -1)*(1 if k<j else -1)
 assert clean(plane(i,k)*plane(k,j)-plane(k,j)*plane(i,k)-root*plane(i,j))
 for sec in dims:assert clean(sg*(rho[sec][aa]*rho[sec][bb]-rho[sec][bb]*rho[sec][aa])-root*rho[sec][c]),(sec,c)
 newcert.append([c,aa,bb,sg])
assert len(newcert)==45 and len(basis)==13 and s.SparseMatrix.eye(45*13).rank()==585
mz=decode(a['controls']['H_only_invariant_phi_matrix'],(20,20));Q=mat(phys['C3_plane_to_parent'])
for h in range(12):
 Mh=s.zeros(20)
 for i in range(45):
  if Q[i,h]!=0:Mh+=Q[i,h]*rho['phi'][i]
 assert clean(Mh*mz-mz*Mh)
assert clean(P('phi','linear',mz)) and any(not clean(M*mz-mz*M) for M in rho['phi'])
print('STAGE verifier actual_ghost_sign_and_scalar_source_types',flush=True)
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));g=s.symbols('g10');f={}
for c in range(45):
 for row in data['master_field_maps'][f'C{c}']:
  i,j=[int(t[1:]) for t in row['word']];z=-s.expand(s.sympify(row['coefficient'])).coeff(g,1);f[c,i,j]=z;f[c,j,i]=-z
mixed=[[c,h,b,str(s.simplify(f.get((c,h,b),0)))] for c in range(45) for h in range(12) for b in range(45) if f.get((c,h,b),0)!=0]
assert mixed==get('cbn')['mixed_H_tensor']
src={'JB':(2,-1,1,1),'Jx':(2,-1,1,0),'JC':(2,-2,0,0)};ft={'A':(1,0,0,1),'B':(1,0,0,1),'x':(1,0,0,0),'C':(1,1,1,0)};types=[]
for ns in [1,2]:
 for ss in combinations_with_replacement(sorted(src),ns):
  for nf in range(3):
   for ff in combinations_with_replacement(sorted(ft),nf):
    ww=sorted(ss+ff);d,gh,p,v=[sum(src[t][i] for t in ss)+sum(ft[t][i] for t in ff) for i in range(4)]
    if d>4 or gh!=0 or p%2:continue
    for nd in range(5-d):
     if v+nd not in [0,2,4]:continue
     for jj in product(range(nd+1),repeat=len(ww)):
      if sum(jj)==nd:types.append([ww,list(jj),4-d-nd])
assert sorted(types)==get('cbn')['minimal_source_patterns']
assert [z for z in sorted(types) if 'Jx' in z[0]]==[[['C','Jx'],[0,0],1],[['C','Jx','x'],[0,0,0],0]]
# This source coefficient cannot receive an ordinary-source-free Q image.
# Actual q0 x=q0 C=0,verified before matching the first coupling coefficient.
for sec,n in dims.items():
 for i in range(n):
  for row in data['master_field_maps'][f'x_{sec}_{i}']:assert s.expand(s.sympify(row['coefficient'])).subs(g,0)==0
for c in range(45):
 for row in data['master_field_maps'][f'C{c}']:assert s.expand(s.sympify(row['coefficient'])).subs(g,0)==0
print('STAGE verifier homogeneous_affine_cocycle_and_skew_adjoint_projection_proof',flush=True)
# Homogeneous coordinates treat translations without omitting them.
n=2;Ph=s.Matrix(2,2,s.symbols('p0:4'));Pb=s.Matrix(2,2,s.symbols('p4:8'));Pc=s.Matrix(2,2,s.symbols('p8:12'))
Uh=s.Matrix(2,2,s.symbols('u0:4'));Ub=s.Matrix(2,2,s.symbols('u4:8'));Uc=s.Matrix(2,2,s.symbols('u8:12'))
vh=s.Matrix(s.symbols('v0:2'));vb=s.Matrix(s.symbols('v2:4'));vc=s.Matrix(s.symbols('v4:6'))
def affine(U,v):return U.row_join(v).col_join(s.zeros(1,3))
Ah,Ab,Ac=[affine(p,s.zeros(2,1)) for p in [Ph,Pb,Pc]];Bh,Bb,Bc=[affine(u,v) for u,v in [(Uh,vh),(Ub,vb),(Uc,vc)]]
ff,tt=s.symbols('f t');br=lambda A,B:A*B-B*A
N=br(Ah,Bb)-br(Ab,Bh)-ff*Bc+tt*Ac;Cov=br(Ah,Bb)-ff*Bc
assert clean(N-Cov+br(Ab,Bh)-tt*Ac)
# Pairing proof for all matrix sizes by cyclic trace;this free symbolic n=3
# expansion independently checks the identity's signs,not its size generality.
k0,k1,k2=s.symbols('k0:3');K=s.Matrix([[0,k0,k1],[-k0,0,k2],[-k1,-k2,0]]);U=s.Matrix(3,3,s.symbols('a0:9'));B=s.Matrix(3,3,s.symbols('b0:9'));u=s.Matrix(s.symbols('r0:3'));v=s.Matrix(s.symbols('r3:6'))
assert s.expand(s.trace(B.T*br(K,U))+s.trace(br(K,B).T*U))==0
assert s.expand((v.T*K*u+(K*v).T*u)[0])==0
# Each invariant projector coefficient of L vanishes;full cocycle then has
# f_ab^c P(r_c)=0. The45 bracket-span rows and13 independent basis directions
# give independent nonzero numerical pivots and force P(r_c)=0.
assert clean(N-Cov+br(Ab,Bh)-tt*Ac)
wrong=N-Cov-br(Ab,Bh)-tt*Ac;assert not clean(wrong)
X=s.Matrix(s.symbols('x0:2')).col_join(s.ones(1,1));assert clean(Ah*X-(Ph*s.Matrix(s.symbols('x0:2'))).col_join(s.zeros(1,1)))
# At g0 alone q0x=q0C=0 gives no affine correction constraint.
assert s.diff(g, g)==1 and (g*br(Ab,Bh)).subs(g,0)==s.zeros(3)
noncompact=s.Matrix([[0,1],[0,0]]);assert s.diag(1,0)*noncompact*s.Matrix([0,1])==s.Matrix([1,0])
# One-dimensional abelian gauge algebra:all brackets/actions zero,so a
# singlet translation is an allowed invariant cocycle despite being nonzero.
assert clean(s.zeros(2)*s.Matrix([1,0])) and s.Matrix([1,0])!=s.zeros(2,1)
fail=read(O/'primary_capture.json');assert fail['execution_state']=='FAILED' and "'tuple' object has no attribute 'items'" in fail['stdout_and_stderr']
out={'execution_state':'COMPLETED','input_sha256':vp['input_sha256'],'schema':'SCALAR_H_GHOST_HEAD_INDEPENDENT_V1','scientific_disposition':'QUALIFIED_NECESSARY_LEADING_H_GHOST_AFFINE_SCALAR_HEAD_VANISHING','actual_basis_dimension':13,'linear_dimension':11,'translation_dimension':2,'independent_plane_bracket_certificate':newcert,'projected_pivots':585,'independent_source_type_and_ghost_sign_check':True,'homogeneous_affine_and_trace_pairing_proofs_checked':True,'all_controls_sensitive_with_declared_g0_only_insensitivity':True,'Schur_completeness_and_full_action_representation_closure_reused_not_freshly_proved':True,'native_failures_preserved':1,'authority_changed':False,'E5_A5_or_positive_g_basic_lifting_qualified':False,'elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
