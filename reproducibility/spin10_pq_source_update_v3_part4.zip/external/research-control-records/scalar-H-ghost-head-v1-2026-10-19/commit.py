from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_scalar_H_ghost_head';C=Path(__file__).resolve().parent;H=R/'docs/RESEARCH_EXECUTION_HANDOFF_V342.md'
digest=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def dump(p,v):
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
base='99340e0a82218f8476952008c1f591fcbb7d38fc';assert git('rev-parse','HEAD').decode().strip()==base and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
vp=read(O/'validation_preparation.json');rc=read(O/'validation_receipt.json');assert rc['execution_state']=='COMPLETED' and rc['scientific_disposition'].startswith('QUALIFIED_NECESSARY_LEADING_H_GHOST_AFFINE_SCALAR_HEAD')
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h,raw
assert digest(O/'validation_receipt.json')=='20001de64d8583d1327d2ed376a447e4b70bb26b6eb85b0f3a3a17616888430c'
for role in ['primary','replay']:
 cap=read(O/(role+'_v2_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0
assert read(O/'validation_capture.json')['execution_state']=='COMPLETED'
for label in ['primary']:
 cap=read(O/(label+'_capture.json'));assert cap['execution_state']=='FAILED' and cap['exit_code']==1
state='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';assert digest(R/'project_state.json')==state
prior=read(C.parent/'coupling-background-noether-v1-2026-10-19/post_commit.json');assert prior['HEAD']==base
for raw,h in prior['files'].items():assert digest(R/raw)==h,raw
assert prior['historical_custody_exit']==2 and prior['unresolved_references']==7
files=sorted([p for p in O.iterdir() if p.is_file()]+[H]);assert all(not p.is_dir() for p in O.iterdir())
assert sum(p.stat().st_size for p in files)<8*2**20
for p in files:assert b'\r' not in p.read_bytes(),('NEW_FILE_NOT_LF',str(p))
paths=[p.relative_to(R).as_posix() for p in files]
untracked=git('ls-files','--others','--exclude-standard').decode().splitlines();assert set(untracked)==set(paths),set(untracked)^set(paths)
pre={'schema':'SCALAR_H_GHOST_HEAD_PRECOMMIT_V1','base':base,'files':{str(p.relative_to(R).as_posix()):digest(p) for p in files},'validation_receipt_sha256':digest(O/'validation_receipt.json'),'state_sha256':state,'parent_post_commit_sha256':digest(C.parent/'coupling-background-noether-v1-2026-10-19/post_commit.json'),'older_tracked_changes':[],'old_broad_audit_reused':True,'fresh_large_audit_or_old_loops_rerun':False,'historical_custody_exit':2,'unresolved_references':7}
dump(C/'pre_commit.json',pre)
subprocess.run(['git','add','--',*paths],cwd=R,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert set(git('diff','--cached','--name-only').decode().splitlines())==set(paths)
for rel,h in pre['files'].items():assert sha256(git('show',':'+rel)).hexdigest()==h,('INDEX_RAW_DIFFERENCE',rel)
cp=subprocess.run(['git','commit','-m','Qualify leading H-ghost scalar counterterm constraint'],cwd=R,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
dump(C/'commit_capture.json',{'exit_code':cp.returncode,'output':cp.stdout});assert cp.returncode==0,cp.stdout
head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()==base
for rel,h in pre['files'].items():assert digest(R/rel)==h and sha256(git('show','HEAD:'+rel)).hexdigest()==h,rel
changes=git('diff','--name-status',base,head).decode().splitlines();assert len(changes)==len(paths) and all(line.startswith('A\t') and line[2:] in paths for line in changes)
assert not git('status','--porcelain') and digest(R/'project_state.json')==state
post={'schema':'SCALAR_H_GHOST_HEAD_POST_COMMIT_V1','HEAD':head,'parent':base,'branch':'main','clean':True,'files':pre['files'],'receipt_sha256':pre['validation_receipt_sha256'],'state_sha256':state,'all_older_tracked_Git_blobs_unchanged':True,'all78_frozen_validation_inputs_unchanged':True,'necessary_leading_H_ghost_affine_scalar_head_vanishing_qualified':True,'universal_minimal_quotient_E5_A5_or_physical_equivalence_qualified':False,'failed_native_workers_preserved':1,'failed_verifier_workers':0,'historical_custody_exit':2,'unresolved_references':7,'prior_broad_audit_reused_not_rerun':True,'prior_broad_audit_capture_sha256':prior['prior_broad_audit_capture_sha256'],'prior_post_commit_sha256':pre['parent_post_commit_sha256']}
dump(C/'post_commit.json',post)
print(json.dumps({'HEAD':head,'files':len(files),'bytes':sum(p.stat().st_size for p in files),'clean':True,'receipt':post['receipt_sha256'],'authority':'34/39_UNCHANGED','E5_A5':'UNQUALIFIED'}))
