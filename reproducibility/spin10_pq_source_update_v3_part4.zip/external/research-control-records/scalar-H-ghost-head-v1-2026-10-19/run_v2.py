from pathlib import Path
from hashlib import sha256
import json,os,subprocess,sys
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_scalar_H_ghost_head';C=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
from audit_a10_e5_antighost_vector import resource,line_json
prep=json.loads((O/'preparation_v2.json').read_bytes());assert sha256(Path(__file__).read_bytes()).hexdigest()==prep['controller_sha256']
assert all(not(O/(r+t)).exists() for r in ['primary','replay'] for t in ['_v2_capture.json','_v2_result.json']),'EXISTING_OUTPUTS_DO_NOT_RESTART'
for role in ['primary','replay']:
 query="@(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.ProcessId -ne "+str(os.getpid())+" -and ($_.CommandLine -like '*canonical_so10_scalar_H_ghost_head*' -or $_.CommandLine -like '*scalar-H-ghost-head-v1-2026-10-19*') } | Select-Object ProcessId,CommandLine) | ConvertTo-Json -Compress"
 assert not subprocess.check_output(['pwsh','-NoProfile','-Command',query]).strip(),'LIVE_WORK_POLL_HANDLE'
 cap=capture([sys.executable,'-B',str(O/'test_v2.py'),role]);raw=json.dumps(cap,sort_keys=True,separators=(',',':')).encode()+b'\n'
 for p in [O/(role+'_v2_capture.json'),C/(role+'_v2_full_capture.json')]:
  with p.open('xb') as f:f.write(raw)
 if cap['execution_state']!='COMPLETED':print(cap['stdout_and_stderr'],flush=True)
 resource(cap);res=line_json(cap['stdout_and_stderr'],'RESULT ');assert 0<res['elapsed_after_imports']<120
 with(O/(role+'_v2_result.json')).open('xb') as f:f.write(json.dumps(res,sort_keys=True,separators=(',',':')).encode()+b'\n')
 print('COMPLETED',role,res['scientific_disposition'],res['elapsed_after_imports'],flush=True)
