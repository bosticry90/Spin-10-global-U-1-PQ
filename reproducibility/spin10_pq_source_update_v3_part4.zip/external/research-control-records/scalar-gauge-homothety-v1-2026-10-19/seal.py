from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_scalar_gauge_homothety';C=Path(__file__).resolve().parent
base='155c1681b1c3dc9bbf929cd7a53627a0c5b31bf6'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==base
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
v=json.loads((O/'validation_receipt_v2.json').read_bytes());assert v['execution_state']=='COMPLETED'
assert v['failed_native_workers']==0 and v['failed_verifier_workers']==1
for raw,h in v['input_sha256'].items():assert digest(Path(raw))==h,raw
for b in v['historical_git_bindings']:assert sha256(git('show',b['commit']+':'+b['path'])).hexdigest()==b['sha256']
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<4*1024**2
new=sorted([p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V359.md'])
files={str(p.relative_to(R)).replace('\\','/'):digest(p) for p in new}
assert len(files)==31
subprocess.run(['git','add','--',*files],cwd=R,check=True)
assert set(git('diff','--cached','--name-only').decode().splitlines())==set(files)
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
old={}
for row in git('ls-tree','-r',base).decode().splitlines():
 info,name=row.split('\t',1);old[name]=info.split()[2]
index={}
for row in git('ls-files','-s').decode().splitlines():
 info,name=row.split('\t',1);index[name]=info.split()[1]
assert all(index[name]==blob for name,blob in old.items())
for name,h in files.items():
 assert sha256(git('show',':'+name)).hexdigest()==h,name
 assert digest(R/name)==h,name
record={'schema':'SCALAR_GAUGE_HOMOTHETY_PRECOMMIT_V1','base_commit':base,
 'validation_receipt_sha256':digest(O/'validation_receipt_v2.json'),'new_files_sha256':files,
 'old_tracked_blobs_unchanged':len(old),'bound_inputs_authenticated':len(v['input_sha256']),
 'scientific_acceptance':'NOT_PERFORMED','authority_changed':False}
with(C/'pre_commit.json').open('xb') as f:f.write((json.dumps(record,indent=2,sort_keys=True)+'\n').encode())
print('SEALED',len(files),'new files',len(old),'old blobs unchanged',flush=True)
