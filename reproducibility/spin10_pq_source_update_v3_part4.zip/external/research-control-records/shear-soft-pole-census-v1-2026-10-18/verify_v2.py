from pathlib import Path
from hashlib import sha256
from collections import Counter
from itertools import product,combinations
import gzip,json,os,sys,time,threading
import sympy as s
R=Path(r'C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_shear_soft_pole_census';P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(P));from audit_a10_e5_antighost_vector import resource,line_json
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def boolean_ast(v):
 kind=v['node'];unit=(0,0,0,0,0)
 if kind=='Field':
  name=v['name'];j={'h_B':0,'k_B':1}.get(name)
  if j is None:
   if name.startswith('h_'):j=2
   elif name.startswith('k_'):j=3
   else:return set()
  e=list(unit);e[j]=1;return {tuple(e)}
 if kind in ['Parameter','StructureConstant','RepresentationGenerator']:return {unit}
 if kind=='ExactScalar':return {unit} if v['value']!='0' else set()
 if kind=='Add':
  out=set()
  for x in v['terms']:out.update(boolean_ast(x))
  return out
 if kind=='OrderedProduct':
  out={unit}
  for x in v['factors']:out={tuple(a+b for a,b in zip(i,j)) for i in out for j in boolean_ast(x)}
  return out
 if kind=='PartialDerivative':return {a[:4]+(a[4]+1,) for a in boolean_ast(v['argument']) if sum(a[:4])}
 if kind=='LocalActionTerm':return boolean_ast(v['density'])
 if kind in ['LorentzContraction','GroupContraction']:return boolean_ast(v.get('expression',v.get('argument')))
 raise AssertionError(('UNHANDLED_PHYSICAL_AST',kind))

# Independent finite exterior algebra for a nontrivial one-loop Wick check.
def plus(*parts):
 out={}
 for part in parts:
  for m,v in part.items():out[m]=s.expand(out.get(m,0)+v)
 return {m:v for m,v in out.items() if v!=0}
def times(a,b):
 out={}
 for m,v in a.items():
  for n,w in b.items():
   if m&n:continue
   sign=(-1)**sum((n&((1<<bit)-1)).bit_count() for bit in range(4) if m&(1<<bit))
   out[m|n]=s.expand(out.get(m|n,0)+sign*v*w)
 return {m:v for m,v in out.items() if v!=0}
def scale(a,v):return {m:s.expand(v*w) for m,w in a.items() if v*w!=0}
def matrix_product(a,b):
 N=len(a);out=[[{} for j in range(N)] for i in range(N)]
 for i in range(N):
  for j in range(N):out[i][j]=plus(*(times(a[i][k],b[k][j]) for k in range(N)))
 return out
def graded_wick_fixture():
 B,L,x=s.symbols('B L x');ev=[B,L,x];par=[0,0,0,1,1,1,1]
 odd=[{1<<i:s.Integer(1)} for i in range(4)];c1,c2,a1,a2=odd
 X=times(c1,a2)
 action=plus({0:B*L+L*L/2+L*x+x*x/2},scale(times(c1,a1),-1),scale(times(c2,a2),-1),scale(X,2*L),scale(times(c2,a1),3*x))
 def derivative(F,i):
  if i<3:return {m:s.diff(v,ev[i]) for m,v in F.items() if s.diff(v,ev[i])!=0}
  bit=i-3;out={}
  for m,v in F.items():
   if m&(1<<bit):out[m^(1<<bit)]=(-1)**((m&((1<<bit)-1)).bit_count())*v
  return out
 def means(F):return {m:s.expand(v.subs({B:0,L:0,x:1})) for m,v in F.items() if v.subs({B:0,L:0,x:1})!=0}
 def hessian(F):return [[means(scale(derivative(derivative(F,i),j),(-1)**(par[j]*(par[i]+1)))) for j in range(7)] for i in range(7)]
 H=hessian(action);body=s.Matrix([[H[i][j].get(0,0) for j in range(7)] for i in range(7)]);inv=body.inv()
 G0=[[({0:inv[i,j]} if inv[i,j]!=0 else {}) for j in range(7)] for i in range(7)]
 N=[[plus(H[i][j],scale({0:body[i,j]},-1)) for j in range(7)] for i in range(7)]
 T=[[scale(v,-1) for v in row] for row in matrix_product(G0,N)]
 identity=[[({0:s.Integer(1)} if i==j else {}) for j in range(7)] for i in range(7)];power=identity;series=identity
 for degree in range(1,5):
  power=matrix_product(power,T);series=[[plus(series[i][j],power[i][j]) for j in range(7)] for i in range(7)]
 assert all(not v for row in matrix_product(power,T) for v in row)
 G=matrix_product(series,G0)
 assert matrix_product(H,G)==identity and matrix_product(G,H)==identity
 def wick(F):
  Q=hessian(F);return scale(plus(*(scale(times(G[i][j],Q[j][i]),(-1)**par[i]) for i in range(7) for j in range(7))),s.Rational(1,2))
 SL=derivative(action,1);IO=wick(times(X,SL));IX=wick(X);Gamma1L=wick(SL)
 ordinary=times(means(SL),IX);quantum=times(means(X),Gamma1L)
 remainder=plus(IO,scale(ordinary,-1),scale(quantum,-1));assert not remainder
 assert IX and ordinary and quantum and plus(IO,scale(ordinary,-1))
 return {'I_X':[[m,str(v)] for m,v in sorted(IX.items())],'Gamma1_L':[[m,str(v)] for m,v in sorted(Gamma1L.items())],'I_XS_L':[[m,str(v)] for m,v in sorted(IO.items())],'full_remainder':[],'omit_quantum_Euler_or_connected_corner_detected':True}

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(O/'validation_preparation_v2.json');assert digest(Path(__file__))==prep['source_sha256']
 for raw,h in prep['input_sha256'].items():assert digest(Path(raw))==h,raw
 allowed=set(prep['read_json'])
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('SOFT_CENSUS_VERIFY_WRITE')
  if p.suffix=='.json':assert str(p) in allowed,('UNDECLARED_SOFT_CENSUS_VERIFIER_JSON',str(p))
 sys.addaudithook(guard);a=read(O/'primary_result.json');b=read(O/'replay_result.json')
 assert {k:v for k,v in a.items() if k not in ['route','elapsed_after_imports']}=={k:v for k,v in b.items() if k not in ['route','elapsed_after_imports']}
 for route,value in [('primary',a),('replay',b)]:
  cap=read(O/(route+'_capture.json'));resource(cap);assert line_json(cap['stdout_and_stderr'],'RESULT ')==value
 ref=read(P/'frozen_a10_e5_full_hessian/primary.json');termmap={v['term_id']:v for v in a['physical_all34_terms']};physical_checked=0
 for term in ref['physical_Hessian_program']['all_34_literal_terms']:
  vectors=boolean_ast(term['mixed_second_variation_AST']);ports=set()
  for hb,kb,hs,ks,j in vectors:
   assert hb+hs==kb+ks==1;ports.add((('B' if hb else 'S','B' if kb else 'S'),j))
  expected={(tuple(row[0]),row[1]) for row in termmap[term['term_id']]['ports_jets']}
  assert ports==expected;physical_checked+=1
 assert physical_checked==34
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));counts=Counter();indices=[];g=s.symbols('g10')
 def field(tok):
  n,sep,j=tok.partition('__')
  if n.startswith('B'):t='B'
  elif n.startswith('A'):t='A'
  elif n.startswith('x_'):t='S'
  elif n.startswith('C'):t='C'
  elif n.startswith(('bar','ub')):t='a'
  elif n.startswith('L') or(n.startswith('b') and n[1:].isdigit()):t='L'
  else:raise AssertionError(('UNKNOWN_ACTUAL_FIELD',n))
  return t,len(j) if sep else 0
 for i,row in enumerate(data['gauge_fixing_density']):
  fs=[field(n) for n in row['word']]
  if len(fs)!=2 or any(t=='A' for t,j in fs):continue
  types=tuple(sorted(t for t,j in fs));assert types in [('B','L'),('L','L'),('L','S'),('C','a')]
  if types==('C','a'):types=('f','f')
  txt=s.sympify(row['coefficient']);powers=s.Poly(txt,g).monoms();assert len(powers)==1
  counts[types,sum(j for t,j in fs),powers[0][0]]+=1;indices.append(i)
 expected={(tuple(v['ports']),v['jets'],v['g']):v['density_rows'] for v in a['complete_GF_quadratic_census']};assert dict(counts)==expected
 assert sha256(json.dumps(indices,separators=(',',':')).encode()).hexdigest()==a['GF_quadratic_rows_sha256']
 assert sum(len(rows) for rows in data['master_field_maps'].values())==a['source_action_rows']==35162
 for rows in [data['gauge_fixing_density']]+list(data['master_field_maps'].values()):
  assert all(not (field(n)[0]=='L' and field(n)[1]) for row in rows for n in row['word'])
 C={(i,j):weight for i,j,weight in a['arbitrary_length_soft_closure']}
 base={('B','B'):2,('B','L'):1,('L','B'):1,('S','S'):0,('f','f'):2};V=[('S','S'),('S','L'),('L','S')]
 # Direct inductive inequalities are an arbitrary-length certificate,not a
 # path-depth test. Also check the two-M/no-return structural argument.
 for (i,j),w in base.items():assert C[i,j]>=w
 for (i,j),w in C.items():
  for k,l in V:
   if j!=k:continue
   for (m,n),z in base.items():
    if l==m:assert (i,n) in C and C[i,n]>=w+z
 assert max(C.values())==2 and ('L','L') not in C and ('L','S') not in C
 # Independent dense inverse with different noncommuting E,W,D fixture.
 q=s.symbols('q',nonzero=True);I=s.eye(2);zero=s.zeros(2);W=s.Matrix([[5,2],[2,3]]);E=s.Matrix([[2,1],[1,0]]);D=s.Matrix([[q*q+3,2],[2,q*q+8]])
 H=s.BlockMatrix([[zero,s.I*q*I,zero],[-s.I*q*I,W,E],[zero,E.T,D]]).as_explicit();Gi=H.inv()
 assert Gi[2:4,2:4]==zero and Gi[2:4,4:6]==zero and Gi[4:6,2:4]==zero
 assert all(s.cancel(v)==0 for v in H*Gi-s.eye(6))
 for i,j,pole in [(0,0,2),(0,1,1),(1,0,1),(0,2,1),(2,0,1),(2,2,0)]:
  assert all(s.cancel(q**pole*Gi[2*i+k,2*j+l]).subs(q,0).is_finite for k in range(2) for l in range(2))
 # Complete one-loop Wick product-rule test with actual even-output/odd-input
 # structure. It has nonzero connected,ordinary and quantum Euler terms.
 wick=graded_wick_fixture()
 # Repeated centers are possible after replacing the local probe by a
 # constant;the earlier actual XZ counterexample must remain preserved.
 assert len(set([0,1,0]))==2
 for witness in a['nonexceptional_domain_witnesses']:
  pp=witness['momenta'];N=len(pp);assert sum(pp)==0
  assert all(sum(pp[i] for i in subset)!=0 for k in range(1,N) for subset in combinations(range(N),k))
 assert a['controls']['wrong_allowed_coefficient_detected_by_support_census'] is False
 assert a['offflat_IR_variation_bound_or_exceptional_distribution_extension_proved'] is False
 assert a['kappa_b0_fixed_identified_or_IR_scheme_adopted'] is False
 proof=' '.join((O/'DERIVATION.md').read_text(encoding='utf-8').split())
 for text in ['one marked','zero soft weight','whole source products','A=0','off-flat','one-loop Wick/Legendre','nonempty proper','arbitrary','O(epsilon²)']:
  assert text in proof,text
 result={'schema':'SHEAR_SOFT_POLE_CENSUS_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':a['scientific_disposition'],
  'all_native_results_equal':True,'independent_all34_boolean_AST_support_and_GF_quadratic_census_verified':True,
  'all35162_source_rows_and_auxiliary_jet_exclusion_verified':True,
  'arbitrary_length_inductive_soft_closure_verified':True,'different_noncommuting_dense_inverse_soft_bounds_verified':True,
  'independent_graded_one_loop_Wick_fixture':wick,
  'analytic_review':{'zero_transfer':'only scalar/scalar and L/scalar;all finite scalar-mass reference insertions retained','soft_language':'arbitrary-length induction,max pole2,not a sampled-depth claim','domain':'flat single local probe,generic labeled external momenta;zero-transfer-only loops reduce to one decorated covariance','IR_removal':'integrable separated centers,Gaussian-mask O(epsilon²),uniform positive heat;actual inverse reduction first','identity':'one-loop graded Hessian product rule with full inverse,whole source products and zero-divergence auxiliary shift;formal coefficientwise construction','remaining':'off-flat spectral variations,exceptional/testfield extension,multiple contacts,measure/global QAP and full source-free restoration unproved'},
  'full_QAP_IR_measure_exceptional_or_E5_A5_proved':False,
  'new_failed_native_workers':0,'new_failed_verifier_workers':1,
  'checks_not_performed':['new physical/color coefficients','new broad sealed E4/custody replay','off-flat spectral/testfield construction','Lean or outside expert validation'],
  'shared_limits':'same action/AST/GF/reference/source/graded conventions and AI author,SymPy/Python;independent implementation cannot validate shared physical premises',
  'authority_Gamma_old_evidence_unchanged':True,'input_sha256':prep['input_sha256'],'elapsed_after_imports':time.perf_counter()-tick}
 print('VALIDATION '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
