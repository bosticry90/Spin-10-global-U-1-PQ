from pathlib import Path
from hashlib import sha256
import subprocess,json,sys
R=Path('C:/Users/psboy/Documents/ToE-Next');C=Path(__file__).resolve().parent
g=lambda *a:subprocess.check_output(['git',*a],cwd=R)
base='7e83a95c07fe7d05a1a6b373be35a8c83f438a82'
names=['calculations/canonical_so10_vector_mass_tangent/'+n for n in ['PACKAGING_REVIEW_V2.md','packaging_whitespace_failure_capture.json','packaging_crlf_review_capture.json']]+['docs/RESEARCH_EXECUTION_HANDOFF_V376.md']
d=lambda p:sha256(p.read_bytes()).hexdigest()
if sys.argv[1]=='before':
 assert g('rev-parse','HEAD').decode().strip()==base and not g('diff','--name-only').strip() and not g('diff','--cached','--name-only').strip()
 tree=g('ls-tree','-r',base);assert len(tree.splitlines())==24555
 assert set(g('ls-files','--others','--exclude-standard').decode().splitlines())==set(names)
 v={'base':base,'new_sha256':{n:d(R/n) for n in names},'old_tree':tree.decode()}
 with (C/'packaging_precommit_seal.json').open('xb') as f:f.write((json.dumps(v,sort_keys=True)+'\n').encode())
 print('PACKAGING_PRESEALED',len(names))
elif sys.argv[1]=='index':
 v=json.loads((C/'packaging_precommit_seal.json').read_bytes());assert set(g('diff','--cached','--name-only').decode().splitlines())==set(names)
 for n,h in v['new_sha256'].items():assert sha256(g('show',':'+n)).hexdigest()==h==d(R/n)
 g('-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check')
 print('PACKAGING_INDEX_VALIDATED')
else:
 v=json.loads((C/'packaging_precommit_seal.json').read_bytes());assert g('rev-parse','HEAD^').decode().strip()==base
 now={l.split(b'\t',1)[1]:l.split(b'\t',1)[0] for l in g('ls-tree','-r','HEAD').splitlines()}
 old={l.split(b'\t',1)[1]:l.split(b'\t',1)[0] for l in v['old_tree'].encode().splitlines()};assert all(now[n]==h for n,h in old.items())
 for n,h in v['new_sha256'].items():assert sha256(g('show','HEAD:'+n)).hexdigest()==h==d(R/n)
 assert not g('status','--porcelain').strip()
 out={'commit':g('rev-parse','HEAD').decode().strip(),'old_blobs_preserved':len(old),'new_raw_index_HEAD':len(names),'clean':True}
 with (C/'packaging_postcommit_seal.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True)+'\n').encode())
 print(out)
