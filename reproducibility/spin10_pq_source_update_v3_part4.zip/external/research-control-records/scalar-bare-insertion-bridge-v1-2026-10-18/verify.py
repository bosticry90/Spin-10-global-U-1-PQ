"""Independent literal even variations and five-radical width polynomials."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from fractions import Fraction as F
from functools import lru_cache
import importlib.util,json,sys,time,threading,os
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_bare_insertion_bridge';CONTROL=Path(__file__).resolve().parent
def load(n,p):
 sp=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);return u
old=load('independent_prior_qualified_recipe',ROOT/'calculations/canonical_so10_ghost_mass_g4_integration/integration.py');m=old.m;q=old.q;s=m.s;v=load('independent_radical_rationals',CONTROL.parent/'ghost-mass-g4-pole-v1-2026-10-18/verify.py');read=v.read;digest=v.digest
PARAM={'g3_etaH0_xi2_scalar1':(3,0,2,1),'g4_etaH1_xi1_scalar1':(4,1,1,1),'g4_etaH0_xi2_scalar1':(4,0,2,1),'g4_etaH0_xi0_scalar2':(4,0,0,2)};ANTI=v.ANTI;SQ=v.SQ
def mask_to_consumer(mask):return sum(1<<m.ex.SQUARES.index(value) for bit,value in enumerate(SQ) if mask&(1<<bit))
def mask_from_consumer(mask):return sum(1<<SQ.index(value) for bit,value in enumerate(m.ex.SQUARES) if mask&(1<<bit))
def cadd(A,B):
 d=dict(A)
 for k,z in B:d[k]=d.get(k,F(0))+z
 return tuple((k,z) for k,z in sorted(d.items()) if z)
def cscale(A,n):return tuple((k,z*n) for k,z in A if z*n)
@lru_cache(maxsize=131072)
def cmul(A,B):
 d={}
 for(a,b,ma),x in A:
  for(c,e,mb),y in B:
   value=x*y
   for bit,prime in enumerate(SQ):
    if ma&mb&(1<<bit):value*=prime
   key=a+c,b+e,ma^mb;d[key]=d.get(key,F(0))+value
 return tuple((k,z) for k,z in sorted(d.items()) if z)
def put(P,k,z):
 if z:P[k]=cadd(P.get(k,()),z)
 if k in P and not P[k]:del P[k]
def consumer(z):return m.ex.Coefficient({(a,b,mask_to_consumer(mask)):v for(a,b,mask),v in z})
def from_consumer(z):return tuple(((a,b,mask_from_consumer(mask)),v) for(a,b,mask),v in sorted(z.cells.items(),key=lambda p:(p[0][0],p[0][1],mask_from_consumer(p[0][2]))))
def token(n):
 name,_,jets=n.partition('__');return name,tuple(map(int,jets))
def serialize(t):
 n,j=t;return n+('__'+''.join(map(str,j)) if j else '')
def parity(n):return m.par[m.index[n]]
def canonical(seq):
 odds=[(m.index[t[0]],t[1]) for t in seq if parity(t[0])]
 if len(odds)!=len(set(odds)):return (),0
 return tuple(sorted(seq,key=lambda t:(m.index[t[0]],t[1]))),(-1)**sum(a>b for i,a in enumerate(odds) for b in odds[i+1:])
def product(P,Q):
 out={}
 for(gp,a),x in P.items():
  for(gq,b),y in Q.items():
   key,sg=canonical(a+b)
   if sg:put(out,(gp+gq,key),cscale(cmul(x,y),sg))
 return out
def decoded_hash(P):
 h=sha256();h.update(b'[')
 for i,((gp,word),z) in enumerate(sorted(P.items(),key=lambda p:(p[0][0],tuple((m.index[n],j) for n,j in p[0][1])))):
  if i:h.update(b',')
  cells=[[[a,b,mask_to_consumer(mask)],str(value)] for(a,b,mask),value in sorted(z,key=lambda p:(p[0][0],p[0][1],mask_to_consumer(p[0][2])))];h.update(json.dumps([gp,[[n,list(j)] for n,j in word],cells],separators=(',',':'),ensure_ascii=True).encode())
 h.update(b']');return h.hexdigest()
@lru_cache(None)
def parse(text):
 z=s.sympify(text,locals={'g10':m.g,'xi':m.xi,'eta_H':m.etaH,'reference_width_M':m.xi,'reference_width_H':m.etaH});out={}
 for(gp,xp,hp),co in s.Poly(s.expand(z),m.g,m.xi,m.etaH).terms():
  if co:out[gp]=cadd(out.get(gp,()),tuple(((xp,hp,mask),value) for mask,value in v.number(str(co))))
 return tuple(sorted(out.items()))
def from_rows(rows):
 out={}
 for row in rows:
  word=tuple(token(n) for n in row['word']);key,sg=canonical(word);assert key==word and sg==1
  for gp,z in parse(row['coefficient']):put(out,(gp,key),z)
 return out
def result_rows(rows):
 out={}
 for row in rows:
  parsed=parse(row['coefficient']);assert len(parsed)==1 and parsed[0][0]==0;key,sg=canonical(tuple(token(n) for n in row['word']));assert sg==1;put(out,(row['g'],key),parsed[0][1])
 return out
@lru_cache(maxsize=8192)
def format_coeff(signature):
 expression=0
 for gp,cells in signature:
  for(xp,hp,mask),value in cells:expression+=m.g**gp*m.xi**xp*m.etaH**hp*v.sym(((mask,value),))
 return q.sumtext((str(s.expand(expression)),))
def delta_and_node(data):
 P={};parts=defaultdict(dict)
 for label,rows in data['canonical_parameter_tables'].items():
  gp,hp,xp,degree=PARAM[label]
  for word,cells in rows:
   key=tuple((n,()) for n in word);assert canonical(key)==(key,1);value=tuple(((xp,hp,mask),F(n,d)) for mask,n,d in cells);put(P,(gp,key),value)
 for(gp,key),value in P.items():parts[key][gp]=value
 node={key:format_coeff(tuple(sorted(values.items()))) for key,values in parts.items()};assert len(node)==719730
 return P,node
def ids_word(word):return tuple((m.index[n],j) for n,j in word)
def raw_rows_from_names(P):return [{'word':[serialize(t) for t in key],'coefficient':z} for key,z in sorted(P.items(),key=lambda p:ids_word(p[0]))]
def kind(n):return 'E' if n.startswith('zz_da') else'x' if n.startswith('x_') else'a' if n in ANTI else'C' if n.startswith('C') else'J' if m.index[n] in m.sources else'B' if n.startswith('B') else'A' if n.startswith('A') else'L' if n.startswith('L') or n.startswith('b') else'OTHER'
def degree(word):
 kinds=tuple(sorted(kind(n) for n,j in word));return len(kinds)-2 if kinds in [('C','E','x'),('C','E','x','x')] else 0
def decode_compact(d):
 assert d['schema']=='FINITE_EXACT_COMPONENT_INTERNED_CELLS_V1' and d['alphabet']==m.names and d['basis_squared']==list(m.ex.SQUARES);coefs=[];out={};used=set()
 for rows in d['coefficients']:
  assert rows and len({(a,b,mask) for a,b,mask,n,den in rows})==len(rows);coefs.append(tuple(((a,b,mask_from_consumer(mask)),F(n,den)) for a,b,mask,n,den in sorted(rows,key=lambda r:(r[0],r[1],mask_from_consumer(r[2])))))
 for gp,word,cid in d['monomials']:
  assert type(cid) is int and 0<=cid<len(coefs);assert all(type(n) is int and 0<=n<len(m.names) for n,j in word);key=tuple((m.names[n],tuple(j)) for n,j in word);assert canonical(key)==(key,1) and (gp,key) not in out;out[gp,key]=coefs[cid];used.add(cid)
 assert used==set(range(len(coefs))) and decoded_hash(out)==d['sha256_exact_cells'];return out
def fixture():
 assert mask_to_consumer(8)==16 and mask_to_consumer(16)==8 and mask_from_consumer(16)==8
 for a in range(32):
  x=(((0,0,a),F(1)),);assert from_consumer(consumer(x))==x
  for b in range(32):assert from_consumer(consumer(x)*consumer((((0,0,b),F(1)),)))==cmul(x,(((0,0,b),F(1)),))
 assert canonical((('ub12',()),('C0',()),('x_Phi_0',())))[1]==-1 and canonical((('C0',()),('C0',())))[1]==0
 return True

def strict_decode(packet):
 assert len(packet['alphabet'])==len(set(packet['alphabet']))
 for cc in packet['coefficients']:
  assert cc and cc==sorted(cc,key=lambda r:r[:3])
  for a,b,mask,n,den in cc:
   assert all(type(v) is int for v in [a,b,mask,n,den]) and a>=0 and b>=0 and 0<=mask<32 and n!=0 and den>0 and F(n,den).numerator==n and F(n,den).denominator==den
 for gp,word,cid in packet['monomials']:
  assert type(gp) is int and 0<=gp<=5 and word
  for n,j in word:assert isinstance(j,list) and all(type(mu) is int and 0<=mu<4 for mu in j) and j==sorted(j)
 return decode_compact(packet)

access=load('qualified_actual_action_IO',ROOT/'calculations/canonical_so10_broken_antighost_g1_reconciliation/reconcile_v2.py').b

def setup_bridge():
 m.setup()
 def new(n,p):
  assert n not in m.index;m.index[n]=len(m.names);m.names.append(n);m.par.append(p)
 for i in range(45):new(f'zz_da{i:02}',1)
 ordered=sorted(m.fields)
 for n in ordered:new('zz_h_'+m.names[n],m.par[n])
 for n in ordered:new('zz_k_'+m.names[n],m.par[n])
 return {f'ub{i}':f'zz_da{i:02}' for i in range(12,45)},{m.names[n]:'zz_h_'+m.names[n] for n in ordered},{m.names[n]:'zz_k_'+m.names[n] for n in ordered}

def even_slots(P,rename):
 out={}
 for(gp,word),z in P.items():
  for i,(n,j) in enumerate(word):
   if n in rename:
    nn=rename[n];assert parity(nn)==parity(n);seq=word[:i]+((nn,j),)+word[i+1:];key,sg=canonical(seq)
    if sg:put(out,(gp,key),z if sg==1 else cscale(z,sg))
 return out

def union(*parts):
 out={}
 for P in parts:
  for k,z in P.items():put(out,k,z)
 return out

def weighted_fixture():
 for n in range(1,5):
  a=((1,2),(0,3));c=((0,1),(-2,0))
  def addmat(A,B):return tuple(tuple(A[i][j]+B[i][j] for j in range(2)) for i in range(2))
  def mm(A,B):return tuple(tuple(sum(A[i][k]*B[k][j] for k in range(2)) for j in range(2)) for i in range(2))
  zero=((0,0),(0,0));ident=((1,0),(0,1));poly={0:ident}
  for k in range(n):
   out={}
   for d,z in poly.items():
    for dd,co in [(0,a),(1,c)]:out[d+dd]=addmat(out.get(d+dd,zero),mm(z,co))
   poly=out
  powers=[ident]
  for k in range(n):powers.append(mm(powers[-1],a))
  expected=zero
  for r in range(n):expected=addmat(expected,mm(mm(powers[r],c),powers[n-1-r]))
  assert poly[1]==expected and mm(a,c)!=mm(c,a)
 return True

def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(OUT/'validation_preparation.json');assert digest(Path(__file__))==prep['validator_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allow={str(Path(p).resolve()) for p in prep['read_json']}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('INDEPENDENT_BARE_BRIDGE_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allow,('UNDECLARED_JSON',str(p))
 sys.addaudithook(guard);I,H,K=setup_bridge();assert fixture() and weighted_fixture()
 a=read(OUT/'primary_result.json');bb=read(OUT/'replay_result.json')
 for key in a.keys()-{'route','stages','elapsed_after_imports'}:assert a[key]==bb[key],key
 del bb
 op=access.auth('canonical_so10_broken_antighost_operator','primary_v2_result.json','validation_v2_receipt.json');e2,eb=access.sealed('frozen_a10_e2_transport','primary');master,mb=access.sealed('frozen_a10_bv_master','primary')
 V={J:result_rows(rows) for J,rows in op['all33_kernel_maps'].items()};B=result_rows(op['classical_sourcefree_breaking']);C=result_rows(op['complete_mixed_Hessian_insertion']);GF=from_rows(e2['gauge_fixing_density']);R={m.names[J]:from_rows(master['source_only_columns'][m.names[n]]) for n,J in m.pairs}
 assert len(R)==643 and len(V)==479 and len(C)==99272 and len(B)==9696
 Bhh=even_slots(even_slots(B,H),K);assembled=union(Bhh,C);print('STAGE independent entire_B_Hessian_and_both_mixed_terms',flush=True)
 anti=even_slots(even_slots(even_slots(GF,I),H),K);source={}
 for J,VP in V.items():
  second=even_slots(even_slots(R[J],H),K)
  if second:
   for key,z in product(VP,second).items():put(source,key,z)
 direct=union(anti,{k:cscale(z,-1) for k,z in source.items()});assert direct==assembled
 assert len(assembled)==a['whole_actual_DH_positions'] and decoded_hash(assembled)==a['whole_actual_DH_sha256_exact_cells'] and strict_decode(a['whole_actual_DH_compact'])==assembled
 assert decoded_hash(source)==a['actual_source_correction_sha256_exact_cells'];print('STAGE independent complete_actual_GF_master_DH_coefficients_and_zero_complements',flush=True)
 per=[{'g':gp,'breaking_hessian_positions':sum(g==gp for g,w in Bhh),'mixed_positions':sum(g==gp for g,w in C),'complete_DH_positions':sum(g==gp for g,w in assembled),'direct_GF_antighost_positions':sum(g==gp for g,w in anti),'source_master_correction_positions':sum(g==gp for g,w in source)} for gp in range(4)]
 assert per==a['complete_Hessian_order_census'] and sorted({g for g,w in assembled})==a['all_actual_DH_orders']==[0,1,2]
 census=Counter()
 for(gp,word),z in assembled.items():
  assert sum(n.startswith('zz_h_') for n,j in word)==1 and sum(n.startswith('zz_k_') for n,j in word)==1 and sum(n.startswith('zz_da') for n,j in word)==1 and not any(m.index[n] in m.sources for n,j in word)
  census[gp,tuple(sorted(n[5:][0] for n,j in word if n.startswith(('zz_h_','zz_k_')))),sum(len(j) for n,j in word)]+=1
 assert [[g,list(pair),jet,num] for(g,pair,jet),num in sorted(census.items())]==a['field_pair_jet_census']
 assert assembled!=Bhh and assembled!=C and source
 for n in range(1,5):
  expected={tuple(['G','H']*r+['G','dH']+['G','H']*(n-1-r)):str(F((-1)**(n+1),n)) for r in range(n)}
  assert {tuple(w):co for w,co in a['ordered_Born_derivative_weighted_word_fixtures'][n-1]}==expected
 loc=access.auth('canonical_so10_ordered_multiheat_uv_log','primary_v2_result.json');oldbridge=access.auth('canonical_so10_broken_antighost_g1_reconciliation','primary_v2_result.json');front=access.auth('canonical_so10_antighost_finite_frontier','primary_result.json','validation_v2_receipt.json')
 assert loc['unheated_complete_classical_minus4_symbol_alone_determines_leading_log'] and oldbridge['all_word_lengths_by_product_rule_not_a_four_word_truncation'] and front['all33_formal_local_UV_insertions_have_g_at_most4'] and front['ordinary_sourcefree_upper_bound']==4 and not front['possible_g5_source_channels'] and op['reference_Green_coefficients_broken_antighost_source_independent'] and op['all_kernel_second_field_variations_zero']
 crp=ROOT/'calculations/canonical_so10_scalar_antighost_component/validation_receipt.json';assert digest(crp)==a['whole_scalar_component_receipt_sha256']=='18252f92a05d0ff3e312bd2a9a77ae8aaf786ed2774c0ffcb60739d300ed9eba';cr=read(crp)
 assert cr['execution_state']=='COMPLETED' and cr['whole_predecessor_census_and_all_g0_to5_degree1_2_jet_domains_verified'] and cr['full146663_source_and2589_kernel_rows_verified'] and cr['complete_component_and_all_implicit_zero_coefficients_verified'] and cr['complete_scalar_component_positions']==a['scalar_leg_derived_bare_insertion_positions'] and cr['complete_scalar_component_sha256_exact_cells']==a['scalar_leg_derived_bare_insertion_sha256'] and cr['whole_component_by_g_and_scalar_degree']==a['whole_scalar_g_degree_dispositions']
 assert not a['new_independent_insertion_loop_integral_performed'] and not a['renormalized_connected_products_contacts_or_QAP_proved'] and not any(a['all_seven_quantum_flags_false'].values())
 for role in ['primary','replay']:
  cap=read(OUT/(role+'_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['calculation_completed'] and cap['post_run_observations_qualified'] and cap['exit_code']==0
 result={'schema':'COMPLETE_ACTUAL_DH_SCALAR_BARE_LEG_BRIDGE_INDEPENDENT_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':'WHOLE_SCALAR_BARE_LEG_REDUCTION_QUALIFIED_RENORMALIZED_CONTACTS_UNPROVED','input_sha256':prep['input_sha256'],'all_actual_GF_master_DH_coefficients_and_zero_complements_independently_verified':True,'both_mixed_terms_breaking_Hessian_and_field_source_parities_retained':True,'complete_all_order_and_field_pair_jet_census_verified':True,'actual_DH_positions':len(assembled),'actual_DH_sha256_exact_cells':decoded_hash(assembled),'complete_Hessian_order_census':per,'whole_scalar_component_and_source_coverage_bound_to_accepted_receipt':True,'ordered_even_arbitrary_finite_word_rule_and_noncommuting_weights_verified':True,'fixed_order_explicit_UV_family_and_reference_independence_premises_authenticated':True,'scalar_leg_derived_bare_insertion_positions':cr['complete_scalar_component_positions'],'scalar_leg_derived_bare_insertion_sha256':cr['complete_scalar_component_sha256_exact_cells'],'new_independent_insertion_integral':'NOT_PERFORMED','renormalized_QAP_contact_measure_IR_E5_A5':'UNQUALIFIED','prelaunch_metadata_failures_preserved':1,'native_worker_failures':0,'independent_worker_failures':0,'fresh_byte_identical_replay_pairs_claimed':0,'authority_functional_and_all_physical_inputs_unchanged':True,'shared_limits':'Actual action/source maps,kernel and measured scalar/source input coverage,finite UV theorem,software and AI author shared. Independent radical arithmetic/literal full DH differentiation,not new integral or renormalized QAP','elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
