from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,ast,symtable,builtins,subprocess,importlib.util,sys
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_bare_insertion_bridge';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();prep=read(OUT/'preparation.json');assert head==prep['base_commit']=='51fe7e284f26be5031c2e6acc9c7bd5aa40851e8'
files={Path(p) for p in prep['input_sha256']}|{OUT/'preparation.json'};allowed={OUT/'validation_preparation.json'}
for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
for role in ['primary','replay']:
 p=OUT/(role+'_result.json');cap=OUT/(role+'_capture.json');c=read(cap);assert c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified'] and c['exit_code']==0 and cap.read_bytes()==(CONTROL/(role+'_full_capture.json')).read_bytes();files|={p,cap,CONTROL/(role+'_full_capture.json')};allowed|={p,cap};allowed.update(Path(p) for p in prep['read_json_by_role'][role])
a=read(OUT/'primary_result.json');b=read(OUT/'replay_result.json')
for key in a.keys()-{'route','stages','elapsed_after_imports'}:assert a[key]==b[key],key
del b
assert a['direct_GF_master_equals_complete_B_second_variation_plus_both_mixed_terms'] and not a['new_independent_insertion_loop_integral_performed'] and not a['renormalized_connected_products_contacts_or_QAP_proved']
for p in [CONTROL/'verify.py',CONTROL/'run_validation.py',Path(__file__)]:
 text=p.read_text(encoding='utf-8');ast.parse(text);tree=symtable.symtable(text,str(p),'exec');defs={z.get_name() for z in tree.get_symbols() if z.is_assigned() or z.is_imported() or z.is_namespace()}|set(dir(builtins))|{'__file__','__name__','__package__'};errors=[]
 def scan(t):
  for z in t.get_symbols():
   if z.is_referenced() and z.is_global() and z.get_name() not in defs:errors.append((t.get_name(),z.get_name()))
  for child in t.get_children():scan(child)
 scan(tree);assert not errors,errors
sp=importlib.util.spec_from_file_location('independent_bare_bridge_preflight',CONTROL/'verify.py');u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);I,H,K=u.setup_bridge();assert u.fixture() and u.weighted_fixture()
P={(2,(('C0',()),('ub12',()),('x_Phi_0',()))):(((1,0,16),F(1)),)};ren=u.even_slots(P,I);assert ren and ren!=P
packet={'schema':'FINITE_EXACT_COMPONENT_INTERNED_CELLS_V1','alphabet':u.m.names,'basis_squared':list(u.m.ex.SQUARES),'coefficients':[[[1,0,8,1,1]]],'monomials':[[2,[[u.m.index[n],list(j)] for n,j in next(iter(P))[1]],0]],'sha256_exact_cells':u.decoded_hash(P)};assert u.strict_decode(packet)==P
bad=json.loads(json.dumps(packet));bad['monomials'][0][2]=-1
try:u.strict_decode(bad)
except AssertionError:pass
else:raise AssertionError('NEGATIVE_COEFFICIENT_INDEX_ACCEPTED')
for mod in list(sys.modules.values()):
 name=getattr(mod,'__file__',None)
 if name:
  p=Path(name).resolve()
  if p.suffix=='.py' and(p.is_relative_to(ROOT) or p.is_relative_to(CONTROL.parent)):files.add(p)
for p in [CONTROL/'verify.py',CONTROL/'run_validation.py',Path(__file__)]:
 copy=Path(str(p)+'.source.txt')
 with copy.open('xb') as f:f.write(p.read_bytes())
 files|={p,copy}
d={'schema':'SCALAR_BARE_INSERTION_BRIDGE_INDEPENDENT_PREPARATION_V1','base_commit':head,'validator_sha256':digest(CONTROL/'verify.py'),'controller_sha256':digest(CONTROL/'run_validation.py'),'input_sha256':{str(p):digest(p) for p in sorted(files)},'read_json':[str(p) for p in sorted(allowed)],'both_native_complete_scientific_records_equal':True,'literal_even_basis_packet_and_noncommuting_fixtures_passed':True,'all_source_copies_exclusive':True,'preserved_prelaunch_metadata_failure_count':1,'no_Gamma_component_recalculation_or_independent_loop':True,'limits':{'seconds_after_imports':180,'private_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2}}
with(OUT/'validation_preparation.json').open('xb') as f:f.write(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('BARE_BRIDGE_VALIDATION_FROZEN',len(files),flush=True)
