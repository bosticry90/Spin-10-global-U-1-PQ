from pathlib import Path
from hashlib import sha256
import json,subprocess
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_bare_insertion_bridge';CONTROL=Path(__file__).resolve().parent;HAND=ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V285.md';BASE='51fe7e284f26be5031c2e6acc9c7bd5aa40851e8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-c','core.autocrlf=false','-c','core.longpaths=true',*args],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='main' and not git('diff','--cached','--name-only').strip()
maps={}
for name in ['preparation.json','validation_preparation.json','validation_receipt.json']:
 d=read(OUT/name)
 for p,h in d['input_sha256'].items():assert digest(Path(p))==h,p
 maps[name]=len(d['input_sha256'])
r=read(OUT/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and digest(OUT/'validation_receipt.json')=='2cc2cef3d438d63fd4b00a521dce5470bc3980cd9e601e2b285469b35c763b21' and r['actual_DH_positions']==99256 and r['renormalized_QAP_contact_measure_IR_E5_A5']=='UNQUALIFIED'
assert (OUT/'bridge.py').read_bytes()==(OUT/'bridge.py.source.txt').read_bytes()
for name in ['run.py','prepare.py','verify.py','run_validation.py','prepare_validation.py']:assert (CONTROL/name).read_bytes()==(CONTROL/(name+'.source.txt')).read_bytes()
failed=read(CONTROL/'prelaunch_metadata_failure.json');assert failed['execution_state']=='FAILED_PRELAUNCH_METADATA_ASSERTION' and not failed['worker_started']
for name in ['primary','replay','validation']:
 assert (OUT/(name+'_capture.json')).read_bytes()==(CONTROL/(name+'_full_capture.json')).read_bytes();c=read(OUT/(name+'_capture.json'));assert c['execution_state']=='COMPLETED' and c['post_run_observations_qualified'] and c['calculation_completed'] and c['exit_code']==0
for name in ['AGENTS.md','project_state.json','CHARTER.md']:assert (ROOT/name).read_bytes()==git('show',BASE+':'+name)
assert digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
expected={p.relative_to(ROOT).as_posix() for p in OUT.rglob('*') if p.is_file()}|{HAND.relative_to(ROOT).as_posix()}
status=git('status','--porcelain','--untracked-files=all').decode().splitlines();assert all(x[3:].replace('\\','/') in expected for x in status),status
git('add','--',OUT.relative_to(ROOT).as_posix(),HAND.relative_to(ROOT).as_posix());assert set(git('diff','--cached','--name-only').decode().splitlines())==expected;git('diff','--cached','--check')
text=git('commit','-m','Qualify complete scalar bare insertion loop-leg bridge').decode();head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()==BASE
assert set(git('diff-tree','--no-commit-id','--name-only','-r',head).decode().splitlines())==expected
for name in expected:assert (ROOT/name).read_bytes()==git('show','HEAD:'+name)==git('show',':'+name),name
assert not git('status','--porcelain','--untracked-files=all').strip()
post={'schema':'SCALAR_BARE_INSERTION_BRIDGE_LOCAL_POST_COMMIT_V1','execution_state':'COMPLETED','parent':BASE,'commit':head,'exact_paths':sorted(expected),'accepted_receipt_sha256':digest(OUT/'validation_receipt.json'),'all_binding_maps_checked':maps,'source_copies_and_full_captures_match':True,'prelaunch_failure_preserved':True,'every_HEAD_index_worktree_byte_equal':True,'protected_parent_bytes_unchanged':True,'working_tree_clean':True,'no_remote_action':True,'bare_loop_leg_bridge_qualified':True,'renormalized_QAP_contact_E5_A5_and_full_goal':'UNQUALIFIED_INCOMPLETE','post_commit_script_sha256':digest(Path(__file__))}
with(CONTROL/'post_commit.json').open('xb') as f:f.write(json.dumps(post,sort_keys=True,separators=(',',':')).encode()+b'\n')
print(text,flush=True);print('POST_COMMIT '+head+' '+str(len(expected))+' files',flush=True)
