from pathlib import Path
from hashlib import sha256
import json,ast,symtable,builtins,subprocess,importlib.util,sys,os
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_bare_insertion_bridge';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='51fe7e284f26be5031c2e6acc9c7bd5aa40851e8'
crp=ROOT/'calculations/canonical_so10_scalar_antighost_component/validation_receipt.json';assert digest(crp)=='18252f92a05d0ff3e312bd2a9a77ae8aaf786ed2774c0ffcb60739d300ed9eba';cr=read(crp)
files={Path(p) for p in cr['input_sha256']}|{crp,OUT/'RECORD.md',ROOT/'AGENTS.md',ROOT/'project_state.json',ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V284.md',CONTROL/'prepare_unfrozen_failed_source.txt',CONTROL/'prelaunch_metadata_failure.json'}
for p,h in cr['input_sha256'].items():assert digest(Path(p))==h,p
for p in [OUT/'bridge.py',CONTROL/'run.py',Path(__file__)]:
 text=p.read_text(encoding='utf-8');ast.parse(text);t=symtable.symtable(text,str(p),'exec');defs={z.get_name() for z in t.get_symbols() if z.is_assigned() or z.is_imported() or z.is_namespace()}|set(dir(builtins))|{'__file__','__name__','__package__'};errors=[]
 def scan(t):
  for z in t.get_symbols():
   if z.is_referenced() and z.is_global() and z.get_name() not in defs:errors.append((t.get_name(),z.get_name()))
  for ch in t.get_children():scan(ch)
 scan(t);assert not errors,errors
sp=importlib.util.spec_from_file_location('bare_bridge_types_preflight',OUT/'bridge.py');u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);active=None
def audit(event,args):
 if event=='open' and active is not None and args and isinstance(args[0],(str,bytes)):
  p=Path(os.fsdecode(args[0])).resolve()
  if p.suffix=='.json':active.add(p)
sys.addaudithook(audit);active=set();eps,I,H,K=u.setup();assert len(H)==len(K)==643 and len(I)==33;common=set(active);active=None
P=u.m.decode([{'word':['C0','ub12','x_Phi_0'],'coefficient':'I*sqrt(7)*g10**2*xi'}]);assert u.m.action(P,I,'primary',True)==u.m.action(P,I,'replay');assert u.word_rule();roles={};types={}
for role in ['primary','replay']:
 active=set();op,e2,master,c,r,loc,old,front=u.dependencies(role);roles[role]=active|common|{OUT/'preparation.json'};files|=active;active=None
 assert len(master['source_only_columns'])==1286 and all(u.m.names[n] in master['source_only_columns'] for n in u.m.fields) and len(u.m.fields)==643 and len(op['all33_kernel_maps'])==479 and len(op['complete_mixed_Hessian_insertion'])==99272 and len(op['classical_sourcefree_breaking'])==9696
 assert isinstance(front['ordinary_sourcefree_upper_bound'],int) and front['ordinary_sourcefree_upper_bound']==4 and len(c['whole_component_by_g_and_scalar_degree'])==12
 types[role]={'stored_field_and_source_master_columns':1286,'selected_integrated_field_master_columns':643,'kernel_channels':479,'classical_breaking_rows':9696,'mixed_rows':99272,'scalar_component_positions':r['complete_scalar_component_positions'],'actual_metadata_values_not_assumed':True}
files|=common
for mod in list(sys.modules.values()):
 name=getattr(mod,'__file__',None)
 if name:
  p=Path(name).resolve()
  if p.suffix=='.py' and(p.is_relative_to(ROOT) or p.is_relative_to(CONTROL.parent)):files.add(p)
for p in [OUT/'bridge.py',CONTROL/'run.py',Path(__file__)]:
 copy=Path(str(p)+'.source.txt')
 with copy.open('xb') as f:f.write(p.read_bytes())
 files|={p,copy}
d={'schema':'SCALAR_BARE_INSERTION_BRIDGE_PREPARATION_V1','base_commit':head,'source_sha256':digest(OUT/'bridge.py'),'controller_sha256':digest(CONTROL/'run.py'),'input_sha256':{str(p):digest(p) for p in sorted(files)},'read_json_by_role':{role:[str(p) for p in sorted(pp)] for role,pp in roles.items()},'actual_types_and_scopes':types,'exact_even_and_noncommuting_weighted_product_fixtures':True,'all_source_copies_exclusive':True,'no_full_Gamma_or_scalar_component_recomputation':True,'limits':{'seconds_after_imports':180,'private_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2}}
with(OUT/'preparation.json').open('xb') as f:f.write(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('BARE_BRIDGE_FROZEN',len(files),flush=True)
