from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_sourcefree_primitive_probe';C=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
base='c4af92b54b616f3ca88027b226671a1d13ae990d'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==base and not subprocess.check_output(['git','diff','--name-only'],cwd=R)
for p in [O/'probe.py',O/'RECORD.md',O/'DERIVATION.md',C/'run.py',Path(__file__)]:
 p.write_bytes((chr(10).join(z.rstrip() for z in p.read_text().splitlines()).rstrip()+chr(10)).encode())
 with p.with_name(p.name+'.source.txt').open('xb') as f:f.write(p.read_bytes())
with(O/'run.py.source.txt').open('xb') as f:f.write((C/'run.py').read_bytes())
prior=C.parent/'actual-uv-basic-representative-v1-2026-10-19'
inputs=[prior/'post_commit.json',prior/'next_sourcefree_primitive_quantum_replacement_question.json',C/'prelaunch_tool_edit_incident.json',C/'run.py',Path(__file__),O/'RECORD.md',O/'DERIVATION.md']
for raw,h in read(prior/'next_sourcefree_primitive_quantum_replacement_question.json')['input_sha256'].items():assert digest(R/raw)==h
for rel in ['AGENTS.md','CHARTER.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V333.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','tools/portable_dh_v1/inputs.json.gz','tools/portable_dh_v1/exact_algebra.py']:
 inputs.append(R/rel)
artifacts={r:{} for r in ['primary','replay']};allowed={r:[str(O/'preparation.json')] for r in artifacts};facts=[]
for label,name,pa,pb in [('actual','canonical_so10_actual_uv_basic_representative','primary_v3_result.json','replay_v3_result.json'),('domain','canonical_so10_joint_born_ir_trace_domain','primary_v2_result.json','replay_v2_result.json')]:
 folder=R/'calculations'/name;rc=folder/'validation_receipt.json';receipt=read(rc);assert receipt['execution_state']=='COMPLETED';inputs.append(rc)
 for role,fn in [('primary',pa),('replay',pb)]:
  fp=folder/fn;assert receipt['input_sha256'][str(fp)]==digest(fp);inputs.append(fp);allowed[role].append(str(fp));artifacts[role][label]={'path':str(fp),'sha256':digest(fp),'receipt':str(rc),'receipt_sha256':digest(rc)}
for name in ['canonical_so10_joint_born_ir_trace_domain','canonical_so10_dimensional_stokes_primitive','canonical_so10_quadratic_probe_completion','canonical_so10_primitive_probe_pullback','canonical_so10_original_ghost_rescaling','canonical_so10_geometric_ward_products','canonical_so10_actual_uv_basic_representative']:
 folder=R/'calculations'/name;rc=folder/'validation_receipt.json';v=read(rc);assert v['execution_state']=='COMPLETED';inputs.append(rc);facts.append({'receipt':str(rc),'scientific_disposition':v['scientific_disposition']})
 for nm in ['RESULT.md','DERIVATION.md','DERIVATION_V2.md','RECORD.md']:
  if(folder/nm).is_file():inputs.append(folder/nm)
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
for nm in ['A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md','A10_E5_NONMINIMAL_RETRACT_RESULT.md','A10_E5_DOMAIN_CONTRACT_V1.md']:inputs.append(P/nm)
v={'schema':'SOURCEFREE_PRIMITIVE_PROBE_PREPARATION_V1','base':base,'source_sha256':digest(O/'probe.py'),'controller_sha256':digest(C/'run.py'),'input_sha256':{str(p):digest(p) for p in sorted(set(inputs))},'read_json_by_role':allowed,'artifacts':artifacts,'receipt_facts':facts,'limits':{'native_seconds_after_imports':120,'verifier_seconds_after_imports':180,'sampled_private_bytes':8*2**30,'package_bytes':8*2**20},'scope':'Complete actual-L source-free carrier domain first-probe quantum replacement in fixed formal Euclidean one-loop prescription,not fullQAP/A5/E5 or universal minimal cohomology.'}
with(O/'preparation.json').open('xb') as f:f.write((json.dumps(v,sort_keys=True,indent=2)+chr(10)).encode())
print('FROZEN',len(v['input_sha256']),v['source_sha256'])
