from pathlib import Path
from hashlib import sha256
import json,subprocess,os
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_sourcefree_primitive_probe';C=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
base='c4af92b54b616f3ca88027b226671a1d13ae990d'
assert git('rev-parse','HEAD').decode().strip()==base and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
vp=read(O/'validation_preparation_v2.json')
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h,raw
rc=O/'validation_receipt.json';r=read(rc)
assert digest(rc)=='7a7cfcfd27541b2715874167e43243652230ed49c500f188dbe5e4f616edf1fb' and r['execution_state']=='COMPLETED'
for k in ['both_complete_native_routes_match','all11_carriers_and22_light_heavy_fixtures_reconstructed','all22_qL_source_shifts_currents_and_Hessians_independently_verified','rho_and_u_source_Eulers_zero_complements_and_probe_jets_retained','all643_field_flow_corrections_zero_from_actual_sourcefree_support','actual_unlabeled_sector_225_tangents_and_joint_trace_extension_reviewed','same_lifted_Stokes_finite_map_and_extended_Nielsen_derivation_reviewed','order_hbar_correlated_replacement_and_actual_residue_scope_reviewed']:assert r[k],k
assert r['new_failed_native_workers']==0 and r['new_failed_verifier_workers']==1 and r['prelaunch_tool_edit_request_rejection_preserved']==1
assert not r['fullQAP_A5_E5_all_order_or_physical_scheme_qualified'] and not r['authority_changed']
assert r['validation_capture_sha256']==digest(O/'validation_v2_capture.json')
prior=C.parent/'actual-uv-basic-representative-v1-2026-10-19/post_commit.json';p=read(prior);assert p['HEAD']==base and p['clean'] and p['all_older_tracked_bytes_unchanged']
broad=C.parent/'ordered-shear-insertion-v1-2026-10-18/research_check_e4_capture.json';assert digest(broad)=='40bbc2d078c522367be0956631b849f64cc3f908ecf6973c4cb4d81c895b7060'
b=read(broad);assert b['exit_code']==0 and not b['fresh_replay'];events=[json.loads(line) for line in b['stdout_utf8'].splitlines()];c=next(e for e in events if e.get('step')=='historical_custody' and e['event']=='step_finished');assert c['exit_code']==2 and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in c['stdout'] and events[-1]['execution_state']=='COMPLETED'
paths=sorted(p.relative_to(R).as_posix() for p in O.rglob('*') if p.is_file())+['docs/RESEARCH_EXECUTION_HANDOFF_V334.md']
assert set(filter(None,git('ls-files','--others','--exclude-standard','-z').decode().split(chr(0))))==set(paths)
assert sum((R/p).stat().st_size for p in paths)<8*2**20
hashes={p:digest(R/p) for p in paths};assert digest(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
with(C/'pre_commit.json').open('xb') as f:f.write((json.dumps({'base':base,'new_sha256':hashes,'receipt_sha256':digest(rc),'prior_post_commit_sha256':digest(prior),'broad_audit_reused_not_rerun':True},sort_keys=True,indent=2)+chr(10)).encode())
subprocess.run(['git','-c','core.autocrlf=false','add','--',*paths],cwd=R,check=True);assert not git('diff','--cached','--check')
assert set(filter(None,git('diff','--cached','--name-only','-z').decode().split(chr(0))))==set(paths)
for p,h in hashes.items():assert sha256(git('show',':'+p)).hexdigest()==h and digest(R/p)==h
cp=subprocess.run(['git','-c','core.autocrlf=false','commit','-m','Construct first-probe quantum replacement for source-free primitive'],cwd=R,capture_output=True)
with(C/'commit_capture.json').open('xb') as f:f.write((json.dumps({'exit_code':cp.returncode,'stdout':cp.stdout.decode(),'stderr':cp.stderr.decode()},sort_keys=True)+chr(10)).encode())
print(cp.stdout.decode(),flush=True);print(cp.stderr.decode(),flush=True);assert cp.returncode==0
head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()==base
assert set(filter(None,git('diff-tree','--no-commit-id','--name-only','-r','-z','HEAD').decode().split(chr(0))))==set(paths)
for p,h in hashes.items():assert sha256(git('show','HEAD:'+p)).hexdigest()==h and digest(R/p)==h
assert not git('status','--porcelain') and not git('diff','--name-only',base,'HEAD','--',':(exclude)calculations/canonical_so10_sourcefree_primitive_probe/**',':(exclude)docs/RESEARCH_EXECUTION_HANDOFF_V334.md')
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h
post={'schema':'SOURCEFREE_PRIMITIVE_PROBE_POST_COMMIT_V1','HEAD':head,'parent':base,'branch':'main','clean':True,'files':hashes,'receipt_sha256':digest(rc),'all_older_tracked_bytes_unchanged':True,'state_sha256':digest(R/'project_state.json'),'new_failed_native_workers_preserved':0,'new_failed_verifier_workers':1,'prelaunch_tool_edit_request_rejections_preserved':1,'actual_sourcefree_primitive_first_probe_quantum_replacement_qualified':True,'universal_adequacy_E5_A5_or_physical_equivalence_qualified':False,'prior_post_commit_sha256':digest(prior),'prior_broad_audit_capture_sha256':digest(broad),'prior_broad_audit_reused_not_rerun':True,'historical_custody_exit':2,'unresolved_references':7,'commit_command_exit_code':0}
with(C/'post_commit.json').open('xb') as f:f.write((json.dumps(post,sort_keys=True,indent=2)+chr(10)).encode())
print('COMMITTED_AND_BYTE_AUTHENTICATED',head,len(paths),sum((R/p).stat().st_size for p in paths),flush=True)
