from pathlib import Path
from hashlib import sha256
import json,sys
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_sourcefree_primitive_probe';C=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
from audit_a10_e5_antighost_vector import resource,line_json
vp=json.loads((O/'validation_preparation.json').read_bytes());assert sha256(Path(__file__).read_bytes()).hexdigest()==vp['controller_sha256']
assert not(O/'validation_receipt.json').exists() and not(O/'validation_capture.json').exists()
cap=capture([sys.executable,'-B',str(C/'verify.py')]);raw=json.dumps(cap,sort_keys=True,separators=(',',':')).encode()+b'\n'
for p in [O/'validation_capture.json',C/'validation_full_capture.json']:
 with p.open('xb') as f:f.write(raw)
if cap['execution_state']!='COMPLETED':print(cap['stdout_and_stderr'],flush=True)
resource(cap);res=line_json(cap['stdout_and_stderr'],'VALIDATION ');assert 0<res['verifier_seconds_after_imports']<180
res['input_sha256']=vp['input_sha256'];res['scope']=vp['scope'];res['validation_capture_sha256']=sha256(raw).hexdigest()
with(O/'validation_receipt.json').open('xb') as f:f.write(json.dumps(res,sort_keys=True,indent=2).encode()+b'\n')
print('QUALIFIED',res['scientific_disposition'],res['verifier_seconds_after_imports'],flush=True)
