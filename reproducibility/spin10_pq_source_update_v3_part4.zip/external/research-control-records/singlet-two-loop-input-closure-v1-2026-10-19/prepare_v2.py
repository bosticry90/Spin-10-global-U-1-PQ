from pathlib import Path
from hashlib import sha256
import ast,json
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_singlet_two_loop_input_closure';C=Path(__file__).resolve().parent
digest=lambda p:sha256(p.read_bytes()).hexdigest();old=json.loads((O/'preparation.json').read_bytes());inputs=dict(old['input_sha256'])
cap=json.loads((O/'primary_capture.json').read_bytes());assert cap['execution_state']=='FAILED' and cap['exit_code']!=0
for path in [O/'preparation.json',O/'primary_capture.json',O/'CONTINUATION_V2.md',O/'closure_v2.py',C/'build_v2.py',C/'prepare_v2.py',C/'run_v2.py']:
 if path.suffix=='.py':ast.parse(path.read_text())
 inputs[str(path)]=digest(path)
for path in [O/'CONTINUATION_V2.md',O/'closure_v2.py',C/'build_v2.py',C/'prepare_v2.py',C/'run_v2.py']:
 dest=O/(path.name+'.source.txt')
 with dest.open('xb') as f:f.write(path.read_bytes())
 inputs[str(dest)]=digest(dest)
for raw,h in inputs.items():assert digest(Path(raw))==h,raw
p={**old,'schema':'SINGLET_TWO_LOOP_INPUT_CLOSURE_PREPARATION_V2','input_sha256':inputs,
 'controller_sha256':digest(C/'run_v2.py'),'preserved_failed_native_workers':1}
with(O/'preparation_v2.json').open('xb') as f:f.write((json.dumps(p,indent=2,sort_keys=True)+'\n').encode())
print('FROZEN_V2',len(inputs),flush=True)
