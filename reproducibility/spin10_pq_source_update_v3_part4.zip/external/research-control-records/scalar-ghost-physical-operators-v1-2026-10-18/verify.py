"""Independent physical operator congruences using the actual reference matrices."""
from pathlib import Path
from collections import defaultdict
from functools import lru_cache
import json,sys,os,time,threading,subprocess,importlib.util
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_physical_operators';CONTROL=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('qualified_independent_five_radical_arithmetic',CONTROL.parent/'ghost-mass-g4-pole-v1-2026-10-18/verify.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v);s=v.s;read=v.read;digest=v.digest;PKG=v.PKG;put=v.put;num=v.number;mm=v.mm;tr=v.tr;mul=v.mul;neg=v.neg;O=v.O
from audit_a10_e5_antighost_vector import resource,line_json
def auth(folder,name,receipt='validation_receipt.json'):
 p=ROOT/'calculations'/folder/name;r=read(p.parent/receipt);assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p)
def unpack(rows):return {tuple(r[:-1]):num(r[-1]) for r in rows}
def ordered(w):
 if len(w)!=len(set(w)):return (),0
 count=sum(a>b for i,a in enumerate(w) for b in w[i+1:]);return tuple(sorted(w)),(-1)**count
def pull4(P,I):
 out={}
 for word,z in P.items():
  layer={():z}
  for a in word:
   nxt={}
   for w,x in layer.items():
    for b,c in I[a].items():ww,sg=ordered(w+(b,));put(nxt,ww,v.scale(mul(x,c),sg)) if sg else None
   layer=nxt
  for w,z in layer.items():put(out,w,z)
 return out
def raw_polynomials(raw,scalar):
 out={'X':{},'Q':{},'R':{},'Y':{}}
 for tag in out:
  for r in raw[tag]:
   w=r['word'];z=num(r['stripped_coefficient'])
   if tag in ['X','Y']:
    a=next(n for n in w if n in v.ANTI);c=next(n for n in w if n.startswith('C'));i=next(n for n in w if n in(v.AUX if tag=='X' else scalar));idx=v.AUX.index(i) if tag=='X' else scalar[i];key=(idx,v.ANTI.index(a),int(c[1:]));put(out[tag],key,z if w.index(a)<w.index(c) else neg(z))
   else:word,sg=ordered(tuple(45+v.ANTI.index(n) if n in v.ANTI else int(n[1:]) for n in w));assert sg;put(out[tag],word,v.scale(z,sg))
 return out
def raw_hessian(P,kind,moved=False,left=False):
 out={}
 for key,z in P.items():
  if kind in ['X','Y']:i,a,c=key;word=[('l' if kind=='X' else's',i),('f',45+a),('f',c)]
  else:word=[('f',n) for n in key]
  if moved and kind in ['X','Y']:word=[word[1],word[0],word[2]]
  par=[int(k=='f') for k,n in word]
  for i,(ki,ni) in enumerate(word):
   for j,(kj,nj) in enumerate(word):
    if i==j or(kind=='X' and(ki=='l')==(kj=='l')):continue
    if left:exponent=par[i]*sum(par[:i])+par[j]*sum(q for k,q in enumerate(par[:j]) if k!=i)+par[j]*(par[i]+1)
    else:exponent=par[i]*sum(par[i+1:])+par[j]*sum(q for k,q in enumerate(par[j+1:],start=j+1) if k!=i)+par[i]
    ext=tuple(t for k,t in enumerate(word) if k not in [i,j]);sg=(-1)**exponent
    if len(ext)==2:
     ww,sign=ordered(tuple(n for k,n in ext));ext=tuple(('f',n) for n in ww);sg*=sign
    put(out,(ki,ni,kj,nj,ext),v.scale(z,sg))
 return out
def congruence(H,maps,kind):
 out={tag:{} for tag in ['X','Xr','Z','U','V','Q','R']}
 @lru_cache(None)
 def external(word):
  layer={():O}
  for typ,n in word:
   nxt={}
   for prev,z in layer.items():
    for i,c in maps[typ][n].items():
     ww=prev+((typ,i),);sg=1
     if len(ww)==2 and all(k=='f' for k,n in ww):order,sg=ordered(tuple(n for k,n in ww));ww=tuple(('f',j) for j in order)
     if sg:put(nxt,ww,v.scale(mul(z,c),sg))
   layer=nxt
  return tuple(layer.items())
 for(ki,ni,kj,nj,ext),z in H.items():
  for i,a in maps[ki][ni].items():
   for j,b in maps[kj][nj].items():
    co=mul(mul(z,a),b)
    for word,c in external(ext):
     if kind=='X':tag='X' if ki=='l' else'Xr';key=(i,j,word[0][1])
     elif kind=='Y':tag='U' if ki=='s' else'V' if kj=='s' else'Z';key=(i,j,word[0][1])
     else:tag=kind;key=(i,j,*[n for t,n in word])
     put(out[tag],key,mul(co,c))
 return out
@lru_cache(None)
def scalar_coefficient(txt):
 g=s.Symbol('g10');z=s.sympify(txt);co=s.cancel(z/g);assert not co.free_symbols and s.expand(z-g*co)==0;return num(str(co))
def kinetic(data,e2,scalar,C,TC,ref):
 Q={(i,j):num(z) for i,j,z in data['C3_plane_to_parent']['entries']};S=mm(Q,C);assert mm(tr(S),S)=={(i,i):O for i in range(45)} and mm(tr(Q),Q)=={(i,j):num(z) for i,j,z in data['parent_gauge_metric']['entries']};names=ref['field_order'];II={(i,j):num(z) for i,j,z in ref['physical_to_raw_inverse']['entries']}
 for mu in range(4):assert {(a,(j-mu)//4):z for a in range(45) for(i,j),z in II.items() if i==names.index(f'B{a}_{mu}')}==C
 phys={};parent={};byplane=defaultdict(list)
 for(a,b),z in S.items():byplane[a].append((b,z))
 for sec,matrices in data['representation_matrices'].items():
  for a,M in enumerate(matrices):
   for i,j,txt in M['entries']:
    pi,pj=scalar[f'x_{sec}_{i}'],scalar[f'x_{sec}_{j}'];z=num(txt);put(parent,(a,pi,pj),z)
    for b,c in byplane[a]:put(phys,(b,pi,pj),mul(z,c))
 actual={};raw={}
 for name,i in scalar.items():
  for r in e2['complete_columns'][name]['source_polynomial']:
   assert len(r['word'])==2 and not any('__' in n for n in r['word']);ghost=next(n for n in r['word'] if n.startswith('C'));x=next(n for n in r['word'] if n in scalar);a=int(ghost[1:]);co=scalar_coefficient(r['coefficient']);put(raw,(a,i,scalar[x]),co)
   for(aa,c),w in C.items():
    if aa==a:put(actual,(c,i,scalar[x]),neg(mul(co,w)))
 assert actual==phys and all(v.conj(z)==z and z==neg(phys.get((a,j,i),())) for(a,i,j),z in phys.items());back={}
 for(b,i,j),z in phys.items():
  for(a,bb),c in S.items():
   if bb==b:put(back,(a,i,j),mul(z,c))
 assert back==parent;rawback={}
 for(b,i,j),z in phys.items():
  for(bb,a),c in TC.items():
   if bb==b:put(rawback,(a,i,j),neg(mul(z,c)))
 assert rawback==raw;return S,phys,parent
def hash_matrix(A):return __import__('hashlib').sha256(json.dumps([[*k,[[m,z.numerator,z.denominator] for m,z in co]] for k,co in sorted(A.items())],separators=(',',':')).encode()).hexdigest()
def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(OUT/'validation_preparation.json')
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 assert digest(Path(__file__))==prep['validator_sha256'] and subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==prep['base_commit'];allowed={str(Path(p).resolve()) for p in prep['input_sha256']}|{str((OUT/'validation_preparation.json').resolve())}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('SCALAR_GHOST_PHYSICAL_VALIDATOR_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_JSON',str(p))
 sys.addaudithook(guard);data={};perf={}
 for role,suffix in [('primary',''),('replay','_v2')]:
  cap=read(OUT/(role+suffix+'_capture.json'));resource(cap);d=read(OUT/(role+suffix+'_result.json'));assert d==line_json(cap['stdout_and_stderr'],'RESULT ') and(OUT/(role+suffix+'_capture.json')).read_bytes()==(CONTROL/(role+suffix+'_full_capture.json')).read_bytes();data[role]=d;perf[role]={'seconds':d['elapsed_after_imports'],'private_bytes':max(z['private_bytes'] for z in cap['all_resource_samples'])}
 for k in set(data['primary'])-{'schema','route','stages','elapsed_after_imports'}:assert data['primary'][k]==data['replay'][k],k
 d=data['primary'];failed=read(OUT/'replay_capture.json');assert failed['execution_state']=='FAILED' and failed['exit_code']==1 and not(OUT/'replay_result.json').exists() and (OUT/'replay_capture.json').read_bytes()==(CONTROL/'replay_full_capture.json').read_bytes() and "KeyError: 'convention'" in failed['stdout_and_stderr'];ref=v.sealed('frozen_a10_e5_full_hessian','primary')['retained_reference'];e2=v.sealed('frozen_a10_e2_transport','primary');physical=v.sealed('frozen_a10_physical_reconciliation','full_primary');other=v.sealed('frozen_a10_physical_reconciliation','full_replay');assert all(physical[k]==other[k] for k in ['C3_plane_to_parent','parent_gauge_metric','representation_digests','representation_matrices','sector_dimensions']) and physical['convention']['scalar_variation']=='-g10*rho(omega)*x' and physical['convention']['covariant_derivative']=='d+g10*rho(B)'
 ref2=v.sealed('frozen_a10_e5_full_hessian','replay')['retained_reference'];e22=v.sealed('frozen_a10_e2_transport','replay');assert ref['field_order']==ref2['field_order'] and all(ref[k]==ref2[k] for k in ['physical_to_raw_kernel','physical_to_raw_inverse']) and e2['gauge_fixing_density']==e22['gauge_fixing_density'];assert all(e2['complete_columns'][n]['source_polynomial']==e22['complete_columns'][n]['source_polynomial'] for n in ref['field_order'] if n.startswith('x_'))
 print('STAGE independent_full_reference_frames_kinetic_plane_and_scalar_Q',flush=True);scalar,IL,IA,IC,TL,TA,TC=v.frame(ref);S,K,parent=kinetic(physical,e2,scalar,IC,TC,ref);assert S==unpack(d['actual_plane_to_HM_isometry']) and K==unpack(d['physical_K']);unified=auth('canonical_so10_unified_scalar_ghost_symbol','primary_v2_result.json');raw=raw_polynomials(unified['actual_raw_GF_vertex_census'],scalar);IO={i:{j:z for(ii,j),z in IC.items() if ii==i} for i in range(45)}|{45+i:{45+j:z for(ii,j),z in IA.items() if ii==i} for i in range(45)};LO={i:{j:z for(ii,j),z in IL.items() if ii==i} for i in range(45)};maps={'l':LO,'f':IO,'s':{i:{i:O} for i in range(328)}};allops={}
 print('STAGE independent_raw_right_Hessians_and_full_congruence_with_external_pullback',flush=True)
 for tag in ['X','Q','R','Y']:
  H=raw_hessian(raw[tag],tag);assert H==raw_hessian(raw[tag],tag,left=True)
  if tag in ['X','Y']:assert H==raw_hessian(raw[tag],tag,moved=True)
  result=congruence(H,maps,tag)
  for k,A in result.items():
   if A:assert k not in allops;allops[k]=A
 for tag,key in [('X','physical_X'),('Xr','physical_Xr'),('Z','physical_Z'),('Q','physical_Q')]:assert allops[tag]==unpack(d[key]),tag
 assert allops['Xr']=={(j,i,k):neg(z) for(i,j,k),z in allops['X'].items()} and allops['V']=={(j,i,k):neg(z) for(i,j,k),z in allops['U'].items()} and all(z==neg(allops['Q'].get((j,i,a,b),())) for(i,j,a,b),z in allops['Q'].items());pole=auth('canonical_so10_ghost_mass_g4_pole','primary_v2_result.json');old=auth('canonical_so10_ghost_mass_g4_reduction','primary_v2_result.json');E,Y=v.orbit(old['all_literal_orbit_rows_stripped_only_g_and_explicit_xi'],scalar,IL,IA,IC,TL,TA,TC,e2);assert E==v.unpack(pole['physical_E']) and {(x,a,c):z for x,P in Y.items() for(a,c),z in P.items()}==v.unpack(pole['physical_Y_aC_density'])
 for(x,a,c),z in v.unpack(pole['physical_Y_aC_density']).items():assert allops['Z'].get((c,45+a,x))==neg(z) and allops['Z'].get((45+a,c,x))==z and allops['U'].get((x,c,45+a))==z and allops['U'].get((x,45+a,c))==neg(z)
 assert len(allops['Z'])==len(allops['U'])==len(allops['V'])==12536;X={(l,k-45,j):z for(l,j,k),z in allops['X'].items() if j<45 and k>=45};Q={(i,j,a,b):z for(i,j,a,b),z in allops['Q'].items() if i<j<45 and 45<=a<b};R={(i,j,a,b):z for(i,j,a,b),z in allops['R'].items() if i<j<45 and 45<=a<b};assert X==unpack(d['physical_X_aC_density']) and Q=={tuple(w):num(z) for w,z in d['physical_Q_density']};backIO={i:{j:z for(ii,j),z in TC.items() if ii==i} for i in range(45)}|{45+i:{45+j:z for(ii,j),z in TA.items() if ii==i} for i in range(45)};assert pull4(Q,backIO)==raw['Q'] and pull4(R,backIO)==raw['R'];backX={}
 for(l,a,c),z in X.items():
  for(ll,raw_l),x in TL.items():
   if ll!=l:continue
   for(aa,raw_a),y in TA.items():
    if aa!=a:continue
    for(cc,raw_c),w in TC.items():
     if cc==c:put(backX,(raw_l,raw_a,raw_c),mul(mul(mul(z,x),y),w))
 assert backX==raw['X'];lor=auth('canonical_so10_fourghost_g4_lorentz','primary_result.json');RR={}
 for i,j,word,z in lor['classical_operator_tables']['Rbar']:w,sg=ordered(tuple(int(n[2:])+(45 if n.startswith('ap') else 0) for n in word));put(RR,(i,j,*w),v.scale(num(z),sg))
 assert RR==allops['R'] and len(RR)==20064
 for tag,A in [('K',K),('X',allops['X']),('Xr',allops['Xr']),('Z',allops['Z']),('Q',allops['Q']),('R',allops['R'])]:assert hash_matrix(A)==d['operator_exact_hashes'][tag]
 counts={'K':len(K),'X_density':len(X),'Q_density':len(Q),'R_density_control':len(R),'X':len(allops['X']),'Xr':len(allops['Xr']),'Z':len(allops['Z']),'U':len(allops['U']),'V':len(allops['V']),'Q':len(allops['Q']),'R_match_control':len(allops['R'])};assert counts==d['operator_position_counts'] and d['complete_sparse_domains']=={'K':[45,328,328],'X':[45,90,90],'Xr':[90,45,90],'Z':[90,90,328],'Q_and_R':[90,90,4005],'quartet_density_C2_a2':[990,990]};assert K!=parent and all(d['controls'].values()) and not d['insensitive_controls'] and d['exact_basis_squared']==[2,3,5,-1,7];assert not d['new_actual_color_pole_or_integration'] and not d['new_loop_full_functional_or_full_QAP_E5_A5'] and not any(d['all_seven_quantum_flags_false'].values()) and d['current_known_sha256']=='fe6bd8e800d8e04f9d0358ce94c081d70e94af0ffd37830bb50c02fdbb0c0241'
 result={'schema':'ACTUAL_SCALAR_GHOST_PHYSICAL_OPERATORS_INDEPENDENT_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':'ALL_FOUR_PHYSICAL_OPERATOR_GROUPS_AND_FULL_ACTION_FRAME_CORRESPONDENCE_QUALIFIED_NOT_POLE','all643_reference_maps_and_both_inverse_products_verified':True,'plane_isometry_full12560_kinetic_and29754_scalar_Q_entries_verified':True,'all_actual_raw_Hessians_right_left_even_reorder_and_full_congruence_verified':True,'all_new_density_inverse_domains_and_odd_zero_complements_verified':True,'all12536_Z_U_V_positions_same_actual_Y_verified':True,'all20064_R_positions_and_full_zero_complement_verified':True,'all_operator_exact_hashes_and_domains_verified':True,'legacy_replay_metadata_shared_with_equal_actual_matrices_verified':True,'original_failed_replay_preserved_primary_reused':True,'controls_and_physical_field_not_source_dual_dependency_verified':True,'operator_position_counts':counts,'operator_exact_hashes':d['operator_exact_hashes'],'physical_K_complex_positions':sum(any(m&8 for m,z in co) for co in K.values()),'new_actual_pole_integration_full_QAP_E5_A5':'NOT_PERFORMED_UNQUALIFIED','native_worker_failures':1,'independent_worker_failures':0,'fresh_byte_identical_replay_pairs_claimed':0,'performance':perf,'input_sha256':prep['input_sha256'],'shared_limits':'Actual action/reference/representation/source and old qualification premises shared. Separate five-radical arithmetic,raw right-Hessian congruences without common frame helper,not new quantum poles or external expert validation','elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
