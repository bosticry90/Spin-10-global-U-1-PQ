"""Index-only planning counts;no coefficient evaluation or scientific qualification."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,time,threading,os
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
timer=threading.Timer(30,lambda:os._exit(124));timer.daemon=True;timer.start();tick=time.perf_counter()
P=ROOT/'calculations/canonical_so10_scalar_ghost_physical_operators';r=read(P/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(P/'primary_result.json')]==digest(P/'primary_result.json');d=read(P/'primary_result.json');m=read(ROOT/'calculations/canonical_so10_ghost_mass_g4_pole/primary_v2_result.json');l=read(ROOT/'calculations/canonical_so10_fourghost_g4_lorentz/primary_result.json');u=read(ROOT/'calculations/canonical_so10_unified_scalar_ghost_symbol/primary_v2_result.json');M={k:defaultdict(int) for k in ['A','L','T','R','E','Et','K','Kt','X','Xr','Q','Z','U','V','W','J']}
for tag in ['A','L','T','R']:
 for i,j,w,z in l['classical_operator_tables']['Rbar' if tag=='R' else tag]:M[tag][i,j]+=1
for a,i,z in m['physical_E']:M['E'][a,i]+=1;M['Et'][i,a]+=1
for a,i,j,z in d['physical_K']:M['K'][a,i]+=1;M['Kt'][i,a]+=1
for tag in ['X','Xr','Q','Z']:
 for row in d['physical_'+tag]:M[tag][row[0],row[1]]+=1
for x,a,c,z in m['physical_Y_aC_density']:M['U'][x,c]+=1;M['U'][x,45+a]+=1;M['V'][c,x]+=1;M['V'][45+a,x]+=1
for i in range(45):M['W'][i,i]=1;M['J'][i,45+i]=1;M['J'][45+i,i]=1
def product(A,B):
 rr=defaultdict(list);C=defaultdict(int)
 for(k,j),z in B.items():rr[k].append((j,z))
 for(i,k),z in A.items():
  for j,v in rr[k]:C[i,j]+=z*v
 return C
result={};total=0
for name in ['DMK','FYK','FFMK','FFY','YR','FMKX','FYX','YQ','YKX']:
 rows=[]
 for word,co in u['normalized_ordered_family_formulas'][name]:
  A=M[word[0]]
  for tag in word[1:]:A=product(A,M[tag])
  count=sum(z for(i,j),z in A.items() if i==j);rows.append({'word':word,'unfiltered_closed_coefficient_tuples':count});total+=count
 result[name]=rows
A=product(product(M['A'],M['K']),M['Kt']);pair=sum(z for(i,j),z in A.items() if i==j)
out={'classification':'INDEX_ONLY_PLANNING_NOT_SCIENTIFIC_EVIDENCE_OR_EXECUTION_ALLOWANCE','physical_operator_receipt_sha256':digest(P/'validation_receipt.json'),'linear_family_support_counts':result,'total_unfiltered_linear_closed_tuples':total,'D_scalar_pair_unfiltered_closed_tuples':pair,'scalar_linear_physical_aC_domain':45*45*328,'scalar_pair_physical_aC_symmetric_xx_domain':45*45*328*329//2,'no_coefficients_values_multiplication_or_quantum_result':True,'seconds':time.perf_counter()-tick}
with(CONTROL/'trace_support_cost_plan.json').open('xb') as f:f.write(json.dumps(out,sort_keys=True,separators=(',',':')).encode()+b'\n')
print(json.dumps({'linear_closed_tuples':total,'pair_closed_tuples':pair,'pair_full_component_domain':out['scalar_pair_physical_aC_symmetric_xx_domain'],'seconds':out['seconds']}));timer.cancel()
