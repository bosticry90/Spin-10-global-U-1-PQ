from pathlib import Path
from hashlib import sha256
import json,ast,symtable,builtins,subprocess,importlib.util,sys
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_physical_operators';CONTROL=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='ca63a61b4ea132067a33cd5bb53e567a1d589163';parent=ROOT/'calculations/canonical_so10_unified_scalar_ghost_symbol/validation_receipt.json';r=read(parent);assert r['execution_state']=='COMPLETED' and digest(parent)=='c909a1d117b9bb3d750d578964c5fc1b12deaf64f4796dd39bdd4ce092db2908'
files={Path(p) for p in r['input_sha256']}|{parent,OUT/'RECORD.md',ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V279.md'}
for p,h in r['input_sha256'].items():assert digest(Path(p))==h,p
oldprep=read(ROOT/'calculations/canonical_so10_ghost_mass_g4_pole/preparation_v2.json');paths={};probes=[]
for role in ['primary','replay']:
 paths[role]={Path(p) for p in oldprep['read_json_by_role'][role]}|{OUT/'preparation.json'}
 for folder,name in [('canonical_so10_ghost_mass_g4_integration',role+'_result.json'),('canonical_so10_ghost_mass_g4_pole',role+'_v2_result.json'),('canonical_so10_unified_scalar_ghost_symbol',role+'_v2_result.json'),('canonical_so10_antighost_g2_scalar_zero','primary_result.json' if role=='primary' else 'replay_v2_result.json'),('canonical_so10_fourghost_g4_lorentz',role+'_result.json'),('canonical_so10_ghost_mass_g4_reduction',role+'_v2_result.json')]:
  p=ROOT/'calculations'/folder/name;rr=p.parent/'validation_receipt.json';rc=read(rr);assert rc['execution_state']=='COMPLETED' and rc['input_sha256'][str(p)]==digest(p);paths[role].update([p,rr]);files.update([p,rr]);probes.append({'path':str(p),'receipt':str(rr),'sha256':digest(p)})
 for folder,name in [('frozen_a10_physical_reconciliation','full_'+role),('frozen_a10_e2_transport',role),('frozen_a10_e5_full_hessian',role)]:
  p=PKG/folder/(name+'.json');rr=p.parent/'bindings.json';b=read(rr);assert b['byte_sha256'][p.relative_to(ROOT).as_posix()]==digest(p);paths[role].update([p,rr]);files.update([p,rr])
 files|=paths[role]-{OUT/'preparation.json'}
for p in [OUT/'operators.py',CONTROL/'run.py',Path(__file__)]:
 text=p.read_text(encoding='utf-8');ast.parse(text);tree=symtable.symtable(text,str(p),'exec');defs={z.get_name() for z in tree.get_symbols() if z.is_assigned() or z.is_imported() or z.is_namespace()}|set(dir(builtins))|{'__file__','__name__','__package__'};errors=[]
 def scan(t):
  for z in t.get_symbols():
   if z.is_referenced() and z.is_global() and z.get_name() not in defs:errors.append((t.get_name(),z.get_name()))
  for q in t.get_children():scan(q)
 scan(tree);assert not errors,errors
sp=importlib.util.spec_from_file_location('actual_scalar_operator_types_preflight',OUT/'operators.py');u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);types={}
for role in ['primary','replay']:
 e2=read(PKG/'frozen_a10_e2_transport'/(role+'.json'));ref=read(PKG/'frozen_a10_e5_full_hessian'/(role+'.json'))['retained_reference'];data=read(PKG/'frozen_a10_physical_reconciliation'/('full_'+role+'.json'));current=read(ROOT/'calculations/canonical_so10_unified_scalar_ghost_symbol'/(role+'_v2_result.json'));counts={}
 values=[co for name in ['physical_to_raw_kernel','physical_to_raw_inverse'] for i,j,co in ref[name]['entries']]+[co for key in ['C3_plane_to_parent','parent_gauge_metric'] for i,j,co in data[key]['entries']]+[co for ms in data['representation_matrices'].values() for M in ms for i,j,co in M['entries']]+[r['stripped_coefficient'] for rows in current['actual_raw_GF_vertex_census'].values() for r in rows]
 for co in values:
  z=u.num(co);assert all(a==b==0 for a,b,m in z.cells)
 cols={n:v['source_polynomial'] for n,v in e2['complete_columns'].items() if n.startswith('x_')};assert len(cols)==328
 for n,rows in cols.items():
  for row in rows:u.scalar_coefficient(row['coefficient']);assert len(row['word'])==2 and not any('__' in x for x in row['word'])
 types[role]={'numeric_map_representation_and_GF_coefficients_checked':len(values),'all328_scalar_columns':len(cols),'scalar_source_positions_checked':sum(map(len,cols.values())),'exact_basis_squared':list(u.e.SQUARES)}
for mode,P in [('X',{(0,0,0):u.ONE}),('Y',{(0,0,0):u.ONE}),('Q',{(0,1,45,46):u.ONE})]:
 left=u.hessian(P,mode,'primary');right=u.hessian(P,mode,'replay');assert left==right
 if mode!='Q':assert left==u.hessian(P,mode,'primary',True) and left!=u.hessian(P,mode,'primary',True,True)
json.dumps({'types':types,'example_numeric_rows':u.packed({(0,1):u.ONE})})
for mod in list(sys.modules.values()):
 name=getattr(mod,'__file__',None)
 if name:
  p=Path(name).resolve()
  if p.suffix=='.py' and(p.is_relative_to(ROOT) or p.is_relative_to(CONTROL.parent)):files.add(p)
for p in [OUT/'operators.py',CONTROL/'run.py',Path(__file__)]:
 copy=Path(str(p)+'.source.txt')
 with copy.open('xb') as f:f.write(p.read_bytes())
 files.update([p,copy])
d={'schema':'ACTUAL_SCALAR_GHOST_OPERATORS_PREPARATION_V1','base_commit':head,'source_sha256':digest(OUT/'operators.py'),'controller_sha256':digest(CONTROL/'run.py'),'input_sha256':{str(p):digest(p) for p in sorted(files)},'read_json_by_role':{role:[str(p) for p in sorted(pp)] for role,pp in paths.items()},'qualified_input_probes':probes,'preflight_all_new_arithmetic_types_and_source_shapes':types,'mixed_even_odd_left_right_and_moved_order_preflight_passed':True,'limits':{'seconds_after_imports':180,'private_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2},'all_source_copies_exclusive':True,'metadata_json_type_preflight_passed':True}
with(OUT/'preparation.json').open('xb') as f:f.write(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('FROZEN',len(files),'types',types)
