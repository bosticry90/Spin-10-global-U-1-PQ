from pathlib import Path
from hashlib import sha256
import json,subprocess
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_physical_operators';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def git(*args,raw=False):
 z=subprocess.check_output(['git',*args],cwd=ROOT);return z if raw else z.decode('utf-8').strip()
base=read(OUT/'preparation.json')['base_commit'];assert git('rev-parse','HEAD')==base=='ca63a61b4ea132067a33cd5bb53e567a1d589163'
r=read(OUT/'validation_receipt.json');assert r['schema']=='ACTUAL_SCALAR_GHOST_PHYSICAL_OPERATORS_INDEPENDENT_VALIDATION_V1' and r['execution_state']=='COMPLETED' and r['scientific_disposition']=='ALL_FOUR_PHYSICAL_OPERATOR_GROUPS_AND_FULL_ACTION_FRAME_CORRESPONDENCE_QUALIFIED_NOT_POLE'
for k,z in r.items():
 if type(z) is bool:assert z,k
assert r['native_worker_failures']==1 and r['independent_worker_failures']==0 and r['fresh_byte_identical_replay_pairs_claimed']==0 and r['new_actual_pole_integration_full_QAP_E5_A5']=='NOT_PERFORMED_UNQUALIFIED'
assert digest(OUT/'validation_receipt.json')=='5e9111e97c80f31d241cb366fcc861608a04b82ca1cede4cbfec8b0d4b90d262'
maps={}
for name in ['preparation.json','preparation_v2.json','validation_preparation.json','validation_receipt.json']:
 d=read(OUT/name);maps[name]=len(d['input_sha256'])
 for p,h in d['input_sha256'].items():assert digest(Path(p))==h,(name,p)
assert list(maps.values())==[1756,1769,1780,1780]
for folder in [OUT,CONTROL]:
 for p in folder.glob('*.source.txt'):assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes(),p
for capname,external,resultname in [('primary_capture.json','primary_full_capture.json','primary_result.json'),('replay_v2_capture.json','replay_v2_full_capture.json','replay_v2_result.json'),('validation_capture.json','validation_full_capture.json','validation_receipt.json')]:
 cap=read(OUT/capname);assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and cap['private_allocation_limit_bytes']==8*1024**3
 assert (OUT/capname).read_bytes()==(CONTROL/external).read_bytes() and cap['all_resource_samples'] and all('query_error' not in z and 0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
 assert 0<read(OUT/resultname)['elapsed_after_imports']<180
cap=read(OUT/'replay_capture.json');assert cap['execution_state']=='FAILED' and cap['exit_code']==1 and not cap['calculation_completed'] and (OUT/'replay_capture.json').read_bytes()==(CONTROL/'replay_full_capture.json').read_bytes() and not(OUT/'replay_result.json').exists()
d=read(OUT/'primary_result.json');rr=read(OUT/'replay_v2_result.json');assert all(d[k]==rr[k] for k in d.keys()-{'route','elapsed_after_imports'})
assert d['operator_position_counts']==r['operator_position_counts'] and d['operator_exact_hashes']==r['operator_exact_hashes'] and all(d['controls'].values()) and not any(d['all_seven_quantum_flags_false'].values())
assert d['current_known_terms']==155143 and d['current_known_sha256']=='fe6bd8e800d8e04f9d0358ce94c081d70e94af0ffd37830bb50c02fdbb0c0241' and d['sourcefree_positions']==41452 and d['sourceimage_positions']==146663 and not d['new_actual_color_pole_or_integration'] and not d['new_loop_full_functional_or_full_QAP_E5_A5']
for p in ['AGENTS.md','CHARTER.md','README.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md']:assert git('show',base+':'+p,raw=True)==(ROOT/p).read_bytes(),p
paths=sorted([p.relative_to(ROOT).as_posix() for p in OUT.iterdir() if p.is_file()]+['docs/RESEARCH_EXECUTION_HANDOFF_V280.md']);assert set(git('ls-files','--others','--exclude-standard').splitlines())==set(paths) and not git('diff','--name-only') and not git('diff','--cached','--name-only')
for p in [ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V280.md',OUT/'RESULT_V3.md']:assert digest(OUT/'validation_receipt.json') in p.read_text(encoding='utf-8')
subprocess.check_call(['git','-c','core.autocrlf=false','-c','core.longpaths=true','add','--',*paths],cwd=ROOT);assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
for p in paths:assert git('show',':'+p,raw=True)==(ROOT/p).read_bytes(),p
subprocess.check_call(['git','diff','--cached','--check'],cwd=ROOT);subprocess.check_call(['git','commit','-m','Qualify actual scalar ghost physical operators and action frame correspondence'],cwd=ROOT)
head=git('rev-parse','HEAD');assert git('rev-parse','HEAD^')==base and set(git('diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines())==set(paths)
for p in paths:assert git('show','HEAD:'+p,raw=True)==git('show',':'+p,raw=True)==(ROOT/p).read_bytes(),p
assert not git('status','--porcelain=v1')
proof={'HEAD':head,'parent':base,'exact_changed_files':paths,'all_HEAD_index_worktree_bytes_equal':True,'working_tree_clean':True,'receipt_sha256':digest(OUT/'validation_receipt.json'),'authority_unchanged':digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8','all_four_current_input_binding_maps':maps,'all_actual_K_X_Q_Z_and_R_control_verified':True,'failed_replay_and_both_source_versions_preserved':True,'corrected_replay_reuses_primary':True,'current_functional_and329_335_scope_counts_unchanged':True,'index_only_plan_sha256':digest(CONTROL/'trace_support_cost_plan.json'),'index_only_source_sha256':digest(CONTROL/'trace_support_cost.py'),'planning_is_scientific_evidence':False,'full_E5_A5':'UNQUALIFIED','no_remote_action':True,'commit_controller_sha256':digest(Path(__file__))};assert proof['authority_unchanged']
with(CONTROL/'post_commit.json').open('xb') as f:f.write(json.dumps(proof,sort_keys=True,separators=(',',':')).encode()+b'\n')
print(json.dumps({'HEAD':head,'files':len(paths),'clean':True,'receipt_sha256':proof['receipt_sha256'],'full_E5_A5':'UNQUALIFIED'}))
