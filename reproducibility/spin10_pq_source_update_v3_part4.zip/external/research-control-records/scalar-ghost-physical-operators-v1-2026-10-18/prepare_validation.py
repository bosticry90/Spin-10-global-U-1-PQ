from pathlib import Path
from hashlib import sha256
import json,ast,symtable,builtins,importlib.util,sys
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_physical_operators';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
p=read(OUT/'preparation_v2.json');files={Path(f) for f in p['input_sha256']}|{OUT/'preparation_v2.json',OUT/'RESULT_V2.md'}
for f,h in p['input_sha256'].items():assert digest(Path(f))==h,f
for role,suf in [('primary',''),('replay','_v2')]:
 for f in [OUT/(role+suf+'_result.json'),OUT/(role+suf+'_capture.json'),CONTROL/(role+suf+'_full_capture.json')]:files.add(f)
 cap=read(OUT/(role+suf+'_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and(OUT/(role+suf+'_capture.json')).read_bytes()==(CONTROL/(role+suf+'_full_capture.json')).read_bytes()
for f in [CONTROL/'verify.py',CONTROL/'run_validation.py',Path(__file__)]:
 text=f.read_text(encoding='utf-8');ast.parse(text);tree=symtable.symtable(text,str(f),'exec');defs={z.get_name() for z in tree.get_symbols() if z.is_assigned() or z.is_imported() or z.is_namespace()}|set(dir(builtins))|{'__file__','__name__','__package__'};errors=[]
 def scan(t):
  for z in t.get_symbols():
   if z.is_referenced() and z.is_global() and z.get_name() not in defs:errors.append((t.get_name(),z.get_name()))
  for q in t.get_children():scan(q)
 scan(tree);assert not errors,errors
sp=importlib.util.spec_from_file_location('independent_physical_operator_imports_only',CONTROL/'verify.py');u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u)
for tag,P in [('X',{(0,0,0):u.O}),('Y',{(0,0,0):u.O}),('Q',{(0,1,45,46):u.O})]:
 H=u.raw_hessian(P,tag);assert H==u.raw_hessian(P,tag,left=True)
 if tag!='Q':assert H==u.raw_hessian(P,tag,moved=True)
for mod in list(sys.modules.values()):
 name=getattr(mod,'__file__',None)
 if name:
  f=Path(name).resolve()
  if f.suffix=='.py' and(f.is_relative_to(ROOT) or f.is_relative_to(CONTROL.parent)):files.add(f)
for f in [CONTROL/'verify.py',CONTROL/'run_validation.py',Path(__file__)]:
 copy=Path(str(f)+'.source.txt')
 with copy.open('xb') as stream:stream.write(f.read_bytes())
 files.update([f,copy])
d={'schema':'PHYSICAL_SCALAR_GHOST_OPERATOR_VALIDATION_PREPARATION_V1','base_commit':p['base_commit'],'validator_sha256':digest(CONTROL/'verify.py'),'controller_sha256':digest(CONTROL/'run_validation.py'),'input_sha256':{str(f):digest(f) for f in sorted(files)},'limits':p['limits'],'all_source_copies_exclusive':True,'completed_native_workers':2,'failed_native_workers':1,'undefined_global_static_preflight_errors':[],'independent_mixed_even_odd_hessian_preflight_passed':True}
with(OUT/'validation_preparation.json').open('xb') as f:f.write(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('FROZEN independent',len(files))
