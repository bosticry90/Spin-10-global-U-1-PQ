from pathlib import Path
from hashlib import sha256
import json,subprocess
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_unified_scalar_ghost_symbol';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def git(*args,raw=False):
 z=subprocess.check_output(['git',*args],cwd=ROOT);return z if raw else z.decode('utf-8').strip()
base=read(OUT/'preparation_v2.json')['base_commit'];assert git('rev-parse','HEAD')==base=='41f2d58f8c8e0bef1415fcabf8248b9d4ebbc17a'
r=read(OUT/'validation_receipt.json');assert r['schema']=='UNIFIED_SCALAR_GHOST_SYMBOL_INDEPENDENT_VALIDATION_V2' and r['execution_state']=='COMPLETED' and r['scientific_disposition']=='COMPLETE40_PROFILE_UNIFIED_LEADING_SYMBOL_AND_ACTUAL_RAW_CENSUS_QUALIFIED_NOT_COLOR_POLE'
for k,z in r.items():
 if type(z) is bool:assert z,k
assert r['native_worker_failures']==r['independent_worker_failures']==1 and r['fresh_byte_identical_replay_pairs_claimed']==0 and r['new_actual_pole_integration_full_QAP_E5_A5']=='NOT_PERFORMED_UNQUALIFIED' and len(r['new_physical_operator_transport_still_required'])==4
assert digest(OUT/'validation_receipt.json')=='c909a1d117b9bb3d750d578964c5fc1b12deaf64f4796dd39bdd4ce092db2908' and r['raw_GF_counts']=={'M':432,'Y':6688,'X':276,'Q':648,'R':418}
fx=r['linked_literal_diagnostic_Gaussian_verified'];assert fx['finite_quantum_field_count']==17 and fx['distinct_cyclic_order_cohorts']==39 and len(fx['fixture_coefficients'])==21 and fx['all21_family_values_match'] and fx['all_even_field_reorderings_and_mixed_transposes_verified']
for name in ['preparation.json','preparation_v2.json','validation_preparation.json','validation_preparation_v2.json','validation_receipt.json']:
 for p,h in read(OUT/name)['input_sha256'].items():assert digest(Path(p))==h,(name,p)
for folder in [OUT,CONTROL]:
 for p in folder.glob('*.source.txt'):assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes(),p
for short in ['primary','replay','validation']:
 capname=short+'_v2_capture.json';external=short+'_v2_full_capture.json';cap=read(OUT/capname);assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and cap['private_allocation_limit_bytes']==8*1024**3
 assert(OUT/capname).read_bytes()==(CONTROL/external).read_bytes() and cap['all_resource_samples'] and all('query_error' not in z and 0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
 result=read(OUT/('validation_receipt.json' if short=='validation' else short+'_v2_result.json'));assert 0<result['elapsed_after_imports']<120
for name in ['primary','validation']:
 cap=read(OUT/(name+'_capture.json'));assert cap['execution_state']=='FAILED' and cap['exit_code']==1 and (OUT/(name+'_capture.json')).read_bytes()==(CONTROL/(name+'_full_capture.json')).read_bytes()
assert not(OUT/'primary_result.json').exists()
d=read(OUT/'primary_v2_result.json');rr=read(OUT/'replay_v2_result.json');assert all(d[k]==rr[k] for k in d.keys()-{'route','elapsed_after_imports'}) and len(d['normalized_ordered_family_formulas'])==21 and len(d['all40_actual_profile_family_correspondence'])==40 and all(d['controls'].values()) and not any(d['all_seven_quantum_flags_false'].values())
assert d['complete_scalar_pair_sums']=={'D':[[['A','K','Kt'],'3']],'FX':[],'FF':[],'XX':[]} and d['current_known_terms']==155143 and d['current_known_sha256']==r['current_known_sha256']=='fe6bd8e800d8e04f9d0358ce94c081d70e94af0ffd37830bb50c02fdbb0c0241' and not d['new_actual_color_pole_or_canonical_integration'] and not d['new_loop_integral_full_functional_or_authority_change'] and not d['full_QAP_IR_measure_products_contacts_equivalence_sourcefree_Slavnov_E5_A5_proved']
assert d['actual_FFMM_structural_zero_preserved_not_generic_color_identity'] and d['generic_FFMM_is_actual_excluded_profile']==2025 and d['remaining_physical_operator_transport_before_color_evaluation']==r['new_physical_operator_transport_still_required']
for p in ['AGENTS.md','CHARTER.md','README.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md']:assert git('show',base+':'+p,raw=True)==(ROOT/p).read_bytes(),p
paths=sorted([p.relative_to(ROOT).as_posix() for p in OUT.iterdir() if p.is_file()]+['docs/RESEARCH_EXECUTION_HANDOFF_V279.md']);assert set(git('ls-files','--others','--exclude-standard').splitlines())==set(paths) and not git('diff','--name-only') and not git('diff','--cached','--name-only')
for p in [ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V279.md',OUT/'RESULT_V3.md']:assert digest(OUT/'validation_receipt.json') in p.read_text(encoding='utf-8')
subprocess.check_call(['git','-c','core.autocrlf=false','-c','core.longpaths=true','add','--',*paths],cwd=ROOT);assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
for p in paths:assert git('show',':'+p,raw=True)==(ROOT/p).read_bytes(),p
subprocess.check_call(['git','diff','--cached','--check'],cwd=ROOT);subprocess.check_call(['git','commit','-m','Qualify unified scalar ghost symbol with preserved export and verifier failures'],cwd=ROOT)
head=git('rev-parse','HEAD');assert git('rev-parse','HEAD^')==base and set(git('diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines())==set(paths)
for p in paths:assert git('show','HEAD:'+p,raw=True)==git('show',':'+p,raw=True)==(ROOT/p).read_bytes(),p
assert not git('status','--porcelain=v1')
proof={'HEAD':head,'parent':base,'exact_changed_files':paths,'all_HEAD_index_worktree_bytes_equal':True,'working_tree_clean':True,'receipt_sha256':digest(OUT/'validation_receipt.json'),'authority_unchanged':digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8','all_five_current_input_bindings_match':True,'all21_formulas_and40_actual_profile_maps_verified':True,'linked_literal_Gaussian39_cyclic_cohorts_verified':True,'native_and_independent_V1_failures_preserved':True,'native_V2_reused_by_corrected_independent_V2':True,'missing_physical_transports_remain_four_groups':True,'current_functional_and329_335_scope_counts_unchanged':True,'full_E5_A5':'UNQUALIFIED','no_remote_action':True,'commit_controller_sha256':digest(Path(__file__))};assert proof['authority_unchanged']
with(CONTROL/'post_commit.json').open('xb') as f:f.write(json.dumps(proof,sort_keys=True,separators=(',',':')).encode()+b'\n')
print(json.dumps({'HEAD':head,'files':len(paths),'clean':True,'receipt_sha256':proof['receipt_sha256'],'full_E5_A5':'UNQUALIFIED'}))
