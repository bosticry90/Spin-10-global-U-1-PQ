"""Independent alternating G/H paths,raw census and literal linked Gaussian."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from itertools import permutations
from fractions import Fraction as F
import importlib.util,json,sys,os,time,threading,subprocess
import sympy as s
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_unified_scalar_ghost_symbol';CONTROL=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(PKG));from audit_a10_e5_antighost_vector import resource,line_json
spec=importlib.util.spec_from_file_location('literal_independent_gaussian_fixture',CONTROL/'fixture_check.py');fx=importlib.util.module_from_spec(spec);spec.loader.exec_module(fx);cq=fx.cq;qa=fx.qa;qm=fx.qm;qs=fx.qs;ZERO=fx.ZERO;ONE=fx.ONE
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
FAMILIES={'DMM':(['D','M','M'],0),'FMY':(['F','M','Y'],0),'YY':(['Y','Y'],0),'FFMM_generic':(['F','F','M','M'],0),'DMK':(['D','M','K'],1),'FYK':(['F','Y','K'],1),'FFMK':(['F','F','M','K'],1),'FFY':(['F','F','Y'],1),'YR':(['Y','R'],1),'FMKX':(['F','M','K','X'],1),'FYX':(['F','Y','X'],1),'YQ':(['Y','Q'],1),'YKX':(['Y','K','X'],1),'DKK':(['D','K','K'],2),'DH':(['D','H'],2),'FXKK':(['F','X','K','K'],2),'FXH':(['F','X','H'],2),'FFKK':(['F','F','K','K'],2),'FFH':(['F','F','H'],2),'XXKK':(['X','X','K','K'],2),'XXH':(['X','X','H'],2)}
COST={'D':(2,0,0),'F':(1,0,0),'M':(1,1,1),'Y':(2,1,1),'X':(0,1,0),'K':(1,0,0),'H':(2,0,0),'Q':(1,1,0),'R':(2,1,0)};ODD={'L','T','X','Xr','U','V'};GD={'A':2,'L':1,'T':1,'X':1,'Xr':1,'U':1,'V':1,'Q':2,'R':2};SD={'K':1,'Kt':1,'Z':1}
def canonical(word):
 assert sum(x in ODD for x in word)%2==0;cuts=[(word[k:]+word[:k],-1 if sum(x in ODD for x in word[:k])%2 else 1) for k in range(len(word))];best=min(w for w,z in cuts);signs={z for w,z in cuts if w==best};return best,next(iter(signs)) if len(signs)==1 else 0
def addword(C,w,z):
 w,sg=canonical(w)
 if not sg:return
 C[w]=qa(C.get(w,ZERO),qs(z,sg))
 if C[w]==ZERO:del C[w]
def decode(rows):return{tuple(w):fx.cv(z) for w,z in rows}
def primitive(p=(2,1,0,0),wrong_mixed=False,noZ=False,remove_transverse=False):
 P=p[0]**2-sum(x*x for x in p[1:]);eta=[1,-1,-1,-1];G=defaultdict(list);V={t:defaultdict(list) for t in COST}
 def put(A,i,j,w,z):
  if z!=ZERO and not(remove_transverse and(i==3 or j==3)):A[i].append((j,tuple(w),z))
 for mu in range(4):
  for nu in range(4):put(G,mu,nu,(),cq(F(-eta[mu]*int(mu==nu),P)+F(p[mu]*p[nu],P*P)));put(G,mu,nu,('W',),cq(F(-p[mu]*p[nu],P*P)))
  put(G,mu,4,(),cq(0,F(p[mu],P)));put(G,4,mu,(),cq(0,F((1 if wrong_mixed else -1)*p[mu],P)));put(V['D'],mu,mu,('A',),cq(eta[mu]));put(V['F'],mu,6,('L',),cq(eta[mu]*p[mu]));put(V['F'],6,mu,('T',),cq(eta[mu]*p[mu]));put(V['K'],mu,5,('K',),cq(0,eta[mu]*p[mu]));put(V['K'],5,mu,('Kt',),cq(0,-eta[mu]*p[mu]));put(V['H'],mu,mu,('K','Kt'),cq(eta[mu]))
 put(G,5,5,(),cq(F(1,P)));put(G,6,6,('J',),cq(F(1,P)));put(V['M'],4,5,('E',),ONE);put(V['M'],5,4,('Et',),ONE);put(V['Y'],5,6,('U',),ONE);put(V['Y'],6,5,('V',),ONE)
 if not noZ:put(V['Y'],6,6,('Z',),ONE)
 put(V['X'],4,6,('X',),ONE);put(V['X'],6,4,('Xr',),ONE);put(V['Q'],6,6,('Q',),ONE);put(V['R'],6,6,('R',),ONE);return G,V,P
def alternate(order,degree,G,V,P,ordinary=False):
 n=len(order);factor=F(-(-1)**(n+1)*P*P,n);out={}
 def visit(start,at,word,z,k):
  if k==n:
   if at==start and sum(GD.get(x,0) for x in word)==2 and sum(SD.get(x,0) for x in word)==degree:addword(out,word,qs(z,factor*(-1 if start==6 and not ordinary else 1)))
   return
  for b,w,x in G.get(at,[]):
   for c,v,y in V[order[k]].get(b,[]):
    ww=word+w+v
    if sum(GD.get(t,0) for t in ww)>2 or sum(SD.get(t,0) for t in ww)>degree:continue
    visit(start,c,ww,qm(qm(z,x),y),k+1)
 for i in range(7):visit(i,i,(),ONE,0)
 return out
def family(seq,d,G,V,P,ordinary=False):
 total={};parts=[]
 for order in sorted(set(permutations(seq))):
  row=alternate(order,d,G,V,P,ordinary)
  for w,z in row.items():addword(total,w,z)
  parts.append((list(order),row))
 return total,parts
def auth(folder,name):
 p=ROOT/'calculations'/folder/name;r=read(p.parent/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p)
def projector():
 p=s.Matrix(s.symbols('ivp0:4',real=True));eta=s.diag(1,-1,-1,-1);n=eta*p;P=(n.T*p)[0];long=p*n.T/P;trans=s.eye(4)-long;GI=-eta/P+p*p.T/P**2;GW=-p*p.T/P**2
 for M in [long*long-long,trans*trans-trans,long*trans,trans*long,GI*eta+trans/P,GW*eta+long/P,(n.T/P)*GI*(n/P),(n.T/P)*GW*(n/P)+s.ones(1)/P**2]:assert all(s.cancel(x)==0 for x in M)
 assert s.cancel(s.trace(trans)-3)==0 and s.cancel(s.trace(long)-1)==0
def census(role):
 p=PKG/'frozen_a10_e2_transport'/(role+'.json');bind=read(p.parent/'bindings.json');assert bind['byte_sha256'][p.relative_to(ROOT).as_posix()]==digest(p);r=read(p);g,xi=s.symbols('g10 xi');out=defaultdict(dict)
 for row in r['gauge_fixing_density']:
  def kind(n):return'x' if n.startswith('x_') else'a' if n.startswith('ub') else n[0]
  types=Counter(map(kind,row['word']));tag='M' if types==Counter(['L','x']) else'Y' if types==Counter(['C','a','x']) else'X' if types==Counter(['L','C','a']) else'QR' if types==Counter(['a','a','C','C']) else None
  if tag is None:continue
  for(a,b),z in s.Poly(s.sympify(row['coefficient']),g,xi).terms():
   assert b==1 and not z.free_symbols;name=('Q' if a==1 else'R') if tag=='QR' else tag;assert a==COST[name][0];key=tuple(row['word']);assert key not in out[name];out[name][key]=s.cancel(z)
 return out
def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(OUT/'validation_preparation.json')
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 assert digest(Path(__file__))==prep['validator_sha256'] and subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==prep['base_commit'];allowed={str(Path(p).resolve()) for p in prep['input_sha256']}|{str((OUT/'validation_preparation.json').resolve())}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('UNIFIED_SYMBOL_VERIFIER_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_JSON',str(p))
 sys.addaudithook(guard);data={};perf={}
 failed=read(OUT/'primary_capture.json');assert failed['execution_state']=='FAILED' and failed['exit_code']==1 and not(OUT/'primary_result.json').exists() and(OUT/'primary_capture.json').read_bytes()==(CONTROL/'primary_full_capture.json').read_bytes();assert 'TypeError: Object of type One is not JSON serializable' in failed['stdout_and_stderr']
 for role in ['primary','replay']:
  cap=read(OUT/(role+'_v2_capture.json'));resource(cap);d=read(OUT/(role+'_v2_result.json'));assert d==line_json(cap['stdout_and_stderr'],'RESULT ') and(OUT/(role+'_v2_capture.json')).read_bytes()==(CONTROL/(role+'_v2_full_capture.json')).read_bytes();data[role]=d;perf[role]={'seconds':d['elapsed_after_imports'],'private_bytes':max(z['private_bytes'] for z in cap['all_resource_samples'])}
 for k in set(data['primary'])-{'route','elapsed_after_imports'}:assert data['primary'][k]==data['replay'][k],k
 d=data['primary'];assert set(d['normalized_ordered_family_formulas'])==set(d['all_distinct_normalized_Born_words'])==set(FAMILIES);projector();G,V,P=primitive();formula={};print('STAGE independent_all_alternating_full_Lorentz_Born_paths_and_words',flush=True)
 for name,(seq,degree) in FAMILIES.items():
  total,parts=family(seq,degree,G,V,P);formula[name]=total;assert total==decode(d['normalized_ordered_family_formulas'][name]),name;saved=d['all_distinct_normalized_Born_words'][name];assert len(parts)==len(saved)
  for(order,row),entry in zip(parts,saved):assert order==entry['order'] and row==decode(entry['terms']),(name,order)
  t=d['family_power_table'][name];assert t=={'g':sum(COST[x][0] for x in seq),'explicit_vertex_xi':sum(COST[x][1] for x in seq),'scalar_degree':degree,'fixed_coefficient_dimension':sum(COST[x][2] for x in seq)} and t['fixed_coefficient_dimension']==2-degree
 def pair(a,b):
  C={}
  for A in [formula[a],formula[b]]:
   for w,z in A.items():addword(C,w,z)
  return C
 expectedpair={'D':pair('DKK','DH'),'FX':pair('FXKK','FXH'),'FF':pair('FFKK','FFH'),'XX':pair('XXKK','XXH')};assert expectedpair['D']=={('A','K','Kt'):cq(3)} and not any(expectedpair[k] for k in ['FX','FF','XX']) and all(v==decode(d['complete_scalar_pair_sums'][k]) for k,v in expectedpair.items())
 mass=auth('canonical_so10_ghost_mass_g4_reduction','primary_v2_result.json');prior=auth('canonical_so10_higher_scalar_pair_reduction','primary_result.json');cur=auth('canonical_so10_ghost_mass_g4_integration','primary_result.json');uv=auth('canonical_so10_ordered_multiheat_uv_log','primary_v2_result.json');assert all(formula[t]==decode(mass['formal_freeword_normalized_formula'][t]) for t in ['DMM','FMY','YY']) and uv['unheated_complete_classical_minus4_symbol_alone_determines_leading_log'] and 2025 in mass['actual_structurally_zero_profiles'] and d['actual_FFMM_structural_zero_preserved_not_generic_color_identity']
 selected=[r for r in prior['all664_updated_scope_rows'] if not r['complete_scope_match'] and r['types'] in [['C','a','x'],['C','a','x','x']]];assert len(selected)==len(d['all40_actual_profile_family_correspondence'])==40;table={tuple(sorted(seq)):name for name,(seq,degree) in FAMILIES.items()}
 for r,entry in zip(selected,d['all40_actual_profile_family_correspondence']):
  seq=[{'O_LX':'M','O_aCX':'Y','S3':'K','S4':'H'}.get(t,t) for t in r['family']];name=table[tuple(sorted(seq))];degree=FAMILIES[name][1];assert entry=={'index':r['index'],'family':name,'g':r['g'],'explicit_vertex_xi':r['descriptor']['explicit_vertex_xi'],'scalar_degree':degree,'coefficient_dimension':r['coefficient_dimension'],'BB_width_roles':r['descriptor']['BB_width_roles']} and r['jets']==0 and not r['descriptor']['scalar_reference_mass_expansions'] and degree+r['coefficient_dimension']==2
 print('STAGE independent_raw_actual_census_and_linked_literal_Gaussian',flush=True)
 for role in ['primary','replay']:
  raw=census(role);saved=data[role]['actual_raw_GF_vertex_census'];assert set(raw)==set(saved)
  for tag,M in raw.items():assert len(M)==len(saved[tag]) and all(s.cancel(M[tuple(r['word'])]-s.sympify(r['stripped_coefficient']))==0 for r in saved[tag])
 assert d['raw_GF_counts']=={'M':432,'Y':6688,'X':276,'Q':648,'R':418};fixture=d['linked_Gaussian_fixture'];checked=fx.check(fixture['linked_matrix_data'],fixture['normalized_family_coefficients_of_ae_ce_and_scalar_power'],FAMILIES)
 assert family(*FAMILIES['YQ'],G,V,P,ordinary=True)[0]!=formula['YQ'];badG,badV,badP=primitive(wrong_mixed=True);assert family(*FAMILIES['DMM'],badG,badV,badP)[0]!=formula['DMM'];ng,nv,np=primitive(noZ=True);assert any(family(*FAMILIES[k],ng,nv,np)[0]!=formula[k] for k in ['FFY','FYX','YQ','YR']);tg,tv,tp=primitive(remove_transverse=True);rank={}
 for k in ['DKK','DH']:
  rr=family(*FAMILIES[k],tg,tv,tp)[0]
  for w,z in rr.items():addword(rank,w,z)
 assert rank!={('A','K','Kt'):cq(3)} and formula['YQ'] and formula['YR'] and formula['YY'];moved={}
 for k in ['DMK','FYK','FFMK','FFY']:
  C={}
  for w,z in formula[k].items():
   if 'W' in w:
    i=w.index('W')
    if i:w=w[:i-1]+(w[i],w[i-1])+w[i+1:]
   addword(C,w,z)
  moved[k]=C
 assert any(moved[k]!=formula[k] for k in moved) and all(d['controls'].values()) and d['insensitive_controls']==['width_changes_do_not_change_complete_mass_or_scalar_pair_controls'];assert len(d['remaining_physical_operator_transport_before_color_evaluation'])==4 and not d['new_actual_color_pole_or_canonical_integration'] and not d['new_loop_integral_full_functional_or_authority_change'] and not d['full_QAP_IR_measure_products_contacts_equivalence_sourcefree_Slavnov_E5_A5_proved'] and not any(d['all_seven_quantum_flags_false'].values()) and cur['updated_known_sha256']==d['current_known_sha256']=='fe6bd8e800d8e04f9d0358ce94c081d70e94af0ffd37830bb50c02fdbb0c0241'
 result={'schema':'UNIFIED_SCALAR_GHOST_SYMBOL_INDEPENDENT_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':'COMPLETE40_PROFILE_UNIFIED_LEADING_SYMBOL_AND_ACTUAL_RAW_CENSUS_QUALIFIED_NOT_COLOR_POLE','all21_formal_family_formulas_and_every_ordered_word_verified':True,'generic_projector_trace_reduction_and_full_Lorentz_paths_verified':True,'all40_actual_profiles_costs_xi_and_dimensions_verified':True,'mass_and_complete_scalar_pair_specializations_verified_without_fitting':True,'both_actual_GF_censuses_and_distinct_Q_R_X_roles_verified':True,'linked_literal_diagnostic_Gaussian_verified':checked,'controls_and_insensitive_scopes_verified':True,'V1_failed_metadata_export_preserved_and_unqualified':True,'new_physical_operator_transport_still_required':d['remaining_physical_operator_transport_before_color_evaluation'],'raw_GF_counts':d['raw_GF_counts'],'current_known_terms':155143,'current_known_sha256':d['current_known_sha256'],'native_worker_failures':1,'independent_worker_failures':0,'fresh_byte_identical_replay_pairs_claimed':0,'new_actual_pole_integration_full_QAP_E5_A5':'NOT_PERFORMED_UNQUALIFIED','performance':perf,'input_sha256':prep['input_sha256'],'shared_limits':'Actual actions/catalogue/old Hessian and UV premises shared. Separate Fraction Gaussian arithmetic,alternating full Lorentz paths,literal diagnostic Hessians;not new actual color coefficients or external validation','elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
