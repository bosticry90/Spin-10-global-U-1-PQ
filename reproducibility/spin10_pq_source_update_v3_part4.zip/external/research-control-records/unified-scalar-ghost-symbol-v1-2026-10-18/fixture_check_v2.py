"""Independent literal diagnostic Hessians and exact Gaussian polynomial matrices."""
from fractions import Fraction as F
from collections import defaultdict
from itertools import permutations
import sympy as s
ZERO=(F(0),F(0));ONE=(F(1),F(0));II=(F(0),F(1))
def cq(a=0,b=0):return(F(a),F(b))
def qa(a,b):return(a[0]+b[0],a[1]+b[1])
def qm(a,b):return(a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def qs(a,z):return(a[0]*z,a[1]*z)
def cv(z):
 a,b=s.expand(s.sympify(z)).as_real_imag();return cq(F(a),F(b))
def add(A,B):
 C=dict(A)
 for k,v in B.items():
  C[k]=qa(C.get(k,ZERO),v)
  if C[k]==ZERO:del C[k]
 return C
def scale(A,z):return{k:qm(v,z) for k,v in A.items() if qm(v,z)!=ZERO}
def mul(A,B):
 C={}
 for(a,u),x in A.items():
  for(b,v),y in B.items():
   if a&b or u+v>2:continue
   k=(a|b,u+v);z=qm(x,y)
   if a&2 and b&1:z=qs(z,-1)
   C[k]=qa(C.get(k,ZERO),z)
   if C[k]==ZERO:del C[k]
 return C
def put(A,i,j,P):
 z=add(A.get((i,j),{}),P)
 if z:A[i,j]=z
 else:A.pop((i,j),None)
def mm(A,B):
 R=defaultdict(list);C={}
 for(k,j),v in B.items():R[k].append((j,v))
 for(i,k),v in A.items():
  for j,w in R[k]:put(C,i,j,mul(v,w))
 return C
def scalar(z=ONE,mask=0,degree=0):return{(mask,degree):z} if z!=ZERO else{}
def specification(data):
 E=data['E'];rho=data['rho'];ss=data['scalar_background'];alpha=data['alpha'];gamma=data['gamma'];rows=[];eta=[1,-1,-1,-1]
 def row(tag,co,*word):
  if co:rows.append((tag,F(co),word))
 def B(a,mu):return(f'B{a}_{mu}',())
 def C(a):return(f'c{a}',())
 def A(a):return(f'a{a}',())
 def X(i):return(f'x{i}',())
 def L(a):return(f'l{a}',())
 for a in range(2):
  for i in range(3):row('M',E[a][i],L(a),X(i))
  row('X',1,L(a),A(a),C(a))
  for c in range(2):
   for i in range(3):row('Y',sum(E[a][j]*rho[c][j][i] for j in range(3)),X(i),A(a),C(c))
 for b in range(2):
  for a in range(2):
   for c in range(2):
    for mu in range(4):row('F',eta[mu]*(2+3*b+2*a+c),(f'a{a}',(mu,)),B(b,mu),C(c));row('F',eta[mu]*(1+b+3*a+2*c),A(a),B(b,mu),(f'c{c}',(mu,)))
 for b in range(2):
  for d in range(2):
   for a in range(2):
    for c in range(2):
     for mu in range(4):row('D',F(eta[mu]*(1+b+d+b*d+2*a+c),2),B(b,mu),B(d,mu),A(a),C(c))
 for a in range(2):
  for mu in range(4):
   for i in range(3):
    for j in range(3):row('K',eta[mu]*rho[a][i][j],B(a,mu),X(j),(f'x{i}',(mu,)))
 for a in range(2):
  for b in range(2):
   for mu in range(4):
    for i in range(3):
     for j in range(3):
      for k in range(3):row('H',F(eta[mu]*rho[a][i][j]*rho[b][i][k],2),B(a,mu),B(b,mu),X(j),X(k))
 for tag,val in zip(['Q','R'],data['Q_R_quartic_density_coefficients']):row(tag,val,A(0),A(1),C(0),C(1))
 return rows
def matrices(data,p,even_first=False):
 names=[f'B{a}_{mu}' for a in range(2) for mu in range(4)]+[f'l{a}' for a in range(2)]+[f'x{i}' for i in range(3)]+['c0','c1','a0','a1'];indices={n:i for i,n in enumerate(names)};par={n:int(n[0] in 'ac') for n in names};H={t:{} for t in ['D','F','M','Y','X','K','H','Q','R']};alpha=data['alpha'];gamma=data['gamma'];ss=data['scalar_background']
 def background(word):
  P=scalar()
  for n,jets in word:
   if jets or n[0] in 'Bl':return{}
   if n[0]=='x':P=mul(P,scalar(cq(ss[int(n[1:])]),degree=1))
   elif n[0]=='a':P=mul(P,scalar(cq(alpha[int(n[1:])]),mask=1))
   else:P=mul(P,scalar(cq(gamma[int(n[1:])]),mask=2))
  return P
 for tag,co,word in specification(data):
  if even_first:word=tuple(x for x in word if not par[x[0]])+tuple(x for x in word if par[x[0]])
  for i,(ni,ji) in enumerate(word):
   left=(-1)**(par[ni]*sum(par[n] for n,j in word[:i]));rest=word[:i]+word[i+1:]
   for j,(nj,jj) in enumerate(rest):
    sign=left*(-1)**(par[nj]*sum(par[n] for n,k in rest[:j]))*(-1)**(par[nj]*(par[ni]+1));P=background(rest[:j]+rest[j+1:])
    if not P:continue
    z=cq(co*sign)
    for mu in ji:z=qm(z,cq(0,-p[mu]))
    for mu in jj:z=qm(z,cq(0,p[mu]))
    put(H[tag],indices[ni],indices[nj],scale(P,z))
 eta=[1,-1,-1,-1];P=sum(e*x*x for e,x in zip(eta,p));assert P!=0;G={};width=[2,5]
 for a in range(2):
  for mu in range(4):
   for nu in range(4):put(G,4*a+mu,4*a+nu,scalar(cq(F(-eta[mu]*int(mu==nu),P)+F((1-width[a])*p[mu]*p[nu],P*P))))
   put(G,4*a+mu,8+a,scalar(cq(0,F(p[mu],P))));put(G,8+a,4*a+mu,scalar(cq(0,F(-p[mu],P))))
 for i in range(3):put(G,10+i,10+i,scalar(cq(F(1,P))))
 for i in range(2):put(G,13+i,15+i,scalar(cq(F(1,P))));put(G,15+i,13+i,scalar(cq(F(-1,P))))
 return G,H,[par[n] for n in names],P
def check(data,expected,families):
 G,H,par,P=matrices(data,[2,1,0,0]);GG,HH,pp,PP=matrices(data,[2,1,0,0],True);assert (G,H,par,P)==(GG,HH,pp,PP)
 for i in range(8):
  for j in range(13,17):assert H['F'].get((i,j),{})==H['F'].get((j,i),{})
 for tag,indices in [('X',range(8,10)),('Y',range(10,13))]:
  for i in indices:
   for j in range(13,17):assert H[tag].get((i,j),{})==scale(H[tag].get((j,i),{}),cq(-1))
 for tag in ['Q','R']:
  for i in range(13,17):
   for j in range(13,17):assert H[tag].get((i,j),{})==scale(H[tag].get((j,i),{}),cq(-1))
 M={t:mm(G,A) for t,A in H.items()};out={};cohort_count=0
 for name,(seq,degree) in families.items():
  orbit={}
  for w in set(permutations(seq)):
   key=min(w[k:]+w[:k] for k in range(len(w)));orbit[key]=orbit.get(key,0)+1
  total={};n=len(seq)
  for order,count in orbit.items():
   A=M[order[0]]
   for t in order[1:]:A=mm(A,M[t])
   trace={}
   for(i,j),z in A.items():
    if i==j:trace=add(trace,scale(z,cq((-1)**par[i])))
   total=add(total,scale(trace,cq(F(-(-1)**(n+1)*P*P*count,n))));cohort_count+=1
  out[name]=total.get((3,degree),ZERO);assert out[name]==cv(expected[name]),(name,out[name],expected[name])
 return {'literal_even_odd_Fourier_Hessians_and_all_Gaussian_cohorts_verified':True,'finite_quantum_field_count':17,'distinct_cyclic_order_cohorts':cohort_count,'all21_family_values_match':True,'all_even_field_reorderings_and_mixed_transposes_verified':True,'fixture_coefficients':{k:str(s.Rational(v[0].numerator,v[0].denominator)+s.I*s.Rational(v[1].numerator,v[1].denominator)) for k,v in out.items()}}
