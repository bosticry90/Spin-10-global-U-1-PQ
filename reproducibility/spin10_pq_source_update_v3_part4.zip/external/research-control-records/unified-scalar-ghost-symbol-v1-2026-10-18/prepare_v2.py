from pathlib import Path
from hashlib import sha256
import json,ast,symtable,builtins,subprocess,importlib.util,sys
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_unified_scalar_ghost_symbol';CONTROL=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='41f2d58f8c8e0bef1415fcabf8248b9d4ebbc17a';parent=ROOT/'calculations/canonical_so10_higher_scalar_pair_reduction/validation_receipt.json';r=read(parent);assert r['execution_state']=='COMPLETED' and digest(parent)=='ee01ac72da0e80ac094cde628373fa7ce741ffb56373375dc08c1fade7be391f'
files={Path(p) for p in r['input_sha256']}|{parent,OUT/'RECORD.md',OUT/'DERIVATION.md',ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V278.md'}
oldprep=read(OUT/'preparation.json')
for p,h in oldprep['input_sha256'].items():assert digest(Path(p))==h,p
files|={Path(p) for p in oldprep['input_sha256']}|{OUT/'preparation.json',OUT/'primary_capture.json',CONTROL/'primary_full_capture.json',OUT/'CORRECTION_V2.md'}
assert (OUT/'primary_capture.json').read_bytes()==(CONTROL/'primary_full_capture.json').read_bytes() and read(OUT/'primary_capture.json')['execution_state']=='FAILED'
for p,h in r['input_sha256'].items():assert digest(Path(p))==h,p
paths={};probes=[]
for role in ['primary','replay']:
 paths[role]={OUT/'preparation_v2.json'}
 for folder,name in [('canonical_so10_higher_scalar_pair_reduction',role+'_result.json'),('canonical_so10_ghost_mass_g4_reduction',role+'_v2_result.json'),('canonical_so10_scalar_ghost_support',role+'_result.json'),('canonical_so10_ghost_mass_g4_integration',role+'_result.json'),('canonical_so10_fourghost_g4_lorentz',role+'_result.json'),('canonical_so10_antighost_g2_scalar_zero','primary_result.json' if role=='primary' else 'replay_v2_result.json'),('canonical_so10_ordered_multiheat_uv_log',role+'_v2_result.json')]:
  p=ROOT/'calculations'/folder/name;rr=p.parent/'validation_receipt.json';rc=read(rr);assert rc['execution_state']=='COMPLETED' and rc['input_sha256'][str(p)]==digest(p);data=read(p);paths[role].update([p,rr]);files.update([p,rr]);probes.append({'path':str(p),'receipt':str(rr),'sha256':digest(p)})
  if folder=='canonical_so10_higher_scalar_pair_reduction':assert sum(not z['complete_scope_match'] and z['types'] in [['C','a','x'],['C','a','x','x']] for z in data['all664_updated_scope_rows'])==40
 p=PKG/'frozen_a10_e2_transport'/(role+'.json');rr=p.parent/'bindings.json';b=read(rr);assert b['byte_sha256'][p.relative_to(ROOT).as_posix()]==digest(p);paths[role].update([p,rr]);files.update([p,rr])
for p in [OUT/'symbol_v2.py',OUT/'fixture_v2.py',CONTROL/'run_v2.py',Path(__file__)]:
 text=p.read_text(encoding='utf-8');ast.parse(text);st=symtable.symtable(text,str(p),'exec');defs={x.get_name() for x in st.get_symbols() if x.is_assigned() or x.is_imported() or x.is_namespace()}|set(dir(builtins))|{'__file__','__name__','__package__'};bad=[]
 def scan(t):
  for x in t.get_symbols():
   if x.is_referenced() and x.is_global() and x.get_name() not in defs:bad.append((t.get_name(),x.get_name()))
  for q in t.get_children():scan(q)
 scan(st);assert not bad,bad
sp=importlib.util.spec_from_file_location('unified_symbol_type_import_only',OUT/'symbol_v2.py');u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);types={role:{tag:len(rows) for tag,rows in u.raw_census(role).items()} for role in ['primary','replay']};assert types['primary']==types['replay']
fs=importlib.util.spec_from_file_location('fixture_v2_metadata_type_preflight',OUT/'fixture_v2.py');ff=importlib.util.module_from_spec(fs);fs.loader.exec_module(ff);json.dumps(ff.evaluate({},{}),sort_keys=True)
for mod in list(sys.modules.values()):
 name=getattr(mod,'__file__',None)
 if name:
  p=Path(name).resolve()
  if p.suffix=='.py' and(p.is_relative_to(ROOT) or p.is_relative_to(CONTROL.parent)):files.add(p)
for p in [OUT/'symbol_v2.py',OUT/'fixture_v2.py',CONTROL/'run_v2.py',Path(__file__)]:
 copy=Path(str(p)+'.source.txt')
 with copy.open('xb') as f:f.write(p.read_bytes())
 files.update([p,copy])
d={'schema':'UNIFIED_SCALAR_GHOST_SYMBOL_PREPARATION_V2','base_commit':head,'source_sha256':digest(OUT/'symbol_v2.py'),'controller_sha256':digest(CONTROL/'run_v2.py'),'input_sha256':{str(p):digest(p) for p in sorted(files)},'read_json_by_role':{role:[str(p) for p in sorted(pp)] for role,pp in paths.items()},'qualified_input_probes':probes,'prelaunch_GF_type_and_coupling_counts_only':types,'limits':{'seconds_after_imports':120,'private_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2},'all_source_copies_exclusive':True,'actual_role_receipt_structure_symbolic_and_fixture_type_preflight_complete':True}
with(OUT/'preparation_v2.json').open('xb') as f:f.write(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('FROZEN',len(files),'probes',len(probes),'raw_types',types['primary'])
