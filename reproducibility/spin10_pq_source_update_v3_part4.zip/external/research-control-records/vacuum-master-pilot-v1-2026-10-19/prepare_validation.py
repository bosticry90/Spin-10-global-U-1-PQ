from pathlib import Path
from hashlib import sha256
import json
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_vacuum_master_pilot'
p=json.loads((O/'preparation.json').read_bytes());files=list(map(Path,p['input_sha256']))
for n,h in p['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
for r in ['primary','replay']:
 cap=json.loads((O/(r+'_capture.json')).read_bytes());assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0
 files.extend([O/(r+'_capture.json'),O/(r+'_result.json')])
files.append(O/'preparation.json')
v={'schema':'VACUUM_MASTER_PILOT_VALIDATION_PREPARATION_V1','input_sha256':{str(q):sha256(q.read_bytes()).hexdigest() for q in files},'authority_changed':False}
with (O/'validation_preparation.json').open('xb') as f:f.write((json.dumps(v,indent=2,sort_keys=True)+'\n').encode())
print('VALIDATION_FROZEN',len(v['input_sha256']),flush=True)
