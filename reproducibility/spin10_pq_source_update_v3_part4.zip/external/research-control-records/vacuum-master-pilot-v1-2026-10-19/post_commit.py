from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path('C:/Users/psboy/Documents/ToE-Next');C=Path(__file__).resolve().parent;git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
v=json.loads((C/'pre_commit.json').read_bytes());head=git('rev-parse','HEAD').decode().strip()
assert git('rev-parse','HEAD^').decode().strip()==v['base_commit'] and git('branch','--show-current').decode().strip()=='main'
assert not git('status','--porcelain')
def blobs(ref):
 out={}
 for row in git('ls-tree','-r','-z',ref).split(b'\0'):
  if row:
   info,name=row.split(b'\t',1);out[name.decode()]=info.split()[2].decode()
 return out
old,new=blobs(v['base_commit']),blobs(head);assert all(new[n]==b for n,b in old.items())
for n,h in v['new_files_sha256'].items():assert sha256((R/n).read_bytes()).hexdigest()==h and sha256(git('show',head+':'+n)).hexdigest()==h,n
rec=json.loads((R/'calculations/canonical_so10_vacuum_master_pilot/validation_receipt_v2.json').read_bytes())
for n,h in rec['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
out={'schema':'VACUUM_MASTER_PILOT_POSTCOMMIT_V1','commit':head,'parent':v['base_commit'],'old_blobs_unchanged':len(old),'new_files_raw_HEAD_equal':len(v['new_files_sha256']),'bound_inputs_authenticated':len(rec['input_sha256']),'working_tree_clean':True,'authority_changed':False,'goal_complete':False}
with (C/'post_commit.json').open('xb') as f:f.write((json.dumps(out,indent=2,sort_keys=True)+'\n').encode())
print(json.dumps(out,sort_keys=True),flush=True)
