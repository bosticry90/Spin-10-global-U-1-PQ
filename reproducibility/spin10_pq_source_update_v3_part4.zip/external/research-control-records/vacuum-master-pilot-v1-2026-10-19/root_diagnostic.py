"""Frozen tiny-mass cancellation diagnostic only, not pilot qualification."""
from pathlib import Path
from hashlib import sha256
import json,sys
import mpmath as mp
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_vacuum_master_pilot';C=Path(__file__).resolve().parent
p=json.loads((O/'preparation.json').read_bytes());d=lambda q:sha256(q.read_bytes()).hexdigest()
for n,h in p['input_sha256'].items():assert d(Path(n))==h,n
src=(O/'masters.py').read_text();old="root=mp.sqrt(lam);a=(z+x-y-root)/(2*z);b=(z+y-x-root)/(2*z)"
new="root=mp.sqrt(lam);a=2*x/(z+x-y+root);b=2*y/(z+y-x+root)"
assert old in src;candidate=src.replace(old,new)
prep={'classification':'ROOT_ARGUMENT_CANCELLATION_DIAGNOSTIC_ONLY','input_sha256':dict(p['input_sha256'],**{str(Path(__file__).resolve()):d(Path(__file__).resolve())}),'candidate_source_sha256':sha256(candidate.encode()).hexdigest()}
with (C/'root_diagnostic_preparation.json').open('xb') as f:f.write((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
with (C/'rationalized_candidate.py').open('xb') as f:f.write(candidate.encode())
sys.path.insert(0,str(O));from masters import sunset,tadpole
env={};exec(compile(candidate,'<rationalized_candidate>','exec'),env);alternative=env['sunset']
mp.mp.dps=80;x,y=mp.mpf(2),mp.mpf(3);delta=mp.mpf('1e-30');i0=sunset(0,x,y);ax,ay=tadpole(x),tadpole(y)
B=(ay-ax)/(x-y);cc=(-(x+y)*i0-2*ax*ay+3*x*ax+3*y*ay-y*ax-x*ay-(x+y)**2)/(x-y)**2
bad=(sunset(delta,x,y)-i0)/delta-cc-B*mp.log(delta)
good=(alternative(delta,x,y)-i0)/delta-cc-B*mp.log(delta)
out={'classification':'ROOT_ARGUMENT_CANCELLATION_DIAGNOSTIC_ONLY','old_boundary_error':mp.nstr(bad,50),'rationalized_boundary_error':mp.nstr(good,50),'IR_log_coefficient':mp.nstr(B,50),'working_digits':80,'mass_delta':'1e-30','same_expected_formula_and_tolerance':True,'preparation_sha256':d(C/'root_diagnostic_preparation.json')}
with (C/'root_diagnostic.json').open('xb') as f:f.write((json.dumps(out,indent=2,sort_keys=True)+'\n').encode())
print(json.dumps(out,indent=2),flush=True)
