from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_vacuum_master_pilot';C=Path(__file__).resolve().parent
base='5aa5466615074e951689c4915c525ae49fd6a7f3';d=lambda q:sha256(q.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==base
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R) and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R)
PK=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
point=R/'calculations/canonical_so10_positive_higgs/POINT.json';ledger=R/'calculations/canonical_so10_gauge_matching/scalar_sm_ledger.json'
assert d(point)=='476645438ea8a7ada42fea90e80174b772d45ce3e729d013d134e9848950c816'
assert json.loads(ledger.read_bytes())['point_sha256']==d(point)
files=[R/'AGENTS.md',R/'CHARTER.md',R/'project_state.json',R/'docs/RESEARCH_EXECUTION_HANDOFF_V371.md',R/'docs/LOCAL_RESEARCH_CONVENTIONS_V1.md',R/'docs/SOLO_REVIEW_POLICY_V1.md',point,ledger,PK/'export_a10_e5_antighost_vector.py',PK/'audit_a10_e5_antighost_vector.py']
for folder,names in [('direct_two_loop_gauge_scalar_threshold',['RECORD.md','MASTER_BASIS_CONTRACT.md','RESULT.md','compiler_readiness.json','scalar_vertex_oracle.json','comparison_gate.json']),('direct_two_loop_heavy_threshold',['RECORD.md','RESULT.md','YUKAWA_CONVENTION_V1.md','two_loop_boundary.json']),('matrix_threshold',['RECORD.md','RESULT.md','scalar_matrix_log.json','check_scalar_matrix_log.py']),('local_cutoff_comparison',['RESULT.md','NEXT_RESEARCH_QUESTION.md','validation_receipt_v4.json'])]:files.extend(R/'calculations'/('canonical_so10_'+folder)/n for n in names)
for name in ['RECORD.md','DERIVATION.md','masters.py','pilot.py','verify.py']:
 with (O/(name+'.source.txt')).open('xb') as f:f.write((O/name).read_bytes())
 files.extend([O/name,O/(name+'.source.txt')])
for name in ['prepare.py','run.py','prepare_validation.py','run_validation.py']:
 with (O/(name+'.source.txt')).open('xb') as f:f.write((C/name).read_bytes())
 files.extend([C/name,O/(name+'.source.txt')])
files.append(O/'.gitattributes');assert all(q.is_file() for q in files)
v={'schema':'VACUUM_MASTER_PILOT_PREPARATION_V1','base_commit':base,'input_sha256':{str(q):d(q) for q in files},'native_seconds_after_imports':120,'verifier_seconds_after_imports':180,'sampled_private_cap_bytes':8*1024**3,'launch_available_commit_floor_bytes':350*1024**2,'package_cap_bytes':4*1024**2,'native_digits':50,'IR_diagnostic_digits':80,'verifier_digits':80,'independent_simplex_digits':35,'scaled_tolerance':'1e-25','complete_master_or_C1_GS_gate':False,'authority_changed':False}
with (O/'preparation.json').open('xb') as f:f.write((json.dumps(v,indent=2,sort_keys=True)+'\n').encode())
print('FROZEN',len(v['input_sha256']),flush=True)
