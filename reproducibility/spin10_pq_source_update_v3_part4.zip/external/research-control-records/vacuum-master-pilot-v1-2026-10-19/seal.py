from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_vacuum_master_pilot';C=Path(__file__).resolve().parent
base='5aa5466615074e951689c4915c525ae49fd6a7f3';git=lambda *a:subprocess.check_output(['git',*a],cwd=R);d=lambda q:sha256(q.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==base and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
v=json.loads((O/'validation_receipt_v2.json').read_bytes());assert v['execution_state']=='COMPLETED' and v['native_failures']==1 and v['verifier_failures']==0
assert not v['authority_changed'] and not v['full_master_basis_or_C1_GS_gate_pass'] and not v['finite_matching_vector_or_refit']
assert d(O/'validation_receipt_v2.json')=='6b4e2e25061911418654ba848a6690970d7393cb92c6750185a0039cbe768280'
for n,h in v['input_sha256'].items():assert d(Path(n))==h,n
captures=[]
for name,code in [('primary_capture.json',1),('primary_v2_capture.json',0),('replay_v2_capture.json',0),('validation_v2_capture.json',0)]:
 cap=json.loads((O/name).read_bytes());assert cap['exit_code']==code and cap['execution_state']==('COMPLETED' if code==0 else 'FAILED')
 assert cap['launch']['memory']['available_pagefile']>=350*1024**2
 sample=max(z['private_bytes'] for z in cap['all_resource_samples']);assert sample<8*1024**3
 captures.append({'name':name,'exit_code':code,'max_sampled_private_bytes':sample})
for r in ['primary','replay']:assert json.loads((O/(r+'_v2_result.json')).read_bytes())['elapsed_after_imports']<120
assert v['elapsed_after_imports']<180 and d(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
size=sum(q.stat().st_size for q in O.iterdir() if q.is_file());assert size<4*1024**2
files={q.relative_to(R).as_posix():d(q) for q in sorted([q for q in O.iterdir() if q.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V372.md'])}
old={}
for row in git('ls-tree','-r','-z',base).split(b'\0'):
 if row:
  info,name=row.split(b'\t',1);old[name.decode()]=info.split()[2].decode()
assert not set(files)&set(old)
subprocess.run(['git','add','--',*files],cwd=R,check=True);assert set(git('diff','--cached','--name-only').decode().splitlines())==set(files)
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
idx={}
for row in git('ls-files','-s','-z').split(b'\0'):
 if row:
  info,name=row.split(b'\t',1);assert info.split()[2]==b'0';idx[name.decode()]=info.split()[1].decode()
assert all(idx[n]==blob for n,blob in old.items())
for n,h in files.items():assert d(R/n)==h and sha256(git('show',':'+n)).hexdigest()==h,n
record={'schema':'VACUUM_MASTER_PILOT_PRECOMMIT_V1','base_commit':base,'new_files_sha256':files,'validation_receipt_sha256':d(O/'validation_receipt_v2.json'),'old_tracked_blobs_unchanged':len(old),'bound_inputs_authenticated':len(v['input_sha256']),'package_bytes':size,'captures':captures,'failed_native_workers_preserved':1,'failed_verifiers':0,'scientific_acceptance':'NOT_PERFORMED','authority_changed':False}
with (C/'pre_commit.json').open('xb') as f:f.write((json.dumps(record,indent=2,sort_keys=True)+'\n').encode())
print('SEALED',len(files),'new',len(old),'old unchanged',size,'package bytes',flush=True)
