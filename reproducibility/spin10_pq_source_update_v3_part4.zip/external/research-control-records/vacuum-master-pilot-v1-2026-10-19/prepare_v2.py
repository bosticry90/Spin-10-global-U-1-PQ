from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_vacuum_master_pilot';C=Path(__file__).resolve().parent
p=json.loads((O/'preparation.json').read_bytes());d=lambda q:sha256(q.read_bytes()).hexdigest()
for n,h in p['input_sha256'].items():assert d(Path(n))==h,n
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==p['base_commit']
cap=json.loads((O/'primary_capture.json').read_bytes());assert cap['execution_state']=='FAILED' and cap['exit_code']==1
diag=json.loads((C/'root_diagnostic.json').read_bytes());assert diag['same_expected_formula_and_tolerance']
files=list(map(Path,p['input_sha256']))+[O/'preparation.json',O/'primary_capture.json']
candidate=(C/'rationalized_candidate.py').read_bytes()
assert sha256(candidate).hexdigest()==json.loads((C/'root_diagnostic_preparation.json').read_bytes())['candidate_source_sha256']
with (O/'masters_v2.py').open('xb') as f:f.write(candidate)
text=(O/'pilot.py').read_text().replace('from masters import','from masters_v2 import').replace("O/'preparation.json'","O/'preparation_v2.json'")
with (O/'pilot_v2.py').open('xb') as f:f.write(text.encode())
text=(O/'verify.py').read_text().replace('validation_preparation.json','validation_preparation_v2.json').replace("r+'_result.json'","r+'_v2_result.json'").replace("role+'_result.json'","role+'_v2_result.json'").replace("role+'_capture.json'","role+'_v2_capture.json'").replace("'native_failures':0","'native_failures':1")
with (O/'verify_v2.py').open('xb') as f:f.write(text.encode())
for name in ['run','prepare_validation','run_validation']:
 text=(C/(name+'.py')).read_text().replace('preparation.json','preparation_v2.json')
 text=text.replace("O/'pilot.py'","O/'pilot_v2.py'").replace("O/'verify.py'","O/'verify_v2.py'")
 text=text.replace("role+'_capture.json'","role+'_v2_capture.json'").replace("role+'_full_capture.json'","role+'_v2_full_capture.json'").replace("role+'_result.json'","role+'_v2_result.json'")
 text=text.replace("r+'_capture.json'","r+'_v2_capture.json'").replace("r+'_result.json'","r+'_v2_result.json'")
 text=text.replace('validation_capture.json','validation_v2_capture.json').replace('validation_full_capture.json','validation_v2_full_capture.json').replace('validation_receipt.json','validation_receipt_v2.json')
 with (C/(name+'_v2.py')).open('xb') as f:f.write(text.encode())
for name in ['masters_v2.py','pilot_v2.py','verify_v2.py','ROOT_STABILITY_V2.md']:
 with (O/(name+'.source.txt')).open('xb') as f:f.write((O/name).read_bytes())
 files.extend([O/name,O/(name+'.source.txt')])
for name in ['prepare_v2.py','run_v2.py','prepare_validation_v2.py','run_validation_v2.py','root_diagnostic.py','root_diagnostic_preparation.json','root_diagnostic.json','rationalized_candidate.py']:
 with (O/(name+'.source.txt')).open('xb') as f:f.write((C/name).read_bytes())
 files.extend([C/name,O/(name+'.source.txt')])
v=dict(p);v['schema']='VACUUM_MASTER_PILOT_PREPARATION_V2';v['input_sha256']={str(q):d(q) for q in files};v['failed_native_workers_preserved']=1
with (O/'preparation_v2.json').open('xb') as f:f.write((json.dumps(v,indent=2,sort_keys=True)+'\n').encode())
print('FROZEN_V2',len(v['input_sha256']),flush=True)
