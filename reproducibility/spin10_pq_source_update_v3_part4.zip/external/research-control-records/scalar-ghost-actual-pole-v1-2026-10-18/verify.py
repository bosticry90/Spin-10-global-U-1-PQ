"""Independent rational-radical polynomial matrix products with constant absorption."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import importlib.util,json,sys,time,threading,os
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_actual_pole';CONTROL=Path(__file__).resolve().parent
def load(n,p):
 sp=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);return u
v=load('independent_rational_radical_arithmetic',CONTROL.parent/'ghost-mass-g4-pole-v1-2026-10-18/verify.py');read=v.read;digest=v.digest;ONE=v.O
def auth(folder,name):
 p=ROOT/'calculations'/folder/name;r=read(p.parent/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p)
def ordered(a,b):
 if set(a)&set(b):return (),0
 return tuple(sorted(a+b)),(-1)**sum(x>y for x in a for y in b)
def put(P,key,value):
 if value:P[key]=v.add(P.get(key,()),value)
 if key in P and not P[key]:del P[key]
def mats(role):
 n=auth('canonical_so10_scalar_ghost_physical_operators','primary_result.json' if role=='primary' else'replay_v2_result.json');o=auth('canonical_so10_ghost_mass_g4_pole',role+'_v2_result.json');l=auth('canonical_so10_fourghost_g4_lorentz',role+'_result.json');f=auth('canonical_so10_unified_scalar_ghost_symbol',role+'_v2_result.json');M={tag:{} for tag in ['A','L','T','R','E','Et','K','Kt','X','Xr','Q','Z','U','V','J','W']}
 def entry(tag,i,j,odd,sc,h,w,z):
  a,sg=ordered((),tuple(odd));sg*=(-1)**sum(x>y for k,x in enumerate(odd) for y in odd[k+1:]);put(M[tag],(i,j,a,tuple(sorted(sc)),h,w),v.scale(z,sg))
 for tag in ['A','L','T','R']:
  for i,j,word,z in l['classical_operator_tables']['Rbar' if tag=='R' else tag]:entry(tag,i,j,[int(s[2:])+(45 if s.startswith('ap') else 0) for s in word],(),0,0,v.number(z))
 for a,i,z in o['physical_E']:entry('E',a,i,(),(),0,0,v.number(z));entry('Et',i,a,(),(),0,0,v.number(z))
 for a,i,x,z in n['physical_K']:entry('K',a,i,(),(x,),0,0,v.number(z));entry('Kt',i,a,(),(x,),0,0,v.number(z))
 for tag in ['X','Xr']:
  for i,j,k,z in n['physical_'+tag]:entry(tag,i,j,(k,),(),0,0,v.number(z))
 for i,j,a,b,z in n['physical_Q']:entry('Q',i,j,(a,b),(),0,0,v.number(z))
 for i,j,x,z in n['physical_Z']:entry('Z',i,j,(),(x,),0,0,v.number(z))
 for x,a,c,z in o['physical_Y_aC_density']:
  z=v.number(z);entry('U',x,c,(45+a,),(),0,0,z);entry('U',x,45+a,(c,),(),0,0,v.neg(z));entry('V',c,x,(45+a,),(),0,0,v.neg(z));entry('V',45+a,x,(c,),(),0,0,z)
 for i in range(45):entry('W',i,i,(),(),int(i<12),int(i>=12),ONE);entry('J',i,i+45,(),(),0,0,ONE);entry('J',i+45,i,(),(),0,0,v.neg(ONE))
 return M,f
def mm(A,B):
 rows=defaultdict(list);C={}
 for(k,j,b,t,c,d),y in B.items():rows[k].append((j,b,t,c,d,y))
 for(i,k,a,s,h,w),x in A.items():
  for j,b,t,c,d,y in rows.get(k,()):
   o,sg=ordered(a,b)
   if sg:put(C,(i,j,o,tuple(sorted(s+t)),h+c,w+d),v.scale(v.mul(x,y),sg))
 return C
def trace2(A,B):
 rows=defaultdict(list);out={}
 for(i,j,o,s,h,w),z in B.items():rows[j,i].append((o,s,h,w,z))
 for(i,j,a,s,h,w),x in A.items():
  for b,t,c,d,y in rows.get((i,j),()):
   o,sg=ordered(a,b)
   if sg:put(out,(*o,tuple(sorted(s+t)),h+c,w+d),v.scale(v.mul(x,y),sg))
 return out
def word_trace(M,word):
 pending=None;parts=[]
 for tag in word:
  A=M[tag]
  if tag in ['J','W','E','Et']:
   if parts:parts[-1]=mm(parts[-1],A)
   else:pending=A if pending is None else mm(pending,A)
  else:
   parts.append(mm(pending,A) if pending is not None else A);pending=None
 assert pending is None and len(parts) in (2,3)
 if len(parts)==2:return trace2(*parts)
 # Pair first for scalar-square sector;else matrix product then closing trace.
 if word==['A','K','Kt']:return trace2(parts[0],mm(parts[1],parts[2]))
 return trace2(mm(parts[0],parts[1]),parts[2])
def pack(P):return [[a,c,list(s),h,w,[[m,z.numerator,z.denominator] for m,z in value]] for(a,c,s,h,w),value in sorted(P.items())]
def hashed(p):return sha256(json.dumps(p,separators=(',',':')).encode()).hexdigest()
def unpack(rows):return {(a,c,tuple(s),h,w):tuple((m,F(n,d)) for m,n,d in z) for a,c,s,h,w,z in rows}
def coalesce(packets,by_family=False):
 out={}
 for name,rows in packets.items():
  group=('g4_xi0_pair' if name=='PAIR_D' else'g4_xi1' if name in ['DMK','FYK','FFMK','FFY'] else'g4_xi2' if name=='YR' else'g3_xi2') if by_family else name
  g=3 if group=='g3_xi2' else 4;vertex_xi=0 if group.endswith('pair') else 1 if group=='g4_xi1' else 2
  for (a,c,s,h,w),z in unpack(rows).items():put(out.setdefault((g,h,vertex_xi+w,len(s)),{}),(a,c,s,0,0),z)
 return out
def selfcheck():
 assert ordered((45,),(0,))==((0,45),-1) and ordered((0,),(0,))[1]==0 and v.mul(v.II,v.II)==v.neg(ONE)
 K={(0,0,(),(0,),0,0):v.scale(ONE,2),(0,0,(),(1,),0,0):v.scale(ONE,3)};Kt={(j,i,o,s,h,w):z for(i,j,o,s,h,w),z in K.items()};A={(0,0,(0,45),(),0,0):v.scale(ONE,5)}
 P=trace2(A,mm(K,Kt));assert pack(P)==[[0,45,[0,0],0,0,[[0,20,1]]],[0,45,[0,1],0,0,[[0,60,1]]],[0,45,[1,1],0,0,[[0,45,1]]]]
 return True
def main():
 tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(OUT/'validation_preparation.json');assert digest(Path(__file__))==prep['validator_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allowed={str(Path(p).resolve()) for p in prep['read_json']}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('INDEPENDENT_ACTUAL_SCALAR_POLE_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_JSON',str(p))
 sys.addaudithook(guard);assert selfcheck();M,u=mats('primary');other,ur=mats('replay');assert M==other and u['normalized_ordered_family_formulas']==ur['normalized_ordered_family_formulas'] and u['all40_actual_profile_family_correspondence']==ur['all40_actual_profile_family_correspondence'];del other
 a=read(OUT/'primary_result.json');b=read(OUT/'replay_result.json');assert a['family_physical_poles']==b['family_physical_poles'] and a['group_physical_poles']==b['group_physical_poles'] and a['group_exact_sha256']==b['group_exact_sha256'];groups={};family={};performance=[];controls={}
 formula={n:u['normalized_ordered_family_formulas'][n] for n in ['DMK','FYK','FFMK','FFY','YR','FMKX','FYX','YQ','YKX']};formula['PAIR_D']=[[['A','K','Kt'],'3']]
 for name,words in formula.items():
  t=time.perf_counter();result={}
  for word,co in words:
   value=word_trace(M,word);c=v.number(co)
   for key,z in value.items():put(result,key,v.mul(c,z))
  rows=pack(result);assert rows==a['family_physical_poles'][name],name;assert hashed(rows)==a['family_summary'][name]['exact_sha256'];family[name]={'nonzero':len(rows),'exact_sha256':hashed(rows)}
  if result:
   key=next(iter(result));alter=dict(result);alter[key]=v.neg(alter[key]);missing=dict(result);del missing[key];assert alter!=result and missing!=result;controls[name]={'one_nonzero_sign_flip_detected':True,'one_nonzero_omission_detected':True}
  else:controls[name]={'zero_family_sign_control':'INSENSITIVE;synthetic fixture retained'}
  group='g4_xi0_pair' if name=='PAIR_D' else'g4_xi1' if name in ['DMK','FYK','FFMK','FFY'] else'g4_xi2' if name=='YR' else'g3_xi2'
  for k,z in result.items():put(groups.setdefault(group,{}),k,z)
  performance.append({'family':name,'seconds':time.perf_counter()-t});print('STAGE independent '+name+' '+str(len(rows)),flush=True)
 for name,P in groups.items():assert pack(P)==a['group_physical_poles'][name] and hashed(pack(P))==a['group_exact_sha256'][name]
 combined=coalesce(a['group_physical_poles']);assert combined==coalesce(b['family_physical_poles'],True)
 combined_summary={};linear_tables={}
 for (g,h,xi,degree),P in combined.items():
  label=f'g{g}_etaH{h}_xi{xi}_scalar{degree}';rows=pack(P);combined_summary[label]={'nonzero':len(rows),'exact_sha256':hashed(rows)}
  if degree==1:linear_tables[label]=rows
  else:assert degree==2 and (g,h,xi)==(4,0,0) and rows==a['group_physical_poles']['g4_xi0_pair']
 assert a['complete_index_only_ceiling_verified']==b['complete_index_only_ceiling_verified']=={'linear':2217632,'pair':8623524} and a['complete_pair_symmetric_domain']==109260900 and a['complete_domain_per_linear_width_monomial']==664200
 assert len(a['all40_actual_profile_family_correspondence'])==40 and a['all40_actual_profile_family_correspondence']==u['all40_actual_profile_family_correspondence'] and a['actual_excluded_FFMM_profile_preserved']==2025 and a['zero_pair_families_qualified_not_recomputed']==['FX','FF','XX']
 assert all(a['controls'].values()) and a['controls']==b['controls'] and not a['canonical_integration_or_simultaneous_sourcefree_identity'] and not b['canonical_integration_or_simultaneous_sourcefree_identity'] and not any(a['all_seven_quantum_flags_false'].values()) and a['current_known_terms']==155143 and a['sourceimage_positions']==146663
 for cap in ['primary_capture.json','replay_capture.json']:
  z=read(OUT/cap);assert z['execution_state']=='COMPLETED' and z['exit_code']==0 and z['post_run_observations_qualified'] and z['calculation_completed']
 r={'schema':'ACTUAL_SCALAR_GHOST_POLE_INDEPENDENT_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':'ALL40_ACTUAL_SCALAR_GHOST_PROFILES_FULL_PHYSICAL_POLES_QUALIFIED_NOT_INTEGRATED','input_sha256':prep['input_sha256'],'independent_full_rational_radical_constant_absorption_matrix_products':True,'both_native_full_tables_and_all_zero_complements_verified':True,'full_pair_by_scalar_Gram_and_Bose_control_verified':True,'all_four_parameter_group_sums_and_hashes_verified':True,'all40_profile_and_coupling_width_origin_correspondence_verified':True,'both_input_role_full_mathematical_packets_equal':True,'native_finite_index_ceilings_verified':True,'full_pole_assembly_after_shared_parameter_coalescence_verified':True,'coalesced_physical_parameter_summary':combined_summary,'coalesced_physical_linear_tables':linear_tables,'coalesced_pair_full_table_reference':'primary_result.json:group_physical_poles:g4_xi0_pair;all333540 positions verified','family_summary':family,'group_nonzero_positions':{g:len(P) for g,P in groups.items()},'group_exact_sha256':a['group_exact_sha256'],'controls':controls,'independent_family_performance':performance,'native_worker_failures':0,'independent_worker_failures':0,'fresh_byte_identical_replay_pairs_claimed':0,'new_canonical_integration_or_full_E5_A5':'NOT_PERFORMED_UNQUALIFIED','protected_authority_and_current_functional_unchanged':True,'shared_limits':'Qualified action/Hessian/coordinate/UV/Gaussian premises,software and AI author shared;new complete rational arithmetic and regrouped finite contractions are computational corroboration,not physical validation','elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(r,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
