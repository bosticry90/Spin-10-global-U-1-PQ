"""Index-only future field-map sizing;no coefficient calculation or qualification."""
from pathlib import Path
from hashlib import sha256
from collections import Counter,defaultdict
import json,time,threading,os,subprocess
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
timer=threading.Timer(30,lambda:os._exit(124));timer.daemon=True;timer.start();tick=time.perf_counter();OUT=ROOT/'calculations/canonical_so10_scalar_ghost_actual_pole';post=read(CONTROL/'post_commit.json');assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==post['HEAD']=='f4086e6de82f9c09b995e26285ed061715febf11'
r=read(OUT/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and digest(OUT/'validation_receipt.json')==post['receipt_sha256']=='a1e1fd90e9a98158c7eed46f5c9b8f7c23cdb385cd08fee588ccb3d52871d47f';p=OUT/'primary_result.json';assert r['input_sha256'][str(p)]==digest(p);data=read(p)
refp=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_full_hessian/primary.json';bindings=read(refp.parent/'bindings.json');assert bindings['byte_sha256'][refp.relative_to(ROOT).as_posix()]==digest(refp);ref=read(refp)['retained_reference'];T=defaultdict(list)
for i,j,z in ref['physical_to_raw_kernel']['entries']:T[i].append((j,z))
names=ref['field_order'];assert len(names)==643
for i in range(180,508):assert len(T[i])==1 and names[T[i][0][0]].startswith('x_') and T[i][0][1]=='1'
for i in range(553,598):assert T[i] and all(names[j].startswith('C') for j,z in T[i])
for i in range(598,643):assert T[i] and all(names[j].startswith('ub') or names[j].startswith('bar') for j,z in T[i])
packets=dict(r['coalesced_physical_linear_tables']);packets['g4_etaH0_xi0_scalar2']=data['group_physical_poles']['g4_xi0_pair'];sizes={}
for label,rows in packets.items():
 expanded=sum(len(T[553+c])*len(T[553+a])*__import__('math').prod(len(T[180+x]) for x in ss) for c,a,ss,h,w,z in rows)
 sizes[label]={'physical_nonzero_positions':len(rows),'unfiltered_field_map_contributions':expanded}
out={'classification':'INDEX_ONLY_CANONICAL_FIELD_MAP_PLANNING_NOT_SCIENTIFIC_EVIDENCE_OR_ALLOWANCE','base_commit':post['HEAD'],'accepted_pole_receipt_sha256':digest(OUT/'validation_receipt.json'),'actual_reference_file_sha256':digest(refp),'parameter_group_sizes':sizes,'total_physical_positions':sum(x['physical_nonzero_positions'] for x in sizes.values()),'total_unfiltered_field_map_contributions':sum(x['unfiltered_field_map_contributions'] for x in sizes.values()),'scalar_map_is_unit_permutation_in_all328_directions':True,'no_coefficient_values_multiplied_or_new_physics_qualified':True,'seconds':time.perf_counter()-tick}
with(CONTROL/'canonical_support_cost_plan.json').open('xb') as f:f.write(json.dumps(out,sort_keys=True,separators=(',',':')).encode()+b'\n')
print(json.dumps(out,sort_keys=True));timer.cancel()
