from pathlib import Path
from hashlib import sha256
import json,ast,symtable,builtins,subprocess,importlib.util,sys
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_actual_pole';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='446dc0cbac619f1683b7f21e9a98a33fe6186457'
parent=ROOT/'calculations/canonical_so10_scalar_ghost_physical_operators/validation_receipt.json';r=read(parent);assert r['execution_state']=='COMPLETED' and digest(parent)=='5e9111e97c80f31d241cb366fcc861608a04b82ca1cede4cbfec8b0d4b90d262'
files={Path(p) for p in r['input_sha256']}|{parent,OUT/'RECORD.md',ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V280.md',ROOT/'AGENTS.md',ROOT/'CHARTER.md',ROOT/'project_state.json'}
for p,h in r['input_sha256'].items():assert digest(Path(p))==h,p
oldcontrol=CONTROL.parent/'scalar-ghost-physical-operators-v1-2026-10-18'
files|={oldcontrol/'post_commit.json',oldcontrol/'trace_support_cost_plan.json',oldcontrol/'trace_support_cost.py'}
roles={};probes=[]
for role in ['primary','replay']:
 roles[role]={OUT/'preparation.json'}
 for folder,name in [('canonical_so10_scalar_ghost_physical_operators','primary_result.json' if role=='primary' else'replay_v2_result.json'),('canonical_so10_ghost_mass_g4_pole',role+'_v2_result.json'),('canonical_so10_fourghost_g4_lorentz',role+'_result.json'),('canonical_so10_unified_scalar_ghost_symbol',role+'_v2_result.json')]:
  p=ROOT/'calculations'/folder/name;rr=p.parent/'validation_receipt.json';z=read(rr);assert z['execution_state']=='COMPLETED' and z['input_sha256'][str(p)]==digest(p);roles[role].update([p,rr]);files.update([p,rr]);probes.append({'path':str(p),'receipt':str(rr),'sha256':digest(p)})
for p in [OUT/'pole.py',CONTROL/'run.py',Path(__file__)]:
 text=p.read_text(encoding='utf-8');ast.parse(text);tree=symtable.symtable(text,str(p),'exec');defs={z.get_name() for z in tree.get_symbols() if z.is_assigned() or z.is_imported() or z.is_namespace()}|set(dir(builtins))|{'__file__','__name__','__package__'};errors=[]
 def scan(t):
  for z in t.get_symbols():
   if z.is_referenced() and z.is_global() and z.get_name() not in defs:errors.append((t.get_name(),z.get_name()))
  for q in t.get_children():scan(q)
 scan(tree);assert not errors,errors
sp=importlib.util.spec_from_file_location('actual_scalar_pole_preflight',OUT/'pole.py');u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);controls=u.controls();types={}
for role in ['primary','replay']:
 M,D,sy,data=u.matrices(role);assert len(sy['all40_actual_profile_family_correspondence'])==40
 expected=[u.old.unpack(u.auth('canonical_so10_scalar_ghost_physical_operators','primary_result.json' if role=='primary' else'replay_v2_result.json')['physical_'+t]) for t in ['X','Xr','Z','Q']]
 for t,P in zip(['X','Xr','Z','Q'],expected):
  actual={}
  for i,j,o,s,h,w,z in M[t]:
   key=(i,j,*o) if t!='Z' else(i,j,s[0]);actual[key]=tuple((m,u.F(v,D[t])) for m,v in z)
  assert actual=={k:tuple((m,v) for(a,b,m),v in sorted(z.cells.items())) for k,z in P.items()}
 Y=u.old.unpack(u.auth('canonical_so10_ghost_mass_g4_pole',role+'_v2_result.json')['physical_Y_aC_density']);U,V=u.old.p.orbit_hessian(Y,role)
 for tag,packet in [('U',U),('V',V)]:
  actual={(i,j,o):tuple((m,u.F(v,D[tag])) for m,v in z) for i,j,o,s,h,w,z in M[tag]}
  assert actual=={(i,j,o):tuple((m,v) for(a,b,m),v in sorted(z.cells.items())) for(i,j),pp in packet.items() for o,z in pp.items()}
 assert all(a==0 or a==1 for n,ds in D.items() for a in [int(ds>0)])
 for tag,rows in M.items():assert len(rows)==len({(i,j,o,s,h,w) for i,j,o,s,h,w,z in rows}) and all(z for i,j,o,s,h,w,z in rows)
 json.dumps({'counts':{k:len(v) for k,v in M.items()},'denominators':D,'packed':u.pack({(0,45,(1,2),0,0):((0,7),(8,-3))},5)})
 types[role]={'operator_counts':{k:len(v) for k,v in M.items()},'exact_integer_scalings':D,'all_complete_X_Q_Z_and_both_U_V_reconciled':True,'all40_profile_metadata_checked':True}
for mod in list(sys.modules.values()):
 name=getattr(mod,'__file__',None)
 if name:
  p=Path(name).resolve()
  if p.suffix=='.py' and(p.is_relative_to(ROOT) or p.is_relative_to(CONTROL.parent)):files.add(p)
for p in [OUT/'pole.py',CONTROL/'run.py',Path(__file__)]:
 copy=Path(str(p)+'.source.txt')
 with copy.open('xb') as f:f.write(p.read_bytes())
 files.update([p,copy])
d={'schema':'ACTUAL_SCALAR_GHOST_POLE_PREPARATION_V1','base_commit':head,'source_sha256':digest(OUT/'pole.py'),'controller_sha256':digest(CONTROL/'run.py'),'input_sha256':{str(p):digest(p) for p in sorted(files)},'read_json_by_role':{role:[str(p) for p in sorted(pp)] for role,pp in roles.items()},'qualified_input_probes':probes,'preflight_all_operator_types_scalings_and_mixed_maps':types,'arithmetic_sign_and_Bose_controls':controls,'limits':{'seconds_after_imports':300,'private_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2},'all_source_copies_exclusive':True,'metadata_json_type_preflight_passed':True}
with(OUT/'preparation.json').open('xb') as f:f.write(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('FROZEN',len(files),'types',types)
