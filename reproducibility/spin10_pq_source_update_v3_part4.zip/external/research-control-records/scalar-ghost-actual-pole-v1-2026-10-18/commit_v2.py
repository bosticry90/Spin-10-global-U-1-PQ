from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,subprocess
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_actual_pole';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def git(*args,raw=False):
 z=subprocess.check_output(['git',*args],cwd=ROOT);return z if raw else z.decode('utf-8').strip()
base=read(OUT/'preparation.json')['base_commit'];assert git('rev-parse','HEAD')==base=='446dc0cbac619f1683b7f21e9a98a33fe6186457'
r=read(OUT/'validation_receipt.json');assert r['schema']=='ACTUAL_SCALAR_GHOST_POLE_INDEPENDENT_VALIDATION_V1' and r['execution_state']=='COMPLETED' and r['scientific_disposition']=='ALL40_ACTUAL_SCALAR_GHOST_PROFILES_FULL_PHYSICAL_POLES_QUALIFIED_NOT_INTEGRATED'
for k,z in r.items():
 if type(z) is bool:assert z,k
assert r['native_worker_failures']==r['independent_worker_failures']==r['fresh_byte_identical_replay_pairs_claimed']==0 and r['new_canonical_integration_or_full_E5_A5']=='NOT_PERFORMED_UNQUALIFIED'
assert digest(OUT/'validation_receipt.json')=='a1e1fd90e9a98158c7eed46f5c9b8f7c23cdb385cd08fee588ccb3d52871d47f'
maps={}
for name in ['preparation.json','validation_preparation.json','validation_receipt.json']:
 d=read(OUT/name);maps[name]=len(d['input_sha256'])
 for p,h in d['input_sha256'].items():assert digest(Path(p))==h,(name,p)
assert list(maps.values())==[1792,1806,1806]
for folder in [OUT,CONTROL]:
 for p in folder.glob('*.source.txt'):assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes(),p
for short in ['primary','replay','validation']:
 cap=read(OUT/(short+'_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'] and cap['private_allocation_limit_bytes']==8*1024**3
 assert (OUT/(short+'_capture.json')).read_bytes()==(CONTROL/(short+'_full_capture.json')).read_bytes() and cap['all_resource_samples'] and all('query_error' not in z and 0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
 assert 0<read(OUT/('validation_receipt.json' if short=='validation' else short+'_result.json'))['elapsed_after_imports']<300
a=read(OUT/'primary_result.json');b=read(OUT/'replay_result.json');assert a['schema']==b['schema']=='ACTUAL_SCALAR_GHOST_COMPLETE_PHYSICAL_POLE_V1'
for key in a.keys()-{'route','elapsed_after_imports','contraction_metadata'}:assert a[key]==b[key],key
assert a['group_exact_sha256']==r['group_exact_sha256'] and a['group_nonzero_positions']==r['group_nonzero_positions']=={'g3_xi2':5256,'g4_xi0_pair':333540,'g4_xi1':20500,'g4_xi2':9632} and all(a['controls'].values()) and not any(a['all_seven_quantum_flags_false'].values())
assert {k:v['nonzero'] for k,v in r['coalesced_physical_parameter_summary'].items()}=={'g3_etaH0_xi2_scalar1':5256,'g4_etaH0_xi0_scalar2':333540,'g4_etaH0_xi2_scalar1':10224,'g4_etaH1_xi1_scalar1':10080}
assert a['current_known_terms']==155143 and a['current_known_sha256']=='fe6bd8e800d8e04f9d0358ce94c081d70e94af0ffd37830bb50c02fdbb0c0241' and a['sourceimage_positions']==146663 and not a['canonical_integration_or_simultaneous_sourcefree_identity'] and not a['full_QAP_IR_measure_products_contacts_equivalence_E5_A5']
coverage=[]
for role in ['primary','replay']:
 old=ROOT/'calculations/canonical_so10_higher_scalar_pair_reduction'/(role+'_result.json');receipt=read(old.parent/'validation_receipt.json');assert receipt['execution_state']=='COMPLETED' and receipt['input_sha256'][str(old)]==digest(old)
 prior=read(old)['all664_updated_scope_rows'];assert len(prior)==664 and len({x['index'] for x in prior})==664 and sum(x['complete_scope_match'] is True for x in prior)==329;assert all(type(x['complete_scope_match']) in [bool,type(None)] for x in prior)
 ledger={x['index']:x for x in prior};new=(a if role=='primary' else b)['all40_actual_profile_family_correspondence'];ids={x['index'] for x in new};wanted={x['index'] for x in prior if not x['complete_scope_match'] and x['types'] in [['C','a','x'],['C','a','x','x']]};assert len(new)==len(ids)==40 and ids==wanted
 for row in new:
  previous=ledger[row['index']];assert not previous['complete_scope_match'] and row['g']==previous['g'] and row['scalar_degree']==len(previous['types'])-2 and row['explicit_vertex_xi']==previous['descriptor']['explicit_vertex_xi'] and row['BB_width_roles']==previous['descriptor']['BB_width_roles']
 matched={x['index'] for x in prior if x['complete_scope_match']}|ids;unmatched=set(ledger)-matched;assert len(matched)==369 and len(unmatched)==295 and not matched&unmatched
 counts={g:{'complete':sum(ledger[i]['g']==g for i in matched),'unmatched':sum(ledger[i]['g']==g for i in unmatched)} for g in range(1,5)};assert counts=={1:{'complete':12,'unmatched':0},2:{'complete':87,'unmatched':0},3:{'complete':172,'unmatched':85},4:{'complete':98,'unmatched':210}}
 remain=Counter((tuple(ledger[i]['types']),ledger[i]['g']) for i in unmatched);assert remain=={(('B','B','C','a'),4):147,(('B','B','C','a'),3):76,(('A','B','C','a'),4):56,(('A','B','C','a'),3):9,(('A','A','C','a'),4):7}
 coverage.append({'role':role,'prior_receipt_sha256':digest(old.parent/'validation_receipt.json'),'prior_ledger_result_sha256':digest(old),'new_exact_profile_indices':sorted(ids),'complete':len(matched),'unmatched':len(unmatched),'by_g':counts,'all_remaining_have_two_vectors_and_C_a':True})
assert coverage[0]['new_exact_profile_indices']==coverage[1]['new_exact_profile_indices'] and coverage[0]['by_g']==coverage[1]['by_g']
for p in ['AGENTS.md','CHARTER.md','README.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md']:assert git('show',base+':'+p,raw=True)==(ROOT/p).read_bytes(),p
paths=sorted([p.relative_to(ROOT).as_posix() for p in OUT.iterdir() if p.is_file()]+['docs/RESEARCH_EXECUTION_HANDOFF_V281.md']);assert set(git('ls-files','--others','--exclude-standard').splitlines())==set(paths) and not git('diff','--name-only') and not git('diff','--cached','--name-only')
for p in [ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V281.md',OUT/'RESULT_V2.md']:assert digest(OUT/'validation_receipt.json') in p.read_text(encoding='utf-8')
subprocess.check_call(['git','-c','core.autocrlf=false','-c','core.longpaths=true','add','--',*paths],cwd=ROOT);assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
for p in paths:assert git('show',':'+p,raw=True)==(ROOT/p).read_bytes(),p
subprocess.check_call(['git','diff','--cached','--check'],cwd=ROOT);subprocess.check_call(['git','commit','-m','Qualify complete actual scalar dependent ghost poles with full sparse verification'],cwd=ROOT)
head=git('rev-parse','HEAD');assert git('rev-parse','HEAD^')==base and set(git('diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines())==set(paths)
for p in paths:assert git('show','HEAD:'+p,raw=True)==git('show',':'+p,raw=True)==(ROOT/p).read_bytes(),p
assert not git('status','--porcelain=v1')
proof={'HEAD':head,'parent':base,'exact_changed_files':paths,'all_HEAD_index_worktree_bytes_equal':True,'working_tree_clean':True,'receipt_sha256':digest(OUT/'validation_receipt.json'),'authority_unchanged':digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8','all_three_current_input_binding_maps':maps,'all_actual_scalar_ghost_poles_zero_domains_and_parameter_coalescence_verified':True,'all40_profile_indices_reconciled_to_prior_unmatched_set':coverage,'current_functional_unchanged':True,'failed_custody_controller_preserved_sha256':digest(CONTROL/'commit.py'),'custody_failure_record_sha256':digest(CONTROL/'commit_failure.json'),'legacy_null_unreconciled_not_counted_as_complete':True,'full_E5_A5':'UNQUALIFIED','no_remote_action':True,'commit_controller_sha256':digest(Path(__file__))};assert proof['authority_unchanged']
with(CONTROL/'post_commit.json').open('xb') as f:f.write(json.dumps(proof,sort_keys=True,separators=(',',':')).encode()+b'\n')
print(json.dumps({'HEAD':head,'files':len(paths),'clean':True,'receipt_sha256':proof['receipt_sha256'],'same_finite_inventory_complete':369,'same_finite_inventory_unmatched':295,'full_E5_A5':'UNQUALIFIED'}))
