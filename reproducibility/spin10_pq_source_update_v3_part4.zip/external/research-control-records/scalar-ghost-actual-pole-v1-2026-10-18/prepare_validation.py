from pathlib import Path
from hashlib import sha256
import json,ast,symtable,builtins,subprocess,importlib.util,sys
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_ghost_actual_pole';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
prep=read(OUT/'preparation.json');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head==prep['base_commit']=='446dc0cbac619f1683b7f21e9a98a33fe6186457'
files={Path(p) for p in prep['input_sha256']}|{OUT/'preparation.json',OUT/'RESULT_V1.md'};allowed={OUT/'validation_preparation.json'}
for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
for role in ['primary','replay']:
 cap=OUT/(role+'_capture.json');result=OUT/(role+'_result.json');c=read(cap);assert c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified'] and c['exit_code']==0 and cap.read_bytes()==(CONTROL/(role+'_full_capture.json')).read_bytes();r=read(result);assert r['route']==role and 0<r['elapsed_after_imports']<300;files.update([cap,result,CONTROL/(role+'_full_capture.json')]);allowed.update([cap,result]);allowed.update(Path(p) for p in prep['read_json_by_role'][role])
a=read(OUT/'primary_result.json');b=read(OUT/'replay_result.json')
for key in a.keys()-{'route','elapsed_after_imports','contraction_metadata'}:assert a[key]==b[key],key
assert a['complete_index_only_ceiling_verified']=={'linear':2217632,'pair':8623524} and all(a['controls'].values())
for p in [CONTROL/'verify.py',CONTROL/'run_validation.py',Path(__file__)]:
 text=p.read_text(encoding='utf-8');ast.parse(text);tree=symtable.symtable(text,str(p),'exec');defs={z.get_name() for z in tree.get_symbols() if z.is_assigned() or z.is_imported() or z.is_namespace()}|set(dir(builtins))|{'__file__','__name__','__package__'};errors=[]
 def scan(t):
  for z in t.get_symbols():
   if z.is_referenced() and z.is_global() and z.get_name() not in defs:errors.append((t.get_name(),z.get_name()))
  for q in t.get_children():scan(q)
 scan(tree);assert not errors,errors
sp=importlib.util.spec_from_file_location('independent_scalar_pole_preflight',CONTROL/'verify.py');u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);assert u.selfcheck();M,f=u.mats('primary');N,ff=u.mats('replay');assert M==N and f['normalized_ordered_family_formulas']==ff['normalized_ordered_family_formulas'];assert len(M['K'])==12560 and len(M['Q'])==37152;json.dumps(u.pack(u.unpack(a['family_physical_poles']['DMK']) ));del M,N
for mod in list(sys.modules.values()):
 name=getattr(mod,'__file__',None)
 if name:
  p=Path(name).resolve()
  if p.suffix=='.py' and(p.is_relative_to(ROOT) or p.is_relative_to(CONTROL.parent)):files.add(p)
for p in [CONTROL/'verify.py',CONTROL/'run_validation.py',Path(__file__)]:
 copy=Path(str(p)+'.source.txt')
 with copy.open('xb') as g:g.write(p.read_bytes())
 files.update([p,copy])
d={'schema':'ACTUAL_SCALAR_GHOST_POLE_VALIDATION_PREPARATION_V1','base_commit':head,'validator_sha256':digest(CONTROL/'verify.py'),'controller_sha256':digest(CONTROL/'run_validation.py'),'input_sha256':{str(p):digest(p) for p in sorted(files)},'read_json':[str(p) for p in sorted(allowed)],'both_full_native_mathematical_payloads_equal':True,'all_independent_input_matrices_and_types_reconciled':True,'independent_odd_and_scalar_Bose_preflight_passed':True,'metadata_json_type_preflight_passed':True,'undefined_global_static_preflight_errors':[],'all_source_copies_exclusive':True,'completed_native_workers':2,'failed_native_workers':0,'limits':{'seconds_after_imports':300,'private_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2}}
with(OUT/'validation_preparation.json').open('xb') as g:g.write(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('VALIDATION_FROZEN',len(files),'groups',a['group_nonzero_positions'])
