from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Q
from collections import Counter,defaultdict
from itertools import permutations,product
from math import factorial,prod
import json,os,sys,threading,time
import sympy as s
R=Path(r'C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_vector_quartic_symbol';P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(P));from audit_a10_e5_antighost_vector import resource,line_json
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(O/'validation_preparation.json');assert digest(Path(__file__))==prep['source_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allowed={str(Path(p).resolve()) for p in prep['read_json']}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('VECTOR_SYMBOL_VALIDATOR_WRITE')
  if p.suffix=='.json':assert str(p) in allowed,('UNDECLARED_VECTOR_SYMBOL_VALIDATION_JSON',str(p))
 sys.addaudithook(guard);native={r:read(O/(r+'_v2_result.json')) for r in ['primary','replay']}
 for role,a in native.items():
  cap=read(O/(role+'_v2_capture.json'));resource(cap);assert line_json(cap['stdout_and_stderr'],'RESULT ')==a and 0<a['elapsed_after_imports']<180
 assert {k:v for k,v in native['primary'].items() if k not in ['route','elapsed_after_imports']}=={k:v for k,v in native['replay'].items() if k not in ['route','elapsed_after_imports']}
 failed=read(O/'primary_capture.json');assert failed['execution_state']=='FAILED' and failed['exit_code']==1 and 'AssertionError' in failed['stdout_and_stderr'];a=native['primary'];scope=a['scope']
 inv=read(R/'calculations/canonical_so10_sourcefree_cycle_inventory/primary_v2_result.json');ledger=read(R/'calculations/canonical_so10_higher_scalar_pair_reduction/primary_result.json')['all664_updated_scope_rows'];vertices=inv['actual_sourcefree_vertices'];edges=set(map(tuple,inv['actual_reference_edges']));rows=[r for r in ledger if sorted(r['types']) in [sorted(['A','A','C','a']),sorted(['A','B','C','a']),sorted(['B','B','C','a'])]];selected=[r for r in rows if not r['complete_scope_match']];old=[r for r in rows if r['complete_scope_match']];assert len(selected)==295 and len(old)==14
 assert {r['index'] for r in selected}=={r['index'] for r in scope['all295_exact_profile_bindings']};aux=[]
 for row in selected:
  rr=inv['all_profiles'][row['index']];assert {k:v for k,v in rr.items() if k!='witness'}==row['descriptor'];ports=rr['witness']['vertices'];outer=[];den_degree=0;num_degree=0;width=set()
  for i,(tag,p,q,rest) in enumerate(ports):
   vertex=vertices[tag];assert any(sorted(z)==sorted([p,q]+rest) for z in vertex['ports']);assert vertex['cd']==0;outer+=rest;num_degree+=p[1]+q[1];nxt=ports[(i+1)%len(ports)][1]
   assert (q[0],nxt[0]) in edges;assert not p[0].startswith(('A','X_')) and not q[0].startswith(('A','X_'));assert len(rest)==vertex['degree']-2
   den_degree+=4-(2 if q[0].startswith('L') else 1)-(2 if nxt[0].startswith('L') else 1)
   if q[0][0]==nxt[0][0]=='B':width.add(q[0])
  assert sorted(outer)==rr['external_ports'] and not any(j for n,j in outer);assert num_degree-den_degree==-4 and rr['vertex_coefficient_dimension']==0 and not rr['scalar_reference_mass_expansions'];assert sorted(width)==rr['BB_width_roles']
  if any(p[0].startswith('L') or q[0].startswith('L') for tag,p,q,rest in ports):aux.append(row['index'])
 assert aux==scope['omit_auxiliary_ports_misses_indices'] and len(aux)==147
 # Independently count labelled permutations,then divide identical-vertex
 # factorials. This is neither the native unique-word accumulation nor its
 # cyclic-orbit-length method.
 totalwords=0
 for rec in scope['all29_family_ordered_trace_rules']:
  family=rec['family'];n=len(family);counts=Counter();den=n*prod(factorial(v) for v in Counter(family).values())
  for lab in permutations(range(n)):
   ww=tuple(family[i] for i in lab);canonical=min(ww[k:]+ww[:k] for k in range(n));counts[canonical]+=1
  expected=[[list(w),Q((-1)**n*ct,den).numerator,Q((-1)**n*ct,den).denominator] for w,ct in sorted(counts.items())];assert expected==rec['normalized_cyclic_trace_words'];totalwords+=len(expected)
 assert totalwords==53
 # Direct ordinary2x2 determinant derivative for the ca nilpotent marker.
 # This code imports neither native ring nor native path/formula helpers.
 f=read(O/'fixture.json');v,w,theta=s.symbols('v w theta');I=s.eye(2)
 def M(k):return s.Matrix(f[k])
 E=I+v*M('E_v')+w*M('E_w')+v*v*M('E_vv')+v*w*M('E_vw')+w*w*M('E_ww');D=I+v*M('O_v')+w*M('O_w')+v*v*M('O_vv')+v*w*M('O_vw')+w*w*M('O_ww')
 def mix(tag):return M(tag+'_0')+v*M(tag+'_v')+w*M(tag+'_w')
 eff=M('E_ca')-mix('Bc')*D.inv()*mix('Ca')+mix('Ba')*D.inv()*mix('Cc')
 def determinant_derivative(A,B):return B[0,0]*A[1,1]+A[0,0]*B[1,1]-B[0,1]*A[1,0]-A[0,1]*B[1,0]
 logca=determinant_derivative(E,eff)/E.det()-determinant_derivative(D,M('O_ca'))/D.det()
 values=[]
 for dv,dw in [(2,0),(1,1),(0,2)]:
  coefficient=s.simplify(-s.diff(logca,v,dv,w,dw).subs({v:0,w:0})/(factorial(dv)*factorial(dw)));assert coefficient.is_Rational;values.append([dv,dw,int(coefficient.p),int(coefficient.q)])
 assert values==a['fixture_three_coefficients_v2_vw_w2_ca']==[[2,0,-16,1],[1,1,-136,1],[0,2,-40,1]]
 print('STAGE independent all295_profiles_53_cyclic_weights_and_literal_determinant_fixture',flush=True)
 # Integer same-axis matching counts divided by4*6*...;no native recurrence
 # and no Gaussian Gamma implementation is used.
 moments=[]
 for degree in range(13):
  for first in product(range(degree+1),repeat=3):
   last=degree-sum(first)
   if last<0:continue
   power=first+(last,)
   if any(q%2 for q in power):z=Q(0)
   else:z=Q(prod(prod(range(1,q,2)) for q in power),prod(range(4,4+degree,2)))
   moments.append([list(power),z.numerator,z.denominator])
 assert moments==a['complete_fourD_angular_moments'] and len(moments)==1820 and sum(z[1]!=0 for z in moments)==210
 assert sha256(json.dumps(moments,separators=(',',':')).encode()).hexdigest()==a['angular_moments_sha256']
 def labelled_pairings(n):
  if not n:return 1
  return sum(labelled_pairings(n-2) for j in range(1,n))
 assert labelled_pairings(12)==10395
 scalar_ports=0;positive=[]
 for tag,V in vertices.items():
  if V['cd']>0:positive.append(tag);continue
  for whole in V['ports']:
   for i in range(len(whole)):
    for j in range(len(whole)):
     if i==j:continue
     p,q=whole[i],whole[j];out=[z for k,z in enumerate(whole) if k not in [i,j]]
     if p[0].startswith('A') or q[0].startswith('A') or len(out) not in [1,2] or any(z[1] or z[0].startswith(('L','X_')) for z in out):continue
     if p[0].startswith('X_') or q[0].startswith('X_'):assert p[0].startswith('X_') and q[0].startswith('X_') and all(z[0][0] in 'AB' for z in out);scalar_ports+=1
 assert scalar_ports==40==scope['scalar_only_marginal_port_options'] and set(positive)==set(scope['all16_positive_dimension_exclusions'])
 # Noncommuting baseline/resolvent control differentiated directly from det.
 u=s.Symbol('ghost_count');K0=s.Matrix([[4,1],[1,3]]);RA=s.Matrix([[2,1],[0,1]]);V0=s.Matrix([[0,2],[1,0]]);V1=s.Matrix([[1,0],[2,-1]]);V2=s.Matrix([[0,1],[-1,1]]);H0=K0+RA+V0;Hu=H0+u*V1+u*u*V2
 assert RA*V1!=V1*RA and Hu.inv()==(K0+RA).inv()-(K0+RA).inv()*(V0+u*V1+u*u*V2)*Hu.inv()
 second=s.simplify(s.diff(s.log(Hu.det()),u,2).subs(u,0));assert second==2*s.trace(H0.inv()*V2)-s.trace(H0.inv()*V1*H0.inv()*V1)
 assert all(a['controls'].values());assert digest(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
 rec={'schema':'VECTOR_QUARTIC_SYMBOL_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':a['scientific_disposition'],'input_sha256':prep['input_sha256'],'both_native_methods_agree':True,'all295_individual_witness_ports_roles_widths_dimensions_and_indices_verified':True,'all29_families53_cyclic_trace_coefficients_from_labelled_permutations':True,'all14_prior_zero_profiles_preserved_not_rerun':True,'independent_literal_determinant_fixture_all_three_coefficients':values,'all1820_moments210_nonzero_from_integer_pair_counts':True,'angular_moments_sha256':a['angular_moments_sha256'],'highest_pair_count_10395_verified':True,'all40_scalar_ports_have_no_ghost_block':True,'actual147_auxiliary_reaching_profiles_require_auxiliaries':True,'reference_reexpansion_analytic_scope_review':['same full-H resolvent;R_A positive background degree','Gamma_ref[A] has no external ghost coefficient but is retained','leading local UV residue only in explicit qualified Weyl/heat family','no arbitrary determinant multiplicativity or finite/IR/global assertion'],'performance':{r:{'seconds':native[r]['elapsed_after_imports'],'sampled_private_bytes':max(z['private_bytes'] for z in read(O/(r+'_v2_capture.json'))['all_resource_samples'])} for r in native},'native_failed_workers':1,'original_negative_control_harness_failure_preserved':True,'independent_failed_workers':0,'actual_Spin10_color_coefficients_measured':False,'checks_not_performed':['actual_full_H1_H2_color_Lorentz_table_extraction','actual295_pole_coefficients','canonical_integration_or_Ward_Slavnov_evaluation','baseline_finite_contact_or_simultaneous_renormalization_construction','QAP_measure_IR_equivalence_E5_A5','Lean_or_external_expert_review'],'authority_Gamma_source38_369of664_295inventory_unchanged':True,'shared_limits':a['shared_limits'],'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(rec,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
