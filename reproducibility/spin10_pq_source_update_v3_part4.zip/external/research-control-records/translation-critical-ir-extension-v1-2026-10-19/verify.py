"""Separate action census and beta-parameter/radial critical-distribution check."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import gzip,json,os,sys,time,threading
import sympy as s
import mpmath as mp
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_translation_critical_ir_extension';C=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
vp=read(O/'validation_preparation.json')
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h,raw
def guard(event,args):
 if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
 p=Path(os.fsdecode(args[0])).resolve()
 if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('TCI_VERIFIER_WRITE')
 if p.suffix=='.json':assert str(p) in vp['input_sha256'] or p==O/'validation_preparation.json',('UNBOUND_TCI_JSON',str(p))
sys.addaudithook(guard)
P=read(O/'primary_v2_result.json');Q=read(O/'replay_v3_result.json');omit={'route','elapsed_after_imports','numerical_controls'}
assert {k:v for k,v in P.items() if k not in omit}=={k:v for k,v in Q.items() if k not in omit}
g,xi,eta=s.symbols('g10 xi eta_H',real=True);ss,eps,nu,tt,beta=s.symbols('s epsilon nu t beta',positive=True);dd=s.Symbol('d',real=True)
@lru_cache(None)
def ex(text):return s.expand(s.sympify(text,locals={'g10':g,'xi':xi,'eta_H':eta,'reference_width_H':eta,'reference_width_M':xi,'s':ss,'epsilon':eps,'nu':nu,'t':tt,'d':dd}))
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));names=data['geometry']['names'];idx={n:i for i,n in enumerate(names)}
old=read(R/'calculations/canonical_so10_source_primitive_transport/replay_result.json');tau={}
for name,rows in old['all643_field_columns'].items():
 value=s.expand(sum(g**row['g']*ex(row['coefficient']) for row in rows if not row['word']))
 if value!=0:assert name.startswith('x_');tau[name]=value
assert len(tau)==20
def shift(rows):
 out={}
 for row in rows:
  co=g**row.get('g',0)*ex(row['coefficient']);word=tuple(row['word'])
  for k,name in enumerate(word):
   if name in tau:
    rest=word[:k]+word[k+1:];v=s.expand(out.get(rest,0)+tau[name]*co)
    if v==0:out.pop(rest,None)
    else:out[rest]=v
 return out
dGF=shift(data['gauge_fixing_density']);assert len(dGF)==P['GF_variation_positions']
anti=[('bar' if i<12 else 'ub')+str(i) for i in range(45)];ci={f'C{i}':i for i in range(45)};ai={n:i for i,n in enumerate(anti)}
nr={}
for word,co in dGF.items():
 assert len(word)==2 and not any('__' in n for n in word)
 cs=[n for n in word if n in ci];aa=[n for n in word if n in ai];assert len(cs)==len(aa)==1
 sign=1 if word==(cs[0],aa[0]) else -1;key=(ci[cs[0]],ai[aa[0]]);nr[key]=s.expand(nr.get(key,0)+sign*co)
nonzero=0;source_positions=0;maximum=0
for name,rows in data['master_field_maps'].items():
 delta=shift(rows);nonzero+=bool(delta);source_positions+=len(delta);maximum=max([maximum]+[len(word) for word in delta])
assert maximum<=1 and nonzero==P['source_translation_nonzero_rules'] and source_positions==P['source_translation_positions']
assert maximum==P['max_source_translation_field_degree'] and len(data['master_field_maps'])==643
core=read(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_full_hessian/replay.json');census=[]
active={'Phi','Sigma','SigmaBar','x_Phi','x_Sigma'}
for term in core['physical_Hessian_program']['all_34_literal_terms']:
 possible=set()
 for powers,word,co in term['index_jet_graph_coefficients']:
  fs=[node for node in word if node[0]=='Field'];ordinary=[node for node in fs if not node[1].startswith(('h_','k_'))]
  if len(ordinary)!=1 or ordinary[0][1] not in active or ordinary[0][3]:continue
  variations=[node for node in fs if node not in ordinary];assert len(variations)==2
  types=sorted('B' if node[1][2:]=='B' else 'x' for node in variations);degree=sum(len(node[3]) for node in variations)
  possible.add((types[0],types[1],degree))
 assert possible<={('B','x',1),('x','x',0)}
 census.append({'term':term['term_id'],'possible_translation_H0_channels':[list(x) for x in sorted(possible)]})
assert len(census)==34 and census==P['physical_34_term_channel_census']
assert P['dressed_response_soft_orders']==[['B','x',1,2],['x','B',1,2],['x','x',0,2],['C','a',0,4],['a','C',0,4]]
print('STAGE verifier_complete_GF_and643_source_variations_and34_physical_term_critical_sector_census',flush=True)

def clean(M):return s.SparseMatrix(M.applyfunc(s.expand))
def mat(packet):return s.SparseMatrix(*packet['shape'],{(i,j):ex(c) for i,j,c in packet['entries']})
ref=core['retained_reference'];Ti=mat(ref['physical_to_raw_inverse']);pos={n:i for i,n in enumerate(ref['field_order'])};cr=[pos[f'C{i}'] for i in range(45)];ar=[pos[n] for n in anti]
Tc=Ti.extract(cr,list(range(553,598)));Ta=Ti.extract(ar,list(range(598,643)));N=clean(Tc.T*s.SparseMatrix(45,45,nr)*Ta)
parent=read(R/'calculations/canonical_so10_general_first_order_transport/replay_v3_result.json');oldN=s.SparseMatrix(45,45,{(i,j):ex(c) for i,j,c in parent['actual_ghost_mass_physical']})
assert not clean(N-oldN).nnz() and N.nnz()==57
Kraw=mat(ref['reference_Hessian_raw_C3']);Ca=clean(Tc.T*Kraw.extract(cr,ar)*Ta)
pp=[s.Symbol(f'p0_ref{i}') for i in range(4)];q=s.symbols('q0:4',real=True);q2=sum(v*v for v in q);wick={pp[0]:s.I*q[0],pp[1]:q[1],pp[2]:q[2],pp[3]:q[3]}
D=clean(Ca.applyfunc(lambda c:s.cancel(c.subs(wick)/q2)));assert D.det()!=0 and not any(c.has(*q,g,xi,eta) for c in D)
Gca=-D.T.inv();Gac=D.inv();Eca=clean(D.T.inv()*N.T*D.T.inv());Eac=clean(-D.inv()*N*D.inv())
assert not clean(D*Eac+N*Gac).nnz() and not clean(-D.T*Eca-N.T*Gca).nnz()
assert not clean(Eca*(-D.T)+Gca*(-N.T)).nnz() and not clean(Eac*D+Gac*N).nnz()
target=s.SparseMatrix(45,45,{(i,j):ex(c) for i,j,c in P['actual_response_topright']});assert not clean(Eca-target).nnz() and Eca.nnz()==57
assert P['actual_response_90field_nonzero']==114
chi,h=s.symbols('chi h',positive=True)
# The two distinct inverse variations retain the actual chi/heat scalars.
assert s.cancel((chi*h)**2/(chi*h)-chi*h)==0
assert s.cancel((chi*h)**2/(chi*h)**2-1)==0
assert chi**2*h**2!=chi*h
print('STAGE verifier_all2025_coefficients_graded_inverse_normalization_and_distinct_regulated_words',flush=True)

mp.mp.dps=65;radial_controls=[]
def lognormal(expr):return s.expand(expr.replace(lambda v:v.func==s.log,lambda v:s.expand_log(s.log(s.factor(v.args[0])),force=True)))
for m in [1,2,4]:
 # Independent beta derivative and zero-profile initial condition,not native binomial/Mellin comparison.
 weights=[s.Integer(m)*(-1)**(j-1)*s.binomial(m-1,j-1)/j for j in range(1,m+1)]
 Ibeta=sum(weights[j-1]*s.log(1+j*beta/ss) for j in range(1,m+1));assert Ibeta.subs(beta,0)==0 and sum(weights)==1
 given=ex(P['profile_finite_parts'][str(m)]['gaussian_16pi2']).subs(eps,beta**s.Rational(-1,2))
 assert s.cancel(s.diff(Ibeta,beta)-s.diff(given,beta))==0 and s.simplify(given.subs(beta,0))==0
 cm=s.expand(s.EulerGamma+sum(weights[j-1]*s.log(j) for j in range(1,m+1)))
 assert s.simplify(cm-ex(P['profile_finite_parts'][str(m)]['finite_IR_offset_c_m']))==0
 assert s.simplify(cm-dd+1-ex(P['profile_finite_parts'][str(m)]['existing_E_d_matching_offset']))==0
 # Direct p-radius quadrature on a NEW non-Gaussian test f=(1+2p²)exp(-s p²).
 es=s.Rational(3,5);sv=s.Rational(5,3);a=s.Integer(2)
 ee=mp.mpf(3)/5;ssv=mp.mpf(5)/3
 fun=lambda r:2*(1+2*r*r)*mp.exp(-ssv*r*r)*(-mp.expm1(-r*r/ee**2))**m/r if r else mp.mpf(0)
 value=mp.quad(fun,[0,ee,1,3,10,mp.inf])
 aa=[(-1)**j*s.binomial(m,j) for j in range(m+1)]
 expected=Ibeta.subs({beta:1/es**2,ss:sv})+a*sum(aa[j]/(sv+j/es**2) for j in range(m+1))
 ev=mp.mpf(str(s.N(expected,62)));error=abs(value-ev);assert error<mp.mpf('1e-48')
 radial_controls.append({'m':m,'test':'(1+2p2)exp(-5p2/3),epsilon3/5','value_16pi2':mp.nstr(value,50),'absolute_error':mp.nstr(error,8)})
 # All-test bound from h(0)=0 and 1-chi^m<=m exp(-r²/eps²).
 r=s.Symbol('r',positive=True);bound=s.integrate(s.exp(-r*r/eps**2),(r,0,s.oo))*m/(8*s.pi**2)
 assert s.simplify(bound-ex(P['profile_finite_parts'][str(m)]['zero_value_test_error_bound_times_gradient_sup']))==0
 for row in [x for packet in [P,Q] for x in packet['numerical_controls'] if x['m']==m]:
  exact=Ibeta.subs({beta:1/s.sympify(row['epsilon'])**2,ss:s.sympify(row['s'])})
  assert abs(mp.mpf(row['value_16pi2'])-mp.mpf(str(s.N(exact,60))))<mp.mpf('1e-42')
  assert mp.mpf(row['absolute_quad_error'])<mp.mpf('1e-45')
print('STAGE verifier_independent_beta_derivative_nonGaussian_radial_controls_and_all_Schwartz_bound',flush=True)

for row in P['relative_profile_responses']:
 k=row['k'];assert row['interaction_profile_power']==2*k and row['reference_profile_power']==k and row['interaction_heat_power']==4 and row['reference_heat_power']==2
 ck=ex(P['profile_finite_parts'][str(k)]['finite_IR_offset_c_m']);c2=ex(P['profile_finite_parts'][str(2*k)]['finite_IR_offset_c_m']);lam=s.expand(ck-c2)
 assert s.simplify(lam-ex(row['IR_delta_coefficient_16pi2']))==0 and lam!=0
 assert lognormal(ex(row['gaussian_difference_16pi2'])-s.log((ss+4*tt)/(ss+2*tt))-lam)==0
 assert s.simplify(ex(row['unmarked_heat_difference_16pi2'])-lam-s.log(2))==0
 assert s.limit(s.log((ss+4*tt)/(ss+2*tt)),tt,0,dir='+')==0
# Two-sided inverse is a DISTRIBUTIONAL identity;the delta is killed by p².
assert s.integrate(2*s.Symbol('r',positive=True)*s.exp(-ss*s.Symbol('r',positive=True)**2),(s.Symbol('r',positive=True),0,s.oo))==1/ss
flux=2*ss/(16*s.pi**2*ss);assert flux==ex(P['momentum_divergence_contact'])==1/(8*s.pi**2)
assert flux/4==ex(P['derivative_contraction_contact'])==1/(32*s.pi**2)
# Integration by parts on Gaussian f gives <E_d,f>-1/(32pi²) for sum p_i*(-d_i E_d/4).
Ed=(-s.EulerGamma-s.log(ss*nu**2)+dd-1)/(16*s.pi**2)
contract=Ed-s.Rational(1,2)*ss/(16*s.pi**2*ss);assert s.simplify(Ed-contract)==1/(32*s.pi**2)
assert s.diff(Ed-contract,dd)==0
assert not P['full_paired_action_source_zero_transfer_identity_or_constant_generator_domain_proved'] and not P['offflat_critical_products_full_measure_QAP_A5_E5_or_physical_scheme_adopted']
assert read(O/'primary_capture.json')['execution_state']=='FAILED' and read(O/'replay_v2_capture.json')['execution_state']=='FAILED'
assert read(O/'primary_v2_capture.json')['execution_state']=='COMPLETED' and read(O/'replay_v3_capture.json')['execution_state']=='COMPLETED'
receipt={'schema':'TRANSLATION_CRITICAL_IR_EXTENSION_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':P['scientific_disposition'],'input_sha256':vp['input_sha256'],
 'complete_GF_and643_source_and34_physical_term_census_verified':True,'only_ghost_reference_response_can_be_critical_under_actual_port_bound':True,
 'all2025_ghost_coefficients_graded_inverse_and_zero_complement_verified':True,'actual_57_coefficients_reused_not_remeasured_or_integrated':True,
 'independent_beta_derivative_and_nonGaussian_radial_verification':True,'radial_controls':radial_controls,'general_Schwartz_limit_and_explicit_error_bound_verified':True,
 'actual_interaction_vs_reference_profiles_and_heat_placement_retained':True,'relative_IR_delta_coefficients':[row['IR_delta_coefficient_16pi2'] for row in P['relative_profile_responses']],
 'existing_E_d_relative_matching_without_fixing_d':True,'unavoidable_derivative_contraction_contact_retained':True,
 'primary_v2_reused_after_replay_only_AST_schema_fix':True,'new_failed_native_workers':2,'new_failed_verifier_workers':0,
 'full_paired_action_source_or_constant_generator_identity_qualified':False,'full_measure_QAP_A5_E5_or_physical_scheme_adopted':False,
 'limits':vp['limits'],'shared_limits':P['shared_limits'],'limitations':P['limitations'],'elapsed_after_imports':time.perf_counter()-tick}
print('VALIDATION '+json.dumps(receipt,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
