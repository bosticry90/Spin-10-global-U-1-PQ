import sympy as s,json
ss,eps,nu=s.symbols('s epsilon nu',positive=True)
for m in [1,2,4]:
 aa=[(-1)**j*s.binomial(m,j) for j in range(m+1)]
 Sm=s.expand(s.expand_log(sum(aa[j]*s.log(j) for j in range(1,m+1)),force=True))
 G=-sum(aa[j]*s.log(ss+s.Rational(j,1)/eps**2) for j in range(m+1))
 err=s.expand(s.expand_log(-sum(aa[j]*s.log(1+ss*eps**2/j) for j in range(1,m+1)),force=True))
 residual=G-s.log(nu**2/eps**2)+s.log(ss*nu**2)+Sm-err
 simplified=s.simplify(residual);expanded=s.expand(s.expand_log(residual,force=True))
 print(json.dumps({'m':m,'simplified':str(simplified),'expanded':str(expanded),'numerical':str(s.N(residual.subs({ss:s.Rational(3,2),eps:s.Rational(1,4),nu:2}),40))}))
