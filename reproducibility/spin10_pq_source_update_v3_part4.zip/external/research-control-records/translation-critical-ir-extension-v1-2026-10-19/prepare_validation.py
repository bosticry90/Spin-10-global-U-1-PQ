from pathlib import Path
from hashlib import sha256
import json
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_translation_critical_ir_extension';C=Path(__file__).resolve().parent
digest=lambda p:sha256(p.read_bytes()).hexdigest()
for p in [C/'verify.py',C/'run_validation.py',Path(__file__)]:
 p.write_bytes(('\n'.join(q.rstrip() for q in p.read_text(encoding='utf-8').splitlines()).rstrip()+'\n').encode())
 with p.with_name(p.name+'.source.txt').open('xb') as f:f.write(p.read_bytes())
for nm in ['verify.py','run_validation.py']:
 with (O/(nm+'.source.txt')).open('xb') as f:f.write((C/nm).read_bytes())
prep=json.loads((O/'preparation_v3.json').read_bytes())
for raw,h in prep['input_sha256'].items():assert digest(Path(raw))==h,raw
paths=[p for p in O.rglob('*') if p.is_file()]+[C/'verify.py',C/'run_validation.py',Path(__file__)]
inputs=dict(prep['input_sha256']);inputs.update({str(p):digest(p) for p in paths})
vp={'schema':'TRANSLATION_CRITICAL_IR_EXTENSION_VALIDATION_PREPARATION_V1','input_sha256':inputs,'limits':prep['limits'],'controller_sha256':digest(C/'run_validation.py'),'scope':prep['scope']}
with (O/'validation_preparation.json').open('xb') as f:f.write(json.dumps(vp,sort_keys=True,indent=2).encode()+b'\n')
print('VERIFIER_FROZEN',len(inputs))
