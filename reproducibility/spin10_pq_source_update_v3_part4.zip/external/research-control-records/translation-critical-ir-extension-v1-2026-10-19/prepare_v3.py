from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_translation_critical_ir_extension';C=Path(__file__).resolve().parent;P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
base='ab13f917e551346e42079d45d7e1ca14e147167c'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==base
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R)
for p in [O/'extension_v3.py',O/'CORRECTION_V3.md',C/'prepare_v3.py',C/'run_v3.py']:
 p.write_bytes(('\n'.join(q.rstrip() for q in p.read_text(encoding='utf-8').splitlines()).rstrip()+'\n').encode())
 with p.with_name(p.name+'.source.txt').open('xb') as f:f.write(p.read_bytes())
with (O/'run_v3.py.source.txt').open('xb') as f:f.write((C/'run_v3.py').read_bytes())
inputs=[R/q for q in ['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V324.md','tools/portable_dh_v1/inputs.json.gz','tools/portable_dh_v1/exact_algebra.py']]
inputs += [O/'CORRECTION_V3.md',O/'RECORD.md',O/'DERIVATION.md',C/'prepare_v3.py',C/'run_v3.py',P/'A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md']
prior=C.parent/'general-first-order-transport-v1-2026-10-19'
inputs += [prior/n for n in ['post_commit.json','next_translation_zero_transfer_question.json']]
byrole={role:[str(O/'preparation_v3.json')] for role in ['primary','replay']};facts=[]
folder=P/'frozen_a10_e5_full_hessian';rc=folder/'validation_receipt.json';receipt=read(rc);assert receipt['status']=='PASS_BOUNDED_FULL_HESSIAN_FINITE_LOOP_VALIDATION_ONLY';inputs.append(rc)
for role in byrole:
 fp=folder/(role+'.json');assert receipt['new_sha256'][fp.relative_to(R).as_posix()]==digest(fp);inputs.append(fp);byrole[role].append(str(fp))
facts.append({'receipt':str(rc),'status':receipt['status']})
names=['canonical_so10_general_first_order_transport','canonical_so10_source_primitive_transport','canonical_so10_local_covariant_reference_witness','canonical_so10_shear_ir_response','canonical_so10_offflat_ir_divided_difference','canonical_so10_joint_ir_extension','canonical_so10_individual_ir_removal','canonical_so10_joint_born_ir_trace_domain']
for name in names:
 folder=R/'calculations'/name;rc=folder/'validation_receipt.json';receipt=read(rc);assert receipt['execution_state']=='COMPLETED';inputs.append(rc)
 for nm in ['RESULT.md','RECORD.md','DERIVATION.md','DERIVATION_V2.md','DIAGNOSTIC_V2_RECORD.md']:
  if (folder/nm).is_file():inputs.append(folder/nm)
 facts.append({'receipt':str(rc),'scientific_disposition':receipt['scientific_disposition']})
 if name in ['canonical_so10_general_first_order_transport','canonical_so10_source_primitive_transport','canonical_so10_local_covariant_reference_witness']:
  for role in byrole:
   fp=folder/(role+('_v3_result.json' if name=='canonical_so10_general_first_order_transport' else '_result.json'));assert receipt['input_sha256'][str(fp)]==digest(fp)
   inputs.append(fp);byrole[role].append(str(fp))
inputs += [O/nm for nm in ['preparation.json','extension.py','primary_capture.json']]
inputs += [C/nm for nm in ['log_comparison_diagnostic.py','log_diagnostic_preparation.json','log_comparison_diagnostic_capture.json']]
inputs += [O/nm for nm in ['preparation_v2.json','extension_v2.py','primary_v2_capture.json','primary_v2_result.json','replay_v2_capture.json','CORRECTION_V2.md']]
prep={'schema':'TRANSLATION_CRITICAL_IR_EXTENSION_PREPARATION_V1','base':base,'input_sha256':{str(p):digest(p) for p in sorted(set(inputs))},'source_sha256':digest(O/'extension_v3.py'),'controller_sha256':digest(C/'run_v3.py'),'read_json_by_role':byrole,'receipt_facts':facts,'limits':{'native_seconds_after_imports':120,'verifier_seconds_after_imports':180,'sampled_private_bytes':8*2**30,'package_bytes':8*2**20},'scope':'Actual flat critical translation response edge extension/profile matching and complete reference channel census;not full paired constant-generator identity,offflat products,measure/QAP/A5/E5 or physical scheme'}
with (O/'preparation_v3.json').open('xb') as f:f.write(json.dumps(prep,sort_keys=True,indent=2).encode()+b'\n')
print('FROZEN',len(prep['input_sha256']),prep['source_sha256'],flush=True)
