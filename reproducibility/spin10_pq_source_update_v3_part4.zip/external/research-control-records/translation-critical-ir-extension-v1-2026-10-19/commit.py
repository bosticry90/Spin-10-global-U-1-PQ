from pathlib import Path
from hashlib import sha256
import json,subprocess,os
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_translation_critical_ir_extension';C=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
base='ab13f917e551346e42079d45d7e1ca14e147167c'
assert git('rev-parse','HEAD').decode().strip()==base and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
query="@(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.ProcessId -ne "+str(os.getpid())+" -and ($_.CommandLine -like '*canonical_so10_translation_critical_ir_extension*' -or $_.CommandLine -like '*translation-critical-ir-extension-v1-2026-10-19*') } | Select-Object ProcessId,CommandLine) | ConvertTo-Json -Compress"
assert not subprocess.check_output(['pwsh','-NoProfile','-Command',query]).strip()
vp=read(O/'validation_preparation.json')
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h,raw
rc=O/'validation_receipt.json';receipt=read(rc)
assert digest(rc)=='8f1ce70845aafb0744b109fc0f412131bb124c9ee9b33c0da79c97bdafc6b611'
assert receipt['execution_state']=='COMPLETED' and receipt['complete_GF_and643_source_and34_physical_term_census_verified'] and receipt['all2025_ghost_coefficients_graded_inverse_and_zero_complement_verified'] and receipt['independent_beta_derivative_and_nonGaussian_radial_verification'] and receipt['general_Schwartz_limit_and_explicit_error_bound_verified'] and receipt['actual_interaction_vs_reference_profiles_and_heat_placement_retained'] and receipt['existing_E_d_relative_matching_without_fixing_d'] and receipt['unavoidable_derivative_contraction_contact_retained'] and not receipt['full_paired_action_source_or_constant_generator_identity_qualified']
assert not receipt['full_measure_QAP_A5_E5_or_physical_scheme_adopted']
assert receipt['new_failed_native_workers']==2 and receipt['new_failed_verifier_workers']==0
prior=C.parent/'general-first-order-transport-v1-2026-10-19/post_commit.json'
old=read(prior);assert old['HEAD']==base and old['clean'] and old['all_older_tracked_bytes_unchanged']
broad=C.parent/'ordered-shear-insertion-v1-2026-10-18/research_check_e4_capture.json'
assert digest(broad)=='40bbc2d078c522367be0956631b849f64cc3f908ecf6973c4cb4d81c895b7060'
b=read(broad);assert b['exit_code']==0 and b['fresh_replay']==False
events=[json.loads(line) for line in b['stdout_utf8'].splitlines()]
custody=next(e for e in events if e.get('step')=='historical_custody' and e['event']=='step_finished')
assert custody['exit_code']==2 and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in custody['stdout']
assert events[-1]['execution_state']=='COMPLETED'
paths=sorted(p.relative_to(R).as_posix() for p in O.rglob('*') if p.is_file())+['docs/RESEARCH_EXECUTION_HANDOFF_V325.md']
assert set(filter(None,git('ls-files','--others','--exclude-standard','-z').decode().split('\0')))==set(paths)
assert sum((R/p).stat().st_size for p in paths)<8*2**20
hashes={p:digest(R/p) for p in paths}
assert digest(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
with (C/'pre_commit.json').open('xb') as f:f.write(json.dumps({'base':base,'new_sha256':hashes,'receipt_sha256':digest(rc),'prior_post_commit_sha256':digest(prior),'broad_audit_reused_not_rerun':True},sort_keys=True,indent=2).encode()+b'\n')
subprocess.run(['git','-c','core.autocrlf=false','add','--',*paths],cwd=R,check=True)
assert not git('diff','--cached','--check')
assert set(filter(None,git('diff','--cached','--name-only','-z').decode().split('\0')))==set(paths)
for p,h in hashes.items():assert sha256(git('show',':'+p)).hexdigest()==h and digest(R/p)==h
cp=subprocess.run(['git','-c','core.autocrlf=false','commit','-m','Construct critical translation IR extension and profile matching'],cwd=R,capture_output=True)
with (C/'commit_capture.json').open('xb') as f:f.write(json.dumps({'exit_code':cp.returncode,'stdout':cp.stdout.decode(),'stderr':cp.stderr.decode()},sort_keys=True).encode()+b'\n')
print(cp.stdout.decode(),flush=True);print(cp.stderr.decode(),flush=True);assert cp.returncode==0
head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()==base
assert set(filter(None,git('diff-tree','--no-commit-id','--name-only','-r','-z','HEAD').decode().split('\0')))==set(paths)
for p,h in hashes.items():assert sha256(git('show','HEAD:'+p)).hexdigest()==h and digest(R/p)==h
assert not git('status','--porcelain')
assert not git('diff','--name-only',base,'HEAD','--',':(exclude)calculations/canonical_so10_translation_critical_ir_extension/**',':(exclude)docs/RESEARCH_EXECUTION_HANDOFF_V325.md')
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h
post={'schema':'TRANSLATION_CRITICAL_IR_EXTENSION_POST_COMMIT_V1','HEAD':head,'parent':base,'branch':'main','clean':True,'files':hashes,'receipt_sha256':digest(rc),'all_older_tracked_bytes_unchanged':True,'state_sha256':digest(R/'project_state.json'),'new_failed_native_workers':2,'new_failed_verifier_workers':0,'full_constant_generator_extension_qualified':False,'qualified_flat_critical_edge_and_profile_matching':True,'prior_post_commit_sha256':digest(prior),'prior_broad_audit_capture_sha256':digest(broad),'prior_broad_audit_reused_not_rerun':True,'historical_custody_exit':2,'unresolved_references':7,'commit_command_exit_code':0}
with (C/'post_commit.json').open('xb') as f:f.write(json.dumps(post,sort_keys=True,indent=2).encode()+b'\n')
print('COMMITTED_AND_BYTE_AUTHENTICATED',head,len(paths),sum((R/p).stat().st_size for p in paths),flush=True)
