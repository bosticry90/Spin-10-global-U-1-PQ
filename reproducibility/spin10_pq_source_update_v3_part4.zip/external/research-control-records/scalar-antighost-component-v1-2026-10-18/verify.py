"""Independent literal even variations and five-radical width polynomials."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from fractions import Fraction as F
from functools import lru_cache
import importlib.util,json,sys,time,threading,os
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_scalar_antighost_component';CONTROL=Path(__file__).resolve().parent
def load(n,p):
 sp=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u);return u
old=load('independent_prior_qualified_recipe',ROOT/'calculations/canonical_so10_ghost_mass_g4_integration/integration.py');m=old.m;q=old.q;s=m.s;v=load('independent_radical_rationals',CONTROL.parent/'ghost-mass-g4-pole-v1-2026-10-18/verify.py');read=v.read;digest=v.digest
PARAM={'g3_etaH0_xi2_scalar1':(3,0,2,1),'g4_etaH1_xi1_scalar1':(4,1,1,1),'g4_etaH0_xi2_scalar1':(4,0,2,1),'g4_etaH0_xi0_scalar2':(4,0,0,2)};ANTI=v.ANTI;SQ=v.SQ
def mask_to_consumer(mask):return sum(1<<m.ex.SQUARES.index(value) for bit,value in enumerate(SQ) if mask&(1<<bit))
def mask_from_consumer(mask):return sum(1<<SQ.index(value) for bit,value in enumerate(m.ex.SQUARES) if mask&(1<<bit))
def cadd(A,B):
 d=dict(A)
 for k,z in B:d[k]=d.get(k,F(0))+z
 return tuple((k,z) for k,z in sorted(d.items()) if z)
def cscale(A,n):return tuple((k,z*n) for k,z in A if z*n)
@lru_cache(maxsize=131072)
def cmul(A,B):
 d={}
 for(a,b,ma),x in A:
  for(c,e,mb),y in B:
   value=x*y
   for bit,prime in enumerate(SQ):
    if ma&mb&(1<<bit):value*=prime
   key=a+c,b+e,ma^mb;d[key]=d.get(key,F(0))+value
 return tuple((k,z) for k,z in sorted(d.items()) if z)
def put(P,k,z):
 if z:P[k]=cadd(P.get(k,()),z)
 if k in P and not P[k]:del P[k]
def consumer(z):return m.ex.Coefficient({(a,b,mask_to_consumer(mask)):v for(a,b,mask),v in z})
def from_consumer(z):return tuple(((a,b,mask_from_consumer(mask)),v) for(a,b,mask),v in sorted(z.cells.items(),key=lambda p:(p[0][0],p[0][1],mask_from_consumer(p[0][2]))))
def token(n):
 name,_,jets=n.partition('__');return name,tuple(map(int,jets))
def serialize(t):
 n,j=t;return n+('__'+''.join(map(str,j)) if j else '')
def parity(n):return m.par[m.index[n]]
def canonical(seq):
 odds=[(m.index[t[0]],t[1]) for t in seq if parity(t[0])]
 if len(odds)!=len(set(odds)):return (),0
 return tuple(sorted(seq,key=lambda t:(m.index[t[0]],t[1]))),(-1)**sum(a>b for i,a in enumerate(odds) for b in odds[i+1:])
def product(P,Q):
 out={}
 for(gp,a),x in P.items():
  for(gq,b),y in Q.items():
   key,sg=canonical(a+b)
   if sg:put(out,(gp+gq,key),cscale(cmul(x,y),sg))
 return out
def decoded_hash(P):
 h=sha256();h.update(b'[')
 for i,((gp,word),z) in enumerate(sorted(P.items(),key=lambda p:(p[0][0],tuple((m.index[n],j) for n,j in p[0][1])))):
  if i:h.update(b',')
  cells=[[[a,b,mask_to_consumer(mask)],str(value)] for(a,b,mask),value in sorted(z,key=lambda p:(p[0][0],p[0][1],mask_to_consumer(p[0][2])))];h.update(json.dumps([gp,[[n,list(j)] for n,j in word],cells],separators=(',',':'),ensure_ascii=True).encode())
 h.update(b']');return h.hexdigest()
@lru_cache(None)
def parse(text):
 z=s.sympify(text,locals={'g10':m.g,'xi':m.xi,'eta_H':m.etaH,'reference_width_M':m.xi,'reference_width_H':m.etaH});out={}
 for(gp,xp,hp),co in s.Poly(s.expand(z),m.g,m.xi,m.etaH).terms():
  if co:out[gp]=cadd(out.get(gp,()),tuple(((xp,hp,mask),value) for mask,value in v.number(str(co))))
 return tuple(sorted(out.items()))
def from_rows(rows):
 out={}
 for row in rows:
  word=tuple(token(n) for n in row['word']);key,sg=canonical(word);assert key==word and sg==1
  for gp,z in parse(row['coefficient']):put(out,(gp,key),z)
 return out
def result_rows(rows):
 out={}
 for row in rows:
  parsed=parse(row['coefficient']);assert len(parsed)==1 and parsed[0][0]==0;key,sg=canonical(tuple(token(n) for n in row['word']));assert sg==1;put(out,(row['g'],key),parsed[0][1])
 return out
@lru_cache(maxsize=8192)
def format_coeff(signature):
 expression=0
 for gp,cells in signature:
  for(xp,hp,mask),value in cells:expression+=m.g**gp*m.xi**xp*m.etaH**hp*v.sym(((mask,value),))
 return q.sumtext((str(s.expand(expression)),))
def delta_and_node(data):
 P={};parts=defaultdict(dict)
 for label,rows in data['canonical_parameter_tables'].items():
  gp,hp,xp,degree=PARAM[label]
  for word,cells in rows:
   key=tuple((n,()) for n in word);assert canonical(key)==(key,1);value=tuple(((xp,hp,mask),F(n,d)) for mask,n,d in cells);put(P,(gp,key),value)
 for(gp,key),value in P.items():parts[key][gp]=value
 node={key:format_coeff(tuple(sorted(values.items()))) for key,values in parts.items()};assert len(node)==719730
 return P,node
def ids_word(word):return tuple((m.index[n],j) for n,j in word)
def raw_rows_from_names(P):return [{'word':[serialize(t) for t in key],'coefficient':z} for key,z in sorted(P.items(),key=lambda p:ids_word(p[0]))]
def kind(n):return 'E' if n.startswith('zz_da') else'x' if n.startswith('x_') else'a' if n in ANTI else'C' if n.startswith('C') else'J' if m.index[n] in m.sources else'B' if n.startswith('B') else'A' if n.startswith('A') else'L' if n.startswith('L') or n.startswith('b') else'OTHER'
def degree(word):
 kinds=tuple(sorted(kind(n) for n,j in word));return len(kinds)-2 if kinds in [('C','E','x'),('C','E','x','x')] else 0
def decode_compact(d):
 assert d['schema']=='FINITE_EXACT_COMPONENT_INTERNED_CELLS_V1' and d['alphabet']==m.names and d['basis_squared']==list(m.ex.SQUARES);coefs=[];out={};used=set()
 for rows in d['coefficients']:
  assert rows and len({(a,b,mask) for a,b,mask,n,den in rows})==len(rows);coefs.append(tuple(((a,b,mask_from_consumer(mask)),F(n,den)) for a,b,mask,n,den in sorted(rows,key=lambda r:(r[0],r[1],mask_from_consumer(r[2])))))
 for gp,word,cid in d['monomials']:
  assert type(cid) is int and 0<=cid<len(coefs);assert all(type(n) is int and 0<=n<len(m.names) for n,j in word);key=tuple((m.names[n],tuple(j)) for n,j in word);assert canonical(key)==(key,1) and (gp,key) not in out;out[gp,key]=coefs[cid];used.add(cid)
 assert used==set(range(len(coefs))) and decoded_hash(out)==d['sha256_exact_cells'];return out
def fixture():
 assert mask_to_consumer(8)==16 and mask_to_consumer(16)==8 and mask_from_consumer(16)==8
 for a in range(32):
  x=(((0,0,a),F(1)),);assert from_consumer(consumer(x))==x
  for b in range(32):assert from_consumer(consumer(x)*consumer((((0,0,b),F(1)),)))==cmul(x,(((0,0,b),F(1)),))
 assert canonical((('ub12',()),('C0',()),('x_Phi_0',())))[1]==-1 and canonical((('C0',()),('C0',())))[1]==0
 return True

def delta_numeric(data):
 out={};cache={};count=0
 for label,rows in data['canonical_parameter_tables'].items():
  gp,hp,xp,d=PARAM[label]
  for names,cells in rows:
   key=tuple((n,()) for n in names);assert canonical(key)==(key,1)
   assert tuple(sorted(kind(n) for n,j in key))==tuple(sorted(['C','a']+['x']*d)) and all(not n.startswith('bar') for n in names)
   sig=xp,hp,tuple(tuple(c) for c in cells)
   if sig not in cache:cache[sig]=tuple(((xp,hp,mask),F(n,den)) for mask,n,den in cells)
   put(out,(gp,key),cache[sig]);count+=1
 assert count==730610 and len(out)==723722;return out

def strict_decode(packet):
 assert len(packet['alphabet'])==len(set(packet['alphabet']))
 for cc in packet['coefficients']:
  assert cc and cc==sorted(cc,key=lambda r:r[:3])
  for a,b,mask,n,den in cc:
   assert all(type(v) is int for v in [a,b,mask,n,den]) and a>=0 and b>=0 and 0<=mask<32 and n!=0 and den>0 and F(n,den).numerator==n and F(n,den).denominator==den
 for gp,word,cid in packet['monomials']:
  assert type(gp) is int and 0<=gp<=5 and word
  for n,j in word:assert isinstance(j,list) and all(type(mu) is int and 0<=mu<4 for mu in j) and j==sorted(j)
 return decode_compact(packet)

def explicit_ordinary(delta):
 out={}
 for(gp,word),z in delta.items():
  anti=[(p,n) for p,(n,j) in enumerate(word) if n in ANTI];assert len(anti)==1 and not any(j for n,j in word)
  pos,n=anti[0];assert n.startswith('ub') and 12<=int(n[2:])<45
  eps=f'zz_da{int(n[2:]):02}';left=(-1)**sum(parity(k) for k,j in word[:pos]);rest=word[:pos]+word[pos+1:];kw,sg=canonical(((eps,()),)+rest)
  assert sg*left==1 and degree(kw) in [1,2];put(out,(gp,kw),cscale(z,left*sg))
 return out

def source_literal(S,V):
 out={0:{},1:{}};routes=defaultdict(set);eligible=set();channels=set();pairs=0;allg=Counter();selected={}
 ordered=sorted(S,key=lambda k:(k[0],ids_word(k[1])))
 for idx,key in enumerate(ordered):
  gp,word=key;allg[gp]+=1;positions=[(p,n,j) for p,(n,j) in enumerate(word) if m.index[n] in m.sources];assert len(positions)==1 and 0<=gp<=4
  pos,J,jets=positions[0];assert not jets;rest=word[:pos]+word[pos+1:];sign=(-1)**(parity(J)*sum(parity(n) for n,j in word[:pos]))
  for(gv,kw),co in V.get(J,{}).items():
   seq=kw+rest;d=degree(seq);js=sum(len(j) for n,j in seq)
   if not d or js>2-d:continue
   assert 0<=gp+gv<=5;pairs+=1;eligible.add(idx);selected[key]=S[key];channels.add(J);routes[gp+gv,gv,d,js].add(idx)
   canon,sg=canonical(seq)
   if sg:put(out[gv],(gp+gv,canon),cscale(cmul(co,S[key]),sign*sg))
 census={'all_source_positions':len(S),'all_source_g_counts':[[g,c] for g,c in sorted(allg.items())],'source_sha256_exact_cells':decoded_hash(S),'all_source_positions_equal_actual_current_operand_via_accepted_A':True,'all_kernel_source_channels':len(V),'qualified_zero_source_kernel_complement':sorted(m.names[n] for n in m.sources if m.names[n] not in V),'all_kernel_rows':sum(map(len,V.values())),'all_kernel_parities_same_as_sources_even_D':True,'all_eligible_source_positions':len(eligible),'eligible_kernel_channels':len(channels),'raw_eligible_kernel_source_position_pairs':pairs,'selected_source_sha256_exact_cells':decoded_hash(selected),'source_rows_order':'sorted(g,canonical typed word) of actual current source polynomial','complete_routes':[{'total_g':gp,'kernel_g':gv,'scalar_degree':d,'jets':js,'source_indices':sorted(ids)} for(gp,gv,d,js),ids in sorted(routes.items())],'all_total_orders0_through5_tested':True,'no_source_jets_in_entire_actual_input_proved':True}
 return out,census

def typed_anchor_literal(P):
 for(gp,word),co in P.items():
  es=[(p,n,j) for p,(n,j) in enumerate(word) if kind(n)=='E'];assert len(es)==1 and not any(j for n,j in word)
  p,n,j=es[0];assert parity(n)==1;left=(-1)**sum(parity(k) for k,j in word[:p]);canon,sg=canonical(((n,()),)+word[:p]+word[p+1:]);assert canon==word and sg*left==1
 return True

def fixtures_extra():
 assert fixture();P={(3,(('C0',()),('x_Phi_0',()),('zz_da12',()))):(((2,0,8),F(1)),)}
 packet={'schema':'FINITE_EXACT_COMPONENT_INTERNED_CELLS_V1','alphabet':m.names,'basis_squared':list(m.ex.SQUARES),'coefficients':[[[2,0,16,1,1]]],'monomials':[[3,[[m.index[n],list(j)] for n,j in next(iter(P))[1]],0]],'sha256_exact_cells':decoded_hash(P)}
 assert strict_decode(packet)==P and typed_anchor_literal(P)
 for field in ['negative_field','negative_coef','bad_mask','negative_width','bad_denominator','duplicate_word']:
  q=json.loads(json.dumps(packet))
  if field=='negative_field':q['monomials'][0][1][0][0]=-1
  elif field=='negative_coef':q['monomials'][0][2]=-1
  elif field=='bad_mask':q['coefficients'][0][0][2]=32
  elif field=='negative_width':q['coefficients'][0][0][0]=-1
  elif field=='bad_denominator':q['coefficients'][0][0][4]=0
  else:q['monomials'].append(q['monomials'][0])
  try:strict_decode(q)
  except (AssertionError,ZeroDivisionError):pass
  else:raise AssertionError(('BAD_PACKET_ACCEPTED',field))
 return True

def main():
 tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start();prep=read(OUT/'validation_preparation.json');assert digest(Path(__file__))==prep['validator_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allowed={str(Path(p).resolve()) for p in prep['read_json']}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('INDEPENDENT_SCALAR_COMPONENT_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_JSON',str(p))
 sys.addaudithook(guard);m.setup()
 for i in range(45):n=f'zz_da{i:02}';m.index[n]=len(m.names);m.names.append(n);m.par.append(1);m.external.add(m.index[n])
 assert fixtures_extra();a=read(OUT/'primary_result.json');b=read(OUT/'replay_result.json')
 for k in a.keys()-{'route','stages','elapsed_after_imports'}:assert a[k]==b[k],k
 del b
 AOUT=ROOT/'calculations/canonical_so10_scalar_ghost_integration';ar=AOUT/'integration_validation_receipt_v3.json';assert digest(ar)==a['accepted_A_receipt_sha256']=='99c192cc7fa6cf22b638af35d787ccc50b8db399851fc5d645a33e355eccba44';accepted=read(ar)
 assert accepted['execution_state']=='COMPLETED' and accepted['component_phase_still_required'];ap=AOUT/'primary_integration_v3_result.json';assert accepted['input_sha256'][str(ap)]==digest(ap);A=read(ap);snap=A['dependent_source_and_scalar_snapshot'];assert A['updated_known_sha256']==a['current_known_functional_hash_authenticated_not_rebuilt'] and not strict_decode(snap['prior_complete_ordinary_scalar_projection']) and snap['prior_scalar_projection_positions']==0
 data=old.auth('canonical_so10_scalar_ghost_canonical','primary_result.json');delta=delta_numeric(data);del data
 assert decoded_hash(delta)==A['new_delta_sha256_exact_cells']==a['ordinary_input_sha256_exact_cells'];print('STAGE independent complete_numeric_delta_and_A_equivalence',flush=True)
 primitive=old.auth('canonical_so10_local_source_primitive','primary_v2_result.json');S=result_rows(primitive['normalized_source_image']);del primitive
 assert len(S)==146663 and decoded_hash(S)==snap['actual_source_sha256_exact_cells'];op=old.auth('canonical_so10_broken_antighost_operator','primary_v2_result.json','validation_v2_receipt.json');V={J:result_rows(rows) for J,rows in op['all33_kernel_maps'].items()};del op
 assert len(V)==479 and sum(map(len,V.values()))==2589
 for J,P in V.items():
  assert m.index[J] in m.sources
  for(gv,word),co in P.items():assert gv in [0,1] and sum(parity(n) for n,j in word)%2==parity(J) and sum(kind(n)=='E' for n,j in word)==1 and not any(m.index[n] in m.sources for n,j in word)
 print('STAGE independent all_source_coefficients_and_all2589_actual_kernel_rows',flush=True)
 O=explicit_ordinary(delta);del delta;assert len(O)==a['ordinary_component_positions'] and decoded_hash(O)==a['ordinary_component_sha256_exact_cells'];source,census=source_literal(S,V);del S,V
 assert census==a['complete_predecessor_census']
 for gv in [0,1]:assert len(source[gv])==a['source_component_by_kernel_g'][str(gv)]['positions'] and decoded_hash(source[gv])==a['source_component_by_kernel_g'][str(gv)]['sha256_exact_cells']
 expected=dict(O)
 for P in source.values():
  for k,z in P.items():put(expected,k,cscale(z,-1))
 assert typed_anchor_literal(expected);assert decoded_hash(expected)==a['raw_component_sha256_exact_cells'] and len(expected)==a['raw_component_positions']==a['anchored_component_positions']
 assert strict_decode(a['complete_component'])==expected and a['typed_Euler_anchor_hypotheses_checked_on_every_word'] and a['raw_equals_anchored_without_currents'] and all(not strict_decode(packet) for packet in a['four_explicit_currents'])
 per=[]
 for gp in range(6):
  for d in [1,2]:
   keys=[k for k in expected if k[0]==gp and degree(k[1])==d];per.append({'g':gp,'scalar_degree':d,'nonzero_positions':len(keys),'jet_positions':sum(any(j for n,j in k[1]) for k in keys)})
 assert per==a['whole_component_by_g_and_scalar_degree'];assert all(0<=gp<=5 and degree(word) in [1,2] for gp,word in expected)
 print('STAGE independent whole_scalar_component_and_all_zero_complements_and_currents',flush=True)
 # Actual controls, including honest zero-sector insensitivity.
 assert bool(O)==a['controls']['wrong_odd_prefix_flips_every_ordinary_coefficient']
 source_total=dict(source[0])
 for k,z in source[1].items():put(source_total,k,z)
 assert bool(source_total)==a['controls']['reverse_source_sign_changes_component'] and bool(source[0])==a['controls']['omit_source0_changes_component'] and bool(source[1])==a['controls']['omit_source1_changes_component']
 if expected:
  k=next(iter(expected));altered=dict(expected);altered[k]=cscale(altered[k],-1);assert altered!=expected
 assert not any(a['all_seven_quantum_flags_false'].values()) and not a['full_sourcefree_Slavnov_QAP_measure_IR_E5_A5']
 for role in ['primary','replay']:
  cap=read(OUT/(role+'_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified']
 result={'schema':'COMPLETE_SCALAR_ANTIGHOST_COMPONENT_INDEPENDENT_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':'COMPLETE_RETAINED_SCALAR_COMPONENT_QUALIFIED_INSERTION_UNMEASURED','input_sha256':prep['input_sha256'],'accepted_A_reused_without_full_functional_rebuild':True,'all730610_parameter_and723722_delta_positions_verified':True,'full146663_source_and2589_kernel_rows_verified':True,'all32_1024_radical_products_and_actual_widths_verified':True,'whole_predecessor_census_and_all_g0_to5_degree1_2_jet_domains_verified':True,'literal_left_field_source_derivatives_independently_agree':True,'complete_component_and_all_implicit_zero_coefficients_verified':True,'strict_interned_packet_indices_coefficients_and_roundtrip_verified':True,'four_currents_and_whole_typed_Euler_anchor_verified':True,'sensitive_negative_controls_and_insensitive_zero_sectors_reported':True,'complete_scalar_component_sha256_exact_cells':decoded_hash(expected),'complete_scalar_component_positions':len(expected),'scalar_component_disposition':a['scientific_disposition'],'whole_component_by_g_and_scalar_degree':per,'eligible_actual_source_positions':census['all_eligible_source_positions'],'source_kernel0_positions':len(source[0]),'source_kernel1_positions':len(source[1]),'native_worker_failures':0,'independent_worker_failures':0,'fresh_byte_identical_replay_pairs_claimed':0,'actual_insertion_contact_restoration_anomaly_conclusion':'UNMEASURED_UNQUALIFIED','sourcefree_Slavnov_QAP_E5_A5':'UNQUALIFIED','authority_and_all_physical_inputs_unchanged':True,'shared_limits':'Measured canonical delta,current source equality,actual kernel/action,finite UV and word premises,software definitions and AI author shared. Independent rational radical width arithmetic and literal left derivatives,not an independently measured insertion or quantum restoration','elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
