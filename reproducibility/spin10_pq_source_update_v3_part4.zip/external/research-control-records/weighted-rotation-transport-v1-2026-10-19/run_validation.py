from pathlib import Path
from hashlib import sha256
import json,os,subprocess,sys
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_weighted_rotation_transport';C=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
from audit_a10_e5_antighost_vector import resource,line_json
p=json.loads((O/'validation_preparation.json').read_bytes());assert sha256(Path(__file__).read_bytes()).hexdigest()==p['controller_sha256']
assert not(O/'validation_receipt.json').exists() and not(O/'validation_capture.json').exists()
query="@(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.ProcessId -ne "+str(os.getpid())+" -and ($_.CommandLine -like '*canonical_so10_weighted_rotation_transport*' -or $_.CommandLine -like '*weighted-rotation-transport-v1-2026-10-19*') } | Select-Object ProcessId,CommandLine) | ConvertTo-Json -Compress"
assert not subprocess.check_output(['pwsh','-NoProfile','-Command',query]).strip(),'LIVE_WORK_POLL_HANDLE'
cap=capture([sys.executable,'-B',str(C/'verify.py')]);raw=(json.dumps(cap,sort_keys=True,separators=(',',':'))+'\n').encode()
for dest in [O/'validation_capture.json',C/'validation_full_capture.json']:
 with dest.open('xb') as f:f.write(raw)
if cap['execution_state']!='COMPLETED':print(cap['stdout_and_stderr'],flush=True)
resource(cap);value=line_json(cap['stdout_and_stderr'],'RESULT ');assert 0<value['elapsed_after_imports']<180
for raw,h in p['input_sha256'].items():assert sha256(Path(raw).read_bytes()).hexdigest()==h,raw
with(O/'validation_receipt.json').open('xb') as f:f.write((json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode())
with(O/'verify.py').open('xb') as f:f.write((C/'verify.py').read_bytes())
print('QUALIFIED',value['scientific_disposition'],value['elapsed_after_imports'],flush=True)
