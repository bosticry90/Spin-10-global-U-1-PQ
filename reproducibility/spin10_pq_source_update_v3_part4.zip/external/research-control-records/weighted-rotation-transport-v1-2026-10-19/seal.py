from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_weighted_rotation_transport';C=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
base='2cef964c98b6a2c5355873a0c7dade39fccb7341'
assert git('rev-parse','HEAD').decode().strip()==base and git('branch','--show-current').decode().strip()=='main'
r=read(O/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and not r['authority_changed']
assert digest(O/'validation_receipt.json')=='e34f0db41ca39eab3ed59c282cc078dcf61ede98074b4dab6fab4c7d61240630'
for raw,h in r['input_sha256'].items():assert digest(Path(raw))==h,raw
assert not git('diff','--name-only').strip()
# Post-qualification reconciliation is navigation/review, not a new theorem.
# Bind its source records as well as all newly committed text.
review=[R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_DOMAIN_CONTRACT_V1.md',
 R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/A10_E5_RENORMALIZATION_POLICY_ANALYSIS_V1.md',
 R/'calculations/canonical_so10_basic_primitive_comparison/ACCEPTANCE_RECONCILIATION.md',
 R/'calculations/canonical_so10_physical_counterterm_span/RESULT.md',
 R/'calculations/canonical_so10_physical_counterterm_span/validation_receipt.json']
review_hashes={str(p):digest(p) for p in review}
assert read(review[-1])['execution_state']=='COMPLETED'
with(O/'seal.py.source.txt').open('xb') as f:f.write(Path(__file__).read_bytes())
files=sorted([p for p in O.iterdir() if p.is_file()]+[R/'docs/RESEARCH_EXECUTION_HANDOFF_V347.md'])
assert sum(p.stat().st_size for p in files)<8*1024**2
bindings={p.relative_to(R).as_posix():digest(p) for p in files}
with(C/'precommit_bindings.json').open('xb') as f:f.write((json.dumps(bindings,indent=2,sort_keys=True)+'\n').encode())
subprocess.run(['git','add','--',*bindings],cwd=R,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
staged=git('diff','--cached','--name-status').decode().splitlines()
assert all(v.startswith('A\t') for v in staged)
assert sorted(v.split('\t')[1] for v in staged)==sorted(bindings)
for name,h in bindings.items():assert sha256(git('show',':'+name)).hexdigest()==h,name
subprocess.run(['git','commit','-m','Classify weighted rotation normalizations and relative Slavnov transport'],cwd=R,check=True)
head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()==base
changed=git('diff','--name-status',base,head).decode().splitlines()
assert all(v.startswith('A\t') for v in changed)
assert sorted(v.split('\t')[1] for v in changed)==sorted(bindings)
assert not git('status','--porcelain').strip()
for name,h in bindings.items():assert digest(R/name)==h and sha256(git('show','HEAD:'+name)).hexdigest()==h,name
for raw,h in {**r['input_sha256'],**review_hashes}.items():assert digest(Path(raw))==h,raw
state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
audit=C.parent/'ordered-shear-insertion-v1-2026-10-18/research_check_e4_capture.json'
assert digest(audit)=='40bbc2d078c522367be0956631b849f64cc3f908ecf6973c4cb4d81c895b7060'
prior=C.parent/'quantum-normalization-filtration-v1-2026-10-19/post_commit.json'
out={'schema':'WEIGHTED_ROTATION_TRANSPORT_POST_COMMIT_V1','HEAD':head,'parent':base,'branch':'main','clean':True,
 'files':bindings,'post_qualification_acceptance_review_input_sha256':review_hashes,
 'receipt_sha256':digest(O/'validation_receipt.json'),'state_sha256':state,'seal_source_sha256':digest(Path(__file__)),
 'all_older_tracked_Git_blobs_unchanged':True,'all173_frozen_validation_inputs_unchanged':True,
 'known_polynomial_rotation_module_local_extension_distinction_and_relative_hbar2_Slavnov_transport_qualified':True,
 'baseline_two_loop_restoration_full_W5_QAP_A5_E5_or_physical_promotion':False,
 'failed_native_workers':0,'failed_verifier_workers':0,'prelaunch_read_only_navigation_errors':1,
 'historical_custody_exit':2,'unresolved_references':7,'prior_broad_audit_reused_not_rerun':True,
 'prior_broad_audit_capture_sha256':digest(audit),'prior_post_commit_sha256':digest(prior)}
with(C/'post_commit.json').open('xb') as f:f.write((json.dumps(out,indent=2,sort_keys=True)+'\n').encode())
print(json.dumps({'HEAD':head,'new_files':len(files),'new_bytes':sum(p.stat().st_size for p in files),
 'all173_frozen_inputs_unchanged':True,'older_Git_blobs_unchanged':True,'state_unchanged':True,'clean':True},sort_keys=True))
