from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_weighted_rotation_transport';C=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
base='2cef964c98b6a2c5355873a0c7dade39fccb7341'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==base
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R).strip()
assert not(O/'preparation.json').exists()
prev=R/'calculations/canonical_so10_quantum_normalization_filtration'
receipt=read(prev/'validation_receipt.json');assert receipt['execution_state']=='COMPLETED'
inputs=dict(receipt['input_sha256'])
for raw,h in inputs.items():assert digest(Path(raw))==h,raw
B=R/'calculations/canonical_so10_basic_rotation_torsion';old=read(B/'preparation_v2.json')
artifacts={role:{k:old['artifacts'][role][k] for k in ['physical','e2','regularity']} for role in ['primary','replay']}
for role in artifacts:
 artifacts[role]['rotation']={'path':str(B/(role+'_result.json'))}
 artifacts[role]['scalar']={'path':str(B/(role+'_scalar_v2_result.json'))}
 for v in artifacts[role].values():
  v['sha256']=digest(Path(v['path']));inputs[v['path']]=v['sha256']
files=[prev/'validation_receipt.json',prev/'DERIVATION.md',prev/'RESULT.md',prev/'NEXT_RESEARCH_QUESTION.md',
 R/'docs/RESEARCH_EXECUTION_HANDOFF_V346.md',
 R/'tools/portable_dh_v1/exact_algebra.py',R/'tools/portable_dh_v1/inputs.json.gz',
 C.parent/'quantum-normalization-filtration-v1-2026-10-19/post_commit.json']
for dirname,extra in [('canonical_so10_onesource_primitive_probe',['DERIVATION.md','RESULT.md','validation_receipt.json']),
 ('canonical_so10_sourcequadratic_primitive_probe',['DERIVATION.md','RESULT.md','validation_receipt.json']),
 ('canonical_so10_sourcefree_primitive_probe',['DERIVATION.md','RESULT.md','validation_receipt.json']),
 ('canonical_so10_actual_normalization_assembly',['DERIVATION.md','validation_receipt.json']),
 ('canonical_so10_polynomial_basic_lift',['DERIVATION.md','validation_receipt_v2.json'])]:
 files.extend(R/'calculations'/dirname/name for name in extra)
for p in files:inputs[str(p)]=digest(p)
for p in [O/'RECORD.md',O/'DERIVATION.md',O/'transport.py',C/'prepare.py',C/'run.py']:
 inputs[str(p)]=digest(p)
 with(O/(p.name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
 inputs[str(O/(p.name+'.source.txt'))]=digest(O/(p.name+'.source.txt'))
for raw,h in inputs.items():assert digest(Path(raw))==h,raw
p={'schema':'WEIGHTED_ROTATION_TRANSPORT_PREPARATION_V1','base_commit':base,'artifacts':artifacts,
 'input_sha256':inputs,'controller_sha256':digest(C/'run.py'),
 'scope':'Complete known polynomial rotation module; local quadratic completion and relative Slavnov/background transport, not baseline two-loop restoration or full geometric W5/QAP/A5',
 'native_seconds_after_imports':120,'independent_seconds_after_imports':180,
 'sampled_private_limit_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2,'package_limit_bytes':8*1024**2,
 'scientific_acceptance':'NOT_PERFORMED'}
with(O/'preparation.json').open('xb') as f:f.write((json.dumps(p,indent=2,sort_keys=True)+'\n').encode())
print('FROZEN',len(inputs),p['controller_sha256'])
