"""Independent WRT right-gradient/word implementation; common parser only."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import product, combinations_with_replacement
from functools import lru_cache
import json,gzip,sys,os,threading,time
import sympy as s
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_weighted_rotation_transport'
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import parse_coefficient
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
vp=read(O/'validation_preparation.json')
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h,raw
def readonly(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):
  raise PermissionError('WRT_VERIFY_READ_ONLY')
sys.addaudithook(readonly)
a=read(O/'primary_result.json');b=read(O/'replay_result.json');skip={'route','elapsed_after_imports'}
assert {k:v for k,v in a.items() if k not in skip}=={k:v for k,v in b.items() if k not in skip}
prep=read(O/'preparation.json')
for role in ['primary','replay']:
 c=read(O/(role+'_capture.json'));assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['post_run_observations_qualified']
 assert all(0<q['private_bytes']<=8*1024**3 for q in c['all_resource_samples'])
get=lambda n:read(Path(prep['artifacts']['replay'][n]['path']))
one=(((0,0,0),F(1)),)
def cadd(a,b):
 d=dict(a)
 for key,v in b:d[key]=d.get(key,F(0))+v
 return tuple((key,v) for key,v in sorted(d.items()) if v)
def cmul(a,b):
 d={}
 for(x,e,m),u in a:
  for(y,f,n),v in b:
   vv=u*v
   for bit,square in enumerate([2,3,5,7,-1]):
    if m&n&(1<<bit):vv*=square
   k=x+y,e+f,m^n;d[k]=d.get(k,F(0))+vv
 return tuple((key,v) for key,v in sorted(d.items()) if v)
def cscale(c,factor):return tuple((key,v*factor) for key,v in c if v*factor)
def put(out,key,co):
 val=cadd(out.get(key,()),co)
 if val:out[key]=val
 else:out.pop(key,None)
def add(*pp):
 out={}
 for p in pp:
  for key,co in p.items():put(out,key,co)
 return out
def scale(p,f):return {key:cscale(co,f) for key,co in p.items()} if f else {}

class Words:
 def __init__(self,names,par,Jof):self.names=names;self.par=par;self.idx={n:i for i,n in enumerate(names)};self.Jof=Jof;self.coords=sorted(set(Jof)|set(Jof.values()))
 def el(self,n,j=()):
  if isinstance(n,str):n=self.idx[n]
  return {(0,((n,j),)):one}
 @lru_cache(None)
 def order(self,w):
  sg=1
  for i,(n,j) in enumerate(w):
   if not self.par[n]:continue
   for m,k in w[i+1:]:
    if not self.par[m]:continue
    if (n,j)==(m,k):return (),0
    if (n,j)>(m,k):sg=-sg
  return tuple(sorted(w)),sg
 def mul(self,*pp):
  out={(0,()):one}
  for p in pp:
   nxt={}
   for(g,w),co in out.items():
    for(h,v),cv in p.items():
     word,sg=self.order(w+v)
     if sg:put(nxt,(g+h,word),cscale(cmul(co,cv),sg))
   out=nxt
  return out
 def D(self,p,mu):
  out={}
  for(g,w),co in p.items():
   for at,(n,j) in enumerate(w):
    word,sg=self.order(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
    if sg:put(out,(g,word),cscale(co,sg))
  return out
 def jet(self,p,j):
  for mu in j:p=self.D(p,mu)
  return p
 def rows(self,rows):
  out={}
  for row in rows:
   word=[]
   for tok in row['word']:
    n,_,suffix=tok.partition('__');word.append((self.idx[n],tuple(int(v) for v in suffix)))
   w,sg=self.order(tuple(word));assert sg==1 and tuple(word)==w
   for g,co in parse_coefficient(row['coefficient']):put(out,(g,w),co)
  return out
 def scalar(self,co):return self.rows([{'coefficient':str(co),'word':[]}])
 def sub(self,p,mp):
  out={}
  for(g,w),co in p.items():out=add(out,self.mul({(g,()):co},*(self.jet(mp.get(n,self.el(n)),j) for n,j in w)))
  return out
 def euler(self,p):
  out={n:{} for n in self.coords}
  for(g,w),co in p.items():
   parity=sum(self.par[n] for n,j in w)%2
   for at,(n,j) in enumerate(w):
    if n not in out:continue
    suffix=sum(self.par[m] for m,k in w[at+1:])
    # Right derivative converted to left; ordinary EL integrates jets by parts.
    sg=-1 if (self.par[n]*(suffix+parity+1)+len(j))%2 else 1
    term={(g,w[:at]+w[at+1:]):cscale(co,sg)}
    out[n]=add(out[n],self.jet(term,j))
  return out
 def ham(self,p,parity):
  el=self.euler(p)
  return {**{i:scale(el[J],1 if parity==0 else (1 if self.par[i] else -1)) for i,J in self.Jof.items()},
          **{J:scale(el[i],1 if parity==0 else (-1 if self.par[i] else 1)) for i,J in self.Jof.items()}}
 def act(self,p,flow,odd=0):
  out={}
  for(g,w),co in p.items():
   pref=0
   for at,(n,j) in enumerate(w):
    if flow.get(n):
     val=self.mul({(g,w[:at]):cscale(co,-1 if odd*pref%2 else 1)},self.jet(flow[n],j),{(0,w[at+1:]):one})
     out=add(out,val)
    pref+=self.par[n]
  return out
 def fp(self,p):
  rows=[[g,[[self.names[n],list(j)] for n,j in w],[[list(key),str(v)] for key,v in co]] for(g,w),co in sorted(p.items())]
  return sha256(json.dumps(rows,separators=(',',':'),ensure_ascii=True).encode()).hexdigest()
 def flowfp(self,flow):return sha256(json.dumps([[n,self.fp(flow[n])] for n in self.coords],separators=(',',':')).encode()).hexdigest()

print('STAGE verifier all_actual_generator_and_quadratic_coordinate_hashes',flush=True)
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry']
Jof={i:J for i,J,h,k in geo['field_source_h_k']};W=Words(geo['names'],geo['parities'],Jof)
mat=lambda p:s.MutableSparseMatrix(*p['shape'],{(i,j):s.sympify(v) for i,j,v in p['entries']})
physical=get('physical');Q=mat(physical['C3_plane_to_parent']);Qi=Q.inv();Ks=[mat(p) for p in get('rotation')['full_skew_basis']]
reg=get('regularity');e2=get('e2')
nm={W.idx[n]:W.rows(v) for n,v in reg['nonminimal']['point_maps'].items()}
U={W.idx[n]:add(W.el(n),W.rows(v)) for n,v in e2['source_shifts'].items()}
Ui={W.idx[n]:add(W.el(n),scale(W.rows(v),-1)) for n,v in e2['source_shifts'].items()}
C=lambda p:W.sub(W.sub(p,nm),U);Ci=lambda p:W.sub(W.sub(p,Ui),nm)
flows=[]
for i,K in enumerate(Ks):
 kr=(Qi*K*Q).applyfunc(s.simplify);G={}
 for(r,c),v in kr.todok().items():
  co=W.scalar(v)
  G=add(G,W.mul(co,W.el(f'JC{r}'),W.el(f'C{c}')))
  for mu in range(4):G=add(G,scale(W.mul(co,W.el(f'JB{r}_{mu}'),W.el(f'B{c}_{mu}')),-1))
 canon=C(G);assert Ci(canon)==G and W.sub(G,nm)==G
 flow=W.ham(canon,1);assert len(flow)==1286
 row=a['four_actual_canonical_generators'][i]
 assert len(canon)==row['canonical_positions'] and W.fp(canon)==row['canonical_generator_sha256']
 assert W.flowfp(flow)==row['all1286_flow_sha256']
 assert row['omitting_U_changes_generator'] and not row['omitting_N_changes_generator']
 flows.append(flow)
for row in a['ten_all_coordinate_quadratic_coefficients']:
 i,j=row['i'],row['j'];out={n:W.act(flows[j][n],flows[i]) for n in W.coords}
 if i!=j:out={n:add(out[n],W.act(flows[i][n],flows[j])) for n in W.coords}
 assert W.flowfp(out)==row['all1286_quadratic_coefficient_sha256']
assert sum(bool(v['physical_program']) for v in e2['complete_columns'].values())==508

print('STAGE verifier independent_graded_classical_and_relative_quantum_signs',flush=True)
names=[f'{p}{i}' for p in ['B','x','C','JB','Jx','JC'] for i in range(3)]
idx={n:i for i,n in enumerate(names)};Jof={idx[f'{p}{i}']:idx[f'J{p}{i}'] for p in ['B','x','C'] for i in range(3)}
T=Words(names,[0]*6+[1]*9+[0]*3,Jof)
def gpower(p,n):return {(g+n,w):co for(g,w),co in p.items()}
S=add(*(scale(T.mul(T.el(f'{p}{i}'),T.el(f'{p}{i}')),F(1,2)) for p in ['B','x'] for i in range(3)))
for i,j,k in product(range(3),repeat=3):
 if len({i,j,k})!=3:continue
 # Orientation independently from inversion parity, not LeviCivita library.
 inv=sum(x>y for at,x in enumerate([i,j,k]) for y in [i,j,k][at+1:]);f=-1 if inv%2 else 1
 for p in ['B','x']:S=add(S,scale(gpower(T.mul(T.el(f'J{p}{i}'),T.el(f'{p}{j}'),T.el(f'C{k}')),1),f))
 S=add(S,scale(gpower(T.mul(T.el(f'JC{i}'),T.el(f'C{j}'),T.el(f'C{k}')),1),F(-f,2)))
G=add(scale(T.mul(T.el('JB0'),T.el('B1')),-1),T.mul(T.el('JB1'),T.el('B0')),
 T.mul(T.el('JC0'),T.el('C1')),scale(T.mul(T.el('JC1'),T.el('C0')),-1))
q=T.ham(S,0);V=T.ham(G,1);Qact=lambda p:T.act(p,q,1)
assert not Qact(S)
D=Qact(G);E=scale(T.act(T.act(S,V),V),F(1,2));DD=scale(T.act(D,T.ham(D,0),1),F(1,2))
assert D and E and DD and not add(Qact(E),DD) and add(Qact(scale(E,-1)),DD)
Floop=Qact(T.mul(T.el('Jx0'),T.el('B1')));I=T.mul(T.el('JC0'),T.el('C2'))
A=add(scale(T.act(Floop,V),-1),Qact(I));FD=T.act(D,T.ham(Floop,0),1)
assert FD and A and not add(Qact(A),FD) and not Qact(D)
assert not add(Qact(scale(T.act(Floop,V),-1)),FD)
for key,p in [('D',D),('E',E),('A',A),('square',DD)]:assert T.fp(p)==a['graded_control'][key+'_sha256']
assert a['graded_control']['omitted_exact_QI_part_insensitive_to_Slavnov_residual_disclosed']

print('STAGE verifier polynomial_necessity_sufficiency_and_relative_order_review',flush=True)
g,xi,eta=s.symbols('g xi eta');examples=[s.sympify(p) for p in a['polynomial_divisibility_examples']]
for p,out in zip(examples,a['positive_shift_results']):
 coef=s.Poly(p,g).terms();assert all(m[0]>0 for m,c in coef if c!=0)
 assert s.expand(g*s.sympify(out)-p)==0
model=get('scalar');M=mat(model['scalar_positive_Gram']);aa=s.symbols('a0:4',real=True)
form=(s.Matrix(aa).T*M*s.Matrix(aa))[0]
squares=(1224*aa[0]**2+1464*(aa[1]**2+aa[2]**2)+168*(aa[1]-aa[2])**2+168*aa[3]**2)/25
assert s.expand(form-squares)==0 and all(M[:i,:i].det()>0 for i in range(1,5))
assert all(s.trace(K)==0 and K+K.T==s.zeros(45) for K in Ks)
# Proof is coefficientwise for ALL real parameter values, not these examples.
# QNF normalization-degree locality is inherited before the g0 projection.
qnf=read(R/'calculations/canonical_so10_quantum_normalization_filtration/validation_receipt.json')
assert qnf['only_normalization_quadratic_sector_local_not_unrestricted_Gamma2']
assert qnf['only_zero_affine_four_direction_family_passes_necessary_extension']
osp=read(R/'calculations/canonical_so10_onesource_primitive_probe/validation_receipt.json')
assert osp['execution_state']=='COMPLETED'
assert not a['new_quantum_amplitude_or_authority_changed']
assert digest(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<8*1024**2
out={'schema':'WEIGHTED_ROTATION_TRANSPORT_INDEPENDENT_V1','execution_state':'COMPLETED',
 'scientific_disposition':'QUALIFIED_COMPLETE_KNOWN_POLYNOMIAL_ROTATION_MODULE_DISTINCTION_LOCAL_COMPLETION_AND_RELATIVE_HBAR2_SLAVNOV_TRANSPORT_WITH_EXPLICIT_QUANTUM_LIMITS',
 'input_sha256':vp['input_sha256'],'both_native_cores_agree':True,
 'four_actual_generator_and_all1286_first_flow_hashes_independently_checked':True,
 'all10_quadratic_parameter_coefficients_all1286_coordinate_hashes_independently_checked':True,
 'source_left_toy_D_E_A_and_square_complete_polynomials_independently_reconstructed':True,
 'polynomial_divisibility_and_positive_Gram_necessity_sufficiency_reviewed':True,
 'full_physical_action_and_all508_Euler_programs_twice_varied_as_bound_program_not_freshly_expanded':True,
 'actual_common_first_probe_used_not_arbitrary_loop_contact_chosen':True,
 'relative_hbar2_Slavnov_background_transport_only_not_baseline_two_loop_restoration':True,
 'full_geometric_W5_multiple_products_QAP_A5_or_global_equivalence_not_proved':True,
 'N_omission_and_QI_omission_insensitivity_disclosed':True,
 'shared_coefficient_parser_but_independent_graded_word_arithmetic':True,
 'authority_changed':False,'E5_A5_HB1_C5_or_physical_promotion':False,
 'failed_native_workers':0,'failed_verifier_workers':0,'prelaunch_read_only_navigation_errors':1,
 'elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
