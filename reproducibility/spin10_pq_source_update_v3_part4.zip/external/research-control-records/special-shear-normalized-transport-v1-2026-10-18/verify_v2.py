"""Independent action Eulers, graded commutator and whole-product verification."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import defaultdict
import gzip,importlib.util,json,os,sys,time,threading
import sympy as s
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_special_shear_normalized_transport';C=Path(__file__).resolve().parent
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sp=importlib.util.spec_from_file_location('old_exact_coefficients',R/'calculations/canonical_so10_connected_contact_lift/lift_v2.py')
u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u)
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
vp=read(O/'validation_preparation_v2.json')
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h,raw
def guard(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('SHEAR_VERIFIER_WRITE')
sys.addaudithook(guard)
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()))
A=u.Algebra(data['geometry']['names'],data['geometry']['parities']);pairs=data['geometry']['field_source_h_k']
fields={n for n,J,h,k in pairs};sources={J for n,J,h,k in pairs};coords=fields|sources
Jof={n:J for n,J,h,k in pairs};fieldof={J:n for n,J,h,k in pairs}
def merge(a,b):
 for key,z in b.items():u.put(a,key,z)
def add(*seq):
 out={}
 for f in seq:merge(out,f)
 return out
neg=lambda f:u.scale(f,-1);mul=A.product;elem=lambda n:{(0,((n,()),)):u.ONE}
def unpack(rows):
 out={}
 for row in rows:u.put(out,(row['g'],tuple(A.token(n) for n in row['word'])),tuple(((x,e,m),F(a,b)) for x,e,m,a,b in row['coefficient_cells']))
 return out
def total(f,mu):
 out={}
 for(g,w),co in f.items():
  for i,(n,j) in enumerate(w):
   ww,sg=A.canonical(w[:i]+((n,tuple(sorted((*j,mu)))),)+w[i+1:])
   if sg:u.put(out,(g,ww),u.scale_coefficient(co,sg))
 return out
def jets(f,j):
 for mu in j:f=total(f,mu)
 return f
def partials(f):
 out=defaultdict(dict)
 for(g,w),co in f.items():
  prefix=0
  for i,(n,j) in enumerate(w):
   u.put(out[n,j],(g,w[:i]+w[i+1:]),u.scale_coefficient(co,(-1)**(A.parities[n]*prefix)))
   prefix+=A.parities[n]
 return out
def deriv(f,m):
 out={}
 for(n,j),df in partials(f).items():
  if m.get(n):merge(out,mul(jets(m[n],j),df))
 return out
def euler(f,selected):
 out={n:{} for n in selected}
 for(n,j),df in partials(f).items():
  if n in selected:merge(out[n],u.scale(jets(df,j),(-1)**len(j)))
 return out
old=read(R/'calculations/canonical_so10_correlated_contact_lift/replay_result.json')
K=unpack(old['complete_K']);Ka=unpack(old['actual_20_Kaux']);kg=partials(K)
XF={n:u.scale(kg.get((J,()),{}),-(-1)**A.parities[n]) for n,J,h,k in pairs}
XS={J:u.scale(kg.get((n,()),{}),(-1)**A.parities[n]) for n,J,h,k in pairs}
X={**XF,**XS}
Rf={A.index[n]:A.rows(rows) for n,rows in data['master_field_maps'].items()}
source={}
for n,J,h,k in pairs:merge(source,mul(elem(J),Rf[n]))
Ssmall=add(A.rows(data['gauge_fixing_density']),source)
selected={n for n,f in XF.items() if f}|{A.index[f'ub{i}'] for i in range(12,45)}
EL=euler(Ssmall,selected)
E2=read(P/'frozen_a10_e2_transport/replay.json')
for n,f in EL.items():assert f==A.rows(E2['complete_columns'][A.names[Jof[n]]]['source_polynomial'])
q=dict(Rf);q.update({Jof[n]:f for n,f in EL.items()})
Cfull=deriv(K,q);assert Cfull==unpack(old['complete_C_QK'])
D={A.index[f'ub{i}']:elem(A.index[f'zz_da{i:02}']) for i in range(12,45)}
D.update({A.index[n]:neg(A.rows(rows,True)) for n,rows in data['all33_kernel_maps'].items()})
comm={}
for n in coords:
 comm[n]=add(deriv(X.get(n,{}),D),neg(deriv(D.get(n,{}),X)))
assert all(n in selected for n in fields if comm[n])
commS={};Pe={};Fwhole={}
for n in fields:
 if comm[n]:merge(commS,mul(comm[n],EL[n]))
 if XF[n]:merge(Fwhole,mul(XF[n],EL[n]))
for J in sources:
 if comm[J]:merge(commS,mul(comm[J],Rf[fieldof[J]]))
 if XS[J]:merge(Pe,mul(XS[J],Rf[fieldof[J]]))
assert not add(Cfull,Pe,Fwhole)
B=deriv(Ssmall,D);Be={}
for n in fields:
 if D.get(n):merge(Be,mul(D[n],EL[n]))
for J in sources:
 if D.get(J):merge(Be,mul(D[J],Rf[fieldof[J]]))
# Recursive integration by parts, rather than the native closed current sum.
currents=[{} for _ in range(4)]
for(n,j),df in partials(Ssmall).items():
 if n not in fields or not D.get(n):continue
 remainder=j;co=df
 while remainder:
  mu,*rest=remainder;remainder=tuple(rest)
  merge(currents[mu],mul(jets(D[n],remainder),co))
  co=neg(total(co,mu))
div=add(*(total(f,mu) for mu,f in enumerate(currents)))
assert add(B,neg(Be))==div
Xcurr=[deriv(f,X) for f in currents];divX=add(*(total(f,mu) for mu,f in enumerate(Xcurr)))
DC=deriv(Cfull,D);XB=deriv(B,X)
assert add(DC,commS,XB)==divX and DC and commS
assert not add(DC,commS,XB) and not any(Xcurr)
print('STAGE independent_full_coordinate_commutator_and_action_current',flush=True)
hmap={n:elem(h) for n,J,h,k in pairs};kmap={n:elem(k) for n,J,h,k in pairs}
dh=lambda f:deriv(f,hmap);dk=lambda f:deriv(f,kmap);H=lambda f:dk(dh(f))
pieces=[{}, {}, {}, {}]
for n,x in XF.items():
 if not x:continue
 E=EL[n]
 for j,f in enumerate([mul(x,H(E)),mul(dh(x),dk(E)),mul(dk(x),dh(E)),mul(H(x),E)]):merge(pieces[j],f)
HC,HP,HF=H(Cfull),H(Pe),H(Fwhole)
assert not add(HC,HP,HF) and HF==add(*pieces) and pieces[3]
# A product of means loses these cross-Hessian terms even if both means exist.
factorized={};cross={}
for J,Y in XS.items():
 if not Y:continue
 RfJ=Rf[fieldof[J]]
 merge(factorized,add(mul(Y,H(RfJ)),mul(H(Y),RfJ)))
 merge(cross,add(mul(dh(Y),dk(RfJ)),mul(dk(Y),dh(RfJ))))
assert cross and HP==add(factorized,cross) and HP!=factorized
a=read(O/'primary_result.json');b=read(O/'replay_result.json')
for key in ['route','elapsed_after_imports']:a.pop(key);b.pop(key)
assert a==b
assert a['commutator_domain_columns']==1286
for n in coords:assert unpack(a['actual_complete_commutator'].get(A.names[n],[]))==comm[n]
for key,f in [('complete_D_C',DC),('complete_commutator_S',commS),('complete_X_B',XB),('Ward_density_remainder',divX)]:assert unpack(a[key])==f
for key,seq in [('antighost_IBP_currents',currents),('X_antighost_IBP_currents',Xcurr)]:
 assert len(a[key])==4
 for rows,f in zip(a[key],seq):assert unpack(rows)==f
for key,f in [('C',HC),('P',HP),('F',HF)]:assert a['Hessians_fully_computed'][key]=={'positions':len(f),'sha256':A.fingerprint(f)}
assert a['F_Hessian_chain_positions']==[len(f) for f in pieces]
assert a['F_Hessian_nonlinear_corner_sha256']==A.fingerprint(pieces[3])
assert all(a['controls'].values())

bubble=read(R/'calculations/canonical_so10_auxiliary_insertion_source_bubble/replay_v2_result.json')
compat=read(R/'calculations/canonical_so10_auxiliary_primitive_contact_compatibility/replay_result.json')
Lnames=[A.index[('b' if i<12 else 'L')+str(i)] for i in range(45)]
scalarorder=[A.index[f'x_{sec}_{i}'] for sec,n in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(n)]
scalar=set(scalarorder);mean={}
for row in bubble['canonical_tensor']:
 E={key:co for key,co in EL.get(Lnames[row['rho_index']],{}).items() if all(n in scalar for n,j in key[1])}
 merge(mean,mul(E,mul(unpack(row['coefficient']),elem(scalarorder[row['scalar_index']]))))
assert mean and unpack(a['scalar_mean_contact'])==mean and add(mean,unpack(compat['local_Slavnov_contact_polynomial']))=={}
for name,f in [('Kaux',Ka),('QKaux',deriv(Ka,q)),('DminusKaux',deriv(Ka,D)),('Cfull',Cfull),('Pwhole',Pe),('B',B)]:
 assert unpack(a['b0_probe_X_images'][name])==deriv(f,X)
print('STAGE independent_Hessian_whole_product_cross_and_nonlinear_scalar_mean',flush=True)

# The same heat-to-hard map removes a nonzero contact of a ZERO unheated family.
# Recover actual frozen cohorts, not the new native recipe as an expected input.
fd=read(R/'calculations/canonical_so10_finite_shear_scalar/replay_v2_result.json')
g,xi=s.symbols('g10 xi',real=True)
unit=s.Rational(36,25)*s.sqrt(15)*xi**3
terms={2:unit*g**4*s.log(s.Rational(3,2)),3:unit*(g**4-g**5)*s.log(s.Rational(4,3))}
old_recipe=s.S.Zero
for row in fd['actual_finite_coefficient_log_recipe']:
 coefficient=sum(s.Rational(n,d)*s.sqrt(s.prod(prime for j,prime in enumerate([2,3,5,7]) if m&(1<<j))) for m,n,d in row['coefficient_cells'])
 old_recipe+=coefficient*g**row['g']*xi**row['xi']*s.log(s.Rational(*row['log_argument']))
native=s.sympify(a['finite_actual_heat_response'],locals={'g10':g,'xi':xi})
assert s.simplify(s.expand_log(sum(terms.values())-old_recipe,force=True))==0
assert s.simplify(s.expand_log(native-old_recipe,force=True))==0
assert s.simplify(s.sympify(a['finite_complete_subtraction'],locals={'g10':g,'xi':xi})+native)==0
assert old_recipe!=0 and s.expand(old_recipe).coeff(g,3)==0
z=s.Symbol('z',positive=True)
# d/da of the heat difference and its equal-scale normalization fix log(b/a).
aa,bb=s.symbols('a b',positive=True)
radial=s.integrate(s.exp(-aa*z),(z,0,s.oo))/2
assert radial==1/(2*aa)
assert s.diff(s.log(bb/aa)/2,aa)==-radial and s.log(bb/aa).subs(bb,aa)==0
# Track loop orders without erasing the unit-insertion correction.
h,b0,kap=s.symbols('hbar b0 kappa')
assert s.expand(h*b0*(h*old_recipe)).coeff(h,1)==0
assert s.expand(s.expand(h*b0*(h*old_recipe)).coeff(h,2)-b0*old_recipe)==0
assert s.diff(old_recipe,kap)==0 and b0!=kap
print('STAGE finite_heat_contact_and_loop_order_checks',flush=True)

scope_review={
 'local_b0_transport':'All1286 [Dminus,X] columns evaluated. The actual DC+commS+XB density vanishes; the explicit B current is annihilated by X. Pullback transports D,breaking,sources/probes; fixedD alone is not restoration.',
 'full_nonlinear_mean':'Complete F Hessian and all four chain contributions checked. T_kappa cyclicity applies only on fixed lifted domain; tangent differential traces zero. Nonlinear corner is retained and equals smooth E_iS times defined first-probe I_Xi.',
 'whole_source_product':'The actual P has nonzero cross-Hessian. The independent computation detects failure of replacing it by products of means. No source-number substitution inside a path integral.',
 'finite_regulator_response':'Existing whole-group adjacent inverse reduction,common heat finite part and individual IR proofs supply a zero UNHEATED lifted family. Its full local finite heat difference is subtracted by the same map. Actual nonzero g4log2-g5log4/3 coefficient remains recorded; zero leading log alone is insufficient.',
 'domain_extension':'Whole P,F are dim4gh0 smooth local densities with independent first probes. Old transfer-node IR bound and metric rank<=4 jet argument apply. E_iS is a smooth external mean coefficient substituted after a single probe derivative; no multiplication of two quantum distributions or diagonal pullback.',
 'normalization':'Same arbitrary real kappa; separate symbolic b0 at orderhbar. Unit-loop shear correction is orderhbar; with u=hbar*b0 its additional effect is orderhbar2. No baseline or physical scheme chosen.',
 'limits':'Selected formal one-loop shear/operator transport only. Not full simultaneous mixing or QAP,measure,quantumA5,E5,higher loops,physical constant-vacuum/adiabatic/causal/Lorentzian/global theorem.'}
result={'schema':'SPECIAL_SHEAR_NORMALIZED_TRANSPORT_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':a['scientific_disposition'],
 'input_sha256':vp['input_sha256'],'native_routes_equal':True,'independent_action_Eulers_and_all1286_commutator':True,
 'nonzero_commutator_fields':sum(bool(comm[n]) for n in fields),'nonzero_commutator_sources':sum(bool(comm[J]) for J in sources),
 'DC_positions':len(DC),'commutator_S_positions':len(commS),'XB_positions':len(XB),
 'explicit_B_currents_positions':[len(f) for f in currents],'X_B_currents_positions':[len(f) for f in Xcurr],
 'whole_source_Hessian_cross_positions':len(cross),'nonlinear_scalar_mean_contact_positions':len(mean),
 'constructed_selected_normalized_one_loop_shear_and_b0_operator_transport':True,
 'full_QAP_measure_A5_E5_physical_equivalence_or_scheme_adopted':False,
 'scope_review':scope_review,'new_failed_native_workers':0,'new_failed_verifier_workers':1,
 'failure_classification':'V1 symbolic fixture compared expanded and factored equivalent hbar2 coefficients structurally after complete action/Hessian checks',
 'shared_limits':'Actual physical action,reference/source charts,old analytic domains/heat identities,Python/SymPy/exact coefficients and AI author;no external or Lean validation',
 'authority':'state113/34of39,sevensfalse,custodyexit2/seven unchanged',
 'elapsed_after_imports':time.perf_counter()-tick}
print('VALIDATION '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
