from pathlib import Path
from hashlib import sha256
import json,subprocess,os
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_special_shear_normalized_transport';C=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
base='c29d987f0f230617fd731c2b9505c6e8c1f886fd'
assert git('rev-parse','HEAD').decode().strip()==base and git('branch','--show-current').decode().strip()=='main'
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
query="@(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.ProcessId -ne "+str(os.getpid())+" -and ($_.CommandLine -like '*canonical_so10_special_shear_normalized_transport*' -or $_.CommandLine -like '*special-shear-normalized-transport-v1-2026-10-18*') } | Select-Object ProcessId,CommandLine) | ConvertTo-Json -Compress"
assert not subprocess.check_output(['pwsh','-NoProfile','-Command',query]).strip()
vp=read(O/'validation_preparation_v2.json')
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h,raw
rc=O/'validation_v2_receipt.json';receipt=read(rc)
assert digest(rc)=='982cbc6d49039774724edb77611fbd0fc7497d3d68886d5e770125a2e5da6bd4'
assert receipt['execution_state']=='COMPLETED' and receipt['constructed_selected_normalized_one_loop_shear_and_b0_operator_transport']
assert not receipt['full_QAP_measure_A5_E5_physical_equivalence_or_scheme_adopted']
assert receipt['new_failed_native_workers']==0 and receipt['new_failed_verifier_workers']==1
prior=C.parent/'auxiliary-probe-renormalization-v1-2026-10-18/post_commit.json'
old=read(prior);assert old['HEAD']==base and old['clean'] and old['all_older_tracked_bytes_unchanged']
broad=C.parent/'ordered-shear-insertion-v1-2026-10-18/research_check_e4_capture.json'
assert digest(broad)=='40bbc2d078c522367be0956631b849f64cc3f908ecf6973c4cb4d81c895b7060'
b=read(broad);assert b['exit_code']==0 and b['fresh_replay']==False
events=[json.loads(line) for line in b['stdout_utf8'].splitlines()]
custody=next(e for e in events if e.get('step')=='historical_custody' and e['event']=='step_finished')
assert custody['exit_code']==2 and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in custody['stdout']
assert events[-1]['execution_state']=='COMPLETED'
paths=sorted(p.relative_to(R).as_posix() for p in O.rglob('*') if p.is_file())+['docs/RESEARCH_EXECUTION_HANDOFF_V314.md']
assert set(filter(None,git('ls-files','--others','--exclude-standard','-z').decode().split('\0')))==set(paths)
assert sum((R/p).stat().st_size for p in paths)<5*2**20
hashes={p:digest(R/p) for p in paths}
assert digest(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
with (C/'pre_commit.json').open('xb') as f:f.write(json.dumps({'base':base,'new_sha256':hashes,'receipt_sha256':digest(rc),'prior_post_commit_sha256':digest(prior),'broad_audit_reused_not_rerun':True},sort_keys=True,indent=2).encode()+b'\n')
subprocess.run(['git','-c','core.autocrlf=false','add','--',*paths],cwd=R,check=True)
assert not git('diff','--cached','--check')
assert set(filter(None,git('diff','--cached','--name-only','-z').decode().split('\0')))==set(paths)
for p,h in hashes.items():assert sha256(git('show',':'+p)).hexdigest()==h and digest(R/p)==h
cp=subprocess.run(['git','-c','core.autocrlf=false','commit','-m','Construct normalized special shear and Ward transport'],cwd=R,capture_output=True)
with (C/'commit_capture.json').open('xb') as f:f.write(json.dumps({'exit_code':cp.returncode,'stdout':cp.stdout.decode(),'stderr':cp.stderr.decode()},sort_keys=True).encode()+b'\n')
print(cp.stdout.decode(),flush=True);print(cp.stderr.decode(),flush=True);assert cp.returncode==0
head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()==base
assert set(filter(None,git('diff-tree','--no-commit-id','--name-only','-r','-z','HEAD').decode().split('\0')))==set(paths)
for p,h in hashes.items():assert sha256(git('show','HEAD:'+p)).hexdigest()==h and digest(R/p)==h
assert not git('status','--porcelain')
assert not git('diff','--name-only',base,'HEAD','--',':(exclude)calculations/canonical_so10_special_shear_normalized_transport/**',':(exclude)docs/RESEARCH_EXECUTION_HANDOFF_V314.md')
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h
post={'schema':'SPECIAL_SHEAR_NORMALIZED_TRANSPORT_POST_COMMIT_V1','HEAD':head,'parent':base,'branch':'main','clean':True,'files':hashes,'receipt_sha256':digest(rc),'all_older_tracked_bytes_unchanged':True,'state_sha256':digest(R/'project_state.json'),'new_failed_native_workers':0,'new_failed_verifier_workers':1,'prior_post_commit_sha256':digest(prior),'prior_broad_audit_capture_sha256':digest(broad),'prior_broad_audit_reused_not_rerun':True,'historical_custody_exit':2,'unresolved_references':7,'commit_command_exit_code':0}
with (C/'post_commit.json').open('xb') as f:f.write(json.dumps(post,sort_keys=True,indent=2).encode()+b'\n')
print('COMMITTED_AND_BYTE_AUTHENTICATED',head,len(paths),sum((R/p).stat().st_size for p in paths),flush=True)
