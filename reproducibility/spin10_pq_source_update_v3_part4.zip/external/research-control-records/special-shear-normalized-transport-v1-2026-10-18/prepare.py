from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_special_shear_normalized_transport';C=Path(__file__).resolve().parent;P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
base='c29d987f0f230617fd731c2b9505c6e8c1f886fd'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==base
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R)
for p in [O/'transport.py',O/'RECORD.md',O/'DERIVATION.md',C/'prepare.py',C/'run.py']:
 p.write_bytes(('\n'.join(q.rstrip() for q in p.read_text(encoding='utf-8').splitlines()).rstrip()+'\n').encode())
 with p.with_name(p.name+'.source.txt').open('xb') as f:f.write(p.read_bytes())
with (O/'run.py.source.txt').open('xb') as f:f.write((C/'run.py').read_bytes())
inputs=[R/q for q in ['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md','docs/SOLO_REVIEW_POLICY_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V313.md','tools/portable_dh_v1/inputs.json.gz','calculations/canonical_so10_correlated_contact_lift/lift.py','calculations/canonical_so10_connected_contact_lift/lift_v2.py']]
inputs += [O/'RECORD.md',O/'DERIVATION.md',C/'prepare.py',C/'run.py',P/'A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md']
prior=C.parent/'auxiliary-probe-renormalization-v1-2026-10-18'
inputs += [prior/q for q in ['post_commit.json','next_special_shear_transport_question.json']]
byrole={role:[str(O/'preparation.json')] for role in ['primary','replay']};facts=[]
folder=P/'frozen_a10_e2_transport';binding=read(folder/'bindings.json');receipt=read(folder/'validation_receipt.json')
assert receipt['status']=='PASS_BOUNDED_E2_TRANSPORT_EVIDENCE_VALIDATION_ONLY'
inputs += [folder/'bindings.json',folder/'validation_receipt.json']
for role in byrole:
 fp=folder/(role+'.json');assert binding['byte_sha256'][fp.relative_to(R).as_posix()]==digest(fp)
 inputs.append(fp);byrole[role].append(str(fp))
facts.append({'receipt':str(folder/'validation_receipt.json'),'status':receipt['status']})
names=['canonical_so10_auxiliary_probe_renormalization','canonical_so10_dimensional_stokes_primitive','canonical_so10_joint_born_ir_trace_domain','canonical_so10_triangular_heat_transport','canonical_so10_individual_ir_removal','canonical_so10_ordered_shear_insertion','canonical_so10_ordered_shear_finite_part','canonical_so10_correlated_contact_lift','canonical_so10_relative_contact_transport','canonical_so10_auxiliary_insertion_source_bubble','canonical_so10_auxiliary_primitive_contact_compatibility','canonical_so10_finite_shear_scalar']
suffix={'canonical_so10_correlated_contact_lift':'_result.json','canonical_so10_relative_contact_transport':'_v2_result.json','canonical_so10_auxiliary_insertion_source_bubble':'_v2_result.json','canonical_so10_auxiliary_primitive_contact_compatibility':'_result.json','canonical_so10_finite_shear_scalar':'_v2_result.json'}
for name in names:
 folder=R/'calculations'/name;rc=folder/('validation_v2_receipt.json' if name.endswith('probe_renormalization') else 'validation_receipt.json');receipt=read(rc);assert receipt['execution_state']=='COMPLETED';inputs.append(rc)
 for nm in ['RESULT.md','RECORD.md','DERIVATION.md','DERIVATION_V2.md']:
  if (folder/nm).is_file():inputs.append(folder/nm)
 facts.append({'receipt':str(rc),'scientific_disposition':receipt['scientific_disposition']})
 if name in suffix:
  for role in byrole:
   fp=folder/(role+suffix[name]);assert receipt['input_sha256'][str(fp)]==digest(fp)
   inputs.append(fp);byrole[role].append(str(fp))
prep={'schema':'SPECIAL_SHEAR_NORMALIZED_TRANSPORT_PREPARATION_V1','base':base,'input_sha256':{str(p):digest(p) for p in sorted(set(inputs))},'source_sha256':digest(O/'transport.py'),'controller_sha256':digest(C/'run.py'),'read_json_by_role':byrole,'receipt_facts':facts,'limits':{'native_seconds_after_imports':120,'verifier_seconds_after_imports':180,'sampled_private_bytes':8*2**30,'package_bytes':5*2**20},'scope':'Actual complete marked D/X transport,nonlinear means and common finite heat subtraction;selected one-loop Euclidean identity,not full measure/QAP/A5/E5 or scheme adoption'}
with (O/'preparation.json').open('xb') as f:f.write(json.dumps(prep,sort_keys=True,indent=2).encode()+b'\n')
print('FROZEN',len(prep['input_sha256']),prep['source_sha256'],flush=True)
