from pathlib import Path
from hashlib import sha256
import json,os,subprocess,sys
R=Path(r'C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_special_shear_normalized_transport';C=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
from audit_a10_e5_antighost_vector import resource,line_json
prep=json.loads((O/'validation_preparation.json').read_bytes());assert sha256(Path(__file__).read_bytes()).hexdigest()==prep['controller_sha256']
assert all(not p.exists() for p in [O/'validation_capture.json',O/'validation_receipt.json',C/'validation_full_capture.json']),'EXISTING_OUTPUTS_DO_NOT_RESTART'
query="@(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.ProcessId -ne "+str(os.getpid())+" -and ($_.CommandLine -like '*canonical_so10_special_shear_normalized_transport*' -or $_.CommandLine -like '*special-shear-normalized-transport-v1-2026-10-18*') } | Select-Object ProcessId,CommandLine) | ConvertTo-Json -Compress"
assert not subprocess.check_output(['pwsh','-NoProfile','-Command',query]).strip(),'LIVE_WORK_POLL_HANDLE'
cap=capture([sys.executable,'-B',str(C/'verify.py')]);raw=json.dumps(cap,sort_keys=True,separators=(',',':')).encode()+b'\n'
for p in [O/'validation_capture.json',C/'validation_full_capture.json']:
 with p.open('xb') as f:f.write(raw)
if cap['execution_state']!='COMPLETED':print(cap['stdout_and_stderr'],flush=True)
resource(cap);result=line_json(cap['stdout_and_stderr'],'VALIDATION ');assert 0<result['elapsed_after_imports']<180
result['performance']={'verifier_seconds_after_imports':result['elapsed_after_imports'],'verifier_peak_sampled_private':max(x['private_bytes'] for x in cap['all_resource_samples'])}
for role in ['primary','replay']:
 native=json.loads((O/(role+'_capture.json')).read_bytes());nresult=line_json(native['stdout_and_stderr'],'RESULT ')
 result['performance'][role]={'seconds_after_imports':nresult['elapsed_after_imports'],'peak_sampled_private':max(x['private_bytes'] for x in native['all_resource_samples'])}
with (O/'validation_receipt.json').open('xb') as f:f.write(json.dumps(result,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('VALIDATED',result['scientific_disposition'],result['elapsed_after_imports'],sha256((O/'validation_receipt.json').read_bytes()).hexdigest(),flush=True)
