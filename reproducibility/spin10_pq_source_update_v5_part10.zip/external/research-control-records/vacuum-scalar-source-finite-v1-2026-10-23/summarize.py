from pathlib import Path
from hashlib import sha256
import json
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');HERE=ROOT/'calculations/canonical_so10_vacuum_scalar_source_finite'
read=lambda p:json.loads(p.read_bytes())
out={}
for role in ['primary','replay','verify','project_v2']:
 c=read(HERE/(role+'_capture.json'));rows=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rows)==1
 out[role]={'exit':c['exit_code'],'seconds':rows[0]['elapsed_after_imports'],'samples':len(c['all_resource_samples']),'max_sampled_private':max(x['private_bytes'] for x in c['all_resource_samples'])}
out['receipts']={n:sha256((HERE/n).read_bytes()).hexdigest() for n in ['validation_receipt.json','projection_receipt_v2.json']}
out['bindings']={n:len(read(HERE/n)['input_sha256']) for n in ['preparation.json','validation_preparation.json','preparation_v2.json']}
out['source_copies']=len(list(HERE.glob('*.source.txt')));out['packet_bytes_before_reports']=sum(x.stat().st_size for x in HERE.iterdir() if x.is_file())
print(json.dumps(out,sort_keys=True),flush=True)
