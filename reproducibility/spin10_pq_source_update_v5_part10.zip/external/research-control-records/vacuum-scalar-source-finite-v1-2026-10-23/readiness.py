from pathlib import Path
import subprocess,json,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');HERE=Path(__file__).resolve().parent
with (HERE/'readiness.jsonl').open('xb') as out,(HERE/'readiness_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_check.py'),'e4'],cwd=ROOT,stdout=out,stderr=err)
lines=[json.loads(x) for x in (HERE/'readiness.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
print(json.dumps({'native_exit':r.returncode,'events':len(lines),'event_keys':[list(x) for x in lines]},sort_keys=True),flush=True)
with (HERE/'readiness_native_exit.json').open('xb') as f:f.write((json.dumps({'native_exit':r.returncode,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
assert r.returncode==0
