from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');HERE=ROOT/'calculations/canonical_so10_vacuum_scalar_source_finite';CONTROL=Path(__file__).resolve().parent
BASE='8677971d6d498c8ed7c7002965757fed999a67c7';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
counts={}
for n in ['preparation.json','validation_preparation.json','preparation_v2.json']:
 d=read(HERE/n);counts[n]=len(d['input_sha256'])
 for p,h in d['input_sha256'].items():assert digest(Path(p))==h,p
assert counts=={'preparation.json':96,'validation_preparation.json':104,'preparation_v2.json':120}
copies=list(HERE.glob('*.source.txt'));assert len(copies)==12
for p in copies:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes()
receipts={'validation_receipt.json':'190e043eaa287538dae303565f0d73c8ee61b584bc4b775617957477ec31cc78','projection_receipt_v2.json':'e566caa6378112e589f94f38b3b873a2e0ed0503ba55ceb84a62c6864482ad14'}
for n,h in receipts.items():assert digest(HERE/n)==h
r=read(HERE/'validation_receipt.json');v=read(HERE/'projection_receipt_v2.json')
assert r['status']=='QUALIFIED_SELECTED_EXTRA_GF_VACUUM_SCALAR_SOURCE_RELATIVE_MEMBER' and r['full_coefficient_positions_compared']==73800
assert v['status']=='QUALIFIED_SELECTED_SOURCE_EULER_AND_GHOST_INSERTION_COEFFICIENT_BRIDGE' and v['full_coefficient_positions_compared']==138240
assert all(x['remainder_nonzero']==400 for x in v['compact_diagnostic'].values()) and not v['complete_cvh_restoration_qualified'] and not r['physical_scheme_adopted']
assert r['ownership']['already_in_C_bStokes'] and not r['ownership']['add_second_copy_to_C_joint']
for role in ['primary','replay','verify','project_v2']:
 c=read(HERE/(role+'_capture.json'));assert c==read(CONTROL/(role+'_full_capture.json'))
 assert c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3
 rows=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rows)==1 and rows[0]['elapsed_after_imports']<600
 if role in ['primary','replay']:
  b=(HERE/(role+'_tables.json.gz')).read_bytes();assert sha256(b).hexdigest()==rows[0]['packed_sha256'] and sha256(gzip.decompress(b)).hexdigest()==rows[0]['tables_sha256']
 else:assert rows[0]==read(HERE/('validation_receipt.json' if role=='verify' else 'projection_receipt_v2.json'))
for n,rec in [('selected_vacuum_scalar_source_member.json.gz',r),('source_Euler_comparison_v2.json.gz',v)]:
 b=(HERE/n).read_bytes();assert sha256(b).hexdigest()==rec['artifact_sha256'] and sha256(gzip.decompress(b)).hexdigest()==rec['artifact_raw_sha256']
for suffix in ['', '_v2']:
 c=read(HERE/('preparation'+suffix+'_capture.json'));assert c['native_exit']==0 and c==read(CONTROL/('preparation'+suffix+'_full_capture.json'))
assert not any((HERE/n).exists() for n in ['controller_failure.json','controller_failure_v2.json'])
assert read(CONTROL/'readiness_native_exit.json')['native_exit']==0
events=[json.loads(x) for x in (CONTROL/'readiness.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()];steps=[x for x in events if x['event']=='step_finished'];assert [x['exit_code'] for x in steps]==[0,0,0,0,0,2]
custody=next(x for x in steps if x['step']=='historical_custody');assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in custody['stdout'] and events[-1]['execution_state']=='COMPLETED'
refs={}
for uid,h in [('b1443272-efc3-4501-ada7-997710904d96','071b50af269558fa554b4e7b062efe68d80594a850c9a07567b8089623de2321'),('afc5c5d0-7218-40c3-972a-08495b09c26d','213dbc6f64c23a624277bc81059f1876057c809c33289e61321be5fca1f5c0ad')]:
 p=Path('C:/Users/psboy/.codex/attachments')/uid/'Pasted text.txt';assert digest(p)==h;refs[str(p)]=h
assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
old=(CONTROL/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==33572
files=sorted([p for p in HERE.iterdir() if p.is_file()]+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V576.md'])
for p in files:
 if p.suffix!='.gz':assert b'\r' not in p.read_bytes(),p
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':33572,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'source_copies':12,'binding_counts':counts,'receipt_sha256':receipts,'reference_intake_sha256':refs,'seal_source_sha256':digest(Path(__file__)),'readiness_steps':[0,0,0,0,0,2],'scientific_acceptance':'NOT_PERFORMED'});print('VSC1_BEFORE_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'raw_index_files':len(files),'scientific_acceptance':'NOT_PERFORMED'});print('VSC1_INDEX_SEALED',len(files),flush=True)
else:
 assert mode=='after';seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==33572+len(files) and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':33572,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'source_copies':12,'binding_counts':counts,'receipt_sha256':receipts,'precommit_and_index_custody_passed':True,'scientific_authority':'34/39_UNCHANGED','historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED','whole_investigation':'INCOMPLETE','failed_compact_source_diagnostics_preserved':True};save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
