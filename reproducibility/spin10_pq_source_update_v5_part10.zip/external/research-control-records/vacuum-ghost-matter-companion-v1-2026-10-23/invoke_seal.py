from pathlib import Path
import json,subprocess,sys
C=Path(__file__).resolve().parent;mode=sys.argv[1]
r=subprocess.run([sys.executable,'-B',str(C/'seal.py'),mode],cwd='C:/Users/psboy/Documents/ToE-Next',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8')
with (C/(mode+'_seal_full_capture.json')).open('xb') as f:f.write((json.dumps({'native_exit':r.returncode,'stdout_and_stderr':r.stdout},sort_keys=True)+'\n').encode())
print(r.stdout,flush=True);sys.exit(r.returncode)
