from pathlib import Path
p=Path('C:/Users/psboy/Documents/ToE-Next/calculations/canonical_so10_vacuum_ghost_matter_companion')
def save(n,s):
 b=s.encode();assert b'\r' not in b
 with (p/n).open('xb') as f:f.write(b)
old=(p/'control_v2.py').read_text()
auth="for p,h in read(HERE/'preparation_v2.json')['input_sha256'].items():assert digest(Path(p))==h,p"
prefix="t=begin('control_v2')\n"+auth
assert prefix in old
new="t=time.perf_counter(); timer=threading.Timer(600,lambda:os._exit(124));timer.daemon=True;timer.start()\n"+auth.replace('preparation_v2','preparation_v3')+"\nbegin('control_v3')"
save('control_v3.py',old.replace(prefix,new).replace("finish('control_v2'","finish('control_v3'"))
save('verify_v3.py',(p/'verify_v2.py').read_text().replace('_v2','_v3').replace('GVC1_V2_','GVC1_V3_'))
save('run_v3.py',(p/'run_v2.py').read_text().replace('_v2','_v3'))
