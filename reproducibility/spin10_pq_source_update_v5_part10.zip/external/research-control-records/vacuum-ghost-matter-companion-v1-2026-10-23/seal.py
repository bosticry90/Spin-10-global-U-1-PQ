from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');HERE=ROOT/'calculations/canonical_so10_vacuum_ghost_matter_companion';CONTROL=Path(__file__).resolve().parent
BASE='691d2884621035d2a8405b34ba73e99ff84b51c2';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
counts={}
for n in ['preparation.json','validation_preparation.json','preparation_v2.json','preparation_v3.json','validation_preparation_v3.json','preparation_v4.json','preparation_v5.json']:
 d=read(HERE/n);counts[n]=len(d['input_sha256'])
 for p,h in d['input_sha256'].items():assert digest(Path(p))==h,p
copies=list(HERE.glob('*.source.txt'));assert len(copies)==26
for p in copies:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes()
expected={'validation_receipt_v3.json':'e2f441006ef9709570e863f7801301cb3adb3cfc17b408f3ddbb2c494251f57f','interpretation_receipt_v4.json':'66933d1432e4779086909b42ead069c6872f62e8433ea6544300e8a89bdff6cb','phase_receipt_v5.json':'7ccf6e8c7f5534c138440a57881aea627bea441bc87b38cb553873583b9912d6'}
for n,h in expected.items():assert digest(HERE/n)==h
r=read(HERE/'validation_receipt_v3.json');assert r['status']=='QUALIFIED_COMPLETE_EXTRA_GF_VACUUM_DIMENSIONAL_cPP_CLASS' and not r['physical_scheme_adopted'] and not r['selected_Cv_c_h_projection_compatible'] and r['candidate_remainder_nonzero_positions']==85
assert r['full_coefficient_positions_compared']==138240 and r['nonlinear_antighost_loop_control_INSENSITIVE'] and r['nonlinear_antighost_operator_control_nonzero']==2272
i=read(HERE/'interpretation_receipt_v4.json');assert i['entire_cPP_tensor_proportional'] and i['a_required_by_hPP']=='1/2' and i['a_required_by_selected_extra_cPP']=='9/50' and i['coefficient_conflict']=='8/25' and not i['full_admissible_counterterm_space_excluded']
assert read(HERE/'phase_receipt_v5.json')['previous_positive_Schur_sign_corroborated']
receiptnames={'verify_v3':'validation_receipt_v3.json','interpret_v4':'interpretation_receipt_v4.json','phase_v5':'phase_receipt_v5.json'}
for role in ['primary','replay','verify','control_v2','control_v3','verify_v3','interpret_v4','phase_v5']:
 c=read(HERE/(role+'_capture.json'));assert c==read(CONTROL/(role+'_full_capture.json'))
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
 if role in ['verify','control_v2']:
  assert c['exit_code']==1
  if role=='control_v2':assert 'GVC1_PEER_DENIED' in c['stdout_and_stderr']
  continue
 assert c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
 rows=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rows)==1 and rows[0]['elapsed_after_imports']<600
 if role in receiptnames:assert rows[0]==read(HERE/receiptnames[role])
 else:
  blob=(HERE/(role+'_tables.json.gz')).read_bytes();assert sha256(blob).hexdigest()==rows[0]['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==rows[0]['tables_sha256']
blob=(HERE/'extra_GF_vacuum_companion_v3.json.gz').read_bytes();assert sha256(blob).hexdigest()==r['artifact_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['artifact_raw_sha256']
assert read(HERE/'controller_failure.json')['last_role']=='verify' and read(HERE/'controller_failure_v2.json')['last_role']=='control_v2'
assert not any((HERE/n).exists() for n in ['validation_receipt.json','validation_receipt_v2.json','control_v2_tables.json.gz','controller_failure_v3.json','controller_failure_v4.json','controller_failure_v5.json'])
for suffix in ['', '_v2','_v3','_v4','_v5']:
 assert read(HERE/('preparation'+suffix+'_capture.json'))['native_exit']==0
 assert read(HERE/('preparation'+suffix+'_capture.json'))==read(CONTROL/('preparation'+suffix+'_full_capture.json'))
RD=CONTROL.with_name('tangent-heat-ward-bridge-v1-2026-10-23');rd=read(RD/'readiness_native_exit.json');assert rd['native_exit']==0 and rd['step_exits']==[0,0,0,0,0,2] and rd['historical_custody']=='EXIT2_SEVEN_NOTPASS'
assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
old=(CONTROL/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==33486
files=sorted([p for p in HERE.iterdir() if p.is_file()]+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V575.md'])
for p in files:
 if p.suffix!='.gz':assert b'\r' not in p.read_bytes(),p
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':33486,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'source_copies':26,'binding_counts':counts,'receipt_sha256':expected,'seal_source_sha256':digest(Path(__file__)),'scientific_acceptance':'NOT_PERFORMED','negative_result_scope':'SINGLE_CANDIDATE_DIRECTION_ONLY'});print('GVC1_BEFORE_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'raw_index_files':len(files),'scientific_acceptance':'NOT_PERFORMED'});print('GVC1_INDEX_SEALED',len(files),flush=True)
else:
 assert mode=='after';seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==33486+len(files) and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':33486,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'source_copies':26,'binding_counts':counts,'receipt_sha256':expected,'precommit_and_index_custody_passed':True,'scientific_authority':'34/39_UNCHANGED','historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED','whole_investigation':'INCOMPLETE','negative_result_scope':'SINGLE_CANDIDATE_DIRECTION_ONLY','earlier_failures_preserved':True}
 save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
