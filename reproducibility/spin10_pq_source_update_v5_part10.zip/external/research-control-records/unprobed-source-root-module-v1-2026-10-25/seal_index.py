from pathlib import Path
from hashlib import sha256,sha1
import json,subprocess
R=Path.cwd();C=Path(__file__).resolve().parent
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
b=json.loads((C/'before_index_seal.json').read_bytes());assert git('rev-parse','HEAD').decode().strip()==b['base'];old={}
for rec in git('ls-tree','-rz','HEAD').split(b'\0'):
 if not rec:continue
 hdr,path=rec.split(b'\t',1);mode,kind,oid=hdr.split();assert kind==b'blob';old[path.decode()]=(mode.decode(),oid.decode())
idx={}
for rec in git('ls-files','--stage','-z').split(b'\0'):
 if not rec:continue
 hdr,path=rec.split(b'\t',1);mode,oid,stage=hdr.split();assert stage==b'0';idx[path.decode()]=(mode.decode(),oid.decode())
assert len(old)==37770 and all(idx.get(p)==v for p,v in old.items());new=set(idx)-set(old);assert new==set(b['new_files_sha256']);assert not git('diff','--name-only')and not git('ls-files','--others','--exclude-standard')
oids=[];records={}
for p in sorted(new):
 raw=(R/p).read_bytes();oid=sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert idx[p]==('100644',oid)and sha256(raw).hexdigest()==b['new_files_sha256'][p];oids.append(oid);records[p]={'git_blob':oid,'raw_sha256':sha256(raw).hexdigest(),'bytes':len(raw)}
proc=subprocess.run(['git','cat-file','--batch'],input=('\n'.join(oids)+'\n').encode(),capture_output=True,check=True);out=proc.stdout;at=0
for p in sorted(new):
 nl=out.index(b'\n',at);oid,kind,size=out[at:nl].split();size=int(size);raw=out[nl+1:nl+1+size];assert kind==b'blob'and oid.decode()==records[p]['git_blob']and raw==(R/p).read_bytes()and out[nl+1+size:nl+2+size]==b'\n';at=nl+2+size
assert at==len(out);check=subprocess.run(['git','diff','--cached','--check'],capture_output=True);assert check.returncode==0,check.stdout+check.stderr;assert sha256((R/'project_state.json').read_bytes()).hexdigest()==b['state_sha256']
z={'base':b['base'],'old_mode_and_blob_ids_preserved':len(old),'new_raw_byte_verified_files':len(new),'index_tree':git('write-tree').decode().strip(),'new_file_objects':records,'cached_diff_check_exit':check.returncode,'cached_diff_check_stdout':check.stdout.decode(),'cached_diff_check_stderr':check.stderr.decode(),'state_sha256':b['state_sha256'],'scientific_acceptance':'NOT_PERFORMED'}
with(C/'index_seal.json').open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
print(json.dumps({k:v for k,v in z.items()if k!='new_file_objects'},sort_keys=True))
