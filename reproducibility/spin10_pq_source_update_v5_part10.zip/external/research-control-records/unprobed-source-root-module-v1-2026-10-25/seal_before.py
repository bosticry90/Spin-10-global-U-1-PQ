from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path.cwd();O=R/'calculations/canonical_so10_unprobed_source_root_module';C=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
base='1988c60c21fea8fe46c2ed764c3c9537d084f3b1';assert git('rev-parse','HEAD').decode().strip()==base and git('branch','--show-current').decode().strip()=='main'
old=(C/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r','HEAD')and len(old.splitlines())==37770;assert not git('diff','--name-only','HEAD')and not git('diff','--cached','--name-only')
state=H(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';checks=0;seen={};copies=[];captures=[];peak=0
for p in O.glob('*preparation*.json'):
 for f,h in json.loads(p.read_bytes()).get('input_sha256',{}).items():assert H(Path(f))==h,(p,f);assert f not in seen or seen[f]==h;seen[f]=h;checks+=1
for p in O.glob('*.source.txt'):assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes();copies.append(p.name)
for p in O.glob('*capture.json'):
 z=json.loads(p.read_bytes());assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']and z['post_run_observations_qualified'];assert z['launch']['memory']['available_pagefile']>=350*1024**2;mx=max(v['private_bytes']for v in z['all_resource_samples']);peak=max(peak,mx);assert mx<=8*1024**3;captures.append({'name':p.name,'exit':z['exit_code'],'state':z['execution_state'],'largest_sample':mx})
assert len(captures)==18 and not list(O.glob('*failure*.json'));v=json.loads((O/'final_review_validation_receipt.json').read_bytes());assert v['all_preparation_bindings_checked']==1160 and v['actual_source_routes_vs_direct_G_D_and_replay_quantum_integration_pass']and v['protected_five_edge_counts_and_exact_witness_checked']==[0,12432]and not v['full_QAP_E5_A5_anomaly_or_physical_promotion']
e=json.loads((C/'e4_full_capture.json').read_bytes());ev=[json.loads(q)for q in e['stdout_and_stderr'].splitlines()];exits=[q['exit_code']for q in ev if q['event']=='step_finished'];assert e['native_exit']==0 and exits==[0,0,0,0,0,2]and ev[-1]['execution_state']=='COMPLETED'
files={p.relative_to(R).as_posix():H(p)for p in O.iterdir()if p.is_file()};hh=R/'docs/RESEARCH_EXECUTION_HANDOFF_V630.md';files[hh.relative_to(R).as_posix()]=H(hh);untracked={x.decode()for x in git('ls-files','--others','--exclude-standard','-z').split(b'\0')if x};assert untracked==set(files),(untracked-set(files),set(files)-untracked);size=sum(p.stat().st_size for p in O.iterdir()if p.is_file());assert size<32*1024**2
z={'base':base,'old_blobs_preserved':37770,'state_sha256':state,'old_tree_sha256':H(C/'old_git_tree.txt'),'binding_checks':checks,'unique_bindings':len(seen),'source_copies':copies,'native_captures':captures,'max_sampled_private':peak,'packet_bytes':size,'new_files_sha256':files,'E4_step_exits':exits,'custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED','goal':'ACTIVE_INCOMPLETE'}
with(C/'before_index_seal.json').open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
print(json.dumps({k:v for k,v in z.items()if k not in ['source_copies','native_captures','new_files_sha256']},sort_keys=True))
