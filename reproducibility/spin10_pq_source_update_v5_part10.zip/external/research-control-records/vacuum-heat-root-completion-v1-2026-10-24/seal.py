from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');H=ROOT/'calculations/canonical_so10_vacuum_heat_root_completion';C=Path(__file__).resolve().parent
BASE='4ef90c58da071496672431008db417af9c94ae6c';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (C/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
expected_counts={'preparation.json':87,'validation_preparation.json':95,'preparation_v2.json':111,'validation_preparation_v2.json':119,'preparation_v3.json':144,'preparation_v4.json':165,'validation_preparation_v4.json':170,'preparation_v5.json':193};counts={}
for n,expect in expected_counts.items():
 d=read(H/n);counts[n]=len(d['input_sha256']);assert counts[n]==expect
 for p,h in d['input_sha256'].items():assert digest(Path(p))==h,p
copies=list(H.glob('*.source.txt'));assert len(copies)==32
for p in copies:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes()
receipts={'validation_receipt.json':'96cd9465967805075220ef5550ddd68f34f4263345d0dfc8c28dcc031d78f741','word_receipt_v2.json':'ca31bee13933975b1fd15d0f5e33fac53e8fc37fa1f6ffb58dce2a0e422352fd','heat_receipt_v4.json':'82cd84dabad6bdf40158ec5ac6c106e58cbc4444fdf89080c6865d2eff55fd54','joint_receipt_v5.json':'ee2148aef85d938c88cca1f0dcfc7b822b67f8aae838a2d794d7c27b81622b0d'}
for n,h in receipts.items():assert digest(H/n)==h
s=read(H/'validation_receipt.json');w=read(H/'word_receipt_v2.json');r=read(H/'heat_receipt_v4.json');j=read(H/'joint_receipt_v5.json')
assert s['ordered_word_count']==12 and s['n_counts']=={'2':1,'3':9,'4':2}
assert w['numeric_witness_matrix_positions']==1536 and all(x['individual_word_nonzero'] and x['universal_free_polynomial_remainder']==0 for x in w['constant_root_pair_proofs'].values())
assert r['complete_selected_first_variation_identity'] and r['model_color_identity_positions']==91125 and r['model_color_identity_nonzero_remainder']==0
assert r['finite_comparison_coefficient_positions']==r['selected_counterterm_coefficient_positions']==138240 and r['inherited_h_identity_positions']==1007616
assert not r['full_renormalized_source_contact_QAP_E5A5_qualified'] and not j['new_zero_matter_h_and_full_source_extension_qualified'] and not j['physical_scheme_adopted']
assert j['old_four_selected_projections_preserved_by_grade_and_support'] and not j['proper_JxCv_added_twice'] and j['new_ghost_identity_positions']==138240
roles=['primary','replay','verify','free_words_v2','paired_words_v2','verify_words_v2','color_primary_v3','color_replay_v3','color_replay_v4','verify_color_v4','integrate_v5']
receipt_roles={'verify':'validation_receipt.json','verify_words_v2':'word_receipt_v2.json','verify_color_v4':'heat_receipt_v4.json','integrate_v5':'joint_receipt_v5.json'}
for role in roles:
 c=read(H/(role+'_capture.json'));assert c==read(C/(role+'_full_capture.json'))
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3
 if role=='color_replay_v3':
  assert c['exit_code']==1 and "KeyError: 'primitive_orbit_at_v'" in c['stdout_and_stderr'];continue
 assert c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
 rows=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rows)==1 and rows[0]['elapsed_after_imports']<600
 if role in receipt_roles:assert rows[0]==read(H/receipt_roles[role])
 else:
  b=(H/(role+'_tables.json.gz')).read_bytes();assert sha256(b).hexdigest()==rows[0]['packed_sha256'] and sha256(gzip.decompress(b)).hexdigest()==rows[0]['tables_sha256']
for n,rec in [('complete_ordered_root_support.json.gz',s),('universal_word_coefficients_v2.json.gz',w),('complete_selected_vacuum_heat_response_v4.json.gz',r),('selected_joint_vacuum_extension_v5.json.gz',j)]:
 b=(H/n).read_bytes();assert sha256(b).hexdigest()==rec['artifact_sha256'] and sha256(gzip.decompress(b)).hexdigest()==rec['artifact_raw_sha256']
for suffix in ['', '_v2','_v3','_v4','_v5']:
 c=read(H/('preparation'+suffix+'_capture.json'));assert c['native_exit']==0 and c==read(C/('preparation'+suffix+'_full_capture.json'))
assert read(H/'controller_failure_v3.json')['last_role']=='color_replay_v3'
assert not any((H/n).exists() for n in ['controller_failure.json','controller_failure_v2.json','controller_failure_v4.json','controller_failure_v5.json','heat_receipt_v3.json','complete_selected_vacuum_heat_response_v3.json.gz','color_replay_v3_tables.json.gz','validation_preparation_v3.json','verify_color_v3_capture.json'])
assert read(C/'readiness_native_exit.json')['native_exit']==0 and read(C/'readiness_native_exit.json')['step_exits']==[0,0,0,0,0,2]
events=[json.loads(x) for x in (C/'readiness.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()];steps=[x for x in events if x['event']=='step_finished'];assert [x['exit_code'] for x in steps]==[0,0,0,0,0,2]
assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in next(x for x in steps if x['step']=='historical_custody')['stdout'] and events[-1]['execution_state']=='COMPLETED'
assert sum(p.stat().st_size for p in H.iterdir() if p.is_file())<16*1024**2
old=(C/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==33660
files=sorted([p for p in H.iterdir() if p.is_file()]+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V578.md'])
for p in files:
 if p.suffix!='.gz':assert b'\r' not in p.read_bytes(),p
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':33660,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'source_copies':32,'binding_counts':counts,'receipt_sha256':receipts,'seal_source_sha256':digest(Path(__file__)),'readiness_sha256':{n:digest(C/n) for n in ['readiness.py','readiness.jsonl','readiness_stderr.txt','readiness_native_exit.json']},'scientific_acceptance':'NOT_PERFORMED','failed_V3_replay_preserved':True});print('VHR1_BEFORE_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(C/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'raw_index_files':len(files),'scientific_acceptance':'NOT_PERFORMED'});print('VHR1_INDEX_SEALED',len(files),flush=True)
else:
 assert mode=='after';seal=read(C/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==33660+len(files) and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 for n,h in seal['readiness_sha256'].items():assert digest(C/n)==h
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':33660,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'source_copies':32,'binding_counts':counts,'receipt_sha256':receipts,'precommit_and_index_custody_passed':True,'scientific_authority':'34/39_UNCHANGED','historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED','whole_investigation':'INCOMPLETE','failed_V3_replay_and_old_records_preserved':True};save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
