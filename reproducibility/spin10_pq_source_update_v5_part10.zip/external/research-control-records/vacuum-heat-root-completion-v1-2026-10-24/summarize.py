from pathlib import Path
from hashlib import sha256
import json
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');H=ROOT/'calculations/canonical_so10_vacuum_heat_root_completion';read=lambda p:json.loads(p.read_bytes());roles=['primary','replay','verify','free_words_v2','paired_words_v2','verify_words_v2','color_primary_v3','color_replay_v3','color_replay_v4','verify_color_v4','integrate_v5'];out={}
for role in roles:
 c=read(H/(role+'_capture.json'));r=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];out[role]={'exit':c['exit_code'],'seconds_after_imports':r[0]['elapsed_after_imports'] if r else None,'samples':len(c['all_resource_samples']),'max_sampled_private':max(x['private_bytes'] for x in c['all_resource_samples'])}
out['bindings']={p.name:len(read(p)['input_sha256']) for p in H.glob('*preparation*.json') if 'input_sha256' in read(p)};out['source_copies']=len(list(H.glob('*.source.txt')));out['packet_pre_reports']=sum(p.stat().st_size for p in H.iterdir() if p.is_file());out['receipts']={n:sha256((H/n).read_bytes()).hexdigest() for n in ['validation_receipt.json','word_receipt_v2.json','heat_receipt_v4.json','joint_receipt_v5.json']};print(json.dumps(out,sort_keys=True),flush=True)
