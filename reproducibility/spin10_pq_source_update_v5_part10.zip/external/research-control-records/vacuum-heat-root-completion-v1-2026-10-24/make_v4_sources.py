from pathlib import Path
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');H=ROOT/'calculations/canonical_so10_vacuum_heat_root_completion'
old=(H/'color_data_v3.py').read_text(encoding='utf-8');anchor='def scalar_review(role,U):';assert old.count(anchor)==1
new=old[:old.index(anchor)].replace("HERE/'preparation_v3.json'","HERE/'preparation_v4.json'").replace("+'_v3_tables.json.gz'","+'_v4_tables.json.gz'")
new+='''def scalar_review(role,U):
 assert role=='replay'
 p=read(PK/'frozen_a10_physical_reconciliation/full_replay.json');v=dec(p['vacuum']['VEV']);E=read(PK/'frozen_a10_e1_fermion/replay.json');g,xi=s.symbols('g10 xi');names=[f'x_{sec}_{i}' for sec,n in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(n)];si={n:i for i,n in enumerate(names)};Oraw=s.SparseMatrix(45,328,{})
 for row in E['polynomial_parts']['heavy_orbit']:
  w=row['word'];a=int(next(n for n in w if n.startswith('ub'))[2:]);j=si[next(n for n in w if n in si)];z=co(-s.sympify(row['coefficient'])/(g*xi));assert not z.free_symbols;Oraw[a,j]+=z
 assert len(E['polynomial_parts']['heavy_orbit'])==432
 O=U.T*Oraw;off=0;antisym_entries=0
 for sec,n in [('Phi',54),('Sigma',252),('phi',20),('S',2)]:
  for a,row in enumerate(p['representation_matrices'][sec]):
   m=dec(row);assert not (m+m.T).applyfunc(co).todok();delta=m*v[off:off+n,0]-O[a,off:off+n].T;assert not delta.applyfunc(co).todok();antisym_entries+=len(m.todok())
  off+=n
 H=dec(packed(CAL/'canonical_so10_yukawa_carrier_transport/replay_tables.json.gz')['H_new']);assert not (H.T*O).applyfunc(co).todok()
 return {'orbit_positions':45*328,'scalar_antisymmetry_full_positions':45*328**2,'scalar_sparse_entries':antisym_entries,'unbroken_projected_orbit_zero':True}
'''
def write(n,text):
 b=text.encode();assert b'\r' not in b;compile(b,str(H/n),'exec')
 with (H/n).open('xb') as f:f.write(b)
write('color_data_v4.py',new)
rep=(H/'color_replay_v3.py').read_text(encoding='utf-8');assert rep.count('from color_data_v3 import *')==1
write('color_replay_v4.py',rep.replace('from color_data_v3 import *','from color_data_v4 import *'))
ver=(H/'verify_color_v3.py').read_text(encoding='utf-8')
for a,b in [('from color_data_v3 import *','from color_data_v4 import *'),("HERE/'validation_preparation_v3.json'","HERE/'validation_preparation_v4.json'"),('color_replay_v3_tables.json.gz','color_replay_v4_tables.json.gz'),('complete_selected_vacuum_heat_response_v3.json.gz','complete_selected_vacuum_heat_response_v4.json.gz')]:
 assert a in ver,a;ver=ver.replace(a,b)
write('verify_color_v4.py',ver)
print('VHR1_V4_SOURCES_EXCLUSIVELY_CREATED_NO_OLD_WRITES',flush=True)
