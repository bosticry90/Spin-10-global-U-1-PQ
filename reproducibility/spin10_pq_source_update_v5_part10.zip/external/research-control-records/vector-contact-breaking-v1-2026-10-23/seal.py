"""VCT1 completed-native and immutable-byte seal."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');CONTROL=Path(__file__).resolve().parent;HERE=ROOT/'calculations/canonical_so10_vector_contact_breaking'
BASE='935b56492a31fc694917c527e8223fe9c5c727fc';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';NOLD=31739
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
old=(CONTROL/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==NOLD
r=read(HERE/'validation_receipt.json');receipt=digest(HERE/'validation_receipt.json');assert receipt=='0f87424162c1861203cd866280fe3e44ccf383e8ca2bf8f7b6ffc58324c3e358'
assert r['status']=='QUALIFIED_VECTOR_CONTACT_MATTER_BREAKING_FAMILY' and r['disposition']=='ACTION_DERIVED_CONTACT_COEFFICIENT_MEASURED'
assert r['profiles_measured']==2 and r['remaining_vector_profiles_unmeasured']==40 and r['coefficient_positions_compared']==1036800 and r['left_nonzero_positions']==r['right_nonzero_positions']==19648
assert r['I0']=='-1/2' and r['J']=='-1/12' and r['endpoint_phases']==['1','-1'] and r['canonical_raw_contact_coefficients']==3530 and r['all4_metric_components_equal']
assert r['Lie_coefficients_nonzero']==3120 and len(r['all12_H_coefficient_remainders'])==12 and not any(r['all12_H_coefficient_remainders'])
assert r['right_plus_left_transpose_remainder']==r['antiHermitian_left_remainder']==r['unit_width_diagnostic_remainder']==0
assert sum(v['profiles'] for v in r['complete_vector_partition'].values())==42 and len(r['complete_vector_partition'])==5
assert r['authority']=='34/39' and r['scientific_acceptance']=='NOT_PERFORMED'
assert not any(r[k] for k in ['extra_family_or_Nambu_half','quantum_coefficients_assigned_from_counterterm','whole_vector_family_or_full_restoration_QAP_measure_phase_massiveC1_E5A5_unification_qualified','physical_scheme_adopted','scientific_authority_changed'])
counts={};cache={}
for n in ['preparation.json','preparation_v2.json','validation_preparation_v2.json']:
 bd=read(HERE/n)['input_sha256'];counts[n]=len(bd)
 for p,h in bd.items():
  if p not in cache:cache[p]=digest(Path(p))
  assert cache[p]==h,p
assert counts=={'preparation.json':239,'preparation_v2.json':264,'validation_preparation_v2.json':272}
assert len(list(HERE.glob('*.source.txt')))==15
for p in HERE.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes() and b'\r' not in p.read_bytes()
for p in HERE.glob('*.py'):compile(p.read_bytes(),str(p),'exec')
for p in HERE.glob('*.md'):assert b'\r' not in p.read_bytes()
assert not (HERE/'controller_v2_failure.json').exists() and sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
resources={}
for name in ['primary','primary_v2','replay_v2','verify_v2']:
 p=HERE/(name+'_capture.json');c=read(p);assert p.read_bytes()==(CONTROL/(name+'_full_capture.json')).read_bytes()
 ss=c['all_resource_samples'];assert ss and c['launch']['creation_after_observation'] and c['launch']['memory']['available_pagefile']>=350*1024**2
 maximum=max(v['private_bytes'] for v in ss);assert maximum<=8*1024**3 and c['post_run_observations_qualified']
 out=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')]
 if name=='primary':assert c['execution_state']=='FAILED' and c['exit_code']==1 and not c['calculation_completed'] and not out
 else:
  assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and len(out)==1
  role=name[:-3];out=out[0];assert out['elapsed_after_imports']<600 and out==read(HERE/('validation_receipt.json' if role=='verify' else role+'_result.json'))
  if role!='verify':
   blob=(HERE/(role+'_tables.json.gz')).read_bytes();assert sha256(blob).hexdigest()==out['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==out['tables_sha256']
 resources[name]={'exit':c['exit_code'],'samples':len(ss),'sampled_private_maximum':maximum,'peak_memory_claimed':False}
failed=read(HERE/'controller_failure.json');assert failed['execution_state']=='FAILED' and failed['last_role']=='primary' and not failed['failure_relabelled_PASS']
assert not (HERE/'replay_capture.json').exists() and not (HERE/'verify_capture.json').exists()
for name in ['preparation','preparation_v2']:
 pc=read(HERE/(name+'_capture.json'));assert pc==read(CONTROL/(name+'_full_capture.json')) and pc['native_exit']==0 and not pc['scientific_calculations_executed']
diag=read(CONTROL/'raw_contact_diagnostic_output.json');dc=read(CONTROL/'raw_contact_diagnostic_capture.json');assert diag['all_metric_equal'] and diag['raw_nonreal_count']==956 and diag['canonical_positions_per_mu']==[3530]*4
assert dc['execution_state']=='COMPLETED' and dc['exit_code']==0 and dc['post_run_observations_qualified'] and dc['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes'] for v in dc['all_resource_samples'])<=8*1024**3
events=[json.loads(v) for v in (CONTROL/'readiness.jsonl').read_text(encoding='utf-8').splitlines()];steps=[v for v in events if v['event']=='step_finished']
assert [v['exit_code'] for v in steps]==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested'] and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
ready=read(CONTROL/'readiness_result.json');assert ready['native_exit']==0 and ready['readiness_command_executed_this_goal_turn'] and not ready['fresh_historical_science_requested'] and ready['custody']=='EXIT2_SEVEN_NOTPASS'
for name in ['prelaunch_preflight.json','v2_prelaunch_preflight.json']:
 pre=read(CONTROL/name);assert pre['git_HEAD']==BASE and pre['state_sha256']==STATE and pre['files_written']==0 and pre['scientific_acceptance']=='NOT_PERFORMED'
files=sorted(p for p in HERE.iterdir() if p.is_file())+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V531.md'];assert len(files)==47
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':NOLD,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'receipt_sha256':receipt,'state_sha256':STATE,'resources':resources,'manifest_counts':counts,'seal_source_sha256':digest(Path(__file__)),'scientific_acceptance':'NOT_PERFORMED'});print('PRECOMMIT_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'before_seal_sha256':digest(CONTROL/'before_commit_seal.json'),'raw_index_files':len(files)});print('RAW_INDEX_MATCH',len(files),flush=True)
else:
 assert mode=='after';seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==len(prior)+len(files) and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':NOLD,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'receipt_sha256':receipt,'state_sha256':STATE,'scientific_authority':'34/39_UNCHANGED','scientific_acceptance':'NOT_PERFORMED','contact_vector_profiles_measured':2,'remaining_vector_profiles':40,'original_raw_reality_failure_preserved':True,'full_restoration_claimed':False,'physical_scheme_adopted':False,'historical_custody':'EXIT2_SEVEN_NOTPASS','whole_investigation':'INCOMPLETE'}
 save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
