import sys
sys.path.insert(0,'C:/Users/psboy/Documents/ToE-Next/calculations/canonical_so10_vector_contact_breaking')
"""VCT1 literal contact Hessian, explicit Clifford and ordered color sewing."""
from data import *
from itertools import permutations
start=begin('primary');g=sy.Symbol('g10');raw=[defaultdict(lambda:Z) for _ in range(4)];nraw=Counter()
for row in packed(ROOT/'tools/portable_dh_v1/inputs.json.gz')['gauge_fixing_density']:
 w=row['word'];bb=[n for n in w if n.startswith('B')];aa=[n for n in w if n.startswith(('bar','ub'))];cc=[n for n in w if n.startswith('C')]
 if len(w)!=4 or len(bb)!=2 or len(aa)!=1 or len(cc)!=1:continue
 assert not any('__' in n for n in w)
 r,mu=map(int,bb[0][1:].split('_'));t,nu=map(int,bb[1][1:].split('_'));assert mu==nu
 a=int(aa[0][3:] if aa[0].startswith('bar') else aa[0][2:]);c=int(cc[0][1:]);sign=-1 if w.index(cc[0])<w.index(aa[0]) else 1
 z=sy.expand(sign*[1,-1,-1,-1][mu]*sy.sympify(row['coefficient'],locals={'g10':g,'eta_H':WH,'xi':WM})/g**2);assert not z.has(g)
 co=Q(str(z));key=(a,c,min(r,t),max(r,t));raw[mu][key]=add(raw[mu][key],co);nraw[mu]+=1
raw=[{k:v for k,v in d.items() if v} for d in raw]

nonreal=[[*k,textq(v),textq(sub(v,conj(v)))] for k,v in sorted(raw[0].items()) if v!=conj(v)]
metric=[{'mu':mu,'differences':[[*k,textq(sub(raw[mu].get(k,Z),raw[0].get(k,Z)))] for k in sorted(set(raw[mu])|set(raw[0])) if sub(raw[mu].get(k,Z),raw[0].get(k,Z))]} for mu in range(1,4)]
ctl=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/vector-contact-breaking-v1-2026-10-23')
d={'raw_positions_per_mu':dict(nraw),'canonical_positions_per_mu':list(map(len,raw)),'all_metric_equal':all(not x['differences'] for x in metric),'metric_differences':metric,'raw_nonreal_count':len(nonreal),'raw_nonreal':nonreal,'scientific_acceptance':'NOT_PERFORMED','diagnostic_only':True}
with (ctl/'raw_contact_diagnostic_output.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(d,f,sort_keys=True);f.write('\n')
print('DIAGNOSTIC '+json.dumps({k:d[k] for k in ['raw_positions_per_mu','canonical_positions_per_mu','all_metric_equal','raw_nonreal_count']},sort_keys=True),flush=True)
