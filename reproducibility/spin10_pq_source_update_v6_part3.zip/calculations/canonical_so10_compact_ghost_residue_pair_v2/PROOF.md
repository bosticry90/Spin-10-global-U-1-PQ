# A compact local residue pair and its source companion

## Parent change and the selected connected comparison

Work at first loop in V915's stripped normalization with real compact
switch sigma. Let E_s be the actual VEV orbit map in scalar block s,
G_s = E_s E_s^t, Y_s the ordered a,C coupling to the scalar x_s,
and L_s the V882 real reference logarithm. M_s is the strictly positive
squared reference mass. Keep both L_s as reference numbers at a fixed
choice of free propagators, with the common symbolic kappa. The factors
multiply polynomials in the dynamical couplings and parameters.
In particular the local terms below contain no inverse mass or gauge
coupling. Their dimensions are four, with [M_s]=2, [v_s]=[x_s]=1
and [G_s]=2 in the symmetric ghost mass counting. Restore the common
loop normalization and actual physical Wick reality as in V882/V915.

The qualified local V915 remainder is m sigma^2(1-sigma) in action
units, where m=sum_s L_s YY_s. Test the following local additions
to the first-loop compact action in the real physical chart:

    N_YY  = -g^4 xi^2 integral sigma^2 sum_s L_s a^t YY_s C
    N_kin = -g^2 xi integral sigma^2 sum_s M_s L_s (2 C_s-8) v_s^t x_s.

These use the two-vertex YY and Bxx–M one-port residue carriers.
V882 gives +2 M_s C_s L_s v_s in the latter, so the finite residue
changes relative to the original radial coefficient are -3 L_Phi/5
and -17 L_Sigma/25. The full ordered V275 pole tables give

    YY_s=(2 C_s-8)G_s,   DMM_s+FMY_s=8G_s,   Y_s[v_s]=-G_s.

Only the first and third identities are used for the kinetic repair.
The second separately verifies the relation to the three-vertex
proper alternative. No new integration is used.

At order hbar a local action change contributes N(phi_tree) to the
connected functional. In the selected sector the YY term evaluates
directly on the original exact exterior ghost roots. The scalar
one-port term sews to the ordinary switched Y vertex. The linear
response is the retained V882 -K_x(0)^(-1)=+1/M_s. It gives
+sigma^3 L_s YY_s as the leading effective a,C coefficient. At the
declared g^4 xi^2 grade, a competing tree would use the ordinary
gauge–ghost vertex and the scalar–auxiliary mixed interaction.
The one-port scalar source has zero overlap with every mixed
direction because E_s v_s=0 by skewness of the joined rho. The
block-diagonal switched scalar inverse preserves v_s. This kills
the competing branch before the gauge–ghost vertex. With physical
ordinary sources set to zero no scalar self-interaction is needed
for the quadratic tree derivative.

For finite nonconstant sigma the scalar term is a sewn distribution.
In the V908 dilated coordinates the input is the fixed smooth
compact source proportional to sigma^2 v_s. The large-mass
resolvent expansion there applies to this source with the same
fixed free M_s, replacing the full bridge by its constant inverse
plus O(R^(-2)) on each fixed compact C^k seminorm. Multiplying by
the Y switch leaves that error on fixed compact support. The V911
exterior estimate for arbitrary smooth compact families costs
O(1+log R), with the existing polynomial Schwartz tail control.
The paired error tends to zero. With the same V915 source sign
for all three terms the local leading profile coefficient is
therefore zero, color by color:

    m sigma^2(1-sigma) - m sigma^2 + m sigma^3 = 0.

This is a cancellation of the V915 profile difference for the
amended compact action, under the same selected causal pairing.
Each correction separately gives a different result. At collapsed
unit switch their contribution to the selected connected
zero-transfer coefficient is zero. The scalar one-port term by
itself still changes the scalar tadpole normalization there.

## The amended insertion

Write F_i=(-1)^p_i EL_Ji P, E_i=EL_zi P and B[P]=int sum_i F_i E_i
in the V900 signed chart. For P+hbar N, the compact insertion is
B[P]+hbar B'[P](N). The source-free N gives the complete expression

    B'[P](N) = integral sum_i F_i EL_zi N.

The derivative here acts on the local action, whose ghost term is
-sigma^2 m. It cannot be applied to the sewn effective coefficient
-sigma^2(1-sigma)m. In the V900 constant-jet projection the local
ghost term yields -i sigma^3 m in the Lambda,C row, with the common
couplings suppressed. The scalar term has no such row at this
grade because F_x is the scalar field-ghost flow. The latter
contributes separately at g^3 xi: in the signed physical chart
v_s^t F_x = g sigma sum_(c,x) E_c[x] x C_c.
It gives the scalar term of B'[P](N) with coefficient
-M_s L_s (2 C_s-8) sigma^3 after removing g^3 xi. Thus one needs
the new insertion. The old fixed-insertion determinant sigma^2
and exclusion remain valid.

For the additive first-loop parent change, the marked argument
P+rho K+hbar N yields the additional ordered marked derivative
B''[P](K,N) in the insertion. It is the variation of the same
signed Euler product. Evaluating the original quantum one-loop
part on the new parent would affect it at second loop. The new
first-loop contributions to the compact master identity are
therefore the derivatives of its tree identity, retaining the
connected tree root variations. This argument is about an action
deformation on the compact chart. The unmarked N is H-covariant:
v_s is fixed and G_s is an intertwiner. Its field/source support
contains neither the affine B_H translation nor a source slot.
This leaves the unmarked classical fixed-background and modified
geometric insertion variations of N zero on this chart. It does
not establish a common quantum prescription for arbitrary sources.

## Why two independent numerical changes do not define a common product map

A scalar–ghost local T2 residue with the same field-independent
contracted-species kernel must also act when one vertex is the
actual retained source J_x g rho_k x C_k. The overall sign is
fixed by the chosen ordering and source convention. With that
common sign and coupling stripped, the source row of the same
kernel is

    S_s[x,c] = sum_(k,y) (rho_k)[x,y] Y_s[y,k,c].

The native and replay checks reconstruct rho v = E before contracting.
They use the joined V787 coefficients because the archived plane
representations need a gauge basis change. The result is (4-C_s)E_c[x],
with nonzero values in both blocks. This also follows from
sum_k rho_k rho_c rho_k=(4-C_s)rho_c. With the V275 two-start factor
and the J-first source sign, the YY companion has coefficient
2(C_s-4) E in stripped g^3 xi units. It has switch degree two.
Sewing the kinetic one-port correction to the actual switched scalar
source vertex produces the opposite coefficient at switch degree three,
using the same massive bridge and its zero-transfer sign. This matches
the connected zero-transfer source carrier at collapsed unit switch.
It leaves the proper scalar tadpole and the proper source change.

There is a distinct, purely proper alternative in these projections.
The FMY reduced source tensor is obtained by replacing the residual
Y antighost by the actual scalar source vertex. The V275 ordered
F coefficient uses F_a=i L_a. Its contraction is

    S_F[s,x,c] = sum_(b,k,y) E_b[y] F_a[b,k,c] (rho_k)[x,y].

It equals 4 E_c[x] in both blocks. The same two-start factor gives
+8 E for FMY in the J-first convention. DMM uses a vertex with two
vector legs and has no corresponding scalar source replacement in
that contraction. Thus a third-order proper residue change
+(C_s-4)L_s (DMM_s+FMY_s)/4 exactly matches the opposite of the
second-order YY change in the ghost and scalar-source projections
at unit switch. At compact switch both changes are proportional
to sigma^2(sigma-1) in each of those projections. This is a better
candidate for the next admissibility test because its selected
repair uses no scalar one-port shift.

The nonzero source row cannot be dropped when using the same fixed
contracted-species kernel. Neither these two projections nor their
unit-switch cancellation establish field independence for a
specified extension on all balanced products, preservation of
the full tadpole/source conditions, or common normalization.

A genuine common finite map Z(P)=P+hbar N[P] would transport a
master direction by the inverse derivative. In the original
coordinates its first-loop shift is

    B'[P](N[P]) - N'[P](B[P]).

For a linear or affine field/source Ward derivative T the
corresponding shift is T N[P] - N'[P](TP). The separate E3
source shift and each marked direction must differentiate the
same functional. These identities follow by multiplying out
(DZ_P)^(-1) on the transformed insertion. They leave open the
action Ward, reality and normalization conditions for an actual
map, and the completion of the forced source and tadpole terms.
The exact block arithmetic uses a shared physical frame, software
and theory. It supports the restricted test without qualifying
W1–W7, A1–A5, a physical observable or a global weak limit.
