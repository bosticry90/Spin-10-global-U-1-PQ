"""Check the selected residue pair and a forced scalar-source companion."""

from collections import defaultdict
import gzip
from itertools import product
import json
import sys

import sympy as sp

from execute import PK, ROOT, run_worker


COLORS = range(45)
BLOCKS = {"Phi": (0, 54, sp.Integer(10)), "Sigma": (54, 306, sp.Rational(25, 2))}


def packet(name):
    return ROOT / "calculations" / f"canonical_so10_{name}"


def exact(entries):
    return {(a, b): sp.sympify(value) for a, b, value in entries}


def unpack(cells):
    result = 0
    for (g, xi, eta, mask), num, den in cells:
        assert (g, xi, eta) == (0, 0, 0)
        value = sp.Rational(num, den)
        for bit, factor in enumerate((sp.sqrt(2), sp.sqrt(3), sp.sqrt(5), sp.sqrt(7), sp.I)):
            if mask & (1 << bit):
                value *= factor
        result += value
    return result


def block_checks(role):
    data = json.loads((packet("ghost_mass_g4_pole") / f"{role}_v2_result.json").read_bytes())
    frame = json.loads((PK / "frozen_a10_physical_reconciliation" / f"full_{role}.json").read_bytes())
    vacuum = {x: sp.sympify(value) for x, _, value in frame["vacuum"]["VEV"]["entries"]}
    orbit = exact(data["physical_E"])
    y = {(x, a, c): sp.sympify(value) for x, a, c, value in data["physical_Y_aC_density"]}
    e = defaultdict(dict)
    for (a, x), value in orbit.items():
        e[a][x] = value
    y_by_contracted_ghost = defaultdict(list)
    for (x, k, c), value in y.items():
        y_by_contracted_ghost[k].append((x, c, value))

    coefficient_file = {"primary": "native_v2_coefficients.json.gz",
                        "replay": "replay_v4_coefficients.json.gz"}[role]
    currents = json.loads(gzip.decompress(
        (packet("physical_current_input_recovery_g1_v1") / coefficient_file).read_bytes()))
    rho = {}
    for k, entries in currents["rho"]:
        rho[k] = defaultdict(list)
        for out, x, cells in entries:
            rho[k][x].append((out, unpack(cells)))

    operators = json.loads((packet("fourghost_g4_lorentz") / f"{role}_result.json").read_bytes())
    f_by_b = defaultdict(list)
    for b, port, words, value in operators["classical_operator_tables"]["L"]:
        if port >= 45 and words[0].startswith("Cp"):
            c = int(words[0][2:])
            f_by_b[b].append((port - 45, c, sp.I * sp.sympify(value)))

    local, source = {}, {}
    for block, (start, stop, casimir) in BLOCKS.items():
        values = data["physical_scalar_sector_family_poles"][block]
        yy, dmm, fmy = (exact(values[key]) for key in ("YY", "DMM", "FMY"))
        normalization = 2 * casimir - 8
        for a, c in product(COLORS, repeat=2):
            gram = sum(e[a].get(x, 0) * e[c].get(x, 0) for x in range(start, stop))
            translated = sum(vacuum.get(x, 0) * y.get((x, a, c), 0) for x in range(start, stop))
            assert sp.expand(yy.get((a, c), 0) - normalization * gram) == 0
            assert sp.expand(dmm.get((a, c), 0) + fmy.get((a, c), 0) - 8 * gram) == 0
            assert sp.expand(translated + gram) == 0
        local[block] = {
            "kinetic_multiplier_of_L": str(-normalization / (2 * casimir)),
            "ordered_color_positions": 2025,
            "YY_diagonals_12_17": [str(yy.get((i, i), 0)) for i in (12, 17)],
        }

        # Contract the identical scalar and odd ports against the actual
        # J_x rho_k x C_k vertex. Strip its overall convention and coupling.
        companion = defaultdict(lambda: sp.S.Zero)
        fm_companion = defaultdict(lambda: sp.S.Zero)
        orbit_rebuilt = defaultdict(lambda: sp.S.Zero)
        for k in COLORS:
            for x, v in vacuum.items():
                if start <= x < stop:
                    for out, generator_value in rho[k][x]:
                        orbit_rebuilt[k, out] += generator_value * v
            for x, c, value in y_by_contracted_ghost[k]:
                if start <= x < stop:
                    for out, generator_value in rho[k][x]:
                        companion[out, c] += generator_value * value
        for b in COLORS:
            for k, c, value in f_by_b[b]:
                for x, e_value in e[b].items():
                    if start <= x < stop:
                        for out, generator_value in rho[k][x]:
                            fm_companion[out, c] += e_value * value * generator_value

        count = 0
        ratio = (casimir - 4) / 4
        for x, c in product(range(start, stop), COLORS):
            orbit_cell = e[c].get(x, 0)
            assert sp.expand(orbit_rebuilt[c, x] - orbit_cell) == 0
            value = sp.expand(companion[x, c])
            fm = sp.expand(fm_companion[x, c])
            assert sp.expand(value - (4 - casimir) * orbit_cell) == 0, (block, x, c)
            assert sp.expand(fm - 4 * orbit_cell) == 0, (block, x, c)
            assert sp.expand(2 * value + ratio * 2 * fm) == 0
            count += bool(value)
        assert count > 0
        source[block] = {"positions": (stop - start) * len(COLORS), "nonzero": count,
                         "YY_reduced_multiplier_of_orbit": str(4 - casimir),
                         "FMY_reduced_multiplier_of_orbit": "4",
                         "cubic_residue_multiplier_of_L": str(ratio),
                         "unit_switch_matched_in_both_projections": True}
    return local, source


def profile_checks(local):
    s, lp, ls, mass, v, gram, log = sp.symbols("s L_Phi L_Sigma M v G L")
    h = s**2 * (1 - s)
    m12 = sum(l * sp.sympify(local[block]["YY_diagonals_12_17"][0])
              for block, l in zip(BLOCKS, (lp, ls)))
    m17 = sum(l * sp.sympify(local[block]["YY_diagonals_12_17"][1])
              for block, l in zip(BLOCKS, (lp, ls)))
    assert sp.expand(m17 - sp.Rational(2017, 170) * m12 - 300 * (lp - ls)) == 0
    for block, (_, _, casimir) in BLOCKS.items():
        # v denotes the VEV direction, so Y[v] acts as -G.
        kinetic = sp.sympify(local[block]["kinetic_multiplier_of_L"]) * 2 * mass * casimir * v * log
        sewed = s**2 * kinetic / mass * s * (-gram / v)
        m = (2 * casimir - 8) * gram * log
        assert sp.expand(sewed - s**3 * m) == 0
        assert sp.expand(h * m - s**2 * m + sewed) == 0
        assert sp.expand((sewed - s**2 * m).subs(s, 1)) == 0
        assert sp.expand(h * m - s**2 * m) != 0
        assert sp.expand(h * m + s**2 * m + sewed) != 0
    return {"combined_residual": "0", "only_YY_residual": "-sigma**3*m",
            "unit_switch_combined_change": "0", "m_12": str(m12), "m_17": str(m17)}


def master_checks():
    s, m, width, n = sp.symbols("s m w n")
    ghost_action = -s**2 * m
    source_matrix = sp.Matrix([[sp.I*s, width], [0, -sp.I*s]])
    induced = source_matrix * sp.Matrix([ghost_action, 0])
    assert sp.expand(induced[0] + sp.I*s**3*m) == 0
    assert sp.expand(source_matrix.det() - s**2) == 0
    assert induced[0] != 0 and induced[1] == 0
    # The scalar tadpole and its VEV are H-invariant, but its full
    # signed master Euler image still uses the actual scalar source row.
    assert (source_matrix * sp.Matrix([ghost_action, n]))[1] == -sp.I*s*n
    return {"fixed_insertion_diagonal": "-I*sigma**3*m",
            "source_matrix_determinant": "sigma**2",
            "amended_insertion": "Bprime[P](N); mixed derivative Bdoubleprime[P](K,N)"}


def check(phase):
    local, source = block_checks("primary" if phase == "native" else "replay")
    return {"local_residues": local, "source_companion": source,
            "profile_pair": profile_checks(local), "master": master_checks()}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
