# V916 pre-execution contract

Test a first-loop compact local action change on the V915 ordered
color-12/17 ordinary ghost profile pair. Freeze the V882 physical
kinetic and YY residues, V908 massive bridge, V911 exterior estimate,
V900 constant-jet master chart and V915 profile coefficient. Use the
same positive fixed reference squared masses and common kappa. The
two independent logarithms are reference coefficients and the
correction must be polynomial in the dynamical coupling grades.

Require the full ordered block-color arithmetic and direct scalar
source contraction in native and replay frames. Preserve the
difference between the connected zero-transfer test, its finite
compact parent with amended master insertion, and a common
causal-product map. In particular test whether the same fixed
scalar–ghost contraction can act on YY alone when the scalar source
vertex is present. Failure of the simple candidate to extend does
not exclude other admissible maps. No full W1–W7/A1–A5 acceptance.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.
Preserve failed computations. No state promotion.

## V2 continuation after native failure

The first native worker failed at Phi row 1, color 31. The frozen
plane representation matrices were in the wrong gauge frame for
this comparison. Preserve the entire failed packet and capture
under the original D: research-control record, in
preserved_active_v1. The SHA inventory is bound here. Use the
already-qualified V787 joined source coefficients and require
rho v = E exactly before contracting. Retain all original gates.
Also test the alternate third-order residue route using the V270
F operator with the same source companion. Require exact ratio
matching at unit switch. The source-completeness ceiling stays.
