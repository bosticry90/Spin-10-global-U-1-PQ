# V916 result

Two local two-vertex residue changes cancel the V915 profile difference
for the selected connected ordinary ghost pair. The YY action change
supplies -sigma² m and the kinetic one-port change, sewn through the
actual massive bridge and switched Y, supplies +sigma³ m. The
dilated bridge error is O(R^-2(1+log R)) in the connected pairing.
The original compact master insertion cannot be held fixed for this
action change. Its signed variation includes a scalar xC contribution
at g³ xi and a Lambda C contribution at g⁴ xi².

Direct scalar-source contractions find 24 Phi and 272 Sigma nonzero
companion entries. The standalone two-residue action ansatz cannot
serve as its own common causal product map. A third-order proper
DMM+FMY residue alternative cancels the YY change at unit switch in
both the ghost and scalar-source projections, without using the
scalar one-port change. Its bosonic and other source/mark companions
still require assessment. Neither alternative earns full causal
normalization, a physical observable result or a global weak limit.

The first native attempt used plane generators for a joined carrier
and failed. Its source, capture and complete preparation are retained
under the original D: control packet and bound by SHA inventory. The
v2 native and replay routes use the qualified joined V787 matrices
and check the orbit relation against V275 before comparing sources.
The calculations share the physical input, conventions and software.
No scientific authority change.
