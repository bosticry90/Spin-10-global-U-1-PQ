from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations,product
from collections import Counter
import gzip,json,os,re,subprocess,sys,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/augmented-uv-grading-v1-2026-11-08')
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def d(n):
    if n>=1286:assert n<1319;return 1
    if n>=643:return 3-d(n-643)
    return 1+int(n in range(508,553))
def degrees(node):
    kind=node['node']
    if kind=='Field':return{(1,0)}
    if kind=='Parameter':return{(0,node['mass_dimension'])}
    if kind in['ExactScalar','InvariantTensor','KroneckerMetric','StructureConstant','RepresentationGenerator']:return{(0,0)}
    if kind in['GroupContraction','LorentzContraction']:return degrees(node.get('expression',node.get('argument')))
    if kind=='Add':return set().union(*(degrees(q)for q in node['terms']))
    assert kind=='OrderedProduct',kind
    out={(0,0)}
    for child in node['factors']:out={(i+j,k+l)for i,k in out for j,l in degrees(child)}
    return out
def check_ports(raw,D,z):
    assert len(raw)==len(z['all_density_words_and_ports']);hist=Counter();marginal=[];count=0;positive=[]
    for at,((word,cells),record)in enumerate(zip(raw,z['all_density_words_and_ports'])):
        coeffdim=D-sum(d(n)+len(js)for n,js in word);assert coeffdim>=0
        assert record['density_word_index']==at and record['complete_word']==word and record['complete_coefficient_cells']==cells and record['declared_density_dimension']==D and record['intrinsic_coefficient_dimension']==coeffdim
        pairs=[]
        for p in range(len(word)):
            if word[p][0]>=643:continue
            for q in range(p+1,len(word)):
                if word[q][0]>=643:continue
                ni,di=word[p];nj,dj=word[q];remaining=word[:p]+word[p+1:q]+word[q+1:];cost=D-d(ni)-d(nj)-len(di)-len(dj);defect=4-D+cost;assert defect==(2-d(ni))+(2-d(nj))-len(di)-len(dj)and defect>=0
                label=[sum(n<643 for n,js in remaining),sum(643<=n<1286 for n,js in remaining),sum(n>=1286 for n,js in remaining)];assert cost==coeffdim+sum(d(n)+len(js)for n,js in remaining)
                row=[p,q,ni,nj,len(di)+len(dj),cost,defect,label];pairs.append(row);hist[defect]+=1;count+=1
                if not defect:marginal.append([at,row])
                if cost>0 and not any(label):positive.append([at,row])
        assert pairs==record['all_two_ordinary_port_positions']
    assert not z['all_counterexamples']and count==z['port_count']and marginal==z['all_marginal_ports']and[[k,v]for k,v in sorted(hist.items())]==z['defect_histogram']
    return count,positive
def cofactor_rows(packet):
    out=[]
    for name,table in packet['states'].items():
        for i,raw in table:
            target=d(i)+1 if name.startswith('F')else 4-d(i)
            for at,(word,cells)in enumerate(raw):
                diff=target-sum(d(n)+len(js)for n,js in word);assert diff>=0;out.append([name,i,at,target,diff])
    for name,table in packet['physical'].items():
        for i,raw in table:
            target=4-d(i)
            for at,(word,cells)in enumerate(raw):
                diff=target-sum(d(n)+len(js)for n,js in word);assert diff>=0;out.append([name,i,at,target,diff])
    return out
def reference(role,audit,record):
    q=s.symbols('q0:4');g,xi,eta=s.symbols('g10 xi eta_H');out={}
    for row in audit['all_zero_transfer_density_audits']:
        if row['density']not in['S0_GF_source','physical_S0_gauge','physical_S0_scalar']:continue
        for i,j,mom,key,num,den in row['complete_zero_transfer_Euler_Fourier_kernel']:
            if sum(mom)!=4-d(i)-d(j):continue
            rad=s.prod(s.sqrt(prime)for bit,prime in enumerate([2,3,5,7])if key[3]&(1<<bit))*(s.I if key[3]&16 else 1);coef=s.Rational(num,den)*g**key[0]*xi**key[1]*eta**key[2]*rad;monomial=s.prod(q[mu]**exponent for mu,exponent in enumerate(mom));out[i,j]=out.get((i,j),0)+coef*monomial
    out={ij:s.expand(v)for ij,v in out.items()if s.expand(v)!=0};target={(i,j):s.sympify(v)for i,j,v in load(B/'canonical_so10_regulator_free_inverse_g1_recovery_v1'/(role+'_inverse.json.gz'))['Pphysical']};assert set(out)==set(target)and len(out)==1543
    for ij in out:assert s.expand(out[ij]-target[ij])==0
    assert record==[[i,j,str(out[i,j])]for i,j in sorted(out)]
    # Executed reference-omission control: a real marginal q² term changes it.
    wrong=dict(out);wrong[0,0]+=sum(x*x for x in q);assert s.expand(wrong[0,0]-target[0,0])!=0
def main():
    tick=time.perf_counter();watch=threading.Timer(240,lambda:os._exit(124));watch.daemon=True;watch.start()
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='b2b4c7c4f52712bcf2d087787ebc746b9d82d5c2'
    for name,h in read(O/'preparation_validation.json')['sha256'].items():assert digest(R/name)==h,name
    saved={'README.md':C/'README_before.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':C/'campaign_before.md'}
    for name in['preparation.json','preparation_v2.json']:
        prep=read(O/name);assert prep==read(C/name)
        for n,h in prep['sha256'].items():assert digest(saved[n]if n in saved else R/n)==h,n
    for name in['input_encoding_bindings.json','input_encoding_bindings_v2.json']:
        z=read(O/name);assert z==read(C/name)
        for row in z['bindings']:
            n=row['file'];live=(saved[n]if n in saved else R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R);assert sha256(live).hexdigest()==row['checkout_sha256']and sha256(stored).hexdigest()==row['git_blob_sha256'];assert row['exact_equal']==(live==stored)and live.replace(b'\r\n',b'\n')==stored and row['only_CRLF_to_LF']
            if live!=stored:assert subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set')
    for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes()
    setup=read(O/'setup_failure.json');assert setup['stage']=='BEFORE_PREPARATION_AND_SCIENTIFIC_WORKER'and setup['observed_exit_code']==1 and setup['failed_wrapper_sha256']==digest(O/'execute.py')
    failed=read(O/'capture.json');assert failed==read(C/'capture.json')and failed['exit_code']==1 and not failed['calculation_completed']and 'ACTUAL_INTRINSIC1_CONSTANT_BASE_NOT_IDENTIFIED'in failed['stdout_and_stderr']and not(O/'result.json').exists()
    cap=read(O/'capture_v2.json');assert cap==read(C/'capture_v2.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);result=read(O/'result_v2.json');assert result['elapsed_after_imports']<120
    kd=load(B/'canonical_so10_cartan_generator_residual_g1_v1/v2_fixed_ward_and_old_affine_endpoints.json.gz');dr=[]
    for i,raw in kd['all1286_D']:
        for at,(word,cells)in enumerate(raw):
            diff=d(i)-sum(d(n)+len(js)for n,js in word);assert diff>=0;dr.append([i,at,d(i),diff])
    physical=read(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_executable_reconciliation/M08_PHYSICAL_ACTION_COVARIANT_EXECUTABLE_V1.json');pot=[]
    for row in physical['local_terms'][5:]:
        ds=degrees(row['density']);assert all(n>=2 and m>=0 and n+m==4 for n,m in ds)and all(m==2 for n,m in ds if n==2);pot.append([row['term_id'],[list(x)for x in sorted(ds)]])
    expected_grammar=[[budget,list(grade),budget+sum(grade),budget+sum(grade)]for budget in range(5)for grade in product(range(2),repeat=4)]
    # Every path increases cost or bounded grade: exact rank function proves
    # arbitrary-length bound; adding an ungraded cost0 token gives a selfcycle.
    states=[(c,g)for c in range(5)for g in product(range(2),repeat=4)];assert all(c+sum(g)<=8 for c,g in states)
    selfcycle=((0,(0,0,0,0)),(0,(0,0,0,0)));assert selfcycle[0]==selfcycle[1]
    synthetic_beta_defect=(2-d(0))+(2-d(553))-3;assert synthetic_beta_defect==-1
    synthetic_mixed=(2-d(508))+(2-d(180));assert synthetic_mixed==1
    summaries=[]
    for r in result['roles']:
        role=r['role'];art=r['artifact'];assert digest(O/art['file'])==art['sha256']and(O/art['file']).stat().st_size==art['bytes'];z=load(O/art['file']);audit=load(B/'canonical_so10_augmented_operator_ir_domain_v1'/(role+'_complete_operator_ir_audit.json.gz'));breaking=load(B/'canonical_so10_augmented_operator_ir_domain_v1'/(role+'_constant_beta_breaking_gate_v2.json.gz'));assert len(breaking['all_six_cases'])==6 and all(not x['complete_B_Euler_Fourier_kernel']['complete_zero_transfer_Euler_Fourier_kernel']for x in breaking['all_six_cases'])
        u=load(B/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_GF_common.json.gz'));s1=load(B/'canonical_so10_full_current_inventory_g1_recovery_v1'/(role+'_route_densities.json.gz'));s0=load(B/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_route_density.json.gz'))['original_GF'];dens=[('S0_GF_source',s0,4),('S1_GF_source',s1['S1'],4)]+[('U0_'+n,u['probes'][p]['U'],4)for p,n in enumerate(['H','M'])]+[('U1_'+n,s1['U1'][p],4)for p,n in enumerate(['H','M'])]+[('KD',kd['complete_K'],3)];known=load(B/'canonical_so10_physical_current_input_recovery_g1_v1'/('native_v2_action.json.gz'if role=='native'else'replay_v4_action.json.gz'));dens+=[('physical_'+name,raw,4)for name,raw in known.items()];np=0;nw=0
        assert len(z['all_literal_parent_density_ports'])==len(dens)
        for(name,raw,D),zz in zip(dens,z['all_literal_parent_density_ports']):
            assert name==zz['density'];count,positive=check_ports(raw,D,zz);np+=count;nw+=len(raw)
            if name=='S0_GF_source':assert positive==z['complete_positive_cost_unlabeled_base_ports']==[]
        rows=cofactor_rows(load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz')));assert rows==z['all_GF_source_and_known_physical_cofactor_type_rows'];hist=Counter(x[-1]for x in rows);assert[[k,v]for k,v in sorted(hist.items())]==z['cofactor_intrinsic_histogram']
        assert z['all_D_type_rows']==dr and z['all29_physical_potential_degrees']==pot and z['all4_dimensions_and_UV_weights']==[[n,d(n),2-d(n)]for n in range(1319)]and z['relaxed_all_grade_cost_grammar']==expected_grammar
        reference(role,audit,z['complete1543_base_zero_cost_kernel_equals_Pphysical']);ctrl=z['negative_controls'];assert ctrl['synthetic_admitted_Lambda_x_constant_defect']==synthetic_mixed and ctrl['actual_unprobed_base_positive_cost_ports']==0 and ctrl['erased_label_beta_BC_has_negative_defect']['relative_defect']==synthetic_beta_defect
        assert np==r['all_selected_port_pairs']==493699 and nw==r['all_literal_density_words']==157200 and len(rows)==r['cofactor_type_rows']==382646;summaries.append(dict(role=role,port_pairs=np,density_words=nw,cofactor_rows=len(rows),complete_base_reference=1543,positive_cost_g0_base_ports=0));del z
        print('STAGE '+role+' independent_complete_UV_type_replay',flush=True)
    assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)
    assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md']
    state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'and b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V851.md)'in live
    links=[]
    for q,txt in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V851.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V851.md').read_text(encoding='utf-8')),(O/'RESULT.md',(O/'RESULT.md').read_text(encoding='utf-8'))]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([q.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0
    events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[z['exit_code']for z in events if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(z for z in events if z['event']=='step_finished'and z['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=64*1024**2
    files=[p for p in O.iterdir()if p.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V851.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_SELECTED_AUGMENTED_UV_GRADING_AND_FINITE_LOCAL_BORN_GATES',base_HEAD=head,state_sha256=state,roles=summaries,conservative_local_UV_Born_length_bound=8,actual_source_jet_commutation_and_common_contacts_NOT_qualified=True,failed_setup_and_false_base_census='PRESERVED_FAILED_NOTPASS',exact_encoding_hashes_and_CRLF_only_relation_checked=True,executed_negative_controls=dict(ungraded_cost0_selfcycle=list(selfcycle),erased_beta_label_defect=synthetic_beta_defect,mixed_Lambda_x_defect=synthetic_mixed,reference_marginal_omission_sensitive=True),UV_remainder_and_full_heat_power_first_jet_boundary_reviewed=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',maximum_sampled_primary_private_bytes=max(x['private_bytes']for x in cap['all_resource_samples']),sampled_not_continuous_peak=True,checked_local_links=links,files_excluding_pending_receipt_capture={p.relative_to(R).as_posix():digest(p)for p in files},shared_action_conventions_Python_Sympy_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
