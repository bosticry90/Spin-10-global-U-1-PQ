# Complete selected first-background proper coefficient

Use V988's 643 ordinary fields, no external
fermions and the same qualified relative
trace. Use fixed total mean, unit switch,
zero width and zero intrinsic degree. At
first A degree every interaction derivative
cancels between the two prescriptions.
The original pure reference has no BB
derivative. Thus only the explicit edge
replacement from V988 is needed. Evaluate
the degree-one local polynomial with
A1 momentum k e1 and polarization e2,
B20 polarization e1 and B33 polarization
e2. The V988 reflection in e3 justifies
the slice B20 momentum zero as a polynomial
evaluation of the nonexceptional family.

At two exterior B means the possible
interaction words are two cubics or one
quartic. At unit switch the ordinary
gauge cubic letters are the physical
Yang-Mills Hessian Y, the gauge-fixing
BB Lambda Hessian L and the B C a
Hessian. The two L letters cannot close
at first degree by V988's Lambda-Lambda
exclusion and the disjoint H/M color
support. The ghost blocks do not mix
with the gauge/auxiliary block at
these means. There is no scalar-gauge
mixed Hessian with the chosen intrinsic
grading and zero scalar means.

The scalar loops have only the returning
Bxx cubics or BBxx seagull. The free
reference, heat and masses are scalar
inside each real invariant block. The
two-cubic color trace is
tr(rho_1 rho_20 rho_33) or its reverse.
It vanishes on all four actual scalar
blocks, also following from the invariant
quadratic trace and f_(1,20,33)=0.
Replacing 33 by 30 gives nonzero trace
controls on the three charged blocks.
The scalar seagull is zero with
orthogonal external polarizations.
The result is on the 643-field
parent. A separate fermionic extension
with its hatted projectors, phases and
profiles is outside this comparison.

For the gauge quartic use the Hessian
of the original [B_mu,B_nu]^2 density.
Only internal polarizations (1,2) and
(2,1) occur. In the first orientation
the color at differentiated ends u,v
is <[20,33],[u,v]>+<[20,v],[u,33]>.
The second orientation exchanges u,v.
Contract r_1[u,v] in each H/M sector.
Both sector sums vanish exactly.
The one-vertex ghost BB C a letter has
equal exterior Lorentz axes in all
53,016 literal rows per route. The
selected orthogonal axes therefore
exclude that letter independently of
the heat profiles.

For the cubic bosonic terms route
the differentiated edge from B20 to
B33 at p=-q, r=-q-k e1. The undifferentiated
line carries q. For each choice of
type and color the cyclic trace with
both edge replacements and both
external B placements gives the
quadratic log multiplier -1 on the
single oriented form. The transpose
and reverse momentum give the same
second orientation. The two vertices
and reference insertion have common
phase i^3, so their loop contribution
has phase +i times the ordered color.

For differentiated/spectator sectors
HH,HM,MH,MM the ordered Y-Y color
sum r_1[u,v] f_(u,x,20) f_(v,x,33)
is (0,0,1/10,-1/10). If one vertex is L,
differentiating the ordinary H edge
leaves a mixed M spectator. That H-M
color sum is zero in both assignments.
Its individual terms need not vanish.
Differentiating the mixed M edge
leaves an ordinary H spectator.
Orient the differentiated edge the
same way for both Y-L and L-Y.
Both colors then are +1/10. Reversing
the L-Y orientation changes its
color and Lorentz sign together.

With q on the unit sphere put d=q1,
u=q2. The Yang-Mills tensors at the
two ends, stripped of i and f, are

    Y20=2d I-q e1^t-e1 q^t,
    Y33=-2u I+(q-k e1)e2^t+e2(q+2k e1)^t.

The literal action checks all 18
relevant rows at each end. Use the
V988 ordered free inverse and first
Weyl reference block. Expand the
right free inverse and the two
vertices through first k. For each
ordered pair write b4 for the mean
unheated degree -4 coefficient, j
for the first heat transfer mean,
d1 for the differentiated sum of
the heat-half amplitudes and d2
for the second transfer-heat mean.
The direct four-dimensional sphere
contraction gives

    pair      b4       j       d1       d2
    Y-Y      -1/12    4/3      1        4
    Y-L       0       3/4     -1/4     -1/3
    L-Y       7/12   -1/4    -13/12    -1/3

The Y-L row is V988. A separate
contraction with the Y33 end kept
on the left gives the negative of
the L-Y row, with reversed ordered
color. Use full differentiated
broken length m and spectator length e.
The covariant clock is c=e+m and
flat clock c_f=e+2m. In units
k/(16 pi²) each row contributes

    b4 log(c_f/c)
      + j [m/(2c)-m/c_f]
      + d1 m/(2c) + d2 m²/(4c²).

The positive heat terms follow from
the two half time weights 1+s and s.
The angular mean uses the exact
four-sphere even moments. The
paired large IR times yield no
hard coefficient. No new exceptional
loop limit is taken.

For ghosts, the actual exterior B20
and B33 vertices with light input C
are whole-vertex total derivatives.
Their other input is M, so both
returning C/a pairs are M. Let T_b
be the M-M C-first cubic color
matrix ad_b. The actual ordered
trace tr(r_1 T_20 T_33) is -1/10.
The opposite order has the opposite
sign. With s=t m and H(Q)=exp(-sQ)/Q,
the background difference on the
C-first inverse is
-i (p+q) dot A r_1 [H[P,Q]+H(P)H(Q)].
Expand the two edge replacements
of the ghost quadratic log, whose
exterior cross multiplier is +1.
The two color orders combine into

    -2i q2² [q1 H(Q)-p1 H(P)]
        [H[P,Q]+H(P)H(Q)] tr(r_1 T_20 T_33),

where p=q+k e1, Q=q², P=p².
At first k the divided difference
is H'(Q). Taking the spherical mean
and putting u=sQ gives the radial
integral

    integral (1/3-u/6)
        [(exp(-3u)-exp(-2u))/u-exp(-2u)] du.

Its value is log(2/3)/3-7/72.
The color trace reverses this sign.
The term uses only the broken length.

Combine the two bosonic rows with
their verified colors and the ghost
term. For c=h+m and c_f=h+2m, the
complete selected relative coefficient
in units i g³ k/(160 pi²) is

    log(c_f/c)/2 + (5/12)log(3/2)
       + 3m/(4c) + 5m²/(6c²)
       - 11m/(6c_f) - 7/24.

At h=m the result is
(11/12)log(3/2)-23/72.
At h:m=1:3 it is
log(7/4)/2+(5/12)log(3/2)-31/672.
Both are nonzero. In the former
case the pure Yang-Mills contribution
vanishes, while the mixed and ghost
contributions do not. These are
finite differences between the two
proper prescriptions. The explicit
cutoff and source derivative with
the same insertion, the separate
fermionic construction, and the
connected forest remain distinct.
Both routes share the action and
symbolic implementation.
