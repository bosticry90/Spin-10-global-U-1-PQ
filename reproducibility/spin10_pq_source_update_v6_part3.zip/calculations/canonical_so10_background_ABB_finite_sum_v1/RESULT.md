# V989 result

The complete selected first-background local
difference on the 643-field proper parent is
nonzero. With c=h+m and d=h+2m, its value in
units i g³ k/(160 pi²) is

    log(d/c)/2 + (5/12) log(3/2)
      + 3m/(4c) + 5m²/(6c²)
      - 11m/(6d) - 7/24.

The ordinary Yang-Mills, mixed BB Lambda and
ghost pieces enter with their own heat clocks
and phases. The ordinary H replacement in
the mixed pair has zero summed color.
The gauge quartic vanishes in each color
sector. The ghost quartic vanishes by
orthogonal exterior polarizations.
The scalar triple traces are zero on
all four blocks and have nonzero
color-replacement controls.

The native and replay routes use the literal
action and the same symbolic software.
This is the complete proper difference for
the declared first local transverse A B B
coefficient. The explicit geometric cutoff
comparison, separate fermionic extension
and connected products remain distinct.
