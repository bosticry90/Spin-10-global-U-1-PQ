"""Sum the degree-one relative background difference in the 643-field parent."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


def previous():
    path = ROOT / "calculations/canonical_so10_mixed_background_edge_finite_v1/mixed_background_edge_finite.py"
    spec = importlib.util.spec_from_file_location("first_mixed_edge",path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def colors(f,entries):
    def value(i,a,b):
        return f.get((i,a,b),0)

    def sector(i):
        return "H" if i<12 else "M"

    cubic,quartic = defaultdict(lambda:sp.S.Zero),defaultdict(lambda:sp.S.Zero)
    ghost = sp.S.Zero
    for (u,a,v),z in f.items():
        if a!=1:
            continue
        assert sector(u)==sector(v)
        r = -z
        for x in range(45):
            cubic[sector(u)+sector(x)] += r*value(u,x,20)*value(v,x,33)
            quartic[sector(u)] += r*(value(x,20,33)*value(x,u,v)+value(x,20,v)*value(x,u,33))
            if min(u,v,x)>=12:
                ghost += r*value(v,20,x)*value(x,33,u)
    cubic = {k:sp.expand(v) for k,v in cubic.items()}
    assert cubic=={"HH":0,"HM":0,"MH":sp.Rational(1,10),"MM":-sp.Rational(1,10)}
    assert {k:sp.expand(v) for k,v in quartic.items()}=={"H":0,"M":0}
    assert sp.expand(ghost)==-sp.Rational(1,10)

    def scalar(label,lo,hi):
        A,B,C = (sp.SparseMatrix(hi-lo,hi-lo,{(i-lo,j-lo):z for (i,j),z in entries[a].items()
                                               if lo<=i<hi and lo<=j<hi}) for a in (1,20,label))
        assert A.T==-A and B.T==-B and C.T==-C
        return sp.expand(sp.trace(A*B*C))
    blocks = ((0,54),(54,306),(306,326),(326,328))
    assert [scalar(33,*s) for s in blocks]==[0,0,0,0]
    assert [scalar(30,*s) for s in blocks]==[3,sp.Rational(35,2),sp.S.Half,0]
    return cubic


def angular():
    n = sp.Matrix(sp.symbols("n0:4"))
    d,u = n[1],n[2]
    e,w = sp.eye(4)[:,1],sp.eye(4)[:,2]
    I = sp.eye(4)
    T = I-n*n.T
    def block(B,M,L):
        return B.row_join(M).col_join(L.row_join(sp.zeros(1)))
    def ordinary(B):
        return block(B,sp.zeros(4,1),sp.zeros(1,4))

    G = block(T,n,-n.T)
    dG = block(-2*d*I-e*n.T-n*e.T+4*d*n*n.T,e-2*d*n,(-e+2*d*n).T)
    K = block(-2*u*I+n*w.T+w*n.T,w,-w.T)
    dK = ordinary((e*w.T+w*e.T)/2)
    B0 = -G*K*G
    B1 = -G*dK*G-G*K*dG
    E0 = 2*u*G
    E1 = 2*u*dG

    def mean(expr):
        poly = sp.Poly(sp.expand(expr),*list(n))
        result = sp.S.Zero
        for powers,coeff in poly.terms():
            if any(j%2 for j in powers):
                continue
            degree = sum(powers)
            numerator = sp.prod(sp.factorial2(j-1) for j in powers)
            denominator = sp.prod(range(4,4+degree,2))
            result += coeff*numerator/denominator
        return result

    def pair(M,N):
        return sum(x*y for x,y in zip(M,N))

    def jets(X,S,Y,dY):
        Z,dZ = X*S*Y.T,X*S*dY.T
        return (mean(pair(Z,B1)+pair(dZ,B0)),mean(-2*d*pair(Z,B0)),
                mean(pair(Z,E1)+2*pair(dZ,E0)),mean(-4*d*pair(Z,E0)))

    Y0 = ordinary(2*d*I-n*e.T-e*n.T)
    Y1 = ordinary(-2*u*I+n*w.T+w*n.T)
    dY1 = ordinary(-e*w.T+2*w*e.T)
    L0 = block(sp.zeros(4),sp.zeros(4,1),e.T)
    L1 = block(sp.zeros(4),sp.zeros(4,1),w.T)
    S = ordinary(T)
    result = {
        "YY":jets(Y0,S,Y1,dY1),
        "YL":jets(Y0,S,L1,sp.zeros(5)),
        "LY":jets(L0,S,Y1,dY1),
    }
    assert result["YY"]==(-sp.Rational(1,12),sp.Rational(4,3),1,4)
    assert result["YL"]==(0,sp.Rational(3,4),-sp.Rational(1,4),-sp.Rational(1,3))
    return result


def literal_other_vertex(phase,source,f,q,k):
    root = ROOT / "calculations"
    role = "native_v2" if phase=="native" else "replay_v4"
    path = root / "canonical_so10_physical_current_input_recovery_g1_v1" / f"{role}_action.json.gz"
    action = source.seagull.read(path)["S1_gauge"]
    e,w = sp.eye(4)[:,1],sp.eye(4)[:,2]
    mom = {29:q+k*e,0:-q,33:-k*e}
    out = sp.zeros(4)
    rows = 0
    for word,cells in action:
        axes = {i//4:(i%4,d) for i,d in word}
        if set(axes)!=set(mom) or axes[33][0]!=2:
            continue
        assert all(v[:3]==[1,0,0] for v,_,_ in cells)
        coeff = source.seagull.unpack([([0,*v[1:]],n,d) for v,n,d in cells])
        (color,[mu]), = [(c,d) for c,(_,d) in axes.items() if d]
        out[axes[29][0],axes[0][0]] += coeff*mom[color][mu]
        rows += 1
    target = -2*q[2]*sp.eye(4)+(q-k*e)*w.T+w*(q+2*k*e).T
    assert rows==18 and (out/f[29,0,33]-target).applyfunc(sp.expand)==sp.zeros(4)

    current = root / f"canonical_so10_unprobed_compact_all_coupling_v1/{phase}_full_current.json.gz"
    raw = source.seagull.read(current)["current"]["complete_S_GF_source"]
    ghost,quartic,mixed = {},0,0
    for g,word,cells in raw:
        ids = tuple(i for i,_ in word)
        if g==1 and ids==(1,81,527):
            mixed += 1
            assert all(not d for _,d in word)
            assert source.seagull.unpack([([0,*p],n,d) for p,n,d in cells])==sp.I*f[19,0,20]
        if g==1 and len(ids)==3 and ids[0] in (81,134) and 553<=ids[1]<598 and 598<=ids[2]<643:
            code = tuple(bool(d) for _,d in word)
            ghost[ids[0],ids[1]-553,ids[2]-598,code] = source.seagull.unpack([([0,*p],n,d) for p,n,d in cells])
        if g==2 and len(ids)==4 and ids[1]<180 and 553<=ids[2]<598<=ids[3]<643:
            assert ids[0]%4==ids[1]%4
            quartic += 1
    assert quartic==53016 and mixed==1
    for b,ids in ((20,81),(33,134)):
        for i in range(45):
            for j in range(45):
                d = -f.get((j,b,i),0)
                for code,expected in (((True,False,False),d if i<12 else 0),
                                      ((False,True,False),d if i<12 else 0),
                                      ((False,False,True),d)):
                    assert ghost.get((ids,i,j,code),0)==expected


def finite(jets):
    h,m,u,a,b = sp.symbols("h m u a b",positive=True)
    c,cf = h+m,h+2*m
    def edge(key,H):
        d4,j1,d1,d2 = jets[key]
        return d4*sp.log((H+2*m)/(H+m))+j1*(m/(2*(H+m))-m/(H+2*m)) + (
               d1*m/(2*(H+m))+d2*m*m/(4*(H+m)**2))
    assert jets["LY"]==(sp.Rational(7,12),-sp.Rational(1,4),-sp.Rational(13,12),-sp.Rational(1,3))
    pure = edge("YY",h)-edge("YY",m)
    mix = edge("YL",h)+edge("LY",h)
    direct_mix = sp.Rational(7,12)*sp.log(cf/c)-5*m/(12*c)-m*m/(6*c*c)-m/(2*cf)
    assert sp.simplify(mix-direct_mix)==0

    # The divided difference at equal arguments supplies h' + h².
    profile = sp.exp(-u)
    rational = sp.integrate(-(sp.exp(-3*u)-sp.exp(-2*u))/6-(sp.Rational(1,3)-u/6)*profile**2,
                            (u,0,sp.oo))
    frullani = sp.integrate(sp.integrate(sp.exp(-a*u),(u,0,sp.oo)),(a,2,3))
    assert rational==-sp.Rational(7,72) and sp.simplify(frullani-sp.log(sp.Rational(3,2)))==0
    ghost = frullani/3-rational
    total = pure+mix+ghost
    target = sp.log(cf/c)/2+sp.Rational(5,12)*sp.log(sp.Rational(3,2))+3*m/(4*c)+5*m*m/(6*c*c)-11*m/(6*cf)-sp.Rational(7,24)
    assert sp.simplify(sp.expand_log(total-target,force=True))==0
    common = sp.Rational(11,12)*sp.log(sp.Rational(3,2))-sp.Rational(23,72)
    unequal = sp.log(sp.Rational(7,4))/2+sp.Rational(5,12)*sp.log(sp.Rational(3,2))-sp.Rational(31,672)
    assert sp.simplify(sp.expand_log(total.subs(h,m)-common,force=True))==0
    assert sp.simplify(sp.expand_log(total.subs({h:1,m:3})-unequal,force=True))==0
    assert sp.Rational(11,12)*sp.Rational(2,5)-sp.Rational(23,72)>0
    return [str(common),str(unequal)]


def check(phase):
    base = previous()
    source = base.owner()
    _,entries,_,bracket,_,_ = source.inputs(phase)
    f = {(i,a,b):z for (a,b),pairs in bracket.items() for i,z in pairs}
    q,k = sp.Matrix(sp.symbols("q0:4")),sp.Symbol("k")
    base.literal_vertices(phase,source,f,q)
    literal_other_vertex(phase,source,f,q,k)
    color = colors(f,entries)
    moments = angular()
    result = finite(moments)
    return {"cubic_color_by_edge_spectator":{k:str(v) for k,v in color.items()},
            "gauge_quartic_color_zero_sectorwise":True,"ghost_quartic_zero_by_axes":True,
            "scalar_blocks_and_negative_control_verified":True,
            "actual_LY_and_YY_symbols_verified":True,
            "full_643_field_ABB_finite_controls":result}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
