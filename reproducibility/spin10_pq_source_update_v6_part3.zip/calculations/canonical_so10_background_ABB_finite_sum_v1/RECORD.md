# V989 pre-execution contract

Use V988 fixed-total-mean first-edge reduction
at zero widths and intrinsic degree, unit switch.
Select A1 with polarization e2 and transfer k e1,
B20 with polarization e1 and B33 with polarization
e2. Extract the local degree-one polynomial using
the V988 nonexceptional reflection argument.
Compute all two-cubic gauge, ghost and mixed
words and the quartic gauge tadpole under the
same paired clock. Show whether scalar and
fermion representation traces can contribute.
Use actual V788/V879/V869/V791 inputs and
V988 literal mixed-edge control. Compare signed
color sectors and both heat routes. The output
is a bounded proper coefficient, with explicit
cutoff and connected extensions still separate.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority
change or selected normalization.
