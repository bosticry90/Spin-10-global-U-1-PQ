# V944 pre-execution contract

Test the full equal stripped-weight V943 color tensor
against a single canonical gauge-coordinate map. Freeze
both V940 bubbles, both V943 mixed ghost sectors, all
ordered colors and the literal source convention.

Recompute the full combined tensor and compare every
implied zero and nonzero to the independently evaluated
commutator transport. Include omitted-family controls.
Derive gauge-square, ghost Jacobi and scalar representation
consequences at this purely algebraic level. Do not assign
the required lower map or transverse metric to the actual
finite scheme. Native 120 s, final 180 s including E4 cap
120 s, 8 GiB sampled private, 350 MiB launch floor, 8 MiB
artifact and 32 MiB packet. No scientific authority change.

V1 reached full tensor equality and then stopped on scalar multiplication
of a sparse dictionary in an omitted-family control. V2 applies the
existing sparse scale operation. The exact V1 failure is preserved on D:.
