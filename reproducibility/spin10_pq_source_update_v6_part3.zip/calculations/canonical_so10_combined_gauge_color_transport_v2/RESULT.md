# V944 result — full canonical color form of the combined source

The equal stripped-weight sum of the two bubbles and two
mixed triangles equals the canonical gauge-coordinate
variation with U=8 P_H-C_H on the complete color basis.
Both routes compare all 91,125 positions, including the
implied zeros. The combined tensor has 1,888 nonzeros.
Removing either family fails the full comparison.

The formal companion has lower derivative map -U and
transverse metric 2U. Gauge square then requires zero
additional ghost bracket. The same coordinate map leaves
the scalar and ghost drivers unchanged, so their
representation and Jacobi conditions hold algebraically.
The selected ordinary color coefficient is retained.

The first native run reached tensor equality and failed
on sparse dictionary scaling in a negative control.
The failed bytes are preserved on D:. V2 repeats the
same test with the established sparse scale helper.

The actual lower and ordinary coefficients still need
to come from one admissible finite map. The equal weights
used here are a color hypothesis. They have not been
adopted, and no causal or quantum right-hand side has
been assigned by the algebraic fit. Both frozen routes
share the model, software and AI authorship.
