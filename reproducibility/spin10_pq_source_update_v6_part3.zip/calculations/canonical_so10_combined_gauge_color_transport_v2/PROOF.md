# Full canonical color form of the combined contact

Let B be the sum of the V940 two bubble tensors and T
the sum of the two mixed V943 tensors in current order.
The equal stripped-weight comparison uses D=B-i T,
where the factor -i removes the literal i in T.
This is a color normalization convention and does not
assign the physical extension coefficients. The
executable builds both complete tensors from the
literal vertices and compares all 45^3 color positions.

Let C_H=-sum_(h in H) ad_h^2 on the full adjoint and
define U=8 P_H-C_H. The joined structure constants give

    D(b,c) = [U b,c] - U[b,c].

Each displayed contact family is needed for this exact
form in the equal-weight comparison. This is the
homogeneous variation from the canonical field map
B_old=(I+t U)B with the ghost fixed. Its free linear
gauge driver changes by L_B=-U. Then the complete
gauge-square bracket target is

    W(b,c)=D(b,c)+[L_B b,c]-L_B[b,c]=0.

Ghost Jacobi and the scalar representation therefore
require no additional ghost or scalar driver for this
formal coordinate map. The map also requires the
ordinary transverse metric U+U^t=16 P_H-2 C_H. The
complete canonical pullback would induce ordinary
gauge and scalar kinetic couplings beyond that
metric. They must be compared to the same finite map.

The ordinary color witness remains 1/10 in its
current-before-IBP units. Agreement in the full
gauge/source tensor establishes an algebraic
candidate with specified lower driver and metric.
It does not establish that the corresponding
lower/source or ordinary coefficients are supplied
by the actual action, or that the mixed and bubble
normalizations are related in the required way by
the auxiliary field equation. Both routes share the
action, conventions, software and AI authorship.
