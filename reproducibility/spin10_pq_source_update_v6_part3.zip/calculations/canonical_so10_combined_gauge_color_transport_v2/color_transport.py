"""Check all gauge outputs of the selected two-edge contact."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)
seagull = source.seagull


def bubbles(phase):
    _, _, _, f, _, _ = source.owner.inputs(phase)
    folder = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    cubic, quartic = {}, defaultdict(list)
    for g, word, cells in rows:
        ids = [i for i, _ in word]
        if g == 1 and len(ids) == 3 and 0 <= ids[0] < 180 and ids[0] % 4 == 1 and 565 <= ids[1] < 598 and 643 <= ids[2] < 823 and (ids[2]-643) % 4 == 1:
            assert all(not d for _, d in word) and all(p[:2] == [0, 0] for p, _, _ in cells)
            a, u, k = (ids[2]-643)//4, ids[0]//4, ids[1]-553
            z = seagull.unpack([([0, *p], n, d) for p, n, d in cells])
            assert (a, u, k) not in cubic
            cubic[a, u, k] = z
        if g == 2 and len(ids) == 4 and ids[1] < 180 and ids[0] % 4 == ids[1] % 4 == 1 and 565 <= ids[2] < 598 and 610 <= ids[3] < 643:
            assert all(not d for _, d in word) and all(p[:2] == [0, 0] for p, _, _ in cells)
            b, d, c, k = ids[0]//4, ids[1]//4, ids[2]-553, ids[3]-598
            z = seagull.unpack([([0, *p], n, d) for p, n, d in cells])
            quartic[b, k].append((d, c, z*(1+int(b == d))))
            if b != d:
                quartic[d, k].append((b, c, z))
    tensors = []
    for internal in (range(12), range(12,45)):
        D = defaultdict(lambda: sp.S.Zero)
        for (a,u,k),z in cubic.items():
            if u in internal:
                for b,c,value in quartic[u,k]:
                    D[a,b,c] += z*value
        tensors.append(source.owner.clean(D))
    DH, DM = tensors
    assert len(DH) == 1360 and len(DM) == 1830
    assert DH.get((1,30,23),0) == 0 and DM[1,30,23] == sp.Rational(1,10)

    return source.add(DH, DM)


def triangles(phase):
    _, _, _, f, _, _ = source.owner.inputs(phase)
    folder = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    gauge_source, auxiliary = defaultdict(list), defaultdict(list)
    ghost = defaultdict(lambda: sp.S.Zero)
    for g, word, cells in rows:
        if g != 1 or len(word) != 3:
            continue
        (i, di), (j, dj), (k, dk) = word
        if i >= 180 or i % 4 != 1:
            continue
        if j < 180 and 508 <= k < 553:
            assert j % 4 == 1 and not (di or dj or dk)
            z = unpack(cells)
            assert i//4 < 12 <= j//4 and k >= 520 and z == sp.I*dict(f[i//4,j//4])[k-508]
            auxiliary[k-508].extend(((i//4,j//4,z),(j//4,i//4,z)))
        if not 553 <= j < 598:
            continue
        if 643 <= k < 823 and (k-643) % 4 == 1:
            assert not (di or dj or dk)
            gauge_source[i//4,j-553].append(((k-643)//4,unpack(cells)))
        if 598 <= k < 643 and not dj:
            assert (di, dk) in (([1],[]),([],[1]))
            ghost[k-598,i//4,j-553] += unpack(cells)*(1 if dk else -1)
    assert sum(len(z) for z in auxiliary.values()) == 668
    assert sum(len(z) for z in gauge_source.values()) == 1674
    values = []
    for span in (range(12),range(12,45)):
        D = defaultdict(lambda: sp.S.Zero)
        for (k,u,c),z in source.owner.clean(ghost).items():
            if k in span:
                for b,v,l in auxiliary[u]:
                    for a,j in gauge_source[v,k]:
                        D[a,b,c] += z*l*j
        values.append(source.owner.clean(D))
    DH, DM = values
    assert [len(D) for D in values] == [810,1302]
    assert all(not D.get((1,30,23),0) and not D.get((1,23,30),0) for D in values)

    return source.add(DH, DM)


def unpack(cells):
    assert all(p[:2] == [0,0] for p,_,_ in cells)
    return seagull.unpack([([0,*p],n,d) for p,n,d in cells])


def check(phase):
    B = bubbles(phase)
    T = triangles(phase)
    D = source.add(B, T, -sp.I)
    assert len(D) == 1888 and D[1,30,23] == sp.Rational(1,10)
    _, _, _, f, _, _ = source.owner.inputs(phase)
    colors = range(45)
    U = {j: defaultdict(lambda:sp.S.Zero) for j in colors}
    for j in colors:
        if j < 12:
            U[j][j] = 8
        for h in range(12):
            for k,x in f[h,j]:
                for i,y in f[h,k]:
                    U[j][i] += x*y
    U = {j: source.owner.clean(v) for j,v in U.items()}
    assert all(U[j].get(i,0) == U[i].get(j,0) for i in colors for j in colors)
    assert U[23][20] == sp.Rational(1,5)
    expected = {}
    for b in colors:
        for c in colors:
            first = source.bracket(f,U[b],{c:1})
            second = source.on_colors(U,dict(f[b,c]))
            out = source.add(first,second,-1)
            expected.update({(a,b,c):z for a,z in out.items()})
    assert D == expected
    assert B != expected and source.add({},T,-sp.I) != expected
    return {"positions_checked": 45**3, "combined_nonzeros": len(D),
            "source_redefinition":"8 P_H - C_H",
            "lower_linear_map":"-8 P_H + C_H",
            "transverse_metric":"16 P_H - 2 C_H",
            "required_extra_ghost_bracket_is_zero":True,
            "required_extra_scalar_driver_is_zero":True,
            "ordinary_selected_stripped":"1/10"}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
