"""Check the two additional gauge–scalar seagull contact tensors."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import PK, ROOT, run_worker


OWNER = ROOT/"calculations/canonical_so10_gauge_scalar_seagull_residue_v1/seagull_residue.py"
SPEC = importlib.util.spec_from_file_location("seagull_owner",OWNER)
seagull = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(seagull)


def vector():
    return defaultdict(lambda:sp.S.Zero)


def add(*parts):
    out = vector()
    for alpha,v in parts:
        seagull.axpy(out,alpha,v)
    return {i:sp.expand(value) for i,value in out.items() if sp.expand(value)}


def rep(rho,colors,v):
    return add(*((a,seagull.apply(rho[k],v)) for k,a in colors.items()))


def bracket(f,left,right):
    out = vector()
    for a,x in left.items():
        for b,y in right.items():
            for c,z in f.get((a,b),()):
                out[c] += x*y*z
    return {i:sp.expand(value) for i,value in out.items() if sp.expand(value)}


def color_probes(phase):
    role = "primary" if phase == "native" else "replay"
    root = ROOT/"calculations/canonical_so10_physical_current_input_recovery_g1_v1"
    data = seagull.read(root/("native_v2_coefficients.json.gz" if phase == "native" else "replay_v4_coefficients.json.gz"))
    frame = seagull.read(PK/"frozen_a10_physical_reconciliation"/f"full_{role}.json")
    vacuum = {x:sp.sympify(v) for x,_,v in frame["vacuum"]["VEV"]["entries"]}
    rho = {}
    for a,rows in data["rho"]:
        columns = defaultdict(list)
        for i,j,cells in rows:
            columns[j].append((i,seagull.unpack(cells)))
        rho[a] = columns
    f = defaultdict(list)
    for (c,a,b),cells in data["f"]:
        f[a,b].append((c,seagull.unpack(cells)))

    def orbit_op(A,B,x):
        if phase == "native":
            return rep(rho,bracket(f,A,B),x)
        return add((1,rep(rho,A,rep(rho,B,x))),(-1,rep(rho,B,rep(rho,A,x))))

    ordinary = [{b:1} for b in seagull.COLORS] + [{0:1,17:2},{12:2,17:-1}]
    mixed = [({0:1},{17:1}),({1:1},{12:1}),({0:1,1:2},{0:1,17:-2})]
    output = {}
    for name,(start,stop,C) in seagull.BLOCKS.items():
        v = {i:c for i,c in vacuum.items() if start <= i < stop}
        E = {a:seagull.apply(rho[a],v) for a in seagull.COLORS}
        samples = {}
        for idx,B in enumerate(ordinary):
            D = add((-1,rep(rho,B,rep(rho,B,v))))
            S,Q,J,T = (vector() for _ in range(4))
            for a,e in E.items():
                if not e:
                    continue
                aa = {a:1}
                seagull.axpy(S,1,rep(rho,aa,rep(rho,B,rep(rho,B,e))))
                if phase == "native":
                    q = rep(rho,bracket(f,B,bracket(f,B,aa)),e)
                else:
                    q = add((1,rep(rho,B,orbit_op(B,aa,e))),
                            (-1,orbit_op(B,aa,rep(rho,B,e))))
                seagull.axpy(Q,1,q)
                seagull.axpy(J,-1,orbit_op(aa,B,rep(rho,B,e)))
                seagull.axpy(J,-1,rep(rho,B,orbit_op(aa,B,e)))
                seagull.axpy(T,1,rep(rho,aa,rep(rho,B,rep(rho,B,e))))
                seagull.axpy(T,1,rep(rho,B,rep(rho,aa,rep(rho,B,e))))
            assert not add((1,S),(1,J),(-C,D))
            assert not add((1,Q),(1,J),(-8,D))
            assert not add((1,T),(1,J),(-(2*C-4),D))
            if idx in (0,12,17):
                samples[str(idx)] = [str(seagull.dot(v,z)) for z in (D,S,J,Q,T)]
        for A,B in mixed:
            assert not rep(rho,A,v)
            J,T = vector(),vector()
            for a,e in E.items():
                if not e:
                    continue
                aa = {a:1}
                seagull.axpy(J,-1,orbit_op(aa,A,rep(rho,B,e)))
                seagull.axpy(J,-1,rep(rho,B,orbit_op(aa,A,e)))
                seagull.axpy(T,1,rep(rho,aa,rep(rho,B,rep(rho,A,e))))
                seagull.axpy(T,1,rep(rho,B,rep(rho,aa,rep(rho,A,e))))
            assert not add((1,J),(1,T))
        output[name] = samples
    return {"color":output,"ordinary_probes":len(ordinary),"mixed_probes":len(mixed)}


def weights_and_width():
    beta,gamma,delta,C = sp.symbols("beta gamma delta C")
    S,J,T,Q,D = sp.symbols("S J T Q D")
    ordinary = (S+beta*J+gamma*T+delta*Q-C*D).subs({S:C*D-J,T:(2*C-4)*D-J,Q:8*D-J})
    equations = [1+delta,beta-gamma,*sp.Poly(sp.expand(ordinary),D,J).coeffs()]
    solution = sp.solve(equations,(delta,beta,gamma))
    assert all(sp.cancel(solution[k]-v)==0 for k,v in {delta:-1,beta:4/(C-2),gamma:4/(C-2)}.items())
    assert not sp.solve([q.subs(beta,1) for q in equations],(delta,gamma))
    weights = {name:[str(sp.cancel(solution[k].subs(C,cv))) for k in (delta,beta,gamma)]
               for name,(_,_,cv) in seagull.BLOCKS.items()}

    w = sp.symbols("w")
    q = sp.Matrix([1,0,0,0])
    k = sp.Matrix([0,1,0,0])
    line = lambda p:sp.eye(4)+(w-1)*p*p.T/p.dot(p)
    diagonal = (q.T*line(q)*q)[0]
    independent = (q.T*line(k)*q)[0]
    assert diagonal == w and independent == 1
    return {"weights":weights,
            "independent_transfer":{"common_ray":str(diagonal),"transverse_width_zero":str(independent)}}


def check(phase):
    return color_probes(phase) | weights_and_width()


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
