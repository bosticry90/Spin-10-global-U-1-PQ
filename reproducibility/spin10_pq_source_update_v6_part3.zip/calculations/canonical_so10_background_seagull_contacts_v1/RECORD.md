# V923 pre-execution contract

Test two additional ordinary graph contact directions for the V922
background seagull defect. They use the same scalar–auxiliary mixing
and distinct placements of the ordinary derivative. Keep the
V919 scalar potential weight fixed and allow a changed coefficient
on the independent V920 gauge orbit kernel. Test the full
derivative-free seagull for arbitrary ordinary fields and light
external background, rather than fitting only the Cartan witness.

Require the actual port and Lorentz trace derivations, exact joined
f/rho verification with commutator replay, and one linked solution
for each fixed scalar block on all nonunit plateaux. Check whether
a contact at zero width requires division by width or can use the
off-diagonal relative derivative class. Preserve ordinary field
normalization and the unshifted reference. Distinguish this local
contact span from full split or master compatibility. Derivative,
source and marked companions remain open. No scientific promotion.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.
