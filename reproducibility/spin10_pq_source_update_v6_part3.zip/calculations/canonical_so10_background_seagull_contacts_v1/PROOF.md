# Correlated background seagull contact directions

## Two additional graph carriers

Retain the actual scalar–auxiliary mixing M=Lambda E_s x.
Use the same hard chart, ordinary propagators and absolute
flat V869 parent. The new direction Q uses a physical Bxx
vertex with the derivative on the internally contracted scalar.
Its scalar port connects to M, and its B port connects by an
ordinary BB line to an unjetted two-B Hessian G. The other B
port of G connects to M by the mixed line. The derivative
difference at the B,x vertex is balanced, so this is a
different contracted-jet kernel from the V920 derivative
at the two-B gauge vertex.

For the reference G, the quadratic connection term of
the actual Weyl K_A gives the Lorentz trace
-(D-1) sum_mu ad_(A_mu)^2 in the hard chart. For the
physical G, expand the YM quartic to second order in
the two contracted B ports. The term involving the
background commutator times the commutator of the two
test ports drops under the symmetric Lorentz trace.
The other two terms give the same trace with B in place
of A. The Lorentz trace follows from the local
delta-contraction: each direction transverse to an
external component contributes once. No connection
acts as a propagating A port.

The raw common-ray Q contraction involves the longitudinal
ordinary gauge inverse and is proportional to its width.
This does not require using its width-dependent residue as
the finite shift. With independent mixed-edge and ordinary
gauge-edge momenta q and k, its reduced numerator includes
q.[I+(w-1)kk^t/k²].q. At q=k it is proportional to w, but
at orthogonal unit q,k it is one even at w=0. The
balanced relative derivative is nonzero on independent
transfers. The mixed, gauge and scalar edges have
scaling degrees three, two and two, with one differentiated
scalar port. The total degree eight allows a delta contact
on the two-relative-coordinate diagonal. A trace contact
on these fixed contracted slots can use an absolute
width-independent coefficient, with no inverse width.
Use the opposite assignment on the other differentiated
slot of the relative B,x jet and extend total derivatives
by the Action Ward identity. This is a local contact
direction under the balanced scaling and ordinary field
conditions. Any additional identities on the longitudinal
or quadratic normalization still have to be checked.

The new direction T uses the physical B²x² vertex with
an undifferentiated B,x mixed Hessian. Its B connects to
M by the mixed edge, its scalar to the final scalar
two-port vertex F, and the other F scalar connects to M.
The derivative at F is the antisymmetric balanced
difference on its scalar slots. It is supplied by the
physical Bxx or the reference Axx connection vertex.
The reference tensor has the same derivative-difference
Hessian, with external A in place of B. The mixed
momentum and the F scalar derivative difference give
two powers of q with angular trace factor 2/D in the
common Hessian normalization. The kernel is logarithmic,
nonzero and independent of the gauge width. The
distinct ordinary contraction patterns permit separate
local coefficients for Q and T. Both require two
ordinary ports at every vertex and preserve the fixed
linear insertion. Include both orientations in the
normalization of the color basis.

## Color identities and one linked solution

Suppress the common g⁴ xi and loop factors. Work in one
Lorentz component and sum components at the end, since
the trace and paired metrics are diagonal. Write R_a=rho_a,
B_r=rho(B), A_r=rho(A), E_a=R_a v_s, and
D_x=-x^t B_r² v_s, the derivative of the seagull in
direction v_s. Let S and J be the scalar and gauge
orbit tensors of V920 in the same color units. Then

    S(B)=x^t sum_a R_a B_r² E_a,
    J(A,B)=-x^t sum_a {[R_a,A_r],B_r} E_a,
    Q(B)=x^t sum_a [B_r,[B_r,R_a]] E_a,
    T(A,B)=x^t sum_a {R_a,B_r} A_r E_a.

Here braces denote an anticommutator. For Q the two-B
trace supplies the adjoint square of the external
connection in its contracted gauge slots. The remaining
F Hessian pairs that color with the scalar mixing,
giving the double commutator displayed above. For T
the mixed derivative of ||B_r x||²/2 supplies
-(R_a B_r+B_r R_a)x. The balanced F derivative supplies
the other sign in the contact basis. These definitions
normalize the proposed finite directions by their
explicit tensor and fix all signs used below. No
coefficient is determined by a zero-width limit of a
proportional residue.

The double-Casimir identity in the actual representations
is sum_a R_a X R_a=(4-C_s)X for any represented generator X.
Together with sum_a R_a² v_s=-C_s v_s it gives

    S(B)+J(B,B)=C_s D_x,
    Q(B)+J(B,B)=8 D_x,
    T(B,B)+J(B,B)=(2 C_s-4) D_x.

For example, expand the double commutator in Q and apply
the identity to its middle term. In T the term with B_r
to the left is (4-C_s)x^t B_r² v_s. For arbitrary external
A in H, A_r v_s=0. The same identity applied to
[B_r,A_r] gives T(A,B)=-J(A,B), with no need for B in H
or for A and B to commute. Also Q(A)=S(A) since the
seagull derivative on A vanishes. The direct f route
and representation-commutator route check these identities
as complete scalar vectors on actual pure and mixed color
probes.

In the full reference split both new kernels have t²
from the two physical vertices. The G or F reference
replacement has (1-t) and the physical replacement has
t. After factoring the V919 common block normalization
g² xi (2 C_s-8)L_s/C_s, keep S at its fixed unit weight.
Let beta multiply the V920 gauge orbit, gamma multiply
T and delta multiply Q in the above color basis. The
reference and physical conditions are

    A²: (1+delta) S(A) = 0,
    AB: beta J(A,B) + gamma T(A,B) = 0,
    B²: S(B)+beta J(B,B)+gamma T(B,B)+delta Q(B)=C_s D_x.

The first sets delta=-1. Equal beta and gamma cancel the
entire reference mixed tensor. The ordinary equation
then gives beta=gamma=4/(C_s-2). Thus the weights
(delta,beta,gamma) are (-1,1/2,1/2) for Phi and
(-1,8/21,8/21) for Sigma. Retaining beta=1 would
fail the ordinary seagull identity. The solution does
not fit different weights for individual color rows or
switch values. It preserves the full zero-background
derivative-free seagull, and cancels both reference
tensors for arbitrary light A at this degree.

This calculation treats the derivative-free seagull
projection. The extra kernels also act on other
vertices with matching contracted slots. For example
the unjetted BB slot can see a physical scalar seagull
with residual x², and the unjetted B,x slot can see a
derivative on a residual scalar. Changing beta also
changes the V921 derivative comparison. These effects
must be computed before qualifying a common map. The
actual compact master tangent and the quadratic
reference-splitting conditions have not been imposed
on this enlarged candidate. Native and replay share
the action, frame and symbolic arithmetic. No new
loop integration, physical parameters or authority.
