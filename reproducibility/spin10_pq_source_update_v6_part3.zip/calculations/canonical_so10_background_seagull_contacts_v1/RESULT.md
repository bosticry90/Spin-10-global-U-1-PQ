# V923 result

Two additional ordinary contact tensors span the derivative-free
background seagull repair. One uses an unjetted gauge Hessian and
a scalar derivative at the mixed gauge–scalar port. The other
uses a mixed seagull Hessian and a scalar derivative difference
at a two-scalar port. The reference and physical replacements
give the same color tensors with the correct switch factors.

In normalized color units, set the new gauge-Hessian weight to
-1 and the old gauge orbit and new mixed weights both to
4/(C_s-2). This preserves the entire ordinary seagull translation
and cancels both reference A²x and ABx terms for light A and
arbitrary ordinary B. The V919 scalar potential weight stays
fixed. The construction of the gauge contact uses an absolute
local coefficient and does not divide by gauge width.

This solves the derivative-free seagull projection only. The
new kernels have other forced local companions, and the changed
gauge weight alters the V921 derivative comparison. Quadratic
reference agreement and the compact master/source/marked
directions still need verification. Native and replay share
physical inputs and software. No authority change.
