# V875 exact integer serialization

The first worker passed its sign and contact assertions, then exited
while encoding a SymPy Integer in JSON. It wrote no result. Preserve
the complete failure capture and source. Convert the two contacts to
Python integers only after both equal exactly −1. The controls and all
scientific inputs remain identical. The original resource bounds apply.
