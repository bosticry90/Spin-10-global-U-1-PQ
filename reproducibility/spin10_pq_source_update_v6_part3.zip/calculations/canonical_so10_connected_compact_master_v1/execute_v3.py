"""Run the unchanged V875 test with a strictly local serialization fix."""

import json
import sys

from execute import BASE, CONTROL, HERE, PK, ROOT, digest, freeze, git, make_preparation, save


def main():
    assert git("rev-parse", "HEAD").decode().strip() == BASE
    assert not git("diff", "--name-only", "HEAD")
    messages = {"worker": "Object of type Integer is not JSON serializable", "worker_v2": "FileNotFoundError"}
    for phase, message in messages.items():
        for kind in ("preparation", "capture"):
            name = f"{kind}_{phase}.json"
            assert (HERE / name).read_bytes() == (CONTROL / name).read_bytes()
        failed = json.loads((HERE / f"capture_{phase}.json").read_bytes())
        assert not failed["calculation_completed"] and failed["post_run_observations_qualified"]
        assert message in failed["stdout_and_stderr"]
    prep = json.loads((HERE / "preparation_worker_v2.json").read_bytes())
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    freeze(("CONTINUATION_V3.md", "master_v3.py", "execute_v3.py"))
    make_preparation(set(prep["sha256"]), "worker_v3")
    sys.path.insert(0, str(PK))
    from export_a10_e5_antighost_vector import capture

    report = capture([sys.executable, "-B", str(HERE / "master_v3.py")])
    save("capture_worker_v3.json", report)
    print(report["stdout_and_stderr"], end="")
    assert report["calculation_completed"] and report["post_run_observations_qualified"]
    assert sum(path.stat().st_size for path in HERE.iterdir() if path.is_file()) <= 32 * 1024**2


if __name__ == "__main__":
    main()
