# V875 preserve the original owner path

V2's generated source accidentally renamed the V848 input as well as
the intended V875 result. Its worker exited before the checks. Retain
the exact V2 bytes and capture. V3 is generated from the original with
specific replacements for the integer conversion and output filename.
The V848 input and all scientific controls use their original bytes.
