# One odd master insertion in the absolute compact connected functional

## Parent and admitted source derivative

Use the V869 compact P=R_A+sigma(S_A+uU−R_A), fixed full A, first g and
first u in either probe, rho=theta=0. Ordinary coordinates have parity
p_i and antifield/source J_i has parity 1−p_i. Write s_i=(-1)^p_i.
Keep the source-first ordinary coupling integral j_i z_i. Form

    E_i=EL^L_zi P,  F_i=s_i EL^L_Ji P,
    B[P]=integral sum_i F_i E_i.

Use the complete switched Eulers, including the reference and all
switch jets. V868 exhibits a nonzero compact master on a switch patch.
The action direction Z=P+beta B[P] uses a single compact odd LEFT
label. Every B[P] root retains a compact switched source-Euler factor.
V868's local word bound n<=10, with at most one negative beta defect,
and its independent-transfer soft pairing apply. V869 extends this to
the full background by the fixed-flat Born reference and metric frame.
Root a compact beta vertex on the V871 one-cycle and tree decomposition.
COS1's independent difference coordinates and finite jets give the
same extended core times ordered Feynman bridges. Retain the entire
regulated forest when taking UV finite parts and then the joint IR
boundary. These operations are on labeled coefficients. No inverse heat
acts separately on a Schwartz mean or source, and no new independent
coincident products are used.

## Odd Legendre and rooted mean

In the common converted prescription the proper master is

    B[Gamma]=I_B^Gamma := LEFT_beta Gamma[P+beta B[P]] at beta=0.

At tree this is its definition. At one loop it is V868/V869's proper
Q_P F=I_B,1 with F the common loop coefficient. The graded Hessian
tangent has no critical finite defect in that converted map. The raw
paired inverse, Jacobian and covariance terms remain in its derivation.

At the full formal stationary mean EL^L_phi_i Gamma=−s_i j_i and
EL^L_Ji W=EL^L_Ji Gamma. The two terms in the J derivative of the
stationary functional cancel, including their source-first signs.
The product Gamma_Ji j_i has no interchange sign since p_i(1−p_i)=0.
It follows that B[Gamma](phi(j))=−integral sum_i j_i EL^L_Ji W.

The LEFT beta derivative of integral j_i phi_i is integral s_i j_i y_i,
where y_i=LEFT_beta phi_i has parity 1+p_i. The stationary term in
LEFT_beta Gamma is integral y_i Gamma_phi_i, its negative. Consequently

    −integral sum_i j_i EL^L_Ji W
       = LEFT_beta W[P+beta B[P]] at beta=0.

At one loop the right side contains (I_B^Gamma)_1(phi0) and the first
mean correction to B[P](phi0). Equivalently the latter is the beta
derivative through the rooted phi0 in F(phi0). To check the odd sign,
hold j fixed in the tree stationary equation and differentiate with
LEFT beta. The direct Euler term is s_i EL^L_zi B, after pulling out
the LEFT beta. The remainder is the LEFT derivative of E_i[phi0],
with the same slot order. Commuting this odd derivative with the even
strength of the loop correction on the stationary tree value equates
the two mean contributions. This proof needs no unsigned transpose of
the ghost Hessian. The finite odd fixture has both mean derivatives
equal and nonzero, and the unsigned direct Euler would reverse one.

In causal coordinates keep D(P)=C_fin(P)+b(P) on Z before differentiating
or sewing. Its beta derivative has the direct C_fin'[B]+b(B) and the
rooted chain term from phi0[Z,j]. The free absolute factor and all
background and source dependent vacuum coefficients have the V871
normalization. If D_root is the rooted difference of the corrected
and raw causal coefficients, the raw connected Ward residual through
one loop is hbar times (integral sum j_i EL_Ji^L D_root+LEFT_beta D_root).
This difference relation neither sets raw breakings zero nor identifies
the fixed-t CWT paired regulator problem with the compact converted map.

## Two actual switch grades in the light antighost-source slot

Restrict this control only to g0, first H probe, A=0 and light source
J=J_a0 with one ordinary odd j_a0. In the original Minkowski chart
the S cross is −Lambda J, the U square has +J^2 and its mixed source
coefficient is 2Lz J, where Lz=div B−w Lambda/2. The two even ordered
Feynman reference contacts are L G e_Lambda=−delta and its formal
transpose e_Lambda^t G L^t=−delta. In the first two switch grades
the actual connected W0,JJ is +2 chi and −4 chi². The first is the
direct central seagull. The second uses a +Lambda mean response to
sigma J from the sign of the unprobed cross and the two ordered bridge
orientations. Both switch factors are spent by the source vertices.

For the master-side calculation use F_a=−P_J=
sigma Lambda−2u sigma(Lz+J). At first u and first switch degree its
ordered J coefficient is −2 chi. The actual E_R,a is K_aC C. Source-first
j_a gives C=+G_Ca j_a. Thus E_R,a=j_a at this grade. In a direct Wick
calculation the beta-root coefficient has the same sign. Moving j_a
through the C in the ordered two-vertex product gives a minus, and the
W prefactor and single i G contraction give the stationary minus. The
reverse order uses the opposite ghost kernel. These signs reproduce
the stationary contact independently of the connected Legendre formula.

At the second switch degree the selected literal ghost density is
−partial C partial a, while R0 is (C Box a−a Box C)/2. The difference
is −Box(C a)/2 in C-before-a order. Hence the switched LEFT a,C
Euler has V=+Box chi/2. The tree inverse has the first change
−G0 V G0. In E_a the +V G0 term and −K0 G0 V G0 term cancel. Dropping
one term retains the nonzero switch jet. The opposite ordered Euler
and inverse obey the same contact with the odd signs reversed.

For the even mean write z^(0)=G_sigma e_Lambda sigma J and
z^(1)=−2G_sigma L^t sigma(Lz^(0)+J) at first u. Through the needed
switch grade Lz^(0)=−sigma J and Lambda^(1)=+2 sigma J. Thus at order
u J the direct F_a seagull has −2 chi, and −2 sigma Lz^(0) plus
sigma Lambda^(1) give +2 chi² each. E_a=j_a including the switched
contact. This gives the beta-root coefficients −2 chi and +4 chi²
on independent compact J,j_a slots. They match −j_a W_J from the
source-first operator. Removing either even bridge loses a +2 chi².
This control does not infer the full broken M polynomial is a square.

The proof and checks share the classical action, reference, causal
sewing prescription and AI authorship. The conclusion is limited to
one odd compact insertion in the selected absolute one-loop family.
Higher marked derivatives, raw fixed-heat paired comparison, general
relative products, measure/phase and full E5/A5 remain open.
