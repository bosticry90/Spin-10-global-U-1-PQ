"""Focused actual source/ghost checks for the selected connected master."""

import gzip
import json
import os
import threading
from pathlib import Path

import sympy as sp


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CALC = ROOT / "calculations"
V848 = CALC / "canonical_so10_augmented_metric_lift_v1"
V865 = CALC / "canonical_so10_joint_common_family_applicability_v1"
V871 = CALC / "canonical_so10_compact_retained_source_functional_v1"


def read(path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == ".gz" else data)


def left_sign(odd_word, coordinate):
    return (-1) ** odd_word.index(coordinate)


def actual_source(roles):
    art = {row["case"]: row["artifact"]["file"] for row in read(V848 / "result_v2.json")["cases"]}
    values = []
    for role in roles:
        u = read(V848 / art[f"{role}_U0_H"])["input_polynomial_Minkowski"]
        a = read(V848 / art[f"{role}_current_parent_g0"])["input_polynomial_Minkowski"]
        h = [row for row in u if any(n == 1241 for n, _ in row[0])]
        cross = [row for row in a if any(n == 1241 for n, _ in row[0])]
        assert cross == [[[[508, []], [1241, []]], [[[0, 0, 0, 0], -1, 1]]]]
        assert h[:4] == [[[[mu, [mu]], [1241, []]], [[[0, 0, 0, 0], 2 * s, 1]]]
                         for mu, s in enumerate((1, -1, -1, -1))]
        assert h[4:] == [[[[508, []], [1241, []]], [[[0, 0, 1, 0], -1, 1]]],
                         [[[1241, []], [1241, []]], [[[0, 0, 0, 0], 1, 1]]]]
        z = read(V865 / f"{role}_complete_full_background_extension.json.gz")
        h_full = next(row["complete_U"] for row in z["probes"] if row["probe"] == "H")
        parity = z["joined_parities"]
        assert [parity[n] for n in (553, 598, 1241)] == [1, 1, 0]
        assert not any(g == 0 and any(parity[n] for n, _ in w) for g, w, _ in h_full)
        gh = [row for row in z["complete_S_GF_source"] if row[0] == 0 and any(n == 598 for n, _ in row[1])]
        assert gh == [[0, [[553, [mu]], [598, [mu]]], [[[0, 0, 0], -1, 1]]] for mu in range(4)]
        values.append({"H_source_rows_Minkowski": h, "base_source_row_Minkowski": cross,
                       "literal_ghost_rows_Euclidean": gh})
    assert all(packet == values[0] for packet in values)
    return values[0]


def source_tree(rows):
    h = rows["H_source_rows_Minkowski"]
    b = rows["base_source_row_Minkowski"][0][1][0][1]
    u_square = h[-1][1][0][1]
    u_cross = h[0][1][0][1]
    p = sp.Matrix(sp.symbols("p0:4"))
    eta = sp.diag(*(h[mu][1][0][1] // u_cross for mu in range(4)))
    P = (p.T * eta * p)[0]
    L_B = sp.I * p.T * eta
    G_Bb, G_bB = sp.I * p / P, -sp.I * p.T / P
    contact = sp.cancel((L_B * G_Bb)[0])
    dual = sp.cancel((G_bB * -L_B.T)[0])
    assert contact == dual == -1
    contact, dual = int(contact), int(dual)

    # Schur derivative and beta-root stationary response use distinct
    # placements of the two source/ordinary derivatives.
    proper_to_connected = [2 * u_square, -b * u_cross * (contact + dual)]
    L_phi0 = -b * contact
    Lambda_phi1 = -u_cross * dual
    terms = [-u_cross * L_phi0, -b * Lambda_phi1]
    beta_root = [-2 * u_square, sum(terms)]
    assert proper_to_connected == [2, -4] and beta_root == [-2, 4]
    old = read(V871 / "result_b.json")["checks"]["tree_bridges"][0]
    assert proper_to_connected == [-old[f"W_tree_s{i}"] for i in (1, 2)]
    assert terms == [2, 2] and sum(terms[1:]) != beta_root[1]
    # Source-first j_a gives an odd crossing, and a single Feynman bridge
    # gives the stationary minus. Their product preserves the root sign.
    wick = left_sign(("C", "j_a"), "j_a") * -1 * beta_root[0]
    assert wick == beta_root[0]
    return {"W_JJ_switch_grades": proper_to_connected, "beta_J_j_switch_grades": beta_root,
            "two_ordered_bridge_terms": terms, "drop_one_bridge": 2,
            "first_switch_direct_Wick": wick}


def ghost_switch():
    P, V = sp.symbols("P V", commutative=False)
    s = sp.Symbol("s")
    one_bridge = 1 / P
    # LEFT a Euler on -Box(chi) C a/2 supplies +Box(chi) C/2.
    jet = -sp.Rational(1, 2) * left_sign(("C", "a"), "a")
    assert jet == sp.Rational(1, 2)
    K, G = P + s * V, one_bridge - s * one_bridge * V * one_bridge
    left = sp.expand(K * G)
    right = sp.expand((-G) * (-K))
    assert left.coeff(s, 0) == right.coeff(s, 0) == 1
    assert left.coeff(s, 1) == right.coeff(s, 1) == 0
    assert sp.expand(K * one_bridge).coeff(s, 1) == V / P
    assert sp.expand(P * G).coeff(s, 1) == -V / P
    return {"LEFT_a_coefficient_over_Box_chi": str(jet), "both_ordered_contacts": 1,
            "first_switch_residual": 0, "missing_dressed_inverse_residual": str(V / P),
            "missing_literal_jet_residual": str(-V / P)}


def odd_mean():
    mu = sp.Symbol("mu", positive=True)
    # P=m*x^2/2+mu*C*a, B=x*C and F=x*a*theta at x0=1.
    a_beta = -left_sign(("beta", "C"), "C") / mu
    C_loop = left_sign(("a", "theta"), "a") / mu
    ordered = left_sign(("beta", "j_a"), "beta") * left_sign(("j_a",), "j_a")
    reversed_order = left_sign(("beta", "j_a"), "j_a") * left_sign(("beta",), "beta")
    assert a_beta == C_loop == 1 / mu and ordered == -reversed_order == 1
    return {"rooted_F_beta_over_theta": str(a_beta), "B_on_loop_mean_over_theta": str(C_loop),
            "wrong_unsigned_rooted_F_beta_over_theta": str(-a_beta),
            "beta_then_j": ordered, "j_then_beta": reversed_order}


def controls(roles):
    rows = actual_source(roles)
    return {"actual_rows": rows, "tree": source_tree(rows), "ghost_switch": ghost_switch(), "odd_mean": odd_mean()}


def main():
    timer = threading.Timer(120, lambda: os._exit(124))
    timer.daemon = True
    timer.start()
    payload = {"execution_state": "COMPLETED", "scientific_acceptance": "NOT_PERFORMED",
               "checks": controls(("native",))}
    data = (json.dumps(payload, sort_keys=True) + "\n").encode()
    name = "result_v2.json" if len(data) <= 8 * 1024**2 else "result_v2.COMPLETE_OVERFLOW_NOTPASS"
    with (HERE / name).open("xb") as stream:
        stream.write(data)
    assert name == "result_v2.json"
    timer.cancel()
    print("STAGE actual two switch grades, ordered ghost jet and odd mean checked", flush=True)


if __name__ == "__main__":
    main()
