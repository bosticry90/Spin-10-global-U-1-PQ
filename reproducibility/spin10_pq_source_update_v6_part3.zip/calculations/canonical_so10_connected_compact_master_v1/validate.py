"""Replay the V875 owner data and verify exact retained evidence."""

import json
import os
import subprocess
import sys
import threading
import time

from execute import BASE, CONTROL, HERE, NAV, ROOT, digest, git, save
from master_v3 import controls, read


def main():
    started = time.perf_counter()
    timer = threading.Timer(180, lambda: os._exit(124))
    timer.daemon = True
    timer.start()
    prep = read(HERE / "preparation_validation.json")
    assert prep["base_HEAD"] == BASE == git("rev-parse", "HEAD").decode().strip()
    assert git("ls-tree", "-r", "HEAD") == (CONTROL / "old_git_tree.txt").read_bytes()
    assert not git("diff", "--cached", "--name-only")
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    failures = {"worker": "Object of type Integer is not JSON serializable", "worker_v2": "FileNotFoundError"}
    for phase in ("worker", "worker_v2", "worker_v3"):
        for kind in ("preparation", "capture"):
            name = f"{kind}_{phase}.json"
            assert (HERE / name).read_bytes() == (CONTROL / name).read_bytes()
        run = read(HERE / f"capture_{phase}.json")
        assert run["calculation_completed"] == (phase == "worker_v3") and run["post_run_observations_qualified"]
        if phase in failures:
            assert failures[phase] in run["stdout_and_stderr"]
    for source in HERE.glob("*.source.txt"):
        assert source.read_bytes() == (HERE / source.name.removesuffix(".source.txt")).read_bytes()
    for name in prep["owner_receipts"]:
        assert read(ROOT / name)["execution_state"] == "COMPLETED", name

    result = read(HERE / "result_v3.json")
    assert result["execution_state"] == "COMPLETED"
    checks = result["checks"]
    assert checks == controls(("replay",))
    tree = checks["tree"]
    assert tree["W_JJ_switch_grades"] == [2, -4]
    assert tree["beta_J_j_switch_grades"] == [-2, 4]
    assert tree["two_ordered_bridge_terms"] == [2, 2]
    assert checks["ghost_switch"]["missing_dressed_inverse_residual"] == "V*P**(-1)"
    assert checks["ghost_switch"]["missing_literal_jet_residual"] == "-V*P**(-1)"
    assert checks["odd_mean"] == {"B_on_loop_mean_over_theta": "1/mu", "beta_then_j": 1,
                                   "j_then_beta": -1, "rooted_F_beta_over_theta": "1/mu",
                                   "wrong_unsigned_rooted_F_beta_over_theta": "-1/mu"}
    print("STAGE replay owner rows and odd master controls checked", flush=True)

    proc = subprocess.run([sys.executable, "-B", "tools/research_check.py", "e4", "--historical-context",
                           "D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4"], cwd=ROOT,
                          capture_output=True, text=True, encoding="utf-8", timeout=120)
    save("e4_capture.json", {"exit_code": proc.returncode, "stdout": proc.stdout, "stderr": proc.stderr})
    events = [json.loads(line) for line in proc.stdout.splitlines() if line.strip()]
    steps = [event for event in events if event.get("event") == "step_finished"]
    exits = [event["exit_code"] for event in steps]
    assert proc.returncode == 0 and exits == [0, 0, 0, 0, 0, 2]
    custody = next(event for event in steps if event["step"] == "historical_custody")
    assert custody["stdout"].count("RECORDED_DIGEST_UNRESOLVED:") == 7
    historic = git("show", "ef70f255a667b9a81e37b344dc78967ada4ed896:README.md")
    assert (ROOT / "README.md").read_bytes().replace(b"\r\n", b"\n").endswith(historic)
    state = digest(ROOT / "project_state.json")
    assert state == "d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8"
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    paths = [p for p in HERE.iterdir() if p.is_file()]
    assert sum(path.stat().st_size for path in paths) <= 32 * 1024**2
    paths.extend(ROOT / n for n in NAV)
    save("validation_receipt.json", {
        "base_HEAD": BASE, "evidence_validation": "PASS_SELECTED_ABSOLUTE_COMPACT_CONNECTED_W3",
        "execution_state": "COMPLETED", "scientific_acceptance": "NOT_PERFORMED",
        "state_sha256": state, "owner_receipts": prep["owner_receipts"],
        "replay_source_rows_match": True, "checks": checks, "E4_step_exits": exits,
        "historical_custody": "SEVEN_UNRESOLVED_NOTPASS",
        "files_excluding_pending_receipt_capture": {path.relative_to(ROOT).as_posix(): digest(path) for path in paths},
        "elapsed_after_imports": time.perf_counter() - started,
    })
    timer.cancel()


if __name__ == "__main__":
    main()
