"""Freeze and run the V875 serialization-only continuation."""

import json
import sys

from execute import BASE, CONTROL, HERE, PK, ROOT, digest, freeze, git, make_preparation, save


def main():
    assert git("rev-parse", "HEAD").decode().strip() == BASE
    assert not git("diff", "--name-only", "HEAD")
    for name in ("preparation_worker.json", "capture_worker.json"):
        assert (HERE / name).read_bytes() == (CONTROL / name).read_bytes()
    first = json.loads((HERE / "capture_worker.json").read_bytes())
    assert not first["calculation_completed"] and first["post_run_observations_qualified"]
    assert "Object of type Integer is not JSON serializable" in first["stdout_and_stderr"]
    prep = json.loads((HERE / "preparation_worker.json").read_bytes())
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    freeze(("CONTINUATION_V2.md", "master_v2.py", "execute_v2.py"))
    make_preparation(set(prep["sha256"]), "worker_v2")
    sys.path.insert(0, str(PK))
    from export_a10_e5_antighost_vector import capture

    report = capture([sys.executable, "-B", str(HERE / "master_v2.py")])
    save("capture_worker_v2.json", report)
    print(report["stdout_and_stderr"], end="")
    assert report["calculation_completed"] and report["post_run_observations_qualified"]
    assert sum(path.stat().st_size for path in HERE.iterdir() if path.is_file()) <= 32 * 1024**2


if __name__ == "__main__":
    main()
