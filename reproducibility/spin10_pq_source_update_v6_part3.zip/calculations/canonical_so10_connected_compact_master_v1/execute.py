"""Freeze V875 evidence before the worker and before separate review."""

import ast
import json
import subprocess
import sys
from hashlib import sha256
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CONTROL = Path("D:/Codex-Research/ToE-Next/research-control-records/connected-compact-master-v1-2026-11-08")
PK = ROOT / "tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1"
BASE = "4d1e24508571cb53802c1176acd1bd45052c7ebb"
NAV = ["README.md", "docs/COMMON_RESTORATION_CAMPAIGN_V1.md", "docs/RESEARCH_EXECUTION_HANDOFF_V875.md"]


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def save(name, value):
    data = (json.dumps(value, sort_keys=True) + "\n").encode()
    for folder in (HERE, CONTROL):
        with (folder / name).open("xb") as f:
            f.write(data)


def freeze(names):
    for name in names:
        raw = (HERE / name).read_bytes()
        if name.endswith(".py"):
            ast.parse(raw)
        with (HERE / (name + ".source.txt")).open("xb") as f:
            f.write(raw)


def make_preparation(names, phase):
    names.update(path.relative_to(ROOT).as_posix() for path in HERE.iterdir() if path.is_file())
    save(f"preparation_{phase}.json", {
        "base_HEAD": BASE, "sha256": {name: digest(ROOT / name) for name in sorted(names)},
        "owner_receipts": sorted(name for name in names if "validation_receipt" in name and name.endswith(".json")),
        "limits": {"seconds": 120 if phase == "worker" else 180, "sampled_private_bytes": 8 * 1024**3,
                   "minimum_available_commit_bytes": 350 * 1024**2, "artifact_bytes": 8 * 1024**2, "packet_bytes": 32 * 1024**2},
        "scientific_acceptance": "NOT_PERFORMED",
    })


def worker():
    assert not git("diff", "--name-only", "HEAD")
    CONTROL.mkdir(exist_ok=False)
    with (CONTROL / "old_git_tree.txt").open("xb") as f:
        f.write(git("ls-tree", "-r", "HEAD"))
    freeze(("RECORD.md", "PROOF.md", "master.py", "execute.py"))
    owners = {
        "augmented_metric_lift_v1": ("PROOF.md", "validation_receipt.json", "result.json", "tensor_2.json.gz", "tensor_6.json.gz", "tensor_7.json.gz"),
        "joint_common_family_applicability_v1": ("PROOF.md", "validation_receipt.json", "native_complete_full_background_extension.json.gz", "replay_complete_full_background_extension.json.gz"),
        "compact_switched_master_domain_v1": ("PROOF.md", "validation_receipt.json"),
        "current_background_reference_bridge_v1": ("PROOF.md", "validation_receipt.json"),
        "compact_retained_source_functional_v1": ("PROOF.md", "result_b.json", "validation_receipt.json"),
        "connected_fixed_background_ward_v1": ("PROOF.md", "validation_receipt.json"),
        "causal_one_loop_sewing": ("DERIVATION.md", "validation_receipt.json"),
        "causal_wick_bridge": ("DERIVATION.md", "validation_receipt.json"),
        "graded_causal_qap": ("DERIVATION.md", "validation_receipt_v2.json"),
        "free_causal_reference": ("DERIVATION.md", "validation_receipt_v3.json"),
        "connected_ward_transport": ("RESULT.md",),
    }
    names = {"AGENTS.md", "CHARTER.md", "project_state.json", "docs/RESEARCH_EXECUTION_HANDOFF_V874.md"}
    names.update((PK / name).relative_to(ROOT).as_posix() for name in ("A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md", "export_a10_e5_antighost_vector.py"))
    for owner, paths in owners.items():
        names.update(f"calculations/canonical_so10_{owner}/{path}" for path in paths)
    make_preparation(names, "worker")


def review():
    assert set(git("diff", "--name-only", "HEAD").decode().splitlines()) == set(NAV[:2])
    for name, backup in zip(NAV[:2], ("README_before_final.bytes", "campaign_before_final.bytes")):
        assert (CONTROL / backup).read_bytes().replace(b"\r\n", b"\n") == git("show", "HEAD:" + name)
    worker_prep = json.loads((HERE / "preparation_worker.json").read_bytes())
    for name, expected in worker_prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    freeze(("RESULT.md", "validate.py"))
    make_preparation(set(worker_prep["sha256"]) | set(NAV) | {"docs/LOCAL_RESEARCH_CONVENTIONS_V1.md"}, "validation")


def main():
    assert git("rev-parse", "HEAD").decode().strip() == BASE
    assert not git("diff", "--cached", "--name-only")
    phase = sys.argv[1]
    if phase == "worker":
        worker()
        command = "master.py"
    else:
        assert phase == "validation"
        review()
        command = "validate.py"
    sys.path.insert(0, str(PK))
    from export_a10_e5_antighost_vector import capture

    report = capture([sys.executable, "-B", str(HERE / command)])
    save(f"capture_{phase}.json", report)
    print(report["stdout_and_stderr"], end="")
    assert report["calculation_completed"] and report["post_run_observations_qualified"]
    assert sum(path.stat().st_size for path in HERE.iterdir() if path.is_file()) <= 32 * 1024**2


if __name__ == "__main__":
    main()
