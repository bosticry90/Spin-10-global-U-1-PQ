# Broken-singlet finite scalar block restriction

Take ghost color e12 in V963. Its H Casimir and both
mixed triangle maps vanish. The lower gauge-source
coefficient is 8 g_MM, and the V951 linked scalar
coefficient is 8 b_M in each active block. Both
exports give a nonzero e12 generator in Phi, Sigma
and ordinary phi. The PQ singlet is outside this test.

Choose exterior scalar momenta zero and p and ghost
momentum -p, with P=p^2>0. The ordinary transverse
Bxx endpoint kills its zero-momentum scalar placement.
The retained seagull-cubic term has the same transfer P
as the quadratic variation in which the scalar driver
acts on the zero-momentum scalar. The stripped linked
two-edge weight is the V952 W(P,M) on this slice, with
M the positive squared scalar reference mass.

The candidate V964 shift is zero at length four.
Any further common shift or the common ghost value
cancels between scalar blocks. Their difference is

    W(P,M1)-W(P,M2)
      = -3/(32 pi^2) integral_0^1 x log((M1+xP)/(M2+xP)) dx.

For M1>M2>0 it is strictly negative. Its P derivative
is strictly positive and is

    3(M1-M2)/(32 pi^2)
       integral_0^1 x^2 / [(M1+xP)(M2+xP)] dx.

At P=0 the difference is -3 log(M1/M2)/(64 pi^2).
No soft ghost value is needed. Distinct positive
squared reference masses cannot satisfy the selected
equality with one common weight. A block-dependent
constant could match one anchor, while this difference
varies with P. Equal reference masses remove this
contrast and leave the common scalar/ghost condition.

Both inverse exports use distinct symbolic masses.
No numerical inequality or physical mass is assumed.
The result leaves additional action and source
terms and fixed-total-parent mass compensation
separate. Both routes share the model and software.
