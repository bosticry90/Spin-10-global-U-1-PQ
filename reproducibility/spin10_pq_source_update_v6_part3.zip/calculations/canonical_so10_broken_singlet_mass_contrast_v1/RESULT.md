# V966 · Broken-singlet mass contrast

The selected unit-switch broken-singlet equation requires
the same finite scalar bubble value in Phi, Sigma and
ordinary phi. The common ghost value cancels when two
blocks are compared. At fixed reference their difference
is nonzero for distinct positive squared masses and varies
with the momentum transfer. The V964 candidate common
length shift leaves this two-edge difference intact.

Both actual inverse exports retain symbolic masses. The
result excludes a common finite value for distinct
positive inputs in this selected class. Equal reference
masses remove the block contrast and leave a separate
scalar/ghost comparison. The complete fixed-parent
transport and other quantum terms are outside the test.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
