# V966 pre-execution contract

Freeze the V963 broken-singlet equation, V964 candidate
common log-core shift, V952 massive two-edge expression
and both V791 free inverse exports. Compare the three
active scalar blocks against their shared ghost weight
at unit switch. Test the exact mass and transfer signs.
Keep the actual reference masses symbolic, with other
quantum contributions and mass compensation open.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority change.
