"""Test the broken-singlet scalar mass contrast at fixed reference."""

import gzip
import importlib.util
import json
import sys

import mpmath as mp
import sympy as sp

from execute import ROOT, run_worker


def references(phase):
    name = "native" if phase == "native" else "replay"
    folder = ROOT / "calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1"
    with gzip.open(folder / f"{name}_inverse.json.gz") as stream:
        diag = {a: z for a,b,z in json.load(stream)["Greference"] if a == b}
    q = tuple(sp.symbols("q0:4"))
    Q = sum(x**2 for x in q)
    blocks = ((0,54,"Phi"),(54,306,"Sigma"),(306,326,"phi"))
    masses = []
    for lo, hi, label in blocks:
        M = sp.Symbol(f"Mref_{label}_squared")
        assert all(sp.sympify(diag[a+180]) == 1/(Q+M) for a in range(lo,hi))
        masses.append(str(M))

    path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
    spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
    source = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(source)
    _, entries, _, f, _, _ = source.owner.inputs(phase)
    assert all(not f[h,12] for h in range(12))
    for lo, hi, _ in blocks:
        assert any(lo <= i < hi and lo <= j < hi for i,j in entries[12])
    assert all(max(i,j) < 326 for i,j in entries[12])
    return masses


def contrasts():
    x, P, M, delta = sp.symbols("x P M delta", positive=True)
    log_ratio = x*sp.log((M+delta+x*P)/(M+x*P))
    relative = -log_ratio
    derivative = delta*x**2/((M+x*P)*(M+delta+x*P))
    assert sp.factor(sp.diff(relative,P)-derivative) == 0
    soft = sp.integrate(relative.subs(P,0),(x,0,1))
    assert sp.simplify(soft+sp.log((M+delta)/M)/2) == 0
    with mp.workdps(42):
        def numerical(p, m1, m2):
            return mp.quad(lambda x: -x*mp.log((m1+x*p)/(m2+x*p)), [0,1])
        for m1,m2 in ((2,1),(7,3),(11,1)):
            values = [numerical(p,m1,m2) for p in (0,1,3)]
            assert values[0] < values[1] < values[2] < 0
            assert abs(values[0]+mp.log(mp.mpf(m1)/m2)/2) < mp.mpf("1e-40")
            assert abs(numerical(1,m2,m1)+values[1]) < mp.mpf("1e-40")
        assert numerical(1,2,2) == 0


def check(phase):
    masses = references(phase)
    contrasts()
    return {"reference_mass_symbols":masses, "three_scalar_e12_generators":True,
            "relative_mass_contrast_nonzero_for_distinct_positive_masses":True,
            "relative_weight_transfer_dependent":True,
            "positive_mass_controls":3}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
