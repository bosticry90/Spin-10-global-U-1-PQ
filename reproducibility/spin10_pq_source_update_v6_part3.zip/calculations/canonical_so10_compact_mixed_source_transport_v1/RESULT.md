# V946 result — compact switch and mixed-line source transport

The lower contact has an exact compact source companion
8 sigma (partial sigma) J_B.C per unit stripped weight.
The derivative on the F switch is independent until
the switches are identified. A B-only point map leaves
this source term missing. A formal local ghost rescale
and opposite coupling spurion reproduce the selected
lower source and preserve the scalar and ghost drivers.
Their ordinary and marked consequences remain open.

The V943 mixed-line derivative separates into a
partial-diagonal collapse and two exterior-derivative
terms. The complete V791 inverse reproduces both
mixed divergence signs in all colors. Its finite
profile gives a smeared delta. At the unregulated
full diagonal the collapsed triangle carries
sigma^3, while the bubble carries sigma^2. Unit
agreement therefore does not establish compact
agreement under the common prescription.

Next compare the mixed-line regulator removal with
the coalesced two-edge distribution. Track the
absolute finite constant separately from a common
subtraction shift, and preserve the exterior
derivative terms. No local coupling or finite
normalization has been adopted. Both routes share
action, conventions, software and authorship.
