# Compact switch companions of the lower source and mixed triangle

In the V945 contact keep the two vertex switches s_J and
s_F until the total derivative is transferred. The
internal derivative hits s_F C, while the derivative
already on the external ghost hits C only. With the
common stripped unit weight, the internal contribution
is minus the sum of d_a over all sectors, or 8 I. The
external derivative gives the rest of L_B. Thus the
literal contact is

    s_J s_F J_B . (8 P_M+C_H) partial C
    + 8 s_J (partial s_F) J_B . C.

For a common switch sigma this retains a sigma partial
sigma term. A pointwise gauge field change alone, with
ghost and coupling fixed, cannot give it in the source
part because J_B acts on partial C without a derivative
on the gauge-coordinate map.

One formal source parametrization uses first-order t,
U=8 P_H-C_H, B_old=(I+t sigma U)B, C_old=(1+8t sigma)C
and the opposite coupling spurion g_old=g(1-8t sigma).
Use the evaluation-dual source maps. The lower J_B
coefficient is sigma^2(8 I-U) partial C plus
8 sigma(partial sigma) C. The product g_old C_old has
zero first-order change and preserves the selected
homogeneous scalar source. The quadratic ghost driver
also stays fixed after its source dual. The upper
J_B homogeneous source changes by sigma^2 times the
V944 gauge-coordinate tensor. This is a formal
parameter derivative of the displayed source
polynomial. A local coupling insertion is neither
adopted nor justified here. Its ordinary, background
and marked terms remain separate.

For the mixed triangle let y be the F vertex, z the
BB Lambda vertex and x the J_B vertex. With external
C and switch at y, the F derivative placements give
F_a s_F C L . partial Delta, F_B s_F C div L Delta,
and F_C s_F partial C . L Delta. Here L is the mixed
line, Delta the ghost line and the unchanged ordinary
BB line is independent of y. Integration by parts at y
leaves

    (F_B-F_a) s_F C div L Delta
    - F_a (partial s_F) C . L Delta
    + (F_C-F_a) s_F partial C . L Delta.

The product rule is exact on the separated
distributions. The undifferentiated primitive has
short-distance degree seven in eight relative
dimensions. The two terms with exterior derivatives
therefore have no new full-diagonal extension
constant under the same scaling bound once the
proper partial diagonals are fixed.

The literal free mixed Green gives q dot G_BLambda=-1
and q dot G_LambdaB=+1. With the finite scalar
profile those values acquire E_profile f_profile.
The unregulated first divergence in the Fourier
endpoint convention is therefore -i delta and the
second is +i delta. The finite mixed line instead
gives the corresponding smeared delta. The
unregulated collapse identifies y and z. At the
full local diagonal the three switches remain,
giving sigma^3 instead of the bubble sigma^2.
Consequently the unit equality does not determine
the compact equality. The product with the
coincident bubble still needs its total-diagonal
normalization and the regulator removal comparison.
Both frozen routes share model, conventions,
software and authorship.
