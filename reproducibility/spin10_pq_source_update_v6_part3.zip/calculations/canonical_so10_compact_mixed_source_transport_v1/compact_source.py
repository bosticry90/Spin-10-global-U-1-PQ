"""Reconstruct the lower gauge source map with all literal derivatives."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)
seagull = source.seagull


def check(phase):
    _, _, _, f, _, _ = source.owner.inputs(phase)
    folder = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    J, F = defaultdict(list), {}
    for g, word, cells in rows:
        if g != 1 or len(word) != 3:
            continue
        (b,db), (c,dc), (a,da) = word
        if b >= 180 or b%4 != 1 or not 553 <= c < 598:
            continue
        if 643 <= a < 823 and (a-643)%4 == 1:
            assert not(db or dc or da)
            J[b//4,c-553].append(((a-643)//4,unpack(cells)))
        if 598 <= a < 643:
            assert sum(bool(d) for d in (db,dc,da)) == 1 and all(d in ([],[1]) for d in (db,dc,da))
            derivative = "B" if db else "C" if dc else "a"
            key = b//4,a-598,c-553,derivative
            assert key not in F
            F[key] = unpack(cells)
    assert sum(map(len,J.values())) == 1674
    assert {d:sum(k[3]==d for k in F) for d in ("B","C","a")} == {"B":334,"C":668,"a":1674}
    actual = defaultdict(lambda: defaultdict(lambda:sp.S.Zero))
    for (b,k,c,d),z in F.items():
        sector = ("H" if b < 12 else "M")+("H" if k < 12 else "M")
        for a,j in J[b,k]:
            actual[sector,d][a,c] += z*j
    actual = {key:source.owner.clean(v) for key,v in actual.items()}

    C = defaultdict(lambda:sp.S.Zero)
    for h in range(12):
        for j in range(45):
            for k,x in f[h,j]:
                for i,y in f[h,k]:
                    C[i,j] -= x*y
    C = source.owner.clean(C)
    Ch = {(i,j):z for (i,j),z in C.items() if i < 12 and j < 12}
    Cm = {(i,j):z for (i,j),z in C.items() if i >= 12 and j >= 12}
    assert source.add(Ch,Cm) == C
    Ph = {(i,i):sp.S.One for i in range(12)}
    Pm = {(i,i):sp.S.One for i in range(12,45)}
    I = source.add(Ph,Pm)
    negative = lambda A: source.add({},A,-1)
    MM_B = source.add(Ch,Ph,-8)
    MM_a = source.add(source.add(Ch,Cm,2),I,-8)
    expected = {("HH","a"):negative(Ch),("HM","a"):negative(Cm),
                ("MH","a"):negative(Cm),("MM","a"):MM_a,
                ("MM","B"):MM_B,("MM","C"):MM_B,("HM","C"):Cm}
    assert actual == expected
    compact = {}
    for sector in ("HH","HM","MH","MM"):
        compact = source.add(compact,actual.get((sector,"a"),{}),-1)
    assert compact == source.add({},I,8)
    lower = compact
    for sector in ("HH","HM","MH","MM"):
        lower = source.add(lower,actual.get((sector,"C"),{}))
    U = source.add(source.add({},Ph,8),C,-1)
    assert lower == source.add(compact,U,-1)

    # Point B transport has no derivative of the switch in the source.
    # A scalar ghost transport with the opposite coupling spurion does.
    t, sigma, ds, c, dc, u = sp.symbols("t sigma ds C dC U")
    ghost = 1+8*t*sigma
    gauge_dual = 1-t*sigma*u
    coupling = 1-8*t*sigma
    first = lambda z: sp.expand(z).coeff(t,1)
    assert first(sigma*gauge_dual*dc) == -sigma**2*u*dc
    assert sp.expand(first(sigma*gauge_dual*(ghost*dc+8*t*ds*c))-sigma**2*(8-u)*dc-8*sigma*ds*c) == 0
    assert first(coupling*ghost) == first(coupling*ghost**2*(1-8*t*sigma)) == 0

    # Preserve the regulated mixed edge when its divergence is taken.
    free_folder = ROOT / "calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1"
    free = seagull.read(free_folder / f"{phase}_inverse.json.gz")
    q = sp.symbols("q0:4")
    E, infrared = sp.symbols("E_profile f_profile")
    for key, profile in (("Greference",sp.S.One),("G_F",E*infrared)):
        G = {(i,j):value for i,j,value in free[key]}
        checked = {}
        for a in range(45):
            lam = 508+a
            for reverse in (False,True):
                words = tuple(G[(lam,4*a+mu) if reverse else (4*a+mu,lam)] for mu in range(4))
                if (reverse,words) not in checked:
                    val = sp.cancel(sum(q[mu]*sp.sympify(z) for mu,z in enumerate(words)))
                    assert val == (profile if reverse else -profile)
                    checked[reverse,words] = val
    assert E*infrared != 1

    # Product-rule separation at the mixed vertex. Keep the three
    # original switching factors for the partial-diagonal collapse.
    Fa,Fb,Fc, BB, L, dL, gh, dgh = sp.symbols("Fa Fb Fc BB L dL gh dgh")
    original = sigma*c*L*Fa*dgh+sigma*c*Fb*dL*gh+sigma*Fc*dc*L*gh
    total = Fa*((ds*c+sigma*dc)*L*gh+sigma*c*(dL*gh+L*dgh))
    remaining = (Fb-Fa)*sigma*c*dL*gh-Fa*ds*c*L*gh+(Fc-Fa)*sigma*dc*L*gh
    assert sp.expand(BB*(original-total-remaining)) == 0
    assert sigma**3 != sigma**2
    return {"compact_lower_switch_map":"8 I","point_B_transport_supplies_switch_term":False,
            "ghost_and_coupling_spurion_matches_selected_source":True,
            "mixed_free_pairs_checked":90,
            "regulated_mixed_divergence_multiplier":"E_profile*f_profile",
            "collapsed_triangle_switch_degree":3,"bubble_switch_degree":2}


def unpack(cells):
    assert all(p[:2] == [0,0] for p,_,_ in cells)
    return seagull.unpack([([0,*p],n,d) for p,n,d in cells])


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
