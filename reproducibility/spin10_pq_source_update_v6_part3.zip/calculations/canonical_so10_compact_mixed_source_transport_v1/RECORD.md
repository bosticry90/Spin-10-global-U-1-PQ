# V946 pre-execution contract

Polarize the V945 lower source with independent compact
vertex switches and retain the resulting exterior switch
derivative. Freeze all derivative placements, the common
stripped weight, and the preserved transverse free-line
condition. Compare a B-only point map and a formal
local ghost/coupling source transport in the A=0 slice.

For the V943 mixed triangle, freeze both V791 mixed
Green orders and their finite profiles. Check the
divergence signs in every color, and the product-rule
decomposition with derivatives on the external ghost
and switch. Keep the three vertex labels through the
partial diagonal. No adoption of a local coupling,
finite map, or quantum normalization.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB
sampled private, 350 MiB launch floor, 8 MiB artifact and
32 MiB packet. No authority change.
