# V871 separate final review

Freeze both completed producer packets, owner evidence and new navigation
before running the verifier. The limit is 180 seconds, 8 GiB sampled
private allocation, a 350 MiB launch floor, and the original 32 MiB
packet limit. The E4 subprocess has 120 seconds.

Independently confirm the full H and M direct source matrices, all 12
mixed-edge contractions in both current reference packets, the opposite
odd LEFT orders, and the nonlinear derivative from the discriminant.
Authenticate the cycle and regulated forest owners. The proof review
checks the absolute normalization and graphwise stationary cancellation,
including the source and A labels and central terms. The relative LAC1
specialization uses compact background vertices in its original support
domain. The absolute graph pairing allows the admitted Schwartz labels.
No relative star-algebra extension follows from that absolute pairing.

Require E4 exit 0 and steps 0,0,0,0,0,2 with seven unresolved custody
references. Preserve the historical README suffix and project_state.json.
Keep failure or exhaustion separate from the scientific disposition.
The result permits a local scoped evidence commit, with no protected
promotion.
