# Absolute compact W and the one-loop Legendre comparison

Use the V869 literal compact action P and the V870 current chart. The
reference is R0, with the same Feynman boundary, graded dual and source-left
order. Keep the compact vertex expansion coefficientwise, at first g and
first H or M probe, with rho=beta=theta=0. The actual two-source check uses
independent even antighost source tests. The B/A switched terms and all
external sources remain in P. In the equations below P is the tree action.

## Absolute Wick functional

Let V=P−R0, with R_A−R0 among its background-labeled vertices. Use the
zero-uncontracted-field coefficient of the normalized COS1 time-ordered
exponential of V+integral j z. Multiply by one source- and background-
independent free normalization and take W=−i hbar log Z around the formal
unit. This uses the declared Feynman boundary, without a positive state or
nonperturbative integral assumption. Central vertices carry the same
interaction exponent as other vertices. An external local N(J,A) with
no ordinary fields multiplies Z by exp(iN/hbar) and shifts W and Gamma by
N. The mean equation is unchanged. V871 phase A authenticates a concrete
source-square instance at tree order. Such a common factor cancels in a
relative field product with the same external arguments. If those
arguments are changed between numerator and denominator its difference
must be kept. This is why LAC1 does not determine the absolute functional.

The Wick exponential groups disjoint graphs with their original
factorials. Even polarized vertices let component signs factor by their
graded contractions, so the formal logarithm selects connected graphs.
With N vertices and E edges, including ordinary-source leaves, the
factor in W is −i hbar (i/hbar)^N (i hbar)^E. For a tree E=N−1 and each
tree edge has its stationary sign −G. For one loop E=N and the factor
is i hbar (−1)^(N+1). The cycle with k vertices therefore carries the
qualified COS1 ordered supertrace weight i(−1)^(k+1)/(2k). The additional
signs of its N−k bridge edges agree with the tree recursion. The bound
cycle receipt supplies the odd loop and parallel-edge normalization. No
extra odd loop sign is inserted. The tree and one-loop graph factors use
the Minkowski W1 sign. The current Euclidean coefficient tests below use
the already bound Wick chart and do not import the old CWT right-source
sign for W1.

## Rooted forests and regulated normalization

Differentiating a tree with respect to j marks an external root. Peeling
its first vertex leaves independent rooted trees at all remaining ports.
The vertex Taylor factorial assigns unordered identical branches the
inverse of their multiplicity factorial. Equivalently one can label all
vertices first, partition their labels among the branches, and cancel
the interaction factorial by that multinomial count. Keep the graded
ordered jets when polarizing at the ports. Thus the tree mean is the
formal stationary rooted solution phi0 of

    EL^L_z P(phi0,J,A) + diag((-1)^p) j = 0.

It includes the source- and background-linear leaves, and the compact
quadratic chains. Differentiating connected W0 with respect to j gives
that same tree solution. Equivalently W0=P(phi0)+integral j phi0 by the
stationary tree recursion and the central constant check.

At one loop, unique cycle peeling leaves forests rooted at the cycle
vertices, including the empty forest. Replacing every uncontracted
ordinary port in a proper cycle by its rooted tree produces exactly the
connected unicyclic graphs. Conversely cutting their bridges recovers
the unique ordered core. The same vertex-label partition and half-edge
polarization give the proper cycle symmetry weight times the tree weights.
No tree is attached to a central vertex with no ordinary ports. The
one-loop local correction is counted as a tree vertex of order hbar,
including its field-independent terms. Putting it in a loop would exceed
the loop order. Its rooted attachments use the same source derivatives
and cutoff currents as the action.

Define this composition graph by graph. For each fixed graph, the COS1
cycle and bridge difference coordinates are an invertible linear map.
Pair the complete extended cycle and the tensor product of Feynman
bridge distributions in those coordinates with the smooth independent
vertex labels. The source jets and field-independent coefficients are
multiplied before any restrictions. This needs no restriction of a
distribution to a partial diagonal and no evaluation on a supposed
Schwartz Feynman mean. The one-vertex finite tadpole is handled by b, with
the divergent self edge subtracted with all its regulated trees. For
every other regulated core subtract D_t B_t with the entire finite-t
forest. Subtracting D_t B0 would leave the nonzero power-times-tree terms
sum A_j B_j of COS1, including its scalar bridge and its actual
gauge/ghost controls. Keep the old heat length, pole parts, first
dimension jet and paired IR order in the core. The connected product is
the graphwise boundary of this correlated subtraction. It is not the
finite part of the entire unsubtracted graph.

Let F denote the proper corrected one-loop coefficient from V869. At
each compact coefficient the uncorrected COS1 core has the heat proper
coefficient minus b(P). Using one order-hbar input D(P)=C_fin(P)+b(P)
in the tree expansion therefore gives the core plus D(P), which is F.
In the rooted representation this gives

    W_1 = F(phi0,J,A)

where the right side denotes precisely the graph substitution just
defined. The fixed-flat pure reference vertices already give the BCR1
relative reference term after V869's Laurent translation. If one writes
the split, include Gamma_ref[A] once, together with its A derivatives.
The free absolute factor is fixed once. No reference-background or
source-dependent vacuum coefficient is divided out. This construction
never applies the CWT standalone inverse heat to a Schwartz source.

## Legendre transform and two retained-source derivatives

Use the original source-first term j_i z_i, so
EL^L_z_i(j_i z_i)=(-1)^p_i j_i. The reference inverse is two-sided in
that evaluation pairing. For a dummy compact ordinary mean label phi,
the classical inverse source j0,i=−(-1)^p_i EL^L_phi_i P is a compact
label in the stated domain. Substituting it into the rooted formal
stationary equation gives phi0(j0)=phi. This follows by two-sided
K0 G0=G0 K0=1 on compact tests and uniqueness of the recursion at finite
interaction order. No homogeneous solution is added to the fixed
Feynman branch. The compact mean inverse applies also to odd sources
with their evaluation dual. The exact odd fixture checks the opposite
orders of the two left source derivatives on the actual C/a pairing.

Under a formal ordinary-source shift j=j0+hbar j1, the order-hbar
variation of W0 at j0 is integral j1 phi in the original source-first
order, since phi0=phi. This cancels the shift in W−integral j phi.
The cancellation takes place at the coefficient level and does not
require j1 to define a new Schwartz label. The compact Legendre
coefficient is therefore Gamma1=F, with Gamma0=P. Source and
background derivatives of the remaining fixed-mean functionals
have the W1 signs. Only j was Legendre transformed.

For two even J directions f1,f2 at fixed j, let y_i=phi0,J_i and
y_12=phi0,J1J2, defined by marked rooted trees. The complete mixed loop
derivative is

    W_1,J1J2 = F_J1J2 + F_J1,phi[y2] + F_J2,phi[y1]
                       + F_phiphi[y1,y2] + F_phi[y_12].

The placements refer to the same rooted cycle/forest product, before
any source restriction. The nonlinear finite control has all five
nonzero and agrees with the exact stationary branch. The actual
isolated g0 light gauge/auxiliary tree control is quadratic, so it
cannot by itself establish nonzero values for all five terms. In
particular the current g0 H J_a dependence of P is at most linear in
ordinary fields. The proper determinant and C_fin+b then have zero
direct derivative with respect to that source at fixed mean, but the
tree contacts and possible mean-sewn loop derivatives still enter W.

## Actual compact first-u light tree bridge

In the V791 current Euclidean chart the 120 g0 GF/source rows in the
light gauge/auxiliary block give eta_H b²/2+i b(div B−div A−J).
The 660 light probe rows are exactly the twelve negative squares
−(Lz−div A−J)² with Lz=div B−i eta_H b/2. The g0 physical gauge
kinetic block is the diagonal quadratic Maxwell block. The remaining
g0 physical terms do not mix light B or b into the scalar Hessian.
Consequently the selected unprobed g0 tree block is quadratic and
decoupled, with the actual compact Euler Hessian K_sigma. The difference
of literal g0 gauge/auxiliary kinetic representatives from Euler-normal
R0 is an ordinary current. It contains div(B_nu F_mu,nu/2+i b B_mu/2).
Multiplying by sigma leaves the term with minus its switch derivative
and includes both Maxwell and auxiliary switch currents in K_sigma.
No replacement of the full compact inverse by G0 is made.

At fixed ordinary source and first u_H, the tree stationary envelope
is the exact probe square on the unprobed rooted mean. For J tests
f1,f2 in one light color it yields the connected tree derivative

    −2 integral sigma (f1−i L G_sigma e_b(sigma f1))
                         (f2−i L G_sigma e_b(sigma f2)).

Here e_b inserts the auxiliary covector and G_sigma denotes the full
formal compact Feynman inverse, including the switch jets. The same
operator expression follows by differentiating the tree Schur
complement P_JJ−P_Jz G_sigma P_zJ at first u_H, with
P_zJ^(0)=−i e_b sigma, P_zJ^(1)=2 L^t sigma and K^(1)=−2 L^t sigma L.
In particular the derivative of G contributes the two-sided last
term in the expanded square. The direct source contact is the first
term, whereas the remaining terms are reducible bridges. Those
bridges are removed by the fixed-mean Legendre derivative.

For a controlled compact check use sigma=s chi, with chi still compact.
At first degree in s the coefficient is −2 integral chi f1 f2. At
second degree the two source endpoints already spend both switch
vertices. Use only the corresponding G0 term in G_sigma. The actual
mixed B/b Green entries and the independent stationary equations give
i L G0 e_b=1. This is the off-shell delta contact, with the derivative
acting on the whole switched test. The two Schur bridge orientations
give −2 each before the Schur minus, so the second coefficient is
+4 integral chi² f1 f2. Dropping the mixed edge loses this coefficient.
The 12 color checks retain the symbolic width. Their constant
momentum result is a local distributional pairing on the original
Feynman boundary, not a constant-switch limit or complete numerical
evaluation of the nonlocal compact inverse.

## Local normalization and scope of the switch comparison

At the retained finite grades the C_fin local symbol subtraction is
an integral of finite products of jets of the input Hessian and its
coefficients in the fixed reference. The b term is linear and local.
The finite clock, scale and width coefficients are fixed for each word.
Thus the same D on admitted local increments obeys disjoint-support
additivity: D(V+f+h)−D(V+f)−D(V+h)+D(V)=0 when the two varying jet
supports are disjoint. Pointwise at least one increment and all its
jets vanish. This proof uses the same reference and pure-background
baseline throughout. The action map V→V+hbar D therefore preserves
the inherited relative causal factorization on such increments. For
two switches agreeing near a compact observation region, an insertion
strength supported there leaves the past relative transporter fixed
if the past difference is held fixed. Causal factorization cancels
that common later action increment in the two factors of the
transporter. General source or background derivatives can still give
LAC1's inner term. This is a statement about input strengths, not a
derivation property of a local affine field operation on the fixed
free star product.

The positive result is an absolute compact coefficientwise W1 and
proper Legendre bridge on the admitted one-loop family. It retains
the central source response, reference terms, and complete regulated
forests. The connected Ward change-of-variables or MWI realization,
general coincident insertions, physical vacuum/phase, global limits
and E5/A5 remain separate. The arithmetic checks share the action,
reference conventions, analytic premises, software and AI authorship.
