# V871 phase B absolute one-loop and Legendre comparison

Freeze this record, the proof, both new worker sources and the full phase A
packet before execution. Use V870 on main and the literal V869 compact
action, with the same fixed flat inverse and CWB, COS1 and V869 finite
normalization. Work coefficientwise at finite compact vertex order, first
g and first H or M u, with rho=beta=theta=0. Allow independent compact
ordinary and external source labels, keeping their graded duals and all
background-only data. Test the two independently smeared even antighost
directions. The actual tree bridge calculation is at g0 and first H u.
No global constant switch or unlabelled limit is taken.

Recover all 660 g0 light probe-square rows and all 120 g0 light
gauge/auxiliary GF/source rows from the actual packets in both routes.
Retain the actual compact Euler Hessian including switch currents.
Check the exact first-u compact tree operator relation and its first
two switch degrees against the mixed free reference edge, in both
orientations. Use an independent stationary elimination of that edge.
Check the actual odd free block and a source-first exterior sign fixture.
Use a nonlinear finite scalar control for the five connected derivatives.
These checks are not new physical loop integrals.

The analytic proof must define the absolute causal vacuum coefficient,
identify the rooted cycle/forest representation and show stationarity
cancels the ordinary-source shift at fixed compact test mean. Retain the
positive-heat power terms with their complete finite-cutoff forests. Keep
the pure reference and the actual central contact. Check disjoint-support
additivity of the one-loop local finite correction, then specialize the
inherited LAC1 input-strength comparison. A field action on the fixed
free star product still requires the separate connected Ward argument.

Root owns writes and execution. Limit the worker to 120 seconds, 8 GiB
sampled private allocation, a 350 MiB launch floor, 8 MiB result and 32 MiB
packet. Preserve exact captures. A failed comparison or analytic gap
leaves the relevant claim unqualified. Final independent validation and
E4 precede a local commit. The ceiling is the compact coefficientwise
absolute one-loop W1/Legendre bridge, with no full E5/A5 or physical claim.
