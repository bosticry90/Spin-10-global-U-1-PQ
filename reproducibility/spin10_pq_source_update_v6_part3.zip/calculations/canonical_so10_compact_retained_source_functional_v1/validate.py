"""Verify V871 contacts, exact Green identities and the E4 sequence."""

from fractions import Fraction
from hashlib import sha256
import json
import os
import subprocess
import sys
import threading
import time

import sympy as sp

from bridge import FREE, Q, q
from central import read
from execute_a import CONTROL, HERE, ROOT, git, save


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def independent_contacts(a, b):
    for name, (start, stop) in {"H": (0, 12), "M": (12, 45)}.items():
        block = a["tree_contacts"][name]
        diagonal = block["complete_direct_matrix_without_sigma_or_u"]
        deletion = block["deletion_direct_matrix_difference"]
        assert len(diagonal) == len(deletion) == 45
        for i in range(45):
            assert len(diagonal[i]) == len(deletion[i]) == 45
            for j in range(45):
                assert diagonal[i][j] == -2 * int(i == j and start <= i < stop)
                assert deletion[i][j] == -diagonal[i][j]
        assert len(block["literal_central_squares"]) == stop - start
    assert b["checks"]["actual_chart"] == {"g0_light_GF_source_rows": 120, "g0_light_probe_square_rows": 660}
    records = b["checks"]["tree_bridges"]
    assert len(records) == 12
    for role in ("native", "replay"):
        packet = read(FREE / f"{role}_inverse.json.gz")
        green = {(i, j): sp.sympify(value) for i, j, value in packet["Greference"]}
        for h, record in enumerate(records):
            auxiliary = 508 + h
            assert (auxiliary, auxiliary) not in green
            divergence = sp.cancel(sum(mu * green[4 * h + axis, auxiliary] for axis, mu in enumerate(q)))
            reverse = sp.cancel(sum(mu * green[auxiliary, 4 * h + axis] for axis, mu in enumerate(q)))
            assert divergence == -1 and reverse == 1
            # The one free mixed bridge in each orientation. The second
            # expansion degree uses two switched endpoints and no insertion.
            assert record == {"light_color": h, "envelope_factor": -1, "W_tree_s1": -2,
                              "W_tree_s2": int(2 * (reverse - divergence)),
                              "missing_mixed_edge_s2": 0, "ordered_schur_terms": [-2, -2]}
        assert green[553, 598] * Q == 1 and green[598, 553] * Q == -1
    assert b["odd"]["LEFT_ja_after_jC"] == "-1/m" and b["odd"]["LEFT_jC_after_ja"] == "1/m"
    pieces = [Fraction(value) for value in b["nonlinear"]["five_pieces_without_common_i_over_2"]]
    discriminant, first, second = 4, -58, 18
    result = (Fraction(second, discriminant) - Fraction(first, discriminant)**2) / 2
    assert len(pieces) == 5 and all(pieces) and sum(pieces) == result
    assert result == Fraction(b["nonlinear"]["direct_stationary_branch"]) == Fraction(-823, 8)
    return {"direct_H_M_diagonals": [12, 33], "actual_mixed_bridge_colors": 12,
            "tree_contact_switch_grades": [-2, 4], "five_term_control": str(result)}


def main():
    started = time.perf_counter()
    watch = threading.Timer(180, lambda: os._exit(124))
    watch.daemon = True
    watch.start()
    prep = read(HERE / "preparation_validation.json")
    assert prep["base_HEAD"] == git("rev-parse", "HEAD").decode().strip()
    assert git("ls-tree", "-r", "HEAD") == (CONTROL / "old_git_tree.txt").read_bytes()
    assert not git("diff", "--cached", "--name-only")
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    for phase in ("a", "b"):
        for prefix in ("preparation", "capture"):
            name = f"{prefix}_{phase}.json"
            assert (HERE / name).read_bytes() == (CONTROL / name).read_bytes()
        capture = read(HERE / f"capture_{phase}.json")
        assert capture["calculation_completed"] and capture["post_run_observations_qualified"]
    for source in HERE.glob("*.source.txt"):
        assert source.read_bytes() == (HERE / source.name.removesuffix(".source.txt")).read_bytes()
    old_reviews = {
        "CNS_FINAL_VALIDATION_AND_NEW_BYTE_SEAL": "PASS_BOUNDED_SOURCE_ENDPOINT_AND_NONLINEAR_SEWING_ALGEBRA",
        "CTS_FINAL_VALIDATION_AND_NEW_BYTE_SEAL": "PASS_BOUNDED_FOUR_NON_TADPOLE_CONNECTED_LOOP_DOMAIN",
        "CWT_FINAL_VALIDATION_AND_NEW_BYTE_SEAL": "PASS_BOUNDED_PAIRED_TRANSPORT_WITH_PRESERVED_SOURCE_DOMAIN_AND_GHOST_LIMITS",
    }
    for name in prep["owner_receipts"]:
        receipt = read(ROOT / name)
        schema = receipt.get("schema")
        if schema in old_reviews:
            assert receipt["evidence_validation"] == old_reviews[schema], name
        else:
            assert receipt["execution_state"] == "COMPLETED", name

    phase_a, phase_b = (read(HERE / f"result_{phase}.json") for phase in ("a", "b"))
    assert phase_a["execution_state"] == phase_b["execution_state"] == "COMPLETED"
    checks = independent_contacts(phase_a["comparison"], phase_b)
    print("STAGE source-only contacts, actual bridge and nonlinear Legendre controls checked", flush=True)

    e4 = subprocess.run([sys.executable, "-B", "tools/research_check.py", "e4", "--historical-context",
                         "D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4"],
                        cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=120)
    save("e4_capture.json", {"exit_code": e4.returncode, "stdout": e4.stdout, "stderr": e4.stderr})
    events = [json.loads(line) for line in e4.stdout.splitlines() if line.strip()]
    steps = [event for event in events if event.get("event") == "step_finished"]
    exits = [event["exit_code"] for event in steps]
    assert e4.returncode == 0 and exits == [0, 0, 0, 0, 0, 2]
    custody = next(event for event in steps if event["step"] == "historical_custody")
    assert custody["stdout"].count("RECORDED_DIGEST_UNRESOLVED:") == 7
    historic = git("show", "ef70f255a667b9a81e37b344dc78967ada4ed896:README.md")
    assert sha256(historic).hexdigest() == "4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792"
    assert (ROOT / "README.md").read_bytes().replace(b"\r\n", b"\n").endswith(historic)
    assert digest(ROOT / "project_state.json") == "d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8"
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    paths = [path for path in HERE.iterdir() if path.is_file()]
    assert sum(path.stat().st_size for path in paths) <= 32 * 1024**2
    paths.extend(ROOT / name for name in prep["navigation"])
    save("validation_receipt.json", {
        "execution_state": "COMPLETED", "evidence_validation": "PASS_ABSOLUTE_COMPACT_ONE_LOOP_RETAINED_SOURCE_LEGENDRE_BRIDGE",
        "scientific_acceptance": "NOT_PERFORMED", "base_HEAD": prep["base_HEAD"],
        "state_sha256": digest(ROOT / "project_state.json"), "owner_receipts": prep["owner_receipts"],
        "independent_checks": checks, "E4_step_exits": exits, "historical_custody": "SEVEN_UNRESOLVED_NOTPASS",
        "files_excluding_pending_receipt_capture": {path.relative_to(ROOT).as_posix(): digest(path) for path in paths},
        "elapsed_after_imports": time.perf_counter() - started,
    })
    watch.cancel()


if __name__ == "__main__":
    main()
