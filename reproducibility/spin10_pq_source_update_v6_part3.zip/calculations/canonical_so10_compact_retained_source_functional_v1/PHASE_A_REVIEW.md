# V871 phase A source contacts and the connected bridge

Both frozen routes agree. The producer took 1.161 seconds. Its only
private-memory sample was 933,888 bytes at launch, so that sample does
not estimate the process peak. The complete direct 45-by-45 source matrix
is −2 times the appropriate light or heavy projector before multiplying
by sigma and the probe strength. The actual H and M packets give 12 and
33 diagonal source squares respectively. All off-diagonal entries vanish
in this declared grade. Two-strength polarization and successive even
left source differentiation agree exactly. The packets preserve the other
central terms. This is a completed producer result pending final review.

For the H source J_bar0 the actual derivative of the switched action is

    P_J = sigma [−i b0 + u_H(2 div(B0−A0)−i eta_H b0−2 J_bar0)].

Thus the direct tree derivative for two independent tests f1,f2 is
−2 u_H integral sigma f1 f2. The source-only square has no ordinary or
source/ordinary derivative. In the diagnostic deletion the full mean
equation, bridge and proper Gaussian do not change. The absolute W and
Gamma change by the deleted central density, with the sign of removal.
This makes their two-source derivative sensitive even when the full
connected response contains reducible terms. A common central factor
cancels between numerator and denominator of a relative field product
at fixed external arguments. This is an actual tree-level test of data
that LAC1's relative field comparison cannot recover on its own.

For phase B hold the ordinary source j fixed and use the plus j z sign
of the W1 contract. Stationarity gives the graded rooted expansion for
phi0. The direct tree source contact is accompanied by the bridge
P_(Jz) phi0,J, with phi0,J=−G_tree P_(zJ) in the evaluation-dual pairing.
The tree bridge is removed only by the fixed-mean Legendre derivative.
At one loop use the absolute normalized causal coefficients, including
vacuum graphs and the pure reference part. The expression W1=F(phi0,J,A)
must be defined coefficientwise by replacing each cycle port with its
rooted tree forest. Apply the same finite loop normalization with the full
regulated forest, and use formal stationary cancellation to recover F
after the Legendre transform. This does not require a map on an arbitrary
Schwartz mean or a standalone inverse-heat operator.

For the two independent even J directions the second connected loop
derivative has five pieces. They are the direct F_J1J2, each of the two
F_Jphi times a first mean response, the F_phiphi with both first responses,
and F_phi times the second mean response. The local correction C_fin+b
must enter the same rooted tree expansion at order hbar. Preserve the
fixed V869 reference normalization and its A derivatives. Prove locality
of the normalization on disjoint support before applying the inherited
relative switch comparison. A plateau-local insertion-strength variation
can leave the past relative transporter fixed by causal factorization.
That fact alone gives no derivation property of a local affine field
action on the fixed free star product. The off-shell retarded/advanced
reference contacts and connected Ward realization remain separate tests.
