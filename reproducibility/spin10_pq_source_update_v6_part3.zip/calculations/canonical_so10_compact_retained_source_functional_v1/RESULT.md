# V871 absolute compact retained-source Legendre bridge

Use with the completed final receipt and capture. The fixed-flat COS1
causal graph family supplies an absolute connected W through one loop
on the selected compact current domain. The construction retains all
central source terms and the relative background determinant. The
graded Legendre transform recovers the V869 corrected proper F at fixed
compact test mean. This is a formal graphwise statement on the original
Feynman branch. The cycle distributions and complete regulated forests
give the connected coefficients before the tree roots are removed.

The direct source matrix has 12 light and 33 heavy diagonal entries,
each −2 before the switch and probe factors in the current Euclidean
chart. Dropping the source-only squares changes the absolute source
response and leaves the rooted mean and ordinary Hessian intact.
The 120 light g0 GF/source rows and all 660 light g0 probe rows give the
exact compact quadratic tree block. Two routes recover the first
reducible tree bridge in all 12 colors. For sigma=s chi its first two
coefficients are −2 integral chi f1 f2 and +4 integral chi² f1 f2.
The second coefficient uses both orientations of the mixed reference
edge and its off-shell contact. Higher switch degrees still use the
full compact tree inverse, with the literal Maxwell and auxiliary
switch currents.

The connected loop derivative retains all five source and mean
terms. The exact nonlinear finite fixture confirms their signs and
placement, with all five nonzero. The actual odd reference block and
exterior fixture check the W1 source-first ordering. No new physical
loop integral was evaluated. The finite local correction also obeys
disjoint-support additivity in the admitted compact relative LAC1
comparison. This does not turn a local field action into a derivation
of the fixed free star product.

[Proof](PROOF.md) and [final review](FINAL_RECORD.md). The next gate
tests the connected background variation on an actual scalar bridge,
including the causal reference compensation and the opposite reference
vertex in the compact interaction. The remaining connected Ward and
nonlinear contact obligations, physical vacuum and global limits are
separate. The routes share the action, reference, analytic assumptions,
software and AI authorship. E5/A5 and physical viability remain open.
Authority 34/39 and seven unresolved historical custody references.
