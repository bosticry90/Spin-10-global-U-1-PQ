"""Extract the actual central source contact before the Legendre comparison."""

from hashlib import sha256
from itertools import permutations
from pathlib import Path
import gzip
import json
import os
import threading
import time


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CURRENT = ROOT / "calculations/canonical_so10_joint_common_family_applicability_v1"
SOURCES = tuple(range(1241, 1286))


def read(path):
    if path.suffix == ".gz":
        with gzip.open(path) as stream:
            return json.load(stream)
    return json.loads(path.read_bytes())


def polarize(rows, parity):
    direct = [[0] * 45 for _ in SOURCES]
    squares = []
    for grade, word, cells in rows:
        if grade != 0:
            continue
        positions = [(i, n) for i, (n, jets) in enumerate(word) if n in SOURCES]
        if len(positions) < 2:
            continue
        # Extract s t in the two independent smeared even directions.
        assert len(positions) == len(word) == 2
        assert all(not jets and not parity[n] for n, jets in word)
        assert cells == [[[0, 0, 0], -1, 1]]
        for (_, n), (_, m) in permutations(positions, 2):
            direct[n - SOURCES[0]][m - SOURCES[0]] -= 1
        squares.append([grade, word, cells])
    return direct, squares


def left_derivatives(rows):
    direct = [[0] * 45 for _ in SOURCES]
    for grade, word, cells in rows:
        if grade or sum(n in SOURCES for n, jets in word) < 2:
            continue
        multiplicities = {n: sum(m == n for m, jets in word) for n, jets in word}
        assert sum(multiplicities.values()) == 2 and all(n in SOURCES for n in multiplicities)
        for n, count_n in multiplicities.items():
            for m, count_m in multiplicities.items():
                # After the first left derivative there are count_m-1
                # factors to choose from when differentiating the same source.
                direct[n - SOURCES[0]][m - SOURCES[0]] -= count_n * (count_m - int(n == m))
    return direct


def single_source_root(rows):
    return [row for row in rows if row[0] == 0 and any(n == SOURCES[0] for n, jets in row[1])]


def verify_role(role):
    packet = read(CURRENT / f"{role}_complete_full_background_extension.json.gz")
    assert all(not packet["joined_parities"][n] for n in SOURCES)
    probes = {probe["probe"]: probe["complete_U"] for probe in packet["probes"]}
    assert set(probes) == {"H", "M"}
    assert not polarize(packet["complete_S_GF_source"], packet["joined_parities"])[1]
    tree = {}
    for name, rows in probes.items():
        matrix, squares = polarize(rows, packet["joined_parities"])
        assert matrix == left_derivatives(rows)
        active = range(12) if name == "H" else range(12, 45)
        assert matrix == [[-2 if i == j and i in active else 0 for j in range(45)] for i in range(45)]
        assert len(squares) == len(active)
        # Zero ordinary fields means the deletion cannot affect the inverse,
        # the source/ordinary bridges, the proper log or the b contraction.
        assert all(n >= 643 for _, word, _ in squares for n, jets in word)
        tree[name] = {"complete_direct_matrix_without_sigma_or_u": matrix, "literal_central_squares": squares,
                      "deletion_direct_matrix_difference": [[-value for value in row] for row in matrix],
                      "ordinary_and_source_ordinary_derivatives_of_deleted_terms_zero": True}
    Ja0 = {
        "base": single_source_root(packet["complete_S_GF_source"]),
        "H": single_source_root(probes["H"]), "M": single_source_root(probes["M"]),
    }
    assert Ja0["base"] == [[0, [[508, []], [1241, []]], [[[0, 0, 16], -1, 1]]]]
    expected = [[0, [[mu, [mu]], [1241, []]], [[[0, 0, 0], 2, 1]]] for mu in range(4)]
    expected.extend([[0, [[508, []], [1241, []]], [[[0, 1, 16], -1, 1]]],
                     [0, [[1241, []], [1241, []]], [[[0, 0, 0], -1, 1]]]])
    expected.extend([0, [[1241, []], [1331 + mu, [mu]]], [[[0, 0, 0], -2, 1]]] for mu in range(4))
    assert Ja0["H"] == expected and not Ja0["M"]
    return {"tree_contacts": tree, "complete_J_bar0_input_roots": Ja0, "switch_and_probe_strength_retained": True}


def main():
    started = time.perf_counter()
    watch = threading.Timer(120, lambda: os._exit(124))
    watch.daemon = True
    watch.start()
    for name, expected in read(HERE / "preparation_a.json")["sha256"].items():
        assert sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    native = verify_role("native")
    print("STAGE native full direct source contacts checked", flush=True)
    replay = verify_role("replay")
    assert native == replay
    print("STAGE replay full direct source contacts agree", flush=True)
    result = {"execution_state": "COMPLETED", "scientific_acceptance": "NOT_PERFORMED",
              "phase": "A_ACTUAL_CENTRAL_TREE_CONTACTS", "comparison": native, "seconds": time.perf_counter() - started}
    data = (json.dumps(result, sort_keys=True) + "\n").encode()
    name = "result_a.json" if len(data) <= 8 * 1024**2 else "result_a.COMPLETE_OVERFLOW_NOTPASS"
    with (HERE / name).open("xb") as stream:
        stream.write(data)
    assert name == "result_a.json"
    watch.cancel()


if __name__ == "__main__":
    main()
