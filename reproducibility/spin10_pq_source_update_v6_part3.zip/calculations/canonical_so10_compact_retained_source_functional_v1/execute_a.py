"""Freeze the absolute source contact worker and observe its execution."""

from hashlib import sha256
from pathlib import Path
import ast
import json
import subprocess
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CONTROL = Path("D:/Codex-Research/ToE-Next/research-control-records/compact-retained-source-functional-v1-2026-11-08")
PK = ROOT / "tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1"


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def save(filename, report):
    data = (json.dumps(report, sort_keys=True) + "\n").encode()
    for folder in (HERE, CONTROL):
        with (folder / filename).open("xb") as stream:
            stream.write(data)


def main():
    head = git("rev-parse", "HEAD").decode().strip()
    assert head == "091f3d0c95d018f0d7999b9bf08c1678344560c9"
    assert not git("diff", "--name-only", "HEAD")
    names = {"AGENTS.md", "CHARTER.md", "project_state.json", "docs/RESEARCH_EXECUTION_HANDOFF_V870.md"}
    records = {
        "joint_compact_background_geometric_v1": ("PROOF.md", "validation_receipt.json"),
        "current_background_reference_bridge_v1": ("PROOF.md", "validation_receipt.json"),
        "joint_common_family_applicability_v1": ("PROOF.md", "validation_receipt.json", "native_complete_full_background_extension.json.gz", "replay_complete_full_background_extension.json.gz"),
        "local_cutoff_comparison": ("RESULT.md", "validation_receipt_v4.json"),
        "causal_one_loop_sewing": ("DERIVATION.md", "validation_receipt.json"),
    }
    for folder, filenames in records.items():
        names.update(f"calculations/canonical_so10_{folder}/{name}" for name in filenames)
    names.update((PK / name).relative_to(ROOT).as_posix() for name in ("export_a10_e5_antighost_vector.py", "A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md"))
    assert all((ROOT / name).is_file() for name in names)
    CONTROL.mkdir(exist_ok=False)
    with (CONTROL / "old_git_tree.txt").open("xb") as stream:
        stream.write(git("ls-tree", "-r", "HEAD"))
    for name in ("RECORD.md", "central.py", "execute_a.py"):
        data = (HERE / name).read_bytes()
        if name.endswith(".py"):
            ast.parse(data)
        with (HERE / (name + ".source.txt")).open("xb") as stream:
            stream.write(data)
    names.update(path.relative_to(ROOT).as_posix() for path in HERE.iterdir() if path.is_file())
    save("preparation_a.json", {
        "base_HEAD": head,
        "sha256": {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in sorted(names)},
        "limits": {"seconds": 120, "sampled_private_bytes": 8 * 1024**3, "packet_bytes": 32 * 1024**2,
                   "artifact_bytes": 8 * 1024**2, "minimum_available_commit_bytes": 350 * 1024**2},
        "scientific_acceptance": "NOT_PERFORMED",
    })
    sys.path.insert(0, str(PK))
    from export_a10_e5_antighost_vector import capture

    report = capture([sys.executable, "-B", str(HERE / "central.py")])
    save("capture_a.json", report)
    print(report["stdout_and_stderr"], end="")
    assert report["calculation_completed"] and report["post_run_observations_qualified"]
    assert sum(path.stat().st_size for path in HERE.iterdir() if path.is_file()) <= 32 * 1024**2


if __name__ == "__main__":
    main()
