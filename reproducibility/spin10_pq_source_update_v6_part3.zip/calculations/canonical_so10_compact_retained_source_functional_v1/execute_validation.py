"""Freeze and run the final absolute W1 review."""

import ast
import sys
from hashlib import sha256

from central import read
from execute_a import CONTROL, HERE, PK, ROOT, git, save


NAVIGATION = ["README.md", "docs/COMMON_RESTORATION_CAMPAIGN_V1.md", "docs/RESEARCH_EXECUTION_HANDOFF_V871.md"]


def main():
    producer = read(HERE / "preparation_b.json")
    head = git("rev-parse", "HEAD").decode().strip()
    assert head == producer["base_HEAD"]
    assert not git("diff", "--cached", "--name-only")
    assert set(git("diff", "--name-only", "HEAD").decode().splitlines()) == set(NAVIGATION[:2])
    for name, backup in zip(NAVIGATION[:2], ("README_before_final.bytes", "campaign_before_final.bytes")):
        assert (CONTROL / backup).read_bytes().replace(b"\r\n", b"\n") == git("show", "HEAD:" + name)
    for name, expected in producer["sha256"].items():
        assert sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    for name in ("FINAL_RECORD.md", "RESULT.md", "validate.py", "execute_validation.py"):
        data = (HERE / name).read_bytes()
        if name.endswith(".py"):
            ast.parse(data)
        with (HERE / (name + ".source.txt")).open("xb") as stream:
            stream.write(data)
    names = set(producer["sha256"]) | set(NAVIGATION)
    names.update(path.relative_to(ROOT).as_posix() for path in HERE.iterdir() if path.is_file())
    names.add("docs/LOCAL_RESEARCH_CONVENTIONS_V1.md")
    receipts = sorted(name for name in names if name.startswith("calculations/") and "receipt" in name and name.endswith(".json"))
    assert len(receipts) == 14
    save("preparation_validation.json", {
        "base_HEAD": head, "navigation": NAVIGATION, "owner_receipts": receipts,
        "sha256": {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in sorted(names)},
        "limits": {**producer["limits"], "seconds": 180}, "scientific_acceptance": "NOT_PERFORMED",
    })
    sys.path.insert(0, str(PK))
    from export_a10_e5_antighost_vector import capture

    report = capture([sys.executable, "-B", str(HERE / "validate.py")])
    save("capture_validation.json", report)
    print(report["stdout_and_stderr"], end="")
    assert report["calculation_completed"] and report["post_run_observations_qualified"]


if __name__ == "__main__":
    main()
