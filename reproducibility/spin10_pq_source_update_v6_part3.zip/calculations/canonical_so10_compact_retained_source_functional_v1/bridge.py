"""Check the actual compact tree bridge and the W1 Legendre conventions."""

from functools import lru_cache
from hashlib import sha256
import json
import os
import threading
import time

import sympy as sp

from central import CURRENT, HERE, ROOT, read


CALC = ROOT / "calculations"
FREE = CALC / "canonical_so10_regulator_free_inverse_g1_recovery_v1"
q = sp.symbols("q0:4")
Q = sum(mu**2 for mu in q)
eta, xi = sp.symbols("eta_H xi")
I = sp.I


@lru_cache(maxsize=1000)
def coefficient(cells):
    result = sp.S.Zero
    for (width, light_width, mask), num, den in json.loads(cells):
        radical = sp.sqrt(sp.prod(p for bit, p in enumerate((2, 3, 5, 7)) if mask & (1 << bit)))
        result += sp.Rational(num, den) * xi**width * eta**light_width * radical * (I if mask & 16 else 1)
    return result


def rows_at_zero(rows, select=lambda word: True):
    return {tuple((i, tuple(jets)) for i, jets in word): coefficient(json.dumps(cells))
            for g, word, cells in rows if g == 0 and select(word)}


def chart_control(data):
    gf_expected = {}
    squares_expected = {}
    for h in range(12):
        b, J = (508 + h, ()), (1241 + h, ())
        vectors = [(4 * h + mu, (mu,)) for mu in range(4)]
        background = [(1331 + 4 * h + mu, (mu,)) for mu in range(4)]
        gf_expected[(b, b)] = eta / 2
        gf_expected[(b, J)] = -I
        gf_expected.update({(B, b): I for B in vectors})
        gf_expected.update({(b, A): -I for A in background})

        # The full H probe is the negative square in each color.
        slots = vectors + [b, J] + background
        factors = [sp.S.One] * 4 + [-I * eta / 2, -sp.S.One] + [-sp.S.One] * 4
        labels = sp.symbols("x0:10")
        square = sp.Poly(-sum(value * label for value, label in zip(factors, labels))**2, *labels)
        for powers, value in square.terms():
            word = tuple(slot for slot, count in zip(slots, powers) for _ in range(count))
            assert len(word) == 2
            squares_expected[word] = value
    gf = rows_at_zero(data["complete_S_GF_source"], lambda word: any(i < 48 or 508 <= i < 520 for i, jets in word))
    U = next(probe["complete_U"] for probe in data["probes"] if probe["probe"] == "H")
    square = rows_at_zero(U)
    assert gf == gf_expected and len(gf) == 120
    assert square == squares_expected and len(square) == 660
    return {"g0_light_GF_source_rows": len(gf), "g0_light_probe_square_rows": len(square)}


def source_endpoints(source, h):
    Ja = 1241 + h
    ports = [4 * h + mu for mu in range(4)] + [508 + h]
    terms = [sp.S.Zero] * 5
    for word, value in source.items():
        if len(word) != 2 or (Ja, ()) not in word:
            continue
        z = next((i, jets) for i, jets in word if i != Ja) if word[0] != word[1] else (Ja, ())
        if z[0] in ports:
            # Formal transpose of the local derivative from the z port.
            terms[ports.index(z[0])] += value * sp.prod(-I * q[mu] for mu in z[1])
    return sp.Matrix(terms)


def reference_bridge(role, data):
    packet = read(FREE / f"{role}_inverse.json.gz")
    G = {(i, j): sp.sympify(value) for i, j, value in packet["Greference"]}
    K = {(i, j): sp.sympify(value) for i, j, value in packet["Preference"]}
    base = rows_at_zero(data["complete_S_GF_source"])
    probe = rows_at_zero(next(probe["complete_U"] for probe in data["probes"] if probe["probe"] == "H"))
    q_reverse = {mu: -mu for mu in q}
    records = []
    for h in range(12):
        ports = [4 * h + mu for mu in range(4)] + [508 + h]
        cov0, cov1 = [source_endpoints(rows, h) for rows in (base, probe)]
        assert cov0 == sp.Matrix([0, 0, 0, 0, -I])
        assert cov1 == sp.Matrix([-2 * I * mu for mu in q] + [-I * eta])
        green = sp.Matrix([[G.get((i, j), 0) for j in ports] for i in ports])
        kernel = sp.Matrix([[K.get((i, j), 0) for j in ports] for i in ports])
        stationary = sp.Matrix([I * mu / Q for mu in q] + [0])
        # Solve the mixed stationary equations without using the saved inverse.
        assert (kernel * stationary - cov0).applyfunc(sp.simplify) == sp.zeros(5, 1)
        assert (green * cov0 - stationary).applyfunc(sp.simplify) == sp.zeros(5, 1)
        L = sp.Matrix([[I * mu for mu in q] + [-I * eta / 2]])
        envelope_factor = sp.simplify((L * stationary)[0])
        orders = [sp.simplify((left.xreplace(q_reverse).T * green * right)[0])
                  for left, right in ((cov0, cov1), (cov1, cov0))]
        assert orders == [-2, -2] and envelope_factor == -1
        assert -sum(orders) == -4 * envelope_factor == 4 and green[4, 4] == 0
        # Negative control: remove the mixed Green edge, leaving the same endpoints.
        wrong = green.copy()
        for mu in range(4):
            wrong[mu, 4] = wrong[4, mu] = 0
        assert (cov0.T * wrong * cov1)[0] == 0
        records.append({"light_color": h, "ordered_schur_terms": [int(value) for value in orders], "envelope_factor": -1,
                        "W_tree_s1": -2, "W_tree_s2": 4, "missing_mixed_edge_s2": 0})

    # Actual free odd block in the source-first W1 chart.
    assert K[553, 598] == -Q and K[598, 553] == Q
    assert G[553, 598] == 1 / Q and G[598, 553] == -1 / Q
    return records


def odd_control():
    m = sp.Symbol("m", nonzero=True)
    jC, ja = 0, 1
    # Products in the ordered exterior basis jC then ja.
    def pair(x, y):
        assert x != y
        return 1 if x < y else -1

    # The stationary fields are C=-ja/m and a=jC/m. Substitute into
    # m C a + jC C + ja a without changing source order.
    W = sp.expand(-pair(ja, jC) / m - pair(jC, ja) / m + pair(ja, jC) / m)
    assert W == -1 / m
    return {"W0_jC_ja_coefficient": str(W), "LEFT_ja_after_jC": str(W), "LEFT_jC_after_ja": str(-W)}


def nonlinear_control():
    J = sp.Symbol("J")
    k, a, b, d = map(sp.Integer, (2, 3, 5, 7))
    y = -d / k
    yy = -(b * y**2 + 2 * a * y) / k
    pieces = (-a**2 / k**2, -a * b * y / k**2, -a * b * y / k**2,
              -b**2 * y**2 / k**2, b * yy / k)
    branch = sp.sqrt((k + a * J)**2 - 2 * b * d * J)
    direct = sp.diff(sp.log(branch), J, 2).subs(J, 0)
    assert direct == sum(pieces) and all(pieces)
    return {"five_pieces_without_common_i_over_2": [str(value) for value in pieces],
            "direct_stationary_branch": str(direct)}


def main():
    started = time.perf_counter()
    watch = threading.Timer(120, lambda: os._exit(124))
    watch.daemon = True
    watch.start()
    for name, expected in read(HERE / "preparation_b.json")["sha256"].items():
        assert sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    checks = []
    for role in ("native", "replay"):
        data = read(CURRENT / f"{role}_complete_full_background_extension.json.gz")
        checks.append({"actual_chart": chart_control(data), "tree_bridges": reference_bridge(role, data)})
        print(f"STAGE {role} light probe square and compact source bridge checked", flush=True)
    assert checks[0] == checks[1]
    result = {"execution_state": "COMPLETED", "scientific_acceptance": "NOT_PERFORMED", "checks": checks[0],
              "odd": odd_control(), "nonlinear": nonlinear_control(), "seconds": time.perf_counter() - started}
    data = (json.dumps(result, sort_keys=True) + "\n").encode()
    name = "result_b.json" if len(data) <= 8 * 1024**2 else "result_b.COMPLETE_OVERFLOW_NOTPASS"
    with (HERE / name).open("xb") as stream:
        stream.write(data)
    assert name == "result_b.json"
    watch.cancel()


if __name__ == "__main__":
    main()
