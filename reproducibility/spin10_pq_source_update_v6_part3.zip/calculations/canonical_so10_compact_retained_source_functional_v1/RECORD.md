# V871 absolute compact retained-source comparison

Continue V870 on main, D:, under AGENTS. Keep the actual V869 compact
R_A-relative parent, the fixed flat COS1 reference and the V870 chart.
Reuse LAC1's relative cutoff factorization and derivative connection. The
new W1 question is whether an absolute connected functional and its graded
Legendre comparison preserve the same retained-source data as the corrected
proper prescription. A relative field comparison alone cannot answer it.

Phase A tests the actual direct tree contact in two independently smeared
even antighost-source directions at g0 and first H or M probe. Compare
literal two-strength polarization and successive left differentiation for
all 45 source coordinates. Keep the complete direct matrix including
cross-sector zeros. Use the actual S_GF/source and U packets, no selected
mean or adjusted reference. Since R_A is source-free, the direct source
seagull is multiplied by the literal compact switch. Bind the single-source
J_bar0 root and distinguish the reducible bridge from the direct contact.
In a diagnostic copy omit only the identified source-only square terms.
They have no ordinary Hessian or mean derivatives but their direct source
contact changes. This is a negative control and no adopted normalization.
Preserve background derivatives and all other central terms.

Phase A freezes sources and exact owners before the run. Root owns writes.
Limits are 120 seconds, 8 GiB sampled private memory, a 350 MiB launch
floor, 8 MiB result and 32 MiB packet. Final qualification awaits the
connected and Legendre bridge. Do not treat a source-only contact as a
computed loop or full connected response.

For phase B use the absolute causal family with all vacuum and central
factors. Subtract one source/background-independent constant only. Do
not evaluate the proper functional on a presumed Schwartz Feynman mean.
Construct its connected coefficient by COS1's cycle and full regulated
forest coordinates, then derive the graded Legendre tree removal at one
loop. The two independent even source derivatives must retain the direct
proper loop derivative, both mixed proper/mean orders, the double mean
sewing and the second mean derivative. Include the local C_fin+b contact
from the same parent. Check local disjoint-support additivity of that
correction before importing LAC1 for the normalized inputs. An insertion
strength supported in a shared plateau is distinct from a local affine
field action on the fixed free star product. Keep any actual connected
Ward contact or domain gap explicit. No global inverse heat, adiabatic
limit, protected promotion or full E5/A5 claim.
