# V877 one marked derivative of the compact connected master

Start at V876 `16878748` on main, D:. Ask whether the qualified proper
one-loop marked insertion transports to the same absolute connected
functional as V871 and V876, with its full source-dependent mean.
Use fixed full A, first g and first H or M u, theta=0, the original
real compact switch and one independent compact odd epsilon label.
Use constant odd LEFT beta and rho strengths in that order of extraction.
Every insertion vertex retains its compact support from the switched
parent. Fix the raw V848 Minkowski chart and the V876 source adapter
before any coefficient comparison. Keep the inherited full Feynman
inverse, reference term, common correction and regulated forests.

Freeze the proper and rooted owner proofs, receipts, actual g0 current
source and primitive packets, and the two calculation routes. Check
the signed tree stationarity, every ordered loop chain term, and an
actual color-12 tree coefficient. Use independent spacelike compact
test boxes, a switch varying near epsilon and zero near the ordinary
ghost-source support. Demonstrate both a nonzero direct term and its
opposite rooted term. A constant-patch zero or a test of only their sum
is insufficient. Use exact exterior arithmetic for a synthetic finite
sign fixture. Shared inputs and software do not imply independent
scientific acceptance.

Worker limit 120 seconds, final review 180 seconds, 8 GiB sampled
private memory, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.
The E4 subprocess retains 120 seconds and must return the established
step exits [0,0,0,0,0,2] with seven unresolved custody references.
Preserve failures and inputs. A mismatch or unproved support or sign
claim leaves the affected comparison incomplete. Success qualifies
one selected compact marked connected identity. No new loop integral,
physical adoption, arbitrary contact extension or protected promotion.
