"""Exact LEFT-chain fixture and actual separated switched-ghost control."""

import gzip
import json
import sys
from fractions import Fraction
import sympy as sp

from execute import PK, ROOT, run_worker

sys.path.insert(0, str(PK))
from source_convention_control import Exterior


CALC = ROOT / "calculations"
V848 = CALC / "canonical_so10_augmented_metric_lift_v1"
V865 = CALC / "canonical_so10_joint_common_family_applicability_v1"
ETA = (1, -1, -1, -1)


def exterior_control():
    e = Exterior()
    beta, rho, J, C, a = (e.variable(name, 1) for name in ("beta", "rho", "J", "C", "a"))
    x = e.variable("x", 0)
    x_symbol = e.even_symbols["x"]
    one = {(): sp.Integer(1)}
    x2 = e.mul(x, x)
    P = e.add(e.scale(x2, sp.Rational(3, 2)), e.scale(e.mul(C, a), 2), e.mul(J, C))
    K = e.add(e.mul(J, x), e.mul(x, a))

    def master(H):
        return e.mul(e.partial(H, "J"), e.partial(H, "x"))

    P_rho = e.add(P, e.mul(rho, K))
    B = master(P)
    M = e.partial(master(P_rho), "rho")
    assert M == e.derive(P, {"x": e.scale(e.partial(K, "J"), -1), "J": e.partial(K, "x")}, parity=0)
    Z = e.add(P_rho, e.mul(beta, master(P_rho)))
    tree = e.add(Z, e.scale(x, -3))

    def substitute(poly, even_x, odd):
        terms = []
        for word, coeff in poly.items():
            for (power,), c in sp.Poly(coeff, x_symbol).terms():
                factors = [odd.get(label, {(label,): sp.Integer(1)}) for label in word]
                terms.append(e.scale(e.mul(*([even_x] * power), *factors), c))
        return e.add(*terms)

    odd_mean = {"J": {}, "C": e.scale(rho, -sp.Rational(1, 2)), "a": e.scale(beta, sp.Rational(3, 2))}
    mean_x = e.add(one, e.scale(e.mul(beta, rho), 3))
    base = {"J": {}, "C": {}, "a": {}}

    def at_base(poly):
        return substitute(poly, one, base)

    def mixed(poly):
        return e.partial(e.partial(poly, "beta"), "rho")

    for i in ("x", "C", "a"):
        assert not substitute(e.partial(tree, i), mean_x, odd_mean), i
    tree_rhs = mixed(substitute(tree, mean_x, odd_mean))
    base_with_J = {"C": {}, "a": e.scale(J, sp.Rational(1, 2))}
    for i in ("x", "C", "a"):
        assert not substitute(e.partial(e.add(P, e.scale(x, -3)), i), one, base_with_J), i
    tree_lhs = e.scale(e.partial(substitute(K, one, base_with_J), "J"), -3)
    assert tree_lhs == tree_rhs == {(): -sp.Rational(9, 2)}
    assert e.scale(tree_lhs, -1) != tree_rhs

    b = {"a": e.partial(odd_mean["a"], "beta")}
    k = {"C": e.partial(odd_mean["C"], "rho")}
    c = {"x": mixed(mean_x)}
    F = e.add(x, e.mul(C, a))
    I_B, I_K = e.mul(x, C), e.mul(x, a)
    I_M, covariance = e.scale(x2, 2), e.scale(x, 5)
    loop = e.add(F, e.mul(beta, I_B), e.mul(rho, I_K), e.mul(beta, rho, e.add(I_M, covariance)))
    rooted_loop = substitute(loop, mean_x, odd_mean)
    direct = mixed(rooted_loop)
    terms = [I_M, covariance, e.derive(I_B, k), e.scale(e.derive(I_K, b), -1),
             e.derive(e.derive(F, b), k), e.derive(F, c, parity=0)]
    values = [at_base(term) for term in terms]
    assert all(values) and e.add(*values) == direct == {(): sp.Rational(35, 4)}
    reversed_order = e.partial(e.partial(rooted_loop, "rho"), "beta")
    assert reversed_order == e.scale(direct, -1)
    return {"tree_both_sides": str(tree_rhs[()]), "synthetic_six_terms": [str(term[()]) for term in values],
            "synthetic_direct": str(direct[()]), "reversed_extraction": str(reversed_order[()])}


def zipped_json(path):
    return json.loads(gzip.decompress(path.read_bytes()))


def actual_operands(role):
    data = V848 / ("tensor_7.json.gz" if role == "native" else "tensor_6.json.gz")
    base = zipped_json(data)["input_polynomial_Minkowski"]
    source_rows = [row for row in base if any(643 <= i < 1286 for i, _ in row[0])]
    assert all(any(i < 643 for i, _ in row[0]) for row in source_rows)
    C_rows = [row for row in source_rows if len(row[0]) == 2 and any(i == 565 for i, _ in row[0])]
    assert C_rows == [[[[565, [mu]], [691 + mu, []]], [[[0, 0, 0, 0], -1, 1]]] for mu in range(4)]
    a_rows = [row for row in source_rows if any(i == 1253 for i, _ in row[0])]
    assert a_rows == [[[[520, []], [1253, []]], [[[0, 0, 0, 0], -1, 1]]]]
    packet = zipped_json(V865 / f"{role}_complete_full_background_extension.json.gz")
    ghost = [[word, [cell for cell in cells if cell[0][0] == 0]]
             for grade, word, cells in packet["complete_S_GF_source"]
             if grade == 0 and any(i == 610 for i, _ in word) and any(k[0] == 0 for k, _, _ in cells)]
    assert ghost == [[[[565, [mu]], [610, [mu]]], [[[0, 0, 0], -1, 1]]] for mu in range(4)]
    p = packet["joined_parities"]
    assert p[565] == p[610] == 1 and p[1253] == 0

    K = zipped_json(V848 / "tensor_0.json.gz")["input_polynomial_Minkowski"]
    selected = [[word, [cell for cell in cells if cell[0][0] == 0]] for word, cells in K
                if any(i == 1286 for i, _ in word) and any(key[0] == 0 for key, _, _ in cells)]
    linear = [row for row in selected if len(row[0]) == 2]
    nonlinear = [row for row in selected if len(row[0]) != 2]
    assert linear == [*[[[[48 + mu, []], [1286, [mu]]], [[[0, 0, 0, 0], -s, 1]]]
                        for mu, s in enumerate(ETA)],
                      [[[520, []], [1286, []]], [[[0, 1, 0, 0], -1, 2]]],
                      [[[1253, []], [1286, []]], [[[0, 0, 0, 0], 1, 1]]]]
    assert len(nonlinear) == 56 and all(len(word) == 3 and not ({565, 610} & {i for i, _ in word})
                                        for word, _ in nonlinear)
    FB = [-cells[0][1] for _, cells in C_rows]  # LEFT J crosses C
    KB = [cells[0][1] for _, cells in linear[:4]]
    direct = [f * k for f, k in zip(FB, KB)]  # M=−F_B K_B, then put epsilon first
    assert direct == [-s for s in ETA]
    assert linear[-1][1][0][1] == -((-1)**p[610])  # raw D_a=+sigma epsilon
    return {"linear_K": linear, "literal_ghost": ghost, "base_C_sources": C_rows, "base_a_source": a_rows,
            "other_K_rows_disjoint_from_Ca": len(nonlinear), "direct_components": direct,
            "rooted_components": [-c for c in direct]}


def separated_support():
    t, r, damping, d = sp.symbols("t r epsilon d", real=True)
    a = damping + sp.I * t
    sine_integral = (1 / (a - sp.I * r) - 1 / (a + sp.I * r)) / (2 * sp.I)
    w = sp.cancel(sine_integral / (4 * sp.pi**2 * r))
    spacelike = 1 / (4 * sp.pi**2 * (r**2 - t**2))
    assert sp.cancel(w.subs(damping, 0) - spacelike) == 0
    assert sp.cancel(sp.diff(spacelike, t).subs(r**2, d + t**2) - t / (2 * sp.pi**2 * d**2)) == 0
    radius = Fraction(1, 8)
    early, late = 1 - 2 * radius, 1 + 2 * radius
    d_lo = (3 - 2 * radius)**2 - late**2
    d_hi = (3 + 2 * radius)**2 + 2 * (2 * radius)**2 - early**2
    w_derivative_lower = early / (2 * d_hi**2)
    direct_lower = 2 * (1 - radius) * w_derivative_lower
    assert (d_lo, d_hi) == (6, Fraction(81, 8))
    assert direct_lower == Fraction(14, 2187) > 0
    return {"support_boxes_radius": str(radius), "spacelike_d_bounds": [str(d_lo), str(d_hi)],
            "strictly_positive_direct_Im_lower_bound_times_pi_squared": str(direct_lower),
            "rooted_Im_upper_bound_times_pi_squared": str(-direct_lower),
            "complete_residual": 0, "drop_rooted_nonzero": True,
            "wrong_rooted_sign_Im_lower_bound_times_pi_squared": str(2 * direct_lower)}


def checks(role):
    return {"finite_exterior": exterior_control(), "actual_operands": actual_operands(role),
            "separated_pairing": separated_support()}


if __name__ == "__main__":
    run_worker(checks, sys.argv[1])
