# V877 selected compact marked connected master

One LEFT marked derivative transports from the qualified proper
identity to the absolute compact connected functional. In beta-rho
order the one-loop coefficient has two fixed-mean contributions and
four rooted contributions. The finite exterior check retains all six
and has a nonzero signed residual when their order is reversed.

The actual color-12 tree control uses independent spacelike epsilon
and ordinary antighost-source tests and a varying switch. Its direct
and rooted terms are separately nonzero, with opposite imaginary
coefficients in epsilon-first order. The direct scalar coefficient
is at least 14/(2187 pi^2). Their sum and the retained-source side
vanish in this test. The selected g0 operands were checked against
both owner data routes with the V876 source-chart repair.

The finite fixture measures a sign and rooted-ordering check, and the
actual witness is a tree comparison. The proper loop terms reuse
V868/V869 and the common regulated forests of V871. See [PROOF.md](PROOF.md)
and the separate receipt and capture. The result is limited to one
marked derivative in the inherited compact one-loop family. Broader
products, raw fixed-t transport, measure, quantum equivalence and
E5/A5 remain open.
