# Marked compact connected master and its rooted mean

## Same parent and ordered coefficient

Use V869's fixed-full-A compact parent P and K=K_sigma, the literal
switched odd primitive of V868. In either V876 chart set s_i=(-1)^p_i
for ordinary parity p_i, and write B[P]=integral sum w_i E_Ji P E_zi P
with LEFT Eulers. Take w_i=1 in the raw Minkowski chart and w_i=s_i
in the adapted signed chart. Let q_i=w_i s_i. Then

    M = [rho] B[P+rho K] = D_sigma P,
    D_sigma z_i = −q_i E_Ji K,   D_sigma J_i = q_i E_zi K,
    Z = P+rho K+beta B[P+rho K]
      = P+beta B[P]+rho K+beta rho M.

Indeed E_Ji(rho K)=−s_i rho E_Ji K and E_zi(rho K)=s_i rho E_zi K.
Moving rho past E_Ji P contributes −s_i. Thus M has ordered integrand
sum w_i(−s_i E_Ji K E_zi P−E_Ji P E_zi K). The two Euler factors
in the second term have the same parity 1−p_i. Their interchange
recovers the displayed D_sigma action. Apply Euler adjoints after
switching. This includes derivatives of the switch in any Euler
that takes a derivative slot. No uncut master or current is substituted.

The marked proper coefficient at one loop from V868/V869 is
I_M+V(K,B), the direct derivative in M and the ordered mixed proper
derivative from the two roots. At length two it contains K B−B K;
the direct M is separate. The compact parent, all derivatives through
first g and first H or M u, and the one possible negative beta defect
are in the V868 n<=10 local conversion proof. The full nonlocal words
are retained. V869 lifts this domain to full fixed A in the one flat
trace with its reference determinant. V871's unique cycle and rooted
tree factorization extends to the same parent Z by counting the two
strengths in its vertex labels. A beta-rho coefficient either has a
single mixed root or separate beta and rho vertices. The independent
cycle and bridge coordinates and finite jets give the same graphwise
pairing and the full regulated forest at either placement. In
particular, subtract the correlated finite-t forest, take the UV
finite part and then the paired IR boundary. This operation is on
labeled coefficients with compact tests and uses no arbitrary
Schwartz mean substitution or independently normalized coincident
contact. It retains the free absolute factor, the reference determinant
and the whole source-dependent finite correction.

## LEFT mean and source signs

With j fixed use the source-first stationary coupling j_i z_i.
Write the classical mean of Z as phi+beta b+rho k+beta rho c, where b,k
are odd tangent derivations and c is even. For frozen components
v use D_v H=sum v_i E_i H with the component on the left. The operator
D_k D_b on the mixed coefficient treats b as frozen and has component
sign (−1)^(p_i+1) on b_i k_j E_j E_i H. Here E_i denotes a partial
derivative on independent jet ports before graphwise polarization,
or the corresponding first variation with jets in the integrated
notation. In particular there is no derivative of a rooted tangent
along another one. The separate c accounts for the full mixed mean.

The stationarity equation is E_i Z+s_i j_i=0. Before substitution its
strength terms are s_i beta E_i B+s_i rho E_i K+beta rho E_i M. It follows
that D_b E_i P=−s_i E_i B and D_k E_i P=−s_i E_i K, and that

    D_c E_i P = −E_i M − D_k D_b E_i P
                − s_i(D_k E_i B−D_b E_i K).

Direct expansion of the common F(Z) on that mean gives

    [beta rho] W_1 = I_M+V(K,B)+D_k I_B−D_b I_K+D_k D_b F+D_c F.

The minus in front of D_b I_K comes from moving beta past rho in the
rho term. The two-root second derivative retains the same LEFT order.
At tree order stationarity cancels the c term in Z+integral j phi_Z.
The first mean equations give D_kD_bP=D_bK=−D_kB. Thus

    [beta rho] W_0 = M+D_k B = M−D_b K.

The full proper master and stationary Legendre relation of V875/V876
give −integral sum q_i j_i E_Ji W as LEFT_beta W[Z] at beta=0. Taking
LEFT rho crosses j_i and E_Ji with combined sign (−1)^(p_i+1−p_i)=−1.
Therefore the connected marked identity is

    +integral sum q_i j_i E_Ji I_K^W = [beta rho] W[Z],
    I_K^W = LEFT_rho W[P+rho K] at rho=0.

This comparison uses the fixed-mean proper identity and the full
rooted mean, with one common normalization. In particular the causal
correction C_fin+b is applied on Z before differentiation and on the
same rooted mean. Although b is linear as a proper map, its evaluation
on the deformed rooted mean has all applicable chain terms. The raw
causal marked residual is hbar times the mixed rooted correction
coefficient minus the connected source operator on its rho coefficient
with the positive sign displayed above. No independent contact term
is fitted and no raw fixed-heat conclusion is inferred.

## Actual separated varying-switch control

Use raw Minkowski color 12 at g=u=0 and A=J=0 after taking the retained
source derivative. Keep only j_a of that color and epsilon of the same
color. Write sigma=s chi, a compact switch with a formal even amplitude
s. V848 gives the actual linear K_B=−sigma partial^mu epsilon,
K_Lambda=−w sigma epsilon/2 and K_{J_a}=+sigma epsilon. The sharp
version uses the opposite J_a coefficient and the V876 adapter. The
actual raw source Eulers are F_B=sigma partial_mu C and F_a=−sigma Lambda.
The literal ghost kinetic input is V865's −partial C partial a with
its metric continuation. Use the original full switched stationarity,
so E_a=j_a exactly. All other E_i vanish on the tree mean.

For raw B, D_k F_i multiplies E_i and D_k E_i=−s_i E_i K.
Taking the odd derivative through F_i gives D_k B=integral sum
[(D_k F_i)E_i+F_i E_i K]. Thus all K_z terms in M cancel before the
projection. Choose chi zero near j_a. The remaining terms with E_a
have switched support and vanish separately. At switch grade s^2
both F_i and E_i K carry one chi, so their product uses only the free
mean C_0=G_Ca j_a=−D_F j_a and Lambda_0=0. The g0 linear F_B
and K_B operands then give, in epsilon-first order,

    M_2 = −integral chi^2 partial^mu epsilon partial_mu C_0,
    (D_k B)_2 = +integral chi^2 partial^mu epsilon partial_mu C_0.

The relevant source support has no other linear F_i along C_0 and no
field-free F_i. Higher field powers do not enter the one-j_a coefficient.
For the connected source side, E_{J_a} I_K^W has the direct K_{J_a}
and the mean derivative driven by the sigma-supported base J_a cross.
Both have a final sigma at the J_a slot. Thus the comparison with j_a
vanishes by support, while the two terms above can be nonzero.

Let x in U satisfy |x^mu|<1/8. Let y in V be within 1/8 in each
coordinate of (1,3,0,0). Take chi=1+x^0 near U, compact and zero
near V. Let epsilon and j_a be nonnegative normalized scalar bumps
in U and V times independent odd generators, respectively. The entire
pair is strictly spacelike, with t=x^0−y^0 in (−5/4,−3/4) and
d=|x_spatial−y_spatial|^2−t^2 between 6 and 81/8. CWB1 graded time
ordering gives iG_Ca=w here with w=1/(4 pi^2 d). The negative time
order uses −W_aC and the two signs cancel. Hence D_F=i w on the pair.
The same expression follows from the damped positive-frequency angular
integral with Abel limit at spacelike separation. If F=D_F j_a,
integration by parts twice uses Box F=0 near epsilon and gives

    M_2 = −2 integral epsilon chi partial chi . partial F.

Since partial_0 w=t/(2 pi^2 d^2), chi>=7/8 and partial_0 chi=1 with
zero spatial derivative there, the imaginary scalar coefficient of
the ordered odd generators in M_2 is at least 14/(2187 pi^2).
The rooted term has the negative of this coefficient. There is no
singular diagonal product in this control. A plateau switch would
annul this separated test because partial chi=0 on U. A retarded
or advanced bridge would also annul it by spacelike support. Keeping
only M_2 would leave the nonzero residual, and changing the rooted
sign would double it. This is a tree witness for the mean term, not
a measurement of a model loop amplitude.

The finite exterior fixture uses a synthetic loop map solely to test
all six ordered coefficients and the tree source sign. The actual
proper loop terms remain the qualified V868/V869 inputs. The compact
one-loop marked result leaves arbitrary contact products, the raw
fixed-t paired domain, quantum equivalence, measure and E5/A5 open.
