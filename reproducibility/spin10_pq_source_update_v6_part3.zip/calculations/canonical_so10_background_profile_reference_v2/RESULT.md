# V977 · Background profile reference

The actual 4,025 ordered Weyl rows and 7,800
homogeneous carrier rows preserve the H/M quartet
split. The V976 relative functional therefore extends
to the V869 expanded fixed-flat background domain.

Each pure reference sector needs its own conversion.
Its relative raw finite part is minus its log residue
times the logarithm of the clock ratio. The ghost
indices at e1 are 3 and 5. The full quartet at
diagnostic width one has nonzero residue
`g² I_s p² A²/(384π²)` on the transverse Fourier pair.
The converted reference is kept once.

V1 used the e1 Gram values on the e0 row and stopped.
V2 verifies both rows and preserves the failed packet.
No width or covariant heat operator was adopted.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
