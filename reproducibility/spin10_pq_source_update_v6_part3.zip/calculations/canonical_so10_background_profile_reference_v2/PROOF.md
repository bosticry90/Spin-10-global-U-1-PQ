# Relative profiles on the expanded compact background parent

Use the V869 fixed-flat prescription with the
external light connection as a retained label.
The reference is the actual ordered K_A. Set
X=G_0(K_A-K_0) and Y=G_0(H_Z-K_A) with the
literal compact Z. Assign each free edge its
own flat scalar heat profile before composing
X or Y. The new profile is matched within each
gauge/ghost quartet, with separate positive H
and M lengths. Keep the other profiles fixed.

In the current chart the actual homogeneous
background matrices preserve both quartet
projectors. The ordered K_A coefficients do
as well, including the mixed and odd blocks.
Thus every pure X path in a quartet stays in
one sector. The raw fixed-flat determinant
for that sector at length ell is the old
regulated determinant at t ell/ell0, with the
same IR profile. Subtract its flat reference
value at the same length. If L_ref is its
logarithmic residue, complete finite parts
give

    H_ref,ell-H_ref,ell0 = -L_ref log(ell/ell0).

This uses dilation of the complete regulated
word, so its power subtractions dilate along
with its positive heat jets. The same holds
with independent sector lengths after splitting
the pure X trace. A flat vacuum constant has
no background or source derivative. The pure
reference conversion is therefore added once
as the negative of this relative raw change.
There is no additional determinant phase.

In mixed X,Y words, A and its derivatives
stay external and the sector factors stay on
their respective lines. The unheated ordered
word is unchanged. The V869 independent-
transfer and hard word estimates supply the
same domain. The proof of V976 then applies
with its positive transfer jets retained. For
the raw heat functional split the reference
by evaluating it on K_A and subtracting the
flat value, not by cyclically factoring the
regulated logarithm. For the converted
functional the existing cyclic factorization
of V869 is unchanged. Its exact relative
conversion is the total conversion minus
the pure reference conversion. This matches
background derivatives of the same total
functional. The reference determinant and
its affine current remain in the background
identity. Keep the old causal b(Z) on the
whole parent if making that comparison.
As a nonblind pure reference check, select
the actual light background generator e1 and
the ghost pair block. Its Weyl coefficients
are opposite ordered D² blocks, so the
relative trace log reduces to minus one
trace of the corresponding covariant
Laplace operator. The flat trace pairing
is the Euclidean one-loop convention
used here. Let I_s=tr_s(r_h^t r_h) for
sector s. The two first-order background
vertices give g² I_s (2q+p)·A squared,
with +1/2 from the paired ghost logarithm.
For p·A=0 the hard angular coefficient
of the bubble at r^-4 is -p² A²/3. One
calculation uses the spherical second
and fourth moments directly. Another
uses the Feynman parameter shift, for
which the coefficient is
-2 p² A² integral_0^1 x(1-x) dx.
The massless seagull has no log term.
Thus this ghost part has log coefficient
-g² I_s p² A²/(96 pi²), in the trace
with A(p),A(-p) paired by the momentum
integral. Its relative raw finite part is
the opposite of that coefficient times
log(ell_s/ell0_s). The ghost control does
not use the gauge block. For a separate
full quartet control, evaluate the actual
unheated ordered log at width one. The
auxiliary Schur complement of the V869
Weyl operator is

    -D² delta_(mu,nu) - [D_mu,D_nu]/2.

The auxiliary determinant is constant.
At critical degree the unheated log
residue permits the cyclic Schur trace.
Four minimal vector components and the
ghost pair give -tr Omega²/(192 pi²),
where Omega=[D,D]. The vector curvature
term has zero first Lorentz trace. Its
square gives +tr Omega²/(256 pi²).
Their sum is -tr Omega²/(768 pi²), or
+g² I_s p² A²/(384 pi²) on the same
transverse Fourier pair. The opposite
relative finite shift times log(ell_s/ell0_s)
is nonzero. This width-one check is a
test of the raw reference change. It
does not set widths in the construction
or factorize the regulated heat trace.

The actual carriers and Weyl pairing
are read from the V869 transported data,
and checked against the V791 flat inverse
and the joined light bracket Gram.
The two routes share the physical and
symbolic premises. This extends the
relative correction only on the V869
expanded fixed-flat background domain.
A genuine covariant heat profile has
ordered Duhamel insertions on both
halves, with an evaluation dual. It
cannot be inferred by commuting an
exponential through the background
inverse. The marked and explicit
regulator insertions require separate
comparisons.
