"""Check the actual sectorwise background reference profile conversion."""

from collections import defaultdict
import importlib.util
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def joined(phase):
    path = ROOT / "calculations/canonical_so10_gauge_first_switch_rank_v1/first_switch_rank.py"
    spec = importlib.util.spec_from_file_location("first_switch_owner",path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    source = module.load_literal().load_owner()
    return source.owner.inputs(phase)[3]


def quartet(i):
    if i < 180:
        return int(i//4 >= 12)
    if 508 <= i < 643:
        return int((i-508)%45 >= 12)
    return None


def actual_reference(phase):
    base = ROOT / "calculations/canonical_so10_current_background_reference_bridge_v1"
    parent = json.loads((base/"result_a.json").read_bytes())["compared"]
    receipt = json.loads((base/"validation_receipt.json").read_bytes())
    assert receipt["execution_state"] == "COMPLETED"
    words = parent["transported_ordered_Weyl_coefficients"]
    assert len(words) == 4025
    assert all(quartet(i)==quartet(j) for i,j,_,_ in words)
    data = {(i,j,tuple(d)):sp.sympify(v) for i,j,d,v in words if i>=553 and j>=553}
    expected = {(i,j,(mu,mu)):sgn
                for c in range(45) for mu in range(4)
                for i,j,sgn in ((553+c,598+c,1),(598+c,553+c,-1))}
    assert data == expected
    rows = parent["twelve_current_homogeneous_carriers"]
    assert len(rows)==12 and sum(map(len,rows))==7800
    assert all(quartet(i)==quartet(j) for R in rows for i,j,_ in R)
    assert all(i!=j for R in rows for i,j,_ in R)
    ghost = []
    for R in rows:
        C = {(i-553,j-553):sp.sympify(z) for i,j,z in R if 553<=i<598 and 553<=j<598}
        a = {(i-598,j-598):sp.sympify(z) for i,j,z in R if i>=598 and j>=598}
        assert C==a and all(C[j,i]==-z for (i,j),z in C.items())
        ghost.append(C)

    f = joined(phase)
    def gram(table,second,lo,hi):
        return sp.simplify(sum(z*second.get(key,0) for key,z in table.items() if lo<=key[0]<hi))

    adj = [{(i,j):z for j in range(45) for i,z in f[h,j]} for h in range(12)]
    result = []
    for lo,hi in ((0,12),(12,45)):
        direct = sp.Matrix(12,12,lambda h,k:gram(ghost[h],ghost[k],lo,hi))
        replay = sp.Matrix(12,12,lambda h,k:gram(adj[h],adj[k],lo,hi))
        assert direct==replay
        result.append(direct)
    assert result[0]+result[1]==8*sp.eye(12)
    assert [mat[0,0] for mat in result]==[sp.Rational(5,2),sp.Rational(11,2)]
    assert [mat[1,1] for mat in result]==[3,5]

    w = {(i,j,tuple(d)):sp.sympify(v) for i,j,d,v in words
         if (i<180 or 508<=i<553) and (j<180 or 508<=j<553)}
    expected_w = defaultdict(lambda:sp.S.Zero)
    for c in range(45):
        aux = 508+c
        expected_w[aux,aux,()] = sp.Symbol("eta_H" if c<12 else "xi")
        for mu in range(4):
            i = 4*c+mu
            expected_w[i,aux,(mu,)] = -sp.I
            expected_w[aux,i,(mu,)] = sp.I
            for nu in range(4):
                j = 4*c+nu
                expected_w[i,j,(mu,nu)] += sp.S.Half
                expected_w[i,j,(nu,mu)] += sp.S.Half
                if mu==nu:
                    for alpha in range(4):
                        expected_w[i,j,(alpha,alpha)] -= 1
    assert w == {key:z for key,z in expected_w.items() if z}
    return len(words),sum(map(len,rows)),len(w)


def residues():
    P,A,g,I,ell,old = sp.symbols("P A g I ell old",positive=True)
    x = sp.Symbol("x")
    hard = 4*(-P*A/4+4*P*A/24)
    shifted = -2*P*A*sp.integrate(x*(1-x),(x,0,1))
    assert hard == shifted == -P*A/3
    ghost = g**2*I*hard/(32*sp.pi**2)
    assert ghost == -g**2*I*P*A/(96*sp.pi**2)

    Dmu,Dnu = sp.symbols("Dmu Dnu",commutative=False)
    mixed = (-sp.I*Dmu)*(sp.I*Dnu)
    assert sp.expand((Dmu*Dnu+Dnu*Dmu)/2-mixed+(Dmu*Dnu-Dnu*Dmu)/2)==0
    omega_squared = -2*g**2*I*P*A
    minimal = -omega_squared/(192*sp.pi**2)
    spin = omega_squared/(256*sp.pi**2)
    quartet = sp.simplify(minimal+spin)
    assert quartet == g**2*I*P*A/(384*sp.pi**2)
    delta = -quartet*sp.log(ell/old)
    assert delta.subs(ell,old)==0 and delta.subs(ell,2*old)!=0
    H0,C0 = sp.symbols("H0 C0")
    assert sp.expand((H0+delta)+(C0-delta)-(H0+C0)) == 0
    assert sp.expand((H0+delta)+(C0-2*delta)-(H0+C0)) != 0


def check(phase):
    words,carriers,gauge = actual_reference(phase)
    residues()
    return {"ordered_reference_rows":words,"homogeneous_carrier_rows":carriers,
            "paired_vector_auxiliary_Weyl_rows":gauge,
            "ghost_Gram_H_M_on_e1":[3,5],
            "ghost_log_coefficient":"-g^2 I_s p^2 A^2/(96 pi^2)",
            "width_one_quartet_log_coefficient":"g^2 I_s p^2 A^2/(384 pi^2)",
            "separate_reference_conversion_once":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
