"""Check the stationary pullback signs by direct graded evaluation."""
import sys

import sympy as sp

from execute import PK, run_worker

sys.path.insert(0,str(PK))
from source_convention_control import Exterior


def check(_phase):
    e = Exterior()
    beta,rho,J,C,a,ja = (e.variable(n,1) for n in ("beta","rho","J","C","a","ja"))
    x,h,Ja = (e.variable(n,0) for n in ("x","h","Ja"))
    one = {():sp.S.One}
    Q = sp.Rational
    x2 = e.mul(x,x)
    P = e.add(e.scale(x2,Q(3,2)),e.scale(e.mul(C,a),2),e.mul(J,C))
    K = e.add(e.mul(J,x),e.mul(x,a))
    P_rho = e.add(P,e.mul(rho,K))

    def master(H):
        return e.mul(e.partial(H,"J"),e.partial(H,"x"))

    def N(H):
        U = e.partial(H,"x")
        return e.mul(x2,U,U)

    def at(poly,xval,odd):
        terms = []
        for word,coefficient in poly.items():
            for (power,),c in sp.Poly(coefficient,e.even_symbols["x"]).terms():
                factors = [odd.get(n,{(n,):sp.S.One}) for n in word]
                terms.append(e.scale(e.mul(*([xval]*power),*factors),c))
        return e.add(*terms)

    def at_base(poly):
        return at(poly,one,{"J":{},"C":{},"a":{}})

    def mixed(poly):
        return e.partial(e.partial(poly,"beta"),"rho")

    Z = e.add(P_rho,e.mul(beta,master(P_rho)))
    zmean = e.add(one,e.scale(e.mul(beta,rho),3))
    zodd = {"J":{},"C":e.scale(rho,-Q(1,2)),"a":e.scale(beta,Q(3,2))}
    pmean = e.add(one,e.scale(e.mul(rho,J),-Q(1,2)))
    podd = {"C":e.scale(rho,-Q(1,2)),"a":e.scale(J,Q(1,2))}
    for H,mean,odd in ((Z,zmean,zodd),(P_rho,pmean,podd)):
        tree = e.add(H,e.scale(x,-3))
        assert all(not at(e.partial(tree,n),mean,odd) for n in ("x","C","a"))
    rhs = mixed(at(N(Z),zmean,zodd))
    I = e.partial(at(N(P_rho),pmean,podd),"rho")
    lhs = e.scale(e.partial(I,"J"),-3)
    assert (lhs,rhs)==({():27},{():54})

    def variants(H):
        F = N(H)
        hvar = master(e.add(H,e.mul(h,F)))
        outward = e.partial(hvar,"h")
        outward = {w:v.subs(e.even_symbols["h"],0) for w,v in outward.items()}
        inward = e.partial(N(e.add(H,e.mul(beta,master(H)))),"beta")
        return e.clean(outward),inward

    outward,inward = variants(P_rho)
    direct_parts = [at_base(e.partial(x,"rho")) for x in (outward,inward)]
    assert direct_parts==[{():-54},{():-36}]
    direct = e.add(direct_parts[0],e.scale(direct_parts[1],-1))
    out0,in0 = variants(P)
    Delta = e.add(out0,e.scale(in0,-1))
    rooted = at_base(e.derive(Delta,{"C":{():-Q(1,2)}}))
    defect = e.add(lhs,e.scale(rhs,-1))
    assert direct=={():-18} and rooted=={():-9}
    assert e.add(direct,rooted)==defect=={():-27}
    assert direct!=defect and e.add(direct,e.scale(rooted,-1))!=defect

    controls = 0
    for ordinary_source,Jname,odd_insertion in (({():-3},"J",J),(ja,"Ja",e.mul(Ja,C))):
        raw = e.scale(e.mul(ordinary_source,e.partial(e.mul(rho,odd_insertion),Jname)),-1)
        after = e.mul(ordinary_source,e.partial(odd_insertion,Jname))
        assert after and e.partial(raw,"rho")==after
        controls += 1
    return {"connected_source_and_beta":[str(lhs[()]),str(rhs[()])],
            "proper_direct_and_rooted":[str(direct[()]),str(rooted[()])],
            "proper_marked_variations":[str(x[()]) for x in direct_parts],
            "connected_defect":str(defect[()]),"left_source_parity_controls":controls}


if __name__=="__main__":
    run_worker(check,sys.argv[1])
