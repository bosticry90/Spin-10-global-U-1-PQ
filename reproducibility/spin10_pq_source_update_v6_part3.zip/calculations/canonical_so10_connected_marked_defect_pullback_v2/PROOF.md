# Stationary pullback of the marked finite-map defect

Use the same compact parent and fixed-j stationary domain as V875 and V877, with the V877 adapted or raw LEFT source chart. Let N[H] be an even differentiable local finite correction on that domain, with every insertion defined by derivatives of this same map. Hold the reference, regulator dictionary and actual ordinary sources fixed. The comparison is linear in N at one loop. The symbol h is an even formal variation, not a new physical parameter.

Write φ(H) for the tree mean at fixed j, S_j=−Σ_i q_i ∫ j_i E_(J_i) for the ordinary connected source operator, and B[H] for the classical master. For any even H, the V875 stationary identity is S_j W_0[H]=B[H](φ(H)). Indeed E_J W_0=E_J H at the mean and E_i H=−s_i j_i. The exchange of E_J H with j_i has exponent p_i(p_i+1)=0. The same identity holds with formal even H=P+rho K_σ.

The h derivative of W_0[H+hN[H]] is W_N[H]=N[H](φ(H)) by stationarity. Differentiate the ordinary identity at h=0. With u the even first mean response to N[H], the right side gives B'_H N(φ)+D_u B(φ). The LEFT beta derivative of W_N[H+beta B[H]] is N'_H B(φ)+D_b N(φ), with b the V875 odd mean response. Their two rooted terms coincide by taking the mixed h,beta derivative of the stationary value of H+hN[H]+beta B[H], with both operands frozen at H. Stationarity eliminates the derivative of the mean from the first derivative in either order. The order swap has no sign because h is even. Consequently the connected source-minus-beta defect is

    S_j W_N[H] − LEFT_beta W_N[H+beta B[H]] = Δ[H](φ(H)),
    Δ[H] = B'_H N − N'_H B.

This identity includes the differentiated mean. It does not require a vanishing proper residual.

Take LEFT rho on the preceding identity at H=P+rho K_σ. Moving it through j_i and E_(J_i) gives the total sign −1 since their parities are p_i and 1−p_i. The connected marked source therefore has the positive V877 sign, and LEFT rho after LEFT beta takes the coefficient of beta rho. On the right φ(P+rho K_σ)=φ+rho k. In the first-order field expansion the left component is rho k_i, so the rooted variation has a plus sign. Thus, with I_K^W=LEFT_rho W_N[P+rho K_σ],

    +Σ_i q_i ∫ j_i E_(J_i) I_K^W − [beta rho] W_N[Z]
       = ([rho] Δ[P+rho K_σ] + D_k Δ[P])(φ).

The direct term is the full local proper transfer, including the two-root derivative of N. The rooted term uses the actual marked mean equation of V877. The formula reorganizes the six connected terms only for this finite correction. It provides no permission to remove a nonzero mean term or change the reference. In particular V1039 only sets its selected direct proper coefficient to zero. Any ordinary defect whose first mark can reach that projection must still be tested, along with the field expansion of the proper and rooted outputs at the same mean.

For a nonzero exact check use the V877 finite exterior parent P=3x²/2+2Ca+JC, K=Jx+xa and j_x=−3. Take N[H]=x²(E_x H)². Both exact stationary means are verified before evaluating N. The direct connected source and beta-rho results are 27 and 54. Expanding the two ordinary proper variations at P+rho K gives marked coefficients −54 and −36. Their difference is −18, while D_k Δ gives −9. Both residuals equal −27. Dropping or reversing the rooted term fails. The odd and even ordinary source cases also verify the total LEFT sign separately. A second analytic fixture with N[H]=xH gives −27/4 in both representations.

This is an identity for differences induced by one finite map on the admitted compact stationary domain. It does not establish the full causal product domain, marked quantum right side, a normalization baseline, or E5/A5.
