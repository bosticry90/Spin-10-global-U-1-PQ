# Bounded marked defect pullback V1040

Freeze the V875 and V877 stationary and sign conventions and V1039 proper transfer. Derive the connected finite-map defect for the same marked parent and mean. Test a nonzero quadratic-map fixture with both proper variations and the rooted term retained. Reversing or removing the rooted term must fail. Keep the actual V1034 ordinary-root inventory and higher marked right side unmeasured in this step. The ceiling is an exact formal stationary identity on the existing compact domain. Historical custody exit 2 remains unresolved.

## V2 verification

The V1 verifier used expected intermediate values from a linear map for the frozen quadratic map. A read-only exact diagnostic gives −54 and −36. Their difference remains −18. V2 changes only the two fixture expectations and corrects their explanation. The original native capture and every original packet byte are hashed under the V1 control directory. No scientific criterion or expected combined defect changes.
