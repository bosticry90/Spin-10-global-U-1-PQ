# V1040 · Stationary pullback of the connected marked defect

For one even finite correction N on the admitted compact stationary domain, define Δ[P]=B'_P N−N'_P B. The connected source-minus-beta residual equals Δ on the same tree mean. After the ordered LEFT rho derivative the residual equals the direct marked proper defect plus the marked mean derivative D_k Δ, both on that mean. The mean-response terms agree by mixed stationary differentiation, so the equality retains their effects.

The exact fixture gives connected source 27 and beta-rho coefficient 54. The two direct proper variations give −54 and −36, and the rooted variation is −9. Both defect representations give −27. Omitting or reversing the root fails. Both source parities pass the LEFT sign check.

V1 failed its two intermediate expectation assertions. It used values from a linear map for the quadratic fixture. V2 corrects them and retains the same combined expectation. V1 is preserved under its external control record. The qualified result is a transport identity for a common finite map, with the actual V1034 rooted coefficients still to be evaluated.
