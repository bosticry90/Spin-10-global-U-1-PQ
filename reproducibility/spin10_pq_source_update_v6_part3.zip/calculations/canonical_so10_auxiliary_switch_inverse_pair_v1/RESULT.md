# V967 · Auxiliary switch inverse pair

The literal auxiliary driver produces 180 nonzero
ordered transverse gauge-source cells in the MM
sector. Its first mixed inverse insertion has the
opposite switch numerator and retains the third
cutoff profile. The combined selected coefficient is

    s² (∂s) Q_Lambda [w2 − (1−s) w3].

Equal finite weights remove its `s²∂s` component
and leave the `s³∂s` term. For the inherited heat
lengths the nonexceptional difference is
`w3−w2=−3 log(3/2)/(64π²)`. Differentiating the
extra profile does not enter the first switch jet.

Both exports agree on the 3,344 literal auxiliary
source rows and the complete contracted tensor.
The ordinary first-switch current and remaining
normalization obligations require separate tests.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
