# V967 pre-execution contract

Freeze the V879 unprobed compact density and V791 free
inverse, the V894 mixed switch kernel, and the V947
nonexceptional heat comparison. At A=0 and zero broken
width, evaluate the selected g2 auxiliary-source
contribution to the first common switch derivative
of the transverse J_B CC master product. Check the
literal quartic and its returning color contraction
in both exports. Compare the explicit two-edge term
to one mixed quadratic switch insertion on the
plateau divergence. Keep separate fixed nonexceptional
heat weights and the selected collapsed local jet.
Failure of either literal or inverse comparison stops
qualification. No new prescription or full gauge
closure is claimed.

Native 120 s, final 180 s including E4 cap 120 s,
8 GiB sampled private, 350 MiB launch floor,
8 MiB artifact and 32 MiB packet. No authority change.
