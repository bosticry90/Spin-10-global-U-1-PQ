# Auxiliary-source first-switch contact and its mixed inverse companion

In the unprobed zero-background density the mixed
quadratic is i Lambda div B. Its symmetric reference
leaves the compact term -(i/2)(partial s) B Lambda.
Use the V879 compact master decomposition, treating
the uncut master as an integrated divergence with
its current retained. The auxiliary-source driver
at grade two supplies both an explicit first switch
term -(i/2)s (partial s) B q_Lambda,2 and a reference
plateau term i s(1-s) q_Lambda,2 div B. The ordinary
uncut current is a separate first-switch input.

In the original Grassmann order the literal coefficient
of C_b C_c a_i J_Lambda,u (b<c) is

    z=i sum_(h in H) f_(u i h) f_(h b c),

with all four ports in M. The signed source driver is
-z C_b C_c a_i. Moving the odd source of the other
vertex and its contracted ghost to source-first order
compensates the minus in the raw J_B cubic. Strip the
common two-edge factor. The explicit term then has
ordered color

    Q_Lambda(a,b,c)= -1/2 ((8 P_H-C_H)[b,c]_H)_a,

with b,c in M and zero otherwise. The identity follows
from the M adjoint sum on H. The executable checks every
literal quartic coefficient and the contracted map.

For the plateau divergence use momenta u=v+r in
the switched inverse, with r carried by the switch.
The zero-width broken transverse block obeys
u^T G_BB(u)=0 and u^T G_B,Lambda(u)=-1. The V894
quadratic switch has Q_Lambda,B=r^T/2 and
Q_Lambda,Lambda=0. Therefore

    u^T (-G(u) Q G(v))_BB = r^T G_BB(v)/2.

This uses the order and minus sign of the first
inverse variation. It kills the Maxwell and other
terms of this projection without setting their
matrices to zero. The surviving r converts the
plateau divergence into the opposite first-switch
numerator to the explicit term. Multiplying by
the source-vertex switch gives

    s^2 (partial s) Q_Lambda [w2-(1-s) w3].

At fixed positive cutoffs the left and right inverse
edges carry separate profiles. There is already an
explicit r, so differentiating those profiles gives
no first-switch coefficient. The ghost retains its
distinct transfer in this relative comparison.
Thus the extra collapsed line leaves one profile
on the common transverse primitive, even though
the free denominator cancels. V947 gives in equal
per-edge heat lengths and common subtraction

    w3-w2 = -3 log(3/2)/(64 pi^2)

in the stripped transverse radial units, for fixed
nonexceptional gauge/ghost transfer. Equal finite
weights would move the selected s^2 shape to s^3.
The inherited heat values instead leave a separate
s^2(1-s) difference. This statement concerns the
relative term on the selected local numerator,
not the exceptional massless integral or the full
compact nonlinear product. Omitting Q_Lambda,B
kills the inverse contribution and fails the
comparison. The ordinary first-switch current,
other switched insertions, finite map changes and
marked products remain open. The two replays share
the model, conventions and software.
