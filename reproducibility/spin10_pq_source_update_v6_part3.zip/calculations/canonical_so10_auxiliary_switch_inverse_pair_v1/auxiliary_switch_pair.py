"""Check the auxiliary-source color and first mixed inverse insertion."""

from collections import defaultdict
import importlib.util
import sys

import mpmath as mp
import sympy as sp

from execute import ROOT, run_worker


def owner():
    path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
    spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
    source = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(source)
    return source


def auxiliary_rows(source, phase):
    folder = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = source.seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    literal = {}
    for g, word, cells in rows:
        if g != 2 or len(word) != 4:
            continue
        (b,eb),(c,ec),(i,ei),(u,eu) = word
        if not (553 <= b < c < 598 and 598 <= i < 643 and 1151 <= u < 1196):
            continue
        assert not (eb or ec or ei or eu)
        assert all(p[:2] == [0,0] for p,_,_ in cells)
        key = b-553,c-553,i-598,u-1151
        assert min(key) >= 12 and key not in literal
        literal[key] = source.seagull.unpack([([0,*p],n,d) for p,n,d in cells])
    assert len(literal) == 3344
    return literal


def color(phase):
    source = owner()
    _, _, _, f, _, _ = source.owner.inputs(phase)
    literal = auxiliary_rows(source, phase)
    by_h = {h: [(i,u,z) for i in range(12,45) for u,z in f[i,h]]
            for h in range(12)}
    expected = defaultdict(lambda: sp.S.Zero)
    for b in range(12,45):
        for c in range(b+1,45):
            for h,value in f[b,c]:
                if h < 12:
                    for i,u,z in by_h[h]:
                        expected[b,c,i,u] += sp.I*value*z
    assert source.owner.clean(expected) == literal

    explicit = defaultdict(lambda: sp.S.Zero)
    for (b,c,i,u),value in literal.items():
        for a,z in f[u,i]:
            explicit[a,b,c] += sp.I*value*z/2
    explicit = source.owner.clean(explicit)
    H = defaultdict(lambda: sp.S.Zero)
    for h in range(12):
        for k in range(12):
            for j,x in f[k,h]:
                for a,y in f[k,j]:
                    H[a,h] -= x*y
    comparison = defaultdict(lambda: sp.S.Zero)
    for b in range(12,45):
        for c in range(b+1,45):
            for h,z in f[b,c]:
                if h < 12:
                    for a in range(12):
                        comparison[a,b,c] -= (8*int(a==h)-H[a,h])*z/2
    assert source.owner.clean(comparison) == explicit
    assert len(explicit) == 180 and all(a < 12 for a,_,_ in explicit)
    assert explicit[0,13,14] == 19*sp.sqrt(10)/40
    return len(literal),len(explicit)


def inverse():
    eps = sp.Symbol("eps", real=True)
    v = sp.Matrix([1,0,0,0])
    r = sp.Matrix([0,eps,0,0])
    u = v+r

    def free(q):
        Q = q.dot(q)
        bb = sp.eye(4)/Q-q*q.T/Q**2
        return bb.row_join(-q/Q).col_join((q.T/Q).row_join(sp.zeros(1)))

    Qbb = (-r.dot(r)*sp.eye(4)-v*r.T+r*u.T)/2
    switch = Qbb.row_join(r/2).col_join((r.T/2).row_join(sp.zeros(1)))
    projected = (u.T*(-free(u)*switch*free(v))[:4,:4]).applyfunc(sp.cancel)
    target = r.T*free(v)[:4,:4]/2
    assert projected == target == sp.Matrix([[0,eps/2,0,0]])
    switch[4,:4] = sp.zeros(1,4)
    assert (u.T*(-free(u)*switch*free(v))[:4,:4]).applyfunc(sp.cancel) == sp.zeros(1,4)

    F0, F1, G0, G1 = sp.symbols("F0 F1 G0 G1")
    dressed = (projected*(F0+eps*F1)*(G0+eps*G1)).applyfunc(sp.expand)
    assert dressed.diff(eps).subs(eps,0) == target.diff(eps)*F0*G0


def weights():
    s, w2, w3 = sp.symbols("s w2 w3")
    result = s**2*(w2-(1-s)*w3)
    assert sp.expand(result-s**3*w2-s**2*(1-s)*(w2-w3)) == 0
    assert sp.expand(result.subs(w3,w2)) == s**3*w2
    assert sp.expand((result-s**3*w2).subs(s,sp.Rational(1,2))-(w2-w3)/8) == 0
    with mp.workdps(40):
        difference = mp.quad(lambda x: mp.exp(-4*x)*mp.expm1(-2*x)/x,[0,1,mp.inf])
        assert abs(difference+mp.log(mp.mpf(3)/2)) < mp.mpf("1e-38")


def check(phase):
    raw, contracted = color(phase)
    inverse()
    weights()
    return {"literal_qLambda_rows":raw,"explicit_MM_cells":contracted,
            "explicit_MM_pivot":"19*sqrt(10)/40",
            "opposite_inverse_numerator":True,"profile_first_derivative_enters":False,
            "selected_weight":"s^2 ds QLambda (w2-(1-s)w3)",
            "relative_inherited_heat_weight":"-3*log(3/2)/(64*pi^2)"}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
