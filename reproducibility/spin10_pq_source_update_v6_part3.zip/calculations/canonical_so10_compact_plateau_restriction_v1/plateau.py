"""Apply the two unit certificates on distinct constant compact plateaus."""

import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def read(folder):
    path = ROOT / "calculations" / ("canonical_so10_"+folder) / "result.json"
    return json.loads(path.read_bytes())["checks"]


def check(phase):
    bubble = read("joint_contact_gauge_square_v1")["literal_ordered_sector_rows"]
    mixed = read("mixed_gauge_source_triangle_v1")
    first, second = ([sp.sympify(z) for z in row] for row in bubble)
    square_B = [first[i]+first[i+2]-second[i]-second[i+2] for i in range(2)]
    assert square_B == [sp.Rational(1,5),-sp.Rational(1,10)]
    square_T = [sp.simplify(sp.sympify(z)/sp.I) for z in mixed["gauge_square_triangle"]]
    metric_T = [sp.simplify(40*sp.sympify(z)/(sp.I*sp.sqrt(10))) for z in mixed["metric_triangle"]]
    assert square_T == [sp.Rational(1,10),-sp.Rational(1,5)]
    assert metric_T == [1,-1]
    s = sp.Symbol("s")
    gates = sp.Matrix([[1,-1,s*metric_T[0],s*metric_T[1]],square_B+[s*z for z in square_T]])
    stacked = gates.subs(s,1).col_join(gates.subs(s,sp.Rational(1,2)))
    assert gates.subs(s,1)*sp.ones(4,1) == sp.zeros(2,1)
    assert stacked.rank() == 4 and stacked.det() != 0
    assert (gates*sp.ones(4,1)-sp.Matrix([0,(1-s)/10])).applyfunc(sp.simplify) == sp.zeros(2,1)

    WB, WT = sp.symbols("W_B W_T")
    singlet = 8+8*WB
    center = 8*WB-8*s*WT
    assert sp.solve((singlet,center.subs(s,1)),(WB,WT)) == {WB:-1,WT:-1}
    assert sp.solve((singlet,center.subs(s,1),center.subs(s,sp.Rational(1,2))),(WB,WT)) == []
    assert sp.simplify(s**3*center.subs({WB:-1,WT:-1})+8*s**3*(1-s)) == 0
    return {"gauge_two_plateau_rank":stacked.rank(),
            "gauge_unit_fit_nonunit_square":"(1-s)/10",
            "scalar_unit_fit_center_residual":"-8*s^3*(1-s)",
            "additional_inhomogeneous_compact_term_not_assigned":True,
            "two_plateaus":["1","1/2"]}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
