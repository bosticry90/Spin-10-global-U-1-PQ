# Constant compact plateau restriction on the unit-fit class

Let the common smooth compact switch be constant s
on the test supports, with all its derivatives zero
there. The physical source-linear q_B and q_C each
carry s in the V879 compact parent. The free
principal transverse Maxwell quadratic is the same
in R and S on a constant patch. The two-edge local
gauge source carries s^2 and the three-edge local
gauge source s^3 after coalescence, as in V946.
After dividing the nonzero common powers, the
V939 and V942 witness functionals therefore act on

    D_B + s D_T.

The gauge-square row difference eliminates every
lower linear source map and alternating ghost
bracket at each fixed s. The commuting-adjoint
functional eliminates any constant-in-field
symmetric transverse metric at each s. Thus the
two normalized rows on (b_H,b_M,t_H,t_M) are

    (1,-1,s,-s),
    (1/5,-1/10,s/10,-s/5).

The bubble and triangle entries are their exact
stripped coefficients from the frozen V942 and
V943 packets. At unit s the four equal directions
pass both rows. At two distinct nonzero s the
stacked equations have rank four. The homogeneous
four-direction fit cannot have nonzero weights
that are independent of s. For all weights one
the normalized gauge-square remainder is
(1-s)/10 in the selected row.

For the ordinary scalar test keep the scalar
driver of V944. The lower gauge correction s^2 L_B
acts on the classical Bxx term with its factor s.
The scalar quadratic and ordinary cubic from the
two-edge kernel have s^2 and are varied by the
classical source with factor s. The mixed scalar
triangle has s^3, hence its classical source
variation carries s^4. In the V949 and V951
stripped basis the homogeneous residual is

    s^3 rho(L_B b + 8 W_B b + 2 s W_T T b).

At the broken singlet e12, T is zero and L_B=8.
This requires W_B=-1. On the light center L_B=0
and T=-4, leaving the unit-fitted residual
-8 s^3(1-s) times the nonzero center generator.
The two plateau values give inconsistent constant
weights even though both exterior switch
derivative terms vanish.

These are comparisons for the isolated local
directions with the other right-hand sides
omitted from the test. The compact parent has
its own reference and current terms. In
particular the V879 s(1-s) term can enter
correlated insertions and must be compared
before concluding anything about full compact
restoration. The calculation identifies the
shape that those terms must address. Both
routes share the model, conventions and software.
