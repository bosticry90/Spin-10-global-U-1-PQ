# V956 pre-execution contract

Test the V944–V951 unit-switch fit on two constant
nonzero compact plateaus. Freeze the V942 and V943
gauge witness coefficients, V946 switch degrees and
the V949 and V951 scalar color maps. Allow arbitrary
lower gauge and symmetric metric maps within the
same projected equations.

Compare the restricted homogeneous local gauge and
scalar coefficients at s=1 and s=1/2. Derive the
residual polynomial and retain the inhomogeneous
compact right-hand side as independent. This is a
test of the isolated fixed-weight unit fit, not
a demand for a homogeneous full compact master
identity. Native 120 s, final 180 s including E4
cap 120 s, 8 GiB sampled private, 350 MiB launch
floor, 8 MiB artifact and 32 MiB packet.
No authority change.
