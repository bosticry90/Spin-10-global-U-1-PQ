"""Check the mixed compact reference-master scalar color span."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)
seagull = source.seagull


def check(phase):
    _, _, _, f, _, _ = source.owner.inputs(phase)
    folder = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    H, M = range(12), range(12,45)
    tensors = [defaultdict(lambda:sp.S.Zero) for _ in range(2)]
    used = 0
    for g,word,cells in rows:
        if g != 1 or len(word) != 3:
            continue
        (b,db),(c,dc),(j,dj) = word
        if b >= 180 or b%4 != 1 or not 553 <= c < 598 or not 691 <= j < 823 or (j-643)%4 != 1:
            continue
        assert not(db or dc or dj) and all(p[:2] == [0,0] for p,_,_ in cells)
        v,c,u = b//4,c-553,(j-643)//4
        z = seagull.unpack([([0,*p],n,d) for p,n,d in cells])
        assert z == -dict(f[v,c])[u]
        out = tensors[int(v in M)]
        for a,value in f[u,v]:
            out[a,c] -= z*value/2
        used += 1
    assert used == 1268
    light, broken = map(source.owner.clean,tensors)
    casimir = defaultdict(lambda:sp.S.Zero)
    for h in H:
        for b in range(45):
            for k,x in f[h,b]:
                for a,y in f[h,k]:
                    casimir[a,b] -= x*y
    casimir = source.owner.clean(casimir)
    Ch = {(i,j):z for (i,j),z in casimir.items() if i in H and j in H}
    Cm = {(i,j):z for (i,j),z in casimir.items() if i in M and j in M}
    assert source.add(Ch,Cm) == casimir
    I = {(i,i):sp.S.One for i in range(45)}
    Ph = {(i,i):sp.S.One for i in H}
    T = source.add(source.add({},casimir,sp.Rational(1,2)),Ph,-4)
    assert light == source.add({},Cm,sp.Rational(1,2))
    assert broken == source.add(source.add(source.add({},I,4),Ch,-sp.Rational(1,2)),Cm,-1)

    def apply(mat,v):
        out = defaultdict(lambda:sp.S.Zero)
        for (i,j),z in mat.items():
            if j in v:
                out[i] += z*v[j]
        return source.owner.clean(out)

    center = {0:sp.sqrt(30)/10,5:sp.sqrt(2)/2,8:sp.S.One}
    singlet = {12:sp.S.One}
    assert all(not source.bracket(f,{h:1},v) for h in H for v in (center,singlet))
    assert not apply(light,center) and not apply(light,singlet)
    assert apply(broken,center) == source.add({},center,4)
    assert apply(broken,singlet) == {12:4}
    assert apply(T,center) == source.add({},center,-4)
    assert not apply(T,singlet)
    return {"literal_broken_gauge_driver_rows":used,
            "mixed_reference_light_B_map":"C_H|M/2",
            "mixed_reference_broken_B_map":"4 I-C_H|H/2-C_H|M",
            "light_center_requires_broken_weight":"-1",
            "broken_singlet_requires_broken_weight":"0",
            "mixed_reference_triangle_color_span_suffices":False}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
