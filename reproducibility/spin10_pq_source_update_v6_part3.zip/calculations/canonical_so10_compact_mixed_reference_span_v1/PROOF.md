# The mixed reference-master scalar color test

On a constant compact plateau, V879 gives the
reference-master carrier s(1-s) sum_i F_i E_(R,i).
The literal V925 mixed gauge component has the
form f_(u v c) (partial Lambda_u) B_v C_c,
where the gauge source output u is broken for a
mixed reference port. Attach two physical Bxx
vertices with one exterior scalar each. The
remaining edges are one mixed B Lambda, one
ordinary BB and a scalar line. The switch
polynomial is s^3(1-s), the one needed by V956.

The differentiated Lambda momentum contracts with
the transverse ordinary B projection. Since
P_T(q) q=0, its contribution is the exterior
transfer at the master vertex, including the
ghost derivative on a constant plateau. At the
ordinary Bxx endpoint the derivative similarly
leaves the exterior scalar derivative. The mixed
Bxx endpoint retains the scalar collapse and its
uncollapsed remainder. This is the relevant
skew scalar color channel, with its Lorentz and
extension constants kept outside.

The skew color contraction is one half of
sum_(u in M,v in S) f_(u v c) [u,v] followed by
the scalar representation. Read the coefficient
from the literal gauge source and the ordered
bracket. The two ordinary internal sectors give

    W_H = C_H|M / 2,
    W_M = 4 I - C_H|H / 2 - C_H|M.

The code checks every matrix position from the
literal exports. The scalar plateau residual in
V956 requires the V949 color shape
T=(-8 P_H+C_H)/2, up to its common sign and weight.

On the light central generator W_H=0, W_M=4,
and T=-4. The broken H-singlet e12 instead has
W_H=0, W_M=4 and T=0. The Phi representation
has nonzero generators on both tests by V948.
The two weights therefore cannot match both
targets. In particular one finite coefficient
cannot be inferred simply from the right switch
polynomial.

This tests only the stated mixed reference-master
triangle and its two internal sectors. Other
reference or source insertions, connected terms
and compact normalization can contribute. No
Lorentz or finite coefficient was set to repair
the residual. Both routes share the model,
conventions, software and authorship.
