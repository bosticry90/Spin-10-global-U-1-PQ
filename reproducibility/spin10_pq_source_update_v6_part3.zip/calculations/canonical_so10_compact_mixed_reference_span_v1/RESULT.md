# V957 result — the mixed reference carrier alone misses the scalar target

The mixed reference-master triangle has the required
compact polynomial s^3(1-s). Both literal routes
give the full internal light and broken color maps.
Their common broken-sector weight must be -1 on
the light-center target and zero on the broken
singlet target, in the stripped comparison. The
light-sector column vanishes on both probes.

Thus this carrier alone cannot supply the scalar
plateau residual. This is a color restriction on
the two stated directions. It leaves other reference
and scalar/source insertions open. In particular
the scalar reference-root with an exterior scalar
at that root and exterior ghost at a BCa vertex
has distinct ports and must be checked.

Both data routes share model, conventions and
software. No coefficient has been chosen.
