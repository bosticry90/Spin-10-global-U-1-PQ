# V993 pre-execution contract

Freeze V992, V991, V877, the literal
V848 marked and source rows and V869
light carriers. Differentiate the
six-term rooted marked expression
once in the external background
on the existing compact domain.
Test the absolute derivative
placements by exact exterior
algebra and the same-clock
relative reduction. Check an
actual causal separated tree
coefficient at g^1 switch degree
two. Fix the epsilon and source
labels and support of the compact
pure-gauge variation before the
comparison. Require nonzero direct
and rooted pieces with opposite
sign. No coincident or weak
adiabatic extension.

Native 120 s, final 180 s including
E4 cap 120 s, 8 GiB sampled private,
350 MiB launch floor, 8 MiB artifact
and 32 MiB packet. No authority change.
