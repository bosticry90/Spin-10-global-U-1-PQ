# V993 result

A first background derivative of the absolute
marked connected coefficient has the six
frozen-root derivatives and five further
tangent placements. Exact exterior algebra
checks them against direct left extraction.
For the same-clock relative comparison the
undifferentiated proper difference is zero
at A=0, so the first relative coefficient
uses the six original rooted terms applied
to the differentiated proper difference.

The actual separated causal tree control
uses epsilon13 and j_a14 and the light
carrier -3 sqrt(10)/20. A compact pure-gauge
background variation changes the propagator
between the two fixed labels. The direct
and rooted pieces each have magnitude at
least |g| 7 sqrt(10)/(7290 pi²) and cancel
with their actual ordered signs.

This checks a nonzero first-background
rooted term in the inherited compact
domain. The local explicit cutoff and
source insertion terms remain separate.
No coincident or weak adiabatic limit
is inferred.
