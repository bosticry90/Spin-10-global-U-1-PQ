"""Check a first-background rooted marked derivative and causal witness."""

import gzip
import json
import sys

import sympy as sp

from execute import PK, ROOT, run_worker

sys.path.insert(0,str(PK))
from source_convention_control import Exterior


def marked_chain():
    e = Exterior()
    beta,rho,C,a = (e.variable(n,1) for n in ("beta","rho","C","a"))
    x = e.variable("x",0)
    X = e.even_symbols["x"]
    u = sp.Symbol("u")
    phi = 1+u
    b,k,c = {():sp.Rational(3,2)+u},{():-sp.S.Half+2*u},{():3+u}
    F = e.add(e.scale(e.mul(x,x),1+2*u),e.scale(e.mul(x,C,a),3+5*u))
    IB,IK = e.scale(e.mul(x,C),2+u),e.scale(e.mul(x,a),3-2*u)
    IM,V = e.scale(e.mul(x,x),2+u),e.scale(x,5-u)
    loops = (F,IB,IK,IM,V)

    def evaluate(poly,z):
        return e.clean({w:q.subs(X,z) for w,q in poly.items() if not w})

    def at_zero(poly):
        return e.clean({w:q.subs(u,0) for w,q in poly.items()})

    def d_background(poly):
        return e.clean({w:sp.diff(q,u) for w,q in poly.items()})

    def terms(items,b,k,c):
        F,IB,IK,IM,V = items
        return [IM,V,e.derive(IB,{"C":k}),e.scale(e.derive(IK,{"a":b}),-1),
                e.derive(e.derive(F,{"a":b}),{"C":k}),e.derive(F,{"x":c},parity=0)]

    def rooted(items):
        F,IB,IK,IM,V = items
        loop = e.add(F,e.mul(beta,IB),e.mul(rho,IK),e.mul(beta,rho,e.add(IM,V)))
        xe = e.add({():phi},e.mul(beta,rho,c))
        odd = {"C":e.mul(rho,k),"a":e.mul(beta,b)}
        out = []
        for word,coeff in loop.items():
            for (power,),q in sp.Poly(coeff,X).terms():
                out.append(e.scale(e.mul(*([xe]*power),*(odd.get(z,{(z,):sp.S.One}) for z in word)),q))
        return e.add(*out)

    def mixed(poly):
        return e.partial(e.partial(poly,"beta"),"rho")

    base = rooted(loops)
    assert mixed(base)==e.add(*(evaluate(t,phi) for t in terms(loops,b,k,c)))
    assert e.partial(e.partial(base,"rho"),"beta")==e.scale(mixed(base),-1)
    direct = at_zero(d_background(mixed(base)))
    b0,k0,c0 = map(at_zero,(b,k,c))
    db,dk,dc = map(d_background,(b,k,c))
    six = [at_zero(d_background(evaluate(t,phi))) for t in terms(loops,b0,k0,c0)]
    five = [e.derive(IB,{"C":dk}),e.scale(e.derive(IK,{"a":db}),-1),
            e.derive(e.derive(F,{"a":b0}),{"C":dk}),
            e.derive(e.derive(F,{"a":db}),{"C":k0}),e.derive(F,{"x":dc},parity=0)]
    five = [at_zero(evaluate(t,1)) for t in five]
    assert all(six) and all(five) and direct==e.add(*six,*five)
    assert e.add(*six)!=direct

    relative = tuple(e.scale(term,u) for term in loops)
    assert not at_zero(mixed(rooted(relative)))
    relative_dot = at_zero(d_background(mixed(rooted(relative))))
    expected = e.add(*(at_zero(evaluate(t,1)) for t in terms(loops,b0,k0,c0)))
    assert relative_dot==expected and relative_dot
    return {"frozen_six":[str(v[()]) for v in six],"moving_five":[str(v[()]) for v in five],
            "same_clock_relative":str(relative_dot[()])}


def read(path):
    if path.suffix==".gz":
        with gzip.open(path) as stream:
            return json.load(stream)
    return json.loads(path.read_bytes())


def literal(phase):
    root = ROOT/"calculations"
    lift = root/"canonical_so10_augmented_metric_lift_v1"
    rows = read(lift/"tensor_0.json.gz")["input_polynomial_Minkowski"]
    linear = [r for r in rows if len(r[0])==2 and any(i==1287 for i,_ in r[0])
              and all(power[0]==0 for power,_,_ in r[1])]
    expected = [[[[52+mu,[]],[1287,[mu]]],[[[0,0,0,0],z,1]]] for mu,z in enumerate((-1,1,1,1))]
    expected += [[[[521,[]],[1287,[]]],[[[0,1,0,0],-1,2]]],
                 [[[1254,[]],[1287,[]]],[[[0,0,0,0],1,1]]]]
    assert linear==expected
    src = read(lift/("tensor_7.json.gz" if phase=="native" else "tensor_6.json.gz"))["input_polynomial_Minkowski"]
    cb = [r for r in src if len(r[0])==2 and any(i==566 for i,_ in r[0])
          and any(643<=i<1286 for i,_ in r[0])]
    assert cb==[[[[566,[mu]],[695+mu,[]]],[[[0,0,0,0],-1,1]]] for mu in range(4)]
    ja = [r for r in src if any(i==1255 for i,_ in r[0])]
    assert ja==[[[[522,[]],[1255,[]]],[[[0,0,0,0],-1,1]]]]
    root_packet = root/"canonical_so10_joint_common_family_applicability_v1"
    packet = read(root_packet/f"{phase}_complete_full_background_extension.json.gz")
    assert all(packet["joined_parities"][i]==1 for i in (566,567,611,612))
    assert packet["joined_parities"][1255]==0
    for a,c in ((611,566),(612,567)):
        kinetic = [[w,[cell for cell in cells if cell[0][0]==0]]
                   for grade,w,cells in packet["complete_S_GF_source"] if grade==0
                   and any(i==a for i,_ in w) and any(v[0]==0 for v,_,_ in cells)]
        assert kinetic==[[[[c,[mu]],[a,[mu]]],[[[0,0,0],-1,1]]] for mu in range(4)]
    path = root/"canonical_so10_current_background_reference_bridge_v1/result_a.json"
    carrier = read(path)["compared"]["twelve_current_homogeneous_carriers"][0]
    data = {(i,j):sp.sympify(z) for i,j,z in carrier}
    assert data[566,567]==data[611,612]==-3*sp.sqrt(10)/20
    return data[566,567]


def separated(r):
    t,s,eps = sp.symbols("t s eps",real=True)
    a = eps+sp.I*t
    abel = (1/(a-sp.I*s)-1/(a+sp.I*s))/(2*sp.I)
    w = 1/(4*sp.pi**2*(s*s-t*t))
    assert sp.cancel(abel.subs(eps,0)/(4*sp.pi**2*s)-w)==0
    assert sp.cancel(sp.diff(w,t)-t/(2*sp.pi**2*(s*s-t*t)**2))==0
    color = sp.Matrix([[0,r],[-r,0]])
    kernel = sp.eye(2)*w
    separated_jet = color*kernel
    assert separated_jet[0,1]==r*w
    assert color*kernel+kernel*color.T==sp.zeros(2)
    radius = sp.Rational(1,8)
    early,late = 1-2*radius,1+2*radius
    d_min = (3-2*radius)**2-late**2
    d_max = (3+2*radius)**2+2*(2*radius)**2-early**2
    bound = 2*(1-radius)*early/(2*d_max**2)
    assert (d_min,d_max,bound)==(6,sp.Rational(81,8),sp.Rational(14,2187))
    assert -r*bound==7*sp.sqrt(10)/7290
    direct = r*bound
    rooted = -r*bound
    assert direct+rooted==0 and direct!=0
    return str(-direct)


def check(phase):
    terms = marked_chain()
    r = literal(phase)
    bound = separated(r)
    return {"six_frozen_and_five_moving_placements":terms,
            "actual_color_13_to_14":str(r),
            "separated_nonzero_lower_bound_times_pi_squared_per_abs_g":bound,
            "actual_direct_and_rooted_cancel":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
