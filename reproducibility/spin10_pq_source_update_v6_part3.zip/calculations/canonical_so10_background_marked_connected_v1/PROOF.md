# First-background connected marked transport

Retain the V877 common parent
Z=P+beta B+rho K+beta rho M with
the indicated left strengths.
Let F be the proper finite loop
functional and phi,b,k,c the
classical rooted mean and its
beta, rho and beta-rho tangents.
All quantities use the same
background A and switch.
Before the new differentiation
the connected coefficient is

    I_M+V(K,B)+D_k I_B-D_b I_K+D_k D_b F+D_c F.

An even first A derivative
keeps this order. Write a dot
for the derivative at fixed
external j. With b,k,c frozen
apply partial_A + D_(dot phi)
to all six terms, including
the explicit P,B,K,M dependence
of the insertions and the
underlying map. The five extra
placements are

    D_(dot k) I_B - D_(dot b) I_K
      + D_(dot k) D_b F + D_k D_(dot b) F
      + D_(dot c) F.

These tangents follow from
differentiating the original
stationary equation at fixed j
with both strengths present,
H_Z dot phi_Z=-partial_A E Z
in the inherited ordered chart.
No independent contact
normalization is assigned.
The exact exterior calculation
compares direct differentiation
with all six frozen and five
tangent placements. Reversing
beta and rho reverses the
complete coefficient.

For the first covariant-minus-
flat comparison at the same
clocks, the zero-background
proper difference vanishes as
a functional with both strengths
retained. The bridges at zero
background agree as well.
Therefore all differentiated
tangent and evaluation placements
on this undifferentiated
difference vanish. The first
relative coefficient is exactly
the V877 six terms applied to
the first proper difference on
the original rooted mean and
original tangents. This is the
V991 matched forest consequence
on independent compact labels.
For different clocks with a
nonzero zero-background
difference, the extra placements
are in general needed. The
explicit V992 cutoff trace and
its source insertions remain
separate in either comparison.

## Separated causal check on the actual tree

Use V877 raw Minkowski signs and
its switch grade two. Let U be
the open box of radius 1/8 about
zero and V the box of radius 1/8
about (1,3,0,0). Choose normalized
nonnegative compact scalar bumps
with independent odd factors for
epsilon13 on U and j_a14 on V.
Write sigma=s chi_s with chi_s
equal to 1+x^0 near U and compact
and zero near V. Choose a compact
light parameter omega of color 0,
one near the whole switch support
and zero near V. Vary the external
background only, along d omega.
The source and epsilon labels
are held fixed. The background
variation and its local derivatives
vanish on the switch support.

At first g the change in the full
quadratic bridge is the reference
change, since all local switched
variations vanish. The unheated
inverse covariance gives

    dot G= M(x) G + G M^sharp(y),

with the endpoint carriers and
their order as in V869. On U x V,
M(x)=g r_0, M(y)=0. The actual
ordinary ghost carrier is
r_0[13,14]=-3 sqrt(10)/20.
The cross-color bridge at A=0
is zero and its first A coefficient
is the corresponding diagonal
Feynman bridge multiplied by
g r_0[13,14]. This is a fixed-label
variation along a pure gauge
background. A full Ward operation
would also transform the endpoints.

The literal V848 K rows with epsilon13
give the raw B13 derivative, auxiliary
width and J_a13 columns. The raw source
kinetic derivative F_B13 has the same
sign as in V877 after putting J first.
The J_a14 variation has final switch
support. The compact stationarity
argument of V877 cancels the K_z
terms between the direct M and D_k B
terms. At the retained one-j degree
the E_a terms vanish by support,
and the only surviving linear
F term is the derivative of C13.
Higher field powers do not return
at that degree. Hence the first
background derivative of the direct
tree coefficient is the V877
diagonal M_2 multiplied by
g r_0[13,14], and the rooted
D_k B coefficient is its opposite.
The connected source-side derivative
still has final switch support on
the j_a14 endpoint and vanishes.
The same direct and rooted terms
remain individually nonzero.

On U x V the time transfer is
between -5/4 and -3/4, and
d=spatial_distance²-time² lies
between 6 and 81/8. The V877
Abel angular integral gives the
spacelike scalar function
w=1/(4 pi² d). The raw ordered
ghost bridge has the V877 Feynman
phase. Integration by parts in
the direct M coefficient uses
the free wave equation off the
diagonal and leaves the varying
switch term proportional to
chi_s partial_0 chi_s partial_0 w.
The V877 lower bound is
14/(2187 pi²) in magnitude.
Multiplying the actual color
coefficient proves a magnitude
of at least |g| 7 sqrt(10)/(7290 pi²)
for each first A piece. Their
sum is zero with the exact
rooted sign. A plateau switch
would remove this test, and a
retarded bridge would vanish
on the separated spacelike pair.

This is an actual causal tree
control for a mandatory background
root derivative. The ordered
one-loop transport above uses
the established compact proper
and bridge domains. It does not
establish coincident nonlinear
products or a weak adiabatic
limit. The routes share the
action and symbolic conventions.
