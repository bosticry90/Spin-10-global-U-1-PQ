"""Check constant light rotation and the paired geometric cutoff sign."""

import importlib.util
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def actual(phase):
    path = ROOT / "calculations/canonical_so10_scalar_source_transport_v2/source_transport.py"
    spec = importlib.util.spec_from_file_location("scalar_transport_owner",path)
    source = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(source)
    _,_,_,bracket,_,_ = source.inputs(phase)
    f = {(i,a,b):z for (a,b),pairs in bracket.items() for i,z in pairs}
    path = ROOT / "calculations/canonical_so10_current_background_reference_bridge_v1/result_a.json"
    rows = json.loads(path.read_bytes())["compared"]["twelve_current_homogeneous_carriers"]
    matrices = {}
    for h in (1,3,6):
        seen = {(i//4,j//4):sp.sympify(z) for i,j,z in rows[h] if i<180 and j<180 and i%4==j%4==0}
        assert seen=={(i,j):-z for (i,a,j),z in f.items() if a==h}
        assert all((i<12)==(j<12) for i,j in seen)
        matrices[h] = sp.SparseMatrix(12,12,{(i,j):z for (i,j),z in seen.items() if i<12})
    r1,r3,r6 = (matrices[h] for h in (1,3,6))
    assert r3[:,6]==sp.eye(12)[:,1]/2
    assert (r3*r6-r6*r3-r1/2).applyfunc(sp.expand)==sp.zeros(12)
    assert all(R.T==-R for R in (r1,r3,r6))
    return r1,r3,r6


def finite_carriers(r1,r3,r6):
    I = sp.eye(12,cls=sp.SparseMatrix)
    kron = sp.kronecker_product
    K0 = kron(sp.diag(4,1),I)
    G0 = K0.inv()
    half = kron(sp.diag(sp.Rational(1,4),sp.Rational(1,2)),I)
    C0 = half*G0*half
    C0_inv = C0.inv()
    M = kron(sp.eye(2),r3)
    J = sp.Matrix([[0,1],[-1,0]])
    assert M.T==-M and M*C0==C0*M

    def edge(r):
        K1 = kron(J,r)
        F1 = -K1/12
        dC = F1*G0*half-half*G0*K1*G0*half+half*G0*F1.T
        R1 = -C0_inv*dC*C0_inv-K1
        Delta = dC+C0*K1*C0
        assert C0*R1*C0==-Delta
        return R1,Delta

    R6,D6 = edge(r6)
    R1,D1 = edge(r1/2)
    clean = lambda X:X.applyfunc(sp.expand)
    E = M.T*R6+R6*M
    assert clean(E+R1)==sp.zeros(24)
    assert clean(M*D6-D6*M-D1)==sp.zeros(24)
    i,j = next((i,j) for i in range(24) for j in range(i+1,24) if D1[i,j]!=0)
    Va = sp.SparseMatrix(24,24,{(i,i):1})
    Vb = sp.SparseMatrix(24,24,{(i,j):1,(j,i):1})

    def relative(D,A,B):
        return -sp.trace(D*A*C0*B+D*B*C0*A)/2

    direct_R = sp.trace((C0*Va*C0*Vb*C0+C0*Vb*C0*Va*C0)*E)/2
    from_mean = relative(D6,M*Va-Va*M,Vb)+relative(D6,Va,M*Vb-Vb*M)
    assert sp.expand(direct_R+relative(D1,Va,Vb))==0
    assert sp.expand(direct_R-from_mean)==0 and sp.expand(direct_R)!=0
    return str(sp.expand(direct_R))


def qualified_transfer():
    folder = ROOT / "calculations/canonical_so10_background_ABB_finite_sum_v1"
    checks = json.loads((folder/"result.json").read_bytes())["checks"]
    receipt = json.loads((folder/"validation_receipt.json").read_bytes())
    assert receipt["evidence_validation"]=="PASS_BOUNDED_BACKGROUND_ABB_FINITE_SUM"
    assert receipt["checks"]==checks
    common,unequal = map(sp.sympify,checks["full_643_field_ABB_finite_controls"])
    assert common==sp.Rational(11,12)*sp.log(sp.Rational(3,2))-sp.Rational(23,72)
    assert unequal==sp.log(sp.Rational(7,4))/2+sp.Rational(5,12)*sp.log(sp.Rational(3,2))-sp.Rational(31,672)
    assert sp.Rational(11,12)*sp.Rational(2,5)>sp.Rational(23,72)
    return [str(-x/2) for x in (common,unequal)]


def check(phase):
    carrier = actual(phase)
    finite = finite_carriers(*carrier)
    transfer = qualified_transfer()
    return {"ordered_rotation_A6_to_A1":"1/2",
            "paired_cutoff_and_mean_ward_fixture":finite,
            "V989_transferred_over_i_g4_k_per_160_pi_squared":transfer,
            "common_profile_regulator_is_nonzero":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
