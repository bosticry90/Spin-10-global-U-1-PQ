# Fixed-background geometric cutoff on the selected local coefficient

Use the V984 affine proper identity
with T_b the full light background
operation and T_q the operation that
holds A fixed. The ordinary and source
transformations agree between them.
Use a constant light parameter omega
in color 3. The actual V869 evaluation
carrier is M=g r_3, with r_h=-ad_h.
There is no affine derivative of omega.
In the external light connection the
homogeneous variation is M A. The
actual (3,6) bracket is -e1/2, so
r_3 A6=A1/2 with the same momentum
and polarization. Both action exports
verify the color and carrier signs.

The fixed-flat cutoff R_0 commutes
with the constant rotation and its
evaluation dual. It has no explicit
affine regulator response for this
parameter, even with unequal H/M
profiles matched in each quartet.
The covariant R_A obeys the full
background congruence. At first A
degree and fixed ordinary/source mean
its explicit fixed-A operator is

    E_q^(1)[A]=M^sharp R_1[A]+R_1[A] M
                         =-R_1[M A].

The term at A=0 vanishes, so the
proper regulator trace at order A
uses the common full mean-dependent
G at A=0. No first derivative of G
is multiplied by a nonzero zero-order
E. The coefficient of the total
regulated difference therefore is

    -1/2 STr G^0 R_1[M A].

Here the complete R_1 includes the
reference and both heat arms. For
adjacent lines use

    C_0 R_1[A] C_0
      = -d C_A[A]-C_0 K_1[A] C_0
      = -Delta C_1[A].

The second equality is the V988
edge replacement. It is valid as
a paired identity. In the Born trace
one can apply it against the
adjacent C_0 factors before any
standalone inverse could occur.
At B² it gives exactly the negative
of the V989 relative proper edge
sum with A replaced by M A. The
pure reference carries no B
dependence, so it cannot enter the
projection. The sign and multiplicity
are also checked on finite ordered
carrier matrices with two external
Hessian letters.

Keep the direct insertion I_(T_q P)
and the separate source translation
I_(CP). At constant omega the
integrated full T_b P is zero by
the actual light invariance and
the scalar switch. Thus T_q P
=-T_A P is at least first degree
in A. The V879 source identity
C S_A=T_A S_A gives the same grade
bound on CP. The two regulated
proper insertion maps agree at
A=0, because they have the same
free cutoff and interaction.
Hence their differences on these
two explicit first-degree
insertions are zero in this
projection. This retains their
common value without fitting it.
It also keeps the pure reference
in the same original branch.

Apply the same ordered finite
parts as V989. For exterior A6
along e2 with transfer k e1 and
ordinary B20 and B33, the relative
explicit geometric cutoff is
-g/2 times V989's coefficient.
For equal heat lengths it is

    -i g^4 k/(320 pi²) [
         (11/12)log(3/2)-23/72 ].

The same -g/2 multiplier holds
for the V989 unequal-length
formula. The common-length case
is nonzero even though the flat
zero-background constant rotation
has no cutoff response.

This transfers the qualified
proper amplitude using the actual
cutoff congruence, with an
independent finite algebra check.
It does not independently integrate
the same loop. It is limited to
constant omega, first A and the
selected proper projection.
A local parameter has an affine
d omega term. Its first-A identity
can require second-A coefficients
and the actual source contact
domain. The fermionic and
connected extensions remain open.
