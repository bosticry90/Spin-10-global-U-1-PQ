# V990 result

The actual constant light color-3 rotation sends
A6 to A1/2 in the evaluation frame. At first A
degree, the paired explicit fixed-A cutoff
response is the negative of the V989 proper
edge sum with this rotated A.

Both the cutoff trace and the ordinary mean
variation give the same sign in a finite
ordered matrix fixture. The direct T_q P
and source CP insertion differences vanish
in this first degree. Their common values
remain in the comparison.

For equal lengths the coefficient in units
-i g^4 k/(320 pi²) is

    (11/12) log(3/2) - 23/72.

At unequal lengths the same -g/2 multiplier
applies to the full V989 proper coefficient.
This is a transfer via the actual cutoff
congruence with independent finite algebra,
not a new loop integration. The projected
proper identity uses a constant light
parameter. The local-parameter and connected
product domains remain separate.
