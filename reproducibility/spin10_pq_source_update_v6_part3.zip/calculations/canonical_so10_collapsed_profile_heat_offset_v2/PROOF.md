# Absolute heat-length offset of the collapsed free mixed line

This comparison concerns the free scalar-profile
subproblem of V946. It keeps distinct fixed Euclidean
momenta q_B=k+p_B, q_C=k+p_C with p_B unequal to p_C,
and an arbitrary fixed q_L=k+p_L. The common transverse
numerator is P_T(q_B). Set

    f_delta(q) = (1-exp(-q^2/delta^2))^2,
    F_j(q) = exp(-t c_j q^2) f_delta(q),

with positive heat lengths c_B,c_C,c_L. Dividing out
the common signed mixed-line collapse, the difference
from the two-edge expression is the integral of

    P_T(q_B) F_B(q_B) F_C(q_C) (F_L(q_L)-1)
      / (q_B^2 q_C^2)

with measure d^4k/(2 pi)^4. The finite mixed line
supplies the third F even though its numerator has
collapsed. Setting that factor to one before the
limits discards the difference.

Split F_L-1 into (exp(-t c_L q_L^2)-1) and
exp(-t c_L q_L^2)(f_delta(q_L)-1). The latter term
is dominated for delta at most delta_0 by a Gaussian
in q_L divided by q_B^2 q_C^2. This is integrable
at fixed nonexceptional p_B,p_C because the two
local poles do not coincide. It vanishes as delta
goes to zero after the UV limit. For the former
term, on bounded k the extra numerator is O(t)
times a bounded quadratic and the poles are
integrable. On the tail the denominators and
angular projector can be replaced by their
homogeneous limits with an O(1/|k|) relative or
tensor error. The integrated error tends to zero
using min(t |k|^2,1) times exponential damping.
Shifted heat arguments change the tail by
O(t |k|+t) times exponential damping. Fixed IR
profiles differ from one on the tail by Gaussian
bounds and do not change the UV rescaling.
These estimates justify the radial limit.

Let a=c_B+c_C and b=a+c_L. The spherical average of
P_T is 3 I/4. With x=t |k|^2 the radial measure is
dx/(16 pi^2 x), and

    integral_0^infinity (exp(-b x)-exp(-a x)) dx/x
       = -log(b/a).

One derivation differentiates with respect to b
and uses the value zero at b=a. The numerical
control independently integrates the difference.
For equal per-edge lengths the relative bracket
is -log(3/2). This constant has the sign and
normalization relative to the common collapsed
kernel, outside its chart and diagram factors.
The two expressions have the same logarithmic
residue, so a common subtraction shift cancels
from their difference. A graph-length-dependent
finite dictionary can account for this constant
and must be checked separately. HMM1 and the
V879 local engineering rule keep the heat length
for every word.

At exactly zero external transfer, with all
lengths equal and delta fixed through the UV
limit, the IR subtraction is a different radial
integral. Expanding f_delta^3-f_delta^2 in
exponentials gives

    -sum_(j=1)^6 (-1)^j binom(6,j) log j
    +sum_(j=1)^4 (-1)^j binom(4,j) log j.

Adding the UV bracket gives
-37 log 2+14 log 3+6 log 5. The independent
quadrature evaluates the direct IR integrand.
The exceptional integral cannot supply the
nonexceptional local constant.

No claim is made here about additional Duhamel
jets, the nonlinear auxiliary Euler insertion
normalization, or unmatched profile sectors.
The actual compact switch powers and exterior
terms remain those of V946. The two replay runs
share the analysis and numerical software.
