"""Verify the collapsed free-profile heat-length and exceptional controls."""

import json
from math import comb
import sys

import mpmath as mp
import sympy as sp

from execute import ROOT, run_worker


def check(phase):
    prior = ROOT / "calculations/canonical_so10_compact_mixed_source_transport_v1/result.json"
    assert json.loads(prior.read_bytes())["checks"]["regulated_mixed_divergence_multiplier"] == "E_profile*f_profile"
    mp.mp.dps = 50
    numerical = []
    for B,C,L in ((2,2,2),(1,2,4),(3,5,1)):
        a, b = B+C, B+C+L
        def difference(x):
            return mp.exp(-a*x)*mp.expm1(-(b-a)*x)/x if x else a-b
        q = mp.quad(difference,[0,mp.mpf("0.5"),2,mp.inf])
        expected = -mp.log(mp.mpf(b)/a)
        assert abs(q-expected) < mp.mpf("1e-40")
        numerical.append([B,C,L,str(sp.Rational(b,a))])
    angular = mp.quad(lambda theta:mp.sin(theta)**4,[0,mp.pi])/mp.quad(lambda theta:mp.sin(theta)**2,[0,mp.pi])
    assert abs(angular-mp.mpf(3)/4) < mp.mpf("1e-40")

    def log_sum(n):
        return sum((-1)**j*comb(n,j)*sp.log(j) for j in range(1,n+1))
    uv = -sp.expand_log(sp.log(sp.Rational(3,2)),force=True)
    ir_exceptional = sp.expand(sp.expand_log(log_sum(4)-log_sum(6),force=True))
    total = sp.expand(uv+ir_exceptional)
    expected_total = -37*sp.log(2)+14*sp.log(3)+6*sp.log(5)
    assert sp.simplify(total-expected_total) == 0
    total = expected_total
    def ir(x):
        r = -mp.expm1(-x)
        return r**4*mp.exp(-x)*(mp.exp(-x)-2)/x if x else 0
    measured = mp.quad(ir,[0,1,3,mp.inf])
    assert abs(measured-mp.mpf(str(ir_exceptional.evalf(52)))) < mp.mpf("1e-40")
    assert abs(measured) > mp.mpf("0.01")
    return {"positive_length_controls":numerical,"angular_factor":"3/4",
            "nonexceptional_uv_ratio_equal_lengths":"3/2",
            "exceptional_relative_bracket":str(total),
            "exceptional_IR_differs_from_nonexceptional":True,
            "common_subtraction_shift_changes_difference":False}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
