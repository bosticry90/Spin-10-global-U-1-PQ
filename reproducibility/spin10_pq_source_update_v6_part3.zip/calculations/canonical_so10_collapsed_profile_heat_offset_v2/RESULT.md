# V947 result — absolute offset of the collapsed heat profile

For the free nonexceptional Euclidean subproblem with
positive matched edge lengths, the collapsed triangle
retains the mixed-edge damping. Its absolute finite
difference from the two-edge expression has relative
radial bracket -log(3/2) at equal lengths, with
transverse angular factor 3/4. The two logarithmic
residues agree, so changing a common subtraction
constant cannot change that difference.

At exactly zero external transfer the infrared
contribution instead survives. The relative bracket is
-37 log 2+14 log 3+6 log 5 with equal lengths. Exact
binomial reduction and independent 50-digit radial
quadrature check the distinction. The first packet
stopped on a structurally unexpanded log(6); it is
preserved on D:. The corrected exact difference and
quadrature pass the same test.

This is a free-profile relative limit before a
graph-dependent finite dictionary or a normalized
nonlinear auxiliary Euler insertion is imposed.
The compact switch and exterior derivatives are
still those of V946. Both executions share the
analysis and software. No finite normalization or
new physical scale has been adopted.
