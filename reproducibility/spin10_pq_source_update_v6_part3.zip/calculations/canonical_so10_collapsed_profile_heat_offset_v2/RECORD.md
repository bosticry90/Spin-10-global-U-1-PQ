# V947 pre-execution contract

Compare the V946 collapsed free mixed edge to the
coalesced two-edge distribution, before additional
graph-dependent finite normalization. Freeze the V791
scalar profile shape, positive heat lengths, common
transverse numerator, order of UV and IR limits and
fixed nonexceptional Euclidean momenta.

Derive the relative absolute constant and the difference
from the exceptional zero-transfer value. Check the
independent radial and angular controls at exact
arguments with 50-digit quadrature. Preserve the prior
switch and exterior derivative labels. No extension of
this result to background Duhamel kernels or arbitrary
profile matching is authorized by this calculation.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB
sampled private, 350 MiB launch floor, 8 MiB artifact and
32 MiB packet. No authority change.

V1 stopped at a structural log-expression comparison because SymPy kept log(6) unexpanded. V2 checks the exact simplified difference. The failed packet is preserved on D:.
