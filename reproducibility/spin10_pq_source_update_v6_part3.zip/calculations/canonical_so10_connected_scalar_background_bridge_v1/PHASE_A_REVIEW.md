# V872 phase A scalar operator disposition

Both frozen routes completed in 17.073 seconds, with 247,156,736 bytes
maximum sampled private allocation. Each checks 50,240 physical scalar
kinetic rows. The 19,832 light rows vary under the actual affine B rule.
The other 30,408 are heavy and inactive for that rule. Left Euler
integration by parts agrees with the full V869 scalar reference
variation at all 39,664 parameter-jet positions. The singlet has no
such positions. Omitting the parameter second derivative loses 19,832
positions. The complete unprobed current GF/source packet has no
additional first-g scalar-pair affine term in this comparison.

This binds the actual scalar part of the first-g affine variation on
the common plateau. In P=R_A+sigma(S_A−R_A), the affine reference
contribution and its opposite in the interaction must both be kept.
When the compact parameter is supported where sigma=1, those two
reference terms cancel locally and the physical kinetic variation
supplies the same operator. The proof is for the chosen unprobed
quadratic insertion, with the V869 flat branch and the original
switch convention. It is not a computation of a general background
state or an arbitrary-field Ward amplitude.

For phase B the actual Phi pair 180,225 has skew carrier entries
r[180,225]=2 sqrt(10)/5 and its negative reverse. Transport the
current Euclidean operator once to the qualified Minkowski phase.
Write M=g r(nu), with compact nu. The pure-gauge affine insertion
has dK=−M^sharp K0−K0 M. FCR1 supplies the two-sided retarded and
advanced inverses. CWB1 supplies the free Wightman bisolution and
the ordered Feynman contact. In the first relative COS1 product
the difference C_F−W is iG_adv on the action-to-field ordering.
This derives the output-field retarded variation −G_ret dK.
On both endpoints the transported W then has

    dW = −G_ret dK W − W dK G_adv = M W + W M^sharp.

Check this with independent compact tests and the two off-shell
delta identities, rather than by setting the free equations to
zero inside an operator product. The opposite term is the fixed-W
coordinate derivation defect. The actual past Phi mass-defect
vertex and one local x_180 field provide a sensitive contraction
control, with the nonzero r_0 coupling to x_225. Keep the literal
cutoff and the reference subtraction in the comparison. The result
to seek is a finite pure-gauge tangent compensation, separate
from LAC1's input-strength transporter derivative and from a
claim of arbitrary-background Feynman-state equivalence.

The completed producer result awaits distributional comparison
and final review. No new loop integral or scientific promotion.
