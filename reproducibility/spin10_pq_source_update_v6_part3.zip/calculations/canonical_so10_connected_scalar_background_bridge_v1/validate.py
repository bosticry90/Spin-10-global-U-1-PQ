"""Verify the actual scalar endpoints and the V872 E4 sequence."""

from fractions import Fraction
from hashlib import sha256
import json
import os
import subprocess
import sys
import threading
import time

import sympy as sp

from execute_a import CONTROL, HERE, ROOT, git, save
from scalar import V869, read


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def independent_checks(a, b):
    assert len(a["complete_reference_scalar_euler"]) == 39664
    assert len(a["roles"]) == 2 and all(not role["residual"] for role in a["roles"])
    carriers = read(V869 / "result_a.json")["compared"]["twelve_current_homogeneous_carriers"]
    raw = [{(i, j): sp.sympify(value) for i, j, value in table} for table in carriers]
    first = second = 0
    for h, omega, field, i, j, value in a["complete_reference_scalar_euler"]:
        assert 180 <= i < 506 and 180 <= j < 506
        assert len(set(omega + field)) == 1 and len(omega + field) == 2
        assert sp.sympify(value) == (1 + len(field)) * raw[h][i, j]
        first += len(omega) == 1
        second += len(omega) == 2
    assert first == second == a["omit_second_parameter_jet_residual"] == 19832
    r = raw[0][180, 225]
    assert r == -raw[0][225, 180] == 2 * sp.sqrt(10) / 5
    endpoint = b["endpoints"]
    assert sp.sympify(endpoint["left"]) == r * sp.Symbol("W_in")
    assert sp.sympify(endpoint["right"]) == -r * sp.Symbol("W_out")
    assert endpoint["without_either_delta"] == [endpoint["left"], endpoint["right"]]
    assert endpoint["shell_coefficients_in_pi_units"] == [[-1, 1, 1], [1, -1, -1]]

    tail = b["tail"]
    low, high = map(Fraction, tail["z_squared_interval"])
    assert low > 0 and high < 1 and low < high
    lower = Fraction(tail["positive_adv_lower_bound_in_m2_over_4pi_units"])
    assert lower == (8 - high) / 16 == Fraction(1967, 4096)
    assert all(Fraction(value) >= lower for point, value in tail["exact_series_controls"])
    assert tail["retarded_zero"] and tail["Delta_sign"] == -1
    switch = b["switch"]
    mass = sp.Symbol("Mref_Phi_squared")
    assert sp.sympify(switch["isolated_fixed_W_defect_factor"]) == -r * mass
    assert sp.sympify(switch["transport_factor"]) == r * mass
    assert Fraction(switch["with_kinetic_current_ratio"]) == 1 - Fraction(1, 2)
    return {"first_second_scalar_positions": [first, second], "strict_timelike_tail_lower": str(lower),
            "carrier": str(r), "switch_current_ratio": "1/2"}


def main():
    started = time.perf_counter()
    watch = threading.Timer(180, lambda: os._exit(124))
    watch.daemon = True
    watch.start()
    prep = read(HERE / "preparation_validation.json")
    assert prep["base_HEAD"] == git("rev-parse", "HEAD").decode().strip()
    assert git("ls-tree", "-r", "HEAD") == (CONTROL / "old_git_tree.txt").read_bytes()
    assert not git("diff", "--cached", "--name-only")
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    for phase, expected in (("a", True), ("b", False), ("b_v2", True)):
        for prefix in ("preparation", "capture"):
            name = f"{prefix}_{phase}.json"
            assert (HERE / name).read_bytes() == (CONTROL / name).read_bytes()
        capture = read(HERE / f"capture_{phase}.json")
        assert capture["calculation_completed"] == expected and capture["post_run_observations_qualified"]
        if not expected:
            assert "assert total == riesz" in capture["stdout_and_stderr"]
    assert not read(HERE / "setup_v2_failure.json")["worker_launched"]
    for source in HERE.glob("*.source.txt"):
        assert source.read_bytes() == (HERE / source.name.removesuffix(".source.txt")).read_bytes()
    v1 = (HERE / "causal.py").read_text(encoding="utf-8")
    v2 = (HERE / "causal_v2.py").read_text(encoding="utf-8")
    assert v2 == v1.replace("4 * (-1)**n", "4 * (-1)**(n+1)").replace("preparation_b.json", "preparation_b_v2.json").replace('"result_b.json"', '"result_b_v2.json"')
    for name in prep["owner_receipts"]:
        assert read(ROOT / name)["execution_state"] == "COMPLETED", name

    a, b = read(HERE / "result_a.json"), read(HERE / "result_b_v2.json")
    assert a["execution_state"] == b["execution_state"] == "COMPLETED"
    checks = independent_checks(a, b)
    print("STAGE scalar endpoint, tail and failure lineage independently checked", flush=True)

    e4 = subprocess.run([sys.executable, "-B", "tools/research_check.py", "e4", "--historical-context",
                         "D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4"],
                        cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=120)
    save("e4_capture.json", {"exit_code": e4.returncode, "stdout": e4.stdout, "stderr": e4.stderr})
    events = [json.loads(line) for line in e4.stdout.splitlines() if line.strip()]
    steps = [event for event in events if event.get("event") == "step_finished"]
    exits = [event["exit_code"] for event in steps]
    assert e4.returncode == 0 and exits == [0, 0, 0, 0, 0, 2]
    custody = next(event for event in steps if event["step"] == "historical_custody")
    assert custody["stdout"].count("RECORDED_DIGEST_UNRESOLVED:") == 7
    historic = git("show", "ef70f255a667b9a81e37b344dc78967ada4ed896:README.md")
    assert sha256(historic).hexdigest() == "4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792"
    assert (ROOT / "README.md").read_bytes().replace(b"\r\n", b"\n").endswith(historic)
    assert digest(ROOT / "project_state.json") == "d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8"
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    paths = [path for path in HERE.iterdir() if path.is_file()]
    assert sum(path.stat().st_size for path in paths) <= 32 * 1024**2
    paths.extend(ROOT / name for name in prep["navigation"])
    save("validation_receipt.json", {
        "execution_state": "COMPLETED", "evidence_validation": "PASS_COMPACT_CONNECTED_SCALAR_BACKGROUND_TANGENT",
        "scientific_acceptance": "NOT_PERFORMED", "base_HEAD": prep["base_HEAD"],
        "state_sha256": digest(ROOT / "project_state.json"), "owner_receipts": prep["owner_receipts"],
        "independent_checks": checks, "E4_step_exits": exits, "historical_custody": "SEVEN_UNRESOLVED_NOTPASS",
        "files_excluding_pending_receipt_capture": {path.relative_to(ROOT).as_posix(): digest(path) for path in paths},
        "elapsed_after_imports": time.perf_counter() - started,
    })
    watch.cancel()


if __name__ == "__main__":
    main()
