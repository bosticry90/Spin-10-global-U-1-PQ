# V872 separate final review

Freeze phase A, both phase B runs, the prelaunch failure record, final
sources, owner receipts and navigation. The final worker has 180 seconds,
8 GiB sampled private allocation and a 350 MiB launch floor. The E4
subprocess has 120 seconds. Keep the 32 MiB packet limit.

Independently check every scalar operator row by the actual carrier
table, both causal contact residuals, the support boxes and exact tail
bound, and the switch-current coefficient. Check the versioned Riesz
sign repair without editing the failed run. Review the distributional
proof against the bound FCR/CWB/COS1 owners and retain the phase and
causal order. The result concerns only one selected compact quadratic
bridge and its pure-gauge tangent.

Require E4 exit 0 with steps 0,0,0,0,0,2 and seven unresolved custody
references. Preserve the historical README suffix and unchanged
project_state.json. Completion permits a scoped local evidence commit,
with no protected promotion.
