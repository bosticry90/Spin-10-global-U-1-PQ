"""Check the pure-gauge endpoint algebra and strict timelike tail witness."""

from fractions import Fraction
from hashlib import sha256
from math import factorial
import json
import os
import threading
import time

import sympy as sp

from scalar import CALC, HERE, ROOT, read


def transfer_control(phase_a):
    p = sp.symbols("p0:4")
    k = sp.symbols("k0:4")
    minkowski = (1, -1, -1, -1)
    m2 = sp.Symbol("Mref_Phi_squared", positive=True)
    incoming = sum(metric * value**2 for metric, value in zip(minkowski, p)) - m2
    outgoing = sum(metric * (value + step)**2 for metric, value, step in zip(minkowski, p, k)) - m2
    r = 2 * sp.sqrt(10) / 5
    checks = []
    for i, j, carrier in ((180, 225, r), (225, 180, -r)):
        positions = [(omega, field, sp.sympify(value))
                     for h, omega, field, a, b, value in phase_a["complete_reference_scalar_euler"]
                     if (h, a, b) == (0, i, j)]
        assert len(positions) == 8
        contributions = []
        for omega, field, value in positions:
            # Every selected derivative pair has one contracted index.
            assert len(omega + field) == 2 and len(set(omega + field)) == 1
            factor = minkowski[omega[0]]
            factor *= sp.prod(sp.I * k[mu] for mu in omega) * sp.prod(sp.I * p[mu] for mu in field)
            contributions.append((len(omega), factor * value))
        total = sp.expand(sum(value for _, value in contributions))
        assert sp.expand(total - (incoming - outgoing) * carrier) == 0
        missing = sp.expand(sum(value for degree, value in contributions if degree == 2))
        assert missing and missing == sp.expand(-carrier * sum(metric * step**2 for metric, step in zip(minkowski, k)))
        checks.append({"ports": [i, j], "carrier": str(carrier), "affine_transfer_symbol": str(total),
                       "missing_second_jet": str(missing)})
    return checks


def endpoint_controls():
    Ko, Ki, R, A, Wo, Wi = sp.symbols("K_out K_in G_ret G_adv W_out W_in")
    r = 2 * sp.sqrt(10) / 5
    insertion = Ki - Ko
    # Separate algebras avoid forming G and W at the same endpoint.
    left_ideal = sp.groebner([R * Ko - 1, Ki * Wi], R, Ko, Ki, Wi)
    right_ideal = sp.groebner([Ki * A - 1, Wo * Ko], A, Ki, Ko, Wo)
    left = r * left_ideal.reduce(-R * insertion * Wi)[1]
    right = r * right_ideal.reduce(-Wo * insertion * A)[1]
    assert left == r * Wi and right == -r * Wo
    left_no_delta = sp.groebner([R * Ko, Ki * Wi], R, Ko, Ki, Wi)
    right_no_delta = sp.groebner([Ki * A, Wo * Ko], A, Ki, Ko, Wo)
    assert left_no_delta.reduce(-R * insertion * Wi)[1] == 0
    assert right_no_delta.reduce(-Wo * insertion * A)[1] == 0
    assert sp.expand(left + right - r * (Wi - Wo)) == 0
    # Check the shell sign of C_F-W on the two frequency halves.
    shell_rows = [[frequency, 1 - 2 * int(frequency > 0), -frequency] for frequency in (-1, 1)]
    assert all(cf_minus_w == adv for _, cf_minus_w, adv in shell_rows)
    return {"left": str(left), "right": str(right), "without_either_delta": [str(left), str(right)],
            "shell_coefficients_in_pi_units": shell_rows}


def causal_tail():
    # Work in the dimensionless variable z^2=m^2 tau^2. Coordinates
    # are in units of 1/m, so this never fixes the reference mass.
    width = Fraction(1, 32)
    center = Fraction(1, 2)
    time_min, time_max = center - 2 * width, center + 2 * width
    low = time_min**2 - 3 * (2 * width)**2
    high = time_max**2
    assert low == Fraction(46, 256) and high == Fraction(81, 256)
    lower_bound = Fraction(1, 2) - high / 16
    assert lower_bound > 0 and high / 8 < 1
    rows = []
    for z2 in (low, (low + high) / 2, high):
        bessel = Fraction(1, 2)
        total = bessel
        for index in range(1, 8):
            bessel *= -z2 / (4 * index * (index + 1))
            total += bessel
        riesz = sum(Fraction(4 * (-1)**(n+1), 2**(2*n+1) * factorial(n-1) * factorial(n)) * z2**(n-1)
                    for n in range(1, 9))
        assert total == riesz and total >= lower_bound
        rows.append([str(z2), str(total)])
    # A past-to-local pair in this orientation tests G_adv. The
    # retarded term is exactly zero on the product of supports.
    return {"time_order": "past minus local", "z_squared_interval": [str(low), str(high)],
            "positive_adv_lower_bound_in_m2_over_4pi_units": str(lower_bound),
            "exact_series_controls": rows, "retarded_zero": True, "Delta_sign": -1}


def switch_control():
    t = sp.Symbol("t")
    v, x = (sp.Function(name)(t) for name in ("v", "x"))
    m2 = sp.Symbol("Mref_Phi_squared", positive=True)
    inverse = CALC / "canonical_so10_regulator_free_inverse_g1_recovery_v1"
    for role in ("native", "replay"):
        packet = read(inverse / f"{role}_inverse.json.gz")
        physical = {(i, j): sp.sympify(value) for i, j, value in packet["Pphysical"]}
        reference = {(i, j): sp.sympify(value, locals={str(m2): m2}) for i, j, value in packet["Preference"]}
        assert all(sp.expand(reference[i, i] - physical[i, i]) == m2 for i in (180, 225))
    switched = v * ((x * sp.diff(x, t)).diff(t) + m2 * x**2) / 2
    current = sp.diff(v * x * sp.diff(x, t) / 2 - sp.diff(v, t) * x**2 / 4, t)
    reduced = (m2 * v + sp.diff(v, t, 2) / 2) * x**2 / 2
    assert sp.expand(switched - current - reduced) == 0
    # In the strict separated pairing the field is constant on supp v
    # and Box on the advanced kernel gives -m^2 times the kernel.
    assert sp.simplify((m2 - m2 / 2) / m2) == sp.Rational(1, 2)
    r = 2 * sp.sqrt(10) / 5
    return {"isolated_fixed_W_defect_factor": str(-r * m2), "transport_factor": str(r * m2),
            "with_kinetic_current_ratio": "1/2"}


def main():
    started = time.perf_counter()
    watch = threading.Timer(120, lambda: os._exit(124))
    watch.daemon = True
    watch.start()
    for name, expected in read(HERE / "preparation_b_v2.json")["sha256"].items():
        assert sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    phase_a = read(HERE / "result_a.json")
    assert all(not role["residual"] for role in phase_a["roles"])
    transfer = transfer_control(phase_a)
    endpoint = endpoint_controls()
    print("STAGE actual scalar transfer and both off-shell endpoints checked", flush=True)
    tail = causal_tail()
    current = switch_control()
    print("STAGE strict timelike support and scalar switch current checked", flush=True)
    result = {"execution_state": "COMPLETED", "scientific_acceptance": "NOT_PERFORMED",
              "transfer": transfer, "endpoints": endpoint, "tail": tail, "switch": current,
              "seconds": time.perf_counter() - started}
    data = (json.dumps(result, sort_keys=True) + "\n").encode()
    name = "result_b_v2.json" if len(data) <= 8 * 1024**2 else "result_b.COMPLETE_OVERFLOW_NOTPASS"
    with (HERE / name).open("xb") as stream:
        stream.write(data)
    assert name == "result_b_v2.json"
    watch.cancel()


if __name__ == "__main__":
    main()
