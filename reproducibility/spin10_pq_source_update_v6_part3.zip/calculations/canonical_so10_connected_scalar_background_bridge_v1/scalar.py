"""Compare physical and reference scalar variations at the actual ports."""

from collections import Counter, defaultdict
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import gzip
import json
import os
import threading
import time

import sympy as sp


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CALC = ROOT / "calculations"
CURRENT = CALC / "canonical_so10_joint_common_family_applicability_v1"
V869 = CALC / "canonical_so10_current_background_reference_bridge_v1"
PHYSICAL = CALC / "canonical_so10_physical_current_input_recovery_g1_v1"


def read(path):
    if path.suffix == ".gz":
        with gzip.open(path) as stream:
            return json.load(stream)
    return json.loads(path.read_bytes())


def scalar(i):
    return 180 <= i < 508


@lru_cache(maxsize=2000)
def coefficient(serialized):
    out = sp.S.Zero
    for (grade, xi, eta, mask), num, den in json.loads(serialized):
        assert (grade, xi, eta) == (1, 0, 0)
        out += sp.Rational(num, den) * sp.sqrt(sp.prod(p for bit, p in enumerate((2, 3, 5, 7)) if mask & (1 << bit))) * (sp.I if mask & 16 else 1)
    return out


def clean(entries):
    out = {}
    for key, value in entries.items():
        expanded = sp.expand(value)
        if expanded:
            out[key] = expanded
    return out


def physical_euler(role, action):
    data = read(CURRENT / f"{role}_complete_full_background_extension.json.gz")
    rules = dict(data["all1391_Tb_columns"])
    affine = {}
    for B in range(48):
        leading = [row for row in rules[B] if row[0] == 0]
        assert leading == [[0, [[1379 + B // 4, [B % 4]]], [[[0, 0, 0], 1, 1]]]]
        assert leading == [[0, word, cells] for g, word, cells in rules[1331 + B] if g == 0]
        affine[B] = (B // 4, B % 4)
    gf_survivors = [row for row in data["complete_S_GF_source"]
                    if row[0] == 1 and sum(scalar(i) for i, jets in row[1]) >= 2
                    and any(i < 48 or 1331 <= i < 1379 for i, jets in row[1])]
    assert not gf_survivors
    counts = Counter()
    out = defaultdict(int)
    for word, cells in read(PHYSICAL / action)["S1_scalar"]:
        (B, Bjet), (i, left_jet), (j, right_jet) = word
        assert B < 180 and not Bjet and scalar(i) and scalar(j)
        assert len(left_jet) + len(right_jet) == 1
        if B not in affine:
            counts["heavy_inactive"] += 1
            continue
        counts["light_active"] += 1
        h, mu = affine[B]
        value = coefficient(json.dumps(cells))
        for row, out_jet, col, in_jet in ((i, left_jet, j, right_jet), (j, right_jet, i, left_jet)):
            if out_jet:
                derivative = out_jet[0]
                out[h, tuple(sorted((mu, derivative))), (), row, col] -= value
                out[h, (mu,), (derivative,), row, col] -= value
            else:
                out[h, (mu,), tuple(in_jet), row, col] += value
    assert sum(counts.values()) == 50240
    return clean(out), counts


def reference_euler():
    data = read(V869 / "result_b.json")
    euler = {(h, tuple(omega), tuple(field), i, j): sp.sympify(value)
             for h, omega, field, i, j, value in data["complete_parameter_jet_identity"] if scalar(i) and scalar(j)}
    carriers = read(V869 / "result_a.json")["compared"]["twelve_current_homogeneous_carriers"]
    formula = {}
    for h, rows in enumerate(carriers):
        for i, j, value in rows:
            if not (scalar(i) and scalar(j)):
                continue
            r = sp.sympify(value)
            for mu in range(4):
                formula[h, (mu, mu), (), i, j] = r
                formula[h, (mu,), (mu,), i, j] = 2 * r
    assert euler == formula
    r0 = 2 * sp.sqrt(10) / 5
    assert euler[0, (0, 0), (), 180, 225] == r0
    assert euler[0, (0, 0), (), 225, 180] == -r0
    assert all(i < 506 and j < 506 for h, omega, field, i, j in euler)
    return euler


def encode(entries):
    return [[*key, str(value)] for key, value in sorted(entries.items())]


def main():
    start = time.perf_counter()
    watch = threading.Timer(120, lambda: os._exit(124))
    watch.daemon = True
    watch.start()
    for name, expected in read(HERE / "preparation_a.json")["sha256"].items():
        assert sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    reference = reference_euler()
    reports = []
    for role, action in (("native", "native_v2_action.json.gz"), ("replay", "replay_v4_action.json.gz")):
        actual, counts = physical_euler(role, action)
        residual = clean({key: actual.get(key, 0) - reference.get(key, 0) for key in actual.keys() | reference.keys()})
        reports.append({"route": role, "literal_rows": counts, "parameter_jet_positions": len(actual), "residual": encode(residual)})
        print(f"STAGE {role} scalar background coefficient comparison finished", flush=True)
    second = sum(len(omega) == 2 for h, omega, field, i, j in reference)
    assert second and second * 2 == len(reference)
    passed = all(not report["residual"] for report in reports)
    data = (json.dumps({"execution_state": "COMPLETED" if passed else "FAILED_OPERATOR_COMPARISON",
                        "scientific_acceptance": "NOT_PERFORMED", "complete_reference_scalar_euler": encode(reference),
                        "roles": reports, "omit_second_parameter_jet_residual": second,
                        "phase": "A_ACTUAL_SCALAR_HESSIAN_COMPARISON", "seconds": time.perf_counter() - start}, sort_keys=True) + "\n").encode()
    name = "result_a.json" if len(data) <= 8 * 1024**2 else "result_a.COMPLETE_OVERFLOW_NOTPASS"
    with (HERE / name).open("xb") as stream:
        stream.write(data)
    assert name == "result_a.json" and passed
    watch.cancel()


if __name__ == "__main__":
    main()
