# Connected scalar Ward compensation at a compact pure-gauge tangent

Use the V869 compact parent and the absolute fixed-flat branch bound in
V871. Work at the unprobed scalar reference and take one first-g
quadratic insertion with compact light parameter nu. The parameter and
its jets are supported within the common sigma=1 region. Phase A uses
the complete physical scalar kinetic rows and the full unprobed GF/source
packet. Its affine scalar Hessian agrees with the V869 reference variation
at every retained position. In the actual compact parent the varied
reference term and its opposite in the interaction both occur. Their
sum is zero on the parameter support, where the physical kinetic term
supplies the matched variation. Switch currents are retained in the
parent. This statement concerns the selected affine insertion with no
other fluctuation vertices on the scalar bridge.

## Transport from the actual relative product

Write K0=P−m²=−Box−m² for an actual scalar block in the Minkowski chart
of FCR1, and M=g r(nu) for the real skew scalar multiplication tangent.
The first-g physical Euler kernel has, in the current Euclidean chart,
2g r(partial_mu nu) partial_mu+g r(Box_E nu). With the bound Wick
phases on the derivative and scalar action, the contracted Minkowski
operator is 2g r(partial^mu nu) partial_mu+g r(Box nu), with

    dK = −M^sharp K0 − K0 M.

Here sharp is the ordinary formal dual on the even scalar block. Its
extension to this compact parameter retains the derivative of M.
The phase B transfer check reduces the same operator to
(K_in−K_out) M, where K_out uses the shifted scalar momentum. Masses
match within each actual representation, so the mass cancels in the
difference. No mass or carrier is fitted to the identity.

For the first insertion V=1/2 integral z dK z, differentiate the
relative COS1 product against a linear scalar observable F. The first
coefficient is (i/hbar)(T2(V,F)−V star F). On the action-to-field
ordering CWB1 gives C_F−W=i G_adv. In the scalar frequency representation
the common principal value cancels in this check. The shell coefficient
of iG_F−W is pi(1−2 theta(p0)) delta(P−m²), exactly that of iG_adv.
Thus the identity includes the full boundary distribution. Since dK is formally symmetric as
a differential operator, contraction of the two ordinary ports
transposes that advanced kernel to the output-field G_ret. The two
Wick choices cancel the factor 1/2. The two i factors give a minus,
so the linear output map has variation −G_ret dK. This uses the full
time-ordered covariance, including the off-shell contact. In the
opposite endpoint pairing the dual variation is −dK G_adv.

This finite insertion therefore gives the contraction variation

    dW = −G_ret dK W − W dK G_adv.

For compact endpoints f and h, G_adv f and G_adv h are smooth by FCR1.
Applying the compact-coefficient dK makes new compact test functions.
The two terms are paired with the original CWB1 bisolution on those
test functions. Thus the compositions in this statement do not multiply
two on-shell distributions at a common momentum. The two-sided inverse
identities and the two Wightman bisolution identities give, in the
displayed order,

    −G_ret dK W = M W,
    −W dK G_adv = W M^sharp.

For example the left endpoint term on (f,h) is
−W(dK G_adv f,h). Substituting dK moves the K0 onto the first
W argument in one term, which gives zero by the bisolution, and
uses K0 G_adv f=f in the other. The right endpoint uses the
dual contact. The identity is also obtained by applying the same
algebra to the independent incoming and outgoing momentum symbols.
Erasing a delta contact would leave one of the two endpoint terms
uncanceled. A purely algebraic inverse identity is blind to exchanging
retarded and advanced inverses on this special tangent, so the time
support is checked separately from the Ward signs.

On a generic off-shell field, −G_ret dK z equals M z plus
G_ret M^sharp K0 z. The second term is generally nonzero. The cancellation
above uses the bisolution at the contracted endpoint.

## Nonzero past-to-local contraction

At first order in a past switch difference, keep the actual Phi reference
mass-defect vertex in S_A−R_A. Its Minkowski coefficient is
+m²/2 times the switched ordinary Phi square. Take the local field
x_180 and a nu_0 parameter vanishing on the past support. From the
actual skew carrier r_0[180,225]=2 sqrt(10)/5, the frozen-W difference
between the coordinate action on the relative conjugate and conjugating
the coordinate action is

    −g (2 sqrt(10)/5) m² integral dσ_-(x) f(y) nu_0(y)
                                  Delta(x−y) x_225(x).

Here dσ_- denotes the change of the past switch, not its derivative.
The relative convention is U=S(V+h_-)^-1 star S(V). Its coefficient
with one h_- and no other interaction vertices is −i h_-/hbar.
At general base V the derivative uses the relative insertion R_V(h_-).
The commutator of a quadratic vertex and a
linear field uses i hbar Delta and two equivalent field choices. These
fix the stated sign. Equivalently the fixed-W Leibniz defect on a single
contraction is minus the contraction with M W+W M^sharp. Only the
local endpoint remains in the past-to-local support test.

Choose compact nonnegative past and local tests in boxes centered at
time 0 and 1/(2m), with each coordinate radius at most 1/(32m).
The past-to-local time difference is strictly negative, and the
positive timelike length tau has
46/256 <= m² tau² <= 81/256. The retarded kernel is zero in that
ordering. In the advanced kernel of K0 the interior tail is
+m J1(m tau)/(4 pi tau). Thus Delta=G_ret−G_adv is strictly negative
on the product support. The alternating Bessel series has
J1(z)/z >= 1/2−z²/16 in that interval. The FCR1 Riesz series gives
the same normalized bound. Pairing with nonzero tests and with a
nonnegative Phi_225 field on the past region gives a nonzero coefficient.
This uses a reference mass to describe the support, without choosing
a physical mass or evaluating the propagator on the light cone.

There is also a control keeping the scalar kinetic switch current in
the same reference-dependent quadratic slice. The literal Minkowski
kinetic term minus the Euler-normal reference equals
div(x partial x)/2+m²x²/2. Multiplying by the past switch change v
gives the quadratic insertion with Hessian m²v+Box v/2 after integration
by parts. Choose the off-shell x_225 field constant on a neighborhood
of supp v. Moving Box off v onto the strictly separated advanced kernel
gives −m² times that kernel, since there is no diagonal contact between
these boxes. The combined kinetic/reference slice therefore has one
half the nonzero isolated mass-defect coefficient and the same sign.
Independent physical potential terms remain separate in the action.

Replacing the contraction by its transported one adds the same
nonzero term with the opposite sign. This is the selected connected
Ward compensation. The plateau-local input-strength derivative of
the past transporter may vanish by LAC1 and V871. The displayed
fixed-W defect still exists if only the coordinate action is used.
The compensation uses the action-induced change of the contraction,
not an affine derivation of a fixed free product. It keeps the
opposite R_A contribution in the actual compact split and does not
count a second reference insertion. It says nothing about the
quantum operation T_q fixing A, general interacting products, or
equality of arbitrary-background retarded and Feynman states.

The two calculations share the same action, reference and causal
inputs, software and AI authorship. No new loop integral or
scientific promotion is inferred.
