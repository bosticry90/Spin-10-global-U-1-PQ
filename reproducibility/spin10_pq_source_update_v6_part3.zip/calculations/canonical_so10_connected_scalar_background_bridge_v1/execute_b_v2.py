"""Freeze and run the compact scalar causal comparison."""

import ast
import sys
from hashlib import sha256

from execute_a import CONTROL, HERE, PK, ROOT, git, save
from scalar import read


def main():
    prior = read(HERE / "preparation_a.json")
    head = git("rev-parse", "HEAD").decode().strip()
    assert head == prior["base_HEAD"] and not git("diff", "--name-only", "HEAD")
    assert git("ls-tree", "-r", "HEAD") == (CONTROL / "old_git_tree.txt").read_bytes()
    for name, expected in prior["sha256"].items():
        assert sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    for name in ("preparation_a.json", "capture_a.json", "preparation_b.json", "capture_b.json"):
        assert (HERE / name).read_bytes() == (CONTROL / name).read_bytes()
    capture_a = read(HERE / "capture_a.json")
    assert capture_a["calculation_completed"] and capture_a["post_run_observations_qualified"]
    for name in ("PHASE_B_CONTINUATION_V2.md", "causal_v2.py", "execute_b_v2.py"):
        data = (HERE / name).read_bytes()
        if name.endswith(".py"):
            ast.parse(data)
        with (HERE / (name + ".source.txt")).open("xb") as stream:
            stream.write(data)
    names = set(prior["sha256"])
    names.update(path.relative_to(ROOT).as_posix() for path in HERE.iterdir() if path.is_file())
    records = {
        "causal_one_loop_sewing": ("DERIVATION.md", "validation_receipt.json"),
        "local_cutoff_comparison": ("RESULT.md", "validation_receipt_v4.json"),
        "regulator_free_inverse_g1_recovery_v1": ("validation_receipt.json", "native_inverse.json.gz", "replay_inverse.json.gz"),
    }
    for folder, files in records.items():
        names.update(f"calculations/canonical_so10_{folder}/{name}" for name in files)
    save("preparation_b_v2.json", {
        "base_HEAD": head,
        "sha256": {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in sorted(names)},
        "limits": prior["limits"], "scientific_acceptance": "NOT_PERFORMED",
    })
    sys.path.insert(0, str(PK))
    from export_a10_e5_antighost_vector import capture

    report = capture([sys.executable, "-B", str(HERE / "causal_v2.py")])
    save("capture_b_v2.json", report)
    print(report["stdout_and_stderr"], end="")
    assert report["calculation_completed"] and report["post_run_observations_qualified"]
    assert sum(path.stat().st_size for path in HERE.iterdir() if path.is_file()) <= 32 * 1024**2


if __name__ == "__main__":
    main()
