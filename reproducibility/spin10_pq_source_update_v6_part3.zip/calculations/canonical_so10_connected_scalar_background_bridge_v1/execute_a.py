"""Freeze the actual scalar bridge comparison before running it."""

import ast
import json
import subprocess
import sys
from hashlib import sha256
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CONTROL = Path("D:/Codex-Research/ToE-Next/research-control-records/connected-scalar-background-bridge-v1-2026-11-08")
PK = ROOT / "tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1"


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def save(filename, report):
    data = (json.dumps(report, sort_keys=True) + "\n").encode()
    for folder in (HERE, CONTROL):
        with (folder / filename).open("xb") as stream:
            stream.write(data)


def main():
    head = git("rev-parse", "HEAD").decode().strip()
    assert head == "c9c700ee64ade6be8c401810784643a11c1e0766"
    assert not git("diff", "--name-only", "HEAD")
    names = {"AGENTS.md", "CHARTER.md", "project_state.json", "docs/RESEARCH_EXECUTION_HANDOFF_V871.md"}
    records = {
        "compact_retained_source_functional_v1": ("PROOF.md", "validation_receipt.json"),
        "current_background_reference_bridge_v1": ("PROOF.md", "result_a.json", "result_b.json", "validation_receipt.json"),
        "joint_common_family_applicability_v1": ("PROOF.md", "validation_receipt.json", "native_complete_full_background_extension.json.gz", "replay_complete_full_background_extension.json.gz"),
        "physical_current_input_recovery_g1_v1": ("validation_receipt.json", "native_v2_action.json.gz", "replay_v4_action.json.gz"),
        "free_causal_reference": ("DERIVATION.md", "validation_receipt_v3.json"),
        "causal_wick_bridge": ("DERIVATION.md", "validation_receipt.json"),
    }
    for folder, filenames in records.items():
        names.update(f"calculations/canonical_so10_{folder}/{name}" for name in filenames)
    names.add((PK / "export_a10_e5_antighost_vector.py").relative_to(ROOT).as_posix())
    assert all((ROOT / name).is_file() for name in names)
    CONTROL.mkdir(exist_ok=False)
    with (CONTROL / "old_git_tree.txt").open("xb") as stream:
        stream.write(git("ls-tree", "-r", "HEAD"))
    for name in ("RECORD.md", "scalar.py", "execute_a.py"):
        data = (HERE / name).read_bytes()
        if name.endswith(".py"):
            ast.parse(data)
        with (HERE / (name + ".source.txt")).open("xb") as stream:
            stream.write(data)
    names.update(path.relative_to(ROOT).as_posix() for path in HERE.iterdir() if path.is_file())
    save("preparation_a.json", {
        "base_HEAD": head,
        "sha256": {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in sorted(names)},
        "limits": {"seconds": 120, "sampled_private_bytes": 8 * 1024**3, "packet_bytes": 32 * 1024**2,
                   "artifact_bytes": 8 * 1024**2, "minimum_available_commit_bytes": 350 * 1024**2},
        "scientific_acceptance": "NOT_PERFORMED",
    })
    sys.path.insert(0, str(PK))
    from export_a10_e5_antighost_vector import capture

    report = capture([sys.executable, "-B", str(HERE / "scalar.py")])
    save("capture_a.json", report)
    print(report["stdout_and_stderr"], end="")
    assert report["calculation_completed"] and report["post_run_observations_qualified"]
    assert sum(path.stat().st_size for path in HERE.iterdir() if path.is_file()) <= 32 * 1024**2


if __name__ == "__main__":
    main()
