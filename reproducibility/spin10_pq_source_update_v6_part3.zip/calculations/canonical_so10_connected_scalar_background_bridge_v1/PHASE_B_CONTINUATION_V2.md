# V872 phase B verifier continuation

The first phase B worker completed the scalar transfer and endpoint
checks, then failed its exact Bessel/Riesz comparison at causal.py:88.
The Riesz summand used the sign of D_m. FCR1 defines the actual scalar
inverse of K0=P−m² to be −D_m. The proof already uses that orientation
and the positive advanced interior tail. Correct the Riesz sign in
the verifier. Keep the support boxes, series order, exact lower bound,
endpoints and limits unchanged. Preserve the original source, preparation
and failed capture. Freeze the versioned worker and bind the failure
before the new run. No prior completion is inferred.
