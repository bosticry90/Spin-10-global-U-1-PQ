# V872 phase B compact causal scalar comparison

Freeze the proof, new sources and completed phase A packet before
execution. Work in the same unprobed scalar sector at the flat reference,
one first-g light parameter and one quadratic insertion. Its compact
support lies where both switches equal one. Keep the V869 literal
reference subtraction and actual physical scalar variation. Bind the
FCR1 two-sided Green operators, CWB1 Wick covariance and ordered contact,
and the existing COS1 relative product on independent compact labels.

Compare the two transported scalar endpoints with the fixed-W defect
using the compact weak operator identities and their independent
transfer-symbol reduction. Verify the actual skew Phi 180,225 pair
and the second parameter jet. Use past and local compact test boxes
strictly timelike separated in units of the positive Phi reference
mass. Establish a nonzero signed bound for the actual Pauli–Jordan
tail by the convergent Riesz and Bessel formulas. Use the mass-defect
past vertex and one local field to test the endpoint compensation. Also
keep the kinetic switch current in that quadratic reference slice and
check its separated-support contribution.
Omitting either contact must fail on its own endpoint test. Keep the
separate causal support control since pure gauge alone cannot
distinguish two algebraic inverses with different support.

Root owns writes and runs. Limit the worker to 120 seconds, 8 GiB
sampled private allocation, a 350 MiB launch floor, 8 MiB result and
32 MiB packet. Keep exact captures and failures. There is no new loop
integral. Final validation and E4 precede a local commit. The ceiling
is the finite first-g scalar connected bridge, without a general
background state, full Ward proof, scientific promotion or E5/A5 claim.
