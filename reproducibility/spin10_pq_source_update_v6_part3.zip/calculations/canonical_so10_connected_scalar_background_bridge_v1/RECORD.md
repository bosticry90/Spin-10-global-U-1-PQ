# V872 connected scalar background bridge

Continue V871 on main, D:, under AGENTS. The question is whether the
actual first-g compact scalar bridge supplies the background variation
needed to compensate the fixed free Wick contraction. Use the same
covariant reference and compact subtraction P=R_A+sigma(S_A−R_A).
Start with the unprobed scalar sector around the flat reference, one
compact light background parameter supported in a shared sigma=1
plateau, and one first-g quadratic insertion in the tree bridge. Keep
the general compact action and its reference subtraction in the proof.

Phase A compares the complete first-g ordinary scalar Hessian variation
from the V787 physical scalar kinetic density under the actual light
affine B rule with the V869 reference variation under the affine A rule.
Use explicit Euler integration by parts in the current Euclidean chart.
Bind all 328 scalar ports and twelve light parameters, including the
singlet zero block. Check the full actual GF/source packet for additional
scalar-pair terms under the same affine replacement. Keep the
nonzero Phi 180,225 carrier, and test omission of the parameter second
derivative. This gives an actual total-parent comparison on the plateau,
where the opposite R_A vertex subtracts the reference variation and the
physical kinetic term supplies it. It is an operator check, not yet a
distributional Ward comparison.

Freeze sources and input owners before execution. Root owns writes.
The worker limit is 120 seconds, 8 GiB sampled private allocation, a
350 MiB launch floor, 8 MiB artifact and 32 MiB packet. Preserve exact
outputs and any failure. Final qualification awaits phase B.

Phase B uses the same FCR1 retarded and advanced inverses and CWB1 free
Wightman kernel. Derive the first-order retarded field transport from
the actual relative COS1 product and test the two endpoint corrections
against the fixed-reference affine defect. Keep the off-shell delta,
literal reference split and causal support. Use an actual nonzero
past-to-local Phi contraction control. The pure-gauge tangent result
does not assign a state for arbitrary backgrounds or give a derivation
of the fixed free star product. Quantum Ward, general connected
products, full E5/A5 and physical viability remain outside this gate.
