# V872 connected scalar background tangent

Use with the separate completed final receipt and capture. The actual
compact first-g scalar kinetic variation supplies the connected
compensating contraction on the common plateau. Both physical routes
match all 39,664 scalar parameter-jet positions to the covariant
reference. Omitting the second parameter derivative loses 19,832
positions. The opposite R_A vertex is kept in the compact split.

The first relative COS1 insertion gives the retarded output variation
−G_ret dK. Its dual and the two off-shell contacts give the scalar
contraction variation MW+WM^sharp on the compact pure-gauge tangent.
This cancels the fixed-reference defect on that selected connected
contraction. The off-shell field map retains its K0 term. A strict
timelike Phi past-to-local pairing has nonzero advanced tail and zero
retarded term in the selected order. The actual 180,225 carrier is
2 sqrt(10)/5, with negative reverse. Including the scalar kinetic
switch current leaves half the isolated mass-defect coefficient
in the reference-dependent quadratic slice and preserves its sign.

The initial tail verifier used D_m instead of the actual −D_m
inverse in its Riesz comparison. The corrected run keeps the same
tests and bounds. Both the failed worker and a separate prelaunch
copier failure remain recorded. No new loop integral was evaluated.

[Proof](PROOF.md) and [review](FINAL_RECORD.md). This is a finite
first-g scalar bridge on the declared free causal branch. The
compact gauge/auxiliary and ghost blocks need their own graded
ordering and support tests. Connected W5, more general Ward products,
arbitrary states, global limits, full E5/A5 and physical viability
remain open. The calculations share action, reference, analytic
premises, software and AI authorship. Authority 34/39 and seven
unresolved historical custody references retain their status.
