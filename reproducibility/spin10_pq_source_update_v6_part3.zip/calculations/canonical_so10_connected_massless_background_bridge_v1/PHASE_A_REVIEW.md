# V873 phase A massless operator disposition

Both frozen routes completed in 15.321 seconds with maximum sampled
private allocation of 224,251,904 bytes. The literal physical gauge
and full GF/source rows yield 16,240 even and 3,248 odd active affine
placements. The ordinary LEFT Euler agrees with all 34,104 V869
non-scalar parameter-jet positions, including 6,496 ordered odd
positions. Dropping the sign from removing the second odd port leaves
3,248 residuals. No cross-scalar position survives. The V872 scalar
comparison remains intact. The causal phase and final review are open.

The next test uses the same off-shell weak distribution identities as
V872, with the graded tensor flip kept distinct from the ordinary
operator dual. In an odd contraction of a quadratic vertex the
evaluation sign and the tensor flip must both be included. In
particular do not treat the graded flip as an ordinary transpose of
operator compositions. FCR1 supplies both mixed orientations and the
width dipole through Box D4=D2. The ordered ghost contacts use
G_Ca=−D2 and G_aC=+D2. CWB1 supplies their respective time-ordered
phase and homogeneous Wightman versions. The pure-gauge endpoint
identity alone is blind to retarded/advanced exchange.

Use compact null-related supports for a nonblind massless witness.
The actual carrier r_0 for light colors 1 and 2 is sqrt(10)/4 in
the vector, auxiliary, C and a blocks, with negative reverse. In the
Minkowski quadratic reference slice the past mixed current is
+(partial v) Lambda B/2, with v the past switch difference. Test a
local B^0 with the uncontracted past Lambda constant near supp v and
all past B fields zero. Moving the derivative onto the complete
BB causal difference gives the coefficient proportional to
−eta_H partial_0(D2_ret−D2_adv)/2. Dropping the dipole changes eta_H
to 1 in this control. Choose the past test's time derivative with
fixed sign over the cone intersections, keeping its descending part
outside them. For the odd block use the actual ordered off-shell
delta, or the g0 current row −(partial0 C_2) J_B2, with its bound
Minkowski phase and graded commutator. A timelike-only massless test
can be blind. Keep the literal switch currents, the opposite R_A
vertex and any off-shell K0 term before using a bisolution. No new
loop or general connected Ward conclusion follows from phase A.
