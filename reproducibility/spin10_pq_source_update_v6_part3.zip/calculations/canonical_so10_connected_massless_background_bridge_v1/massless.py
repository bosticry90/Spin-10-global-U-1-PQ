"""Compare all actual non-scalar affine Hessian coefficients to V869."""

from collections import Counter, defaultdict
from functools import lru_cache
from hashlib import sha256
from itertools import product
from pathlib import Path
import gzip
import json
import os
import threading
import time

import sympy as sp


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CALC = ROOT / "calculations"
CURRENT = CALC / "canonical_so10_joint_common_family_applicability_v1"
PHYSICAL = CALC / "canonical_so10_physical_current_input_recovery_g1_v1"
V869 = CALC / "canonical_so10_current_background_reference_bridge_v1"


def read(path):
    if path.suffix == ".gz":
        with gzip.open(path) as stream:
            return json.load(stream)
    return json.loads(path.read_bytes())


def ordinary_scalar(n):
    return 180 <= n < 508


@lru_cache(maxsize=3000)
def coefficient(cells):
    xi, eta = sp.symbols("xi eta_H")
    out = sp.S.Zero
    for (heavy_width, light_width, mask), num, den in cells:
        roots = sp.sqrt(sp.prod(p for bit, p in enumerate((2, 3, 5, 7)) if mask & (1 << bit)))
        out += sp.Rational(num, den) * xi**heavy_width * eta**light_width * roots * (sp.I if mask & 16 else 1)
    return out


def clean(entries):
    result = {}
    for key, value in entries.items():
        expanded = sp.expand(value)
        if expanded:
            result[key] = expanded
    return result


def encode(entries):
    return [[*key, str(value)] for key, value in sorted(entries.items())]


def affine_ports(data):
    rules = dict(data["all1391_Tb_columns"])
    result = {}
    for ports in (range(48), range(1331, 1379)):
        for offset, n in enumerate(ports):
            leading = [row for row in rules[n] if row[0] == 0]
            assert leading == [[0, [[1379 + offset // 4, [offset % 4]]], [[[0, 0, 0], 1, 1]]]]
            result[n] = offset // 4, offset % 4
    return result


def euler(rows, affine, parity):
    result = defaultdict(int)
    wrong_odd = defaultdict(int)
    counts = Counter()
    for word, cells in rows:
        if len(word) != 3:
            continue
        for slot, (target, target_jets) in enumerate(word):
            if target not in affine:
                continue
            rest = word[:slot] + word[slot+1:]
            if any(i >= 643 for i, jets in rest):
                continue
            scalar_count = sum(ordinary_scalar(i) for i, jets in rest)
            if scalar_count:
                counts[f"remaining_scalar_{scalar_count}"] += 1
                continue
            h, mu = affine[target]
            omega = tuple(target_jets) + (mu,)
            value = coefficient(tuple((tuple(key), num, den) for key, num, den in cells))
            counts["odd" if parity[rest[0][0]] else "even"] += 1
            for out_slot, (i, out_jets) in enumerate(rest):
                j, in_jets = rest[1 - out_slot]
                assert parity[i] == parity[j]
                odd_sign = (-1) ** (parity[i] * out_slot)
                adjoint = (-1) ** len(out_jets)
                for places in product((0, 1), repeat=len(out_jets)):
                    on_omega = tuple(sorted(omega + tuple(d for d, place in zip(out_jets, places) if place == 0)))
                    on_field = tuple(sorted(tuple(in_jets) + tuple(d for d, place in zip(out_jets, places) if place == 1)))
                    key = h, on_omega, on_field, i, j
                    result[key] += odd_sign * adjoint * value
                    wrong_odd[key] += adjoint * value
    assert not counts["remaining_scalar_1"]
    return clean(result), clean(wrong_odd), dict(counts)


def actual(role, action):
    current = read(CURRENT / f"{role}_complete_full_background_extension.json.gz")
    parity = current["joined_parities"]
    assert parity[:643] == [0] * 553 + [1] * 90
    physical = read(PHYSICAL / action)["S1_gauge"]
    gauge = []
    for word, cells in physical:
        assert all(grade == 1 for (grade, xi, eta, mask), num, den in cells)
        gauge.append((word, [([xi, eta, mask], num, den) for (grade, xi, eta, mask), num, den in cells]))
    gf = [(word, cells) for grade, word, cells in current["complete_S_GF_source"] if grade == 1]
    assert len(gauge) == 20088
    correct, wrong, counts = euler(gauge + gf, affine_ports(current), parity)
    return correct, wrong, counts


def difference(left, right):
    return clean({key: left.get(key, 0) - right.get(key, 0) for key in left.keys() | right.keys()})


def main():
    started = time.perf_counter()
    watch = threading.Timer(120, lambda: os._exit(124))
    watch.daemon = True
    watch.start()
    for name, expected in read(HERE / "preparation_a.json")["sha256"].items():
        assert sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    reference = {(h, tuple(omega), tuple(field), i, j): sp.sympify(value)
                 for h, omega, field, i, j, value in read(V869 / "result_b.json")["complete_parameter_jet_identity"]
                 if not (ordinary_scalar(i) or ordinary_scalar(j))}
    reports = []
    for role, action in (("native", "native_v2_action.json.gz"), ("replay", "replay_v4_action.json.gz")):
        correct, wrong, counts = actual(role, action)
        odd_error = difference(correct, wrong)
        assert odd_error and all(i >= 553 and j >= 553 for h, omega, field, i, j in odd_error)
        reports.append({"route": role, "affine_slot_counts": counts, "actual_positions": len(correct),
                        "wrong_left_odd_sign_residual_count": len(odd_error), "residual": encode(difference(correct, reference))})
        print(f"STAGE {role} graded massless affine Hessian compared", flush=True)
    passed = all(not row["residual"] for row in reports)
    result = {"execution_state": "COMPLETED" if passed else "FAILED_OPERATOR_COMPARISON",
              "scientific_acceptance": "NOT_PERFORMED", "phase": "A_ACTUAL_MASSLESS_OPERATOR_COMPARISON",
              "complete_reference_massless_euler": encode(reference), "roles": reports, "seconds": time.perf_counter() - started}
    data = (json.dumps(result, sort_keys=True) + "\n").encode()
    name = "result_a.json" if len(data) <= 8 * 1024**2 else "result_a.COMPLETE_OVERFLOW_NOTPASS"
    with (HERE / name).open("xb") as stream:
        stream.write(data)
    assert name == "result_a.json" and passed
    watch.cancel()


if __name__ == "__main__":
    main()
