# V873 graded causal endpoint and cone checks

Freeze this record, the proof and worker sources on the V872 base. Bind
the actual completed phase A packet, V869 carrier and reference, V871
literal current and FCR1/CWB1/COS1 owners. Work at the unprobed flat
mean, source and background point after taking the ordinary Hessian.
Use one first-g compact light parameter on the common plateau and one
quadratic bridge insertion. The compact split and its opposite reference
vertex stay in the proof.

Test the full mixed five-block and ordered odd block using the actual
FCR inverse and CWB shell identities. Keep the derivative of the massless
shell and the width dipole. Check both inverse and bisolution orders,
the retarded contraction parity and the distinct operator dual. Omission
of the odd flip or of the dipole must fail a suitable actual block.
Derive both endpoint variations on independent compact test labels.

For the past auxiliary switch-current contribution use null-related
compact supports and the nonzero light 1,2 carrier. Show a signed
cone pairing and the symbolic width dependence. Verify the opposite
ordered ghost cone and local delta contacts. The pure-gauge endpoint
identity alone is blind to retarded/advanced exchange. No pointwise
sampling of a delta, diagonal restriction, new loop integral or physical
width choice.

Root owns writes. The worker has 120 seconds, 8 GiB sampled private
allocation, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.
Preserve exact captures. Final independent review and E4 precede the
local evidence commit. The ceiling is the finite connected W4
massless bridge. Connected W5, general states and full E5/A5 stay open.
