# V873 phase B exact ghost comparison continuation

The first worker stopped at causal.py:58 after the mixed inverse,
shell and missing-dipole checks. One ordered ghost matrix diagonal
was represented by −(−P)/P in expanded momentum coordinates and
the assertion compared expression trees. Exact rational cancellation
gives identity in both orders. Compare the shell equality after
expansion and the transpose after rational cancellation. Keep the
ordered ghost signs, contacts, all tests and resource limits unchanged.
Preserve the original worker, preparation and failure capture. Bind
them before the versioned rerun. No scientific gate was relaxed.
