"""Verify the massless inverse, graded contacts and compact cone control."""

from fractions import Fraction
from hashlib import sha256
import json
import os
import threading
import time

import sympy as sp

from massless import CALC, HERE, ROOT, V869, read


def block_controls():
    p = sp.Matrix(sp.symbols("p0:4", real=True))
    eta = sp.diag(1, -1, -1, -1)
    P = (p.T * eta * p)[0]
    ep = eta * p
    w, d, e = sp.symbols("eta_H d0 e0", real=True)
    I = sp.I
    kernel = (-P * eta + ep * ep.T).row_join(I * ep).col_join((-I * ep.T).row_join(sp.Matrix([[w]])))

    def covariance(simple, double):
        vector = -eta * simple + (1 - w) * p * p.T * double
        return vector.row_join(I * p * simple).col_join((-I * p.T * simple).row_join(sp.zeros(1)))

    green = covariance(1 / P, 1 / P**2)
    shell = covariance(d, -e)
    for product in (kernel * green, green * kernel):
        assert product.applyfunc(sp.cancel) == sp.eye(5)

    def bisolution(product):
        for value in product:
            value = sp.expand(value)
            shell_prime_over_P = sp.cancel(value.coeff(e) / P)
            assert sp.denom(shell_prime_over_P) == 1
            shell_after = sp.expand(value.coeff(d) - shell_prime_over_P)
            assert sp.denom(sp.cancel(shell_after / P)) == 1

    bisolution(kernel * shell)
    bisolution(shell * kernel)
    wrong_green = covariance(1 / P, 0)
    wrong_shell = covariance(d, 0)
    left = sp.cancel((kernel * wrong_green)[4, 0])
    right = sp.cancel((wrong_green * kernel)[0, 4])
    assert sp.cancel(left - I * (1 - w) * p[0] / P) == 0
    assert sp.cancel(right + I * (1 - w) * p[0] / P) == 0
    assert sp.expand((kernel * wrong_shell)[4, 0]) == sp.expand(I * (1 - w) * p[0] * d)
    assert sp.expand((wrong_shell * kernel)[0, 4]) == sp.expand(-I * (1 - w) * p[0] * d)
    reverse = {component: -component for component in p}
    for matrix in (kernel, green, shell):
        assert (matrix.T.xreplace(reverse) - matrix).applyfunc(sp.expand) == sp.zeros(5)

    ghost_k = sp.Matrix([[0, -P], [P, 0]])
    ghost_g = sp.Matrix([[0, 1 / P], [-1 / P, 0]])
    ghost_w = sp.Matrix([[0, d], [-d, 0]])
    assert ghost_k * ghost_g == ghost_g * ghost_k == sp.eye(2)
    assert ghost_k * ghost_w == ghost_w * ghost_k == P * d * sp.eye(2)
    for matrix in (ghost_k, ghost_g, ghost_w):
        assert matrix.T.xreplace(reverse) == -matrix
    # T2 minus star on the first field slot has the evaluation sign s.
    # The ordinary advanced transpose contributes the same s.
    parity = [[p, (-1)**p, (-1)**p, (-1)**(2*p)] for p in (0, 1)]
    assert [row[-1] for row in parity] == [1, 1]
    # Shell coefficients in pi units after subtracting W. The double
    # boundary value has the opposite delta-prime sign to the simple one.
    phases = [[sign, 1 - 2 * int(sign > 0), -1 + 2 * int(sign > 0)] for sign in (-1, 1)]
    assert phases == [[-1, 1, -1], [1, -1, 1]]
    return {"mixed_omitted_dipole_left": str(left), "mixed_omitted_dipole_right": str(right),
            "ordered_ghost_Box_contact": [-1, 1], "parity_factors": parity,
            "advanced_simple_and_double_shell_signs": phases}


def endpoint_control():
    # Typed single-endpoint word checks. No products of an inverse and
    # a shell distribution in the same transfer variable are formed.
    left = {("G_ret", "M^t", "K", "W"): 1, ("G_ret", "K", "M", "W"): 1}
    right = {("W", "M^t", "K", "G_adv"): 1, ("W", "K", "M", "G_adv"): 1}

    def reduce(words, contact, bisolution, drop_contact=False):
        reduced = {}
        for word, value in words.items():
            pairs = tuple(zip(word, word[1:]))
            if bisolution in pairs or drop_contact and contact in pairs:
                continue
            index = pairs.index(contact)
            after = word[:index] + word[index+2:]
            reduced[after] = value
        return reduced

    assert reduce(left, ("G_ret", "K"), ("K", "W")) == {("M", "W"): 1}
    assert reduce(right, ("K", "G_adv"), ("W", "K")) == {("W", "M^t"): 1}
    assert not reduce(left, ("G_ret", "K"), ("K", "W"), drop_contact=True)
    assert not reduce(right, ("K", "G_adv"), ("W", "K"), drop_contact=True)
    return {"left": "M W", "right": "W M^t", "both_off_shell_contacts_required": True}


def cone_control():
    carrier = read(V869 / "result_a.json")["compared"]["twelve_current_homogeneous_carriers"][0]
    values = {(i, j): sp.sympify(value) for i, j, value in carrier}
    c = sp.sqrt(10) / 4
    for i, j in ((4, 8), (509, 510), (554, 555), (599, 600)):
        assert values[i, j] == c and values[j, i] == -c
    # Use T=1 in arbitrary test coordinate units, without fixing a mass.
    T, eps = Fraction(1), Fraction(1, 32)
    assert 5 * eps < T - eps and T > 10 * eps
    min_radius, max_radius = T - 2 * eps, T + 2 * eps
    root_bound = 3 * eps
    assert root_bound < 4 * eps and min_radius > 0
    lower_in_pi_units = 1 / (4 * max_radius)
    assert lower_in_pi_units == Fraction(4, 17)
    w = sp.Symbol("eta_H")
    defect = c * w / 2
    omit_dipole = sp.expand(defect - c / 2)
    assert omit_dipole != 0 and omit_dipole.subs(w, 1) == 0
    return {"carrier": str(c), "null_time_root_absolute_bound": str(root_bound), "past_retarded_zero": True,
            "strict_positive_dE2_lower_in_1_over_pi_units": str(lower_in_pi_units),
            "ordered_ghost_cone_signs": [1, -1], "fixed_W_defect_factor_without_g": str(defect),
            "compensation_factor_without_g": str(-defect), "omitted_dipole_difference": str(omit_dipole)}


def main():
    started = time.perf_counter()
    watch = threading.Timer(120, lambda: os._exit(124))
    watch.daemon = True
    watch.start()
    for name, expected in read(HERE / "preparation_b.json")["sha256"].items():
        assert sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    phase_a = read(HERE / "result_a.json")
    assert phase_a["execution_state"] == "COMPLETED" and all(not row["residual"] for row in phase_a["roles"])
    block, endpoints = block_controls(), endpoint_control()
    print("STAGE actual mixed and ghost off-shell and shell orders checked", flush=True)
    cone = cone_control()
    print("STAGE strict null cone pairing and width control checked", flush=True)
    result = {"execution_state": "COMPLETED", "scientific_acceptance": "NOT_PERFORMED", "blocks": block,
              "endpoints": endpoints, "cone": cone, "seconds": time.perf_counter() - started}
    data = (json.dumps(result, sort_keys=True) + "\n").encode()
    name = "result_b.json" if len(data) <= 8 * 1024**2 else "result_b.COMPLETE_OVERFLOW_NOTPASS"
    with (HERE / name).open("xb") as stream:
        stream.write(data)
    assert name == "result_b.json"
    watch.cancel()


if __name__ == "__main__":
    main()
