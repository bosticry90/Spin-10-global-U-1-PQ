# V873 connected mixed gauge and ghost background bridge

Continue V872 on main, D:, under AGENTS. Keep the actual unprobed V869
compact parent and the free FCR1/CWB1 branch. Use one first-g light
background parameter supported in the shared sigma=1 plateau, and
one quadratic insertion at the flat mean/source/background point.
Take the ordinary Hessian before evaluating at that point. Preserve
the opposite R_A contribution and switch currents in the parent.

Phase A compares the complete non-scalar affine Hessian from the
physical S1_gauge and full GF/source g1 packets with the ordered V869
parameter-jet reference. Use literal active B and A replacements
and the ordinary LEFT Euler, including the odd sign when removing
the second odd port. Check the cross-scalar complement and retain
the scalar result from V872. Preserve the complete residual on a
mismatch. A wrong odd transpose must change a nonzero block.

Freeze sources and owners before execution. Root owns writes. The
worker has 120 seconds, 8 GiB sampled private allocation, a 350 MiB
launch floor, 8 MiB artifact and 32 MiB packet. Keep exact captures.
Phase A is an operator comparison pending the causal phase and final
review.

Phase B will use the graded transpose and off-shell delta on the actual
gauge/auxiliary, ghost and dual endpoints. Retain the width-dependent
dipole, both mixed orientations and both ghost orders. Use a nonblind
cone or null-related control for the massless kernels. The pure-gauge
tangent does not give a derivation of the fixed star product or a general
interacting or background state. Connected W5, nonlinear Ward products,
full E5/A5 and physical viability remain open.
