# V873 separate final review

Freeze phase A, both phase B runs, the final sources, owner receipts
and navigation. The final worker has 180 seconds, 8 GiB sampled private
allocation and a 350 MiB launch floor. The E4 subprocess has 120 seconds.
Retain the 32 MiB packet limit.

Independently compare the full non-scalar reference positions, graded
odd counts, ordered inverse and bisolution signs, and the null-support
bound and width residual. Verify the limited exact-algebra repair to
the original failed worker. Review the parity proof, dipole and both
causal endpoints against the actual owners.

Require E4 exit 0 with steps 0,0,0,0,0,2 and exactly seven unresolved
custody references. Preserve the historical README suffix and unchanged
project_state.json. Completion permits a scoped local evidence commit,
with no protected promotion.
