# Graded connected W4 compensation on the compact massless bridge

Use the actual V869 unprobed compact parent at the flat mean, source
and background point after ordinary variation. The one light parameter
and all its jets have support inside the common sigma=1 region. Phase A
compares the complete physical gauge and full GF/source affine Hessian
to the non-scalar reference variation. It retains both B and A affine
replacements, the actual LEFT ordinary Euler, and the cross-scalar
zero complement. In the compact parent the reference variation and
its opposite in the interaction cancel on the parameter support. The
actual physical and GF/source variation supplies the same operator
there. The switch-current terms outside that region are part of the
parent and are not deleted. Together with V872 this covers the full
free-reference block list at this selected insertion and order.

## Graded contraction and dual endpoint

Let K0 be the actual flat operator and M the even homogeneous light
carrier, including g and the compact parameter. Write t for ordinary
formal transpose of operators. The actual first-g Hessian variation
is dK=−M^t K0−K0 M. The parity matrix s=diag((-1)^p) commutes with these
parity-preserving operators. Thus K0^t=s K0 and dK^t=s dK. The analogous
Green relations are G_ret^t=s G_adv and G_adv^t=s G_ret. These are
operator statements on the original evaluation pairing, including the
sign of the odd block. The graded flip of a contraction tensor is
the ordinary kernel transpose with the extra sign s on its paired
odd block. It is not used as an ordinary transpose of a product of
operators.

Use one quadratic insertion V with left ordinary Euler dK z. The
relative COS1 first coefficient on a linear field is
(i/hbar)(T2(V,z)−V star z). The first slot uses the right derivative of
the even V, which differs from its left derivative by s. In that
action-to-field order the CWB identity is C_F−W=i G_adv. The ordinary
kernel transpose turns the advanced contraction into s G_ret, so the
two parity signs cancel. The retarded field map has variation
−G_ret dK z on all the blocks. Its ordinary dual is −dK G_adv,
since dK^t G_ret^t=(s dK)(s G_adv). On an arbitrary off-shell field
the map still contains G_ret M^t K0 z in addition to Mz.

The two contractions give dW=−G_ret dK W−W dK G_adv. On independent
compact endpoint tests apply the advanced inverse to the first test
in the weak left term and multiply by the compact dK. This gives a
compact smooth argument for W. The other weak term is defined the
same way on the opposite endpoint. Both K0 G=G K0=1 and K0 W=W K0=0
apply in their respective orders by FCR1 and CWB1. Hence

    −G_ret dK W = M W,     −W dK G_adv = W M^t.

The corresponding fixed-W contraction defect is their negative.
In the actual mixed block, cancellation uses the retarded or advanced
dipole through Box D4=D2 and the shell dipole through P delta'(P)=−delta(P).
The separate exact controls verify both inverse and homogeneous
orders and the failure of omitting either dipole. The two ghost orders
are opposites. The odd right/left signs cancel only if the tensor
flip is included. This does not give a derivation of the fixed star
product or identify an arbitrary-background Feynman state.

## Nonzero cone control in the actual switch current

Use light colors 1 and 2 with nu_0. Their common carrier has the
nonzero entry c=sqrt(10)/4 in the vector, auxiliary, C and a blocks,
and the opposite reverse entry. The literal Minkowski mixed quadratic
term differs from its Euler-normal reference by −div(Lambda B)/2.
The past switch difference v therefore gives +(partial_mu v) Lambda
B^mu/2. Keep the past output Lambda_2 constant on a neighborhood of
supp v and set the uncontracted past B to zero for this projection.
The Maxwell current has no Lambda output there. The relative
coefficient with one past vertex and no other interaction vertices
pairs this vertex with the local B^0. For fixed W the local variation
of B^0_1 gives c times B^0_2, whereas the coordinate variation of the
past output is zero. With E2=D2_ret−D2_adv and E4=D4_ret−D4_adv, the
complete vector contraction has divergence

    partial_mu Delta_BB^{mu0} = partial^0 E2 + (w−1) partial^0 Box E4
                              = w partial_0 E2.

Integrating the switch derivative by parts gives the pairing
−w/2 against v Lambda_2 and partial_0 E2. With the local rotation the
fixed-reference relative defect has the opposite factor +g c w/2.
The transported right endpoint supplies the compensating negative
factor. Width w is the symbolic light eta_H. Omitting the dipole
changes w to 1, so the difference is detectable at generic width.
At w=1 this control is insensitive to the missing term, and at w=0
the full particular pairing is zero. Neither width is chosen here.

For a compact signed cone pairing take the past spatial support in
the epsilon ball around zero. Take the local support near (T,T e1)
with time radius epsilon and spatial radius epsilon, where T>10 epsilon.
For every pair of spatial points and local time on these supports,
the past null time y0−R, R=|y−x|, lies in |x0|<3 epsilon.
Take a nonnegative compact past temporal profile
(6 epsilon+t) chi(t), with chi=1 for |t|<=4 epsilon and zero for
|t|>=5 epsilon. Its derivative is one at all null roots, and all
past times precede the local times. Use nonnegative spatial past
test and local f nu_0 with unit integrals. The advanced cone measure
has weight 1/(4 pi R), and the retarded kernel vanishes in that
order. The pairing of partial_0 E2 with the past/local tests is
positive, bounded below by 1/[4 pi (T+2 epsilon)]. This follows
by moving the derivative to the past test and applying the FCR1
cone measure. No value of a delta is assigned at a point. The
ordered ghost differences have opposite signs on the same cone.
The local off-shell Box G contacts check those signs separately,
since those contacts alone cannot select causal support.

This is a finite compact W4 compensation at the chosen quadratic
insertion. It extends the scalar case without adding a ghost metric
or imposing a fixed-star derivation. It leaves connected W5 at fixed
A, more general nonlinear products, interacting states and E5/A5
separate. The calculations share the action, reference conventions,
analytic premises, software and AI authorship.
