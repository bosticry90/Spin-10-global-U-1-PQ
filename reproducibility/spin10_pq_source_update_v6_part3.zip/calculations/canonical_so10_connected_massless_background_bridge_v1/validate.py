"""Independent V873 evidence checks and the local E4 sequence."""

from fractions import Fraction
from hashlib import sha256
import json
import os
import subprocess
import sys
import threading
import time

import sympy as sp

from execute_a import CONTROL, HERE, ROOT, git, save
from massless import V869, ordinary_scalar, read


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def independent_checks(a, b):
    rows = [row for row in read(V869 / "result_b.json")["complete_parameter_jet_identity"]
            if not any(ordinary_scalar(n) for n in row[3:5])]
    assert rows == a["complete_reference_massless_euler"] and len(rows) == 34104
    odd = [row for row in rows if row[3] >= 553 and row[4] >= 553]
    assert len(odd) == 6496
    assert all((row[3] >= 553) == (row[4] >= 553) for row in rows)
    for route in a["roles"]:
        assert not route["residual"] and route["actual_positions"] == len(rows)
        assert route["affine_slot_counts"] == {"even": 16240, "odd": 3248}
        assert route["wrong_left_odd_sign_residual_count"] * 2 == len(odd)
    block = b["blocks"]
    l, r = (sp.sympify(block[name]) for name in ("mixed_omitted_dipole_left", "mixed_omitted_dipole_right"))
    assert l and sp.cancel(l + r) == 0
    assert block["ordered_ghost_Box_contact"] == [-1, 1]
    assert block["parity_factors"] == [[0, 1, 1, 1], [1, -1, -1, 1]]
    assert block["advanced_simple_and_double_shell_signs"] == [[-1, 1, -1], [1, -1, 1]]
    cone = b["cone"]
    eps = Fraction(cone["null_time_root_absolute_bound"]) / 3
    lower = Fraction(cone["strict_positive_dE2_lower_in_1_over_pi_units"])
    assert eps == Fraction(1, 32) and lower == 1 / (4 * (1 + 2 * eps)) == Fraction(4, 17)
    assert cone["past_retarded_zero"] and cone["ordered_ghost_cone_signs"] == [1, -1]
    w = sp.Symbol("eta_H")
    c = sp.sympify(cone["carrier"])
    defect = sp.sympify(cone["fixed_W_defect_factor_without_g"])
    assert c == sp.sqrt(10) / 4 and defect == c * w / 2
    assert sp.sympify(cone["compensation_factor_without_g"]) == -defect
    assert sp.simplify(sp.sympify(cone["omitted_dipole_difference"]) - c * (w - 1) / 2) == 0
    assert b["endpoints"] == {"left": "M W", "right": "W M^t", "both_off_shell_contacts_required": True}
    return {"massless_positions": len(rows), "ordered_odd_positions": len(odd), "cone_lower_in_1_over_pi_units": str(lower),
            "width_dipole_residual": str(sp.factor(l))}


def main():
    started = time.perf_counter()
    watch = threading.Timer(180, lambda: os._exit(124))
    watch.daemon = True
    watch.start()
    prep = read(HERE / "preparation_validation.json")
    assert prep["base_HEAD"] == git("rev-parse", "HEAD").decode().strip()
    assert git("ls-tree", "-r", "HEAD") == (CONTROL / "old_git_tree.txt").read_bytes()
    assert not git("diff", "--cached", "--name-only")
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    for phase, expected in (("a", True), ("b", False), ("b_v2", True)):
        for prefix in ("preparation", "capture"):
            name = f"{prefix}_{phase}.json"
            assert (HERE / name).read_bytes() == (CONTROL / name).read_bytes()
        capture = read(HERE / f"capture_{phase}.json")
        assert capture["calculation_completed"] == expected and capture["post_run_observations_qualified"]
        if not expected:
            assert "ghost_k * ghost_g == ghost_g * ghost_k" in capture["stdout_and_stderr"]
    for source in HERE.glob("*.source.txt"):
        assert source.read_bytes() == (HERE / source.name.removesuffix(".source.txt")).read_bytes()
    for name in prep["owner_receipts"]:
        assert read(ROOT / name)["execution_state"] == "COMPLETED", name

    a, b = read(HERE / "result_a.json"), read(HERE / "result_b_v2.json")
    assert a["execution_state"] == b["execution_state"] == "COMPLETED"
    checks = independent_checks(a, b)
    print("STAGE graded signs, cone support and width dependence independently checked", flush=True)

    e4 = subprocess.run([sys.executable, "-B", "tools/research_check.py", "e4", "--historical-context",
                         "D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4"],
                        cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=120)
    save("e4_capture.json", {"exit_code": e4.returncode, "stdout": e4.stdout, "stderr": e4.stderr})
    events = [json.loads(line) for line in e4.stdout.splitlines() if line.strip()]
    steps = [event for event in events if event.get("event") == "step_finished"]
    exits = [event["exit_code"] for event in steps]
    assert e4.returncode == 0 and exits == [0, 0, 0, 0, 0, 2]
    custody = next(event for event in steps if event["step"] == "historical_custody")
    assert custody["stdout"].count("RECORDED_DIGEST_UNRESOLVED:") == 7
    historic = git("show", "ef70f255a667b9a81e37b344dc78967ada4ed896:README.md")
    assert sha256(historic).hexdigest() == "4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792"
    assert (ROOT / "README.md").read_bytes().replace(b"\r\n", b"\n").endswith(historic)
    assert digest(ROOT / "project_state.json") == "d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8"
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    paths = [path for path in HERE.iterdir() if path.is_file()]
    assert sum(path.stat().st_size for path in paths) <= 32 * 1024**2
    paths.extend(ROOT / name for name in prep["navigation"])
    save("validation_receipt.json", {
        "execution_state": "COMPLETED", "evidence_validation": "PASS_COMPACT_CONNECTED_MASSLESS_BACKGROUND_TANGENT",
        "scientific_acceptance": "NOT_PERFORMED", "base_HEAD": prep["base_HEAD"],
        "state_sha256": digest(ROOT / "project_state.json"), "owner_receipts": prep["owner_receipts"],
        "independent_checks": checks, "E4_step_exits": exits, "historical_custody": "SEVEN_UNRESOLVED_NOTPASS",
        "files_excluding_pending_receipt_capture": {path.relative_to(ROOT).as_posix(): digest(path) for path in paths},
        "elapsed_after_imports": time.perf_counter() - started,
    })
    watch.cancel()


if __name__ == "__main__":
    main()
