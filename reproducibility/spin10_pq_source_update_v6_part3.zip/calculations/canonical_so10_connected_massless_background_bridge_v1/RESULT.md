# V873 connected massless background tangent

Use with the completed final receipt and capture. Both physical routes
match all 34,104 non-scalar parameter-jet positions to the covariant
reference. They include 6,496 ordered odd positions. Dropping the LEFT
sign on the second odd port changes 3,248 of them. The cross-scalar
complement is zero. The unprobed compact parent retains the opposite
reference vertex and the switch currents.

The odd right/left derivative sign and the tensor flip cancel in the
retarded relative field coefficient. The ordinary operator dual gives
the advanced right endpoint. Both off-shell inverse orders and both
Wightman bisolution orders pass with the mixed dipole and the original
ghost order. The transported endpoints cancel the fixed-reference
contraction defect at this first-g quadratic insertion. The off-shell
field map still contains its K0 term.

The actual past mixed gauge/auxiliary current gives a nonzero signed
null-cone test. It retains the light-width factor eta_H, which becomes
1 if the dipole is omitted. The two ghost orders give opposite cone
and local-contact signs. The support and contact tests are distinct.
The first ghost verification stopped on unsimplified rational forms.
Exact cancellation in both orders gives identity. The corrected run
keeps the same signs and tests, and the failure remains recorded.

[Proof](PROOF.md) and [final review](FINAL_RECORD.md). With V872 this
covers the full reference block list at one compact first-g quadratic
background insertion. It does not give general interacting W4, a
fixed-star derivation or a new state. Next test connected W5 at fixed
A using the whole C(P) insertion and the ordinary-source lift of the
affine geometric action. No new loop integral, full E5/A5 or physical
viability result. The calculations share action, reference, analytic
premises, software and AI authorship. Authority 34/39 and seven
unresolved historical custody references retain their status.
