"""Check the exact raw/sharp source transport on actual V848 inputs."""

import gzip
import importlib.util
import json
import sys
from pathlib import Path


HERE = Path(__file__).resolve().parent
CALC = HERE.parents[1] / "calculations"
V848 = CALC / "canonical_so10_augmented_metric_lift_v1"
V865 = CALC / "canonical_so10_joint_common_family_applicability_v1"
V875 = CALC / "canonical_so10_connected_compact_master_v1"
SIZE = 643
METRIC = (1, -1, -1, -1)


def read(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == ".gz" else raw)


def raw(name):
    return read(V848 / name)["input_polynomial_Minkowski"]


def literal(row_map, word, key=(0, 0, 0, 0)):
    return row_map[(tuple((i, tuple(jets)) for i, jets in word), key)]


def indexed(rows):
    return {(tuple((i, tuple(j)) for i, j in word), tuple(key)): n
            for word, cells in rows for key, n, d in cells if d == 1}


def adapt(rows, signs):
    out = []
    for word, cells in rows:
        parity = sum(signs[i - SIZE] == -1 for i, _ in word if SIZE <= i < 2 * SIZE)
        out.append([word, [[key, (-1)**parity * n, d] for key, n, d in cells]])
    return out


def wick_phases(own):
    spec = importlib.util.spec_from_file_location("v848_metric_algebra", V848 / "algebra.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    parity = own["joined_parities"]
    signs = [(-1)**parity[i] for i in range(SIZE)]
    pairs = []
    for i, s in enumerate(signs):
        assert parity[i] + parity[i + SIZE] == 1
        assert module.par(i) == parity[i] and module.par(i + SIZE) == parity[i + SIZE]
        left, right = module.phase(i), module.phase(i + SIZE)
        assert (left + right) % 4 == (2 if s == 1 else 0)
        pairs.append([i, left, right, s])
    assert signs.count(1) == 553 and signs.count(-1) == 90
    return signs, pairs


def tree(base, probe, bracket):
    b = literal(base, ((508, ()), (1241, ())))
    c = literal(probe, ((0, (0,)), (1241, ())))
    d = literal(probe, ((1241, ()), (1241, ())))
    # Both ordered L G e_Lambda and e_Lambda^t G L^t are -1 in V875/FCR.
    L_phi0, lambda_phi1 = b, c
    schur = [2 * d, 2 * b * c]
    beta = [2 * bracket * d, bracket * (c * L_phi0 + b * lambda_phi1)]
    return {"linear_base": b, "linear_probe": c, "W_JJ": schur, "beta_Jj": beta}


def checks(role):
    own = read(V865 / f"{role}_complete_full_background_extension.json.gz")
    signs, pairs = wick_phases(own)
    base = raw("tensor_7.json.gz" if role == "native" else "tensor_6.json.gz")
    u = raw("tensor_2.json.gz")
    K = raw("tensor_0.json.gz")
    for rows in (base, u, K):
        assert adapt(adapt(rows, signs), signs) == rows
    r, r_u, r_K = map(indexed, (base, u, K))
    s, s_u, s_K = (indexed(adapt(rows, signs)) for rows in (base, u, K))
    raw_tree, sharp_tree = tree(r, r_u, 1), tree(s, s_u, signs[598])
    assert raw_tree == {"linear_base": -1, "linear_probe": 2, "W_JJ": [2, -4], "beta_Jj": [2, -4]}
    assert sharp_tree == {"linear_base": 1, "linear_probe": -2, "W_JJ": [2, -4], "beta_Jj": [-2, 4]}
    old = read(V875 / "result_v3.json")["checks"]["tree"]
    assert sharp_tree["W_JJ"] == old["W_JJ_switch_grades"] and sharp_tree["beta_Jj"] == old["beta_J_j_switch_grades"]

    # C precedes odd J_B, so LEFT differentiation changes the row's sign.
    FB = [-literal(r, ((553, (mu,)), (SIZE + mu, ()))) for mu in range(4)]
    EB = [-literal(r, ((mu, (mu,)), (508, ()))) for mu in range(4)]
    assert FB == [1] * 4 and EB == list(METRIC)
    gh = [row for row in own["complete_S_GF_source"] if row[0] == 0 and any(i == 598 for i, _ in row[1])]
    assert gh == [[0, [[553, [mu]], [598, [mu]]], [[[0, 0, 0], -1, 1]]] for mu in range(4)]
    # Wick density minus and two time jets give the Minkowski -eta row.
    # Odd LEFT prefix and Euler adjoint each contribute -1 to E_a.
    Ea = [row[2][0][1] * (-1 if mu == 0 else 1) * -1 for mu, row in enumerate(gh)]
    assert Ea == [-value for value in METRIC]
    b_leg = [-f * e for f, e in zip(FB, EB)]
    a_leg = [raw_tree["linear_base"] * e for e in Ea]
    sharp_leg = [signs[598] * sharp_tree["linear_base"] * e for e in Ea]
    mixed_leg = [signs[598] * raw_tree["linear_base"] * e for e in Ea]
    assert a_leg == sharp_leg == list(METRIC)
    residual = [b + a for b, a in zip(b_leg, mixed_leg)]
    assert [b + a for b, a in zip(b_leg, a_leg)] == [0] * 4
    assert residual == [-2 * value for value in METRIC]

    source = ((1253, ()), (1286, ()))
    rk, sk = literal(r_K, source), literal(s_K, source)
    marked = [-signs[610] * rk, -sk, -rk]
    assert (rk, sk) == (1, -1) and marked == [1, 1, -1]
    return {"phase_pairs": pairs, "raw": raw_tree, "sharp": sharp_tree,
            "uncut_correct_each_chart": 0, "uncut_mixed_chart_Box_coefficient": -2,
            "uncut_mixed_chart_component_coefficients": residual,
            "marked_Da_raw_sharp_mixed": marked}


if __name__ == "__main__":
    from execute import run_worker

    run_worker(checks, sys.argv[1])
