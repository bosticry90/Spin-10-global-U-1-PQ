# V876 connected master source-chart qualification

Start from V875 `aabec3c4` on main, D:. Preserve its committed evidence.
The marked follow-up exposed a suspected mixing of the raw V848
Minkowski source coordinates and the signed current master bracket.
Determine the precise transport and repeat the affected actual V875
controls before extending the marked identity. V875's formal signed
Legendre calculation, V871 source Hessian and V874 even Ward equation
have separate dependencies.

Use two descriptions of one compact functional, with fixed full A,
first g and first H or M u and one constant LEFT odd beta strength.
Compactness is supplied by B[P] after literal switching. Check the
643 actual phase products and complementary source parities. Compare
raw unsigned and explicitly adapted signed roots in the g0 H source
and ghost control. Test the uncut Lambda Box C slot, where the mixed
chart must fail, and the actual marked source adapter before any new
marked calculation. No restoration is inferred from an uncut projection.

Freeze the original and replay data, proof, current policy and sources.
Worker and final review limits are 120 and 180 seconds, 8 GiB sampled
private allocation, 350 MiB launch floor, 8 MiB result and 32 MiB packet.
The final E4 subprocess retains 120 seconds and the historical-context
contract, including seven unresolved custody references. Evidence can
requalify the actual selected V875 bridge in the correct charts. Keep
all original records, state, formal authority and protected gates.
