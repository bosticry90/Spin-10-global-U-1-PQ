"""Freeze, run, and independently review the V876 chart correction."""

import ast
import json
import os
import subprocess
import sys
import threading
import time
from hashlib import sha256
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CONTROL = Path("D:/Codex-Research/ToE-Next/research-control-records/connected-master-source-chart-v1-2026-11-08")
PK = ROOT / "tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1"
BASE = "aabec3c4dc0f79107c3aee3198c6a65e84d50c06"
NAV = ["README.md", "docs/COMMON_RESTORATION_CAMPAIGN_V1.md", "docs/RESEARCH_EXECUTION_HANDOFF_V876.md"]


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def digest(p):
    return sha256(p.read_bytes()).hexdigest()


def read(p):
    return json.loads(p.read_bytes())


def save(name, payload):
    data = (json.dumps(payload, sort_keys=True) + "\n").encode()
    for directory in (HERE, CONTROL):
        with (directory / name).open("xb") as f:
            f.write(data)
    return len(data)


def bind(names, phase):
    if phase == "native":
        CONTROL.mkdir(exist_ok=False)
        with (CONTROL / "old_git_tree.txt").open("xb") as f:
            f.write(git("ls-tree", "-r", "HEAD"))
        snapshots = ("RECORD.md", "PROOF.md", "chart.py", "execute.py")
    else:
        snapshots = ("RESULT.md",)
    for name in snapshots:
        data = (HERE / name).read_bytes()
        if name.endswith(".py"):
            ast.parse(data)
        with (HERE / (name + ".source.txt")).open("xb") as f:
            f.write(data)
    names.update(path.relative_to(ROOT).as_posix() for path in HERE.iterdir() if path.is_file())
    save(f"preparation_{phase}.json", {
        "base_HEAD": BASE, "sha256": {name: digest(ROOT / name) for name in sorted(names)},
        "scientific_acceptance": "NOT_PERFORMED",
        "limits": {"seconds": 120 if phase == "native" else 180, "e4_seconds": 120,
                   "sampled_private_bytes": 8 * 1024**3, "minimum_available_commit_bytes": 350 * 1024**2,
                   "artifact_bytes": 8 * 1024**2, "packet_bytes": 32 * 1024**2},
    })


def prepare(phase):
    assert git("rev-parse", "HEAD").decode().strip() == BASE
    assert not git("diff", "--cached", "--name-only")
    if phase == "native":
        assert not git("diff", "--name-only", "HEAD")
        owners = {
            "augmented_metric_lift_v1": ("algebra.py", "PROOF.md", "validation_receipt.json", "tensor_0.json.gz", "tensor_2.json.gz", "tensor_6.json.gz", "tensor_7.json.gz"),
            "joint_common_family_applicability_v1": ("validation_receipt.json", "native_complete_full_background_extension.json.gz", "replay_complete_full_background_extension.json.gz"),
            "current_causal_initial_dictionary_v1": ("PROOF.md", "validation_receipt.json"),
            "compact_switched_master_domain_v1": ("PROOF.md", "validation_receipt.json"),
            "current_background_reference_bridge_v1": ("PROOF.md", "validation_receipt.json"),
            "compact_retained_source_functional_v1": ("PROOF.md", "validation_receipt.json"),
            "connected_fixed_background_ward_v1": ("validation_receipt.json",),
            "connected_compact_master_v1": ("PROOF.md", "master_v3.py", "result_v3.json", "validation_receipt.json"),
            "free_causal_reference": ("DERIVATION.md", "validation_receipt_v3.json"),
        }
        names = {"AGENTS.md", "CHARTER.md", "project_state.json", "docs/RESEARCH_EXECUTION_HANDOFF_V875.md"}
        names.update((PK / name).relative_to(ROOT).as_posix() for name in ("A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md", "export_a10_e5_antighost_vector.py"))
        for owner, paths in owners.items():
            names.update(f"calculations/canonical_so10_{owner}/{path}" for path in paths)
    else:
        assert phase == "validation"
        assert set(git("diff", "--name-only", "HEAD").decode().splitlines()) == set(NAV[:2])
        for name, backup in zip(NAV[:2], ("README_before_final.bytes", "campaign_before_final.bytes")):
            assert (CONTROL / backup).read_bytes().replace(b"\r\n", b"\n") == git("show", "HEAD:" + name)
        first = read(HERE / "preparation_native.json")
        for name, expected in first["sha256"].items():
            assert digest(ROOT / name) == expected, name
        names = set(first["sha256"]) | set(NAV) | {"docs/LOCAL_RESEARCH_CONVENTIONS_V1.md"}
    bind(names, phase)


def run_worker(check, phase):
    started = time.perf_counter()
    prep = read(HERE / f"preparation_{phase}.json")
    timer = threading.Timer(prep["limits"]["seconds"], lambda: os._exit(124))
    timer.daemon = True
    timer.start()
    assert git("rev-parse", "HEAD").decode().strip() == BASE == prep["base_HEAD"]
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    if phase == "native":
        result = {"execution_state": "COMPLETED", "checks": check("native")}
        size = len((json.dumps(result, sort_keys=True) + "\n").encode())
        assert save("result.json" if size <= 8 * 1024**2 else "result.COMPLETE_OVERFLOW_NOTPASS", result) == size
        assert size <= 8 * 1024**2
        print("STAGE all phase products and actual raw/sharp controls checked", flush=True)
    else:
        review(check, prep, started)
    timer.cancel()


def review(check, prep, started):
    assert not git("diff", "--cached", "--name-only")
    assert git("ls-tree", "-r", "HEAD") == (CONTROL / "old_git_tree.txt").read_bytes()
    for name in ("preparation_native.json", "capture_native.json", "result.json"):
        assert (HERE / name).read_bytes() == (CONTROL / name).read_bytes()
    capture = read(HERE / "capture_native.json")
    assert capture["calculation_completed"] and capture["post_run_observations_qualified"]
    for source in HERE.glob("*.source.txt"):
        assert source.read_bytes() == (HERE / source.name.removesuffix(".source.txt")).read_bytes()
    receipts = sorted(n for n in prep["sha256"] if "validation_receipt" in n and n.endswith(".json"))
    assert all(read(ROOT / name)["execution_state"] == "COMPLETED" for name in receipts)
    a = read(HERE / "result.json")["checks"]
    assert a == check("replay") and len(a["phase_pairs"]) == 643
    assert a["raw"]["beta_Jj"] == [-n for n in a["sharp"]["beta_Jj"]]
    assert a["uncut_mixed_chart_Box_coefficient"] == -2 and a["marked_Da_raw_sharp_mixed"] == [1, 1, -1]
    print("STAGE replay rows and nonblind chart controls agree", flush=True)

    e4 = subprocess.run([sys.executable, "-B", "tools/research_check.py", "e4", "--historical-context",
                         "D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4"], cwd=ROOT,
                        capture_output=True, text=True, encoding="utf-8", timeout=120)
    save("e4_capture.json", {"exit_code": e4.returncode, "stdout": e4.stdout, "stderr": e4.stderr})
    events = [json.loads(line) for line in e4.stdout.splitlines() if line.strip()]
    steps = [event for event in events if event.get("event") == "step_finished"]
    exits = [event["exit_code"] for event in steps]
    assert e4.returncode == 0 and exits == [0, 0, 0, 0, 0, 2]
    custody = next(event for event in steps if event["step"] == "historical_custody")
    assert custody["stdout"].count("RECORDED_DIGEST_UNRESOLVED:") == 7
    hist = git("show", "ef70f255a667b9a81e37b344dc78967ada4ed896:README.md")
    assert sha256(hist).hexdigest() == "4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792"
    assert (ROOT / "README.md").read_bytes().replace(b"\r\n", b"\n").endswith(hist)
    state = digest(ROOT / "project_state.json")
    assert state == "d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8"
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    files = [path for path in HERE.iterdir() if path.is_file()] + [ROOT / name for name in NAV]
    save("validation_receipt.json", {"base_HEAD": BASE, "execution_state": "COMPLETED",
         "evidence_validation": "PASS_SELECTED_W3_SOURCE_CHART_REPAIR",
         "scientific_acceptance": "NOT_PERFORMED", "state_sha256": state, "E4_step_exits": exits,
         "historical_custody": "SEVEN_UNRESOLVED_NOTPASS", "owner_receipts": receipts,
         "actual_phase_positions": len(a["phase_pairs"]), "uncut_mixed_chart_residual": -2,
         "raw_tree": a["raw"], "sharp_tree": a["sharp"],
         "files_excluding_pending_receipt_capture": {p.relative_to(ROOT).as_posix(): digest(p) for p in files},
         "elapsed_after_imports": time.perf_counter() - started})


def main():
    phase = sys.argv[1]
    prepare(phase)
    sys.path.insert(0, str(PK))
    from export_a10_e5_antighost_vector import capture

    report = capture([sys.executable, "-B", str(HERE / "chart.py"), phase])
    save(f"capture_{phase}.json", report)
    print(report["stdout_and_stderr"], end="")
    assert report["calculation_completed"] and report["post_run_observations_qualified"]
    assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file()) <= 32 * 1024**2


if __name__ == "__main__":
    main()
