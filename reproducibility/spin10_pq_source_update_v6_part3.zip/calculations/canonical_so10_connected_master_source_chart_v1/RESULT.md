# V876 actual source-chart repair for the selected connected master

The raw V848 Minkowski master is unsigned in the field/source Euler
pair. The corresponding connected source operator is
−integral sum_i s_i j_i EL_JM W. With J_M=s_i Jsharp, the common
functional instead uses the signed master and the V875 formal
connected operator −integral sum_i j_i EL_Jsharp W. Adapt every
retained-source operand, including the marked primitive.

All 643 actual phase products obey w_z w_J=−s_i. The actual g0 H
beta-root Jj coefficients are +2 chi and −4 chi² raw, and −2 chi
and +4 chi² after the adapter. The two-source Hessian is unchanged.
The uncut Lambda Box C coefficient vanishes in both consistent
charts and is −2 in the mixed chart. The marked antighost shift
agrees between the consistent charts and reverses in the mixed one.

This replaces V875's actual mixed-chart operand check. Preserve that
calculation and its failure history. V875's formal signed Legendre
proof and odd mean and ghost-contact fixtures retain their scope.
See [PROOF.md](PROOF.md) and the separate validation receipt and capture.
The result requalifies the selected absolute compact W3 bridge under
the original one-loop assumptions. No protected promotion or new loop.
