# Raw and signed source charts for the compact connected master

V875's stationary Legendre cancellation is correct in its signed
current chart. Its actual tree fixture paired the signed bracket with
the unadapted V848 Minkowski source rows. In the odd antighost slot the
two independent source derivatives are invariant under the source sign
change. The fixture therefore obtained the signed-chart output numbers
without testing the actual transport of its linear operands. Its claim
of an actual signed-Minkowski comparison needs the correction below.
Preserve the complete V875 packet and classify that operand comparison
as a mixed-chart diagnostic. The formal identity, V871 source-square
check and V874 affine geometric identity have separate dependencies.

## Derive the adapter from the actual Wick phases

Let s_i=(-1)^p_i. In V848's literal density convention the current
Euclidean action is minus the Wick substitution of its raw Minkowski
expression. Write z_M=w_z z_E and J_M=w_J J_E for the constant slot
phases, with the inherited derivative transport. Thus the LEFT Eulers
have the respective factors −w_z and −w_J, after transporting the
derivatives and taking the same local adjoints. The two Euler factors
in B_E multiply to s_i w_z w_J. The actual phases give w_z w_J=−s_i
in every one of the 643 field/source pairs. Both even and odd orders
are retained. It follows that B_E is the density-minus transport of
the raw UNSIGNED Minkowski master sum EL_JM P_M EL_zM P_M.

Define a signed Minkowski coordinate Jsharp by J_M=s_i Jsharp.
Pull back every source-bearing operand once, including P, K, B,
correction and contact coefficients. Since EL_Jsharp=s_i EL_JM,
the signed master in the sharp chart is exactly the raw master pulled
back. This is the constant external evaluation sign underlying V867's
adapter, with the raw and sharp labels specified here independently
of the historical source names. No ordinary field, inverse, regulator,
contact normalization, or density coefficient is chosen for cancellation.
Beta is an odd constant bookkeeping strength. The action direction
beta B[P] is compact because B[P] is built from the switched parent.

In either chart the ordinary source-first stationary condition is
EL_phi Gamma=−s_i j_i, and the retained source Legendre derivative is
EL_J W=EL_J Gamma on the full formal mean. The connected raw master
operator is −integral sum_i s_i j_i EL_JM W. The sharp operator is
−integral sum_i j_i EL_Jsharp W. Pulling back one gives the other.
The odd beta stationary cancellation and the signed rooted mean of
V875 apply to both. Transport the same V868/V869 proper breaking,
V871 absolute graph functional and common conversion in each chart.
The constant sign changes commute with compact switches, local
derivatives and graph sewing. This proves the two versions of the
selected compact connected W3 relation with their own source charts.

## Actual sign-sensitive controls

For light color zero in the raw Minkowski input, the base cross is
−Lambda J and the H probe includes +2 Lz J and +J². In sharp coordinates
the crosses are +Lambda Jsharp and −2 Lz Jsharp. The square and the
two ordered reference contacts are unchanged. The raw central and
mixed W_JJ coefficients are +2 chi and −4 chi², also the sharp values.
The raw beta root in ordered J_M j_a is +2 chi and −4 chi² since the
ordinary antighost has s_a=−1. The adapted root is −2 chi and +4 chi².
Both keep the same two mixed inverse orientations and the ghost switch
jet from the original V875 contact calculation. Changing a single
source argument matters even where the two-source Hessian is invariant.

The actual raw J_B and J_a Eulers on the uncut unprobed g0 H projection
are partial C and −Lambda. The E_B, E_a mixed entries are partial Lambda
and −Box C. With the Minkowski metric pairing, the integrated J_B leg
gives −Lambda Box C and the J_a leg gives +Lambda Box C. Their sum
vanishes. In the sharp chart the sign of the literal J_a cross changes
and the signed bracket reproduces the same two terms. Using signed
Eulers on the raw source cross instead leaves −2 Lambda Box C.
For C=zeta f and Lambda=Box f with a compact real test having nonzero
Box f, the mixed-chart coefficient is nonzero. This is only an uncut
projection check. It gives no zero for the actual compact B[P].

As an additional marked guard, the actual raw K source coefficient
J_a12 epsilon12 is +1. It becomes −1 after adapting J. Thus
D_a^raw=−s_a EL_JM K and D_a^sharp=−EL_Jsharp K both give +epsilon12
before multiplying by the compact switch. The invalid mixed chart
gives the opposite sign. The subsequent marked connected test must
use one consistent operand chart and carry the classical mean response
as well as the proper direct and covariance insertions.

These checks share the action, prior Wick/causal map, conventions and
AI authorship. They resolve the source-chart defect in the selected
absolute compact W3 bridge. They do not measure a new loop, establish
the raw fixed-t CWT paired domain, or qualify full E5/A5.
