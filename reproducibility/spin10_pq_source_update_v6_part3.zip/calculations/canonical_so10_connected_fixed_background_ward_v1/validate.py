"""Separately review V874 contacts, source histories and historical E4."""

import os
import subprocess
import sys
import threading
import time
from fractions import Fraction

import sympy as sp

from connected import INVERSE, METRIC, read
from execute_a import CONTROL, HERE, ROOT, git, save
from execute_b import digest


def review_controls(a, b):
    assert a["execution_state"] == b["execution_state"] == "COMPLETED"
    base = a["comparison"]["base"]
    probes = a["comparison"]["probes"]
    total = 0
    for packet, sizes in ((base, (48, 1152)), (probes["H"], (480, 8640)), (probes["M"], (0, 0))):
        assert not packet["complete_residual"] and not packet["flat_residual"]
        for key in ("direct_rows_by_grade", "insertion_rows_by_grade"):
            assert tuple(packet[key].get(str(g), 0) for g in (0, 1)) == sizes
        total += sum(sizes)

    inverse = read(INVERSE / "replay_inverse.json.gz")
    green = {(i, j): expr for i, j, expr in inverse["Greference"]}
    q = sp.symbols("q0:4")
    j = (7, -3, 8, 1)
    momenta = (2, -3, 5, 11)
    subs = dict(zip(q, momenta))
    Q = sum(p**2 for p in momenta)
    coupling = sum(p * x for p, x in zip(momenta, j))
    for mu, p in enumerate(momenta):
        assert sp.sympify(green[508, mu]).subs(subs) == Fraction(p, Q)
        assert sp.sympify(green[mu, 508]).subs(subs) == Fraction(-p, Q)
    sample = {**subs, **dict(zip(sp.symbols("j0:4"), j))}
    affine = b["affine"]
    assert affine["mixed_ordered_contact_positions"] == 8 and affine["correct_residual"] == 0
    assert sp.sympify(affine["TP_on_reference_mean_over_omega"]).subs(sample) == -sp.I * coupling
    assert sp.sympify(affine["wrong_orientation_residual_over_omega"]).subs(sample) == 2 * sp.I * coupling
    assert sp.sympify(affine["dropped_mixed_residual_over_omega"]).subs(sample) == sp.I * coupling

    roots = read(METRIC / "replay_complete_geometric_metric_insertions.json.gz")["all_fixed_density_roots"]
    cs = next(root for root in roots if root["name"] == "C_S")
    assert [row for row in cs["complete_Minkowski"] if {i for i, _ in row[0]} == {564, 607, 1296}] == b["ghost"]["actual_Minkowski_density"]
    assert [row for row in cs["complete_Euclidean"] if row[0] == 0 and {i for i, _ in row[1]} == {508, 1286}] == affine["CP_grade0_density"]
    assert b["ghost"]["spectator"] == [607, 562, -1]
    assert b["ghost"]["K0_response_spacelike_value_over_g"] == "-1/(4*pi**2*L**2)"
    assert b["ghost"]["wrong_missing_second_jet_value_over_g"] == "0"
    assert b["mean_chain"] == {"proper": "b*v/(2*k)", "rooted_mean": "-b*v/(2*k)", "sum": 0}
    return {"literal_rows": total, "mixed_contact_positions": 8, "ordered_Minkowski_ghost_rows": 4,
            "nonzero_controls": ["affine_sign", "second_omega_jet", "rooted_mean_chain"]}


def main():
    started = time.perf_counter()
    timer = threading.Timer(180, lambda: os._exit(124))
    timer.daemon = True
    timer.start()
    prep = read(HERE / "preparation_validation.json")
    assert prep["base_HEAD"] == git("rev-parse", "HEAD").decode().strip()
    assert git("ls-tree", "-r", "HEAD") == (CONTROL / "old_git_tree.txt").read_bytes()
    assert not git("diff", "--cached", "--name-only")
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    for phase, passed in (("a", True), ("b_v2", False), ("b_v3", True)):
        for prefix in ("preparation", "capture"):
            name = f"{prefix}_{phase}.json"
            assert (HERE / name).read_bytes() == (CONTROL / name).read_bytes(), name
        cap = read(HERE / f"capture_{phase}.json")
        assert cap["calculation_completed"] == passed and cap["post_run_observations_qualified"]
    assert "sp.integrate" in read(HERE / "capture_b_v2.json")["stdout_and_stderr"]
    assert (HERE / "launch_b_failed.json").read_bytes() == (CONTROL / "launch_b_failed.json").read_bytes()
    assert read(HERE / "launch_b_failed.json")["state"] == "SETUP_FAILED_BEFORE_FREEZE_OR_WORKER"
    assert (HERE / "result_b_v3.json").read_bytes() == (CONTROL / "result_b_v3.json").read_bytes()
    for source in HERE.glob("*.source.txt"):
        assert source.read_bytes() == (HERE / source.name.removesuffix(".source.txt")).read_bytes()
    for name in prep["owner_receipts"]:
        assert read(ROOT / name)["execution_state"] == "COMPLETED", name
    checks = review_controls(read(HERE / "result_a.json"), read(HERE / "result_b_v3.json"))
    print("STAGE owner replay signs and ordered connected controls checked", flush=True)

    e4 = subprocess.run([sys.executable, "-B", "tools/research_check.py", "e4", "--historical-context",
                         "D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4"],
                        cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=120)
    save("e4_capture.json", {"exit_code": e4.returncode, "stdout": e4.stdout, "stderr": e4.stderr})
    steps = [event for event in map(read_line, e4.stdout.splitlines()) if event.get("event") == "step_finished"]
    exits = [event["exit_code"] for event in steps]
    assert e4.returncode == 0 and exits == [0, 0, 0, 0, 0, 2]
    custody = next(event for event in steps if event["step"] == "historical_custody")
    assert custody["stdout"].count("RECORDED_DIGEST_UNRESOLVED:") == 7
    historic = git("show", "ef70f255a667b9a81e37b344dc78967ada4ed896:README.md")
    assert (ROOT / "README.md").read_bytes().replace(b"\r\n", b"\n").endswith(historic)
    assert digest(ROOT / "project_state.json") == "d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8"
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    paths = [path for path in HERE.iterdir() if path.is_file()]
    assert sum(path.stat().st_size for path in paths) <= 32 * 1024**2
    paths.extend(ROOT / name for name in prep["navigation"])
    save("validation_receipt.json", {
        "execution_state": "COMPLETED", "evidence_validation": "PASS_SELECTED_ABSOLUTE_COMPACT_CONNECTED_W5",
        "scientific_acceptance": "NOT_PERFORMED", "base_HEAD": prep["base_HEAD"],
        "state_sha256": digest(ROOT / "project_state.json"), "owner_receipts": prep["owner_receipts"],
        "independent_checks": checks, "E4_step_exits": exits, "historical_custody": "SEVEN_UNRESOLVED_NOTPASS",
        "files_excluding_pending_receipt_capture": {path.relative_to(ROOT).as_posix(): digest(path) for path in paths},
        "elapsed_after_imports": time.perf_counter() - started,
    })
    timer.cancel()


def read_line(line):
    import json

    return json.loads(line) if line.strip() else {}


if __name__ == "__main__":
    main()
