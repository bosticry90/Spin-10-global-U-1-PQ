# V874 phase A whole source insertion disposition

Both frozen routes completed in 1.780 seconds and agree. The maximum
sampled private allocation was 185,274,368 bytes. The external-only
A variation T_A and the actual whole source insertion agree as literal
density coefficients through first g, at full background and before
restricting sources or ordinary fields. For S the comparison has 48
grade-zero and 1,152 grade-one rows. For U_H it has 480 and 8,640.
Both U_M sides are absent in these grades. There are no residual rows
in either background comparison. The physical action has no A or
sources, so the nonzero comparison uses its full GF/source companion.

Since C(R_A)=0, write the literal compact parent as
P=R_A+sigma(S_A+uU−R_A). Through these grades the tree combination
G=(T_q+C)P can be written

    G=(1−sigma) T_q R_A+sigma T_b(S_A+uU).

Keep the total derivative current of the uncut background operation
when multiplying by sigma. The actual switched G need not vanish.
At one quadratic bridge on the common plateau the missing affine-A
part of T_q P is supplied by the whole C(P) insertion, not by varying
A in the fixed-background operation. The actual C11,a9,omega10
row has a parameter second derivative in the LEFT C11 output.
Choose a compact omega with zero first jet and nonzero second jet
in a local test region. Its Wightman coupling on separated supports
then provides a sensitive insertion control. The producer checks
the actual literal rows and their second-jet sign. The distributional
comparison remains for phase B.

For the connected W5 source lift write T_q z=ell z+v and let the
ordinary source transform by the evaluation dual of −ell, in the
original source-first order. V871's graphwise Legendre cancellation
then gives the candidate

    Ttilde_q W + I_CP^W = I_G^W + integral j v.

Here I^W is the derivative of the absolute connected functional at
fixed j, and its identification with the proper insertion uses the
full formal mean phi(j). At first loop it includes the rooted mean
term in addition to the proper derivative. Check the actual grade-zero
mixed B/Lambda contact for the jv term and the nonzero first-g ghost
row for the whole C(P) insertion. Preserve the same finite correction
and background-only terms. This source-functional comparison is
separate from a general derivation of relative causal field products.
Phase A does not by itself qualify the connected identity.
