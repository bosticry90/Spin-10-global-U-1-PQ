# Phase B setup correction

The first wrapper stopped before freezing Phase B or launching its worker.
It demanded a Phase A result copy in the external control directory, but
Phase A wrote its result in the calculation packet. Phase A preparation
and capture do have external copies, and V2 still compares them. V2 binds
the packet's actual result hash, frozen Phase A inputs, both route status
and the complete original source. The separate final worker checks the
recorded phase A counts and the Phase B controls against the owner replay.
Preserve the initial wrapper and shell capture. No change to the scientific
test, physics inputs, resource limits or acceptance criteria.
