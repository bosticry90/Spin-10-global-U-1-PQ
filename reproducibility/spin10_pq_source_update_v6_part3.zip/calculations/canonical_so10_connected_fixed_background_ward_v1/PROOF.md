# Connected geometric Ward identity at fixed background

## Selected common functional

Use V869 and V870's compact parent P=R_A+sigma(S_A+uU−R_A), first g,
first H or M u, with one compact even omega and rho=beta=0. Geometric T_q
acts at theta=0 at fixed A. C(P) is the first whole source-shift insertion
at theta=0. In the source-first chart write T_q z=M z+v, with M even,
local, independent of ordinary fields, and v_B=partial omega on the
light B support. The retained source action is the V865 evaluation dual.
The background operation T_b differs from T_q by the A derivative T_A.

Phase A compares the actual source and A substitutions before any field
or source restriction. It gives C(S_A)=T_A S_A, C(U_H)=T_A U_H and
C(U_M)=T_A U_M=0 in these grades. C(R_A)=0. Consequently the literal
direction G=(T_q+C)P is

    G=(1−sigma) T_q R_A + sigma T_b(S_A+uU).

Weight the actual uncut background currents by sigma before discarding
total derivatives. In the functional the uncut term contributes the
negative switch gradient contracted with its current. In general G is a
nonzero insertion. On a common sigma=1 patch containing omega's support,
the reference cancels and the uncut current integrates to zero.

For the proper loop coefficient F, the V868 affine LEFT Hessian chain
holds for the full A-labeled parent since the ordinary-field tangent is
still affine and A is held fixed. Its extra ordered terms are M^t H+H M.
V868's converted cyclic trace and zero sector trace of M cancel those
terms. Use V869's fixed flat reference factorization for the whole parent,
including the reference determinant and any affine reference insertion.
For each direction V deform that same parent by s V before differentiating
F. Keep the same heat clock, UV finite part followed by joint IR limit,
and full regulated forest. In causal coordinates the common correction
is C_fin+b with b the V867 conversion and the inherited Laurent offset.
Thus T_q F=I^Gamma_(T_q P),1 and the tree identity has the same insertion
notation. In an unconverted chart with conversion D, the raw difference
T_q F_raw−I_(T_qP),raw equals I_(T_qP),D−T_q D. No raw homogeneous Ward
condition or separate source contact normalization is needed.

The V868 affine directions have a compact local parameter and finite jets.
At this grade the C direction has the compact switch and the same single
parameter, with the local dimension bound inherited from the action and
source operation. Add one marked vertex to V871's independent compact
slots, using its cycle and regulated rooted forests. In a local conversion
word there are at most four positive costs and three possible labeled
slots (g,u,s); this bounds the needed new local jet words, while retaining
the full finite coefficient at each grade. Sewing differentiates the
complete bridges, including local Green contacts. The operation never
requires evaluating a nonlocal proper functional on an arbitrary
Schwartz mean. It uses the same formal coefficient substitution on both
sides. The test is for one insertion, with no products of independent
geometric labels.

## Affine ordinary-source term and full formal mean

Let j be the ordinary source and use source-first integral j z. Lift
T_q to Ttilde_q with Ttilde_q j=−j M. M preserves parity, so the ordered
evaluation dual cancels the homogeneous variation in j z. The surviving
term is integral j v. For s_i=(-1)^p_i the LEFT Euler of the source
coupling in z_i is s_i j_i. V871's stationary Legendre map has
EL^L_phi Gamma=−s_i j_i. In the ordered even differential, moving the
field variation past j_i cancels s_i. Differentiating the stationary
relation W=Gamma+integral j phi therefore gives

    Ttilde_q W=(T_q Gamma)(phi(j))+integral j v.

For an even whole action direction V, the variation of the stationary
mean cancels at fixed j. This gives I_V^W=(I_V^Gamma)(phi(j)). At one loop
the equality reads

    (I_V^W)_1 = (I_V^Gamma)_1(phi0) + V_phi[phi1]
              = (I_V^Gamma)_1(phi0) + F_phi[y_V].

Here phi1=−G_tree EL^L F and y_V=−G_tree EL^L V in the owner pairing.
The equality of the two chain terms is symmetry of the even polarized
tree Hessian with the evaluation signs retained. This is the first-order
rooted substitution of V871. A linear V can have zero ordinary Hessian
and still give a nonzero chain term. At g0 the homogeneous carrier M
vanishes, so the affine Ward term in the proper loop insertion must
cancel its rooted mean term in the connected functional. A finite
nonlinear fixture tests this cancellation with both terms nonzero.

The resulting identity for the common absolute functional is

    Ttilde_q W + I_CP^W = I_G^W + integral j v.

In the g0 unprobed Euclidean calibration, the actual plateau proper
direction is +i Lambda_H Box_E omega_H. At reference momentum q, the
mixed ordered inverse has G_Lambda,B(q)=q_mu/q^2 and its opposite
orientation is negative. Stationarity gives phi_Lambda(−q)=
+q_mu j_B,mu(−q)/q^2. Multiplication by Box_E omega(q) gives
−i q_mu j_B,mu(−q) omega(q), which is −jv. Swapping mixed order reverses
this sign, and omitting the mixed contraction gives zero. In the full
tree, the same sign follows from EL P=−s j without substituting the flat
free mean for the switched mean. Compact real j_B0=partial_0 omega on
the plateau gives a nonzero Euclidean pairing. The momentum ratio is a
free bridge calibration; the proof uses the compact rooted identity.

## Actual quadratic ghost response

For this separate bridge test restrict the omega support to the common
plateau and take the flat point after the ordinary variations. Let
N=H(CP)=H(T_A P) there and D=H(T_bP). V872/V873 give
D=−M^t K0−K0 M in the selected quadratic bridge. Thus H(T_q P)=D−N.
For a compact even quadratic direction X the ordered weak response is

    R(X)=−G_ret X W−W X G_adv.

The two Green identities and both W bisolution equations use the original
graded ordered pairing of V873. The fixed-A response is M W+W M^t−R(N).
The whole CP response supplies R(N). Away from the plateau the reference
piece in G remains; the bridge comparison gives no general star Ward law.

In the actual C_S Minkowski density the C11,a9,omega10 coefficient is
+g(partial^mu C11) a9 partial_mu omega10. Its LEFT C11 output is
−g(D_omega+Box omega) on a9, where D_omega=partial^mu omega partial_mu.
The reverse LEFT a9 output is −g D_omega on C11, by the odd derivative
and the different derivative placement. The four coefficients in the
current Euclidean chart are +1, and the Minkowski ones are +1,−1,−1,−1.

To see that the missing response is a nonzero distribution, apply the
actual differential K0 in the first endpoint. It gives K0 R(N)=−N W.
In the C11,C9 output choose the massless spectator W_a9,C9=−w. At a
point x where omega is a compact bump times (x^0)^2/2 with the bump one
near zero, partial omega(0)=0 and Box omega(0)=1. Take y spacelike from
x with y^0=0 and spatial distance L>0. There w=1/(4 pi^2 L^2), the
smooth spacelike value of the actual massless Wightman distribution.
It follows from the free positive-frequency integral by angular
integration and the Abel limit of integral exp(−epsilon p) sin(pL) dp.
The nonzero value of −N W and its difference from a missing-Box-jet
operator persist in open separated neighborhoods by smoothness. Compact
tests in these neighborhoods detect the difference. The first test may
be acted on by K0's formal adjoint without increasing its support. This
proves sensitivity of the response without assigning values to a cone
singularity or assuming the first jet vanishes on an open neighborhood.

The qualification covers the selected absolute connected one-loop Ward
identity and the stated quadratic response. The two input routes and
reviews share the action, conventions, regulator construction and AI
authorship. General nonlinear relative products, a compatible state,
global limits, the full W1–W7 acceptance and physical viability remain open.
