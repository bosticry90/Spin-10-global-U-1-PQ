# Phase B exact-expression correction

The V2 worker reached the Minkowski spectator calculation and failed
the structural comparison of the exact Abel integral. SymPy produced
1/(L(1+epsilon^2/L^2)), while the assertion expected L/(epsilon^2+L^2).
V3 requires exact rational cancellation of their difference under the
same positive L and epsilon assumptions. Keep the V2 sources, capture
and earlier setup failure. V3 also explicitly enforces the declared
120-second worker and 8 MiB artifact limits. The action, proof,
all controls and acceptance requirements are the same.
