"""Actual selected contact checks for the compact connected W5 proof."""

import gzip
import json
import os
import threading

import sympy as sp

from execute_a import HERE, ROOT, save


CALC = ROOT / "calculations"
INVERSE = CALC / "canonical_so10_regulator_free_inverse_g1_recovery_v1"
METRIC = CALC / "canonical_so10_geometric_metric_insertion_lift_v1"


def read(path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == ".gz" else data)


def affine_contact(inverse, source_root):
    q = sp.symbols("q0:4", real=True)
    j = sp.symbols("j0:4")
    Q = sum(p * p for p in q)
    parse = dict(zip((str(p) for p in q), q))
    matrices = [{(i, k): sp.sympify(value, locals=parse) for i, k, value in inverse[name]}
                for name in ("Preference", "Greference")]
    kernel, green = matrices
    assert (508, 508) not in green
    dual, wrong_dual = [], []
    for mu, p in enumerate(q):
        assert (kernel[mu, 508], kernel[508, mu]) == (p, -p)
        assert sp.cancel(green[508, mu] - p / Q) == 0
        assert sp.cancel(green[mu, 508] + p / Q) == 0
        dual.append(-green[508, mu].subs(dict(zip(q, (-p for p in q))), simultaneous=True))
        wrong_dual.append(-dual[-1])
    cp_rows = [row for row in source_root if row[0] == 0 and {t[0] for t in row[1]} == {508, 1286}]
    assert cp_rows == [[0, [[508, []], [1286, [mu, mu]]], [[[0, 0, 16], -1, 1]]] for mu in range(4)]
    plus_jv = sp.I * sum(p * a for p, a in zip(q, j))
    h = -sp.I * Q * sum(d * a for d, a in zip(dual, j))
    wrong_h = -sp.I * Q * sum(d * a for d, a in zip(wrong_dual, j))
    assert sp.cancel(h + plus_jv) == 0
    assert sp.cancel(wrong_h - plus_jv) == 0 and plus_jv != 0
    return {"CP_grade0_density": cp_rows, "mixed_ordered_contact_positions": 8,
            "TP_on_reference_mean_over_omega": str(sp.cancel(h)),
            "correct_residual": 0, "wrong_orientation_residual_over_omega": str(2 * plus_jv),
            "dropped_mixed_residual_over_omega": str(plus_jv)}


def ghost_contact(root, actual):
    ids = {564, 607, 1296}
    minkowski = [row for row in root if {t[0] for t in row[0]} == ids]
    signs = [1, -1, -1, -1]
    assert minkowski == [[[[564, [mu]], [607, []], [1296, [mu]]], [[[1, 0, 0, 0], sign, 1]]]
                        for mu, sign in enumerate(signs)]
    euclidean = actual["actual_ghost_rows"]
    assert euclidean == [[1, [[564, [mu]], [607, []], [1329, [mu]]], [[[0, 0, 0], 1, 1]]]
                         for mu in range(4)]
    assert actual["C11_output_second_parameter_jet"] == [[564, 607, [mu, mu], -1] for mu in range(4)]
    x = sp.symbols("x0:4", real=True)
    L, p, eps = sp.symbols("L p epsilon", positive=True)
    origin = dict.fromkeys(x, 0)
    omega = x[0] ** 2 / 2  # germ of a smooth compact test with plateau bump
    w = 1 / (4 * sp.pi**2 * ((x[1] - L)**2 + x[2]**2 + x[3]**2 - x[0]**2))
    abel = sp.integrate(sp.exp(-eps * p) * sp.sin(p * L), (p, 0, sp.oo))
    assert sp.cancel(abel - L / (eps**2 + L**2)) == 0
    expected = -1 / (4 * sp.pi**2 * L**2)
    projected = -sum(s * sp.diff(sp.diff(omega, t) * w, t) for s, t in zip(signs, x)).subs(origin)
    no_second_jet = -sum(s * sp.diff(omega, t) * sp.diff(w, t) for s, t in zip(signs, x)).subs(origin)
    assert projected == expected and no_second_jet == 0
    return {"actual_Minkowski_density": minkowski, "spectator": [607, 562, -1],
            "K0_response_spacelike_value_over_g": str(projected),
            "wrong_missing_second_jet_value_over_g": str(no_second_jet)}


def nonlinear_chain():
    z, s = sp.symbols("z s", real=True)
    k, b, v = sp.symbols("k b v", positive=True)
    P = k * z**2 / 2 + b * z**3 / 6
    H = v * sp.diff(P, z)
    F = sp.log(sp.diff(P, z, 2)) / 2
    proper = sp.diff(sp.log(sp.diff(P + s * H, z, 2)) / 2, s).subs({z: 0, s: 0})
    phi1 = -sp.diff(F, z).subs(z, 0) / k
    mean = sp.diff(H, z).subs(z, 0) * phi1
    stationarity_tangent = -sp.diff(H, z).subs(z, 0) / k
    assert proper == v * b / (2 * k)
    assert mean == sp.diff(F, z).subs(z, 0) * stationarity_tangent == -proper
    return {"proper": str(proper), "rooted_mean": str(mean), "sum": 0}


def main():
    timer = threading.Timer(120, lambda: os._exit(124))
    timer.daemon = True
    timer.start()
    a = read(HERE / "result_a.json")["comparison"]
    inverse = read(INVERSE / "native_inverse.json.gz")
    packet = read(METRIC / "native_complete_geometric_metric_insertions.json.gz")
    cs = next(row for row in packet["all_fixed_density_roots"] if row["name"] == "C_S")
    report = {
        "execution_state": "COMPLETED", "affine": affine_contact(inverse, cs["complete_Euclidean"]),
        "ghost": ghost_contact(cs["complete_Minkowski"], a), "mean_chain": nonlinear_chain(),
    }
    artifact_ok = len(json.dumps(report).encode()) + 1 <= 8 * 1024**2
    save("result_b_v3.json" if artifact_ok else "result_b_v3.COMPLETE_OVERFLOW_NOTPASS", report)
    assert artifact_ok
    timer.cancel()
    print("STAGE actual affine source, separated ghost and full-mean controls checked", flush=True)


if __name__ == "__main__":
    main()
