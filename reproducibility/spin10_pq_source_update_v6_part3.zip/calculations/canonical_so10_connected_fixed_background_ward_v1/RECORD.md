# V874 connected geometric Ward insertion at fixed background

Continue V873 on main, D:, under AGENTS. Use the literal compact V869
parent, first g and first H or M u, with the original source-first
evaluation dual and fixed A under the geometric quantum variation.
Keep the ordinary sources, full background support, opposite reference
vertex and cutoff currents. Use rho=beta=0 and one local omega label.
The source shift C is inserted through the same action family.

Phase A compares the actual whole C(S) and C(U_H/M) with the
contribution from varying only A under the V865 background operation.
Include the affine and homogeneous A terms and their jet prolongations.
Compare both full-background and A=0 residuals before source or field
restriction, without assigning a missing row zero. Record any remaining
terms exactly for the next integrated-current check. Bind a nonzero
actual light ghost pair with the parameter second derivative in its
ordinary Hessian. This is a tree operator/source insertion comparison.

Freeze sources and inputs before running. Root owns writes. The worker
limit is 120 seconds, 8 GiB sampled private allocation, 350 MiB launch
floor, 8 MiB artifact and 32 MiB packet. Preserve exact outputs and
failure captures. No new loop integral or protected promotion.

Phase B must bind the compact V871 rooted connected and proper
insertion maps through the full affine source lift, including the
ordinary-source term and full formal mean. Keep the whole C(P) and the
cutoff breaking. In a quadratic connected test compare the missing
A response and the actual C(P) insertion through the retarded and
advanced contacts. A causal relative observable statement requires
its own supported check. General W5, nonlinear products, E5/A5 and
physical viability stay open.
