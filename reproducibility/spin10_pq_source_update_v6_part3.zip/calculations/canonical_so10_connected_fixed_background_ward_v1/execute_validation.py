"""Freeze and run the separate V874 final review."""

import json
from hashlib import sha256

from execute_a import CONTROL, HERE, ROOT, git, save
from execute_b import digest, execute, freeze_sources


NAV = ["README.md", "docs/COMMON_RESTORATION_CAMPAIGN_V1.md", "docs/RESEARCH_EXECUTION_HANDOFF_V874.md"]


def main():
    b = json.loads((HERE / "preparation_b_v3.json").read_bytes())
    assert git("rev-parse", "HEAD").decode().strip() == b["base_HEAD"]
    assert not git("diff", "--cached", "--name-only")
    assert set(git("diff", "--name-only", "HEAD").decode().splitlines()) == set(NAV[:2])
    for name, backup in zip(NAV[:2], ("README_before_final.bytes", "campaign_before_final.bytes")):
        assert (CONTROL / backup).read_bytes().replace(b"\r\n", b"\n") == git("show", "HEAD:" + name)
    for name, expected in b["sha256"].items():
        assert digest(ROOT / name) == expected, name
    historic = git("show", "ef70f255a667b9a81e37b344dc78967ada4ed896:README.md")
    assert sha256(historic).hexdigest() == "4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792"
    freeze_sources(("RESULT.md", "validate.py", "execute_validation.py"))
    names = set(b["sha256"]) | set(NAV)
    names.update(path.relative_to(ROOT).as_posix() for path in HERE.iterdir() if path.is_file())
    names.add("docs/LOCAL_RESEARCH_CONVENTIONS_V1.md")
    for folder in ("causal_wick_bridge", "causal_one_loop_sewing"):
        names.update(f"calculations/canonical_so10_{folder}/{name}" for name in ("DERIVATION.md", "validation_receipt.json"))
    receipts = sorted(n for n in names if "validation_receipt" in n and n.endswith(".json"))
    save("preparation_validation.json", {
        "base_HEAD": b["base_HEAD"], "navigation": NAV, "owner_receipts": receipts,
        "sha256": {name: digest(ROOT / name) for name in sorted(names)},
        "limits": {**b["limits"], "seconds": 180}, "scientific_acceptance": "NOT_PERFORMED",
    })
    execute("validate.py", "validation")


if __name__ == "__main__":
    main()
