"""Compare the actual whole C source insertion to the external A variation."""

from collections import Counter, defaultdict
from hashlib import sha256
from itertools import product
from pathlib import Path
import json
import os
import sys
import threading
import time


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "canonical_so10_connected_massless_background_bridge_v1"))
from massless import CURRENT, ROOT, clean, coefficient, encode, read


def word_tuple(word):
    return tuple((n, tuple(jets)) for n, jets in word)


def value_of(cells):
    return coefficient(tuple((tuple(key), num, den) for key, num, den in cells))


def external_rules(data):
    rules = {}
    raw = dict(data["all1391_Tb_columns"])
    for n in range(1331, 1379):
        column = []
        for grade, word, cells in raw[n]:
            typed = []
            for m, jets in word:
                if 1379 <= m < 1391:
                    m -= 60  # Use the same quantum omega argument as C.
                assert 1319 <= m < 1379
                typed.append((m, tuple(jets)))
            column.append((grade, tuple(typed), value_of(cells)))
        rules[n] = column
    return rules


def apply_A(rows, rules):
    out = defaultdict(int)
    for g, atoms, cells in rows:
        word = word_tuple(atoms)
        for slot, (n, derivatives) in enumerate(word):
            if n not in rules:
                continue
            value = value_of(cells)
            for h, replacement, factor in rules[n]:
                if g + h > 1:
                    continue
                for places in product(range(len(replacement)), repeat=len(derivatives)):
                    labels = [(i, tuple(sorted(jets + tuple(d for d, place in zip(derivatives, places) if place == k))))
                              for k, (i, jets) in enumerate(replacement)]
                    # All replacement atoms are even. Sorting therefore
                    # preserves the original relative order of odd atoms.
                    out[g+h, tuple(sorted(word[:slot] + tuple(labels) + word[slot+1:]))] += value * factor
    return clean(out)


def compare(parent, insertion, rules):
    direct = apply_A(parent, rules)
    actual = {(g, word_tuple(word)): value_of(cells) for g, word, cells in insertion}
    residual = clean({key: actual.get(key, 0) - direct.get(key, 0) for key in direct.keys() | actual.keys()})
    flat = {key: value for key, value in residual.items() if all(not 1331 <= n < 1379 for n, jets in key[1])}
    return {"direct_rows_by_grade": Counter(g for g, word in direct),
            "insertion_rows_by_grade": Counter(g for g, word in actual),
            "complete_residual": encode(residual), "flat_residual": encode(flat)}


def role_check(role):
    data = read(CURRENT / f"{role}_complete_full_background_extension.json.gz")
    rules = external_rules(data)
    ordinary = compare(data["complete_S_GF_source"], data["complete_CS"], rules)
    probes = {probe["probe"]: compare(probe["complete_U"], probe["complete_CU"], rules) for probe in data["probes"]}
    # Actual quadratic ghost witness, with the original C then a order.
    ghost_rows = [row for row in data["complete_CS"] if row[0] == 1 and {n for n, jets in row[1]} == {564, 607, 1329}]
    assert ghost_rows == [[1, [[564, [mu]], [607, []], [1329, [mu]]], [[[0, 0, 0], 1, 1]]] for mu in range(4)]
    # For output C11 the left Euler puts -partial_mu on both the
    # quantum parameter and the incoming a9. This second jet has
    # coefficient -1. It must survive if the first parameter jet is zero.
    second_jet = []
    for _, ((output, left_jet), (incoming, _), (_, omega_jet)), cells in ghost_rows:
        value = (-1) ** len(left_jet) * value_of(cells)
        second_jet.append([output, incoming, sorted(left_jet + omega_jet), int(value)])
    assert second_jet == [[564, 607, [mu, mu], -1] for mu in range(4)]
    return {"base": ordinary, "probes": probes, "actual_ghost_rows": ghost_rows,
            "C11_output_second_parameter_jet": second_jet}


def main():
    started = time.perf_counter()
    watch = threading.Timer(120, lambda: os._exit(124))
    watch.daemon = True
    watch.start()
    for name, expected in read(HERE / "preparation_a.json")["sha256"].items():
        assert sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    first = role_check("native")
    print("STAGE native actual external A and whole source insertions compared", flush=True)
    second = role_check("replay")
    assert first == second
    print("STAGE replay literal comparison agrees", flush=True)
    result = {"execution_state": "COMPLETED", "scientific_acceptance": "NOT_PERFORMED",
              "phase": "A_WHOLE_SOURCE_AND_EXTERNAL_BACKGROUND_VARIATION", "comparison": first,
              "seconds": time.perf_counter() - started}
    data = (json.dumps(result, sort_keys=True) + "\n").encode()
    name = "result_a.json" if len(data) <= 8 * 1024**2 else "result_a.COMPLETE_OVERFLOW_NOTPASS"
    with (HERE / name).open("xb") as stream:
        stream.write(data)
    assert name == "result_a.json"
    watch.cancel()


if __name__ == "__main__":
    main()
