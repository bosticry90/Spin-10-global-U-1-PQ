"""Freeze and run the selected connected Ward controls."""

import ast
import json
import sys
from hashlib import sha256

from execute_a import CONTROL, HERE, PK, ROOT, git, save


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def freeze_sources(names):
    for name in names:
        data = (HERE / name).read_bytes()
        if name.endswith(".py"):
            ast.parse(data)
        with (HERE / (name + ".source.txt")).open("xb") as stream:
            stream.write(data)


def execute(name, suffix):
    sys.path.insert(0, str(PK))
    from export_a10_e5_antighost_vector import capture

    report = capture([sys.executable, "-B", str(HERE / name)])
    save(f"capture_{suffix}.json", report)
    print(report["stdout_and_stderr"], end="")
    assert report["calculation_completed"] and report["post_run_observations_qualified"]
    assert sum(path.stat().st_size for path in HERE.iterdir() if path.is_file()) <= 32 * 1024**2


def main():
    a = json.loads((HERE / "preparation_a.json").read_bytes())
    assert git("rev-parse", "HEAD").decode().strip() == a["base_HEAD"]
    assert not git("diff", "--name-only", "HEAD")
    for name, expected in a["sha256"].items():
        assert digest(ROOT / name) == expected, name
    for name in ("preparation_a.json", "capture_a.json", "result_a.json"):
        assert (HERE / name).read_bytes() == (CONTROL / name).read_bytes(), name
    freeze_sources(("PHASE_B_RECORD.md", "PROOF.md", "connected.py", "execute_b.py"))
    owners = {
        "compact_switched_master_domain_v1": ("PROOF.md", "validation_receipt.json"),
        "joint_compact_background_geometric_v1": ("PROOF.md", "validation_receipt.json"),
        "regulator_free_inverse_g1_recovery_v1": ("PROOF.md", "validation_receipt.json", "native_inverse.json.gz", "replay_inverse.json.gz"),
        "geometric_metric_insertion_lift_v1": ("PROOF.md", "validation_receipt.json", "native_complete_geometric_metric_insertions.json.gz", "replay_complete_geometric_metric_insertions.json.gz"),
        "free_causal_reference": ("DERIVATION.md", "validation_receipt_v3.json"),
        "graded_causal_qap": ("DERIVATION.md", "validation_receipt_v2.json"),
    }
    names = set(a["sha256"])
    for folder, files in owners.items():
        names.update(f"calculations/canonical_so10_{folder}/{name}" for name in files)
    names.update(path.relative_to(ROOT).as_posix() for path in HERE.iterdir() if path.is_file())
    save("preparation_b.json", {
        "base_HEAD": a["base_HEAD"], "limits": a["limits"], "scientific_acceptance": "NOT_PERFORMED",
        "sha256": {name: digest(ROOT / name) for name in sorted(names)},
    })
    execute("connected.py", "b")


if __name__ == "__main__":
    main()
