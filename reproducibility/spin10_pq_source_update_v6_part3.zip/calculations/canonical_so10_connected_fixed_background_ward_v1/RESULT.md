# V874 selected absolute connected W5 at fixed background

The common compact absolute source functional satisfies

    Ttilde_q W + I_CP^W = I_G^W + integral j v

through one loop, first g and first H or M probe, at fixed full A with
one local geometric label. Here v is the affine light-vector shift and
G retains the switched reference and uncut background currents. The
insertion uses the full formal mean and the same regulated forests and
finite correction as W.

Phase A matched 10,320 literal rows between the whole source insertion
and the A-only variation. Phase B checked the mixed affine contact, a
nonzero first-g ghost response and a nonzero rooted loop-mean term.
The ghost test compares the current Euclidean density to its actual
Minkowski continuation and uses separated spacelike tests after applying
the left free differential. The ordinary-source control fails for the
wrong mixed orientation. The full-mean fixture fails if the rooted term
is dropped. Details and scope are in [PROOF.md](PROOF.md).

Preserve the initial missing-control-copy setup failure and the V2
structural-expression assertion failure. V3 cancels the exact Abel
fractions algebraically with unchanged assumptions. Qualification
requires the separate validation receipt and capture. General nonlinear
relative products and all W1–W7 acceptance remain open. State 113 and
scientific authority 34/39 are unaffected by this evidence.
