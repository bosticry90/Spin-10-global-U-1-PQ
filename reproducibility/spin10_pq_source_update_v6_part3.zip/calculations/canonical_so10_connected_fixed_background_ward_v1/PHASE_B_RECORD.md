# V874 phase B and final review contract

Close the selected absolute compact connected W5 identity through one loop,
first g and first H or M probe, at full fixed A, rho=beta=theta=0 and one
compact even geometric label. The first whole source derivative uses the
same parent before setting theta to zero. Freeze the proof and worker
before execution. Check the inherited proper and rooted maps, the entire
phase A residual status, an actual g0 mixed affine contact and an actual
g1 Minkowski LEFT ghost Hessian. Test the full-mean chain on a nonlinear
finite fixture. An algebraic fixture calibrates a rule, not a physical
amplitude. Preserve the cutoff currents and background-only terms.

Reject a wrong source dual, missing affine term, missing second parameter
jet or omitted rooted loop-mean term. The distribution witness uses the
ordered Green identities and separated spacelike compact tests after
applying K0 on the left. No loop integrations, full relative-product Ward
statement, unrestricted field-product domain, or protected promotion.

Use the phase A resource limits for the scientific worker. Independently
review the weak distribution step and the Legendre cancellation. Final E4
uses the established historical context and a 120-second subprocess.
Require step exits [0,0,0,0,0,2] with exactly seven unresolved custody
references, unchanged scientific state and preserved README suffix. No
acceptance is inferred from the byte or custody checks.
