from pathlib import Path
from fractions import Fraction as Fr
from hashlib import sha256
import ast,gc,gzip,importlib.util,json,os,re,subprocess,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/cartan-gaussian-support-g0-v1-2026-11-08');digest=lambda q:sha256(q.read_bytes()).hexdigest();read=lambda q:json.loads(q.read_bytes());load=lambda q:json.loads(gzip.decompress(q.read_bytes()))
def module(name,q):
 sp=importlib.util.spec_from_file_location(name,q);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in['preparation.json','preparation_validation.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for q in O.glob('*.source.txt'):assert q.read_bytes()==q.with_name(q.name.removesuffix('.source.txt')).read_bytes(),q.name
 cap=read(O/'capture.json');res=read(O/'result.json');assert cap==read(C/'capture.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and res['all_structural_premises_pass']and res['elapsed_after_imports']<180;assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and cap['all_resource_samples']and all(0<q['private_bytes']<=8*1024**3 for q in cap['all_resource_samples'])
 a=module('CGS_final_support_helpers',O/'compute_support.py');J=a.J;p=a.p;raw=module('CGS_qualified_Fraction_Taylor',O.parent/'canonical_so10_cartan_generator_residual_g1_v1/final_review_v4.py');Hcount=0;hidden=0;omission_controls=[];mapchecks=0
 for role in['native','replay']:
  base=O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1';common=load(base/(role+'_GF_common.json.gz'));S0=load(base/(role+'_route_density.json.gz'))['original_GF'];packet=load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));states={k:dict(v)for k,v in packet['states'].items()};del packet
  for label,owner in[('S0',S0),('U0_H',common['probes'][0]['U']),('U0_M',common['probes'][1]['U'])]:
   z=load(O/(role+'_'+label+'_hessian_support.json.gz'));assert z['full_parent_density']==owner;P=raw.flat(owner);Hraw=raw.tangent(raw.tangent(P,1319),1962);same=raw.tangent(raw.tangent(P,1319),1319);assert Hraw==raw.flat(z['full_ordinary_T_k_T_h'])==raw.flat(z['full_LEFT_T_k_T_h']);assert same==raw.flat(z['complete_same_h_Hessian'])and{k:v/2 for k,v in same.items()}==raw.flat(z['quadratic_Taylor_half']);Hcount+=len(z['full_ordinary_T_k_T_h']);hidden+=len(z['hidden_ghost_mean_Hessian']);del P,Hraw,same
   for key in['forbidden_source_word_indices','joint_B_Ja_degree_counterexamples','scalar_port_word_indices','Ja_jet_word_indices','complete_pairing_difference','complete_mixed_block','bosonic_mean_or_source_counterexamples','ghost_affinity_or_species_counterexamples','ghost_internal_derivative_counterexamples']:assert not z[key],(role,label,key)
   H=J.decode(z['full_ordinary_T_k_T_h']);div={}
   for mu,rows in enumerate(z['four_Hessian_IBP_currents']):J.add(div,J.D(J.decode(rows),mu))
   assert a.a.plus(H,a.a.neg(J.decode(z['complete_canonical_h_normal_Hessian'])))==J.clean(div),'HESSIAN_LITERAL_IBP'
   peer=load(O/(('replay'if role=='native'else'native')+'_'+label+'_hessian_support.json.gz'));assert z['complete_canonical_h_normal_Hessian']==peer['complete_canonical_h_normal_Hessian'];del peer
   B={w:c for w,c in H.items()if any(n<180 for n,js in w)};Ja={w:c for w,c in H.items()if any(1241<=n<1286 for n,js in w)};expectedB={};expectedJa={}
   for bb,rows in z['all45_full_Ja_cofactors']:
    tail=J.decode(rows);assert tail==J.leftjet(H,(1241+bb,()));J.add(expectedJa,J.mul(p.atom(1241+bb),tail))
    for mu in range(4):J.add(expectedB,a.a.neg(J.mul(p.atom(4*bb+mu,(mu,)),tail)))
   assert B==J.clean(expectedB)==J.decode(z['complete_mean_B_part'])and Ja==J.clean(expectedJa)==J.decode(z['complete_mean_Ja_part']);assert all(a.degree_BJa(w)<=(0 if label=='S0'else 1)for w in H);assert all(not any(a.source(n)and(label=='S0'or not(1241<=n<1286))for n,js in w)for w in H);assert not any(a.scalar(n)for w in H for n,js in w)
   G={w:c for w,c in H.items()if not any(553<=n<643 for n,js in w)};assert G==J.decode(z['complete_ghost_zero_Hessian']);omission_controls.append(dict(role=role,parent=label,omitting_Ja_pair_sensitive=bool(B),unbroken_or_original_blind=not B));assert bool(B)==(label=='U0_M');del z,H,G;gc.collect()
  maps=load(O/(role+'_full_required_maps.json.gz'));assert not maps['all643_Q0_field_counterexamples']
  for n in range(643):
   expected=p.atom(553+n//4,(n%4,))if n<180 else a.a.sc(p.atom(508+n-598),J.I)if n>=598 else{};assert J.decode(states['F0'][n])==expected;mapchecks+=1
  for row in maps['all45_full_Q0Ja']:
   P=J.decode(row['complete_map']);assert P==a.a.neg(J.decode(states['E0'][row['port']-643]))and not row['B_Ja_counterexamples'];assert not any(n<180 or 1241<=n<1286 for w in P for n,js in w);mapchecks+=1
  for probe in maps['probes']:
   pr=probe['probe'];assert not probe['non_a_field_counterexamples'];F=states['Fu0_'+str(pr)];assert all(not F[n]for n in range(598))
   for row in probe['all45_a_blocks']:
    P=J.decode(row['complete_map']);assert P==J.decode(F[row['port']]);actual={w:c for w,c in P.items()if any(n<180 or 1241<=n<1286 for n,js in w)};paired={}
    for bb in range(45):
     coefficient=P.get(((1241+bb,()),),a.zero)
     if coefficient:
      J.add(paired,a.a.sc(p.atom(1241+bb),coefficient))
      for mu in range(4):J.add(paired,a.a.sc(p.atom(4*bb+mu,(mu,)),-coefficient))
    assert actual==J.clean(paired),'FULL_Qu0a_B_Ja_REMAINDER_NOT_PAIRED';assert not any(cells for bb,mu,cells in row['all180_W_plus_S_coefficients']);mapchecks+=1
  del common,states;gc.collect()
 endpoint=load(O/'complete_R_endpoint_support.json.gz');assert len(endpoint['all76_nonzero_coordinates'])==76 and not endpoint['unexpected_port_or_shape_counterexamples']
 inv=load(O.parent/'canonical_so10_regulator_free_inverse_g1_recovery_v1/native_inverse.json.gz');assert inv==load(O.parent/'canonical_so10_regulator_free_inverse_g1_recovery_v1/replay_inverse.json.gz');allowed={'E_profile','f_profile','q0','q1','q2','q3','xi','eta_H','Mref_Phi_squared','Mref_S_squared','Mref_Sigma_squared','Mref_phi_squared'};symbols=set()
 for key in['full_regulator','Preference']:
  for row in inv[key]:symbols|={n.id for n in ast.walk(ast.parse(row[2],mode='eval'))if isinstance(n,ast.Name)}
 assert symbols<=allowed,'REGULATOR_OR_REFERENCE_HAS_UNFROZEN_MEAN_SOURCE_SYMBOL'
 local=module('CGS_local_Pi_calibration',O.parent/'canonical_so10_marked_source_projection_g1_v1/source_projection_v2.py');bb=12;cc=13;eps=1286;pref=J.mul(p.atom(553+cc),p.atom(eps));F=a.a.sc(J.mul(p.atom(1241+bb),pref),J.constant(5))
 for mu in range(4):F=a.a.plus(F,a.a.sc(J.mul(p.atom(4*bb+mu,(mu,)),pref),J.constant(2)),a.a.sc(J.mul(p.atom(4*bb+mu),J.mul(p.atom(553+cc,(mu,)),p.atom(eps))),J.constant(3)))
 el=J.euler(F,set(range(1286)));pi=local.project(F)['Pi'];calibration=[];variable_kernel_controls=[]
 for mu in range(4):
  defect=a.a.plus(el.get(4*bb+mu,{}),a.a.neg(J.D(el.get(1241+bb,{}),mu)));cghost=defect.get(((553+cc,(mu,)),(eps,())),a.zero);ceps=defect.get(((553+cc,()),(eps,(mu,))),a.zero);assert cghost==J.constant(-4)and ceps==J.constant(-7)and pi[12,bb,cc,mu]==-cghost;current=J.mul(p.atom(4*bb+mu),pref);totaldiv=J.D(current,mu);assert not J.euler(totaldiv,set(range(1286))),'LOCAL_ZERO_FUNCTIONAL_EULER_CONTROL';calibration.append([mu,4,7,True])
  # Existing scalar coordinate used ONLY as a varying spectator-kernel control.
  variable_div=J.D(J.mul(p.atom(180),current),mu);assert not J.euler(variable_div,set(range(1286)));omitted={w:c for w,c in variable_div.items()if not any(n==180 and js==(mu,)for n,js in w)};assert J.euler(omitted,{4*bb+mu}),'DROPPED_KERNEL_DERIVATIVE_NOT_DETECTED';variable_kernel_controls.append([mu,True,True])
 # Formal derivative symbols retain the SAME arbitrary external kernel/leg.
 kernel_controls=[]
 for mu in range(4):
  eb={'DxK_'+str(mu):Fr(-1)};dja={'DxK_'+str(mu):Fr(-1)}
  def difference(x,y):return{k:x.get(k,Fr(0))-y.get(k,Fr(0))for k in set(x)|set(y)if x.get(k,Fr(0))!=y.get(k,Fr(0))}
  paired=difference(eb,dja);wrong=difference(eb,{'DxK_'+str(mu):Fr(1)});independent=difference(eb,{'DxL_'+str(mu):Fr(-1)});zero_divergence=difference(eb,eb);dropped_kernel_derivative=eb;assert not paired and wrong and independent and not zero_divergence and dropped_kernel_derivative;kernel_controls.append(dict(mu=mu,paired_Euler_defect_zero=True,wrong_Ja_sign_sensitive=True,independent_kernel_sensitive=True,kernel_IBP_zero_and_omission_sensitive=True,external_B_Ja_leg='SAME_x',other_legs='INDEPENDENT_y_z'))
 dump(O/'paired_kernel_and_local_controls.json',dict(local_Euler_coefficient_calibration=calibration,kernel_controls=kernel_controls,variable_spectator_kernel_IBP_controls=variable_kernel_controls,model_partner_omission_controls=omission_controls,nonlocal_definition='FUNCTIONAL_E_B_MINUS_D_E_Ja; NOT_DISPLAYED_DERIVATIVE_PLACEMENT',no_trace_value_assigned=True))
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==read(O/'preparation.json')['base_HEAD'];assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md'];assert(C/'README_before.md').read_bytes()==subprocess.check_output(['git','show','HEAD:README.md'],cwd=R)
 history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);readme=(R/'README.md').read_bytes();assert readme.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792';state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';links=[]
 for q,text in[(R/'README.md',readme[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V837.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V837.md').read_text(encoding='utf-8'))]:
  for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',text):
   if target.startswith(('http:','https:','#')):continue
   resolved=(q.parent/target.split('#')[0]).resolve();assert resolved.is_relative_to(R)and resolved.exists();links.append([q.relative_to(R).as_posix(),target])
 command=[__import__('sys').executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0;events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[z['exit_code']for z in events if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(z for z in events if z['event']=='step_finished'and z['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 files=[q for q in O.iterdir()if q.is_file()]+[R/'README.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V837.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_FINITE_PROPER_CARTAN_EULER_KERNEL_PROJECTION',base_HEAD=head,state_sha256=state,full_Hessian_rows_Fraction_verified=Hcount,hidden_ghost_rows_retained=hidden,actual_map_blocks_verified=mapchecks,full_nonlocal_Euler_kernel_definition_IBP_invariant=True,local_V835_Pi_coefficient_calibrated=True,finite_proper_same_parent_theorem_only=True,reference_contact_mean_UVIR_and_common_restoration_NOT_established=True,new_loop_coefficients_computed_or_assigned=False,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',checked_local_links=links,files_excluding_pending_receipt_capture={q.relative_to(R).as_posix():digest(q)for q in files},shared_action_chart_software_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','full_Hessian_rows_Fraction_verified','hidden_ghost_rows_retained','actual_map_blocks_verified','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
