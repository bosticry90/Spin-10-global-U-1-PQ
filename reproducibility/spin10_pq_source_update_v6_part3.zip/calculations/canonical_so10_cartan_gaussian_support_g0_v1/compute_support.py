from pathlib import Path
from fractions import Fraction as Fr
from hashlib import sha256
import gc,gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/cartan-gaussian-support-g0-v1-2026-11-08')
sp=importlib.util.spec_from_file_location('CGS_existing_classical_helpers',O.parent/'canonical_so10_cartan_generator_residual_g1_v1/audit.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a);p=a.p;J=a.J;A=a.A;zero=a.zero
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(name,z):
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 if len(blob)>8*1024**2:
  with(C/(name+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
  raise AssertionError('COMPLETE_OVERFLOW_PRESERVED_NOTPASS')
 with(O/name).open('xb')as f:f.write(blob)
 assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def degree_BJa(w):return sum(n<180 or 1241<=n<1286 for n,js in w)
def source(n):return 643<=n<1286
def scalar(n):return 180<=n<508 or 1319+180<=n<1319+508 or 1962+180<=n<1962+508
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in a.read(O/'preparation.json')['sha256'].items():assert a.b.digest(R/n)==h,n
 endpoint=a.load(O.parent/'canonical_so10_cartan_generator_residual_g1_v1/v2_native_g1.json.gz');endpoints=[];endpointbad=[]
 for n,raw in endpoint['all1286_X_R']:
  if not raw:continue
  P=J.decode(raw);allowed=508<=n<553 or 1196<=n<1286
  if 508<=n<553 or 1241<=n<1286:shape=all(p.pattern(w)==('C','epsilon')and all(not js for k,js in w)for w in P)
  else:shape=all(p.pattern(w)in[('JLambda','epsilon'),('a','epsilon')]and all(not js for k,js in w)for w in P)
  if not allowed or not shape:endpointbad.append(n)
  endpoints.append([n,raw])
 endpointref=save('complete_R_endpoint_support.json.gz',dict(all76_nonzero_coordinates=endpoints,unexpected_port_or_shape_counterexamples=endpointbad,source_JC_endpoint_RETAINED=True));alloutputs=[];summaries=[]
 for role in['native','replay']:
  base=O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1';old=a.load(base/(role+'_GF_common.json.gz'));S0=J.decode(a.load(base/(role+'_route_density.json.gz'))['original_GF']);packet=a.load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));states={k:dict(v)for k,v in packet['states'].items()};del packet;gc.collect();outputs=[];rows=[]
  for label,P in[('S0',S0),('U0_H',J.decode(old['probes'][0]['U'])),('U0_M',J.decode(old['probes'][1]['U']))]:
   H=p.s.v.tangent(p.s.v.tangent(P),1962);peer=p.s.vr.tangent(p.s.vr.tangent(P),1962);canonical,ibp=p.normal(H,set(range(1319,1962)));same=p.s.v.tangent(p.s.v.tangent(P));assert H==peer,'FULL_PREFIX_LEFT_HESSIAN_DIFFERENCE';words=sorted(H);assert all(sum(1319<=n<1962 for n,js in w)==1 and sum(1962<=n<2605 for n,js in w)==1 for w in words);forbidden_source=[];degreebad=[];scalarbad=[];Ja_jets=[]
   for at,w in enumerate(words):
    if any(source(n)and(label=='S0'or not(1241<=n<1286))for n,js in w):forbidden_source.append(at)
    if degree_BJa(w)>(0 if label=='S0'else 1):degreebad.append(at)
    if any(scalar(n)for n,js in w):scalarbad.append(at)
    if any(1241<=n<1286 and js for n,js in w):Ja_jets.append(at)
   Bpart={w:c for w,c in H.items()if any(n<180 for n,js in w)};Jap={w:c for w,c in H.items()if any(1241<=n<1286 for n,js in w)};expectedB={};paircof=[]
   for bb in range(45):
    tail=J.leftjet(H,(1241+bb,()));paircof.append([bb,J.encode(tail)])
    for mu in range(4):J.add(expectedB,a.neg(J.mul(p.atom(4*bb+mu,(mu,)),tail)))
   expectedB=J.clean(expectedB);pairdiff=a.plus(Bpart,a.neg(expectedB));ghostzero={w:c for w,c in H.items()if not any(553<=n<643 for n,js in w)};boson={};ghost={};mixed={};bosonbad=[];ghostbad=[];internalbad=[]
   for at,(w,c)in enumerate(sorted(ghostzero.items())):
    count=sum(553<=(n-1962 if n>=1962 else n-1319)<643 for n,js in w if n>=1319)
    if count==0:
     boson[w]=c
     if any(n<1286 for n,js in w):bosonbad.append(at)
    elif count==2:
     ghost[w]=c;means=[(n,js)for n,js in w if n<1319]
     if len(means)>1 or any(not(n<180 or 508<=n<553 or 1241<=n<1286)for n,js in means):ghostbad.append(at)
     background=bool(means)
     if(label!='S0'or background)and any(js for n,js in w if n>=1319):internalbad.append(at)
    else:mixed[w]=c
   bad=bool(forbidden_source or degreebad or scalarbad or Ja_jets or pairdiff or bosonbad or ghostbad or internalbad or mixed);artifact=dict(parent=label,full_parent_density=J.encode(P),full_ordinary_T_k_T_h=J.encode(H),full_LEFT_T_k_T_h=J.encode(peer),complete_canonical_h_normal_Hessian=J.encode(canonical),four_Hessian_IBP_currents=[J.encode(q)for q in ibp],complete_same_h_Hessian=J.encode(same),quadratic_Taylor_half=J.encode(a.sc(same,J.constant(Fr(1,2)))),forbidden_source_word_indices=forbidden_source,joint_B_Ja_degree_counterexamples=degreebad,scalar_port_word_indices=scalarbad,Ja_jet_word_indices=Ja_jets,complete_mean_B_part=J.encode(Bpart),complete_mean_Ja_part=J.encode(Jap),all45_full_Ja_cofactors=paircof,complete_same_port_B_reconstruction=J.encode(expectedB),complete_pairing_difference=J.encode(pairdiff),complete_ghost_zero_Hessian=J.encode(ghostzero),complete_bosonic_block=J.encode(boson),complete_ghost_block=J.encode(ghost),complete_mixed_block=J.encode(mixed),bosonic_mean_or_source_counterexamples=bosonbad,ghost_affinity_or_species_counterexamples=ghostbad,ghost_internal_derivative_counterexamples=internalbad,hidden_ghost_mean_Hessian=J.encode({w:c for w,c in H.items()if w not in ghostzero}));ref=save(role+'_'+label+'_hessian_support.json.gz',artifact);outputs.append(artifact);rows.append(dict(parent=label,artifact=ref,full_Hessian_words=len(H),ghost_zero_words=len(ghostzero),hidden_ghost_words=len(H)-len(ghostzero),all_support_and_pairing_gates_pass=not bad));print('STAGE '+role+' '+label+' fullH='+str(len(H))+' support_pass='+str(not bad),flush=True)
  q0bad=[];q0Ja=[]
  for n in range(643):
   expected=p.atom(553+n//4,(n%4,))if n<180 else a.sc(p.atom(508+n-598),J.I)if n>=598 else{}
   if J.decode(states['F0'][n])!=expected:q0bad.append(n)
  for bb in range(45):
   P=a.neg(J.decode(states['E0'][598+bb]));bad=[at for at,(w,c)in enumerate(sorted(P.items()))if any(n<180 or 1241<=n<1286 for n,js in w)];q0Ja.append(dict(port=1241+bb,complete_map=J.encode(P),B_Ja_counterexamples=bad))
  qprobes=[]
  for pr in[0,1]:
   F=dict(states['Fu0_'+str(pr)]);outside=[n for n in range(598)if F[n]];blocks=[]
   for aa in range(45):
    P=J.decode(F[598+aa]);W={};S={};rejected=[]
    for at,(w,c)in enumerate(sorted(P.items())):
     if len(w)==1:
      n,js=w[0]
      if n<180 and js==(n%4,):W[n//4,n%4]=c;continue
      if 1241<=n<1286 and not js:S[n-1241]=c;continue
     rejected.append(at)
    residual=[[bb,mu,A.encode_coeff(W.get((bb,mu),zero)+S.get(bb,zero))]for bb in range(45)for mu in range(4)];blocks.append(dict(port=598+aa,complete_map=J.encode(P),all180_W_plus_S_coefficients=residual,rejected_raw_indices=rejected))
   qprobes.append(dict(probe=pr,non_a_field_counterexamples=outside,all45_a_blocks=blocks))
  maps=dict(all643_Q0_field_counterexamples=q0bad,all45_full_Q0Ja=q0Ja,probes=qprobes);ref=save(role+'_full_required_maps.json.gz',maps);outputs.append(maps);mapok=not q0bad and not any(z['B_Ja_counterexamples']for z in q0Ja)and all(not q['non_a_field_counterexamples']and not any(cells for row in q['all45_a_blocks']for bb,mu,cells in row['all180_W_plus_S_coefficients'])for q in qprobes);summaries.append(dict(role=role,parents=rows,maps=ref,all_required_map_gates_pass=mapok));alloutputs.append(outputs);del old,states;gc.collect()
 for i in range(3):assert alloutputs[0][i]['complete_canonical_h_normal_Hessian']==alloutputs[1][i]['complete_canonical_h_normal_Hessian'],'CANONICAL_NATIVE_REPLAY_HESSIAN_DIFFERENCE'
 assert alloutputs[0][1:]==alloutputs[1][1:],'COMPLETE_PROBE_OR_MAP_NATIVE_REPLAY_DIFFERENCE'
 passed=not endpointbad and all(q['all_required_map_gates_pass']and all(z['all_support_and_pairing_gates_pass']for z in q['parents'])for q in summaries);out=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',roles=summaries,R_endpoint_artifact=endpointref,R_endpoint_gates_pass=not endpointbad,all_structural_premises_pass=passed,canonical_native_replay_Hessians_and_complete_probe_maps_equal=True,original_free_ghost_density_representatives_retained_separately=True,no_quantum_trace_value_projection_or_reference_theorem_qualified=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
