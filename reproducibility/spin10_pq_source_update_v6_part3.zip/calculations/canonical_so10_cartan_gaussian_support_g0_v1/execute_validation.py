from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/cartan-gaussian-support-g0-v1-2026-11-08');digest=lambda q:sha256(q.read_bytes()).hexdigest()
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert not(O/'preparation_validation.json').exists();old=json.loads((O/'preparation.json').read_bytes())
for n,h in old['sha256'].items():assert digest(R/n)==h,n
names=[]
for folder,files in[('canonical_so10_proper_slavnov_source_chain_g1_v1',['PROOF.md','RECORD.md','validation_receipt.json']),('canonical_so10_absolute_marked_quantum_g0_recovery_v1',['RECORD.md','PROOF.md','validation_receipt.json']),('canonical_so10_Ward_primitive_canonical',['PROOF.md','final_review_validation_receipt.json']),('canonical_so10_regulator_free_inverse_g1_recovery_v1',['PROOF.md','validation_receipt.json','native_inverse.json.gz','replay_inverse.json.gz']),('canonical_so10_cartan_generator_residual_g1_v1',['final_review_v4.py'])]:
 names+=['calculations/'+folder+'/'+n for n in files]
for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
for n in['PROOF.md','RESULT.md','FINAL_RECORD.md','compute_validation.py','execute_validation.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
bindings={**old['sha256'],**{n:digest(R/n)for n in names},**{q.relative_to(R).as_posix():digest(q)for q in O.iterdir()if q.is_file()},**{n:digest(R/n)for n in['README.md','docs/RESEARCH_EXECUTION_HANDOFF_V837.md']}};prep=dict(base_HEAD=old['base_HEAD'],sha256=bindings,scientific_acceptance='NOT_PERFORMED');dump(O/'preparation_validation.json',prep);dump(C/'preparation_validation.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute_validation.py')]);dump(O/'capture_validation.json',cap);dump(C/'capture_validation.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
