# Finite proper Cartan projection: proof and boundary

Claim CGS-FINITE-PI-1 concerns the previously declared643-field Euclidean
proper one-loop Gaussian prescription, at finite common cutoff and each
fixed finite Taylor/auxiliary degree about A0. Sources are differentiated
before restriction. Epsilon is local, rho constant odd and LEFT ordered.
There are no inverse mean fields or resummed-background assumptions.
This is an analytic/computational argument using qualified exact algebra,
not a proof-assistant theorem or a physical measure construction.

## The actual finite parent and its insertion

Use S=S0+gS1+uU0+guU1 and the actual +rho KD parent. The bound V801 proper
derivative identities apply with a mean/source-independent regulator matrix
and fixed reference determinant. V791 supplies that actual free regulator
matrix in all643 coordinates; its heat/IR profiles and reference masses
are fixed parameters, not mean fields or BV sources. Iota does not vary them.
The full regulator density may vary affinely; it is NOT discarded in a
connected or whole-product identity. This proof concerns the proper Gaussian.

Even Taylor variations commute with the constant-coefficient evolutionary
iota. V801's LEFT derivative identities and the actual kappa signs give

    iota Gamma1 = <T²(iota S)/2>.

CGR's full-source identity is KD=iota S+R and D={Q,iota}+XR, through every
retained g/u coefficient, without assuming Q²=0. Linearity of the actual
rho-left insertion in the SAME regulated parent therefore gives

    I_D1 = iota Gamma1 + I_R1,     I_R1=<T²R/2>,
    M_D1 := D Gamma1-Q I_D1
          = iota(Q Gamma1)+XR Gamma1-Q I_R1.

The nonzero R Hessian remains present. R=g Rg only; its0,u,gu coefficients
are0. The selected coefficient is consequently

    [M_D1]gu = [iota(Q Gamma1)]gu + XRg Gamma_u
               -Q0 I_R,gu -Qu0 I_R,g.

No missing coefficient has been defined to satisfy this equation. I_R,g and
I_R,gu are the actual Gaussian insertions of the new R ghost-pair root.
The old WPC57 coefficients are not substituted for their unknown values.

## A representation-independent defect of paired kernels

Keep all external points/momenta independent, including epsilon momentum.
A common arbitrary kernel K multiplying

    epsilon_r(z) C_c(y) [divB_b(x)-Ja_b(x)]

has opposite divB and Ja coefficients at the SAME x leg. Displayed derivative
placements alone do NOT define a projection of nonlocal functionals: kernel
IBP moves derivatives onto K. Instead take full FUNCTIONAL Euler derivatives
and define the selected kernel defect

    L_mu F = E_B_mu F - partial_mu E_Ja F,
    Pi_pair F = -Alt_(b,c) [L_mu F]_(epsilon_r C_c).

The brackets retain the complete external epsilon/C kernel, with independent
momenta and a fixed common LEFT order. Functional derivatives, including all
kernel derivatives, make this definition invariant under density IBP. For
the displayed paired subspace E_B=-partial_x(K epsilon C), E_Ja=-K epsilon C,
so L_mu=0 before antisymmetrization. No loop-momentum shift or separate
subtraction is used. Derivatives of the common leg preserve that equality.

For a LOCAL one-jet C-before-epsilon representative U divB*C*epsilon +
V B*partialC*epsilon +S Ja*C*epsilon, the partialC*epsilon coefficient of
-L_mu is U-V+S. That coefficient of Pi_pair is V835's Pi. The other local
epsilon-derivative coefficient is retained separately, not conflated with Pi.
This does NOT extend the whole local-insertion theorem to arbitrary nonlocal
functionals. It proves a stronger Euler-kernel defect0 for a specific paired
subspace, then identifies the local coefficient consequence.

## Gaussian support and the three projected terms

CGS-A checks the complete sourceful GF/probe Hessians before ghost means0,
including2400 original and61536 broken-probe hidden-ghost words. The original
Hessian has no B/Ja/BV-source dependence. Its physical scalar block remains
separate; scalar potentials are not set0. The physical gauge g0 block is
quadratic, and GF/probes have no scalar means/polarizations. The qualified
g0 physical support therefore preserves these properties for the relevant
full inverse. The same support excludes any extra chiral/matter assertion.

U0'' has JOINT B+Ja degree<=1, no other BV source, and a complete same-leg
Ja -> -divB pairing in every polarization block and source column. Taking
the formal inverse of H0 cannot introduce absent B/Ja/source factors. One
U0'' response in I_R,gu preserves its joint bound. All these statements are
coefficientwise at fixed finite Taylor degree, without evaluating a trace.

1. For Q0 I_R,gu, QB=partial C and full QJa have no B/Ja. Their operations
remove the only such factor, so cannot leave a target B/Ja. Qa=iLambda
leaves a target-forbidden auxiliary factor; QC=QLambda=0. Remaining hidden
ghost coefficients and source derivatives are retained, not declared0.
Thus Pi_pair(Q0 I_R,gu)=0.

2. I_R,g has no B/Ja/BV source, but CAN have hidden aC terms. Probe field
operations except a vanish. Only the coefficient linear in a and C can
reach the selected target. Its a variation supplies actual Qu0a's divB/Ja
partners at the same port with opposite coefficients and the same arbitrary
kernel. Final validation must additionally check that the complete remaining
Qu0a map has no other B/Ja term. This gives a paired response, generally
nonzero as a functional, with Pi_pair(Qu0 I_R,g)=0. Jets commute with the
same substitution; epsilon is never replaced by a constant.

3. XRg acts only on Lambda,Ja,JC. Its Lambda/Ja coefficients are local
epsilon C with no jets or B/Ja. Their target therefore uses Gamma_u's
zero-ordinary-ghost sector AFTER source differentiation. There the bosonic
response is constant. The ghost response can have arbitrary formal Lambda
dependence but is jointly at most linear in B/Ja, with those partners paired.
Lambda differentiation preserves that pairing; Ja
differentiation removes the sole Ja and leaves no B/Ja target. The JC
derivative is0 by the full g0 parent-Hessian source absence, not by setting
JC0 early. The affine XR source endpoint is retained until this argument.
No relation between the separate Lambda coefficient and the B/Ja pair is
assumed. Hence Pi_pair(XRg Gamma_u)=0.

Combining these three results gives the FINITE proper identity

    Pi_pair [M_D1]gu = Pi_pair [iota(Q Gamma1)]gu.

The new R insertion has a nonzero Hessian and need not have zero amplitude.
Its full contribution is not discarded; only this paired projection is0.

## Reference and scientific ceiling

This is not the separately normalized UV finite-part/IR reference identity.
Common-parent subtractions, marked insertion mixing, contact products,
connected/mean terms and ordered Schwartz UV/IR limits require their own
applicability/continuity proofs. WPC's g0 limit does not supply arbitrary g1
transport. The finite theorem identifies an economical quantum dependency;
it neither supplies an unmeasured unmarked coefficient nor establishes a
common counterterm/insertion module or complete restoration. Authority34/39,
E5/A5, physical viability and seven custody NOTPASS remain unchanged.

Shared action, chart, reference, algebra and AI authorship limit independence.
The local/raw and nonlocal/paired statements are deliberately distinguished.
