# CGS final finite-proof and evidence validation

Freeze primary sources/captures and PROOF/RESULT/V837/README plus this record
and new execute_validation.py/compute_validation.py BEFORE validation.
Validate the59.221s primary capture and complete classical input support,
both roles, full ordinary Hessians, explicit h-normal IBP currents, source/
JOINT B+Ja/scalar exclusions and all same-spacetime-leg partner identities.
Recompute selected polynomial derivatives with plain Fraction odd-sign/slot
arithmetic, no fitted coefficients; retain original free-ghost IBP differences.

Add the explicit remaining-map gate needed by PROOF: every rejected Qu0a
word has no B/Ja. Check full actual source maps/endpoint shapes, and original
and probe parent-Hessian JC absence before restriction. Calibrate Pi_pair on
the local U-V+S definition using a formal arbitrary common-kernel label,
independent color/leg labels and all4 Lorentz directions. Use the IBP-invariant
Euler defect E_B-partial E_Ja, not displayed U/V placement. A zero-functional
kernel-divergence control must give0 after its kernel derivative is retained;
dropping that derivative must fail. Wrong Ja sign and independent-kernel
replacements must be sensitive in an antisymmetric color
channel. This is a small proof control, not a benchmark platform or a model
amplitude. Check actual broken-probe partner omission is nonzero; report
unbroken controls honestly. Do not integrate or assign any new quantum trace.

Bind V801 proper derivative/LEFT conventions, literal +rhoKD owner/WPC
calibration and actual V791 fixed regulator matrix. Analytic review must
separate the finite paired-projection theorem from reference/contact/mean/
UVIR transport; no claim about the latter is accepted. No master-flatness,
constant epsilon, missing physical Euler0 or hatted-source-fixed derivative.

Check old HEAD/tree, exact historical README suffix/current links and unchanged
state. E4 once using fixed D: context/no fresh, expected0,0,0,0,0,2 and exactly7
custody NOTPASS. One180-second final worker after imports,8GiB sampled private/
350MiB floor,32MiB packet/8MiB file. Full capture/receipt repo+D. Preserve any
failure/incomplete source and evidence, no weakening or silent retry. Validate
all staged bytes before a local commit; no remote action or promotion.
