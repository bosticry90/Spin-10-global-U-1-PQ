# CGS-A: full Gaussian support before new quantum coefficients

Continue V836/7feb8f261ca86646664326b99cc233fa7896e0fb, main,D:.
Goal ACTIVE; state113/34of39 unchanged. Live AGENTS, charter, epistemic/solo
review and computational-authority policies apply. Root owns writes and one
worker at a time; AI reviewers read only. No branch/worktree, protected
activation/promotion, adoption, publication, remote action or spending.

Physics decision enabled: can the actual Cartan remainder contribute to the
remaining marked projection through the finite g0 Gaussian/probe parent?
Current blocker removed: unqualified full-source/hidden-ghost support premises
for Q0 I_R,gu, Qu0 I_R,g and XRg Gamma_u, before new color traces/integrals.
Why existing tools are insufficient: existing Taylor and WPC algebra suffice,
but no qualified record checks ALL these support/pairing premises for the
new NONZERO-Hessian R. Reuse those tools, not a new engine or benchmark.
Minimum new implementation surface: one complete Hessian/support classifier
and frozen capture wrapper. No loop coefficient, fit or physical parameter.
Structure-preservation obligations: same source chart and full sourceful
parents, original643 ordinary fields, fixed sources/local epsilon, intrinsic
01, actual even Taylor/odd Q conventions. No source restriction before Euler
or Hessian operations. Preserve all zeros and counterexamples.
Stopping condition: complete premises PASS, an exact failed premise, or
bounded incomplete evidence; no automatic quantum or reference conclusion.
What will be deleted or deactivated if this does not work: delete nothing;
deactivate the proposed zero-projection shortcut and retain all failures.

Use both current g0 S_GF and full sourceful U_H/U_M parents already owned by
V830/V836. Compute complete ordinary T_k T_h, T_h² and independent LEFT/front
Taylor Hessians, sources fixed, before any ghost-mean restriction. Save full
results. Original S0 kinetic representatives differ by an explicit ordinary
divergence; compare their complete h-normal Hessians with all four retained
IBP currents, not an unjustified raw-density equality. Full probe/map records
must agree as written; preserve both original free-ghost representatives.
Check S_GF'' is independent of mean B/Ja and ALL BV sources; retain its
Lambda,a,C dependence. Check U'' has JOINT mean B+Ja degree<=1, not separate
degree bounds, and no JB/JLambda/JC/Jx. Save every unexpected word.

For EVERY polarization block and source leg, reconstruct the entire mean-B
part of U'' from its complete mean-Ja part by Ja_b -> -divB_b. Compare all
four Lorentz directions, ordinary jets and hidden ghost coefficients. Do not
infer this pairing from one color trace or only from the zero-source plane.

Record the zero-ordinary-ghost Hessian blocks separately: bosonic block must
be independent of ordinary means; ghost block uses only C/a polarizations
and is affine in Lambda/B/Ja. Probe and background-dependent original ghost
blocks have no internal ghost-polarization derivatives; retain the original
free ghost kinetic derivatives explicitly.
Keep full-parent hidden a/C terms. They can feed Qu0I_R,g through actual
Qu0a, so do NOT infer Qu0I_R,g=0 from a ghost-zero restriction.

Check actual Q0 sourceful Ja maps contain no B/Ja; QB=partial C, Qa=iLambda,
QC=QLambda=0. Check all g0 probe field maps except a vanish, and every linear
divB/Ja coefficient of Qu0a obeys W+S=0 at the SAME field/color port. Save full
maps and rejected indices. Bind the actual R Hamiltonian support (Lambda,
Ja,JC) and factorization; no endpoint is silently dropped.

Physical scalar/matter potentials are not set0. Their g0 blocks are independent
of nonminimal variables/B/Ja and decouple from these probe/R ports by the
qualified physical/CPS support arguments. Check GF/probe full Hessians have
no scalar means/polarizations. A failed check stops that applicability claim.

One180-second worker after imports,8GiB sampled private/350MiB launch floor,
32MiB packet/8MiB file. Freeze input/source/live-policy bytes before execution.
Complete overflow preserved D: before NOTPASS; full capture repo+D. No E4,
quantum insertion/reference acceptance or commit in this worker. Distinct
construction shares action/chart/software/AI authorship and is not empirical
validation. Final proof/validation is a separately frozen phase.

Any later projection theorem must explicitly extend Pi to paired arbitrary
nonlocal kernels with the SAME B/Ja spacetime leg and independent external
momenta. V835's local insertion theorem alone does not justify that extension.
Common-reference/contact/mean and ordered UV/IR transport remain separate.
