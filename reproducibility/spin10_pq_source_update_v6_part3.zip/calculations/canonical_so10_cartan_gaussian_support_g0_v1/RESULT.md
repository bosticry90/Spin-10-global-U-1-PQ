# Finite paired projection of the Cartan remainder

The full Gaussian support calculation completed59.221s. Both sourceful
constructions satisfy the required support and same-leg pairing tests.
Their ordered Hessians have4365 original,300 H-probe and69561 M-probe
words. The2400 original and61536 M hidden-ghost words remain present.
Original kinetic representatives are compared with explicit IBP currents;
the complete probe and source-map records agree without that adjustment.

The [proof](PROOF.md) keeps the actual NONZERO R Hessian and its quantum
insertion. In the SAME finite proper +rhoKD parent it gives

    I_D1=iota Gamma1+I_R1,
    M_D1=iota(Q Gamma1)+XR Gamma1-Q I_R1.

The source/ghost support and exact same-spacetime-leg B/Ja pairing then
eliminate the R terms only from the selected paired-kernel projection:

    Pi_pair[M_D1]gu = Pi_pair[iota(Q Gamma1)]gu.

This does not declare the insertion amplitude or its full variation0. In
particular hidden aC terms can feed Qu0 I_R,g; their generally nonzero
responses have opposite B/Ja coefficients with the SAME arbitrary kernel.
Pi_pair uses the complete Euler defect E_B-partial E_Ja, so kernel integration
by parts cannot change it. The argument precedes momentum integration and
keeps epsilon momentum. V835 Pi is obtained from its local partialC*epsilon
coefficient; the other epsilon-derivative coefficient remains distinct.

Final validation/receipt governs qualification of the analytic finite
proof and its additional map/control checks. No new loop trace coefficient
has been computed, assigned or fitted. The renormalized reference, insertion
mixing, contact/mean products and ordered UV/IR transport remain withheld.

This is useful scientific economy: it tests a newly identified quantum
dependency through its complete structural inputs before expanding another
g1 loop inventory. The next question is the unmarked profiles selected by
iota, especially the unqualified Ja²C term, and applicability of the SAME
reference prescription. A named empty catalog is not a proper quantum zero.

Common restoration, complete admissible module, E5/A5 and physical viability
remain open. Authority34/39/state113 and seven custody NOTPASS are unchanged.
Shared action, source conventions, software and AI authorship limit support;
this is internal analytic/computational evidence, not empirical validation.
The independent C: snapshot remains a point-in-time backup through V835,
not an automatic backup of this later work.
