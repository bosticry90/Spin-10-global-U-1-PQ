"""Compare canonical ghost replacement with two literal off-orbit rows."""

import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


def load_owner(name, file):
    path = ROOT / "calculations" / ("canonical_so10_" + name) / file
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


source = load_owner("joint_nonlinear_source_span_v2", "joint_nonlinear.py")
free = load_owner("linear_nonminimal_transport_v1", "nonminimal_transport.py")
seagull = source.seagull


def exact_off_orbit_rows(phase):
    v_all, entries, rho, f, K, ghosts = source.owner.inputs(phase)
    vacuum = {i: z for i, z in v_all.items() if i < 54}
    orbit = {a: seagull.apply(rho[a], vacuum) for a in range(45)}
    rows = []
    for j, c, i, b in ((17, 23, 41, 20), (21, 20, 40, 23)):
        # Arbitrary scalar maps, gauge fermion and both auxiliary shifts
        # have zero coefficient at this row. Test the full support.
        assert not f[j, c]
        assert not seagull.apply(rho[c], orbit[j])
        assert all(row != i for row, _ in entries[c])
        assert all(i not in vector for vector in orbit.values())

        raw = source.raw_null_row(rho, K, ghosts, orbit, vacuum, {j: 1}, c)
        assert raw[i] == -sp.sqrt(2)/2
        alternative = source.owner.act(rho, K[c], orbit[j])
        assert alternative.get(i) == sp.sqrt(2)/2
        # Only one entry in the common ghost map can hit this target.
        hits = {}
        for a in range(45):
            z = seagull.apply(rho[a], orbit[j]).get(i, 0)
            if z:
                hits[a] = z
        assert hits == {b: -5*sp.sqrt(2)/2}
        rows.append({"a": j, "C": c, "x": i, "ghost_map_row": b,
                     "target": str(raw[i]), "response": str(hits[b]),
                     "ratio": str(sp.cancel(raw[i]/hits[b]))})

    eps, k = sp.symbols("epsilon_Phi k")
    residuals = (k-eps/5, -k-eps/5)
    assert sp.solve(residuals, (k, eps)) == {k: 0, eps: 0}
    assert sp.solve(residuals[0], k) == [eps/5]
    return rows


def free_and_triangular_controls(phase):
    literal = free.check_free(phase)["free"]
    # Check the homogeneous free equations entry by entry for each
    # transpose pair in a two-dimensional color plane.
    K, A, L, U = (sp.Matrix(2, 2, sp.symbols(f"{name}:4"))
                  for name in ("K", "A", "L", "U"))
    coupled = tuple(A.T+K) + tuple(L-A) + tuple(L.T+U)
    variables = tuple(A)+tuple(L)+tuple(U)
    solution, = sp.solve(coupled, variables, dict=True)
    assert U.subs(solution) == K
    maxwell = (U+U.T).subs(solution)
    assert maxwell == K+K.T
    # Isolate the selected scalar companion in the literal Wick chart.
    folder = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    mix = {}
    for g, word, cells in rows:
        if g != 1 or len(word) != 2:
            continue
        (i, di), (j, dj) = word
        if 180 <= i < 508 and 508 <= j < 553:
            assert not di and not dj
            mix[i-180, j-508] = seagull.unpack([([0, 0, 0, mask], n, d)
                                                for (xi, eta, mask), n, d in cells
                                                if (xi, eta) == (1, 0)])
            assert all(p[:2] == [1, 0] for p, _, _ in cells)
    v_all, _, rho, _, _, _ = source.owner.inputs(phase)
    expected = {(i, j): sp.I*z for j in range(45)
                for i, z in seagull.apply(rho[j], v_all).items()}
    assert mix == expected and len(mix) == 296
    # qa = i Lambda, and q(P(C)a)|_Lambda = -i P(C)Lambda.
    # The induced Lambda driver is the opposite of that coefficient.
    p = sp.Symbol("P")
    q_shift = -sp.I*p
    source_shift = -q_shift
    assert sp.I*q_shift == p
    assert sp.I*source_shift == -p
    return {"literal_free_rows": literal["literal_rows"],
            "literal_scalar_mixing_rows": len(mix),
            "canonical_scalar_pair_coefficient": ["1", "-1"],
            "canonical_free_ghost_matrix_is_skew": True}


def check(phase):
    return {"off_orbit_rows": exact_off_orbit_rows(phase),
            "controls": free_and_triangular_controls(phase)}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
