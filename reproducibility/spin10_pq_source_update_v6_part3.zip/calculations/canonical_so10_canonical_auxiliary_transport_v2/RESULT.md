# V932 result — auxiliary transport and reciprocal ghost weights

A complete canonical auxiliary shift cancels its own selected
Lambda x C response. The induced source driver and the ordinary
scalar-mixing partner give equal and opposite terms. The replay
checks the phase of all 296 inherited scalar mixing rows and the
618 declared free current rows. Dropping the ordinary partner
retains the isolated source response and breaks the canonical
pair, with a linked variation that must enter the other equations.

For the broader canonical replacement test, the literal
Phi rows (a17,C23,x41) and (a21,C20,x40) each require a
nonzero common ghost response of the same sign. Their target
is -sqrt(2)/2 in the common stripped units. Each permitted
ghost entry has response -5 sqrt(2)/2, so the reciprocal
entries both require epsilon_Phi/5 under the stated convention.
Other displayed canonical terms vanish in these two projections.
Keeping the ordinary free ghost and mixed terms, linear Qa and
the transverse Maxwell form makes the common ghost map skew.
The two rows exclude the replacement on the symbolic log
family. The special Phi-zero scale is outside this exclusion.

The first run reached the two literal rows and stopped on the
shape of a SymPy one-equation control. Its full failed packet is
preserved on D:. The rerun corrects the control call and repeats
the scientific criteria. The literal and algebraic calculations
share the model, symbolic software and AI authorship.

A source change that transports the free Qa normalization or
a noncanonical partial ordinary companion has separate equations.
The next test should identify its linked scalar and nonminimal
master coefficients before further loop expansion. This result
does not decide the complete geometric or causal Ward problem.
