# V932 pre-execution contract

Test the canonical transport suggested by V931 at the unprobed
unit switch. Freeze the V879 literal current, V928 forced ghost
companion, V929 residual sign, V930 free normalization and V931
shared auxiliary span. Allow block scalar linear redefinitions,
linear color maps on gauge and nonminimal fields and the common
ghost, linear and aC auxiliary shifts, their source duals, and
a scalar-linear gauge fermion. Keep the homogeneous free ghost
and mixed gauge terms, linear Qa and transverse Maxwell symbol.

Check the mixed auxiliary-scalar coefficient against every
literal row and the triangular source versus ordinary companion
in the inherited Wick chart. Test two predeclared off-orbit Phi
rows for reciprocal common ghost weights. Require a nonzero
target, exact support exclusions and replay. The question is
canonical replacement in this family on the symbolic logarithmic
domain. A Phi-zero scale, other grades and noncanonical
companions are separate questions. No change in authority.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.

V1 reached both literal witnesses and failed on the return shape of
a one-equation SymPy sensitivity control. V2 passes the single
expression to the scalar solve. The exact V1 packet and failure
capture are preserved in the V1 D: control directory.
