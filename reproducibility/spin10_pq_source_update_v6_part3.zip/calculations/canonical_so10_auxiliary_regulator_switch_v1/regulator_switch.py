"""Verify the literal regulated auxiliary switch companion."""

import gzip
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def actual_rows(phase):
    name = "native" if phase == "native" else "replay"
    path = ROOT / "calculations/canonical_so10_regulator_free_inverse_g1_recovery_v1"
    with gzip.open(path / f"{name}_inverse.json.gz") as stream:
        data = json.load(stream)
    keys = ("Pphysical","Preference","full_regulator","reference_defect")
    matrices = {key:{(i,j):value for i,j,value in data[key]} for key in keys}
    E, f = sp.symbols("E_profile f_profile")
    q = sp.symbols("q0:4")
    count = 0
    for color in range(12,45):
        for axis, momentum in enumerate(q):
            B, aux = 4*color+axis,508+color
            for key, value in (((B,aux),momentum),((aux,B),-momentum)):
                assert key not in matrices["reference_defect"]
                assert sp.sympify(matrices["Pphysical"][key]) == value
                assert sp.sympify(matrices["Preference"][key]) == value
                observed = sp.sympify(matrices["full_regulator"][key])
                assert sp.cancel(observed-value*(1/(E*f)-1)) == 0
                count += 1
    return count


def profile_comparison():
    E, f, F_v, F_gh, s, ds, Q = sp.symbols("E f F_v F_gh s ds Q")
    F_u = E*f
    w2 = F_v*F_gh
    w3 = F_u*w2
    exact = sp.cancel((1/F_u-1)*w3)
    assert sp.expand(exact-(w2-w3)) == 0
    heat_only = sp.cancel((1/E-1)*w3)
    assert sp.expand(exact-heat_only-(1-f)*w2) == 0
    proper = s**2*ds*Q*(w2-(1-s)*w3)
    regulator = -s**2*ds*Q*exact
    total = sp.expand(proper+regulator)
    assert total == s**3*ds*Q*w3
    assert sp.expand(proper-s**3*ds*Q*w3).coeff(s,2) != 0
    assert sp.expand(proper-s**2*ds*Q*heat_only).coeff(s,2) != 0
    pivot = {s:sp.Rational(1,2), E:sp.Rational(3,4), f:sp.Rational(2,3),
             F_v:sp.Rational(4,5), F_gh:sp.Rational(3,5), Q:1, ds:1}
    assert regulator.subs(pivot) == -sp.Rational(3,50)
    assert total.subs(pivot) == sp.Rational(3,100)


def check(phase):
    count = actual_rows(phase)
    profile_comparison()
    return {"actual_mixed_regulator_rows":count, "vanishing_M_reference_defect":True,
            "profile":"(1-F_u) F_v F_ghost",
            "auxiliary_s2_coefficient_with_regulator":0,
            "remaining_auxiliary_coefficient":"s^3 ds QLambda w3",
            "heat_only_negative_control":True}


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
