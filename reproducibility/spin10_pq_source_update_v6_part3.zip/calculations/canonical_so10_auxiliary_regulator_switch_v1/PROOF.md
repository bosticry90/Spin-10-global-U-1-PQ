# Auxiliary regulator companion of the first-switch gauge equation

Work with the V967 transverse M-sector auxiliary
insertion, zero background and zero broken width.
At finite positive cutoffs the switched Gaussian
uses the fixed flat regulator R of V791. In this
block P_ref=P_phys and R=(F^{-1}-1)P_ref with
F=fE. The two separate IR and heat defects remain.
The action dependence is that of P+R, with R
source independent. The source-first master
variation of R is sum_i F_{P,i} E_{R,i} with the
same signed source column as B[P]. Thus the
q_Lambda grade-two term has s, without the
additional (1-s) of the compact reference root.

In the proper comparison the regulator insertion
uses its connected mean subtraction. For this
auxiliary term that subtracts the product with
the mean of B. There is no exterior B in J_B CC,
so that product contributes zero in this selected
projection. The term with E_{R,Lambda} on the
returning B edge survives. A single quadratic
switch is needed: the direct free ordinary BB
edge is transverse. The differentiated insertion
is exactly the same V967 inverse projection, with
the left divergence multiplied by (F_u^{-1}-1).
Its sign relative to the explicit compact current
is the V967 opposite inverse sign.

Before integrating, write w2's profile factor as
F_v F_ghost and w3's as F_u F_v F_ghost. The
regulator insertion on the collapsed leg supplies

    (F_u^{-1}-1) F_u F_v F_ghost
      = (1-F_u) F_v F_ghost.

There is already one switch momentum, so no
profile derivative enters this first jet. The
whole profile factor is 1-F_u, including the
IR term 1-f_u. Dropping that IR term leaves
a difference at finite cutoffs. This comparison
keeps nonexceptional gauge and ghost transfers
as in V947.

In the insertion side of the master comparison
the signed regulator contribution is

    -s² (partial s) Q_Lambda (w2-w3).

Adding it to V967's
s²(partial s) Q_Lambda [w2-(1-s)w3] gives

    s³ (partial s) Q_Lambda w3.

The cancellation occurs before the common
finite part. It also cancels the finite relative
heat-length term in the s² coefficient, without
a change to either heat length or a fitted
finite normalization. The regulator contribution
itself has a nonzero ordered limit in the chosen
nonexceptional units. The independent auxiliary
condition of V968 therefore constrains the
proper-only expression; this actual regulator
companion removes it from the selected modified
comparison. The ordinary rank-two condition and
the s³ term have separate obligations.

The executable binds both orientations of every
M mixed regulator row to the actual V791 matrices,
checks that the M reference defect vanishes there,
and tests the finite profile algebra. This is one
bare regulator response in the fixed-flat proper
construction. Other regulator drivers, induced
finite contacts, compact source/ordinary/marked
products and the joint removal and normalization
conditions are not inferred. General modified
Slavnov–Taylor identities provide context but do
not supply this model-specific contraction.
[Ellwanger, regulated Slavnov–Taylor identity](https://arxiv.org/abs/hep-th/9402077)
Both input routes share the model and software.
