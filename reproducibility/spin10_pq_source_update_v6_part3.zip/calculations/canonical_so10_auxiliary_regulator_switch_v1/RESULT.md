# V969 · Auxiliary regulator switch companion

The actual quadratic regulator contributes
`−s²(∂s) Q_Lambda (w2−w3)` in the selected
transverse auxiliary-source insertion. The
factor `1−F` comes from the regulator Euler
multiplying the extra collapsed profile. It
retains the infrared part as well as heat.

With the V967 terms included, the coefficient
is `s³(∂s) Q_Lambda w3` already at fixed
cutoffs. Thus the independent auxiliary
`s²∂s` condition of the proper-only V968 test
is absent in this modified comparison. The
ordinary rank-two condition and the remaining
`s³∂s` term still require comparison.

Both exports verify 264 directed mixed
regulator rows. No finite shift was chosen.

[Proof](PROOF.md) · [Validation receipt](validation_receipt.json)
