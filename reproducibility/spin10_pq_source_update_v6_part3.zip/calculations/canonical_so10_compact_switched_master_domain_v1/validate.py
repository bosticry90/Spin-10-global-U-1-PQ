"""Separate replay of the compact switched evidence and local E4 audit."""

from fractions import Fraction
from hashlib import sha256
from itertools import product
import json
import os
import subprocess
import sys
import threading
import time

import sympy as sp

from check_b_v2 import GEOMETRIC, HERE, INVERSE, ROOT, digest, read
from execute_b_v2 import CONTROL, git, write_pair


def verify_captures():
    cases = {"a": "COMPLETED", "b": "FAILED", "b_v2": "COMPLETED"}
    for phase, outcome in cases.items():
        for prefix in ("preparation", "capture"):
            name = f"{prefix}_{phase}.json"
            assert (HERE / name).read_bytes() == (CONTROL / name).read_bytes()
        report = read(HERE / f"capture_{phase}.json")
        assert report["execution_state"] == outcome
        assert report["post_run_observations_qualified"]
        assert report["calculation_completed"] == (outcome == "COMPLETED")
        assert not report["failed_or_incomplete_counted_as_PASS"]
        if outcome == "FAILED":
            assert "assert not columns[508]" in report["stdout_and_stderr"]
    for frozen in HERE.glob("*.source.txt"):
        source = HERE / frozen.name.removesuffix(".source.txt")
        assert source.read_bytes() == frozen.read_bytes(), source.name


def independent_reference(saved):
    checked = []
    for role in ("native", "replay"):
        packet = read(INVERSE / f"{role}_inverse.json.gz")
        assert packet["Pphysical"] == saved["principal_kernel"]
        difference = []
        for ref, principal in zip(packet["Preference"], packet["Pphysical"], strict=True):
            assert ref[:2] == principal[:2]
            if ref[2] != principal[2]:
                mass, separator, kinetic = ref[2].partition(" + ")
                assert separator and kinetic == principal[2] and ref[0] == ref[1]
                difference.append([ref[0], mass])
        assert difference == saved["scalar_reference_mass_only_differences"]
        assert len(difference) == 328
        reference = {(i, j): expression for i, j, expression in packet["Preference"]}
        route = "primary" if role == "native" else "replay"
        actual = read(GEOMETRIC / f"{route}_complete_geometric_current_source_chart.json.gz")
        rules = dict(actual["all1286_direct_Tq_columns"])
        assert rules[508] == saved["complete_H_auxiliary_T_column"]
        assert len(rules[508]) == 4 and all(row[0] == 1 for row in rules[508])
        witness = []
        for mu in range(4):
            q = sp.Symbol(f"q{mu}")
            ref_symbol = sp.sympify(reference[508, mu])
            variation = [row for row in rules[mu] if row[0] == 0]
            assert variation == saved["actual_H_affine_columns"][mu]
            numerator, denominator = variation[0][2][0][1:]
            momentum_coefficient = sp.expand(ref_symbol * sp.I * q * sp.Rational(numerator, denominator))
            assert momentum_coefficient == -sp.I * q**2
            witness.append(str(momentum_coefficient))
        checked.append({"route": role, "reference_rows": len(reference), "TR_H_Fourier": witness})
    return checked


def independent_switch_checks():
    t = sp.Symbol("t")
    sigma, x, ghost, epsilon, partial_density = [sp.Function(name)(t) for name in ("sigma", "x", "C", "eps", "L_i")]
    d = lambda f, n=1: sp.diff(f, t, n)
    # Coefficients of the left variation, kept in source-first order.
    assert sp.expand(-d(sigma * ghost) + sigma * d(ghost)) == -d(sigma) * ghost
    assert sp.expand(-d(sigma * d(x)) + sigma * d(x, 2)) == -d(sigma) * d(x)
    assert sp.expand(-d(sigma * epsilon) + sigma * d(epsilon)) == -d(sigma) * epsilon
    assert sp.expand(d(sigma * partial_density, 2) - sigma * d(partial_density, 2)) == (
        2 * d(sigma) * d(partial_density) + d(sigma, 2) * partial_density
    )
    for packet in read(HERE / "result_a.json")["roles"]:
        selected = packet["complete_EL_C_reference_cross"]
        actual = {tuple((i, tuple(jets)) for i, jets in word): Fraction(num, den) for word, grade, num, den in selected}
        predicted = {}
        for mu in range(4):
            predicted[((180, ()), (181, (mu, mu)))] = Fraction(1, 2)
            predicted[((180, (mu, mu)), (181, ()))] = -Fraction(1, 2)
        assert actual == predicted
    return {"left_source_product": "-sigma' C", "ordinary_product": "-sigma' x'", "marked_source": "-sigma' eps", "second_jet_leibniz": True, "eight_actual_scalar_rows": True}


def main():
    started = time.perf_counter()
    watch = threading.Timer(180, lambda: os._exit(124))
    watch.daemon = True
    watch.start()
    prep = read(HERE / "preparation_validation.json")
    assert git("rev-parse", "HEAD").decode().strip() == prep["base_HEAD"]
    assert git("ls-tree", "-r", "HEAD") == (CONTROL / "old_git_tree.txt").read_bytes()
    assert not git("diff", "--cached", "--name-only")
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    verify_captures()
    owners = {}
    for name in prep["owner_receipts"]:
        receipt = read(ROOT / name)
        assert receipt["execution_state"] == "COMPLETED", name
        outcome = receipt.get("evidence_validation", receipt.get("scientific_disposition"))
        assert isinstance(outcome, str) and "FAIL" not in outcome, name
        owners[name] = outcome
    result = read(HERE / "result_b_v2.json")
    reference = independent_reference(result["compared_reference"])
    switches = independent_switch_checks()
    grammar = [[budget, credit, mask, budget + credit + sum(bool(mask & (1 << bit)) for bit in range(5))]
               for budget, credit, mask in product(range(5), range(2), range(32)) if not credit or mask & 16]
    assert grammar == result["relaxed_signed_defect_grammar"]
    assert result["ordered_beta_rho_length_two"] == [["BK", -1], ["KB", 1], ["MX", 1], ["XM", 1]]
    print("STAGE independent compact reference, Euler and grade controls checked", flush=True)
    e4 = subprocess.run([sys.executable, "-B", "tools/research_check.py", "e4", "--historical-context",
                         "D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4"],
                        cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=120)
    write_pair("e4_capture.json", {"exit_code": e4.returncode, "stdout": e4.stdout, "stderr": e4.stderr})
    events = [json.loads(line) for line in e4.stdout.splitlines() if line.strip()]
    steps = [event for event in events if event.get("event") == "step_finished"]
    exits = [event["exit_code"] for event in steps]
    assert e4.returncode == 0 and exits == [0, 0, 0, 0, 0, 2]
    custody = next(event for event in steps if event["step"] == "historical_custody")
    assert custody["stdout"].count("RECORDED_DIGEST_UNRESOLVED:") == 7
    historic = git("show", "ef70f255a667b9a81e37b344dc78967ada4ed896:README.md")
    assert sha256(historic).hexdigest() == "4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792"
    assert (ROOT / "README.md").read_bytes().replace(b"\r\n", b"\n").endswith(historic)
    assert digest(ROOT / "project_state.json") == "d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8"
    for name, expected in prep["sha256"].items():
        assert digest(ROOT / name) == expected, name
    paths = [path for path in HERE.iterdir() if path.is_file()]
    assert sum(path.stat().st_size for path in paths) <= 32 * 1024**2
    paths.extend(ROOT / name for name in prep["navigation"])
    write_pair("validation_receipt.json", {
        "execution_state": "COMPLETED",
        "evidence_validation": "PASS_COMPACT_SWITCHED_PROPER_ONE_LOOP_WARD_ADMISSION",
        "scientific_acceptance": "NOT_PERFORMED",
        "base_HEAD": prep["base_HEAD"],
        "state_sha256": digest(ROOT / "project_state.json"),
        "owner_receipts": owners,
        "independent_reference": reference,
        "independent_switch_checks": switches,
        "signed_grade_rows": len(grammar),
        "E4_step_exits": exits,
        "historical_custody": "SEVEN_UNRESOLVED_NOTPASS",
        "files_excluding_pending_receipt_capture": {path.relative_to(ROOT).as_posix(): digest(path) for path in paths},
        "elapsed_after_imports": time.perf_counter() - started,
    })
    watch.cancel()


if __name__ == "__main__":
    main()
