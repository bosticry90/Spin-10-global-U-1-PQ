from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/compact-switched-master-domain-v1-2026-11-08')
def digest(p):return sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='d3d6da41cf4775996c7fb7db4b46dc0679a6e0ef'and not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).strip()
names={'AGENTS.md','CHARTER.md','README.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V867.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md'}
for folder,files in [('canonical_so10_proper_slavnov_actual_operators_g1_v1',['native_inputs.json.gz','replay_inputs.json.gz','validation_receipt.json']),('canonical_so10_regulator_free_inverse_g1_recovery_v1',['native_inverse.json.gz','replay_inverse.json.gz','validation_receipt.json']),('canonical_so10_current_causal_initial_dictionary_v1',['PROOF.md','validation_receipt.json','capture_validation.json'])]:
    names.update('calculations/'+folder+'/'+n for n in files)
for n in ['RECORD.md','cross.py','execute_a.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names.update(q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file())
with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
prep=dict(base_HEAD=head,sha256={n:digest(R/n)for n in sorted(names)},limits=dict(seconds=120,sampled_private_bytes=8*1024**3,packet_bytes=32*1024**2,artifact_bytes=8*1024**2),scientific_acceptance='NOT_PERFORMED');dump(O/'preparation_a.json',prep);dump(C/'preparation_a.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'cross.py')]);dump(O/'capture_a.json',cap);dump(C/'capture_a.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
assert(O/'result_a.json').stat().st_size<=8*1024**2 and sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=32*1024**2
