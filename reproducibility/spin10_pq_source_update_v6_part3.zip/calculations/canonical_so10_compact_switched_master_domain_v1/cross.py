from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
from hashlib import sha256
import json,gzip,time,threading,os
R=Path(__file__).resolve().parents[2];B=R/'calculations';O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def add(out,w,k,v):out[tuple(sorted(w)),k]+=v
def encode(P):return[[[[n,list(j)]for n,j in w],list(k),v.numerator,v.denominator]for(w,k),v in sorted(P.items())if v]
def main():
    tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in read(O/'preparation_a.json')['sha256'].items():assert sha256((R/n).read_bytes()).hexdigest()==h,n
    reports=[];peers=[]
    for role in ['native','replay']:
        packet=load(B/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));states={k:dict(v)for k,v in packet['states'].items()};x=[180,181];ghost=555;rows={}
        for i in x:
            assert all(not states[k][i]for k in ['F0','Fu0_0','Fu0_1','Fu1_0','Fu1_1'])
            rows[i]=[row for row in states['F1'][i]if all(n in x+[ghost]for n,j in row[0])];assert len(rows[i])==1
        matrix={}
        for i,[(word,cs)]in rows.items():
            assert len(word)==2 and all(not j for n,j in word)and word[1][0]==ghost;j=word[0][0];assert i!=j;assert len(cs)==1;key,num,den=cs[0];assert key==[1,0,0,0];matrix[i,j]=F(num,den)
        assert matrix[180,181]==-matrix[181,180] and matrix[180,181]
        inv=load(B/'canonical_so10_regulator_free_inverse_g1_recovery_v1'/(role+'_inverse.json.gz'));ref=[r for r in inv['Preference']if r[0]in x or r[1]in x];assert ref==[[i,i,'Mref_Phi_squared + q0**2 + q1**2 + q2**2 + q3**2']for i in x]
        ghostrow=[r for r in inv['Preference']if r[1]==ghost];assert len(ghostrow)==1 and ghostrow[0][0]==600
        assert all(not [row for row in states[name][600]if all(n in x+[ghost]for n,j in row[0])]for name in ['F0','F1','Fu0_0','Fu0_1','Fu1_0','Fu1_1'])
        direct=defaultdict(F);mass=defaultdict(F);ibp=defaultdict(F);raw=defaultdict(F);normal=defaultdict(F);current=[defaultdict(F)for mu in range(4)];key=(1,0,0,0)
        for(i,j),v in matrix.items():
            add(mass,[(i,()),(j,())],key,v)
            for mu in range(4):
                # Direct E_R=−Box+M. EL_C has plus sign on the scalar prefix.
                add(direct,[(i,(mu,mu)),(j,())],key,-v)
                # Independently vary C in +dC*(rho*x)^t d x.
                add(ibp,[(i,(mu,mu)),(j,())],key,-v);add(ibp,[(i,(mu,)),(j,(mu,))],key,-v)
                add(raw,[(i,(mu,mu)),(j,()),(ghost,())],key,-v)
                add(normal,[(i,(mu,)),(j,()),(ghost,(mu,))],key,v)
                add(current[mu],[(i,(mu,)),(j,()),(ghost,())],key,-v)
        assert not encode(mass)and encode(direct)==encode(ibp)and len(encode(direct))==8
        residual=defaultdict(F,raw)
        for(w,k),v in normal.items():residual[w,k]-=v
        for mu,part in enumerate(current):
            for(w,k),v in part.items():
                for at,(i,j)in enumerate(w):add(residual,w[:at]+((i,tuple(sorted(j+(mu,)))),)+w[at+1:],k,-v)
        assert not encode(residual)
        z=dict(role=role,complete_actual_F1_scalar_rows=[[i,p]for i,p in rows.items()],complete_selected_reference=ref,complete_ghost_reference_column=ghostrow,corresponding_projected_Fa_all6_zero=True,complete_raw_cross_density=encode(raw),complete_IBP_density=encode(normal),complete_EL_C_reference_cross=encode(direct),complete_mass_residual=encode(mass),complete_IBP_Euler=encode(ibp),all_four_explicit_currents=[encode(q)for q in current],switch_factor='sigma*(1-sigma) with sigma locally constant',derivative_switch_only_control_fails=True,not_full_B_sigma_or_trace_domain=True)
        reports.append(z);peers.append({k:v for k,v in z.items()if k!='role'});print('STAGE '+role+' actual_nonzero_scalar_switch_cross_bound',flush=True)
    assert peers[0]==peers[1];result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',phase='A_ACTUAL_SWITCH_CROSS_CONTROL',roles=reports,no_new_loop_integrals=True,elapsed_after_imports=time.perf_counter()-tick)
    with(O/'result_a.json').open('x',encoding='utf-8',newline='\n')as f:json.dump(result,f,sort_keys=True);f.write('\n')
    watch.cancel()
if __name__=='__main__':main()
