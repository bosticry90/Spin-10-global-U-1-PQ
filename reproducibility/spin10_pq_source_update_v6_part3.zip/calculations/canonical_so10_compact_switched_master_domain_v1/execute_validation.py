"""Bind the completed and failed packets before the final audit."""

import ast
import sys

from execute_b_v2 import CONTROL, HERE, ROOT, TOOLS, digest, git, write_pair
from check_b_v2 import read


NAVIGATION = ["README.md", "docs/COMMON_RESTORATION_CAMPAIGN_V1.md", "docs/RESEARCH_EXECUTION_HANDOFF_V868.md"]


def main():
    producer = read(HERE / "preparation_b_v2.json")
    head = git("rev-parse", "HEAD").decode().strip()
    assert head == producer["base_HEAD"]
    assert not git("diff", "--cached", "--name-only")
    assert set(git("diff", "--name-only", "HEAD").decode().splitlines()) == set(NAVIGATION[:2])
    for name, backup in zip(NAVIGATION[:2], ("README_before_final.bytes", "campaign_before_final.bytes")):
        assert digest(CONTROL / backup) == producer["sha256"][name]
    for name, expected in producer["sha256"].items():
        if name not in NAVIGATION:
            assert digest(ROOT / name) == expected, name
    for name in ("FINAL_RECORD.md", "RESULT.md", "validate.py", "execute_validation.py"):
        data = (HERE / name).read_bytes()
        if name.endswith(".py"):
            ast.parse(data)
        with (HERE / (name + ".source.txt")).open("xb") as stream:
            stream.write(data)
    names = set(producer["sha256"]) | set(NAVIGATION)
    names.update(path.relative_to(ROOT).as_posix() for path in HERE.iterdir() if path.is_file())
    names.update({
        "docs/LOCAL_RESEARCH_CONVENTIONS_V1.md",
        "calculations/canonical_so10_augmented_operator_ir_domain_v1/PROOF.md",
        "calculations/canonical_so10_augmented_operator_ir_domain_v1/validation_receipt.json",
        "calculations/canonical_so10_joint_born_ir_trace_domain/DERIVATION_V2.md",
        "calculations/canonical_so10_joint_born_ir_trace_domain/validation_receipt.json",
    })
    receipts = sorted(name for name in names if name.startswith("calculations/") and "receipt" in name and name.endswith(".json"))
    assert len(receipts) >= 16
    write_pair("preparation_validation.json", {
        "base_HEAD": head,
        "navigation": NAVIGATION,
        "owner_receipts": receipts,
        "sha256": {name: digest(ROOT / name) for name in sorted(names)},
        "limits": {**producer["limits"], "seconds": 180},
        "scientific_acceptance": "NOT_PERFORMED",
    })
    sys.path.insert(0, str(TOOLS))
    from export_a10_e5_antighost_vector import capture

    report = capture([sys.executable, "-B", str(HERE / "validate.py")])
    write_pair("capture_validation.json", report)
    print(report["stdout_and_stderr"], end="")
    assert report["calculation_completed"] and report["post_run_observations_qualified"]


if __name__ == "__main__":
    main()
