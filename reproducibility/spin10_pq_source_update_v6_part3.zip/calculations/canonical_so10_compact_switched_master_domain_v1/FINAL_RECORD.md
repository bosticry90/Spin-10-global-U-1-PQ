# V868 separate final review

Run once on the V867 base under the current AGENTS policy. Freeze this review,
the phase A and phase B packets, both B captures, the owner evidence, and the
current navigation before running the verifier. The final worker has 180
seconds, 8 GiB sampled private allocation, a 350 MiB launch floor and the
phase B packet limits. The E4 subprocess has 120 seconds within that limit.

Require the two successful captures and the preserved failed B capture.
Independently recover the full reference mass difference, the scalar ghost
Euler witness, the H affine witness and all relaxed length rows. Exercise
LEFT switch Euler and primitive derivative controls against explicit
differentiation. Compare all source snapshots and phase manifests. Authenticate
the reused owner receipts. These checks do not freshly execute those owners.

The proof review checks compact transfer, flat reference, the fixed metric
and first dimension jet, and common forest normalization. The Q tangent is
the derivative of F_P, whose source-free reference part is zero. The full
source variation E_P includes E_R. Acting with it on a source-dependent
compact vertex retains that vertex's compact factor. These two facts explain
why the tangent admission does not require erasing E_R. The reference
determinant stays fixed for a flat field/source variation and remains in the
functional. The full background derivative is a separate obligation.
The geometric reference witness uses a constant patch with sigma different
from one. The Euler-normal R has mixed density
i(Λ div B−B·grad Λ)/2. Its literal g0 variation is i Λ Box omega minus
i div(Λ grad omega)/2. The four saved terms are its constant-patch Euler
witness. For variable sigma the divergence in (1−sigma) TR produces
−i (grad sigma)·Λ grad omega/2. The Maxwell reference current is kept by
the same literal TR rule. Neither witness replaces the whole TR or measures
a proper loop. The geometric Ward claim uses theta=0 with one local omega.
The theta derivatives of the master and of the parent define common
contacts. An additional theta derivative of the geometric Ward equation
would require the two-geometric-label admission.

The free b(R) is zero by V867's scalar and massless-reference checks.
Gamma_T,1 is the proper coefficient of the same COS1 forest-normalized
products. Reuse the joint Schwartz seminorm estimates and two-sided
edge cutoffs of the bound joint Born trace derivation. The extra finite
switch jets increase the required finite seminorm order. This is a joint
boundary comparison, with no finite-part claim for an arbitrary connected
bare product.

E4 must return 0 with steps 0,0,0,0,0,2 and exactly seven recorded unresolved
custody references. Preserve exact captures, the original README suffix and
unchanged project_state.json. A missing owner, a check mismatch or exhausted
limit keeps the evidence unqualified. A successful final receipt permits an
ordinary local evidence commit. It does not promote scientific authority.
