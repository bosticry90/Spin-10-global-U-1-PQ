# V868 — actual compact switched master and converted trace admission

Continue main d3d6da41cf4775996c7fb7db4b46dc0679a6e0ef/V867,D:,ACTIVE.
Previous turn PROGRESS,V867 completed. Root writes/runs/Git; read-only AI
reviews. Current AGENTS/charter/solo,state113,authority34/39,E5/A5 open,seven
custody NOTPASS,flavor pause/HB1/C5 blocks unchanged. No branch/worktree,
physical scheme/adoption,protected promotion,push or publication.

Question: can V853's converted trace identity be admitted on the actual
compact current parent,with its classical switched breaking and all marked
companions intact? This is the next applicability gate after V867's causal
initial dictionary. Do not reopen V866 or rebuild the old causal products.

Freeze the flat source-free CWB reference R, literal current A=S+uU and K
representatives,real compact switch sigma. Work g<=1,first H or M u,
intrinsic01 with actual higher intrinsic reference terms kept as programs,
first rho/beta/theta and all source/test jets. Set A_sigma=R+sigma(A−R),
K_sigma=sigma K and P=A_sigma+rho K_sigma+theta C(A_sigma+rho K_sigma).
Form B[P] BEFORE Z=P+beta B[P]. C is current even source operation.
No global sigma->1,full covariant-background R[A],connected nonlinear
inverse-heat lift or chiral/measure claim.

Phase A (120s/8GiB sampled,32MiB packet/8MiB artifact) freezes a decisive
actual nonzero switch-cross control. From the qualified current F1 scalar
columns and V791 reference,retain two Phi coordinates180/181 and local
ghost555. Compute COMPLETE EL_C coefficient of sum F_A E_R in this
projection,once by literal ordered multiplication and once by kinetic
integration by parts. Compare all rational/jet cells,reference-mass
cancellation and opposite generator entries. Keep sigma locally constant
symbolically c≠0,1,not a physical benchmark. The sigma(1−sigma) term should
remain even when sigma jets vanish in that patch. A zero result or mismatch
is retained honestly; no coefficient fitted or alternative generator chosen
to evade a failure. No new integral.

Phase B will freeze its sources separately. Derive full switched Euler
identity F_sigma=sigma F_A+f_dsigma,E_sigma=(1−sigma)E_R+sigma E_A+e_dsigma.
Keep sigma²B[A] with its density/current distinction; multiplying a divergence
by sigma² introduces a switch current. Keep sigma(1−sigma) sum F_A E_R
and every switch-jet term. Derive D_sigma by LEFT Eulers. Beta-rho retains
both direct D_sigma A_sigma and the ordered covariance with K_sigma and
B[A_sigma]; theta transports B_sigma. V867 b of direct seagull may vanish
by support,but does not remove it or b of the base master.

Prove the actual switched principal/reference match including its natural
quadratic divergence and switch-jet remainder. Keep positive reference
masses and real label transfer at each compact vertex; no extra ungraded
marginal base letter. Check fixed tensor lift,all-D/first-jet identity and
ordered heat/forest subtractions. One beta letter can have defect−1;
if all other defects/grade premises pass,the conservative local bound is
10=5positive+4other marginal+1negative. Do not assert switched B=0 or
truncate the nonlocal determinant. Apply V853 and V867/GQAP only after the
specific switched trace/current domain passes. Any remaining missing
operator/analytic premise is recorded precisely rather than inventing a loop.

Phase B and final resource bounds/source/inputs to be frozen before those
computations. Final requires independent mathematics and exact bindings,
fixed E4 0,0,0,0,0,2/seven NOTPASS before local commit. Phase A alone is
unqualified for switched restoration. Positive ceiling: scoped compact
bosonic one-loop Ward realization WITH its classical cutoff insertion,
not full causal/all-order QAP,physical vacuum or E5/A5/viability. Shared
action/conventions/software/analytic assumptions and AI limit independence.
