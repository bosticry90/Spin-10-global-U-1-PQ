# Compact switched master and common proper trace

This result uses the original unshifted flat bosonic reference and the
coefficient domain in the phase A and phase B records. The same real compact
switch acts on the literal current interaction and primitive. Field, source,
epsilon and geometric test labels are retained through differentiation. No
analytic continuation of a particular compact test function is used.

## Form the master after switching

For an ordinary or source coordinate i, let L_(i,I) be the left partial of
the literal density L with respect to its jet i,I. The exact switched Euler
formula is

    EL_i(sigma L) = sigma EL_i L
      + sum_(I,0<K<=I) (-1)^|I| binom(I,K) (partial^K sigma)
                                             partial^(I-K) L_(i,I).

It follows by expanding each adjoint derivative in the Euler sum. All
Grassmann prefix signs stay inside L_(i,I). Write the second term for A−R
as e_i for an ordinary coordinate and f_i after the factor (-1)^p_i for
its source. Since R is source-free,

    F_sigma,i = sigma F_A,i + f_i,
    E_sigma,i = (1−sigma) E_R,i + sigma E_A,i + e_i,
    B_sigma = sigma² B[A] + sigma(1−sigma) sum_i F_A,i E_R,i
      + sum_i (sigma F_A,i e_i + f_i[(1−sigma)E_R,i+sigma E_A,i] + f_i e_i).

This formula is for densities in their displayed order. A divergence
sigma² div j has integrated representative −2 sigma (partial_mu sigma)j^mu.
The phase A raw and normal cross representatives also differ by a current.
Multiplying that current by sigma(1−sigma) gives the associated gradient of
sigma(1−sigma). The phase A comparison keeps eight nonzero ghost Euler words
on an actual constant patch and preserves all four cross currents. In that
calculation equal Phi reference masses cancel by the antisymmetric generator.
The ghost reference column contributes zero by the actual F_a support.

With K_sigma=sigma K the same Euler formula gives
D_sigma z_i=−EL_Ji K_sigma and D_sigma J_i=EL_zi K_sigma. The rho coefficient
of B[A_sigma+rho K_sigma] is the density sum_i[(D_sigma z_i)E_sigma,i
−F_sigma,i(D_sigma J_i)]. Its integral is D_sigma A_sigma with the Euler
currents included. The even canonical source translation C annihilates sigma
and the source-free R. It gives CP before forming B[P], and its bracket
derivation gives B'[P](CP)=C B[P] as a local functional. This keeps the
theta transport of the switched master. CK_sigma=0 on the literal K from
V865. It implies commutation of C with D_sigma, while the transported
D_sigma A_sigma must still be kept.

Form Z=P+beta B[P]. The ordered left beta then rho derivative of the common
functional F has the direct insertion F'[D_sigma A_sigma] and the mixed
derivative F''[K_sigma,B_sigma]. The latter is defined by the ordered
strengths in the single parent. At length two the covariance words are
K B0−B0 K, with X0 Br+Br X0 the base/direct-seagull words. V867's zero for
the single scalar tadpole contraction b(D_sigma A_sigma) leaves both the
direct insertion and the mixed covariance in the full functional.

## Principal match and local word bound

Use R=1/2 sum_i z_i EL_i R as the reference density representative, with
its actual graded dual kernel. This is fixed by the CWB/V791 quadratic
functional and the stated choice of representative. The homogeneous scaling
variation of a quadratic literal density L gives

    2 L = sum_i z_i EL_i L + div j_L.

Here j_L is obtained by telescoping each derivative in
(partial^I z_i)L_(i,I) onto L_(i,I). The left variation order is unchanged
throughout. V851's complete ungraded, dimension-zero, two-port Fourier
kernel equals the kinetic part of R in all 1,543 entries. The independent
reference comparison keeps the 328 diagonal positive scalar masses. For
the dimension-zero principal comparison the equalities lift in the same
V848 metric construction. There are at most four free field or momentum
slots, all paired by metrics, and the rank-zero, two and four pairing
tensors are faithful at four dimensions. Symmetric derivative slots impose
the same symmetries in the lift. Classical two-port matching adds no
dimension-dependent trace. The scaled Euler formula therefore identifies
the literal principal difference with div j_0 in that lift. In the switched
interaction its equivalent representative is −(partial_mu sigma)j_0^mu.
The switched parent continues to use the original literal densities. In
particular, no ungraded marginal quadratic letter survives. Equivalently,
setting switch jets to zero in that principal Hessian multiplies the complete
zero kernel by sigma.

For two ordinary Hessian ports the relative defect is delta=4−D_L+c, with
D_L the unmarked density dimension and c the dimension left outside the
ports. A switch jet contributes its jet order to c. Undifferentiated sigma
has dimension zero and gives a transfer label. The unmarked action and its
theta derivative have D_L<=4, K_sigma has D_L<=3, and B[P] uses one Euler
pair with D_L<=5 before its strength. All remaining intrinsic coefficients
are nonnegative in dimension. Positive scalar masses, physical potential
Eulers and higher-intrinsic reference terms remain as programs. No uncut
zero-transfer exclusion for B is imported. One beta root may have delta=−1.
At most four other zero-defect roots can occur, since each spends a distinct
g/u/rho/theta grade. Closed products telescope the relative port weights.
At degree at least −4 there are at most five positive-defect letters with
one negative letter, so n<=10 for local UV conversion. With a nonnegative
beta defect the bound is nine. For the geometric insertion one even
strength replaces beta and the insertion has dimension at most four.
These bounds leave the full nonlocal coefficient series intact.

## Fixed metric, joint soft pairing and ordered finite parts

Assign sigma and the even geometric test parameter zero dimension, ghost
number and Lorentz slot cost. Their jets cost one dimension per endpoint.
Thus V852's additive d−gh−ell>=0 still holds with the same negative-beta
and rho/epsilon assignments. The only new classical sewings are the single
source/field Euler pair in B and one Euler substitution into a cochain.
Removing a vector port opens one metric line whose other end is still on an
actual carrier or derivative endpoint. Connecting the open ends across
the two Euler factors, or into a cochain, joins those surviving endpoints.
Leibniz derivatives hitting sigma create actual derivative endpoints.
This process creates no closed numeric Lorentz line. Affine T uses the same
metric construction and zero-order skew field matrix, with an affine
parameter jet for a vector translation. Its source coefficients are
ordinary-field independent. These classical operations commute with the
external projection and first dimension jet on the fixed rank-at-most-four
local module. Closed internal quantum D factors and the derivative of the
sphere normalization remain in alpha'_4.

Every interacting vertex in H_Z−H_R has a compact factor. In particular
every term in B[P] contains a switched source Euler factor. The Q tangent
has the same property, and the T tangent and TP insertions have the local
geometric test label, including the terms that use (1−sigma)R. Differentiating
or taking an adjoint does not erase the last compact factor. Use independent
vertex coordinates and transfers before pairing them with compact products
of the same switch and field/source jets. After removing the total transfer,
the loop momentum and independent transfers give all edge momenta as linear
coordinates on the cycle. Each free edge has soft pole order at most two.
Consequently the product on a finite cycle is locally integrable in joint
variables. Finite polynomial momentum factors from the jets cannot worsen
that soft order. The complete inverse/tangent comparison uses the inherited
paired IR prescription, including distributional contact defects, in its
original order of UV finite part then joint IR limit. This argument gives no
unsmeared zero-transfer product or global adiabatic limit.

For a fixed word the hard-shell expansion and remainder argument of V851
applies to its rational reference denominators with the added polynomial
transfer numerators. Subtract through degree −4, retaining the ordered old
heat clock c=2n, all prefactor and Duhamel jets, and the full analytic
dimension jet. The remaining hard radial integrand is bounded by a constant
times r^−2 after the bounded Gaussian polynomial is taken into account.
Use the finite-jet extension of COS1 for balanced jets of composite vertices.
Subtract each cycle's divergence with its complete regulated forest before
taking finite parts. The finite T comparison uses the joint distribution
boundary with independent external label slots and the qualified Wick tensor
factors. A fixed compact sigma is smeared after that boundary comparison.
The original reference determinant remains part of each common map.

## Broken identities in one compact proper prescription

In this domain use V853's F_kappa=F_heat+C_fin on the same whole parent.
The actual arbitrary-source Hessian identity and the converted cyclic
Stokes map give Q_P F_kappa=I_B,kappa. The differential tangent has no
critical homogeneous symbol or hard finite constant in that map. This
argument retains the paired raw heat inverse, Jacobian and covariance
terms. The reference is fixed by Q_P, which acts on the fields and sources.
The marked coefficient is

    D_sigma F_kappa − Q_A_sigma I_K,kappa
       = I_(D_sigma A_sigma),kappa + F_kappa''[K_sigma,B_sigma].

For geometric T acting on the same flat chart, the reference operator is
held fixed in the trace. The V860 affine Hessian congruence is independent
of the parent. Its adjoint trace terms cancel by the converted trace, with
the qualified skew tangent and all raw regulator terms retained before
conversion. Therefore T F_kappa[P]=I_(TP),kappa[P]. At theta=0 put

    G_sigma=(T+C) A_sigma=(1−sigma) TR + sigma (T+C)A.

The reference term survives on a constant switch patch. The actual H
reference auxiliary-vector cross under T0 B_H=partial omega_H gives
i Lambda_H Box omega_H in the Euclidean density convention. It is nonzero
as a functional of the independent Lambda and test jets. If (T+C)A=div j,
the last term has integrated representative −(partial_mu sigma)j^mu.
The flat reference operator and its determinant are held fixed for this
flat field/source operation. The full local-background derivative of the
reference determinant is a distinct W4 contribution outside this slice.

The modified geometric identity is T F_kappa + I_CA_sigma = I_G_sigma.
Using TK_sigma=−K_sigma[L_omega epsilon] and CK_sigma=0, its rho derivative
has the additional F_kappa''[G_sigma,K_sigma] on the right, alongside
−I_K[L_omega epsilon]. The left side includes T I_K and
F_kappa''[CA_sigma,K_sigma]. All theta derivatives act on the same whole
insertions, including the derivatives of their arguments. In particular the
uncut marked geometric relation cannot remove the switched covariance.

Finally the fixed-reference dictionary of V867 and COS1 gives
Gamma_T,1[Z]=F_heat[Z]−b[Z] and C_T[Z]=C_fin[Z]+b[Z] on this coefficient
domain. Applying strength derivatives to their sum transports the compact
proper identities with one common contact prescription. The linear b acts
on the actual switched products, with cross contractions and Euler
currents, and its physical tadpoles remain. No commutation of b with
field-dependent Q or local T is assumed. The GQAP compact anomaly recursion
on the underlying causal products retains the classical insertion B[P]
and gives a local anomaly in its original chart. This comparison does not
classify the entire local cohomology or remove the cutoff. The connected
inverse-heat Schwartz counterexample and the full nonlinear, background,
measure, chiral, equivalence and physical-viability obligations remain.

The producer and proof reviews share action definitions, the reference,
analytic inputs, software and AI authorship. The numerical guards authenticate
specific interfaces. The arbitrary-word and arbitrary-jet claims use the
proofs above and the bound owner results.
