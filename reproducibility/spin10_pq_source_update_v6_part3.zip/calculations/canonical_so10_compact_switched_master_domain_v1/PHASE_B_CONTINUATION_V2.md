# V868 phase B verifier continuation

The first worker failed at check_b.py:74. It tested emptiness of the whole
Lambda_H geometric field column while verifying its g0 reference cross.
The two frozen V855 packets have an empty g0 column and four nonzero g1
rotation rows. The initial assertion was stronger than the frozen g0 claim.
Keep the original worker, preparation and failure capture unchanged.

The V2 worker checks the g0 projection and saves the full column with its
g1 rows. The reference identity, UV grading, affine proof and all other
requirements are unchanged. Use the same limits as phase B and bind its
failed capture before the new run. No prior scientific PASS is implied.
