# V868 phase B compact proper trace admission

Use the phase A preparation and completed capture at the same V867 Git base.
Keep the original phase A contract and outputs. The producer has 120 seconds,
8 GiB sampled private memory, a 350 MiB launch floor, an 8 MiB result limit and
a 32 MiB total packet limit. Root owns writes. The two AI reviews were read-only.

Use the exact CWB/V791 source-free reference as a quadratic functional. In the
literal switched density choose its representative by graded quadratic Euler
reconstruction of the reference kernel. Carry any change of the interaction's
literal density through its explicit current before computing switched Eulers.
Fix the old matched reference, heat clock, scale, and symbolic kappa. No new
physical parameters, profiles, or normalization values are chosen.

Compare all 1,543 saved base kernel entries with both V791 reference packets.
Only the 328 diagonal scalar reference masses may differ. Check the actual H
auxiliary-vector cross and its T0 variation, the complete phase A scalar Euler
result, the relaxed signed-defect grammar, and ordered odd extraction with two
implementations. Preserve failed controls and exact evidence. The proof must
justify arbitrary switch jets, compact labeled transfers and the same fixed
metric lift. Neither an example nor a finite grammar can replace those proofs.

Apply the older common trace conversion and the causal initial dictionary
only on the bounded flat compact proper coefficient family. Keep reference,
classical cutoff insertions, ordered forest factors, regulator and contact
terms. Geometric tests act on the flat reference fields, including the cutoff
cross in a constant switch patch. Preserve the independent local omega label
before Wick boundary pairing. The full local background reference, global
connected transport, and unrestricted products are outside the test.

Failure of a mathematical or resource gate leaves the affected admission open.
The evidence ceiling is a common compact proper one-loop Ward family with its
classical switched carriers, plus the existing compact QAP locality statement.
Full E5/A5, physical viability and the seven unresolved custody items retain
their recorded status. Final independent review, authenticated owner receipts,
and the fixed E4 sequence are required before a commit.
