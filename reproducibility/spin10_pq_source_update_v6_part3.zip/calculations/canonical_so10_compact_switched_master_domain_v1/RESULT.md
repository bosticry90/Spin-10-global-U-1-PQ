# V868 compact proper one-loop Ward admission

Use this result with the completed final receipt and capture. The declared
compact flat-reference coefficient family admits one proper causal
normalization for the selected Slavnov, marked and modified geometric
identities. The same finite functional supplies the action and contact
derivatives. These identities retain the actual switched classical carriers.

Two exact constructions give the eight-word scalar ghost Euler witness
with the factor sigma(1−sigma). It survives where the switch is constant
between zero and one. The fixed reference contributes a separate classical
geometric term (1−sigma)TR. The degree-zero H witness is i Λ_H Box omega_H
on a constant patch. Its literal reference current and the other cutoff
currents remain in the full expression.

The 1,543-entry marginal kernel and 328 scalar reference mass differences
match in both routes. The fixed lift and compact transfer argument admit
the ordered finite parts and their first dimension jet. At most ten letters
can contribute to the local conversion at the selected grades. This bound
allows a single beta letter of defect −1 and leaves the nonlocal words
intact. The mixed marked master retains its direct seagull and both
covariance orders. The geometric Ward equation uses one local test
parameter at theta=0, and its rho derivative retains the cutoff covariance.

The causal comparison uses the existing complete forest prescription and
linear b dictionary with the same reference. No new integral was needed.
The first phase B worker failed by checking the full auxiliary T column
for a g0 witness. The V2 worker retains all four g1 rows and checks the
g0 projection. The original failed run remains in the packet.

[Proof](PROOF.md) and [final review scope](FINAL_RECORD.md). The result uses
the older common reference and its matched heat family. The whole recovered
heat profile, local background reference determinant, two-geometric-label
Ward domain, unrestricted composite products and global connected transport
remain open. The compact QAP locality result is used within its declared
scope. The cutoff stays in place. No measure, chiral, equivalence, E5/A5 or
physical-viability conclusion follows. The shared inputs, analytic
assumptions, software and AI authorship limit the independence of the checks.

The next test binds the existing background reference kernel and relative
determinant to the current frame. Compare its flat block and first nonzero
background covariance and current before deciding whether any new quantum
input is needed. Authority 34/39, state 113 and seven unresolved historical
custody references retain their recorded status.
