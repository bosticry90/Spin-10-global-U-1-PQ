"""Freeze the phase B program and owner evidence before launching it."""

from hashlib import sha256
from pathlib import Path
import ast
import json
import subprocess
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CONTROL = Path("D:/Codex-Research/ToE-Next/research-control-records/compact-switched-master-domain-v1-2026-11-08")
TOOLS = ROOT / "tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1"
OWNER_FILES = {
    "augmented_uv_grading_v1": ("PROOF.md", "validation_receipt_v2.json", "native_complete_UV_grading_v2.json.gz", "replay_complete_UV_grading_v2.json.gz"),
    "augmented_metric_lift_v1": ("PROOF.md", "validation_receipt.json"),
    "augmented_source_dimension_jet_v1": ("PROOF.md", "validation_receipt.json"),
    "common_conversion_carrier_v1": ("PROOF.md", "validation_receipt.json"),
    "dimensional_stokes_primitive": ("DERIVATION.md", "validation_receipt.json"),
    "geometric_affine_trace_domain_v1": ("PROOF.md", "validation_receipt.json"),
    "geometric_ward_current_source_chart_v1": ("validation_receipt_v2.json", "primary_complete_geometric_current_source_chart.json.gz", "replay_complete_geometric_current_source_chart.json.gz"),
    "joint_common_family_applicability_v1": ("PROOF.md", "validation_receipt.json"),
    "causal_one_loop_sewing": ("DERIVATION.md", "FINITE_JET_DOMAIN.md", "validation_receipt.json", "cycle_receipt.json", "jets_receipt.json"),
    "graded_causal_qap": ("DERIVATION.md", "validation_receipt_v2.json"),
    "connected_ward_transport": ("RESULT.md",),
}


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def write_pair(filename, value):
    data = (json.dumps(value, sort_keys=True) + "\n").encode()
    for folder in (HERE, CONTROL):
        with (folder / filename).open("xb") as stream:
            stream.write(data)


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def main():
    prior = json.loads((HERE / "preparation_a.json").read_bytes())
    head = git("rev-parse", "HEAD").decode().strip()
    assert head == prior["base_HEAD"] and not git("diff", "--name-only", "HEAD")
    assert git("ls-tree", "-r", "HEAD") == (CONTROL / "old_git_tree.txt").read_bytes()
    for name, expected in prior["sha256"].items():
        assert digest(ROOT / name) == expected, name
    for name in ("preparation_a.json", "capture_a.json", "preparation_b.json", "capture_b.json"):
        assert (HERE / name).read_bytes() == (CONTROL / name).read_bytes()
    capture_a = json.loads((HERE / "capture_a.json").read_bytes())
    assert capture_a["calculation_completed"] and capture_a["post_run_observations_qualified"]
    for name in ("execute_b_v2.py", "check_b_v2.py", "PHASE_B_CONTINUATION_V2.md"):
        source = (HERE / name).read_bytes()
        if name.endswith(".py"):
            ast.parse(source)
        with (HERE / (name + ".source.txt")).open("xb") as stream:
            stream.write(source)
    names = set(prior["sha256"])
    names.update(path.relative_to(ROOT).as_posix() for path in HERE.iterdir() if path.is_file())
    for directory, files in OWNER_FILES.items():
        names.update(f"calculations/canonical_so10_{directory}/{name}" for name in files)
    names.add((TOOLS / "export_a10_e5_antighost_vector.py").relative_to(ROOT).as_posix())
    write_pair("preparation_b_v2.json", {
        "base_HEAD": head,
        "sha256": {name: digest(ROOT / name) for name in sorted(names)},
        "limits": prior["limits"],
        "scientific_acceptance": "NOT_PERFORMED",
    })
    sys.path.insert(0, str(TOOLS))
    from export_a10_e5_antighost_vector import capture

    report = capture([sys.executable, "-B", str(HERE / "check_b_v2.py")])
    write_pair("capture_b_v2.json", report)
    print(report["stdout_and_stderr"], end="")
    assert report["calculation_completed"] and report["post_run_observations_qualified"]
    assert sum(path.stat().st_size for path in HERE.iterdir() if path.is_file()) <= 32 * 1024**2


if __name__ == "__main__":
    main()
