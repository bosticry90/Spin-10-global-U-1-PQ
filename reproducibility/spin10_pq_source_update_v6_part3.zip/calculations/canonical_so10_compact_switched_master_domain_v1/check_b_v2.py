"""Exact phase B guards for the compact proper trace proof."""

from fractions import Fraction
from hashlib import sha256
from itertools import permutations
from pathlib import Path
import gzip
import json
import os
import threading
import time

import sympy as sp


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CALC = ROOT / "calculations"
INVERSE = CALC / "canonical_so10_regulator_free_inverse_g1_recovery_v1"
UV = CALC / "canonical_so10_augmented_uv_grading_v1"
GEOMETRIC = CALC / "canonical_so10_geometric_ward_current_source_chart_v1"


def read(path):
    if path.suffix == ".gz":
        with gzip.open(path) as stream:
            return json.load(stream)
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def save(path, payload):
    data = (json.dumps(payload, sort_keys=True) + "\n").encode()
    if len(data) > 8 * 1024**2:
        with path.with_suffix(".COMPLETE_OVERFLOW_NOTPASS").open("xb") as stream:
            stream.write(data)
        raise RuntimeError("Result exceeded the frozen artifact limit")
    with path.open("xb") as stream:
        stream.write(data)


def reference_check(role):
    with gzip.open(UV / f"{role}_complete_UV_grading_v2.json.gz") as stream:
        uv = json.load(stream)
    principal = uv["complete1543_base_zero_cost_kernel_equals_Pphysical"]
    assert not uv["complete_positive_cost_unlabeled_base_ports"]
    del uv
    packet = read(INVERSE / f"{role}_inverse.json.gz")
    assert principal == packet["Pphysical"] and len(principal) == 1543
    p = {(i, j): value for i, j, value in principal}
    ref = {(i, j): value for i, j, value in packet["Preference"]}
    assert ref.keys() == p.keys()
    masses = {}
    for (i, j), value in ref.items():
        if value == p[i, j]:
            continue
        assert i == j and 180 <= i <= 507
        species = "Phi" if i < 234 else "Sigma" if i < 486 else "phi" if i < 506 else "S"
        delta = sp.expand(sp.sympify(value) - sp.sympify(p[i, j]))
        assert delta == sp.Symbol(f"Mref_{species}_squared")
        masses[i] = str(delta)
    assert set(masses) == set(range(180, 508))
    cross = [[mu, ref[508, mu], ref[mu, 508]] for mu in range(4)]
    assert cross == [[mu, f"-q{mu}", f"q{mu}"] for mu in range(4)]

    route = "primary" if role == "native" else "replay"
    geometric = read(GEOMETRIC / f"{route}_complete_geometric_current_source_chart.json.gz")
    columns = dict(geometric["all1286_direct_Tq_columns"])
    affine = [[row for row in columns[mu] if row[0] == 0] for mu in range(4)]
    assert affine == [[[0, [[1286, [mu]]], [[[0, 0, 0], 1, 1]]]] for mu in range(4)]
    assert not [row for row in columns[508] if row[0] == 0]
    # In the declared Fourier convention partial_mu maps to i q_mu.
    # The row Lambda<-B gives -q_mu, so its density coefficient is i.
    q = sp.symbols("q0:4")
    coefficient = [sp.sympify(row[1]) / (sp.I * q[mu]) for mu, row in enumerate(cross)]
    assert coefficient == [sp.I] * 4
    return {
        "principal_kernel": principal,
        "scalar_reference_mass_only_differences": sorted(masses.items()),
        "actual_H_reference_cross": cross,
        "actual_H_affine_columns": affine,
        "complete_H_auxiliary_T_column": columns[508],
        "geometric_witness": [[508, 1286, [mu, mu], "I"] for mu in range(4)],
    }


def local_word_grammar():
    rows = []
    for budget in range(5):
        for beta_credit in (0, 1):
            ceiling = budget + beta_credit
            best = {(0, 0): 0}
            # A positive letter spends cost. A marginal letter spends one
            # of g, u, rho, theta, beta. Both transitions increase this order.
            for cost in range(ceiling + 1):
                for mask in range(32):
                    if (cost, mask) not in best:
                        continue
                    length = best[cost, mask] + 1
                    if cost < ceiling:
                        best[cost + 1, mask] = max(best.get((cost + 1, mask), 0), length)
                    for flag in (1, 2, 4, 8, 16):
                        if not mask & flag:
                            target = (cost, mask | flag)
                            best[target] = max(best.get(target, 0), length)
            for mask in range(32):
                if beta_credit and not mask & 16:
                    continue
                maximum = best[ceiling, mask]
                assert maximum == ceiling + mask.bit_count()
                rows.append([budget, beta_credit, mask, maximum])
    assert max(row[-1] for row in rows) == 10
    return rows


def odd_word_guard():
    markers = {"X": (), "K": ("rho",), "B": ("beta",), "M": ("beta", "rho")}
    rows = []
    for left, right in permutations(markers, 2):
        order = markers[left] + markers[right]
        if sorted(order) != ["beta", "rho"]:
            continue
        crossing = (-1) ** (len(markers[left]) * len(markers[right]))
        coefficient = crossing * (-1 if order[0] == "rho" else 1)
        # Extract beta on the left after moving right markers across the
        # left operator. The subsequent rho extraction needs no move.
        word = [*markers[left], left, *markers[right], right]
        beta_index = word.index("beta")
        sign = (-1) ** sum(item in {"beta", "rho", "K", "B"} for item in word[:beta_index])
        word.remove("beta")
        sign *= (-1) ** sum(item in {"rho", "K", "B"} for item in word[:word.index("rho")])
        assert coefficient == sign
        rows.append([left + right, coefficient])
    assert dict(rows) == {"KB": 1, "BK": -1, "XM": 1, "MX": 1}
    return sorted(rows)


def main():
    started = time.perf_counter()
    watch = threading.Timer(120, lambda: os._exit(124))
    watch.daemon = True
    watch.start()
    for name, expected in read(HERE / "preparation_b_v2.json")["sha256"].items():
        assert digest(ROOT / name) == expected, name
    phase_a = read(HERE / "result_a.json")
    for role in phase_a["roles"]:
        euler = role["complete_EL_C_reference_cross"]
        assert len(euler) == 8 and euler == role["complete_IBP_Euler"]
        assert sorted(Fraction(row[2], row[3]) for row in euler) == [-Fraction(1, 2)] * 4 + [Fraction(1, 2)] * 4
        assert not role["complete_mass_residual"] and len(role["all_four_explicit_currents"]) == 4
    native = reference_check("native")
    print("STAGE native principal and geometric reference cross checked", flush=True)
    replay = reference_check("replay")
    assert native == replay
    print("STAGE replay principal and geometric reference cross checked", flush=True)
    save(HERE / "result_b_v2.json", {
        "execution_state": "COMPLETED",
        "scientific_acceptance": "NOT_PERFORMED",
        "compared_reference": native,
        "phase_A_complete_euler_rechecked": True,
        "relaxed_signed_defect_grammar": local_word_grammar(),
        "ordered_beta_rho_length_two": odd_word_guard(),
        "no_new_integrals": True,
        "seconds": time.perf_counter() - started,
    })
    watch.cancel()


if __name__ == "__main__":
    main()
