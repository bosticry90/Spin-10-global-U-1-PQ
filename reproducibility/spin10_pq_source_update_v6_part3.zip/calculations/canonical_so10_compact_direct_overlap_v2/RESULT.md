# V892 — Nonzero compact-to-direct ghost and reference coefficients

The continued connected ghost tree agrees with the compact
Feynman tree at fixed switching on the insertion support.
The actual first-g two-ghost-source insertion also agrees
on the common compact mean slice. Its linear insertion on
the changing mean supplies the second term in the current.
The collapsed spacelike coefficient is nonzero and detects
the missing second omega jet. The weak Wightman contact
agrees in this collapsed comparison, with its own boundary
conditions. Remote switch-only vertices remain in the full
compact parent.

The pure Phi54 reference loop agrees after the common
normalization conversion. Before conversion, the fixed-flat
raw heat tensor has a calculable local difference, with
delta coefficient −M(log 2+1/2)+5z/72 and pp coefficient
5/36 in g² I/(16 pi²) units. The raw power, seagull b and
first dimension jet are retained. The two routes recover
the nonzero Euclidean shape and the same timelike cut.
This tests the reference piece before its combination with
the relative part of the full determinant.

Require the final receipt and capture. V1 stopped on a
structural-expression assertion. V2 compares the exact
expanded residual and retains the failed run. The routes
share model inputs, software and AI authorship. The
normalization is inherited and remains symbolic. V878's
polynomial-coupling requirement continues to apply.
General interacting products, weak adiabatic limits and
observable equivalence remain open.
