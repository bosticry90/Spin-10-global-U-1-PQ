# V892 versioned symbolic assertion correction

V1 stopped in the scalar seagull omission check after the
ghost controls and tensor difference. It compared an expanded
expression to a factored expression by structural equality.
V2 expands their difference and tests exact zero, with the
same frozen mathematical requirement and execution bounds.
All V1 sources, preparations and captures are preserved in
preserved_active_v1 under the V1 D control directory. The
failed V1 execution has no scientific validation receipt.
