# Two nonzero compact-to-direct coefficients

Use the same 643-coordinate action, fixed flat inverse, ordinary
source pairing and common finite normalization as V874 and
V887–V891. Treat the comparisons as coefficients of the common
parent with independent vertex labels. The compact and direct
test spaces are related here by continuation of the specified
kernels. Compact support in position and compact Fourier
support are two different test requirements.

## Geometric ghost insertion

Take one g-linear quadratic Hessian of the actual whole E3
insertion C_source S at A=J=u=0, and two ordinary odd source
leaves. Extract zero degree in every other interaction label,
including the g0 switch-only quadratic labels. At fixed compact
sigma=1 near the compact omega support, the chosen compact
direction is sigma C_source S=C_source S on that support, with
all its jets. This equality holds at the marked vertex. The
complete compact parent still contains switch currents. For
example, the actual free ghost density and its Euler-normal
reference differ by a divergence, yielding the quadratic
switch term −(Box sigma) C a/2 after integration by parts.
Such a vertex can lie on either bridge outside the plateau.
Its coefficient is separate from the single-insertion tree.

In the raw Minkowski chart the density is
g (partial^mu C11) a9 partial_mu omega10. With
D_omega=(partial^mu omega10) partial_mu, its LEFT entries are
N_(C11,a9)=−g(D_omega+Box omega10) and N_(a9,C11)=−g D_omega.
For ordinary sources j_C9=alpha f and j_a11=beta h in
alpha beta order, the two stationary free means give
C11=+beta F h and a9=−alpha F f. The connected coefficient
of the insertion is

    g integral (F f) partial^mu(F h) partial_mu omega10
      = <h, F N_(C11,a9) F f>.

Both trees use exactly these two bridges. The finite source
coefficient follows by differentiating stationarity and is
also the source-first Wick contraction of the marked density.
This includes the complete mean contribution of the quadratic-insertion
tag. Keeping the wrong ordered ghost sign reverses it.

On independent Euclidean tree-edge momenta the two profiles
tend to the unheated simple inverse factors as tempered
distributions. The singularity 1/q² is locally integrable in
four Euclidean dimensions. Polynomial numerators and
invertible edge coordinates preserve the tensor product.
Continue the resulting rational kernel, with V791's
q_M0=i q_E0, density minus and unit ghost phases. A common
energy rotation gives the Feynman simple poles. Away from
the cone tip the two angular roots are simple. At the tip
the radial distribution scales as r^3/r² and the angular
boundary is bounded on smooth tests. This extends to each
edge, with the mark transfer given by their difference.
Thus the continued coefficient agrees with the fixed-switch
compact Feynman tree. No cutoff factor is continued.

For the collapsed comparison write C_F=iG_F with K0G_F=1,
so K0 delta C_F=−N C_F. The V874 weak response
−G_ret N W−W N G_adv instead gives K0 delta W=−N W.
The ordered free entries agree at separated spacelike
points in the stated phase convention. Choose a compact
germ omega=(x0)^2/2 near x=0 and y=(0,L,0,0), L>0.
Then the second parameter jet gives −g/(4 pi² L²) in the
C11,C9 collapsed coefficient. Dropping the second jet
gives zero at these points. The sign of the source-leaf
coefficient uses the displayed alpha beta order and the
common conversion C_F=iG_F. This comparison of collapsed
spacelike kernels places no equality on the full Feynman
and retarded/advanced Wightman variations.

## Companion from the classical mean

Also compute the first-g connected coefficient with the
linear insertion CP_0 and its one ordinary cubic. In the
same actual chart, CP_0 has the mixed Lambda Box omega
direction, and the only relevant g-linear E_B term at
these two ghost means is −g C11 partial_mu a9 in color 10.
Its A-only companion in the density is +g (partial_mu C11)
a9 A_mu. The mixed inverse turns CP_0 on the first-order
mean into +v·E_B V_1. In the direct regulated expression
this contact carries f(k) on the mark momentum k, in
addition to the paired ghost factors. Its sign follows
from the same mixed inverse as CP_0 on the ordinary
source. In the compact Feynman coefficient K0 G_F=1
collapses the mixed bridge before evaluation, and sigma
at the cubic is then one on the mark support. In the
direct paired limit the extra f(k) tends to one almost
everywhere. The two simple ghost poles are on independent
edge transfers and supply an integrable Euclidean
majorant, so there is no residual of this factor.

With the free mean factors kept, the sum is therefore
g integral partial_mu omega [(partial^mu C11) a9−
C11 partial^mu a9], in the ordered density chart. Its
Fourier numerator is proportional to k·(q−r)=r²−q².
As a nonzero compact mean control choose omega=t near
the support, scalar test a, and scalar test c=t a in
the two odd means. Then c' a−c a'=a². Use the ordinary
sources obtained by the free differential on these
means. Because the means have support strictly within
the plateau, the compact g0 quadratic switch jets act
as zero on them. The formal compact inverse on this
source slice therefore gives the same g0 means, also
when those quadratic vertices are admitted. The CP_0
relation at the compact stationary mean follows locally
from CP_0=−v·E P_0. It retains the v·E V_1 term. This
compares the complete first-g two-ghost-source insertion
on the stated source slice and the two separately
tagged graphs. The full compact and direct means for
arbitrary sources may differ.

## Actual Phi54 reference loop

Use the explicitly separated pure reference determinant
R_A−R_0, of degree two in a compact smooth H background A,
with M the positive Phi reference mass squared. Its X
vertices are compact with all their jets. In the full
uncut scalar kinetic Hessian the physical connection is B.
On the A² slice at B=0 the relative words cancel the
reference words. The pure reference coefficient is kept
once, before that cancellation. The present test is of
that coefficient and its normalization.

Work in the stripped Euclidean half trace log. Restore
the inherited external density and loop phase after
comparison. Put I_hk=−tr r_h r_k=12 delta_hk in the joined
current chart and P0=g² I_hk/(16 pi²). The actual covariant
Laplacian gives the linear symbol i g r_h (2q+p)·A^h and
the quadratic symbol −g² sum_mu r(A_mu)^2. The two traces
are half the seagull and minus one quarter the bubble in
the effective action. Hence in its two-point kernel the
seagull is g²I delta T(M), and the bubble is −g²I/2 times
the two-propagator numerator (2q+p)_mu(2q+p)_nu.

First compute the fixed-flat raw heat comparison using
the n1 and n2 clocks, with exp(−2t q²) per edge. For one
edge the radial integral in P0 units is
1/(2t)−M exp(2tM) E1(2tM). For two edges use
Delta=M+v(1−v)z, z=p², m=min(v,1−v), w=(1−2v)^2.
The Schwinger sum s starts at 2t/m; the two terms are
minus exp(4tM) times

    delta_mu,nu integral dv integral_(2t/m)^infty ds exp(−s Delta)/s²
    + p_mu p_nu /2 integral dv w integral_(2t/m)^infty ds exp(−s Delta)/s.

Subtract the complete power and logarithmic terms in
the fixed-flat prescription. At the endpoints v=0,1 the
expansion error is integrable. For m>=t the error is
O(t log(1/t)) on bounded z; for m<t use the integrable
log(t/m) estimate, giving O(t). The first radial
integral has leading 1/(8t); the prefactor contributes
the finite M/2 before the bubble sign. With
L_H=gamma_E+log(2/mu²)−kappa_H the raw delta coefficient
is M(L_H+log M)−M/2−integral Delta(L_H+log Delta−1−log m).
The pp coefficient is integral w(L_H+log Delta−log m)/2.
The total delta power coefficient is 3/(8t), before P0.

Next compute in dimension D before taking the pole
coefficient. Use the 4/D angular numerator and
d/dM T(M)=−J(M), with J the squared-denominator integral.
Integration in v gives the transverse kernel
P0(z delta−pp) F_M(z)/2, where

    F_M(z)=integral dv w[log(mu²/Delta)+log(4pi)−gamma_E+kappa_D].

The full first dimension jet is required. Premature D=4
in the angular numerator changes the raw dimensional
answer by −P0(M+z/6)delta/2. Match the owner convention
kappa_D=kappa_H−1−log(16pi). The raw heat minus converted
tensor is then

    P0{[−M(log 2+1/2)+5z/72]delta+5 pp/36}.

This exact polynomial fixes the conversion for this
fixed-flat reference comparison. It comes from the two
specified clocks and the full Laurent finite part. The
old n1 finite moment is
d_Phi=M[gamma_E+log(2M/mu²)−kappa_H]/(16pi²).
The seagull gives the action contraction
b(R_A−R_0)=g² I d_Phi integral A²/2. The causal normalized
functional uses Gamma_T=Gamma_H−b and C_T=C_fin+b on
the same parent, so the two b terms cancel with their
inherited phase. The total converted local difference
is minus the displayed raw-minus-converted polynomial.
These fixed-flat expressions do not compute the separate
covariant-heat profile jets of BCR1.

For the nonlocal check, the massive bubble has
F(z)−F(0)=−z integral_(4M)^infty ds (1−4M/s)^(3/2)/
[3s(s+z)]. In the Lorentzian boundary z=−s−i0 the
lower-minus-upper cut is 2 pi i (1−4M/s)^(3/2)/3.
The cut can also be obtained from the two-body phase
space and the scalar current numerator. The seagull
and the local conversion have no cut. The cut plus
the common Laurent normalization gives the same analytic
form factor, including its local term. The subtracted
shape at z=9M/4 is 56/27−(125/81)log 4, and its
slope at zero is −1/(30M). Logarithms at the massive
threshold are locally integrable under the parameter
integral, and the tensor grows at most like
<p>² log(<p>+1). Its distribution extends continuously
from compact Fourier tests to Schwartz tests before
evaluation on compact position backgrounds. COS1 supplies
the compact two-vertex distribution with the same finite
normalization. The massive direct coefficient has the
same unheated limit in this block. No switching limit
or analytic continuation of a compact test is used.

The ghost result is exact equality of the specified
continued tree coefficient. The scalar loop agrees after
the specified local normalization transformation. These
are two nonzero tests of the common prescription. General
mixed loops with extra switch insertions, nonlinear
composite products and a weak adiabatic limit remain
separate. V878's polynomial-coupling constraint applies
throughout, with no inverse g used. The arithmetic routes
share model inputs, conventions, software and AI authorship.
