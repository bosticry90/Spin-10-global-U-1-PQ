"""Actual source and reference controls for the compact-to-direct overlap."""

from functools import cache
import gzip
import json
import sys

import sympy as sp

from execute import ROOT, run_worker


def calc(owner, name):
    path = ROOT / "calculations" / ("canonical_so10_" + owner) / name
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="utf-8") as handle:
            return json.load(handle)
    return json.loads(path.read_bytes())


def selected(rows, degree, slots):
    return [row for row in rows if row[0] == degree and {n for n, _ in row[1]} == slots]


def ghost_controls(role):
    current = calc("unprobed_compact_all_coupling_v1", role + "_full_current.json.gz")["current"]
    one = [[[0, 0, 0], 1, 1]]
    minus = [[[0, 0, 0], -1, 1]]
    for axis in range(4):
        mark = [1, [[564, [axis]], [607, []], [1329, [axis]]], one]
        assert mark in selected(current["complete_CS"], 1, {564, 607, 1329})
        a = [1, [[564, [axis]], [607, []], [1371+axis, []]], one]
        b = [1, [[40+axis, []], [564, []], [607, [axis]]], minus]
        gf = current["complete_S_GF_source"]
        assert selected(gf, 1, {564, 607, 1371+axis}) == [a]
        assert selected(gf, 1, {564, 607, 40+axis}) == [b]
    assert len(selected(current["complete_CS"], 1, {564, 607, 1329})) == 4
    assert selected(current["complete_CS"], 0, {518, 1329}) == [
        [0, [[518, []], [1329, [axis, axis]]], [[[0, 0, 16], -1, 1]]] for axis in range(4)]
    for c, a in ((562, 607), (564, 609)):
        assert selected(gf, 0, {c, a}) == [
            [0, [[c, [axis]], [a, [axis]]], minus] for axis in range(4)]

    inverse = calc("regulator_free_inverse_g1_recovery_v1", role + "_inverse.json.gz")
    q = sp.symbols("q0:4")
    k2 = sum(x*x for x in q)
    entries = [{(i, j): sp.sympify(c) for i, j, c in inverse[key]}
               for key in ("Preference", "Greference")]
    for slots in ((562, 607), (564, 609)):
        k, green = (sp.Matrix(2, 2, lambda i, j: table.get((slots[i], slots[j]), 0))
                    for table in entries)
        assert k == sp.Matrix([[0, -k2], [k2, 0]])
        assert green == sp.Matrix([[0, 1/k2], [-1/k2, 0]])
        assert (k*green).applyfunc(sp.cancel) == sp.eye(2)
    for axis in range(4):
        assert entries[1][518, 40+axis] == q[axis]/k2
        assert entries[1][40+axis, 518] == -q[axis]/k2

    raw = calc("geometric_metric_insertion_lift_v1",
               role + "_complete_geometric_metric_insertions.json.gz")
    cs = next(root for root in raw["all_fixed_density_roots"] if root["name"] == "C_S")
    signs = (1, -1, -1, -1)
    assert [row for row in cs["complete_Minkowski"] if {i for i, _ in row[0]} == {564, 607, 1296}] == [
        [[[564, [mu]], [607, []], [1296, [mu]]], [[[1, 0, 0, 0], sign, 1]]]
        for mu, sign in enumerate(signs)]

    x = sp.symbols("x0:4", real=True)
    length = sp.Symbol("L", positive=True)
    zero = dict.fromkeys(x, 0)
    w = 1/(4*sp.pi**2*((x[1]-length)**2+x[2]**2+x[3]**2-x[0]**2))
    omega = x[0]**2/2
    direct = -sum(s*sp.diff(sp.diff(omega, t)*w, t) for s, t in zip(signs, x))
    wrong = -sum(s*sp.diff(omega, t)*sp.diff(w, t) for s, t in zip(signs, x))
    assert direct.subs(zero) == -1/(4*sp.pi**2*length**2) and wrong.subs(zero) == 0

    r = sp.symbols("r0:4")
    rooted = sum((a+b)*b for a, b in zip(q, r))
    marked = -sum((a+b)*a for a, b in zip(q, r))
    assert rooted != 0 and marked != 0
    assert sp.expand(rooted+marked) == sum(x*x for x in r)-k2
    assert (rooted+marked).subs({q[0]: 1, r[0]: 2, **dict.fromkeys(q[1:]+r[1:], 0)}) == 3
    a = sp.Function("a")(x[0])
    c = x[0]*a
    assert sp.expand(sp.diff(c, x[0])*a-c*sp.diff(a, x[0])) == a*a
    return {"ghost_raw_and_continued_rows": 4, "companion_cubic_rows": 4,
            "collapsed_spacelike_over_g": str(direct.subs(zero)),
            "drop_parameter_second_jet": 0, "omit_rooted_changes_numerator": True,
            "common_mean_sum_numerator_at_q1_r2": 3}


def scalar_chart(role):
    current = calc("current_background_reference_bridge_v1", "result_a.json")["compared"]
    p = cache(sp.sympify)
    matrices = [{(i, j): p(v) for i, j, v in entries if 180 <= i < 234 and 180 <= j < 234}
                for entries in current["twelve_current_homogeneous_carriers"]]
    for h, first in enumerate(matrices):
        for k, second in enumerate(matrices):
            assert -sum(v*second.get((j, i), 0) for (i, j), v in first.items()) == 12*(h == k)
    owner = calc("background_reference_normalization",
                 ("primary" if role == "native" else "replay") + "_v3_result.json")
    assert owner["scalar_moments"][:2] == ["1/3", "1/30"]
    return 12


def scalar_kernel(role):
    v = sp.Symbol("v", positive=True)
    M, z, L = sp.symbols("M z L_H", positive=True)
    w = (1-2*v)**2
    a = v*(1-v)
    weights = [sp.S.One, a, w]
    if role == "native":
        log_m = [2*sp.integrate(f*sp.log(v), (v, 0, sp.Rational(1, 2))) for f in weights]
    else:
        half = sp.Rational(1, 2)
        def log_moment(degree):
            n = degree + 1
            return 2*half**n*(sp.log(half)/n-sp.Rational(1, n*n))
        log_m = [sum(c*log_moment(i[0]) for i, c in sp.Poly(f, v).terms()) for f in weights]
    assert [sp.expand(x) for x in log_m] == [-1-sp.log(2), -sp.log(2)/6-sp.Rational(7, 72),
                                            -sp.log(2)/3-sp.Rational(11, 18)]
    d_mass, d_log, w_log = sp.symbols("integral_Delta_log_Delta log_M integral_w_log_Delta")
    # Power 1/(8t) times the prefactor exp(4tM) supplies M/2.
    bubble_delta = -M/2-(M+z/6)*(L-1)-d_mass+M*log_m[0]+z*log_m[1]
    seagull = M*(L+d_log)
    heat_delta = bubble_delta+seagull
    dim_delta = M*d_log-d_mass-z*(L+sp.log(2))/6
    heat_pp = (L/3+w_log-log_m[2])/2
    dim_pp = ((L+sp.log(2)+1)/3+w_log)/2
    delta = sp.expand(heat_delta-dim_delta)
    pp = sp.expand(heat_pp-dim_pp)
    assert delta == -M*sp.log(2)-M/2+5*z/72 and pp == sp.Rational(5, 36)
    assert sp.expand(bubble_delta-dim_delta-delta+seagull) == 0

    D = sp.Symbol("D")
    assert sp.diff(4/D, D).subs(D, 4)*(M+z/6) == -(M+z/6)/4
    assert sp.integrate(w*a, (v, 0, 1)) == sp.Rational(1, 30)
    t = sp.Rational(5, 3)
    if role == "native":
        value = -sp.integrate(v*v*sp.log(1+sp.Rational(9, 16)*(1-v*v)), (v, 0, 1))
    else:
        value = -sp.Rational(2, 3)*sp.integrate(v**4/(t*t-v*v), (v, 0, 1))
    exact = sp.Rational(56, 27)-sp.Rational(125, 81)*sp.log(4)
    assert sp.simplify(sp.expand_log(value-exact, force=True)) == 0
    beta = sp.Symbol("beta", positive=True)
    if role == "native":
        discontinuity = sp.integrate(w, (v, (1-beta)/2, (1+beta)/2))*2*sp.pi*sp.I
    else:
        # Integrated two-body phase space times angular current average,
        # real-scalar half and the inverse of the stripped 1/(32 pi^2).
        discontinuity = beta/(8*sp.pi)*beta**2/3*sp.I/2*32*sp.pi**2
    assert sp.expand(discontinuity) == 2*sp.pi*sp.I*beta**3/3
    return {"Phi_trace_Gram": scalar_chart(role), "shape_at_z_over_M_9_over_4": str(exact),
            "M_times_shape_slope": "-1/30", "cut_factor": str(sp.expand(discontinuity)),
            "heat_minus_converted_delta_over_P0": str(delta), "heat_minus_converted_pp_over_P0": str(pp),
            "unsubtracted_delta_power_over_P0": "3/(8t)", "nonzero_n1_b_over_P0": str(seagull)}


def checks(role):
    return {"ghost": ghost_controls(role), "scalar": scalar_kernel(role)}


if __name__ == "__main__":
    run_worker(checks, sys.argv[1])
