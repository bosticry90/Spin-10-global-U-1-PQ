# V892 pre-execution contract

Test the two nonzero overlaps requested in the V891 assessment.
Keep the existing 643-field action, V791 phase and source chart,
polynomial coupling ring, paired Euclidean profile and V869
fixed-flat reference normalization. At tree order compare the
actual color-10 geometric insertion with two odd source leaves.
Include the g-linear quadratic insertion and the linear insertion
on the cubic mean response. Admit common compact mean tests
within one fixed switching plateau. Compare the separately
tagged tree distribution on independent ghost momenta. Keep
switch-only vertices in the parent. Require a nonzero spacelike
collapsed check with the full second parameter jet.

At one loop compare the pure Phi54 two-background reference
kernel. Keep positive reference mass squared and both the bubble
and seagull, including b and the full first dimension jet. Derive
the local difference from the actual heat clocks and Laurent
translation. Compare the nonlocal form factor by the parameter
integral and dispersion, and check the cut independently. Bind
both source routes, both old BCR1 roles, the finite CWB initial
normalization and COS1 compact distribution. Fail on a wrong
source or root sign, missing local term, or unequal normalized
nonlocal kernels. No numerical normalization is chosen.

Native limit 120 s, final 180 s including E4 cap of 120 s,
8 GiB sampled private, 350 MiB launch commit floor, 8 MiB
artifact, 32 MiB packet. Freeze inputs, code and proof. Require
final replay, E4 with custody separate and exact staged bytes.
Ceiling is the specified continued tree insertion and pure
reference one-loop coefficient, including its normalization.
General interacting one-loop overlap, nonlinear products and
weak adiabatic applicability remain open.
