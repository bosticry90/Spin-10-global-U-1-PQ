# V904 pre-execution contract

Control the actual subtracted FMY and FFMM proper core with
independent action switch transfers, the V898 color-17
divergence term, and DMM and YY in the same local domain.
Keep no internal quadratic switch insertions, any fixed
finite exterior count, the original converted constants,
and compact smooth soft momentum source tests. Require the
massive parameter derivative, exact FFMM face numerator and
transfer logarithm, the common-sign exterior boundary and
tip shell bounds. Do not infer any uniform switch sum,
feedback completion or global weak-limit conclusion.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB
sampled private, 350 MiB launch floor, 8 MiB artifact and
32 MiB packet. Require exact control replay, receipt and
staged review. No normalization or authority change.
