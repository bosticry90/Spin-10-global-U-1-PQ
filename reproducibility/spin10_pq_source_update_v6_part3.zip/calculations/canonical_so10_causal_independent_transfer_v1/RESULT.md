# Independent causal transfer comparison V904

The actual FMY, FFMM, DMM and YY proper cores with no internal
quadratic insertions admit the stated small-momentum Lorentzian
comparison after their original local constants are subtracted.
At each fixed exterior switch count the massive parameter has
a uniformly positive derivative. The FFMM massless face retains
a logarithm of an independent transfer. Its actual numerator
is quadratic in that transfer and remains nonzero on a tested
null transfer, so it cannot be removed by setting the transfer
to zero inside the integrand.

The common-sign contour bound controls the moving thresholds
against both exterior Feynman poles. The momentum tip has a
positive power after joint scaling in independent edge
coordinates. For zero exterior insertions the nonconstant
piece reaches the V883 boundary. For each fixed positive
exterior count it vanishes in the localized comparison.
The frozen replay checks the actual color-17 divergence
branch, parameter identities, null-transfer control and
scaling margins. The analytic shell argument is in the proof.

The estimates use compact soft momentum source tests and are
not uniform over the exterior count. Independently switched
internal quadratic insertions and the complete feedback
remain outside this comparison. The local dressed result V903
has therefore not yet been combined with the full causal
proper and connected switching sums. Shared model data,
conversion and symbolic conventions delimit the checks.
