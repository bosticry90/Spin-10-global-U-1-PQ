"""Exact controls for independent transfers in the proper ghost core."""

import json
from itertools import combinations
import sys

import sympy as sp

from execute import ROOT, run_worker


def vector(name):
    return sp.Matrix(sp.symbols(f"{name}0:4", real=True))


def dot(a, b):
    return (a.T * sp.diag(1, -1, -1, -1) * b)[0]


def square(a):
    return dot(a, a)


def face_route(phase):
    t, s, u, M = sp.symbols("t s u M", real=True)
    p1, p2, p3, pm, pe = (vector(name) for name in ("a", "b", "c", "m", "e"))
    b = 1-s
    points = [p1, p2, p3]
    weights = [b*u, s, b*(1-u)]
    d = p3-p1
    pbar = u*p1+(1-u)*p3
    D = u*(1-u)*square(d)
    Q = square(p2-pbar)
    if phase == "native":
        A = sum(weights[i]*weights[j]*square(points[i]-points[j])
                for i, j in combinations(range(3), 2))
    else:
        centroid = sum((w*p for w, p in zip(weights, points)), sp.zeros(4, 1))
        A = sum(w*square(p) for w, p in zip(weights, points))-square(centroid)
    C = sum(w*square(p-pm) for w, p in zip(weights, points))
    actual = M*t-(1-t)**2*A-t*(1-t)*C
    assert sp.expand(A-b*(s*Q+D)) == 0
    assert sp.expand(sp.diff(actual, t)-(M+2*(1-t)*A-(1-2*t)*C)) == 0
    assert sp.expand(actual.subs(t, 1)-M) == 0
    assert sp.expand(actual.subs(t, 0)+b*(s*Q+D)) == 0
    jacobian = sp.Matrix([b*u, s]).jacobian([u, s]).det()
    assert jacobian == b

    n0 = dot(pe, p1-pbar)*dot(p3-pbar, p2-pbar)
    expected = -u*(1-u)*dot(pe, d)*dot(d, p2-pbar)
    assert sp.expand(n0-expected) == 0
    assert n0.subs(dict(zip(p3, p1)), simultaneous=True).expand() == 0
    values = {}
    for v, point in ((p1, (0, 0, 0, 0)), (p3, (1, 1, 0, 0)),
                     (p2, (2, 0, 0, 0)), (pe, (1, 0, 0, 0))):
        values.update(zip(v, point))
    values[u] = sp.Rational(1, 2)
    assert square(d).subs(values) == 0
    assert n0.subs(values) == -sp.Rational(1, 2)
    return {"massive_derivative": "M+2*(1-t)*A-(1-2*t)*C",
            "face_after_jacobian": "-s*Q-D-i0",
            "face_numerator": "-u*(1-u)*(pe.d)*(d.(P2-Pbar))",
            "null_transfer_nonzero_witness": "-1/2",
            "collapsed_transfer_face_numerator": 0}


def shell_controls():
    eps, eta, r, a = sp.symbols("eps eta r a", positive=True)
    for signature in (1, -1):
        # Select the sign of the deformation by the Lorentz gradient.
        p_j = a
        z = p_j+sp.I*signature*eta*r
        assert sp.im(signature*z**2) == 2*a*eta*r
        # Reversing the entire shifted momentum retains the same sign.
        assert sp.im(signature*(-z)**2) == 2*a*eta*r
    D, Q, s = sp.symbols("D Q s", real=True)
    face = -s*Q-D-sp.I*eps/(1-s)
    assert sp.simplify(sp.diff(face, s)-(-Q-sp.I*eps/(1-s)**2)) == 0
    assert face.subs(s, 0) == -D-sp.I*eps
    inner = {"FMY_internal": 2, "FMY_external": 3, "FFMM": 3,
             "DMM": 2, "YY": 2}
    margins = {name: 4-degree for name, degree in inner.items()}
    assert min(margins.values()) == 1
    n = sp.symbols("n", nonnegative=True, integer=True)
    assert sp.expand(4-2*(2+n)+2*n) == 0
    return {"tip_margins_before_exterior_derivative_gain": margins,
            "additional_exterior_shell_factor": "(delta/r)**(2*n)",
            "hard_tip_sum_bound": "delta*(1+abs(log(delta)))",
            "soft_cone_subtracted_shell_bound": "r**2*(1+abs(log(r)))",
            "common_absorption_face": "-s*Q-D-i*eps/(1-s)"}


def check(phase):
    path = ROOT / "calculations/canonical_so10_ghost_two_color_transition_v2/result.json"
    owner = json.loads(path.read_bytes())["checks"]
    literal = owner["literal"]
    assert literal["divergence_triplets"] == 44
    assert literal["raw_divergence_F_E_pair"] == {"Phi": "-115/2", "Sigma": "-63/200"}
    assert owner["normalization"]["divergence_FFMM_relative_UV_excess"] == -1
    return {"face": face_route(phase), "shells": shell_controls(),
            "actual_color17_divergence_pairs": literal["raw_divergence_F_E_pair"]}


if __name__ == "__main__":
    run_worker(check, sys.argv[1])
