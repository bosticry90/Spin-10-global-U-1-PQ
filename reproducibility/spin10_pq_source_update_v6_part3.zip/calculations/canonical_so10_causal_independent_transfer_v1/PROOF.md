# Independent soft transfers in the causal proper ghost core

Keep the actual V883 FMY and FFMM derivative assignments, the V898
color-17 switch-divergence branch, the COS1 common UV conversion and
the sequential same-sign Feynman boundary. Work with no internal
quadratic switch insertions, any fixed finite number n of exterior
ghost switch insertions, and smooth compactly supported momentum
tests for the ordinary sources in a sufficiently small Euclidean
momentum ball. Every ordinary action switch and exterior quadratic
switch has its own transfer. This is a localized coefficient test.

The aim is to subtract the actual zero-momentum proper constant
on its original switch labels and control the remaining moving
inner cuts against both exterior poles. Constants and local
feedback with different switch counts remain separate. For n=0
the target is the V883 nonconstant boundary. For n>0 the target
for this subtracted part is zero. No estimate uniform in n is used.

## Actual denominator and numerator

Write P(q)=q0²−|q_space|² and use one massive line with squared
reference mass M>0. Orient the loop once. In FMY one mixed line
q+P1 and the massive line q+Pm have shifts made from switches
only. The ghost q+P2 has shift P2=p+O(k), up to a common sign
choice for p. The two numerator types are the Lorentz contractions
of q+P1 with q+P2 (internal antighost derivative), and q+P1 with
the differentiated exterior momentum (external antighost).
In FFMM the second mixed line q+P3 also has shift made only
from switches. The product of derivatives is, with inherited
overall constants stripped,

    (p_e · (q+P1)) ((q+P3) · (q+P2)).

Here p_e is the exterior antighost momentum, except that the
V898 additional divergence branch substitutes the appropriate
switch momentum. The color factor of that branch is nonzero
in both scalar blocks. Neither dropping that derivative nor
identifying the two mixed momenta is allowed. The independent
vertex transfers make d=P3−P1 a full rank four-vector coordinate
when this face occurs. The DMM comparison has two mixed lines
with switch-only shifts and one massive line; YY has a single
massless ghost and one massive line.

## Massive parameter and the FFMM face

Combine the same-sign denominators before taking the boundary.
If the massive weight is t, write the remaining weights as
(1−t) times massless simplex weights y_i. After shifting the loop,
the effective squared mass is

    Delta = M t − (1−t)² A − t(1−t) C,
    A = sum_(i<j) y_i y_j P(P_i−P_j),
    C = sum_i y_i P(P_i−P_m).

The loop shift is first performed for real external arguments.
The parameter formula then supplies the analytic continuation
with the displayed denominator Delta−i0.
On a small fixed momentum ball and small transfers,
Re(partial_t Delta)>=M/2, including the complex deformation
below. The massless faces therefore occur at t=0. At t=1 the
effective mass is M. In FMY the q-quadratic contraction after
the loop shift gives the converted logarithm of Delta, and
the shifted numerator of size O(r²) multiplies its first inverse.
In FFMM the q-quadratic tensor terms have coefficients O(r²)
and multiply its first inverse. The fully shifted numerator
N(t) is O(r⁴) and multiplies its second inverse. Odd powers in
the shifted loop integrate to zero. Here r=|p|_E and |k|<<r;
the derivative-switch branch has an additional |k|/r gain.
These power counts follow from the actual numerator and the
four-dimensional radial measure. The first-inverse t integrals
are reduced to logs by integration by parts using Delta_t.
The second inverse is reduced first to its t=0 boundary and
a first-inverse bulk term. The t=1 endpoint is regular. The
simplex weights and the derivatives of Delta_t are kept.

For the FFMM boundary write y_2=s, y_1=(1−s)u,
y_3=(1−s)(1−u) and let b=1−s. Set
Pbar=u P1+(1−u)P3, D=u(1−u)P(d) and Q=P(P2−Pbar).
Then A=b(s Q+D) and the massless simplex Jacobian is b.
Thus the first-inverse face is governed by −s Q−D−i0
after cancellation of b. Its shifted numerator at s=0
contains exactly

    N0=−u(1−u)(p_e·d)(d·(P2−Pbar)).

This is O(r² |k|²), and is generally nonzero even when P(d)=0.
Additional smooth prefactors from the t integration do not
remove the two powers of d. Split the weighted numerator into
its s=0 value and s times a bounded smooth remainder O(r⁴).
The first part produces a genuine transfer logarithm
log(−D−i0). It cannot be collapsed pointwise on the null cone.

## Uniform nonzero momentum shells

Let delta bound the physical transfers on a fixed normalized
band, with r>=C_0 delta for large fixed C_0. On each angular
patch choose one component p_j with |p_j|>=c r. Deform that
component by i eta r with sign equal to that of the corresponding
Lorentz gradient component. For small fixed eta>0 the imaginary
parts of P(p+O(k)), including all exterior momenta and Q, are
at least c r² eta. The same statement holds for a reversed
orientation by changing the full shifted argument's sign.
In Delta the terms involving line 2 therefore contribute
a negative imaginary part of size at least
c x_2(1−x_2) r² eta with x_2=(1−t)s. All other invariants
depend only on real transfers. This deformation is independent
of the presence of a time component on the patch.

On t<=C_1 r² the logarithms are bounded in parameter integral
by 1+|log r|+|log eta|. The extra logs of
x_2(1−x_2) are integrable in the simplex. For the FMY UV
log difference, this region has size O(r²). On t>=C_1 r² the
difference from the zero-momentum log is O(r²/t), so its integral
is O(r²(1+|log r|)). The other FMY shifted and FFMM bulk terms
are bounded with their numerator powers by the t integrations
above. The constant subtraction is made after the common UV
conversion; its local coefficient is the inherited value.

In the FFMM face the s remainder is bounded by
O(r² eta^-1), since s/|s Q+D+i0|<=C/(r² eta).
For the s=0 numerator localize to s<=3/4 and integrate in s
using its derivative. At a positive common absorption epsilon,
after division by b the denominator is
−s Q−D−i epsilon/b. Its s derivative has magnitude at least
c r² eta+epsilon/b², and the derivative of its reciprocal is
bounded by C/(r² eta) on this support. The other region s>=1/2
has a direct imaginary bound and the b endpoint is integrable.
The integrated s=0 term costs at most

    C |k|² eta^-1 [1+|log delta|+|log eta|]

in normalized transfer seminorms. Indeed the boundary log
has D=delta² u(1−u) P(d/delta), whose transfer factor
log|P(d/delta)| is locally integrable even at its tip.
The compact normalized transfer domain and the full-rank
d coordinate give a fixed log integral. The u endpoints
are integrable. At each fixed delta the absorption is sent
to zero in this expression, retaining the same sign of the
log. If d is identically zero in a separately collapsed
comparison, N0 vanishes before introducing the logarithm.
The delta²(1+|log delta|) factor is bounded by
C r²(1+|log r|) in the present region.

The subtracted DMM core is independent of p at fixed transfers.
The two mixed numerators after shifting give the converted
log difference and a first-inverse term with coefficient
O(delta²). The massive t derivative and the two-massless
face A=u(1−u)P(d) give O(delta²(1+|log delta|)) after normalized
transfer smearing. The YY bubble is analytic near zero since
its first massive threshold is separated. For example its
log difference has Delta=t[M−(1−t)P(P_2−P_m)], so the
t endpoint log cancels. Its subtraction is O(r²+delta²).

The two exterior poles cost r^-4 eta^-2, canceled by the
four-dimensional p shell measure. Each extra fixed exterior
switch contributes one pole and its actual wave-operator
numerator O(delta²), producing (delta/r)² and one further
power of eta^-1. Thus the deformed shell of the subtracted
core is bounded by

    C_n eta^-N (delta/r)^(2n) r² (1+|log r|)

in normalized test seminorms for some finite N depending
on n. Log eta can be absorbed into N. To pass to the real
boundary, apply a compact almost-analytic extension of
the normalized test in the selected component p_j, of
order greater than N+1, and use the one-variable Cauchy
boundary formula. Its error derivative is O(eta^(N+1)).
The deformed integrals are holomorphic in that component
after smearing the independent transfers. All affected
invariants have the common sign above, so the real boundary
is the original Feynman product. The remaining d-only log
is integrated as a transfer distribution throughout.
This gives the corresponding shell bound without eta.
At fixed r, first collapse transfers on the deformed patch
and then pass through this dominated boundary formula. The
n=0 limit is the inherited nonconstant V883 branch, and
n>0 has the extra positive transfer powers.

## The momentum tip and transfer tails

On |p|<=C_0 delta first take the loop region |q|<=C_2 delta.
Rescale all loop, exterior and independent transfer momenta
together. For the unicyclic graph, loop q and one source
momentum together with the independently attached vertex
transfers give invertible linear coordinates on all free
edge momenta, with the other source momentum fixed by total
conservation. The massless boundaries are tensor pullbacks
in these coordinates. On the rescaled compact domain each
has its homogeneous scaling degree, not an absolute bound
on a Lorentzian propagator. A mixed line and a differentiated
ghost line each cost one power; a bare ghost costs two.
The FMY and FFMM inner total is at most three even without
the external derivative gain. The massive line is smooth
here. The q volume gives at least delta^(4−3)=delta.
The two exterior poles are neutralized by the p volume, and
every fixed extra exterior switch carries two compensating
derivatives. The zero-momentum constant subtracted on the
same original labels has the same tip bound when restricted
to this q region. In the collapsed FMY and DMM integrands
the q² contraction removes one common pole, and the FFMM
constant is zero.

For |q| of size rho>=C_2 delta, use Euclidean annuli q=rho U.
On each unit annulus the same-sign combined loop denominator
has normalized phase P(U+abar)+constant, with
|abar|<=C delta/rho. Its real derivative in one local
coordinate is bounded away from zero on a fixed patch.
Hence the translated one-variable Feynman power has uniform
test seminorms, including any fixed number of derivatives
with respect to the scaled external variables. This follows
directly by the submersion change of variable on each patch,
with the constant shift allowed to vary in the Feynman
simplex. If the massive denominator is far from zero it
can be treated as a smooth bounded factor. Subtracting the
zero-momentum shell therefore gains delta/rho. At low rho
the massive line is bounded and the massless degree d<=3
gives shell size rho^(4−d). Summing gives
O(delta(1+|log delta|)) at worst. At large rho the converted
proper FMY and DMM logarithms gain one inverse power in
the difference, and the differentiated FFMM is already
UV convergent. The common UV conversion contributes only
the original local polynomials, smooth under the small
transfer difference. The resulting q shell difference is
smooth in the normalized exterior variables, so these
seminorms suffice for sewing to the independent exterior
poles on the p tip region.

Write the physical transfers as k=R^-1 l and partition
the l variables into joint dyadic size L>=1. On a band put
delta=L/R. All profile transforms are Schwartz and at
least one argument is of size L, so the normalized-band
test seminorms decay faster than any power of L, even with
the transfer volumes and derivative factors. For delta
in the small-transfer region the preceding bounds are
summable over bands. For larger delta use the tempered
finite converted graph and the rapid switch-transform
tail, with the fixed localized momentum test. Its finite
distribution order costs only fixed powers of R and L.
For n=0, r²(1+|log r|) is summable at r=0. For each fixed
n>0 its product with (delta/r)^(2n) tends to zero on the
nonzero shells and is dominated by the same summable bound.
The tip itself tends to zero with its stated positive margin.

This qualifies the independent transfers of the subtracted
proper core in the stated localized Feynman comparison.
The proof preserves the finite graph conversion and does
not use a Euclidean absolute estimate on the real cone.
It does not justify the infinite exterior series for the
nonlocal core, additional independently switched internal
quadratic edges, or the complete feedback and causal
comparison. The two-color exterior result in V903 remains
a distinct local contribution.
