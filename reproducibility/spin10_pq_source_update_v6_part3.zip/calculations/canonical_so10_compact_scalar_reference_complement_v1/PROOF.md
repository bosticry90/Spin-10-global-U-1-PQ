# Scalar reference-root color complement of the mixed reference carrier

On a constant plateau the scalar part of the reference
cross is s(1-s) F_x E_(R,x). Its mass Euler is a scalar
on each representation and pairs to zero with the
skew field driver. Integration by parts of the scalar
kinetic Euler leaves the factor
(partial x)^t rho(partial C) x, with its common action
sign outside. Place the undifferentiated exterior
scalar at this root. The differentiated scalar and
ghost are now internal.

Join the ghost to an ordinary BCa vertex with exterior
C, and the scalar to a physical Bxx vertex with the
other exterior scalar. An ordinary BB line closes
the triangle. Its two endpoint derivatives leave
one exterior ghost derivative and one exterior scalar
derivative on the preserved transverse slice. At the
reference root the two internal derivatives contract.
The local term is of order two in external derivatives.
The scalar squared-mass remainder after cancelling the
hard scalar denominator must be retained in the full
kernel. The compact factor is s^3(1-s). If the
differentiated scalar at the root were exterior, its
extra exterior derivative would exceed this local
order.

For internal ordinary B color v and ghost k, the
transverse exterior-ghost vertex coefficient is
F_C-F_a, as in V945. Its product with the skew
scalar order [rho_k,rho_v]/2 gives the full stripped
color map. Reading all literal scalar source rows
checks rho itself. In (B,ghost) sector order the
four color maps are

    R_HH = C_H|H/2,   R_HM = C_H|M,
    R_MH = C_H|M/2,   R_MM = 4 P_M-C_H|M.

The factor in R_HM includes the direct derivative
on exterior C. In R_MM that derivative cancels
the internal-ghost contrast for light exterior C.
The full sum is C_H/2+4 P_M. These results do not
use a scalar mass value.

Let W_H,W_M be the mixed reference maps of V957.
The exact color identity is

    T = W_H-W_M+R_MM,

where T is the V949 residual shape. Thus a formal
span is available once this distinct reference
placement is included. On the other hand, with
one coefficient on the complete mixed reference
family and one on the complete scalar reference
family, the light center and broken singlet fix
those coefficients to -1 and +1. Their sum gives
T+C_H/2, leaving a nonzero color condition. The
executable verifies both assertions on the full
ordered color maps.

This establishes a possible independent sector
direction and a restriction on the two common
family weights. It does not justify independent
sector coefficients in the inherited finite map
or determine the Lorentz signs and profiles of
the actual compact terms. Both routes share the
model, software and authorship.
