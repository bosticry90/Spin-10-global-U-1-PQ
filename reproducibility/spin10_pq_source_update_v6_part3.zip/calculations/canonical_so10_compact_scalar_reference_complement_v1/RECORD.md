# V958 pre-execution contract

Test the alternate scalar reference-master placement
left open by V957. Freeze the literal scalar source,
the BCa derivative table, the transverse BB and
massless ghost edges and the skew scalar slot.
Place one exterior scalar at the reference root
and the exterior ghost at BCa.

Compare the full four-sector color tensor against
the joined Casimirs. Test both independent sector
weights and one common weight on each complete
reference family. Preserve the full compact and
normalization equations separately. No finite weight
is chosen. Native 120 s, final 180 s including E4
cap 120 s, 8 GiB sampled private, 350 MiB launch
floor, 8 MiB artifact and 32 MiB packet.
No authority change.
