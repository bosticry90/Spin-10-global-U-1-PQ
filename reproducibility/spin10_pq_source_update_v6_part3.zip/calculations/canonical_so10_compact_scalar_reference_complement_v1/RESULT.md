# V958 result — scalar reference-root color complement

The alternate scalar reference-root triangle supplies
a new color direction at s^3(1-s). With one scalar
exterior at the reference root and the ghost at the
BCa vertex, the broken-gauge and broken-ghost sector
is 4 P_M-C_H|M. All four sectors agree between the
literal routes, including the direct exterior ghost
derivative and 12,560 scalar-driver rows.

The full target satisfies T=W_H-W_M+R_MM in the
stripped color basis. Independent sector coefficients
therefore span the scalar plateau remainder. Using
one common coefficient on each complete reference
family instead leaves C_H/2 after the center and
singlet equations are imposed.

This compares color and switch support. It does not
assign independent sector freedoms, Lorentz signs
or actual finite weights. Both routes share model,
conventions and software.
