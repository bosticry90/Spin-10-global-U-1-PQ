"""Test the scalar reference-master alternate exterior placement."""

from collections import defaultdict
import importlib.util
import sys

import sympy as sp

from execute import ROOT, run_worker


path = ROOT / "calculations/canonical_so10_joint_nonlinear_source_span_v2/joint_nonlinear.py"
spec = importlib.util.spec_from_file_location("nonlinear_source_owner", path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)
seagull = source.seagull


def check(phase):
    _, entries, _, f, _, _ = source.owner.inputs(phase)
    folder = ROOT / "calculations/canonical_so10_unprobed_compact_all_coupling_v1"
    rows = seagull.read(folder / f"{phase}_full_current.json.gz")["current"]["complete_S_GF_source"]
    H, M = range(12), range(12,45)
    names = ("HH","HM","MH","MM")
    F = defaultdict(lambda:sp.S.Zero)
    drivers = 0
    for g,word,cells in rows:
        if g != 1 or len(word) != 3:
            continue
        (i,di),(j,dj),(k,dk) = word
        if not 553 <= j < 598:
            continue
        c = j-553
        if 180 <= i < 508 and 823 <= k < 1151:
            assert not(di or dj or dk)
            assert unpack(cells) == entries[c][k-823,i-180]
            drivers += 1
        if i < 180 and i%4 == 1 and 598 <= k < 643 and not di:
            assert (dj,dk) in (([1],[]),([],[1]))
            F[i//4,k-598,c] += unpack(cells)*(1 if dj else -1)
    assert drivers == 12560
    W = {key:defaultdict(lambda:sp.S.Zero) for key in names}
    for (v,k,c),z in source.owner.clean(F).items():
        sector = ("H" if v in H else "M")+("H" if k in H else "M")
        for a,value in f[k,v]:
            W[sector][a,c] += z*value/2
    W = {key:source.owner.clean(z) for key,z in W.items()}

    C = defaultdict(lambda:sp.S.Zero)
    for h in H:
        for j in range(45):
            for k,x in f[h,j]:
                for i,y in f[h,k]:
                    C[i,j] -= x*y
    C = source.owner.clean(C)
    Ch = {(i,j):z for (i,j),z in C.items() if i in H and j in H}
    Cm = {(i,j):z for (i,j),z in C.items() if i in M and j in M}
    Ph = {(i,i):sp.S.One for i in H}
    Pm = {(i,i):sp.S.One for i in M}
    I = source.add(Ph,Pm)
    h = source.add({},Ch,sp.Rational(1,2))
    m = source.add({},Cm,sp.Rational(1,2))
    assert W == {"HH":h,"HM":Cm,"MH":m,"MM":source.add(source.add({},Pm,4),Cm,-1)}

    T = source.add(source.add({},C,sp.Rational(1,2)),Ph,-4)
    RH = m
    RM = source.add(source.add(source.add({},I,4),h,-1),Cm,-1)
    assert source.add(source.add(RH,RM,-1),W["MM"]) == T
    both = source.add(RH,RM)
    scalar = {}
    for A in W.values():
        scalar = source.add(scalar,A)
    assert source.add(scalar,both,-1) != T
    assert source.add(source.add(scalar,both,-1),C,-sp.Rational(1,2)) == T
    # Light center and broken singlet force the common coefficients
    # of the two summed families to -1 and +1 respectively.
    a,b = sp.symbols("a b")
    assert sp.solve((4*a+4,4*a+4*b),(a,b)) == {a:-1,b:1}
    return {"literal_scalar_driver_rows":drivers,"scalar_reference_sector_entries":{k:len(v) for k,v in W.items()},
            "reference_color_identity":"T = W_H - W_M + R_MM",
            "independent_sector_color_span_suffices":True,
            "one_weight_per_complete_family_suffices":False,
            "remaining_equal_family_color":"C_H/2"}


def unpack(cells):
    assert all(p[:2] == [0,0] for p,_,_ in cells)
    return seagull.unpack([([0,*p],n,d) for p,n,d in cells])


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
