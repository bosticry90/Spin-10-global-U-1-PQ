# One finite functional supplies a prospective mixed carrier

Qualification requires the completed separate final receipt. Work in the
original unshifted A0,g<=1,first-u H/M,rho,beta family, with the fixed metric
constructor and qualified reference/heat class. u/g are even, rho/beta odd
and placed LEFT. Sources remain external until after all differentiations.
Q below is Q_Sigma, never a new beta-deformed Q. All equalities of local
functionals retain their explicit ordinary-current representatives.

## Define the common map before its derivatives

In the original owner's Minkowski convention set

  F_R[Z]=Gamma_ref[A]+(i/2) T_kappa(L_D[Z]),
  L_D[Z]=log(1+Gref_D V_D[Z]),
  T_kappa=tau_h,mu-alpha'_4+(kappa-1-log(16pi))*alpha4/2.

V_D is the FULL graded Gaussian Taylor endomorphism, with the actual
evaluation-dual/LEFT signs. It is not an unsigned Hessian with an odd marker
pulled across field derivatives. The reference, background heat operator,
scale and kappa are the SAME for every derivative. The fixed metric lift is
V848, source-nonlinear Taylor identity V849, actual structural IR/UV gates
V850/851 and local external first-jet bridge V852. No new evanescent term is
chosen. Internal vector D traces and sphere-normalization derivatives survive
until alpha'_4. The operator logarithm is a full formal coefficient family,
not a nonlocal series truncated at eight.

For the declared older full heat/reference family define, prospectively,

  C[Z]=F_R[Z]-F_heat,FP[Z].

This difference uses complete ordered heat words, all heat-power/prefactor
jets and separately declared common logarithmic normalizations. The shared
Gamma_ref is retained in both functionals; it cancels only their difference.
V851's finite local UV bound and the inherited remainder comparison make
the difference local at each requested coefficient. Its n<=8 bound applies
to these local conversion words ONLY. Words whose local difference vanishes
are allowed in the unreduced expression; none is called a nonzero amplitude.
No inverse physical coupling/mass/width is used.

The actual recovered positive-heat identification is a different claim:
V847 verifies only the selected M profile,231 coordinates/858 Green entries,
at t_new=2t_old and delta=epsilon. Its finite clock shift and corrected absolute
bubble argument remain. Transport from the Minkowski convention uses the
qualified V848 Wick map. This construction does not assert whole643 equality
to the current recovered heat functional, choose an H profile or assume a
target uses only M edges. That identification needs its actual support/profile
bridge. The following formal-parent statements retain this boundary.

## Full breaking and its direct rho variation

Let Sigma_rho=Sigma+rho K_D, F_i=(-1)^p_i Sigma_Ji,E_i=Sigma_zi and
B[Sigma]=sum_i F_i E_i. K_D is odd, D even. The actual chart gives

  Dzi=-EL^L_Ji K_D,  DJi=EL^L_zi K_D,
  Q_rho=Q+rho D,
  B[Sigma_rho]=B0+rho B1,
  B1=sum_i[(Dzi)E_i-F_i(DJi)]=D Sigma

as integrated functionals. The minus sign comes from moving rho past odd
F_i in the second product. All g/u terms are included before introducing
beta. A bare projected DS or mixed-hatted zero cannot assign C'[B1] zero.
Blocks remain complete action-defined programs: master/support identities
may make individual programs zero, but a formal word count does not decide
that and is not a measured nonzero coefficient.

Introduce the SAME even Gaussian parent Z=Sigma_rho+beta B[Sigma_rho].
Define the insertion by LEFT_beta F_R[Z]|beta0 and all counterterm companions
by differentiating C[Z]. In particular

  A=C[Sigma],
  I_D,C=LEFT_rho C[Sigma_rho]|0,
  C_Brho=LEFT_rho LEFT_beta C[Sigma_rho+beta B[Sigma_rho]]|0.

Splitting the action's rho dependence gives exactly

  C_Brho=C'[B1]+C''[K_D,B0].

The ordered bilinear term means LEFT_rho LEFT_beta C[Sigma+rhoKD+betaB0]|0.
It is not an independently normalized product. Reversing the two odd
derivatives negates the coefficient. The direct B1 seagull is separate from
the two ordered covariance legs, and its letter has heat length one.

## Complete ordered local words

Extract the operator blocks from the FULL marked Gaussian parent AFTER the
LEFT Taylor conventions, then write

  X=X0+gXg+uXu+guXgu+rhoK0+g*rhoKg
       +beta(B0+gBg+uBu+guBgu+rhoBr+g*rhoBgr+u*rhoBur+gu*rhoBgur).

The block symbols here stand for endomorphism coefficients, not tree density
names with untested Hessian signs. Their parity equals their odd marker
degree, so each displayed marked term is even. There is no u*rhoK term
because fixed KD is independent of u. Nonnegative coupling/probe powers
above the requested grades cannot feed back by differentiation; no inverse
physical parameter is admitted. Formal coefficient extraction is not a
physical nilpotence assumption for g/u.

All ordered log words for n1..8 and every grade0/1 are constructed before
applying the linear finite map. Native coefficient-left multiplication and
an independent exterior permutation agree exactly. Their lower-order guard is

  [beta*rho]X=Br,
  [beta*rho]X²=K0 B0-B0 K0+X0 Br+Br X0.

The second line has log weight-1/2. Moving rhoK past beta gives the first
positive covariance word; moving betaB past rho gives the negative one.
Bare heat finite parts are not assumed cyclic and K/B are not commuted.
Each word retains its true covariance length n, even for a multi-marker
seagull. All heat finite terms, first jet and common log/reference definitions
remain attached to that ordered word's map.

There are13,832 unreduced formal log words and10,308 mixed words. The latter
split into1,740 direct seagull and8,568 ordered covariance words. These are
universal action-program expressions, not nonzero color amplitudes or
independent normalization parameters. Controls have nonzero WORD differences
when omitting the seagull, either covariance order, reversing odd derivatives,
commuting K/B or assigning heat length by marker count. Evaluation on the
actual action or a specific projection can make some differences vanish;
no projected sensitivity is claimed from these formal controls alone.

## Converted broken identity and the retained carrier

V849's arbitrary-source identity is
T²B/2=Q_Sigma(T²Sigma/2)+sum(TF_i)(TE_i), including E*T²F/source-Euler legs.
Two even polarizations give the full Hessian/tangent/adjoint chain, with all
source operations and currents. Apply the SAME admitted lifted cyclic/Stokes
map, keeping commutator defects through alpha'_4. The differential tangent
has no degree-minus-four symbol, first dimension jet or hard finite constant
in that map. This proves the formal-parent relation

  Q_Sigma F_R=I_B,R.

It does NOT set the raw heat Jacobian, covariance or regulator response zero.
Nor does it use B=0 or Q_Sigma²=0. Gamma_ref is fixed by Q A=0, not deleted.

Write F_R[Sigma_rho]=F_R+rho I_D,R. Since Q is odd,
Q(rho I_D,R)=-rho Q I_D,R. The rho coefficient of the preceding relation is

  D F_R-Q I_D,R=LEFT_rho I_B,R.

Consequently, for a heat family to which this common difference actually
applies, define R_heat=D F_heat-Q I_D,heat-LEFT_rho I_B,heat. Then

  R_heat=C_Brho-D C+Q I_D,C.

This is a compatibility equation carrying the full mixed insertion, not a
homogeneous auxiliary D law. It explains what the common counterterm product
must transport without selecting a coefficient to cancel R_heat. The named
current/regulator interpretation still requires its action-defined source,
mean and profile bridges; the equation is not the geometric W5 target.

## Scientific disposition

A prospective source-integrable local conversion family and its explicit
ordered mixed carrier have been constructed at operator level. Its derivatives
cannot be chosen independently. This is more than the earlier list of
unknown contact coefficients, but less than a qualified common restoration.

No actual alpha'_4/color coefficient was evaluated. Reality/background and
independent contact normalizations must still be checked where required.
Fixed V833/V834 data, V845's nonzero actual regulator response and the original
geometric W1-W7 target are not automatically equal to this candidate family.
Known zero/master/support identities should be applied before any new
coefficient campaign. Unselected actual profiles remain explicit missing
applicability inputs. QAP/measure, full background/chiral sectors, all-order
equivalence, E5/A5 and physical viability stay open. Shared action, conventions,
Python and AI authorship limit independence; exact formal agreement adds no
experimental evidence for Spin(10) or PQ physics.
