from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from collections import Counter
import gzip,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/common-conversion-carrier-v1-2026-11-08')
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
# Marker order is g,u,beta,rho. These are coefficients of the FULL marked
# Gaussian endomorphism, not unsigned Hessians factored through LEFT fields.
BLOCKS={0:'X0',1:'Xg',2:'Xu',3:'Xgu',8:'K0',9:'Kg',4:'B0',5:'Bg',6:'Bu',7:'Bgu',12:'Br',13:'Bgr',14:'Bur',15:'Bgur'}
MAP=dict(loop_convention='ORIGINAL_MINKOWSKI_i_OVER_2_THEN_QUALIFIED_WICK',converted='Gamma_ref+(i/2)*T_kappa(log(1+X_D))',T_kappa='tau_h_mu-alpha_prime4+(kappa-1-log(16pi))*alpha4/2',conversion='F_R-F_heat_FP_WITH_SAME_REFERENCE_AND_DECLARED_NORMALIZATIONS',word_heat_length='NUMBER_OF_COVARIANCE_LETTERS_NOT_MARKER_DEGREE',heat_power_prefactor_jets='ALL_RETAINED',internal_D_traces_and_sphere_jet='RETAINED_UNTIL_ALPHA_PRIME4',current_actual_profile_identification='SELECTED_M_ONLY_231_COORDINATES_858_GREEN_ENTRIES_IF_SUPPORT_MATCHES',whole643_current_heat_equality='NOT_QUALIFIED',unselected_H_profile='NOT_CHOSEN',geometric_W5_and_fixed_V833_match='NOT_QUALIFIED')
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def clean(p):return{k:v for k,v in p.items()if v}
def add(*ps):
    out={}
    for p in ps:
        for k,v in p.items():out[k]=out.get(k,F(0))+v
    return clean(out)
def scale(p,c):return{k:v*c for k,v in p.items()if v*c}
def encode(p):return[[n,mask,list(word),v.numerator,v.denominator]for(n,mask,word),v in sorted(p.items())if v]
def native():
    level={(0,()):F(1)};out={};counts=[]
    for n in range(1,9):
        new={}
        for(mask,word),v in level.items():
            for bit in BLOCKS:
                if mask&bit:continue
                oddleft=((mask>>2)&1)+((mask>>3)&1);oddright=((bit>>2)&1)+((bit>>3)&1)
                sign=(-1)**(oddleft*oddright+int(bool(mask&8)and bool(bit&4)))
                key=mask|bit,word+(bit,);new[key]=new.get(key,F(0))+sign*v
        level=clean(new);an=F((-1)**(n+1),n)
        for(mask,word),v in level.items():out[n,mask,word]=an*v
        counts.append([n,len(level)])
    return out,counts
def exterior_sign(word):
    odd=[]
    for at,bit in enumerate(word):
        if bit&4:odd.append(0)
        if bit&8:odd.append(1)
        if bool(bit&4)!=bool(bit&8):odd.append(2+at)
    assert len(odd)==len(set(odd))
    return(-1)**sum(x>y for i,x in enumerate(odd)for y in odd[i+1:])
def replay():
    out={}
    def visit(word,used,n):
        if len(word)==n:
            out[n,used,word]=F((-1)**(n+1)*exterior_sign(word),n);return
        for bit in sorted(BLOCKS):
            if not used&bit:visit(word+(bit,),used|bit,n)
    for n in range(1,9):visit((),0,n)
    return out
def mixed(p):return{k:v for k,v in p.items()if k[1]&12==12}
def wrong_commute(p):
    out={}
    for(n,mask,word),v in p.items():
        ww=list(word)
        for i in range(len(ww)-1):
            if ww[i]in[4,5,6,7]and ww[i+1]in[8,9]:ww[i],ww[i+1]=ww[i+1],ww[i]
        key=n,mask,tuple(ww);out[key]=out.get(key,F(0))+v
    return clean(out)
def save(n,z):
    blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    if len(blob)>8*1024**2:
        with(C/(n+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
        raise AssertionError('COMPLETE_OVERFLOW_NOTPASS')
    with(O/n).open('xb')as f:f.write(blob)
    assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=32*1024**2
    return dict(file=n,sha256=digest(O/n),bytes=len(blob))
def main():
    tick=time.perf_counter();watch=threading.Timer(90,lambda:os._exit(124));watch.daemon=True;watch.start()
    for n,h in read(O/'preparation.json')['sha256'].items():assert digest(R/n)==h,n
    primary,counts=native();second=replay();assert primary==second
    guard={(n,word):v for(n,mask,word),v in primary.items()if mask==12 and n<=2}
    assert guard=={(1,(12,)):F(1),(2,(8,4)):F(-1,2),(2,(4,8)):F(1,2),(2,(0,12)):F(-1,2),(2,(12,0)):F(-1,2)}
    M=mixed(primary);seagull={};covariance={};ordered={};classification=[]
    for(n,mask,word),v in M.items():
        both=[i for i,b in enumerate(word)if b&12==12];K=[i for i,b in enumerate(word)if b in[8,9]];bb=[i for i,b in enumerate(word)if b in[4,5,6,7]]
        if both:assert len(both)==1 and not K and not bb;seagull[n,mask,word]=v;kind='DIRECT_Brho_SEAGULL'
        else:assert len(K)==len(bb)==1;covariance[n,mask,word]=v;kind='ORDERED_K_BEFORE_B'if K[0]<bb[0]else'ORDERED_B_BEFORE_K';ordered[n,mask,word]=kind
        classification.append([n,mask,list(word),kind])
    assert add(seagull,covariance)==M
    omitKbefore={k:v for k,v in covariance.items()if ordered[k]=='ORDERED_K_BEFORE_B'};omitBbefore={k:v for k,v in covariance.items()if ordered[k]=='ORDERED_B_BEFORE_K'}
    reverse=scale(M,-1);wrongcomm=wrong_commute(M);differences=dict(omit_direct_Brho=scale(seagull,-1),omit_K_before_B=scale(omitKbefore,-1),omit_B_before_K=scale(omitBbefore,-1),wrong_commute_K_and_B=add(wrongcomm,scale(M,-1)),reverse_LEFT_odd_order=add(reverse,scale(M,-1)))
    assert all(differences.values())
    wrongheat=[[n,mask,list(word),v.numerator,v.denominator,mask.bit_count()]for(n,mask,word),v in sorted(M.items())if n!=mask.bit_count()];assert wrongheat
    target=Counter(mask for n,mask,word in M);assert set(target)=={12,13,14,15}
    packet=dict(complete_block_program_definitions=[[mask,name,'LEFT_MARKER_COEFFICIENT_OF_FULL_Gref_TIMES_MARKED_GAUSSIAN_TAYLOR_ENDOMORPHISM',((mask>>2)&1)^((mask>>3)&1)]for mask,name in sorted(BLOCKS.items())],fixed_map_definition=MAP,all_local_log_words=encode(primary),all_n_counts=counts,complete_mixed_beta_rho_carrier=encode(M),complete_direct_seagull=encode(seagull),complete_ordered_covariance=encode(covariance),complete_carrier_word_classification=classification,complete_reversed_LEFT_order=encode(reverse),complete_negative_control_differences={name:encode(p)for name,p in differences.items()},complete_wrong_heat_length_assignments=wrongheat,all_series_orders1_through8_local_ONLY=True,no_color_or_loop_coefficient_evaluated=True)
    artifact=save('complete_common_carrier_operator_words.json.gz',packet)
    result=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='PROSPECTIVE_COMMON_CONVERSION_ORDERED_CARRIER_WORDS_CONSTRUCTED',artifact=artifact,complete_log_words=len(primary),complete_mixed_words=len(M),direct_seagull_words=len(seagull),ordered_covariance_words=len(covariance),all_n_counts=counts,negative_control_nonzero_words={name:len(p)for name,p in differences.items()},wrong_heat_length_rows=len(wrongheat),mixed_grade_counts=[[mask,n]for mask,n in sorted(target.items())],formal_operator_candidate_NOT_actual_color_amplitude=True,current_heat_profile_bridge_M_only=True,full_common_restoration_E5_NOT_established=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result.json',result);print('RESULT '+json.dumps(result,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
