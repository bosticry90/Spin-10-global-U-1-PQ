# Separate V853 directional word and common-map validation

One180s afterimports,8GiBsampled/350MiBfloor,32MiBpacket/8MiBartifact.
Freeze actualsources/copies/inputs/ownerreceipts/proof/results/navigation.
No producer import. Reconstruct ALL n1..8 words using independent directional
insertions: baseeven X letters; one K; one B; direct Br or both orderedK/B
legs. Keep LEFT_rho LEFT_beta and actual n covariance length. Reproduce all
complete partitions, counts, controls and negative differences. Preserve map
definition including profileceiling, fullreference/clock/heatpower/firstjet.
Review actualoperatorchain and rho-minus sign, noB0/Q²0 assumption and no
raw heat-Jacobian zero inference. Formal wordcontrols are not modelamplitudes.

Authenticate rawhashes,sourcecopies,preparations,current/storedGitencodings
EXACTor declaredtextCRLFonly,completedcapture/resources,oldGittree,state,
savedoldnavbytes,currentlinks/exacthistoricalREADMEsuffix. E4fixedcontextonce
0,0,0,0,0,2/sevenNOTPASS. Full failurespreserved. Exactstagingbeforelocalcommit.
No actualwhole643heatprofilematch,independentfixedcontactmatch,W5,E5promotion.
