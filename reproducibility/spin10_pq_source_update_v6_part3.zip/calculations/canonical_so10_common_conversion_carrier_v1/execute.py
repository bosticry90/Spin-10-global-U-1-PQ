from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/common-conversion-carrier-v1-2026-11-08')
def digest(p):return sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='1908611ddf1db850e3063520ed982dfdcca7c096'and not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).strip()
old=json.loads((R/'calculations/canonical_so10_augmented_source_dimension_jet_v1/preparation_validation.json').read_bytes());names=set(old['sha256'])|{'docs/RESEARCH_EXECUTION_HANDOFF_V852.md','calculations/canonical_so10_augmented_source_dimension_jet_v1/validation_receipt.json','calculations/canonical_so10_augmented_source_dimension_jet_v1/capture_validation.json'}
for folder in['canonical_so10_mixed_probe_slavnov','canonical_so10_geometric_ward_products','canonical_so10_actual_normalization_assembly','canonical_so10_heat_clock_applicability_v1']:
    for p in(R/'calculations'/folder).iterdir():
        if p.name in['DERIVATION.md','RESULT.md','PROOF_V3.md','RESULT_V3.md','validation_receipt.json','validation_receipt_v5.json','ACCEPTANCE_RECONCILIATION.md']:names.add(p.relative_to(R).as_posix())
encodings=[]
for n in sorted(names):
    live=(R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R)
    if live!=stored:assert live.replace(b'\r\n',b'\n')==stored and subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set'),n
    encodings.append(dict(file=n,checkout_sha256=sha256(live).hexdigest(),git_blob_sha256=sha256(stored).hexdigest(),exact_equal=live==stored,only_CRLF_to_LF=live.replace(b'\r\n',b'\n')==stored))
C.mkdir(exist_ok=False)
for name,out in[('README.md','README_before.md'),('docs/COMMON_RESTORATION_CAMPAIGN_V1.md','campaign_before.md')]:
    with(C/out).open('xb')as f:f.write((R/name).read_bytes())
with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
dump(O/'input_encoding_bindings.json',dict(bindings=encodings));dump(C/'input_encoding_bindings.json',dict(bindings=encodings))
for n in['RECORD.md','compute.py','execute.py']:
    if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
    with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names|={p.relative_to(R).as_posix()for p in O.iterdir()if p.is_file()};prep=dict(base_HEAD=head,sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation.json',prep);dump(C/'preparation.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'compute.py')]);dump(O/'capture.json',cap);dump(C/'capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
