from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from collections import Counter
from hashlib import sha256
import gzip,json,os,re,subprocess,sys,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'calculations';C=Path('D:/Codex-Research/ToE-Next/research-control-records/common-conversion-carrier-v1-2026-11-08')
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,z):
    with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def decode(rows):
    p={(n,m,tuple(w)):F(num,den)for n,m,w,num,den in rows};assert len(p)==len(rows);return p
def clean(p):return{k:v for k,v in p.items()if v}
def sub(p,q):
    out=dict(p)
    for k,v in q.items():out[k]=out.get(k,F(0))-v
    return clean(out)
def directional_words():
    # Independent chain rule: fill unmarked even slots, or mark one K/B,
    # or the direct Br, or two DISTINCT K/B slots. No envelope multiplication.
    answer={};partition={}
    def fill(n,fixed,oddmask,orientation,kind):
        def rec(at,word,gu):
            if at==n:
                key=n,gu|oddmask,tuple(word);assert key not in answer
                answer[key]=F((-1)**(n+1)*orientation,n);partition[key]=kind;return
            choices=[fixed[at]]if at in fixed else[0,1,2,3]
            for block in choices:
                evenbits=block&3
                if gu&evenbits:continue
                rec(at+1,word+[block],gu|evenbits)
        rec(0,[],0)
    for n in range(1,9):
        fill(n,{},0,1,'BASE')
        for at in range(n):
            for k in[8,9]:fill(n,{at:k},8,1,'FIRST_RHO')
            for k in[4,5,6,7]:fill(n,{at:k},4,1,'FIRST_BETA')
            for k in[12,13,14,15]:fill(n,{at:k},12,1,'DIRECT_Brho_SEAGULL')
        for ki in range(n):
            for bi in range(n):
                if ki==bi:continue
                for k in[8,9]:
                    for b in[4,5,6,7]:fill(n,{ki:k,bi:b},12,1 if ki<bi else -1,'ORDERED_K_BEFORE_B'if ki<bi else'ORDERED_B_BEFORE_K')
    return answer,partition
def main():
    tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='1908611ddf1db850e3063520ed982dfdcca7c096'
    for n,h in read(O/'preparation_validation.json')['sha256'].items():assert digest(R/n)==h,n
    saved={'README.md':C/'README_before.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md':C/'campaign_before.md'};pp=read(O/'preparation.json');assert pp==read(C/'preparation.json')
    for n,h in pp['sha256'].items():assert digest(saved[n]if n in saved else R/n)==h,n
    enc=read(O/'input_encoding_bindings.json');assert enc==read(C/'input_encoding_bindings.json')
    for row in enc['bindings']:
        n=row['file'];live=(saved[n]if n in saved else R/n).read_bytes();stored=subprocess.check_output(['git','show','HEAD:'+n],cwd=R);assert sha256(live).hexdigest()==row['checkout_sha256']and sha256(stored).hexdigest()==row['git_blob_sha256'];assert row['exact_equal']==(live==stored)and row['only_CRLF_to_LF']==(live.replace(b'\r\n',b'\n')==stored)and(row['exact_equal']or row['only_CRLF_to_LF'])
        if live!=stored:assert subprocess.check_output(['git','check-attr','text','--',n],cwd=R,text=True).strip().endswith(': text: set')
    for p in O.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name.removesuffix('.source.txt')).read_bytes()
    cap=read(O/'capture.json');assert cap==read(C/'capture.json')and cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']and all(0<x['private_bytes']<=8*1024**3 for x in cap['all_resource_samples']);result=read(O/'result.json');assert result['elapsed_after_imports']<90
    art=result['artifact'];assert digest(O/art['file'])==art['sha256']and(O/art['file']).stat().st_size==art['bytes'];packet=load(O/art['file']);formal,classification=directional_words();assert formal==decode(packet['all_local_log_words'])
    counts=Counter(n for n,m,w in formal);assert[[n,k]for n,k in sorted(counts.items())]==packet['all_n_counts']==result['all_n_counts']
    mixed={k:v for k,v in formal.items()if k[1]&12==12};direct={k:v for k,v in mixed.items()if classification[k]=='DIRECT_Brho_SEAGULL'};cov={k:v for k,v in mixed.items()if k not in direct};assert mixed==decode(packet['complete_mixed_beta_rho_carrier'])and direct==decode(packet['complete_direct_seagull'])and cov==decode(packet['complete_ordered_covariance'])
    recorded_class={(n,m,tuple(w)):kind for n,m,w,kind in packet['complete_carrier_word_classification']};assert len(recorded_class)==len(packet['complete_carrier_word_classification'])and recorded_class=={k:classification[k]for k in mixed}
    # LEFT-rho AFTER LEFT-beta gives +; LEFT-rho first crosses beta once.
    reversed_poly={k:-v for k,v in mixed.items()};assert reversed_poly==decode(packet['complete_reversed_LEFT_order'])
    kept_direct={k:v for k,v in mixed.items()if k not in direct};kept_Kfirst={k:v for k,v in mixed.items()if classification[k]!='ORDERED_K_BEFORE_B'};kept_Bfirst={k:v for k,v in mixed.items()if classification[k]!='ORDERED_B_BEFORE_K'};commuted={}
    for(n,m,w),v in mixed.items():
        ww=list(w)
        for at in range(len(ww)-1):
            if ww[at]&12==4 and ww[at+1]&12==8:ww[at:at+2]=ww[at:at+2][::-1]
        key=n,m,tuple(ww);commuted[key]=commuted.get(key,F(0))+v
    controls=dict(omit_direct_Brho=sub(kept_direct,mixed),omit_K_before_B=sub(kept_Kfirst,mixed),omit_B_before_K=sub(kept_Bfirst,mixed),wrong_commute_K_and_B=sub(clean(commuted),mixed),reverse_LEFT_odd_order=sub(reversed_poly,mixed))
    assert all(controls.values())and{n:decode(z)for n,z in packet['complete_negative_control_differences'].items()}==controls
    heat=[]
    for(n,m,w),v in sorted(mixed.items()):
        wrong=sum(bool(m&(1<<bit))for bit in range(4))
        if wrong!=n:heat.append([n,m,list(w),v.numerator,v.denominator,wrong])
    assert heat==packet['complete_wrong_heat_length_assignments']and len(heat)==10048
    guard={(n,w):v for(n,m,w),v in mixed.items()if m==12 and n<=2};assert guard=={(1,(12,)):F(1),(2,(8,4)):F(-1,2),(2,(4,8)):F(1,2),(2,(0,12)):F(-1,2),(2,(12,0)):F(-1,2)}
    expected_names={0:'X0',1:'Xg',2:'Xu',3:'Xgu',8:'K0',9:'Kg',4:'B0',5:'Bg',6:'Bu',7:'Bgu',12:'Br',13:'Bgr',14:'Bur',15:'Bgur'}
    assert packet['complete_block_program_definitions']==[[m,name,'LEFT_MARKER_COEFFICIENT_OF_FULL_Gref_TIMES_MARKED_GAUSSIAN_TAYLOR_ENDOMORPHISM',int(bool(m&4)!=bool(m&8))]for m,name in sorted(expected_names.items())]
    mapping=packet['fixed_map_definition'];assert mapping['T_kappa']=='tau_h_mu-alpha_prime4+(kappa-1-log(16pi))*alpha4/2'and mapping['word_heat_length']=='NUMBER_OF_COVARIANCE_LETTERS_NOT_MARKER_DEGREE'and mapping['current_actual_profile_identification']=='SELECTED_M_ONLY_231_COORDINATES_858_GREEN_ENTRIES_IF_SUPPORT_MATCHES'and mapping['whole643_current_heat_equality']=='NOT_QUALIFIED'and mapping['unselected_H_profile']=='NOT_CHOSEN'
    assert len(formal)==13832 and len(mixed)==10308 and len(direct)==1740 and len(cov)==8568
    assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R)
    assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md','docs/COMMON_RESTORATION_CAMPAIGN_V1.md']
    state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);live=(R/'README.md').read_bytes();assert live.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792'and b'[Current execution handoff](docs/RESEARCH_EXECUTION_HANDOFF_V853.md)'in live
    links=[]
    for q,txt in[(R/'README.md',live[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V853.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V853.md').read_text(encoding='utf-8')),(O/'RESULT.md',(O/'RESULT.md').read_text(encoding='utf-8'))]:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',txt):
            if target.startswith(('http:','https:','#')):continue
            dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(R)and dest.exists();links.append([q.relative_to(R).as_posix(),target])
    command=[sys.executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);ec=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_capture.json',ec);dump(C/'e4_capture.json',ec);assert e.returncode==0
    events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[z['exit_code']for z in events if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(z for z in events if z['event']=='step_finished'and z['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    assert sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=32*1024**2
    files=[p for p in O.iterdir()if p.is_file()]+[R/'README.md',R/'docs/COMMON_RESTORATION_CAMPAIGN_V1.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V853.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_PROSPECTIVE_COMMON_CONVERSION_AND_ORDERED_MIXED_CARRIER_CONSTRUCTION',base_HEAD=head,state_sha256=state,complete_log_words=len(formal),mixed_words=len(mixed),seagull_words=len(direct),covariance_words=len(cov),independent_directional_chain_rule_all_words_match=True,all_control_differences_checked=True,operator_broken_and_rho_transport_proof_reviewed=True,formal_word_controls_NOT_actual_nonzero_amplitudes=True,actual_heat_identification_M_support_only=True,fixed_normalization_W5_E5_NOT_qualified=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',maximum_sampled_primary_private_bytes=max(x['private_bytes']for x in cap['all_resource_samples']),sampled_not_continuous_peak=True,checked_local_links=links,files_excluding_pending_receipt_capture={p.relative_to(R).as_posix():digest(p)for p in files},shared_action_conventions_Python_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','E4_step_exits','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
