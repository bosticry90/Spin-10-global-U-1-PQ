from pathlib import Path
from hashlib import sha256
import ast,json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/cartan-generator-residual-g1-v1-2026-11-08');digest=lambda q:sha256(q.read_bytes()).hexdigest()
def dump(path,z):
 with path.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert not(O/'preparation_diagnosis.json').exists();old=json.loads((O/'preparation.json').read_bytes())
for n,h in old['sha256'].items():assert digest(R/n)==h,n
assert json.loads((O/'capture.json').read_bytes())['exit_code']==1
for n in['DIAGNOSTIC_RECORD.md','diagnosis.py','run_diagnosis.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
prep=dict(base_HEAD=old['base_HEAD'],sha256={**old['sha256'],**{q.relative_to(R).as_posix():digest(q)for q in O.iterdir()if q.is_file()}},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation_diagnosis.json',prep);dump(C/'preparation_diagnosis.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'diagnosis.py')]);dump(O/'capture_diagnosis.json',cap);dump(C/'capture_diagnosis.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
