from pathlib import Path
from fractions import Fraction as Fr
from hashlib import sha256
import gc,gzip,importlib.util,json,os,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/cartan-generator-residual-g1-v1-2026-11-08')
sp=importlib.util.spec_from_file_location('CGR_existing_classical_algebra',O.parent/'canonical_so10_correlated_ghost_source_log_g1_v1/action.py');b=importlib.util.module_from_spec(sp);sp.loader.exec_module(b);p=b.p;J=b.J;A=b.A;zero=b.zero;one=b.one;load=b.load;read=b.read;plus=b.plus
CASES=[('g0','F0','E0',0,None),('g1','F1','E1',1,None),('u0_H','Fu0_0','Eu0_0',0,0),('u0_M','Fu0_1','Eu0_1',0,1),('u1_H','Fu1_0','Eu1_0',1,0),('u1_M','Fu1_1','Eu1_1',1,1)]

def dump(path,z):
 with path.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def save(name,z):
 name='v2_'+name
 blob=gzip.compress((json.dumps(z,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
 if len(blob)>8*1024**2:
  with(C/(name+'.COMPLETE_OVERFLOW_NOTPASS')).open('xb')as f:f.write(blob)
  raise AssertionError('COMPLETE_OVERFLOW_PRESERVED_NOTPASS')
 with(O/name).open('xb')as f:f.write(blob)
 assert sum(q.stat().st_size for q in O.iterdir()if q.is_file())<=32*1024**2
 return dict(file=name,sha256=sha256(blob).hexdigest(),bytes=len(blob))
def sc(P,c):return p.scale(P,c)
def neg(P):return sc(P,-one)
def grade(P,g):return J.clean({w:J.Coeff([(k,v)for k,v in c.terms if k[0]==g])for w,c in P.items()})
def typed(P,dim,gh,par,intrinsic=False):
 for w,c in P.items():
  deficit=dim-sum((1 if 1286<=n<1319 else J.dimension(n))+len(js)for n,js in w)
  assert deficit in ([0,1]if intrinsic else[0]) and sum(-1 if 1286<=n<1319 else p.s.ghost(n)for n,js in w)==gh and sum(J.parity(n)for n,js in w)%2==par,('INTRINSIC_TYPE',w,deficit,gh,par)
def operate(P,Q,role):return p.s.v.act(P,Q,odd=True)if role=='native'else p.LEFT(P,Q)
def normal(P):return p.normal(P,set(range(1286,1319)))
def flow(K):
 el=J.euler(K,set(range(1286)));return{n:q for i in range(643)for n,q in[(i,neg(el.get(643+i,{}))),(643+i,el.get(i,{}))]if q}

def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in read(O/'preparation_v2.json')['sha256'].items():assert b.digest(R/n)==h,n
 ct=load(O.parent/'canonical_so10_Ward_primitive_canonical/canonical_tables.json.gz');assert all(J.parity(i)==ct['geometry']['parities'][i]for i in range(1319))
 K=p.decode_canonical(ct['K'],ct['geometry']);Kn,Kcur=normal(K);typed(Kn,3,-1,1,intrinsic=True);assert all(k[0]in[0,1]for c in K.values()for k,v in c.terms);D={int(n):p.decode_canonical(raw,ct['geometry'])for n,raw in ct['D'].items()};old=load(O.parent/'canonical_so10_log_source_restoring_preimage_g1_v1/full_marked_image_and_controls.json.gz');assert D=={int(n):J.decode(raw)for n,raw in old['actual_full_D'].items()};assert flow(Kn)==D;del old
 save('fixed_ward_and_old_affine_endpoints.json.gz',dict(complete_K=J.encode(K),complete_K_epsilon_normal=J.encode(Kn),four_IBP_currents=[J.encode(q)for q in Kcur],all1286_D=[[n,J.encode(D.get(n,{}))]for n in range(1286)],old32_full_source_QJL_comparison_remainders=ct['full_source_QJL_comparison_remainders'],old_comparison_is_not_redefined_as_new_R=True));assert len(ct['full_source_QJL_comparison_remainders'])==32
 role_results=[];role_data=[]
 for role in['native','replay']:
  folder=O.parent/'canonical_so10_correlated_ghost_source_log_g1_v1';grads={n:J.decode(v)for n,v in load(folder/(role+'_g0_gaugefermion.json.gz'))['all643_Psi_field_Eulers']};widths={};kappa={}
  for r in range(12,45):
   G=grads.get(508+r,{});assert set(G)=={((598+r,()),)},('PSI_WIDTH_NOT_SINGLE_A',role,r,J.encode(G));widths[r]=J.times(J.constant(2),J.times(J.I,next(iter(G.values()))));assert all(k[0]==0 for k,v in widths[r].terms)
   J.add(kappa,sc(J.mul(p.atom(1286+r-12),plus(p.atom(1151+r),neg(G))),J.I))
  kappa=J.clean(kappa);typed(kappa,2,-2,0);el=J.euler(kappa,set(range(1286)));iota={}
  for n in range(643):
   for port,q in[(n,el.get(643+n,{})),(643+n,el.get(n,{}))]:
    if q:iota[port]=sc(q,J.constant((-1)**J.parity(n)))
  explicit={port:q for r in range(12,45)for port,q in[(508+r,sc(p.atom(1286+r-12),-J.I)),(1241+r,sc(p.atom(1286+r-12),J.times(widths[r],J.constant(Fr(-1,2)))))]}
  assert iota==explicit,'EVEN_HAMILTONIAN_IOTA_SIGN_OR_SUPPORT';assert all(all(1286<=i<1319 and not js for i,js in w)for q in iota.values()for w in q)
  src=O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1';g0=load(src/(role+'_GF_common.json.gz'));S0=J.decode(load(src/(role+'_route_density.json.gz'))['original_GF']);g1=load(O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1'/(role+'_route_densities.json.gz'));packet=load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1'/(role+'_inputs.json.gz'));states={name:dict(v)for name,v in packet['states'].items()};del packet;gc.collect()
  widthchecks=[]
  for r in range(12,45):
   got=S0.get(((508+r,()),(508+r,())),zero);assert J.times(got,J.constant(2))==widths[r],('ACTION_PSI_WIDTH_MISMATCH',role,r);widthchecks.append([r,A.encode_coeff(widths[r]),A.encode_coeff(got)])
  save(role+'_iota.json.gz',dict(complete_kappa=J.encode(kappa),all1286_iota=[[n,J.encode(iota.get(n,{}))]for n in range(1286)],all33_actual_Psi_and_action_widths=widthchecks))
  outputs=[];summary=[]
  for label,F,E,g,pr in CASES:
   density=S0 if label=='g0'else J.decode(g1['S1'])if label=='g1'else J.decode(g0['probes'][pr]['U'])if g==0 else J.decode(g1['U1'][pr]);cofactor={}
   for r in range(12,45):
    q=plus(sc(J.decode(states[E][508+r]),-J.I),sc(J.decode(states[F][598+r]),J.times(widths[r],J.constant(Fr(1,2)))));J.add(cofactor,J.mul(p.atom(1286+r-12),q))
   cofactor=J.clean(cofactor);direct=operate(density,iota,role);Theta,curr=normal(direct);peer,peer_cur=normal(cofactor);typed(Theta,3,-1,1,intrinsic=True);owner=grade(Kn,g)if pr is None else{};rem=plus(owner,neg(Theta));typed(rem,3,-1,1,intrinsic=True);XR=flow(rem);differences=[];checks=[]
   typed(density,4,0,0,intrinsic=True);assert all(k[0]==g for c in density.values()for k,v in c.terms),'PARENT_COUPLING_GRADE'
   parent_types=[[at,4-sum(J.dimension(n)+len(js)for n,js in w)]for at,(w,c)in enumerate(sorted(density.items()))];lower_density={w:c for w,c in density.items()if 4-sum(J.dimension(n)+len(js)for n,js in w)==1};lower_direct=operate(lower_density,iota,role);lower_normal,lower_curr=normal(lower_direct);lower_Theta={w:c for w,c in Theta.items()if 3-sum((1 if 1286<=n<1319 else J.dimension(n))+len(js)for n,js in w)==1};assert lower_normal==lower_Theta,'COMPLETE_INTRINSIC_ONE_PARENT_RECONSTRUCTION'
   for n in range(643):
    qf=operate(J.decode(states[F][n]),iota,role);qs=sc(operate(J.decode(states[E][n]),iota,role),J.constant((-1)**J.parity(n)))
    for port,contracted in[(n,qf),(643+n,qs)]:
     dc=grade(D.get(port,{}),g)if pr is None else{};delta=plus(dc,neg(contracted),neg(XR.get(port,{})));checks.append([port,not delta])
     if delta:differences.append([port,J.encode(delta)])
   arities=[[at,sum(n<643 for n,js in w)]for at,(w,c)in enumerate(sorted(rem.items()))];nonlinear=[at for at,count in arities if count>1];controls=[]
   for name,mapping,odd in [('wrong_Ja_sign',{n:(neg(q)if 1241<=n<1286 else q)for n,q in iota.items()},True),('omit_Ja_shift',{n:q for n,q in iota.items()if n<1241},True),('wrong_even_prefix',iota,False)]:
    wrong=p.s.v.act(density,mapping,odd=odd);wn,wc=normal(wrong);diff=plus(wn,neg(Theta));controls.append(dict(name=name,sensitive=bool(diff),complete_normalized_difference=J.encode(diff),four_wrong_IBP_currents=[J.encode(q)for q in wc]))
   artifact=dict(case=label,all_parent_word_intrinsic_deficits=parent_types,complete_intrinsic1_parent_density=J.encode(lower_density),complete_intrinsic1_direct_variation=J.encode(lower_direct),complete_intrinsic1_Theta=J.encode(lower_normal),four_intrinsic1_IBP_currents=[J.encode(q)for q in lower_curr],full_density_input_words=len(density),complete_direct_iota_density=J.encode(direct),complete_EF_cofactor_density=J.encode(cofactor),complete_Theta=J.encode(Theta),four_direct_IBP_currents=[J.encode(q)for q in curr],four_cofactor_IBP_currents=[J.encode(q)for q in peer_cur],complete_cofactor_minus_direct_normal=J.encode(plus(peer,neg(Theta))),complete_R=J.encode(rem),all1286_X_R=[[n,J.encode(XR.get(n,{}))]for n in range(1286)],all1286_coordinate_checks=checks,complete_coordinate_differences=differences,all_R_word_ordinary_arities=arities,nonlinear_R_word_indices=nonlinear,full_ordinary_Hessian_zero_by_affine_support=not nonlinear,nonminimal_independent_physical_Eulers_iota_zero_NOT_full_Q_zero=True,controls=controls)
   ref=save(role+'_'+label+'.json.gz',artifact);ok=peer==Theta and not differences;summary.append(dict(case=label,artifact=ref,interfaces_match=ok,Theta_words=len(Theta),R_words=len(rem),X_R_nonzero_coordinates=len(XR),ordinary_Hessian_zero_by_affine_support=not nonlinear,controls_sensitive={q['name']:q['sensitive']for q in controls}));outputs.append(artifact);print('STAGE '+role+' '+label+' Rwords='+str(len(rem))+' coordinate_differences='+str(len(differences)),flush=True)
  role_results.append(dict(role=role,cases=summary));role_data.append(outputs);del g0,g1,states;gc.collect()
 assert role_data[0]==role_data[1],'COMPLETE_NATIVE_REPLAY_GENERATOR_RESIDUAL_DIFFERENCE'
 allok=all(row['interfaces_match']for rr in role_results for row in rr['cases']);affine=all(row['ordinary_Hessian_zero_by_affine_support']for rr in role_results for row in rr['cases']);out=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',scientific_disposition='FULL_CARTAN_RESIDUAL_CLASSIFIED_AFFINE'if allok and affine else'GENERATOR_INTERFACE_OR_NONLINEAR_REMAINDER_REQUIRES_REVIEW',roles=role_results,all15432_coordinate_checks_pass=allok,complete_native_replay_results_equal=True,all_full_ordinary_residual_Hessians_zero_by_affine_support=affine,no_quantum_value_or_quantum_reference_bridge_established=True,no_general_admissibility_restoration_or_E5A5_claim=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'result_v2.json',out);print('RESULT '+json.dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
