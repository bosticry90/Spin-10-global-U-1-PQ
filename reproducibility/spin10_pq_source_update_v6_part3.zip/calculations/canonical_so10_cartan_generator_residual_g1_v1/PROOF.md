# Generator and source-endpoint test

The current source convention for an even action S is
Q z_i=(-1)^p_i EL_Ji S, Q J_i=(-1)^p_i EL_zi S.
For an odd primitive K it is D z_i=-EL_Ji K, D J_i=EL_zi K.
Sources conjugate to Lambda are odd; in kappa=i epsilon JLambda the LEFT
source derivative therefore gives -i epsilon. The actual Psi Lambda Euler
is -i Omega a/2; kappa consequently also contains -Omega epsilon a/2.
Its source operation on Ja is -Omega epsilon/2. These signs are tested
against the actual full Euler tables, not assumed from typography.

Since Qepsilon=QOmega=0, Q(iota z_i)=Q(iota J_i)=0. The graded
anticommutator is therefore iota applied to each full Q coordinate.
Evolutionary differentiation of the action gives its candidate Hamiltonian
Theta=iota S, modulo explicit ordinary divergences. The audit tests this
both by the actual E/F cofactors and by direct sourceful density replacement,
then tests every coordinate of D-iota Q-X_(K_D-Theta). Thus it does not rely
on an untested appeal to graded Jacobi or full Q nilpotence.

Physical gauge/scalar actions contain no Lambda/a or nonminimal BV sources;
the physical potential is scalar-only. SMA action/source adds kinetic,
BPP,xPP,K_P C P terms, none containing Lambda or Ja. Ordinary Euler
differentiation cannot introduce these absent coordinates. Hence iota of
their Euler derivatives is0 even if those Eulers are unknown/nonzero.
This is the qualified CPS/physical-action support argument; current GF
Eulers, including their scalar-source columns, are NOT discarded.

If the normalized full R is at most affine in ordinary fields, two ordinary
fluctuation variations annihilate it at fixed sources and local epsilon.
Jets count as ordinary factors; all643 fields are included. Source derivatives
and X_R can nevertheless survive. Consequently a zero fluctuation Hessian
does not prove a zero functional, zero connected response, zero endpoint
operation or equality of quantum insertions. A quantum bridge would require
the actual common rho-parent/reference/regulator/mean/contact construction.

In particular retain the general proposed bookkeeping, NOT an earned quantum
identity: D={Q,iota}+X_R; if independently justified,
M_D=iota(QGamma1)+X_R Gamma1-Q I_R1. Its g/u convolutions can involve
lower proper functions even when their Q images vanish. This increment
computes no Gamma1 or I_R1 and assigns no missing coefficient.
