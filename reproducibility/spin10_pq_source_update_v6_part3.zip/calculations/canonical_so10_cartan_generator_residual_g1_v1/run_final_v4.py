from pathlib import Path
from hashlib import sha256
import ast,json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/cartan-generator-residual-g1-v1-2026-11-08')
def read(q):return json.loads(q.read_bytes())
def locate(q):
 q=Path(q)
 if q==O/'audit_v2.py':
  z=read(O/'source_relocation_receipt.json');assert not q.exists();q=R/z['current_path'];assert sha256(q.read_bytes()).hexdigest()==z['sha256']and q.read_bytes()==(O/'audit_v2.py.source.txt').read_bytes()
 return q
def digest(q):return sha256(locate(q).read_bytes()).hexdigest()
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert not(O/'preparation_final_v4.json').exists()and not(O/'validation_receipt.json').exists();old=read(O/'preparation_final_v3.json')
for n,h in old['sha256'].items():assert digest(R/n)==h,n
assert read(O/'capture_final_v3.json')['exit_code']==1 and not(O/'e4_v3_capture.json').exists()
text=(O/'final_review_v3.py').read_text(encoding='utf-8')
for before,after in[("assertlocate(","assert locate("),("'preparation_final_v2.json','preparation_final_v3.json'","'preparation_final_v2.json','preparation_final_v3.json','preparation_final_v4.json'")]:
 assert text.count(before)==1;text=text.replace(before,after)
assert text.count("'e4_v3_capture.json'")==2;text=text.replace("'e4_v3_capture.json'","'e4_v4_capture.json'");tree=ast.parse(text);assert not any(isinstance(n,ast.Name)and n.id=='assertlocate'for n in ast.walk(tree))
with(O/'final_review_v4.py').open('x',encoding='utf-8',newline='\n')as f:f.write(text)
for n in['FINAL_CONTINUATION_V4.md','final_review_v4.py','run_final_v4.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
prep=dict(base_HEAD=old['base_HEAD'],sha256={**old['sha256'],**{q.relative_to(R).as_posix():digest(q)for q in O.iterdir()if q.is_file()}},historical_source_relocation=read(O/'source_relocation_receipt.json'),scientific_acceptance='NOT_PERFORMED');dump(O/'preparation_final_v4.json',prep);dump(C/'preparation_final_v4.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'final_review_v4.py')]);dump(O/'capture_final_v4.json',cap);dump(C/'capture_final_v4.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
