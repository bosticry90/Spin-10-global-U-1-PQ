# CGR-A-v2: intrinsic-graded type correction

Preserve CGR-A exit1 and all original source/capture/preparation/partial files.
CGR-D completed3.816s and saved complete g1 direct/cofactor/Theta/R and every
offending type row. Theta has296 bare dimension2 and2004 bare dimension3
words, all ghost-1/odd. First witness is5 g xi x185 epsilon17. All668 R words
are bare dimension3; cofactor minus direct normal is0. This is diagnostic
evidence, not completion of CGR-A or qualification of its g0 partial result.

The original homogeneous type premise omitted the qualified intrinsic0/1
grading of the full sourceful action and fixed Ward primitive. Upstream FJB
native.py74–78 retains4-token_dimension, including intrinsic1 Ja*x terms;
the full-current and proper-operator contracts use that same intrinsic01
domain. xi/eta/g remain dimensionless; no physical coefficient is changed.
This is an assertion/domain bookkeeping correction, not permission to weaken
ghost/parity requirements or adopt a mass/parameter value.

Freeze a new audit_v2 copied by the exact declared transformations in
make_v2.py. Original sources are immutable. Preserve intrinsic deficit0/1 in
S/U (base4) and K/Theta/R (base3); kappa remains homogeneous base2.
Before coordinate comparisons, check every full parent density word, its
coupling degree, ghost0/even type, and intrinsic deficit. Split ALL degree1
parent rows, contract them independently, and require their complete normal
form to equal the degree1 Theta sector. Save full parent rows/indices,
direct variation, normal form and four currents; no scalar endpoint is
removed merely because the eventual mean-plane projection vanishes.

Keep every original full-source/cofactor/coordinate/control/arity obligation.
All files have exclusive v2 names; no overwrite, truncation or old PASS.
One new180-second worker after imports,8GiB sampled private/350MiB launch
floor, existing32MiB packet/8MiB file. Capture repo+D. No E4 in this worker.
Outcome remains a classical residual classification, not a quantum identity,
restoration or scientific promotion. Final review is separately frozen.
