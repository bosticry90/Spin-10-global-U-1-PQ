from pathlib import Path
import ast
O=Path(__file__).resolve().parent
def transformed(text):
 edits=[
 ("def save(name,z):\n", "def save(name,z):\n name='v2_'+name\n"),
 ("def typed(P,dim,gh,par):\n for w,c in P.items():assert(sum((1 if 1286<=n<1319 else J.dimension(n))+len(js)for n,js in w),sum(-1 if 1286<=n<1319 else p.s.ghost(n)for n,js in w),sum(J.parity(n)for n,js in w)%2)==(dim,gh,par)", "def typed(P,dim,gh,par,intrinsic=False):\n for w,c in P.items():\n  deficit=dim-sum((1 if 1286<=n<1319 else J.dimension(n))+len(js)for n,js in w)\n  assert deficit in ([0,1]if intrinsic else[0]) and sum(-1 if 1286<=n<1319 else p.s.ghost(n)for n,js in w)==gh and sum(J.parity(n)for n,js in w)%2==par,('INTRINSIC_TYPE',w,deficit,gh,par)"),
 ("read(O/'preparation.json')", "read(O/'preparation_v2.json')"),
 ("Kn,Kcur=normal(K);assert all", "Kn,Kcur=normal(K);typed(Kn,3,-1,1,intrinsic=True);assert all"),
 ("typed(Theta,3,-1,1)", "typed(Theta,3,-1,1,intrinsic=True)"),
 ("typed(rem,3,-1,1)", "typed(rem,3,-1,1,intrinsic=True)"),
 ('   for n in range(643):\n    qf=', "   typed(density,4,0,0,intrinsic=True);assert all(k[0]==g for c in density.values()for k,v in c.terms),'PARENT_COUPLING_GRADE'\n   parent_types=[[at,4-sum(J.dimension(n)+len(js)for n,js in w)]for at,(w,c)in enumerate(sorted(density.items()))];lower_density={w:c for w,c in density.items()if 4-sum(J.dimension(n)+len(js)for n,js in w)==1};lower_direct=operate(lower_density,iota,role);lower_normal,lower_curr=normal(lower_direct);lower_Theta={w:c for w,c in Theta.items()if 3-sum((1 if 1286<=n<1319 else J.dimension(n))+len(js)for n,js in w)==1};assert lower_normal==lower_Theta,'COMPLETE_INTRINSIC_ONE_PARENT_RECONSTRUCTION'\n   for n in range(643):\n    qf="),
 ("artifact=dict(case=label,", "artifact=dict(case=label,all_parent_word_intrinsic_deficits=parent_types,complete_intrinsic1_parent_density=J.encode(lower_density),complete_intrinsic1_direct_variation=J.encode(lower_direct),complete_intrinsic1_Theta=J.encode(lower_normal),four_intrinsic1_IBP_currents=[J.encode(q)for q in lower_curr],"),
 ("dump(O/'result.json',out)", "dump(O/'result_v2.json',out)")]
 for old,new in edits:
  assert text.count(old)==1,('EXACT_V2_TRANSFORMATION_NOT_UNIQUE',old)
  text=text.replace(old,new)
 return text
if __name__=='__main__':
 text=transformed((O/'audit.py').read_text(encoding='utf-8'));ast.parse(text)
 with(O/'audit_v2.py').open('x',encoding='utf-8',newline='\n')as f:f.write(text)
 print('EXACT_V2_SOURCE_CREATED_NOT_EXECUTED')
