from pathlib import Path
from hashlib import sha256
import ast,json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/cartan-generator-residual-g1-v1-2026-11-08');digest=lambda q:sha256(q.read_bytes()).hexdigest()
def dump(path,z):
 with path.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert not(O/'preparation_final_v2.json').exists();old=json.loads((O/'preparation_final.json').read_bytes())
for n,h in old['sha256'].items():assert digest(R/n)==h,n
assert json.loads((O/'capture_final.json').read_bytes())['exit_code']==1 and not(O/'e4_capture.json').exists()and not(O/'validation_receipt.json').exists()
text=(O/'final_review.py').read_text(encoding='utf-8')
for before,after in[("assert z['all1286_coordinate_checks']==[[n,True]for n in range(1286)]","assert sorted(z['all1286_coordinate_checks'])==[[n,True]for n in range(1286)]"),("'preparation_hessian.json','preparation_final.json'","'preparation_hessian.json','preparation_final.json','preparation_final_v2.json'")]:
 assert text.count(before)==1; text=text.replace(before,after)
ast.parse(text)
with(O/'final_review_v2.py').open('x',encoding='utf-8',newline='\n')as f:f.write(text)
for n in['FINAL_CONTINUATION_V2.md','final_review_v2.py','run_final_v2.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names={q.relative_to(R).as_posix():digest(q)for q in O.iterdir()if q.is_file()};prep=dict(base_HEAD=old['base_HEAD'],sha256={**old['sha256'],**names},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation_final_v2.json',prep);dump(C/'preparation_final_v2.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'final_review_v2.py')]);dump(O/'capture_final_v2.json',cap);dump(C/'capture_final_v2.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
