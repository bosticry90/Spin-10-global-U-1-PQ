from pathlib import Path
from hashlib import sha256
import ast,json,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/cartan-generator-residual-g1-v1-2026-11-08')
def read(q):return json.loads(q.read_bytes())
relocation=read(O/'source_relocation_receipt.json');assert relocation==read(C/'source_relocation_receipt.json')
def locate(q):
 q=Path(q)
 if q==R/relocation['historical_path']:
  assert not q.exists();q=R/relocation['current_path'];assert sha256(q.read_bytes()).hexdigest()==relocation['sha256']and q.read_bytes()==(O/'audit_v2.py.source.txt').read_bytes()
 return q
def digest(q):return sha256(locate(q).read_bytes()).hexdigest()
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert not(O/'preparation_final_v3.json').exists()and not(O/'validation_receipt.json').exists();old=read(O/'preparation_final_v2.json')
for n,h in old['sha256'].items():assert digest(R/n)==h,n
oldgate=read(O/'e4_capture.json');assert oldgate['exit_code']==2 and 'AUDIT_MUTATION_CONTRACT_VIOLATION' in oldgate['stdout'];assert read(O/'capture_final_v2.json')['exit_code']==1
text=(O/'final_review_v2.py').read_text(encoding='utf-8')
edits=[("sha256(q.read_bytes()).hexdigest();read=","sha256(locate(q).read_bytes()).hexdigest();read="),("q.with_name(q.name.removesuffix('.source.txt')).read_bytes()","locate(q.with_name(q.name.removesuffix('.source.txt'))).read_bytes()"),("(O/'audit_v2.py').read_text(encoding='utf-8')","locate(O/'audit_v2.py').read_text(encoding='utf-8')"),("'preparation_final.json','preparation_final_v2.json'","'preparation_final.json','preparation_final_v2.json','preparation_final_v3.json'")]
for before,after in edits:assert text.count(before)==1;(None);text=text.replace(before,after)
assert text.count("'e4_capture.json'")==2;text=text.replace("'e4_capture.json'","'e4_v3_capture.json'")
locator="def locate(q):\n q=Path(q)\n if q==O/'audit_v2.py':\n  z=read(O/'source_relocation_receipt.json');assert not q.exists()and z['historical_path']==q.relative_to(R).as_posix();q=R/z['current_path'];assert q==O/'compute_v2.py'and sha256(q.read_bytes()).hexdigest()==z['sha256']and q.read_bytes()==(O/'audit_v2.py.source.txt').read_bytes()\n return q\n"
assert text.count('def dump(q,z):')==1;text=text.replace('def dump(q,z):',locator+'def dump(q,z):');ast.parse(text)
with(O/'final_review_v3.py').open('x',encoding='utf-8',newline='\n')as f:f.write(text)
for n in['FINAL_CONTINUATION_V3.md','final_review_v3.py','run_final_v3.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
names={q.relative_to(R).as_posix():digest(q)for q in O.iterdir()if q.is_file()};prep=dict(base_HEAD=old['base_HEAD'],sha256={**old['sha256'],**names},historical_source_relocation=relocation,scientific_acceptance='NOT_PERFORMED');dump(O/'preparation_final_v3.json',prep);dump(C/'preparation_final_v3.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'final_review_v3.py')]);dump(O/'capture_final_v3.json',cap);dump(C/'capture_final_v3.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
