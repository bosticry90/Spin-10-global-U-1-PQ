from pathlib import Path
import importlib.util,os,threading,time
O=Path(__file__).resolve().parent;sp=importlib.util.spec_from_file_location('CGR_preserved_audit',O/'audit.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a);J=a.J;p=a.p
def main():
 tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in a.read(O/'preparation_diagnosis.json')['sha256'].items():assert a.b.digest(a.R/n)==h,n
 z=a.load(O/'native_iota.json.gz');iota={n:J.decode(raw)for n,raw in z['all1286_iota']if raw};width={r:a.A.decode_coeff(raw)for r,raw,old in z['all33_actual_Psi_and_action_widths']};packet=a.load(O.parent/'canonical_so10_proper_slavnov_actual_operators_g1_v1/native_inputs.json.gz');states={name:dict(rows)for name,rows in packet['states'].items()};density=J.decode(a.load(O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1/native_route_densities.json.gz')['S1']);direct=a.operate(density,iota,'native');Theta,curr=a.normal(direct);cofactor={}
 for r in range(12,45):
  q=a.plus(a.sc(J.decode(states['E1'][508+r]),-J.I),a.sc(J.decode(states['F1'][598+r]),J.times(width[r],J.constant(a.Fr(1,2)))));J.add(cofactor,J.mul(p.atom(1286+r-12),q))
 peer,peer_cur=a.normal(J.clean(cofactor));ct=a.load(O.parent/'canonical_so10_Ward_primitive_canonical/canonical_tables.json.gz');K=p.decode_canonical(ct['K'],ct['geometry']);Kn,Kcur=a.normal(K);rem=a.plus(a.grade(Kn,1),a.neg(Theta));outputs={}
 for name,P in[('direct',direct),('Theta',Theta),('cofactor',J.clean(cofactor)),('R',rem)]:
  rows=[];hist={}
  for at,(w,c)in enumerate(sorted(P.items())):
   typ=(sum((1 if 1286<=n<1319 else J.dimension(n))+len(js)for n,js in w),sum(-1 if 1286<=n<1319 else p.s.ghost(n)for n,js in w),sum(J.parity(n)for n,js in w)%2);hist[typ]=hist.get(typ,0)+1
   if typ!=(3,-1,1):rows.append(dict(raw_word_index=at,type=list(typ),word=[[n,list(js),p.species(n)]for n,js in w],coefficient=a.A.encode_coeff(c)))
  outputs[name]=dict(complete_polynomial=J.encode(P),all_type_counts=[[list(k),v]for k,v in sorted(hist.items())],all_offending_words=rows)
 ref=a.save('g1_full_type_diagnosis.json.gz',dict(outputs=outputs,complete_cofactor_minus_direct_normal=J.encode(a.plus(peer,a.neg(Theta))),four_direct_currents=[J.encode(q)for q in curr],four_cofactor_currents=[J.encode(q)for q in peer_cur],no_scientific_requirement_changed=True));out=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',artifact=ref,type_counts={k:v['all_type_counts']for k,v in outputs.items()},first_witnesses={k:(v['all_offending_words'][:1])for k,v in outputs.items()},elapsed_after_imports=time.perf_counter()-tick);a.dump(O/'diagnosis_result.json',out);print('RESULT '+__import__('json').dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
