# Actual Cartan remainder, with a necessary ghost insertion

The six full-source classical comparisons agree in both constructions:

    D = {Q,iota} + X_R,     iotaLambda=-i epsilon,
    iotaJa=-Omega epsilon/2.

All15,432 coordinate comparisons pass before source restriction. R0 and all
four first-probe g0/g1 remainders vanish. The original g1 remainder has668
words and76 nonzero Hamiltonian coordinate operations. It is NOT zero or
affine in all ordinary fields:334 words contain a ghost-antighost pair,
and334 contain a ghost and its nonminimal source. The complete remainder
factorizes through the actual hatted JLambda, without fitting a tensor.

The full fixed-source ordinary Hessian is nonzero, with668 ordered words
and334 same-polarization words, entirely in C/a fluctuations. Both tangent
orders and prefix/LEFT constructions agree. Keeping only the affine source
part would give a false zero Hessian. The older WPC32 affine comparator
concerns a different formula and remains unchanged.

The initial run FAILED because its homogeneous type assertion omitted the
already-qualified intrinsic0/1 grading. The complete diagnostic retains all
296 bare-dimension2 scalar-epsilon endpoints. A new frozen continuation
checks all parent intrinsic degrees and reconstructs their entire degree1
Theta sector; it does not change physical inputs or ghost/parity conditions.
The old failure remains FAILED. V2 completed23.919s; Hessian phase0.901s.
Final receipt and captures govern validation; no scientific acceptance is
inferred merely from successful execution.

This narrows the quantum task rather than solving it. For the actual parent,
the finite proper relationship would have to retain the insertion of R:

    I_D1 = iota Gamma1 + I_R1,
    M_D1 = iota(Q Gamma1) + X_R Gamma1 - Q I_R1.

These quantum bridges and their reference/contact/mean extension are NOT
qualified here. R's nonzero Hessian prevents dropping I_R1 by an affine
argument. Its actual ghost-pair root may permit reuse of qualified g0 probe
Gaussian data before any broad g1 loop campaign. Derive that input from the
action, independently of the desired marked cancellation.

The Ja-sign/omission controls are sensitive in four of six cases per route;
the even-prefix density control is blind in all six and supplies no sign
validation. Different constructions share the action, chart, software and AI
authorship. This is bounded internal mathematics, not empirical support.
No complete admissible correction module, common restoration, E5/A5 or
physical viability is established. Authority34/39/state113 unchanged;
seven historical custody references remain NOTPASS.

Before this increment, a separately verified point-in-time backup through
V835/34bde7b5 was made on independent C: disk0 (research D: disk2):
C:/Users/psboy/Codex-Continuity-Backups/ToE-Next-34bde7b5-20261108.
It preserves all frozen refs/raw Git and external controls/evidence, with
archive hashes and an isolated object restore/fsck. That engineering result
does not validate science or automatically back up this later increment.
