# CGR-D: diagnose the preserved g1 type failure

CGR-A exited1 at its type assertion after native g0. Its source, preparation,
capture and partial outputs remain FAILED, not qualified. Do not edit them.
This new prospective diagnostic reconstructs complete g1 direct/cofactor
Theta and R from the same frozen classical operands and records ALL actual
dimension/ghost/parity tuples and offending words. It changes no physical
input, sign or scientific requirement and claims no full coordinate result.

Freeze this record, diagnosis.py and run_diagnosis.py plus every original
preparation binding and existing partial outputs. One60-second worker after
imports,8GiB sampled private/350MiB floor, original32MiB/8MiB packet/file
bounds. Save complete normal forms/currents before interpreting type failure;
no truncation, fitting or scientific PASS. No E4 or commit. Review the actual
type witnesses and owner conventions before any corrected continuation.
