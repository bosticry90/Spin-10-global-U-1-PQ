# Final validator continuation: coordinate record order

The first final validator exited1 before E4 and before any receipt. Preserve
its source, preparation and full capture as FAILED. It expected coordinate
records0..1285, while the worker intentionally writes field0,source0,field1,
source1,... . Every stored check is true; that does not waive verification.

Use a new exclusive final_review_v2 with exactly two prospective changes:
sort the full coordinate-check list before comparing with all1286 exact
port/true pairs (therefore duplicates/omissions still FAIL), and include the
new final preparation in the immutable-binding loop. No mathematical input,
expected identity, resource or scientific acceptance condition changes.
Authenticate original failure and all prior sources/captures. Original E4
was never reached; run it once under the unchanged fixed-context conditions.
One180-second worker after imports,8GiB sampled private/350MiB floor,
32MiB packet/8MiB file. No overwrite, truncation or retroactive PASS.
