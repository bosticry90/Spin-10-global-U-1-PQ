from pathlib import Path
import gc,importlib.util,os,threading,time
O=Path(__file__).resolve().parent;sp=importlib.util.spec_from_file_location('CGR_full_residual_helpers',O/'audit.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a);p=a.p;J=a.J
def main():
 tick=time.perf_counter();watch=threading.Timer(60,lambda:os._exit(124));watch.daemon=True;watch.start()
 for n,h in a.read(O/'preparation_hessian.json')['sha256'].items():assert a.b.digest(a.R/n)==h,n
 assert all(J.parity(1319+n)==J.parity(n)==J.parity(1962+n)for n in range(643))
 results=[];data=[]
 for role in['native','replay']:
  z=a.load(O/('v2_'+role+'_g1.json.gz'));P=J.decode(z['complete_R']);parts={k:{}for k in['affine','quadratic','other']}
  for w,c in P.items():
   arity=sum(n<643 for n,js in w);parts['affine'if arity<=1 else'quadratic'if arity==2 else'other'][w]=c
  Hnative=p.s.v.tangent(p.s.v.tangent(P),1962);Hreplay=p.s.vr.tangent(p.s.vr.tangent(P),1962);reverse=p.s.v.tangent(p.s.v.tangent(P,1962));same=p.s.v.tangent(p.s.v.tangent(P));half=a.sc(same,J.constant(a.Fr(1,2)));sourceonly=p.s.v.tangent(p.s.v.tangent(parts['affine']),1962)
  assert Hnative==Hreplay==reverse,'FULL_ORDERED_ORDINARY_HESSIAN_DISAGREEMENT';assert not sourceonly,'AFFINE_PART_NONZERO_HESSIAN';assert p.s.v.tangent(p.s.v.tangent(parts['quadratic']),1962)==Hnative if not parts['other']else True
  grads={n:J.decode(raw)for n,raw in a.load(O.parent/'canonical_so10_correlated_ghost_source_log_g1_v1'/(role+'_g0_gaugefermion.json.gz'))['all643_Psi_field_Eulers']};hatted={};linear_rows=[];other_affine=[]
  for at,(w,c)in enumerate(sorted(parts['affine'].items())):
   Cs=[n for n,js in w if 553<=n<598];Ls=[n for n,js in w if 1151<=n<1196];eps=[n for n,js in w if 1286<=n<1319]
   if len(w)==3 and len(Cs)==len(Ls)==len(eps)==1 and all(not js for n,js in w):
    hat=a.plus(p.atom(Ls[0]),a.neg(grads.get(Ls[0]-643,{})));J.add(hatted,a.sc(J.mul(J.mul(p.atom(Cs[0]),hat),p.atom(eps[0])),c));linear_rows.append([Cs[0]-553,Ls[0]-1151,eps[0]-1286+12,a.A.encode_coeff(c)])
   else:other_affine.append(at)
  hatted=J.clean(hatted);diff=a.plus(P,a.neg(hatted));species=sorted({p.species(n-1319 if 1319<=n<1962 else n-1962)for w,c in Hnative.items()for n,js in w if n>=1319});artifact=dict(complete_R=J.encode(P),complete_affine_part=J.encode(parts['affine']),complete_quadratic_part=J.encode(parts['quadratic']),complete_other_part=J.encode(parts['other']),full_T_h_T_k_R=J.encode(Hnative),full_LEFT_T_h_T_k_R=J.encode(Hreplay),full_T_k_T_h_R=J.encode(reverse),full_same_hessian=J.encode(same),full_quadratic_Taylor_half=J.encode(half),full_source_only_hessian=J.encode(sourceonly),omitting_quadratic_piece_complete_Hessian_difference=J.encode(Hnative),all_affine_source_coefficients=linear_rows,unhandled_affine_word_indices=other_affine,complete_actual_hatted_source_reconstruction=J.encode(hatted),complete_R_minus_hatted_reconstruction=J.encode(diff),all_polarized_field_species=species,no_quantum_or_reference_value_assigned=True);ref=a.save('h_'+role+'_full_R_hessian.json.gz',artifact);row=dict(role=role,artifact=ref,R_words=len(P),affine_words=len(parts['affine']),quadratic_words=len(parts['quadratic']),other_words=len(parts['other']),ordered_Hessian_words=len(Hnative),same_Hessian_words=len(same),actual_full_Hessian_nonzero=bool(Hnative),sourceonly_shortcut_false=bool(Hnative)and not sourceonly,actual_hatted_source_factorization_matches=not diff and not other_affine,polarized_field_species=species);results.append(row);data.append(artifact);gc.collect()
 assert data[0]==data[1],'COMPLETE_NATIVE_REPLAY_R_HESSIAN_DIFFERENCE'
 out=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',roles=results,complete_native_replay_results_equal=True,ordinary_Hessian_nonzero=all(q['actual_full_Hessian_nonzero']for q in results),hatted_source_factorization_matches=all(q['actual_hatted_source_factorization_matches']for q in results),no_quantum_value_reference_extension_or_restoration_established=True,elapsed_after_imports=time.perf_counter()-tick);a.dump(O/'hessian_result.json',out);print('RESULT '+__import__('json').dumps(out,sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
