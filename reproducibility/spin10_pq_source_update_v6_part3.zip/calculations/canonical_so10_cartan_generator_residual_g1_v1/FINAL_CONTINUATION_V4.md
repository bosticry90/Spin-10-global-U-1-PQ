# Final continuation: preserve a generated-token failure

Final-v3 failed with NameError before mathematical replay or E4: its generated
locator expression joined the existing `assert` keyword to `locate`. Preserve
all exact source/preparation/capture bytes; no e4_v3 capture/receipt exists.
Correct only `assertlocate(` to `assert locate(` in a new final_review_v4,
add its new preparation binding and distinct e4_v4 output name. No scientific
requirement, old manifest, source byte, custody locator or gate is changed.

Validate the exact source transformation and absence of the erroneous token
before freezing. Same180-second/8GiB sampled/350MiB floor/32MiB/8MiB bounds;
full captures repo+D. E4 once under the unchanged fixed D: context; earlier
FAILED runs remain FAILED. This routine source-generation error is not a
scientific result or permission to weaken checks.
