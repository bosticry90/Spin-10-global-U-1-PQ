from pathlib import Path
from hashlib import sha256
import ast,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/cartan-generator-residual-g1-v1-2026-11-08');digest=lambda q:sha256(q.read_bytes()).hexdigest()
def dump(path,z):
 with path.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
assert not(O/'preparation.json').exists();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='34bde7b5bb72b98ad199f5f8b2e7441cf09d8849';old=json.loads((O.parent/'canonical_so10_marked_source_projection_g1_v1/preparation_a_v2.json').read_bytes())
for n,h in old['sha256'].items():assert digest(R/n)==h,('OLD_IMMUTABLE_BINDING_CHANGED',n)
names=set(old['sha256'])|{'AGENTS.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V835.md','calculations/canonical_so10_marked_source_projection_g1_v1/validation_receipt.json','calculations/canonical_so10_log_source_restoring_preimage_g1_v1/full_marked_image_and_controls.json.gz','calculations/canonical_so10_Ward_primitive_canonical/canonical_tables.json.gz','calculations/canonical_so10_Ward_primitive_canonical/PROOF.md','calculations/canonical_so10_Ward_primitive_canonical/final_review_validation_receipt.json','calculations/canonical_so10_chiral_probe_support/DERIVATION.md','calculations/canonical_so10_chiral_probe_support/validation_receipt.json','calculations/canonical_so10_source_homotopy_applicability_g1_v1/final_review.py','calculations/canonical_so10_source_homotopy_applicability_g1_v1/validation_receipt.json','calculations/canonical_so10_physical_current_input_recovery_g1_v1/PROOF.md','calculations/canonical_so10_sterile_matter_action/ACTION_V1.md'}
for role in['native','replay']:
 for folder,suffix in[('canonical_so10_new_physical_returning_inventory_g1_recovery_v1','_route_density.json.gz'),('canonical_so10_new_physical_returning_inventory_g1_recovery_v1','_GF_common.json.gz'),('canonical_so10_full_current_inventory_g1_recovery_v1','_route_densities.json.gz')]:names.add('calculations/'+folder+'/'+role+suffix)
for folder in['canonical_so10_new_physical_returning_inventory_g1_recovery_v1','canonical_so10_full_current_inventory_g1_recovery_v1']:names.add('calculations/'+folder+'/validation_receipt.json')
for n in names:assert(R/n).read_bytes()==subprocess.check_output(['git','show','HEAD:'+n],cwd=R),n
C.mkdir(exist_ok=False)
for n in['RECORD.md','PROOF.md','audit.py','run.py']:
 if n.endswith('.py'):ast.parse((O/n).read_text(encoding='utf-8'))
 with(O/(n+'.source.txt')).open('xb')as f:f.write((O/n).read_bytes())
with(C/'old_git_tree.txt').open('xb')as f:f.write(subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R))
with(C/'README_before.md').open('xb')as f:f.write((R/'README.md').read_bytes())
names|={q.relative_to(R).as_posix()for q in O.iterdir()if q.is_file()};prep=dict(base_HEAD=head,sha256={n:digest(R/n)for n in sorted(names)},scientific_acceptance='NOT_PERFORMED');dump(O/'preparation.json',prep);dump(C/'preparation.json',prep)
sys.path.insert(0,str(R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'));from export_a10_e5_antighost_vector import capture
cap=capture([sys.executable,'-B',str(O/'audit.py')]);dump(O/'capture.json',cap);dump(C/'capture.json',cap);print(cap['stdout_and_stderr']);assert cap['exit_code']==0 and cap['calculation_completed']and cap['post_run_observations_qualified']
