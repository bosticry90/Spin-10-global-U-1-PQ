# Final continuation: preserve a misnamed producer, enforce read-only audits

The second final validator passed its mathematical, intrinsic, raw-rational,
IBP, source and navigation checks, then E4 FAILED with read_only exit1.
Custody was NOT reached. Preserve that exact e4_capture/capture_final_v2 and
the original first validation failure. No successful receipt exists yet.

Cause: the new mutating calculation producer was named audit_v2.py. The live
COMPUTATIONAL_AUTHORITY_POLICY requires every audit_* entry point read-only;
the unchanged sealed checker correctly rejected its save/dump calls. This
was a producer naming/policy error, not a mathematical or custody PASS.

Perform one reversible, evidence-preserving LOCAL FILE relocation:
audit_v2.py -> compute_v2.py in this same uncommitted calculation folder.
Check exact original SHA against preparation_v2 AND its source.txt copy,
verify containment/exclusive destination before Move-Item, then check exact
bytes again and save a custody receipt. No old manifest, source bytes,
contract, capture or calculation output is edited/rebound/deleted. Preserve
audit_v2.py.source.txt. Old executions keep their historical name/status.
No read-only checker exception or narrowed scan is permitted.

A new final_review_v3 authenticates the old historical path binding through
that explicit custody mapping to the SAME bytes. The live old executable
path must be absent; all other old bindings use their original paths. This
is historical byte authentication after a recorded relocation, not an old
execution replay, an alternative policy hash or retroactive authorization.
Source-copy and exact transformation checks use the same locator. There is
no need to recompute unchanged scientific tensors to repair the filename.

Keep every mathematical/negative-control/state/navigation obligation from
the original final record. Freeze all sources/custody/old captures plus this
record and new validator BEFORE execution. Run a NEW E4 once, with distinct
e4_v3_capture name and unchanged D: context. The old E4 remains FAILED.
Expected components0,0,0,0,0,2 and exactly7 custody NOTPASS. One180-second
worker after imports,8GiB sampled private/350MiB floor,32MiB packet/8MiB file.
No authority promotion, remote operation or overwrite is authorized.
