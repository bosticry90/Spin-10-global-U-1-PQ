# CGR-A: full classical generator remainder

Prospective continuation of V835/34bde7b5 on main, D:. Goal ACTIVE;
state113/authority34of39 unchanged. Live AGENTS and the existing three-track,
epistemic and solo-review policies govern. Root owns writes and sequential
workers; two AI reviewers read only. No branch/worktree, physical adoption,
protected activation/promotion, publication, remote action or spending.

Question: does the actual fixed Ward primitive equal contraction of the full
source-dependent classical action? If not, what complete remainder and
Hamiltonian operation survive in all six g/u cases? This is the least costly
applicability test before a new marked quantum loop campaign. A zero, affine,
nonlinear or mismatched-interface result is informative; no fit is permitted.

Use the original formal Euclidean A0 and polynomial parameter ring, all643
ordinary fields and all643 sources BEFORE restriction, local odd epsilon in
the33 broken directions, constant physical coefficients. Ordinary jets commute
with evolutionary operations. Do not substitute constant epsilon, discard
source endpoints, or assign unavailable physical Eulers zero.

Derive kappa=i sum epsilon_r (JLambda_r-EL_Lambda_r Psi0) from the actual
V833 gauge fermion. Its even Hamiltonian operation must give precisely
iotaLambda=-i epsilon, iotaJa=-Omega epsilon/2, all other coordinates0.
Derive Omega from Psi0, and compare the actual S0 quadratic width. Check all
1319 field/source/epsilon parities against WPC geometry. Q and iota are ODD;
D and X_R are EVEN. K_D,Theta,R are dimension3/ghost-1/odd.

Six cases: original g0/g1, H/M first-u g0/g1. Native cofactor construction:
Theta=sum epsilon[-i E_Lambda+(Omega/2)F_a]. Independently apply literal odd
replacement to the FULL sourceful owning S0,S1,U0_H/M,U1_H/M densities, with
all jets prolonged. Use both role packets/densities. Normalize epsilon with
explicit four-current reconstruction and compare every coefficient.

Keep R=K_D-Theta for original cases, R=-Theta for probe cases; the fixed
K_D has no u. Retain all grades, source words and nonzero endpoints. Preserve
WPC's32 old affine corrections separately; they compare a different formula.
Compute full source/field Euler derivatives before any restriction. At every
one of1286 coordinates per case compare actual D-iota Q with X_R, where
X_R field=-EL_source R and X_R source=EL_field R. Q(iota coordinate)=0 here
because its coefficients are constant epsilon/widths. Missing physical/SMA
Eulers are iota-INERT by their actual nonminimal-independent action support;
GF contributions remain fully present. This is not setting full Q sources0.

Count ordinary-field arity of EVERY complete R word across all643 fields.
Arity<=1 proves the full ordinary fluctuation Hessian0 while leaving X_R
intact. If the sufficient arity test fails, preserve the complete nonlinear
words and classify Hessian/quantum insertion as unresolved; do not infer
Hessian nonzero solely from arity. No quantum-reference identity, contact or
mean subtraction, complete admissible normalization module or E5/A5 follows.

Negative controls: wrong Ja shift sign, omitted Ja shift, and replacing odd
prefix signs with an even operation. Save complete normalized differences,
including honest insensitive cases. Both complete role outputs must agree;
shared action, chart, algebra, software and AI authorship limit independence.

Freeze sources, immutable inputs/current live policy and180-second worker
after imports BEFORE calculation.8GiB sampled private/350MiB launch floor,
32MiB repository packet/8MiB file. Preserve complete overflow in D: control
before NOTPASS, no truncation. Full captures repo+D. No E4 or commit in this
worker. Final review/resources/acceptance are a separate frozen phase.

The independent physical-disk backup completed BEFORE this increment:
C:/Users/psboy/Codex-Continuity-Backups/ToE-Next-34bde7b5-20261108.
Its receipt authenticates engineering continuity only, not scientific claims;
it is a point-in-time snapshot through V835, not this prospective increment.
