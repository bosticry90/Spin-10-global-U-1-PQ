# CGR-H: complete nonlinear remainder Hessian

CGR-A-v2 completed23.919s; native/replay agree, all15432 classical coordinate
checks pass. R0 and all four probe remainders vanish. R1 has668 words,
including334 with ordinary arity2; its full Hessian has NOT been qualified.
Preserve the first FAILED homogeneous-type run and all diagnostic evidence.
The original32 WPC comparison does not supply this new remainder's Hessian.

Question: what complete fixed-source ordinary Hessian does the actual R1
generate, and does its affine source part combine with the quadratic ghost
part through the actual hatted JLambda? This determines which insertion
kernel is genuinely required before computing a quantum coefficient.

Freeze all v2 inputs/outputs plus this record/hessian.py/run_hessian.py.
Use both role R1 outputs, all643 ordinary tangent coordinates, and sources/
local epsilon FIXED. Compute complete T_h T_k R, T_k T_h R and T_h^2 R/2
by prefix-position replacement and independently LEFT-jet/front replacement.
All ordinary parity data and h/k geometry must agree. Retain full sourceful
R and its affine/quadratic/other split; do not restrict sources before the
derivatives. Save every polynomial, including all zeros and both orders.

Test exactly one action-derived hatted representation: read coefficients of
the existing C JLambda epsilon words, replace JLambda by JLambda-EL_Lambda
Psi0 from the actual V833 gauge fermion, and compare its COMPLETE density
with R1. No coefficient, sign, permutation or factor is fitted to a marked
target. A failed factorization is a preserved result, not permission to fit.
The source-only piece must be differentiated too; demonstrate whether its
zero Hessian fails to represent the complete R. Retain all ordinary field
species found in the Hessian. No quantum integral or amplitude is computed.

One60-second worker after imports,8GiB sampled private/350MiB launch floor,
original32MiB packet/8MiB file. Exclusive outputs/full capture repo+D;
overflow complete then NOTPASS. No E4 or commit. Final validation separately
freezes all sources and evidence. No zero whole functional, quantum reference
bridge, general correction completeness, E5/A5 or authority promotion follows.
