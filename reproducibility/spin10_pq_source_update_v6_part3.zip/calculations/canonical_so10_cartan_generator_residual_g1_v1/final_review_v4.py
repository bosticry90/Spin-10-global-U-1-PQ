from pathlib import Path
from fractions import Fraction as Fr
from hashlib import sha256
import gzip,importlib.util,json,os,re,subprocess,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;C=Path('D:/Codex-Research/ToE-Next/research-control-records/cartan-generator-residual-g1-v1-2026-11-08');digest=lambda q:sha256(locate(q).read_bytes()).hexdigest();read=lambda q:json.loads(q.read_bytes());load=lambda q:json.loads(gzip.decompress(q.read_bytes()))
def locate(q):
 q=Path(q)
 if q==O/'audit_v2.py':
  z=read(O/'source_relocation_receipt.json');assert not q.exists()and z['historical_path']==q.relative_to(R).as_posix();q=R/z['current_path'];assert q==O/'compute_v2.py'and sha256(q.read_bytes()).hexdigest()==z['sha256']and q.read_bytes()==(O/'audit_v2.py.source.txt').read_bytes()
 return q
def dump(q,z):
 with q.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def flat(rows):
 out={}
 for w,cs in rows:
  word=tuple((n,tuple(js))for n,js in w)
  for key,num,den in cs:
   k=(word,tuple(key));out[k]=out.get(k,Fr(0))+Fr(num,den)
 return{k:v for k,v in out.items()if v}
def par(n):
 if n>=1962:return par(n-1962)
 if n>=1319:return par(n-1319)
 return 1 if n>=1286 else int(n>=553)if n<643 else 1-int(n-643>=553)
def put(out,w,key,c):
 odds=[t for t in w if par(t[0])]
 if len(set(odds))!=len(odds):return
 sign=(-1)**sum(x>y for i,x in enumerate(odds)for y in odds[i+1:]);k=(tuple(sorted(w)),key);out[k]=out.get(k,Fr(0))+sign*c
def tangent(P,offset):
 out={}
 for(w,key),c in P.items():
  for at,(n,js)in enumerate(w):
   if n<643:put(out,w[:at]+((offset+n,js),)+w[at+1:],key,c)
 return{k:v for k,v in out.items()if v}
def rawflow(P):
 out={}
 for(w,key),c in P.items():
  assert all(not js for n,js in w),'ACTUAL_R_JETS_REQUIRE_GENERAL_EULER'
  for at,(n,js)in enumerate(w):
   if n>=1286:continue
   port=643+n if n<643 else n-643;sign=(-1)**(par(n)*sum(par(i)for i,jj in w[:at]));part=out.setdefault(port,{});put(part,w[:at]+w[at+1:],key,c*sign*(1 if n<643 else-1))
 return{n:{k:v for k,v in q.items()if v}for n,q in out.items()if any(q.values())}
def main():
 tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
 for pn in['preparation.json','preparation_diagnosis.json','preparation_v2.json','preparation_hessian.json','preparation_final.json','preparation_final_v2.json','preparation_final_v3.json','preparation_final_v4.json']:
  for n,h in read(O/pn)['sha256'].items():assert digest(R/n)==h,(pn,n)
 for q in O.glob('*.source.txt'):assert q.read_bytes()==locate(q.with_name(q.name.removesuffix('.source.txt'))).read_bytes(),q.name
 sp=importlib.util.spec_from_file_location('CGR_final_exact_builder',O/'make_v2.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);assert locate(O/'audit_v2.py').read_text(encoding='utf-8')==m.transformed((O/'audit.py').read_text(encoding='utf-8'))
 for name,limit,exitcode in[('capture.json',180,1),('capture_diagnosis.json',60,0),('capture_v2.json',180,0),('capture_hessian.json',60,0)]:
  cap=read(O/name);assert cap==read(C/name)and cap['exit_code']==exitcode and cap['post_run_observations_qualified'];assert cap['calculation_completed']==(exitcode==0);assert cap['launch']['memory']['available_pagefile']>=350*1024**2 and cap['all_resource_samples']and all(0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
 assert 'AssertionError' in read(O/'capture.json')['stdout_and_stderr'];assert read(O/'diagnosis_result.json')['elapsed_after_imports']<60 and read(O/'result_v2.json')['elapsed_after_imports']<180 and read(O/'hessian_result.json')['elapsed_after_imports']<60
 diag=load(O/'g1_full_type_diagnosis.json.gz');assert len(diag['outputs']['Theta']['all_offending_words'])==296 and not diag['outputs']['R']['all_offending_words']and not diag['complete_cofactor_minus_direct_normal']
 sp=importlib.util.spec_from_file_location('CGR_final_classical_helpers',O/'audit.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a);J=a.J;p=a.p;cases=[];controls={};coordinate_count=0;parent_rows=0
 fixed=load(O/'v2_fixed_ward_and_old_affine_endpoints.json.gz');K=J.decode(fixed['complete_K_epsilon_normal']);assert len(fixed['old32_full_source_QJL_comparison_remainders'])==32
 for role in['native','replay']:
  g0=load(O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_GF_common.json.gz'));g1=load(O.parent/'canonical_so10_full_current_inventory_g1_recovery_v1'/(role+'_route_densities.json.gz'));S0=load(O.parent/'canonical_so10_new_physical_returning_inventory_g1_recovery_v1'/(role+'_route_density.json.gz'))['original_GF']
  for label,F,E,g,pr in a.CASES:
   z=load(O/('v2_'+role+'_'+label+'.json.gz'));assert(O/('v2_native_'+label+'.json.gz')).read_bytes()==(O/('v2_replay_'+label+'.json.gz')).read_bytes();assert not z['complete_cofactor_minus_direct_normal']and not z['complete_coordinate_differences'];assert sorted(z['all1286_coordinate_checks'])==[[n,True]for n in range(1286)];coordinate_count+=1286
   density=J.decode(S0 if label=='g0'else g1['S1']if label=='g1'else g0['probes'][pr]['U']if g==0 else g1['U1'][pr]);expected=[[at,4-sum(J.dimension(n)+len(js)for n,js in w)]for at,(w,c)in enumerate(sorted(density.items()))];assert z['all_parent_word_intrinsic_deficits']==expected and all(d in[0,1]for at,d in expected);parent_rows+=len(expected);lower={w:c for w,c in density.items()if 4-sum(J.dimension(n)+len(js)for n,js in w)==1};assert J.decode(z['complete_intrinsic1_parent_density'])==lower
   for rawkey,curkey,normkey in[('complete_direct_iota_density','four_direct_IBP_currents','complete_Theta'),('complete_EF_cofactor_density','four_cofactor_IBP_currents','complete_Theta'),('complete_intrinsic1_direct_variation','four_intrinsic1_IBP_currents','complete_intrinsic1_Theta')]:
    div={}
    for mu,rows in enumerate(z[curkey]):J.add(div,J.D(J.decode(rows),mu))
    assert a.plus(J.decode(z[rawkey]),a.neg(J.decode(z[normkey])))==J.clean(div),(role,label,rawkey)
   P=J.decode(z['complete_R']);assert P==a.plus(a.grade(K,g)if pr is None else{},a.neg(J.decode(z['complete_Theta'])));raw=flat(z['complete_R']);xr=rawflow(raw);stored={n:flat(rows)for n,rows in z['all1286_X_R']if rows};assert xr==stored,'RAW_FRACTION_HAMILTONIAN_DERIVATIVES'
   if label!='g1':assert not raw and not xr
   else:assert len(P)==668 and len(xr)==76
   for ctrl in z['controls']:
    assert ctrl['sensitive']==bool(ctrl['complete_normalized_difference']);counts=controls.setdefault(ctrl['name'],{'sensitive':0,'blind':0});counts['sensitive'if ctrl['sensitive']else'blind']+=1
   cases.append(dict(role=role,case=label,R_words=len(P),X_R_nonzero_coordinates=len(xr)))
  h=load(O/('h_'+role+'_full_R_hessian.json.gz'));raw=flat(h['complete_R']);hn=tangent(tangent(raw,1319),1962);hr=tangent(tangent(raw,1962),1319);same=tangent(tangent(raw,1319),1319);assert hn==hr==flat(h['full_T_h_T_k_R'])==flat(h['full_LEFT_T_h_T_k_R'])==flat(h['full_T_k_T_h_R']);assert same==flat(h['full_same_hessian'])and{k:v/2 for k,v in same.items()}==flat(h['full_quadratic_Taylor_half']);assert hn and not h['full_source_only_hessian']and h['all_polarized_field_species']==['C','a'];assert len(h['complete_affine_part'])==len(h['complete_quadratic_part'])==334 and not h['complete_other_part'];assert not tangent(tangent(flat(h['complete_affine_part']),1319),1962);assert not h['complete_R_minus_hatted_reconstruction']and not h['unhandled_affine_word_indices'];assert h['complete_R']==load(O/('v2_'+role+'_g1.json.gz'))['complete_R']
 assert coordinate_count==15432 and controls=={'wrong_Ja_sign':{'sensitive':8,'blind':4},'omit_Ja_shift':{'sensitive':8,'blind':4},'wrong_even_prefix':{'sensitive':0,'blind':12}}
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==read(O/'preparation.json')['base_HEAD'];assert(C/'old_git_tree.txt').read_bytes()==subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=R);assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()==['README.md'];assert(C/'README_before.md').read_bytes()==subprocess.check_output(['git','show','HEAD:README.md'],cwd=R)
 history=subprocess.check_output(['git','show','ef70f255a667b9a81e37b344dc78967ada4ed896:README.md'],cwd=R);raw=(R/'README.md').read_bytes();assert raw.endswith(history)and sha256(history).hexdigest()=='4a00e15665bebfc23fb0ae9338770c22d1260610bde6435415c09e21a5a43792';state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';links=[]
 for q,text in[(R/'README.md',raw[:-len(history)].decode()),(R/'docs/RESEARCH_EXECUTION_HANDOFF_V836.md',(R/'docs/RESEARCH_EXECUTION_HANDOFF_V836.md').read_text(encoding='utf-8'))]:
  for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',text):
   if target.startswith(('http:','https:','#')):continue
   resolved=(q.parent/target.split('#')[0]).resolve();assert resolved.is_relative_to(R)and resolved.exists();links.append([q.relative_to(R).as_posix(),target])
 command=[__import__('sys').executable,'-B','tools/research_check.py','e4','--historical-context','D:/Codex-Research/ToE-Next/research-evidence/e4-context-v4'];e=subprocess.run(command,cwd=R,capture_output=True,encoding='utf-8',timeout=120);capture=dict(command=command,exit_code=e.returncode,stdout=e.stdout,stderr=e.stderr,scientific_acceptance='NOT_PERFORMED');dump(O/'e4_v4_capture.json',capture);dump(C/'e4_v4_capture.json',capture);assert e.returncode==0;events=[json.loads(line)for line in e.stdout.splitlines()if line.strip()];exits=[z['exit_code']for z in events if z['event']=='step_finished'];assert exits==[0,0,0,0,0,2]and next(z for z in events if z['event']=='step_finished'and z['step']=='historical_custody')['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
 files=[q for q in O.iterdir()if q.is_file()]+[R/'README.md',R/'docs/RESEARCH_EXECUTION_HANDOFF_V836.md'];receipt=dict(execution_state='COMPLETED',scientific_acceptance='NOT_PERFORMED',evidence_validation='PASS_FULL_CLASSICAL_CARTAN_REMAINDER_AND_NONZERO_GHOST_HESSIAN',base_HEAD=head,state_sha256=state,all_coordinate_comparisons=coordinate_count,parent_rows_intrinsic_authenticated=parent_rows,all_cases=cases,plain_Fraction_R_Eulers_and_both_Hessian_orders_match=True,old_homogeneous_type_attempt='FAILED_PRESERVED_NOTPASS',diagnosis_and_versioned_intrinsic_correction_preserved=True,full_R1_nonzero_Hessian=True,actual_hatted_source_factorization=True,controls=controls,quantum_coefficients_reference_bridge_and_common_restoration_NOT_established=True,E4_step_exits=exits,historical_custody='SEVEN_UNRESOLVED_NOTPASS',checked_local_links=links,files_excluding_pending_receipt_capture={q.relative_to(R).as_posix():digest(q)for q in files},shared_action_chart_software_AI_limit_independence=True,elapsed_after_imports=time.perf_counter()-tick);dump(O/'validation_receipt.json',receipt);dump(C/'validation_receipt.json',receipt);print('RESULT '+json.dumps({k:receipt[k]for k in['evidence_validation','all_coordinate_comparisons','parent_rows_intrinsic_authenticated','controls','elapsed_after_imports']},sort_keys=True),flush=True);watch.cancel()
if __name__=='__main__':main()
