# CGR final evidence validation

Freeze all prior sources/preparations/captures/artifacts plus RESULT, V836
handoff/current README, final_review.py/run_final.py and this record BEFORE
validation. Preserve CGR-A FAILED separately from diagnostic/v2/H completion.
Verify exact v2 source transformation and all old byte bindings. Check both
role outputs, all15432 coordinate rows, all parent intrinsic row coverage,
degree1 reconstruction, complete R/Theta identity and four-current IBP.

Independently differentiate flattened J-encoded R using plain Fraction
arithmetic, explicit odd inversions and coordinate replacement: compare every
Hamiltonian source/field derivative and both ordinary tangent orders/same
Hessian. No symbolic algebra helper supplies these rational derivative
coefficients. Require no jets in actual R before using the ordinary LEFT
derivative specialization. Check source-only false-zero control, full334/334
split and actual hatted-source reconstruction. Report blind controls honestly.
Do not create or validate any quantum coefficient or reference extension.

Check old Git tree/HEAD, only authorized current navigation diff, exact
historical README suffix, current links and unchanged scientific state.
Run delegated E4 ONCE, fixed D: context/no fresh; components0,0,0,0,0,2 and
exactly7 custody NOTPASS, never custody PASS. One180-second final worker
after imports,8GiB sampled private/350MiB floor,32MiB packet/8MiB file.
Full capture/receipt repo+D; no remote action or protected promotion.
