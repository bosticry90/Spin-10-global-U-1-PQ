# V922 pre-execution contract

Test the V919–V921 local finite shifts on the actual V869 absolute
flat reference split at nonzero background. The selected test is
the ordinary unmarked, source-free, single Cartan-direction
A²x, ABx and B²x projection on a nonunit constant-switch patch.
Keep both the pure reference and switched subtraction legs.
Evaluate the retained W4 insertion before concluding there is a
defect. Do not assume the full compact Ward equation is homogeneous.

Require a literal reference-symbol and carrier comparison,
the color witnesses from independent joined routes, and a
switch-polynomial and integrated affine Ward test. Compare
first-jet contacts in the same derivative grade. Check whether
one extra scalar two-connection cycle with one constant weight
would cancel the entire selected reference coefficient.
A failure applies to the specified fixed kernels and projection.
Retain other admissible normalizations and master directions.
No parameter adoption or scientific authority change.

Native 120 s, final 180 s including E4 cap 120 s, 8 GiB sampled
private, 350 MiB launch floor, 8 MiB artifact and 32 MiB packet.

## V2 continuation after native failure

The first run reached the literal Weyl match, then stopped because
SymPy does not multiply an Add by a Python bool. Convert the
Kronecker indicator to an exact integer. The complete failed run
is preserved in its original control record with a SHA inventory.
No mathematical assertion, bound or gate changed. The proof uses
the term plateau for the nonunit switch throughout.
