# V922 result

The V869 absolute flat split adds an A²x scalar reference term
and an ABx vector reference term to the fixed V919–V921
normalization. On the actual light single-generator slice their
relative weights are (1,-1,0) for A²x, ABx and B²x, with
t²(1-t) switch weight. Simultaneous affine variation leaves
(a-b) partial omega. The exact Phi and Sigma coefficients
show that no common kappa removes the defect at distinct
positive reference masses.

The original affine background insertion is linear in ordinary
fields. The graph-supported finite shifts have no extra
contact on that insertion. The V921 derivative correction
cannot change this derivative grade. One extra pair of linear
scalar reference insertions alone has the wrong switch degree
to cancel the reference coefficient on every nonunit patch.

This is a W4 failure of the specified fixed kernels, with
explicit finite-map transport. It leaves more general contact
assignments, geometric and master directions, and the full
quantum construction open. The first native verifier stopped
on a SymPy boolean multiplier. Its complete capture is
preserved; v2 uses the exact integer indicator. Native and
replay share physical inputs and software. No authority change.
