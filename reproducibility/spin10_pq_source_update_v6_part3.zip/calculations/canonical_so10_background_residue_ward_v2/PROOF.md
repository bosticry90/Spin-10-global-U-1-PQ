# Nonzero-background test of the fixed local residues

## Reference terms in the absolute flat split

Use V869 with independent total connection B and external connection A.
Take rho=theta=0 for the ordinary test and a constant switch sigma=t
with 0<t<1 on the patch containing the Ward test. The total quadratic
reference in the local Taylor input is

    (1-t)(R_A-R_0) + t(S_A-R_0).

This is the algebraic sum of the X reference and Y relative legs of
V869 at this specialization. It is not just the Y subtraction. The
pure reference determinant remains in the underlying functional.
It is independent of the ordinary scalar mean, so it has no direct
linear scalar term in this projection.

Read the actual ordered Weyl matrices and transported field carriers.
For either test color h=0 or h=1, the connection on the ordinary scalar
space is partial+g rho_h A, since the homogeneous field matrix is
r_h=-rho_h. On the vector space it is partial+g ad_h A. The reference
scalar seagull is the same covariant norm as the physical scalar
seagull, with A in place of B. In the positive hard angular chart,
the A² term of K_x is -g² A² rho_h². Contraction with two orbit ports
E_(s,a) produces the color coefficient
S_s=sum_a ||rho_h E_(s,a)||². The Hessian has both x slots.

For the vector reference the Euclidean ordered two-derivative part is
-delta_(mu nu) D² + (D_mu D_nu+D_nu D_mu)/2. At zero A transfer,
differentiating the two slots with -ip into the right vector leg gives
the linear connection factor i g ad_h multiplying

    2 (p.A) delta_(mu nu) - A_mu p_nu - p_mu A_nu.

This equals the V920 physical cubic Hessian in the same chart with
its spectator B replaced by A. In components (ad_h)_(a,b)=-f_(a,b,h),
which gives the required color sign. The 1/2 in the reference
quadratic form is removed by its Hessian, so this replacement carries
no extra factor. Both orientations and the transverse gauge factor
are therefore the same as in V920. Terms containing partial A are
irrelevant to the derivative-free coefficients and remain part of
the full reference Euler and Ward current.

## Exact single-generator projection

Choose an external connection in one Lorentz component with
A=a T_h, B=b T_h and x along the actual v_s, with other ordinary
means zero. The same h is used for both connections and the
background parameter. Its commutator with itself is zero and
rho_h v_s=0. The V920 ordinary seagull sum vanishes in this
projection, since the scalar derivative of its covariant norm
in direction v_s vanishes. Its two terms are separately
S_s b² and -S_s b² before adding their linked coefficients.

On the two fixed T3 families, the reference scalar Hessian
can occupy the two-scalar slot and gives S_s a², with switch
factor t²(1-t). The gauge reference connection can occupy the
cubic gauge Hessian slot and gives -S_s ab with the same
switch factor. There is no A propagator. The physical mixed
Hessian slot in the gauge triangle supplies the remaining b.
The gauge reference has no scalar, the scalar reference has
no ordinary B port, and no reference has the Lambda x mixing
used in these families. Thus the remaining direct replacements
in these specified kernels cannot generate another derivative-free
A²x, ABx or B²x coefficient. The fixed two-vertex kinetic mass
residue needs the same mixed B–Lambda and scalar ports, and has
no derivative-free reference replacement with two external
connections. The ghost pair of V916 does not supply a reference
A²x term: its two contracted slots include a scalar.
This census concerns the already changed kernels.

Including their block weight, the plateau color coefficient of
the inherited projection is

    t²(1-t) L_s (2 C_s-8) S_s/C_s times (a²-ab),

with the common loop, g⁴ xi and Lorentz units understood.
For h=0 the stripped Phi and Sigma prefactors are 126 L_Phi
and (153/125) L_Sigma. They come from the actual S_s values
105 and 9/10. The two blocks are independently testable.
The distinct positive reference masses prevent both L_s
from vanishing at any common kappa.

## Affine Ward defect and restricted repair test

On this one-generator slice the simultaneous background action
has delta a=delta b=partial omega_h in the selected component,
and delta x=0 for x=c(y) v_s with scalar test c. The necessary
conditions on a local polynomial c_A a²+c_AB ab+c_B b² in this
derivative grade are 2 c_A+c_AB=0 and c_AB+2 c_B=0. In the
inherited projection the relative coefficients are (1,-1,0);
the residual is (a-b) partial omega_h times the displayed
block and switch weight. It is a nonzero local functional.
For example take b=0 and a nonzero constant on the Ward test
support, and vary c in the relevant direction. Integrating
against partial omega_h tests partial c, rather than a
divergence with constant coefficients alone. All choices can
be realized inside a larger compact patch. Terms of positive
ordinary derivative grade contribute in higher derivative
grade to the affine variation on this slice. In particular
the V921 derivative contacts cannot cancel this component.

The W4 test must also transport the original insertion. By V869,
T_b P at the constant-switch patch is (1-t) z^t K_A t_aff
modulo the retained total current. This is linear in ordinary
fields. A linear ordinary insertion is fixed by the field
equation normalization and cannot occupy a two-port loop
vertex of these finite shifts. The original insertion's tree
effect remains in the Ward equation, with zero extra finite
contact from this map. Thus the computed first-order defect
survives in T_b N - N'_P[T_b P]. At fixed A the explicit
geometric variation is instead -a partial omega_h times
the common coefficient; an A derivative of the new reference
contact cannot be dropped when transporting W5. This does
not impose a separate homogeneous geometric Ward identity.

One prospective additional core puts two reference linear
connection insertions on the internal scalar of the original
kinetic–mixing pair. The two scalar inverse terms in the
covariant scalar kernel have hard angular weights 1 and -4/D
for a quadratic connection and two linear connections,
respectively, at fixed background on that line. Their sum
is zero at D=4 before switching. In the compact parent the
two-linear graph has switch factor t²(1-t)², whereas the
fixed scalar A² term above has t²(1-t). A single new
switch-independent coefficient on this pair cannot cancel
the existing coefficient for all t. This limited test does
not exhaust additional ghost, gauge or background-labeled
contacts. If the flat c_B=0 result is retained, affine closure
requires cancellation of both net c_A and net c_AB.

This establishes a nonzero-background failure of the fixed
V919–V921 kernels under the retained W4 insertion. The
native and replay calculations share the same action,
background convention and symbolic software. Other finite
normalizations, the full compact master and physical
viability remain open. No new loop integration or authority.
