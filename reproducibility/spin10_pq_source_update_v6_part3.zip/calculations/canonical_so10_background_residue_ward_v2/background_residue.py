"""Check the nonzero-background Ward projection of the fixed residues."""

from collections import defaultdict
import importlib.util
from itertools import product
import sys

import sympy as sp

from execute import PK, ROOT, run_worker


OWNER = ROOT/"calculations/canonical_so10_gauge_scalar_seagull_residue_v1/seagull_residue.py"
SPEC = importlib.util.spec_from_file_location("seagull_owner",OWNER)
seagull = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(seagull)


def reference_checks(phase):
    role = "primary" if phase == "native" else "replay"
    root = ROOT/"calculations"
    proof = seagull.read(root/"canonical_so10_current_background_reference_bridge_v1/result_a.json")["compared"]
    table = {(i,j,tuple(jets)):sp.sympify(v)
             for i,j,jets,v in proof["transported_ordered_Weyl_coefficients"] if len(jets) == 2
             and (i < 508 or j < 508)}
    expected = {}
    for a,mu,nu,r,s in product(seagull.COLORS,range(4),range(4),range(4),range(4)):
        value = -(mu==nu)*(r==s) + sp.Rational(1,2)*((mu==r)*(nu==s)+(mu==s)*(nu==r))
        if value:
            expected[4*a+mu,4*a+nu,(r,s)] = value
    for i,r in product(range(180,508),range(4)):
        expected[i,i,(r,r)] = -1
    assert table == expected
    A = sp.Matrix(sp.symbols("A0:4"))
    p = sp.Matrix(sp.symbols("p0:4"))
    for mu,nu in product(range(4),repeat=2):
        actual = sum(-table.get((mu,nu,(r,s)),0)*(p[r]*A[s]+A[r]*p[s])
                     for r,s in product(range(4),repeat=2))
        target = 2*A.dot(p)*int(mu==nu)-A[mu]*p[nu]-A[nu]*p[mu]
        assert sp.expand(actual-target) == 0
    assert proof["all_48_connection_affines"] == [[1331+i,1379+i//4,i%4] for i in range(48)]

    name = "native_v2_coefficients.json.gz" if phase == "native" else "replay_v4_coefficients.json.gz"
    joined = seagull.read(root/"canonical_so10_physical_current_input_recovery_g1_v1"/name)
    rho, entries = {}, {}
    for a,rows in joined["rho"]:
        columns = defaultdict(list)
        entries[a] = {}
        for i,j,cells in rows:
            value = seagull.unpack(cells)
            columns[j].append((i,value))
            entries[a][180+i,180+j] = -value
        rho[a] = columns
    f = {(a,b,c):seagull.unpack(v) for (a,b,c),v in joined["f"]}
    frame = seagull.read(PK/"frozen_a10_physical_reconciliation"/f"full_{role}.json")
    vacuum = {x:sp.sympify(v) for x,_,v in frame["vacuum"]["VEV"]["entries"]}
    values, support = {k:{} for k in seagull.BLOCKS}, {}
    for h in (0,1):
        carriers = proof["twelve_current_homogeneous_carriers"][h]
        xs = {(i,j):sp.sympify(v) for i,j,v in carriers if 180<=i<508 and 180<=j<508}
        bs = {(i,j):sp.sympify(v) for i,j,v in carriers if i<180 and j<180}
        assert xs == entries[h]
        assert bs == {(4*a+mu,4*b+mu):z for (a,b,c),z in f.items() if c==h for mu in range(4)}
        support[str(h)] = [len(xs),len(bs)]
        for block,(start,stop,C) in seagull.BLOCKS.items():
            v = {i:x for i,x in vacuum.items() if start<=i<stop}
            assert not seagull.apply(rho[h],v)
            E = [seagull.apply(rho[a],v) for a in seagull.COLORS]
            if phase == "native":
                S = sum(seagull.dot(e,seagull.apply(rho[h],seagull.apply(rho[h],e))) for e in E)*-1
            else:
                S = sum(seagull.dot(z,z) for z in (seagull.apply(rho[h],e) for e in E))
            check = seagull.read(root/"canonical_so10_gauge_scalar_seagull_residue_v1/result.json")
            scalar,gauge,target = map(sp.sympify,check["checks"]["color"][block][str(h)])
            assert (S,-S,sp.S.Zero) == (scalar,gauge,target)
            values[block][str(h)] = str(sp.simplify(S*(2*C-8)/C))
    return {"background":values,"reference":{"principal_positions":len(table),
            "light_carrier_positions":support,"gauge_reference_matches_orbit_tensor":True}}


def ward_checks():
    a,b,da,t,L,q,D = sp.symbols("a b da t L q D")
    direct = L*t**2*(1-t)
    N = direct*(a*a-a*b)
    transport = sp.expand(da*(sp.diff(N,a)+sp.diff(N,b)))
    assert sp.expand(transport-direct*da*(a-b)) == 0
    c_A,c_AB,c_B = sp.symbols("c_A c_AB c_B")
    constraints = [2*c_A+c_AB,c_AB+2*c_B]
    assert sp.solve([*constraints,c_B],(c_A,c_AB,c_B)) == {c_A:0,c_AB:0,c_B:0}
    # Including just one new scalar core with two linear reference
    # insertions changes A² by a term with two unswitched factors.
    coefficient = sp.Poly(t**2*(1-t)*(L+q*(1-t)),t)
    assert sp.solve(coefficient.coeffs(),(L,q)) == {L:0,q:0}
    assert (1-4/D).subs(D,4) == 0
    return {"ward":{"inherited_slice":["1","-1","0"],
                    "selected_W4_defect":"L*t**2*(1-t)*(a-b)*da",
                    "geometric_explicit_variation":"-L*t**2*(1-t)*a*da",
                    "pure_two_connection_switch":"t**2*(1-t)**2",
                    "constant_scalar_pair_alone_suffices":False}}


def check(phase):
    return reference_checks(phase) | ward_checks()


if __name__ == "__main__":
    run_worker(check,sys.argv[1])
