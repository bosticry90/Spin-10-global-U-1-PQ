from pathlib import Path
from hashlib import sha256
import json,os,threading,time
import mpmath as mp
import sympy as s
O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'adversarial_preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p
mp.mp.dps=40;rows=[]
for width in ['0.7','1','2.3']:
    ss=mp.mpf(width)
    sch=mp.quad(lambda A:mp.log(1+A/ss)/A**2,[ss,mp.inf])
    angular=2/ss*mp.quad(lambda u:(mp.exp(-ss*u)-mp.exp(-2*ss*u))/u,[0,1,mp.inf])
    expect=2*mp.log(2)/ss
    assert abs(sch-expect)<mp.mpf('1e-36') and abs(angular-expect)<mp.mpf('1e-36')
    rows.append({'test_width':width,'Schwinger_normalized':mp.nstr(sch,37),
       'angular_route_difference':mp.nstr(sch-angular,6)})
angles=[]
for rr,ll in [(1,2),(2,1),(1,1)]:
    value=2/mp.pi*mp.quad(lambda th:mp.sin(th)**2/(rr**2+ll**2+2*rr*ll*mp.cos(th)),[0,mp.pi/2,mp.pi]) if rr!=ll else mp.mpf(1)
    # Equal radii: sin^2(theta)/(2+2cos(theta))=(1-cos(theta))/2.
    if rr==ll:value=2/mp.pi*mp.quad(lambda th:(1-mp.cos(th))/2,[0,mp.pi])
    expect=mp.mpf(1)/max(rr**2,ll**2)
    assert abs(value-expect)<mp.mpf('1e-37')
    angles.append({'radii':[rr,ll],'angular_average':mp.nstr(value,37)})
r=s.symbols('r',positive=True)
assert s.integrate(1/r,(r,0,1))==s.oo
assert all(a<4 for a in [3,3,2]) and 7-sum([3,3,2])==-1
out={'schema':'CTS3_TWO_ROUTE_JOINT_MAJORANT_REVIEW',
 'evidence_validation':'PASS_EXACT_JOINT_MAJORANT_AND_UNSAFE_DIAGONAL_CONTROL',
 'joint_majorant_integral':'2*log(2)/(s*(16*pi^2)^2)',
 'two_integral_routes':rows,'angular_Newton_checks':angles,
 'early_k0_control':'LOOP_Q_DEGREE4_LOG_DIVERGENCE',
 'individual_bounds_alone_insufficient_control':[3,3,2],
 'no_model_amplitude_or_scalar_tadpole_or_connected_Ward_claim':True,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'adversarial_validation_receipt.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
