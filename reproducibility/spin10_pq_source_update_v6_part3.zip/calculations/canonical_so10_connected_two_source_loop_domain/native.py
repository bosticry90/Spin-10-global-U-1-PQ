from pathlib import Path
from hashlib import sha256
from itertools import product
from collections import Counter
import gzip,json,os,sys,threading,time
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'calculations/canonical_so10_full_jet_source_master_bridge'))
import jets as J
from coefficient_ring import expression,coefficient
read=lambda p:json.loads(p.read_bytes())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(300,lambda:os._exit(124));timer.daemon=True;timer.start()
for p,h in read(O/'preparation.json')['input_sha256'].items():assert digest(Path(p))==h,p

planes=load(R/'calculations/canonical_so10_even_source_mean_response/plane_tables_v2.json.gz')
actual=[]
for role in ['primary','replay']:
    raw=load(R/f'calculations/canonical_so10_u_maximal_heat_cutoff/{role}_inputs.json.gz')
    for probe,encoded in enumerate(raw['QG']):
        poly=J.decode(encoded);n2={};n1={};families=Counter()
        for w,c in poly.items():
            js=[i for i,jet in w if 1241<=i<1286]
            if len(js)>=2:
                assert len(js)==len(w)==2 and all(not jet for i,jet in w)
                J.put(n2,w,c)
            elif len(js)==1:
                # Other sources are zero only AFTER the two differentiations.
                if any(i>=643 and not 1241<=i<1286 for i,jet in w):continue
                fields=[(i,jet) for i,jet in w if i<643]
                assert len(fields)<=2
                J.put(n1,w,c)
                families[tuple(sorted('B' if i<180 else 'x' if i<508 else 'L' if i<553 else 'C' if i<598 else 'a' for i,jet in fields))]+=1
        assert len(n2)==[12,33][probe]
        row=next(z for z in planes['routes'] if z['role']==role and z['probe']==probe)
        EL={i:J.decode(z) for i,z in row['E_Lambda']}
        K={i:J.decode(z) for i,z in row['K']}
        square={};nlinear=0
        for r in range(45):
            if (r<12)!=(probe==0):continue
            z=dict(EL.get(r,{}));om=z.get(((508+r,()),),J.ZERO)
            J.add(z,{((508+r,()),):om},J.constant(-s.Rational(1,2)))
            assert J.clean(z)==K.get(r,{})
            J.add(square,J.mul(z,z))
            nlinear+=sum(1 for w in z if len(w)==1 and 180<=w[0][0]<508)
        expected={w:c for w,c in J.decode(row['even_QG']).items() if J.degree(w,4)<=1}
        got={w:c for w,c in square.items() if J.degree(w,4)<=1}
        assert J.clean(got)==J.clean(expected)
        assert nlinear==[0,296][probe]
        actual.append({'role':role,'probe':probe,'source_only_JaJa_rows':len(n2),'Ja_linear_max_field_arity':2,
          'Ja_linear_families':[[list(k),v] for k,v in sorted(families.items())],
          'actual_N_canonical_entries':nlinear,'full_intrinsic01_square_remainder':0,
          'bare_two_Ja_proper_loop_firstu':'ZERO_H_JJ_AND_BASE_H_J_VANISH'})
        print('STAGE actual '+role+' '+str(probe),flush=True)
for probe in [0,1]:
    aa,bb=[v for v in actual if v['probe']==probe]
    assert {k:v for k,v in aa.items() if k!='role'}=={k:v for k,v in bb.items() if k!='role'}

# Scalar mixing is an interaction, not silently part of the fixed regulator.
y,la,x,j,n,a,e,om=s.symbols('y la x j n a e om',nonzero=True)
fields=[y,la,x];Sref=s.I*la*y+om*la**2/2+a*x**2/2
H=s.hessian(Sref,fields);G=H.inv();V=s.hessian(n*la*x,fields)
Gt=e*G-e**2*G*V*G
U=(s.I*(y-j)+om*la/2+n*x)**2
base=s.Matrix([e*j,0,0]);force=s.Matrix([s.diff(U,z).subs(dict(zip(fields,base))) for z in fields])
response=(-Gt*force).applyfunc(lambda z:s.expand(z).series(n,0,2).removeO().expand())
target=s.Matrix([-om*e*(1-e)*j,2*s.I*e*(1-e)*j,2*s.I*n*e*(1-e)**2*j/a])
assert (response-target).applyfunc(s.simplify)==s.zeros(3,1)
missing_chain=(-e*G*force).applyfunc(lambda z:s.expand(z).series(n,0,2).removeO().expand())
assert s.simplify(missing_chain[2]-target[2])!=0
assert (Gt*s.Matrix([0,s.I*j,0])-base).applyfunc(s.simplify)==s.zeros(3,1)

# All flats of the three distinct node maps into one scalar momentum coordinate.
maps=[s.Matrix([[1,0]]),s.Matrix([[1,1]]),s.Matrix([[0,1]])]
flats=[]
for bits in product([0,1],repeat=3):
    subset=[i for i,b in enumerate(bits) if b]
    if not subset:continue
    A=s.Matrix.vstack(*(maps[i] for i in subset));rank=A.rank()
    closure=[i for i,z in enumerate(maps) if s.Matrix.vstack(A,z).rank()==rank]
    if subset==closure:flats.append((subset,rank))
assert flats==[([2],1),([1],1),([0],1),([0,1,2],2)]
tests=[]
for exps in product(range(3),repeat=3):
    margins=[4*rank-sum(exps[i] for i in subset) for subset,rank in flats]
    assert min(margins)>0
    tests.append({'degrees':list(exps),'flat_margins':margins})
bad1=(2,2,4);bad2=(3,3,2)
assert min(4*r-sum(bad1[i] for i in ids) for ids,r in flats)==0
assert min(4*r-sum(bad2[i] for i in ids) for ids,r in flats)==0

# Exact heat bubble and external Gaussian pairing. mu^2=mu2.
t,K,ss,mu2=s.symbols('t K ss mu2',positive=True)
c=-s.EulerGamma+1-s.log(2)
finite=-s.log(K/mu2)+c
paired=s.integrate(s.exp(-ss*K)*finite,(K,0,s.oo))
expect=(s.log(ss*mu2)+1-s.log(2))/ss
assert s.simplify(s.expand_log(paired-expect,force=True))==0
power_cross=s.limit((s.exp(-t*K)-1)/(t*K),t,0)
assert power_cross==-1
out={'schema':'CTS1_ACTUAL_SUPPORT_AND_JOINT_DOMAIN','actual_source_support':actual,
 'scalar_linear_response':[str(z) for z in target],'direct_N_chain_omission_sensitive':True,
 'loop_node_maps':[[1,0],[1,1],[0,1]],'complete_flats':flats,'ordinary_degree_tests':tests,
 'worst_ordinary_total_degree':6,'joint_dimension':8,'worst_flat_margin':2,
 'negative_controls':{'individual_degree4':'LOG_DIVERGENCE','individual_below4_total8':'SIMULTANEOUS_LOG_DIVERGENCE'},
 'bubble_finite_normalized':str(finite),'Gaussian_pairing_normalized':str(expect),
 'wrong_mean_power_subtraction_finite_cross':str(power_cross),
 'full_connected_Ward_or_tadpole_claim':False,'analytic_proof_not_assistant_formalized':True,
 'elapsed_after_imports':time.perf_counter()-tick,'scientific_acceptance':'NOT_PERFORMED'}
with(O/'native_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps({k:v for k,v in out.items() if k not in ['actual_source_support','ordinary_degree_tests']},sort_keys=True),flush=True)
timer.cancel()
