# The worst ordinary joint soft kernel is integrable, its diagonal need not be

For s>0 put

 J(s)=integral dq dk/(2pi)^8 e^-s(q^2+k^2)/[q^2 k^2(q+k)^2].

Schwinger parameters alpha,beta,gamma>=0 give the determinant
D=(s+alpha)(s+beta)+gamma(2s+alpha+beta). The positive Gaussian integral
is (16pi^2)^-2 integral D^-2. Integrating gamma first and putting
A=s+alpha,B=s+beta leaves integral_s^infinity dA dB/[AB(A+B)].
The B integral is log(1+A/s)/A^2. Integration by parts in A gives

                    J(s)=2log2/[s(16pi^2)^2].

No conditionally convergent cancellation was used: positivity licenses
Tonelli, and the final elementary integral is finite.

Independently, in four dimensions the angular mean of 1/(q+k)^2 at fixed
r=|q|,l=|k| is 1/max(r^2,l^2). This follows from the harmonic mean-value
identity for the Newton kernel, or its convergent Gegenbauer expansion
off equal radii and the integrable equal-radius limit. Radial variables
u=r^2,v=l^2 then give

 (16pi^2)^2 J(s)=integral_0^infinity du dv e^-s(u+v)/max(u,v)
              =2/s integral_0^infinity (e^-su-e^-2su)/u du
              =2log2/s.

This proves an actual global integral of the worst soft majorant rather
than just an exponent count. It does not evaluate any model tensor or
replace the UV subtraction of a real loop amplitude.

If k is set to0 before constructing the joint distribution, the two loop
denominators become q^-4 and its four-dimensional radial integral is
integral_0^1 dr/r, divergent. A joint locally-L1 distribution therefore
does not automatically possess that diagonal restriction. Nor is testing
each node separately enough: degrees(3,3,2) are individually below4 but
their simultaneous eight-dimensional radial integral is also log divergent.
Neither unsafe operation is used in CTS1/2. RAS's tadpole-delta extension
required its distinct numerator and even-mollifier proof; this majorant
cannot be substituted for it or the remaining scalar tadpole construction.
