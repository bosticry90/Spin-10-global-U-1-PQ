from pathlib import Path
from hashlib import sha256
import ast,json,os,subprocess,threading,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/connected-two-source-loop-domain-v1-2026-10-27')
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
bindings={};preps=[]
for p in sorted(O.glob('*preparation*.json')):
    preps.append(p.name)
    for name,h in read(p)['input_sha256'].items():
        assert digest(Path(name))==h,(p.name,name)
        if name in bindings:assert bindings[name]==h
        bindings[name]=h
copies=list(O.glob('*.source.txt'))
for p in copies:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes(),p
for p in O.glob('*.py'):ast.parse(p.read_bytes())
for p in O.iterdir():
    if p.suffix in ['.md','.py','.txt']:assert all(z==z.rstrip(b' \t') for z in p.read_bytes().splitlines()),p
accepted={'native_capture.json','review_capture.json','adversarial_capture.json','e4_capture.json'}
seen=set();samples={}
for p in O.glob('*capture*.json'):
    seen.add(p.name);cap=read(p)
    assert p.name in accepted and cap['execution_state']=='COMPLETED' and cap['exit_code']==0
    assert cap['calculation_completed'] and cap['post_run_observations_qualified']
    assert not cap['failed_or_incomplete_counted_as_PASS'] and cap['launch']['creation_after_observation']
    assert cap['launch']['memory']['available_pagefile']>=350*1024**2
    assert cap['all_resource_samples'] and all('query_error' not in z and 0<z['private_bytes']<=8*1024**3 for z in cap['all_resource_samples'])
    samples[p.name]=max(z['private_bytes'] for z in cap['all_resource_samples'])
assert seen==accepted and not list(O.glob('*controller_failure*.json'))
a=read(O/'native_result.json');b=read(O/'validation_receipt.json');c=read(O/'adversarial_validation_receipt.json')
assert a['elapsed_after_imports']<300 and b['elapsed_after_imports']<180 and c['elapsed_after_imports']<180
assert [z['source_only_JaJa_rows'] for z in a['actual_source_support']]==[12,33,12,33]
assert [z['actual_N_canonical_entries'] for z in a['actual_source_support']]==[0,296,0,296]
assert all(z['full_intrinsic01_square_remainder']==0 for z in a['actual_source_support'])
assert a['direct_N_chain_omission_sensitive'] and len(a['ordinary_degree_tests'])==27
assert a['worst_ordinary_total_degree']==6 and a['joint_dimension']==8 and a['worst_flat_margin']==2
assert b['scalar_stationary_response_matches'] and b['rank_two_node_arrangement_rederived']
assert b['same_regulated_mean_subtraction_retained'] and b['finite_A0_A1_A2_not_fixed']
assert b['scalar_tadpole_and_connected_Ward_still_open'] and not a['full_connected_Ward_or_tadpole_claim']
assert c['early_k0_control']=='LOOP_Q_DEGREE4_LOG_DIVERGENCE'
assert c['no_model_amplitude_or_scalar_tadpole_or_connected_Ward_claim']
assert len(c['two_integral_routes'])==3 and len(b['Schwinger_vs_direct_heat_pairing'])==3
assert 'Focused result-to-claim assessment' in (O/'RESULT.md').read_text()
assert 'The fifth term -Gamma_phi[y_ij] remains separate.' in (O/'PROOF.md').read_text()
events=read(O/'e4_events.json');steps=[z for z in events if z['event']=='step_finished'];exits=[z['exit_code'] for z in steps]
assert exits==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested']
assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
assert read(O/'e4_capture.json')['elapsed_seconds']<300
git=lambda *args:subprocess.run(['git',*args],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()=='6bcba57dc12daacc6c3156225fc4a7ddc3888b99'
assert git('branch','--show-current').decode().strip()=='main'
assert git('ls-tree','-r','--full-tree','HEAD')==(C/'old_git_tree.txt').read_bytes()
git('diff','--quiet','HEAD','--')
state=digest(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
size=sum(p.stat().st_size for p in O.rglob('*') if p.is_file());assert size<16*1024**2
out={'schema':'CTS_FINAL_EVIDENCE_REVIEW','evidence_validation':'PASS_BOUNDED_FOUR_NON_TADPOLE_CONNECTED_LOOP_DOMAIN',
 'preparations':preps,'input_bindings_authenticated':len(bindings),'source_copies_equal':len(copies),
 'accepted_completed_captures':sorted(accepted),'failed_scientific_captures':[],
 'actual_source_and_scalar_response_support_checked':True,'joint_domain_and_distinct_integral_controls_checked':True,
 'finite_normalization_jets_symbolic':True,'subtraction_transport_same_regulated_mean':True,
 'scalar_tadpole_and_connected_Ward_still_open':True,'analytic_proof_not_formal_assistant_certified':True,
 'full_connected_QAP_E5_physical_claim':False,'E4_step_exits':exits,
 'custody':'EXIT2_SEVEN_UNRESOLVED_NOTPASS','state_sha256':state,'old_tracked_tree_unchanged':True,
 'largest_observed_private_sample':max(samples.values()),'memory_samples_not_true_peak':True,
 'packet_bytes_before_final_capture_and_seal':size,'elapsed_after_imports':time.perf_counter()-tick,
 'scientific_acceptance':'NOT_PERFORMED'}
with(O/'final_review_result.json').open('xb') as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print('RESULT '+json.dumps(out,sort_keys=True),flush=True);timer.cancel()
