# Four connected loop terms have a common joint domain in the selected sector

CTS1/2/3 completed; final byte/resource/E4 validation is separately recorded.
Original unshiftedSMA/CSW/EDS,A0,zero ordinary source,even two-Ja directions,
constant firstu,bothprobes,intrinsic0/1,positive scalar REFERENCE masses,
independent Schwartz sources,UV finite part THEN IR. No input, physical
vacuum, scalar mass or normalization baseline was selected to force this.

## Actual support and the new scalar response

Full primary/replay QG data retain12/33 JaJa source-only rows. They have
zero field Hessian. The original Ja action is affine in Lambda and also
has zero field Hessian. Hence the BARE proper two-Ja loop Gamma_ij is
zero through firstu in this restriction; a finite local A_ij is retained.

The broken probe's one-Ja terms have132 B-derivative,33 Lambda,296 scalar,
1336 BB and600 Ca rows. The unbroken probe has48 B-derivative and12 Lambda
rows. Complete intrinsic01 even-plane square equality is rechecked, not
inferred from these counts. This retains the ghost pair and source contacts
needed in the loop expression.

The actual N Lambda x mixing has296 canonical entries and only broken
rows. Independent quadratic inversion and stationary equations give

 y_u=-Omega E(1-E)J,
 Lambda_u=2i E(1-E)J,
 x_u=2i (E/a) N^T(1-E)^2 J, a=p^2+m_reference^2>0.

The constant-chain correction changes the scalar response; its omission
is sensitive. These are linear mean responses, not the nonlinear y_ij
needed for every tadpole. The scalar references remain mathematical
references, not a measured massive physical vacuum.

## A loop-plus-source theorem, not the previous external-tree bound

At zero remaining fields/sources translation invariance leaves loop nodes
q,q+k and external tree momentum k. The other four Legendre terms have
ordinary soft degrees bounded by(2,2,2). Their joint dimension is8, with
individual node codimension4. The complete linear-flat test requires

       a<4, b<4, c<4, a+b+c<8.

All27 integer upper-bound combinations through2 pass; the worst margin
is2. PROOF gives the sector decomposition establishing local integrability
for the entire joint kernel, not just each factor. Seagulls have independent
q,k and better bounds. Old constant chains, firstu blocks and SMA matter
edges are inherited within their audited support.

The decisive majorant also has an exact global check:

 integral dq dk/(2pi)^8 e^-s(q^2+k^2)/[q^2 k^2(q+k)^2]
             =2log2/[s(16pi^2)^2].

Schwinger and four-dimensional angular/Newton derivations agree. Setting
k=0 first instead gives a critical q^-4 loop integral. Degrees(3,3,2)
give a simultaneous log divergence despite every individual degree<4.
These sensitive controls explain why the new joint argument is necessary.
They do not assign those excluded kernels to the actual model.

The SAME complete proper symbol subtraction is differentiated and evaluated
on the SAME regulated mean before finite part. The inherited q^-5 hard
remainder remains integrable when multiplied by external trees of combined
pole<=2; independent source Schwartz functions control large k. The
bounded free-edge IR approximants then converge under the joint majorant.
All inverse/source defects remain at finite IR regulator. No arbitrary
finite-part cyclicity, diagonal restriction or UV/IR exchange is invoked.

## Finite terms and normalization jets remain visible

A direct heat-bubble control gives

 FP I_t(k)=[-log(k^2/mu^2)-gamma_E+1-log2]/(16pi^2),

whose tree-sewn Gaussian pairing is
[log(s mu^2)+1-log2]/[s(16pi^2)^2], generically NONZERO. Independent
heat/Schwinger pairings agree at40-digit working precision; this supplements
the analytic derivations, not independent physical validation. At diagnostic
s=1.7,mu^2=2.3 the normalized finite value is
0.9825824667278406432959249522684809828. These are test widths and subtraction
parameters of a scalar control, not fitted Spin(10) couplings or coefficients.

The exact heat power-subtraction control leaves -a if the regulated tree
e^-tK/K is replaced by1/K in the subtraction of a/t. Subtracting at the
same regulated mean cancels it. Thus a valid joint IR bound does not
authorize commuting sewing with a partially subtracted UV expression.

All four finite jets A_ij,A_i,phi[y_j],A_j,phi[y_i],A_phi,phi[y_i,y_j]
remain symbolic with inherited admissibility conditions. No A0,A1,A2
coefficient, chi4,kappa,b0 or IR baseline is set or equated. Not every
finite local choice is claimed to satisfy every quantum Ward requirement.

## Focused result-to-claim assessment

The strongest supported claim is a common FOUR-non-tadpole-term formal
Euclidean extension for the selected even two-Ja sector. Actual support,
scalar response and joint flats are checked; explicit analytic estimates
carry the all-finite-Born argument. No proof assistant has formalized it.
The scalar integral controls validate the domain reasoning, not a new
Spin(10) tensor. Prior NSP proper products and RAS auxiliary extension
are authenticated/reused rather than their loops being recalculated.

This removes a specific loop/tree joint-domain gap. It does not prove the
complete five-term connected functional. In particular the scalar finite
A0 tadpole and its nonlinear mean response remain unqualified. Nor does
integrability establish cancellation of the actual connected Ward response.
General means, odd/mixed90-source products, physical K products, repeated
Slavnovs, global chiral phase/measure, causal/vacuum limits, E5/A5 and
physical viability retain their separate obligations. No authority change.

The latest supplied assessment through e08257cd correctly identified these
bridges; ESM/RAS and CTS now address different parts of them. Its external
constructive-QFT announcement remains unimported context. No new external
theorem or experiment was checked or adopted in this bounded calculation.

The AI capability demonstrated is the structural reduction of a connected
product to its actual momentum arrangement, coupled to a distinct analytic
integral and subtraction-order controls. Action/chart/reference premises,
Python/SymPy infrastructure and AI authorship remain shared. Independent
routes are computational/analytic corroboration, not independent scientists
or empirical evidence. All scientific workers passed on their first run;
routine read-only metadata inspection initially requested an absent
elapsed_seconds field, corrected without altering scientific evidence.

Next smallest authorized test: recover the scalar/auxiliary coupling in
the nonlinear y_ij and characterize all finite scalar A0 tadpoles under
the actual covariant reference. Decide whether their zero-total-momentum
pairing has a compatible extension. Only then assemble the full five terms
and differentiate the actual connected Ward/source transports.

## Execution and preservation

Native8.5016175s,review0.7194773s,adversarial0.2711055s afterimports.
Native300/review180s,8GiB sampled private,350MiB available-pagefile launch
floor,16MiB packet. Largest observed scientific-worker private sample
779485184bytes; sampling is not a peak measurement. Source copies, frozen
input hashes and complete captures are retained. No scientific failed run.
E4once/no--fresh and old-tree/raw-index checks are required before the local
commit and owned by the final receipt. Custody exit2/seven remains NOTPASS.
Sole authority state113/34of39,E5/A5 OPEN remains unchanged.
