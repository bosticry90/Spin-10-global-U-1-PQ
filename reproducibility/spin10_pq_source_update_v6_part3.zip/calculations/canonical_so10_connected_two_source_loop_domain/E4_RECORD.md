# Delegated read-only E4 validation

Prospective after CTS native, independent review and adversarial success.
Run python -B tools/research_check.py e4 ONCE, no--fresh, under the current
delegated convention. Preserve complete command/capture/events. Expect
native0,steps[0,0,0,0,0,2],terminalCOMPLETED,custody exit2/seven NOTPASS.
Authentication and execution do not promote a scientific gate. Observe
actual elapsed<300s,8GiB sampled private,350MiB launch floor. A changed
count/exit or bound failure requires explicit review, not automatic PASS.
