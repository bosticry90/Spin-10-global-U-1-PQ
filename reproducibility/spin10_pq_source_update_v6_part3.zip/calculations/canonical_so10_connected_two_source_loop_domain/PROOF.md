# A joint domain for the four non-tadpole terms

Prospective until actual support, separate review and evidence validation.
Analytic arguments below are explicit mathematics, not proof-assistant
certification or a consequence of matching numeric constants.

## 1. Actual source responses and the retained operator expression

Use the CNS five-term formula, with ESM/RAS actual signs. At j=J=0 the
mean is zero. The four terms considered here are

 -Gamma_ij-Gamma_i,phi[y_j]-Gamma_j,phi[y_i]
              -Gamma_phi,phi[y_i,y_j].                         (1)

The fifth term -Gamma_phi[y_ij] remains separate. It must not be discarded
by calling (1) the complete connected Hessian.

At each finite regulator these four terms can be organized using

 P_i=H_i+H_phi[y_i],
 Q_ij=H_ij+H_i,phi[y_j]+H_j,phi[y_i]+H_phi,phi[y_i,y_j].

Their Gaussian contribution is -STr(G Q_ij-G P_j G P_i)/2. This expression
retains matrix order; its expansion at firstu is the inherited ordered
NSP resolvent differentiation. It does not add H_phi[y_ij] to Q_ij.
Each finite Born coefficient keeps all old constant scalar/mixed chains
and at most one u insertion. Matter lines have pole degree1, not a worse
massless block; the SMA doubled Gaussian and its signs remain inherited.

The actual base Ja action is -i Ja Lambda, whose field Hessian is zero.
The full first-u QG has JaJa contacts12/33, with no additional fields.
Consequently its field Hessian H_ij also vanishes for two Ja derivatives.
Thus the BARE proper Gamma_ij contribution is zero through firstu. This
does NOT set the finite source-only A_ij normalization to zero or eliminate
the cross and field-Hessian terms in (1). No analogous assertion is made
for arbitrary JL or physical sources.

The actual linearized even-plane equations include N Lambda x. Through
first intrinsic degree, suppress sector/color indices and put a=p^2+m^2,
E=exp(-t p^2), Omega=eta_H or xi. The longitudinal free reference is

 Sref=i Lambda y+Omega Lambda^2/2+a x^2/2,
 V=N Lambda x,
 U=(i(y-J)+Omega Lambda/2+N x)^2 mod intrinsic>=2.

This is the complete actual quadratic restriction, with N only in M and
296 canonical entries. Matrix notation replaces N by the actual tensor
and a^-1 by each positive reference scalar Green; the calculation is
coefficientwise and does not resum an infinite N series. At fixed heat,
the source mean has y=EJ,Lambda=x=0 at u0. Its first-u linear responses are

 y_u=-Omega E(1-E)J,
 Lambda_u=2i E(1-E)J,
 x_u=2i (E/a) N^T (1-E)^2 J.                         (2)

The second N crossing is intrinsic2 and outside this truncation. The
double heat difference in the scalar response requires BOTH the direct
Nx vertex and the constant-chain correction to the Green function.
It is not legitimate to replace it with one heat difference. At finite
IR proof smoothing, use direct diagrams with every free edge smoothed;
keep inverse defects instead of imposing a false inverse identity.

Since B_mu=-i p_mu y/p^2, each first response has pole degree<=1;
Lambda and the positive-reference x responses have degree0. Transverse
pieces vanish in this affine source restriction. This proves the needed
tree bound without assuming all nonlinear scalar means or tadpoles zero.

## 2. The two independent momentum variables

After source differentiation and evaluation at zero remaining fields and
sources, proper two-point coefficients are translation invariant. Their
two external mean/source momenta are k and -k. They are NOT independent
transfers k and l inside a two-point loop. Independent source directions
still pair as h_i(k)h_j(-k); this product is Schwartz. There is no k=0
restriction or identification of the two source directions.

A proper two-vertex loop therefore has nodes q and q+k. A seagull has
one node q. Collapsing the already audited constant chains and single-u
block does not add transfer nodes or increase ordinary loop pole degree
beyond2. The two external mean responses in (1) add at most two degrees
at k=0. A mixed source/field term adds at most one. The finite seagull
and source contacts retain both source labels even when they share a
vertex. Every ordinary two-loop-node majorant is bounded locally by

 |q|^-a |q+k|^-b |k|^-c,  0<=a,b,c<=2.               (3)

This is one quantum loop plus an external source momentum integral,
not a two-quantum-loop amplitude. The seagull majorant has independent
q and k and degrees<=2. Positive scalar masses improve these bounds.
All polynomial derivative numerators only improve soft scaling or give
harmless bounded factors on compact sets.

For three distinct linear node maps q,q+k,k into R4, local integrability
requires individual exponents<4 and their sum<8. Here is a direct proof.
Away from their common intersection only one node can vanish; its radial
integral is integral r^(3-a)dr. Near their common origin, at least two
of the three node norms are comparable to their maximum R, by the triangle
inequality. Partition into which node is smallest. If its radius r<R/2,
the other two have size comparable R and integration in the small vector
gives R^(4-a_small). The large-vector integral is then bounded by
integral_0^1 R^(7-a-b-c)dR. Where all three are comparable, ordinary
eight-dimensional radial integration gives the same exponent. Thus both
the individual and collective conditions are sufficient; the corresponding
rank-one and simultaneous radial restrictions show why they are necessary.
The worst ordinary total is6, leaving two powers of margin.

Bounded even free-edge IR profiles are dominated by (3) and tend to1 off
the nodes. Thus the joint distribution has a common locally-L1 IR limit
with no extra delta at the triple intersection in THIS construction.
This is not an assertion that an arbitrary restriction of that distribution
to k=0 exists. No tadpole delta(p) is paired in this four-term proof.
Matching to the actual A0 reference profiles uses the inherited rooted
free-edge construction: at background0 the profiles are scalar functions
on the retained q,q+k,k edges. Retain their source/inverse defects at
finite epsilon. No cyclicity of a finite-part trace is used.

## 3. UV subtraction before sewing, not an exchange of limits

Use the SAME complete hard-shell subtraction D_t(phi,J) already defining
the NSP proper functional. Differentiate its full polynomial and evaluate
it on phi_t BEFORE its finite part. It is not replaced with D_t(phi_0,J).
In the hard region |q|>2(1+|k|), the inherited full symbol subtraction
leaves an integrable q^-5 remainder, bounded by a finite polynomial in k
times a Schwartz seminorm. Multiplication by the external tree responses
adds at worst |k|^-2. This is locally integrable in4D; the external source
Schwartz product controls large k. On the complementary region, bounded k
uses the locally-L1 joint bound (3); unbounded k is controlled by those
same Schwartz seminorms and the finite polynomial degree of each coefficient.
The finite heat constants and powers in D_t remain intact. These arguments
give a common tempered remainder for all four terms, coefficientwise in
the finite Born expansion, in the order UV finite part THEN IR limit.

This extends the inherited proper-domain remainder argument to the new
tree factors. It does not use the RAS external-tree estimate to control
an internal quantum-loop momentum. No convergence of the whole Born series,
arbitrary smoothing profile or massless scalar construction is claimed.

The scalar worst-case diagnostic makes the logarithmic part explicit:

 I_t(K)=integral dq/(2pi)^4 exp[-t(q^2+(q+k)^2)]/[q^2(q+k)^2], K=k^2>0,
 16pi^2 I_t=2 integral_(1/2)^1 E1(t K x)dx,
 FP I_t=[-log(K/mu^2)-gamma_E+1-log2]/(16pi^2).       (4)

Schwinger parameters a,b>=t and coordinates v=a+b,x=a/v prove (4);
v>=t/min(x,1-x). Its tree-sewn Gaussian pairing is

 integral dk/(2pi)^4 e^-sK/K FP I_t
       =[log(s mu^2)+1-log2]/[(16pi^2)^2 s].         (5)

This is nonzero generically and locally integrable, including K0 after
source integration. It is an analytic majorant/control, NOT a measured
Spin(10) coefficient or an adopted new physical subtraction scheme.

Power subtractions require more care than (4). For T_t=e^-tK/K and an
actual local divergent coefficient a/t, subtracting T_t*a/t at the same
mean cancels exactly. Sewing first but subtracting T_0*a/t instead leaves
FP [(T_t-T_0)a/t]=-a, a nonzero local remainder. Gaussian source pairing
is -a/[(16pi^2)s^2]. This is the exact heat version of the inherited T1*a
control. It forbids a convenient exchange of sewing and proper subtraction;
it does not determine any unknown physical a or finite normalization.

## 4. Finite jets and the claim boundary

The common allowed finite functional A(phi,J) contributes to (1) through

 -A_ij-A_i,phi[y_j]-A_j,phi[y_i]-A_phi,phi[y_i,y_j].   (6)

All four jets are retained symbolically with inherited locality, covariance,
reality, parameter-ring and ghost/dimension requirements. A2 source-only
JaJa survives even though the bare proper loop Gamma_ij is zero here.
A0 Hessians and A1 mixed jets also survive. The missing fifth jet
-A_phi[y_ij] belongs to the remaining tadpole investigation, not to (6).
No unique baseline, complete mixing rank or Ward restoration follows from
these analytic bounds. The four-term piece alone is not advertised as an
integrable Hessian of a complete connected functional at nonlinear means.

This constructs the common FOUR-term extension in the declared j0 even
two-Ja sector. RAS owns only the auxiliary finite-tadpole zero extension.
Scalar finite A0 tadpoles and their nonlinear responses must be treated
before claiming a complete five-term selected connected construction.
The actual connected Slavnov response must then differentiate all operator
coefficients/source transports; none is proved zero by this integrability
result. Odd/mixed90-source products, general means, physical K products,
multiple independent Slavnov insertions, phase/measure, causal/vacuum limits,
E5/A5 and physical viability remain open in their separate qualified scopes.
