# CTS1: the four non-tadpole connected two-source terms

Prospective at6bcba57dc12daacc6c3156225fc4a7ddc3888b99/main. Read-only
preflight: clean, no matching workers. CurrentAGENTS/V663, charter, solo
review and epistemic ladder apply. Goal ACTIVE. State113/34of39,E5/A5 OPEN,
custody2/seven NOTPASS unchanged. No agents, new checkout or remote action.

Question: do the other FOUR terms of the even two-Ja Legendre formula have
a common loop/source-momentum extension? RAS proved the finite auxiliary
tadpole term, not these loops. Reuse NSP proper derivatives, CNS endpoints,
ESM/RAS regulated responses and UDR constant-chain bounds. A new large
coefficient expansion would not answer this domain question.

Claim under test: the four non-tadpole terms, at zero ordinary source and
zero undifferentiated nonminimal source, admit a common formal one-loop
extension with the SAME complete proper UV subtraction evaluated on the
SAME regulated mean, followed by IR removal. Keep both independent source
directions and source-only normalization jets. This is NOT yet the full
five-term connected construction or its Slavnov identity.

Domain: unchanged unshifted SMA/CSW/EDS, A0, constant first-u probes,
rho0 AFTER differentiation, intrinsic0/1, independently Schwartz Ja
directions. Positive scalar REFERENCE masses, actual mixed Green signs,
all finite old constant-chain coefficients, no shifted physical vacuum.
No repeated independent Slavnov operations, physical K sources, odd Ja/JL
mixtures, general nonzero means or new IR/physical subtraction prescription.
Keep chi4,kappa,b0,IR and allowed finite A jets distinct and symbolic.

Expected evidence: actual full QG source support and affine plane maps;
scalar response derived with the actual Nx mixing; a two-momentum graph
reduction; explicit analytic integrability and UV-remainder estimates;
distinct Schwinger/heat bubble calculations, Gaussian source pairing and
subtraction-order controls. A numerical fixture supplements the proof;
passing source counts or proof-string checks cannot certify it.

Methods: native full jet/graded source support plus exact reference-block
inversion and rank/power-counting calculation. Separate review derives
response from stationary equations, graph flats from independent linear
coordinates, and bubble finite part by Schwinger parameters versus a
direct heat-integral pairing. No new model-specific quantum coefficient
is inferred from those scalar majorant diagnostics.

Falsifiers: missing source contact; scalar pole worse than the inherited
positive-reference support; a rank-one exponent>=4 or rank-two sum>=8;
uncontrolled UV subtraction/tree cross term; inability to retain a finite
normalization jet; invalid restriction to k=0. Negative controls must
expose critical scalar powers and wrong subtraction order. Keep actual
kernel ordering; no inverse heat on Schwartz products, arbitrary FP
cyclicity, UV/IR exchange or dropping finite-IR inverse defects.

Freeze sources/copies and immutable input hashes before native300s and
review180s afterimports. Private8GiB sampled, launch available-pagefile
350MiB, packet16MiB. Full captures and any failures retained. Exhaustion
is INCOMPLETE, not an anomaly. Validate bounded work and E4 once/no--fresh
before local commit; all old bytes and scientific authority preserved.

Possible results: a common FOUR-term extension; a missing joint-domain or
normalization condition; bounded underdefinition. The scalar/other finite
tadpole term and actual connected Ward response remain explicit next
obligations. An existence result here does not measure its finite amplitude,
complete the connected source family, QAP, E5/A5 or physical unification.

Latest user assessment through e08257cd is frozen as an input. It correctly
separates proper products, finite algebra and continuum sewing, and warns
about shared Hessian errors and subtraction order. ESM/RAS have since
resolved the selected auxiliary subproblem. Its external constructive-QFT
announcement remains context only; no external theorem is imported or
revalidated by this calculation. Focused result-to-claim review will state
the exact advance, remaining scalar tadpole/variation and shared premises.
