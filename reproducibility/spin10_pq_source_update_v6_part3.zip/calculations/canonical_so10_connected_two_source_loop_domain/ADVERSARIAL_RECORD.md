# CTS3: a global integral check of the joint soft majorant

Prospective after native/review success, before this new calculation.
Same frozen scientific scope, resources and authority ceiling as RECORD.
Do not edit earlier sources or their preparations. This additional test
checks the decisive graph-majorant interpretation by two mathematical
routes rather than merely rerunning the finite rank inequalities.

Compute the normalized eight-dimensional Gaussian integral of
1/[q^2 k^2(q+k)^2] with common positive test width s. Derive via Schwinger
parameters and, separately, the four-dimensional angular/Newton identity.
Expected value 2log2/[s(16pi^2)^2]. This is a majorant diagnostic, not an
action coefficient. Check the angular identity numerically away from and
at equal radii. Negative control: setting k=0 first yields a critical
q^-4 integral, so that restriction cannot be justified by the joint result.
Also retain the rank-two total-degree8 counterexample with each individual
degree below4. No new physical regulator or normalization is adopted.

The proof explains all-finite support; numerical integration only checks
its implementation. Success cannot supply the missing scalar tadpole or
connected Ward identity. Keep captures, source copies, input hashes and
adversarial limitations in the existing result-to-claim assessment.
