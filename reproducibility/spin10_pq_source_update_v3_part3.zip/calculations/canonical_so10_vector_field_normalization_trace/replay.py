"""First-order jet pullback and ordered-insertion/proper-time trace route."""
import os,threading,time
import sympy as s
from data import q,z1,z2,eps,clean,packed,mat,CAL,setup,assemble,emit

class Jet:
    def __init__(self,a,b=0):self.a=s.sympify(a);self.b=s.sympify(b)
    def __add__(self,o):
        if not isinstance(o,Jet):o=Jet(o)
        return Jet(self.a+o.a,self.b+o.b)
    def __neg__(self):return Jet(-self.a,-self.b)
    def __sub__(self,o):return self+-o
    def __mul__(self,o):
        if not isinstance(o,Jet):o=Jet(o)
        return Jet(self.a*o.a,self.a*o.b+self.b*o.a)
    def inverse(self):return Jet(1/self.a,-self.b/self.a**2)
    def root(self):return Jet(s.sqrt(self.a),self.b/(2*s.sqrt(self.a)))

def bare_jets():
    Z=Jet(1,q);X1=Jet(1,z1);X2=Jet(1,z2);S=Z.root();inverse=S.inverse()
    assert clean((S*inverse).a-1)==0 and clean((S*inverse).b)==0
    rr=S*S*X1.inverse();ss=X2;rs=S*(X2*X1.inverse()).root()-S
    # sQ inhomogeneous chain factor inverseS is applied before varying F_B.
    ghostkin=S*inverse;ghostv=S;ghostmass=(X1*X2).root();sourcehom=inverse*S
    return {'physical_Q_quadratic':Z.b,'gf_longitudinal':rr.b,'gf_scalar_mass':ss.b,'mixed_after_kinetic':rs.b,
      'ghost_kinetic':ghostkin.b,'ghost_vector_relative':ghostv.b,'ghost_mass_relative':ghostmass.b,'ghost_scalar_relative':ghostmass.b,
      'source_inhomogeneous':inverse.b,'source_homogeneous':sourcehom.b,'cotangent_source_relative':inverse.b,
      'auxiliary_contact_per_color':z1/2,'pure_Q_contact_per_vector_coordinate':q/2,'linear_Q_measure_Jacobian_contact':-q/2}

def actual_weights(b,P):
    f={(a,c,d):s.sympify(v) for a,c,d,v in b['f']}
    ad=[s.SparseMatrix(45,45,{(d,c):v for (a,c,d),v in f.items() if a==h}) for h in range(45)]
    E=mat(packed(CAL/'canonical_so10_vector_quartic_ir_matching/replay_tables.json.gz')['light_embedding'])
    probes=[sum((E[a,h]*ad[a] for a in range(45) if E[a,h]),s.zeros(45)) for h in [0,1,4]]
    return [[clean(-s.trace(R*T*T)) for T in probes] for R in P[1:]]

def main():
    start=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
    jets=bare_jets();b,O,G,qval,heat,P,masses,fci,qdv,qmv=setup('replay');weights=actual_weights(b,P)
    # Ordered trace: kinetic part Kv-M²; its identity contact has zero
    # background derivative in this prescription. The positive proper-time
    # boundary provides the same relation before continuation.
    D=4-2*eps;cv=(D/12-2)/2
    mass=clean(12*cv*qval/eps);kinetic=clean(-12*cv*qval/eps)
    # WHP1 operator/heat identities with the already DERIVED ghost factor.
    wv=clean(qval/(2*eps));wc=clean(-qval/(2*eps));total=clean(kinetic+mass+wv+wc)
    pref={'kinetic':kinetic,'mass':mass,'width_vector':wv,'width_ghost':wc,'total':total,
      'omitted_ghost':kinetic+mass+wv,'reversed_ghost':kinetic+mass+wv-wc,
      'premature_D4_width_heat':kinetic+mass+wc,'duplicated_mass_only':total+mass,
      'false_universal_FCI_mass_shift':clean((D-25)*qval/(2*eps)),'double_complete_direction':2*total}
    emit('replay',assemble('replay',jets,weights,pref,'replay'),start,
      {'independent_first_order_jet_algebra':True,'weights_from_actual_adjoint_projectors':True,
       'ordered_insertion_and_positive_boundary_used':True,'WHP1_qualified_proof_reused_not_rerun':True});timer.cancel()
if __name__=='__main__':main()
