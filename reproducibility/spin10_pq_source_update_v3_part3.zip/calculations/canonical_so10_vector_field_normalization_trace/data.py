"""Inherited tensors, canonical output and exact-once comparison for VFN1."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import gzip,json,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
eps=s.Symbol('eps',real=True);q,z1,z2=s.symbols('q z1 z2',real=True)
z,zz=s.symbols('z zeta2',real=True);hs=s.symbols('h1:5',real=True)
LOC={str(v):v for v in [eps,q,z1,z2,z,zz,*hs]}
@lru_cache(100000)
def clean(v):return s.cancel(s.expand(v))
def tidy(M):return s.SparseMatrix(M).applyfunc(clean)
def zero(M):assert not tidy(M).todok(),'NONZERO_MATRIX'
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def mat(d):return s.SparseMatrix(*d['shape'],{(i,j):s.sympify(v,locals=LOC) for i,j,v in d['entries']})
def enc(M):
    M=tidy(M);return {'shape':list(map(int,M.shape)),'entries':[[int(i),int(j),str(v)] for (i,j),v in sorted(M.todok().items())]}
def expr(v):return s.sympify(v,locals=LOC)
def setup(role):
    b=packed(CAL/'canonical_so10_background_threshold_inputs'/f'{role}_tables.json.gz')
    O=s.SparseMatrix(328,45,{(i,j):s.sympify(v) for i,j,v in b['orbit']})
    G=s.SparseMatrix(45,45,{(i,j):s.sympify(v) for i,j,v in b['Gram']});zero(O.T*O-G)
    qdv=packed(CAL/'canonical_so10_quantum_vector_derivative_uv'/f'{role}_tables.json.gz')
    qmv=packed(CAL/'canonical_so10_quantum_vector_mass_uv'/f'{role}_tables.json.gz')
    qval=s.sympify(qdv['formal_cancelling_deltaZ_Q']);zero(mat(qmv['field_normalization_mass_jet'])-qval*G)
    zero(mat(qdv['longitudinal_pole_matrix']))
    old=packed(CAL/'canonical_so10_width_hard_projection'/f'{role}_tables.json.gz')
    heat={k:expr(v) for k,v in old['heat_coefficients'].items()};P=list(map(mat,old['projectors']))
    fci=packed(CAL/'canonical_so10_finite_counterterm_insertion'/f'{role}_v3_tables.json.gz')
    masses=list(map(s.sympify,fci['vector_mass_eigenvalues']))
    return b,O,G,qval,heat,P,masses,fci,qdv,qmv
def operators(jets,b,O,G,qval,qdv,qmv):
    def component(name):return clean(s.diff(jets[name].subs(z1,q),q)*qval)
    assert clean(jets['gf_longitudinal'].subs(z1,q))==0
    assert jets['gf_scalar_mass'].has(z2) and jets['mixed_after_kinetic'].has(z2)
    a=component('physical_Q_quadratic');ghost=component('ghost_mass_relative');mixed=component('mixed_after_kinetic')
    source=component('source_inhomogeneous');fp=component('ghost_vector_relative');ft=component('ghost_scalar_relative')
    mass=a*G;zero(mass-mat(qmv['field_normalization_mass_jet']))
    zero(a*s.eye(45)-mat(qdv['counterterm_operator_matrices']['a']))
    zero(-2*a*s.eye(45)-mat(qdv['counterterm_operator_matrices']['c']))
    assert component('ghost_kinetic')==0 and component('source_homogeneous')==0
    tensors={}
    for name,factor,entries,shape in [('FP_vector',fp,b['f'],[45,45,45]),('source_background',source,b['f'],[45,45,45]),('FP_scalar',ft,b['T'],[45,45,328])]:
        tensors[name]={'shape':shape,'entries':[[*entry[:-1],str(clean(factor*s.sympify(entry[-1])))] for entry in entries]}
    loop=mat(qmv['loop_mass_matrix']);parameter=mat(qmv['existing_parameter_mass_jet'])
    zero(loop+parameter+mass);double=tidy(loop+parameter+2*mass);assert double.todok()
    return {'q_YM_color_coefficient':enc(a*s.eye(45)),'q_mass':enc(mass),
      'first_width_longitudinal_color_coefficient':enc(qval*s.eye(45)),
      'q_ghost_mass':enc(ghost*G),'q_scalar_GF_mass':enc(s.zeros(328)),
      'q_mixed_density_coefficient':enc(mixed*O),'source_Q_Dc_color_coefficient':enc(source*s.eye(45)),
      'source_Q_homogeneous_variation':'0','tensor_maps':tensors,
      'second_width_diagnostic_ray':{'scalar_GF_mass':enc(O*O.T),'ghost_mass':enc(G/2),'mixed_density_coefficient':enc(O/2)},
      'doubled_complete_q_direction_mass_renormalization_residual':enc(double),
      'other_width_matrix_slots':'NOT_FIXED_OR_EXHAUSTED',
      'units':'YM/DD/source_Dc: ell*g10²/eps; mass/ghost_mass/FP_scalar: ell*g10^4/eps; mixed/FP_vector/source_background: ell*g10³/eps; tensor maps use the fixed BFT Grassmann order'}
def rows(weights,masses,prefactors,method):
    result=[]
    for i,name in enumerate(['U1','SU2','SU3']):
        channels={};by_mass=[]
        for n,prefix in prefactors.items():
            out={-1:0,0:0,1:0}
            for r,m in enumerate(masses):
                j=z-hs[r];tau=weights[r][i]
                if method=='primary':
                    series=s.series(prefix*s.exp(eps*j+eps**2*zz/2),eps,0,2).removeO().expand()
                    for power in out:out[power]+=tau*series.coeff(eps,power)
                else:
                    residue=clean(s.limit(eps*prefix,eps,0));constant=clean(prefix-residue/eps)
                    assert not constant.has(eps)
                    H=[1,j,(j*j+zz)/2]
                    for k,power in enumerate([-1,0,1]):out[power]+=tau*(residue*H[k]+(constant*H[k-1] if k else 0))
            channels[n]={str(power):str(s.expand(clean(v))) for power,v in out.items()}
        for r,m in enumerate(masses):by_mass.append({'mass_eigenvalue':str(m),'ratio_to_60':str(m/60),'tau':str(weights[r][i])})
        result.append({'group':name,'positive_mass_assignments':by_mass,'coefficients':channels})
    return result
def assemble(role,jets,weights,prefactors,method):
    b,O,G,qval,heat,P,masses,fci,qdv,qmv=setup(role)
    assert len(weights)==4 and all(len(r)==3 for r in weights)
    assert clean(prefactors['kinetic']+prefactors['mass']+prefactors['width_vector']+prefactors['width_ghost'])==0
    assert prefactors['total']==0 and prefactors['double_complete_direction']==0
    return {'schema':'C1_VECTOR_FIELD_NORMALIZATION_TRACE_TABLES_V1',
      'general_bare_jet_coefficients':{k:str(clean(v)) for k,v in jets.items()},'measured_q':str(qval),
      'operators':operators(jets,b,O,G,qval,qdv,qmv),'per_mass_prefactors_times_H_epsilon':{k:str(clean(v)) for k,v in prefactors.items()},
      'trace_rows':rows(weights,masses,prefactors,method),'full_H_epsilon':'exp(gammaE*eps)*Gamma(1+eps)*exp(eps*(z-h_r))',
      'first_width_reused_qualified_theorem':True,'positive_heavy_total_F2_all_Laurent_orders':'0',
      'identity_contacts':'RETAINED; background derivatives vanish only in original dimensional C1 prescription',
      'general_off_shell_E_remainder':'RETAINED_NOT_ZERO',
      'insensitive_controls':['whole_correlated_direction_duplicated_F2','mixed_VS_omission_single_trace','identity_contact_deletion_F2','source_only_cotangent_error_at_sources_zero'],
      'second_width':'INDEPENDENT_COMMUTING_DIAGNOSTIC_COORDINATE; general matrix module not exhausted',
      'scope':'positive_heavy_local_background_F2_only; not massless/full EFT/finite C1',
      'finite_scheme_or_full_quantum_equivalence_adopted':False}
def emit(role,table,start,diagnostics):
    raw=(json.dumps(table,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/(role+'_tables.json.gz')).open('xb') as out:out.write(blob)
    value={'schema':'C1_VECTOR_FIELD_NORMALIZATION_TRACE_NATIVE_V1','execution_state':'COMPLETED',
      'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(blob).hexdigest(),
      'raw_bytes':len(raw),'packed_bytes':len(blob),'diagnostics':diagnostics,'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(value,sort_keys=True,separators=(',',':')),flush=True)
