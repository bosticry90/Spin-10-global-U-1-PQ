"""Independent bare map, exact tensor, Laurent and proper-time audit."""
from pathlib import Path
from hashlib import sha256
import gzip,json,os,threading,time
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
eps=s.Symbol('eps',real=True);q,z1,z2=s.symbols('q z1 z2',real=True)
z,zz=s.symbols('z zeta2',real=True);hs=s.symbols('h1:5',real=True);LOC={str(v):v for v in [eps,q,z1,z2,z,zz,*hs]}
def clean(v):return s.cancel(s.expand(v))
def expr(v):return s.sympify(v,locals=LOC)
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def mat(d):return s.SparseMatrix(*d['shape'],{(i,j):s.sympify(v) for i,j,v in d['entries']})
def zero(M):assert all(clean(v)==0 for v in M.todok().values())
def mpnum(v):
    v=s.Rational(v);return mp.mpf(int(v.p))/int(v.q)

def bare_and_operators(tab):
    expected={'physical_Q_quadratic':q,'gf_longitudinal':q-z1,'gf_scalar_mass':z2,'mixed_after_kinetic':(z2-z1)/2,
      'ghost_kinetic':0,'ghost_vector_relative':q/2,'ghost_mass_relative':(z1+z2)/2,'ghost_scalar_relative':(z1+z2)/2,
      'source_inhomogeneous':-q/2,'source_homogeneous':0,'cotangent_source_relative':-q/2,
      'auxiliary_contact_per_color':z1/2,'pure_Q_contact_per_vector_coordinate':q/2,'linear_Q_measure_Jacobian_contact':-q/2}
    for name,value in expected.items():assert clean(expr(tab['general_bare_jet_coefficients'][name])-value)==0
    b=packed(CAL/'canonical_so10_background_threshold_inputs/primary_tables.json.gz')
    O=s.SparseMatrix(328,45,{(i,j):s.sympify(v) for i,j,v in b['orbit']});G=s.SparseMatrix(45,45,{(i,j):s.sympify(v) for i,j,v in b['Gram']})
    qq=s.sympify(tab['measured_q']);ops=tab['operators']
    for name,M in [('q_YM_color_coefficient',qq*s.eye(45)),('q_mass',qq*G),('first_width_longitudinal_color_coefficient',qq*s.eye(45)),
      ('q_ghost_mass',qq*G/2),('q_scalar_GF_mass',s.zeros(328)),('q_mixed_density_coefficient',-qq*O/2),('source_Q_Dc_color_coefficient',-qq*s.eye(45)/2)]:zero(mat(ops[name])-M)
    for name,M in [('scalar_GF_mass',O*O.T),('ghost_mass',G/2),('mixed_density_coefficient',O/2)]:zero(mat(ops['second_width_diagnostic_ray'][name])-M)
    assert ops['source_Q_homogeneous_variation']=='0' and expr(tab['general_bare_jet_coefficients']['gf_scalar_mass']).has(z2)
    domains={}
    for name,base,co,shape in [('FP_vector',b['f'],qq/2,[45,45,45]),('source_background',b['f'],-qq/2,[45,45,45]),('FP_scalar',b['T'],qq/2,[45,45,328])]:
        d=ops['tensor_maps'][name];assert d['shape']==shape
        want={tuple(v[:-1]):clean(co*s.sympify(v[-1])) for v in base};got={tuple(v[:-1]):s.sympify(v[-1]) for v in d['entries']}
        assert want==got;domains[name]={'positions':int(s.prod(shape)),'nonzero':len(got)}
    qmv=packed(CAL/'canonical_so10_quantum_vector_mass_uv/primary_tables.json.gz');qdv=packed(CAL/'canonical_so10_quantum_vector_derivative_uv/primary_tables.json.gz')
    zero(mat(ops['q_mass'])-mat(qmv['field_normalization_mass_jet']));zero(mat(ops['q_YM_color_coefficient'])-mat(qdv['counterterm_operator_matrices']['a']))
    double=mat(qmv['loop_mass_matrix'])+mat(qmv['existing_parameter_mass_jet'])+2*mat(ops['q_mass'])
    zero(mat(ops['doubled_complete_q_direction_mass_renormalization_residual'])-double);assert double.todok()
    # Cotangent error is invisible at sources zero, but fails the actual map.
    wrong_hom=qq/2;wrong_inhom=0;assert wrong_hom!=0 and wrong_inhom!=(-qq/2)
    # Ignoring the BRST chain factor produces a spurious FP kinetic rescaling.
    wrong_canonical_mass=(z1+z2-q)/2
    assert s.diff(wrong_canonical_mass.subs(z1,q),q)==0
    assert s.diff(expected['ghost_mass_relative'].subs(z1,q),q)==s.Rational(1,2)
    # Explicit zero off-diagonal trace, without deleting the nonzero operator.
    a,c,m=s.symbols('a c m');assert s.trace(s.diag(a,c)*s.Matrix([[0,m],[m,0]]))==0
    assert mat(ops['q_mixed_density_coefficient']).todok()
    # Finite Gaussian contact and auxiliary contour completion controls.
    beta,alpha,F,bv,xi=s.symbols('beta alpha F b xi',real=True)
    K=s.Matrix([[2+beta*beta,beta],[beta,3+beta*beta]])
    assert clean((alpha*K).det()-alpha**2*K.det())==0
    assert clean(bv*F-xi*bv*bv/2-(-xi*(bv-F/xi)**2/2+F*F/(2*xi)))==0
    return qq,domains,{'forgotten_cotangent_homogeneous_error':str(wrong_hom),
      'forgotten_cotangent_source_zero_F2_test':'INSENSITIVE','wrong_BRST_chain_removes_required_ghost_q_component':True,
      'mixed_VS_single_trace_omission':'INSENSITIVE','constant_identity_contact_F2_deletion':'INSENSITIVE',
      'whole_q_direction_duplicate_F2_test':'INSENSITIVE','whole_q_direction_duplicate_detected_by_mass_operator_entries':len(double.todok())}

def exact_coefficients(tab,qq):
    expected={'kinetic':(10+eps)*qq/eps,'mass':-(10+eps)*qq/eps,'width_vector':qq/(2*eps),'width_ghost':-qq/(2*eps),
      'total':0,'omitted_ghost':qq/(2*eps),'reversed_ghost':qq/eps,'premature_D4_width_heat':-qq/(2*eps),
      'duplicated_mass_only':-(10+eps)*qq/eps,'false_universal_FCI_mass_shift':-(s.Rational(21,2)+eps)*qq/eps,'double_complete_direction':0}
    for name,prefix in expected.items():assert clean(expr(tab['per_mass_prefactors_times_H_epsilon'][name])-prefix)==0
    old=packed(CAL/'canonical_so10_finite_counterterm_insertion/primary_v3_tables.json.gz')
    masses=list(map(s.sympify,old['vector_mass_eigenvalues']));weights=[[s.sympify(v) for v in row] for row in old['vector_indices']]
    sums=[sum(row[i] for row in weights) for i in range(3)];assert sums==[8,6,5]
    prefixes={k:expr(v) for k,v in tab['per_mass_prefactors_times_H_epsilon'].items()};controls=[]
    for i,row in enumerate(tab['trace_rows']):
        for name,prefix in prefixes.items():
            pole=clean(s.limit(eps*prefix,eps,0));constant=clean(prefix-pole/eps);assert not constant.has(eps)
            out=[0,0,0]
            for r,x in enumerate(masses):
                j=z-hs[r];H=[1,j,(j*j+zz)/2]
                for k in range(3):out[k]+=weights[r][i]*(pole*H[k]+(constant*H[k-1] if k else 0))
            for k,power in enumerate(['-1','0','1']):assert clean(out[k]-expr(row['coefficients'][name][power]))==0
        for name in ['total','double_complete_direction']:assert all(expr(v)==0 for v in row['coefficients'][name].values())
        for name in ['mass','omitted_ghost','reversed_ghost','premature_D4_width_heat','duplicated_mass_only','false_universal_FCI_mass_shift']:
            assert expr(row['coefficients'][name]['-1'])!=0
        controls.append({'group':row['group'],'mass_only_pole':row['coefficients']['mass']['-1'],
          'false_FCI_universal_mass_shift_pole':row['coefficients']['false_universal_FCI_mass_shift']['-1'],
          'omitted_ghost_pole':row['coefficients']['omitted_ghost']['-1'],
          'premature_D4_pole':row['coefficients']['premature_D4_width_heat']['-1']})
    return masses,weights,prefixes,controls

def numerical_checks(tab,masses,weights,prefixes,qq):
    mp.mp.dps=80;errors=[];qv=mpnum(qq);zv=mp.mpf(2)/7
    ratios=[x/60 for x in masses];logs=[mp.log(mpnum(x)) for x in ratios]
    # Independent positive proper-time integrals: eps*I0 and x*I1.
    for e in [mp.mpf(1)/3,mp.mpf(1)/2]:
        for x in ratios:
            xv=mpnum(x)
            A=mp.quad(lambda u:mp.exp(-xv*u**(1/e)),[0,1,mp.inf])
            B=xv**(-e)*mp.quad(lambda t:t**e*mp.exp(-t),[0,1,mp.inf])
            want=mp.gamma(1+e)*xv**(-e)
            for val in [A,B]:
                error=abs(val-want)/(1+abs(want));assert error<mp.mpf('1e-45');errors.append(error)
            # Kinetic/mass and vector-width/ghost are evaluated through
            # separate integrals, not numerically set to a common value.
            total=qv/e*((10+e)*A-(10+e)*B+(A-B)/2)
            assert abs(total)/(1+abs(want))<mp.mpf('1e-45')
    sub={z:s.Rational(2,7),zz:s.pi*s.pi/6,**{h:s.log(x) for h,x in zip(hs,ratios)}}
    for i,row in enumerate(tab['trace_rows']):
        for name,prefix in prefixes.items():
            pole=clean(s.limit(eps*prefix,eps,0));constant=clean(prefix-pole/eps);p0,p1=mpnum(pole),mpnum(constant)
            def smooth(e):
                return sum((mpnum(weights[r][i])*(p0+p1*e)*mp.exp(mp.euler*e)*mp.gamma(1+e)*mp.exp(e*(zv-logs[r])) for r in range(4)),mp.mpf(0))
            for order,power in [(0,'-1'),(1,'0'),(2,'1')]:
                got=mp.diff(smooth,0,order)/mp.factorial(order)
                want=mp.mpf(str(s.N(expr(row['coefficients'][name][power]).subs(sub),85)))
                error=abs(got-want)/(1+abs(want));assert error<mp.mpf('1e-45');errors.append(error)
    return mp.nstr(max(errors),12)

def main():
    start=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
    tab=packed(HERE/'primary_tables.json.gz');assert tab==packed(HERE/'replay_tables.json.gz')
    for role in ['primary','replay']:
        rec=json.loads((HERE/(role+'_result.json')).read_bytes());blob=(HERE/(role+'_tables.json.gz')).read_bytes()
        assert sha256(blob).hexdigest()==rec['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==rec['tables_sha256']
    qq,domains,controls=bare_and_operators(tab);masses,weights,prefixes,tracecontrols=exact_coefficients(tab,qq)
    error=numerical_checks(tab,masses,weights,prefixes,qq)
    receipt={'schema':'C1_VECTOR_FIELD_NORMALIZATION_TRACE_VALIDATION_V1','execution_state':'COMPLETED',
      'status':'QUALIFIED_CORRELATED_Q_FIELD_FIRST_WIDTH_POSITIVE_HEAVY_F2_ZERO',
      'scientific_acceptance':'NOT_PERFORMED','scientific_authority':'34/39_UNCHANGED',
      'actual_bare_GF_FP_and_cotangent_pullback_checked':True,'actual_source_and_FP_tensor_domains':domains,
      'all_pole_finite_and_Oepsilon_coefficients_checked':True,'positive_heavy_total_F2_all_Laurent_orders':'0',
      'WHP1_theorem_reused_not_independently_reproved':True,'second_width_and_other_matrix_slots_not_fixed':True,
      'max_scaled_proper_time_and_Laurent_error':error,'operator_and_source_controls':controls,'trace_negative_controls':tracecontrols,
      'identity_contacts_off_shell_remainder_and_massless_scope_preserved':True,
      'massless_EFT_full_C1_full_QAP_or_field_equivalence_qualified':False,
      'new_physical_scheme_or_finite_normalization_adopted':False,'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(receipt,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
