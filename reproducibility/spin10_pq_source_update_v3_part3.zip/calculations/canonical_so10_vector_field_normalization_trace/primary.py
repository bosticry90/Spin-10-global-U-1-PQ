"""Exact bare-expression differentiation and independent kinetic/mass scaling."""
import os,threading,time
import sympy as s
from data import q,z1,z2,eps,clean,setup,assemble,emit

def bare_jets():
    t=s.Symbol('t');r,s0,P,k,V,M,U,A,B=s.symbols('r s P k V M U A B')
    Z=1+t*q;x1=1+t*z1;x2=1+t*z2;Qfac=s.sqrt(Z)
    def d(expr):return s.expand(s.diff(expr,t).subs(t,0))
    density=(Qfac*r+s.sqrt(x1*x2)*s0)**2/(2*x1)-Qfac*r*s0
    dd=d(density);ghost=k+Qfac*V+s.sqrt(x1*x2)*(M+U);gg=d(ghost);source=A/Qfac+B;ss=d(source)
    assert clean(Qfac/Qfac-1)==0
    return {'physical_Q_quadratic':d(Z*P).coeff(P),'gf_longitudinal':2*dd.coeff(r,2),
      'gf_scalar_mass':2*dd.coeff(s0,2),'mixed_after_kinetic':dd.coeff(r).coeff(s0),
      'ghost_kinetic':gg.coeff(k),'ghost_vector_relative':gg.coeff(V),'ghost_mass_relative':gg.coeff(M),'ghost_scalar_relative':gg.coeff(U),
      'source_inhomogeneous':ss.coeff(A),'source_homogeneous':ss.coeff(B),
      'cotangent_source_relative':d(1/Qfac),'auxiliary_contact_per_color':d(s.log(x1)/2),
      'pure_Q_contact_per_vector_coordinate':d(s.log(Z)/2),'linear_Q_measure_Jacobian_contact':-d(s.log(Z)/2)}

def main():
    start=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
    jets=bare_jets();b,O,G,qval,heat,P,masses,fci,qdv,qmv=setup('primary')
    weights=[[s.sympify(v) for v in row] for row in fci['vector_indices']]
    alpha,x=s.symbols('alpha x',positive=True)
    cv=heat['vector_F2'];cm=heat['combined_F2']
    # J_eps common Gamma factor is factored out only after taking the
    # independent kinetic and mass derivatives.
    kinetic=clean(s.diff(-12*cv*alpha**eps,alpha).subs(alpha,1)*qval/eps**2)
    mass=clean(x*s.diff(-12*cv*x**(-eps),x)*x**eps*qval/eps**2)
    wv=clean(-12*heat['width_vector_integrated_F2']*qval/eps)
    wc=clean(-12*heat['width_ghost_integrated_F2']*qval/eps)
    total=clean(kinetic+mass+wv+wc)
    pref={'kinetic':kinetic,'mass':mass,'width_vector':wv,'width_ghost':wc,'total':total,
      'omitted_ghost':clean(kinetic+mass+wv),'reversed_ghost':clean(kinetic+mass+wv-wc),
      'premature_D4_width_heat':clean(kinetic+mass+wc),'duplicated_mass_only':clean(total+mass),
      'false_universal_FCI_mass_shift':clean(12*cm*qval/eps),'double_complete_direction':2*total}
    assert total==0 and all(pref[k]!=0 for k in ['mass','omitted_ghost','reversed_ghost','premature_D4_width_heat','duplicated_mass_only','false_universal_FCI_mass_shift'])
    emit('primary',assemble('primary',jets,weights,pref,'primary'),start,
      {'source_and_FP_derived_before_source_zero':True,'kinetic_and_mass_responses_differentiated_separately':True,
       'WHP1_qualified_proof_reused_not_rerun':True});timer.cancel()
if __name__=='__main__':main()
