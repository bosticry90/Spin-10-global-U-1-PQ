# VFN1 bare pullback and regulated insertion, frozen before computation

Use a bookkeeping t independent of dimensional eps. Set
Z_Q=1+tq, Q_B=sqrt(Z_Q)Q, J_Q,B=J_Q/sqrt(Z_Q),
xi1_B=1+tz1,xi2_B=1+tz2. g,v,eta and other field/parameter jets are fixed
ONLY in this partial component; their independent contributions are not set
to zero in the full theory. Dbar remains fixed by the background convention.
Here z2 is an independent commuting diagnostic ray; no claim is made that
one number exhausts a general H-covariant matrix width or mixing module.

Bare gauge fixing is F_B=Dbar.Q_B+g sqrt(xi1_B xi2_B)O^T eta,
Sgf=F_B²/(2xi1_B). After the prescribed auxiliary contour Gaussian, retain
the background-independent normalization det(xi1_B)^(-1/2). Write
r=Dbar.Q,s=g O^T eta. Including the kinetic mixing, the relevant density is

    (sqrt(Z_Q)r+sqrt(xi1_B xi2_B)s)²/(2xi1_B)-sqrt(Z_Q)rs.

Its first variations are (q-z1)r²/2+z2 s²/2+(z2-z1)rs/2.
The covariant physical vector quadratic term supplies q(K_YM+M²delta).
Thus the full vector variation is q K_v+z1 Dbar_mDbar_n, the scalar GF mass
is z2 g²OO^T, and the residual mixed action is
g(z2-z1)eta^T O Dbar.Q/2. QDV1 measured zero flat longitudinal pole, so
in the conventional bare coordinates z1=q. z2 remains independent.

Do not keep the old BRST coefficients after changing Q coordinates:
sQ=Z_Q^(-1/2)Dbar c+g[Q,c]. Equivalently,
J_Q,B sQ_B=J_Q[Z_Q^(-1/2)Dbar c+g[Q,c]]. The source inhomogeneous
variation is -q/2, while its homogeneous commutator variation is zero.
The cotangent product sqrt(Z_Q)*Z_Q^(-1/2)=1 preserves the classical BV pair.
This is linear classical transport, not a nonlinear quantum-equivalence theorem.

Now differentiate F_B using the actual bare sQ_B and s eta. The fixed-order
ghost density is

    barc[-Dbar²-g sqrt(Z_Q)Dbar ad_Q
         +g²sqrt(xi1_B xi2_B)(G+T.eta)]c.

The ghost kinetic coefficient has no q term. The vector-ghost vertex has
relative q/2, and the mass/scalar-ghost coefficient is (z1+z2)/2. The known
q component therefore gives deltaKc=q M²/2, independently of any desired
F² cancellation. Other ghost wavefunction jets multiply their whole kernel
and remain separate identity contacts in this projection.

At z1=q, isolating the q component with z2 still a separate coordinate gives

    deltaKv=q(Kv+Dbar_mDbar_n), deltaKc=q M²/2,
    deltaKs=0, deltaL_vs=-q g eta^T O Dbar.Q/2.

This reproduces QMV1's qG mass block and QDV1's qK_YM derivative block.
The off-diagonal VS insertion has zero single trace against the block-diagonal
reference but is not an absent operator. In the Gaussian effective action,

    deltaGamma_q=q Tr_v(1)/2+q T_xi1,

apart from retained auxiliary and other field-measure identity contacts.
WHP1 already proves T_xi1=-Tr_c(1)/2+Tr[J Gv E Gc]/2, E=Dbar.F,
and zero positive-heavy local F² coefficient at every Laurent order. The
general off-shell E remainder and massless sector are not put to zero.

Use the original C1 dimensional interpretation: background derivatives of
the identity contacts vanish. Do NOT assert universal vanishing of a regulated
Tr1. A linear Q integration Jacobian would cancel its own field contact;
either convention has the same F² derivative here. The auxiliary Gaussian
adds Tr ln(xi1_B)/2, another explicitly background-independent contact.

For an independent positive-mass proper-time check, the real-vector F² heat
coefficient is cV(D)=(D/12-2)/2=-5/6-eps/12. In lambda=-12Gamma normalization,
lambda_V=(10+eps)tau exp(gammaE eps)Gamma(eps)(Q²/x)^eps.
Scaling only its kinetic operator by alpha multiplies this coefficient by
alpha^eps; scaling x differentiates x^-eps. Their pole-normalization responses
for q/eps are therefore opposite, before any expansion.

Set H_eps=exp(gammaE eps)Gamma(1+eps)(Q²/x)^eps. In lambda2/g² units,

    vector kinetic/spin: +(10+eps)q tau H_eps/eps,
    vector mass:         -(10+eps)q tau H_eps/eps,
    longitudinal width:  +q tau H_eps/(2eps),
    ordered ghost width: -q tau H_eps/(2eps).

The last two use the qualified WHP1 coefficients -1/24,+1/24, not a fitted
ghost partner. Sum zero for every positive mass and every eps order. Common
Re(eps)>0,m²>0 controls the proper-time F² boundary before continuation.
Native replay uses this ordered/boundary derivation instead of kinetic scaling.

Keep j_r=log(Q²/60)-log(g²)-log(lambda_r/60), with actual lambda_r>0 and
tau_i,r. H_eps=1+eps j+eps²(j²+zeta2)/2+... . Record poles, finite and O(eps)
terms, while the exact common-factor cancellation establishes all orders.
Dropping the evanescent width-vector heat coefficient before integration
leaves the nonzero ghost term. A falsely universal FCI mass shift would instead
give -(21/2+eps)q tau H_eps/eps. Neither is an actual additional C1 coefficient.

A complete zero direction duplicated is still F² zero; compare the measured
operator/source coefficients to catch it. A duplicated mass part alone leaves
a nonzero trace. The separate z2 operator, mixed term and identity contacts
cannot be normalized or tested fully from this one F² projection.

Literature comparator: Martens, arXiv:1011.2927v2 sections2.1--2.2 explicitly
retains separate gauge widths, ghost mass factors and mixed counterterms.
https://arxiv.org/html/1011.2927v2. Its one-VEV/on-shell-mass matching result
is not imported. Actual coefficients and the C1 contact prescription come
from BFT1/QDV1/QMV1/WHP1. No new physical scheme or finite condition is adopted.
