# Next: actual VVSS primitive with complete field/region accounting

VFN1 qualified the correlated measured q=-2/3 direction: zero positive-heavy
local F² insertion after kinetic/mass/first-width/ghost partners. Do not add
qG by itself to FCI1. Keep free second width, general matrix slots, off-shell
E remainder, identity contacts and massless/common-EFT obligations separate.
QMV1/QDV1 full vector-vector UV block is available; do not rerun it or WHP1.

Return to an actually missing primitive rather than another generic theorem.
VVSS is the compact candidate because its literal scalar kinetic quartic is

    -g² Q_mu^a Q_mu^b eta^T rho_a rho_b eta/2.

Derive its real-field Wick coefficient from BFT1 before evaluation; do not
guess it from a cancellation. Its distinct vector/scalar loops avoid a328^4
tensor expansion. The two coincident propagators admit the existing heat/
mass-function treatment. Preserve all8 raw labelled background placements;
prove which combine or vanish in the actual F² projection.

Candidate structural reduction, NOT YET CALCULATED OR QUALIFIED:
construct the scalar quadratic color map L(M)=-sum_ab M_ab rho_a rho_b for
each vector mass projector P_r. For the external gauge factor also use
M=P_r times the normalized average of ad_h² over that H ideal. The average
is needed for background-invariant scalar multiplicity blocks; a single
Cartan squared need not act as a scalar on a degenerate mass set. The U(1)
case has one generator, SU2 and SU3 average over3 and8 respectively.

These5+15 operators should be H-invariant and project into the qualified
35 scalar multiplicity blocks. Check the actual covariance and coordinate
map; do not replace their entries by coarse beta weights. Keep noncommuting
operator order inside scalar traces. Use the existing exact H, gauge-orbit
projectors and physical positivity, with symbolic g² and scale logs. Compute
only required matrix functions using distinct competent methods; do not repeat
qualified scalar/tadpole loops or choose finite mass/VEV/tadpole conditions.

For positive vector and scalar regulator masses, a local Cartan-curvature probe
can isolate F². The scalar coincident kernel has no Lorentz-linear F term,
and the vector trace eliminates its antisymmetric linear term. Derive the
remaining two heat structures independently, keeping D=4-2eps factors and
all positive-eps master terms needed by two-loop poles. This is a prospective
reduction, not a licensed premature constant-A or zero-momentum limit.

Inventory full vector12light/33heavy and scalar5soft/323positive assignments
before discarding anything. Use a common positive IR regulator and retain
their coefficients before the limit. Prove the literal restricted-tree EFT
VVSS vertex and the actual opened hard vector/scalar companion kernels.
The qualified OSF1 identity can then be reused in its exact scope, not assumed
to cancel every light term. Unknown finite Higgs mass is not a reason to
repeat a calculation it already cancels from the specified common block.

The desired outcome is a complete model-specific primitive coefficient class
with its exact Laurent/finite content and proved UV/IR/EFT disposition. A
positive-heavy trace alone is not the full class. If an input or subtraction
is missing, isolate it precisely rather than invent a zero or fit a local C2.
Do not substitute a full summed parent CT on the quartic graph alone, add
FCI/HTB twice, or confuse spacetime locality with mass-independent matching.
Keep graph-local forests and full parent-normalization reconciliation distinct.

Use existing inputs to freeze the acceptance contract and resource scope
before computation. If the actual operator support makes a different complete
hard family the competent cheaper next test, justify that choice explicitly.
No new framework, broad review or director approval is required for ordinary
authorized research. Authority113/34of39 and all blocked/paused boundaries
remain; finite C1_GS and the overall investigation are still incomplete.
