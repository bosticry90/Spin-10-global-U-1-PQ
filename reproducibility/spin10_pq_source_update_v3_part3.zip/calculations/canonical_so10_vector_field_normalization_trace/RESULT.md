# VFN1: correlated field normalization adds zero positive-heavy F² insertion

The measured quantum-vector normalization must NOT be added as a standalone
extra mass correction to FCI1. Its actual bare-field/source/first-width
pullback has a zero positive-heavy local F² trace once the correlated kinetic,
mass, longitudinal-vector and ordered-ghost pieces are retained.

Two routes and separate verification agree. Scientific acceptanceNOT_PERFORMED;
authority113/34of39 unchanged. Base141cde4056afa1e4695120b2d32565822441d387/main.
This is a bounded result in the original dimensional C1 prescription, not a
zero general functional, massless limit, full EFT matching or complete C1.

## The ghost partner follows from the bare action

Use Q_B=sqrt(Z_Q)Q, J_Q,B=J_Q/sqrt(Z_Q), Z_Q=1+tq, and separate bare
widths xi1_B=1+tz1,xi2_B=1+tz2. The scalar z2 is an independent commuting
diagnostic coordinate, not a claim to exhaust a general matrix width module.
Other field/parameter jets remain separate components of the full problem.

Differentiating the original kinetic/GF density gives

    deltaL_GF+mix=(q-z1)(Dbar.Q)²/2
       +z2 g² eta^T OO^T eta/2
       +g(z2-z1)eta^T O Dbar.Q/2.

The measured flat longitudinal condition from QDV1 requires z1=q in these
bare coordinates. It leaves z2 independent. The source cotangent/BRST chain
gives sQ=Z_Q^(-1/2)Dbar c+g[Q,c], so the source's inhomogeneous coefficient
changes by -q/2 and its homogeneous commutator coefficient stays unchanged.
This is classical linear transport, not a new quantum source-restoration theorem.

Varying the bare F_B with that chain rule gives

    K_FP=-Dbar²-g sqrt(Z_Q)Dbar ad_Q
         +g²sqrt(xi1_B xi2_B)(G+T.eta).

The ghost kinetic term has no q variation. Its vector vertex has relative
q/2 and its mass/scalar vertex has relative(z1+z2)/2. The coefficient1/2 was
derived before the trace, not inferred from a desired cancellation.

For the known q=-2/3 component, with z2 still a separate free coordinate,

    deltaKv=q(Kv+Dbar_mDbar_n), deltaKc=q M²/2,
    deltaKs=0, deltaL_vs=-qg eta^T O Dbar.Q/2.

These operators reproduce QMV1's qG mass term and QDV1's qK_YM derivative
term. The off-diagonal VS term is nonzero and retained. Its single trace
against the block-diagonal reference vanishes; this does not remove it from
the action or other Green functions. Full45x45 matrices and the fixed source/
FP tensors are checked, including720/91125 vector and affine-source positions
and10524/664200 scalar-ghost positions, with all zero complements.
These vertex maps establish transport. At this two-loop background order,
only the quadratic CT trace is inserted; no extra cubic/quartic CT is added
to a two-loop primitive skeleton.

## The four nonzero trace pieces cancel

In lambda=-12Gamma normalization, the known field-pole insertion contributes,
per positive mass x and real index tau, in lambda2/g10² units:

| Piece | Coefficient multiplying tau H_eps/eps |
| --- | ---: |
| Vector kinetic/spin | (10+eps)q |
| Vector mass | -(10+eps)q |
| Longitudinal first width | q/2 |
| Ordered ghost first width | -q/2 |
| Sum | 0 |

H_eps=exp(gammaE eps)Gamma(1+eps)(Q²/x)^eps. Primary derives the first
two by independently scaling the kinetic operator and differentiating its
mass. Replay derives them from the ordered insertion and positive proper-time
boundary. The width pair reuses the already qualified WHP1 theorem; its
analytic assumptions were not independently re-proved or silently broadened.

The exact common factor establishes cancellation at every Laurent order.
The tables also explicitly give pole, finite and O(eps) coefficients for
the actual four positive mass sets and all three gauge factors. Actual heavy
index sums are(8,6,5); the neutral positive mass set is retained but cannot
validate signs by itself. Scale/coupling logs remain symbolic:
j_r=log(Q²/60)-log(g10²)-log(lambda_r/60).

Consequently this correlated q direction adds ZERO to the known positive-heavy
counterterm F² subtotal. It does not alter FCI1's authenticated parameter
mass jet, set a finite field/VEV/tadpole condition, or complete the threshold.

## Wrong assembly gives demonstrably nonzero answers

An isolated vector mass insertion would leave poles
(160/3,40,100/3). Incorrectly treating qG as a universal FCI multiplet mass
shift would leave(56,42,35). Both are counterfactual controls in lambda2/g²
units, not measured new physical threshold corrections.

Omitting the derived ghost partner leaves(-8/3,-2,-5/3). Removing the
evanescent width-vector heat response at D=4 leaves(8/3,2,5/3). A reversed
ghost sign or duplicated mass part also leaves a nonzero result. Finite and
positive-eps terms were checked as well as these poles.

Duplicating the WHOLE zero direction remains F² zero: that test is INSENSITIVE.
The separately measured QMV1 mass constraint detects it through105 changed
operator entries. A source-only cotangent error, an omitted off-diagonal VS
term, or deletion of an identity contact is also invisible in this source-zero
F² trace. Their actual source/operator maps are checked separately; no claim
is made that this one projection validates the entire action or measure.

Forgetting the BRST chain factor gives a spurious ghost kinetic rescaling;
canonicalizing that incorrect density removes the required q ghost mass
partner. The direct bare FP/source calculation catches this before any
consistency sum. No ghost normalization was chosen to force the trace to zero.

## Contacts and scope remain explicit

The ordered identity is deltaGamma_q=q Tr_v(1)/2+q T_xi1, with the auxiliary
Gaussian contact and other linear field contacts retained separately.
WHP1 preserves T_xi1=-Tr_c(1)/2+Tr[J Gv(Dbar.F)Gc]/2. The generally nonzero
off-shell remainder has not been discarded.

The original C1 dimensional prescription gives zero BACKGROUND DERIVATIVES
of the identity contacts. No universal Tr1=0 or E5 finite-part prescription
is used. The auxiliary contour Gaussian produces det(xi1_B)^(-1/2); its
effective-action contact is Tr ln(xi1_B)/2. A constant linear Q integration
Jacobian would cancel its corresponding field contact. Both are independent
of the background for this projection; no full quantum-equivalence theorem
is inferred. Finite Gaussian and auxiliary completion identities were checked.

The positive-heavy F² boundary is controlled for Re(eps)>0,x>0 before
continuation. This does not justify taking x=0 or suppressing the massless
EFT sector. The free second width and general scalar/ghost/source normalization
remain unresolved outside the measured component. Earlier nonlinear Jacobian,
contact and physical-domain obligations are not replaced by this linear result.

## Evidence and execution

VFN1 froze2333 input/source/proof bindings before calculation. Sources and
all completed outputs are immutable. Commands completed once under their
exclusive output names:

    python -B calculations/canonical_so10_vector_field_normalization_trace/prepare.py
    python -B calculations/canonical_so10_vector_field_normalization_trace/run.py native
    python -B calculations/canonical_so10_vector_field_normalization_trace/run.py validate

Primary18.7146583s,replay6.2504698s,verifier15.1651231s after imports.
Caps120/120/180s,8GiB sampled private,350MiB launch floor,4MiB package.
Private samples10/4/8, observed maxima73715712/61370368/55046144B, not
continuous peak bounds. No failed scientific worker/verifier or timeout.
One prefreeze text-patch request had a bad context anchor and was corrected;
its exact rejected request/error is retained in PREPARATION_EDIT_EVENT.md.

Both native tables386619raw/52311gzip bytes.
RawSHA7881dee154d5a73edf163c2c4487d4d7b085f38594b0320a8aa9d0faedbb6796.
GzipSHA47c6ebf66d09fa2872fa6d14582512679f6bff8cbf3dd2de82bc863c77e5a45c.
Final validation_receipt.json SHA
57e5ea1ddbcaebb066d93f7c71fa05c334df126ec8fa3e49a778f1e86793f9c3.
Status QUALIFIED_CORRELATED_Q_FIELD_FIRST_WIDTH_POSITIVE_HEAVY_F2_ZERO.
The separate verifier checks tensor maps, exact coefficients and80-digit
proper-time/Laurent controls, maximum scaled error1.97887363081e-81,
tolerance1e-45. It imports no new scientific helper.

WHP1 receipt4b648968948cd39fae6a7e220d914ddedc0df0dfdf778db5f8de0580e75553f7
and QMV1/QDV1 input bytes are authenticated, not freshly replayed old workers.
Shared action, WHP1 theorem, indices, software and AI authorship remain;
there is no outside, Lean or empirical validation. Martens1011.2927v2
sections2.1--2.2 supplies a separate-width/ghost-factor comparator, not this
model's scheme or result. Its finite matching formula is not imported.

Delegated e4 checks completed6 expected exits, with no fresh old scientific
replay. Custody remains exit2/seven unresolved, not PASS. Full captures and
control records are external under
C:/Users/psboy/.codex/research-control-records/ToE-Next/
vector-field-normalization-trace-v1-2026-10-20. Preserve all25561 old Git blobs
and verify new raw/index/HEAD bytes before/after local commit. StateSHA
d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8 unchanged.

## Next action

The measured field-normalization direction is now accounted for without a
false extra positive-heavy mass insertion. Return to a genuinely missing
primitive hard family, using the actual VVSS quartic and scalar multiplicity
blocks as the compact candidate. Retain every hard/light assignment and
derive its graph-local/common-EFT subtraction before any finite claim.

Full C1_GS,E5/A5,physical quantum control and gauge unification remain open.
Authority34/39,HB1/C5blocked,flavorpaused,C1null,quartetFAIL3960/648,
custodyexit2/seven,scalar140%/1.94%/20.27%,matching.745476 and missing Yukawas
remain distinct. No point, action, finite scheme, foundation, remote state,
publication or prior bounded causal result was changed.
