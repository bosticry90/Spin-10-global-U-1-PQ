# VFN1 bounded contract, prospective before calculation

Base141cde4056afa1e4695120b2d32565822441d387/main. State113/34of39,
SHA d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8.
Question: does the measured quantum-vector normalization produce an additional
positive-heavy local F² threshold insertion when its ACTUAL bare-field,
source, first-width and ghost partners are retained? Prevent isolated mass
double counting in FCI1; do not infer a missing partner from a desired zero.

Scope: BFT1 physical source-zero C1 Gaussian, xi1=xi2=1 at the reference,
H-valued background, constant reference O,v. First-order bare Q normalization
z_Q=-2/3 from QDV1/QMV1. Keep second width z2 independent, not globally zero
or equal to z1. All other field/parameter jets remain separate components.
Scalar z2 is a commuting diagnostic coordinate; it does not exhaust the
general H-covariant width/mixing module. The measured q direction is uniform.
Work in the ORIGINAL dimensional C1 prescription, not an E5 finite-part trace.
Claim only the positive-heavy local background F² projection, not a general
functional, massless limit, full EFT matching, full CT action, or finite C1.

Before computation freeze this contract, proof, source and controllers; hash
all direct/nested inputs. Reuse WHP1's qualified positive-heavy first-width
identity and heat normalization, rather than rerun its completed workers.
Use QDV1 z_Q, QMV1 exact mass match, FCI1 actual indices/masses, BFT1 O/G/T/f,
QIR1 normalized H embedding, WHP1 mass projectors. Preserve all25561 old blobs.

Primary: differentiate exact bare GF/kinetic/FP/source expressions before
setting sources zero. Include Q source cotangent factor and BRST chain rule.
Derive physical-field and width decomposition with symbolic z1,z2, then
use the measured flat longitudinal condition z1=z_Q. Evaluate actual weighted
positive-heavy F² responses from independent kinetic scaling and mass
derivatives of the dimensional vector heat expression plus qualified WHP1.

Replay: first-order jet algebra, direct ordered-insertion identities and the
positive proper-time boundary. Determine actual weights from normalized
adjoint contractions, not the primary's FCI table. Use Laurent convolution
to retain poles, finite and O(eps) terms with symbolic scale/coupling logs.
Do not choose finite parameters or solve ghost coefficients from cancellation.

Separate verifier imports no new scientific helper. Check complete field,
mixed and source tensor maps, all weighted coefficients, proper-time/Gamma
normalization, and every explicit control. Numerical80digits, scaled1e-45
tolerance. Reusing WHP1 analytic assumptions is not an independent reproof.

Controls: isolated vector mass insertion; falsely treating z_Q as a universal
FCI multiplet mass shift; omitted/reversed ghost partner; premature D4 heat
projection; duplicate mass part with other partners once; forgotten source
cotangent/BRST chain factor; duplicated complete direction checked at operator
level. Whole complete direction duplicated is F²-INSENSITIVE; off-diagonal VS
omission and background-independent contact deletion are also trace-insensitive.
Keep these limitations explicit. Second-width equality is not inferred from
the F² result. Neutral massive color alone cannot validate signs.

The auxiliary Gaussian contact and constant linear field Jacobian are retained
as background-independent contacts, with the exact declared C1 interpretation.
No universal Tr1=0, nonlinear quantum-equivalence theorem or changed measure
is assumed. Off-shell E=Db.F remainder and light/common-EFT subtraction remain.

Bounds: native120s each, verifier180s after imports,8GiB sampled private,
350MiB launch commit floor,4MiB package. Daemon hard timers, full captures
before assertions, exclusive outputs. Preserve/version failures; no completed
rerun. Sequential independent routes, compare, then separate verification.
Exhaustion is incomplete; scientific acceptance NOT_PERFORMED.

TrackB: evaluate dependency reduction and trace-insensitive controls under
shared action, WHP1 theorem, indices, software and AI authorship. No external,
Lean or empirical validation. Director education nonblocking. No old evidence,
physical point/action/finite scheme, foundation, authority, main, remote or
publication changes. E5/A5unqualified,HB1/C5blocked,flavorpaused,C1null,
quartetFAIL3960/648,custodyexit2/seven and physical limitations remain.
