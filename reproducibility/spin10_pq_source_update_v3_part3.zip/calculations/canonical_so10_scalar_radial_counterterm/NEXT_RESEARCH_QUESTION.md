# Next: assemble the complete local radial gauge/scalar UV kernel

SRC1 supplies scalar-loop curvature C0; GQH1 supplies gauge-quartic C4.
SWF1 supplies the scalar p^2 pole. Derive the remaining xi*g10^2 radial
potential curvature directly from OFV1's independent-field/reference formula,
keeping the reference fixed until after both derivatives.

With Ephi=phi^T C2 V', Ew=w^T C2 V', the combined potential CT at g^2 is
xi*(Ew-Ephi/2). At the stationary point its Hessian is
xi*[sum_k Ck vk V'''_kij-(Ci+Cj)V''_ij]/2. Do not obtain V''' by
differentiating the already stationary-mass-substituted VMT Hessian; that
would retune the parent masses. Differentiate the full actual radial
potential first or use its fixed coefficient cubic/quartic monomials.

Then authenticate and assemble the already measured C0,C4, tadpole and
kinetic inputs exactly once. This is assembly/reuse, not new independent
loop evidence. Prove the radial vectors are orthogonal to every gauge orbit
so gauge-fixing mass/width CTs do not contaminate this projection. Check the
actual second derivative with co-moving reference as a sensitive error;
the first stationary derivative is insensitive, as OFV1 recorded.

This yields a well-defined local three-radial UV kernel under the same
scalar/gauge/ghost one-loop scope. It does not complete the nonradial328-field
counterterm module, finite on-shell conditions, parent-basis closure or
physical quantum control. Next assess the actual embedding/35-block map
for complete counterterm projection before expanding a large tensor grid.
No finite normalization fit or paused-flavor activation is justified.
