"""Sequential owned capture; compare only completed independently derived outputs."""
from pathlib import Path
from hashlib import sha256
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CONTROL = Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-radial-counterterm-v1-2026-10-20')
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
from audit_a10_e5_antighost_vector import resource,line_json

prep = json.loads((HERE/'preparation.json').read_bytes())
for name,digest in prep['input_sha256'].items():
    assert sha256(Path(name).read_bytes()).hexdigest() == digest, name
query = "@(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.ProcessId -ne "+str(os.getpid())+" -and $_.CommandLine -like '*canonical_so10_scalar_radial_counterterm*' } | Select-Object ProcessId,CommandLine) | ConvertTo-Json -Compress"
assert not subprocess.check_output(['pwsh','-NoProfile','-Command',query]).strip(), 'LIVE_WORK_PRESERVE_HANDLE'
results = []
for role in ['primary','replay']:
    cap = capture([sys.executable,'-B',str(HERE/'pilot.py'),role])
    raw = (json.dumps(cap,sort_keys=True,separators=(',',':'))+'\n').encode()
    for destination in [HERE/(role+'_capture.json'),CONTROL/(role+'_full_capture.json')]:
        with destination.open('xb') as out:
            out.write(raw)
    if cap['execution_state'] != 'COMPLETED':
        print(cap['stdout_and_stderr'],flush=True)
    resource(cap)
    value = line_json(cap['stdout_and_stderr'],'RESULT ')
    assert value['elapsed_after_imports'] < prep['native_after_imports_seconds']
    with (HERE/(role+'_result.json')).open('xb') as out:
        out.write((json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode())
    results.append(value)
    print(role,'COMPLETED',value['elapsed_after_imports'],flush=True)
for key in ['gradient_exact','curvature_exact','potential_exact','gradient_numeric','curvature_numeric']:
    assert results[0][key] == results[1][key], key
print('COMPLETED_NATIVE_AGREEMENT',flush=True)
