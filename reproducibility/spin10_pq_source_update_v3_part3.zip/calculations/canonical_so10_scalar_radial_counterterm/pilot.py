"""SRC1 exact matrix differentiation vs exact trace-polynomial interpolation."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import json
import os
import sys
import threading
import time
import sympy as s
import mpmath as mp

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'calculations/canonical_so10_uv_radial_tadpoles'))
from inputs import coeffs,reduce_root,root,number,fmt
@lru_cache(None)
def clean(value):return s.cancel(s.expand(value))
@lru_cache(None)
def parse(value):return s.sympify(value)

def main():
    start=time.perf_counter();timer=threading.Timer(90,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    prep=json.loads((HERE/'preparation.json').read_bytes())
    for name,digest in prep['input_sha256'].items():assert sha256(Path(name).read_bytes()).hexdigest()==digest,name
    role=sys.argv[1];assert role in ['primary','replay']
    slots,cc,degrees,values,q,quad=coeffs()
    packet=json.loads((ROOT/'calculations/canonical_so10_singlet_tadpole/original_v2_result.json').read_bytes())
    work=[];census=0
    for row in packet['block_inputs']:
        size=len(row['sectors']);terms=defaultdict(lambda:s.S.Zero)
        legs=[[int(sector=='Phi'),int(sector in ['Sigma','SigmaBar']),int(sector in ['S','SBar'])] for sector in row['sectors']]
        for k,i,j,value in row['raw_H34_sparse']:
            degree=degrees[slots[k].partition(':')[0]]
            powers=tuple(degree[r]-legs[i][r]-legs[j][r] for r in range(3))
            assert min(powers)>=0 and sum(powers)<=2,(row['sectors'],slots[k],i,j,powers)
            terms[i,j,powers]+=values[k]*parse(value)
        terms={key:clean(value) for key,value in terms.items() if clean(value)}
        metric=list(map(s.Rational,row['metric']));assert all(value>0 for value in metric)
        work.append((size,int(row['dimension']),metric,terms))
        census+=size*int(row['dimension'])
    assert len(work)==35 and census==328
    def cross(A,B,metric):
        return sum((A[i,j]*B[j,i]/(metric[i]*metric[j]) for i in range(A.rows) for j in range(A.rows) if A[i,j]!=0 and B[j,i]!=0),s.S.Zero)
    gradient=s.zeros(3,1);curvature=s.zeros(3);base_value=s.S.Zero
    if role=='primary':
        for size,dim,metric,terms in work:
            B=s.zeros(size);first=[s.zeros(size) for _ in range(3)];second=[[s.zeros(size) for _ in range(3)] for _ in range(3)]
            for (i,j,powers),value in terms.items():
                B[i,j]+=value
                for r in range(3):
                    first[r][i,j]+=powers[r]*value
                    for t in range(3):second[r][t][i,j]+=powers[r]*(powers[t]-int(r==t))*value
            B=B.applyfunc(clean);first=[A.applyfunc(clean) for A in first]
            assert not (B-B.H).applyfunc(clean).todok()
            base_value+=dim*cross(B,B,metric)/4
            for r in range(3):
                gradient[r]+=dim*cross(B,first[r],metric)/(2*q[r])
                for t in range(3):curvature[r,t]+=dim*(cross(first[r],first[t],metric)+cross(B,second[r][t].applyfunc(clean),metric))/(2*q[r]*q[t])
    else:
        @lru_cache(None)
        def scalar_trace(direction,t):
            total=s.S.Zero
            for size,dim,metric,terms in work:
                B=s.zeros(size)
                for (i,j,powers),value in terms.items():
                    factor=s.prod((1+t*direction[r])**powers[r] for r in range(3))
                    B[i,j]+=factor*value
                total+=dim*cross(B.applyfunc(clean),B.applyfunc(clean),metric)/4
            return clean(total)
        base_value=scalar_trace((0,0,0),0)
        def stencil(direction):
            m2,m1,p1,p2=[scalar_trace(direction,t) for t in [-2,-1,1,2]]
            return clean((8*(p1-m1)-(p2-m2))/12),clean((16*(p1+m1-2*base_value)-(p2+m2-2*base_value))/12)
        for r in range(3):
            direction=tuple(int(i==r) for i in range(3));first,second=stencil(direction)
            gradient[r]=first/q[r];curvature[r,r]=second/q[r]**2
        for r in range(3):
            for t in range(r):
                direction=tuple(int(i in [r,t]) for i in range(3));_,second=stencil(direction)
                curvature[r,t]=curvature[t,r]=clean((second-q[r]**2*curvature[r,r]-q[t]**2*curvature[t,t])/(2*q[r]*q[t]))
    gradient=gradient.applyfunc(lambda value:reduce_root(value,quad));curvature=curvature.applyfunc(lambda value:reduce_root(value,quad))
    base_value=reduce_root(base_value,quad)
    assert curvature==curvature.T
    mp.mp.dps=100;branch=root(quad)
    result={
        'schema':'C1_GS_SCALAR_RADIAL_COUNTERTERM_NATIVE_V1','route':role,
        'gradient_exact':list(map(str,gradient)),
        'curvature_exact':[[str(value) for value in row] for row in curvature.tolist()],
        'potential_exact':str(base_value),
        'gradient_numeric':[fmt(number(value,branch)) for value in gradient],
        'curvature_numeric':[[fmt(number(value,branch)) for value in row] for row in curvature.tolist()],
        'blocks':len(work),'real_internal_directions':census,'radial_external_directions':3,
        'loop_factor':'hbar/(16*pi**2*epsilon_UV)',
        'parameters_fixed_in_field_derivative':True,'UTP1_target_read':False,
        'full328_mass_CT_or_finite_part':False,'elapsed_after_imports':time.perf_counter()-start,
    }
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
