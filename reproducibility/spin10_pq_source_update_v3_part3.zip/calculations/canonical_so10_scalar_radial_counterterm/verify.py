"""SRC1 independent cached-block evaluation with high-precision polynomial stencils."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json
import os
import sys
import threading
import time
import numpy as np
import mpmath as mp
import sympy as s

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'calculations/canonical_so10_higgs_stationary_tangent'))
from model import Model,SLOTS

def main():
    start=time.perf_counter();timer=threading.Timer(90,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    prep=json.loads((HERE/'validation_preparation.json').read_bytes())
    for name,digest in prep['input_sha256'].items():assert sha256(Path(name).read_bytes()).hexdigest()==digest,name
    primary=json.loads((HERE/'primary_result.json').read_bytes());replay=json.loads((HERE/'replay_result.json').read_bytes())
    for key in ['gradient_exact','curvature_exact','potential_exact','gradient_numeric','curvature_numeric']:
        assert primary[key]==replay[key],key
    w=s.Symbol('w',real=True)
    utp=json.loads((ROOT/'calculations/canonical_so10_uv_radial_tadpoles/primary_result.json').read_bytes())
    radii=[s.sqrt(60),s.sqrt(s.Rational(3,5)),s.sqrt(s.Rational(3,5))]
    for value,old,radius in zip(primary['gradient_exact'],utp['scalar_exact_reduced_w'],radii):
        assert s.cancel(s.expand(s.sympify(value,locals={'w':w})-s.sympify(old,locals={'w':w})/(4*radius)))==0
    # A massless mode can have a nonzero second derivative of its squared mass.
    q,v,lam=s.symbols('q v lam',positive=True)
    zero_mode=s.diff((lam*(q*q-v*v))**2/4,q,2).subs(q,v)
    assert s.simplify(zero_mode-2*lam*lam*v*v)==0 and zero_mode!=0
    M=Model();mp.mp.dps=80
    point=json.loads((ROOT/'calculations/canonical_so10_positive_higgs/POINT.json').read_bytes())
    base=json.loads((ROOT/'calculations/canonical_so10_scalar_benchmark/STAGE1_POINT.json').read_bytes())['free_coefficients']
    base.update(point['changed_free_coefficients'])
    names=list(dict.fromkeys(slot.partition(':')[0] for slot in SLOTS));cc={}
    for name in names:
        if name in base:cc[name]=mp.mpf(base[name])
        elif name+':re' in base:cc[name]=mp.mpc(base[name+':re'],base[name+':im'])
    sq60=mp.sqrt(60);q0=[sq60,mp.sqrt(mp.mpf(3)/5),mp.sqrt(mp.mpf(3)/5)]
    for name in ['muPhi','muPhiPhi','z6']:cc[name]*=sq60
    pp=point['determinant_polynomial'];A=mp.mpf(pp['A']);B=mp.mpf(pp['B0'])+mp.mpf(pp['B1'])*mp.sqrt(15);C=mp.mpf(pp['C0'])+mp.mpf(pp['C1'])*mp.sqrt(15)
    branch=(-B+mp.sqrt(B*B-4*A*C))/(2*A)
    assert mp.mpf('.00530')<branch<mp.mpf('.00531')
    cc['mphi2']=60*(branch+mp.mpf(1)/500)
    def assign_stationary_masses(params,coords):
        a,b,c=coords;lp=params['lambdaPhi1']+mp.mpf(7)*params['lambdaPhi2']/60;lm=params['lambdaPhiSigma1']-params['lambdaPhiSigma2']/4
        params['mPhi2']=-3*params['muPhi']*a/(2*sq60)-2*lp*a*a-lm*b*b-params['lambdaPhiS']*c*c/2
        params['mSigma2']=-lm*a*a-2*params['lambdaSigma1']*b*b-params['lambdaSigmaS']*c*c/2
        params['mS2']=-params['lambdaPhiS']*a*a-params['lambdaSigmaS']*b*b-params['lambdaS']*c*c
    assign_stationary_masses(cc,q0)  # once at the point, never in the actual variation
    def slot_values(params):
        result=[]
        for slot in SLOTS:
            name,_,part=slot.partition(':');value=params[name]
            result.append(mp.im(value) if part=='im' else mp.re(value))
        return result
    fixed=slot_values(cc);degrees=[list(map(int,row)) for row in M.nslot]
    work=[];census=0
    for label,cache in M.cache.items():
        meta=M.metadata[label];size=len(meta['ids']);dimension=meta['ledger']['real_dimension_per_eigenvalue']
        entries=[]
        for k in range(len(SLOTS)):
            for i in range(size):
                for j in range(size):
                    value=cache[k,i,j]
                    if value!=0:entries.append((k,i,j,mp.mpc(str(float(np.real(value))),str(float(np.imag(value))))))
        metric=[mp.mpf(str(value)) for value in meta['unit_metric']]
        work.append((size,int(dimension),list(map(int,meta['ids'])),metric,entries))
        census+=size*int(dimension)
    assert len(work)==35 and census==328
    scales0=[q0[0]/sq60,q0[1]/(4*mp.sqrt(2)),q0[2]/mp.sqrt(2)]
    imaginary_errors=[]
    @lru_cache(None)
    def trace_value(coords,mode='fixed'):
        scales=[coords[0]/sq60,coords[1]/(4*mp.sqrt(2)),coords[2]/mp.sqrt(2)]
        values=fixed
        if mode=='stationary_family':
            changed=dict(cc);assign_stationary_masses(changed,coords);values=slot_values(changed)
        factors=[value*mp.fprod(scales[r]**degree[r] for r in range(3)) for value,degree in zip(values,degrees)]
        total=mp.mpc(0)
        for size,dimension,ids,metric,entries in work:
            raw=[[mp.mpc(0) for _ in range(size)] for _ in range(size)]
            for k,i,j,value in entries:raw[i][j]+=factors[k]*value
            normscale=scales0 if mode=='missing_kinetic_endpoints' else scales
            gmetric=[value*(normscale[idx]**2 if idx>=0 else 1) for value,idx in zip(metric,ids)]
            total+=dimension*mp.fsum(raw[i][j]*raw[j][i]/(gmetric[i]*gmetric[j]) for i in range(size) for j in range(size))/4
        imaginary_error=abs(mp.im(total))/(1+abs(total));imaginary_errors.append(imaginary_error)
        assert imaginary_error<mp.mpf('5e-8')
        return mp.re(total)
    f0=trace_value(tuple(q0))
    def stencil(direction,h,mode='fixed'):
        values={t:trace_value(tuple(q0[r]*(1+t*h*direction[r]) for r in range(3)),mode) for t in [-2,-1,1,2]}
        first=(8*(values[1]-values[-1])-(values[2]-values[-2]))/(12*h)
        second=(16*(values[1]+values[-1]-2*f0)-(values[2]+values[-2]-2*f0))/(12*h*h)
        return first,second
    def all_values(h):
        gradient=[mp.mpf(0)]*3;curvature=[[mp.mpf(0) for _ in range(3)] for _ in range(3)]
        for r in range(3):
            first,second=stencil(tuple(int(i==r) for i in range(3)),h)
            gradient[r]=first/q0[r];curvature[r][r]=second/(q0[r]*q0[r])
        for r in range(3):
            for t in range(r):
                _,second=stencil(tuple(int(i in [r,t]) for i in range(3)),h)
                curvature[r][t]=curvature[t][r]=(second-q0[r]**2*curvature[r][r]-q0[t]**2*curvature[t][t])/(2*q0[r]*q0[t])
        return gradient,[value for row in curvature for value in row]
    target_gradient=list(map(mp.mpf,primary['gradient_numeric']));target_curvature=[mp.mpf(value) for row in primary['curvature_numeric'] for value in row]
    scaled=lambda a,b:max(abs(x-y)/(1+abs(x)+abs(y)) for x,y in zip(a,b))
    values1=all_values(mp.mpf(1)/4);values2=all_values(mp.mpf(1)/8)
    errors=[scaled(values1[0],target_gradient),scaled(values1[1],target_curvature),scaled(values2[0],target_gradient),scaled(values2[1],target_curvature)]
    refinement=[scaled(a,b) for a,b in zip(values1,values2)]
    assert max(errors+refinement)<mp.mpf('5e-8')
    wrong=[]
    for r in range(3):
        first,_=stencil(tuple(int(i==r) for i in range(3)),mp.mpf(1)/4,'stationary_family');wrong.append(first/q0[r])
    assert max(abs(x-y) for x,y in zip(wrong,target_gradient))>mp.mpf('1e-3')
    missing,_=stencil((1,0,0),mp.mpf(1)/4,'missing_kinetic_endpoints')
    assert abs(missing/q0[0]-target_gradient[0])>mp.mpf('1e-3')
    receipt={
        'schema':'C1_GS_SCALAR_RADIAL_COUNTERTERM_VALIDATION_V1','execution_state':'COMPLETED',
        'disposition':'QUALIFIED_SCALAR_LOOP_THREE_RADIAL_COUNTERTERM_CURVATURE',
        'input_bindings':len(prep['input_sha256']),'real_internal_scalar_directions':census,'blocks':len(work),
        'radial_external_directions':3,'exact_native_gradient_and_curvature_agreement':True,
        'UTP1_scalar_tadpole_exact_match':True,'source_cache_precision':'complex128',
        'cache_arithmetic_digits':mp.mp.dps,'stencil_steps':['1/4','1/8'],
        'cache_scaled_errors':list(map(lambda value:mp.nstr(value,25),errors)),
        'step_refinement_scaled_errors':list(map(lambda value:mp.nstr(value,25),refinement)),
        'cache_trace_max_scaled_imaginary':mp.nstr(max(imaginary_errors),25),
        'scaled_acceptance':'5e-8','wrong_stationary_gradient':list(map(lambda value:mp.nstr(value,25),wrong)),
        'missing_endpoint_gradient_control':mp.nstr(missing/q0[0],25),
        'zero_mode_curvature_control':str(zero_mode),
        'gradient_numeric':primary['gradient_numeric'],'curvature_numeric':primary['curvature_numeric'],
        'full328_scalar_mass_CT_or_finite_part':False,'native_failures':0,'verifier_failures':0,
        'authority':'34/39_UNCHANGED','external_or_Lean_or_empirical_validation':False,
        'elapsed_after_imports':time.perf_counter()-start,
    }
    print('RESULT '+json.dumps(receipt,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
