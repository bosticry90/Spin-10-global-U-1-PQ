# SRC1 — scalar-loop radial potential counterterm

The frozen primary, replay and verifier completed atbase
9b154e8b4a062f540205d27d62f251b291c1c72f. For the required local scalar-loop
subtraction U0=Tr328[V''(q)^2]/4, the canonical Phi,Sigma,S radial gradient is
approximately (14555.3860064,54354.2844343,26.2650047). Its curvature is

    [[4964.2204065,8164.4424315,5.8198889],
     [8164.4424315,139704.6792635,0.2483117],
     [5.8198889,0.2483117,45.9079812]].

The counterterm multiplies hbar/(16*pi^2*epsilon_UV); the gradient has
dimension3 and curvature dimension2. These are ultraviolet pole coefficients,
not finite mass corrections, percentages, eigenvalues or a vacuum shift.
Exact affine expressions in POINT's algebraic root and100-digit evaluations
are retained in the native results. The point vacuum constant is retained
without adopting a vacuum-energy condition.

All35 SM blocks/all328 internal directions contribute to the trace, including
tree-zero modes. Only three external radial directions were differentiated;
this is not the full328x328 scalar-loop counterterm Hessian. Every parent
parameter, including the Higgs mass, stays fixed during the field derivative.

The primary differentiates the exact raw34 block Hessians with both physical
kinetic endpoints. The replay evaluates the fixed-frame degree4 polynomial
at0,+/-1,+/-2 along all three coordinate and three paired directions. Their
exact gradients, curvatures and point potential agree. Nonnegative residual
field powers and degree<=2 of each Hessian entry were checked before using
the degree4 trace interpolation. No matrix logarithm, mass cutoff or old
finite loop was recalculated.

The separate verifier uses the HST complex128 cache and independently built
point coefficients, with80-digit working arithmetic and h=1/4,1/8 stencils.
All3 gradients and9 curvature entries pass the frozen5e-8 scaled comparison
and refinement checks. Agreement reaches working precision for these cached
numbers; this does not upgrade the source cache to80-digit independent
physical data. The exact packet and numerical cache share ancestry, action,
degree assignments and AI author; this is a normalization/implementation
cross-check, not external validation of those premises.

The first derivative equals one-quarter of the canonical measured UTP1 g^0
coefficient, tested after extraction. The retuned stationary-family shortcut
instead gives (14557.3818878,45282.4946995,25.3354887). Dropping the kinetic
endpoints changes the Phi control to14569.3009874. Both are rejected.
A massless-mode control has nonzero curvature2*lambda^2*v^2 even though its
mass vanishes at the point; such modes were not discarded. This concerns
the already UV-separated polynomial, not a claim that the corresponding
zero-momentum massless loop is IR finite or scaleless zero.

Commands: prepare.py,run.py,prepare_validation.py,run_validation.py with
python -B under this folder. Frozen native/validation bindings1293/1298;
native times after imports0.8933989/2.1451870s, verifier12.0630061s.
Zero failed native/verifier executions. Largest private-memory sample
430227456 bytes, not a measured peak. Caps90/90s after imports,8GiB sampled,
350MiB launch floor,4MiB package and all tolerances unchanged. Sources and
full captures are preserved; the old expensive finite calculations are reused
as authenticated evidence, not rerun.

This supplies an actual radial scalar-loop potential piece of deltaK. Full
nonradial mass counterterms, parent-parameter projection, other gauge/source/
width inputs, finite normalization and the two-loop C1_GS amplitude remain
open. No external, Lean or empirical validation, scientific authority or
physical benchmark promotion follows. All historical evidence and state113/
34of39 remain; E5/A5 unqualified, HB1/C5 blocked, flavor paused, quartetfailure,
custodyexit2/seven and separate physical-control/matching limits unchanged.
