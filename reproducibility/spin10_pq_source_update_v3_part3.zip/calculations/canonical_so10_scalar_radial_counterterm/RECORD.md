# SRC1 — scalar-loop radial counterterm curvature

Prospective at9b154e8b4a062f540205d27d62f251b291c1c72f/main,2026-10-20.
Previous goal turn PROGRESS: OFV1 and GQH1 completed, not full E5/C1_GS.
Preflight clean, no matching active workers;452 bindings authenticate bytes.
Question: what is the complete three-radial curvature of the scalar-loop
local potential subtraction U0=Tr328[V''(q)^2]/4 at the actual point?
This supplies a necessary vacuum-sector scalar mass-counterterm submatrix.
It is not the full328x328 scalar-loop Hessian or a finite mass prediction.

Freeze the physical parent, POINT algebraic root, exact V81 raw34 block
matrices/metrics, actual AST field degrees,35-block real multiplicities,
HST complex128 cache/model metadata and prior OFV1 pole normalization.
All328 internal directions, including38 tree-zero modes, are retained.
The three external coordinates are canonical Phi,Sigma,S radial amplitudes
q0=(sqrt60,sqrt(3/5),sqrt(3/5)). Every parent parameter, including the Higgs
mass, is fixed during field variation; their stationary values are evaluated
only at q0. No stationary/Higgs-tuned parameter family is differentiated.

## Frozen mathematical representation

In each qualified SM block let M0 be its metric at the fixed point. For a
nonzero raw slot entry (i,j), let n_r be the parent monomial's radial field
degree and l_ir/l_jr count the two external-leg species. In fractional
Cartesian displacements q=q0*(1+u), the fixed-frame raw Hessian is

    B_ij(u)=sum_slots c_slot*raw_slot_ij*prod_r(1+u_r)^p_r,
    p_r=n_r-l_ir-l_jr.

For each nonzero entry assert p_r>=0 and sum_r p_r<=2. The physical trace
is Tr(M0^-1 B M0^-1 B), with both kinetic endpoints included. M0 stays
fixed in this polynomial frame; it is not the raw moving-basis matrix.
The trace degree is at most4 in any straight radial variation.

Primary differentiates B: B_r=sum p_r*entry, B_rs=sum p_r*(p_s-delta_rs)*entry.
For real-irrep multiplicity d, sum all35 blocks and use

    t_r = sum d*Tr(M0^-1 B M0^-1 B_r)/(2q0_r),
    C_rs = sum d*[Tr(M0^-1 B_r M0^-1 B_s)
                  +Tr(M0^-1 B M0^-1 B_rs)]/(2q0_r q0_s).

The actual scalar-loop counterterm multiplies L=hbar/(16pi^2 epsUV).
Tr(H^2) has dimension4, t dimension3 and C dimension2. The algebraic root
can be reduced by POINT's exact quadratic, retaining its declared branch.
Derivatives act on external fields before that evaluation/reduction.

Replay evaluates the exact fixed-frame trace at t=0,+/-1,+/-2 in all three
coordinate and three paired directions. For a polynomial f(t) of degree4,
f'(0)=[8(f(1)-f(-1))-(f(2)-f(-2))]/12 and
f''(0)=[16(f(1)+f(-1)-2f(0))-(f(2)+f(-2)-2f(0))]/12.
No analytic B derivative or primary result is read by replay. The raw block
inputs and degree/frame map are shared; that limitation stays explicit.

Verifier imports no new native helper. Use the independent HST complex128
cache with80-digit arithmetic to avoid stencil roundoff. Build the actual
point coefficients from frozen JSON, once; hold them fixed while changing q.
Use h=1/4 and1/8 (all amplitudes positive), the degree4 formula and all six
directions. Compare all3 gradient and9 curvature values and step refinement
with frozen scaled tolerance5e-8; source-cache precision remains complex128,
not80-digit input evidence. Native arithmetic is exact, reported values at
100 digits. First-derivative agreement with UTP1 is tested only AFTER extraction.
Reject the stationary-family gradient, missing kinetic-leg subtraction and
a model control that drops a massless mode before taking curvature.

The local UV coefficient is the already separated OFV1 polynomial; taking
its derivative is not an unqualified interchange of massless limits with
the full loop integral. Positive-mass UV normalization is inherited; no
scaleless integral or IR/finite contribution is assigned zero. The vacuum
constant is retained as a coefficient, without choosing a vacuum-energy
prescription. No finite VEV/tadpole condition, on-shell mass or matching fit.

Expected evidence: exact reduced t3/C3x3 and replay equality, all35/328 census,
independent cache checks/controls, or a discrepancy/underdefinition/incomplete
run. Native90s/verifier90s AFTER imports,8GiB sampled private NOTpeak,
350MiB launch-commit floor,4MiB package. Freeze all bytes before math; full
captures precede assertions, failures/unfinished sources remain, no silent
resource/tolerance expansion or expensive old finite-loop replay.

Shared action, cache ancestry, field degrees, symbolic/runtime software and
AI authorship limit the checks; no external, Lean or experimental validation.
State113/34of39,E5/A5unqualified,HB1/C5blocked,flavorpaused,C1_GSuncalculated,
quartetFAIL3960/648,custodyexit2/seven and separate physical-control/matching
warnings remain. No old evidence/state/action/point/source/partialGamma/
scheme/policy/main/remote/publication change. Whole ToE goal remains active.
