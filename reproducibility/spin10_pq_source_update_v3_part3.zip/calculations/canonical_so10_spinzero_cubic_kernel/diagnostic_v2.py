"""SCK1 finite-constant diagnostic; no qualification inferred."""
from functions import *
def main():
    start=begin('preparation_v2.json',180);which=sys.argv[1]
    mp.mp.dps=70 if which=='equal' else 90
    vals=[mp.mpf(1)]*3 if which=='equal' else [mp.mpf(3)/253,mp.mpf(1),mp.mpf('1e-12')]
    ax=0 if which=='equal' else 2;idx=[0,0,0];idx[ax]=3
    m=old_master();der=m.imaster_derivative(tuple(map(str,vals)),tuple(idx))
    unit,error=bubble_unit(vals[ax],vals[(ax+1)%3],vals[(ax+2)%3],8)
    out={'case':which,'masses':list(map(str,vals)),'axis':ax,'dps':mp.mp.dps,
      'old_derivative_over6':mp.nstr(vals[ax]*der/6,75),
      'finite_bubble':mp.nstr(unit,75),'quad_error':mp.nstr(error,10),
      'difference':mp.nstr(unit-vals[ax]*der/6,30)}
    if which!='equal':
        r=vals[0];d0=vals[2];sr=-bubble_finite(r)/(6*d0)-kinetic(r)/6
        out.update({'soft_subtracted':mp.nstr(unit-sr,65),'hard_heat_K_over2':mp.nstr(kinetic(r)/2,65)})
    save('diagnostic_'+which,'v2',out,start)
if __name__=='__main__':main()
