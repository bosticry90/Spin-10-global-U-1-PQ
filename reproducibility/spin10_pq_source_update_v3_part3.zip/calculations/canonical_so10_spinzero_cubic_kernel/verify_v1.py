"""SCK1 whole-domain, finite-constant and actual soft-matching validation."""
from functions import *
def require(v,n):
    if not v:raise AssertionError(n)
def table(n):return packed(HERE/n)
def main():
    start=begin('validation_preparation_v1.json',600);mp.mp.dps=160
    captured=[]
    specs=[('primary_kernel_v2',300),('diagnostic_equal_v2',180),('diagnostic_soft_v2',180),
      ('primary_numeric_numeric_v1',600),('replay_positive_numeric_v1',600),
      *[(f'replay_soft{i}_numeric_v1',600) for i in range(4)]]
    for key,cap in specs:
        c=json.loads((HERE/(key+'_capture.json')).read_bytes());r=json.loads((HERE/(key+'_result.json')).read_bytes())
        require(c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified'],key)
        require(c['launch']['memory']['available_pagefile']>=350*1024**2 and max(a['private_bytes'] for a in c['all_resource_samples'])<=8*1024**3,key+' resources')
        raw=gzip.decompress((HERE/(key+'_tables.json.gz')).read_bytes())
        require(sha256(raw).hexdigest()==r['tables_sha256'] and r['elapsed_after_imports']<cap,key+' hash/time')
        captured.append({'role':key,'seconds':r['elapsed_after_imports'],'sampled_private_max':max(a['private_bytes'] for a in c['all_resource_samples'])})
    failure=json.loads((HERE/'primary_kernel_capture.json').read_bytes())
    require(failure['execution_state']=='FAILED' and failure['exit_code']==1 and 'AssertionError' in failure['stdout_and_stderr'],'original failure preserved')
    exact=table('primary_kernel_v2_tables.json.gz');If=s.Function('Ifin')(x,y,z)
    times=[st,tt,ut];h=sum(1/a for a in times);U=st*tt+st*ut+tt*ut
    controls={}
    for i,v in enumerate([x,y,z]):
        tau=times[i];others=[a for a in times if a!=tau]
        # Product of heat determinants and radial Gaussian: <R_plane^2>=4/h.
        expected=-tau**2/6-tau/(3*h)
        require(clean(expr(exact['positive_axes'][str(i)]['heat_coefficient'])-expected)==0,'independent heat product')
        fourier=-tau**2/2+tau**3*(others[0]+others[1])/(3*U)
        require(clean(fourier-expected)==0,'Fourier angular Gaussian allD')
        # Explicit independent Laurent coefficient arithmetic, including evanescents.
        Ae3=(s.log(v)-1)/v**2
        bp=-1/(6*v);bf=v*s.diff(If,v,3)/6+s.Rational(1,4)/v-s.Rational(1,12)/v+v*Ae3/6
        ct=s.series(s.exp(s.EulerGamma*eps)*s.gamma(1+eps)*s.exp(-eps*s.log(v))/(6*v*eps),eps,0,1).removeO().expand()
        eb=exact['positive_axes'][str(i)]
        for a,b in zip(map(expr,eb['bare_Laurent']),[0,bp,bf]):require(clean(a-b)==0,'bare finite and poles')
        for a,b in zip(map(expr,eb['forest_Laurent']),[0,ct.coeff(eps,-1),ct.coeff(eps,0)]):require(clean(a-b)==0,'actual mass forest')
        require(clean(bf+ct.coeff(eps,0)-v*s.diff(If,v,3)/6)==0,'correct finite kernel')
        require(clean(expr(eb['Rprime_Laurent'][2])-v*s.diff(If,v,3)/6)==0,'Rprime representation')
        require(clean(2*bp+ct.coeff(eps,-1)-expr(eb['scale_j']))==0,'common scale factors')
        require(list(map(expr,exact['controls']['early_D4_bare_changes'][str(i)]))==[0,0,-1/(6*v)],'earlyD4 sensitive finite')
        require(clean(expr(exact['controls']['missing_Ae_bare_changes'][str(i)][2])-(1-s.log(v))/(6*v))==0,'single-mass omission')
        controls[str(i)]={'early_D4_finite_change':str(-1/(6*v)),'missing_forest_pole':str(bp),
          'missing_Ae_finite_change':str((1-s.log(v))/(6*v)),'initial_target_finite_error':str(-1/(6*v))}
    beta=2-eps
    hc=clean(s.combsimp(-s.gamma(3)*s.gamma(beta-3)/(6*s.gamma(beta))-s.gamma(3)*s.gamma(beta-2)/(3*s.gamma(beta+1))))
    require(clean(hc-expr(exact['one_soft_scalar']['hard_prefactor']))==0 and hc.subs(eps,0)==s.Rational(1,2),'hard analytic-index time integral')
    bf,kk=s.symbols('Bfin K',real=True)
    sr=[s.sympify(v,locals={**LOC,'Bfin':bf,'K':kk}) for v in exact['one_soft_scalar']['Rprime_soft_Laurent']]
    require(sr[:2]==[0,0] and clean(sr[2]+(j+bf)/(6*d)+kk/6)==0,'full soft mass+kinetic closure')
    require(exact['background_words']==15 and exact['Lambda_ghostS_prefactor']=='-3*g10^4','actual BFT scope and conversion')
    aa,bb,tv=s.symbols('a b t',positive=True)
    require(clean(s.sympify(exact['gaussian_ghost_1PI_weight'],locals={'a':aa,'b':bb,'t':tv})-tv**2/(2*aa*bb**2))==0,'Legendre ghost weight')
    p=table('primary_numeric_numeric_v1_tables.json.gz');rpos=table('replay_positive_numeric_v1_tables.json.gz')
    require(p['dps']==110 and rpos['dps']==240,'fixed worker precision')
    errpos=mp.mpf(0);errsoft=mp.mpf(0);conv=mp.mpf(0);quad=mp.mpf(0);gam=mp.mpf(0);leak=mp.mpf(0);reconstruct=mp.mpf(0)
    def qhistory(hist):
        nonlocal quad
        require([r['maxdegree'] for r in hist]==[8,10],'quadrature history')
        require(max(mp.mpf(v['error_estimate']) for v in hist)<mp.mpf('1e-50'),'quadrature estimate')
        delta=abs(mp.mpf(hist[-1]['value'])-mp.mpf(hist[0]['value']));quad=max(quad,delta)
        require(delta<mp.mpf('1e-40'),'quadrature refinement');return mp.mpf(hist[-1]['value'])
    for ci,c in enumerate([['1/2','1','2'],['1','1','1'],['2','3','7']]):
        key=str(ci);require(p['positive'][key]['masses']==rpos['data'][key]['masses']==c,'positive complete cases')
        for i in range(3):
            pv=qhistory(p['positive'][key]['axes'][i]);rr=rpos['data'][key]['axes'][i]
            require(mp.mpf(rr['imaginary_leak'])<mp.mpf('1e-80'),'positive imaginary leak')
            errpos=max(errpos,abs(pv-mp.mpf(rr['value'])))
    softvalues={};actualcontrol={}
    for ri,rtext in enumerate(['1/2','1','3/253','253/3']):
        key=str(ri);ps=p['soft'][key];rs=table(f'replay_soft{ri}_numeric_v1_tables.json.gz')
        require(ps['ratio']==rs['data']['ratio']==rtext and rs['dps']==240,'whole soft ratio scope')
        rr=q(rtext);hv=[qhistory(v) for v in ps['heavy_axes']];gh=ps['scalar_axis']
        require([(a['nodes'],a['radius']) for a in gh]==[(48,'0.03125'),(80,'0.03125'),(80,'0.015625')],'Gamma contour history')
        vals=[list(map(mp.mpf,a['Laurent'])) for a in gh]
        for a in gh:leak=max(leak,mp.mpf(a['imaginary_leak']))
        for a in vals:
            for k in range(3):gam=max(gam,abs(a[k]-vals[-1][k]))
        require(max(abs(v) for v in vals[-1][:2])<mp.mpf('1e-40'),'hard has no pole')
        kval=mp.mpf(ps['kinetic_direct_quad']);require(abs(kval-kinetic(rr))<mp.mpf('1e-80'),'independent kinetic integral')
        require(abs(vals[-1][2]-kval/2)<mp.mpf('1e-40'),'independent hard K/2')
        expected=hv+[vals[-1][2]];softvalues[key]=expected
        histories=rs['data']['histories'];require([h['d'] for h in histories]==['1e-44','1e-50','1e-56'],'all soft regulators')
        for di,history in enumerate(histories):
            dd=mp.mpf(history['d'])
            for i in range(3):
                ax=history['axes'][i];require(mp.mpf(ax['imaginary_leak'])<mp.mpf('1e-80'),'soft imaginary leak')
                for si,jj in enumerate([mp.mpf(0),mp.mpf(2)/7]):
                    row=ax['scales'][si];native=mp.mpf(row['native']);soft=mp.mpf(row['soft']);matched=mp.mpf(row['matched'])
                    require(abs(mp.mpf(row['j'])-jj)<mp.mpf('1e-118'),'scale retained')
                    outer=[rr,mp.mpf(1),dd][i]
                    independent=-(jj+bubble_finite(rr))/(6*dd)-kval/6 if i==2 else mp.mpf(0)
                    require(abs(soft-independent)<mp.mpf('1e-60'),'actual opened soft kernel')
                    reconstruct=max(reconstruct,abs(native-soft-matched))
                    target=expected[i]-(jj/(6*outer) if i<2 else 0)
                    errsoft=max(errsoft,abs(matched-target))
                    if di:
                        prev=mp.mpf(histories[di-1]['axes'][i]['scales'][si]['matched']);conv=max(conv,abs(matched-prev))
        if ri==2:
            row=histories[-1]['axes'][2]['scales'][1]
            actualcontrol={'missing_whole_soft_finite_change':row['soft'],
              'missing_kinetic_finite_change':mp.nstr(-kval/6,40),
              'equal_r1_j0_mass_control':'INSENSITIVE','actual_ratio':rtext,
              'matched_hard_K_over2':mp.nstr(kval/2,65)}
            require(abs(mp.mpf(row['soft']))>mp.mpf('1e50') and abs(kval/6)>mp.mpf('.01'),'sensitive actual soft controls')
    require(errpos<mp.mpf('1e-35') and errsoft<mp.mpf('1e-35') and conv<mp.mpf('1e-35'),'distinct full finite routes')
    require(gam<mp.mpf('1e-40') and leak<mp.mpf('1e-80') and reconstruct<mp.mpf('1e-60'),'Gamma and native reconstruction')
    # The actual mass-role reverse; scale shift follows from the logarithm itself.
    rr=q('3/253');A,B,C=softvalues['2'];Ar,Br,Cr=softvalues['3']
    roleerr=max(abs(Ar-rr*B+rr*mp.log(rr)/6),abs(Br-rr*A+mp.log(rr)/6),abs(Cr-rr*C))
    require(roleerr<mp.mpf('1e-40'),'actual mass-role reverse with scale normalization')
    u0,_=bubble_unit(mp.mpf(1),mp.mpf(2),mp.mpf(3),8)
    us,_=bubble_unit(mp.mpf(2),mp.mpf(4),mp.mpf(6),8)
    up,_=bubble_unit(mp.mpf(1),mp.mpf(3),mp.mpf(2),8)
    hom=max(abs(2*us-u0-mp.log(2)/6),abs(up-u0));require(hom<mp.mpf('1e-70'),'mass homogeneity and inner roles')
    require(sum(a.stat().st_size for a in HERE.iterdir() if a.is_file())<4*1024**2,'whole package byte cap')
    out={'schema':'SCK1_VALIDATION','status':'QUALIFIED_COMPLETE_SPINZERO_CUBIC_F2_MATCHING_KERNEL',
      'positive_cases':3,'positive_charge_axes_checked':9,'soft_mass_ratios':4,'soft_regulators_per_ratio':3,
      'scale_checks':[0,'2/7'],'max_positive_error':mp.nstr(errpos,20),'max_soft_error':mp.nstr(errsoft,20),
      'max_soft_limit_change':mp.nstr(conv,20),'max_quad_refinement':mp.nstr(quad,20),
      'max_Gamma_change':mp.nstr(gam,20),'max_imaginary_leak':mp.nstr(leak,20),
      'max_native_reconstruction':mp.nstr(reconstruct,20),'mass_role_error':mp.nstr(roleerr,20),'homogeneity_error':mp.nstr(hom,20),
      'positive_finite':'m_axis*Ifin_third/6','positive_scale':'-1/(6*m_axis)',
      'scalar_soft_subtraction':'-(j+Bfin(r))/(6*d)-K(r)/6','scalar_hard':'K(r)/2',
      'controls':controls,'actual_soft_controls':actualcontrol,'runs':captured,
      'original_failed_exact_derivation':'PRESERVED_NOT_PASS','model_ghostS_amplitude':'NOT_CALCULATED',
      'scientific_acceptance':'NOT_PERFORMED','authority':'34/39','C1_E5_A5_qualified':False,
      'shared_limits':['OLD master convention','action/reference inputs','software','AI authorship'],
      'elapsed_after_imports':time.perf_counter()-start}
    with (HERE/'validation_receipt.json').open('x',encoding='utf-8') as f:json.dump(out,f,sort_keys=True,indent=2);f.write('\n')
    print('RESULT '+json.dumps({'status':out['status'],'elapsed_after_imports':out['elapsed_after_imports'],
      'receipt_sha256':sha256((HERE/'validation_receipt.json').read_bytes()).hexdigest()},sort_keys=True),flush=True)
if __name__=='__main__':main()
