# SCK1: complete spin-zero cubic F² and scalar-soft matching kernel

Qualified by validation_receipt.json,SHA256
fce3be82ab650672b444b354f436bf4975992486b954d95a93c4731f54dcecf3.
Scientific acceptance NOT_PERFORMED,state113/authority34of39 unchanged.
This supplies the universal unit required by the complete GSS1 support;
the actual Spin(10) ghostS tensor amplitude has NOT been calculated.

For positive squared masses x,y,z,the charge-axis proper-subtracted finite
kernel is m_axis*Ifin_third/6,with scale derivative -1/(6*m_axis).
The bare axis pole -1/(6*m_axis) cancels against its actual graph-local
bubble mass forest +1/(6*m_axis). All three edge cuts and the BFT1 ghost
Wick weight +1/2 are retained. The heat/Fourier identity holds before setting
D=4-2eps. No overall pole remains for this nondifferentiated cubic unit.
This is not an overall counterterm result for the other primitive families.

For scalar squared mass d->0 and ghost masses(r,1),the actual opened bubble
has Bfin(r)=1-r log(r)/(r-1) and kinetic derivative -K(r),where
K(r)=integral_0^1 a(1-a)/[1+(r-1)a]da. The renormalized soft contribution
on the scalar-charge axis is -(j+Bfin(r))/(6d)-K(r)/6. Both terms must be
subtracted. The independently integrated hard heat value is K(r)/2,with
zero pole and zero scale derivative. Heavy charge axes have the finite
positive-bubble representation with inner scalar mass0;their scale derivative
remains -1/(6*m_axis). This covers both actual GSS1 ratios3/253 and253/3.

At r3/253,the hard scalar-axis unit is approximately
0.23182089723533413029018955493217905374058706568282. Omitting the soft
kinetic term changes this by -0.07727363241177804343006318497739. Omitting
the entire soft term leaves a divergent finite expression in the regulated
limit. At equal ghost masses and j0,the soft MASS control is INSENSITIVE;
the kinetic term still is not zero. These are unit coefficients,not a full
model threshold or physical observables. Bfin is not the earlier free b0.

The first exact worker FAILED an incorrect proposed finite target
[m Ifin_third-1/m]/6. Its sources,preparation and complete native capture
are retained without a qualification receipt. V2 independently accounts for
the three finite contributions 1/(4m),-1/(12m),(log(m)-1)/(6m),then the
fixed forest. This corrects the target to m Ifin_third/6. The corrected
formula agrees with the independently subtracted finite bubble integral;
merely changing the assertion did not qualify it. No old accepted result,
counterterm scheme,action or physical input was changed.

Primary numerical route: finite subtracted-bubble integral at110digits,
quadrature refinements8/10,and uncombined analytic-index Gamma/Beta/hypergeom
contours48/80nodes at radii1/32 and1/64. Replay: OLD authenticated dilog master
and direct third derivatives at fixed240digits,all9positive axes and all3
axes for four soft ratios,each at d1e-44,1e-50,1e-56. Native120digit and
matched80digit values were formed at240digits before serialization.
Separate validation checks j0,2/7,full mass/kinetic subtraction,role reversal,
homogeneity,forests and the zero complements of the Laurent poles.

Max positive error4.192e-113,soft error1.3941e-41 at1e-35gate,Gamma change
1.874e-59,native reconstruction4.762e-65. EarlyD4 changes the finite positive
kernel by -1/(6m) while its pole control is insensitive. Omitting the forest
leaves -1/(6m) pole;omitting Ae changes finite by(1-log(m))/(6m).

3193V2bindings,3210numeric,3235validation. ExactV2 5.6144s,diagnostics2.8423/
2.5434s,primarynumeric20.1433s,replaypositive109.5900s,softreplays12.3294/
13.9837/5.4906/5.3823s,validator6.7942s. Caps300exact/180diagnostic/600numeric
orvalidator;8GiB sampled private/350MiBlaunchfloor/4MiBpackage. Native sampled
private maxima under51MiB. The positive replay and first soft replay briefly
overlapped after a nonterminal poll;their frozen inputs and exclusive outputs
were independent,no dependent calculation read unfinished evidence,and both
resource gates passed. Other native workers were sequential. This scheduling
overlap is disclosed rather than described as entirely sequential execution.

One failed scientific derivation,zero numeric/validator failures,timeouts,
cancellations or worker-output truncations. Read-only retrieval mistakes
(missing inherited filenames,one Windows display-encoding error and an
overbroad text search) were corrected using actual file inventories/UTF8;
they are not scientific failures or successful evidence. Full native captures
remain intact. Initial lost terminal display was recovered from its failure
capture without rerunning the old worker.

Shared action,reference,master convention,software and AIauthorship limit
independence. No Lean,external scientist or empirical confirmation. TrackB
demonstrates detection of an erroneous finite target and an indispensable
soft kinetic contribution,alongside the cost of that derivation error.
Keep the FULL Cfamily before soft cancellation for parent-minus-family
ownership. Full ghostS,C1,E5/A5,other primitives and physical matching remain
unqualified. State,quartet failure,custodyexit2/seven NOTPASS and all protected
boundaries remain unchanged. Next: full ordered ghost/scalar charge operators
and spectral contraction,not another positive-only example.
