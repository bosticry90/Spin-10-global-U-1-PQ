"""SCK1 whole positive/one-soft spin-zero cubic kernel,full dimensional algebra."""
from data import *

def main():
    start=begin('preparation_v2.json',300);U=st*tt+st*ut+tt*ut;times=[st,tt,ut];masses=[x,y,z]
    If=s.Function('Ifin')(x,y,z)
    A0=lambda v:v*(s.log(v)-1)
    Ae=lambda v:v*(-1-s.zeta(2)/2+s.log(v)-s.log(v)**2/2)
    bareI=-(x+y+z)/(2*eps**2)+(sum(A0(v) for v in masses)-(x+y+z)/2)/eps+If+sum(Ae(v) for v in masses)
    positive={};wrongD={};noAe={}
    for axis,(v,tau) in enumerate(zip(masses,times)):
        others=[q for q in times if q!=tau]
        heat=-tau**2/6-tau**2*others[0]*others[1]/(3*U)
        fourier=-tau**2/2+(4/D)*tau**3/6*D*(others[0]+others[1])/(2*U)
        assert clean(heat-fourier)==0
        op=lambda V:((4/D-1)/2*s.diff(V,v,2)+2*v/(3*D)*s.diff(V,v,3))
        def jet(V,dim):
            out=s.series(op(V).subs(D,dim),eps,0,1).removeO().expand()
            return [clean(out.coeff(eps,p)) for p in [-2,-1,0]]
        jj=jet(bareI,4-2*eps);ct=[0,1/(6*v),-s.log(v)/(6*v)];rp=[clean(a+b) for a,b in zip(jj,ct)]
        target=v*s.diff(If,v,3)/6
        assert rp[0]==rp[1]==0 and clean(rp[2]-target)==0
        scale=clean(2*jj[1]+ct[1]);assert scale==-1/(6*v)
        positive[str(axis)]={'mass':str(v),'heat_coefficient':str(heat),'bare_Laurent':list(map(str,jj)),
          'forest_Laurent':list(map(str,ct)),'Rprime_Laurent':list(map(str,rp)),'scale_j':str(scale)}
        wrongD[str(axis)]=[str(clean(a-b)) for a,b in zip(jet(bareI,4),jj)]
        noAe[str(axis)]=[str(clean(a-b)) for a,b in zip(jet(bareI-sum(Ae(v) for v in masses),4-2*eps),jj)]
    # Scalar-third hard time integral:keep beta-2 before Gamma continuation.
    beta=2-eps
    hardcoef=clean(s.combsimp(-s.gamma(3)/6*s.gamma(beta-3)/s.gamma(beta)-s.gamma(3)/3*s.gamma(beta-2)/s.gamma(beta+1)))
    assert clean(hardcoef-1/((2-eps)*(1-eps)*(1+eps)))==0
    assert hardcoef.subs(eps,0)==s.Rational(1,2)
    bf,kk=s.symbols('Bfin K',real=True)
    H=1+eps*(j-s.log(d));B=1/eps+j+bf
    softbare=s.series(-H*B/(6*d)-H*kk/6,eps,0,1).removeO().expand()
    softct=s.series(H/(6*d*eps),eps,0,1).removeO().expand()
    soft=[clean(softbare.coeff(eps,p)) for p in [-2,-1,0]]
    ct=[clean(softct.coeff(eps,p)) for p in [-2,-1,0]]
    sr=[clean(a+b) for a,b in zip(soft,ct)]
    assert sr[0]==sr[1]==0 and clean(sr[2]+(j+bf)/(6*d)+kk/6)==0
    aa,bb,tv,hh=s.symbols('a b t h',positive=True)
    JJ=-hh*tv/bb-hh**2*tv**3/(aa*bb**3)
    W=JJ**2/(2*aa)+hh*s.series(s.log(bb+tv*JJ/aa),hh,0,2).removeO()
    g2=clean(-s.expand(W).coeff(hh,2));assert g2==tv**2/(2*aa*bb**2)
    info=json.loads((CAL/'canonical_so10_background_threshold_inputs/primary_result.json').read_bytes())['inventory']
    assert ['ghostS','1/2',15] in info['families'] and info['ghost_sunset_weight']=='1/2'
    value={'schema':'SCK1_EXACT_KERNEL','positive_axes':positive,'one_soft_scalar':{'hard_prefactor':str(hardcoef),
      'hard_finite':'K/2','heavy_axes':'positive finite bubble with scalar mass0','scalar_scale_j':'0',
      'bare_Laurent':list(map(str,soft)),'forest_Laurent':list(map(str,ct)),'Rprime_soft_Laurent':list(map(str,sr)),
      'Bfin':'1-r*log(r)/(r-1),limit r=1 is0','K':'integral a(1-a)/(1+(r-1)a),limit r=1 is1/6'},
      'gaussian_ghost_1PI_weight':str(g2),'Lambda_ghostS_prefactor':'-3*g10^4','Fphys_squared_over_B_squared':2,
      'background_words':15,'controls':{'early_D4_bare_changes':wrongD,'missing_Ae_bare_changes':noAe,
       'missing_forest_pole':'-1/(6*m_axis)','wrong_ghost_sign_weight_change':str(-2*g2)},
      'full_model_ghostS_calculated':False,'full_C1_or_E5_qualified':False,'scientific_acceptance':'NOT_PERFORMED'}
    save('primary','kernel_v2',value,start)
if __name__=='__main__':main()
