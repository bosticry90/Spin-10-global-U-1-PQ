# Custody correction after an erroneously early commit

The first seal failed because Git normalized six already-frozen CRLF files.
The narrow directory attributes were then added,but an ordinary git add did
not refresh the already staged file contents. The V2 index seal therefore
failed at kernel_v2.py as well. The controller erroneously proceeded to local
commit 58068a2c987ecc2886a7860bf0c95a6df1f678cd despite that failed gate.
That checkpoint is NOT the final byte-qualified research checkpoint.

No raw calculation,source,preparation,receipt or recorded input hash changed.
The six incorrect index/commit blobs contained LF while their authenticated
original raw files retained CRLF. git add --renormalize under the narrow
-text/-eol exceptions forces an index refresh that preserves the original
raw bytes. A subsequent separate corrective commit is required;there is no
reset,amend,history rewriting or replacement of the failed checkpoint.

The external V3 seal must authenticate every original input/source/capture,
all98new scientific-checkpoint files against their original raw SHA256s,
all26419baseline blobs against c5be086c4f746328e297313a5426abc7242dd5c5,
and the additional custody records. It must separately pass raw/index and
raw/index/HEAD equality. The completed e4 six-step authentication is reused;
its old evidence and project_state.json did not change. Custody exit2/seven
remains NOTPASS. No scientific calculation is replayed just to repair Git
storage. The scientific receipt and the later byte-custody seals have
different scopes and must not be counted as independent physics evidence.

TrackB records two failed byte-seal attempts and the erroneous early commit,
in addition to the retained failed initial finite-target derivation. The
scientific results remain those authenticated from original raw bytes;this
record does not conceal or relabel the controller failures as success.
