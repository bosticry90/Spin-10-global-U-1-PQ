"""SCK1 stable,finite,one-dimensional subtracted-bubble representation."""
from data import *

def f_weight(r):
    r=mp.mpf(r)
    if r==0:return -mp.mpf(5)/36
    t=r-1
    if abs(t)<mp.mpf('.1'):
        out=mp.mpf(0);n=1;tol=mp.power(10,-mp.mp.dps-8)
        while True:
            out+=(-1)**(n+1)*t**n/(n*(n+2)*(n+3))
            bound=abs(t)**(n+1)/((n+1)*(1-abs(t)))
            if bound<tol:return out
            n+=1
            if n>10000:raise ArithmeticError('F_WEIGHT_SERIES_RESOURCE')
    delta=[r**(n+1)*(mp.log(r)/(n+1)-mp.mpf(1)/(n+1)**2)+mp.mpf(1)/(n+1)**2 for n in range(3)]
    return (-delta[2]+(r+1)*delta[1]-r*delta[0])/t**3

def bubble_unit(outer,left,right,maxdegree):
    outer,left,right=map(mp.mpf,[outer,left,right]);assert outer>0 and left>=0 and right>=0 and left+right>0
    def at(a):
        if left==0:
            if a==1:return mp.mpf(0) # a.e.endpoint value of an integrable log
            logA=mp.log(right)+mp.log1p(-a);ratio=a*outer/right
        elif right==0:
            if a==0:return mp.mpf(0)
            logA=mp.log(left)+mp.log(a);ratio=(1-a)*outer/left
        else:
            A=a*left+(1-a)*right;logA=mp.log(A);ratio=a*(1-a)*outer/A
        return (logA/6+f_weight(ratio)+mp.mpf(5)/36)/outer
    return mp.quad(at,[0,mp.mpf('.5'),1],method='tanh-sinh',maxdegree=maxdegree,error=True)

def bubble_finite(r):
    r=mp.mpf(r);t=r-1
    if t==0:return mp.mpf(0)
    if abs(t)<mp.mpf('.1'):
        out=mp.mpf(0);n=1
        while True:
            out+=(-1)**n*t**n/(n*(n+1))
            if abs(t)**(n+1)/((n+1)*(1-abs(t)))<mp.power(10,-mp.mp.dps-8):return out
            n+=1
            if n>10000:raise ArithmeticError('B_FIN_SERIES_RESOURCE')
    return 1-r*mp.log(r)/(r-1)

def kinetic(r):
    r=mp.mpf(r);t=r-1
    if t==0:return mp.mpf(1)/6
    if abs(t)<mp.mpf('.1'):
        out=mp.mpf(0);n=0
        while True:
            out+=(-t)**n/((n+2)*(n+3))
            if abs(t)**(n+1)/(1-abs(t))<mp.power(10,-mp.mp.dps-8):return out
            n+=1
            if n>10000:raise ArithmeticError('K_SERIES_RESOURCE')
    return (r+1)/(2*t*t)-r*mp.log(r)/(t*t*t)
