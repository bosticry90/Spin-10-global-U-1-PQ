# SCK1 V2: resolve the finite Laurent discrepancy

The original exact worker FAILED before generating a kernel table. Its source,
preparation and full capture remain immutable. The asserted positive-axis
finite target was wrong by -1/(6v). This is an unqualified proposed formula,
not a change to any accepted model coefficient or subtraction scheme.

Retaining D=4-2eps gives a=eps/4+O(eps²), b=v/6+v eps/12+O(eps²).
The finite bare contributions are respectively 1/(4v), -1/(12v), and
v Ae'''/6=(log(v)-1)/(6v), in addition to v Ifin'''/6. Their sum is
v Ifin'''/6+log(v)/(6v). The independently fixed mass forest subtracts
log(v)/(6v). Thus the proper finite result is v Ifin'''/6, not the
initially asserted [v Ifin'''-1/v]/6. The omitted-Ae control likewise changes
to (1-log(v))/(6v). Early D4 still loses 1/(6v).

V2 keeps all positive and one-soft obligations, exact forest normalization,
soft kinetic term, hard K/2 result, authority ceiling and original caps. It
must also compare the corrected positive formula against the independently
subtracted finite bubble integral, including unequal and equal masses. It
may not qualify on the basis of replacing the failed assertion alone.

The least expensive diagnostic first computes the finite bubble and the OLD
master's direct third derivative for masses (1,1,1), at fixed 70 digits, and
one positive soft regulator d=1e-12, r=3/253, at fixed 90 digits in a fresh
process. Neither diagnostic selects a result from the new exact table.
Diagnostic caps 180s each,8GiB sampled,350MiB launch floor. Complete numeric
qualification remains a subsequent separately frozen step at original
precisions/tolerances. No model amplitude or scientific promotion is claimed.
