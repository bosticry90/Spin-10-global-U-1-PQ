# SCK1: complete spin-zero cubic F² kernel for ghostS support

Basec5be086c4f746328e297313a5426abc7242dd5c5/main. GSS1 independently qualified
the complete ghostS support:both ghost edges heavy,the scalar positive/Gold or
soft. This increment must supply BOTH positive and one-soft-scalar kernels;
a positive-only result cannot be used as a completed ghostS input. Whole goal
ACTIVE/incomplete,state113/34of39 unchanged. No model amplitude claimed here.

Same conventional BFT1 linearRxi/Gaussian-auxiliary,xi1 C1 reference,real field
metric and dimensional MSbar convention. Reuse its actual15nonderivative
background words and ghost sunset Wick weight+1/2,not E1quartic ghosts.
Mass variables x,y>0 are ghost squared masses,z>=0 scalar squared mass.
All three heat edges have spin0. Vertex matrices are not commuted through
mass projectors. Resolve each H charge/mass block,using actual tensor
covariance q1+q2+q3=0 for the heat phases. Keep all three charge axes.

Question: derive the complete proper-subtracted positive kernel and actual
one-soft scalar matching,in a form suitable for all admitted model masses.
This is a dependency-critical full universal unit,not a chosen normalization
to fit a Ward identity. Freeze proofs,sources,input hashes,expected evidence,
failure conditions and resource caps before calculation.

Primary derivation: off-diagonal scalar heat kernels and15inverse-product
background words. Their phases cancel only on the conserved-charge plane.
Their F² coefficient is E=-sum q_i²s_i²/6-sum q_i²s_i/(3h),h=sum1/s_i.
Independent route: solve the weak-field scalar Fourier inverse and angular
average in D dimensions. Each axis reduces to[(4/D-1)/2]I_vv+
[2v/(3D)]I_vvv of the BARE sunset. Retain D=4-2eps and its single-mass
finite additions through proper mass-forest subtraction. A separate finite
renormalized-bubble integral will numerically test the full finite constants,
not just high derivatives that would erase counterterms.

For z=delta>0,x=r>0,y=1,derive the actual opened heavy ghost bubble mass
Bfin(r)=1-r log(r)/(r-1) and momentum derivative-K(r),
K(r)=int_0^1 a(1-a)/[1+(r-1)a]da. Bfin is an explicit bubble function,NOT
the earlier unrelated free contact baseline b0. Use the regulated covariant
heat equation to close both mass and kinetic operators,before delta removal.
No universal Tr1zero is assumed. Match full proper primitive minus the
actual renormalized one-soft term,retaining finite kinetic/contact pieces.
Independently integrate the z=0 hard heat polynomial by analytic-index
Beta/Gamma continuation. Preserve the order of dimensional integration;
an evanescent times singular term can have a finite nonzero limit.

Numeric primary: proper-subtracted finite one-dimensional bubble integrals
for all positive axes,independent Cauchy/Gamma integral for soft scalar,and
finite bubble limits for the heavy axes. Replay: OLD MVM dilog master with
direct THIRD mass derivatives at FIXED240digits;all-positive cases and full
z=d1e-44/1e-50/1e-56 followed by actual mass/kinetic soft subtraction.
Use generic coincident/unequal positive cases and r1/2,1,3/253,253/3,including
the actual GSS1soft pair and its role reverse. Require convergence/agreement
<1e-35,quad refinement<1e-40,Gamma changes<1e-40/leak<1e-80. No numerical
coefficient is selected from the new exact result table. Native120digit,
matched80digit values are formed at240digits before display.

Separate verifier checks heat/Fourier identity for allD,the Laurent/forest
cancellation,three-cut real/ghost normalization,15word scope,all numeric
histories,common scales j0,2/7 and homogeneity/role permutations. Controls:
earlyD4,omitted forest/single-mass additions,wrong ghost sign,missing scalar
soft kinetic term,missing whole soft term. Preserve insensitive tests at
equal masses or special scales;actual r3/253 must test a nonzero soft mass.

Caps300s exact,600s per numeric/verifier,8GiBsampled,350MiBfloor,4MiBpackage.
No silent expansions,partial-cache resume,premature cancellation or evidence
editing. Outcomes:complete universal kernel;real discrepancy;underdefinition;
resource inconclusive. Failure leaves no qualification receipt. All model
tensor contractions,mixing,overall C1,parent-minus-family,finite field/width/
tadpole/parameter/reference jets and nonlinear matching remain separate.
No finite normalization/physical g/scale/point/scheme is adopted.

State113/34of39,E5/A5unqualified,HB1/C5blocked,flavorhumanpaused,C1null,
quartetFAIL,custody2/seven NOTPASS and physical limitations remain. No
activation,push,publication,outreach,branch/worktree or foundation adoption.
Shared action,master,reference,software/AIauthorship limit independence;
no Lean/external scientist/empirical confirmation. TrackB tests structural
loop reduction and detection of a finite soft/contact contribution,not a
separate benchmark. Validate/e4/seal before local commit;goal stays ACTIVE.
