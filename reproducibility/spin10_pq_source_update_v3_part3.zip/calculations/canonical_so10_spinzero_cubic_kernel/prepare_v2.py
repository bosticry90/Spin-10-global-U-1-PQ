"""Freeze SCK1 correction without rebinding failed evidence."""
from pathlib import Path
from hashlib import sha256
import json,ast
HERE=Path(__file__).resolve().parent
deps=json.loads((HERE/'preparation.json').read_bytes())['input_sha256']
for p,h in deps.items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
for n in ['preparation.json','primary_kernel_capture.json','CONTINUATION_V2.md','kernel_v2.py','diagnostic_v2.py','functions.py','prepare_v2.py','run_v2.py']:
    p=HERE/n;raw=p.read_bytes()
    if p.suffix=='.py':ast.parse(raw,filename=str(p))
    deps[str(p)]=sha256(raw).hexdigest()
    if p.suffix=='.py':
        q=HERE/(n+'.source.txt')
        with q.open('xb') as f:f.write(raw)
        deps[str(q)]=sha256(raw).hexdigest()
v={'schema':'SCK1_PREPARATION_V2','input_sha256':dict(sorted(deps.items())),
   'diagnostic_seconds':180,'exact_seconds':300,'scientific_acceptance':'NOT_PERFORMED',
   'original_failed_assertion_retained':True,'numerical_qualification_not_inferred':True}
with (HERE/'preparation_v2.json').open('x',encoding='utf-8') as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
print('FROZEN_V2',len(deps),'bindings',flush=True)
