"""SCK1 distinct finite-bubble/analytic-index and OLD-master routes."""
from functions import *
CASES=[['1/2','1','2'],['1','1','1'],['2','3','7']]
RATIOS=['1/2','1','3/253','253/3']
def fmt(v,n=120):return mp.nstr(v,n)
def quad_history(v,a,b):
    out=[]
    for md in [8,10]:
        value,error=bubble_unit(v,a,b,md)
        out.append({'maxdegree':md,'value':fmt(value),'error_estimate':fmt(error,15)})
    return out
def contour(r,N,radius):
    sums=[mp.mpc(0)]*3
    for k in range(N):
        e=radius*mp.exp(2j*mp.pi*(k+mp.mpf('.5'))/N)
        f=mp.exp(2*mp.euler*e)*mp.gamma(1+2*e)*mp.beta(2+e,2+e)*mp.hyp2f1(1+2*e,2+e,4+2*e,1-r)/((2-e)*(1-e)*(1+e))
        for t,p in enumerate([-2,-1,0]):sums[t]+=f/e**p/N
    return {'nodes':N,'radius':fmt(radius,12),'Laurent':list(map(lambda z:fmt(z.real),sums)),
      'imaginary_leak':fmt(max(abs(v.imag) for v in sums),20)}
def primary():
    positive={};soft={}
    for ci,c in enumerate(CASES):
        vs=list(map(q,c));positive[str(ci)]={'masses':c,'axes':[quad_history(vs[i],vs[(i+1)%3],vs[(i+2)%3]) for i in range(3)]}
    for ri,rtext in enumerate(RATIOS):
        r=q(rtext)
        soft[str(ri)]={'ratio':rtext,'heavy_axes':[quad_history(r,1,0),quad_history(1,r,0)],
          'scalar_axis':[contour(r,N,mp.mpf(1)/den) for N,den in [(48,32),(80,32),(80,64)]],
          'kinetic_direct_quad':fmt(mp.quad(lambda a:a*(1-a)/(1+(r-1)*a),[0,mp.mpf('.5'),1]))}
    return {'method':'finite_subtracted_bubble_and_uncombined_Gamma','dps':mp.mp.dps,'positive':positive,'soft':soft}
def replay(which):
    master=old_master();out={}
    if which=='replay_positive':
        for ci,c in enumerate(CASES):
            vs=list(map(q,c));axes=[]
            for i in range(3):
                idx=[0,0,0];idx[i]=3
                der=master.imaster_derivative(tuple(map(str,vs)),tuple(idx));value=vs[i]*der/6
                axes.append({'value':fmt(mp.re(value)),'imaginary_leak':fmt(abs(mp.im(value)),20)})
            out[str(ci)]={'masses':c,'axes':axes}
    else:
        ri=int(which[-1]);r=q(RATIOS[ri]);hist=[]
        for dtext in ['1e-44','1e-50','1e-56']:
            dd=mp.mpf(dtext);vs=[r,mp.mpf(1),dd];axes=[]
            for i in range(3):
                idx=[0,0,0];idx[i]=3
                der=master.imaster_derivative(tuple(map(str,vs)),tuple(idx));value=vs[i]*der/6
                scale=[]
                for jj in [mp.mpf(0),mp.mpf(2)/7]:
                    full=value-jj/(6*vs[i]);sr=-(jj+bubble_finite(r))/(6*dd)-kinetic(r)/6 if i==2 else mp.mpf(0)
                    scale.append({'j':fmt(jj),'native':fmt(mp.re(full)),
                      'soft':fmt(sr),'matched':fmt(mp.re(full-sr),80)})
                axes.append({'imaginary_leak':fmt(abs(mp.im(value)),20),'scales':scale})
            hist.append({'d':dtext,'axes':axes})
        out={'ratio':RATIOS[ri],'histories':hist}
    return {'method':'OLD_MVM_dilog_direct_third_derivatives','dps':mp.mp.dps,'data':out}
def main():
    start=begin('numeric_preparation_v1.json',600);which=sys.argv[1]
    assert which in ['primary_numeric','replay_positive',*[f'replay_soft{i}' for i in range(4)]]
    mp.mp.dps=110 if which=='primary_numeric' else 240
    value=primary() if which=='primary_numeric' else replay(which)
    save(which,'numeric_v1',value,start)
if __name__=='__main__':main()
