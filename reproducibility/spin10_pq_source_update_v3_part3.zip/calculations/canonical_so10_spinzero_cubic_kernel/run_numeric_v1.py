"""Sequential native numeric captures; no expected-result selection."""
from pathlib import Path
from hashlib import sha256
import json,sys,gzip
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/spinzero-cubic-kernel-v1-2026-10-20')
def dump(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
for p,h in json.loads((HERE/'numeric_preparation_v1.json').read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
which=sys.argv[1];assert which in ['primary_numeric','replay_positive',*[f'replay_soft{i}' for i in range(4)]]
cap=HERE/f'{which}_numeric_v1_capture.json';assert not cap.exists()
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
c=capture([sys.executable,'-B',str(HERE/'numeric_v1.py'),which]);dump(cap,c);dump(CONTROL/f'{which}_numeric_v1_full_capture.json',c)
print('TERMINAL',which,c['execution_state'],c['exit_code'],flush=True)
if c['exit_code']!=0:print(c['stdout_and_stderr'],flush=True)
assert c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
assert c['launch']['memory']['available_pagefile']>=350*1024**2 and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
r=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(r)==1 and r[0]['elapsed_after_imports']<600
blob=(HERE/f'{which}_numeric_v1_tables.json.gz').read_bytes();assert sha256(gzip.decompress(blob)).hexdigest()==r[0]['tables_sha256']
dump(HERE/f'{which}_numeric_v1_result.json',r[0]);print('COMPLETED',which,flush=True)
