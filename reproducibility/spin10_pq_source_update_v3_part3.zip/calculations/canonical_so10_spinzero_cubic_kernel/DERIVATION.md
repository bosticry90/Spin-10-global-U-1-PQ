# SCK1 prospective heat,bare-master and soft matching derivation

For three local spin-zero propagators,Wilson phases cancel by actual H-charge
conservation. The product of plane heat determinants and Gaussian widths
gives E_i=-s_i²/6-s_i²s_js_k/(3U),U=s1s2+s1s3+s2s3. This includes all15
labelled inverse/connection seagull words,with no background vertex derivative
for a nondifferentiated cubic. BFT1's ghostS Gaussian weight is+1/2.
Fphys²=2B² and Lambda=-12Gamma_F²/(ell²g10²) give
Lambda_ghostS=-3g10^4 sum ordered_tensor_weights*unit_kernel atxi1.
Do not insert another minus sign for the ghost loop.

The independent Fourier scalar inverse is1/P+(gqB)²[-1/P³+2p_plane²/P4].
Rotational averaging p_plane²=2p²/D yields per charge axis
[(4/D-1)/2]d_v² Ibare+[2v/(3D)]d_v³ Ibare. Its Schwinger Gaussian image
is exactly E_i for every D. Use the authenticated bare sunset convention

```
Ibare=-sum(v)/(2eps²)+[sum A0(v)-sum(v)/2]/eps+Ifin+sum Ae(v),
A0(v)=v(logv-1),Ae(v)=v[-1-zeta2/2+logv-(logv)²/2].
```

One-loop subgraphs are nondifferentiated bubbles,with pole1/eps and no
momentum-pole term. Closing their mass counterterm on the charged outer
spin-zero line gives+Gamma(1+eps)exp(gamma eps)(Q²/v)^eps/(6v eps).
All three edge cuts are retained with BFT1's real/ghost factors. Expected
proper kernel at Q²=1 is[v Ifin_vvv-1/v]/6,pole0;scale derivative-1/(6v).
This is to be derived/verified,not a fitted finite counterterm.

An independent complete finite representation,after the bubble subtraction,
is

```
R_v=(1/v)int_0^1 du u(1-u)int_0^1 da
 log[a m_j+(1-a)m_k+a(1-a)v*u/(1-u)] .
```

It follows from the genuinely convergent outer Fourier integral with the
renormalized bubble,so D4 is allowed AFTER that subtraction. The u integral
is elementary,leaving a stable1D integral. At the endpoints its a.e.value may
be defined arbitrarily where a logarithm is integrable;no finite cutoff.

## Scalar soft limit and a finite hard term

Put z=d,x=r,y=1,j=log(Q²/y). The bubble at zero soft momentum is
Bm=1/eps+j+Bfin(r),Bfin=1-r log(r)/(r-1),and its p² derivative is-K(r),
K=int a(1-a)/[1+(r-1)a]. Keeping the full covariant heat equation gives
TrG_F²=-Hdelta/(6d) and Tr[G(-D²)]_F²=+Hdelta/6. The latter follows by
integrating -eps*K_F²(t)/t on Reeps>0 at delta>0 then continuing;it is
not a universal rule for Tr1 in unrelated products.

Thus the renormalized soft coefficient on the scalar-charge axis is
Sren=-(j+Bfin)/(6d)-K/6. On the two heavy ghost-charge axes the soft region
is suppressed. No arbitrary Higgs finite mass condition is set;this is the
actual opened bubble and its graph-local pole counterterm. OSF's common
finite-Higgs and the separate HTB bridge retain their own scopes.

The independent hard heat integral at z=0 first integrates the scalar time:

```
exp(2gamma eps)Gamma(1+2eps)
/[(2-eps)(1-eps)(1+eps)]
*int_0^1 da [a(1-a)]^(1+eps)/[1+(r-1)a]^(1+2eps).
```

The finite hard scalar-charge value is K/2,scale0,pole0. Keeping only D4
before the singular time integration would incorrectly erase it. In the
positive-mass limit the finite bubble representation gives leading
-(j+Bfin)/(6d)+K/3;subtracting the INDEPENDENT kinetic soft term-K/6 leaves
K/2. This agreement is a test,not the definition of K/2. At r=1,j0 the soft
mass term is insensitive (Bfin=0),so actual r3/253 and nonzero scale controls
must also be retained.

The heavy-axis R_v remains the finite bubble integral with the other scalar
mass set0;its log(1-a) endpoint is integrable and dominated convergence
applies. Its scale derivative remains-1/(6v). These limits cover the full
GSS1 support without a two-soft/all-soft loop,which the actual ghost vertex
projectors exclude. Model amplitudes and full finite C1 are not computed
by this universal derivation alone.
