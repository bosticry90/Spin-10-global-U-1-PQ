"""Freeze completed native tables and separate SCK1 validator."""
from pathlib import Path
from hashlib import sha256
import json,ast
HERE=Path(__file__).resolve().parent
deps=json.loads((HERE/'numeric_preparation_v1.json').read_bytes())['input_sha256']
for p,h in deps.items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
for p in sorted(HERE.iterdir()):
    if p.is_file():deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for n in ['verify_v1.py','prepare_validation_v1.py','run_validation_v1.py']:
    p=HERE/n;raw=p.read_bytes();ast.parse(raw,filename=str(p));cp=HERE/(n+'.source.txt')
    with cp.open('xb') as f:f.write(raw)
    deps[str(cp)]=sha256(raw).hexdigest()
v={'schema':'SCK1_VALIDATION_PREPARATION_V1','input_sha256':dict(sorted(deps.items())),
 'seconds':600,'scientific_acceptance':'NOT_PERFORMED'}
with (HERE/'validation_preparation_v1.json').open('x',encoding='utf-8') as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
print('FROZEN_VALIDATION',len(deps),'bindings',flush=True)
