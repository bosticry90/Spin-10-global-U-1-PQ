# Frozen Windows bytes and Git normalization

The first precommit raw/index comparison FAILED before any commit: the
repository's inherited text=auto/eol=lf attributes normalized six new files
whose already frozen raw bytes contained Windows CRLF. core.autocrlf=false
does not override those attributes. This was a custody/controller failure,
not a failed scientific calculation or permission to refresh recorded hashes.

The original source,source copy,preparations,receipt and all their hashes
remain unchanged. This directory's narrow .gitattributes exceptions preserve
the six frozen files verbatim,following the repository's existing exact-byte
exception convention. No historical .gitattributes or other old blob changed.
The failed seal and its original manifest remain in the external control
record. A new V2 seal must pass raw/index/HEAD equality before reporting a
committed result. The scientific receipt does not attest to this later seal.
