# SCK1 complete numerical qualification after V2 correction

Freeze all sources and current completed/failed evidence before execution.
Positive masses: (1/2,1,2),(1,1,1),(2,3,7),all three charge axes.
Soft ratios r=1/2,1,3/253,253/3,including both actual ghost mass roles.
Primary fixed110digits: finite-bubble quadrature maxdegree8 and10; heavy
axes have the scalar mass0; scalar axis uses the uncombined analytic-index
Gamma/Beta/hypergeometric integral,48/80nodes at radius1/32 and80 at1/64.
Replay positive fixed240digits,OLD authenticated dilog master/direct third
derivatives. Four separate fresh replay soft workers at fixed240digits,
each full3axes at d=1e-44,1e-50,1e-56,with both independently derived mass
and kinetic soft contributions subtracted BEFORE formatting. This separates
resource ownership,not mathematical coverage; all four must pass.

Require positive/soft agreement and successive soft limits<1e-35,quadrature
refinement<1e-40,quadrature estimates<1e-50,Gamma changes<1e-40 and imaginary
leak<1e-80. Retain native120digit and matched80digit soft values; recompute
native soft subtraction in the verifier. Compare j=0,2/7 on every axis,
pole and finite mass forests,homogeneity and mass-role permutations.
No fresh numeric worker imports the new exact table or uses its result as
its answer. The verifier alone compares routes/targets. Functions shared by
workers only supply mass parsing and OLD-master loading; primary integrates
the renormalized bubble while replay differentiates the dilog master.

Caps600s each primary,replay-positive,and each replay-soft worker;600s
verifier;8GiB sampled private allocation,350MiB available-commit launchfloor,
4MiB total package. Original failed exact source and capture remain bound.
No partial resume,finite result fitting,model amplitude or C1 promotion.
