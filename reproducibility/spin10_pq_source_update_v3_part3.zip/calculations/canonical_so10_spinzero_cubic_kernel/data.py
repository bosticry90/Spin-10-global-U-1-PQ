"""SCK1 fixed-domain exact and high-precision kernel helpers."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json,gzip,sys,time,threading,os,importlib.util
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
eps,D,d,jm=s.symbols('eps D d jm',real=True)
st,tt,ut=s.symbols('s t u',positive=True)
x,y,z=s.symbols('x y z',positive=True)
LOC={str(v):v for v in [eps,D,d,jm,st,tt,ut,x,y,z]}
def expr(v):return s.sympify(v,locals=LOC)
def clean(v):return s.cancel(s.expand(v))
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def load(n,p):
    spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def begin(prep,seconds):
    start=time.perf_counter();w=threading.Timer(seconds,lambda:os._exit(124));w.daemon=True;w.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    for p,h in json.loads((HERE/prep).read_bytes())['input_sha256'].items():assert sha256(Path(p).read_bytes()).hexdigest()==h,p
    return start
def save(role,kind,v,start):
    raw=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/f'{role}_{kind}_tables.json.gz').open('xb') as f:f.write(blob)
    print('RESULT '+json.dumps({'schema':'SCK1_'+kind.upper(),'role':role,'elapsed_after_imports':time.perf_counter()-start,
      'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(blob).hexdigest(),'raw_bytes':len(raw),'packed_bytes':len(blob)},sort_keys=True),flush=True)
q1,q2,q3=s.symbols('q1 q2 q3',real=True)
j=s.Symbol('j',real=True)
LOC.update({str(v):v for v in [q1,q2,q3,j]})

def q(v):
    v=str(v)
    if '/' in v:
        n=s.Rational(v);return mp.mpf(int(n.p))/int(n.q)
    return mp.mpf(v)

def old_master():return load('sck_cck',CAL/'canonical_so10_charged_current_kernel/data.py').finite_master_coefficients()
