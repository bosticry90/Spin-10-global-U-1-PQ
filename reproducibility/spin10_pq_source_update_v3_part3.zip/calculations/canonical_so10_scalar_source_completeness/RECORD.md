# SSC1: the remaining affine scalar-source sector

Base ed06fb8f/main; previous goal turn PROGRESS. This tests the remaining
source-completeness question after GHC1, not a new tensor or protected gate.

1. **Question.** In the specified fixed-tree/reference affine extension class,
   must the general remaining scalar map r_a=U_a x+v_a have a factor g, and
   does a real polynomial primitive then remove it?
2. **Claims.** The actual kinetic Noether condition makes U_a0 skew. Quadratic
   local source consistency makes them commute; the compact CE trace identity
   forces U_a0=0. Literal quadratic mass contractions force v_a0=0 over the
   original parameter ring. A fixed numerical Casimir/invariant-projector
   inverse then supplies an affine CE primitive for r/g, with no inverse g,
   mass, field or width. This reduces the complete remaining minimal source
   sector under the explicit applicability hypotheses, not all finite schemes.
3. **Ceiling.** No baseline two-loop restoration, arbitrary nonaffine-family
   classification, full QAP/W5/A5/E5, physical/global limit or authority change.
   A universal infinitesimal physical parameter-span theorem is not inferred.
4. **Frozen types.** All328 real scalar directions54+252+20+2, actual45 rho
   matrices, positive internal kinetic Gram and source-left W1-W7 signs.
   Real polynomial coefficient ring with independent mass coordinates, finite
   jets and nonnegative dimensions. Scalar maps are affine by complete source
   census. Retain all ordinary counterterms, currents and physical Eulers.
5. **Evidence.** GHC gauge/ghost normalization, QNF locality at normalization
   degree2 BEFORE g0, exact-obstruction invariance, SHG full scalar/source signs,
   Schur/invariant projector completeness, uniform primitive first-probe and
   actual literal action/embedding records. Authenticate these, do not rerun
   large loops, old Schur ranks, full source tensors or broad E4 audit.
6. **Primary.** Exact scalar Euler/kinetic calculation, full embedding mass
   Grams, universal CE trace contraction and actual Casimir normalization.
   Define a typed fixed numerical affine-module homotopy with an explicit
   invertibility proof, not a new numerical fit.
7. **Replay.** First variation/current, direct ambient quadratic contraction
   accumulation, affine/graded source composition and separate trace proof.
   Reconstruct actual full328 fixtures and all13 invariant projector directions.
8. **Controls.** Dropping skewness/commutativity/cocycle/perfectness or treating
   a singlet as gauged; special massless rings; missing factorial/complex-real
   normalization; wrong homotopy or source sign; discarded translations. The
   finite fixtures are controls, not the proof for arbitrary scalar maps.
9. **Known limits.** No EOM reduction, unrestricted nonlocal g0/IR limit, or
   assumption that multiple-Q traces exist. The mass specialization is only a
   nonzero-polynomial witness, not a benchmark. Distinguish fixed numerical
   operator inverse from forbidden physical denominators and from an assembled
   107912-square matrix. Apply linear and translation dimensions separately.
10. **Caps.** Two sequential120s-after-import native workers, independent180s;
    8GiB sampled private,350MiB available-commit launch floor,8MiB package.
    Freeze source/own inputs, AST-parse new scripts, preserve every failure.
11. **Outcomes.** Qualified conditional full scalar-source reduction; actual
    evading linear/translation map; exact missing premise; or bounded incomplete.
    The known nonintegrable infinitesimal classes remain valid in the larger
    linear cohomology. Do not redefine original E5 acceptance around this class.
12. **Evidence record.** Complete route comparison, independent checks, captures,
    exact failed sources, input/new-byte/old-Git seals and local commit. Shared
    action, inherited mathematical proofs, software and AI authorship disclosed.
    State113/34of39, custody exit2/seven, blocked/paused stages unchanged.
