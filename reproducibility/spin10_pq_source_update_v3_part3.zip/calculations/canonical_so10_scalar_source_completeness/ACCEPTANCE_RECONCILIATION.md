# A complete conditional source reduction still has an applicability boundary

This is evidence reconciliation, not protected acceptance or a replacement
scientific ledger. The original literal nonhorizontal ghost-rescaling witness
remains. Its justified first-probe replacement, PBL/BPC comparisons and the
actual UV residue physical-span theorem remain in their qualified scopes.

GHC and SSC now treat the GENERAL minimal source normal form, including
scalar translations and cross-sector linear maps, under the specified
affine fixed-tree/reference extension hypotheses. They do more than analyze
the four selected rotation classes. They do NOT show that every possible
renormalized prescription in original W6 necessarily belongs to that family.

W6 says first differing restored local counterterms obey Q delta=0 and
background Ward, with their insertion/source normalizations. It does not by
itself guarantee that any such difference can be freely scaled in an affine
one-loop family, nor establish every higher-order product needed for that
extension. Original E5 adequacy must not be silently redefined to the smaller
class just analyzed. The nonintegrable infinitesimal classes are preserved.

The conditional source-reduction theorem is useful, but the next decision
is whether its applicability can be derived from the actual quantum
construction or whether a definite normalization premise remains missing.
This has higher decision value than another selected coefficient calculation.
See NEXT_RESEARCH_QUESTION. Source-free physical/background stability can be
revisited after that applicability question, with parity/topological and global
limits kept explicit rather than assumed from PCS's actual-residue theorem.

The P-invariant homotopy ambiguity is also not automatically physical
unobservability; read INTERPRETATION_NOTE_V2. No scheme, physical parameter,
source alphabet, foundational action, gate or authority is changed here.
Full QAP/A5/E5, baseline higher-loop restoration, arbitrary products, physical
IR/vacuum/Lorentzian limits and viability remain unqualified at34/39.
