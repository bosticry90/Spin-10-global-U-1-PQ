# Verification scope and limits

Native sources/controllers are AST-parsed and frozen before execution. Primary
uses exact embedding Gram products and second-jet Euler derivatives; replay
accumulates ambient row contractions and uses first variation with currents.
Both check all328 scalar metrics/mass blocks, all45 real skew generators in
each sector, actual Casimir normalization and all13 invariant projector modes.
The general trace/homotopy proof covers cross-sector maps as well.

Actual full328 homotopy fixtures have norms96/560/16/0 for the four linear
sector cocycles and9/2 for the nontrivial phi translation. Noncommuting exact
CE fixtures expose the necessity of quadratic source consistency. Invariant
singlet translations are retained kernel modes, not divided by a zero Casimir.

The independent verifier imports no new native helper. It checks the scalar
principal symbol, homogeneous affine/source signs, literal contractions,
actual Casimir/projector data and universal positive-operator identities.
The complete real Schur/invariant-rank theorem and qualified source/coordinate
duals are authenticated inherited evidence, not freshly recomputed. The
107912-square operator inverse is defined by a proved numerical operator
program; no dense inverse or full mixing-coefficient table is claimed.

The theorem assumes the current polynomial ring with independent mass
coordinates. A massless specialization can destroy the mass-kernel argument;
it is a control, not a new theory/benchmark. Finite fixtures do not substitute
for the all-module CE/trace proof. The original all-scheme applicability gap
and nonintegrable linear classes are preserved.

Three read-only prelaunch navigation/metadata mistakes are preserved separately:
a mass-term query used a key absent from gauge/kinetic rows; rg received a
literal Windows glob path; a read guessed scalar_v2.py instead of locating
test_v2.py. No native scientific worker was launched by these mistakes.
Runtime/failure counts belong to the completed receipt. Old loop, Schur-rank,
large source/Euler expansions and broad E4 audit are reused, not rerun.

Shared action, conventions, inherited algebraic/analytic premises, Python/SymPy
and AI authorship limit independence. No Lean, outside scientist or experiment.
No universal quantum equivalence, baseline higher-loop restoration or protected
promotion. Historical custody remains exit2/seven, never PASS.
