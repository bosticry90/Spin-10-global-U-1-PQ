"""Independent scalar principal-symbol, mass and affine homotopy proof checks."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations,product
import json,sys,os,time,threading
import sympy as s
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_scalar_source_completeness'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
vp=read(O/'validation_preparation.json')
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h,raw
def readonly(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):
  raise PermissionError('SSC_VERIFY_READ_ONLY')
sys.addaudithook(readonly);prep=read(O/'preparation.json')
a=read(O/'primary_result.json');b=read(O/'replay_result.json');skip={'route','elapsed_after_imports'}
assert {k:v for k,v in a.items() if k not in skip}=={k:v for k,v in b.items() if k not in skip}
for role in ['primary','replay']:
 c=read(O/(role+'_capture.json'));assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['post_run_observations_qualified']
get=lambda name:read(Path(prep['artifacts']['replay'][name]['path']))
mat=lambda pk:s.MutableSparseMatrix(*pk['shape'],{(i,j):s.sympify(v) for i,j,v in pk['entries']})
dims={'Phi':54,'Sigma':252,'phi':20,'S':2};physical=get('physical');action=get('action');embedding=get('embedding');shg=get('shg')
rho={sec:[mat(p) for p in physical['representation_matrices'][sec]] for sec in dims}
def clean(M):return M.applyfunc(s.simplify)
def dot(M,N):
 nn=N.todok();return s.simplify(sum(v*nn.get(key,0) for key,v in M.todok().items()))
def comm(M,N):return M*N-N*M
def packet(M):return [[i,j,str(s.simplify(v))] for(i,j),v in sorted(M.todok().items()) if s.simplify(v)!=0]
def fp(obj):return sha256(json.dumps(obj,separators=(',',':')).encode()).hexdigest()

print('STAGE verifier_full_kinetic_metric_and_literal_mass_normalization',flush=True)
massnames={'Phi':'mPhi2','Sigma':'mSigma2','phi':'mphi2','S':'mS2'}
blocks=[]
for sec,n in dims.items():
 rec=embedding['sectors'][sec];E=s.MutableSparseMatrix(rec['ambient_real_dimension'],n,{(i,j):s.sympify(v) for i,j,v in rec['embedding_entries']})
 diag=s.MutableSparseMatrix(E.rows,E.rows,{(i,i):s.sympify(v) for i,v in enumerate(rec['tensor_metric_diagonal'])})
 assert clean(E.T*diag*E)==s.eye(n)
 term=next(t for t in action['local_terms'] if t.get('coefficient_direction')==massnames[sec])
 factors=term['density']['factors'];assert factors[0]['value']=='-1' and factors[1]['name']==massnames[sec]
 arg=factors[2]['argument'];leaves=arg['factors']
 if sec=='Phi':
  assert [v['name'] for v in leaves]==['Phi','Phi'] and leaves[0]['indices']==leaves[1]['indices'][::-1]
  # Polarize literal Tr(Phi^2), not a guessed kinetic normalization.
  labels=rec['ambient_coordinates'];idx={v:i for i,v in enumerate(labels)};swap={}
  for i,label in enumerate(labels):
   p,q=map(int,label[4:-1].split(','));swap[i]=idx[f'Phi[{q},{p}]']
  gram=clean(E.T*s.MutableSparseMatrix(E.rows,E.rows,{(i,j):1 for i,j in swap.items()})*E)
 elif sec=='Sigma':
  assert leaves[0]['value']=='1/120' and {v['name'] for v in leaves[1:]}=={'Sigma','SigmaBar'}
  # Five-index permutations in both conjugate factors have identical signs;
  # their5! multiplicity cancels1/120 on the complete compact coordinate set.
  coords=rec['ambient_coordinates'];re=[v for v in coords if v.startswith('ReSigma')];im=[v for v in coords if v.startswith('ImSigma')]
  assert len(re)==len(im)==252
  assert all(list(map(int,v[v.index('[')+1:-1].split(',')))==sorted(map(int,v[v.index('[')+1:-1].split(','))) for v in coords)
  assert s.factorial(5)==120
  gram=clean(E.T*E)
 else:
  assert {v['name'] for v in leaves}=={sec,sec+'Bar'}
  gram=clean(E.T*E)
 H=2*gram;factor=s.simplify(H[0,0]);assert H==factor*s.eye(n)
 blocks.append([sec,massnames[sec],n,str(factor)])
assert blocks==a['mass_Hessian_blocks']
assert sum(n for sec,name,n,c in blocks)==328
assert sum(n for sec,name,n,c in blocks if c=='2')==306
# Nonzero determinant is a polynomial injectivity proof, not adoption of an
# inverse mass. A massless singlet specialization has a kernel, as disclosed.
assert a['mass_determinant_nonzero_polynomial']=='2^306*mPhi2^54*mSigma2^252*mphi2^20*mS2^2'
assert s.zeros(2)*s.Matrix([1,0])==s.zeros(2,1)

print('STAGE verifier_scalar_principal_symbol_affine_source_and_trace_identities',flush=True)
p=s.symbols('p0:4');p2=p[0]**2-p[1]**2-p[2]**2-p[3]**2
M=s.Matrix(3,3,s.symbols('m0:9'));X=s.Matrix(s.symbols('x0:3'))
N=-p2*(X.T*M*X)[0]
for i in range(3):assert s.expand(s.diff(N,X[i])+p2*((M+M.T)*X)[i])==0
# Homogeneous-coordinate affine bracket keeps translation and source signs.
def lift(A,v):return A.row_join(v).col_join(s.zeros(1,A.cols+1))
ra=s.Matrix(2,2,s.symbols('ra0:4'));rb=s.Matrix(2,2,s.symbols('rb0:4'));rc=s.Matrix(2,2,s.symbols('rc0:4'))
ua=s.Matrix(2,2,s.symbols('ua0:4'));ub=s.Matrix(2,2,s.symbols('ub0:4'));uc=s.Matrix(2,2,s.symbols('uc0:4'))
va=s.Matrix(s.symbols('va0:2'));vb=s.Matrix(s.symbols('vb0:2'));vc=s.Matrix(s.symbols('vc0:2'))
g,e,f=s.symbols('g e f');Aa=lift(-g*ra+e*ua,e*va);Ab=lift(-g*rb+e*ub,e*vb);Ac=lift(-g*rc+e*uc,e*vc)
sq=-comm(Aa,Ab)-g*f*Ac
ce=lift(comm(ra,ub)-comm(rb,ua)-f*uc,ra*vb-rb*va-f*vc)
for i,j in product(range(3),repeat=2):
 poly=s.Poly(sq[i,j],e,g)
 assert s.expand(poly.coeff_monomial(e*g)-ce[i,j])==0
 assert s.expand(poly.coeff_monomial(e*e)+comm(lift(ua,va),lift(ub,vb))[i,j])==0
# Positive-operator identity holds on ALL End(V), not only skew endomorphisms.
z=s.symbols('z0:3');Rr=s.Matrix([[0,z[0],z[1]],[-z[0],0,z[2]],[-z[1],-z[2],0]])
Y=s.Matrix(3,3,s.symbols('y0:9'));Z=s.Matrix(3,3,s.symbols('w0:9'))
assert s.expand(s.trace(Y.T*(-comm(Rr,comm(Rr,Y))))-s.trace(comm(Rr,Y).T*comm(Rr,Y)))==0
assert s.expand(s.trace(Y.T*comm(Rr,Z))+s.trace(comm(Rr,Y).T*Z))==0
skew=lambda v:s.Matrix([[0,v[0],v[1]],[-v[0],0,v[2]],[-v[1],-v[2],0]])
B=skew(s.symbols('b0:3'));C=skew(s.symbols('c0:3'))
assert s.expand(s.trace(C.T*comm(Rr,B))-s.trace(Rr.T*comm(B,C)))==0

print('STAGE verifier_actual_compact_Casimir_all13_modes_and_full328_fixture_hashes',flush=True)
assert shg['conditional_module_lemma'].startswith('Whenever the scalar cocycle')
assert shg['real_Schur_dimensions_reused']==[1,2,4,4]
assert shg['invariant_affine_dimension']==13 and shg['invariant_translation_dimension']==2
assert sum(len(m.todok()) for rr in rho.values() for m in rr)==7602
for sec,n in dims.items():
 for m in rho[sec]:assert m+m.T==s.zeros(n) and all(s.im(v)==0 for v in m.todok().values())
 c=s.sympify(a['translation_Casimir_by_sector'][sec])
 Cas=sum((-m*m for m in rho[sec]),s.MutableSparseMatrix(n,n,{}));assert clean(Cas)==c*s.eye(n)
# All translation inverse coefficients are fixed numerical constants; the
# two singlet zero modes are lifted by P, not by a forbidden zero inverse.
assert [s.sympify(a['translation_Casimir_by_sector'][sec]) for sec in dims]==[10,s.Rational(25,2),s.Rational(9,2),0]
assert [s.Rational(1,10),s.Rational(2,25),s.Rational(2,9),1]==[1/(s.sympify(a['translation_Casimir_by_sector'][sec]) or s.Integer(1)) for sec in dims]
planes=list(combinations(range(10),2));pr=[m.extract(range(0,20,2),range(0,20,2)) for m in rho['phi']]
ff={}
for i,j in product(range(45),repeat=2):
 cc=comm(pr[i],pr[j])
 for k,(r,c) in enumerate(planes):
  if cc[r,c]:ff[k,i,j]=s.sqrt(2)*cc[r,c]
assert len(ff)==720
for c,d in product(range(45),repeat=2):assert s.simplify(sum(ff.get((c,i,j),0)*ff.get((d,i,j),0) for i,j in product(range(45),repeat=2)))==8*(c==d)
assert all(ff.get((c,a,b),0)+ff.get((a,c,b),0)==0 for a,b,c in product(range(45),repeat=3))
# Reconstruct the11-mode projector's actual basis; completeness is inherited
# separately and is essential for invertibility of C+P on all cross blocks.
bas=[('Phi',s.eye(54)),('Sigma',s.eye(252)),('Sigma',s.MutableSparseMatrix(252,252,{(2*i,2*i+1):-1 for i in range(126)}|{(2*i+1,2*i):1 for i in range(126)}))]
for sec,n in [('phi',10),('S',1)]:
 for i,j in product(range(2),repeat=2):bas.append((sec,s.MutableSparseMatrix(2*n,2*n,{(2*k+i,2*k+j):1 for k in range(n)})))
assert [str(dot(B,B)) for sec,B in bas]==a['invariant_linear_norms']
for sec,B in bas:assert all(comm(m,B)==s.zeros(dims[sec]) for m in rho[sec])
fixtures=[]
for sec,n in dims.items():
 W=rho[sec][0];rr=[comm(m,W) for m in rho[sec]]
 H=sum((comm(m,r) for m,r in zip(rho[sec],rr)),s.MutableSparseMatrix(n,n,{}));assert clean(H)==-8*W
 assert all(dot(B,W)==0 for sec2,B in bas if sec==sec2)
 norm=s.simplify(sum(dot(r,r) for r in rr));assert norm==8*dot(W,W)
 fixtures.append([sec,'linear',fp(packet(W)),fp([packet(r) for r in rr]),str(norm)])
v=s.eye(20)[:,0];rr=[m*v for m in rho['phi']]
assert clean(sum((m*r for m,r in zip(rho['phi'],rr)),s.zeros(20,1)))==-s.Rational(9,2)*v
fixtures.append(['phi','translation',fp(packet(v)),fp([packet(r) for r in rr]),'9/2'])
assert fixtures==a['actual_full328_homotopy_fixtures']
assert a['noncommuting_exact_CE_fixture_exposes_missing_quadratic_condition']
# Abelian gauge control: f=0 permits a nonzero commuting skew one-generator
# map. The Spin10 Casimir/perfectness is necessary; global PQ is not gauged.
assert Rr!=s.zeros(3) and comm(Rr,Rr)==s.zeros(3)

print('STAGE verifier_operator_program_and_scope_review',flush=True)
# C positive, kerC=invariants, P complete orthogonal projector => C+P>0.
# CE projection+perfectness give Ps=0; the f cancellation above gives
# L_b H=-C s_b. Hence Y=-(C+P)^-1 H solves L_bY=s_b coefficientwise.
# Its inverse is a fixed matrix of numerical constants, not a physical
# denominator or an assembled107912-square table. Both grades stay separate.
assert a['affine_module_dimension']==328*328+328==107912
assert a['fixed_numerical_C_plus_P_inverse_primitive_proved_not_dense_matrix_assembled']
qnf=read(R/'calculations/canonical_so10_quantum_normalization_filtration/validation_receipt.json')
ghc=read(R/'calculations/canonical_so10_gauge_head_completeness/validation_receipt.json')
assert qnf['only_normalization_quadratic_sector_local_not_unrestricted_Gamma2']
assert ghc['general_normalized_ghost_head_g_divisibility_necessary_for_specified_affine_extension']
assert not a['all_linear_cohomology_universal_finite_scheme_or_E5_A5_qualified']
assert digest(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
assert sum(p.stat().st_size for p in O.iterdir() if p.is_file())<8*1024**2
out={'schema':'SCALAR_SOURCE_COMPLETENESS_INDEPENDENT_V1','execution_state':'COMPLETED',
 'scientific_disposition':'QUALIFIED_FULL328_CONDITIONAL_SCALAR_SOURCE_G_DIVISIBILITY_AND_POLYNOMIAL_AFFINE_PRIMITIVE_OPERATOR_PROGRAM_WITH_EXPLICIT_SCHEME_LIMITS',
 'input_sha256':vp['input_sha256'],'both_native_cores_agree':True,
 'full328_kinetic_and_literal_quadratic_mass_normalizations_independently_checked':True,
 'independent_principal_symbol_and_homogeneous_affine_source_sign_checked':True,
 'actual_Casimir8_and_universal_trace_positive_operator_identities_checked':True,
 'all13_invariant_mode_matrices_checked_Schur_completeness_reused':True,
 'full328_linear_and_translation_homotopy_fixture_hashes_reconstructed':True,
 'fixed_numerical_C_plus_P_inverse_program_and_CE_proof_reviewed_not_dense_matrix_or_mixing_table':True,
 'general_affine_scalar_source_head_g_divisible_in_specified_extension_class':True,
 'polynomial_source_left_primitive_removes_scalar_head_with_full_physical_Euler_and_current':True,
 'first_probe_and_canonical_chart_transport_reused_not_a_new_loop':True,
 'massless_specializations_and_all_linear_cohomology_not_claimed':True,
 'original_E5_all_scheme_applicability_not_silently_narrowed':True,
 'authority_changed':False,'E5_A5_HB1_C5_or_physical_promotion':False,
 'failed_native_workers':0,'failed_verifier_workers':0,'prelaunch_read_only_navigation_errors':3,
 'elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
