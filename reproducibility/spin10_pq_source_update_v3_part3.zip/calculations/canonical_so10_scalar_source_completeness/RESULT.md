# SSC1: complete conditional scalar-source reduction

Qualification requires a completed independent receipt and committed-byte
seal. The two native routes agree. No new loop, pole or stored functional
coefficient was measured or integrated.

Within the specified affine fixed-tree/reference extension class, after GHC
ghost/gauge normalization, the GENERAL remaining scalar-source correction
`r_a=U_a x+v_a` has a factor g. This covers ALL328 real coordinates and all
cross-sector endomorphisms, not a selected faithful block or H-only module.

The kinetic Noether condition makes U_a0 real skew. The local quadratic source
equation makes them commute. Contracting their full CE equation with the actual
structure constants yields `8 sum ||U_a0||^2=0`, so all U_a0 vanish. This is an
internal finite-dimensional trace argument, not quantum ghost positivity.

Translations are treated separately. Actual embeddings and literal mass
contractions give Hessian blocks

`2mPhi2 I54; 2mSigma2 I252; mphi2 I20; mS2 I2`.

Its determinant is a nonzero polynomial in the original independent mass
coordinates. The projected potential equation therefore forces v_a0=0 without
an inverse mass or EOM reduction. Specialized massless rings and physical
vacuum/IR limits are not covered by this injectivity statement.

Positive coefficient shift defines s=r/g. The explicit homotopy program is

`Y=-(C+P)^(-1) sum L_a s_a`, `C=-sum L_a^2`,

where P is the complete invariant projector with11 linear and2 translation
modes. C+P is a positive definite FIXED numerical operator; its inverse
preserves the polynomial parameter ring and dimensions. No107912-square
dense matrix or entrywise inverse table was assembled. The invertibility and
CE homotopy are proved algebraically; full328 linear/translation fixtures and
all13 projector modes are checked against actual matrices.

The admitted scalar primitive `G=+Jx.Y` changes the field-source rule by
`-g L(Y)=-r`. It retains the full physical Euler contraction, source-dual maps,
canonical N/U transport and ordinary/probe currents. The qualified uniform
primitive first-probe theorem supplies its bounded quantum interpretation.

Together with the earlier normalizations, this reduces the COMPLETE source
sector to source-free ordinary content in this explicit affine-extendible
class. It does not classify every linear cocycle or every finite prescription;
the unweighted nonintegrable classes remain. No assumption is made that every
original E5/W6 normalization belongs to this affine class. Full QAP/products,
geometric W5 at higher orders, baseline two-loop restoration and A5/E5 remain
separate. Authority34/39/state113, custody exit2/seven and all historical,
blocked/paused and physical limitations are unchanged.
