# Kernel ambiguity is not a physical unobservability theorem

The phrase "unobservable homotopy ambiguity" in the frozen DERIVATION section6
is too strong and is superseded by this note. The correct statement is
"undetermined invariant kernel component of the CE primitive".

If Y is changed by an invariant affine mode, its L_a image is unchanged, so
it removes the SAME scalar-source correction. Its Q-exact action image can
still change source-free kinetic/potential or translation normalization.
Operators and observables must be transported with it, under the existing
quantum-equivalence/A5 conditions. Physical unobservability has not been
proved merely because that mode lies in ker L.

Choosing PY=0 specifies a mathematical section and constructs one primitive.
It does not set a physical finite normalization or establish universal quantum
equivalence. The source-reduction, mass, trace and invertibility calculations
are unchanged. Their complete receipts and original draft bytes remain intact.
This is a scientific-interpretation correction caught before local commit,
not a native or verifier execution failure. Use RESULT together with this note.
