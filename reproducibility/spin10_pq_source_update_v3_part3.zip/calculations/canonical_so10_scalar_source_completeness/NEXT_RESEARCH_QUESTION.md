# Next priority: bridge the affine-family hypothesis to the actual target

UNTESTED. Reconcile the original W1-W7/E5 contracts before adopting any broader
conclusion from the completed conditional source reduction. No new axiom or
physical scheme is authorized by the last theorem.

At present GHC/SSC require an explicitly affine one-loop normalization family
and use its quadratic normalization degree. Original W6 instead describes
first differences between restored prescriptions. Determine whether the
current construction actually guarantees the needed affine extension, or
whether this is a genuine applicability gap. Do not infer it from linear
cocycle closure, a canonical classical map or a generic renormalization-group
analogy without matching the actual source/product/trace assumptions.

A possible bounded bridge is a unit EVEN local-cocycle insertion. For a
general delta satisfying Qdelta=Tbdelta=0, differentiate the SAME one-loop
finite construction with an external u*delta. Use the actual full Hessian,
reference determinant, metric lift, Duhamel terms, finite heat/Stokes conversion,
source duals and connected products. First inspect which existing domain and
finite-Stokes proofs genuinely cover this new marked operator. Odd primitive
first-probe coverage alone does not prove arbitrary even-cocycle coverage.

Let A_delta be the independently constructed one-loop insertion coefficient.
The relevant relation to test is

`Q A_delta + (F_kappa,delta) = chi_delta`,

including every finite local normalization/trace defect and ordinary current.
If chi_delta is defined and removable by a justified local correction, the
remaining fixed-normalization second-order condition may reduce to the local
square already tested, without assuming a freely scalable affine family.
If a nontrivial chi remains, calculate/classify it; do not choose it to cancel
the desired square. If a required domain/contact prescription is missing,
identify that exact premise. Do not take a g0 limit of a general nonlocal
insertion or commute it with IR/finite-part limits without proof.

The least expensive first action is a proof/domain dependency review of the
finite-Stokes construction at linear even-probe order, not a full tensor
expansion or two-loop amplitude. A local-Schwartz-probe statement is not
automatically a constant-strength normalization or global change of variables;
retain the actual infrared and field-independent operator exceptions.

An applicability proof, an explicit remaining trace/contact term, or a precise
underdefinition would each materially change the next E5 action. Do not
continue accumulating source-sector cancellations while this logical boundary
remains unresolved. No HB1/C5/C1_GS activation, source-free universal stability
claim, scheme adoption, protected promotion or change to historical evidence.
