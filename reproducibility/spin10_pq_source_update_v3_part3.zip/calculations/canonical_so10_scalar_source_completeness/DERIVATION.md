# Complete affine scalar-source reduction under the extension hypotheses

## 1. Retain the general scalar correction

After the qualified nonminimal, derivativeghost and GHC paired normalizations,
the minimal ghost/gauge corrections vanish. The general scalar map is
`r_a(x)=U_a x+v_a`, with U dimension0 and v dimension1, in the FULL328 real
Cartesian scalar frame. The exact full-g scalar-source equation is

`[rho_a,U_b]-[rho_b,U_a]-f_ab^c U_c=0`,
`rho_a v_b-rho_b v_a-f_ab^c v_c=0`.

These equations follow at positive coupling coefficient by the qualified
source-left mixed equation, not from g0 nilpotence alone. The conditional SHG
lemma gives r_h=0 for H indices at every coefficient when t(H,.)=0. Keep the
actual source duals, derivative-test currents and induced scalar companions
of every earlier exact normalization.

## 2. The full ordinary equation forces an internal skew metric

Take g0, source0, background/vector0 and positive ghost jets0 only AFTER
deriving the full source equations. Retain all scalar jets and constant ghost
symbols. Every ordinary counterterm has projected Q0 image0 because Q0x=0
and Q0B=dC. The remaining density is E_x.(U_a0 x+v_a0) C^a, required to be
an ordinary current. This uses the full physical Euler program, not E_x=0.

The actual kinetic density is 1/2 sum_A partial x_A partial x_A. Its
second-derivative Euler coefficient in this Noether density is proportional
to U_a0+U_a0^T. Potential terms contain no scalar derivatives and cannot
cancel it; translations contribute only a kinetic current. Thus every leading
U is real skew in the actual internal metric. This is not quantum/reflection
positivity or an assertion about the mixed gauge heat operator.

## 3. Local quadratic source consistency makes the leading maps commute

QNF first extracts hbar2 and quadratic normalization degree, giving a LOCAL
equation. Only then take the polynomial g0 coefficient. Complete source types
leave no scalar-source B/A or derivativeghost partner and no minimal source2.
Since Q0x=Q0C=0, Q0 of any allowed second-order counterterm has zero scalar
source head. The surviving square is the bracket of the affine r_a0. Its
linear component requires `[U_a0,U_b0]=0`; the translation component is kept.

Earlier exact normalizations cannot change this necessary obstruction: for
QD=0, the square changes under D->D+QG by
`Q[-(D,G)+(G,QG)/2]`. The stationary local source projection annihilates this
image. No canonicality of the nonminimal cochain projector or arbitrary
deformed-baseline quantum prescription is assumed.

## 4. A positive compact CE identity eliminates every linear leading map

Use the Hilbert-Schmidt pairing <X,Y>=Tr(X^T Y). For real skew U and rho,
cyclicity gives

`<U_c,[rho_a,U_b]>=<rho_a,[U_b,U_c]>`.

Contract the CE residual with f_ab^c U_c, summing all45 indices. The exact
actual normalization is `sum_ab f_ab^c f_ab^d=8 delta_cd`. Therefore

`sum_abc f_ab^c <U_c,CE_ab>
 =2 sum_abc f_ab^c <rho_a,[U_b,U_c]>-8 sum_c ||U_c||^2`.

With the actual CE equation and the quadratic commutativity condition both
terms on the left/right except the norm vanish. Hence all U_a0=0. The proof
is dimension-independent and applies to ALL328 scalar coordinates, including
cross-sector endomorphisms; it does not restrict unknown maps to a Schur block.
Actual matrices establish the required real metric and normalization. A
noncommuting exact CE fixture shows why linear closure alone is insufficient.

## 5. Translations require the literal mass contractions

The coefficient linear in x of the projected potential Noether density is
`-(M2 v_a0).x`. Higher cubic/quartic terms cannot enter this field degree;
kinetic translations are currents. Thus M2 v_a0=0, without an EOM reduction.

The actual AST and complete physical embeddings give the quadratic Hessian

`M2=diag(2 mPhi2 I54, 2 mSigma2 I252, mphi2 I20, mS2 I2)`.

The Phi trace uses symmetric tensors; the Sigma 1/5! contracts all ordered
five-indices and cancels their multiplicity; the complex phi/S bridges retain
their 1/sqrt2. The determinant is a nonzero polynomial in the FOUR independent
mass coordinates. Hence M2 is injective on polynomial columns and v_a0=0.
No inverse mass is introduced. Setting mass coordinates to1 is solely a
nonzero-polynomial witness, not a physical point. Specialized massless rings
are a different question, and neither constant-vacuum nor IR limits are taken.

Thus the complete remaining affine source map r has a factor g. Positive
coefficient shift defines s=r/g as a finite polynomial coefficient array, not
as division on BRST cohomology. Both dimension sectors remain separate.

## 6. A fixed numerical homotopy supplies the missing affine primitive

Let W=End_R(V) direct-sum V, with actions
`L_a(M,w)=([rho_a,M],rho_a w)`. They are skew-adjoint in their respective
internal metrics. Let P be the qualified COMPLETE invariant orthogonal
projector:11 linear modes and2 singlet translations. Define

`C=-sum_a L_a^2`, `H(s)=sum_a L_a s_a`.

C is positive semidefinite with kernel precisely the invariant modes, since
`<y,Cy>=sum ||L_a y||^2`. It commutes with every L_a by the actual Lie and
invariant-metric identities. C+P is positive definite and invertible. Its
inverse is a FIXED numerical algebraic operator determined by the actual rho
and P. Matrix entries lie in the same constant coefficient field by finite
linear algebra. It inverts no physical parameter, mass, width, field or jet.
This defines an explicit operator program, not an assembled107912-square
matrix or newly computed entrywise mixing table.

Project the CE equation for s: P L=0 and perfectness imply P s_a=0. The full
graded/sign-correct CE equation also gives

`L_b H(s)=-C s_b`.

The f terms cancel using total antisymmetry; keep that cancellation rather
than treating only one generator. Thus

`Y=-(C+P)^(-1) H(s)` satisfies `L_b Y=s_b`.

All parameter coefficients, dimensions, reality and finite jets are preserved.
Because s_h=0, L_hY=0: Y is H-equivariant and the primitive is background
invariant. The unique P-orthogonal solution fixes only the unobservable
homotopy ambiguity; it does not choose a physical finite normalization.

## 7. Full source-left primitive and its bounded quantum meaning

Y is an affine vector field Mx+w. In the beta chart use
`G_scalar=+sum Jx.Y`. The odd source-left convention gives X_G x=-Y and
the corresponding evaluation-dual source map. Its Q image changes the
scalar field rule by `-g L_aY=-r_a`, and retains +E_x.Y and the physical
first-variation current. It has no ghost/gauge source head. Canonical C=UN^-1
transports the WHOLE generator/action/current; no source0 shortcut.

This is a polynomial admitted dimension3 odd generator. The already qualified
uniform primitive first-probe construction supplies its operator-defined
connected insertion and descendant in the same formal Euclidean prescription.
It does not supply arbitrary multiple products, global field substitution,
baseline two-loop restoration or complete A5. No new loop coefficient is fitted.

Within the SPECIFIED affine-extendible class, general local counterterms can
therefore be reduced to source-free ordinary content plus admitted exact
normalizations/current programs. This is not a classification of ALL linear
cohomology: the known unweighted nonintegrable classes remain. Applying this
restriction to every original E5/W6 prescription requires its own applicability
argument; no original acceptance target or physical scheme is silently narrowed.
