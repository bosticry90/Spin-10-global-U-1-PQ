"""Full real scalar-source metric, compact CE identity and fixed homotopy."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations,product,combinations_with_replacement
import json,sys,os,time,threading
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
role=sys.argv[1];assert role in ['primary','replay']
tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
prep=read(O/'preparation.json')
for raw,h in prep['input_sha256'].items():assert digest(Path(raw))==h,raw
def readonly(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):
  raise PermissionError('SSC_NATIVE_READ_ONLY')
sys.addaudithook(readonly)
get=lambda name:read(Path(prep['artifacts'][role][name]['path']))
mat=lambda p:s.MutableSparseMatrix(*p['shape'],{(i,j):s.sympify(v) for i,j,v in p['entries']})
dims={'Phi':54,'Sigma':252,'phi':20,'S':2}
phys=get('physical');action=get('action');emb=get('embedding');shg=get('shg')
rho={sec:[mat(p) for p in phys['representation_matrices'][sec]] for sec in dims}
assert shg['raw_scalar_BRST_positions_checked']==29754 and shg['invariant_affine_dimension']==13

def nonzero(m):return {(i,j):s.simplify(v) for(i,j),v in m.todok().items() if v!=0}
def packet(m):return [[i,j,str(v)] for(i,j),v in sorted(nonzero(m).items())]
def fp(obj):return sha256(json.dumps(obj,separators=(',',':')).encode()).hexdigest()
def dot(a,b):
 aa=nonzero(a);bb=nonzero(b)
 return s.simplify(sum(v*bb.get(key,0) for key,v in aa.items()))
def comm(a,b):return a*b-b*a
def row_gram(E,weights):
 if role=='primary':return (E.T*s.diag(*weights,cls=s.MutableSparseMatrix)*E).applyfunc(s.simplify)
 out={};rows={}
 for(i,j),v in E.todok().items():rows.setdefault(i,[]).append((j,v))
 for r,entries in rows.items():
  for i,u in entries:
   for j,v in entries:out[i,j]=out.get((i,j),0)+weights[r]*u*v
 return s.MutableSparseMatrix(E.cols,E.cols,{key:s.simplify(v) for key,v in out.items() if s.simplify(v)!=0})

print('STAGE',role,'full328_kinetic_and_literal_quadratic_mass_contractions',flush=True)
mass_names={'Phi':'mPhi2','Sigma':'mSigma2','phi':'mphi2','S':'mS2'}
mass_terms={t.get('coefficient_direction'):t for t in action['local_terms'] if t.get('coefficient_direction') in mass_names.values()}
assert len(mass_terms)==4
def leaves(n,kind):
 out=[n] if n['node']==kind else []
 for key in ['argument','expression']:
  if key in n:out+=leaves(n[key],kind)
 for key in ['factors','terms']:
  for p in n.get(key,[]):out+=leaves(p,kind)
 return out
def field_degrees(n):
 k=n['node']
 if k=='Field':return {1}
 if k in ['ExactScalar','Parameter','InvariantTensor','RepresentationGenerator','StructureConstant']:return {0}
 if k=='Add':return set().union(*(field_degrees(p) for p in n['terms']))
 if k=='OrderedProduct':
  out={0}
  for p in n['factors']:out={a+b for a in out for b in field_degrees(p)}
  return out
 return field_degrees(n.get('argument',n.get('expression')))
quadratic=[t['coefficient_direction'] for t in action['local_terms'][5:] if field_degrees(t['density'])=={2}]
assert set(quadratic)==set(mass_names.values())
mass=[];embedding_checks=[]
for sec,n in dims.items():
 rec=emb['sectors'][sec]
 E=s.MutableSparseMatrix(rec['ambient_real_dimension'],n,{(i,j):s.sympify(v) for i,j,v in rec['embedding_entries']})
 weights=[s.sympify(v) for v in rec['tensor_metric_diagonal']]
 gram=row_gram(E,weights);assert gram==s.eye(n)
 term=mass_terms[mass_names[sec]];den=term['density']
 params=leaves(den,'Parameter');assert len(params)==1 and params[0]['name']==mass_names[sec]
 assert action['parameter_coordinates'][mass_names[sec]]=={'mass_dimension':2,'real':True}
 coeff=s.prod(s.sympify(v['value']) for v in leaves(den,'ExactScalar'))
 fields=leaves(den,'Field');assert len(fields)==2
 multiplicity=s.Integer(120) if sec=='Sigma' else s.Integer(1)
 if sec=='Phi':
  assert [v['name'] for v in fields]==['Phi','Phi'] and fields[0]['indices']==fields[1]['indices'][::-1]
  labels=rec['ambient_coordinates'];lookup={label:i for i,label in enumerate(labels)}
  for r,label in enumerate(labels):
   i,j=map(int,label[4:-1].split(','));assert E[r,:]==E[lookup[f'Phi[{j},{i}]'],:]
 elif sec=='Sigma':
  assert {v['name'] for v in fields}=={'Sigma','SigmaBar'} and len(fields[0]['indices'])==5
  assert coeff==-s.Rational(1,120)
 else:assert {v['name'] for v in fields}=={sec,sec+'Bar'} and coeff==-1
 ambient=row_gram(E,[s.Integer(1)]*E.rows)
 Hess=(-2*coeff*multiplicity*ambient).applyfunc(s.simplify)
 factor=s.simplify(Hess[0,0]);assert Hess==factor*s.eye(n) and factor!=0
 mass.append([sec,mass_names[sec],n,str(factor)])
 embedding_checks.append([sec,E.rows,n,len(E.todok()),fp(packet(gram)),fp(packet(Hess))])
assert mass==[['Phi','mPhi2',54,'2'],['Sigma','mSigma2',252,'2'],['phi','mphi2',20,'1'],['S','mS2',2,'1']]
det='2^306*mPhi2^54*mSigma2^252*mphi2^20*mS2^2'

print('STAGE',role,'complete_actual_compact_module_projector_and_Casimir_normalization',flush=True)
counts={};vector_C={}
for sec,n in dims.items():
 assert len(rho[sec])==45
 counts[sec]=sum(len(m.todok()) for m in rho[sec])
 for m in rho[sec]:assert m+m.T==s.zeros(n) and all(s.im(v)==0 for v in m.todok().values())
 C=sum((-m*m for m in rho[sec]),s.MutableSparseMatrix(n,n,{}));C=C.applyfunc(s.simplify)
 c=s.simplify(C[0,0]);assert C==c*s.eye(n);vector_C[sec]=str(c)
assert counts=={'Phi':1122,'Sigma':6300,'phi':180,'S':0}
assert vector_C=={'Phi':'10','Sigma':'25/2','phi':'9/2','S':'0'}
planes=list(combinations(range(10),2));pr=[m.extract(range(0,20,2),range(0,20,2))*s.sqrt(2) for m in rho['phi']]
assert pr==[s.MutableSparseMatrix(10,10,{(i,j):1,(j,i):-1}) for i,j in planes]
ff={}
for a,b in product(range(45),repeat=2):
 co=pr[a]*pr[b]-pr[b]*pr[a]
 for c,(i,j) in enumerate(planes):
  if co[i,j]:ff[c,a,b]=co[i,j]/s.sqrt(2)
assert len(ff)==720
fg=s.Matrix(45,45,lambda c,d:sum(ff.get((c,a,b),0)*ff.get((d,a,b),0) for a,b in product(range(45),repeat=2)))
assert fg==8*s.eye(45)
# These identities are the coefficients of BOTH universal f cancellations
# in L_b H=-C s_b and [C,L_b]=0 on every affine-module dimension.
assert all(ff.get((c,a,b),0)+ff.get((a,c,b),0)==0 for a,b,c in product(range(45),repeat=3))
basis=[('Phi',s.eye(54)),('Sigma',s.eye(252)),('Sigma',s.MutableSparseMatrix(252,252,{(2*i,2*i+1):-1 for i in range(126)}|{(2*i+1,2*i):1 for i in range(126)}))]
for sec,n in [('phi',10),('S',1)]:
 for a,b in product(range(2),repeat=2):basis.append((sec,s.MutableSparseMatrix(2*n,2*n,{(2*i+a,2*i+b):1 for i in range(n)})))
assert len(basis)==11
norms=[]
for i,(sec,M) in enumerate(basis):
 norms.append(str(dot(M,M)))
 assert all(comm(m,M)==s.zeros(dims[sec]) for m in rho[sec])
 for j,(sec2,N) in enumerate(basis):
  if sec==sec2 and i!=j:assert dot(M,N)==0
assert norms==['54','252','252','10','10','10','10','1','1','1','1']
for i in range(2):assert all(m*s.eye(2)[:,i]==s.zeros(2,1) for m in rho['S'])
# Completeness of these invariant modes is the inherited real Schur theorem,
# not inferred from finding this basis. Fresh checks fix its actual matrices.

print('STAGE',role,'Noether_source_square_and_compact_trace_certificate',flush=True)
xx=s.symbols('z0:4');x=s.Matrix([s.Function(f'x{i}')(*xx) for i in range(3)])
M=s.Matrix(3,3,s.symbols('u0:9'));v=s.Matrix(s.symbols('v0:3'));eta=[1,-1,-1,-1]
L=sum(eta[mu]*s.diff(x[i],xx[mu])**2 for i,mu in product(range(3),range(4)))/2
E=s.Matrix([-sum(eta[mu]*s.diff(z,xx[mu],2) for mu in range(4)) for z in x])
V=M*x+v;N=(E.T*V)[0]
varL=sum(eta[mu]*s.diff(x[i],xx[mu])*s.diff(V[i],xx[mu]) for i,mu in product(range(3),range(4)))
theta=[sum(eta[mu]*s.diff(x[i],xx[mu])*V[i] for i in range(3)) for mu in range(4)]
assert s.expand(N-varL+sum(s.diff(theta[mu],xx[mu]) for mu in range(4)))==0
def euler(f,z,order):
 out=s.diff(f,z)
 for n in range(1,order+1):
  for js in combinations_with_replacement(range(4),n):
   jet=s.diff(z,*(xx[j] for j in js));co=s.diff(f,jet)
   if co:out+=(-1)**n*s.diff(co,*(xx[j] for j in js))
 return s.expand(out)
for i in range(3):assert s.expand(euler(N,x[i],2) if role=='primary' else euler(varL,x[i],1))==s.expand(((M+M.T)*E)[i])
g,e,f=s.symbols('g e f');ra=s.Matrix(3,3,s.symbols('ra0:9'));rb=s.Matrix(3,3,s.symbols('rb0:9'));rc=s.Matrix(3,3,s.symbols('rc0:9'))
ua=s.Matrix(3,3,s.symbols('ua0:9'));ub=s.Matrix(3,3,s.symbols('ub0:9'));uc=s.Matrix(3,3,s.symbols('uc0:9'))
va=s.Matrix(s.symbols('va0:3'));vb=s.Matrix(s.symbols('vb0:3'));vc=s.Matrix(s.symbols('vc0:3'));X=s.Matrix(s.symbols('X0:3'))
A=-g*ra+e*ua;B=-g*rb+e*ub;C=-g*rc+e*uc
sq=-(A*B-B*A)*X-(A*e*vb-B*e*va)-g*f*(C*X+e*vc)
ce=(comm(ra,ub)-comm(rb,ua)-f*uc)*X+ra*vb-rb*va-f*vc
for i in range(3):
 pp=s.Poly(sq[i],e,g)
 assert s.expand(pp.coeff_monomial(e*g)-ce[i])==0
 assert s.expand(pp.coeff_monomial(e*e)+(comm(ua,ub)*X+ua*vb-ub*va)[i])==0
# Universal cyclic trace identity on arbitrary skew matrices. The matrix
# transpose/cyclicity proof in DERIVATION supplies every dimension, not just3.
skew=lambda q:s.Matrix([[0,q[0],q[1]],[-q[0],0,q[2]],[-q[1],-q[2],0]])
Rr=skew(s.symbols('r0:3'));Ub=skew(s.symbols('b0:3'));Uc=skew(s.symbols('c0:3'))
assert s.expand(s.trace(Uc.T*comm(Rr,Ub))-s.trace(Rr.T*comm(Ub,Uc)))==0

print('STAGE',role,'actual_full328_homotopy_fixtures_and_required_noncommuting_control',flush=True)
fixtures=[];noncommuting=False
for sec,n in dims.items():
 W=rho[sec][0];S=[comm(m,W) for m in rho[sec]]
 H=sum((comm(m,ss) for m,ss in zip(rho[sec],S)),s.MutableSparseMatrix(n,n,{})).applyfunc(s.simplify)
 assert H==-8*W
 assert all(dot(B,W)==0 for sec2,B in basis if sec2==sec)
 norm=s.simplify(sum(dot(z,z) for z in S));assert norm==8*dot(W,W)
 fixtures.append([sec,'linear',fp(packet(W)),fp([packet(z) for z in S]),str(norm)])
 if sec=='phi':
  noncommuting=any(comm(S[i],S[j])!=s.zeros(n) for i,j in combinations(range(45),2))
assert noncommuting
w=s.eye(20)[:,0];Sv=[m*w for m in rho['phi']]
Hv=sum((m*z for m,z in zip(rho['phi'],Sv)),s.zeros(20,1))
assert Hv==-s.Rational(9,2)*w
fixtures.append(['phi','translation',fp(packet(w)),fp([packet(z) for z in Sv]),'9/2'])
# Singlet translation is an invariant kernel mode, not a divide-by-zero case.
assert all(m*s.eye(2)[:,0]==s.zeros(2,1) for m in rho['S'])
# The scalar-source primitive G=+Jx.Y has V=-Y. Check full affine sign.
rr=s.Matrix(3,3,s.symbols('p0:9'));Y=M*X+v
variation=(-M)*(-g*rr*X)-(-g*rr)*(-Y)
assert s.expand(variation+g*(comm(rr,M)*X+rr*v))==s.zeros(3,1)
out={'schema':'SCALAR_SOURCE_COMPLETENESS_NATIVE_V1','route':role,
 'all328_kinetic_Gram_and_literal_mass_contractions':embedding_checks,'mass_Hessian_blocks':mass,
 'mass_determinant_nonzero_polynomial':det,'new_physical_mass_point_or_inverse_mass_used':False,
 'actual_scalar_representation_nnz':counts,'translation_Casimir_by_sector':vector_C,
 'actual_adjoint_contraction_Casimir':8,'invariant_linear_norms':norms,'invariant_linear_dimension':11,'invariant_translation_dimension':2,
 'actual_full328_homotopy_fixtures':fixtures,'noncommuting_exact_CE_fixture_exposes_missing_quadratic_condition':noncommuting,
 'generic_Noether_affine_source_sign_and_compact_trace_identities_checked':True,
 'general_leading_linear_and_translation_scalar_heads_vanish_in_specified_affine_extension_class':True,
 'fixed_numerical_C_plus_P_inverse_primitive_proved_not_dense_matrix_assembled':True,
 'affine_module_dimension':107912,'source_left_scalar_removal_sign':'+Jx.Y gives -g L(Y)',
 'uniform_first_probe_and_canonical_chart_transport_reused_not_new_loop':True,
 'all_linear_cohomology_universal_finite_scheme_or_E5_A5_qualified':False,
 'authority_changed':False,'scientific_disposition':'COMPLETE_CONDITIONAL_SCALAR_SOURCE_REDUCTION_PENDING_INDEPENDENT_VALIDATION',
 'elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
