# Full affine scalar-source reduction

Start with [RESULT.md](RESULT.md), then [DERIVATION.md](DERIVATION.md).
[RECORD.md](RECORD.md) freezes the question and [VERIFICATION.md](VERIFICATION.md)
states new checks, inherited premises and operator-program limits. Qualification
uses the completed independent receipt and committed-byte seal.

The source reduction is conditional on the stated affine extension class.
It does not silently replace original E5 adequacy with that narrower target.
