"""SQP1 raw bare-action dual-number expansion; no new native helper import."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import Counter
import gzip,json,os,sys,threading,time
import sympy as s

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(ROOT/'calculations/canonical_so10_uv_radial_tadpoles'))
from inputs import coeffs,w
xi=s.Symbol('xi',real=True)
CAS={'Phi':s.Integer(10),'Sigma':s.Rational(25,2),'SigmaBar':s.Rational(25,2),
     'phi':s.Rational(9,2),'phiBar':s.Rational(9,2),'S':s.S.Zero,'SBar':s.S.Zero}
@lru_cache(None)
def clean(z):return s.cancel(s.expand(z))
def tidy(M):return s.SparseMatrix(M).applyfunc(clean)
def zero(M):assert not tidy(M).todok()
def read(p):return json.loads(p.read_bytes())
def dec(d):return s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z,locals={'w':w,'xi':xi}) for i,j,z in d['entries']})
def dualmul(a,b):return (a[0]*b[0],a[0]*b[1]+a[1]*b[0])
def fields(node):
    if isinstance(node,list):return sum((fields(z) for z in node),Counter())
    if not isinstance(node,dict):return Counter()
    if node.get('node')=='Field':return Counter({node['name']:1})
    return sum((fields(z) for z in node.values()),Counter())

def main():
    tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    prep=read(HERE/'validation_preparation.json')
    for n,h in prep['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
    tabs=[];out=[]
    for role in ['primary','replay']:
        result=read(HERE/(role+'_result.json'));packed=(HERE/(role+'_tables.json.gz')).read_bytes();raw=gzip.decompress(packed)
        assert sha256(raw).hexdigest()==result['tables_sha256'] and sha256(packed).hexdigest()==result['packed_sha256']
        tabs.append(json.loads(raw));out.append(result)
    assert tabs[0]==tabs[1];tab=tabs[0]
    mats={k:dec(v) for k,v in tab['matrices'].items()}
    slots,cc,_,cv,point,_=coeffs();alpha=(3+xi)/2;beta=(3-xi)/2
    source=read(ROOT/'calculations/canonical_so10_singlet_tadpole/original_v2_result.json')
    frame=json.loads(gzip.decompress((ROOT/'calculations/canonical_so10_scalar_sm_frame/replay_tables.json.gz').read_bytes()))
    ast=read(PK/'frozen_action_ast_a3/A38_parent_potential_ASTs.json')['directions']
    ast_fields={name:fields(row['density']) for name,row in ast.items()}
    weights={name:sum(CAS[field]*count for field,count in ct.items()) for name,ct in ast_fields.items()}
    assert {n:str(z) for n,z in weights.items()}==tab['carrier_Casimirs']
    print('STAGE literal_raw_bare_action_pullback_in_all35_classes',flush=True)
    expected={key:{} for key in mats};raw_terms=0
    for ib,(row,block) in enumerate(zip(source['block_inputs'],frame['blocks'])):
        n=len(row['sectors']);metrics=list(map(s.Rational,row['metric']))
        values={key:s.SparseMatrix(n,n,{}) for key in ['H','Hpar','Href','Hend','Htotal','TC','D2','Hp']}
        for k,i,j,z in row['raw_H34_sparse']:
            name=slots[k].partition(':')[0];ct=ast_fields[name];ci,cj=[CAS[row['sectors'][q]] for q in [i,j]]
            # Differentiate the literal product of bare parameter/reference/field factors, e^2=0.
            pjet=(s.S.One,-s.Rational(3,2)*weights[name])
            rjet=(s.S.One,s.S.Zero);tjet=(s.S.One,s.S.Zero)
            external=Counter([row['sectors'][i],row['sectors'][j]])
            # Conjugate species can be exchanged by Hessian dual pairing;
            # use paired physical sectors for the actual radial scaling below.
            groups=[(['Phi'],10),(['Sigma','SigmaBar'],s.Rational(25,2)),(['S','SBar'],0)]
            for members,c in groups:
                power=sum(ct[sec]-external[sec] for sec in members);assert power>=0
                for unused in range(power):
                    rjet=dualmul(rjet,(1,alpha*c));tjet=dualmul(tjet,(1,c))
            phi_power=sum(ct[sec]-external[sec] for sec in ['phi','phiBar']);assert phi_power==0
            fjet=dualmul((1,beta*ci),(1,beta*cj));alljet=dualmul(dualmul(pjet,rjet),fjet)
            a=cv[k]*s.sympify(z)/s.sqrt(metrics[i]*metrics[j]);raw_terms+=1
            for key,co in [('H',1),('Hpar',pjet[1]),('Href',rjet[1]),('Hend',fjet[1]),
                           ('Htotal',alljet[1]),('TC',tjet[1]),('D2',(tjet[1]-ci-cj)/2),
                           ('Hp',dualmul(pjet,rjet)[1])]:values[key][i,j]+=co*a
        off=block['offset'];m=block['multiplicity']
        for key,M in values.items():
            M=tidy(M);zero(M-dec(tab['blocks'][key][ib]))
            for a in range(block['dimension']):
                for (i,j),z in M.todok().items():expected[key][off+a*m+i,off+a*m+j]=z
    Q,D,J=map(dec,[frame['Q'],frame['D'],frame['real_conjugation']]);Qi=s.SparseMatrix(328,328,{(i,i):1/D[i,i] for i in range(328)})*Q.H
    for key,entries in expected.items():
        A=s.SparseMatrix(328,328,entries);zero(A.H*D-D*A);zero(A*J-J*A.conjugate())
        zero(mats[key]-Q*A*Qi);zero(mats[key]-mats[key].T);zero(mats[key]-mats[key].conjugate())
    print('STAGE independent_fixed_reference_radial_and_full_Ward_checks',flush=True)
    data=read(PK/'frozen_a10_physical_reconciliation/full_replay.json');v=dec(data['vacuum']['VEV']);O=dec(data['vacuum']['orbit'])
    C=s.diag(*([10]*54+[s.Rational(25,2)]*252+[s.Rational(9,2)]*20+[0]*2));Cv=C*v
    H=mats['H'];TC=mats['TC'];anti=tidy(C*H+H*C);h=tidy(H*Cv)
    zero(H*O);zero(h-dec(tab['h']));zero(xi*h/2-dec(tab['t2']))
    zero(mats['Hp']-mats['Hpar']-mats['Href']);zero(mats['Htotal']-xi*mats['D2'])
    E=s.SparseMatrix(328,3,{})
    for r,(lo,hi) in enumerate([(0,54),(54,306),(326,328)]):
        for i in range(lo,hi):
            if v[i]:E[i,r]=v[i]/point[r]
    radial=tidy(E.T*mats['D2']*E);radial_t=tidy(E.T*h/2)
    target=read(ROOT/'calculations/canonical_so10_radial_uv_kernel/primary_result.json')
    zero(radial-s.Matrix([[s.sympify(z) for z in row] for row in target['D2']]))
    zero(radial_t-s.Matrix([s.sympify(z) for z in target['t2']]))
    zero(radial-dec(tab['radial_D2']));zero(radial_t-dec(tab['radial_t2_without_xi']))
    rhos=[s.SparseMatrix(s.diag(*(dec(data['representation_matrices'][sec][a]) for sec in ['Phi','Sigma','phi','S']))) for a in range(45)]
    T=s.SparseMatrix(328,328,{})
    for lo,hi,charge in [(54,306,2),(306,326,-2),(326,328,-4)]:
        for i in range(lo,hi,2):T[i,i+1]=-charge;T[i+1,i]=charge
    rhos.append(T)
    for T in rhos:
        zero(TC*T*v+H*T*Cv-T*h)
        zero(mats['Hp']*T*v+alpha*H*T*Cv-T*dec(tab['t2']))
        zero(mats['D2']*T*v+H*T*Cv-T*h/2)
    P=dec(json.loads(gzip.decompress((ROOT/'calculations/canonical_so10_quadratic_counterterm_trace/primary_tables.json.gz').read_bytes()))['P'])
    gold=tidy(P*mats['D2']*P);assert gold.todok()
    zero(P*mats['Hp']*P-xi*gold)
    assert tidy(mats['D2']*O).todok() and tidy(mats['D2']*rhos[-1]*v).todok()
    tied=tidy((TC+anti)/2);zero(tied-mats['D2']-anti)
    assert anti.todok() and tidy(mats['Href']).todok() and tidy(mats['Hend']).todok()
    zero(mats['Hp'].subs(xi,1)-mats['D2']+anti)
    # Separate shifted polynomial fixture; coefficients rather than native derivatives.
    a,b,rr,mm,ll=s.symbols('a b r m l',real=True)
    x=rr+a;y=b;V=mm*(x*x+y*y)/2+ll*(x*x+y*y)**2/4
    V=s.expand(V.subs(mm,-ll*rr*rr));VX=s.diff(V,a);VY=s.diff(V,b)
    fixed=s.Poly(s.expand((rr-a)*VX/2-b*VY/2),a,b)
    assert clean(fixed.coeff_monomial(b*b)*2)==ll*rr*rr
    assert fixed.coeff_monomial(a)!=0
    assert tab['controls']['first_stationary_derivative_insensitive']
    assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<4*1024**2
    result={'schema':'C1_SCALAR_QUADRATIC_PULLBACK_VALIDATION_V1','execution_state':'COMPLETED',
            'status':'QUALIFIED_FULL_G2_SCALAR_POTENTIAL_QUADRATIC_PULLBACK',
            'SM_classes':35,'real_fields':328,'parameter_directions':34,'raw_Hessian_terms':raw_terms,
            'positions_compared_per_operator':328**2,'operators_compared':len(mats),
            'support':{n:len(M.todok()) for n,M in mats.items()},
            'all45_plus_PQ_Ward_relations':True,'gauge_Goldstone_projected_potential_CT_nonzero':True,
            'PQ_Goldstone_potential_CT_nonzero':True,'RCP1_all9_radial_curvatures_and3_tadpoles_match':True,
            'trace_insertion_is_Hp_not_D2':True,'tied_reference_error_CH_plus_HC_detected':True,
            'first_stationary_derivative_insensitive':True,'old_loop_inputs_reused_not_remeasured':True,
            'finite_C1_or_E5_or_physical_mass_complete':False,'authority_changed':False,
            'input_bindings':len(prep['input_sha256']),'elapsed_after_imports':time.perf_counter()-tick,
            'external_or_Lean_or_empirical_validation':False,'shared_action_data_software_AI':True}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
