# Next: a compact route to the remaining full scalar-loop counterterm

SMF1 now supplies a complete physical/SM coordinate map and a measured g10^4
point mass-counterterm lift. Do not spend another increment selecting values
for its three blind quartic coefficients or extending radial-only checks.
The current point data cannot determine their global values.

The principal unmeasured potential subtraction input is the full nonradial
second derivative of U0=Tr[V''(phi)^2]/4. SRC1 covers only three external
radials, although all328 internal fields were retained. OFV1 already supplies
the general gauge-width-dependent g10^2 operator and its field/reference/
parameter cancellation; use that proof rather than remeasure its loops.

Recover the existing actual parent third-/fourth-derivative oracles and sparse
tensor data. Determine the least expensive complete contraction for each of
the35 SM multiplicity blocks. For fixed canonical external directions i,j,
the target is U0_ij=Tr[H_i H_j+H H_ij]/2, retaining the true tree zero modes
and both kinetic endpoints. H_i is the fixed-parameter derivative of H=V'',
not the derivative of a stationary family. The corresponding tadpole is
Tr[H H_i]/2. The complexified external pairings require the established
conjugation map. Reuse the complete frame, not a new rank-only identification.

First establish support, dependency order and feasible resource cost from
the existing sparse oracles. Prefer a structural contraction/trace reduction
over a328^4 component grid. Freeze the smallest complete interaction family
and a distinct check before measuring it; if no feasible full contraction
exists, identify the smallest missing tensor map rather than quietly truncate.
An image in a frozen parent space is not obtained by setting quantum targets
to whatever makes closure hold. If the full scalar-loop result admits a
point lift, preserve all invisible coefficients/free directions as in SMF1.

The purpose is to complete the indispensable C1 local subtraction input,
then address finite normalization and the actual two-loop threshold. It is
not full physical quantum control: matter/flavor remains human-paused and
the known Yukawa-dependent higher-order carrier remains unresolved. No
finite scheme, physical vacuum, flavor parameters or E5/HB1/C5 promotion
is implied by this continuation.
