"""Save complete verifier capture before resource or scientific assertions."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CONTROL = Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-sm-frame-v1-2026-10-20')
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
from audit_a10_e5_antighost_vector import resource,line_json

cap = capture([sys.executable,'-B',str(HERE/'verify.py')])
raw = (json.dumps(cap,sort_keys=True,separators=(',',':'))+'\n').encode()
for destination in [HERE/'validation_capture.json',CONTROL/'validation_full_capture.json']:
    with destination.open('xb') as out:
        out.write(raw)
if cap['execution_state'] != 'COMPLETED':
    print(cap['stdout_and_stderr'],flush=True)
resource(cap)
value = line_json(cap['stdout_and_stderr'],'RESULT ')
assert value['elapsed_after_imports'] < 180
with (HERE/'validation_receipt.json').open('xb') as out:
    out.write((json.dumps(value,sort_keys=True,indent=2)+'\n').encode())
print('VALIDATED',value['elapsed_after_imports'],flush=True)
