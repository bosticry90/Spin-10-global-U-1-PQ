"""SMF1 separate forward-embedding/representation and full-matrix verifier.

Does not import the new frame or native pilot. Old tensor representatives and
parent blocks are shared inputs, not independently rederived physical data.
"""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from itertools import combinations
import gzip
import json
import os
import sys
import threading
import time
import sympy as s

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(ROOT/'calculations/canonical_so10_full_hessian'))
sys.path.insert(0,str(ROOT/'calculations/canonical_so10_uv_radial_tadpoles'))
from evaluate_sm_hessian_blocks import rational_representatives
from compile_sm_multiplicity_representatives import RAISING
from inputs import coeffs

@lru_cache(None)
def tidy_scalar(x):return s.cancel(s.expand(x))
def tidy(M):return s.SparseMatrix(M).applyfunc(tidy_scalar)
def matrix(row):return s.SparseMatrix(*row['shape'],{(i,j):s.sympify(z) for i,j,z in row['entries']})
def zero(M):assert not tidy(M).todok()
def inflate(blocks,matrices):
    out={}
    for block,H in zip(blocks,matrices):
        m=block['multiplicity'];off=block['offset']
        for a in range(block['dimension']):
            out.update({(off+a*m+i,off+a*m+j):v for (i,j),v in H.todok().items() if v})
    return s.SparseMatrix(328,328,out)

def main():
    start=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    prep=json.loads((HERE/'validation_preparation.json').read_bytes())
    for name,digest in prep['input_sha256'].items():assert sha256(Path(name).read_bytes()).hexdigest()==digest,name
    natives=[];tables=[]
    for role in ['primary','replay']:
        native=json.loads((HERE/(role+'_result.json')).read_bytes());blob=(HERE/(role+'_tables.json.gz')).read_bytes();raw=gzip.decompress(blob)
        assert sha256(blob).hexdigest()==native['packed_sha256'] and sha256(raw).hexdigest()==native['tables_sha256']
        natives.append(native);tables.append(json.loads(raw))
    assert tables[0]==tables[1]
    tab=tables[0];Q,D,J,seeds=map(matrix,[tab['Q'],tab['D'],tab['real_conjugation'],tab['raw_seeds']]);blocks=tab['blocks']
    slots,cc,degrees,_,point,_=coeffs();assert tab['slots']==slots
    Dinv=s.SparseMatrix(328,328,{(i,i):1/D[i,i] for i in range(328)})
    assert all(D[i,i].is_positive for i in range(328))
    zero(Q.H*Q-D);zero(J-Dinv*Q.H*Q.conjugate());zero(J*J.conjugate()-s.eye(328))
    print('STAGE independent_forward_fields_and_full_kinetic_Gram',flush=True)
    md=json.loads((PK/'frozen_action_ast_a3/A31_embeddings.json').read_bytes())['sectors']
    domains=[('Phi',0,54),('Sigma',54,252),('phi',306,20),('S',326,2)]
    embeddings={};tensor_metrics={}
    for name,lo,n in domains:
        a=md[name];E=s.SparseMatrix(a['ambient_real_dimension'],n,{(i,j):s.sympify(z) for i,j,z in a['embedding_entries']})
        T=s.diag(*map(s.sympify,a['tensor_metric_diagonal']));zero(E.T*T*E-s.eye(n))
        embeddings[name]=E;tensor_metrics[name]=T
    reps=rational_representatives();five=list(combinations(range(10),5));seed=0
    for block in blocks:
        label=tuple(block['label']);off=block['offset'];m=block['multiplicity']
        assert m==len(reps[label])
        for i,(sector,weight,obj) in enumerate(reps[label]):
            info=tab['seed_info'][seed];parent={'SigmaBar':'Sigma','phiBar':'phi','SBar':'S'}.get(sector,sector)
            _,lo,n=next(x for x in domains if x[0]==parent);local=seeds[lo:lo+n,seed]
            assert not seeds[:lo,seed].todok() and not seeds[lo+n:,seed].todok()
            sign=-1 if sector in ['Sigma','phi','S'] else 1
            if parent=='Phi':expected=s.Matrix(list(obj))
            elif parent=='Sigma':expected=s.Matrix([obj.get(idx,0)/2 for idx in five]+[sign*s.I*obj.get(idx,0)/2 for idx in five])
            elif parent=='phi':expected=s.Matrix([z/2 for z in obj]+[sign*s.I*z/2 for z in obj])
            else:expected=s.Matrix([s.Rational(1,2),sign*s.I/2])
            zero(embeddings[parent]*local-expected)
            norm=tidy_scalar((local.H*local)[0]);assert norm==s.sympify(info['metric'])
            zero(Q[:,off+i]-seeds[:,seed]/s.sqrt(norm))
            assert info['weight']==list(weight) and info['sector']==sector
            seed+=1
    assert seed==65 and sum(b['dimension']*b['multiplicity'] for b in blocks)==328
    data=json.loads((PK/'frozen_a10_physical_reconciliation/full_replay.json').read_bytes())
    rhos=[s.SparseMatrix(s.diag(*(matrix(data['representation_matrices'][name][a]) for name,_,_ in domains))) for a in range(45)]
    pairs=list(combinations(range(10),2));orbit=matrix(data['vacuum']['orbit']);v=matrix(data['vacuum']['VEV'])
    zero(s.SparseMatrix.hstack(*(R*v for R in rhos))-orbit)
    for i,info in enumerate(tab['seed_info']):
        for k in range(5):zero(rhos[pairs.index((2*k,2*k+1))]*seeds[:,i]+s.I*info['weight'][k]*seeds[:,i]/s.sqrt(2))
    print('STAGE full_SM_generator_actions_not_only_rank',flush=True)
    for tensor in RAISING:
        R=sum((s.sqrt(2)*tensor[i,j]*rhos[a] for a,(i,j) in enumerate(pairs) if tensor[i,j]),s.SparseMatrix(328,328,{}))
        zero(R*v);zero(R*seeds)
        mapped=tidy(Dinv*Q.H*R*Q)
        valid=set()
        for block in blocks:
            off=block['offset'];m=block['multiplicity'];d=block['dimension']
            for i in range(d):
                for j in range(d):
                    value=mapped[off+i*m,off+j*m]
                    for a in range(m):
                        assert tidy_scalar(mapped[off+i*m+a,off+j*m+a]-value)==0
                        valid.add((off+i*m+a,off+j*m+a))
        assert all((i,j) in valid for i,j in mapped.todok())
    print('STAGE raw34_parent_transport_reality_tree_nullity',flush=True)
    old=json.loads((ROOT/'calculations/canonical_so10_singlet_tadpole/original_v2_result.json').read_bytes())
    rebuilt=[];amp=[point[0]/s.sqrt(60),point[1]/(4*s.sqrt(2)),point[2]/s.sqrt(2)]
    for ib,(row,block) in enumerate(zip(old['block_inputs'],blocks)):
        m=block['multiplicity'];metric=list(map(s.Rational,row['metric']));raw=[s.SparseMatrix(m,m,{}) for _ in slots]
        for k,i,j,z in row['raw_H34_sparse']:raw[k][i,j]=s.sympify(z)
        Bs=[]
        for k,slot in enumerate(slots):
            n=slot.partition(':')[0];f=s.prod(amp[d]**degrees[n][d] for d in range(3))
            H=tidy(s.diag(*(1/s.sqrt(g) for g in metric))*raw[k]*s.diag(*(1/s.sqrt(g) for g in metric))*f)
            zero(H-matrix(tab['parent_blocks'][ib][k]));Bs.append(H)
        rebuilt.append(Bs)
    operators=[inflate(blocks,[Hs[k] for Hs in rebuilt]) for k in range(34)]
    for A in operators:zero(A.H*D-D*A);zero(A*J-J*A.conjugate())
    ps=[]
    for slot in slots:
        n,_,part=slot.partition(':');ps.append(s.im(cc[n]) if part=='im' else s.re(cc[n]))
    tree=tidy(sum((p*A for p,A in zip(ps,operators)),s.SparseMatrix(328,328,{})))
    zero(tree*Dinv*Q.H*orbit)
    pq=s.zeros(328,1)
    for i in range(54,306,2):pq[i]=-2*v[i+1];pq[i+1]=2*v[i]
    pq[326]=4*v[327];pq[327]=-4*v[326]
    zero(tree*Dinv*Q.H*pq)
    print('STAGE independent_all107584_measured_positions_and_lift',flush=True)
    g4=json.loads(gzip.decompress((ROOT/'calculations/canonical_so10_gauge_quartic_hessian/replay_tables.json.gz').read_bytes()))
    H4=s.SparseMatrix(*g4['H_shape'],{(i,j):s.sympify(z) for i,j,z in g4['H']})
    t4=s.SparseMatrix(*g4['gradient_shape'],{(i,j):s.sympify(z) for i,j,z in g4['gradient']})
    Y=tidy(Q.H*H4*Q);K=[matrix(row) for row in tab['gauge_blocks']]
    zero(Y-D*inflate(blocks,K));zero(H4*v/3-t4)
    assert tidy_scalar((v.T*H4*v)[0]/12-s.sympify(g4['potential']))==0
    # Rebuild all unit-coordinate rows without sharing the native equation builder.
    allowed=['lambdaPhi1','lambdaPhi2','lambdaSigma1','lambdaSigma2','lambdaSigma3','lambdaSigma4','lambdaPhiVector1','lambdaPhiVector2','lambdaPhiSigma1','lambdaPhiSigma2','lambdaPhiphi1','lambdaPhiphi2','lambdaSigmaphi1','lambdaSigmaphi2']
    assert tab['allowed']==allowed
    ks=[slots.index(name) for name in allowed];eq=[]
    for bs,target in zip(rebuilt,K):
        for i in range(target.rows):
            for j in range(target.cols):
                z=[bs[k][i,j] for k in ks]+[target[i,j]]
                for part in [s.re,s.im]:
                    row=tuple(tidy_scalar(part(x)) for x in z)
                    if any(row):eq.append(row)
    M=s.Matrix([row[:-1] for row in eq]);r=s.Matrix([row[-1] for row in eq]);rank=M.rank();aug=M.row_join(r).rank()
    assert all(n['rank']==rank and n['augmented_rank']==aug for n in natives)
    null=M.nullspace();assert len(null)==14-rank==len(tab['kernel'])
    for z,row in zip(null,tab['kernel']):zero(z-s.Matrix(list(map(s.sympify,row))))
    cs=s.symbols('c0:14',real=True);env=dict(zip(map(str,cs),cs));sol=s.linsolve((M,r),*cs)
    if tab['lift'] is None:assert sol==s.EmptySet and aug>rank
    else:
        lift=s.Matrix([s.sympify(x,locals=env) for x in tab['lift']]);zero(M*lift-r)
        zero(lift-s.Matrix(next(iter(sol))))
        A=tidy(sum((p*operators[k] for p,k in zip(lift,ks)),s.SparseMatrix(328,328,{})))
        zero(A-Dinv*Y)
    # Norm/rank can miss the wrong holomorphic orientation.
    wrong_index=next(i for i,x in enumerate(tab['seed_info']) if x['sector']=='SigmaBar' and all(x['weight']))
    bad=seeds[:,wrong_index].copy()
    for i in range(55,306,2):bad[i,0]*=-1
    assert tidy_scalar((bad.H*bad-seeds[:,wrong_index].H*seeds[:,wrong_index])[0])==0
    assert tidy(embeddings['Sigma']*(bad[54:306,:]-seeds[54:306,wrong_index])).todok()
    weight_detected=any(tidy(rhos[pairs.index((2*k,2*k+1))]*bad+s.I*tab['seed_info'][wrong_index]['weight'][k]*bad/s.sqrt(2)).todok() for k in range(5))
    assert weight_detected
    phi_index=next(i for i,x in enumerate(tab['seed_info']) if x['sector']=='phi')
    local=seeds[306:326,phi_index];E=embeddings['phi'];wrong=E.T*(E*local)
    zero(wrong-local/2);assert tidy_scalar((wrong.H*wrong)[0]-(local.H*local)[0])!=0
    package_bytes=sum(p.stat().st_size for p in HERE.iterdir() if p.is_file());assert package_bytes<4*1024**2
    result={'schema':'C1_GS_COMPLETE_SCALAR_SM_FRAME_VALIDATION_V1','execution_state':'COMPLETED',
            'status':'QUALIFIED_FRAME_AND_POINT_LIFT' if tab['lift'] is not None else 'QUALIFIED_FRAME_NO_POINT_LIFT',
            'frame_dimension':328,'SM_classes':35,'highest_directions':65,'parent_directions':34,
            'full_GQH_positions':328**2,'actual_SM_lowering_and_weight_checks':True,
            'all34_parent_reality_and_metric_checks':True,'tree_gauge_and_PQ_nullity':True,
            'point_lift':tab['lift'],'allowed':allowed,'rank':rank,'augmented_rank':aug,'kernel_dimension':len(null),
            'phase_error_preserves_norm_but_fails_forward_and_weight_maps':True,
            'wrong_tensor_metric_rejected':True,'global_quartic_identity':False,
            'finite_C1_E5_or_whole_goal_completed':False,'authority_changed':False,
            'package_bytes_before_receipt_and_report':package_bytes,'elapsed_after_imports':time.perf_counter()-start,
            'input_bindings':len(prep['input_sha256']),'shared_inputs_software_and_AI_authorship':True}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
