"""Freeze SMF1 sources, inherited qualified inputs and old tree before calculation."""
from pathlib import Path
from hashlib import sha256
import json
import subprocess

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-sm-frame-v1-2026-10-20')
BASE='6e653571265757ebbd21ed02086dcc2c7a6ea473'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT).decode().strip()=='main'
prior=json.loads((ROOT/'calculations/canonical_so10_radial_uv_kernel/validation_preparation.json').read_bytes())
for name,digest in prior['input_sha256'].items():assert sha256(Path(name).read_bytes()).hexdigest()==digest,name
CONTROL.mkdir(parents=True,exist_ok=False)
files=list(map(Path,prior['input_sha256']))
files.extend(p for p in (ROOT/'calculations/canonical_so10_radial_uv_kernel').iterdir() if p.is_file())
files.extend((ROOT/'calculations/canonical_so10_full_hessian').glob('*.py'))
files.extend([ROOT/'AGENTS.md',ROOT/'project_state.json',ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V385.md'])
PK=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
files.extend([PK/'frozen_action_ast_a3/A31_embeddings.json',PK/'frozen_action_ast_a3/A38_parent_potential_ASTs.json',
              PK/'frozen_a10_physical_reconciliation/full_primary.json',PK/'frozen_a10_physical_reconciliation/full_replay.json',
              ROOT/'calculations/canonical_so10_singlet_tadpole/original_v2_result.json',
              ROOT/'calculations/canonical_so10_gauge_quartic_hessian/primary_tables.json.gz',
              ROOT/'calculations/canonical_so10_gauge_quartic_hessian/replay_tables.json.gz'])
for path in list(HERE.iterdir()):
    if path.suffix in ['.py','.md']:
        if path.suffix=='.py':compile(path.read_bytes(),str(path),'exec')
        with (HERE/(path.name+'.source.txt')).open('xb') as out:out.write(path.read_bytes())
files.extend(HERE.iterdir())
tree=subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT);assert len(tree.splitlines())==24849
with (CONTROL/'old_git_tree.txt').open('xb') as out:out.write(tree)
files.append(CONTROL/'old_git_tree.txt')
value={'schema':'C1_GS_SCALAR_SM_FRAME_PREPARATION_V1','base_commit':BASE,'old_git_blobs':24849,
       'input_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in sorted(set(files))},
       'native_after_imports_seconds':120,'verifier_after_imports_seconds':180,
       'arithmetic':'EXACT_SYMBOLIC','sampled_private_limit':8*1024**3,
       'launch_floor_bytes':350*1024**2,'package_limit':4*1024**2}
with (HERE/'preparation.json').open('xb') as out:out.write((json.dumps(value,sort_keys=True,indent=2)+'\n').encode())
print('FROZEN',len(value['input_sha256']),'bindings',24849,'old blobs',flush=True)
