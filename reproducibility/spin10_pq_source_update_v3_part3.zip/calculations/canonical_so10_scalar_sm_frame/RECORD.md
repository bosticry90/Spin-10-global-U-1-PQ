# SMF1 — complete physical scalar/SM frame and point counterterm lift

Prospective at6e653571265757ebbd21ed02086dcc2c7a6ea473/main,2026-10-20.
Previous goal turn PROGRESS: SRC1/RCP1 completed; no E5/C1 promotion.
Preflight clean/no matching live workers/452 byte bindings only. Question:
can the actual canonical328-real scalar carrier be mapped faithfully to the
35 SM multiplicity blocks so the measured GQH1 counterterm can be projected
and lifted to the existing parent coefficient space at the frozen point?

Inputs: A31 embeddings/tensor metrics, actual normalized45-plane-generator
scalar representations, rational SM highest-weight tensor representatives,
V81 exact raw34 block Hessians/metrics and actual parent/POINT coefficients,
GQH1 measured328x328 Hessian/tadpole and current BFT1 physical conventions.
These are the same physical parent fields. No formal E1/source action or
historical failed-A10 action is adopted. Existing action/representation and
SM-character qualifications are reused, not independently validated anew.

## Frozen map and scope

Let E_R embed canonical real sector coordinates in ambient tensor components
and T_R be the tensor kinetic metric. Check E_R^T T_R E_R=I. Primary converts
the old ComplexTangent=A+iB into ambient real components and applies
E_R^T T_R separately to A,B, checking exact forward reconstruction. Replay
uses explicit components: Phi off-diagonal sqrt2*Phi_ij and standard traceless
diagonal coordinates; Sigma/phi complexified holomorphic coordinates
(F/sqrt2,-iF/sqrt2), antiholomorphic(F/sqrt2,+iF/sqrt2); singlets similarly.
Sigma uses the declared half-five-form coordinates and exact Hodge image.
Thus conjugation and kinetic normalization, not field names alone, are tested.

Check all65 highest directions, their full five-Cartan weights and the three
SM raising operators. Normalize their kinetic Gram matrices. Generate all
lower-weight states using the actual three compact lowering matrices and
exact Gram-Schmidt common to each multiplicity copy. No truncation is allowed:
the required35-block dimension/multiplicity census is328. The full kinetic
Gram must be positive diagonal. The construction gives an invertible complete
complexified frame Q with its exact real-field conjugation map, not328
independent complex physical particles. Highest-weight/rank checks alone do
not qualify the map.

Parent-Hessian transport is by the linear coordinate chain rule. The fixed
parent tensor polynomial restricted through E_R is the declared canonical
parent action. Since E_R u reconstructs each old tensor tangent, its polarized
second derivative equals u^T Hcanonical v. H invariance at the actual VEV
and the complete lowering frame extend the supplied multiplicity blocks to
all states. Preserve both kinetic endpoints and actual VEV amplitude factors
in all34 real coefficient directions. This transports the already qualified
609 nonzero raw Hessian entries/implicit zeros; it does NOT newly evaluate
every original parent tensor contraction or certify a changed action.

Check D-Hermiticity and real-conjugation compatibility of all34 full-frame
coefficient operators. The actual point tree Hessian must annihilate the
independently constructed45 gauge orbits and global PQ tangent. Project the
measured GQH1 full matrix with Q and check the full328x328 transformed operator
against its35 multiplicity blocks, including all implicit cross-block zeros.

## Frozen admissible point lift

The g10^4 pure-gauge potential is independent of S and separately invariant
under Sigma and phi rephasings. Before solving freeze exactly these14 real
quartic directions: lambdaPhi1,lambdaPhi2; lambdaSigma1..4;
lambdaPhiVector1,lambdaPhiVector2; lambdaPhiSigma1,lambdaPhiSigma2;
lambdaPhiphi1,lambdaPhiphi2; lambdaSigmaphi1,lambdaSigmaphi2.
Mass/cubic, S-containing and phase-charged directions are excluded by that
operator's homogeneous degree and field/rephasing structure, not by fit.

Primary solves the measured raw active-frame blocks against these frozen
parent columns. Replay solves in unit kinetic coordinates. Keep the entire
exact affine solution family and rank/kernel, or an exact no-image result.
Do not choose invisible coefficients to zero. Pure10 quartics are invisible
to the point Hessian at zero10 VEV; further invisible combinations may occur.
An image proves only the point Hessian/tadpole slice can be lifted, not a
global quartic identity. Quartic Euler homogeneity checks the full measured
tadpole/value from the matched Hessian. One-loop cubic/quartic CTs inside
two-loop skeletons are orderhbar^3; the point deltaK is the required hbar^2
potential insertion, but this does not close other CTs or finite conditions.

Native routes share the lowering/trace/linear-algebra engine but use distinct
coordinate inverses and raw/unit lift equations. The verifier imports no
new native helper: check ambient forward fields/conjugate orientation,
complete kinetic Gram, reality/coefficient transport, gauge/PQ nullity,
measured full operator projection and every lift equation. A deliberate
SigmaBar phase error must retain its norm but fail its field/weight map;
metric-only/rank-only checks are insufficient. No old expensive loop replay.

Possible outcomes: qualified full frame plus point lift; qualified frame but
no-image/underdefined lift; coordinate/action discrepancy; bounded incomplete.
Map failure stops dependent projection. Native120s/verifier180s AFTER imports,
8GiB sampled private NOTpeak,350MiB launch floor,4MiB package. Exact arithmetic;
freeze all input/code/controller/proof bytes before execution. Full captures
before assertions; preserve failures and do not silently extend resources or
scientific requirements. Compact owned gzip tables only, no old-file changes.

This supports the full C1 counterterm dependency, not another radial-only
identity. Shared action/embeddings/oracles/software/AI author remain; no
external, Lean or experimental validation. No state/action/point/source/
partialGamma/policy/scheme/main/remote/publication changes. State113/34of39,
E5/A5unqualified,HB1/C5blocked,flavorpaused,C1_GSuncalculated,quartetfailure,
custodyexit2/seven and physical quantum-control/matching warnings unchanged.
