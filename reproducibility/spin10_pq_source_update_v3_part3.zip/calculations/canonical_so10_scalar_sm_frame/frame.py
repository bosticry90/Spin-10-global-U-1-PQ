"""SMF1 exact coordinate maps and complete compact-SM lowering frame."""
from pathlib import Path
from itertools import combinations
from functools import lru_cache
import json
import sympy as s

ROOT=Path(__file__).resolve().parents[2]
PACKET=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
SECTORS=[('Phi',0,54),('Sigma',54,252),('phi',306,20),('S',326,2)]
FIVE=list(combinations(range(10),5));HALF=[idx for idx in FIVE if idx<tuple(i for i in range(10) if i not in idx)]
PAIRS=list(combinations(range(10),2))
@lru_cache(None)
def parse(value):return s.sympify(value)
@lru_cache(None)
def clean(value):return s.cancel(s.expand(value))
def tidy(M):return s.SparseMatrix(M).applyfunc(clean)
def mat(row):return s.SparseMatrix(*row['shape'],{(i,j):parse(z) for i,j,z in row['entries']})
def entries(M):return [[i,j,str(value)] for (i,j),value in sorted(M.todok().items()) if value]
def zero(M):assert not tidy(M).todok()

def ambient_state(state,sector):
    if sector=='Phi':return s.Matrix(list(state.Phi))
    if sector in ['Sigma','SigmaBar']:
        return s.Matrix([state.Sigma.get(idx,(0,0))[part] for part in [0,1] for idx in FIVE])
    if sector in ['phi','phiBar']:
        return s.Matrix([s.re(value) if part==0 else s.im(value) for part in [0,1] for value in state.phi])
    return s.Matrix([s.re(state.S),s.im(state.S)])

def ambient_complex(sector,obj):
    if sector=='Phi':return s.Matrix(list(obj))
    sign=-1 if sector in ['Sigma','phi','S'] else 1
    if sector in ['Sigma','SigmaBar']:
        return s.Matrix([obj.get(idx,0)/2 for idx in FIVE]+[sign*s.I*obj.get(idx,0)/2 for idx in FIVE])
    if sector in ['phi','phiBar']:return s.Matrix([value/2 for value in obj]+[sign*s.I*value/2 for value in obj])
    return s.Matrix([s.Rational(1,2),sign*s.I/2])

def direct_coordinates(sector,obj):
    if sector=='Phi':
        values=[s.sqrt(2)*obj[i,j] for i,j in PAIRS]
        values.extend((sum(obj[i,i] for i in range(k))-k*obj[k,k])/s.sqrt(k*(k+1)) for k in range(1,10))
        return s.Matrix(values)
    sign=-1 if sector in ['Sigma','phi','S'] else 1
    if sector in ['Sigma','SigmaBar']:
        return s.Matrix([value for idx in HALF for value in [obj.get(idx,0)/s.sqrt(2),sign*s.I*obj.get(idx,0)/s.sqrt(2)]])
    if sector in ['phi','phiBar']:
        return s.Matrix([value for z in obj for value in [z/s.sqrt(2),sign*s.I*z/s.sqrt(2)]])
    return s.Matrix([1/s.sqrt(2),sign*s.I/s.sqrt(2)])

def build(role,representatives,realified,kinetic,raising,point):
    data=json.loads((PACKET/('frozen_a10_physical_reconciliation/full_'+role+'.json')).read_bytes())
    metadata=json.loads((PACKET/'frozen_action_ast_a3/A31_embeddings.json').read_bytes())['sectors']
    embeddings={};duals={}
    for sector,_,size in SECTORS:
        row=metadata[sector];E=s.SparseMatrix(row['ambient_real_dimension'],size,{(i,j):parse(value) for i,j,value in row['embedding_entries']})
        T=s.SparseMatrix(E.rows,E.rows,{(i,i):parse(value) for i,value in enumerate(row['tensor_metric_diagonal'])})
        zero(E.T*T*E-s.eye(size));embeddings[sector]=E;duals[sector]=E.T*T
    rhos=[s.SparseMatrix(s.diag(*(mat(data['representation_matrices'][sector][a]) for sector,_,_ in SECTORS))) for a in range(45)]
    v=mat(data['vacuum']['VEV']);O=tidy(s.SparseMatrix.hstack(*(rho*v for rho in rhos)))
    zero(O-mat(data['vacuum']['orbit']))
    cartans=[rhos[PAIRS.index((2*k,2*k+1))] for k in range(5)]
    roots=[]
    for tensor in raising:
        generator=s.SparseMatrix(328,328,{})
        for a,(i,j) in enumerate(PAIRS):
            if tensor[i,j]:generator+=s.sqrt(2)*tensor[i,j]*rhos[a]
        roots.append(tidy(generator))
    lowers=[tidy(root.H) for root in roots]
    for generator in roots+lowers:zero(generator*v)
    old=json.loads((ROOT/'calculations/canonical_so10_singlet_tadpole/original_v2_result.json').read_bytes())
    raw_seeds=[];seed_info=[];blocks=[];all_columns=[];all_norms=[];seed_offset=0;offset=0
    for row in old['block_inputs']:
        label=tuple(row['label']);reps=representatives[label];m=len(reps);dimension=int(row['dimension'])
        assert [sector for sector,_,_ in reps]==row['sectors']
        expected_dim=(label[0]+1)*(label[1]+1)*(label[0]+label[1]+2)//2*(label[2]+1)
        assert dimension==expected_dim
        columns=[];metrics=[];active_metrics=[];amplitudes=[]
        for i,(sector,weight,obj) in enumerate(reps):
            parent='Sigma' if sector=='SigmaBar' else 'phi' if sector=='phiBar' else 'S' if sector=='SBar' else sector
            if role=='primary':
                tangent=realified(sector,obj)
                ambient=ambient_state(tangent.real,sector)+s.I*ambient_state(tangent.imag,sector)
                local=tidy(duals[parent]*ambient)
            else:local=tidy(direct_coordinates(sector,obj))
            zero(embeddings[parent]*local-ambient_complex(sector,obj))
            g0=clean(2*kinetic(obj,obj,'matrix') if parent=='Phi' else kinetic(obj,obj,'form') if parent=='Sigma' else kinetic(obj,obj,'vector') if parent=='phi' else s.S.One)
            assert g0.is_positive and clean((local.H*local)[0]-g0)==0
            amp=point[0]/s.sqrt(60) if parent=='Phi' else point[1]/(4*s.sqrt(2)) if parent=='Sigma' else point[2]/s.sqrt(2) if parent=='S' else s.S.One
            metric=clean(g0*amp*amp);assert metric==s.Rational(row['metric'][i])
            global_vec=s.SparseMatrix(328,1,{})
            start=next(lo for name,lo,_ in SECTORS if name==parent)
            for (j,_),value in local.todok().items():global_vec[start+j,0]=value
            for k,cartan in enumerate(cartans):zero(cartan*global_vec+s.I*weight[k]*global_vec/s.sqrt(2))
            for root in roots:zero(root*global_vec)
            raw_seeds.append(global_vec)
            seed_info.append({'sector':sector,'weight':list(weight),'label':list(label),'index_in_block':i,'metric':str(g0),'active_metric':str(metric),'amplitude':str(amp)})
            columns.append(global_vec/s.sqrt(g0));metrics.append(g0);active_metrics.append(metric);amplitudes.append(amp)
        U=tidy(s.SparseMatrix.hstack(*columns));zero(U.H*U-s.eye(m))
        states=[U];norms=[s.S.One];cursor=0
        while cursor<len(states):
            for lower in lowers:
                Z=lower*states[cursor]
                for previous,norm in zip(states,norms):
                    coefficient=clean((previous[:,0].H*Z[:,0])[0]/norm)
                    if coefficient:Z-=coefficient*previous
                Z=tidy(Z);norm=clean((Z[:,0].H*Z[:,0])[0])
                if norm==0:zero(Z);continue
                assert norm.is_positive
                zero(Z.H*Z-norm*s.eye(m))
                states.append(Z);norms.append(norm)
                assert len(states)<=dimension,(label,len(states),dimension)
            cursor+=1
        assert len(states)==dimension,(label,len(states),dimension)
        for state,norm in zip(states,norms):
            all_columns.extend(state[:,j] for j in range(m));all_norms.extend([norm]*m)
        blocks.append({'label':list(label),'dimension':dimension,'multiplicity':m,'offset':offset,'seed_offset':seed_offset,
                       'state_norms':list(map(str,norms)),'active_metrics':list(map(str,active_metrics)),
                       'metric_raw':list(map(str,metrics)),'amplitudes':list(map(str,amplitudes))})
        offset+=dimension*m;seed_offset+=m
    assert offset==328 and seed_offset==65 and len(blocks)==35
    Q=tidy(s.SparseMatrix.hstack(*all_columns));D=s.SparseMatrix(s.diag(*all_norms))
    zero(Q.H*Q-D)
    J=tidy(s.SparseMatrix(s.diag(*(1/n for n in all_norms)))*Q.H*Q.conjugate())
    zero(J*J.conjugate()-s.eye(328))
    return {'data':data,'old':old,'Q':Q,'D':D,'norms':all_norms,'reality':J,'seeds':tidy(s.SparseMatrix.hstack(*raw_seeds)),
            'seed_info':seed_info,'blocks':blocks,'rhos':rhos,'roots':roots,'cartans':cartans,'v':v,'orbit':O,'embeddings':embeddings}
