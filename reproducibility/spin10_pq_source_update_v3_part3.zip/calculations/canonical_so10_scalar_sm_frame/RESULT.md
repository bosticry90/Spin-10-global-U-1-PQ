# SMF1 — complete scalar/SM frame and gauge-quartic point lift

Two frozen native routes and a separately implemented verifier completed at
base `6e653571265757ebbd21ed02086dcc2c7a6ea473` on main. The result qualifies
the complete kinetic coordinate map needed for the physical C1 scalar
counterterm projection and a point-level parent lift of the measured GQH1
gauge-quartic Hessian. It does not evaluate a new loop integral.

## Coordinate and action checks

The 65 highest-weight directions in 35 SM classes generate a complete
328-dimensional complexification of the existing 328-real-field scalar
carrier. These are not 328 independent complex physical fields. With Q the
complete frame and D its positive diagonal kinetic Gram matrix, the exact
checks give Q†Q=D and the real-field conjugation J=D^-1 Q†conjugate(Q), with
J conjugate(J)=I. The actual SM raising/lowering operators act consistently
on every multiplicity copy; this is more than a dimension or rank check.

Primary converts the inherited realified tensor tangents using the weighted
A31 embedding inverse. Replay uses explicit traceless-symmetric, five-form,
vector and singlet component formulas, including opposite holomorphic and
antiholomorphic phase signs. Both reconstruct all original ambient tensor
fields. The verifier imports neither new native helper and checks those
forward fields, all Cartan weights, the full kinetic Gram and full SM
generator actions independently of the lowering construction.

All 34 inherited parent Hessian coefficient directions retain their two
kinetic endpoints and VEV amplitude factors. Their complete frame operators
satisfy D-Hermiticity and the real-conjugation condition. The actual point
tree Hessian annihilates the independently constructed 45 gauge orbits and
global PQ tangent. Parent-Hessian transport uses the linear coordinate chain
rule and inherited H invariance/raw block qualifications. The 609 raw
nonzero block entries and their zeros are transported, not remeasured by
fresh evaluation of every original parent tensor contraction.

The measured GQH1 canonical matrix is projected with the complete Q. All
107,584 transformed positions agree with its 35 multiplicity blocks and
implicit cross-state/cross-class zeros. Quartic Euler homogeneity also
reproduces the measured full gradient and potential value from that Hessian.

## Parent quartic family at the frozen point

The allowed 14 directions were frozen before solving, using homogeneous
quartic degree, S independence and separate Sigma/phi rephasing invariance
of 3 Tr[G(phi)^2]/4. In units
`L*g10^4`, where `L=hbar/(16*pi^2*epsilon_UV)`, the complete point-lift family is:

| Parent coefficient | Counterterm coefficient |
| --- | --- |
| lambdaPhi1 | 9/4 |
| lambdaPhi2 | 15/2 |
| lambdaSigma1 | 135/16 |
| lambdaSigma2 | -3 |
| lambdaSigma3 | 3/2 |
| lambdaSigma4 | -3/8 |
| lambdaPhiVector1 | u |
| lambdaPhiVector2 | v |
| lambdaPhiSigma1 | 9/2 |
| lambdaPhiSigma2 | 3 |
| lambdaPhiphi1 | 123/80 - z/100 |
| lambdaPhiphi2 | 15 |
| lambdaSigmaphi1 | z |
| lambdaSigmaphi2 | 0 |

Here u, v and z remain arbitrary real coefficients; no value is adopted.
Both raw active-frame and unit-kinetic-coordinate systems have rank11 and
augmented rank11, with a three-dimensional kernel. The verifier reconstructs
all equations and the entire solution family. The resulting full operator,
not just selected eigenvalues or radial entries, equals the measured matrix.

The two pure-10 quartics have zero point Hessians because the 10 has zero
VEV. A further mixed-portal combination is invisible at these particular
VEV norms. Neither invisibility makes its global coefficient zero. This
point Hessian/tadpole lift is NOT a global quartic polynomial identity.
It is sufficient to identify this measured point quadratic insertion; it
does not close the remaining scalar-loop or finite counterterm inputs.

## Error sensitivity, execution and limits

Flipping the SigmaBar imaginary-coordinate signs preserves its norm but
fails both the ambient field map and actual Cartan weights. Omitting the
factor2 tensor metric for a phi representative halves its coordinates and
changes its norm. Both controls are rejected. Singlet conjugation is checked
through the full field/coefficient reality maps rather than a zero-weight
Cartan test alone. Agreement between native routes is limited by their
shared lowering/linear-algebra engine, old action/representatives/raw
Hessians, measured gauge matrix, software and AI author. The separate verifier
does not remove those shared physical premises. No external, Lean or
experimental validation is claimed.

Execution order is `python -B` on prepare.py, run.py,
prepare_validation.py and run_validation.py in this directory. Native and
validation preparations bind 1,350 and 1,357 inputs. Times after imports:
40.8955826s primary, 37.5292763s replay, 38.7451648s verifier. Zero failed
native/verifier executions. Full captures contain 21/20/20 private-memory
samples, largest77,946,880 bytes across the three workers, NOT a measured
peak. Frozen caps remain120s native/180s verifier after imports,8GiB sampled,
350MiB launch floor and4MiB package. Sources were frozen before calculation;
old expensive loop calculations were not repeated. Read-only navigation
mistakes encountered during recovery did not alter scientific inputs.

Both native tables have decompressed SHA256
`351c83b40bd0a2030ed4b80c98707b72f98a9a239194394be994172b183c2582`
and gzip SHA256
`35e2eda14575462d9f655a77818727a5fb7d1fee50bea840574fdc120c202924`.
Completed validation_receipt.json SHA256:
`f0769e62ca8a2f17895a636b48c9138ae0269f6ec957559df187bd46313faf3c`.

No earlier action, point, source functional, evidence, scheme, policy or
scientific authority changed. State113/34of39, E5/A5unqualified, HB1/C5blocked,
flavorpaused, finite C1_GSuncalculated, quartetFAIL3960/648 and custodyexit2/
seven remain. Scalar140%/1.94%/20.27% diagnostics, matching residual.745476
and missing Yukawa inputs remain distinct physical limitations. The latest
director references remain at their already recorded V367 scopes: AI
interpretability WATCH and future RHN/B-L/PQ/defect/GW work, not activation.
The whole Spin(10)xPQ investigation remains active and incomplete.
