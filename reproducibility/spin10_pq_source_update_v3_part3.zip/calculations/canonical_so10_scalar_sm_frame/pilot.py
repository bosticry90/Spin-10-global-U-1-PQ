"""SMF1 complete kinetic frame, transported parent Hessians and measured point lift."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import gzip
import json
import os
import sys
import threading
import time
import sympy as s

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'calculations/canonical_so10_full_hessian'))
sys.path.insert(0,str(ROOT/'calculations/canonical_so10_uv_radial_tadpoles'))
from evaluate_sm_hessian_blocks import rational_representatives,realified_representative
from compile_sm_multiplicity_representatives import kinetic_inner,RAISING
from inputs import coeffs
from frame import build,clean,tidy,zero,entries

ALLOWED=['lambdaPhi1','lambdaPhi2','lambdaSigma1','lambdaSigma2','lambdaSigma3','lambdaSigma4',
         'lambdaPhiVector1','lambdaPhiVector2','lambdaPhiSigma1','lambdaPhiSigma2',
         'lambdaPhiphi1','lambdaPhiphi2','lambdaSigmaphi1','lambdaSigmaphi2']
def enc(M):return {'shape':list(M.shape),'entries':entries(M)}
def scalar_parts(z):
    a,b=s.expand(z).as_real_imag();return [clean(a),clean(b)]
def expand_blocks(blocks,values):
    data={}
    for block,V in zip(blocks,values):
        offset=block['offset'];m=block['multiplicity']
        for k in range(block['dimension']):
            for (i,j),v in V.todok().items():
                if v:data[offset+k*m+i,offset+k*m+j]=v
    return s.SparseMatrix(328,328,data)

def main():
    start=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    prep=json.loads((HERE/'preparation.json').read_bytes())
    for name,digest in prep['input_sha256'].items():assert sha256(Path(name).read_bytes()).hexdigest()==digest,name
    role=sys.argv[1];assert role in ['primary','replay']
    slots,cc,degrees,_,point,_=coeffs()
    print('STAGE exact_representatives_and_complete_frame',flush=True)
    F=build(role,rational_representatives(),realified_representative,kinetic_inner,RAISING,point)
    Q,D,J=F['Q'],F['D'],F['reality'];blocks=F['blocks'];old=F['old']
    Dinv=s.SparseMatrix(s.diag(*(1/n for n in F['norms'])))
    print('STAGE transport_all34_parent_Hessians',flush=True)
    parent=[];raw_blocks=[];vfacs=[]
    for row,block in zip(old['block_inputs'],blocks):
        m=block['multiplicity'];raw=[s.SparseMatrix(m,m,{}) for _ in slots]
        for k,i,j,z in row['raw_H34_sparse']:raw[k][i,j]=s.sympify(z)
        metrics=list(map(s.sympify,block['active_metrics']))
        factors=[];Hs=[]
        for k,slot in enumerate(slots):
            name=slot.partition(':')[0];deg=degrees[name]
            factor=clean(s.prod((point[d]/[s.sqrt(60),4*s.sqrt(2),s.sqrt(2)][d])**deg[d] for d in range(3)))
            factors.append(factor)
            H=tidy(s.SparseMatrix(m,m,{(i,j):clean(factor*z/s.sqrt(metrics[i]*metrics[j])) for (i,j),z in raw[k].todok().items()}))
            Hs.append(H)
        parent.append(Hs);raw_blocks.append(raw);vfacs.append(factors)
    operators=[expand_blocks(blocks,[row[k] for row in parent]) for k in range(len(slots))]
    for A in operators:
        zero(A.H*D-D*A);zero(A*J-J*A.conjugate())
    physical=[]
    for slot in slots:
        name,sep,part=slot.partition(':');value=cc[name]
        physical.append(clean(s.im(value) if part=='im' else s.re(value)))
    tree=tidy(sum((p*A for p,A in zip(physical,operators)),s.SparseMatrix(328,328,{})))
    zero(tree*(Dinv*Q.H*F['orbit']))
    pq=s.SparseMatrix(328,1,{})
    for i in range(54,306,2):pq[i,0]=-2*F['v'][i+1,0];pq[i+1,0]=2*F['v'][i,0]
    pq[326,0]=4*F['v'][327,0];pq[327,0]=-4*F['v'][326,0]
    zero(tree*(Dinv*Q.H*pq))
    print('STAGE full_measured_gauge_quartic_projection',flush=True)
    measured=json.loads(gzip.decompress((ROOT/'calculations/canonical_so10_gauge_quartic_hessian/primary_tables.json.gz').read_bytes()))
    H4=s.SparseMatrix(*measured['H_shape'],{(i,j):s.sympify(z) for i,j,z in measured['H']})
    gradient=s.SparseMatrix(*measured['gradient_shape'],{(i,j):s.sympify(z) for i,j,z in measured['gradient']})
    Y=tidy(Q.H*H4*Q);gauge_blocks=[];expected={}
    for block in blocks:
        off=block['offset'];m=block['multiplicity'];K=tidy(Y[off:off+m,off:off+m]);gauge_blocks.append(K)
        for k,norm in enumerate(map(s.sympify,block['state_norms'])):
            for (i,j),value in K.todok().items():expected[off+k*m+i,off+k*m+j]=clean(norm*value)
    zero(Y-s.SparseMatrix(328,328,expected))
    zero(H4*F['v']/3-gradient)
    assert clean((F['v'].T*H4*F['v'])[0]/12-s.sympify(measured['potential']))==0
    print('STAGE frozen14_quartic_point_lift',flush=True)
    indices=[slots.index(name) for name in ALLOWED];equations=set()
    for ib,(block,K) in enumerate(zip(blocks,gauge_blocks)):
        m=block['multiplicity'];metrics=list(map(s.sympify,block['active_metrics']))
        for i in range(m):
            for j in range(m):
                if role=='primary':
                    cols=[vfacs[ib][k]*raw_blocks[ib][k][i,j] for k in indices]
                    target=clean(s.sqrt(metrics[i]*metrics[j])*K[i,j])
                else:cols=[parent[ib][k][i,j] for k in indices];target=K[i,j]
                parts=[scalar_parts(z) for z in cols+[target]]
                for reim in range(2):
                    row=tuple(v[reim] for v in parts)
                    if any(row):equations.add(row)
    rows=sorted(equations,key=str);A=s.Matrix([r[:-1] for r in rows]);b=s.Matrix([r[-1] for r in rows])
    cs=s.symbols('c0:14',real=True);rank=A.rank();aug=A.row_join(b).rank()
    solution=s.linsolve((A,b),*cs);lift=None;kernel=A.nullspace()
    if solution is not s.EmptySet and solution!=s.EmptySet:
        lift=tuple(clean(value) for value in next(iter(solution)))
        candidate=tidy(sum((value*operators[k] for value,k in zip(lift,indices)),s.SparseMatrix(328,328,{})))
        zero(candidate-Dinv*Y)
    blind=[name for k,name in enumerate(ALLOWED) if not any(A[:,k])]
    assert 'lambdaPhiVector1' in blind and 'lambdaPhiVector2' in blind
    tables={
        'schema':'C1_GS_COMPLETE_SCALAR_SM_FRAME_TABLES_V1','Q':enc(Q),'D':enc(D),'real_conjugation':enc(J),
        'raw_seeds':enc(F['seeds']),'seed_info':F['seed_info'],'blocks':blocks,'slots':slots,
        'parent_blocks':[[enc(H) for H in row] for row in parent],
        'gauge_blocks':[enc(H) for H in gauge_blocks],
        'allowed':ALLOWED,'lift':None if lift is None else list(map(str,lift)),
        'kernel':[list(map(str,vec)) for vec in kernel],
    }
    raw=json.dumps(tables,sort_keys=True,separators=(',',':')).encode();packed=gzip.compress(raw,mtime=0)
    with (HERE/(role+'_tables.json.gz')).open('xb') as out:out.write(packed)
    result={'schema':'C1_GS_COMPLETE_SCALAR_SM_FRAME_NATIVE_V1','route':role,'execution_state':'COMPLETED',
            'frame_dimension':328,'SM_classes':35,'highest_directions':65,'parent_coefficient_directions':34,
            'full_measured_positions':328**2,'all_parent_real_and_metric_compatible':True,
            'gauge_and_PQ_tree_nullity':True,'full_gauge_projection_matches':True,
            'allowed':ALLOWED,'rank':rank,'augmented_rank':aug,'kernel_dimension':len(kernel),
            'point_lift':None if lift is None else list(map(str,lift)),
            'coordinate_blind_directions':blind,'free_symbols':[] if lift is None else sorted(str(z) for z in set().union(*(value.free_symbols for value in lift))),
            'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(packed).hexdigest(),
            'table_bytes':len(raw),'packed_bytes':len(packed),'elapsed_after_imports':time.perf_counter()-start,
            'global_quartic_identity':False,'finite_C1_or_E5_completed':False}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
