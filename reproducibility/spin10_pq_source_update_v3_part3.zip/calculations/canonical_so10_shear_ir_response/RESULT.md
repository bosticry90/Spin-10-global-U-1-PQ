# Actual infrared response: nonzero at zero momentum, removable off it

Prospective qualification requires completed separate validation and exact
committed-byte checks. Both native routes completed and agree. No IR witness
or renormalization scheme is adopted. Authority remains113/34of39.

The historical loop contract calls for an H-covariant temporary IR restriction
and its breaking insertion. Two provisional source-independent spectral
smoothings were constructed for this applicability test:

    chi_k=(1-exp(-P/epsilon²))^k, k=1,2.

The ordered inverse requires an additional R_IR=(K_t,epsilon-K_t)/2. Dropping
its special-shear response is incorrect even though both smoothings leave
the ultraviolet symbol unchanged to every power. The existing complete
source product and all37 source flows remain required globally.

In the actual canonical C12*ub12*x_Sigma153 scalar channel,the complete XZ
cohort has two massless odd internal lines. Sparse matrix products and an
opposite index-path calculation independently give left/right traces
-18sqrt15/25 each. The full trace is-36sqrt15/25,matching the previously
measured action-based coefficient. This is not a fitted normalization.

The IR insertion contribution in hbar/(32pi²) units is

    (36sqrt15/25) g10^4 xi^3 D_k(t,epsilon,p).

The native records supply its exact E1/log kernels and numeric controls.
The nonlinear corner is zero in this projection by its actual100 B/Lambda
external partners before taking any limit. This is ONE COHORT of I_reg,IR;
other cohorts/source/connected terms are not declared zero or closed.

At p=0,with s=4t epsilon²,the complete radial sum is finite and positive:

    D_1(s)=-log(s+1)+2log(s+2)-log(s+3),
    D_2(s)=-2log(s+1)+9log(s+2)-16log(s+3)
           +14log(s+4)-6log(s+5)+log(s+6).

At s0 these become log(4/3) and38log2-15log3-6log5,respectively. They differ.
Thus the actual exceptional-momentum response has a finite IR-shape
dependence. It is not the old g10^3 xi² contact target,and it is not by
itself an anomaly or a failure of the complete identity.

For fixed p_E²>0 the analytic bound is

    0<=D_k<=16k[epsilon²/p_E²+epsilon^4/(p_E²)^2], all t>=0.

It is uniform in canceled-leg momentum routing. Therefore this actual IR
response disappears uniformly when the cutoff is removed on any compact
domain away from p²=0. The two orders t0/epsilon0 commute there. The two
orders p0/epsilon0 do NOT commute:one gives the constants above,the other0.
A constant-field UV projection cannot determine the nonexceptional finite
identity by interchanging these limits.

The same bound controls the difference between the IR-smoothed and original
actual primitive bubble. Its previously qualified nonexceptional kernel and
source/Ward/Slavnov descendants retain their common kappa family for both
witnesses. Source differentiation still precedes J0. kappa and b0 remain
distinct and unfixed. This preserves a genuine constructed sector while
locating the boundary of its extension to exceptional momenta.

Next:perform a port/pole-order census for ALL kernels entering a complete
selected special-shear identity with local probes. Determine which have only
integrable separated soft poles and which have repeated momentum clusters.
Keep zero-momentum transfers,scalar reference insertions and source products.
Such a census can establish a common nonexceptional domain or identify the
smallest genuinely missing IR normalization without another huge tensor.
Do not extrapolate this XZ calculation to every one-loop coefficient.

Track B evidence:an actual domain problem was reduced to a complete compact
cohort and two analytically controlled limits,rather than another blanket
assumption about covariant cutoffs. Native/replay share frozen action,charts,
operator/support/Wick qualifications,software and AI author. Separate
verification adds implementation checks,not external scientific confirmation.
Read receipts for runtimes,memory,failures and numerical convergence.

No Gamma,state,policy,old evidence,scheme,physical inputs or protected stages
change. Full renormalized special-shear/contact prescription,source-free
Slavnov,QAP,measure/IR/equivalence/E5/A5 stay unqualified. Source38,
Gamma874873/source146663,369/664,295 unmeasured vector profiles,custody2/seven,
quartet failure,140%singlet warning,matching miss,HB1/C5 block and flavor pause
retain their established dispositions.
