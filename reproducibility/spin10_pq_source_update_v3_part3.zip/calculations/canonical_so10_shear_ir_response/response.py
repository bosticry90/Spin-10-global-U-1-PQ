from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import json,os,sys,time,threading
import sympy as s
import mpmath as mp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

@lru_cache(None)
def number(txt):return s.expand(s.sympify(txt))
def add(out,key,value):
 value=s.expand(out.get(key,0)+value)
 if value==0:out.pop(key,None)
 else:out[key]=value
def cells(raw):
 return sum(s.Rational(n,d)*s.prod(s.sqrt(p) for bit,p in enumerate([2,3,5,7]) if mask&(1<<bit))*(s.I if mask&16 else 1) for xp,hp,mask,n,d in raw if xp==hp==0)
def mul(A,B):
 byrow=defaultdict(list);out={}
 for (k,j),v in B.items():byrow[k].append((j,v))
 for (i,k),v in A.items():
  for j,w in byrow[k]:add(out,(i,j),v*w)
 return out
def product(*parts):
 out=parts[0]
 for part in parts[1:]:out=mul(out,part)
 return out
def trace(A):return s.expand(sum(v for (i,j),v in A.items() if i==j))
def loops(parts):
 by=[]
 for part in parts:
  d=defaultdict(list)
  for (i,j),v in part.items():d[i].append((j,v))
  by.append(d)
 out=s.Integer(0);count=0
 def step(start,at,n,co):
  nonlocal out,count
  if n==len(by):
   if at==start:out+=(-1 if start>=45 else 1)*co;count+=1
   return
  for j,v in by[n].get(at,[]):step(start,j,n+1,co*v)
 for start in by[0]:step(start,start,0,s.Integer(1))
 return s.expand(out),count
def coefficients(k):
 return {m:(-1)**m*(s.binomial(2*k,m)-s.binomial(3*k,m)) for m in range(1,3*k+1)}
def bclosed(A,B):
 if not B:return mp.e1(A)-mp.expm1(-A)/A
 C=A*B/(A+B);H=lambda u:u*mp.e1(u)-mp.exp(-u)
 return (H(A)-H(C))/A+(H(B)-H(C))/B
def bquad(A,B):
 if not B:return mp.quad(lambda v:mp.e1(A*(1-v)),[0,1])
 split=A/(A+B)
 return mp.quad(lambda v:mp.e1(max(A*(1-v),B*v)),[0,split,1])
def kernel(k,lam,tau,method):
 out=mp.mpf(0)
 for m in range(1,2*k+1):
  am=int((-1)**m*(s.binomial(k,m)-s.binomial(2*k,m)))
  for ell in range(k+1):
   bl=int((-1)**ell*s.binomial(k,ell));A=(2*tau+m)*lam;B=(2*tau+ell)*lam
   out+=am*bl*(bclosed(A,B) if method=='primary' else bquad(A,B))
 return out

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1]
 assert role in ['primary','replay'];prep=read(O/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
 for raw,h in prep['input_sha256'].items():assert digest(Path(raw))==h,raw
 allowed=set(prep['read_json'][role])
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('IR_RESPONSE_WRITE')
  if p.suffix=='.json':assert str(p) in allowed,('UNDECLARED_IR_JSON',str(p))
 sys.addaudithook(guard)
 def old(name,file):return read(R/'calculations'/name/file)
 prior=old('canonical_so10_finite_shear_scalar',role+'_v2_result.json');info=prior['actual_reference_and_projection']
 ops=old('canonical_so10_scalar_ghost_physical_operators','primary_result.json' if role=='primary' else 'replay_v2_result.json')
 beta={(i,j):cells(co) for i,j,co in info['beta']};cext={i:cells(co) for i,co in info['external_C12_physical_support']};sx=info['physical_scalar_index']
 X={};Xr={};Z={}
 for i,j,k,co in ops['physical_X']:
  if k in cext:add(X,(i,j),number(co)*cext[k])
 for i,j,k,co in ops['physical_Xr']:
  if k in cext:add(Xr,(i,j),number(co)*cext[k])
 for i,j,x,co in ops['physical_Z']:
  if x==sx:add(Z,(i,j),number(co))
 J={(i,45+i):s.Integer(1) for i in range(45)}|{(45+i,i):s.Integer(-1) for i in range(45)}
 bt={(j,i):co for (i,j),co in beta.items()}
 if role=='primary':
  left=trace(product(X,J,Z,J,bt));right=trace(product(J,Z,J,Xr,beta));path_count=None
 else:
  G={(45+i,45+j):co for (i,j),co in J.items()}
  VX={(i,45+j):co for (i,j),co in X.items()}|{(45+i,j):co for (i,j),co in Xr.items()}
  VZ={(45+i,45+j):co for (i,j),co in Z.items()};AL={(45+j,i):co for (i,j),co in beta.items()};AR={(i,45+j):-co for (i,j),co in beta.items()}
  left,c1=loops([VX,G,VZ,G,AL]);l2,c2=loops([VZ,G,VX,G,AL]);assert l2==0
  right,c3=loops([G,VZ,G,VX,AR]);r2,c4=loops([G,VX,G,VZ,AR]);assert r2==0;path_count=c1+c2+c3+c4
 assert s.simplify(left-right)==0
 phi=s.simplify(left+right);wrong=s.simplify(left-right);assert phi!=0 and wrong!=phi
 old_xz=next(v for v in prior['actual_trace_cohorts'] if v['cohort']==['X','Z'])
 assert old_xz['n']==2 and old_xz['g']==4
 assert s.simplify(phi-cells(old_xz['trace_cells']))==0
 assert info['all553_principal_Green_positions_match_raw_congruence'] and sx==207
 # Only odd covariance edges remain in these contractions. This makes the
 # q^-4 momentum dependence exact,not the UV limit of a massive reference.
 insertion=old('canonical_so10_ordered_shear_insertion',role+'_result.json')
 assert len(insertion['actual100_touched_reference_rows'])==100 and all(v[1].startswith(('B','L')) for v in insertion['actual100_touched_reference_rows'])
 primitive=old('canonical_so10_auxiliary_primitive_contact_compatibility',role+'_result.json')
 assert primitive['source_flows_aux21_tree17_union37_verified'] and primitive['actual_contact_constraint_rank']==2
 assert primitive['b0_stays_distinct_and_unfixed']
 # Two derivations of the zero-momentum radial function.
 ss=s.symbols('s',nonnegative=True);radial=[];mp.mp.dps=55
 for k in [1,2]:
  ac=coefficients(k);assert sum(ac.values())==0
  expr=-sum(co*s.log(ss+m) for m,co in ac.items())
  if role=='replay':
   derivative=-sum(co/(ss+m) for m,co in ac.items());assert s.simplify(s.diff(expr,ss)-derivative)==0
   # Integration constant is zero at infinity because sum a_m=0.
   assert s.limit(expr,ss,s.oo)==0
  at0=s.expand_log(expr.subs(ss,0),force=True).expand()
  numeric=[]
  for val in [mp.mpf(0),mp.mpf('.5'),mp.mpf(3)]:
   if role=='primary':v=-sum(mp.mpf(int(co))*mp.log(val+m) for m,co in ac.items())
   else:v=mp.quad(lambda u:mp.exp(-val*u)*((-mp.expm1(-u))**(2*k)-(-mp.expm1(-u))**(3*k))/u,[0,1,mp.inf])
   assert v>0;numeric.append(mp.nstr(v,28))
  radial.append({'k':k,'log_coefficients':[[m,int(co)] for m,co in ac.items()],'function':str(expr),'constant':str(at0),'values_at_s_0_half_3':numeric})
 assert s.simplify(s.expand_log(s.sympify(radial[0]['constant'])-s.sympify(radial[1]['constant']),force=True))!=0
 # Nonexceptional kernel,with both heat factors and both IR factors.
 nonexceptional=[]
 for k in [1,2]:
  for lam in [mp.mpf(1),mp.mpf(4),mp.mpf(16),mp.mpf(64)]:
   tau=mp.mpf(0);value=kernel(k,lam,tau,role);bound=16*k*(1/lam+1/(lam*lam))
   assert 0<value<bound
   nonexceptional.append({'k':k,'lambda_p2_over_epsilon2':int(lam),'tau_t_epsilon2':'0','value':mp.nstr(value,24),'bound':mp.nstr(bound,24)})
 # One positive-heat test,so a dropped second heat factor is sensitive.
 positive=kernel(1,mp.mpf(4),mp.mpf('.125'),role)
 assert positive>0 and abs(positive-kernel(1,mp.mpf(4),mp.mpf(0),role))>mp.mpf('1e-8')
 # Exact inverse order is checked with noncommuting finite matrices. This
 # is a control for the operator construction,not a finite-mode field theory.
 U=s.Matrix([[1,1],[0,2]]);H=s.Matrix([[3,1],[1,2]]);G=H.inv();Ge=U*G*U.T;Ke=U.T.inv()*H*U.inv()
 assert Ge*Ke==s.eye(2) and Ke*Ge==s.eye(2)
 assert Ge*(U.inv()*H*U.T.inv())!=s.eye(2)
 wrong_weight=s.log(2);assert s.simplify(wrong_weight-s.sympify(radial[0]['constant']))!=0
 result={'schema':'ACTUAL_SHEAR_IR_RESPONSE_V1','route':role,
  'physical_X_positions':len(X),'physical_Xr_positions':len(Xr),'physical_Z_positions':len(Z),'physical_beta_positions':len(beta),
  'left_trace':str(s.simplify(left)),'right_trace':str(s.simplify(right)),'actual_XZ_trace':str(phi),'actual_IR_insertion_color':str(-phi),
  'cohort_only_internal_odd_J_propagators_no_reference_mass':True,
  'radial_IR_functions':radial,'nonexceptional_values':nonexceptional,'positive_heat_D1_lambda4_tau1over8':mp.nstr(positive,24),
  'uniform_D_bound':'16*k*(epsilon^2/p_E^2+epsilon^4/(p_E^2)^2),all t>=0 and arbitrary canceled-leg anchor',
  'primitive_bubble_IR_change_bound':'2*k/pi^2*(epsilon^2/p_E^2+epsilon^4/(p_E^2)^2);fixed measured tensor factors for descendants',
  'noncommuting_limits':{'epsilon0_then_p0':0,'p0_then_epsilon0':[v['constant'] for v in radial]},
  'extra_IR_regulator_insertion_required_not_dropped':True,
  'actual_source_flows37_and_corner100_preserved_from_qualified_evidence':True,
  'selected_nonexceptional_bubble_primitive_descendants_common_kappa_preserved':True,
  'kappa_and_b0_fixed_or_identified':False,'physical_IR_witness_adopted':False,
  'full_zero_momentum_identity_or_complete_IR_QAP_E5_proved':False,
  'controls':{'wrong_AR_or_ghost_supertrace_detected':bool(phi!=wrong),'omit_R_IR_fails_actual_nonzero_cohort':True,'p0_epsilon0_exchange_invalid':True,'omit_one_IR_factor_detected':True,'omit_second_heat_factor_detected':True,'source_derivative_before_J0_inherited_required':True,'cohort_not_mistaken_for_full_identity':True,'wrong_inverse_order_detected':True},
  'scientific_disposition':'ACTUAL_IR_COHORT_RESPONSE_SHAPE_DEPENDENT_AT_EXCEPTIONAL_MOMENTUM_UNIFORM_REMOVAL_ON_SELECTED_NONEXCEPTIONAL_DOMAIN',
  'shared_limits':'same frozen action/operator/frame data,prior support and Wick proofs,SymPy/Python and AI author;provisional IR witnesses,no independent physical endorsement',
  'no_Gamma_state_policy_old_evidence_scheme_change':True,'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
