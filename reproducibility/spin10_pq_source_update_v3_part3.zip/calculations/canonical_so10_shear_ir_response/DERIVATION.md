# An actual IR insertion and noncommuting momentum limits

Prospective derivation requiring completed native and separate verification.
No physical IR prescription is adopted. All scope is fixed in RECORD.

## 1. The inverse and the extra insertion

For the provisional H-covariant spectral multiplier chi_k=(1-exp(-P/epsilon²))^k,
put U=chi_k^1/2. On a common spectral core the covariance is U G_t U^ST,
and its inverse is U^-ST K_t U^-1,with both orders checked. At flat A=0 the
common scalar chi commutes with the reference matrices,so G_t,epsilon=chi G_t
and K_t,epsilon=chi^-1 K_t. The extra quadratic regulator is

    R_IR=one_half phi (K_t,epsilon-K_t) phi.

The regulated fixed-J identity must use I_reg,total=<X(R_t+R_IR)> and its
whole source products. The formal special Jacobian remains an inherited
zero diagnostic,not a new continuum measure proof. chi is source independent.
At general background its variation has a spectral/Duhamel response;no
unjustified commutation past a vertex or omission of this response is made.

In the selected scalar/ghost projection X R_IR has the same B/Lambda external
partners as X R_t. Its nonlinear corner is therefore zero before taking any
loop limit. In a tangent contraction,adjacent K_t,epsilon G_t,epsilon=I
eliminates the inverse chi. For the XZ cohort,the two surviving propagators
are odd J/q² and J/(q+p)²;the extra factor from the canceled leg is1-chi.
No scalar/gauge denominator or reference mass enters this cohort. With the
antighost momentum0,the two tangent orientations differ only by q->-q-p.
Their matrix/ghost coefficients agree,and the convergent IR-reduced integrals
can be routed before any limit.

Using the same Minkowski/Wick normalization as the previous measured finite
scalar result,define the dimensionless function

    D_k(t,epsilon,p)=16pi² integral d4q/(2pi)^4
      exp[-2t(q²+(q+p)²)]
      chi_k(q²) chi_k((q+p)²) [1-chi_k(q²)]/[q²(q+p)²].

The exact XZ contribution to I_reg,IR in hbar/(32pi²) units is

    (36sqrt15/25) g10^4 xi^3 D_k.

This color factor is derived by both tangent orientations of the actual
physical matrices,before comparison to the old trace. In stripped units
the full trace is2 Tr(X J Z J beta^t)=-36sqrt15/25. Its negative is the
insertion coefficient. There is no loop-length1/n factor. It is one measured
cohort,not the full contact/IR answer or the old g10^3 xi²384-position target.

## 2. Exact kernel at nonzero momentum

Expand chi(q)[1-chi(q)]=sum_m A_m exp(-m q²/epsilon²) and
chi(q+p)=sum_l B_l exp(-l(q+p)²/epsilon²),where

 A_m=(-1)^m[binom(k,m)-binom(2k,m)],m1..2k,
 B_l=(-1)^l binom(k,l),l0..k.

For a>0,b>=0,p²>0 the scalar integral J(a,b,p) has

    16pi² J=integral_0^1 dv E1(p² max(a(1-v),b v)).

This follows by Schwinger parameters alpha>=a,beta>=b and then alpha=u v,
beta=u(1-v). It preserves both heat factors,not a one-leg surrogate.
Set A=a p²,B=b p²,C=AB/(A+B),H(u)=u E1(u)-exp(-u). For b>0 it equals

    [H(A)-H(C)]/A+[H(B)-H(C)]/B.

For b=0 it equals E1(A)+(1-exp(-A))/A. D_k is the finite sum of these kernels
with a=2t+m/epsilon²,b=2t+l/epsilon². Individual p0 terms are IR divergent;
the sum must be made before that specialization. The complete chi product
makes D_k finite at p0 for every epsilon>0,t>=0.

## 3. The exact constant-field limit

For p=0 use u=q²/epsilon²,s=4t epsilon². Then

    D_k=integral_0^infinity du exp(-s u)
        [(1-exp(-u))^(2k)-(1-exp(-u))^(3k)]/u
       =-sum_(m=1)^(3k) a_m log(s+m),
    a_m=(-1)^m[binom(2k,m)-binom(3k,m)].

sum a_m=0 makes the log integral well-defined. A separate derivation
differentiates in s,integrates the rational sum and uses D_k(infinity)=0.
In the t0 (or fixed-t epsilon0) limit,

    D_1=log(4/3),
    D_2=38log2-15log3-6log5.

Both are positive and different. Thus an actual allowed IR-response cohort
has a nonzero finite,shape-dependent constant at exceptional zero momentum,
even though both witnesses have identical ultraviolet asymptotics. This is
not an anomaly:the remaining source/regulator/connected terms may supply
companion contributions,and no complete zero-momentum identity is claimed.

## 4. A common nonexceptional domain and a uniform bound

For integer k>=1,0<=chi_k<=1 and1-chi_k(q²)<=k exp(-q²/epsilon²).
Let p²>0. For any anchor a,the normalized Gaussian bubble obeys

 integral d4q/(2pi)^4 exp(-|q+a|²/epsilon²)/[q²(q+p)²]
 <= [epsilon²/p²+epsilon^4/(p²)^2]/pi².

Proof:split balls |q|<|p|/2 and|q+p|<|p|/2 from their complement. On each
ball one denominator is >=p²/4. Uniformly in a,split the remaining Coulomb
integral at radius epsilon:its inner contribution is <=pi² epsilon² and its
outer contribution is <=epsilon^-2 integral Gaussian=pi² epsilon².
The two balls together are bounded by16pi² epsilon²/p² before division by
(2pi)^4. On the complement,both denominators are >=p²/4 and the bound is
16pi² epsilon^4/(p²)^2. Boundary overlap has measure zero. Heat<=1,so the
bound is uniform for all t>=0 and for all canceled-leg momentum anchors.

Consequently

    0<=D_k<=16k[epsilon²/p²+epsilon^4/(p²)^2], p²>0.

It goes to0 at fixed p²>0,uniformly in t. The two orders t0/epsilon0 commute
for this response on any compact domain bounded away from p²=0. But the
orders p0/epsilon0 DO NOT commute:one gives the nonzero constants above and
the other gives0. A constant-field UV coefficient cannot replace the
nonexceptional finite insertion without this domain qualification.

For the actual primitive bubble,the IR change is weighted by
1-chi(q)chi(q+p)<=k[exp(-q²/epsilon²)+exp(-(q+p)²/epsilon²)].
The same bound,twice,proves uniform removal of both provisional restrictions
from that selected kernel. It is a UV-finite difference,so it also commutes
with the already constructed common finite part there. The actual local
Ward/Slavnov descendants multiply this kernel by fixed finite M/V tensors
and retain local probes/source derivatives. On nonexceptional momenta their
previous common-kappa family is unchanged. This statement uses their actual
qualified tensor identities;it does not evaluate other connected products.
The older b0 remains distinct and unfixed.

## 5. Consequence and boundary

The general IR/domain gap cannot be repaired by calling a restriction
H covariant. We now exhibit an actual nonzero regulator response and a
common nonexceptional domain in which that cohort's response vanishes.
This is stronger than a generic projector counterexample. The temporary
restriction is a source-independent Gaussian witness,not a constructed
physical scheme,global inverse/measure,nonlinear product domain or a full
zero-momentum restoration theorem. No arbitrary external-testfield bounds,
causal/Lorentzian continuation or global IR removal is obtained.

Do not insert these cohort coefficients into Gamma or tune kappa/b0. Before
extending the full special-shear theorem,the next useful question is whether
ALL ordered coefficient kernels needed by a complete selected identity share
such a nonexceptional domain,or which repeated soft-momentum clusters need
additional IR treatment. A port/pole-order census can settle that before
another component expansion. Preserve the actual scalar quadratic reference
insertions,source probes and zero-momentum transfers in such a census.
