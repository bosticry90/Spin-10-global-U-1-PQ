# Actual XZ special-shear IR response V1

Base c89dcc2a18b9b078b49dae1664dbef04b61299d2,main. Previous increment PROGRESS.
Question:can the currently unspecified H-covariant IR restriction produce a
real correction in an actual special-shear loop,and can that correction be
removed on a common nonexceptional momentum domain? This tests the missing
premise of the common finite-part construction,not another arbitrary tensor.

The historical loop contract specifies a temporary H-covariant IR spectral
restriction but no unique multiplier. Examine TWO PROVISIONAL witnesses
chi_k(P)=(1-exp(-P/epsilon^2))^k,k1/2,using the already fixed P=-Dbar_H^2.
They are real,positive away from zero,source independent,parity preserving,
H covariant,and approach1 faster than any power at large flat momentum.
Do not adopt either as the physical prescription or replace historical inputs.
G_t,epsilon=chi^(1/2) G_t chi^ST(1/2) and its EXACT ordered inverse define the
Gaussian witness on a core avoiding zero spectral values. At A=0 the common
scalar multiplier gives G_t,epsilon=chi G_t,K_t,epsilon=chi^-1 K_t.
Include R_IR=(K_t,epsilon-K_t)/2 in the regulator response. No false claim
that nonlinear multiplication preserves the spectral core is permitted.

Use the actual entire XZ cohort of the existing canonical C12*ub12*x_Sigma153
finite scalar channel. Its two remaining internal lines are both odd and have
exact J/q^2 covariance,no scalar reference mass or UV approximation. Derive
the color contraction from frozen physical X,Xr,Z,beta and C12 charts before
comparing the old trace. Keep both tangent orientations and ghost signs.
Set the external antighost momentum to0 and ghost/scalar momenta to-p/p.
This leaves two distinct loop poles when p_E^2>0. The pure scalar/ghost
nonlinear corner is zero by the actual100 B/Lambda partners;all37 source
products remain globally required. No complete Ward identity is inferred.

Required evidence:ordered adjacent inverse cancellation gives a finite IR
insertion with chi(q)chi(q+p)[1-chi(q)] and the two-propagator heat. Prove the
opposite tangent has the same kernel after convergent routing. Evaluate its
zero-momentum radial function exactly for both k and general s=4t epsilon².
Derive a positive,uniform nonexceptional bound for arbitrary Gaussian anchor.
Establish the noncommuting p0/epsilon0 limits and classify their scope.
Also bound the IR change to the actual primitive bubble and its already
qualified source/Ward/Slavnov descendants without identifying kappa and b0.

Primary:ordered sparse products,Schwinger/E1 integrals and binomial log sum.
Replay:explicit index-loop paths,radial regulator differentiation and direct
quadrature. Separate verifier:own color contractions/finite sums,independent
integrations and analytic bound/domain review. Freeze inputs/receipts/source
before execution. No reuse of expected new results as calculation inputs.
Controls:wrong ghost supertrace or AR sign,drop R_IR,set p0 before removing
IR,replace chi products by1,omit one smoothing factor,source J0 before
derivative,and treating this single cohort as the complete IR identity.

Two sequential native120s after imports/8GiB sampledprivate,verifier120s/8GiB,
350MiB launch floor,new bytes<2MiB. Preserve failed/unfinished executions;
freeze corrections separately. No subagents,full Gamma expansion or295-vector
calculation. Validate and authenticate committed bytes before qualification.

Ceiling:actual selected-cohort response and common nonexceptional IR-removal
result in these provisional flat witnesses. Not an adopted IR scheme,global
semigroup,causal/continuum measure,testfield extension,complete renormalized
special-shear identity,QAP or E5/A5. Other zero-momentum cohorts may contribute
and are not declared zero. No state/Gamma/policy/old evidence changes. All
authority113/34of39,sevensfalseflags,source38,Gamma874873/source146663,
369/664,295 unmeasured profiles,custody2/seven and protected warnings/blocks/
pause remain. Shared action/charts/qualified proofs/software/AI author limit
independence. Plausible outcomes:bounded IR construction,prescription
dependence,underdefinition or incomplete calculation;none alone is an anomaly.
