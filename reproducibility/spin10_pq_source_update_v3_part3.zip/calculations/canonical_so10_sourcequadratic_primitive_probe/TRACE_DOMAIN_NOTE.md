# First-probe trace domain: the single labelled vertex is a separate case

The two native routes completed in105.342 and93.548seconds. Their complete
3890-position primitive and47411-field-word image match the inherited exact
hashes. This note resolves an endpoint of the analytic argument before its
independent validation. It is not another loop coefficient or physical scheme.

The DERIVATION's independent-transfer statement must be read for two or more
labelled vertices. With only ONE labelled vertex, the trace sets its TOTAL
transfer to zero. Additional factors at the SAME local vertex add relative
test momenta; they do not make the two sides of that vertex independent.
One cannot prove that endpoint by saying every label splits two nodes.

At first probe order, a direct insertion is a trace G*H_(probe G) or
G*H_(u QG) and has only one Green edge, up to the inherited zero-transfer
scalar/M chains. Its dressed soft order is<=2. The old constant Q tangent
still has exactly the old support and its merged bound<=3. It is not a
second new constant symmetry insertion. Probe/source differentiation never
removes the old momentum numerator except by a labelled background term.

The new source-dependent tangent occurs in the complete Hessian congruence.
Keep H*G and G*H legs together with all constant reference countervertices;
do not define a product of two naked massless Green entries first. At one
labelled vertex its total Fourier transfer is zero. The reference cutoffs
are scalar functions of the same loop momentum and commute with the constant
matrix/symbol at that root. Each H cancels an adjacent inverse in the complete
ordered identity. What remains is a polynomial tangent times an ordinary
dressed edge or a polynomial differential trace, not an independently
extended critical1/p^4 kernel. Nonlinear coefficient factors at that vertex
are still retained test functions, convolved at total transfer zero.

At finite proof cutoff the cancellation is NOT asserted exact. G_epsilon*H
contains the actual edge cutoffs. At each fixed finite constant-chain order,
retain the complete inverse and projection defects. The paired terms differ
by bounded powers of chi_epsilon=1-exp(-p^2/epsilon^2), multiplying the SAME
ordinary dressed edge/tangent. The existing constant-chain support proof
bounds it by a locally integrable power<=2 (or the one old tangent bound3).
It converges pointwise off zero and is dominated in that joint class. Thus
its residual vanishes, rather than generating an arbitrary IR delta. Hard
UV-shell differences are smoothing, so this remains true in the prescribed
UV finite part THEN IR order. No infinite Born resummation is claimed.

For example the exact four-dimensional flat diagnostic is

 integral dp/(2pi)^4 (chi_epsilon^4-chi_epsilon^2)/p^2
       = -7 epsilon^2/(192 pi^2),

which tends to zero. In contrast replacing the paired ordinary edge by a
naked critical1/p^4 would give log(81/128)/(16pi^2), NONZERO and independent
of epsilon. This control exposes precisely why cancellation before a
singular restriction matters. These are regulator diagnostics, not actual
Spin10 source tensors or a license to discard the earlier critical IR delta.

For two or more labelled vertices, apply the independent node routing and
submersion proof already recorded, retaining any single old constant tangent.
Use the same free-edge smoothing/covariant-family matching. This completes
the labelled-node argument at every finite coefficient for the FIRST probe
and its first Slavnov variation. Arbitrary coincident source-derivative
diagonals, a constant-strength unit-probe determinant, two independent Q
insertions and global physical limits are not covered.

The master-Hessian product identity remains valid with source-quadratic S:
ordinary field differentiation of S_i R_i always gives the four ordered
legs. Its source variation is the full QJ operation, not an omitted constant
source or an assumed source-linear action. The fixed metric lift and the
same T_kappa extend the COMPLETE grouped identity. Raw heat, reference and
Jacobian responses remain in the finite conversion. Flat field divergence
zero, checked for this family, does not establish zero raw heat Jacobian.

Failure record: four failed native executions are preserved. V1 tuple/list
setup; V2 census display-order fixture; V3 incorrect odd carrier reconstruction;
V4 omitted explicit inert-A columns in a completeness assertion. Only V5
completed both routes. The V3 sign was derived from parity, not fitted to a
Ward remainder. There was no cap expansion or new physical input. The first
two/fourth failures were avoidable orchestration errors and remain TrackB
limitations. Multiple routes share action, conventions, software and analyst.
