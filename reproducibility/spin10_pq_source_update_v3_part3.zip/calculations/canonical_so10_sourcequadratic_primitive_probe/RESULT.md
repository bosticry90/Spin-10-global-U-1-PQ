# Complete two-source first-probe replacement in the fixed one-loop construction

Completed V5 native routes and separate independent validation passed.
Validation receipt SHA256:
`570973eded4ca60615a17ca97b51102517cd806dee229666b653f9f127b1243b`.
Qualification is confined to the specified formal Euclidean one-loop,
local-Schwartz-probe/first-Slavnov-variation construction. It is not full E5/A5.

## A complete source-degree sector is covered

Power counting and ghost/parity grades leave exactly two dimension3,gh=-1
odd patterns with at least two BV sources:

 JL*Ja,                 JL*JL*C.

There are no derivatives, positive-dimensional coefficients or three-source
patterns at that grade. The odd JL pair is antisymmetric. General coefficient
tensors obey the actual reality/background restrictions; their invariant
ranks are not claimed. Polynomial dimensionless parameter factors remain.

Gauge fixing transports BOTH patterns with the actual full E2 source shifts.
Their correlated lower-source terms are retained. The common augmented
functional S+u QG+rho G, truncated only by probe degree, defines the whole
connected insertions in the inherited T_kappa prescription. Its first-probe
identity is

 I_QG=(Gamma1,G)+(S,I_G),       [QG]=(Gamma_kappa,[G]) modulo hbar^2,

with local probe jets and ordinary currents. This supplies a uniform bounded
replacement for this entire two-source carrier module, rather than assuming
that a source-dependent canonical map is a change of integrated variables.
No missing quantum coefficient is assigned the value required for cancellation.

## The actual earlier basic example is reproduced exactly

The reconstructed Ksrc=U N Kbeta matches ALL3890 inherited coefficients and
the old serialized hash `e47704cd5e43b68d24722d6e8f7b9678cb904cbf15e52d78ab15a8332aa509bf`.
Its Q image matches the full47411-field-word old result and hash
`ae61fe1a37cbb97bac059d0e4904a81295b02f02654b794d66f2ab5cdbb8daeb`.
It has47685 coupling-resolved positions; the two counts are different types
of bookkeeping, not different amplitudes.

| Actual transported object | Exact positions |
| --- | ---: |
| Source degree0 part of Ksrc |1824 |
| Source degree1 part |1996 |
| Source degree2 part |70 |
| Ordinary two-polarization Hessian of Ksrc |9168 |
| Full Hessian of QKsrc, coupling-resolved |319039 |
| Derivative-rho functional-Hessian terms |188 |

The canonical flow has90 nonzero integrated-field and514 nonzero source
columns, with all1286 slots and their zero complement derived. The508 physical
Euler programs are retained/bound, not freshly expanded or put on shell.
The inherited dimension-one orbit coefficients retain their old typed lift;
word-only grading of their evaluated numerical values is not substituted.

Both light/heavy fixtures cover each carrier pattern. They are generic
component tests, not separately asserted invariant counterterms. The old
actual Ksrc inherits its reality/basicness only after the full exact match.

## Sensitive controls distinguish the actual requirements

Omitting U companions loses the entire9168-position Ksrc field Hessian.
Dropping its top-source part changes35407 coupling-resolved QG positions.
That top part has ZERO ordinary G Hessian, so that particular Hessian-only
control is insensitive and is expressly not counted as detecting the omission.
Setting sources to zero before Q changes71898 coupling-resolved positions.
Thus a source-zero projection cannot test the complete identity.

A finite Gaussian source-dependent control gives a raw Hessian trace16/5
versus the canonical two-leg sum6/5. The difference2 is the necessary tangent
measure term in that diagnostic, not an actual Spin10 heat coefficient.
The actual family has zero flat FIELD superdivergence by explicit calculation;
this does not set its raw weighted heat/Jacobian response to zero. The full
finite heat/reference/power/first-dimension-jet conversion remains in T_kappa.

The trace proof keeps the old225 unlabeled tangent entries and constant-chain
support unchanged. It uses the same edge smoothing and UV finite part before
IR removal. TRACE_DOMAIN_NOTE separates the one-labelled-vertex endpoint
from the independent-transfer argument and retains paired inverse defects.
Its ordinary-edge cutoff control tends to zero; the deliberately naked
critical1/p^4 control instead gives nonzero log(81/128)/(16pi^2). Earlier IR
delta/contact terms are not dropped or identified with kappa or b0.

## Validation, failures and limits

Native routes use prefix and left-gradient operations and different carrier
contraction orders. The separate verifier imports no SQP native code: it uses
expanded rational/radical coefficients, right gradients and independently
ordered transport. It freshly checks the entire actual primitive, Q image,
full G and QG Hessians, all five fixture families, complete canonical flows,
local probe adjoints and sensitive controls. For the large actual example it
recomputes the full HQ directly; it does not freshly recompute each of its
four product groups. Those use native agreement plus the reviewed general
polarized product proof. All four groups are independently replayed on the
component fixtures. Finite checks support, not replace, the analytic proof.

Native elapsed105.342/93.548seconds after imports; verifier47.056seconds.
Maximum SAMPLED private allocation1262706688bytes, not a true peak. Frozen
120/120/180second,8GiB,350MiB launch-floor and8MiB package limits passed.
The older broad audit is authenticated/reused, not rerun; custody remains
exit2/seven. Old loop calculations and physical invariant ranks were not rerun.

Four failed native executions remain: tuple/list setup, reversed census
display-order expectation, wrong odd carrier ordering, and missing explicit
zero background columns in a completeness check. The first two and fourth
are avoidable implementation/harness failures. The third was an actual
rejected coefficient reconstruction; its sign correction follows Grassmann
ordering, not fitting. Only V5 completed. No verifier failure occurred.
Shared action, inherited proofs, software/arithmetic and AI authorship remain;
this is computational corroboration, not independent physical endorsement.

No action, parameter, reference scheme, physical benchmark, older evidence or
project_state byte changed. Formal authority stays34/39. Full E5/A5, universal
counterterm/basic quotient adequacy, the remaining one-source primitive module,
minimal polynomial cocycles, arbitrary multiple insertions, all-order/local QAP,
measure/global equivalence and physical limits remain unqualified.

Next: complete the one-source primitive inventory and its actual quantum
implementation. Then reconcile the FULL exact-term domain with the original
E5 quotient problem. No new295-vector coefficient expansion is justified here.
