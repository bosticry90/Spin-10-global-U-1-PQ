# Complete two-source carrier sector and one common first-probe construction

## The finite sector, without a guessed source-free restriction

Project grades of B,x,A,C,a,Lambda are respectively dimensions1,1,1,1,1,2
and ghost numbers0,0,0,1,-1,0. Their BV sources have dimensions2,2,2,2,1
for JB,Jx,JC,Ja,JL, ghost numbers-1,-1,-2,0,-1 and parities1,1,0,0,1.
A is external and has no BV source. Positive coefficient dimensions and
derivatives consume the same dimension budget. At least two sources and
total dimension<=3 therefore leave only

 G2=sum M_ij JL_i Ja_j + sum N_ijk JL_i JL_j C_k,

with N antisymmetric in i,j. Three JL have ghost number-3 and cannot be
repaired within the dimension budget. Other source pairs similarly fail
ghost number or dimension. Both allowed patterns saturate dimension3, so
no jet or positive-dimensional coefficient remains. Polynomial g,width
coefficients may multiply them. Real/background-compatible tensors form
subspaces of this carrier module; no invariant rank is asserted.

U fixes ordinary fields and replaces J by J+A_J with the ACTUAL E2 shifts.
Thus a complete transported two-source generator is U G2. Its lower-source
companions cannot be removed. General primitives with the same highest-source
part differ from this completion by source-degree<=1 terms; those remain a
separate coverage question. The actual N involution precedes U in Ksrc.

The old basic example is Kbeta=Jbeta^T Gsource (Jeta-g Dstar C_H Jbeta).
Use the unchanged N and U to obtain Ksrc=U N Kbeta. The pre-U result lies
in exactly the two carriers above. Reconstruct its full3890 positions and
compare the original exact serialized hash. Its reality and basicness are
inherited only after that match; component fixtures alone need not be basic.

## Canonical algebra and the complete Hessian chain

For odd G use source-left X_G z=-(-1)^p Euler_J G and
X_G J=(-1)^p Euler_z G. QG=(S,G) uses BOTH Euler legs. Ksrc only consumes
nonphysical source columns; the508 physical programs nevertheless remain
part of S and its full inverse and are not equations set to zero.

For independent inert even u and odd rho set

 S_ext=S+u QG+rho G modulo probe degree>=2,
 d=integral rho delta_u.

Then (S_ext,S_ext)/2+d S_ext=0 modulo probe degree>=2, with all ordinary
currents and local derivatives retained. This is a first-order identity;
brackets of two perturbations do not lower probe degree. G has no field jets
before U, but U supplies divB terms. Derivative-rho adjoints of its functional
Hessian must remain, so H_(rho G) cannot be replaced by rho times a restricted
constant-probe kernel.

For any even S_ext, including its source-quadratic terms, the ordinary field
Hessian of its master breaking has the same chain rule. Writing R_i=EL_Ji S,
the two polarized product derivatives of S_i R_i have four ordered legs:
H(S_i)R_i, (D_h S_i)(D_k R_i), (D_k S_i)(D_h R_i), S_i H(R_i).
External source dependence does not remove the last leg or its QJ factor.
The corresponding operator identity contains the full QH and both tangent
congruence legs. No source-linearity assumption is needed for THIS first
variation. No derivative with respect to a source is taken after source0.

## Applicability, not an assumed general QAP

Every perturbation Hessian, field tangent and source variation retains u,
rho, a probe jet, or its tracking replacement. At probe degree zero the
unlabeled action, constant scalar/auxiliary chains and all225 constant tangent
entries are exactly the qualified original ones. Polynomial source dependence
can be differentiated away by QJ, but cannot remove the independent probe.
This is why the argument covers all allowed M,N rather than only a numerical
field configuration. U adds finite local products and derivatives, not inverse
operators or an unlabeled mass vertex.

At fixed finite external/probe order every new vertex has an independent
Schwartz transfer. Multiplication at one vertex convolves tests and uses a
submersive sum map. The source-dependent tangent has its own transfer too;
its two adjacent nodes must not be restricted to equal momentum. The old
ordinary dressed edges have soft order<=2. The one OLD unlabeled tangent
can merge to order<=3. Thus the same joint locally-L1 majorant and free-edge
smoothing argument apply. Keep finite-cutoff inverse defects until removal.
The actual covariant IR family and proof approximants share their joint
limit in the required order UV finite part THEN IR removal. This is not an
arbitrary coincident-source functional derivative, constant-probe diagonal,
two independent Slavnov insertion or vacuum-domain assertion.

Use the same fixed metric lift. Both G2 carriers are Lorentz scalars without
vector slots; U's gauge-fixing contractions already have that lift. Continue
the full source/field Euler operation before projection. The original
lifted Stokes and finite heat/power/first-D-jet conversion therefore apply to
the complete augmented log and its first variation. Differential tangent
traces vanish only IN converted T_kappa. Do not discard raw heat/Jacobian
responses or cancel integrated field traces against external BV sources.

Define Gamma_ext from that one augmented Hessian with the unchanged Gamma_ref.
Differentiation, including the complete finite conversion, defines the WHOLE
insertions I_G and I_QG, not a chosen polynomial remainder. The extended
identity gives

 [QG]=(Gamma_kappa,[G]) modulo hbar^2,
 I_QG=(Gamma1,G)+(S,I_G),

with the local probe/current form understood. These include connected source
products; neither source0 nor classical canonicality proves the relation.
At a counterterm strength O(hbar), crossed loop responses enter hbar^2;
unit insertions themselves retain their one-loop corrections.

## Sensitive finite control and ceiling

For a one-variable Hessian H=V'' and an external even nilpotent chi=Jb*theta,
take odd G=Jx*chi*f(x), S=V(x). Then I_G=Jx*chi*f''/(2H).
The two canonical legs yield chi*(V'*f''+V'''*f)/(2H), whereas the raw
Hessian trace I_QG also contains chi*f'. With V=x^2+x^4/4,f=x^2,x=1,
the canonical sum is6/5 chi and raw trace16/5 chi: the difference is2 chi.
This exposes the tangent/measure term. It is a finite algebraic control,
not an actual Spin10 heat coefficient or proof that its raw Jacobian is2.

This proves a uniform bounded two-source first-probe family only if the exact
calculations and separate validation pass. One-source primitive coverage,
minimal polynomial cocycles, induced/intrinsic basic quotient adequacy,
arbitrary products, all-order/local QAP and physical/global limits remain.
All older witnesses, parameter torsion, finite constants and custody remain.
