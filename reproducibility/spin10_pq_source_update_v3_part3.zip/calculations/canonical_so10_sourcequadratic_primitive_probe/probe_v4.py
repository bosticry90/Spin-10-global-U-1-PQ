"""Complete two-source first-probe sector; no new loop tensor or authority."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations_with_replacement
from collections import Counter
from functools import lru_cache
import gzip,json,sys,time,threading,os
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra,ONE,put,scale,scale_coefficient
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def plus(*pp):
 out={}
 for p in pp:
  for key,z in p.items():put(out,key,z)
 return out

def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 role=sys.argv[1];assert role in ['primary','replay'];prep=read(O/'preparation_v4.json');assert digest(Path(__file__))==prep['source_sha256']
 for raw,h in prep['input_sha256'].items():assert digest(Path(raw))==h,raw
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('SQP_NATIVE_WRITE')
  if p.suffix=='.json':assert str(p) in prep['read_json_by_role'][role],('SQP_UNDECLARED_JSON',str(p))
 sys.addaudithook(guard);get=lambda label:read(Path(prep['artifacts'][role][label]['path']))
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry']
 base=Algebra(geo['names'],geo['parities']);u=len(base.names);rho=u+1;A=Algebra(list(base.names)+['sqp_u','sqp_rho'],list(base.parities)+[0,1]);pairs=geo['field_source_h_k']
 fields={i for i,J,h,k in pairs};sources={J for i,J,h,k in pairs};Jof={i:J for i,J,h,k in pairs};Hof={i:h for i,J,h,k in pairs};Kof={i:k for i,J,h,k in pairs}
 def elem(n,j=()):
  if isinstance(n,str):n=A.index[n]
  return {(0,((n,j),)):ONE}
 def rows(rr):return A.rows(rr,explicit_g=False)
 def mul(*pp):
  out={(0,()):ONE}
  for p in pp:out=A.product(out,p)
  return out
 def summary(p):return {'g_word_positions':len(p),'field_words':len({w for g,w in p}),'sha256_exact_cells':A.fingerprint(p)}
 def pack(p):
  cs=[];idx={};out=[]
  for(g,w),co in sorted(p.items()):
   if co not in idx:idx[co]=len(cs);cs.append([[*k,v.numerator,v.denominator] for k,v in co])
   out.append([g,[[n,list(j)] for n,j in w],idx[co]])
  return {'coefficients':cs,'monomials':out,**summary(p)}
 def D(p,mu):
  out={}
  for(g,w),co in p.items():
   for at,(n,j) in enumerate(w):
    ww,sg=A.canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
    if sg:put(out,(g,ww),scale_coefficient(co,sg))
  return out
 def DD(p,j):
  for mu in j:p=D(p,mu)
  return p
 def grad(p):
  out={}
  for(g,w),co in p.items():
   pref=0
   for at,(n,j) in enumerate(w):
    put(out.setdefault((n,j),{}),(g,w[:at]+w[at+1:]),scale_coefficient(co,(-1)**(A.parities[n]*pref)));pref+=A.parities[n]
  return {k:v for k,v in out.items() if v}
 def EL(p,domain):
  out={n:{} for n in domain}
  for(n,j),pp in grad(p).items():
   if n in domain:
    for k,c in scale(DD(pp,j),(-1)**len(j)).items():put(out[n],k,c)
  return out
 def op(p,v,odd=False):
  out={}
  if role=='replay':
   for(n,j),df in grad(p).items():
    if v.get(n):
     for k,c in mul(DD(v[n],j),df).items():put(out,k,c)
  else:
   cache={}
   for(g,w),co in p.items():
    pref=0
    for at,(n,j) in enumerate(w):
     if v.get(n):
      if(n,j) not in cache:cache[n,j]=DD(v[n],j)
      pp=mul({(g,w[:at]):scale_coefficient(co,(-1)**pref if odd else 1)},cache[n,j],{(0,w[at+1:]):ONE})
      for k,c in pp.items():put(out,k,c)
     pref+=A.parities[n]
  return out
 def sub(p,mp):
  out={}
  for(g,w),co in p.items():
   pp={(g,()):co}
   for n,j in w:pp=mul(pp,DD(mp.get(n,elem(n)),j))
   for k,c in pp.items():put(out,k,c)
  return out
 def mat(pkt):
  m=s.zeros(*pkt['shape'])
  for i,j,z in pkt['entries']:m[i,j]=s.sympify(z)
  return m
 def coeff(z):return rows([{'coefficient':str(z),'word':[]}])
 def old_hash(p):
  g,xi,eh=s.symbols('g10 xi eta_H');cache={};out={}
  for(gp,w),cc in p.items():
   if cc not in cache:
    z=0
    for(x,h,mask),v in cc:z+=s.Rational(v.numerator,v.denominator)*xi**x*eh**h*s.prod(s.sqrt(prime) for b,prime in enumerate([2,3,5,7]) if mask&(1<<b))*(s.I if mask&16 else 1)
    cache[cc]=z
   ww=tuple((A.names[n],j) for n,j in w);out[ww]=out.get(ww,0)+g**gp*cache[cc]
  rr=[{'word':[n+('__'+''.join(map(str,j)) if j else '') for n,j in w],'coefficient':clean_string(c)} for w,c in sorted(out.items()) if c!=0]
  return sha256(json.dumps(rr,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 @lru_cache(None)
 def clean_string(c):return str(s.simplify(c))
 # Complete coarse typing, including all possible positive coefficient grades.
 types={'B':(1,0,0,0),'x':(1,0,0,0),'A':(1,0,0,0),'C':(1,1,1,0),'a':(1,-1,1,0),'L':(2,0,0,0),'JB':(2,-1,1,1),'Jx':(2,-1,1,1),'JC':(2,-2,0,1),'Ja':(2,0,0,1),'JL':(1,-1,1,1)}
 patterns=[]
 for degree in range(2,4):
  for words in combinations_with_replacement(sorted(types),degree):
   ds,gh,pa,ns=[sum(types[n][i] for n in words) for i in range(4)]
   if ns>=2 and ds<=3 and gh==-1 and pa%2==1:
    for jets in range(4-ds):patterns.append([list(words),jets,3-ds-jets])
 assert patterns==[[['JL','Ja'],0,0],[['C','JL','JL'],0,0]],patterns
 e1=get('e1');e2=get('e2');e3=get('e3');nm=get('regularity')['nonminimal'];old=get('retract')['cochain_controls']['basic_closed_counterterm_controls']['source_quadratic']
 N={A.index[n]:rows(rr) for n,rr in nm['point_maps'].items()};sh={A.index[n]:rows(rr) for n,rr in e2['source_shifts'].items()};U={n:plus(elem(n),pp) for n,pp in sh.items()}
 q={i:rows(data['master_field_maps'][A.names[i]]) for i in fields}
 needed={A.index[('Jb' if i<12 else 'JL')+str(i)] for i in range(45)}|{A.index[('Jbar' if i<12 else 'Jub')+str(i)] for i in range(45)}
 Q={**q,**{J:rows(e2['complete_columns'][A.names[J]]['source_polynomial']) for J in needed}}
 assert all(not rr or any(w for g,w in rr) for rr in q.values())
 print('STAGE '+role+' complete_two_source_types_and_actual_transported_basic_primitive',flush=True)
 # Actual invariant beta-chart pairing. Source carrier comes from the sealed
 # background action; the two routes contract in different orders.
 beta={};metrics={}
 for block,ids,aux,anti in [('light_primal',range(12),'b','bar'),('heavy_dual',range(12,45),'L','ub')]:
  ids=list(ids);S=mat(e1['charts']['blocks'][block]['source_embedding']);Gs=(S.T*S).applyfunc(s.simplify);metrics[block]=Gs
  jb=[elem('J'+aux+str(i)) for i in ids];je=[elem('J'+anti+str(i)) for i in ids];cy=[]
  for i in ids:
   tc=rows(e3['operators']['Tb_geometric_and_transported']['J'+aux+str(i)]);cmap={A.index['omega'+str(h)]:elem('C'+str(h)) for h in range(12)}
   if role=='primary':
    cp={}
    for(gp,word),co in tc.items():
     assert len(word)==2 and not any(j for n,j in word)
     js=[n for n,j in word if n in sources];oms=[n for n,j in word if n in cmap];assert len(js)==len(oms)==1 and A.parities[js[0]]==1
     term=mul({(gp,()):co},cmap[oms[0]],elem(js[0]))
     for key,z in term.items():put(cp,key,z)
    cy.append(cp)
   else:
    assert all(len(word)==2 and word[0][0] in sources and word[1][0] in cmap for gp,word in tc)
    cy.append(scale(sub(tc,cmap),-1))
  if role=='primary':
   yy=[plus(ee,scale(cc,-1)) for ee,cc in zip(je,cy)]
   beta[block]=plus(*(mul(coeff(z),jb[i],yy[j]) for(i,j),z in Gs.todok().items()))
  else:
   beta[block]=plus(*(plus(mul(coeff(z),jb[i],je[j]),scale(mul(coeff(z),jb[i],cy[j]),-1)) for(i,j),z in Gs.todok().items()))
 Kb=plus(*beta.values());KD=sub(Kb,N);K=sub(KD,U);assert all(n not in sources or n in needed for g,w in K for n,j in w)
 actual_hash=old_hash(K);assert actual_hash==old['primitive_sha256'],('OLD_KSRC_HASH',summary(K),actual_hash,old['primitive_sha256'])
 Fp=op(K,Q,True);assert old_hash(Fp)==old['counterterm_sha256'],('OLD_QKSRC_HASH',summary(Fp))
 assert len({w for g,w in K})==3890 and len({w for g,w in Fp})==47411
 def source_degree(w):return sum(n in sources for n,j in w)
 Kdeg={d:{k:c for k,c in K.items() if source_degree(k[1])==d} for d in range(3)};assert all(Kdeg.values())
 Dh=lambda p:A.action(p,Hof,'slot' if role=='primary' else 'left');Dk=lambda p:A.action(p,Kof,'slot' if role=='primary' else 'left');Hess=lambda p:Dk(Dh(p))
 def analyze(label,G,full=False):
  gf=grad(G);unknown={n for n,j in gf if n not in Q};assert not unknown,(label,'MISSING_Q',unknown)
  qG=op(G,Q,True);HH=Hess(G);HQ=Hess(qG);groups=[{} for i in range(4)]
  for(n,j),df in gf.items():
   qr=DD(Q[n],j);parts=[mul(Hess(qr),df),mul(Dh(qr),Dk(df)),mul(Dk(qr),Dh(df)),mul(qr,Hess(df))]
   for bucket,pp in zip(groups,parts):
    for k,c in pp.items():put(bucket,k,c)
  assert plus(*groups)==HQ,(label,'FOUR_HESSIAN_LEGS')
  for probe in [u,rho]:
   pg=mul(elem(probe),G);hpg=Hess(pg);ev=EL(pg,fields|sources);assert all(any(n==probe for n,j in w) for pp in ev.values() for g,w in pp)
   if probe==rho:assert op(pg,Q,True)==scale(mul(elem(rho),qG),-1)
   else:assert op(pg,Q,True)==mul(elem(u),qG)
   assert all(any(n==probe for n,j in w) for g,w in hpg)
  ef=EL(G,fields);ej=EL(G,sources);v={i:scale(ej[Jof[i]],-(-1)**A.parities[i]) for i in fields};vj={Jof[i]:scale(ef[i],(-1)**A.parities[i]) for i in fields}
  trace={}
  for i,pp in v.items():
   for(n,j),df in grad(pp).items():
    if n==i:
     for k,c in scale(df,(-1)**A.parities[i]).items():put(trace.setdefault(j,{}),k,c)
  assert all(not p for p in trace.values()),(label,'FLAT_FIELD_SUPERDIV_NOT_ZERO')
  hr=Hess(mul(elem(rho),G));hop=EL(hr,set(Hof.values()));hbase=EL(HH,set(Hof.values()));rhojets=0
  for i in fields:
   delta=plus(hop[Hof[i]],scale(mul(elem(rho),hbase[Hof[i]]),-(-1)**A.parities[i]))
   if delta:rhojets+=len(delta);assert all(any(n==rho and j for n,j in w) for g,w in delta),(label,'RHO_ADJOINT')
  qsource=plus(*(mul(DD(Q[n],j),df) for(n,j),df in gf.items() if n in sources));qfield=plus(qG,scale(qsource,-1))
  source0=lambda p:{k:c for k,c in p.items() if not any(n in sources for n,j in k[1])}
  early=plus(source0(qG),scale(op(source0(G),Q,True),-1))
  return {'G':summary(G),'QG':summary(qG),'H_G':summary(HH),'H_QG':summary(HQ),'four_Hessian_groups':[summary(p) for p in groups],'nonzero_Hessian_omission_controls':[bool(p) for p in groups],'nonzero_field_flow_columns':sum(bool(p) for p in v.values()),'nonzero_source_flow_columns':sum(bool(p) for p in vj.values()),'all1286_flow_columns_and_zero_complement_derived':True,'flat_field_superdivergence_zero_without_BV_source_cancellation':True,'Q_source_Euler_leg':summary(qsource),'Q_field_Euler_leg':summary(qfield),'early_source0_defect':summary(early),'rho_adjoint_derivative_positions':rhojets,'full_kernel_field_labels':sorted({A.names[n] for g,w in HH for n,j in w if n in fields}), 'G_packet':pack(G) if full else None}
 facts={'actual_basic_Ksrc':analyze('actual_basic_Ksrc',K,True)}
 fixture_base={
  'light_JLJa':mul(elem('Jb0'),elem('Jbar0')),
  'heavy_JLJa':mul(elem('JL13'),elem('Jub14')),
  'light_JLJLC':mul(elem('Jb0'),elem('Jb1'),elem('C12')),
  'heavy_JLJLC':mul(elem('JL13'),elem('JL14'),elem('C12'))}
 for label,G0 in fixture_base.items():facts[label]=analyze(label,sub(G0,U))
 assert any(v['rho_adjoint_derivative_positions'] for v in facts.values()) and facts['actual_basic_Ksrc']['early_source0_defect']['g_word_positions']
 assert not mul(elem('JL13'),elem('JL13'),elem('C12'))
 assert all(sum(n in sources for n,j in w)==2 for g,w in KD)
 omittedU=plus(Hess(K),scale(Hess(KD),-1));assert omittedU
 omitted2=plus(Fp,scale(op(plus(Kdeg[0],Kdeg[1]),Q,True),-1));assert omitted2
 assert not Hess(Kdeg[2]),'ORDINARY_KERNEL_IS_INSENSITIVE_TO_REMOVING_TOP_SOURCE_DEGREE'
 print('STAGE '+role+' common_probe_labels_and_source_derivative_controls',flush=True)
 # Independent momentum labels, including a source-dependent tangent.
 routing=[]
 for n in range(2,7):
  M=s.zeros(n)
  for i in range(n):M[i,0]=1
  for i in range(1,n):
   for j in range(1,i+1):M[i,j]=1
  assert M.det()==1;routing.append({'labeled_nodes':n,'routing_determinant':1,'ordinary_bound':2,'one_old_tangent_bound':3})
 x=s.Symbol('x',real=True);V=x*x+x**4/4;ff=x*x;HH=s.diff(V,x,2)
 twolegs=s.simplify((s.diff(V,x)*s.diff(ff,x,2)+s.diff(V,x,3)*ff)/(2*HH));raw=s.simplify(s.diff(s.diff(V,x)*ff,x,2)/(2*HH));dif=s.simplify(raw-twolegs)
 assert s.simplify(dif-s.diff(ff,x))==0 and twolegs.subs(x,1)==F(6,5) and raw.subs(x,1)==F(16,5)
 gaussian={'canonical_two_legs_at_x1':str(twolegs.subs(x,1)),'raw_Hessian_trace_at_x1':str(raw.subs(x,1)),'omitted_tangent_measure_response':str(dif.subs(x,1)),'external_source_derivative_required':True,'not_actual_Spin10_amplitude':True}
 result={'schema':'SOURCEQUADRATIC_PRIMITIVE_PROBE_V1','route':role,'scientific_disposition':'COMPLETE_TWO_SOURCE_CARRIER_FIRST_PROBE_QUANTUM_REPLACEMENT_IN_FIXED_FORMAL_EUCLIDEAN_ONE_LOOP_DOMAIN_PENDING_INDEPENDENT_VALIDATION','patterns':patterns,'old_primitive_serialized_hash':actual_hash,'old_counterterm_serialized_hash':old['counterterm_sha256'],'KD':summary(KD),'K_source_degrees':{str(d):summary(p) for d,p in Kdeg.items()},'families':facts,'controls':{'U_companion_Hessian_omission':summary(omittedU),'top_source_degree_QG_omission':summary(omitted2),'top_source_degree_G_Hessian_omission_insensitive':True,'repeated_odd_source_square_zero':True},'joint_routing':routing,'gaussian':gaussian,'old225_unlabeled_tangents_and_constant_sector_unchanged':True,'all_new_tangents_keep_probe_labels':True,'same_metric_lift_Tkappa_full_heat_power_Djet_and_IR_conversion_retained':True,'first_probe_identity':'I_QG=(Gamma1,G)+(S,I_G)','arbitrary_source_derivative_diagonals_or_multiple_Q_domain_claimed':False,'all_one_source_primitives_or_universal_quotient_classified':False,'full_E5_A5_or_physical_equivalence_claimed':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
if __name__=='__main__':main()
