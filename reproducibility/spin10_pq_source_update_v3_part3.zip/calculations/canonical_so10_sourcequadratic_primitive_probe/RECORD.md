# Two-source primitive sector: first-probe quantum replacement SQP1

Base f527745d/main. Previous goal turn PROGRESS. Question: can the complete
dimension3, ghost-number-1 odd TWO-SOURCE primitive sector be implemented by
the same formal Euclidean one-loop first-probe prescription, with its source
derivatives, rather than assumed from the classical nonminimal retract?

Freeze this record, derivation, code, controller and own-route inputs before
execution. Two sequential native routes, 120 seconds after imports each,
8GiB sampled private allocation,350MiB available-commit launch floor. Separate
180second verifier, same memory/floor. Package8MiB. Preserve failed/unfinished
sources and captures. No repeated old loop calculations or resource expansion.

Same643 integrated fields,643 BV sources,48 external backgrounds, polynomial
coupling/mass/width ring, ordinary currents, actual E1/E2/N coordinates and
physical reality. No inverse coupling or dimensional parameters. Sources are
external. Local even u and odd rho are independent Schwartz tracking probes;
only their linear terms and one Slavnov variation are retained. They are not
new integrated degrees of freedom or a new physical scheme.

Enumerate source-count>=2, project-dimension<=3, gh=-1, odd patterns from the
actual grades, nonnegative-dimensional coefficients and jets. Prove exactly
JL*Ja and JL*JL*C survive, with no derivative or dimensionful coefficient.
The JL pair is antisymmetric. General coefficient tensors are restricted by
the inherited real/background/Lorentz conditions, not fitted. Do not claim
their invariant ranks or all one-source/minimal cohomology are classified.

Reconstruct the old actual basic Ksrc using both inherited N and U maps,
actual H source carriers and bilinears. Match all3890 coefficients to the
old primitive hash. Its47411-position Q image is inherited qualified evidence,
not a new loop amplitude. Freshly derive its Q image and field/source flows,
ordinary field Hessian, full source-dependent chain, and the linear probe
master relation. Distinct routes must agree on exact coefficient fingerprints.
Physical508 Euler programs remain bound, not set to zero or re-expanded.

Also use light/heavy generator fixtures for both complete carrier types.
Keep full U companions, source differentiation before source0, Grassmann
signs, local probe jets, differentiated-source terms and ordinary currents.
Test omission of U companions, source-degree-two and source derivatives where
sensitive. A control insensitive in a projection is explicitly so classified.

The derivation must establish applicability to the actual augmented Hessian:
all new vertices/tangents keep probe/source labels; the old unlabeled225
tangents and constant support remain unchanged; common free-edge smoothing,
UV finite part before IR, fixed metric lift and finite heat/dimension-jet
conversion are retained. Source-dependent field maps are not simply changes
of integrated variables. Include both source/field Euler legs. A finite
Gaussian source-dependent control must detect the omitted tangent trace.

Success: uniform first-probe replacement for this COMPLETE two-source sector
and actual old basic witness in the specified prescription. Failure or missing
analytic/domain premise is reported explicitly; neither implies an anomaly.
Not a universal E5 quotient, arbitrary multiple-probe theorem, all-order/local
QAP, physical/global equivalence, or director acceptance. No older evidence,
policy, action, physical benchmark, project_state, authority or blocked stage
changes. No push/publication/outreach. Authority34/39; E5/A5 unqualified;
historical custody exit2/seven. Reuse broad audit by authenticated byte chain.
