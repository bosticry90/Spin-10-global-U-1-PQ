# Continuation V4: exact rejected carrier reconstruction retained

V1 failed at tuple/list setup; V2 at reversed expected census display order.
V3 reached the scientific primitive reconstruction and was rejected:4250
words differed from the immutable3890-position primitive. Its odd carrier
was wrong. These are three FAILED native executions, not three qualifications.

The actual even background rule has, for example,
Tb JL13 = g sqrt(2) i/2 JL13 omega1 + ... .
An even omega commutes with JL; replacing it after word canonicalization by
an odd ghost is not the operation g Dstar C JL. It gives JL C=-C JL.
The primary now extracts the even matrix coefficient and inserts C BEFORE JL.
Replay compensates the odd interchange in that particular two-factor column.
Every consumed column must have exactly one odd JL and one even omega.
This derives the sign from grading and the original beta Y definition, not
from the coefficient that would make a quantum identity vanish. Action,
reference, matrices and old expected hashes stay unchanged. V4 is a new frozen
bounded execution with the SAME120/180second and memory/package caps.
