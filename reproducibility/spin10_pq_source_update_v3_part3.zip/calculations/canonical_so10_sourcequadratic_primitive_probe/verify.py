"""Independent expanded-Fraction/right-gradient check;imports no SQP native."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations_with_replacement,product as cartesian
import json,gzip,sys,time,threading,os
import sympy as s
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_sourcequadratic_primitive_probe'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start()
vp=read(O/'validation_preparation.json')
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h,raw
def readonly(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('SQP_VERIFY_WRITE')
sys.addaudithook(readonly)
prep=read(O/'preparation_v5.json');a=read(O/'primary_v5_result.json');b=read(O/'replay_v5_result.json')
assert {k:v for k,v in a.items() if k not in ['route','elapsed_after_imports']}=={k:v for k,v in b.items() if k not in ['route','elapsed_after_imports']}
for role in ['primary','replay']:
 cap=read(O/(role+'_v5_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0
 for art in prep['artifacts'][role].values():assert digest(Path(art['path']))==art['sha256'] and digest(Path(art['receipt']))==art['receipt_sha256']
get=lambda lab:read(Path(prep['artifacts']['primary'][lab]['path']))
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry'];names=geo['names']+['sqp_u','sqp_rho'];par=geo['parities']+[0,1];index={n:i for i,n in enumerate(names)};u=index['sqp_u'];rho=index['sqp_rho'];pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};sources={J for i,J,h,k in pairs};canon=fields|sources;Jof={i:J for i,J,h,k in pairs};Hof={i:h for i,J,h,k in pairs};Kof={i:k for i,J,h,k in pairs}
g,xi,eta=s.symbols('g10 xi eta_H');loc={'g10':g,'xi':xi,'eta_H':eta,'reference_width_M':xi,'reference_width_H':eta};squares=[2,3,5,7,-1]
factors={(i,j):s.prod(squares[k] for k in range(5) if i&j&(1<<k)) for i in range(32) for j in range(32)};factors={k:int(v) for k,v in factors.items()}
def put(p,k,v):
 if not v:return
 p[k]=p.get(k,F(0))+v
 if not p[k]:del p[k]
def add(*pp):
 out={}
 for p in pp:
  for k,v in p.items():put(out,k,v)
 return out
def scaled(p,c):return {k:v*c for k,v in p.items() if v*c}
@lru_cache(None)
def canonical(w):
 out=[];sg=1
 for token in w:
  if par[token[0]] and token in out:return (),0
  at=len(out)
  while at and out[at-1]>token:
   if par[token[0]] and par[out[at-1][0]]:sg=-sg
   at-=1
  out.insert(at,token)
 return tuple(out),sg
def product(p,q):
 out={}
 for (gp,xp,hp,m,w),c in p.items():
  for (gq,xq,hq,n,v),d in q.items():
   word,sg=canonical(w+v)
   if sg:put(out,(gp+gq,xp+xq,hp+hq,m^n,word),c*d*(sg*factors[m,n]))
 return out
@lru_cache(None)
def coefficients(text):
 z=s.expand(s.sympify(text,locals=loc));out={}
 assert not z.has(s.Float) and z.free_symbols<={g,xi,eta}
 for powers,co in s.Poly(z,g,xi,eta).terms():
  for term in s.Add.make_args(s.expand(co)):
   rat,rest=term.as_coeff_Mul(rational=True);assert rat.is_Rational;number=F(int(rat.p),int(rat.q));mask=0
   for factor in s.Mul.make_args(rest):
    if factor==s.I:mask^=16
    elif factor.is_Rational:number*=F(int(factor.p),int(factor.q))
    else:
     assert factor.is_Pow and factor.exp==s.Rational(1,2) and factor.base.is_Integer and factor.base>0,factor
     value=int(factor.base)
     for bit,prime in enumerate(squares[:4]):
      exponent=0
      while value%prime==0:value//=prime;exponent+=1
      number*=prime**(exponent//2)
      if exponent%2:mask^=1<<bit
     assert value==1
   put(out,(*powers,mask),number)
 return tuple(out.items())
def token(t):
 n,_,j=t.partition('__');return index[n],tuple(map(int,j))
def rows(rr):
 out={}
 for row in rr:
  w=tuple(map(token,row['word']));assert canonical(w)==(w,1)
  for (gp,xp,hp,m),v in coefficients(row['coefficient']):
   if 'g' in row:assert gp==0;gp=row['g']
   put(out,(gp,xp,hp,m,w),v)
 return out
def unpack(packet):
 out={}
 for gp,word,cid in packet['monomials']:
  w=tuple((n,tuple(j)) for n,j in word);assert canonical(w)==(w,1)
  for xp,hp,m,num,den in packet['coefficients'][cid]:put(out,(gp,xp,hp,m,w),F(num,den))
 return out
def elem(n,j=()):
 if isinstance(n,str):n=index[n]
 return {(0,0,0,0,((n,j),)):F(1)}
def D(p,mu):
 out={}
 for(gp,xp,hp,m,w),v in p.items():
  for at,(n,j) in enumerate(w):
   word,sg=canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
   if sg:put(out,(gp,xp,hp,m,word),v*sg)
 return out
def DD(p,j):
 for mu in j:p=D(p,mu)
 return p
def gradient(p):
 out={}
 for(gp,xp,hp,m,w),v in p.items():
  total=sum(par[n] for n,j in w)%2
  for at,(n,j) in enumerate(w):
   suffix=sum(par[t] for t,k in w[at+1:]);sg=(-1)**((par[n]*suffix+par[n]*(total-par[n]))%2);put(out.setdefault((n,j),{}),(gp,xp,hp,m,w[:at]+w[at+1:]),v*sg)
 return out
def EL(p,domain):
 out={n:{} for n in domain}
 for(n,j),df in gradient(p).items():
  if n in domain:out[n]=add(out[n],scaled(DD(df,j),(-1)**len(j)))
 return out
def vector(p):
 el=EL(p,canon);v={}
 for i in fields:v[i]=scaled(el[Jof[i]],-(-1)**par[i]);v[Jof[i]]=scaled(el[i],(-1)**par[i])
 return v
def operation(images,odd=False):
 images={n:p for n,p in images.items() if p};cache={}
 def act(p):
  out={}
  for(gp,xp,hp,m,w),c in p.items():
   total=sum(par[n] for n,j in w)%2
   for at,(n,j) in enumerate(w):
    if n not in images:continue
    if(n,j) not in cache:cache[n,j]=DD(images[n],j)
    suffix=sum(par[t] for t,k in w[at+1:]);sg0=(-1)**((par[n]*suffix+(total+par[n] if odd else 0))%2);rest=w[:at]+w[at+1:]
    for(gq,xq,hq,mask,repl),v in cache[n,j].items():
     word,sg=canonical(rest+repl)
     if sg:put(out,(gp+gq,xp+xq,hp+hq,m^mask,word),c*v*(sg0*sg*factors[m,mask]))
  return out
 return act
def collapsed(p):
 out={}
 for(gp,xp,hp,m,w),v in p.items():out.setdefault((gp,w),{})[xp,hp,m]=v
 return out
def summary(p):
 h=sha256();h.update(b'[');cc=collapsed(p)
 for i,((gp,w),co) in enumerate(sorted(cc.items())):
  if i:h.update(b',')
  row=[gp,[[names[n],list(j)] for n,j in w],[[list(k),str(v)] for k,v in sorted(co.items())]];h.update(json.dumps(row,separators=(',',':'),ensure_ascii=True).encode())
 h.update(b']');return {'g_word_positions':len(cc),'field_words':len({w for gp,w in cc}),'sha256_exact_cells':h.hexdigest()}

def mul(*pp):
 out={(0,0,0,0,()):F(1)}
 for p in pp:out=product(out,p)
 return out
def subst(p,images):
 out={}
 for(gp,xp,hp,m,w),c in p.items():
  pp={(gp,xp,hp,m,()):c}
  for n,j in w:pp=product(pp,DD(images.get(n,elem(n)),j))
  out=add(out,pp)
 return out
def scalar(z):return rows([{'word':[],'coefficient':str(z)}])
e1=get('e1');e2=get('e2');e3=get('e3');nm=get('regularity')['nonminimal'];old=get('retract')['cochain_controls']['basic_closed_counterterm_controls']['source_quadratic']
N={index[n]:rows(pp) for n,pp in nm['point_maps'].items()};U={index[n]:add(elem(n),rows(pp)) for n,pp in e2['source_shifts'].items()}
Q={i:rows(data['master_field_maps'][names[i]]) for i in fields}
needed={index[('Jb' if i<12 else 'JL')+str(i)] for i in range(45)}|{index[('Jbar' if i<12 else 'Jub')+str(i)] for i in range(45)}
Q.update({J:rows(e2['complete_columns'][names[J]]['source_polynomial']) for J in needed});Q.update({index[f'A{i}_{mu}']:{} for i in range(12) for mu in range(4)})
q=operation(Q,True);Dh=operation({i:elem(Hof[i]) for i in fields});Dk=operation({i:elem(Kof[i]) for i in fields});H=lambda p:Dk(Dh(p))
print('STAGE verifier independent_expanded_source_carriers_and_full_U_transport',flush=True)
Kb={}
for block,ids,aux,anti in [('light_primal',range(12),'b','bar'),('heavy_dual',range(12,45),'L','ub')]:
 ids=list(ids);pkt=e1['charts']['blocks'][block]['source_embedding'];S=s.zeros(*pkt['shape'])
 for i,j,z in pkt['entries']:S[i,j]=s.sympify(z)
 M=(S.T*S).applyfunc(s.simplify)
 for ai,i in enumerate(ids):
  for bj,j in enumerate(ids):
   if M[ai,bj]==0:continue
   y=elem('J'+anti+str(j));tc=rows(e3['operators']['Tb_geometric_and_transported']['J'+aux+str(j)])
   # Independently extract the matrix;never substitute an odd object for an
   # even omega inside the canonical word.
   for(gp,xp,hp,mask,w),v in tc.items():
    jj=[n for n,I in w if n in sources];oo=[n for n,I in w if names[n].startswith('omega')]
    assert len(w)==2 and len(jj)==len(oo)==1
    h=int(names[oo[0]][5:]);yp=mul({(gp,xp,hp,mask,()):v},elem('C'+str(h)),elem(jj[0]));y=add(y,scaled(yp,-1))
   Kb=add(Kb,mul(scalar(M[ai,bj]),elem('J'+aux+str(i)),y))
KD=subst(Kb,N);K=subst(KD,U);native=a['families']['actual_basic_Ksrc'];assert K==unpack(native['G_packet'])
assert summary(K)==native['G'] and summary(KD)==a['KD'];assert summary(K)['field_words']==3890
qK=q(K);assert summary(qK)==native['QG'] and summary(qK)['field_words']==47411
assert a['old_primitive_serialized_hash']==old['primitive_sha256'] and a['old_counterterm_serialized_hash']==old['counterterm_sha256']
typ={'JB':(2,-1,1),'Jx':(2,-1,1),'JC':(2,-2,0),'Ja':(2,0,0),'JL':(1,-1,1)};ft={'B':(1,0,0),'A':(1,0,0),'x':(1,0,0),'C':(1,1,1),'a':(1,-1,1),'L':(2,0,0)};patterns=[]
for scount in [2,3]:
 for sw in combinations_with_replacement(sorted(typ),scount):
  sd,sg,sp=[sum(typ[t][i] for t in sw) for i in range(3)]
  if sd>3:continue
  for fw in [()]+[(x,) for x in ft]:
   d=sd+sum(ft[t][0] for t in fw);gh=sg+sum(ft[t][1] for t in fw);pa=sp+sum(ft[t][2] for t in fw)
   if d<=3 and gh==-1 and pa%2==1:
    for jets in range(4-d):patterns.append([sorted(sw+fw),jets,3-d-jets])
assert sorted(patterns)==sorted(a['patterns']) and len(patterns)==2
print('STAGE verifier direct_right_gradient_full_Hessians_and_local_probes',flush=True)
fixtures={'actual_basic_Ksrc':K,'light_JLJa':subst(mul(elem('Jb0'),elem('Jbar0')),U),'heavy_JLJa':subst(mul(elem('JL13'),elem('Jub14')),U),'light_JLJLC':subst(mul(elem('Jb0'),elem('Jb1'),elem('C12')),U),'heavy_JLJLC':subst(mul(elem('JL13'),elem('JL14'),elem('C12')),U)}
for label,G in fixtures.items():
 f=a['families'][label];qG=q(G);hg=H(G);hq=H(qG)
 for p,key in [(G,'G'),(qG,'QG'),(hg,'H_G'),(hq,'H_QG')]:assert summary(p)==f[key],(label,key)
 for probe in [u,rho]:
  pg=mul(elem(probe),G);expected=scaled(mul(elem(probe),qG),1 if probe==u else -1);assert q(pg)==expected
  for pp in EL(pg,canon).values():assert all(any(n==probe for n,j in w) for gp,xp,hp,m,w in pp)
 v=vector(G);tr={}
 for i in fields:
  for(n,j),df in gradient(v[i]).items():
   if n==i:tr[j]=add(tr.get(j,{}),scaled(df,(-1)**par[i]))
 assert all(not z for z in tr.values())
 assert sum(bool(v[i]) for i in fields)==f['nonzero_field_flow_columns'] and sum(bool(v[Jof[i]]) for i in fields)==f['nonzero_source_flow_columns']
 zeroJ=lambda p:{key:c for key,c in p.items() if not any(n in sources for n,j in key[-1])}
 assert summary(add(zeroJ(qG),scaled(q(zeroJ(G)),-1)))==f['early_source0_defect']
 if label!='actual_basic_Ksrc':
  groups=[{} for _ in range(4)]
  for(n,j),df in gradient(G).items():
   qr=DD(Q[n],j)
   for k,pp in enumerate([mul(H(qr),df),mul(Dh(qr),Dk(df)),mul(Dk(qr),Dh(df)),mul(qr,H(df))]):groups[k]=add(groups[k],pp)
  assert add(*groups)==hq
  for p,expected in zip(groups,f['four_Hessian_groups']):assert summary(p)==expected
 # Density polarization alone is not the functional Hessian: compare its
 # complete first-polarization Euler covector,including derivative-rho terms.
 hr=H(mul(elem(rho),G));op=EL(hr,set(Hof.values()));base=EL(hg,set(Hof.values()));count=0
 for i in fields:
  defect=add(op[Hof[i]],scaled(mul(elem(rho),base[Hof[i]]),-(-1)**par[i]));count+=len(collapsed(defect))
  assert all(any(n==rho and j for n,j in w) for gp,xp,hp,m,w in defect)
 assert count==f['rho_adjoint_derivative_positions']
print('STAGE verifier sensitive_omissions_and_graded_means',flush=True)
degree=lambda w:sum(n in sources for n,j in w)
lo={k:c for k,c in K.items() if degree(k[-1])<2};top={k:c for k,c in K.items() if degree(k[-1])==2}
assert not H(top) and summary(add(H(K),scaled(H(KD),-1)))==a['controls']['U_companion_Hessian_omission']
assert summary(add(qK,scaled(q(lo),-1)))==a['controls']['top_source_degree_QG_omission']
assert a['controls']['top_source_degree_QG_omission']['g_word_positions']>0
assert not mul(elem('JL13'),elem('JL13'),elem('C12'))
x=s.symbols('x');V=x*x+x**4/4;ff=x*x;HH=s.diff(V,x,2);I=ff.diff(x,2)/(2*HH);QIG=V.diff(x)*I;other=HH.diff(x)*ff/(2*HH);raw=s.diff(V.diff(x)*ff,x,2)/(2*HH)
assert s.simplify(raw-QIG-other-ff.diff(x))==0 and (QIG+other).subs(x,1)==s.Rational(6,5) and raw.subs(x,1)==s.Rational(16,5)
assert a['gaussian']['omitted_tangent_measure_response']=='2'
weights={1:-2,2:5,3:-4,4:1};assert sum(weights.values())==0 and sum(s.Rational(c,n) for n,c in weights.items())==-s.Rational(7,12)
assert s.expand_log(-sum(c*s.log(n) for n,c in weights.items())-s.log(s.Rational(81,128)),force=True)==0
for n in range(2,7):
 M=s.Matrix([[1]+[int(j<=i) for j in range(1,n)] for i in range(n)]);assert M.det()==1
assert a['old225_unlabeled_tangents_and_constant_sector_unchanged'] and not a['all_one_source_primitives_or_universal_quotient_classified'] and not a['full_E5_A5_or_physical_equivalence_claimed']
# The proof review covers general tensor coefficients and the common marked
# trace domain; finite components alone are not an analytic theorem.
result={'schema':'SOURCEQUADRATIC_PRIMITIVE_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':'QUALIFIED_COMPLETE_TWO_SOURCE_PRIMITIVE_FIRST_PROBE_REPLACEMENT_IN_SPECIFIED_FORMAL_EUCLIDEAN_ONE_LOOP_FAMILY_ONLY','method':'Independent expanded rational/radical right-gradient and ordered word construction;no new native import.','all3890_actual_primitive_coefficients_and47411_Q_image_checked':True,'all5_families_direct_full_field_Hessians_and_source_flows_checked':True,'all4_actual_HQ_groups_freshly_recomputed':False,'actual_four_group_identity_review':'Native distinct prefix/left-gradient agreement plus general polarized product proof;verifier freshly recomputes actual full HQ and all four fixture groups.','complete_two_source_type_proof_reviewed':True,'general_first_probe_master_Hessian_and_joint_IR_lift_applicability_reviewed':True,'source0_U_and_source_degree_controls_sensitive_in_stated_scopes':True,'top_source_degree_ordinary_G_Hessian_control_insensitive_disclosed':True,'Gaussian_bare_measure_defect_nonzero':'2','failed_native_workers_preserved':4,'failed_verifier_workers':0,'authority_changed':False,'full_E5_A5_or_physical_equivalence':False,'input_sha256':vp['input_sha256'],'elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
