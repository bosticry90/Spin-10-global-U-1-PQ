# UTS1: the actual finite one-tau insertion identity

Base9d3f2307/main. Previous goal turn PROGRESS: qualified IRS1, not full E5.
Question: does the ACTUAL paired C_tau insertion, with prescribed shared
critical extension, satisfy Q A_tau+(F_kappa,C_tau)=0, rather than just have
a Q-closed logarithmic residue? This addresses a real unit-map prerequisite;
it does not replace original W6 adequacy by the easier exact tau direction.

Types: same643 fields, full sources,48 H backgrounds, real polynomial coupling/
width ring, positive computational reference masses, Euclidean Schwartz mean
fields. Finite Born/background order only; no inverse physical mass/coupling,
infinite resummation, changed physical vacuum or global translation of the
Schwartz configuration space. Keep full physical QJ and Euler programs.

Inputs: qualified OSP1 local one-source first-probe theorem, PTR1 actual full
action/marked pairing, CRV1 first-Q/source-commutator support, CCM1 covariant
critical ghost-root match, IRS1 whole-residue closure, actual N/D/tau, full
metric-lift/finite heat/Stokes prescription and original E5 boundaries. All
receipts and immutable bytes bound before calculation. No expensive broad
loop replay. Reuse the complete365 translated physical Hessian programs;
do not pretend to remeasure every scalar-potential tensor.

Least expensive competent method: prove the large Gaussian local-probe to
unit-root matching for the complete marked family using a joint soft split.
Compute the universal bubble constant twice (Schwinger Gaussian determinant
and coordinate heat-Green convolution), with sensitive finite profile and
dilation contacts. Reconstruct actual source partners/physical mass vector,
check their zero complement and subcritical support. Use the existing local
Ward theorem only on Schwartz probes; pass to the unit map only AFTER the
matching/commutation proof. No fitted contact or Ward coefficient.

Primary/replay: distinct integrals and exact actual-data contractions. Separate
verifier imports no new native helper, independently checks the analytic
assumptions, normalization, controls and actual-input completeness. Finite
diagnostics are not a replacement for the all-finite-order proof.

Acceptance: Gaussian adiabatic finite part and E_d prescribed map differ ONLY
by the derived finite multiple of the complete P_tau, with same UV conversion,
reference determinant and tadpole densities. The first-Q expansion commutes
with this finite part; all source-commutator/probe-jet terms on the bracket
side have their actual common domain and limit. IRS QP_tau=0 then gives the
unit Ward law. If any finite defect or missing premise remains, preserve it
and do not assert the theorem. Keep derivative delta contacts.

Controls: missing IR logarithm, wrong finite matching constant, same-unit
profile change, a nonzero dilation/probe boundary contact, ordinary p² versus
critical root, noncommuting ordered-word differentiation, omitted physical
source constants and wrong odd trace/factor1/2. Disclose insensitive controls.

Caps:120s after imports per native route,180s independent,8GiB sampled private,
350MiB available-commit launch floor,8MiB package. Freeze before execution;
preserve failures and version corrections. No automatic resource expansion.

Outcomes: qualified finite one-tau law in stated domain; complete nonzero
defect; exact underdefinition; or incomplete. Do not tune d,nu,kappa,b0.
Unit insertion means a constructed distributional replacement, not a global
physical field shift. Zero-label tadpoles stay coefficient densities, not
infinite-volume integrals. UV finite part BEFORE IR/adiabatic matching.

Ceiling: no all-W6 affinity/even-cocycle theorem, general multiple products,
QAP/measure/A5/E5, physical equivalence or blocked-stage activation. Authority
34of39/state113, seven flags false, custody2/seven, old failures/benchmarks/
stored functionals unchanged. Shared action/premises/software/AI author;
no Lean/expert/experiment. One read-only wrong-filename lookup during discovery,
corrected from the actual directory listing, is not a scientific worker failure.
