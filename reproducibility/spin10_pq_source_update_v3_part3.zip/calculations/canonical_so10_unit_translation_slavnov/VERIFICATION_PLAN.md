# Independent acceptance check UTS1

Read authenticated inputs and source/derivation, but read native answers only
after independent calculations. Reconstruct tau through the physical frame;
differentiate literal field-rule lists by a scalar lambda substitution rather
than the native exact-polynomial derivative. Compare all643 source-column
fingerprints and zero complement. Reconstruct the20 physical mass/source
constants and actual296-entry C/x kernel. Keep the full physical508 programs
and both inverse-congruence legs as inherited qualified premises.

Check the90-odd normalization and unit-extension convention. Derive the
Gaussian determinant/Frullani ratio, normalization, finite log and profile
constants, ordinary p² limit and nonzero dilation boundary. Independently
integrate the positive coordinate convolution. Use a varied-residue coupled
Gaussian family to detect omission of the subtraction's first variation.
Read/compare both native results only afterwards, including exact coefficients,
implicit zeros, numerical errors, scope/false flags and preserved failures.

Analytic review must establish all-finite-order smooth amputated amplitudes,
joint soft Taylor-remainder bounds, UV-FP-first locality, matched covariant
root convention, root-preserving Q continuity and subcritical source/probe-jet
limits. The old local theorem is used only with Schwartz probes. IRS closure
removes a measured finite matching multiple, not an uncomputed finite defect.
Tadpole coefficient densities and Gamma_ref remain. A finite integral fixture
cannot by itself establish this theorem or original all-W6 adequacy.

The matched Ward law is insensitive to a COMMON finite residue shift because
QP_tau=0. Therefore the separate nonzero integral/profile comparisons are
required to check the actual prescribed insertion map. Do not present the
zero Ward expression alone as a check of that map's finite constant.

Same180s,8GiB sampled private,350MiB launch floor and8MiB package caps. Two
native failures (field-name lookup and unsimplified equivalent logs) remain
FAILED; V3 completed both routes. One read-only navigation mistake is separate.
No action, physical assumption, authority, baseline or acceptance gate changes.
