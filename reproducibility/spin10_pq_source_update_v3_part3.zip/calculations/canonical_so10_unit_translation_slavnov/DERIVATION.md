# A unit insertion law requires matching, not formal Jacobi alone

Prospective. Requires actual support checks, two routes and independent review.
F_kappa denotes the previously qualified restored one-loop finite functional,
including its heat-placement, power, dimension-jet/local conversion and full
source dependence. It is not the stored partial874873-word polynomial.

## 1. Use the established theorem only inside its domain

For finite R, u_R(x)=exp(-|x|²/R²) is Schwartz. Put
K_R=-integral u_R J_x.tau, C_R=QK_R=-delta_(u_R tau) S, retaining currents.
K_R is linear in sources and independent of ordinary fields, so its ordinary
field Hessian and loop primitive correction vanish. The OSP1 first-probe
construction, with the full physical Euler/source operation and SAME finite
map, gives the actual marked insertion

 A_R=(F_kappa,K_R),
 Q A_R+(F_kappa,C_R)=0.

This uses the qualified LOCAL augmented-functional theorem. It does not apply
Jacobi to an unconstructed unit quantum bracket. Its field/source/heat pieces
are derived before source0; Gamma_ref[A] is retained and tau-inert.

## 2. Derive the universal large-probe constant without a new scheme

Use the Fourier convention already fixed in PDA. For positive a,b and
c=R²/4 define the UV-finite soft-test integral

 I_R(a,b)=integral dp dq/(2pi)^8 uhat_R(q-p)
                 exp(-a p²-b q²)/(p² q²).

The double Schwinger Gaussian determinant is AB+c(A+B), A>=a,B>=b. Thus

 I_R=c²/(16pi²) integral_a^infty dA integral_b^infty dB
                       [AB+c(A+B)]^-2
    =log[(a+c)(b+c)/(ab+c(a+b))]/(16pi²).

Independently the heat-smoothed Green kernel is
g_a(x)=[1-exp(-|x|²/(4a))]/(4pi²|x|²). The coordinate pairing
integral dx u_R g_a g_b gives the same result by radial Frullani integration.
These are two actual convergent calculations, not an assumed trace rotation.

Subtract log(R²nu²)/(16pi²). The finite part is

 I_ad=-log[4(a+b)nu²]/(16pi²).

The prescribed extension E_d on exp[-(a+b)p²] is

 I_unit=[d-1-gamma_E-log((a+b)nu²)]/(16pi²).

Hence I_unit-I_ad=c_d/(16pi²),
c_d=d-1-gamma_E+log4. No d is selected. For u_R,s=(1+s|x|²/R²)u_R,
I_R,s=I_R+(s/2)R partial_R I_R, so the finite part changes by s/(16pi²).
Both probes have pointwise limit1. Discarding this finite term is wrong.
The nonzero dilation control R partial_R I_R ->2/(16pi²) is retained.
It is NOT an admissible assertion that all derivative-probe terms vanish.

Multiplication by p² is different: -partial_a I_R tends
1/[16pi²(a+b)], the ordinary-root integral. No log or d remains. These
controls distinguish the critical diagonal from subcritical polynomial legs.
The actual90-odd contraction supplies the nonzero multiplier
T_N=(24370125/4)g10^8xi^4, not an unknown tuned for a cancellation.

## 3. Why this determines the whole finite-order matching

Separate each fixed marked word into a compact soft part at its marked root
and the already UV-subtracted hard/integrable remainder. The ONLY critical
constant translation channel is the actual ghost mass N. With a local probe,
its adjacent ghost momenta p,q are independent and coupled by uhat_R(q-p).
Amputate the other localized vertices first. At every finite Born/background
order their joint amplitude is smooth at p=q=0 in the remaining Schwartz
variables. This follows from the subcritical independent-node bounds and
the same constant-chain support, not from evaluating the nonlocal action
at zero external momentum. Multiple soft-node intersections remain integrable
as in PTR/CCM; no second critical tau mark is present.

Write the soft amplitude as its value at(0,0) times a Gaussian reference plus
its Taylor remainder. The remainder vanishes linearly in (p,q). Its diagonal
has scaling degree<=3 in four dimensions. Under simultaneous soft scaling
p,q=O(1/R), measure/approximate-identity factors leave O(1/R), with possible
finite logarithms. Away from that region, the split remainder is dominated
by the old ordinary-node Schwartz seminorm majorants. Partitioning the
regions |p| comparable to |q-p| and |p| larger supplies the same bound; for
the latter the mean-value remainder leaves integrable r^-3, with the tails
controlled by the Gaussian approximate identity. Thus it has the unique
ordinary diagonal limit, and changing the subtraction Gaussian changes both
definitions equally. Derivatives in other test momenta move onto localized
vertices and preserve this estimate. The only matching freedom is the
derived scalar constant times the root evaluation.

The complete root evaluation is exactly IRS's P_tau, including every ordinary,
source and background vertex. With the insertion's negative residue sign,

 A_ad=FP_R[A_R+log(R²nu²)P_tau/(16pi²)],
 A_tau=A_ad-c_d P_tau/(16pi²).

Same-unit deformed profiles change A_ad by -s P_tau/(16pi²), compensated by
their derived matching constant. These are formulae for the already prescribed
E_d family, not adoption of an adiabatic physical scheme or choice of d.
CCM's covariant root/spectral construction ensures the same statement for
the fixed Weyl witness. Its ordinary/reference profile offsets AND integrable
heat response are retained; substituting the reference inverse response for
an ordinary marked propagator would violate PTR and is forbidden here.

The soft split is UV-smoothing after external smearing. Every hard finite
heat/power/dimension-jet conversion is local; its tau/probe derivative has
the usual local limit, with all source currents. This proves matching AFTER
the original UV finite part, not an exchange of UV and IR limits. Pure
zero-label one-edge tadpoles are kept as coefficient density programs. Their
infinite-volume integrals are not taken or canceled by a logarithmic residue.

## 4. First-Q passage and the source commutator

Q does not vary the inert probe or root direction tau. On ordinary retained
labels it replaces fields by localized polynomials/jets; on sources the full
Euler rule has no constant at the original zero field. The ROOT-PRESERVING
variation therefore commutes with external smearing, its Taylor subtraction
and the seminorm convergence at a fixed finite coefficient, as in CRV. Vary
the complete residue before the limit; never omit Q of a subtraction.
IRS supplies the crucial identity Q P_tau=0 using the entire master-Hessian
congruence and boundary estimate, not QPi_A=0 or p delta=0 separately.
Consequently Q A_ad is the finite part of Q A_R, and the matching constant
does not change it.

For the other Ward term, (F,C_R) is generated by [Q,delta_(u_R tau)], not
by declaring that sources remain zero. Its ordinary directions are the
actual200 rules/432 positions, linear in localized fields/ghosts. Its physical
source direction has the genuine20 constants +M_scalar tau; their actual
weighted C/x Hessian kernel has296 nonzero positions in14760. Dressed endpoints
have pole2+0 or2+1, strictly below4. Those terms have no simultaneous N mark
at first tau order. All other coefficients remain localized. Probe jets
arising from physical kinetic/Euler currents are retained. In the complete
inverse-congruence grouping they multiply the same subcritical kernels; their
extra transfer momenta do not increase the poles. The Gaussian approximate
identity and its derivative distributions hence give their ordinary limit;
constant-probe gradients vanish only in THIS actually bounded sector.

This proves (F,C_R)->(F,C_tau) in the common first-variation domain. It does
not use naked products of inverses before grouping, nor erase the critical
div_p(p E_d)=delta_star/(8pi²) contact if an alternative momentum IBP is used.
The nonzero dilation control above tests precisely that potential error.

Taking the matched limit of the QUALIFIED local identity now yields

 Q A_tau+(F_kappa,C_tau)=0.

This is the second finite insertion law for this exact direction, constructed
from actual marked words and existing local identities. It is not inferred
from residue closure alone. No finite coefficient has been fitted. The same
proof permits arbitrary common d,nu,kappa with their correlated transport;
b0 remains distinct and undetermined.

## 5. Limits and next decision

This is one tau insertion and its first Ward/Slavnov descendant, at all finite
retained Born/background orders for the constructed reference witness. It is
not two independent tau/Q insertions, a full constant-strength determinant,
a global change of physical fields, or a Lorentzian/vacuum theorem. No claim
of zero unknown coefficient tensor is made independently of the operator proof.

After validation return explicitly to original W6/even-cocycle adequacy and
its affinity premise. Implementing this exact primitive cannot prove that
every W6 prescription has the conditional affine structure used by GHC/SSC.
W5/source products, QAP, general measure/equivalence and E5/A5 remain separate.
