# Independent verifier V2: use declared physical field names

Verifier V1 stopped before calculation because actual_tau_physical stores
physical field NAMES and coefficients, not integer indices. V2 maps those
names through the explicit canonical scalar order54+252+20+2 before applying
the full inverse frame. No native answer is used for that conversion. This
preserves the distinct literal-lambda derivation and every acceptance condition.
The failed verifier source/preparation/capture remain; native V3 is unchanged
and is not rerun. Same180s/memory/package limits. This was an avoidable schema
interpretation error, not a mathematical failure or a reason to weaken a gate.
