# Extension standard and scope comparison

Brunetti and Fredenhagen, *Microlocal Analysis and Interacting Quantum Field
Theories: Renormalization on Physical Backgrounds*, CMP208 (2000),
[original preprint, theorems5.2-5.3](https://arxiv.org/pdf/math-ph/9903028),
distinguish unique scaling-preserving extensions below the ambient dimension
from finite local ambiguities at or above it. At degree4 in four variables,
the ambiguity without additional derivative order is a delta term. This
matches the inherited E_d root language and the need to retain a finite
constant. The original was inspected on2026-10-19.

Those general point-extension theorems do not prove our joint p,q diagonal
limit or its Slavnov compatibility. UTS derives the Gaussian constant and
the actual model's first-Q/source limit separately. Nor is this Euclidean
root construction their Lorentzian time-ordered-product construction or a
full local QAP. Their hypotheses cannot be transferred merely by citation.

The nearer project comparators are PDA's nonzero adiabatic logarithm/profile
shift, PTR's action-derived marked pairing, OSP's local first-probe theorem,
CRV's first-Q/source bounds, CCM's fixed-witness spectral/root matching and
IRS's closure of the complete residue. UTS preserves their narrower historical
claims while proving the additional matching/first-descendant statement.

The action, classical master proof, complete Hessian programs, software,
reference family and AI author remain shared. This is bounded mathematical
corroboration, not external expert or empirical confirmation.
