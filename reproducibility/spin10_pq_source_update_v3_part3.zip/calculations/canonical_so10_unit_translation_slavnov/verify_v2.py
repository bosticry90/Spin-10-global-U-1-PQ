from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,gzip,sys,time,os,threading
import sympy as s
import mpmath as mp
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_unit_translation_slavnov';C=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
vp=read(O/'validation_preparation_v2.json')
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h,raw
assert digest(Path(__file__))==vp['verifier_sha256']
def guard(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('UTS_VERIFIER_READ_ONLY')
sys.addaudithook(guard);p=read(O/'preparation_v3.json');get=lambda n:read(Path(p['artifacts']['replay'][n]['path']))
g,xi,eta=s.symbols('g10 xi eta_H',real=True)
@lru_cache(None)
def ex(v):return s.sympify(v,locals={'g10':g,'xi':xi,'eta_H':eta,'reference_width_H':eta,'reference_width_M':xi})
mat=lambda pk:s.SparseMatrix(*pk['shape'],{(i,j):ex(v) for i,j,v in pk['entries']});clean=lambda M:s.MutableSparseMatrix(M.applyfunc(s.simplify))
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry'];A=Algebra(geo['names'],geo['parities']);fields=[i for i,J,h,k in geo['field_source_h_k']]
ref=get('core')['retained_reference'];names=ref['field_order'];pos={n:i for i,n in enumerate(names)};T=mat(ref['physical_to_raw_kernel']);Ti=mat(ref['physical_to_raw_inverse'])
print('STAGE independent_literal_lambda_translation_of_all_actual_source_rules',flush=True)
physpos={f'x_{sec}_{j}':180+offset+j for sec,n,offset in [('Phi',54,0),('Sigma',252,54),('phi',20,306),('S',2,326)] for j in range(n)}
tauphys=s.SparseMatrix(643,1,{(physpos[name],0):ex(v) for name,v in get('transport')['actual_tau_physical']});assert tauphys.nnz()==20
traw=clean(Ti*tauphys);dt={names[i]:v for(i,j),v in traw.todok().items()};lam=s.Symbol('lambda_translation');zz={};table={}
for i in fields:
 name=A.names[i];expression=s.S.Zero
 for row in data['master_field_maps'][name]:
  toks=row['word']
  if not any(t in dt for t in toks):continue
  term=ex(row['coefficient'])
  for token in toks:
   z=zz.setdefault(token,s.Symbol(token));term*=z+(lam*dt[token] if token in dt else 0)
  expression+=s.expand(term).coeff(lam,1)
 expression=s.expand(expression);active=sorted(expression.free_symbols & set(zz.values()),key=str);rows=[]
 if expression!=0:
  assert active
  for powers,co in s.Poly(expression,*active).terms():
   assert sum(powers)==1;token=str(active[powers.index(1)]);rows.append({'coefficient':str(s.expand(co)),'word':[token]})
 poly=A.rows(rows);table[name]={'positions':len(poly),'sha256':A.fingerprint(poly)}
assert table==get('paired')['all643_source_partner_table'] and sum(v['positions'] for v in table.values())==432
assert sum(bool(v['positions']) for v in table.values())==200
mPhi,mSigma,mphi,mS=s.symbols('mPhi2 mSigma2 mphi2 mS2',real=True);mass=[2*mPhi]*54+[2*mSigma]*252+[mphi]*20+[mS]*2
wphys=s.SparseMatrix(643,1,{(180+i,0):s.expand(mass[i]*tauphys[180+i]) for i in range(328) if tauphys[180+i]!=0});assert wphys.nnz()==20
wpack=[[i,str(s.expand(v))] for(i,j),v in sorted(wphys.todok().items())];wraw=clean(T.T*wphys)
cr=[pos[f'C{i}'] for i in range(45)];xr=[i for i,n in enumerate(names) if n.startswith('x_')];cg={names[v]:i for i,v in enumerate(cr)};xx={names[v]:i for i,v in enumerate(xr)};raw=defaultdict(lambda:s.S.Zero)
for(i,j),weight in wraw.todok().items():
 for row in data['master_field_maps'][names[i]]:
  tokens=row['word'];ct=[t for t in tokens if t in cg];xt=[t for t in tokens if t in xx];assert len(tokens)==2 and len(ct)==len(xt)==1
  raw[cg[ct[0]],xx[xt[0]]]+=weight*ex(row['coefficient'])
Nk=clean(Ti.extract(cr,list(range(553,598))).T*s.SparseMatrix(45,328,raw)*Ti.extract(xr,list(range(180,508))))
nr=[[i,j,str(s.expand(v))] for(i,j),v in sorted(Nk.todok().items())];nh=sha256(json.dumps(nr,separators=(',',':')).encode()).hexdigest();assert len(nr)==296 and nh==get('firstQ')['actual_source_constant_ghost_scalar_kernel_sha256']
print('STAGE independent_graded_reference_and_exact_soft_diagonal_matching',flush=True)
K=clean(Ti.T*mat(ref['reference_Hessian_raw_C3'])*Ti);pm=[s.Symbol(f'p0_ref{i}') for i in range(4)];D=clean(K[553:598,598:643].subs(dict(zip(pm,[s.I,0,0,0]))))
N=s.SparseMatrix(45,45,{(i,j):ex(v) for i,j,v in get('transport')['actual_ghost_mass_physical']});assert N.nnz()==57
z=s.zeros(45);HN=s.BlockMatrix([[z,N],[-N.T,z]]).as_explicit();GG=s.BlockMatrix([[z,-D.T.inv()],[D.inv(),z]]).as_explicit()
norm=s.factor(s.trace(GG*HN*GG*HN)/2);assert norm==s.Rational(24370125,4)*g**8*xi**4
a,b,c,nu=s.symbols('a b c nu',positive=True);d,shape=s.symbols('d shape',real=True)
rates=[1/(4*c),1/(4*c)+1/(4*a),1/(4*c)+1/(4*b),1/(4*c)+1/(4*a)+1/(4*b)]
ratio=s.factor(rates[1]*rates[2]/(rates[0]*rates[3]));F=s.log(ratio)
assert s.factor(ratio-(a+c)*(b+c)/(a*b+c*(a+b)))==0 and s.limit(ratio/c,c,s.oo)==1/(a+b)
ad=-s.log(4*(a+b)*nu**2);unit=d-1-s.EulerGamma-s.log((a+b)*nu**2);cd=d-1-s.EulerGamma+s.log(4)
assert s.simplify(s.expand_log(unit-ad-cd,force=True))==0
assert s.simplify(c*s.diff(F,c)+a*s.diff(F,a)+b*s.diff(F,b))==0
assert s.limit(c*s.diff(F,c),c,s.oo)==1 and s.simplify(a*s.diff(ad,a)+b*s.diff(ad,b))==-1
ordinary=s.factor(-s.diff(F,a));assert s.limit(ordinary,c,s.oo)==1/(a+b)
assert s.limit(shape*c*s.diff(F,c),c,s.oo)==shape
# A nonclosed artificial residue detects failure to vary the WHOLE subtraction.
# It is a diagnostic test family, not an actual new Spin10 symmetry amplitude.
theta=s.Symbol('theta',real=True);test=(2+theta)*F+theta**2*ordinary
residue=2+theta;finite=(2+theta)*ad+theta**2/(a+b)
matched=(2+theta)*unit+theta**2/(a+b)
assert s.simplify(matched-finite-residue*cd)==0
assert s.simplify(s.diff(matched-finite,theta)-s.diff(residue,theta)*cd)==0
assert s.diff(residue,theta)==1 # omission leaves log(RÂ²nuÂ²), not zero
softpowers=[['Taylor_remainder',3,0,1],['source_C_x',2,0,2],['source_C_B',3,0,1],['grouped_Rtau',2,0,2]]
jetpowers=[[pole,jets,4-pole+jets] for pole in [2,3] for jets in [1,2]];assert all(e[-1]>0 for e in softpowers+jetpowers)
print('STAGE independent_coordinate_Green_integral_and_varied_residue_limit',flush=True)
mp.mp.dps=60;errors=[];varied=[]
for av,bv,RR in [(2,3,4),(mp.mpf(3)/2,mp.mpf(7)/3,8),(2,3,16)]:
 av,bv,RR=map(mp.mpf,[av,bv,RR]);cv=RR**2/4
 observed=mp.quad(lambda y:mp.exp(-y/RR**2)*(-mp.expm1(-y/(4*av)))*(-mp.expm1(-y/(4*bv)))/y,[0,1,RR**2,mp.inf])/(16*mp.pi**2)
 expected=mp.log((av+cv)*(bv+cv)/(av*bv+cv*(av+bv)))/(16*mp.pi**2);err=abs(observed-expected);assert err<mp.mpf('1e-45');errors.append(mp.nstr(err,12))
 for th in [mp.mpf(1)/3,mp.mpf(2)/5]:
  h0=mp.mpf('1.5');d0=mp.mpf('1.4');cd0=d0-1-mp.euler+mp.log(4)
  A0=av*bv+cv*(av+bv);Jp=(bv+cv)/A0-1/(av+cv)
  rawvar=16*mp.pi**2*expected+2*th*Jp-mp.log(RR**2*h0**2)+cd0
  target=d0-1-mp.euler-mp.log((av+bv)*h0**2)+2*th/(av+bv)
  bound=(av+bv)/cv+2*abs(th)*abs(Jp-1/(av+bv));assert abs(rawvar-target)<=bound
  varied.append([mp.nstr(abs(rawvar-target),12),mp.nstr(bound,12)])
print('STAGE authenticate_native_comparisons_and_complete_analytic_review_scope',flush=True)
aa=read(O/'primary_v3_result.json');bb=read(O/'replay_v3_result.json');skip={'route','elapsed_after_imports','convergent_integral_tests'}
assert {k:v for k,v in aa.items() if k not in skip}=={k:v for k,v in bb.items() if k not in skip}
for ans in [aa,bb]:
 assert ans['actual643_source_partner_table']==table and ans['actual_partner_positions']==432 and ans['actual_partner_nonzero_rules']==200
 assert ans['actual_source_constant_physical_vector']==wpack and ans['actual_source_Cx_kernel_sha256']==nh and ans['actual_source_Cx_kernel_nonzero']==296 and ans['actual_source_Cx_kernel_zero']==14464
 assert s.simplify(ex(ans['actual_ghost_odd_normalization'])-norm)==0
 assert s.simplify(s.sympify(ans['gaussian_integral_16pi2'],locals={'a':a,'b':b,'c':c})-F)==0
 for key,want in [('adiabatic_finite_16pi2',ad),('prescribed_unit_16pi2',unit),('unit_minus_adiabatic_16pi2',cd),('same_unit_profile_finite_shift_16pi2',shape),('ordinary_p2_root_limit_16pi2',1/(a+b))]:
  val=s.sympify(ans[key],locals={'a':a,'b':b,'c':c,'nu':nu,'d':d,'shape':shape});assert s.simplify(s.expand_log(val-want,force=True))==0
 assert ans['joint_soft_remainder_decay_powers']==softpowers and ans['source_probe_jet_decay_powers']==jetpowers
 assert ans['dilation_contact_16pi2']==2 and s.simplify(ex(ans['nonzero_actual_dilation_control'])-norm/(8*s.pi**2))==0
 for row in ans['convergent_integral_tests']:
  av,bv,RR=map(mp.mpf,row[:3]);cv=RR**2/4;expected=mp.log((av+cv)*(bv+cv)/(av*bv+cv*(av+bv)))/(16*mp.pi**2)
  assert abs(mp.mpf(row[3])-expected)<mp.mpf('1e-40') and mp.mpf(row[4])<mp.mpf('1e-40') and 0<mp.mpf(row[5])<mp.mpf(row[6])
 assert not ans['analytic_scope']['all_W6_affinity_general_even_unit_cocycles_multiple_products_QAP_A5_E5_physical_scheme'] and not ans['authority_changed'] and not ans['stored_functional_changed']
assert get('irs')['complete_one_translation_IR_residue_Q_closed_in_retained_Euclidean_finite_Born_domain']
assert get('local')['one_probe_identity']=='I_QG=(Gamma1,G)+(S,I_G)' and get('local')['same_Tkappa_reference_heat_power_Djet_conversion']
assert get('ccm')['proof_scope']['subtraction_is_actual_covariant_zero_energy_bikernel_Psi_Pi0_Psi_dual']
for raw,h in vp['input_sha256'].items():assert digest(Path(raw))==h,raw
assert digest(R/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
out={'schema':'UNIT_TRANSLATION_SLAVNOV_INDEPENDENT_V1','execution_state':'COMPLETED','input_sha256':vp['input_sha256'],
 'complete643_partner_positions':432,'source_constant_Cx_nonzero':296,'source_constant_Cx_sha256':nh,'actual_nonzero_ghost_normalization':str(norm),
 'unit_minus_gaussian_adiabatic_matching_16pi2':str(cd),'coordinate_convolution_errors':errors,'varied_residue_limit_errors_and_bounds':varied,
 'all_finite_order_soft_matching_Q_continuity_and_subcritical_source_bracket_reviewed':True,
 'actual_finite_one_tau_insertion_QA_plus_F_C_zero_in_declared_domain':True,
 'complete_zero_label_tadpole_density_reference_and_local_finite_conversions_retained':True,
 'all_W6_affinity_general_even_cocycles_multiple_products_QAP_A5_E5_or_physical_promotion':False,
 'authority_changed':False,'stored_functional_changed':False,'failed_native_workers':2,'failed_verifier_workers':1,'read_only_navigation_errors':1,
 'scientific_disposition':'QUALIFIED_ACTUAL_FINITE_ONE_TRANSLATION_SLAVNOV_INSERTION_LAW_BY_MATCHED_ADIABATIC_ROOT_CONSTRUCTION',
 'elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
