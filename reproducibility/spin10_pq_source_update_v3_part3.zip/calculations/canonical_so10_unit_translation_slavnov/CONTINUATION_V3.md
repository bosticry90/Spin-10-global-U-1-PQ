# V3: compare logarithms in an exact common normal form

V2 primary passed the actual-data checks and stopped on the structural test
expand_log(unit-ad-c_d)==0. The expression remained
-log(a+b)+log(4a+4b)-2log2. With a,b,nu positive, exact simplify gives0.
V3 applies simplify after expansion and compares the later log4 control as
a zero difference too. The equations and values are unchanged. The two
failed primary executions (V1 receipt-field lookup, V2 expression comparison)
and their full captures remain. No replay previously launched; no cap,
physical assumption, normalization or scientific acceptance gate is relaxed.
