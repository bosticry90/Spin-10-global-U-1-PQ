# UTS1: the actual finite one-tau Slavnov insertion law

The prescribed one-translation insertion now satisfies

`Q A_tau+(F_kappa,C_tau)=0`

in the retained formal Euclidean, Schwartz-test-field, finite Born/background
domain. This is one insertion and its first descendant for the constructed
reference witness. It is stronger than IRS's residue closure: the finite
unit map is matched to the existing local-probe construction before passing
the Ward identity to it. It is not general quantum equivalence or E5/A5.

## The missing bridge is explicit

For u_R=exp(-|x|²/R²), the convergent Gaussian two-edge kernel is

`16pi² I_R(a,b)=log[(a+c)(b+c)/(ab+c(a+b))], c=R²/4`.

Primary Schwinger/Gaussian-determinant integration and replay coordinate
heat-Green convolution agree, including finite terms. After subtracting
log(R²nu²), its finite part is -log[4(a+b)nu²]. The ACTUAL prescribed E_d
root gives d-1-gamma_E-log[(a+b)nu²]. Their difference is

`c_d=d-1-gamma_E+log4`.

Thus, with the inherited insertion sign,

`A_ad=FP_R[A_R+log(R²nu²)P_tau/(16pi²)]`,

`A_tau=A_ad-c_d P_tau/(16pi²)`.

No value of d or nu is selected. Same-unit profiles (1+s|x|²/R²)u_R change
the finite part by a nonzero residue multiple; the matching accounts for it.
The complete residue is the full source/background scattering program, not
a selected scalar table. Its nonzero normalization remains
`T_N=(24370125/4)g10^8xi^4`. The zero of chi_tau cannot by itself check the
finite matching constant, because QP_tau=0; the separate integral tests do.

At every fixed Born/background coefficient, the joint soft Taylor remainder
has degree<=3 and a unique ordinary diagonal limit. Full Q preserves that
root/expansion after all source terms and its varied subtraction are kept.
The actual source commutator has20 constant physical directions and a
296-entry C/x kernel; its dressed poles are<=3. This supplies the separate
limit of (F,C_R), including physical Euler/probe-jet terms. IRS's whole-residue
closure then removes the matching multiple from Q A_tau. The qualified
LOCAL one-source identity gives the displayed finite UNIT law. Neither
unproved global Jacobi nor naive finite-trace cyclicity is used.

## Actual inputs and controls

Both native routes reproduce all643 source-partner fingerprints, including
zero columns:200 nonzero rules and432 coefficient positions. The independent
verifier uses a literal lambda substitution of the action-rule lists rather
than the native exact-polynomial derivative. It independently reproduces
the20 physical mass/source constants,296/14760 C/x kernel and full90-odd
normalization. The complete365 translated physical Hessian programs and508
Euler programs are authenticated/reused, not freshly expanded potential
tensors. No new quantum pole or stored-functional term is integrated.

Independent convergent convolution tests and a varied-residue test detect
omitted subtraction variation, wrong log/finite constant, missing profile
shift, wrong odd sign/factor1/2 and dropped source constants. The dilation
contact has normalized value2, or actual multiplier T_N/(8pi²), NONZERO.
It prevents a false claim that pointwise-vanishing probe effects can all be
discarded. Multiplication by p² instead has the ordinary limit
1/[16pi²(a+b)], consistent with the inherited distributional contact rules.
The positive first-Q/source decay powers, not a chosen convenient field
configuration, justify their bracket limits. All sources differentiate
before source0; Gamma_ref[A] and zero-label tadpole DENSITIES remain.

## Qualification and limitations

Completed independent receipt validation_receipt_v2.json SHA256
`bd0ed65b42c60882960b056037edf8ee7aabc84e1174d8e6fc0c756a305cd6f1`.
It authenticates529 inputs. Native V3 primary13.854163s/replay15.224794s;
independent V2 16.187822s, all after imports. Maximum sampled private
allocation371851264B, NOT peak.120/120/180s,8GiB sampled,350MiB launch
available-commit floor and8MiB package caps passed.

Two failed native primaries remain: V1 shortened receipt-field name; V2
structural comparison of equivalent unexpanded logarithms. One failed
verifier remains: physical tau field names were initially treated as integer
indices. Their corrections preserve the complete sources/captures and all
equations/limits. Two read-only navigation mistakes are separate; the receipt
records the one occurring before its freeze. See continuation/review records.
These were avoidable implementation/schema errors, not physics failures.

UV finite part precedes this IR construction. Common d,nu,kappa are symbolic
and distinct from b0. No constant-strength interacting determinant, two
independent quantum insertions, Lorentzian/causal/vacuum result, physical
scheme adoption or universal source-equivalence theorem is supplied.

The original W6/generic even-cocycle and affinity question remains. Conditional
GHC/SSC divisibility results cannot be transferred to every W6 prescription
because the precise affine quantum-extension premise is unproved there.
Original counterterm adequacy, W5 products, full QAP/measure/equivalence,
parameter stability and E5/A5 retain their independent obligations. The next
research question returns explicitly to that original acceptance gap.

Authority remains34/39/state113, with all seven protected quantum flags false.
HB1/C5 blocked, matter/flavor paused, C1_GS uncalculated, custody exit2/seven
unresolved. Historical quartet3960/648 failure, scalar140% quantum-control
warning, incomplete gauge matching and broader physical limitations remain.
All old evidence, action, benchmark, stored partial functionals and policy
bytes remain unchanged. The broad completed E4 audit is reused, not rerun.

Same action, inherited proofs, exact data, SymPy/mpmath and AI author limit
independence. No Lean certificate, outside expert or experiment is claimed.
The literature comparison supports the extension language, not applicability
of an unproved physical QAP. This is a bounded mathematical advance toward
the full investigation, not a completed unified theory.
