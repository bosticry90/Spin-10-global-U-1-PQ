"""Gaussian-probe/root matching with the actual complete tau/source programs."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from functools import lru_cache
import json,gzip,sys,os,time,threading
import sympy as s
import mpmath as mp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra,put,scale_coefficient
role=sys.argv[1];assert role in ['primary','replay'];tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();prep=read(O/'preparation_v2.json')
for raw,h in prep['input_sha256'].items():assert digest(Path(raw))==h,raw
def guard(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('UTS_NATIVE_READ_ONLY')
sys.addaudithook(guard);get=lambda n:read(Path(prep['artifacts'][role][n]['path']))
g,xi,eta=s.symbols('g10 xi eta_H',real=True)
@lru_cache(None)
def ex(v):return s.expand(s.sympify(v,locals={'g10':g,'xi':xi,'eta_H':eta,'reference_width_H':eta,'reference_width_M':xi}))
@lru_cache(None)
def ce(co):return s.expand(sum(s.Rational(v.numerator,v.denominator)*xi**a*eta**b*s.prod(s.sqrt(p) for bit,p in enumerate([2,3,5,7]) if mask&(1<<bit))*(s.I if mask&16 else 1) for(a,b,mask),v in co))
mat=lambda pk:s.SparseMatrix(*pk['shape'],{(i,j):ex(v) for i,j,v in pk['entries']});clean=lambda M:s.MutableSparseMatrix(M.applyfunc(s.simplify))
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry'];A=Algebra(geo['names'],geo['parities']);fields=[i for i,J,h,k in geo['field_source_h_k']];fieldof={J:i for i,J,h,k in geo['field_source_h_k']}
print('STAGE',role,'actual_translation_source_partner_and_constant_commutator_completeness',flush=True)
tau={}
for(gp,w),co in A.rows(get('original')['fixed_generator_components']['intrinsic_translation'],explicit_g=True).items():
 assert len(w)==1 and not w[0][1];i=fieldof[w[0][0]];assert A.names[i].startswith('x_');put(tau.setdefault(i,{}),(gp,()),scale_coefficient(co,-1))
Q={i:A.rows(data['master_field_maps'][A.names[i]]) for i in fields};assert sum(map(len,Q.values()))==35162
partners={i:{} for i in fields}
if role=='primary':
 for i,P in Q.items():
  for(gp,w),co in P.items():
   for at,(n,jets) in enumerate(w):
    if n in tau and not jets:
     for key,value in A.product(tau[n],{(gp,w[:at]+w[at+1:]):co}).items():put(partners[i],key,value)
else:
 for n,dt in tau.items():
  for i,P in Q.items():
   for(gp,w),co in P.items():
    for at,token in enumerate(w):
     if token==(n,()):
      for key,value in A.product({(gp,w[:at]+w[at+1:]):co},dt).items():put(partners[i],key,value)
table={A.names[i]:{'positions':len(P),'sha256':A.fingerprint(P)} for i,P in partners.items()};assert table==get('paired')['all643_source_partner_table']==get('firstQ')['all643_partner_table']
assert sum(bool(v) for v in partners.values())==200 and sum(map(len,partners.values()))==432
assert all(len(w)==1 for P in partners.values() for gp,w in P) # Their field Hessian zero; they are not zero.
ref=get('core')['retained_reference'];names=ref['field_order'];pos={n:i for i,n in enumerate(names)};T=mat(ref['physical_to_raw_kernel']);Ti=mat(ref['physical_to_raw_inverse'])
traw=s.zeros(643,1)
for i,P in tau.items():
 for(gp,w),co in P.items():assert not w;traw[pos[A.names[i]]]+=g**gp*ce(co)
tphys=clean(T*traw);assert tphys.nnz()==20
mPhi,mSigma,mphi,mS=s.symbols('mPhi2 mSigma2 mphi2 mS2',real=True);mass=[2*mPhi]*54+[2*mSigma]*252+[mphi]*20+[mS]*2
wphys=clean(s.SparseMatrix(643,1,{(180+i,0):mass[i]*tphys[180+i] for i in range(328) if tphys[180+i]!=0}));assert wphys.nnz()==20
wv=[[i,str(s.expand(v))] for(i,j),v in sorted(wphys.todok().items())];assert wv==get('firstQ')['source_commutator_constant_physical_vector']
wraw=clean(T.T*wphys);cr=[pos[f'C{i}'] for i in range(45)];xr=[i for i,n in enumerate(names) if n.startswith('x_')];cg={v:i for i,v in enumerate(cr)};sx={v:i for i,v in enumerate(xr)}
entries=defaultdict(lambda:s.S.Zero)
for(i,j),weight in wraw.todok().items():
 for(gp,w),co in Q[A.index[names[i]]].items():
  assert len(w)==2 and not any(jets for n,jets in w);ns=[pos[A.names[n]] for n,jets in w];c=[n for n in ns if n in cg];x=[n for n in ns if n in sx];assert len(c)==len(x)==1
  entries[cg[c[0]],sx[x[0]]]+=weight*g**gp*ce(co)
rawkernel=s.SparseMatrix(45,328,entries);kernel=clean(Ti.extract(cr,list(range(553,598))).T*rawkernel*Ti.extract(xr,list(range(180,508))))
rows=[[i,j,str(s.expand(v))] for(i,j),v in sorted(kernel.todok().items())];kh=sha256(json.dumps(rows,separators=(',',':')).encode()).hexdigest()
assert len(rows)==296 and kh==get('firstQ')['actual_source_constant_ghost_scalar_kernel_sha256']
assert get('firstQ')['source_constant_kernel_dressed_bound']<=3 and get('firstQ')['new_Rtau_grouped_single_edge_bound']<=2
assert get('local')['one_probe_identity'] and get('local')['same225_unlabeled_tangents_and_single_probe_IR_domain']
assert get('local')['same_Tkappa_reference_heat_power_Djet_conversion'] and get('local')['physical_Euler_program_count']==508
assert get('irs')['complete_one_translation_IR_residue_Q_closed_in_retained_Euclidean_finite_Born_domain']
assert get('ccm')['proof_scope']['subtraction_is_actual_covariant_zero_energy_bikernel_Psi_Pi0_Psi_dual']
print('STAGE',role,'actual90_odd_bubble_normalization_and_gaussian_adiabatic_constant',flush=True)
K=clean(Ti.T*mat(ref['reference_Hessian_raw_C3'])*Ti);pm=[s.Symbol(f'p0_ref{i}') for i in range(4)];D=clean(K[553:598,598:643].subs(dict(zip(pm,[s.I,0,0,0]))))
N=s.SparseMatrix(45,45,{(i,j):ex(v) for i,j,v in get('transport')['actual_ghost_mass_physical']});assert N.nnz()==57
if role=='primary':norm=s.factor(s.trace((D.inv()*N)**2))
else:
 z=s.zeros(45);H=s.BlockMatrix([[z,N],[-N.T,z]]).as_explicit();G=s.BlockMatrix([[z,-D.T.inv()],[D.inv(),z]]).as_explicit();norm=s.factor(s.trace(G*H*G*H)/2)
assert norm==s.Rational(24370125,4)*g**8*xi**4 and norm!=0
a,b,c,aa,nu=s.symbols('a b c A nu',positive=True);d,shape=s.symbols('d shape',real=True)
ratio=(a+c)*(b+c)/(a*b+c*(a+b));logI=s.log(ratio)
if role=='primary':
 primitive=s.log(((b+c)*aa+b*c)/(aa+c))/c**2
 assert s.simplify(s.diff(primitive,aa)-1/((aa+c)*((b+c)*aa+b*c)))==0
 assert s.factor((b+c)*(a+c)/((b+c)*a+b*c)-ratio)==0
else:
 # Radial convolution: exp(-y/RÂ²)(1-exp(-y/4a))(1-exp(-y/4b))/y.
 rates=[1/(4*c),1/(4*c)+1/(4*a),1/(4*c)+1/(4*b),1/(4*c)+1/(4*a)+1/(4*b)]
 assert s.factor(rates[1]*rates[2]/(rates[0]*rates[3])-ratio)==0
assert s.limit(ratio/c,c,s.oo)==1/(a+b)
ad=-s.log(4*(a+b)*nu**2);unit=d-1-s.EulerGamma-s.log((a+b)*nu**2);cd=d-1-s.EulerGamma+s.log(4)
assert s.expand_log(unit-ad-cd,force=True)==0
assert s.limit(c*s.diff(logI,c),c,s.oo)==1
ordinary=s.simplify(-s.diff(logI,a));assert s.limit(ordinary,c,s.oo)==1/(a+b)
# The complete simultaneous-dilation identity includes the probe derivative.
assert s.simplify(a*s.diff(logI,a)+b*s.diff(logI,b)+c*s.diff(logI,c))==0
assert s.simplify(a*s.diff(ad,a)+b*s.diff(ad,b))==-1
assert s.limit(shape*c*s.diff(logI,c),c,s.oo)==shape
actual_boundary=s.factor(norm/(8*s.pi**2));assert actual_boundary!=0
print('STAGE',role,'independent_convergent_gaussian_integrals_and_soft_remainder_bounds',flush=True)
mp.mp.dps=55;tests=[]
for av,bv,RR in [(2,3,4),(mp.mpf(3)/2,mp.mpf(7)/3,8),(2,3,16)]:
 av,bv,RR=map(mp.mpf,[av,bv,RR]);cv=RR**2/4
 if role=='primary':
  observed=cv**2*mp.quad(lambda A0:1/((A0+cv)*((bv+cv)*A0+bv*cv)),[av,av+1,mp.inf])/(16*mp.pi**2)
 else:
  observed=mp.quad(lambda y:mp.exp(-y/RR**2)*(-mp.expm1(-y/(4*av)))*(-mp.expm1(-y/(4*bv)))/y,[0,1,RR**2,mp.inf])/(16*mp.pi**2)
 exact=mp.log((av+cv)*(bv+cv)/(av*bv+cv*(av+bv)))/(16*mp.pi**2);err=abs(observed-exact);assert err<mp.mpf('1e-40')
 remainder=16*mp.pi**2*exact-mp.log(cv)+mp.log(av+bv);assert 0<remainder<(av+bv)/cv
 tests.append([str(av),str(bv),str(RR),mp.nstr(exact,42),mp.nstr(err,12),mp.nstr(remainder,18),mp.nstr((av+bv)/cv,18)])
# General first Taylor remainder improves the critical degree4 to3;
# one independent Q tangent/source-commutator has the inherited bounds.
subcritical=[['Taylor_remainder',3,0],['source_C_x',2,0],['source_C_B',3,0],['grouped_Rtau',2,0]]
decay=[[name,pole,jets,4-pole+jets] for name,pole,jets in subcritical];assert all(e[-1]>=1 for e in decay)
jetdecay=[[pole,jets,4-pole+jets] for pole in [2,3] for jets in [1,2]];assert min(e[-1] for e in jetdecay)==2
# Counterexample to a naked-critical limit: log term and profile/dilation
# constants are nonzero even though each finite-momentum difference vanishes.
assert s.expand_log(cd-(d-1-s.EulerGamma),force=True)==s.log(4)
local_identity={'K_tau_local_Hessian_zero':True,'loop_I_K_tau_zero':True,'all_source_derivatives_before_source0':True,'unit_Ward_conclusion_from_matched_local_identity_not_assumed_global_Jacobi':True}
out={'schema':'UNIT_TRANSLATION_SLAVNOV_NATIVE_V1','route':role,'actual643_source_partner_table':table,'actual_partner_nonzero_rules':200,'actual_partner_positions':432,
 'actual_source_constant_physical_vector':wv,'actual_source_Cx_kernel_nonzero':len(rows),'actual_source_Cx_kernel_zero':14760-len(rows),'actual_source_Cx_kernel_sha256':kh,
 'actual_ghost_odd_normalization':str(norm),'gaussian_integral_16pi2':str(logI),'adiabatic_finite_16pi2':str(ad),'prescribed_unit_16pi2':str(unit),'unit_minus_adiabatic_16pi2':str(cd),
 'same_unit_profile_finite_shift_16pi2':str(shape),'dilation_contact_16pi2':2,'nonzero_actual_dilation_control':str(actual_boundary),'ordinary_p2_root_limit_16pi2':str(1/(a+b)),
 'joint_soft_remainder_decay_powers':decay,'source_probe_jet_decay_powers':jetdecay,'convergent_integral_tests':tests,'local_identity':local_identity,
 'analytic_scope':{'all_finite_Born_source_background_soft_diagonal_matching':True,'first_Q_common_limit_includes_complete_residue_variation_and_actual_source_commutator':True,
 'finite_chi_tau_zero_in_retained_one_insertion_first_descendant_domain':True,'zero_label_tadpoles_density_and_reference_determinant_retained':True,
 'all_W6_affinity_general_even_unit_cocycles_multiple_products_QAP_A5_E5_physical_scheme':False},
 'authority_changed':False,'stored_functional_changed':False,'scientific_disposition':'FINITE_UNIT_TRANSLATION_SLAVNOV_LAW_PENDING_INDEPENDENT_VALIDATION','elapsed_after_imports':time.perf_counter()-tick}
print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
