# Return to original W6 adequacy, without importing affinity

UTS closes the finite unit law for the selected exact tau direction. Do not
continue accumulating tau refinements as a substitute for general adequacy.

Reconcile the ACTUAL original W6 first-differing-restored-order class with
GHC/SSC/QNF's affine fixed-reference extension hypotheses. The original
contract requires local real Q-closed/background-compatible differences WITH
their insertion/source-normalization changes. It does not grant a freely
scalable affine interpolation between all prescriptions. QNF's normalization-
degree locality works for its explicitly specified family. Neither that
result nor UTS proves the missing implication.

The least expensive competent next step is a bounded endpoint-versus-family
analysis using the actual g0 action/source structure and original order
requirements. First determine precisely what restoration order and local
finite-normalization freedom W6 assumes; do not add a two-loop condition
merely to force a desired one-loop counterterm classification.

A potentially informative UNTESTED route is whether, for a SINGLE legitimate
higher-order endpoint, the relevant leading local source projection can be
separated without affine interpolation. Inspect the actual g0 master field
rules and GF/physical Hessian to test whether the base finite F0 is source-free
and scalar-only. Then assess the full endpoint equation, including (F0,delta0),
allowed second-order source/contact terms and exact-shift transport. Nonlocal
limits or forbidden source omissions cannot be hidden in this projection.
This is a hypothesis, not a qualified new exclusion of any W6 class.

If original W6 does NOT supply the needed endpoint order, preserve that exact
scope distinction. Seek an actual admissible family/replacement for the
remaining polynomial classes, or classify the underdefinition, rather than
silently restricting W6 to the easiest affine subclass. General constant
translations and nonexact even-cocycle insertions need their own complete
domains; UTS covers only the authenticated tau vector. The original basic
quotient/physical parameter stability obligations remain separate.

Reuse completed obstruction matrices, source normal forms and homotopies;
no catalog expansion or new295-profile vector calculation without a specific
dependency. Keep all original blocked-stage and authority boundaries.
