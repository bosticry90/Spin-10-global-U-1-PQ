# V2: correct the IRS receipt field name

V1 primary completed the actual643 source-partner and20 constant-source/kernel
checks, then stopped with KeyError when looking up a shortened IRS receipt
field name. The qualified receipt actually uses the full name
complete_one_translation_IR_residue_Q_closed_in_retained_Euclidean_finite_Born_domain.
V2 changes that lookup only, with the same original120/120/180s and memory/
package limits. Physical inputs, proof obligations and expected outcomes stay.
No replay had launched. V1 source, preparation, controller and complete failed
capture are preserved; it is not counted as a completed scientific calculation.
