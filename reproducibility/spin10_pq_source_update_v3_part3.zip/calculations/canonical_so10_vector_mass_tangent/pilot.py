"""Exact parameter/field mass-tangent separation; no loop CT is selected."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict
import json,sys,gzip,time,threading,os
import sympy as s
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(R/'calculations/canonical_so10_scalar_reconstruction'))
from verify_eta1_doublet_mixing import vacuum_form
@lru_cache(None)
def clean(z):return s.cancel(s.expand(z))
@lru_cache(None)
def parse(z):return s.sympify(z)
def mat(row):return s.SparseMatrix(*row['shape'],{(i,j):parse(z) for i,j,z in row['entries']})
def tidy(M):return s.SparseMatrix(M).applyfunc(clean)
def enc(M):return {'shape':list(M.shape),'entries':[[i,j,str(z)] for (i,j),z in sorted(tidy(M).todok().items()) if z]}
def zero(M):assert not tidy(M).todok()
def main(role):
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=json.loads((D/'preparation.json').read_bytes())
 for n,h in prep['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
 data=json.loads((P/('frozen_a10_physical_reconciliation/full_'+role+'.json')).read_bytes())
 v=mat(data['vacuum']['VEV']);radii=[s.sqrt(60),s.sqrt(60)/10,s.sqrt(60)/10]
 sectors=[('Phi',0,54),('Sigma',54,252),('S',326,2)]
 vs=[];orbits=[]
 for name,off,n in sectors:
  vv=v.extract(range(off,off+n),[0]);vs.append(vv)
  zero(vv.T*vv-s.Matrix([[radii[len(vs)-1]**2]]))
  if role=='primary':
   oo=s.SparseMatrix.hstack(*(mat(row)*vv for row in data['representation_matrices'][name]));orbits.append(tidy(oo))
 if role=='primary':grams=[tidy(oo.T*oo) for oo in orbits]
 else:
  tab=json.loads(gzip.decompress((R/'calculations/canonical_so10_background_threshold_inputs/replay_tables.json.gz').read_bytes()))
  J=[defaultdict(lambda:s.S.Zero) for _ in range(3)]
  for a,b,i,z in tab['T']:
   pos=0 if i<54 else 1 if i<306 else 2 if i>=326 else None
   if pos is None:continue
   coeff=parse(z)*v[i,0]
   J[pos][a,b]+=coeff;J[pos][b,a]+=coeff
  grams=[tidy(s.SparseMatrix(45,45,dd)/2) for dd in J]
 G=tidy(sum(grams,s.SparseMatrix(45,45,{})));zero(G-mat(data['vacuum']['orbit_Gram']));zero(grams[2])
 zero(grams[0]*grams[1]-grams[1]*grams[0])
 evs=list(map(s.Rational,['0','3/10','3/2','25','253/10']));projectors=[];weights=[];ranks=[]
 for lam in evs:
  pr=s.SparseMatrix(s.eye(45))
  for nu in evs:
   if nu!=lam:pr=pr*(G-nu*s.eye(45))/(lam-nu)
  pr=tidy(pr);zero(pr*pr-pr);zero(G*pr-lam*pr)
  n=int(s.trace(pr));ranks.append(n)
  c=[clean(s.trace(pr*gg)/n) for gg in grams]
  for gg,z in zip(grams,c):zero(gg*pr-z*pr)
  weights.append(c);projectors.append(pr)
 zero(sum(projectors,s.SparseMatrix(45,45,{}))-s.eye(45))
 for i in range(5):
  for j in range(i):zero(projectors[i]*projectors[j])
 assert ranks==[12,8,1,12,12]
 # Matrix equality at a changed radial point is diagnostic, not adoption.
 xp,ys,zs=s.Rational(6,5),s.Rational(7,6),s.Rational(4,3)
 finite=xp*xp*grams[0]+ys*ys*grams[1]+zs*zs*grams[2]
 if role=='primary':
  direct=sum(((fac*oo).T*(fac*oo) for fac,oo in zip([xp,ys,zs],orbits)),s.zeros(45));zero(finite-direct)
 # The common projectors are verified for the whole radial family.
 for pr,c in zip(projectors,weights):zero(finite*pr-(xp*xp*c[0]+ys*ys*c[1]+zs*zs*c[2])*pr)
 heavy=weights[1:];jac=s.Matrix([[2*cp,2*cs,0,2*(cp+cs)] for cp,cs,c0 in heavy]);rank=jac.rank()
 left=jac.T.nullspace();nullrows=s.Matrix.vstack(*(q.T for q in left)) if left else s.zeros(0,4)
 zero(nullrows*jac);assert len(left)==4-rank
 # Absolute normalization and missing-sector controls, independent of rank.
 assert tidy(2*grams[0]+grams[1]-G).todok() and tidy(grams[0]-G).todok()
 print('STAGE exact_mass_tangent',time.perf_counter()-tick,flush=True)
 w,sig,vsym=s.symbols('omega sigma s',positive=True);q=s.Matrix([w,sig,vsym])
 embed=json.loads((P/'frozen_action_ast_a3/A31_embeddings.json').read_bytes())['sectors']
 if role=='primary':
  v2=[]
  for (name,off,n),vv,r,qr in zip(sectors,vs,radii,q):
   e=embed[name];E=s.SparseMatrix(e['ambient_real_dimension'],e['domain_dimension'],{(i,j):parse(z) for i,j,z in e['embedding_entries']})
   ambient=E*vv*qr/r
   v2.append(clean((ambient.T*ambient)[0]))
 else:
  d=[-2]*6+[3]*4;form=vacuum_form()
  v2=[clean(sum(z*z for z in d)*w*w/60),clean(sum(a*a+b*b for a,b in form.values())*sig*sig/32),vsym*vsym/2]
 assert v2==[w*w,sig*sig,vsym*vsym/2]
 m=s.Matrix(s.symbols('mPhi2 mSigma2 mS2',real=True));mu,Lp,Lm,lps,lss,ls,lsig=s.symbols('muPhi Lp Lm lambdaPhiS lambdaSigmaS lambdaS lambdaSigma1',real=True)
 V=sum(m[i]*v2[i] for i in range(3))+mu*w**3/s.sqrt(60)+Lp*w**4+Lm*w*w*sig*sig+lps*w*w*vsym*vsym/2+lsig*sig**4+lss*sig*sig*vsym*vsym/2+ls*vsym**4/4
 t=s.Matrix([s.diff(V,x) for x in q]);B=tidy(t.jacobian(m))
 if role=='primary':mstar=tidy(-B.inv()*t.subs(dict.fromkeys(m,0)))
 else:mstar=s.Matrix([-3*mu*w/(2*s.sqrt(60))-2*Lp*w*w-Lm*sig*sig-lps*vsym*vsym/2,-Lm*w*w-2*lsig*sig*sig-lss*vsym*vsym/2,-lps*w*w-lss*sig*sig-ls*vsym*vsym])
 subs=dict(zip(m,mstar));zero(t.subs(subs));H=tidy(t.jacobian(q).subs(subs));zero(H-H.T)
 lift=tidy(-B.inv()*H*s.diag(*q)) if role=='primary' else tidy(mstar.jacobian(q)*s.diag(*q))
 zero(B*lift+H*s.diag(*q));detB=clean(B.det());assert detB==4*w*sig*vsym
 assert B.subs(w,0).rank()==2 and B.subs(sig,0).rank()==2 and B.subs(vsym,0).rank()==2
 wrong=s.diag(w,sig,vsym);assert tidy(wrong*lift+H*s.diag(*q)).todok() # wrong mass normalization
 # No requirement to invert H to lift a classical stationary parameter family.
 # One-loop physical vacuum shift instead depends on the actual renormalized tadpole.
 # Field normalization: full kinetic/mass congruence, not free mass parameters.
 zvals=list(map(s.Rational,['1/2','1/3','1/5','1/7']))
 Z=tidy(sum((z*p for z,p in zip(zvals,projectors[1:])),s.zeros(45)))
 deltaMass=tidy((Z*G+G*Z)/2);zero(deltaMass-(Z*G+G*Z)/2);assert deltaMass.todok()
 ell=s.Rational(2,7);L=s.eye(45)+ell*Z/2;Af=tidy(L.T*L);Bf=tidy(L.T*G*L);zero(Af*G-Bf)
 rawrank=s.diag(*evs[1:]).rank()
 # All four raw diagonal mass entries can move with independent field rescalings,
 # but the accompanying kinetic variation cancels these generalized-mass jets.
 assert rawrank==4
 tv=[s.Matrix([s.Rational(14,5),0,1]),s.zeros(3,1),s.Matrix([5,3,2]),s.Matrix([s.Rational(1,5),3,2])]
 response=s.zeros(3,2)
 for r,(cp,cs,c0) in enumerate(heavy):
  for a,z in enumerate([cp,cs]):response[:,a]+= -21*tv[r]*z/evs[r+1]
 response=tidy(response);zero(response[:,0]+response[:,1]+21*s.Matrix([8,6,5]))
 payload={'Gram_Phi':enc(grams[0]),'Gram_Sigma':enc(grams[1]),'Gram_S':enc(grams[2]),
 'base_eigenvalues':list(map(str,evs)),'base_multiplicities':ranks,
 'radial_Gram_eigenvalues':[[str(z) for z in c] for c in weights],
 'mass_squared_radial_formula_coefficients':[[str(clean(c[0]/60)),str(clean(c[1]/s.Rational(3,5))),str(c[2])] for c in heavy],
 'fractional_jet_columns':['deltaomega/omega','deltasigma/sigma','deltas/s','deltag/g_GEOMETRY_ONLY'],
 'mass_squared_jet_matrix':enc(jac),'jet_rank':rank,'mass_squared_jet_left_relations':enc(nullrows),
 'quadratic_radial_invariants':list(map(str,v2)),'tadpole_mass_Jacobian':enc(B),
 'stationary_masses':enc(mstar),'radial_Hessian':enc(H),'stationary_mass_lift_fractional_VEV':enc(lift),
 'tadpole_mass_Jacobian_determinant':str(detB),'fixed_g_vector_lambda1_VEV_response':enc(response),
 'field_rescaling_raw_mass_jet_rank':rawrank,'canonical_parameter_jet_rank':rank,
 'full_generalized_mass_congruence_preserved':True,'mass_only_field_change_detected':True,
 'radial_contraction_blind_to_T_antisymmetric_part':True,'Higgs_tuning_and_scalar_spectrum_preserved':False,
 'finite_CT_chosen':False,'actual_loop_CT_coefficients_calculated':False,'C1_GS_calculated':False,'authority_changed':False}
 out={'schema':'VECTOR_MASS_TANGENT_NATIVE_V1','role':role,'calculation':payload,'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main(sys.argv[1])
