# VMT1 result — correlated vector masses and a stationary radial lift

**PASS for the frozen canonical vector-parameter geometry and radial
stationarity problem.** No actual loop counterterm, finite normalization,
physical scheme or C1_GS has been selected or calculated.

The full45x45 mass operator, not a fitted set of eigenvalues, gives the
following formulas along the existing radial VEV ansatz:

| Massive vector set | Real directions | M^2/g10^2 |
| --- | ---: | --- |
| A | 8 | sigma^2/2 |
| B | 1 | 5 sigma^2/2 |
| X | 12 | 5 omega^2/12 |
| Y | 12 | 5 omega^2/12+sigma^2/2 |

The12 unbroken directions remain zero. S is a gauge singlet and contributes
zero to every vector mass entry. The base values at omega^2=60,
sigma^2=3/5 reproduce3/10,3/2,25,253/10 exactly, with the correct multiplicities.
A,B,X,Y label existing vector mass sets, not new particles or amplitudes.

The canonical parameter mass tangent has rank2 and exactly two independent
relations:

    delta M_B^2=5 delta M_A^2,
    delta M_Y^2=delta M_X^2+delta M_A^2.

The four vector masses cannot be treated as independent finite parameters
of this radial tree action. A geometric delta g/g column is the sum of the
two fractional charged-VEV columns; the fixed-g MST1 comparison does not
adopt a finite gauge-coupling change. Complete quantum field, gauge-width
and self-energy counterterms remain separate obligations. This result is
not a rank theorem for the entire renormalized vector counterterm module.

## Complete matrix evidence

Primary reconstructed O_Phi,O_Sigma,O_S directly from the exact physical
representation matrices and VEV. Replay contracted the independently qualified
full ghost-scalar tensor as dG[v_sector]=sum v_sector,I(T_abI+T_baI), using
Euler homogeneity to recover each sector Gram. The completed outputs agree
exactly. The verifier independently rebuilt every Gram coefficient from the
separate replay representation input:2,025 positions in each of three sectors.

All five base spectral projectors satisfy orthogonality, completeness and
the full matrix identities Gsector P=csector P. Hence no off-diagonal or
degenerate-subspace entry was inferred from a trace alone. A finite exact
two-radial rescaling also agrees, including all cross-term information.
Absolute mass normalization and a missing Sigma contribution are detected
by negative controls. This radial contraction is insensitive to T's
antisymmetric part; BFT1's separate full tensor test, not this calculation,
establishes that part. The inherited representation/VEV and T premises remain
shared inputs, not independently established physics.

## Actual quadratic-parameter lift

Ambient tensor embeddings and an independent literal-tensor norm calculation
give the quadratic radial invariants omega^2,sigma^2,s^2/2. Therefore the
tadpole Jacobian with respect to the existing mass parameters is

    B=diag(2omega,2sigma,s), det B=4omega sigma s.

The factor2 difference is required by the frozen kinetic and invariant
normalizations. On the current nonzero-VEV branch, each specified radial
VEV tangent has a unique quadratic-parameter tangent at fixed other couplings:

    delta(mPhi2,mSigma2,mS2)^T=-B^-1 Hrad delta(omega,sigma,s)^T.

Direct differentiation of the qualified action-derived V0 agrees identically
with differentiating its solved stationary masses. All mixed couplings and
the cubic muPhi term are retained. The verifier also checks the finite
stationary family algebraically. No inverse of Hrad is required for this
parameter lift. The B inverse loses rank when any corresponding VEV vanishes;
that limit is explicitly excluded rather than extrapolated silently.

This is a classical stationary family, not the physical quantum displacement
Hrad*v1+t1_ren=0. It chooses no finite tadpole value or quantum correction.
The three mass variations are existing invariant directions of the parent;
there is no added interaction or foundational adoption. The inherited
H-singlet and phase/gauge census delimits the stationary ansatz. Higgs tuning,
the full scalar spectrum, positivity and BFB are not preserved by this
statement and need their own tangent checks.

## Field normalization and matching transport

A field rescaling can make all four raw diagonal mass entries move. It must
also transform their kinetic operator. With both terms retained, the full
finite generalized mass spectrum is invariant; a noncommuting exact2x2
control detects the false mass-only shortcut. In the full actual vector
projector family, canonicalization removes the corresponding field-rescaling
mass jets. These four apparent raw directions are not four extra canonical
parameter masses. This does not calculate a physical pole spectrum.

At fixed g and mu, the vector part of the one-loop lambda sensitivity pulled
back to alpha=deltaomega/omega and beta=deltasigma/sigma is

    [ -27615/253   -14889/253 ]
    [ -31689/253     -189/253 ] .
    [ -21126/253    -5439/253 ]

Rows are U1,SU2,SU3; columns are alpha,beta. Their sum is
-21*(8,6,5), as required for a common VEV scaling. These are exact derivatives
of the existing vector one-loop kernel. The scalar contribution and actual
two-loop graphs are absent. The negative derivative enters MST1's finite
scheme transport only after an actual finite parameter redefinition is
specified; none is specified here. Consistent parameter/coefficient transport
preserves the same bare matching, not a physical repair of unification.

## Verification, resources and limitations

Native primary0.376685s, replay0.336762s; independent verifier3.104775s after
imports. Zero failed native or verifier executions; exact algebra without
numerical tolerances.46 initial and51 verification bindings. Sources, proof,
controllers and immutable inputs frozen before computation; full captures
saved before assertions. Caps120/180s,8GiB sampled private,350MiB launch floor,
4MiB package. Native startup samples do not measure runtime/peak allocation;
largest verifier sample48,345,088 bytes is not a true peak.

Receipt SHA256:
`82ca977dc8ca92187cff319f633f83bf07735fef5d51a920b7f6a2c051e7f138`.
Commands, separately at repository root (exclusive outputs preserve history):

```powershell
python -B calculations/canonical_so10_vector_mass_tangent/prepare.py
python -B calculations/canonical_so10_vector_mass_tangent/run.py
python -B calculations/canonical_so10_vector_mass_tangent/prepare_validation.py
python -B calculations/canonical_so10_vector_mass_tangent/run_validation.py
```

The calculation shares the action, representation/VEV data, earlier T,
qualified radial V0, SymPy and AI author. This is bounded internal mathematical
corroboration, not external, Lean or experimental validation. It demonstrates
useful reduction of nominally independent matching inputs and detection of
a field/parameter normalization confusion. It does not validate shared
physical premises or construct the complete counterterm prescription.

No old action, evidence, state, source, point, partialGamma, scheme, policy,
branch or remote changed.34/39,state113/sevenfalse; E5/A5 unqualified,
HB1/C5 blocked, flavor human-paused, C1_GS uncalculated. QuartetFAIL3960/648,
custodyexit2/seven, scalar140%/1.94%/20.27%, matching0.745476 and missing
Yukawa control remain separate limitations.
