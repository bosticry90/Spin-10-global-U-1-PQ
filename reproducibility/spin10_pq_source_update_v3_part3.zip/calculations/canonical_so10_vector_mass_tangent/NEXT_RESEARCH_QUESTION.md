# Next: complete the benchmark's stationary, Higgs-tuned mass tangent

VMT1 supplies the actual vector mass geometry and radial-stationarity lift.
It does not preserve the one light Higgs condition. The next justified input
is to differentiate the actual tuned doublet block along this same parent
parameter/VEV tangent, then determine the required correlated mphi2 tangent.
Use its measured nonzero10_H fraction and a full light spectral projector;
do not assume the denominator or its sign from the existence of a tuned root.

Once that condition is independently checked, propagate this specific parent
tangent through the existing35 small Hessian blocks and the heavy scalar
matrix-log kernel. This can pull MST1 back to a genuinely model-derived
stationary/Higgs-tuned family instead of an arbitrary Hermitian diagnostic.
Retain fixed physical matching scale and original reference units. Verify
derivative counting when varying omega, since old compiled blocks used a
fixed raw Phi VEV and rescaled Sigma/S coordinates. Check the kinetic metric
and all zero modes explicitly; a frozen-coordinate shortcut can be wrong.

Use existing on-demand parent derivatives and qualified coefficient caches
with an independent direct-action control, not a328^4 array or another
unrestricted master-function test. Neither this tangent construction nor
its threshold sensitivity chooses a finite prescription, computes C1_GS,
proves quantum control, or admits a parameter fit. Actual loop counterterms,
weighted diagrams, reduction and UV/EFT subtraction remain indispensable.
