# Post-commit packaging review — preserved CRLF controller sources

The VMT1 native primary, replay and independent scientific verifier all
completed successfully before commit7e83a95c07fe7d05a1a6b373be35a8c83f438a82.
Its precommit raw/index equality checks also completed, but the final
git diff --cached --check command returned exit2. The orchestration incorrectly
continued to the local commit without acting on that nonzero exit. This is
an execution-control error; it is not a scientific-worker or verifier failure.

The failure was reproduced against exactly the committed parent/child diff
and captured in packaging_whitespace_failure_capture.json. All136 output
lines are preserved. The flagged files are run.py,run.py.source.txt,
run_validation.py,run_validation.py.source.txt. They were copied using
Windows text I/O before the prospective source freeze and contain CRLF.
The final source/capture/receipt bytes match their frozen and committed bytes.
No frozen file was changed to repair the packaging check.

A separate explicit CRLF-aware check retained the ordinary blank-at-eol,
blank-at-eof and space-before-tab checks:

```text
git -c core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol diff HEAD^ HEAD --check
```

It returned exit0 with no diagnostics on the same VMT1 parent/child bytes.
The exact command, exits and classification are preserved in
packaging_crlf_review_capture.json. This interprets the Windows end-of-line
convention explicitly; it does not relax a mathematical requirement or
relabel the original exit2 as PASS. The scientific validation receipt remains
82ca977dc8ca92187cff319f633f83bf07735fef5d51a920b7f6a2c051e7f138, unchanged.

Postcommit custody checks authenticated all24,527 pre-existing Git blobs,
all28 new raw/index/HEAD files and the unchanged authority, with a clean
checkout. These checks are distinct from the failed default whitespace check.
Future dependent commands must inspect the preceding exit before mutation;
use an explicit newline convention when copying new source files. Preserve
this failure in Track B's engineering record. No scientific gate or protected
authority is altered by this packaging review.
