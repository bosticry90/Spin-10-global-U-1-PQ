# VMT1 — actual vector-mass and radial-stationarity tangent

Prospective at a18a2cf747a3dd05280e40b9825552bedf024497/main,2026-10-20.
Clean preflight/no matching scientific workers/452 byte bindings only.
Active C1_GS input research, no finite-amplitude gate promotion.

Question: which correlated vector-mass first variations arise from the frozen
parent's Phi, Sigma and S radial VEVs? Can these VEV tangents be lifted to
the existing quadratic mass parameters while preserving radial stationarity,
without choosing finite coefficients? This supplies actual model geometry
to the general MST1 finite scheme law; arbitrary four-mass shifts are not a
substitute for the parent action's parameter counterterms.

Inputs: unchanged parentSHA01323e0f6a025edd6f6669b43e7c730f5350e28d8561e72df89636862ca358ed,
positive-Higgs pointSHA476645438ea8a7ada42fea90e80174b772d45ce3e729d013d134e9848950c816,
orthonormal328-real representation/VEV and A31 embeddings, BFT1 exact ghost
scalar tensor, existing vector ledger, qualified action-derived radial V0
and tadpoles, MST1 law and receipt. Reuse existing Lie, Goldstone, H-singlet
census and vacuum-polynomial evidence; do not repeat a full scalar Hessian.
Inactive A10 kinematic data are not adoption/repair of its historical action.
The formal E1 nonlinear gauge/source functional remains untouched.

Freeze proof/code/controllers/hash-bound inputs before computation. Types:
45x45 real vector Gram, common exact base spectral projectors, VEV fractions
alpha=deltaomega/omega, beta=deltasigma/sigma, chi=deltas/s. Factor g10^2;
same MSbar gauge coupling in the MST1 application. A gamma=deltag/g column
may be recorded geometrically, but does NOT supply a finite gauge-coupling
scheme law. Include the12 zero vector directions. Never fix finite shifts.

Primary: construct all scalar orbit columns from rho_a times each sector VEV,
then G_Phi=O_Phi^T O_Phi, G_Sigma=O_Sigma^T O_Sigma, G_S=O_S^T O_S.
Replay: obtain the radial derivatives from the independently qualified full
T_abI via sum_I v_sector,I (T_abI+T_baI); reconstruct sector Grams by Euler
homogeneity. Compare every matrix coefficient and all base mass projectors.
Derive the four set eigenvalue jets, exact rank and complete left nullspace;
do not infer the answer by fitting a few diagonal entries or the desired
matching residual. Check a finite exact two-radial rescaling and polarization.

Derive the quadratic-potential normalization in the canonical radial variables
by ambient A31 tensor embeddings; independently use literal diagonal Phi,
sorted-index Sigma norm and S=s/sqrt2. Preserve the factor2 difference between
mPhi2/mSigma2 and mS2 in the tadpole Jacobian. Reuse qualified radial V0
to construct its full Hessian and tangent lift; replay through differentiating
the exact solved stationary masses. Check all coefficient polynomials and
mixed derivatives, not a selected numerical point. Verify rank loss at a
vanishing VEV rather than extrapolating the nonzero-VEV inverse there.

Check quantum-field normalization separately as a simultaneous congruence of
the transverse kinetic/mass pair. A raw mass CT that omits its kinetic partner
must fail the generalized-spectrum control. This does not establish the full
field/gauge-width CT module or a quantum pole spectrum. Keep physical loop
vacuum displacement, finite tadpole normalization and parameter shifts distinct.
Radial stationarity alone does not preserve Higgs tuning, all scalar masses,
positivity, BFB, physical matching or the full finite counterterm prescription.

Native120s/verifier180s AFTER imports,8GiB sampled private NOT peak,
350MiB available-commit launch floor,4MiB new package. Exact SymPy algebra;
optional80digit matrix diagnostics require1e-30 scaled agreement. Distinct
completed routes compared before independent verifier importing no native
helper. Save original complete captures before assertions; preserve failed/
unfinished executions and source versions, never relax acceptance silently.

Possible dispositions: bounded correlated-jet/stationary-lift result,
discrepancy, underdefinition or resource inconclusiveness. Success is not an
actual one-loop CT coefficient, chosen scheme, weighted two-loop graph,
C1_GS, RG/refit/alignment or physical-theory verdict. Shared action, VEV/
representation data, qualified tensor, radial-polynomial premises, SymPy and
AI authorship remain limitations; no Lean/external/experimental validation.

Preserve all old evidence/state/source/point/partialGamma/policy/scheme/main/
remote/publication. Authority34/39/state113/sevenfalse; E5/A5 unqualified,
HB1/C5 blocked, flavor human-paused, C1_GS uncomputed, quartetFAIL3960/648,
custodyexit2/seven. Scalar140%/1.94%/20.27% and matching0.745476/Yukawa
limits unchanged. The next decision must address an indispensable C1 input,
not accumulate more generic tests or unrelated295-profile tensors.
