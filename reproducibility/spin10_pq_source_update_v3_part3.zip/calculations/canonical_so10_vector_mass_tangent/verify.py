"""Independent full Gram/projector, stationary lift and congruence replay."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json,time,threading,os
import sympy as s
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
@lru_cache(None)
def c(z):return s.cancel(s.expand(z))
def mat(d):return s.SparseMatrix(*d['shape'],{(i,j):s.sympify(v) for i,j,v in d['entries']})
def zero(M):assert all(c(v)==0 for v in M)
def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=json.loads((D/'validation_preparation.json').read_bytes())
 for n,h in prep['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
 a,b=[json.loads((D/(r+'_result.json')).read_bytes())['calculation'] for r in ['primary','replay']];assert a==b
 data=json.loads((P/'frozen_a10_physical_reconciliation/full_replay.json').read_bytes())
 v=mat(data['vacuum']['VEV']);gg=[];rr=[]
 for sector,lo,hi in [('Phi',0,54),('Sigma',54,306),('S',326,328)]:
  vv=v.extract(range(lo,hi),[0]);rhos=[mat(q) for q in data['representation_matrices'][sector]]
  O=s.Matrix.hstack(*(rho*vv for rho in rhos));gg.append(O.T*O);rr.append(rhos)
 for name,M in zip(['Gram_Phi','Gram_Sigma','Gram_S'],gg):zero(mat(a[name])-M)
 G=sum(gg,s.zeros(45));zero(G-mat(data['vacuum']['orbit_Gram']));zero(gg[2]);zero(gg[0]*gg[1]-gg[1]*gg[0])
 evs=list(map(s.sympify,a['base_eigenvalues']));projectors=[]
 for lam,mult,cweights in zip(evs,a['base_multiplicities'],a['radial_Gram_eigenvalues']):
  pr=s.eye(45)
  for nu in evs:
   if nu!=lam:pr=pr*(G-nu*s.eye(45))/(lam-nu)
  pr=pr.applyfunc(c);assert s.trace(pr)==mult;zero(pr*pr-pr);zero(pr*G-lam*pr)
  for M,coef in zip(gg,cweights):zero(M*pr-s.sympify(coef)*pr)
  projectors.append(pr)
 # A full, independently reconstructed two-VEV family, including cross terms.
 x,y,z=s.symbols('x y z',real=True)
 family=x*x*gg[0]+y*y*gg[1]+z*z*gg[2]
 for lam,pr,cweights in zip(evs,projectors,a['radial_Gram_eigenvalues']):
  cp,cs,c0=map(s.sympify,cweights);zero(family*pr-(cp*x*x+cs*y*y+c0*z*z)*pr)
 J=mat(a['mass_squared_jet_matrix']);C=mat(a['mass_squared_jet_left_relations']);rank=J.rank()
 assert rank==a['jet_rank'] and C.rows==4-rank and C.rank()==4-rank;zero(C*J)
 for row,pr in enumerate(projectors[1:]):
  n=int(s.trace(pr));expected=[2*s.trace(pr*gg[0])/n,2*s.trace(pr*gg[1])/n,0,2*s.trace(pr*G)/n]
  zero(J[row,:]-s.Matrix([expected]))
 assert J[:,0]!=J[:,1] and J[:,2]==s.zeros(4,1) and J[:,3]==J[:,0]+J[:,1]
 # Independent actual norms establish the parent quadratic-mass normalization.
 em=json.loads((P/'frozen_action_ast_a3/A31_embeddings.json').read_bytes())['sectors'];radii=[s.sqrt(60),s.sqrt(60)/10,s.sqrt(60)/10]
 for k,(name,lo,hi) in enumerate([('Phi',0,54),('Sigma',54,306),('S',326,328)]):
  row=em[name];E=s.SparseMatrix(row['ambient_real_dimension'],row['domain_dimension'],{(i,j):s.sympify(z) for i,j,z in row['embedding_entries']})
  norm=((E*v.extract(range(lo,hi),[0])).T*(E*v.extract(range(lo,hi),[0])))[0]
  assert c(norm/radii[k]**2)==[1,1,s.Rational(1,2)][k]
 # Parse positive radial symbols with the same assumptions as the exact output.
 w,sg,vs=s.symbols('omega sigma s',positive=True);mu,Lp,Lm,lps,lss,ls,lsig=s.symbols('muPhi Lp Lm lambdaPhiS lambdaSigmaS lambdaS lambdaSigma1',real=True)
 env={str(q):q for q in [w,sg,vs,mu,Lp,Lm,lps,lss,ls,lsig]}
 decode=lambda d:s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z,locals=env) for i,j,z in d['entries']})
 B=decode(a['tadpole_mass_Jacobian']);H=decode(a['radial_Hessian']);lift=decode(a['stationary_mass_lift_fractional_VEV']);mass=decode(a['stationary_masses'])
 zero(B-s.diag(2*w,2*sg,vs));assert s.factor(B.det())==4*w*sg*vs
 # Hessian from differentiating the explicit stationarity equations, including
 # both mass-factor2 conventions; an independent elementwise replay.
 p,ss,ms=s.symbols('mPhi2 mSigma2 mS2',real=True)
 tad=s.Matrix([2*p*w+3*mu*w*w/s.sqrt(60)+4*Lp*w**3+2*Lm*w*sg*sg+lps*w*vs*vs,
 2*ss*sg+2*Lm*w*w*sg+4*lsig*sg**3+lss*sg*vs*vs,
 ms*vs+lps*w*w*vs+lss*sg*sg*vs+ls*vs**3])
 q=s.Matrix([w,sg,vs]);sub=dict(zip([p,ss,ms],mass));zero(tad.subs(sub));zero(H-tad.jacobian(q).subs(sub));zero(B*lift+H*s.diag(*q))
 # Finite exact stationary family, not just a numerical first derivative.
 t=s.symbols('t');qprime={w:w*(1+t/7),sg:sg*(1-t/11),vs:vs*(1+t/13)}
 mprime=mass.subs(qprime,simultaneous=True)
 zero(tad.subs(qprime,simultaneous=True).subs(dict(zip([p,ss,ms],mprime))))
 wrongB=s.diag(w,sg,vs);assert any(c(z)!=0 for z in wrongB*lift+H*s.diag(*q))
 # Exact noncommuting finite congruence: preserve generalized, not raw masses.
 M=s.diag(2,5);L=s.Matrix([[s.Rational(4,3),s.Rational(1,5)],[s.Rational(1,5),s.Rational(7,6)]]);Af=L.T*L;Mf=L.T*M*L
 assert (Af.inv()*Mf).charpoly().as_expr()==M.charpoly().as_expr()
 assert Mf.charpoly().as_expr()!=M.charpoly().as_expr()
 Z=s.Matrix([[1,2],[2,3]]);dM=(Z*M+M*Z)/2;zero(dM-(Z*M+M*Z)/2);assert dM!=s.zeros(2)
 # The apparent4 diagonal rescaling mass directions are not independent mass
 # parameters when their kinetic partners are retained.
 assert a['field_rescaling_raw_mass_jet_rank']==4 and a['full_generalized_mass_congruence_preserved']
 # Pull back the independently qualified vector part of the log sensitivity.
 weights=[[s.Rational(14,5),0,1],[0,0,0],[5,3,2],[s.Rational(1,5),3,2]];response=s.zeros(3,2)
 for row in range(4):
  for j in range(2):response[:,j]+=-s.Rational(21,2)*s.Matrix(weights[row])*J[row,j]/evs[row+1]
 zero(response-mat(a['fixed_g_vector_lambda1_VEV_response']));zero(response[:,0]+response[:,1]+21*s.Matrix([8,6,5]))
 for k in ['finite_CT_chosen','actual_loop_CT_coefficients_calculated','C1_GS_calculated','authority_changed','Higgs_tuning_and_scalar_spectrum_preserved']:assert not a[k]
 out={'schema':'VECTOR_MASS_TANGENT_VALIDATION_V1','status':'PASS_VECTOR_PARAMETER_GEOMETRY_AND_RADIAL_STATIONARY_LIFT_ONLY',
 'input_bindings':len(prep['input_sha256']),'full_Gram_positions_per_sector':2025,'sectors':3,'vector_projectors':5,
 'canonical_parameter_jet_rank':rank,'independent_heavy_mass_relations':C.rows,
 'raw_field_rescaling_mass_rank':4,'generalized_mass_field_rescaling_invariant':True,
 'tadpole_Jacobian_determinant':'4*omega*sigma*s','all_three_stationary_radial_tangents_lifted':True,
 'Higgs_tuning_preserved':False,'full_counterterm_prescription_constructed':False,'finite_CT_chosen':False,
 'actual_loop_CT_coefficients_calculated':False,'C1_GS_calculated':False,'authority_changed':False,
 'formal_authority':'34/39_UNCHANGED','native_failures':0,'verifier_failures':0,
 'shared_premises':'same action, representation/VEV, prior T and radial V0, SymPy, AI author',
 'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
