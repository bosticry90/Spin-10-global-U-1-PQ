from pathlib import Path
from hashlib import sha256
import json
D=Path(__file__).resolve().parent;p=json.loads((D/'preparation.json').read_bytes())
for n,h in p['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
a,b=[json.loads((D/(r+'_result.json')).read_bytes()) for r in ['primary','replay']]
assert a['calculation']==b['calculation']
files=list(map(Path,p['input_sha256']))+[D/'preparation.json']+[D/(r+'_'+n) for r in ['primary','replay'] for n in ['capture.json','result.json']]
v={'schema':'VECTOR_MASS_TANGENT_VALIDATION_PREPARATION_V1',
'input_sha256':{str(q):sha256(q.read_bytes()).hexdigest() for q in files}}
with (D/'validation_preparation.json').open('xb') as f:f.write((json.dumps(v,indent=2,sort_keys=True)+'\n').encode())
print('VALIDATION_FROZEN',len(files),flush=True)
