# VMT1 derivation

In the actual orthonormal scalar frame write v=vPhi+vSigma+vS. These
sectors are orthogonal and rho_a is block diagonal, so

    G(v)=O(v)^T O(v)=GP+GS+Gsinglet,
    O_sector,a=rho_a v_sector.

Gsinglet must vanish by actual contraction. Radial rescaling by factors x,y,z
gives G(x,y,z)=x^2 GP+y^2 GS, including every off-diagonal entry. This is a
parametric tree mass operator, not a loop self-energy. Independent replay
uses dG_ab[v_sector]=sum_I v_sector,I(T_abI+T_baI)=2Gsector_ab. Retain the
ghost ordering of T; an arbitrary symmetrized replacement is not accepted as
the full tensor, even though this particular radial contraction is blind to
its antisymmetric part (BFT1 established that limitation).

For the exact base Gram eigenvalues0,3/10,3/2,25,253/10 form Lagrange
spectral projectors P_r. Determine cPr=Tr(P_r GP)/rank(P_r) and cSr likewise,
then check the FULL identities GP P_r=cPr P_r and GS P_r=cSr P_r and pairwise
orthogonality/completeness. This establishes simultaneous radial diagonalization
even in nontrivial degenerate mass subspaces. Fractions alpha,beta,chi produce
deltaG=2alpha GP+2beta GS; the geometric gamma column is2gamma G.
The complete rank/nullspace of the four heavy eigenvalue jets follows from
this actual projected matrix, including any exact relations between mass sets.
Predicted possibilities include a lower-rank map; this is not assumed merely
because there are two charged VEVs. The dimensionful radial formula is recovered
by dividing cP by omega0^2=60 and cS by sigma0^2=3/5.

With fixed g and mu, the vector part of MST1 pulls back to the actual VEV
fractions by -21/2 sum_r TV_i,r deltaG_r/G_r. Use the independently qualified
four SM index vectors. No scalar-potential contribution, finite two-loop graph
or pure-background normalization is included in that partial response. Applying
a finite gauge-coupling change additionally requires its tree and coupling
transport; the geometric gamma column is not that calculation.

The parent quadratic invariants are p2, N, |S|^2. In normalized radial
coordinates q=(omega,sigma,s), the actual embeddings must yield respectively
omega^2,sigma^2,s^2/2. Thus the derivative of radial tadpoles with respect to
(mPhi2,mSigma2,mS2) is

    B(q)=diag(2omega,2sigma,s).

It is invertible for the frozen nonzero VEVs, without requiring inversion of
the scalar Hessian. Let Hrad=partial_q^2 V0 at stationary masses. If all
other parent coefficients are fixed, any specified radial tangent dq has
the unique quadratic-parameter tangent dm=-B^-1 Hrad dq. This is an implicit
stationary-family derivative, not a finite tadpole choice or a physical loop
shift. More generally dm=-B^-1(Hrad dq+partial_p(t)dp-delta_t), where delta_t
is a separately prescribed tadpole variation when a convention supplies one.
No numerical value is supplied here.

Reuse the exact qualified vacuum polynomial with Lp=lambdaPhi1+7lambdaPhi2/60,
Lm=lambdaPhiSigma1-lambdaPhiSigma2/4:

    V0=mPhi2*omega^2+mSigma2*sigma^2+mS2*s^2/2
       +muPhi*omega^3/sqrt60+Lp*omega^4+Lm*omega^2*sigma^2
       +lambdaPhiS*omega^2*s^2/2+lambdaSigma1*sigma^4
       +lambdaSigmaS*sigma^2*s^2/2+lambdaS*s^4/4.

Replay differentiates the independently recorded solved masses
mPhi2=-3muPhi*omega/(2sqrt60)-2Lp*omega^2-Lm*sigma^2-lambdaPhiS*s^2/2,
mSigma2=-Lm*omega^2-2lambdaSigma1*sigma^2-lambdaSigmaS*s^2/2,
mS2=-lambdaPhiS*omega^2-lambdaSigmaS*sigma^2-lambdaS*s^2.
Check that B*(D mstar)+Hrad=0 identically. The inherited H-singlet census and
phase/gauge identities delimit this ansatz's stationary family. No new global
vacuum, Higgs tuning, scalar positivity or quantum stationarity claim follows.

Finally, for a real symmetric field-normalization jet Z, transverse quadratic
data A=I and Bmass=G transform by L=I+ell Z/2:

    delta A=Z,
    delta Bmass=delta Gparam+(ZG+GZ)/2.

Canonicalizing the kinetic term subtracts (delta A G+G delta A)/2, leaving
delta Gparam. Exact finite congruence preserves the generalized spectrum of
(A,Bmass); keeping only the mass congruence does not. Antisymmetric field
rotations generate a basis commutator, not new eigenvalue parameters. This is
an algebraic distinction between field and parameter CTs, not proof of the
complete model CT module or a pole-mass renormalization condition.
