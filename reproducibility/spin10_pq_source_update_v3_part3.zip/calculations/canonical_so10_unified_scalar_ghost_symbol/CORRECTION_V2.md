# Exact metadata correction after preserved V1 export failure

Original primary V1 exited1 during final JSON export. Its algebra, prior mass
specialization, scalar-pair sums, actual40-profile/coupling census and controls
had executed, but no result was exported or qualified. Original symbol.py,
fixture.py,sources,preparation,controllers and complete failed captures remain
immutable. No failed output is accepted as a computed result.

The linked fixture metadata contained SymPy Integer entries from Matrix.tolist
and list(Matrix). JSON rejects those exact mathematical objects. V2 changes
ONLY those metadata lists to explicit Python integers. It does not change a
matrix value,Hessian,coefficient,unit,identity,sign or acceptance requirement.
No broad default=str serializer hides unexpected scientific object types.
The symbolic source otherwise changes only versioned preparation/fixture names.

V2 uses symbol_v2.py,fixture_v2.py,preparation_v2.json and separate controller,
exclusive source mirrors and role_v2 result/capture paths. Same120sec after
imports/8GiB/min350MiB available commit limits. A JSON roundtrip of fixture
metadata is added to prelaunch type checks. No original replay was launched;
both required native routes must complete under V2 before independent checking.
This delegated routine correction adds no physics scope or protected authority.

The avoidable omission was failing to typecheck the diagnostic metadata before
launch. Preserve it in Track B alongside the later scientific verdict;the
serialization failure is not evidence for a nonzero or vanishing physical pole.
