"""One ordered scalar/ghost Gaussian UV symbol;no actual color pole extraction."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
from itertools import permutations
from functools import lru_cache
import json,sys,os,time,threading
import importlib.util
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
PAR={x:1 for x in ['L','T','X','Xr','U','V']};GHOST={'A':2,'L':1,'T':1,'X':1,'Xr':1,'U':1,'V':1,'Q':2,'R':2};SCALAR={'K':1,'Kt':1,'Z':1};COST={'D':(2,0,0),'F':(1,0,0),'M':(1,1,1),'Y':(2,1,1),'X':(0,1,0),'K':(1,0,0),'H':(2,0,0),'Q':(1,1,0),'R':(2,1,0)}
FAMILIES={'DMM':(['D','M','M'],0),'FMY':(['F','M','Y'],0),'YY':(['Y','Y'],0),'FFMM_generic':(['F','F','M','M'],0),'DMK':(['D','M','K'],1),'FYK':(['F','Y','K'],1),'FFMK':(['F','F','M','K'],1),'FFY':(['F','F','Y'],1),'YR':(['Y','R'],1),'FMKX':(['F','M','K','X'],1),'FYX':(['F','Y','X'],1),'YQ':(['Y','Q'],1),'YKX':(['Y','K','X'],1),'DKK':(['D','K','K'],2),'DH':(['D','H'],2),'FXKK':(['F','X','K','K'],2),'FXH':(['F','X','H'],2),'FFKK':(['F','F','K','K'],2),'FFH':(['F','F','H'],2),'XXKK':(['X','X','K','K'],2),'XXH':(['X','X','H'],2)}
def auth(folder,name,receipt='validation_receipt.json'):
 p=OUT.parent/folder/name;r=read(p.parent/receipt);assert r['execution_state']=='COMPLETED' and r['input_sha256'][str(p)]==digest(p);return read(p)
def plus(A,B):
 C=dict(A)
 for k,z in B.items():
  C[k]=s.expand(C.get(k,0)+z)
  if C[k]==0:del C[k]
 return C
def pmul(A,B):
 C={}
 for(p,w),x in A.items():
  for(q,v),y in B.items():C=plus(C,{(p+q,w+v):x*y})
 return C
def mm(A,B):
 cols=defaultdict(list);C={}
 for(k,j),P in B.items():cols[k].append((j,P))
 for(i,k),P in A.items():
  for j,Q in cols[k]:
   v=plus(C.get((i,j),{}),pmul(P,Q))
   if v:C[i,j]=v
   else:C.pop((i,j),None)
 return C
def rotation(word):
 rows=[]
 for k in range(len(word)):
  a,b=word[:k],word[k:];rows.append((b+a,(-1)**(sum(PAR.get(x,0) for x in a)*sum(PAR.get(x,0) for x in b))))
 best=min(w for w,z in rows);signs={z for w,z in rows if w==best};return best,next(iter(signs)) if len(signs)==1 else 0
def merge_word(C,word,z):
 w,sg=rotation(word)
 if sg:
  C[w]=s.expand(C.get(w,0)+sg*z)
  if C[w]==0:del C[w]
def rows(A):return [[list(w),str(z)] for w,z in sorted(A.items())]
def kernel(reduced=True,p=None,wrong_mixed=False,omit_Z=False):
 G={};V={k:{} for k in COST}
 def put(A,i,j,word=(),z=1,power=0):A[i,j]=plus(A.get((i,j),{}),{(power,tuple(word)):s.sympify(z)})
 if reduced:
  B,LAM,S,F=0,1,2,3;put(G,B,B,('W',),-1,-2);put(G,B,LAM,(),s.I,-1);put(G,LAM,B,(),s.I if wrong_mixed else -s.I,-1);put(G,S,S,(),1,-1);put(G,F,F,('J',),1,-1);put(V['D'],B,B,('A',),1,1);put(V['F'],B,F,('L',),1,1);put(V['F'],F,B,('T',),1,1);put(V['K'],B,S,('K',),s.I,1);put(V['K'],S,B,('Kt',),-s.I,1);put(V['H'],B,B,('K','Kt'),1,1)
 else:
  LAM,S,F=4,5,6;eta=[1,-1,-1,-1];P=sum(e*x*x for e,x in zip(eta,p));assert P!=0
  for mu in range(4):
   for nu in range(4):put(G,mu,nu,(),-s.Rational(eta[mu]*int(mu==nu),P)+s.Rational(p[mu]*p[nu],P**2));put(G,mu,nu,('W',),-s.Rational(p[mu]*p[nu],P**2))
   put(G,mu,LAM,(),s.I*p[mu]/P);put(G,LAM,mu,(),(s.I if wrong_mixed else -s.I)*p[mu]/P);put(V['D'],mu,mu,('A',),eta[mu]);put(V['F'],mu,F,('L',),eta[mu]*p[mu]);put(V['F'],F,mu,('T',),eta[mu]*p[mu]);put(V['K'],mu,S,('K',),s.I*eta[mu]*p[mu]);put(V['K'],S,mu,('Kt',),-s.I*eta[mu]*p[mu]);put(V['H'],mu,mu,('K','Kt'),eta[mu])
  put(G,S,S,(),s.Rational(1,P));put(G,F,F,('J',),s.Rational(1,P))
 put(V['M'],LAM,S,('E',));put(V['M'],S,LAM,('Et',));put(V['Y'],S,F,('U',));put(V['Y'],F,S,('V',))
 if not omit_Z:put(V['Y'],F,F,('Z',))
 put(V['X'],LAM,F,('X',));put(V['X'],F,LAM,('Xr',));put(V['Q'],F,F,('Q',));put(V['R'],F,F,('R',));return G,V,F
def compute(reduced,route,p=None,wrong_trace=False,wrong_mixed=False,omit_Z=False,transverse_rank=3):
 G,H,odd=kernel(reduced,p,wrong_mixed,omit_Z);M={t:mm(G,A) for t,A in H.items()};ans={};pieces={}
 for name,(seq,degree) in FAMILIES.items():
  n=len(seq);total={};pp=[];orders=sorted(set(permutations(seq)));factor=-s.Rational((-1)**(n+1),n)
  if not reduced:factor*=sum(e*x*x for e,x in zip([1,-1,-1,-1],p))**2
  for order in orders:
   image={}
   def consume(start,word,co,power):
    if sum(GHOST.get(x,0) for x in word)!=2 or sum(SCALAR.get(x,0) for x in word)!=degree:return
    if reduced:assert power+2==0,(name,word,power)
    merge_word(image,word,co*(-1 if start==odd and not wrong_trace else 1)*factor)
   if route=='primary':
    A=M[order[0]]
    for t in order[1:]:A=mm(A,M[t])
    for(i,j),C in A.items():
     if i==j:
      for(power,word),z in C.items():consume(i,word,z,power)
   else:
    edges={t:defaultdict(list) for t in order}
    for t in edges:
     for(i,j),C in M[t].items():edges[t][i].append((j,C))
    def walk(start,at,word,co,power,k):
     if k==n:
      if at==start:consume(start,word,co,power)
      return
     for j,C in edges[order[k]].get(at,[]):
      for(pw,ww),z in C.items():walk(start,j,word+ww,co*z,power+pw,k+1)
    for i in sorted({i for i,j in M[order[0]]}):walk(i,i,(),s.S.One,0,0)
   if reduced and all(t in ['D','H'] for t in order):
    word=tuple(x for t in order for x in (('A',) if t=='D' else('K','Kt')));merge_word(image,word,transverse_rank*(-1)**n*factor)
   for w,z in image.items():merge_word(total,w,z)
   pp.append({'order':list(order),'terms':rows(image)})
  ans[name]=rows(total);pieces[name]=pp
 return ans,pieces
def generic_projectors():
 p=s.Matrix(s.symbols('p0:4',real=True));eta=s.diag(1,-1,-1,-1);n=eta*p;P=(p.T*n)[0];PL=p*n.T/P;PT=s.eye(4)-PL;dual=n.T/P;Ipart=-eta/P+p*p.T/P**2;Wpart=-p*p.T/P**2
 checks=[PL*PL-PL,PT*PT-PT,PL*PT,PT*PL,PT*p,n.T*PT,Ipart*n,Wpart*n+p/P,dual*Ipart*dual.T,dual*Wpart*dual.T+s.ones(1)/P**2,dual*p-s.ones(1),p.T*eta*p-s.ones(1)*P]
 assert all(all(s.cancel(x)==0 for x in A) for A in checks) and s.cancel(s.trace(PT)-3)==0 and s.cancel(s.trace(PL)-1)==0
 return {'generic_nonnull_p_primitive_matrix_identities':len(checks),'transverse_rank':3,'longitudinal_rank':1,'Lorentz_generators_only_eta_n_p_and_scalar_color_matrices':True,'trace_similarity_only_not_quantum_field_redefinition':True,'W_is_ordered_color_word_not_scalar':True}
@lru_cache(None)
def number(z):return s.sympify(z)
def raw_census(role):
 p=PKG/'frozen_a10_e2_transport'/(role+'.json');bind=read(p.parent/'bindings.json');assert bind['byte_sha256'][p.relative_to(ROOT).as_posix()]==digest(p);data=read(p);out=defaultdict(list);g=s.Symbol('g10');xi=s.Symbol('xi')
 for r in data['gauge_fixing_density']:
  word=r['word'];ty=sorted('x' if n.startswith('x_') else'a' if n.startswith('ub') else n[0] for n in word)
  tag={'L,x':'M','C,a,x':'Y','C,L,a':'X','C,C,a,a':'QR'}.get(','.join(ty))
  if tag is None:continue
  assert all('__' not in n for n in word)
  for(a,),co in s.Poly(number(r['coefficient']),g).terms():
   label=('Q' if a==1 else'R') if tag=='QR' else tag;assert a==COST[label][0];z=s.cancel(co/xi);assert not z.free_symbols;out[label].append({'word':word,'stripped_coefficient':str(z)})
 for tag in out:out[tag].sort(key=lambda r:(r['word'],r['stripped_coefficient']))
 assert len(out['M'])==432 and len(out['Y'])==6688 and all(out[t] for t in ['X','Q','R']);return dict(out)
def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(OUT/'preparation.json');assert role in ['primary','replay'] and digest(Path(__file__))==prep['source_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('UNIFIED_SCALAR_SYMBOL_WRITE')
  if p.suffix=='.json':assert str(p.resolve()) in allowed,('UNDECLARED_OR_PEER_JSON',str(p))
 sys.addaudithook(guard);projector=generic_projectors();prior=auth('canonical_so10_higher_scalar_pair_reduction',role+'_result.json');mass=auth('canonical_so10_ghost_mass_g4_reduction',role+'_v2_result.json');support=auth('canonical_so10_scalar_ghost_support',role+'_result.json');current=auth('canonical_so10_ghost_mass_g4_integration',role+'_result.json');lor=auth('canonical_so10_fourghost_g4_lorentz',role+'_result.json');scalar=auth('canonical_so10_antighost_g2_scalar_zero','primary_result.json' if role=='primary' else 'replay_v2_result.json');uv=auth('canonical_so10_ordered_multiheat_uv_log',role+'_v2_result.json');assert uv['unheated_complete_classical_minus4_symbol_alone_determines_leading_log'] and lor['actual_all_four_Lorentz_copy_normalization_qualified_by_primary'] and scalar['all328_scalar_directions_retained_no_projected_scalar_inverse'];print('STAGE '+role+' complete_ordered_unified_symbol_all_families',flush=True)
 if role=='primary':formula,words=compute(True,'primary')
 else:
  formula,words=compute(False,'replay',[3,1,1,1]);second,pp=compute(False,'replay',[5,2,1,0]);assert formula==second and words==pp
 for tag in ['DMM','FMY','YY']:assert formula[tag]==mass['formal_freeword_normalized_formula'][tag]
 def combine(a,b):
  C={}
  for w,z in formula[a]+formula[b]:merge_word(C,tuple(w),number(z))
  return rows(C)
 pairs={k:combine(a,b) for k,a,b in [('D','DKK','DH'),('FX','FXKK','FXH'),('FF','FFKK','FFH'),('XX','XXKK','XXH')]};assert pairs['D']==[[['A','K','Kt'],'3']] and not any(pairs[k] for k in ['FX','FF','XX']);raw=raw_census(role);ledger=prior['all664_updated_scope_rows'];selected=[r for r in ledger if not r['complete_scope_match'] and r['types'] in [['C','a','x'],['C','a','x','x']]];assert len(selected)==40;families={tuple(sorted(seq)):name for name,(seq,deg) in FAMILIES.items()};mapped=[]
 for r in selected:
  seq=tuple(sorted({'O_LX':'M','O_aCX':'Y','S3':'K','S4':'H'}.get(t,t) for t in r['family']));name=families[seq];degree=2 if r['types']==['C','a','x','x'] else 1;assert FAMILIES[name][1]==degree and r['coefficient_dimension']==2-degree and not r['descriptor']['scalar_reference_mass_expansions'] and r['jets']==0;g=sum(COST[t][0] for t in seq);xi=sum(COST[t][1] for t in seq);assert g==r['g'] and xi==r['descriptor']['explicit_vertex_xi'];mapped.append({'index':r['index'],'family':name,'g':g,'explicit_vertex_xi':xi,'scalar_degree':degree,'coefficient_dimension':2-degree,'BB_width_roles':r['descriptor']['BB_width_roles']})
 noZ,_=compute(True,'primary',omit_Z=True);wrong,_=compute(True,'primary',wrong_trace=True);flip,_=compute(True,'primary',wrong_mixed=True);rank2,_=compute(True,'primary',transverse_rank=2);commuted={}
 for name in ['DMK','FYK','FFMK','FFY']:
  C={}
  for w,z in formula[name]:
   w=tuple(w);j=w.index('W') if 'W' in w else-1
   if j>0:w=w[:j-1]+(w[j],w[j-1])+w[j+1:]
   merge_word(C,w,number(z))
  commuted[name]=rows(C)
 rank2pair={}
 for w,z in rank2['DKK']+rank2['DH']:merge_word(rank2pair,tuple(w),number(z))
 controls={'omit_Y_ghost_block_changes_linear_families':any(formula[k]!=noZ[k] for k in ['FFY','FYX','YQ','YR']),'omit_Q_or_R_changes_distinct_coupling_orders':bool(formula['YQ']) and bool(formula['YR']),'ordinary_instead_of_supertrace_changes_unified_symbol':formula!=wrong,'reverse_one_mixed_reference_sign_changes_mass_control':formula['DMM']!=flip['DMM'],'drop_one_transverse_direction_changes_scalar_pair':pairs['D']!=rows(rank2pair),'move_W_through_neighbor_changes_ordered_linear_symbol':any(formula[n]!=commuted[n] for n in commuted),'drop_existing_Y_mixed_role_changes_mass_YY':bool(formula['YY'])};assert all(controls.values());sp=importlib.util.spec_from_file_location('linked_gaussian_fixture_values',OUT/'fixture.py');fx=importlib.util.module_from_spec(sp);sp.loader.exec_module(fx);fixture=fx.evaluate(formula,{name:d for name,(seq,d) in FAMILIES.items()})
 result={'schema':'UNIFIED_SCALAR_GHOST_BILINEAR_SYMBOL_V1','route':role,'scientific_disposition':'COMPLETE40_PROFILE_UNIFIED_ORDERED_SYMBOL_NOT_ACTUAL_COLOR_POLES','generic_projector_trace_reduction':projector,'normalized_ordered_family_formulas':formula,'all_distinct_normalized_Born_words':words,'complete_scalar_pair_sums':pairs,'all40_actual_profile_family_correspondence':mapped,'family_power_table':{k:{'g':sum(COST[t][0] for t in seq),'explicit_vertex_xi':sum(COST[t][1] for t in seq),'scalar_degree':d,'fixed_coefficient_dimension':sum(COST[t][2] for t in seq)} for k,(seq,d) in FAMILIES.items()},'actual_raw_GF_vertex_census':raw,'raw_GF_counts':{k:len(v) for k,v in raw.items()},'linked_Gaussian_fixture':fixture,'generic_FFMM_is_actual_excluded_profile':2025,'actual_FFMM_structural_zero_preserved_not_generic_color_identity':2025 in mass['actual_structurally_zero_profiles'],'already_qualified_actual_physical_blocks':['A','L','T','R','E','Et','U','V'],'remaining_physical_operator_transport_before_color_evaluation':['K(s) and Kt(s) in actual B/scalar frames','X and Xr actual even/odd Hessians','Q actual g1 quartic-ghost Hessian','Z(s) actual g2 orbit odd Hessian linked to U/V'],'current_known_terms':current['updated_known_terms'],'current_known_sha256':current['updated_known_sha256'],'sourcefree_positions':41452,'sourceimage_positions':146663,'all_seven_quantum_flags_false':current['all_seven_quantum_flags_false'],'controls':controls,'insensitive_controls':['width_changes_do_not_change_complete_mass_or_scalar_pair_controls'],'new_actual_color_pole_or_canonical_integration':False,'new_loop_integral_full_functional_or_authority_change':False,'full_QAP_IR_measure_products_contacts_equivalence_sourcefree_Slavnov_E5_A5_proved':False,'shared_limits':'Inherited actual action/Hessian/principal/UV/catalogue premises,software and AI author. Generic graded reduction and raw census,not newly transported physical blocks or actual pole coefficients','elapsed_after_imports':time.perf_counter()-tick};assert not any(result['all_seven_quantum_flags_false'].values());print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
