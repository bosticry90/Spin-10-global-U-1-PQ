# Unified constant-scalar ghost-bilinear UV symbol V1

Base41f2d58f8c8e0bef1415fcabf8248b9d4ebbc17a,clean main,no live workers.
Previous goal turn PROGRESS; full Spin(10)xPQ goal stays active. USG1 asks
whether one finite Gaussian symbol represents all remaining40 scalar-bearing
profiles,with zero/one/two external scalar specializations rather than40
separate integrals. USG2 tests complete family applicability and identifies
the actual classical block transports needed before physical color evaluation.
This is a reduction,not a measured new pole or a source/Slavnov fit.

Freeze V278 full56-pair proof/current664 ledger,V277 full112 refined support,
V274 actual mass-family reduction,V275 actual field/orbit pole checks,V270
actual D/F/R Hessian forms,V261 scalar kinetic/Wick theorem,V252 actual
principal and V255 ordered-heat local UV correspondence. Current V276
functional155143/sourcefree41452/sourceimage146663 remains unchanged.

Keep the actual physical-principal blocks B45,Lambda45,scalar328,odd(C45,a45),
full four-dimensional momentum p,P=p.eta.p!=0,graded J and both widths W.
Define D(A),F(L,T),X(X,Xr),M(E,Et),Y(U,V,Z(s)),kinetic S3(K(s),Kt(s)),
S4(H=K Kt),and BOTH Q/R odd Hessians. Xr=-X^t and V=-U^t for nondifferentiated
mixed fields; Fourier F has T=L^t. Never identify these transpose rules.
Y with an external scalar gives Z(s);with an external ghost gives U,V.
M/Y carry one fixed mass dimension and explicit vertex xi each. Preserve
every ghost derivative,Grassmann sign,relative Gaussian and Bose factor.

The candidate leading-log expression is the degree-minus4,ghost-degree2,
scalar-degree0/1/2 part of the unchanged finite Born supertrace. Enumerate
all distinct vertex orders,including repeats,with i*(-1)^(n+1)/(2n). Use the
qualified separated UV residue2i in32pi^2 units,not a whole scaleless zero.
All nine actual linear-scalar family contexts and complete D scalar-pair
cohort must be present. Mass DMM/FMY/YY and V278 pair zeros are independent
specialization controls,never normalization targets to fit.

Primary reduces the generated Lorentz tensor algebra to rank3 transverse
and rank1 longitudinal sectors,retaining W as a noncommuting color word.
Use the non-normalized longitudinal basis p and dual eta*p/P only inside
finite traces;this is not a quantum field redefinition or scheme choice.
Prove the generic projector/intertwining identities before evaluating a
momentum. Replay follows full four-component Lorentz/graded block paths at
two distinct nonnull momenta. Those finite points are diagnostics;the generic
projector algebra establishes arbitrary-p scope. Verify every ordered word,
matrix order,explicit xi count,scalar/mass degree and UV homogeneity.

Authenticate the actual raw GF M/Y/X/Q/R census from frozen E2,both role
catalogues and actual refined supports. New physical K(s),X/Xr,Q,Z(s)
operator transports are NOT assumed available merely because raw blocks
exist. Report exactly which are still needed. E/U/V,A/L/T/R already have
qualified full physical maps;reusing their definitions is not fresh replay.
A formal trace formula alone must not be called an evaluated physical pole.

Independent verification uses its own block-path and graded cyclic algebra,
generic projector proof,and a linked cubic/quartic Gaussian diagnostic with
noncommuting color matrices. Compare every actual family/profile and prior
specialization,not one convenient tensor component. Sensitive controls omit
Z,Q/R,one mixed Fourier sign,supertrace grading,transverse rank or width
ordering. Disclose controls made insensitive by empty/type-zero scopes.
Never include a generic path excluded by actual ports as an actual amplitude.

Two sequential native workers and one independent verifier,each120sec after
imports/8GiB sampled private/min350MiB available commit. Freeze sources,
role reads,actual receipt paths,types,diagnostic data and exclusive mirrors
before workers. Missing premises,manifest mismatch,resource exhaustion or
method disagreement leave the affected result incomplete,preserved exactly.
No auto expansion/truncation;version delegated routine corrections if needed.

No dense actual color tensor,new momentum integral,canonical integration,
full functional reconstruction/variation,parameter search or physical input.
No scope ledger promotion for surviving families solely from this formula.
Authority34/39/seven flags false;full sourcefreeSlavnov,QAP,measure,IR,32
nonlinear products,contacts,equivalence,E5/A5/GUT viability unqualified.
HB1/C5 blocked,flavor paused;quartet candidate/scalar140%/gauge matching/
custodyexit2-seven limitations unchanged. No benchmark,scheme,policy,authority,
agent,branch/worktree,remote,publication or full-goal completion. Shared exact
actions/catalogue/prior proofs/UV/chart premises,software and AI author limit
independence. Validate before local commit and authenticate exact custody.
