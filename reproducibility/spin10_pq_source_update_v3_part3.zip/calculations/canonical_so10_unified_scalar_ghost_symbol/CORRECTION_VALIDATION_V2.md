# Correct the verifier's even/odd differentiation rule, preserve its failure

The independent V1 verifier completed its generic full-Lorentz word checks,
actual40-profile correspondence and raw-action census,then FAILED on the
literal diagnostic FMY coefficient:738 versus frozen native expected-1032.
No validation receipt exists for that run. Its sources,preparation and complete
validation_capture.json/external capture remain immutable. No result is qualified
by its earlier successful subchecks.

The literal Hessian helper used (-1)^prefix for EVERY left derivative. That
is wrong for an even field: the exponent must be parity(field)*prefix. The
same omission affected the second derivative. An even B sitting after an
odd antighost in an F density therefore received a spurious sign. This is a
checker implementation error,not a new convention for Grassmann differentiation.

fixture_check_v2.py multiplies both prefix exponents by the differentiated
field parity. It adds complete invariance checks under moving all even fields
to the front of each literal monomial,plus the F Fourier transpose and the
opposite nondifferentiated X/Y transpose and Q/R antisymmetry. These sensitive
checks would have caught the original defect BEFORE Gaussian evaluation.
The unchanged canonical formula,expected fixture coefficients and every native
V2 calculation remain required;no value is fitted or acceptance check relaxed.

verify_v2.py and versioned preparation/controller/capture reuse both completed
native V2 runs. Same120sec-after-imports/8GiB/min350MiB available-commit limits.
Independent failures count1. If the corrected literal calculation still differs,
preserve that difference and stop qualification. This routine correction under
AGENTS.md changes no physics,action,input,scope,scheme or authority.

Track B: shared symbolic success did not protect an independently coded graded
derivative harness. The failure and algebraically justified correction must
remain visible alongside the eventual scientific verdict.
