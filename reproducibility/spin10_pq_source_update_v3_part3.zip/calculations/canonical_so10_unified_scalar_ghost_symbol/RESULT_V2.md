# A common ordered symbol for the remaining scalar-dependent ghost terms

USG1/USG2, parent `41f2d58f8c8e0bef1415fcabf8248b9d4ebbc17a`.
This is a prospective qualification report. Completed independent validation,
exact bindings and committed-byte checks are required; native agreement alone
does not qualify it. The full Spin(10) x PQ investigation remains active.

The remaining 40 scalar-bearing profiles fit one constant-background Gaussian
symbol. It supplies ordered trace formulas for all nine linear-scalar family
contexts and reproduces the complete previously established scalar-pair and
intrinsic mass reductions. It does not supply new evaluated Spin(10) color
coefficients. Four groups of physical operator transports remain necessary
before those formulas can be used for actual coefficient extraction.

This is useful because the next calculation need not reconstruct 40 separate
loop integrals. The relevant momentum reduction and relative weights are now
organized together, including terms absent from the scalar-pair analysis.

## What must be retained

The odd field order is (C45,a45), with its actual oriented inverse J/P.
Besides the existing D(A), F(L,T), M(E,Et), and mixed Y(U,V), the symbol
includes X/Xr, both Q/R quartic ghost Hessians, and Y's odd block Z(s) when
the external field is scalar. K(s),Kt(s) are the scalar kinetic mixed blocks;
H=K Kt is the kinetic contact. These are Hessian definitions from the same
action, not additional physical interactions.

The Fourier F relation T=L^t differs from the nondifferentiated mixed-field
relations Xr=-X^t and V=-U^t. The scalar-background Y block Z(s) cannot be
replaced by its mixed U/V roles. Ordinary propagator widths W remain ordered
color matrices, separate from explicit vertex xi factors.

The actual raw E2 census gives M432, Y6688, X276, Q648 and R418 rows after
stripping only their declared g/xi factors. Both roles reproduce every row
and exact coefficient. These are raw C3 density counts, not physical tensor
support counts or particle numbers. In particular, Q is orderg1 and R orderg2;
neither can be silently folded into the other.

## Lorentz and Gaussian reduction

Generic nonnull-p projector identities establish a rank-three transverse and
rank-one longitudinal decomposition of the generated Lorentz tensor algebra.
Every B-index vertex is eta or n=eta*p; every mixed reference edge is p.
Paths leaving the vector Lorentz space are longitudinal. Pure transverse
cycles contain only D and the scalar kinetic contact.

In the nonnormalized longitudinal basis p, with dual n^t/P, the inverse is

    G_BB=-W/P^2, G_BL=i/P, G_LB=-i/P, G_ss=1/P, G_ff=J/P.

The corresponding D/F/K/contact B entries acquire P. Each transverse copy
has G_T=-1/P. This is a finite trace calculation, not a quantum field
redefinition or a new prescription. It makes no claim about a measure Jacobian.

The primary multiplies these ordered blocks. The replay follows all full
four-component Lorentz block paths at two different nonnull momenta. Generic
projector identities establish arbitrary-p applicability; those two momenta
check implementation and do not substitute for the generic argument.

Every distinct Born order is retained with i*(-1)^(n+1)/(2n), including repeated
vertices and graded cyclic signs. The inherited separated UV normalization
multiplies the complete degree-minus4 coefficient by 2i P^2 in32pi^2 units.
No scaleless-integral zero, commuting-color assumption or Ward fit is used.

## The nine linear-scalar formulas

The following entries denote ordered finite traces. All matrices are stripped
only of the action's declared coupling and explicit xi factors. Each K/Kt/Z
is linear in the external scalar; E/U/V have their fixed dimensionful orbit
coefficients. Every expression has external ghost degree2.

| Family | Reduced ordered trace polynomial |
| --- | --- |
| D-M-K | Tr(A E Kt W)+Tr(A W K Et) |
| F-Y-K | -i Tr(J T W K U)+i Tr(J V Kt W L) |
| F-F-M-K | -Tr(E Kt W L J T)-Tr(Et L J T W K) |
| F-F-Y | -Tr(J T W L J Z) |
| Y-R | -Tr(J R J Z) |
| F-M-K-X | i Tr(E Kt X J T)-i Tr(Et L J Xr K) |
| F-Y-X | i Tr(J T X J Z)-i Tr(J Xr L J Z) |
| Y-Q | -Tr(J Q J Z) |
| Y-K-X | Tr(J V Kt X)+Tr(J Xr K U) |

The last four rows contribute at g3*xi^2. The first four contribute at g4*xi;
Y-R contributes at g4*xi^2. These power assignments distinguish explicit
vertices from W's later physical eta_H/xi specialization. There is no favorable
numerical width choice. All 22 actual scalar-single descriptors match these
families, with their actual width-role sets and coefficient dimension1.

The 18 surviving scalar-pair profiles occupy complete D-K-K/D-H pairs. Their
sum is +3Tr(A K Kt) after the inherited Minkowski UV normalization, matching
V278's Euclidean Gaussian -3Tr(A K Kt)/(2Q^2) bridge. F-X, F-F and the old
X-X kinetic pair sums remain zero. The three intrinsic mass expressions exactly
reproduce V274 before any actual coefficient is evaluated or cancellation sought.

A generic FFMM term also exists without actual port restrictions. The actual
profile2025 remains structurally excluded; it is not reinstated as an amplitude
or declared a universal color zero. Every generic diagnostic expression and
actual-family boundary is retained in the result.

## Independent validation and diagnostic scope

Qualification requires a separate exact Gaussian-rational calculation of every
ordered word through alternating full Lorentz G/H paths, generic projector
checks, both raw censuses, all 40 actual profile assignments and controls.
A linked cubic/quartic diagnostic separately derives Fourier/graded Hessians
from a literal density and checks the full 17-field Gaussian against all21
formal family values. Its rho/E/Y link and noncommuting W/H are controls,
not proposed physical inputs. Two external Grassmann variables project the
diagnostic onto one ghost bilinear; generic word algebra supplies the broader
matrix scope. Degree projection there is exact grading, not resource truncation.

Omitting Z, Q/R, a mixed-reference sign, supertrace grading, transverse rank
or the W order changes the stated generic formulas. Width changes are
insensitive for the complete mass/scalar-pair controls. Neither that insensitivity
nor a zero diagnostic entry is counted as independent error detection.

## Preserved failed export and exact correction

Original primary V1 failed at final JSON serialization, exit1. Its complete
capture and all original sources/manifests remain. The algebra checks had
executed, but no result was exported or qualified. The defect was SymPy
integers in fixture metadata from Matrix.tolist/list(Matrix).

V2 converts only those metadata entries to Python integers, adds a prelaunch
metadata-serialization check, and uses separate versioned sources, manifests,
results and captures. It changes no matrix, mathematical assertion, coefficient,
normalization or resource limit. No broad default=str serializer hides unknown
types. Both native V2 routes have completed; independent completion and final
failure/resource counts are determined by the actual receipt and captures.
Each worker remains bounded by120sec after imports,8GiB sampled private memory
and min350MiB available commit. The missed metadata type preflight is an
avoidable Track B engineering failure, not a failed physics prediction.

## Exact next dependency and unchanged standing

The previously qualified full physical blocks A/L/T/R and E/Et/U/V remain
available. New physical K/Kt, X/Xr, Q and Z(s) must be extracted and verified
in the actual field frames before color evaluation. Raw rows, a formal Hessian
definition or an invertible coordinate map alone do not qualify that transport.
Z must be checked against the same Y density as U/V; scalar K must match the
actual kinetic action and gauge-frame conventions. This is the next dependency,
not an invitation to fit an unknown coefficient from a desired identity.

No new canonical term is integrated and no current scope-ledger profile is
promoted merely from these formulas. The functional stays155143 words/hash
`fe6bd8e800d8e04f9d0358ce94c081d70e94af0ffd37830bb50c02fdbb0c0241`,
sourcefree41452/sourceimage146663; V278's329 complete/335 unreconciled scope
counts keep their qualified meaning. Full source-free Slavnov, QAP, measure,
infrared validity,32 nonlinear products,contacts,equivalence and E5/A5 remain
unqualified. Authority34/39/seven false quantum flags,HB1/C5 block,flavor pause,
quartet-candidate/scalar quantum-control/gauge-matching/custodyexit2-seven
limitations remain. No physical input,scheme,benchmark,policy or external action.

The methods share actions,old exact theorems,catalogue,UV/chart assumptions,
software and AI author. They test implementation and reduction, not those
shared physical premises. No fresh identical replay pair,Lean,expert review
or experiment is claimed. The larger quantum-construction and physical-viability
questions are preserved rather than replaced by this successful local reduction.
