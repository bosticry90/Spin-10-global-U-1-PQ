"""Linked finite Gaussian diagnostic,not a physical model or parameter choice."""
from collections import defaultdict
import sympy as s
def add(A,B):
 C=dict(A)
 for k,z in B.items():
  C[k]=s.expand(C.get(k,0)+z)
  if not C[k]:del C[k]
 return C
def mul(A,B):
 C={}
 for(a,u),x in A.items():
  for(b,v),y in B.items():
   if a&b:continue
   C=add(C,{(a|b,u+v):x*y*(-1 if a&2 and b&1 else 1)})
 return C
def scale(A,z):return {k:s.expand(z*v) for k,v in A.items() if z*v!=0}
def cell(mask=0,power=0,z=1):return {(mask,power):s.sympify(z)} if z else{}
def mm(A,B):
 C={};rr=defaultdict(list)
 for(k,j),P in B.items():rr[k].append((j,P))
 for(i,k),P in A.items():
  for j,Q in rr[k]:
   z=add(C.get((i,j),{}),mul(P,Q))
   if z:C[i,j]=z
   else:C.pop((i,j),None)
 return C
def trace(A):
 C={}
 for(i,j),P in A.items():
  if i==j:C=add(C,P)
 return C
def transpose(A,sg=1):return {(j,i):scale(z,sg) for(i,j),z in A.items()}
def operators():
 E=s.Matrix([[1,2,3],[4,5,7]]);rho=[s.Matrix([[0,1,2],[-1,0,3],[-2,-3,0]]),s.Matrix([[0,2,1],[-2,0,4],[-1,-4,0]])];background=s.Matrix([1,2,3]);alpha=[1,2];gamma=[3,5];Y={(a,c,i):sum(E[a,j]*rho[c][j,i] for j in range(3)) for a in range(2) for c in range(2) for i in range(3)};K=s.Matrix(2,3,lambda a,i:(rho[a]*background)[i]);H=K*K.T;W=s.diag(2,5);assert W*H!=H*W
 mats={k:{} for k in ['A','L','T','X','Xr','E','Et','U','V','Z','Q','R','K','Kt','W','J']}
 def put(t,i,j,P):
  z=add(mats[t].get((i,j),{}),P)
  if z:mats[t][i,j]=z
 for a in range(2):
  put('W',a,a,cell(z=W[a,a]));put('J',a,2+a,cell());put('J',2+a,a,cell(z=-1))
  for i in range(3):put('E',a,i,cell(z=E[a,i]));put('K',a,i,cell(power=1,z=K[a,i]))
  for b in range(2):
   coefficient=sum((1+a+b+a*b+2*c+d)*alpha[c]*gamma[d] for c in range(2) for d in range(2));put('A',a,b,cell(mask=3,z=coefficient))
   for c in range(2):
    put('L',a,c,cell(mask=1,z=s.I*(1+a+3*b+2*c)*alpha[b]));put('L',a,2+b,cell(mask=2,z=-s.I*(2+3*a+2*b+c)*gamma[c]))
  for c in range(2):put('X',a,c,cell(mask=1,z=int(a==c)*alpha[a]));put('X',a,2+c,cell(mask=2,z=-int(a==c)*gamma[a]))
 for i in range(3):
  for c in range(2):put('U',i,c,cell(mask=1,z=sum(Y[a,c,i]*alpha[a] for a in range(2))))
  for a in range(2):put('U',i,2+a,cell(mask=2,z=-sum(Y[a,c,i]*gamma[c] for c in range(2))))
 for a in range(2):
  for c in range(2):z=sum(Y[a,c,i]*background[i] for i in range(3));put('Z',c,2+a,cell(power=1,z=-z));put('Z',2+a,c,cell(power=1,z=z))
 for t,co in [('Q',7),('R',11)]:
  word=['a0','a1','c0','c1'];names=['c0','c1','a0','a1']
  for i,one in enumerate(names):
   for j,two in enumerate(names):
    if one==two:continue
    w=list(word);pos=w.index(one);sg=(-1)**pos;w.pop(pos);pos=w.index(two);sg*=(-1)**pos;w.pop(pos);P=cell(z=sg*co)
    for n in w:P=mul(P,cell(mask=1 if n[0]=='a' else 2,z=(alpha if n[0]=='a' else gamma)[int(n[1:])]))
    put(t,i,j,P)
 for target,source,sg in [('T','L',1),('Xr','X',-1),('Et','E',1),('Kt','K',1),('V','U',-1)]:mats[target]=transpose(mats[source],sg)
 return mats,{'E':[[int(x) for x in row] for row in E.tolist()],'rho':[[[int(x) for x in row] for row in r.tolist()] for r in rho],'scalar_background':[int(x) for x in background],'alpha':alpha,'gamma':gamma,'Y_E_rho_linked':True,'W_H_noncommuting':True,'exterior_order':['ae','ce'],'odd_quantum_order':['c0','c1','a0','a1'],'Q_R_quartic_density_coefficients':[7,11]}
def evaluate(formulas,degree_by_family):
 M,data=operators();out={}
 for name,rows in formulas.items():
  total={}
  for word,z in rows:
   A=M[word[0]]
   for t in word[1:]:A=mm(A,M[t])
   total=add(total,scale(trace(A),s.sympify(z)))
  assert all(mask==3 and power==degree_by_family[name] for mask,power in total);out[name]=str(total.get((3,degree_by_family[name]),s.S.Zero))
 return {'linked_matrix_data':data,'normalized_family_coefficients_of_ae_ce_and_scalar_power':out,'diagnostic_not_physical_inputs':True}
