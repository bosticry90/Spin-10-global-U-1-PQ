# MST1 result — a checked mass-induced finite transport law

**PASS for the frozen one-loop-induced transport problem.** No mass
normalization, physical scheme, VEV shift, finite tadpole or two-loop C1_GS
has been selected or calculated. BFT1 and all historical evidence are preserved.

For the formal loop expansion F=ell*lambda1+ell^2*lambda2, and p'=p+ell*h
with the same gauge coupling and external background convention, the result is

    lambda2' = lambda2-Dlambda1[h].

This derives how an already computed boundary would have to transform. It
does not determine lambda2. Converting it to a particular C1 convention also
requires that coefficient's declared normalization. Changing the gauge
coupling or adding an independent finite background F^2 normalization is
outside this mass-induced law.

The derivative uses the actual qualified direct-SM one-loop convention:
scalar +1/2 Tr(W log X) and vector Tr(W[1-(21/2)log X]), with X=M^2/mu^2.
Its matrix logarithm derivative was calculated using divided differences and
independently using convergent positive resolvent integrals. Neither method
assumes that a mass variation commutes with the mass matrix.

## Actual input coverage and sensitive controls

All35 scalar SM multiplicity blocks were reconciled, retaining290 heavy
and38 excluded zero real directions. The complete output gives each positive
mass-squared sensitivity3*b_i/x and excluded light multiplicity. Independent
SM Dynkin/hypercharge formulas reproduce the frozen beta weights, including
the real/complex counting. Their heavy sum is(377/30,77/6,79/6). The four
vector index vectors independently reproduce the total(8,6,5).

Using the three positive masses from the actual charged-doublet block,
0.011785773863100646,0.34446986360791204,0.42041607328535896 in omega^2 units,
both methods agree on the full rotated3x3 Frechet derivative. Independent
fourth-order finite differences give maximum errors1.3653e-42 and8.5329e-44
at step1e-10 and half step. The wrong matrix product X^-1 E is detected.
These arbitrary diagnostic matrix jets are NOT claimed to be lifted to
admissible parent-action parameter counterterms.

A four-dimensional exactly-gap-preserving light/heavy rotation also passes.
It retains the differentiated heavy projector and never takes log of a
near-zero numerical eigenvalue. Omitting that projector variation fails the
full matrix test. A physical commuting trace is insensitive to its off-diagonal
part; this limitation is explicitly checked. The degenerate positive-mass
limit is regular. These facts do not validate the historically excluded
noncommuting broken-PS one-loop single-log shortcut.

The exact common squared-mass diagnostic Es=Xs,Ev=Xv at fixed physical mu gives

    Dlambda1 = (-463/10,-49/2,-13).

Its negative is the corresponding induced lambda2 scheme transport per unit
FORMAL jet. This is not a measured threshold vector, a fitted normalization,
or evidence that arbitrary independent mass shifts are admissible. The same
response is cross-checked against the original gauge/scalar-only beta jump.
It is nonuniversal, so the unresolved finite-input conventions can affect
relative gauge matching and cannot be dismissed as a common coupling offset.
When the parameters and two-loop coefficient are transported together, the
same bare matching and physical predictions are unchanged to this order.
This coordinate freedom is therefore not a physical repair of unification.

Exact composition, inverse and wrong-sign controls pass. Symbolic tadpole
tests distinguish a parameter/VEV tangent to tree stationarity from the
physical one-loop vacuum displacement. Omitting the VEV term changes a
scalar mass jet. A separate units test confirms that redefining omega as a
reference unit cannot itself change log(M^2/mu^2); physical mu is fixed here.
No tadpole value, finite mass shift or unknown Yukawa has been chosen.

## Evidence and remaining question

Native primary0.067221s, replay0.197052s, independent verifier0.345111s after
imports.80-digit arithmetic,1e-30 scaled comparison for new diagnostics;
the inherited floating one-loop regression retains1e-9 absolute tolerance.
Extra arithmetic digits do not improve the input spectrum's accuracy.
Zero failed native or verifier runs;39 initial and44 validation bindings.
All sources/controllers/proofs were frozen before computation. Complete
captures precede assertions. Caps120/180s,8GiB sampled private,350MiB launch
floor and4MiB package. Subsecond runs yielded startup memory samples only;
these do not measure runtime allocation or a true peak.

Validation receipt SHA256:
`cd276154724c5c33e17c24e89e93b5a3f48515fbaff2677fbabe06a2e8988190`.
Reproduction commands, each separately at the repository root:

```powershell
python -B calculations/canonical_so10_threshold_scheme_transport/prepare.py
python -B calculations/canonical_so10_threshold_scheme_transport/run.py
python -B calculations/canonical_so10_threshold_scheme_transport/prepare_validation.py
python -B calculations/canonical_so10_threshold_scheme_transport/run_validation.py
```

Exclusive outputs protect original completed evidence. These calculations
share the supplied spectral data, one-loop matching convention, mpmath/SymPy
and AI author. The resolver/eigenvalue finite-difference methods test
mathematical implementation and convention errors, not shared physical
assumptions. No external, Lean or experimental verification is claimed.

The next missing object is the actual parent-parameter/VEV/field-counterterm
lift, with a consistent finite prescription. The log derivative quantifies
its effect but cannot choose it. In particular, the four vector mass shifts
must be derived from the existing orbit/VEV structure rather than treated
as four independent adjustable constants. That is a smaller justified next
question before any weighted two-loop amplitude is evaluated.

No finite C1_GS, full master-basis PASS, new benchmark, matching refit or
physical-unification conclusion.34/39,state113/sevenfalse; E5/A5 unqualified,
HB1/C5 blocked, flavor paused. QuartetFAIL3960/648, historical custodyexit2/
seven, scalar140%/1.94%/20.27%, matching0.745476 and missing Yukawa control
remain unchanged. No old state/action/source/partialGamma/evidence was edited.
