# Next: actual vector-mass counterterm lift

MST1 computes the map from a mass jet to a finite boundary transport, not
which jets are allowed. BFT1 supplies O, exact representations and the
Faddeev–Popov derivative tensor. Reuse them to derive actual vector mass
jets under the frozen Phi/Sigma/S VEV directions and, separately, the fixed
gauge-coupling convention. Test the full matrices/spectral-projector action,
not four independently adjustable mass shifts inferred from matching needs.

Determine the rank and exact relations among the four massive-vector set
jets. Then identify the action's radial tadpole parameter variations that
can implement a stationary VEV tangent, without selecting their finite
coefficients or confusing them with the physical loop displacement.
The original parent has three separate quadratic masses; use the real
invariant normalization before asserting that they provide an arbitrary
tadpole lift. On-demand potential derivatives are preferable to a full328^4
array or a generic complete-counterterm platform.

This asks which finite directions are genuinely coupled by the existing
action. A qualified lift would narrow the unresolved counterterm input for
the amplitude; it still would not supply the actual one-loop renormalization
coefficients, finite prescriptions or C1_GS. Keep pure-background, field and
gauge CTs separate and all original finite-amplitude obligations intact.
No normalization is to be fitted to a favorable gauge-matching residual.
