from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Q
import json,sys,time,threading,os
import mpmath as mp
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent
def fmt(x):return mp.nstr(x,45)
def arr(M):return [[fmt(M[i,j]) for j in range(M.cols)] for i in range(M.rows)]
def norm(M):return max([abs(z) for z in M]+[mp.mpf(0)])
def logmat(X):
 vals,U=mp.eigsy(X);assert min(vals)>0,'NONPOSITIVE_HEAVY_MASS'
 return U*mp.diag([mp.log(x) for x in vals])*U.T
def weight(ir):
 a,b=ir['su3_dynkin'];d2=ir['su2_dim'];Y=Q(ir['hypercharge']);d3=Q((a+1)*(b+1)*(a+b+2),2)
 c3=Q(a*a+b*b+a*b+3*a+3*b,3);t3=d3*c3/8;t2=Q(d2*(d2*d2-1),12)
 return [Q(3,5)*Y*Y*d3*d2/6,t2*d3/6,t3*d2/6]
def mpq(q):return mp.mpf(q.numerator)/q.denominator
def divided(x,y):
 if x==y:return 1/x
 return mp.log1p((x-y)/y)/(x-y)
def main(role):
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=json.loads((D/'preparation.json').read_bytes())
 for n,h in prep['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
 mp.mp.dps=80;tol=mp.mpf('1e-30')
 ledger=json.loads((R/'calculations/canonical_so10_gauge_matching/scalar_sm_ledger.json').read_bytes())
 total=[Q(0)]*3;shifts=[];lam=[mp.mpf(0)]*3;counts=[0,0]
 for k,row in enumerate(ledger['blocks']):
  w=([Q(v).limit_denominator(10**6) for v in row['one_loop_b_per_physical_eigenvalue']] if role=='primary' else weight(row['sm_irrep']))
  assert all(abs(float(a)-b)<1e-14 for a,b in zip(w,row['one_loop_b_per_physical_eigenvalue']))
  z=row['zero_multiplicity'];masses=sorted(row['mass_squared_over_omega_squared'],key=abs)
  assert len(masses)==row['multiplicity'] and all(abs(x)<1e-9 for x in masses[:z])
  xx=list(map(lambda x:mp.mpf(str(x)),masses[z:]));assert all(x>0 for x in xx)
  counts[0]+=len(xx)*row['real_dimension_per_eigenvalue'];counts[1]+=z*row['real_dimension_per_eigenvalue']
  for i in range(3):
   total[i]+=len(xx)*w[i];lam[i]+=3*mpq(w[i])*sum(mp.log(x) for x in xx)
  shifts.append({'block':k,'label':row['sm_irrep'],'excluded_light_multiplicity':z,
  'b':list(map(str,w)),'heavy_mass_squared':list(map(fmt,xx)),
  'd_lambda1_dx':[[fmt(3*mpq(a)/x) for a in w] for x in xx]})
 assert counts==[290,38] and total==[Q(377,30),Q(77,6),Q(79,6)]
 old=json.loads((R/'calculations/canonical_so10_matrix_threshold/scalar_matrix_log.json').read_bytes())
 assert all(abs(a-mp.mpf(str(b)))<mp.mpf('1e-9') for a,b in zip(lam,old['lambda_scalar_SM_order_1_2_3']))
 if role=='primary':Tv=[[Q(14,5),Q(0),Q(1)],[Q(0)]*3,[Q(5),Q(3),Q(2)],[Q(1,5),Q(3),Q(2)]]
 else:
  specs=[[(1,0,1,'2/3',2),(0,0,1,'1',2)],[(0,0,1,'0',1)],[(1,0,2,'5/6',2)],[(1,0,2,'1/6',2)]]
  Tv=[]
  for terms in specs:
   vv=[Q(0)]*3
   for a,b,d2,Y,mult in terms:
    w=weight({'su3_dynkin':[a,b],'su2_dim':d2,'hypercharge':Y})
    for i in range(3):vv[i]+=6*mult*w[i]
   Tv.append(vv)
 vector=[sum(v[i] for v in Tv) for i in range(3)];assert vector==[Q(8),Q(6),Q(5)]
 common=[3*total[i]-Q(21,2)*vector[i] for i in range(3)]
 assert common==[Q(-463,10),Q(-49,2),Q(-13)]
 # Use three positive heavy eigenvalues from the actual charged-doublet block.
 row=ledger['blocks'][5];assert row['sm_irrep']=={'su3_dynkin':[0,0],'su2_dim':2,'hypercharge':'-3/6'}
 xs=[mp.mpf(str(x)) for x in sorted(row['mass_squared_over_omega_squared'],key=abs)[row['zero_multiplicity']:]]
 assert len(xs)==3
 E=mp.matrix([[mp.sqrt(xs[i]*xs[j])*(i+j+1)/20 for j in range(3)] for i in range(3)])
 L=mp.zeros(3)
 for i in range(3):
  for j in range(3):
   if role=='primary':L[i,j]=divided(xs[i],xs[j])
   else:
    x,y=xs[i],xs[j];L[i,j]=mp.quad(lambda t:1/((x+t)*(y+t)),[0,min(x,y),max(x,y),mp.inf])
 H=mp.matrix([[L[i,j]*E[i,j] for j in range(3)] for i in range(3)])
 v=mp.matrix([1,2,3]);U=mp.eye(3)-2*v*v.T/(v.T*v)[0];X=U*mp.diag(xs)*U.T;Er=U*E*U.T;Hr=U*H*U.T
 step=mp.mpf('1e-10');errors=[]
 for h in [step,step/2]:
  diff=(8*(logmat(X+h*Er)-logmat(X-h*Er))-(logmat(X+2*h*Er)-logmat(X-2*h*Er)))/(12*h)
  error=norm(diff-Hr);assert error<tol*(1+norm(Hr));errors.append(fmt(error))
 assert norm(Hr-X**-1*Er)>mp.mpf('1e-5') # wrong matrix shortcut
 print('STAGE positive_block',time.perf_counter()-tick,flush=True)
 # Gap-preserving projector motion, not log of a near-zero numerical eigenvalue.
 X4=mp.diag([0]+xs);F4=mp.diag([0]+[mp.log(x) for x in xs]);E4=mp.zeros(4);Omega=mp.zeros(4)
 for i in range(3):
  for j in range(3):E4[i+1,j+1]=E[i,j]
 for j in range(1,4):Omega[0,j]=mp.mpf(j)/7;Omega[j,0]=-mp.mpf(j)/7
 E4+=Omega*X4-X4*Omega
 if role=='primary':
  H4=mp.zeros(4)
  for i in range(4):
   for j in range(4):
    if i==j==0:continue
    coeff=(mp.log(xs[j-1])/xs[j-1] if i==0 else mp.log(xs[i-1])/xs[i-1] if j==0 else L[i-1,j-1])
    H4[i,j]=coeff*E4[i,j]
 else:
  H4=Omega*F4-F4*Omega
  for i in range(3):
   for j in range(3):H4[i+1,j+1]+=H[i,j]
 def mixed(t):
  rot=mp.expm(t*Omega);fh=logmat(mp.diag(xs)+t*E);f=mp.zeros(4)
  for i in range(3):
   for j in range(3):f[i+1,j+1]=fh[i,j]
  return rot*f*rot.T
 mixed_fd=(8*(mixed(step)-mixed(-step))-(mixed(2*step)-mixed(-2*step)))/(12*step)
 assert norm(mixed_fd-H4)<tol*(1+norm(H4))
 no_projector=mp.zeros(4)
 for i in range(3):
  for j in range(3):no_projector[i+1,j+1]=H[i,j]
 assert norm(H4-no_projector)>mp.mpf('.01')
 assert abs(mp.trace(H4-no_projector))<tol if hasattr(mp,'trace') else abs(sum((H4-no_projector)[i,i] for i in range(4)))<tol
 # Coalescent-mass derivative is regular; don't divide eigenspace vectors.
 assert abs(divided(1,1+mp.mpf('1e-40'))-1)<mp.mpf('1e-39')
 out={'schema':'THRESHOLD_MASS_SCHEME_TRANSPORT_NATIVE_V1','role':role,'heavy_real':counts[0],'excluded_light_real':counts[1],
 'scalar_beta':list(map(str,total)),'vector_indices':[list(map(str,w)) for w in Tv],
 'common_squared_mass_jet_response':list(map(str,common)),'scalar_lambda1':list(map(fmt,lam)),
 'scalar_sensitivities':shifts,'doublet_heavy_masses':list(map(fmt,xs)),
 'rotated_mass_log_derivative':arr(Hr),'heavy_light_log_derivative':arr(H4),
 'positive_finite_difference_errors':errors,'full_matrix_wrong_shortcut_detected':True,
 'projector_omission_detected':True,'commuting_trace_blind_to_projector_rotation':True,
 'scheme_law':'lambda2_prime=lambda2-Dlambda1[h]; p_prime=p+ell*h; same g and background',
 'jet_lifted_to_parent_counterterms':False,'finite_CT_or_scheme_chosen':False,'C1_GS_calculated':False,
 'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main(sys.argv[1])
