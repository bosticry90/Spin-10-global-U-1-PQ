from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/mass-scheme-transport-v1-2026-10-20');C.mkdir(parents=True,exist_ok=False)
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();assert base=='93f84b5b517ccb13e99ab901bddeb20fed63083a'
names=['AGENTS.md','CHARTER.md','project_state.json','docs/SOLO_REVIEW_POLICY_V1.md','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md',
'docs/RESEARCH_EXECUTION_HANDOFF_V373.md','calculations/canonical_so10_scalar_reconstruction/PARENT_ACTION_V1.md',
'calculations/canonical_so10_positive_higgs/POINT.json','calculations/canonical_so10_direct_gauge_matching/RECORD.md',
'calculations/canonical_so10_direct_gauge_matching/derive_and_solve.py',
'calculations/canonical_so10_direct_two_loop_gauge_scalar_threshold/RECORD.md',
'calculations/canonical_so10_gauge_matching/scalar_sm_ledger.json','calculations/canonical_so10_gauge_matching/vector_ledger.json',
'calculations/canonical_so10_matrix_threshold/scalar_matrix_log.json','calculations/canonical_so10_matrix_threshold/RESULT.md',
'calculations/canonical_so10_matrix_threshold/check_scalar_matrix_log.py',
'calculations/canonical_so10_background_threshold_inputs/DERIVATION.md',
'calculations/canonical_so10_background_threshold_inputs/RESULT.md',
'calculations/canonical_so10_background_threshold_inputs/validation_receipt_v2.json']
files=[R/n for n in names]+[P/'export_a10_e5_antighost_vector.py',P/'audit_a10_e5_antighost_vector.py']
for p in list(D.iterdir()):
 if p.suffix in ['.py','.md']:
  with (D/(p.name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
files+=list(D.iterdir());tree=subprocess.check_output(['git','ls-tree','-r',base],cwd=R)
with (C/'old_git_tree.txt').open('xb') as f:f.write(tree)
files.append(C/'old_git_tree.txt')
v={'schema':'THRESHOLD_MASS_SCHEME_TRANSPORT_PREPARATION_V1','base_commit':base,'old_git_blobs':len(tree.splitlines()),
'input_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in files},
'native_after_imports_seconds':120,'verifier_after_imports_seconds':180,'precision_digits':80,
'numeric_tolerance':'1e-30','sampled_private_limit':8*1024**3,'launch_floor_bytes':350*1024**2,'package_limit':4*1024**2}
with (D/'preparation.json').open('xb') as f:f.write((json.dumps(v,indent=2,sort_keys=True)+'\n').encode())
print('FROZEN',len(files),'bindings',v['old_git_blobs'],'old blobs',flush=True)
