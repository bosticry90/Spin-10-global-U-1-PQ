"""Distinct derivative/chain-rule, scalar sensitivities and tadpole controls."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Q
import json,time,threading,os
import mpmath as mp
import sympy as s
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent
def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=json.loads((D/'validation_preparation.json').read_bytes())
 for n,h in prep['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
 a,b=[json.loads((D/(r+'_result.json')).read_bytes()) for r in ['primary','replay']];mp.mp.dps=80;tol=mp.mpf('1e-30')
 def near(x,y):
  x,y=mp.mpf(x),mp.mpf(y);assert abs(x-y)<tol*(1+abs(x)+abs(y)),(x,y)
 for name in ['scalar_beta','vector_indices','common_squared_mass_jet_response','doublet_heavy_masses','scheme_law']:
  assert a[name]==b[name],name
 for name in ['rotated_mass_log_derivative','heavy_light_log_derivative']:
  for ra,rb in zip(a[name],b[name]):
   for x,y in zip(ra,rb):near(x,y)
 # Actual full scalar sensitivity output, including light multiplicities.
 ledger=json.loads((R/'calculations/canonical_so10_gauge_matching/scalar_sm_ledger.json').read_bytes())
 for out in [a,b]:
  assert not out['C1_GS_calculated'] and not out['finite_CT_or_scheme_chosen'] and not out['jet_lifted_to_parent_counterterms']
  assert out['heavy_real']==290 and out['excluded_light_real']==38
  assert len(out['scalar_sensitivities'])==35
  for k,(row,z) in enumerate(zip(ledger['blocks'],out['scalar_sensitivities'])):
   assert z['block']==k and z['excluded_light_multiplicity']==row['zero_multiplicity']
   for x,vals in zip(z['heavy_mass_squared'],z['d_lambda1_dx']):
    xx=mp.mpf(x);step=mp.mpf('1e-10')*xx
    d=(8*(mp.log(xx+step)-mp.log(xx-step))-(mp.log(xx+2*step)-mp.log(xx-2*step)))/(12*step)
    for w,val in zip(z['b'],vals):
     qq=Q(w);near(val,3*mp.mpf(qq.numerator)/qq.denominator*d)
 # Exact finite-reparameterization law; wrong sign fails at ell^2.
 ell,m,hm,L2=s.symbols('ell m hm L2',positive=True)
 original=ell*s.log(m-ell*hm)+ell**2*L2
 transported=ell*s.log(m)+ell**2*(L2-hm/m)
 assert s.series(original-transported,ell,0,3).removeO()==0
 wrong=ell*s.log(m)+ell**2*(L2+hm/m)
 assert s.series(original-wrong,ell,0,3).removeO().coeff(ell,2)!=0
 h1,h2=s.symbols('h1 h2');law=lambda v,h:s.expand(v-h/m)
 assert law(law(L2,h1),h2)==law(L2,h1+h2) and law(law(L2,h1),-h1)==L2
 # Tadpole/VEV parameter jet is distinct from the physical loop shift.
 x,v,mm,lam,dm,dl,dv,t1=s.symbols('x v mm lam dm dl dv t1',nonzero=True)
 V=mm*x*x/2+lam*x**4/4;t=s.diff(V,x).subs(x,v);H=s.diff(V,x,2).subs(x,v)
 dt=s.diff(t,mm)*dm+s.diff(t,lam)*dl+s.diff(t,v)*dv
 solution=s.solve(dt,dv)[0];physical=-t1/H
 assert s.simplify(dt.subs(dv,solution))==0 and s.simplify(solution-physical)!=0
 massjet=s.diff(H,mm)*dm+s.diff(H,lam)*dl+s.diff(H,v)*dv
 assert s.simplify(massjet.subs(dv,solution)-massjet.subs(dv,0))!=0
 # At fixed mu, moving the reference units alone cannot shift log(M^2/mu^2).
 omega,mu,M,eps=s.symbols('omega mu M eps',positive=True)
 logratio=s.log((M/(omega*(1+eps)))**2/(mu/(omega*(1+eps)))**2)
 assert s.diff(logratio,eps)==0
 # Common jet cross-check by the inherited exact beta jump, gauge/scalar only.
 bs=[Q(1,10),Q(-43,6),Q(-11)];parent=Q(-46,3)
 common=[Q(z) for z in a['common_squared_mass_jet_response']]
 assert [-2*z for z in common]==[6*(v-parent) for v in bs]
 assert len(set(common))==3 # nonuniversal; not a fitted target vector
 result={'schema':'THRESHOLD_MASS_SCHEME_TRANSPORT_VALIDATION_V1',
 'status':'PASS_MASS_INDUCED_FINITE_SCHEME_LAW_ONLY','input_bindings':len(prep['input_sha256']),
 'scalar_blocks':35,'heavy_real_directions':290,'excluded_light_real_directions':38,
 'common_squared_mass_jet_response':list(map(str,common)),
 'scalar_sensitivity_full_replay':True,'noncommuting_matrix_and_rotating_projector_controls':True,
 'finite_transport_wrong_sign_detected':True,'commuting_trace_control_insensitivity_disclosed':True,
 'tadpole_parameter_and_physical_vacuum_shifts_distinguished':True,'units_cancellation_verified':True,
 'scheme_chosen':False,'parent_parameter_counterterms_constructed':False,'C1_GS_calculated':False,
 'authority_changed':False,'formal_authority':'34/39_UNCHANGED','native_failures':0,'verifier_failures':0,
 'shared_premises':'same action/spectral ledger/one-loop convention, mpmath/SymPy and AI author',
 'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
