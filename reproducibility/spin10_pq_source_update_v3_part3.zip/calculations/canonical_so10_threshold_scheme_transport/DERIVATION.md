# MST1 — mass-induced finite scheme transport

Introduce a FORMAL loop marker ell and an additive matching coefficient
F=ell*lambda1(p)+ell^2*lambda2(p)+O(ell^3). It is not necessary to assume the
missing C1 normalization equals lambda2 in any unspecified convention.
Define p'=p+ell*h(p); keep MSbar g and background field fixed. Reexpressing
the SAME matching in p' gives

    lambda2'(p')=lambda2(p')-D lambda1(p')[h].

It is a coordinate change on the same bare theory, not permission to move a
fixed numerical benchmark while leaving its counterterms unchanged. A changed
coupling or background normalization would add other terms, excluded here.
An independent finite F^2 counterterm also is not fixed by this mass law.

The actual direct-SM one-loop convention is

    lambda1_S=1/2 Tr_heavy(W_i log(X_S/mu^2)),
    lambda1_V=Tr_heavy(W_i[1-(21/2)log(X_V/mu^2)]).

In a scalar multiplicity block W_i=6 b_i I, with b_i the beta weight per
eigenvalue. For X>0,

    D log_X[E]=integral_0^infinity (X+t)^-1 E (X+t)^-1 dt.

Diagonalizing X gives L_ab E_ab, L_ab=(log x_a-log x_b)/(x_a-x_b),
L_aa=1/x_a. This follows by differentiating the convergent scalar resolvent
representation of log, then spectral multiplication. It is a linear map,
not the generally wrong matrix product X^-1 E. No eigenvector derivative
denominators survive the coalescent limit. Reality and simultaneous unitary
covariance follow directly. Thus

    d lambda1_i=1/2 Tr(W_i Dlog_Xs[Es])
                -(21/2)Tr(W_i Dlog_Xv[Ev]).

For the actual unbroken SM insertions [W_i,X]=0, the trace reduces to
Tr(W_i X^-1 E) on the positive heavy subspace. This equality can hide wrong
off-diagonal matrices; test the FULL Frechet map separately. It does not
license the one-loop simple-log kernel for a broken PS generator with
[W,X]!=0. The mathematical Frechet identity is general; that physical kernel
is not assumed general.

With a light/heavy spectral gap, define f(X)=log(X/mu^2) on the positive
heavy cluster and zero on the separated light cluster. For a rotating
projector its divided difference between light0 and heavyx is log(x/mu^2)/x,
while its light-light derivative is0. A family X(t)=U(t)diag(0,Xh+tEh)U(t)^T
has exactly zero light eigenvalue; its derivative is
diag(0,Dlog_Xh[Eh])+[Omega,diag(0,log Xh)], U(t)=exp(t Omega).
Dropping projector motion fails the full matrix test. With the physical
commuting W, its off-diagonal trace is zero, an explicitly insensitive control.
No negative or tiny eigenvalue is ever passed to log.

For SU3 labels(a,b), d3=(a+1)(b+1)(a+b+2)/2,
C3=(a^2+b^2+ab+3a+3b)/3, T3=d3*C3/8. For SU2 dimensiond2,
T2=d2*(d2^2-1)/12. With physical hyperchargeY,

    b=( (3/5)Y^2*d3*d2, T2*d3, T3*d2 )/6.

The full35-block sum, with its real/complexified multiplicity convention,
must reproduce (377/30,77/6,79/6) for the290 heavy directions. Per scalar
heavy mass-squared entry x, d lambda1_i/dx=3 b_i/x. The vector weights for
the four frozen massive sets are(14/5,0,1),(0,0,0),(5,3,2),(1/5,3,2),
sum(8,6,5). The same weights follow from the conjugate SM representations,
independently of assigning threshold values to fit couplings.

For a common diagnostic jet Es=Xs,Ev=Xv at fixed mu, the response is

    R_i=3*b_heavyS_i-(21/2)*T_heavyV_i.

Do not turn R into an actual scheme shift by selecting a free coefficient.
Rescaling mu as well changes the comparison. If omega is used merely as a
unit, differentiating only M^2/omega^2 while ignoring mu/omega is wrong.
Here physical mu and the reference units are fixed. All mass changes are
formal jets; no new point or physical scale is adopted.

For action parameters p_alpha and VEV v,
E_S=D(V''+GFmass)[h], E_V=g^2[(deltaO)^T O+O^T deltaO] with delta g=0,
deltaO_a=rho_a delta v. The finite parameter/VEV tangent to tree stationarity
satisfies H*delta v+sum_alpha partial_palpha(t)*delta p_alpha=0 if tadpoles
are required to remain zero in that family. The physical loop shift instead
has H*v1+t1_ren=0. A chosen independent tadpole CT modifies the first relation
according to its declared convention. These relations do not choose that CT
or prove every matrix jet lifts to the frozen34 real parent directions.

The chain rule can therefore quantify a mass-normalization dependency
without supplying a numerical finite threshold or choosing an on-shell/
MSbar mass and tadpole prescription. Martens arXiv:1011.2927v2 section2.2 is
the relevant primary comparator for the distinction between on-shell masses
and MSbar couplings. No new physical renormalization convention is adopted.
