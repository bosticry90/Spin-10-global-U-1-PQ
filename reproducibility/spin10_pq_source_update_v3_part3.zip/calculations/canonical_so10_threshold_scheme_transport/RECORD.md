# MST1 — finite mass-normalization transport of the two-loop boundary

Prospective at93f84b5b517ccb13e99ab901bddeb20fed63083a/main,2026-10-20.
BFT1 is complete, not a finite threshold. Question: exactly which part of
the desired two-loop finite boundary changes under a one-loop finite mass/
VEV reparameterization, with the same MSbar gauge coupling and external
background normalization? This diagnoses the finite-input gap without choosing
any normalization, changing the benchmark or fitting a matching residual.

Freeze the proof in DERIVATION and code/input hashes before execution. Reuse
the actual one-loop direct-SM kernel, scalar35-block ledger (290 heavy/38zero),
vector mass sets and indices, and BFT1 CT ledger. Do not revive the invalid
two-boundary PS single-log shortcut. This law concerns mass-induced transport,
not arbitrary finite background-kinetic counterterms or gauge-coupling changes.

Types: positive Hermitian heavy mass-squared blocks X at fixed physical mu,
Hermitian first jet E=D X[h] induced by a finite parent reparameterization h
when such a lift exists. Unlifted E is a matrix-calculus diagnostic, not an
admissible ToE counterterm. H generators commute with physical mass operators;
the trace weights are constant on SM multiplicity spaces. Fixed-gap light
projectors are varied correctly; zero/near-zero modes are not logarithmized.
No threshold-crossing, noncommuting broken-PS claim or full massless IR claim.

Primary derives log Frechet coefficients by divided differences and obtains
all scalar mass sensitivities from the frozen ledger. Replay derives the
positive-block coefficients by convergent resolvent integrals and obtains
all35 group weights independently from the SM labels/Dynkin formulas. Verify
with independent fourth-order finite differences of actual rotated3x3 mass
blocks from the charged-doublet ledger row5 (three positive entries).
Retain a four-dimensional heavy/light rotating-projector control with an
exactly zero light eigenvalue. Full matrix comparison must detect off-diagonal
terms that a physical commuting trace cannot see. Test degenerate/coalescent
positive masses, basis rotations, finite-map sign, composition and inverses.
Test coupled VEV/parameter tadpole jets symbolically; no numerical CT chosen.

Numerics80digits; resolvent and full matrix agreement1e-30*(1+norm), fourth
order symmetric derivative with step1e-10 and an observed refinement control
at half step. Actual ledger digits keep their inherited spectral accuracy.
Derive exact rational group weights; rationalizing the float ledger requires
agreement1e-14 and denominator<=1e6. Full scalar output includes every heavy
eigenvalue, sensitivity and each excluded light multiplicity. Refuse loss of
the heavy/light gap or a nonpositive heavy eigenvalue. No zero-mass master or
full physical finite correction is inferred from this matrix experiment.

Native120s/verifier180s after imports;8GiB sampled private NOT true peak;
350MiB launch floor;4MiB new package. Sequential native routes, completed-byte
comparison before independent verification. Freeze controllers/proof/code/
immutable inputs; save full captures before assertions. Preserve original
failures/unfinished work, version corrections; no silent tolerance or resource
increase. Possible result: qualified transport law, discrepancy, underdefinition
or bounded inconclusiveness. Verification does not construct parent MSbar CTs.

Authority ceiling: independently checked one-loop-induced FINITE SCHEME LAW
and actual input sensitivity, not C1_GS, allowed CT completeness, a normalization
choice, unification fit or promotion. b0/kappa/heat IR normalizations untouched.
Do not infer that missing finite conventions are a physical obstruction.
No old evidence/action/state/point/partialGamma/source/policy/branch/remote/
publication changes.34/39/state113/sevenfalse, E5/A5 unqualified, HB1/C5 blocked,
flavor paused, quartetFAIL3960/648, custodyexit2/seven. Physical-control and
matching/Yukawa limitations remain. Shared conventions/data/software/AI author
disclosed; no Lean/external/experimental verification is earned.
The reused floating one-loop ledger regression has1e-9 absolute tolerance;
it retains its original numerical spectral accuracy. This is distinct from
the1e-30 high-precision agreement of the new matrix-calculus diagnostics.
