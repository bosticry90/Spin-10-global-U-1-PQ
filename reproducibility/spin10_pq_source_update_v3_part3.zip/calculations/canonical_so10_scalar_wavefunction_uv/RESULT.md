# SWF1 — complete gauge-only scalar kinetic UV input

At base `00ca4b97b2033dbd4924a77a028beb89004e59d8`, the two frozen
native routes and the separately implemented verifier completed. The result
is the simple ultraviolet pole, not a finite amplitude or a physical mass.
With the current canonical real fields and plane generators J/sqrt(2),

\[
 \Gamma^{(2)}_{\rm pole}(p)=
 -\frac{\hbar g_{10}^2}{16\pi^2\epsilon_{\rm UV}}
 (3-\xi)C_2\,p^2,\qquad
 \delta Z_{\rm pole}=
 +\frac{\hbar g_{10}^2}{16\pi^2\epsilon_{\rm UV}}(3-\xi)C_2.
\]

| Canonical real sector | Dimension | C2 | Stripped deltaZ at xi=1 |
| --- | ---: | ---: | ---: |
| Phi | 54 | 10 | 20 |
| Sigma | 252 | 25/2 | 25 |
| phi | 20 | 9/2 | 9 |
| S | 2 | 0 | 0 |

The last column multiplies hbar*g10^2/(16*pi^2*epsilon_UV).
All 107,584 matrix positions are determined: generically 326 nonzero
diagonal entries and 107,258 zero entries. The xi=3 zero is only this
gauge-dependent pole contribution. The xi=0 result is an algebraic Landau
limit, not a new assertion of invertibility at xi=0 for the massive reference.
The block-scalar result commutes with all representation generators and is
compatible with the inherited residual-background action on these fields.

## How the result was checked

The primary route Taylor-expands the actual derivative VSS bubble and takes
its angular residue, obtaining 2 from the Feynman numerator and -1 from
the longitudinal numerator. It multiplies the full matrices -sum rho_a^2.
The replay integrates shifted-loop Feynman parameters and independently
obtains the representation indices by Frobenius norms of all 45 generators.
It reads the supplied replay representation, not the primary output. The
two actual sparse coefficient tables agree exactly.

The verifier imports no new native helper. Its entry-level Gram contraction
checks both complete representations and the zero complement. With R=k^2+m2,
its Feynman and longitudinal p^2 coefficients are respectively

    m2/R^3 + (3D-4)/(D R^2) + 4m2^2/(D R^4),
    -1/R^2 + 2m2/R^3 - (D-4)m2^2/(D R^4) - 4m2^3/(D R^5).

Only R^-2 carries a logarithmic UV pole in four dimensions. Exact Gamma
residues of J1..J5 are (-m2,1,0,0,0), with positive auxiliary mass retained
until UV/IR separation. A literal Hermitian two-field Gaussian and the
second-order logdet expansion independently fix the effective-action minus
sign. No unseparated scaleless integral was assigned zero. The D-dependent
expressions are used for the pole only, not a finite coefficient.

Feynman and special-width regressions pass. Algebraic negative controls
change the answer when dropping the longitudinal contribution, halving the
complex realification count or using the old unnormalized plane J. These
are exact normalization controls, not fresh full wrong-action loop runs.
Dimension-one potential, VVS and ghost-scalar vertices have UV-finite p^2
descendants; seagulls are momentum independent. This is the gauge-only
wavefunction contribution, not a claim that Yukawa terms vanish in the model.

The general gauge contribution agrees with [Sperling, Stoeckinger and Voigt,
arXiv:1305.1548v3, eq.20](https://arxiv.org/abs/1305.1548).
Their separate background/VEV prescription is not adopted by this match.

## Evidence, resources and limits

Commands, in order:

    python -B calculations/canonical_so10_scalar_wavefunction_uv/prepare.py
    python -B calculations/canonical_so10_scalar_wavefunction_uv/run.py
    python -B calculations/canonical_so10_scalar_wavefunction_uv/prepare_validation.py
    python -B calculations/canonical_so10_scalar_wavefunction_uv/run_validation.py

Preparation binds 1,147 inputs; validation binds 1,152. Full captures and
source copies accompany the result. Primary/replay times after imports were
2.9803615/2.8646527 s; the verifier took 5.9683864 s. Zero failed native or
verifier runs in SWF1. Two read-only navigation commands earlier used missing
filenames/Windows globs; they launched no scientific worker and modified no
evidence. Largest observed private-memory sample was 54,706,176 bytes,
not a measured peak. Frozen caps remain 30/60 s after imports, 8 GiB sampled,
350 MiB launch-commit floor and 4 MiB package. No resource or acceptance
extension was needed.

The construction inherits the action, kinematic packets, regulator convention,
software and AI author. Distinct reductions corroborate the implementation;
they do not independently validate shared physical premises. No Lean theorem,
outside scientific validation or experiment was performed. Expensive old
finite loops, the full partial functional and custody audit were not rerun.

This adds a required local deltaK input. It does not choose finite field,
VEV, source, mass or coupling counterterms, establish their full simultaneous
closure, or calculate finite C1_GS. All pre-existing evidence and authority
are preserved: state113/34of39, E5/A5 unqualified, HB1/C5 blocked, flavor
paused, quartet failure and custody exit2/seven unresolved references.
Scalar quantum-control and gauge-matching limitations are unchanged.
