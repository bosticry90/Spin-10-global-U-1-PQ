# Next smallest question after SWF1

SWF1 and UTP1 determine different one-loop local inputs. Do not infer a
reference-VEV shift from either one alone or fit a vacuum counterterm to
cancel the measured tadpole. Field and background-VEV renormalization can
differ in Rxi gauges; the distinction is explicit in1305.1548v3.

Recover the original C1 contract and its chosen independent parameters,
gauge-fixing reference and MSbar conditions. Determine which combinations
of mass, potential, field and reference counterterms are required for its
one-loop deltaK insertion. Reuse the qualified stationary/Higgs tangent as
a tree-coordinate map, not a quantum normalization prescription.

A useful bounded next step is a model-specific applicability/definition
check for background-VEV normalization. If the literature's external BRST
doublet can be used as a bookkeeping probe of the actual fixed-reference
gauge fermion, explicitly prove the map and keep provisional extension apart
from adoption. If it requires an extra prescription, identify that premise
instead of silently importing it. Do not transfer a result from the historical
E1 source action to the physical C1 gauge by similarity of field names.

Then calculate an actually missing pole input or assemble an authenticated
complete counterterm relation. Avoid another isolated identity that does not
reduce a C1 dependency. Retain fermion/flavor pause and the fact that C1_GS
is Yukawa-vertex-independent, not automatically devoid of gauge-coupled
fermion contributions. No finite matching fit, physical coupling choice,
foundation/source adoption or authority promotion is implied.
