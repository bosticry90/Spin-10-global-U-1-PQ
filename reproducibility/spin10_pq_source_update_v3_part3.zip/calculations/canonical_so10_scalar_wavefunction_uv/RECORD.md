# SWF1 — gauge contribution to the scalar p^2 UV pole

Prospective at00ca4b97b2033dbd4924a77a028beb89004e59d8/main,2026-10-20.
UTP1 UV tadpole extraction qualified, with its native/verifier/prelaunch
failures preserved. No old finite loop or UTP calculation is to be repeated.
Question: what is the complete one-loop gauge contribution to scalar-field
wavefunction normalization in the physical C1 reference? This supplies an
actual further entry of deltaK, not a new finite amplitude or a VEV condition.

Frozen inputs: physical parent action/kinetics; BFT1 fixed-reference linear
Rxi vertices; actual canonical328-real scalar rho matrices, normalized with
plane J/sqrt2 and g10; UTP1 exact Casimirs and dimensional tadpole convention.
Common positive TREE xi, with C1 Feynman xi=1 as a regression. The separately
needed bare width counterterms are not equated by this choice. No E1 source
action adoption, physical coupling value or finite scheme is implied.

Types: external Euclidean scalar momentum p, loop k, g10^2 p^2 local simple
UV pole, all45 internal vector directions and the full real scalar carrier.
Keep massive/reference interactions in the inventory: only the derivative
VSS bubble can supply this p^2 logarithmic pole at one loop. Quartic seagulls
are p independent; dimension-one potential, VVS and FP scalar vertices have
UV-finite p^2 descendants by power counting. Ordinary matter requires scalar
Yukawa vertices and is outside this explicitly gauge-only contribution.
Prove these scope exclusions; do not claim full-theory wavefunction control.

Primary: Taylor/large-loop-momentum tensor expansion of the actual derivative
vertex bubble, angular averaging in D, with the Hessian-logdet expansion fixing
its sign. Contract the FULL actual Casimir matrices to obtain every canonical
p^2 coefficient, including off-diagonal zeros. Replay: independent Feynman-
parameter and shifted-loop tensor reduction, using the original Gamma tadpole/
bubble pole convention; derive representation indices and map their Casimir
values without reading the primary result. Compare actual full matrices.

Independent verifier imports no new native helper. Recompute the p^2 Taylor
coefficient with a common positive auxiliary IR mass, reduce each rational
radial term to convergent integrals plus the single logarithmic J2 residue,
and show the residue is independent of that mass. Verify the literal two-field
Gaussian Hessian sign and closed determinant expansion, all representation
operators, dimension/normalization, Feynman/Landau/special-width regressions,
and errors from lost longitudinal term, wrong complex counting or gstar map.
No unseparated scaleless integral is declared zero. D-4 can affect finite
parts; this result extracts only the simple pole after the required D limit.

All mathematics exact rational/symbolic. Native30s/verifier60s AFTER imports,
8GiB sampled private NOT peak,350MiB available-commit launch floor,4MiB new
package. Freeze proof/code/controllers/source inputs before computation.
Sequential native routes compared after completion, then independent verifier.
Save full captures before assertions, preserve all failures/unfinished sources;
no silent extension or truncation. Inspect every dependent exit before mutation.

Acceptance ceiling: selected actual p^2 pole and opposite local field-kinetic
subtraction target. Not a finite wavefunction choice, complete CT action,
background-VEV/source renormalization theorem, pole-mass prediction, QAP or
C1_GS. A general scalar-field formula in1305.1548v3 eq20 is a primary comparator;
its separate background-field/VEV prescription is not imported or adopted.
Do not solve unknown counterterms from the value needed to cancel UTP1.

Shared action/representations, existing source definitions, symbolic software
and AI author remain limitations. Distinct integral reductions test errors,
not independent physical premises. No external/Lean/experimental verification.
Possible outcomes: qualified input, discrepancy, underdefinition or bounded
inconclusiveness. No old evidence/state/action/point/source/partialGamma/
policy/scheme/main/remote/publication change.34/39,state113/sevenfalse;
E5/A5unqualified,HB1/C5blocked,flavorpaused,C1_GSuncalculated,quartetFAIL3960/648,
custodyexit2/seven; scalar140%/1.94%/20.27%,matching0.745476/Yukawa limits remain.
