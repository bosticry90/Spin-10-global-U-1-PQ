"""Freeze SWF1 source/input bytes before either exact calculation."""
from pathlib import Path
from hashlib import sha256
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CONTROL = Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/scalar-wavefunction-uv-v1-2026-10-20')
BASE = '00ca4b97b2033dbd4924a77a028beb89004e59d8'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip() == BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT).decode().strip() == 'main'
prior = json.loads((ROOT/'calculations/canonical_so10_uv_radial_tadpoles/validation_preparation_v3.json').read_bytes())
for name,digest in prior['input_sha256'].items():
    assert sha256(Path(name).read_bytes()).hexdigest() == digest, name
CONTROL.mkdir(parents=True,exist_ok=False)
files = list(map(Path,prior['input_sha256']))
files.extend(p for p in (ROOT/'calculations/canonical_so10_uv_radial_tadpoles').iterdir() if p.is_file())
files.extend([ROOT/'AGENTS.md',ROOT/'project_state.json',ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V378.md'])
for path in list(HERE.iterdir()):
    if path.suffix in ['.py','.md']:
        if path.suffix == '.py':
            compile(path.read_bytes(),str(path),'exec')
        with (HERE/(path.name+'.source.txt')).open('xb') as out:
            out.write(path.read_bytes())
files.extend(HERE.iterdir())
tree = subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT)
assert len(tree.splitlines()) == 24657
with (CONTROL/'old_git_tree.txt').open('xb') as out:
    out.write(tree)
files.append(CONTROL/'old_git_tree.txt')
value = {
    'schema':'C1_GS_SCALAR_WAVEFUNCTION_UV_PREPARATION_V1','base_commit':BASE,
    'old_git_blobs':len(tree.splitlines()),
    'input_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in sorted(set(files))},
    'native_after_imports_seconds':30,'verifier_after_imports_seconds':60,
    'arithmetic':'EXACT_SYMBOLIC_RATIONAL','sampled_private_limit':8*1024**3,
    'launch_floor_bytes':350*1024**2,'package_limit':4*1024**2,
}
with (HERE/'preparation.json').open('xb') as out:
    out.write((json.dumps(value,sort_keys=True,indent=2)+'\n').encode())
print('FROZEN',len(value['input_sha256']),'bindings',value['old_git_blobs'],'old blobs',flush=True)
