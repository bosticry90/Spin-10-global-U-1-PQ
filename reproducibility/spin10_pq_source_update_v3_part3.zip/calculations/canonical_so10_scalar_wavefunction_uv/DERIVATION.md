# SWF1 — scalar derivative bubble and its pole

The real scalar kinetic term is1/2(D_phi)^T(D_phi), D=partial+g rho(A),
rho^T=-rho. Its VSS vertex supplies(2p+k)_mu up to the oriented Fourier i
and generator. Contracting the vector propagator in uniform Rxi gauge gives

    N_F=(k+2p)^2,
    N_L=[k.(k+2p)]^2/k^2,
    integrand=g^2 C [N_F+(xi-1)N_L]/[k^2(k+p)^2],
    C=-sum_a rho_a^2.

The sign of the scalar two-point effective-action correction is fixed by
the actual bosonic Hessian: Gamma1 has -1/4 Tr(G deltaK G deltaK). Its two
off-diagonal vector/scalar orientations give -1/2; the conjugate Fourier i
factors in the Hermitian blocks give a positive product. Taking the second
external scalar derivative therefore gives a negative sign multiplying the
displayed integral. The vector seagull is p independent and cannot change
this p^2 residue. Dimension-one vertices (including VVS, potential cubics,
and FP scalar vertices proportional to v) have logarithmic superficial
degree0 before the p^2 expansion and hence no p^2 UV pole. Potential quartic
tadpoles likewise carry no external momentum. Other one-loop gauge-only
topologies cannot supply this coefficient by valence and power counting.

Primary: write k^2=r^2,p.k=r*p*c. The p^2/r^4 coefficients of the integrand
are3-4c^2 for N_F and-1 for N_L. Angular averaging gives c^2=1/D, hence
4-xi-4/D, whose D=4 simple-pole residue is3-xi. A positive auxiliary mass
will independently isolate the UV pole; this leading expansion is not a
scaleless integral assigned zero. Differences suppressed by masses/v cannot
alter a dimensionless p^2 UV residue, although they do alter mass and finite
terms. No inverse mass or VEV is allowed in this local power-counting step.

Replay: use a Feynman parameter x and shift the loop momentum. For the
Feynman part, the pole coefficient is

    integral_0^1 [-2x(1-x)+(2-x)^2] dx.

For the longitudinal part,1/[k^4(k+p)^2]=2 integral_0^1 x/[l^2+Delta]^3,
with k=l-(1-x)p. Its numerator to order p^2 is
l^4+[4x^2/D-2+2x^2]*l^2*p^2. Pole parts of the massive integrals give

    2 integral_0^1 x[-3x(1-x)+4x^2/D-2+2x^2] dx,

evaluated at D=4 for the residue. Pole-truncated reductions can differ away
from D=4 by O(D-4); they do not determine the full finite amplitude. The
normalized simple poles are J1=-m^2/epsilon,J2=1/epsilon,Jn>=3 finite.
They follow from Gamma(n-D/2)/Gamma(n) with a positive auxiliary mass and
the original dimensional normalization, not dimensional reduction.

Thus, with the same current g10 convention,

    Gamma2_pole(p)=-hbar*g10^2/(16pi^2 epsilon_UV)*(3-xi)*C*p^2,
    deltaZ_pole=+hbar*g10^2/(16pi^2 epsilon_UV)*(3-xi)*C.

Compute C from all45 actual representation matrices. Replay obtains each
index T_R=-Tr(rho_a^2) independently in the supplied faithful frame and
C_R=45*T_R/dim_R, with the entire matrix checked separately. This is the
gauge-only wavefunction pole; scalar/Yukawa wavefunction structures outside
the declared vertex domain are not inferred absent from the full theory.

For the auxiliary-mass check, set R=k^2+m^2. The angular p^2 integrands reduce
to powers R^-n. Only R^-2 has a logarithmic UV pole; terms m^(2n-4) R^-n,
n>=3, are UV convergent. Retain them until this separation is established.
The Gaussian sign can also be checked by a literal Hermitian2x2 kernel with
off-diagonal i*g*t*b and its conjugate: det K=AB-g^2*t^2*b^2, giving the
same -g^2*b^2/(AB) two-point coefficient. This is a sign control, not a
replacement for the vector/scalar tensor contraction.

The source-field and VEV/reference normalizations are different questions.
Sperling–Stoeckinger–Voigt1305.1548v3 eqs20,23 distinguishes scalar Z from
background Zhat. Its eq20 is a comparator for this gauge subset; Zhat is not
derived by, nor adopted in, this calculation. Full potential/source/gauge
counterterm consistency must accompany any later use of this local deltaZ.
