"""SWF1 independent auxiliary-mass, exact Gaussian and entry-level verifier."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json
import os
import threading
import time
import sympy as s

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PACKET = ROOT / 'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_physical_reconciliation'

def clean(z):
    return s.cancel(s.expand(z))

def main():
    start = time.perf_counter()
    timer = threading.Timer(60, lambda: os._exit(124))
    timer.daemon = True
    timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED')
    prep = json.loads((HERE/'validation_preparation.json').read_bytes())
    for name, digest in prep['input_sha256'].items():
        assert sha256(Path(name).read_bytes()).hexdigest() == digest, name
    p, r, c, dim, u, m2, xi = s.symbols('p r c D R m2 xi', real=True)
    radial = r**2 + m2
    numerators = [r**2+4*r*p*c+4*p**2, (r**2+2*r*p*c)**2]
    denominators = [radial*(radial+2*r*p*c+p**2), radial**2*(radial+2*r*p*c+p**2)]
    residues, radial_expressions = [], []
    for numerator, denominator in zip(numerators, denominators):
        coefficient = s.expand(s.diff(numerator/denominator, p, 2).subs(p,0)/2)
        assert s.Poly(coefficient,c).degree() <= 2
        averaged = clean(coefficient.subs(c**2,1/dim).subs(c,0))
        radial_only = clean(averaged.subs(r**2,u-m2))
        log_coefficient = clean(s.limit(u**2*radial_only,u,s.oo))
        remainder = clean(radial_only-log_coefficient/u**2)
        # Every remaining term has a positive auxiliary-mass power and UV degree < -4.
        assert s.limit(u**2*remainder,u,s.oo) == 0
        assert clean(remainder.subs(m2,0)) == 0
        residues.append(clean(log_coefficient.subs(dim,4)))
        radial_expressions.append(str(s.apart(radial_only,u)))
    assert residues == [2,-1]
    total = clean(residues[0]+(xi-1)*residues[1])
    assert total == 3-xi and m2 not in total.free_symbols
    e = s.symbols('epsilon', positive=True)
    mass = s.symbols('mass', positive=True)
    gamma_residues = []
    for n in range(1,6):
        gamma_residues.append(s.simplify(s.limit(e*s.gamma(n-2+e)/s.gamma(n)*mass**(2-e-n),e,0)))
    assert gamma_residues == [-mass,1,0,0,0]
    A,B,g,t,b = s.symbols('A B g t b', positive=True)
    kernel = s.Matrix([[A,s.I*g*t*b],[-s.I*g*t*b,B]])
    literal = s.simplify(s.diff(s.log(kernel.det())/2,t,2).subs(t,0))
    assert literal == -g**2*b**2/(A*B)
    logdet_series = -s.trace((s.diag(1/A,1/B)*(kernel-s.diag(A,B)))**2)/4
    assert s.simplify(s.diff(logdet_series,t,2)-literal) == 0
    # Both supplied kinematic representations; no native helper or result is read yet.
    expected_sparse, dimensions, casimirs = [], {}, {}
    offset = 0
    for sector,size in [('Phi',54),('Sigma',252),('phi',20),('S',2)]:
        both = []
        for filename in ['full_primary.json','full_replay.json']:
            packet = json.loads((PACKET/filename).read_bytes())
            contractions = defaultdict(lambda:s.S.Zero)
            for row in packet['representation_matrices'][sector]:
                assert row['shape'] == [size,size]
                entries = {(i,j):s.sympify(z) for i,j,z in row['entries']}
                assert all(s.simplify(z+entries.get((j,i),0)) == 0 for (i,j),z in entries.items())
                # Gram contraction by each internal index; distinct from -rho*rho.
                grouped = defaultdict(list)
                for (k,i),z in entries.items():
                    grouped[k].append((i,z))
                for values in grouped.values():
                    for i,z in values:
                        for j,w in values:
                            contractions[i,j] += z*w
            actual = {key:clean(z) for key,z in contractions.items() if clean(z)}
            assert all(i==j for i,j in actual)
            diag = [actual.get((i,i),s.S.Zero) for i in range(size)]
            assert len(set(diag)) == 1
            both.append(diag[0])
        assert both[0] == both[1]
        value = both[0]
        casimirs[sector],dimensions[sector] = str(value),size
        for i in range(size):
            if value:
                expected_sparse.append([offset+i,offset+i,str(clean(value*total))])
        offset += size
    assert casimirs == {'Phi':'10','Sigma':'25/2','phi':'9/2','S':'0'}
    assert offset == 328 and len(expected_sparse) == 326
    # Negative controls are sensitive: p-independent vertices cannot generate this term.
    regressions = {str(width):{name:str(clean(total.subs(xi,width)*s.sympify(value))) for name,value in casimirs.items()} for width in [0,1,3]}
    assert regressions['1'] == {'Phi':'20','Sigma':'25','phi':'9','S':'0'}
    assert set(regressions['3'].values()) == {'0'}
    assert clean(residues[0]-total) != 0                 # omitted longitudinal part
    assert s.Rational(9,2) != s.Rational(9,4)            # half complex realification
    assert 2*s.Rational(9,2) != s.Rational(9,2)          # old unnormalized plane J
    for role in ['primary','replay']:
        native = json.loads((HERE/(role+'_result.json')).read_bytes())
        assert native['Casimirs'] == casimirs
        assert native['deltaZ_stripped_sparse'] == expected_sparse
        assert s.sympify(native['integral_residue'],locals={'xi':xi}) == total
        assert native['effective_action_two_point_sign'] == -1 and native['counterterm_sign'] == 1
    p0 = json.loads((HERE/'primary_result.json').read_bytes())
    p1 = json.loads((HERE/'replay_result.json').read_bytes())
    keys = ['Feynman_residue','longitudinal_residue','integral_residue','Casimirs','indices','deltaZ_stripped_sparse','domain','nonzero_generic_xi','zero_complement_generic_xi','Feynman_gauge_deltaZ_per_sector','loop_factor']
    assert all(p0[key] == p1[key] for key in keys)
    receipt = {
        'schema':'C1_GS_SCALAR_WAVEFUNCTION_UV_VALIDATION_V1', 'execution_state':'COMPLETED',
        'disposition':'QUALIFIED_GAUGE_ONLY_SCALAR_P2_UV_INPUT',
        'input_bindings':len(prep['input_sha256']),
        'auxiliary_mass_radial_expressions':radial_expressions,
        'Gamma_residues_J1_through_J5':[str(z) for z in gamma_residues],
        'Gaussian_two_point_sign':str(literal),'Casimirs':casimirs,
        'scalar_real_directions':offset,'matrix_positions':328**2,
        'nonzero_diagonal_generic_xi':len(expected_sparse), 'zero_complement_generic_xi':328**2-len(expected_sparse),
        'width_regressions':regressions,
        'wrong_longitudinal_complex_and_generator_normalizations_detected':True,
        'full_matrix_native_agreement':True,'finite_or_VEV_or_full_CT_choice':False,
        'native_failures':0,'verifier_failures':0,
        'external_or_Lean_or_empirical_validation':False,'authority':'34/39_UNCHANGED',
        'elapsed_after_imports':time.perf_counter()-start,
    }
    print('RESULT '+json.dumps(receipt,sort_keys=True,separators=(',',':')),flush=True)
    timer.cancel()

if __name__ == '__main__':
    main()
