"""SWF1: two exact reductions; neither route reads the other's output."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json
import os
import sys
import threading
import time
import sympy as s

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PACKET = ROOT / 'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_physical_reconciliation'
SECTORS = [('Phi', 54), ('Sigma', 252), ('phi', 20), ('S', 2)]

@lru_cache(None)
def exact(z):
    return s.cancel(s.expand(z))

def main():
    start = time.perf_counter()
    timer = threading.Timer(30, lambda: os._exit(124))
    timer.daemon = True
    timer.start()
    assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED')
    prep = json.loads((HERE / 'preparation.json').read_bytes())
    for name, digest in prep['input_sha256'].items():
        assert sha256(Path(name).read_bytes()).hexdigest() == digest, name
    role = sys.argv[1]
    assert role in ['primary', 'replay']
    dim, xi = s.symbols('D xi', real=True)
    if role == 'primary':
        r, p, c = s.symbols('r p c', real=True)
        denominator = r**2 * (r**2 + 2*r*p*c + p**2)
        numerators = [r**2 + 4*r*p*c + 4*p**2, (r**2 + 2*r*p*c)**2 / r**2]
        angular = []
        for numerator in numerators:
            taylor = s.expand(s.diff(numerator / denominator, p, 2).subs(p, 0) * r**4 / 2)
            assert s.Poly(taylor, c).degree() <= 2
            angular.append(exact(taylor.subs(c**2, 1/dim).subs(c, 0)))
        f, longitudinal = angular
        packet = json.loads((PACKET / 'full_primary.json').read_bytes())
    else:
        x = s.symbols('x', real=True)
        # Shifted-loop integrals: the normalized J1/J2 and l^4/J3 poles.
        f = s.integrate(-2*x*(1-x) + (2-x)**2, (x, 0, 1))
        longitudinal = s.integrate(2*x*(-3*x*(1-x) + 4*x**2/dim - 2 + 2*x**2), (x, 0, 1))
        packet = json.loads((PACKET / 'full_replay.json').read_bytes())
    f4, l4 = [exact(z.subs(dim, 4)) for z in (f, longitudinal)]
    residue = exact(f4 + (xi-1)*l4)
    assert residue == 3-xi
    casimirs, indices, kinetic = {}, {}, []
    offset = 0
    for sector, size in SECTORS:
        rows = packet['representation_matrices'][sector]
        assert len(rows) == 45 and all(row['shape'] == [size, size] for row in rows)
        if role == 'primary':
            operator = s.SparseMatrix(size, size, {})
            for row in rows:
                rho = s.SparseMatrix(size, size, {(i,j):s.sympify(z) for i,j,z in row['entries']})
                assert not (rho + rho.T).todok()
                operator -= rho*rho
            operator = operator.applyfunc(exact)
            value = exact(s.trace(operator) / size)
            assert not (operator - value*s.eye(size)).todok()
            index = exact(value*size/45)
        else:
            # Dynkin index by Frobenius norm, not by multiplying Casimir matrices.
            norms = [exact(sum((s.sympify(z)**2 for _,_,z in row['entries']), s.S.Zero)) for row in rows]
            assert len(set(norms)) == 1
            index = norms[0]
            value = exact(45*index/size)
        casimirs[sector], indices[sector] = str(value), str(index)
        for i in range(size):
            z = exact(residue*value)
            if z:
                kinetic.append([offset+i, offset+i, str(z)])
        offset += size
    assert offset == 328 and len(kinetic) == 326
    result = {
        'schema':'C1_GS_SCALAR_WAVEFUNCTION_UV_NATIVE_V1', 'route':role,
        'Feynman_residue':str(f4), 'longitudinal_residue':str(l4),
        'angular_or_parameter_D_coefficients':[str(exact(f)),str(exact(longitudinal))],
        'integral_residue':str(residue), 'effective_action_two_point_sign':-1,
        'counterterm_sign':1, 'Casimirs':casimirs, 'indices':indices,
        'deltaZ_stripped_sparse':kinetic, 'domain':[328,328],
        'nonzero_generic_xi':len(kinetic), 'zero_complement_generic_xi':328**2-len(kinetic),
        'Feynman_gauge_deltaZ_per_sector':{k:str(2*s.sympify(v)) for k,v in casimirs.items()},
        'loop_factor':'hbar*g10**2/(16*pi**2*epsilon_UV)',
        'finite_part_or_VEV_normalization_calculated':False,
        'elapsed_after_imports':time.perf_counter()-start,
    }
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')), flush=True)
    timer.cancel()

if __name__ == '__main__':
    main()
