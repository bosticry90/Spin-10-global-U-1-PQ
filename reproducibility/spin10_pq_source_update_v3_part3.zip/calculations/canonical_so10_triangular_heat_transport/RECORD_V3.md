# V3: complete the special formal heat-Jacobian diagnostic

The completed V2 pair proves only a finite-mode unit-Berezinian control.
Before relying on it for the actual prescribed heat family,check the precise
retained formal trace as a new bounded continuation. The20 field-flow tangent
entries have even output and odd input only. The ACTUAL643 homogeneous H
columns must all preserve field parity;P=-Dbar_H^2 and its heat then do too.
Consequently W_t DX has no diagonal field block for W_t=F_t or F_t^2,without
a cyclic/infinite-trace manipulation or value of a coincident heat kernel.
DX^2=0 makes log(I+u DX)=u DX. This evaluates the declared formal field
heat-Jacobian diagnostic to zero,not an arbitrary renormalized measure.
External BV sources are not integrated. The previous full generator's
nonzero trace and all32 product obligations remain unchanged.

Two read-only sequential120second/8GiB runs,min350MiB launch;independent
validation in the existing120second bound includes these exact premises.
Retain every V1/V2 artifact;no earlier scope or receipt rewritten. Freeze
source and input hashes. No Gaussian contour,global measure,A5,QAP,finite
contact or physical-prescription adoption. This small actual-block check
prevents mistaking the finite-mode control for an already proved heat result.
