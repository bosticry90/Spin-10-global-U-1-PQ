from pathlib import Path
from hashlib import sha256
import gzip,json,os,sys,time,threading,importlib.util
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sp=importlib.util.spec_from_file_location('known_local_exact_algebra',O.parent/'canonical_so10_connected_contact_lift/lift_v2.py');u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u)
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];prep=read(O/'jacobian_preparation.json');assert digest(Path(__file__))==prep['source_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('HEAT_JACOBIAN_WRITE')
  if p.suffix=='.json':assert str(p) in allowed,('UNDECLARED_HEAT_JACOBIAN_JSON',str(p))
 sys.addaudithook(guard);data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));A=u.Algebra(data['geometry']['names'],data['geometry']['parities']);fields={A.index[n] for n in data['master_field_maps']};e3=read(P/f'frozen_a10_e3_symmetry/{role}.json')['operators']['Tb_geometric_and_transported'];record=read(O/(role+'_v2_result.json'));flows=record['whole20_heat_defect_recipe']['flows'];counts={'even_to_even':0,'odd_to_odd':0};rows=0
 for n in fields:
  H=A.rows(e3[A.names[n]])
  for gp,w in H:
   actual=[j for j,jets in w if j in fields]
   if actual:assert len(actual)==1 and A.parities[n]==A.parities[actual[0]];counts['even_to_even' if A.parities[n]==0 else 'odd_to_odd']+=1
   assert all(A.parities[j]==0 for j,jets in w if j not in fields);rows+=1
 from fractions import Fraction as F
 tangent=[]
 for name,rr in flows.items():
  n=A.index[name];poly={(z['g'],tuple(A.token(q) for q in z['word'])):tuple(((x,h,m),F(a,b)) for x,h,m,a,b in z['coefficient_cells']) for z in rr}
  E=u.left_gradients(A,poly)
  for j,Q in E.items():assert n in fields and j in fields and A.parities[n]==0 and A.parities[j]==1;tangent.append([name,A.names[j],u.pack(A,Q)])
 assert len(tangent)==40 and len(flows)==20 and len(fields)==643
 res={'schema':'SPECIAL_FORMAL_FIELD_HEAT_JACOBIAN_V1','route':role,'H_field_rows_checked':rows,'parity_preserving_linear_rows':counts,'all643_H_columns_preserve_parity':True,'whole_field_tangent':tangent,'nonzero_tangent_coefficient_positions':40,'tangent_nonzero_even_output_odd_input_only':True,'DX_square_exactly_zero_by_block_support':True,'formal_log_Berezinian_heat_diagnostic':0,'heat_profiles':'Any W_t built from actual parity-preserving P=-Dbar_H^2,including F_t or F_t^2;STr(W_t log(I+u DX))=0 from identically zero diagonal BLOCKS','sources_integrated':False,'global_measure_QAP_A5_or_renormalized_contacts_proved':False,'sourcefull_generator_nonzero_diagnostic_unchanged':True,'no_field_or_source_counterterm_applied':True,'shared_limits':'Qualified field-flow/H/parity premises and specified formal heat-trace convention;not a convergent/global or arbitrary field-dependent measure theorem','elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(res,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
