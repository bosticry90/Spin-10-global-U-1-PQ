# A special zero Jacobian does not remove the heat/product transport

Prospective until completed independent validation_receipt and committed-byte
checks. The sole authority remains project_state v113/34of39.

The generator from34e6ac5 gives an EXACT local polynomial canonical shear
with inverse u->-u across all1286 field/source coordinates. Its20 field and37
source flows have arguments that stay fixed. All643 local H/field-flow
commutators vanish. No equation of motion or physical input was changed.

The selected FIELD tangent has40 entries,only even output/odd input. The
finite-mode Berezinian is1. The new V3 actual-carrier check also establishes
that the prescribed formal heat-regularized field log-Jacobian is ZERO:
all643 actual H columns preserve parity,so the regulated tangent has zero
diagonal blocks. No divergent trace cyclicity,coincident heat value or BV
source integration is used. This special result does not change the earlier
full source generator's nonzero Jacobian diagnostic. Neither result is a
global/convergent or arbitrary field-dependent measure theorem.

The important remaining correction is NONZERO. For each actual nonlinear
shift X_Lambda=Z C a12,heat smoothing differs from separately smoothing its
two factors by an explicit ordered Duhamel product. Its flat factor is

    exp[-t(k+l)^2]-exp[-t(k^2+l^2)].

For k=l of squared norm1,t=log2,this equals -3/16. It multiplies a genuinely
nonzero actual L13/C44/a12 coefficient. The fixed-external-momentum O(t)
estimate is not uniform in the UV:scaling k=l=v/sqrt(t) leaves a nonzero
constant. This invalidates deletion of the product correction inside loops;
it does not itself calculate an integrated finite contact or UV coefficient.

The correct inverse of the actual G_t=F G F^ST is F^-ST K_ref F^-1,with order
retained. All100 reference rows affected by the20 shifts are authenticated.
Their auxiliary regulator-response component has20 nonzero positions,hash
414c844c5516d43698967ec2fad6d0b45fc52039219794106d47d35f6ddef55a.
An actual term is16 sqrt2 I g10^2 xi^2 C44 Lambda44 a12/25 times the flat factor
exp(2tq_E^2)-1. This is a kernel/vertex result,not an anomaly or measured loop.

The source-left/Legendre signs lead to the retained conditional identity

    I_C+I_source-I_reg+sum Gamma_Lambda <X_Lambda>=0.

I_source is the whole field-dependent source product;I_reg is X_field R_t
with R_t=one_half eta(K_t-K_ref)eta. The actual tree sign relation is checked
in full568/1136/1176-position polynomials. A Gaussian control detects a missing
regulator insertion. Mean fields retain the connected C/a12 product. For an
hbar-order map its connected transport begins at hbar^2 at fixed regulator;
this does not fix finite contact normalizations or remove their one-loop
source/insertion counterterms.

The precise next missing premise is now narrower:define/control the ordered
inverse-heat regulator insertion and its connected/contact subtraction,
including external source transport. The previous ordinary positive-heat
Born theorem cannot automatically justify this class. The W1-W7 contract
still leaves those renormalized constructions conditional. A formal finite
Gaussian check or finite Fourier external support is not a historical
finite-mode path integral or a continuum measure proof.

V1 failed on structural equality of two equivalent exponential forms;source,
freeze and full capture are retained. V2 changes only to exact simplification
of their difference. Native V2 routes2.346/2.349sec;separate V3 field-heat
diagnostic1.094/1.113sec. Independent SymPy finite bracket pullback,Grassmann
probe/whole-H,quadratic-Hessian and heat/IBP verification is required;its actual
receipt owns status,timing/memory.120sec/8GiB/min350MiB launch applies. No
fresh same-command byte-identical replay pair or expert/Lean/experiment claim.
Shared action,field/source/heat/reference assumptions,software and AI author
remain. Whole diagonal trace and k.l=0 controls are correctly insensitive.

No finite counterterm,field/source redefinition,physical scheme,benchmark or
quantum correction was applied. CurrentGamma874873/source146663,source38 theorem,
369/664inventory,295vectorprofiles,state113/34of39/sevenfalseflags,HB1/C5 block,
flavorpause,140%scalarwarning,matching miss,quartetfailure,custody2/seven and
all prior evidence remain unchanged. Full sourcefree Slavnov,contacts,QAP,
global measure/IR,equivalence,E5/A5 and physical GUT viability are unqualified.
