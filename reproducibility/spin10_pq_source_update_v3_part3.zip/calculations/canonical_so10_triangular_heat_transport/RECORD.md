# Special triangular source/contact transport: applicability test V1

Base34e6ac55f7d2be7edfbe2a0dc628f085a99efd88,main,current AGENTS delegation.
Previous goal turn PROGRESS. Question:what actual regulator/product terms
prevent equating the qualified sourceful classical normalization with a quantum
change of prescription? Test the special20-auxiliary flow,not another full
sourcefree functional or a general equivalence theorem.

Inputs:completed correlated_contact_lift receipt and complete own-role K/
field-source maps;portable643-field geometry;actual E3 H tables and full
reference K/Green/heat program;qualified ordered_multiheat and local covariant
witness records/receipts;W1-W7 retained-source functional contract. Authenticate
all bytes and read sets before computation. Preserve history and authority.

Claims and tests:
1. All1286 coordinate flows have invariant arguments under this actual X,so
z'=z+uXz,J'=J+uXJ have exact inverse u->-u. Check the complete first-order
canonical-pair correction and structural zero second-order bracket on ALL
coordinate pairs,using actual source-left signs. This local polynomial claim
is not a true source-dependent change of path-integral integration variables.
2. The actual20 integrated-field shifts depend only on odd C/a12 and never
auxiliaries. Any fixed finite linear mode projection of their product gives
a triangular field Jacobian with even/odd diagonal identities and Ber=1.
Prove it algebraically;do not claim that such a finite-mode prescription was
historically supplied. No BV-source integration or general zero-Jacobian lemma.
3. All643 H/field-flow commutator columns must vanish with actual12-generator
local H rules. a12 is H-inert. Thus the constant actual Z in X_Lambda=Z C a12
is an H intertwiner. For ACTUAL P=-Dbar_H^2,derive the ordered product defect
 F_L(t)(V a)-[F_L(t)V][F_a(t)a]
 =2 int_0^t F_L(t-s)[(D_mu F_L(s)V)(partial_mu F_a(s)a)] ds, V=Z C,
with fixed order V then a and F_a ordinary scalar heat. Off-flat statement is
a formal Duhamel/common-domain identity,not global semigroup/IR existence.
Check complete20 coefficients and all implicit-zero shifts. Exact flat Fourier
factor exp[-t(k+l)^2]-exp[-t(k^2+l^2)] must be nonzero on an ACTUAL coefficient.
Check nu=k.l=0 insensitive case and k=l=unit decisive case. Fixed-momentum
O(t) does not vanish uniformly at k=l=v/sqrt(t);no inference about an actual
loop finite coefficient without integration/subtraction.
4. Reconstruct the actual ordered Gaussian reference inverse
 K_t=F_t^{-ST} K_ref F_t^{-1} from G_t=F_t G_ref F_t^ST. Keep all order/dual
structure and Gamma_ref[t,A]. It is a formal Gaussian implementation of the
existing Born covariance,not a constructed convergent measure. Define
 R_t=one_half z(K_t-K_ref)z and retain X_field R_t. Authenticate every relevant
reference row (20Lambda shifts) and a nonzero actual auxiliary-square witness
including the e^(2tq^2)-1 flat factor. No regulator-response deletion.
5. Derive the regulated insertion relation with BV J held fixed during the
field-variable change. Retain WHOLE I_source=<sum XJ R>,ordinary j Xfield and
I_reg=<X_field R_t>. In W1 signs,
 I_C+I_source-I_reg+sum Gamma_Lambda <X_Lambda>=0
subject to the declared formal Gaussian/IBP and boundary assumptions. A1/A2
are not discharged. Connected <C a> is not a product of means. At u=hbar*b
its connected mean-field correction starts at hbar^2,not permission to drop
order-hbar insertion/source normalization or to infer all-order A5.

Primary:actual prefix derivatives,full sparse canonical correction and direct
heat-exponential integration. Replay:left-gradient route and heat-evolution/
endpoint derivation. Independent SymPy coefficient/jet/Grassmann checks and
review of analytic hypotheses required. All1286 zero columns/support and all
20reference/heat factors retained. Use compact tensor recipes/hashes;do not
duplicate the prior15MB complete data. No new file>5MiB,total newbytes<10MiB.

Controls:wrong source-left sign,ordinary full trace instead of field-only
Berezinian,forgotten source companions,wrong product heat,missing gradient2,
wrong FGF inverse factor,omitted regulator insertion,commuted noncommuting
operators,wrong odd field order,naive mean-factorization. Sensitivity must be
reported honestly;nu0 and zero source/field slots may be insensitive.

Two sequential native runs120seconds after imports/8GiB;one independent
verifier120seconds/8GiB,350MiB available-commit launch gate. Freeze sources,
controllers,input bytes;capture owned processes/resources and entire failures.
Corrections get versioned freezes,never weaker requirements or silent budgets.
Validate before local commit. No agents,newbranch/worktree,remote/publication,
physical scheme/benchmark adoption,parameter search,quantum loop or Gamma
change,policy/README/authority edits,HB1/C5/flavor activation.

Literature comparator:Anselmi1205.3862 sections1-2 distinguishes sourceful
canonical replacements from true integral-variable changes;its enlarged
master-functional formalism is NOT adopted. Brennecke-Duetsch0801.1408 QAP
is a causal construction,not proof for this heat family. Our special algebra
and explicit Duhamel calculation stand on their checked model premises.

Possible outcomes:verified special finite map and explicit noncommuting heat/
source/product obligation;failure of a premise;underdefined actual prescription;
bounded inconclusive. NOT a QAP,renormalized contacts,global measure/IR,A5,
sourcefree Slavnov,E5/A5 or viableGUT theorem. project_statev113/34of39,seven
falseflags,source38 theorem,Gamma874873/source146663,369/664inventory/295vector
profiles,scalar140%warning,matching miss,quartetfailure,custody2/seven,blocks/
pauses unchanged. Share action,charts,input data,software and AI author limits.
The next calculation should evaluate or define the smallest REQUIRED regulator/
connected insertion rather than equate classical canonicality with restoration.
