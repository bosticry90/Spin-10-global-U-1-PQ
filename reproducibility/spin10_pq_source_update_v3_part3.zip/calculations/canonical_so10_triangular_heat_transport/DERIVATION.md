# Special shear, heat product, and the retained insertion identity

This is a bounded formal result for the fixed generator from34e6ac5. A completed
independent receipt and committed-byte verification are required. It is not a
construction of the complete renormalized quantum functional.

## 1. Exact local canonical map and the special field Jacobian

Write X=X_K for the source-left Hamiltonian vector of the qualified odd K.
Its20 field maps shift only auxiliary Lambda coordinates by beta_ij C_j a12.
Its37 source maps depend on C,a12,x and J_Lambda. Every argument of every
nonzero coordinate flow is fixed by X. Therefore

    F_u(z,J)=(z+u Xz,J+u XJ),      F_-u F_u=identity

for constant even formal u. This extends to ordinary jets by prolongation.
No inverse physical coupling or new parameter is introduced. Inherited reality
holds for real u;this is a local polynomial coordinate statement.

For left gradients,the actual bracket convention is

    (F,G)=sum_i [(-1)^(p_i p_F) F_zi G_Ji
                 +(-1)^((p_i+1)p_F) F_Ji G_zi].

It reproduces the frozen metadata (-1)^p_i times right/left antiparentheses.
The complete first-order canonical correction is zero. Its152 derivative
coefficient positions are checked. The union of arguments of X is isotropic:
it contains no conjugate coordinate pair. Hence every second-order bracket
(Xy_i,Xy_j) is zero. Finite pullback thus preserves all canonical pairs and
zero complements,not merely the infinitesimal action image.

J'=J+u XJ depends on integrated fields. It is NOT an allowed substitution of
external source numbers inside a path integral. The source effects below are
retained as whole insertions rather than a scalar transformation law for Gamma.

The field tangent DX has40 nonzero positions,all even-output/odd-input.
With553 even and90 odd fields,the field Jacobian has blocks

    [[I_even, u B_odd], [0, I_odd]],       Ber=1.

Any fixed auxiliary-independent finite linear projection of C*a into auxiliary
modes preserves this conclusion. That is an algebraic control,not evidence
that the historical heat prescription supplied a finite-mode path integral
or that an arbitrary mode projection preserves local H covariance.

The V3 continuation checks the ACTUAL heat carriers. All643 homogeneous H
columns preserve field parity:8738 linear positions plus48 affine background
terms. Therefore P=-Dbar_H^2 and W_t=F_t or F_t^2 preserve parity. Since
(DX)^2=0 and W_t DX has identically zero diagonal field blocks,

    STr[W_t log(I+u DX)] = u STr(W_t DX) = 0.

No infinite-dimensional cyclicity,coincident kernel evaluation or removal of a
cutoff is used. This evaluates the specified FORMAL field heat-Jacobian
diagnostic. It proves no global/convergent or arbitrary field-dependent measure.
No BV source is integrated. The earlier full generator's nonzero diagnostic,
its32 nonlinear products and general A5 obligations remain unchanged.

## 2. The actual nonlinear field product does not commute with heat

The complete actual643-column calculation gives [H,X_field]=0 for all12 local
H parameters,and H a12=0. Thus the constant coefficient Z in X_Lambda=Z C a12
intertwines ghost and auxiliary H carriers. Let V=Z C,keep the odd product
order V a12,and let F_r(t)=exp(-t P_r),P_r=-Dbar_r^2. On a common invariant
heat domain,or coefficientwise in the specified formal ordered Duhamel family,

    F_L(t)(V a)-[F_L(t)V][F_a(t)a]
      =2 integral_0^t F_L(t-s)[(D_mu F_L(s)V)(partial_mu F_a(s)a)] ds.

Proof:put H(s)=F_L(t-s)[F_L(s)V F_a(s)a]. Covariant Leibniz gives
P_L(Va)=(P_L V)a+V(P_a a)-2(D_mu V)(partial_mu a). Thus H'(s) is minus the
displayed integrand. Integrating H(t)-H(0) proves the identity with the fixed
order and factor2. Even spacetime derivatives cause no exchange of odd fields.
This argument does not prove a global semigroup or an infrared prescription.

At the actual flat member A=0,the complete20-shift tensor is multiplied in
Fourier space by

    d_t(k,l)=exp[-t(k+l)^2]-exp[-t(k^2+l^2)].

For k=l with squared norm1 and t=log2,the factor is exactly -3/16. The ACTUAL
L13 shift contains64 sqrt2 I g10^2 xi C44 a12/25,so its defect coefficient is
-12 sqrt2 I g10^2 xi/25. This is a nonzero tensor/control statement at generic
symbolic g10,xi,not a new physical scale,gauge choice or evaluated loop.

For fixed k,l,d_t=-2t k.l+O(t^2). But k=l=v/sqrt(t),v^2=1,gives the nonzero
constant exp(-4)-exp(-2). Therefore dropping this term as uniformly small in
loop momenta is invalid. When k.l=0,the flat factor is zero;that control is
insensitive and is preserved. This does NOT calculate a nonzero finite or
logarithmic coefficient after integration. In particular,the earlier theorem
for positive-heat ordered Born logarithms is not a finite-contact theorem.

## 3. The regulator action response that must be retained

The actual program has G_t=F_t G_ref F_t^ST,with its exact evaluation-dual
right action. At the formal inverse level,its Gaussian quadratic kernel is

    K_t=(F_t^ST)^-1 K_ref F_t^-1,
    R_t=one_half eta (K_t-K_ref) eta.

The inverse order follows by multiplying G_t K_t and K_t G_t,without commuting
operators. eta denotes the retained reference fluctuations. The selected
auxiliary rows have only B/Lambda partners,so shifting scalar coordinates by
their fixed vacuum does not alter this particular X_field R_t. No background
reference determinant is removed:Gamma_ref[t,A] remains explicitly present
and is inert under this field/source map only because A is fixed.

All100 actual reference rows touched by the20 shifts are retained. In the flat
member,K_t=exp(2t q_E^2) K_ref. The auxiliary part of X_field R_t has20 tensor
positions multiplying exp(2t q_E^2)-1. An actual coefficient is

    16 sqrt2 I g10^2 xi^2 C44 Lambda44 a12/25.

It follows from the literal K_(Lambda13,Lambda44)=xi/4 and the known L13 flow.
Independent differentiation of one_half Lambda K Lambda verifies both legs
and the half factor. This is a vertex/kernel witness,NOT a measured closed
loop or quantum anomaly. It vanishes with the shift at special g10*xi=0;
no such specialization is selected.

Importantly,K_t contains inverse heat. Ordinary positive-heat Born convergence
or UV-log locality cannot simply be transferred to this insertion class.
Ordered cancellations with adjacent G_t factors,and subsequent connected
subtraction/contact limits,need their own argument. A finite Gaussian control
does not silently supply that continuum argument.

## 4. Correct fixed-source insertion relation and its remaining premise

Perform ONLY the even integrated-field change X_field at fixed external BV J.
For the formal regulated Gaussian/interaction expansion,where IBP and the
necessary products are defined,and with the retained boundary conditions,

    0=<X_field(S'+R_t)+sum j_Lambda X_Lambda>.

The actual canonical sign check supplies

    X_field S'=-C-sum XJ R_z,       C=Q'K.

The complete source product has568 positions;the field-action term has1136.
Together with the full1176-position C their density sum is exactly zero.
This sign is checked coefficientwise,not chosen to cancel a quantum remainder.
Using W1's even-auxiliary j_Lambda=-Gamma_Lambda gives

    I_C+I_source-I_reg+sum Gamma_Lambda <X_Lambda>=0,
    I_source=<sum XJ(z,J) R_z(z)>,  I_reg=<X_field R_t>.

These are WHOLE inserted/connected products. Neither source-field dependence
nor I_reg may be discarded. This is a conditional regulated insertion equation,
not its newly measured renormalized value or an A1/A2/A4 proof. A separate
finite Gaussian Wick/IBP control detects omission of I_reg with a nonzero
right side. It is a control,not an actual model amplitude.

For the fixed odd order C a,

    <X_Lambda>=X_Lambda(phi)+Z<(C-phi_C)(a-phi_a)>.

At fixed regulator,the connected two-point term begins at hbar in formal
perturbation theory. If u=hbar*b,its contribution to the mean-field map starts
at hbar^2. This bookkeeping does NOT remove the order-hbar source/insertion
counterterms or choose the finite contact matrix. It does not permit exchanging
cutoff limits without the missing subtraction theorem.

## Applicability and scientific boundary

The W1-W7 contract explicitly leaves A1-A5 conditional. Finite Fourier external
support in the UV proof is not an adopted quantum-mode cutoff. The present
work reduces an assumed shortcut to explicit checked terms. It constructs no
physical scheme,global measure,renormalized product,QAP,full quantum equivalence,
sourcefree Slavnov or E5/A5 theorem. It changes no measured coefficient.

[Anselmi,sections1-2](https://arxiv.org/html/1205.3862) explains the distinction
between sourceful canonical replacements and true variable changes. Its extra
master-functional/proper fields are not introduced here.
[Brennecke-Duetsch](https://arxiv.org/abs/0801.1408) proves QAP results in causal
perturbation theory;that does not supply the missing mixed-heat hypotheses.
Our special algebra/heat conclusions use their independently checked premises.
