"""Special finite canonical shear, and its actual ordered-heat obstruction."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Q
from collections import defaultdict,Counter
import gzip,importlib.util,json,os,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sp=importlib.util.spec_from_file_location('qualified_local_lift_algebra',OUT.parent/'canonical_so10_connected_contact_lift/lift_v2.py');u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u)
read=u.read;digest=u.digest;put=u.put;scale=u.scale;combine=u.combine;ONE=u.ONE

def unpack(A,rows):
 P={}
 for r in rows:put(P,(r['g'],tuple(A.token(n) for n in r['word'])),tuple(((x,h,m),Q(n,d)) for x,h,m,n,d in r['coefficient_cells']))
 return P

def merged(P,Q):
 for k,z in Q.items():put(P,k,z)

def canonical_first(A,X,pairs):
 partner={n:J for n,J in pairs}|{J:n for n,J in pairs};out=defaultdict(dict);support=0;grad={}
 for i,P in X.items():
  E=u.left_gradients(A,P);grad[i]=E
  for n,dP in E.items():
   support+=len(dP)
   merged(out[i,partner[n]],scale(dP,(-1)**(A.parities[n]*A.parities[i])))
   merged(out[partner[n],i],scale(dP,(-1)**A.parities[partner[n]]))
 return {k:P for k,P in out.items() if P},grad,support

def calculate(role):
 bundle=ROOT/'tools/portable_dh_v1';manifest=read(bundle/'manifest.json')
 for n,h in manifest['files_sha256'].items():assert digest(bundle/n)==h,n
 data=json.loads(gzip.decompress((bundle/'inputs.json.gz').read_bytes()));A=u.Algebra(data['geometry']['names'],data['geometry']['parities']);pairs=[(n,J) for n,J,h,k in data['geometry']['field_source_h_k']];fields={n for n,J in pairs};sources={J for n,J in pairs};coords=fields|sources;Jof=dict(pairs);partner={n:J for n,J in pairs}|{J:n for n,J in pairs}
 upstream=OUT.parent/'canonical_so10_correlated_contact_lift';receipt=read(upstream/'validation_receipt.json');assert receipt['execution_state']=='COMPLETED' and digest(upstream/'validation_receipt.json')=='e07f22f6cafee7c31a614395ffa7a8a8a3f988c10535c963fe59a35870fa6e85'
 inp=upstream/(role+'_result.json');assert receipt['input_sha256'][str(inp)]==digest(inp);old=read(inp);assert old['whole_384_scalar_target_matched'] and not old['complete_Q_C_residual']
 K=unpack(A,old['complete_K']);C=unpack(A,old['complete_C_QK']);XF={A.index[n]:unpack(A,P) for n,P in old['all643_nonzero_field_flows'].items()};XJ={A.index[n]:unpack(A,P) for n,P in old['all643_nonzero_source_flows'].items()};X=XF|XJ;assert len(XF)==20 and len(XJ)==37 and len(coords)==1286
 EK=u.left_gradients(A,K)
 for n,J in pairs:
  assert XF.get(n,{})==scale(EK.get(J,{}),-(-1)**A.parities[n]);assert XJ.get(J,{})==scale(EK.get(n,{}),(-1)**A.parities[n])
 deps={n for P in X.values() for gp,w in P for n,j in w};assert not deps&set(X);assert all(not j for P in X.values() for gp,w in P for n,j in w)
 second={n:u.operate(A,P,X,0,role) for n,P in X.items()};assert not any(second.values())
 first,grads,derivsupport=canonical_first(A,X,pairs);assert not first
 # Dependencies form an isotropic coordinate set: hence ALL second-order
 # pullback bracket corrections vanish,including unmaterialized zero pairs.
 assert not {partner[n] for n in deps}&deps
 wrong=XF|{J:scale(P,-1) for J,P in XJ.items()};bad,_,_=canonical_first(A,wrong,pairs);assert bad
 fieldgrad={n:u.left_gradients(A,P) for n,P in XF.items()};diag={n:E.get(n,{}) for n,E in fieldgrad.items()};assert not any(diag.values())
 anti=A.index['ub12'];assert all(A.names[n].startswith('L') and A.parities[n]==0 and all(len(w)==2 and sum(q==anti for q,j in w)==1 and sum(A.names[q].startswith('C') for q,j in w)==1 and all(A.parities[q]==1 for q,j in w) for gp,w in P) for n,P in XF.items())
 assert len([n for n in fields if A.parities[n]==0])==553 and len([n for n in fields if A.parities[n]==1])==90
 e3p=PKG/f'frozen_a10_e3_symmetry/{role}.json';bound=read(e3p.parent/'bindings.json');assert bound['byte_sha256'][e3p.relative_to(ROOT).as_posix()]==digest(e3p);T=read(e3p)['operators']['Tb_geometric_and_transported'];H={n:A.rows(T[A.names[n]]) for n in fields};assert not H[anti]
 hcomm={}
 for n in sorted(fields):
  P=combine(u.operate(A,XF.get(n,{}),H,0,role),scale(u.operate(A,H[n],XF,0,role),-1))
  if P:hcomm[A.names[n]]=u.pack(A,P)
 assert not hcomm
 print('STAGE '+role+' all1286_exact_shear_canonical_and_all643_H_flow_columns',flush=True)
 rfpath=PKG/f'frozen_a10_e5_full_hessian/{role}.json';binding=read(rfpath.parent/'bindings.json');assert binding['byte_sha256'][rfpath.relative_to(ROOT).as_posix()]==digest(rfpath);record=read(rfpath);ref=record['retained_reference'];raw=ref['field_order'];Kraw=ref['reference_Hessian_raw_C3']['entries'];born=record['finite_cutoff_loop_program']
 assert born['Green_program']=='G_Lambda=F_Lambda G_ref F_Lambda^ST; fixed evaluation pairing, exact graded transpose'
 relevant=[];auxresponse={};Xby={A.names[n]:P for n,P in XF.items()}
 for i,j,co in Kraw:
  if raw[i] not in Xby:continue
  relevant.append({'shifted_field':raw[i],'partner':raw[j],'reference_kernel':co})
  if raw[j].startswith(('L','b')) and not raw[j].startswith('bar'):
   constant=u.parse_coefficient(co);assert all(gp==0 for gp,z in constant)
   factor={(0,((A.index[raw[j]],()),)):constant[0][1]};merged(auxresponse,A.product(Xby[raw[i]],factor))
 assert len(relevant)==100 and len(auxresponse)==20
 witness=[r for r in relevant if r['shifted_field']=='L13' and r['partner']=='L44'];assert witness==[{'shifted_field':'L13','partner':'L44','reference_kernel':'xi/4'}]
 word=tuple(A.token(n) for n in ['C44','L44','ub12']);key=(2,word);expected=(((2,0,17),Q(16,25)),);assert auxresponse[key]==expected
 a,b,nu=s.symbols('a b nu',real=True);tt,ss=s.symbols('t s',positive=True);aa=a+b+2*nu;bb=a+b;defect=s.exp(-aa*tt)-s.exp(-bb*tt)
 if role=='primary':
  nd=s.symbols('nu_nz',real=True,nonzero=True);integral=s.integrate(-2*nd*s.exp(-(tt-ss)*(a+b+2*nd)-ss*(a+b)),(ss,0,tt),conds='none');assert s.simplify(integral-defect.subs(nu,nd))==0
 else:
  kernel=s.exp(-(tt-ss)*aa-ss*bb);assert s.simplify(s.diff(kernel,ss)-2*nu*kernel)==0;assert s.simplify(defect.subs(tt,0))==0;assert s.simplify(s.diff(defect,tt)+aa*defect+2*nu*s.exp(-bb*tt))==0
 assert defect.subs(nu,0)==0
 diagonal=s.factor(defect.subs({a:1,b:1,nu:1}));assert s.simplify(diagonal-(s.exp(-4*tt)-s.exp(-2*tt)))==0
 fixed_t_linear=s.simplify(s.limit(defect/tt,tt,0,dir='+'));assert fixed_t_linear==-2*nu
 scaled=s.simplify(defect.subs({a:1/tt,b:1/tt,nu:1/tt}));assert s.simplify(scaled-(s.exp(-4)-s.exp(-2)))==0 and scaled!=0
 FL=s.Matrix([[1,2],[0,1]]);KK=s.Matrix([[3,1],[1,2]]);GG=KK.inv();GT=FL*GG*FL.T;KT=FL.T.inv()*KK*FL.inv();assert GT*KT==KT*GT==s.eye(2);badKT=FL.inv()*KK*FL.T.inv();assert GT*badKT!=s.eye(2)
 assert s.simplify(s.exp(-2*tt)*s.exp(2*tt)-1)==0 and s.simplify(s.exp(-2*tt)*s.exp(tt)-1)!=0
 print('STAGE '+role+' actual100_reference_rows_full20_heat_defect_and_nonuniform_UV_control',flush=True)
 R={A.index[n]:A.rows(P) for n,P in data['master_field_maps'].items()};sourceproduct={};fieldaction={};Qsource={A.index[n]:unpack(A,P) for n,P in old['actual_consumed_Qsource_maps'].items()}
 for n,J in pairs:
  if XJ.get(J):merged(sourceproduct,A.product(XJ[J],R[n]))
  if XF.get(n):assert J in Qsource;merged(fieldaction,A.product(XF[n],Qsource[J]))
 assert not combine(C,sourceproduct,fieldaction)
 # Finite Gaussian/IBP control. The actual finite-mode field map is a
 # separate algebraic control;the Born program is not a global measure.
 E=s.symbols('E',positive=True);JB,JL,muC,muA,cov,hbar,beta,upar=s.symbols('JB JL muC muA cov hbar beta u');K0=s.Matrix([[3,1],[1,2]]);Kt=E*K0;j=s.Matrix([JB,JL]);mean=Kt.inv()*j;ordered_pair=muC*muA+hbar*cov
 reference_ward=s.simplify(beta*ordered_pair*(Kt*mean-j)[1]);omitted=s.factor(beta*ordered_pair*(K0*mean-j)[1]);regterm=s.factor(beta*ordered_pair*((Kt-K0)*mean)[1]);assert reference_ward==0 and omitted!=0 and s.simplify(omitted+regterm)==0
 connected=s.expand((hbar*upar)*beta*(muC*muA+hbar*cov));assert connected.coeff(hbar,2)==upar*beta*cov and connected.coeff(hbar,1)==upar*beta*muC*muA
 unit_even=s.eye(2);unit_odd=s.eye(2);Bblock=s.Matrix([[s.Symbol('odd_a'),s.Symbol('odd_c')],[0,0]]);Cblock=s.zeros(2);assert (unit_even-Bblock*unit_odd.inv()*Cblock).det()/unit_odd.det()==1
 shifted_even=s.diag(1+upar,1);assert shifted_even.det()!=1
 actual_trace=all(not E.get(n,{}) for n,E in grads.items());assert actual_trace
 controls={'wrong_source_orientation_breaks_canonical_pairs':bool(bad),'unit_Ber_requires_no_auxiliary_dependence_countermodel_sensitive':shifted_even.det()!=1,'whole_field_source_diagonal_trace_control_insensitive':actual_trace,'missing_gradient_factor2_fails_heat_identity':s.simplify(defect-defect/2)!=0,'flat_product_heat_is_not_multiplicative':diagonal!=0,'nu0_heat_control_insensitive':True,'uniform_Ot_shortcut_exposed':scaled!=0,'wrong_ordered_inverse_fails':GT*badKT!=s.eye(2),'one_heat_leg_instead_of_FGF_fails':s.simplify(s.exp(-2*tt)*s.exp(tt)-1)!=0,'actual_regulator_auxiliary_response_nonzero':bool(auxresponse),'omit_regulator_insertion_fails_Gaussian_IBP':omitted!=0,'mean_factorization_misses_connected_product':connected.coeff(hbar,2)!=0,'wrong_C_a_order_changes_actual_nonzero_witness':expected!=tuple((c,-z) for c,z in expected)}
 return {'schema':'SPECIAL_TRIANGULAR_HEAT_TRANSPORT_V1','route':role,'scientific_disposition':'EXACT_SPECIAL_CANONICAL_SHEAR_WITH_NONTRIVIAL_HEAT_AND_PRODUCT_TRANSPORT_REQUIRED','coordinate_count':1286,'nonzero_field_flows':20,'nonzero_source_flows':37,'zero_field_flows':623,'zero_source_flows':606,'all_coordinate_second_flow_images_zero':True,'all_flow_arguments_fixed_by_X':True,'flow_argument_names':sorted(A.names[n] for n in deps),'complete_first_order_canonical_residual':[],'complete_second_order_bracket_support_isotropic':True,'all_pair_domain':1286**2,'canonical_derivative_coefficient_positions':derivsupport,'exact_coordinate_inverse':'F_u(z,J)=(z+u Xz,J+u XJ),F_-u F_u=identity because EVERY argument of X is fixed;local polynomial and jet prolongation','field_even_odd_counts':[553,90],'finite_mode_control_Berezinian':1,'finite_mode_control_domain':'Any fixed auxiliary-independent linear projection of C*a products into finite auxiliary coordinates;algebraic control only,no historical finite-mode quantum prescription or localH-compatible projection asserted','field_source_diagonal_trace_control_insensitive':True,'all643_local_H_field_flow_commutator_residual':hcomm,'a12_H_inert':True,'whole20_heat_defect_recipe':{'flows':{A.names[n]:u.pack(A,P) for n,P in XF.items()},'ordered_scalar_factor':'exp[-t(k+l)^2]-exp[-t(k^2+l^2)]','covariant_Duhamel':'2 integral_0^t F_L(t-s)[(D_mu F_L(s)(Z C)) (partial_mu F_a(s)a12)] ds;order C then a12','domain':'formal ordered heat/Duhamel coefficients or common invariant semigroup domain;if the latter is not constructed,no global existence claim'},'actual_nonzero_flat_heat_factor':str(diagonal),'fixed_external_linear_t_term':str(fixed_t_linear),'nonuniform_UV_scaled_factor':str(scaled),'actual_relevant_reference_kernel_rows':relevant,'actual_auxiliary_regulator_response':u.pack(A,auxresponse),'actual_auxiliary_response_sha256':A.fingerprint(auxresponse),'actual_auxiliary_witness':u.pack(A,{key:expected})[0],'actual_auxiliary_response_flat_multiplier':'exp(2*t*q_E^2)-1;generic nonzero g10*xi,not a computed closed-loop coefficient','ordered_regulated_kernel':'K_t=(F_t^ST)^-1 K_ref F_t^-1;R_t=one_half z(K_t-K_ref)z;Gamma_ref[t,A] retained','whole_classical_source_product_positions':len(sourceproduct),'whole_classical_source_product_sha256':A.fingerprint(sourceproduct),'whole_classical_field_action_positions':len(fieldaction),'whole_classical_field_action_sha256':A.fingerprint(fieldaction),'complete_classical_sign_identity':'C+sum XJ*R+sum X_Lambda*EL_Lambda S=0','regulated_insertion_identity':'I_C+I_source-I_reg+sum Gamma_Lambda <X_Lambda>=0 at fixedJ,subject to formal Gaussian/IBP/boundary assumptions;I_reg=<X_field R_t>,I_source=<sum XJ R> are WHOLE products','nonlinear_mean_field_transport':'<X_Lambda>=X_Lambda(phi)+Z< (C-phi_C)(a12-phi_a12)>;u=hbar*b gives connected correction beginning hbar^2 at fixed regulator','one_loop_order_bookkeeping_does_not_fix_finite_contact_matrix':True,'prescription_assessment':'W1-W7 A1-A5 remain conditional;actual retained evidence defines finite Born/heat coefficients and formal UV locality,not a convergent/global renormalized functional measure or unique finite mixing. Finite Fourier external support is not an adopted quantum-mode cutoff.','controls':controls,'no_new_loop_Gamma_contact_normalization_scheme_or_authority_adopted':True,'no_full_QAP_A5_E5_A5_IR_or_physical_viability':True,'shared_limits':'Qualified input action/flow/source maps,reference family,formal-domain and analytic premises,software and AI author shared;distinct algebra routes are not expert/experiment/Lean verification'}

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation_v2.json');assert digest(Path(__file__))==prep['source_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 allowed={str(Path(p).resolve()) for p in prep['read_json_by_role'][role]}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('TRIANGULAR_TRANSPORT_WRITE')
  if p.suffix=='.json':assert str(p) in allowed,('UNDECLARED_TRIANGULAR_INPUT',str(p))
 sys.addaudithook(guard);result=calculate(role);result['elapsed_after_imports']=time.perf_counter()-tick;print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
