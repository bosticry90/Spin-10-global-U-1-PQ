# Exact exponential equality correction V2

V1 passed the complete canonical/H flow checks and reached the scaled-UV
control,but compared two mathematically equal exponential expressions with
Python/SymPy structural equality. simplify() returned a factored form while
the expected side was expanded. The failed source,freeze and complete primary
capture remain immutable. No replay ran and no result was qualified.

V2 tests simplify(actual-expected)==0 for the same exact scaled expression.
No equation,coefficient,sign,control or hypothesis changes. Both complete
native routes run under the same120seconds/8GiB/350MiB gate. Preserve failures;
no scientific acceptance or resources are relaxed. Standing AGENTS delegation
permits this ordinary symbolic-normal-form correction.
