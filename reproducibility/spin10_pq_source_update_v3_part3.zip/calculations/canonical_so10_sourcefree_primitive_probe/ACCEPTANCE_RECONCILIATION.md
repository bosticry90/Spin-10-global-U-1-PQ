# Acceptance reconciliation after the actual-L first-probe construction

This maps existing evidence to the original contracts. It is not a replacement
contract, status ledger or E5 acceptance. project_state.json stays v113/34of39.

The original E5 domain contract separates differential closure from adequacy
for the required BV-compatible counterterms. Its literal ghost-rescaling
counterexample remains true: Euler_(JB0_0)(iota F') contains +partial0 omega0.
The justified quantum target W1-W7 permits renormalized replacements with
transported source/operator identities; it does not require fixed strict
Tqprime invariance by fiat or allow exactness alone to erase the witness.

| Requirement | Evidence now available | Remaining scope |
| --- | --- | --- |
| W1/A1 functional domain | Full643-field Hessian; common formal Euclidean first-Q trace domain | General measure, causal/Lorentzian and constant-vacuum limits |
| W2/A2 subtraction | Complete formal local-log residue and lifted finite Stokes prescription | All-order QAP and arbitrary insertions/multiple contacts |
| W3/A3 restoration | Complete formal one-loop pole identity; finite local breaking primitive | All-order joint restoration and stability |
| W4 background | Actual covariance and qualified source/source-free constructions | Joint transport with a complete chosen normalization and broader physical prescriptions |
| W5 broken geometric Ward | Complete56-slot whole-product construction at the specified base prescription | Its assembled transport with the entire actual counterterm |
| W6 original F' | Qualified original ghost-rescaling replacement preserving the witness | Universal exact-class quotient/adequacy theorem |
| Actual UV residue | Source-complete constructive R=B+Q(K+L),B basic | B/L components not materialized; stability of an arbitrary counterterm space not classified |
| Actual exact K piece | Full source-generator probes and quadratic contacts; prior bounded replacements | No unrestricted field/source equivalence or all-order map |
| Actual exact L piece | Present complete source-free first-probe/Nielsen replacement | No mixed K/L multiple insertion or constant-unit-probe determinant |

The immediate assembly question is whether one common first-order normalized
functional and its source/Ward insertions simultaneously realize the complete
actual counterterm B+Q(K+L). Use the identical T_kappa, source-Euler conventions,
reference determinant and currents. At orderhbar this needs linear responses;
it does not demand a new K/L double-insertion amplitude or a global constant
translation. A complete assembled result would be stronger than separate
replacement lemmas, but still a formal one-loop construction in its stated
domain. Verify W5 as an insertion identity rather than naive Tqprime Gamma.

Do not confuse that actual-residue task with the original universal minimal
polynomial cohomology/adequacy question. The known coupling-torsion examples,
source-dependent arbitrary restored differences, intrinsic versus induced
basic quotients and stability require their own complete argument. The present
construction is not authorization to unlock HB1/C5 or promote E5/A5.

Reviewed: A10_E5_DOMAIN_CONTRACT_V1.md, A10_E5_DOMAIN_RESULT.md,
A10_E5_QUANTUM_FUNCTIONAL_SPEC_V1.md; actual_uv_basic_representative,
original_ghost_rescaling,geometric_ward_products,primitive_probe_pullback,
quadratic_probe_completion and this completed validation_receipt.json.
Old contracts, reports, calculations and receipts remain unchanged.
