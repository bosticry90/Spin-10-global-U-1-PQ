"""Complete source-free carrier first probe; no new model loop coefficients."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from collections import Counter
import gzip,json,sys,time,threading,os
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra,ONE,put,scale,scale_coefficient
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def plus(*pp):
 out={}
 for p in pp:
  for key,z in p.items():put(out,key,z)
 return out

def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start();role=sys.argv[1];assert role in ['primary','replay'];prep=read(O/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
 for p,h in prep['input_sha256'].items():assert digest(Path(p))==h,p
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('SPP_NATIVE_WRITE')
  if p.suffix=='.json':assert str(p) in prep['read_json_by_role'][role],('SPP_UNDECLARED_JSON',str(p))
 sys.addaudithook(guard)
 get=lambda lab:read(Path(prep['artifacts'][role][lab]['path']))
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry'];assert 'spp_u' not in geo['names'] and 'spp_rho' not in geo['names']
 A=Algebra(geo['names']+['spp_u','spp_rho'],geo['parities']+[0,1]);u=A.index['spp_u'];rho=A.index['spp_rho'];pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};sources={J for i,J,h,k in pairs};Hof={i:h for i,J,h,k in pairs};Kof={i:k for i,J,h,k in pairs};Hdomain=set(Hof.values());Jof={i:J for i,J,h,k in pairs}
 def elem(n,j=()):
  if isinstance(n,str):n=A.index[n]
  return {(0,((n,j),)):ONE}
 def rows(rr):
  out={}
  for r in rr:
   for k,c in A.rows([r],explicit_g='g' in r).items():put(out,k,c)
  return out
 def pack(p):
  coeffs=[];ids={};terms=[]
  for(g,w),co in sorted(p.items()):
   if co not in ids:ids[co]=len(coeffs);coeffs.append([[*cell,v.numerator,v.denominator] for cell,v in co])
   terms.append([g,[[n,list(j)] for n,j in w],ids[co]])
  return {'coefficients':coeffs,'monomials':terms,'sha256_exact_cells':A.fingerprint(p)}
 def summary(p):return {'positions':len(p),'sha256_exact_cells':A.fingerprint(p)}
 def D(p,mu):
  out={}
  for(g,w),co in p.items():
   for at,(n,j) in enumerate(w):
    ww,sg=A.canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
    if sg:put(out,(g,ww),scale_coefficient(co,sg))
  return out
 def DD(p,j):
  for mu in j:p=D(p,mu)
  return p
 def grad(p):
  out={}
  for(g,w),co in p.items():
   pref=0
   for at,(n,j) in enumerate(w):
    put(out.setdefault((n,j),{}),(g,w[:at]+w[at+1:]),scale_coefficient(co,(-1)**(A.parities[n]*pref)));pref+=A.parities[n]
  return {k:v for k,v in out.items() if v}
 def EL(p,domain):
  out={n:{} for n in domain}
  for(n,j),df in grad(p).items():
   if n in domain:
    for key,c in scale(DD(df,j),(-1)**len(j)).items():put(out[n],key,c)
  return out
 q={i:rows(data['master_field_maps'][A.names[i]]) for i in fields};dq={}
 def qjet(n,j):
  if(n,j) not in dq:dq[n,j]=DD(q[n],j)
  return dq[n,j]
 def Q(p,wrong=False):
  out={}
  if role=='replay' and not wrong:
   for(n,j),df in grad(p).items():
    if n in fields:
     for key,c in A.product(qjet(n,j),df).items():put(out,key,c)
   return out
  for(g,w),co in p.items():
   pref=0
   for at,(n,j) in enumerate(w):
    if n in fields:
     pp=A.product(A.product({(g,w[:at]):scale_coefficient(co,1 if wrong else (-1)**pref)},qjet(n,j)),{(0,w[at+1:]):ONE})
     for key,c in pp.items():put(out,key,c)
    pref+=A.parities[n]
  return out
 def H(p):
  method='slot' if role=='primary' else 'left'
  return A.action(A.action(p,Hof,method),Kof,method)
 def currents(p):
  out=[{} for mu in range(4)]
  for(n,I),df in grad(p).items():
   if n not in fields:continue
   for at,mu in enumerate(I):
    pp=scale(A.product(qjet(n,I[at+1:]),DD(df,I[:at])),(-1)**at)
    for key,c in pp.items():put(out[mu],key,c)
  return out
 def mul(*pp):
  out={(0,()):ONE}
  for p in pp:out=A.product(out,p)
  return out
 def met(fn):return plus(*(scale(fn(mu),1 if mu==0 else -1) for mu in range(4)))
 prior=get('actual');patterns=prior['Lorentz_allowed_primitive_types'];assert len(patterns)==11
 domain=get('domain');assert domain['complete_interaction_and_single_BRST_joint_trace_domain_constructed'] and domain['field_independent_tangent_positions']==225 and domain['single_tangent_max_joint_node_pole']==3
 assert all(w and any(n in fields for n,j in w) for pp in q.values() for(g,w) in pp)
 constant=Counter()
 for pp in q.values():
  for(g,w),co in pp.items():
   if len(w)==1 and not any(n in sources for n,j in w):
    # Full constant tangent means linear in one field,with constant scalar coefficient.
    constant[(g,len(w[0][1]))]+=1
 assert sum(v for (gp,j),v in constant.items() if gp==0)==225
 fixtures={};controls={};total=Counter();derivative_probe=[]
 print('STAGE '+role+' all_sourcefree_carriers_and_local_source_shift',flush=True)
 for variant,a1,a2,aux in [('light','bar0','bar1','b1'),('heavy','ub13','ub14','L14')]:
  templates=[met(lambda mu:mul(elem(a1),elem(f'A1_{mu}'),elem(f'A1_{mu}'))),met(lambda mu:mul(elem(a1),elem(f'A1_{mu}'),elem(f'B13_{mu}'))),met(lambda mu:mul(elem(a1),elem(f'A1_{mu}',(mu,)))),met(lambda mu:mul(elem(a1),elem(f'B13_{mu}'),elem(f'B14_{mu}'))),met(lambda mu:mul(elem(a1),elem(f'B13_{mu}',(mu,)))),mul(elem('C12'),elem(a1),elem(a2)),mul(elem(a1),elem(aux)),elem(a1),met(lambda mu:elem(a1,(mu,mu))),mul(elem(a1),elem('x_Sigma_0')),mul(elem(a1),elem('x_Sigma_0'),elem('x_Phi_0'))]
  assert len(templates)==len(patterns)
  for ix,(types,jets,cd) in enumerate(patterns):
   label=variant+'_'+str(ix);L=templates[ix];qL=Q(L);assert not Q(qL),(label,'actual_q_square')
   Gu=mul(elem(u),L);Fr=mul(elem(rho),L);Fu=mul(elem(u),qL);assert Q(Gu)==mul(elem(u),qL) and Q(Fr)==scale(mul(elem(rho),qL),-1)
   assert not plus(Q(Fu),Q(Fr),mul(elem(rho),qL))
   eu=EL(Gu,fields);e0=EL(L,fields);flow={i:scale(eu[i],-(-1)**A.parities[i]) for i in fields};raw_action=plus(*(mul(flow[i],q[i]) for i in fields if flow[i]));jj=currents(Gu)
   assert not plus(Fu,scale(raw_action,-1),scale(plus(*(D(jj[mu],mu) for mu in range(4))),-1)),(label,'source_shift_current')
   naive={i:mul(elem(u),scale(e0[i],-(-1)**A.parities[i])) for i in fields};source_derivative_difference=plus(*(plus(flow[i],scale(naive[i],-1)) for i in fields))
   # Mixing different source columns is unsuitable for detecting zero;use all columns.
   du_changes=sum(bool(plus(flow[i],scale(naive[i],-1))) for i in fields)
   er=EL(Fr,fields);ee=EL(Fu,fields)
   assert all(any(n==rho for n,j in w) for pp in er.values() for(g,w) in pp)
   assert all(any(n==u for n,j in w) for pp in ee.values() for(g,w) in pp)
   hr=H(Fr);hu=H(Fu);hl=H(L);op=EL(hr,Hdomain);op0=EL(hl,Hdomain);rho_difference={}
   for i in fields:
    delta=plus(op[Hof[i]],scale(mul(elem(rho),op0[Hof[i]]),-(-1)**A.parities[i]))
    if delta:
     assert all(any(n==rho and j for n,j in w) for(g,w) in delta),(label,'odd_left_probe_factor')
     rho_difference[Hof[i]]=delta
   if rho_difference:derivative_probe.append(label)
   assert all(any(n==rho for n,j in w) for(g,w) in hr) and all(any(n==u for n,j in w) for(g,w) in hu)
   assert not any(n in sources for pp in [Fr,Fu] for(g,w) in pp for n,j in w)
   maxjet=max([len(j) for pp in op.values() for(g,w) in pp for n,j in w if n in set(Kof.values())]+[0]);assert maxjet<=1
   total['L']+=len(L);total['qL']+=len(qL);total['HrhoL']+=len(hr);total['HuQL']+=len(hu)
   fixtures[label]={'pattern':[types,jets,cd],'coefficient_dimensional_unit_annotation':cd,'L':pack(L),'qL':pack(qL),'source_shift':{A.names[Jof[i]]:pack(pp) for i,pp in flow.items() if pp},'source_shift_currents':[pack(p) for p in jj],'rho_source_Eulers':{A.names[Jof[i]]:summary(pp) for i,pp in er.items() if pp},'u_source_Eulers':{A.names[Jof[i]]:summary(pp) for i,pp in ee.items() if pp},'whole_rho_Hessian':summary(hr),'whole_u_Hessian':summary(hu),'rho_functional_Hessian':{A.names[n]:summary(pp) for n,pp in op.items() if pp},'derivative_rho_operator_terms':sum(len(pp) for pp in rho_difference.values()),'Du_source_shift_columns':du_changes,'all_augmented_source_Eulers_keep_their_probe':True,'all643_field_flow_corrections_zero':True,'q_square_and_extended_master_residual_zero':True,'explicit_source_shift_current_residual_zero':True}
 assert derivative_probe and any(f['Du_source_shift_columns'] for f in fixtures.values())
 print('STAGE '+role+' constant_chain_and_joint_label_domain',flush=True)
 nodes=['B','L','x','C','a'];G={('B','B'):2,('B','L'):1,('L','B'):1,('x','x'):0,('C','a'):2,('a','C'):2};V={('x','x'):0,('x','L'):0,('L','x'):0};T={('B','C'):-1,('C','B'):-1,('a','L'):0,('L','a'):0}
 def addmax(*pp):
  out={}
  for p in pp:
   for k,v in p.items():out[k]=max(v,out.get(k,-1000))
  return out
 def mm(p,q):
  out={}
  for(i,k),v in p.items():
   for(kk,j),z in q.items():
    if k==kk:out[i,j]=max(v+z,out.get((i,j),-1000))
  return out
 def close(v):
  M=mm(G,v);star=addmax(M,{(n,n):0 for n in nodes})
  if role=='primary':
   for k in nodes:
    for i in nodes:
     for j in nodes:
      if(i,k) in star and(k,j) in star:star[i,j]=max(star.get((i,j),-1000),star[i,k]+star[k,j])
  else:
   for length in range(len(nodes)):star=addmax(star,mm(star,M))
  return mm(star,G),any(star.get((n,n),0)>0 for n in nodes)
 dressed,bad=close(V);assert not bad and [[i,j,v] for(i,j),v in sorted(dressed.items())]==domain['dressed_zero_transfer_IR_edges'];one=mm(mm(dressed,T),dressed);two=mm(mm(one,T),dressed);assert max(one.values())==3 and max(two.values())==4
 _,forbidden=close(addmax(V,{('a','C'):0}));assert forbidden
 routing=[]
 for N in range(1,7):
  M=s.eye(N)
  for i in range(1,N):M[i,0]=1
  assert M.det()==1;routing.append([N,4*N,1])
 print('STAGE '+role+' nonzero_gaussian_Nielsen_and_connected_covariance',flush=True)
 x,b,t=s.symbols('x b t',real=True);f=x+x*x/2;U=1+x;D0=b-U*U;cov=s.Matrix([[b,U],[U,1]]).inv();assert s.cancel(cov[0,0]-1/D0)==0
 gaussian=[]
 for h,point in [(x,{x:1,b:9}),(x*x/2,{x:2,b:16})]:
  fu=f+t*h;log=s.log(b*s.diff(fu,x,2)-s.diff(fu,x)**2)/2-s.log(s.diff(fu,x));det=s.diff(log,t).subs(t,0)
  IL=(s.diff(h,x,2)/2-s.diff(h,x)/U)/D0;direct=b*s.diff(h,x,2)*cov[0,0]/2+s.diff(h,x)*cov[1,0]-s.diff(h,x)/U
  assert s.cancel(det-direct)==0 and s.cancel(direct-b*IL)==0
  vals=[s.cancel(IL.subs(point)),s.cancel(direct.subs(point))];assert all(v!=0 for v in vals)
  wrong=b*s.diff(h,x,2)*cov[0,0]/2+s.diff(h,x)*cov[1,0]+s.diff(h,x)/U;assert s.cancel((wrong-direct).subs(point))!=0
  gaussian.append({'h':str(h),'point':{str(k):v for k,v in point.items()},'I_L_over_a':str(vals[0]),'I_qL':str(vals[1]),'determinant_and_Berezin_response_match':True,'mean_field_omission_fails':True,'wrong_ghost_sign_fails':True})
 assert [g['I_qL'] for g in gaussian]==['-9/10','-8/21']
 result={'schema':'SOURCEFREE_PRIMITIVE_PROBE_V1','route':role,'scientific_disposition':'COMPLETE_FORMAL_ONE_LOOP_FIRST_PROBE_SOURCEFREE_PRIMITIVE_REPLACEMENT_IN_DECLARED_EUCLIDEAN_DOMAIN_NOT_FULL_E5','fixtures':fixtures,'all11_carriers_with_light_heavy_fixtures':len(fixtures)==22,'total_coefficient_positions':dict(total),'rho_derivative_operator_fixtures':derivative_probe,'constant_tangent_entries_unchanged':225,'dressed_IR_edges':[[i,j,v] for(i,j),v in sorted(dressed.items())],'single_tangent_bound':3,'two_independent_tangents_critical':4,'no_new_unlabeled_constant_vertex':True,'forbidden_unlabeled_ghost_mass_positive_cycle':forbidden,'joint_routing_controls':routing,'gaussian_controls':gaussian,'second_gaussian_at_x1_insensitive_and_not_used_as_sensitive_control':True,'Nielsen_one_loop_relation':'I_qL=(Gamma1,L)+(S,I_L)','same_Tkappa_full_lift_heat_power_contacts_and_nonlocal_remainder_retained':True,'local_probe_only_no_constant_strength_unit_probe_limit':True,'no_integrated_field_classical_flow_or_field_Jacobian':True,'earlier_fullK_Jacobians_retained':True,'actual_L_coefficients_fitted_or_extracted':False,'mixed_K_L_multiple_insertion_constructed':False,'full_QAP_A5_E5_physical_or_universal_cohomology_claim':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
if __name__=='__main__':main()
