# Actual source-free generator and the first-probe quantum construction

## 1. Classical operation and explicit current

The actual prolonged odd field operation q is source-free and nilpotent.
For source-free odd L, QL=qL as an integrated functional. Its Hamiltonian
field flow is zero. G=integral uL generates the negative canonical source
shift A_Ji=-(-1)^pi Euler_left,zi(G). Since S is source-linear,
S(J+A)=S+sum A_Ji R_i, with no quadratic source-shift action term.

The source-left pairing gives sum A_J R=sum R_i Euler_left,i(uL). Ordinary
integration by parts gives

 u*qL-sum A_J R=div j,
 j_mu=sum_(i,I,k with I_k=mu) (-1)^k
       D_(I_after_k) R_i * D_(I_before_k) leftgrad_(i,I)(uL).

For second jets the telescope is Dmu Dnu R*f-R*Dmu Dnu f
=Dmu[(Dnu R)f]-Dnu[R Dmu f]. Du,D2u remain. No EOM, source restriction or
density-zero current is used.

All mutual source-free BV brackets vanish. For inert local tests,
(S_u,S_u)/2=0 and (S_ext,S_ext)/2=-integral rho*qL. Adding the bookkeeping
term integral rho*delta_u S_ext=+integral rho*qL yields the exact extended
master identity. Source-field brackets and integrations retain the current.
The external tracking differential d=integral rho delta_u introduces no
integrated degree of freedom or adopted change of physical transformations.

## 2. Applicability of the actual common trace domain

New vertices are u*qL and rho*L. Every ordinary Hessian coefficient retains
u/rho or its jet. A linear ordinary-field vertex has zero Hessian. Both
additions are source-free, so all643 classical field maps, their225 constant
tangent entries and formal adjoints are unchanged. New source-Euler terms
retain probes even if they are constant in ordinary fields. The external
variation replaces a u label by rho, never by a constant.

Thus the completely unlabeled interaction sector stays exactly the same:
BB pole2, BL/LB pole1, odd pole2 and positive-reference-mass scalar pole0,
with only scalar-mass/scalar--auxiliary constant vertices. The inherited
support automaton has no positive-pole constant cycle, at most two scalar/M
endpoints, ordinary dressed nodes at most2 and a single tangent/adjoint
merged node at most3. The NEW labeled vertices do not enter that automaton.
A rho-L Hessian has at most one ordinary derivative; a u-qL Hessian at most
two. Their polynomial numerators cannot increase soft poles. A masslike
u*ghost-bilinear is a labeled vertex, never an unlabeled constant mass cycle.

At N labeled vertices, loop momentum and N-1 transfer sums give N independent
four-dimensional node vectors. Additional labels at a vertex add free relative
momenta. The same submersive routing and locally-L1 majorant therefore apply
to first probe order and one Slavnov/external-doublet variation. Nonlinear
substitutions preserve/replace labels and ordinary jets. This proof does not
take a constant-probe or physical-vacuum restriction or two independent Q
insertions. Each fixed finite external/probe coefficient has finitely many
UV-symbol terms; no whole Born-series convergence is asserted.

Use the same proof smoothing on EVERY free edge. Keep finite-cutoff inverse,
source and projection defects until removal. The extended majorant is
epsilon-independent; dominated convergence gives the same limit as the
actual covariant profiles. Hard-shell profile differences/jets are smoothing
and have no UV subtraction coefficients. The existing positive auxiliary
Mellin weight and r^-5 remainder still apply. This proves UV finite part
first, then IR removal, not an unrestricted L2 trace/inverse statement.
Separate critical IR delta terms are not dropped or adjusted. Finite path
and routing tests support the argument, not a proof of infinite resummation.

## 3. Same lift and finite prescription, without fitted contacts

Continue Lorentz contractions in L using the FIXED metric lift of S. Its
vector/derivative carriers a*divB,a*divA,a*BB,a*AB,a*AA,Box(a) have direct
tensor-index lifts. Scalar/exterior-ghost coefficients are independent of
the continued vector trace count. Use Q_D L_D in the u term and L_D in the
rho term so the extended classical master identity holds in the lifted
algebra. Retain closed factors D and their first jet before D=4 projection.

The qualified lifted Stokes construction applies coefficientwise to the SAME
augmented Hessian with differential q+d. External d commutes with symbol
composition, angular integration and the first D-jet. It adds no integrated
field trace or Jacobian. Field BRST tangent/heat measure remain those of the
qualified model. Full source-Euler congruence terms remain. The same local
heat/power conversion, dimension-jet finite term and common kappa extend the
complete first-probe family. Nonlocal remainders and Gamma_ref[A] remain.

Apply T_kappa to the complete log(H_ext/Kref). Its derivatives define

 [L]_kappa(x)=delta_left Gamma_ext/delta rho(x)|0=L(x)+hbar I_L(x),
 [qL]_kappa(x)=delta Gamma_ext/delta u(x)|0.

I_L is the WHOLE i/2*T_kappa[G H_(rho L)] with rho extracted by LEFT Euler
derivative, including derivative-probe contacts and local finite conversion.
G is the complete formal inverse, not the flat propagator alone. Analogous
u differentiation defines the qL insertion. Gamma_ref is source/probe-inert,
but is not removed from Gamma.

The once-rho-differentiated extended restored identity is

 delta_u Gamma|0=(Gamma,[L]_kappa) modulo hbar2,
 I_qL=(Gamma1,L)+(S,I_L).

These are correlated normalizations from one fixed augmented functional.
No unknown coefficient was assigned to cancel a remainder. The loop generator
can depend on BV sources although the classical L does not; a strict nonlinear
mean-field source substitution is not inferred.

## 4. Actual-residue use and loop-order distinction

V333 gives R=B+Q(K+L) modulo currents. Qualified fullK first-probe results
and the present uniform actual-L result supply separately justified first-order
replacements. A mixed K/L double insertion is not needed at strength of
orderhbar; it would affect hbar2 and need a separate product theorem.

At a fixed regulator, formal u=hbar*lambda changes the effective action by
hbar*lambda*qL modulo hbar2, with the derived correlated source normalization.
A constant coefficient on this tree local functional is legitimate on the
test fields; no unit-strength constant-u determinant or vacuum diagonal is
inferred. Laurent pole normalization uses the same coefficientwise loop order,
without an analytic exchange of hbar and cutoff limits. No physical scheme
is adopted. Classical integrated field flow is identically zero, so its field
Jacobian is zero; earlier fullK/ghost-rescaling Jacobians remain nonzero.
Unit-probe connected corrections are retained, not deferred.

The theorem is first-probe formal one-loop actual-residue replacement, not
universal minimal cohomology, all-order stability/QAP/E5/A5 or physical
S-matrix equivalence.

## 5. Nonzero independent Gaussian controls

A BRST quartet has Qx=c,Qa=b,Qb=Qc=0 and
S=b*f(x)+b^2/2-a*f'(x)*c+Jx*c+Ja*b, f=x+x^2/2.
This explicitly differs by an auxiliary/antighost sign from raw Spin10.
Let L=a*h(x), with h=x or x^2/2. Then qL=b*h-a*h'*c.
Put U=1+x,D=b-U^2>0,U>0. Gxx=1/D,Gbx=-U/D. The shifted odd Gaussian gives
<delta a delta x>/a=-Gxx/U and <delta a delta c>=1/U. Therefore

 I_L/a=(h''/2-h'/U)/D,
 I_qL=b*h''/(2D)+h'*Gbx-h'/U=b*I_L/a.

Independently f_u=f+u*h gives
Gamma1_u=log[b*f_u''-(f_u')^2]/2-log(f_u'). Its u derivative at0 is the same
I_qL. Linear field rules imply Gamma1 has no source dependence, so
(Gamma1,L)=0 in this control. At x1,b9,h=x the values are -1/10,-9/10;
at x2,b16,h=x^2/2 they are -1/42,-8/21. Mean-field factorization or a wrong
ghost sign fails. The second control at x1 is insensitive (both zero), so it
is not used as a sensitive test. These finite Gaussian controls are not
Spin10 loop measurements or global interacting convergence theorems.

Primary comparison: Quadri, arXiv:1412.6772 sections2.2-3 supplies the extended
Slavnov/canonical-flow method; Gambino/Grassi, hep-ph/9907254 discusses Nielsen
identities and renormalization. Applicability here follows from the actual
label/domain/metric-lift proof, not their Standard Model or physical-pole
conclusions. See RECORD.md for direct links.
