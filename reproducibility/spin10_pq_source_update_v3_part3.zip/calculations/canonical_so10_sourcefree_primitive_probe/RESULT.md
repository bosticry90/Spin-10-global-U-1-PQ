# First-probe quantum replacement for the actual source-free primitive

The completed independent receipt is validation_receipt.json, SHA256
7a7cfcfd27541b2715874167e43243652230ed49c500f188dbe5e4f616edf1fb.
Both native routes and corrected independent verification passed. Final local
sealing additionally checks committed bytes and preservation of older evidence.
This is a formal Euclidean one-loop first-probe result, not full E5/A5.

## The missing actual-L construction is now supplied

The preceding actual-residue theorem gave R=B+Q(K+L) modulo explicit currents.
It constructed L=H(R-QK) as a source-free local odd generator, but did not
justify its quantum replacement. The present construction covers its complete
power-counting carrier domain:17 typed patterns,11 of even Lorentz rank.
These are potential tensor structures, not11 independent invariant counterterms.
L's actual coefficients need not be extracted or fitted to obtain this result.

For local external tests u even and rho odd, define

 S_u=S+integral u*qL,
 S_ext=S_u+integral rho*L.

The same finite prescription gives the complete first-probe identity

 delta_u Gamma|0=(Gamma,[L]_kappa) modulo hbar2,
 I_qL=(Gamma1,L)+(S,I_L),
 [L]_kappa=L+hbar I_L.

The insertions are derivatives of ONE restored augmented functional, including
all source derivatives, connected products and local finite conversion. This
is not a counterterm coefficient assigned to cancel a remainder. The term
(Gamma1,L) must remain in the actual model; its vanishing in the small Gaussian
control is a special property of that control, not a Spin10 simplification.

## The source-only operation and its currents are explicit

Because L has no BV sources, its classical Hamiltonian operation fixes every
one of the643 integrated fields. For integral uL the negative canonical
source shift is

 A_Ji=-(-1)^pi Euler_left,zi(uL).

The actual source-linear action therefore obeys

 S(J+A)=S+sum_i A_Ji R_i,
 u*qL-sum_i A_Ji R_i=div j.

The complete source-left signs and first/second probe derivatives are retained.
Replacing A_(uL) by u*A_L loses Du and D2u terms. Currents cannot be discarded
as zero densities. The extended master identity follows with its correct sign:

 (S_ext,S_ext)/2+integral rho*delta_u S_ext=0.

All mutual source-free BV brackets vanish. The external differential u->rho
is bookkeeping for this identity, not a new integrated field, canonical pair
or adopted physical BRST law. The loop generator [L] can acquire BV-source
dependence even though its classical term L is source-free. No naive scalar
substitution Gamma(J+A(mean fields)) is asserted.

Twenty-two light/heavy component fixtures check all11 carrier structures using
the actual field rules. Their finite coordinates are diagnostic tensor entries,
not new invariant interactions or physical coefficients. The analytic graded
derivation in DERIVATION.md applies uniformly to arbitrary allowed tensors.

| Calculated fixture object | Coupling-resolved positions |
| --- | ---: |
| L densities |58 |
| Actual qL densities |1479 |
| Nonzero local source shifts |110 |
| Explicit source-shift currents |216 |
| Polarized rho-L Hessians |112 |
| Polarized u-qL Hessians |12136 |

Ten source-shift columns change when probe derivatives are omitted. The
functional vector/antighost Hessian has8 derivative-rho terms across the two
color fixtures. They disappear under a false factorization of the probe
through its differential operator. Zero complements across all643 source and
field directions are retained. Box(a) remains in the local-probe calculation
even though its constant-coefficient integral is an ordinary boundary.

## Why the same trace construction applies

The new vertices are source-free. Thus the classical field BRST maps and their
225 field-independent tangent/adjoint entries are unchanged. Every new ordinary
Hessian and every new source-Euler monomial retains u,rho or a jet. The
external variation replaces u by rho, never by a nonzero constant. No new
unlabeled constant interaction enters the existing infrared-chain analysis.

The inherited scalar-mass/scalar--auxiliary chains therefore still have the
same eight dressed edge types. Ordinary joint nodes have pole degree at most2;
a single tangent junction has at most3. The new local differential numerators
do not increase these soft exponents. The same independent transfer-momentum
routing, smooth free-edge proof approximants and dominated-convergence bounds
apply to the first-probe family and its first Slavnov variation.

No constant-u unit-strength limit or fixed physical-vacuum/plane-wave diagonal
is taken. Erasing the probe label would change a hypothesis. An additional
unlabeled ghost-mass edge creates a positive-pole cycle in the conservative
support control; that is not a measured failure of the actual covariant L.
Two independent tangents can still reach critical degree4, so this result is
not an arbitrary multiple-insertion theorem. The earlier distributional IR
contacts remain in their original scopes and are not set to zero.

The same metric lift is used for S,L and qL. Closed vector factors D and their
first derivative remain before four-dimensional projection. The common
T_kappa retains finite heat constants, power/first-dimension-jet terms,
ordinary source Eulers, functional adjoints and nonlocal remainders. No finite
coefficient was chosen, and kappa,b0 and IR constants remain distinct.
Gamma_ref[A] is retained. The required UV finite part precedes IR removal.

DERIVATION.md supplies the all-finite-coefficient domain/lift proof. Finite
support paths and routing determinants challenge that proof; they do not
establish convergence of a whole Born resummation or unrestricted L2 inverse.

## The nonzero connected controls are sensitive

For a finite BRST quartet with Qx=c,Qa=b and
S=b*f(x)+b^2/2-a*f'(x)*c+Jx*c+Ja*b, f=x+x^2/2, take L=a*h(x).
The Gaussian Hessian and a separate Berezin completion give

 I_L/a=(h''/2-h'/(1+x))/(b-(1+x)^2),
 I_qL=b*I_L/a.

Independently differentiating the actual boson/ghost determinant under
f->f+u*h reproduces I_qL on the open positive-boson-Hessian domain.

| Control | I_L/a | I_qL |
| --- | ---: | ---: |
| h=x, x1,b9 | -1/10 | -9/10 |
| h=x^2/2, x2,b16 | -1/42 | -8/21 |

Dropping the mixed odd/bosonic covariance or changing the ghost sign fails.
The second case would vanish at x1 and is explicitly not counted as a
sensitive test there. This finite Gaussian calculation is a control of the
connected-insertion and loop-order reasoning, not a new Spin10 amplitude or
a global interacting functional-integral convergence result.

The method is related to the extended Slavnov/Nielsen canonical-flow framework
in [Quadri, sections2.2-3](https://arxiv.org/html/1412.6772) and
[Gambino/Grassi](https://arxiv.org/abs/hep-ph/9907254). Their general framework
does not certify this mixed heat-regulated model; the explicit domain/lift
argument above supplies applicability in the stated scope. No Standard Model
physical-pole theorem is transferred.

## Consequence for the actual one-loop residue

Together with the existing fullK replacement, this supplies the previously
missing source-free exact-piece replacement in R=B+Q(K+L). At formal strength
u=hbar*lambda and fixed regulator, its one-loop effective-action change is
hbar*lambda*qL modulo hbar2, with correlated source/operator normalization.
Unit-probe corrections are nevertheless present at one loop and are retained.
A mixed K/L double insertion would affect hbar2 and is not constructed here.
No global constant-strength integrated-field translation is required or proved.

The classical source-only operation has zero integrated-field Jacobian because
it fixes those fields. This does not cancel the earlier nonzero fullK or
ghost-rescaling Jacobians. Neither does it mean that the altered quantum
effective action is obtained by a naive field-dependent source substitution.

The next useful test is the simultaneous first-order normalization of the
complete actual counterterm B+Q(K+L), with the source and broken geometric-Ward
insertions transported in the SAME prescription. Separate successful pieces
do not by themselves constitute that assembled acceptance result. General
minimal source-counterterm classification and stability remain separate.

## Execution and limitations

Native routes completed in5.172/4.432seconds after imports. The separate
corrected verifier took149.398seconds, within its180second cap. Maximum sampled
private allocation was256380928bytes, not a true process peak. Both natives
stayed within120second caps;8GiB memory/8MiB package bounds and launch commit
floors were respected. No native failed and no completed native was rerun.

One independent verifier failed its right-to-left derivative sign conversion:
a negative integer exponent made Python produce a Float. V2 reduces parity
modulo2 first and retains exact rational/radical coefficients. Failed source,
preparation and complete capture are preserved and excluded from qualification.
One large terminal-edit request was rejected before any process started; the
same edits were completed with the file-patch tool and the incident is recorded.

The verifier imports no new native helper. It reconstructs all22 qL/source
shifts, currents, full Hessian fingerprints, source-Euler zero complements and
probe jets using right gradients and separate SymPy/word arithmetic. It also
checks the nonzero Gaussian/Berezin and determinant responses. The complete
analytic proof and its inherited master/reference/Stokes assumptions remain
necessary. Shared scientific inputs, Python/SymPy and AI authorship limit
independence. No external scientist, Lean kernel or experiment validates the
physical model. Track B records both the structural reduction and the exact
arithmetic verifier failure. Education remains voluntary and nonblocking.

State113/34of39 and seven false quantum flags are unchanged. The broad E4
audit is reused by an authenticated unchanged-byte chain; custody staysexit2
with seven unresolved references, never PASS. Original nonhorizontal witness,
quartet failure,295 unmeasured vector profiles, scalar140percent warning and
matching gap remain. FullQAP,A5/E5,all-order stability,arbitrary product/measure,
minimal/basic quotient comparison and physical IR/vacuum/Lorentzian/causal
equivalence remain unqualified. HB1/C5 stays blocked, flavor paused and C1_GS
uncalculated. No physical scheme, baseline, benchmark, action, policy, protected
authority, old evidence, push or publication changed. Whole goal remains active.
