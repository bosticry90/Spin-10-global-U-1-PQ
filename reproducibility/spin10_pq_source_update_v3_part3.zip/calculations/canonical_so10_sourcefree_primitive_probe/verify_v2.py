"""Separate right-gradient/field-word verifier; imports no new native code."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from fractions import Fraction as F
from itertools import combinations_with_replacement
import json,gzip,time,threading,os
import sympy as s
R=Path('C:/Users/psboy/Documents/ToE-Next');O=R/'calculations/canonical_so10_sourcefree_primitive_probe'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
tick=time.perf_counter();watch=threading.Timer(180,lambda:os._exit(124));watch.daemon=True;watch.start();vp=read(O/'validation_preparation_v2.json')
for raw,z in vp['input_sha256'].items():assert digest(Path(raw))==z,raw
def readonly(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('SPP_VERIFY_WRITE')
sys_audit=__import__('sys').addaudithook(readonly)
prep=read(O/'preparation.json');a=read(O/'primary_result.json');b=read(O/'replay_result.json');assert {k:v for k,v in a.items() if k not in ['route','elapsed_after_imports']}=={k:v for k,v in b.items() if k not in ['route','elapsed_after_imports']}
for role in ['primary','replay']:
 cap=read(O/(role+'_capture.json'));assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0
 for bind in prep['artifacts'][role].values():assert digest(Path(bind['path']))==bind['sha256'] and digest(Path(bind['receipt']))==bind['receipt_sha256']
data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry'];names=geo['names']+['spp_u','spp_rho'];par=geo['parities']+[0,1];index={n:i for i,n in enumerate(names)};u=index['spp_u'];rho=index['spp_rho'];pairs=geo['field_source_h_k'];fields={i for i,J,h,k in pairs};sources={J for i,J,h,k in pairs};Jof={i:J for i,J,h,k in pairs};Hof={i:h for i,J,h,k in pairs};Kof={i:k for i,J,h,k in pairs};Hd=set(Hof.values())
g,xi,eta=s.symbols('g10 xi eta_H');loc={'g10':g,'xi':xi,'eta_H':eta,'reference_width_M':xi,'reference_width_H':eta}
@lru_cache(None)
def coef(t):return s.expand(s.sympify(t,locals=loc))
def canonical(word):
 result=[];sg=1
 for token in word:
  if par[token[0]] and token in result:return (),0
  at=len(result)
  while at and result[at-1]>token:
   if par[token[0]] and par[result[at-1][0]]:sg=-sg
   at-=1
  result.insert(at,token)
 return tuple(result),sg
def add(*pp):
 out={}
 for p in pp:
  for k,v in p.items():out[k]=out.get(k,0)+v
 return {k:s.expand(v) for k,v in out.items() if s.expand(v)!=0}
def scale(p,c):return {k:c*v for k,v in p.items() if c*v!=0}
def mul(*pp):
 out={():s.S.One}
 for p in pp:
  new={}
  for w,c in out.items():
   for v,d in p.items():
    ww,sg=canonical(w+v)
    if sg:new[ww]=new.get(ww,0)+sg*c*d
  out=add(new)
 return out
def elem(n,j=()):return {((index[n] if isinstance(n,str) else n,j),):s.S.One}
def token(text):
 n,_,j=text.partition('__');return index[n],tuple(map(int,j))
def decode_rows(rows):
 out={}
 for r in rows:
  w=tuple(map(token,r['word']));assert canonical(w)==(w,1);out[w]=out.get(w,0)+coef(r['coefficient'])*g**r.get('g',0)
 return add(out)
def unpack(packet):
 cc=[]
 for cells in packet['coefficients']:
  z=0
  for xp,hp,mask,num,den in cells:
   rad=s.prod(s.sqrt(prime) for bit,prime in enumerate([2,3,5,7]) if mask&(1<<bit))*(s.I if mask&16 else 1);z+=s.Rational(num,den)*xi**xp*eta**hp*rad
  cc.append(z)
 out={}
 for gp,word,i in packet['monomials']:
  w=tuple((n,tuple(j)) for n,j in word);assert canonical(w)==(w,1)
  out[w]=out.get(w,0)+g**gp*cc[i]
 return add(out)
def D(p,mu):
 out={}
 for w,c in p.items():
  for at,(n,j) in enumerate(w):
   ww,sg=canonical(w[:at]+((n,tuple(sorted(j+(mu,)))),)+w[at+1:])
   if sg:out[ww]=out.get(ww,0)+sg*c
 return add(out)
def DD(p,j):
 for mu in j:p=D(p,mu)
 return p
def gradient(p):
 # Derive left gradients from independently formed RIGHT derivatives.
 out={}
 for w,c in p.items():
  total=sum(par[n] for n,j in w)%2
  for at,(n,j) in enumerate(w):
   suffix=sum(par[t] for t,jj in w[at+1:]);sg=(-1)**((par[n]*suffix+par[n]*(total-par[n]))%2);rest=w[:at]+w[at+1:];d=out.setdefault((n,j),{});d[rest]=d.get(rest,0)+sg*c
 return {k:add(p) for k,p in out.items() if add(p)}
def EL(p,domain):
 out={n:{} for n in domain}
 for(n,j),df in gradient(p).items():
  if n in domain:out[n]=add(out[n],scale(DD(df,j),(-1)**len(j)))
 return out
@lru_cache(None)
def qfield(n):return decode_rows(data['master_field_maps'][names[n]])
def Q(p):
 out={}
 for w,c in p.items():
  total=sum(par[n] for n,j in w)%2
  for at,(n,j) in enumerate(w):
   if n not in fields:continue
   suffix=sum(par[t] for t,jj in w[at+1:]);sg=(-1)**(par[n]*suffix+total+par[n]);rest=w[:at]+w[at+1:]
   out=add(out,scale(mul({rest:c},DD(qfield(n),j)),sg))
 return out
def Hess(p):
 # Direct second jet gradient, h and k on the left in their derived order.
 out={}
 for(i,I),first in gradient(p).items():
  if i not in fields:continue
  for(j,J),second in gradient(first).items():
   if j in fields:out=add(out,mul(elem(Hof[i],I),elem(Kof[j],J),second))
 return out
@lru_cache(None)
def numeric_cells(expression):
 out={}
 for term in s.Add.make_args(s.expand(expression)):
  powers=term.as_powers_dict();xp=int(powers.get(xi,0));hp=int(powers.get(eta,0));rest=s.cancel(term/(xi**xp*eta**hp));rat,rest=rest.as_coeff_Mul(rational=True);assert rat.is_Rational;number=F(int(rat.p),int(rat.q));mask=0
  for factor in s.Mul.make_args(rest):
   if factor==s.I:mask^=16
   elif factor.is_Rational:number*=F(int(factor.p),int(factor.q))
   else:
    assert factor.is_Pow and factor.exp==s.Rational(1,2) and factor.base.is_Integer and factor.base>0,factor
    value=int(factor.base)
    for bit,prime in enumerate([2,3,5,7]):
     power=0
     while value%prime==0:value//=prime;power+=1
     number*=prime**(power//2)
     if power%2:mask^=1<<bit
    assert value==1
  out[xp,hp,mask]=out.get((xp,hp,mask),F(0))+number
 return tuple((k,v) for k,v in sorted(out.items()) if v)
def summary(p):
 coeff={}
 for w,c in p.items():
  for(gp,),v in s.Poly(s.expand(c),g).terms():
   if v:coeff[gp,w]=numeric_cells(v)
 h=sha256();h.update(b'[')
 for at,((gp,w),co) in enumerate(sorted(coeff.items())):
  if at:h.update(b',')
  row=[gp,[[names[n],list(j)] for n,j in w],[[list(k),str(v)] for k,v in co]];h.update(json.dumps(row,separators=(',',':'),ensure_ascii=True).encode())
 h.update(b']');return {'positions':len(coeff),'sha256_exact_cells':h.hexdigest()}
print('STAGE independent full_type_domain_and_source_probe_calculus',flush=True)
T={'A':(1,0),'B':(1,0),'x':(1,0),'L':(2,0),'a':(1,-1),'C':(1,1)};patterns=[]
for count in range(1,4):
 for word in combinations_with_replacement(sorted(T),count):
  dim=sum(T[t][0] for t in word)
  if dim>3 or sum(T[t][1] for t in word)!=-1:continue
  for jets in range(4-dim):
   if(sum(t in ['A','B'] for t in word)+jets)%2==0:patterns.append([list(word),jets,3-dim-jets])
assert sorted(patterns)==[a['fixtures']['light_'+str(i)]['pattern'] for i in range(11)]
current_terms=probe_derivatives=0;field_checks=0
for label,fx in a['fixtures'].items():
 L=unpack(fx['L']);qL=Q(L);assert qL==unpack(fx['qL']) and not Q(qL),label
 def kind(n):
  name=names[n]
  if name.startswith(('bar','ub')):return 'a'
  if name.startswith(('L','b')):return 'L'
  if name.startswith('x_'):return 'x'
  return name[0]
 for word in L:
  assert all(n not in sources for n,j in word)
  assert sorted(kind(n) for n,j in word)==fx['pattern'][0] and sum(len(j) for n,j in word)==fx['pattern'][1]
  assert any(names[n].startswith('ub' if label.startswith('heavy') else 'bar') for n,j in word)
 Gu=mul(elem(u),L);Fr=mul(elem(rho),L);Fu=mul(elem(u),qL);assert Q(Fr)==scale(mul(elem(rho),qL),-1) and not add(Q(Fu),Q(Fr),mul(elem(rho),qL))
 eu=EL(Gu,fields);flow={i:scale(eu[i],-(-1)**par[i]) for i in fields};assert {names[Jof[i]]:v for i,v in flow.items() if v}=={n:unpack(p) for n,p in fx['source_shift'].items()}
 raw=add(*(mul(flow[i],qfield(i)) for i in fields if flow[i]));jj=[unpack(p) for p in fx['source_shift_currents']];assert not add(Fu,scale(raw,-1),scale(add(*(D(jj[mu],mu) for mu in range(4))),-1))
 for current in jj:current_terms+=len(current)
 # Independently reconstruct the order<=2 integration-by-parts current.
 pred=[{} for mu in range(4)]
 for(n,I),df in gradient(Gu).items():
  if n not in fields:continue
  if len(I)==1:pred[I[0]]=add(pred[I[0]],mul(qfield(n),df))
  elif len(I)==2:
   mu,nu=I;pred[nu]=add(pred[nu],mul(D(qfield(n),mu),df));pred[mu]=add(pred[mu],scale(mul(qfield(n),D(df,nu)),-1))
  else:assert not I
 assert pred==jj,label
 hr=Hess(Fr);hu=Hess(Fu);assert summary(hr)==fx['whole_rho_Hessian'] and summary(hu)==fx['whole_u_Hessian'],label
 op=EL(hr,Hd);assert {names[n]:summary(v) for n,v in op.items() if v}==fx['rho_functional_Hessian']
 op0=EL(Hess(L),Hd);diff={n:add(op[n],scale(mul(elem(rho),op0[n]),-(-1)**par[n])) for n in Hd}
 assert sum(summary(v)['positions'] for v in diff.values())==fx['derivative_rho_operator_terms']
 assert all(any(n==rho and j for n,j in word) for v in diff.values() for word in v)
 er=EL(Fr,fields);ee=EL(Fu,fields)
 assert {names[Jof[i]]:summary(v) for i,v in er.items() if v}==fx['rho_source_Eulers']
 assert {names[Jof[i]]:summary(v) for i,v in ee.items() if v}==fx['u_source_Eulers']
 assert all(any(n==rho for n,j in w) for v in er.values() for w in v) and all(any(n==u for n,j in w) for v in ee.values() for w in v)
 probe_derivatives+=fx['derivative_rho_operator_terms'];field_checks+=643
assert probe_derivatives>0 and current_terms>0 and field_checks==22*643
print('STAGE independent marked_domain_support_and_Nielsen_controls',flush=True)
effective={('B','B'):2,('B','L'):1,('B','x'):1,('L','B'):1,('x','B'):1,('x','x'):0,('C','a'):2,('a','C'):2};assert [[i,j,v] for(i,j),v in sorted(effective.items())]==a['dressed_IR_edges']
tangent=[('B','C',-1),('C','B',-1),('a','L',0),('L','a',0)];one={}
for(i,k),v in effective.items():
 for a0,b0,w in tangent:
  if k!=a0:continue
  for(kk,j),z in effective.items():
   if kk==b0:one[i,j]=max(one.get((i,j),-1000),v+w+z)
assert max(one.values())==3
assert max(v+w+z for(i,k),v in one.items() for a0,b0,w in tangent if k==a0 for(kk,j),z in effective.items() if kk==b0)==4
# Fresh direct Berezin completion and determinant derivative with nonzero means.
x,beta,t=s.symbols('x beta t',real=True);U=1+x;D0=beta-U*U;Gxx=1/D0;Gbx=-U/D0;controls=[]
for h,point,expected in [(x,{x:1,beta:9},s.Rational(-9,10)),(x*x/2,{x:2,beta:16},s.Rational(-8,21))]:
 mixed=-Gxx/U;IL=s.diff(h,x,2)*Gxx/2+s.diff(h,x)*mixed;Iq=beta*s.diff(h,x,2)*Gxx/2+s.diff(h,x)*Gbx-s.diff(h,x)/U
 f=x+x*x/2+t*h;response=s.diff(s.log(beta*s.diff(f,x,2)-s.diff(f,x)**2)/2-s.log(s.diff(f,x)),t).subs(t,0)
 assert s.cancel(response-Iq)==0 and s.cancel(beta*IL-Iq)==0 and s.cancel(Iq.subs(point))==expected and IL.subs(point)!=0
 assert s.cancel((s.diff(h,x,2)*Gxx/2-IL).subs(point))!=0
 controls.append([str(s.cancel(IL.subs(point))),str(expected)])
assert controls==[[z['I_L_over_a'],z['I_qL']] for z in a['gaussian_controls']]
assert a['local_probe_only_no_constant_strength_unit_probe_limit'] and not a['full_QAP_A5_E5_physical_or_universal_cohomology_claim']
result={'schema':'SOURCEFREE_PRIMITIVE_PROBE_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':a['scientific_disposition'],'both_complete_native_routes_match':True,'all11_carriers_and22_light_heavy_fixtures_reconstructed':True,'all22_qL_source_shifts_currents_and_Hessians_independently_verified':True,'rho_and_u_source_Eulers_zero_complements_and_probe_jets_retained':True,'all643_field_flow_corrections_zero_from_actual_sourcefree_support':True,'actual_unlabeled_sector_225_tangents_and_joint_trace_extension_reviewed':True,'same_lifted_Stokes_finite_map_and_extended_Nielsen_derivation_reviewed':True,'order_hbar_correlated_replacement_and_actual_residue_scope_reviewed':True,'independent_nonzero_Berezin_and_determinant_controls':controls,'new_failed_native_workers':0,'new_failed_verifier_workers':1,'prelaunch_tool_edit_request_rejection_preserved':1,'new_actual_L_or295_vector_amplitudes_measured':False,'fullQAP_A5_E5_all_order_or_physical_scheme_qualified':False,'authority_changed':False,'shared_limits':['Same action,old reference/trace/Stokes and master proofs.','Python/SymPy and AI authorship;no external expert,Lean or experiment.'],'verifier_seconds_after_imports':time.perf_counter()-tick}
print('VALIDATION '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
