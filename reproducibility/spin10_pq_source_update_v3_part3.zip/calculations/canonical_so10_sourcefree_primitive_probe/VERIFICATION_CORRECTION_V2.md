# Independent verifier integer-parity correction

The first verifier stopped before a receipt because Python (-1)**(-1)
created a Float in its right-to-left derivative sign conversion. V2 takes
the exponent modulo2 first. Every coefficient remains exact; mathematical
requirements and native sources/results are unchanged. Old verifier source,
frozen preparation and full failed capture are preserved. One failed verifier
is excluded from qualification. Completed native routes are not repeated.
