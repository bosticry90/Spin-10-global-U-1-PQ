# Source-free primitive probe and quantum replacement V1

SPP1 asks whether the complete actual-L carrier domain from V333 admits a
common one-loop one-probe/first-Slavnov-descendant construction and the
correlated order-hbar replacement. It applies to L=H(R-QK) without extracting
its unmeasured component tensor. Baseline c4af92b5/main; previous turn PROGRESS.

Use the same643 fields/643 sources/48 backgrounds, full Cartesian variables,
ordinary jets, polynomial g/widths/dimensional coefficients, fixed metric
lift and physical real structure. L has project grade(3,-1,odd), standard
dimension4 and no BV source. The17 typed patterns have11 even-Lorentz
carriers, not11 independent invariant counterterms. Arbitrary tensors satisfy
the actual reality/background conditions; component fixtures test signs.
External tests u even(0,0) and rho odd(1,1) in project grade have standard
dimension0. Neither is integrated or a new canonical pair. The bookkeeping
differential du=rho, drho=0 is not a changed physical BRST law.

Freeze record, derivation, code/controller and own-role inputs before native
execution. Two sequential distinct routes:120s after imports,8GiB sampled
private memory,350MiB launch commit floor. Separate verifier:180s, same memory
and floor. Package cap8MiB. Preserve full failures/captures. No truncation,
silent cap growth, old loop replay or Gamma expansion.

Construct S_u=S+integral u*qL and S_ext=S_u+integral rho*L. Derive the extended
master identity with local tests and all currents. The negative canonical
source shift A_J=-(-1)^p Euler_left,z(uL) fixes all integrated fields. Retain
Du,D2u and derivative-rho Hessian/source companions. Check all11 structures
with light/heavy actual-field fixtures and distinct odd factors in a*a*C.
Use prefix versus left-gradient variations and independent polarized versus
functional Hessian checks. The analytic proof is uniform in coefficient
tensors; finite fixtures do not exhaust color components.

Establish SAME T_kappa applicability. Every new Hessian/source-Euler monomial
retains a probe/jet. The unlabeled quadratic sector and225 constant field
tangents stay unchanged. Extend the qualified constant-chain, joint-routing,
smoothing and first-Q bounds explicitly. Retain physical/source Euler
programs, Gamma_ref[A], finite heat/power/first-D-jet terms, nonlocal remainders
and UV-finite-part-before-IR order. No unit constant-u/physical-vacuum
diagonal, second independent Q insertion or arbitrary QAP theorem.

Acceptance: construct [L]_kappa from the full left rho derivative and prove
delta_u Gamma|0=(Gamma,[L]_kappa),
I_qL=(Gamma1,L)+(S,I_L)
through one loop and first probe order. Keep operator ordering, contacts and
currents. Do not fit a finite coefficient or equate kappa,b0,IR constants.
Explain the correlated order-hbar replacement without nonlinear mean-field
source substitution or a global integrated-field map. Classical integrated
field flow is zero; earlier nonzero fullK/ghost-rescaling Jacobians remain.

Use nonzero finite BRST-Gaussian/Berezin controls for a*x and a*x*x. Compare
determinant response with whole connected insertion. Controls detect omitted
mixed covariance, wrong ghost/source signs, missing probe derivatives/current
and erased IR labels. Disclose insensitive projections. Separate verification
imports no new native helper and reviews the analytic domain/lift proof.
Shared action, upstream proofs, software and AI authorship limit independence;
no Lean, human or empirical endorsement. Track B records selection/failures;
education remains voluntary and nonblocking.

Possible outcomes are a bounded full-carrier first-probe replacement, a
precise domain/contact gap, or incompatibility with complete inputs. No
protected E5/A5 promotion, universal minimal cohomology, all-order stability,
intrinsic/induced quotient equality or physical equivalence follows.
No scheme/action/state/policy/benchmark adoption, old-evidence edit, push,
publication or blocked-stage activation. State113/34of39/sevenfalse, HB1/C5
blocked, flavor paused, C1_GS gap, quartet failure,140percent singlet warning,
matching gap and custodyexit2/seven remain. Whole goal stays active.

Primary methodological references: Quadri, Canonical Flow in the Space of
Gauge Parameters, arXiv:1412.6772 sections2.2-3,
https://arxiv.org/html/1412.6772 ; Gambino/Grassi, hep-ph/9907254,
https://arxiv.org/abs/hep-ph/9907254 . These supply the standard enlarged
Slavnov/Nielsen framework, not applicability to this heat prescription or a
Spin(10) physical-observable theorem. The model-specific derivation controls
that applicability. No generic physical-pole result is imported.
