"""Read-only predecessor authentication, then exclusive prospective freeze."""
from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/threshold-exact-once-v1-2026-10-20')
BASE='a1a9d6cc23018e502a2cc61e72111d11c7017be4'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='main'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).strip()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT).strip()
def write(p,b):
    with p.open('xb') as f:f.write(b)
deps={}
for d,prep in [('canonical_so10_heavy_tadpole_bridge','validation_preparation_v4.json'),
               ('canonical_so10_finite_counterterm_insertion','validation_preparation_v5.json')]:
    p=CAL/d/prep;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
    for n,h in json.loads(p.read_bytes())['input_sha256'].items():
        assert sha256(Path(n).read_bytes()).hexdigest()==h,n
        if n in deps:assert deps[n]==h
        deps[n]=h
direct=['AGENTS.md','CHARTER.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md',
        'docs/SOLO_REVIEW_POLICY_V1.md','docs/RESEARCH_EXECUTION_HANDOFF_V396.md',
        'docs/ai_research_epistemic_ladder_v1/AI_RESEARCH_EPISTEMIC_LADDER_V1.md']
for d,files in [
 ('canonical_so10_finite_counterterm_insertion',['DERIVATION.md','RECORD.md','validation_receipt_v5.json','primary_v3_result.json','replay_v3_result.json','primary_v3_tables.json.gz','replay_v3_tables.json.gz']),
 ('canonical_so10_heavy_tadpole_bridge',['DERIVATION.md','RECORD.md','validation_receipt_v4.json','primary_v3_result.json','replay_v3_result.json','primary_v3_tables.json.gz','replay_v3_tables.json.gz']),
 ('canonical_so10_one_soft_factorization',['DERIVATION.md','validation_receipt_v4.json']),
 ('canonical_so10_width_hard_projection',['primary_tables.json.gz','replay_tables.json.gz','validation_receipt.json']),
 ('canonical_so10_background_threshold_inputs',['primary_tables.json.gz','replay_tables.json.gz','DERIVATION.md','RECORD.md','validation_receipt_v2.json'])]:
    direct += ['calculations/'+d+'/'+f for f in files]
pk='tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/'
direct += [pk+f for f in ['export_a10_e5_antighost_vector.py','export_a10_e5_vector_ghost_closed_controls_v3.py','export_a10_e5_vector_ghost_closed_actual_v3.py']]
direct += ['tools/pole_blind_validation_guard/sitecustomize.py']
for name in direct:
    p=ROOT/name;deps[str(p)]=sha256(p.read_bytes()).hexdigest()
for name in ['prepare.py','run.py','assemble.py','verify.py','RECORD.md','DERIVATION.md']:
    p=HERE/name;b=p.read_bytes()
    if p.suffix=='.py':ast.parse(b,filename=str(p))
    write(HERE/(name+'.source.txt'),b);deps[str(p)]=sha256(b).hexdigest()
    deps[str(HERE/(name+'.source.txt'))]=sha256(b).hexdigest()
state='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
receipts={
 'canonical_so10_finite_counterterm_insertion/validation_receipt_v5.json':'8001162677d2281016e3fb7ef8da53b91dd788fa82feec673f38b91becd156d7',
 'canonical_so10_heavy_tadpole_bridge/validation_receipt_v4.json':'3b77d2f5bd1d93ce5f0cc55b12a06e36ad00cf88d748e3ca284b9a6752b4fa00',
 'canonical_so10_one_soft_factorization/validation_receipt_v4.json':'3612bc3db506239b90101c5b8b511243c7e8e2aa5581de3f2b5ac24018e427fe'}
for n,h in receipts.items():assert sha256((CAL/n).read_bytes()).hexdigest()==h
old=subprocess.check_output(['git','ls-tree','-r',BASE],cwd=ROOT);assert len(old.splitlines())==25317
write(CONTROL/'old_git_tree.txt',old)
value={'schema':'C1_EXACT_ONCE_PREPARATION_V1','base_commit':BASE,'scientific_acceptance':'NOT_PERFORMED',
       'input_sha256':dict(sorted(deps.items())),'state_sha256':state,
       'limits':{'native_seconds':120,'verifier_seconds':180,'private_sample_limit':8*1024**3,'launch_floor':350*1024**2,'new_package_bytes':1024**2}}
write(HERE/'preparation.json',(json.dumps(value,sort_keys=True,indent=2)+'\n').encode())
print('FROZEN',len(deps),'bindings; old blobs25317; no science executed')
