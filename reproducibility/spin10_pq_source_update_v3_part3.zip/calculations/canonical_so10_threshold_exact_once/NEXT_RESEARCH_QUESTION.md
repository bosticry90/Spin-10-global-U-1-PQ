# Next: one complete VVVV primitive, with its zero-mass assignments accounted for

EAT1 supplies the known FCI1+HTB1 sub-sum and the complete quartic color-pair
support, not the primitive amplitude. Do not repeat the completed assemblies
or remove FCI1's poles by counting the tadpole CT a second time.

The least expensive next test is the factorized VVVV doublebubble with the
actual BFT1 quartic density and all eight background placements. Derive its
covariant coincident vector-propagator expansion through F2, retaining orbital
and spin terms and D=4-2eps multiplicities. Use the actual H-charge matrices
and all five mass projectors, not W_rs alone: coarse color support cannot
determine the curvature-inserted contractions. No new 328^4 scalar expansion
is needed to start this family.

Before presenting a finite COMPLETE family, account for both massive and
zero-mass assignments. The latter may yield factorized scaleless hard-region
integrals, but their UV/IR poles, power-sensitive soft terms and products with
epsilon-dependent hard terms need an explicit disposition compatible with
OSF1 and the common EFT construction. A positive-mass heat-boundary argument
does not apply automatically at mass0. An auxiliary IR mass is a diagnostic,
not a new physical mass or an adopted IR prescription.

Prefer a collective Schwinger/heat expression or a complete external-momentum
reduction over convenient massive components. Keep the pole and finite parts
of every required master through the epsilon orders induced by subdivergences.
If the necessary common subtraction is underdefined, identify the precise
missing condition and the complete expression it affects; do not promote a
massive-only result or call it an anomaly. A genuinely complete weighted
primitive contribution, or a precise demonstrated missing premise, is the
next meaningful outcome.

Preserve f_fin and finite parameter/reference conditions symbolically, xi1 as
the current reference, unknown extra CTs/local2loop background CT and nonlinear
matching conversion. Keep the original causal/QAP work in its qualified scope;
no reason to reopen it without a new dependency. No matter/flavor activation,
benchmark refit, scientific promotion, push/publication or foundation change.
