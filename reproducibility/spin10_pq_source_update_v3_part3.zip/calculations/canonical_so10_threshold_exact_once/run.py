"""Freeze-aware sequential owned execution with complete captured failures."""
from pathlib import Path
from hashlib import sha256
import json,sys
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CONTROL=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/threshold-exact-once-v1-2026-10-20')
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
def dump(p,x):
    with p.open('xb') as f:f.write((json.dumps(x,sort_keys=True,indent=2)+'\n').encode())
def auth(prep):
    for name,h in prep['input_sha256'].items():assert sha256(Path(name).read_bytes()).hexdigest()==h,name
def resource(c):
    assert c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed']
    assert c['post_run_observations_qualified'] and c['private_allocation_limit_bytes']==8*1024**3
    assert c['launch']['memory']['available_pagefile']>=350*1024**2
    assert c['all_resource_samples'] and all(0<x['private_bytes']<=8*1024**3 for x in c['all_resource_samples'])
def one(role,script,args):
    c=capture([sys.executable,'-B',str(HERE/script),*args])
    dump(HERE/(role+'_capture.json'),c);dump(CONTROL/(role+'_full_capture.json'),c)
    if c['execution_state']!='COMPLETED':print(c['stdout_and_stderr'],flush=True)
    resource(c)
    rows=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rows)==1
    value=rows[0];assert value['elapsed_after_imports']<(180 if role=='validation' else 120)
    dump(HERE/('validation_receipt.json' if role=='validation' else role+'_result.json'),value)
    print(role,'COMPLETED',value['elapsed_after_imports'],flush=True)
prep=json.loads((HERE/'preparation.json').read_bytes());auth(prep)
if sys.argv[1]=='native':
    one('primary','assemble.py',['primary']);one('replay','assemble.py',['replay'])
else:
    assert sys.argv[1]=='validate'
    names=list(map(Path,prep['input_sha256']))+[HERE/'preparation.json']
    for role in ['primary','replay']:
        c=json.loads((HERE/(role+'_capture.json')).read_bytes());resource(c)
        names += [HERE/(role+'_capture.json'),HERE/(role+'_result.json')]
    vp={'schema':'C1_EXACT_ONCE_VALIDATION_PREPARATION_V1',
        'input_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in sorted(set(names))}}
    dump(HERE/'validation_preparation.json',vp);auth(vp);one('validation','verify.py',[])
