"""Two distinct assemblies from qualified bytes; no predecessor worker runs."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import gzip,json,os,sys,threading,time
import sympy as s
import mpmath as mp

ROOT=Path(__file__).resolve().parents[2]; HERE=Path(__file__).resolve().parent
CAL=ROOT/'calculations'
read=lambda p:json.loads(p.read_bytes())
packed=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def matrix(x):
    return s.SparseMatrix(*x['shape'],{(i,j):s.sympify(v) for i,j,v in x['entries']})
def fmt(x):return mp.nstr(x,50)
def eq(a,b):
    assert abs(a-b)<mp.mpf('1e-40')*(1+abs(a)),(a,b)

def polynomial(role):
    fci=read(CAL/'canonical_so10_finite_counterterm_insertion'/f'{role}_v3_result.json')
    htb=read(CAL/'canonical_so10_heavy_tadpole_bridge'/f'{role}_v3_result.json')
    out={}; pieces={}
    if role=='primary':
        for n in [-2,0,2,4]:
            out[str(n)]={}
            for key in ['pole','constant','scale_log','coupling_log']:
                out[str(n)][key]=[mp.mpf(fci['coefficients'][str(n)][key][a])+
                    (mp.mpf(htb['coefficients'][str(n)][key][a]) if key!='pole' else 0) for a in range(3)]
    else:
        # Replay uses exact rational arithmetic on the finite decimal inputs,
        # reconstructs the CT pieces and convolves maps with tadpole leaves.
        F=lambda z:Fraction(str(z)); z=Fraction(0)
        T=htb['tadpole_coefficients'];maps=htb['finite_tadpole_linear_maps'];p=fci['pieces']
        for n in [-2,0,2,4]:
            row={k:[z]*3 for k in ['pole','constant','scale_log','coupling_log']}
            for a in range(3):
                if n>=0:
                    j=n//2
                    row['pole'][a]+=F(p['physical_pole'][j][a])
                    row['constant'][a]+=F(p['physical_constant'][j][a])
                if n<=2:
                    j=(n+2)//2
                    row['pole'][a]+=F(p['Goldstone_potential_pole'][j][a])
                    row['coupling_log'][a]-=F(p['Goldstone_potential_pole'][j][a])
                    row['constant'][a]+=F(p['Goldstone_potential_constant'][j][a])
                if n==2:
                    row['pole'][a]+=F(p['vector_pole'][a]);row['coupling_log'][a]-=F(p['vector_pole'][a])
                    row['constant'][a]+=F(p['vector_constant'][a])
                row['scale_log'][a]=row['pole'][a]
                for power in [0,-2]:
                    tn=str(n-power)
                    if tn in T:
                        for key in ['constant','scale_log','coupling_log']:
                            row[key][a]+=sum((F(maps[str(power)][a][i])*F(T[tn][key][i]) for i in range(3)),z)
            out[str(n)]={k:[mp.mpf(x.numerator)/x.denominator for x in v] for k,v in row.items()}
    for n in [-2,0,2,4]:
        for key in out[str(n)]:
            for a in range(3):
                expected=mp.mpf(fci['coefficients'][str(n)][key][a])
                if key!='pole':expected+=mp.mpf(htb['coefficients'][str(n)][key][a])
                eq(out[str(n)][key][a],expected)
    assert any(x for row in out.values() for x in row['pole'])
    return {n:{k:list(map(fmt,v)) for k,v in row.items()} for n,row in out.items()},htb['finite_tadpole_linear_maps']

def color(role):
    b=packed(CAL/'canonical_so10_background_threshold_inputs'/f'{role}_tables.json.gz')
    wh=packed(CAL/'canonical_so10_width_hard_projection'/f'{role}_tables.json.gz')
    P=list(map(matrix,wh['projectors']));assert wh['eigenvalues']==['0','3/10','3/2','25','253/10']
    for r,X in enumerate(P):
        assert X==X.T and X*X==X and s.trace(X)==wh['ranks'][r]
        for Y in P[:r]:assert X*Y==s.zeros(45)
    assert sum(P,s.zeros(45))==s.eye(45)
    supplied={(a,c,e):s.sympify(v) for a,c,e,v in b['f']}
    if role=='primary':
        F=[s.SparseMatrix(45,45,{(a,c):v for (a,c,k),v in supplied.items() if k==e}) for e in range(45)]
        W=s.zeros(5)
        for e,F0 in enumerate(F):
            A=[X*F0 for X in P]
            for r in range(5):
                for t in range(5):W[r,t]-=s.trace(A[r]*A[t])
    else:
        pairs=[(i,j) for i in range(10) for j in range(i+1,10)]
        hh=[s.SparseMatrix(10,10,{(i,j):1/s.sqrt(2),(j,i):-1/s.sqrt(2)}) for i,j in pairs]
        independent={}
        # Recover all bracket coefficients in the orthonormal plane basis.
        for a in range(45):
            for c in range(45):
                B=hh[a]*hh[c]-hh[c]*hh[a]
                for (i,j),v in B.todok().items():
                    if i<j:independent[(a,c,pairs.index((i,j)))]=s.expand(s.sqrt(2)*v)
        assert independent==supplied and len(independent)==720
        by_e=[[ (a,c,v) for (a,c,k),v in independent.items() if k==e] for e in range(45)]
        W=s.zeros(5)
        for terms in by_e:
            for a,c,v in terms:
                for d,f,u in terms:
                    for r in range(5):
                        if P[r][a,d]:
                            for t in range(5):
                                if P[t][c,f]:W[r,t]+=v*u*P[r][a,d]*P[t][c,f]
    W=W.applyfunc(s.simplify)
    assert W==W.T and all(v>=0 for v in W)
    assert [sum(W[r,t] for t in range(5)) for r in range(5)]==[8*k for k in wh['ranks']]
    assert sum(W)==360
    assert any(W[0,t] for t in range(1,5)),'NO_MIXED_ZERO_MASS_SUPPORT'
    assert W[0,0]!=0
    return {'eigenvalues':wh['eigenvalues'],'ranks':wh['ranks'],
            'color_pair_support':[[str(W[r,t]) for t in range(5)] for r in range(5)],
            'zero_mass_assignments_not_disposed_as_scaleless':True,
            'actual_F2_amplitude_measured':False,'background_words_still_required':8}

def reduction(role):
    e,z,l=s.symbols('eps z ell');r=s.Matrix(s.symbols('R0:2'));t=s.Matrix(s.symbols('t0:2'));c=s.Matrix(s.symbols('c0:2'))
    M=s.Matrix([[5,2],[2,3]]);f=t+c+z*r
    if role=='primary':v=-(f.T*M.inv()*f)[0]/2
    else:
        x=-l*M.inv()*f;v=s.expand(((x.T*M*x)[0]/2+l*(f.T*x)[0])).coeff(l,2)
    actual=s.expand(v).coeff(z,1);expected=-(r.T*M.inv()*(t+c))[0]
    assert s.expand(actual-expected)==0
    assert s.expand(2*actual-expected)!=0 and s.expand(actual/2-expected)!=0 and s.expand(-actual-expected)!=0
    p,b,ff,R0,R1=s.symbols('p barefinite finiteCT R0 R1')
    R=R0+e*R1;bare=p/e+b;ct=-p/e+ff
    assert s.expand(s.expand((bare+ct)*R).coeff(e,0)-R0*(b+ff))==0
    assert s.expand((bare+2*ct)*R).coeff(e,-1)==-R0*p
    assert s.expand(bare*R).coeff(e,0)-(R0*b)==R1*p
    h,cf,ce=s.symbols('h cf ce');assert s.expand(h+cf-(h+cf-ce)-ce)==0
    assert s.expand(h+cf-(h+cf-ce))==ce
    return {'off_diagonal_heavy_reduction_verified':True,'wrong_sign_double_and_half_bridge_detected':True,
            'pole_cancellation_before_finite_part':True,'missing_and_duplicate_tadpole_CT_detected':True,
            'soft_EFT_omission_detected':True,'source_normalization_control':'NOT_APPLICABLE_SOURCE_ZERO_DOMAIN'}

def main():
    role=sys.argv[1];assert role in ['primary','replay'];mp.mp.dps=80
    start=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.start()
    print('STAGE assemble_'+role,flush=True);coeff,maps=polynomial(role)
    print('STAGE color_support_'+role,flush=True);support=color(role)
    controls=reduction(role)
    value={'schema':'C1_EXACT_ONCE_NATIVE_V1','execution_state':'COMPLETED','route':role,
           'coefficients':coeff,'finite_tadpole_linear_maps':maps,'primitive_support':support,'controls':controls,
           'full_C1_or_primitive_amplitude_calculated':False,'finite_normalization_selected':False,
           'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(value,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
