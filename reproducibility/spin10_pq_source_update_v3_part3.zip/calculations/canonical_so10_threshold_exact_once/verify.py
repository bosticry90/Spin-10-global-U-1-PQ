"""Independent assembly audit: fractions, polynomial substitution, norms."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import gzip,json,os,threading,time
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
read=lambda p:json.loads(p.read_bytes())
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def matrix(x):return s.SparseMatrix(*x['shape'],{(i,j):s.sympify(v) for i,j,v in x['entries']})
def near(x,y):
    assert abs(x-y)<mp.mpf('1e-40')*(1+abs(x)),(x,y)
def rat(x):
    q=F(str(x));return mp.mpf(q.numerator)/q.denominator
def numeric(M):
    return mp.matrix([[mp.mpf(str(s.N(M[i,j],85))) for j in range(M.cols)] for i in range(M.rows)])

def audit_coefficients(role,native):
    ct=read(CAL/'canonical_so10_finite_counterterm_insertion'/f'{role}_v3_result.json')
    ht=read(CAL/'canonical_so10_heavy_tadpole_bridge'/f'{role}_v3_result.json')
    p=ct['pieces']; t=ht['tadpole_coefficients'];maps=ht['finite_tadpole_linear_maps'];z=F(0)
    for power in [-2,0,2,4]:
        for a in range(3):
            c={key:z for key in ['pole','constant','scale_log','coupling_log']}
            if power>=0:
                c['pole']+=F(p['physical_pole'][power//2][a]);c['constant']+=F(p['physical_constant'][power//2][a])
            if power<=2:
                j=(power+2)//2;q=F(p['Goldstone_potential_pole'][j][a])
                c['pole']+=q;c['coupling_log']-=q;c['constant']+=F(p['Goldstone_potential_constant'][j][a])
            if power==2:
                q=F(p['vector_pole'][a]);c['pole']+=q;c['coupling_log']-=q;c['constant']+=F(p['vector_constant'][a])
            c['scale_log']=c['pole']
            for k in [0,-2]:
                tp=str(power-k)
                if tp in t:
                    for key in ['constant','scale_log','coupling_log']:
                        c[key]+=sum((F(maps[str(k)][a][i])*F(t[tp][key][i]) for i in range(3)),z)
            for key,val in c.items():near(rat(val),mp.mpf(native['coefficients'][str(power)][key][a]))
    # Direct predecessor sum is separately retained, not replaced by convolution.
    for power in [-2,0,2,4]:
        for key in ['pole','constant','scale_log','coupling_log']:
            for a in range(3):
                val=rat(ct['coefficients'][str(power)][key][a])
                if key!='pole':val+=rat(ht['coefficients'][str(power)][key][a])
                near(val,mp.mpf(native['coefficients'][str(power)][key][a]))
    for k in ['0','-2']:
        for a in range(3):
            for i in range(3):near(mp.mpf(maps[k][a][i]),mp.mpf(native['finite_tadpole_linear_maps'][k][a][i]))

def field_translation():
    ht=packed(CAL/'canonical_so10_heavy_tadpole_bridge/primary_v3_tables.json.gz')
    hr=read(CAL/'canonical_so10_heavy_tadpole_bridge/primary_v3_result.json')
    M=matrix(ht['raw_Hessian']);Mi=matrix(ht['raw_Hessian_inverse'])
    assert (M*Mi-s.eye(3)).applyfunc(s.simplify)==s.zeros(3)
    Rm=matrix(ht['Rminus2']);Fm=matrix(ht['Rminus2_tadpole_linear_map'])
    assert (Fm*M+Rm).applyfunc(s.simplify)==s.zeros(3)
    Mn=numeric(M);A=mp.matrix([[mp.mpf(x) for x in row] for row in hr['finite_tadpole_linear_maps']['0']])
    R=mp.matrix([[mp.mpf(x) for x in row] for row in hr['R0']])
    for v in A*Mn+R:near(v,mp.mpf(0))
    # A nonzero raw radial translation detects omission/doubling of its partner.
    u=s.Matrix([1,2,3]);res=Rm*u
    assert any(s.simplify(v)!=0 for v in res)
    return {'all18_finite_tadpole_map_entries_checked':True,'exact_inverse_g2_coordinate_pair_cancels':True,
            'actual_reference_jet_not_identified_with_quantum_shift':True,
            'nonzero_omitted_coordinate_partner_detected':True}

def polynomial_reduction():
    # Substitute the stationary solution in a different 3-dimensional heavy
    # Gaussian, keeping the F2 label as an ordinary polynomial indeterminate.
    ell,z=s.symbols('ell z');M=s.Matrix([[4,1,0],[1,3,1],[0,1,5]])
    t=s.Matrix([2,3,7]);f=s.Matrix([-1,4,2]);R=s.Matrix([3,-2,5]);x=-ell*M.inv()*(t+f+z*R)
    gamma=s.expand((x.T*M*x)[0]/2+ell*((t+f+z*R).T*x)[0])
    got=gamma.coeff(ell,2).coeff(z,1);expect=-(R.T*M.inv()*(t+f))[0]
    assert got==expect and got!=0
    assert got!=2*expect and got!=expect/2 and got!=-expect
    eps=s.Symbol('eps');rp=s.Matrix([11,13,17]);r1=s.Matrix([5,3,1]);pole=s.Matrix([7,2,3])
    total=pole/eps+t-pole/eps+f
    expr=s.expand(-((rp+eps*r1).T*M.inv()*total)[0])
    assert expr.coeff(eps,-1)==0 and expr.coeff(eps,0)==-(rp.T*M.inv()*(t+f))[0]
    for mutant in [pole/eps+t, pole/eps+t-2*pole/eps+f]:
        q=s.expand(-((rp+eps*r1).T*M.inv()*mutant)[0]);assert q.coeff(eps,-1)!=0
    # Keep the lower-order EFT kernel independently defined; omission is nonzero.
    h=s.Matrix([2,4,9]);cf=s.Matrix([1,-2,3]);ce=s.Matrix([7,3,-2]);match=h+cf-ce
    assert h+cf-match-ce==s.zeros(3,1) and h+cf-match!=s.zeros(3,1)
    return {'reduced_stationary_action_matches_two_leaf_term':True,
            'double_half_sign_bridge_and_pole_CT_mutants_detected':True,
            'specified_one_soft_EFT_omission_detected':True}

def color_norms(native):
    wh=packed(CAL/'canonical_so10_width_hard_projection/primary_tables.json.gz')
    b=packed(CAL/'canonical_so10_background_threshold_inputs/primary_tables.json.gz')
    P=[matrix(v) for v in wh['projectors']]
    # Third method: square every entry of the projected antisymmetric matrices.
    by=[{} for _ in range(45)]
    for a,c,e,v in b['f']:by[e][a,c]=s.sympify(v)
    W=s.zeros(5)
    for e,entries in enumerate(by):
        FF=s.SparseMatrix(45,45,entries)
        for r in range(5):
            for t in range(5):
                Z=P[r]*FF*P[t]
                W[r,t]+=sum((v*v for v in Z.todok().values()),s.Integer(0))
    W=W.applyfunc(s.simplify)
    expected=s.Matrix([[s.sympify(v) for v in row] for row in native['primitive_support']['color_pair_support']])
    assert W==expected and W==W.T
    assert [sum(W[r,t] for t in range(5)) for r in range(5)]==[8*k for k in wh['ranks']]
    assert sum(W)==360 and W[0,0]>0 and sum(W[0,t] for t in range(1,5))>0
    # A massive-only table cannot reproduce the complete color support.
    omitted=sum(W[0,t] for t in range(5))+sum(W[r,0] for r in range(1,5))
    assert omitted>0
    return {'all25_pair_entries_and_zeros_checked':True,'projected_Frobenius_route_agrees':True,
            'omitted_zero_mass_color_support':str(omitted),
            'zero_mass_F2_amplitude_or_scaleless_value_inferred':False}

def evanescence():
    tab=packed(CAL/'canonical_so10_finite_counterterm_insertion/primary_v3_tables.json.gz')
    residual=[-sum((s.sympify(tab['vector_indices'][r][a])*s.sympify(tab['vector_fractional_jets'][r]) for r in range(4)),s.Integer(0)) for a in range(3)]
    assert all(z!=0 for z in residual)
    return list(map(str,residual))

def main():
    start=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.start();mp.mp.dps=80
    A=read(HERE/'primary_result.json');B=read(HERE/'replay_result.json')
    print('STAGE independent_assembly',flush=True)
    for role,n in [('primary',A),('replay',B)]:audit_coefficients(role,n)
    for power in A['coefficients']:
        for key in A['coefficients'][power]:
            for a in range(3):near(mp.mpf(A['coefficients'][power][key][a]),mp.mpf(B['coefficients'][power][key][a]))
    assert A['primitive_support']==B['primitive_support']
    translation=field_translation();reduced=polynomial_reduction()
    print('STAGE independent_color_norms',flush=True);color=color_norms(A)
    value={'schema':'C1_EXACT_ONCE_VALIDATION_V1','execution_state':'COMPLETED',
      'status':'QUALIFIED_KNOWN_SUBSUM_EXACT_ONCE_AND_COMPLETE_QUARTIC_COLOR_SUPPORT',
      'scientific_acceptance':'NOT_PERFORMED','scientific_authority':'34/39_UNCHANGED',
      'all48_coefficients_and18_symbolic_tadpole_map_entries_checked':True,
      'field_translation':translation,'heavy_reduction':reduced,'primitive_support':color,
      'dropped_vector_evanescent_constant':evanescence(),
      'predecessor_loops_rerun':False,'finite_scheme_or_vacuum_selected':False,
      'complete_C1_or_primitive_F2_family_measured':False,
      'source_normalization_negative_control':'NOT_APPLICABLE_SOURCE_ZERO_DOMAIN',
      'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(value,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
