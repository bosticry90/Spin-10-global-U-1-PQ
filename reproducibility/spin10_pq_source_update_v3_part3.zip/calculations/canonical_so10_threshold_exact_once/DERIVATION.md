# EAT1: the two expansions must not be conflated

Let Gamma=S+ell F+ell^2 B, F=Gamma1+C1, with C1 the *complete* first-order
local action, not just its quadratic insertion. At tree heavy solution x0(l)
and M=S_xx, solve Gamma_x=0: xhat=x0-ell M^-1 F_x+O(ell^2). Thus

    Gamma_red2 = B(x0,l) - F_x M^-1 F_x/2.

B contains the nine BFT1 full-1PI primitive families, the one-loop insertion
I[C1'']=(1/2)Tr_b G C1'' - Tr_c Gc C1''c and local C2. The full Legendre
transform already removes full-1PR dumbbells. The second displayed term
reintroduces a HEAVY bridge in a light-1PI functional; it is not another
primitive doublebubble or a second Tr(G deltaK). BFT1 and OSF1 fix these signs
and multiplicities independently of the measured threshold.

For the leading local F2 coefficient, HTB1 proves the bridge is the radial
cross term. Write F_x=t_total+R_Gamma F2. With Lambda=-12 Gamma_F2 this is

    Lambda_bridge2 = -R Mraw^-1 (t_fin+f_fin).

The factor1/2 is canceled by two cross orderings. A renormalizable local C1
cannot contain radial-scalar times F2 (dimension5), so its radial derivative
does not supply a second F2 leaf. Scalar singlets have Dbar x0=0; no omitted
bridge background insertions occur at this derivative order in HTB1's domain.
This is a selected heavy local expansion, not arbitrary backgrounds/momenta.

If a bare tadpole is p/eps+t+eps t1 and its correlated CT is -p/eps+f,

    FP[(R0+eps R1+...)(t_bare+t_CT)] = R0(t+f).

The two R1 p terms cancel. An extra -p/eps gives a new pole and spurious finite
term. This cancellation is internal to the bridge. It does NOT cancel FCI1's
remaining full-1PI CT pole. That pole must be retained for primitive/local-CT
subtraction, not canceled against a second copy of the tadpole CT.

An arbitrary *reference* delta v_CT also changes parameters/GF/source maps;
it is not the physical quantum shift -M^-1(t+f). The conditional pure field
coordinate direction is a useful exact check: if a complete insertion has
delta K=(partial_quantum_field K)u, its hard determinant response is R u,
whereas its tadpole changes by M u. Then

    [I_fin + R u] - R M^-1[t+f+M u] = I_fin-R M^-1[t+f].

Keep u distinct from delta v_ref and from the physical shift. This does not
show that FCI1's actual combined pole jet is a pure coordinate translation.
Nor does it fix f or the remaining finite parameter conditions. Full dimensional
equality is used for pole translations before finite-part extraction.

The known sub-sum has the following unambiguous meaning:

    Lambda_known2 = Lambda_FCI,hard + Lambda_HTB,both-hard
       = sum_n g^n [p_n/eps + a_n + b_n L + c_n U]
         + (F0+g^-2 Fminus2) f_fin.

Only the FCI part supplies p_n. Explicitly retain the rest of matching:

    Lambda_match2 = Lambda_known2 + Lambda_primitive,all-hard
       + Lambda_extra_quadratic_CT,hard + D Lambda1,hard[Efinite]
       + Lambda_local_background_CT2 + U_tree/all-soft/reference/EFT.

Here U is a named unresolved remainder, NOT asserted zero. It includes the
common tree/all-soft and background/field matching construction still lacking
a complete proof. The OSF1 specified one-soft block is removed ONLY under its
independently defined bare two-point equality and common regulator:

    Ls[Hh,red+CF]-Ls[Hh,red+CF-CE]-Ls[CE] = 0.

The HTB both-hard bridge excludes the mixed bridge already included in that
reduced Hh,red kernel. FCI hard excludes its separately retained soft jets.
Unknown finite Higgs data are not measured/zeroed to perform this cancellation.
The complete nonlinear Gamma_F2-to-C1 conversion is still outside this sub-sum.
Fixed xi1 is retained; no symbolic-width or gauge-independence result is added.

## What a complete VVVV family must include

Using BFT1's orthonormal generators let (Fe)_ab=f_abe and the complete adjoint
mass projectors P_r, r=(0,3/10,3/2,25,253/10), with masses g^2 lambda_r.
The quartic Wick color-pair support is

    W_rs = sum_e,a,b,c,d f_abe f_cde (P_r)_ac (P_s)_bd
         = -sum_e Tr(P_r Fe P_s Fe)
         = sum_e ||P_r Fe P_s||_F^2 >= 0.

This uses real orthogonal projectors, symmetric Fe^T=-Fe and completeness.
It entails W_rs=W_sr, sum_s W_rs=8 rank(P_r), sum_rs W_rs=360.
Reconstruct f independently from h_ij=(Eij-Eji)/sqrt2 in lexicographic order,
f_abc=-Tr([h_a,h_b]h_c). No H-coordinate norm is substituted for a group index.

This coarse support is not the F2 coefficient. A massive-only heat expansion
would require a separate disposition of every nonzero P0 assignment before
qualifying the complete family. Nonzero support does not exclude cancellation
after all eight background placements/Lorentz terms; no such cancellation is
assumed. If massless hard terms are scaleless in dimensional regularization,
their UV/IR separation and pole-times-epsilon products must still be accounted
for consistently with OSF1 and the common EFT. Actual primitive amplitudes
are not calculated by this support test.

Scientific comparators already examined in OSF1/HTB1: Fuentes-Martin et al,
arXiv2412.12270v2 sections4.1-4.2 (1LPI heavy reduction, gauge caveat), and
Martin-Patel1808.07615 (dimensional bosonic potential comparator). This work
uses their stated roles, not a new imported gauge-fixing action or theorem.
