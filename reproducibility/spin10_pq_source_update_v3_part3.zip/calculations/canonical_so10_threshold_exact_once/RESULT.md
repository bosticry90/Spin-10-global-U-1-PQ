# EAT1 result: the known two-loop sub-sum is assembled without duplication

Qualified bounded evidence; scientific acceptance NOT_PERFORMED. Authority
remains34/39, state113 unchanged. Final receipt SHA256:
`b188a4762725f616b3fcfa8861c59f3805584e4f7c6c35e781e9d93f9be484c9`.
This is not a finite C1_GS result or a measured primitive two-loop amplitude.

The independently calculated FCI1 prescribed-pole hard CT insertion and HTB1
both-hard radial heavy bridge have now been assembled as one explicitly
labelled KNOWN SUB-SUM. With L=log(Q^2/60), U=log(g10^2), ell=hbar/(16pi^2),
and Lambda=-12 Gamma_F2, it is

    Lambda_known2 = sum_{n=-2,0,2,4} g10^n [p_n/eps+a_n+b_n L+c_n U]
                   + (F0+g10^-2 Fminus2) f_fin.

All48 scalar coefficients and the18 entries in the finite-tadpole maps are
in primary_result.json/replay_result.json. They are supplied to50 decimal
digits; the finite-data precision and shared assumptions are inherited, not
replaced by a rigorous uncertainty bound. No g, Q or f value was selected.
The remaining poles are exactly FCI1's poles: the renormalized bridge does
not remove them. They still need the primitive/local-CT assembly. No partial
numerical vector is compared with the historical gauge mismatch.

Primary adds authenticated predecessor polynomials at80 digits. Replay
reconstructs FCI1 from its physical, gauge-orbit-potential and vector pieces,
and constructs HTB1 by convolving the tadpole polynomial with its two finite
maps, using rational arithmetic on the supplied decimals. Separate validation
checks both against both predecessor roles at scaled1e-40. No old loop or
large scalar tensor calculation was rerun.

## The operations are now distinguished by topology and order

For Gamma=S+ell F+ell^2 B, quantum heavy elimination gives
Gamma_red2=B-F_x M^-1 F_x/2. B contains full-1PI primitive skeletons,
Tr(G deltaK) and local C2. The bridge is an additional heavy-reduced1LPI
contribution, not another primitive doublebubble. At F2 its two cross
orderings produce -R Mraw^-1(t_fin+f_fin), with no remaining1/2.

The tadpole's pole CT cancels its own bare pole BEFORE multiplication by
the epsilon-dependent F2 leaf. Thus the two pole-times-epsilon terms cancel.
Counting that CT again creates a new pole and an artificial finite remainder.
This internal bridge cancellation is distinct from the remaining FCI1 poles.

An explicitly correlated coordinate direction gives a further check:
Efinite -> Efinite+(partial_quantum_field K)u and f_fin -> f_fin+Mraw u.
The insertion shifts by +R u, the bridge by -R u. Their sum is unchanged.
All18 actual map entries were checked; the inverse-g2 part cancels exactly
over Q(sqrt15), and the remaining part passes the frozen precision bound.
This is a conditional bookkeeping identity. It does not assert that the
actual reference-VEV pole jet is this direction or identify it with a physical
quantum vacuum shift. No general inverse-g cancellation is established.

OSF1's independently defined common one-soft block remains a conditional
exact zero including its reduced hard kernel and both UV/EFT CTs. Its mixed
heavy bridge is already part of that kernel and is not added to HTB1 again.
FCI1's soft jets likewise remain outside its hard sub-sum. The complete
tree/all-soft EFT construction is still unresolved; no massless/scaleless
shortcut supplies it.

The full threshold still needs primitive all-hard graphs, extra quadratic
CTs, finite parameter/reference jets, the local two-loop background CT,
common tree/all-soft/EFT matching and the nonlinear Gamma_F2-to-C1 conversion.
DERIVATION names these remaining contributions rather than assigning them0.
All new calculations retain the frozen xi1 reference. This is not a global
gauge-width independence test or a symbolic arbitrary-width result.

## The next primitive family has genuine massless support

The complete quartic color contraction W_rs was calculated using all720
structure-constant entries and all five adjoint mass projectors. In mass order
(0,3/10,3/2,25,253/10), with masses g10^2 times these values:

| r / s | 0 | 3/10 | 3/2 | 25 | 253/10 |
| --- | ---: | ---: | ---: | ---: | ---: |
| 0 | 30 | 54/5 | 0 | 30 | 126/5 |
| 3/10 | 54/5 | 14 | 16/5 | 18 | 18 |
| 3/2 | 0 | 16/5 | 0 | 0 | 24/5 |
| 25 | 30 | 18 | 0 | 30 | 18 |
| 253/10 | 126/5 | 18 | 24/5 | 18 | 30 |

Primary uses -sum_e Tr(P_r F_e P_s F_e). Replay rebuilds all ten-plane Lie
brackets independently and contracts their tensor entries. The separate
verifier uses sum_e ||P_r F_e P_s||_F^2. All25 entries and zero complements
agree exactly. Symmetry, orthogonal projectors, row sums8 rank(P_r) and
total360 hold. Omitting every zero-mass assignment loses color weight162;
this is an algebraic weight, not an amplitude or a completion percentage.

This support is necessary information for the complete VVVV primitive family,
not its F2 coefficient. The first row has nonzero mixed massless/heavy
couplings. A massive-only calculation cannot stand for this entire support.
All eight labelled background placements and Lorentz terms must still be
evaluated; some support could cancel there. This result neither proves a
nonzero massless F2 term nor assigns a scaleless hard integral a finite value.
The next bounded task must retain its UV/IR disposition before qualifying a
complete finite family.

## Validation and limitations

The exact heavy elimination is checked by completing the Gaussian square
and separately substituting its stationary solution, including an off-diagonal
heavy Hessian. Negative controls detect double/half/reversed bridge, missing
and duplicated tadpole CT, omission of the specified EFT partner, loss of a
nonzero coordinate partner and omission of zero-mass color support. The actual
FCI1 vector evanescent finite term is retained; removing it changes the three
coefficients by (-171046/759,-37534/253,-101380/759), up to mutant orientation.
No source-normalization control is claimed in this source-zero calculation.
No new power-divergence finite coefficient was measured; that remains part of
the pending primitive analysis, rather than a successful new negative control.

All scientific workers exited0; no failed scientific worker/verifier run.
Preparations2097/2102 bindings; native times after imports1.2411169s and
.8132857s, verifier1.2609348s. Sample counts2/1/2, maximum observed private
allocation51,277,824 bytes, NOTpeak. The replay's single startup observation
does not bound its unobserved peak. Limits120s native/180s verifier, sampled
8GiB private,350MiB launch floor,1MiB package remained in force. Full owned
captures and frozen source copies are preserved. Multiple implementations
share action, projectors, finite inputs, libraries and AI analyst. Their
agreement is bounded computational corroboration, not external, Lean or
experimental validation of the physics.

Track B's useful result is exact assembly plus a model-specific completeness
check that rules out claiming a massive-only subset as a complete primitive
family. The support test does not replace the needed amplitude. This work
does not establish physical quantum control, successful gauge matching or a
viable GUT. Historical scalar140%/1.94%/20.27% diagnostics, mismatch.745476,
missing Yukawas, quartetFAIL3960/648, custodyexit2/seven and paused/blocked
stages remain distinct and unchanged.

The delegated `python -B tools/research_check.py e4` completed all six checks
with their declared exits. This authenticated the sealed historical E4 evidence
and current authority/structure/read-only contracts, without a fresh scientific
replay or acceptance. Custody returned its required exit2 with seven unresolved
references; it is not an overall PASS. Local commit sealing separately checks
all25317 prior tracked blobs and the new raw/index/HEAD bytes. A documentation
patch initially failed to match its handoff context; no scientific source or
calculation changed, and the corrected editorial patch was applied separately.
