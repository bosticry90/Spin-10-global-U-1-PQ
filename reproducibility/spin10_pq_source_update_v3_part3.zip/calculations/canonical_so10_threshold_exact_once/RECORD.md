# EAT1: exact-once known threshold terms and a primitive-family support test

Prospective, base a1a9d6cc23018e502a2cc61e72111d11c7017be4/main, 2026-10-20.
Question: can FCI1's full-1PI prescribed-pole insertion and HTB1's reduced
heavy bridge be assembled without duplicating tadpole subtraction, reference
translation or the OSF1 soft block? Which mass assignments must a subsequent
complete VVVV primitive calculation address? This is a necessary bounded C1_GS
dependency, not a completed threshold, gauge-unification or E5 claim.

Freeze the source-zero BFT1 action, xi1, dimensional MSbar normalization
Lambda=-12 Gamma_F2, ell=hbar/(16pi^2), positive g10, the SAME positive-Higgs
POINT, FCI1 V3 tables/results and V5 receipt, HTB1 V3 tables/results and V4
receipt, OSF1 V4, WHP1 projectors/receipt and BFT1 f tables. Previous loops are
authenticated/reused, not rerun. Preserve state113/34of39, E5/A5 unqualified,
HB1/C5 blocked, flavor paused, C1_GS null, quartet failure and custody exit2/seven.

Types: three remnant factors (U1,SU2,SU3); fractional raw radials (Phi,Sigma,S);
formal monomials g^n, n=-2,0,2,4, times epsilon^-1, 1, L=log(Q^2/60),
U=log(g^2). Retain f_fin as a three-covector; it is not set to zero. The
assembly is only the known FCI+HTB sub-sum; no residual pole is subtracted by
inventing a primitive amplitude. Unknown quadratic/local CTs, finite jets,
tree/all-soft EFT and nonlinear conversion remain separate explicit terms.

DERIVATION freezes the full-1PI/reduced identity and its graph partition.
Primary adds the authenticated two result polynomials with high precision.
Replay reconstructs FCI from its separately recorded physical/Goldstone/vector
pieces and HTB by convolution of its finite tadpole maps and tadpole polynomial.
Compare all48 scalar coefficients and18 finite-tadpole-map entries at scaled
1e-40, using80 digits; output50 digits. The accuracy inherited from previous
finite data is not promoted to a rigorous error bound by decimal arithmetic.

Check an off-diagonal heavy Gaussian's exact quantum elimination versus an
explicit two-leaf contraction. Keep independent tadpole-loop/pole-CT pieces
until they cancel BEFORE taking finite parts. Show that a paired finite
coordinate change Efin -> Efin + (partial_field K)u, f -> f+M u leaves the
sub-sum invariant. This conditional coordinate identity does not identify an
actual reference-VEV CT with a physical quantum shift or prove that all such
finite changes satisfy the full normalization contract.

Primitive support: contract the actual 720 f entries with ALL five adjoint
mass projectors to obtain the complete5x5 nonnegative quartic color-pair
matrix W_rs. Primary uses adjoint matrix traces; replay independently rebuilds
the orthonormal ten-plane Lie brackets and contracts tensor entries. This is
coarse support, not an F2 amplitude. Require exact equality, symmetry, all
zero complements, row sums8 rank(P_r), total360, and orthogonal complete
projectors. Do not assume that support at zero mass survives the eventual
spin/background sum, or that it vanishes as a scaleless integral.

Separate verifier imports no new native code: independently reconstruct the
two-loop reduced coefficient by polynomial substitution, check actual HTB
M/R/f maps, reconstruct every assembled polynomial from BOTH predecessor
roles, and use projected Frobenius norms for all25 color entries. Retain
eight labelled BFT1 background placements, even though support contraction
does not yet measure any of them. Negative controls must detect double
bridge, omitted pole-CT in bridge, duplicate tadpole CT, wrong bridge sign/
half, omitted EFT partner in the specified soft block, dropped vector
evanescence and omission of any nonzero zero-mass support. No claim to test
source normalization: this is the source-zero action and such a control is
not sensitive here. Global gauge-width independence is not established.

Freeze sources/proof/controller/input bytes before science; sequential owned
workers, no subagents. Native120s each, verifier180s after imports, sampled
private8GiB NOTpeak, launch350MiB floor, new package1MiB. Full captures precede
assertions. Preserve/version failed or incomplete runs without weakening tests.
Outcomes: qualified assembly/support, discrepancy, underdefinition or bounded
incomplete. Scientific acceptance NOT_PERFORMED. Validate before local commit;
no old evidence, state, scheme, point, policy, main, remote or publication change.

Track B tests exact assembly and choosing complete families instead of convenient
subsets; shared action/cache, libraries, AI analyst and inherited finite inputs
remain explicit. No outside, Lean, experimental or physical validation claimed.
