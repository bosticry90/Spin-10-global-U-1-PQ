# Equivalent polynomial loop-order fixture

The first separate verifier completed the all-coordinate commutator, actual
action/current, full Hessian, whole-source cross-term and nonlinear scalar
checks. Its loop-order fixture then compared an expanded hbar^2 coefficient
to the equivalent factored expression by structural equality. That assertion
failed; it was not a nonzero mathematical difference.

V2 tests the exact expanded DIFFERENCE against zero. No native calculation,
quantum coefficient, loop-order requirement or scientific acceptance changed.
The failed full verifier capture and frozen source remain. This is another
avoidable symbolic comparison failure and remains part of the AI-capability
record. No native run failed or was repeated.
