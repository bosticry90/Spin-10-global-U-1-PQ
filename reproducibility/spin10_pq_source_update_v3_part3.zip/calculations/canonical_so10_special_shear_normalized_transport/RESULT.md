# The selected normalized shear and Ward-operator transport are constructed

Both native calculations and the separate action-based verifier completed.
In the fixed lifted Euclidean one-loop construction, the common subtraction
now supports the full special-shear insertion identity and the induced
order-hbar b0 Ward/operator transport. All source products and nonlinear
mean-field terms remain.

This is a selected renormalized replacement result, not a general quantum
field/source-equivalence theorem. No physical scheme or baseline b0 was
adopted; full QAP/A5/E5 remains unqualified.

## The nonzero fixed-operator image has its required companions

The actual generator has36 terms,20 nonzero field flows and37 source
flows. All1,286 coordinate columns of [D-minus,X] were computed, including
zero complements. There are20 nonzero field columns and37 source columns.
Their action is derived before the Ward comparison, without fitting inputs.

For C=QK and B=D-minus S, the complete result is

    D-minus C + [D-minus,X]S + X B = 0.

The three nonzero polynomials contain1,252,1,356 and104 positions,
respectively. These are support counts, not numbers to add as coefficients.
Thus the old nonzero1,252-position fixed-D image is preserved, while its
induced-operator and breaking companions now have an explicit construction.

The antighost density and Euler representatives differ by a fully recorded
current with669 positions in each spacetime direction. Its X image is zero.
The Ward transport therefore cancels as a density in these representatives;
no equation of motion or unrecorded boundary omission was used.

For u=hbar*b0 and T=exp(-u X), the corresponding transport is

    S_b=S+u C,       O_b=O-u X O,
    D_b=D+u[D,X],    B_b=B-u X B.

It leaves b0 symbolic. It does not require b0=0 or identify it with kappa.
The selected Kaux, QKaux, D-minus Kaux, C and whole source-product X
images are zero; the full breaking's image has104 positions. These
zeros were computed, not assumed for arbitrary operators.

## Nonlinear quantum means and whole source products are essential

The actual complete classical identity is

    C + P + F = 0,
    P=sum Y_J R_J,   F=sum X_i E_i S.

C has1,176 positions, P568 and F1,136. P is a whole inserted source
product. It is not a product of separately evaluated mean fields.

The full643-field Hessians of C,P,F contain10,096,3,264 and10,000
positions. They cancel jointly. Differentiating F gives four actual chain
groups with1,200,3,468,3,468 and2,384 positions. The nonlinear corner
cannot be omitted. The separate verifier also finds2,200 cross-Hessian
positions in P that a product-of-means replacement would lose.

Applying the same lifted first-probe prescription gives

    I_C^(1)+I_P^(1)+X_field Gamma1,R
                    +sum E_i S I_Xi^(1)=0.

The last term is the nonlinear quantum mean correction. Its selected scalar
contact has948 positions and cancels the already qualified local scalar
insertion contact exactly. The old368-coefficient kernel and its descendant
data were authenticated and reused; this is not a new loop measurement.

E_i S here is a smooth classical mean-field coefficient substituted after
probe differentiation. The whole F insertion is defined separately through
its full Hessian. No product of two quantum distributions or diagonal
multi-insertion extension is silently assumed.

## The finite regulator response is subtracted, not declared absent

The actual heat-regulated relation includes I_reg. The complete adjacent
inverse-heat reduction, finite-part proof and individual infrared removal
are qualified dependencies. They define the whole response before traces;
no isolated inverse-heat operator is assigned a trace.

Its complete unheated lifted family is zero because K_t-Kref is zero
when the heat is removed. Its actual heat finite part need not be zero.
The common heat-to-hard local subtraction therefore gives

    R_kappa(I_reg,t)=FP(I_reg,t)-L_heat(I_reg,t)=0.

This is a result within the constructed prescription family. It is not
the assertion that the unsubtracted regulator contribution vanishes.
The previously measured C12 ub12 x_Sigma153 coefficient remains

    hbar/(32pi^2) *36sqrt15*xi^3/25
                    *[g10^4 log2-g10^5 log(4/3)].

The corresponding local finite conversion is the negative of this coefficient.
The coefficient was authenticated from the actual three ordered trace
cohorts, independently of the Ward cancellation. Both coupling orders
remain; there is no g10^3 term. Zero leading logarithm alone would have
been insufficient to justify this finite subtraction.

All positive heat jets, power-prefactor convolutions, source/inverse
defects, background reference determinant and fixed IR normalization
remain. For a unit insertion this response is orderhbar. When the shear
itself is u=hbar*b0, its additional loop transport starts at hbar^2.
That bookkeeping does not delete the unit-insertion term.

## Scope, verification and limitations

The whole P and F probes remain in the rational, metric-natural dim4gh0
class with independent Schwartz transfer labels. The common joint IR and
first-probe construction therefore applies. All limits follow the frozen
UV/IR ordering. There is no new constant-probe, adiabatic, coincident
multiple-product or arbitrary four-dimensional cyclic-trace assertion.

Both natives agree on every complete commutator and small polynomial,
the fully computed Hessian hashes and their zero complements. The separate
verifier reconstructs the required Euler maps from the actual gauge-fixing
plus source density and uses its own graded differentiation and recursive
boundary-current calculation. It also checks the whole source cross terms,
nonlinear scalar mean, finite heat normalization and loop-order separation.

The native runs took8.53 and8.50 seconds after imports; verification10.51.
Sampled private memory stayed below683MB, within120/120/180 seconds and
8GiB. No native worker failed. One verifier failed after its substantive
action/Hessian checks on structural comparison of equivalent expanded and
factored loop-order polynomials. V2 checks their exact difference; all
requirements are unchanged and the failed capture/source is preserved.
This repeats an avoidable symbolic comparison weakness in the AI workflow.

The calculations share action, geometry, reference/Wick conventions,
prior analytic/master premises, exact coefficients, Python/SymPy and AI
authorship. Agreement cannot validate these common physical assumptions.
No external scientist, experiment or Lean certificate is implied.

The result does not construct all multiple-insertion contacts, mixing
normalizations, a general measure or quantum A5, all-order QAP/restoration,
physical vacuum/IR/causal/Lorentzian/global limits or parameter stability.
It does not resolve the general generator's different nonzero Jacobian
or the historical quartet-normalization failure.

## Next scientific decision and standing

The selected nonlinear shear no longer needs another isolated scalar
calculation. The next useful target is the first genuinely missing
multiple-insertion/domain condition. In particular, the qualified
single-Q bound permits soft degree3, while two independent constant
Slavnov insertions can reach critical degree4. Their actual complete
kernel and contact treatment must be inspected before extending the
first-probe construction. A collective support reduction should precede
any new tensor extraction.

Authority remains state113/34of39 with all seven quantum flags false.
Source38, measured Gamma874,873/source146,663 coupling-resolved input,
369/664 antighost coverage and295 unmeasured vector profiles are unchanged.
Custody remains exit2/seven unresolved, not PASS. Scalar quantum-control,
gauge matching and quartet issues, HB1/C5 block and flavor pause remain.
No old evidence, state, action, policy or physical benchmark changed.
No push, publication or outreach. The overall investigation is incomplete.
