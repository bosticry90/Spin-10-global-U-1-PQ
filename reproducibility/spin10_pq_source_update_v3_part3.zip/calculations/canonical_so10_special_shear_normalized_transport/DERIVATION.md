# Normalized shear, nonlinear means and the transported Ward operator

Prospective argument; native and independent checks must establish its actual
model inputs. The proof is for the same formal Euclidean one-loop family,
not a general equivalence theorem or adoption of a physical normalization.

1. Let X=ad_Kfull, with actual X_field^i and Y_J=XS_J. Sources are external.
The canonical convention gives the complete classical identity

 C+P+F=0, C=QKfull, P=sum Y_J R_J, F=sum X_field^i E_i S.

P is a WHOLE insertion. It is not Y_J(phi) Gamma_J. E_i S denotes the
actual classical Euler derivative, including source terms. Physical action
terms contain no auxiliary fields, so their E_i vanish in these20 directions.
Thus these particular E_i can be reconstructed from full GF+source density
without a new physical Euler expansion or opening H-basic/C5.

With independent even field variations h,k, differentiate F:

 H_F=sum_i [X_i H_Ei +(d_h X_i)(d_k E_i)
                    +(d_k X_i)(d_h E_i)+(H_Xi) E_i].

The final term is essential; X is nonlinear. The first three are the
actual X_field H and two tangent/congruence terms. Their graded operator
trace under the constructed lifted T_kappa gives X_field Gamma1,R;
the differential tangent trace is zero. Keep derivative adjoints/currents.
The corner gives sum E_i S I_Xi^(1), where the source direction is held
external in defining each probe derivative, THEN replaced by the smooth
mean-field function E_i S. This is not a coincident quantum product of
E_i and Xi. The whole F insertion was defined separately by its full Hessian.
Linearity therefore supplies

 I_C^(1)+I_P^(1)+X_field Gamma1,R+sum E_i S I_Xi^(1)=0.

At J=0 on the selected scalar sector, X_field Gamma vanishes because X
contains external ghosts, and I_P vanishes only AFTER source derivatives.
The nonlinear mean term remains: the old368 T and actual scalar/auxiliary
Euler M give +M^T T, opposite to the ordered/local QKaux kernel.
Its full local coefficient polynomial is checked, not a convenient sample.
The unprojected source and field terms remain in the general identity.

2. This is compatible with the actual heat-regulated identity, not a claim
that its bare finite regulator insertion vanishes. That identity reads

 I_C+I_P-I_reg+sum Gamma_i <Xi>=0.

Use the inherited adjacent inverse-heat reduction on the WHOLE response
before traces. Individual isolated inverse-heat terms have no assigned
trace. Its complete unheated lift is zero: the original DeltaK=K_t-Kref
is zero when heat is removed, for all dimensions in the fixed metric lift.
The existing positive-heat/IR proofs give a common finite part, an unchanged
nonlocal remainder and local finite heat difference. Denote the COMPLETE
local heat-to-hard finite difference by L_heat. Then

 R_kappa(I_reg,t)=FP I_reg,t - L_heat(I_reg,t)=0.

There is no first dimension jet or residue ambiguity for this complete
zero unheated lift. This equation SUBTRACTS an independently determined
nonzero local finite term; it does not drop it. For the authenticated
C12 ub12 x_Sigma153 component, in hbar/(32pi^2) units,

 L_heat(I_reg,t)=36sqrt15*xi^3/25
                    *[g10^4 log2-g10^5 log(4/3)].

The conversion is dictated by the same complete subtraction for every
admitted heat family. It is not fitted from a Ward remainder. All positive
heat jets, power-prefactor convolutions and finite inverse/source defects
remain. The zero logarithm alone would not justify this operation.
Gamma_ref[A] is retained; X leaves A fixed.

The first-probe class is enlarged only by the whole smooth local P and F
densities that occur in the differentiated action. Each new first probe
is a scalar/evaluation-dual external Schwartz label, total density dim4gh0.
It does not alter the zero-label reference chains; the joint node bound
and fixed lifted rank<=4 argument apply as before. Multiplication of the
resulting distribution by smooth E_i S is defined; no diagonal pullback of
two independent quantum insertions is needed. The prior individual inverse
arms and common IR normalization are reused, not inferred from UV locality.

3. b0 transport is a DIFFERENT loop-order question. Put u=hbar*b0 and
T=exp(-u X). The old exact triangular canonical map and its inverse supply
this classical pullback, including all sources, background and jets.
To first order,

 S_b=S+u C, O_b=O-u X O,
 D_b=T D T^-1=D+u[D,X],
 Q_b=T Q T^-1=Q+u[Q,X].

The native calculation constructs ALL1286 [D,X] columns with the actual
corrected D-minus source kernels, before evaluating any Ward comparison.
Acting on the complete classical action gives

 D C+[D,X]S+X B=0, B=D S.

D C alone is the old NONZERO1252-position image. The induced operator and
breaking transport supply the required companions. At one loop,

 D_b(S+hbar Gamma1,R+u C)
   =B-u X B+hbar D Gamma1,R+O(hbar^2).

Thus the transformed tree breaking and quantum insertion identity transport
together for symbolic b0; this relation does not force b0=0 or identify it
with kappa. The analogous Slavnov relation follows from the qualified
canonicality and Q C=0, retaining source/probe companions. Actual O_b images
for the selected primitive/descendants are explicitly computed; zeros are
reported rather than presumed.

Some B representatives differ by a divergence. The native routes construct
the antighost integration-by-parts current explicitly and verify its
divergence and its X image. They never use equations of motion or discard
a nonzero density without its boundary current.

The nonlinear quantum mean and finite regulator correction under an
independent UNIT insertion remain orderhbar. When the shear itself is
u=hbar*b0, their additional transport is orderhbar^2 at fixed cutoff.
The common coefficientwise subtraction/domain justifies this formal order
statement here; it is not a proof of higher-loop equivalence.

4. The construction is a selected normalized one-loop shear identity and
orderhbar canonical/operator transport, not a general quantum A5 theorem.
No actual source-number substitution inside an integral was made. There
is no general path-integral measure, global convergence, diagonal multiple
product extension, all mixing ranks/normalizations, higher-loop or
physical constant-vacuum/adiabatic/causal/Lorentzian claim. The nonzero
general generator Jacobian and historical quartet failure remain separate.
The common kappa prescription is preserved; b0 stays a distinct finite
normalization freedom, not a new physical coupling or chosen baseline.
