# Actual special-shear and normalization transport, V1

Question SST1: does the common first-probe prescription implement the full
special-shear identity with its nonlinear means and whole source products,
and the induced order-hbar b0 Ward/operator transport?
Base c29d987f0f230617fd731c2b9505c6e8c1f886fd,main.
Prospective bounded contract; completed paired checks and separate validation
required. No physical equivalence or full E5/A5 acceptance follows.

Reuse actual Kfull=Ktree+Kaux, E2 full source rules, corrected D-minus,
the complete ordered positive-heat response and individual IR removals,
the lifted finite primitive and common first-probe kappa prescription.
The least expensive competent test is complete local vector-field,
Hessian-chain and probe-transport identities, not295 unmeasured tensors.
Positive outcome: a constructed normalized ONE-LOOP special-shear identity
and order-hbar b0 operator transport in the existing Euclidean family.
Negative/underdefined outcome: exact inconsistent polynomial or missing
product/domain premise; no anomaly claim from incomplete coverage.

Kfull odd dim3 gh-1, X=ad_K even dim0 gh0; C=QK even dim4 gh0;
actual field flows20 auxiliary shifts and37 source flows.
D is the corrected even EPSILON-MARKED antighost operation, epsilon-left.
Independent local parameters and all their jets remain. b0 real and free;
kappa real/free/distinct. No source is integrated or replaced by a scalar
source transformation inside a quantum integral.

Native P: prefix signed word variations and explicit density currents.
Native R: collected left gradients/suffix reordering and Euler pairing.
Compute all1286 coordinate columns of [D,X]=DX-XD including zero columns;
retain complete maps and their source/ordinary action. Compute the full
ordinary643-field Hessian of X_field S by both a literal variation and
four product-chain contributions. Verify nonlinear corner and all companion
terms rather than infer them from a scalar sample.
Authenticate old finite scalar trace cohorts and apply the universal complete
heat subtraction, preserving both g4 and g5 terms. Match the nonlinear mean
against old selected scalar T/contact data without redoing qualified loops.
Separate verifier reconstructs required Euler maps from actual GF+source
density, uses its own derivative implementation, and rechecks complete maps.
Store full small polynomials; for larger Hessians compute all positions and
zero complements, then store exact hashes/counts, not partial tensors.

Limits120 seconds after imports/native,180/verifier, sampled private8GiB
with inherited available-commit floor. New package ceiling5MiB. Freeze
types, assumptions, scripts and immutable inputs before computation.
Write complete captures before checking exits. Preserve failed/unfinished
workers and frozen versions. Workers read only their own inherited route,
never new expected output or opposite route for calculation.

Required controls: fixed D C is not zero; omit or reverse induced operator;
omit nonlinear Hessian/mean; factorize whole source product; discard the
nonzero finite heat response merely from its zero logarithm; wrong b0
loop order. Classify genuine insensitive controls honestly.

No multiplication of divergent loop functions or new diagonal multi-probe
pullback. The E_i S factor in E_i S I_Xi is a smooth classical mean-field
function substituted AFTER probe differentiation. Whole product insertion
I_(X_i E_i S) remains different. All currents and distributional IR deltas
remain. Inherit fixed lifted metric algebra, reference/Wick/real structure,
joint Schwartz domain and all-n symbol/heat proofs, with shared-premise
limits explicit. No generic four-dimensional cyclic trace is assumed.

No actual scheme adoption or b0 baseline, no inverse physical parameter,
Gamma/action/policy/old evidence/state/authority changes. Project state113,
34/39,sevensfalse;source38,369/664,295unmeasured,custodyexit2/seven unchanged.
No blocked/paused activation, push, publication or outreach. Full QAP,
multiple insertion/mixing, measure, A5/E5, physical vacuum/IR/causal/
Lorentzian/global limits and historical quartet remain separate obligations.
