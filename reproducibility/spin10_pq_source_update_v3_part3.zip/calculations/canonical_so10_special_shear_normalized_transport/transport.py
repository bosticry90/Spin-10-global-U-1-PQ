"""Complete marked Ward commutator, nonlinear product and finite transport."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,gzip,importlib.util,os,sys,time,threading
import sympy as s
O=Path(__file__).resolve().parent;R=O.parents[1]
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sp=importlib.util.spec_from_file_location('qualified_contact_algebra',R/'calculations/canonical_so10_correlated_contact_lift/lift.py')
v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v);u=v.u
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def main():
 start=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 role=sys.argv[1];assert role in ['primary','replay']
 prep=read(O/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
 # Authenticate bytes before the role-specific scientific parse guard.
 for raw,h in prep['input_sha256'].items():assert digest(Path(raw))==h,raw
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(x in args[1] for x in 'wax+'):raise PermissionError('SHEAR_WORKER_WRITE')
  if p.suffix=='.json':assert str(p) in prep['read_json_by_role'][role],('UNDECLARED_SHEAR_JSON',str(p))
 sys.addaudithook(guard)
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()))
 A=u.Algebra(data['geometry']['names'],data['geometry']['parities']);pairs=data['geometry']['field_source_h_k']
 fields={n for n,J,h,k in pairs};sources={J for n,J,h,k in pairs};coords=fields|sources
 Jof={n:J for n,J,h,k in pairs};fieldof={J:n for n,J,h,k in pairs}
 elem=lambda n:{(0,((n,()),)):u.ONE};add=v.combine;mul=A.product;neg=lambda f:v.scale(f,-1)
 act=lambda f,m,p=0:v.act(A,f,m,p,role)
 old=read(R/f'calculations/canonical_so10_correlated_contact_lift/{role}_result.json')
 K=v.unpack(A,old['complete_K']);Ka=v.unpack(A,old['actual_20_Kaux'])
 E2=read(P/f'frozen_a10_e2_transport/{role}.json')
 Rfield={A.index[n]:A.rows(rows) for n,rows in data['master_field_maps'].items()}
 q=dict(Rfield);nonminimal={n for n in fields if A.names[n].startswith(('L','b','ub','bar'))}
 for n in nonminimal:q[Jof[n]]=A.rows(E2['complete_columns'][A.names[Jof[n]]]['source_polynomial'])
 C=act(K,q,1);assert C==v.unpack(A,old['complete_C_QK'])
 grad=u.left_gradients(A,K)
 XF={n:v.scale(grad.get(J,{}),-(-1)**A.parities[n]) for n,J,h,k in pairs}
 XS={J:v.scale(grad.get(n,{}),(-1)**A.parities[n]) for n,J,h,k in pairs}
 X={**XF,**XS};assert sum(bool(f) for f in XF.values())==20 and sum(bool(f) for f in XS.values())==37
 D={A.index[f'ub{i}']:elem(A.index[f'zz_da{i:02}']) for i in range(12,45)}
 for name,rows in data['all33_kernel_maps'].items():D[A.index[name]]=neg(A.rows(rows,True))
 comm={n:add(act(X.get(n,{}),D),neg(act(D.get(n,{}),X))) for n in coords}
 activecomm={n:f for n,f in comm.items() if f}
 assert len(comm)==1286
 assert all(n in nonminimal for n in fields if comm[n]),'UNEXPECTED_PHYSICAL_EULER_NEEDED'
 Cw=act(C,D);Pwhole={};F={}
 for J,f in XS.items():
  if f:v.merge(Pwhole,mul(f,Rfield[fieldof[J]]))
 for n,f in XF.items():
  if f:v.merge(F,mul(f,q[Jof[n]]))
 assert not add(C,Pwhole,F)
 source={}
 for n,J,h,k in pairs:v.merge(source,mul(elem(J),Rfield[n]))
 GF=A.rows(data['gauge_fixing_density']);ordinary=add(GF,source)
 B=act(ordinary,D)
 Beuler={};commS={}
 for n in fields:
  if D.get(n):v.merge(Beuler,mul(D[n],q[Jof[n]]))
  if comm[n]:v.merge(commS,mul(comm[n],q[Jof[n]]))
 for J in sources:
  if D.get(J):v.merge(Beuler,mul(D[J],Rfield[fieldof[J]]))
  if comm[J]:v.merge(commS,mul(comm[J],Rfield[fieldof[J]]))
 # Explicit local antighost IBP current; even variation, left field gradient.
 current=[{} for _ in range(4)]
 for(g,w),co in ordinary.items():
  prefix=0
  for ii,(n,jets) in enumerate(w):
   if n in fields and D.get(n) and jets:
    partial={(g,w[:ii]+w[ii+1:]):u.scale_coefficient(co,(-1)**(A.parities[n]*prefix))}
    for ell,mu in enumerate(jets):
     f=mul(v.jets(A,D[n],jets[ell+1:]),v.jets(A,partial,jets[:ell]))
     v.merge(current[mu],v.scale(f,(-1)**ell))
   prefix+=A.parities[n]
 divergence=add(*(v.total(A,f,mu) for mu,f in enumerate(current)))
 assert not add(B,neg(Beuler),neg(divergence))
 Xcurrent=[act(f,X) for f in current];Xdiv=add(*(v.total(A,f,mu) for mu,f in enumerate(Xcurrent)))
 XB=act(B,X);ward=add(Cw,commS,XB)
 assert ward==Xdiv
 historical=read(R/f'calculations/canonical_so10_relative_contact_transport/{role}_v2_result.json')
 assert Cw==v.unpack(A,historical['complete_Ward_DminusC_all33'])
 assert Cw and not act(C,X)
 print('STAGE',role,'all1286_commutator_and_complete_Ward_transport',flush=True)
 hmap={n:elem(h) for n,J,h,k in pairs};kmap={n:elem(k) for n,J,h,k in pairs}
 dh=lambda f:act(f,hmap);dk=lambda f:act(f,kmap);H=lambda f:dk(dh(f))
 pieces=[{}, {}, {}, {}]
 for n,x in XF.items():
  if not x:continue
  E=q[Jof[n]]
  assert all(w for gp,w in E),'NON_SCHWARTZ_CONSTANT_EULER_FACTOR'
  for j,f in enumerate([mul(x,H(E)),mul(dh(x),dk(E)),mul(dk(x),dh(E)),mul(H(x),E)]):v.merge(pieces[j],f)
 HF=H(F);assert HF==add(*pieces)
 HC=H(C);HP=H(Pwhole);assert not add(HC,HP,HF)
 assert pieces[3] and add(HF,neg(add(*pieces[:3])))
 scalar={n for n in fields if A.names[n].startswith('x_')}
 pscalar=lambda f:{key:co for key,co in f.items() if all(n in scalar for n,j in key[1])}
 scalarorder=[A.index[f'x_{sec}_{i}'] for sec,count in [('Phi',54),('Sigma',252),('phi',20),('S',2)] for i in range(count)]
 Ln=[A.index[('b' if i<12 else 'L')+str(i)] for i in range(45)]
 bubble=read(R/f'calculations/canonical_so10_auxiliary_insertion_source_bubble/{role}_v2_result.json')
 compatibility=read(R/f'calculations/canonical_so10_auxiliary_primitive_contact_compatibility/{role}_result.json')
 mean={}
 for row in bubble['canonical_tensor']:
  E=pscalar(q[Jof[Ln[row['rho_index']]]]);term=mul(E,mul(v.unpack(A,row['coefficient']),elem(scalarorder[row['scalar_index']])))
  v.merge(mean,term)
 localC=v.unpack(A,compatibility['local_Slavnov_contact_polynomial'])
 assert localC and not add(localC,mean)
 # Whole-field b0 probe images, including all source companions.
 probeimages={name:act(f,X) for name,f in [('Kaux',Ka),('QKaux',act(Ka,q,1)),('DminusKaux',act(Ka,D)),('Cfull',C),('Pwhole',Pwhole),('B',B)]}
 finite=read(R/f'calculations/canonical_so10_finite_shear_scalar/{role}_v2_result.json')
 g,xi,eta=s.symbols('g10 xi eta_H',real=True)
 raw=s.S.Zero
 for row in finite['actual_finite_coefficient_log_recipe']:
  cc=sum(s.Rational(a,b)*s.sqrt(s.prod(p for bit,p in enumerate([2,3,5,7]) if mask&(1<<bit))) for mask,a,b in row['coefficient_cells'])
  raw+=cc*g**row['g']*xi**row['xi']*eta**row['eta_H']*s.log(s.Rational(*row['log_argument']))
 expected=s.Rational(36,25)*s.sqrt(15)*xi**3*(g**4*s.log(2)-g**5*s.log(s.Rational(4,3)))
 assert s.simplify(s.expand_log(raw-expected,force=True))==0 and raw!=0
 assert s.expand(raw).coeff(g,3)==0
 # The prescribed complete heat difference, not a fitted Ward coefficient.
 subtracted=s.expand(raw-raw);assert subtracted==0
 controls={
 'fixed_D_C_is_nonzero':bool(Cw),
 'operator_omission_failure_or_current_explicit':bool(add(Cw,XB,neg(Xdiv))),
 'operator_reversal_failure_or_current_explicit':bool(add(Cw,neg(commS),XB,neg(Xdiv))),
 'nonlinear_Hessian_corner_required':bool(pieces[3]),
 'scalar_nonlinear_mean_omission_leaves_nonzero_contact':bool(localC),
 'whole_source_product_has_nonzero_Hessian':bool(HP),
 'actual_finite_regulator_response_not_zero_from_zero_log':raw!=0,
 'hbar_times_one_loop_response_begins_hbar2':finite['order_of_actual_finite_regulator_loop_with_u_hbar_b']==2}
 # Report insensitive operator controls, never require a false sensitivity.
 assert controls['fixed_D_C_is_nonzero'] and controls['nonlinear_Hessian_corner_required'] and controls['whole_source_product_has_nonzero_Hessian']
 pack=lambda f:u.pack(A,f)
 result={'schema':'SPECIAL_SHEAR_NORMALIZED_TRANSPORT_V1','route':role,
 'scientific_disposition':'CONSTRUCTED_FORMAL_ONE_LOOP_SPECIAL_SHEAR_AND_ORDER_HBAR_WARD_OPERATOR_TRANSPORT_NOT_FULL_QAP_A5_E5',
 'Kfull_positions':len(K),'Cfull_positions':len(C),'Pwhole_positions':len(Pwhole),'Xfield_action_positions':len(F),
 'commutator_domain_columns':len(comm),'commutator_nonzero_field_columns':sum(bool(comm[n]) for n in fields),'commutator_nonzero_source_columns':sum(bool(comm[n]) for n in sources),
 'actual_complete_commutator':{A.names[n]:pack(f) for n,f in activecomm.items()},
 'complete_D_C':pack(Cw),'complete_commutator_S':pack(commS),'complete_X_B':pack(XB),
 'Ward_density_remainder':pack(ward),'current_divergence_matches_remainder':True,
 'antighost_IBP_currents':[pack(f) for f in current],'X_antighost_IBP_currents':[pack(f) for f in Xcurrent],
 'B_positions':len(B),'B_euler_positions':len(Beuler),
 'Hessians_fully_computed':{name:{'positions':len(f),'sha256':A.fingerprint(f)} for name,f in [('C',HC),('P',HP),('F',HF)]},
 'F_Hessian_chain_positions':[len(f) for f in pieces],
 'F_Hessian_nonlinear_corner_sha256':A.fingerprint(pieces[3]),
 'scalar_mean_contact':pack(mean),'scalar_mean_contact_positions':len(mean),
 'selected_scalar_contact_plus_nonlinear_mean_zero':True,
 'b0_probe_X_images':{name:pack(f) for name,f in probeimages.items()},
 'finite_actual_heat_response':str(raw),'finite_complete_subtraction':str(-raw),
 'same_prescription_zero_unheated_response_after_full_local_subtraction':True,
 'retained_unsubtracted_finite_heat_response_nonzero':True,
 'kappa_and_b0_distinct_free_no_baseline_or_scheme_adopted':True,
 'controls':controls,
 'domain':'Formal fixed lifted Euclidean one-loop coefficients,independent Schwartz first probes and smooth classical Euler factors;not diagonal quantum multiple products or physical vacuum',
 'limitations':'No general measure,QAP,all mixing,quantumA5,E5,higher loops,causal/Lorentzian/global/physical IR or adoption;Gamma and295unmeasured vector coefficients unchanged',
 'shared_limits':'Actual action,geometry,reference/Wick,old master/domain/heat premises,exact algebra/Python/SymPy and AI analyst;not independent physical or external verification',
 'elapsed_after_imports':time.perf_counter()-start}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
if __name__=='__main__':main()
