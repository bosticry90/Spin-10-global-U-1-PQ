# Flat critical translation response:an extension and explicit profile matching

TCI1 is qualified in its declared flat Euclidean,first-translation reference
scope. The critical ghost edge now has an explicit tempered-distribution
extension compatible with both linearized unheated inverse equations and
the actual reality/H intertwiner conditions. Its relative finite infrared
normalization is calculated for both prescribed profiles.

The complete paired action/source zero-transfer identity and full constant-
generator quantum transformation remain UNQUALIFIED. No physical scheme,
vacuum or value of an infrared constant has been adopted. Authority is34/39.

## The actual two regulated responses are different

Let chi_k=(1-exp(-p^2/epsilon^2))^k,k=1,2. The prescribed covariance is
U_k F_t G0 F_t^sharp U_k^sharp,with U_k^2=chi_k,F_t=exp(-t p^2).
For the actual ordinary mass interaction N,the response is

 delta_int G=chi_k^2 exp(-4t p^2) E/(p^2)^2.

Varying the reference covariance instead gives

 delta_ref G=chi_k exp(-2t p^2) E/(p^2)^2.

The latter has a dressed inverse vertex chi_k^-1 exp(2t p^2)N. It cannot
replace the ordinary insertion while claiming to compute the same regulated
word. Matrix order,graded normalization and BOTH inverse directions were
checked. All57 nonzero response coefficients and1968 zeros in the45x45
top-right ghost block are retained;the complete90-field response has114
nonzero entries. These old measured/action-derived coefficients are reused,
not recalculated as a new pole or inserted into Gamma again.

## The infrared finite part is explicit

Use normalized dp/(2pi)^4 and delta_star=(2pi)^4 delta(p). For
T_m,epsilon=(1-exp(-p^2/epsilon^2))^m/(p^2)^2,define

 S_m=sum_(j=1)^m (-1)^j binomial(m,j) log j.

Then the distributional limit on Schwartz tests is

 T_m,epsilon-log(nu^2/epsilon^2)delta_star/(16pi^2)
       ->R_nu(p^-4)+(gamma_E-S_m)delta_star/(16pi^2).

This is proved for every Schwartz test,not only a Gaussian. Subtract a
Gaussian with the same value at the origin. The remaining test vanishes
linearly there,so its quotient by p^4 is locally integrable. Dominated
profile convergence applies to that remainder. An explicit error bound is
m*epsilon/(16*pi^(3/2)) times its gradient supremum,plus an O(epsilon^2)
Gaussian remainder with a recorded exact coefficient bound.

The required finite constants are:

| Profile power m | S_m | Finite delta coefficient gamma_E-S_m |
| --- | --- | --- |
| 1 | 0 | gamma_E |
| 2 | log2 | gamma_E-log2 |
| 4 | 8log2-4log3 | gamma_E-8log2+4log3 |

The existing spectral-mass family is
E_d=R_nu+(d-1)delta_star/(16pi^2). The exact relative offset is therefore
(gamma_E-S_m-d+1)delta_star/(16pi^2). This constructs a sufficient common
flat edge family for any fixed real d. It neither fixes d nor proves that
every other quantum product must use this family. d,UV kappa and b0 remain
distinct;nu is not identified with the ultraviolet subtraction scale.

This response has no epsilon^4 prefactor. Its finite IR-delta component
survives cutoff removal;the older epsilon^4-suppressed inverse-corner
removal bound cannot be transferred to this new response.

After their logarithmic IR subtraction,REFERENCE MINUS ORDINARY response
contains

 (exp(-2t p^2)-exp(-4t p^2))*R_nu(p^-4)
                     +lambda_k*delta_star/(16pi^2),

multiplied by the actual matrix E,where

 lambda_1=log2,
 lambda_2=7log2-4log3=log(128/81).

Both are nonzero. The first term is an ordinary locally L1 kernel because
its prefactor vanishes at the origin. It tends to zero on fixed Schwartz
tests as t->0,but its UNMARKED heat integral is log2/(16pi^2). The heat
placement term and the momentum-origin delta are different contributions.
For a Gaussian exp(-s p^2),their sum is

 [log((s+4t)/(s+2t))+lambda_k]/(16pi^2).

The unmarked s=0 diagnostic is not the fixed-Schwartz-test limit. No finite
regulator term is discarded because it vanishes pointwise or has no UV pole.

## The ghost response is the only critical reference channel

The COMPLETE GF translation variation has33 canonical positions,all in
the known ghost bilinear. All643 actual field rules were varied before
source restriction. They give200 nonzero rule variations with432 positions,
each of field degree at most1. Hence the source Hessian variation is zero
for arbitrary retained J. The source variations THEMSELVES are nonzero and
must remain in the subsequent Ward/source transport problem.

All34 physical Hessian terms were inspected using their graph coefficients
versus an independent extraction from their action ASTs. At zero mean the
possible physical channels are B/scalar with one momentum and scalar/scalar
with no momentum. They occur only in kinetic_Phi,kinetic_Sigma,potential_muPhi
and potential_muPhiPhi. These are complete channel upper bounds,not newly
evaluated potential or physical Euler coefficients. Tensor contractions
can remove a channel but cannot create an omitted one.

The qualified scalar/M dressed ports give maximal response order2 in those
bosonic channels,whereas the ghost mass response has order4. Thus only
the ghost reference edge needs this critical extension. This does not
calculate or remove physical one-point/tadpole/Euler terms in delta_tau S;
those must accompany any complete action/source identity.

## A derivative contact remains unavoidable

The extension obeys p^2 E_d(p^-4)=1/p^2 and p^2 delta_star=0. Together with
the actual signed matrix inverse,this proves both linearized inverse
response equations without fixing d. The mass/response matrices satisfy
all12 actual constant-H intertwiner conditions and physical reality. This
is not a new off-flat local-H extension theorem.

The normalized distribution also satisfies

 sum_mu partial_pmu[p_mu R_nu(p^-4)]=delta_star/(8pi^2).

Consequently,for E_mu=-partial_mu E_d/4,

 sum_mu p_mu E_mu=E_d-delta_star/(32pi^2).

The fixed contraction contact cannot be removed by adjusting d. A purely
pointwise homogeneity argument would miss it. The later paired Slavnov/
source calculation must retain it rather than assume all divergent
derivative/contraction identities hold without contacts.

## Verification and failures

Primary uses binomial/Frullani subtraction and full graph coefficients;
replay uses a strip-valid Mellin/Laplace derivation and the independent
physical action ASTs. All exact profile and matrix fields agree. The
separate verifier derives the Gaussian identity from a beta derivative
and its initial condition,and evaluates a NEW non-Gaussian radial test
(1+2p^2)exp(-5p^2/3). It independently checks the complete GF/source census,
all34 physical channels,all2025 ghost entries and graded inverse directions.
Both numerical control routes agree with the exact formulas;the analytic
all-test error bound supplies the distributional conclusion.

Successful native primary V2/replay V3 took6.16/7.53seconds after imports;
the verifier took2.33seconds. Sampled private memory stayed below275MB;
these samples are not a true-peak guarantee. Limits were120/120/180s,
8GiB sampled-private and8MiB new package. The completed receipt SHA256 is
8f1ce70845aafb0744b109fc0f412131bb124c9ee9b33c0da79c97bdafc6b611.

Two failed native runs are preserved. V1 stopped at an exact m4 logarithm
comparison that needed positive-argument rational factoring;the independent
diagnostic and failed bytes remain. V2 replay then stopped at an AST wrapper
whose child was serialized as argument rather than expression. V3 handles
both declared wrapper forms. The completed primary V2 was authenticated
and reused because only the replay AST branch changed. Neither failure
changed a coefficient,profile,subtraction or acceptance obligation. There
were no verifier failures. Use the preserved source/controller copies and
preparations for actual commands and exact read/resource ownership.

The methods share the action,frames,GF/source/primitive/reference and
qualified IR assumptions,Python/SymPy/mpmath and AI analyst. They are
bounded computational/analytic corroboration,not independent expert,
experimental or Lean validation. Old57-coefficient amplitudes and broad
audits were authenticated/reused,not rerun as new independent evidence.

## Next dependency and unchanged authority

The individual FLAT critical edge now has a compatible candidate extension
and exact profile conversions. The full paired first-translation action/
source response still needs a proof using that SAME extension. It must
carry the432 nonzero source-rule partners,the complete physical Euler/
tadpole terms,finite inverse-regulator defects and derivative contacts.
An open-edge inverse identity does not establish that paired result.

Use the actual marked-translation Born/Hessian identities to determine
whether one critical-root extension covers the whole required first
variation or whether a further normalization/domain condition is needed.
Off-flat critical products and the constant-probe/adiabatic functional
limit remain separate. Do not drop tau,adopt a shifted vacuum,choose d=0
or identify IR contacts with kappa/b0. No295-profile tensor is needed merely
to repeat this edge calculation.

Whole Spin(10)xPQ goal stays active. State113/34of39,sevensfalse,source38,
Gamma874873/source146663,369/664,295unmeasured,custody2/seven,quartet/140%scalar/
matching warnings,HB1/C5block andflavorpause remain. Full constant-generator
transport,QAP/measure/A5/E5 and physical limits/viability are unqualified.
All old bytes/action/state/policy/benchmark/scheme preserved. No branch/
worktree,push,publication,outreach or blocked/paused work was activated.
