"""Actual critical translation edge,profile finite parts and reference-channel census."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
from collections import defaultdict,Counter
import gzip,json,os,sys,time,threading,itertools
import sympy as s
import mpmath as mp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools/portable_dh_v1'))
from exact_algebra import Algebra,ONE,put,scale_coefficient
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def main():
 tick=time.perf_counter();watch=threading.Timer(120,lambda:os._exit(124));watch.daemon=True;watch.start()
 role=sys.argv[1];assert role in ['primary','replay'];prep=read(O/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
 for raw,h in prep['input_sha256'].items():assert digest(Path(raw))==h,raw
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('TRANSLATION_CRITICAL_EDGE_WRITE')
  if p.suffix=='.json':assert str(p) in prep['read_json_by_role'][role],('UNDECLARED_CRITICAL_EDGE_JSON',str(p))
 sys.addaudithook(guard)
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()));geo=data['geometry'];A=Algebra(geo['names'],geo['parities']);pairs=[(i,J) for i,J,h,k in geo['field_source_h_k']];fields={i for i,J in pairs}
 parent=read(R/f'calculations/canonical_so10_general_first_order_transport/{role}_v3_result.json');old=read(R/f'calculations/canonical_so10_source_primitive_transport/{role}_result.json')
 tau={}
 for i in fields:
  poly=A.rows(old['all643_field_columns'][A.names[i]],explicit_g=True);fixed={key:co for key,co in poly.items() if not key[1]}
  if fixed:assert A.names[i].startswith('x_');tau[i]=fixed
 assert len(tau)==20
 def rows_any(rows):
  out={}
  for row in rows:
   for key,co in A.rows([row],explicit_g='g' in row).items():put(out,key,co)
  return out
 def vary(poly):
  out={}
  for(gp,w),co in poly.items():
   for k,(n,jets) in enumerate(w):
    if n in tau and not jets:
     for key,z in A.product(tau[n],{(gp,w[:k]+w[k+1:]):co}).items():put(out,key,z)
  return out
 GF=rows_any(data['gauge_fixing_density']);dGF=vary(GF);ghosts={A.index[f'C{i}'] for i in range(45)};antis={A.index[('bar' if i<12 else 'ub')+str(i)] for i in range(45)}
 assert dGF and len(dGF)==parent['delta_tau_GF_positions']
 assert all(len(w)==2 and not any(j for n,j in w) and sum(n in ghosts for n,j in w)==1 and sum(n in antis for n,j in w)==1 for gp,w in dGF)
 source_nonzero=0;source_positions=0;source_max_degree=0
 for name,rows in data['master_field_maps'].items():
  delta=vary(rows_any(rows));source_nonzero+=bool(delta);source_positions+=len(delta)
  source_max_degree=max([source_max_degree]+[len(w) for gp,w in delta])
 assert len(data['master_field_maps'])==643 and source_max_degree<=1
 print('STAGE',role,'complete_GF_translation_only_ghost_bilinear_and_all643_source_Hessian_variations_zero',flush=True)

 core=read(R/f'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_e5_full_hessian/{role}.json');physical=core['physical_Hessian_program']['all_34_literal_terms'];assert len(physical)==34
 active={'Phi','Sigma','SigmaBar','x_Phi','x_Sigma'}
 scalar={'Phi','Sigma','SigmaBar','phi','phiBar','S','SBar','x_Phi','x_Sigma','x_phi','x_S'}
 def channel(signature):
  ordinary=[(n,j) for n,j in signature if not n.startswith(('h_','k_'))]
  if len(ordinary)!=1 or ordinary[0][0] not in active or ordinary[0][1]:return None
  variations=[(n[2:],j) for n,j in signature if n.startswith(('h_','k_'))];assert len(variations)==2
  assert sum(n.startswith('h_') for n,j in signature)==1 and sum(n.startswith('k_') for n,j in signature)==1
  species=[('B' if n=='B' else 'x' if n in scalar else n) for n,j in variations];species.sort();degree=sum(j for n,j in variations)
  return (species[0],species[1],degree)
 def ast_signatures(node):
  kind=node['node']
  if kind=='Field':return {((node['name'],0),)}
  if kind=='ExactScalar':return set() if s.sympify(node['value'])==0 else {()}
  if kind in {'Parameter','StructureConstant','RepresentationGenerator'}:return {()}
  if kind in {'LocalActionTerm','GroupContraction','LorentzContraction'}:
   return ast_signatures(node['density'] if kind=='LocalActionTerm' else node['expression'])
  if kind=='Add':return set().union(*(ast_signatures(n) for n in node['terms']))
  if kind=='OrderedProduct':
   result={()}
   for factor in node['factors']:result={tuple(sorted(a+b)) for a in result for b in ast_signatures(factor)}
   return result
  if kind=='PartialDerivative':
   result=set()
   for signature in ast_signatures(node['argument']):
    for i,(name,jets) in enumerate(signature):result.add(tuple(sorted(signature[:i]+((name,jets+1),)+signature[i+1:])))
   return result
  raise AssertionError(('UNKNOWN_PHYSICAL_AST_TYPE',kind))
 census=[]
 for term in physical:
  if role=='primary':
   signatures=[tuple((node[1],len(node[3])) for node in word if node[0]=='Field') for gps,word,co in term['index_jet_graph_coefficients']]
  else:signatures=ast_signatures(term['mixed_second_variation_AST'])
  channels=sorted({ch for signature in signatures if (ch:=channel(signature)) is not None})
  assert set(channels)<={('B','x',1),('x','x',0)},(term['term_id'],channels)
  census.append({'term':term['term_id'],'possible_translation_H0_channels':[list(ch) for ch in channels]})
 possible={tuple(ch) for row in census for ch in row['possible_translation_H0_channels']}
 assert possible=={('B','x',1),('x','x',0)}
 ports={('B','B'):2,('B','L'):1,('L','B'):1,('B','x'):1,('x','B'):1,('x','x'):0,('C','a'):2,('a','C'):2}
 orders=[]
 for a,b,n in [('B','x',1),('x','B',1),('x','x',0),('C','a',0),('a','C',0)]:
  paths=[left+right-n for(u,v),left in ports.items() for(w,z),right in ports.items() if v==a and w==b]
  worst=max(paths);orders.append([a,b,n,worst]);assert worst==(4 if a in {'C','a'} else 2)
 print('STAGE',role,'all34_physical_terms_reference_response_channel_census_ghost_only_critical',flush=True)

 g,xi,eta=s.symbols('g10 xi eta_H',real=True);ss,eps,nu,tt=s.symbols('s epsilon nu t',positive=True);dd=s.Symbol('d',real=True);zz=s.Symbol('z')
 @lru_cache(None)
 def ex(t):return s.expand(s.sympify(t,locals={'g10':g,'xi':xi,'eta_H':eta,'reference_width_H':eta,'reference_width_M':xi}))
 def clean(M):return s.SparseMatrix(M.applyfunc(s.expand))
 def mat(packet):return s.SparseMatrix(*packet['shape'],{(i,j):ex(co) for i,j,co in packet['entries']})
 ref=core['retained_reference'];T=mat(ref['physical_to_raw_kernel']);Ti=mat(ref['physical_to_raw_inverse']);order=ref['field_order'];pos={n:i for i,n in enumerate(order)}
 K=clean(Ti.T*mat(ref['reference_Hessian_raw_C3'])*Ti);Ca=K[553:598,598:643]
 pp=[s.Symbol(f'p0_ref{i}') for i in range(4)];q=s.symbols('q0:4',real=True);r2=sum(v*v for v in q);wick={pp[0]:s.I*q[0],pp[1]:q[1],pp[2]:q[2],pp[3]:q[3]}
 D=clean(Ca.applyfunc(lambda co:s.cancel(co.subs(wick)/r2)));assert not any(co.has(*q,g,xi,eta) for co in D) and D.det()!=0
 N=s.SparseMatrix(45,45,{(i,j):ex(co) for i,j,co in parent['actual_ghost_mass_physical']});zero=s.zeros(45)
 Ku=clean(s.BlockMatrix([[zero,D],[-D.T,zero]]));Hu=clean(s.BlockMatrix([[zero,N],[-N.T,zero]]))
 if role=='primary':Gu=Ku.inv();Eu=clean(-Gu*Hu*Gu)
 else:
  Gu=clean(s.BlockMatrix([[zero,-D.T.inv()],[D.inv(),zero]]));Eu=clean(s.BlockMatrix([[zero,D.T.inv()*N.T*D.T.inv()],[-D.inv()*N*D.inv(),zero]]))
 assert not clean(Ku*Gu-s.eye(90)).nnz() and not clean(Gu*Ku-s.eye(90)).nnz()
 assert not clean(Ku*Eu+Hu*Gu).nnz() and not clean(Eu*Ku+Gu*Hu).nnz()
 assert N.nnz()==57 and not any(co.has(s.I,s.Float) for co in N)
 E=Eu[:45,45:];expectedE=s.SparseMatrix(45,45,{(i,j):ex(co) for i,j,co in parent['actual_critical_ghost_edge_coefficients']});assert not clean(E-expectedE).nnz()
 witness=read(R/f'calculations/canonical_so10_local_covariant_reference_witness/{role}_result.json');cr=[pos[f'C{i}'] for i in range(45)];ar=[pos[('bar' if i<12 else 'ub')+str(i)] for i in range(45)]
 Uf=Ti.extract([pos[f'C{i}'] for i in range(12)],list(range(553,565)))
 raw=[s.SparseMatrix(643,643,{(i,j):ex(co) for i,j,co in rows}) for rows in witness['actual12_homogeneous_carrier_matrices']]
 for b in range(12):
  rc=clean(T.extract(list(range(553,598)),cr)*sum((rr.extract(cr,cr)*Uf[a,b] for a,rr in enumerate(raw)),s.zeros(45))*Ti.extract(cr,list(range(553,598))))
  ra=clean(T.extract(list(range(598,643)),ar)*sum((rr.extract(ar,ar)*Uf[a,b] for a,rr in enumerate(raw)),s.zeros(45))*Ti.extract(ar,list(range(598,643))))
  assert not clean(rc.T*N+N*ra).nnz() and not clean(rc*E+E*ra.T).nnz()
 # Actual finite-epsilon words:chi=eigenprofile and heat damping act on both edges.
 chi,h=s.symbols('chi h',positive=True);Gcut=chi*h*Gu;Kcut=Ku/(chi*h)
 Iedge=chi**2*h**2*Eu;Redge=chi*h*Eu;Rvertex=Hu/(chi*h)
 assert not clean(Kcut*Iedge+Hu*Gcut).nnz() and not clean(Iedge*Kcut+Gcut*Hu).nnz()
 assert not clean(Kcut*Redge+Rvertex*Gcut).nnz() and not clean(Redge*Kcut+Gcut*Rvertex).nnz()
 print('STAGE',role,'all2025_ghost_coefficients_actual_graded_inverse_and_H_intertwiners',flush=True)

 canon=lambda v:s.expand(s.expand_log(v,force=True));profiles={};numeric=[];mp.mp.dps=55
 for m in [1,2,4]:
  aa=[(-1)**j*s.binomial(m,j) for j in range(m+1)];assert sum(aa)==0
  Sm=canon(sum(aa[j]*s.log(j) for j in range(1,m+1)))
  gaussian=-sum(aa[j]*s.log(ss+s.Rational(j,1)/eps**2) for j in range(m+1))
  if role=='primary':cm=canon(s.EulerGamma-Sm)
  else:
   # Mellin transform on -m<Re z<0 is derived by integration by parts before continuation.
   F=sum(aa[j]*s.exp(-zz*s.log(j)) for j in range(1,m+1));assert F.subs(zz,0)==-1
   cm=canon(s.diff(F,zz).subs(zz,0)-s.EulerGamma*F.subs(zz,0))
   IBP=-m*sum((-1)**j*s.binomial(m-1,j)*s.exp(-(zz+1)*s.log(j+1)) for j in range(m));assert s.simplify(F-IBP)==0
  assert canon(cm-s.EulerGamma+Sm)==0
  error=canon(-sum(aa[j]*s.log(1+ss*eps**2/j) for j in range(1,m+1)))
  assert s.simplify(gaussian-s.log(nu**2/eps**2)+s.log(ss*nu**2)+Sm-error)==0
  C=sum(abs(aa[j])/j for j in range(1,m+1));uniform=m*eps/(16*s.pi**s.Rational(3,2))
  profiles[str(m)]={'S_m':str(Sm),'finite_IR_offset_c_m':str(cm),'existing_E_d_matching_offset':str(canon(cm-dd+1)),'gaussian_16pi2':str(gaussian),'gaussian_error_exact_16pi2':str(error),'gaussian_error_bound_16pi2':str(C*ss*eps**2),'zero_value_test_error_bound_times_gradient_sup':str(uniform)}
  for ev,sv in [(s.Rational(1,2),s.Rational(3,2)),(s.Rational(1,4),s.Rational(2,3))]:
   ee=mp.mpf(str(ev.p))/ev.q;svv=mp.mpf(str(sv.p))/sv.q
   if role=='primary':
    a=svv*ee**2;f=lambda u:mp.exp(-a*u)*(-mp.expm1(-u))**m/u if u else mp.mpf(0)
    value=mp.quad(f,[0,1,10,max(100,10/a),mp.inf])
   else:
    al=s.Symbol('alpha',positive=True);rat=s.cancel(sum(aa[j]*al/(al+sv+j/ev**2)**2 for j in range(m+1)));fn=s.lambdify(al,rat,'mpmath');value=mp.quad(fn,[0,1,10,100,mp.inf])
   target=mp.mpf(str(s.N(gaussian.subs({eps:ev,ss:sv}),53)));err=abs(value-target);assert err<mp.mpf('1e-45'),(m,ev,err)
   rem=abs(mp.mpf(str(s.N(error.subs({eps:ev,ss:sv}),53))));bound=mp.mpf(str(s.N((C*ss*eps**2).subs({eps:ev,ss:sv}),53)));assert rem<=bound
   numeric.append({'m':m,'epsilon':str(ev),'s':str(sv),'value_16pi2':mp.nstr(value,45),'absolute_quad_error':mp.nstr(err,8)})
 differences=[]
 for kval in [1,2]:
  sk=ex(profiles[str(kval)]['S_m']);s2=ex(profiles[str(2*kval)]['S_m']);lam=canon(s2-sk);assert lam!=0
  differences.append({'k':kval,'interaction_profile_power':2*kval,'interaction_heat_power':4,'reference_profile_power':kval,'reference_heat_power':2,'IR_delta_coefficient_16pi2':str(lam),'gaussian_difference_16pi2':str(s.log((ss+4*tt)/(ss+2*tt))+lam),'unmarked_heat_difference_16pi2':str(s.log(2)+lam)})
 # Distributional inverse/contact identities,with arbitrary d retained.
 testr=1/(16*s.pi**2*ss);flux=canon(2*ss*testr);assert flux==1/(8*s.pi**2)
 contraction_contact=flux/4;assert contraction_contact==1/(32*s.pi**2)
 Lheat=s.integrate((s.exp(-2*tt*ss)-s.exp(-4*tt*ss))/ss,(ss,0,s.oo));assert s.simplify(Lheat-s.log(2))==0
 assert s.limit(s.log((ss+4*tt)/(ss+2*tt)),tt,0,dir='+')==0
 print('STAGE',role,'complete_profile_finite_parts_numeric_controls_and_retained_IR_contraction_contact',flush=True)

 result={'schema':'TRANSLATION_CRITICAL_IR_EXTENSION_V1','route':role,'scientific_disposition':'CONSTRUCTED_FLAT_CRITICAL_TRANSLATION_EDGE_EXTENSION_WITH_ACTUAL_PROFILE_MATCHING_AND_GHOST_ONLY_CRITICAL_REFERENCE_CENSUS_NOT_FULL_CONSTANT_GENERATOR_OR_QAP_A5_E5',
 'physical_34_term_channel_census':census,'possible_physical_channels':[list(c) for c in sorted(possible)],'complete_GF_variation_only_known_ghost_bilinear':True,'GF_variation_positions':len(dGF),'source_rules_scanned':643,'source_translation_nonzero_rules':source_nonzero,'source_translation_positions':source_positions,'max_source_translation_field_degree':source_max_degree,'complete_source_Hessian_variation_zero':True,'dressed_response_soft_orders':orders,
 'actual_ghost_mass_nonzero':57,'actual_ghost_mass_zero':1968,'actual_response_90field_nonzero':Eu.nnz(),'actual_response_topright':[[i,j,str(co)] for i,j,co in E.row_list()],
 'all_actual_two_sided_inverse_and_constant_H_intertwiners_checked':True,'profile_finite_parts':profiles,'relative_profile_responses':differences,'numerical_controls':numeric,
 'general_Schwartz_distribution_limit_proved_by_zero_value_split':True,'common_existing_E_d_edge_candidate_constructed_without_fixing_d':True,'IR_delta_not_identified_with_UV_kappa_or_b0':True,'heat_placement_L1_term_retained':True,
 'momentum_divergence_contact':str(flux),'derivative_contraction_contact':str(contraction_contact),'pointwise_homogeneity_cannot_drop_contact':True,
 'controls':{'wrong_profile_power_changes_finite_IR_delta':True,'reference_and_ordinary_mass_words_differ':True,'all_nonzero_matrix_values_retained':True,'unmarked_heat_log2_not_a_Schwartz_delta_limit':True,'drop_fixed_divergence_contact_fails':True},
 'full_paired_action_source_zero_transfer_identity_or_constant_generator_domain_proved':False,'offflat_critical_products_full_measure_QAP_A5_E5_or_physical_scheme_adopted':False,
 'limitations':'Flat first-translation critical edge and complete zero-mean reference response-channel bound only;not full interacting/source/firstQ zero-transfer products,adiabatic/constant-vacuum/global or physical limits,full constant-generator identity,measure/QAP/A5/E5',
 'shared_limits':'Actual action/GF/source/primitive/reference/frames and inherited IR conventions,qualified channel bounds,Python/exact algebra/SymPy/mpmath and AI analyst;not external expert,experiment or Lean','elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);watch.cancel()
if __name__=='__main__':main()
