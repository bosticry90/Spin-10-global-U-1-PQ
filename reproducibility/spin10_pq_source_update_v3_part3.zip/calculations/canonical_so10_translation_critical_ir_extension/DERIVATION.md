# Actual critical translation edge and its infrared finite part

Prospective;complete native and separate validation required. All statements
are coefficientwise in the frozen Euclidean reference. No physical scheme,
vacuum,constant-generator theorem or complete QAP is adopted.

## Which regulated response is being differentiated

The actual provisional profiles have U_k=(1-exp(-P/epsilon^2))^(k/2),k1/2.
At flat background P=q^2 and F_t=exp(-t q^2). The covariance is
G_t,epsilon=U_k F_t G0 F_t^sharp U_k^sharp=chi_k exp(-2t q^2)G0.
Its inverse is U_k^-sharp F_t^-sharp K0 F_t^-1 U_k^-1. Matrix order and
graded inverse normalization are inherited and checked,not assumed scalar
before flattening. The actual constant scalar translation leaves P/U fixed.

For the ORDINARY local action insertion N=delta_tau Hghost,with the
reference fixed,Born differentiation gives

 delta_int G_t,epsilon=-G_t,epsilon N G_t,epsilon
             =chi_k^2 exp(-4t q^2) E/q^4.

Here E is the actual signed90-field response matrix,not an unknown fitted
coefficient. In contrast,variation of the REFERENCE covariance itself gives

 delta_ref G_t,epsilon=chi_k exp(-2t q^2) E/q^4,

whose inverse vertex contains chi_k^-1 exp(2t q^2)N. Those are different
regulated words. The finite-epsilon inverse equations hold with their OWN
vertices. Equating them without retaining the inverse-regulator response
would lose a real finite term. No singular inverse factor is multiplied by
a subtracted delta distribution;combine finite-epsilon identities first.

## General profile distribution

Put chi_base=1-exp(-q^2/epsilon^2),m a positive integer and
a_j=(-1)^j binomial(m,j). With dq/(2pi)^4 and f_s=exp(-s q^2),s>0,

 16pi^2 T_m,epsilon[f_s]=-sum_(j=0)^m a_j log(s+j/epsilon^2).

This is derived before expanding epsilon;the sum of a_j is0. Write
S_m=sum_(j=1)^m a_j log j. Then

 T_m,epsilon-log(nu^2/epsilon^2)delta*/(16pi^2)
   -> R_nu(q^-4)+(gamma_E-S_m)delta*/(16pi^2),

where R_nu[f_s]=[-gamma_E-log(s nu^2)]/(16pi^2). For every Schwartz f,
subtract f(0)exp(-s0 q^2). The remainder is O(|q|) at0 and Schwartz at
infinity,so its quotient by q^4 is integrable. Bounded profile convergence
and the exact Gaussian formula prove convergence in S',not just a test at
one Gaussian. The dimension-4 scaling-degree bound allows only a scalar
delta ambiguity at this critical degree. The candidate comparison to the
EXISTING E_d family is the explicit finite offset

 T_m,sub-E_d=(gamma_E-S_m-d+1)delta*/(16pi^2).

This leaves d arbitrary and fixed;it does not identify d with kappa/b0 or
show the full quantum construction requires a unique value. A common E_d
on all these edge components is a sufficient candidate if the inverse,
reality and H checks pass. It is not a new adopted IR prescription.

For k1/2 the interaction word requires m=2k and heat4t;the reference word
requires m=k and heat2t. Thus their subtracted difference is

 (exp(-2t q^2)-exp(-4t q^2))R_nu(q^-4)
                          +(S_(2k)-S_k)delta*/(16pi^2).

The first factor vanishes at0,so that term is an ordinary locally L1
kernel,independent of an IR-delta convention. On Schwartz tests it tends
to0 as t0. Its UNMARKED heat integral is log2/(16pi^2),not0. For f_s the
whole difference is

 [log((s+4t)/(s+2t))+S_(2k)-S_k]/(16pi^2).

Setting s0 before t0 is a separate unmarked UV diagnostic,not a distribution
limit on fixed Schwartz tests. Both the UV heat placement and IR delta
must remain. The two k profiles need not agree before their finite offsets
are matched;this is not a new physical normalization or an anomaly.

## Actual reference-response census

Reuse tau and N rather than measure another loop. Differentiate the entire
GF density with the actual tau and all643 actual master field rules. If the
complete GF variation is precisely the known C N antighost density and
every varied source rule has field degree<=1,then the source Hessian
variation is zero for arbitrary retained external J. No source is set0
before differentiating to obtain that fact.

Scan all34 physical Hessian programs at zero mean after one constant tau
replacement. Ordinary scalar derivatives of tau vanish. Graphs with any
remaining ordinary field vanish;only one un-differentiated Phi/Sigma
ordinary field can be replaced. Tensor contractions can make a coefficient
zero but cannot introduce a new channel. Keep them as upper bounds,not
new evaluated potential or physical Euler coefficients. Possible surviving
channels must be scalar/scalar with no momentum or B/scalar with one
momentum. If this census fails,report the actual extra channel.

The already qualified dressed ports are BB order2,Bx/xB order1,xx order0,
B/Lambda order1,and ghost order2. A B/x derivative insertion has maximal
response order2+1-1=2;an x/x zero-derivative insertion has maximal1+1=2.
The ghost mass has2+2=4. Thus the ghost sector is the ONLY potentially
critical reference response under those actual channel premises. This
does not prove all arbitrary interacting or doubly varied products are
covered by the same theorem.

## Inverse checks and the contact that must not be erased

Multiplication gives q^2 R_nu(q^-4)=1/q^2 and q^2 delta*=0. Therefore the
matrix edge extension satisfies BOTH linearized unheated inverse equations
for any real fixed d. Actual compact-H invariance and physical reality of
the mass/response matrix are checked. A nonzero N remains a nonzero response;
no coefficient is inferred from an inverse or a desired cancellation.

The retained distribution also obeys

 sum_mu partial_qmu[q_mu R_nu(q^-4)]=delta*/(8pi^2).

This follows from the normalized small-sphere flux and is independent of d.
If E_mu=-partial_mu E_d/4 is used for q_mu/q^6,then
sum q_mu E_mu=E_d-delta*/(32pi^2). Pointwise homogeneity would miss the
fixed contact. An extension cannot be assumed to preserve every divergent
pointwise derivative/contraction identity simultaneously. The full paired
Slavnov/source variation must retain such contacts before any promotion.

The result,if qualified,constructs the individual FLAT critical reference
edge and its actual relative profile matching. It does not by itself define
the whole constant-translation derivative of Gamma on Schwartz fields,
the paired off-flat/all-source zero-transfer identities,adiabatic or physical
vacuum limits,full QAP/measure/A5/E5. The full objective stays unchanged.
