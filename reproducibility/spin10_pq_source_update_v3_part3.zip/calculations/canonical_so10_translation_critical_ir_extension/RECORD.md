# Translation critical infrared response V1

TCI1;baseab13f917e551346e42079d45d7e1ca14e147167c,main.
Previous goal turn PROGRESS. The full constant-generator quantum theorem
remains unqualified. Investigate the next actual missing component,not an
easier translation-free generator. No result is assumed by this record.

Inputs:actual20-component scalar translation and complete57/2025 ghost
response from the qualified general_first_order_transport,actual physical
reference/dual frames,34 physical Hessian programs,complete GF/master-field
maps,and prescribed provisional chi_k=(1-exp(-P/epsilon^2))^k,k1/2.
The existing IR R_nu and spectral-mass family E_d=R_nu+(d-1)delta*/16pi^2
are fixed dependencies;do not choose d or identify it with kappa/b0.

Required mathematical and model-specific tests:
1.Recover the actual covariance U G_t U^sharp,its inverse and the ORDINARY
mass interaction N. Derive the number/placement of chi and positive-heat
factors for -G_epsilon N G_epsilon. Distinguish a variation of the reference
inverse,whose vertex is U^-sharp F^-sharp N F^-1 U^-1. Keep both;do not
replace the actual ordinary mass insertion by the reference variation.
2.Independently compute the critical scalar distribution for every actual
profile power required above. Prove its epsilon->0 subtraction on ALL
Schwartz tests by Gaussian reference plus integrable zero-value remainder.
Retain the logarithmic IR delta and finite delta matching to R_nu/E_d.
Native binomial/Frullani route versus Laplace/Mellin/Gamma route;separate
verifier direct radial quadrature and independent exact expansion.
3.Preserve the actual heat times. A difference of e^-2tp^2 and e^-4tp^2
is locally L1 at the origin but can have a nonzero unmarked UV heat trace.
Do not conflate that term with the finite momentum-origin delta. Check
Gaussian tests,their t->0 limits and the unmarked heat diagnostic separately.
4.Carry ALL57 actual response coefficients and1968 zeros,graded inverse,
reality and H invariance. No new loop amplitude or Gamma integration.
Check the two-sided UNHEATED inverse response after extension;finite-epsilon
inverse identities must be combined BEFORE multiplying an IR delta by a
singular inverse cutoff. Retain derivative/contraction IR contacts.
5.Census the COMPLETE zero-mean-field translation Hessian channels. Vary
the full GF and all643 source-field maps;compare the complete GF variation
to the known ghost bilinear and show whether source Hessian variation is0.
Inspect all34 physical Hessian programs:only possible B/x one-derivative
and x/x zero-derivative channels may remain at zero mean for the actual
Phi/Sigma translation support. Use channel bounds,not unknown numerical
potential coefficients. With qualified dressed scalar/M ports,establish
which reference responses can be critical. A failed channel premise stays
a gap;do not discard an adverse physical/Euler contribution.

The target is a qualified flat first-translation reference-edge extension
and its actual profile matching/completeness boundary. A shared scalar E_d
can be a sufficient candidate edge normalization,not a proved unique or
globally adopted prescription. Complete paired action/source identities,
off-flat critical products,zero-transfer/adiabatic functional limits,full
QAP/measure/A5/E5 and physical viability remain separate unless actually
proved. The known constant translation must NOT be dropped or absorbed
into an adopted physical vacuum. All failed/unfinished runs preserved.

Two sequential native120s after imports,independent180s;8GiB sampled-private,
350MiB launch floor,8MiB new package. Freeze types/proof/code/inputs and
role read ownership before workers. Primary versus replay own-role packets;
shared classical geometry/analysis inputs disclosed. No opposite-role native
scientific reads,no agents/outreach. Full captures before resource gates.
Validate before local commit;preserve main,old bytes,state113/34of39,
sevensfalse,source38,Gamma/source,295unmeasured,custody2/seven,quartet/scalar/
matching warnings,HB1/C5block,flavorpause. No push/publication/physical scheme.
Whole Spin(10)xPQ goal remains active;do not substitute this bounded target.
