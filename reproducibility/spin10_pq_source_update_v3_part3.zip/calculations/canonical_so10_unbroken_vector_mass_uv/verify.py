"""Separate plane-adjoint, pole, determinant and convergent-integral audit."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import gzip,json,os,threading,time
import sympy as s
import mpmath as mp
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
w=s.Symbol('w');g2,g4=s.symbols('g2 g4')
def clean(x):return s.cancel(s.expand(x))
def mat(v):return s.SparseMatrix(*v['shape'],{(i,j):s.sympify(x,locals={'w':w}) for i,j,x in v['entries']})
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def expr(v):return s.sympify(v,locals={'w':w,'g2':g2,'g4':g4})
def zero(M):assert all(clean(v)==0 for v in M.todok().values())

def plane_check(tab):
    B=packed(CAL/'canonical_so10_background_threshold_inputs/primary_tables.json.gz')
    G=s.SparseMatrix(45,45,{(i,j):s.sympify(x) for i,j,x in B['Gram']})
    V=mat(packed(CAL/'canonical_so10_vector_quartic_ir_matching/primary_tables.json.gz')['light_embedding'])
    E=[]
    for i,j in combinations(range(10),2):
        M=s.SparseMatrix(10,10,{(i,j):1/s.sqrt(2),(j,i):-1/s.sqrt(2)});E.append(M)
    charges=[]
    for col in [0,1,4]:
        h=sum((V[a,col]*E[a] for a in range(45) if V[a,col]),s.zeros(10));T=s.zeros(45)
        for b in range(45):
            C=h*E[b]-E[b]*h
            for a in range(45):T[a,b]=clean(s.trace(E[a].T*C))
        charges.append(T)
    W=[clean(-s.trace(T*T*G)/60) for T in charges]
    assert W==list(map(expr,tab['geometry']['W']))
    expected=s.diag(W[0],*([W[1]]*3),*([W[2]]*8));zero(mat(tab['geometry']['W_matrix'])-expected)
    # Direct QIR quartic operators independently bound to every ideal/matrix
    # entry, not only a final zero or a difference between two diagnostics.
    Q=packed(CAL/'canonical_so10_vector_quartic_ir_matching/primary_tables.json.gz')
    k=[0,s.Rational(1,200),s.Rational(1,40),s.Rational(5,12),s.Rational(253,600)]
    Mh=-3*sum((k[i]*mat(Q['mass_operators'][i]) for i in range(1,5)),s.zeros(45))
    zero(V.T*Mh*V+3*expected)
    for i,row in enumerate(tab['groups']):
        terms={n:expr(v) for n,v in row['terms'].items()}
        assert clean(terms['vector_quartic']+3*g4*W[i])==0
        assert clean(terms['vector_cubic']-s.Rational(9,2)*g4*W[i])==0
        assert clean(terms['ghost']+g4*W[i]/2)==0
        assert clean(terms['mixed_VS']+g4*W[i])==0
        Si=expr(tab['geometry']['S'][i])
        assert clean(terms['scalar_seagull']+g2*Si+g4*W[i])==0
        assert clean(terms['scalar_bubble']-g2*Si-g4*W[i])==0
        assert clean(sum(terms.values()))==0
        # Actual mutated sums. Nonzero controls retain symbolic parameters.
        controls={
          'omitted_mixed_VS_residual':sum(v for n,v in terms.items() if n!='mixed_VS'),
          'half_ghost_residual':sum(terms.values())-terms['ghost']/2,
          'wrong_mixed_product_residual':sum(terms.values())-2*terms['mixed_VS'],
          'wrong_scalar_seagull_residual':sum(terms.values())-terms['scalar_seagull']/2}
        for name,value in controls.items():assert clean(value-expr(row[name]))==0 and clean(value)!=0
    return [str(x) for x in W]

def block_scalar_check(tab):
    blocks=packed(CAL/'canonical_so10_finite_counterterm_insertion/replay_v3_tables.json.gz')['blocks']
    sums=[0,0,0];indices=[0,0,0];count=0
    for b in blocks:
        a,c,l,q=map(s.Integer,b['label']);dc=(a+1)*(c+1)*(a+c+2)/2;dw=l+1
        C=(a*a+c*c+a*c+3*a+3*c)/3
        tau=[q*q*dc*dw/60,dc*dw*l*(l+2)/12,dc*dw*C/8]
        trace=s.trace(mat(b['H']));count+=int(dc*dw*b['multiplicity'])
        for i in range(3):sums[i]+=tau[i]*trace/60;indices[i]+=tau[i]*b['multiplicity']
    assert count==328 and indices==[84]*3
    assert all(clean(a-expr(b))==0 for a,b in zip(sums,tab['geometry']['S']))

def finite_matrix_controls():
    mp.mp.dps=70;errors=[]
    for p in [mp.mpf('0.7'),mp.mpf('2.3')]:
        for a,b,m in [(mp.mpf('0.1'),mp.mpf('0.2'),mp.mpf('0.8')),(mp.mpf('-0.15'),mp.mpf('0.4'),mp.mpf('1.7'))]:
            P=mp.matrix([p,0]);k=mp.matrix([p+a,b]);q=k-P;x=m*m;t=(k.T*k)[0]+x;c=(P.T*k)[0]+x
            Kv=t*mp.eye(2)-k*k.T+P*P.T;K=mp.matrix(3,3)
            for i in range(2):
                for j in range(2):K[i,j]=Kv[i,j]
                K[i,2]=1j*m*q[i];K[2,i]=-1j*m*q[i]
            K[2,2]=t;want=t*c*c
            error=abs(mp.det(K)-want)/(1+abs(want));assert error<mp.mpf('1e-60');errors.append(error)
            # Reversing both phases is basis transport; NOT a sensitive test.
            for i in range(2):K[i,2]*=-1;K[2,i]*=-1
            assert abs(mp.det(K)-want)<mp.mpf('1e-59')
            # One wrong sign changes the product and is detected.
            for i in range(2):K[i,2]*=-1
            assert abs(mp.det(K)-want)>mp.mpf('1e-6')
            # Moving the gauge reference changes components, even if a
            # separately consistent background calculation also has zero mass.
            assert mp.norm(Kv-t*mp.eye(2))>mp.mpf('0.01')
    return mp.nstr(max(errors),12)

def radial_check():
    # Positive-mass common convergence strip, independent quadrature, no
    # scaleless integral and no subtraction of two divergent numeric integrals.
    mp.mp.dps=80;errors=[]
    for D in [mp.mpf('0.5'),mp.mpf('1.0')]:
        for x in [mp.mpf('0.3'),mp.mpf('1.7')]:
            A=mp.quad(lambda p:p**(D-1)/(p*p+x),[0,1,mp.inf])
            B=mp.quad(lambda p:p**(D-1)/(p*p+x)**2,[0,1,mp.inf])
            J=mp.quad(lambda p:p**(D+1)/(p*p+x)**2,[0,1,mp.inf])
            for v in [J-D*A/2,J-A+x*B]:
                e=abs(v)/(1+abs(A));assert e<mp.mpf('1e-30');errors.append(e)
            total=(D-1)*A/2-3*(1-1/D)*J/2+J/(2*D)-x*B/2+A/2-J/D
            assert abs(total)/(1+abs(A))<mp.mpf('1e-30')
    return mp.nstr(max(errors),12)

def main():
    start=time.perf_counter();timer=threading.Timer(240,lambda:os._exit(124));timer.daemon=True;timer.start()
    tab=packed(HERE/'primary_tables.json.gz');assert tab==packed(HERE/'replay_tables.json.gz')
    for role in ['primary','replay']:
        rec=json.loads((HERE/(role+'_result.json')).read_bytes());blob=(HERE/(role+'_tables.json.gz')).read_bytes()
        assert sha256(blob).hexdigest()==rec['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==rec['tables_sha256']
    weights=plane_check(tab);block_scalar_check(tab);deterror=finite_matrix_controls();radialerror=radial_check()
    receipt={'schema':'C1_UNBROKEN_VECTOR_MASS_UV_VALIDATION_V1','execution_state':'COMPLETED',
      'status':'QUALIFIED_COMPLETE_FIXED_REFERENCE_UNBROKEN_VECTOR_LOG_MASS_POLE_ZERO',
      'scientific_acceptance':'NOT_PERFORMED','scientific_authority':'34/39_UNCHANGED',
      'all12_actual_H_intertwiners_and_scalar_H_commutators_checked':True,
      'complete_light12x12_log_mass_matrix_zero':True,'all_coefficients_and_zero_complements_checked':True,
      'actual_mass_weight_W':weights,'actual_scalar_S':tab['geometry']['S'],
      'isolated_QUS_quartic_pole_reproduced_without_fitting':True,
      'sensitive_controls':['omitted_mixed_VS','half_ghost','one_mixed_phase','wrong_scalar_seagull','moving_GF_Hessian_components'],
      'insensitive_controls':tab['insensitive_controls'],
      'max_scaled_determinant_error':deterror,'max_scaled_convergent_radial_error':radialerror,
      'quantum_kinetic_curvature_counterterms_or_full_C1_qualified':False,
      'finite_physical_mass_or_regulator_scheme_adopted':False,'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(receipt,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
