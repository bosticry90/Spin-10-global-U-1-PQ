# UVM1 derivation proposed before execution

For h in H, T=ad_h, R=rho_h, Rv=0, RO=OT, [T,G]=[R,H]=0 and HO=0.
On each positive G eigenvalue lambda, O/sqrt(lambda) identifies its gauge
mode with a normalized Goldstone. Put x=g²lambda=m². The orthogonal scalar
complement has H and the unbroken scalar charge simultaneously reducible.
These properties must be checked against the actual physical matrices.

Take p=(p,0,...), charged momentum displacement kappa=(a,b,0,...),
k=p+kappa. For independent left/right amplitudes (u*,eta*) and(u,eta),
the exact quadratic densities are

    YM = 1/2 sum_mn (k_m u*_n-k_n u*_m)(k_m u_n-k_n u_m)
    kin = sum_m (-i k_m eta*+m u*_m)(i k_m eta+m u_m)
    gf = (-i p.u*+m eta*)(i p.u+m eta).

Thus Kv=(k²+x)I-kk^T+pp^T, Ks=k²+x,
K_v,s=i m(k-p), K_s,v=-i m(k-p)^T. Actual BFT1 ordered FP density gives
Kc=p.k+x. At Abar=0 the fixed gauge functional differentiates with p, not k.
The three-dimensional (p,kappa,Goldstone) determinant is t*c²,
t=k²+x,c=p.k+x; D-2 spectator vectors give detKvs=t^(D-1)c².
Hence (1/2)logdetKvs-logKc=(D-1)logt/2 locally near kappa=0.
For lambda=0 no Goldstone is adjoined: detKv=(k²)^(D-2)(p.k)².
Its ghost cancellation leaves(D-2)logk²/2. No global log branch is claimed.
The same algebra applies to any real antisymmetric charge matrix by its
orthogonal two-plane decomposition; neutral sectors are retained.

Independently expand Kv about kappa=0, with p·kappa=a0:
K1=2a0 I-p kappa^T-kappa p^T, K2=kappa²I-kappa kappa^T.
TrK1²=(4D-6)a0²+2p²kappa²; angular<a0²>=p²kappa²/D.
For t0=p²+x define A=integral1/t0, B=integral1/t0²,
Jp=integralp²/t0²=A-xB. Common convergence0<ReD<2 and x>0 gives
Jp=D*A/2 by radial integration by parts; boundaries vanish there, followed
by meromorphic continuation. Poles at D=4-2eps: A=-x/eps,B=1/eps,
Jp=-2x/eps in normalized ell units. No forbidden UV/IR scaleless shift.

The q² coefficients of Gamma per real charged gauge mode are

    vector seagull      (D-1)A/2
    vector cubic       -3(1-1/D)Jp/2
    ghost               Jp/(2D)
    mixed VS           -xB/2
    minimal Goldstone   A/2-Jp/D =0.

All sum to zero before expanding D. Every physical scalar similarly has
A/2-Jp/D with its own mass. With Gamma=q²Sigma/2 and kappa=g*charge*q,
the massive gauge-family UV Sigma residues/(ell g² x charge²) are
(-3,9/2,-1/2,-1,-1,+1), the last two being Goldstone seagull/bubble.

Model contractions: for normalized h_i define
W_i=Tr[-ad_hi² G]/60=sum_lambda lambda Tr[-ad_hi² P_lambda]/60,
S_i=Tr[-rho_hi² H]/60. Intertwining implies
Tr[-rho_hi² OO^T]/60=W_i. Scalar seagull/bubble in unitsell60/eps
are -(g² S_i+g4 W_i) and +(g² S_i+g4 W_i).
The four other families are g4 W_i*(-3,9/2,-1/2,-1).
Extract actual S_i independently through the full328 matrix and35 blocks,
with tau=(3Y² d3d2/5, d3 d2(d2²-1)/12, d2 d3 C3/8).
For each block TrH is over multiplicity, not representation dimension.
All12 H generators and full light matrices control ideal isotropy; do not
mistake historical unnormalized charge traces for physical Dynkin indices.

The isolated vector-seagull residue must equal QUS1's independently measured
light mass pole. Its cancellation requires the mixed and ghost terms. This
does NOT cancel QUS1's distinct light-internal curvature pole on a heavy
loop, complete other two-loop skeletons, or supply a quantum-field kinetic Z.

For massless sectors the large-p q² symbol is p^-2. It has a possible power
divergence but no4D logarithmic mass term. No finite p=0 amplitude, constant
vacuum limit or positive-mass convergence strip at x=0 follows.

Primary comparators: Martin--Patel, arXiv:1808.07615 (generalized gauge
fixing and effective potential, not this calculation); Martens,
arXiv:1011.2927v2 sections2.1--2.2 (separate gauge-width/field normalization,
not a replacement for the fixed-reference Hessian). These sources do not
certify the derived determinant or Spin(10) contractions; those are tested
here. Background beta=-46/3 is not substituted for quantum-vector Z.
