"""Fixed-reference quantum-vector mass logarithm: two bounded derivations."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import gzip,json,os,sys,threading,time
import sympy as s
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;CAL=ROOT/'calculations'
D=s.Symbol('D');w=s.Symbol('w');LOC={'w':w}

@lru_cache(200000)
def clean(v):return s.cancel(s.expand(v))
def tidy(M):return s.SparseMatrix(M).applyfunc(clean)
def zero(M):assert not tidy(M).todok(),'NONZERO_MATRIX'
def packed(p):return json.loads(gzip.decompress(p.read_bytes()))
def mat(x):return s.SparseMatrix(*x['shape'],{(int(i),int(j)):s.sympify(v,locals=LOC) for i,j,v in x['entries']})
def enc(M):
    M=tidy(M);return {'shape':list(map(int,M.shape)),'entries':[[int(i),int(j),str(v)] for (i,j),v in sorted(M.todok().items())]}
def tr(M):return clean(s.trace(M))
def string(v):return str(clean(v))

def scalar_charge(physical,h):
    entries={};off=0
    for sector in ['Phi','Sigma','phi','S']:
        for a in range(45):
            if not h[a]:continue
            for i,j,v in physical['representation_matrices'][sector][a]['entries']:
                key=(off+int(i),off+int(j));entries[key]=entries.get(key,0)+h[a]*s.sympify(v)
        off+=physical['sector_dimensions'][sector]
    assert off==328
    return tidy(s.SparseMatrix(328,328,entries))

def weights(label):
    a,b,l,q=map(s.Integer,label);d3=(a+1)*(b+1)*(a+b+2)/2;d2=l+1
    C3=(a*a+b*b+a*b+3*a+3*b)/3
    return [s.Rational(3,5)*(q/6)**2*d3*d2,d3*d2*(d2*d2-1)/12,d2*d3*C3/8]

def geometry(role):
    B=packed(CAL/'canonical_so10_background_threshold_inputs'/f'{role}_tables.json.gz')
    f={(int(a),int(b),int(c)):s.sympify(v) for a,b,c,v in B['f']}
    ad=[s.SparseMatrix(45,45,{(c,b):v for (a,b,c),v in f.items() if a==h}) for h in range(45)]
    G=s.SparseMatrix(45,45,{(i,j):s.sympify(v) for i,j,v in B['Gram']})
    O=s.SparseMatrix(328,45,{(i,j):s.sympify(v) for i,j,v in B['orbit']})
    P=list(map(mat,packed(CAL/'canonical_so10_width_hard_projection'/f'{role}_tables.json.gz')['projectors']))
    V=mat(packed(CAL/'canonical_so10_vector_quartic_ir_matching'/f'{role}_tables.json.gz')['light_embedding'])
    physical=json.loads((ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1/frozen_a10_physical_reconciliation'/f'full_{role}.json').read_bytes())
    v=mat(physical['vacuum']['VEV'])
    H=mat(packed(CAL/'canonical_so10_scalar_quadratic_pullback'/f'{role}_tables.json.gz')['matrices']['H'])
    zero(H-H.T);zero(O.T*O-G);zero(H*O);zero(G*V);zero(O*V)
    zero(V.T*V-s.eye(12));zero(V*V.T-P[0]);zero(sum(P,s.zeros(45))-s.eye(45))
    lam=[0,s.Rational(3,10),s.Rational(3,2),25,s.Rational(253,10)]
    for j,Q in enumerate(P):zero(G*Q-lam[j]*Q);zero(Q*Q-Q)
    Ts=[];Rs=[]
    for j in range(12):
        print('STAGE actual_H_generator_'+str(j),flush=True)
        h=V[:,j];T=tidy(sum((h[a]*ad[a] for a in range(45) if h[a]),s.zeros(45)));R=scalar_charge(physical,h)
        zero(T+T.T);zero(R+R.T);zero(R*v);zero(R*O-O*T);zero(T*G-G*T);zero(R*H-H*R)
        assert tr(-T*T)==8 and tr(-R*R)==84
        Ts.append(T);Rs.append(R)
    Wmat=s.SparseMatrix(12,12,{(i,j):tr(-Ts[i]*Ts[j]*G)/60 for i in range(12) for j in range(12)})
    Wmat=tidy(Wmat);probes=[0,1,4];W=[Wmat[i,i] for i in probes]
    zero(Wmat-s.diag(W[0],*([W[1]]*3),*([W[2]]*8)))
    old=packed(CAL/'canonical_so10_vector_quartic_uv_subgraphs'/f'{role}_tables.json.gz')
    assert old['light_mass_poles_in_ell60g4_units']==[string(-3*x) for x in W]
    if role=='primary':
        S=[tr(-Rs[i]*Rs[i]*H)/60 for i in probes]
        charges=[[tr(-Ts[i]*Ts[i]*Q) for Q in P] for i in probes]
    else:
        small=packed(CAL/'canonical_so10_finite_counterterm_insertion'/f'{role}_v3_tables.json.gz')['blocks']
        assert len(small)==35
        S=[clean(sum((weights(b['label'])[i]*tr(mat(b['H'])) for b in small),s.Integer(0))/60) for i in range(3)]
        # Spectral generator norms instead of the primary trace contraction.
        charges=[[clean(sum((x*x for x in tidy(Q*Ts[i]).todok().values()),s.Integer(0))) for Q in P] for i in probes]
    for i in range(3):
        assert clean(sum(lam[j]*charges[i][j] for j in range(5))/60-W[i])==0
        assert sum(charges[i])==8
        assert clean(tr(-Rs[probes[i]]*Rs[probes[i]]*O*O.T)/60-W[i])==0
    return {'W_matrix':enc(Wmat),'W':[string(x) for x in W],'S':[string(x) for x in S],
      'charge_squared_by_mass':[[string(x) for x in row] for row in charges],
      'mass_eigenvalues':list(map(str,lam)),'ranks':[int(s.trace(Q)) for Q in P],
      'H_Goldstone_kernel_and_all12_intertwiners_checked':True,
      'all12_scalar_charge_indices':[84]*12,'all12_adjoint_charge_indices':[8]*12}

def kernels(role):
    p,a,b,m=s.symbols('p a b m',real=True);kk=s.Matrix([p+a,b]);pp=s.Matrix([p,0]);kap=kk-pp
    t=(kk.T*kk)[0]+m*m;c=(pp.T*kk)[0]+m*m
    Kv=t*s.eye(2)-kk*kk.T+pp*pp.T
    K=Kv.row_join(s.I*m*kap).col_join((-s.I*m*kap.T).row_join(s.Matrix([[t]])))
    if role=='primary':
        left=s.symbols('ubar0 ubar1 etabar');right=s.symbols('u0 u1 eta');ub=s.Matrix(left[:2]);u=s.Matrix(right[:2]);eb=left[2];eta=right[2]
        YM=sum((kk[i]*ub[j]-kk[j]*ub[i])*(kk[i]*u[j]-kk[j]*u[i]) for i in range(2) for j in range(2))/2
        kin=sum((-s.I*kk[i]*eb+m*ub[i])*(s.I*kk[i]*eta+m*u[i]) for i in range(2))
        gf=(-s.I*(pp.T*ub)[0]+m*eb)*(s.I*(pp.T*u)[0]+m*eta)
        derived=s.Matrix(3,3,lambda i,j:s.diff(YM+kin+gf,left[i],right[j]));zero(derived-K)
        assert clean(derived.det()-t*c*c)==0
    else:
        for N in [3,4,5]:
            P=s.Matrix([p]+[0]*(N-1));q=s.Matrix([a,b]+[0]*(N-2));aa=(P.T*q)[0]
            K1=2*aa*s.eye(N)-P*q.T-q*P.T;K2=(q.T*q)[0]*s.eye(N)-q*q.T
            assert clean(s.trace(K2)-(N-1)*(q.T*q)[0])==0
            assert clean(s.trace(K1*K1)-((4*N-6)*aa*aa+2*(P.T*P)[0]*(q.T*q)[0]))==0
        # Schur determinant independently retains both mixed products.
        assert clean(Kv.det()*t-t*c*c-m*m*(a*a+b*b)*t)==0
        assert clean(Kv.det()*t-(((-s.I*m*kap.T)*Kv.adjugate()*(s.I*m*kap))[0])-t*c*c)==0
    assert clean(Kv.det()-(c*c+m*m*(a*a+b*b)))==0
    massless=Kv.subs(m,0);assert clean(massless.det()-((pp.T*kk)[0])**2)==0
    A,B=s.symbols('A B');J=A-m*m*B
    parts={'vector_quartic':(D-1)*A/2,'vector_cubic':-s.Rational(3,2)*(1-1/D)*J,
      'ghost':J/(2*D),'mixed_VS':-m*m*B/2,'scalar_seagull':A/2,'scalar_bubble':-J/D}
    # This identity is exact on J=D*A/2, not merely at D=4.
    total=clean(sum(parts.values()).subs(B,(1-D/2)*A/(m*m)))
    assert total==0
    poles={name:string(2*s.limit(clean(value.subs({A:-m*m,B:1})),D,4)/(m*m)) for name,value in parts.items()}
    return {'determinant3':s.factor(K.det()).__str__(),'ghost':str(c),
      'mass_pole_coefficients':poles,'total_after_meromorphic_IBP':'0',
      'spectator_power_massive':'D-2','spectator_power_massless':'D-2',
      'massless_log_mass_coefficient':'0','source':'fixed_reference_bilinear_densities'}

def coefficients(g,k):
    rows=[];poles=k['mass_pole_coefficients'];g2,g4=s.symbols('g2 g4')
    for name,W,S in zip(['U1','SU2','SU3'],map(s.sympify,g['W']),[s.sympify(x,locals=LOC) for x in g['S']]):
        terms={n:clean(g4*W*s.sympify(poles[n])) for n in ['vector_quartic','vector_cubic','ghost','mixed_VS']}
        terms['scalar_seagull']=-g2*S-g4*W;terms['scalar_bubble']=g2*S+g4*W
        assert clean(sum(terms.values()))==0
        assert W!=0 and S!=0
        rows.append({'group':name,'terms':{n:string(v) for n,v in terms.items()},'total':'0',
          'omitted_mixed_VS_residual':string(-terms['mixed_VS']),
          'half_ghost_residual':string(-terms['ghost']/2),
          'wrong_mixed_product_residual':string(-2*terms['mixed_VS']),
          'wrong_scalar_seagull_residual':string(-terms['scalar_seagull']/2)})
    return rows

def main():
    start=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
    role=sys.argv[1];assert role in ['primary','replay']
    geom=geometry(role);print('STAGE density_or_Taylor',flush=True);kern=kernels(role)
    out={'schema':'C1_UNBROKEN_VECTOR_MASS_UV_TABLES_V1','geometry':geom,'kernels':kern,
      'groups':coefficients(geom,kern),'units':'Sigma pole = ell*60/eps times terms; g2=g10²,g4=g10^4',
      'scope':'local_logarithmic_mass_only_fixed_reference_xi1',
      'insensitive_controls':['both_mixed_signs_reversed','minimal_scalar_omitted_total','moving_GF_reference_total_zero']}
    raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(raw,mtime=0)
    with (HERE/(role+'_tables.json.gz')).open('xb') as f:f.write(blob)
    result={'schema':'C1_UNBROKEN_VECTOR_MASS_UV_NATIVE_V1','execution_state':'COMPLETED',
      'tables_sha256':sha256(raw).hexdigest(),'packed_sha256':sha256(blob).hexdigest(),
      'raw_bytes':len(raw),'packed_bytes':len(blob),'elapsed_after_imports':time.perf_counter()-start}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
