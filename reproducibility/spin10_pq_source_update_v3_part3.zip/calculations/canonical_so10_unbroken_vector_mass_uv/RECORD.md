# UVM1 bounded execution contract, frozen before calculation

Question: Does the complete one-loop gauge/scalar/ghost quantum-vector mass
UV logarithm cancel on the unbroken H subspace, and how does the nonzero
isolated QUS1 vector-quartic pole participate? This is a dependency of the
finite C1_GS parent-subtraction problem, not a new physical scheme.

Base765e8eba36ddb443358811065b9f861713ae5e23/main. Sole authority113,34/39,
stateSHA d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8.
No acceptance/promotion, state/action/point/width/finite-normalization changes,
branch, push, publication, outreach or blocked-stage activation.

Types: BFT1 physical598-coordinate one-loop 1PI Gaussian after45auxiliary
Gaussian integrations;328 real scalars,45 real vectors,45 ordered complex
ghost pairs. xi=1, Abar=0, fixed gauge-fixing O,v. External CONSTANT QUANTUM
Q_mu=q_mu h along H, used only to extract local UV q^2 density. It is not
a constant-vacuum physical limit, a kinetic threshold, or Abar=Q. g>0,
dimensional regularization D=4-2eps, ell=1/(16pi²), positive heavy masses.
H potential Hessian, G=O^T O, W=OO^T. No fermions or historical643 reference
substitution. Preserve massless UV/IR distinction and negative ghost trace.

Immutable inputs: BFT1 primary/replay tensors and derivation; SQP1 fullH;
FCI1 35 scalar multiplicity blocks; physical representation matrices/VEV;
WHP1 five vector projectors; QIR1 light embedding; QUS1 pole comparison.
preparation.json hashes direct inputs, frozen code/proof and authenticated
nested preparations. All25467 old Git blobs preserved, full captures external.

Before computation: freeze this contract, DERIVATION, prepare/run, native and
verifier sources. Each native <=180s, verifier<=240s after imports, daemon
hard timer; captured8GiB private sampled cap,350MiB launch commit floor,
package<=4MiB. Full captures and failures retained. One successful exclusive
native command and one validation command under these output names. Repairs
must have new frozen versions; resource expiry is incomplete, not a verdict.

Primary: derive finite-dimensional Hessian from Yang-Mills, scalar kinetic
and fixed-gauge bilinear densities; exact3x3 determinant reduction with
spectator dimensions retained. Actual full328 scalar H charge trace.
Replay: direct momentum Taylor expansion of vector/scalar/ghost and mixed
blocks, derive trace coefficients at independent Lorentz dimensions, then
meromorphic radial masters. Scalar trace via35 SM multiplicity blocks.
Both: actual O/G/H invariance and intertwining checks for all12 H generators;
normalized Y,weak,color probes; actual massive spectral weights/zeros.
Independent verifier: reconstructed fundamental10-plane adjoint weights,
all tabulated poles/zero complements, full12x12 light mass matrices, numerical
nontrivial determinant tests and convergent positive-mass radial integration.

Admissibility: for x>0 use common0<ReD<2 convergence domain for A and Jp,
then meromorphic continuation. Never shift an undefined TraceLog integral.
Massless q² symbols have p^-2 degree and no4D p^-4 log-mass term; this is not
a finite scaleless-amplitude zero or positive-mass IR proof at x=0.

Controls: omitted mixed VS block; half ghost weight; wrong mixed product;
wrong scalar coefficient; shifted GF reference distinguished at Hessian/
component level even if TOTAL ZERO insensitive. Reversing both mixed signs
is a scalar-basis change and insensitive. Deleting a separately canceling
minimal scalar block is also total-mass-insensitive. Neutral massive modes
alone cannot test charged errors. Compare vector quartic to QUS1 actual pole,
not to a value inferred from cancellation. No fitted unknown coefficient.

Success: both derivations, actual model traces and verifier agree on complete
UV mass coefficients and reconcile QUS1 isolated pole. Nonzero complete pole
would require investigation, not automatic anomaly. Incomplete inputs/domain
or resource failures remain explicit. Do not infer full quantum-vector
kinetic/curvature counterterms, UV forest, finite C1, full QAP/E5/A5 or physical
mass/gauge-independent observable from this mass-only calculation.

Track B: assess structural reduction and sensitive controls using existing
records; shared action/point/representations/SymPy/runtime/AI authorship remain.
No external scientific validation or Lean certificate. Director education
nonblocking. Historical quartet FAIL3960/648, custody exit2/seven, HB1/C5
blocked, flavorpaused, scalar140%/1.94%/20.27%, matching.745476 remain distinct.
