# After UVM1: reconcile quantum-vector derivative and curvature normalization

UVM1 qualified the complete unbroken quantum-vector log mass pole as zero,
including its nonzero scalar, mixed and ghost companions. No physical input
changed. Do not repeat it, reinterpret it as the historical quartet repair,
or treat mass zero as a kinetic threshold result.

Finite C1_GS still needs a complete UV forest. QUS1 opened the vector-quartic
proper subgraph and retained its light-internal curvature pole. The full
parent quantum-vector UV kernel, rather than that isolated graph, must be
matched to the prescribed counterterm Hessian. UVM1 only closes its light
mass-jet compatibility question. Curvature insertions are not mass insertions.

Smallest justified continuation: derive the local TWO-DERIVATIVE quantum-vector
UV pole at fixed Abar/GF reference, starting with the source-zero finite-momentum
two-point coefficient, then determine the precise additional background-
curvature input needed. Freeze the actual vertex/Hessian and predecessor census
before integrations. Use external momentum to separate p² poles from the
already checked mass coefficient; preserve longitudinal and transverse tensors,
ordered ghosts, real scalar weights and gauge-width counterterm slots.

The derivative pole is mass-independent by local power counting only after
its positive-mass infrared definition or explicit nonzero-momentum integral
has been justified. Do not equate a scaleless integral with a UV zero. Derive
the model-specific coefficients from CA=8 and real scalar index84 with their
actual normalization, not from a beta coefficient selected to cancel QUS1.
Background-field and quantum-field Z are distinct.

Background covariance allows more than one FQQ/ordered-derivative structure.
If the finite-momentum two-point coefficient does not uniquely fix the full
background-curvature pole, identify and calculate the smallest actual AQQ
projection or covariant open-Hessian trace needed; do not infer its coefficient
from Ward cancellation alone. Keep source/GF/width normalization requirements
and admissible operator identities explicit. A joint covariant-symbol method
is acceptable if it independently measures all derivative-order slots.

Compare the resulting full parent kernel with FCI1 and QUS1 by topology,
normalization and exact-once subtraction, preserving evanescent finite pieces
on the remaining heavy loop. Do not add a newly measured insertion twice or
adopt a new finite mass/VEV/tadpole scheme. No convenient C2 fitted to a residual.

The bounded question is whether the still-visible curvature subtraction is
resolved by the complete parent kernel and existing normalization, needs a
missing measured coefficient, or exposes an underdefined operator condition.
None of those outcomes alone establishes an anomaly or full C1_GS. After this
dependency is settled, return to a genuinely missing hard two-loop family.

Retain main, old evidence, state113/34of39, finiteC1null, fullE5/A5unqualified,
HB1/C5blocked, flavorpaused, historicalquartetFAIL/custodyexit2seven, physical
scalar/gauge-control limitations and the qualified bounded causal framework.
