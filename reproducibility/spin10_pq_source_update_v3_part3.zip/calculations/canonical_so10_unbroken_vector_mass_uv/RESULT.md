# UVM1 result: the complete unbroken quantum-vector log mass pole cancels

Execution COMPLETED; qualified bounded computational/derivation result.
Scientific acceptance NOT_PERFORMED. Sole authority113,34/39 unchanged.
Base765e8eba36ddb443358811065b9f861713ae5e23/main. This increment implements
V400's smallest next test within the continuing finite C1_GS investigation.
It preserves the supplied review's priority: resolve actual matching and
subtraction dependencies before enlarging the formal framework.

The complete one-loop gauge/scalar/ghost contribution has ZERO logarithmic
quantum-vector mass pole on the12-dimensional unbroken H subspace, for the
BFT1 physical source-zero reference at xi=1. This is not a finite physical
mass calculation, kinetic threshold, arbitrary-width result or E5 theorem.

## What cancels

The previous QUS1 isolated vector-quartic pole was nonzero and remains so.
No measured value was changed. At fixed Abar=0 and fixed gauge-fixing O,v,
the complete one-loop Hessian also contains vector-cubic, ordered ghost,
mixed vector--Goldstone, and scalar seagull/bubble contributions.

Define W_i=Tr[-ad_hi² G]/60 for normalized Y,weak,color probes. Actual values:

    W=(1309/600,503/200,1009/600).

In units ell60 g10^4/eps, the four gauge/mixed residues are

| One-loop family | Coefficient |
| --- | --- |
| vector quartic seagull | -3 W_i |
| two vector cubic vertices | +(9/2) W_i |
| ordered complex ghost loop | -(1/2) W_i |
| mixed vector--Goldstone loop | -W_i |
| sum | 0 |

The first row reproduces QUS1 exactly: (-1309,-1509,-1009)/200.
Scalar seagull and bubble residues are separately nonzero and opposite:

    Sigma_scalar/(ell60/eps)=
      -(g10² S_i+g10^4 W_i)+(g10² S_i+g10^4 W_i)=0,
    S_i=Tr[-rho_hi² H]/60.

Both representations reproduce the actual full scalar traces:

    S_Y =2w-2744357 sqrt15/1500000000+1115700266551/60000000000,
    S_2 =2w-12136121 sqrt15/500000000+350263945557/20000000000,
    S_3 =2w+11937913 sqrt15/375000000+1213062911371/60000000000.

w is the unchanged inherited scalar-point parameter. It was not solved anew
or adjusted. The gauge-orbit scalar mass g10² OO^T is retained, not replaced
by the zero of its potential mass. All other scalar masses are included in H.

## Why the reduction is complete within this target

The six families above exhaust the second quantum-vector variation of the
one-loop Gaussian determinant. Scalar self-interactions enter through the
actual H; no independent one-loop scalar-potential vertex is missing in this
1PI two-point coefficient. Ghost--scalar diagrams with an extra scalar loop
are not one-loop two-point graphs. Auxiliary integration is the prescribed
BFT1 Gaussian, not a deletion of physical mixed terms.

For all12 actual H generators, the calculation verifies Rv=0, RO=OT,
[T,G]=0, [R,H]=0, HO=0, antisymmetry and scalar/adjoint indices84/8.
It retains all five gauge masses, ranks(12,8,1,12,12). Charge-square traces
in that order are

    Y:    (0,14/5,0,5,1/5),
    weak: (2,0,0,3,3),
    color:(3,1,0,2,2).

The full12x12 W matrix is diag(W_Y,W_2 I3,W_3 I8), including its off-diagonal
zero complement. Any H combination inherits the verified intertwining and
commutators by linearity. The determinant proof applies to its antisymmetric
charge two-planes. Polarization therefore establishes the entire12x12 zero
mass matrix; it does not merely check three selected numerical directions.

In a massive color/Goldstone two-plane, differentiating the actual quadratic
densities gives Kv=tI-kk^T+pp^T, Ks=t, mixed blocks +/-i sqrt(x)(k-p),
and ordered ghost c=p.k+x. Its exact3x3 determinant is t*c²; spectator
vectors yield t^(D-1)c². The ghost cancels c² with its correct weight.
The result is(D-1)log(t)/2, not a guessed covariant completion.

The replay independently expands both vector vertices and the mixed Hessian
product, deriving their tensor traces at independent Lorentz dimensions.
For positive x, the common convergent radial domain0<ReD<2 establishes
Jp=D A/2 and Jp=A-xB before meromorphic continuation. The full coefficient
cancels already at general D. No shift of an undefined TraceLog integral is
used. In massless sectors the q² symbol has degree p^-2 and no4D log-mass
coefficient; no complete finite scaleless amplitude or IR theorem follows.

## Validation and limitations of its controls

Primary uses the density Hessian/determinant and actual full328 scalar H.
Replay uses momentum Taylor traces and35 SM multiplicity-block scalar traces.
Both calculate against their own authenticated primary/replay input records.
Separate validation rebuilds the adjoint from fundamental10-plane commutators,
checks actual spectral weights, each family coefficient and the full light
quartic matrix against QIR/QUS evidence, and independently checks scalar traces.

Omitting the mixed block leaves +g10^4 W, half ghost weight leaves
+g10^4 W/4, and a wrong mixed product leaves +2g10^4 W. A wrong scalar
seagull also leaves a nonzero symbolic remainder. These are actual mutated
sums, not simply nonzero-value diagnostics. One reversed mixed phase changes
the finite determinant and is detected.

Reversing BOTH mixed phases is a scalar basis change and is INSENSITIVE.
Deleting an entire separately canceling minimal scalar determinant is also
INSENSITIVE to total mass zero. Moving the gauge reference can give another
zero mass result; it is detected here by its changed Hessian components,
not claimed detectable from the final zero. These limitations stay explicit.

Convergent radial quadrature at80 digits has maximum scaled error
1.73432057395e-43, tolerance1e-30. Nontrivial finite-matrix determinant
tests at70 digits have maximum scaled error1.96464902477e-71,
tolerance1e-60. These numerical controls supplement the exact proof.

Shared action, point, representations, symbolic software, runtime and AI
authorship remain shared-error limits. No external scientist, empirical test
or Lean theorem certificate independently validates these premises. Literature
comparators in DERIVATION.md do not calculate these model contractions.

## Evidence and execution

Frozen sources/proof/assumptions and2238 input bindings preceded computation.
Commands (COMPLETED; do not rerun exclusive output names):

    python -B calculations/canonical_so10_unbroken_vector_mass_uv/prepare.py
    python -B calculations/canonical_so10_unbroken_vector_mass_uv/run.py native
    python -B calculations/canonical_so10_unbroken_vector_mass_uv/run.py validate

Native elapsed-after-imports8.5222634s and7.5109060s; verifier2.5574399s.
Caps180/180/240s,8GiB sampled private limit,350MiB commit launch floor,
package4MiB. Private samples5/5/2; observed maxima65519616/61272064/48218112B.
These sampled values are not continuous peak-memory bounds. No failed
scientific worker, verifier, resource exhaustion or unfinished run.

Tables3378 raw/1111gzip bytes, identical across both methods.
RawSHA bb3562845baf2bef46c90fe7ef4787bbf0793ba3462eb6c717219bf23cd876ec.
GzipSHA5a058e71512e8a158faddf3aa2c4387e427c7a077d10f08e4176ffe2448cce24.
Final validation_receipt.json SHA
e571242000c0aecb465be4639d6939f0bfdbac7fb5b21961cb2a3da1607c2f95.
Status QUALIFIED_COMPLETE_FIXED_REFERENCE_UNBROKEN_VECTOR_LOG_MASS_POLE_ZERO.
The receipt qualifies this bounded derivation, not director scientific acceptance.

Delegated research_check.py e4 completed all6 expected-exit checks without a
fresh old scientific replay. Historical custody remains exit2/seven unresolved,
not PASS. External control/captures:
C:/Users/psboy/.codex/research-control-records/ToE-Next/
unbroken-vector-mass-uv-v1-2026-10-20. All25467 old Git blobs must remain
unchanged, and new raw/index/HEAD bytes must match before/after local commit.

## Consequence and next smallest action

The previously isolated light mass pole is now reconciled with a complete
one-loop sum. It does not require a new unbroken-vector mass counterterm.
This is compatible with the existing FCI1 mass jet's zero light block; it
does not by itself validate all its heavy blocks or field normalization.

QUS1's DIFFERENT light-internal curvature contribution on a heavy external
loop remains. The complete quantum-vector two-derivative/background-curvature
UV kernel and its parent normalization must be reconciled before completing
that UV forest. Background beta_GS=-46/3 is not quantum-vector wavefunction Z.
Do not remove the residual by fitting a convenient local C2 or count QUS1
insertions again on top of FCI1. NEXT_RESEARCH_QUESTION.md defines the next test.

No full C1_GS, gauge unification, arbitrary-width independence, full QAP/E5/A5
or physical viability follows. Historical quartet FAIL3960/648 and custody
exit2/seven are unaffected. HB1/C5blocked, flavorpaused, finiteC1null,
scalar140%/1.94%/20.27%, gauge mismatch.745476 and missing Yukawas stay distinct.
Bounded causal one-loop results are retained, not reopened or silently promoted.
