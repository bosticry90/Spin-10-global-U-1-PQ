from pathlib import Path
from hashlib import sha256
import json,time,threading,os
import mpmath as mp
from inputs import read,block_inputs,root,nm,number
D=Path(__file__).resolve().parent
def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=read(D/'matrix_diagnostic_preparation.json')
 for n,h in prep['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
 mp.mp.dps=100;old=mp.matrix(2,2,lambda i,j:1+i+2*j);correct=mp.matrix([[1+i+2*j for j in range(2)] for i in range(2)])
 assert old==mp.zeros(2) and correct!=old
 work,cc,q,quad,packet,radial=block_inputs('replay');ww=root(quad);oldcounts=[0,0];newcounts=[0,0];rows=[]
 for row,H,Ds,metric in work:
  sq=[mp.sqrt(number(z).real) for z in metric];original=nm(H,ww)
  previous=mp.matrix(H.rows,H.cols,lambda i,j:original[i,j]/(sq[i]*sq[j]))
  amended=mp.matrix([[original[i,j]/(sq[i]*sq[j]) for j in range(H.cols)] for i in range(H.rows)])
  ea=mp.eighe(previous,eigvals_only=True);eb=mp.eighe(amended,eigvals_only=True)
  ca=[sum(x>mp.mpf('1e-4') for x in ea),sum(abs(x)<mp.mpf('1e-60') for x in ea)]
  cb=[sum(x>mp.mpf('1e-4') for x in eb),sum(abs(x)<mp.mpf('1e-60') for x in eb)]
  for j in range(2):oldcounts[j]+=row['dimension']*ca[j];newcounts[j]+=row['dimension']*cb[j]
  rows.append({'label':row['label'],'old':ca,'corrected':cb,'old_norm':str(max(abs(z) for z in previous)),'corrected_norm':mp.nstr(max(abs(z) for z in amended),20)})
 assert oldcounts==[0,328] and newcounts==[290,38]
 out={'schema':'UTP_MATRIX_CONSTRUCTOR_DIAGNOSTIC_V1','old_positive_zero_real':oldcounts,'corrected_positive_zero_real':newcounts,
 'small_literal_wrong_constructor_is_zero':True,'physical_inputs_and_tolerances_unchanged':True,'rows':rows,'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
