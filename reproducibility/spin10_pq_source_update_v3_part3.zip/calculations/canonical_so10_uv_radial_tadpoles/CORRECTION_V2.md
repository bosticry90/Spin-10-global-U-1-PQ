# UTP1 V2 — explicit mpmath matrix construction

Original exact primary COMPLETED; original spectral replay FAILED with exit1
at the290positive/38zero count. Complete original source/preparation/capture
remain unchanged. A separately frozen diagnostic demonstrated that
mpmath.matrix(n,n,lambda...) silently constructs a zero matrix: the original
route obtained0positive/328zero. Explicit list-of-lists construction gives
290positive/38zero for the same inputs,100digits and thresholds.

The proposed corrected pilot_v2.py was hash-frozen before that diagnostic.
It changes exactly the two canonical H/D numerical matrix constructors and
the preparation filename. It does not change operator entries, coupling or
coordinate normalization, polynomial formulas, precision, tolerance, zero
census or resources. The successful original primary uses exact SymPy traces
and is unaffected; authenticate and reuse its completed result rather than
repeat it. Rerun only the failed spectral route under V2 preparation.

Reuse the separate verifier with a V2 preparation binding and explicit count
of one failed native worker. No scientific verifier has yet run. One failed
prelaunch Python -c preparation invocation (shell quotation SyntaxError) is
also preserved in diagnostic_launch_parse_failure.txt and the tool record;
it launched no scientific worker. Preparation now executes a saved file.
The native API error and prelaunch orchestration error remain Track B limits.

Acceptance/resources are unchanged: native120s/verifier180s after imports,
8GiB sampled private,350MiB launch floor,4MiB package;100digit native1e-50
agreement and inherited float verification tolerances. Save full V2 captures
before assertions; compare completed original-primary/corrected-replay before
verification. No old finite loop rerun, input adoption or authority promotion.
