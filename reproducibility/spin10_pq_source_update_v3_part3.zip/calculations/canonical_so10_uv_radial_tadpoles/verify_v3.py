"""Independent fixed-parameter trace, exact orbit and Gaussian pole checks."""
from pathlib import Path
from hashlib import sha256
from functools import lru_cache
import json,sys,time,threading,os
import sympy as s
import numpy as np
import mpmath as mp
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent;C=R/'calculations'
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
sys.path.insert(0,str(C/'canonical_so10_higgs_stationary_tangent'))
from model import Model,SLOTS,norm,fd4
@lru_cache(None)
def clean(z):return s.cancel(s.expand(z))
def mat(row):return s.SparseMatrix(*row['shape'],{(i,j):s.sympify(z) for i,j,z in row['entries']})
def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=json.loads((D/'validation_preparation_v3.json').read_bytes())
 for n,h in prep['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
 M=Model();base,dc=M.parameters(M.q0,M.m0);cv=[]
 for slot in SLOTS:
  n,sep,part=slot.partition(':');v=base[n];cv.append(float(v.imag if part=='im' else np.real(v)))
 cv=np.array(cv);scalar=np.zeros(3);wrong_stationary=np.zeros(3);shapes=0;realcount=0
 def fixedH(label,q):
  scales=q/np.array([np.sqrt(60),4*np.sqrt(2),np.sqrt(2)]);meta=M.metadata[label]
  res=np.prod(scales[None,:]**M.nslot,axis=1);raw=np.einsum('k,kij->ij',cv*res,M.cache[label])
  factors=np.array([scales[j] if j>=0 else 1 for j in meta['ids']]);g=meta['unit_metric']*factors*factors
  return raw/np.sqrt(g[:,None]*g[None,:])
 for label in M.cache:
  meta=M.metadata[label];dim=meta['ledger']['real_dimension_per_eigenvalue'];realcount+=dim*len(meta['ids']);shapes+=1
  H=fixedH(label,M.q0);Hp,stationary,dm,kin,phi=M.hessian(label,M.q0,M.m0,True);assert norm(H-Hp)<1e-8*(1+norm(H))
  scales=M.q0/np.array([np.sqrt(60),4*np.sqrt(2),np.sqrt(2)]);res=np.prod(scales[None,:]**M.nslot,axis=1)
  factors=np.array([scales[j] if j>=0 else 1 for j in meta['ids']]);g=meta['unit_metric']*factors*factors;den=np.sqrt(g[:,None]*g[None,:])
  for j in range(3):
   indicator=(meta['ids']==j).astype(float)
   E=np.einsum('k,kij->ij',cv*res*M.nslot[:,j],M.cache[label])/den-H*(indicator[:,None]+indicator[None,:])
   scalar[j]+=2*dim*float(np.trace(H@E).real);wrong_stationary[j]+=2*dim*float(np.trace(H@stationary[j]).real)
 def trace_square(q):
  total=0.
  for label in M.cache:
   H=fixedH(label,q);total+=M.metadata[label]['ledger']['real_dimension_per_eigenvalue']*float(np.trace(H@H).real)
  return total
 finite=[];refined=[]
 for j in range(3):
  direction=np.eye(3)[j];fun=lambda t:trace_square(M.q0*(1+t*direction))
  v1,v2=fd4(fun),fd4(fun,5e-5);assert abs(v1-v2)<5e-7*(1+abs(v1)+abs(v2));finite.append(v1);refined.append(v2)
 assert np.max(abs(scalar-wrong_stationary))>1e-3 and realcount==328 and shapes==35
 a,b=[json.loads((D/(('primary_result.json' if role=='primary' else 'replay_v2_result.json'))).read_bytes()) for role in ['primary','replay']]
 mp.mp.dps=100
 for key in ['fractional_coefficients','canonical_coefficients']:
  for ra,rb in zip(a[key],b[key]):
   for x,y in zip(ra,rb):
    x,y=mp.mpf(x),mp.mpf(y);assert abs(x-y)<mp.mpf('1e-50')*(1+abs(x)+abs(y))
 target=np.array([float(row[0]) for row in a['fractional_coefficients']]);err=np.max(abs(target-scalar)/(1+abs(target)+abs(scalar)));assert err<5e-8
 assert np.max(abs(target-finite)/(1+abs(target)+np.abs(finite)))<5e-7
 assert np.max(abs(target-refined)/(1+abs(target)+np.abs(refined)))<5e-7
 print('STAGE fixed_parameter_trace_check',time.perf_counter()-tick,flush=True)
 # Full current orbit normalization, independently rederived from the replay
 # physical representation rather than inferred from the old gstar numbers.
 data=json.loads((P/'frozen_a10_physical_reconciliation/full_replay.json').read_bytes());v=mat(data['vacuum']['VEV']);Gr=[];cas={}
 for name,off,n in [('Phi',0,54),('Sigma',54,252),('S',326,2)]:
  rhos=[mat(row) for row in data['representation_matrices'][name]];vv=v.extract(range(off,off+n),[0]);O=s.SparseMatrix.hstack(*(rho*vv for rho in rhos));Gr.append((O.T*O).applyfunc(clean))
  operator=-sum((rho*rho for rho in rhos),s.SparseMatrix(n,n,{}));val=clean(s.trace(operator)/n)
  assert not (operator-val*s.eye(n)).applyfunc(clean).todok();cas[name]=str(val)
 assert cas=={'Phi':'10','Sigma':'25/2','S':'0'}
 old=json.loads((C/'canonical_so10_radial_bosonic_tadpoles/original_v2_result.json').read_bytes());assert s.Matrix(old['gauge_Gamma_Phi'])==2*Gr[0] and s.Matrix(old['gauge_Gamma_Sigma'])==2*Gr[1] and Gr[2]==s.zeros(45)
 G=Gr[0]+Gr[1];expected4=[12*s.trace(G*Gr[0]),12*s.trace(G*Gr[1]),0]
 assert list(map(s.sympify,a['vector_fractional_exact']))==expected4
 # Exact fixed-reference broken O2 inverse trace. The derivative mixing
 # is present before its first trace is evaluated.
 z,vv,g,xi,lam,t=s.symbols('z v g xi lam t',positive=True);r=vv+t
 K=s.Matrix([[z/xi+g*g*r*r,-s.I*g*t*s.sqrt(z)],[s.I*g*t*s.sqrt(z),z+lam*(r*r-vv*vv)+xi*g*g*vv*vv]])
 fp=z+xi*g*g*vv*r;at=K.subs(t,0);dK=K.diff(t).subs(t,0)
 inverse=s.cancel(s.trace(at.inv()*dK)/2-s.diff(fp,t).subs(t,0)/fp.subs(t,0));orbit=lam*vv/(z+xi*g*g*vv*vv)
 assert s.cancel(inverse-orbit)==0
 assert s.cancel(s.trace(at.inv()*dK)/2-orbit)!=0 # omitted FP
 assert s.cancel(orbit-lam*vv/z)!=0 # omitted orbit GF mass
 # Noncommuting rectangular orbit matrices retain ordered ghost variation.
 O=s.Matrix([[1,2],[3,1],[0,2]]);Oprime=s.Matrix([[2,-1],[1,3],[2,0]]);GG=O.T*O;dGG=Oprime.T*O+O.T*Oprime
 longitudinal=2*s.trace(GG*dGG);ghost=-4*s.trace(GG*O.T*Oprime)
 assert longitudinal+ghost==0 and longitudinal!=0 and GG*dGG!=dGG*GG
 # Bare integral/pole sign and the explicitly uncomputed finite vector term.
 e,x,L=s.symbols('e x L',positive=True);gamma=s.exp(e*(s.EulerGamma-L))*s.gamma(e-1)*x
 assert s.limit(e*gamma,e,0)==-x
 integrand=(3-2*e)*x*(-1/e+L-1);vector_finite_coefficient=s.expand(integrand).coeff(e,0)
 assert s.expand(vector_finite_coefficient-x*(3*L-1))==0 and s.expand(vector_finite_coefficient-3*x*(L-1))!=0
 aux=s.symbols('b',positive=True);assert s.limit(-aux,aux,0)==0
 pp=s.symbols('p',positive=True);assert s.integrate(pp**3/pp**2,(pp,0,1))==s.Rational(1,2)
 for out in [a,b]:
  assert out['effective_action_pole_prefactor']=='-hbar/(64*pi^2*epsilon_UV)'
  assert out['actual_selected_GS_UV_input_extracted'] and out['fixed_parent_coefficients_and_GF_reference']
  assert not out['finite_subtraction_or_tadpole_condition_chosen'] and not out['C1_GS_calculated'] and not out['authority_changed'] and not out['old_finite_tadpole_loops_rerun']
 result={'schema':'C1_GS_LOCAL_UV_RADIAL_TADPOLE_VALIDATION_V3',
 'status':'PASS_SELECTED_GAUGE_SCALAR_RADIAL_UV_INPUT_EXTRACTION_AND_NORMALIZATION_TRANSPORT',
 'input_bindings':len(prep['input_sha256']),'potential_real_directions':328,'scalar_blocks':35,
 'fresh_float_scalar_trace_scaled_error':float(err),'scalar_finite_difference':finite,'scalar_refined_finite_difference':refined,
 'wrong_stationary_family_derivative_difference':(wrong_stationary-scalar).tolist(),
 'fractional_coefficients':a['fractional_coefficients'],'canonical_coefficients':a['canonical_coefficients'],
 'exact_current_Casimirs':cas,'generator_coupling_map_verified':True,
 'literal_fixed_reference_Gaussian_and_FP_cancellation':True,'massless_local_pole_limit_checked':True,
 'old_finite_loops_rerun':False,'finite_tadpole_or_mass_scheme_selected':False,'complete_one_loop_CT_module':False,
 'actual_selected_UV_tadpole_input_calculated':True,'C1_GS_calculated':False,'authority_changed':False,
 'formal_authority':'34/39_UNCHANGED','native_failures':1,'prelaunch_parse_failures':1,'verifier_failures':1,
 'shared_premises':'same parent/AST, restored exact cache and old finite reference, HST block/metric compiler, software and AI author',
 'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
