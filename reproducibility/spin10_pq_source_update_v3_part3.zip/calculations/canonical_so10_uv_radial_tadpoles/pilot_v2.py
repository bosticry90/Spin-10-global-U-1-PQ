from pathlib import Path
from hashlib import sha256
import json,sys,time,threading,os
import sympy as s
import mpmath as mp
from inputs import R,C,P,w,read,matrix,clean,number,nm,fmt,block_inputs,reduce_root,root,casimirs
D=Path(__file__).resolve().parent
def main(role):
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=read(D/'preparation_v2.json')
 for n,h in prep['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
 # Authenticate selected reused outputs against the original completed receipts;
 # live policy files are not substituted for historically bound policy hashes.
 for folder,file in [('canonical_so10_singlet_tadpole','original_v2_result.json'),('canonical_so10_radial_bosonic_tadpoles','original_v2_result.json')]:
  receipt=read(C/folder/'validation_receipt.json');key='calculations/'+folder+'/'+file
  assert receipt['byte_sha256'][key]==sha256((C/folder/file).read_bytes()).hexdigest()
 mp.mp.dps=100;work,cc,q,quad,packet,radial=block_inputs(role);ww=root(quad)
 if role=='primary':
  scalar=[s.S.Zero]*3
  for row,H,Ds,metric in work:
   inv=s.diag(*(1/z for z in metric))
   for j in range(3):scalar[j]+=2*row['dimension']*s.trace(inv*H*inv*Ds[j])
  scalar=[reduce_root(z,quad) for z in scalar];scalarval=[number(z,ww) for z in scalar]
 else:
  scalar=None;scalarval=[mp.mpf(0)]*3;zeros=0;positive=0
  for row,H,Ds,metric in work:
   sq=[mp.sqrt(number(z).real) for z in metric];Hn=nm(H,ww);Hn=mp.matrix([[Hn[i,j]/(sq[i]*sq[j]) for j in range(H.cols)] for i in range(H.rows)])
   ev,U=mp.eighe(Hn);zeros+=row['dimension']*sum(abs(v)<mp.mpf('1e-60') for v in ev);positive+=row['dimension']*sum(v>mp.mpf('1e-4') for v in ev)
   assert all(abs(v)<mp.mpf('1e-60') or v>mp.mpf('1e-4') for v in ev)
   for j in range(3):
    Dn=nm(Ds[j],ww);Dn=mp.matrix([[Dn[i,k]/(sq[i]*sq[k]) for k in range(H.cols)] for i in range(H.rows)]);diag=U.H*Dn*U
    scalarval[j]+=2*row['dimension']*sum(ev[i]*diag[i,i] for i in range(H.rows))
  assert (positive,zeros)==(290,38)
  # Third extraction uses already measured S eigenvalues/vertices; no finite
  # CW integrals or high-cost original tadpole workers are rerun.
  oldS=mp.mpf(0)
  for row in packet['probes'][-1]['blocks']:
   oldS+=2*row['dimension']*sum(mp.mpf(x)*mp.mpf(y) for x,y in zip(row['mass_squared'],row['S_mass_derivative_eigenbasis']))
  assert abs(oldS-scalarval[2])<mp.mpf('1e-50')*(1+abs(oldS))
 print('STAGE scalar_UV_residue',time.perf_counter()-tick,flush=True)
 V=read(C/'canonical_so10_vector_mass_tangent/primary_result.json')['calculation'];GP=matrix(V['Gram_Phi']);GS=matrix(V['Gram_Sigma']);G=GP+GS
 assert s.Matrix(radial['gauge_Gamma'])==2*G and s.Matrix(radial['gauge_Gamma_Phi'])==2*GP and s.Matrix(radial['gauge_Gamma_Sigma'])==2*GS
 if role=='primary':
  Cas=casimirs();assert Cas=={'Phi':10,'Sigma':s.Rational(25,2),'phi':s.Rational(9,2),'S':0}
  env={}
  a,b,c=s.symbols('omega sigma s',positive=True);env.update(zip(['omega','sigma','s'],[a,b,c]));env.update({n:s.Symbol(n,real=True) for n in ['Lp','Lm','muPhi','lambdaPhiS','lambdaSigmaS','lambdaS','lambdaSigma1']})
  Hrow=V['radial_Hessian'];Hr=s.Matrix(*Hrow['shape'],lambda i,j:0)
  for i,j,z in Hrow['entries']:Hr[i,j]=s.sympify(z,locals=env)
  subs={a:q[0],b:q[1],c:q[2],env['Lp']:cc['lambdaPhi1']+s.Rational(7,60)*cc['lambdaPhi2'],env['Lm']:cc['lambdaPhiSigma1']-cc['lambdaPhiSigma2']/4}
  subs.update({env[n]:cc[n] for n in ['muPhi','lambdaPhiS','lambdaSigmaS','lambdaS','lambdaSigma1']});Hr=Hr.subs(subs)
  mixed=[clean(2*q[j]*(Cas['Phi']*q[0]*Hr[0,j]+Cas['Sigma']*q[1]*Hr[1,j])) for j in range(3)]
  vector=[clean(12*s.trace(G*GP)),clean(12*s.trace(G*GS)),s.S.Zero]
 else:
  Cas=None;tables=radial['gauge_spectral_coefficients'];mixed=[];vector=[]
  for j in range(2):
   mixed.append(clean(sum(s.Rational(r['gamma'])*s.sympify(r['orbit_potential_derivative_trace'][j]) for r in tables)))
   vector.append(clean(s.Rational(3,2)*sum(s.Rational(r['gamma'])*s.sympify(r['Gamma_derivative_trace'][j]) for r in tables)))
  mixed.append(s.S.Zero);vector.append(s.S.Zero)
 assert mixed[0]!=0 and mixed[1]!=0 and mixed[2]==vector[2]==0
 fractional=[[scalarval[j],number(mixed[j]),number(vector[j])] for j in range(3)]
 canonical=[[z/number(q[j]) for z in row] for j,row in enumerate(fractional)]
 # Missing generator map produces g^2/g^4 errors, rather than a numerical
 # coupling choice. Raw scalar coefficient remains the same physical action.
 assert any(z!=2*z for z in mixed) and any(z!=4*z for z in vector)
 out={'schema':'C1_GS_LOCAL_UV_RADIAL_TADPOLE_NATIVE_V1','role':role,
 'fractional_direction_names':['Phi','Sigma','S'],'pole_coefficient_columns':['g^0','xi*g10^2','g10^4'],
 'effective_action_pole_prefactor':'-hbar/(64*pi^2*epsilon_UV)','local_subtraction_target_prefactor':'+hbar/(64*pi^2*epsilon_UV)',
 'fractional_coefficients':[[fmt(z) for z in row] for row in fractional],
 'canonical_coefficients':[[fmt(z) for z in row] for row in canonical],
 'scalar_exact_reduced_w':list(map(str,scalar)) if scalar is not None else None,
 'mixed_fractional_exact':list(map(str,mixed)),'vector_fractional_exact':list(map(str,vector)),
 'actual_Casimir_matrices':{k:str(v) for k,v in Cas.items()} if Cas else None,
 'coupling_map':'gstar=g10/sqrt(2); G_old=2*G_new',
 'potential_real_directions':328,'old_finite_tadpole_loops_rerun':False,
 'fixed_parent_coefficients_and_GF_reference':True,'actual_selected_GS_UV_input_extracted':True,
 'finite_subtraction_or_tadpole_condition_chosen':False,'full_one_loop_CT_module_constructed':False,
 'full_E1_quantum_equivalence_claimed':False,'C1_GS_calculated':False,'authority_changed':False,
 'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main(sys.argv[1])
