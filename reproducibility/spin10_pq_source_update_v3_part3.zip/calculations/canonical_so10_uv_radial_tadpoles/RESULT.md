# UTP1 result — selected gauge/scalar UV tadpole coefficients

**PASS for the specified three-radial C1 Gaussian UV input.** The complete
selected gauge/scalar pole is now extracted and independently checked. This
uses qualified older finite-tadpole operator data; those finite loops were
not rerun. No finite normalization, vacuum shift or physical scheme is chosen.

For canonical radial fields(Phi,Sigma,S), the effective-action one-loop pole is

    T1_pole = -hbar/(64*pi^2*epsilon_UV) * (P0+xi*g10^2*P2+g10^4*P4).

The coefficient vectors have mass dimension3 in the existing internal units:

| Canonical radial direction | P0 | P2 | P4 |
| --- | ---: | ---: | ---: |
| Phi | 58221.544026 | 13.395526955 | 23377.327478 |
| Sigma | 217417.137737 | 57.893654983 | 1457.016335 |
| S | 105.060018738 | 0 | 0 |

These are loop-factor-stripped pole coefficients, NOT finite tadpoles, mass
shifts, percentages or observables. The local subtraction target has the
opposite sign. Distributing it among mass, coupling, VEV, field and gauge-fixing
counterterms remains part of the uncompleted renormalization program.

The fractional-coordinate coefficients, before division by
(sqrt60,sqrt(3/5),sqrt(3/5)), have exact mixed/vector entries

    P2 = (322006179/1000000-7043823*sqrt15/125000,
          70069113/1562500,0),
    P4 = (181080,5643/5,0).

All three P0 entries are stored as exact affine expressions in the unchanged
point's algebraic Higgs root w, reduced by its frozen quadratic; high-precision
canonical and fractional values are in primary_result.json. The expressions
are conditional on the previously qualified exact lattice reconstruction of
the35-block cache. This is not a new independent derivation of all parent
mass monomials. Extra numerical digits do not validate shared physical inputs.

## Fixed external-field derivative and gauge terms

Physical parent parameters and the gauge-fixing reference VEV are held fixed.
Differentiating the solved stationary parameter family would give a different
quantity. The independent check detects that error: its fractional scalar
residue differs by approximately(61.8401,-28107.9125,-2.88).

The vector/scalar mixing derivative was retained in the actual Hessian before
its first trace was evaluated. It is off diagonal against the base block-diagonal
propagator and has zero first trace. No higher-derivative zero is inferred.
Longitudinal-vector and complex FP contributions cancel in the selected first
variation. The scalar gauge-orbit contribution survives and gives P2. It
cannot be removed by treating all potential Goldstone zeros as massless.

The P2 check uses freshly verified actual representation Casimirs
(10,25/2,9/2,0) for(Phi54,Sigma252,phi20,S2), together with the action-derived
radial field Hessian. Differentiated invariance gives

    Tr(OO^T D_j)=q_j sum_R C_R q_R Hrad_Rj.

This agrees exactly with the older independently qualified spectral orbit
coefficients after normalization transport. The S mixed/vector zero is specific
to its gauge singlet and the current lambdaPhiS=lambdaSigmaS=0 benchmark;
it is not a general all-loop zero for the singlet sector.

The old generator convention used J and gstar; the C1 reference uses J/sqrt2
and g10. Every GP/GS entry satisfies G_old=2G_new. Consequently
gstar=g10/sqrt2, with no numerical coupling chosen. Omitting this map produces
incorrect factors2 and4 in the two gauge powers. Only matching selected
quadratic/first-variation data are transported; this is not quantum equivalence
of the historical E1 nonlinear/source action or an adoption of its inactive
physical candidate.

## Verification

The original exact primary traces every inherited scalar block with its
physical metric, dimension and conjugate counting, covering328 real directions.
It avoids diagonalization and reduces the scalar polynomial by POINT's exact
root relation. The corrected spectral replay independently contracts canonical
mass eigenvalues and derivative vertices at100digits. It reproduces the
290positive/38zero census and agrees with the primary at the frozen1e-50
scaled tolerance. The older recorded S eigenvalue/vertex data supply a third
extraction of its residue, without a finite-loop replay.

The separate verifier uses the HST1 compiler at FIXED physical coefficients
and fourth-order finite differences of the full dimension-weighted Tr(H^2).
Its analytic scaled discrepancy is3.48e-16; the step/half-step checks satisfy
the unchanged complex128 acceptance tolerances. It also reconstructs the
current exact orbit matrices, tests a literal broken-O2 inverse-trace Gaussian,
checks ordered FP/longitudinal cancellation with noncommuting orbit matrices,
and anchors the pole sign to the Gamma tadpole integral.

Massless channels are handled by a positive auxiliary mass whose local pole
vanishes in its zero limit, and the one-loop radial IR power count is checked.
No unseparated scaleless integral is declared zero. Power-sensitive and finite
contributions are outside this calculation. The transverse d-1 factor has
a nonzero finite effect; a pole-only extraction does not discard that effect
from the full calculation.

The bare Gamma normalization agrees with the primary master convention of
[Martin–Robertson](https://arxiv.org/pdf/hep-ph/0501132). Generalized-gauge
one-loop functions in [Martin–Patel](https://arxiv.org/pdf/1808.07615) are
technical comparators; the fixed-reference first-variation derivation here
establishes the actual scope. Their finite/tadpole-free choices are not adopted.

## Preserved failures and resource evidence

One native spectral replay failed because mpmath.matrix(n,n,lambda...) silently
constructed zeros. The frozen diagnostic reproduced0positive/328zero for that
API call and290positive/38zero with explicit matrix construction. V2 changes
only the two H/D constructors and preparation binding; the successful exact
primary is authenticated and reused. No scientific formula, input, tolerance,
precision or census was changed. See MATRIX_DIAGNOSTIC_V2 and CORRECTION_V2.

One V2 verifier failed on abs(list); V3 uses numpy.abs. Inspection also caught
a diagnostic variable collision before that rerun; its symbolic variable was
renamed while preserving the same identity. One prelaunch quoted Python -c
preparation failed to parse and created no scientific worker. Its diagnostic
and the original tool record remain preserved. No failure is relabelled PASS.

Completed exact primary5.367805s, corrected replay3.042671s, matrix diagnostic
1.393933s, V3 verifier15.659508s, after imports. Final preparation/validation
bindings1080/1110/1113/1123 (including the correction stages). Caps120/180s,
8GiB sampled private,350MiB launch floor,4MiB package. Largest successful
sample468,389,888 bytes is NOT a true peak. Original and corrected complete
captures precede their assertions. The V3 launcher's retained print label
VALIDATED_V2 is cosmetic; its source, command, V3 capture and V3 receipt schema
identify the actual completed run.

Final receipt SHA256:
`0219d2436e7c8a438fc1868f852100fb3eb8cc87fd73fcf89de8472886c4cc17`.
The completed sequence is preserved by the original prepare/run, diagnostic,
prepare_v2/run_v2, prepare_validation_v2/run_validation_v2 (failed verifier),
then prepare_validation_v3/run_validation_v3 files. Exclusive outputs protect
all evidence. Do not blindly rerun these in place or replace their hashes.

The result demonstrates reuse of qualified evidence, a complete normalization
transport and a separately checked local quantum input. It also records two
avoidable scientific-code/harness errors and a prelaunch quotation error.
Shared action/AST, restored cache, old finite reference, HST kinetic compiler,
software and AI author remain limitations; no outside, Lean or experimental
confirmation is claimed.

The full one-loop counterterm module and finite prescription, weighted two-loop
amplitudes, reduction, required epsilon/IR descendants and common UV/EFT
subtraction remain missing. No finite C1_GS or unification fit is produced.
No old evidence/state/action/point/source/partialGamma/policy/scheme/main/
remote/publication changes.34/39,state113/sevenfalse,E5/A5unqualified,
HB1/C5blocked,flavorpaused,quartetFAIL3960/648,custodyexit2/seven; scalar140%/
1.94%/20.27%,matching0.745476 and missing Yukawa control remain separate.
