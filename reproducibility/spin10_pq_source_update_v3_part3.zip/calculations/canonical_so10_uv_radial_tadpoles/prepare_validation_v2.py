from pathlib import Path
from hashlib import sha256
import json,mpmath as mp
D=Path(__file__).resolve().parent;p=json.loads((D/'preparation_v2.json').read_bytes())
for n,h in p['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
a,b=[json.loads((D/n).read_bytes()) for n in ['primary_result.json','replay_v2_result.json']];mp.mp.dps=100
for xrow,yrow in zip(a['fractional_coefficients'],b['fractional_coefficients']):
 for x,y in zip(xrow,yrow):
  x,y=mp.mpf(x),mp.mpf(y);assert abs(x-y)<mp.mpf('1e-50')*(1+abs(x)+abs(y))
files=list(map(Path,p['input_sha256']))+[D/'preparation_v2.json',D/'replay_v2_capture.json',D/'replay_v2_result.json']
v={'schema':'C1_GS_UV_RADIAL_TADPOLE_VALIDATION_PREPARATION_V2','input_sha256':{str(q):sha256(q.read_bytes()).hexdigest() for q in files}}
with (D/'validation_preparation_v2.json').open('xb') as f:f.write((json.dumps(v,indent=2,sort_keys=True)+'\n').encode())
print('VALIDATION_V2_FROZEN',len(files),flush=True)
