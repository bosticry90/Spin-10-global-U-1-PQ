from pathlib import Path
from hashlib import sha256
import json
D=Path(__file__).resolve().parent;p=json.loads((D/'validation_preparation_v2.json').read_bytes())
for n,h in p['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
failed=json.loads((D/'validation_v2_capture.json').read_bytes());assert failed['execution_state']=='FAILED' and failed['exit_code']==1
text=(D/'verify_v2.py').read_text();changes={
"D/'validation_preparation_v2.json'":"D/'validation_preparation_v3.json'",
'1+abs(target)+abs(finite)':'1+abs(target)+np.abs(finite)',
'1+abs(target)+abs(refined)':'1+abs(target)+np.abs(refined)',
'finite=s.expand(integrand).coeff(e,0)':'vector_finite_coefficient=s.expand(integrand).coeff(e,0)',
's.expand(finite-x*(3*L-1))':'s.expand(vector_finite_coefficient-x*(3*L-1))',
's.expand(finite-3*x*(L-1))':'s.expand(vector_finite_coefficient-3*x*(L-1))',
"'verifier_failures':0":"'verifier_failures':1",
"'schema':'C1_GS_LOCAL_UV_RADIAL_TADPOLE_VALIDATION_V1'":"'schema':'C1_GS_LOCAL_UV_RADIAL_TADPOLE_VALIDATION_V3'"}
for a,b in changes.items():assert text.count(a)==1,a;text=text.replace(a,b)
with (D/'verify_v3.py').open('xb') as f:f.write(text.encode())
files=list(map(Path,p['input_sha256']))+[D/n for n in ['validation_preparation_v2.json','validation_v2_capture.json','VERIFIER_CORRECTION_V3.md','prepare_validation_v3.py','run_validation_v3.py','verify_v3.py']]
for n in ['VERIFIER_CORRECTION_V3.md','prepare_validation_v3.py','run_validation_v3.py','verify_v3.py']:
 with (D/(n+'.source.txt')).open('xb') as f:f.write((D/n).read_bytes())
 files.append(D/(n+'.source.txt'))
v={'schema':'C1_GS_UV_RADIAL_TADPOLE_VALIDATION_PREPARATION_V3','input_sha256':{str(q):sha256(q.read_bytes()).hexdigest() for q in sorted(set(files))}}
with (D/'validation_preparation_v3.json').open('xb') as f:f.write((json.dumps(v,indent=2,sort_keys=True)+'\n').encode())
print('VALIDATION_V3_FROZEN',len(v['input_sha256']),flush=True)
