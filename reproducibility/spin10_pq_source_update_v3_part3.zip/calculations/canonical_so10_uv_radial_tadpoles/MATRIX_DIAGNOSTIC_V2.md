# Prospective matrix-constructor diagnostic

The primary exact trace completed. The original spectral replay FAILED the
unchanged290positive/38zero census. Its complete source/preparation/capture
remain frozen. Do not qualify the pole result or relax the census.

Hypothesis: the mpmath call matrix(n,n,lambda...) was mistakenly treated as
the SymPy callable-initializer API. Diagnose this on a small literal matrix
and on every inherited scalar block, at the same100digits/1e-60 zero and
1e-4 positive thresholds. Compare the old constructor with a list-of-lists
constructor; record all old/new counts and nonzero matrix norms. No coupling,
normalization, source data, physics formula, tolerance or resource change.

Freeze the original inputs, diagnostic code and proposed two-line constructor
correction before running.120s after imports,8GiB sampled,350MiB launch floor,
4MiB package. Preserve all captures before assertions. This is a bounded
implementation diagnosis, not a new finite-loop replay or a scientific gate.
If the hypothesis is disproved, retain it and investigate the actual mismatch.
