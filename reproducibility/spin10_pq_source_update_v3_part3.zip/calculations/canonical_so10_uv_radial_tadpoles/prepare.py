from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent
C=Path('C:/Users/psboy/.codex/research-control-records/ToE-Next/uv-radial-tadpoles-v1-2026-10-20');C.mkdir(parents=True,exist_ok=False)
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();assert base=='e83c4017a36a1d4683be15333abe4547749ba91a'
old=json.loads((R/'calculations/canonical_so10_higgs_stationary_tangent/validation_preparation.json').read_bytes())
for n,h in old['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
files=list(map(Path,old['input_sha256']))
names=['AGENTS.md','project_state.json','docs/RESEARCH_EXECUTION_HANDOFF_V377.md',
'calculations/canonical_so10_higgs_stationary_tangent/validation_receipt.json',
'calculations/canonical_so10_higgs_stationary_tangent/RESULT.md',
'calculations/canonical_so10_higgs_stationary_tangent/model.py',
'calculations/canonical_so10_vector_mass_tangent/primary_result.json',
'calculations/canonical_so10_vector_mass_tangent/replay_result.json',
'calculations/canonical_so10_background_threshold_inputs/DERIVATION.md',
'calculations/canonical_so10_background_threshold_inputs/validation_receipt_v2.json',
'calculations/canonical_so10_vacuum_master_pilot/DERIVATION.md',
'calculations/canonical_so10_vacuum_master_pilot/validation_receipt_v2.json']
files +=[R/n for n in names]
for folder in ['canonical_so10_singlet_tadpole','canonical_so10_radial_bosonic_tadpoles']:
 files +=[R/'calculations'/folder/n for n in ['original_v2_result.json','validation_receipt.json','RECORD.md','RESULT.md']]
files +=[P/n for n in ['frozen_a10_physical_reconciliation/full_primary.json','frozen_a10_physical_reconciliation/full_replay.json']]
for p in list(D.iterdir()):
 if p.suffix in ['.py','.md']:
  with (D/(p.name+'.source.txt')).open('xb') as f:f.write(p.read_bytes())
files+=list(D.iterdir());tree=subprocess.check_output(['git','ls-tree','-r',base],cwd=R)
with (C/'old_git_tree.txt').open('xb') as f:f.write(tree)
files.append(C/'old_git_tree.txt');files=sorted(set(files))
v={'schema':'C1_GS_UV_RADIAL_TADPOLE_PREPARATION_V1','base_commit':base,'old_git_blobs':len(tree.splitlines()),
'input_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in files},
'native_after_imports_seconds':120,'verifier_after_imports_seconds':180,'native_precision_digits':100,
'native_scaled_tolerance':'1e-50','float_trace_scaled_tolerance':5e-8,'FD_scaled_tolerance':5e-7,
'sampled_private_limit':8*1024**3,'launch_floor_bytes':350*1024**2,'package_limit':4*1024**2}
with (D/'preparation.json').open('xb') as f:f.write((json.dumps(v,indent=2,sort_keys=True)+'\n').encode())
print('FROZEN',len(files),'bindings',v['old_git_blobs'],'old blobs',flush=True)
