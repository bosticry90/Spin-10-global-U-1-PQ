# UTP1 — actual C1 gauge/scalar local UV tadpole input

Prospective at e83c4017a36a1d4683be15333abe4547749ba91a/main,2026-10-20.
Previous goal turn PROGRESS. Fresh preflight clean, no matching workers;
452 bindings authenticate declared bytes only. C1_GS active input seam.

Evidence reuse changes the least-cost method: V81's exact recovered35-block
mass/operator packet and V83's fixed-VEV finite bosonic tadpoles already exist.
Do NOT rerun their finite CW calculations. Extract their local logarithmic
UV residue and transport the quadratic/first-variation data to the actual
BFT1 C1 generator convention. Verify using a distinct local trace/Casimir
calculation. This is new qualified C1 UV-input extraction and reconciliation,
not a claim of newly integrating the old finite loops.

Types: external scalar q=(omega,sigma,s) near the frozen stationary VEV v,
all physical parent coefficients FIXED. The gauge-fixing reference O_v is
fixed. Zero gauge, ghost, source and auxiliary mean fields. BFT1 linear
Rxi Gaussian (common tree xi>0; independent width CTs remain separate).
Ordinary g10 multiplies plane generators J/sqrt2, Tr10 normalization1.
The older gstar used J; derive gstar=g10/sqrt2 before importing any gstar
power. No numerical coupling, gauge width or physical scheme is adopted.
No equivalence of the full E1/nonlinear/source action is inferred.

Freeze DERIVATION, code, controllers and immutable inputs before computation.
Target is T1_pole= -hbar/(64pi^2 epsilon_UV)*(P0+xi*g10^2*P2+g10^4*P4),
with fractional external variations then division by q_j for canonical radial
tadpoles. Output exact coefficient functions where inherited data permit,
and high-precision numerical values at the unchanged exact algebraic point.
Opposite-sign local pole subtraction is identified; no FINITE subtraction,
renormalized tadpole condition, delta v, mass prescription or C1_GS is chosen.

Primary: exact generalized scalar trace over ALL328 real directions using
V81's recovered rational34-slot blocks and physical metrics, at fixed parent
parameters. Monomial degrees/external legs derive from the frozen AST. Avoid
eigendecomposition for this polynomial trace. Reduce dependence on the Higgs
root using its exact POINT quadratic. Compute the mixed orbit term via
the fresh actual scalar Casimir matrices and action-derived radial Hessian.
Use the exact VMT1 vector Grams for the transverse-vector contribution.

Replay: high-precision spectral one-loop tadpole residues from the exact
scalar packet, independently reconstructing canonical propagators and
derivative vertices; use old V83 spectral orbit/vector data after the explicit
generator/coupling map. Reconcile the entire base Gram and first radial
derivative matrices, not a numerical diagnostic field configuration. Retain
S direction: its mixed/vector zero must follow actual singlet/benchmark
coupling data, not a general zero assignment. Authenticate the selected old
completed outputs against their original receipts without rebinding historical
policies to live bytes or claiming a fresh old finite-loop replay.

Independent verifier imports no new native helper: use the separately qualified
HST1 block map at FIXED parent parameters, fourth-order finite differences of
the full dimension-weighted Tr(H^2), and its analytic fixed-parameter matrix
jets. Check full actual Casimir identities, normalized orbit Grams, longitudinal/
ghost cancellation and pole signs with a literal broken O2 Gaussian and the
Gamma tadpole integral. Check cancellation BEFORE discarding widths or d-4.
Keep the nonzero orbit-scalar pole and derivative mixing's zero FIRST trace;
do not infer a higher-derivative zero. No scalar-only/finite/QAP theorem is
promoted by this selected UV coefficient.

Native exact expressions/evaluation100digits, spectral replay100digits;
relative-scaled agreement1e-50 for native exact/spectral values. HST1 float
cross-checks inherit complex128 accuracy: analytic5e-8 scaled, FD5e-7 scaled
with step1e-4 and half step. Report refinement. No tolerance changes after
results. Required controls: wrong gstar identification, missing orbit curvature,
omitted FP/longitudinal term, wrong real/complex multiplicity or pole sign,
wrong external normalization, and wrongly differentiating the stationary
parameter family instead of the external field at fixed coefficients.

Massless one-loop tadpole channels: establish the local logarithmic coefficient
using a positive auxiliary mass then its zero limit; do not call an unseparated
scaleless integral zero. Power-sensitive and finite terms are not calculated.
The transverse d-1=3-2epsilon affects the finite part, but only its leading
coefficient multiplies the simple UV pole. No all-loop IR conclusion.

Native120s/verifier180s AFTER imports,8GiB sampled private NOT true peak,
350MiB available-commit launch floor,4MiB package. Freeze inputs/source closure,
save full captures before assertions, preserve failures/unfinished versions.
Sequential independent calculations; compare completed outputs before verifier.
Inspect each dependent exit before any mutation. No expensive qualified finite
loop repetition, full328^4 grid, arbitrary master platform or source-quartic run.

Possible outcomes: qualified UV-input extraction, discrepancy, underdefinition
or bounded inconclusiveness. Shared parent/AST, exact restored cache/VEVs,
prior finite reference and geometry, symbolic/numeric software and AI author
remain explicit limits; no external/Lean/experimental verification. Actual
one-loop CT module, its finite scheme, weighted two-loop diagrams, reduction,
required epsilon/IR descendants and common UV/EFT subtraction remain unearned.

No old evidence/state/action/point/source/partialGamma/policy/scheme/main/
remote/publication changes.34/39,state113/sevenfalse,E5/A5unqualified,
HB1/C5blocked,flavorpaused,C1_GSuncalculated,quartetFAIL3960/648,custodyexit2/
seven. Scalar140%/1.94%/20.27%,matching0.745476 and missing Yukawa control
remain separate limitations. Protected E1/source history is not repaired.
