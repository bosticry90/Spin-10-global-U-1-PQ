# UTP1 — fixed-reference Gaussian residue and local Ward check

All parent parameters are fixed during the external-field variation. Put
O(q)_Ia=(rho_a q)_I, O0=O(v), G=O0^T O0, F=O0 O0^T,
H=V''(v), D_j=partial_fraction_j V'' at fixed parameters. At the stationary
point H O0=0. The BFT1 reference Hessians at constant scalar background are

    scalar: p^2+V''(q)+xi*g^2 F,
    vector: (p^2+g^2 G(q)) P_T+(p^2/xi+g^2 G(q)) P_L,
    ghost: p^2+xi*g^2 O0^T O(q).

The vector/scalar mixing is proportional to p*(O(q)-O0); at q=v it vanishes.
Its first variation is off diagonal, so Tr(K0^-1 deltaK_mix)=0. This does
not discard its second variation. The eliminated Gaussian auxiliary contributes
only a field-independent normalization here, on the established complex contour.

For a real scalar, Gamma1=1/2 Tr log K. The established normalized tadpole
integral is Abar(x)=x exp[epsilon(gamma_E-log(x/Q^2))] Gamma(epsilon-1)
=-x/epsilon+finite. Thus its one-point pole is -Tr(M^2 deltaM^2)/(32pi^2 eps).
A complex FP pair has weight-1 in Tr log, not-1/2. The transverse vector
has d-1=3-2epsilon and the longitudinal mass is xi*g^2 G. The latter's
first variation and FP variation cancel because the fixed-reference ghost
variation is xi*g^2 O0^T O'_j, half the vector Gram variation inside this
trace. Preserve matrix order until using symmetry of G and the trace.

Writing G'_j=O'_j^T O0+O0^T O'_j yields the complete specified pole

    T1_pole= -hbar/(64pi^2 eps_UV)*(P0+xi*g^2 P2+g^4 P4),
    P0_j=2 Tr_328(H D_j),
    P2_j=2 Tr_328(F D_j),
    P4_j=6 Tr_45(G G'_j).

Scalar GF mass is fixed with the reference VEV: its derivative is zero,
but it remains inside the propagator. It produces the P2 term. A putative
scalar-only tadpole that omits this orbit contribution is generally wrong.
The longitudinal and ghost g^4*xi^2 terms cancel, not the orbit-scalar term.
Retaining d-1 through the integral generates finite pieces; none is evaluated
or set to zero by this pole-only result. For the gauge-scalar subset there
are no ordinary matter-fermion loops; their absence is declared scope, not
an assumed vanishing of their full-theory effects.

Differentiated gauge invariance of the potential gives H(q)rho_a q=rho_a V'(q).
Taking O(q)^T times this identity and summing a gives

    Tr[V''(q) O(q)O(q)^T]=q^T C V'(q), C=-sum_a rho_a^2.

Differentiate at V'(v)=0, holding parameters fixed. Since H O0=0, derivatives
of O do not contribute to this trace, and

    Tr(F D_j)=q_j sum_R C_R q_R (Hrad)_Rj.

Fresh actual representation matrices determine C_R, rather than a fitted
normalization. Hrad is the FIELD Hessian evaluated at stationary parameters;
it is not the derivative of V(q,pstar(q)). This is the independent local
check of the measured orbit tadpole coefficient.

For P0 no matrix logarithm or IR subtraction is needed: the pole is a
local quadratic trace. In each inherited SM block with raw Hessian B, raw
fixed-field derivative E_j and physical metric M,

    Tr(H D_j)=Tr(M^-1 B M^-1 E_j).

Sum with real-irrep dimensions and conjugate counting to328. Raw34-slot
matrices are the previously qualified exact lattice reconstruction of the
numeric compiler, not a new independent parent-monomial derivation. The
point's mphi2 is affine in its exact root w; these traces have degree<=2 in w.
Reduction by POINT's exact quadratic preserves the same algebraic branch.
Replay diagonalizes the canonical H and contracts its eigenvalues with the
fixed-parameter derivative vertices, using100-digit arithmetic. No old finite
CW loop evaluation is repeated. Old S eigenvalue/derivative data give an
additional independent extraction of the selected S residue.

The old V83 generators were J, while BFT1 uses J/sqrt2. Therefore
G_old=2G_new, gstar=g10/sqrt2. Its orbit projectors and potential-derivative
traces are unchanged; the old gamma and Gram derivatives each carry a factor2.
Compare every base GP/GS entry. After the coupling map, the old spectral
coefficients give P2_j=sum gamma_old*orbitDtrace_old,j and
P4_j=(3/2)sum gamma_old*GramDerivativeTrace_old,j. These are transport of
matching quadratic/first-variation data only, not quantum equivalence of the
historical E1/source theory. The S mixed/vector zero uses the actual gauge
singlet and the benchmark's lambdaPhiS=lambdaSigmaS=0 identities.

Divide fractional-direction coefficients by the canonical radii
(sqrt60,sqrt(3/5),sqrt(3/5)) for the three dimension3 tadpoles. The opposite
pole is the required local subtraction target. Its representation among
field/VEV/mass/quartic counterterms and all finite normalization conditions
are not determined by this one-point projection.

At a zero mass, a positive auxiliary mass b makes the local pole proportional
to b and hence zero as b->0; the one-loop radial integrand1/p^2 is locally
IR integrable in four dimensions. This establishes the selected logarithmic
coefficient, not a zero finite/power-sensitive amplitude or a general IR theorem.

Primary references for conventions: Martin–Robertson hep-ph/0501132v6,
eqs2.16–2.18 (bare tadpole normalization); Martin–Patel1808.07615,
generalized gauge fixing and one-loop functions3.69–3.70. The Gaussian
derivation above fixes the specific C1 reference rather than importing a
different background-scalar or tadpole-free prescription from those papers.
