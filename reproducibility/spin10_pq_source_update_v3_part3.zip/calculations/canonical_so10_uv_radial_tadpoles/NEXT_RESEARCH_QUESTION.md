# Next: actual scalar field pole and the separate VEV normalization

UTP1 supplies the local three-radial UV one-point input, not the full scalar
counterterm action. The next useful calculation is the gauge/scalar scalar
wavefunction p^2 pole in the SAME fixed-reference gauge and generator convention.
Use the actual derivative VSS vertex, vector propagator and complete scalar
Casimir matrices. Separate massive terms by UV degree rather than setting
all masses to zero in an unseparated scaleless integral. Verify the residue
by independent high-momentum/angular and Feynman-parameter tensor methods,
with a positive auxiliary IR mass and the original dimensional normalization.

Keep quantum-field normalization distinct from VEV/gauge-fixing-reference
normalization. The selected tadpole pole alone cannot determine either.
Sperling–Stöckinger–Voigt, arXiv:1305.1548v3 section3.2, explicitly distinguishes
them in Rxi gauges and supplies a useful primary comparator. Their background
BRST/source prescription must be matched before its separate VEV constant is
imported; it is not already supplied by the formal E1 source theorem.
No new background/source architecture or finite physical scheme is adopted.

The goal is another actual one-loop CT input and an exact identification of
remaining VEV/parameter obligations, not a tadpole counterterm fitted in
isolation. Preserve the older large finite vacuum-response warning. Ordinary
matter/Yukawa loops remain outside this explicitly declared scalar/gauge
subset; a future COMPLETE C1 inventory must respect its precise frozen
Yukawa-vertex-independent definition rather than silently excluding any
allowed pure-gauge fermion descendants. Do not resume paused flavor or select
fermion masses/Yukawas to complete such an inventory.
