from pathlib import Path
from hashlib import sha256
import json
D=Path(__file__).resolve().parent;p=json.loads((D/'matrix_diagnostic_preparation.json').read_bytes())
for n,h in p['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
diag=json.loads((D/'matrix_diagnostic_result.json').read_bytes());assert diag['old_positive_zero_real']==[0,328] and diag['corrected_positive_zero_real']==[290,38]
old=json.loads((D/'preparation.json').read_bytes());failed=json.loads((D/'replay_capture.json').read_bytes());assert failed['execution_state']=='FAILED' and failed['exit_code']==1
assert json.loads((D/'primary_capture.json').read_bytes())['execution_state']=='COMPLETED'
text=(D/'verify.py').read_text().replace("D/'validation_preparation.json'","D/'validation_preparation_v2.json'").replace("role+'_result.json'","('primary_result.json' if role=='primary' else 'replay_v2_result.json')").replace("'native_failures':0","'native_failures':1,'prelaunch_parse_failures':1")
with (D/'verify_v2.py').open('xb') as f:f.write(text.encode())
files=list(map(Path,p['input_sha256']))+[D/n for n in ['matrix_diagnostic_preparation.json','matrix_diagnostic_capture.json','matrix_diagnostic_result.json','CORRECTION_V2.md','prepare_v2.py','run_v2.py','prepare_validation_v2.py','run_validation_v2.py','verify_v2.py']]
for n in ['matrix_diagnostic.py','prepare_matrix_diagnostic.py','run_matrix_diagnostic.py','pilot_v2.py','verify_v2.py','prepare_v2.py','run_v2.py','prepare_validation_v2.py','run_validation_v2.py','MATRIX_DIAGNOSTIC_V2.md','CORRECTION_V2.md']:
 q=D/n
 with (D/(n+'.source.txt')).open('xb') as f:f.write(q.read_bytes())
 files.append(D/(n+'.source.txt'))
v=dict(old);v['schema']='C1_GS_UV_RADIAL_TADPOLE_PREPARATION_V2';v['input_sha256']={str(q):sha256(q.read_bytes()).hexdigest() for q in sorted(set(files))};v['native_failures_preserved']=1
with (D/'preparation_v2.json').open('xb') as f:f.write((json.dumps(v,indent=2,sort_keys=True)+'\n').encode())
print('V2_FROZEN',len(v['input_sha256']),flush=True)
