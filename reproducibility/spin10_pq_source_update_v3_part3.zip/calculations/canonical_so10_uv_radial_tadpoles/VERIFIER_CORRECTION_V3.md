# UTP1 V3 — verifier array conversion and diagnostic naming

The corrected spectral replay completed and agrees with the original exact
primary at the unchanged100digit/1e-50 native tolerance. The V2 independent
verifier FAILED with a Python TypeError: abs(finite) was applied to a list
while comparing the already calculated finite-difference array. Its exact
source/preparation/full capture are preserved; no completed validation receipt
was produced. This is a verifier implementation failure, not a coefficient
discrepancy or an accepted scientific result.

V3 replaces the two list abs calls by numpy.abs. Source inspection also found
that a later symbolic vector finite-part diagnostic reused the variable name
finite and would overwrite the numeric list intended for the JSON receipt.
Rename that local symbolic variable vector_finite_coefficient. Preserve its
same polynomial identity and nonzero finite-term control. These changes alter
no calculation input, scientific expression, tolerance, precision or resource.

Authenticate and reuse the completed native outputs. Rerun only the separate
verifier, with180s after imports/8GiB sampled/350MiB launch/4MiB package.
Count one failed native replay, one failed verifier and one prelaunch parse
failure explicitly. Retain all original and corrected sources/captures. No
finite-loop repetition, authority promotion or favorable input selection.
