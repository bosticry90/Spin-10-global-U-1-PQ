"""Read-only exact scalar packet and current normalization, no expected poles."""
from pathlib import Path
from functools import lru_cache
from collections import Counter
import json
import sympy as s
import mpmath as mp
R=Path(__file__).resolve().parents[2];C=R/'calculations';P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
w=s.Symbol('w',real=True)
read=lambda p:json.loads(p.read_bytes())
@lru_cache(None)
def clean(z):return s.cancel(s.expand(z))
def matrix(d):return s.SparseMatrix(*d['shape'],{(i,j):s.sympify(z) for i,j,z in d['entries']})
def coeffs():
 point=read(C/'canonical_so10_positive_higgs/POINT.json');base=read(C/'canonical_so10_scalar_benchmark/STAGE1_POINT.json')['free_coefficients'];base.update(point['changed_free_coefficients'])
 slots=read(C/'canonical_so10_singlet_tadpole/original_v2_result.json')['slots'];names=list(dict.fromkeys(n.partition(':')[0] for n in slots))
 cc={}
 for n in names:
  if n in base:cc[n]=s.Rational(base[n])
  elif n+':re' in base:cc[n]=s.Rational(base[n+':re'])+s.I*s.Rational(base[n+':im'])
 for n in ['muPhi','muPhiPhi','z6']:cc[n]*=s.sqrt(60)
 q=[s.sqrt(60),s.sqrt(s.Rational(3,5)),s.sqrt(s.Rational(3,5))];a,b,c=q
 lp=cc['lambdaPhi1']+s.Rational(7,60)*cc['lambdaPhi2'];lm=cc['lambdaPhiSigma1']-cc['lambdaPhiSigma2']/4
 cc['mPhi2']=-3*cc['muPhi']*a/(2*s.sqrt(60))-2*lp*a*a-lm*b*b-cc['lambdaPhiS']*c*c/2
 cc['mSigma2']=-lm*a*a-2*cc['lambdaSigma1']*b*b-cc['lambdaSigmaS']*c*c/2
 cc['mS2']=-cc['lambdaPhiS']*a*a-cc['lambdaSigmaS']*b*b-cc['lambdaS']*c*c;cc['mphi2']=60*(w+s.Rational(1,500))
 ast=read(P/'frozen_action_ast_a3/A38_parent_potential_ASTs.json')['directions'];degrees={}
 for n,row in ast.items():
  ct=Counter(t['name'] for t in row['density']['argument']['factors'] if t['node']=='Field')
  degrees[n]=[ct['Phi'],ct['Sigma']+ct['SigmaBar'],ct['S']+ct['SBar']]
 values=[]
 for slot in slots:
  n,sep,part=slot.partition(':');ns,ss=degrees[n][1:];z=cc[n]*(b/(4*s.sqrt(2)))**ns*(c/s.sqrt(2))**ss
  values.append(clean(s.im(z) if part=='im' else s.re(z)))
 pp=point['determinant_polynomial'];A=s.Integer(pp['A']);B=s.Integer(pp['B0'])+s.Integer(pp['B1'])*s.sqrt(15);K=s.Integer(pp['C0'])+s.Integer(pp['C1'])*s.sqrt(15)
 return slots,cc,degrees,values,q,(A,B,K)
def reduce_root(z,quad):
 A,B,K=quad;p=s.Poly(clean(z),w);assert p.degree()<=2
 return clean(p.nth(0)+p.nth(1)*w-p.nth(2)*(B*w+K)/A)
def root(quad):
 A,B,K=map(number,quad);v=(-B+mp.sqrt(B*B-4*A*K))/(2*A)
 assert abs(mp.im(v))<mp.mpf('1e-90') and mp.mpf('.00530')<mp.re(v)<mp.mpf('.00531');return mp.re(v)
def number(z,ww=None):
 z=s.sympify(z)
 if ww is not None:z=z.subs(w,s.Float(mp.nstr(ww,mp.mp.dps+3),mp.mp.dps+3))
 a,b=z.as_real_imag();return mp.mpc(str(s.N(a,mp.mp.dps+8)),str(s.N(b,mp.mp.dps+8)))
def nm(M,ww):return mp.matrix([[number(z,ww) for z in row] for row in M.tolist()])
def fmt(z):
 assert abs(mp.im(z))<mp.mpf('1e-75')*(1+abs(z));return mp.nstr(mp.re(z),75)
def block_inputs(role):
 slots,cc,deg,cv,q,quad=coeffs();packet=read(C/'canonical_so10_singlet_tadpole/original_v2_result.json');radial=read(C/'canonical_so10_radial_bosonic_tadpoles/original_v2_result.json')
 work=[]
 for row in packet['block_inputs']:
  n=len(row['sectors']);raw=[s.zeros(n) for _ in slots]
  for k,i,j,z in row['raw_H34_sparse']:raw[k][i,j]=s.sympify(z)
  H=sum((value*M for value,M in zip(cv,raw)),s.zeros(n)).applyfunc(clean);Ds=[]
  for direction in range(3):
   DD=s.zeros(n)
   for k,slot in enumerate(slots):
    name=slot.partition(':')[0]
    degree=deg[name][direction] if role=='primary' or direction==2 else radial['partial_degrees'][direction][name]
    if role=='replay' and direction==2:
     if slot in row['raw_D8']:DD+=cv[k]*s.Matrix(row['raw_D8'][slot])
     continue
    counts=[int(sec=='Phi') if direction==0 else int(sec in ['Sigma','SigmaBar']) if direction==1 else int(sec in ['S','SBar']) for sec in row['sectors']]
    DD+=cv[k]*s.Matrix(n,n,lambda i,j:(degree-counts[i]-counts[j])*raw[k][i,j])
   Ds.append(DD.applyfunc(clean))
  metric=list(map(s.Rational,row['metric']));work.append((row,H,Ds,metric))
 assert sum(row['dimension']*H.rows for row,H,Ds,metric in work)==328
 return work,cc,q,quad,packet,radial
def casimirs():
 data=read(P/'frozen_a10_physical_reconciliation/full_primary.json');out={}
 for sector,size in [('Phi',54),('Sigma',252),('phi',20),('S',2)]:
  Cas=s.SparseMatrix(size,size,{})
  for row in data['representation_matrices'][sector]:
   rho=matrix(row);Cas-=rho*rho
  val=clean(s.trace(Cas)/size);assert not (Cas-val*s.eye(size)).applyfunc(clean).todok();out[sector]=val
 return out
