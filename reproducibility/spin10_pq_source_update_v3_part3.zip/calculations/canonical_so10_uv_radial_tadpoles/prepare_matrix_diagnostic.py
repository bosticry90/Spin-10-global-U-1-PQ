from pathlib import Path
from hashlib import sha256
import json
D=Path(__file__).resolve().parent;p=json.loads((D/'preparation.json').read_bytes())
for n,h in p['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
candidate=(D/'pilot.py').read_text()
replacements={
'Hn=mp.matrix(H.rows,H.cols,lambda i,j:Hn[i,j]/(sq[i]*sq[j]))':'Hn=mp.matrix([[Hn[i,j]/(sq[i]*sq[j]) for j in range(H.cols)] for i in range(H.rows)])',
'Dn=mp.matrix(H.rows,H.cols,lambda i,k:Dn[i,k]/(sq[i]*sq[k]))':'Dn=mp.matrix([[Dn[i,k]/(sq[i]*sq[k]) for k in range(H.cols)] for i in range(H.rows)])',
"D/'preparation.json'":"D/'preparation_v2.json'"}
for a,b in replacements.items():assert candidate.count(a)==1;candidate=candidate.replace(a,b)
with (D/'pilot_v2.py').open('xb') as f:f.write(candidate.encode())
files=list(map(Path,p['input_sha256']))+[D/n for n in ['preparation.json','primary_capture.json','primary_result.json','replay_capture.json','MATRIX_DIAGNOSTIC_V2.md','matrix_diagnostic.py','pilot_v2.py','prepare_matrix_diagnostic.py','run_matrix_diagnostic.py','diagnostic_launch_parse_failure.txt']]
v={'schema':'UTP_MATRIX_DIAGNOSTIC_PREPARATION_V1','input_sha256':{str(q):sha256(q.read_bytes()).hexdigest() for q in files}}
with (D/'matrix_diagnostic_preparation.json').open('xb') as f:f.write((json.dumps(v,indent=2,sort_keys=True)+'\n').encode())
print('DIAGNOSTIC_FROZEN',len(files),flush=True)
