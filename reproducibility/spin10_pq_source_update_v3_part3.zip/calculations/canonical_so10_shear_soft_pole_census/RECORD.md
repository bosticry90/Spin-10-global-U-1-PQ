# Complete flat single-probe shear soft-pole census V1

Base d4e8c50e5385e7f99a9f8bc71ed1bdfa6d5ed161,main. Previous turn PROGRESS.
Question:do ALL one-loop kernels in the actual fixed-J special-shear identity
admit a common nonexceptional IR domain,or do zero-transfer insertions force
stronger soft poles? This follows the measured XZ response;it is not a new
component-tensor expansion or an excuse to ignore the remaining quantum gaps.

Scope:flat A=0 finite external Fourier/coupling/engineering coefficients,
one local shear probe u,all retained sources and whole source products.
Use the full Cartesian fields,not a vacuum substitution creating new
zero-transfer vertices. Mark source/ordinary fields and local probes with
generic momenta whose nonempty proper partial sums do not vanish. When a
loop has no external transfers it is a single marked vertex with ordinary
zero-transfer decorations. Do not infer constant-probe or vacuum/exceptional
limits. Off-flat IR-regulator variations and general testfield extensions are
explicit separate questions,not covered by flat vertex counting.

Freeze both full643-field Hessian records,all34 physical second-variation
ASTs and their index-jet graphs,portable exact GF/master maps,the actual K,
20 field/37 source flows and prior support/Wick/UV/IR receipts. No discarded
physical/GF/source block. No scalar/auxiliary elimination or reference change.
The positive scalar REFERENCE masses are regulators,not physical adoption.

Required new evidence:
1. Independently scan all34 literal physical Hessians and entire GF density
at zero external means. Apart from qualified absorbed reference kinetic and
width blocks,the ONLY permitted zero-transfer interaction ports must be
scalar/scalar and auxiliary/scalar. Verify this rather than assume generic
nonexceptional momenta eliminate quadratic insertions. Keep arbitrary finite
scalar reference-mass differences. Confirm every source Hessian retains an
external source until it is differentiated into a marked probe.
2. Check K/flows have no jets and the20 field flows shift only auxiliaries;
verify there are no differentiated auxiliaries in the actual GF/source
action. Then localizing the shear by u retains its actual source products
without introducing an unaccounted physical-action current. Reuse qualified
C+source+XfieldS identity,not a fitted loop coefficient.
3. Prove the arbitrary-length zero-transfer propagator language has soft
degree<=2. G_LL=0,scalar reference propagators bounded at q0,mixed B/L pole1,
BB/odd pole2. Scalar/scalar repeats are allowed;do not stop at a sampled
length. Use a finite-state cycle certificate plus an independent block-inverse
or resolvent proof without inverting physical couplings/masses.
4. Establish a common nonexceptional IR bound for every finite one-loop
single-insertion word using these decorated propagators. Include whole
source-product Hessians,nonlinear corners and Euler-times-mean terms.
State exactly how this supports formal one-loop Wick/Legendre identity
construction and FP transport. Do not claim global measure/QAP,off-flat
spectral calculus or distributional extension merely from convergence.

Primary:physical graph/AST support comparison,GF row scan,forward port
language. Replay:literal AST zero-field evaluation,reverse port paths,
quadratic differentiation and independent block algebra. Separate verifier:
own AST/GF scan,cycle proof,noncommuting block fixture and analytic review.
Controls:invent forbidden zero-transfer ghost mass,omit M or scalar quadratic
ports,set local probe momentum0,replace G_LL zero by nonzero,omit whole source
products. A structural envelope cannot detect a wrong allowed coefficient;
state this insensitivity instead of claiming color-coefficient verification.

Two sequential native120s after imports/8GiB sampledprivate;separate verifier
120s/8GiB;350MiB available-commit floor,new files<2MiB. Freeze before launch,
full captures before assertions,preserve failures/new correction versions.
No subagents,large Gamma expansion,295-vector measurement or scheme adoption.

Acceptance requires complete actual support coverage,arbitrary-length proof,
native agreement,separate validation and committed-byte authentication.
If a forbidden port occurs,stop the affected universal IR claim and preserve
the finding. Possible outcomes:common bounded coefficient domain,actual
obstruction,underdefinition or inconclusive execution. Keep foundation and
director acceptance separate. No state/Gamma/old evidence/policy changes.
Authority113/34of39,source38,Gamma874873/source146663,369/664,295 unmeasured
profiles,custody2/seven and protected warnings/blocks/pause remain. Full
source-free Slavnov,global contacts/QAP/IR/measure/equivalence/E5/A5 remain
unqualified. Shared action,ASTs,charts,software and AI author limit independence.
