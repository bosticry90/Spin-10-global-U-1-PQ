# Complete flat soft-pole closure and formal local-probe shear relation

Prospective bounded qualification requires completed separate validation and
committed-byte checks. Both native routes completed and agree. This result
concerns formal one-loop coefficients,not a continuum quantum measure.

All34 actual physical Hessian ASTs agree with their index-jet graphs on the
zero-mean ports. Only gauge/scalar reference kinetics and the four scalar
quadratic potential terms survive. The full GF quadratic-density census is:

| Ports | Jets | g power | Density rows |
|---|---:|---:|---:|
| B/L |1|0|188|
| L/L |0|0|26|
| L/scalar |0|1|432|
| ghost/antighost |2|0|188|

The reference kinetic/width blocks are authenticated from the qualified full
inverse. The unabsorbed zero-transfer envelope is scalar/scalar and L/scalar,
including arbitrary finite scalar reference-mass differences. None is
discarded to obtain favorable IR behavior. Every Hessian of the35,162 source
action rows retains its external source,or a marked source probe when that
source is differentiated. All643 fields/sources remain.

The actual36-term K and its20 auxiliary field/37 source flows have no jets.
The full GF/master-map scan finds no differentiated auxiliary. This permits
a local shear parameter u with the actual whole source products and the
qualified pointwise action identity. u is a bookkeeping probe,not a newly
adopted physical field or a constant parameter imposed prematurely.

The arbitrary-length zero-transfer propagator language has a finite
inductive closure. Its endpoint pole degrees are BB2,BL1,LB1,BS1,SB1,SS0,
and odd/odd2. Its only cycle is a scalar/scalar repeat of soft weight0.
No chain exceeds pole degree2. An independent noncommuting block-resolvent
fixture verifies the same structure. No physical mass is inverted or adopted.
A forbidden zero-transfer ghost mass or a false nonzero G_LL creates a
positive soft cycle and defeats the conclusion,as the controls demonstrate.

On a compact nonexceptional region of the labeled field/source/local-probe
momenta,distinct routing shifts are separated. At each soft center only
one decorated block can be singular,and it is at worst1/q². Every finite
single-insertion loop is therefore locally integrable. The two provisional
IR smoothings can be removed with an O(epsilon²) bound for each fixed
coefficient,uniform in positive heat. The complete inverse-heat group is
reduced first;source-product Hessians and nonlinear corners remain.

This supplies a common domain for the actual flat one-loop Wick/Legendre
construction. The full Hessian product rule and exact regulated inverse give

    I_C+I_source-I_reg,total+sum Gamma_Lambda I_XLambda=0

coefficientwise,with one local shear probe and all retained sources. The
diagonal trace of the actual auxiliary-shift tangent vanishes by its field
support. This result uses whole source products and both heat/IR regulator
responses. Uniform IR removal and the common UV finite-part map transport
the relation on this domain,including power-contact convolutions. No unknown
coefficient is selected to obtain zero.

This is a formal flat nonexceptional single-probe identity,not the complete
renormalized special-shear theorem or QAP. It does not extend through
exceptional momenta,make the shear probe constant,construct arbitrary
testfield products,or handle off-flat variations of chi(P[A]). The latter
can bring inverse IR-scale factors in raw Duhamel expressions and requires
its own divided-difference or equivalent uniform bound. The previous
noncommuting zero-momentum limits remain valid. Multiple-probe contacts,
causal/Lorentzian construction,measure,full source-free Slavnov and E5/A5
remain unqualified. kappa and b0 stay distinct/free;no scheme is adopted.

Next smallest action:analyze off-flat IR multiplier variations at finite
external Fourier order,using the actual covariant generator P and its
ordered source/field descendants. Determine whether separated soft centers
also control the divided differences,or whether an actual new IR term
survives. Then assess the exceptional/testfield extension as a separate
normalization problem. No295-vector expansion is justified by this result.

Track B:the work closes a complete propagator-language question rather than
counting sampled paths. It preserves scalar mass/reference insertions and
tests the premises behind generic-momentum reasoning. The census is
insensitive to a wrong coefficient within an allowed port class;qualified
action/inverse/graded/Wick inputs and shared software/AI authorship remain
common-error limitations. Read receipts for actual verification/failures and
runtime. Earlier broad sealed/custody checks are reused,not newly replayed.

No authority/state/Gamma/policy/old-evidence changes. Authority113/34of39,
sevenfalseflags,source38,Gamma874873/source146663,369/664,295 unmeasured vector
profiles,custody2/seven and all protected quartet/physical warnings,blocks
and flavor pause retain their established dispositions.
