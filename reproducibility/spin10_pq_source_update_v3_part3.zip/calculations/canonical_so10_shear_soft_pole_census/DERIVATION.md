# Zero-transfer blocks and a common local-probe domain

Prospective result requiring actual support checks and separate validation.
All statements use the frozen flat Cartesian reference,positive scalar
reference masses and finite coefficient domain in RECORD. No physical
prescription is adopted. This is not an IR theorem for arbitrary backgrounds.

## 1. Actual support is the decisive premise

Evaluate the full physical Hessian at B=x=A=0 and set the external BV sources
to zero only for the unmarked propagator classification. The34 literal
physical second-variation ASTs and their independent index-jet graphs must
agree that surviving physical entries are gauge/scalar reference kinetics
and scalar/scalar quadratic terms. Higher scalar and gauge interactions
leave external fields. The complete GF row scan must show only the absorbed
B/L derivative,LL width and ghost kinetic quadratic blocks plus the retained
M: L/S quadratic mixing. Every Hessian of sum J R keeps J as an external
coefficient;differentiating J creates a marked insertion rather than an
unnoticed zero-transfer interaction. Actual GF/source jets must be checked.

After subtracting the exact qualified reference quadratic terms,the
zero-transfer vertex envelope is therefore

    P: S -> S,     M: L -> S and S -> L.

P includes arbitrary finite repetitions of actual scalar potential/reference
mass differences. M is not discarded. This is a support statement,not a new
measurement or a positivity assumption for the physical scalar mass matrix.
The physical action and all643 directions remain. No scalar is eliminated.

## 2. Arbitrary-length soft-pole certificate

On the flat Euclidean soft chart,the reference covariance has port bounds

    G_BB=O(r^-2), G_BL/G_LB=O(r^-1), G_SS=O(1), G_ff=O(r^-2),
    G_LL=G_LS=G_SL=0.

Transverse/projector components are bounded by the same powers;odd pair
signs do not worsen norms. Each scalar reference eigenvalue is positive,
so every finite scalar chain is bounded at r0. For a chain (G V0)^n G,
the only transitions in G V0 are B->S(weight1),S->S(weight0) and
S->L(weight0). Its only directed cycle is S->S with zero soft weight.
No path can contain more than one B->S and one final L->B propagator.
Thus ALL finite lengths have total pole degree<=2. A finite maximum-length
sample alone would not prove this;the zero-cycle certificate is essential.

The decorated endpoint envelope is BB2,BL1,LB1,BS1,SB1,SS0,ff2.
LL,LS,SL remain zero. A separate block-resolvent proof gives,formally,

    G_BB=-(W-E D^-1 E^t)/q²,
    G_BL=i/q, G_LB=-i/q,
    G_BS=-i E D^-1/q, G_SB=i D^-1 E^t/q,
    G_SS=D^-1, G_LL=G_LS=G_SL=0,

for the longitudinal block K=[[0,iq,0],[-iq,W,E],[0,E^t,D]]. Interpret D^-1
as a formal series around the POSITIVE reference scalar covariance with
finitely many P insertions,not as an adopted inverse of a physical mass.
E,W,P can be noncommuting matrices. The transverse BB part retains its
reference r^-2 bound. This proves the same envelope without port enumeration.

For comparison,a forbidden ghost/ghost zero-transfer mass would create an
f->f positive-weight cycle and arbitrarily high repeated soft poles. A
nonzero G_LL would similarly permit additional M cycles. These controls
expose why generic external momenta alone are not a proof.

## 3. Localize the actual shear before choosing momenta

The actual K has no jets and its only field flows are the20 auxiliary shifts.
No auxiliary derivative occurs in the actual GF/source density. Therefore
the local even parameter u(x) multiplies X_Lambda and its actual37 source
flows. The physical action is auxiliary independent. The previously
qualified pointwise C+sum XJ R+Xfield S identity is retained with this u.
No source is changed as an external number inside a path integral;all source
dependence is handled by whole insertions. The local parameter is an external
probe,not a new physical field or canonical pair. In the nonlocal regulator
terms its momentum and all ordered heat factors must remain explicit.

For any fixed finite external coefficient,choose momenta in an open compact
nonexceptional region:all nonempty proper partial sums of its labeled local
probes and ordinary external fields/sources are separated from zero,subject
only to overall conservation. This includes the effective probe obtained by
folding tree coefficients into Gamma_Lambda I_X. Different routing shifts of
the remaining nonzero-transfer vertices are then separated by d>0. The
allowed u momentum is not automatically0. Setting it0 can merge the two
propagators adjacent to an insertion and invalidate the bound.

If a loop has no nonzero-transfer vertices,it is one marked insertion with
a zero-transfer decorated covariance. Its trace is O(r^-2),still integrable
in d4q. Free actual X tadpoles are additionally zero by the qualified C_j/a12
support;that extra zero is not needed to replace the general integrability
argument. Whole source products are one marked polynomial,not several
independently subtracted means or a multiple-probe contact construction.

## 4. Uniform infrared removal

At every possible soft center only ONE decorated covariance block is
singular,and it is at worst C/r². All other centers are separated by d.
Local differential vertices give bounded numerators near these finite
centers. On a compact nonexceptional kinematic region the resulting
one-loop integrand has an integrable local majorant. The inverse-heat
special-regulator group must FIRST be reduced by its qualified adjacent
inverse identities;its remaining factors have the same propagator ports.
The nonlinear corner is one marked open-path contraction with external
inverse regulator factors. Their external momenta must also remain away
from zero;the reference corner is exactly block-zero.

For either provisional smooth IR witness chi_k,a finite-word difference
between restricted and unrestricted covariances telescopes into terms with
one factor1-chi_k, bounded by k exp(-|q+K|²/epsilon²). Uniformly in an anchor,

    integral d4q exp(-|q+K|²/epsilon²)/|q-Q|² <=2pi² epsilon².

This follows by splitting |q-Q| at epsilon,as in the actual XZ calculation.
Use finitely many disjoint soft balls and their complement. Polynomial
numerators contribute only bounded factors on the balls;Gaussian tails
control them outside. Thus each finite coefficient difference is O(epsilon²)
with a constant depending on its finite data and kinematic compact set.
The bound is uniform for 0<t<=t0:positive heat and its finitely many
derivatives have bounded Gaussian-polynomial factors. Zero-transfer P chains
can have many scalar lines,but every fixed coefficient contains only
finitely many and every one remains bounded at soft momentum.

The IR-regulator response has1-chi factors after adjacent inverse reduction;
the same bound applies. External inverse-chi corrections vanish uniformly
when their external momenta stay nonzero. No negative epsilon powers are
assumed harmless. At A=0 chi is a scalar multiplier;off-flat variations of
chi(P[A]) need a NEW divided-difference/Duhamel bound and are not included
by treating them as ordinary local vertices.

The IR differences are UV-smoothing,so this bound also applies after the
common ultraviolet finite-part construction. All power-contact convolutions
and ordered source/field derivatives remain. It supplies a common flat
nonexceptional coefficient domain,not the exceptional-momentum distribution
extension. The measured noncommuting p0/epsilon0 example remains intact.

## 5. Formal identity construction and its ceiling

At fixed positive t,epsilon define the one-loop functions coefficientwise
by the actual ordered log-Hessian program and the single-insertion Wick map.
The exact regulated inverse is used,including R_t+R_IR. On the common
nonexceptional domain the complete reduced coefficient integrals exist.
For the auxiliary-even field vector X,the graded second-variation product
rule is

    Hess(X_i S_t,i)=X_i Hess(S_t,i)+X_i'' S_t,i
                    +A_L H_t+H_t A_R.

Subtracting Gamma1,i X_i and Gamma0,i I_Xi^(1) cancels the first two terms.
The remaining complete trace uses H_t G_t=G_t H_t=I and becomes the
diagonal field trace of A_L+A_R. It is zero by the actual off-even/odd support
of DX,including local u. At fixed finite perturbative order use the exact
truncated inverse identities,not an incorrect untruncated equality. The
same convention and all nonlinear corners/source products are inherited
from the qualified actual Hessian/loop-leg checks. This is algebraic
one-loop Wick/Legendre construction,not proof of a continuum measure.

Using Xfield S=-C-sum XJ R gives the COMPLETE fixed-J special-shear relation

    I_C+I_source-I_reg,total+sum Gamma_Lambda I_XLambda=0

within this flat,single-local-probe,finite-coefficient nonexceptional domain.
All retained sources remain. The uniform IR removal then carries it to
epsilon0 there,and the common linear FP carries it to the corresponding
formal finite parts. The same logarithmic-scale/kappa direction can be kept
throughout;it does not determine b0 or all finite mixing parameters.

Qualification of this formal local-probe relation is contingent on ALL
actual support and algebra checks above. It must not be relabeled complete
renormalized special-shear/QAP restoration. Simultaneous extension through
exceptional momenta,off-flat spectral variations,tempered/causal testfield
products,multiple-probe contacts,global measure and full source-free Slavnov
remain outside this result. No source-free loop tensor is fitted or inserted
into Gamma. This theorem tests a formerly conditional finite-coefficient
premise;it does not promote the protected E5/A5 flags or physical viability.
