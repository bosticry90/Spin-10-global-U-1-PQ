from pathlib import Path
from hashlib import sha256
from collections import Counter
from functools import lru_cache
from itertools import product,combinations
import json,gzip,os,sys,time,threading
import sympy as s
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
P=R/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def ast_support(node):
 typ=node['node']
 if typ=='Field':
  name=node['name'];return {((name,0),)} if name.startswith(('h_','k_')) else set()
 if typ=='ExactScalar':return {()} if node['value']!='0' else set()
 if typ in ['Parameter','StructureConstant','RepresentationGenerator']:return {()}
 if typ=='Add':return set().union(*(ast_support(v) for v in node['terms']))
 if typ=='OrderedProduct':
  ans={()}
  for factor in node['factors']:
   part=ast_support(factor);ans={tuple(sorted(a+b)) for a in ans for b in part}
   if not ans:break
  return ans
 if typ=='PartialDerivative':
  ans=set()
  for word in ast_support(node['argument']):
   for k,(name,j) in enumerate(word):ans.add(tuple(sorted(word[:k]+((name,j+1),)+word[k+1:])))
  return ans
 if typ=='LocalActionTerm':return ast_support(node['density'])
 if typ in ['LorentzContraction','GroupContraction']:
  return ast_support(node.get('expression',node.get('argument')))
 raise AssertionError(('UNCLASSIFIED_ACTUAL_AST_NODE',typ))

def graph_support(rows):
 ans=set();zero_rows=0
 for pars,atoms,co in rows:
  fields=[atom for atom in atoms if atom[0]=='Field']
  if not all(a[1].startswith(('h_','k_')) for a in fields):continue
  if co=='0':continue
  assert len(fields)==2 and sum(a[1].startswith('h_') for a in fields)==sum(a[1].startswith('k_') for a in fields)==1
  ans.add(tuple(sorted((a[1],len(a[3])) for a in fields)));zero_rows+=1
 return ans,zero_rows

def role(n):
 if n=='B' or n.startswith('B'):return 'B'
 if n.startswith('x_'):return 'S'
 if n.startswith('C'):return 'f'
 if n.startswith(('ub','bar')):return 'f'
 if n.startswith('L') or(n.startswith('b') and n[1:].isdigit()):return 'L'
 if n.startswith('A'):return 'A'
 if n.startswith('J'):return 'J'
 raise AssertionError(('UNKNOWN_ACTUAL_FIELD',n))
def token(n):
 a,sep,b=n.partition('__');return a,tuple(int(k) for k in b) if sep else ()

def maxmul(a,b):
 out={}
 for (i,j),v in a.items():
  for (k,l),w in b.items():
   if j==k:out[i,l]=max(out.get((i,l),-1000),v+w)
 return out
def join(a,b):
 out=dict(a)
 for key,v in b.items():out[key]=max(out.get(key,-1000),v)
 return out
def close(G,V,reverse=False):
 ans=dict(G);snapshots=[]
 for n in range(9):
  nxt=maxmul(maxmul(G,V),ans) if reverse else maxmul(maxmul(ans,V),G)
  both=join(ans,nxt);snapshots.append(len(both))
  if both==ans:return ans,n,snapshots
  ans=both
 raise AssertionError('NO_FINITE_SOFT_CLOSURE_WITHIN_CERTIFICATE_BOUND')
def cycles(T):
 ans=set();states=['B','L','S','f']
 def walk(at,start,path,weight):
  for (i,j),w in T.items():
   if i!=at:continue
   if j==start:
    word=path;rots=[word[k:]+word[:k] for k in range(len(word))];ans.add((min(rots),weight+w))
   elif j not in path:walk(j,start,path+(j,),weight+w)
 for st in states:walk(st,st,(st,),0)
 return sorted(ans)

def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();route=sys.argv[1]
 assert route in ['primary','replay'];prep=read(O/'preparation.json');assert digest(Path(__file__))==prep['source_sha256']
 for raw,h in prep['input_sha256'].items():assert digest(Path(raw))==h,raw
 allowed=set(prep['read_json'][route])
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  p=Path(os.fsdecode(args[0])).resolve()
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('SOFT_POLE_WORKER_WRITE')
  if p.suffix=='.json':assert str(p) in allowed,('UNDECLARED_SOFT_POLE_JSON',str(p))
 sys.addaudithook(guard)
 refrecord=read(P/f'frozen_a10_e5_full_hessian/{route}.json');ref=refrecord['retained_reference']
 assert len(ref['field_order'])==643 and ref['all643_inverse_directions_both_checked'] and ref['auxiliary_auxiliary_Green_zero']
 assert ref['literal_GF_all_413449_entries_matched'] and not ref['scalar_reference_masses_are_adopted_physical_parameters']
 physical=[]
 for term in refrecord['physical_Hessian_program']['all_34_literal_terms']:
  graph,count=graph_support(term['index_jet_graph_coefficients']);ast=ast_support(term['mixed_second_variation_AST'])
  # Compare complete role/jet signatures;raw tensor index relabelings are
  # independently frozen at the inherited Hessian checkpoint.
  canon=lambda words:sorted(set((tuple(sorted('B' if n[2:]=='B' else 'S' for n,j in w)),sum(j for n,j in w)) for w in words))
  gc=canon(graph);ac=canon(ast);assert gc==ac,('ACTUAL_PHYSICAL_AST_GRAPH_SUPPORT_MISMATCH',term['term_id'],gc,ac)
  chosen=gc if route=='primary' else ac
  assert all((ports,jets) in [(('B','B'),2),(('S','S'),2),(('S','S'),0)] for ports,jets in chosen)
  physical.append({'term_id':term['term_id'],'zero_mean_graph_rows':count,'ports_jets':[[list(ports),jets] for ports,jets in chosen]})
 assert len(physical)==34
 data=json.loads(gzip.decompress((R/'tools/portable_dh_v1/inputs.json.gz').read_bytes()))
 g=s.symbols('g10');gf=Counter();gf_quadratic_indices=[]
 @lru_cache(None)
 def gp(txt):
  poly=s.Poly(s.sympify(txt),g);powers={int(k[0]) for k,v in poly.terms() if v!=0};assert len(powers)==1;return next(iter(powers))
 for rowid,row in enumerate(data['gauge_fixing_density']):
  word=[token(n) for n in row['word']]
  if any(role(n)=='A' for n,j in word):continue
  if route=='primary':keep=len(word)==2
  else:
   # Literal two-field differentiation at zero remaining means. The
   # original row is retained once even when both variation orders occur.
   keep=any(len(word[:i]+word[i+1:j]+word[j+1:])==0 for i in range(len(word)) for j in range(i+1,len(word)))
  if not keep:continue
  key=tuple(sorted(role(n) for n,j in word)),sum(len(j) for n,j in word),gp(row['coefficient'])
  assert key in [(('B','L'),1,0),(('L','L'),0,0),(('f','f'),2,0),(('L','S'),0,1),(('B','B'),2,0)],('FORBIDDEN_ZERO_TRANSFER_GF_PORT',key,row)
  gf[key]+=1;gf_quadratic_indices.append(rowid)
 source_count=sum(len(v) for v in data['master_field_maps'].values());assert len(data['master_field_maps'])==643
 # All source Hessians keep J;no hidden source-independent quadratic vertex.
 auxjets=[]
 for origin,rows in [('GF',data['gauge_fixing_density'])]+list(data['master_field_maps'].items()):
  for i,row in enumerate(rows):
   for tok in row['word']:
    n,j=token(tok)
    if role(n)=='L' and j:auxjets.append([origin,i,tok])
    if origin!='GF':assert role(n)!='J'
 assert not auxjets
 old=read(R/f'calculations/canonical_so10_correlated_contact_lift/{route}_result.json')
 assert len(old['complete_K'])==36 and len(old['all643_nonzero_field_flows'])==20 and len(old['all643_nonzero_source_flows'])==37
 assert not old['Hamiltonian_XS_plus_QK_residual']
 for name,rows in old['all643_nonzero_field_flows'].items():assert role(name)=='L'
 for rows in [old['complete_K']]+list(old['all643_nonzero_field_flows'].values())+list(old['all643_nonzero_source_flows'].values()):
  assert all(not token(tok)[1] for row in rows for tok in row['word'])
 assert gf[(('L','S'),0,1)]>0
 # Arbitrary-length maximum soft-pole induction certificate.
 G={('B','B'):2,('B','L'):1,('L','B'):1,('S','S'):0,('f','f'):2}
 V={('S','S'):0,('S','L'):0,('L','S'):0}
 C,steps,history=close(G,V,route=='replay');assert max(C.values())==2
 assert join(C,maxmul(maxmul(C,V),G))==C and join(C,maxmul(maxmul(G,V),C))==C
 cyc=cycles(maxmul(G,V));assert all(weight==0 for path,weight in cyc)
 badghost=dict(V);badghost['f','f']=0;badL=dict(G);badL['L','L']=2
 assert any(weight>0 for path,weight in cycles(maxmul(G,badghost)))
 assert any(weight>0 for path,weight in cycles(maxmul(badL,V)))
 # Noncommuting block inverse is a fixture;D is not a physical mass inverse.
 q=s.symbols('q',nonzero=True);W=s.Matrix([[3,1],[1,4]]);E=s.Matrix([[1,2],[0,1]]);D=s.Matrix([[q*q+5,1],[1,q*q+7]]);Di=D.inv();I=s.eye(2);zero=s.zeros(2)
 K=s.BlockMatrix([[zero,s.I*q*I,zero],[-s.I*q*I,W,E],[zero,E.T,D]]).as_explicit()
 Q=s.BlockMatrix([[-(W-E*Di*E.T)/(q*q),s.I*I/q,-s.I*E*Di/q],[-s.I*I/q,zero,zero],[s.I*Di*E.T/q,zero,Di]]).as_explicit()
 if route=='primary':assert all(s.cancel(v)==0 for v in K*Q-s.eye(6))
 else:assert all(s.cancel(v)==0 for v in Q*K-s.eye(6))
 assert W*E!=E*W
 for (i,j),power in [(('B','B'),2),(('B','S'),1),(('S','B'),1),(('S','S'),0)]:
  ii={'B':0,'S':2}[i];jj={'B':0,'S':2}[j]
  assert all(s.cancel(q**power*Q[2*ii+a,2*jj+b]).subs(q,0).is_finite for a in range(2) for b in range(2))
 # Explicit open nonexceptional kinematic domain for every finite label set.
 domain=[]
 for n in range(2,9):
  p=[2**i for i in range(n-1)];p.append(-sum(p))
  assert all(sum(p[i] for i in subset)!=0 for k in range(1,n) for subset in combinations(range(n),k))
  domain.append({'labels':n,'momenta':p,'minimum_nonempty_proper_sum':1})
 merged=[0,1,0];assert len(set(merged))<len(merged)
 ir=read(R/f'calculations/canonical_so10_shear_ir_response/{route}_result.json')
 assert ir['extra_IR_regulator_insertion_required_not_dropped'] and not ir['physical_IR_witness_adopted']
 result={'schema':'SHEAR_SOFT_POLE_CENSUS_V1','route':route,'physical_all34_terms':physical,
  'complete_GF_quadratic_census':[{'ports':list(p),'jets':j,'g':h,'density_rows':n} for (p,j,h),n in sorted(gf.items())],
  'GF_quadratic_rows_sha256':sha256(json.dumps(gf_quadratic_indices,separators=(',',':')).encode()).hexdigest(),
  'source_action_rows':source_count,'all643_source_Hessians_retain_external_J':True,'auxiliary_derivative_occurrences':len(auxjets),
  'actual_K36_field20_source37_localization_checks':True,
  'zero_transfer_vertex_envelope':['SS','SL','LS'],'zero_transfer_cycles':[[list(p),w] for p,w in cyc],
  'arbitrary_length_soft_closure':[[i,j,v] for(i,j),v in sorted(C.items())],'maximum_soft_pole_degree':max(C.values()),
  'both_inductive_closure_inequalities_verified':True,'noncommuting_block_inverse_checked':True,
  'nonexceptional_domain_witnesses':domain,'new_model_color_poles_measured':False,
  'common_flat_single_local_probe_finite_coefficient_IR_domain':True,
  'formal_one_loop_fixedJ_shear_identity_status':'constructed coefficientwise by full Hessian Wick/inverse identity,whole products and regulated source conventions;flat nonexceptional finite coefficients only',
  'uniform_IR_removal':'O(epsilon^2) for each finite word,on fixed kinematic compact sets with separated partial sums and positive scalar reference masses;positive heat uniform',
  'offflat_IR_variation_bound_or_exceptional_distribution_extension_proved':False,
  'kappa_b0_fixed_identified_or_IR_scheme_adopted':False,
  'controls':{'forbidden_ghost_mass_positive_soft_cycle_detected':True,'false_nonzero_G_LL_positive_soft_cycle_detected':True,'M_and_scalar_quadratic_omission_detectable_by_actual_support':True,'constant_probe_can_merge_soft_centers':True,'source_products_kept_as_whole_marked_polynomials':True,'wrong_allowed_coefficient_detected_by_support_census':False},
  'scientific_disposition':'COMPLETE_FLAT_SINGLE_PROBE_SOFT_PORT_CLOSURE_AND_FORMAL_NONEXCEPTIONAL_ONE_LOOP_SHEAR_IDENTITY_DOMAIN_NOT_GLOBAL_QAP',
  'no_Gamma_state_policy_old_evidence_scheme_change':True,
  'shared_limits':'same frozen physical AST/GF/master/source/reference and prior graded Wick/UV proofs,SymPy and AI author;support does not validate shared physical assumptions or allowed coefficient values',
  'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()

if __name__=='__main__':main()
