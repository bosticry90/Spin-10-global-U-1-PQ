# Verifier V2: normalize prose whitespace, preserve all mathematical checks

The first separate verifier completed its native comparison,all34 AST/GF
checks,arbitrary-length closure,dense inverse and nontrivial graded Wick
fixture. It then failed the final exact prose-presence assertion for
"whole source products":the frozen derivation wraps that phrase across a
line break. This is an evidence-harness failure,not a failed physics test.

Preserve verify.py,its exact source copies,validation_preparation.json,
validation_capture.json and the external full capture unchanged. No receipt
was produced by that failed run. New verify_v2.py normalizes whitespace only
for the prose-presence assertions and records one failed verifier execution.
Every mathematical assertion,domain restriction and acceptance condition is
unchanged. No native calculation or source evidence is rerun or edited.

One corrected verifier is delegated under AGENTS. Limit120s after imports,
8GiB sampledprivate,350MiB launch floor. Freeze its source,new controller and
inputs including all failed bytes before execution. New capture filenames;
the usual validation_receipt.json may be created only on completed success.
