# Verifier V3: correct the prose binding after inspection

V2 again reached the final prose-presence assertion and failed. V2's diagnosis
was wrong:the exact phrase "whole source products" is absent,not line-wrapped.
The frozen derivation actually states "whole insertions" and
"corners/source products". All requested passages were inspected and checked
before preparing this correction. V2 and its mistaken diagnosis are preserved.

V3 keeps the normalized-whitespace check but binds BOTH existing phrases.
This is a correction of an ancillary prose binding,not replacement of the
whole-product mathematical requirement. All AST/GF/source,inductive closure,
dense inverse,graded Wick and domain assertions remain unchanged. The
analytical review still explicitly requires whole source-product Hessians.
The full derivation and native evidence are unchanged.

Preserve both failed verifier sources,preparations and complete captures.
There is no completed receipt from V1 or V2. The corrected verifier reports
two failed verifier executions and zero failed native runs. One new V3 run
uses the same120s/8GiB/floor350MiB limits,with fresh frozen files and captures.
No scientific claim is qualified until it actually completes.
