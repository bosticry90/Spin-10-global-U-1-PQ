from pathlib import Path
from hashlib import sha256
import json,itertools,time,threading,os,sys
import mpmath as mp
from masters_v2 import sunset,sunset_xy,tadpole,tadpole_e,tadpole_ee,clausen,model_sample,stable_h
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
def main(role):
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start()
 p=json.loads((O/'preparation_v2.json').read_bytes())
 for n,h in p['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
 mp.mp.dps=50;method='dilog' if role=='primary' else 'angular';tol=mp.mpf('1e-25')
 def near(a,b):assert abs(a-b)<tol*(1+abs(a)+abs(b)),(a,b)
 # Small sensitive convention/finite-normalization checks FIRST.
 cl=clausen(mp.pi/3);ieq=-mp.mpf(15)/2+2*mp.sqrt(3)*cl;near(sunset(1,1,1,method=method),ieq)
 near(sunset(0,1,1,method=method),-5);near(sunset(0,0,1,method=method),-mp.mpf(5)/2-mp.pi**2/6)
 for bad in [(0,0,0),(-1,2,3)]:
  try:sunset(*bad,method=method)
  except ValueError:pass
  else:raise AssertionError('INVALID_DOMAIN_ACCEPTED')
 try:sunset_xy(0,2,3)
 except ValueError:pass
 else:raise AssertionError('MASSLESS_DERIVATIVE_ACCEPTED')
 x=mp.mpf(2);eps=mp.mpf('1e-12');L=mp.log(x)
 # Verify the actual gamma convention before a physically weighted input exists.
 with mp.workdps(80):
  raw=x*mp.exp(eps*(mp.euler-mp.log(x)))*mp.gamma(eps-1)
  series=-x/eps+tadpole(x)+eps*tadpole_e(x)+eps*eps*tadpole_ee(x)
  assert abs(raw-series)<mp.mpf('1e-30')
 bare_prod=tadpole(1)**2-2*tadpole_e(1);near(bare_prod,3+mp.zeta(2));assert abs(bare_prod-tadpole(1)**2)>1
 hfixtures=[]
 for r,ss in [('0','.7'),('.25','.25'),('.2','.5'),('.4','.400000000000000000000000000001'),('.49','100')]:
  h0,h1=stable_h(mp.mpf(r),mp.mpf(ss));assert h0>0 and h1>0
  hfixtures.append([r,ss,mp.nstr(h0,40),mp.nstr(h1,40)])
 controls={}
 for xyz in [(1,1,1),(1,2,3),(1,2,16),(1,1,4),(0,2,3),(0,2,2),(0,0,2)]:
  val=sunset(*xyz,method=method);controls[','.join(map(str,xyz))]=mp.nstr(val,40)
  for perm in set(itertools.permutations(xyz)):near(sunset(*perm,method=method),val)
  near(sunset(*(mp.mpf(3)*v for v in xyz),q2=3,method=method),3*val)
 near(sunset(1,1,mp.mpf(4)+mp.mpf('1e-28'),method=method),sunset(1,1,4,method=method))
 # Physical sample selected independently from the authenticated ledger in each route.
 ledger=json.loads((R/'calculations/canonical_so10_gauge_matching/scalar_sm_ledger.json').read_bytes())
 sample=model_sample(ledger);masses=[mp.mpf(v[0]) for v in sample];iv=sunset(*masses,method=method)
 print('STAGE finite_I',time.perf_counter()-tick,flush=True)
 derivative_cases=[('equal',[mp.mpf(1)]*3),('triangle',list(map(mp.mpf,[1,2,3]))),('outside',list(map(mp.mpf,[1,2,16])))]
 derivative_cases.extend(('model_pair_'+str(k),[masses[i] for i in perm]) for k,perm in enumerate([(0,1,2),(0,2,1),(1,2,0)]))
 derivatives={}
 for label,(x,y,z) in derivative_cases:
  if role=='primary':value=mp.diff(lambda a,b:sunset(a,b,z,method='dilog'),(x,y),(1,1))
  else:value=sunset_xy(x,y,z)
  assert value>0;derivatives[label]=mp.nstr(value,40)
  if label=='equal':near(value,4*cl/(3*mp.sqrt(3)))
  print('STAGE derivative '+label,time.perf_counter()-tick,flush=True)
 # Q dependence of the declared finite master, not a fitted matching constant.
 if role=='primary':scale=mp.diff(lambda logq:sunset(*masses,q2=mp.exp(logq),method='dilog'),mp.mpf(0))
 else:scale=sum(tadpole(v)-v for v in masses)
 near(scale,sum(tadpole(v)-v for v in masses))
 # Retain the actual zero-mass descendant IR logarithm with its coefficient.
 with mp.workdps(80):
  x,y=mp.mpf(2),mp.mpf(3);d=mp.mpf('1e-30');i0=sunset(0,x,y,method=method);ax,ay=tadpole(x),tadpole(y)
  B=(ay-ax)/(x-y)
  C=(-(x+y)*i0-2*ax*ay+3*x*ax+3*y*ay-y*ax-x*ay-(x+y)**2)/(x-y)**2
  delta=(sunset(d,x,y,method=method)-i0)/d
  assert abs(delta-C-B*mp.log(d))<mp.mpf('1e-25') and B!=0
  ir={'log_coefficient':mp.nstr(B,40),'subtracted_difference_error':mp.nstr(delta-C-B*mp.log(d),8)}
 bare_poles={'double':mp.nstr(-sum(masses)/2,40),'single':mp.nstr(sum(tadpole(v) for v in masses)-sum(masses)/2,40),
  'finite_from_declared_conversion':mp.nstr(iv+sum(tadpole_e(v) for v in masses),40),'finite_subdivergence_shift':mp.nstr(sum(tadpole_e(v) for v in masses),40)}
 out={'schema':'VACUUM_MASTER_PILOT_NATIVE_V1','role':role,'finite_controls':controls,'model_sample':sample,'model_I':mp.nstr(iv,40),
  'mixed_derivatives':derivatives,'dI_dlogQ2':mp.nstr(scale,40),'model_bare_conversion':bare_poles,'IR_boundary':ir,
  'model_A':[mp.nstr(tadpole(v),40) for v in masses],'model_A_epsilon':[mp.nstr(tadpole_e(v),40) for v in masses],
  'model_A_epsilon2':[mp.nstr(tadpole_ee(v),40) for v in masses],'factorized_bare_finite_at_unit_mass':mp.nstr(bare_prod,40),
  'H_fixtures':hfixtures,
  'spectral_input_accuracy_not_promoted':True,'master_basis_gate_complete':False,'C1_GS_or_matching_vector_produced':False,
  'TSIL_executable_used':False,'authority_changed':False,'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main(sys.argv[1])
