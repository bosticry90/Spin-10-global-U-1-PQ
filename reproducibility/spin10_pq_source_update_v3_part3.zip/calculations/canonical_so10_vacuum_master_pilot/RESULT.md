# MVM1 — a vacuum-master input for the active gauge-scalar threshold work

Completed pilot and independent verification at base
5aa5466615074e951689c4915c525ae49fd6a7f3/main. Receipt
`validation_receipt_v2.json` SHA256
`6b4e2e25061911418654ba848a6690970d7393cb92c6750185a0039cbe768280`.
Scientific acceptance is NOT performed. Full master-basis and C1_GS gates
remain unqualified. No physical scheme, benchmark or authority changes.

## What this adds

The active physical two-loop threshold contract named an unimplemented
massive-vacuum integral layer. This pilot supplies executable finite MSbar
sunsets I(x,y,z), tadpoles through epsilon^2 and a separately evaluated,
UV-finite mixed mass derivative for positive masses. It includes a numerical
sample selected from the actual qualified scalar spectrum. This is an
integral input, not a two-loop matching vector, weighted graph or gauge refit.

No existing vacuum-master implementation was found in the repository. No
gcc/clang/cl/make/cmake executable was found on PATH. TSIL itself was not run
or integrated. The implemented formulas are established results, not claimed
novel physics: [Martin](https://arxiv.org/abs/hep-ph/0111209v2), equations2.19-2.31,
and the explicit finite/bare convention of
[Martin-Robertson](https://arxiv.org/abs/hep-ph/0501132v6), equations2.16-2.34.
No supersymmetric model assumption is imported from those papers.

## Convention and essential finite-subtraction distinction

Use the original C1_GS MSbar convention with normalized loop factor
16pi^2*mu^(2epsilon)/(2pi)^D and Q^2=4pi*exp(-gamma_E)*mu^2. All mass
arguments are SQUARED masses. The physical sample uses Q^2/omega^2=1.
No formal heat kappa, b0 or infrared normalization is identified with this
existing matching convention.

The renormalized I is NOT the bare epsilon^0 coefficient. In this convention,

    Jbar_0=I(x,y,z)+A_epsilon(x)+A_epsilon(y)+A_epsilon(z).

The finite terms from subdivergence counterterms must be retained. At the
model sample their sum is -3.053173780906360357975171813260044883432,
so simply discarding poles would produce a materially different master.
The displayed bare coefficients are reconstructed from the declared published
conversion, not independently measured by a new bare dimensional loop integral.

The factorized control has the same lesson: at x=y=Q^2=1, the bare finite
tadpole product is3+zeta(2), while the product with BOTH tadpole subtractions
is A(1)^2=1. The epsilon-positive tadpole terms matter. Gamma-function checks
validate A through epsilon^2 with the fixed scale convention.

## Distinct numerical routes and independent derivative

The primary uses principal-branch dilogarithms and high-precision mass
differentiation. Replay uses a triangle/Clausen angular integral when the
discriminant is negative and a logarithm-integral dilogarithm outside that
region. These finite-I routes share the published analytic expression and
subtraction normalization; they are not independent derivations of that result.

The mixed distinct-mass derivative has a separate convergent integral,

    I_xy=integral_simplex u*v/[ (uv+uw+vw)^2*(u*x+v*y+w*z) ].

Schwinger Gaussian integration derives it directly. Six ordered sectors and
an analytic inner integration reduce it to a positive one-dimensional
quadrature, with explicitly bounded series near coincident divided differences.
This does not differentiate the same dilogarithm routine. Independent
verification also evaluates the ORIGINAL two-dimensional simplex for the
nondegenerate1,2,3 control, without importing native helpers:

    I_xy(1,2,3)=0.47738562622110961383781786696281...

The equal-mass normalization is independently obtained from a positive
logarithm integral:

    I_xy(1,1,1)=4 Cl2(pi/3)/(3sqrt(3))
              =0.78130241289648629686718742962409235636513433654529...

Mixed derivatives are INSENSITIVE to additive functions f(x)+f(y)+f(z).
They therefore cannot validate the entire finite normalization alone. The
equal/zero-mass absolute formulas, Gamma and explicit bare/subdivision tests
remain separate conditions. This shared-normalization limitation is disclosed.

Controls include permutation and common mass/scale dependence, Q derivatives,
triangle and outside-triangle masses, the apparent zero discriminant at1,1,4
and its nearby limit, equal/zero masses, all three distinct pairs of the
physical sample, and explicit domain rejection. Values agree at the frozen
scaled1e-25 tolerance. Numerical working digits exceed physical spectral accuracy.

## Deterministic sample from the existing benchmark

The two routes independently recover the declared290 positive heavy real
directions and38 excluded zeros from the frozen SM ledger, respecting its
multiplicities. First/middle/last of the weighted positive list give:

| SM label (SU3 Dynkin; SU2 dimension; Y) | m^2/omega^2 |
| --- | --- |
| (0,0);1;0 |0.0014426926299895904|
| (0,2);1;-4/6 |0.20184463718884615|
| (0,1);1;-2/6 |1.2860473739515608|

At these decimal-encoded numerical inputs,

    I/omega^2=-4.937662673877480223612019919320922738018.

The three distinct pair derivatives, in the normalized inverse-omega^2 units,
are7.708958219839499384829605725914594730317,
4.344258512589843247001629882674372935674 and
1.703534010380381478622259563261480525958.

These are numerical kernel controls. No claim is made that these three
SM-labelled states have an allowed common vertex. No color factor, coupling,
symmetry factor, graph amplitude or comparison with the target matching vector
is inferred. Their mass inputs retain the earlier floating spectral accuracy;
40 output digits do not create40 accurate physical mass digits. The functions
are integral-evaluation inputs under the C1 contract, not elements of the
restricted E5 local counterterm complex.

## Infrared boundary is explicit

Finite I(0,x,y) does not mean a doubled zero-mass propagator is harmless.
For the delta,2,3 control, the derivative has the nonzero coefficient

    B=[A(3)-A(2)]/(2-3)
     =-0.90954250488443845535127146785122397779147140474774...

of log(delta/Q^2). The small-positive-mass expansion is checked at delta=1e-30
with80 working digits. This pilot refuses a differentiated massless boundary
and the unseparated all-zero scaleless case instead of returning an invented
finite value. That logarithm is not an obstruction to the GUT: the actual
hard-region/UV-minus-EFT calculation must determine its cancellations and
subtractions. That layer has not been constructed here.

## Failure, correction and resources

One primary failed at the tiny-mass boundary: subtractive root arguments lost
digits, giving error1.62019128e-22 against1e-25. A frozen diagnostic and exact
rationalization of (z+x-y-R)/(2z) to2x/(z+x-y+R) reduced it to-4.882866e-30
at the SAME80digits, mass, branch and tolerance. The original source, FAILED
capture and diagnostic remain. Both full routes reran. No verifier failed.
See ROOT_STABILITY_V2.md; no finite constant or mathematical condition changed.

46 initial/72 V2/77 final independent bindings. Successful routes took
0.625466/9.758114seconds after imports; verifier4.492588seconds, including
independent35-digit simplex integration. Other native work uses50digits,
boundary/verifier80digits. Fixed120/180seconds,8GiB sampled private allocation,
350MiB launch floor and4MiB package caps remain. Largest successful native
private sample13504512 bytes is NOT a true peak; the subsecond primary sample
can miss most Python runtime allocation and must not be sold as a peak bound.

The work demonstrates a useful physical-input implementation and a stable
method correction. It does not independently validate the shared physical
action, classical benchmark, published subtraction convention or AI scientific
interpretation. There is no independent human, experimental, Lean or TSIL
runtime validation. Extra precision and agreement are implementation evidence.

## Unchanged gates and next question

The original master-basis contract still requires the actual epsilon orders
needed by reduction and all necessary massless descendants with UV/IR
separation. This pilot is not a full master-basis PASS. The finite C1_GS gate
also requires complete physical vertices/eigenstates, actual background-gauge
diagrams/symmetry factors, one-loop field/mass/gauge/VEV/tadpole counterterms,
tensor reduction and common UV-minus-SM-EFT subtraction. None is replaced
by this sunset value. See NEXT_RESEARCH_QUESTION.md.

No finite C1 vector, target alignment, gauge refit, benchmark replacement,
physical gauge independence, BFB or missing-Yukawa control is claimed.
All old evidence/action/state/partialGamma/source/point/policy/scheme/branch/
remote/publication data remain unchanged. State113/34of39/sevenfalse,
E5/A5unqualified,HB1/C5blocked,C1_GSuncalculated,flavorhumanpaused,
quartetFAIL3960/648,custodyexit2/seven. Physical scalar and matching warnings
remain distinct. Goal active and incomplete; scientific acceptance not performed.
