# MVM1 — positive-mass vacuum-master pilot for the active C1_GS seam

Prospective contract, base5aa5466615074e951689c4915c525ae49fd6a7f3/main.
LAC1 completed; fresh preflight clean/no matching workers,452 bindings only.
Active seam C1_GS; its finite-amplitude gate remains scientifically BLOCKED.
Question: can a declared-convention vacuum sunset input and its UV-finite
mixed mass derivative be evaluated independently on the actual nondegenerate
scalar spectrum? This supplies a missing input, not the threshold amplitude.

Reuse original direct gauge/scalar RECORD and MASTER_BASIS_CONTRACT, unchanged
positive-Higgs POINT, qualified scalar SM mass ledger/matrix trace and one-loop
MSbar convention. Squared masses are ratios to omega^2; Q^2/omega^2=1 for
the physical numerical sample. No new g10/omega or benchmark is adopted.
No formal heat-kappa/b0/IR baseline is identified with this existing MSbar scheme.
No TSIL executable or C compiler was found; use published equations with
independent convergent quadrature, not a claim of running or integrating TSIL.

Freeze Euclidean C=(16pi^2)mu^(2epsilon)/(2pi)^D, D=4-2epsilon,
Q^2=4pi exp(-gamma_E)mu^2. A(x)=x(log(x/Q^2)-1). I is the subdivergence-
subtracted Martin/TSIL sunset, NOT the epsilon^0 term of the bare integral.
Implement A through epsilon^2, A products, finite positive-mass I, explicit
I(0,x,y)/I(0,x,x)/I(0,0,x) limits, and the UV-finite mixed distinct-mass
derivative I_xy for strictly positive masses. Reject negative masses,
unseparated all-zero scaleless cases and massless differentiated boundaries;
record the nonzero IR logarithm rather than silently output zero.

Primary: published principal-branch dilogarithm expression and high-precision
mass differentiation. Replay: Clausen angular integrals in the triangle regime,
logarithm-integral dilogarithms outside it, plus an INDEPENDENT positive
Schwinger/Feynman one-dimensional integral for I_xy. Finite I implementations
share the published analytic normalization; derivative quadrature does not fix
additive one-variable contact terms. Check these with the declared bare/subdiv
conversion, Gamma tadpole expansion, equal-mass normalization and factorized
subtraction. Disclose that shared-normalization limit explicitly.

Model sample: recover all290 positive heavy real directions and38 excluded
zeros from the FROZEN ledger with its stated zero multiplicities. Select the
lightest, middle and heaviest positive entries of the weighted ordered list;
use their exact decimal encodings as numerical inputs. This is a kernel sample,
not an assertion those three eigenstates share a nonzero physical vertex.
Input spectral accuracy remains the existing floating-point certificate;
extra quadrature digits do not create extra physical mass accuracy.

Controls before model work: I(1,1,1),I(1,2,3),I(1,2,16), apparent discriminant
zero I(1,1,4) and nearby values; permutation, common scale and Q dependence;
equal and zero mass formulas; A Gamma expansion and factorized bare-vs-
renormalized products; I_xy at equal masses and all three distinct pairs for
the model sample. Wrong subtraction finite pieces and missing sector/Jacobian
must fail. I_xy is insensitive to sums of one-variable functions, explicitly
test that limitation. No arbitrary finite vector can be inferred from RG logs.

Numerics: primary/replay50digits (80 for the small-mass boundary diagnostic),
80digit verifier (35 for the independent two-dimensional quadrature),
agreement1e-25 scaled by
1+|value|; kernel quadrature positive and stable divided differences with
explicit convergent-series tail bounds. Native120s/verifier180s after imports,
8GiB sampled private NOT true peak,350MiB launch floor,4MiB new package.
No silent tolerance relaxation, domain truncation, resource expansion or cache
of expected values before calculation. Freeze proof/code/input/controller bytes
before execution; preserve failures exactly. Verifier imports no native helper.

Success is a qualified PILOT for these specified master functions, controls
and sample. Full MASTER_BASIS and C1_GS remain unqualified until their actual
epsilon orders, massless UV/IR descendants, reduction/diagram/counterterm and
UV-minus-EFT subtraction obligations are satisfied. No finite C1 vector,
alignment/refit, full master PASS, physical promotion or missing-Yukawa bound.
Possible outcomes also include exact discrepancy, underdefinition or exhaustion.

No old evidence/action/state/point/partialGamma/source/policy/scheme/branch/
remote/publication change. State113/34of39/sevenfalse,E5/A5unqualified,
HB1/C5blocked,flavorhumanpaused,quartetFAIL3960/648,custodyexit2/seven.
Scalar140%/1.94%/20.27%,matching0.745476 andYukawa limitations unchanged.
