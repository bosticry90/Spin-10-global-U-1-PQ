# Next — connect masters to an actual amplitude and its counterterms

MVM1 provides a convention-explicit finite vacuum-master PILOT and independent
UV-finite derivative controls. Do not call the full original MASTER_BASIS or
C1_GS gate passed. Do not fill a grid of unrelated mass triples to increase
calculation counts. No actual graph or matching vector has been produced.

The next smallest dependency question is which model-specific gauge-scalar
background two-point diagrams and counterterms are actually required at the
frozen positive-Higgs point. Reconcile the existing on-demand scalar vertex
oracle, full Hessian/physical action, SM multiplet spectra, background-field
gauge convention and prior C1 readiness list. Avoid a gigantic328^4 vertex
expansion. Establish a complete topology/symmetry-factor and counterterm
inventory before choosing one amplitude subfamily.

Mass/VEV/tadpole normalization matters at this order. Determine what the
ORIGINAL MSbar matching contract specifies, what is inherited and what
remains genuinely undefined; do not silently adopt pole masses, a favorable
finite tadpole scheme or new renormalization conditions. A structural relation
expressing a mass-insertion subfamily through derivatives of the measured
one-loop background kernel may reduce work, but all its tadpole, mass,
seagull and counterterm companions must be included before a physical claim.

Only that actual reduction determines the needed positive epsilon orders,
massless derivatives and UV/EFT separation. Use the nonzero small-mass IR
log as a sensitive control. Do not set a scaleless descendant to zero or
treat its singularity alone as a model obstruction. MVM1's mixed derivative
is blind to one-variable finite terms, so its separate normalization tests
cannot be removed. No TSIL executable has been run.

The existing C1_GS scope is pure gauge/scalar. Even a complete result would
not supply all Yukawa-vertex-independent mixed gauge/fermion terms or the
missing Yukawa-dependent uncertainty. Keep human-paused flavor paused.
Preserve the scalar140%/1.94%/20.27% diagnostics, failed uniform weakening,
matching0.745476 and all lower-order passes. Never fit missing constants to
the preregistered target. No activation of HB1/C5, authority promotion or
physical scheme/benchmark change follows from this input work.
