"""Independent vacuum-master checks, including original simplex quadrature."""
from pathlib import Path
from hashlib import sha256
import json,time,threading,os
import mpmath as mp
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
def main():
 tick=time.perf_counter();timer=threading.Timer(180,lambda:os._exit(124));timer.daemon=True;timer.start()
 prep=json.loads((O/'validation_preparation_v2.json').read_bytes())
 for n,h in prep['input_sha256'].items():assert sha256(Path(n).read_bytes()).hexdigest()==h,n
 a,b=[json.loads((O/(r+'_v2_result.json')).read_bytes()) for r in ['primary','replay']]
 mp.mp.dps=80;tol=mp.mpf('1e-25')
 def near(x,y):
  x,y=mp.mpf(x),mp.mpf(y);assert abs(x-y)<tol*(1+abs(x)+abs(y)),(x,y)
 # Explicit normalization before relying on any model sample.
 cl=-mp.quad(lambda t:mp.log(2*mp.sin(t/2)) if t else 0,[0,mp.pi/3])
 ieq=-mp.mpf(15)/2+2*mp.sqrt(3)*cl
 jeq=mp.quad(lambda t:-mp.log(t*(1-t))/(3*(1-t*(1-t))) if 0<t<1 else 0,[0,mp.mpf('.5'),1])
 near(jeq,4*cl/(3*mp.sqrt(3)));assert jeq>0
 for out in [a,b]:
  near(out['finite_controls']['1,1,1'],ieq);near(out['mixed_derivatives']['equal'],jeq)
  near(out['finite_controls']['0,2,2'],2*(-mp.log(2)**2+4*mp.log(2)-5))
  near(out['finite_controls']['0,0,2'],2*(-mp.log(2)**2/2+2*mp.log(2)-mp.mpf(5)/2-mp.pi**2/6))
  near(out['factorized_bare_finite_at_unit_mass'],3+mp.zeta(2))
 for key in ['finite_controls','mixed_derivatives','model_bare_conversion']:
  assert set(a[key])==set(b[key])
  for label in a[key]:near(a[key][label],b[key][label])
 for key in ['model_I','dI_dlogQ2']:near(a[key],b[key])
 assert a['model_sample']==b['model_sample']
 for key in ['model_A','model_A_epsilon','model_A_epsilon2']:
  for x,y in zip(a[key],b[key]):near(x,y)
 # Direct integration of each rational inner kernel; no native stable-H code.
 for out in [a,b]:
  for rr,ss,h0,h1 in out['H_fixtures']:
   r,ss=mp.mpf(rr),mp.mpf(ss)
   direct0=mp.quad(lambda u:1/((1+r*u)**2*(1+ss*u)),[0,1])
   direct1=mp.quad(lambda u:u/((1+r*u)**2*(1+ss*u)),[0,1])
   near(h0,direct0);near(h1,direct1)
 # Original simplex uv/U^2/M in independent coordinates, one well-conditioned
 # nondegenerate control.35digits were fixed before computation.
 with mp.workdps(35):
  def outer(u):
   def inner(t):
    den=u+(1-u)*t*(1-t);mass=u+(1-u)*(2*t+3*(1-t))
    return u*t/(den*den*mass) if den else mp.mpf(0)
   return mp.quad(inner,[0,mp.mpf('.5'),1])
  independent=mp.quad(outer,[0,mp.mpf('.5'),1])
 near(independent,a['mixed_derivatives']['triangle']);near(independent,b['mixed_derivatives']['triangle'])
 print('STAGE independent_simplex',time.perf_counter()-tick,flush=True)
 # Independent inventory/sample and original point identity.
 ledger=json.loads((R/'calculations/canonical_so10_gauge_matching/scalar_sm_ledger.json').read_bytes())
 point=R/'calculations/canonical_so10_positive_higgs/POINT.json'
 assert ledger['point_sha256']==sha256(point.read_bytes()).hexdigest()
 values=[];zeros=0
 for row in ledger['blocks']:
  masses=sorted(row['mass_squared_over_omega_squared'],key=abs);nz=row['zero_multiplicity'];dim=row['real_dimension_per_eigenvalue']
  assert max([abs(x) for x in masses[:nz]]+[0])<1e-9;zeros+=nz*dim
  values.extend((str(x),row['sm_irrep']) for x in masses[nz:] for _ in range(dim))
 values.sort(key=lambda x:mp.mpf(x[0]));assert len(values)==290 and zeros==38
 expected=[list(values[i]) for i in [0,145,289]];assert expected==a['model_sample']
 masses=[mp.mpf(x[0]) for x in expected];assert len(set(masses))==3
 A=lambda x:x*(mp.log(x)-1)
 AE=lambda x:x*(-mp.mpf(1)/2*(mp.log(x)-1)**2-mp.mpf(1)/2-mp.zeta(2)/2)
 for i,x in enumerate(masses):near(a['model_A'][i],A(x));near(a['model_A_epsilon'][i],AE(x));assert AE(x)<0
 near(a['dI_dlogQ2'],sum(A(x)-x for x in masses))
 bare=a['model_bare_conversion'];near(bare['double'],-sum(masses)/2);near(bare['single'],sum(A(x) for x in masses)-sum(masses)/2)
 near(bare['finite_from_declared_conversion'],mp.mpf(a['model_I'])+sum(AE(x) for x in masses))
 assert abs(mp.mpf(bare['finite_subdivergence_shift']))>0
 # The mixed derivative would miss this one-variable finite subtraction error;
 # the explicit normalization checks above must therefore remain separate.
 assert AE(masses[0])+AE(masses[1])+AE(masses[2])!=0
 eps=mp.mpf('1e-12');x=mp.mpf(2);L=mp.log(x)
 aa=x*(L-1);ae=x*(-1-mp.zeta(2)/2+L-L*L/2)
 aee=x*(-1-mp.zeta(2)/2+mp.zeta(3)/3+(1+mp.zeta(2)/2)*L-L*L/2+L**3/6)
 original=x*mp.exp(eps*(mp.euler-L))*mp.gamma(eps-1)
 assert abs(original-(-x/eps+aa+eps*ae+eps**2*aee))<mp.mpf('1e-30')
 B=(A(mp.mpf(3))-A(mp.mpf(2)))/(2-3);assert B!=0
 for out in [a,b]:
  near(out['IR_boundary']['log_coefficient'],B)
  assert abs(mp.mpf(out['IR_boundary']['subtracted_difference_error']))<mp.mpf('1e-25')
  assert not out['master_basis_gate_complete'] and not out['C1_GS_or_matching_vector_produced'] and not out['TSIL_executable_used'] and not out['authority_changed']
 performance={}
 for role in ['primary','replay']:
  cap=json.loads((O/(role+'_v2_capture.json')).read_bytes());out=json.loads((O/(role+'_v2_result.json')).read_bytes())
  assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and out['elapsed_after_imports']<120
  assert cap['launch']['memory']['available_pagefile']>=350*1024**2
  sample=max(s['private_bytes'] for s in cap['all_resource_samples']);assert sample<8*1024**3
  performance[role]={'seconds':out['elapsed_after_imports'],'max_sampled_private_bytes':sample}
 out={'schema':'VACUUM_MASTER_PILOT_VALIDATION_V1','execution_state':'COMPLETED','scientific_acceptance':'NOT_PERFORMED',
  'scientific_disposition':'MSBAR_FINITE_SUNSET_PILOT_WITH_INDEPENDENT_CONVERGENT_DERIVATIVE_AND_MODEL_MASS_SAMPLE',
  'input_sha256':prep['input_sha256'],'performance':performance,'model_sample':a['model_sample'],'model_I':a['model_I'],
  'independent_simplex_derivative':mp.nstr(independent,32),'equal_mass_derivative':mp.nstr(jeq,50),
  'finite_subdivision_shift':bare['finite_subdivergence_shift'],'massless_IR_log_coefficient':mp.nstr(B,50),
  'shared_published_finite_normalization_disclosed':True,'extra_numerical_digits_not_physical_accuracy':True,
  'higher_epsilon_and_all_massless_descendants_complete':False,'full_master_basis_or_C1_GS_gate_pass':False,
  'finite_matching_vector_or_refit':False,'authority_changed':False,'native_failures':1,'verifier_failures':0,
  'shared_input_data_software_and_AI_author':True,'elapsed_after_imports':time.perf_counter()-tick}
 print('RESULT '+json.dumps(out,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
