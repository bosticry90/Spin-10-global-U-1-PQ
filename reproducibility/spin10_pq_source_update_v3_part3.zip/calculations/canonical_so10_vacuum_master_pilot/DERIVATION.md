# MVM1 — convention and an independent convergent sunset derivative

Prospective until complete native routes and separate verification. This is
an input to the existing physical two-loop program, not a two-loop matching
amplitude or a replacement for its unearned diagram/subtraction layers.

## 1. Fixed subtraction and numerical implementation

Use the original C1_GS MSbar master convention. With D=4-2e and
Q^2=4pi exp(-gamma_E)mu^2, put L_x=log(x/Q^2). The normalized tadpole is

 Abar(e,x)=x exp[e*(gamma_E-L_x)] Gamma(e-1),
 Abar=-x/e+A(x)+e A_e(x)+e^2 A_ee(x)+O(e^3),
 A=x(L_x-1),
 A_e=x[-1-zeta(2)/2+L_x-L_x^2/2],
 A_ee=x[-1-zeta(2)/2+zeta(3)/3+(1+zeta(2)/2)L_x-L_x^2/2+L_x^3/6].

For the normalized Euclidean sunset Jbar, subtract
(Abar(x)+Abar(y)+Abar(z))/e and (x+y+z)*(1/(2e^2)-1/(2e)). Hence

 Jbar=-(x+y+z)/(2e^2)+[A(x)+A(y)+A(z)-(x+y+z)/2]/e
           +I(x,y,z)+A_e(x)+A_e(y)+A_e(z)+O(e).

The bare finite coefficient is NOT I. Nor is the bare finite product of two
tadpoles A(x)A(y): it also contains -x A_e(y)-y A_e(x). Renormalizing both
factors before multiplying removes those correlated subdivergence pieces.
This convention is explicitly the one in Martin-Robertson,
https://arxiv.org/abs/hep-ph/0501132v6 , equations2.16-2.34. It is not a
choice of the separate formal heat/contact kappa or b0.

The finite I expression is implemented from Martin,
https://arxiv.org/abs/hep-ph/0111209v2 , equations2.19-2.31. It uses the
principal logarithm/dilogarithm and root of
lambda=x^2+y^2+z^2-2xy-2xz-2yz with argument0 orpi/2, with the largest mass
in the third slot. No SUSY assumption from the paper is adopted; the scalar
vacuum integral is a general mathematical input. Published equal/zero mass
formulas and scale identities fix/control the stated finite normalization.

For negative lambda, a separate expression uses triangle angles of sides
sqrt(x),sqrt(y),sqrt(z): xi=-2sqrt(-lambda)*sum Cl2(2alpha_i),
Cl2(theta)=-integral_0^theta log[2sin(t/2)]dt. For positive lambda, integrate
the defining dilogarithm along its non-cut path instead of calling polylog.
These finite-I routes share the established closed-form master and its
normalization. Their agreement tests implementation/branch errors, not an
independent derivation of that published result.

## 2. Independent two-mass derivative has no UV subtraction ambiguity

Differentiate once in x and once in y. In momentum space both propagators
are squared and the signs multiply to plus. For positive masses the integral
is UV/IR convergent; all single-mass subtractions in section1 differentiate
to zero. Schwinger Gaussian integration gives, with the same normalized
measure,

 I_xy = integral_(u+v+w=1,u,v,w>=0) u v/[U^2 M],
 U=uv+uw+vw, M=ux+vy+wz.

The integrand is positive. This directly tests both mass derivatives, not a
finite difference of the same dilogarithm code. It is insensitive to an
additive f(x)+f(y)+f(z); therefore section1's absolute controls stay necessary.

Divide the simplex into its three largest-coordinate sectors. In one sector
write the largest coordinate1/(1+a+b), the others a/(1+a+b),b/(1+a+b).
The Jacobian is (1+a+b)^-3. Split the square into b=a*t and its reverse,
a,t in[0,1]. All factors1+a+b cancel. For the ordered sector with dominant
mass X and other masses Y,Z, d=1+t and c=Y+Zt:

 if the dominant line is doubled and Y is doubled: numerator1;
 if the dominant line is doubled and Z is doubled: numeratort;
 if only the two smaller-coordinate lines are doubled: numeratora*t.

Each sector is the integral of that numerator divided by
(d+a*t)^2*(X+a*c). There are exactly six ordered sectors. Omitting sectors
or this Jacobian changes the normalization; no graph symmetry factor is
inserted into the MASTER itself.

The a integral is analytic. Put r=t/(1+t), s=c/X and
F=[log(1+r)-log(1+s)]/(r-s). Then

 H1=integral_0^1 a/[(1+ra)^2(1+sa)]da
    =[log((1+r)/(1+s))-(r-s)/(1+r)]/(r-s)^2,
 H0=integral_0^1 1/[(1+ra)^2(1+sa)]da=F-r H1.

Multiply by1/(d^2 X) and the appropriate t factor. The remaining t integral
is positive, one-dimensional and independent of the dilogarithm formula.

For close r,s avoid cancellation. Let v=1/(1+s),q=(r-s)/(1+s),b=s/(1+s).
Use convergent expansions

 H1=v^2 sum_(n>=0) (-q)^n (n+1)/(n+2),
 H0=v   sum_(n>=0) (-q)^n [1-b*(n+1)/(n+2)].

For |q|<1/4, absolute tails after n are bounded respectively by
v^2 |q|^(n+1)/(1-|q|) and v |q|^(n+1)/(1-|q|). No silent order truncation
is used. At r=s these give H1=1/[2(1+s)^2] and H0=(s+2)/[2(1+s)^2].

## 3. Independent normalization and boundary controls

At x=y=z=M the symmetric sum of the three mixed derivative integrands is
1/(M U). Integrating one simplex coordinate gives

 I_xy(M,M,M)=(1/(3M)) integral_0^1 -log[t(1-t)]/[1-t(1-t)]dt
            =4 Cl2(pi/3)/(3sqrt(3)M).

The last equality follows by partial fractions of t^2-t+1 and the defining
logarithm integral, independently of the sunset expression. Together with
the published I(M,M,M)=M[-3L^2/2+6L-15/2+2sqrt(3)Cl2(pi/3)], this is a
sensitive absolute/derivative/sector comparison. Scale checks use
I(tx,ty,tz;tQ^2)=tI(x,y,z;Q^2), I_xy(tx,ty,tz)=I_xy(x,y,z)/t and
dI/dlog(Q^2)=A(x)+A(y)+A(z)-(x+y+z).

Finite I(0,x,y),I(0,x,x),I(0,0,x) do not imply every differentiated zero-mass
integral is finite. In particular, for positive unequal x,y,

 I(delta,x,y)=I(0,x,y)+delta*(C+B log(delta/Q^2))+higher terms,
 B=[A(y)-A(x)]/(x-y).

It is generically nonzero (use x=2,y=3,Q^2=1). The derivative at delta=0
has a logarithmic infrared singularity. Returning zero by a scaleless rule
would erase it. The pilot refuses such differentiated boundaries and the
unseparated all-zero case; full hard-region UV/IR subtraction remains to be
constructed. It does not claim this necessary original master-basis clause
has been satisfied for every zero-mass descendant.

## 4. Actual model inputs and claim ceiling

Recover the qualified290 positive heavy real scalar directions and38 zeros
from the immutable SM ledger and its multiplicities. The first/middle/last
positive weighted squared masses form a deterministic nondegenerate sample
in omega^2 units, without introducing a new point. Decimal encodings of
floating spectra are exact numerical routine inputs, not exact physical
spectral certificates. No vertex/coupling weight or allowed graph is inferred
from choosing those three masses.

The original MASTER_BASIS_CONTRACT still needs whatever further epsilon
orders its eventual reduction requires, all needed massless descendants and
UV/IR separation. The C1_GS calculation additionally needs its model diagrams,
counterterms, tensor reduction and UV-minus-SM-EFT subtraction. This pilot
produces none of the matching vector, gauge cancellation, finite refit or
Yukawa-dependent uncertainty. No full master PASS or physics authority changes.
