"""Published MSbar vacuum master with an independent convergent derivative.

Martin hep-ph/0111209v2 eq2.19-2.31; Martin-Robertson hep-ph/0501132v6.
Positive real squared masses; no tensor reduction or physical matching claim.
"""
import itertools
import mpmath as mp

def tadpole(x,q2=1):
 x=mp.mpf(x);q2=mp.mpf(q2)
 if x<0 or q2<=0:raise ValueError('MASS_OR_SCALE_DOMAIN')
 if not x:return mp.mpf(0)
 return x*(mp.log(x/q2)-1)

def tadpole_e(x,q2=1):
 x=mp.mpf(x)
 if x<=0 or mp.mpf(q2)<=0:raise ValueError('POSITIVE_MASS_REQUIRED_FOR_EPSILON_SERIES')
 L=mp.log(x/mp.mpf(q2));return x*(-1-mp.zeta(2)/2+L-L*L/2)

def tadpole_ee(x,q2=1):
 x=mp.mpf(x)
 if x<=0 or mp.mpf(q2)<=0:raise ValueError('POSITIVE_MASS_REQUIRED_FOR_EPSILON_SERIES')
 L=mp.log(x/mp.mpf(q2))
 return x*(-1-mp.zeta(2)/2+mp.zeta(3)/3+(1+mp.zeta(2)/2)*L-L*L/2+L**3/6)

def clausen(theta):
 theta=mp.mpf(theta)
 return -mp.quad(lambda t:mp.log(2*mp.sin(t/2)) if t else mp.mpf(0),[0,theta])

def li2_integral(z):
 return -mp.quad(lambda t:mp.log1p(-z*t)/t if t else -z,[0,1])

def sunset(x,y,z,q2=1,method='dilog'):
 x,y,z=sorted(map(mp.mpf,[x,y,z]));q2=mp.mpf(q2)
 if x<0 or q2<=0:raise ValueError('MASS_OR_SCALE_DOMAIN')
 if z==0:raise ValueError('UNSEPARATED_SCALELESS_UV_IR')
 L=lambda a:mp.log(a/q2)
 if x==0:
  if y==0:return z*(-L(z)**2/2+2*L(z)-mp.mpf(5)/2-mp.pi**2/6)
  if y==z:return y*(-L(y)**2+4*L(y)-5)
  a,b=z,y;li=mp.polylog(2,b/a) if method=='dilog' else li2_integral(b/a)
  return (a-b)*(li-mp.log(a/b)*L(a-b)+L(a)**2/2-mp.pi**2/6)-mp.mpf(5)*(a+b)/2+2*a*L(a)+2*b*L(b)-a*L(a)*L(b)
 lam=x*x+y*y+z*z-2*x*y-2*x*z-2*y*z
 if lam==0:xi=mp.mpf(0)
 elif lam<0 and method=='angular':
  angles=[]
  for a,b,c in [(x,y,z),(y,z,x),(z,x,y)]:
   co=(b+c-a)/(2*mp.sqrt(b*c));assert -1<=co<=1;angles.append(mp.acos(co))
  xi=-2*mp.sqrt(-lam)*sum(clausen(2*a) for a in angles)
 else:
  root=mp.sqrt(lam);a=(z+x-y-root)/(2*z);b=(z+y-x-root)/(2*z)
  li=mp.polylog if method=='dilog' else None
  da=li(2,a) if li else li2_integral(a);db=li(2,b) if li else li2_integral(b)
  xi=root*(2*mp.log(a)*mp.log(b)-mp.log(x/z)*mp.log(y/z)-2*da-2*db+mp.pi**2/3)
 value=((x-y-z)*L(y)*L(z)+(y-x-z)*L(x)*L(z)+(z-x-y)*L(x)*L(y))/2+2*(x*L(x)+y*L(y)+z*L(z))-mp.mpf(5)*(x+y+z)/2-xi/2
 assert abs(mp.im(value))<mp.mpf('1e-35')*(1+abs(mp.re(value))),'EUCLIDEAN_BRANCH_NOT_REAL'
 return mp.re(value)

def stable_h(r,s):
 """H0,H1 and explicit near-coincidence geometric tail bound."""
 r,s=mp.mpf(r),mp.mpf(s);v=1/(1+s);q=(r-s)*v
 if abs(q)<mp.mpf('.25'):
  b=s*v;power=mp.mpf(1);h0=mp.mpf(0);h1=mp.mpf(0);n=0;tol=mp.power(10,-mp.mp.dps-8)
  while True:
   h0+=power*(1-b*mp.mpf(n+1)/(n+2));h1+=power*mp.mpf(n+1)/(n+2)
   tail=abs(q)**(n+1)/(1-abs(q))
   if tail<tol:break
   n+=1
   if n>10000:raise ArithmeticError('SERIES_RESOURCE_NOT_CONVERGED')
   power*=-q
  return v*h0,v*v*h1
 delta=r-s;log=mp.log1p(q);F=log/delta
 h1=(log-delta/(1+r))/(delta*delta);h0=F-r*h1
 return h0,h1

def sunset_xy(x,y,z):
 masses=list(map(mp.mpf,[x,y,z]))
 if any(v<=0 for v in masses):raise ValueError('IR_BOUNDARY_NOT_INCLUDED')
 total=mp.mpf(0)
 for i,j,k in itertools.permutations(range(3)):
  X,Y,Z=masses[i],masses[j],masses[k]
  def kernel(t):
   d=1+t;h0,h1=stable_h(t/d,(Y+Z*t)/X)
   if i==2:return t*h1/(d*d*X)
   if j==2:return t*h0/(d*d*X)
   return h0/(d*d*X)
  value=mp.quad(kernel,[0,mp.mpf('.5'),1]);assert value>0;total+=value
 return total

def model_sample(ledger):
 heavy=[];zero_real=0;labels=[]
 for row in ledger['blocks']:
  values=sorted(row['mass_squared_over_omega_squared'],key=abs);nz=int(row['zero_multiplicity']);dim=int(row['real_dimension_per_eigenvalue'])
  assert max([abs(v) for v in values[:nz]]+[0])<1e-9
  zero_real+=nz*dim
  for v in values[nz:]:
   assert v>0
   heavy.extend([str(v)]*dim);labels.extend([row['sm_irrep']]*dim)
 assert len(heavy)==ledger['heavy_real_dimension']==290 and zero_real==ledger['zero_real_dimension']==38
 ordered=sorted(zip(heavy,labels),key=lambda v:mp.mpf(v[0]));chosen=[ordered[i] for i in [0,len(ordered)//2,len(ordered)-1]]
 assert len(set(v[0] for v in chosen))==3
 return chosen
