# V2 — rationalized arguments with the same branch and IR condition

The first primary FAILED the tiny-positive-mass boundary check. At80digits
and delta=1e-30, its error was1.62019128e-22, exceeding the fixed1e-25
condition. The isolated frozen diagnostic identifies cancellation in
(z+x-y-R)/(2z), whose numerator is of order delta. Its logarithm lost precision.

Using the exact identity (z+x-y)^2-R^2=4xz, replace that argument by
2x/(z+x-y+R), and similarly for y. The root, principal branches, mass inputs,
expected IR expansion and precision/tolerance remain unchanged. The diagnostic
error becomes-4.882866e-30 without increasing precision. This is a stable
evaluation of the SAME published equation, not a new finite normalization.

Keep the original source/capture and the full diagnostic/candidate sources.
Both native routes rerun with the rationalized expression and original scope;
the independent Schwinger derivative and simplex checks do not use this repair.
One native failure is retained; no verifier has yet executed.
