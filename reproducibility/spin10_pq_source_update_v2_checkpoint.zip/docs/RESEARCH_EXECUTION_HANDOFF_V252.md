# Research handoff V252 - weighted reference symbol verified

Base f3b3dbc8d6cb39767b5cc5ce29f2c8f7287a9ed3. Live AGENTS authoritative.
Previous goal turn was PROGRESS; this increment verifies a real UV-locality
prerequisite and locates the actual remaining operator-definition boundary.
Read canonical_so10_ub12_reference_symbol RECORD, DERIVATION, RESULT, failed V1,
corrected V2 sources/preparations/captures/results and validation_receipt.

All643 actual weights checked:598 weight1,45 weight0 auxiliaries. All1597 K and
1550 G entries obey the correct weighted degrees including reference masses.
Both constant frame maps preserve weights. All45 physical mixed principal
blocks reconstructed from raw matrices, determinants -(p^2)^4 independent of
widths. All45 ghost orientations and328 scalar leading inverses retain signs.
Wick p0=i q0 gives p^2=-|q|^2, nonzero Euclidean principal inverse with no inverse
width,g or reference mass. Independent sparse principal KG and GK cover every
643x643 entry including implicit zeros. This is weighted invertibility, NOT a
positive whole mixed Laplacian or a physical IR/contour theorem.

Sensitive controls:remove mixed blocks -> singular Maxwell symbol;uniform
order2 -> actual mixed inverse scaling fails. Actual H adjoint curvature gives
nonzero [Delta,D]. Two local covariant orderings may agree flat and differ at
symbol order-4. This does NOT prove nonlocality. A matrix-potential inverse
recursion was tested through relative4 on both sides as a finite-jet control.

The bound frozen retained-reference artifact contains flat matrices and a
prose covariantization instruction,not a structured ordered background symbol.
No repository-wide absence claim. The local-parametrix sufficiency theorem
requires an actual local differential/finite-jet coefficient class;principal
invertibility alone does not prove membership. V251 stays conditional. No new
background coefficient or heat/IR/QAP theorem measured or silently imported.
Lesch primary-paper reference in DERIVATION is an applicability guide only.

V1 native timed out120sec(exit124),preserved FAILED. V2 exact shared-block cache
and polynomial-domain determinants preserve all checks. Corrected native runs
12.328/15.019sec,independent18.762sec,all sampled private<193MB,within120sec/8GiB.
One native failure,no independent verifier failure. An unfrozen preparation
syntax error before writes/workers is also documented. ReceiptSHA
 a1d0ae0b83d556c6103cdfc587af8411fd605407aed47d4e3ec67097dc798f14.
Shared action/reference/charts/software/AI author;no expert or fresh identical
replay-pair claim. No protected input/source/function/authority changes.

NEXT smallest competent action: construct an explicit ordered LOCAL covariant
reference witness (or prove a universal statement for a precise local class)
consistent with the frozen flat inverse and heat family. Natural candidate is
the Hessian of a local background-covariant quadratic form on fluctuations:
Maxwell(dbar hB),mixed hLambda dbar.hB,constant widths,ghost dbar^2,scalar kinetic
and existing reference masses. Derive ordering and graded transpose from that
quadratic form,not a convenient p->D guess. Test actual H carrier/metric
compatibility and all flat entries before using a weighted parametrix. Treat
it as an exploratory construction within the specified family;it is NOT an
adopted physical renormalization scheme or a full quantum construction. Do not
select curvature terms to fit the known insertion. If the existing definition
does not identify a unique member,retain universal-vs-chosen distinction.
This is ordinary delegated research;no routine approval request is needed.

Keep the whole goal active. Known functional155110/hash
ce8dbca159eefb2e477ea56973bd180383db5b35c8dbe4d42167b9f5d7018bc1;
sourcefree40309/hashad385556b964a8a3d32511d578ba6e2ad20209a148f2c835c29599bcacbc6c7a.
Preserve source38/unbroken proofs,generic156matched/2197unreconciled profiles,
regulated breaking/source/heat terms,seven false quantum flags,Jacobian and32
products,128sourcejets,508physicalprograms,historical quartet and scalar quantum
warnings. Full source-free Slavnov,QAP,measure,IR,contacts,E5/A5 and physical GUT
viability remain unqualified;authority34/39. HB1/C5 blocked,flavor paused,C1_GS
uncalculated,closed routes and custody exit2/seven retained. No remote action.
