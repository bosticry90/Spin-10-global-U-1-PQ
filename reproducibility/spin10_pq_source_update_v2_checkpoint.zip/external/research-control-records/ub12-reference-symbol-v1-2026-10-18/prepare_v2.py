from pathlib import Path
from hashlib import sha256
import ast,json
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_ub12_reference_symbol';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
old=read(OUT/'preparation.json');assert not (OUT/'preparation_v2.json').exists()
for p,k in old['input_sha256'].items():assert digest(Path(p))==k,p
cap=read(OUT/'primary_capture.json');assert cap['execution_state']=='FAILED' and cap['exit_code']==124 and (OUT/'primary_capture.json').read_bytes()==(CONTROL/'primary_full_capture.json').read_bytes()
files={Path(p) for p in old['input_sha256']}|{OUT/'preparation.json',OUT/'primary_capture.json',CONTROL/'primary_full_capture.json',OUT/'CORRECTION_V2.md',OUT/'test_v2.py',CONTROL/'run_v2.py',Path(__file__),CONTROL/'unfrozen_preparation_syntax_failure.txt'}
for p in [OUT/'test_v2.py',CONTROL/'run_v2.py',Path(__file__)]:
 ast.parse(p.read_text(encoding='utf-8'));Path(str(p)+'.source.txt').write_bytes(p.read_bytes());files.add(Path(str(p)+'.source.txt'))
allow={rte:sorted(set(paths)|{str(OUT/'preparation_v2.json')}) for rte,paths in old['read_json_by_role'].items()}
d={**old,'schema':'UB12_REFERENCE_SYMBOL_PREPARATION_V2','source_sha256':digest(OUT/'test_v2.py'),'controller_sha256':digest(CONTROL/'run_v2.py'),'input_sha256':{str(p):digest(p) for p in sorted(files)},'read_json_by_role':allow}
(OUT/'preparation_v2.json').write_bytes(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n');print('FROZEN exact cache and polynomial determinant correction',len(files))
