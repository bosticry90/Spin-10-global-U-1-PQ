from pathlib import Path
from hashlib import sha256
import ast,json
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_ub12_reference_symbol';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
p=read(OUT/'preparation_v2.json');assert not (OUT/'validation_preparation.json').exists()
for f,k in p['input_sha256'].items():assert digest(Path(f))==k,f
files={Path(f) for f in p['input_sha256']}|{OUT/'preparation_v2.json',OUT/'RESULT.md',OUT/'DERIVATION.md',CONTROL/'verify.py',CONTROL/'run_validation.py',Path(__file__)}
for role in ['primary','replay']:files|={OUT/(role+'_v2_result.json'),OUT/(role+'_v2_capture.json'),CONTROL/(role+'_v2_full_capture.json')}
for f in [CONTROL/'verify.py',CONTROL/'run_validation.py',Path(__file__)]:
 ast.parse(f.read_text(encoding='utf-8'));Path(str(f)+'.source.txt').write_bytes(f.read_bytes());files.add(Path(str(f)+'.source.txt'))
d={'schema':'UB12_REFERENCE_SYMBOL_VALIDATION_PREPARATION_V1','base_commit':p['base_commit'],'validator_sha256':digest(CONTROL/'verify.py'),'controller_sha256':digest(CONTROL/'run_validation.py'),'input_sha256':{str(f):digest(f) for f in sorted(files)},'limits':p['limits']}
(OUT/'validation_preparation.json').write_bytes(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n');print('FROZEN independent weighted principal and applicability verification',len(files))
