from pathlib import Path
from hashlib import sha256
import json,sys,time
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_ub12_reference_symbol';CONTROL=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
from audit_a10_e5_antighost_vector import resource,line_json
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
prep=read(OUT/'validation_preparation.json')
for p,k in [(Path(__file__),'controller_sha256'),(CONTROL/'verify.py','validator_sha256')]:assert digest(p)==prep[k] and p.read_bytes()==Path(str(p)+'.source.txt').read_bytes()
assert not (OUT/'validation_capture.json').exists()
tick=time.perf_counter();rec=capture([sys.executable,'-B',str(CONTROL/'verify.py')]);rec['parent_wall_seconds']=time.perf_counter()-tick
raw=json.dumps(rec,sort_keys=True,separators=(',',':')).encode()+b'\n'
for p in [CONTROL/'validation_full_capture.json',OUT/'validation_capture.json']:
    with p.open('xb') as f:f.write(raw)
if rec['execution_state']!='COMPLETED':print(rec['stdout_and_stderr'],flush=True)
resource(rec);r=line_json(rec['stdout_and_stderr'],'RESULT ');assert 0<r['elapsed_after_imports']<120
with (OUT/'validation_receipt.json').open('xb') as f:f.write(json.dumps(r,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('EXPORTED validation '+digest(OUT/'validation_receipt.json'),flush=True)
