"""Independent weighted rational degrees, full sparse principal inverse and jets."""
from pathlib import Path
from functools import lru_cache
from collections import Counter,defaultdict
import importlib.util,json,os,sys,time,threading,subprocess
import sympy as s
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_ub12_reference_symbol';CONTROL=Path(__file__).resolve().parent
def load(n,p):
 z=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(z);z.loader.exec_module(u);return u
b=load('qualified_ordinary_verifier_alphabet',CONTROL.parent/'auxiliary-companion-canonical-v1-2026-10-17/verify.py');v=b.v;read=v.read;digest=v.digest;PKG=v.PKG

def sealed(folder,rte):
 p=PKG/folder/(rte+'.json');r=read(p.parent/'bindings.json');assert r['byte_sha256'][p.relative_to(ROOT).as_posix()]==digest(p);return read(p)
def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();vp=read(OUT/'validation_preparation.json');assert digest(Path(__file__))==vp['validator_sha256']
 for path,k in vp['input_sha256'].items():assert digest(Path(path))==k,path
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==read(OUT/'preparation_v2.json')['base_commit'];allow={str(Path(x).resolve()) for x in vp['input_sha256']}|{str((OUT/'validation_preparation.json').resolve())}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  path=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('REFERENCE_SYMBOL_VALIDATION_WRITE')
  if path.suffix=='.json':assert str(path.resolve()) in allow,('UNDECLARED_VALIDATION_JSON',str(path))
 sys.addaudithook(guard);data={};perf={}
 for rte in ['primary','replay']:
  cap=read(OUT/(rte+'_v2_capture.json'));v.resource(cap);assert (OUT/(rte+'_v2_capture.json')).read_bytes()==(CONTROL/(rte+'_v2_full_capture.json')).read_bytes();data[rte]=v.line_json(cap['stdout_and_stderr'],'RESULT ');assert data[rte]==read(OUT/(rte+'_v2_result.json'));perf[rte]={'seconds':data[rte]['elapsed_after_imports'],'private_bytes':max(z['private_bytes'] for z in cap['all_resource_samples'])}
 for key in set(data['primary'])-{'route','stages','elapsed_after_imports'}:assert data['primary'][key]==data['replay'][key],key
 d=data['primary'];w=v.alphabet();core=sealed('frozen_a10_e5_full_hessian','primary');ref=core['retained_reference'];fields=ref['field_order'];grades=w.grades|w.external;t=[2-grades[n][0] for n in fields];assert Counter(t)==Counter({1:598,0:45}) and d['field_weight_counts']=={'0':45,'1':598};pp=s.symbols('p0_ref:4',real=True);loc=dict(zip(map(str,pp),pp));eta=(1,-1,-1,-1);P=sum(e*p*p for e,p in zip(eta,pp))
 @lru_cache(None)
 def num(txt):return s.sympify(txt,locals=loc)
 K={(i,j):num(z) for i,j,z in ref['reference_Hessian_raw_C3']['entries']};G={(i,j):num(z) for i,j,z in ref['reference_Green_raw_C3']['entries']};masses=sorted({a for z in [*K.values(),*G.values()] for a in z.free_symbols if str(a).startswith('Mref_')},key=str);assert len(masses)==4;variables=tuple(pp)+tuple(masses);weights=(1,)*4+(2,)*4
 @lru_cache(None)
 def degrees(expr):
  n,den=s.fraction(s.cancel(expr));N=s.Poly(n,*variables);D=s.Poly(den,*variables);ns={sum(x*y for x,y in zip(power,weights)) for power,z in N.terms() if z};ds={sum(x*y for x,y in zip(power,weights)) for power,z in D.terms() if z};assert len(ns)==len(ds)==1;assert not any(str(x) in ['xi','eta_H','g10'] for x in den.free_symbols);return next(iter(ns))-next(iter(ds))
 print('STAGE independent_all3147_weighted_numerator_denominator_degrees',flush=True)
 for (i,j),z in K.items():assert degrees(z)==t[i]+t[j]
 for (i,j),z in G.items():assert degrees(z)==-t[i]-t[j]
 assert [len(K),len(G)]==d['all1597_K1550_G_entries_homogeneous_with_mass_dimension']==[1597,1550]
 T={(i,j):num(z) for i,j,z in ref['physical_to_raw_kernel']['entries']};I={(i,j):num(z) for i,j,z in ref['physical_to_raw_inverse']['entries']};phys=[1]*508+[0]*45+[1]*90;assert all(not z.free_symbols and phys[i]==t[j] for (i,j),z in T.items());assert all(not z.free_symbols and t[i]==phys[j] for (i,j),z in I.items())
 K0={ij:s.cancel(z.xreplace({M:0 for M in masses})) for ij,z in K.items()};G0={ij:s.cancel(z.xreplace({M:0 for M in masses})) for ij,z in G.items()};K0={ij:z for ij,z in K0.items() if z};G0={ij:z for ij,z in G0.items() if z}
 @lru_cache(None)
 def cancel(expr):return s.cancel(expr)
 def product(A,B):
  rows=defaultdict(list)
  for (i,j),z in B.items():rows[i].append((j,z))
  R={}
  for (i,j),z in A.items():
   for k,u in rows[j]:R[i,k]=R.get((i,k),0)+z*u
  return {ij:zz for ij,z in R.items() if (zz:=cancel(z))!=0}
 print('STAGE independent_all643_sparse_leading_KG_GK_including_implicit_zeros',flush=True);identity={(i,i):s.S.One for i in range(643)};assert product(K0,G0)==product(G0,K0)==identity
 # No pole in widths or coupling; Euclidean p^2 nonzero on the unit shell.
 for U in [K0,G0]:
  for z in U.values():
   n,den=s.fraction(s.cancel(z));assert den.free_symbols<=set(pp)
 q=s.symbols('q0:4',real=True);Q=sum(x*x for x in q);assert s.expand(P.subs({pp[0]:s.I*q[0],**{pp[i]:q[i] for i in range(1,4)}},simultaneous=True))==-Q
 pv=s.Matrix(pp);em=s.diag(*eta);up=em*pv;W=s.Symbol('width');K5=(-P*em+up*up.T).row_join(s.I*up).col_join((-s.I*up.T).row_join(s.Matrix([[W]])));assert s.factor(K5.det(method='domain-ge'))==-P**4 and (-P*em+up*up.T).det(method='domain-ge')==0;assert len(d['all45_mixed_principal_blocks'])==45 and all(row==[i,'eta_H' if i<12 else 'xi','-p_squared^4'] for i,row in enumerate(d['all45_mixed_principal_blocks']))
 # Mislabeling all inverse entries as order-2 fails for actual mixed entries.
 assert any(degrees(z)!=-2 for (i,j),z in G0.items() if t[i]!=t[j])
 print('STAGE independent_actual_H_curvature_and_ordered_inverse_identities',flush=True);e3=sealed('frozen_a10_e3_symmetry','primary');R=s.zeros(12);g=s.Symbol('g10')
 for i in range(12):
  for row in e3['operators']['Tb_geometric_and_transported']['C'+str(i)]:
   if 'omega0' in row['word']:
    other=[n for n in row['word'] if n.startswith('C')];R[i,int(other[0][1:])]+=s.cancel(s.sympify(row['coefficient'])/g)
 assert R==s.SparseMatrix(12,12,{(i,j):s.sympify(z) for i,j,z in d['actual_H_curvature_order_control']['rho_entries']});j=d['actual_H_curvature_order_control']['column'];x,y=s.symbols('x y');f=s.zeros(12,1);f[j]=x*y;D0=lambda z:z.diff(x);D1=lambda z:z.diff(y)+g*x*R*z;Delta=lambda z:-D0(D0(z))-D1(D1(z));comm=(Delta(D1(f))-D1(Delta(f))).applyfunc(s.expand);assert comm==(-2*g*R*D0(f)).applyfunc(s.expand) and comm!=s.zeros(12,1)
 f[j]=x*x;actual=(Delta(D1(f))-D1(Delta(f))).applyfunc(s.expand);assert actual==s.Matrix(12,1,lambda i,k:s.sympify(dict(d['actual_H_curvature_order_control']['nonzero_commutator']).get(i,'0')))
 # Different noncommuting exact matrices verify orientation; formal identity is
 # additionally expanded as free words reduced only by genuine inverse pairs.
 L=s.Matrix([[2,1],[0,3]]);D=s.Matrix([[0,1],[2,0]]);Li=L.inv();assert Li*D-D*Li==-Li*(L*D-D*L)*Li and Li*Li*D-D*Li*Li==Li*(-Li*(L*D-D*L)*Li)+(-Li*(L*D-D*L)*Li)*Li
 # Reconstruct the entire degree-4 inverse jet recurrence, no native formula.
 z,p=s.symbols('z p');U=s.Matrix(2,2,lambda i,j:s.Function('u'+str(i)+str(j))(z));A=p*p*s.eye(2)+U;parts=[s.eye(2)/p**2]
 for n in range(1,5):
  trial=sum(parts,s.zeros(2));defect=A*trial-2*s.I*p*trial.diff(z)-trial.diff(z,2);coeff=defect.applyfunc(lambda v:s.expand(v).coeff(p,-n));parts.append(-coeff/p**(n+2))
 B=sum(parts,s.zeros(2));native=s.Matrix(2,2,lambda i,j:s.sympify(next(text for a,b,text in d['matrix_potential_parametrix_through_relative4'] if (a,b)==(i,j))));assert all(s.expand(v)==0 for v in B-native)
 left=A*B-2*s.I*p*B.diff(z)-B.diff(z,2);right=sum((((-s.I)**n/s.factorial(n))*B.diff(p,n)*A.diff(z,n) for n in range(5)),s.zeros(2))
 for product0 in [left,right]:assert all(s.expand(v).coeff(p,n)==0 for v in product0-s.eye(2) for n in range(-4,1))
 # The input artifact declares a family; no exact ordered A-dependent symbol
 # is present in its bound structured reference entries. No whole-repo absence.
 assert sorted(ref)==d['actual_retained_reference_fields'] and isinstance(core['finite_cutoff_loop_program']['reference'],str) and 'covariantized' in core['finite_cutoff_loop_program']['reference'];assert d['actual_covariant_reference_specification']==core['finite_cutoff_loop_program']['reference'] and d['actual_heat_specification']==core['finite_cutoff_loop_program']['cutoff'];assert not d['structured_background_ordered_symbol_in_these_bound_fields'] and d['ordering_difference_does_not_prove_nonlocality']
 failed=read(OUT/'primary_capture.json');assert failed['execution_state']=='FAILED' and failed['exit_code']==124 and (OUT/'primary_capture.json').read_bytes()==(CONTROL/'primary_full_capture.json').read_bytes();qc=sealed('frozen_a10_e5_quantum_contract','primary');assert all(qc[k]==value==False for k,value in d['seven_quantum_flags_unchanged'].items());assert all(d['counterexample_controls'].values()) and not d['actual_local_UV_or_regulated_QAP_measure_IR_contacts_full_Slavnov_E5_A5_proved']
 result={'schema':'UB12_REFERENCE_SYMBOL_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':'ACTUAL_MIXED_WEIGHTED_PRINCIPAL_INVERTIBILITY_QUALIFIED_ACTUAL_BACKGROUND_LOCALITY_UNPROVED','all643_weights_and3147_actual_entries_verified':True,'all_constant_frame_entries_preserve_weights':True,'all643_sparse_principal_KG_and_GK_including_implicit_zeros_verified':True,'Wick_principal_no_width_g_or_reference_mass_inverse':True,'all45_mixed_blocks_ghost_signs_scalar_principals_consistent':True,'actual_H_curvature_noncommutation_recomputed_with_distinct_fixture':True,'matrix_potential_local_inverse_recurrence_and_both_sides_checked':True,'literal_bound_covariant_reference_ordering_gap_preserved_not_global_absence':True,'no_whole_mixed_positive_Laplacian_or_residue_cyclicity_shortcut':True,'actual_local_UV_QAP_measure_IR_contacts_E5_A5':'UNQUALIFIED','authority_inputs_sources_functional_and_seven_false_flags_unchanged':True,'new_failed_worker_executions':1,'new_failed_verifier_executions':0,'fresh_byte_identical_replay_pairs_claimed':0,'performance':perf,'input_sha256':vp['input_sha256'],'shared_limits':'Actual reference,field/frame conventions,SymPy and AI author shared. Symbol tests do not instantiate the missing ordered background reference or global heat/IR/measure construction.','elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
