from pathlib import Path
from hashlib import sha256
import json,subprocess,sys,time
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_ub12_reference_symbol';CONTROL=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'))
from export_a10_e5_antighost_vector import capture
from audit_a10_e5_antighost_vector import resource,line_json
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
role=sys.argv[1];assert role in ['primary','replay'];prep=read(OUT/'preparation.json');assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==prep['base_commit']
for p,k in [(Path(__file__),'controller_sha256'),(OUT/'test.py','source_sha256')]:assert digest(p)==prep[k] and p.read_bytes()==Path(str(p)+'.source.txt').read_bytes()
assert not (OUT/(role+'_capture.json')).exists()
if role=='replay':resource(read(OUT/'primary_v2_capture.json'))
tick=time.perf_counter();rec=capture([sys.executable,'-B',str(OUT/'test.py'),role]);rec['parent_wall_seconds']=time.perf_counter()-tick
raw=json.dumps(rec,sort_keys=True,separators=(',',':')).encode()+b'\n'
for p in [CONTROL/(role+'_full_capture.json'),OUT/(role+'_capture.json')]:
    with p.open('xb') as f:f.write(raw)
if rec['execution_state']!='COMPLETED':print(rec['stdout_and_stderr'],flush=True)
resource(rec);r=line_json(rec['stdout_and_stderr'],'RESULT ');assert 0<r['elapsed_after_imports']<120
with (OUT/(role+'_result.json')).open('xb') as f:f.write(json.dumps(r,sort_keys=True,separators=(',',':')).encode()+b'\n')
print('EXPORTED '+role+' '+digest(OUT/(role+'_result.json')),flush=True)
