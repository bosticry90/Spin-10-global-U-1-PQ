from pathlib import Path
from hashlib import sha256
import json,subprocess
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_ub12_reference_symbol';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def git(*args,raw=False):
 b=subprocess.check_output(['git',*args],cwd=ROOT);return b if raw else b.decode('utf-8').strip()
base=read(OUT/'preparation_v2.json')['base_commit'];assert git('rev-parse','HEAD')==base;r=read(OUT/'validation_receipt.json');assert r['execution_state']=='COMPLETED' and r['scientific_disposition']=='ACTUAL_MIXED_WEIGHTED_PRINCIPAL_INVERTIBILITY_QUALIFIED_ACTUAL_BACKGROUND_LOCALITY_UNPROVED'
for k in ['all643_weights_and3147_actual_entries_verified','all_constant_frame_entries_preserve_weights','all643_sparse_principal_KG_and_GK_including_implicit_zeros_verified','Wick_principal_no_width_g_or_reference_mass_inverse','all45_mixed_blocks_ghost_signs_scalar_principals_consistent','actual_H_curvature_noncommutation_recomputed_with_distinct_fixture','matrix_potential_local_inverse_recurrence_and_both_sides_checked','literal_bound_covariant_reference_ordering_gap_preserved_not_global_absence','no_whole_mixed_positive_Laplacian_or_residue_cyclicity_shortcut','authority_inputs_sources_functional_and_seven_false_flags_unchanged']:assert r[k],k
assert r['new_failed_worker_executions']==1 and r['new_failed_verifier_executions']==0 and r['actual_local_UV_QAP_measure_IR_contacts_E5_A5']=='UNQUALIFIED'
for p,k in r['input_sha256'].items():assert digest(Path(p))==k,p
vp=read(OUT/'validation_preparation.json');assert digest(CONTROL/'verify.py')==vp['validator_sha256'] and digest(CONTROL/'run_validation.py')==vp['controller_sha256'];cap=read(OUT/'validation_capture.json');assert cap['execution_state']=='COMPLETED' and cap['exit_code']==0 and cap['calculation_completed'] and cap['post_run_observations_qualified'];assert (OUT/'validation_capture.json').read_bytes()==(CONTROL/'validation_full_capture.json').read_bytes()
for p in ['AGENTS.md','CHARTER.md','README.md','project_state.json','docs/LOCAL_RESEARCH_CONVENTIONS_V1.md']:assert git('show',base+':'+p,raw=True)==(ROOT/p).read_bytes()
paths=sorted([p.relative_to(ROOT).as_posix() for p in OUT.iterdir() if p.is_file()]+['docs/RESEARCH_EXECUTION_HANDOFF_V252.md']);assert set(git('ls-files','--others','--exclude-standard').splitlines())==set(paths) and not git('diff','--name-only') and not git('diff','--cached','--name-only')
subprocess.check_call(['git','-c','core.autocrlf=false','-c','core.longpaths=true','add','--',*paths],cwd=ROOT);assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
for p in paths:assert git('show',':'+p,raw=True)==(ROOT/p).read_bytes(),p
subprocess.check_call(['git','diff','--cached','--check'],cwd=ROOT);subprocess.check_call(['git','commit','-m','Verify mixed reference principal symbol and classify UV-locality prerequisite'],cwd=ROOT)
head=git('rev-parse','HEAD');assert git('rev-parse','HEAD^')==base and set(git('diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines())==set(paths)
for p in paths:assert git('show','HEAD:'+p,raw=True)==git('show',':'+p,raw=True)==(ROOT/p).read_bytes()
assert not git('status','--porcelain=v1');proof={'HEAD':head,'parent':base,'exact_changed_files':paths,'all_HEAD_index_worktree_bytes_equal':True,'working_tree_clean':True,'receipt_sha256':digest(OUT/'validation_receipt.json'),'authority_unchanged':digest(ROOT/'project_state.json')=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8','current_full_functional_unchanged':True,'weighted_principal_symbol_qualified_actual_locality_unproved':True,'full_QAP_measure_E5_A5':'UNQUALIFIED','no_remote_action':True};assert proof['authority_unchanged']
(CONTROL/'post_commit.json').write_bytes(json.dumps(proof,sort_keys=True,separators=(',',':')).encode()+b'\n');print(json.dumps({'HEAD':head,'files':len(paths),'clean':True,'receipt_sha256':proof['receipt_sha256'],'full_E5_A5':'UNQUALIFIED'}))
