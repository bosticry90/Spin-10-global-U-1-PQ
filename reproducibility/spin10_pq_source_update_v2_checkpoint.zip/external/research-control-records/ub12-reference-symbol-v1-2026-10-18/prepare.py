from pathlib import Path
from hashlib import sha256
import ast,json,subprocess
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_ub12_reference_symbol';CONTROL=Path(__file__).resolve().parent;PKG=ROOT/'tools/two_loop_qft_compiler_v1/m08_independent_replay_package_v1'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert base=='f3b3dbc8d6cb39767b5cc5ce29f2c8f7287a9ed3' and not (OUT/'preparation.json').exists();prior=ROOT/'calculations/canonical_so10_ub12_background_locality';r=read(prior/'validation_v2_receipt.json');assert r['execution_state']=='COMPLETED'
files={Path(p) for p in r['input_sha256']}|{prior/'validation_v2_receipt.json',OUT/'RECORD.md',OUT/'DERIVATION.md',OUT/'test.py',CONTROL/'run.py',Path(__file__),ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V251.md',PKG/'a10_e5_full_hessian.py',PKG/'a10_e5_full_hessian_ref_factorization.py'}
for p,k in r['input_sha256'].items():assert digest(Path(p))==k,p
allow={}
for rte in ['primary','replay']:
 paths={OUT/'preparation.json'}
 for folder in ['frozen_a10_e5_full_hessian','frozen_a10_e3_symmetry','frozen_a10_e5_quantum_contract']:paths|={PKG/folder/(rte+'.json'),PKG/folder/'bindings.json'}
 allow[rte]=sorted(str(p) for p in paths);files|=paths-{OUT/'preparation.json'}
for p in [OUT/'test.py',CONTROL/'run.py',Path(__file__)]:
 ast.parse(p.read_text(encoding='utf-8'));Path(str(p)+'.source.txt').write_bytes(p.read_bytes());files.add(Path(str(p)+'.source.txt'))
d={'schema':'UB12_REFERENCE_SYMBOL_PREPARATION_V1','base_commit':base,'source_sha256':digest(OUT/'test.py'),'controller_sha256':digest(CONTROL/'run.py'),'input_sha256':{str(p):digest(p) for p in sorted(files)},'read_json_by_role':allow,'limits':{'seconds_after_imports':120,'private_bytes':8*1024**3,'minimum_available_commit_bytes':350*1024**2}}
(OUT/'preparation.json').write_bytes(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n');print('FROZEN actual mixed reference symbol assessment',len(files))
