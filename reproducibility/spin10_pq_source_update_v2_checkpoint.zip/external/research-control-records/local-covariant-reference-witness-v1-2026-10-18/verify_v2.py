"""Independent coefficient-matrix and ordered-quadratic reference verification."""
from pathlib import Path
from collections import Counter,defaultdict
from functools import lru_cache
from itertools import permutations
import importlib.util,json,os,sys,time,threading,subprocess
import sympy as s
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_local_covariant_reference_witness';CONTROL=Path(__file__).resolve().parent
def load(n,p):
 z=importlib.util.spec_from_file_location(n,p);u=importlib.util.module_from_spec(z);z.loader.exec_module(u);return u
b=load('ordinary_local_reference_helpers',CONTROL.parent/'auxiliary-companion-canonical-v1-2026-10-17/verify.py');v=b.v;read=v.read;digest=v.digest;PKG=v.PKG

def sealed(folder,rte):
 p=PKG/folder/(rte+'.json');r=read(p.parent/'bindings.json');assert r['byte_sha256'][p.relative_to(ROOT).as_posix()]==digest(p);return read(p)
@lru_cache(None)
def clean(z):return s.cancel(z)
def main():
 tick=time.perf_counter();timer=threading.Timer(120,lambda:os._exit(124));timer.daemon=True;timer.start();vp=read(OUT/'validation_preparation_v2.json');assert digest(Path(__file__))==vp['validator_sha256']
 for path,k in vp['input_sha256'].items():assert digest(Path(path))==k,path
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==read(OUT/'preparation.json')['base_commit'];allow={str(Path(x).resolve()) for x in vp['input_sha256']}|{str((OUT/'validation_preparation_v2.json').resolve())}
 def guard(event,args):
  if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
  path=Path(os.fsdecode(args[0]))
  if len(args)>1 and isinstance(args[1],str) and any(c in args[1] for c in 'wax+'):raise PermissionError('LOCAL_REFERENCE_VALIDATION_WRITE')
  if path.suffix=='.json':assert str(path.resolve()) in allow,('UNDECLARED_VALIDATION_JSON',str(path))
 sys.addaudithook(guard);data={};perf={}
 for rte in ['primary','replay']:
  cap=read(OUT/(rte+'_capture.json'));v.resource(cap);assert (OUT/(rte+'_capture.json')).read_bytes()==(CONTROL/(rte+'_full_capture.json')).read_bytes();data[rte]=v.line_json(cap['stdout_and_stderr'],'RESULT ');assert data[rte]==read(OUT/(rte+'_result.json'));perf[rte]={'seconds':data[rte]['elapsed_after_imports'],'private_bytes':max(z['private_bytes'] for z in cap['all_resource_samples'])}
 for key in set(data['primary'])-{'route','stages','elapsed_after_imports'}:assert data['primary'][key]==data['replay'][key],key
 d=data['primary'];core=sealed('frozen_a10_e5_full_hessian','primary');e3=sealed('frozen_a10_e3_symmetry','primary');w=v.alphabet();fields=core['retained_reference']['field_order'];pos={n:i for i,n in enumerate(fields)};grades=w.grades|w.external;par=[grades[n][2] for n in fields];R=[{} for _ in range(12)];aff=set()
 for n in fields:
  for row in e3['operators']['Tb_geometric_and_transported'][n]:
   omega=[z for z in row['word'] if z.startswith('omega')];body=[z for z in row['word'] if not z.startswith('omega')];assert len(omega)==1
   if '__' in omega[0]:assert not body and n.startswith('B');aff.add(n);continue
   assert len(body)==1 and body[0] in pos;i,j=pos[n],pos[body[0]];a=int(omega[0][5:]);z=clean(v.num(row['coefficient'])/v.g);assert not z.free_symbols and grades[n]==grades[body[0]];R[a][i,j]=R[a].get((i,j),0)+z
 assert sorted(aff)==d['actual48_field_affines'] and len(aff)==48
 for rho,rows in zip(R,d['actual12_homogeneous_carrier_matrices']):assert rho=={(i,j):v.num(z) for i,j,z in rows}
 assert e3['local_algebra']['all_generator_local_Lie_checks']==4002 and e3['local_algebra']['all_three_residuals_zero'] and e3['local_algebra']['parameter_derivatives_retained']
 pp=s.symbols('p0_ref:4');K={(i,j):v.num(z) for i,j,z in core['retained_reference']['reference_Hessian_raw_C3']['entries']};coeff=defaultdict(dict)
 for ij,z in K.items():
  for powers,c in s.Poly(z,*pp).terms():assert sum(powers)<=2;coeff[powers][ij]=c
 def invariant(C,rho):
  rr=defaultdict(list);out={}
  for (i,j),z in rho.items():rr[i].append((j,z))
  for (i,j),z in C.items():
   for k,u in rr[j]:out[i,k]=out.get((i,k),0)+z*u
   for k,u in rr[i]:out[k,j]=out.get((k,j),0)+u*z
  return all(clean(z)==0 for z in out.values())
 print('STAGE independent_every_momentum_coefficient_all12_actual_carrier_congruences',flush=True)
 for powers,C in coeff.items():assert all(invariant(C,rho) for rho in R),powers
 # Reconstruct ordering from polarization of noncommuting derivatives, using
 # permutation multiplicity rather than native distinct-word averaging.
 O={}
 for powers,C in coeff.items():
  word=tuple(mu for mu,k in enumerate(powers) for _ in range(k));perms=list(permutations(word)) if word else [()]
  for ij,z in C.items():
   for ws in perms:O[ij[0],ij[1],ws]=O.get((ij[0],ij[1],ws),0)+z*(-s.I)**len(word)/len(perms)
 O={key:clean(z) for key,z in O.items()};saved={(i,j,tuple(ws)):v.num(z) for i,j,ws,z in d['explicit_covariant_operator']['entries']};assert set(O)==set(saved) and all(clean(z-saved[key])==0 for key,z in O.items());assert len(O)==d['explicit_operator_positions']==4131
 flat=defaultdict(lambda:s.S.Zero)
 for (i,j,word),z in O.items():flat[i,j]+=z*s.prod(s.I*pp[mu] for mu in word)
 assert set(flat)==set(K) and len(K)==1597 and all(clean(z-K[ij])==0 for ij,z in flat.items());assert Counter(map(lambda key:len(key[2]),O))==Counter({0:375,1:376,2:3380})
 # This adjoint is exactly the polarization Hessian of one_half h Kcov h;
 # coefficient intertwiners checked above justify dual integration by parts.
 adj={}
 for (i,j,word),z in O.items():adj[j,i,word[::-1]]=(-1)**(par[i]*par[j]+len(word))*z
 assert set(adj)==set(O) and all(clean(z-adj[key])==0 for key,z in O.items())
 # No false sensitivity for reversal of a fully symmetric derivative word.
 assert all(O[i,j,ws[::-1]]==z for (i,j,ws),z in O.items()) and ('insensitive' in d['insensitive_control'] or d['insensitive_control'].startswith('reversing'))
 mutant=dict(R[0]);mutant.pop(next(iter(mutant)));assert any(not invariant(C,mutant) for C in coeff.values())
 wrongghost=any(clean(z-(-1)**len(ws)*O.get((j,i,ws[::-1]),0))!=0 for (i,j,ws),z in O.items() if par[i]);assert wrongghost
 # Explicit local parameter-gradient covariance: at A=0,deltaA=domega,
 # [g rho omega,partial]=-g rho domega. Only negative connection sign agrees.
 domega=s.Symbol('omega_gradient');nonzero=next(z for z in R[0].values() if z);delta_plus=v.g*nonzero*domega;comm=-v.g*nonzero*domega;assert clean(delta_plus-comm)!=0 and clean(-delta_plus-comm)==0
 witness=d['explicit_covariant_operator'];assert witness['derivative']=='D_mu=partial_mu-g10 sum_a rho_a A^a_mu';assert 'symmetric' in witness['ordering'] and 'one_half' in witness['quadratic_form'];assert d['local_differential_order_at_most2_and_local_finite_background_jets'] and d['same_actual_weighted_principal_symbol']
 priorp=ROOT/'calculations/canonical_so10_ub12_reference_symbol/validation_receipt.json';prior=read(priorp);assert prior['execution_state']=='COMPLETED' and prior['all643_sparse_principal_KG_and_GK_including_implicit_zeros_verified'];qc=sealed('frozen_a10_e5_quantum_contract','primary');assert all(qc[k]==value==False for k,value in d['seven_false_quantum_flags'].items())
 cp=read(OUT/'replay_controller_preparation_v2.json');assert digest(CONTROL/'run_replay_v2.py')==cp['controller_sha256'];assert (CONTROL/'run_replay_v2.py').read_bytes()==(CONTROL/'run_replay_v2.py.source.txt').read_bytes();assert 'prelaunch' in (OUT/'REPLAY_CONTROLLER_CORRECTION_V2.md').read_text(encoding='utf-8').lower() or 'before' in (OUT/'REPLAY_CONTROLLER_CORRECTION_V2.md').read_text(encoding='utf-8');assert all(d['controls'].values())
 assert not d['adopted_physical_scheme_or_unique_historical_covariantization'] and not d['full_heat_IR_UV_subtraction_correspondence_or_actual_historical_member_qualification'] and not d['QAP_measure_IR_contacts_full_sourcefree_Slavnov_E5_A5_proved']
 result={'schema':'LOCAL_COVARIANT_REFERENCE_WITNESS_VALIDATION_V1','execution_state':'COMPLETED','scientific_disposition':'EXPLICIT_LOCAL_COVARIANT_REFERENCE_WITNESS_QUALIFIED_NOT_ADOPTED_QUANTUM_SCHEME','all643_actual_H_carriers_and48_affines_verified':True,'all12_congruences_checked_coefficient_by_coefficient':True,'all4131_ordered_entries_reconstructed_by_independent_multiplicities':True,'all1597_original_flat_coefficients_exactly_recovered':True,'formal_graded_adjoint_and_quadratic_Hessian_checked':True,'inherited4002_Lie_checks_and_actual_weighted_principal_qualified_inputs_authenticated':True,'wrong_connection_sign_carrier_omission_and_ghost_sign_controls_sensitive':True,'Weyl_word_reversal_insensitivity_disclosed':True,'only_this_explicit_local_member_and_formal_local_jet_recursion_qualified':True,'actual_heat_IR_UV_QAP_measure_contacts_full_Slavnov_E5_A5':'UNQUALIFIED','authority_inputs_sources_functional_and_seven_false_flags_unchanged':True,'new_failed_scientific_worker_executions':0,'new_failed_controller_prelaunches':1,'new_failed_verifier_executions':0,'completed_independent_verifier_runs':2,'V1_reversal_diagnostic_assertion_strengthened':True,'fresh_byte_identical_replay_pairs_claimed':0,'performance':perf,'input_sha256':vp['input_sha256'],'shared_limits':'Actual E3 Lie/reference/field conventions,software and AI author shared. Formal quadratic reference and local-symbol class do not prove global heat/measure/QAP/IR or adopted physical scheme.','elapsed_after_imports':time.perf_counter()-tick};print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True);timer.cancel()
if __name__=='__main__':main()
