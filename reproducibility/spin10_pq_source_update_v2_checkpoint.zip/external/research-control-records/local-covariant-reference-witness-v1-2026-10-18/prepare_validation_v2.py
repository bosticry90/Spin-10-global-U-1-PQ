from pathlib import Path
from hashlib import sha256
import json,ast
ROOT=Path(r'C:/Users/psboy/Documents/ToE-Next');OUT=ROOT/'calculations/canonical_so10_local_covariant_reference_witness';CONTROL=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
old=read(OUT/'validation_preparation.json');previous=read(OUT/'validation_receipt.json');assert previous['execution_state']=='COMPLETED' and not (OUT/'validation_preparation_v2.json').exists()
for p,k in old['input_sha256'].items():assert digest(Path(p))==k,p
assert (OUT/'validation_capture.json').read_bytes()==(CONTROL/'validation_full_capture.json').read_bytes()
files={Path(p) for p in old['input_sha256']}|{OUT/'validation_preparation.json',OUT/'validation_capture.json',OUT/'validation_receipt.json',CONTROL/'validation_full_capture.json',OUT/'VALIDATION_CLARIFICATION_V2.md',CONTROL/'verify_v2.py',CONTROL/'run_validation_v2.py',Path(__file__)}
for p in [CONTROL/'verify_v2.py',CONTROL/'run_validation_v2.py',Path(__file__)]:
 ast.parse(p.read_text(encoding='utf-8'));Path(str(p)+'.source.txt').write_bytes(p.read_bytes());files.add(Path(str(p)+'.source.txt'))
d={'schema':'LOCAL_REFERENCE_WITNESS_VALIDATION_PREPARATION_V2','base_commit':old['base_commit'],'validator_sha256':digest(CONTROL/'verify_v2.py'),'controller_sha256':digest(CONTROL/'run_validation_v2.py'),'input_sha256':{str(p):digest(p) for p in sorted(files)},'limits':old['limits']}
(OUT/'validation_preparation_v2.json').write_bytes(json.dumps(d,sort_keys=True,separators=(',',':')).encode()+b'\n');print('FROZEN explicit reversal assertion strengthening',len(files))
