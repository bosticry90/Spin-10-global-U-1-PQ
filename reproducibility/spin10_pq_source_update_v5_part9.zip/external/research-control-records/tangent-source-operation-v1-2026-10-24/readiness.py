from pathlib import Path
import subprocess,json,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');H=Path(__file__).resolve().parent
# A fresh bounded read-only run is captured here for byte-custody of sealing;
# the preceding terminal-only run was successful but has no native file capture.
with (H/'readiness.jsonl').open('xb') as out,(H/'readiness_stderr.txt').open('xb') as err:r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/research_check.py'),'e4'],cwd=ROOT,stdout=out,stderr=err)
lines=[json.loads(x) for x in (H/'readiness.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()];steps=[x['exit_code'] for x in lines if x['event']=='step_finished']
with (H/'readiness_native_exit.json').open('xb') as f:f.write((json.dumps({'native_exit':r.returncode,'step_exits':steps,'historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print(json.dumps({'native_exit':r.returncode,'step_exits':steps},sort_keys=True),flush=True);assert r.returncode==0 and steps==[0,0,0,0,0,2]
