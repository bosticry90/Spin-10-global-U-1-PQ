from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');H=ROOT/'calculations/canonical_so10_tangent_source_operation';C=Path(__file__).resolve().parent;BASE='604be9c28b64572479fda1bc4137dff4ff274e9d';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (C/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
expected={'preparation.json':63,'validation_preparation.json':71,'preparation_v2.json':95,'validation_preparation_v2.json':103}
for n,k in expected.items():
 d=read(H/n);assert len(d['input_sha256'])==k
 for p,h in d['input_sha256'].items():assert digest(Path(p))==h,p
copies=list(H.glob('*.source.txt'));assert len(copies)==15
for p in copies:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes()
receipts={'validation_receipt.json':'1d845840ed222701a765d03af4ed71a0815587208862733e16e22d75e3e3b80e','validation_receipt_v2.json':'63dc86af3f5b62ad1a5b05f8d26b4cf181170f99384df68dcc5a13d39e225a18'}
for n,h in receipts.items():assert digest(H/n)==h
r,v=read(H/'validation_receipt.json'),read(H/'validation_receipt_v2.json')
assert r['status']=='QUALIFIED_SELECTED_LOCAL_TANGENT_SOURCE_OPERATION_AND_HH_COMPATIBILITY'
assert r['individual_hh_bubble_and_source_nonzero_each']==24761 and r['summed_hh_antighost_nonzero']==0 and r['generic_bubble_nonzero_positions']==42426 and r['new_source_Euler_nonzero_positions_each']==13538
assert r['hh_antighost_positions_full']==2413260 and r['hh_antighost_positions_within_sectors']==1496160 and r['actual_hh_JL_nonzero']==0 and not r['new_quantum_trace_or_multiple_insertion_domain_proved']
assert v['status']=='QUALIFIED_COMMON_ZERO_MATTER_H_LOCAL_COMPARISON_WITH_MATCHED_SINGLE_VARIATION_DOMAIN'
assert v['coefficient_nonzero_counts']=={'affine_v':448,'affine_w':42426,'auxiliary':17658,'extra_triangle':0,'ordinary_H':36320,'ordinary_M':0,'source_Jx':1342}
assert v['primitive_H_covariance_positions']==36886848 and v['primitive_H_covariance_residual']==0 and v['constant_tangent_entries_unchanged']==225 and v['one_tangent_IR_degree']==3 and v['two_tangent_critical_IR_degree_control']==4
assert v['new_Jx_kernel_ownership']=='REPLACES_VHR_V5_NEW_JH_OWNER_NOT_AN_ADDITIONAL_COPY' and not v['full_chiral_extension_proved'] and not v['full_QAP_E5A5_qualified'] and not r['full_QAP_E5A5_qualified']
roles=['primary','replay','verify','primary_v2','replay_v2','verify_v2']
for role in roles:
 c=read(H/(role+'_capture.json'));assert c==read(C/(role+'_full_capture.json')) and c['all_resource_samples']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3
 assert c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
 rr=[json.loads(z[7:]) for z in c['stdout_and_stderr'].splitlines() if z.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<600
 if role=='verify':assert rr[0]==r
 elif role=='verify_v2':assert rr[0]==v
 else:
  b=(H/(role+'_tables.json.gz')).read_bytes();assert sha256(b).hexdigest()==rr[0]['packed_sha256'] and sha256(gzip.decompress(b)).hexdigest()==rr[0]['tables_sha256']
for n,d in [('selected_local_tangent_source_operation.json.gz',r),('common_h_local_comparison_v2.json.gz',v)]:
 b=(H/n).read_bytes();assert sha256(b).hexdigest()==d['artifact_sha256'] and sha256(gzip.decompress(b)).hexdigest()==d['artifact_raw_sha256']
assert not any(p.name.startswith('controller_failure') for p in H.iterdir())
for suffix in ['','_v2']:
 c=read(H/('preparation'+suffix+'_capture.json'));assert c['native_exit']==0 and c==read(C/('preparation'+suffix+'_full_capture.json'))
assert sum(p.stat().st_size for p in H.iterdir() if p.is_file())<16*1024**2
assert read(C/'readiness_native_exit.json')['native_exit']==0 and read(C/'readiness_native_exit.json')['step_exits']==[0,0,0,0,0,2]
ev=[json.loads(z) for z in (C/'readiness.jsonl').read_text(encoding='utf-8').splitlines() if z.strip()];steps=[x for x in ev if x['event']=='step_finished'];assert [x['exit_code'] for x in steps]==[0,0,0,0,0,2]
assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in next(x for x in steps if x['step']=='historical_custody')['stdout'] and ev[-1]['execution_state']=='COMPLETED'
old=(C/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==33893
files=sorted([p for p in H.iterdir() if p.is_file()]+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V581.md'])
for p in files:
 if p.suffix!='.gz':assert b'\r' not in p.read_bytes(),p
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':33893,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'binding_counts':expected,'source_copies':15,'receipt_sha256':receipts,'scientific_acceptance':'NOT_PERFORMED','seal_source_sha256':digest(Path(__file__)),'readiness_sha256':{n:digest(C/n) for n in ['readiness.py','readiness.jsonl','readiness_stderr.txt','readiness_native_exit.json']}});print('TSO1_BEFORE_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(C/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'raw_index_files':len(files),'scientific_acceptance':'NOT_PERFORMED'});print('TSO1_INDEX_SEALED',len(files),flush=True)
else:
 assert mode=='after';seal=read(C/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 mapping=lambda bb:{v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in bb.splitlines()};prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==33893+len(files) and all(current[n]==d for n,d in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 for n,h in seal['readiness_sha256'].items():assert digest(C/n)==h
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':33893,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'source_copies':15,'binding_counts':expected,'receipt_sha256':receipts,'precommit_and_index_custody_passed':True,'scientific_authority':'34/39_UNCHANGED','historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED','whole_investigation':'INCOMPLETE','all_old_failed_records_preserved':True};save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
