from pathlib import Path
from hashlib import sha256,sha1
import json,subprocess,sys,os
R=Path.cwd();O=R/'calculations/canonical_so10_intrinsic_source_cutoff_color';C=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes());phase=sys.argv[1]
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
def dump(p,z):
 with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True);f.write('\n')
def tree(ref):
 out={}
 for rec in git('ls-tree','-rz',ref).split(b'\0'):
  if rec:
   hdr,p=rec.split(b'\t',1);m,t,h=hdr.split();assert t==b'blob';out[p.decode()]=(m.decode(),h.decode())
 return out
base='93226d5d038772c8edc0e3928cf0768bad5af588';state='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';assert H(R/'project_state.json')==state and git('branch','--show-current').decode().strip()=='main'
if phase=='before':
 assert git('rev-parse','HEAD').decode().strip()==base and git('ls-tree','-r','HEAD')==(C/'old_git_tree.txt').read_bytes()and len(tree(base))==38078;assert not git('diff','--name-only','HEAD')and not git('diff','--cached','--name-only');bindings=copies=peak=0;caps=[]
 for p in O.glob('*preparation*.json'):
  for f,h in read(p)['input_sha256'].items():assert H(Path(f))==h,(p,f);bindings+=1
 for p in O.glob('*.source.txt'):assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes();copies+=1
 for p in O.glob('*capture.json'):
  z=read(p);assert z['post_run_observations_qualified']and z['launch']['memory']['available_pagefile']>=350*1024**2;mx=max(q['private_bytes']for q in z['all_resource_samples']);peak=max(peak,mx);assert mx<=8*1024**3
  if p.name=='final_review_capture.json':assert z['exit_code']==1 and z['execution_state']=='FAILED'and not z['calculation_completed']
  else:assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']
  caps.append({'name':p.name,'state':z['execution_state'],'exit':z['exit_code'],'largest_sample':mx})
 assert len(caps)==6 and not(O/'final_review_validation_receipt.json').exists();v=read(O/'final_review_validation_receipt_v2.json');assert v['original_final_lexical_assertion_failed_and_preserved']and all(q['all_old_F5_plus_new_cutoff_zero']for q in v['independent_exact_ring_full_tensor_check'])and not v['complete_source_Ward_QAP_or_E5_promoted'];files={p.relative_to(R).as_posix():H(p)for p in O.iterdir()if p.is_file()};hh=R/'docs/RESEARCH_EXECUTION_HANDOFF_V634.md';assert max(int(p.stem.split('_V')[-1])for p in (R/'docs').glob('RESEARCH_EXECUTION_HANDOFF_V*.md'))==634;files[hh.relative_to(R).as_posix()]=H(hh);untracked={p.decode()for p in git('ls-files','--others','--exclude-standard','-z').split(b'\0')if p};assert untracked==set(files);size=sum(p.stat().st_size for p in O.iterdir()if p.is_file());assert size<32*1024**2
 e=read(C/'e4_full_capture.json');events=[json.loads(q)for q in e['stdout_and_stderr'].splitlines()];exits=[q['exit_code']for q in events if q['event']=='step_finished'];assert e['native_exit']==0 and exits==[0,0,0,0,0,2]and events[-1]['execution_state']=='COMPLETED';z={'base':base,'old_blobs_preserved':38078,'state_sha256':state,'bindings_checked':bindings,'source_copies':copies,'captures':caps,'largest_sampled_private':peak,'packet_bytes':size,'new_files_sha256':files,'E4_step_exits':exits,'custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED','goal':'ACTIVE_INCOMPLETE'};dump(C/'before_index_seal.json',z);print(json.dumps({k:v for k,v in z.items()if k not in['captures','new_files_sha256']},sort_keys=True))
elif phase=='index':
 b=read(C/'before_index_seal.json');old=tree(base);idx={}
 for rec in git('ls-files','--stage','-z').split(b'\0'):
  if rec:
   hdr,p=rec.split(b'\t',1);m,h,stage=hdr.split();assert stage==b'0';idx[p.decode()]=(m.decode(),h.decode())
 assert all(idx.get(p)==v for p,v in old.items());new=set(idx)-set(old);assert new==set(b['new_files_sha256']);assert not git('diff','--name-only')and not git('ls-files','--others','--exclude-standard');records={}
 for p in sorted(new):
  raw=(R/p).read_bytes();h=sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert idx[p]==('100644',h)and sha256(raw).hexdigest()==b['new_files_sha256'][p];records[p]={'oid':h,'raw_sha256':sha256(raw).hexdigest(),'bytes':len(raw)}
 z=subprocess.run(['git','cat-file','--batch'],input=('\n'.join(records[p]['oid']for p in sorted(new))+'\n').encode(),capture_output=True,check=True);at=0
 for p in sorted(new):
  nl=z.stdout.index(b'\n',at);h,t,n=z.stdout[at:nl].split();n=int(n);raw=z.stdout[nl+1:nl+1+n];assert h.decode()==records[p]['oid']and t==b'blob'and raw==(R/p).read_bytes()and z.stdout[nl+1+n:nl+2+n]==b'\n';at=nl+2+n
 assert at==len(z.stdout);ck=subprocess.run(['git','diff','--cached','--check'],capture_output=True);assert ck.returncode==0,ck.stdout.decode();seal={'base':base,'old_mode_and_blob_ids_preserved':len(old),'new_raw_byte_verified_files':len(new),'index_tree':git('write-tree').decode().strip(),'new_objects':records,'cached_diff_check_exit':ck.returncode,'state_sha256':state};dump(C/'index_seal.json',seal);print(json.dumps({k:v for k,v in seal.items()if k!='new_objects'},sort_keys=True))
elif phase=='after':
 b=read(C/'before_index_seal.json');idx=read(C/'index_seal.json');head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()==base and git('rev-parse','HEAD^{tree}').decode().strip()==idx['index_tree'];assert not git('status','--porcelain=v1');old=tree(base);now=tree('HEAD');assert all(now.get(p)==v for p,v in old.items())and len(old)==38078
 for p,h in b['new_files_sha256'].items():assert H(R/p)==h
 # This observer's own Python invocation names this control directory. Exclude
 # only its known PID; no unrelated process is stopped or omitted by name.
 cmd="Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'python' -and $_.ProcessId -ne "+str(os.getpid())+" -and $_.CommandLine -match 'ToE-Next|intrinsic_source_cutoff_color' } | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress";workers=subprocess.check_output(['powershell','-NoProfile','-Command',cmd]).decode().strip();assert not workers,workers
 z={'commit':head,'parent':base,'tree':idx['index_tree'],'old_blobs_preserved':len(old),'new_files_verified':len(b['new_files_sha256']),'state_sha256':state,'clean_tree':True,'matching_research_workers':0,'observer_only_excluded_pid':os.getpid(),'scientific_acceptance':'NOT_PERFORMED','goal_last_observed':'ACTIVE_INCOMPLETE','no_remote_action':True};dump(C/'after_commit_seal.json',z);(C/'commit_object.txt').open('xb').write(git('cat-file','-p',head));print(json.dumps(z,sort_keys=True))
else:raise ValueError(phase)
