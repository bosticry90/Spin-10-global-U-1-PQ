from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');HERE=ROOT/'calculations/canonical_so10_odd_gauge_local_coverage';CONTROL=Path(__file__).resolve().parent
BASE='1260472a16fddacbd3c14c4b630e5334f9322f3a';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
counts={}
for n in ['preparation.json','validation_preparation.json','control_preparation_v3.json']:
 d=read(HERE/n);counts[n]=len(d['input_sha256'])
 for p,h in d['input_sha256'].items():assert digest(Path(p))==h,p
sources=list(HERE.glob('*.source.txt'));assert len(sources)==14
for p in sources:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes()
assert digest(HERE/'validation_receipt.json')=='3adbe1600754c9b11230e24fe25d4402dfeb696e4663fd212e89a22d1f525ff1'
r=read(HERE/'validation_receipt.json');assert r['status']=='QUALIFIED_COMPLETE_SELECTED_LOCAL_ODD_BOSONIC_FERMION_GAUGE_INSERTION_COVERAGE' and r['actual_selected_odd_local_variation']==0 and not r['physical_scheme_adopted']
assert r['all_chiral_path_positions_compared']==168
for role in ['primary','replay','verify','complete_controls_v3']:
 c=read(HERE/(role+'_capture.json'));assert c==read(CONTROL/(role+'_full_capture.json')) and c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
 rows=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rows)==1 and rows[0]['elapsed_after_imports']<600
 if role=='verify':assert rows[0]==r
 elif role=='complete_controls_v3':assert rows[0]==read(HERE/'control_receipt_v3.json')
 else:
  blob=(HERE/(role+'_tables.json.gz')).read_bytes();assert sha256(blob).hexdigest()==rows[0]['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==rows[0]['tables_sha256']
assert digest(HERE/'control_receipt_v3.json')=='92e87d7988fa5f78b18f8d6a6344b8884c1e70a956b46b636e91b40c4ab35b13'
v=read(HERE/'control_receipt_v3.json');assert v['status']=='QUALIFIED_OGC_CORE_WITH_EXPLICIT_CORRECTED_OMISSION_CONTROLS' and v['Alt4_single_pair_omission_changed_free_words']==[8,8,8] and v['trace4_half_term_omission_changed_free_words']==[4,4] and v['zero_matrix_control_subspaces_reported']==1
assert not v['core_identities_or_physics_changed'] and not v['old_scientific_workers_replayed']
assert read(HERE/'control_controller_failure_v2.json')['execution_state']=='FAILED'
f=read(CONTROL/'control_prelaunch_v2_observed_failure.json');assert f['native_exit']==1 and not f['scientific_worker_launched'] and not f['failure_relabelled_PASS']
assert not (HERE/'control_preparation_v2.json').exists() and not (HERE/'control_receipt_v2.json').exists() and not (HERE/'control_controller_failure_v3.json').exists()
assert (HERE/'check_controls_v3.py').read_text().replace('control_preparation_v3.json','control_preparation_v2.json')==(HERE/'check_controls_v2.py').read_text()
blob=(HERE/'local_odd_coverage_member.json.gz').read_bytes();assert sha256(blob).hexdigest()==r['artifact_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['artifact_raw_sha256']
OLD=CONTROL.with_name('odd-gauge-triangle-insertion-v1-2026-10-23');rd=read(OLD/'readiness_result.json');assert rd['native_exit']==0 and rd['step_exits']==[0,0,0,0,0,2] and rd['historical_custody']=='EXIT2_SEVEN_NOTPASS'

assert not (HERE/'controller_failure.json').exists() and sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
old=(CONTROL/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==33201
files=sorted([p for p in HERE.iterdir() if p.is_file()]+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V568.md'])
for p in files:
 if p.suffix!='.gz':assert b'\r' not in p.read_bytes(),p
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':33201,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'source_copies':14,'binding_counts':counts,'receipt_sha256':digest(HERE/'validation_receipt.json'),'corrected_control_receipt_sha256':digest(HERE/'control_receipt_v3.json'),'original_two_control_count_labels_require_V3_correction':True,'preserved_prelaunch_failure':True,'seal_source_sha256':digest(Path(__file__)),'scientific_acceptance':'NOT_PERFORMED'});print('OGC1_BEFORE_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'raw_index_files':len(files),'scientific_acceptance':'NOT_PERFORMED'});print('OGC1_INDEX_SEALED',len(files),flush=True)
else:
 assert mode=='after';seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==33201+len(files) and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':33201,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'source_copies':14,'binding_counts':counts,'receipt_sha256':digest(HERE/'validation_receipt.json'),'corrected_control_receipt_sha256':digest(HERE/'control_receipt_v3.json'),'original_two_control_count_labels_require_V3_correction':True,'preserved_prelaunch_failure':True,'precommit_and_index_custody_passed':True,'scientific_authority':'34/39_UNCHANGED','historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED','whole_investigation':'INCOMPLETE'}
 save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
