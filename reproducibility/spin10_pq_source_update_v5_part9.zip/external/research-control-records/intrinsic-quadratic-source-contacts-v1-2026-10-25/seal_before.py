from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path.cwd();O=R/'calculations/canonical_so10_intrinsic_quadratic_source_contacts';C=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()=='960241d21e678f5ec5e0688ef596257946033791';assert git('branch','--show-current').decode().strip()=='main'
old=(C/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r','HEAD');assert len(old.splitlines())==37440;assert not git('diff','--name-only','HEAD');assert not git('diff','--cached','--name-only')
state=H(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
seen={};checks=0
for p in O.glob('*preparation*.json'):
 for path,h in json.loads(p.read_bytes()).get('input_sha256',{}).items():
  assert H(Path(path))==h,(p,path);assert path not in seen or seen[path]==h;seen[path]=h;checks+=1
copies=[]
for p in O.glob('*.source.txt'):
 assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes();copies.append(p.name)
fail={'kernel_primary_capture.json':1,'source_flow_capture.json':1,'source_flow_v2_capture.json':1};native=[];peak=0
for p in O.glob('*capture.json'):
 z=json.loads(p.read_bytes());assert z['post_run_observations_qualified']and z['launch']['memory']['available_pagefile']>=350*1024**2
 mx=max(v['private_bytes']for v in z['all_resource_samples']);peak=max(peak,mx);assert mx<=8*1024**3
 if p.name in fail:assert z['exit_code']==fail[p.name]and not z['calculation_completed']and z['execution_state']=='FAILED'
 else:assert z['exit_code']==0 and z['calculation_completed']and z['execution_state']=='COMPLETED'
 native.append({'name':p.name,'exit':z['exit_code'],'state':z['execution_state'],'largest_sample':mx})
for n in ['kernel_controller_failure.json','source_flow_controller_failure.json','source_flow_controller_failure_v2.json','auxiliary_controller_failure.json','auxiliary_controller_failure_v2.json']:assert json.loads((O/n).read_bytes())['execution_state']=='FAILED'
for n in ['color_controller_failure.json','structure_controller_failure.json','source_flow_controller_failure_v3.json','auxiliary_controller_failure_v3.json','group_controller_failure.json','final_review_controller_failure.json']:assert not(O/n).exists()
for n in ['kernel_primary_result.json','kernel_primary_tables.json.gz','source_flow_tables.json.gz','source_flow_validation_receipt.json','source_flow_tables_v2.json.gz','source_flow_validation_receipt_v2.json']:assert not(O/n).exists()
rev=json.loads((O/'final_review_validation_receipt.json').read_bytes());assert rev['group_P_positions_compared_both_ISD_methods']==236160 and rev['replay_quantum_roots_and_explicit_G_source_phases_group_pass']and not rev['full_QAP_E5_A5_or_physical_promotion']
e=json.loads((C/'e4_full_capture.json').read_bytes());ev=[json.loads(l)for l in e['stdout_and_stderr'].splitlines()];exits=[q['exit_code']for q in ev if q['event']=='step_finished'];assert e['native_exit']==0 and exits==[0,0,0,0,0,2]and ev[-1]['execution_state']=='COMPLETED'
hh=R/'docs/RESEARCH_EXECUTION_HANDOFF_V628.md';assert hh.exists();files={p.relative_to(R).as_posix():H(p)for p in O.iterdir()if p.is_file()};files[hh.relative_to(R).as_posix()]=H(hh);size=sum(p.stat().st_size for p in O.iterdir()if p.is_file());assert size<32*1024**2
out={'base':git('rev-parse','HEAD').decode().strip(),'old_blobs_preserved':37440,'state_sha256':state,'old_tree_sha256':H(C/'old_git_tree.txt'),'binding_checks':checks,'unique_bindings':len(seen),'source_copies':copies,'native_captures':native,'max_sampled_private':peak,'packet_bytes':size,'new_files_sha256':files,'E4_step_exits':exits,'custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED','goal':'ACTIVE_INCOMPLETE'}
with(C/'before_index_seal.json').open('xb')as f:f.write((json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode())
print(json.dumps({k:v for k,v in out.items()if k not in ['source_copies','native_captures','new_files_sha256']},sort_keys=True))
