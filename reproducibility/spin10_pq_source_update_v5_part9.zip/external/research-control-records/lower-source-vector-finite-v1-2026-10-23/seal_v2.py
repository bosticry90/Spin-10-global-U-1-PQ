from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');CONTROL=Path(__file__).resolve().parent;HERE=ROOT/'calculations/canonical_so10_lower_source_vector_finite'
BASE='e6aeb51f33fd539c9eadda19b59e986415f781ec';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';NOLD=32221
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
old=(CONTROL/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==NOLD
receipt=digest(HERE/'validation_receipt_v2.json');assert receipt=='62c5ed150391a88f9409b27acbdac7d9d95dfad4dc0d2b647675b996a2d12ccf'
r=read(HERE/'validation_receipt_v2.json');assert r['status']=='QUALIFIED_LOWER_AUXILIARY_SOURCE_VECTOR_FINITE_FAMILY' and r['complete_unintegrated_positions_per_route']==80 and r['old_UV_unit_positions_compared']==160
assert r['complete_fixed_color_and_current_tensor_zero'] and r['old_UV_YM_equals_three_ghost_plus_aux']=={'primary':True,'replay':True}
assert r['original_nonzero_fixed_expectation']=='REFUTED_ORIGINAL_GATE_FAILED_PRESERVED' and r['finite_color_roundtrip_positions']==346275 and r['homogeneous_H_covariance_matrix_checks']==1620
assert r['fixed_family_omission_nonzero_counts']=={'YM_B':1940,'aux_B':526,'ghost_B':1940} and r['new_color_nonzero_counts']=={'chi4':{'A':0,'B':1680},'log3over2':{'A':0,'B':1680},'fixed':{'A':0,'B':0}}
assert r['xi_factored_out_exactly_once'] and r['bosonic_overall_factor']=='g10^2*xi/(16*pi^2)' and r['matter_overall_factor']=='-I*g10^3*xi/(16*pi^2)'
assert r['scientific_acceptance']=='NOT_PERFORMED' and r['authority']=='34/39'
assert not any(r[k] for k in ['new_model_color_paths_or_loop_integrals_recomputed','coupled_cancellation_claimed','physical_scheme_adopted','quantum_coefficient_fitted','scientific_authority_changed','full_QAP_measure_phase_massiveC1_E5A5_unification_qualified'])
counts={};cache={}
for n,expected in [('preparation.json',1036),('validation_preparation.json',1044),('validation_preparation_v2.json',1055)]:
 bd=read(HERE/n)['input_sha256'];counts[n]=len(bd);assert len(bd)==expected
 for p,h in bd.items():
  if p not in cache:cache[p]=digest(Path(p))
  assert cache[p]==h,p
assert len(list(HERE.glob('*.source.txt')))==11
for p in HERE.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes() and b'\r' not in p.read_bytes()
for p in HERE.glob('*.py'):compile(p.read_bytes(),str(p),'exec')
for p in HERE.glob('*.md'):assert b'\r' not in p.read_bytes()
assert (HERE/'controller_failure.json').exists() and not (HERE/'controller_failure_v2.json').exists() and not (HERE/'validation_receipt.json').exists()
resources={}
for name in ['primary','replay','verify','verify_v2']:
 p=HERE/(name+'_capture.json');c=read(p);assert p.read_bytes()==(CONTROL/(name+'_full_capture.json')).read_bytes()
 ss=c['all_resource_samples'];assert ss and c['launch']['creation_after_observation'] and c['launch']['memory']['available_pagefile']>=350*1024**2
 maximum=max(v['private_bytes'] for v in ss);assert maximum<=8*1024**3 and c['post_run_observations_qualified']
 if name=='verify':assert c['exit_code']==1 and c['execution_state']=='FAILED' and not c['calculation_completed'] and 'AssertionError' in c['stdout_and_stderr']
 else:
  assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed']
  out=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(out)==1;out=out[0];assert out['elapsed_after_imports']<600
  if name=='verify_v2':assert out==r
  else:
   b=(HERE/(name+'_tables.json.gz')).read_bytes();assert sha256(b).hexdigest()==out['packed_sha256'] and sha256(gzip.decompress(b)).hexdigest()==out['tables_sha256']
   if name!='diagnostic':assert out==read(HERE/(name+'_result.json'))
 resources[name]={'exit':c['exit_code'],'execution_state':c['execution_state'],'samples':len(ss),'sampled_private_maximum':maximum,'peak_memory_claimed':False}
for name in ['preparation']:
 pc=read(HERE/(name+'_capture.json'));assert pc==read(CONTROL/(name+'_full_capture.json')) and pc['native_exit']==0 and not pc['scientific_calculations_executed']
assert read(HERE/'controller_failure.json')['last_role']=='verify' and not read(HERE/'controller_failure.json')['failure_relabelled_PASS']
events=[json.loads(v) for v in (CONTROL/'readiness.jsonl').read_text(encoding='utf-8').splitlines()];steps=[v for v in events if v['event']=='step_finished']
assert [v['exit_code'] for v in steps]==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
fresh=read(CONTROL/'readiness_result.json');assert fresh['fresh_command'] and fresh['native_exit']==0 and not fresh['scientific_replay_requested']
for n in ['prelaunch_preflight.json','prelaunch_v2_preflight.json']:
 pre=read(CONTROL/n);assert pre['git_HEAD']==BASE and pre['state_sha256']==STATE and pre['files_written']==0 and pre['scientific_acceptance']=='NOT_PERFORMED'
files=sorted(p for p in HERE.iterdir() if p.is_file())+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V542.md'];assert len(files)==41 and sum(p.stat().st_size for p in files)<16*1024**2
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':NOLD,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'receipt_sha256':receipt,'state_sha256':STATE,'resources':resources,'manifest_counts':counts,'seal_source_sha256':digest(Path(__file__)),'scientific_acceptance':'NOT_PERFORMED'});print('PRECOMMIT_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'before_seal_sha256':digest(CONTROL/'before_commit_seal.json'),'raw_index_files':len(files)});print('RAW_INDEX_MATCH',len(files),flush=True)
else:
 assert mode=='after';seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==len(prior)+len(files) and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':NOLD,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'receipt_sha256':receipt,'state_sha256':STATE,'scientific_authority':'34/39_UNCHANGED','scientific_acceptance':'NOT_PERFORMED','original_nonzero_fixed_expectation':'REFUTED_GATE_FAILED_PRESERVED','actual_fixed_tensor_zero_qualified':True,'coupled_cancellation_claimed':False,'physical_scheme_adopted':False,'historical_custody':'EXIT2_SEVEN_NOTPASS','whole_investigation':'INCOMPLETE'}
 save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
