from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');CONTROL=Path(__file__).resolve().parent;HERE=ROOT/'calculations/canonical_so10_source_vector_finite_units'
BASE='37cd8455b933f505d28659c5f3ca0fd168192cad';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';NOLD=32089
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
old=(CONTROL/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==NOLD
receipt=digest(HERE/'validation_receipt_v2.json');assert receipt=='153afb0f1ea65ebbdb7048f5a4b1d30f96ed408e2f50cde15e34e1bd3f3cc130'
r=read(HERE/'validation_receipt_v2.json');assert r['status']=='QUALIFIED_ORDINARY_SOURCE_VECTOR_FINITE_UNITS' and r['pointwise_positions_per_route']==128 and r['old_UV_positions_compared']==256 and r['unit_variants']==8
assert r['all_complete_kernels_and_zero_complements_match'] and r['common_chi4_symbolic'] and r['triangle_heat_shift']=='log(3/2)' and r['FF_current_sum_remainder']==0
assert r['scientific_acceptance']=='NOT_PERFORMED' and r['authority']=='34/39'
assert not any(r[k] for k in ['actual_Spin10_color_coefficients_computed','quantum_coefficient_fitted','physical_scheme_adopted','scientific_authority_changed','full_coupled_restoration_QAP_measure_phase_massiveC1_E5A5_unification_qualified'])
cc=read(HERE/'cancellation_classification.json');assert cc['execution_state']=='CANCELED' and cc['scientific_disposition']=='INCOMPLETE_ENGINEERING_REASSESSMENT' and not cc['resource_limit_exhausted'] and not cc['failure_relabelled_PASS'] and not cc['mathematical_requirements_changed']
counts={};cache={}
for n,expected in [('preparation.json',739),('preparation_v2.json',760),('validation_preparation_v2.json',768)]:
 bd=read(HERE/n)['input_sha256'];counts[n]=len(bd);assert len(bd)==expected
 for p,h in bd.items():
  if p not in cache:cache[p]=digest(Path(p))
  assert cache[p]==h,p
assert len(list(HERE.glob('*.source.txt')))==15
for p in HERE.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes() and b'\r' not in p.read_bytes()
for p in HERE.glob('*.py'):compile(p.read_bytes(),str(p),'exec')
for p in HERE.glob('*.md'):assert b'\r' not in p.read_bytes()
assert (HERE/'controller_failure.json').exists() and not (HERE/'controller_failure_v2.json').exists() and not (HERE/'validation_receipt.json').exists()
resources={}
for name in ['primary','primary_v2','replay_v2','verify_v2']:
 p=HERE/(name+'_capture.json');c=read(p);assert p.read_bytes()==(CONTROL/(name+'_full_capture.json')).read_bytes()
 ss=c['all_resource_samples'];assert ss and c['launch']['creation_after_observation'] and c['launch']['memory']['available_pagefile']>=350*1024**2
 maximum=max(v['private_bytes'] for v in ss);assert maximum<=8*1024**3 and c['post_run_observations_qualified']
 if name=='primary':assert c['exit_code']==4294967295 and c['execution_state']=='FAILED' and not c['calculation_completed'] and not (HERE/'primary_tables.json.gz').exists()
 else:
  assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed']
  out=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(out)==1;out=out[0];assert out['elapsed_after_imports']<600
  if name=='verify_v2':assert out==r
  else:
   b=(HERE/(name+'_tables.json.gz')).read_bytes();assert sha256(b).hexdigest()==out['packed_sha256'] and sha256(gzip.decompress(b)).hexdigest()==out['tables_sha256']
   if name!='diagnostic':assert out==read(HERE/(name+'_result.json'))
 resources[name]={'exit':c['exit_code'],'execution_state':c['execution_state'],'samples':len(ss),'sampled_private_maximum':maximum,'peak_memory_claimed':False}
for name in ['preparation','preparation_v2']:
 pc=read(HERE/(name+'_capture.json'));assert pc==read(CONTROL/(name+'_full_capture.json')) and pc['native_exit']==0 and not pc['scientific_calculations_executed']
assert read(HERE/'controller_failure.json')['last_role']=='primary' and not read(HERE/'controller_failure.json')['failure_relabelled_PASS']
events=[json.loads(v) for v in (CONTROL/'readiness.jsonl').read_text(encoding='utf-8').splitlines()];steps=[v for v in events if v['event']=='step_finished']
assert [v['exit_code'] for v in steps]==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
reuse=read(CONTROL/'readiness_reuse.json');assert not reuse['fresh_readiness_command_here'] and reuse['source_command_executed_earlier_this_goal_turn'] and reuse['fresh_byte_preflight_here']
for p,h in reuse['source_sha256'].items():assert digest(Path(p))==h
for n in ['prelaunch_preflight.json','prelaunch_v2_preflight.json']:
 pre=read(CONTROL/n);assert pre['git_HEAD']==BASE and pre['state_sha256']==STATE and pre['files_written']==0 and pre['scientific_acceptance']=='NOT_PERFORMED'
files=sorted(p for p in HERE.iterdir() if p.is_file())+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V539.md'];assert len(files)==51 and sum(p.stat().st_size for p in files)<16*1024**2
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':NOLD,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'receipt_sha256':receipt,'state_sha256':STATE,'resources':resources,'manifest_counts':counts,'seal_source_sha256':digest(Path(__file__)),'scientific_acceptance':'NOT_PERFORMED'});print('PRECOMMIT_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'before_seal_sha256':digest(CONTROL/'before_commit_seal.json'),'raw_index_files':len(files)});print('RAW_INDEX_MATCH',len(files),flush=True)
else:
 assert mode=='after';seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==len(prior)+len(files) and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':NOLD,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'receipt_sha256':receipt,'state_sha256':STATE,'scientific_authority':'34/39_UNCHANGED','scientific_acceptance':'NOT_PERFORMED','original_primary':'CANCELED_INCOMPLETE_NATIVE_FAILURE_PRESERVED','corrected_finite_units_qualified':True,'actual_Spin10_color_coefficients_computed':False,'physical_scheme_adopted':False,'historical_custody':'EXIT2_SEVEN_NOTPASS','whole_investigation':'INCOMPLETE'}
 save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
