from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');HERE=ROOT/'calculations/canonical_so10_ghost_vertex_order_reconciliation';CONTROL=Path(__file__).resolve().parent
BASE='89e6dc95bb11dda636517d39ef7e1e7e2d84a218';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
counts={}
for n in ['preparation.json','validation_preparation.json','preparation_v2.json']:
 d=read(HERE/n);counts[n]=len(d['input_sha256'])
 for p,h in d['input_sha256'].items():assert digest(Path(p))==h,p
assert counts=={'preparation.json':140,'validation_preparation.json':148,'preparation_v2.json':173}
copies=list(HERE.glob('*.source.txt'));assert len(copies)==12
for p in copies:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes()
receipts={'validation_receipt.json':'9668b172b67615880310262d5bf5ef33182126d7834fd054ad3164228335c4ce','finite_receipt_v2.json':'4a6ebf060177d8dceaea4b145aae923951e93a135ba0782a04354d0de5536984'}
for n,h in receipts.items():assert digest(HERE/n)==h
r=read(HERE/'validation_receipt.json');f=read(HERE/'finite_receipt_v2.json')
assert r['status']=='QUALIFIED_ACTION_ORDER_CORRECTION_SELECTED_VACUUM_COEFFICIENTS_AND_POLE_COMPATIBILITY' and r['pole_Slavnov_image_zero'] and r['isolated_fixed_Cv_candidate_c_h_pass']
assert r['corrected_full_source_compact_identity'] and r['old_GVC_VSC_orbit_interpretation_superseded'] and r['old_source_compact_remainder_nonzero']==424
assert r['GVC_coefficient_positions_compared']==138240 and r['source_coefficient_positions_compared']==44280 and r['Euler_coefficient_positions_compared']==138240
assert not r['complete_heat_response_or_counterterm_family_qualified'] and not f['new_complete_heat_trace_qualified'] and not f['uncomputed_root_complement_independently_zero_proved'] and f['n2_group_target_positions_checked']==46080
assert len(f['dependency_manifests'])==13 and sum(x['input_bindings_examined'] for x in f['dependency_manifests'])==6741 and all(not x['later_GVC_VSC_bindings'] for x in f['dependency_manifests'])
for x in f['models']:
 assert x['holo_algebraic_target_minus_direct_n2_remainder_nonzero']==x['anti_algebraic_target_minus_direct_n2_remainder_nonzero']==0
 if x['carrier']=='126':
  for side in ['holo','anti']:
   assert x['compact_finite'][side+'_chi4']['ratio']=='0' and x['compact_finite'][side+'_fixed']['ratio']=='-1/2' and x['compact_finite'][side+'_log3over2']['ratio']=='-17/25' and x['compact_n2_heat'][side]['ratio']=='17/25'
for role in ['primary','replay','verify','finite_v2']:
 c=read(HERE/(role+'_capture.json'));assert c==read(CONTROL/(role+'_full_capture.json'))
 assert c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3
 rows=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rows)==1 and rows[0]['elapsed_after_imports']<600
 if role in ['primary','replay']:
  b=(HERE/(role+'_tables.json.gz')).read_bytes();assert sha256(b).hexdigest()==rows[0]['packed_sha256'] and sha256(gzip.decompress(b)).hexdigest()==rows[0]['tables_sha256']
 else:assert rows[0]==read(HERE/('validation_receipt.json' if role=='verify' else 'finite_receipt_v2.json'))
for n,rec in [('order_corrected_vacuum_family.json.gz',r),('finite_image_review_v2.json.gz',f)]:
 b=(HERE/n).read_bytes();assert sha256(b).hexdigest()==rec['artifact_sha256'] and sha256(gzip.decompress(b)).hexdigest()==rec['artifact_raw_sha256']
for suffix in ['', '_v2']:
 c=read(HERE/('preparation'+suffix+'_capture.json'));assert c['native_exit']==0 and c==read(CONTROL/('preparation'+suffix+'_full_capture.json'))
assert not any((HERE/n).exists() for n in ['controller_failure.json','controller_failure_v2.json'])
assert read(CONTROL/'readiness_native_exit.json')['native_exit']==0 and read(CONTROL/'readiness_native_exit.json')['step_exits']==[0,0,0,0,0,2]
events=[json.loads(x) for x in (CONTROL/'readiness.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()];steps=[x for x in events if x['event']=='step_finished'];assert [x['exit_code'] for x in steps]==[0,0,0,0,0,2]
custody=next(x for x in steps if x['step']=='historical_custody');assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in custody['stdout'] and events[-1]['execution_state']=='COMPLETED'
assert sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
old=(CONTROL/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==33616
files=sorted([p for p in HERE.iterdir() if p.is_file()]+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V577.md'])
for p in files:
 if p.suffix!='.gz':assert b'\r' not in p.read_bytes(),p
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':33616,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'source_copies':12,'binding_counts':counts,'receipt_sha256':receipts,'seal_source_sha256':digest(Path(__file__)),'readiness_sha256':{n:digest(CONTROL/n) for n in ['readiness.py','readiness.jsonl','readiness_stderr.txt','readiness_native_exit.json']},'scientific_acceptance':'NOT_PERFORMED','old_interpretation_superseded_new_evidence_only':True});print('GOR1_BEFORE_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'raw_index_files':len(files),'scientific_acceptance':'NOT_PERFORMED'});print('GOR1_INDEX_SEALED',len(files),flush=True)
else:
 assert mode=='after';seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==33616+len(files) and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 for n,h in seal['readiness_sha256'].items():assert digest(CONTROL/n)==h
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':33616,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'source_copies':12,'binding_counts':counts,'receipt_sha256':receipts,'precommit_and_index_custody_passed':True,'scientific_authority':'34/39_UNCHANGED','historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED','whole_investigation':'INCOMPLETE','old_interpretation_superseded_new_evidence_only':True,'old_records_and_failures_preserved':True};save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
