from pathlib import Path
from hashlib import sha256
import json,gzip
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');HERE=ROOT/'calculations/canonical_so10_ghost_vertex_order_reconciliation';read=lambda p:json.loads(p.read_bytes())
out={}
for role in ['primary','replay','verify','finite_v2']:
 c=read(HERE/(role+'_capture.json'));rows=[json.loads(x[7:]) for x in c['stdout_and_stderr'].splitlines() if x.startswith('RESULT ')];assert len(rows)==1
 out[role]={'exit':c['exit_code'],'seconds':rows[0]['elapsed_after_imports'],'samples':len(c['all_resource_samples']),'max_sampled_private':max(x['private_bytes'] for x in c['all_resource_samples'])}
out['receipts']={n:sha256((HERE/n).read_bytes()).hexdigest() for n in ['validation_receipt.json','finite_receipt_v2.json']}
out['bindings']={n:len(read(HERE/n)['input_sha256']) for n in ['preparation.json','validation_preparation.json','preparation_v2.json']}
out['source_copies']=len(list(HERE.glob('*.source.txt')));out['packet_bytes_before_reports']=sum(x.stat().st_size for x in HERE.iterdir() if x.is_file())
p=json.loads(gzip.decompress((HERE/'primary_tables.json.gz').read_bytes()));r=json.loads(gzip.decompress((HERE/'replay_tables.json.gz').read_bytes()));out['literal_ordinary_rows']=p['literal_ordinary_rows'];out['changed_old_vertex_positions']=p['old_vertex_sign_changed_nonzero_positions'];out['Euler_product_rows_mu0']=r['Euler_product_rows_mu0']
print(json.dumps(out,sort_keys=True),flush=True)
