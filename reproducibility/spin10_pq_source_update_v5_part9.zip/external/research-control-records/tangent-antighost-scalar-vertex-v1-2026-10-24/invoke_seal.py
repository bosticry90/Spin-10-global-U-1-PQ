from pathlib import Path
import sys,subprocess,json
H=Path(__file__).resolve().parent;mode=sys.argv[1]
r=subprocess.run([sys.executable,'-B',str(H/'seal.py'),mode],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8')
with (H/(mode+'_seal_full_capture.json')).open('xb') as f:f.write((json.dumps({'native_exit':r.returncode,'stdout_and_stderr':r.stdout,'scientific_acceptance':'NOT_PERFORMED'},sort_keys=True)+'\n').encode())
print(r.stdout,flush=True);assert r.returncode==0
