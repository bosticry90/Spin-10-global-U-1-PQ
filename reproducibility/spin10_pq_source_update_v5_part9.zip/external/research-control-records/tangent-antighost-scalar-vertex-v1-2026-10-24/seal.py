from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');H=ROOT/'calculations/canonical_so10_tangent_antighost_scalar_vertex';C=Path(__file__).resolve().parent;BASE='b16acf055762b179bc0a3838b07e1f01517525c0';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (C/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
expected={'preparation.json':47,'preparation_v2.json':65,'validation_preparation_v2.json':73,'preparation_v3.json':95,'validation_preparation_v3.json':103}
for n,k in expected.items():
 d=read(H/n);assert len(d['input_sha256'])==k
 for p,h in d['input_sha256'].items():assert digest(Path(p))==h,p
copies=list(H.glob('*.source.txt'));assert len(copies)==22
for p in copies:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes()
receipts={'validation_receipt_v2.json':'7b2936a6113ccd9edcdd66fa3bd5a7d70a6810683fa42d72159d64dd57b63a21','vacuum_receipt_v3.json':'bba7a271ceaa92158f887241bc36e1b65dfdf517ff18e3e7a7a66ebd55394cd7'}
for n,h in receipts.items():assert digest(H/n)==h
r,v=read(H/'validation_receipt_v2.json'),read(H/'vacuum_receipt_v3.json')
assert r['status']=='QUALIFIED_SELECTED_PROPER_TANGENT_ANTIGHOST_SCALAR_RELATIVE_VERTEX' and r['nonzero_by_class']=={'ordinary_H':36320,'ordinary_M':0,'auxiliary':17658}
assert r['ordered_words']=={'ordinary':6,'auxiliary':6} and r['block_diagonal_positions_compared']==9021240 and r['offblock_zeros_by_scalar_types']==5502600 and r['full_typed_position_scope']==14523840
assert r['universal_phases']==['-1','1'] and r['no_dimensional_angular_jet'] and r['raw_Green_longitudinal_slots_checked']==8100
assert r['controls']['full_projector_changed_positions']==0 and r['controls']['unit_width_changed_positions']==36320 and r['controls']['ordinary_trace_changed_universal_fixtures']==4
assert v['status']=='QUALIFIED_COMPLETE_SELECTED_AFFINE_TANGENT_GHOST_VACUUM_RELATIVE_MEMBER' and v['support_counts']=={'bubble':4,'triangle':6,'JL_new':0}
assert v['coefficient_counts']=={'ordinary_H':0,'ordinary_M':0,'auxiliary':448,'extra_bubble':448,'extra_triangle':0} and v['complete_member_nonzero_positions']==448
assert v['full_GF_scalar_reconstruction_positions']==664200 and v['nonlinear_antighost_orbit_term_retained_then_projected_zero'] and v['JL_h_v_qualified_zero_in_scope']
assert v['bubble_heat_length']==4 and v['triangle_heat_length']==6 and v['wrong_common_heat_length_changed_positions']==448
assert not r['common_full_h_family_qualified'] and not r['full_QAP_measure_phase_E5A5_qualified'] and not r['physical_scheme_adopted'] and not v['common_full_h_QAP_family_qualified'] and not v['full_E5A5_qualified'] and not v['physical_scheme_adopted']
roles=['primary','primary_v2','replay_v2','verify_v2','vacuum_primary_v3','vacuum_replay_v3','vacuum_verify_v3']
for role in roles:
 c=read(H/(role+'_capture.json'));assert c==read(C/(role+'_full_capture.json')) and c['all_resource_samples']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and max(x['private_bytes'] for x in c['all_resource_samples'])<=8*1024**3
 if role=='primary':
  assert c['exit_code']==1 and "UNCLASSIFIED_GF_SOURCE_TARGET', ['B', 'B', 'C', 'a']" in c['stdout_and_stderr'];continue
 assert c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
 rr=[json.loads(z[7:]) for z in c['stdout_and_stderr'].splitlines() if z.startswith('RESULT ')];assert len(rr)==1 and rr[0]['elapsed_after_imports']<600
 if role=='verify_v2':assert rr[0]==r
 elif role=='vacuum_verify_v3':assert rr[0]==v
 else:
  b=(H/(role+'_tables.json.gz')).read_bytes();assert sha256(b).hexdigest()==rr[0]['packed_sha256'] and sha256(gzip.decompress(b)).hexdigest()==rr[0]['tables_sha256']
for n,d in [('selected_tangent_antighost_scalar_vertex_v2.json.gz',r),('selected_affine_tangent_vacuum_v3.json.gz',v)]:
 b=(H/n).read_bytes();assert sha256(b).hexdigest()==d['artifact_sha256'] and sha256(gzip.decompress(b)).hexdigest()==d['artifact_raw_sha256']
assert read(H/'controller_failure.json')['last_role']=='primary'
assert not any((H/n).exists() for n in ['controller_failure_v2.json','controller_failure_v3.json','primary_tables.json.gz','replay_capture.json','verify_capture.json','validation_preparation.json','validation_receipt.json','selected_tangent_antighost_scalar_vertex.json.gz'])
for suffix in ['','_v2','_v3']:
 c=read(H/('preparation'+suffix+'_capture.json'));assert c['native_exit']==0 and c==read(C/('preparation'+suffix+'_full_capture.json'))
assert sum(p.stat().st_size for p in H.iterdir() if p.is_file())<16*1024**2
assert read(C/'readiness_native_exit.json')['native_exit']==0 and read(C/'readiness_native_exit.json')['step_exits']==[0,0,0,0,0,2]
ev=[json.loads(z) for z in (C/'readiness.jsonl').read_text(encoding='utf-8').splitlines() if z.strip()];steps=[x for x in ev if x['event']=='step_finished'];assert [x['exit_code'] for x in steps]==[0,0,0,0,0,2]
assert 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in next(x for x in steps if x['step']=='historical_custody')['stdout'] and ev[-1]['execution_state']=='COMPLETED'
old=(C/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==33819
files=sorted([p for p in H.iterdir() if p.is_file()]+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V580.md'])
for p in files:
 if p.suffix!='.gz':assert b'\r' not in p.read_bytes(),p
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':33819,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'binding_counts':expected,'source_copies':22,'receipt_sha256':receipts,'failed_original_primary_preserved':True,'scientific_acceptance':'NOT_PERFORMED','seal_source_sha256':digest(Path(__file__)),'readiness_sha256':{n:digest(C/n) for n in ['readiness.py','readiness.jsonl','readiness_stderr.txt','readiness_native_exit.json']}});print('TAV1_BEFORE_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(C/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'raw_index_files':len(files),'scientific_acceptance':'NOT_PERFORMED'});print('TAV1_INDEX_SEALED',len(files),flush=True)
else:
 assert mode=='after';seal=read(C/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 mapping=lambda bb:{v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in bb.splitlines()};prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==33819+len(files) and all(current[n]==d for n,d in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 for n,h in seal['readiness_sha256'].items():assert digest(C/n)==h
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':33819,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'source_copies':22,'binding_counts':expected,'receipt_sha256':receipts,'precommit_and_index_custody_passed':True,'scientific_authority':'34/39_UNCHANGED','historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED','whole_investigation':'INCOMPLETE','failed_original_primary_and_old_records_preserved':True};save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
