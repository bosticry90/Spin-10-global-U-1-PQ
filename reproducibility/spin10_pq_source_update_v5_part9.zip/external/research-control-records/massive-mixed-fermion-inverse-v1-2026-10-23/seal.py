from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');HERE=ROOT/'calculations/canonical_so10_massive_mixed_fermion_inverse';CONTROL=Path(__file__).resolve().parent
BASE='d2c6f4f72ad7adccc3b13749990410edecf3424e';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
counts={}
for n in ['preparation.json','validation_preparation.json','neutral_support_preparation.json','neutral_support_preparation_v2.json']:
 d=read(HERE/n);counts[n]=len(d['input_sha256'])
 for p,h in d['input_sha256'].items():assert digest(Path(p))==h,p
sources=list(HERE.glob('*.source.txt'));assert len(sources)==16
for p in sources:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes()
assert digest(HERE/'validation_receipt.json')=='4a59fceecdcf9c61fa046b576ff73be8e2e46030498edb33d2984f6d49944b47'
r=read(HERE/'validation_receipt.json');assert r['status']=='QUALIFIED_EXACT_CONSTANT_MASS_SMA_MIXED_INVERSE_AND_LIMITS_WITH_AUXILIARY_IR_DIAGNOSTIC' and r['no_inverse_M_or_bar_p2_required'] and not r['physical_scheme_or_mass_spectrum_adopted']
for role in ['primary','replay','verify']:
 c=read(HERE/(role+'_capture.json'));assert c==read(CONTROL/(role+'_full_capture.json')) and c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
 rows=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rows)==1 and rows[0]['elapsed_after_imports']<600
 if role=='verify':assert rows[0]==r
 else:
  b=(HERE/(role+'_tables.json.gz')).read_bytes();assert sha256(b).hexdigest()==rows[0]['packed_sha256'] and sha256(gzip.decompress(b)).hexdigest()==rows[0]['tables_sha256']

for role,n in [('neutral_support','neutral_support_receipt.json'),('neutral_support_v2','neutral_support_v2_receipt.json')]:
 c=read(HERE/(role+'_capture.json'));assert c==read(CONTROL/(role+'_full_capture.json')) and c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
 rows=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rows)==1 and rows[0]==read(HERE/n) and rows[0]['elapsed_after_imports']<600
assert digest(HERE/'neutral_support_receipt.json')=='68c3ad1e500841a6173cba1748d221f3666ab96a4003cc6193588f3057717142' and digest(HERE/'neutral_support_v2_receipt.json')=='711c806c1a8e26642d368eab7022e5db0b805f99b1d1b8c30bd3b828f6fc59b7'
assert read(HERE/'neutral_support_receipt.json')['pure_broken_control_seed']==0 and read(HERE/'neutral_support_v2_receipt.json')['neutral_to_H_charged_transition_positions']==2
assert not (HERE/'neutral_controller_failure.json').exists() and not (HERE/'neutral_controller_failure_v2.json').exists()
b=(HERE/'massive_inverse_recipe.json.gz').read_bytes();assert sha256(b).hexdigest()==r['recipe_sha256'] and sha256(gzip.decompress(b)).hexdigest()==r['recipe_raw_sha256']
recipe=json.loads(gzip.decompress(b));assert recipe['all_denominators_on_right'] and not recipe['physical_scheme_or_spectrum_adopted'] and not recipe['uniform_Dirac_IR_bound_or_analytic_dimensional_domain_proved']

assert not (HERE/'controller_failure.json').exists() and sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
old=(CONTROL/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==32971
files=sorted([p for p in HERE.iterdir() if p.is_file()]+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V562.md'])
for p in files:
 if p.suffix!='.gz':assert b'\r' not in p.read_bytes(),p
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':32971,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'source_copies':16,'binding_counts':counts,'receipt_sha256':digest(HERE/'validation_receipt.json'),'seal_source_sha256':digest(Path(__file__)),'scientific_acceptance':'NOT_PERFORMED'});print('MMI1_BEFORE_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'raw_index_files':len(files),'scientific_acceptance':'NOT_PERFORMED'});print('MMI1_INDEX_SEALED',len(files),flush=True)
else:
 assert mode=='after';seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==32971+len(files) and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':32971,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'source_copies':16,'binding_counts':counts,'receipt_sha256':digest(HERE/'validation_receipt.json'),'precommit_and_index_custody_passed':True,'scientific_authority':'34/39_UNCHANGED','historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED','whole_investigation':'INCOMPLETE'}
 save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
