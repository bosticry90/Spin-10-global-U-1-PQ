"""MSP1 byte/native capture seal. It performs no scientific promotion."""
from pathlib import Path
from hashlib import sha256
import ast,gzip,json,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');CONTROL=Path(__file__).resolve().parent;HERE=ROOT/'calculations/canonical_so10_matter_source_primitive'
BASE='77532dba14bc19e09dad3083dcf04d6d790df59f';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';NOLD=31386
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)
digest=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
old=(CONTROL/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==NOLD
r=read(HERE/'validation_receipt.json');receipt=digest(HERE/'validation_receipt.json')
assert receipt=='c0e178079368b7f841ef0c44d2b76035a289a761dc8d427b4a6a4732119638c2'
assert r['status']=='QUALIFIED_EXPLICIT_MATTER_SOURCE_PRIMITIVE_TEST' and r['scientific_acceptance']=='NOT_PERFORMED' and r['authority']=='34/39'
assert r['disposition']=='CONSTRUCTED_SELECTED_LOCAL_SOURCE_PRIMITIVE' and r['adjoint_Casimir']=='8'
assert r['source_image_remainders']=={'3':{'left_image':0,'right_image':0},'4':{'left_image':0,'right_image':0}}
assert r['H_covariance_nonzero_blocks']=={'3':0,'4':0} and r['no_inverse_physical_parameter'] and r['real_polynomial_H_covariant'] and r['Euler_companion_density_retained']
assert not any(r[k] for k in ['scientific_authority_changed','physical_scheme_adopted','external_elementary_qK_changed','full_cPP_quantum_matching_or_QAP_or_Slavnov_restoration_qualified'])
counts={};cache={}
for n in ['preparation.json','validation_preparation.json']:
 bd=read(HERE/n)['input_sha256'];counts[n]=len(bd)
 for p,h in bd.items():
  if p not in cache:cache[p]=digest(Path(p))
  assert cache[p]==h,p
assert counts=={'preparation.json':49,'validation_preparation.json':56}
assert len(list(HERE.glob('*.source.txt')))==8
for p in HERE.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes() and b'\r' not in p.read_bytes()
for p in HERE.glob('*.py'):compile(p.read_bytes(),str(p),'exec')
for p in HERE.glob('*.md'):assert b'\r' not in p.read_bytes()
assert not (HERE/'controller_failure.json').exists() and sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
resources={}
for name in ['primary','replay','verify']:
 p=HERE/(name+'_capture.json');c=read(p);assert p.read_bytes()==(CONTROL/(name+'_full_capture.json')).read_bytes()
 ss=c['all_resource_samples'];assert ss and c['launch']['creation_after_observation'] and c['launch']['memory']['available_pagefile']>=350*1024**2
 maximum=max(v['private_bytes'] for v in ss);assert maximum<=8*1024**3
 assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
 out=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(out)==1;out=out[0];assert out['elapsed_after_imports']<600
 assert out==read(HERE/('validation_receipt.json' if name=='verify' else name+'_result.json'))
 if name!='verify':
  b=(HERE/(name+'_tables.json.gz')).read_bytes();assert sha256(b).hexdigest()==out['packed_sha256'] and sha256(gzip.decompress(b)).hexdigest()==out['tables_sha256']
 resources[name]={'exit':c['exit_code'],'samples':len(ss),'sampled_private_maximum':maximum,'peak_memory_claimed':False}
events=[json.loads(v) for v in (CONTROL/'readiness.jsonl').read_text().splitlines()];steps=[v for v in events if v['event']=='step_finished']
assert [v['exit_code'] for v in steps]==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested'] and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
ready=read(CONTROL/'readiness_result.json');assert ready['fresh_readiness_command_in_this_goal_turn'] and ready['native_exit']==0 and not ready['fresh_historical_science_requested'] and ready['step_exits']==[0,0,0,0,0,2]
assert ready['command'][1:]==['-B',str(ROOT/'tools/research_check.py'),'e4']
assert r['counts']=={'3':{'left_image':8768,'left_primitive':592,'right_image':8768,'right_primitive':592,'scalar_primitive_coefficients':105},'4':{'left_image':10368,'left_primitive':720,'right_image':10368,'right_primitive':720,'scalar_primitive_coefficients':105}}

files=sorted(p for p in HERE.iterdir() if p.is_file())+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V522.md'];assert len(files)==28
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':NOLD,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'receipt_sha256':receipt,'state_sha256':STATE,'resources':resources,'manifest_counts':counts,'seal_source_sha256':digest(Path(__file__)),'readiness_sha256':digest(CONTROL/'readiness.jsonl'),'scientific_acceptance':'NOT_PERFORMED'})
 print('PRECOMMIT_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'before_seal_sha256':digest(CONTROL/'before_commit_seal.json'),'raw_index_files':len(files)});print('RAW_INDEX_MATCH',len(files),flush=True)
else:
 assert mode=='after';seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==len(prior)+len(files) and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':NOLD,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'receipt_sha256':receipt,'state_sha256':STATE,'scientific_authority':'34/39_UNCHANGED','scientific_acceptance':'NOT_PERFORMED','qualified_scope':r['status'],'selected_source_primitive_constructed':True,'new_quantum_integrals':0,'physical_scheme_adopted':False,'readiness_execution':'FRESH_COMMAND_THIS_GOAL_TURN_NO_HISTORICAL_SCIENCE_REPLAY','expensive_historical_science_replayed':False,'historical_custody':'EXIT2_SEVEN_NOTPASS','whole_investigation':'INCOMPLETE'}
 save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
