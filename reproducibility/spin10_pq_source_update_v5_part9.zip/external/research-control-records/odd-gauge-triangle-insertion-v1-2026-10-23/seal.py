from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');HERE=ROOT/'calculations/canonical_so10_odd_gauge_triangle_insertion';CONTROL=Path(__file__).resolve().parent
BASE='b2ae38a93f89ab69c8bf7e2647964628b789e57b';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
counts={}
for n in ['preparation.json','validation_preparation.json']:
 d=read(HERE/n);counts[n]=len(d['input_sha256'])
 for p,h in d['input_sha256'].items():assert digest(Path(p))==h,p
sources=list(HERE.glob('*.source.txt'));assert len(sources)==8
for p in sources:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes()
assert digest(HERE/'validation_receipt.json')=='97ff54a20cd05e0c0d4a28d47989a5c5d06039236ab76997c8e9a7c415350b3d'
r=read(HERE/'validation_receipt.json');assert r['status']=='QUALIFIED_ACTUAL_CGG_ODD_IHAT_AND_POSITIVE_HEAT_MATCH_WITH_SPIN10_TENSOR_APPLICATION' and r['actual_Spin10_selected_odd_breaking']==0 and not r['physical_scheme_adopted']
assert r['unit_coefficient']=='1/3' and r['unit_charge_control_coefficient']=='2/3' and r['nonzero_universal_epsilon_positions']==24
for role in ['primary','replay','verify']:
 c=read(HERE/(role+'_capture.json'));assert c==read(CONTROL/(role+'_full_capture.json')) and c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
 rows=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rows)==1 and rows[0]['elapsed_after_imports']<600
 if role=='verify':assert rows[0]==r
 else:
  blob=(HERE/(role+'_tables.json.gz')).read_bytes();assert sha256(blob).hexdigest()==rows[0]['packed_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==rows[0]['tables_sha256']
blob=(HERE/'selected_odd_triangle_member.json.gz').read_bytes();assert sha256(blob).hexdigest()==r['artifact_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['artifact_raw_sha256']
rd=read(CONTROL/'readiness_result.json');assert rd['native_exit']==0 and rd['step_exits']==[0,0,0,0,0,2] and rd['historical_custody']=='EXIT2_SEVEN_NOTPASS'

assert not (HERE/'controller_failure.json').exists() and sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
old=(CONTROL/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==33171
files=sorted([p for p in HERE.iterdir() if p.is_file()]+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V567.md'])
for p in files:
 if p.suffix!='.gz':assert b'\r' not in p.read_bytes(),p
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':33171,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'source_copies':8,'binding_counts':counts,'receipt_sha256':digest(HERE/'validation_receipt.json'),'seal_source_sha256':digest(Path(__file__)),'scientific_acceptance':'NOT_PERFORMED'});print('OGT1_BEFORE_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'raw_index_files':len(files),'scientific_acceptance':'NOT_PERFORMED'});print('OGT1_INDEX_SEALED',len(files),flush=True)
else:
 assert mode=='after';seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==33171+len(files) and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':33171,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'source_copies':8,'binding_counts':counts,'receipt_sha256':digest(HERE/'validation_receipt.json'),'precommit_and_index_custody_passed':True,'scientific_authority':'34/39_UNCHANGED','historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED','whole_investigation':'INCOMPLETE'}
 save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
