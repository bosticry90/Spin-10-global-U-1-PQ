"""GHP1 completed-native and immutable-byte seal."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');CONTROL=Path(__file__).resolve().parent;HERE=ROOT/'calculations/canonical_so10_gauge_source_heat_p_response'
BASE='8ffdfddea2fbd48f3070c8833ce77ce859c8bb18';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';NOLD=32466
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
old=(CONTROL/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==NOLD
r=read(HERE/'validation_receipt.json');receipt=digest(HERE/'validation_receipt.json');assert receipt=='587dc13e1f076b5ce0ab738e79a8ff77b4a1cee2ddf90152d6ef4466d7ba84ae'
assert r['status']=='QUALIFIED_ACTUAL_TWO_WIDTH_GAUGE_SOURCE_HEAT_P_RESPONSE'
assert r['response_color_positions_compared']==161280 and r['actual_GTT_bare_dimensional_p_matches'] and r['actual_VFC_FHK_PSF_relative_p_matches']
assert r['units']=={'heat_length_log':'-1','heat_pair_Taylor':'-1/12','heat_odd_endpoint_Taylor':'-1/6','heat_total_fixed':'-1/4','dimensional_fixed':'-1/6','relative_log':'1','relative_fixed':'1/12'}
assert r['derived_negative_traceless_CW_over6_equals_old_CFC_F0'] and r['old_positive_compact_diagnostic_changed_positions']==16 and r['old_positive_compact_failure_preserved']
assert r['H12_projection_zero_and_insensitive'] and r['equal_width_projection_zero_and_insensitive'] and r['actual_source_partner_equals_CW_commutator']
assert r['authority']=='34/39' and r['scientific_acceptance']=='NOT_PERFORMED'
assert not any(r[k] for k in ['q_slot_response_derived','physical_scheme_adopted','quantum_coefficient_fitted','full_nonlinear_Slavnov_QAP_measure_phase_E5A5_qualified','scientific_authority_changed','z_psi_selected'])
counts={};cache={}
for n in ['preparation.json','validation_preparation.json']:
 bd=read(HERE/n)['input_sha256'];counts[n]=len(bd)
 for p,h in bd.items():
  if p not in cache:cache[p]=digest(Path(p))
  assert cache[p]==h,p
assert counts=={'preparation.json':1381,'validation_preparation.json':1389}
assert len(list(HERE.glob('*.source.txt')))==8
for p in HERE.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes() and b'\r' not in p.read_bytes()
for p in HERE.glob('*.py'):compile(p.read_bytes(),str(p),'exec')
for p in HERE.glob('*.md'):assert b'\r' not in p.read_bytes()
assert not (HERE/'controller_failure.json').exists() and sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
resources={}
for name in ['primary','replay','verify']:
 p=HERE/(name+'_capture.json');c=read(p);assert p.read_bytes()==(CONTROL/(name+'_full_capture.json')).read_bytes()
 ss=c['all_resource_samples'];assert ss and c['launch']['creation_after_observation'] and c['launch']['memory']['available_pagefile']>=350*1024**2
 maximum=max(v['private_bytes'] for v in ss);assert maximum<=8*1024**3 and c['post_run_observations_qualified']
 assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed']
 out=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(out)==1
 out=out[0];assert out['elapsed_after_imports']<600 and out==read(HERE/('validation_receipt.json' if name=='verify' else name+'_result.json'))
 if name!='verify':
  b=(HERE/(name+'_tables.json.gz')).read_bytes();assert sha256(b).hexdigest()==out['packed_sha256'] and sha256(gzip.decompress(b)).hexdigest()==out['tables_sha256']
  d=json.loads(gzip.decompress(b));assert d['source_partner_matches_actual_CW_commutator'] and d['source_both_endpoints_retained'] and not d['z_psi_selected'] and not d['full_q_or_nonlinear_Slavnov_QAP_measure_phase_E5A5_qualified'] and not d['quantum_coefficient_fitted'] and not d['physical_scheme_adopted']
 resources[name]={'exit':0,'samples':len(ss),'sampled_private_maximum':maximum,'peak_memory_claimed':False}
pc=read(HERE/'preparation_capture.json');assert pc==read(CONTROL/'preparation_full_capture.json') and pc['native_exit']==0 and not pc['scientific_calculations_executed']
events=[json.loads(v) for v in (CONTROL/'readiness.jsonl').read_text(encoding='utf-8').splitlines()];steps=[v for v in events if v['event']=='step_finished']
assert [v['exit_code'] for v in steps]==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested'] and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
rr=read(CONTROL/'readiness_result.json');assert rr['fresh_command_here'] and rr['native_exit']==0 and rr['step_exits']==[0,0,0,0,0,2] and rr['historical_custody']=='EXIT2_SEVEN_NOTPASS'
pre=read(CONTROL/'prelaunch_preflight.json');assert pre['git_HEAD']==BASE and pre['state_sha256']==STATE and pre['files_written']==0 and pre['scientific_acceptance']=='NOT_PERFORMED'
files=sorted(p for p in HERE.iterdir() if p.is_file())+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V549.md'];assert len(files)==32
assert git('rev-parse','HEAD').decode().strip()=='e511fbdc9c538197d6586348cf9369aab414e0ab' and git('rev-parse','HEAD^').decode().strip()==BASE
failure=read(CONTROL/'observed_custody_failure.json');assert not failure['precommit_custody_passed'] and failure['original_seal_sha256']==digest(CONTROL/'seal.py')
def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==len(prior)+len(files) and all(current[n]==v for n,v in prior.items())
newhash={}
for p in files:
 n=p.relative_to(ROOT).as_posix();h=digest(p);assert sha256(git('show','HEAD:'+n)).hexdigest()==h==sha256(git('show',':'+n)).hexdigest();newhash[n]=h
assert not git('status','--porcelain').strip()
out={'status':'POSTCOMMIT_CUSTODY_RECOVERED_WITH_ORIGINAL_PRECOMMIT_FAILURE_PRESERVED','commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':NOLD,'new_raw_index_HEAD_bytes_match':len(files),'new_raw_sha256':newhash,'clean':True,'receipt_sha256':receipt,'state_sha256':STATE,'scientific_authority':'34/39_UNCHANGED','scientific_acceptance':'NOT_PERFORMED','actual_gauge_source_heat_p_response_qualified':True,'precommit_custody_passed':False,'observed_failure_sha256':digest(CONTROL/'observed_custody_failure.json'),'recovery_source_sha256':digest(Path(__file__)),'resources':resources,'manifest_counts':counts,'historical_custody':'EXIT2_SEVEN_NOTPASS','whole_investigation':'INCOMPLETE'}
save('postcommit_recovery_seal.json',out);print(json.dumps({k:v for k,v in out.items() if k not in ['new_raw_sha256','resources']},sort_keys=True),flush=True)
