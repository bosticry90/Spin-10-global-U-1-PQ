"""GHP1 separate correction commit with mandatory fail-stop gates."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');CONTROL=Path(__file__).resolve().parent;BASE='e511fbdc9c538197d6586348cf9369aab414e0ab';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
r=read(CONTROL/'postcommit_recovery_seal.json');assert r['commit']==BASE and r['old_tracked_blobs_unchanged']==32466 and r['new_raw_index_HEAD_bytes_match']==32 and not r['precommit_custody_passed']
assert digest(CONTROL/'seal_recovery_v2.py')==r['recovery_source_sha256'] and digest(CONTROL/'observed_custody_failure.json')==r['observed_failure_sha256']
assert read(CONTROL/'recovery_v2_capture.json')['native_exit']==0
for n,h in r['new_raw_sha256'].items():assert digest(ROOT/n)==h==sha256(git('show',BASE+':'+n)).hexdigest()
old=git('ls-tree','-r',BASE);assert len(old.splitlines())==32498
files=[ROOT/'calculations/canonical_so10_gauge_source_heat_p_response/CUSTODY_REPAIR_V2.md',ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V550.md']
for p in files:assert p.exists() and b'\r' not in p.read_bytes()
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('repair_before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':32498,'old_tree_sha256':sha256(old).hexdigest(),'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'recovery_seal_sha256':digest(CONTROL/'postcommit_recovery_seal.json'),'seal_source_sha256':digest(Path(__file__)),'original_precommit_custody_passed':False,'repair_precommit_custody_passed':True,'scientific_acceptance':'NOT_PERFORMED'});print('REPAIR_PRECOMMIT_SEALED_2',flush=True)
elif mode=='index':
 seal=read(CONTROL/'repair_before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('repair_successful_index_gate.json',{'raw_index_files':2,'original_precommit_custody_passed':False,'repair_precommit_custody_passed':True});print('REPAIR_INDEX_SEALED_2',flush=True)
else:
 assert mode=='after';seal=read(CONTROL/'repair_before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==32500 and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'original_GHP_commit':BASE,'old_tracked_blobs_unchanged':32498,'new_raw_index_HEAD_bytes_match':2,'clean':True,'original_precommit_custody_passed':False,'original_postcommit_custody_recovered':True,'repair_precommit_custody_passed':True,'scientific_authority':'34/39_UNCHANGED','historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED','whole_investigation':'INCOMPLETE'}
 save('repair_postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
