"""OSM1 native/byte seal, preserving the exhausted original gate."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');CONTROL=Path(__file__).resolve().parent;HERE=ROOT/'calculations/canonical_so10_ordinary_scalar_matter_breaking'
BASE='c3d0353965e69c08242558cd6e351db898accc0c';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';NOLD=31597
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
old=(CONTROL/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==NOLD
r=read(HERE/'validation_receipt.json');receipt=digest(HERE/'validation_receipt.json')
assert r['status']=='QUALIFIED_COMPLETE_ORDINARY_AND_ASSEMBLED_SCALAR_MATTER_BREAKING_TEST'
zero=not any(n for row in r['fixed_upper_source_sum_remainders'].values() for n in row.values())
assert r['disposition']==('SCALAR_KERNEL_CANCELS_FIXED_SOURCE_ON_ACTUAL_CARRIERS' if zero else 'NONZERO_FIXED_SOURCE_SCALAR_REMAINDER_PRESERVED')
assert r['authority']=='34/39' and r['scientific_acceptance']=='NOT_PERFORMED'
assert r['ordinary_profiles']==8 and r['complete_scalar_candidate_profiles']==24 and r['paired_zero_profiles_reused']==12 and r['auxiliary_profiles_reused']==4
assert r['mass_map_positions_compared']==15114240 and not any(r['global_H_tensor_nonzero_positions']) and r['mass_reality_and_symmetry_remainders']=='0'
assert r['remaining_unmeasured_degreezero_vector_profiles']==42 and r['radial_integrations_reused_not_rerun']
assert r['total_program']=={'J1':'-1/6','J2':'-1/6','L':'-1/2','R':'-1/2'}
for k in ['full_coupled_finite_restoration_QAP_measure_phase_massive_C1_E5A5_or_unification_qualified','scientific_authority_changed','physical_scheme_adopted']:assert not r[k]
blob=(HERE/'comparison_tables.json.gz').read_bytes();assert sha256(blob).hexdigest()==r['comparison_tables_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['comparison_raw_sha256']
counts={};cache={}
for n in ['preparation.json','validation_preparation.json','preparation_v2.json','validation_preparation_v2.json','preparation_v3.json','validation_preparation_v3.json']:
 bd=read(HERE/n)['input_sha256'];counts[n]=len(bd)
 for p,h in bd.items():
  if p not in cache:cache[p]=digest(Path(p))
  assert cache[p]==h,p
assert counts=={'preparation.json':59,'validation_preparation.json':67,'preparation_v2.json':83,'validation_preparation_v2.json':85,'preparation_v3.json':99,'validation_preparation_v3.json':101}
assert len(list(HERE.glob('*.source.txt')))==16
for p in HERE.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes() and b'\r' not in p.read_bytes()
for p in HERE.glob('*.py'):compile(p.read_bytes(),str(p),'exec')
for p in HERE.glob('*.md'):assert b'\r' not in p.read_bytes()
assert not (HERE/'controller_v3_failure.json').exists() and sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
resources={}
for name in ['primary','replay','verify','verify_v2','verify_v3']:
 p=HERE/(name+'_capture.json');c=read(p);assert p.read_bytes()==(CONTROL/(name+'_full_capture.json')).read_bytes()
 ss=c['all_resource_samples'];assert ss and c['launch']['creation_after_observation'] and c['launch']['memory']['available_pagefile']>=350*1024**2
 maximum=max(v['private_bytes'] for v in ss);assert maximum<=8*1024**3 and c['post_run_observations_qualified']
 out=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')]
 if name in ['verify','verify_v2']:
  assert c['execution_state']=='FAILED' and c['exit_code']==124 and not c['calculation_completed'] and not out
 else:
  assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and len(out)==1
  out=out[0];assert out['elapsed_after_imports']<600 and out==read(HERE/('validation_receipt.json' if name=='verify_v3' else name+'_result.json'))
  if name!='verify_v3':
   b=(HERE/(name+'_tables.json.gz')).read_bytes();assert sha256(b).hexdigest()==out['packed_sha256'] and sha256(gzip.decompress(b)).hexdigest()==out['tables_sha256']
 resources[name]={'exit':c['exit_code'],'scientific_execution':'INCOMPLETE_RESOURCE_LIMIT' if name in ['verify','verify_v2'] else 'COMPLETED_WITHIN_FROZEN_SCOPE','samples':len(ss),'sampled_private_maximum':maximum,'peak_memory_claimed':False}
failed=read(HERE/'controller_failure.json');assert failed['execution_state']=='FAILED' and failed['last_role']=='verify' and not failed['failure_relabelled_PASS'] and failed['scientific_acceptance']=='NOT_PERFORMED'
failed2=read(HERE/'controller_v2_failure.json');assert failed2['execution_state']=='FAILED' and failed2['last_role']=='verify_v2' and not failed2['failure_relabelled_PASS']
for name in ['preparation','preparation_v2','preparation_v3']:
 pc=read(HERE/(name+'_capture.json'));assert pc==read(CONTROL/(name+'_full_capture.json')) and pc['native_exit']==0 and not pc['scientific_calculations_executed']
events=[json.loads(v) for v in (CONTROL/'readiness.jsonl').read_text(encoding='utf-8').splitlines()];steps=[v for v in events if v['event']=='step_finished']
assert [v['exit_code'] for v in steps]==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested'] and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
reuse=read(CONTROL/'readiness_reuse.json');assert not reuse['fresh_readiness_command_here'] and reuse['source_command_executed_earlier_this_goal_turn'] and reuse['fresh_byte_preflight_here']
ready=read(CONTROL/'readiness_result.json');assert ready['native_exit']==0 and ready['readiness_command_executed_this_goal_turn'] and not ready['fresh_historical_science_requested'] and ready['custody']=='EXIT2_SEVEN_NOTPASS'
for n in ['prelaunch_preflight.json','v2_prelaunch_preflight.json','v3_prelaunch_preflight.json']:
 d=read(CONTROL/n);assert d['git_HEAD']==BASE and d['state_sha256']==STATE and d['files_written']==0 and d['scientific_acceptance']=='NOT_PERFORMED'
files=sorted(p for p in HERE.iterdir() if p.is_file())+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V528.md'];assert len(files)==56
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':NOLD,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'receipt_sha256':receipt,'state_sha256':STATE,'resources':resources,'manifest_counts':counts,'seal_source_sha256':digest(Path(__file__)),'scientific_acceptance':'NOT_PERFORMED'})
 print('PRECOMMIT_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'before_seal_sha256':digest(CONTROL/'before_commit_seal.json'),'raw_index_files':len(files)});print('RAW_INDEX_MATCH',len(files),flush=True)
else:
 assert mode=='after';seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==len(prior)+len(files) and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':NOLD,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'receipt_sha256':receipt,'state_sha256':STATE,'scientific_authority':'34/39_UNCHANGED','scientific_acceptance':'NOT_PERFORMED','ordinary_scalar_profiles_measured':8,'complete_scalar_catalogue_profiles':24,'fixed_source_Euler_sum_zero':zero,'original_and_V2_gate_exhaustions_preserved':True,'completed_quantum_workers_repeated':False,'physical_scheme_adopted':False,'historical_custody':'EXIT2_SEVEN_NOTPASS','whole_investigation':'INCOMPLETE'}
 save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
