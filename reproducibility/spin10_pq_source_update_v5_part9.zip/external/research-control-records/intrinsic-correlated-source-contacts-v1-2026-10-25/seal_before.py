from pathlib import Path
from hashlib import sha256
import json,subprocess
R=Path.cwd();O=R/'calculations/canonical_so10_intrinsic_correlated_source_contacts';C=Path(__file__).resolve().parent;H=lambda p:sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()=='8e9b743934cf9bd4583946df62d026ad529c41c6';assert git('branch','--show-current').decode().strip()=='main'
old=(C/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r','HEAD')and len(old.splitlines())==37620;assert not git('diff','--name-only','HEAD')and not git('diff','--cached','--name-only')
state=H(R/'project_state.json');assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';checks=0;seen={};copies=[];peak=0;captures=[]
for p in O.glob('*preparation*.json'):
 for f,h in json.loads(p.read_bytes()).get('input_sha256',{}).items():
  assert H(Path(f))==h,(p,f);assert f not in seen or seen[f]==h;seen[f]=h;checks+=1
for p in O.glob('*.source.txt'):
 assert p.read_bytes()==Path(str(p)[:-len('.source.txt')]).read_bytes();copies.append(p.name)
for p in O.glob('*capture.json'):
 z=json.loads(p.read_bytes());assert z['post_run_observations_qualified']and z['launch']['memory']['available_pagefile']>=350*1024**2;mx=max(v['private_bytes']for v in z['all_resource_samples']);peak=max(peak,mx);assert mx<=8*1024**3
 if p.name=='roots_verify_capture.json':assert z['exit_code']==1 and z['execution_state']=='FAILED'and not z['calculation_completed']
 else:assert z['exit_code']==0 and z['execution_state']=='COMPLETED'and z['calculation_completed']
 captures.append({'name':p.name,'exit':z['exit_code'],'state':z['execution_state'],'largest_sample':mx})
assert json.loads((O/'roots_controller_failure.json').read_bytes())['execution_state']=='FAILED';assert not(O/'roots_validation_receipt.json').exists()
for n in ['roots_controller_failure_v2.json','contact_support_controller_failure.json','contact_kernel_controller_failure.json','contact_color_controller_failure.json','lowering_controller_failure.json','auxiliary_roots_controller_failure.json','partial_H_controller_failure.json','final_review_controller_failure.json']:assert not(O/n).exists()
v=json.loads((O/'final_review_validation_receipt.json').read_bytes());assert v['corrected_exact_operation_coefficients_checked']==20977 and v['replay_contact_N0_roots_and_old_H_independent_integration_pass']and not v['full_QAP_E5_A5_or_physical_promotion'];assert v['new_three_edge_contact_lowering_plus_marginal_companion_nonzero']==[0,2496]
e=json.loads((C/'e4_full_capture.json').read_bytes());ev=[json.loads(l)for l in e['stdout_and_stderr'].splitlines()];exits=[q['exit_code']for q in ev if q['event']=='step_finished'];assert e['native_exit']==0 and exits==[0,0,0,0,0,2]and ev[-1]['execution_state']=='COMPLETED'
files={p.relative_to(R).as_posix():H(p)for p in O.iterdir()if p.is_file()};hh=R/'docs/RESEARCH_EXECUTION_HANDOFF_V629.md';files[hh.relative_to(R).as_posix()]=H(hh);size=sum(p.stat().st_size for p in O.iterdir()if p.is_file());assert size<32*1024**2
z={'base':git('rev-parse','HEAD').decode().strip(),'old_blobs_preserved':37620,'state_sha256':state,'old_tree_sha256':H(C/'old_git_tree.txt'),'binding_checks':checks,'unique_bindings':len(seen),'source_copies':copies,'native_captures':captures,'max_sampled_private':peak,'packet_bytes':size,'new_files_sha256':files,'E4_step_exits':exits,'custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED','goal':'ACTIVE_INCOMPLETE'}
with(C/'before_index_seal.json').open('x',encoding='utf-8',newline='\n')as f:json.dump(z,f,sort_keys=True)
print(json.dumps({k:v for k,v in z.items()if k not in ['source_copies','native_captures','new_files_sha256']},sort_keys=True))
