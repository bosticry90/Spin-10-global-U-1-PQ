"""GTT1 byte/native capture seal. It performs no scientific promotion."""
from pathlib import Path
from hashlib import sha256
import ast,gzip,json,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');CONTROL=Path(__file__).resolve().parent;HERE=ROOT/'calculations/canonical_so10_ghost_triangle_field_insertion'
BASE='a2d4057b7dc3dc5a5a626d468b85bec887839630';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';NOLD=31442
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)
digest=lambda p:sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
old=(CONTROL/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==NOLD
r=read(HERE/'validation_receipt.json');receipt=digest(HERE/'validation_receipt.json')
assert receipt=='610e974608e4d4f711708a7018a0981a857180cdc852a36807cdb7fa5be42d4a'
assert r['status']=='QUALIFIED_COMPLETE_GF_GHOST_FINITE_FIELD_INSERTION' and r['scientific_acceptance']=='NOT_PERFORMED' and r['authority']=='34/39'
assert r['triangle_supports']==8 and r['ordinary_g3_supports']==6 and r['auxiliary_g2_supports']==2 and r['full_cPP_supports_assembled_exactly_once']==12
assert r['triangle_matrix_positions_compared']==368640 and r['complete_cPP_matrix_positions_assembled_compared']==184320
assert r['selected_g2_matching_disposition']=='SELECTED_G2_KINETIC_CHANNEL_CANCELS_MOD_RETAINED_CURRENT' and not any(r['selected_g2_matching_remainder_positions'].values())
assert all(not any(tab.values()) for tab in r['analytic_reality_remainder_positions'].values()) and all(not any(tab.values()) for tab in r['internal_H_nonzero_blocks'].values())
assert not any(r[k] for k in ['scientific_authority_changed','physical_scheme_adopted','g3_counterterm_matching_and_complete_Slavnov_QAP_measure_phase_massive_matching_qualified'])
blob=(HERE/'comparison_tables.json.gz').read_bytes();assert sha256(blob).hexdigest()==r['comparison_tables_sha256'] and sha256(gzip.decompress(blob)).hexdigest()==r['comparison_raw_sha256']
counts={};cache={}
for n in ['preparation.json','validation_preparation.json']:
 bd=read(HERE/n)['input_sha256'];counts[n]=len(bd)
 for p,h in bd.items():
  if p not in cache:cache[p]=digest(Path(p))
  assert cache[p]==h,p
assert counts=={'preparation.json':75,'validation_preparation.json':84}
assert len(list(HERE.glob('*.source.txt')))==8
for p in HERE.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes() and b'\r' not in p.read_bytes()
for p in HERE.glob('*.py'):compile(p.read_bytes(),str(p),'exec')
for p in HERE.glob('*.md'):assert b'\r' not in p.read_bytes()
assert not (HERE/'controller_failure.json').exists() and sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
resources={}
for name in ['primary','replay','verify']:
 p=HERE/(name+'_capture.json');c=read(p);assert p.read_bytes()==(CONTROL/(name+'_full_capture.json')).read_bytes()
 ss=c['all_resource_samples'];assert ss and c['launch']['creation_after_observation'] and c['launch']['memory']['available_pagefile']>=350*1024**2
 maximum=max(v['private_bytes'] for v in ss);assert maximum<=8*1024**3
 assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed'] and c['post_run_observations_qualified']
 out=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(out)==1;out=out[0];assert out['elapsed_after_imports']<600
 assert out==read(HERE/('validation_receipt.json' if name=='verify' else name+'_result.json'))
 if name!='verify':
  b=(HERE/(name+'_tables.json.gz')).read_bytes();assert sha256(b).hexdigest()==out['packed_sha256'] and sha256(gzip.decompress(b)).hexdigest()==out['tables_sha256']
 resources[name]={'exit':c['exit_code'],'samples':len(ss),'sampled_private_maximum':maximum,'peak_memory_claimed':False}
events=[json.loads(v) for v in (CONTROL/'readiness.jsonl').read_text().splitlines()];steps=[v for v in events if v['event']=='step_finished']
assert [v['exit_code'] for v in steps]==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested'] and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
reuse=read(CONTROL/'readiness_reuse.json');assert not reuse['fresh_readiness_command_here'] and reuse['source_was_fresh_in_prior_goal_turn'] and reuse['fresh_byte_preflight_here'] and reuse['fresh_byte_preflight_native_exit']==0 and not reuse['scientific_replay_or_acceptance_inferred']
for n,h in reuse['source_sha256'].items():assert digest(Path(n))==h==digest(CONTROL/Path(n).name)
snap=read(CONTROL/'prelaunch_preflight.json');assert snap['git_HEAD']==BASE and snap['state_sha256']==STATE and snap['scientific_acceptance']=='NOT_PERFORMED' and snap['files_written']==0
ex=json.loads(gzip.decompress((HERE/'qualified_reference_inputs.json.gz').read_bytes()));assert ex['old_source_UV_loop_targets_excluded'] and set(ex['reference_fields'])=={'raw_ghost_Green','raw_auxiliary_plane_map','old_plane_V','old_plane_H','plane_f'}
assert r['literal_density_positions']=={'B':720,'H':276,'a':3480,'c':1440}

files=sorted(p for p in HERE.iterdir() if p.is_file())+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V524.md'];assert len(files)==30
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':NOLD,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'receipt_sha256':receipt,'state_sha256':STATE,'resources':resources,'manifest_counts':counts,'seal_source_sha256':digest(Path(__file__)),'readiness_sha256':digest(CONTROL/'readiness.jsonl'),'scientific_acceptance':'NOT_PERFORMED'})
 print('PRECOMMIT_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'before_seal_sha256':digest(CONTROL/'before_commit_seal.json'),'raw_index_files':len(files)});print('RAW_INDEX_MATCH',len(files),flush=True)
else:
 assert mode=='after';seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==len(prior)+len(files) and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':NOLD,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'receipt_sha256':receipt,'state_sha256':STATE,'scientific_authority':'34/39_UNCHANGED','scientific_acceptance':'NOT_PERFORMED','qualified_scope':r['status'],'new_GF_triangle_supports':8,'selected_cPP_catalogue_exact_once':12,'selected_g2_cancellation':True,'physical_scheme_adopted':False,'readiness_execution':'AUTHENTICATED_PRIOR_TURN_MSP1_E4_FRESH_BYTE_PREFLIGHT_HERE','expensive_historical_science_replayed':False,'historical_custody':'EXIT2_SEVEN_NOTPASS','whole_investigation':'INCOMPLETE'}
 save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
