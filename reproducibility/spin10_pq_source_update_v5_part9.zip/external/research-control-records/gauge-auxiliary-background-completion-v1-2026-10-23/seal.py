from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');HERE=ROOT/'calculations/canonical_so10_gauge_auxiliary_background_completion';CONTROL=Path(__file__).resolve().parent
BASE='ccba8c86623fb191e004ddfebc59e9fcc874a4b3';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
counts={}
for n in ['preparation.json','validation_preparation.json','extension_preparation_v2.json']:
 d=read(HERE/n);counts[n]=len(d['input_sha256'])
 for p,h in d['input_sha256'].items():assert digest(Path(p))==h,p
sources=list(HERE.glob('*.source.txt'));assert len(sources)==11
for p in sources:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes()
assert digest(HERE/'validation_receipt.json')=='bb912b908c8118bf3a3ce3211c14aeafe2a697ef1312ec2b394d7fcd81aea317'
r=read(HERE/'validation_receipt.json');assert r['status']=='QUALIFIED_FULL_D_GAUGE_AUXILIARY_H_MEMBER_AND_SELECTED_GAUGE_BACKGROUND_HEAT_COMPATIBILITY' and r['total_remainder_nonzero']==0 and not r['physical_scheme_adopted']
for role in ['primary','replay','verify']:
 c=read(HERE/(role+'_capture.json'));assert c==read(CONTROL/(role+'_full_capture.json')) and c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
 rows=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rows)==1 and rows[0]['elapsed_after_imports']<600
 if role=='verify':assert rows[0]==r
 else:
  b=(HERE/(role+'_tables.json.gz')).read_bytes();assert sha256(b).hexdigest()==rows[0]['packed_sha256'] and sha256(gzip.decompress(b)).hexdigest()==rows[0]['tables_sha256']

c=read(HERE/'complete_reference_check_capture.json');e=read(HERE/'extension_receipt_v2.json')
assert c==read(CONTROL/'complete_reference_check_full_capture.json') and c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
rows=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rows)==1 and rows[0]==e and e['elapsed_after_imports']<600
assert digest(HERE/'extension_receipt_v2.json')=='ad75131e28f54ca95a0cb4a62d7b8b085e4b9f72fb54d02550f3223aaf468da6'
assert e['status']=='QUALIFIED_LITERAL_GFK_FLAT_MATCH_AND_SELECTED_RELATIVE_BACKGROUND_ASSEMBLY' and not e['physical_scheme_adopted']
for n,packed,raw in [('selected_gauge_background_family.json.gz',r['family_sha256'],r['family_raw_sha256']),('selected_relative_background_extension.json.gz',e['extension_sha256'],e['extension_raw_sha256'])]:
 b=(HERE/n).read_bytes();assert sha256(b).hexdigest()==packed and sha256(gzip.decompress(b)).hexdigest()==raw
h=read(HERE/'historical_SMP_byte_authentication.json');assert len(h['bindings'])==77 and not h['old_scientific_workers_rerun'] and not h['new_policy_substituted']
for v in h['bindings']:
 assert v['authentication']=='CURRENT_BYTES_MATCH_OLD_BINDING' and digest(Path(v['path']))==v['old_sha256']
assert '53a99e56ee95c247efd4e07d3ff7a4fb8817d284dd4f7a0cbfc63f449495c25c' in (ROOT/'docs/MMI1_HISTORICAL_SCOPE_CORRECTION_V1.md').read_text()
rd=read(CONTROL/'readiness_result.json');assert rd['native_exit']==0 and rd['step_exits']==[0,0,0,0,0,2] and rd['historical_custody']=='EXIT2_SEVEN_NOTPASS'
assert not (HERE/'extension_controller_failure_v2.json').exists()

assert not (HERE/'controller_failure.json').exists() and sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
old=(CONTROL/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==33027
files=sorted([p for p in HERE.iterdir() if p.is_file()]+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V563.md',ROOT/'docs/MMI1_HISTORICAL_SCOPE_CORRECTION_V1.md'])
for p in files:
 if p.suffix!='.gz':assert b'\r' not in p.read_bytes(),p
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':33027,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'source_copies':11,'binding_counts':counts,'receipt_sha256':digest(HERE/'validation_receipt.json'),'seal_source_sha256':digest(Path(__file__)),'scientific_acceptance':'NOT_PERFORMED'});print('GAB1_BEFORE_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'raw_index_files':len(files),'scientific_acceptance':'NOT_PERFORMED'});print('GAB1_INDEX_SEALED',len(files),flush=True)
else:
 assert mode=='after';seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==33027+len(files) and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':33027,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'source_copies':11,'binding_counts':counts,'receipt_sha256':digest(HERE/'validation_receipt.json'),'precommit_and_index_custody_passed':True,'scientific_authority':'34/39_UNCHANGED','historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED','whole_investigation':'INCOMPLETE'}
 save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
