"""SMP1 completed-native and immutable-byte seal."""
from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');CONTROL=Path(__file__).resolve().parent;HERE=ROOT/'calculations/canonical_so10_scalar_matter_primitive'
BASE='184cd5cb6b425e315f29de71e13d2d80be093f08';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8';NOLD=31710
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
old=(CONTROL/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==NOLD
r=read(HERE/'validation_receipt.json');receipt=digest(HERE/'validation_receipt.json');assert receipt=='0a7cf416cc8777095a9ec879193aad84d77c92a179e338ca8c3147ce0ba10737'
assert r['status']=='QUALIFIED_SCALAR_MATTER_FINITE_YUKAWA_PRIMITIVE' and r['disposition']=='COMPLETE_SELECTED_SCALAR_REMAINDER_CANCELLED_WITH_SYMBOLIC_INVARIANT_ADDITIONS'
assert r['relation_degree']==3 and r['relation']==['2160','516','40','1']
assert len(r['all45_full_operator_image_remainders'])==45 and not any(r['all45_full_operator_image_remainders']) and len(r['all12_H_operator_remainders'])==12 and not any(r['all12_H_operator_remainders']) and r['all45_antiholomorphic_operator_remainders']==0
assert r['authority']=='34/39' and r['scientific_acceptance']=='NOT_PERFORMED'
assert r['physical_kernel_nonzero_counts']==[320,4032] and all(v==[8576,141696] for v in r['controls'].values())
assert r['widths_formal_and_nonnegative_polynomial'] and r['general_symmetric_families_retained'] and r['highest_source_and_zero_scalar_onejet_preserved'] and r['invariant_additions']==['u10*M10','u126*M126']
assert not any(r[k] for k in ['inverse_physical_parameters_used','invariant_parameters_fixed','homogeneous_family_exhaustive','full_coupled_restoration_QAP_measure_phase_massiveC1_E5A5_or_unification_qualified','quantum_loops_rerun','physical_scheme_adopted','scientific_authority_changed'])
counts={};cache={}
for n in ['preparation.json','validation_preparation.json']:
 bd=read(HERE/n)['input_sha256'];counts[n]=len(bd)
 for p,h in bd.items():
  if p not in cache:cache[p]=digest(Path(p))
  assert cache[p]==h,p
assert counts=={'preparation.json':200,'validation_preparation.json':208}
assert len(list(HERE.glob('*.source.txt')))==8
for p in HERE.glob('*.source.txt'):assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes() and b'\r' not in p.read_bytes()
for p in HERE.glob('*.py'):compile(p.read_bytes(),str(p),'exec')
for p in HERE.glob('*.md'):assert b'\r' not in p.read_bytes()
assert not (HERE/'controller_failure.json').exists() and sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
resources={}
for name in ['primary','replay','verify']:
 p=HERE/(name+'_capture.json');c=read(p);assert p.read_bytes()==(CONTROL/(name+'_full_capture.json')).read_bytes()
 ss=c['all_resource_samples'];assert ss and c['launch']['creation_after_observation'] and c['launch']['memory']['available_pagefile']>=350*1024**2
 maximum=max(v['private_bytes'] for v in ss);assert maximum<=8*1024**3 and c['post_run_observations_qualified']
 assert c['execution_state']=='COMPLETED' and c['exit_code']==0 and c['calculation_completed']
 out=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(out)==1
 out=out[0];assert out['elapsed_after_imports']<600 and out==read(HERE/('validation_receipt.json' if name=='verify' else name+'_result.json'))
 if name!='verify':
  b=(HERE/(name+'_tables.json.gz')).read_bytes();assert sha256(b).hexdigest()==out['packed_sha256'] and sha256(gzip.decompress(b)).hexdigest()==out['tables_sha256']
  d=json.loads(gzip.decompress(b));assert d['relation']==r['relation'] and d['all45_full_operator_image_remainders']==r['all45_full_operator_image_remainders'] and d['physical_kernel_nonzero_counts']==r['physical_kernel_nonzero_counts']
 resources[name]={'exit':0,'samples':len(ss),'sampled_private_maximum':maximum,'peak_memory_claimed':False}
pc=read(HERE/'preparation_capture.json');assert pc==read(CONTROL/'preparation_full_capture.json') and pc['native_exit']==0 and not pc['scientific_calculations_executed']
events=[json.loads(v) for v in (CONTROL/'readiness.jsonl').read_text(encoding='utf-8').splitlines()];steps=[v for v in events if v['event']=='step_finished']
assert [v['exit_code'] for v in steps]==[0,0,0,0,0,2] and events[-1]['execution_state']=='COMPLETED' and not events[-1]['fresh_requested'] and 'HISTORICAL_REFERENCE_INTEGRITY_UNRESOLVED 7' in steps[-1]['stdout']
reuse=read(CONTROL/'readiness_reuse.json');assert not reuse['fresh_readiness_command_here'] and reuse['source_command_executed_earlier_this_goal_turn'] and reuse['fresh_byte_preflight_here']
for p,h in reuse['source_sha256'].items():assert digest(Path(p))==h
pre=read(CONTROL/'prelaunch_preflight.json');assert pre['git_HEAD']==BASE and pre['state_sha256']==STATE and pre['files_written']==0 and pre['scientific_acceptance']=='NOT_PERFORMED'
files=sorted(p for p in HERE.iterdir() if p.is_file())+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V530.md'];assert len(files)==29
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':NOLD,'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'receipt_sha256':receipt,'state_sha256':STATE,'resources':resources,'manifest_counts':counts,'seal_source_sha256':digest(Path(__file__)),'scientific_acceptance':'NOT_PERFORMED'});print('PRECOMMIT_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'before_seal_sha256':digest(CONTROL/'before_commit_seal.json'),'raw_index_files':len(files)});print('RAW_INDEX_MATCH',len(files),flush=True)
else:
 assert mode=='after';seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==len(prior)+len(files) and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':NOLD,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'receipt_sha256':receipt,'state_sha256':STATE,'scientific_authority':'34/39_UNCHANGED','scientific_acceptance':'NOT_PERFORMED','selected_scalar_primitive_full_images_cancelled':45,'invariant_parameters_fixed':False,'complete_coupled_restoration_claimed':False,'physical_scheme_adopted':False,'historical_custody':'EXIT2_SEVEN_NOTPASS','whole_investigation':'INCOMPLETE'}
 save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
