"""HMS1 fail-stop native evidence and before/index/after Git custody."""
from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
ROOT=Path('C:/Users/psboy/Documents/ToE-Next');HERE=ROOT/'calculations/canonical_so10_heat_highest_matter_source';CONTROL=Path(__file__).resolve().parent
BASE='fa5b121f9aa61e53c7a6da840f2609a3a025d2a2';STATE='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
read=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
def save(n,d):
 with (CONTROL/n).open('xb') as f:f.write((json.dumps(d,sort_keys=True,indent=2)+'\n').encode())
assert git('branch','--show-current').decode().strip()=='main' and digest(ROOT/'project_state.json')==STATE
counts={}
for name in ['preparation.json','validation_preparation.json']:
 d=read(HERE/name);counts[name]=len(d['input_sha256'])
 for p,h in d['input_sha256'].items():assert digest(Path(p))==h,p
sources=list(HERE.glob('*.source.txt'));assert len(sources)==8
for p in sources:assert p.read_bytes()==p.with_name(p.name[:-11]).read_bytes()
assert digest(HERE/'validation_receipt.json')=='e704f146a6aa1c5baf2c3abae817c85bfbbc75b264d6d6498958942e7bf98ced'
receipt=read(HERE/'validation_receipt.json');assert receipt['status']=='QUALIFIED_COMPLETE_SELECTED_HIGHEST_MATTER_SOURCE_HEAT_RESPONSE_AND_COMMON_THREE_PROJECTION_FAMILY' and not receipt['independent_component_heat_integration'] and not receipt['full_chiral_Slavnov_QAP_products_measure_phase_E5A5_qualified']
for role in ['primary','replay','verify']:
 c=read(HERE/(role+'_capture.json'));assert c==read(CONTROL/(role+'_full_capture.json')) and c['exit_code']==0 and c['execution_state']=='COMPLETED' and c['calculation_completed'] and c['post_run_observations_qualified']
 assert c['launch']['memory']['available_pagefile']>=350*1024**2 and c['all_resource_samples'] and max(v['private_bytes'] for v in c['all_resource_samples'])<=8*1024**3
 rows=[json.loads(v[7:]) for v in c['stdout_and_stderr'].splitlines() if v.startswith('RESULT ')];assert len(rows)==1 and rows[0]['elapsed_after_imports']<600;r=rows[0]
 if role=='verify':assert r==receipt
 else:
  raw=(HERE/(role+'_tables.json.gz')).read_bytes();assert sha256(raw).hexdigest()==r['packed_sha256'] and sha256(gzip.decompress(raw)).hexdigest()==r['tables_sha256']
assert not (HERE/'controller_failure.json').exists() and sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())<16*1024**2
ready=read(CONTROL/'readiness_reuse.json');assert ready['same_goalturn_fresh_command_authenticated_not_repeated'] and digest(Path(ready['source']))==ready['sha256']
assert read(Path(ready['source']))['step_exits']==[0,0,0,0,0,2]
family=(HERE/'selected_three_projection_family.json.gz').read_bytes();assert sha256(family).hexdigest()==receipt['family_sha256'] and sha256(gzip.decompress(family)).hexdigest()==receipt['family_raw_sha256']
recipe=json.loads(gzip.decompress(family));assert recipe['all_three_selected_projection_remainders_zero'] and recipe['new_term_has_no_sourcefree_cPP_cBPP_image'] and not recipe['full_source_or_background_functional_image_qualified']
old=(CONTROL/'old_git_tree.txt').read_bytes();assert old==git('ls-tree','-r',BASE) and len(old.splitlines())==32671
files=sorted([p for p in HERE.iterdir() if p.is_file()]+[ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V555.md'])
for p in files:assert b'\r' not in p.read_bytes() if p.suffix!='.gz' else True
mode=sys.argv[1]
if mode=='before':
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
 assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={p.relative_to(ROOT).as_posix() for p in files}
 save('before_commit_seal.json',{'base_commit':BASE,'old_tracked_blobs':32671,'old_tree_sha256':sha256(old).hexdigest(),'new_raw_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'source_copies':8,'binding_counts':counts,'receipt_sha256':digest(HERE/'validation_receipt.json'),'seal_source_sha256':digest(Path(__file__)),'historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED'});print('HMS1_PRECOMMIT_SEALED',len(files),flush=True)
elif mode=='index':
 seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(seal['new_raw_sha256'])
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show',':'+n)).hexdigest()==h==digest(ROOT/n)
 git('diff','--cached','--check');save('successful_index_gate.json',{'raw_index_files':len(files),'scientific_acceptance':'NOT_PERFORMED'});print('HMS1_INDEX_SEALED',len(files),flush=True)
else:
 assert mode=='after';seal=read(CONTROL/'before_commit_seal.json');assert git('rev-parse','HEAD^').decode().strip()==BASE and digest(Path(__file__))==seal['seal_source_sha256']
 def mapping(b):return {v.split(b'\t',1)[1]:v.split(b'\t',1)[0] for v in b.splitlines()}
 prior,current=mapping(old),mapping(git('ls-tree','-r','HEAD'));assert len(current)==32671+len(files) and all(current[n]==v for n,v in prior.items())
 for n,h in seal['new_raw_sha256'].items():assert sha256(git('show','HEAD:'+n)).hexdigest()==h==digest(ROOT/n)==sha256(git('show',':'+n)).hexdigest()
 assert not git('status','--porcelain').strip()
 out={'commit':git('rev-parse','HEAD').decode().strip(),'old_tracked_blobs_unchanged':32671,'new_raw_index_HEAD_bytes_match':len(files),'clean':True,'source_copies':8,'binding_counts':counts,'receipt_sha256':digest(HERE/'validation_receipt.json'),'precommit_and_index_custody_passed':True,'identity_based_not_independent_component_heat_integration':True,'scientific_authority':'34/39_UNCHANGED','historical_custody':'EXIT2_SEVEN_NOTPASS','scientific_acceptance':'NOT_PERFORMED','whole_investigation':'INCOMPLETE'}
 save('postcommit_seal.json',out);print(json.dumps(out,sort_keys=True),flush=True)
