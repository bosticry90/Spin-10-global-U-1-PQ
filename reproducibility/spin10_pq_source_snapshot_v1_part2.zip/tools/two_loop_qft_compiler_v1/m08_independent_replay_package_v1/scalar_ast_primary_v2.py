"""Ordered A3 contraction kernels and complex-linear lifts. No INT7 imports.

Conjugate field views are formed on real canonical vectors BEFORE complex
linear extension. Conjugating an already complexified slot would be wrong.
"""
from collections import defaultdict
from functools import lru_cache
from itertools import combinations
import sympy as sp

import execute_a3_parent_potential_ast as a3
from execute_scalar_ast_channel_bridge import HERE, factors, load, matrix, parity


CONJUGATE = {'Phi': 'Phi', 'Sigma': 'SigmaBar', 'SigmaBar': 'Sigma',
             'phi': 'phiBar', 'phiBar': 'phi', 'S': 'SBar', 'SBar': 'S'}


def real_tables(state):
    s = {idx: r + sp.I*i for idx, (r, i) in state.Sigma.items() if r + sp.I*i != 0}
    sb = {idx: r - sp.I*i for idx, (r, i) in state.Sigma.items() if r - sp.I*i != 0}
    return {'Phi': {(i, j): state.Phi[i, j] for i in range(10) for j in range(10) if state.Phi[i, j] != 0},
            'Sigma': s, 'SigmaBar': sb,
            'phi': {(i,): v for i, v in enumerate(state.phi) if v != 0},
            'phiBar': {(i,): sp.conjugate(v) for i, v in enumerate(state.phi) if v != 0},
            'S': {(): state.S} if state.S != 0 else {},
            'SBar': {(): sp.conjugate(state.S)} if state.S != 0 else {}}


def combine_tables(terms):
    result = {name: defaultdict(lambda: sp.Integer(0)) for name in CONJUGATE}
    for scale, tables in terms:
        for name, entries in tables.items():
            for idx, v in entries.items():
                result[name][idx] += scale*v
    return {name: {idx: sp.simplify(v) for idx, v in entries.items() if sp.simplify(v) != 0}
            for name, entries in result.items()}


def dot(a, b):
    return sp.simplify(sum(v * b.get((j, i), 0) for (i, j), v in a.items()))


def sigma_pair_boundary(a, b):
    """AST Sigma_ijlmn Sigma_ijpqr boundary (sorted lmpqr,n).

    ij, lm, pqr each have independent antisymmetric permutation orbits.
    Summing them yields 2!*2!*3!=24, exactly cancelling the A38 1/24.
    This is index contraction compression, NOT occurrence-slot symmetrization.
    """
    result = defaultdict(lambda: sp.Integer(0))
    for ia, va in a.items():
        sa = set(ia)
        for ib, vb in b.items():
            overlap = tuple(i for i in ia if i in ib)
            for ij in combinations(overlap, 2):
                rest = tuple(i for i in ia if i not in ij)
                pqr = tuple(i for i in ib if i not in ij)
                for n in rest:
                    lm = tuple(i for i in rest if i != n)
                    c = lm+pqr
                    if len(set(c)) == 5:
                        sign = parity(ij+lm+(n,))*parity(ij+pqr)*parity(c)
                        result[(tuple(sorted(c)), n)] += sign*va*vb
    return {idx: sp.simplify(v) for idx, v in result.items() if sp.simplify(v) != 0}


def phi_product(a, b):
    result = defaultdict(lambda: sp.Integer(0))
    for (i, j), va in a.items():
        for (k, l), vb in b.items():
            if j == k:
                result[(i, l)] += va*vb
    return {idx: sp.simplify(v) for idx, v in result.items() if sp.simplify(v) != 0}


def pair_boundary(name, a, b):
    if name == 'muPhi':
        return phi_product(a, b)
    if name == 'lambdaPhi1':
        return {(): dot(a, b)}
    if name == 'z6':
        return {(): sp.simplify(sum(v*b.get(idx, 0) for idx, v in a.items()))}
    assert name == 'zEta'
    return sigma_pair_boundary(a, b)


def terminal_value(name, boundary, c, d=None):
    if name == 'muPhi':
        return dot(boundary, c)
    if name == 'z6':
        return sp.simplify(boundary.get((), 0)*c.get((), 0))
    if name == 'lambdaPhi1':
        return sp.simplify(boundary.get((), 0)*dot(c, d))
    assert name == 'zEta'
    return sp.simplify(sum(v*c.get(idx, 0)*d.get((n,), 0) for (idx, n), v in boundary.items()))


def ordered_value(name, ast, slots, hc=False):
    prefactor, occurrences = factors(ast)
    names = [CONJUGATE[f] if hc else f for f, _ in occurrences]
    expected = {'muPhi': (1, ['Phi', 'Phi', 'Phi']), 'z6': (1, ['phi', 'phi', 'SBar']),
                'lambdaPhi1': (1, ['Phi']*4), 'zEta': (sp.Rational(1, 24), ['Sigma', 'Sigma', 'SigmaBar', 'phi'])}
    assert (prefactor, [f for f, _ in occurrences]) == expected[name]
    tables = [slot[f] for slot, f in zip(slots, names)]
    boundary = pair_boundary(name, tables[0], tables[1])
    return terminal_value(name, boundary, *tables[2:])


class A3SlotLifts:
    def __init__(self, role_artifact):
        self.basis = a3.canonical_real_basis()
        self.tables = [real_tables(row.state) for row in self.basis]
        raw = load(HERE.parent / 'sm_weight_basis.json')
        self.u = sp.SparseMatrix(328, 328, {(i, j): sp.sympify(v) for j, col in enumerate(raw['columns']) for i, v in col['sparse_parent_coordinates']})
        self.adapters = {r['component_id']: matrix(r['matrix']) for r in role_artifact['component_adapters']['S']}
        self.lifts, self.certificates = {}, []
        for cid, a in self.adapters.items():
            gram = a*a.H
            b = a.H*gram.inv()
            for otherid, other in self.adapters.items():
                assert other*b == (sp.eye(a.rows) if cid == otherid else sp.zeros(other.rows, a.rows)), (cid, otherid)
            parent = self.u*b
            self.lifts[cid] = [combine_tables((v, self.tables[i]) for (i, k), v in parent.todok().items() if k == j)
                               for j in range(parent.cols)]
            self.certificates.append({'component_id': cid, 'role_row_count': a.rows,
                                      'lift_inverse_residual': 'ZERO_EXACT', 'off_role_residual': 'ZERO_EXACT'})
        print('A3_COMPONENT_LIFTS', len(self.lifts), flush=True)

    @lru_cache(None)
    def physical_slot(self, index):
        return combine_tables((v, self.tables[i]) for (i, j), v in self.u[:, index].todok().items())

    def parent_coordinates_slot(self, coordinates):
        return combine_tables((v, self.tables[i]) for i, v in coordinates.items())
