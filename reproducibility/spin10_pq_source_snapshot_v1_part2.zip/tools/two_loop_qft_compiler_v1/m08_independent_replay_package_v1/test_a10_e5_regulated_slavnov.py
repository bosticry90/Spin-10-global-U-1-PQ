"""Regulated source operators, complete tangent coverage and failure controls."""
import unittest
from copy import deepcopy
from a10_e5_regulated_slavnov import *
from audit_a10_e5_regulated_slavnov import adjudicate,execution_matches


class RegulatedSlavnov(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.P=read(OUT/'primary.json');cls.R=read(OUT/'replay.json')

    def test_01_complete_route_identity_and_scope(self):
        r=adjudicate(self.P,self.R);self.assertEqual(r['scientific_gate'],STATUS)
        self.assertFalse(r['actual_one_loop_local_restoration_proved'])

    def test_02_full_tangent_stream_and_implicit_jets(self):
        t=self.P['complete_field_tangent'];self.assertEqual(t['all_directional_coefficients'],70935)
        self.assertEqual(t['derivative_order_counts'],{'0':70755,'1':180});self.assertTrue(t['no_coefficients_truncated'])
        self.assertEqual(t['canonical_row_stream_sha256'],self.R['complete_field_tangent']['canonical_row_stream_sha256'])

    def test_03_grassmann_right_derivative_orientation(self):
        w=alphabet();P=w.mul(w.var('C0'),w.var('C1'));grad=partials(P,w,{'C0','C1'})
        self.assertEqual(grad[('C0',())],w.var('C1'))
        self.assertEqual(grad[('C1',())],w.scale(w.var('C0'),-1))
        # Right derivative of an even ghost transformation has the opposite
        # sign to its left derivative. No ungraded matrix replacement is valid.
        right=w.scale(grad[('C0',())],-1);self.assertNotEqual(right,grad[('C0',())])

    def test_04_all_physical_heat_carriers_retained(self):
        m=self.P['specified_heat_measure'];self.assertEqual(len(m['diagonal_carriers']),13)
        self.assertEqual(sum(x['coordinates'] for x in m['diagonal_carriers']),643)
        self.assertEqual(m['raw_nonzero_diagonal_block_coefficients'],34544)
        self.assertTrue(all(x['all_45_generators_including_zeros_skew_and_real'] for x in m['diagonal_carriers']))

    def test_05_heat_trace_proof_for_arbitrary_symmetric_kernel(self):
        a,b,c,t=s.symbols('a b c t');K=s.Matrix([[a,b],[b,c]]);A=s.Matrix([[0,t],[-t,0]])
        self.assertEqual((K*A).trace(),0)
        self.assertNotEqual((s.Matrix([[a,b+1],[b,c]])*A).trace(),0)
        self.assertTrue(self.P['specified_heat_measure']['nonselfadjoint_profile_negative_control'])

    def test_06_bare_coordinate_metric_is_not_heat_metric(self):
        d=self.P['specified_heat_measure']['bare_canonical_transpose_negative_control']
        self.assertNotEqual(s.sympify(d['bare_transpose_defect']),0)
        self.assertFalse(self.P['specified_heat_measure']['continuum_measure_or_all_scheme_anomaly_freedom_proved'])

    def test_07_singlet_and_light_diagonal_zero(self):
        sectors={x['carrier']:x for x in self.P['specified_heat_measure']['diagonal_carriers']}
        for n in ('S','light_antighost','light_auxiliary'):self.assertEqual(sectors[n]['physical_coefficients'],0)
        self.assertEqual(sectors['heavy_antighost']['generator_stream_sha256'],sectors['heavy_auxiliary']['generator_stream_sha256'])

    def test_08_born_cyclic_derivative_cancels_n(self):
        for n in (1,2,3,7,13):
            terms=[(tuple('X'*i+'Y'+'X'*(n-i-1)),s.Rational(1,n)) for i in range(n)]
            self.assertEqual(word_add(terms),{cyclic(tuple('X'*(n-1)+'Y')):1})

    def test_09_inverse_cyclic_reduction_and_transpose_trace(self):
        self.assertEqual(reduce_gaussian(('G','AT','K')),('A',))
        self.assertEqual(reduce_gaussian(('G','K','A')),('A',))
        self.assertNotEqual(reduce_gaussian(('G','U')),())

    def test_10_missing_source_word_is_not_zero(self):
        d=word_identity('primary');self.assertTrue(d['nonlinear_source_correction_U_retained'])
        self.assertTrue(d['missing_source_correction_nonzero_word'])
        self.assertIn('(V_Lambda,Gamma1)',d['complete_retained_source_identity'])

    def test_11_actual_phi_coefficient_and_constant_parameter(self):
        d=self.P['actual_phi_cutoff_breaking'];self.assertEqual(d['real_coordinate_pair'],[0,2])
        loc={n:s.Symbol(n,positive=True) for n in ('p_E_squared','q_E_squared','Mref_squared','Lambda_squared')}
        loc['g10']=g;v=s.sympify(d['complete_tree_breaking_coefficient'],locals=loc)
        self.assertEqual(s.simplify(v.subs(loc['q_E_squared'],loc['p_E_squared'])),0)
        self.assertEqual(v.subs(g,0),0)
        self.assertEqual(s.limit(v,loc['Lambda_squared'],s.oo),0)

    def test_12_finite_cutoff_witness_is_not_local_or_boundary(self):
        d=self.P['actual_phi_cutoff_breaking'];v=s.sympify(d['selected_p2_1_q2_4_M2_1_Lambda2_2'],locals={'g10':g})
        self.assertNotEqual(v.subs(g,1),0);self.assertTrue(d['ghost_Euler_coefficient_nonzero'])
        self.assertTrue(d['other_regulator_carriers_have_no_two_phi_monomial'])
        self.assertTrue(d['finite_cutoff_breaking_is_not_finite_local_polynomial'])
        self.assertFalse(d['physical_action_failure_inferred'])

    def test_13_regulated_and_original_loop_operators_differ(self):
        c=self.P['retained_source_operator_control'];loc={'rCtl':s.Symbol('rCtl',positive=True)}
        original=s.sympify(c['original_Q_loop_variation'][0]['coefficient'],locals=loc)
        regulated=s.sympify(c['regulated_Q_loop_variation'][0]['coefficient'],locals=loc)
        correction=s.sympify(c['physical_source_derivative_correction'][0]['coefficient'],locals=loc)
        self.assertEqual(s.cancel(regulated-original-correction),0)
        self.assertNotEqual(correction.subs(loc['rCtl'],1),0)

    def test_14_corrected_insertion_identity_and_negative_control(self):
        c=self.P['retained_source_operator_control'];self.assertFalse(c['correct_original_identity_residual'])
        self.assertTrue(c['missing_source_correction_residual']);self.assertEqual(c['regulated_Q_loop_variation'],c['breaking_insertion'])
        self.assertTrue(c['all_fields_and_sources_retained']);self.assertTrue(c['no_EOM_used'])

    def test_15_actual_nonlinear_source_Hessian_reused(self):
        self.assertEqual(self.P['complete_source_Hessian_coefficients_authenticated'],73218)
        old=read(HERE/'frozen_a10_e5_full_hessian/primary.json')
        self.assertEqual(self.P['complete_source_Hessian_stream_sha256'],old['complete_source_and_GF_Hessian']['source_second_variation']['canonical_row_stream_sha256'])
        self.assertTrue(old['complete_source_and_GF_Hessian']['g0_xi_cubic_interaction_retained'])

    def test_16_ir_projection_and_contact_obligations_are_not_discharged(self):
        d=self.P['regulated_word_identity'];self.assertTrue(d['additional_IR_projection_breakings_required'])
        self.assertFalse(d['IR_projection_or_physical_measure_proved']);self.assertFalse(d['all_contact_identities_proved'])
        self.assertFalse(self.P['retained_source_operator_control']['full_643_field_amplitude_independently_integrated'])
        # Covariance of a Hessian does not prove invariance of its quadratic
        # action in affine total-connection coordinates.
        x,y,a,b,k,l,m,t=s.symbols('x y a b k l m t')
        z=s.Matrix([x,y]);shift=s.Matrix([a,b]);A=s.Matrix([[0,t],[-t,0]]);K=s.Matrix([[k,l],[l,m]])
        dK=-A.T*K-K*A
        variation=s.expand((z.T*K*(A*z+shift))[0]+(z.T*dK*z)[0]/2)
        self.assertEqual(s.simplify(variation-(z.T*K*shift)[0]),0)
        self.assertEqual(s.hessian(variation,(x,y)),s.zeros(2))
        self.assertNotEqual(variation,0)

    def test_17_overclaims_and_activation_rejected(self):
        for n in ('actual_one_loop_local_restoration_proved','all_probe_contact_identities_proved','quantum_A5_equivalence_proved',
          'full_M2_M5_A1_A5_proved','full_E5_PASS','full_anomaly_freedom_proved','sources_activated','HB1_C5_run','C1_GS_calculated'):
            a,b=deepcopy(self.P),deepcopy(self.R);a[n]=b[n]=True
            with self.assertRaises(AssertionError):adjudicate(a,b)

    def test_18_start_hash_and_predecessor_binding_reject_stale_data(self):
        f=next(read(p)['fingerprint'] for p in OUT.glob('primary_attempt_*.json') if read(p)['completed_evidence'])
        execution_matches(f);bad=deepcopy(f);bad['input_manifest_sha256']='stale'
        with self.assertRaises(AssertionError):execution_matches(bad)
        a,b=deepcopy(self.P),deepcopy(self.R);a['complete_Hessian_dependency_sha256']=b['complete_Hessian_dependency_sha256']='other'
        with self.assertRaises(AssertionError):adjudicate(a,b)


if __name__=='__main__':unittest.main()
