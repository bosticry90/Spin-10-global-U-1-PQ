"""Independent exact exterior differentiation; imports no stored R action."""
from collections import defaultdict
from itertools import combinations
import sympy as sp


def clean(value):
    return sp.cancel(sp.expand(value))


def wedge(left, right):
    if set(left) & set(right):
        return None, 0
    sign = -1 if sum(a > b for a in left for b in right) % 2 else 1
    return tuple(sorted(left+right)), sign


def add(target, word, value):
    if value:
        target[word] = clean(target.get(word, 0)+value)
        if target[word] == 0:
            del target[word]


def multiply(left, right):
    result = {}
    for lw, lv in left.items():
        for rw, rv in right.items():
            word, sign = wedge(lw, rw)
            if sign:
                add(result, word, sign*lv*rv)
    return result


def differentiate(poly, images):
    result = {}
    for word, coefficient in poly.items():
        for position, variable in enumerate(word):
            prefix = {word[:position]: (-1)**position*coefficient}
            suffix = {word[position+1:]: sp.Integer(1)}
            for output, value in multiply(multiply(prefix, images[variable]), suffix).items():
                add(result, output, value)
    return result


def column_matrix(rows):
    return sp.SparseMatrix(45, len(rows), {(entry['index'], j): sp.sympify(entry['coefficient'])
        for j, row in enumerate(rows) for entry in row['raw_so10_coordinates']})


def geometry(rep):
    pairs = list(combinations(range(10), 2))
    raw = []
    for a, b in pairs:
        raw.append(sp.SparseMatrix(10, 10, {(a, b): 1, (b, a): -1}))
    qh, qm = column_matrix(rep['h_basis']), column_matrix(rep['heavy_basis'])
    q = qh.row_join(qm)
    inverse = sp.SparseMatrix(q.inv())
    assert q.shape == (45, 45) and q*inverse == sp.eye(45)
    assert qh.T*qm == sp.zeros(12, 33)
    metric = q.T*q
    physical = [sum((v*raw[i] for (i, _), v in q[:, col].todok().items()),
                    sp.SparseMatrix(10, 10, {})) for col in range(45)]
    f = {}
    for j, k in combinations(range(45), 2):
        bracket = physical[j]*physical[k]-physical[k]*physical[j]
        coords = inverse*sp.Matrix([bracket[a, b] for a, b in pairs])
        for i, value in enumerate(coords):
            value = clean(value)
            if value:
                f[i, j, k] = value
                f[i, k, j] = -value
    assert not any(i >= 12 and j < 12 and k < 12 for i, j, k in f)
    assert not any(i < 12 and ((j < 12) != (k < 12)) for i, j, k in f)
    return {'Q': q, 'inverse': inverse, 'metric': metric, 'raw_f': f,
            'physical_matrices_raw': physical}


def ghost_algebra(f):
    # Raw constants are rescaled by 1/sqrt(2) for the action-normalized
    # parent matrices. The coefficient of g10 is kept separately.
    images = [{} for _ in range(45)]
    curvature = [{} for _ in range(12)]
    for (output, j, k), value in f.items():
        if j < k:
            add(images[output], (j, k), -value)
            if output < 12 and j >= 12:
                add(curvature[output], (j, k), -value)
    induced = [differentiate(poly, images) for poly in curvature]
    negative_adjoint = [{} for _ in range(12)]
    for (output, light, target), value in f.items():
        if output < 12 and light < 12 and target < 12:
            for word, coefficient in multiply({(light,): 1}, curvature[target]).items():
                add(negative_adjoint[output], word, -value*coefficient)
    assert induced == negative_adjoint, 'COMPOSITE_LIE_COVARIANCE_FAILED'
    nilpotence = [differentiate(image, images) for image in images]
    assert all(not poly for poly in nilpotence), 'PARENT_GHOST_NILPOTENCE_FAILED'
    assert all(all(word[0] < 12 and word[1] >= 12 for word in poly)
               for poly in induced), 'HEAVY_CUBIC_LEAKAGE'
    return {'images_raw': images, 'curvature_raw': curvature, 'induced_raw': induced,
            'parent_nilpotence_residuals': nilpotence}


def poly_payload(poly, scale=sp.Integer(1)):
    return [{'variables': list(word), 'coefficient': str(sp.factor(scale*coefficient))}
            for word, coefficient in sorted(poly.items())]


def matrix_payload(matrix):
    return {'shape': list(matrix.shape), 'entries': [[i, j, str(sp.factor(v))]
            for (i, j), v in sorted(matrix.todok().items())]}
