"""Own-byte read-only binding / corrected dependent comparison execution."""
import json,sys,time
from hashlib import sha256
from a10_e5_auxiliary_next_comparison_v3 import HERE,ROOT,OUT,read,build,compare,s


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    route,prepname=sys.argv[1:];assert route == 'comparison_v3'
    path=OUT/prepname/'preparation.json';prep=read(path)
    for n,h in prep['execution_bytes'].items():assert sha256((ROOT/n).read_bytes()).hexdigest()==h,n
    assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==prep['state_sha256']
    assert sha256((ROOT/prep['input_manifest']).read_bytes()).hexdigest()==prep['input_manifest_sha256']
    for n,h in prep['completed_actual_sha256'].items():assert sha256((OUT/(n+'.json')).read_bytes()).hexdigest()==h
    assert len(prep['completed_actual_sha256'])==2
    if route=='comparison_v3':
        assert len(prep['completed_bound_sha256'])==2
        for n,h in prep['completed_bound_sha256'].items():assert sha256((OUT/(n+'.json')).read_bytes()).hexdigest()==h
    writes=[]
    def hook(event,args):
        if event=='open' and len(args)>1 and isinstance(args[1],str) and any(k in args[1] for k in 'wax+'):
            writes.append(str(args[0]));raise PermissionError('AUXILIARY_BOUND_WORKER_WRITE_DENIED')
    sys.addaudithook(hook)
    print('EXECUTION '+json.dumps({'route':route,'preparation':path.relative_to(ROOT).as_posix(),
        'preparation_sha256':sha256(path.read_bytes()).hexdigest(),'execution_bytes':prep['execution_bytes'],
        'input_manifest_sha256':prep['input_manifest_sha256'],'state_sha256':prep['state_sha256'],
        'completed_actual_sha256':prep['completed_actual_sha256'],'completed_bound_sha256':prep['completed_bound_sha256'],
        'python':sys.version,'executable':sys.executable,'sympy':s.__version__,'guard_active':True},sort_keys=True,separators=(',',':')),flush=True)
    tick=time.perf_counter();result=compare(lambda n,f:f()) if route=='comparison_v3' else build(route.split('_')[0],lambda n,f:f())
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
    print('METRICS '+json.dumps({'execution_state':'COMPLETED','seconds':time.perf_counter()-tick,'write_attempts':writes},sort_keys=True,separators=(',',':')),flush=True)


if __name__=='__main__':main()
