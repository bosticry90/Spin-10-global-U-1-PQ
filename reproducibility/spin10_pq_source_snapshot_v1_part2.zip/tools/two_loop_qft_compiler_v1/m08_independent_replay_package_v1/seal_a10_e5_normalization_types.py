"""Seal validated bounded proof bytes without scientific authority promotion."""
from hashlib import sha256
import subprocess
from a10_e5_normalization_types import HERE, ROOT, OUT, read, BASE, STATUS
from validate_a10_e5_normalization_types import protected, new_files
from export_a10_e5_normalization_types import dump
from seal_a10_e5_quartic_companion import PARENTS as QUARTIC_PARENTS

PARENTS = (*QUARTIC_PARENTS, 'frozen_a10_e5_quartic_companion')


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED')
    assert not (OUT / 'bindings.json').exists(), 'NO_OVERWRITE'
    r = read(OUT / 'validation_receipt.json')
    assert r['status'] == 'PASS_BOUNDED_NORMALIZATION_TYPES_AND_CLASSICAL_SHEAR_ONLY'
    assert r['scientific_disposition'] == STATUS and r['fresh_routes_byte_identical'] == 2
    assert not r['audit_time_changes'] and r['historical_custody_exit'] == 2 and r['unresolved_historical_references'] == 7
    assert r['source_free_obstruction'] and not r['residual_fit'] and not r['new_loop_amplitudes_computed']
    assert not r['normalization_adopted'] and not r['quantum_A5_or_full_E5_PASS']
    assert protected() == r['protected_byte_sha256']
    for name, h in r['new_sha256'].items(): assert sha256((ROOT / name).read_bytes()).hexdigest() == h, name
    assert sha256((ROOT / 'project_state.json').read_bytes()).hexdigest() == r['state_sha256']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
    paths = new_files() + [OUT / 'validation_receipt.json']; assert len(PARENTS) == 32
    dump(OUT / 'bindings.json', {'schema': 'E5_NORMALIZATION_TYPES_BINDINGS_V1', 'base_commit': BASE,
        'byte_sha256': {p.relative_to(ROOT).as_posix(): sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))},
        'inherited_manifest_sha256': {(HERE / n / 'bindings.json').relative_to(ROOT).as_posix(): sha256((HERE / n / 'bindings.json').read_bytes()).hexdigest() for n in PARENTS},
        'state_sha256': r['state_sha256'], 'scientific_disposition': STATUS,
        'source_free_repair_obstructed_with_prior_matches_fixed': True, 'classical_auxiliary_shear_prerequisite_qualified': True,
        'quartic_residual_fit': False, 'preceding_quartic_failure_replaced': False, 'new_loop_amplitudes_computed': False,
        'normalization_adopted': False, 'sources_activated': False, 'auxiliaries_eliminated': False,
        'quantum_A5_or_full_E5_PASS': False, 'HB1_C5_run': False, 'C1_GS_calculated': False,
        'authority_changed': False, 'whole_goal_complete': False, 'remote_push': False, 'external_endorsement': False})
    print('SEALED source-free obstruction and classical shear prerequisite; whole goal incomplete')


if __name__ == '__main__': main()
