"""Scientific controls for the typed obstruction and nonlinear shear."""
import unittest
from audit_a10_e5_normalization_types import agreement, independent_checks
from a10_e5_normalization_types import carriers, left_gradients, canonical_pairing, alphabet, canonical, s


class NormalizationTypesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.result = agreement(); cls.shear = cls.result['classical_auxiliary_shear']

    def test_complete_carrier_types(self):
        self.assertEqual(len(carriers()['quartet_carrier_types']), 5)
        self.assertEqual(carriers(), self.result['carrier_classification'])

    def test_no_source_free_repair(self):
        self.assertTrue(self.result['source_free_obstruction']['no_source_free_repair_with_prior_width_and_full_cubic_fixed'])

    def test_physical_curvature_span(self):
        self.assertTrue(self.result['source_free_obstruction']['curvature_in_H_connection_span'])

    def test_skew_alone_insufficient(self):
        self.assertTrue(self.result['source_free_obstruction']['non_H_skew_control_Q_image'])

    def test_abstract_commutator_derivation(self):
        self.assertTrue(independent_checks()['abstract_commuting_skew_proof'])

    def test_left_gradient_even_variable_has_no_odd_prefix_sign(self):
        w = alphabet(); P = w.mul(w.var('C12'), w.var('L12'), w.var('ub13'))
        self.assertEqual(left_gradients(P, w)['L12'], canonical(w.EL(P, 'L12')))

    def test_left_gradient_odd_sign(self):
        w = alphabet(); P = w.mul(w.var('JL12'), w.var('ub13'), w.var('C14'))
        for name in ['JL12', 'ub13', 'C14']:
            self.assertEqual(left_gradients(P, w)[name], canonical(w.EL(P, name)))

    def test_canonical_pairings_have_nonzero_sign_control(self):
        self.assertFalse(self.shear['all_elementary_bracket_residuals'])
        self.assertTrue(self.shear['wrong_source_sign_pairing_residual'])

    def test_generic_auxiliary_shear_pairing(self):
        w = alphabet(); K = w.mul(w.var('JL12'), w.var('ub13'), w.var('C14'))
        E = left_gradients(K, w); Y = {}
        for z, J in w.pairs:
            for n, P in [(z, w.scale(E.get(J, {}), -(-1)**w.p[z])), (J, w.scale(E.get(z, {}), (-1)**w.p[z]))]:
                if P: Y[n] = P
        self.assertFalse(canonical_pairing(Y, w))
        wrong = dict(Y); wrong['Jub13'] = w.scale(wrong['Jub13'], -1)
        self.assertTrue(canonical_pairing(wrong, w))

    def test_all_generator_slots_and_exact_inverse(self):
        self.assertTrue(self.shear['all1286_columns_checked'])
        self.assertEqual(self.shear['exact_both_direction_inverse_checks'], 2572)

    def test_local_H_and_real_pairing(self):
        self.assertEqual(len(self.shear['local_H']['all12_background_H_identities']), 12)
        self.assertTrue(self.shear['physical_real_generator'])

    def test_full_quartet_image(self):
        self.assertTrue(self.shear['all980100_image_slots_defined'])
        self.assertEqual(len(self.shear['quartet_image']), self.shear['quartet_image_nonzero_slots'])

    def test_companions_and_prior_projections(self):
        self.assertTrue(self.shear['image_type_coupling_inventory'])
        self.assertTrue(self.shear['prior_source_ghost_mixing_width_cubic_projections_preserved'])
        self.assertEqual(self.shear['zero_full_images_at_prior_orders'], [[0, 2], [1, 1], [1, 2]])
        self.assertTrue(all(self.shear['companion_omission_controls'].values()))

    def test_preserved_unlowered_H_failure(self):
        r = self.shear['unlowered_V1_H_failure_control']
        self.assertEqual(r['nonzero_failed_rows'], 152)
        self.assertFalse(r['accepted_generator'])
        self.assertEqual(r['nonzero_failed_rows'], len(r['exact_residual']))

    def test_typed_orbit_grade_is_retained(self):
        self.assertEqual(self.shear['inherited_coefficient_dimensions'], {'OrbitPullback': 1})
        self.assertEqual(len(self.shear['typed_dimension_one_OrbitPullback_image']), 3936)

    def test_nonlinear_jet_control(self):
        self.assertTrue(self.shear['second_jet_omission_residual'])

    def test_Berezinian_and_mean_field_not_conflated(self):
        self.assertEqual(self.shear['integrated_field_Berezinian']['value'], '1')
        self.assertNotEqual(self.shear['quantum_mean_field_control']['mean_aC'], self.shear['quantum_mean_field_control']['product_of_means'])
        self.assertFalse(self.shear['classical_canonical_flow_is_quantum_A5'])

    def test_no_residual_fit_or_new_loops(self):
        self.assertFalse(self.shear['quartic_residual_read_or_fitted'])
        self.assertFalse(self.shear['actual_new_loop_amplitudes_computed'])

    def test_previous_failure_and_whole_goal_retained(self):
        self.assertFalse(self.result['preceding_quartic_failure_replaced'])
        self.assertFalse(self.result['whole_goal_complete'])


if __name__ == '__main__': unittest.main()
