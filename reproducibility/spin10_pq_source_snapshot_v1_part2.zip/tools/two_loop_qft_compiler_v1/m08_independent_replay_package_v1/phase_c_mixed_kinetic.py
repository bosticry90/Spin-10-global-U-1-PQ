"""First closed interacting H/heavy kinetic gate; no active M08 write."""
import itertools
import json
from hashlib import sha256
import sympy as s
from phase_c_mixed_source import geometry, IDS, H, M, g
from nonminimal_bv_m08_architecture import load
from interacting_actual_h_preflight import GaugeJets, FailedIdentity
from nonminimal_bv_free import ETA


def build(stage=lambda n,fn:fn()):
    f,_=stage('closed_mixed_geometry',geometry)
    basis=load('frozen_c3/C3_representation_basis.json')
    frame=s.Matrix(45,45,lambda i,j:next((s.sympify(v['coefficient']) for v in (basis['h_basis']+basis['heavy_basis'])[j]['raw_so10_coordinates'] if v['index']==i),0))
    G=(frame.T*frame).extract(IDS,IDS)
    j=GaugeJets(0); a=j.a
    # A gauge/ghost gate; nonminimal coordinates passed separately, not yet
    # inferred to be integrated with gauge fixing or the physical scalar.
    j.fields={**{f'q{i}_{mu}':(1,0,0) for mu in range(4) for i in IDS},**{'C'+str(i):(1,1,1) for i in IDS}}
    j.pairs=[(z,'J'+z) for z in j.fields]
    j.grades={**j.fields,**{J:(3-j.fields[z][0],-1-j.fields[z][1],1-j.fields[z][2]) for z,J in j.pairs}}
    j.external={f'A{i}_{mu}':(1,0,0) for mu in range(4) for i in H}
    x={n:j.var(n) for n in j.grades|j.external}
    plus=lambda v,w:[a.add(z,y) for z,y in zip(v,w)]
    scale=lambda v,k:[a.scale(z,k) for z in v]
    comm=lambda v,w:[a.add(*(a.scale(a.mul(v[b],w[c]),f.get((i,IDS[b],IDS[c]),0)) for b,c in itertools.product(range(10),repeat=2))) for i in IDS]
    B=[[a.add(x[f'q{i}_{mu}'],x.get(f'A{i}_{mu}',{})) for i in IDS] for mu in range(4)]
    C=[x['C'+str(i)] for i in IDS]
    F={(mu,nu):plus(plus([j.D(z,mu) for z in B[nu]],scale([j.D(z,nu) for z in B[mu]],-1)),scale(comm(B[mu],B[nu]),g)) for mu,nu in itertools.combinations(range(4),2)}
    S0=a.add(*(a.scale(a.mul(v[i],v[k]),-G[i,k]*ETA[mu]*ETA[nu]/2) for (mu,nu),v in F.items() for i,k in itertools.product(range(10),repeat=2) if G[i,k]))
    q={f'q{i}_{mu}':P for mu in range(4) for i,P in zip(IDS,plus([j.D(z,mu) for z in C],scale(comm(B[mu],C),g)))}
    q.update({'C'+str(i):P for i,P in zip(IDS,scale(comm(C,C),-g/2))})
    def zero(P,label):
        if P: raise FailedIdentity(label,P,j)
    def field_checks():
        for n in j.fields: zero(j.Q(q[n],q),'mixed_forward_square_'+n)
        for pair,v in F.items():
            target=scale(comm(v,C),g)
            for i,P in enumerate(v): zero(a.add(j.Q(P,q),a.scale(target[i],-1)),'mixed_curvature_'+str((pair,IDS[i])))
        zero(j.Q(S0,q),'mixed_physical_kinetic_invariance')
    stage('mixed_interacting_forward_and_kinetic',field_checks)
    S=a.add(S0,*(a.mul(x[J],q[z]) for z,J in j.pairs))
    Q=stage('mixed_complete_Euler_source_columns',lambda:j.columns(S))
    def source_checks():
        for n in j.grades: zero(j.Q(Q[n],Q),'mixed_full_square_'+n)
        for z in j.fields: zero(a.add(Q[z],a.scale(q[z],-1)),'mixed_derived_forward_'+z)
    stage('mixed_source_nilpotence',source_checks)
    half=a.scale(j.bracket(S,S),s.Rational(1,2))
    currents=stage('mixed_master_current',lambda:j.current4(half))
    def summary(P):
        r=j.record(P); raw=json.dumps(r,sort_keys=True,separators=(',',':')).encode()
        return {'terms':len(r),'canonical_sha256':sha256(raw).hexdigest()}
    return {'schema':'PHASE_C_MIXED_KINETIC_GATE_V1','status':'PASS_CLOSED_MIXED_KINETIC_GATE_ONLY','ids':IDS,'pairs':50,'generators':100,'spacetime_directions':4,
        'kinetic':summary(S0),'master_action':summary(S),'images':{n:summary(P) for n,P in Q.items()},'half_master':summary(half),'explicit_currents':[summary(P) for P in currents],
        'counts':{'forward_squares':50,'curvature_covariance':60,'full_squares':100,'forward_recovery':50},
        'physical_gauge_interactions':{'cubic_and_quartic_retained':True,'non_symmetric_heavy_bracket_retained':True},
        'maximum_jet_order':j.max_order,'EOM_used':False,'physical_scalar_or_gauge_fixing_tested':False,'full_M08_qualified':False,'active_sources_added':False,'formal_authority':'34/39_UNCHANGED'}


if __name__=='__main__':
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    try: result=build(lambda n,fn:(print('STAGE '+n,flush=True),fn())[1])
    except FailedIdentity as e: result={'schema':'PHASE_C_MIXED_KINETIC_GATE_V1','status':'FAILED_FIRST_PREREQUISITE','witness':e.evidence,'full_M08_qualified':False,'active_sources_added':False,'formal_authority':'34/39_UNCHANGED'}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
