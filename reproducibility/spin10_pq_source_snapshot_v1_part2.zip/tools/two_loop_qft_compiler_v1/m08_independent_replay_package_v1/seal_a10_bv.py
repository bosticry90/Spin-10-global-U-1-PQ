"""Byte-seal the bounded negative finding only after read-only validation."""
from pathlib import Path
from hashlib import sha256
import json,subprocess
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];OUT=HERE/'frozen_a10_bv_master'
FILES=('A10_BV_MASTER_CONTRACT_V1.md','A10_BV_MASTER_RESULT.md','A10_BV_TECHNICAL_REVIEW_PACKET_V1.md',
       'a10_bv_common.py','a10_bv_primary.py','a10_bv_replay.py','a10_bv_physical.py',
       'a10_bv_gauge_euler_replay.py','assemble_a10_bv_candidate.py','audit_a10_bv.py',
       'export_a10_bv_evidence.py','export_a10_bv_receipt.py','run_a10_bv.py',
       'test_a10_bv.py','validate_a10_bv.py','seal_a10_bv.py')
def digest(path):return sha256(path.read_bytes()).hexdigest()
def main():
    assert not (OUT/'bindings.json').exists(),'ALREADY_SEALED'
    receipt=json.loads((OUT/'validation_receipt.json').read_bytes())
    assert receipt['status']=='PASS_BOUNDED_FAILURE_EVIDENCE_VALIDATION_ONLY'
    assert receipt['scientific_gate']=='STOP_GATE_3_CANONICAL_GAUGE_EULER_TRANSLATION_FAILED'
    assert receipt['targeted_regression_tests']==75 and receipt['historical_custody_exit']==2
    assert not receipt['audit_time_changes']
    state=digest(ROOT/'project_state.json');assert state==receipt['live_state_transaction_sha256']
    from audit_a10_bv import authenticate
    assert authenticate()['scientific_gate']==receipt['scientific_gate']
    files=[HERE/n for n in FILES]+[ROOT/'docs/A10_BV_MASTER_CURRENT.md']
    files+=sorted(p for p in OUT.glob('*.json') if p.name!='bindings.json')
    assert all(b'\r\n' not in p.read_bytes() for p in files)
    manifests=[HERE/n/'bindings.json' for n in ('frozen_source_component_decoder','frozen_phase_c_scalar_action',
        'frozen_a10_physical_reconciliation','frozen_a10_executable_reconciliation','frozen_a10_cotangent_adapter')]
    result={'schema':'A10_BV_MASTER_STOP_BYTE_BINDINGS_V1',
       'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
       'byte_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in files},
       'inherited_manifest_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in manifests},
       'state_sha256':state,'scientific_disposition':receipt['scientific_gate'],
       'authority_changed':False,'candidate_adopted':False,'sources_activated':False,
       'full_master_action_qualified':False,'Stage_E_reached':False,'personal_outreach':False,'remote_push':False,
       'post_validation_finalization':'receipt export and byte sealing only; no scientific files altered after validation'}
    (OUT/'bindings.json').write_bytes(json.dumps(result,sort_keys=True,separators=(',',':')).encode()+b'\n')
    print('SEALED '+str(len(files))+' files; custody remains exit 2',flush=True)
if __name__=='__main__':main()
