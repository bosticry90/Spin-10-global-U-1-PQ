"""Replay's distinct E1 schema: derive declared dimensions and vacuum type checks.

No numerical input or protected record is changed. Only the local metadata
argument of the shared dimension lift is supplied in its stated typed schema.
"""
import json,sys,time
from copy import deepcopy
from hashlib import sha256
import a10_e5_nonminimal_retract as retract

original_lift=retract.vacuum_dimension_lift
original_operations=retract.replay_ops


def canonical_replay_operations(*args,**kwargs):
    values=list(original_operations(*args,**kwargs))
    # The closed replay formula sums two polynomials. Drop only exact symbolic
    # zero terms before structural equality; do not alter its mathematical map.
    values[4]={name:retract.canonical(P) for name,P in values[4].items()}
    return tuple(values)


def replay_typed_lift(w,e1,A,route):
    assert route=='replay'
    typed=retract.read(retract.HERE/'frozen_a10_e1_fermion/M08_PHYSICAL_FRAME_GAUGE_FERMION_V1.json')
    dimensions=typed['coefficient_mass_dimensions']
    assert dimensions=={'Gram':0,'OrbitPullback':1,'eta_H':0,'f':0,'xi':0}
    v=retract.read(retract.HERE/'frozen_a10_physical_reconciliation/full_replay.json')['vacuum']
    orbit=retract.mat(v['orbit']);vacuum=retract.mat(v['VEV'])
    assert orbit.shape==(328,45) and vacuum.shape==(328,1)
    assert (orbit.T*vacuum).applyfunc(retract.clean)==retract.s.zeros(45,1)
    data=deepcopy(e1)
    data['geometry']['coefficient_mass_dimensions']=dimensions
    data['geometry']['O_transpose_v_zero']=True
    # The numerical action, chart, covectors and tensor records remain exact.
    assert {k:v for k,v in data.items() if k!='geometry'}=={k:v for k,v in e1.items() if k!='geometry'}
    return original_lift(w,data,A,route)


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    assert len(sys.argv)==2 and sys.argv[1]=='replay'
    writes=[]
    def hook(event,args):
        if event=='open' and len(args)>1 and isinstance(args[1],str) and any(k in args[1] for k in 'wax+'):
            writes.append(str(args[0]));raise PermissionError('E5_NONMINIMAL_RETRACT_WRITE_DENIED')
    sys.addaudithook(hook)
    names=('A10_E5_NONMINIMAL_RETRACT_CONTRACT_V1.md','A10_E5_NONMINIMAL_RETRACT_DERIVATION_V1.md',
           'a10_e5_nonminimal_retract.py','run_a10_e5_nonminimal_retract_replay.py')
    fingerprint={'schema':'E5_NONMINIMAL_RETRACT_EXECUTION_START_V1','route':'replay',
      'implementation_and_contract_sha256':{n:sha256((retract.HERE/n).read_bytes()).hexdigest() for n in names},
      'input_manifest_sha256':sha256((retract.HERE/'frozen_a10_e5_coupling_ring/bindings.json').read_bytes()).hexdigest(),
      'state_sha256':sha256((retract.ROOT/'project_state.json').read_bytes()).hexdigest(),
      'python':sys.version,'executable':sys.executable,'sympy':retract.s.__version__,'guard_active':True}
    print('EXECUTION '+json.dumps(fingerprint,sort_keys=True,separators=(',',':')),flush=True)
    print('TYPE_ADAPTER frozen executable E1 dimensions; fresh replay O^T v=0; numerical input records unchanged',flush=True)
    stages=[];started=time.perf_counter()
    def stage(n,fn):
        print('STAGE '+n,flush=True);tick=time.perf_counter();value=fn()
        stages.append({'name':n,'seconds':time.perf_counter()-tick});return value
    retract.vacuum_dimension_lift=replay_typed_lift
    retract.replay_ops=canonical_replay_operations
    result=retract.build('replay',stage)
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
    print('METRICS '+json.dumps({'stages':stages,'seconds':time.perf_counter()-started,
       'execution_state':'COMPLETED','write_attempts':writes},sort_keys=True),flush=True)


if __name__=='__main__':main()
