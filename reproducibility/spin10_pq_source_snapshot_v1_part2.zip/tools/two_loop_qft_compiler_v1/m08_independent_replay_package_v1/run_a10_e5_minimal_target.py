"""Read-only new bounded route; start bindings precede all calculations."""
import json,sys,time
from hashlib import sha256
from a10_e5_minimal_target import HERE,ROOT,build,s


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    assert len(sys.argv)==2 and sys.argv[1] in ('primary','replay')
    writes=[]
    def hook(event,args):
        if event=='open' and len(args)>1 and isinstance(args[1],str) and any(k in args[1] for k in 'wax+'):
            writes.append(str(args[0]));raise PermissionError('E5_MINIMAL_TARGET_WRITE_DENIED')
    sys.addaudithook(hook)
    names=('A10_E5_MINIMAL_TARGET_CONTRACT_V1.md','A10_E5_MINIMAL_TARGET_DERIVATION_V1.md',
      'A10_E5_MINIMAL_TARGET_CONTRACT_V2.md','A10_E5_MINIMAL_TARGET_DERIVATION_V2.md',
      'a10_e5_minimal_target.py','run_a10_e5_minimal_target.py')
    fingerprint={'schema':'E5_MINIMAL_TARGET_EXECUTION_START_V2','route':sys.argv[1],
      'implementation_and_contract_sha256':{n:sha256((HERE/n).read_bytes()).hexdigest() for n in names},
      'input_manifest_sha256':sha256((HERE/'frozen_a10_e5_nonminimal_retract/bindings.json').read_bytes()).hexdigest(),
      'state_sha256':sha256((ROOT/'project_state.json').read_bytes()).hexdigest(),
      'python':sys.version,'executable':sys.executable,'sympy':s.__version__,'guard_active':True}
    print('EXECUTION '+json.dumps(fingerprint,sort_keys=True,separators=(',',':')),flush=True)
    stages=[];started=time.perf_counter()
    def stage(n,fn):
        print('STAGE '+n,flush=True);tick=time.perf_counter();value=fn()
        stages.append({'name':n,'seconds':time.perf_counter()-tick});return value
    result=build(sys.argv[1],stage)
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
    print('METRICS '+json.dumps({'stages':stages,'seconds':time.perf_counter()-started,
      'execution_state':'COMPLETED','write_attempts':writes},sort_keys=True),flush=True)


if __name__=='__main__':main()
