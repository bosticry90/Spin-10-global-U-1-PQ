"""Independent ordered-word local residual/source replay; stdout only.

No primary model, columns or output imported. Python/SymPy and conventions
remain shared. The physical model grammar is retained from the earlier replay.
"""
import json
import sympy as s
from partial_gauge_bv_bridge_replay import PartialWords


def setup(stage=None):
    if not __debug__: raise RuntimeError("ASSERTIONS_REQUIRED")
    if stage is None: stage=lambda name,fn:fn()
    w=PartialWords(); names=tuple(w.p); x={n:w.var(n) for n in names}
    g,h,xi,v=s.symbols("g h xi v"); metric=(1,-1,-1,-1)
    def cross(X,Y):
        return [w.add(w.mul(X[(k+1)%3],Y[(k+2)%3]),w.scale(w.mul(X[(k+2)%3],Y[(k+1)%3]),-1)) for k in range(3)]
    def dot(X,Y): return w.add(*(w.mul(a,b) for a,b in zip(X,Y)))
    def t(X): return [w.scale(X[1],-1),X[0],{}]
    A=[[x[f"A{k}{m}"] for k in range(3)] for m in range(4)]
    p=[x[f"p{k}"] for k in range(3)]; eta=[p[0],p[1],w.add(p[2],{():v})]
    C=[x[f"c{k}"] for k in range(3)]; bar=[x["bar0"],x["bar1"],{}]; b=[x["b0"],x["b1"],{}]
    R=w.scale(w.mul(C[0],C[1]),-1)
    kinetic={}; curvature={}; cov=[]
    for m in range(4):
        for n in range(m+1,4):
            ac=cross(A[m],A[n]); f=[w.add(w.D(A[n][k],m),w.scale(w.D(A[m][k],n),-1),w.scale(ac[k],g)) for k in range(3)]
            curvature[m,n]=f; kinetic=w.add(kinetic,w.scale(dot(f,f),-metric[m]*metric[n]/s.Integer(2)))
        cov.append([w.add(w.D(eta[k],m),w.scale(cross(A[m],eta)[k],g)) for k in range(3)])
    rad=w.add(dot(eta,eta),{():-v*v})
    S0=w.add(kinetic,*(w.scale(dot(y,y),metric[m]/s.Integer(2)) for m,y in enumerate(cov)),w.scale(w.mul(rad,rad),-h/4))
    forward={}
    for m in range(4):
        for k in range(3): forward[f"A{k}{m}"]=w.add(w.D(C[k],m),w.scale(cross(A[m],C)[k],g))
    for k in range(3):
        forward[f"p{k}"]=w.scale(cross(C,eta)[k],-g); forward[f"c{k}"]=w.scale(cross(C,C)[k],-g/2)
    for k in range(2):
        forward[f"bar{k}"]=w.add(w.scale(b[k],-1),w.scale(w.mul(C[2],t(bar)[k]),-g))
        forward[f"b{k}"]=w.add(w.scale(w.mul(C[2],t(b)[k]),-g),w.scale(w.mul(R,t(bar)[k]),-g*g))
    Smin=w.add(S0,*(w.mul(x[J],forward[z]) for z,J in w.pairs))
    G=[]; gold=cross([{},{},{():v}],p)
    for k in range(2):
        # Explicit two-dimensional rotation, not the primary epsilon grammar.
        G.append(w.add(*(w.scale(w.add(w.D(A[m][k],m),w.scale(w.mul(A[m][2],t(A[m])[k]),g)),metric[m]) for m in range(4)),w.scale(gold[k],-xi*g)))
    psi=dot(bar[:2],[w.add(G[k],w.scale(b[k],-xi/2)) for k in range(2)])
    Qmin=stage("word_partial_minimal_columns",lambda:w.columns(Smin))
    gf=w.Q(psi,Qmin); S=w.add(Smin,gf)
    Q=stage("word_partial_fixed_columns",lambda:w.columns(S))
    for z in forward: assert Q[z]==Qmin[z]==forward[z],"forward "+z
    assert w.Q(S0,Q)=={}
    for m in range(4):
        for k in range(3): assert w.Q(cov[m][k],Q)==w.scale(cross(C,cov[m])[k],-g)
    for f in curvature.values():
        for k in range(3): assert w.Q(f[k],Q)==w.scale(cross(C,f)[k],-g)
    L={n:{} for n in names}
    for prefix,mus in (("A",range(4)),("JA",range(4)),("p",[None]),("Jp",[None]),("c",[None]),("Jc",[None]),("bar",[None]),("Jbar",[None]),("b",[None]),("Jb",[None])):
        for mu in mus:
            tail="" if mu is None else str(mu)
            L[prefix+"0"+tail]=x[prefix+"1"+tail]; L[prefix+"1"+tail]=w.scale(x[prefix+"0"+tail],-1)
    I={n:{} for n in names}; I["c2"]={():s.Integer(1)}
    lie=lambda P:w.act(P,L,0)
    contract=lambda P:w.act(P,I,1)
    assert Q["c2"]==w.scale(R,g) and w.Q(R,Q)=={}
    assert lie(psi)==contract(psi)=={} and w.strip(gf)==gf
    return w,names,x,g,h,xi,v,A,p,eta,C,bar,b,R,S0,forward,Smin,G,psi,Qmin,gf,S,Q,L,I


def bracket(w,F,H):
    # Right variation is derived from left variation for homogeneous F.
    parity=next((sum(w.p[n] for n,J in word)%2 for word in F),0)
    assert all(sum(w.p[n] for n,J in word)%2==parity for word in F)
    return w.add(*(w.scale(w.add(
        w.scale(w.mul(w.EL(F,z),w.EL(H,J)),(-1)**(w.p[z]*(parity+1))),
        w.scale(w.mul(w.EL(F,J),w.EL(H,z)),-(-1)**(w.p[J]*(parity+1)))),(-1)**w.p[z]) for z,J in w.pairs))


def build(stage=None):
    if not __debug__: raise RuntimeError("ASSERTIONS_REQUIRED")
    if stage is None: stage=lambda n,f:f()
    w,names,x,g,h,xi,v,A,p,eta,C,bar,b,R,S0,forward,Smin,G,psi,Qmin,gf,S,Q,L,I=setup(stage)
    w.p["omega"]=0; om=w.var("omega")
    fields=[z for z,J in w.pairs]
    physical={z:w.scale(w.mul(om,L[z]),g) for z in fields}
    for mu in range(4): physical[f"A2{mu}"]=w.D(om,mu)
    generator=w.add(*(w.scale(w.mul(x[J],physical[z]),-(-1)**w.p[z]) for z,J in w.pairs))
    T=stage("word_local_cotangent_lift",lambda:{n:bracket(w,generator,x[n]) for n in names})
    for z in fields: assert T[z]==physical[z],"physical lift "+z
    for z,J in w.pairs: assert T[J]==w.scale(w.mul(om,L[J]),g),"dual lift "+J
    Iom={n:{} for n in names}; Iom["c2"]=om
    act=lambda P:w.act(P,T,0)
    contract=lambda P:w.act(P,Iom,1)
    lie=lambda P:w.act(P,L,0)
    ig=lambda P:w.act(P,I,1)
    def compatibility():
        for n in names:
            assert w.add(contract(Q[n]),w.Q(Iom[n],Q))==T[n],"local iQ "+n
            assert w.add(act(Q[n]),w.scale(w.Q(T[n],Q),-1))=={},"local TQ "+n
            assert w.add(ig(Q[n]),w.Q(I[n],Q))==w.scale(L[n],g)
            assert w.add(lie(Q[n]),w.scale(w.Q(L[n],Q),-1))=={}
            assert w.add(lie(I[n]),w.scale(ig(L[n]),-1))=={} and ig(I[n])=={}
            for mu in range(4):
                assert act(w.D(x[n],mu))==w.D(T[n],mu)
                assert contract(w.D(x[n],mu))==w.D(Iom[n],mu)
        for z,J in w.pairs:
            assert w.add(act(bracket(w,x[z],x[J])),w.scale(bracket(w,T[z],x[J]),-1),w.scale(bracket(w,x[z],T[J]),-1))=={}
        for prefix in ("A","p","c","bar","b"):
            for mu in (range(4) if prefix=="A" else [None]):
                tail="" if mu is None else str(mu)
                pair=w.add(*(w.mul(x["J"+prefix+str(k)+tail],x[prefix+str(k)+tail]) for k in range(2)))
                assert act(pair)=={}
        M=w.EL(S,"c2"); assert M==w.EL(Smin,"c2")
        current=[w.scale(w.mul(om,x[f"JA2{mu}"]),-1) for mu in range(4)]
        assert w.add(generator,w.scale(w.mul(om,M),-1))==w.add(*(w.D(t,mu) for mu,t in enumerate(current)))
        return M,current
    M,current=stage("word_complete_local_source_identities",compatibility)
    replace={"omega":w.scale(R,-g)}
    TR={n:w.replace(T[n],replace) for n in names}
    delta={n:w.strip(Q[n]) for n in names if n!="c2"}
    assert w.Q(R,delta)=={}
    def closure():
        for n in delta: assert w.Q(delta[n],delta)==TR[n],"local Cartan square "+n
        for n in delta:
            for mu in range(4): assert w.Q(w.Q(w.var(n,(mu,)),delta),delta)==w.D(TR[n],mu),"Cartan jet "+n
        return list(delta)
    passed=stage("word_complete_local_Cartan_square",closure)
    actual=w.Q(delta["Jc0"],delta)
    before=bracket(w,w.replace(generator,replace),x["Jc0"])
    bad_order=w.add(actual,w.scale(before,-1))
    chain=w.scale(w.mul(w.EL(R,"c0"),M),-g)
    assert bad_order==chain and bad_order
    connection=w.Q(delta["A20"],delta)
    assert connection==TR["A20"]==w.scale(w.D(R,0),-g)
    paired=w.mul(x["JA20"],connection); assert w.EL(paired,"JA20")==connection
    density=w.mul(x["JA20"],x["A20"])
    density_square=w.Q(w.Q(density,delta),delta)
    assert density_square==w.act(density,TR,0)
    assert w.strip(M)==M and lie(M)=={} and M
    def ward():
        rotation=[w.scale(G[1],-1),G[0]]
        for k in range(2): assert act(G[k])==w.scale(w.mul(om,rotation[k]),-g)
        assert all(act(P)==contract(P)=={} for P in (S0,psi,gf))
        assert w.Q(S0,Q)=={}
        return {"arbitrary_parameter_jets":True,"G_covariant":True,"S0_psi_GF_pointwise_invariant_and_horizontal":True,"residual_connection_dynamical_not_background":True}
    ward_data=stage("word_partial_local_Ward",ward)
    def squares():
        for n in names:
            assert w.Q(Qmin[n],Qmin)=={},"minimal Q square "+n
            assert w.Q(Q[n],Q)=={},"fixed Q square "+n
            for mu in range(4):
                assert w.Q(w.D(x[n],mu),Q)==w.D(Q[n],mu)
                assert w.Q(w.Q(w.var(n,(mu,)),Q),Q)=={},"Q jet square "+n
        return 264
    count=stage("word_complete_partial_Q_squares",squares)
    def masters():
        out={}
        for label,Lx,images in (("minimal",Smin,Qmin),("partial_fixed",S,Q)):
            half=w.add(*(w.mul(w.EL(Lx,z),images[z]) for z,J in w.pairs))
            assert all(w.EL(half,n)=={} for n in names)
            current=w.boundary(half)
            out[label]={"half_density":w.record(half),"current":[w.record(t) for t in current],"all_Euler_residuals_zero":True}
        return out
    master=stage("word_partial_master_currents",masters)
    def transport():
        shifts={J:w.scale(w.EL(psi,z),-(-1)**w.p[z]) for z,J in w.pairs}
        pos={n:w.add(x[n],shifts.get(n,{})) for n in names}; neg={n:w.add(x[n],w.scale(shifts.get(n,{}),-1)) for n in names}
        transformed=w.replace(Smin,pos); current=w.boundary(w.add(transformed,w.scale(S,-1)))
        for n in names:
            assert w.replace(w.replace(x[n],pos),neg)==x[n]
            assert w.Q(w.replace(x[n],pos),Q)==w.replace(Qmin[n],pos)
            assert act(w.replace(x[n],pos))==w.replace(T[n],pos)
            assert contract(w.replace(x[n],pos))==w.replace(Iom[n],pos)
        assert w.replace(transformed,neg)==Smin
        return {"shifts":{n:w.record(shifts.get(n,{})) for n in names},"action_difference_current":[w.record(t) for t in current],"inverse_intertwining_local_equivariance":True}
    trans=stage("word_partial_canonical_gauge_fixing",transport)
    def controls():
        quartic={word:co for word,co in gf.items() if len(word)==4 and set(word)=={(n,()) for n in ("bar0","bar1","c0","c1")}}
        assert quartic and w.Q(gf,delta)=={}
        omitted=w.Q(w.add(gf,w.scale(quartic,-1)),delta); assert omitted
        wrong=dict(Q); wrong.update({f"p{k}":w.scale(Q[f"p{k}"],-1) for k in range(3)})
        scalar_bad=w.Q(wrong["p0"],wrong); assert scalar_bad
        bad=dict(Q)
        for k in range(2): bad[f"b{k}"]=w.add(Q[f"b{k}"],w.scale(w.mul(R,w.scale(bar[1],-1) if k==0 else bar[0]),g*g))
        aux_bad=w.Q(bad["bar0"],bad); assert aux_bad
        broken=w.add(S,*(w.scale(w.mul(x[f"Jbar{k}"],Q[f"bar{k}"]),-1) for k in range(2)))
        old={n:w.EL(broken,other) for pair in w.pairs if not pair[0].startswith("bar") for n,other in (pair,pair[::-1])}
        old.update({f"bar{k}":Q[f"bar{k}"] for k in range(2)})
        old_square=w.Q(old["Jb0"],old)
        free={word:s.expand(co.subs(g,0)) for word,co in old_square.items() if s.expand(co.subs(g,0))!=0}
        assert free==w.add(*(w.scale(w.D(w.D(C[0],mu),mu),-(1 if mu==0 else -1)) for mu in range(4)))
        candidates={"scalar_coset_radius":w.add(w.mul(eta[0],eta[0]),w.mul(eta[1],eta[1])),"source_curvature":w.mul(x["Jc2"],R),"antighost_auxiliary":w.add(w.mul(bar[0],b[0]),w.mul(bar[1],b[1]))}
        rec={}
        for name,P in candidates.items():
            assert act(P)==contract(P)=={}
            image=w.Q(P,Q)
            assert image and act(image)==contract(image)=={} and image==w.Q(P,delta)
            rec[name]={"operator":w.record(P),"image":w.record(image)}
        return {"quartic_density":w.record(quartic),"omitted_quartic_delta_residual":w.record(omitted),"wrong_scalar_square":w.record(scalar_bad),"omitted_R_auxiliary_square":w.record(aux_bad),"omitted_partner_free_square":w.record(free),"basic_controls":rec}
    ctrl=stage("word_partial_basic_negative_controls",controls)
    return {"schema":"LOCAL_RESIDUAL_CARTAN_REPLAY_V1","base_generator_count":44,"canonical_pair_count":22,
        "actions":{"invariant":w.record(S0),"minimal_master":w.record(Smin),"gauge_fermion":w.record(psi),"gauge_fixing":w.record(gf),"partial_fixed_master":w.record(S)},
        "minimal_images":{n:w.record(Qmin[n]) for n in names},"images":{n:w.record(Q[n]) for n in names},
        "local_action":{"Hamiltonian":w.record(generator),"independent_parameter_images":{n:w.record(T[n]) for n in names},"moment":w.record(M),"moment_current":[w.record(t) for t in current],"R":w.record(R),"after_variation_substituted_images":{n:w.record(TR[n]) for n in names}},
        "closure":{"all_43_base_generators":passed,"all_172_first_jets":True,"total_checks":215,"all_exact_zero_residual":True,"source_Jc2_retained":True,"moment_constraint_not_imposed":True,
            "substitution_order_control":{"generator":"Jc0","actual_square":w.record(actual),"local_parameter_square":w.record(TR["Jc0"]),"field_dependent_Hamiltonian_square":w.record(before),"field_dependent_residual":w.record(bad_order),"moment_chain_rule_diagnostic":w.record(chain)}},
        "historical_connection":{"actual_square":w.record(connection),"source_paired_nonzero_Euler":w.record(w.EL(paired,"JA20")),"source_density_square":w.record(density_square),"full_local_source_density_action":w.record(w.act(density,TR,0))},
        "master":master,"transport":trans,"local_Ward":ward_data,"controls":ctrl,"Q_square_count":count,"all_Q_squares_exact_zero":True,"maximum_jet_order":w.max_jet,"EOM_used":False,
        "independence":{"ALGORITHM_INDEPENDENT":True,"CODE_PATH_INDEPENDENT":True,"LIBRARY_INDEPENDENT":False,"RUNTIME_INDEPENDENT":False,"primary_model_or_columns_imported":False,"analyst_blind":False,"external_specialist_review":False,"scope":"complete model, 88 Euler columns, local cotangent action, Cartan square, currents, canonical shift and controls; shared Python/SymPy and declared conventions"}}


if __name__=="__main__": print(json.dumps(build(),sort_keys=True,separators=(",",":")))
