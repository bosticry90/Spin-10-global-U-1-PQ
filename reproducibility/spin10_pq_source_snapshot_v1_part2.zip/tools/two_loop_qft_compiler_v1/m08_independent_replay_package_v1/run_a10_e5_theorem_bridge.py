"""Read-only new target controls; exporter alone writes complete evidence."""
import json,sys,time
from a10_e5_theorem_bridge import build


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    assert len(sys.argv)==2 and sys.argv[1] in ('primary','replay')
    writes=[]
    def hook(event,args):
        if event=='open' and len(args)>1 and isinstance(args[1],str) and any(k in args[1] for k in 'wax+'):
            writes.append(str(args[0]));raise PermissionError('E5_THEOREM_BRIDGE_WRITE_DENIED')
    sys.addaudithook(hook);stages=[];started=time.perf_counter()
    def stage(n,fn):
        print('STAGE '+n,flush=True);t=time.perf_counter();result=fn()
        stages.append({'name':n,'seconds':time.perf_counter()-t});return result
    result=build(sys.argv[1],stage)
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
    print('METRICS '+json.dumps({'stages':stages,'wall_seconds':time.perf_counter()-started,'write_attempts':writes},sort_keys=True),flush=True)


if __name__=='__main__':main()
