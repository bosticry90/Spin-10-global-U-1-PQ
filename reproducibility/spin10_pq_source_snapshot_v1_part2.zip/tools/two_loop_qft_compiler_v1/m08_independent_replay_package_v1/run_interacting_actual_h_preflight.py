"""Read-only instrumented runner; emits a lossless exact evidence capsule."""
import base64
import hashlib
import importlib
import json
from pathlib import Path
import sys
import time
import zlib

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'tools/readiness'))
from profile_pole_blind_workflow import process_counters


def run(route):
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED'),'POLE_BLIND_GUARD_REQUIRED'
    name={'primary':'interacting_actual_h_preflight','replay':'interacting_actual_h_preflight_replay'}[route]
    module=importlib.import_module(name); timings=[]
    first=process_counters(); start=time.perf_counter()
    def stage(label,fn):
        before=process_counters(); t=time.perf_counter()
        print('START '+label,flush=True)
        try: value=fn()
        except Exception:
            timings.append({'name':label,'status':'FAILED_OR_STOPPED','wall_seconds':time.perf_counter()-t})
            raise
        after=process_counters()
        timings.append({'name':label,'status':'COMPLETED','wall_seconds':time.perf_counter()-t,'before':before,'after':after})
        print('DONE '+label,flush=True); return value
    result=module.build(stage); final=process_counters()
    raw=json.dumps(result,sort_keys=True,separators=(',',':')).encode()
    print('SUMMARY '+json.dumps({'status':result['result']['status'],'witness':result['result'].get('witness'),'wall_seconds':time.perf_counter()-start,'payload_bytes':len(raw),'process_before':first,'process_after':final}),flush=True)
    print('CAPSULE '+json.dumps({'schema':'EXACT_BOUNDED_EVIDENCE_CAPSULE_V1','payload_encoding':'zlib+base64','payload_sha256':hashlib.sha256(raw).hexdigest(),'payload_b64':base64.b64encode(zlib.compress(raw,9)).decode()},sort_keys=True,separators=(',',':')),flush=True)
    print('TIMINGS '+json.dumps({'route':route,'stages':timings,'symbolic_parse_normalization_seconds':None,'exact_linear_algebra_seconds':None,'files_bytes_per_stage':None,'cache_hit_counts':None,'unavailable_counters_reason':'No separate attribution hook; OS process transfer counters and stage timing only.'}),flush=True)


if __name__=='__main__': run(sys.argv[1])
