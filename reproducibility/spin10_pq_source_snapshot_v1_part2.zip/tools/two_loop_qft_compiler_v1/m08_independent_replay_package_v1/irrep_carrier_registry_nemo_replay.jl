"""Independent Julia/Nemo exact verifier for the bounded H-carrier registry."""

using Nemo

length(ARGS) == 1 || error("expected REG11 replay TSV")

matrices = Dict{String, Any}()
labels = NTuple{5, Int}[]
for line in readlines(ARGS[1])[2:end]
    isempty(line) && continue
    fields = split(line, '\t')
    if fields[1] == "MDEF"
        matrices[fields[2]] = zero_matrix(QQ, parse(Int, fields[3]), parse(Int, fields[4]))
    elseif fields[1] == "MENTRY"
        value = QQ(parse(BigInt, fields[5])) / QQ(parse(BigInt, fields[6]))
        matrices[fields[2]][parse(Int, fields[3]), parse(Int, fields[4])] = value
    elseif fields[1] == "LABEL"
        label = parse.(Int, split(fields[2], ','))
        push!(labels, (label[1], label[2], label[3], label[4], parse(Int, fields[3])))
    else
        error("unknown replay row $(fields[1])")
    end
end

pq = sort(unique((label[1], label[2]) for label in labels))
ns = sort(unique(label[3] for label in labels))
@assert length(labels) == 271
@assert length(pq) == 15
@assert ns == collect(0:4)

function m3(p, q, name)
    matrices["SU3:$p,$q:$name"]
end

function m2(n, name)
    matrices["SU2:$n:$name"]
end

for (p, q) in pq
    e1, e2, e13 = m3(p, q, "E12"), m3(p, q, "E23"), m3(p, q, "E13")
    f1, f2, f13 = m3(p, q, "F12"), m3(p, q, "F23"), m3(p, q, "F13")
    h1, h2 = m3(p, q, "H1"), m3(p, q, "H2")
    @assert h1 * e1 - e1 * h1 == 2 * e1
    @assert h2 * e2 - e2 * h2 == 2 * e2
    @assert e1 * e2 - e2 * e1 == e13
    @assert f2 * f1 - f1 * f2 == f13
    @assert e1 * f1 - f1 * e1 == h1
    @assert e2 * f2 - f2 * e2 == h2
    pairing = matrices["PAIR3:$p,$q"]
    expected = div((p + 1) * (q + 1) * (p + q + 2), 2)
    @assert nrows(h1) == expected
    @assert rank(pairing) == expected
    for name in ("E12", "E23", "E13", "F12", "F23", "F13", "H1", "H2")
        @assert transpose(m3(q, p, name)) * pairing + pairing * m3(p, q, name) == zero_matrix(QQ, expected, expected)
    end
end

for n in ns
    e, f, h = m2(n, "E"), m2(n, "F"), m2(n, "H")
    @assert e * f - f * e == h
    pairing = matrices["PAIR2:$n"]
    @assert rank(pairing) == n + 1
    for name in ("E", "F", "H")
        @assert transpose(m2(n, name)) * pairing + pairing * m2(n, name) == zero_matrix(QQ, n + 1, n + 1)
    end
end

for (p, q, n, y6, dimension) in labels
    expected = div((p + 1) * (q + 1) * (p + q + 2) * (n + 1), 2)
    @assert dimension == expected
    @assert (q, p, n, -y6, expected) in labels
end
@assert maximum(label[5] for label in labels) == 135

# Independent character-multiplicity checks on a deterministic coverage set.
function comps(degree)
    [(a, b, degree - a - b) for a in 0:degree for b in 0:(degree - a)]
end

function expected_su3_weights(p, q)
    counts = Dict{Tuple{Int, Int}, Int}()
    for a in comps(p), b in comps(q)
        weight = ((a[1] - b[1]) - (a[2] - b[2]),
                  (a[2] - b[2]) - (a[3] - b[3]))
        counts[weight] = get(counts, weight, 0) + 1
    end
    if p > 0 && q > 0
        for a in comps(p - 1), b in comps(q - 1)
            weight = ((a[1] - b[1]) - (a[2] - b[2]),
                      (a[2] - b[2]) - (a[3] - b[3]))
            counts[weight] = get(counts, weight, 0) - 1
        end
    end
    filter!(pair -> pair.second != 0, counts)
    counts
end

coverage = [(0, 0), (1, 0), (0, 1), (1, 1), (2, 2), (4, 0), (0, 4)]
for (p, q) in coverage
    actual = Dict{Tuple{Int, Int}, Int}()
    h1, h2 = m3(p, q, "H1"), m3(p, q, "H2")
    for index in 1:nrows(h1)
        @assert denominator(h1[index, index]) == 1
        @assert denominator(h2[index, index]) == 1
        weight = (Int(numerator(h1[index, index])), Int(numerator(h2[index, index])))
        actual[weight] = get(actual, weight, 0) + 1
    end
    @assert actual == expected_su3_weights(p, q)
end

println("STATUS=PASS")
println("JULIA_VERSION=", VERSION)
println("NEMO_VERSION=", Base.pkgversion(Nemo))
println("CARRIER_COUNT=271")
println("SU3_FACTOR_COUNT=15")
println("SU2_FACTOR_COUNT=5")
println("ALL_COMMUTATORS=PASS")
println("ALL_PAIRINGS=PASS")
println("ALL_DIMENSIONS=PASS")
println("COVERAGE_CHARACTERS=PASS")
