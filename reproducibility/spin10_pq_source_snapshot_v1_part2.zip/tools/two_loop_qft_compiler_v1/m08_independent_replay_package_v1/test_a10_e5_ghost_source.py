"""Scientific adversarial checks: source grade, loops, charts and IBP functional."""
import unittest
from audit_a10_e5_ghost_source import *
from a10_e5_ghost_source_control import model,born,residue
from a10_e5_ghost_source import hessian


class GhostSourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.a,cls.c,cls.u,cls.q=evidence()
    def test_complete_source_ghost_domain(self):self.assertEqual(self.a['domain']['antisymmetric_slots'],45*45*44//2)
    def test_actual_replay_contains_all_families(self):self.assertTrue(all(self.a['family_poles'].values()))
    def test_even_source_type_and_wrong_parity(self):
        w,V=model();self.assertTrue(w.grade(V[0],(4,0,0)));w.p['Jext']=1;w.external['Jext']=(2,-2,1);self.assertFalse(w.grade(V[0],(4,0,0)))
    def test_unit_gauge_derivative_sign(self):self.assertEqual(self.u['unit_poles']['triangle:B'],'2')
    def test_unit_external_ghost_derivative_zero_is_calculated(self):self.assertEqual(self.u['unit_poles']['triangle:c'],'0');self.assertIn('triangle:c',self.u['unit_kernels'])
    def test_missing_odd_orientation_is_not_qualified(self):self.assertEqual(residue(born('bubble',omit_reverse_odd=True)),'0');self.assertNotEqual(self.u['unit_poles']['bubble:a'],'0')
    def test_missing_mixed_edge_is_not_qualified(self):self.assertEqual(residue(born('triangle',omit_mixed=True)),'0');self.assertNotEqual(self.u['unit_poles']['triangle:a'],'0')
    def test_reversing_external_assignment_sign(self):self.assertEqual(residue(born('triangle',reverse=True)),'2')
    def test_all_source_coupling_units(self):self.assertTrue(all(s.Poly(z,g,xi).monoms()==[(2,1)] for z in decode_typed(self.a['canonical_full_g_squared_xi_density']).values()))
    def test_source_has_anomalous_CC_hessian(self):
        from a10_e5_quartic_companion import group_alphabet
        w=group_alphabet()
        for i in IDS:__import__('a10_e5_ghost_source_control').register(w,f'JCp{i}',(2,-2,0))
        A=hessian(decode_typed(self.a['vertices']['S']),w);self.assertTrue(A);self.assertTrue(all(90<=i<135 and 90<=j<135 for i,j in A))
    def test_wrong_source_primal_chart_has_nonzero_discrepancy(self):
        w,sub,back,source,anti,Cinv,Cphys=frames('primary');pullback=w.replace
        for i in IDS:
            __import__('a10_e5_ghost_source_control').register(w,f'JCp{i}',(2,-2,0))
            back[f'JCp{i}']=w.add(*(w.scale(w.var(f'JC{j}'),Cphys[i,j]) for j in IDS if Cphys[i,j]))
        wrong=pullback(decode_typed(self.a['physical_full_g_squared_xi_density']),back)
        self.assertTrue(canonical(w.add(wrong,w.scale(decode_typed(self.a['canonical_full_g_squared_xi_density']),-1))))
    def test_nojet_local_H_all12(self):self.assertEqual(self.a['all12_local_nojet_H_identities'],list(range(12)))
    def test_equal_color_distinct_jet_ghosts_survive(self):
        w=frames('primary')[0];self.assertTrue(w.mul(w.var('C14'),w.D(w.var('C14'),0)));self.assertFalse(w.mul(w.var('C14'),w.var('C14')))
    def test_raw_domain_includes_same_color_distinct_jets(self):self.assertEqual(self.c['raw_domain'],3539700)
    def test_full_current_reconstructs_raw(self):
        w=frames('primary')[0];R=decode_typed(self.c['enlarged_raw_Slavnov_left_side']);A=decode_typed(self.c['anchored_Slavnov_left_side']);curr=[decode_typed(P) for P in self.c['full_IBP_currents']]
        self.assertFalse(canonical(w.add(R,w.scale(A,-1),w.scale(w.add(*(w.D(P,mu) for mu,P in enumerate(curr))),-1))))
    def test_independent_Eulers_cover_all45(self):self.assertEqual(set(self.c['all45_antighost_Eulers']),set(ANTI))
    def test_dropped_currents_have_exact_nonzero_discrepancy(self):self.assertGreater(self.q['dropped_current_exact_discrepancy_terms'],0)
    def test_omitted_source_leaves_nonboundary_variation(self):self.assertGreater(self.c['negative_controls']['omitted_new_source_anchored_terms'],0)
    def test_unknown_rhs_and_partners_never_zero(self):self.assertFalse(self.c['Delta_s_Delta_b_unknown_Gamma_contacts_or_measure_set_to_zero'])
    def test_inherited_metric_error_rejected(self):self.assertGreater(self.q['inherited_source_metric_error_terms'],0);self.assertFalse(self.q['unqualified_old_comparison_counted_as_PASS'])
    def test_old_to_corrected_projected_difference_exact(self):self.assertTrue(self.q['old_to_corrected_projected_difference_exact'])
    def test_prior_g3_failure_not_repaired_by_source_result(self):self.assertFalse(self.c['previous_g3_quartet_candidate_failure_repaired']);self.assertFalse(read(HERE/'frozen_a10_e5_quartic_g3/bindings.json')['candidate_selected_quartic_g3_gate_PASS'])
    def test_whole_goal_and_quantum_equivalence_open(self):self.assertFalse(self.c['whole_goal_complete']);self.assertFalse(self.c['full_E5_or_quantum_A5'])


if __name__=='__main__':unittest.main()
