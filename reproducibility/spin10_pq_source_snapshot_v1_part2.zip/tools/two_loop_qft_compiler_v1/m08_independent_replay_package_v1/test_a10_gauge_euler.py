"""Adversarial physical Euler, Lorentz-chart and boundary regressions."""
import unittest
import sympy as s
from a10_executable_action import contract,ETA,read
from a10_gauge_euler_common import HERE,OUT,algebra,component_tables,extract,rows
from a10_gauge_euler_adapter import TypedExecutor,identity_tables,canonical_euler,momentum
from m08_local_functional_ast import field,mul,scalar,derivative,source

class GaugeEulerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p=read(OUT/'primary.json');cls.r=read(OUT/'replay.json');cls.c=read(OUT/'checks.json')
    def test_independent_all_Euler_coefficients(self):
        self.assertEqual(self.p['gauge_Euler'],self.r['gauge_Euler'])
        self.assertEqual(sum(map(len,self.p['gauge_Euler'].values())),135000)
    def test_arbitrary_first_variation_and_boundary(self):
        self.assertEqual(self.p['boundary_momentum'],self.r['boundary_momentum'])
        self.assertEqual(sum(map(len,self.p['boundary_momentum'].values())),9720)
        self.assertEqual(self.p['first_variation_identity']['residual'],[])
        self.assertFalse(self.p['first_variation_identity']['EOM_used'])
    def test_all_16_free_controls(self):
        rows=self.p['negative_controls']['free_comparisons'];self.assertEqual(len(rows),16)
        for row in rows:
            nu,mu=row['connection_component'],row['ordinary_jet_direction']
            self.assertEqual(row['Euler'],[] if nu==mu else [{'word':[f'B0_{nu}__{mu}{mu}'],'coefficient':str(ETA[nu]*ETA[mu])}])
    def test_uniform_metric_shortcut_refuted(self):
        control=self.p['negative_controls']
        self.assertTrue(control['uniform_metric_multiplier_refuted'])
        self.assertEqual(control['constant_quartic_Euler'],[{'word':['B0_0','B0_0','B1_1'],'coefficient':'g10**2/2'}])
    def test_general_all_four_currents(self):
        self.assertEqual(self.p['scalar_currents'],self.r['scalar_currents'])
        self.assertEqual(self.p['summary']['scalar_current_factorized_nonzero_coefficients'],{'Phi':4488,'Sigma':25200,'phi':720,'S':0})
    def test_nonzero_connection_not_discarded(self):
        for sec,row in self.c['nonzero_matter_controls'].items():
            self.assertFalse(row['connection_projected_before_variation'])
            if sec!='S':
                self.assertTrue(any(any(n.startswith('B') for n in v['word']) for v in row['Euler']))
    def test_full_Noether_scope(self):
        proof=self.c['Noether']
        self.assertEqual(len(proof['pure_Yang_Mills_exact_expanded_components']),45)
        self.assertEqual(len(proof['matter_skew_pairing_checks']),180)
        self.assertEqual(proof['potential_directions'],29);self.assertFalse(proof['EOM_used'])
    def test_exact_metric_loss_preserved(self):
        d=self.c['diagnosis'];self.assertEqual(d['comparisons'][1]['residual'],'2*W')
        self.assertEqual(d['old_simplified_AST']['name'],'W')
    def test_canonical_lower_source_chart(self):
        m=self.c['source_maps'];self.assertEqual(m['raw_Lorentz_chart_bracket_unsigned'],'eta')
        self.assertEqual(m['canonical_bracket_unsigned'],'identity')
        self.assertEqual(m['physical_source_left_sign'],'+E')
        self.assertTrue(m['conjugation_and_inverse_checks'])
    def test_saved_historical_consumer_scope(self):
        for row in self.c['historical_impact']['selected_frozen_consumers']:
            self.assertEqual(row['S7_saved_Euler'],[{'word':['b__00'],'coefficient':'1'}])
            self.assertEqual(row['canonical_component_Euler'],[{'word':['b__00'],'coefficient':'-1'}])
        self.assertFalse(self.c['historical_impact']['all_historical_columns_declared_wrong'])
    def test_no_BV_or_activation(self):
        for key in ('full_BV_master_action_qualified','Stage_D_resumed','Stage_E_reached','sources_activated','HB1_C5_run'):
            self.assertFalse(self.p['summary'][key])
    def test_odd_density_is_rejected(self):
        with self.assertRaises(AssertionError):canonical_euler(field('odd',parity=1))
    def test_source_density_is_rejected(self):
        with self.assertRaises((AssertionError,ValueError)):canonical_euler(source('K',parity=0))
    def test_higher_input_jet_is_rejected(self):
        with self.assertRaises(AssertionError):canonical_euler(derivative('mu',derivative('nu',field('B',indices=('a','lambda')))))
    def test_output_index_capture_is_rejected(self):
        with self.assertRaises(AssertionError):canonical_euler(field('B',indices=('out_a','mu')))
    def test_independent_Lorentz_sum_product_is_rejected(self):
        B=field('B',indices=('a','mu'))
        L=contract(contract(mul(B,B),('a',)),('mu',),'LorentzContraction')
        with self.assertRaises(ValueError):canonical_euler(mul(L,L))
    def test_weighted_mass_operation_not_final_sign_patch(self):
        # Independent closed polynomial: its canonical covector retains eta;
        # no differentiation of a gauge kinetic term is needed for this test.
        B=field('B',indices=('a','mu'))
        L=contract(contract(mul(scalar(s.Rational(1,2)),B,B),('a',)),('mu',),'LorentzContraction')
        w=algebra();data=read(HERE/'frozen_a10_physical_reconciliation/full_primary.json')
        tables=component_tables(w,data);tables.update(identity_tables(w))
        result=extract(TypedExecutor(w,tables).eval(canonical_euler(L)))
        self.assertEqual(result[0,1],w.scale(w.var('B0_1'),-1))
        self.assertEqual(result[0,0],w.var('B0_0'))

if __name__=='__main__':unittest.main()
