"""Adversarial local identities and preserved quotient boundaries."""
import unittest
from copy import deepcopy
from a10_e5_quotient_common import *
from audit_a10_e5_quotient import adjudicate


def unpack(data):
    P=decode_typed(data)
    return canonical({word:c.subs({s.Symbol('zH'):zH,s.Symbol('zM'):zM}) for word,c in P.items()})


class QuotientTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.a=read(OUT/'primary.json');cls.b=read(OUT/'replay.json');cls.w=alphabet()

    def test_complete_independent_family_agreement(self):
        self.assertEqual(adjudicate(self.a,self.b)['scientific_gate'],STATUS)

    def test_complete_inverse_and_jet_coverage(self):
        self.assertEqual((len(self.a['finite_maps']),self.a['inverse_checks'],self.a['first_jet_checks']),(1286,2572,2572))

    def test_ghost_sources_are_evaluation_duals(self):
        self.assertEqual(unpack(self.a['finite_maps']['C0']),self.w.scale(self.w.var('C0'),zH))
        self.assertEqual(unpack(self.a['finite_maps']['JC0']),self.w.scale(self.w.var('JC0'),1/zH))
        self.assertNotEqual(zH*zH,1)

    def test_generating_fermion_and_two_sector_parameters(self):
        P=unpack(self.a['generating_fermion_difference'])
        self.assertTrue(P);self.assertTrue(any(c.has(zM) for c in P.values()))
        self.assertEqual(weight('C12'),zM);self.assertEqual(weight('JC12'),1/zM)

    def test_original_literal_witness_survives(self):
        self.assertEqual(self.a['original_free_Euler_witness'],[{'coefficient':'1','word':['omega0__0']}])
        self.assertTrue(self.a['original_literal_failure_preserved'])

    def test_action_orientation_and_explicit_boundary(self):
        delta=unpack(self.a['action_delta']);F=self.w.add(*(unpack(P) for P in self.a['exact_tangents'].values()))
        div=self.w.add(*(self.w.D(unpack(P),mu) for mu,P in enumerate(self.a['action_tangent_boundary_current'])))
        self.assertFalse(canonical(self.w.add(differentiate_units(delta),F,self.w.scale(div,-1))))
        wrong=canonical(self.w.add(differentiate_units(delta),self.w.scale(F,-1),self.w.scale(div,-1)))
        self.assertTrue(wrong)
        E=canonical(self.w.EL(wrong,'JB0_0'))
        free=canonical({word:c.subs(g,0) for word,c in E.items()})
        self.assertEqual(free,self.w.scale(self.w.D(self.w.var('C0'),0),2))

    def test_fixed_contraction_policy_has_exact_defect(self):
        self.assertEqual(unpack(self.a['fixed_contraction_defect']),self.w.scale(self.w.D(self.w.var('omega0'),0),zH-1))
        self.assertEqual(unpack(self.a['transported_contraction_columns']['C0']),self.w.scale(self.w.var('omega0'),1/zH))

    def test_actual_nonminimal_and_nonsymmetric_structure_preserved(self):
        self.assertGreater(self.a['nonsymmetric_heavy_structure_coefficients_retained'],0)
        self.assertEqual(self.a['Cartan_checks'],1286)

    def test_physical_programs_and_backgrounds_are_spectators(self):
        self.assertEqual(self.a['physical_Euler_programs_unchanged'],508)
        self.assertEqual(self.a['external_backgrounds_fixed'],48)

    def test_intrinsic_and_induced_quotients_not_equated(self):
        self.assertFalse(self.a['basic_only_exactness_assumed'])
        self.assertFalse(self.a['general_basic_full_quotient_isomorphism_proved'])

    def test_tampered_normalization_rejected(self):
        b=deepcopy(self.b);b['finite_maps']['C0'][0]['coefficient']='2*zH'
        with self.assertRaises(AssertionError):adjudicate(self.a,b)

    def test_full_E5_and_quantum_promotion_rejected(self):
        a=deepcopy(self.a);b=deepcopy(self.b);a['E5_full_PASS']=b['E5_full_PASS']=True
        with self.assertRaises(AssertionError):adjudicate(a,b)


if __name__=='__main__':unittest.main()
