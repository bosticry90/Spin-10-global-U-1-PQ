"""Physical four-dimensional tensor policy and exact bounded epsilon tests.

This module is not imported by a loop reduction engine. All indices are lower;
raising uses the inverse metric. Products of two alternating tensors reduce
to minus the metric determinant; antisymmetrization over five indices is zero.
"""
from itertools import product, permutations
from math import prod
import sympy as sp
from jcat3_contract_preflight import HERE, load, byte_hash, INPUTS, WITNESS

ETA = (-1, 1, 1, 1)


def metric(a, b):
    return ETA[a] if a == b else 0


def epsilon(indices):
    if len(set(indices)) != 4:
        return 0
    return (-1) ** sum(indices[i] > indices[j] for i in range(4) for j in range(i+1,4))


def raised_epsilon(indices):
    return prod(ETA[i] for i in indices) * epsilon(indices)


def epsilon_product(a, b):
    # Exact determinant expansion, derived from the Lorentz metric determinant.
    return -sum(epsilon(p) * prod(metric(a[i], b[p[i]]) for i in range(4))
                for p in permutations(range(4)))


def contract():
    return {
        'object_id':'M08_JCAT_PHYSICAL_LORENTZ_EPSILON_CONTRACT_V2',
        'status':'FROZEN_USER_ADJUDICATED_PHYSICAL_OPERATOR_POLICY',
        'PHYSICAL_LORENTZ_DIMENSION':4,
        'DIMENSIONAL_REGULARIZATION_DIMENSION':'4 - 2 epsilon',
        'continuous_covariance':'SO^+(1,3)',
        'metric_signature':ETA,'epsilon_0123':1,
        'metric_provenance':'Historical JCAT3 witness component convention; unchanged',
        'invariant_generators':['eta_mu_nu','epsilon_mu_nu_rho_sigma'],
        'parity_sectors':['PARITY_EVEN','PARITY_ODD'],
        'orientation_reversal_projection':False,
        'canonicalization':{
            'epsilon':'Totally antisymmetric; repeated index zero',
            'two_epsilon':'epsilon_abcd epsilon_efgh = -det(eta_{a_i b_j})',
            'raised_indices':'Contract only through the frozen inverse metric',
            'maximum_irreducible_epsilon_factors':1,
            'Schouten':'Exact antisymmetrization over five Lorentz indices vanishes',
            'derivative_of_epsilon':'ZERO_FLAT_BACKGROUND',
        },
        'IBP':'drop_exact_total_derivatives_of_local_densities_AFTER_RAW_JETS',
        'EOM_policy':'DEFERRED_NO_CATALOG_EOM_QUOTIENT',
        'regulator_interface':'NOT_AUTHORIZED_REQUIRE_SEPARATE_SCHEME_EVANESCENT_CONTRACT_IF_NEEDED',
        'loop_engine_modified':False,'gamma5_anomaly_claim':False,
        'parity_violation_or_nonzero_coupling_claim':False,
        'supersedes_admissibility_gap_only':byte_hash(HERE/'frozen_jcat3_contract_preflight/JCAT3_contract_gap.json'),
        'historical_checkpoint_preserved':byte_hash(HERE/'frozen_jcat3_contract_preflight/JCAT3_checkpoint.json'),
    }


def tests():
    tuples = list(product(range(4), repeat=4))
    for a in tuples:
        assert raised_epsilon(a) == -epsilon(a)
        for i in range(3):
            b = list(a); b[i],b[i+1] = b[i+1],b[i]
            assert epsilon(b) == -epsilon(a)
        for b in tuples:
            assert epsilon(a)*epsilon(b) == epsilon_product(a,b)
    # Component-complete five-index Schouten identity eta_{x[a} eps_{bcde]}.
    for x,*a in product(range(4), repeat=6):
        assert sum((-1)**i * metric(x,a[i]) * epsilon(a[:i]+a[i+1:]) for i in range(5)) == 0
    # Six Lorentz Lie-algebra generators, acting on all four epsilon slots.
    generators = []
    for a in range(4):
        for b in range(a+1,4):
            g = sp.zeros(4); g[a,b] = ETA[b]; g[b,a] = -ETA[a]
            assert g.T * sp.diag(*ETA) + sp.diag(*ETA) * g == sp.zeros(4)
            for idx in tuples:
                assert sum(g[j,idx[s]]*epsilon(idx[:s]+(j,)+idx[s+1:]) for s in range(4) for j in range(4)) == 0
            generators.append((a,b))
    witness = load(HERE/'frozen_jcat3_contract_preflight/JCAT3_conditional_Lorentz_witness.json')
    assert witness['signature_id'] == WITNESS
    values = [[metric(a,b)*metric(c,d),metric(a,c)*metric(b,d),metric(a,d)*metric(b,c),epsilon((a,b,c,d))]
              for a,b,c,d in tuples]
    assert values == witness['component_values']
    assert sp.Matrix(values[:]).rank() == 4 and sp.Matrix(values)[:,:3].rank() == 3
    assert values[tuples.index((0,1,2,3))] == [0,0,0,1]
    for idx,row in zip(tuples,values):
        assert [(-1)**idx.count(0)*v for v in row] == [*row[:3],-row[3]]
    assert sum(epsilon(a)*raised_epsilon(a) for a in tuples) == -24
    # Bound verification: every current scalar/vector occurrence has dimension
    # at least one. Hence at most four Lorentz indices (including derivatives).
    ledger = load(HERE/'frozen_jcat3_contract_preflight/JCAT3_signature_contract_ledger.json')
    ranks = []
    for row in ledger['rows']:
        vectors = sum(f['Lorentz_type'] == 'VECTOR' for f in row['field_types'])
        assert vectors + row['degree_bounds']['maximum_derivative_degree'] <= 4
        ranks.extend(vectors+d for d in row['degree_bounds']['feasible_derivative_degrees'])
    return {'status':'PASS_EXACT_PHYSICAL_LORENTZ_POLICY_REGRESSIONS',
        'epsilon_product_component_pairs':65536,'Schouten_component_controls':4096,
        'Lorentz_generators':generators,'generator_epsilon_controls':1536,
        'epsilon_upper_0123':-1,'fully_contracted_epsilon_square':-24,
        'witness_signature':WITNESS,'metric_rank':3,'metric_epsilon_rank':4,
        'negative_control_0123':[0,0,0,1],'reflection':'EVEN_EVEN_EVEN_ODD_ZERO_RESIDUAL',
        'maximum_bounded_raw_Lorentz_rank':max(ranks),
        'higher_rank_Schouten_requirement':'No >4-index generator at these bounds; full 5-index identity separately verified',
        'all_residuals':'ZERO_EXACT','parity_odd_retained':True}
