"""Full Hessian coverage, graded source controls and finite loop boundaries."""
import unittest
from copy import deepcopy
from a10_e5_full_hessian import *
from audit_a10_e5_full_hessian import adjudicate,execution_matches,heat_expression


class FullHessian(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.P=read(OUT/'primary.json');cls.R=read(OUT/'replay.json')
        cls.HP=read(OUT/'heat_primary.json');cls.HR=read(OUT/'heat_replay.json')

    def test_01_complete_routes_and_bounded_ceiling(self):
        a=adjudicate(self.P,self.R,self.HP,self.HR)
        self.assertEqual(a['scientific_gate'],STATUS);self.assertFalse(a['full_E5_PASS'])

    def test_02_all_literal_physical_terms_and_potential_parameters(self):
        p=self.P['physical_Hessian_program']
        self.assertEqual(len(p['all_34_literal_terms']),34)
        self.assertEqual(p['graph_coefficients'],391);self.assertEqual(p['all_real_parameters'],34)
        self.assertTrue(p['all_potential_29_programs_match_prior_with_minus_V'])

    def test_03_wrong_derivative_product_rejected(self):
        # The frozen physical grammar differentiates fields, not an arbitrary
        # product; silently treating a product as one jet would lose Leibniz terms.
        bad=derivative('mu',mul(field('x_Phi',indices=['i']),field('x_Phi',indices=['j'])))
        with self.assertRaises(AssertionError):physical_graphs_AST(bad)

    def test_04_complete_polynomial_and_source_hashes(self):
        h=self.P['complete_source_and_GF_Hessian'];r=self.R['complete_source_and_GF_Hessian']
        for name,count in [('complete_second_variation',354321),('source_second_variation',73218),('g0_complete_second_variation',2455)]:
            self.assertEqual(h[name]['complete_coefficients'],count)
            self.assertEqual(h[name]['canonical_row_stream_sha256'],r[name]['canonical_row_stream_sha256'])
            self.assertTrue(h[name]['no_coefficients_truncated'])

    def test_05_source_g_powers_are_not_unweighted_classes(self):
        h=self.P['complete_source_and_GF_Hessian']
        self.assertEqual(h['source_second_variation']['source_minimum_g_power_counts'],{'1':68202,'2':5016})
        self.assertEqual(h['g0_complete_second_variation']['source_degree_counts'],{'0':2455})
        self.assertFalse(self.P['weighted_gF_quantum_A5_equivalence_proved'])

    def test_06_zero_coupling_retains_actual_cubic_interaction(self):
        h=self.P['complete_source_and_GF_Hessian']['g0_complete_second_variation']
        roles=dict((tuple(k),v) for k,v in h['field_role_blocks'])
        self.assertEqual(roles[('ghost','heavy_auxiliary')],552)
        self.assertEqual(roles[('heavy_antighost','heavy_auxiliary')],552)
        self.assertEqual(roles[('ghost','heavy_antighost')],816)
        self.assertTrue(any('xi' in v['coefficient'] and len(v['word'])==3 for v in h['selected_rows_not_used_as_coverage']))

    def test_07_boundary_current_is_essential_to_density_replay(self):
        h=self.P['complete_source_and_GF_Hessian']
        self.assertTrue(h['omitted_current_nonzero_density'])
        self.assertTrue(h['independent_directional_symmetry_zero'])
        self.assertTrue(h['all643_field_directions_retained'])

    def test_08_field_parities_and_external_sources(self):
        r=self.P['retained_reference'];self.assertEqual(r['integrated_even_fields'],553)
        self.assertEqual(r['integrated_odd_fields'],90);self.assertEqual(len(r['field_order']),643)
        self.assertTrue(self.P['complete_source_and_GF_Hessian']['external643_sources_frozen_only_in_fluctuation_derivative'])

    def test_09_free_gauge_auxiliary_inverse_and_no_width_inverse(self):
        p=s.Matrix(s.symbols('p_test0:4'));eta=s.diag(1,-1,-1,-1);up=eta*p
        p2=(p.T*eta*p)[0];width=s.Symbol('width_test')
        K=(-p2*eta+up*up.T).row_join(s.I*up).col_join((-s.I*up.T).row_join(s.Matrix([[width]])))
        G=(-eta/p2+(1-width)*p*p.T/p2**2).row_join(s.I*p/p2).col_join((-s.I*p.T/p2).row_join(s.zeros(1,1)))
        self.assertEqual(cm(K*G),s.eye(5));self.assertEqual(cm(G*K),s.eye(5))
        self.assertEqual(G[4,4],0)
        self.assertTrue(all(not v.has(1/width) for v in G))

    def test_10_odd_block_sign_negative_control(self):
        p2=s.Symbol('p2_test',nonzero=True);K=s.Matrix([[0,-p2],[p2,0]])
        G=s.Matrix([[0,1/p2],[-1/p2,0]])
        self.assertEqual(K*G,s.eye(2));self.assertNotEqual(K*(-G),s.eye(2))

    def test_11_full_reference_and_fourier_matching(self):
        r=self.P['retained_reference'];self.assertTrue(r['all643_inverse_directions_both_checked'])
        self.assertTrue(r['literal_GF_all_413449_entries_matched']);self.assertEqual(r['auxiliary_auxiliary_Green_zero'],45)
        self.assertFalse(r['auxiliary_or_ghost_field_eliminated']);self.assertFalse(r['physical_width_or_g_inverted'])

    def test_12_source_freezing_fails_hessian_congruence(self):
        c=self.P['graded_source_Ward_control']
        self.assertFalse(c['full_master_residual']);self.assertFalse(c['complete_hessian_congruence_residual'])
        self.assertEqual(len(c['frozen_source_variations_hessian_defect']),20)
        self.assertTrue(c['nil_inverse_complete_through_all_four_odd_variables'])

    def test_13_finite_cutoff_breaking_matches_insertion_not_zero(self):
        c=self.P['graded_source_Ward_control'];self.assertEqual(c['one_loop_Slavnov_variation'],c['one_loop_breaking_insertion'])
        self.assertFalse(c['variation_minus_insertion']);self.assertTrue(c['one_loop_Slavnov_variation'])
        v=s.sympify(c['one_loop_Slavnov_variation'][0]['coefficient']);r=s.Symbol('rCtl')
        self.assertNotEqual(v.subs(r,1),0);self.assertTrue(c['wrong_frozen_source_one_loop_variation'])
        self.assertFalse(c['full_643_field_amplitude_replayed_by_this_control'])

    def test_14_finite_bubble_replay_and_derivative(self):
        c=s.Symbol('cHeat',positive=True);v=heat_expression(self.HP['exact_nonexceptional_bubble'])
        self.assertEqual(s.simplify(v-heat_expression(self.HR['exact_nonexceptional_bubble'])),0)
        expected=-(s.exp(-c/2)-s.exp(-c))/(8*s.pi**2*c*c)
        self.assertEqual(s.simplify(s.diff(v,c)-expected),0)

    def test_15_limit_bound_and_uv_residue(self):
        c=s.Symbol('cHeat',positive=True)
        bound=(2*s.exp(-c/2)+2*s.exp(-c))/(8*s.pi**2*c)
        self.assertEqual(s.limit(bound,c,s.oo),0)
        v=heat_expression(self.HP['derivative_with_respect_to_c'])
        self.assertEqual(s.limit(-c*v,c,0,dir='+'),1/(16*s.pi**2))

    def test_16_finite_scheme_difference_local_and_ir_boundary(self):
        q2,mu2=s.symbols('q_E_squared mu_squared',positive=True)
        v=heat_expression(self.HP['renormalized_finite_bubble'])
        self.assertEqual(s.simplify(s.diff(v,q2)),-1/(16*s.pi**2*q2))
        analytic=(1+s.log(mu2/q2))/(16*s.pi**2)
        self.assertEqual(s.simplify(analytic-v-heat_expression(self.HP['analytic_MS_minus_heat_finite'])),0)
        self.assertFalse(self.HP['zero_external_momentum_included']);self.assertFalse(self.HP['physical_IR_limit_proved'])

    def test_17_retained_auxiliary_subtraction_and_primitive(self):
        h=self.HP;self.assertTrue(h['source_free_primitive']);self.assertTrue(h['source_free_pole_metric_density'])
        self.assertTrue(h['BRST_exact_subtraction_with_all_auxiliaries_retained'])
        self.assertTrue(h['auxiliary_auxiliary_propagation_zero']);self.assertFalse(h['xi_vertex_changed'])
        for v in h['source_free_primitive']+h['source_free_pole_metric_density']:
            self.assertTrue(all(not z.startswith('J_') for z in v['word']))

    def test_18_loop_domain_does_not_claim_full_restoration(self):
        l=self.P['finite_cutoff_loop_program'];self.assertIn('Gamma_ref',l['reference_background_normalization'])
        self.assertFalse(l['complete_finite_source_dependent_amplitudes_evaluated'])
        self.assertFalse(l['full_M2_M5_or_A1_A5_proved']);self.assertFalse(l['physical_IR_or_continuum_measure_proved'])
        self.assertFalse(self.P['retained_reference']['whole_mixed_Hessian_positive_Laplace_operator_claimed'])

    def test_19_promotion_and_false_quantum_pass_rejected(self):
        for name in ('full_E5_PASS','complete_nonzero_g_Ward_ST_restoration_proved','full_quantum_M2_M5_nonempty_proved',
          'weighted_gF_quantum_A5_equivalence_proved','full_anomaly_freedom_proved','sources_activated','HB1_C5_run','C1_GS_calculated'):
            a,b=deepcopy(self.P),deepcopy(self.R);a[name]=b[name]=True
            with self.assertRaises(AssertionError):adjudicate(a,b,self.HP,self.HR)

    def test_20_stale_execution_and_cross_core_heat_binding_rejected(self):
        f=next(read(p)['fingerprint'] for p in OUT.glob('replay_attempt_*.json') if read(p)['completed_evidence'])
        execution_matches(f);bad=deepcopy(f);bad['input_manifest_sha256']='stale'
        with self.assertRaises(AssertionError):execution_matches(bad)
        h=deepcopy(self.HP);h['core_artifact_sha256']='another core'
        with self.assertRaises(AssertionError):adjudicate(self.P,self.R,h,self.HR)


if __name__=='__main__':unittest.main()
