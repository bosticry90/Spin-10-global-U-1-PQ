"""Meaningful graded, insertion, scope and promotion negative controls."""
import unittest
from copy import deepcopy
from a10_e5_quantum_contract import *
from audit_a10_e5_quantum_contract import adjudicate


class QuantumContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.a=read(OUT/'primary.json');cls.b=read(OUT/'replay.json');cls.w=alphabet()

    def test_completed_distinct_routes_agree_conditionally(self):
        self.assertEqual(adjudicate(self.a,self.b)['scientific_gate'],STATUS)

    def test_unconditional_promotion_is_rejected_even_if_both_routes_claim_it(self):
        for flag in ('QAP_proved_for_model','measure_or_anomaly_freedom_proved','joint_restoration_proved',
          'actual_renormalization_prescription_constructed','full_E5_PASS','all_order_class_nonempty_proved'):
            a=deepcopy(self.a);b=deepcopy(self.b);a[flag]=b[flag]=True
            with self.assertRaises(AssertionError):adjudicate(a,b)

    def test_omitting_shared_assumption_is_rejected(self):
        a=deepcopy(self.a);b=deepcopy(self.b);del a['assumptions']['A4'];del b['assumptions']['A4']
        with self.assertRaises(AssertionError):adjudicate(a,b)

    def test_fourth_order_Slavnov_nonlinearity_and_independent_convolution(self):
        self.assertEqual(slavnov('primary'),slavnov('replay'))
        self.assertEqual(self.a['Slavnov']['orders'][4],'B04 + B13 + B22/2')

    def test_first_relative_difference_is_homogeneous_only_at_its_first_order(self):
        self.assertEqual(self.a['Slavnov']['first_difference_order_two'],['0','0','B0F','B1F','B2F + BFF/2'])
        self.assertFalse(self.a['Slavnov']['all_Gamma_n_closed_claim'])

    def test_broken_master_has_nonzero_linearized_square_and_consistent_breaking(self):
        data=jacobi_control('replay')
        self.assertEqual(data,self.a['graded_canonical_control'])
        self.assertTrue(data['Jacobi_source_and_field_squares']['B0_0'])
        self.assertTrue(data['Jacobi_source_and_field_squares']['JC1'])
        self.assertFalse(data['consistency_residual'])

    def test_canonical_exact_term_orientation_is_not_a_uniform_sign_guess(self):
        toy=self.a['graded_canonical_control'];P=decode_typed(toy['XKS']);Q=decode_typed(toy['QK'])
        self.assertFalse(canonical(self.w.add(P,Q)))
        self.assertTrue(canonical(self.w.add(P,self.w.scale(Q,-1))))

    def test_odd_Legendre_source_requires_opposite_Gamma_derivative_sign(self):
        table=self.a['Legendre_source_contract']
        self.assertEqual(table['C0']['Gamma_phi_sign'],1)
        self.assertEqual(table['B0_0']['Gamma_phi_sign'],-1)
        register(self.w,'probe_jC',(3,-1,1));P=self.w.mul(self.w.var('probe_jC'),self.w.var('C0'))
        self.assertEqual(canonical(self.w.EL(P,'C0')),self.w.scale(self.w.var('probe_jC'),-1))

    def test_product_insertion_cannot_be_replaced_by_factorized_means(self):
        A=gaussian('primary');B=gaussian('replay');self.assertEqual(A,B)
        self.assertNotEqual(A['whole_product_xy'],A['factorized_xy'])
        self.assertEqual(clean(s.sympify(A['connected_product_defect'])+s.Symbol('hbar')*s.Symbol('k')/(s.Symbol('a')*s.Symbol('c')-s.Symbol('k')**2)),0)

    def test_nonlinear_coordinate_mean_is_a_composite_expectation(self):
        self.assertNotEqual(self.a['Gaussian_insertion_control']['nonlinear_mean_map_defect'],'0')
        self.assertFalse(self.a['Gaussian_insertion_control']['mean_map_scalar_Gamma_claim'])

    def test_background_normalization_changes_a_measurable_functional_derivative(self):
        self.assertEqual(self.a['Gaussian_insertion_control']['background_normalization_second_derivative'],'2*N')
        self.assertTrue(self.a['background_only_terms_retained'])

    def test_full_tree_product_reproduces_broken_Ward_with_its_current(self):
        data=self.a['actual_quantum_insertions'];self.assertTrue(data['whole_tree_product_insertion'])
        self.assertFalse(data['tree_breaking_plus_insertion_minus_current'])
        self.assertGreater(data['field_dependent_correction_slots'],0)
        a=deepcopy(self.a);b=deepcopy(self.b)
        a['actual_quantum_insertions']['tree_breaking_plus_insertion_minus_current']=[{'word':['b0'],'coefficient':'1'}]
        b['actual_quantum_insertions']['tree_breaking_plus_insertion_minus_current']=a['actual_quantum_insertions']['tree_breaking_plus_insertion_minus_current']
        with self.assertRaises(AssertionError):adjudicate(a,b)

    def test_local_omega0_channel_retains_four_Lorentz_second_jets(self):
        data=self.a['actual_quantum_insertions'];a=decode_typed(data['free_local_breaking_Euler_b0'])
        b=decode_typed(data['free_local_product_Euler_b0'])
        self.assertEqual(len(a),4);self.assertFalse(canonical(self.w.add(a,b)))
        self.assertTrue(a)
        self.assertFalse(projected(a,lambda n,j:not j))

    def test_background_Ward_scope_negative_control_is_preserved(self):
        self.assertEqual(self.a['preserved_controls']['Ward_scope_nonzero_Euler_omega0'],[{'word':['A0_0__000'],'coefficient':'2'}])
        self.assertEqual(self.a['preserved_controls']['background_real_spatial_Euler'],[{'word':['A0_1__00'],'coefficient':'-2'}])

    def test_canonical_quotient_and_fixed_contraction_controls_remain_distinct(self):
        data=self.a['preserved_controls'];self.assertTrue(data['canonical_generator_scope_control_Euler_JB0_0'])
        self.assertEqual(data['preserved_original_horizontality_witness'],[{'word':['omega0__0'],'coefficient':'1'}])
        self.assertEqual(data['preserved_wrong_source_pairing'],'zH**2 - 1')
        self.assertTrue(data['preserved_fixed_contraction_defect'])

    def test_sources_backgrounds_and_quantum_target_do_not_acquire_unproved_pairs(self):
        self.assertEqual(len(self.a['Legendre_source_contract']),643)
        self.assertFalse(any(n.startswith('JA') for n in self.w.grades))
        self.assertEqual(self.a['actual_quantum_insertions']['background_source_corrections_nonzero'],0)
        a=deepcopy(self.a);b=deepcopy(self.b)
        a['actual_quantum_insertions']['strict_fixed_Tqprime_quantum_identity_imposed']=True
        b['actual_quantum_insertions']['strict_fixed_Tqprime_quantum_identity_imposed']=True
        with self.assertRaises(AssertionError):adjudicate(a,b)


if __name__=='__main__':unittest.main()
