"""Exact operator controls, coverage mutations and preservation of failure scope."""
import unittest
from copy import deepcopy
from audit_a10_e5_quartic_companion import (read,OUT,adjudicate_actual,compare_candidate,exact_real,
    operator_symbol_control,closed_trace_control,s)


class QuartetControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.a=read(OUT/'primary_v3.json');cls.b=read(OUT/'replay_v2.json')

    def mutation(self,change):
        a,b=deepcopy(self.a),deepcopy(self.b);change(a);change(b)
        with self.assertRaises(AssertionError):adjudicate_actual(a,b)

    def test_complete_routes_agree(self):
        self.assertTrue(adjudicate_actual(self.a,self.b)['all980100_slots_compared_between_routes'])

    def test_even_auxiliary_derivative_after_odd_factor(self):
        self.assertTrue(operator_symbol_control()['even_L_derivative_has_no_odd_prefix_sign'])

    def test_closed_trace_matches_full_products(self):
        self.assertTrue(closed_trace_control()['input_polynomials_not_mutated'])

    def test_unqualified_earlier_replay_is_rejected(self):
        with self.assertRaises(AssertionError):adjudicate_actual(self.a,read(OUT/'replay.json'))

    def test_ordinary_quartic_cannot_be_omitted(self):
        self.mutation(lambda x:x['family_poles'].__setitem__('ordinary_triangle',[]))

    def test_quartic_bubble_cannot_be_omitted(self):
        self.mutation(lambda x:x['family_poles'].__setitem__('quartic_bubble',[]))

    def test_mixed_triangle_cannot_be_omitted(self):
        self.mutation(lambda x:x['family_poles'].__setitem__('mixed_triangle',[]))

    def test_domain_cannot_shrink_to_heavy(self):
        self.mutation(lambda x:x['domain'].__setitem__('antighost_directions',33))

    def test_BB_quartic_inventory_cannot_disappear(self):
        self.mutation(lambda x:x['literal_inventory'].__setitem__('ordinary_two_heavy_B_quartic_per_Lorentz',0))

    def test_field_measure_or_source_activation_cannot_promote(self):
        self.mutation(lambda x:x.__setitem__('sources_activated',True))

    def test_full_E5_cannot_promote(self):
        self.mutation(lambda x:x.__setitem__('full_E5_PASS',True))

    def test_precandidate_blind_boundary_required(self):
        self.mutation(lambda x:x.__setitem__('frozen_candidate_read_during_actual_calculation',True))

    def test_heat_profiles_are_not_merged(self):
        self.mutation(lambda x:x['heat_profiles'].__setitem__('box',4))

    def test_wrong_value_is_detected_by_family_sum(self):
        self.mutation(lambda x:x['actual_pole'][0].__setitem__(4,'1'))

    def test_floating_coefficients_rejected(self):
        with self.assertRaises(AssertionError):exact_real('0.64')

    def test_real_quartic_failure_and_Euler_witness(self):
        result=compare_candidate(self.a)
        self.assertEqual(result['nonzero_difference_slots'],5528)
        self.assertEqual(result['real_Euler_witness']['difference'],'32/25')
        self.assertTrue(result['real_Euler_witness']['direct_left_deletion_agrees'])
        self.assertFalse(result['candidate_adjusted_or_adopted'])


if __name__=='__main__':unittest.main()
