"""Small, exact BRST/BV comparators; never changes frozen M08 data.

Run with the repository pole-blind guard and PYTHONDONTWRITEBYTECODE=1.
All results are stdout only. No cochain catalog, rank or cohomology is computed.
"""
from __future__ import annotations

import argparse
import itertools
import json
import time
from dataclasses import dataclass
from pathlib import Path

import sympy as s


def epsilon(a, b, c):
    if len({a, b, c}) != 3:
        return 0
    return (-1) ** sum(x > y for i, x in enumerate((a, b, c)) for y in (a, b, c)[i + 1 :])


class Exterior:
    """Finite exterior words over a commutative exact polynomial ring."""

    def __init__(self):
        self.parity = {}
        self.even_symbols = {}
        self.odd_order = {}

    def variable(self, name, parity):
        assert name not in self.parity
        self.parity[name] = parity
        if parity:
            self.odd_order[name] = len(self.odd_order)
            return {(name,): s.Integer(1)}
        sym = s.Symbol(name)
        self.even_symbols[name] = sym
        return {(): sym}

    @staticmethod
    def clean(poly):
        return {w: v for w, c in poly.items() if (v := s.expand(c)) != 0}

    def add(self, *polys):
        out = {}
        for poly in polys:
            for w, c in poly.items():
                out[w] = out.get(w, 0) + c
        return self.clean(out)

    def scale(self, poly, scalar):
        return self.clean({w: scalar * c for w, c in poly.items()})

    def mul(self, *polys):
        result = {(): s.Integer(1)}
        for poly in polys:
            out = {}
            for wa, ca in result.items():
                for wb, cb in poly.items():
                    word = wa + wb
                    if len(set(word)) != len(word):
                        continue
                    inversions = sum(self.odd_order[x] > self.odd_order[y] for i, x in enumerate(word) for y in word[i + 1 :])
                    ordered = tuple(sorted(word, key=self.odd_order.__getitem__))
                    out[ordered] = out.get(ordered, 0) + (-1) ** inversions * ca * cb
            result = self.clean(out)
        return result

    def partial(self, poly, name, side="left"):
        if not self.parity[name]:
            return self.clean({w: s.diff(c, self.even_symbols[name]) for w, c in poly.items()})
        out = {}
        for word, c in poly.items():
            if name in word:
                pos = word.index(name)
                sign = (-1) ** (pos if side == "left" else len(word) - pos - 1)
                new = word[:pos] + word[pos + 1 :]
                out[new] = out.get(new, 0) + sign * c
        return self.clean(out)

    def derive(self, poly, images, parity=1):
        out = {}
        for name, image in images.items():
            if image and not self.parity[name]:
                # The coefficient is written BEFORE its exterior word. An odd
                # coefficient image must therefore also precede that word.
                out = self.add(out, self.mul(image, self.partial(poly, name)))
        for word, coeff in poly.items():
            for pos, name in enumerate(word):
                if image := images.get(name):
                    prefix = {word[:pos]: coeff * (-1) ** (parity * pos)}
                    out = self.add(out, self.mul(prefix, image, {word[pos + 1 :]: s.Integer(1)}))
        return out

    def bracket(self, f, h, pairs):
        out = {}
        for z, source in pairs:
            factor = (-1) ** self.parity[z]
            out = self.add(out, self.scale(self.mul(self.partial(f, z, "right"), self.partial(h, source)), factor))
            out = self.add(out, self.scale(self.mul(self.partial(f, source, "right"), self.partial(h, z)), -factor))
        return out

    @staticmethod
    def record(poly):
        return [{"odd_word": list(w), "coefficient": str(c)} for w, c in sorted(poly.items())]


@dataclass
class Checks:
    count: int = 0

    def zero(self, value, label):
        self.count += 1
        if value:
            raise AssertionError(f"{label}: {Exterior.record(value)}")

    def equal(self, algebra, a, b, label):
        self.zero(algebra.add(a, algebra.scale(b, -1)), label)

    def true(self, value, label):
        self.count += 1
        if not value:
            raise AssertionError(label)


def cross(a, x, y):
    return [a.add(*(a.scale(a.mul(x[j], y[k]), epsilon(i, j, k)) for j in range(3) for k in range(3) if epsilon(i, j, k))) for i in range(3)]

def vector(a, prefix, parity):
    return [a.variable(f"{prefix}{i}", parity) for i in range(3)]

def dot(a, x, y):
    return a.add(*(a.mul(i, j) for i, j in zip(x, y)))


def model(partial=False):
    if not __debug__:
        raise RuntimeError("EXACT_CONTROL_REQUIRES_ASSERTIONS_ENABLED")
    a, checks = Exterior(), Checks()
    g, xi = s.symbols("g xi")
    c = vector(a, "c", 1)
    u = vector(a, "u", 1) if partial else None
    names = ("X1", "X2", "Y1", "Y2") if partial else ("X", "Y")
    fields = {name: vector(a, name, 0) for name in names}
    pairs, forward, sources = [], {}, {}
    if partial:
        R = [a.scale(p, -s.Rational(1, 2)) for p in cross(a, u, u)]
        qc = [a.add(a.scale(R[i], g), a.scale(p, -g / 2)) for i, p in enumerate(cross(a, c, c))]
        qu = [a.scale(p, -g) for p in cross(a, c, u)]
        for i in range(3):
            forward[f"u{i}"] = qu[i]
    else:
        R = None
        qc = [a.scale(p, -g / 2) for p in cross(a, c, c)]
    for i in range(3):
        forward[f"c{i}"] = qc[i]
    for name, vec in fields.items():
        ghost = [a.add(c[i], a.scale(u[i], 1 if name.startswith("X") else -1)) for i in range(3)] if partial else c
        for i, p in enumerate(cross(a, ghost, vec)):
            forward[f"{name}{i}"] = a.scale(p, -g)
    for name in list(forward):
        source = ("Lc" if name.startswith("c") else "Lu" if name.startswith("u") else "K" + name[:-1]) + name[-1]
        sources[source] = a.variable(source, 1 - a.parity[name])
        pairs.append((name, source))
    if partial:
        S0 = a.add(a.scale(dot(a, cross(a, fields["X1"], fields["X2"]), cross(a, fields["X1"], fields["X2"])), s.Rational(1, 4)),
                   a.scale(dot(a, cross(a, fields["Y1"], fields["Y2"]), cross(a, fields["Y1"], fields["Y2"])), s.Rational(1, 4)))
    else:
        xy = cross(a, fields["X"], fields["Y"])
        S0 = a.scale(dot(a, xy, xy), s.Rational(1, 4))
    S = a.add(S0, *(a.mul(sources[j], forward[z]) for z, j in pairs))
    variables = {name: ({(name,): s.Integer(1)} if p else {(): a.even_symbols[name]}) for name, p in a.parity.items()}
    Q = {name: a.bracket(S, var, pairs) for name, var in variables.items()}
    for name, image in forward.items():
        checks.equal(a, Q[name], image, f"forward {name}")
    for z, j in pairs:
        checks.equal(a, Q[j], a.partial(S, z), f"left reverse {j}")
        checks.equal(a, a.partial(S, z, "right"), a.scale(a.partial(S, z), (-1) ** a.parity[z]), f"right/left {z}")
    checks.zero(a.bracket(S, S, pairs), "classical master equation")
    checks.zero(a.derive(S0, Q), "physical action invariance")
    for name in Q:
        checks.zero(a.derive(Q[name], Q), f"nilpotence {name}")
    # Derive the old mixed prescription independently from the same action.
    bad = dict(Q)
    for z, j in pairs:
        if a.parity[z]:
            bad[j] = a.partial(S, z, "right")
    bad_square = a.derive(bad["Lc0"], bad)
    checks.true(bool(bad_square), "wrong reverse-source sign must fail")
    result = {"model": "SU2xSU2_diagonal_SU2" if partial else "SU2_reduced_Yang_Mills", "minimal_generator_count": len(Q),
              "master_equation": "EXACT_ZERO", "all_generator_squares": "EXACT_ZERO", "wrong_sign_Lc0_square": a.record(bad_square)}
    if partial:
        # Split ghost images are derived from the two ordinary SU(2) rules.
        for sign in (1, -1):
            split = [a.add(c[i], a.scale(u[i], sign)) for i in range(3)]
            for i, ordinary in enumerate(cross(a, split, split)):
                checks.equal(a, a.add(qc[i], a.scale(qu[i], sign)), a.scale(ordinary, -g / 2), "split ghost identity")
        for i, r in enumerate(R):
            checks.equal(a, a.derive(r, Q), a.scale(cross(a, c, R)[i], -g), "derived R image")
        bar, aux = vector(a, "bar", 1), vector(a, "aux", 0)
        for i in range(3):
            variables[f"bar{i}"] = bar[i]
            variables[f"aux{i}"] = aux[i]
            Q[f"bar{i}"] = a.add(a.scale(aux[i], -1), a.scale(cross(a, c, bar)[i], -g))
            Q[f"aux{i}"] = a.add(a.scale(cross(a, c, aux)[i], -g), a.scale(cross(a, R, bar)[i], -g**2))
        lie, contraction = [], []
        vectors = [("c", c, False), ("u", u, False), ("bar", bar, False), ("aux", aux, False)]
        vectors += [(name, v, False) for name, v in fields.items()]
        vectors += [(prefix, [sources[f"{prefix}{i}"] for i in range(3)], True) for prefix in ("Lc", "Lu", "KX1", "KX2", "KY1", "KY2")]
        for alpha in range(3):
            L, I = {}, {}
            for prefix, vec, dual in vectors:
                for i in range(3):
                    L[f"{prefix}{i}"] = a.add(*(a.scale(vec[j], epsilon(j, alpha, i) if dual else -epsilon(i, alpha, j)) for j in range(3)))
            for i in range(3):
                I[f"c{i}"] = {(): s.Integer(alpha == i)} if alpha == i else {}
                I[f"aux{i}"] = {}  # Completed-Weil auxiliary, not raw b.
            lie.append(L)
            contraction.append(I)
        trial_I = dict(contraction[1])
        trial_I["aux0"] = a.scale(bar[2], -g)
        trial_residual = a.add(a.derive(Q["bar0"], trial_I), a.scale(lie[1]["bar0"], -g))
        checks.equal(a, trial_residual, a.scale(bar[2], g), "preregistered auxiliary-lift failure")
        raw_b = [a.add(aux[i], a.scale(cross(a, c, bar)[i], g)) for i in range(3)]
        for i in range(3):
            checks.zero(a.derive(raw_b[i], Q), "raw nonminimal doublet b is closed")
            for alpha in range(3):
                checks.equal(a, a.derive(raw_b[i], contraction[alpha]), a.add(*(a.scale(bar[j], g * epsilon(i, alpha, j)) for j in range(3))), "raw b contraction")
        for name in Q:
            checks.zero(a.derive(Q[name], Q), f"extended nilpotence {name}")
            for alpha in range(3):
                L, I = lie[alpha], contraction[alpha]
                checks.equal(a, a.add(a.derive(Q[name], I), a.derive(I.get(name, {}), Q)), a.scale(L[name], g), f"Cartan {alpha} {name}")
                checks.equal(a, a.derive(Q[name], L, 0), a.derive(L[name], Q), f"Lie Q {alpha} {name}")
                for beta in range(3):
                    rhs = a.add(*(a.scale(lie[k][name], epsilon(alpha, beta, k)) for k in range(3)))
                    lhs = a.add(a.derive(lie[beta][name], L, 0), a.scale(a.derive(L[name], lie[beta], 0), -1))
                    checks.equal(a, lhs, rhs, "Lie closure")
                    rhs_i = a.add(*(a.scale(contraction[k].get(name, {}), epsilon(alpha, beta, k)) for k in range(3)))
                    lhs_i = a.add(a.derive(contraction[beta].get(name, {}), L, 0), a.scale(a.derive(L[name], contraction[beta]), -1))
                    checks.equal(a, lhs_i, rhs_i, "Lie contraction")
                    checks.zero(a.add(a.derive(contraction[beta].get(name, {}), I), a.derive(I.get(name, {}), contraction[beta])), "contraction anticommutator")
        # Source-free Cartan restriction. The curvature remains composite.
        delta = {f"u{i}": {} for i in range(3)}
        for name, vec in fields.items():
            for i, p in enumerate(cross(a, u, vec)):
                delta[f"{name}{i}"] = a.scale(p, -g if name.startswith("X") else g)
        for i in range(3):
            delta[f"bar{i}"] = a.scale(aux[i], -1)
            delta[f"aux{i}"] = a.scale(cross(a, R, bar)[i], -g**2)
        for name in delta:
            checks.equal(a, a.derive(delta[name], delta), a.scale(a.add(*(a.mul(R[alpha], lie[alpha][name]) for alpha in range(3))), -g**2), f"Cartan square {name}")
        for r in R:
            checks.zero(a.derive(r, delta), "Cartan curvature closure")
        F = [a.add(x, y) for x, y in zip(cross(a, fields["X1"], fields["Y1"]), cross(a, fields["X2"], fields["Y2"]))]
        psi = dot(a, bar, [a.add(F[i], a.scale(aux[i], -xi / 2)) for i in range(3)])
        Sgf = a.add(S0, a.scale(a.derive(psi, delta), -1))
        for L in lie:
            checks.zero(a.derive(psi, L, 0), "invariant gauge fixing fermion")
        checks.zero(a.derive(Sgf, delta), "equivariant gauge-fixed action")
        quartic = {w: coeff for w, coeff in Sgf.items() if len(w) == 4 and sum(n.startswith("bar") for n in w) == 2 and sum(n.startswith("u") for n in w) == 2}
        checks.true(bool(quartic), "nonzero quartic ghost term")
        # Broken gauge Jacobian at a local regular patch, evaluated exactly.
        patch = {a.even_symbols[f"{prefix}{i}"]: int(i == axis) for prefix, axis in (("X1", 0), ("Y1", 0), ("X2", 1), ("Y2", 1)) for i in range(3)}
        jac = s.zeros(3)
        for alpha in range(3):
            broken = {}
            for name, vec in fields.items():
                for i in range(3):
                    broken[f"{name}{i}"] = a.add(*(a.scale(vec[j], (-g if name.startswith("X") else g) * epsilon(i, alpha, j)) for j in range(3)))
            for i in range(3):
                val = a.derive(F[i], broken, 0)
                checks.true(set(val).issubset({()}), "Jacobian commuting")
                jac[i, alpha] = s.expand(val.get((), 0).subs(patch))
        checks.true(jac.det() != 0, "local gauge fixing is nondegenerate")
        # Complete the COMPARATOR's nonminimal BV source system and rederive
        # sources from the gauge-fixed action, not the old source-free S0.
        full_forward = {name: Q[name] for name in list(forward) + [f"{p}{i}" for p in ("bar", "aux") for i in range(3)]}
        full_pairs = list(pairs)
        for prefix, dual_prefix in (("bar", "Jbar"), ("aux", "Jaux")):
            dual_vec = vector(a, dual_prefix, 1 - a.parity[f"{prefix}0"])
            for i in range(3):
                z, j = f"{prefix}{i}", f"{dual_prefix}{i}"
                sources[j] = variables[j] = dual_vec[i]
                full_pairs.append((z, j))
                for alpha in range(3):
                    lie[alpha][j] = a.add(*(a.scale(dual_vec[k], epsilon(k, alpha, i)) for k in range(3)))
        full_S = a.add(Sgf, *(a.mul(sources[j], full_forward[z]) for z, j in full_pairs))
        full_Q = {name: a.bracket(full_S, var, full_pairs) for name, var in variables.items()}
        checks.zero(a.bracket(full_S, full_S, full_pairs), "gauge-fixed nonminimal BV master equation")
        checks.zero(a.derive(Sgf, full_Q), "full Q preserves gauge-fixed physical action")
        for z, image in full_forward.items():
            checks.equal(a, full_Q[z], image, "full BV forward images unchanged")
        for name in full_Q:
            checks.zero(a.derive(full_Q[name], full_Q), "full gauge-fixed BV nilpotence")
            for alpha in range(3):
                checks.equal(a, a.add(a.derive(full_Q[name], contraction[alpha]), a.derive(contraction[alpha].get(name, {}), full_Q)), a.scale(lie[alpha][name], g), "full BV Cartan identity")
                checks.equal(a, a.derive(full_Q[name], lie[alpha], 0), a.derive(lie[alpha][name], full_Q), "full BV Lie Q commutator")
        invariant_pair = dot(a, [sources[f"Lc{i}"] for i in range(3)], R)
        for alpha in range(3):
            checks.zero(a.derive(invariant_pair, lie[alpha], 0), "Lc R invariant")
            checks.zero(a.derive(invariant_pair, contraction[alpha]), "Lc R horizontal")
            checks.zero(a.derive(a.derive(invariant_pair, Q), contraction[alpha]), "Lc R preserved")
            checks.zero(a.derive(a.derive(invariant_pair, full_Q), contraction[alpha]), "full BV Lc R preserved")
        result.update({"extended_generator_count": len(Q), "cartan_identities": "EXACT_ON_ALL_GENERATORS", "equivariant_square": "EXACT_ON_ALL_CARTAN_GENERATORS", "gauge_fixing_Jacobian": [[str(x) for x in row] for row in jac.tolist()], "gauge_fixing_Jacobian_determinant": str(jac.det()), "quartic_ghost_terms": a.record(quartic), "source_pair_basicness_preserved": True, "initial_auxiliary_contraction_trial_residual": a.record(trial_residual), "completed_Weil_auxiliary_contraction": "ZERO_DERIVED_FROM_RAW_DOUBLET"})
        result.update({"gauge_fixed_full_BV_generator_count": len(full_Q), "gauge_fixed_full_BV_master_equation": "EXACT_ZERO",
                       "gauge_fixed_full_BV_all_generator_squares_and_Cartan_identities": "EXACT_ZERO"})
    result["exact_assertion_count"] = checks.count
    return result


def m08_primary():
    # Explicit reuse: qualified raw-coordinate geometry and AST extraction.
    # The separately coded replay does not import either helper.
    from hbp_structural_preflight import split_geometry, source_coefficients
    here = Path(__file__).resolve().parent
    images = {v["identity"]: v for v in json.loads((here / "frozen_rh_composite_adjudication/S6_BSigma_17_images_V2.json").read_text())["images"]}
    coeff, rsign = source_coefficients(images)
    old_sign = coeff["second"] - coeff["first"]
    assert old_sign == rsign == -1
    # An even action differentiated w.r.t. an odd field has left=-right.
    candidate_sign = -old_sign
    A, _, R, words = split_geometry()
    rv = R[:, words.index((1, 26))]
    old_pair = s.simplify((old_sign + rsign) * (A[0] * rv)[4])
    new_pair = s.simplify((candidate_sign + rsign) * (A[0] * rv)[4])
    assert old_pair == -2 * s.I and new_pair == 0
    checks = 0
    old_selected = new_selected = None
    for a, b in itertools.combinations(range(12), 2):
        adjoint = sum((A[a][k, b] * A[k].T for k in range(12)), s.zeros(12))
        commutator = A[a].T * A[b].T - A[b].T * A[a].T
        assert (adjoint + commutator).applyfunc(s.simplify) == s.zeros(12)
        candidate = -candidate_sign * adjoint - candidate_sign**2 * commutator
        assert candidate.applyfunc(s.simplify) == s.zeros(12)
        checks += 1
        if (a, b) == (0, 4):
            old_selected = s.simplify((-old_sign * adjoint - old_sign**2 * commutator)[0, 4])
            new_selected = s.simplify(candidate[0, 4])
    assert old_selected == 1 and new_selected == 0
    return {"route": "REUSED_RAW_COORDINATE_GEOMETRY_AND_CURRENT_IMAGE_AST", "f_4_0_4": str(A[0][4, 4]), "R4_u1_u26": str(rv[4]),
            "frozen_reverse_source_self_sign": str(old_sign), "left_bracket_candidate_self_sign": str(candidate_sign),
            "frozen_pair_residual": str(old_pair), "candidate_pair_residual": str(new_pair),
            "frozen_source_square": str(old_selected), "candidate_source_square": str(new_selected),
            "source_self_square_matrix_blocks_checked": checks,
            "Sigma_nonhorizontal_coefficient": str(-A[0][4, 4]), "full_M08_repair_or_ST_recomputation": False}


def build():
    return {"schema": "SOURCE_CONVENTION_COMPARATOR_V1", "results": [model(False), model(True)], "M08_bounded_comparison": m08_primary()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=("ordinary", "partial", "both", "full"), default="full")
    args = parser.parse_args()
    start, cpu = time.perf_counter(), time.process_time()
    result = build() if args.model == "full" else {"schema": "SOURCE_CONVENTION_COMPARATOR_V1", "results": [model(p) for p in (False, True) if args.model == "both" or (args.model == "partial") == p]}
    print(json.dumps(result, indent=2, sort_keys=True), flush=True)
    import sys
    print(json.dumps({"wall_seconds": time.perf_counter() - start, "cpu_seconds": time.process_time() - cpu}), file=sys.stderr)


if __name__ == "__main__":
    main()
