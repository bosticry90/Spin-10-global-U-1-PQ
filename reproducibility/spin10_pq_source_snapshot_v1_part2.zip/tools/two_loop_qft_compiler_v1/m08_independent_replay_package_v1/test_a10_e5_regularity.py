"""Adversarial exact tests; no test count substitutes for the all-order proof."""
import unittest
from copy import deepcopy
from a10_e5_regularity import *
from audit_a10_e5_regularity import adjudicate


class Regularity(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.P=read(OUT/'primary.json');cls.R=read(OUT/'replay.json')

    def test_01_distinct_routes_match(self):
        self.assertEqual(adjudicate(self.P,self.R)['scientific_gate'],STATUS)

    def test_02_literal_density_derivative_scope(self):
        A,S=action_structure();self.assertEqual(S,self.P['action_structure'])
        self.assertEqual(len(A['local_terms']),34)

    def test_03_spatial_sign_negative_control(self):
        self.assertIn({'word':['B0_1__00'],'coefficient':'-1'},self.P['free_principal_columns']['B0_1'])
        w=algebra();E={n:decode(v) for n,v in self.P['free_principal_columns'].items()}
        E['B0_1']=w.scale(E['B0_1'],-1)
        with self.assertRaises(AssertionError):jet_charts(E,w,(2,))

    def test_04_no_false_equation_independence(self):
        r=3;row=self.P['jet_chart']['finite_controls'][1]
        self.assertEqual(row['independent_equations']+45,508*comb(r+2,4))
        self.assertNotEqual(row['independent_equations'],508*comb(r+2,4))

    def test_05_arbitrary_order_count_and_unique_pivots(self):
        # Counts support, but do not replace, the induction proof.
        for r in range(2,20):
            self.assertEqual(463*comb(r+2,4)+45*comb(r+1,3)+45*comb(r+1,4),508*comb(r+2,4))
        E={'B0_0':{},'B0_1':{},'B0_2':{},'B0_3':{},'x_S_0':{}}
        L=layout(7,E);self.assertEqual(len(L),len({v for n,j,v in L}))

    def test_06_all_four_scalar_sectors(self):
        cols=self.P['free_principal_columns']
        for sec,n in DIM.items():
            self.assertEqual(sum(k.startswith('x_'+sec+'_') for k in cols),n)
            self.assertIn({'word':[f'x_{sec}_0__00'],'coefficient':'-1'},cols[f'x_{sec}_0'])

    def test_07_noether_source_left_sign(self):
        for a in IDS:
            for mu in range(4):self.assertIn({'word':[f'JB{a}_{mu}__{mu}'],'coefficient':'1'},
              self.P['Noether']['ghost_antifield_columns'][f'JC{a}'])

    def test_08_nonminimal_type_and_grading(self):
        w=algebra()
        for n,records in self.P['nonminimal']['point_maps'].items():
            self.assertTrue(w.grade(decode(records),w.grades[n]),n)
        self.assertEqual(self.P['nonminimal']['unchanged_spectator_pairs'],508)

    def test_09_nonminimal_ghost_source_correction_required(self):
        nm=self.P['nonminimal']
        self.assertEqual(nm['wrong_unchanged_ghost_source_cross_bracket'],
          [{'word':['ub13'],'coefficient':'-sqrt(2)*I*g10/2'}])
        self.assertEqual(nm['field_only_action_residual_coefficients'],1304)

    def test_10_inverse_and_jet_maps(self):
        nm=self.P['nonminimal'];w=algebra();maps={n:decode(v) for n,v in nm['point_maps'].items()}
        for n in ('L13','JC1','Jub13','b0','Jb0'):
            self.assertFalse(canonical(w.add(w.replace(maps[n],maps),w.scale(w.var(n),-1))))
            self.assertEqual(w.replace(w.var(n,(0,1,1)),maps),w.dword(maps[n],(0,1,1)))

    def test_11_ghost_antifield_primitive_is_needed(self):
        c=homotopy_control('replay')
        self.assertEqual(c,self.P['homotopy'])
        self.assertEqual(c['missing_ghost_antifield_cycle'],'v')

    def test_12_polynomial_not_inverse_coupling_ring(self):
        for rows_ in self.P['nonminimal']['point_maps'].values():
            for row in rows_:
                c=s.sympify(row['coefficient'],locals={'g10':g})
                self.assertFalse(s.denom(c).has(g))
                self.assertFalse(c.has(s.Float))

    def test_13_global_PQ_not_local_gauge(self):
        self.assertEqual(pq_control('replay'),self.P['PQ'])
        self.assertEqual(self.P['PQ']['frozen_scalar_charges']['S'],-4)
        text=(ROOT/'calculations/canonical_so10_scalar_reconstruction/RECORD.md').read_text(encoding='utf-8')
        self.assertIn('| `q_PQ` | `+1` | `0` | `+2` | `-2` | `-4` |',text)
        self.assertFalse(self.P['PQ']['PQ_gauged'])

    def test_14_scope_adversary_rejects_overclaim(self):
        bad=deepcopy(self.P);bad['full_E5_PASS']=True
        with self.assertRaises(AssertionError):adjudicate(bad,bad)
        self.assertFalse(self.P['invariant_subspace_homotopy_proved'])
        self.assertFalse(self.P['homotopy']['homology_modulo_divergences_proved'])

    def test_15_failed_attempt_preserved_excluded(self):
        attempt=read(OUT/'primary_attempt_1.json')
        self.assertEqual(attempt['execution_state'],'FAILED')
        self.assertFalse(attempt['completed_evidence']);self.assertFalse(attempt['counted_in_final_PASS'])
        self.assertIn("KeyError: 'expression'",attempt['log'])

    def test_16_normality_dependency_and_proof_scope(self):
        proof=(HERE/'A10_E5_REGULARITY_DERIVATION_V1.md').read_text(encoding='utf-8')
        self.assertIn('strictly decrease K',proof)
        self.assertIn('their only polynomial syzygies are the Koszul relations'.lower(),proof.lower())
        self.assertIn('not a proof of quantum restoration',proof)
        self.assertFalse(self.P['A1_A5_discharged'])


if __name__=='__main__':unittest.main()
