"""Exact polarized realization, with untagged commuting background jets only.

No IBP, EOM, BRST quotient or final homogeneous-field statistics projection.
The background-only averaging certificate describes a polynomial realization
kernel; it does not change the canonical internal channel basis.
"""
from collections import defaultdict
from itertools import product, permutations
from functools import lru_cache
import sympy as sp
from jcat3_contract_preflight import HERE, load, canonical
from jcat_background_packets_v2 import serial, triplet_data, polynomial_columns
from execute_scalar_ast_channel_bridge import matrix
from int8_block_conjugation_v2 import BlockConjugation, address_key
from jcat_internal_permutations import InternalPermutation, permutation_matrix
from jcat_physical_jets import rename

OLD = HERE/'frozen_jcat_background_packets_v2'
BLOCKER = 'M08_JCAT7_GLOBAL_BACKGROUND_PACKET_COMPLETENESS_REPLAY_PENDING'


def contract():
    return {'contract_id': 'M08_JCAT7_EXACT_PHYSICAL_REALIZATION_CONTRACT_V3',
        'status': 'FROZEN_USER_ADJUDICATED_FAITHFUL_REPLAY_CONTRACT',
        'homogeneous_occurrences': 'INDEPENDENTLY_TAGGED_UNTIL_JCAT11',
        'background_occurrences': 'SAME_COMMUTING_CONNECTION_AND_ITS_ORDINARY_JETS',
        'typing_adjudication': 'Direct user reply: keep homogeneous occurrences tagged until JCAT11; identify repeated background connections now',
        'rho': 'Ordered joint internal/Lorentz jets -> polarized physical tensor polynomials',
        'N_realization': 'Exact kernel of rho; no IBP/EOM/BRST or final statistics',
        'faithful_domain': 'E_ordered / N_realization',
        'acceptance': 'span(q P_primary)=q ker(delta_background)=ker(delta_faithful); also equal realized spans',
        'source_addresses': 'All 431 signatures and every ordered address retained',
        'slot_action': 'Joint internal slot action with attached Lorentz and derivative relocation',
        'variation_codomain': 'Faithful ordinary variation-polynomial coordinates, or an explicitly certified realization quotient',
        'counts': ['EXPANSION_ADDRESS_COUNT', 'ORDERED_COORDINATE_DIMENSION',
            'REALIZATION_NULLITY', 'REALIZED_OPERATOR_DIMENSION', 'BACKGROUND_COVARIANT_PACKET_DIMENSION'],
        'excluded_relations': ['IBP', 'EOM', 'BRST_exact', 'cohomology',
            'general_final_Bose_Fermi_projection', 'dynamical_equations', 'loop_relations'],
        'physical_Lorentz_dimension': 4, 'upstream_basis_changed': False,
        'IBP_applied': False, 'statistics_applied': False, 'C5_executed': False}


def quotient(rho):
    reduced, pivots = rho.rref()
    rank = len(pivots)
    q = sp.SparseMatrix(reduced[:rank, :])
    section = sp.SparseMatrix(rho.cols, rank, {(j, i): 1 for i, j in enumerate(pivots)})
    null = sp.SparseMatrix.hstack(*rho.nullspace()) if rank < rho.cols else sp.zeros(rho.cols, 0)
    assert q*section == sp.eye(rank)
    assert rho == rho*section*q
    assert q*null == sp.zeros(rank, null.cols)
    assert rank+null.cols == rho.cols
    return q, section, null, pivots


def primary_transport():
    old = load(OLD/'JCAT7V2_triplet_primary_packets.json')
    return {'status': 'PASS_IMMUTABLE_PRIMARY_REUSE',
        'primary_source_sha256': old['artifact_sha256'],
        'expansion_addresses': old['expansion_addresses'],
        'packet_parents': old['packet_parents'],
        'expansion_matrix': old['expansion_matrix'],
        'coefficient_changes': False, 'replay_coefficients_imported': False,
        'interpretation': 'Bounded qualified SU2 kinetic fiber, not a new full physical-role normalization claim'}


def full_lorentz_replay(actions=None):
    """Direct independent four-dimensional ordinary-polynomial prolongation."""
    engine, T = triplet_data()
    if actions is not None: T = actions
    def vector(name): return sp.Matrix(sp.symbols(f'{name}0:3'))
    x, y, q, s, b, t, bt = [vector(n) for n in ('x', 'y', 'box_x', 'box_y', 'div_a', 'theta', 'box_theta')]
    p = [vector(f'dx_{mu}_') for mu in range(4)]
    r = [vector(f'dy_{mu}_') for mu in range(4)]
    a = [vector(f'a_{mu}_') for mu in range(4)]
    dt = [vector(f'dtheta_{mu}_') for mu in range(4)]
    eta = (-1, 1, 1, 1)
    def action(v): return sum((v[i]*T[i] for i in range(3)), sp.zeros(3))
    def value(n, args):
        from jcat_internal_permutations import coordinates
        return [sp.expand(sum(v*sp.prod(args[i][z] for i, z in enumerate(coordinates(j, (3,)*n)))
            for (j, _), v in basis.todok().items())) for _, basis in engine.basis((2,)*n)[1]]
    targets = [*value(2, (q, y)), sum(eta[mu]*value(2, (p[mu], r[mu]))[0] for mu in range(4)),
        *value(2, (x, s)), *value(3, (b, x, y)),
        sum(eta[mu]*value(3, (a[mu], p[mu], y))[0] for mu in range(4)),
        sum(eta[mu]*value(3, (a[mu], x, r[mu]))[0] for mu in range(4))]
    targets += [sum(eta[mu]*value(4, (a[mu], a[mu], x, y))[i] for mu in range(4)) for i in range(3)]
    variables = [*x, *y, *q, *s, *b, *(z for v in p+r+a for z in v)]
    variations = [*(action(t)*x), *(action(t)*y),
        *(action(t)*q+2*sum((eta[mu]*action(dt[mu])*p[mu] for mu in range(4)), sp.zeros(3, 1))+action(bt)*x),
        *(action(t)*s+2*sum((eta[mu]*action(dt[mu])*r[mu] for mu in range(4)), sp.zeros(3, 1))+action(bt)*y),
        *(action(t)*b+sum((eta[mu]*action(dt[mu])*a[mu] for mu in range(4)), sp.zeros(3, 1))-bt),
        *(z for mu in range(4) for z in action(t)*p[mu]+action(dt[mu])*x),
        *(z for mu in range(4) for z in action(t)*r[mu]+action(dt[mu])*y),
        *(z for mu in range(4) for z in action(t)*a[mu]-dt[mu])]
    deltas = [sp.expand(sum(sp.diff(f, z)*dz for z, dz in zip(variables, variations))) for f in targets]
    vm, V = polynomial_columns(deltas, variables+[*t, *bt, *(z for v in dt for z in v)])
    rm, rho = polynomial_columns(targets, variables)
    return {'status': 'PASS_EXACT_FOUR_DIMENSIONAL_POLYNOMIAL_REPLAY',
        'metric': list(eta), 'polarized_homogeneous_fields': ['x', 'y'],
        'realization_matrix': serial(rho), 'realization_monomials': rm,
        'realization_variables': [str(z) for z in variables],
        'variation_matrix': serial(V), 'variation_monomials': vm,
        'variation_variables': [str(z) for z in variables+[*t, *bt, *(z for v in dt for z in v)]],
        'kernel': serial(sp.Matrix.hstack(*V.nullspace())),
        'primary_coefficients_imported': False,
        'independence': {'ALGORITHM_INDEPENDENT': True, 'COEFFICIENT_CODE_PATH_INDEPENDENT': True,
            'LIBRARY_INDEPENDENT': False, 'RUNTIME_INDEPENDENT': False,
            'shared_inputs': 'Qualified SU2 carriers and decomposition duals; frozen action convention'},
        'IBP_applied': False, 'statistics_applied': False}


def physical_background_action():
    """Transport the frozen physical connection, not an arbitrary Lie identification."""
    from execute_scalar_adapter_v2 import registry_generators
    from int9_scalar_swap import clean
    catalog = BlockConjugation.from_frozen()
    roots = load(HERE/'frozen_c3/C3_representation_basis.json')['h_basis']
    pa = sp.SparseMatrix(45, 12, {(r['index'], j): sp.sympify(r['coefficient'])
        for j, col in enumerate(roots) for r in col['raw_so10_coordinates']})
    left_inverse = clean((pa.H*pa).inv()*pa.H)
    rows = load(HERE/'frozen_int8_block_conjugation_v2/INT8V2_physical_copy_maps.json')['components']
    connection = next(r for r in rows if r['source_component'] == 'A_adjoint_H_0_0_2_0_PQ+0')
    physical_columns = matrix(connection['physical_columns'])
    coefficients = clean(left_inverse*physical_columns)
    assert clean(pa*coefficients-physical_columns) == sp.zeros(45, 3)
    generators = registry_generators((0, 0, 2, 0), catalog.duals)
    actions = [clean(sum((coefficients[j, a]*generators[j] for j in range(12)), sp.zeros(3))) for a in range(3)]
    engine, diagnostic = triplet_data()
    ds = sp.Matrix.hstack(*(sp.Matrix(9, 1, list(m)) for m in diagnostic))
    rhs = sp.Matrix.hstack(*(sp.Matrix(9, 1, list(m)) for m in actions))
    transition = clean((ds.T*ds).inv()*ds.T*rhs)
    assert clean(ds*transition-rhs) == sp.zeros(9, 3) and transition.det() != 0
    assert all(actions[i][:, j]+actions[j][:, i] == sp.zeros(3, 1) for i in range(3) for j in range(3))
    return {'status': 'PASS_TYPED_FROZEN_PHYSICAL_BACKGROUND_ACTION',
        'background_component': connection['source_component'],
        'raw_SO10_physical_columns': serial(physical_columns),
        'H_root_coordinate_columns': serial(coefficients),
        'scalar_triplet_actions': [serial(m) for m in actions],
        'diagnostic_connection_coordinates_from_current_registry': serial(transition),
        'transition_determinant': str(transition.det()),
        'physical_column_residual': 'ZERO_EXACT', 'action_transport_residual': 'ZERO_EXACT',
        'normalization_authority': 'INT12 physical gauge columns sqrt(2) times INT8 columns, paired with canonical SO10 generators divided by sqrt(2); factors cancel',
        'upstream_objects_changed': False}, actions


def physical_primary(action_record, T):
    from jcat_background_packets_v2 import extract
    engine, _ = triplet_data()
    I = sp.Matrix(3, 3, list(engine.basis((2, 2))[1][0][1])); unit = sp.eye(3)
    tensor = lambda n, f: sp.Matrix([f(*digits) for digits in product(range(3), repeat=n)])
    l = extract(engine, 3, tensor(3, lambda a, x, y: ((T[a]*unit[:, x]).T*I*unit[:, y])[0]))
    rr = extract(engine, 3, tensor(3, lambda a, x, y: (unit[:, x].T*I*T[a]*unit[:, y])[0]))
    pairs = [extract(engine, 4, tensor(4, f)) for f in (
        lambda a, b, x, y: ((T[a]*T[b]*unit[:, x]).T*I*unit[:, y])[0],
        lambda a, b, x, y: ((T[a]*unit[:, x]).T*I*T[b]*unit[:, y])[0],
        lambda a, b, x, y: (unit[:, x].T*I*T[a]*T[b]*unit[:, y])[0])]
    P = sp.zeros(9, 3); P[0, 0] = P[1, 1] = P[2, 2] = 1
    P[3, 0], P[4, 0] = l[0], 2*l[0]
    P[4, 1], P[5, 1] = rr[0], l[0]
    P[3, 2], P[5, 2] = rr[0], 2*rr[0]
    for j, values in enumerate(pairs):
        for i, value in enumerate(values): P[6+i, j] = value
    source = primary_transport()
    return dict(source, status='PASS_MANIFEST_COVARIANT_PRIMARY_FROZEN_PHYSICAL_CONVENTION',
        expansion_matrix=serial(P), physical_action_sha256=canonical(action_record),
        coefficient_derivation='Independent covariant grammar plus qualified C/J tensor extraction; no replay kernel imported',
        historical_diagnostic_coefficients_preserved=True,
        interpretation='Full four-dimensional triplet completion in the frozen physical background registry convention')


def faithful_replay(replay):
    rho, V = matrix(replay['realization_matrix']), matrix(replay['variation_matrix'])
    q, section, N, pivots = quotient(rho)
    assert V*N == sp.zeros(V.rows, N.cols)
    induced = V*section
    assert induced*q == V
    K = matrix(replay['kernel'])
    kernel = sp.Matrix.hstack(*induced.nullspace())
    assert (q*K).rank() == kernel.rank() == (q*K.row_join(section*kernel)).rank()
    return {'status': 'PASS_EXACT_FAITHFUL_REPLAY_DOMAIN',
        'quotient_map': serial(q), 'canonical_section': serial(section),
        'quotient_pivot_addresses': list(pivots), 'realization_nullspace': serial(N),
        'realization_on_section': serial(rho*section), 'induced_variation': serial(induced),
        'faithful_kernel': serial(kernel), 'raw_kernel_quotient_image': serial(q*K),
        'EXPANSION_ADDRESS_COUNT': rho.cols, 'ORDERED_COORDINATE_DIMENSION': rho.cols,
        'REALIZATION_NULLITY': N.cols, 'REALIZED_OPERATOR_DIMENSION': q.rows,
        'BACKGROUND_COVARIANT_PACKET_DIMENSION': kernel.cols,
        'raw_kernel_dimension': K.cols, 'variation_realization_nullity': 0,
        'variation_codomain': 'Independent distinct commutative polynomial monomials',
        'q_kernel_equals_induced_kernel': 'ZERO_EXACT',
        'rho_delta_delta_N': 'ZERO_EXACT', 'addresses_deleted': False}


def bounded_descent(primary, faithful):
    engine, _ = triplet_data()
    q, section, N = (matrix(faithful[k]) for k in ('quotient_map', 'canonical_section', 'realization_nullspace'))
    bg = sp.eye(9); bg[6:9, 6:9] = engine.swap((2,)*4, 0)
    phi = sp.zeros(9)
    phi[2, 0] = phi[0, 2] = phi[1, 1] = 1
    phi[3, 3] = -1; phi[5, 4] = phi[4, 5] = -1
    phi[6:9, 6:9] = permutation_matrix(engine, (2,)*4, (0, 1, 3, 2))
    catalog = BlockConjugation.from_frozen()
    C = sp.zeros(9)
    rows = primary['expansion_addresses']
    index = {(address_key(r['internal_channel_address']), tuple(r['derivative_placement'])): i for i, r in enumerate(rows)}
    for i, row in enumerate(rows):
        for addr, coeff in catalog.image(row['internal_channel_address']):
            C[index[(address_key(addr), tuple(row['derivative_placement']))], i] += coeff
    assert C*sp.conjugate(C) == sp.eye(9)
    assert q*C*sp.conjugate(N) == sp.zeros(q.rows, N.cols)
    assert bg*phi == phi*bg
    operators = []
    for name, S in (('background_slots_joint_swap', bg), ('tagged_Phi_occurrence_joint_swap', phi)):
        assert S*S == sp.eye(9) and q*S*N == sp.zeros(q.rows, N.cols)
        induced = q*S*section
        assert q*S == induced*q and induced*induced == sp.eye(q.rows)
        operators.append({'map': name, 'ordered_matrix': serial(S), 'faithful_matrix': serial(induced),
            'descent_residual': 'ZERO_EXACT', 'final_statistics_projector': False})
    cq = q*C*sp.conjugate(section)
    assert q*C == cq*sp.conjugate(q) and cq*sp.conjugate(cq) == sp.eye(q.rows)
    return {'status': 'PASS_EXACT_STRUCTURE_DESCENT', 'joint_slot_actions': operators,
        'conjugation_ordered': serial(C), 'conjugation_faithful': serial(cq),
        'conjugation_descent': 'ZERO_EXACT', 'anti_linear_involution': 'ZERO_EXACT',
        'background_variation_descent': faithful['rho_delta_delta_N'],
        'background_only_internal_swap_applicable_here': 'Its Lorentz contraction is symmetric; the general catalog uses joint actions'}


def compare(primary, replay, faithful, descent):
    P, rho, V, K = (matrix(r[k]) for r, k in ((primary, 'expansion_matrix'),
        (replay, 'realization_matrix'), (replay, 'variation_matrix'), (replay, 'kernel')))
    q, N, kernel = (matrix(faithful[k]) for k in ('quotient_map', 'realization_nullspace', 'faithful_kernel'))
    assert V*P == sp.zeros(V.rows, P.cols)
    assert P.row_join(N).rank() == K.rank() == P.row_join(N).row_join(K).rank() == 4
    assert (q*P).rank() == kernel.rank() == (q*P).row_join(kernel).rank() == 3
    assert (rho*P).rank() == (rho*K).rank() == (rho*P).row_join(rho*K).rank() == 3
    assert N.cols == 1 and N[7, 0] != 0 and q[:, 7] == sp.zeros(8, 1)
    return {'status': 'PASS_EXACT_FAITHFUL_PACKET_COMPARISON',
        'primary_frozen_before_comparison': True, 'replay_frozen_before_comparison': True,
        'quotient_frozen_before_comparison': True, 'primary_coefficients_adjusted': False,
        'ordered_dimension': 9, 'realization_rank': 8, 'realization_nullity': 1,
        'raw_kernel_dimension': 4, 'faithful_kernel_dimension': 3,
        'K_raw_equals_primary_plus_N': 'ZERO_EXACT', 'q_primary_equals_q_raw_kernel': 'ZERO_EXACT',
        'realized_primary_equals_realized_kernel': 'ZERO_EXACT',
        'zero_direction': {'address': primary['expansion_addresses'][7]['internal_channel_address'],
            'ordered_vector': serial(N[:, 0]), 'status': 'REALIZATION_NULL_NONZERO_EXPANSION_NEGATIVE_CONTROL',
            'nonzero_ordered_tensor': True, 'four_dimensional_realization': 'ZERO_EXACT',
            'raw_kernel_member': True, 'faithful_class': 'ZERO',
            'counting_as_fourth_packet': 'FAIL_EXPECTED_OVERCOUNT'},
        'structure_descent': descent['status'], 'IBP_applied': False,
        'statistics_applied': False, 'full_431_packet_completeness_implied': False}


def tup(x): return tuple(tup(a) for a in x) if isinstance(x, list) else x


class ReusableRealization:
    def __init__(self):
        self.internal = InternalPermutation()
        self.catalog = self.internal.catalog

    @lru_cache(None)
    def addresses(self, fid):
        desc = self.catalog.descriptors[fid]
        return tuple(a for key, _, _, _ in self.catalog.blocks(desc) for a in self.catalog.addresses(fid, key))

    @lru_cache(None)
    def action(self, fid, jets, perm):
        addresses = self.addresses(fid); nj = len(jets)
        ai = {address_key(a): i for i, a in enumerate(addresses)}
        ji = {key: j for j, key in enumerate(jets)}
        entries = {}
        for i, addr in enumerate(addresses):
            targets = list(self.internal.image(addr, perm))
            for j, (degree, key) in enumerate(jets):
                image, phase = rename(key, perm)
                if not phase: continue
                k = ji[(degree, image)]
                for target, coeff in targets:
                    entries[ai[address_key(target)]*nj+k, i*nj+j] = phase*coeff
        return sp.ImmutableSparseMatrix(len(addresses)*nj, len(addresses)*nj, entries)

    def conjugation(self, fid, jets):
        addresses = self.addresses(fid); nj = len(jets)
        index = {address_key(a): i for i, a in enumerate(addresses)}
        entries = {}
        for i, a in enumerate(addresses):
            for target, coeff in self.catalog.image(a):
                for j in range(nj): entries[index[address_key(target)]*nj+j, i*nj+j] = coeff
        return sp.ImmutableSparseMatrix(len(addresses)*nj, len(addresses)*nj, entries)

    def class_record(self, fid, jets, bg, names):
        n = len(names); total = len(self.addresses(fid))*len(jets)
        actions = []
        for a, b in zip(bg, bg[1:]):
            perm = list(range(n)); perm[a], perm[b] = perm[b], perm[a]
            actions.append(self.action(fid, jets, tuple(perm)))
        # Components are finite coordinate-mixing orbits, not a dense global inverse.
        parent = list(range(total))
        def find(i):
            while parent[i] != i: i = parent[i]
            return i
        for S in actions:
            for (i, j), value in S.todok().items():
                if value: parent[find(i)] = find(j)
        groups = defaultdict(list)
        for i in range(total): groups[find(i)].append(i)
        records = []; q_entries = {}; s_entries = {}; n_entries = {}
        offset = null_offset = 0
        for indices in sorted(groups.values(), key=lambda g: g[0]):
            local = [sp.Matrix(S.extract(indices, indices)) for S in actions]
            size = len(indices)
            for S in local: assert S*S == sp.eye(size)
            for i in range(len(local)-1):
                assert local[i]*local[i+1]*local[i] == local[i+1]*local[i]*local[i+1]
            for i in range(len(local)):
                for j in range(i+2, len(local)): assert local[i]*local[j] == local[j]*local[i]
            # Ordinary polynomial substitution identifies only background slots.
            # Its kernel equals the relations v-P v for this background factor.
            all_images = [sp.eye(size)]
            for p in permutations(range(len(bg))):
                perm = list(range(n))
                for new, old in zip(bg, p): perm[new] = bg[old]
                M = self.action(fid, jets, tuple(perm)).extract(indices, indices)
                if p != tuple(range(len(bg))): all_images.append(M)
            rho = sum(all_images, sp.zeros(size))/len(all_images)
            assert rho*rho == rho
            q, section, N, pivots = quotient(rho)
            rel = sp.Matrix.hstack(*(sp.eye(size)-S for S in local))
            assert rel.rank() == N.cols and rho*rel == sp.zeros(size, rel.cols)
            for (i, j), value in q.todok().items(): q_entries[offset+i, indices[j]] = value
            for (i, j), value in section.todok().items(): s_entries[indices[i], offset+j] = value
            for (i, j), value in sp.SparseMatrix(N).todok().items(): n_entries[indices[i], null_offset+j] = value
            records.append({'ordered_coordinate_indices': indices, 'background_slot_actions': [serial(S) for S in local],
                'realization_factor': serial(rho), 'quotient_map': serial(q), 'section': serial(section),
                'null_basis': serial(N), 'rank': q.rows, 'nullity': N.cols,
                'realization_certificate': 'Commutative background-jet polynomial substitution; homogeneous slots retain independent tags',
                'complete_null_generators': 'Span of I-P for adjacent background-only JOINT slot operations',
                'background_variation_descent': 'Exact chain rule: derivation commutes with polynomial substitution',
                'no_IBP_EOM_or_homogeneous_statistics': True})
            offset += q.rows; null_offset += N.cols
        Q = sp.SparseMatrix(offset, total, q_entries)
        section = sp.SparseMatrix(total, offset, s_entries)
        N = sp.SparseMatrix(total, null_offset, n_entries)
        assert Q*section == sp.eye(offset) and Q*N == sp.zeros(offset, null_offset)
        C = self.conjugation(fid, jets)
        assert (Q*C*sp.conjugate(N)).applyfunc(sp.simplify) == sp.zeros(offset, null_offset)
        # Disjoint homogeneous-species factors normalize the background factor.
        hom_actions = []
        for name in dict.fromkeys(names):
            slots = [i for i, x in enumerate(names) if x == name]
            for a, b in zip(slots, slots[1:]):
                perm = list(range(n)); perm[a], perm[b] = perm[b], perm[a]
                S = self.action(fid, jets, tuple(perm))
                assert Q*S*N == sp.zeros(offset, null_offset)
                hom_actions.append({'permutation': perm, 'null_descent': 'ZERO_EXACT'})
        return {'family_id': fid, 'raw_jet_addresses': jets, 'background_slots': bg,
            'ORDERED_COORDINATE_DIMENSION': total, 'REALIZATION_NULLITY': null_offset,
            'REALIZED_OPERATOR_DIMENSION': offset, 'blocks': records,
            'conjugation_null_descent': 'ZERO_EXACT', 'joint_permutation_descent': hom_actions,
            'source_address_order': 'INT6 address enumeration then raw Lorentz/derivative address',
            'largest_local_block': max((len(r['ordered_coordinate_indices']) for r in records), default=0),
            'BACKGROUND_COVARIANT_PACKET_DIMENSION': None}

    def generate(self):
        ledger = load(OLD/'JCAT7V2_expansion_address_ledger.json')
        reusable = {}; rows = []
        for ordinal, row in enumerate(ledger['rows']):
            names = tuple(r['field'] for r in row['ordered_occurrences'])
            bg = tuple(i for i, name in enumerate(names) if name == 'Abar_H_mu')
            jets = tup(row['raw_Lorentz_derivative_addresses'])
            fid = row['internal_family']; total = row['EXPANSION_ADDRESS_COUNT']
            key = canonical({'family': fid, 'jets': jets, 'background_slots': bg,
                'species_equality_pattern': [names.index(name) for name in names]})[:20]
            if len(bg) < 2:
                rank, nullity = total, 0
                certificate = 'Tagged homogeneous tensor slots and unique background occurrence: certified internal injection times canonical Lorentz/ordinary-jet injection'
            else:
                if key not in reusable:
                    reusable[key] = self.class_record(fid, jets, bg, names)
                    print('JCAT7V3_REALIZATION_CLASS', key, total,
                        reusable[key]['REALIZATION_NULLITY'], flush=True)
                rank = reusable[key]['REALIZED_OPERATOR_DIMENSION']
                nullity = reusable[key]['REALIZATION_NULLITY']
                certificate = 'Exact finite realization blocks '+key
            assert rank+nullity == total
            rows.append({'signature_id': row['signature_id'], 'class_id': key,
                'EXPANSION_ADDRESS_COUNT': total, 'ORDERED_COORDINATE_DIMENSION': total,
                'REALIZATION_NULLITY': nullity, 'REALIZED_OPERATOR_DIMENSION': rank,
                'BACKGROUND_COVARIANT_PACKET_DIMENSION': None, 'certificate': certificate,
                'addresses_deleted': False, 'homogeneous_occurrences_tagged': True})
        return {'status': 'PASS_COMPLETE_REUSABLE_POLARIZED_REALIZATION_NULL_ACCOUNTING',
            'signature_count': len(rows), 'rows': rows, 'reusable_background_classes': reusable,
            'EXPANSION_ADDRESS_COUNT': sum(r['EXPANSION_ADDRESS_COUNT'] for r in rows),
            'ORDERED_COORDINATE_DIMENSION': sum(r['ORDERED_COORDINATE_DIMENSION'] for r in rows),
            'REALIZATION_NULLITY': sum(r['REALIZATION_NULLITY'] for r in rows),
            'REALIZED_OPERATOR_DIMENSION': sum(r['REALIZED_OPERATOR_DIMENSION'] for r in rows),
            'BACKGROUND_COVARIANT_PACKET_DIMENSION': None,
            'physical_polynomial_certificate': 'The separately tagged tensor evaluation is injective. Identifying background slots factors precisely through their finite joint relabeling relations. Ordinary commuting derivative and four-dimensional Lorentz identities are already canonicalized. No homogeneous fields are identified.',
            'variation_descent_certificate': 'rho_delta delta_bg = delta_bg_physical rho, by the exact ordinary-jet Leibniz rule; hence every certified null generator and its span has zero realized variation',
            'no_dense_global_matrix': True, 'IBP_applied': False, 'statistics_applied': False}


def full_covector(catalog, address):
    from int9_scalar_swap import dimension
    desc, _, slots, _, b, r, a, bb = catalog.address_parts(address)
    dims = tuple(dimension(catalog.by_id[c]) for c in slots)
    n = desc['arity']
    if n < 2: return dims, sp.ones(1, 1)
    _, d = catalog.duals.channel_objects(tuple(b['left_H_label']), tuple(b['right_H_label']), tuple(b['output_H_label']), a)
    if n == 2: value = d
    else:
        value = d.T*catalog.duals.pairing(tuple(b['output_H_label'])).T
        if n == 4:
            _, rd = catalog.duals.channel_objects(tuple(r['left_H_label']), tuple(r['right_H_label']), tuple(r['output_H_label']), bb)
            value = value*rd
    return dims, sp.SparseMatrix(sp.prod(dims), 1,
        {(i*value.cols+j, 0): v for (i, j), v in sp.SparseMatrix(value).todok().items()})


def polynomial_realization_columns(catalog, addresses, jets, selected, bg):
    """Direct tensor-component -> ordinary monomial coefficients, no P matrices."""
    from jcat_internal_permutations import coordinates
    from jcat_lorentz_v2 import ETA, epsilon
    columns = []
    for ordinal in selected:
        a, j = divmod(ordinal, len(jets)); address = addresses[a]
        dims, tensor = full_covector(catalog, address)
        slots, copies = catalog.address_parts(address)[2:4]
        _, (parity, contraction) = jets[j]
        assignments = []
        if parity == 'PARITY_EVEN':
            for values in product(range(4), repeat=len(contraction)):
                tokens = [(token, mu) for pair, mu in zip(contraction, values) for token in pair]
                assignments.append((tokens, sp.prod(ETA[mu] for mu in values)))
        else:
            for values in permutations(range(4)):
                assignments.append((list(zip(contraction, values)), epsilon(values)))
        polynomial = defaultdict(lambda: 0)
        for (index, _), value in tensor.todok().items():
            internal = coordinates(index, dims)
            for tokens, coeff in assignments:
                vector = {}; derivatives = defaultdict(list)
                for (kind, slot), mu in tokens:
                    if kind == 'v': vector[slot] = mu
                    else: derivatives[slot].append(mu)
                monomial = tuple(sorted(('Abar' if i in bg else 'HOMO_TAG_'+str(i),
                    slots[i], copies[i], internal[i], vector.get(i, -1), tuple(sorted(derivatives[i])))
                    for i in range(len(slots))))
                polynomial[monomial] += value*coeff
        columns.append({m: sp.expand(v) for m, v in polynomial.items() if sp.expand(v) != 0})
    monomials = sorted(set().union(*(set(p) for p in columns)))
    index = {m: i for i, m in enumerate(monomials)}
    rho = sp.SparseMatrix(len(monomials), len(columns),
        {(index[m], j): value for j, p in enumerate(columns) for m, value in p.items()})
    return monomials, rho


def component_replay(catalog_record):
    from int9_scalar_swap import dimension
    engine = ReusableRealization()
    choices = []
    # Consequential maximum block; ties broken deterministically by local dimension,
    # tensor size and canonical class ID, not by comparison with primary matrices.
    for cid, record in sorted(catalog_record['reusable_background_classes'].items()):
        addresses = engine.addresses(record['family_id'])
        for bi, block in enumerate(record['blocks']):
            if block['nullity']:
                size = len(block['ordered_coordinate_indices'])
                tensor_size = max(sp.prod(dimension(engine.catalog.by_id[c]) for c in
                    engine.catalog.address_parts(addresses[i//len(record['raw_jet_addresses'])])[2])
                    for i in block['ordered_coordinate_indices'])
                choices.append((size, int(tensor_size), cid, bi))
    largest = max(choices)
    singleton = next((c, bi) for _, _, c, bi in sorted(choices)
        if len(catalog_record['reusable_background_classes'][c]['blocks'][bi]['ordered_coordinate_indices']) == 1)
    selected = [(largest[2], largest[3]), singleton]
    output = []
    for cid, bi in selected:
        record = catalog_record['reusable_background_classes'][cid]; block = record['blocks'][bi]
        jets = tup(record['raw_jet_addresses']); coordinates_ = block['ordered_coordinate_indices']
        monomials, rho = polynomial_realization_columns(engine.catalog,
            engine.addresses(record['family_id']), jets, coordinates_, tuple(record['background_slots']))
        # The source block only selects the fixed coverage domain. Its quotient,
        # null coefficients, action matrices and ranks are NOT used in this solve.
        q, section, null, pivots = quotient(rho)
        output.append({'class_id': cid, 'block_index': bi, 'ordered_coordinate_indices': coordinates_,
            'physical_realization_matrix': serial(rho), 'physical_monomials': monomials,
            'independently_solved_null_basis': serial(null), 'independently_solved_quotient': serial(q),
            'rank': q.rows, 'nullity': null.cols, 'primary_null_coefficients_imported': False,
            'primary_realization_factor_imported': False})
    return {'status': 'PASS_INDEPENDENT_DIRECT_COMPONENT_REALIZATION_SOLVES', 'blocks': output,
        'independence': {'ALGORITHM_INDEPENDENT': True, 'CODE_PATH_INDEPENDENT': True,
            'LIBRARY_INDEPENDENT': False, 'RUNTIME_INDEPENDENT': False,
            'shared_inputs': 'Frozen carriers, embeddings, duals and Lorentz tensor convention; primary descriptor selects coverage only'}}


def component_replay_acceptance(catalog_record, replay):
    for row in replay['blocks']:
        block = catalog_record['reusable_background_classes'][row['class_id']]['blocks'][row['block_index']]
        N, N2 = matrix(block['null_basis']), matrix(row['independently_solved_null_basis'])
        rho = matrix(row['physical_realization_matrix'])
        assert rho*N == sp.zeros(rho.rows, N.cols)
        assert N.row_join(N2).rank() == N.cols == N2.cols == row['nullity']
        assert row['rank'] == block['rank']
    return {'status': 'PASS_EXACT_COMPONENT_REALIZATION_REPLAY',
        'block_count': len(replay['blocks']), 'zero_realization_residual': 'ZERO_EXACT',
        'null_mutual_span': 'ZERO_EXACT', 'primary_frozen_before_comparison': True,
        'replay_frozen_before_comparison': True, 'global_packet_completeness_implied': False}


def singleton_packets():
    ledger = load(OLD/'JCAT7V2_expansion_address_ledger.json')
    rows = [{'signature_id': row['signature_id'], 'internal_family': row['internal_family'],
        'raw_jet_indices': row['singleton_covariant_jet_indices'],
        'tagged_packet_dimension': row['singleton_packet_count'],
        'primary_expansion_map': 'IDENTITY_ON_SPECIFIED_INT6_X_RAW_JET_ADDRESSES',
        'background_variation': 'ZERO_EXACT_BY_FUSION_COVARIANCE_AND_TERMINAL_PAIRING',
        'replay_kernel': 'FULL_SPECIFIED_ZERO_DERIVATIVE_NO_BACKGROUND_SUBSPACE',
        'addresses_retained': True}
        for row in ledger['rows'] if row['singleton_covariant_jet_indices']]
    return {'status': 'PASS_ZERO_DERIVATIVE_NO_BACKGROUND_SINGLETON_RECOVERY', 'rows': rows,
        'tagged_packet_dimension': sum(row['tagged_packet_dimension'] for row in rows),
        'certificate': 'With no affine connection and no ordinary derivatives, local background variation is the sum of homogeneous carrier actions at one point. Every fusion covector intertwines these actions and its invariant terminal pairing annihilates their sum. Thus the entire specified realized tagged subspace is the exact kernel; no primary coefficient solve is imported.',
        'final_identical_field_statistics_applied': False,
        'global_background_packet_dimension': None}


def address_realization_image(signature_id, address, jet_index, catalog_record):
    """Read-only, deterministic original-address -> faithful-class API."""
    row = next(r for r in catalog_record['rows'] if r['signature_id'] == signature_id)
    catalog = BlockConjugation.from_frozen()
    desc, target, _, _, _, _, _, _ = catalog.address_parts(address)
    assert desc['family_id'] == next(r['internal_family'] for r in
        load(OLD/'JCAT7V2_expansion_address_ledger.json')['rows'] if r['signature_id'] == signature_id)
    prefix = 0; ordinal = None
    for key, card, _, _ in catalog.blocks(desc):
        if key == target:
            local = [address_key(a) for a in catalog.addresses(desc['family_id'], key)]
            ordinal = prefix+local.index(address_key(address)); break
        prefix += card
    assert ordinal is not None
    source = next(r for r in load(OLD/'JCAT7V2_expansion_address_ledger.json')['rows'] if r['signature_id'] == signature_id)
    jet_count = len(source['raw_Lorentz_derivative_addresses'])
    assert 0 <= jet_index < jet_count
    index = ordinal*jet_count+jet_index
    cls = catalog_record['reusable_background_classes'].get(row['class_id'])
    if cls is None:
        return {'class_id': row['class_id'], 'ordered_coordinate_index': index,
            'faithful_coordinates': [[index, '1']], 'address_deleted': False}
    offset = 0
    for block in cls['blocks']:
        if index in block['ordered_coordinate_indices']:
            column = block['ordered_coordinate_indices'].index(index)
            q = matrix(block['quotient_map'])
            return {'class_id': row['class_id'], 'ordered_coordinate_index': index,
                'faithful_coordinates': [[offset+i, str(q[i, column])] for i in range(q.rows) if q[i, column]],
                'address_deleted': False}
        offset += block['rank']
    raise AssertionError('ORIGINAL_ADDRESS_NOT_COVERED_BY_REALIZATION_QUOTIENT')


def universal_variation_descent():
    tests = []
    for n in (2, 3, 4):
        z = sp.symbols(f'z0:{n}'); dz = sp.symbols(f'dz0:{n}')
        f = sp.prod(z)
        df = sum(dz[i]*sp.prod(z[j] for j in range(n) if j != i) for i in range(n))
        for p in permutations(range(n)):
            fp = sp.prod(z[i] for i in p)
            dfp = sum(dz[p[i]]*sp.prod(z[p[j]] for j in range(n) if j != i) for i in range(n))
            assert sp.expand(fp-f) == 0 and sp.expand(dfp-df) == 0
        tests.append({'background_factor_count': n, 'permutation_count': len(list(permutations(range(n)))),
            'realization_identity': 'ZERO_EXACT', 'arbitrary_derivation_image': 'ZERO_EXACT'})
    return {'status': 'PASS_UNIVERSAL_POLYNOMIAL_SUBSTITUTION_DERIVATION_COMPATIBILITY',
        'tests': tests, 'variation_jet_rule': 'delta(partial_multi A)=partial_multi([theta,A]-partial theta/g10), expanded by exact Leibniz rule',
        'scope': 'z_i may be any background color/Lorentz/ordinary-derivative component; dz_i is arbitrary, including affine and prolonged terms. Homogeneous tagged factors are spectators in these null generators.',
        'completeness_bridge': 'Each reusable null basis is exactly the span of adjacent joint background relabeling differences I-P. The universal commutative identity and its derivation therefore certify rho_delta(delta N)=0 for every null vector.',
        'IBP_EOM_BRST_or_final_statistics_used': False}
