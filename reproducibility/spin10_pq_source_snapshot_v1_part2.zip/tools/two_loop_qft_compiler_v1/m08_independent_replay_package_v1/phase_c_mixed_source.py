"""First inactive Phase C mixed source prerequisite; stdout only."""
import itertools
import json
import sympy as s
from source_convention_control import Exterior
from nonabelian_m08_semantic import canonical
from nonminimal_bv_m08_architecture import load

IDS=[0,1,3,4,11,12,13,19,38,44]
H=[i for i in IDS if i<12]; M=[i for i in IDS if i>=12]
g=s.Symbol('g10')


def geometry():
    raw=load('frozen_rh_composite_adjudication/RH_primary_closed.json')
    f={(i,a,b):s.sympify(v)/s.sqrt(2) for i,a,b,v in raw['upper_index_structure_constants_raw']}
    f.update({(i,b,a):-v for (i,a,b),v in list(f.items())})
    basis=load('frozen_c3/C3_representation_basis.json'); B=s.zeros(45)
    for j,row in enumerate(basis['h_basis']+basis['heavy_basis']):
        for v in row['raw_so10_coordinates']: B[v['index'],j]=s.sympify(v['coefficient'])
    G=B.T*B; C=(B.inv()*B.conjugate()).applyfunc(s.simplify)
    selected={0,4,13}; history=[]
    while True:
        larger=selected|{i for i,a,b in f if a in selected and b in selected}
        larger|={i for j in selected for i in range(45) if G[i,j] or C[i,j]}
        history.append(sorted(larger))
        if larger==selected: break
        selected=larger
    assert sorted(selected)==IDS and G.extract(IDS,IDS).det()!=0
    assert f[12,13,44]==-4*s.sqrt(2)*s.I/5
    return f,history


def build(stage=lambda n,fn:fn()):
    f,history=stage('actual_mixed_geometry',geometry)
    a=Exterior(); fields={**{'C'+str(i):(1,1,1) for i in IDS},
        **{prefix+str(i):grade for prefix,indices,grade in [('ubar',M,(1,-1,1)),('Lambda',M,(2,0,0)),('bar',H,(1,-1,1)),('b',H,(2,0,0))] for i in indices}}
    pairs=[(z,'J'+z) for z in fields]
    grades={**fields,**{J:(3-fields[z][0],-1-fields[z][1],1-fields[z][2]) for z,J in pairs}}
    x={n:a.variable(n,p) for n,(d,gh,p) in grades.items()}; omega={i:a.variable('omega'+str(i),0) for i in H}
    C={i:x['C'+str(i)] for i in IDS}
    R={h:a.add(*(a.scale(a.mul(C[i],C[j]),-f.get((h,i,j),0)) for i,j in itertools.combinations(M,2))) for h in H}
    forward={'C'+str(i):a.add(*(a.scale(a.mul(C[j],C[k]),-g*f.get((i,j,k),0)) for j,k in itertools.combinations(IDS,2))) for i in IDS}
    for i in M:
        forward['ubar'+str(i)]=a.add(a.scale(x['Lambda'+str(i)],-1),*(a.scale(a.mul(C[h],x['ubar'+str(j)]),g*f.get((j,h,i),0)) for h in H for j in M))
        forward['Lambda'+str(i)]=a.add(*(a.scale(a.mul(C[h],x['Lambda'+str(j)]),g*f.get((j,h,i),0)) for h in H for j in M),*(a.scale(a.mul(R[h],x['ubar'+str(j)]),g*g*f.get((j,h,i),0)) for h in H for j in M))
    for h in H: forward['bar'+str(h)]=a.scale(x['b'+str(h)],-1); forward['b'+str(h)]={}
    S=a.add(*(a.mul(x[J],forward[z]) for z,J in pairs))
    Q={n:a.bracket(S,p,pairs) for n,p in x.items()}
    record=lambda P:canonical(P,a)
    counts={'forward':0,'Q_squares':0,'R_chain':0,'Cartan':0,'iota_squares':0,'TQ':0}
    def zero(P,label):
        if P: raise Failure(label,record(P))
    for z in fields: zero(a.add(Q[z],a.scale(forward[z],-1)),'forward_'+z); counts['forward']+=1
    for h in H:
        target=a.add(*(a.scale(a.mul(C[k],R[j]),-g*f.get((h,k,j),0)) for k,j in itertools.product(H,repeat=2)))
        zero(a.add(a.derive(R[h],Q),a.scale(target,-1)),'derived_R_'+str(h)); counts['R_chain']+=1
    stage('complete_mixed_source_squares',lambda:[(zero(a.derive(Q[n],Q),'Q_square_'+n),counts.__setitem__('Q_squares',counts['Q_squares']+1)) for n in grades])
    zero(a.bracket(S,S,pairs),'source_master')
    Igen=a.add(*(a.mul(x['JC'+str(h)],omega[h]) for h in H),*(a.scale(a.mul(x['Jb'+str(i)],omega[h],x['bar'+str(j)]),g*f.get((i,h,j),0)) for i,h,j in itertools.product(H,repeat=3)))
    I={n:a.bracket(Igen,p,pairs) for n,p in x.items()}
    T={}
    for prefix,indices,dual in [('C',IDS,False),('ubar',M,True),('Lambda',M,True),('bar',H,False),('b',H,False)]:
        for i in indices:
            T[prefix+str(i)]=a.add(*(a.scale(a.mul(omega[h],x[prefix+str(j)]),g*f.get((j,h,i),0) if dual else -g*f.get((i,h,j),0)) for h in H for j in indices))
            T['J'+prefix+str(i)]=a.add(*(a.scale(a.mul(omega[h],x['J'+prefix+str(j)]),-g*f.get((i,h,j),0) if dual else g*f.get((j,h,i),0)) for h in H for j in indices))
    for n in grades:
        zero(a.add(a.derive(Q[n],I),a.derive(I[n],Q),a.scale(T[n],-1)),'Cartan_'+n); counts['Cartan']+=1
        zero(a.derive(I[n],I),'iota_square_'+n); counts['iota_squares']+=1
        zero(a.add(a.derive(Q[n],T,0),a.scale(a.derive(T[n],Q),-1)),'TQ_'+n); counts['TQ']+=1
    F=a.add(*(a.mul(x['JC'+str(h)],R[h]) for h in H)); image=a.derive(F,Q)
    assert F and image
    for name,P in [('F',F),('QF',image)]:
        zero(a.derive(P,I),'horizontal_'+name); zero(a.derive(P,T,0),'invariant_'+name)
    return {'schema':'PHASE_C_MIXED_SOURCE_PREREQUISITE_V1','status':'PASS_MIXED_SOURCE_FIBER_ONLY','ids':IDS,'closure':history,'canonical_pairs':len(pairs),'generators':len(grades),'counts':counts,
        'source_master':record(S),'images':{n:record(P) for n,P in Q.items()},'contraction':{n:record(P) for n,P in I.items()},'R':{str(h):record(P) for h,P in R.items()},'domain':{'F':record(F),'QF':record(image)},
        'derivatives_or_physical_action_tested':False,'full_M08_qualified':False,'active_sources_added':False,'formal_authority':'34/39_UNCHANGED'}


class Failure(Exception):
    def __init__(self,label,rows): self.evidence={'identity':label,'residual':rows,'first_component':rows[0]}


if __name__=='__main__':
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    try: result=build(lambda n,fn:(print('STAGE '+n,flush=True),fn())[1])
    except Failure as e: result={'schema':'PHASE_C_MIXED_SOURCE_PREREQUISITE_V1','status':'FAILED_FIRST_PREREQUISITE','witness':e.evidence,'full_M08_qualified':False,'active_sources_added':False,'formal_authority':'34/39_UNCHANGED'}
    print('RESULT '+json.dumps(result,sort_keys=True,separators=(',',':')),flush=True)
