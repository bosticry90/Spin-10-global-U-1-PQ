"""Bounded S2 regression, with exact block maps and physical-coordinate replay.

No general permutation catalog, loop input, canonical basis rotation or AST fit.
"""
from itertools import product
import sympy as sp
import execute_scalar_ast_channel_bridge as br
from int8_block_conjugation_v2 import BlockConjugation, address_key


def clean(m):
    return sp.SparseMatrix(m).applyfunc(sp.simplify)


def payload(m):
    p = br.serialize(m)
    return {'shape': [int(v) for v in p['shape']],
            'entries': [[int(i), int(j), v] for i, j, v in p['entries']]}


def dimension(row):
    p, q, n, _ = row['H_label']
    return (p+1)*(q+1)*(p+q+2)*(n+1)//2


def pivot_solve(bases, targets):
    """Sparse deterministic independent-entry solve plus every-entry residual."""
    bd = [sp.SparseMatrix(b).todok() for b in bases]
    td = [sp.SparseMatrix(t).todok() for t in targets]
    support = sorted(set().union(*(set(b) for b in bd)))
    echelon, selected = {}, []
    for pos in support:
        row = {j: d[pos] for j, d in enumerate(bd) if pos in d}
        for col, pivot in sorted(echelon.items()):
            if col not in row:
                continue
            scale = row[col]
            for j, value in pivot.items():
                z = sp.simplify(row.get(j, 0)-scale*value)
                if z == 0:
                    row.pop(j, None)
                else:
                    row[j] = z
        if row:
            col = min(row); scale = row[col]
            echelon[col] = {j: sp.simplify(v/scale) for j, v in row.items()}
            selected.append(pos)
        if len(selected) == len(bases):
            break
    assert len(selected) == len(bases), ('basis not full rank', len(selected), len(bases))
    m = sp.SparseMatrix(len(bases), len(bases),
                        {(i, j): d[pos] for i, pos in enumerate(selected)
                         for j, d in enumerate(bd) if pos in d})
    rhs = sp.SparseMatrix(len(bases), len(targets),
                          {(i, j): d[pos] for i, pos in enumerate(selected)
                           for j, d in enumerate(td) if pos in d})
    solution = clean(m.inv()*rhs)
    for j, target in enumerate(td):
        residual = dict(target)
        for i in range(len(bases)):
            coeff = solution[i, j]
            if coeff:
                for pos, value in bd[i].items():
                    residual[pos] = residual.get(pos, 0)-coeff*value
        nonzero = [(pos, sp.simplify(v)) for pos, v in sorted(residual.items())
                   if sp.simplify(v) != 0]
        if nonzero:
            raise RuntimeError('FULL_TENSOR_SPAN_RESIDUAL '+str((j, nonzero[:8])))
    return solution, selected, m, rhs


def primary(catalog):
    fid = 'INV_S_S'; desc = catalog.descriptors[fid]
    addresses = [a for key, _, _, _ in catalog.blocks(desc)
                 for a in catalog.addresses(fid, key)]
    assert len(addresses) == 89
    indices = {address_key(a): i for i, a in enumerate(addresses)}
    terminal = {tuple(catalog.block_slots(desc, key)): key[0]
                for key, _, _, _ in catalog.blocks(desc)}
    swap = sp.MutableSparseMatrix(89, 89, {})
    blocks = []
    for ti, t in enumerate(desc['terminal_channels']):
        b = catalog.binary[('S', 'S')][t['binary_block_index']]
        left, right, out = (tuple(b[k]) for k in
                            ('left_H_label', 'right_H_label', 'output_H_label'))
        revti = terminal[(b['right_component_id'], b['left_component_id'])]
        reverse = catalog.binary[('S', 'S')][desc['terminal_channels'][revti]['binary_block_index']]
        ds = [catalog.duals.channel_objects(left, right, out, a)[1]
              for a in range(b['SU3_channel_range'][1])]
        csrev = [catalog.duals.channel_objects(right, left, out, a)[0]
                 for a in range(reverse['SU3_channel_range'][1])]
        drev = [catalog.duals.channel_objects(right, left, out, a)[1]
                 for a in range(reverse['SU3_channel_range'][1])]
        dl = dimension(catalog.by_id[b['left_component_id']])
        dr = dimension(catalog.by_id[b['right_component_id']])
        local = sp.zeros(len(csrev), len(ds))
        for a, d in enumerate(ds):
            transposed = sp.SparseMatrix(1, dl*dr,
                {(0, j*dl+i): v for (_, k), v in d.todok().items()
                 for i, j in [divmod(k, dr)]})
            for bb, c in enumerate(csrev):
                local[bb, a] = (transposed*c)[0]
            rebuilt = sum((local[bb, a]*dd for bb, dd in enumerate(drev)), sp.zeros(1, dl*dr))
            assert clean(rebuilt-transposed) == sp.zeros(1, dl*dr)
        for ca, cb, a in product(*(range(r) for r in t['radices'])):
            source = {'family_id': fid, 'terminal_channel_index': ti, 'digits': [ca, cb, a]}
            for bb in range(local.rows):
                target = {'family_id': fid, 'terminal_channel_index': revti, 'digits': [cb, ca, bb]}
                if local[bb, a]:
                    swap[indices[address_key(target)], indices[address_key(source)]] = local[bb, a]
        blocks.append({'source_terminal': ti, 'target_terminal': revti,
                       'carrier_swap_matrix': payload(local),
                       'copy_transport': 'left and right copy digits exchanged',
                       'full_covector_residual': 'ZERO_EXACT'})
    swap = clean(swap)
    assert swap*swap == sp.eye(89) and sp.trace(swap) == 3
    plus = sp.SparseMatrix(sp.Matrix.hstack(*(swap-sp.eye(89)).nullspace()))
    minus = sp.SparseMatrix(sp.Matrix.hstack(*(swap+sp.eye(89)).nullspace()))
    assert plus.cols == 46 and minus.cols == 43
    assert sp.Matrix.hstack(plus, minus).rank() == 89
    return addresses, swap, plus, minus, blocks


def physical_bilinears(catalog, addresses):
    roles = br.load(br.HERE/'frozen_scalar_adapter_v2/SA9_scalar_role_adapter_V2.json')
    adapters = {r['component_id']: br.matrix(r['matrix']) for r in roles['component_adapters']['S']}
    result = []
    for address in addresses:
        _, _, slots, copies, b, _, ch, _ = catalog.address_parts(address)
        dl, dr = (dimension(catalog.by_id[cid]) for cid in slots)
        _, d = catalog.duals.channel_objects(tuple(b['left_H_label']), tuple(b['right_H_label']),
                                             tuple(b['output_H_label']), ch)
        f = sp.SparseMatrix(dl, dr, {(i//dr, i % dr): v for (_, i), v in d.todok().items()})
        al, ar = [adapters[cid][c*dim:(c+1)*dim, :] for cid, c, dim in zip(slots, copies, (dl, dr))]
        result.append(clean(al.T*f*ar))
    return result


def cat3_bilinears():
    """Materialize unchanged CAT3 matrix units in its canonical real weight basis."""
    data = br.load(br.HERE/'frozen_catalog_cat0_cat4/CAT3_scalar_bilinear_basis.json')
    cat2 = br.load(br.HERE/'frozen_catalog_cat0_cat4/CAT2_scalar_HPQ_decomposition.json')
    copies = {c['copy_id']: c for t in cat2['isotypic_blocks'] for c in t['copies']}
    result = []
    for row in data['basis']:
        ls = copies[row['left_copy']]['real_column_indices']
        rs = copies[row['right_copy']]['real_column_indices']
        assert len(ls) == len(rs)
        f = sp.MutableSparseMatrix(328, 328, {})
        if row['matrix_unit'] == 'COMPLEX_HERMITIAN_OFFDIAGONAL_IMAGINARY':
            # z=(x+i*y)/sqrt(2), Hermitian offdiagonal imaginary unit;
            # the real symmetric bilinear is its complete realification.
            assert len(ls) % 2 == 0
            for k in range(0, len(ls), 2):
                for i, j, v in [(ls[k], rs[k+1], -1), (ls[k+1], rs[k], 1)]:
                    f[i, j] += sp.Rational(v, 2); f[j, i] += sp.Rational(v, 2)
        else:
            for i, j in zip(ls, rs):
                if i == j:
                    f[i, j] = 1
                else:
                    f[i, j] += sp.Rational(1, 2); f[j, i] += sp.Rational(1, 2)
        assert f == f.T
        result.append(sp.SparseMatrix(f))
    assert len(result) == 46
    return data, result


def physical_replay(catalog, addresses):
    """No primary S imported. Transpose complete physical bilinears and solve."""
    fs = physical_bilinears(catalog, addresses)
    solved, pivots, m, rhs = pivot_solve(fs, [f.T for f in fs])
    assert solved*solved == sp.eye(89) and sp.trace(solved) == 3
    plus = sp.SparseMatrix(sp.Matrix.hstack(*(solved-sp.eye(89)).nullspace()))
    minus = sp.SparseMatrix(sp.Matrix.hstack(*(solved+sp.eye(89)).nullspace()))
    assert (plus.cols, minus.cols) == (46, 43)
    catdata, cats = cat3_bilinears()
    to_channels, cpivots, cm, crhs = pivot_solve(fs, cats)
    assert clean((solved-sp.eye(89))*to_channels) == sp.zeros(89, 46)
    # Work in physical coordinates for both mutual-span directions.
    symmetric = [clean(sum((plus[i, j]*f for i, f in enumerate(fs) if plus[i, j]),
                          sp.zeros(328))) for j in range(46)]
    to_cat, rpivots, rm, rrhs = pivot_solve(cats, symmetric)
    assert to_cat.rank() == 46 and to_channels.rank() == 46
    assert clean(to_channels*to_cat-plus) == sp.zeros(89, 46)
    return {'independently_solved_swap': payload(solved), 'pivot_entries': pivots,
            'basis_value_matrix': payload(m), 'swapped_values': payload(rhs),
            'plus_basis': payload(plus), 'minus_basis': payload(minus),
            'CAT3_basis_ids': [r['basis_id'] for r in catdata['basis']],
            'CAT3_to_ordered_channels': payload(to_channels),
            'symmetric_view_to_CAT3': payload(to_cat),
            'CAT3_pivot_entries': cpivots, 'reverse_span_pivot_entries': rpivots,
            'CAT3_pivot_matrix': payload(cm), 'CAT3_values': payload(crhs),
            'reverse_span_matrix': payload(rm), 'symmetric_values': payload(rrhs),
            'full_tensor_residual': 'ZERO_EXACT', 'mutual_span_residual': 'ZERO_EXACT',
            'primary_swap_imported': False,
            'independence': {'ALGORITHM_INDEPENDENT': True, 'CODE_PATH_INDEPENDENT': True,
                'LIBRARY_INDEPENDENT': False, 'RUNTIME_INDEPENDENT': False,
                'shared_inputs': 'INT3/REG7/qualified D, scalar adapter V2, exact physical coordinates'}}
