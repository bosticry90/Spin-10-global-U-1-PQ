"""Exact indexed Euler--Lagrange operations for the bounded M08 AST.

This extends the A2 operation without adding an AST node type.  Component
indices are exposed by Kronecker metrics and eliminated only by the explicit
contraction wrappers already present in the frozen AST.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Iterable

from m08_local_functional_ast import (
    add,
    derivative,
    is_zero,
    mul,
    normalize,
    parity,
    scalar,
    tensor,
)


Expr = dict[str, Any]
LEAF_NODES = {
    "ExactScalar", "Parameter", "FrozenBackground", "StructureConstant",
    "RepresentationGenerator", "KroneckerMetric",
}


def _all_index_names(expression: Expr) -> set[str]:
    found = set(expression.get("indices", ()))
    node = expression.get("node")
    if node == "PartialDerivative":
        found.add(expression["index"])
        found.update(_all_index_names(expression["argument"]))
    elif node == "Add":
        for term in expression["terms"]:
            found.update(_all_index_names(term))
    elif node == "OrderedProduct":
        for factor in expression["factors"]:
            found.update(_all_index_names(factor))
    elif node in {"LorentzContraction", "GroupContraction"}:
        found.update(expression.get("contracted_indices", ()))
        found.update(expression.get("summed_indices", ()))
        found.update(_all_index_names(expression[_inner_key(expression)]))
    elif node == "LocalActionTerm":
        found.update(_all_index_names(expression["density"]))
    return found


def alpha_rename_reserved_dummies(expression: Expr, reserved: set[str]) -> Expr:
    """Rename contraction dummies that would capture variational free slots."""
    used = _all_index_names(expression) | set(reserved)
    ordinal = 0

    def fresh() -> str:
        nonlocal ordinal
        while True:
            candidate = f"_var{ordinal}"
            ordinal += 1
            if candidate not in used:
                used.add(candidate)
                return candidate

    def visit(node: Expr) -> Expr:
        result = deepcopy(node)
        kind = result.get("node")
        if kind in {"LorentzContraction", "GroupContraction"}:
            key = _inner_key(result)
            index_key = (
                "contracted_indices" if "contracted_indices" in result
                else "summed_indices" if "summed_indices" in result
                else "contracted_indices"
            )
            indices = list(result.get(index_key, ()))
            child = result[key]
            for position, index in enumerate(indices):
                if index in reserved:
                    replacement = fresh()
                    child = _replace_index(child, index, replacement)
                    indices[position] = replacement
            result[index_key] = indices
            result[key] = visit(child)
            result["parity"] = parity(result[key])
            return result
        if kind == "Add":
            result["terms"] = [visit(term) for term in result["terms"]]
        elif kind == "OrderedProduct":
            result["factors"] = [visit(factor) for factor in result["factors"]]
        elif kind == "PartialDerivative":
            result["argument"] = visit(result["argument"])
        elif kind == "LocalActionTerm":
            result["density"] = visit(result["density"])
        return result

    return visit(expression)


def expand_spacetime_derivatives(expression: Expr) -> Expr:
    """Expand derivatives of sums/products before Euler lowering.

    This is deliberately local to the variational operation.  It preserves the
    frozen action serialization and is what distinguishes ``d(V*u)`` from
    ``V*d(u)`` in the heavy-ghost regression.
    """
    node = expression.get("node")
    if node == "Add":
        return add(*(expand_spacetime_derivatives(term) for term in expression["terms"]))
    if node == "OrderedProduct":
        return mul(*(expand_spacetime_derivatives(factor) for factor in expression["factors"]))
    if node == "PartialDerivative":
        index = expression["index"]
        argument = expand_spacetime_derivatives(expression["argument"])
        if argument.get("node") == "Add":
            return add(*(expand_spacetime_derivatives(derivative(index, term))
                         for term in argument["terms"]))
        if argument.get("node") == "OrderedProduct":
            factors = argument["factors"]
            terms = []
            for position, factor in enumerate(factors):
                if factor.get("node") in {
                    "ExactScalar", "Parameter", "StructureConstant",
                    "RepresentationGenerator", "KroneckerMetric",
                }:
                    continue
                terms.append(mul(
                    *factors[:position],
                    expand_spacetime_derivatives(derivative(index, factor)),
                    *factors[position + 1:],
                ))
            return add(*terms)
        if argument.get("node") in {"LorentzContraction", "GroupContraction"}:
            key = _inner_key(argument)
            result = deepcopy(argument)
            result[key] = expand_spacetime_derivatives(derivative(index, argument[key]))
            result["parity"] = parity(result[key])
            return result
        return derivative(index, argument)
    if node in {"LorentzContraction", "GroupContraction"}:
        key = _inner_key(expression)
        result = deepcopy(expression)
        result[key] = expand_spacetime_derivatives(expression[key])
        result["parity"] = parity(result[key])
        return result
    if node == "LocalActionTerm":
        return expand_spacetime_derivatives(expression["density"])
    return expression


def _inner_key(expression: Expr) -> str:
    if "expression" in expression:
        return "expression"
    if "argument" in expression:
        return "argument"
    raise ValueError(f"contraction node lacks an operand: {expression.get('node')}")


def _jet(expression: Expr) -> tuple[str, str, tuple[str, ...], tuple[str, ...], int] | None:
    derivative_indices: list[str] = []
    current = expression
    while current.get("node") == "PartialDerivative":
        derivative_indices.append(current["index"])
        current = current["argument"]
    if current.get("node") not in {"Field", "ExternalSource"}:
        return None
    return (
        current["node"],
        current["name"],
        tuple(current.get("indices", ())),
        tuple(derivative_indices),
        parity(current),
    )


def _occurrence_orders(expression: Expr, *, node_type: str, name: str) -> set[tuple[str, ...]]:
    found: set[tuple[str, ...]] = set()
    candidate = _jet(expression)
    if candidate is not None and candidate[0] == node_type and candidate[1] == name:
        found.add(candidate[3])
        return found
    node = expression.get("node")
    if node == "Add":
        for term in expression["terms"]:
            found.update(_occurrence_orders(term, node_type=node_type, name=name))
    elif node == "OrderedProduct":
        for factor in expression["factors"]:
            found.update(_occurrence_orders(factor, node_type=node_type, name=name))
    elif node == "PartialDerivative":
        found.update(_occurrence_orders(expression["argument"], node_type=node_type, name=name))
    elif node in {"LorentzContraction", "GroupContraction"}:
        found.update(_occurrence_orders(
            expression[_inner_key(expression)], node_type=node_type, name=name))
    elif node == "LocalActionTerm":
        found.update(_occurrence_orders(expression["density"], node_type=node_type, name=name))
    return found


def _metric_name(kind: str) -> str:
    return {
        "lorentz": "eta_Lorentz",
        "adjoint_H": "delta_adjoint_H",
        "heavy": "delta_R_heavy",
        "scalar": "delta_scalar_328",
        "generic": "delta_exact",
    }[kind]


def _component_delta(indices: tuple[str, ...], free_indices: tuple[str, ...],
                     index_kinds: tuple[str, ...]) -> Expr:
    if len(indices) != len(free_indices) or len(indices) != len(index_kinds):
        raise ValueError((indices, free_indices, index_kinds))
    if not indices:
        return scalar(1)
    return mul(*(
        tensor("KroneckerMetric", _metric_name(kind), (old, free))
        for old, free, kind in zip(indices, free_indices, index_kinds, strict=True)
    ))


def _jet_partial(expression: Expr, *, node_type: str, name: str,
                 derivative_indices: tuple[str, ...], free_indices: tuple[str, ...],
                 index_kinds: tuple[str, ...], side: str) -> Expr:
    expression = normalize(expression)
    candidate = _jet(expression)
    if candidate is not None:
        candidate_type, candidate_name, indices, derivatives, _ = candidate
        if candidate_type == node_type and candidate_name == name and derivatives == derivative_indices:
            return _component_delta(indices, free_indices, index_kinds)
        return scalar(0)
    node = expression.get("node")
    if node in LEAF_NODES or node in {"Field", "ExternalSource"}:
        return scalar(0)
    if node == "Add":
        return add(*(
            _jet_partial(
                term, node_type=node_type, name=name,
                derivative_indices=derivative_indices,
                free_indices=free_indices, index_kinds=index_kinds, side=side,
            )
            for term in expression["terms"]
        ))
    if node == "OrderedProduct":
        factors = expression["factors"]
        terms = []
        for position, factor in enumerate(factors):
            differentiated = _jet_partial(
                factor, node_type=node_type, name=name,
                derivative_indices=derivative_indices,
                free_indices=free_indices, index_kinds=index_kinds, side=side,
            )
            if is_zero(differentiated):
                continue
            if side == "left":
                exponent = sum(parity(item) for item in factors[:position])
            elif side == "right":
                exponent = sum(parity(item) for item in factors[position + 1:])
            else:
                raise ValueError("side must be left or right")
            terms.append(mul(
                scalar(-1 if exponent % 2 else 1),
                *factors[:position], differentiated, *factors[position + 1:],
            ))
        return add(*terms)
    if node in {"LorentzContraction", "GroupContraction"}:
        key = _inner_key(expression)
        differentiated = _jet_partial(
            expression[key], node_type=node_type, name=name,
            derivative_indices=derivative_indices,
            free_indices=free_indices, index_kinds=index_kinds, side=side,
        )
        if is_zero(differentiated):
            return scalar(0)
        result = deepcopy(expression)
        result[key] = differentiated
        result["parity"] = parity(differentiated)
        return result
    if node == "LocalActionTerm":
        return _jet_partial(
            expression["density"], node_type=node_type, name=name,
            derivative_indices=derivative_indices,
            free_indices=free_indices, index_kinds=index_kinds, side=side,
        )
    if node == "PartialDerivative":
        # A derivative of a composite is not a jet.  Preserve it while
        # differentiating the composite coefficient.
        return derivative(
            expression["index"],
            _jet_partial(
                expression["argument"], node_type=node_type, name=name,
                derivative_indices=derivative_indices,
                free_indices=free_indices, index_kinds=index_kinds, side=side,
            ),
        )
    raise ValueError(f"unsupported AST node in indexed derivative: {node}")


def _replace_index(expression: Expr, old: str, new: str) -> Expr:
    result = deepcopy(expression)
    if "indices" in result:
        result["indices"] = [new if index == old else index for index in result["indices"]]
    if result.get("node") == "PartialDerivative":
        if result["index"] == old:
            result["index"] = new
        result["argument"] = _replace_index(result["argument"], old, new)
    elif result.get("node") == "Add":
        result["terms"] = [_replace_index(term, old, new) for term in result["terms"]]
    elif result.get("node") == "OrderedProduct":
        result["factors"] = [_replace_index(factor, old, new) for factor in result["factors"]]
    elif result.get("node") in {"LorentzContraction", "GroupContraction"}:
        key = _inner_key(result)
        result[key] = _replace_index(result[key], old, new)
        for index_key in ("contracted_indices", "summed_indices"):
            if index_key in result:
                result[index_key] = [
                    new if index == old else index for index in result[index_key]
                ]
    elif result.get("node") == "LocalActionTerm":
        result["density"] = _replace_index(result["density"], old, new)
    return result


def _index_counts(expression: Expr) -> dict[str, int]:
    counts: dict[str, int] = {}

    def visit(node: Expr) -> None:
        for index in node.get("indices", ()):
            counts[index] = counts.get(index, 0) + 1
        kind = node.get("node")
        if kind == "PartialDerivative":
            counts[node["index"]] = counts.get(node["index"], 0) + 1
            visit(node["argument"])
        elif kind == "Add":
            # Called after contraction distribution; each term is simplified
            # separately, so an Add here is only a nested tensor-valued sum.
            for term in node["terms"]:
                visit(term)
        elif kind == "OrderedProduct":
            for factor in node["factors"]:
                visit(factor)
        elif kind in {"LorentzContraction", "GroupContraction"}:
            visit(node[_inner_key(node)])
        elif kind == "LocalActionTerm":
            visit(node["density"])

    visit(expression)
    return counts


def simplify_contractions(expression: Expr) -> Expr:
    node = expression.get("node")
    if node == "Add":
        return add(*(simplify_contractions(term) for term in expression["terms"]))
    if node == "OrderedProduct":
        return mul(*(simplify_contractions(factor) for factor in expression["factors"]))
    if node == "PartialDerivative":
        return derivative(expression["index"], simplify_contractions(expression["argument"]))
    if node == "LocalActionTerm":
        return simplify_contractions(expression["density"])
    if node not in {"LorentzContraction", "GroupContraction"}:
        return expression
    key = _inner_key(expression)
    child = simplify_contractions(expression[key])
    if child.get("node") == "Add":
        distributed = []
        for term in child["terms"]:
            wrapped = deepcopy(expression)
            wrapped[key] = term
            wrapped["parity"] = parity(term)
            distributed.append(simplify_contractions(wrapped))
        return add(*distributed)
    index_key = (
        "contracted_indices" if "contracted_indices" in expression
        else "summed_indices" if "summed_indices" in expression
        else "contracted_indices"
    )
    contracted = list(expression.get(index_key, ()))
    changed = True
    while changed:
        changed = False
        factors = child["factors"] if child.get("node") == "OrderedProduct" else [child]
        counts = _index_counts(child)
        for position, factor in enumerate(factors):
            if factor.get("node") != "KroneckerMetric":
                continue
            left, right = factor["indices"]
            if left in contracted:
                old, new = left, right
            elif right in contracted:
                old, new = right, left
            elif counts.get(left, 0) > 1 and counts.get(right, 0) == 1:
                old, new = left, right
            elif counts.get(right, 0) > 1 and counts.get(left, 0) == 1:
                old, new = right, left
            else:
                continue
            remaining = factors[:position] + factors[position + 1:]
            child = mul(*(_replace_index(item, old, new) for item in remaining))
            contracted = [index for index in contracted if index != old]
            changed = True
            break
    live_indices = _all_index_names(child)
    contracted = [index for index in contracted if index in live_indices]
    if not contracted:
        return child
    result = deepcopy(expression)
    result[key] = child
    result[index_key] = contracted
    result["parity"] = parity(child)
    return result


def indexed_euler_lagrange(expression: Expr, *, name: str,
                           free_indices: Iterable[str], index_kinds: Iterable[str],
                           node_type: str = "Field", side: str = "left") -> Expr:
    """Return the exact indexed Euler--Lagrange derivative.

    ``free_indices`` names the output slots.  ``index_kinds`` chooses the
    immutable identity tensor used to expose each slot.
    """
    free = tuple(free_indices)
    kinds = tuple(index_kinds)
    expression = alpha_rename_reserved_dummies(expression, set(free))
    expression = expand_spacetime_derivatives(expression)
    result = scalar(0)
    orders = sorted(_occurrence_orders(expression, node_type=node_type, name=name))
    for derivative_indices in orders:
        term = _jet_partial(
            expression, node_type=node_type, name=name,
            derivative_indices=derivative_indices,
            free_indices=free, index_kinds=kinds, side=side,
        )
        for index in reversed(derivative_indices):
            term = derivative(index, term)
        if len(derivative_indices) % 2:
            term = mul(scalar(-1), term)
        result = add(result, term)
    # The variational integration by parts above can create derivatives of a
    # product even when the input had already been expanded.  Expand once more
    # before eliminating component deltas so that, for example, the two
    # ``V * partial(u)`` contributions in ``delta[partial(V*u)]/delta V``
    # cancel exactly and leave the derivative on the antighost coefficient.
    return simplify_contractions(expand_spacetime_derivatives(result))


def sum_local_densities(local_terms: list[dict[str, Any]]) -> Expr:
    densities = []
    for row in local_terms:
        term = row["term"]
        densities.append(term["density"] if term.get("node") == "LocalActionTerm" else term)
    return add(*densities)


def lower_sparse_ambient_gradient(*, embedding_entries: list[list[Any]],
                                  metric_diagonal: list[str],
                                  ambient_gradient: list[Expr],
                                  domain_dimension: int) -> list[Expr]:
    """Apply the exact field-specific ``E^dagger G`` gradient bridge.

    The entries are the already-frozen sparse coordinate-to-tensor embedding.
    This operation intentionally accepts the tensor metric explicitly: using a
    Euclidean transpose here would be wrong for the complex 10 and singlet and
    would obscure the real-252 interpretation of the 126.
    """
    if len(metric_diagonal) != len(ambient_gradient):
        raise ValueError("ambient metric and gradient dimensions differ")
    result = [scalar(0) for _ in range(domain_dimension)]
    for ambient_row, coordinate_column, coefficient in embedding_entries:
        result[coordinate_column] = add(
            result[coordinate_column],
            mul(
                scalar(coefficient),
                scalar(metric_diagonal[ambient_row]),
                ambient_gradient[ambient_row],
            ),
        )
    return result
