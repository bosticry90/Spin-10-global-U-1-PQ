"""Bounded ordinary-derivative SO+(1,3) jets and exact total derivatives.

Tokens are occurrence-attached vector indices or commuting partial derivatives.
At these bounds there are at most four indices. Their invariant contractions
are metric matchings and the alternating four-form, with intrinsic commuting
derivative identities imposed before IBP. No EOM or statistics signs here.
"""
from functools import lru_cache
from itertools import combinations_with_replacement, combinations, product
import sympy as sp
from jcat_lorentz_v2 import metric,epsilon
from jcat_internal_permutations import stabilizer_elements,specht_character,partitions
from execute_scalar_ast_channel_bridge import serialize


def matchings(tokens):
    if not tokens:
        yield ();return
    for j in range(1,len(tokens)):
        for rest in matchings(tokens[1:j]+tokens[j+1:]):
            yield ((tokens[0],tokens[j]),)+rest


def canon(parity,contraction):
    if parity=='PARITY_EVEN':
        return (parity,tuple(sorted(tuple(sorted(pair)) for pair in contraction))),1
    tokens=list(contraction)
    if len(set(tokens))<4: return None,0
    sign=(-1)**sum(tokens[i]>tokens[j] for i in range(4) for j in range(i+1,4))
    return (parity,tuple(sorted(tokens))),sign


def tensor_generators(tokens):
    assert len(tokens) in (0,2,4)
    for pairing in matchings(tuple(tokens)):
        yield canon('PARITY_EVEN',pairing)
    if len(tokens)==4:
        yield canon('PARITY_ODD',tokens)


def rename(key,perm):
    parity,contraction=key
    inverse={old:new for new,old in enumerate(perm)}
    def token(t): return t[0],inverse[t[1]]
    return canon(parity,tuple(tuple(token(t) for t in p) for p in contraction) if parity=='PARITY_EVEN' else tuple(token(t) for t in contraction))


@lru_cache(None)
def construct(vector_slots,slot_count,degrees):
    vectors=[('v',i) for i in vector_slots]
    keys=set()
    relation_dicts=[]
    for degree in degrees:
        for placement in combinations_with_replacement(range(slot_count),degree):
            for key,value in tensor_generators(vectors+[('p',i) for i in placement]):
                if value:keys.add((degree,key))
        if degree:
            # Every divergence of a local vector density of degree d-1. The
            # q index labels the free vector; q=sum_i p_i implements the
            # exact Leibniz/total-derivative relation without reordering slots.
            for placement in combinations_with_replacement(range(slot_count),degree-1):
                tokens=vectors+[('p',i) for i in placement]+[('q',-1)]
                for qkey,sign in tensor_generators(tokens):
                    if not sign:continue
                    relation={}
                    for i in range(slot_count):
                        def sub(t): return ('p',i) if t[0]=='q' else t
                        parity,contraction=qkey
                        mapped=tuple(tuple(sub(t) for t in pair) for pair in contraction) if parity=='PARITY_EVEN' else tuple(sub(t) for t in contraction)
                        key,value=canon(parity,mapped)
                        if value:relation[(degree,key)]=relation.get((degree,key),0)+sign*value
                    if any(relation.values()):relation_dicts.append(relation)
    ordered=tuple(sorted(keys)); index={key:i for i,key in enumerate(ordered)}
    relations=sp.SparseMatrix(len(ordered),len(relation_dicts),{(index[k],j):v for j,r in enumerate(relation_dicts) for k,v in r.items() if v})
    reduced,pivots=relations.T.rref()
    free=[i for i in range(len(ordered)) if i not in pivots]
    quotient=sp.zeros(len(free),len(ordered))
    inclusion=sp.zeros(len(ordered),len(free))
    for j,i in enumerate(free):quotient[j,i]=inclusion[i,j]=1
    for row,pivot in enumerate(pivots):
        for j,i in enumerate(free):quotient[j,pivot]=-reduced[row,i]
    assert quotient*relations==sp.zeros(quotient.rows,relations.cols)
    assert quotient*inclusion==sp.eye(len(free))
    return ordered,relations,quotient,inclusion,tuple(free)


def representation(keys,perm):
    index={key:i for i,key in enumerate(keys)};out=sp.zeros(len(keys))
    for j,(degree,key) in enumerate(keys):
        image,coefficient=rename(key,perm)
        out[index[(degree,image)],j]=coefficient
    return out


def generate(rows):
    result=[]; types={}
    for row in rows:
        names=row['ordered_symbol_names']
        vectors=tuple(i for i,f in enumerate(row['field_types']) if f['Lorentz_type']=='VECTOR')
        degrees=tuple(row['degree_bounds']['feasible_derivative_degrees'])
        keys,r,q,n,free=construct(vectors,len(names),degrees)
        tid=f'JETS_{len(names)}_{"_".join(map(str,vectors))}_{"_".join(map(str,degrees))}'
        if tid not in types:
            types[tid]={'type_id':tid,'slot_count':len(names),'vector_slots':vectors,'derivative_degrees':degrees,
                'raw_addresses':keys,'IBP_relations':serialize(r),'quotient_map':serialize(q),
                'quotient_representatives':free,'raw_dimension':len(keys),'quotient_dimension':len(free),
                'parity_of_quotient_addresses':[keys[i][1][0] for i in free]}
        elements=list(stabilizer_elements(names)); actions=[]; traces=[]
        for p in elements:
            raw=representation(keys,p)
            action=q*raw*n
            assert q*raw*r==sp.zeros(q.rows,r.cols),(row['signature_id'],'IBP not equivariant')
            assert q*raw==action*q
            actions.append(action);traces.append(int(action.trace()))
        lookup={p:i for i,p in enumerate(elements)}
        for i,p in enumerate(elements):
            for j,t in enumerate(elements):
                composite=tuple(t[p[k]] for k in range(len(names)))
                assert actions[i]*actions[j]==actions[lookup[composite]]
        classes=[tuple(i for i,name in enumerate(names) if name==species) for species in dict.fromkeys(names)]
        young=[]
        for multi in product(*(partitions(len(c)) for c in classes)):
            chars=[sp.prod(specht_character(part,tuple(c.index(p[i]) for i in c)) for part,c in zip(multi,classes)) for p in elements]
            multiplicity=sp.Rational(sum(x*y for x,y in zip(chars,traces)),len(elements))
            assert multiplicity.is_Integer and multiplicity>=0
            if multiplicity:young.append({'multipartition':multi,'multiplicity':int(multiplicity),'Specht_dimension':int(chars[0])})
        assert sum(b['multiplicity']*b['Specht_dimension'] for b in young)==q.rows
        result.append({'signature_id':row['signature_id'],'type_id':tid,'raw_dimension':len(keys),
            'quotient_dimension':q.rows,'elements':elements,'quotient_traces':traces,
            'quotient_actions':[serialize(a) for a in actions],'quotient_Young_blocks':young,
            'IBP_equivariance':'ZERO_EXACT','stabilizer_group_relations':'ZERO_EXACT',
            'background_connection_covariance':'NOT_INFERRED_FROM_GLOBAL_ADJOINT_TRANSFORMATION',
            'EOM_quotiented':False,'statistics_projected':False})
    return {'status':'PASS_ORDINARY_PARTIAL_JET_ALGEBRA_NOT_BACKGROUND_ADMISSIBILITY',
            'signature_count':len(result),'reusable_jet_types':list(types.values()),'rows':result}
