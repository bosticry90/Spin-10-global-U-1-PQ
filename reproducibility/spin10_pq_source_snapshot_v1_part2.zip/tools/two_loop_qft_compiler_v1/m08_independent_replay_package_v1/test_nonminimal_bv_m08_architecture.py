"""Regressions for an exact failed prerequisite, not for M08 promotion."""
import copy
import inspect
import json
import unittest
from pathlib import Path
import sympy as s
from nonminimal_bv_m08_architecture import build
from nonminimal_bv_m08_architecture_replay import build as replay_build
import nonminimal_bv_m08_architecture_replay as replay_module
from audit_nonminimal_bv_m08_architecture import compare, negative_controls, encoded

HERE = Path(__file__).resolve().parent


class ArchitectureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.primary, cls.replay = build(), replay_build()

    def test_exact_primary_physical_replay_agreement(self):
        compare(self.primary, self.replay)

    def test_nine_mutations_rejected(self):
        self.assertEqual(negative_controls(self.primary, self.replay), 9)

    def test_frozen_bytes_regenerate(self):
        for name, row in (("primary", self.primary), ("replay", self.replay)):
            self.assertEqual(encoded(row), (HERE/"frozen_nonminimal_bv_m08_architecture"/(name+".json")).read_bytes())

    def test_two_contributions_add_not_cancel(self):
        c = self.primary["selected_component"]
        self.assertEqual(s.sympify(c["ghost_variation_contribution"]), s.Rational(1, 2))
        self.assertEqual(s.sympify(c["scalar_iteration_contribution"]), s.Rational(1, 2))
        self.assertEqual(s.sympify(c["coefficient_in_Q2_eta0"]), 1)

    def test_physical_representation_itself_is_consistent(self):
        self.assertEqual(self.primary["physical_representation_commutator_residual"], "ZERO_EXACT")

    def test_alternate_sign_is_diagnostic_not_adopted(self):
        self.assertEqual(self.primary["frozen_scalar_sign"], "1")
        self.assertIn("DIAGNOSTIC_ONLY_NOT_ADOPTED", self.primary["alternate_scalar_sign_selected_square"])
        self.assertFalse(self.primary["Sigma_or_frozen_images_changed"])

    def test_source_partners_cannot_be_fitted_into_this_coefficient(self):
        self.assertFalse(self.primary["source_or_auxiliary_dependent"])
        self.assertFalse(self.replay["R_H_or_sources_needed"])

    def test_no_EOM_or_IBP_identification(self):
        self.assertFalse(self.primary["EOM_or_IBP_used"])
        self.assertFalse(self.replay["EOM_or_IBP_used"])

    def test_no_full_complex_or_catalog_work_reached(self):
        for key in ("full_M08_master_action_constructed", "full_seventeen_role_rederivation_reached",
                    "catalog_reconstruction_reached", "HB1_C5_authorized", "full_M08_replacement_promoted"):
            self.assertFalse(self.primary[key])

    def test_independence_limits_are_retained(self):
        flags = self.replay["independence"]
        self.assertTrue(flags["algorithm_independent"] and flags["code_path_independent"])
        self.assertFalse(flags["library_independent"] or flags["runtime_independent"] or flags["external_specialist_review"])

    def test_replay_imports_no_primary_or_serialized_action_matrices(self):
        code = inspect.getsource(replay_module)
        self.assertNotIn("from nonminimal_bv_m08_architecture import", code)
        self.assertNotIn('load("frozen_scalar_adapter_v2/', code)

    def test_wrong_physics_or_formal_promotion_is_rejected(self):
        bad = copy.deepcopy(self.primary)
        bad["formal_authority"] = "35/39"
        with self.assertRaises(AssertionError):
            compare(bad, self.replay)
        self.assertIn("Spin(10) physics", self.primary["not_a_no_go_for"])


if __name__ == "__main__":
    unittest.main()
