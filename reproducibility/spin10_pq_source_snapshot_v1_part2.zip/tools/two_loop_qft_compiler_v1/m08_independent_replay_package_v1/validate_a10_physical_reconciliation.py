"""Read-only validation driver; receipt is emitted to stdout, not written."""
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from validate_interacting_actual_h_preflight import inventory, bound_hashes

HERE = Path(__file__).resolve().parent; ROOT = HERE.parents[2]

def main():
    assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED')
    state = sha256((ROOT/'project_state.json').read_bytes()).hexdigest()
    before = inventory(); inherited = bound_hashes(); records = []; start = time.perf_counter()
    reuse = '--reuse-fresh-receipt' in sys.argv
    if reuse:
        out = HERE/'frozen_a10_physical_reconciliation'
        prior = json.loads((out/'fresh_validation_receipt.json').read_text())
        sealed = json.loads((out/'fresh_validation_bindings.json').read_text())['byte_sha256']
        assert prior['status'] == 'PASS_INACTIVE_CLASSICAL_CANDIDATE_VALIDATION_ONLY' and prior['audit_time_changes'] == []
        entry = prior['tasks'][0]; assert entry['name'] == 'a10_new_evidence_fresh_regeneration' and entry['exit_code'] == 0
        evidence = json.loads(entry['stdout'].split('AUDIT ', 1)[1]); assert evidence['new_results_regenerated_byte_identically']
        # Only documents, scope authentication and validation routing changed.
        # Every calculation module and its frozen result remain byte-identical.
        core = ['a10_covariant_phi_control.py', 'a10_covariant_phi_replay.py', 'a10_physical_reconciliation.py',
                'a10_physical_reconciliation_replay.py', 'run_a10_reconciliation.py', 'assemble_a10_physical_candidate.py']
        core += ['frozen_a10_physical_reconciliation/'+name for name in ('phi_primary.json', 'phi_replay.json', 'full_primary.json', 'full_replay.json', 'M08_PHYSICAL_ACTION_COVARIANT_CANDIDATE_V1.json')]
        for name in core:
            path = HERE/name; rel = path.relative_to(ROOT).as_posix()
            assert sha256(path.read_bytes()).hexdigest() == sealed[rel], ('REUSED_FRESH_CORE_CHANGED', name)
    tasks = [
        ('a10_scoped_evidence_authentication', [str(HERE/'audit_a10_physical_reconciliation.py')]+([] if reuse else ['--fresh-new-only']), ROOT, 0),
        ('adversarial_candidate_regressions', ['-m', 'unittest', 'test_a10_physical_reconciliation', '-v'], HERE, 0),
        ('preserved_complete_action_negative_controls', ['-m', 'unittest', 'test_phase_c_scalar_action', '-v'], HERE, 0),
        ('governance_regressions', ['-m', 'unittest', 'discover', '-s', 'docs/ai_research_epistemic_ladder_v1', '-p', 'test_*.py'], ROOT, 0),
        ('authority_coherence', ['tools/two_loop_qft_compiler_v1/audit_authority_coherence.py'], ROOT, 0),
        ('structure_preserving_map', ['tools/readiness/audit_structure_preserving_map_contract.py'], ROOT, 0),
        ('read_only_entrypoints', ['tools/readiness/audit_read_only_contract.py'], ROOT, 0),
        ('historical_custody_current_coherence', ['docs/ai_research_epistemic_ladder_v1/audit_epistemic_ladder.py'], ROOT, 2)]
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(ROOT/'tools/pole_blind_validation_guard'))
    for name, args, cwd, expected in tasks:
        print('START '+name, flush=True); t = time.perf_counter()
        proc = subprocess.run([sys.executable, '-B', *args], cwd=cwd, env=env,
                              capture_output=True, text=True, encoding='utf-8', errors='replace')
        record = {'name': name, 'exit_code': proc.returncode, 'expected_exit_code': expected,
                  'wall_seconds': time.perf_counter()-t, 'stdout': proc.stdout, 'stderr': proc.stderr}
        records.append(record); print('DONE '+name+' '+str(proc.returncode), flush=True)
        if proc.returncode != expected:
            print('FAILED '+json.dumps(record), flush=True); raise RuntimeError('A10_BOUNDED_VALIDATION_FAILED_'+name)
    after = inventory()
    changes = sorted(n for n in before.keys() | after.keys() if before.get(n) != after.get(n))
    assert not changes, ('AUDIT_TIME_MUTATIONS', changes)
    assert bound_hashes() == inherited and sha256((ROOT/'project_state.json').read_bytes()).hexdigest() == state
    assert records[-1]['stdout'].count('RECORDED_DIGEST_UNRESOLVED:') == 7
    print('RECEIPT '+json.dumps({'schema': 'A10_PHYSICAL_RECONCILIATION_VALIDATION_RECEIPT_V1',
        'status': 'PASS_INACTIVE_CLASSICAL_CANDIDATE_VALIDATION_ONLY',
        'historical_A10_scientific_gate': 'FAILED_COMPLETE_PHYSICAL_ACTION_SELECTED_CHANNEL',
        'candidate_scientific_gate': 'PASS_INACTIVE_CLASSICAL_PHYSICAL_CANDIDATE_ONLY',
        'tasks': records, 'wall_seconds': time.perf_counter()-start, 'inherited_byte_bindings': len(inherited),
        'inherited_bytes_unchanged': True, 'workspace_active_data_metadata_records': len(before),
        'inventory_kind': 'size_and_mtime_ns_not_all_byte_audit', 'audit_time_changes': changes,
        'live_state_transaction_sha256': state, 'historical_custody_exit': 2, 'unresolved_historical_references': 7,
        'historical_original_bindings_resolved': False, 'mixed_source_or_nonminimal_expensive_rerun': False,
        'mixed_kinetic_run': False, 'HB1_C5_run': False, 'C1_GS_calculated': False,
        'T5_reconstructed': False, 'unrestricted_all_validation_run': False,
        'external_specialist_review': False, 'personal_outreach_planned': False,
        'solo_review_policy': 'docs/SOLO_REVIEW_POLICY_V1.md', 'candidate_adopted': False,
        'fresh_regeneration_reused_from_validated_unchanged_core': reuse,
        'fresh_receipt_sha256': sha256((HERE/'frozen_a10_physical_reconciliation/fresh_validation_receipt.json').read_bytes()).hexdigest() if reuse else None,
        'formal_authority': '34/39_UNCHANGED'}, sort_keys=True, separators=(',', ':')), flush=True)

if __name__ == '__main__': main()
