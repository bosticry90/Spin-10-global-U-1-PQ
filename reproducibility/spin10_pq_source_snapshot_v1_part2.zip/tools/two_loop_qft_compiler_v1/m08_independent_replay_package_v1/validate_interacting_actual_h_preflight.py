"""Bounded validation driver: no writes, no --all, no catalog rebuild."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT/'tools/readiness'))
from profile_pole_blind_workflow import process_counters


def inventory():
    out={}
    for root in (ROOT,ROOT.parent/'ToE-Next-active-data'):
        for directory,subdirs,files in os.walk(root,followlinks=False):
            subdirs[:]=[name for name in subdirs if name!='.git']
            for name in files:
                p=Path(directory)/name; st=p.stat(); out[str(p)]=(st.st_size,st.st_mtime_ns)
    return out


def bound_hashes():
    a=json.loads((HERE/'frozen_interacting_actual_h_preflight/architecture.json').read_text())
    b=json.loads((HERE/'frozen_interacting_actual_h_preflight/bindings.json').read_text())
    expected={row['path']:row['sha256'] for row in a['inherited_bindings_authenticated']}
    expected.update(b['new_byte_sha256'])
    actual={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in expected}
    assert actual==expected,'BOUND_INPUT_HASH_MISMATCH'
    return actual


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED'),'POLE_GUARD_REQUIRED'
    state_before=hashlib.sha256((ROOT/'project_state.json').read_bytes()).hexdigest()
    # Historical context is checked against immutable Git bytes by the evidence
    # audit. A future legitimate ledger change must not invalidate that history.
    # Current coherence is its own audit; here enforce only transactional custody.
    before=inventory(); hashes=bound_hashes(); records=[]; started=time.perf_counter(); first=process_counters()
    tasks=[
        ('bounded_evidence_and_fresh_parallel_regeneration',[str(HERE/'audit_interacting_actual_h_preflight.py'),'--verify-fresh-repeat'],ROOT,0),
        ('new_bounded_regressions',['-m','unittest','test_interacting_actual_h_preflight','-v'],HERE,0),
        ('governance_regressions',['-m','unittest','discover','-s','docs/ai_research_epistemic_ladder_v1','-p','test_*.py'],ROOT,0),
        ('authority_coherence',['tools/two_loop_qft_compiler_v1/audit_authority_coherence.py'],ROOT,0),
        ('structure_preserving_map',['tools/readiness/audit_structure_preserving_map_contract.py'],ROOT,0),
        ('read_only_entrypoints',['tools/readiness/audit_read_only_contract.py'],ROOT,0),
        ('historical_custody_current_coherence',['docs/ai_research_epistemic_ladder_v1/audit_epistemic_ladder.py'],ROOT,2)]
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(ROOT/'tools/pole_blind_validation_guard'))
    for name,args,cwd,expected in tasks:
        t=time.perf_counter(); print('START '+name,flush=True)
        result=subprocess.run([sys.executable,'-B',*args],cwd=cwd,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
        record={'name':name,'exit_code':result.returncode,'expected_exit_code':expected,'wall_seconds':time.perf_counter()-t,'stdout':result.stdout,'stderr':result.stderr}
        records.append(record); print('DONE '+name+' '+str(result.returncode),flush=True)
        if result.returncode!=expected:
            print('FAILED '+json.dumps(record),flush=True); raise RuntimeError('BOUNDED_VALIDATION_FAILED_'+name)
    after=inventory(); changes=sorted(name for name in set(before)|set(after) if before.get(name)!=after.get(name))
    assert not changes,'AUDIT_TIME_WORKSPACE_OR_ACTIVE_DATA_MUTATION'
    assert bound_hashes()==hashes
    assert hashlib.sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state_before
    report={'schema':'INTERACTING_ACTUAL_H_VALIDATION_RECEIPT_V1','status':'PASS_BOUNDED_VALIDATION_ONLY','tasks':records,
        'inventory_records_before':len(before),'inventory_records_after':len(after),'inventory_kind':'size_and_mtime_ns_not_all_byte_audit',
        'audit_time_changes':changes,'bound_byte_count':len(hashes),'bound_bytes_unchanged':True,'live_state_transaction_sha256':state_before,'wall_seconds':time.perf_counter()-started,
        'process_before':first,'process_after':process_counters(),'historical_custody_exit':2,'historical_original_bindings_resolved':False,
        'unrestricted_all_validation_run':False,'T5_reconstructed':False,'external_specialist_review':False,
        'recorded_preflight_authority':'34/39_UNCHANGED','live_state_expectation':'transactional_preservation_not_historical_hash_equality',
        'reused_historical_tests':'156 byte bindings; earlier scientific tests not rerun'}
    print('RECEIPT '+json.dumps(report,sort_keys=True,separators=(',',':')),flush=True)


if __name__=='__main__': main()
