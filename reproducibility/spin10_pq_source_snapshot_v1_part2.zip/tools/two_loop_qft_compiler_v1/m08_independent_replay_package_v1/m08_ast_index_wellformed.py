"""Exact bounded index checks for the frozen M08 functional AST.

This is deliberately a structural validator, not a tensor algebra package.
It checks the demonstrated failure class: additive tensor expressions must
have one common free-index signature, products may contract an index only in
pairs, and declared free indices must agree exactly with the AST.
"""

from __future__ import annotations

from hashlib import sha256
import json
from typing import Any, Iterable


Expr = dict[str, Any]


class IndexWellFormedError(RuntimeError):
    pass


def _leaf_signature(expression: Expr) -> tuple[str, ...]:
    counts: dict[str, int] = {}
    for index in expression.get("indices", ()):
        counts[index] = counts.get(index, 0) + 1
    repeated = {index: count for index, count in counts.items() if count > 2}
    if repeated:
        raise IndexWellFormedError(f"leaf index multiplicity exceeds two: {repeated}")
    return tuple(sorted(index for index, count in counts.items() if count == 1))


def _combine(signatures: Iterable[tuple[str, ...]], context: str) -> tuple[str, ...]:
    counts: dict[str, int] = {}
    for signature in signatures:
        for index in signature:
            counts[index] = counts.get(index, 0) + 1
    repeated = {index: count for index, count in counts.items() if count > 2}
    if repeated:
        raise IndexWellFormedError(
            f"{context} index multiplicity exceeds two: {repeated}"
        )
    return tuple(sorted(index for index, count in counts.items() if count == 1))


def free_signature(expression: Expr) -> tuple[str, ...]:
    node = expression["node"]
    if node in {
        "ExactScalar", "Parameter", "Field", "ExternalSource",
        "FrozenBackground", "StructureConstant", "RepresentationGenerator",
        "KroneckerMetric",
    }:
        return _leaf_signature(expression)
    if node == "PartialDerivative":
        return _combine(
            (free_signature(expression["argument"]), (expression["index"],)),
            "partial derivative",
        )
    if node == "Add":
        signatures = [free_signature(term) for term in expression["terms"]]
        if not signatures:
            return ()
        if any(signature != signatures[0] for signature in signatures[1:]):
            raise IndexWellFormedError(
                f"addends have inconsistent free indices: {signatures}"
            )
        return signatures[0]
    if node == "OrderedProduct":
        return _combine(
            (free_signature(factor) for factor in expression["factors"]),
            "ordered product",
        )
    if node in {"LorentzContraction", "GroupContraction"}:
        signature = list(free_signature(expression["expression"]))
        for index in expression.get("contracted_indices", ()):
            if index in signature:
                signature.remove(index)
        return tuple(sorted(signature))
    if node == "LocalActionTerm":
        return free_signature(expression["density"])
    raise IndexWellFormedError(f"unsupported AST node: {node}")


def audit_expression(
    expression: Expr,
    *,
    declared_free: Iterable[str] = (),
    expression_id: str = "expression",
) -> dict[str, Any]:
    actual = free_signature(expression)
    expected = tuple(sorted(declared_free))
    if actual != expected:
        raise IndexWellFormedError(
            f"{expression_id}: declared free indices {expected}, actual {actual}"
        )
    return {
        "expression_id": expression_id,
        "declared_free_indices": list(expected),
        "actual_free_indices": list(actual),
        "status": "PASS_EXACT",
    }


def rename_indices(expression: Expr, mapping: dict[str, str]) -> Expr:
    """Pure deterministic index renaming used by the regression oracle."""
    node = expression["node"]
    result = dict(expression)
    if "indices" in result:
        result["indices"] = [mapping.get(index, index) for index in result["indices"]]
    if node == "PartialDerivative":
        result["index"] = mapping.get(result["index"], result["index"])
        result["argument"] = rename_indices(result["argument"], mapping)
    elif node == "Add":
        result["terms"] = [rename_indices(term, mapping) for term in result["terms"]]
    elif node == "OrderedProduct":
        result["factors"] = [rename_indices(factor, mapping)
                             for factor in result["factors"]]
    elif node in {"LorentzContraction", "GroupContraction"}:
        result["contracted_indices"] = [
            mapping.get(index, index)
            for index in result.get("contracted_indices", ())
        ]
        result["expression"] = rename_indices(result["expression"], mapping)
    elif node == "LocalActionTerm":
        result["density"] = rename_indices(result["density"], mapping)
    return result


def canonical_hash(expression: Expr) -> str:
    encoded = json.dumps(expression, sort_keys=True, separators=(",", ":")).encode()
    return sha256(encoded).hexdigest()
