"""Read-only stdout measurement wrapper for the two bounded Phase C routes."""
import importlib
import json
import os
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'tools/readiness'))
from profile_pole_blind_workflow import process_counters


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    name=sys.argv[1]
    assert name in ('phase_c_mixed_source','phase_c_mixed_source_replay','phase_c_mixed_kinetic','phase_c_mixed_kinetic_replay','phase_c_nonminimal_map','phase_c_nonminimal_map_replay')
    reads=set(); counts={'read_open_attempts':0,'write_open_attempts':0}
    def hook(event,args):
        if event!='open' or not isinstance(args[0],(str,bytes)): return
        path=Path(os.fsdecode(args[0])); mode=args[1] or ''; flags=args[2] if len(args)>2 else 0
        if any(c in mode for c in 'wax+') or flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC):
            counts['write_open_attempts']+=1
            raise PermissionError('PHASE_C_CALCULATION_WRITES_FORBIDDEN')
        counts['read_open_attempts']+=1; reads.add(str(path.resolve()))
    sys.addaudithook(hook)
    begin=time.perf_counter(); initial=process_counters(); stages=[]
    def stage(label,fn):
        print('STAGE '+label,flush=True); t=time.perf_counter(); c=process_counters()
        try: return fn()
        finally:
            after=process_counters(); stages.append({'stage':label,'wall_seconds':time.perf_counter()-t,'cpu_seconds':after['cpu_seconds']-c['cpu_seconds'],'peak_process_working_set_bytes':after['peak_working_set_bytes']})
    module=stage('module_import',lambda:importlib.import_module(name))
    try: result=module.build(stage)
    except getattr(module,'Failure',getattr(module,'FailedIdentity',())) as e:
        result={'schema':'PHASE_C_MIXED_KINETIC_GATE_V1' if 'kinetic' in name else 'PHASE_C_MIXED_SOURCE_PREREQUISITE_V1','status':'FAILED_FIRST_PREREQUISITE','witness':e.evidence,'full_M08_qualified':False,'active_sources_added':False,'formal_authority':'34/39_UNCHANGED'}
    raw=stage('serialization',lambda:json.dumps(result,sort_keys=True,separators=(',',':')))
    print('RESULT '+raw,flush=True)
    after=process_counters()
    sizes=[Path(p).stat().st_size for p in reads if Path(p).is_file()]
    metrics={'route':name,'wall_seconds':time.perf_counter()-begin,'cpu_seconds':after['cpu_seconds']-initial['cpu_seconds'],
        'peak_process_working_set_bytes':after['peak_working_set_bytes'],'stages':stages,**counts,'unique_read_files':len(sizes),'unique_read_file_sizes_sum_bytes':sum(sizes),
        'result_stdout_bytes':len(raw.encode()),'workspace_files_written':0,'os_io_read_transfer_bytes':after['os_io_read_transfer_bytes']-initial['os_io_read_transfer_bytes'],
        'os_io_write_transfer_bytes':after['os_io_write_transfer_bytes']-initial['os_io_write_transfer_bytes'],'parse_normalization_seconds_separately_instrumented':None,
        'exact_linear_algebra_seconds_separately_instrumented':None,'cache_hits':None,'cache_misses':None,
        'measurement_limits':'Unique file sizes are not bytes actually consumed. OS transfers include runtime and pipe I/O. Per-stage peak is cumulative process peak; shared runtime/import costs are not independent. Uninstrumented subdivisions/cache counts are null.'}
    print('METRICS '+json.dumps(metrics,sort_keys=True,separators=(',',':')),flush=True)


if __name__=='__main__': main()
