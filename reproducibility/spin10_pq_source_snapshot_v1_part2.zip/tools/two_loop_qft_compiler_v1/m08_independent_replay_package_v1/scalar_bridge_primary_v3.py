"""A3-only fusion lowering in certified V2 coordinates. No comparator import."""
from functools import lru_cache
from itertools import product, combinations
from collections import defaultdict
import sympy as sp
import execute_scalar_ast_channel_bridge as br
from scalar_ast_primary_v2 import A3SlotLifts, CONJUGATE, pair_boundary, terminal_value
from scalar_dual_convention_v2 import ExactDualConvention

HERE = br.HERE
CONTROLS = ('muPhi', 'z6', 'lambdaPhi1', 'zEta')


def qualified_duals():
    """Reuse immutable qualified projections; do not renormalize or rederive."""
    obj = ExactDualConvention()
    cert = br.load(HERE/'frozen_scalar_dual_bridge_v2/DUAL2_DUAL4_exact_maps.json')
    assert cert['factor_block_count'] == 94 and cert['largest_multiplicity_inverse'] == 2
    for row in cert['blocks']:
        key = tuple(tuple(x) if isinstance(x, list) else x for x in row['channel_labels'])
        target = obj.d3 if row['group'] == 'SU3' else obj.d2
        target[key] = [br.matrix(d) for d in row['projections']]
    obj.certificates = cert['blocks']
    return obj


class ScalarCatalog:
    def __init__(self):
        ledger = br.load(HERE/'frozen_intertwiner_channel_basis/INT3_binary_channel_ledger.json')
        self.binary = next(p['blocks'] for p in ledger['ordered_pair_blocks'] if p['ordered_character_pair'] == ['S', 'S'])
        self.components = ledger['module_components']['S']
        self.by_id = {r['component_id']: r for r in self.components}
        self.descriptors = {r['arity']: r for r in br.load(HERE/'frozen_intertwiner_basis_int4r_int15/INT6_ordered_invariant_channel_families.json')['family_descriptors']
                            if r['ordered_character_families'] == ['S']*r['arity']}

    def dimension(self, cid):
        p, q, n, _ = self.by_id[cid]['H_label']
        return (p+1)*(q+1)*(p+q+2)*(n+1)//2

    def slots(self, address):
        arity = 3 if address['family_id'] == self.descriptors[3]['family_id'] else 4
        t = self.descriptors[arity]['terminal_channels'][address['terminal_channel_index']]
        x = address['digits']
        if arity == 3:
            b = self.binary[t['left_binary_block_index']]
            return [(b['left_component_id'], x[0]), (b['right_component_id'], x[1]),
                    (self.components[t['third_component_index']]['component_id'], x[3])]
        l = self.binary[t['left_binary_block_indices'][x[0]]]
        r = self.binary[t['right_binary_block_indices'][x[1]]]
        return [(l['left_component_id'], x[2]), (l['right_component_id'], x[3]),
                (r['left_component_id'], x[5]), (r['right_component_id'], x[6])]

    def eligible(self, ast, hc=False):
        names = [CONJUGATE[f] if hc else f for f, _ in br.factors(ast)[1]]
        degree = len(names); desc = self.descriptors[degree]
        for ti, t in enumerate(desc['terminal_channels']):
            if degree == 3:
                candidates = product(*(range(r) for r in t['radices']))
            else:
                def quartic_digits():
                    for lc, li in enumerate(t['left_binary_block_indices']):
                        l = self.binary[li]
                        if any(self.by_id[cid]['source_sector'] != name for cid, name in
                               zip((l['left_component_id'], l['right_component_id']), names[:2])):
                            continue
                        for rc, ri in enumerate(t['right_binary_block_indices']):
                            r = self.binary[ri]
                            if any(self.by_id[cid]['source_sector'] != name for cid, name in
                                   zip((r['left_component_id'], r['right_component_id']), names[2:])):
                                continue
                            radices = [l['left_copy_range'][1], l['right_copy_range'][1], l['SU3_channel_range'][1],
                                       r['left_copy_range'][1], r['right_copy_range'][1], r['SU3_channel_range'][1]]
                            for copies in product(*(range(radix) for radix in radices)):
                                yield (lc, rc, *copies)
                candidates = quartic_digits()
            for digits in candidates:
                address = {'family_id': desc['family_id'], 'terminal_channel_index': ti, 'digits': list(digits)}
                slots = self.slots(address)
                if all(self.by_id[cid]['source_sector'] == name for (cid, _), name in zip(slots, names)):
                    yield address, slots, names


class PrimaryLowering(ScalarCatalog):
    def __init__(self):
        super().__init__()
        self.duals = qualified_duals()
        self.roles = br.load(HERE/'frozen_scalar_adapter_v2/SA9_scalar_role_adapter_V2.json')
        self.lifts = A3SlotLifts(self.roles)
        self.used_binary = set()

    @lru_cache(None)
    def physical_pair_boundary(self, name, cid0, ca, i, cid1, cb, j, fields, right):
        a = self.lifts.lifts[cid0][ca*self.dimension(cid0)+i][fields[0]]
        b = self.lifts.lifts[cid1][cb*self.dimension(cid1)+j][fields[1]]
        if right and name == 'zEta':
            return {(idx, n[0]): va*vb for idx, va in a.items() for n, vb in b.items()}
        if name != 'zEta':
            return pair_boundary(name, a, b)
        # The frozen 24-fold index-orbit compression, evaluated in the exact
        # numeric radical ring by expansion rather than heuristic simplify.
        result = defaultdict(lambda: sp.Integer(0))
        for ia, va in a.items():
            for ib, vb in b.items():
                overlap = tuple(x for x in ia if x in ib)
                for ij in combinations(overlap, 2):
                    rest = tuple(x for x in ia if x not in ij)
                    pqr = tuple(x for x in ib if x not in ij)
                    for n in rest:
                        lm = tuple(x for x in rest if x != n); c = lm+pqr
                        if len(set(c)) == 5:
                            sign = br.parity(ij+lm+(n,))*br.parity(ij+pqr)*br.parity(c)
                            result[(tuple(sorted(c)), n)] += sign*va*vb
        return {idx: sp.expand(v) for idx, v in result.items() if sp.expand(v) != 0}

    @lru_cache(None)
    def boundary(self, name, bi, ca, cb, ch, fields, right=False):
        block = self.binary[bi]
        self.used_binary.add((bi, ch))
        c, d = self.duals.channel_objects(tuple(block['left_H_label']), tuple(block['right_H_label']), tuple(block['output_H_label']), ch)
        assert d*c == sp.eye(c.cols)
        cid0, cid1 = block['left_component_id'], block['right_component_id']
        d0, d1 = self.dimension(cid0), self.dimension(cid1)
        vs0 = self.lifts.lifts[cid0][ca*d0:(ca+1)*d0]
        vs1 = self.lifts.lifts[cid1][cb*d1:(cb+1)*d1]
        result = []
        for k in range(c.cols):
            entries = {}
            for (row, col), scale in c.todok().items():
                if col != k:
                    continue
                i, j = divmod(row, d1)
                part = self.physical_pair_boundary(name, cid0, ca, i, cid1, cb, j, fields, right)
                for idx, value in part.items():
                    entries[idx] = entries.get(idx, 0)+scale*value
            result.append({idx: sp.expand(v) for idx, v in entries.items() if sp.expand(v) != 0})
        return result

    def restricted_tensor(self, name, address, slots, fields):
        x = address['digits']; degree = len(slots)
        t = self.descriptors[degree]['terminal_channels'][address['terminal_channel_index']]
        if degree == 3:
            li = t['left_binary_block_index']; ca, cb, ch, cc = x
            left = self.boundary(name, li, ca, cb, ch, tuple(fields[:2]))
            dc = self.dimension(slots[2][0]); vs = self.lifts.lifts[slots[2][0]][cc*dc:(cc+1)*dc]
            target = sp.Matrix(len(left), dc, lambda i, j: terminal_value(name, left[i], vs[j][fields[2]]))
        else:
            lc, rc, ca, cb, ch, cc, cd, dh = x
            li, ri = t['left_binary_block_indices'][lc], t['right_binary_block_indices'][rc]
            left = self.boundary(name, li, ca, cb, ch, tuple(fields[:2]))
            right = self.boundary(name, ri, cc, cd, dh, tuple(fields[2:]), True)
            target = sp.Matrix(len(left), len(right), lambda i, j:
                               sp.simplify(left[i].get((), 0)*right[j].get((), 0)) if name == 'lambdaPhi1'
                               else sp.expand(sum(v*right[j].get(idx, 0) for idx, v in left[i].items())))
        label = tuple(self.binary[li]['output_H_label'])
        return target, self.duals.pairing(label).T, label

    def lower(self, name, ast):
        coefficients, checks = [], []
        for hc in ([False, True] if ast['complex_monomial'] else [False]):
            for address, slots, fields in self.eligible(ast, hc):
                target, pairing, label = self.restricted_tensor(name, address, slots, fields)
                i, j = sorted(pairing.todok())[0]
                coefficient = sp.simplify(target[i, j]/pairing[i, j])
                residual = sp.simplify(target-coefficient*pairing)
                row = {'branch': 'HC' if hc else 'MONOMIAL', 'address': address, 'ordered_slots': slots,
                       'intermediate_H_label': label, 'coefficient': str(coefficient),
                       'terminal_dimension': target.rows, 'extraction_entry': [i, j],
                       'target_sha256': br.canonical(br.serialize(target)), 'residual': 'ZERO_EXACT'}
                if residual != sp.zeros(*target.shape):
                    return coefficients, checks, dict(row, target=br.serialize(target), terminal_pairing=br.serialize(pairing),
                                                      residual=br.serialize(residual))
                checks.append(row)
                if coefficient != 0:
                    coefficients.append(row)
                if len(checks) % 100 == 0:
                    print('PRIMARY_V3', name, row['branch'], len(checks), 'NONZERO', len(coefficients), flush=True)
        return coefficients, checks, None
