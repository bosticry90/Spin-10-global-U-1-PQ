"""Read-only validation; successful evidence audit does not pass the failed gate."""
import json,os,re,subprocess,sys,time
from hashlib import sha256
from a10_e5_quartic_g3_control import HERE,ROOT,OUT,read
from validate_interacting_actual_h_preflight import inventory


def protected():
    sys.path.insert(0,str(ROOT/'tools'))
    from research_session_preflight import BINDING_KEYS,authenticate_bytes
    manifest=(HERE/'frozen_a10_e5_auxiliary_ghost/bindings.json').relative_to(ROOT).as_posix()
    authenticate_bytes(ROOT,manifest);names=set();seen=set()
    def visit(n):
        if n in seen:return
        seen.add(n);data=read(ROOT/n)
        for key in BINDING_KEYS:names.update(data.get(key,{}))
        for child in data.get('inherited_manifest_sha256',{}):visit(child)
    visit(manifest);names.update(seen);assert len(seen)==41
    return {n:sha256((ROOT/n).read_bytes()).hexdigest() for n in sorted(names)}


def new_files():
    files=list(HERE.glob('*quartic_g3*.py'))+list(HERE.glob('A10_E5_QUARTIC_G3*.md'))
    files += [ROOT/'docs/A10_E5_QUARTIC_G3_CURRENT.md',ROOT/'docs/RESEARCH_EXECUTION_HANDOFF_V30.md']
    files += [p for p in OUT.rglob('*') if p.is_file() and p.name not in ['bindings.json','validation_receipt.json']]
    return sorted(set(files))


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    before=inventory();old=protected();new={p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in new_files()}
    state=sha256((ROOT/'project_state.json').read_bytes()).hexdigest()
    assert state=='d610f07422ff491118a0303c4773661e96bc0d76cf73d9e1a2ec8d148c0977c8'
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(ROOT/'tools/pole_blind_validation_guard'))
    tasks=[('actual_quartic_g3_and_candidate_evidence',[str(HERE/'audit_a10_e5_quartic_g3.py')],ROOT),
        ('scientific_regressions',['-m','unittest','test_a10_e5_quartic_g3','-v'],HERE),
        ('process_regressions',['-m','unittest','discover','-s','tools','-p','test_research_*.py'],ROOT),
        ('governance',['-m','unittest','discover','-s','docs/ai_research_epistemic_ladder_v1','-p','test_*.py'],ROOT),
        ('delegated_existing_e5',['tools/research_check.py','e5'],ROOT),
        ('fresh_four_controls_actual_and_comparison_routes',[str(HERE/'audit_a10_e5_quartic_g3.py'),'--fresh'],ROOT)]
    records=[];started=time.perf_counter()
    for name,args,cwd in tasks:
        print('START '+name,flush=True);tick=time.perf_counter()
        p=subprocess.Popen([sys.executable,'-B',*args],cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8')
        lines=[]
        for line in p.stdout:
            lines.append(line)
            if not line.startswith(('AUDIT ','{')):print(line,end='',flush=True)
        code=p.wait();output=''.join(lines)
        records.append({'name':name,'command':[sys.executable,'-B',*args],'exit_code':code,'expected_exit_code':0,'seconds':time.perf_counter()-tick,'stdout_and_stderr':output})
        print('DONE '+name+' '+str(code),flush=True);assert code==0,records[-1]
    counts={n:int(re.search(r'Ran (\d+) tests?',next(r['stdout_and_stderr'] for r in records if r['name']==n)).group(1)) for n in ['scientific_regressions','process_regressions','governance']}
    events=[json.loads(line) for line in next(r['stdout_and_stderr'] for r in records if r['name']=='delegated_existing_e5').splitlines()]
    assert events[-1]['execution_state']=='COMPLETED' and events[-1]['scientific_acceptance']=='NOT_PERFORMED'
    custody=next(e for e in events if e.get('step')=='historical_custody' and e['event']=='step_finished')
    assert custody['exit_code']==2 and custody['stdout'].count('RECORDED_DIGEST_UNRESOLVED:')==7
    fresh=json.loads(next(line[6:] for line in records[-1]['stdout_and_stderr'].splitlines() if line.startswith('AUDIT ')))
    assert len(fresh['fresh_routes'])==4 and all(v['start_identical'] and v['own_bytes_identical'] for v in fresh['fresh_routes'])
    assert fresh['scientific_disposition']==read(OUT/'comparison.json')['status'] and fresh['candidate_match']==read(OUT/'comparison.json')['match']
    after=inventory();changes=sorted(n for n in before.keys()|after.keys() if before.get(n)!=after.get(n))
    assert not changes and protected()==old
    assert {p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in new_files()}==new
    assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==state
    print('RECEIPT '+json.dumps({'schema':'E5_QUARTIC_G3_VALIDATION_V1','status':'PASS_BOUNDED_QUARTIC_G3_EVIDENCE_VALIDATION_ONLY',
        'scientific_disposition':fresh['scientific_disposition'],'quartic_g3_summary':fresh,'tasks':records,'test_counts':counts,'targeted_tests':sum(counts.values()),
        'fresh_routes_byte_identical':4,'predecessor_chains_authenticated':41,'protected_byte_sha256':old,'new_sha256':new,'state_sha256':state,
        'audit_time_changes':changes,'metadata_records':len(before),'metadata_inventory_kind':'size_and_mtime_not_whole_environment_byte_audit',
        'wall_seconds':time.perf_counter()-started,'historical_custody_exit':2,'unresolved_historical_references':7,
        'old_expensive_scientific_replays_run':False,'failed_attempts_counted_as_PASS':0,'actual_quartic_g3_loop_run':True,'candidate_selected_quartic_g3_gate_PASS':fresh['candidate_match'],
        'normalization_adopted':False,'physical_parameters_fitted':False,'full_E5_or_quantum_A5':False,'whole_goal_complete':False,'authority':'34/39_UNCHANGED'},sort_keys=True,separators=(',',':')),flush=True)


if __name__=='__main__':main()
