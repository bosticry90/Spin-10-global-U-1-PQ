"""Exact continuum-jet BV comparator. Stdout only; never modifies M08.

All columns come from Euler variation of one declared action. The existing
exterior engine is reused; the replay has a separate word/variation engine.
"""
from __future__ import annotations

import itertools
import json
import sympy as s
from source_convention_control import Exterior, Checks

ETA = (1, -1, -1, -1)
FIELDS = {**{f"V{m}": (1, 0, 0) for m in range(4)},
          "u": (1, 1, 1), "bar": (1, -1, 1), "Lambda": (2, 0, 0)}
PAIRS = [(f"V{m}", f"KV{m}") for m in range(4)] + [("u", "Lu"), ("bar", "Kbar"), ("Lambda", "KL")]
GRADES = {**FIELDS, **{j: (3-FIELDS[z][0], -1-FIELDS[z][1], 1-FIELDS[z][2]) for z, j in PAIRS}}


class Jets:
    """Symmetric ordinary jets, created on demand; exceeding a limit raises.

    The limit is a computation safeguard, NOT an algebraic zero/truncation.
    """
    def __init__(self, limit=6):
        self.a = Exterior()
        self.meta = {}
        self.values = {}
        self.limit = limit
        self.max_order = 0
        for base in GRADES:
            self.var(base)

    def var(self, base, indices=()):
        indices = tuple(sorted(indices))
        if len(indices) > self.limit:
            raise RuntimeError("JET_LIMIT_REACHED_NOT_TRUNCATED")
        name = base + ("__" + "".join(map(str, indices)) if indices else "")
        if name not in self.meta:
            self.meta[name] = (base, indices)
            self.values[name] = self.a.variable(name, GRADES[base][2])
            self.max_order = max(self.max_order, len(indices))
        return self.values[name]

    def support(self, p):
        names = {n for w in p for n in w}
        symbols = set().union(*(c.free_symbols for c in p.values())) if p else set()
        names.update(str(x) for x in symbols if str(x) in self.meta)
        return sorted(names)

    def D(self, p, mu):
        images = {n: self.var(self.meta[n][0], self.meta[n][1]+(mu,)) for n in self.support(p)}
        return self.a.derive(p, images, parity=0)

    def multiD(self, p, indices):
        for mu in indices:
            p = self.D(p, mu)
        return p

    def box(self, p):
        return self.a.add(*(self.a.scale(self.D(self.D(p, m), m), ETA[m]) for m in range(4)))

    def euler(self, p, base, side="left"):
        result = {}
        for n in self.support(p):
            z, indices = self.meta[n]
            if z == base:
                term = self.multiD(self.a.partial(p, n, side), indices)
                result = self.a.add(result, self.a.scale(term, (-1)**len(indices)))
        return result

    def bracket(self, f, g, pairs=PAIRS):
        a = self.a
        return a.add(*(a.scale(a.add(
            a.mul(self.euler(f, z, "right"), self.euler(g, j)),
            a.scale(a.mul(self.euler(f, j, "right"), self.euler(g, z)), -1)),
            (-1)**GRADES[z][2]) for z, j in pairs))

    def columns(self, action, pairs=PAIRS):
        return {n: self.bracket(action, self.var(n), pairs) for pair in pairs for n in pair}

    def Q(self, p, base_images):
        images = {n: self.multiD(base_images.get(self.meta[n][0], {}), self.meta[n][1]) for n in self.support(p)}
        return self.a.derive(p, images)

    def div(self, currents):
        return self.a.add(*(self.D(currents[m], m) for m in range(4)))

    def transport(self, p, shifts, sign=1):
        """Substitute all sources and their jets; finite source-degree expansion."""
        a, result = self.a, {}
        names = self.support(p)
        images = {n: a.add(self.values[n], a.scale(self.multiD(shifts.get(self.meta[n][0], {}), self.meta[n][1]), sign)) for n in names}
        even = [a.even_symbols[n] for n in names if not a.parity[n]]
        for word, coefficient in p.items():
            monomials = s.Poly(coefficient, *even).terms() if even else [((), coefficient)]
            for powers, c in monomials:
                term = {(): c}
                for x, power in zip(even, powers):
                    for _ in range(power):
                        term = a.mul(term, images[str(x)])
                term = a.mul(term, *(images[n] for n in word))
                result = a.add(result, term)
        return result

    def homogeneous_grade(self, p, grade):
        """Check each exact even monomial and exterior word separately."""
        for word, coefficient in p.items():
            even = sorted((x for x in coefficient.free_symbols if str(x) in self.meta), key=str)
            monomials = s.Poly(coefficient, *even).terms() if even else [((), coefficient)]
            for powers, _ in monomials:
                factors = list(word) + [str(x) for x, power in zip(even, powers) for _ in range(power)]
                d = gh = parity = 0
                for n in factors:
                    base, indices = self.meta[n]
                    dg, gg, pg = GRADES[base]
                    d, gh, parity = d+dg+len(indices), gh+gg, (parity+pg) % 2
                if (d, gh, parity) != grade:
                    return False
        return True


def setup(partner_sign=-1):
    j = Jets()
    a, x, xi = j.a, {n: j.var(n) for n in GRADES}, s.Symbol("xi")
    curvature = {(m, n): a.add(j.D(x[f"V{n}"], m), a.scale(j.D(x[f"V{m}"], n), -1)) for m in range(4) for n in range(4)}
    kinetic = a.add(*(a.scale(a.mul(f, f), -s.Rational(1, 4)*ETA[m]*ETA[n]) for (m, n), f in curvature.items()))
    divV = a.add(*(a.scale(j.D(x[f"V{m}"], m), ETA[m]) for m in range(4)))
    gf = a.add(a.scale(a.mul(x["bar"], j.box(x["u"])), -1),
               a.scale(a.mul(x["Lambda"], divV), -1), a.scale(a.mul(x["Lambda"], x["Lambda"]), xi/2))
    minimal = a.add(kinetic, *(a.mul(x[f"KV{m}"], j.D(x["u"], m)) for m in range(4)),
                    a.scale(a.mul(x["Kbar"], x["Lambda"]), partner_sign))
    psi = a.mul(x["bar"], a.add(divV, a.scale(x["Lambda"], -xi/2)))
    return j, x, kinetic, gf, minimal, psi


def build():
    if not __debug__:
        raise RuntimeError("EXACT_COMPARATOR_REQUIRES_ASSERTIONS_ENABLED")
    j, x, kinetic, gf, minimal, psi = setup()
    a, checks = j.a, Checks()
    action = a.add(minimal, gf)

    # Reproduce the old operation BEFORE testing the complete pairing.
    old_action = a.add(action, a.mul(x["Kbar"], x["Lambda"]))
    old_pairs = [pair for pair in PAIRS if pair[0] != "bar"]
    old_Q = j.columns(old_action, old_pairs)
    old_Q["bar"] = a.scale(x["Lambda"], -1)
    old_square = j.Q(old_Q["KL"], old_Q)
    checks.equal(a, old_square, a.scale(j.box(x["u"]), -1), "old -box(u) retained")
    old_pair_square = j.Q(j.Q(a.mul(x["KL"], x["Lambda"]), old_Q), old_Q)
    checks.equal(a, old_pair_square, a.scale(a.mul(x["Lambda"], j.box(x["u"])), -1), "old witness square")

    Q, Qmin = j.columns(action), j.columns(minimal)
    checks.true(len(Q) == 14, "all fourteen images materialized")
    for n, p in Q.items():
        d, gh, parity = GRADES[n]
        checks.true(j.homogeneous_grade(p, (d+1, gh+1, 1-parity)), "column grading "+n)
    checks.true(j.homogeneous_grade(action, (4, 0, 0)), "master action grading")
    checks.true(j.homogeneous_grade(psi, (3, -1, 1)), "gauge fermion grading")
    checks.equal(a, Q["bar"], a.scale(x["Lambda"], -1), "canonical antighost image")
    checks.equal(a, Q["Kbar"], a.scale(j.box(x["u"]), -1), "canonical partner image")
    checks.equal(a, Q["KL"], a.add(old_Q["KL"], a.scale(x["Kbar"], -1)), "derived source correction")
    # Every jet through order two, including mixed derivatives, not a mode sample.
    square_count = 0
    for n in GRADES:
        for order in range(3):
            for indices in itertools.combinations_with_replacement(range(4), order):
                checks.zero(j.Q(j.Q(j.var(n, indices), Q), Q), "off-shell square "+n+str(indices))
                square_count += 1
        checks.zero(j.Q(Qmin[n], Qmin), "ungauge-fixed square "+n)
        for mu in range(4):
            checks.equal(a, j.Q(j.D(x[n], mu), Q), j.D(Q[n], mu), "derivative prolongation")
    for n, m in itertools.product(GRADES, repeat=2):
        checks.equal(a, j.Q(a.mul(x[n], x[m]), Q), a.add(a.mul(Q[n], x[m]), a.scale(a.mul(x[n], Q[m]), (-1)**GRADES[n][2])), "left Leibniz")

    maxwell_euler = [j.euler(kinetic, f"V{m}") for m in range(4)]
    checks.zero(j.div(maxwell_euler), "Maxwell differential identity without EOM")
    current = [a.add(a.mul(maxwell_euler[m], x["u"]), a.scale(a.mul(x["Lambda"], j.D(x["u"], m)), ETA[m])) for m in range(4)]
    half_master = a.scale(j.bracket(action, action), s.Rational(1, 2))
    checks.equal(a, half_master, j.div(current), "master equation explicit total derivative")
    for n in GRADES:
        checks.zero(j.euler(half_master, n), "master Euler residual "+n)
    # The old ST scalar also vanishes modulo the SAME current, despite Q squared.
    old_half = a.scale(j.bracket(old_action, old_action, old_pairs), s.Rational(1, 2))
    old_T = j.Q(old_action, {"bar": a.scale(x["Lambda"], -1)})
    checks.equal(a, a.add(old_half, old_T), j.div(current), "old ST cancellation retained")
    T = {"bar": a.scale(x["Lambda"], -1)}
    derivation_defect = a.add(j.Q(j.bracket(x["bar"], x["KL"], old_pairs), T),
                              a.scale(j.bracket(T["bar"], x["KL"], old_pairs), -1))
    checks.equal(a, derivation_defect, {(): s.Integer(1)}, "old noncanonical bracket defect retained")
    for z, source in PAIRS:
        star = a.scale(x[source], (-1)**GRADES[z][2])
        checks.equal(a, j.bracket(x[z], star), {(): s.Integer(1)}, "canonical antifield coordinate map")
        checks.equal(a, j.bracket(star, x[z]), {(): s.Integer(-1)}, "canonical inverse bracket orientation")

    shifts = {n: a.scale(j.bracket(psi, x[n]), -1) for n in GRADES}
    checks.equal(a, j.Q(psi, Qmin), gf, "gauge fixing from declared fermion")
    transported = j.transport(minimal, shifts)
    shift_current = [a.scale(a.mul(x["bar"], j.D(x["u"], m)), ETA[m]) for m in range(4)]
    checks.equal(a, a.add(transported, a.scale(action, -1)), j.div(shift_current), "canonical action shift modulo explicit IBP")
    for n in GRADES:
        checks.true(j.homogeneous_grade(shifts[n], GRADES[n]), "shift grading "+n)
        for sign in (1, -1):
            checks.equal(a, j.transport(j.transport(x[n], shifts, sign), shifts, -sign), x[n], "inverse shift "+n)
        checks.equal(a, j.Q(j.transport(x[n], shifts), Q), j.transport(Qmin[n], shifts), "differential intertwining "+n)
    checks.equal(a, j.transport(j.transport(minimal, shifts), shifts, -1), minimal, "full action inverse")
    F = a.mul(x["KL"], x["Lambda"])
    checks.zero(j.Q(j.Q(F, Q), Q), "original functional witness repaired off-shell")
    checks.true(bool(j.euler(a.mul(x["Lambda"], j.box(x["u"])), "Lambda")), "old witness not IBP null")

    # Retain exact failure when the new partner is omitted or gets the wrong sign.
    checks.true(bool(Q["Kbar"]), "Kbar=0 not a Q-invariant off-shell restriction")
    wrong_j, wrong_x, _, wrong_gf, wrong_min, _ = setup(partner_sign=1)
    wrong_Q = wrong_j.columns(wrong_j.a.add(wrong_min, wrong_gf))
    checks.equal(wrong_j.a, wrong_Q["bar"], wrong_x["Lambda"], "wrong source sign changes forward rule")
    projected_KL = a.add(Q["KL"], x["Kbar"])
    checks.equal(a, j.Q(projected_KL, old_Q), a.scale(j.box(x["u"]), -1), "omitted source restores defect")

    rec = a.record
    return {"schema": "NONMINIMAL_BV_FREE_COMPARATOR_V1",
            "disposition": "QUALIFIED_FREE_COMPARATOR_ONLY_NOT_M08_REPLACEMENT",
            "metric": list(ETA), "base_generator_count": len(GRADES), "canonical_pair_count": len(PAIRS),
            "grades": {n: list(g) for n, g in GRADES.items()},
            "actions": {"free_gauge_kinetic": rec(kinetic), "free_gauge_fixing": rec(gf), "minimal_nonminimal_master": rec(minimal), "gauge_fixed_master": rec(action), "gauge_fermion": rec(psi)},
            "images": {n: rec(Q[n]) for n in GRADES},
            "old_failure": {"Q2_KL": rec(old_square), "Q2_KL_Lambda": rec(old_pair_square), "ST_minus_total_derivative": [], "old_noncanonical_bracket_derivation_defect": rec(derivation_defect)},
            "master": {"half_master_density": rec(half_master), "total_derivative_current": [rec(p) for p in current], "Euler_residuals_all_zero": True, "EOM_used": False},
            "squares": {"base_and_jets_through_order_two_checked": square_count, "all_exact_zero": True, "original_pairing_exact_zero": True, "maximum_jet_order_encountered": j.max_order, "truncation_used": False},
            "transport": {"direction": "U=exp(-ad_psi); J shifts by -(-1)^p Euler_left(psi,z)", "shifts": {n: rec(shifts[n]) for n in GRADES}, "inverse": "psi -> -psi", "inverse_and_intertwining_exact": True, "action_difference_current": [rec(p) for p in shift_current], "source_coordinate_map": "z_star=(-1)^p J; inverse J=(-1)^p z_star", "full_M08_transport_claimed": False},
            "negative_controls": {"Kbar_zero_is_Q_invariant": False, "Q_Kbar_at_Kbar_zero": rec(Q["Kbar"]), "omitted_partner_restores_minus_box_u": True, "flipped_partner_sign_changes_Qbar": True, "old_witness_is_not_IBP_null": True},
            "exact_assertion_count": checks.count, "M08_changed": False, "HB1_C5_authorized": False,
            "cochain_rank_cohomology_computed": False, "external_specialist_review": False}


if __name__ == "__main__":
    print(json.dumps(build(), sort_keys=True, separators=(",", ":")))
