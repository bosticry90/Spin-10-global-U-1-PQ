"""Independent word/functional-variation interacting control; stdout only.

No primary model, transformation column, action or output is imported.
Model/bracket conventions, Python/SymPy and the earlier word engine are shared.
"""
import json
import sympy as s
from nonminimal_bv_free_replay import Words


class ControlWords(Words):
    def __init__(self):
        self.p={**{f"A{k}{m}":0 for k in range(3) for m in range(4)},
                **{f"p{k}":0 for k in range(3)},**{f"c{k}":1 for k in range(3)},
                **{f"bar{k}":1 for k in range(3)},**{f"b{k}":0 for k in range(3)}}
        fields=list(self.p); self.pairs=[(z,"J"+z) for z in fields]
        self.p.update({j:1-self.p[z] for z,j in self.pairs}); self.max_jet=0

    def columns(self,S):
        return {n:self.EL(S,other) for pair in self.pairs for n,other in (pair,pair[::-1])}

    def boundary(self,P):
        """Independent monomial integration-by-parts scaling homotopy."""
        current=[{} for _ in range(4)]
        for word,coefficient in P.items():
            if not word: raise AssertionError("CONSTANT_CANNOT_BE_DISCARDED")
            for pos,(name,indices) in enumerate(word):
                # Left variation brings the varied factor past the prefix.
                sign=(-1)**(self.p[name]*sum(self.p[n] for n,_ in word[:pos]))
                rest={word[:pos]+word[pos+1:]:coefficient*sign/s.Integer(len(word))}
                for cut,mu in enumerate(indices):
                    term=self.scale(self.mul(self.var(name,indices[cut+1:]),self.dword(rest,indices[:cut])),(-1)**cut)
                    current[mu]=self.add(current[mu],term)
        if self.add(self.add(*(self.D(t,m) for m,t in enumerate(current))),self.scale(P,-1)):
            raise AssertionError("INDEPENDENT_BOUNDARY_RECONSTRUCTION_FAILED")
        return current

    @staticmethod
    def record(P):
        rows=Words.record(P)
        return sorted(rows,key=lambda row:tuple(row["word"]))


def build(stage=None):
    if not __debug__: raise RuntimeError("REPLAY_REQUIRES_ASSERTIONS")
    if stage is None: stage=lambda name,fn:fn()
    w=ControlWords(); x={n:w.var(n) for n in w.p}
    g,h,xi,v=s.symbols("g h xi v"); metric=(1,-1,-1,-1)
    def cross(left,right):
        # Cyclic components rather than the primary epsilon summation.
        return [w.add(w.mul(left[(k+1)%3],right[(k+2)%3]),w.scale(w.mul(left[(k+2)%3],right[(k+1)%3]),-1)) for k in range(3)]
    def dot(left,right): return w.add(*(w.mul(l,r) for l,r in zip(left,right)))
    A=[[x[f"A{k}{m}"] for k in range(3)] for m in range(4)]
    phi=[x[f"p{k}"] for k in range(3)]; eta=[phi[0],phi[1],w.add(phi[2],{():v})]
    c=[x[f"c{k}"] for k in range(3)]; bar=[x[f"bar{k}"] for k in range(3)]; b=[x[f"b{k}"] for k in range(3)]
    kinetic={}; curvature={}
    for m in range(4):
        for n in range(m+1,4):
            comm=cross(A[m],A[n])
            f=[w.add(w.D(A[n][k],m),w.scale(w.D(A[m][k],n),-1),w.scale(comm[k],g)) for k in range(3)]
            curvature[m,n]=f
            kinetic=w.add(kinetic,w.scale(dot(f,f),-metric[m]*metric[n]/s.Integer(2)))
    cov=[]; scalar={}
    for m in range(4):
        ae=cross(A[m],eta)
        y=[w.add(w.D(eta[k],m),w.scale(ae[k],g)) for k in range(3)]; cov.append(y)
        scalar=w.add(scalar,w.scale(dot(y,y),metric[m]/s.Integer(2)))
    r=w.add(dot(eta,eta),{():-v*v}); potential=w.scale(w.mul(r,r),h/4)
    S0=w.add(kinetic,scalar,w.scale(potential,-1))
    forward={}
    for m in range(4):
        ac=cross(A[m],c)
        for k in range(3): forward[f"A{k}{m}"]=w.add(w.D(c[k],m),w.scale(ac[k],g))
    ce,cc=cross(c,eta),cross(c,c)
    for k in range(3):
        forward[f"p{k}"]=w.scale(ce[k],-g); forward[f"c{k}"]=w.scale(cc[k],-g/2)
        forward[f"bar{k}"]=w.scale(b[k],-1); forward[f"b{k}"]={}
    Smin=w.add(S0,*(w.mul(x[j],forward[z]) for z,j in w.pairs))
    Qmin=stage("word_minimal_Euler_columns",lambda:w.columns(Smin))
    vev=[{}, {}, {():v}]; gold=cross(vev,phi)
    div=[w.add(*(w.scale(w.D(A[m][k],m),metric[m]) for m in range(4))) for k in range(3)]
    G=[w.add(div[k],w.scale(gold[k],-xi*g)) for k in range(3)]
    psi=dot(bar,[w.add(G[k],w.scale(b[k],-xi/2)) for k in range(3)])
    gf=w.Q(psi,Qmin); S=w.add(Smin,gf)
    Q=stage("word_gauge_fixed_Euler_columns",lambda:w.columns(S))
    for z in forward:
        assert Q[z]==forward[z]==Qmin[z],"forward "+z
    for m in range(4):
        expected=cross(c,cov[m])
        for k in range(3): assert w.Q(cov[m][k],Q)==w.scale(expected[k],-g)
    for f in curvature.values():
        expected=cross(c,f)
        for k in range(3): assert w.Q(f[k],Q)==w.scale(expected[k],-g)
    assert w.Q(S0,Q)==w.Q(potential,Q)=={}
    def squares():
        count=0
        for n in w.p:
            assert w.Q(Qmin[n],Qmin)=={},"minimal square "+n
            assert w.Q(Q[n],Q)=={},"square "+n; count+=2
            for mu in range(4):
                assert w.Q(w.D(x[n],mu),Q)==w.D(Q[n],mu)
                assert w.Q(w.Q(w.var(n,(mu,)),Q),Q)=={},"first jet square "+n; count+=1
        return count
    count=stage("word_complete_squares",squares)
    def master():
        result={}
        for label,L,images in (("minimal",Smin,Qmin),("gauge_fixed",S,Q)):
            half=w.add(*(w.mul(w.EL(L,z),images[z]) for z,_ in w.pairs))
            assert all(w.EL(half,n)=={} for n in w.p),"master Euler "+label
            current=w.boundary(half)
            result[label]={"half_density":w.record(half),"current":[w.record(t) for t in current],"all_Euler_residuals_zero":True}
        return result
    masters=stage("word_master_and_boundary",master)
    def shift():
        shifts={j:w.scale(w.EL(psi,z),-(-1)**w.p[z]) for z,j in w.pairs}
        pos={n:w.add(x[n],shifts.get(n,{})) for n in w.p}
        neg={n:w.add(x[n],w.scale(shifts.get(n,{}),-1)) for n in w.p}
        transformed=w.replace(Smin,pos); diff=w.add(transformed,w.scale(S,-1)); current=w.boundary(diff)
        for n in w.p:
            assert w.replace(w.replace(x[n],pos),neg)==x[n]
            assert w.Q(w.replace(x[n],pos),Q)==w.replace(Qmin[n],pos),"intertwining "+n
        assert w.replace(transformed,neg)==Smin
        return {"shifts":{n:w.record(shifts.get(n,{})) for n in w.p},"action_difference_current":[w.record(t) for t in current]}
    transport=stage("word_canonical_shift",shift)
    # Left odd differentiation: the antighost contributes -bar QG.
    expected_mass=w.scale(w.add(w.mul(bar[0],c[0]),w.mul(bar[1],c[1])),-xi*g*g*v*v)
    ghost_mass={word:co for word,co in gf.items() if all(n in ["bar0","bar1","bar2","c0","c1","c2"] and not I for n,I in word)}
    assert ghost_mass==expected_mass
    zero={n:{} for n in w.p}
    gauge_mass=[]; scalar_mass=[]
    for k in range(3):
        grow=[]; srow=[]
        for l in range(3):
            gm=w.replace(w.EL(w.EL(S0,f"A{k}0"),f"A{l}0"),zero)
            # Euler derivatives of S0 include kinetic terms; on a constant
            # vacuum those derivatives vanish, leaving the algebraic Hessian.
            sm=w.replace(w.EL(w.EL(potential,f"p{k}"),f"p{l}"),zero)
            assert gm==({():g*g*v*v} if k==l and k<2 else {})
            assert sm==({():2*h*v*v} if k==l==2 else {})
            grow.append(str(gm.get((),0))); srow.append(str(sm.get((),0)))
        gauge_mass.append(grow); scalar_mass.append(srow)
    goldstone=[w.scale(t,-g) for t in cross(c,vev)]
    for k in range(3):
        assert w.replace(Q[f"p{k}"],{f"p{i}":{} for i in range(3)})==goldstone[k]
    mixing=w.add(*(w.scale(dot(A[m],[w.D(t,m) for t in gold]),g*metric[m]) for m in range(4)))
    mixing_current=[w.scale(dot(A[m],gold),g*metric[m]) for m in range(4)]
    assert w.add(mixing,w.scale(dot(div,gold),g))==w.add(*(w.D(t,m) for m,t in enumerate(mixing_current)))
    bad=dict(Q); bad.update({f"p{k}":w.scale(Q[f"p{k}"],-1) for k in range(3)})
    scalar_bad=w.Q(bad["p0"],bad); assert scalar_bad
    broken=w.add(S,*(w.mul(x[f"Jbar{k}"],b[k]) for k in range(3)))
    old={n:w.EL(broken,other) for pair in w.pairs if not pair[0].startswith("bar") for n,other in (pair,pair[::-1])}
    old.update({f"bar{k}":w.scale(b[k],-1) for k in range(3)})
    square=w.Q(old["Jb0"],old)
    free={word:s.expand(co.subs({g:0})) for word,co in square.items() if s.expand(co.subs({g:0}))!=0}
    box=w.add(*(w.scale(w.D(w.D(c[0],m),m),-metric[m]) for m in range(4)))
    assert free==box and Q["Jbar0"]
    flipped=w.add(S,w.scale(w.mul(x["Jbar0"],b[0]),2))
    wrong_bar=w.EL(flipped,"Jbar0"); assert wrong_bar==b[0]
    return {"schema":"INTERACTING_BV_PREFLIGHT_REPLAY_V1","base_generator_count":len(w.p),"canonical_pair_count":len(w.pairs),
        "actions":{"invariant":w.record(S0),"minimal_master":w.record(Smin),"gauge_fermion":w.record(psi),"gauge_fixing":w.record(gf),"gauge_fixed_master":w.record(S)},
        "minimal_images":{n:w.record(Qmin[n]) for n in w.p},"images":{n:w.record(Q[n]) for n in w.p},
        "master":masters,"transport":transport,"square_count":count,"all_squares_exact_zero":True,"maximum_jet_order":w.max_jet,
        "Goldstone_images":[w.record(t) for t in goldstone],"mixing_current":[w.record(t) for t in mixing_current],"ghost_mass_density":w.record(ghost_mass),"gauge_mass_squared_matrix":gauge_mass,"scalar_potential_Hessian":scalar_mass,
        "negative_controls":{"wrong_positive_scalar_square":w.record(scalar_bad),"omitted_partner_free_square":w.record(free),"flipped_source_Qbar":w.record(wrong_bar)},
        "EOM_used":False,"independence":{"ALGORITHM_INDEPENDENT":True,"CODE_PATH_INDEPENDENT":True,"LIBRARY_INDEPENDENT":False,"RUNTIME_INDEPENDENT":False,"primary_columns_imported":False,"analyst_blind":False,"external_specialist_review":False,"shared_assumptions":"declared model and canonical bracket; Python/SymPy; earlier ordered-word polynomial engine"}}


if __name__=="__main__": print(json.dumps(build(),sort_keys=True,separators=(",",":")))
