"""Domain closure, missing-class witness and explicit scientific ceiling."""
import unittest
from a10_e5_domain_common import *
from audit_a10_e5_domain import adjudicate


class E5DomainTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.a,cls.b=read(OUT/'primary.json'),read(OUT/'replay.json')
    def test_independent_bounded_stop_agreement(self):
        self.assertEqual(adjudicate(self.a,self.b)['scientific_gate'],STATUS)
    def test_complete_contraction_and_Cartan_coverage(self):
        self.assertEqual(len(self.a['alphabet_grades']),1286)
        self.assertEqual(self.a['Cartan_generator_checks'],1286)
        self.assertEqual(self.a['contraction_square_checks'],1286)
    def test_local_jets_and_background_covariance(self):
        self.assertEqual(self.a['first_jet_Cartan_checks'],1286)
        self.assertEqual(self.a['background_covariance_field_checks'],643)
    def test_source_transport_and_joint_domain(self):
        self.assertEqual(len(self.a['transported_contraction_columns']),1286)
        self.assertIn('Tq_transported',self.a['domain'])
        self.assertFalse(self.a['restricted_607_domain_equivalence_proved'])
    def test_domain_not_trivially_zero(self):
        self.assertTrue(self.a['nontrivial_basic_source'])
        self.assertTrue(self.a['nontrivial_basic_source_image'])
    def test_permitted_exact_counterterm_not_literal_basic(self):
        self.assertTrue(self.a['counterterm_is_BRST_exact'])
        self.assertEqual(self.a['counterterm_grade'],[4,0,0])
        self.assertTrue(self.a['counterterm_horizontality_defect'])
    def test_nonboundary_free_source_witness(self):
        self.assertEqual(self.a['free_Euler_witness'],[{'word':['omega0__0'],'coefficient':'1'}])
        w=alphabet()
        # Explicit left variation after IBP of -(partial JB) omega.
        P=w.scale(w.mul(w.D(w.var('JB0_0'),0),w.var('omega0')),-1)
        self.assertEqual(canonical(w.EL(P,'JB0_0')),w.D(w.var('omega0'),0))
    def test_omitted_nonminimal_correction_control(self):
        self.assertTrue(self.a['omitted_light_correction_control']['residual'])
    def test_initial_wrong_sign_expectation_preserved_excluded(self):
        x=read(OUT/'initial_free_sign_incident.json')
        self.assertTrue(x['excluded_from_final_qualification'])
        self.assertEqual(read(OUT/'initial_free_sign_primary.json'),read(OUT/'initial_free_sign_replay.json'))
    def test_no_false_E5_promotion_or_catalog_authorization(self):
        bad=dict(self.a,E5_full_PASS=True)
        with self.assertRaises(AssertionError):adjudicate(bad,dict(self.b,E5_full_PASS=True))
        self.assertFalse(self.a['catalog_generated']);self.assertEqual(self.a['authority'],'34/39_UNCHANGED')


if __name__=='__main__':unittest.main()
