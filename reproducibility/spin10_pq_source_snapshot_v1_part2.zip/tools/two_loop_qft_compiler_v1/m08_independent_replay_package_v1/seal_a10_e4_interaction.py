"""Seal validated E4 and process additions; formal scientific authority stays frozen."""
from a10_e4_interaction_common import *
import json,subprocess,sys

FILES=('A10_E4_INTERACTION_CONTRACT_V1.md','A10_E4_INTERACTION_RESULT.md',
    'A10_E4_INTERACTION_TECHNICAL_REVIEW_PACKET_V1.md','a10_e4_interaction_common.py',
    'a10_e4_interaction_primary.py','a10_e4_interaction_replay.py','a10_e4_interaction_checks.py',
    'audit_a10_e4_interaction.py','run_a10_e4_interaction.py','export_a10_e4_interaction.py',
    'test_a10_e4_interaction.py','validate_a10_e4_interaction.py','export_a10_e4_receipt.py',
    'seal_a10_e4_interaction.py')
PROCESS_FILES=('AGENTS.md','docs/AGENTIC_ENGINEERING_GAP_ANALYSIS_V1.md',
    'docs/RESEARCH_EXECUTION_HANDOFF_V1.md','docs/AGENTIC_ENGINEERING_INCORPORATION_RESULT_V1.md',
    'docs/A10_E4_INTERACTION_CURRENT.md','tools/research_session_preflight.py',
    'tools/test_research_session_preflight.py','tools/test_research_validation_io.py')
LIVE_PROCESS_FILES=('AGENTS.md','tools/research_session_preflight.py',
    'tools/test_research_session_preflight.py','tools/test_research_validation_io.py')


def files(include_receipt=True):
    return [HERE/n for n in FILES]+[ROOT/n for n in PROCESS_FILES]+sorted(p for p in OUT.iterdir()
        if p.is_file() and p.name!='bindings.json' and (include_receipt or p.name!='validation_receipt.json'))


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    assert not (OUT/'bindings.json').exists(),'ALREADY_SEALED'
    if '--process-snapshot' in sys.argv:
        snapshot={'schema':'RESEARCH_PROCESS_IMPLEMENTATION_SNAPSHOT_V1',
            'live_tools_are_scientific_dependencies':False,
            'reason':'authenticate the tested process version without freezing mutable repository instructions into a scientific dependency',
            'files':{n:{'sha256':sha256((ROOT/n).read_bytes()).hexdigest(),
                'utf8':(ROOT/n).read_text(encoding='utf-8')} for n in LIVE_PROCESS_FILES}}
        (OUT/'process_snapshot.json').write_bytes(json.dumps(snapshot,sort_keys=True,separators=(',',':')).encode()+b'\n')
        print('EXPORTED tested process snapshot; live process tooling is separate from frozen physics',flush=True)
        return
    receipt=read(OUT/'validation_receipt.json')
    assert receipt['scientific_gate']==STATUS and receipt['targeted_regression_tests']==209
    assert receipt['fresh_new_routes_byte_identical']==3 and not receipt['audit_time_changes']
    assert receipt['historical_custody_exit']==2 and receipt['unresolved_historical_references']==7
    assert receipt['new_bytes_unchanged'] and not receipt['E5_executed']
    state=sha256((ROOT/'project_state.json').read_bytes()).hexdigest()
    assert state==receipt['live_state_transaction_sha256']
    for n,h in receipt['audit_time_code_and_output_sha256'].items():
        assert sha256((ROOT/n).read_bytes()).hexdigest()==h,('POST_VALIDATION_CHANGED',n)
    from audit_a10_e4_interaction import authenticate
    assert authenticate()['scientific_gate']==STATUS
    bounded=files()
    for p in bounded:
        raw=p.read_bytes();assert b'\r\n' not in raw and raw.endswith(b'\n') and not raw.endswith(b'\n\n'),str(p)
    base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    assert base=='1dc61f001c02e634c3cfeb7e2aac18fecd39678f','BASE_CHANGED'
    permanent=[p for p in bounded if p.relative_to(ROOT).as_posix() not in LIVE_PROCESS_FILES]
    snapshot=read(OUT/'process_snapshot.json')
    for n,row in snapshot['files'].items():
        assert row['utf8'].encode()==(ROOT/n).read_bytes() and row['sha256']==sha256((ROOT/n).read_bytes()).hexdigest()
    result={'schema':'A10_E4_AND_PROCESS_BYTE_BINDINGS_V1','base_commit':base,
        'byte_sha256':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in permanent},
        'inherited_manifest_sha256':{(HERE/n/'bindings.json').relative_to(ROOT).as_posix():
            sha256((HERE/n/'bindings.json').read_bytes()).hexdigest() for n in PREDECESSORS},
        'state_sha256':state,'scientific_disposition':STATUS,'authority_changed':False,
        'sources_activated':False,'candidate_adopted':False,'E5_executed':False,'Stage_D_E3_modified':False,
        'catalog_rebuilt':False,'HB1_C5_run':False,'C1_GS_calculated':False,'personal_outreach':False,
        'external_endorsement':False,'remote_push':False,
        'post_validation_finalization':'receipt export and byte sealing only; no scientific edits'}
    (OUT/'bindings.json').write_bytes(json.dumps(result,sort_keys=True,separators=(',',':')).encode()+b'\n')
    print('SEALED '+str(len(bounded))+' E4/process files',flush=True)


if __name__=='__main__':main()
