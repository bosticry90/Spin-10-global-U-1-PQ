"""Read-only measured calculation runner; results and metrics go to stdout."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_phase_c_scalar_action  # Establish the existing counter-library path.

# Keep the established process counters and write-denial implementation but
# extend its route whitelist only in this separately scoped runner.
def main():
    import importlib, json, os, time
    from profile_pole_blind_workflow import process_counters
    assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED')
    route = sys.argv[1]
    assert route in ('a10_covariant_phi_control', 'a10_covariant_phi_replay',
                     'a10_physical_reconciliation', 'a10_physical_reconciliation_replay')
    reads = set(); writes = []
    def hook(event, args):
        if event != 'open' or not isinstance(args[0], (str, bytes)): return
        path = Path(os.fsdecode(args[0])); mode = args[1] or ''; flags = args[2] if len(args) > 2 else 0
        if any(c in mode for c in 'wax+') or flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC):
            writes.append(str(path)); raise PermissionError('A10_CALCULATION_WRITES_FORBIDDEN')
        reads.add(str(path.resolve()))
    sys.addaudithook(hook)
    start = time.perf_counter(); first = process_counters(); stages = []
    def stage(name, fn):
        print('STAGE '+name, flush=True); t = time.perf_counter(); before = process_counters()
        try: return fn()
        finally:
            after = process_counters()
            stages.append({'name': name, 'wall_seconds': time.perf_counter()-t,
                           'cpu_seconds': after['cpu_seconds']-before['cpu_seconds'],
                           'peak_process_working_set_bytes': after['peak_working_set_bytes']})
    module = stage('module_import', lambda: importlib.import_module(route))
    result = module.build(stage)
    raw = stage('serialization', lambda: json.dumps(result, sort_keys=True, separators=(',', ':')))
    print('RESULT '+raw, flush=True); last = process_counters()
    print('METRICS '+json.dumps({'route': route, 'stages': stages,
        'wall_seconds': time.perf_counter()-start, 'cpu_seconds': last['cpu_seconds']-first['cpu_seconds'],
        'peak_process_working_set_bytes': last['peak_working_set_bytes'], 'read_paths': sorted(reads),
        'unique_read_files': len(reads), 'write_open_attempts': writes, 'workspace_files_written': 0,
        'os_io_read_transfer_bytes': last['os_io_read_transfer_bytes']-first['os_io_read_transfer_bytes'],
        'os_io_write_transfer_bytes': last['os_io_write_transfer_bytes']-first['os_io_write_transfer_bytes'],
        'limits': 'Read paths count accesses, not bytes; OS I/O includes runtime and pipes; peak is cumulative.'},
        sort_keys=True, separators=(',', ':')), flush=True)

if __name__ == '__main__': main()
