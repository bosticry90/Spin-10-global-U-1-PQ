"""Bounded read-only validation driver; records stdout, never writes a receipt."""
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from validate_interacting_actual_h_preflight import inventory, bound_hashes

HERE = Path(__file__).resolve().parent; ROOT = HERE.parents[2]


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'), 'DENIED')
    state = sha256((ROOT/'project_state.json').read_bytes()).hexdigest()
    before = inventory(); inherited = bound_hashes(); records = []; start = time.perf_counter()
    tasks = [
        ('phase_c_evidence_fresh_scalar_only', [str(HERE/'audit_phase_c_scalar_action.py'), '--fresh-scalar-only'], ROOT, 0),
        ('compensator_and_divergence_regressions', ['-m', 'unittest', 'test_phase_c_scalar_action', '-v'], HERE, 0),
        ('governance_regressions', ['-m', 'unittest', 'discover', '-s', 'docs/ai_research_epistemic_ladder_v1', '-p', 'test_*.py'], ROOT, 0),
        ('authority_coherence', ['tools/two_loop_qft_compiler_v1/audit_authority_coherence.py'], ROOT, 0),
        ('structure_preserving_map', ['tools/readiness/audit_structure_preserving_map_contract.py'], ROOT, 0),
        ('read_only_entrypoints', ['tools/readiness/audit_read_only_contract.py'], ROOT, 0),
        ('historical_custody_current_coherence', ['docs/ai_research_epistemic_ladder_v1/audit_epistemic_ladder.py'], ROOT, 2)]
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(ROOT/'tools/pole_blind_validation_guard'))
    for name, args, cwd, expected in tasks:
        print('START '+name, flush=True); t = time.perf_counter()
        proc = subprocess.run([sys.executable, '-B', *args], cwd=cwd, env=env,
                              capture_output=True, text=True, encoding='utf-8', errors='replace')
        record = {'name': name, 'exit_code': proc.returncode, 'expected_exit_code': expected,
                  'wall_seconds': time.perf_counter()-t, 'stdout': proc.stdout, 'stderr': proc.stderr}
        records.append(record); print('DONE '+name+' '+str(proc.returncode), flush=True)
        if proc.returncode != expected:
            print('FAILED '+json.dumps(record), flush=True); raise RuntimeError('BOUNDED_VALIDATION_FAILED_'+name)
    after = inventory()
    changes = sorted(n for n in before.keys() | after.keys() if before.get(n) != after.get(n))
    assert not changes, ('AUDIT_TIME_MUTATIONS', changes)
    assert bound_hashes() == inherited and sha256((ROOT/'project_state.json').read_bytes()).hexdigest() == state
    custody = records[-1]['stdout']
    assert custody.count('RECORDED_DIGEST_UNRESOLVED:') == 7
    print('RECEIPT '+json.dumps({'schema': 'PHASE_C_SCALAR_ACTION_VALIDATION_RECEIPT_V1',
          'status': 'PASS_BOUNDED_FAILURE_EVIDENCE_VALIDATION_ONLY',
          'scientific_gate': 'FAILED_COMPLETE_PHYSICAL_ACTION_SELECTED_CHANNEL',
          'tasks': records, 'wall_seconds': time.perf_counter()-start,
          'inherited_byte_bindings': len(inherited), 'inherited_bytes_unchanged': True,
          'workspace_active_data_metadata_records': len(before),
          'inventory_kind': 'size_and_mtime_ns_not_all_byte_audit', 'audit_time_changes': changes,
          'live_state_transaction_sha256': state, 'historical_custody_exit': 2,
          'unresolved_historical_references': 7, 'historical_original_bindings_resolved': False,
          'mixed_source_or_nonminimal_expensive_rerun': False, 'mixed_kinetic_run': False,
          'HB1_C5_run': False, 'C1_GS_calculated': False, 'T5_reconstructed': False,
          'unrestricted_all_validation_run': False, 'external_specialist_review': False,
          'formal_authority': '34/39_UNCHANGED'}, sort_keys=True, separators=(',', ':')), flush=True)


if __name__ == '__main__': main()
