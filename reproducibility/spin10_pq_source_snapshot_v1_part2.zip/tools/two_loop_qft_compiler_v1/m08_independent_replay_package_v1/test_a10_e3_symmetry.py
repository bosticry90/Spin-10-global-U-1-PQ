"""Local residual Ward, source-cotangent and full physical replay regressions."""
import unittest
from a10_e3_symmetry_common import *
from audit_a10_e3_symmetry import adjudicate

class E3SymmetryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p,cls.r=[read(OUT/(n+'.json')) for n in ('primary','replay')]
        cls.c=read(OUT/'checks.json');cls.w=alphabet()
        cls.e2=read(HERE/'frozen_a10_e2_transport/primary.json')
    def test_all_canonical_and_external_operator_columns_compare(self):
        a=adjudicate(self.p,self.r)
        self.assertEqual(a['complete_operator_columns_compared'],4002)
        self.assertEqual(a['operator_coefficients_compared'],55852)
        self.assertEqual(set(self.p['operators']),{'Tq_geometric','Tb_geometric_and_transported','Tq_transported'})
        for I in self.p['operators'].values():self.assertEqual(len(I),1334)
        self.assertFalse(self.r['route_evidence']['primary_outputs_imported'])
    def test_all_hamiltonian_source_columns_and_evaluation_pairing(self):
        self.assertEqual(self.p['route_evidence']['all_generator_Hamiltonian_transport_checks'],1286)
        self.assertTrue(self.c['wrong_source_transpose_sign_witness'])
        self.assertEqual(len(self.c['wrong_source_transpose_pair']),2)
        self.assertIn('physical 10x10 H',self.r['route_evidence']['field_source_construction'])
    def test_quantum_source_correction_is_variational_not_universal_shift(self):
        d=self.p['source_transport_corrections']['quantum']
        self.assertEqual(set(d),{J for z,J in self.w.pairs})
        self.assertEqual(d,self.r['source_transport_corrections']['quantum'])
        self.assertEqual(sum(map(len,d.values())),3032)
        self.assertEqual(sum(map(bool,d.values())),56)
        self.assertTrue(d['Jbar0'])
        self.assertNotEqual(self.p['operators']['Tq_geometric'],self.p['operators']['Tq_transported'])
    def test_background_correction_is_zero_in_all_source_slots(self):
        d=self.p['source_transport_corrections']['background']
        self.assertEqual(set(d),{J for z,J in self.w.pairs})
        self.assertFalse(any(d.values()))
        self.assertEqual(self.p['action_Wards']['background_action_residual'],[])
    def test_fermion_expected_light_quantum_breaking_keeps_parameter_jets(self):
        self.assertEqual(len(self.p['quantum_fermion_breaking']),1760)
        self.assertEqual(self.p['quantum_fermion_breaking'],self.r['quantum_fermion_breaking'])
        self.assertTrue(any(jets for word in decode_typed(self.p['quantum_fermion_breaking']) for n,jets in word if n.startswith('omega')))
    def test_complete_quantum_action_breaking_is_not_a_boundary(self):
        w=self.p['action_Wards']
        self.assertTrue(w['geometric_quantum_breaking'])
        self.assertEqual(len(w['geometric_quantum_breaking']),22520)
        self.assertTrue(w['quantum_breaking_Euler_b0'])
        self.assertIn('Qprime(Tq Psi)+div(Tq L)',w['geometric_breaking_formula'])
        self.assertFalse(w['EOM_used'])
    def test_minimal_quantum_breaking_and_source_defect_have_opposite_signs(self):
        box=self.w.add(*(self.w.scale(self.w.var('omega0',(mu,mu)),ETA[mu]) for mu in range(4)))
        G=mat(read(HERE/'frozen_a10_bv_master/primary.json')['architecture']['gauge_metric_C3'])
        self.assertEqual(decode_typed(self.c['minimal_quantum_Ward']),canonical(self.w.scale(self.w.mul(self.w.var('b0'),box),-G[0,0])))
        self.assertEqual(decode_typed(self.c['minimal_geometric_Qprime_Tq_Jb0']),canonical(self.w.scale(box,G[0,0])))
        self.assertEqual(decode_typed(self.c['required_transported_Jbar0_correction']),canonical(self.w.scale(box,-G[0,0])))
    def test_constant_parameter_test_cannot_replace_local_ward(self):
        self.assertTrue(self.c['constant_parameter_projection_hides_minimal_failure'])
        self.assertTrue(any(jets for word in decode_typed(self.c['minimal_quantum_Ward']) for n,jets in word))
        self.assertTrue(self.c['missing_background_transport_source_columns'])
    def test_transported_quantum_action_has_explicit_boundary_treatment(self):
        w=self.p['action_Wards']
        self.assertEqual(w,self.r['action_Wards'])
        self.assertEqual(w['transported_quantum_minus_divergence'],[])
        self.assertEqual(w['transported_quantum_density'],[])
        self.assertFalse(any(w['transported_quantum_current']))
        self.assertFalse(any(w['geometric_boundary_current']))
        self.assertFalse(any(w['breaking_variation_boundary']))
        self.assertEqual(len(w['transported_quantum_current']),4)
        self.assertEqual(len(w['geometric_boundary_current']),4)
        self.assertEqual(len(w['breaking_variation_boundary']),4)
        self.assertIn('compact support',w['boundary_conditions'])
    def test_complete_brst_commutators_include_correct_geometric_defect(self):
        c=self.p['BRST_compatibility']
        self.assertEqual(c['pretransport_polynomial_checks'],1286)
        self.assertEqual(c['complete_polynomial_and_external_checks'],4002)
        self.assertEqual(c['background_and_transported_quantum_residuals'],[])
        self.assertTrue(c['geometric_quantum_commutator']['Jb0'])
        self.assertEqual(sum(map(len,c['geometric_quantum_commutator'].values())),66368)
        self.assertFalse(any(P for n,P in c['geometric_quantum_commutator'].items() if not n.startswith('J')))
        self.assertFalse(c['EOM_used'])
    def test_full_local_lie_and_mixed_algebra_retains_independent_parameters(self):
        a=self.p['local_algebra']
        self.assertEqual(a['all_generator_local_Lie_checks'],4002)
        self.assertEqual(a['independent_parameters'],['omega','beta'])
        self.assertTrue(a['parameter_derivatives_retained'] and a['all_three_residuals_zero'])
        self.assertFalse(a['domain_or_catalog_qualification'])
    def test_physical_covector_theorem_is_bound_and_not_exhaustive_expansion(self):
        c=self.p['physical_Euler_covariance']
        self.assertEqual(c['physical_slots'],508)
        self.assertEqual(c['physical_program_sha256'],digest(self.e2['physical_Euler_program']))
        self.assertTrue(c['program_unchanged'] and c['all_45_physical_Noether_dependencies_authenticated'])
        self.assertFalse(c['fresh_exhaustive_physical_Euler_expansion'] or c['EOM_used'])
        self.assertIn('differentiate',c['operation'])
    def test_composite_R_H_and_nonsymmetric_coset_are_retained(self):
        c=self.p['composite_R_H']
        self.assertEqual(set(c['R_H']),set(map(str,H)));self.assertEqual(c['H_covariance_checks'],12)
        self.assertTrue(any(c['R_H'].values()) and c['nonsymmetric_f_MMM_preserved'])
        self.assertFalse(c['independent_coordinate_added'] or c['E4_quartic_interpretation_qualified'])
    def test_inverse_transport_on_all_canonical_and_external_coordinates(self):
        self.assertEqual(self.c['inverse_operator_transport_checks'],2668)
        self.assertEqual(self.c['cached_prefix_preserved_engine_checks'],40)
        self.assertEqual(self.c['reference_engine_window_monomials_at_most'],64)
        self.assertFalse(self.c['full_source_squares_enumerated'])
    def test_real_structure_and_graded_source_types_across_full_alphabet(self):
        self.assertEqual(self.c['complete_real_structure_operator_checks'],4002)
        for I in self.p['operators'].values():
            for n,P in I.items():
                if n not in self.w.grades:continue
                gh,parity=self.w.grades[n][1:]
                for word in decode_typed(P):
                    grade=self.w.grades|self.w.external|{f'omega{h}':(0,0,0) for h in H}
                    self.assertEqual(sum(grade[z][1] for z,jets in word),gh)
                    self.assertEqual(sum(self.w.p[z] for z,jets in word)%2,parity)
    def test_jet_prolongation_and_resource_cap_are_explicit(self):
        self.assertEqual(self.c['first_and_second_jet_transport_checks'],624)
        self.assertTrue(self.c['jet_resource_cap_raises'])
        self.assertIn('symmetric prolongation',self.p['BRST_compatibility']['all_admitted_jets'])
    def test_distinct_exterior_replay_includes_all_physical_source_derivatives(self):
        c=self.c['exterior_control']
        self.assertEqual(c['canonical_pairs'],20);self.assertEqual(len(c['full_Euler_columns']),40)
        self.assertEqual(c['BRST_commutator_checks'],126)
        self.assertEqual(c['first_jet_BRST_commutator_checks'],84)
        self.assertEqual(c['background_Ward_residual'],[])
        self.assertEqual(c['transported_quantum_Ward_residual'],[])
        self.assertTrue(c['R_H'] and c['wrong_background_Euler_b0'])
        self.assertFalse(c['EOM_used'] or c['auxiliaries_eliminated'] or c['E4_E5_qualified'])
    def test_backgrounds_remain_external_and_no_full_45_background_is_invented(self):
        c=self.p['contract']
        self.assertEqual(c['external_background_components'],48)
        self.assertEqual(c['H_generators'],12);self.assertEqual(c['background_canonical_pairs'],0)
        self.assertTrue(self.c['invented_45_background_rejected'])
        self.assertFalse(any(n.startswith('JA') for I in self.p['operators'].values() for n in I))
    def test_candidate_preserves_frozen_action_without_new_terms(self):
        c=read(OUT/(NAME+'.json'));self.assertEqual(c,candidate(self.p))
        self.assertFalse(c['action_modified_here'])
        self.assertEqual(self.p['route_evidence']['new_action_terms_added'],0)
        self.assertEqual(len(self.p['contract']['manifest_sha256']),11)
        self.assertFalse(c['H_basic_domain_qualified'] or c['historical_equivalence_proved'])
    def test_false_downstream_promotions_are_rejected(self):
        self.assertEqual(len(self.c['false_promotion_flags_rejected']),13)
        self.assertTrue(self.c['changed_source_column_rejected'])
        for key in self.c['false_promotion_flags_rejected']:
            p,r=dict(self.p),dict(self.r);p[key]=r[key]=True
            with self.assertRaises(AssertionError):adjudicate(p,r)
        self.assertTrue(self.p['inactive'])
        self.assertEqual(self.p['formal_authority'],'34/39_UNCHANGED')

if __name__=='__main__':unittest.main()
