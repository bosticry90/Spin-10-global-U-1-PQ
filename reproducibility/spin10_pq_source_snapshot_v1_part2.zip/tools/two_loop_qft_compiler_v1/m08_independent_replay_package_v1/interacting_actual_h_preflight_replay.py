"""Physical-matrix/ordered-word replay; no primary table or residual import."""
import itertools
import json
import sympy as s
from source_domain_transport_replay import DomainWords, coordinate_bridge, g, xi
from interacting_bv_preflight_replay import ControlWords

ETA=(1,-1,-1,-1)


class FailedIdentity(Exception):
    def __init__(self,label,P,w): self.evidence={'identity':label,'residual':w.record(P),'first_component':w.record(P)[0]}


def zero(P,label,w):
    if P: raise FailedIdentity(label,P,w)


class GaugeWords(DomainWords):
    def __init__(self,n):
        self.fields={**{f'q{i}_{mu}':(1,0,0) for mu in range(4) for i in range(n)},**{f'{prefix}{i}':grade for prefix,grade in [('c',(1,1,1)),('bar',(1,-1,1)),('b',(2,0,0))] for i in range(n)}}
        self.pairs=[(z,'J'+z) for z in self.fields]
        self.grades={**self.fields,**{J:(3-self.fields[z][0],-1-self.fields[z][1],1-self.fields[z][2]) for z,J in self.pairs}}
        self.external={**{f'A{i}_{mu}':(1,0,0) for mu in range(4) for i in range(n)},**{f'{prefix}{i}':(0,0,0) for prefix in ('omega','beta') for i in range(n)}}
        self.p={name:grade[2] for name,grade in (self.grades|self.external).items()}; self.max_jet=0
        self._prolongations={}

    def D(self,P,mu):
        terms=[]
        for word,coefficient in P.items():
            for pos,(name,jets) in enumerate(word):
                indices=tuple(sorted(jets+(mu,))); self.max_jet=max(self.max_jet,len(indices))
                if len(indices)>6: raise RuntimeError('REPLAY_JET_LIMIT_NOT_A_ZERO_RELATION')
                terms.append(self.mul({word[:pos]:coefficient},self.var(name,indices),{word[pos+1:]:1}))
        return self.add(*terms)

    def EL(self,P,base):
        terms=[]
        for word,coefficient in P.items():
            for pos,(name,jets) in enumerate(word):
                if name==base:
                    sign=(-1)**(self.p[name]*sum(self.p[n] for n,_ in word[:pos])+len(jets))
                    terms.append(self.scale(self.dword({word[:pos]+word[pos+1:]:coefficient},jets),sign))
        return self.add(*terms)

    def act(self,P,images,parity=0):
        key=id(images)
        if key not in self._prolongations: self._prolongations[key]=(images,{})
        owner,cache=self._prolongations[key]; assert owner is images
        terms=[]
        for word,coefficient in P.items():
            for pos,(name,jets) in enumerate(word):
                if (name,jets) not in cache: cache[name,jets]=self.dword(images.get(name,{}),jets)
                sign=(-1)**(parity*sum(self.p[n] for n,_ in word[:pos]))
                terms.append(self.scale(self.mul({word[:pos]:coefficient},cache[name,jets],{word[pos+1:]:1}),sign))
        return self.add(*terms)

    def replace(self,P,substitutions):
        terms=[]; cache={}
        for word,coefficient in P.items():
            term={():coefficient}
            for name,jets in word:
                if (name,jets) not in cache: cache[name,jets]=self.dword(substitutions.get(name,self.var(name)),jets)
                term=self.mul(term,cache[name,jets])
            terms.append(term)
        return self.add(*terms)

    def grade(self,P,target):
        for word in P:
            values=[0,0,0]
            for name,jets in word:
                d,gh,par=(self.grades|self.external)[name]; values[0]+=d+len(jets); values[1]+=gh; values[2]^=par
            if tuple(values)!=target: return False
        return True

    def current4(self,P):
        for name in self.p: zero(self.EL(P,name),'master_Euler_'+name,self)
        return ControlWords.boundary(self,P)


def model(f,ids,G,stage):
    n=len(ids); w=GaugeWords(n); x={name:w.var(name) for name in w.p}
    vec=lambda prefix:[x[prefix+str(i)] for i in range(n)]
    conn=lambda prefix,mu:[x[f'{prefix}{i}_{mu}'] for i in range(n)]
    add=lambda v,r:[w.add(a,b) for a,b in zip(v,r)]
    scale=lambda v,k:[w.scale(a,k) for a in v]
    comm=lambda v,r:[w.add(*(w.scale(w.mul(v[a],r[b]),f.get((ids[i],ids[a],ids[b]),0)) for a in range(n) for b in range(n))) for i in range(n)]
    pairing=lambda v,r:w.add(*(w.scale(w.mul(v[a],r[b]),G[a,b]) for a in range(n) for b in range(n) if G[a,b]))
    dot=lambda v,r:w.add(*(w.mul(a,b) for a,b in zip(v,r)))
    A=[conn('A',mu) for mu in range(4)]; q=[conn('q',mu) for mu in range(4)]; B=[add(a,b) for a,b in zip(A,q)]
    c,bar,b,omega,beta=[vec(prefix) for prefix in ('c','bar','b','omega','beta')]
    curvature={(mu,nu):add(add([w.D(a,mu) for a in B[nu]],scale([w.D(a,nu) for a in B[mu]],-1)),scale(comm(B[mu],B[nu]),g)) for mu,nu in itertools.combinations(range(4),2)}
    S0=w.add(*(w.scale(pairing(F,F),-s.Rational(1,2)*ETA[mu]*ETA[nu]) for (mu,nu),F in curvature.items()))
    forward={f'q{i}_{mu}':P for mu in range(4) for i,P in enumerate(add([w.D(a,mu) for a in c],scale(comm(B[mu],c),g)))}
    forward.update({'c'+str(i):w.add(*(w.scale(w.mul(c[a],c[b]),-g*f.get((ids[i],ids[a],ids[b]),0)) for a,b in itertools.combinations(range(n),2))) for i in range(n)})
    forward.update({'bar'+str(i):w.scale(b[i],-1) for i in range(n)}); forward.update({'b'+str(i):{} for i in range(n)})
    Smin=w.add(S0,*(w.mul(x[J],forward[z]) for z,J in w.pairs))
    condition=[w.add(*(w.scale(w.add(w.D(q[mu][i],mu),w.scale(comm(A[mu],q[mu])[i],g)),ETA[mu]) for mu in range(4))) for i in range(n)]
    psi=pairing(bar,add(condition,scale(b,-xi/2))); assert w.grade(Smin,(4,0,0)) and w.grade(psi,(3,-1,1))
    def free_control():
        sub=lambda P:{word:s.expand(coef.subs(g,0)) for word,coef in P.items() if coef.subs(g,0)}
        Sfree=w.add(*(w.mul(x[J],sub(forward[z])) for z,J in w.pairs)); Q=w.columns(Sfree)
        Sfixed=w.add(Sfree,w.act(sub(psi),Q,1)); images=w.columns(Sfixed); bad=dict(images)
        for i in range(n): bad['Jb'+str(i)]=w.add(images['Jb'+str(i)],x['Jbar'+str(i)]); bad['Jbar'+str(i)]={}
        result={}
        for i in range(n):
            actual=w.act(bad['Jb'+str(i)],bad,1)
            expected=w.add(*(w.scale(w.D(w.D(c[k],mu),mu),-G[i,k]*ETA[mu]) for k in range(n) for mu in range(4) if G[i,k]))
            zero(w.add(actual,w.scale(expected,-1)),'free_omitted_partner_'+str(i),w); assert actual
            zero(w.act(images['Jb'+str(i)],images,1),'free_complete_partner_'+str(i),w)
            result['Jb'+str(i)]=w.record(actual)
        return result
    negative=stage('word_free_missing_partner_regression',free_control)
    Q=stage('word_interacting_minimal_columns',lambda:w.columns(Smin))
    I={name:{} for name in w.grades}
    for i in range(n):
        I['c'+str(i)]=omega[i]; I['b'+str(i)]=w.scale(comm(omega,bar)[i],g)
        I['Jbar'+str(i)]=w.add(*(w.scale(w.mul(omega[a],x['Jb'+str(k)]),-g*f.get((ids[k],ids[a],ids[i]),0)) for a in range(n) for k in range(n)))
    def local(parameter,background=False):
        images={f'q{i}_{mu}':P for mu in range(4) for i,P in enumerate(scale(comm(q[mu],parameter),g))}
        if not background: images={f'q{i}_{mu}':P for mu in range(4) for i,P in enumerate(add([w.D(a,mu) for a in parameter],scale(comm(B[mu],parameter),g)))}
        for prefix in ('c','bar','b'): images.update({prefix+str(i):P for i,P in enumerate(scale(comm(vec(prefix),parameter),g))})
        for z,J in w.pairs:
            prefix=z.rstrip('0123456789')
            if z.startswith('q'):
                i,mu=map(int,z[1:].split('_')); prefix='q'; source=lambda k:f'Jq{k}_{mu}'
            else:
                i=int(z[len(prefix):]); source=lambda k:'J'+prefix+str(k)
            images[J]=w.add(*(w.scale(w.mul(parameter[a],x[source(k)]),g*f.get((ids[k],ids[a],ids[i]),0)) for a in range(n) for k in range(n)))
        if background: images.update({f'A{i}_{mu}':P for mu in range(4) for i,P in enumerate(add([w.D(a,mu) for a in parameter],scale(comm(A[mu],parameter),g)))})
        return images
    Tq=stage('word_direct_quantum_cotangent',lambda:local(omega)); Tb=stage('word_direct_background_cotangent',lambda:local(beta,True))
    Tqb,Tbo=local(beta),local(omega,True); pb=scale(comm(beta,omega),g); Tqbr,Tbbr=local(pb),local(pb,True)
    Ibr={name:{} for name in w.grades}
    for i in range(n):
        Ibr['c'+str(i)]=pb[i]; Ibr['b'+str(i)]=w.scale(comm(pb,bar)[i],g)
        Ibr['Jbar'+str(i)]=w.add(*(w.scale(w.mul(pb[a],x['Jb'+str(k)]),-g*f.get((ids[k],ids[a],ids[i]),0)) for a in range(n) for k in range(n)))
    def pre():
        for name in w.grades:
            zero(w.act(Q[name],Q,1),'pre_Q_square_'+name,w)
            zero(w.add(w.act(Q[name],I,1),w.act(I[name],Q,1),w.scale(Tq[name],-1)),'pre_Cartan_'+name,w)
            zero(w.act(I[name],I,1),'pre_iota_square_'+name,w)
            for tag,T in [('quantum',Tq),('background',Tb)]: zero(w.add(w.act(Q[name],T),w.scale(w.act(T[name],Q,1),-1)),'pre_'+tag+'_Q_'+name,w)
            for first,second,expected in [(Tqb,Tq,Tqbr),(Tb,Tbo,Tbbr),(Tb,Tq,Tqbr)]: zero(w.add(w.act(second[name],first),w.scale(w.act(first[name],second),-1),w.scale(expected[name],-1)),'local_Lie_'+name,w)
            for T in (Tqb,Tb): zero(w.add(w.act(I[name],T),w.scale(w.act(T[name],I,1),-1),w.scale(Ibr[name],-1)),'iota_covariance_'+name,w)
        for z in w.fields: zero(w.add(Q[z],w.scale(forward[z],-1)),'derived_forward_'+z,w)
        for (mu,nu),F in curvature.items():
            for i,P in enumerate(F): zero(w.add(w.act(P,Q,1),w.scale(comm(F,c)[i],-g)),'curvature_Q_'+str((mu,nu,i)),w)
        zero(w.act(S0,Q,1),'kinetic_Q_invariance',w); zero(w.act(S0,Tq),'kinetic_quantum_Ward',w); zero(w.act(S0,Tb),'kinetic_background_Ward',w); zero(w.act(psi,Tb),'fermion_background_Ward',w)
        for name in w.external:
            if name.startswith('A'): zero(w.add(w.act(Tbo[name],Tb),w.scale(w.act(Tb[name],Tbo),-1),w.scale(Tbbr[name],-1)),'background_connection_Lie_'+name,w)
        return True
    stage('word_pre_identities_and_interacting_Ward',pre)
    def master(action):
        P=w.scale(w.bracket(action,action),s.Rational(1,2)); currents=w.current4(P)
        return {'half_density':w.record(P),'currents':[w.record(a) for a in currents],'Euler_zero':True,'divergence_reconstructed':True}
    minimal_master=stage('word_minimal_master_divergence',lambda:master(Smin))
    shifts={name:{} for name in w.grades}
    for z,J in w.pairs: shifts[J]=w.scale(w.EL(psi,z),-(-1)**w.p[z])
    positive={name:w.add(x[name],P) for name,P in shifts.items()}
    negative_shifts={name:w.add(x[name],w.scale(P,-1)) for name,P in shifts.items()}
    U=lambda P:w.replace(P,positive); inv=lambda P:w.replace(P,negative_shifts)
    fixed=U(Smin); Qfixed=stage('word_fixed_Euler_columns',lambda:w.columns(fixed))
    transport=lambda images,parity:{name:U(w.act(inv(x[name]),images,parity)) for name in w.grades}
    Tfixed=stage('word_transport_quantum_sources',lambda:transport(Tq,0)); Ifixed=stage('word_transport_iota',lambda:transport(I,1)); Bfixed=stage('word_transport_background',lambda:{**{name:U(Tb[name]) for name in w.external if name.startswith('A')},**transport(Tb,0)})
    Tgen=w.add(*(w.scale(w.mul(x[J],Tq[z]),-(-1)**w.p[z]) for z,J in w.pairs))
    Igen=w.add(dot(vec('Jc'),omega),dot(vec('Jb'),scale(comm(omega,bar),g)))
    def fixed_checks():
        for name in w.grades:
            assert w.grade(shifts[name],w.grades[name])
            zero(w.add(inv(U(x[name])),w.scale(x[name],-1)),'inverse_'+name,w)
            zero(w.add(w.act(U(x[name]),Qfixed,1),w.scale(U(Q[name]),-1)),'Q_intertwiner_'+name,w)
            zero(w.act(Qfixed[name],Qfixed,1),'fixed_Q_square_'+name,w)
            zero(w.add(w.act(Qfixed[name],Ifixed,1),w.act(Ifixed[name],Qfixed,1),w.scale(Tfixed[name],-1)),'fixed_Cartan_'+name,w)
            zero(w.add(Bfixed[name],w.scale(Tb[name],-1)),'background_commutes_U_'+name,w)
            for T in (Tfixed,Bfixed): zero(w.add(w.act(Qfixed[name],T),w.scale(w.act(T[name],Qfixed,1),-1)),'fixed_TQ_'+name,w)
            zero(w.add(w.bracket(U(Tgen),x[name]),w.scale(Tfixed[name],-1)),'fixed_quantum_Hamiltonian_'+name,w)
            zero(w.add(w.bracket(U(Igen),x[name]),w.scale(Ifixed[name],-1)),'fixed_iota_Hamiltonian_'+name,w)
            for mu in range(4):
                jet=w.D(x[name],mu); zero(w.act(w.act(jet,Qfixed,1),Qfixed,1),'fixed_first_jet_square_'+str((name,mu)),w)
                for tag,images,parity in [('Q',Qfixed,1),('I',Ifixed,1),('Tq',Tfixed,0),('Tb',Bfixed,0)]: zero(w.add(w.act(jet,images,parity),w.scale(w.D(images[name],mu),-1)),'first_jet_prolongation_'+str((tag,name,mu)),w)
        for z,J in w.pairs: zero(w.add(w.bracket(U(x[z]),w.scale(U(x[J]),(-1)**w.p[z])),{():s.Integer(-1)}),'canonical_diagonal_'+z,w)
        for (_,J),(_,K) in itertools.combinations_with_replacement(w.pairs,2): zero(w.bracket(U(x[J]),U(x[K])),'canonical_cross_'+J+'_'+K,w)
        for name in w.external:
            if name.startswith('A'):
                zero(w.add(Bfixed[name],w.scale(Tb[name],-1)),'external_background_transport_'+name,w)
                for mu in range(4): zero(w.add(w.act(w.D(x[name],mu),Bfixed),w.scale(w.D(Bfixed[name],mu),-1)),'external_background_first_jet_'+str((name,mu)),w)
        difference=w.add(fixed,w.scale(Smin,-1),w.scale(w.act(psi,Q,1),-1)); return [w.record(a) for a in w.current4(difference)]
    density_current=stage('word_canonical_fixed_identities_and_jets',fixed_checks)
    fixed_master=stage('word_fixed_master_divergence',lambda:master(fixed))
    F=dot(vec('Jb'),curvature[0,1]); image=w.act(F,Q,1); FF=U(F); fixedimage=w.act(FF,Qfixed,1)
    def domain():
        assert image and fixedimage and w.grade(F,(3,-1,1)); zero(w.add(fixedimage,w.scale(U(image),-1)),'domain_Q_intertwiner',w)
        for P in (F,image):
            for tag,T,parity in [('Tq',Tq,0),('I',I,1),('Tb',Tb,0)]: zero(w.act(P,T,parity),'pre_domain_'+tag,w)
        for P in (FF,fixedimage):
            for tag,T,parity in [('Tq',Tfixed,0),('I',Ifixed,1),('Tb',Bfixed,0)]: zero(w.act(P,T,parity),'fixed_domain_'+tag,w)
        defect=w.act(fixedimage,Tq); assert defect
        selected=next((name,w.EL(defect,name)) for name in w.p if w.EL(defect,name))
        return {'raw_quantum_defect':w.record(defect),'Euler_variable':selected[0],'Euler_residual':w.record(selected[1])}
    wrong=stage('word_nonzero_source_domain_and_negative',domain)
    return {'status':'PASS_BOUNDED_INTERACTING_ACTUAL_H_CONTROL','ids':ids,'pairs':28,'generators':56,'spacetime_directions':4,
        'actions':{'kinetic':w.record(S0),'minimal':w.record(Smin),'fermion':w.record(psi),'fixed':w.record(fixed)},
        'images':{tag:{name:w.record(P) for name,P in table.items()} for tag,table in [('Q_min',Q),('Q_fixed',Qfixed),('Tq_min',Tq),('Tb_min',Tb),('iota_min',I),('Tq_fixed',Tfixed),('Tb_fixed',Bfixed),('iota_fixed',Ifixed)]},
        'shifts':{name:w.record(P) for name,P in shifts.items()},'master':{'minimal':minimal_master,'fixed':fixed_master},'fixed_density_current':density_current,
        'domain':{'F':w.record(F),'QF':w.record(image),'UF':w.record(FF),'Qfixed_UF':w.record(fixedimage),'nonzero_images':True,'structural_preservation':True,'counterterm_completeness':False},
        'negative_controls':{'free_missing_partner':negative,'wrong_raw_source':wrong},
        'counts':{'minimal_squares':56,'fixed_squares':56,'fixed_first_jet_squares':224,'canonical_diagonal':28,'source_cross_pairs':406,'first_jet_prolongation':896,'external_background_first_jets':64},
        'maximum_jet_order':w.max_jet,'jet_truncation':False,'EOM_used':False}


def build(stage=None):
    if not __debug__: raise RuntimeError('ASSERTIONS_REQUIRED')
    stage=stage or (lambda name,fn:fn()); f,ids,G,_=stage('physical_actual_H_geometry',coordinate_bridge)
    try: result=model(f,ids,G,stage)
    except FailedIdentity as failure: result={'status':'FAILED_FIRST_PREREQUISITE','witness':failure.evidence}
    return {'schema':'INTERACTING_ACTUAL_H_PREFLIGHT_V1','result':result,'full_M08_qualified':False,'active_sources_added':False,'phase_C_authorized':False,'HB1_C5_authorized':False,'formal_authority':'34/39_UNCHANGED','finite_C1_GS':None,'external_specialist_review':False}


if __name__=='__main__': print(json.dumps(build(),sort_keys=True,separators=(',',':')))
