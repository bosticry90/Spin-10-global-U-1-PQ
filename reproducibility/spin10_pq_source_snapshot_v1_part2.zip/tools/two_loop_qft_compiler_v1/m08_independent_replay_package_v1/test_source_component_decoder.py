"""Frozen evidence regressions; read-only audit recomputes both routes."""
import copy
import inspect
import json
from pathlib import Path
import unittest
from audit_source_component_decoder import compare, negative_controls
import source_component_decoder_replay as replay


class SourceDecoderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        out=Path(__file__).resolve().parent/"frozen_source_component_decoder"
        cls.p=json.loads((out/"primary.json").read_text()); cls.r=json.loads((out/"replay.json").read_text())
    def test_complete_exact_comparison(self): compare(self.p,self.r)
    def test_31_false_claim_mutations(self): self.assertEqual(negative_controls(self.p,self.r),31)
    def test_six_literal_couplings(self): self.assertEqual(len(self.p["source_inventory"]),6)
    def test_recovery_uses_frozen_images(self): self.assertTrue(all(x["source_Euler_recovery"]=="EXACT_FROZEN_IMAGE" for x in self.p["source_inventory"]))
    def test_no_implicit_Gram_in_AST(self): self.assertFalse(any(x["explicit_Gram_between_source_and_image"] for x in self.p["source_inventory"]))
    def test_source_grade_is_dual_of_field_grade(self):
        for x in self.p["source_inventory"]:
            d,g,p=x["field_grade"]; self.assertEqual(x["source_grade"],[3-d,-1-g,1-p])
    def test_light_macro_and_typed_coordinates_not_identical(self):
        self.assertEqual([x["source"] for x in self.p["source_inventory"] if not x["CAT_INT12_direct_orientation_agrees"]],["K_q","L_c"])
    def test_wrong_primal_pairing_reproduced(self): self.assertEqual(self.p["coordinates"]["first_nonzero_component"],[0,4,4,"-sqrt(2)*I"])
    def test_all_12_H_generators_checked(self): self.assertEqual(len(self.p["coordinates"]["wrong_direct_primal_delta_pairing"]),12)
    def test_not_a_universal_no_go(self): self.assertFalse(self.p["historical_layer_comparison"]["all_possible_source_decoders_ruled_out"])
    def test_six_physical_triangles(self): self.assertEqual(len(self.p["physical_triangles"]),6)
    def test_scalar_328_decoder_not_dynamics(self): self.assertEqual(self.p["physical_triangles"][2]["channel_components"],328); self.assertFalse(self.r["independence"]["scalar_328_reconstructed"])
    def test_Lambda_double_dual(self): self.assertTrue(self.p["physical_triangles"][4]["field_dual"]); self.assertFalse(self.p["physical_triangles"][4]["typed_source_dual"])
    def test_nonidentity_source_bracket(self): self.assertTrue(self.p["coordinates"]["conditional_induced_even_field_bracket"]["entries"])
    def test_odd_source_pair_sign_separate(self): self.assertNotEqual(self.p["coordinates"]["conditional_induced_even_field_bracket"],self.p["coordinates"]["conditional_induced_odd_field_bracket"])
    def test_coupling_change_negative_control(self): self.assertEqual(self.p["coordinates"]["conditional_coupling_difference"]["Gram_inserted_coefficient"],"0")
    def test_inverse_and_conjugation_checks(self): self.assertTrue(all(x["both_inverse_products_pairing_physical_reconstruction_conjugation"] for x in self.p["physical_triangles"]))
    def test_frozen_extractors_not_imported_by_replay(self): self.assertNotIn('r["physical_extractor"]',inspect.getsource(replay)); self.assertFalse(self.r["independence"]["serialized_extractors_imported"])
    def test_replay_no_primary_decoder_import(self): self.assertNotIn("from source_component_decoder import",inspect.getsource(replay))
    def test_990_physical_parent_pairs(self): self.assertEqual(self.r["independence"]["physical_parent_commutators"],990)
    def test_1728_component_equations(self): self.assertEqual(self.r["component_pairing_equations"],1728)
    def test_shared_library_limits(self): self.assertFalse(self.r["independence"]["LIBRARY_INDEPENDENT"] or self.r["independence"]["RUNTIME_INDEPENDENT"] or self.r["independence"]["analyst_blind"])
    def test_prospective_partners_only(self): self.assertEqual(sum(x["components"] for x in self.p["prospective_partners"]),57); self.assertFalse(any(x["active"] for x in self.p["prospective_partners"]))
    def test_joint_domain_not_full_M08(self): self.assertFalse(self.p["joint_domain"]["full_M08_domain_preservation_tested"])
    def test_quantum_background_actions_separate(self): self.assertTrue(self.p["joint_domain"]["quantum_background_actions_distinct"])
    def test_composite_substitution_order_preserved(self): self.assertTrue(self.p["joint_domain"]["independent_parameter_then_substitution"])
    def test_proposal_only_authorized(self): self.assertTrue(self.p["interacting_reconstruction_proposal_authorized"]); self.assertFalse(self.p["full_interacting_reconstruction_authorized"])
    def test_legacy_operator_not_repaired(self): self.assertFalse(self.p["historical_layer_comparison"]["historical_canonical_operator_repaired"])
    def test_no_active_M08_changes(self): self.assertFalse(self.p["M08_changed"] or self.p["HB1_C5_authorized"] or self.p["cochain_dimensions_computed"])
    def test_34_of_39_not_ToE_percentage(self): self.assertEqual(self.p["formal_authority"],"34/39_UNCHANGED"); self.assertIsNone(self.p["finite_C1_GS"])
    def test_specialist_review_outstanding(self): self.assertFalse(self.p["external_specialist_review"])
    def test_false_triangle_digest_rejected(self):
        bad=copy.deepcopy(self.p); bad["physical_triangles"][1]["inverse"]["canonical_sparse_sha256"]="0"*64
        with self.assertRaises(AssertionError): compare(bad,self.r)
    def test_false_physical_promotion_rejected(self):
        bad=copy.deepcopy(self.p); bad["formal_authority"]="35/39"
        with self.assertRaises(AssertionError): compare(bad,self.r)


if __name__=="__main__": unittest.main()
