"""Scientific controls for the stopped derivative companion."""
import unittest
from audit_a10_e5_derivative_gauge import *
from a10_e5_derivative_gauge_control import gaussian_moment,sphere_moment,times,R,pa,pc,wx


class DerivativeGaugeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.a,cls.u,cls.c,cls.q=evidence()
    def test_complete_zero_slot_domain(self):self.assertEqual(self.q['complete_slot_comparisons'],182250)
    def test_five_nonzero_graph_classes(self):self.assertEqual(set(self.a['family_pole_slots']),{'YM','ghost','lambda','ordinary','quartic'})
    def test_full_all45_external_tensor(self):self.assertEqual(self.a['domain']['ghost_directions'],45);self.assertEqual(self.a['domain']['antighost_directions'],45)
    def test_homogeneous_H_scope(self):self.assertEqual(self.a['all12_homogeneous_H_tensor_checks'],list(range(12)));self.assertFalse(self.a['full_local_jet_Ward_identity_claimed'])
    def test_reference_widths_canceled(self):self.assertTrue(self.a['reference_widths_cancel_after_complete_contraction'])
    def test_full_transverse_BB_control(self):self.assertEqual(self.q['numeric_negative_controls']['omit_transverse_BB_residual'],'3/2')
    def test_odd_order_numeric_control(self):self.assertEqual(self.q['numeric_negative_controls']['reverse_external_odd_order_residual'],'-2')
    def test_missing_assignment_numeric_control(self):self.assertEqual(self.q['numeric_negative_controls']['omit_external_antighost_assignment_unit_residual'],'-1/2')
    def test_every_graph_omission_nonzero(self):self.assertTrue(all(self.q['numeric_negative_controls']['omit_'+f+'_graph_family']['coefficient']!='0' for f in self.a['family_pole_slots']))
    def test_ordinary_quartic_included(self):self.assertEqual(self.a['inventory']['ordinary_two_B_quartic_terms_all4'],14120)
    def test_projected_ghost_quartic_included(self):self.assertEqual(self.a['inventory']['raw_g_xi_quartic_terms'],648)
    def test_two_independent_momenta(self):self.assertTrue(self.u['both_independent_external_momenta_retained']);self.assertEqual(self.q['numeric_negative_controls']['single_momentum_reduction_hides_nonzero_Euler_symbol']['p_a_1_p_C_minus1'],'0')
    def test_actual_and_candidate_currents_nonzero(self):self.assertEqual(len(self.c['actual_quartic_B_derivative_current']),276);self.assertEqual(len(self.c['candidate_IBP_current']),416)
    def test_real_dual_primal_control(self):self.assertNotEqual(self.q['numeric_negative_controls']['wrong_primal_antighost_chart_residual']['coefficient'],'0')
    def test_lower_order_zero_without_candidate(self):self.assertTrue(self.a['prerequisites']['full4_vector_double_longitudinal_YM_identity']);self.assertFalse(self.c['lower_candidate_zero_actual_residual'])
    def test_all_four_polarizations(self):self.assertTrue(all(v==[1,2,3] for v in self.u['all4_Lorentz_axes_checked'].values()));self.assertEqual(self.q['full_four_copy_difference_terms'],2048)
    def test_real_Euler_excludes_boundary(self):self.assertEqual(self.q['real_Euler_terms'],36);self.assertFalse(self.c['real_gauge_Euler_witness']['pure_total_derivative'])
    def test_source_free_K4_has_no_derivative_image(self):self.assertTrue(self.c['new_K4_derivative_projection_zero'])
    def test_necessary_match_failed(self):self.assertFalse(self.c['match']);self.assertTrue(self.c['first_failure_stopped'])
    def test_no_fitting_or_higher_loop(self):self.assertFalse(self.c['primitive_or_parameters_refitted']);self.assertFalse(self.c['higher_or_other_source_actual_loops_executed'])
    def test_no_quantum_or_empirical_inference(self):self.assertFalse(self.c['normalization_adopted']);self.assertFalse(self.c['full_E5_or_quantum_A5']);self.assertFalse(self.c['whole_goal_complete']);self.assertFalse(self.c['real_gauge_Euler_witness']['general_EOM_or_anomaly_conclusion'])
    def test_exact_linear_Taylor_projection(self):self.assertEqual(times(1+pa+pc,1+pa+pc),1+2*pa+2*pc);self.assertEqual(times(wx**7,wx**9),wx**16)
    def test_distinct_sphere_moment_recursions(self):
        for powers in [(4,0,0,0),(2,2,0,0),(0,2,2,2),(2,2,2,2),(3,1,0,0)]:self.assertEqual(gaussian_moment(powers),sphere_moment(powers))
    def test_Minkowski_angular_signs(self):self.assertEqual(gaussian_moment((2,0,0,0)),s.Rational(1,4));self.assertEqual(gaussian_moment((0,2,0,0)),-s.Rational(1,4))
    def test_UV_only_and_heat_profiles(self):self.assertEqual(self.u['UV_domain'],'k_E^2>R_UV^2>0');self.assertEqual((self.u['triangle_heat_profile'],self.u['bubble_heat_profile']),(6,4));self.assertFalse(self.u['finite_IR_or_whole_scaleless_integral_calculated'])


if __name__=='__main__':unittest.main()
