"""Seal completed actual quartet and its inactive normalization comparison."""
import json,subprocess,sys
from hashlib import sha256
from a10_e5_quartic_companion import HERE,ROOT,OUT,read
from validate_a10_e5_quartic_companion import protected,new_files
from seal_a10_e5_cubic_primitive import PARENTS as OLD_PARENTS

PARENTS=(*OLD_PARENTS,'frozen_a10_e5_cubic_primitive')


def main():
    assert __debug__ and hasattr(__import__('sitecustomize'),'DENIED')
    assert not (OUT/'bindings.json').exists(),'NO_OVERWRITE'
    r=read(OUT/'validation_receipt.json')
    assert r['status']=='PASS_BOUNDED_ACTUAL_QUARTET_EVIDENCE_VALIDATION_ONLY'
    assert r['fresh_routes_byte_identical']==2 and not r['audit_time_changes']
    assert r['historical_custody_exit']==2 and r['unresolved_historical_references']==7
    assert r['actual_agreement']['all980100_slots_compared_between_routes']
    assert r['comparison']['all980100_actual_candidate_slots_compared']
    assert not r['normalization_adopted'] and not r['source_loops_after_quartic_stop_executed']
    assert protected()==r['protected_byte_sha256']
    for name,h in r['new_sha256'].items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h,('CHANGED_AFTER_VALIDATION',name)
    assert sha256((ROOT/'project_state.json').read_bytes()).hexdigest()==r['state_sha256']
    base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    assert base=='1e8198037ded95b3992fcca5255aa5bf92dff987'
    paths=new_files()+[OUT/'validation_receipt.json'];assert all(p.read_bytes().endswith(b'\n') for p in paths)
    value={'schema':'E5_ACTUAL_QUARTIC_BINDINGS_V1','base_commit':base,
        'byte_sha256':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))},
        'inherited_manifest_sha256':{(HERE/n/'bindings.json').relative_to(ROOT).as_posix():sha256((HERE/n/'bindings.json').read_bytes()).hexdigest() for n in PARENTS},
        'state_sha256':r['state_sha256'],'scientific_disposition':r['scientific_gate'],
        'complete_selected_actual_quartet_qualified':True,'inactive_normalization_matches_selected_quartet':r['comparison']['nonzero_difference_slots']==0,
        'sources_activated':False,'auxiliaries_eliminated':False,'candidate_adopted':False,'authority_changed':False,
        'full_E5_PASS':False,'whole_goal_complete':False,'HB1_C5_run':False,'C1_GS_calculated':False,
        'source_loops_after_first_failure_executed':False,'remote_push':False,'external_endorsement':False,
        'post_validation_finalization':'receipt export and byte seal; calculation/protected bytes unchanged'}
    with (OUT/'bindings.json').open('xb') as f:f.write(json.dumps(value,sort_keys=True,separators=(',',':')).encode()+b'\n')
    print('SEALED complete selected actual quartet and inactive normalization comparison; whole goal incomplete')


if __name__=='__main__':main()
