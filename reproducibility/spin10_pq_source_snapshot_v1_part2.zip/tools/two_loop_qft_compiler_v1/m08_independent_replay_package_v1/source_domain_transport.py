"""Inactive canonical source/domain candidate; bounded actual-H test, stdout only."""
import itertools
import json
import sympy as s
from nonabelian_m08_semantic import geometry, matrix_record, canonical, digest
from nonminimal_bv_free import Jets
from source_convention_control import Exterior
from nonminimal_bv_m08_architecture import load

DISPOSITION = "QUALIFIED_BOUNDED_SOURCE_DOMAIN_TRANSPORT_NOT_FULL_M08"
g, xi = s.symbols("g10 eta_H")


def source_bridge():
    f, H, _, previous = geometry()
    record = previous["H_gram"]
    G = s.Matrix(s.MutableSparseMatrix(*record["shape"], {(i, j): s.sympify(v) for i, j, v in record["entries"]}))
    inverse = G.inv(); assert G*inverse == inverse*G == s.eye(12)
    basis = load("frozen_c3/C3_representation_basis.json"); cols = []
    for row in basis["h_basis"]+basis["heavy_basis"]:
        col = s.zeros(45, 1)
        for r in row["raw_so10_coordinates"]: col[r["index"]] = s.sympify(r["coefficient"])
        cols.append(col)
    frame = s.Matrix.hstack(*cols); real = (frame.inv()*frame.conjugate()).applyfunc(s.simplify)
    assert real[12:, :12] == s.zeros(33, 12)
    C = real[:12, :12]; dual_C = C.inv().T
    assert (C*C.conjugate()).applyfunc(s.simplify) == s.eye(12)
    assert (C.T*G*C-G.conjugate()).applyfunc(s.simplify) == s.zeros(12)
    assert (G*C-dual_C*G.conjugate()).applyfunc(s.simplify) == s.zeros(12)
    for M in H: assert (M.T*G+G*M).applyfunc(s.simplify) == s.zeros(12)
    wrong = inverse-s.eye(12); assert wrong != s.zeros(12)
    # Grade and parity do not change under a constant even coordinate map.
    # With J=G k, (z_a,k_b)=(-1)^p (G^-1)_(b,a).
    weighted_recovery = G*inverse; assert weighted_recovery == s.eye(12)
    selected = {0, 4}; iterations = []
    while True:
        larger = set(selected)
        for a, b in itertools.product(selected, repeat=2): larger.update(i for i in range(12) if f.get((i, a, b), 0))
        larger.update(j for i in selected for j in range(12) if G[i, j])
        iterations.append(sorted(larger))
        if larger == selected: break
        selected = larger
    indices = sorted(selected); K = G.extract(indices, indices)
    assert indices == [0, 1, 4, 11] and K.det() != 0
    assert all(not f.get((i, a, b), 0) for a, b in itertools.product(indices, repeat=2) for i in range(12) if i not in indices)
    return f, indices, K, {"H_gram": matrix_record(G), "inverse": matrix_record(inverse), "conjugation": matrix_record(C), "evaluation_dual_conjugation": matrix_record(dual_C),
        "inverse_pairing_equivariance_and_reality": True, "induced_carrier_bracket": matrix_record(inverse.T), "wrong_delta_bracket_residual": matrix_record(wrong),
        "coordinate_map": "J=G_H k; canonical z_star=(-1)^p J; k alone is not a canonical source with delta bracket",
        "legacy_catalog_decoder_bound": False, "selection_seed": [0, 4], "selection_iterations": iterations, "selected_H_indices": indices, "selected_gram": matrix_record(K)}


class DomainJets(Jets):
    def __init__(self, n):
        self.a, self.meta, self.values = Exterior(), {}, {}
        self.limit, self.max_order, self.n = 6, 0, n
        types = {"q": (1, 0, 0), "c": (1, 1, 1), "bar": (1, -1, 1), "b": (2, 0, 0), "p": (1, 0, 0)}
        self.fields = {prefix+str(i): grade for prefix, grade in types.items() for i in range(n)}
        self.pairs = [(name, "J"+name) for name in self.fields]
        self.grades = {**self.fields, **{J: (3-d, -1-gh, 1-par) for (z, J), (d, gh, par) in zip(self.pairs, self.fields.values())}}
        self.external = {prefix+str(i): (1 if prefix == "A" else 0, 0, 0) for prefix in ("A", "omega", "beta") for i in range(n)}
        for name in self.grades | self.external: self.var(name)

    def var(self, base, indices=()):
        indices = tuple(sorted(indices))
        if len(indices) > self.limit: raise RuntimeError("JET_LIMIT_NOT_TRUNCATION")
        name = base+("__"+"".join(map(str, indices)) if indices else "")
        if name not in self.meta:
            self.meta[name] = (base, indices); grade = (self.grades | self.external)[base]
            self.values[name] = self.a.variable(name, grade[2]); self.max_order = max(self.max_order, len(indices))
        return self.values[name]

    def bracket(self, F, G, pairs=None):
        a = self.a; pairs = self.pairs if pairs is None else pairs
        return a.add(*(a.scale(a.add(a.mul(self.euler(F, z, "right"), self.euler(G, J)), a.scale(a.mul(self.euler(F, J, "right"), self.euler(G, z)), -1)), (-1)**self.grades[z][2]) for z, J in pairs))

    def columns(self, S): return {name: self.euler(S, other) for pair in self.pairs for name, other in (pair, pair[::-1])}
    def act(self, P, images, parity=0):
        return self.a.derive(P, {name: self.multiD(images.get(self.meta[name][0], {}), self.meta[name][1]) for name in self.support(P)}, parity=parity)
    def Q(self, P, images): return self.act(P, images, 1)
    def record(self, P): return canonical(P, self.a)
    def grade(self, P, target):
        for row in self.record(P):
            result = [0, 0, 0]
            for name in row["word"]:
                base, jets = self.meta[name]; d, gh, par = (self.grades | self.external)[base]
                result[0] += d+len(jets); result[1] += gh; result[2] ^= par
            if tuple(result) != target: return False
        return True
    def current(self, P):
        if not P: return {}
        parts = {}
        for row in self.record(P):
            degree = len(row["word"]); assert degree
            term = {(): s.sympify(row["coefficient"])}
            for name in row["word"]: term = self.a.mul(term, self.values[name])
            parts[degree] = self.a.add(parts.get(degree, {}), term)
        result = {}
        for degree, part in parts.items():
            for base in self.grades | self.external: assert not self.euler(part, base), "master Euler "+base
            for name in self.support(part):
                base, jets = self.meta[name]; coeff = self.a.partial(part, name)
                assert all(mu == 0 for mu in jets)
                for k in range(len(jets)):
                    term = self.a.mul(self.var(base, jets[k+1:]), self.multiD(coeff, jets[:k]))
                    result = self.a.add(result, self.a.scale(term, s.Rational((-1)**k, degree)))
        assert not self.a.add(self.D(result, 0), self.a.scale(P, -1)), "explicit master current"
        return result


def bounded_model(f, indices, G, stage):
    n = len(indices); j = DomainJets(n); a = j.a; x = {name: j.var(name) for name in j.grades | j.external}
    vec = lambda prefix: [x[prefix+str(i)] for i in range(n)]
    comm = lambda v, w: [a.add(*(a.scale(a.mul(v[b], w[c]), f.get((indices[i], indices[b], indices[c]), 0)) for b in range(n) for c in range(n))) for i in range(n)]
    addvec = lambda v, w: [a.add(z, y) for z, y in zip(v, w)]
    scaled = lambda v, c: [a.scale(z, c) for z in v]
    dot = lambda v, w: a.add(*(a.mul(z, y) for z, y in zip(v, w)))
    paired = lambda v, w: a.add(*(a.scale(a.mul(v[i], w[k]), G[i, k]) for i in range(n) for k in range(n) if G[i, k]))
    A, q, c, bar, b, phi, omega, beta = [vec(prefix) for prefix in ("A", "q", "c", "bar", "b", "p", "omega", "beta")]
    B = addvec(A, q); Dbar = lambda z: addvec([j.D(t, 0) for t in z], scaled(comm(A, z), g))
    forward = {}
    for prefix, images in (("q", addvec([j.D(t, 0) for t in c], scaled(comm(B, c), g))), ("c", scaled(comm(c, c), -g/2)), ("bar", scaled(b, -1)), ("b", [{} for _ in b]), ("p", scaled(comm(c, phi), -g))):
        forward.update({prefix+str(i): value for i, value in enumerate(images)})
    Smin = a.add(*(a.mul(x[J], forward[z]) for z, J in j.pairs)); Q = stage("minimal_canonical_columns", lambda: j.columns(Smin))
    Igen = a.add(dot(vec("Jc"), omega), dot(vec("Jb"), scaled(comm(omega, bar), g)))
    I = {name: j.bracket(Igen, x[name]) for name in j.grades}
    def local(parameter, background=False):
        fields = {prefix+str(i): value for prefix in ("q", "c", "bar", "b", "p") for i, value in enumerate(scaled(comm(vec(prefix), parameter), g))}
        if not background: fields.update({"q"+str(i): value for i, value in enumerate(addvec([j.D(t, 0) for t in parameter], scaled(comm(B, parameter), g)))})
        generator = a.add(*(a.scale(a.mul(x[J], fields[z]), -(-1)**j.grades[z][2]) for z, J in j.pairs))
        result = {name: j.bracket(generator, x[name]) for name in j.grades}
        if background: result.update({"A"+str(i): value for i, value in enumerate(Dbar(parameter))})
        return result, generator
    Tq, Tgen = stage("quantum_cotangent_lift", lambda: local(omega))
    Tb, _ = stage("background_cotangent_Ward_lift", lambda: local(beta, True))
    Tq_beta, _ = local(beta); Tb_omega, _ = local(omega, True)
    parameter_bracket = scaled(comm(beta, omega), g)
    Tq_bracket, _ = local(parameter_bracket); Tb_bracket, _ = local(parameter_bracket, True)
    Ibracket = a.add(dot(vec("Jc"), parameter_bracket), dot(vec("Jb"), scaled(comm(parameter_bracket, bar), g)))
    I_bracket = {name: j.bracket(Ibracket, x[name]) for name in j.grades}
    condition = Dbar(q); psi = paired(bar, addvec(condition, scaled(b, -xi/2)))
    wrong_psi = dot(bar, addvec(condition, scaled(b, -xi/2)))
    def preflight():
        assert j.grade(Smin, (4, 0, 0)) and j.grade(psi, (3, -1, 1))
        assert not j.act(psi, Tb)
        wrong = j.act(wrong_psi, Tb); assert wrong, "wrong ordinary dot pairing must fail Ward"
        for name in j.grades:
            assert not a.add(j.Q(Q[name], I), j.Q(I[name], Q), a.scale(Tq[name], -1)), "pre Cartan "+name
            assert not j.Q(Q[name], Q), "pre Q square "+name
            assert not j.Q(I[name], I)
            for T in (Tq, Tb): assert not a.add(j.act(Q[name], T), a.scale(j.Q(T.get(name, {}), Q), -1)), "pre TQ "+name
            for first, second, expected in ((Tq_beta, Tq, Tq_bracket), (Tb, Tb_omega, Tb_bracket), (Tb, Tq, Tq_bracket)):
                assert not a.add(j.act(second[name], first), a.scale(j.act(first[name], second), -1), a.scale(expected[name], -1)), "local Lie "+name
            for first in (Tq_beta, Tb):
                assert not a.add(j.act(I[name], first), a.scale(j.Q(first[name], I), -1), a.scale(I_bracket[name], -1)), "local contraction covariance "+name
        for z in j.fields: assert not a.add(Q[z], a.scale(forward[z], -1))
        for name in j.external:
            if name.startswith("A"):
                assert not a.add(j.act(Tb_omega[name], Tb), a.scale(j.act(Tb[name], Tb_omega), -1), a.scale(Tb_bracket[name], -1))
        return wrong
    wrong = stage("pre_domain_identities_and_Ward", preflight)
    shifts = {name: a.scale(j.bracket(psi, x[name]), -1) for name in j.grades}
    U = lambda P: j.transport(P, shifts); inv = lambda P: j.transport(P, shifts, -1)
    fixed = U(Smin); Qfixed = stage("fixed_canonical_columns", lambda: j.columns(fixed))
    transported = lambda images, parity: {name: U(j.act(inv(x[name]), images, parity)) for name in j.grades}
    Tfixed = stage("transport_quantum_source_action", lambda: transported(Tq, 0))
    Ifixed = stage("transport_contraction", lambda: transported(I, 1))
    Bfixed = stage("transport_background_action", lambda: transported(Tb, 0))
    def transport_checks():
        for name in j.grades:
            assert j.grade(shifts[name], j.grades[name])
            assert not a.add(inv(U(x[name])), a.scale(x[name], -1))
            assert not a.add(j.Q(U(x[name]), Qfixed), a.scale(U(Q[name]), -1))
            assert not a.add(Bfixed[name], a.scale(Tb[name], -1))
            assert not a.add(j.bracket(U(Tgen), x[name]), a.scale(Tfixed[name], -1))
            assert not a.add(j.bracket(U(Igen), x[name]), a.scale(Ifixed[name], -1))
            assert not a.add(j.Q(Qfixed[name], Ifixed), j.Q(Ifixed[name], Qfixed), a.scale(Tfixed[name], -1))
            assert not j.Q(Qfixed[name], Qfixed)
            for T in (Tfixed, Tb): assert not a.add(j.act(Qfixed[name], T), a.scale(j.Q(T[name], Qfixed), -1))
            assert not a.add(j.act(j.D(x[name], 0), Tfixed), a.scale(j.D(Tfixed[name], 0), -1))
            assert not a.add(j.Q(j.D(x[name], 0), Ifixed), a.scale(j.D(Ifixed[name], 0), -1))
        for z, J in j.pairs:
            star = a.scale(U(x[J]), (-1)**j.grades[z][2])
            assert j.bracket(U(x[z]), star) == {(): s.Integer(1)}
        for (_, J), (_, K) in itertools.combinations_with_replacement(j.pairs, 2):
            assert not j.bracket(U(x[J]), U(x[K])), "canonical source cross-pair "+J+" "+K
        expected = j.D(paired(bar, [forward["q"+str(i)] for i in range(n)]), 0)
        assert not a.add(fixed, a.scale(Smin, -1), a.scale(j.Q(psi, Q), -1), a.scale(expected, -1))
    stage("canonical_transport_and_joint_compatibility", transport_checks)
    F = dot(vec("Jb"), phi); image = j.Q(F, Q); FF = U(F); fixed_image = j.Q(FF, Qfixed)
    def domain_checks():
        assert image and fixed_image and j.grade(F, (2, -1, 1))
        assert not a.add(fixed_image, a.scale(U(image), -1))
        for P in (F, image):
            assert not j.act(P, Tq) and not j.Q(P, I) and not j.act(P, Tb)
        for P in (FF, fixed_image):
            assert not j.act(P, Tfixed) and not j.Q(P, Ifixed) and not j.act(P, Tb)
        defect = j.act(fixed_image, Tq); assert defect
        euler = j.euler(defect, "p0"); assert euler, "wrong raw-domain control must not be IBP-null"
        return defect, euler
    defect, euler = stage("nonzero_basic_controls_and_wrong_raw_domain", domain_checks)
    def masters():
        result = {}
        for label, action in (("minimal", Smin), ("fixed", fixed)):
            half = a.scale(j.bracket(action, action), s.Rational(1, 2))
            current = j.current(half)
            result[label] = {"half_density": j.record(half), "current": j.record(current), "all_Euler_residuals_zero": True}
        return result
    master = stage("bounded_source_master_currents", masters)
    return {"selected_indices": indices, "canonical_pairs": len(j.pairs), "base_generators": len(j.grades), "ordinary_derivations": 1,
        "external_background_components": n, "kinetic_potential_action_included": False,
        "fields_and_sources_grades": {name: list(grade) for name, grade in j.grades.items()},
        "actions": {"source_minimal": j.record(Smin), "gauge_fermion": j.record(psi), "source_fixed": j.record(fixed)},
        "images": {"Q_min": {name: j.record(p) for name, p in Q.items()}, "Q_fixed": {name: j.record(p) for name, p in Qfixed.items()},
            "T_quantum_fixed": {name: j.record(p) for name, p in Tfixed.items()}, "iota_fixed": {name: j.record(p) for name, p in Ifixed.items()}},
        "transport": {"shifts": {name: j.record(p) for name, p in shifts.items()}, "all_40_inverse_grade_Q_and_structural_intertwiners": True, "background_action_unchanged": True,
            "all_20_canonical_pair_checks": True, "canonical_source_cross_pair_checks": 210, "ordinary_first_jet_prolongation_checks": 80},
        "pre_structural_check_counts": {"Cartan": 40, "Q_square": 40, "iota_square": 40, "TQ": 80, "local_Lie": 124, "local_iota_covariance": 80},
        "domain": {"pre_basic_source_F": j.record(F), "pre_Q_image": j.record(image), "fixed_F": j.record(FF), "fixed_Q_image": j.record(fixed_image),
            "both_controls_joint_constraints_pass": True, "arbitrary_functional_preservation_by_verified_generator_identities": True},
        "master": master, "negative_controls": {"wrong_plain_dot_Ward_residual": j.record(wrong), "wrong_raw_quantum_domain_residual": j.record(defect), "nonzero_scalar_Euler_residual": j.record(euler)},
        "maximum_jet_order": j.max_order, "jet_truncation": False, "EOM_used": False}


def build(stage=None):
    if not __debug__: raise RuntimeError("ASSERTIONS_REQUIRED")
    stage = stage or (lambda n, fn: fn())
    f, indices, gram, bridge = stage("full_H_source_coordinate_bridge", source_bridge)
    block = bounded_model(f, indices, gram, stage)
    return {"schema": "SOURCE_DOMAIN_TRANSPORT_CANDIDATE_V1", "disposition": DISPOSITION, "source_bridge": bridge, "block": block,
        "candidate": {"domain_pre": "ker(Tq_omega) intersect ker(iota_omega) intersect ker(Tb_beta), for all independent local parameters/jets modulo total derivatives",
            "domain_fixed": "U_psi domain_pre; all quantum structural operators transported; Tb unchanged only after its commutation proof",
            "Sigma_basic_required": False, "source_zero_quotient": False, "independent_parameter_then_substitution": True,
            "full_M08_qualified": False, "legacy_source_pairing_decoder_qualified": False},
        "remaining": ["bind the legacy component contraction/evaluation-source decoder, not just module labels", "derive full non-symmetric-coset and heavy-nonminimal canonical action with shifted 328 scalar", "verify complete M08 identities and joint domain under partial/light gauge fixing", "qualify full catalog descent and extended-source coverage", "external specialist semantic review"],
        "M08_changed": False, "HB1_C5_authorized": False, "cochain_dimensions_computed": False, "external_specialist_review": False, "formal_authority": "34/39_UNCHANGED", "finite_C1_GS": None}


if __name__ == "__main__": print(json.dumps(build(), sort_keys=True, separators=(",", ":")))
