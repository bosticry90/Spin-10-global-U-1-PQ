"""Diagnostic full-action variation; stdout only, no replacement promotion.

The new variation visitor fixes parity in its own path. The historical visitor
and all frozen images remain unchanged. A finite source/nonminimal test follows
the complete candidate derivation and stops further qualification on failure.
"""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path

import sympy as s

from m08_local_functional_ast import (
    add, content_hash, derivative, field, is_zero, mul, parity, scalar, source, tensor,
)
import m08_indexed_variational as old
from source_convention_control import Exterior

HERE = Path(__file__).resolve().parent


def load(relative):
    return json.loads((HERE / relative).read_text(encoding="utf-8"))


def children(n):
    if n["node"] == "Add":
        return n["terms"]
    if n["node"] == "OrderedProduct":
        return n["factors"]
    for key in ("expression", "argument", "density"):
        if key in n:
            return [n[key]]
    return []


def contains(n, name):
    return n.get("name") == name or any(contains(c, name) for c in children(n))


def expand_R(expression):
    """Composite substitution before differentiation, with fresh summed slots."""
    used = old._all_index_names(expression)
    counter = 0
    def fresh():
        nonlocal counter
        while True:
            v = f"_compositeR{counter}"
            counter += 1
            if v not in used:
                used.add(v)
                return v
    def visit(n):
        if n.get("node") == "Field" and n.get("name") == "R_H":
            i, j = fresh(), fresh()
            inside = mul(scalar("-1/2"), tensor("StructureConstant", "f", (n["indices"][0], i, j)),
                         field("u_H", parity=1, indices=(i,)), field("u_H", parity=1, indices=(j,)))
            return {"node": "GroupContraction", "contracted_indices": [i, j], "expression": inside, "parity": 0}
        r = deepcopy(n)
        if n["node"] == "Add":
            return add(*(visit(c) for c in n["terms"]))
        if n["node"] == "OrderedProduct":
            return mul(*(visit(c) for c in n["factors"]))
        for key in ("expression", "argument", "density"):
            if key in n:
                r[key] = visit(n[key])
        return r
    return visit(expression)


def jet_partial(n, *, name, node_type, order, free, kinds, target_parity):
    if not contains(n, name):
        return scalar(0)
    candidate = old._jet(n)
    if candidate is not None:
        kind, identity, indices, derivatives, _ = candidate
        if (kind, identity, derivatives) == (node_type, name, order):
            return old._component_delta(indices, free, kinds)
        return scalar(0)
    kind = n["node"]
    args = dict(name=name, node_type=node_type, order=order, free=free, kinds=kinds, target_parity=target_parity)
    if kind == "Add":
        return add(*(jet_partial(c, **args) for c in n["terms"]))
    if kind == "OrderedProduct":
        terms, before = [], 0
        for pos, item in enumerate(n["factors"]):
            partial = jet_partial(item, **args)
            if not is_zero(partial):
                terms.append(mul(scalar((-1)**(target_parity * before)), *n["factors"][:pos], partial, *n["factors"][pos+1:]))
            before += parity(item)
        return add(*terms)
    if kind in {"GroupContraction", "LorentzContraction", "LocalActionTerm"}:
        key = "density" if kind == "LocalActionTerm" else old._inner_key(n)
        partial = jet_partial(n[key], **args)
        if is_zero(partial):
            return scalar(0)
        if kind == "LocalActionTerm":
            return partial
        r = deepcopy(n)
        r[key], r["parity"] = partial, parity(partial)
        return r
    if kind == "PartialDerivative":
        raise AssertionError("SPACETIME_PRODUCT_DERIVATIVE_NOT_EXPANDED")
    return scalar(0)


def euler(n, name, free=(), kinds=(), target_parity=0, node_type="Field"):
    # Variation is linear: discard only summands with no target occurrence,
    # before expensive derivative expansion or dummy-renaming.
    if n["node"] == "Add":
        n = add(*(t for t in n["terms"] if contains(t, name)))
    if not contains(n, name):
        return scalar(0)
    n = old.expand_spacetime_derivatives(old.alpha_rename_reserved_dummies(n, set(free)))
    terms = []
    for order in sorted(old._occurrence_orders(n, name=name, node_type=node_type)):
        term = jet_partial(n, name=name, node_type=node_type, order=order, free=tuple(free), kinds=tuple(kinds), target_parity=target_parity)
        for index in reversed(order):
            term = derivative(index, term)
        terms.append(mul(scalar((-1)**len(order)), term))
    return old.simplify_contractions(old.expand_spacetime_derivatives(add(*terms)))


SPECS = {
    "K_V": ("V_H", ("i", "mu"), ("heavy", "lorentz"), 0),
    "K_q": ("q_L", ("alpha", "mu"), ("adjoint_H", "lorentz"), 0),
    "K_phi": ("eta_328", ("A",), ("scalar",), 0),
    "L_u": ("u_H", ("i",), ("heavy",), 1),
    "K_Lambda": ("Lambda_H", ("i",), ("heavy",), 0),
    "L_c": ("c_L", ("alpha",), ("adjoint_H",), 1),
}


def full_candidates():
    sigma_payload = load("frozen_source_seed_s3_s5/Sigma_M08_V1.json")
    sigma = old.sum_local_densities(sigma_payload["Sigma_M08"]["local_terms"])
    expanded = expand_R(sigma)
    couplings = load("frozen_source_seed_s3_s5/S33_source_couplings.json")["couplings"]
    # Six complete forward rows are derived from the unchanged action.
    forward, reverse, chain = {}, {}, {}
    for name, (z, free, kinds, p) in SPECS.items():
        forward[z] = euler(sigma, name, free, kinds, 1-p, "ExternalSource")
        reverse[name] = euler(expanded, z, free, kinds, p)
        if z == "u_H":
            without_chain = euler(sigma, z, free, kinds, p)
            chain[name] = {"expanded_R_changes_expression": content_hash(reverse[name]) != content_hash(without_chain),
                           "without_composite_chain_AST": without_chain}
    # Scalar views use the same certified constrained E^dagger G lowering as
    # the old action, but the variational templates are freshly constructed.
    potential = load("frozen_action_ast_a3/A38_parent_potential_ASTs.json")
    views = {"Phi": (("I", "J"), ("generic",)*2), "Sigma": (tuple(f"I{i}" for i in range(5)), ("generic",)*5),
             "SigmaBar": (tuple(f"I{i}" for i in range(5)), ("generic",)*5), "phi": (("I",), ("generic",)),
             "phiBar": (("I",), ("generic",)), "S": ((), ()), "SBar": ((), ())}
    templates = []
    for direction, n in sorted(potential["directions"].items()):
        for view, (free, kinds) in views.items():
            gradient = euler(n, view, free, kinds)
            if not is_zero(gradient):
                templates.append({"coefficient_direction": direction, "tensor_view": view, "gradient_AST": gradient})
    embeddings = load("frozen_action_ast_a3/A31_embeddings.json")
    bridges = load("frozen_action_ast_a3/A34_complex_real_bridges.json")
    coordinate_rows, offset = [], 0
    for sector in ("Phi", "Sigma", "phi", "S"):
        for name in embeddings["sectors"][sector]["coordinate_names"]:
            z = "x_" + name.replace(".", "_")
            coordinate_rows.append({"coordinate": offset, "sector": sector, "field": z,
                                    "kinetic_AST": mul(scalar(-1), derivative("mu", derivative("mu", field(z))))})
            offset += 1
    assert offset == 328
    scalar_bundle = {"canonical_target": "CANONICAL_328_REAL", "coordinate_count": 328,
                     "coordinate_kinetic_rows": coordinate_rows, "potential_tensor_gradients": templates,
                     "eta_gradient_AST": reverse["K_phi"], "lowering": "E_dagger G; add kinetic, potential and eta contributions",
                     "embedding_artifact_sha256": embeddings["artifact_sha256"], "bridge_artifact_sha256": bridges["artifact_sha256"]}
    # Noncanonical images are recovered from the frozen explicit ST operator,
    # not differentiated with respect to nonexistent antifields.
    heavy = load("frozen_source_seed_s3_s5/S30_offshell_source_zero_action.json")["action"]["local_terms"][-1]["term"]
    expressions = {**reverse, "V_H_mu": forward["V_H"], "q_L_mu": forward["q_L"], "phi": forward["eta_328"],
                   "Lambda_H": forward["Lambda_H"], "u_H": forward["u_H"], "c_L": forward["c_L"],
                   "Abar_H_mu": scalar(0), "cbar_L": mul(scalar(-1), field("lambda_L", indices=("alpha",))),
                   "lambda_L": scalar(0)}
    # This identical expression occurs in the actual heavy gauge-fixing AST.
    ubar_candidates = []
    def visit(n):
        if n["node"] == "Add" and contains(n, "Lambda_H") and contains(n, "c_L") and contains(n, "ubar_H") and not contains(n, "R_H"):
            if all(c["node"] == "OrderedProduct" for c in n["terms"]) and len(n["terms"]) == 2:
                if any(any(x.get("name") == "Lambda_H" for x in c["factors"]) for c in n["terms"]):
                    ubar_candidates.append(n)
        for c in children(n):
            visit(c)
    visit(heavy)
    assert ubar_candidates
    expressions["ubar_H"] = deepcopy(ubar_candidates[0])
    free_ubar = next(x["indices"][0] for c in expressions["ubar_H"]["terms"] for x in c["factors"] if x.get("name") == "Lambda_H")
    expressions["ubar_H"] = old._replace_index(expressions["ubar_H"], free_ubar, "i")
    # Derive Q R in index form from its definition and freshly recovered Q u.
    # Output slots are alpha; u_i/u_j slots are renamed before substitution.
    ui, uj = field("u_H", parity=1, indices=("_ri",)), field("u_H", parity=1, indices=("_rj",))
    qi = old._replace_index(forward["u_H"], "i", "_ri")
    qj = old._replace_index(forward["u_H"], "i", "_rj")
    expressions["R_H"] = mul(scalar("-1/2"), tensor("StructureConstant", "f", ("alpha", "_ri", "_rj")),
                               add(mul(qi, uj), mul(scalar(-1), ui, qj)))
    expressions["K_phi"] = {"factorized_bundle_sha256": content_hash(scalar_bundle)}
    old_rows = load("frozen_rh_composite_adjudication/S6_BSigma_17_images_V2.json")["images"]
    impacts = []
    for row in old_rows:
        identity = row["identity"]
        impacts.append({"identity": identity, "candidate_expression_sha256": content_hash(expressions[identity]),
                        "old_expression_sha256": content_hash(row["B_Sigma_image"]),
                        "syntactically_identical": expressions[identity] == row["B_Sigma_image"],
                        "comparison_scope": "RAW_AST_ONLY_NOT_QUOTIENT_EQUIVALENCE"})
    old_scalar = load("frozen_variational_s5_s8/V4_V5_scalar_gradient_bundle.json")["scalar_gradient_bundle"]
    scalar_comparison = {
        "eta_gradient_syntactically_identical": scalar_bundle["eta_gradient_AST"] == old_scalar["eta_328_full_gradient_AST"],
        "eta_gradient_ordered_tensor_terms_equal": ordered_tensor_terms(scalar_bundle["eta_gradient_AST"], {"A"}) == ordered_tensor_terms(old_scalar["eta_328_full_gradient_AST"], {"A"}),
        "potential_template_count": len(templates),
        "potential_templates_syntactically_identical": all(
            (r["coefficient_direction"], r["tensor_view"], r["gradient_AST"]) ==
            (o["coefficient_direction"], o["tensor_view"], o["gradient_AST"])
            for r, o in zip(templates, old_scalar["potential_tensor_gradient_templates"], strict=True)),
        "comparison_is_not_imported_candidate_coefficients": True,
    }
    ubar_comparison = ordered_tensor_terms(expressions["ubar_H"], {"i"}) == ordered_tensor_terms(
        next(r["B_Sigma_image"] for r in old_rows if r["identity"] == "ubar_H"), {"i"})
    assert len(expressions) == len(impacts) == 17
    return {"schema": "M08_SOURCE_CONVENTION_FULL_CANDIDATE_IMAGES_V1", "status": "DIAGNOSTIC_INACTIVE",
            "Sigma_canonical_sha256": sigma_payload["Sigma_M08"]["canonical_action_sha256"],
            "expressions": expressions, "scalar_gradient_bundle": scalar_bundle, "impact": impacts,
            "scalar_impact": scalar_comparison,
            "ubar_impact": {"equal_after_dummy_renaming": ubar_comparison},
            "composite_chain_rule_impact": chain, "source_coupling_count": len(couplings),
            "complete_variation_not_complete_consistency_qualification": True}


def flat_terms(n):
    if n["node"] in {"GroupContraction", "LorentzContraction", "LocalActionTerm"}:
        return flat_terms(n.get("expression", n.get("argument", n.get("density"))))
    if n["node"] == "Add":
        return [t for c in n["terms"] for t in flat_terms(c)]
    if n["node"] == "OrderedProduct":
        result = [[]]
        for c in n["factors"]:
            result = [a+b for a in result for b in flat_terms(c)]
        return result
    return [[n]]


def ordered_tensor_terms(n, free):
    """Bounded comparison: distribute sums/scalars and rename dummy indices.

    Does not permute factors, invoke Jacobi/Schouten, or prove quotient descent.
    Used only for like-ordered ubar and scalar-gradient impact controls.
    """
    result = {}
    for factors in flat_terms(n):
        coefficient, mapping = s.Integer(1), {}
        def rename(index):
            if index in free:
                return index
            if index not in mapping:
                mapping[index] = f"dummy{len(mapping)}"
            return mapping[index]
        def visit(leaf):
            r = deepcopy(leaf)
            if "indices" in r:
                r["indices"] = [rename(i) for i in r["indices"]]
            if r["node"] == "PartialDerivative":
                r["index"] = rename(r["index"])
                r["argument"] = visit(r["argument"])
            return r
        row = []
        for leaf in factors:
            if leaf["node"] == "ExactScalar":
                coefficient *= s.sympify(leaf["value"])
            else:
                row.append(visit(leaf))
        key = json.dumps(row, sort_keys=True, separators=(",", ":"))
        result[key] = s.expand(result.get(key, 0)+coefficient)
    return {k: str(v) for k, v in result.items() if v != 0}


def free_projection(n, a, variables):
    """Extract the g^0, zero-source, zero-scalar free jet AFTER variation."""
    out = {}
    for factors in flat_terms(n):
        p = {(): s.Integer(1)}
        for node in factors:
            kind = node["node"]
            if kind == "ExactScalar":
                p = a.scale(p, s.sympify(node["value"]))
            elif kind == "Parameter":
                p = a.scale(p, 0 if node["name"] == "g10" else s.Symbol(node["name"]))
            elif kind == "KroneckerMetric" and node["name"] == "P_m_exact":
                pass  # identity on the certified heavy subspace
            else:
                jet = old._jet(node)
                if jet and jet[0] == "Field":
                    z, indices, order = jet[1:4]
                    key = (z, order)
                    p = a.mul(p, variables.get(key, {}))
                else:
                    p = {}
            if not p:
                break
        out = a.add(out, p)
    return out


def decisive_primary(candidate):
    a = Exterior()
    u2 = a.variable("u_second_jet", 1)
    lam = a.variable("Lambda", 0)
    divV = a.variable("div_V", 0)
    k = a.variable("K_Lambda", 1)
    bar = a.variable("ubar", 1)
    u = a.variable("u", 1)
    xi = s.Symbol("xi")
    variables = {("u_H", ("mu", "mu")): u2, ("Lambda_H", ()): lam,
                 ("V_H", ("mu",)): divV, ("ubar_H", ()): bar, ("u_H", ()): u}
    action = load("frozen_source_seed_s3_s5/S30_offshell_source_zero_action.json")["action"]["local_terms"]
    heavy = next(r["term"] for r in action if r["sector"] == "HEAVY_EQUIVARIANT_GAUGE_FIXING_AND_GHOST_OFFSHELL")
    Sfree = free_projection(heavy, a, variables)
    expected = a.add(a.scale(a.mul(bar, u2), -1), a.scale(a.mul(lam, divV), -1), a.scale(a.mul(lam, lam), xi/2))
    assert Sfree == expected, "FROZEN_FREE_HEAVY_ACTION_PROJECTION_DISAGREES"
    qk = free_projection(candidate["expressions"]["K_Lambda"], a, variables)
    assert qk == a.add(a.scale(divV, -1), a.scale(lam, xi)), "COMPLETE_KLAMBDA_VARIATION_PROJECTION_CHANGED"
    images = {"div_V": u2, "Lambda": {}, "ubar": a.scale(lam, -1), "u": {}, "u_second_jet": {}, "K_Lambda": qk}
    # Q div V is div QV = box u, using the frozen derivative prolongation.
    q2k = a.derive(qk, images)
    F = a.mul(k, lam)
    qF = a.derive(F, images)
    q2F = a.derive(qF, images)
    assert q2k == a.scale(u2, -1) and q2F == a.scale(a.mul(lam, u2), -1)
    assert not a.derive(Sfree, images), "FREE_ACTION_SYMMETRY_CONTROL_FAILED"
    pairs = [("Lambda", "K_Lambda")]
    T = {"ubar": a.scale(lam, -1)}
    # For an odd Poisson bracket, an odd derivation obeys
    # T(F,G)=(TF,G)+(-1)^(|F|+1)(F,TG). Here F=ubar is odd.
    bracket_defect = a.add(a.derive(a.bracket(bar, k, pairs), T),
                           a.scale(a.bracket(a.derive(bar, T), k, pairs), -1))
    assert bracket_defect == {(): s.Integer(1)}
    # Conventional elimination of a constant trivial pair is a contrast only:
    # move Lambda out of the six-pair bracket and omit its source.
    assert not a.derive(a.scale(lam, -1), images)
    return {"schema": "M08_SOURCE_CONVENTION_IMPACT_PREFLIGHT_V1",
            "status": "BLOCKED_EXACT_NONMINIMAL_SOURCE_SQUARE",
            "blocker": "M08_C5_COHERENT_SOURCE_CONVENTION_NONMINIMAL_PAIRING_NOT_CLOSED",
            "coupling_sector": "Quadratic heavy-action sector at g10^0; arbitrary xi; source-zero projection AFTER variation; retain div V and box u jets",
            "free_heavy_action": a.record(Sfree), "Q_K_Lambda": a.record(qk), "Q2_K_Lambda": a.record(q2k),
            "test_pairing": a.record(F), "Q_pairing": a.record(qF), "Q2_pairing": a.record(q2F),
            "free_action_Q_residual": [], "Q2_pairing_box_u_coefficient": "-Lambda",
            "T_antibracket_derivation_residual_ubar_KLambda": a.record(bracket_defect),
            "pairing_grade": {"d": 3, "gh": -1, "w": 4}, "square_grade": {"d": 5, "gh": 1, "w": 4},
            "IBP_nonzero_certificate": "Euler derivative of -Lambda*box(u) with respect to Lambda is -box(u), nonzero",
            "EOM_used": False, "new_source_added": False, "candidate_promoted": False,
            "complete_master_Cartan_basic_descent_gates": "NOT_REACHED_AFTER_FAILED_SOURCE_SQUARE",
            "coefficient_isolation": "Extract the degree-one box(u) coefficient in Q2 K_Lambda; remaining source terms carry g10 and other g10^0 terms have higher field degree with no constant physical-field Q image",
            "scope_limit": "Rejects the specified six-pair full-Weil candidate; not every relative/BV domain or alternative source formulation"}


def even_variation_control():
    z = field("q_L", indices=("beta", "mu"))
    k = source("K_q", parity=1, indices=("alpha", "mu"))
    c = field("c_L", parity=1, indices=("gamma",))
    # This is the actual ordering of the K_q q_L c_L source monomial.
    n = mul(k, z, c)
    current = old.indexed_euler_lagrange(n, name="q_L", free_indices=("B", "N"), index_kinds=("adjoint_H", "lorentz"), side="left")
    coherent = euler(n, "q_L", ("B", "N"), ("adjoint_H", "lorentz"), 0)
    assert current == mul(scalar(-1), coherent)
    return {"input_AST": n, "frozen_visitor_AST": current, "parity_aware_visitor_AST": coherent,
            "opposite_sign": True, "meaning": "Even target parity is zero; no Grassmann crossing sign is allowed",
            "scope": "Actual source-factor ordering, with invariant coefficient suppressed; no old file modified"}


def build():
    if not __debug__:
        raise RuntimeError("EXACT_IMPACT_REQUIRES_ASSERTIONS_ENABLED")
    candidate = full_candidates()
    return {"candidate": candidate, "preflight": decisive_primary(candidate), "even_variation_control": even_variation_control()}


if __name__ == "__main__":
    print(json.dumps(build(), indent=2, sort_keys=True))
